"""
VaultLayer — Server-Side Job Lifecycle Worker

Handles the full lifecycle: provision -> monitor -> terminate -> recover

Extracted from job_routes.py. Shared state (_active_jobs, _job_queue, etc.)
is defined here and imported by job_routes.py and admin_routes.py.
"""
import asyncio
import hashlib
import hmac
import logging
import math
import os
import time
from datetime import datetime, timezone
from typing import Optional

from api.db import get_db, _db_call

logger = logging.getLogger(__name__)


# ── Server-side job state ────────────────────────────────────────────────────

_active_jobs: dict[str, dict] = {}   # job_id -> full job state
_job_queue: list[str] = []            # FIFO list of job_ids waiting for GPU
_job_lock = asyncio.Lock()

_worker_debug = {"started": False, "last_error": None, "broker_ok": False, "cycle_count": 0, "last_provision_attempts": []}

_broker_instance = None


# ── Provision backoff & retry (unified across preferred-set / empty-preferred) ─
#
# Before: preferred_providers=set jobs died after the first capacity failure;
# empty-preferred jobs hammered every provider every 3s forever. Neither is
# right — transient capacity droughts (e.g. AWS V100 spot pool dry for 5-15
# min) should requeue, not kill the job; and retries should back off so a
# multi-hour drought doesn't generate millions of provider API calls.
#
# Applies only when is_retryable(failure_code) — auth/schema failures still
# fail immediately since they won't clear by waiting.
_PROVISION_BACKOFF_SCHEDULE = [30, 120, 600, 1800]  # 30s, 2m, 10m, 30m
_PROVISION_MAX_TOTAL_SECONDS = 2 * 3600  # give up after 2h of retrying
# After this many retries on the initial GPU type, walk to the next BFS alternative.
# Auto-selected jobs should not sit on a stale cheapest-GPU choice when the provider
# immediately says "no capacity"; move to the next priced, VRAM-valid option in the
# same worker cycle. User-specified GPUs keep standard backoff.
_PROVISION_BFS_TRIGGER_COUNT = 0

from shared.gpu_sizing import (
    GPU_FALLBACK_CHAIN as _JW_FALLBACK_CHAIN,
    GPU_VRAM_GB as _JW_GPU_VRAM_GB,
    bfs_gpu_fallback as _shared_bfs_gpu_fallback,
    gpu_vram_gb as _shared_gpu_vram_gb,
    min_vram_for_model as _shared_min_vram_for_model,
    disk_gb_for_model as _shared_disk_gb_for_model,
)


_PROVIDER_DB_NAMES = {
    "Vast.ai": "vast_ai",
    "RunPod": "runpod",
    "Lambda Labs": "lambda_labs",
    "AWS": "aws",
    "AWS Spot": "aws",
    "GCP": "gcp",
    "Azure": "azure",
    "CoreWeave": "coreweave",
    "Voltage Park": "voltage_park",
    "Crusoe": "crusoe",
    "Nebius": "nebius",
    "Nebius (EU)": "nebius",
    "Hyperstack": "hyperstack",
}


def _gpu_has_dispatchable_price(gpu_type: str, job: dict) -> bool:
    """True if the fallback GPU has at least one priced, allowed provider."""
    try:
        from shared.data_loader import (
            get_provider_prices,
            resolve_gpu_key,
            get_included_providers,
            get_testing_providers,
            user_can_use_testing_providers,
        )
        gpu_key = resolve_gpu_key(gpu_type)
        prices = get_provider_prices()
        included = set(get_included_providers())
        if user_can_use_testing_providers(job.get("user_id", "")):
            included |= set(get_testing_providers())
    except Exception:
        return True

    excluded = set(job.get("excluded_providers") or [])
    preferred = list(job.get("preferred_providers") or [])
    for provider_name, gpu_prices in prices.items():
        if provider_name.startswith("_") or "Reserved" in provider_name or "On-Demand" in provider_name:
            continue
        if included and provider_name not in included:
            continue
        provider_db_name = _PROVIDER_DB_NAMES.get(provider_name)
        if not provider_db_name:
            continue
        if provider_name in excluded or provider_db_name in excluded:
            continue
        if preferred and provider_name not in preferred and provider_db_name not in preferred:
            continue
        price = gpu_prices.get(gpu_key) if isinstance(gpu_prices, dict) else None
        if isinstance(price, (int, float)) and price > 0:
            return True
    return False


def _generate_job_token(job_id: str) -> str:
    """Generate HMAC job token for container auth.

    Requires SUPABASE_SERVICE_KEY or VL_JOB_SECRET to be set.
    Falls back to a per-process random secret if neither is available
    (safe for single-process Railway deployment, tokens are ephemeral).
    """
    secret = os.environ.get("SUPABASE_SERVICE_KEY") or os.environ.get("VL_JOB_SECRET") or ""
    if not secret:
        # Generate a random per-process secret so tokens are unpredictable
        if not hasattr(_generate_job_token, "_fallback_secret"):
            import secrets as _secrets
            _generate_job_token._fallback_secret = _secrets.token_hex(32)
            logger.warning("[job-token] No SUPABASE_SERVICE_KEY or VL_JOB_SECRET set — using random per-process secret")
        secret = _generate_job_token._fallback_secret
    return hmac.new(secret[:32].encode(), job_id.encode(), hashlib.sha256).hexdigest()[:32]


def _init_broker():
    """Initialize BrokerAgent with server-side config."""
    global _broker_instance
    if _broker_instance is not None:
        return _broker_instance
    try:
        # Server-side: map Railway env vars to what load_config() expects
        # Railway uses VL_* prefix, load_config() uses bare names
        _ENV_MAP = {
            "VL_VAST_AI_API_KEY": "VAST_AI_API_KEY",
            "VL_RUNPOD_API_KEY": "RUNPOD_API_KEY",
            "VL_LAMBDA_LABS_API_KEY": "LAMBDA_LABS_API_KEY",
            "VL_COREWEAVE_API_KEY": "COREWEAVE_API_KEY",
            "VL_VOLTAGE_PARK_API_KEY": "VOLTAGE_PARK_API_KEY",
            "VL_CRUSOE_API_KEY": "CRUSOE_API_KEY",
            "VL_HYPERSTACK_API_KEY": "HYPERSTACK_API_KEY",
            "VL_NEBIUS_API_KEY": "NEBIUS_API_KEY",
        }
        for vl_key, bare_key in _ENV_MAP.items():
            val = os.environ.get(vl_key, "")
            if val and not os.environ.get(bare_key):
                os.environ[bare_key] = val

        if not os.environ.get("VAULTLAYER_TOKEN"):
            _svc_key = os.environ.get("SUPABASE_SERVICE_KEY", "")
            if _svc_key:
                os.environ["VAULTLAYER_TOKEN"] = f"vl_server_{_svc_key[:16]}"

        from shared.config import load_config, CloudflareConfig
        from agents.broker.agent import BrokerAgent
        from shared.queue import AgentQueue
        config = load_config()

        # Inject R2 credentials from Railway env vars (broker reads these for onstart scripts)
        if not config.cloudflare:
            _r2_ep = os.environ.get("R2_ENDPOINT", "")
            _r2_key = os.environ.get("R2_ACCESS_KEY_ID", "")
            _r2_sec = os.environ.get("R2_SECRET_ACCESS_KEY", "")
            if _r2_ep and _r2_key and _r2_sec:
                config.cloudflare = CloudflareConfig(
                    account_id=os.environ.get("CLOUDFLARE_ACCOUNT_ID", "managed"),
                    r2_access_key_id=_r2_key, r2_secret_access_key=_r2_sec,
                    r2_bucket=os.environ.get("R2_BUCKET", "vaultlayer-checkpoints"),
                    r2_endpoint=_r2_ep, cf_master_token="",
                )

        # Create a minimal queue object (broker needs it but we don't use pub/sub)
        q = AgentQueue.__new__(AgentQueue)
        q.published = []
        q._job_states = {}
        _broker_instance = BrokerAgent(config, q)

        # Set the VAULTLAYER_TOKEN on the broker config so _get_managed_credentials works
        # On Railway, use any valid token from the api_tokens table
        if not getattr(config, 'token', None) or config.token.startswith('vl_server_'):
            # Try to find a valid token from the database
            try:
                db = get_db()
                result = db.table("api_tokens").select("token_hash, user_id").limit(1).execute()
                if result.data:
                    # We can't reverse the hash, but the broker needs the token for API calls.
                    # Since the broker IS the server, we bypass by setting provider configs directly.
                    pass
            except Exception:
                pass

        # Warm GPU resolver cache with all available provider keys.
        # Runs async so it doesn't block broker init — cache populates in background.
        try:
            _warm_keys: dict[str, str] = {}
            if getattr(config, "runpod", None):
                _warm_keys["RunPod"] = config.runpod.api_key
            if getattr(config, "vast_ai", None):
                _warm_keys["Vast.ai"] = config.vast_ai.api_key
            if getattr(config, "lambda_labs", None):
                _warm_keys["Lambda Labs"] = config.lambda_labs.api_key
            if _warm_keys:
                asyncio.create_task(
                    _broker_instance.gpu_resolver.warm(_warm_keys),
                    name="gpu-resolver-warm",
                )
        except Exception as _warm_err:
            logger.debug(f"[broker] GPU cache warm failed (non-fatal): {_warm_err}")

        logger.info("Job worker: broker initialized successfully")
        return _broker_instance
    except Exception as e:
        _worker_debug["last_error"] = f"broker init failed: {type(e).__name__}: {e}"
        logger.error(f"Job worker: broker init FAILED: {e}", exc_info=True)
        return None


async def _try_provision(broker, job: dict) -> Optional[str]:
    """Try provisioning on cheapest available provider. Returns instance_id or None."""
    from shared.models import Job, Provider, GPUType, JobStatus
    from shared.data_loader import get_provider_prices, resolve_gpu_key, resolve_gpu_enum, reload

    reload()

    # Validate R2 credentials are available (required for checkpoint I/O)
    if not broker.config.cloudflare:
        logger.warning("[provision] R2/Cloudflare config not set — checkpoints will be local-only (not persisted to R2)")
    elif not broker.config.cloudflare.r2_access_key_id:
        logger.warning("[provision] R2 access key is empty — checkpoints will be local-only")

    gpu_type_str = job["gpu_type"]
    try:
        gpu_type_enum = resolve_gpu_enum(gpu_type_str, strict=True)
    except TypeError:
        # Compatibility for tests or older monkeypatches that do not accept
        # keyword arguments.
        gpu_type_enum = resolve_gpu_enum(gpu_type_str)
    except ValueError as exc:
        job["failure_code"] = "prov_schema_reject"
        job["_provision_attempts"] = [{
            "provider": "validation",
            "error": f"unknown gpu_type {gpu_type_str!r}: {exc}",
        }]
        logger.error(
            "[provision] Rejecting unknown gpu_type %s for job %s",
            gpu_type_str, job.get("job_id", "")[:8],
        )
        return None

    # Inject job token into container environment for auth
    _job_token = _generate_job_token(job["job_id"])
    job["environment"]["VL_JOB_TOKEN"] = _job_token
    job["environment"]["VAULTLAYER_API_URL"] = os.environ.get(
        "VAULTLAYER_API_URL", "https://vaultlayer-production.up.railway.app"
    )
    _disk_gb = max(
        int(job.get("disk_gb") or 0),
        _shared_disk_gb_for_model(
            job.get("model_params_billion"), job.get("training_mode") or "qlora"
        ),
    )
    job["disk_gb"] = _disk_gb
    if _disk_gb > 100:
        # Large HF models download full safetensor shards before quantization.
        # Keep caches under /workspace so container providers with separate
        # workspace/volume sizing do not fill the root overlay.
        job["environment"].setdefault("HF_HOME", "/workspace/.cache/huggingface")
        job["environment"].setdefault("HF_HUB_CACHE", "/workspace/.cache/huggingface/hub")
        job["environment"].setdefault("HF_XET_CACHE", "/workspace/.cache/huggingface/xet")
        job["environment"].setdefault("TRANSFORMERS_CACHE", "/workspace/.cache/huggingface/transformers")

    # Inject script into environment so onstart can decode and run it.
    #
    # For scripts larger than the inline threshold (issue #71), we upload
    # to R2 and pass a signed URL via VL_SCRIPT_URL instead. The onstart
    # curls from the URL and execs. This bypasses Vast.ai's 16 KB onstart
    # cap and keeps AWS UserData well under its 16 KB limit regardless of
    # user script size.
    if job.get("script_b64"):
        from shared.script_upload import should_route_via_r2, upload_script_and_sign
        _script_name = job.get("script_name") or "script.py"
        job["environment"]["VL_SCRIPT_NAME"] = _script_name

        if should_route_via_r2(job["script_b64"]):
            _url = upload_script_and_sign(
                job_id=job["job_id"],
                script_b64=job["script_b64"],
                script_name=_script_name,
            )
            if _url:
                job["environment"]["VL_SCRIPT_URL"] = _url
                # Don't also send B64 — reduces onstart payload.
            else:
                # R2 upload failed for a script that needs it. Falling back
                # to inline would re-enter the exact provider payload limits
                # the R2 path was meant to avoid (Vast.ai 16 KB, AWS 16 KB).
                # Fail fast with a clear error rather than let provisioning
                # fail late with an opaque provider error.
                from shared import script_upload as _su
                _reason = _su.LAST_UPLOAD_ERROR or "unknown"
                raise RuntimeError(
                    f"Script exceeds inline size limit and R2 upload failed "
                    f"({_reason}). Check R2_ENDPOINT / R2_ACCESS_KEY_ID / "
                    f"R2_SECRET_ACCESS_KEY config and retry."
                )
        else:
            # Small scripts skip the R2 hop
            job["environment"]["VL_SCRIPT_B64"] = job["script_b64"]
    if job.get("script_name"):
        job["environment"]["VL_SCRIPT_NAME"] = job["script_name"]
    if job.get("script_args"):
        job["environment"]["VL_SCRIPT_ARGS"] = job["script_args"]

    # Build Job object for broker. Thread the constraint-satisfaction filters
    # (preferred_providers / regions / their exclusions) onto the model so the
    # broker's _check_region_allowed and any provider-aware paths see the same
    # constraints the API validated. Empty lists carry the "no constraint"
    # semantic naturally.
    model_job = Job(
        job_id=job["job_id"], user_id=job["user_id"], name=f"job-{job['job_id'][:8]}",
        status=JobStatus.RUNNING, provider=Provider.AWS, gpu_type=gpu_type_enum,
        instance_id="pending", region="us", command=job.get("script_args", ""),
        model_params_billion=float(job.get("model_params_billion") or 0.0),
        training_mode=job.get("training_mode") or "qlora",
        disk_gb=_disk_gb,
        environment=job.get("environment", {}),
        docker_image=job.get("docker_image") or "",
        failover_enabled=job.get("failover", True),
        preferred_providers=list(job.get("preferred_providers") or []),
        excluded_providers=list(job.get("excluded_providers") or []),
        regions=list(job.get("regions") or []),
        excluded_regions=list(job.get("excluded_regions") or []),
        dataset_id=job.get("dataset_id") or None,
    )

    # Try providers sorted by price
    # Maps display name (from provider_prices JSON) → (broker method, Provider enum value)
    # All 11 providers are wired — cheapest available wins.
    #
    # Aliases exist because config/vaultlayer_data.json uses longer pricing-key
    # variants ("AWS Spot", "Nebius (EU)") while the broker methods and DB
    # Provider enum use short names. Missing aliases here cause silent routing
    # drops — e.g. "AWS Spot" rows were skipped entirely and provision_aws()
    # was never called regardless of preferred_provider. Keep both the short
    # name and every pricing-table variant mapped.
    _PROV_METHODS = {
        "Vast.ai": ("provision_vast", "vast_ai"),
        "RunPod": ("provision_runpod", "runpod"),
        "Lambda Labs": ("provision_lambda", "lambda_labs"),
        "AWS": ("provision_aws", "aws"),
        "AWS Spot": ("provision_aws", "aws"),            # pricing-key alias
        "GCP": ("provision_gcp", "gcp"),
        "Azure": ("provision_azure", "azure"),
        "CoreWeave": ("provision_coreweave", "coreweave"),
        "Voltage Park": ("provision_voltage_park", "voltage_park"),
        "Crusoe": ("provision_crusoe", "crusoe"),
        "Nebius": ("provision_nebius", "nebius"),
        "Nebius (EU)": ("provision_nebius", "nebius"),   # pricing-key alias
        "Hyperstack": ("provision_hyperstack", "hyperstack"),
    }

    _gpu_key = resolve_gpu_key(gpu_type_str)
    prices = get_provider_prices()
    excluded = set(job.get("excluded_providers", []))
    preferred = list(job.get("preferred_providers") or [])

    # Failover override: when excluded_providers fully covers preferred_providers
    # (i.e. failover has kicked in and ruled out every user-chosen provider),
    # drop the preference so we can fall back to other providers. Without this
    # the job would deadlock: "must match preferred" + "every preferred is
    # excluded" → nothing dispatches.
    if preferred and set(preferred) <= excluded:
        logger.info(
            f"[provision] All preferred providers {preferred} are in the excluded "
            f"list {sorted(excluded)}; dropping preference so failover can try "
            f"other providers."
        )
        preferred = []

    # Resume-leg preference: when a job died alive and is being resumed, try
    # the prior provider FIRST (regardless of price-sort) so we don't pay
    # checkpoint+egress costs to migrate when capacity has likely returned.
    # The constraint-satisfaction spec is explicit: step (a) on a resume leg
    # is "original provider within regions", step (b) is "any other routable
    # provider". We honour exclusions either way.
    _resume_pref = job.get("_resume_prefer_provider") or ""

    def _sort_key(item):
        name, gpus = item
        is_resume = 0 if (_resume_pref and (name == _resume_pref
                                            or _PROV_METHODS.get(name, (None, None))[1] == _resume_pref)) else 1
        price = (gpus.get(_gpu_key) or 999) if isinstance(gpus, dict) else 999
        return (is_resume, price)

    # Three-state allowlist filter (config/vaultlayer_data.json:included_providers).
    # Regular users: dispatcher only considers `providers` (production-included).
    # Test users (in VL_TEST_USER_IDS): also considers `testing` providers, so
    # an allowlisted test user's failover pool can include a still-being-validated
    # provider. Production users' failover pool NEVER includes testing providers,
    # which is the safety guarantee of the three-state model.
    # See docs/provider_test_matrix.md (production) and docs/provider_testing_matrix.md.
    from shared.data_loader import (
        get_included_providers as _get_included,
        get_testing_providers as _get_testing,
        user_can_use_testing_providers as _user_can_test,
    )
    _included = set(_get_included())
    if _user_can_test(job.get("user_id", "")):
        _included = _included | set(_get_testing())

    attempts = []
    for prov_name, gpu_prices in sorted(prices.items(), key=_sort_key):
        if prov_name.startswith("_") or "Reserved" in prov_name or "On-Demand" in prov_name:
            continue
        # Skip providers not in the included allowlist (when one is set)
        if _included and prov_name not in _included:
            attempts.append({"provider": prov_name, "skip": "not_in_included_providers"})
            continue
        prov_info = _PROV_METHODS.get(prov_name)
        if not prov_info:
            continue
        # If preferred_providers is set, only consider matching entries
        # (match either the pricing-key display name or the short Provider
        # value — both are valid identifiers for a given provider). Exception:
        # a resume-leg's prior provider is allowed through even when not in
        # preferred_providers, per the spec's step (a). Exclusions still
        # apply below — never relaxed.
        method_name, provider_db_name = prov_info
        is_resume_pref = bool(_resume_pref and (
            prov_name == _resume_pref or provider_db_name == _resume_pref
        ))
        if preferred and not is_resume_pref:
            if (provider_db_name not in preferred
                    and prov_name not in preferred):
                continue
        if prov_name in excluded or provider_db_name in excluded:
            attempts.append({"provider": prov_name, "skip": "excluded"})
            continue
        price = gpu_prices.get(_gpu_key) if isinstance(gpu_prices, dict) else None
        if not isinstance(price, (int, float)) or price <= 0:
            attempts.append({"provider": prov_name, "skip": f"no_price_for_{_gpu_key}"})
            continue

        fn = getattr(broker, method_name, None)
        if not fn:
            attempts.append({"provider": prov_name, "skip": "no_method"})
            continue
        # Per-provider concurrency cap: skip providers that have hit their
        # max concurrent job threshold. Without this check, the worker could
        # launch more jobs than a provider can handle, causing queuing/rejection.
        try:
            from shared.provider_capacity import is_provider_at_capacity, claim_provider_slot as _claim_slot
            if is_provider_at_capacity(provider_db_name):
                attempts.append({"provider": prov_name, "skip": "provider_at_capacity"})
                logger.debug(f"[provision] {prov_name} at capacity — skipping this cycle")
                continue
        except ImportError:
            _claim_slot = None  # capacity guard not available — allow all
        try:
            result = await fn(gpu_type_enum, model_job)
            if result:
                attempts.append({"provider": prov_name, "result": str(result)[:20]})
                job["instance_id"] = result
                job["provider"] = provider_db_name
                # Register the job against this provider's concurrency counter now
                # that provisioning succeeded. Idempotent — safe to call even if
                # the slot was already claimed by a prior attempt on the same provider.
                try:
                    if _claim_slot:
                        _claim_slot(provider_db_name, job.get("job_id", ""))
                except Exception:
                    pass  # non-fatal; capacity tracking is best-effort
                # Prefer the real accepted rate from the provider (set on
                # model_job.current_hourly_rate) over the cached config
                # rate — otherwise we bill the user at a stale price.
                # Only vast_ai currently sets this; other providers fall
                # back to the config price.
                _real_rate = float(getattr(model_job, "current_hourly_rate", 0) or 0)
                job["price_per_hr"] = _real_rate if _real_rate > 0 else price
                if _real_rate > 0 and abs(_real_rate - price) > 0.001:
                    logger.info(
                        f"[provision] {prov_name} accepted at ${_real_rate:.4f}/hr "
                        f"(config was ${price:.4f}/hr) for {_gpu_key}"
                    )
                job["actual_gpu_type"] = _gpu_key
                # Capture actual placement (zone/region) from the provider's
                # in-process cache so the fence path can use the correct location
                # even after a restart that wipes provider-specific caches.
                # Stored on the job dict and persisted to job_runs.metadata by
                # _record_provision_to_db() so it survives Railway redeploys.
                _placement: dict = {}
                if provider_db_name == "gcp":
                    _gcp_info = getattr(broker, "_gcp_sa_info", {}).get(result, {})
                    if _gcp_info.get("zone"):
                        _placement["zone"] = _gcp_info["zone"]
                        _placement["project_id"] = _gcp_info.get("project_id", "")
                elif provider_db_name == "aws":
                    _placement["region"] = (
                        getattr(model_job, "region", "") or job.get("region", "")
                    )
                if _placement:
                    job["_placement"] = _placement
                # Stash attempts on BOTH the per-job dict (primary, race-free)
                # and the shared _worker_debug global (kept for legacy admin
                # endpoints). The failure-reporting path at the caller reads
                # the per-job dict first; the shared dict was racing across
                # concurrent provisions — job B's success could overwrite
                # job A's attempts and job A would then surface "unknown".
                job["_provision_attempts"] = attempts
                _worker_debug["last_provision_attempts"] = attempts
                return result
            else:
                # Provision returned None — read the actual error from the Job model
                _prov_err = getattr(model_job, "last_provision_error", "") or "unknown (check provider dashboard)"
                attempts.append({"provider": prov_name, "error": _prov_err})
                logger.warning(f"Provision {prov_name} returned None for {_gpu_key}: {_prov_err}")
        except Exception as e:
            attempts.append({"provider": prov_name, "error": str(e)[:200]})
            logger.error(f"Provision {prov_name} EXCEPTION: {e}", exc_info=True)

    # Stash attempts on the per-job dict so the caller can surface the
    # actual failure reason without racing against concurrent provisions.
    job["_provision_attempts"] = attempts
    # Also propagate the Pydantic Job's failure_code / detail (set by providers
    # via the Lifecycle Gate wire-ins) so the outer status-setting path can
    # write these alongside the free-form error string.
    _code = getattr(model_job, "failure_code", None)
    if _code:
        job["failure_code"] = _code
    _detail = getattr(model_job, "failure_detail", None)
    if _detail:
        job["failure_detail"] = _detail
    # Detect credential/config failures that adapters surface as None returns.
    # Without this, _handle_provision_result defaults to PROV_NO_CAPACITY and
    # retries indefinitely — a credential issue will never self-heal.
    if not job.get("failure_code"):
        _CRED_PHRASES = ("no credentials available", "creds incomplete")
        for _att in attempts:
            _err_lower = (_att.get("error") or "").lower()
            if any(p in _err_lower for p in _CRED_PHRASES):
                job["failure_code"] = "prov_auth_bad"
                logger.warning(
                    f"[provision] Credential failure detected for {_gpu_key} "
                    f"('{_att['error'][:80]}') — marking prov_auth_bad (non-retryable)"
                )
                break
    _worker_debug["last_provision_attempts"] = attempts
    logger.info(f"No capacity for {_gpu_key}: tried {len(attempts)} providers")

    return None


async def _check_alive(broker, job: dict) -> bool:
    """Check if the instance is still running.

    HTTP calls run in executor to avoid blocking the async event loop.
    """
    from shared.models import Provider

    provider_str = job.get("provider", "")
    instance_id = job.get("instance_id", "")
    if not instance_id or not provider_str:
        return True  # No instance yet — assume alive

    _PROV_MAP = {
        "vast_ai": Provider.VAST_AI,
        "runpod": Provider.RUNPOD,
        "lambda_labs": Provider.LAMBDA_LABS,
        "aws": Provider.AWS,
        "gcp": Provider.GCP,
        "azure": Provider.AZURE,
        "coreweave": Provider.COREWEAVE,
        "voltage_park": Provider.VOLTAGE_PARK,
        "crusoe": Provider.CRUSOE,
        "nebius": Provider.NEBIUS,
        "hyperstack": Provider.HYPERSTACK,
    }
    provider = _PROV_MAP.get(provider_str)
    if not provider:
        return True  # Unknown provider — assume alive

    # Get API key directly from broker config (server-side, no HTTP call needed)
    api_key = ""
    try:
        _prov_key = provider_str.lower().replace(" ", "_")
        _cfg = broker._get_provider_config(_prov_key)
        if _cfg:
            api_key = getattr(_cfg, "api_key", "")
    except Exception as e:
        logger.warning(f"[alive-check] Cannot get API key for {provider_str}: {e}")
    if not api_key:
        return True  # Can't check without API key — assume alive

    import httpx
    loop = asyncio.get_event_loop()

    def _do_alive_check() -> bool:
        """Synchronous alive check — runs in thread executor."""
        try:
            if provider == Provider.VAST_AI:
                resp = httpx.get(
                    f"https://console.vast.ai/api/v0/instances/{instance_id}/",
                    headers={"Authorization": f"Bearer {api_key}"},
                    timeout=10,
                )
                if resp.status_code == 404:
                    logger.info(f"[alive-check] Vast.ai {instance_id}: 404 (gone)")
                    return False
                if resp.status_code == 200:
                    data = resp.json()
                    if data.get("instances") is None:
                        logger.info(f"[alive-check] Vast.ai {instance_id}: instances=null (gone)")
                        return False
                    actual = data.get("actual_status", "")
                    cur = data.get("cur_state", "")
                    if actual in ("exited", "stopped", "destroyed"):
                        logger.info(f"[alive-check] Vast.ai {instance_id}: actual_status={actual}")
                        return False
                    if actual is None and cur not in ("running", "loading", "created"):
                        logger.info(f"[alive-check] Vast.ai {instance_id}: actual_status=None, cur_state={cur}")
                        return False
            elif provider == Provider.RUNPOD:
                resp = httpx.get(
                    f"https://rest.runpod.io/v1/pods/{instance_id}",
                    headers={"Authorization": f"Bearer {api_key}"},
                    timeout=10,
                )
                if resp.status_code == 404:
                    logger.info(f"[alive-check] RunPod {instance_id}: 404 (gone)")
                    return False
            elif provider == Provider.LAMBDA_LABS:
                # Lambda uses Basic auth: base64("api_key:")
                # Status enum: "booting" | "active" | "unhealthy" | "terminated" | "terminating" | "preempted"
                # Source: https://cloud.lambda.ai/api/v1/openapi.json
                import base64 as _b64
                _basic = _b64.b64encode(f"{api_key}:".encode()).decode()
                resp = httpx.get(
                    f"https://cloud.lambdalabs.com/api/v1/instances/{instance_id}",
                    headers={"Authorization": f"Basic {_basic}"},
                    timeout=10,
                )
                if resp.status_code == 404:
                    logger.info(f"[alive-check] Lambda {instance_id}: 404 (gone)")
                    return False
                if resp.status_code == 200:
                    data = resp.json()
                    status = data.get("data", {}).get("status", "")
                    if status in ("terminated", "terminating", "preempted", "unhealthy"):
                        logger.info(f"[alive-check] Lambda {instance_id}: status={status} (dead)")
                        return False
        except Exception as e:
            logger.warning(f"[alive-check] {provider_str} {instance_id} check failed: {e}")
        return True

    return await loop.run_in_executor(None, _do_alive_check)


async def _check_completion(job_id: str, job: dict = None) -> bool:
    """Check if training completed. Checks DB logs first, then provider logs.

    All DB/HTTP calls are run via run_in_executor to avoid blocking the async event loop.
    """
    loop = asyncio.get_event_loop()

    # Method 1: Check DB (container heartbeat posts here)
    # Match any exit code — both success (exit 0) and failure (exit 1) mean training is done
    try:
        def _db_check():
            db = get_db()
            return db.table("job_logs").select("line").eq(
                "job_id", job_id
            ).like("line", "%Training finished (exit%").limit(1).execute()

        result = await loop.run_in_executor(None, _db_check)
        if isinstance(getattr(result, "data", None), list) and result.data:
            return True
    except Exception as e:
        logger.debug(f"[completion] DB check failed for {job_id}: {e}")

    # Method 2: Check Vast.ai logs directly — fallback for when the
    # container's heartbeat auth is broken (log_line_count stays at 0).
    # When heartbeat is working, Method 1 (DB) already catches the sentinel,
    # and calling Vast.ai every cycle is wasteful (PUT + S3 GET + sleep).
    # Gate Method 2 behind "heartbeat is silent" to keep it a real fallback.
    if (
        job
        and job.get("provider") == "vast_ai"
        and job.get("instance_id")
        and job.get("log_line_count", 0) == 0
    ):
        try:
            import httpx
            _key = os.environ.get("VAST_AI_API_KEY", os.environ.get("VL_VAST_AI_API_KEY", ""))
            if _key:
                def _vast_log_check():
                    # Request a log snapshot; Vast.ai uploads to S3 and
                    # returns a result_url that becomes valid after a short
                    # delay. Poll the URL a few times instead of a fixed
                    # sleep so we return as soon as the object is ready.
                    # Source: https://docs.vast.ai/api-reference/instances/show-logs
                    resp = httpx.put(
                        f"https://console.vast.ai/api/v0/instances/request_logs/{job['instance_id']}",
                        headers={"Authorization": f"Bearer {_key}", "Content-Type": "application/json"},
                        json={"tail": "200"},
                        timeout=10,
                    )
                    if resp.status_code != 200:
                        return False
                    result_url = resp.json().get("result_url", "")
                    if not result_url:
                        return False
                    import time as _time
                    for _attempt in range(4):  # up to ~2s total with 500ms backoff
                        _time.sleep(0.5)
                        try:
                            log_resp = httpx.get(result_url, timeout=10)
                        except Exception:
                            continue
                        if log_resp.status_code == 200:
                            return "[VaultLayer] Training finished (exit" in log_resp.text
                        if log_resp.status_code == 404:
                            continue  # S3 object not yet uploaded
                        break  # other status — give up
                    return False

                found = await loop.run_in_executor(None, _vast_log_check)
                if found:
                    logger.info(f"[completion] Detected via Vast.ai logs for {job_id}")
                    return True
        except Exception as e:
            logger.debug(f"[completion] Vast.ai log check failed for {job_id}: {e}")

    # Method 3: Check R2 for _COMPLETED sentinel written by the container
    # startup script after exit 0. This catches the case where the final
    # /logs POST fails (network, auth) but the sentinel write succeeded —
    # without this, a successful job can be re-queued as lost.
    try:
        def _r2_sentinel_check():
            import boto3 as _b3
            _ep = os.environ.get("R2_ENDPOINT", "")
            _k = os.environ.get("R2_ACCESS_KEY_ID", "")
            _s = os.environ.get("R2_SECRET_ACCESS_KEY", "")
            _bkt = os.environ.get("R2_BUCKET", "vaultlayer-checkpoints")
            if not all([_ep, _k, _s]):
                return False
            s3 = _b3.client("s3", endpoint_url=_ep, aws_access_key_id=_k, aws_secret_access_key=_s)
            try:
                s3.head_object(Bucket=_bkt, Key=f"checkpoints/{job_id}/_COMPLETED")
                return True
            except Exception:
                return False
        found = await asyncio.get_event_loop().run_in_executor(None, _r2_sentinel_check)
        if found:
            logger.info(f"[completion] Detected via R2 _COMPLETED sentinel for {job_id}")
            return True
    except Exception as e:
        logger.debug(f"[completion] R2 sentinel check failed for {job_id}: {e}")

    # Method 4: Check job_events table for event_type=completed OR failed posted
    # by the container/VM final Python snippet. Both signal that training is
    # done and the instance can be terminated + billed. Previously only
    # 'completed' was checked — if the script exited non-zero and the final
    # /logs POST failed, the job kept billing until provider liveness expired.
    try:
        def _events_check():
            db = get_db()
            return db.table("job_events").select("event_type, message").eq(
                "job_id", job_id
            ).in_("event_type", ["completed", "failed"]).order(
                "created_at", desc=True
            ).limit(1).execute()
        result = await asyncio.get_event_loop().run_in_executor(None, _events_check)
        if isinstance(getattr(result, "data", None), list) and result.data:
            _evt = result.data[0]
            _evt_type = _evt.get("event_type", "")
            logger.info(
                f"[completion] Detected via job_events ({_evt_type}) for {job_id}"
            )
            # Store the event type on the job dict so _parse_training_exit_code
            # can use it as a fallback when the 'Training finished' log line is
            # missing (e.g. final /logs POST failed).
            if job is not None:
                job["_completion_event_type"] = _evt_type
                job["_completion_event_message"] = _evt.get("message", "")
            return True
    except Exception as e:
        logger.debug(f"[completion] job_events check failed for {job_id}: {e}")

    return False


def _reset_job_for_new_leg(job: dict) -> None:
    """Clear per-leg state on the job dict before migrating to a new leg.

    Issue #74 (P0): previously only `_spend_id` and `_run_id` were reset on
    failover, leaving `_provider_billed_usd` (and other per-leg state) stale.
    When the next leg's `settle_instance` ran, it re-used the prior leg's
    provider_billed_usd as the cost basis, producing the wrong
    user_charged_usd (see stress run 7b1e5737 — GCP leg charged $0.0616
    instead of $2.17). This helper consolidates all per-leg resets in one
    place so every migration site gets the same treatment.

    Fields intentionally preserved across the migration boundary:
      job_id, user_id, gpu_type, script_*, docker_image, failover,
      checkpoint_step, excluded_providers, environment, regions, etc.
    Fields reset here are the ones that describe a specific instance run,
    not the user's job intent.

    Also marks `_is_resume_leg=True` so the worker's exhaustion branch
    routes to status=cancelled+failure_reason=resume_no_capacity instead of
    the initial-submit failure behaviour. Callers that want the dispatcher
    to prefer the previous leg's provider on retry should set
    `_resume_prefer_provider` BEFORE calling this — it is preserved here.
    """
    # Spend + run row IDs — new leg gets fresh rows
    job["_spend_id"]             = None
    job["_run_id"]               = None
    # Per-leg billing state — MUST be cleared or settle_instance on the
    # next leg will use the prior leg's numbers
    job["_provider_billed_usd"]  = None
    job["_termination_confirmed"] = False
    # Timing & state carried by the previous leg
    job["started_at"]            = None
    job["completed_at"]          = None
    job["duration"]              = None
    job["instance_id"]           = None
    job["provider"]              = None
    job["price_per_hr"]          = None
    job["actual_gpu_type"]       = None
    # Don't leak the old leg's error message onto the new leg
    job["error"]                 = None
    job.pop("failure_code", None)
    job.pop("failure_detail", None)
    job.pop("failure_reason", None)
    # This re-queue is a resume leg — exhaustion should cancel+email rather
    # than retry forever or report 'failed'. Initial submits never set this.
    job["_is_resume_leg"]        = True


def _prepare_failover_requeue(job: dict, job_id: str, checkpoint_lookup=None) -> tuple[str | None, int | None]:
    """Prepare a failed leg for another provision attempt.

    If a checkpoint exists, the next leg is a true resume leg. If not, retry
    from the beginning and keep normal provisioning backoff behavior.
    """
    _dying_provider = job.get("provider")
    _lookup = checkpoint_lookup or _find_checkpoint
    _ckpt = _lookup(job_id)
    _ckpt_step = _ckpt["step"] if _ckpt else None
    if _dying_provider:
        job["_resume_prefer_provider"] = _dying_provider
    _reset_job_for_new_leg(job)
    if _ckpt_step is None:
        # No checkpoint means there is no in-progress state to preserve.
        # Retry as a fresh start so normal provision backoff/BFS applies
        # instead of terminal resume_no_capacity cancellation.
        job.pop("_is_resume_leg", None)
    job["status"] = "recovering"
    job["checkpoint_step"] = _ckpt_step
    job["migration_count"] = job.get("migration_count", 0) + 1
    job["queued_at"] = time.time()
    return _dying_provider, _ckpt_step


def _prepare_stuck_failover_requeue(job: dict, job_id: str, checkpoint_lookup=None) -> tuple[str | None, int | None]:
    """Backward-compatible wrapper for stuck/boot-failed legs."""
    return _prepare_failover_requeue(job, job_id, checkpoint_lookup=checkpoint_lookup)


async def _parse_training_exit_code(job_id: str) -> "int | None":
    """Return the exit code from the '[VaultLayer] Training finished (exit N)' log line.

    Returns None if the sentinel is missing (shouldn't happen after
    _check_completion returns True, but defensive). Returns the integer
    exit code otherwise. Used by the worker to route non-zero exits to
    status=failed rather than status=completed (issue #72).
    """
    loop = asyncio.get_event_loop()
    try:
        def _fetch():
            db = get_db()
            if db is None:
                return None
            # Latest "Training finished (exit N)" line for this job
            res = (
                db.table("job_logs")
                .select("line")
                .eq("job_id", job_id)
                .like("line", "%Training finished (exit%")
                .order("created_at", desc=True)
                .limit(1)
                .execute()
            )
            if not res.data:
                return None
            return res.data[0].get("line", "")

        line = await loop.run_in_executor(None, _fetch)
        if not line:
            return None
        # Format: "[VaultLayer] Training finished (exit 0)" or "(exit 1)"
        import re
        m = re.search(r"\(exit\s+(-?\d+)\)", line)
        if m:
            return int(m.group(1))
        return None
    except Exception as e:
        logger.debug(f"[exit-code] parse failed for {job_id}: {e}")
        return None


def _fetch_recent_log_text(job_id: str, limit: int = 200) -> str:
    """Return recent job log lines in chronological order."""
    try:
        db = get_db()
        if db is None:
            return ""
        res = (
            db.table("job_logs")
            .select("line")
            .eq("job_id", job_id)
            .order("created_at", desc=True)
            .limit(limit)
            .execute()
        )
        rows = list(reversed(getattr(res, "data", None) or []))
        return "\n".join(str(row.get("line", "")) for row in rows)
    except Exception as e:
        logger.debug(f"[logs] recent log fetch failed for {job_id}: {e}")
        return ""


def _classify_nonzero_exit(log_text: str, exit_code: int | None) -> tuple[str, str]:
    """Classify a non-zero training exit from logs.

    Dependency/import/script failures should stay terminal. CUDA OOM is a
    recoverable runtime sizing failure because the same script can succeed on a
    larger GPU or a clean high-VRAM node.
    """
    from shared.failure_codes import JobFailureCode

    text = log_text or ""
    lower = text.lower()
    if (
        "torch.cuda.outofmemoryerror" in lower
        or "cuda out of memory" in lower
        or "cublas_status_alloc_failed" in lower
        or ("out of memory" in lower and "cuda" in lower)
    ):
        return JobFailureCode.RUN_OOM.value, "CUDA out of memory"

    disk_full_markers = (
        "no space left on device",
        "os error 28",
        "errno 28",
        "not enough disk space",
        "not enough free disk space",
        "disk quota exceeded",
        "file reconstruction error",
    )
    if any(marker in lower for marker in disk_full_markers):
        return JobFailureCode.BOOT_DISK_FULL.value, "disk full while preparing training environment"

    dependency_markers = (
        "modulenotfounderror",
        "importerror",
        "no module named",
        "cannot import name",
        "command not found",
        "no such file or directory",
    )
    if exit_code == 127 or any(marker in lower for marker in dependency_markers):
        return JobFailureCode.BOOT_IMPORT_FAIL.value, "dependency or command import failure"

    return JobFailureCode.RUN_EXITED_NONZERO.value, f"user script exited with code {exit_code}"


def _find_runtime_oom_retry_gpu(
    job: dict,
    check_candidate=None,
) -> tuple[str | None, float]:
    """Find a larger GPU for a runtime OOM retry.

    The next leg must exceed both the model-derived floor and the current
    GPU's VRAM. That handles two cases:
      - the old estimator was too low for the model size;
      - the model generally fits the tier, but this provider node was too tight.
    """
    current_gpu = job.get("gpu_type") or job.get("actual_gpu_type") or ""
    current_vram = _shared_gpu_vram_gb(current_gpu, unknown=0.0)
    model_params = float(job.get("model_params_billion") or 0.0)
    training_mode = job.get("training_mode") or "qlora"
    derived_min = (
        _shared_min_vram_for_model(model_params, training_mode)
        if model_params > 0
        else 0.0
    )
    min_vram = max(
        float(job.get("min_vram_gb") or 0.0),
        derived_min,
        current_vram + 1.0,
    )
    tried = set(job.get("_bfs_tried_gpus") or set())
    if current_gpu:
        tried.add(current_gpu)

    candidate_check = check_candidate or (lambda gpu: _gpu_has_dispatchable_price(gpu, job))
    next_gpu = _shared_bfs_gpu_fallback(
        current_gpu,
        min_vram,
        check_candidate=lambda gpu: gpu not in tried and candidate_check(gpu),
    )
    return next_gpu, min_vram


def _prepare_runtime_oom_requeue(
    job: dict,
    job_id: str,
    next_gpu: str,
    min_vram_gb: float,
    checkpoint_lookup=None,
) -> tuple[str | None, int | None]:
    """Prepare an OOM leg for retry on a larger GPU."""
    old_gpu = job.get("gpu_type") or job.get("actual_gpu_type") or ""
    tried = set(job.get("_bfs_tried_gpus") or set())
    if old_gpu:
        tried.add(old_gpu)
    _dying_provider, _ckpt_step = _prepare_failover_requeue(
        job,
        job_id,
        checkpoint_lookup=checkpoint_lookup,
    )
    job["gpu_type"] = next_gpu
    job["min_vram_gb"] = float(min_vram_gb or 0.0)
    job["gpu_auto_selected"] = True
    job["_bfs_tried_gpus"] = tried
    job["error"] = f"Runtime CUDA OOM on {old_gpu}; retrying on {next_gpu}"
    return _dying_provider, _ckpt_step


def _next_disk_retry_gb(job: dict) -> int | None:
    current = int(job.get("disk_gb") or _shared_disk_gb_for_model(
        job.get("model_params_billion"), job.get("training_mode") or "qlora"
    ))
    retry_count = int(job.get("_disk_retry_count") or 0)
    if retry_count >= 2 or current >= 1000:
        return None
    target = min(1000, max(current + 100, int(math.ceil(current * 1.5 / 50.0) * 50)))
    return target if target > current else None


def _prepare_disk_full_requeue(
    job: dict,
    job_id: str,
    next_disk_gb: int,
    checkpoint_lookup=None,
) -> tuple[str | None, int | None]:
    _dying_provider, _ckpt_step = _prepare_failover_requeue(
        job,
        job_id,
        checkpoint_lookup=checkpoint_lookup,
    )
    old_disk = int(job.get("disk_gb") or 0)
    job["disk_gb"] = int(next_disk_gb)
    job["_disk_retry_count"] = int(job.get("_disk_retry_count") or 0) + 1
    job["error"] = f"Disk full on {old_disk or 'default'}GB; retrying with {next_disk_gb}GB"
    return _dying_provider, _ckpt_step


async def _terminate_and_settle(broker, job: dict):
    """Terminate instance and settle billing."""
    provider_str = job.get("provider", "")
    instance_id = job.get("instance_id", "")
    if not instance_id:
        return

    _FENCE_MAP = {
        "vast_ai": "_hard_fence_vast_ai",
        "runpod": "_hard_fence_runpod",
        "lambda_labs": "_hard_fence_lambda",
        "aws": "_hard_fence_aws",
        "gcp": "_hard_fence_gcp",
        "azure": "_hard_fence_azure",
        "coreweave": "_hard_fence_coreweave",
        "voltage_park": "_hard_fence_voltage_park",
        "crusoe": "_hard_fence_crusoe",
        "nebius": "_hard_fence_nebius",
        "hyperstack": "_hard_fence_hyperstack",
    }

    # Fence result is tracked so settle_instance only marks
    # termination_confirmed=True when the provider API actually
    # confirmed the instance is gone. Before this, any fence failure
    # (TypeError from signature mismatch, provider API error, network
    # blip) was caught and the DB still claimed the instance was
    # terminated — leading to ongoing provider billing on "completed"
    # jobs. See the AWS leak from job 5f27bb51 (2026-04-16).
    fence_success = False
    fence_name = _FENCE_MAP.get(provider_str)
    if fence_name:
        fence_fn = getattr(broker, fence_name, None)
        if fence_fn:
            # Providers AWS / GCP / Azure require a job argument for
            # per-job STS session labelling and region resolution; the
            # others take only instance_id. Try the 2-arg form first,
            # fall back to 1-arg. Worker state is a dict, not a Job
            # model — synthesise a minimal object for compatibility.
            from types import SimpleNamespace
            # Include placement metadata (zone/region) so provider fence can
            # target the correct location. GCP's hard_fence() reads job.zone
            # as the fallback when the in-process _gcp_sa_info cache is empty.
            _placement = job.get("_placement") or {}
            _job_shim = SimpleNamespace(
                job_id=job.get("job_id", ""),
                zone=_placement.get("zone"),
                region=_placement.get("region"),
            )
            try:
                try:
                    await fence_fn(instance_id, _job_shim)
                except TypeError:
                    await fence_fn(instance_id)
                fence_success = True
                logger.info(f"Terminated {provider_str} instance {instance_id}")
            except Exception as e:
                logger.error(
                    f"[fence] FAILED to terminate {provider_str} instance "
                    f"{instance_id}: {type(e).__name__}: {e}. "
                    f"termination_confirmed will remain false; instance may still be billing."
                )

    # Verify instance is actually gone (fire-and-forget DELETE may not work).
    # _verify_instance_destroyed handles its own errors; if it succeeds at
    # re-deleting a zombie, we keep fence_success as-is (the DB row's
    # termination_confirmed reflects whether the FIRST fence worked).
    await _verify_instance_destroyed(broker, provider_str, instance_id)

    # Record the fence outcome on the job dict so _close_job can pass it
    # to settle_instance.
    job["_termination_confirmed"] = fence_success

    # Fetch actual billing from provider (store in job for settle_instance)
    actual_cost = await _fetch_provider_billing(broker, provider_str, instance_id)
    if actual_cost is not None:
        job["_provider_billed_usd"] = actual_cost


async def _fetch_provider_billing(broker, provider_str: str, instance_id: str) -> Optional[float]:
    """Query the provider's billing API for actual cost of an instance. Returns USD or None.

    Provider billing API coverage:
      RunPod      — GET /v1/billing/pods?podId=X -> per-pod cost (real-time)
      Hyperstack  — GET /billing/history/virtual-machine/{vm_id} -> per-VM cost (real-time)
      Crusoe      — GET /billing/export?resource_id=X -> per-instance (real-time)
      Voltage Park— GET /billing/transactions?types=virtual_machine -> filter by time
      Vast.ai     — GET /api/v1/invoices/ -> account-level (no per-instance filter)
      AWS         — GetCostAndUsageWithResources -> 24-48h delay
      Azure       — GET /usageDetails?$filter=resourceId -> 24-72h delay
      GCP         — BigQuery export only (requires setup)
      Lambda Labs — No billing API
      CoreWeave   — No billing API
      Nebius      — gRPC batch export only
    """
    _SUPPORTED = ("runpod", "vast_ai", "hyperstack", "crusoe", "voltage_park")
    if not instance_id or provider_str not in _SUPPORTED:
        return None

    import httpx
    loop = asyncio.get_event_loop()

    def _query():
        try:
            _cfg = broker._get_provider_config(provider_str)
            if not _cfg:
                return None
            api_key = getattr(_cfg, "api_key", "")
            if not api_key:
                return None

            if provider_str == "runpod":
                resp = httpx.get(
                    "https://rest.runpod.io/v1/billing/pods",
                    headers={"Authorization": f"Bearer {api_key}"},
                    params={"podId": instance_id, "bucketSize": "hour"},
                    timeout=15,
                )
                if resp.status_code == 200:
                    # Response is a top-level JSON array of BillingRecord
                    # objects ({amount, diskSpaceBilledGb, endpointId,
                    # gpuTypeId, podId, time, timeBilledMs}). An earlier
                    # implementation read data["billingItems"] which is
                    # not a documented key — every row silently returned
                    # 0 and provider_billed_usd was written null.
                    # Source: https://docs.runpod.io/api-reference/billing/GET/billing/pods
                    data = resp.json()
                    if isinstance(data, list):
                        items = data
                    elif isinstance(data, dict):
                        # Defensive: tolerate an undocumented wrapper in
                        # case the API adds one later.
                        items = data.get("billingItems") or data.get("data") or []
                    else:
                        items = []
                    total = sum(float(item.get("amount") or 0) for item in items)
                    if total > 0:
                        logger.info(
                            f"[billing] RunPod {instance_id}: actual=${total:.4f} "
                            f"({len(items)} billing records)"
                        )
                        return total
                    logger.info(
                        f"[billing] RunPod {instance_id}: no billing records yet "
                        f"(charges settle within minutes; backfill later if needed)"
                    )
                    return None

            elif provider_str == "hyperstack":
                # Per-VM billing history
                resp = httpx.get(
                    f"https://infrahub-api.nexgencloud.com/v1/billing/billing/history/virtual-machine/{instance_id}",
                    headers={"api_key": api_key},
                    timeout=15,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    # Sum all billing events for this VM
                    total = float(data.get("total_cost", 0) or 0)
                    if not total:
                        events = data.get("billing_events", []) or data.get("data", []) or []
                        total = sum(float(e.get("cost", 0) or 0) for e in events)
                    logger.info(f"[billing] Hyperstack {instance_id}: actual=${total:.4f}")
                    return total if total > 0 else None

            elif provider_str == "crusoe":
                # Crusoe billing export with resource filter
                # Auth: HMAC-SHA256 signed token (same as fence)
                _project = getattr(_cfg, "project_id", "")
                _org = getattr(_cfg, "organization_id", "")
                if not _org:
                    return None
                resp = httpx.get(
                    f"https://api.crusoecloud.com/v1alpha5/organizations/{_org}/billing/export",
                    headers={"Authorization": f"Bearer {api_key}"},
                    params={"resource_id": instance_id},
                    timeout=15,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    items = data.get("items", []) or data.get("data", []) or []
                    total = sum(float(i.get("total_price", 0) or 0) for i in items)
                    logger.info(f"[billing] Crusoe {instance_id}: actual=${total:.4f}")
                    return total if total > 0 else None

            elif provider_str == "voltage_park":
                # Transaction history filtered by time (no per-instance filter)
                resp = httpx.get(
                    "https://cloud-api.voltagepark.com/api/v1/billing/transactions",
                    headers={"Authorization": f"Bearer {api_key}"},
                    params={"types": "virtual_machine", "limit": 10},
                    timeout=15,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    # Look for transactions matching our instance in description
                    txns = data.get("transactions", []) or data.get("data", []) or []
                    for txn in txns:
                        desc = str(txn.get("description", ""))
                        if instance_id in desc:
                            amount = abs(float(txn.get("amount", 0) or 0))
                            logger.info(f"[billing] Voltage Park {instance_id}: actual=${amount:.4f}")
                            return amount
                    logger.debug(f"[billing] Voltage Park: no matching transaction for {instance_id}")

            elif provider_str == "vast_ai":
                # Per-instance charges from Vast.ai billing API.
                # Source: https://docs.vast.ai/api-reference/billing/show-charges
                # GET /api/v0/charges/ returns rows tagged source="instance-<id>"
                # with `amount` in USD (GPU + disk + bwd + bwu combined).
                # Charges are eventually consistent; if queried right after
                # fence, the row may not have settled yet and we return None
                # (caller keeps provider_billed_usd null). A backfill path
                # can reconcile these later.
                import json as _json
                from datetime import datetime, timedelta, timezone
                _now = datetime.now(timezone.utc)
                # 48h window catches both same-day + next-day settlement.
                _start = _now - timedelta(days=2)
                _filters = {"day": {"gte": int(_start.timestamp()), "lte": int(_now.timestamp())}}
                _source_tag = f"instance-{instance_id}"
                total = 0.0
                matched = 0
                resp = httpx.get(
                    "https://console.vast.ai/api/v0/charges/",
                    headers={"Authorization": f"Bearer {api_key}"},
                    params={"select_filters": _json.dumps(_filters), "limit": "500"},
                    timeout=15,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    for row in (data.get("results") or []):
                        if str(row.get("source", "")) == _source_tag:
                            total += float(row.get("amount") or 0)
                            matched += 1
                if matched > 0 and total > 0:
                    logger.info(
                        f"[billing] Vast.ai {instance_id}: actual=${total:.4f} "
                        f"({matched} charge rows)"
                    )
                    return total
                logger.info(
                    f"[billing] Vast.ai {instance_id}: no charges in /charges/ yet "
                    f"(eventual consistency). provider_billed_usd stays null; "
                    f"backfill later via scripts/reconcile_vast_charges.py"
                )
                return None

        except Exception as e:
            logger.warning(f"[billing] {provider_str} billing query failed for {instance_id}: {e}")
        return None

    return await loop.run_in_executor(None, _query)


async def _verify_instance_destroyed(broker, provider_str: str, instance_id: str):
    """Verify the instance is actually gone after DELETE. Retry if still alive."""
    if not instance_id or provider_str not in ("vast_ai", "runpod"):
        return  # Only verify providers with fire-and-forget DELETE

    import httpx
    loop = asyncio.get_event_loop()

    def _check():
        try:
            if provider_str == "vast_ai":
                _cfg = broker._get_provider_config("vast_ai")
                if not _cfg:
                    return
                resp = httpx.get(
                    f"https://console.vast.ai/api/v0/instances/{instance_id}/",
                    headers={"Authorization": f"Bearer {_cfg.api_key}"},
                    timeout=10,
                )
                if resp.status_code == 404:
                    logger.info(f"[verify] Vast.ai {instance_id}: confirmed destroyed (404)")
                    return
                if resp.status_code == 200:
                    data = resp.json()
                    status = data.get("actual_status", "unknown")
                    if status in ("exited", "destroyed", None):
                        logger.info(f"[verify] Vast.ai {instance_id}: status={status} (destroyed)")
                    else:
                        logger.error(f"[verify] Vast.ai {instance_id}: STILL ALIVE (status={status})! Retrying DELETE...")
                        httpx.delete(
                            f"https://console.vast.ai/api/v0/instances/{instance_id}/",
                            headers={"Authorization": f"Bearer {_cfg.api_key}"},
                            timeout=10,
                        )
            elif provider_str == "runpod":
                _cfg = broker._get_provider_config("runpod")
                if not _cfg:
                    return
                resp = httpx.get(
                    f"https://rest.runpod.io/v1/pods/{instance_id}",
                    headers={"Authorization": f"Bearer {_cfg.api_key}"},
                    timeout=10,
                )
                if resp.status_code == 404:
                    logger.info(f"[verify] RunPod {instance_id}: confirmed destroyed (404)")
                elif resp.status_code == 200:
                    logger.error(f"[verify] RunPod {instance_id}: STILL ALIVE! Retrying DELETE...")
                    httpx.delete(
                        f"https://rest.runpod.io/v1/pods/{instance_id}",
                        headers={"Authorization": f"Bearer {_cfg.api_key}"},
                        timeout=10,
                    )
        except Exception as e:
            logger.warning(f"[verify] {provider_str} {instance_id}: verification failed: {e}")

    # Run verification in background after a brief delay
    await asyncio.sleep(3)
    await loop.run_in_executor(None, _check)


def _fetch_vast_log_marker(instance_id: str, vast_key: str) -> Optional[str]:
    """Sync helper: fetch a content-progress marker for a Vast.ai instance log.

    Uses PUT /api/v0/instances/request_logs/{id} → result_url → GET log content.

    Returns a string marker combining byte length + MD5 of the tail content, or
    None on any failure. The marker changes whenever the tail content changes,
    which covers both log growth AND rolling-window replacement (>200 lines):
      - Growing log: content is different each fetch → marker changes
      - Rolling tail: old lines pushed out, new lines appear → content differs → marker changes
      - Truly stuck: same tail content every fetch → marker stays identical

    Tracking content change rather than byte length alone avoids the Codex-identified
    bug where a job with >200 log lines has a stable tail byte count despite training.

    Source: https://docs.vast.ai/api-reference/instances/logs
    """
    import hashlib as _hl
    import httpx as _httpx
    import time as _t

    try:
        resp = _httpx.put(
            f"https://console.vast.ai/api/v0/instances/request_logs/{instance_id}",
            headers={"Authorization": f"Bearer {vast_key}", "Content-Type": "application/json"},
            json={"tail": "200"},
            timeout=10,
        )
        if resp.status_code != 200:
            return None
        result_url = resp.json().get("result_url", "")
        if not result_url:
            return None
        for _ in range(4):
            _t.sleep(0.5)
            try:
                log_resp = _httpx.get(result_url, timeout=10)
                if log_resp.status_code == 200:
                    text = log_resp.text
                    digest = _hl.md5(text.encode(errors="replace")).hexdigest()
                    return f"{len(text)}:{digest}"
            except Exception:
                continue
    except Exception:
        pass
    return None


async def _vast_check_log_progress(job: dict, instance_id: str, _fetch_fn=None) -> bool:
    """Check if a Vast.ai instance is making log progress between stuck-check cycles.

    Returns True to skip kill (active or first snapshot), False to proceed with kill.

    Two-cycle approach: on the first stuck-check, snapshot the log content marker
    and defer the kill by one cycle. On the next check:
      - marker changed → content is different → instance is actively training → skip kill
      - marker unchanged → same tail content → truly stuck → proceed with kill

    Tracks content hash rather than byte length alone to handle rolling-tail windows
    (jobs with >200 log lines): a tail window with the same byte count but different
    content still signals progress. Stale identical content always falls through to kill.

    ``_fetch_fn``: optional sync callable() → Optional[str] injected for unit tests.
    Default uses the real Vast.ai API (requires VAST_AI_API_KEY env var).
    """
    vast_key = os.environ.get("VAST_AI_API_KEY", os.environ.get("VL_VAST_AI_API_KEY", ""))
    if not vast_key and _fetch_fn is None:
        return False  # No key and no override → fall through to existing kill path

    try:
        fn = _fetch_fn if _fetch_fn is not None else (lambda: _fetch_vast_log_marker(instance_id, vast_key))
        current_marker = await asyncio.get_running_loop().run_in_executor(None, fn)

        if current_marker is None:
            return False  # API failure → fall through to kill

        prior_marker = job.get("_vast_log_marker")

        if prior_marker is None:
            # First stuck check: snapshot marker, defer kill by one cycle.
            job["_vast_log_marker"] = current_marker
            logger.info(
                f"[stuck] {job.get('job_id', '?')[:8]} first stuck-check: "
                f"snapshotted log marker — deferring kill by one cycle."
            )
            return True

        if current_marker != prior_marker:
            # Content changed → instance is actively producing logs.
            job["_vast_log_marker"] = current_marker
            logger.info(
                f"[stuck] {job.get('job_id', '?')[:8]} log content changed "
                f"(marker updated) — instance active, skip kill."
            )
            return True

        # Marker identical since last stuck-check → no new output → truly stuck.
        logger.warning(
            f"[stuck] {job.get('job_id', '?')[:8]} log content UNCHANGED "
            f"since last check — confirmed stuck, proceeding to kill."
        )
        return False

    except Exception as e:
        logger.debug(f"[stuck] Vast.ai log progress probe error: {e}")
        return False


def _find_checkpoint(job_id: str) -> Optional[dict]:
    """Check R2 for latest checkpoint.

    Two formats recognized:
      * **HF `checkpoint-<N>/`** (canonical, per docs/job_contract.md §3).
        R2 keys look like `checkpoints/{job_id}/checkpoint-50/model.safetensors`.
        This is what HF Trainer + SFTTrainer write via `save_steps=N`.
      * `ckpt_step_<N>.pt` (legacy flat-file format from the pre-2026-04-21
        custom checkpoint helper; removed from startup_scripts.py in ae69987
        but may still exist in R2 for in-flight legacy jobs). Left here so a
        mid-migration job that checkpointed with the old helper still resumes.

    Bug fixed 2026-04-21: this function used to only recognize the legacy
    `ckpt_step_` format, so every failover on a post-refactor job returned
    None → job marked `Instance lost, no checkpoint found` even when the
    HF checkpoint existed in R2. Caught via demo_resume.py run on job
    `909c4358` — training was at step ~100 with checkpoint-50 written, but
    the broker's resume path couldn't see it.
    """
    try:
        import boto3
        endpoint = os.environ.get("R2_ENDPOINT", "")
        key = os.environ.get("R2_ACCESS_KEY_ID", "")
        secret = os.environ.get("R2_SECRET_ACCESS_KEY", "")
        bucket = os.environ.get("R2_BUCKET", "vaultlayer-checkpoints")
        if not all([endpoint, key, secret]):
            return None
        s3 = boto3.client(
            "s3", endpoint_url=endpoint,
            aws_access_key_id=key, aws_secret_access_key=secret,
        )
        ckpt_steps: set[int] = set()
        total_size = 0
        prefix = f"checkpoints/{job_id}/"
        # Paginate: FSDP/DeepSpeed checkpoints write hundreds of shard files per
        # step-dir, easily exceeding 1000 objects. Without pagination the worker
        # only sees the first page and may return a stale (lower) step number.
        kwargs: dict = {"Bucket": bucket, "Prefix": prefix, "MaxKeys": 1000}
        while True:
            resp = s3.list_objects_v2(**kwargs)
            for obj in resp.get("Contents", []):
                k = obj["Key"]
                rest = k[len(prefix):] if k.startswith(prefix) else k
                # HF canonical: `checkpoint-<N>/<file>`
                if rest.startswith("checkpoint-"):
                    try:
                        seg = rest.split("/", 1)[0]  # e.g. "checkpoint-50"
                        step = int(seg.split("-", 1)[1])
                        ckpt_steps.add(step)
                        total_size += obj["Size"]
                        continue
                    except (ValueError, IndexError):
                        pass
                # Raw PyTorch (vaultlayer_checkpoint.py): `step-<N>/checkpoint.pt`
                # vaultlayer init generates vaultlayer_checkpoint.py which writes
                # this format. Server-side failover must recognise it or else
                # checkpoint_step stays None and resume starts from step 0.
                if rest.startswith("step-"):
                    try:
                        seg = rest.split("/", 1)[0]  # e.g. "step-500"
                        step = int(seg.split("-", 1)[1])
                        ckpt_steps.add(step)
                        total_size += obj["Size"]
                        continue
                    except (ValueError, IndexError):
                        pass
                # Legacy flat-file: `ckpt_step_<N>.pt`
                if "ckpt_step_" in rest:
                    try:
                        step = int(rest.split("ckpt_step_")[1].split(".")[0])
                        ckpt_steps.add(step)
                        total_size += obj["Size"]
                    except Exception:
                        pass
            if not resp.get("IsTruncated"):
                break
            kwargs["ContinuationToken"] = resp["NextContinuationToken"]
        if ckpt_steps:
            max_step = max(ckpt_steps)
            return {"step": max_step, "size_bytes": total_size}
    except Exception:
        pass
    return None


def _get_log_count(job_id: str) -> int:
    """Get number of log lines for a job from DB."""
    try:
        db = get_db()
        result = db.table("job_logs").select("line", count="exact").eq(
            "job_id", job_id
        ).execute()
        return result.count or 0
    except Exception:
        return 0


def _deduct_credits(job: dict):
    """Deduct credits for a completed job when spend_id is missing.

    Used as fallback by _settle_in_db() when _spend_id was never recorded
    (e.g., DB was down at provision time). Idempotent: uses a deterministic
    stripe_payment_id key so double-invocation is a no-op.
    """
    try:
        duration_s = (job.get("completed_at", 0) or time.time()) - (job.get("started_at", 0) or time.time())
        rate = job.get("price_per_hr", 0) or 0
        margin = float(job.get("vl_margin_pct") or os.environ.get("VL_MARGIN_PCT", "0.40"))
        user_id = job.get("user_id", "")
        db = None
        if user_id:
            try:
                db = get_db()
                if db:
                    _ur = _db_call(
                        lambda: db.table("users")
                            .select("billing_model, compute_markup_pct")
                            .eq("user_id", user_id)
                            .execute(),
                        label="deduct_credits:fetch_user_billing",
                    )
                    if _ur.data and _ur.data[0].get("billing_model") == "cost_plus":
                        margin = float(_ur.data[0].get("compute_markup_pct") or margin)
            except Exception:
                pass
        cost_usd = (duration_s / 3600) * rate * (1.0 + margin)
        # math.ceil(round(..., 4)) avoids int() truncation on IEEE 754 fractions
        # e.g. 2.0 * 1.15 * 100 = 229.99... → int=229, but ceil(round)=230
        credits = math.ceil(round(cost_usd * 100, 4))
        if credits <= 0:
            return
        if db is None:
            db = get_db()
        _fallback_key = f"fallback:{job['job_id']}"
        # Idempotency: skip if a fallback event already exists for this job
        _existing = _db_call(
            lambda: db.table("credit_events")
                .select("id")
                .eq("stripe_payment_id", _fallback_key)
                .limit(1)
                .execute(),
            label="deduct_credits:idempotency_check",
        )
        if _existing and _existing.data:
            logger.info(
                f"[credits] Fallback event already exists for job {job['job_id'][:8]} — skipping duplicate deduction"
            )
            return
        _db_call(
            lambda: db.table("credit_events").insert({
                "user_id":           user_id,
                "event_type":        "burned",
                "amount_credits":    -credits,
                "job_id":            job["job_id"],
                "stripe_payment_id": _fallback_key,
                "description": (
                    f"Job {job['job_id'][:8]}: {job.get('provider', '')} "
                    f"{job.get('actual_gpu_type', '')} {duration_s:.0f}s "
                    f"@ ${rate}/hr margin={margin*100:.0f}% [spend_id_fallback]"
                ),
            }).execute(),
            label="job_routes:deduct_credits",
        )
        logger.info(f"[credits] Fallback: charged {credits} credits for job {job['job_id'][:8]}")
    except Exception as e:
        logger.error(f"[credits] Deduction failed for {job['job_id']}: {e}")


def _release_submit_reservation(job: dict, status: str) -> None:
    """Release the submit-time credit reservation when a managed job is terminal."""
    if status not in {"completed", "failed", "cancelled", "terminated", "termination_failed"}:
        return
    job_id = job.get("job_id")
    user_id = job.get("user_id")
    if not job_id or not user_id:
        return
    try:
        db = get_db()
        _reserved = _db_call(
            lambda: db.table("credit_events")
                .select("amount_credits")
                .eq("stripe_payment_id", f"submit:{job_id}")
                .limit(1)
                .execute(),
            label="settle:lookup_submit_reservation",
        )
        reserved_credits = (
            abs(int(_reserved.data[0]["amount_credits"]))
            if _reserved and _reserved.data else 0
        )
        if reserved_credits <= 0:
            return

        _existing_release = _db_call(
            lambda: db.table("credit_events")
                .select("id")
                .in_("stripe_payment_id", [
                    f"settle:{job_id}",
                    f"submit_cancel_refund:{job_id}",
                ])
                .limit(1)
                .execute(),
            label="settle:reservation_release_idempotency",
        )
        if _existing_release and _existing_release.data:
            logger.info(
                "[credits] Submit reservation already released for job %s",
                job_id[:8],
            )
            return

        from api.db import add_credit_event
        add_credit_event(
            user_id=user_id,
            event_type="released",
            amount_credits=reserved_credits,
            job_id=job_id,
            stripe_payment_id=f"settle:{job_id}",
            description=(
                f"Released submit-time reservation of {reserved_credits} "
                f"credits on managed job {status}"
            ),
        )
        logger.info(
            "[credits] Released submit reservation for job %s: %d credits",
            job_id[:8], reserved_credits,
        )
    except Exception as e:
        if "unique" in str(e).lower() or "duplicate" in str(e).lower():
            logger.info("[credits] Reservation release already exists for job %s", job_id[:8])
            return
        logger.warning("[credits] Submit reservation release failed for job %s: %s", job_id, e)


def _sync_job_status(run_id: str, status: str, **extra_fields):
    """Update job_runs row with new status. Non-fatal."""
    if not run_id:
        return
    try:
        from shared.job_run_logger import update_run
        update_run(run_id, status=status, **extra_fields)
    except Exception as e:
        logger.warning(f"[sync] update_run failed for {run_id}: {e}")


def _queue_state_for_job(job: dict) -> dict:
    """Return the durable submission/retry state for a job."""
    return {
        "user_id":                    job.get("user_id", ""),
        "gpu_type":                   job.get("gpu_type", ""),
        "script_b64":                 job.get("script_b64", ""),
        "script_name":                job.get("script_name", ""),
        "script_args":                job.get("script_args", ""),
        "environment":                job.get("environment") or {},
        "docker_image":               job.get("docker_image", ""),
        "failover":                   job.get("failover", True),
        "preferred_providers":        job.get("preferred_providers") or [],
        "excluded_providers":         job.get("excluded_providers") or [],
        "regions":                    job.get("regions") or [],
        "excluded_regions":           job.get("excluded_regions") or [],
        "resume_from_job_id":         job.get("resume_from_job_id"),
        "min_vram_gb":                float(job.get("min_vram_gb") or 0),
        "disk_gb":                    int(job.get("disk_gb") or 100),
        "gpu_auto_selected":          bool(job.get("gpu_auto_selected")),
        "model_params_billion":       job.get("model_params_billion"),
        "training_mode":              job.get("training_mode") or "qlora",
        "dataset_id":                 job.get("dataset_id") or "",
        "dataset_r2_prefix":          job.get("dataset_r2_prefix") or "",
        "checkpoint_step":            job.get("checkpoint_step"),
        "migration_count":            job.get("migration_count", 0),
        "_is_resume_leg":             bool(job.get("_is_resume_leg", False)),
        "_resume_prefer_provider":    job.get("_resume_prefer_provider"),
        "queued_at":                  job.get("queued_at") or time.time(),
        "_provision_retry_count":     job.get("_provision_retry_count", 0),
        "_next_retry_at":             job.get("_next_retry_at"),
        "_first_provision_failure_at": job.get("_first_provision_failure_at"),
        "_disk_retry_count":          int(job.get("_disk_retry_count") or 0),
    }


def _sync_queue_state(run_id: str, job: dict) -> None:
    """Persist the full queue_state (submission + backoff counters) to DB.

    Called after each backoff cycle so the startup recovery path can restore
    _provision_retry_count, _next_retry_at, and _first_provision_failure_at
    without losing the accumulated backoff budget across deploys.
    """
    if not run_id:
        return
    qs = _queue_state_for_job(job)
    try:
        from shared.job_run_logger import update_run
        update_run(run_id, queue_state=qs)
    except Exception as e:
        logger.warning(f"[sync] _sync_queue_state failed for {run_id}: {e}")


def _open_requeue_run(job: dict) -> None:
    """Persist a re-queued failover leg so API restarts do not lose it."""
    if job.get("_run_id"):
        _sync_queue_state(job.get("_run_id"), job)
        _sync_job_status(job.get("_run_id"), "queued")
        return
    try:
        from datetime import datetime, timezone
        from shared.job_run_logger import open_run
        run_id = open_run(
            job_id=job.get("job_id", ""),
            provider=job.get("_resume_prefer_provider") or "",
            gpu_type=job.get("gpu_type", ""),
            instance_id="",
            provisioned_at=datetime.now(timezone.utc),
            rate_per_hr=0,
            run_type="real",
            account_id=job.get("user_id", ""),
            job_name=f"job-{str(job.get('job_id', ''))[:8]}",
            docker_image=job.get("docker_image") or "",
            initial_status="queued",
            queue_state=_queue_state_for_job(job),
        )
        if run_id:
            job["_run_id"] = run_id
            logger.info(f"[run] Opened requeue job_run for {job.get('job_id', '')[:8]} run_id={run_id}")
    except Exception as e:
        logger.warning(f"[run] requeue job_run write failed (non-fatal): {e}")


def _record_provision_to_db(job: dict):
    """Write to spend_ledger + job_runs so dashboard sees provisioned jobs."""
    try:
        from shared.spend import record_provision
        from datetime import datetime, timezone
        spend_id = record_provision(
            job_id=job["job_id"],
            provider=job.get("provider", ""),
            gpu_type=job.get("actual_gpu_type", job.get("gpu_type", "")),
            instance_id=job.get("instance_id", ""),
            provisioned_at=datetime.fromtimestamp(job.get("started_at", time.time()), tz=timezone.utc),
            rate_per_hr=job.get("price_per_hr", 0) or 0,
            user_id=job.get("user_id", ""),
        )
        if spend_id:
            job["_spend_id"] = spend_id
            logger.info(f"[spend] Recorded provision for {job['job_id'][:8]} spend_id={spend_id}")
    except Exception as e:
        logger.warning(f"[spend] record_provision failed (non-fatal): {e}")

    # job_runs row lifecycle — now routes through the shared helper in
    # shared/job_run_logger.record_provision(). Same code path used by the
    # local smoke script (scripts/aws_smoke_local.py), enforcing the
    # "every real provision → one DB row" invariant everywhere.
    try:
        from datetime import datetime, timezone
        from shared.job_run_logger import record_provision
        _prov_at = datetime.fromtimestamp(job.get("started_at", time.time()), tz=timezone.utc)
        run_id = record_provision(
            job_id=job["job_id"],
            provider=job.get("provider", ""),
            gpu_type=job.get("actual_gpu_type", job.get("gpu_type", "")),
            instance_id=job.get("instance_id", ""),
            provisioned_at=_prov_at,
            rate_per_hr=job.get("price_per_hr", 0) or 0,
            account_id=job.get("user_id", ""),
            job_name=f"job-{job['job_id'][:8]}",
            run_type="real",
            docker_image=job.get("docker_image") or "",
            existing_run_id=job.get("_run_id"),
            spend_ledger_id=job.get("_spend_id"),
            metadata=({"placement": job["_placement"]} if job.get("_placement") else None),
        )
        if run_id and not job.get("_run_id"):
            job["_run_id"] = run_id
            logger.info(f"[run] Opened job_run for {job['job_id'][:8]} run_id={run_id}")
        elif run_id:
            logger.info(f"[run] Updated job_run {run_id} -> running")
    except Exception as e:
        logger.warning(f"[run] job_run write failed (non-fatal): {e}")


def _settle_in_db(job: dict, status: str = "completed"):
    """Close the spend_ledger + job_runs rows. Called on completion, failure, or cancellation.

    Note on status values:
      - job_runs.status has a CHECK constraint allowing only
        ('provisioning','running','completed','failed','terminated','termination_failed').
      - For semantic statuses like 'migrated' or 'stuck_requeue', we map to 'terminated'
        and store the original intent in failure_reason so dashboards can distinguish
        legs closed due to failover from legs closed due to completion or errors.
    """
    end_time = job.get("completed_at") or time.time()
    start_time = job.get("started_at") or end_time
    duration_s = max(0, end_time - start_time)

    # Settle spend_ledger first and capture the canonical billing values.
    # close_run() then mirrors those exact numbers into job_runs so the two
    # tables cannot drift. Previously job_runs applied a hardcoded 20%
    # markup independent of the tier (Standard 20% / Scarcity 30% /
    # Failover 40%) actually recorded on spend_ledger — Failover jobs
    # showed different user_charged_usd in each table, and reconciliation
    # relied on a periodic sync script.
    settled: Optional[dict] = None
    spend_id = job.get("_spend_id")
    if spend_id:
        try:
            from shared.spend import settle_instance
            from datetime import datetime, timezone
            _prov_billed = job.get("_provider_billed_usd")
            _term_confirmed = job.get("_termination_confirmed", False)
            settled = settle_instance(
                spend_id,
                datetime.fromtimestamp(end_time, tz=timezone.utc),
                provider_billed_usd=_prov_billed,
                termination_confirmed=_term_confirmed,
            )
            logger.info(
                f"[spend] Settled {job['job_id'][:8]} spend_id={spend_id} "
                f"status={status} provider_billed={_prov_billed} "
                f"termination_confirmed={_term_confirmed} "
                f"user_charged=${(settled or {}).get('user_charged_usd', 0):.4f} "
                f"margin={(settled or {}).get('vl_margin_pct', 0) * 100:.0f}%"
            )
        except Exception as e:
            logger.warning(f"[spend] settle_instance failed (non-fatal): {e}")
    else:
        _deduct_credits(job)

    _release_submit_reservation(job, status)

    # Map non-canonical statuses to the allowed set + failure_reason
    _VALID_STATUSES = {"provisioning", "running", "completed", "failed", "terminated", "termination_failed"}
    _db_status = status
    _failure_reason = None
    if status not in _VALID_STATUSES:
        _db_status = "terminated"
        _failure_reason = status  # e.g. "migrated", "stuck_requeue"

    run_id = job.get("_run_id")
    if run_id:
        try:
            from shared.job_run_logger import record_termination
            from datetime import datetime, timezone
            # Same shared helper used by scripts/aws_smoke_local.py — keeps
            # the close_run pattern in one place. When `settled` is provided
            # from spend_ledger, record_termination uses those canonical
            # billing values (no drift between spend_ledger and job_runs).
            record_termination(
                run_id=run_id,
                provider=job.get("provider", ""),
                provisioned_at=datetime.fromtimestamp(
                    job.get("started_at") or end_time, tz=timezone.utc
                ),
                terminated_at=datetime.fromtimestamp(end_time, tz=timezone.utc),
                rate_per_hr=job.get("price_per_hr", 0) or 0,
                status=_db_status,
                termination_confirmed=bool(job.get("_termination_confirmed", False)),
                fallback_reason=job.__dict__.get("fallback_reason") if hasattr(job, "__dict__") else job.get("fallback_reason") if isinstance(job, dict) else None,
                provider_billed_usd=job.get("_provider_billed_usd"),
                failure_reason=_failure_reason,
                settled=settled,
            )
            logger.info(f"[run] Closed job_run for {job['job_id'][:8]} run_id={run_id} status={status} (db_status={_db_status})")
        except Exception as e:
            logger.warning(f"[run] close_run failed (non-fatal): {e}")


# ── Provision-result branch helper (extracted for testability) ───────────────

def _handle_provision_result(
    *, job: dict, job_id: str, instance_id: "Optional[str]", pref_label: str,
) -> str:
    """Apply the side effects of a provisioning attempt's result.

    Returns one of:
      "running"          — instance came up; caller should mark for queue removal.
      "cancelled_resume" — resume leg exhausted; cancel + email fired; remove.
      "failed"           — preferred providers all failed; remove from queue.
      "requeue"          — no constraint and nothing came up; leave on queue.

    Pulled out of `_job_worker()` so the resume-exhaustion branch can be
    exercised under unit-test mocks without spinning up the whole async loop.
    Behaviour is byte-for-byte identical to the inline version that shipped
    earlier in this file's history; if you tweak this, mirror the change in
    test_constraint_satisfaction.py.
    """
    if instance_id:
        job["status"] = "running"
        job["instance_id"] = instance_id
        job["started_at"] = time.time()
        _record_provision_to_db(job)
        # Resume succeeded — clear the resume markers so a future death on
        # this leg starts fresh.
        job.pop("_is_resume_leg", None)
        job.pop("_resume_prefer_provider", None)
        # Clear provision-retry bookkeeping — a future death will start a new
        # budget. Prevents the count from leaking across legs.
        job.pop("_provision_retry_count", None)
        job.pop("_first_provision_failure_at", None)
        job.pop("_next_retry_at", None)
        return "running"

    if job.get("_is_resume_leg"):
        # Resume leg with no capacity anywhere — terminal cancel per the
        # constraint-satisfaction spec. Distinct from initial-submit failure:
        # nothing to provision means the user's prior leg is gone and they
        # need to be told via email; we don't keep retrying forever.
        #
        # Read attempts ONLY from the per-job dict, never from the shared
        # _worker_debug global. The shared global races across concurrent
        # provisions and leaks sibling-job errors onto this job's surface
        # (job 7f680ee3 Lambda leg surfaced GCP's "unknown" in
        # 2026-04-20 because the global was last written by a concurrent
        # GCP attempt). If the per-job list is empty, use the default
        # fallback string.
        _attempts = job.get("_provision_attempts") or []
        # Prefer real errors (provider API failures) over skip reasons —
        # a skip from provider X must not mask a billing/auth failure from Y.
        _last_err = next(
            (a["error"] for a in reversed(_attempts) if a.get("error")),
            None,
        ) or next(
            (a["skip"] for a in reversed(_attempts) if a.get("skip")),
            "no providers had capacity",
        )
        job["status"] = "cancelled"
        job["cancel_reason"] = "resume_no_capacity"
        job["error"] = f"resume_no_capacity: {_last_err}"
        _sync_job_status(
            job.get("_run_id"), "cancelled",
            failure_reason="resume_no_capacity",
        )
        try:
            from shared.email import send_cancel_email
            send_cancel_email(
                job_id=job_id,
                user_email=job.get("user_email") or "",
                reason="resume_no_capacity",
                preferred_providers=job.get("preferred_providers") or [],
                regions=job.get("regions") or [],
                run_id=job.get("_run_id"),
            )
        except Exception as e:
            logger.warning(f"[resume_no_capacity] email send failed for {job_id}: {e}")
        logger.warning(
            f"Job {job_id[:8]}: resume leg exhausted — cancelled. "
            f"preferred={job.get('preferred_providers') or 'any'} "
            f"regions={job.get('regions') or 'any'}"
        )
        return "cancelled_resume"

    # ── Unified no-capacity handling ────────────────────────────────────────
    # Before: preferred_providers=set → status=failed on first try (lost the
    # job during any transient capacity drought); preferred=empty → retried
    # every 3s forever with no backoff. Both branches now share backoff+retry
    # gated by is_retryable(failure_code).
    from shared.failure_codes import JobFailureCode, is_retryable as _is_retryable

    _attempts = job.get("_provision_attempts") or []
    # Prefer real errors (provider API failures) over skip reasons —
    # a skip from provider X must not mask a billing/auth failure from Y.
    _last_err = next(
        (a["error"] for a in reversed(_attempts) if a.get("error")),
        None,
    ) or next(
        (a["skip"] for a in reversed(_attempts) if a.get("skip")),
        "unknown",
    )

    _code_str = job.get("failure_code") or ""
    try:
        _code = JobFailureCode(_code_str) if _code_str else JobFailureCode.PROV_NO_CAPACITY
    except ValueError:
        _code = JobFailureCode.PROV_NO_CAPACITY
    # When no specific failure_code was set by the provider, default to
    # PROV_NO_CAPACITY — we got here because every provider returned None,
    # which is the capacity-exhaustion signal. Auth / schema errors raise
    # explicit codes (PROV_AUTH_BAD, PROV_SCHEMA_REJECT) and fall through
    # to the non-retryable branch below.

    if _is_retryable(_code):
        _count = int(job.get("_provision_retry_count", 0))
        _first = job.get("_first_provision_failure_at") or time.time()
        job["_first_provision_failure_at"] = _first
        _total_elapsed = time.time() - _first

        # ── BFS GPU-type walk for auto-selected jobs ─────────────────────────
        # When the user didn't specify --gpu (gpu_auto_selected=True), we try
        # the next GPU in the fallback chain rather than re-queuing the same
        # GPU indefinitely. Resets retry count for the new type so it gets its
        # own full backoff budget. Not applied to resume legs (those have a
        # specific GPU intent from the prior run).
        if (
            job.get("gpu_auto_selected")
            and not job.get("_is_resume_leg")
            and _count >= _PROVISION_BFS_TRIGGER_COUNT
        ):
            _current_gpu = job["gpu_type"]
            _tried: set = job.get("_bfs_tried_gpus") or set()
            _tried.add(_current_gpu)
            _min_vram = float(job.get("min_vram_gb") or 0)
            _next_gpu = _shared_bfs_gpu_fallback(
                _current_gpu,
                _min_vram,
                check_candidate=lambda g: g not in _tried and _gpu_has_dispatchable_price(g, job),
            )
            if _next_gpu:
                _tried.add(_next_gpu)
                job["_bfs_tried_gpus"] = _tried
                job["gpu_type"] = _next_gpu
                job["_provision_retry_count"] = 0
                job["_first_provision_failure_at"] = None
                job["_next_retry_at"] = None
                job["status"] = "queued"
                job["error"] = f"No {_current_gpu} capacity; trying {_next_gpu}"
                logger.info(
                    f"Job {job_id[:8]}: BFS GPU walk {_current_gpu} → {_next_gpu} "
                    f"(auto-selected, attempt {_count + 1}, min_vram={_min_vram}GB)"
                )
                return "requeue"
            # All chain alternatives exhausted — fall through to standard backoff

        if _total_elapsed > _PROVISION_MAX_TOTAL_SECONDS:
            # Budget exhausted — flip to terminal failed. Preserves the most
            # recent provider error so the dashboard shows why the last leg
            # failed, not a generic "gave up".
            job["status"] = "failed"
            job["error"] = (
                f"{pref_label}: no capacity after {_count} retries over "
                f"{_total_elapsed/60:.0f} min — {_last_err}"
            )
            job["failure_code"] = JobFailureCode.PROV_NO_CAPACITY.value
            _sync_job_status(job.get("_run_id"), "failed")
            # Release the submit-time credit reservation — the job never
            # launched, so no actual compute was consumed. Without this the
            # hold stays open until the user manually cancels or billing
            # reconciliation runs.
            _release_submit_reservation(job, "failed")
            logger.warning(
                f"Job {job_id[:8]}: provision budget exhausted "
                f"({_count} attempts / {_total_elapsed/60:.0f}min) — failing"
            )
            return "failed"

        # Schedule next attempt per backoff table. Clamp index to last bucket
        # so long-running droughts settle at the longest gap (30m).
        _idx = min(_count, len(_PROVISION_BACKOFF_SCHEDULE) - 1)
        _delay = _PROVISION_BACKOFF_SCHEDULE[_idx]
        job["_provision_retry_count"] = _count + 1
        job["_next_retry_at"] = time.time() + _delay
        job["status"] = "queued"
        # Surface last error on the job so the UI shows WHY it's waiting
        # instead of a stale "queued" with no hint.
        job["error"] = f"{pref_label}: retrying in {_delay}s — {_last_err}"
        # Persist retry state to DB so a restart can restore the backoff
        # position. We merge the current queue_state: submission fields were
        # written at submit time; here we only add/update the backoff keys.
        _sync_queue_state(job.get("_run_id"), job)
        logger.info(
            f"Job {job_id[:8]}: no capacity (attempt {_count + 1}), "
            f"backoff {_delay}s (preferred={pref_label})"
        )
        return "requeue"

    # Non-retryable (auth, schema reject, etc.) — fail immediately; no amount
    # of backoff clears these.
    job["status"] = "failed"
    job["error"] = f"{pref_label}: {_last_err}"
    _sync_job_status(job.get("_run_id"), "failed")
    # Release the submit-time credit reservation — the job never launched.
    _release_submit_reservation(job, "failed")
    logger.warning(
        f"Job {job_id[:8]}: non-retryable failure ({_code.value}) — failing"
    )
    return "failed"


# ── Main worker loop ──────────────────────────────────────────────────────────

async def _job_worker():
    """Server-side job lifecycle manager. Handles provision -> monitor -> terminate -> recover."""
    logger.info("Job worker starting...")
    _worker_debug["started"] = True

    # Wait a few seconds for app to fully start
    await asyncio.sleep(5)

    # ── Recover active jobs from DB (survive deploys) ──────────────────────
    # Recovers three categories:
    #   running            — active instances, recovered for monitoring
    #   queued             — pre-dispatch rows; re-enqueue into _job_queue
    #   awaiting_expand_consent — waiting for CLI consent; restore to _active_jobs
    # provisioning rows with a real instance_id are orphaned in-flight calls —
    # terminate the VM and mark failed. provisioning rows without an instance_id
    # indicate a crash mid-provision; log BILLING LEAK and mark failed.
    try:
        db = get_db()
        def _without_queue_state(cols: str) -> str:
            return cols.replace("queue_state, ", "").replace(", queue_state", "")

        def _db_select_with_legacy_queue_state(query_factory, cols: str, label: str):
            try:
                return _db_call(lambda: query_factory(cols).execute(), label=label)
            except Exception as exc:
                if "queue_state" not in str(exc):
                    raise
                legacy_cols = _without_queue_state(cols)
                return _db_call(
                    lambda: query_factory(legacy_cols).execute(),
                    label=f"{label}_legacy_schema",
                )

        _active_cols = (
            "run_id, job_id, account_id, instance_id, provider, gpu_type, "
            "rate_per_hr, status, spend_ledger_id, provisioned_at, docker_image, "
            "queue_state, metadata"
        )
        active = _db_select_with_legacy_queue_state(
            lambda cols: db.table("job_runs").select(cols).in_("status", ["running"]),
            _active_cols,
            "job_worker:recover",
        )
        _recovered = 0
        _recovery_broker = _init_broker()
        for row in (active.data or []):
            jid = row["job_id"]
            inst = row.get("instance_id")
            if jid in _active_jobs or not inst or inst == "pending":
                continue
            _prov_ts = None
            if row.get("provisioned_at"):
                try:
                    from dateutil.parser import parse as _parse_dt
                    _prov_ts = _parse_dt(row["provisioned_at"]).timestamp()
                except Exception:
                    pass
            # Restore full job intent from queue_state (written at submit time
            # for rows created after issue #126 fix). Falls back to safe
            # defaults for legacy rows that pre-date queue_state persistence.
            _qs = row.get("queue_state") or {}
            # Load placement from job_runs.metadata (written by
            # _record_provision_to_db after a successful provision).
            # Provides the actual zone/region used so fence calls target
            # the right location after a restart that wipes in-process caches.
            _meta = row.get("metadata") or {}
            _recovered_placement = _meta.get("placement") or {}
            _recovered_job = {
                "job_id": jid,
                "user_id": _qs.get("user_id") or row.get("account_id", ""),
                "gpu_type": row.get("gpu_type", ""),
                # Original script and command — empty for pre-#126 rows; failover
                # for those rows will not relaunch (script required check below).
                "script_b64":  _qs.get("script_b64", ""),
                "script_name": _qs.get("script_name", ""),
                "script_args": _qs.get("script_args", ""),
                "environment": _qs.get("environment") or {},
                # Prefer queue_state docker_image; fall back to direct column
                "docker_image": (_qs.get("docker_image") or row.get("docker_image") or ""),
                # Preserve an explicit failover flag; default missing/legacy
                # rows to protected recovery.
                "failover": bool(_qs.get("failover", True)),
                "status": "running",
                "instance_id": inst,
                "provider": row.get("provider"),
                "price_per_hr": row.get("rate_per_hr"),
                "actual_gpu_type": row.get("gpu_type", ""),
                "log_line_count": 0,
                "started_at": _prov_ts,
                "completed_at": None, "duration": None,
                "error": None, "checkpoint_step": _qs.get("checkpoint_step"),
                "preferred_providers":  _qs.get("preferred_providers") or [],
                "excluded_providers":   _qs.get("excluded_providers") or [],
                "regions":              _qs.get("regions") or [],
                "excluded_regions":     _qs.get("excluded_regions") or [],
                "resume_from_job_id":   _qs.get("resume_from_job_id"),
                "min_vram_gb":          float(_qs.get("min_vram_gb") or 0),
                "disk_gb":              int(_qs.get("disk_gb") or 100),
                "gpu_auto_selected":    bool(_qs.get("gpu_auto_selected")),
                "model_params_billion": _qs.get("model_params_billion"),
                "training_mode":        _qs.get("training_mode") or "qlora",
                "dataset_id":           _qs.get("dataset_id") or "",
                "dataset_r2_prefix":    _qs.get("dataset_r2_prefix") or "",
                "migration_count":      int(_qs.get("migration_count") or 0),
                "queued_at": _prov_ts or time.time(),
                "_run_id": row.get("run_id"),
                "_spend_id": row.get("spend_ledger_id"),
                "_placement": _recovered_placement,
                "_disk_retry_count":    int(_qs.get("_disk_retry_count") or 0),
            }
            try:
                if _recovery_broker and not await _check_alive(_recovery_broker, _recovered_job):
                    _recovered_job["completed_at"] = time.time()
                    _recovered_job["duration"] = (
                        _recovered_job["completed_at"]
                        - (_recovered_job.get("started_at") or _recovered_job["completed_at"])
                    )
                    _recovered_job["error"] = "Instance not alive during startup recovery"
                    _settle_in_db(_recovered_job, status="failed")
                    logger.warning(
                        "[recovery] job %s not recovered: provider reports instance %s is not alive",
                        jid[:8], inst,
                    )
                    continue
            except Exception as _alive_err:
                logger.warning(
                    "[recovery] liveness check failed for job %s; recovering conservatively: %s",
                    jid[:8], _alive_err,
                )
            _active_jobs[jid] = _recovered_job
            if not _qs.get("script_b64"):
                # Legacy row pre-dating queue_state persistence (#126).
                # The job is tracked for heartbeat/billing but CANNOT be
                # relaunched on failover — no script to restart with.
                logger.warning(
                    f"[recovery] job {jid[:8]} recovered without script_b64 "
                    f"(pre-#126 row). Failover disabled for this job. "
                    f"run_id={row.get('run_id', 'unknown')}"
                )
            _recovered += 1
        if _recovered:
            logger.info(f"[recovery] Recovered {_recovered} running jobs from DB")

        # ── Re-enqueue queued + awaiting_expand_consent rows ───────────────
        # These are pre-dispatch: no instance was ever provisioned, so no
        # billing leak risk. Rebuild the full job entry from queue_state and
        # restore the backoff timer so the job resumes where it left off.
        _queued_rows = _db_select_with_legacy_queue_state(
            lambda cols: db.table("job_runs").select(cols).in_(
                "status", ["queued", "awaiting_expand_consent"]
            ),
            "run_id, job_id, status, queue_state",
            "job_worker:recover_queued",
        )
        _requeued = 0
        for _qrow in (_queued_rows.data or []):
            _qjid = _qrow.get("job_id")
            if not _qjid or _qjid in _active_jobs:
                continue
            _qs = _qrow.get("queue_state") or {}
            # Reconstruct the in-memory job dict from the persisted submission data.
            # Fields not in queue_state (log_line_count, etc.) get safe defaults.
            _recovered_job = {
                "job_id":             _qjid,
                "user_id":            _qs.get("user_id", ""),
                "gpu_type":           _qs.get("gpu_type", ""),
                "script_b64":         _qs.get("script_b64", ""),
                "script_name":        _qs.get("script_name", ""),
                "script_args":        _qs.get("script_args", ""),
                "environment":        _qs.get("environment") or {},
                "docker_image":       _qs.get("docker_image", ""),
                "failover":           _qs.get("failover", True),
                "status":             _qrow["status"],
                "instance_id":        None,
                "provider":           None,
                "price_per_hr":       None,
                "actual_gpu_type":    None,
                "log_line_count":     0,
                "started_at":         None,
                "completed_at":       None,
                "duration":           None,
                "error":              None,
                "checkpoint_step":    _qs.get("checkpoint_step"),
                "preferred_providers": _qs.get("preferred_providers") or [],
                "excluded_providers": _qs.get("excluded_providers") or [],
                "regions":            _qs.get("regions") or [],
                "excluded_regions":   _qs.get("excluded_regions") or [],
                "resume_from_job_id": _qs.get("resume_from_job_id"),
                "min_vram_gb":        float(_qs.get("min_vram_gb") or 0),
                "disk_gb":            int(_qs.get("disk_gb") or 100),
                "gpu_auto_selected":  bool(_qs.get("gpu_auto_selected")),
                "model_params_billion": _qs.get("model_params_billion"),
                "training_mode":      _qs.get("training_mode") or "qlora",
                "dataset_id":         _qs.get("dataset_id") or "",
                "dataset_r2_prefix":  _qs.get("dataset_r2_prefix") or "",
                "migration_count":    int(_qs.get("migration_count") or 0),
                "queued_at":          _qs.get("queued_at") or time.time(),
                "_run_id":            _qrow.get("run_id"),
                "_is_resume_leg":     bool(_qs.get("_is_resume_leg", False)),
                "_resume_prefer_provider": _qs.get("_resume_prefer_provider"),
                # Restore backoff state so the job picks up where it left off
                "_provision_retry_count":      _qs.get("_provision_retry_count", 0),
                "_next_retry_at":              _qs.get("_next_retry_at"),
                "_first_provision_failure_at": _qs.get("_first_provision_failure_at"),
                "_disk_retry_count":            int(_qs.get("_disk_retry_count") or 0),
            }
            _active_jobs[_qjid] = _recovered_job
            if _qrow["status"] == "queued":
                _job_queue.append(_qjid)
            _requeued += 1
        if _requeued:
            logger.info(f"[recovery] Re-enqueued {_requeued} queued/awaiting-consent jobs from DB")

        # Terminate any "provisioning" instances that got an instance_id before
        # the restart — without this the provider VM keeps billing while VaultLayer
        # considers the job gone.
        _prov_rows = _db_call(
            lambda: db.table("job_runs").select(
                "run_id, job_id, account_id, instance_id, provider"
            ).eq("status", "provisioning").execute(),
            label="job_worker:query_provisioning",
        )
        for _prow in (_prov_rows.data or []):
            _prov_inst = _prow.get("instance_id")
            if _prov_inst and _prov_inst != "pending":
                try:
                    _broker = _init_broker()
                    _stub = {
                        "job_id": _prow.get("job_id", ""),
                        "instance_id": _prov_inst,
                        "provider": _prow.get("provider", ""),
                    }
                    await _terminate_and_settle(_broker, _stub)
                    logger.info(
                        f"[recovery] Terminated orphaned provisioning instance "
                        f"{_prov_inst} ({_prow.get('provider')}) for job "
                        f"{_prow.get('job_id', '')[:8]}"
                    )
                except Exception as _term_err:
                    logger.error(
                        f"[recovery] FAILED to terminate provisioning instance "
                        f"{_prov_inst}: {_term_err} — BILLING LEAK"
                    )
            else:
                # Row has no instance_id: the worker crashed or timed out before
                # the provider returned an ID. The VM may still exist on the
                # provider side (billing active) with no handle to terminate it.
                # Log a BILLING LEAK warning so operators can manually audit the
                # provider dashboard for orphaned instances around this timestamp.
                _job_id = _prow.get("job_id", "unknown")
                _provider = _prow.get("provider") or "unknown"
                logger.error(
                    f"[recovery] BILLING LEAK RISK — provisioning row for job "
                    f"{_job_id[:8]} ({_provider}) has no instance_id. "
                    f"Worker may have crashed mid-provision. "
                    f"Check {_provider} dashboard for orphaned instances. "
                    f"run_id={_prow.get('run_id', 'unknown')}"
                )
        # Mark all provisioning rows failed (instance_id or not).
        # These are genuinely orphaned mid-provision calls, not queued jobs
        # (those are now written as status=queued and handled above).
        _db_call(
            lambda: db.table("job_runs").update({"status": "failed"}).eq("status", "provisioning").execute(),
            label="job_worker:cleanup_provisioning",
        )

    except Exception as e:
        logger.warning(f"[recovery] Failed to recover jobs from DB (non-fatal): {e}")

    while True:
        await asyncio.sleep(3)
        _worker_debug["cycle_count"] += 1

        try:
            # === Phase A: Provision queued jobs ===
            # Circuit breaker: set VL_PAUSE_PROVISIONING=1 in Railway env to halt
            # all new provisioning without a code deploy. Checked every cycle so
            # the env var takes effect on next Railway restart.
            if os.environ.get("VL_PAUSE_PROVISIONING", "").strip() == "1":
                logger.warning("[worker] VL_PAUSE_PROVISIONING=1 — skipping all provisioning this cycle")
                for _jid in list(_job_queue):
                    _qjob = _active_jobs.get(_jid)
                    if _qjob and _qjob.get("status") == "queued":
                        _qjob["error"] = "provisioning paused by operator (VL_PAUSE_PROVISIONING=1)"
                await asyncio.sleep(30)
                continue

            # Process up to MAX_CONCURRENT_PROVISIONS jobs per cycle
            MAX_CONCURRENT_PROVISIONS = 5  # Don't overwhelm providers with simultaneous requests
            _to_remove = []
            # Count in-flight provision attempts (not already-running jobs).
            # Running jobs already consumed their provision budget in a prior cycle;
            # subtracting them from _slots would block the queue even when no
            # new provision API calls are in flight.
            _inflight_count = sum(1 for j in _active_jobs.values() if j.get("status") == "provisioning")
            _slots = max(0, MAX_CONCURRENT_PROVISIONS - _inflight_count)
            _provisioned_this_cycle = 0

            # Phase 1c of unified_queue rollout (design doc:
            # docs/architecture/unified_queue.md). When the feature flag is on,
            # enforce per-provider concurrency caps in addition to the global
            # cap above. Prevents a single provider's bid market from
            # saturating under burst load (see Bug 6 in
            # docs/stress_testing_lessons_2026_04_22.md — Vast A100_40 stuck
            # queue with 10+ concurrent). Off by default → legacy behavior.
            _uq_enabled = False
            _per_provider_inflight = {}
            try:
                from api import unified_queue as _uq
                _uq_enabled = _uq.feature_enabled()
                if _uq_enabled:
                    for _j in _active_jobs.values():
                        _p = _j.get("provider")
                        if _p and _j.get("status") in ("provisioning", "running"):
                            _per_provider_inflight[_p] = _per_provider_inflight.get(_p, 0) + 1
            except ImportError:
                pass  # module optional during staged rollout

            for _qi, job_id in enumerate(list(_job_queue)):
                job = _active_jobs.get(job_id)
                if not job or job["status"] == "cancelled":
                    _to_remove.append(job_id)
                    continue
                if _provisioned_this_cycle >= _slots:
                    break  # at concurrency limit, try rest next cycle

                # Per-provider cap check (Phase 1c). If ALL of the job's
                # preferred providers are at their configured concurrency cap,
                # skip this job for this cycle — it'll get a chance on next
                # iteration once a slot frees.
                if _uq_enabled:
                    _preferred = job.get("preferred_providers") or []
                    if _preferred and all(
                        _per_provider_inflight.get(p, 0) >= _uq.cap_for(p)
                        for p in _preferred
                    ):
                        logger.debug(
                            f"job {job_id[:8]}: all preferred providers "
                            f"{_preferred} at cap; skipping this cycle"
                        )
                        continue

                # Skip jobs waiting out their provision backoff. Set by
                # _handle_provision_result() on a retryable capacity failure —
                # reattempting before _next_retry_at would hammer the same
                # dead regions and waste provider API quota.
                _wait_until = job.get("_next_retry_at")
                if _wait_until and time.time() < _wait_until:
                    continue

                broker = _init_broker()
                if broker is None:
                    _broker_err = _worker_debug.get("last_error") or "broker init failed"
                    # Surface the failure on every queued job so the CLI heartbeat shows why
                    for _jid in list(_job_queue):
                        _qjob = _active_jobs.get(_jid)
                        if _qjob and _qjob.get("status") == "queued":
                            _qjob["error"] = f"broker unavailable — {_broker_err}"
                    logger.warning(f"Job worker: broker unavailable ({_broker_err}), retrying in 30s")
                    await asyncio.sleep(27)
                    break  # can't provision anything without broker
                _worker_debug["broker_ok"] = True

                job["status"] = "provisioning"
                # Persist the status transition to DB before the provider call.
                # This ensures a restart mid-provision sees status=provisioning
                # (orphan cleanup path) rather than status=queued (re-enqueue
                # path), preventing double-dispatch of the same job.
                _sync_job_status(job.get("_run_id"), "provisioning")
                _pref_label = ",".join(job.get("preferred_providers") or []) or "auto"
                logger.info(f"Job worker: provisioning {job_id[:8]} ({job['gpu_type']}) preferred={_pref_label}")
                # Phase 1c (unified_queue): increment in-cycle inflight count
                # against the first preferred provider so we don't launch
                # multiple cycle-local jobs to the same capped provider.
                # Actual provider lands in job["provider"] after _try_provision;
                # this is an optimistic increment based on first preference.
                if _uq_enabled and (job.get("preferred_providers") or []):
                    _first_pref = job["preferred_providers"][0]
                    _per_provider_inflight[_first_pref] = _per_provider_inflight.get(_first_pref, 0) + 1
                # 150s budget is calibrated for the GCP per-zone loop:
                # 3-5 zones × (compute.insert ~5-10 s + zoneOperations.get
                # poll up to 20 s) = 75-150 s under normal conditions.
                # 60 s was the previous value; it was cancelling provisions
                # mid-flight on GCP (2026-04-19: jobs 908f4ab8, 9abad94e
                # both surfaced as "GCP: unknown" with empty attempts
                # because wait_for killed _try_provision before it could
                # write them). Other providers complete in <30 s so the
                # extra headroom doesn't hurt the fast paths. If this
                # number grows again, move to a per-provider budget.
                try:
                    instance_id = await asyncio.wait_for(
                        _try_provision(broker, job), timeout=150
                    )
                except asyncio.TimeoutError:
                    logger.error(f"Job {job_id[:8]}: provision timed out after 150s")
                    # Write a proper timeout error onto the per-job attempts
                    # list so the caller doesn't fall back to the shared
                    # _worker_debug global (which races between jobs and
                    # was surfacing the WRONG provider's error — e.g.
                    # "GCP: Lambda: HTTP 400..." on job 82e558aa when the
                    # Lambda-v1 attempt before it had the real last error).
                    if not job.get("_provision_attempts"):
                        _pname = (job.get("preferred_providers") or ["auto"])[0]
                        job["_provision_attempts"] = [{
                            "provider": _pname,
                            "error": "provision timed out after 150s (wait_for cancelled _try_provision mid-flight)",
                        }]
                    # BILLING LEAK guard: if the provider created a VM after the
                    # timeout fired but before wait_for cancelled the coroutine,
                    # job["instance_id"] may have been set inside _try_provision
                    # before the cancellation propagated. Terminate it now.
                    _orphan_iid = job.get("instance_id")
                    if _orphan_iid:
                        logger.error(
                            f"Job {job_id[:8]}: BILLING LEAK — instance {_orphan_iid} "
                            f"created mid-timeout; scheduling async termination"
                        )
                        _orphan_job = dict(job)
                        asyncio.create_task(
                            _terminate_and_settle(broker, _orphan_job),
                            name=f"orphan_term_{job_id[:8]}",
                        )
                        job["instance_id"] = None
                    else:
                        logger.warning(
                            f"Job {job_id[:8]}: provision timed out with no recorded "
                            f"instance_id — VM may have been created mid-flight. "
                            f"Check provider dashboard for orphaned instances."
                        )
                    instance_id = None

                _outcome = _handle_provision_result(
                    job=job, job_id=job_id, instance_id=instance_id,
                    pref_label=_pref_label,
                )
                if _outcome == "running":
                    _provisioned_this_cycle += 1
                    _to_remove.append(job_id)
                elif _outcome in ("cancelled_resume", "failed"):
                    _to_remove.append(job_id)
                # _outcome == "requeue" → leave on queue for next cycle

            # Remove processed jobs from queue
            if _to_remove:
                async with _job_lock:
                    for jid in _to_remove:
                        if jid in _job_queue:
                            _job_queue.remove(jid)

            # === Phase B: Monitor running jobs ===
            _b = _broker_instance  # use singleton (may be None if no jobs provisioned yet)
            for job_id, job in list(_active_jobs.items()):
                if job["status"] != "running":
                    continue
                if _b is None:
                    _b = _init_broker()
                    if _b is None:
                        break  # can't monitor without broker

                # Startup recovery rebuilds running jobs with log_line_count=0.
                # Refresh before the stuck watchdog so a live job that already
                # posted logs is not treated as a boot failure after an API
                # restart or stale in-memory state.
                job["log_line_count"] = await asyncio.get_event_loop().run_in_executor(
                    None, _get_log_count, job_id
                )

                # Check for stuck instance (provisioned but never posted logs)
                # Container providers (RunPod, Vast.ai) need longer — Docker image pull
                # can take 5-10 min on top of 2-5 min boot time.
                # VM providers (Lambda, AWS, GCP) boot faster with cloud-init.
                _CONTAINER_PROVIDERS = {"runpod", "vast_ai"}
                _stuck_timeout = 900 if job.get("provider") in _CONTAINER_PROVIDERS else 600
                _elapsed = time.time() - (job.get("started_at") or time.time())
                if _elapsed > _stuck_timeout and job.get("log_line_count", 0) == 0:
                    # DB log_line_count can be 0 even when the instance is actively
                    # training (heartbeat upserts fail silently on Supabase). For
                    # Vast.ai, use a two-cycle progress check: on first stuck-check
                    # snapshot the raw log byte count; on the next cycle if bytes
                    # grew the instance is active; if unchanged it is truly stuck.
                    # A stale snapshot (startup lines then hang) always results in
                    # kill on the second cycle. See _vast_check_log_progress().
                    if job.get("provider") == "vast_ai" and job.get("instance_id"):
                        _skip = await _vast_check_log_progress(job, job["instance_id"])
                        if _skip:
                            continue

                    # Before killing: check if instance is still alive and loading.
                    # Container providers may still be pulling the Docker image.
                    # If alive, extend timeout by 10 min (don't kill a loading instance).
                    _still_alive = await _check_alive(_b, job)
                    if _still_alive and _elapsed < _stuck_timeout + 600:
                        logger.info(
                            f"[stuck] Job {job_id[:8]} has 0 logs after {_elapsed:.0f}s but "
                            f"instance is still alive (likely pulling image). Extending timeout."
                        )
                        continue  # skip kill, check again next cycle
                    _timeout_min = int(_elapsed // 60)
                    logger.warning(
                        f"[stuck] Job {job_id[:8]} running {_elapsed:.0f}s with 0 logs — "
                        f"instance {job.get('instance_id')} likely failed to boot. Terminating."
                    )
                    await _terminate_and_settle(_b, job)
                    job["completed_at"] = time.time()
                    job["duration"] = job["completed_at"] - job["started_at"]
                    if job.get("failover"):
                        _settle_in_db(job, status="stuck_requeue")
                        _dying_provider, _ckpt_step = _prepare_stuck_failover_requeue(job, job_id)
                        _open_requeue_run(job)
                        async with _job_lock:
                            _job_queue.append(job_id)
                        # Phase 2 (unified_queue): also enqueue with HIGH
                        # priority when flag is on. Failover retries jump
                        # the NORMAL-priority line because the user is mid-
                        # training and latency matters. Design doc:
                        # docs/architecture/unified_queue.md §DD-5.
                        try:
                            from api import unified_queue as _uq
                            if _uq.feature_enabled():
                                _uq.enqueue(
                                    job_id,
                                    priority=_uq.PRIO_FAILOVER,
                                    retry_context={
                                        "reason": "stuck_requeue",
                                        "prior_provider": _dying_provider or "",
                                        "checkpoint_step": _ckpt_step,
                                    },
                                )
                        except ImportError:
                            pass
                        logger.info(
                            f"[stuck] Job {job_id[:8]} re-queued for failover "
                            f"(checkpoint_step={_ckpt_step})"
                        )
                    else:
                        _settle_in_db(job, status="failed")
                        job["status"] = "failed"
                        job["error"] = f"Instance failed to boot (0 logs after {_timeout_min} min)"
                    continue

                # Check if instance is still alive
                alive = await _check_alive(_b, job)

                # Check for completion (DB logs + provider logs)
                completed = await _check_completion(job_id, job)

                if completed:
                    job["status"] = "completing"
                    await _terminate_and_settle(_b, job)
                    job["completed_at"] = time.time()
                    job["duration"] = job["completed_at"] - (job["started_at"] or job["completed_at"])
                    # Issue #72: parse the exit code from the
                    # "[VaultLayer] Training finished (exit N)" log line
                    # and route non-zero exits to status=failed rather than
                    # reporting them as clean completions. Previous behavior
                    # charged users the full rate for crashed jobs and showed
                    # them on the dashboard as "completed" — semantically
                    # wrong. Exit code 0 remains the only "completed" path.
                    _exit = await _parse_training_exit_code(job_id)
                    # When the 'Training finished' log line is missing (final
                    # /logs POST failed), fall back to the completion event type
                    # stored by _check_completion() Method 4. A 'failed' event
                    # signals a non-zero exit even without the log sentinel.
                    if _exit is None and job.get("_completion_event_type") == "failed":
                        _msg = job.get("_completion_event_message", "")
                        import re as _re
                        _m = _re.search(r"exit_code=(-?\d+)", _msg)
                        _exit = int(_m.group(1)) if _m else 1
                        logger.info(
                            f"[worker] job {job_id[:8]} exit code from failed event: {_exit}"
                        )
                    if _exit is None or _exit == 0:
                        _settle_in_db(job)  # settles spend_ledger + job_runs + deducts credits
                        job["status"] = "completed"
                    else:
                        _log_text = await asyncio.get_event_loop().run_in_executor(
                            None, _fetch_recent_log_text, job_id, 200
                        )
                        _failure_code, _failure_detail = _classify_nonzero_exit(
                            _log_text, _exit
                        )
                        job["failure_code"] = _failure_code
                        job["failure_detail"] = _failure_detail

                        if _failure_code == "run_oom" and job.get("failover"):
                            _next_gpu, _oom_min_vram = _find_runtime_oom_retry_gpu(job)
                            if _next_gpu:
                                _old_gpu = job.get("gpu_type") or job.get("actual_gpu_type") or ""
                                job["error"] = (
                                    f"Runtime CUDA OOM on {_old_gpu}; "
                                    f"retrying on {_next_gpu}"
                                )
                                _settle_in_db(job, status="runtime_oom_requeue")
                                _dying_prov, _ckpt_step = _prepare_runtime_oom_requeue(
                                    job,
                                    job_id,
                                    next_gpu=_next_gpu,
                                    min_vram_gb=_oom_min_vram,
                                )
                                _open_requeue_run(job)
                                async with _job_lock:
                                    _job_queue.append(job_id)
                                try:
                                    from api import unified_queue as _uq
                                    if _uq.feature_enabled():
                                        _uq.enqueue(
                                            job_id,
                                            priority=_uq.PRIO_FAILOVER,
                                            retry_context={
                                                "reason": "runtime_oom_requeue",
                                                "prior_provider": _dying_prov or "",
                                                "checkpoint_step": _ckpt_step,
                                                "prior_gpu": _old_gpu,
                                                "next_gpu": _next_gpu,
                                                "min_vram_gb": _oom_min_vram,
                                            },
                                        )
                                except ImportError:
                                    pass
                                logger.info(
                                    f"[runtime-oom] Job {job_id[:8]} re-queued on "
                                    f"{_next_gpu} after OOM on {_old_gpu} "
                                    f"(min_vram={_oom_min_vram:.1f}GB, "
                                    f"checkpoint_step={_ckpt_step})"
                                )
                                continue

                            logger.warning(
                                f"[runtime-oom] Job {job_id[:8]} OOM but no larger "
                                f"dispatchable GPU was found; settling as failed"
                            )

                        if _failure_code == "boot_disk_full" and job.get("failover"):
                            _next_disk_gb = _next_disk_retry_gb(job)
                            if _next_disk_gb:
                                _old_disk_gb = int(job.get("disk_gb") or 0)
                                job["error"] = (
                                    f"Disk full on {_old_disk_gb or 'default'}GB; "
                                    f"retrying with {_next_disk_gb}GB"
                                )
                                _settle_in_db(job, status="disk_full_requeue")
                                _dying_prov, _ckpt_step = _prepare_disk_full_requeue(
                                    job,
                                    job_id,
                                    next_disk_gb=_next_disk_gb,
                                )
                                _open_requeue_run(job)
                                async with _job_lock:
                                    _job_queue.append(job_id)
                                try:
                                    from api import unified_queue as _uq
                                    if _uq.feature_enabled():
                                        _uq.enqueue(
                                            job_id,
                                            priority=_uq.PRIO_FAILOVER,
                                            retry_context={
                                                "reason": "disk_full_requeue",
                                                "prior_provider": _dying_prov or "",
                                                "checkpoint_step": _ckpt_step,
                                                "prior_disk_gb": _old_disk_gb,
                                                "next_disk_gb": _next_disk_gb,
                                            },
                                        )
                                except ImportError:
                                    pass
                                logger.info(
                                    f"[disk-full] Job {job_id[:8]} re-queued with "
                                    f"{_next_disk_gb}GB disk after disk-full failure "
                                    f"(checkpoint_step={_ckpt_step})"
                                )
                                continue

                            logger.warning(
                                f"[disk-full] Job {job_id[:8]} disk full but disk retry "
                                f"budget is exhausted; settling as failed"
                            )

                        if _failure_code == "run_oom":
                            job["error"] = (
                                "CUDA out of memory; no larger dispatchable GPU "
                                "was available for automatic retry"
                            )
                        elif _failure_code == "boot_disk_full":
                            job["error"] = (
                                "Disk full while preparing the training environment; "
                                "no larger disk retry was available"
                            )
                        else:
                            job["error"] = f"user script exited with code {_exit}"
                        job["failure_reason"] = (
                            "runtime_oom"
                            if _failure_code == "run_oom"
                            else "disk_full"
                            if _failure_code == "boot_disk_full"
                            else f"user_script_exit_{_exit}"
                        )
                        _settle_in_db(job, status="failed")
                        job["status"] = "failed"
                        logger.info(
                            f"[worker] job {job_id[:8]} settled as FAILED "
                            f"(failure_code={_failure_code}, exit={_exit})"
                        )

                elif not alive:
                    # Instance lost — settle the old spend leg first
                    job["completed_at"] = time.time()
                    job["duration"] = job["completed_at"] - (job["started_at"] or job["completed_at"])

                    if job.get("failover"):
                        _settle_in_db(job, status="migrated")
                        _dying_prov, _ckpt_step = _prepare_failover_requeue(job, job_id)
                        _open_requeue_run(job)
                        async with _job_lock:
                            _job_queue.append(job_id)  # re-queue
                        # Phase 2 (unified_queue): HIGH-priority failover retry
                        # enqueue when flag on. Design doc §DD-5.
                        try:
                            from api import unified_queue as _uq
                            if _uq.feature_enabled():
                                _uq.enqueue(
                                    job_id,
                                    priority=_uq.PRIO_FAILOVER,
                                    retry_context={
                                        "reason": "alive_check_failover",
                                        "prior_provider": _dying_prov or "",
                                        "checkpoint_step": _ckpt_step,
                                        "migration_count": job["migration_count"],
                                    },
                                )
                        except ImportError:
                            pass
                        logger.info(
                            f"[failover] Job {job_id[:8]} re-queued after alive-check failure. "
                            f"migration_count={job['migration_count']} checkpoint_step={_ckpt_step}"
                        )
                    else:
                        _settle_in_db(job, status="failed")
                        job["status"] = "failed"
                        job["error"] = "Instance lost (failover not enabled)"

                # Update log line count from DB (non-blocking)
                job["log_line_count"] = await asyncio.get_event_loop().run_in_executor(
                    None, _get_log_count, job_id
                )

        except Exception as e:
            _worker_debug["last_error"] = str(e)[:200]
            logger.error(f"Job worker error: {e}", exc_info=True)
            await asyncio.sleep(5)
