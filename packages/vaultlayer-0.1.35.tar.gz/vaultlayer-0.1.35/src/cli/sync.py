"""
VaultLayer CLI -- vaultlayer sync
Uploads a local dataset OR mirrors a cloud bucket to the Neutral Zone (Cloudflare R2).

Usage:
    vaultlayer sync ./data --dataset-id my-dataset           # local upload
    vaultlayer sync s3://my-bucket/data --dataset-id my-ds   # S3  -> R2 mirror
    vaultlayer sync gs://my-bucket/data --dataset-id my-ds   # GCS -> R2 mirror
    vaultlayer sync az://container/data --dataset-id my-ds   # Azure Blob -> R2 mirror

After this runs, the dataset lives in R2. Every future training run
mounts it at /mnt/vaultlayer on any cloud provider with zero egress fees.
Switch from AWS to CoreWeave without moving a single byte of training data.

Egress pricing (one-time, to internet):
    S3    (AWS us-east-1):     first 100 GB free, then $0.09/GB
    GCS   (GCP):               first 1 GB free, then $0.10/GB (median)
    Azure (Blob Storage):      first 5 GB free, then $0.085/GB
"""

import asyncio
import hashlib
import os
import sys
import time
from pathlib import Path
from typing import Optional

import click


def _register_dataset(config, dataset_id: str, name: str, source_type: str,
                      source_uri: Optional[str], total_bytes: int, total_shards: int) -> None:
    """Register dataset via Railway API (user's machine) or direct DB (Railway).

    Routes through API so users never need Supabase credentials.
    Raises click.ClickException on API registration failure so the upload
    command exits non-zero rather than silently dropping the dataset record.
    """
    import os
    token = os.environ.get("VAULTLAYER_TOKEN", "")
    if not token:
        try:
            from pathlib import Path
            cfg = Path.home() / ".vaultlayer" / "config.env"
            if cfg.exists():
                for line in cfg.read_text().splitlines():
                    if line.startswith("VAULTLAYER_TOKEN="):
                        token = line.split("=", 1)[1].strip().strip('"').strip("'")
                        break
        except Exception:
            pass

    api_url = os.environ.get("VAULTLAYER_API_URL",
                             "https://vaultlayer-production.up.railway.app").rstrip("/")

    if token:
        import httpx
        resp = httpx.post(
            f"{api_url}/api/v1/datasets",
            headers={"Authorization": f"Bearer {token}"},
            json={
                "dataset_id": dataset_id,
                "name": name,
                "source_type": source_type,
                "source_uri": source_uri,
                "total_bytes": total_bytes,
                "total_shards": total_shards,
                "r2_prefix": f"datasets/{dataset_id}/",
            },
            timeout=10,
        )
        if resp.status_code not in (200, 201):
            raise click.ClickException(
                f"Dataset registration failed (HTTP {resp.status_code}): {resp.text[:200]}. "
                f"Upload succeeded but dataset is not tracked. Re-run to retry."
            )
        return

    # Fallback: direct DB (Railway-side or dev with SUPABASE_URL set)
    try:
        from api.db import get_db, SUPABASE_URL
        if not SUPABASE_URL:
            raise click.ClickException(
                "No VAULTLAYER_TOKEN and no SUPABASE_URL — cannot register dataset. "
                "Run 'vaultlayer init' to authenticate."
            )
        db = get_db()
        user_id = getattr(config, "user_id", None) or "default"
        db.table("datasets").upsert({
            "dataset_id":    dataset_id,
            "user_id":       user_id,
            "name":          name,
            "source_type":   source_type,
            "source_uri":    source_uri,
            "r2_prefix":     f"datasets/{dataset_id}/",
            "total_bytes":   total_bytes,
            "total_shards":  total_shards,
            "last_synced_at": "now()",
        }, on_conflict="dataset_id,user_id").execute()
    except click.ClickException:
        raise
    except Exception as e:
        raise click.ClickException(
            f"Dataset registration failed: {e}. Upload succeeded but dataset is not tracked."
        )

# AWS S3 egress pricing tiers (USD/GB, us-east-1 to internet)
_S3_EGRESS_FREE_GB   = 100.0
_S3_EGRESS_TIER1_USD = 0.09   # per GB, 100 GB – 10 TB
_S3_EGRESS_TIER2_USD = 0.085  # per GB, > 10 TB


def _estimate_s3_egress_cost(total_gb: float) -> float:
    """
    Estimate AWS S3 egress cost for transferring total_gb gigabytes.
    Uses us-east-1 to public internet pricing (worst case; DirectConnect cheaper).
    First 100 GB/month is free.
    """
    billable = max(0.0, total_gb - _S3_EGRESS_FREE_GB)
    tier1_gb = min(billable, 10_000 - _S3_EGRESS_FREE_GB)  # 100 GB - 10 TB tier
    tier2_gb = max(0.0, billable - tier1_gb)
    return tier1_gb * _S3_EGRESS_TIER1_USD + tier2_gb * _S3_EGRESS_TIER2_USD


def _parse_s3_uri(uri: str):
    """Parse 's3://bucket/prefix' into (bucket, prefix). prefix may be empty."""
    stripped = uri[len("s3://"):]
    parts = stripped.split("/", 1)
    bucket = parts[0]
    prefix = parts[1] if len(parts) > 1 else ""
    return bucket, prefix


def _parse_gcs_uri(uri: str):
    """Parse 'gs://bucket/prefix' into (bucket, prefix). prefix may be empty."""
    stripped = uri[len("gs://"):]
    parts = stripped.split("/", 1)
    bucket = parts[0]
    prefix = parts[1] if len(parts) > 1 else ""
    return bucket, prefix


def _parse_azure_uri(uri: str):
    """Parse 'az://container/prefix' into (container, prefix). prefix may be empty."""
    stripped = uri[len("az://"):]
    parts = stripped.split("/", 1)
    container = parts[0]
    prefix = parts[1] if len(parts) > 1 else ""
    return container, prefix


# GCS egress pricing (GCP → internet, 2025)
_GCS_EGRESS_FREE_GB   = 1.0    # first 1 GB/month free
_GCS_EGRESS_USD_PER_GB = 0.10  # $0.10/GB median (US/EU); $0.12 for APAC/AU

# Azure Blob Storage egress pricing (to internet, 2025)
_AZURE_EGRESS_FREE_GB   = 5.0    # first 5 GB/month free
_AZURE_EGRESS_TIER1_USD = 0.085  # per GB, 5 GB – 10 TB


def _estimate_gcs_egress_cost(total_gb: float) -> float:
    """Estimate GCS egress cost (GCP → internet). First 1 GB/month free."""
    billable = max(0.0, total_gb - _GCS_EGRESS_FREE_GB)
    return billable * _GCS_EGRESS_USD_PER_GB


def _estimate_azure_egress_cost(total_gb: float) -> float:
    """Estimate Azure Blob Storage egress cost. First 5 GB/month free."""
    billable = max(0.0, total_gb - _AZURE_EGRESS_FREE_GB)
    return billable * _AZURE_EGRESS_TIER1_USD


@click.command()
@click.argument("source_path")
@click.option("--dataset-id", required=True,
              help="Unique ID for this dataset (used to reference it in training runs)")
@click.option("--name", default=None, help="Human-readable dataset name (optional)")
@click.option("--shard-size-mb", default=512, type=int, help="Target shard size in MB (default: 512)")
@click.option("--force", is_flag=True, default=False, help="Re-upload even if dataset already exists")
@click.option("--yes", "-y", is_flag=True, default=False,
              help="Skip the egress cost confirmation prompt (useful in scripts/CI)")
def sync(source_path, dataset_id, name, shard_size_mb, force, yes):
    """
    Upload a dataset for VaultLayer jobs.

    \\b
    Supports four source types:
      Local path   : vaultlayer sync ./training-data --dataset-id my-dataset
      S3 bucket    : vaultlayer sync s3://my-bucket/data --dataset-id my-dataset
      GCS bucket   : vaultlayer sync gs://my-bucket/data --dataset-id my-dataset
      Azure Blob   : vaultlayer sync az://container/data --dataset-id my-dataset

    \\b
    Cloud mirrors are streamed directly without using local disk.
    Egress cost is estimated and confirmed before any data is transferred.
    """
    asyncio.run(_sync_async(source_path, dataset_id, name, shard_size_mb, force, yes))


async def _sync_async(source_path, dataset_id, name, shard_size_mb, force, yes=False):
    is_s3_source    = source_path.startswith("s3://")
    is_gcs_source   = source_path.startswith("gs://")
    is_azure_source = source_path.startswith("az://")
    is_cloud_source = is_s3_source or is_gcs_source or is_azure_source

    if not is_cloud_source:
        source = Path(source_path)
        if not source.exists():
            click.echo(f"  Error: path not found: {source_path}", err=True)
            sys.exit(1)

    from shared.env_utils import load_vaultlayer_env
    load_vaultlayer_env()

    try:
        from shared.config import load_config
        config = load_config()
    except EnvironmentError as e:
        click.echo(f"  Config error: {e}", err=True)
        click.echo("  Run: vaultlayer init --help", err=True)
        sys.exit(1)

    from agents.vault.r2 import R2Client
    from agents.namespace.ingestion import DatasetIngester

    # Get R2 credentials — from config or managed API
    _r2_endpoint = getattr(config.cloudflare, 'r2_endpoint', '') if config.cloudflare else ''
    _r2_key = getattr(config.cloudflare, 'r2_access_key_id', '') if config.cloudflare else ''
    _r2_secret = getattr(config.cloudflare, 'r2_secret_access_key', '') if config.cloudflare else ''
    _r2_bucket = getattr(config.cloudflare, 'r2_bucket', 'vaultlayer-checkpoints') if config.cloudflare else 'vaultlayer-checkpoints'

    if not _r2_endpoint:
        from shared.r2_utils import get_r2_credentials
        _r2 = get_r2_credentials(f"upload-{dataset_id}")
        _r2_endpoint = _r2.get("endpoint", "")
        _r2_key = _r2.get("access_key_id", "")
        _r2_secret = _r2.get("secret_access_key", "")
        _r2_bucket = _r2.get("bucket", "vaultlayer-checkpoints")

    if not _r2_endpoint:
        click.echo("  Error: R2 credentials not available.")
        click.echo("  Set R2_ENDPOINT in .env or ensure VAULTLAYER_TOKEN is valid.")
        sys.exit(1)

    # Inject into config so downstream code that references config.cloudflare works
    if not config.cloudflare:
        from shared.config import CloudflareConfig
        config.cloudflare = CloudflareConfig(
            account_id="managed",
            r2_access_key_id=_r2_key,
            r2_secret_access_key=_r2_secret,
            r2_bucket=_r2_bucket,
            r2_endpoint=_r2_endpoint,
            cf_master_token="",
        )

    r2 = R2Client(
        endpoint=_r2_endpoint,
        access_key_id=_r2_key,
        secret_access_key=_r2_secret,
        bucket=_r2_bucket,
    )

    if not force:
        existing = await DatasetIngester.load_manifest(r2, dataset_id)
        if existing:
            click.echo(f"\n  Dataset '{dataset_id}' already exists in the Neutral Zone.")
            click.echo(f"  Shards: {existing.total_shards}")
            click.echo(f"  Size:   {existing.total_size_bytes / 1e9:.2f} GB")
            click.echo(f"  Use --force to re-upload.\n")
            return

    # ── Cloud sources: list objects, estimate egress cost, stream → R2 ─────
    if is_s3_source:
        await _sync_from_s3(source_path, dataset_id, name, shard_size_mb, config, r2, yes)
        return
    if is_gcs_source:
        await _sync_from_gcs(source_path, dataset_id, name, config, r2, yes)
        return
    if is_azure_source:
        await _sync_from_azure(source_path, dataset_id, name, config, r2, yes)
        return

    # ── Local source ──────────────────────────────────────────────────────────
    source = Path(source_path)
    total_bytes = sum(f.stat().st_size for f in source.rglob("*") if f.is_file())
    total_files = sum(1 for f in source.rglob("*") if f.is_file())

    click.echo(f"""
  VaultLayer Sync -- Neutral Zone Upload
  ----------------------------------------
  Source:      {source_path}
  Dataset ID:  {dataset_id}
  Files:       {total_files:,}
  Size:        {total_bytes / 1e9:.2f} GB
  Destination: r2://{config.cloudflare.r2_bucket}/datasets/{dataset_id}/
""")

    start_time = time.monotonic()
    last_pct = [0]

    def on_progress(uploaded, total):
        pct = int(uploaded / total * 100) if total else 0
        if pct >= last_pct[0] + 5 or uploaded == total:
            last_pct[0] = pct
            elapsed = time.monotonic() - start_time
            rate = uploaded / elapsed if elapsed > 0 else 0
            eta = (total - uploaded) / rate if rate > 0 else 0
            bar = "#" * (pct // 5) + "-" * (20 - pct // 5)
            click.echo(f"\\r  [{bar}] {pct}%  {uploaded}/{total} shards  ETA: {eta:.0f}s    ",
                       nl=(uploaded == total))

    ingester = DatasetIngester(
        r2=r2, dataset_id=dataset_id,
        dataset_name=name or dataset_id,
        shard_size_bytes=shard_size_mb * 1024 * 1024,
        on_progress=on_progress,
    )

    try:
        manifest = await ingester.ingest(source_path)
    except Exception as e:
        click.echo(f"\\n  Upload failed: {e}", err=True)
        sys.exit(1)

    elapsed = time.monotonic() - start_time
    speed = (total_bytes / 1e9) / elapsed * 8 if elapsed > 0 else 0

    import hashlib
    version_hash = hashlib.sha256(
        f"{dataset_id}:{manifest.total_size_bytes}:{manifest.total_shards}".encode()
    ).hexdigest()[:12]
    dataset_version = f"v-{version_hash}"

    # Register dataset in Supabase for storage billing + dashboard visibility
    _register_dataset(
        config=config,
        dataset_id=dataset_id,
        name=name or dataset_id,
        source_type="local",
        source_uri=None,
        total_bytes=manifest.total_size_bytes,
        total_shards=manifest.total_shards,
    )

    try:
        if hasattr(config, "supabase") and config.supabase:
            from supabase import create_client
            _sb = create_client(config.supabase.url, config.supabase.key)
            _sb.table("datasets").upsert(
                {"id": dataset_id, "current_version": dataset_version},
                on_conflict="id",
            ).execute()
    except Exception:
        pass

    from shared.storage_billing import get_current_storage_rate
    monthly_cost = (manifest.total_size_bytes / 1e9) * get_current_storage_rate()
    click.echo(f"""
  Upload complete!
  ----------------------------------------
  Shards:   {manifest.total_shards}
  Size:     {manifest.total_size_bytes / 1e9:.2f} GB
  Time:     {elapsed:.1f}s ({speed:.2f} Gbps)
  Storage:  ~${monthly_cost:.3f}/month
  Dataset version: {dataset_version}
  Manifest: r2://{config.cloudflare.r2_bucket}/datasets/{dataset_id}/manifest.json

  To use in training:
    vaultlayer run --data r2://{dataset_id} python train.py

  Your dataset is now accessible from any cloud provider with zero egress fees.
""")


# ── S3 → R2 mirror ───────────────────────────────────────────────────────────

async def _sync_from_s3(s3_uri, dataset_id, name, shard_size_mb, config, r2, yes: bool):
    """
    Mirror an S3 bucket/prefix directly to Cloudflare R2.

    Flow:
      1. List all objects at s3_uri (boto3 paginator)
      2. Compute total size and estimate AWS egress cost
      3. Show summary + cost estimate to user
      4. Ask for confirmation (unless --yes)
      5. Stream each object from S3 → R2 without writing to local disk
         (boto3 get_object -> StreamingBody -> r2 put_object)
    """
    import boto3
    import botocore.exceptions

    bucket, prefix = _parse_s3_uri(s3_uri)

    click.echo(f"\n  Scanning s3://{bucket}/{prefix} ...")

    # ── 1. List all objects ──────────────────────────────────────────────────
    try:
        s3 = boto3.client(
            "s3",
            aws_access_key_id=config.aws.access_key_id,
            aws_secret_access_key=config.aws.secret_access_key,
            region_name=getattr(config.aws, "region", "us-east-1"),
        )
        paginator = s3.get_paginator("list_objects_v2")
        pages = paginator.paginate(Bucket=bucket, Prefix=prefix)
        objects = []
        for page in pages:
            for obj in page.get("Contents", []):
                objects.append({"key": obj["Key"], "size": obj["Size"]})
    except botocore.exceptions.ClientError as e:
        click.echo(f"\n  S3 error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"\n  Failed to list S3 objects: {e}", err=True)
        sys.exit(1)

    if not objects:
        click.echo(f"  No objects found at s3://{bucket}/{prefix}", err=True)
        sys.exit(1)

    total_bytes = sum(o["size"] for o in objects)
    total_gb    = total_bytes / 1e9
    egress_cost = _estimate_s3_egress_cost(total_gb)

    # ── 2. Show summary + egress cost estimate ───────────────────────────────
    click.echo(f"""
  VaultLayer Sync -- S3 to R2 Mirror
  ----------------------------------------
  Source:       s3://{bucket}/{prefix}
  Objects:      {len(objects):,}
  Total size:   {total_gb:.2f} GB
  Destination:  r2://{config.cloudflare.r2_bucket}/datasets/{dataset_id}/

  AWS Egress Estimate
  ----------------------------------------
  Data to transfer : {total_gb:.2f} GB
  Free tier used   : {min(total_gb, _S3_EGRESS_FREE_GB):.1f} GB (of {_S3_EGRESS_FREE_GB:.0f} GB/month)
  Billable         : {max(0.0, total_gb - _S3_EGRESS_FREE_GB):.2f} GB @ ${_S3_EGRESS_TIER1_USD}/GB
  Estimated cost   : ${egress_cost:.2f} USD

  Note: Cost is a one-time fee. R2 storage and reads are free.
  After this mirror, switching providers costs $0 in egress.
""")

    # ── 3. Confirmation prompt ───────────────────────────────────────────────
    if not yes:
        if egress_cost > 0:
            confirmed = click.confirm(
                f"  Proceed with S3 mirror? (estimated egress: ${egress_cost:.2f})",
                default=False,
            )
        else:
            confirmed = click.confirm(
                f"  Proceed with S3 mirror? (within free tier — no egress charge)",
                default=True,
            )
        if not confirmed:
            click.echo("  Aborted.")
            return

    # ── 4. Stream S3 → R2 ───────────────────────────────────────────────────
    r2_prefix = f"datasets/{dataset_id}/"
    transferred = 0
    failed = []
    start_time = time.monotonic()

    click.echo(f"  Mirroring {len(objects):,} objects to R2 ...")

    # Create one R2 client for the entire loop — avoids repeated auth handshakes
    import boto3 as _boto3
    r2_boto = _boto3.client(
        "s3",
        endpoint_url=config.cloudflare.r2_endpoint,
        aws_access_key_id=config.cloudflare.r2_access_key_id,
        aws_secret_access_key=config.cloudflare.r2_secret_access_key,
        region_name="auto",
    )

    for i, obj in enumerate(objects, 1):
        key   = obj["key"]
        # Compute destination key: strip the S3 prefix so objects are relative
        rel   = key[len(prefix):].lstrip("/") if prefix else key
        r2_key = r2_prefix + rel

        try:
            # Stream from S3 directly into R2 multipart upload — avoids loading
            # the entire object into CLI memory (issue #137).
            response = s3.get_object(Bucket=bucket, Key=key)
            r2_boto.upload_fileobj(
                response["Body"],
                config.cloudflare.r2_bucket,
                r2_key,
                ExtraArgs={"ServerSideEncryption": "AES256"},
            )
            transferred += obj["size"]
        except Exception as e:
            failed.append((key, str(e)))
            click.echo(f"\n  Warning: failed to mirror {key}: {e}", err=True)

        # Progress every 5% or last object
        pct = int(i / len(objects) * 100)
        if i == 1 or pct % 5 == 0 or i == len(objects):
            elapsed  = time.monotonic() - start_time
            rate_mbs = (transferred / 1e6) / elapsed if elapsed > 0 else 0
            eta      = (total_bytes - transferred) / (transferred / elapsed) if transferred > 0 and elapsed > 0 else 0
            bar      = "#" * (pct // 5) + "-" * (20 - pct // 5)
            click.echo(
                f"\r  [{bar}] {pct}%  {i}/{len(objects)} objects  "
                f"{rate_mbs:.1f} MB/s  ETA: {eta:.0f}s    ",
                nl=(i == len(objects)),
            )

    elapsed = time.monotonic() - start_time

    # ── 5. Fail on partial transfer (issue #136) ─────────────────────────────
    if failed:
        raise click.ClickException(
            f"S3 mirror incomplete: {len(failed)}/{len(objects)} objects failed. "
            f"Dataset NOT registered. Failed keys: {[k for k, _ in failed[:5]]}..."
            if len(failed) > 5 else
            f"S3 mirror incomplete: {len(failed)}/{len(objects)} objects failed. "
            f"Dataset NOT registered. Failed keys: {[k for k, _ in failed]}"
        )

    # ── 6. Write canonical manifest.json (issue #135) ─────────────────────────
    import json as _json
    manifest_key  = r2_prefix + "manifest.json"
    manifest_body = _json.dumps({
        "dataset_id":    dataset_id,
        "dataset_name":  name or dataset_id,
        "source_type":   "s3_mirror",
        "source_uri":    s3_uri,
        "object_count":  len(objects),
        "total_bytes":   transferred,
        "mirrored_at":   time.time(),
    })
    try:
        r2_boto.put_object(
            Bucket=config.cloudflare.r2_bucket,
            Key=manifest_key,
            Body=manifest_body.encode(),
            ContentType="application/json",
            ServerSideEncryption="AES256",
        )
    except Exception as e:
        click.echo(f"\n  Warning: could not write manifest: {e}", err=True)

    speed_mbps = (transferred / 1e6) / elapsed if elapsed > 0 else 0
    from shared.storage_billing import get_current_storage_rate
    monthly_storage_cost = (transferred / 1e9) * get_current_storage_rate()

    # Register in Supabase for storage billing
    _register_dataset(
        config=config,
        dataset_id=dataset_id,
        name=name or dataset_id,
        source_type="s3_mirror",
        source_uri=s3_uri,
        total_bytes=transferred,
        total_shards=len(objects),
    )

    click.echo(f"""
  Mirror complete!
  ----------------------------------------
  Objects:        {len(objects):,} transferred
  Size:           {transferred / 1e9:.2f} GB
  Time:           {elapsed:.1f}s ({speed_mbps:.1f} MB/s)
  Egress cost:    ~${egress_cost:.2f} USD (one-time)
  Storage:        ~${monthly_storage_cost:.3f}/month

  Dataset is now in R2 — future migrations cost $0 in egress.
  To use in training:
    vaultlayer run --data r2://{dataset_id} python train.py
""")


# ── GCS → R2 mirror ───────────────────────────────────────────────────────────

async def _sync_from_gcs(gcs_uri: str, dataset_id: str, name, config, r2, yes: bool):
    """
    Mirror a GCS bucket/prefix directly to Cloudflare R2.

    Flow:
      1. List all blobs at gs://bucket/prefix (google-cloud-storage)
      2. Estimate GCP egress cost ($0.10/GB to internet, first 1 GB free)
      3. Show summary + cost estimate, confirm
      4. Stream each blob GCS → R2 without writing to local disk
    """
    try:
        from google.cloud import storage as gcs_storage
    except ImportError:
        click.echo(
            "  Error: google-cloud-storage is required for GCS mirroring.\n"
            "  Install: pip install google-cloud-storage",
            err=True,
        )
        sys.exit(1)

    bucket_name, prefix = _parse_gcs_uri(gcs_uri)

    click.echo(f"\n  Scanning gs://{bucket_name}/{prefix} ...")

    # ── 1. Build GCS client ───────────────────────────────────────────────────
    try:
        storage_cfg = getattr(config, "storage", None)
        creds_json  = getattr(storage_cfg, "gcs_credentials_json", "") if storage_cfg else ""
        if creds_json:
            gcs_client = gcs_storage.Client.from_service_account_json(creds_json)
        else:
            # Application Default Credentials (gcloud auth application-default login)
            gcs_client = gcs_storage.Client()

        bucket = gcs_client.bucket(bucket_name)
        blobs  = list(gcs_client.list_blobs(bucket_name, prefix=prefix or None))
    except Exception as e:
        click.echo(f"\n  GCS error listing blobs: {e}", err=True)
        sys.exit(1)

    if not blobs:
        click.echo(f"  No blobs found at gs://{bucket_name}/{prefix}", err=True)
        sys.exit(1)

    total_bytes = sum(b.size or 0 for b in blobs)
    total_gb    = total_bytes / 1e9
    egress_cost = _estimate_gcs_egress_cost(total_gb)

    # ── 2. Summary ───────────────────────────────────────────────────────────
    click.echo(f"""
  VaultLayer Sync -- GCS to R2 Mirror
  ----------------------------------------
  Source:       gs://{bucket_name}/{prefix}
  Blobs:        {len(blobs):,}
  Total size:   {total_gb:.2f} GB
  Destination:  r2://{config.cloudflare.r2_bucket}/datasets/{dataset_id}/

  GCP Egress Estimate
  ----------------------------------------
  Data to transfer : {total_gb:.2f} GB
  Free tier used   : {min(total_gb, _GCS_EGRESS_FREE_GB):.1f} GB (of {_GCS_EGRESS_FREE_GB:.0f} GB/month)
  Billable         : {max(0.0, total_gb - _GCS_EGRESS_FREE_GB):.2f} GB @ ${_GCS_EGRESS_USD_PER_GB}/GB
  Estimated cost   : ${egress_cost:.2f} USD

  Note: Cost is a one-time fee. After this mirror, switching providers costs $0 in egress.
""")

    # ── 3. Confirmation ───────────────────────────────────────────────────────
    if not yes:
        confirmed = click.confirm(
            f"  Proceed with GCS mirror?"
            + (f" (estimated egress: ${egress_cost:.2f})" if egress_cost > 0
               else " (within free tier — no egress charge)"),
            default=(egress_cost == 0),
        )
        if not confirmed:
            click.echo("  Aborted.")
            return

    # ── 4. Stream GCS → R2 ───────────────────────────────────────────────────
    import boto3 as _boto3

    r2_boto = _boto3.client(
        "s3",
        endpoint_url=config.cloudflare.r2_endpoint,
        aws_access_key_id=config.cloudflare.r2_access_key_id,
        aws_secret_access_key=config.cloudflare.r2_secret_access_key,
        region_name="auto",
    )
    r2_prefix  = f"datasets/{dataset_id}/"
    transferred = 0
    failed      = []
    start_time  = time.monotonic()

    click.echo(f"  Mirroring {len(blobs):,} blobs to R2 ...")

    for i, blob in enumerate(blobs, 1):
        rel    = blob.name[len(prefix):].lstrip("/") if prefix else blob.name
        r2_key = r2_prefix + rel
        try:
            # Stream GCS → R2 without buffering in CLI memory (issue #137).
            # blob.open("rb") returns a BlobReader file-like that reads lazily
            # from GCS; upload_fileobj feeds it in chunks to S3/R2 multipart.
            # This avoids loading the full blob into a BytesIO buffer first.
            with blob.open("rb") as _gcs_stream:
                r2_boto.upload_fileobj(
                    _gcs_stream,
                    config.cloudflare.r2_bucket,
                    r2_key,
                    ExtraArgs={"ServerSideEncryption": "AES256"},
                )
            transferred += blob.size or 0
        except Exception as e:
            failed.append((blob.name, str(e)))
            click.echo(f"\n  Warning: failed to mirror {blob.name}: {e}", err=True)

        pct = int(i / len(blobs) * 100)
        if i == 1 or pct % 5 == 0 or i == len(blobs):
            elapsed  = time.monotonic() - start_time
            rate_mbs = (transferred / 1e6) / elapsed if elapsed > 0 else 0
            eta      = (total_bytes - transferred) / (transferred / elapsed) if transferred > 0 and elapsed > 0 else 0
            bar      = "#" * (pct // 5) + "-" * (20 - pct // 5)
            click.echo(
                f"\r  [{bar}] {pct}%  {i}/{len(blobs)} blobs  "
                f"{rate_mbs:.1f} MB/s  ETA: {eta:.0f}s    ",
                nl=(i == len(blobs)),
            )

    elapsed = time.monotonic() - start_time

    # ── 5. Fail on partial transfer (issue #136) ─────────────────────────────
    if failed:
        raise click.ClickException(
            f"GCS mirror incomplete: {len(failed)}/{len(blobs)} blobs failed. "
            f"Dataset NOT registered. Failed: {[k for k, _ in failed[:5]]}..."
            if len(failed) > 5 else
            f"GCS mirror incomplete: {len(failed)}/{len(blobs)} blobs failed. "
            f"Dataset NOT registered. Failed: {[k for k, _ in failed]}"
        )

    # ── 6. Write canonical manifest.json (issue #135) ─────────────────────────
    import json as _json
    manifest_key  = r2_prefix + "manifest.json"
    manifest_body = _json.dumps({
        "dataset_id":    dataset_id,
        "dataset_name":  name or dataset_id,
        "source_type":   "gcs_mirror",
        "source_uri":    gcs_uri,
        "object_count":  len(blobs),
        "total_bytes":   transferred,
        "mirrored_at":   time.time(),
    })
    try:
        r2_boto.put_object(
            Bucket=config.cloudflare.r2_bucket,
            Key=manifest_key,
            Body=manifest_body.encode(),
            ContentType="application/json",
            ServerSideEncryption="AES256",
        )
    except Exception as e:
        click.echo(f"\n  Warning: could not write manifest: {e}", err=True)

    speed_mbps = (transferred / 1e6) / elapsed if elapsed > 0 else 0
    from shared.storage_billing import get_current_storage_rate
    monthly_storage_cost = (transferred / 1e9) * get_current_storage_rate()

    _register_dataset(
        config=config,
        dataset_id=dataset_id,
        name=name or dataset_id,
        source_type="gcs_mirror",
        source_uri=gcs_uri,
        total_bytes=transferred,
        total_shards=len(blobs),
    )

    click.echo(f"""
  Mirror complete!
  ----------------------------------------
  Blobs:          {len(blobs):,} transferred
  Size:           {transferred / 1e9:.2f} GB
  Time:           {elapsed:.1f}s ({speed_mbps:.1f} MB/s)
  Egress cost:    ~${egress_cost:.2f} USD (one-time)
  Storage:        ~${monthly_storage_cost:.3f}/month

  Dataset is now in R2 — future migrations cost $0 in egress.
  To use in training:
    vaultlayer run --data r2://{dataset_id} python train.py
""")


# ── Azure Blob → R2 mirror ────────────────────────────────────────────────────

async def _sync_from_azure(azure_uri: str, dataset_id: str, name, config, r2, yes: bool):
    """
    Mirror an Azure Blob Storage container/prefix to Cloudflare R2.

    Flow:
      1. List all blobs at az://container/prefix (azure-storage-blob)
      2. Estimate Azure egress cost ($0.085/GB, first 5 GB free)
      3. Show summary + cost estimate, confirm
      4. Stream each blob Azure → R2 without writing to local disk
    """
    try:
        from azure.storage.blob import BlobServiceClient
    except ImportError:
        click.echo(
            "  Error: azure-storage-blob is required for Azure Blob mirroring.\n"
            "  Install: pip install azure-storage-blob",
            err=True,
        )
        sys.exit(1)

    container_name, prefix = _parse_azure_uri(azure_uri)

    click.echo(f"\n  Scanning az://{container_name}/{prefix} ...")

    # ── 1. Build Azure client ─────────────────────────────────────────────────
    try:
        storage_cfg = getattr(config, "storage", None)
        conn_str    = getattr(storage_cfg, "azure_connection_string", "") if storage_cfg else ""
        acct_name   = getattr(storage_cfg, "azure_account_name", "")    if storage_cfg else ""
        acct_key    = getattr(storage_cfg, "azure_account_key", "")     if storage_cfg else ""

        if conn_str:
            az_client = BlobServiceClient.from_connection_string(conn_str)
        elif acct_name and acct_key:
            az_client = BlobServiceClient(
                account_url=f"https://{acct_name}.blob.core.windows.net",
                credential=acct_key,
            )
        else:
            raise ValueError(
                "No Azure credentials found. Run: vaultlayer connect storage --provider azure"
            )

        container_client = az_client.get_container_client(container_name)
        blobs = list(container_client.list_blobs(name_starts_with=prefix or None))
    except Exception as e:
        click.echo(f"\n  Azure error listing blobs: {e}", err=True)
        sys.exit(1)

    if not blobs:
        click.echo(f"  No blobs found at az://{container_name}/{prefix}", err=True)
        sys.exit(1)

    total_bytes = sum(b["size"] or 0 for b in blobs)
    total_gb    = total_bytes / 1e9
    egress_cost = _estimate_azure_egress_cost(total_gb)

    # ── 2. Summary ───────────────────────────────────────────────────────────
    click.echo(f"""
  VaultLayer Sync -- Azure Blob to R2 Mirror
  ----------------------------------------
  Source:       az://{container_name}/{prefix}
  Blobs:        {len(blobs):,}
  Total size:   {total_gb:.2f} GB
  Destination:  r2://{config.cloudflare.r2_bucket}/datasets/{dataset_id}/

  Azure Egress Estimate
  ----------------------------------------
  Data to transfer : {total_gb:.2f} GB
  Free tier used   : {min(total_gb, _AZURE_EGRESS_FREE_GB):.1f} GB (of {_AZURE_EGRESS_FREE_GB:.0f} GB/month)
  Billable         : {max(0.0, total_gb - _AZURE_EGRESS_FREE_GB):.2f} GB @ ${_AZURE_EGRESS_TIER1_USD}/GB
  Estimated cost   : ${egress_cost:.2f} USD

  Note: Cost is a one-time fee. After this mirror, switching providers costs $0 in egress.
""")

    # ── 3. Confirmation ───────────────────────────────────────────────────────
    if not yes:
        confirmed = click.confirm(
            f"  Proceed with Azure Blob mirror?"
            + (f" (estimated egress: ${egress_cost:.2f})" if egress_cost > 0
               else " (within free tier — no egress charge)"),
            default=(egress_cost == 0),
        )
        if not confirmed:
            click.echo("  Aborted.")
            return

    # ── 4. Stream Azure → R2 ─────────────────────────────────────────────────
    import boto3 as _boto3

    r2_boto = _boto3.client(
        "s3",
        endpoint_url=config.cloudflare.r2_endpoint,
        aws_access_key_id=config.cloudflare.r2_access_key_id,
        aws_secret_access_key=config.cloudflare.r2_secret_access_key,
        region_name="auto",
    )
    r2_prefix   = f"datasets/{dataset_id}/"
    transferred = 0
    failed      = []
    start_time  = time.monotonic()

    click.echo(f"  Mirroring {len(blobs):,} blobs to R2 ...")

    for i, blob_props in enumerate(blobs, 1):
        blob_name = blob_props["name"]
        rel       = blob_name[len(prefix):].lstrip("/") if prefix else blob_name
        r2_key    = r2_prefix + rel
        try:
            # Stream Azure Blob → R2 without buffering in CLI memory (issue #137).
            # StorageStreamDownloader implements read(length) so upload_fileobj
            # consumes it in configurable chunks without a full BytesIO buffer.
            blob_client = container_client.get_blob_client(blob_name)
            _az_stream = blob_client.download_blob()
            r2_boto.upload_fileobj(
                _az_stream,
                config.cloudflare.r2_bucket,
                r2_key,
                ExtraArgs={"ServerSideEncryption": "AES256"},
            )
            transferred += blob_props["size"] or 0
        except Exception as e:
            failed.append((blob_name, str(e)))
            click.echo(f"\n  Warning: failed to mirror {blob_name}: {e}", err=True)

        pct = int(i / len(blobs) * 100)
        if i == 1 or pct % 5 == 0 or i == len(blobs):
            elapsed  = time.monotonic() - start_time
            rate_mbs = (transferred / 1e6) / elapsed if elapsed > 0 else 0
            eta      = (total_bytes - transferred) / (transferred / elapsed) if transferred > 0 and elapsed > 0 else 0
            bar      = "#" * (pct // 5) + "-" * (20 - pct // 5)
            click.echo(
                f"\r  [{bar}] {pct}%  {i}/{len(blobs)} blobs  "
                f"{rate_mbs:.1f} MB/s  ETA: {eta:.0f}s    ",
                nl=(i == len(blobs)),
            )

    elapsed = time.monotonic() - start_time

    # ── 5. Fail on partial transfer (issue #136) ─────────────────────────────
    if failed:
        raise click.ClickException(
            f"Azure mirror incomplete: {len(failed)}/{len(blobs)} blobs failed. "
            f"Dataset NOT registered. Failed: {[k for k, _ in failed[:5]]}..."
            if len(failed) > 5 else
            f"Azure mirror incomplete: {len(failed)}/{len(blobs)} blobs failed. "
            f"Dataset NOT registered. Failed: {[k for k, _ in failed]}"
        )

    # ── 6. Write canonical manifest.json (issue #135) ─────────────────────────
    import json as _json
    manifest_key  = r2_prefix + "manifest.json"
    manifest_body = _json.dumps({
        "dataset_id":    dataset_id,
        "dataset_name":  name or dataset_id,
        "source_type":   "azure_mirror",
        "source_uri":    azure_uri,
        "object_count":  len(blobs),
        "total_bytes":   transferred,
        "mirrored_at":   time.time(),
    })
    try:
        r2_boto.put_object(
            Bucket=config.cloudflare.r2_bucket,
            Key=manifest_key,
            Body=manifest_body.encode(),
            ContentType="application/json",
            ServerSideEncryption="AES256",
        )
    except Exception as e:
        click.echo(f"\n  Warning: could not write manifest: {e}", err=True)

    speed_mbps = (transferred / 1e6) / elapsed if elapsed > 0 else 0
    from shared.storage_billing import get_current_storage_rate
    monthly_storage_cost = (transferred / 1e9) * get_current_storage_rate()

    _register_dataset(
        config=config,
        dataset_id=dataset_id,
        name=name or dataset_id,
        source_type="azure_mirror",
        source_uri=azure_uri,
        total_bytes=transferred,
        total_shards=len(blobs),
    )

    click.echo(f"""
  Mirror complete!
  ----------------------------------------
  Blobs:          {len(blobs):,} transferred
  Size:           {transferred / 1e9:.2f} GB
  Time:           {elapsed:.1f}s ({speed_mbps:.1f} MB/s)
  Egress cost:    ~${egress_cost:.2f} USD (one-time)
  Storage:        ~${monthly_storage_cost:.3f}/month

  Dataset is now in R2 — future migrations cost $0 in egress.
  To use in training:
    vaultlayer run --data r2://{dataset_id} python train.py
""")
