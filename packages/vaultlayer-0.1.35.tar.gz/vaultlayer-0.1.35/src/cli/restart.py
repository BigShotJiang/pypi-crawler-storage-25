"""
vaultlayer restart — Resume a suspended or interrupted job.

Usage:
    vaultlayer restart --job-id abc123

Internally:
  1. Looks up the job in the database (job_runs table)
  2. Verifies job exists + status is suspended/interrupted/failed
  3. Checks credit balance >= $5 minimum
  4. Finds the latest checkpoint in R2
  5. Checks GPU availability + current pricing
  6. If price changed significantly or GPU unavailable → shows user and asks
  7. Re-submits the job with checkpoint auto-loaded (user never sees internal details)

The restart command is as simple as the start command — the user doesn't need
to know about checkpoints, R2, or providers. They just run the command and
training continues from where it left off.
"""
from __future__ import annotations

import os
import sys
import logging
import shlex
from pathlib import Path

import click

logger = logging.getLogger(__name__)


@click.command()
@click.option("--job-id", required=True, help="Job ID to restart (from suspension email or vaultlayer ps)")
@click.option("--yes", "-y", is_flag=True, default=False,
              help="Skip confirmation prompt (use in scripts/CI)")
def restart(job_id: str, yes: bool):
    """Restart a suspended or interrupted job from its last checkpoint.

    \b
    Your training continues exactly where it left off — no code changes needed.
    VaultLayer automatically finds the latest checkpoint and resumes on the
    cheapest available GPU.

    \b
    Examples:
        vaultlayer restart --job-id abc123
        vaultlayer restart --job-id abc123 -y
    """
    # Load env
    from shared.env_utils import load_vaultlayer_env
    load_vaultlayer_env()

    token = os.environ.get("VAULTLAYER_TOKEN", "")
    if not token:
        from pathlib import Path
        token_file = Path.home() / ".vaultlayer" / "token"
        config_env = Path.home() / ".vaultlayer" / "config.env"
        if token_file.exists():
            token = token_file.read_text().strip()
        elif config_env.exists():
            from dotenv import dotenv_values
            token = dotenv_values(config_env).get("VAULTLAYER_TOKEN", "")
    if not token:
        click.echo("  Not authenticated. Run 'vaultlayer init' first.")
        raise SystemExit(1)

    click.echo("")
    click.echo(f"  Restarting job {job_id}...")
    click.echo("")
    api_url = os.environ.get("VAULTLAYER_API_URL", "https://vaultlayer-production.up.railway.app")

    # ── Step 1: Look up job ──────────────────────────────────────────────────
    job_info = _fetch_job_info(job_id, token=token, api_url=api_url)
    if not job_info:
        click.echo(f"  Error: Job {job_id} not found in database.")
        click.echo("  Check the job ID and try again. Use 'vaultlayer ps' to list jobs.")
        raise SystemExit(1)

    status = job_info.get("status", "")
    if status in ("running", "provisioning"):
        click.echo(f"  Job {job_id} is already {status}. Nothing to restart.")
        raise SystemExit(0)

    if status not in ("suspended", "failed", "interrupted"):
        click.echo(f"  Job {job_id} has status '{status}' — cannot restart.")
        click.echo("  Only suspended, failed, or interrupted jobs can be restarted.")
        raise SystemExit(1)

    click.echo(f"  Job found: {job_info.get('job_name', job_id)}")
    click.echo(f"  Status: {status}")
    click.echo(f"  Provider: {job_info.get('provider', '?')}")
    click.echo(f"  GPU: {job_info.get('gpu_type', '?')}")

    # ── Step 2: Check credits ────────────────────────────────────────────────
    balance = _check_balance(api_url, token)
    if balance is not None:
        click.echo(f"  Credits: ${balance:.2f}")
        if balance < 5.0:
            click.echo("")
            click.echo("  Insufficient credits. Minimum $5.00 required.")
            click.echo("  Contact support to top up credits.")
            raise SystemExit(1)
    else:
        click.echo("  Credits: could not verify — check your connection and try again.")
        raise SystemExit(1)

    # ── Step 3: Find latest checkpoint ───────────────────────────────────────
    checkpoint_info = _find_latest_checkpoint(job_id)
    if checkpoint_info:
        click.echo(f"  Checkpoint: step {checkpoint_info['step']} "
                    f"({checkpoint_info.get('size_label', '?')})")
    else:
        click.echo("  Checkpoint: none found — job will start from scratch")

    # ── Step 4: Check GPU availability ───────────────────────────────────────
    gpu_type = job_info.get("gpu_type", "")
    # Status API returns price_per_hr; DB rows use rate_per_hr
    rate = float(job_info.get("price_per_hr") or job_info.get("rate_per_hr") or 0)
    click.echo(f"  Rate: ${rate:.2f}/hr")
    click.echo("")

    # ── Step 5: Confirm ──────────────────────────────────────────────────────
    if not yes:
        if checkpoint_info:
            click.echo(f"  Resume training from step {checkpoint_info['step']}?")
        else:
            click.echo("  Restart training from scratch?")
        if not click.confirm("  Continue?", default=True):
            click.echo("  Cancelled.")
            raise SystemExit(0)

    # ── Step 6: Re-submit ────────────────────────────────────────────────────
    click.echo("")
    click.echo("  Restarting...")

    # Reconstruct command from status API fields (script_name + script_args)
    # or legacy DB field (command)
    _script_name = job_info.get("script_name", "")
    _script_args = job_info.get("script_args", "")
    command = job_info.get("command", "")
    if _script_name:
        command = f"python {_script_name} {_script_args}".strip()
    if not command:
        click.echo("  Error: No command found for this job. Cannot restart.")
        raise SystemExit(1)

    # Build the run command args
    _run_args = shlex.split(command)
    _gpu = gpu_type or "H100_80GB_SXM"
    _docker = job_info.get("docker_image", "")

    click.echo(f"  Command: {command}")
    click.echo(f"  GPU: {_gpu}")
    if checkpoint_info:
        click.echo(f"  Resuming from: step {checkpoint_info['step']}")
    click.echo("")

    # Execute via RunCommand — same as `vaultlayer run`
    try:
        import asyncio
        from cli.run import RunCommand
        runner = RunCommand(
            command=_run_args,
            job_name=job_info.get("job_name", "") or f"restart-{job_id[:8]}",
            gpu_type=_gpu,
            docker_image=_docker or "",
        )
        runner.job_id = job_id  # reuse the same job ID for continuity
        runner.yes = True
        runner._skip_preflight = True
        runner.vaultlayer_token = token
        runner.api_url = api_url
        runner.hourly_rate_usd = rate
        runner.resume_from_job_id = job_id
        # The resume hook auto-detects the checkpoint from R2 using job_id
        exit_code = asyncio.run(runner.execute())
        if isinstance(exit_code, int) and exit_code != 0:
            raise SystemExit(exit_code)
    except SystemExit:
        raise
    except KeyboardInterrupt:
        click.echo("\n  Interrupted.")
    except Exception as e:
        click.echo(f"  Error restarting: {e}")
        raise SystemExit(1)


def _fetch_job_info(job_id: str, token: str = "", api_url: str = "") -> dict | None:
    """Fetch job status via the managed API (no Supabase credentials needed)."""
    _token = token or os.environ.get("VAULTLAYER_TOKEN", "")
    _api = api_url or os.environ.get("VAULTLAYER_API_URL",
                                     "https://vaultlayer-production.up.railway.app")
    if not _token:
        return None
    try:
        import httpx
        resp = httpx.get(
            f"{_api}/api/v1/jobs/{job_id}/status",
            headers={"Authorization": f"Bearer {_token}"},
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.json()
        if resp.status_code == 404:
            return None
        logger.warning(f"[restart] API status check HTTP {resp.status_code} for job={job_id}")
        return None
    except Exception as e:
        logger.warning(f"[restart] API query failed: {e}")
        return None


def _check_balance(api_url: str, token: str) -> float | None:
    """Check available credit balance via API."""
    if not token:
        return None
    try:
        import httpx
        resp = httpx.get(
            f"{api_url}/api/v1/credits",
            headers={"Authorization": f"Bearer {token}"},
            timeout=8,
        )
        if resp.status_code == 200:
            data = resp.json()
            if "available_usd" in data and data["available_usd"] is not None:
                return float(data["available_usd"])
            return float(data.get("available_credits", 0)) / 100
    except Exception:
        pass
    return None


def _find_latest_checkpoint(job_id: str) -> dict | None:
    """Find the latest checkpoint for a job in R2."""
    try:
        from shared.r2_utils import get_r2_credentials
        _r2 = get_r2_credentials(job_id)
        _r2_endpoint = _r2.get("endpoint", "")
        _r2_key = _r2.get("access_key_id", "")
        _r2_secret = _r2.get("secret_access_key", "")
        _r2_bucket = _r2.get("bucket", "vaultlayer-checkpoints")

        if not all([_r2_endpoint, _r2_key, _r2_secret]):
            # Try reading the namespace manifest via Supabase (cheaper than listing R2)
            return _find_checkpoint_from_db(job_id)

        import boto3
        s3 = boto3.client("s3",
            endpoint_url=_r2_endpoint,
            aws_access_key_id=_r2_key,
            aws_secret_access_key=_r2_secret,
        )
        # List checkpoint step directories
        prefix = f"checkpoints/{job_id}/"
        resp = s3.list_objects_v2(Bucket=_r2_bucket, Prefix=prefix, Delimiter="/")
        prefixes = resp.get("CommonPrefixes", [])
        if not prefixes:
            return None

        # Parse step numbers, find latest. Support both HF checkpoint-N/ and
        # raw-PyTorch step-N/ layouts; preserve the actual directory name for
        # the size lookup because raw step dirs are not always zero-padded.
        steps: list[tuple[int, str]] = []
        for p in prefixes:
            dirname = p["Prefix"].rstrip("/").split("/")[-1]
            if dirname.startswith("checkpoint-"):
                try:
                    steps.append((int(dirname.replace("checkpoint-", "")), dirname))
                except ValueError:
                    pass
            elif dirname.startswith("step-"):
                try:
                    steps.append((int(dirname.replace("step-", "")), dirname))
                except ValueError:
                    pass

        if not steps:
            return None

        latest_step, latest_dir = max(steps, key=lambda item: item[0])
        # Estimate size from the step directory
        step_prefix = f"checkpoints/{job_id}/{latest_dir}/"
        size_resp = s3.list_objects_v2(Bucket=_r2_bucket, Prefix=step_prefix)
        total_bytes = sum(obj.get("Size", 0) for obj in size_resp.get("Contents", []))
        size_mb = total_bytes / (1024 * 1024)
        size_label = f"{size_mb:.0f} MB" if size_mb < 1024 else f"{size_mb/1024:.1f} GB"

        return {"step": latest_step, "size_bytes": total_bytes, "size_label": size_label}
    except Exception as e:
        logger.debug(f"[restart] R2 checkpoint lookup failed: {e}")
        return _find_checkpoint_from_db(job_id)


def _find_checkpoint_from_db(job_id: str) -> dict | None:
    """Fallback: check job state in Redis/DB for last_checkpoint field."""
    try:
        _su = os.environ.get("SUPABASE_URL", "")
        _sk = os.environ.get("SUPABASE_SERVICE_KEY", "")
        if not _su or not _sk:
            return None
        from supabase import create_client
        db = create_client(_su, _sk)
        # Check job_events for last checkpoint_saved event
        result = db.table("job_events").select(
            "metadata"
        ).eq("job_id", job_id).eq("event_type", "checkpoint_saved").order(
            "created_at", desc=True
        ).limit(1).execute()
        if result.data:
            meta = result.data[0].get("metadata", {})
            step = meta.get("step", 0)
            size = meta.get("size_bytes", 0)
            size_mb = size / (1024 * 1024) if size else 0
            size_label = f"{size_mb:.0f} MB" if size_mb < 1024 else f"{size_mb/1024:.1f} GB"
            return {"step": step, "size_bytes": size, "size_label": size_label}
    except Exception:
        pass
    return None
