"""`vaultlayer admin <subcommand>` — operator-only helpers.

Wraps the /api/v1/admin/* endpoints so the founder doesn't have to curl
every time. All commands read the admin token from VL_INTERNAL_ADMIN_TOKEN
(env var); if unset, the command aborts with a clear instruction rather
than leaking a failed request to the API.
"""
from __future__ import annotations

import json
import os
import sys

import click
import httpx


def _admin_token() -> str:
    tok = os.environ.get("VL_INTERNAL_ADMIN_TOKEN", "").strip()
    if not tok:
        click.echo(
            "  VL_INTERNAL_ADMIN_TOKEN not set. Export the admin token "
            "before running admin commands.",
            err=True,
        )
        sys.exit(1)
    return tok


def _api_url() -> str:
    return os.environ.get(
        "VAULTLAYER_API_URL",
        "https://vaultlayer-production.up.railway.app",
    ).rstrip("/")


@click.group(hidden=True)
def admin():
    """Admin-only operations (requires VL_INTERNAL_ADMIN_TOKEN)."""


@admin.command()
@click.argument("email")
@click.option("--credits", "credits_cents", default=1000, show_default=True,
              help="Initial credit grant in cents ($10 = 1000)")
@click.option("--note", default=None, help="Memo stored with the invite (admin-facing)")
def invite(email: str, credits_cents: int, note: str | None):
    """Generate an invite token for EMAIL and print it.

    Pipe the output into your email client. The plaintext token is only
    shown ONCE — if you lose it, revoke and re-issue.
    """
    url = f"{_api_url()}/api/v1/admin/invites"
    try:
        r = httpx.post(
            url,
            headers={"X-Internal-Admin-Token": _admin_token()},
            json={
                "email": email,
                "credits_cents": credits_cents,
                "note": note,
            },
            timeout=15,
        )
    except httpx.HTTPError as e:
        click.echo(f"  Could not reach API: {e}", err=True)
        sys.exit(1)

    if r.status_code == 404:
        click.echo(
            "  API returned 404 — admin token invalid, or admin endpoints "
            "disabled on the server.",
            err=True,
        )
        sys.exit(1)
    if r.status_code == 409:
        click.echo(
            f"  An active invite already exists for {email}. "
            f"Revoke it (not yet supported in CLI — use DB directly) "
            f"before re-issuing.",
            err=True,
        )
        sys.exit(1)
    if r.status_code >= 400:
        try:
            detail = r.json().get("detail", r.text)
        except Exception:
            detail = r.text
        click.echo(f"  API error {r.status_code}: {detail}", err=True)
        sys.exit(1)

    data = r.json()
    click.echo("")
    click.echo(f"  ✓ Invite issued for {data['email']}")
    click.echo(f"    credits:       {data['credits_cents']}¢ (${data['credits_cents']/100:.2f})")
    click.echo(f"    invite_id:     {data['invite_id']}")
    click.echo("")
    click.echo("  Token (copy the line below and email to the user):")
    click.echo("")
    click.echo(f"    {data['invite_token']}")
    click.echo("")
    click.echo("  Suggested email template:")
    click.echo("")
    click.echo(f"    Subject: Your VaultLayer beta invite")
    click.echo(f"    ")
    click.echo(f"    Hey — here's your VaultLayer beta invite.")
    click.echo(f"    ")
    click.echo(f"    Run:")
    click.echo(f"        pip install vaultlayer")
    click.echo(f"        vaultlayer init")
    click.echo(f"    ")
    click.echo(f"    When prompted, paste this token:")
    click.echo(f"        {data['invite_token']}")
    click.echo(f"    ")
    click.echo(f"    You've got {data['credits_cents']/100:.0f}$ of credit to play with.")
    click.echo("")


@admin.group(name="invites")
def invites_group():
    """Manage existing invites (list, revoke)."""


@invites_group.command(name="list")
@click.option("--status", "status_filter", default=None,
              type=click.Choice(["open", "redeemed", "revoked"]),
              help="Filter by status (default: all)")
@click.option("--limit", default=50, show_default=True,
              help="Max invites to return (1..200)")
def invites_list(status_filter: str | None, limit: int):
    """List invites you've issued."""
    url = f"{_api_url()}/api/v1/admin/invites"
    params = {}
    if status_filter:
        params["status_filter"] = status_filter
    if limit:
        params["limit"] = limit
    try:
        r = httpx.get(
            url,
            headers={"X-Internal-Admin-Token": _admin_token()},
            params=params,
            timeout=15,
        )
    except httpx.HTTPError as e:
        click.echo(f"  Could not reach API: {e}", err=True)
        sys.exit(1)

    if r.status_code >= 400:
        try:
            detail = r.json().get("detail", r.text)
        except Exception:
            detail = r.text
        click.echo(f"  API error {r.status_code}: {detail}", err=True)
        sys.exit(1)

    body = r.json()
    if body["count"] == 0:
        click.echo("  (no invites)")
        return
    click.echo(f"\n  {body['count']} invite(s):\n")
    for inv in body["invites"]:
        state = (
            "REVOKED"  if inv.get("revoked_at")
            else "REDEEMED" if inv.get("redeemed_at")
            else "OPEN"
        )
        click.echo(
            f"    [{state:<8}] {inv['email']:<32} "
            f"{inv['credits_cents']/100:>6.2f}$  "
            f"{inv['token_prefix']}  "
            f"id={inv['invite_id'][:8]}  "
            f"created={inv['created_at'][:10]}"
        )
    click.echo("")


@invites_group.command(name="revoke")
@click.argument("invite_id")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def invites_revoke(invite_id: str, yes: bool):
    """Revoke an outstanding invite by ID. Irreversible."""
    if not yes:
        click.confirm(
            f"Revoke invite {invite_id}? This permanently invalidates the token.",
            abort=True,
        )
    url = f"{_api_url()}/api/v1/admin/invites/{invite_id}/revoke"
    try:
        r = httpx.post(
            url,
            headers={"X-Internal-Admin-Token": _admin_token()},
            timeout=15,
        )
    except httpx.HTTPError as e:
        click.echo(f"  Could not reach API: {e}", err=True)
        sys.exit(1)

    if r.status_code == 404:
        click.echo("  Invite not found.", err=True)
        sys.exit(1)
    if r.status_code == 409:
        click.echo(
            "  Invite already redeemed — revoking the invite doesn't "
            "disable the user account. Use user-level deactivation instead.",
            err=True,
        )
        sys.exit(1)
    if r.status_code >= 400:
        try:
            detail = r.json().get("detail", r.text)
        except Exception:
            detail = r.text
        click.echo(f"  API error {r.status_code}: {detail}", err=True)
        sys.exit(1)

    body = r.json()
    if body.get("already_revoked"):
        click.echo(f"  Invite was already revoked on {body.get('revoked_at')}.")
    else:
        click.echo(f"  ✓ Invite revoked at {body.get('revoked_at')}.")
