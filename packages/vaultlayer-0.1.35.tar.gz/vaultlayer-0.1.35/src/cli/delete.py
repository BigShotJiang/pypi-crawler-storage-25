"""
VaultLayer CLI -- vaultlayer delete-job / rotate-key
GDPR-compliant data deletion with multiple safeguards.

Safeguards on delete-job:
  1. --confirm flag required (no accidental deletion from typos)
  2. Interactive prompt listing exactly what will be deleted
  3. Type-to-confirm: user must retype the job ID
  4. Running job check: blocks deletion if job is still running
  5. Dry-run flag: preview objects that would be deleted
  6. User namespace scoping: cannot delete another users checkpoints
  7. Audit log record written on every deletion

Usage:
    vaultlayer delete-job --job-id <id> --dry-run
    vaultlayer delete-job --job-id <id> --confirm
"""
import asyncio
import click
from pathlib import Path


@click.command("delete-job")
@click.option("--job-id", required=True, help="Job ID to delete all data for")
@click.option("--user", default=None, envvar="VAULTLAYER_USER_ID", hidden=True,
              help="User ID (RBAC namespace). Defaults to VAULTLAYER_USER_ID env var.")
@click.option("--confirm", is_flag=True, default=False,
              help="Skip interactive prompt (use in scripts). Still requires type-to-confirm.")
@click.option("--dry-run", is_flag=True, default=False,
              help="Preview what would be deleted without deleting anything.")
@click.option("--force", is_flag=True, default=False, hidden=True,
              help="Skip type-to-confirm check. Use only in automated pipelines.")
def delete_job(job_id, user, confirm, dry_run, force):
    """Delete all saved data for a job."""
    asyncio.run(_delete_job(job_id, user or "default", confirm, dry_run, force))


async def _delete_job(job_id: str, user_id: str, confirm: bool, dry_run: bool, force: bool):
    # -- Step 1: Load config + connect --
    try:
        from dotenv import load_dotenv
        env_file = Path.home() / ".vaultlayer" / "config.env"
        if env_file.exists(): load_dotenv(env_file)
        if Path(".env").exists(): load_dotenv(".env")
        from shared.config import load_config
        from shared.queue import AgentQueue
        from agents.vault.r2 import R2Client
        from shared.security import get_audit
        import json
        config = load_config()
        r2 = R2Client(
            endpoint=config.cloudflare.r2_endpoint,
            access_key_id=config.cloudflare.r2_access_key_id,
            secret_access_key=config.cloudflare.r2_secret_access_key,
            bucket=config.cloudflare.r2_bucket,
        )
    except Exception as e:
        click.echo(f"  Error: {e}"); raise

    # -- Step 2: Running job check --
    queue = AgentQueue(config.redis.url)
    await queue.connect()
    try:
        redis = queue._redis
        job_key = f"vaultlayer:job:{user_id}:{job_id}"
        raw = await redis.get(job_key)
        if raw:
            try:
                state = json.loads(raw)
                status = state.get("status", "unknown")
                if status == "running":
                    click.echo("")
                    click.echo(f"  [BLOCKED] Job {job_id} is currently RUNNING.")
                    click.echo(f"  Stop the job first before deleting its data.")
                    click.echo(f"  If the job is stuck, wait for it to complete or fail.")
                    click.echo("")
                    await queue.disconnect()
                    return
            except Exception:
                pass
    finally:
        pass  # disconnect after dry-run check below

    # -- Step 3: Dry-run preview --
    checkpoint_prefix = f"checkpoints/{job_id}/"
    all_objects = r2.list_all_objects(checkpoint_prefix)

    if dry_run:
        click.echo("")
        click.echo(f"  [DRY RUN] Would delete for job: {job_id} (user: {user_id})")
        click.echo(f"  R2 objects ({len(all_objects)}):")
        for obj in all_objects[:10]:
            click.echo(f"    {obj}")
        if len(all_objects) > 10:
            click.echo(f"    ... and {len(all_objects)-10} more")
        click.echo(f"  Redis key: {job_key}")
        click.echo("")
        click.echo(f"  Nothing deleted. Run with --confirm to proceed.")
        click.echo("")
        await queue.disconnect()
        return

    # -- Step 4: Interactive confirmation --
    if not confirm:
        click.echo("")
        click.echo(f"  This will permanently delete:")
        click.echo(f"    R2 checkpoints : {len(all_objects)} object(s) under checkpoints/{job_id}/")
        click.echo(f"    Redis state    : key {job_key}")
        click.echo(f"  This action CANNOT be undone.")
        click.echo("")
        if not click.confirm("  Continue?"):
            click.echo("  Aborted.")
            await queue.disconnect()
            return

    # -- Step 5: Type-to-confirm (unless --force) --
    if not force:
        click.echo("")
        typed = click.prompt(f"  Type the job ID to confirm deletion ({job_id})")
        if typed.strip() != job_id:
            click.echo(f"  Confirmation failed: you typed {typed!r}, expected {job_id!r}")
            click.echo(f"  Aborted. Nothing was deleted.")
            await queue.disconnect()
            return

    # -- Step 6: Execute deletion --
    click.echo("")
    click.echo(f"  Deleting R2 checkpoints for {job_id} (user: {user_id})...")
    deleted_count = r2.delete_job_checkpoints(job_id, user_id=user_id)
    click.echo(f"  Deleted {deleted_count} checkpoint object(s) from R2")

    click.echo(f"  Removing job state from Redis...")
    try:
        keys_deleted = 0
        for pattern in [f"vaultlayer:job:{user_id}:{job_id}",
                        f"vaultlayer:job:{user_id}:{job_id}:*"]:
            keys = await redis.keys(pattern)
            if keys:
                await redis.delete(*keys)
                keys_deleted += len(keys)
        click.echo(f"  Removed {keys_deleted} Redis key(s)")
    finally:
        await queue.disconnect()

    # -- Step 7: Audit log --
    get_audit().record("job_deleted", resource=f"job:{user_id}:{job_id}",
                       detail=f"r2_objects={deleted_count} redis_keys={keys_deleted}")

    click.echo("")
    click.echo(f"  Job {job_id} fully deleted. Audit record written.")
    click.echo("")


@click.command("rotate-key", hidden=True)
@click.option("--new-key", required=True,
              help='New encryption key. Generate: python -c "import secrets; print(secrets.token_urlsafe(32))"')
@click.option("--job-id", default=None, help="Re-encrypt only this job. Default: all jobs.")
@click.option("--user", default=None, envvar="VAULTLAYER_USER_ID",
              help="Limit rotation to this user namespace.")
@click.option("--confirm", is_flag=True, default=False)
@click.option("--dry-run", is_flag=True, default=False,
              help="Count objects without re-encrypting.")
def rotate_key(new_key, job_id, user, confirm, dry_run):
    """Re-encrypt all checkpoints with a new AES-256-GCM key."""
    from cli._preflight import require_admin_token
    require_admin_token()
    asyncio.run(_rotate_key(new_key, job_id, user or "default", confirm, dry_run))


async def _rotate_key(new_key: str, job_id_filter, user_id: str, confirm: bool, dry_run: bool):
    if not dry_run and not confirm:
        click.echo("  Use --dry-run to count objects, or --confirm to execute.")
        return
    try:
        from dotenv import load_dotenv
        env_file = Path.home() / ".vaultlayer" / "config.env"
        if env_file.exists(): load_dotenv(env_file)
        if Path(".env").exists(): load_dotenv(".env")
        from shared.config import load_config
        from shared.security import CheckpointEncryption, get_audit
        from agents.vault.r2 import R2Client
        config = load_config()
        old_enc = CheckpointEncryption()
        new_enc = CheckpointEncryption(master_key=new_key)
        r2 = R2Client(
            endpoint=config.cloudflare.r2_endpoint,
            access_key_id=config.cloudflare.r2_access_key_id,
            secret_access_key=config.cloudflare.r2_secret_access_key,
            bucket=config.cloudflare.r2_bucket,
        )
        prefix = f"checkpoints/{job_id_filter}/" if job_id_filter else "checkpoints/"
        all_keys = r2.list_all_objects(prefix)
        click.echo(f"  Found {len(all_keys)} object(s) under {prefix}")
        if dry_run:
            click.echo(f"  Dry run complete. Run with --confirm to re-encrypt.")
            return
        rotated, errors = 0, 0
        for key in all_keys:
            try:
                data = r2._s3.get_object(Bucket=r2.bucket, Key=key)["Body"].read()
                plaintext = old_enc.decrypt(data)
                re_enc = new_enc.encrypt(plaintext)
                r2._s3.put_object(Bucket=r2.bucket, Key=key, Body=re_enc,
                                  ContentType="application/octet-stream",
                                  ServerSideEncryption="AES256")
                rotated += 1
                click.echo(f"  [{rotated}/{len(all_keys)}] Rotated: {key}")
            except Exception as e:
                click.echo(f"  [WARN] {key}: {e}"); errors += 1
        get_audit().record("key_rotated", detail=f"objects={rotated} errors={errors}")
        click.echo("")
        click.echo(f"  Key rotation complete: {rotated} rotated, {errors} errors")
        click.echo(f"  Now update VAULTLAYER_ENCRYPTION_KEY to the new key.")
        click.echo("")
    except Exception as e:
        click.echo(f"  Error: {e}"); raise
