"""
vaultlayer data commands — datasets listing and region queries.

Extracted from main.py to keep the CLI entry point manageable.
"""
import os
from pathlib import Path

import click


# ── datasets command ──────────────────────────────────────────────────────────

@click.command(name="datasets")
@click.option("--delete", default=None, metavar="DATASET_ID",
              help="Delete a dataset (cannot be undone).")
def datasets(delete):
    """List uploaded datasets.

    \b
    Upload a dataset:
        vaultlayer sync ./data --dataset-id my-dataset
    Use in training:
        vaultlayer run --data r2://my-dataset python train.py
    """
    from cli.main import _load_token, _api_url
    import httpx as _httpx
    _token = os.environ.get("VAULTLAYER_TOKEN", "") or _load_token()
    _api = _api_url()

    if delete:
        click.confirm(
            f"Delete dataset '{delete}'? This cannot be undone and will "
            f"stop billing for this dataset.",
            abort=True,
        )
        try:
            resp = _httpx.delete(
                f"{_api}/api/v1/datasets/{delete}",
                headers={"Authorization": f"Bearer {_token}"},
                timeout=10,
            )
            if resp.status_code in (200, 204):
                click.echo(f"  Dataset '{delete}' marked for deletion. "
                           f"Files will be purged within 24 hours.")
            else:
                click.echo(f"  Delete failed: {resp.text}", err=True)
        except Exception as e:
            click.echo(f"  Delete failed: {e}", err=True)
        return

    try:
        resp = _httpx.get(
            f"{_api}/api/v1/datasets",
            headers={"Authorization": f"Bearer {_token}"},
            timeout=10,
        )
        resp.raise_for_status()
        rows = resp.json().get("datasets", [])
    except _httpx.HTTPError as e:
        click.echo(f"  Could not fetch datasets: {e}", err=True)
        return

    if not rows:
        click.echo("\n  No datasets found.")
        click.echo("  Upload one with: vaultlayer sync ./data --dataset-id my-dataset\n")
        return

    total_gb = sum(r.get("total_bytes", 0) for r in rows) / 1e9
    total_cost = sum(float(r.get("monthly_cost_usd", 0)) for r in rows)

    click.echo(f"\n  {'DATASET ID':<28} {'NAME':<20} {'SIZE':>9} {'$/mo':>7}  {'SOURCE':<10}  LAST SYNCED")
    click.echo(f"  {'-'*28} {'-'*20} {'-'*9} {'-'*7}  {'-'*10}  {'-'*19}")
    for r in rows:
        gb = r.get("total_bytes", 0) / 1e9
        cost = float(r.get("monthly_cost_usd", 0))
        synced = (r.get("last_synced_at") or "")[:10]
        src = r.get("source_type", "local")
        click.echo(
            f"  {r['dataset_id']:<28} {r.get('name',''):<20} "
            f"{gb:>7.2f}GB {cost:>6.3f}  {src:<10}  {synced}"
        )

    click.echo(f"\n  Total: {total_gb:.2f} GB  —  ~${total_cost:.3f}/month")
    click.echo(f"\n  To delete a dataset:  vaultlayer datasets --delete <dataset-id>\n")


# ── regions command group ─────────────────────────────────────────────────────

# All routable GPU regions — loaded from config/vaultlayer_data.json:routable_regions
def _load_aws_gpu_regions() -> list[tuple[str, str, str]]:
    from shared.data_loader import get_routable_regions
    return [(r["code"], r["location"], r["gpus"]) for r in get_routable_regions()]

_RESTRICTED_REGIONS = {
    "cn-north-1":     "China (Beijing) — BIS export controls apply to H100/A100",
    "cn-northwest-1": "China (Ningxia) — BIS export controls apply to H100/A100",
    "us-gov-east-1":  "AWS GovCloud (US-East) — requires GovCloud account",
    "us-gov-west-1":  "AWS GovCloud (US-West) — requires GovCloud account",
    "ap-east-1":      "Asia Pacific (Hong Kong) — check BIS license for H100",
    "il-central-1":   "Israel (Tel Aviv) — OFAC screening recommended",
    "ru-central-1":   "Russia — OFAC sanctioned, provisioning blocked by default",
}


@click.group()
def regions():
    """Query available regions for provisioning."""
    pass


@regions.command(name="list-all")
def regions_list_all():
    """List all AWS regions where VaultLayer can provision GPU nodes.

    \b
    Regions marked with compliance notes require extra care:
      - GDPR: use eu-central-1 or eu-west-1 for EU personal data
      - BIS:  H100/A100 export to certain regions requires a US export license
      - OFAC: provisioning in sanctioned countries is blocked automatically
    """
    click.echo("\n  Available GPU regions:\n")
    click.echo(f"  {'REGION':<20} {'LOCATION':<35} {'GPU TYPES'}")
    click.echo(f"  {'-'*20} {'-'*35} {'-'*20}")
    for code, location, gpus in _load_aws_gpu_regions():
        click.echo(f"  {code:<20} {location:<35} {gpus}")

    click.echo("\n  Restricted / compliance-flagged regions:\n")
    click.echo(f"  {'REGION':<20} NOTE")
    click.echo(f"  {'-'*20} {'-'*55}")
    for code, note in _RESTRICTED_REGIONS.items():
        click.echo(f"  {code:<20} {note}")

    click.echo("\n  To restrict your job to specific regions:")
    click.echo("    vaultlayer run --regions eu-central-1,eu-west-1 python train.py")
    click.echo("  To exclude a region:")
    click.echo("    vaultlayer run --excluded-regions cn-north-1 python train.py\n")


@regions.command(name="current")
def regions_current():
    """Show the region VaultLayer will provision in with current credentials.

    \b
    The active region is read from AWS_DEFAULT_REGION env var or from your
    VaultLayer config (set during 'vaultlayer init').
    """
    env_file = Path.home() / ".vaultlayer" / "config.env"
    if env_file.exists():
        from dotenv import load_dotenv
        load_dotenv(env_file)

    region = None
    try:
        from shared.config import load_config
        config = load_config()
        region = config.aws.region
    except Exception:
        pass

    if not region:
        import os as _os
        region = _os.environ.get("AWS_DEFAULT_REGION") or _os.environ.get("AWS_REGION")

    if not region:
        click.echo("  Could not determine current region. "
                   "Run 'vaultlayer init' or set AWS_DEFAULT_REGION.", err=True)
        return

    # Find the human-readable name
    location = next((loc for code, loc, _ in _load_aws_gpu_regions() if code == region), "Unknown location")
    compliance_note = _RESTRICTED_REGIONS.get(region)

    click.echo(f"\n  Current region: {region}")
    click.echo(f"  Location:       {location}")
    if compliance_note:
        click.echo(f"\n  Compliance note: {compliance_note}", err=True)
    click.echo(f"\n  To provision in a different region, re-run 'vaultlayer init' with the new region,")
    click.echo(f"  or use --regions on a per-job basis.\n")
