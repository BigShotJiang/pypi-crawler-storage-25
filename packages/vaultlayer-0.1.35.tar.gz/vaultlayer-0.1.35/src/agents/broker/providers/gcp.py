"""GCP provider — provision + fence."""
from __future__ import annotations

import asyncio
import logging
import os
import time
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from shared.models import GPUType, Job

from shared.models import GPUType
from agents.broker.providers import gcp_capacity

logger = logging.getLogger(__name__)


def _extract_gcp_error_code(msg: str) -> str:
    """Pull a GCE error reason out of an exception message for cooldown matching.

    GCE googleapiclient errors render as '... with reason "QUOTA_EXCEEDED" ...'
    or include the code in a JSON blob. We just scan for known signatures so
    the planner doesn't have to parse JSON out of the exception string.
    """
    for code in gcp_capacity.COOLDOWN_ERROR_CODES:
        if code in msg:
            return code
    # Fall back to HTTP status hints
    if "403" in msg:
        return "FORBIDDEN"
    if "404" in msg:
        return "NOT_FOUND"
    return "UNKNOWN"


async def provision(broker, gpu_type: "GPUType", job: "Job") -> Optional[str]:
    """Provision a GCP Compute Engine instance with accelerator. Returns instance name or None."""
    gcp_cfg = broker.config.gcp
    _sa_info: Optional[dict] = None  # set when using managed credentials

    if not gcp_cfg:
        # No local BYOC config — fetch from Railway credential server.
        # Railway stores GCP creds as individual fields (not one JSON blob)
        # because the Railway UI truncates large env var values.
        # VL_GCP_CLIENT_EMAIL + VL_GCP_PRIVATE_KEY + VL_GCP_PROJECT_ID are
        # the three Railway vars; broker assembles the SA info dict here.
        _managed = await broker._get_managed_credentials("gcp", job.job_id)
        if not _managed:
            job.last_provision_error = "GCP: no credentials available (BYOC or managed)"
            logger.error("[broker] GCP credentials not available (BYOC or managed)")
            return None
        from types import SimpleNamespace
        # Reconstruct service_account_info from individual Railway fields
        _client_email = _managed.get("client_email", "")
        _private_key  = _managed.get("private_key", "").replace("\\n", "\n")
        _project_id   = _managed.get("project_id", "")
        if not (_client_email and _private_key and _project_id):
            job.last_provision_error = "GCP: managed creds incomplete (missing client_email, private_key, or project_id)"
            logger.error(
                "[broker] GCP managed creds incomplete — set VL_GCP_CLIENT_EMAIL, "
                "VL_GCP_PRIVATE_KEY, VL_GCP_PROJECT_ID in Railway Variables"
            )
            return None
        _sa_info = {
            "type":                        "service_account",
            "project_id":                  _project_id,
            "private_key_id":              "managed",
            "private_key":                 _private_key,
            "client_email":                _client_email,
            "client_id":                   "",
            "auth_uri":                    "https://accounts.google.com/o/oauth2/auth",
            "token_uri":                   "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_x509_cert_url":        f"https://www.googleapis.com/robot/v1/metadata/x509/{_client_email}",
        }
        gcp_cfg = SimpleNamespace(
            service_account_json=None,
            project_id=_project_id,
            region=_managed.get("region", "us-central1"),
            zone=_managed.get("zone", "us-central1-a"),
        )

    # GPU -> accelerator type + machine type
    #
    # A10G maps to n1-standard-4 (4 vCPU / 15 GB RAM) + T4. We previously
    # used n1-standard-8 here, but the vaultlayer-prod project has a
    # CPUS_ALL_REGIONS quota of 16 vCPUs — two concurrent n1-standard-8
    # jobs exhausted it and every subsequent insert silently failed async
    # with QUOTA_EXCEEDED. n1-standard-4 lets 4 concurrent T4 jobs fit
    # in the same quota, and T4 training workloads are GPU-bound rather
    # than CPU-bound so 4 vCPUs is ample.
    _GCP_ACCELERATORS: dict[GPUType, tuple[str, str]] = {
        GPUType.H100_80GB_SXM: ("nvidia-h100-80gb", "a3-highgpu-1g"),
        GPUType.A100_80GB_SXM: ("nvidia-tesla-a100", "a2-ultragpu-1g"),
        GPUType.A100_40GB:     ("nvidia-tesla-a100", "a2-highgpu-1g"),
        GPUType.A10G:          ("nvidia-tesla-t4",   "n1-standard-4"),
    }
    if gpu_type not in _GCP_ACCELERATORS:
        logger.error(f"GPU type {gpu_type} not supported on GCP")
        return None

    accel_type, machine_type = _GCP_ACCELERATORS[gpu_type]

    # VL_GCP_SKIP_ACCELERATOR=1 — CPU-only smoke escape hatch.
    #
    # When set, we map the requested GPU type to an e2-small (CPU-only,
    # free-tier eligible) and SKIP the guestAccelerators block in the
    # insert body. This lets us verify the full provisioning path
    # (credentials → zone ranking → insert → op-poll → hard_fence →
    # job_runs tracking) end-to-end on a real GCP project that doesn't
    # yet have GPU quota approved.
    #
    # Same design as AWS_INSTANCE_MAP monkey-patching in
    # scripts/aws_smoke_local.py — one env flag, one code branch, no
    # duplicate provisioning logic.
    #
    # Source order: job.environment > process env. Reading from
    # job.environment lets an operator trigger the CPU-only smoke per
    # submission without touching Railway env vars (especially useful
    # when GPUS_ALL_REGIONS quota is 0 pending approval — caught
    # 2026-04-20 when GCP denied the initial quota raise for 48h).
    _job_env = getattr(job, "environment", None) or {}
    _skip_raw = _job_env.get("VL_GCP_SKIP_ACCELERATOR") \
        or os.environ.get("VL_GCP_SKIP_ACCELERATOR", "")
    _skip_accelerator = str(_skip_raw).lower() in ("1", "true", "yes")
    if _skip_accelerator:
        machine_type = "e2-small"
        accel_type = None  # signals "no guestAccelerators block"
        logger.info(
            f"[GCP] VL_GCP_SKIP_ACCELERATOR=1 — provisioning {machine_type} "
            f"(CPU-only, no GPU attach) for smoke verification"
        )

    instance_name = f"vl-{job.job_id[:8]}-{gpu_type.value.split('_')[0].lower()}"
    primary_zone = gcp_cfg.zone

    try:
        import google.auth
        from google.oauth2 import service_account
        from googleapiclient import discovery
        import json as _json

        if _sa_info:
            # Managed path: JSON content came from Railway — use from_service_account_info
            creds = service_account.Credentials.from_service_account_info(
                _sa_info,
                scopes=["https://www.googleapis.com/auth/compute"],
            )
        else:
            # BYOC path: local file path
            creds = service_account.Credentials.from_service_account_file(
                gcp_cfg.service_account_json,
                scopes=["https://www.googleapis.com/auth/compute"],
            )
        compute = discovery.build("compute", "v1", credentials=creds)

        # Capacity-aware zone ranking — mirror of what AWS does.
        #
        # GCP quotas are per-region but instances launch per-zone, so we
        # fall back across zones. ZONE_RESOURCE_POOL_EXHAUSTED and
        # QUOTA_EXCEEDED both trigger a 10-min cooldown on the failing
        # zone; acceleratorTypes.list() drops zones that don't offer
        # the SKU at all (no more wasting an insert op on them).
        #
        # VL_GCP_ZONE_LOCKED=1 bypasses everything for strict pinning.
        _zone_locked = os.environ.get("VL_GCP_ZONE_LOCKED", "").lower() in ("1", "true", "yes")
        if _zone_locked or _skip_accelerator:
            # CPU-only smoke skips the acceleratorTypes.list pre-filter —
            # e2-small is offered in every zone, and we don't need GPU
            # supply confirmation for it.
            zones_to_try = [primary_zone]
            dropped: list[str] = []
            _reason = "VL_GCP_ZONE_LOCKED=1" if _zone_locked else "VL_GCP_SKIP_ACCELERATOR=1 (CPU-only)"
            logger.info(f"[GCP] {_reason} — single-zone provision on {primary_zone}")
        else:
            candidate_zones = gcp_capacity.zones_for_accelerator(accel_type)
            # Ensure primary_zone is a candidate even if not in hardcoded list
            if primary_zone and primary_zone not in candidate_zones:
                candidate_zones = [primary_zone] + candidate_zones
            zones_to_try, dropped = gcp_capacity.rank_zones(
                candidate_zones=candidate_zones,
                accel_type=accel_type,
                compute=compute,
                project_id=gcp_cfg.project_id,
                primary_zone=primary_zone,
            )
            if dropped:
                logger.info(f"[GCP] skipped zones (not offered / unreachable): {dropped}")
            if not zones_to_try:
                job.last_provision_error = (
                    f"GCP: no zone offers {accel_type} "
                    f"(checked {candidate_zones}; dropped {dropped})"
                )
                logger.error(job.last_provision_error)
                return None
            # Budget cap: the broker's outer wait_for is 150s, and a
            # single-zone attempt can cost up to 25s (5s insert + 20s
            # zoneOperations.get poll). T4 has 22 candidate zones and
            # A100 has 10 — fully iterating either blows past the 150s
            # outer cap and the worker cancels _try_provision mid-flight
            # (seen 2026-04-20 on jobs 44e3a52b / 78ca840c). rank_zones
            # returns zones ordered by cooldown+preference, so top 5 is
            # the best-chance subset. 5 × 25s = 125s fits under 150s.
            # If none of the top 5 have capacity, the planner's 10-min
            # cooldown will have filtered out that region by the time a
            # user retries — giving the 6th+ zones a real shot on the
            # next attempt.
            _ZONE_TRY_CAP = 5
            if len(zones_to_try) > _ZONE_TRY_CAP:
                logger.info(
                    f"[GCP] {len(zones_to_try)} viable zones for {accel_type}; "
                    f"capping to top {_ZONE_TRY_CAP} to fit the worker's 150s "
                    f"wait_for budget. Dropped tail: {zones_to_try[_ZONE_TRY_CAP:]}"
                )
                zones_to_try = zones_to_try[:_ZONE_TRY_CAP]
            logger.info(
                f"[GCP] provision ordering for {accel_type}: {zones_to_try} "
                f"(primary={primary_zone})"
            )

        # Boot image: plain Ubuntu 22.04 LTS (NOT the "accelerator" variant).
        #
        # Why not ubuntu-accelerator-2204-amd64-with-nvidia-580?
        # 2026-04-19 smoke jobs (caad81a0, 82e558aa, d22638c8, 0a2dcde6)
        # all provisioned fine on that image and billed the full 20-min
        # stuck-detector window but produced ZERO serial-console output —
        # not even BIOS / kernel boot messages. GCP support confirmed this
        # pattern points to hypervisor-level or image-level boot failure
        # (their own explicit mitigation #2: "try a plain Ubuntu 22.04 LTS
        # image without accelerator/NVIDIA additions"). Swapping to plain
        # ubuntu-2204-lts + installing the driver ourselves via apt is the
        # same pattern we already use on every other VM provider.
        #
        # shieldedInstanceConfig.enableSecureBoot=false is load-bearing:
        # nvidia-driver-* via apt uses DKMS to build the kernel module at
        # install time; DKMS modules aren't signed, so Secure Boot blocks
        # them unless an MOK key is enrolled (interactive, can't do from
        # startup-script). Turning Secure Boot off is the simplest fix.
        #
        # Driver install itself happens in build_vm_startup_script under
        # the VL_GCP_NEEDS_DRIVER_INSTALL=1 gate so the bootstrap chain
        # stays provider-agnostic. Remove the old VL_GCP_GPU_WAIT gate
        # (that was for activating pre-installed driver modules on the
        # accelerator image — no longer relevant on plain Ubuntu).
        # Filter zones_to_try against job placement constraints.
        # GCP zones are "{region}-{suffix}" — "us-central1-a" → region "us-central1".
        # Job.regions is a whitelist; job.excluded_regions is a blacklist.
        _job_regions = list(getattr(job, "regions", None) or [])
        _job_excl_regions = set(getattr(job, "excluded_regions", None) or [])
        if _job_regions or _job_excl_regions:
            _zone_constraint_dropped: list[str] = []
            _zone_filtered: list[str] = []
            for _z in zones_to_try:
                _z_region = _z.rsplit("-", 1)[0]  # "us-central1-a" → "us-central1"
                if _z_region in _job_excl_regions:
                    _zone_constraint_dropped.append(_z)
                elif _job_regions and _z_region not in _job_regions:
                    _zone_constraint_dropped.append(_z)
                else:
                    _zone_filtered.append(_z)
            if _zone_constraint_dropped:
                logger.info(
                    f"[GCP] dropped zones {_zone_constraint_dropped} — violate job "
                    f"placement constraints (regions={_job_regions}, "
                    f"excluded={list(_job_excl_regions)})"
                )
            zones_to_try = _zone_filtered
            if not zones_to_try:
                job.last_provision_error = (
                    "GCP: no zone satisfies job placement constraints "
                    f"(regions={_job_regions}, excluded={list(_job_excl_regions)})"
                )
                logger.error(job.last_provision_error)
                return None

        if not _skip_accelerator:
            (job.environment or {}).setdefault("VL_GCP_NEEDS_DRIVER_INSTALL", "1")

        # Per-zone try loop. Each iteration attempts one zone:
        #   1. instances.insert — sync call returns an Operation immediately
        #   2. zoneOperations.get polled for up to 20s to catch async failures
        #      (QUOTA_EXCEEDED, ZONE_RESOURCE_POOL_EXHAUSTED, etc.)
        # On a cooldown-worthy failure, gcp_capacity.record_failure() puts
        # the zone into 10-min cooldown and we try the next one.
        per_zone_errors: list[str] = []
        for zone in zones_to_try:
            # CPU-only smoke uses a plain Debian image (no NVIDIA driver
            # needed); GPU path uses plain Ubuntu 22.04 LTS and the driver
            # is apt-installed by build_vm_startup_script.
            _source_image = (
                "projects/debian-cloud/global/images/family/debian-12"
                if _skip_accelerator
                else "projects/ubuntu-os-cloud/global/images/family/ubuntu-2204-lts"
            )
            # CPU-only smoke gets 40 GB (enough to docker pull our 8.1 GB
            # training-base:1.0 with overlay overhead + apt cache; previous 10 GB
            # boot disk ran out mid-pull with "no space left on device" on
            # job a90d53d3 2026-04-20 — containerd ingest for layer sha256:22ba0fb
            # aborted ~60% through). GPU path gets 200 GB — model + dataset +
            # checkpoints easily exceed 40 GB.
            _disk_size = "40" if _skip_accelerator else str(
                max(200, int(getattr(job, "disk_gb", 200) or 200))
            )
            body = {
                "name": instance_name,
                "machineType": f"zones/{zone}/machineTypes/{machine_type}",
                "disks": [{
                    "boot": True,
                    "autoDelete": True,
                    "initializeParams": {
                        "sourceImage": _source_image,
                        "diskSizeGb": _disk_size,
                    },
                }],
                "networkInterfaces": [{"accessConfigs": [{"type": "ONE_TO_ONE_NAT"}]}],
                # Secure Boot MUST be off for GPU path: `apt-get install
                # nvidia-driver-535` compiles the kernel module via DKMS,
                # and unsigned DKMS modules are rejected by Secure Boot
                # without an enrolled MOK key (which we can't set up from
                # a non-interactive startup-script). Leave defaults in
                # place for CPU-only smoke (_skip_accelerator=True).
                **({"shieldedInstanceConfig": {
                    "enableSecureBoot": False,
                    "enableVtpm": True,
                    "enableIntegrityMonitoring": True,
                }} if not _skip_accelerator else {}),
                # guestAccelerators is the canonical GCE REST API field name
                # for attaching discrete GPUs to N1 VMs. "accelerators" is
                # silently accepted but doesn't attach the GPU (every prior
                # "successful" smoke ran CPU-only with `modprobe: No such
                # device`; confirmed 2026-04-17 debug job 1618568d).
                # Source: https://docs.cloud.google.com/compute/docs/reference/
                #         rest/v1/instances#Instance.FIELDS.guest_accelerators
                **({"guestAccelerators": [{
                    "acceleratorType": f"zones/{zone}/acceleratorTypes/{accel_type}",
                    "acceleratorCount": 1,
                }]} if not _skip_accelerator else {}),
                # provisioningModel=SPOT is the modern GCE spot flag (superseded
                # the legacy preemptible:true which capped at 24h).
                # onHostMaintenance MUST be TERMINATE for any GPU instance.
                "scheduling": {
                    "onHostMaintenance": "TERMINATE",
                    "provisioningModel": "SPOT",
                },
                "metadata": {
                    "items": [
                        {"key": "VAULTLAYER_JOB_ID", "value": job.job_id},
                        {"key": "startup-script", "value": broker._build_vm_startup_script(job)},
                    ],
                },
                "labels": {
                    "vaultlayer-job": job.job_id[:63].lower().replace("_", "-"),
                    "managed-by": "vaultlayer",
                },
            }

            # IDEM-1: GCP's requestId query param makes instances.insert
            # idempotent — if the broker crashes between request and
            # response, retry with the same requestId returns the cached
            # operation instead of creating a duplicate VM. requestId must
            # be a non-zero UUIDv4. See docs/IDEM1_PROVIDER_KEYS.md.
            from shared.idempotency import provision_idempotency_key
            _attempts = (job.get("_provision_attempts") if isinstance(job, dict)
                         else getattr(job, "_provision_attempts", None)) or []
            _req_id = provision_idempotency_key(
                f"{job.job_id if hasattr(job, 'job_id') else job.get('job_id')}:gcp:{zone}",
                len(_attempts) + 1,
            )
            try:
                op = compute.instances().insert(
                    project=gcp_cfg.project_id, zone=zone, body=body,
                    requestId=_req_id,
                ).execute()
                logger.info(f"[GCP] {zone}: instance create op: {op.get('name')}")
                if _sa_info:
                    broker._gcp_sa_info[instance_name] = {
                        "sa_info": _sa_info,
                        "project_id": gcp_cfg.project_id,
                        "zone": zone,
                    }
            except Exception as _insert_err:
                _msg = str(_insert_err)
                if "alreadyExists" in _msg or "409" in _msg:
                    logger.warning(f"GCP instance {instance_name} already exists, reusing it")
                    return instance_name
                # Sync-insert failure — could be auth, project-wide quota, etc.
                _code = _extract_gcp_error_code(_msg)
                per_zone_errors.append(f"{zone}:{_code}")
                gcp_capacity.record_failure(zone, _code)
                if zone != zones_to_try[-1] and _code in gcp_capacity.COOLDOWN_ERROR_CODES:
                    logger.warning(
                        f"[GCP] {zone}: insert failed ({_code}), trying next zone"
                    )
                    continue
                job.last_provision_error = (
                    f"GCP: insert failed in {zone}: {_code}: {_msg[:150]} "
                    f"[zones tried: {', '.join(per_zone_errors)}]"
                )
                logger.error(f"GCP provision error in {zone}: {_insert_err}")
                return None

            # Poll the Operation briefly to catch ASYNC failures
            # (QUOTA_EXCEEDED / ZONE_RESOURCE_POOL_EXHAUSTED land here).
            _op_name = op.get("name")
            _op_deadline = time.monotonic() + 20
            _async_err_code: Optional[str] = None
            _async_err_msg: Optional[str] = None
            while time.monotonic() < _op_deadline:
                try:
                    op_status = compute.zoneOperations().get(
                        project=gcp_cfg.project_id, zone=zone, operation=_op_name
                    ).execute()
                    if op_status.get("status") == "DONE":
                        _op_err = op_status.get("error")
                        if _op_err:
                            _err_items = _op_err.get("errors", [])
                            _async_err_code = (
                                _err_items[0].get("code", "UNKNOWN") if _err_items else "UNKNOWN"
                            )
                            _async_err_msg = (
                                _err_items[0].get("message", "no message")
                                if _err_items else "no error detail"
                            )
                            break
                        # DONE with no error — instance created successfully
                        return instance_name
                except Exception as e:
                    logger.debug(f"GCP op poll transient error for {_op_name}: {e}")
                await asyncio.sleep(2)

            if _async_err_code is not None:
                per_zone_errors.append(f"{zone}:{_async_err_code}")
                gcp_capacity.record_failure(zone, _async_err_code)
                broker._gcp_sa_info.pop(instance_name, None)
                if zone != zones_to_try[-1] and _async_err_code in gcp_capacity.COOLDOWN_ERROR_CODES:
                    logger.warning(
                        f"[GCP] {zone}: insert op failed async ({_async_err_code}), trying next zone"
                    )
                    continue
                job.last_provision_error = (
                    f"GCP: insert op failed in {zone}: {_async_err_code}: "
                    f"{(_async_err_msg or '')[:150]} "
                    f"[zones tried: {', '.join(per_zone_errors)}]"
                )
                logger.error(
                    f"GCP insert op {_op_name} failed async: {_async_err_code}: {_async_err_msg}"
                )
                return None

            # Op still PENDING/RUNNING after 20s — legitimate cold boot.
            # Return the instance name; monitor loop takes over.
            logger.info(
                f"[GCP] {zone}: op {_op_name} still running after 20s — "
                f"returning instance_name, monitor loop will track boot"
            )
            return instance_name

        # Exhausted all zones
        job.last_provision_error = (
            f"GCP: all zones exhausted [{', '.join(per_zone_errors)}]"
        )
        logger.error(f"[GCP] All zones exhausted for job {job.job_id}: {per_zone_errors}")
        return None

    except ImportError:
        job.last_provision_error = "GCP: google-api-python-client not installed"
        from shared.failure_codes import JobFailureCode
        job.failure_code = JobFailureCode.PROV_AUTH_BAD.value
        job.failure_detail = "google-api-python-client not installed on API deploy"
        logger.error("google-api-python-client not installed. Run: pip install google-api-python-client google-auth")
        return None
    except Exception as e:
        # Catch-all: tag with UNKNOWN so dashboards count it, with full type
        # + message in failure_detail for triage. Every recurring UNKNOWN
        # over time should motivate a more specific code in
        # src/shared/failure_codes.py.
        from shared.failure_codes import JobFailureCode
        job.last_provision_error = f"GCP: {type(e).__name__}: {str(e)[:150]}"
        job.failure_code = JobFailureCode.UNKNOWN.value
        job.failure_detail = f"GCP provision raised {type(e).__name__}: {str(e)[:400]}"
        logger.error(f"GCP provision error: {e}")
        return None


async def hard_fence(broker, instance_id: str, job=None) -> None:
    """Delete a GCP Compute Engine instance via API and poll until deleted.

    Credential resolution order:
      1. In-process cache from provision_gcp (broker._gcp_sa_info).
         Fastest path, covers same-process lifecycle.
      2. BYOC config file (broker.config.gcp.service_account_json).
      3. Managed env vars via _read_provider_credentials("gcp").
         Critical fallback: the in-process cache is wiped on every
         Railway redeploy, which used to leak GCE instances that
         were provisioned before the redeploy (manually cleaned up
         vl-ccd98f81-a10g and vl-fc6a607c-a10g on 2026-04-17 — both
         were stuck for 7h+ consuming the CPUS_ALL_REGIONS quota).
    """
    _cached = broker._gcp_sa_info.get(instance_id)
    try:
        from google.oauth2 import service_account
        from googleapiclient import discovery

        if _cached:
            # Managed-credentials path: use cached SA info from provision
            creds = service_account.Credentials.from_service_account_info(
                _cached["sa_info"],
                scopes=["https://www.googleapis.com/auth/compute"],
            )
            _project_id = _cached["project_id"]
            _zone = _cached["zone"]
        elif broker.config.gcp and getattr(broker.config.gcp, "service_account_json", ""):
            gcp_cfg = broker.config.gcp
            creds = service_account.Credentials.from_service_account_file(
                gcp_cfg.service_account_json,
                scopes=["https://www.googleapis.com/auth/compute"],
            )
            _project_id = gcp_cfg.project_id
            _zone = gcp_cfg.zone
        else:
            # Fallback: reconstruct SA info from VL_GCP_* env vars. The
            # in-process cache is gone (likely post-redeploy); fetch
            # managed creds inline. This eliminates the prior leak where
            # GCE VMs provisioned before a Railway redeploy became
            # unfenceable in-process.
            from api.credentials import _read_provider_credentials
            managed = _read_provider_credentials("gcp")
            if not managed:
                raise RuntimeError(
                    f"GCP fence: no credentials available (no cache, no BYOC, "
                    f"no VL_GCP_* env) for {instance_id}"
                )
            sa_info = {
                "type":         "service_account",
                "project_id":   managed["project_id"],
                "private_key":  managed["private_key"].replace("\\n", "\n"),
                "client_email": managed["client_email"],
                "token_uri":    "https://oauth2.googleapis.com/token",
            }
            creds = service_account.Credentials.from_service_account_info(
                sa_info, scopes=["https://www.googleapis.com/auth/compute"],
            )
            _project_id = managed["project_id"]
            # Prefer the job's zone if available, fall back to env-configured
            # zone. Instance names don't encode zone, so when we lose context
            # we must trust either a job hint or the default.
            _zone = (
                getattr(job, "zone", None)
                or managed.get("zone", "")
                or "us-central1-a"
            )
            logger.info(
                f"[Broker] GCP fence using rebuilt managed creds for {instance_id} "
                f"(project={_project_id}, zone={_zone})"
            )

        compute = discovery.build("compute", "v1", credentials=creds)
        # instance_id is the instance name for GCP
        op = compute.instances().delete(
            project=_project_id,
            zone=_zone,
            instance=instance_id,
        ).execute()
        logger.info(f"[Broker] GCP delete issued for {instance_id}, op={op.get('name')}")
        # Poll until the delete operation completes (up to 90s)
        deadline = time.monotonic() + 90
        while time.monotonic() < deadline:
            await asyncio.sleep(5)
            try:
                op_status = compute.zoneOperations().get(
                    project=_project_id,
                    zone=_zone,
                    operation=op["name"],
                ).execute()
                if op_status.get("status") == "DONE":
                    logger.info(f"[Broker] GCP instance {instance_id} confirmed deleted")
                    return
            except Exception as _poll_err:
                raise RuntimeError(f"GCP fence poll error for {instance_id}: {_poll_err}") from _poll_err
        raise RuntimeError(f"GCP fence poll timed out for {instance_id} — delete op did not complete within 90s")
    except Exception:
        raise


async def fetch_serial_console(broker, instance_id: str, zone: Optional[str] = None) -> Optional[str]:
    """Fetch the VM's serial-port output via `compute.instances().getSerialPortOutput()`.

    Use when a GCP job silently times out with 0 log lines — the instance's
    serial console captures kernel + bash output even when our Python
    heartbeat never reaches the API (seen 2026-04-19 on every instance
    running image ubuntu-accelerator-2204-amd64-with-nvidia-580). Requires
    the service account to have `compute.instances.getSerialPortOutput`
    (included in roles/compute.instanceAdmin.v1 and roles/compute.viewer).

    Credential resolution mirrors hard_fence(): in-process cache →
    BYOC file → VL_GCP_* env vars.

    Returns the console bytes as a string, or None on error.

    Source: https://cloud.google.com/compute/docs/reference/rest/v1/instances/getSerialPortOutput
    """
    _cached = broker._gcp_sa_info.get(instance_id)
    try:
        from google.oauth2 import service_account
        from googleapiclient import discovery

        if _cached:
            creds = service_account.Credentials.from_service_account_info(
                _cached["sa_info"],
                scopes=["https://www.googleapis.com/auth/compute.readonly"],
            )
            _project_id = _cached["project_id"]
            _zone = _cached["zone"]
        elif broker.config.gcp and getattr(broker.config.gcp, "service_account_json", ""):
            gcp_cfg = broker.config.gcp
            creds = service_account.Credentials.from_service_account_file(
                gcp_cfg.service_account_json,
                scopes=["https://www.googleapis.com/auth/compute.readonly"],
            )
            _project_id = gcp_cfg.project_id
            _zone = zone or gcp_cfg.zone
        else:
            from api.credentials import _read_provider_credentials
            managed = _read_provider_credentials("gcp")
            if not managed:
                logger.warning(
                    f"[Broker] GCP serial fetch: no credentials available for {instance_id}"
                )
                return None
            sa_info = {
                "type":         "service_account",
                "project_id":   managed["project_id"],
                "private_key":  managed["private_key"].replace("\\n", "\n"),
                "client_email": managed["client_email"],
                "token_uri":    "https://oauth2.googleapis.com/token",
            }
            creds = service_account.Credentials.from_service_account_info(
                sa_info, scopes=["https://www.googleapis.com/auth/compute.readonly"],
            )
            _project_id = managed["project_id"]
            _zone = zone or managed.get("zone", "") or "us-central1-a"

        compute = discovery.build("compute", "v1", credentials=creds)
        # port=1 is the kernel serial console on GCE (same as what Google
        # Cloud Console's "View serial port 1 (console)" button shows).
        resp = compute.instances().getSerialPortOutput(
            project=_project_id,
            zone=_zone,
            instance=instance_id,
            port=1,
        ).execute()
        return resp.get("contents") or ""
    except Exception as e:
        logger.warning(
            f"[Broker] GCP serial fetch failed for {instance_id} (zone={zone}): {e}"
        )
        return None
