"""Nebius AI provider -- provision + fence via nebius Python SDK (gRPC).

Architecture:
  - Nebius Compute API is gRPC-only (no HTTP transcoding exists).
    Source: https://github.com/nebius/api/blob/main/nebius/compute/v1/instance_service.proto
    There are NO google.api.http annotations; aiohttp REST calls will always fail.
  - Auth: exchange service_account_key (RSA private key PEM) for IAM token via
    HTTP at https://auth.eu.nebius.com/oauth2/token/exchange, then pass to SDK.
  - SDK: `nebius` Python package (pip install nebius>=0.3.0) wraps gRPC.
    Source: https://github.com/nebius/pysdk

Required managed credential fields:
  service_account_key  : RSA private key PEM (PKCS8 or traditional)
  key_id               : public key ID (registered with the service account)
  service_account_id   : service account ID (e.g. "serviceaccount-e00...")
  folder_id / parent_id: project ID (metadata.parent_id in CreateInstanceRequest)
  subnet_id            : VPC subnet ID (required for network_interfaces)
  region               : IAM region prefix, default "eu"

Optional:
  preset               : override default single-GPU preset (e.g. "8gpu-128vcpu-1600gb")
"""
from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Optional

import aiohttp

if TYPE_CHECKING:
    from shared.models import GPUType, Job

logger = logging.getLogger(__name__)

# Default single-GPU preset per Nebius platform ID.
# Source: https://docs.nebius.com/compute/virtual-machines/types
# Override per-job via managed credential "preset" field.
_PLATFORM_PRESETS: dict[str, str] = {
    "gpu-h100-sxm": "1gpu-16vcpu-200gb",
    "gpu-h200-sxm": "1gpu-16vcpu-200gb",
    "gpu-b200-sxm": "1gpu-20vcpu-224gb",
    "gpu-b200-sxm-a": "1gpu-20vcpu-224gb",
    "gpu-b300-sxm": "1gpu-24vcpu-346gb",
}

# Boot disk: ubuntu-22-04 with CUDA 12.0 pre-installed.
# Source: https://docs.nebius.com/compute/virtual-machines/manage/create
_BOOT_IMAGE_FAMILY = "ubuntu-22-04-cuda-12-0-lts"
_BOOT_DISK_SIZE_GIB = 200


async def _get_iam_token(broker, cfg) -> Optional[str]:
    """Exchange a Nebius service-account private key for an IAM access token.

    Nebius auth flow (source: https://github.com/nebius/api/blob/main/README.md):
      1. Sign a short-lived JWT (RS256, 5-min expiry) with the private key.
         JWT claims: alg=RS256, kid=key_id, iss=service_account_id, sub=service_account_id
      2. POST https://auth.{region}.nebius.com/oauth2/token/exchange
         (form-encoded, grant_type=token-exchange, subject_token=<JWT>)
      3. Response: {"accessToken": "...", "expiresIn": "43200"}  (12h)
      4. Use accessToken as Authorization: Bearer in all API calls.

    The raw service_account_key is NEVER a valid Bearer token -- it is the RSA
    private key used only to sign the JWT.  Passing it directly causes 401.
    """
    # Return cached token if still valid (with 5-min safety margin)
    if broker._nebius_token_cache:
        token, expiry = broker._nebius_token_cache
        if time.monotonic() < expiry - 300:
            return token

    private_key = getattr(cfg, "service_account_key", "")
    key_id = getattr(cfg, "key_id", "")
    sa_id = getattr(cfg, "service_account_id", "")
    region = getattr(cfg, "region", "eu")

    if not private_key:
        logger.error("[Broker] Nebius service_account_key not set -- cannot obtain IAM token")
        return None
    if not key_id or not sa_id:
        logger.warning(
            "[Broker] Nebius key_id or service_account_id not set -- "
            "cannot sign JWT for IAM token exchange."
        )
        return None

    try:
        import jwt as _jwt  # PyJWT

        now = int(time.time())
        payload = {"iss": sa_id, "sub": sa_id, "iat": now, "exp": now + 300}
        token_jwt = _jwt.encode(
            payload,
            private_key,
            algorithm="RS256",
            headers={"kid": key_id},
        )

        auth_url = f"https://auth.{region}.nebius.com/oauth2/token/exchange"
        async with aiohttp.ClientSession() as s:
            resp = await s.post(
                auth_url,
                data={
                    "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
                    "requested_token_type": "urn:ietf:params:oauth:token-type:access_token",
                    "subject_token": token_jwt,
                    "subject_token_type": "urn:ietf:params:oauth:token-type:jwt",
                },
                timeout=aiohttp.ClientTimeout(total=15),
            )
            if resp.status != 200:
                body = await resp.text()
                logger.error(f"[Broker] Nebius IAM token exchange failed ({resp.status}): {body[:200]}")
                return None
            data = await resp.json()
            iam_token = data.get("accessToken") or data.get("access_token")
            expires_in = int(data.get("expiresIn") or data.get("expires_in") or 43200)
            broker._nebius_token_cache = (iam_token, time.monotonic() + expires_in)
            logger.info(f"[Broker] Nebius IAM token obtained (expires in {expires_in}s)")
            return iam_token
    except ImportError:
        logger.error("[Broker] PyJWT not installed -- run: pip install PyJWT cryptography")
    except Exception as e:
        logger.error(f"[Broker] Nebius IAM token exchange error: {e}")
    return None


def _make_cfg(managed: dict):
    """Build a config namespace from managed credentials dict."""
    from types import SimpleNamespace
    return SimpleNamespace(
        service_account_key=managed.get("service_account_key", ""),
        key_id=managed.get("key_id", ""),
        service_account_id=managed.get("service_account_id", ""),
        region=managed.get("region", "eu"),
        folder_id=managed.get("folder_id") or managed.get("parent_id", ""),
        subnet_id=managed.get("subnet_id", ""),
        preset=managed.get("preset", ""),
    )


async def provision(broker, gpu_type: "GPUType", job: "Job") -> Optional[str]:
    """Provision a Nebius AI instance via nebius Python SDK (gRPC).

    Source: https://github.com/nebius/api/blob/main/nebius/compute/v1/instance_service.proto
    SDK:    https://github.com/nebius/pysdk
    pip install nebius>=0.3.0

    Returns instance ID string or None on failure.
    """
    from shared.data_loader import get_instance_string, resolve_gpu_key, is_gpu_available

    _cfg = broker._get_provider_config("nebius")
    if not _cfg:
        _managed = await broker._get_managed_credentials("nebius", job.job_id)
        if not _managed:
            job.last_provision_error = "Nebius: no credentials available"
            return None
        _sk = _managed.get("service_account_key", "")
        if not _sk:
            job.last_provision_error = "Nebius: managed credentials missing service_account_key"
            from shared.failure_codes import JobFailureCode
            job.failure_code = JobFailureCode.PROV_AUTH_BAD.value
            return None
        _cfg = _make_cfg(_managed)

    _gpu_key = resolve_gpu_key(gpu_type.value)
    if not is_gpu_available("Nebius (EU)", _gpu_key):
        job.last_provision_error = f"Nebius: GPU {_gpu_key} not available"
        return None

    # get_instance_string("Nebius", _gpu_key) returns the platform ID e.g. "gpu-h100-sxm"
    platform = get_instance_string("Nebius", _gpu_key)
    if not platform:
        job.last_provision_error = f"Nebius: no platform mapped for {_gpu_key}"
        return None

    # Resolve preset: credential override > _PLATFORM_PRESETS lookup.
    # Some tests use MagicMock config objects; an unset MagicMock attribute is
    # truthy but not a valid protobuf string, so ignore non-string overrides.
    preset_override = getattr(_cfg, "preset", "") or ""
    if not isinstance(preset_override, str):
        preset_override = ""
    preset = preset_override or _PLATFORM_PRESETS.get(platform, "")
    if not preset:
        job.last_provision_error = (
            f"Nebius: no preset known for platform {platform!r}. "
            "Set 'preset' in managed credentials (e.g. '1gpu-16vcpu-200gb')."
        )
        return None

    # subnet_id is required by the Nebius API for network_interfaces
    subnet_id = getattr(_cfg, "subnet_id", "")
    if not subnet_id:
        job.last_provision_error = (
            "Nebius: subnet_id not set in credentials. "
            "Add 'subnet_id' to Nebius managed credentials."
        )
        logger.error("[Broker] Nebius subnet_id missing — cannot create network interface")
        return None

    # folder_id maps to metadata.parent_id (Nebius project ID)
    folder_id = getattr(_cfg, "folder_id", "") or getattr(_cfg, "parent_id", "")
    if not folder_id:
        job.last_provision_error = "Nebius: folder_id (project ID) not set in credentials"
        return None

    iam_token = await _get_iam_token(broker, _cfg)
    if not iam_token:
        job.last_provision_error = "Nebius: could not obtain IAM token"
        return None

    startup_script = broker._build_vm_startup_script(job)

    try:
        # Nebius Compute API is gRPC-only — use the `nebius` Python SDK.
        # Source: https://github.com/nebius/pysdk README.md
        # pip install nebius>=0.3.0
        from nebius.sdk import SDK
        from nebius.api.nebius.common.v1 import ResourceMetadata
        from nebius.api.nebius.compute.v1 import (
            InstanceServiceClient,
            CreateInstanceRequest,
            InstanceSpec,
            ResourcesSpec,
            AttachedDiskSpec,
            ManagedDisk,
            NetworkInterfaceSpec,
            PublicIPAddress,
            DiskSpec,
            SourceImageFamily,
        )

        # IDEM-1: Nebius supports X-Idempotency-Key on all mutating gRPC calls.
        # The SDK passes it as gRPC metadata. We pass it at SDK init level.
        from shared.idempotency import provision_idempotency_key
        _attempts = getattr(job, "_provision_attempts", None) or []
        _idem_key = provision_idempotency_key(
            f"{job.job_id}:nebius", len(_attempts) + 1
        )

        async with SDK(credentials=iam_token) as sdk:
            svc = InstanceServiceClient(sdk)
            op = await svc.create(
                CreateInstanceRequest(
                    metadata=ResourceMetadata(
                        parent_id=folder_id,
                        name=f"vl-{job.job_id[:8]}",
                        labels={"vl_job_id": job.job_id},
                    ),
                    spec=InstanceSpec(
                        resources=ResourcesSpec(
                            platform=platform,   # e.g. "gpu-h100-sxm"
                            preset=preset,       # e.g. "1gpu-16vcpu-200gb"
                        ),
                        network_interfaces=[
                            NetworkInterfaceSpec(
                                name="eth0",
                                subnet_id=subnet_id,
                                public_ip_address=PublicIPAddress(static=False),
                            )
                        ],
                        boot_disk=AttachedDiskSpec(
                            attach_mode="READ_WRITE",
                            managed_disk=ManagedDisk(
                                name=f"boot-{job.job_id[:8]}",
                                spec=DiskSpec(
                                    type=DiskSpec.DiskType.NETWORK_SSD,
                                    size_gibibytes=_BOOT_DISK_SIZE_GIB,
                                    source_image_family=SourceImageFamily(
                                        image_family=_BOOT_IMAGE_FAMILY,
                                    ),
                                ),
                            ),
                        ),
                        # cloud_init_user_data is raw text (NOT base64).
                        # This replaces the old incorrect metadata.user-data approach.
                        cloud_init_user_data=startup_script,
                    ),
                ),
                metadata={"x-idempotency-key": _idem_key},
            )
            # Operation is async — poll until the instance is created.
            # SDK op.wait() polls OperationService/Get until status is set.
            # Timeout: Nebius instance creation typically takes 2-5 min; 300s
            # gives headroom without blocking the migration lock indefinitely.
            import asyncio as _asyncio
            try:
                await _asyncio.wait_for(op.wait(), timeout=300)
            except _asyncio.TimeoutError:
                job.last_provision_error = "Nebius: instance creation timed out after 300s"
                logger.error("[Broker] Nebius provision timed out for job %s", job.job_id[:8])
                return None
            instance_id = getattr(op, "resource_id", None) or getattr(
                getattr(op, "metadata", None), "resource_id", None
            )
            if not instance_id:
                job.last_provision_error = "Nebius: operation completed but no instance_id returned"
                logger.error("[Broker] Nebius: op.wait() done but resource_id is empty: %s", op)
                return None
            logger.info(
                "[Broker] Nebius instance %s created (platform=%s preset=%s job=%s)",
                instance_id, platform, preset, job.job_id[:8],
            )
            return instance_id

    except ImportError as _imp:
        job.last_provision_error = (
            f"Nebius: nebius SDK not installed -- run: pip install 'nebius>=0.3.0' ({_imp})"
        )
        logger.error("[Broker] nebius Python SDK not installed: %s", _imp)
        return None
    except Exception as e:
        job.last_provision_error = f"Nebius: {type(e).__name__}: {str(e)[:150]}"
        logger.error("Nebius provision error for job %s: %s", job.job_id[:8], e)
        return None


async def hard_fence(broker, instance_id: str, job=None) -> None:
    """Delete a Nebius AI instance via nebius Python SDK (gRPC).

    DELETE is permanent and also removes all managed disks created with the instance.
    Source: https://github.com/nebius/api/blob/main/nebius/compute/v1/instance_service.proto
    Proto comment: "Deletes a VM instance by its ID. Also deletes all the managed
    disks, declared in the instance spec."
    """
    _cfg = broker._get_provider_config("nebius")
    if not _cfg:
        _job_id = getattr(job, "job_id", None) if job else None
        if _job_id:
            _managed = await broker._get_managed_credentials("nebius", _job_id)
            if _managed and _managed.get("service_account_key"):
                _cfg = _make_cfg(_managed)
        if not _cfg:
            raise RuntimeError(f"Nebius config not found for fence of {instance_id}")

    iam_token = await _get_iam_token(broker, _cfg)
    if not iam_token:
        raise RuntimeError(f"Nebius: could not obtain IAM token for fence of {instance_id}")

    try:
        from nebius.sdk import SDK
        from nebius.api.nebius.compute.v1 import (
            InstanceServiceClient,
            DeleteInstanceRequest,
        )

        import asyncio as _asyncio
        async with SDK(credentials=iam_token) as sdk:
            svc = InstanceServiceClient(sdk)
            op = await svc.delete(DeleteInstanceRequest(id=instance_id))
            try:
                await _asyncio.wait_for(op.wait(), timeout=120)
            except _asyncio.TimeoutError:
                # Delete operation timed out — log and raise so the caller
                # can mark termination unconfirmed for manual follow-up.
                raise RuntimeError(
                    f"Nebius delete timed out after 120s for {instance_id} "
                    "(instance may still be running — check Nebius console)"
                )
            logger.info("[Broker] Nebius instance %s deleted", instance_id)

    except ImportError as _imp:
        raise RuntimeError(
            f"Nebius SDK not installed -- run: pip install 'nebius>=0.3.0' ({_imp})"
        ) from _imp
    except Exception as e:
        err_str = str(e).lower()
        if "not found" in err_str or "404" in err_str:
            logger.info("[Broker] Nebius instance %s already gone -- treating as deleted", instance_id)
            return
        logger.error("[Broker] Nebius fence error for %s: %s", instance_id, e)
        raise
