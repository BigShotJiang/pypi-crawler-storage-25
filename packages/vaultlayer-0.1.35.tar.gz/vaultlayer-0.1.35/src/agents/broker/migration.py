"""
Migration execution logic extracted from BrokerAgent.

The main function `execute_migration()` takes `broker` (a BrokerAgent instance)
as its first parameter so it can access config, queue, and other broker state.
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
from datetime import datetime
from typing import Optional, TYPE_CHECKING

from shared.models import AgentEvent, EventType, Job, JobStatus, Provider, GPUType
from shared.queue import make_event
from shared.telemetry import MetricCategory
from shared.job_logger import log_event

if TYPE_CHECKING:
    from agents.broker.agent import BrokerAgent

logger = logging.getLogger(__name__)

try:
    from shared.provider_capacity import (
        claim_provider_slot, release_provider_slot,
        acquire_provision_lock, release_provision_lock, extend_provision_lock,
    )
    _HAS_CAPACITY = True
except ImportError:
    _HAS_CAPACITY = False
    def claim_provider_slot(p, j): return True
    def release_provider_slot(j): return None
    def acquire_provision_lock(j, ttl_seconds=300): return True
    def release_provision_lock(j): return None
    def extend_provision_lock(j, ttl_seconds=300): return True

try:
    from shared.price_guard import check_margin, check_price_freshness, MarginViolation, PriceStaleError, VL_MARGIN
    _PRICE_GUARD = True
except ImportError:
    _PRICE_GUARD = False
    VL_MARGIN = 1.15


# ---------------------------------------------------------------------------
# GAP-25: Pre-flight quota check tables
# ---------------------------------------------------------------------------

_LAMBDA_GPU_MAP: dict = {
    GPUType.H100_80GB_SXM: "gpu_8x_h100_sxm5",
    GPUType.A100_80GB_SXM: "gpu_8x_a100_sxm4",
    GPUType.A100_40GB: "gpu_1x_a100",
    GPUType.A10G: "gpu_1x_a10",
}

_AWS_GPU_QUOTA_CODES: dict = {
    "H100_80GB_SXM": "L-417A185B", "H100_80GB_PCIE": "L-417A185B",
    "H100_80GB_NVL": "L-417A185B", "A100_80GB_SXM": "L-417A185B",
    "A100_40GB": "L-417A185B",
    "A10G": "L-DB2E81BA", "L40S": "L-DB2E81BA",
}

_GCP_GPU_METRICS: dict = {
    "H100_80GB_SXM": "NVIDIA_H100_80GB_GPUS",
    "H100_80GB_PCIE": "NVIDIA_H100_80GB_GPUS",
    "H100_80GB_NVL": "NVIDIA_H100_80GB_GPUS",
    "A100_80GB_SXM": "NVIDIA_A100_80GB_GPUS",
    "A100_40GB": "NVIDIA_A100_GPUS",
    "A10G": "NVIDIA_L4_GPUS",
    "L40S": "NVIDIA_L4_GPUS",
}

_AZURE_GPU_FAMILIES: dict = {
    "H100_80GB_SXM": "standardNDSH100v5Family",
    "H100_80GB_PCIE": "standardNDSH100v5Family",
    "H100_80GB_NVL": "standardNDSH100v5Family",
    "A100_80GB_SXM": "standardNDASv4_A100Family",
    "A100_40GB": "standardNDASv4_A100Family",
    "A10G": "standardNCASv3_T4Family",
}


async def _unfreeze_billing(broker: "BrokerAgent", job: "Job") -> None:
    """Clear the migration billing freeze on failure paths."""
    _freeze_field = "billing_" "frozen_at"
    if not getattr(job, _freeze_field, None):
        return
    try:
        from api.db import get_db, _db_call as _db_c_uf
        _db_c_uf(
            lambda: get_db().table("jobs").update({
                _freeze_field: None,
            }).eq("job_id", job.job_id).execute(),
            label="billing_freeze:clear_on_failure",
        )
        # This helper clears billing_frozen_at in both DB and queued job state.
        setattr(job, _freeze_field, None)
        await broker.queue.set_job_state(job.job_id, job.model_dump(mode="json"))
        logger.info(f"[Broker] Billing unfrozen (failure path) for job {job.job_id}")
    except Exception as _uf_err:
        logger.warning(f"[Broker] Billing unfreeze failed (non-fatal): {_uf_err}")


async def check_quota(broker: "BrokerAgent", provider: Provider, gpu_type: GPUType) -> bool:
    """Check if provider has quota/capacity for this GPU type. Returns True if available.

    Best-effort: returns True (fail open) if the check fails or the provider
    doesn't support quota introspection. A False means we know for certain
    that capacity is exhausted -- skip this provider to save time.
    """
    try:
        if provider == Provider.LAMBDA_LABS:
            import aiohttp
            async with aiohttp.ClientSession() as s:
                resp = await s.get(
                    f"{broker.config.lambda_labs.base_url}/instance-types",
                    headers={"Authorization": f"Basic {broker.config.lambda_labs.api_key}"},
                    timeout=aiohttp.ClientTimeout(total=10),
                )
                data = await resp.json()
                instance_types = data.get("data", {})
                target = _LAMBDA_GPU_MAP.get(gpu_type, "")
                entry = instance_types.get(target, {})
                regions = entry.get("regions_with_capacity_available", [])
                return len(regions) > 0

        if provider == Provider.AWS:
            quota_code = _AWS_GPU_QUOTA_CODES.get(gpu_type.value)
            if not quota_code:
                return True
            import boto3
            from shared.sts import STSSessionManager
            session = STSSessionManager(broker.config).get_session()
            sq = session.client("service-quotas", region_name=broker.config.aws.region)
            resp = sq.get_service_quota(ServiceCode="ec2", QuotaCode=quota_code)
            limit = resp.get("Quota", {}).get("Value", 0)
            if limit <= 0:
                logger.warning(
                    f"[Broker] AWS quota {quota_code} limit is {limit} vCPUs -- "
                    f"user has no GPU capacity for {gpu_type.value}"
                )
                return False
            return True

        if provider == Provider.GCP:
            metric = _GCP_GPU_METRICS.get(gpu_type.value)
            if not metric:
                return True
            cfg = broker.config.gcp
            if not cfg:
                return True
            from googleapiclient.discovery import build
            from google.oauth2 import service_account
            import json
            creds_data = json.loads(cfg.service_account_json) if isinstance(cfg.service_account_json, str) else cfg.service_account_json
            credentials = service_account.Credentials.from_service_account_info(creds_data)
            compute = build("compute", "v1", credentials=credentials, cache_discovery=False)
            region_info = compute.regions().get(
                project=cfg.project_id, region=cfg.region or "us-central1"
            ).execute()
            for quota in region_info.get("quotas", []):
                if quota.get("metric") == metric:
                    usage = float(quota.get("usage", 0))
                    limit = float(quota.get("limit", 0))
                    if limit <= 0 or usage >= limit:
                        logger.warning(f"[Broker] GCP quota {metric} exhausted: {usage}/{limit}")
                        return False
                    return True
            return True

        if provider == Provider.AZURE:
            family = _AZURE_GPU_FAMILIES.get(gpu_type.value)
            if not family:
                return True
            cfg = broker.config.azure
            if not cfg:
                return True
            from azure.identity import ClientSecretCredential
            from azure.mgmt.compute import ComputeManagementClient
            credential = ClientSecretCredential(
                tenant_id=cfg.tenant_id, client_id=cfg.client_id, client_secret=cfg.client_secret,
            )
            compute_client = ComputeManagementClient(credential, cfg.subscription_id)
            location = cfg.region or "eastus"
            for usage in compute_client.usage.list(location):
                if usage.name.value == family:
                    if usage.limit <= 0 or usage.current_value >= usage.limit:
                        logger.warning(f"[Broker] Azure quota {family} exhausted: {usage.current_value}/{usage.limit}")
                        return False
                    return True
            return True

        return True
    except Exception as e:
        logger.warning(f"[Broker] Quota check failed for {provider}/{gpu_type}: {e}")
        return True  # fail open


async def execute_migration(
    broker: "BrokerAgent",
    job: Job,
    target_provider: Provider,
    target_gpu: GPUType,
    decision_id: str,
    event_type: Optional[str] = None,
):
    """Full migration sequence: checkpoint -> provision -> restore -> resume."""
    from agents.broker.agent import RegionNotAllowedError
    from agents.broker.billing import record_provision_spend
    from agents.broker.warm_pool import WarmNode

    # Region guard: check allowed/blocked_regions before provisioning
    target_region = broker.config.aws.region if target_provider == Provider.AWS else ""
    if target_region:
        broker._check_region_allowed(target_region, job)
    # Price guard: staleness + margin check before spending money
    if _PRICE_GUARD:
        try:
            check_price_freshness(provider=str(target_provider))
        except PriceStaleError as _pse:
            logger.error(f"Migration blocked by stale prices: {_pse}")
            raise
        try:
            _gpu_key = target_gpu.value.split("_")[0]
            _prov_name = target_provider.value.replace("_", " ").title()
            _live_cost = broker._get_live_price(_prov_name, _gpu_key)
            _user_charge = broker._get_user_charge(_prov_name, _gpu_key)
            if _live_cost is not None and _user_charge is not None and _live_cost > 0 and _user_charge > 0:
                result = check_margin(_prov_name, _gpu_key, _live_cost, _user_charge)
                logger.info(f"Margin check OK: {_prov_name} {_gpu_key} {result.get('margin_pct', 0.0):.1f}%")
        except MarginViolation as _mv:
            logger.critical(f"Migration BLOCKED by margin violation: {_mv}")
            raise
    # Capacity guard: release OLD provider slot + claim NEW provider slot
    if _HAS_CAPACITY:
        # Release the slot on the provider the job is LEAVING
        _old_prov = job.provider.value.replace("_", " ").title() if job.provider else ""
        if _old_prov:
            release_provider_slot(job.job_id)  # frees old slot immediately
            logger.debug(f"Released {_old_prov} slot for migrating job {job.job_id}")
        # Claim a slot on the NEW provider
        _new_prov = target_provider.value.replace("_", " ").title()
        if not claim_provider_slot(_new_prov, job.job_id):
            # Re-claim old slot since migration is blocked
            if _old_prov:
                claim_provider_slot(_old_prov, job.job_id)
            raise RuntimeError(
                f"{_new_prov} is at concurrent job capacity. "
                f"Migration blocked -- orchestration should retry with a different provider."
            )
    # Durable provision lock: Redis SETNX with 5-min TTL.
    # Survives broker crash/restart — prevents double-provisioning the same job_id
    # if the broker dies mid-flight and restarts before the prior provision completes.
    # Falls back to True (allow) when Redis is not configured.
    # Replaces the prior asyncio.Lock which was a no-op (body was `pass`).
    if not acquire_provision_lock(job.job_id):
        logger.warning(
            f"[Broker] Provision for job {job.job_id} already in-flight "
            "(Redis lock held) — dropping duplicate migration to prevent double-provision"
        )
        # Re-restore capacity slots to the state before this call
        if _HAS_CAPACITY and _new_prov:
            release_provider_slot(job.job_id)
            if _old_prov:
                claim_provider_slot(_old_prov, job.job_id)
        return None
    # GAP-6: STONITH -- hard fence via provider terminate API for voluntary migrations.
    # For TERMINATION_SIGNAL (spot preemption), the cloud provider already killed/is
    # killing the instance, so we skip the fence call -- instance is already dead.
    _is_termination_signal = event_type == "termination_signal" if event_type else False
    _is_arbitrage = event_type == "arbitrage_opportunity" if event_type else False
    if not _is_termination_signal:
        # For voluntary migrations and heartbeat-miss triggered migrations, call and
        # confirm provider API termination before provisioning the new node.
        # This guarantees at most one node writes to R2 at a time.
        await broker._fence_old_node(job)

    migration_id = f"{job.job_id}:{decision_id[:8]}"
    # Save old instance info for cleanup after migration completes
    _old_instance_id = job.instance_id
    _old_provider = job.provider
    # Capture old run_id for hop chain linking (Gap 6)
    _old_run_id = getattr(broker, "_run_ids", {}).get(_old_instance_id)
    broker._active_migrations[migration_id] = {"status": "starting", "started_at": datetime.utcnow()}
    logger.info(f"Migration {migration_id}: {job.provider.value} -> {target_provider.value}")
    migration_start = time.monotonic()

    # P0-L1: Create per-job checkpoint event BEFORE provisioning starts.
    _ckpt_event = asyncio.Event()
    # Defensive getattr: tests may construct BrokerAgent via __new__ without __init__
    _ckpt_store = getattr(broker, "_checkpoint_events", None)
    if _ckpt_store is not None:
        _ckpt_store[job.job_id] = _ckpt_event
    if broker._tel:
        broker._tel.event("broker.migration_started",
                          tags={"from": job.provider.value, "to": target_provider.value,
                                "gpu": target_gpu.value},
                          job_id=job.job_id, category=MetricCategory.PROVIDER)

    await broker.queue.publish_critical("broker", make_event(
        event_type=EventType.MIGRATION_STARTED, source_agent=broker.AGENT_NAME, job_id=job.job_id,
        payload={"target_provider": target_provider.value, "target_gpu": target_gpu.value, "migration_id": migration_id},
        priority=2,
    ))
    await log_event(
        job_id=job.job_id,
        user_id=job.user_id,
        event_type="migration_started",
        message=f"Migrating from {_old_provider.value} -> {target_provider.value} ({target_gpu.value})",
        metadata={"from_provider": _old_provider.value, "to_provider": target_provider.value,
                  "gpu": target_gpu.value, "migration_id": migration_id},
    )

    # -- Billing freeze: pause credit burn during migration window --
    _failover = getattr(job, "failover_enabled", True)
    if _failover:
        try:
            from api.db import get_db, _db_call as _db_c
            _freeze_ts = datetime.utcnow()
            _db_c(
                lambda: get_db().table("jobs").update({
                    "billing_frozen_at": _freeze_ts.isoformat(),
                }).eq("job_id", job.job_id).execute(),
                label="billing_freeze:set",
            )
            job.billing_frozen_at = _freeze_ts
            # Sync to Redis so orchestration's credit burn loop sees the freeze
            await broker.queue.set_job_state(job.job_id, job.model_dump(mode="json"))
            logger.info(f"[Broker] Billing frozen for job {job.job_id} during migration")
        except Exception as _bf_err:
            logger.warning(f"[Broker] Billing freeze failed (non-fatal): {_bf_err}")

    # -- Provision target node -- with per-provider retry + failover --
    MAX_PROVISION_ATTEMPTS = 3
    PROVISION_RETRY_DELAYS = [30, 60, 120]  # seconds between attempts

    async def _provision_on(provider: Provider, gpu: GPUType) -> Optional[str]:
        """Single provision call dispatched by provider enum."""
        _DISPATCH = {
            Provider.LAMBDA_LABS:  broker.provision_lambda,
            Provider.COREWEAVE:   broker.provision_coreweave,
            Provider.AWS:         broker.provision_aws,
            Provider.RUNPOD:      broker.provision_runpod,
            Provider.VAST_AI:     broker.provision_vast,
            Provider.VOLTAGE_PARK: broker.provision_voltage_park,
            Provider.CRUSOE:      broker.provision_crusoe,
            Provider.NEBIUS:      broker.provision_nebius,
            Provider.HYPERSTACK:  broker.provision_hyperstack,
            Provider.GCP:         broker.provision_gcp,
            Provider.AZURE:       broker.provision_azure,
        }
        fn = _DISPATCH.get(provider)
        if not fn:
            logger.error(f"No provision method for provider: {provider}")
            return None
        return await fn(gpu, job)

    async def _notify_user(subject: str, detail: str, level: str = "warning") -> None:
        """Publish a human-readable status update to the escalate channel."""
        await broker.queue.publish("escalate", make_event(
            event_type=EventType.ESCALATION,
            source_agent=broker.AGENT_NAME,
            job_id=job.job_id,
            payload={
                "subject": subject,
                "detail": detail,
                "level": level,
                "job_name": job.name,
                "migration_id": migration_id,
            },
            priority=2,
        ))

    # GAP-25: Pre-flight quota check before provisioning
    if not await broker._check_quota(target_provider, target_gpu):
        logger.warning(f"[Broker] {target_provider}/{target_gpu} has no capacity -- skipping")
        broker._active_migrations[migration_id]["status"] = "failed_quota"
        await _unfreeze_billing(broker, job)
        release_provision_lock(job.job_id)
        return None

    instance_id = None
    actual_provider = target_provider

    # #140: Stamp VL_MIGRATION=1 into job env so startup scripts skip auto-start
    # (SSH resume will launch training; without this the node double-launches).
    _env_was_none = job.environment is None
    if job.environment is None:
        job.environment = {}
    job.environment["VL_MIGRATION"] = "1"

    # P0-L3: Check warm pool before cold provision.
    _warm_node: Optional[WarmNode] = None
    _warm_pool = getattr(broker, "_warm_pool", None)
    if _warm_pool is not None:
        _warm_node = await _warm_pool.claim(target_gpu)
        if _warm_node is not None:
            instance_id = _warm_node.instance_id
            actual_provider = _warm_node.provider
            logger.info(
                "[Broker] P0-L3: Warm pool HIT -- skipping cold provision "
                "(instance=%s, gpu=%s, idle=%.0fs)",
                instance_id, target_gpu.value, _warm_node.idle_secs,
            )

    # -- Step 0: try same provider in a different AZ/region first --
    # Run this BEFORE the generic failover ladder so we avoid cross-cloud egress
    # costs when capacity may simply be in a different region on the same provider.
    _same_provider_tried = False
    if instance_id is None and job.provider != target_provider and job.provider in (
        Provider.AWS, Provider.LAMBDA_LABS, Provider.RUNPOD
    ):
        logger.info(
            f"[Broker] Step 0: trying same-provider retry on {job.provider.value} "
            f"before cross-cloud to {target_provider.value} (job={job.job_id})"
        )
        try:
            _same_instance = await broker._try_same_provider_different_az(job, target_gpu)
            if _same_instance:
                instance_id = _same_instance
                actual_provider = job.provider
                _same_provider_tried = True
                logger.info(
                    f"[Broker] Same-provider retry succeeded -- staying on "
                    f"{job.provider.value} (job={job.job_id})"
                )
        except Exception as _sp_err:
            logger.debug(f"[Broker] Same-provider retry raised: {_sp_err}")

    # -- Failover path: deterministic ladder (all flows, when failover_enabled) --
    # Runs after same-provider AZ retry so we only cross clouds when the origin
    # provider is truly exhausted.
    if instance_id is None and _failover:
        _fo_iid, _fo_gpu, _fo_prov = await broker._provision_with_failover(
            job=job,
            target_gpu=target_gpu,
            provision_fn=_provision_on,
        )
        if _fo_iid:
            instance_id = _fo_iid
            actual_provider = _fo_prov
            target_gpu = _fo_gpu  # may differ if fallback ladder was used

    # Attempt the requested (cross-cloud) provider with retries (skipped if warm pool or same-provider hit)
    for attempt in range(MAX_PROVISION_ATTEMPTS if instance_id is None else 0):
        try:
            instance_id = await _provision_on(target_provider, target_gpu)
            if instance_id:
                break
        except Exception as _prov_err:
            logger.warning(
                f"Migration {migration_id}: provision attempt {attempt+1}/{MAX_PROVISION_ATTEMPTS} "
                f"on {target_provider.value} raised: {_prov_err}"
            )

        if attempt < MAX_PROVISION_ATTEMPTS - 1:
            delay = PROVISION_RETRY_DELAYS[attempt]
            logger.info(
                f"Migration {migration_id}: retrying {target_provider.value} in {delay}s "
                f"(attempt {attempt+2}/{MAX_PROVISION_ATTEMPTS})"
            )
            await _notify_user(
                subject=f"Provisioning retry {attempt+2}/{MAX_PROVISION_ATTEMPTS}",
                detail=(
                    f"Could not provision {target_provider.value} on attempt {attempt+1}. "
                    f"Retrying in {delay}s. Your job is safe -- checkpoint is preserved in R2."
                ),
            )
            await asyncio.sleep(delay)

    # Primary provider exhausted -- try next cheapest alternatives from price cache
    if not instance_id:
        await _notify_user(
            subject=f"{target_provider.value} unavailable -- trying alternatives",
            detail=(
                f"All {MAX_PROVISION_ATTEMPTS} attempts on {target_provider.value} failed. "
                f"Scanning for next available provider with capacity for {target_gpu.value}. "
                f"Your job checkpoint is safe and will resume automatically."
            ),
        )
        try:
            cached_prices = await broker.queue.get_price_cache() or []

            def _price_entry_allowed(p: dict) -> bool:
                region = p.get("region", "")
                if p.get("provider") == Provider.AWS.value and region:
                    try:
                        broker._check_region_allowed(region, job)
                    except RegionNotAllowedError:
                        return False
                return True

            alternatives = sorted(
                [
                    p for p in cached_prices
                    if isinstance(p, dict)
                    and p.get("provider") != target_provider.value
                    and p.get("provider") != job.provider.value  # don't go back to origin
                    and p.get("gpu") == target_gpu.value
                    and p.get("availability") != "unavailable"
                    and _price_entry_allowed(p)
                ],
                key=lambda p: p.get("price_per_hour", 9999),
            )
            for alt in alternatives[:3]:  # try top-3 alternatives
                alt_provider_str = alt.get("provider", "")
                try:
                    alt_provider = Provider(alt_provider_str)
                except ValueError:
                    continue
                logger.info(
                    f"Migration {migration_id}: trying fallback provider "
                    f"{alt_provider.value} @ ${alt.get('price_per_hour')}/hr"
                )
                await _notify_user(
                    subject=f"Trying fallback: {alt_provider.value}",
                    detail=(
                        f"Attempting to provision {target_gpu.value} on {alt_provider.value} "
                        f"(${alt.get('price_per_hour', '?')}/hr). "
                        f"Job will resume automatically if successful."
                    ),
                )
                try:
                    instance_id = await _provision_on(alt_provider, target_gpu)
                    if instance_id:
                        actual_provider = alt_provider
                        logger.info(
                            f"Migration {migration_id}: fallback provision succeeded "
                            f"on {alt_provider.value} ({instance_id})"
                        )
                        break
                except Exception as _alt_err:
                    logger.warning(
                        f"Migration {migration_id}: fallback {alt_provider.value} failed: {_alt_err}"
                    )
        except Exception as _cache_err:
            logger.error(f"Migration {migration_id}: failed to read price cache for failover: {_cache_err}")

    # -- AWS On-Demand last resort --
    if not instance_id:
        od_enabled = os.getenv("VL_AWS_OD_FALLBACK_ENABLED", "true").lower() in ("true", "1", "yes")
        has_aws_config = bool(getattr(getattr(broker.config, "aws", None), "region", None))
        if od_enabled and has_aws_config:
            logger.warning(
                f"Migration {migration_id}: all spot providers exhausted -- "
                f"attempting AWS On-Demand last resort for job {job.job_id}"
            )
            await _notify_user(
                subject="Spot market exhausted -- trying AWS On-Demand",
                detail=(
                    f"No spot capacity found across all providers for {target_gpu.value}. "
                    f"Falling back to AWS On-Demand (no interruption risk, full OD price). "
                    f"Your job will resume automatically. No gainshare charged for this leg."
                ),
            )
            try:
                instance_id = await broker.provision_aws_on_demand(target_gpu, job)
                if instance_id:
                    actual_provider = Provider.AWS
                    # Tag job so FinOps skips gainshare billing for this migration leg
                    job.__dict__["fallback_reason"] = "aws_od_last_resort"
                    logger.warning(
                        f"Migration {migration_id}: AWS On-Demand fallback succeeded "
                        f"({instance_id}) -- gainshare billing suppressed for this leg"
                    )
            except Exception as _od_err:
                logger.error(
                    f"Migration {migration_id}: AWS On-Demand fallback failed: {_od_err}"
                )

    # #140: Clear VL_MIGRATION immediately after all provisioning attempts complete.
    # Treat it as a transient provisioning-only flag — must NEVER persist to Redis.
    # Every subsequent code path (DLQ, FAILED, SSH failure, and success) persists
    # job state, so clean up here once, unconditionally.
    if job.environment:
        job.environment.pop("VL_MIGRATION", None)
    if _env_was_none and job.environment == {}:
        job.environment = None

    if not instance_id:
        # P0-C5: Dead-letter queue -- increment failure counter and retry
        job.provision_failure_count = getattr(job, "provision_failure_count", 0) + 1
        if _HAS_CAPACITY:
            release_provider_slot(job.job_id)
        broker._active_migrations[migration_id]["status"] = "failed"

        if job.provision_failure_count < job.max_provision_failures:
            job.status = JobStatus.INTERRUPTED
            job.dlq_at = datetime.utcnow()
            await broker.queue.set_job_state(job.job_id, job.model_dump(mode="json"))
            logger.warning(
                f"Migration {migration_id}: all providers exhausted "
                f"(attempt {job.provision_failure_count}/{job.max_provision_failures}) -- "
                f"job {job.job_id} queued for DLQ retry in 5 min. "
                f"Checkpoint safe at step {job.current_step}."
            )
            await log_event(
                job_id=job.job_id,
                user_id=job.user_id,
                event_type="migration_failed",
                message=(
                    f"All providers exhausted (attempt {job.provision_failure_count}/"
                    f"{job.max_provision_failures}) -- entering DLQ retry"
                ),
                metadata={"target_provider": target_provider.value, "gpu": target_gpu.value,
                          "migration_id": migration_id, "checkpoint_step": job.current_step,
                          "provision_failure_count": job.provision_failure_count,
                          "last_error": job.last_provision_error},
            )
            await _notify_user(
                subject=f"Capacity crunch -- retrying in 5 min (attempt {job.provision_failure_count}/{job.max_provision_failures})",
                detail=(
                    f"VaultLayer could not find a node for job '{job.name}' right now. "
                    f"Checkpoint is safe at step {job.current_step}. "
                    f"Will automatically retry in ~5 minutes."
                    + (f"\nLast error: {job.last_provision_error}" if job.last_provision_error else "")
                ),
                level="warning",
            )
            await _unfreeze_billing(broker, job)
            release_provision_lock(job.job_id)
            return

        # All retries exhausted -- escalate to permanent FAILED
        logger.error(
            f"Migration {migration_id}: all providers exhausted after "
            f"{job.provision_failure_count} DLQ retries -- escalating to human"
        )
        await _notify_user(
            subject="ACTION REQUIRED -- job needs manual intervention",
            detail=(
                f"VaultLayer could not provision a replacement node for job '{job.name}' "
                f"after {job.provision_failure_count} attempts over ~25 minutes. "
                f"Your checkpoint is safe in R2 at step {job.current_step}. "
                f"To resume manually: vaultlayer resume --job-id {job.job_id}"
                + (f"\nLast error: {job.last_provision_error}" if job.last_provision_error else "")
            ),
            level="critical",
        )
        # Mark job as permanently failed
        job.status = JobStatus.FAILED
        await broker.queue.set_job_state(job.job_id, job.model_dump(mode="json"))
        await log_event(
            job_id=job.job_id,
            user_id=job.user_id,
            event_type="migration_failed",
            message=f"All providers exhausted after {job.provision_failure_count} DLQ retries -- job permanently failed",
            metadata={"target_provider": target_provider.value, "gpu": target_gpu.value,
                      "migration_id": migration_id, "checkpoint_step": job.current_step,
                      "provision_failure_count": job.provision_failure_count,
                      "last_error": job.last_provision_error},
        )
        await _unfreeze_billing(broker, job)
        release_provision_lock(job.job_id)
        return

    # -- Provision succeeded -- clear error field --
    job.last_provision_error = ""
    # Update job.instance_id AND job.provider so watchdog monitors the correct node.
    # Use actual_provider (not target_provider) — they differ when a warm pool hit,
    # same-provider AZ retry, or alt-provider fallback was used. Watchdog and host
    # resolution both use job.provider to pick the correct provider API; using the
    # wrong value causes termination calls and heartbeat checks to go to the wrong API.
    job.instance_id = instance_id
    job.provider = actual_provider
    # -- Gainshare billing: set user-facing rate (not raw sourced cost) --
    _prov_name_bill = actual_provider.value.replace("_", " ").title()
    _gpu_key_bill = target_gpu.value.split("_")[0]
    _user_rate = broker._get_user_charge(_prov_name_bill, _gpu_key_bill)
    if _user_rate and _user_rate > 0:
        job.current_hourly_rate = _user_rate
        logger.info(
            f"Migration {migration_id}: user billed at ${_user_rate:.4f}/hr "
            f"(gainshare-adjusted, {_prov_name_bill} {_gpu_key_bill})"
        )
    await broker.queue.set_job_state(job.job_id, job.model_dump(mode='json'))
    logger.info(f'Migration {migration_id}: provisioned {instance_id} on {target_provider}')
    broker._active_migrations[migration_id].update({"status": "provisioned", "instance_id": instance_id})
    # -- Record spend + job_run for the new migration leg --
    try:
        record_provision_spend(
            broker=broker,
            job=job,
            provider=actual_provider.value if hasattr(actual_provider, "value") else str(actual_provider),
            gpu_type=target_gpu.value,
            instance_id=instance_id,
            provisioned_at=datetime.utcnow(),
            rate_per_hr=_user_rate or job.current_hourly_rate or 0.0,
            is_test=getattr(job, "is_test", False),
            is_hop_leg=True,
            migrated_from_run_id=_old_run_id,
        )
    except Exception as _spend_err:
        logger.warning(f"[Broker] Migration spend recording failed (non-fatal): {_spend_err}")
    logger.info(f"Migration {migration_id}: node ready ({instance_id}), restoring checkpoint...")

    # P0-L2: Short buffer for provider API to assign and propagate the node IP,
    # then rely on SSH/bootstrap readiness probes instead of a blind 30s sleep.
    await asyncio.sleep(5)

    # Resolve the node IP for downstream agents (namespace, watchdog).
    _node_ip = ""
    try:
        _node_ip = await broker._resolve_instance_host(instance_id, actual_provider) or ""
    except Exception:
        pass

    # Signal Vault to restore checkpoint on new node.
    await broker.queue.publish("broker", make_event(
        event_type=EventType.NODE_PROVISIONED, source_agent=broker.AGENT_NAME, job_id=job.job_id,
        payload={
            "command": "restore", "target_agent": "vault_agent",
            "instance_id": instance_id, "target_dir": "/workspace/checkpoint",
            "migration_id": migration_id,
            # NamespaceAgent uses these to remount + restart prefetcher:
            "node_ip": _node_ip,
            "dataset_id": job.dataset_id or "",
            "nvme_cache_path": "/mnt/nvme/vl-cache",
        },
        priority=1,
    ))

    ssh_key = os.environ.get("VAULTLAYER_SSH_KEY_PATH", os.path.expanduser("~/.ssh/id_rsa"))
    node_host = os.environ.get(f"VAULTLAYER_NODE_HOST_{instance_id}", "") or _node_ip
    # P0-L3: Warm pool node already knows its host + key.
    if _warm_node is not None:
        if _warm_node.host and _warm_node.host != _warm_node.instance_id:
            node_host = _warm_node.host
        if _warm_node.ssh_key:
            ssh_key = _warm_node.ssh_key
    # Rule 3: resume path is on NVMe ($VL_DATA_ROOT set by UserData).
    resume_ckpt = f"${{VL_DATA_ROOT:-/tmp}}/vl-checkpoints/{job.job_id}"
    # R2 key prefix for checkpoint prefetch — different from the local NVMe path.
    # Layout: checkpoints/{job_id}/ (see startup_scripts.py:317, r2.py:105).
    # Passing resume_ckpt (local path) to _prefetch_checkpoint would build an
    # invalid rclone source: r2:<bucket>/${VL_DATA_ROOT:-/tmp}/vl-checkpoints/<id>.
    _r2_ckpt_prefix = f"checkpoints/{job.job_id}/"
    if node_host and ssh_key:
        # Renew immediately after provision before SSH/bootstrap waits. Provision
        # plus wait_for_ssh(180s) plus wait_for_bootstrap(300s) can exceed the
        # original 5-minute TTL before the checkpoint wait starts.
        extend_provision_lock(job.job_id, ttl_seconds=900)
        try:
            await broker._wait_for_ssh(node_host, timeout=180)
        except Exception as _ssh_err:
            logger.error(
                f"Migration {migration_id}: SSH to {node_host} failed -- rolling back. {_ssh_err}"
            )
            # Fence the newly provisioned instance before clearing job.instance_id.
            # Without this, the node keeps billing while the control plane has
            # already dropped its instance_id from the job record.
            try:
                await broker._fence_old_node_by_id(instance_id, actual_provider)
                logger.info(
                    f"[Migration] Fenced leaked instance {instance_id} "
                    f"({actual_provider.value}) after SSH failure"
                )
            except Exception as _fence_err:
                logger.error(
                    f"[Migration] Failed to fence {instance_id} after SSH failure "
                    f"(billing leak risk): {_fence_err}. Manual cleanup required."
                )
            # Transactional rollback: revert job state so orchestration can retry
            job.instance_id = None
            job.status = JobStatus.FAILED
            await broker.queue.set_job_state(job.job_id, job.model_dump(mode="json"))
            broker._active_migrations[migration_id]["status"] = "failed_ssh"
            await log_event(
                job_id=job.job_id,
                user_id=job.user_id,
                event_type="migration_failed",
                message=f"SSH unreachable after provisioning {instance_id} -- job marked failed",
                metadata={"instance_id": instance_id, "host": node_host,
                          "migration_id": migration_id, "error": str(_ssh_err)},
            )
            if _HAS_CAPACITY:
                release_provider_slot(job.job_id)
            await _unfreeze_billing(broker, job)
            release_provision_lock(job.job_id)
            return
        # P0-L2: Wait for full bootstrap to complete
        await broker._wait_for_bootstrap(node_host, ssh_key, job)

        # P0-L1: Parallel checkpoint gate.
        # Extend provision lock before the long checkpoint wait (up to 600s) to
        # prevent a duplicate-provision race if the lock's 5-min TTL expires.
        extend_provision_lock(job.job_id, ttl_seconds=900)
        if _ckpt_store is not None and not _ckpt_event.is_set():
            logger.info(
                f"[Broker] P0-L1: provision+bootstrap complete, waiting for checkpoint "
                f"to land in R2 (job={job.job_id}) ..."
            )
            try:
                await asyncio.wait_for(_ckpt_event.wait(), timeout=600)
                logger.info(f"[Broker] P0-L1: checkpoint ready, starting prefetch (job={job.job_id})")
            except asyncio.TimeoutError:
                # #144: If the job has prior progress, a cold restart would lose steps.
                # Fence the provisioned node, requeue for DLQ retry so the checkpoint
                # has more time to propagate. Only allow cold restart when current_step=0.
                _has_prior_step = bool(getattr(job, "current_step", None))
                if _has_prior_step:
                    logger.error(
                        f"[Broker] P0-L1: timed out waiting for CHECKPOINT_READY after 600s "
                        f"(job={job.job_id}, current_step={job.current_step}) -- "
                        f"refusing cold restart with prior progress; fencing node and requeueing"
                    )
                    if _ckpt_store is not None:
                        _ckpt_store.pop(job.job_id, None)
                    # Fence the provisioned node to stop billing before we abandon it
                    _fenced_checkpoint_timeout_node = False
                    try:
                        await broker._fence_old_node_by_id(instance_id, actual_provider)
                        _fenced_checkpoint_timeout_node = True
                        logger.info(
                            f"[Migration] Fenced instance {instance_id} "
                            f"({actual_provider.value}) after checkpoint timeout"
                        )
                    except Exception as _fence_err:
                        logger.error(
                            f"[Migration] Failed to fence {instance_id} after checkpoint timeout "
                            f"(billing leak risk): {_fence_err}. Manual cleanup required."
                        )
                    if _fenced_checkpoint_timeout_node:
                        job.instance_id = None
                    job.provision_failure_count = getattr(job, "provision_failure_count", 0) + 1
                    job.status = JobStatus.INTERRUPTED
                    job.dlq_at = datetime.utcnow()
                    await broker.queue.set_job_state(job.job_id, job.model_dump(mode="json"))
                    await log_event(
                        job_id=job.job_id,
                        user_id=job.user_id,
                        event_type="migration_failed",
                        message=(
                            f"CHECKPOINT_READY timeout (600s) with prior progress "
                            f"at step {job.current_step} -- fenced node, entering DLQ retry"
                        ),
                        metadata={
                            "instance_id": instance_id,
                            "current_step": job.current_step,
                            "migration_id": migration_id,
                            "provision_failure_count": job.provision_failure_count,
                        },
                    )
                    if _HAS_CAPACITY:
                        release_provider_slot(job.job_id)
                    await _unfreeze_billing(broker, job)
                    release_provision_lock(job.job_id)
                    return
                else:
                    logger.warning(
                        f"[Broker] P0-L1: timed out waiting for CHECKPOINT_READY after 600s "
                        f"(job={job.job_id}) -- no prior checkpoint, cold restart is safe"
                    )
        # Cleanup event registry after use
        if _ckpt_store is not None:
            _ckpt_store.pop(job.job_id, None)

        # GAP-20: Start checkpoint prefetch in background while docker pull runs.
        # Pass the R2 prefix (not the local NVMe path) as the rclone source key.
        asyncio.create_task(
            broker._prefetch_checkpoint(node_host, ssh_key, job, _r2_ckpt_prefix)
        )
        # Extend provision lock again before the Docker pull wait (can take
        # 10-20+ min for large images). This ensures the lock outlives the full
        # migration transaction even in the slowest case.
        extend_provision_lock(job.job_id, ttl_seconds=900)
        # Level 1 cold-start fix: wait for docker image to be ready before launching
        if job.docker_image:
            image_ready = await broker._wait_for_image_ready(node_host, ssh_key, job)
            if not image_ready:
                logger.warning(
                    f"execute_migration: docker pull timed out for {job.docker_image!r}. "
                    "Proceeding anyway -- training may fail if image is incomplete."
                )
        # CUDA/driver parity probe
        cuda_ok, detected_driver = await broker._probe_cuda(node_host, ssh_key, job=job)
        if not cuda_ok:
            logger.warning(
                f"execute_migration: CUDA probe failed on {node_host} "
                f"(driver={detected_driver}). Proceeding -- monitor job for CUDA errors."
            )
            await broker.queue.publish("broker", make_event(
                event_type=EventType.MIGRATION_STARTED,
                source_agent=broker.AGENT_NAME,
                job_id=job.job_id,
                payload={
                    "warning": "cuda_driver_mismatch",
                    "detected_driver": detected_driver,
                    "migration_id": migration_id,
                },
                priority=4,
            ))
        _restart_ok = await broker._restart_job_on_node(
            host=node_host, ssh_key=ssh_key,
            command=job.command, job_id=job.job_id,
            resume_checkpoint=resume_ckpt
        )
        if not _restart_ok:
            logger.error(
                f"Migration {migration_id}: _restart_job_on_node returned False "
                f"(SSH launch failed) — fencing {instance_id} and marking failed"
            )
            try:
                await broker._fence_old_node_by_id(instance_id, actual_provider)
            except Exception as _fe:
                logger.error(f"[Migration] Fence of {instance_id} after restart failure: {_fe}")
            job.instance_id = None
            job.status = JobStatus.FAILED
            await broker.queue.set_job_state(job.job_id, job.model_dump(mode="json"))
            broker._active_migrations[migration_id]["status"] = "failed_restart"
            await log_event(
                job_id=job.job_id,
                user_id=job.user_id,
                event_type="migration_failed",
                message=f"SSH restart failed after provisioning {instance_id}",
                metadata={"instance_id": instance_id, "migration_id": migration_id},
            )
            if _HAS_CAPACITY:
                release_provider_slot(job.job_id)
            await _unfreeze_billing(broker, job)
            release_provision_lock(job.job_id)
            return
        # GAP-8: Re-register heartbeat monitoring on the new node after migration.
        await broker.queue.publish("watchdog", make_event(
            event_type=EventType.NODE_PROVISIONED,
            source_agent=broker.AGENT_NAME,
            job_id=job.job_id,
            payload={
                "new_instance_id": instance_id,
                "new_provider": actual_provider.value,
                "host": node_host,
                "reattach_watchdog": True,  # signal to watchdog to re-arm
            },
            priority=2,
        ))
    else:
        # node_host or ssh_key is empty — cannot SSH to restart training.
        # Fence the provisioned instance to prevent a billing leak.
        logger.error(
            f"Migration {migration_id}: cannot SSH to new node "
            f"(node_host={node_host!r}, ssh_key missing={not ssh_key}) — "
            f"fencing {instance_id} and marking migration failed"
        )
        try:
            await broker._fence_old_node_by_id(instance_id, actual_provider)
        except Exception as _fe:
            logger.error(f"[Migration] Fence of {instance_id} after missing SSH config: {_fe}")
        job.instance_id = None
        job.status = JobStatus.FAILED
        await broker.queue.set_job_state(job.job_id, job.model_dump(mode="json"))
        broker._active_migrations[migration_id]["status"] = "failed_no_ssh"
        await log_event(
            job_id=job.job_id,
            user_id=job.user_id,
            event_type="migration_failed",
            message=f"No SSH credentials to restart {instance_id} — instance fenced",
            metadata={"instance_id": instance_id, "migration_id": migration_id,
                      "node_host": node_host},
        )
        if _HAS_CAPACITY:
            release_provider_slot(job.job_id)
        await _unfreeze_billing(broker, job)
        release_provision_lock(job.job_id)
        return
    broker._active_migrations[migration_id]["status"] = "completed"
    elapsed = (datetime.utcnow() - broker._active_migrations[migration_id]["started_at"]).total_seconds()
    if broker._tel:
        broker._tel.timing("broker.migration_duration_ms", elapsed * 1000,
                           tags={"to": actual_provider.value, "gpu": target_gpu.value},
                           job_id=job.job_id, category=MetricCategory.PROVIDER)
        broker._tel.event("broker.migration_completed",
                          tags={"to": actual_provider.value, "elapsed_s": str(round(elapsed, 1))},
                          job_id=job.job_id, category=MetricCategory.PROVIDER)

    await broker.queue.publish("broker", make_event(
        event_type=EventType.MIGRATION_COMPLETE, source_agent=broker.AGENT_NAME, job_id=job.job_id,
        payload={"migration_id": migration_id, "instance_id": instance_id,
                 "target_provider": target_provider.value,  # requested (audit trail)
                 "actual_provider": actual_provider.value,  # where it landed
                 "duration_seconds": elapsed},
        priority=2,
    ))
    await log_event(
        job_id=job.job_id,
        user_id=job.user_id,
        event_type="migration_complete",
        message=f"Migration complete in {elapsed:.0f}s (requested={target_provider.value}, actual={actual_provider.value})",
        metadata={"to_provider": actual_provider.value, "requested_provider": target_provider.value,
                  "gpu": target_gpu.value,
                  "migration_id": migration_id, "duration_seconds": round(elapsed, 1)},
    )
    logger.info(f"Migration {migration_id} complete in {elapsed:.0f}s")
    # -- Billing unfreeze: resume credit burn after migration --
    if getattr(job, "billing_frozen_at", None):
        try:
            from api.db import get_db, _db_call as _db_c2
            _db_c2(
                lambda: get_db().table("jobs").update({
                    "billing_frozen_at": None,
                }).eq("job_id", job.job_id).execute(),
                label="billing_freeze:clear",
            )
            job.billing_frozen_at = None
            # Sync to Redis so orchestration resumes credit burn
            await broker.queue.set_job_state(job.job_id, job.model_dump(mode="json"))
            logger.info(f"[Broker] Billing unfrozen for job {job.job_id}")
        except Exception as _bu_err:
            logger.warning(f"[Broker] Billing unfreeze failed (non-fatal): {_bu_err}")
    # GAP-22: Cleanup old instance storage asynchronously (non-blocking)
    if _old_instance_id and _old_provider and _old_instance_id != instance_id:
        asyncio.create_task(
            cleanup_old_instance(broker, _old_instance_id, _old_provider, job)
        )
    release_provision_lock(job.job_id)


async def cleanup_old_instance(broker: "BrokerAgent", old_instance_id: str, old_provider: Provider, job: Job) -> None:
    """Terminate old instance, revoke its scoped R2 credentials, and release storage."""
    # Revoke job-scoped R2 credentials for the old node first
    if broker._r2_minter:
        broker._r2_minter.revoke_cached(job.job_id)
    try:
        if old_provider == Provider.RUNPOD:
            import aiohttp
            _cfg = broker._get_provider_config("runpod")
            if _cfg:
                async with aiohttp.ClientSession() as s:
                    await s.delete(
                        f"https://rest.runpod.io/v1/pods/{old_instance_id}",
                        headers={"Authorization": f"Bearer {_cfg.api_key}"},
                    )
        elif old_provider == Provider.LAMBDA_LABS:
            import aiohttp
            _cfg = broker._get_provider_config("lambda_labs")
            if _cfg:
                async with aiohttp.ClientSession() as s:
                    await s.post(
                        f"{_cfg.base_url}/instance-operations/terminate",
                        headers={"Authorization": f"Basic {_cfg.api_key}"},
                        json={"instance_ids": [old_instance_id]},
                    )
        elif old_provider == Provider.VAST_AI:
            import aiohttp
            _cfg = broker._get_provider_config("vast_ai")
            if _cfg:
                async with aiohttp.ClientSession() as s:
                    await s.delete(
                        f"https://console.vast.ai/api/v0/instances/{old_instance_id}/",
                        headers={"Authorization": f"Bearer {_cfg.api_key}"},
                    )
        elif old_provider == Provider.AWS:
            ec2 = broker._sts.get_ec2_client(job_id=job.job_id, region=broker.config.aws.region)
            ec2.terminate_instances(InstanceIds=[old_instance_id])
            # GAP-22: release EIPs
            try:
                addrs = ec2.describe_addresses(
                    Filters=[{"Name": "instance-id", "Values": [old_instance_id]}]
                )
                for eip in addrs.get("Addresses", []):
                    alloc_id = eip.get("AllocationId")
                    if alloc_id:
                        try:
                            ec2.release_address(AllocationId=alloc_id)
                            logger.info(f"[Broker] Released EIP {alloc_id} for instance {old_instance_id}")
                        except Exception as _eip_err:
                            logger.warning(f"[Broker] Failed to release EIP {alloc_id}: {_eip_err}")
            except Exception as _eip_list_err:
                logger.warning(f"[Broker] Failed to describe EIPs for instance {old_instance_id}: {_eip_list_err}")
            # GAP-22: wait up to 30s for volumes to become available, then delete non-root volumes
            _root_devices = {"/dev/xvda", "/dev/sda1"}
            _vol_deadline = time.monotonic() + 30
            while time.monotonic() < _vol_deadline:
                try:
                    vols = ec2.describe_volumes(
                        Filters=[{"Name": "attachment.instance-id", "Values": [old_instance_id]}]
                    )
                    remaining = [v for v in vols.get("Volumes", []) if v.get("State") != "available"]
                    if not remaining:
                        break
                except Exception:
                    break
                await asyncio.sleep(5)
            try:
                vols = ec2.describe_volumes(
                    Filters=[{"Name": "attachment.instance-id", "Values": [old_instance_id]}]
                )
                for vol in vols.get("Volumes", []):
                    if vol.get("State") != "available":
                        continue
                    attachments = vol.get("Attachments", [])
                    device = attachments[0].get("Device", "") if attachments else ""
                    if device in _root_devices:
                        continue
                    delete_on_term = attachments[0].get("DeleteOnTermination", True) if attachments else True
                    if delete_on_term:
                        continue
                    vol_id = vol["VolumeId"]
                    try:
                        ec2.delete_volume(VolumeId=vol_id)
                        logger.info(f"[Broker] Deleted EBS volume {vol_id} (device={device}) for instance {old_instance_id}")
                    except Exception as _del_err:
                        logger.warning(f"[Broker] Failed to delete EBS volume {vol_id}: {_del_err}")
            except Exception as _vol_err:
                logger.warning(f"[Broker] Failed to describe/delete EBS volumes for instance {old_instance_id}: {_vol_err}")
        elif old_provider == Provider.GCP:
            if broker.config.gcp:
                try:
                    from google.oauth2 import service_account
                    from googleapiclient import discovery
                    _gcp = broker.config.gcp
                    _creds = service_account.Credentials.from_service_account_file(
                        _gcp.service_account_json,
                        scopes=["https://www.googleapis.com/auth/compute"],
                    )
                    _compute = discovery.build("compute", "v1", credentials=_creds)
                    _compute.instances().delete(
                        project=_gcp.project_id, zone=_gcp.zone, instance=old_instance_id,
                    ).execute()
                except Exception as _gcp_err:
                    logger.warning(f"[Broker] GCP instance delete failed for {old_instance_id}: {_gcp_err}")
        elif old_provider == Provider.AZURE:
            if broker.config.azure:
                try:
                    from azure.identity import ClientSecretCredential
                    from azure.mgmt.compute import ComputeManagementClient
                    from azure.mgmt.network import NetworkManagementClient
                    _az = broker.config.azure
                    _az_cred = ClientSecretCredential(
                        tenant_id=_az.tenant_id, client_id=_az.client_id, client_secret=_az.client_secret,
                    )
                    _vm_name = old_instance_id.split("/")[0]
                    _rg = _az.resource_group
                    _cc = ComputeManagementClient(_az_cred, _az.subscription_id)
                    _nc = NetworkManagementClient(_az_cred, _az.subscription_id)
                    _cc.virtual_machines.begin_delete(_rg, _vm_name).result()
                    for _res_del, _res_name in [
                        (_nc.network_interfaces,    f"{_vm_name}-nic"),
                        (_nc.public_ip_addresses,   f"{_vm_name}-pip"),
                        (_nc.virtual_networks,      f"{_vm_name}-vnet"),
                    ]:
                        try:
                            _res_del.begin_delete(_rg, _res_name).result()
                        except Exception:
                            pass
                except Exception as _az_err:
                    logger.warning(f"[Broker] Azure VM delete failed for {old_instance_id}: {_az_err}")
        logger.info(f"[Broker] Cleaned up old {old_provider} instance {old_instance_id}")
    except Exception as e:
        logger.warning(f"[Broker] Storage cleanup failed for {old_instance_id}: {e}")
