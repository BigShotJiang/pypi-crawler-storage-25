"""
SSH / node interaction helpers extracted from BrokerAgent.

All functions take `broker` (a BrokerAgent instance) as their first parameter
so they can access config, queue, and other broker state.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import shlex
import time
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from agents.broker.agent import BrokerAgent
    from shared.models import Job, Provider

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lazy paramiko import — mirrors agent.py pattern
# ---------------------------------------------------------------------------
_paramiko = None
try:
    import paramiko as _paramiko
    _HAS_PARAMIKO = True
except ImportError:
    _HAS_PARAMIKO = False


def parse_command(command) -> list:
    """Safely parse command into list: handles list, JSON string, or plain string."""
    if isinstance(command, list):
        return command
    if isinstance(command, str):
        try:
            parsed = json.loads(command)
            if isinstance(parsed, list):
                return [str(c) for c in parsed]
        except (json.JSONDecodeError, ValueError):
            logger.debug(f"[Broker] command is not JSON, treating as shell string: {command[:80]!r}")
        return shlex.split(command)
    return [str(command)]


async def wait_for_ssh(broker: "BrokerAgent", host: str, timeout: int = 180) -> bool:
    """
    Poll SSH port 22 until reachable, using exponential backoff.

    Backoff schedule: 1s -> 2s -> 4s -> 8s -> 16s -> 30s (capped) for the
    remaining deadline.  This reduces noise during the first few seconds
    when the instance is still booting, while still detecting readiness
    quickly once the SSH daemon starts.
    """
    import socket
    deadline = time.monotonic() + timeout
    delay = 1.0
    attempt = 0
    while time.monotonic() < deadline:
        try:
            sock = socket.create_connection((host, 22), timeout=3)
            sock.close()
            logger.info(f"SSH reachable on {host} after {attempt} retries")
            return True
        except (socket.timeout, ConnectionRefusedError, OSError):
            attempt += 1
            remaining = deadline - time.monotonic()
            wait = min(delay, 30.0, remaining)
            if wait <= 0:
                break
            logger.debug(f"SSH not yet reachable on {host} (attempt {attempt}), retrying in {wait:.0f}s")
            await asyncio.sleep(wait)
            delay = min(delay * 2, 30.0)  # double each round, cap at 30s
    logger.error(f"SSH not reachable on {host} after {timeout}s ({attempt} attempts)")
    return False


async def ssh_exec(broker: "BrokerAgent", host: str, ssh_key: str, cmd: str, timeout: float = 30.0) -> str:
    """Execute a shell command via SSH. Returns stdout string."""
    if not _HAS_PARAMIKO:
        raise RuntimeError("paramiko unavailable -- cannot SSH exec")
    client = _paramiko.SSHClient()
    client.set_missing_host_key_policy(_paramiko.AutoAddPolicy())
    client.connect(host, username="ubuntu", key_filename=ssh_key, timeout=15)
    try:
        _, stdout, _ = client.exec_command(cmd, timeout=timeout)
        out = stdout.read().decode("utf-8", errors="replace")
    finally:
        client.close()
    return out


async def resolve_instance_host(broker: "BrokerAgent", instance_id: str, provider: "Provider") -> Optional[str]:
    """Attempt to resolve the public hostname/IP for an instance. Returns None if unknown."""
    from shared.models import Provider as Prov
    try:
        if provider == Prov.AWS:
            ec2 = broker._sts.get_ec2_client(job_id="resolve", region=broker.config.aws.region)
            desc = ec2.describe_instances(InstanceIds=[instance_id])
            inst = desc["Reservations"][0]["Instances"][0]
            return inst.get("PublicIpAddress") or inst.get("PrivateIpAddress")
        if provider == Prov.AZURE:
            # Azure instance_id is encoded as "vm_name/public_ip" by provision_azure()
            if "/" in instance_id:
                return instance_id.split("/", 1)[1]
        if provider == Prov.NEBIUS:
            return await _resolve_nebius_host(broker, instance_id)
    except Exception as e:
        logger.debug(f"_resolve_instance_host failed for {instance_id}: {e}")
    return None


async def _resolve_nebius_host(broker, instance_id: str) -> Optional[str]:
    """Query Nebius InstanceService/Get for the public IP of an instance.

    Uses the nebius Python SDK (gRPC). Requires the IAM token from the broker's
    nebius credentials — same flow as provision/fence.

    The public IP is in instance.status.network_interfaces[0].public_ip_address.address
    (assigned after the instance reaches RUNNING state).
    """
    try:
        from agents.broker.providers.nebius import _get_iam_token, _make_cfg
        from nebius.sdk import SDK
        from nebius.api.nebius.compute.v1 import InstanceServiceClient, GetInstanceRequest

        _cfg = broker._get_provider_config("nebius")
        if not _cfg:
            _managed = await broker._get_managed_credentials("nebius", instance_id)
            if not _managed:
                logger.debug("[nebius] no credentials for resolve_host(%s)", instance_id)
                return None
            _cfg = _make_cfg(_managed)

        iam_token = await _get_iam_token(broker, _cfg)
        if not iam_token:
            return None

        async with SDK(credentials=iam_token) as sdk:
            svc = InstanceServiceClient(sdk)
            inst = await svc.get(GetInstanceRequest(id=instance_id))

        # Walk the status network interfaces to find a public IP.
        # Field path: instance.status.network_interfaces[].public_ip_address.address
        status = getattr(inst, "status", None)
        for ni in getattr(status, "network_interfaces", []) or []:
            pub = getattr(ni, "public_ip_address", None)
            addr = getattr(pub, "address", None)
            if addr:
                logger.debug("[nebius] resolved %s → %s", instance_id, addr)
                return addr

        logger.debug("[nebius] instance %s has no public IP yet", instance_id)
        return None

    except ImportError:
        logger.debug("[nebius] SDK not installed — cannot resolve host for %s", instance_id)
        return None
    except Exception as e:
        logger.debug("[nebius] resolve_host(%s) failed: %s", instance_id, e)
        return None


async def wait_for_image_ready(
    broker: "BrokerAgent",
    host: str,
    ssh_key: str,
    job: "Job",
    poll_interval: int = 10,
    timeout: int = 600,
) -> bool:
    """
    Wait until the background docker pull (started in UserData) completes.

    UserData backgrounds the pull with:
        (docker pull {image} && touch /tmp/vl_image_ready) &
    This method polls for the sentinel file.  Returns True when ready,
    False if the timeout is reached (600s = 10 min -- larger than any
    realistic pull time, so False is a genuine failure signal).

    Why this matters for the cold-start race:
      - UserData starts docker pull the moment the node boots (before SSH opens)
      - Checkpoint prefetch runs in parallel over SSH as soon as SSH is up
      - This gate ensures training only starts after BOTH are ready
      - Net effect: training starts as soon as max(docker_pull, ckpt_prefetch)
        finishes, instead of docker_pull + ckpt_prefetch in sequence

    Skipped if job has no docker_image or uses a pre-baked AMI.
    """
    if not job.docker_image:
        return True

    elapsed = 0
    while elapsed < timeout:
        try:
            result = await asyncio.wait_for(
                broker._ssh_exec(host, ssh_key, "test -f /tmp/vl_image_ready && echo READY || echo WAITING"),
                timeout=15.0,
            )
            if "READY" in (result or ""):
                logger.info(f"[Broker] Docker image ready on {host} for job {job.job_id}")
                return True
        except Exception:
            pass
        await asyncio.sleep(poll_interval)
        elapsed += poll_interval
        logger.debug(f"[Broker] Waiting for docker image on {host} ({elapsed}s elapsed)...")

    logger.warning(
        f"[Broker] Docker image not ready after {timeout}s on {host} for job {job.job_id}. "
        f"Check /tmp/vl_docker_pull.log on the node."
    )
    return False


async def wait_for_bootstrap(
    broker: "BrokerAgent",
    host: str,
    ssh_key: str,
    job: "Job",
    timeout: int = 300,
) -> bool:
    """
    P0-L2: Poll for /tmp/vl_bootstrap_done sentinel written at the end of
    _build_userdata() and _build_container_onstart().

    Replaces the blind `await asyncio.sleep(30)` that previously separated
    provisioning from the restore signal.  On a pre-warmed node where bootstrap
    already finished, this returns in one poll interval (<5s).  On a slow cold
    start it waits up to `timeout` seconds before proceeding anyway (non-blocking
    on failure -- we still attempt migration rather than abandoning the node).

    Polls with exponential back-off: 2, 4, 8, 16, 30s (capped).
    """
    intervals = [2, 4, 8, 16, 30]
    elapsed = 0
    poll_idx = 0
    while elapsed < timeout:
        try:
            result = await asyncio.wait_for(
                broker._ssh_exec(
                    host, ssh_key,
                    "test -f /tmp/vl_bootstrap_done && echo DONE || echo WAITING",
                ),
                timeout=10.0,
            )
            if "DONE" in (result or ""):
                logger.info(
                    f"[Broker] Bootstrap sentinel confirmed on {host} "
                    f"for job {job.job_id} ({elapsed}s elapsed)"
                )
                return True
        except Exception as _e:
            logger.debug(f"[Broker] Bootstrap poll error on {host}: {_e}")

        interval = intervals[min(poll_idx, len(intervals) - 1)]
        poll_idx += 1
        await asyncio.sleep(interval)
        elapsed += interval
        logger.debug(
            f"[Broker] Waiting for bootstrap on {host} "
            f"({elapsed}s / {timeout}s)..."
        )

    logger.warning(
        f"[Broker] Bootstrap sentinel not seen after {timeout}s on {host} "
        f"for job {job.job_id} -- proceeding anyway (bootstrap may still be running)"
    )
    return False


async def prefetch_checkpoint(broker: "BrokerAgent", host: str, ssh_key: str, job: "Job", resume_checkpoint: str) -> None:
    """Download checkpoint from R2 to node NVMe (Rule 3 -- cache-first resume).

    Downloads synchronously (foreground rclone, not nohup) to local NVMe so
    that when _restart_job_on_node() launches training the checkpoint is
    immediately available from disk, not from R2 over the network.

    The sentinel file $VL_DATA_ROOT/vl-checkpoints/{job_id}/.vl_ckpt_ready
    is written after a successful download.  _restart_job_on_node() polls this
    sentinel before launching the training command.

    Download path: $VL_DATA_ROOT/vl-checkpoints/{job_id}/
      - VL_DATA_ROOT=/mnt/nvme on nodes with instance-store NVMe (set by UserData)
      - VL_DATA_ROOT=/tmp on nodes without NVMe (fallback)
    """
    try:
        # The rclone config was written to /tmp/vaultlayer-rclone.conf by UserData.
        # Use that, not the control-plane's ~/.config/rclone/rclone.conf.
        _cf = broker.config.cloudflare
        _r2_bucket = _cf.r2_bucket if _cf else ""
        cmd = (
            # Resolve VL_DATA_ROOT -- set by UserData, default /tmp if missing
            "VL_DATA_ROOT=${VL_DATA_ROOT:-/tmp} && "
            f"VL_CKPT_DIR=$VL_DATA_ROOT/vl-checkpoints/{job.job_id} && "
            "mkdir -p $VL_CKPT_DIR && "
            # Synchronous copy -- training must NOT start until this completes
            f"rclone copy "
            f"r2:{_r2_bucket}/{resume_checkpoint} "
            "$VL_CKPT_DIR/ "
            "--config /tmp/vaultlayer-rclone.conf "
            "--transfers 16 --checkers 8 "
            "--progress && "
            # Sentinel: _restart_job_on_node() polls for this file
            "touch $VL_CKPT_DIR/.vl_ckpt_ready && "
            "echo '[VaultLayer] Checkpoint prefetch complete: '$VL_CKPT_DIR"
        )
        await broker._ssh_exec(host, ssh_key, cmd)
        logger.info(
            f"[Broker] Checkpoint prefetch complete on NVMe for {job.job_id}"
        )
    except Exception as e:
        logger.warning(f"[Broker] Checkpoint pre-fetch failed (non-fatal): {e}")


async def probe_cuda(
    broker: "BrokerAgent",
    host: str,
    ssh_key: str,
    min_driver_version: str = "525.0",
    job: Optional["Job"] = None,
) -> tuple[bool, str]:
    """
    Run a 10-second CUDA probe on the target node via SSH.

    Executes `nvidia-smi --query-gpu=driver_version --format=csv,noheader` and
    compares the result against min_driver_version.  Returns (compatible, version_string).

    Failures are non-blocking: if SSH is unavailable or paramiko is missing this returns
    (True, "unknown") so the migration can still proceed -- the failure is logged as a warning.
    """
    from shared.models import EventType
    from shared.queue import make_event

    if not _HAS_PARAMIKO:
        logger.warning(f"_probe_cuda: paramiko unavailable, skipping CUDA probe on {host}")
        return True, "unknown"
    try:
        client = _paramiko.SSHClient()
        client.set_missing_host_key_policy(_paramiko.AutoAddPolicy())
        client.connect(host, username="ubuntu", key_filename=ssh_key, timeout=15)
        _, stdout, stderr = client.exec_command(
            "nvidia-smi --query-gpu=driver_version --format=csv,noheader",
            timeout=10,
        )
        out = stdout.read().decode().strip()
        err = stderr.read().decode().strip()
        # GAP-19: also query compute capability
        _, cc_stdout, _ = client.exec_command(
            "nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -1",
            timeout=10,
        )
        cc_out = cc_stdout.read().decode().strip()
        client.close()
        if not out:
            logger.warning(f"_probe_cuda: nvidia-smi returned no output on {host} (stderr: {err})")
            return False, "none"
        # Take the first GPU's driver version
        detected = out.splitlines()[0].strip()
        # Parse compute capability (e.g. "8.0" for A100, "9.0" for H100)
        compute_cap = cc_out.splitlines()[0].strip() if cc_out else None
        cc_float = None
        if compute_cap:
            try:
                cc_float = float(compute_cap)
                logger.info(f"CUDA probe: compute_cap={cc_float} on {host}")
            except ValueError:
                compute_cap = None
        # GAP-19: store original arch on first node; warn on downgrade for subsequent nodes
        if cc_float is not None and job is not None:
            if not job.source_compute_cap:
                job.source_compute_cap = cc_float
                logger.info(
                    f"[Broker] Source GPU arch recorded: sm_{cc_float} for job {job.job_id}"
                )
            elif cc_float < job.source_compute_cap:
                logger.warning(
                    f"[Broker] GPU arch downgrade detected for job {job.job_id}: "
                    f"sm_{job.source_compute_cap} -> sm_{cc_float} on {host}. "
                    "Compiled CUDA kernels may not run correctly on the lower arch."
                )
                asyncio.get_event_loop().call_soon(
                    lambda: asyncio.ensure_future(
                        broker.queue.publish("pricing", make_event(
                            event_type=EventType.ARBITRAGE_OPPORTUNITY,
                            source_agent=broker.AGENT_NAME,
                            job_id=job.job_id,
                            payload={
                                "warning": "gpu_arch_downgrade",
                                "source_compute_cap": job.source_compute_cap,
                                "target_compute_cap": cc_float,
                                "host": host,
                                "savings_score": -1.0,
                            },
                            priority=3,
                        ))
                    )
                )
        # Compare as float tuples (e.g. "535.104.05" -> (535, 104, 5))
        def _ver(v: str):
            parts = v.split(".")
            try:
                return tuple(int(x) for x in parts[:2])
            except ValueError:
                return (0, 0)
        if _ver(detected) >= _ver(min_driver_version):
            logger.info(f"CUDA probe passed on {host}: driver={detected} >= min={min_driver_version}")
            return True, detected
        else:
            logger.warning(
                f"CUDA probe FAILED on {host}: driver={detected} < min={min_driver_version}. "
                "Migration may encounter CUDA_ERROR_UNKNOWN at runtime."
            )
            return False, detected
    except Exception as e:
        logger.warning(f"_probe_cuda: SSH probe failed on {host}: {e} -- proceeding with caution")
        return True, "unknown"


async def restart_job_on_node(
    broker: "BrokerAgent",
    host: str,
    ssh_key: str,
    command,
    job_id: str,
    resume_checkpoint: str = "",
) -> bool:
    """SSH into new node and restart training job with checkpoint resume."""
    from shared.models import EventType
    from shared.queue import make_event

    if not _HAS_PARAMIKO:
        logger.warning("paramiko unavailable -- publishing RESUME_JOB event")
        await broker.queue.publish("broker", make_event(
            EventType.NODE_PROVISIONED, broker.AGENT_NAME, job_id,
            payload={"command": "resume_job", "host": host,
                     "training_command": parse_command(command),
                     "resume_checkpoint": resume_checkpoint},
            priority=1))
        return False
    try:
        client = _paramiko.SSHClient()
        client.set_missing_host_key_policy(_paramiko.AutoAddPolicy())
        client.connect(host, username="ubuntu", key_filename=ssh_key, timeout=30)
        # Rule 2: Set VAULTLAYER_API_URL so the training script's
        # _notify_checkpoint() and _send_heartbeat() can reach the control
        # plane rather than silently failing at localhost:8765 (which doesn't
        # exist on the GPU node after migration).
        _api_url = os.environ.get("VAULTLAYER_API_URL", "")
        env_prefix = (
            f"export VAULTLAYER_JOB_ID={job_id} && "
            # Rule 1: VL_DATA_ROOT is set by UserData; expose it so
            # vaultlayer_checkpoint.py picks the NVMe path automatically.
            "export VL_DATA_ROOT=${VL_DATA_ROOT:-/tmp} && "
            f"export CHECKPOINT_DIR=${{VL_DATA_ROOT:-/tmp}}/vl-checkpoints && "
        )
        if _api_url:
            env_prefix += f"export VAULTLAYER_API_URL={_api_url} && "
        if resume_checkpoint:
            # Rule 3: Wait for the NVMe checkpoint sentinel before launching.
            # _prefetch_checkpoint() downloads from R2 to NVMe and writes
            # $VL_DATA_ROOT/vl-checkpoints/{job_id}/.vl_ckpt_ready when done.
            _sentinel = resume_checkpoint.rstrip("/") + "/.vl_ckpt_ready"
            env_prefix += (
                f"echo '[VaultLayer] Waiting for NVMe checkpoint sentinel...' && "
                f"for _vl_i in $(seq 1 60); do "
                f"  [ -f {_sentinel} ] && break || sleep 5; "
                f"done && "
                f"[ -f {_sentinel} ] || echo '[VaultLayer] WARNING: checkpoint sentinel not found, proceeding anyway' && "
            )
            # Resolve the latest concrete checkpoint inside the job root dir.
            # resume_checkpoint points at the job-level root (e.g.
            # $VL_DATA_ROOT/vl-checkpoints/<job_id>), not the specific step.
            # Exporting the root directly causes torch.load() to receive a
            # directory, or HF Trainer to miss the concrete checkpoint-<N>/ dir.
            # Mirror startup_scripts.py:308-311 format detection:
            #   1. HF-style checkpoint-N/ — pick highest N
            #   2. Raw step-N/checkpoint.pt — pick highest N
            #   3. Fallback to root if neither format is found
            _ckpt_root = resume_checkpoint.rstrip("/")
            env_prefix += (
                f"_VL_CKPT_ROOT={_ckpt_root} && "
                "_VL_LATEST_RESUME='' && "
                "_VL_HF_NAME=$(ls -1d \"$_VL_CKPT_ROOT\"/checkpoint-[0-9]* 2>/dev/null | "
                "  awk -F/ '{print $NF}' | sort -t- -k2,2n | tail -1) && "
                "[ -n \"$_VL_HF_NAME\" ] && [ -d \"$_VL_CKPT_ROOT/$_VL_HF_NAME\" ] && "
                "_VL_LATEST_RESUME=\"$_VL_CKPT_ROOT/$_VL_HF_NAME\" || true && "
                "if [ -z \"$_VL_LATEST_RESUME\" ]; then "
                "  _VL_RAW_NAME=$(ls -1d \"$_VL_CKPT_ROOT\"/step-[0-9]* 2>/dev/null | "
                "    awk -F/ '{print $NF}' | sort -t- -k2,2n | tail -1); "
                "  [ -n \"$_VL_RAW_NAME\" ] && [ -f \"$_VL_CKPT_ROOT/$_VL_RAW_NAME/checkpoint.pt\" ] && "
                "  _VL_LATEST_RESUME=\"$_VL_CKPT_ROOT/$_VL_RAW_NAME/checkpoint.pt\" || true; "
                "fi && "
                "[ -n \"$_VL_LATEST_RESUME\" ] && _VL_RESOLVED_CKPT=$_VL_LATEST_RESUME"
                f" || _VL_RESOLVED_CKPT={_ckpt_root} && "
                "export VAULTLAYER_RESUME_CHECKPOINT=$_VL_RESOLVED_CKPT && "
                "export RESUME_FROM_CHECKPOINT=$_VL_RESOLVED_CKPT && "
                "echo '[VaultLayer] Resume checkpoint resolved: '$_VL_RESOLVED_CKPT && "
            )
            # -- Zero-code-change resume hook injection --
            # Write a sitecustomize.py to /tmp/vl_hook on the remote node.
            # Python imports sitecustomize before user code, so torch.nn.Module
            # gets patched before train.py runs -- checkpoint loads on first forward
            # even if the user's script has no explicit load_state_dict() call.
            hook_script = (
                "import os, sys; "
                "os.environ.setdefault('VAULTLAYER_RESUME_CHECKPOINT', "
                f"'{resume_checkpoint}'); "
                "sys.path.insert(0, '/workspace/vaultlayer/src') "
                "if '/workspace/vaultlayer/src' not in sys.path else None; "
                "exec(open('/workspace/vaultlayer/src/vaultlayer/_resume_hook.py').read()) "
                "if __import__('os').path.exists('/workspace/vaultlayer/src/vaultlayer/_resume_hook.py') else None"
            )
            env_prefix += (
                "mkdir -p /tmp/vl_hook && "
                f"printf {shlex.quote(hook_script)} > /tmp/vl_hook/sitecustomize.py && "
                "export PYTHONPATH=/tmp/vl_hook:${PYTHONPATH:-} && "
            )
        # shlex.quote each arg to handle spaces/special chars safely
        cmd_parts = parse_command(command)
        cmd_str = env_prefix + " ".join(shlex.quote(str(c)) for c in cmd_parts)
        full_cmd = f"nohup bash -c {shlex.quote(cmd_str)} >> /tmp/vaultlayer.log 2>&1 &"
        stdin, stdout, stderr = client.exec_command(full_cmd)
        exit_code = stdout.channel.recv_exit_status()
        client.close()
        logger.info(f"Job {job_id} restarted on {host} (exit={exit_code})")
        return exit_code == 0
    except Exception as e:
        logger.error(f"SSH restart failed on {host}: {e}")
        return False
