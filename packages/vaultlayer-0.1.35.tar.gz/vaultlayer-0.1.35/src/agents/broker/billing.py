"""
Billing / spend recording helpers extracted from BrokerAgent.

All functions take `broker` (a BrokerAgent instance) as their first parameter
so they can access config, queue, and other broker state.
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from agents.broker.agent import BrokerAgent
    from shared.models import Job

logger = logging.getLogger(__name__)


def record_provision_spend(
    broker: "BrokerAgent",
    job: "Job",
    provider: str,
    gpu_type: str,
    instance_id: str,
    provisioned_at: datetime,
    rate_per_hr: float,
    is_test: bool = False,
    is_hop_leg: bool = False,
    migrated_from_run_id: str | None = None,
) -> None:
    """Record a provision event to spend_ledger + job_runs and store IDs.

    Non-fatal -- a DB failure must never abort provisioning.
    The spend_id is stored in broker._spend_ids[instance_id] and
    run_id in broker._run_ids[instance_id] so _hard_fence_and_confirm()
    can settle and close both records on termination.

    is_hop_leg: True when this leg was created by execute_migration() (Tier 3 markup).
    migrated_from_run_id: run_id of the previous leg in the hop chain.
    """
    run_type = "smoke_test" if is_test else "real"
    account_id = getattr(job, "user_id", "") or getattr(job, "account_id", "") or ""

    # -- Compute per-leg tier markup --
    try:
        from shared.compute_tiers import get_leg_tier
        _failover = getattr(job, "failover_enabled", True)
        _tier_num, _tier_markup, _tier_label = get_leg_tier(
            gpu_type, is_hop_leg, failover_enabled=_failover,
        )
    except Exception:
        _tier_num, _tier_markup, _tier_label = 1, 0.20, "Standard"

    # -- spend_ledger row --
    try:
        from shared.spend import record_provision
        spend_id = record_provision(
            job_id=job.job_id,
            provider=provider,
            gpu_type=gpu_type,
            instance_id=instance_id,
            provisioned_at=provisioned_at,
            rate_per_hr=rate_per_hr,
            user_id=account_id,
            is_test=is_test,
            metadata={"provider_tag": provider, "job_name": getattr(job, "name", ""),
                      "compute_tier": _tier_num, "compute_tier_label": _tier_label},
            vl_margin_pct=_tier_markup,
        )
        if spend_id:
            broker._spend_ids[instance_id] = spend_id
    except Exception as e:
        logger.warning(f"[Broker] spend record_provision failed (non-fatal): {e}")
        spend_id = None

    # -- job_runs row --
    try:
        from shared.job_run_logger import open_run
        run_id = open_run(
            job_id=job.job_id,
            provider=provider,
            gpu_type=gpu_type,
            instance_id=instance_id,
            provisioned_at=provisioned_at,
            rate_per_hr=rate_per_hr,
            run_type=run_type,
            account_id=account_id,
            job_name=getattr(job, "name", "") or getattr(job, "job_id", ""),
            command=getattr(job, "command", "") or "",
            docker_image=getattr(job, "docker_image", "") or "",
            model_params_billion=getattr(job, "model_params_billion", None) or None,
            training_mode=getattr(job, "training_mode", None) or None,
            dataset_size_gb=getattr(job, "dataset_size_gb", None) or None,
            gpu_count=getattr(job, "gpu_count", 1) or 1,
            region=getattr(job, "region", "") or "",
            job_triggered_at=getattr(job, "started_at", None),
            spend_ledger_id=spend_id,
            migrated_from_run_id=migrated_from_run_id,
            metadata={"provider_tag": provider,
                      "compute_tier": _tier_num, "compute_tier_label": _tier_label},
        )
        if run_id:
            broker._run_ids[instance_id] = run_id
    except Exception as e:
        logger.warning(f"[Broker] job_runs open_run failed (non-fatal): {e}")

    # -- cache provision info for billing at close time --
    broker._provision_info[instance_id] = {
        "rate_per_hr":      rate_per_hr,
        "provisioned_at":   provisioned_at,
        "job_triggered_at": getattr(job, "started_at", None),
    }


def get_live_price(broker: "BrokerAgent", provider, gpu_type):
    """Return live price for a provider/gpu combination."""
    from shared.data_loader import get_provider_prices
    try:
        for p in get_provider_prices():
            prov = p.provider if hasattr(p, "provider") else p.get("provider", "")
            gpu = p.gpu if hasattr(p, "gpu") else p.get("gpu", "")
            price = p.price_per_hr if hasattr(p, "price_per_hr") else p.get("price_per_hr")
            if str(prov) == str(provider) and str(gpu) == str(gpu_type):
                return price
    except Exception:
        pass
    return None


def get_user_charge(
    broker: "BrokerAgent",
    provider_name: str,
    gpu_key: str,
    baseline_provider: Optional[str] = None,
) -> Optional[float]:
    """
    Return the VaultLayer user-facing charge using the gainshare model.
    baseline_provider: the provider the user is migrating FROM (anchor source).
    Falls back to flat VL_MARGIN if gainshare cannot be computed.
    """
    from shared.price_guard import compute_user_charge, VL_MARGIN
    live = get_live_price(broker, provider_name, gpu_key)
    if not live or live <= 0:
        return None
    try:
        result = compute_user_charge(
            provider=baseline_provider or provider_name,
            gpu=gpu_key,
            sourced_cost_per_hr=live,
        )
        return result["user_billed_rate"]
    except Exception:
        return round(live * VL_MARGIN, 2)
