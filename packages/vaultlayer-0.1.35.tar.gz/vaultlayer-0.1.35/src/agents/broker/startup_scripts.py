"""Startup script builders for VM and container providers."""
from __future__ import annotations

import base64
import logging
import shlex
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from shared.models import Job

logger = logging.getLogger(__name__)


def get_r2_credentials_for_node(broker, job: "Job") -> tuple[str, str, str]:
    """
    Return (access_key_id, secret_access_key, session_token) for a GPU node.

    Security model:
      - When CF_MASTER_TOKEN is configured: mint a short-lived prefix-scoped
        token restricted to jobs/{job.job_id}/.  The node can ONLY access
        its own prefix — cross-job reads return 403 at the Cloudflare edge.
      - Fallback (self-hosted / CF_MASTER_TOKEN absent): use master R2 keys.
        Suitable for single-tenant deployments; not recommended for multi-tenant SaaS.
    """
    if broker._r2_minter:
        try:
            # Security: only include dataset prefix from the server-side job.dataset_id
            # field — NEVER from job.environment["VAULTLAYER_DATASET_ID"].  The environment
            # dict is user-provided and could name any dataset prefix, enabling
            # cross-tenant reads/writes if the ID is accepted blindly.
            # job.dataset_id is set by the API after server-side ownership validation.
            _dataset_id = getattr(job, "dataset_id", None)
            _extra = [f"datasets/{_dataset_id}/"] if _dataset_id else []
            creds = broker._r2_minter.mint(job.job_id, extra_prefixes=_extra)
            logger.info(
                f"[Broker] Job-scoped R2 credentials minted for {job.job_id} "
                f"(prefixes=checkpoints/{job.job_id}/" + (f",datasets/{_dataset_id}/" if _dataset_id else "") +
                f", expires_in={int(creds.expires_at - __import__('time').time()//1)}s)"
            )
            return creds.access_key_id, creds.secret_access_key, creds.session_token
        except Exception as e:
            logger.error(
                f"[Broker] Failed to mint scoped R2 credentials for {job.job_id}: {e}. "
                f"Falling back to master keys (SECURITY DEGRADED — check CF_MASTER_TOKEN)"
            )
    # Fallback: master key, no session token
    if not broker.config.cloudflare:
        logger.warning(
            "[Broker] R2 credentials unavailable — cloudflare config not set. "
            "Startup script will omit R2 mount (checkpoint I/O disabled)."
        )
        return ("", "", "")
    return (
        broker.config.cloudflare.r2_access_key_id,
        broker.config.cloudflare.r2_secret_access_key,
        "",
    )


def _user_s3_mirror_lines(job_id: str, rclone_conf_path: str) -> list[str]:
    """Generate bash lines to mirror checkpoints to the user's own S3 bucket.

    Activates only when the GPU node has VL_S3_BUCKET + VL_S3_ACCESS_KEY_ID +
    VL_S3_SECRET_ACCESS_KEY in its environment — set via job.environment forwarding
    from run.py when the user ran `vaultlayer connect storage`.

    Writes a separate rclone config (/tmp/vl-user-s3-rclone.conf) so the R2 config
    is never touched. Non-fatal: a failed user-S3 sync only logs a warning; the
    primary R2 sync continues unaffected.

    Destination path: s3://<VL_S3_BUCKET>/vaultlayer-checkpoints/<job_id>/
    Supports AWS S3, and S3-compatible stores (MinIO, Cloudflare R2, etc.)
    when VL_S3_ENDPOINT is set.
    """
    return [
        "# ── Optional: mirror checkpoints to user's own S3 bucket ─────────────",
        "if [ -n \"$VL_S3_ACCESS_KEY_ID\" ] && [ -n \"$VL_S3_SECRET_ACCESS_KEY\" ] && [ -n \"$VL_S3_BUCKET\" ]; then",
        "  cat > /tmp/vl-user-s3-rclone.conf << 'VL_S3_RCLONE_EOF'",
        "[user-s3]",
        "type = s3",
        "VL_S3_RCLONE_EOF",
        "  if [ -n \"$VL_S3_ENDPOINT\" ]; then",
        "    echo 'provider = Other' >> /tmp/vl-user-s3-rclone.conf",
        "    echo \"endpoint = $VL_S3_ENDPOINT\" >> /tmp/vl-user-s3-rclone.conf",
        "  else",
        "    echo 'provider = AWS' >> /tmp/vl-user-s3-rclone.conf",
        "  fi",
        "  echo \"access_key_id = $VL_S3_ACCESS_KEY_ID\" >> /tmp/vl-user-s3-rclone.conf",
        "  echo \"secret_access_key = $VL_S3_SECRET_ACCESS_KEY\" >> /tmp/vl-user-s3-rclone.conf",
        "  echo \"region = ${VL_S3_REGION:-us-east-1}\" >> /tmp/vl-user-s3-rclone.conf",
        f"  echo '[VaultLayer] Mirroring checkpoints to user bucket: s3://$VL_S3_BUCKET/vaultlayer-checkpoints/{job_id}/'",
        f"  (while true; do rclone sync $CHECKPOINT_DIR user-s3:$VL_S3_BUCKET/vaultlayer-checkpoints/{job_id}/ "
        "--config /tmp/vl-user-s3-rclone.conf --transfers 4 --checkers 2 "
        "|| echo '[VaultLayer] WARN: user S3 mirror sync failed (non-fatal, R2 sync continues)'; "
        "sleep 60; done) &",
        "fi",
        "",
    ]


def _r2_credential_refresh_lines(job_id: str, rclone_conf_path: str) -> list[str]:
    """Generate node-side refresh loop for Cloudflare temporary credentials."""
    root_conf = "/root/.config/rclone/rclone.conf"
    copy_root = [
        "    os.makedirs('/root/.config/rclone', exist_ok=True)",
        f"    if config_path != {root_conf!r}:",
        f"        shutil.copyfile(config_path, {root_conf!r})",
    ]
    return [
        "# ── Refresh job-scoped R2 credentials before Cloudflare TTL expiry ──",
        "cat > /tmp/vl_refresh_r2_credentials.py << 'PY'",
        "import json, os, shutil, urllib.request",
        f"job_id = {job_id!r}",
        f"config_path = {rclone_conf_path!r}",
        "api = os.environ.get('VAULTLAYER_API_URL', 'https://vaultlayer-production.up.railway.app').rstrip('/')",
        "token = os.environ.get('VL_JOB_TOKEN', '')",
        "if not token:",
        "    raise SystemExit(0)",
        "payload = json.dumps({'job_id': job_id, 'ttl_seconds': 14400}).encode()",
        "req = urllib.request.Request(",
        "    api + '/api/v1/jobs/credentials',",
        "    data=payload,",
        "    headers={'X-Job-Token': token, 'Content-Type': 'application/json'},",
        ")",
        "with urllib.request.urlopen(req, timeout=20) as resp:",
        "    body = json.loads(resp.read().decode('utf-8'))",
        "session_token = body.get('r2_session_token') or ''",
        "tmp_path = config_path + '.tmp'",
        "with open(tmp_path, 'w') as f:",
        "    f.write('[r2]\\n')",
        "    f.write('type = s3\\n')",
        "    f.write('provider = Cloudflare\\n')",
        "    f.write('access_key_id = ' + body['r2_access_key_id'] + '\\n')",
        "    f.write('secret_access_key = ' + body['r2_secret_access_key'] + '\\n')",
        "    if session_token:",
        "        f.write('session_token = ' + session_token + '\\n')",
        "    f.write('endpoint = ' + body.get('r2_endpoint', '') + '\\n')",
        "os.replace(tmp_path, config_path)",
        "try:",
        *copy_root,
        "except Exception:",
        "    pass",
        "print('[VaultLayer] Refreshed R2 temporary credentials')",
        "PY",
        "(while true; do sleep 10800; "
        "python3 /tmp/vl_refresh_r2_credentials.py >> $_VL_LOG 2>&1 "
        "|| echo '[VaultLayer] WARN: R2 credential refresh failed' | tee -a $_VL_LOG; "
        "done) &",
        "",
    ]


def build_vm_startup_script(broker, job: "Job") -> str:
    """Generate a full startup script for VM-based providers (GCP, Azure, Lambda Labs,
    CoreWeave, Crusoe, Nebius, Hyperstack, Voltage Park).

    Mirrors _build_userdata() (AWS) but returns plain text (not base64-encoded).
    All 10 non-AWS VM providers receive the same bootstrap:
      1. Set VAULTLAYER_JOB_ID + job.environment
      2. NVMe detection + mount (or /tmp fallback)
      3. Install rclone + fuse3
      4. Write rclone R2 config with job-scoped temp credentials
      5. Mount R2 at /mnt/vaultlayer for CHECKPOINT I/O only
      6. Copy dataset shards from R2 to NVMe (if dataset_id set)
      7. Install Docker + background pull job.docker_image (if set)

    Security: calls get_r2_credentials_for_node() to mint job-scoped R2 tokens.
    Node receives only prefix  jobs/{job_id}/  — cross-job reads return 403.
    """
    # Mint scoped R2 credentials (same as _build_userdata for AWS)
    r2_key_id, r2_secret, r2_session_token = get_r2_credentials_for_node(broker, job)
    _cf = broker.config.cloudflare
    r2_endpoint = _cf.r2_endpoint if _cf else ""
    r2_bucket = _cf.r2_bucket if _cf else ""

    # Gap 4 fix: inject the VaultLayer SSH public key so the broker can SSH in
    # after provisioning. Required for all VM providers that use cloud-init
    # (Nebius, GCP, Azure, CoreWeave, Crusoe, Hyperstack, Voltage Park).
    # Set VL_SSH_PUBLIC_KEY on Railway to the contents of ~/.ssh/id_rsa.pub
    # (or whichever key matches VAULTLAYER_SSH_KEY_PATH on the broker).
    import os as _os
    _ssh_pub_key = _os.environ.get("VL_SSH_PUBLIC_KEY", "").strip()

    lines = [
        "#!/bin/bash",
        "# No set -e — handle errors gracefully so heartbeat/training still runs",
        "# even if NVMe detection, rclone install, or R2 mount fails.",
        "",
        "# ── VaultLayer VM bootstrap (all providers) ──────────────────────",
        f"export VAULTLAYER_JOB_ID={job.job_id}",
        f"echo VAULTLAYER_JOB_ID={job.job_id} >> /etc/environment",
        "",
    ]

    # Inject SSH public key for broker access. Non-fatal if key is absent —
    # log a warning so the operator knows SSH will likely fail.
    if _ssh_pub_key:
        lines += [
            "# ── VaultLayer SSH public key injection ─────────────────────────",
            "mkdir -p /root/.ssh && chmod 700 /root/.ssh",
            f"echo {shlex.quote(_ssh_pub_key)} >> /root/.ssh/authorized_keys",
            "chmod 600 /root/.ssh/authorized_keys",
            "# Also inject for ubuntu user (Nebius default user on Ubuntu images)",
            "mkdir -p /home/ubuntu/.ssh && chmod 700 /home/ubuntu/.ssh",
            f"echo {shlex.quote(_ssh_pub_key)} >> /home/ubuntu/.ssh/authorized_keys",
            "chmod 600 /home/ubuntu/.ssh/authorized_keys",
            "chown -R ubuntu:ubuntu /home/ubuntu/.ssh 2>/dev/null || true",
            "",
        ]
    else:
        lines += [
            "# WARNING: VL_SSH_PUBLIC_KEY not set — broker SSH access will fail.",
            "# Set VL_SSH_PUBLIC_KEY on Railway to enable SSH-based job management.",
            "",
        ]

    # Set job environment variables first so they're available to all steps
    # Shell-escape values to prevent command injection via user-controlled env vars
    for key, value in (job.environment or {}).items():
        _escaped = str(value).replace("'", "'\\''")
        lines += [f"export {key}='{_escaped}'", f"echo {key}='{_escaped}' >> /etc/environment"]

    lines += [
        "",
        "# ── Background heartbeat: posts logs to API every 30s ──────────────",
        "# MUST start BEFORE infrastructure setup (NVMe/rclone/R2) so the server",
        "# sees logs even if rclone install or FUSE mount hangs.",
        "_VL_LOG=/tmp/vaultlayer.log",
        "touch $_VL_LOG",
        "echo '[VaultLayer] VM bootstrap started' | tee -a $_VL_LOG",
        # ── Early-life curl probe ──
        # The Python-based heartbeat below only fires every 30s AND depends
        # on python3 + urllib + CA bundles being intact. On GCP's ubuntu-
        # accelerator AMI we've seen 20 min of 0 logs → platform stuck-
        # detector auto-fence (jobs caad81a0 / 82e558aa / d22638c8 on
        # 2026-04-19). This one-shot `curl` tells us whether the VM
        # userData actually executed at all: if this line reaches the API,
        # bootstrap is running and any silence afterward is a python/DNS/
        # SSL issue downstream; if it doesn't, userData never fired.
        # printf: single-quoted format string keeps JSON escapes literal; the
        # %s positional expands the shell-evaluated $(hostname). Nesting
        # $(...) directly inside single quotes leaves it literal (the bug
        # the initial version of this probe shipped with).
        f"_VL_EARLY_PAYLOAD=$(printf '{{\"lines\":[\"[VaultLayer] VM userData entered — early probe from %s\"],\"source\":\"bootstrap-probe\"}}' \"$(hostname 2>/dev/null || echo unknown)\")",
        f"curl -fsS -X POST "
        f"-H \"X-Job-Token: ${{VL_JOB_TOKEN:-}}\" -H \"Content-Type: application/json\" "
        f"-d \"$_VL_EARLY_PAYLOAD\" "
        f"\"${{VAULTLAYER_API_URL:-https://vaultlayer-production.up.railway.app}}/api/v1/jobs/{job.job_id}/logs\" "
        f">/dev/null 2>&1 && echo '[VaultLayer] early curl probe POSTed' >> $_VL_LOG "
        f"|| echo '[VaultLayer] early curl probe failed' >> $_VL_LOG",
        # Heartbeat: stream NEW log content only, tracking a byte offset in
        # /tmp/vl_log_offset. The previous design re-POSTed lines[-100:] every
        # 30s regardless of whether anything new appeared, and the API
        # endpoint has no dedup — job f9b88427 ended with 9 distinct lines
        # stored as 275 rows. On POST failure we do NOT advance the offset,
        # so the next tick retries the same span.
        "(while true; do",
        "  sleep 30",
        f"  python3 -c \"",
        f"import os, json, urllib.request",
        f"job_token = os.environ.get('VL_JOB_TOKEN', '')",
        f"api = os.environ.get('VAULTLAYER_API_URL', 'https://vaultlayer-production.up.railway.app')",
        f"job_id = '{job.job_id}'",
        f"if not job_token: raise SystemExit(0)",
        f"offset_file = '/tmp/vl_log_offset'",
        f"try: offset = int(open(offset_file).read().strip())",
        f"except Exception: offset = 0",
        f"try:",
        f"    with open('/tmp/vaultlayer.log', 'rb') as f:",
        f"        f.seek(offset)",
        f"        chunk = f.read()",
        f"        new_offset = f.tell()",
        f"except Exception: raise SystemExit(0)",
        f"if not chunk: raise SystemExit(0)",
        # Keep only fully-terminated lines this round; if the tail is a
        # partial line (no trailing newline), leave it for next tick by
        # rewinding the offset to the last newline. Prevents splitting a
        # line across two POSTs.
        f"last_nl = chunk.rfind(b'\\n')",
        f"if last_nl < 0: raise SystemExit(0)",
        f"complete = chunk[:last_nl+1]",
        f"new_offset = offset + len(complete)",
        f"lines = [l for l in complete.decode('utf-8', 'replace').splitlines() if l.strip()]",
        f"if not lines: ",
        f"    open(offset_file, 'w').write(str(new_offset)); raise SystemExit(0)",
        f"data = json.dumps(dict(lines=lines, source='training')).encode()",
        f"req = urllib.request.Request(api + '/api/v1/jobs/' + job_id + '/logs', data=data,",
        f"    headers={{'X-Job-Token': job_token, 'Content-Type': 'application/json'}})",
        f"try:",
        f"    urllib.request.urlopen(req, timeout=5)",
        f"    open(offset_file, 'w').write(str(new_offset))",
        f"except Exception: pass",
        f"\" 2>/dev/null",
        "done) &",
        "_VL_HEARTBEAT_PID=$!",
        "",
        "# ── NVMe instance-store detection + mount ────────────────────────",
        "VL_NVME_DEVS=$(lsblk -dpno NAME,TYPE 2>/dev/null | awk '$2==\"disk\"{print $1}' | grep nvme | grep -v nvme0n1 | head -8 || true)",
        "VL_NVME_COUNT=$(echo \"$VL_NVME_DEVS\" | grep -c nvme 2>/dev/null || echo 0)",
        "if [ \"$VL_NVME_COUNT\" -ge 2 ]; then",
        "  apt-get install -y -qq mdadm > /dev/null 2>&1 || yum install -y mdadm > /dev/null 2>&1 || true",
        "  mdadm --create /dev/md0 --level=0 --raid-devices=$VL_NVME_COUNT $VL_NVME_DEVS --force --run 2>/dev/null || true",
        "  mkfs.ext4 -q /dev/md0 2>/dev/null || true",
        "  mkdir -p /mnt/nvme && mount /dev/md0 /mnt/nvme 2>/dev/null || true",
        "  VL_DATA_ROOT=/mnt/nvme",
        "elif [ \"$VL_NVME_COUNT\" -eq 1 ]; then",
        "  VL_NVME_DEV=$(echo \"$VL_NVME_DEVS\" | head -1)",
        "  mkfs.ext4 -q $VL_NVME_DEV 2>/dev/null || true",
        "  mkdir -p /mnt/nvme && mount $VL_NVME_DEV /mnt/nvme 2>/dev/null || true",
        "  VL_DATA_ROOT=/mnt/nvme",
        "else",
        "  VL_DATA_ROOT=/tmp",
        "  echo '[VaultLayer] No instance-store NVMe found — using /tmp'",
        "fi",
        "mkdir -p $VL_DATA_ROOT/vl-data $VL_DATA_ROOT/vl-cache $VL_DATA_ROOT/vl-checkpoints",
        "echo \"[VaultLayer] Data root: $VL_DATA_ROOT\"",
        "echo VL_DATA_ROOT=$VL_DATA_ROOT >> /etc/environment",
        "export VL_DATA_ROOT",
        "",
        "# ── Install rclone ────────────────────────────────────────────────",
        # fuse3 removed 2026-04-21 — sync-only protocol doesn't need FUSE.
        "if ! command -v rclone &>/dev/null; then",
        "  curl -s --max-time 60 --connect-timeout 10 https://rclone.org/install.sh | bash",
        "fi",
        "",
        "# ── Write rclone R2 config (job-scoped temp credentials) ──────────",
        "mkdir -p /root/.config/rclone",
        "cat > /tmp/vaultlayer-rclone.conf << 'RCLONE_EOF'",
        "[r2]",
        "type = s3",
        "provider = Cloudflare",
        f"access_key_id = {r2_key_id}",
        f"secret_access_key = {r2_secret}",
        *([ f"session_token = {r2_session_token}" ] if r2_session_token else []),
        f"endpoint = {r2_endpoint}",
        "RCLONE_EOF",
        "cp /tmp/vaultlayer-rclone.conf /root/.config/rclone/rclone.conf",
        "",
        *(_r2_credential_refresh_lines(job.job_id, "/tmp/vaultlayer-rclone.conf") if r2_session_token else []),
        # ── Checkpoint dir + R2 sync (no FUSE) ────────────────────────────
        # FUSE mount removed 2026-04-21 — see docs/job_contract.md §4 for
        # rationale. One code path (rclone copy/sync) works everywhere; the
        # previous dual-path-with-fallback caused a silent-bug class where
        # FUSE sometimes mounted on AWS but never on containers, and the
        # new-leg restore was outbound-only (job 7f680ee3 Lambda leg burned
        # 15 min with 3 bootstrap logs because checkpoint-50 in R2 was never
        # pulled into the fresh CHECKPOINT_DIR).
        f"export CHECKPOINT_DIR=$VL_DATA_ROOT/vl-checkpoints/{job.job_id}",
        "export VAULTLAYER_CHECKPOINT_DIR=$CHECKPOINT_DIR",
        "mkdir -p $CHECKPOINT_DIR",
        f"export VAULTLAYER_R2_BUCKET={r2_bucket}",
        f"echo CHECKPOINT_DIR=$CHECKPOINT_DIR >> /etc/environment",
        f"echo VAULTLAYER_CHECKPOINT_DIR=$CHECKPOINT_DIR >> /etc/environment",
        f"echo VAULTLAYER_R2_BUCKET={r2_bucket} >> /etc/environment",
        # Resume: pull any prior-leg checkpoints from R2 before training starts.
        # First leg: R2 path is empty, no-op. Subsequent legs: HF checkpoint-N/
        # subdirs appear so SFTTrainer.train(resume_from_checkpoint=...) works.
        f"echo '[VaultLayer] Checking R2 for prior-leg checkpoints...'",
        f"rclone copy r2:{r2_bucket}/checkpoints/{job.job_id}/ $CHECKPOINT_DIR/ "
        "--config /tmp/vaultlayer-rclone.conf --transfers 4 --checkers 2 2>&1; _VL_RCLONE_RC=$?",
        f"if [ $_VL_RCLONE_RC -ne 0 ]; then",
        f"  echo '[VaultLayer] ERROR: rclone checkpoint restore exited '$_VL_RCLONE_RC' (auth/network/prefix failure)'",
        f"fi",
        # Chain-walk resume: if this job was resubmitted after a capacity/infra failure,
        # also pull checkpoints from the previous job's R2 path. This preserves checkpoint
        # continuity across GPU chain-walks (the core VaultLayer USP).
        *(
            [
                f"echo '[VaultLayer] Chain-walk resume: pulling checkpoints from prior job {job.resume_from_job_id}...'",
                f"rclone copy r2:{r2_bucket}/checkpoints/{job.resume_from_job_id}/ $CHECKPOINT_DIR/ "
                "--config /tmp/vaultlayer-rclone.conf --transfers 4 --checkers 2 2>&1; _VL_RCLONE_CHAIN_RC=$?",
                f"if [ $_VL_RCLONE_CHAIN_RC -ne 0 ]; then",
                f"  echo '[VaultLayer] ERROR: chain-walk rclone restore exited '$_VL_RCLONE_CHAIN_RC",
                f"fi",
            ]
            if getattr(job, "resume_from_job_id", None)
            else []
        ),
        f"if [ -n \"$(ls -A $CHECKPOINT_DIR 2>/dev/null)\" ]; then",
        f"  echo '[VaultLayer] Restored prior checkpoints from R2 into '$CHECKPOINT_DIR",
        f"else",
        f"  echo '[VaultLayer] No prior checkpoints in R2 (first leg)'",
        f"fi",
        # Inject VAULTLAYER_RESUME_CHECKPOINT when checkpoint_step is known.
        # HF Trainer and Lightning scripts can read this to resume:
        #   trainer.train(resume_from_checkpoint=os.environ.get("VAULTLAYER_RESUME_CHECKPOINT"))
        # Without this, a script that has checkpoint files in CHECKPOINT_DIR but
        # no explicit resume path will restart from step 0 (audit gap P1.4 2026-04-26).
        *(
            [
                # Detect checkpoint directory format at runtime (after R2 restore).
                # HF Trainer writes checkpoint-<N>/; raw PyTorch scripts write step-<N>/.
                # Static construction of checkpoint-{step} pointed at a missing dir
                # for raw PyTorch jobs — runtime detection handles both (audit gap 2026-04-26).
                f"_VL_CKPT_STEP={job.checkpoint_step}",
                "if [ -d \"$CHECKPOINT_DIR/checkpoint-$_VL_CKPT_STEP\" ]; then",
                f"  export VAULTLAYER_RESUME_CHECKPOINT=$CHECKPOINT_DIR/checkpoint-$_VL_CKPT_STEP",
                "elif [ -d \"$CHECKPOINT_DIR/step-$_VL_CKPT_STEP\" ]; then",
                "  export VAULTLAYER_RESUME_CHECKPOINT=$CHECKPOINT_DIR/step-$_VL_CKPT_STEP/checkpoint.pt",
                "fi",
                "if [ -n \"$VAULTLAYER_RESUME_CHECKPOINT\" ]; then",
                "  echo VAULTLAYER_RESUME_CHECKPOINT=$VAULTLAYER_RESUME_CHECKPOINT >> /etc/environment",
                "  echo '[VaultLayer] Resume checkpoint: '$VAULTLAYER_RESUME_CHECKPOINT",
                "else",
                f"  echo '[VaultLayer] WARN: checkpoint step {job.checkpoint_step} not found in $CHECKPOINT_DIR — check R2 restore'",
                "fi",
            ]
            if getattr(job, "checkpoint_step", None)
            else []
        ),
        # Background persist loop: every 60s, sync CHECKPOINT_DIR → R2.
        # Errors are logged to stderr (visible in VaultLayer job logs) not suppressed.
        # SIGTERM handler ensures a final sync runs before the node shuts down.
        "trap '_vl_sync_now() { echo \"[VaultLayer] SIGTERM — running final R2 sync before exit\"; "
        f"rclone sync $CHECKPOINT_DIR r2:{r2_bucket}/checkpoints/{job.job_id}/ "
        "--config /tmp/vaultlayer-rclone.conf --transfers 4 --checkers 2 "
        "&& echo \"[VaultLayer] Final R2 sync complete\" "
        "|| echo \"[VaultLayer] ERROR: final R2 sync failed\"; }; _vl_sync_now' SIGTERM SIGHUP",
        f"(while true; do rclone sync $CHECKPOINT_DIR r2:{r2_bucket}/checkpoints/{job.job_id}/ "
        "--config /tmp/vaultlayer-rclone.conf --transfers 4 --checkers 2 "
        "|| echo \"[VaultLayer] ERROR: rclone R2 sync failed (credentials/network issue)\"; "
        "sleep 60; done) &",
        "",
        *_user_s3_mirror_lines(job.job_id, "/tmp/vaultlayer-rclone.conf"),
    ]

    # Dataset copy: same logic as _build_userdata()
    dataset_id = getattr(job, "dataset_id", None)  # server-validated only; never read from env
    if dataset_id:
        r2_dataset_prefix = f"datasets/{dataset_id}"
        lines += [
            f"# ── Copy dataset {dataset_id} from R2 to NVMe ────────────────",
            f"VL_LOCAL_DATA=$VL_DATA_ROOT/vl-data/{dataset_id}",
            f"mkdir -p $VL_LOCAL_DATA",
            f"echo \"[VaultLayer] Warming dataset {dataset_id} to $VL_LOCAL_DATA ...\"",
            # Guard: abort startup if rclone fails — training on missing data is worse than failing fast.
            # VAULTLAYER_LOCAL_DATA is NOT exported until the copy succeeds.
            f"rclone copy r2:{r2_bucket}/{r2_dataset_prefix}/ "
            "$VL_LOCAL_DATA/ "
            "--config /tmp/vaultlayer-rclone.conf "
            "--transfers 16 --checkers 8 --progress"
            f" || {{ echo \"[VaultLayer] FATAL: dataset {dataset_id} warmup failed -- aborting job\"; exit 1; }}",
            f"echo \"[VaultLayer] Dataset ready at $VL_LOCAL_DATA\"",
            "export VAULTLAYER_LOCAL_DATA=$VL_LOCAL_DATA",
            "echo VAULTLAYER_LOCAL_DATA=$VL_LOCAL_DATA >> /etc/environment",
            "",
            "# Background sync to keep NVMe warm if R2 is updated mid-run (non-fatal)",
            f"nohup rclone sync r2:{r2_bucket}/{r2_dataset_prefix}/ "
            "$VL_LOCAL_DATA/ "
            "--config /tmp/vaultlayer-rclone.conf "
            "--transfers 4 --checkers 4 "
            "> /tmp/vl_shard_sync.log 2>&1 &",
            "export VL_NVME_CACHE=$VL_DATA_ROOT/vl-cache",
            "echo VL_NVME_CACHE=$VL_DATA_ROOT/vl-cache >> /etc/environment",
            "",
        ]

    # Docker: install if absent, ensure nvidia-container-toolkit, then background pull.
    #
    # nvidia-container-toolkit is required for `docker run --gpus all` (the
    # launch path used when job.docker_image is set — see the auto-start
    # block below). Lambda / AWS DLAMI ship it pre-installed; GCP's
    # ubuntu-accelerator-2204 and Crusoe sometimes don't. Silently install
    # if missing so the docker-run launch doesn't fail with
    # "could not select device driver with capabilities: [[gpu]]".
    if job.docker_image:
        _img = shlex.quote(job.docker_image)
        lines += [
            "# ── Docker install + nvidia-ctk + background image pull ──────",
            "if ! command -v docker &>/dev/null; then",
            "  curl -fsSL https://get.docker.com | bash",
            "fi",
            "if ! command -v nvidia-ctk &>/dev/null; then",
            "  echo '[VaultLayer] Installing nvidia-container-toolkit' | tee -a $_VL_LOG",
            "  (curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey \\",
            "     | gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg 2>/dev/null) || true",
            "  (curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list \\",
            "     | sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' \\",
            "     > /etc/apt/sources.list.d/nvidia-container-toolkit.list) || true",
            "  apt-get update -qq >/dev/null 2>&1 || true",
            "  apt-get install -y -qq nvidia-container-toolkit >/dev/null 2>&1 || true",
            "  nvidia-ctk runtime configure --runtime=docker 2>/dev/null || true",
            "  systemctl restart docker 2>/dev/null || service docker restart 2>/dev/null || true",
            "fi",
            f"if docker image inspect {_img} > /dev/null 2>&1; then",
            f"  echo '[VaultLayer] Docker image {_img} cached — skipping pull'",
            "  touch /tmp/vl_image_ready",
            "else",
            f"  echo '[VaultLayer] Background docker pull: {_img}'",
            f"  (docker pull {_img} && touch /tmp/vl_image_ready) > /tmp/vl_docker_pull.log 2>&1 &",
            f"  echo $! > /tmp/vl_docker_pull.pid",
            "fi",
        ]
    else:
        lines += ["touch /tmp/vl_image_ready"]

    # ── Decode + run embedded training script (remote execution via API) ──
    lines += [
        "",
        # Materialize the user's training script on disk. Prefer the
        # R2 pre-signed URL path (VL_SCRIPT_URL) since it bypasses
        # onstart/UserData size limits (issue #71). Fall back to inline
        # base64 for small scripts or when R2 is unavailable.
        "_VL_WORK=${VL_DATA_ROOT:-/tmp}/workspace",
        "mkdir -p $_VL_WORK",
        "if [ -n \"${VL_SCRIPT_URL:-}\" ] && [ -n \"${VL_SCRIPT_NAME:-}\" ]; then",
        "  echo \"[VaultLayer] Fetching training script from signed URL\" | tee -a $_VL_LOG",
        "  curl -fsSL \"${VL_SCRIPT_URL}\" -o $_VL_WORK/${VL_SCRIPT_NAME}",
        "  chmod +x $_VL_WORK/${VL_SCRIPT_NAME}",
        "elif [ -n \"${VL_SCRIPT_B64:-}\" ] && [ -n \"${VL_SCRIPT_NAME:-}\" ]; then",
        "  echo \"[VaultLayer] Decoding embedded training script: ${VL_SCRIPT_NAME}\" | tee -a $_VL_LOG",
        "  echo \"${VL_SCRIPT_B64}\" | base64 -d > $_VL_WORK/${VL_SCRIPT_NAME}",
        "  chmod +x $_VL_WORK/${VL_SCRIPT_NAME}",
        "fi",
        "",
        "echo '[VaultLayer] VM Bootstrap complete' | tee -a $_VL_LOG",
        "touch /tmp/vl_bootstrap_done",
        "",
        "# ── GCP: install NVIDIA driver (plain Ubuntu 22.04 LTS path) ────",
        # Set by gcp.py provision(). Plain ubuntu-2204-lts has NO NVIDIA
        # driver pre-installed, so we apt-install it here. Secure Boot is
        # off on the VM (shieldedInstanceConfig.enableSecureBoot=false in
        # the GCE insert body) because DKMS-built modules are unsigned.
        # Driver install takes ~3-5 min on first boot; that's inside the
        # 20-min stuck-detector fence with headroom.
        "if [ \"${VL_GCP_NEEDS_DRIVER_INSTALL:-0}\" = \"1\" ]; then",
        "  echo '[VaultLayer] GCP plain Ubuntu path — installing NVIDIA driver via apt (~3-5 min)' | tee -a $_VL_LOG",
        "  DEBIAN_FRONTEND=noninteractive apt-get update -qq >> $_VL_LOG 2>&1 || true",
        # ubuntu-drivers detects the right driver for the attached GPU and
        # handles kernel-header + DKMS deps. Fallback to explicit
        # nvidia-driver-535 if ubuntu-drivers isn't available.
        "  if command -v ubuntu-drivers &>/dev/null; then",
        "    DEBIAN_FRONTEND=noninteractive ubuntu-drivers install --no-install-recommends >> $_VL_LOG 2>&1 || true",
        "  else",
        "    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq --no-install-recommends "
        "linux-headers-$(uname -r) nvidia-driver-535 >> $_VL_LOG 2>&1 || true",
        "  fi",
        "  modprobe nvidia 2>&1 | tee -a $_VL_LOG | head -3 || true",
        "  modprobe nvidia-uvm 2>&1 | tee -a $_VL_LOG | head -3 || true",
        "  systemctl start nvidia-persistenced 2>&1 | tee -a $_VL_LOG | head -3 || true",
        "  nvidia-smi -pm 1 2>&1 | tee -a $_VL_LOG | head -3 || true",
        "  echo '[VaultLayer] Waiting for GPU to enumerate (up to 120s)...' | tee -a $_VL_LOG",
        "  for _i in $(seq 1 24); do",
        "    if nvidia-smi -L 2>/dev/null | grep -q 'GPU 0'; then",
        "      nvidia-smi -L | tee -a $_VL_LOG",
        "      break",
        "    fi",
        "    sleep 5",
        "  done",
        "fi",
        "# Legacy gate (kept so already-deployed provider code paths that still",
        # emit VL_GCP_GPU_WAIT=1 don't no-op silently). Same modprobe chain.
        "if [ \"${VL_GCP_GPU_WAIT:-0}\" = \"1\" ] && [ \"${VL_GCP_NEEDS_DRIVER_INSTALL:-0}\" != \"1\" ]; then",
        "  echo '[VaultLayer] VL_GCP_GPU_WAIT=1 (legacy accelerator-image path) — modprobe only' | tee -a $_VL_LOG",
        "  modprobe nvidia 2>&1 | tee -a $_VL_LOG | head -3 || true",
        "  modprobe nvidia-uvm 2>&1 | tee -a $_VL_LOG | head -3 || true",
        "  systemctl start nvidia-persistenced 2>&1 | tee -a $_VL_LOG | head -3 || true",
        "  nvidia-smi -pm 1 2>&1 | tee -a $_VL_LOG | head -3 || true",
        "fi",
        "",
        "# ── Auto-start training if script was materialized ──────────────",
        # Fire on EITHER inline (VL_SCRIPT_B64) or R2-URL (VL_SCRIPT_URL) path.
        # Issue #71 split script materialization into two paths above, but
        # this guard was left B64-only so the URL path fetched then never ran.
        "# VL_MIGRATION=1 means SSH resume will launch training — skip auto-start to prevent double-launch (#140)",
        "if [ \"${VL_MIGRATION:-0}\" != \"1\" ] && [ -n \"${VL_SCRIPT_NAME:-}\" ] && { [ -n \"${VL_SCRIPT_B64:-}\" ] || [ -n \"${VL_SCRIPT_URL:-}\" ]; }; then",
        "  _VL_WORK=${VL_DATA_ROOT:-/tmp}/workspace",
        # Pick interpreter by file extension. Previously this always used
        # bash — Python scripts (.py) would fail on line 1 with shell
        # syntax errors on f-strings / colons / etc. Issue #75, caught
        # 2026-04-18 on AWS smoke (i-03ed5c9272c27114f).
        "  case \"${VL_SCRIPT_NAME}\" in",
        "    *.py)  _VL_INTERP=\"python3\" ;;",
        "    *.sh)  _VL_INTERP=\"bash\"    ;;",
        "    *)     _VL_INTERP=\"bash\"    ;;",  # unknown ext → bash + shebang still works
        "  esac",
    ]

    # Launch branch — two paths.
    #
    # (A) job.docker_image set → run the script INSIDE the image via `docker
    #     run --gpus all`, mounting $_VL_WORK + /mnt/vaultlayer into the
    #     container. This kills the host-OS dep-hell class of failures
    #     (typing_extensions debian wall, triton submodule mismatch, psutil
    #     ABI, numpy 2.x pyarrow bridge) that path-1 stub installs kept
    #     hitting. Same image that already works on Vast.ai + RunPod.
    #
    # (B) no docker_image → keep today's host-native launch unchanged
    #     (backward-compatible fallback for jobs that truly want host
    #     python3, and for any tests that depend on this path).
    if job.docker_image:
        _img = shlex.quote(job.docker_image)
        # Propagate all env vars the training code might read. The outer
        # bootstrap already exported these (VAULTLAYER_JOB_ID, VL_JOB_TOKEN,
        # VAULTLAYER_API_URL, CHECKPOINT_DIR, VL_DATA_ROOT, VAULTLAYER_R2_BUCKET,
        # VAULTLAYER_LOCAL_DATA, VL_NVME_CACHE) plus everything in
        # job.environment. `docker -e K` without `=v` inherits from the
        # current shell, which is what we want.
        _infra_env = [
            "VAULTLAYER_JOB_ID", "VL_JOB_TOKEN", "VAULTLAYER_API_URL",
            # Both checkpoint-dir names — broker contract is CHECKPOINT_DIR,
            # but vaultlayer-examples training scripts read VAULTLAYER_CHECKPOINT_DIR.
            # Without the second one, scripts fall back to ${VL_DATA_ROOT}/...
            # which on a no-NVMe Lambda host = /tmp = ephemeral.
            "CHECKPOINT_DIR", "VAULTLAYER_CHECKPOINT_DIR",
            "VL_DATA_ROOT", "VAULTLAYER_R2_BUCKET",
            "VAULTLAYER_LOCAL_DATA", "VL_NVME_CACHE",
        ]
        _user_env = [
            k for k in (job.environment or {}).keys()
            if k not in {"VL_SCRIPT_B64", "VL_SCRIPT_URL", "VL_SCRIPT_NAME"}
        ]
        _env_flags = " ".join(f"-e {k}" for k in _infra_env + _user_env)
        lines += [
            # 25 min cap: vl-training-base:1.0 is ~6GB; a first attempt with
            # a 20-min cap (job 2d59bb83, 2026-04-20) timed out at exactly
            # 20m18s — the pull was finishing ~18s past the wall. Raising to
            # 25 min gives realistic variance margin. Sustained fix for AWS
            # (ghcr.io pulls are slow from EC2) is ECR Public hosting — see
            # TODO.md AWS-2 follow-up.
            #
            # Progress heartbeat every 120s is load-bearing: the platform-
            # level stuck detector fences instances after 20 min of 0 new
            # log lines. Without these progress pings, the docker-pull
            # silence looks like a hung VM and the watchdog terminates
            # (error: "Instance failed to boot (0 logs after 20 min)",
            # seen on job 99bf9f51-059c-4560-9db6-bed239a340e9 on 2026-04-20).
            # Each ping is distinct content (includes minute marker), so
            # the log-offset heartbeat forwards it to the API and the stuck
            # detector resets.
            "  echo '[VaultLayer] Waiting for docker image pull (up to 25 min)...' | tee -a $_VL_LOG",
            "  for _i in $(seq 1 300); do",
            "    [ -f /tmp/vl_image_ready ] && break",
            "    # Every 24 iterations × 5s = 120s, emit a progress heartbeat.",
            "    # Each message is unique per minute-mark so the log-offset",
            "    # heartbeat forwards it and the platform stuck-detector resets.",
            "    if [ $((_i % 24)) -eq 0 ]; then",
            "      _mins=$((_i / 12))",
            "      echo \"[VaultLayer] docker pull still in progress at ${_mins}min\" | tee -a $_VL_LOG",
            "    fi",
            "    sleep 5",
            "  done",
            "  if [ ! -f /tmp/vl_image_ready ]; then",
            f"    echo '[VaultLayer] docker pull of {job.docker_image} did not finish in 25 min — aborting' | tee -a $_VL_LOG",
            "    _EXIT=124",
            "  else",
            "    echo \"[VaultLayer] Starting (in container): cd /workspace && ${VL_SCRIPT_ARGS:-$_VL_INTERP /workspace/${VL_SCRIPT_NAME}}\" | tee -a $_VL_LOG",
            # pipefail is load-bearing — see #72.
            "    set -o pipefail",
            # --gpus all: CUDA passthrough (needs nvidia-container-toolkit).
            # --network host: training code hits HF Hub + R2 + our API; bridged
            #   net would need NAT setup. Host net simpler + matches container
            #   providers' default behavior.
            # --shm-size=4g: torch DataLoader workers use /dev/shm; default 64M
            #   triggers "bus error (core dumped)" on moderate dataloaders.
            # Mounts: $_VL_WORK→/workspace (script) + $CHECKPOINT_DIR (host NVMe path).
            # CHECKPOINT_DIR bind-mount is required: without it the container writes
            # checkpoints into its own ephemeral filesystem, which is deleted on
            # `docker run --rm` exit. The host-side rclone sync then sees an empty
            # directory and no checkpoints reach R2 (audit gap 2026-04-26).
            f"    docker run --rm --gpus all --network host --shm-size=4g "
            f"-v $_VL_WORK:/workspace "
            f"-v $CHECKPOINT_DIR:$CHECKPOINT_DIR "
            f"-v $VL_DATA_ROOT:$VL_DATA_ROOT "
            f"{_env_flags} "
            f"{_img} "
            "sh -lc \"cd /workspace && ${VL_SCRIPT_ARGS:-$_VL_INTERP /workspace/${VL_SCRIPT_NAME}}\" 2>&1 | tee -a $_VL_LOG",
            "    _EXIT=${PIPESTATUS[0]}",
            "    set +o pipefail",
            "  fi",
        ]
    else:
        lines += [
            "  echo \"[VaultLayer] Starting: ${VL_SCRIPT_ARGS:-$_VL_INTERP $_VL_WORK/${VL_SCRIPT_NAME}}\" | tee -a $_VL_LOG",
            "  set -o pipefail",
            "  cd $_VL_WORK && sh -lc \"${VL_SCRIPT_ARGS:-$_VL_INTERP $_VL_WORK/${VL_SCRIPT_NAME}}\" 2>&1 | tee -a $_VL_LOG",
            "  _EXIT=$?",
            "  set +o pipefail",
        ]

    lines += [
        # Force a final R2 checkpoint sync BEFORE emitting any completion signal.
        # The worker polls for "Training finished" in job_logs and calls
        # _terminate_and_settle() immediately on detection. If the sync ran
        # after the log POST it would race with instance termination and
        # checkpoints written in the final ~60s of training would be lost.
        # This must be the first thing after training exits, before any signal
        # that the worker could observe (audit gap P1.3, ordering fix 2026-04-26).
        f"  if [ -d \"$CHECKPOINT_DIR\" ]; then",
        f"    if rclone sync $CHECKPOINT_DIR r2:{r2_bucket}/checkpoints/{job.job_id}/ "
        "--config /tmp/vaultlayer-rclone.conf --transfers 4 --checkers 2; then",
        f"      echo '[VaultLayer] Final checkpoint sync to R2 complete' | tee -a $_VL_LOG",
        f"    else",
        f"      echo '[VaultLayer] FATAL: final checkpoint sync to R2 failed' | tee -a $_VL_LOG",
        f"      _EXIT=98",
        f"    fi",
        f"  fi",
        "  echo \"[VaultLayer] Training finished (exit $_EXIT)\" | tee -a $_VL_LOG",
        # R2 sentinel: write _COMPLETED for success or _FAILED for non-zero exit.
        # This is the same approach as the container path (build_container_onstart).
        # The worker's _check_completion() polls for _COMPLETED; without it a VM
        # job can only be detected via the "Training finished" log line, which is
        # lost if the final /logs POST fails.
        f"  echo $_EXIT > /tmp/_VL_EXIT_SENTINEL",
        f"  _VL_SENTINEL_KEY='checkpoints/{job.job_id}/_COMPLETED'",
        f"  if [ $_EXIT -ne 0 ]; then _VL_SENTINEL_KEY='checkpoints/{job.job_id}/_FAILED'; fi",
        # R2 sentinel write: capture exit code so the worker can detect completion
        # even if the API event POST fails.  Errors are printed, not swallowed.
        f"  rclone copyto /tmp/_VL_EXIT_SENTINEL r2:{r2_bucket}/$_VL_SENTINEL_KEY "
        "--config /tmp/vaultlayer-rclone.conf 2>&1; _VL_RCLONE_SENT_RC=$?",
        f"  if [ $_VL_RCLONE_SENT_RC -ne 0 ]; then",
        f"    echo '[VaultLayer] ERROR: R2 sentinel write exited '$_VL_RCLONE_SENT_RC' — worker may miss completion'",
        f"  fi",
        # Final POST: drain any bytes newer than the last heartbeat offset,
        # then post a completed/failed job event. Using the offset tracker keeps
        # the 1:1 duplication ratio end-to-end — previously the final
        # POST re-sent splitlines()[-100:] which the server re-stored
        # with a new created_at (seen as the 2x ratio on job 996bab81).
        # The entire block runs without 2>/dev/null so errors appear in VM logs.
        f"  python3 << 'PYEOF'",
        f"import os, json, time, urllib.request",
        f"t = os.environ.get('VL_JOB_TOKEN', '')",
        f"a = os.environ.get('VAULTLAYER_API_URL', 'https://vaultlayer-production.up.railway.app')",
        f"if not t: raise SystemExit(0)",
        f"exit_code = int(open('/tmp/_VL_EXIT_SENTINEL').read().strip()) if os.path.exists('/tmp/_VL_EXIT_SENTINEL') else 1",
        f"offset_file = '/tmp/vl_log_offset'",
        f"try: offset = int(open(offset_file).read().strip())",
        f"except Exception: offset = 0",
        f"try:",
        f"    with open('/tmp/vaultlayer.log', 'rb') as f:",
        f"        f.seek(offset)",
        f"        chunk = f.read()",
        f"except Exception: chunk = b''",
        f"new_lines = [l for l in chunk.decode('utf-8', 'replace').splitlines() if l.strip()]",
        f"new_lines.append('TRAINING_COMPLETE')",
        f"data = json.dumps(dict(lines=new_lines, source='training')).encode()",
        f"req = urllib.request.Request(a + '/api/v1/jobs/{job.job_id}/logs', data=data,",
        f"    headers={{'X-Job-Token': t, 'Content-Type': 'application/json'}})",
        f"try:",
        f"    urllib.request.urlopen(req, timeout=15)",
        f"    print('[VaultLayer] Final logs posted (' + str(len(new_lines)) + ' lines)')",
        f"except Exception as e:",
        f"    print('[VaultLayer] WARN: Final log POST failed: ' + str(e))",
        f"# Post terminal event with retry — non-2xx means worker may miss completion.",
        f"evt_type = 'completed' if exit_code == 0 else 'failed'",
        f"evt = json.dumps(dict(event_type=evt_type, message='exit_code=' + str(exit_code))).encode()",
        f"for _attempt in range(3):",
        f"    try:",
        f"        req2 = urllib.request.Request(a + '/api/v1/jobs/{job.job_id}/events', data=evt,",
        f"            headers={{'X-Job-Token': t, 'Content-Type': 'application/json'}})",
        f"        urllib.request.urlopen(req2, timeout=15)",
        f"        print('[VaultLayer] Terminal event posted: ' + evt_type)",
        f"        break",
        f"    except Exception as e:",
        f"        print('[VaultLayer] WARN: event POST attempt ' + str(_attempt+1) + ' failed: ' + str(e))",
        f"        if _attempt < 2: time.sleep(5)",
        f"else:",
        f"    print('[VaultLayer] ERROR: terminal event POST failed after 3 attempts — worker may miss completion')",
        f"PYEOF",
        "  _PYEOF_EXIT=$?",
        "  if [ $_PYEOF_EXIT -ne 0 ]; then",
        "    echo '[VaultLayer] ERROR: VM finalizer Python block exited with code '$_PYEOF_EXIT",
        "  fi",
        "fi",
        "# Heartbeat keeps running in background (started before infrastructure setup)",
    ]
    return "\n".join(lines) + "\n"


def build_container_onstart(broker, job: "Job") -> str:
    """Generate an onstart script for container platforms (RunPod, Vast.ai).

    Container platforms already run the user's Docker image — no docker pull needed.
    This script runs INSIDE the container before the main process starts:
      1. Set VAULTLAYER_JOB_ID + job.environment
      2. Install rclone (if not present in the base image)
      3. Write rclone R2 config with job-scoped temp credentials
      4. Attempt FUSE mount of R2 for checkpoint I/O (falls back to rclone copy)
      5. Copy dataset shards from R2 to /workspace (if dataset_id set)

    Security: same scoped R2 credentials as build_vm_startup_script().
    No NVMe setup (containers use overlay filesystem or attached volumes).
    No Docker install (already inside a container).
    """
    r2_key_id, r2_secret, r2_session_token = get_r2_credentials_for_node(broker, job)
    _cf = broker.config.cloudflare
    r2_endpoint = _cf.r2_endpoint if _cf else ""
    r2_bucket = _cf.r2_bucket if _cf else ""

    lines = [
        "#!/bin/bash",
        "# No set -e — we handle errors gracefully to avoid killing the container",
        "",
        "# ── VaultLayer container bootstrap (self-contained — no provider env dependency) ──",
        f"export VAULTLAYER_JOB_ID='{job.job_id}'",
        "_VL_LOG=/tmp/vaultlayer.log",
        "touch $_VL_LOG",
    ]

    # Embed ALL env vars directly in the script — never rely on provider env mechanism.
    # This ensures VL_JOB_TOKEN, VL_SCRIPT_B64, VAULTLAYER_API_URL etc. are available
    # regardless of whether Vast.ai/RunPod/Lambda set them before onstart runs.
    for key, value in (job.environment or {}).items():
        _escaped = str(value).replace("'", "'\\''")
        lines.append(f"export {key}='{_escaped}'")

    lines += [
        "",
        "# ── Early heartbeat: post 'bootstrap started' so server knows we're alive ──",
        "echo '[VaultLayer] Bootstrap started' | tee -a $_VL_LOG",
        f"python3 -c \"",
        f"import json, urllib.request, os",
        f"t = os.environ.get('VL_JOB_TOKEN', '')",
        f"a = os.environ.get('VAULTLAYER_API_URL', 'https://vaultlayer-production.up.railway.app')",
        f"if t:",
        f"    d = json.dumps(dict(lines=['[VaultLayer] Bootstrap started — installing dependencies'], source='bootstrap')).encode()",
        f"    r = urllib.request.Request(a + '/api/v1/jobs/{job.job_id}/logs', data=d,",
        f"        headers={{'X-Job-Token': t, 'Content-Type': 'application/json'}})",
        f"    try: urllib.request.urlopen(r, timeout=5)",
        f"    except: pass",
        f"\" 2>/dev/null",
        "",
        "# ── Background heartbeat: posts logs to API every 30s ──────────────",
        "# MUST start BEFORE infrastructure setup (rclone/R2) so the server sees",
        "# logs even if rclone install or FUSE mount hangs. Without this, the",
        "# stuck detector fires after 10 min of 0 logs and kills the instance.",
        "(while true; do",
        "  sleep 30",
        "  _LINES=$(wc -l < $_VL_LOG 2>/dev/null || echo 0)",
        # Marker file on the persistent volume — shell-observable proof
        # of life for operators who SSH into a pod. Survives even if the
        # heartbeat POST fails. /workspace is the persistent volume on
        # RunPod/Vast.ai; mkdir is defensive for images that don't mount it.
        "  mkdir -p /workspace 2>/dev/null || true",
        "  echo \"$(date -u +%Y-%m-%dT%H:%M:%SZ) uptime=${SECONDS:-0}s log_lines=$_LINES\" > /workspace/vl-heartbeat.flag 2>/dev/null || true",
        # Offset-tracking heartbeat (same design as VM builder at line 122).
        # Only POST bytes written since the last successful send. Avoids the
        # 9-distinct-lines-as-275-rows flood confirmed on 2026-04-20 job
        # f9b88427. Offset advances only on POST success.
        f"  python3 -c \"",
        f"import os, json, urllib.request",
        f"job_token = os.environ.get('VL_JOB_TOKEN', '')",
        f"api = os.environ.get('VAULTLAYER_API_URL', 'https://vaultlayer-production.up.railway.app')",
        f"job_id = '{job.job_id}'",
        f"if not job_token: raise SystemExit(0)",
        f"offset_file = '/tmp/vl_log_offset'",
        f"try: offset = int(open(offset_file).read().strip())",
        f"except Exception: offset = 0",
        f"try:",
        f"    with open('/tmp/vaultlayer.log', 'rb') as f:",
        f"        f.seek(offset)",
        f"        chunk = f.read()",
        f"except Exception: raise SystemExit(0)",
        f"if not chunk: raise SystemExit(0)",
        f"last_nl = chunk.rfind(b'\\n')",
        f"if last_nl < 0: raise SystemExit(0)",
        f"complete = chunk[:last_nl+1]",
        f"new_offset = offset + len(complete)",
        f"lines = [l for l in complete.decode('utf-8', 'replace').splitlines() if l.strip()]",
        f"if not lines:",
        f"    open(offset_file, 'w').write(str(new_offset)); raise SystemExit(0)",
        f"data = json.dumps(dict(lines=lines, source='training')).encode()",
        f"req = urllib.request.Request(api + '/api/v1/jobs/' + job_id + '/logs', data=data,",
        f"    headers={{'X-Job-Token': job_token, 'Content-Type': 'application/json'}})",
        f"try:",
        f"    urllib.request.urlopen(req, timeout=5)",
        f"    open(offset_file, 'w').write(str(new_offset))",
        f"    print(f'[heartbeat] posted {{len(lines)}} lines')",
        f"except Exception as e: print(f'[heartbeat] failed: {{e}}')",
        f"\" 2>/dev/null",
        "done) &",
        "_VL_HEARTBEAT_PID=$!",
        "",
        "# ── Install rclone (need v1.60+ for Cloudflare R2 support) ────────",
        "echo '[VaultLayer] Installing rclone...' | tee -a $_VL_LOG",
        "if ! command -v rclone &>/dev/null || [ \"$(rclone version --check 2>/dev/null | grep -o '[0-9]*' | head -1)\" -lt 60 ] 2>/dev/null; then",
        "  apt-get install -y -qq unzip 2>/dev/null || true",
        "  curl -s --max-time 60 --connect-timeout 10 https://rclone.org/install.sh | bash 2>/dev/null || \\",
        "    apt-get install -y -qq rclone 2>/dev/null || true",
        "fi",
        "echo '[VaultLayer] rclone ready' | tee -a $_VL_LOG",
        "",
        "# ── Write rclone R2 config (job-scoped temp credentials) ──────────",
        "mkdir -p /root/.config/rclone",
        "cat > /root/.config/rclone/rclone.conf << 'RCLONE_EOF'",
        "[r2]",
        "type = s3",
        "provider = Cloudflare",
        f"access_key_id = {r2_key_id}",
        f"secret_access_key = {r2_secret}",
        *([ f"session_token = {r2_session_token}" ] if r2_session_token else []),
        f"endpoint = {r2_endpoint}",
        "RCLONE_EOF",
        "",
        *(_r2_credential_refresh_lines(job.job_id, "/root/.config/rclone/rclone.conf") if r2_session_token else []),
        # ── Checkpoint dir + R2 sync (no FUSE) ────────────────────────────
        # FUSE mount (the `rclone` mount subcommand) removed 2026-04-21: it requires privileged
        # mode or CAP_SYS_ADMIN + /dev/fuse, which container providers like
        # Vast.ai / RunPod do not grant by default. The silent-fallback code
        # path doubled our bug surface (see job 7f680ee3 Lambda leg). Using
        # rclone copy/sync always works everywhere. See docs/job_contract.md.
        f"export CHECKPOINT_DIR=/workspace/checkpoints/{job.job_id}",
        "export VAULTLAYER_CHECKPOINT_DIR=$CHECKPOINT_DIR",
        "mkdir -p $CHECKPOINT_DIR",
        # Resume: pull any prior-leg checkpoints from R2 before training starts.
        # First leg: R2 path is empty, no-op. Subsequent legs: HF checkpoint-N/
        # subdirs appear so SFTTrainer.train(resume_from_checkpoint=...) works.
        f"echo '[VaultLayer] Checking R2 for prior-leg checkpoints...'",
        f"rclone copy r2:{r2_bucket}/checkpoints/{job.job_id}/ $CHECKPOINT_DIR/ "
        "--transfers 4 --checkers 2 2>&1; _VL_RCLONE_RC=$?",
        f"if [ $_VL_RCLONE_RC -ne 0 ]; then",
        f"  echo '[VaultLayer] ERROR: rclone checkpoint restore exited '$_VL_RCLONE_RC' (auth/network/prefix failure)'",
        f"fi",
        # Chain-walk resume: if this job was resubmitted after a capacity/infra failure,
        # also pull checkpoints from the previous job's R2 path. This preserves checkpoint
        # continuity across GPU chain-walks (the core VaultLayer USP).
        *(
            [
                f"echo '[VaultLayer] Chain-walk resume: pulling checkpoints from prior job {job.resume_from_job_id}...'",
                f"rclone copy r2:{r2_bucket}/checkpoints/{job.resume_from_job_id}/ $CHECKPOINT_DIR/ "
                "--transfers 4 --checkers 2 2>&1; _VL_RCLONE_CHAIN_RC=$?",
                f"if [ $_VL_RCLONE_CHAIN_RC -ne 0 ]; then",
                f"  echo '[VaultLayer] ERROR: chain-walk rclone restore exited '$_VL_RCLONE_CHAIN_RC",
                f"fi",
            ]
            if getattr(job, "resume_from_job_id", None)
            else []
        ),
        f"if [ -n \"$(ls -A $CHECKPOINT_DIR 2>/dev/null)\" ]; then",
        f"  echo '[VaultLayer] Restored prior checkpoints from R2 into '$CHECKPOINT_DIR",
        f"else",
        f"  echo '[VaultLayer] No prior checkpoints in R2 (first leg)'",
        f"fi",
        # Inject VAULTLAYER_RESUME_CHECKPOINT when checkpoint_step is known.
        # Mirrors the VM path injection (audit gap P1.4 2026-04-26).
        *(
            [
                f"_VL_CKPT_STEP={job.checkpoint_step}",
                "if [ -d \"$CHECKPOINT_DIR/checkpoint-$_VL_CKPT_STEP\" ]; then",
                "  export VAULTLAYER_RESUME_CHECKPOINT=$CHECKPOINT_DIR/checkpoint-$_VL_CKPT_STEP",
                "elif [ -d \"$CHECKPOINT_DIR/step-$_VL_CKPT_STEP\" ]; then",
                "  export VAULTLAYER_RESUME_CHECKPOINT=$CHECKPOINT_DIR/step-$_VL_CKPT_STEP/checkpoint.pt",
                "fi",
                "if [ -n \"${VAULTLAYER_RESUME_CHECKPOINT:-}\" ]; then",
                "  echo VAULTLAYER_RESUME_CHECKPOINT=$VAULTLAYER_RESUME_CHECKPOINT >> /etc/environment",
                "  echo '[VaultLayer] Resume checkpoint: '$VAULTLAYER_RESUME_CHECKPOINT",
                "fi",
            ]
            if getattr(job, "checkpoint_step", None)
            else []
        ),
        # Background persist loop: every 60s, sync CHECKPOINT_DIR → R2.
        # Errors logged to stderr (visible in job logs) not suppressed.
        # SIGTERM handler ensures a final sync runs before container shuts down.
        "trap '_vl_sync_now() { echo \"[VaultLayer] SIGTERM — running final R2 sync before exit\"; "
        f"rclone sync $CHECKPOINT_DIR r2:{r2_bucket}/checkpoints/{job.job_id}/ "
        "--transfers 4 --checkers 2 "
        "&& echo \"[VaultLayer] Final R2 sync complete\" "
        "|| echo \"[VaultLayer] ERROR: final R2 sync failed\"; }; _vl_sync_now' SIGTERM SIGHUP",
        f"(while true; do rclone sync $CHECKPOINT_DIR r2:{r2_bucket}/checkpoints/{job.job_id}/ "
        "--transfers 4 --checkers 2 "
        "|| echo \"[VaultLayer] ERROR: rclone R2 sync failed (credentials/network issue)\"; "
        "sleep 60; done) &",
        "",
        *_user_s3_mirror_lines(job.job_id, "/root/.config/rclone/rclone.conf"),
    ]

    dataset_id = getattr(job, "dataset_id", None)  # server-validated only; never read from env
    if dataset_id:
        r2_dataset_prefix = f"datasets/{dataset_id}"
        lines += [
            f"# ── Copy dataset {dataset_id} from R2 ────────────────────────",
            "VL_WORKSPACE=${WORKSPACE:-/workspace}",
            f"VL_LOCAL_DATA=$VL_WORKSPACE/vl-data/{dataset_id}",
            "mkdir -p $VL_LOCAL_DATA",
            f"echo \"[VaultLayer] Warming dataset {dataset_id} to $VL_LOCAL_DATA ...\"",
            # Guard: abort container startup if rclone fails — VAULTLAYER_LOCAL_DATA
            # is NOT exported until the copy succeeds.
            f"rclone copy r2:{r2_bucket}/{r2_dataset_prefix}/ "
            "$VL_LOCAL_DATA/ --transfers 8 --checkers 4 --progress"
            f" || {{ echo \"[VaultLayer] FATAL: dataset {dataset_id} warmup failed -- aborting job\"; exit 1; }}",
            f"echo \"[VaultLayer] Dataset ready at $VL_LOCAL_DATA\"",
            "export VAULTLAYER_LOCAL_DATA=$VL_LOCAL_DATA",
            "",
            "# Background sync for mid-run R2 updates (non-fatal)",
            f"nohup rclone sync r2:{r2_bucket}/{r2_dataset_prefix}/ "
            "$VL_LOCAL_DATA/ --transfers 4 > /tmp/vl_shard_sync.log 2>&1 &",
            "",
        ]

    # ── Materialize training script (remote execution) ───────────────
    lines += [
        "",
        # Prefer R2 signed-URL fetch for scripts too big to inline (issue #71).
        # Falls back to base64 decode for small scripts.
        "if [ -n \"${VL_SCRIPT_URL:-}\" ] && [ -n \"${VL_SCRIPT_NAME:-}\" ]; then",
        "  echo \"[VaultLayer] Fetching training script from signed URL\"",
        "  curl -fsSL \"${VL_SCRIPT_URL}\" -o /workspace/${VL_SCRIPT_NAME}",
        "elif [ -n \"${VL_SCRIPT_B64:-}\" ] && [ -n \"${VL_SCRIPT_NAME:-}\" ]; then",
        "  echo \"[VaultLayer] Decoding embedded training script: ${VL_SCRIPT_NAME}\"",
        "  echo \"${VL_SCRIPT_B64}\" | base64 -d > /workspace/${VL_SCRIPT_NAME}",
        "fi",
        "",
        # Legacy flat-file checkpoint helper removed 2026-04-21. HF Trainer's
        # native checkpoint-N/ directory format is the only contract now —
        # see docs/job_contract.md §3. For raw PyTorch loops, users save
        # to $CHECKPOINT_DIR/checkpoint-<step>/model.safetensors themselves.
        "export PYTHONPATH=/workspace:${PYTHONPATH:-}",
        "",
    ]

    lines += [
        "echo '[VaultLayer] Container bootstrap complete' | tee -a $_VL_LOG",
        # P0-L2: write sentinel so BrokerAgent knows bootstrap is done
        "touch /tmp/vl_bootstrap_done",
        "",
        "# Heartbeat already running (started before infrastructure setup)",
        "",
        "# ── Auto-start training if script was materialized ──────────────",
        # Fire on EITHER inline (VL_SCRIPT_B64) or R2-URL (VL_SCRIPT_URL) path.
        "# VL_MIGRATION=1 means SSH resume will launch training — skip auto-start to prevent double-launch (#140)",
        "if [ \"${VL_MIGRATION:-0}\" != \"1\" ] && [ -n \"${VL_SCRIPT_NAME:-}\" ] && { [ -n \"${VL_SCRIPT_B64:-}\" ] || [ -n \"${VL_SCRIPT_URL:-}\" ]; }; then",
        # Pick interpreter by file extension (issue #75). Containers prefer
        # python3 for .py (python may not exist on minimal images) and
        # bash for .sh.
        "  case \"${VL_SCRIPT_NAME}\" in",
        "    *.py)  _VL_INTERP=\"python3\" ;;",
        "    *.sh)  _VL_INTERP=\"bash\"    ;;",
        "    *)     _VL_INTERP=\"bash\"    ;;",
        "  esac",
        "  echo \"[VaultLayer] Starting training: ${VL_SCRIPT_ARGS:-$_VL_INTERP /workspace/${VL_SCRIPT_NAME}}\"",
        "  set -o pipefail",
        # -a: append so bootstrap logs written before this point are preserved.
        # Without -a, tee truncates $_VL_LOG, advancing the offset tracker past
        # the new file beginning and dropping early training output (#P1 tee-a fix).
        "  cd /workspace && sh -lc \"${VL_SCRIPT_ARGS:-$_VL_INTERP /workspace/${VL_SCRIPT_NAME}}\" 2>&1 | tee -a $_VL_LOG",
        "  _EXIT=$?",
        "  set +o pipefail",
        "  kill $_VL_HEARTBEAT_PID 2>/dev/null || true",
        # Final checkpoint sync BEFORE any worker-visible completion signal.
        # Worker detects completion via "Training finished" in /logs, _COMPLETED in
        # R2, or job_events.completed. Any of these causes immediate termination.
        # Sync must happen first so the checkpoint is safely in R2 before the
        # worker can act on the signal (audit gap P1.3, ordering fix 2026-04-26).
        f"  if [ -d \"$CHECKPOINT_DIR\" ]; then",
        f"    if rclone sync $CHECKPOINT_DIR r2:{r2_bucket}/checkpoints/{job.job_id}/ "
        "--transfers 4 --checkers 2; then",
        f"      echo '[VaultLayer] Final checkpoint sync to R2 complete' | tee -a $_VL_LOG",
        f"    else",
        f"      echo '[VaultLayer] FATAL: final checkpoint sync to R2 failed' | tee -a $_VL_LOG",
        f"      _EXIT=98",
        f"    fi",
        f"  fi",
        "  echo \"[VaultLayer] Training finished (exit $_EXIT)\" | tee -a $_VL_LOG",
        "  # Write completion sentinel — try FUSE mount first, fallback to rclone copy",
        f"  if [ $_EXIT -eq 0 ]; then",
        f"    echo 'completed' > /tmp/_COMPLETED_SENTINEL",
        f"    if mountpoint -q /mnt/vaultlayer 2>/dev/null; then",
        f"      cp /tmp/_COMPLETED_SENTINEL /mnt/vaultlayer/checkpoints/{job.job_id}/_COMPLETED 2>/dev/null || true",
        f"    fi",
        f"    # Also try rclone copy as backup",
        f"    rclone copyto /tmp/_COMPLETED_SENTINEL r2:{r2_bucket}/checkpoints/{job.job_id}/_COMPLETED 2>/dev/null || true",
        f"  fi",
        "  # POST final logs + completion status to API (drain from offset)",
        "  export _VL_EXIT=$_EXIT",
        f"  python3 << 'PYEOF'",
        f"import os, json, urllib.request, time",
        f"job_token = os.environ.get('VL_JOB_TOKEN', '')",
        f"api = os.environ.get('VAULTLAYER_API_URL', 'https://vaultlayer-production.up.railway.app')",
        f"job_id = '{job.job_id}'",
        f"import sys; exit_code = int(os.environ.get('_VL_EXIT', '1'))",
        f"if job_token:",
        f"    # Drain any bytes newer than the last heartbeat offset to",
        f"    # preserve 1:1 duplication ratio end-to-end.",
        f"    offset_file = '/tmp/vl_log_offset'",
        f"    try: offset = int(open(offset_file).read().strip())",
        f"    except Exception: offset = 0",
        f"    try:",
        f"        with open('/tmp/vaultlayer.log', 'rb') as f:",
        f"            f.seek(offset)",
        f"            chunk = f.read()",
        f"    except Exception: chunk = b''",
        f"    lines = [l for l in chunk.decode('utf-8', 'replace').splitlines() if l.strip()]",
        f"    try:",
        f"        data = json.dumps(dict(lines=lines, source='training')).encode()",
        f"        req = urllib.request.Request(api + '/api/v1/jobs/' + job_id + '/logs', data=data,",
        f"            headers={{'X-Job-Token': job_token, 'Content-Type': 'application/json'}})",
        f"        urllib.request.urlopen(req, timeout=15)",
        f"        print('[VaultLayer] Final logs posted to API (' + str(len(lines)) + ' new lines)')",
        f"    except Exception as e:",
        f"        print('[VaultLayer] WARN: Final log POST failed: ' + str(e))",
        f"    # Post terminal event with retry (up to 3 attempts) — non-2xx means",
        f"    # the worker will not see the durable terminal signal (issue #218).",
        f"    evt_type = 'completed' if exit_code == 0 else 'failed'",
        f"    evt = json.dumps(dict(event_type=evt_type, message='exit_code=' + str(exit_code))).encode()",
        f"    for _attempt in range(3):",
        f"        try:",
        f"            req2 = urllib.request.Request(api + '/api/v1/jobs/' + job_id + '/events', data=evt,",
        f"                headers={{'X-Job-Token': job_token, 'Content-Type': 'application/json'}})",
        f"            urllib.request.urlopen(req2, timeout=15)",
        f"            print('[VaultLayer] Terminal event posted: ' + evt_type)",
        f"            break",
        f"        except Exception as e:",
        f"            print('[VaultLayer] WARN: event POST attempt ' + str(_attempt+1) + ' failed: ' + str(e))",
        f"            if _attempt < 2: time.sleep(5)",
        f"    else:",
        f"        print('[VaultLayer] ERROR: terminal event POST failed after 3 attempts — worker may not detect completion')",
        f"PYEOF",
        "  _PYEOF_EXIT=$?",
        "  if [ $_PYEOF_EXIT -ne 0 ]; then",
        "    echo '[VaultLayer] ERROR: finalizer Python block exited with code '$_PYEOF_EXIT",
        "  fi",
        "fi",
        "",
        "# Wait briefly for API POST to complete, then exit cleanly.",
        "# Container exits on its own — no 'sleep infinity' to avoid billing leaks.",
        "# CLI detects completion via API logs marker or R2 sentinel.",
        "sleep 15",
    ]
    return "\n".join(lines) + "\n"


def build_userdata(broker, job: "Job") -> str:
    """Build EC2 UserData script that bootstraps the node for VaultLayer.

    Installs rclone, mounts R2 Neutral Zone (checkpoints only), copies
    dataset to local NVMe, sets environment variables, and pulls the
    Docker image if configured.

    Security: GPU node receives job-scoped temporary R2 credentials
    restricted to jobs/{job_id}/ — master keys never leave Broker.
    """
    # Mint scoped credentials before building the script
    r2_key_id, r2_secret, r2_session_token = get_r2_credentials_for_node(broker, job)
    _cf = broker.config.cloudflare
    r2_endpoint = _cf.r2_endpoint if _cf else ""
    r2_bucket = _cf.r2_bucket if _cf else ""

    lines = [
        "#!/bin/bash",
        "set -e",
        "",
        "# -- VaultLayer node bootstrap --",
        f"echo VAULTLAYER_JOB_ID={job.job_id} >> /etc/environment",
        f"export VAULTLAYER_JOB_ID={job.job_id}",
        "",
        # ── NVMe detection + mount ──────────────────────────────────────
        # GPU nodes (p5, p4d, p3dn, Lambda H100, CoreWeave) ship with
        # instance-store NVMe drives that are NOT automounted on DLAMI.
        # /dev/nvme0n1 is always the root EBS / boot volume — skip it.
        # We stripe remaining drives into /mnt/nvme using mdadm or use
        # the first one if only one exists.  If no extra NVMe is found we
        # fall back to /tmp (tmpfs) so the script never fails.
        "# ── NVMe instance-store detection + mount ──",
        "VL_NVME_DEVS=$(lsblk -dpno NAME,TYPE | awk '$2==\"disk\"{print $1}' | grep nvme | grep -v nvme0n1 | head -8 || true)",
        "VL_NVME_COUNT=$(echo \"$VL_NVME_DEVS\" | grep -c nvme || true)",
        "if [ \"$VL_NVME_COUNT\" -ge 2 ]; then",
        "  apt-get install -y -qq mdadm > /dev/null 2>&1 || true",
        "  mdadm --create /dev/md0 --level=0 --raid-devices=$VL_NVME_COUNT $VL_NVME_DEVS --force --run 2>/dev/null || true",
        "  mkfs.ext4 -q /dev/md0 2>/dev/null || true",
        "  mkdir -p /mnt/nvme && mount /dev/md0 /mnt/nvme",
        "  VL_DATA_ROOT=/mnt/nvme",
        "elif [ \"$VL_NVME_COUNT\" -eq 1 ]; then",
        "  VL_NVME_DEV=$(echo \"$VL_NVME_DEVS\" | head -1)",
        "  mkfs.ext4 -q $VL_NVME_DEV 2>/dev/null || true",
        "  mkdir -p /mnt/nvme && mount $VL_NVME_DEV /mnt/nvme",
        "  VL_DATA_ROOT=/mnt/nvme",
        "else",
        "  VL_DATA_ROOT=/tmp",
        "  echo '[VaultLayer] No instance-store NVMe found — using /tmp (may be tmpfs)'",
        "fi",
        "mkdir -p $VL_DATA_ROOT/vl-data $VL_DATA_ROOT/vl-cache $VL_DATA_ROOT/vl-checkpoints",
        "echo \"[VaultLayer] Data root: $VL_DATA_ROOT ($(df -h $VL_DATA_ROOT | tail -1 | awk '{print $2}') total)\"",
        "echo VL_DATA_ROOT=$VL_DATA_ROOT >> /etc/environment",
        "export VL_DATA_ROOT",
        "",
        "# Install rclone + fuse3",
        "apt-get update -qq && apt-get install -y -qq fuse3 || yum install -y fuse3",
        "curl -s --max-time 60 --connect-timeout 10 https://rclone.org/install.sh | bash",
        "",
        "# Write rclone R2 config (job-scoped temp credentials — NOT master keys)",
        "mkdir -p /root/.config/rclone",
        "cat > /tmp/vaultlayer-rclone.conf << 'RCLONE_EOF'",
        "[r2]",
        "type = s3",
        "provider = Cloudflare",
        f"access_key_id = {r2_key_id}",
        f"secret_access_key = {r2_secret}",
        # session_token only emitted when using scoped temp credentials
        *([ f"session_token = {r2_session_token}" ] if r2_session_token else []),
        f"endpoint = {r2_endpoint}",
        "RCLONE_EOF",
        "",
        # Crack-2 fix: FUSE is for CHECKPOINT writes only, NOT dataset reads.
        # Training data is always copied to local NVMe (/tmp/vl-data/) before
        # training starts, so DataLoader reads are zero-latency local I/O.
        # FUSE mount with --vfs-cache-mode full is appropriate for the
        # checkpoint write path (sequential, large blocks) but catastrophic
        # for shuffle=True dataset reads (thousands of small random reads across
        # the internet to R2).
        "# Mount R2 Neutral Zone for CHECKPOINT I/O only",
        "mkdir -p /mnt/vaultlayer/checkpoints $VL_DATA_ROOT/vaultlayer-rclone-cache",
        "chmod 777 /mnt/vaultlayer",
        f"rclone mount r2:{r2_bucket} /mnt/vaultlayer "
        "--config /tmp/vaultlayer-rclone.conf "
        "--vfs-cache-mode full --vfs-cache-max-size 10240M "
        "--cache-dir $VL_DATA_ROOT/vaultlayer-rclone-cache "
        "--vfs-read-ahead 128M --buffer-size 256M "
        "--transfers 16 --checkers 8 --daemon",
        "",
    ]

    # Crack-2 fix: Copy dataset shards to local NVMe before training starts.
    # This runs synchronously (rclone copy, not mount) so training always reads
    # from local disk at full NVMe bandwidth regardless of DataLoader shuffle mode.
    dataset_id = getattr(job, "dataset_id", None)  # server-validated only; never read from env
    if dataset_id:
        r2_dataset_prefix = f"datasets/{dataset_id}"
        lines += [
            "",
            f"# Crack-2: Copy dataset {dataset_id} from R2 to instance-store NVMe",
            "# VL_DATA_ROOT is /mnt/nvme (NVMe) or /tmp fallback — set above.",
            f"VL_LOCAL_DATA=$VL_DATA_ROOT/vl-data/{dataset_id}",
            f"mkdir -p $VL_LOCAL_DATA",
            f"echo \"[VaultLayer] Warming dataset {dataset_id} to $VL_LOCAL_DATA ...\"",
            # Guard: abort if rclone fails — VAULTLAYER_LOCAL_DATA is NOT exported
            # until the copy succeeds. Background sync remains non-fatal.
            f"rclone copy r2:{r2_bucket}/{r2_dataset_prefix}/ "
            "$VL_LOCAL_DATA/ "
            "--config /tmp/vaultlayer-rclone.conf "
            "--transfers 16 --checkers 8 "
            "--progress"
            f" || {{ echo \"[VaultLayer] FATAL: dataset {dataset_id} warmup failed -- aborting job\"; exit 1; }}",
            f"echo \"[VaultLayer] Dataset ready at $VL_LOCAL_DATA\"",
            "export VAULTLAYER_LOCAL_DATA=$VL_LOCAL_DATA",
            f"echo VAULTLAYER_LOCAL_DATA=$VL_LOCAL_DATA >> /etc/environment",
            "",
            "# Shard background sync: keeps NVMe warm if R2 is updated mid-run (non-fatal)",
            f"nohup rclone sync r2:{r2_bucket}/{r2_dataset_prefix}/ "
            "$VL_LOCAL_DATA/ "
            "--config /tmp/vaultlayer-rclone.conf "
            "--transfers 4 --checkers 4 "
            "> /tmp/vl_shard_sync.log 2>&1 &",
            "export VL_NVME_CACHE=$VL_DATA_ROOT/vl-cache",
            "echo VL_NVME_CACHE=$VL_DATA_ROOT/vl-cache >> /etc/environment",
        ]

    # Set job environment variables (shell-escaped to prevent command injection)
    for key, value in (job.environment or {}).items():
        _escaped = str(value).replace("'", "'\\''")
        lines.append(f"export {key}='{_escaped}'")

    # Level 1 cold-start fix: Background docker pull.
    #
    # BEFORE this fix: docker pull ran synchronously at the END of UserData.
    # UserData blocks SSH until it finishes → node idle for 5-7 min on a
    # 10-20 GB PyTorch/CUDA image → operator pays for idle GPU time.
    #
    # AFTER this fix:
    #   1. docker pull starts in the BACKGROUND immediately at node boot
    #      (in parallel with rclone install, R2 mount, dataset NVMe copy)
    #   2. A sentinel file /tmp/vl_image_ready is created when pull completes
    #   3. The training launcher script waits for /tmp/vl_image_ready before
    #      running the container — guarantees image is available without
    #      blocking SSH readiness or the checkpoint prefetch
    #
    # On re-migration to the same provider (warm node): docker image is already
    # cached on-disk, so `docker image inspect` returns immediately and the
    # pull is skipped entirely → <5s instead of 5-7 min.
    if job.docker_image:
        _img = shlex.quote(job.docker_image)
        lines += [
            "",
            "# Level 1 cold-start fix: background docker pull (non-blocking)",
            "# Image may already be cached from a prior migration to this node",
            f"if docker image inspect {_img} > /dev/null 2>&1; then",
            f"  echo '[VaultLayer] Docker image {_img} already cached — skipping pull'",
            f"  touch /tmp/vl_image_ready",
            "else",
            f"  echo '[VaultLayer] Starting background docker pull: {_img}'",
            f"  (docker pull {_img} && touch /tmp/vl_image_ready) > /tmp/vl_docker_pull.log 2>&1 &",
            f"  echo $! > /tmp/vl_docker_pull.pid",
            f"  echo '[VaultLayer] Docker pull running in background (PID '\"$!\"'). Training will start when ready.'",
            "fi",
        ]

    # P0-L2: write sentinel as the final step so BrokerAgent can confirm
    # bootstrap is complete without a fixed sleep. Placed AFTER docker pull
    # sentinel so /tmp/vl_bootstrap_done implies the whole bootstrap chain.
    lines += [
        "",
        "echo '[VaultLayer] Bootstrap complete'",
        "touch /tmp/vl_bootstrap_done",
    ]

    script = "\n".join(lines) + "\n"
    return base64.b64encode(script.encode()).decode()
