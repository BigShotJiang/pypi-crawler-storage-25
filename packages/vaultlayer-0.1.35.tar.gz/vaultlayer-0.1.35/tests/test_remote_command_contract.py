"""Regression coverage for managed remote command and log contracts."""
from __future__ import annotations

import asyncio
import importlib
import inspect
import sys
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest


def test_python_module_invocation_detects_interpreter_options():
    from cli._remote import _python_module_invocation

    assert _python_module_invocation(["python", "-m", "trainer"]) == "trainer"
    assert _python_module_invocation(["python", "-u", "-m", "trainer"]) == "trainer"
    assert _python_module_invocation(["python3", "-X", "dev", "-m", "trainer"]) == "trainer"
    assert _python_module_invocation(["python", "train.py", "-m", "model"]) is None


def test_known_remote_launchers_are_allowlisted():
    from cli import _remote

    assert "torch.distributed.run" in _remote._ALLOWED_REMOTE_MODULE_LAUNCHERS
    assert "accelerate.commands.launch" in _remote._ALLOWED_REMOTE_MODULE_LAUNCHERS
    assert "deepspeed.launcher.runner" in _remote._ALLOWED_REMOTE_MODULE_LAUNCHERS


def test_bare_local_python_script_command_is_normalized(tmp_path):
    from cli._remote import _normalize_bare_python_script_command

    train = tmp_path / "train.py"
    train.write_text("print('train')\n")

    assert _normalize_bare_python_script_command([str(train)]) == ["python", str(train)]
    assert _normalize_bare_python_script_command([str(train), "--epochs", "3"]) == [
        "python", str(train), "--epochs", "3"
    ]


def test_explicit_python_and_distributed_launchers_are_not_normalized(tmp_path):
    from cli._remote import _normalize_bare_python_script_command

    train = tmp_path / "train.py"
    train.write_text("print('train')\n")

    explicit_python = ["python", str(train)]
    explicit_python_u = ["python", "-u", str(train)]
    torchrun = ["torchrun", "--nproc_per_node=4", str(train)]
    accelerate = ["accelerate", "launch", str(train)]

    assert _normalize_bare_python_script_command(explicit_python) == explicit_python
    assert _normalize_bare_python_script_command(explicit_python_u) == explicit_python_u
    assert _normalize_bare_python_script_command(torchrun) == torchrun
    assert _normalize_bare_python_script_command(accelerate) == accelerate


def test_run_remote_submits_normalized_script_args_for_bare_python_file(tmp_path):
    from cli._remote import run_remote

    train = tmp_path / "train.py"
    train.write_text("print('train')\n")

    run_cmd = SimpleNamespace(command=[str(train), "--epochs", "3"], api_url="https://api.example")
    job = SimpleNamespace(
        gpu_type=SimpleNamespace(value="A10G"),
        environment={},
        docker_image="",
        failover_enabled=True,
        preferred_providers=[],
        excluded_providers=[],
        regions=[],
        excluded_regions=[],
    )
    captured = {}

    def _post(url, **kwargs):
        captured["url"] = url
        captured["json"] = kwargs["json"]
        return SimpleNamespace(status_code=200, json=lambda: {"job_id": "job-normalized"})

    def _get(url, **kwargs):
        return SimpleNamespace(
            status_code=200,
            json=lambda: {"status": "completed", "duration": 1, "price_per_hr": 0.5},
        )

    async def _sleep_noop(*args, **kwargs):
        return None

    with patch("shared.api_utils.get_token", return_value="vl_test_token"), \
         patch("httpx.post", side_effect=_post), \
         patch("httpx.get", side_effect=_get), \
         patch("cli._remote.asyncio.sleep", side_effect=_sleep_noop):
        assert asyncio.run(run_remote(run_cmd, job, broker=MagicMock(), queue=MagicMock())) == 0

    assert captured["url"] == "https://api.example/api/v1/jobs/run"
    assert captured["json"]["script_name"] == "train.py"
    assert captured["json"]["script_args"] == "python train.py --epochs 3"
    assert run_cmd.command == ["python", str(train), "--epochs", "3"]


def test_run_remote_rejects_multiple_local_python_files(tmp_path):
    from cli._remote import run_remote

    train = tmp_path / "train.py"
    helper = tmp_path / "helper.py"
    train.write_text("print('train')\n")
    helper.write_text("print('helper')\n")

    run_cmd = SimpleNamespace(command=["python", str(train), str(helper)])
    job = SimpleNamespace(gpu_type=SimpleNamespace(value="A10G"), environment={})

    with pytest.raises(SystemExit) as exc_info:
        asyncio.run(run_remote(run_cmd, job, broker=None, queue=None))

    assert "supports exactly one local .py script" in str(exc_info.value)


def test_run_remote_rejects_missing_local_python_file():
    from cli._remote import run_remote

    run_cmd = SimpleNamespace(command=["python", "train_quick.py"])
    job = SimpleNamespace(gpu_type=SimpleNamespace(value="A10G"), environment={})

    with pytest.raises(SystemExit) as exc_info:
        asyncio.run(run_remote(run_cmd, job, broker=None, queue=None))

    msg = str(exc_info.value)
    assert "script file not found: train_quick.py" in msg
    assert "path/to/train_quick.py" in msg


def test_format_elapsed_for_cli_heartbeat():
    from cli._remote import _format_elapsed

    assert _format_elapsed(5) == "5s"
    assert _format_elapsed(65) == "1m05s"
    assert _format_elapsed(3670) == "1h01m"


def test_run_remote_remembers_rate_and_duration_for_summary():
    from cli._remote import _remember_remote_status

    run_cmd = SimpleNamespace()
    job = SimpleNamespace(current_hourly_rate=0.0)

    _remember_remote_status(run_cmd, job, {"price_per_hr": 0.07123, "duration": 117})

    assert run_cmd.remote_price_per_hr == 0.07123
    assert run_cmd.remote_duration_seconds == 117.0
    assert job.current_hourly_rate == 0.07123


def test_run_summary_formatters():
    from cli.run import (
        _format_duration_seconds,
        _format_rate_usd_per_hr,
        _supported_model_cap_billion,
    )

    assert _format_duration_seconds(117) == "1m57s"
    assert _format_duration_seconds(3605) == "1h00m"
    assert _format_rate_usd_per_hr(0.07123) == "$0.07/hr"
    assert _format_rate_usd_per_hr(0.0042) == "$0.0042/hr"
    assert _format_rate_usd_per_hr(0) == "unavailable"
    assert _supported_model_cap_billion("qlora", 30.0) == 72.0
    assert _supported_model_cap_billion("full", 30.0) == 30.0


def test_run_remote_rejects_python_dash_m_local_module():
    from cli._remote import run_remote

    run_cmd = SimpleNamespace(command=["python", "-u", "-m", "trainer"])
    job = SimpleNamespace(gpu_type=SimpleNamespace(value="A10G"), environment={})

    with pytest.raises(SystemExit) as exc_info:
        asyncio.run(run_remote(run_cmd, job, broker=None, queue=None))

    assert "'python -m trainer'" in str(exc_info.value)


def test_log_endpoint_and_cli_use_server_side_offset():
    from api import job_routes
    from cli import _remote

    route_src = inspect.getsource(job_routes.get_job_logs)
    cli_src = inspect.getsource(_remote.run_remote)

    assert "offset: int = 0" in route_src
    assert ".range(offset, offset + limit - 1)" in route_src
    assert 'params={"limit": 500, "offset": _last_log_count}' in cli_src
    assert "for line_data in lines:" in cli_src
    assert "_last_log_count += len(lines)" in cli_src
    assert "for line_data in lines[_last_log_count:]" not in cli_src


def test_run_remote_submit_uses_preflight_api_url_and_prints_endpoint():
    from cli import _remote

    src = inspect.getsource(_remote.run_remote)

    assert "api = _api_url_for_remote(run_cmd)" in src
    assert "Error submitting to server at {api}" in src
    assert "unset VAULTLAYER_API_URL" in src


def test_run_remote_submit_sends_model_sizing_metadata(tmp_path, monkeypatch):
    from cli._remote import run_remote
    from shared.models import GPUType
    from unittest.mock import MagicMock, patch

    script = tmp_path / "train.py"
    script.write_text("print('ok')\n")
    run_cmd = SimpleNamespace(
        command=["python", str(script)],
        api_url="https://api.example",
        min_vram_gb=40.0,
        gpu_auto_selected=True,
        model_params_billion=32.0,
        train_mode="qlora",
    )
    job = SimpleNamespace(
        gpu_type=GPUType.RTX5090,
        environment={},
        docker_image="",
        failover_enabled=True,
        preferred_providers=[],
        excluded_providers=[],
        regions=[],
        excluded_regions=[],
    )
    captured = {}

    def _post(url, **kwargs):
        captured["json"] = kwargs["json"]
        return MagicMock(status_code=400, json=MagicMock(return_value={"detail": "stop"}), text="stop")

    with patch("shared.api_utils.get_token", return_value="vl_test_xxx"), \
         patch("httpx.post", side_effect=_post):
        result = asyncio.run(run_remote(run_cmd, job, broker=None, queue=None))

    assert result == 1
    assert captured["json"]["model_params_billion"] == 32.0
    assert captured["json"]["training_mode"] == "qlora"
    assert captured["json"]["min_vram_gb"] == 40.0
    assert captured["json"]["disk_gb"] == 200
    assert captured["json"]["gpu_auto_selected"] is True


def test_run_remote_submit_forwards_cli_env(tmp_path):
    from cli._remote import run_remote
    from shared.models import GPUType

    script = tmp_path / "train.py"
    script.write_text("print('ok')\n")
    run_cmd = SimpleNamespace(command=["python", str(script)], api_url="https://api.example")
    job = SimpleNamespace(
        gpu_type=GPUType.A40,
        environment={"MODEL_ID": "Qwen/Qwen2.5-32B-Instruct"},
        docker_image="",
        failover_enabled=True,
        preferred_providers=[],
        excluded_providers=[],
        regions=[],
        excluded_regions=[],
    )
    captured = {}

    def _post(url, **kwargs):
        captured["json"] = kwargs["json"]
        return MagicMock(status_code=400, json=MagicMock(return_value={"detail": "stop"}), text="stop")

    with patch("shared.api_utils.get_token", return_value="vl_test_xxx"), \
         patch("httpx.post", side_effect=_post):
        result = asyncio.run(run_remote(run_cmd, job, broker=None, queue=None))

    assert result == 1
    assert captured["json"]["environment"]["MODEL_ID"] == "Qwen/Qwen2.5-32B-Instruct"


def test_remote_api_url_prefers_run_command_value(monkeypatch):
    from cli._remote import _api_url_for_remote

    monkeypatch.setenv("VAULTLAYER_API_URL", "https://stale.example")
    run_cmd = SimpleNamespace(api_url="https://vaultlayer-production.up.railway.app/")

    assert _api_url_for_remote(run_cmd) == "https://vaultlayer-production.up.railway.app"


def test_cli_version_import_does_not_load_data_tables():
    sys.modules.pop("cli.main", None)
    sys.modules.pop("cli.estimate", None)
    sys.modules.pop("shared.data_loader", None)

    mod = importlib.import_module("cli.main")

    assert "shared.data_loader" not in sys.modules
    from click.testing import CliRunner
    result = CliRunner().invoke(mod.cli, ["--version"])
    assert result.exit_code == 0
    assert "0.1.35" in result.output
    assert "shared.data_loader" not in sys.modules
