from __future__ import annotations

from unittest.mock import MagicMock, patch

from click.testing import CliRunner


def _response(data: dict, status_code: int = 200):
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = data
    resp.text = ""
    return resp


def test_admin_invite_template_uses_init_prompt_flow():
    from cli.admin_cmd import admin

    token = "vl_invite_" + "a" * 32
    resp = _response(
        {
            "email": "user@example.com",
            "credits_cents": 2500,
            "invite_id": "invite-123",
            "invite_token": token,
        }
    )

    with patch.dict("os.environ", {"VL_INTERNAL_ADMIN_TOKEN": "admin-secret"}), \
         patch("cli.admin_cmd.httpx.post", return_value=resp) as mock_post:
        result = CliRunner().invoke(admin, ["invite", "user@example.com", "--credits", "2500"])

    assert result.exit_code == 0
    assert token in result.output
    assert "vaultlayer init" in result.output
    assert "When prompted, paste this token" in result.output
    assert "export VAULTLAYER_TOKEN" not in result.output
    assert f"VAULTLAYER_TOKEN={token}" not in result.output

    body = mock_post.call_args.kwargs["json"]
    assert body["email"] == "user@example.com"
    assert body["credits_cents"] == 2500


def test_admin_invite_cli_requires_internal_admin_token():
    from cli.admin_cmd import admin

    with patch.dict("os.environ", {}, clear=True), \
         patch("cli.admin_cmd.httpx.post") as mock_post:
        result = CliRunner().invoke(admin, ["invite", "user@example.com"])

    assert result.exit_code != 0
    assert "VL_INTERNAL_ADMIN_TOKEN not set" in result.output
    assert not mock_post.called


def test_admin_invite_api_fails_closed_without_server_admin_token(monkeypatch):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from api import auth
    from api.invite_routes import admin_invites_router

    monkeypatch.setattr(auth, "TESTING_MODE", False)
    monkeypatch.setattr(auth, "INTERNAL_ADMIN_TOKEN", "")
    monkeypatch.delenv("VL_INTERNAL_ADMIN_TOKEN", raising=False)

    app = FastAPI()
    app.include_router(admin_invites_router)
    response = TestClient(app).post(
        "/api/v1/admin/invites",
        json={"email": "user@example.com"},
    )

    assert response.status_code == 503


def test_admin_invite_api_hides_route_without_matching_admin_token(monkeypatch):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from api import auth
    from api.invite_routes import admin_invites_router

    monkeypatch.setattr(auth, "TESTING_MODE", False)
    monkeypatch.setattr(auth, "INTERNAL_ADMIN_TOKEN", "")
    monkeypatch.setenv("VL_INTERNAL_ADMIN_TOKEN", "correct-secret")

    app = FastAPI()
    app.include_router(admin_invites_router)
    client = TestClient(app)

    no_header = client.post(
        "/api/v1/admin/invites",
        json={"email": "user@example.com"},
    )
    wrong_header = client.post(
        "/api/v1/admin/invites",
        json={"email": "user@example.com"},
        headers={"X-Internal-Admin-Token": "wrong-secret"},
    )
    correct_header = client.post(
        "/api/v1/admin/invites",
        json={"email": "not-an-email"},
        headers={"X-Internal-Admin-Token": "correct-secret"},
    )

    assert no_header.status_code == 404
    assert wrong_header.status_code == 404
    assert correct_header.status_code == 400
