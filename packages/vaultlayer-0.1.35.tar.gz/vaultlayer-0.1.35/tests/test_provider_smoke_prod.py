"""
VaultLayer — Live Provider Smoke Tests (Production)
====================================================
Calls REAL provider APIs using credentials fetched from the Railway
credential server (api.vaultlayer.ai). No mocking.

Flow per provider:
  1. Broker calls _get_managed_credentials() → hits Railway credential server
  2. Railway returns VL_* API key for the provider
  3. Broker provisions a real instance with the cheapest available GPU
  4. Test asserts instance_id is returned (API accepted the request)
  5. Broker immediately terminates the instance (_hard_fence_*)

Cheapest GPU per provider (avail=True in instance matrix):
  AWS          A10G          ~$1.10/hr spot  (g5.xlarge)
  Lambda Labs  A10G           $1.10/hr
  RunPod       A100_40GB      $7.60/hr
  Vast.ai      A100_40GB      $5.60/hr
  Voltage Park A100_80GB_SXM $10.00/hr
  Crusoe       A100_40GB      $7.20/hr
  Hyperstack   A100_40GB      $7.00/hr
  GCP          A10G           $2.80/hr

Skipped (not yet available): CoreWeave, Azure

Gate: tests only run when VL_PROD_TEST=1 is set in the environment.
      Requires VAULTLAYER_TOKEN to be set for credential server auth.

Run:
  VL_PROD_TEST=1 VAULTLAYER_TOKEN=vl_live_... pytest tests/test_provider_smoke_prod.py -v -s
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import asyncio
import time
import logging
import warnings
import pytest
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# Suppress noisy warnings from aiohttp/asyncio cleanup on event loop close
warnings.filterwarnings("ignore", message=".*Unclosed client session.*")
warnings.filterwarnings("ignore", message=".*Unclosed connector.*")
warnings.filterwarnings("ignore", category=ResourceWarning)

# Monkey-patch aiohttp.ClientSession.__del__ to suppress the "Unclosed" message.
# This is the ONLY reliable way to silence it — the message is printed directly
# to stderr from C-level destructor, bypassing Python's warnings framework.
try:
    import aiohttp
    aiohttp.ClientSession.__del__ = lambda self: None
    # Also silence the connector
    aiohttp.TCPConnector.__del__ = lambda self: None
except Exception:
    pass

# NOTE: aiohttp prints "Unclosed client session" via C-level stderr writes
# that no Python wrapper can intercept. Use the clean runner script instead:
#   ./scripts/smoke-test.sh crusoe
#   ./scripts/smoke-test.sh "lambda or runpod"
#   ./scripts/smoke-test.sh              (all providers)

from conftest import MockAgentQueue, make_job
from shared.models import GPUType, Provider

logger = logging.getLogger(__name__)

# ── Persistent log file — every prod run appends to logs/smoke_prod_YYYYMMDD.log ─
# This is the audit trail for billing reconciliation. Without this we cannot
# recover instance IDs or timing from past runs.
_log_dir = Path(__file__).parent.parent / "logs"
_log_dir.mkdir(exist_ok=True)
_log_file = _log_dir / f"smoke_prod_{datetime.now(timezone.utc).strftime('%Y%m%d')}.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    handlers=[
        logging.StreamHandler(),                          # terminal
        logging.FileHandler(_log_file, encoding="utf-8"), # persistent file
    ],
)
logger.info(f"=== Prod smoke run started — log: {_log_file} ===")

# ── Load ~/.vaultlayer/config.env so users don't need to manually export vars ─
# This mirrors what `vaultlayer run` does — any token stored by `vaultlayer init`
# is picked up automatically, no manual export needed.
_config_env = Path.home() / ".vaultlayer" / "config.env"
if _config_env.exists():
    try:
        from dotenv import load_dotenv
        load_dotenv(_config_env, override=False)  # env vars already exported take priority
    except ImportError:
        pass  # python-dotenv not installed — fall back to manual export

# ── Gate: skip entire module unless VL_PROD_TEST=1 ───────────────────────────

pytestmark = pytest.mark.skipif(
    os.environ.get("VL_PROD_TEST", "0") != "1",
    reason="Live provider tests skipped — set VL_PROD_TEST=1 to run"
)

VAULTLAYER_TOKEN = os.environ.get("VAULTLAYER_TOKEN", "")
VAULTLAYER_API_URL = os.environ.get("VAULTLAYER_API_URL", "https://vaultlayer-production.up.railway.app")


# ── Minimal config: token-only, no local provider keys ────────────────────────
# Forces broker to use _get_managed_credentials() → Railway credential server

@pytest.fixture(scope="module")
def prod_config():
    """
    Token-only config — no BYOC provider keys.
    The broker will call the Railway credential server for each provider.
    """
    if not VAULTLAYER_TOKEN:
        pytest.skip("VAULTLAYER_TOKEN not set — required for prod tests")

    from shared.config import VaultLayerConfig, CloudflareConfig, RedisConfig
    return VaultLayerConfig(
        token=VAULTLAYER_TOKEN,
        user_id="prod-smoke",
        # No BYOC provider keys — all fetched from Railway credential server
        # AWS keys are VaultLayer's own, stored as VL_AWS_* in Railway
        aws=None,
        # R2 for checkpoint storage (optional — only needed for full E2E)
        cloudflare=None,
        redis=RedisConfig(url=os.environ["UPSTASH_REDIS_URL"])
        if os.environ.get("UPSTASH_REDIS_URL") else None,
        # All provider keys intentionally absent — fetched from credential server
        lambda_labs=None,
        runpod=None,
        vast_ai=None,
        voltage_park=None,
        crusoe=None,
        nebius=None,
        hyperstack=None,
        coreweave=None,
        gcp=None,
        azure=None,
    )


@pytest.fixture(scope="function")  # function scope: fresh broker per test
def prod_broker(prod_config):      # sync fixture — async cleanup handled by smoke-test.sh
    from agents.broker.agent import BrokerAgent
    return BrokerAgent(prod_config, MockAgentQueue())


def _prod_job(provider_tag: str) -> object:
    """Create a smoke job with a recognisable name and the minimal smoke command."""
    j = make_job(job_id=f"prod-smoke-{provider_tag}-{int(time.time()) % 100000:05d}")
    j.command = "python -c \"import time; print('VaultLayer smoke test OK'); time.sleep(5); print('done')\""
    j.docker_image = "pytorch/pytorch:2.3-cuda12.1-cudnn8-runtime"
    j.environment = {"VL_SMOKE_TEST": "1", "VL_PROVIDER": provider_tag}
    return j


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ─────────────────────────────────────────────────────────────────────────────
# BUDGET-GATED GPU CANDIDATE LADDER
# ─────────────────────────────────────────────────────────────────────────────
# Each provider lists GPUs cheapest-first. The smoke test tries each in order
# until one provisions successfully. Budget is $0.20 per provider — at ~60s
# billing, even a $12/hr GPU costs only $0.20/min, so all GPUs qualify.
#
# If the cheapest GPU has no capacity, we move to the next. This eliminates
# "insufficient-capacity" failures without increasing cost.
# ─────────────────────────────────────────────────────────────────────────────

# Max we're willing to SPEND per provider smoke test (not the GPU hourly rate).
# A smoke test provisions + immediately terminates in ~60 seconds.
# At $0.20 budget: max hourly rate = $0.20 * 60 = $12/hr.
# Every GPU under $12/hr qualifies. All current GPUs are under $7/hr
# except B200 ($6.69) — well within budget.
SMOKE_BUDGET_USD = 0.20

# (GPUType, canonical_key, rate_per_hr) — sorted cheapest first per provider
# Prices from config/vaultlayer_data.json (verified 2026-04-05)
_GPU_CANDIDATES: dict[str, list[tuple]] = {
    "lambda_labs": [
        (GPUType.A10G,          "A10G",          0.50),
        (GPUType.A100_40GB,     "A100_40",       0.80),
        (GPUType.A6000,         "A6000",         1.09),
        (GPUType.A100_80GB_SXM, "A100",          1.29),
        (GPUType.H100_80GB_SXM, "H100",          2.49),
    ],
    "runpod": [
        (GPUType.A10G,          "A10G",          0.44),
        (GPUType.A6000,         "A6000",         0.59),
        (GPUType.A40,           "A40",           0.80),
        (GPUType.A100_40GB,     "A100_40GB",     0.95),
        (GPUType.A100_80GB_SXM, "A100",          1.59),
        (GPUType.H100_80GB_SXM, "H100",          2.99),
    ],
    "vast_ai": [
        (GPUType.A10G,          "A10G",          0.36),
        (GPUType.A6000,         "A6000",         0.49),
        (GPUType.A100_40GB,     "A100_40GB",     0.70),
        (GPUType.A100_80GB_SXM, "A100",          1.29),
        (GPUType.H100_80GB_SXM, "H100",          2.49),
    ],
    "aws": [
        (GPUType.A10G,          "A10G",          0.76),
        (GPUType.A100_40GB,     "A100_40",       1.62),
        (GPUType.A100_80GB_SXM, "A100",          3.40),
        (GPUType.H100_80GB_SXM, "H100",          3.90),
    ],
    "crusoe": [
        (GPUType.A100_40GB,     "A100_40GB",     0.90),
        (GPUType.A100_80GB_SXM, "A100",          1.70),
        (GPUType.L40S,          "L40S",          1.50),
        (GPUType.H100_80GB_SXM, "H100",          2.90),
    ],
    "voltage_park": [
        (GPUType.H100_80GB_SXM, "H100",          1.00),
        (GPUType.A100_80GB_SXM, "A100",          1.25),
    ],
    "hyperstack": [
        (GPUType.A100_40GB,     "A100_40GB",     0.88),
        (GPUType.A100_80GB_SXM, "A100",          1.75),
        (GPUType.L40S,          "L40S",          1.50),
        (GPUType.H100_80GB_SXM, "H100",          3.20),
    ],
    "gcp": [
        (GPUType.A10G,          "A10G",          2.80),
        (GPUType.A100_40GB,     "A100_40",       3.50),
    ],
    "nebius": [
        (GPUType.H100_80GB_SXM, "H100",          3.15),
    ],
}


async def _smoke_test_provider(
    prod_broker,
    provider_key: str,
    provider_label: str,
    provision_fn_name: str,
    fence_fn_name: str,
    fetch_billed_fn=None,
) -> tuple[Optional[str], str, float, bool]:
    """
    Shared smoke test runner — tries GPUs cheapest-first within SMOKE_BUDGET_USD.

    Returns (instance_id, gpu_label, rate_per_hr, terminated).
    Logs results to spend_ledger + job_runs.
    """
    candidates = _GPU_CANDIDATES.get(provider_key, [])
    if not candidates:
        logger.error(f"[smoke] No GPU candidates defined for {provider_key}")
        return None, "none", 0.0, False

    job = _prod_job(provider_key)
    provision_fn = getattr(prod_broker, provision_fn_name)
    fence_fn = getattr(prod_broker, fence_fn_name, None)

    # Suppress noisy broker warnings during smoke tests (expected: no R2, no local config)
    _broker_logger = logging.getLogger("agents.broker.agent")
    _prev_level = _broker_logger.level
    _broker_logger.setLevel(logging.CRITICAL)


    instance_id = None
    gpu_label = "unknown"
    rate_per_hr = 0.0
    t0 = time.monotonic()
    provisioned_at = _now()

    # Try GPUs cheapest-first — clean output per attempt
    _attempts = []
    print(f"\n  ── {provider_label} smoke test ({'→'.join(c[1] for c in candidates)}) ──")
    for _gpu, _label, _rate in candidates:
        # Budget check: estimated smoke cost = rate_per_hr / 60 (for ~60s test).
        estimated_smoke_cost = _rate / 60.0
        if estimated_smoke_cost > SMOKE_BUDGET_USD:
            print(f"    {_label:<12} ${_rate:.2f}/hr  ⏭ over budget (${estimated_smoke_cost:.4f} > ${SMOKE_BUDGET_USD})")
            continue

        print(f"    {_label:<12} ${_rate:.2f}/hr  ", end="", flush=True)
        try:
            instance_id = await provision_fn(_gpu, job)
        except Exception as e:
            instance_id = None

        if instance_id:
            gpu_label, rate_per_hr = _label, _rate
            print(f"✓ provisioned ({instance_id})")
            _attempts.append((_label, "provisioned"))
            break
        else:
            print("✗ no capacity")
            _attempts.append((_label, "no capacity"))

    # Log failure to DB if no GPU was provisioned
    if not instance_id:
        _log_smoke_failure(job, provider_key, _attempts)

    # Terminate
    terminated = False
    terminated_at = None
    if instance_id and fence_fn:
        try:
            # Some fence functions take (instance_id), others take (instance_id, job)
            import inspect
            sig = inspect.signature(fence_fn)
            if len(sig.parameters) >= 2 and "job" in sig.parameters:
                await fence_fn(instance_id, job)
            else:
                await fence_fn(instance_id)
            terminated_at = _now()
            terminated = True
        except Exception as e:
            logger.warning(f"[smoke] {provider_label} terminate failed: {e}")

    elapsed = time.monotonic() - t0

    # Fetch provider-billed amount (if API available)
    provider_billed = None
    if terminated and instance_id and fetch_billed_fn:
        try:
            _cfg = prod_broker._get_provider_config(provider_key)
            _api_key = (_cfg.api_key if _cfg else
                        (await prod_broker._get_managed_credentials(provider_key, job.job_id) or {}).get("api_key", ""))
            if _api_key:
                provider_billed = await fetch_billed_fn(_api_key, instance_id)
        except Exception as e:
            logger.warning(f"[smoke] {provider_label} billing fetch failed: {e}")

    # Log to DB
    estimated_cost = None
    if instance_id and terminated_at:
        estimated_cost = _log_smoke_run(
            job, provider_key, gpu_label, instance_id,
            provisioned_at, terminated_at, rate_per_hr,
            provider_billed_usd=provider_billed,
        )
        billed_str = f"${provider_billed:.4f}" if provider_billed is not None else "N/A"
        _print_result(provider_label, gpu_label, f"${rate_per_hr}/hr", instance_id,
                      elapsed, terminated,
                      (terminated_at - provisioned_at).total_seconds(), estimated_cost)
        if provider_billed is not None:
            print(f"  Provider billed: {billed_str}")
    else:
        _print_result(provider_label, gpu_label, f"${rate_per_hr}/hr",
                      instance_id, elapsed, terminated)

    # Restore broker logger
    _broker_logger.setLevel(_prev_level)

    return instance_id, gpu_label, rate_per_hr, terminated


def _print_result(provider: str, gpu: str, price: str, instance_id: Optional[str],
                  elapsed: float, terminated: bool,
                  billing_seconds: Optional[float] = None,
                  estimated_cost_usd: Optional[float] = None):
    if instance_id and terminated:
        cost_str = f"${estimated_cost_usd:.4f}" if estimated_cost_usd is not None else "?"
        billing_str = f"{billing_seconds:.0f}s" if billing_seconds is not None else "?"
        print(f"  ✓ PASS  {provider}  {gpu}  {price}  "
              f"cost={cost_str} ({billing_str})  id={instance_id}")
    elif instance_id and not terminated:
        print(f"  ⚠ WARN  {provider}  {gpu}  provisioned but NOT terminated — check manually!  "
              f"id={instance_id}")
    else:
        print(f"  ✗ FAIL  {provider}  no GPU available ({elapsed:.0f}s)")
    # Always write to log file for audit
    logger.info(
        f"RESULT  provider={provider}  gpu={gpu}  price={price}  "
        f"instance_id={instance_id or 'None'}  "
        f"terminated={terminated}  elapsed={elapsed:.1f}s  "
        f"billing_seconds={billing_seconds}  estimated_cost_usd={estimated_cost_usd}"
    )


def _log_smoke_run(
    job,
    provider: str,
    gpu_type: str,
    instance_id: str,
    provisioned_at: datetime,
    terminated_at: datetime,
    rate_per_hr: float,
    provider_billed_usd: Optional[float] = None,
) -> Optional[float]:
    """
    Write spend_ledger + job_runs records for every smoke test.

    Smoke tests use is_test=True / run_type='smoke_test' so they don't
    trigger user credit deduction, but every detail IS stored so we can:
    - Audit real API costs and catch billing anomalies (RunPod $9.2 incident)
    - Build an admin dashboard showing all job runs including smoke tests
    - Track provision latency and termination success rates per provider

    Returns estimated_cost_usd or None if Supabase is not configured.
    """
    spend_id: Optional[str] = None
    _db_ok = False

    # ── Pre-check: Supabase MUST be configured for prod tests ─────────────────
    # Prod smoke tests cost real money. Every provision + termination MUST be
    # recorded in the database for billing audit. If Supabase is not configured,
    # we still log to file but raise a loud warning that will show in test output.
    try:
        from api.db import get_db, SUPABASE_URL
        if not SUPABASE_URL or not get_db():
            logger.error(
                "[smoke] CRITICAL: Supabase not configured — prod test results will NOT "
                "be stored in the database. Set SUPABASE_URL + SUPABASE_SERVICE_KEY. "
                "This run's data exists ONLY in the log file: %s", _log_file
            )
        else:
            _db_ok = True
    except Exception:
        logger.error("[smoke] CRITICAL: Could not connect to Supabase — results not stored in DB")

    # ── spend_ledger ──────────────────────────────────────────────────────────
    try:
        from shared.spend import record_provision, settle_instance
        spend_id = record_provision(
            job_id=job.job_id,
            provider=provider,
            gpu_type=gpu_type,
            instance_id=instance_id,
            provisioned_at=provisioned_at,
            rate_per_hr=rate_per_hr,
            user_id="smoke-test",
            is_test=True,
            metadata={"smoke_test": True, "job_name": getattr(job, "name", "")},
        )
        estimated_cost = None
        if spend_id:
            # settle_instance returns a dict (user_charged_usd, billing_seconds,
            # estimated_cost_usd, credits_charged, vl_margin_pct, rate_per_hr)
            # so callers can mirror canonical values onto job_runs. The smoke
            # test only needs estimated_cost_usd for its own logging.
            _settled = settle_instance(spend_id, terminated_at, provider_billed_usd)
            if _settled is not None:
                estimated_cost = _settled.get("estimated_cost_usd")
        elif _db_ok:
            logger.error(
                f"[smoke] spend_ledger write returned None despite Supabase being configured. "
                f"Provider={provider} instance={instance_id} — billing data LOST"
            )
    except Exception as e:
        logger.error(f"[smoke] spend_ledger write FAILED: {e}  provider={provider} instance={instance_id}")
        estimated_cost = None

    # ── job_runs ──────────────────────────────────────────────────────────────
    try:
        from shared.job_run_logger import open_run, close_run, compute_billing
        run_id = open_run(
            job_id=job.job_id,
            provider=provider,
            gpu_type=gpu_type,
            instance_id=instance_id,
            provisioned_at=provisioned_at,
            rate_per_hr=rate_per_hr,
            run_type="smoke_test",
            account_id="",                       # anonymous smoke test
            job_name=getattr(job, "name", "") or job.job_id,
            command=getattr(job, "command", "") or "",
            docker_image=getattr(job, "docker_image", "") or "",
            job_triggered_at=provisioned_at,     # smoke test: triggered = provisioned
            spend_ledger_id=spend_id,
            metadata={"smoke_test": True},
        )
        if run_id:
            billing_s, cost_usd, uc_usd, credits = compute_billing(
                provisioned_at, terminated_at, rate_per_hr=rate_per_hr,
            )
            run_duration = (terminated_at - provisioned_at).total_seconds()
            close_run(
                run_id,
                terminated_at=terminated_at,
                billing_seconds=billing_s,
                rate_per_hr=rate_per_hr,
                estimated_cost_usd=cost_usd,
                user_charged_usd=uc_usd,
                credits_charged=credits,
                provider_billed_usd=provider_billed_usd,
                run_duration_seconds=run_duration,
            )
        elif _db_ok:
            logger.error(
                f"[smoke] job_runs write returned None despite Supabase being configured. "
                f"Provider={provider} instance={instance_id} — run data LOST"
            )
    except Exception as e:
        logger.error(f"[smoke] job_runs write FAILED: {e}  provider={provider} instance={instance_id}")

    if not _db_ok:
        logger.warning(
            f"[smoke] DB NOT CONFIGURED — {provider} {gpu_type} instance={instance_id} "
            f"recorded in log file ONLY. Re-run with Supabase configured to store in DB."
        )

    return estimated_cost


# Keep old name as alias for backward compat with any existing callers
_log_smoke_spend = _log_smoke_run


def _log_smoke_failure(
    job,
    provider: str,
    attempted_gpus: list[tuple[str, str]],
) -> None:
    """
    Log a FAILED smoke test to job_runs so it appears in vaultlayer smoke-history.

    Called when all GPU candidates were exhausted without a successful provision.
    Writes a single job_runs row with status='failed' + metadata listing every
    GPU attempted and the failure reason for each.
    """
    try:
        from shared.job_run_logger import open_run, update_run
        _now_ts = datetime.now(timezone.utc)
        gpu_list = [g for g, _ in attempted_gpus]
        reason_list = [r for _, r in attempted_gpus]
        run_id = open_run(
            job_id=job.job_id,
            provider=provider,
            gpu_type=gpu_list[0] if gpu_list else "none",
            instance_id="none",
            provisioned_at=_now_ts,
            rate_per_hr=0.0,
            run_type="smoke_test",
            account_id="",
            job_name=getattr(job, "name", "") or job.job_id,
            metadata={
                "smoke_test": True,
                "status": "failed",
                "attempted_gpus": gpu_list,
                "failure_reasons": reason_list,
            },
        )
        if run_id:
            failure_msg = "All GPUs unavailable: " + ", ".join(
                f"{g} ({r})" for g, r in attempted_gpus
            )
            update_run(run_id, status="failed",
                       failed_at=_now_ts.isoformat(),
                       failure_reason=failure_msg)
            logger.info(f"[smoke] Failure logged to DB: run_id={run_id} provider={provider}")
    except Exception as e:
        logger.warning(f"[smoke] failure DB logging failed: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# Provider billing fetchers
# Called after termination to get the actual billed amount from provider APIs.
# Where no billing API exists, returns None (estimated cost used instead).
# All endpoints verified from official documentation before implementation.
# ─────────────────────────────────────────────────────────────────────────────

async def _fetch_runpod_billed(api_key: str, pod_id: str) -> Optional[float]:
    """Fetch actual billed amount for a RunPod pod.
    Source: https://docs.runpod.io/api-reference/billing/GET/billing/pods
    GET /billing/pods?podId={id} → BillingRecords[].amount (USD)
    """
    import aiohttp
    try:
        async with aiohttp.ClientSession() as s:
            resp = await s.get(
                "https://rest.runpod.io/v1/billing/pods",
                params={"podId": pod_id},
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=aiohttp.ClientTimeout(total=10),
            )
            if resp.status == 200:
                records = await resp.json()
                if records:
                    total = sum(float(r.get("amount", 0)) for r in records)
                    logger.info(f"[smoke] RunPod billed ${total:.4f} for pod {pod_id} ({len(records)} records)")
                    return total
    except Exception as e:
        logger.warning(f"[smoke] RunPod billing fetch failed: {e}")
    return None


async def _fetch_vast_billed(api_key: str, instance_id: str) -> Optional[float]:
    """Fetch actual billed amount for a Vast.ai instance.
    Source: https://docs.vast.ai/api-reference/billing/search-invoices
    GET /api/v0/invoices/search → results[].amount filtered by instance_id
    """
    import aiohttp
    try:
        async with aiohttp.ClientSession() as s:
            resp = await s.get(
                "https://console.vast.ai/api/v0/invoices/search",
                params={"instance_id": instance_id},
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=aiohttp.ClientTimeout(total=10),
            )
            if resp.status == 200:
                data = await resp.json()
                results = data.get("results", [])
                if results:
                    total = sum(float(r.get("amount", 0)) for r in results
                                if str(r.get("instance_id")) == str(instance_id))
                    logger.info(f"[smoke] Vast.ai billed ${total:.4f} for instance {instance_id}")
                    return total if total > 0 else None
    except Exception as e:
        logger.warning(f"[smoke] Vast.ai billing fetch failed: {e}")
    return None


async def _fetch_hyperstack_billed(api_key: str, vm_id: str) -> Optional[float]:
    """Fetch actual billed amount for a Hyperstack VM.
    Source: https://docs.hyperstack.cloud - GET /billing/billing/history/virtual-machine/{vm_id}
    Response: ResourceLevelBillingDetailsMetrics.incurred_bill (float, USD)
    """
    import aiohttp
    try:
        async with aiohttp.ClientSession() as s:
            resp = await s.get(
                f"https://infrahub-api.nexgencloud.com/billing/billing/history/virtual-machine/{vm_id}",
                headers={"api_key": api_key},
                timeout=aiohttp.ClientTimeout(total=10),
            )
            if resp.status == 200:
                data = await resp.json()
                billed = data.get("incurred_bill") or data.get("data", {}).get("incurred_bill")
                if billed is not None:
                    logger.info(f"[smoke] Hyperstack billed ${float(billed):.4f} for VM {vm_id}")
                    return float(billed)
    except Exception as e:
        logger.warning(f"[smoke] Hyperstack billing fetch failed: {e}")
    return None


# ─────────────────────────────────────────────────────────────────────────────
# 1. AWS — cheapest-first within $0.20 budget
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_prod_aws(prod_broker):
    """PROD: AWS — tries GPUs cheapest-first (A10G→A100_40→A100→H100)."""
    iid, gpu, rate, term = await _smoke_test_provider(
        prod_broker, "aws", "AWS",
        "provision_aws", "_hard_fence_aws",
    )
    if not iid:
        pytest.skip("AWS: no GPU capacity available across all candidates")


# ─────────────────────────────────────────────────────────────────────────────
# 2. Lambda Labs — cheapest-first within $0.20 budget
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_prod_lambda(prod_broker):
    """PROD: Lambda Labs — tries GPUs cheapest-first (A10G→A100_40→A6000→A100→H100)."""
    iid, gpu, rate, term = await _smoke_test_provider(
        prod_broker, "lambda_labs", "Lambda Labs",
        "provision_lambda", "_hard_fence_lambda",
    )
    if not iid:
        pytest.skip("Lambda Labs: no GPU capacity available across all candidates")


# ─────────────────────────────────────────────────────────────────────────────
# 3. RunPod — cheapest-first within $0.20 budget
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_prod_runpod(prod_broker):
    """PROD: RunPod — tries GPUs cheapest-first (A10G→A6000→A40→A100_40→A100→H100).
    Fetches actual billed amount from RunPod billing API.
    """
    iid, gpu, rate, term = await _smoke_test_provider(
        prod_broker, "runpod", "RunPod",
        "provision_runpod", "_hard_fence_runpod",
        fetch_billed_fn=_fetch_runpod_billed,
    )
    if not iid:
        pytest.skip("RunPod: no GPU capacity available across all candidates")


# ─────────────────────────────────────────────────────────────────────────────
# 4. Vast.ai — cheapest-first within $0.20 budget
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_prod_vast(prod_broker):
    """PROD: Vast.ai — tries GPUs cheapest-first (A10G→A6000→A100_40→A100→H100→H200).
    Fetches actual billed amount from Vast.ai invoices API.
    """
    iid, gpu, rate, term = await _smoke_test_provider(
        prod_broker, "vast_ai", "Vast.ai",
        "provision_vast", "_hard_fence_vast_ai",
        fetch_billed_fn=_fetch_vast_billed,
    )
    if not iid:
        pytest.skip("Vast.ai: no GPU capacity available across all candidates")


# ─────────────────────────────────────────────────────────────────────────────
# 5. Voltage Park — cheapest-first within $0.20 budget
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_prod_voltage_park(prod_broker):
    """PROD: Voltage Park — tries GPUs cheapest-first (H100→A100)."""
    iid, gpu, rate, term = await _smoke_test_provider(
        prod_broker, "voltage_park", "Voltage Park",
        "provision_voltage_park", "_hard_fence_voltage_park",
    )
    if not iid:
        pytest.skip("Voltage Park: no GPU capacity available across all candidates")


# ─────────────────────────────────────────────────────────────────────────────
# 6. Crusoe — cheapest-first within $0.20 budget
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_prod_crusoe(prod_broker):
    """PROD: Crusoe — tries GPUs cheapest-first (A100_40→L40S→A100→H100)."""
    iid, gpu, rate, term = await _smoke_test_provider(
        prod_broker, "crusoe", "Crusoe",
        "provision_crusoe", "_hard_fence_crusoe",
    )
    if not iid:
        pytest.skip("Crusoe: no GPU capacity available across all candidates")


# ─────────────────────────────────────────────────────────────────────────────
# 7. Hyperstack — cheapest-first within $0.20 budget
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_prod_hyperstack(prod_broker):
    """PROD: Hyperstack — tries GPUs cheapest-first (A100_40→L40S→A100→H100).
    Fetches actual billed amount from Hyperstack billing API.
    """
    iid, gpu, rate, term = await _smoke_test_provider(
        prod_broker, "hyperstack", "Hyperstack",
        "provision_hyperstack", "_hard_fence_hyperstack",
        fetch_billed_fn=_fetch_hyperstack_billed,
    )
    if not iid:
        pytest.skip("Hyperstack: no GPU capacity available across all candidates")


# ─────────────────────────────────────────────────────────────────────────────
# 8. GCP — cheapest-first within $0.20 budget
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_prod_gcp(prod_broker):
    """PROD: GCP — tries GPUs cheapest-first (A10G→A100_40)."""
    iid, gpu, rate, term = await _smoke_test_provider(
        prod_broker, "gcp", "GCP",
        "provision_gcp", "_hard_fence_gcp",
    )
    if not iid:
        pytest.skip("GCP: no GPU capacity available across all candidates")


# ─────────────────────────────────────────────────────────────────────────────
# Skipped providers (not yet onboarded)
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.skip(reason="CoreWeave not available — pending onboarding")
@pytest.mark.asyncio
async def test_prod_coreweave_a10g(prod_broker):
    pass


@pytest.mark.asyncio
async def test_prod_nebius_h100(prod_broker):
    """PROD: Nebius EU — H100 SXM (testing-tier, VL_TEST_USER_IDS only)."""
    iid, gpu, rate, term = await _smoke_test_provider(
        prod_broker, "nebius", "Nebius (EU)",
        "provision_nebius", "_hard_fence_nebius",
    )
    if not iid:
        pytest.skip("Nebius: no GPU capacity available")


@pytest.mark.skip(reason="Azure not available — subscription onboarding pending")
@pytest.mark.asyncio
async def test_prod_azure_a100_40gb(prod_broker):
    pass


# ─────────────────────────────────────────────────────────────────────────────
# Credential server connectivity check
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_prod_credential_server_reachable():
    """
    Verify the Railway credential server is reachable and can serve credentials.
    Uses POST /api/v1/credentials/provider (same endpoint the broker uses) to
    fetch Lambda Labs credentials — a real non-destructive connectivity check.
    """
    if not VAULTLAYER_TOKEN:
        pytest.skip("VAULTLAYER_TOKEN not set")

    import aiohttp
    url = f"{VAULTLAYER_API_URL}/api/v1/credentials/provider"
    headers = {
        "Authorization": f"Bearer {VAULTLAYER_TOKEN}",
        "Content-Type": "application/json",
    }
    t0 = time.monotonic()
    async with aiohttp.ClientSession() as session:
        async with session.post(
            url, headers=headers,
            json={"provider": "lambda_labs", "job_id": "smoke-connectivity-check"},
            timeout=aiohttp.ClientTimeout(total=10),
        ) as r:
            elapsed = time.monotonic() - t0
            body = await r.json()

    assert r.status == 200, (
        f"Credential server returned {r.status} — is Railway up? body={body}"
    )
    assert "api_key" in body or "credentials" in body or body, (
        f"Unexpected credential server response shape: {body}"
    )
    api_key = body.get("api_key") or (body.get("credentials") or {}).get("api_key", "")
    masked = f"{api_key[:8]}..." if api_key and len(api_key) > 8 else "(present)"
    print(f"\n  ✓ Credential server reachable  ({elapsed:.2f}s)")
    print(f"    lambda_labs key: {masked}")

    # Spot-check: key must be present (format varies by how it's stored in Railway)
    assert api_key, "Lambda Labs API key returned empty from credential server"
