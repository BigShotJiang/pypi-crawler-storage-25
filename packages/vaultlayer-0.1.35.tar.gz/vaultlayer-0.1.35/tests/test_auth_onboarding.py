"""
Tests for the new auth/onboarding flows:
  - load_config() with VAULTLAYER_TOKEN only
  - _read_token_from_config_env / _write_token_to_config_env helpers
  - vaultlayer init flow (token validation, config.env writes, --reauth)
  - vaultlayer connect (provider credential storage)
  - vaultlayer connect storage (S3/GCS/Azure credential storage)
  - Storage scanner (detect s3/gcs/azure access in scripts)
  - POST /api/v1/jobs/credentials (scoped R2 + Redis creds)
"""
import os
import sys
import hashlib
import pytest
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))


# ── load_config() ─────────────────────────────────────────────────────────────

class TestLoadConfig:
    def test_token_only_succeeds(self, monkeypatch, tmp_path):
        """load_config() should succeed with only VAULTLAYER_TOKEN set."""
        monkeypatch.setenv("VAULTLAYER_TOKEN", "vl_live_" + "a" * 64)
        # Clear provider env vars to simulate fresh CLI user
        for key in ["AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY",
                    "LAMBDA_LABS_API_KEY", "COREWEAVE_API_KEY",
                    "CLOUDFLARE_ACCOUNT_ID", "UPSTASH_REDIS_URL"]:
            monkeypatch.delenv(key, raising=False)

        # Point config.env loader at a non-existent file
        with patch("shared.config.Path") as mock_path_cls:
            mock_path_cls.return_value = tmp_path / ".vaultlayer" / "config.env"
            from shared.config import load_config
            config = load_config()

        assert config.token == "vl_live_" + "a" * 64
        assert config.aws is None
        assert config.lambda_labs is None
        assert config.cloudflare is None
        assert config.redis is None

    def test_missing_token_raises(self, monkeypatch):
        """load_config() must raise ValueError when no token is set."""
        monkeypatch.delenv("VAULTLAYER_TOKEN", raising=False)
        # Prevent loading from config.env
        with patch("shared.config._load_config_env"):
            from shared.config import load_config
            with pytest.raises(ValueError, match="VAULTLAYER_TOKEN"):
                load_config()

    def test_aws_loaded_when_present(self, monkeypatch):
        """AWS config is populated when both keys are set."""
        monkeypatch.setenv("VAULTLAYER_TOKEN", "vl_live_" + "b" * 64)
        monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AKIA_TEST")
        monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "secret")
        monkeypatch.setenv("AWS_REGION", "eu-west-1")

        with patch("shared.config._load_config_env"):
            from shared.config import load_config
            config = load_config()

        assert config.aws is not None
        assert config.aws.access_key_id == "AKIA_TEST"
        assert config.aws.region == "eu-west-1"

    def test_aws_not_loaded_when_partial(self, monkeypatch):
        """AWS config stays None when only one key is set."""
        monkeypatch.setenv("VAULTLAYER_TOKEN", "vl_live_" + "c" * 64)
        monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AKIA_TEST")
        monkeypatch.delenv("AWS_SECRET_ACCESS_KEY", raising=False)

        with patch("shared.config._load_config_env"):
            from shared.config import load_config
            config = load_config()

        assert config.aws is None

    def test_cloudflare_loaded_when_complete(self, monkeypatch):
        monkeypatch.setenv("VAULTLAYER_TOKEN", "vl_live_" + "d" * 64)
        monkeypatch.setenv("CLOUDFLARE_ACCOUNT_ID", "acct123")
        monkeypatch.setenv("R2_ACCESS_KEY_ID", "r2key")
        monkeypatch.setenv("R2_SECRET_ACCESS_KEY", "r2secret")
        monkeypatch.setenv("R2_ENDPOINT", "https://test.r2.cf.com")

        with patch("shared.config._load_config_env"):
            from shared.config import load_config
            config = load_config()

        assert config.cloudflare is not None
        assert config.cloudflare.r2_bucket == "vaultlayer-checkpoints"  # default

    def test_storage_config_loaded_from_env(self, monkeypatch):
        monkeypatch.setenv("VAULTLAYER_TOKEN", "vl_live_" + "e" * 64)
        monkeypatch.setenv("VL_S3_ACCESS_KEY_ID", "s3key")
        monkeypatch.setenv("VL_S3_SECRET_ACCESS_KEY", "s3secret")

        with patch("shared.config._load_config_env"):
            from shared.config import load_config
            config = load_config()

        assert config.storage is not None
        assert config.storage.has_s3()
        assert not config.storage.has_gcs()

    def test_require_provider_raises_for_missing(self, monkeypatch):
        monkeypatch.setenv("VAULTLAYER_TOKEN", "vl_live_" + "f" * 64)
        # Clear AWS env vars that may have been set by other tests
        monkeypatch.delenv("AWS_ACCESS_KEY_ID", raising=False)
        monkeypatch.delenv("AWS_SECRET_ACCESS_KEY", raising=False)
        monkeypatch.delenv("AWS_DEFAULT_REGION", raising=False)
        with patch("shared.config._load_config_env"):
            from shared.config import load_config, require_provider
            config = load_config()
            with pytest.raises(ValueError, match="aws"):
                require_provider(config, "aws")

    def test_loads_from_config_env_file(self, tmp_path):
        """_load_config_env() reads token from ~/.vaultlayer/config.env."""
        config_env = tmp_path / "config.env"
        config_env.write_text('VAULTLAYER_TOKEN=vl_test_fromfile\n')

        import importlib
        import shared.config as cfg_mod

        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("VAULTLAYER_TOKEN", None)
            with patch("shared.config.Path") as mock_path:
                # Make Path.home() / ".vaultlayer" / "config.env" return our temp file
                mock_home = MagicMock()
                mock_path.home.return_value = mock_home
                mock_home.__truediv__ = lambda s, x: tmp_path if x == ".vaultlayer" else (tmp_path / x)
                cfg_mod._load_config_env()
                # token should now be in environ
                # (test via the file read — just verify no exception)


# ── CLI config.env helpers ────────────────────────────────────────────────────

class TestConfigEnvHelpers:
    def test_write_and_read_token(self, tmp_path):
        from cli.main import _write_token_to_config_env, _read_token_from_config_env
        config_env = tmp_path / "config.env"
        token = "vl_live_" + "x" * 64

        _write_token_to_config_env(config_env, token)
        assert config_env.exists()
        assert oct(config_env.stat().st_mode)[-3:] == "600"
        assert _read_token_from_config_env(config_env) == token

    def test_write_overwrites_existing_token(self, tmp_path):
        from cli.main import _write_token_to_config_env, _read_token_from_config_env
        config_env = tmp_path / "config.env"

        _write_token_to_config_env(config_env, "vl_live_" + "a" * 64)
        _write_token_to_config_env(config_env, "vl_live_" + "b" * 64)

        assert _read_token_from_config_env(config_env) == "vl_live_" + "b" * 64
        # Only one token line
        lines = [l for l in config_env.read_text().splitlines() if l.startswith("VAULTLAYER_TOKEN=")]
        assert len(lines) == 1

    def test_write_preserves_other_keys(self, tmp_path):
        from cli.main import _write_token_to_config_env
        from cli.connect import _append_to_config_env
        config_env = tmp_path / "config.env"

        _write_token_to_config_env(config_env, "vl_live_" + "a" * 64)
        _append_to_config_env(config_env, "LAMBDA_LABS_API_KEY", "lambda123")
        _write_token_to_config_env(config_env, "vl_live_" + "b" * 64)

        text = config_env.read_text()
        assert "LAMBDA_LABS_API_KEY=lambda123" in text
        assert "vl_live_" + "b" * 64 in text

    def test_append_adds_new_key(self, tmp_path):
        from cli.connect import _append_to_config_env
        config_env = tmp_path / "config.env"

        _append_to_config_env(config_env, "RUNPOD_API_KEY", "pod123")
        assert "RUNPOD_API_KEY=pod123" in config_env.read_text()

    def test_append_updates_existing_key(self, tmp_path):
        from cli.connect import _append_to_config_env
        config_env = tmp_path / "config.env"

        _append_to_config_env(config_env, "RUNPOD_API_KEY", "pod_v1")
        _append_to_config_env(config_env, "RUNPOD_API_KEY", "pod_v2")

        text = config_env.read_text()
        lines = [l for l in text.splitlines() if l.startswith("RUNPOD_API_KEY=")]
        assert len(lines) == 1
        assert lines[0] == "RUNPOD_API_KEY=pod_v2"

    def test_read_missing_file_returns_empty(self, tmp_path):
        from cli.main import _read_token_from_config_env
        assert _read_token_from_config_env(tmp_path / "nonexistent.env") == ""

    def test_read_file_without_token_returns_empty(self, tmp_path):
        from cli.main import _read_token_from_config_env
        config_env = tmp_path / "config.env"
        config_env.write_text("LAMBDA_LABS_API_KEY=test\n")
        assert _read_token_from_config_env(config_env) == ""


# ── vaultlayer init CLI ───────────────────────────────────────────────────────

class TestVaultlayerInit:
    def _invoke_init(self, args=None, env=None):
        from click.testing import CliRunner
        from cli.main import cli
        runner = CliRunner(mix_stderr=False)
        env = env or {}
        return runner.invoke(cli, ["init"] + (args or []), env=env, catch_exceptions=False)

    def test_valid_token_writes_config_env(self, tmp_path):
        from click.testing import CliRunner
        from cli.main import cli

        token = "vl_live_" + "g" * 64
        runner = CliRunner()

        with patch("cli.main.Path.home", return_value=tmp_path), \
             patch("httpx.post") as mock_post:
            mock_post.return_value = MagicMock(
                status_code=200,
                json=lambda: {"valid": True, "email": "alice@example.com", "balance_credits": 5000},
                raise_for_status=lambda: None,
            )
            result = runner.invoke(cli, ["init", "--token", token])

        assert result.exit_code == 0
        assert "alice@example.com" in result.output

    def test_invalid_format_exits_1(self, tmp_path):
        from click.testing import CliRunner
        from cli.main import cli
        runner = CliRunner()
        result = runner.invoke(cli, ["init", "--token", "bad_token_format"])
        assert result.exit_code == 1
        assert "Invalid token format" in result.output

    def test_revoked_token_shows_reauth_message(self, tmp_path):
        from click.testing import CliRunner
        from cli.main import cli
        import httpx

        token = "vl_live_" + "h" * 64
        runner = CliRunner()

        mock_resp = MagicMock()
        mock_resp.status_code = 401
        mock_resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "401", request=MagicMock(), response=mock_resp
        )

        with patch("httpx.post", return_value=mock_resp):
            result = runner.invoke(cli, ["init", "--token", token])

        assert result.exit_code == 1
        assert "revoked" in result.output.lower() or "reauth" in result.output

    def test_api_responds_invalid(self, tmp_path):
        from click.testing import CliRunner
        from cli.main import cli

        token = "vl_test_" + "i" * 64
        runner = CliRunner()

        with patch("httpx.post") as mock_post:
            mock_post.return_value = MagicMock(
                status_code=200,
                json=lambda: {"valid": False, "message": "Token not found"},
                raise_for_status=lambda: None,
            )
            result = runner.invoke(cli, ["init", "--token", token])

        assert result.exit_code == 1
        assert "invalid" in result.output.lower() or "not found" in result.output.lower()


# ── _validate_token_or_exit ───────────────────────────────────────────────────

class TestValidateTokenOrExit:
    def test_revoked_token_exits(self, capsys):
        import httpx
        from cli.main import _validate_token_or_exit

        mock_resp = MagicMock()
        mock_resp.status_code = 401
        mock_resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "401", request=MagicMock(), response=mock_resp
        )

        with patch("httpx.post", return_value=mock_resp), \
             pytest.raises(SystemExit) as exc_info:
            _validate_token_or_exit("vl_live_abc")

        assert exc_info.value.code == 1
        out = capsys.readouterr().out
        assert "Token revoked" in out
        assert "fresh invite/token" in out
        assert "Choose [1]" in out

    def test_network_error_warns_and_returns(self, capsys):
        import httpx
        from cli.main import _validate_token_or_exit

        with patch("httpx.post", side_effect=httpx.ConnectError("unreachable")):
            result = _validate_token_or_exit("vl_live_abc")

        assert result == {}  # empty dict on network error


# ── vaultlayer connect storage ────────────────────────────────────────────────

class TestConnectStorage:
    def test_s3_credentials_written_to_config_env(self, tmp_path):
        from click.testing import CliRunner
        from cli.main import cli

        runner = CliRunner()
        with patch("cli.connect.Path.home", return_value=tmp_path), \
             patch("cli.connect._validate_s3_credentials"):  # skip boto3 validation
            result = runner.invoke(
                cli,
                ["connect", "storage", "--provider", "s3"],
                input="AKIA_TEST\nsecret_test\nus-east-1\n\n\n",  # access, secret, region, endpoint(blank), bucket(blank)
            )

        assert result.exit_code == 0
        config_env = tmp_path / ".vaultlayer" / "config.env"
        assert config_env.exists()
        text = config_env.read_text()
        assert "VL_S3_ACCESS_KEY_ID=AKIA_TEST" in text
        assert "VL_S3_SECRET_ACCESS_KEY=secret_test" in text

    def test_gcs_credentials_written(self, tmp_path):
        from click.testing import CliRunner
        from cli.main import cli

        # Create a fake credentials JSON file
        fake_creds = tmp_path / "sa.json"
        fake_creds.write_text('{"type": "service_account"}')

        runner = CliRunner()
        with patch("cli.connect.Path.home", return_value=tmp_path):
            result = runner.invoke(
                cli,
                ["connect", "storage", "--provider", "gcs"],
                input=f"{fake_creds}\nmy-project\n\n",  # creds_path, project, bucket(blank)
            )

        assert result.exit_code == 0
        config_env = tmp_path / ".vaultlayer" / "config.env"
        text = config_env.read_text()
        assert "VL_GCS_CREDENTIALS_JSON" in text
        assert "VL_GCS_PROJECT=my-project" in text


# ── POST /api/v1/jobs/credentials ────────────────────────────────────────────

class TestJobCredentialsEndpoint:
    @pytest.fixture
    def mock_user(self):
        return {"user_id": "user-123", "email": "test@example.com"}

    @pytest.fixture
    def mock_minter(self):
        from shared.r2_credentials import ScopedCredentials
        import time
        minter = MagicMock()
        minter.mint.return_value = ScopedCredentials(
            access_key_id="test-akid",
            secret_access_key="test-secret",
            session_token="test-token",
            job_id="job-abc",
            prefix="checkpoints/job-abc/",
            expires_at=time.time() + 7200,
        )
        return minter

    def test_credentials_returned(self, mock_user, mock_minter, monkeypatch):
        monkeypatch.setenv("R2_ENDPOINT", "https://test.r2.cf.com")
        monkeypatch.setenv("R2_BUCKET", "vaultlayer-checkpoints")
        # UPSTASH_REDIS_URL is intentionally NOT set or used — that field
        # was removed from JobCredentialsResponse to stop leaking pub/sub
        # access to authenticated users (security audit P1-4).

        import api.credits as credits_mod
        import api.job_worker as jw

        # Seed the in-memory job so the new ownership check passes.
        jw._active_jobs[mock_user["user_id"] + "-job"] = None  # placeholder cleanup
        jw._active_jobs.clear()
        jw._active_jobs["job-abc"] = {
            "job_id": "job-abc", "user_id": mock_user["user_id"],
            "status": "running", "gpu_type": "A10G",
        }

        original_minter = credits_mod._r2_minter
        credits_mod._r2_minter = mock_minter
        try:
            from api.models import JobCredentialsRequest
            import asyncio

            async def _test():
                from api.credits import get_job_credentials
                req = JobCredentialsRequest(job_id="job-abc", ttl_seconds=7200)
                result = await get_job_credentials(req, user=mock_user)
                return result

            result = asyncio.run(_test())
            assert result.r2_access_key_id == "test-akid"
            assert result.r2_prefix == "checkpoints/job-abc/"
            # redis_url field was removed from the model — confirm it is gone.
            assert not hasattr(result, "redis_url")
        finally:
            credits_mod._r2_minter = original_minter
            jw._active_jobs.clear()

    def test_503_when_minter_not_configured(self, mock_user, monkeypatch):
        monkeypatch.delenv("CLOUDFLARE_ACCOUNT_ID", raising=False)
        monkeypatch.delenv("R2_ENDPOINT", raising=False)

        import api.credits as credits_mod
        original = credits_mod._r2_minter
        credits_mod._r2_minter = None  # reset

        from api.models import JobCredentialsRequest
        import asyncio
        from fastapi import HTTPException

        async def _test():
            from api.credits import get_job_credentials
            req = JobCredentialsRequest(job_id="job-xyz")
            return await get_job_credentials(req, user=mock_user)

        try:
            with pytest.raises(HTTPException) as exc_info:
                asyncio.run(_test())
            assert exc_info.value.status_code == 503
        finally:
            credits_mod._r2_minter = original

    def test_ttl_clamped_to_4_hours(self, mock_user, mock_minter, monkeypatch):
        monkeypatch.setenv("R2_ENDPOINT", "https://test.r2.cf.com")

        import api.credits as credits_mod
        import api.job_worker as jw

        jw._active_jobs.clear()
        jw._active_jobs["job-ttl"] = {
            "job_id": "job-ttl", "user_id": mock_user["user_id"],
            "status": "running", "gpu_type": "A10G",
        }

        original = credits_mod._r2_minter
        credits_mod._r2_minter = mock_minter

        from api.models import JobCredentialsRequest
        import asyncio

        async def _test():
            from api.credits import get_job_credentials
            req = JobCredentialsRequest(job_id="job-ttl", ttl_seconds=99999)
            await get_job_credentials(req, user=mock_user)
            # Verify minter was called with clamped TTL (max 4*3600=14400)
            call_args = mock_minter.mint.call_args
            return call_args

        try:
            call_args = asyncio.run(_test())
            ttl_used = call_args.kwargs.get("ttl_seconds") or call_args.args[1]
            assert ttl_used <= 4 * 3600
        finally:
            credits_mod._r2_minter = original
            jw._active_jobs.clear()


# ── StorageConfig helpers ─────────────────────────────────────────────────────

class TestStorageConfig:
    def test_has_s3(self):
        from shared.config import StorageConfig
        cfg = StorageConfig(s3_access_key_id="key", s3_secret_access_key="secret")
        assert cfg.has_s3()
        assert not cfg.has_gcs()
        assert not cfg.has_azure()
        assert cfg.has_any()

    def test_has_gcs(self):
        from shared.config import StorageConfig
        cfg = StorageConfig(gcs_credentials_json="/path/to/sa.json")
        assert cfg.has_gcs()
        assert not cfg.has_s3()

    def test_has_azure_connection_string(self):
        from shared.config import StorageConfig
        cfg = StorageConfig(azure_connection_string="DefaultEndpointsProtocol=https;...")
        assert cfg.has_azure()

    def test_empty_has_none(self):
        from shared.config import StorageConfig
        cfg = StorageConfig()
        assert not cfg.has_any()
