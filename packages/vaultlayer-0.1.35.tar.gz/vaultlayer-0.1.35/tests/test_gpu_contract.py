"""GPU key contract tests.

These tests pin the boundary between:
  - pricing rows / CLI auto-selection, which use short keys like H100/GH200;
  - API pricing endpoints, which also accept enum values and aliases;
  - worker provisioning, which validates against GPUType.
"""
from __future__ import annotations

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def _positive_priced_gpu_keys() -> set[str]:
    from shared.data_loader import get_provider_prices

    keys: set[str] = set()
    for provider, gpus in get_provider_prices().items():
        if provider.startswith("_") or not isinstance(gpus, dict):
            continue
        if "Reserved" in provider or "On-Demand" in provider:
            continue
        for gpu, price in gpus.items():
            if isinstance(price, (int, float)) and price > 0:
                keys.add(gpu)
    return keys


def test_every_positive_pricing_gpu_key_reaches_worker_enum():
    from shared.data_loader import resolve_gpu_enum
    from shared.models import GPUType

    for gpu in sorted(_positive_priced_gpu_keys()):
        assert isinstance(resolve_gpu_enum(gpu, strict=True), GPUType), gpu


def test_every_cli_rate_gpu_key_reaches_worker_enum():
    from cli.main import _get_gpu_rates
    from shared.data_loader import resolve_gpu_enum
    from shared.models import GPUType

    for gpu in sorted(_get_gpu_rates()):
        assert isinstance(resolve_gpu_enum(gpu, strict=True), GPUType), gpu


def test_common_gpu_aliases_reach_worker_enum():
    from shared.data_loader import resolve_gpu_enum
    from shared.models import GPUType

    assert resolve_gpu_enum("A10", strict=True) == GPUType.A10G
    assert resolve_gpu_enum("a10g", strict=True) == GPUType.A10G
    assert resolve_gpu_enum("L40", strict=True) == GPUType.L40S
    assert resolve_gpu_enum("H100", strict=True) == GPUType.H100_80GB_SXM
    assert resolve_gpu_enum("A100_40GB", strict=True) == GPUType.A100_40GB
    assert resolve_gpu_enum("GH200", strict=True) == GPUType.GH200


def test_priced_gpu_keys_have_vram_metadata():
    from shared.gpu_sizing import GPU_VRAM_GB

    for gpu in sorted(_positive_priced_gpu_keys()):
        assert gpu in GPU_VRAM_GB, gpu


def test_fallback_chain_nodes_have_vram_metadata():
    from shared.gpu_sizing import GPU_FALLBACK_CHAIN, GPU_VRAM_GB

    nodes = set(GPU_FALLBACK_CHAIN)
    for neighbors in GPU_FALLBACK_CHAIN.values():
        nodes.update(neighbors)
    for gpu in sorted(nodes):
        assert gpu in GPU_VRAM_GB, gpu


def test_production_priced_gpu_keys_are_dispatchable_candidates():
    from api.job_worker import _gpu_has_dispatchable_price
    from shared.data_loader import get_included_providers, get_provider_prices

    prices = get_provider_prices()
    production = set(get_included_providers())
    for provider in sorted(production):
        gpus = prices.get(provider, {})
        assert isinstance(gpus, dict), provider
        for gpu, price in sorted(gpus.items()):
            if isinstance(price, (int, float)) and price > 0:
                assert _gpu_has_dispatchable_price(
                    gpu,
                    {"preferred_providers": [], "excluded_providers": []},
                ), (provider, gpu)


@pytest.mark.asyncio
async def test_pricing_single_gpu_accepts_enum_and_matches_short_key(monkeypatch):
    from api import pricing_routes

    async def fake_prices():
        return ([
            {
                "gpu": "H100",
                "provider": "Vast.ai",
                "price_per_hour": 2.0,
                "availability": "available",
                "region": "us",
                "is_spot": True,
            }
        ], 5)

    monkeypatch.setattr(pricing_routes, "_get_cached_prices", fake_prices)

    response = await pricing_routes.get_gpu_price("H100_80GB_SXM")
    assert response.gpu_type == "H100"
    assert response.compute_tier == 2
    assert response.providers[0].provider == "Vast.ai"


@pytest.mark.asyncio
async def test_pricing_availability_accepts_alias_and_matches_canonical_key(monkeypatch):
    from api import pricing_routes

    async def fake_prices():
        return ([
            {
                "gpu": "A10G",
                "provider": "RunPod",
                "price_per_hour": 0.72,
                "availability": "available",
                "region": "us",
                "is_spot": False,
            }
        ], 5)

    monkeypatch.setattr(pricing_routes, "_get_cached_prices", fake_prices)

    response = await pricing_routes.check_gpu_availability("A10")
    assert response["gpu_type"] == "A10G"
    assert response["available"] is True
    assert response["provider"] == "RunPod"
