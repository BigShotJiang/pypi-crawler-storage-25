"""
Tests for vaultlayer init / login / signup CLI commands.

Covers:
  signup  — disabled, exits 1 with invite-only message
  login   — disabled, exits 1 pointing to vaultlayer init
  init    — all paths:
    A. plain init, no stored token → direct token prompt (no menu)
    B. plain init, stored token exists → skips prompt, validates
    C. plain init, --token flag → validates directly
    D. plain init, invite token (vl_invite_) → redeems, swaps for live token
    E. plain init, invalid invite token → exits 1
    F. plain init, invalid token format → exits 1
    G. plain init, API 401 → exits 1, "revoked" message
    H. plain init, API returns valid=False → exits 1
    I. plain init, network error during validate → warns/continues
    J. token saved to config.env after successful init
    K. --reauth shows only [1]/[2], no signup option
    L. --reauth choice [1] → paste token → validates + saves
    M. --reauth choice [2] → rotate → new token saved, old revoked
    N. --reauth choice [2], no stored token → exits 1
    O. --reauth choice [2], rotate API 401 → exits 1
    P. --reauth choice [2], rotate API 5xx → exits 1
    Q. --reauth with explicit --token flag → skips menu, validates directly
"""
from __future__ import annotations

import os
import sys
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

# Clear VAULTLAYER_TOKEN from the real environment so Click's envvar= pickup
# doesn't interfere with tests that exercise the "no token" prompt paths.
_NO_TOKEN_ENV = {"VAULTLAYER_TOKEN": ""}


# ── helpers ───────────────────────────────────────────────────────────────────

def _runner():
    from click.testing import CliRunner
    return CliRunner()


def _invoke(args, input_text="", home=None):
    from click.testing import CliRunner
    from cli.main import cli
    runner = CliRunner()
    if home:
        with patch("pathlib.Path.home", return_value=home):
            return runner.invoke(cli, args, input=input_text, catch_exceptions=False)
    return runner.invoke(cli, args, input=input_text, catch_exceptions=False)


def _ok_validate(email="user@example.com", balance=1000):
    m = MagicMock()
    m.status_code = 200
    m.raise_for_status = lambda: None
    m.json = lambda: {"valid": True, "email": email, "balance_credits": balance}
    return m


def _invalid_validate(message="Token not found"):
    m = MagicMock()
    m.status_code = 200
    m.raise_for_status = lambda: None
    m.json = lambda: {"valid": False, "message": message}
    return m


def _http_error(status_code):
    import httpx
    m = MagicMock()
    m.status_code = status_code
    m.raise_for_status.side_effect = httpx.HTTPStatusError(
        str(status_code), request=MagicMock(), response=m
    )
    return m


# ── signup ────────────────────────────────────────────────────────────────────

class TestSignupDisabled:
    def test_exits_1(self):
        from click.testing import CliRunner
        from cli.main import cli
        result = CliRunner().invoke(cli, ["signup"])
        assert result.exit_code == 1

    def test_shows_not_available(self):
        from click.testing import CliRunner
        from cli.main import cli
        result = CliRunner().invoke(cli, ["signup"])
        assert "not available" in result.output.lower()

    def test_mentions_vaultlayer_com(self):
        from click.testing import CliRunner
        from cli.main import cli
        result = CliRunner().invoke(cli, ["signup"])
        assert "vaultlayer.com" in result.output

    def test_hidden_from_help(self):
        from click.testing import CliRunner
        from cli.main import cli
        result = CliRunner().invoke(cli, ["--help"])
        assert "signup" not in result.output

    def test_email_flag_still_exits_1(self):
        from click.testing import CliRunner
        from cli.main import cli
        result = CliRunner().invoke(cli, ["signup", "--email", "x@y.com"])
        assert result.exit_code == 1


# ── login ─────────────────────────────────────────────────────────────────────

class TestLoginDisabled:
    def test_exits_1(self):
        from click.testing import CliRunner
        from cli.main import cli
        result = CliRunner().invoke(cli, ["login"])
        assert result.exit_code == 1

    def test_shows_not_available(self):
        from click.testing import CliRunner
        from cli.main import cli
        result = CliRunner().invoke(cli, ["login"])
        assert "not available" in result.output.lower()

    def test_points_to_vaultlayer_init(self):
        from click.testing import CliRunner
        from cli.main import cli
        result = CliRunner().invoke(cli, ["login"])
        assert "vaultlayer init" in result.output

    def test_hidden_from_help(self):
        from click.testing import CliRunner
        from cli.main import cli
        result = CliRunner().invoke(cli, ["--help"])
        assert "login" not in result.output

    def test_email_flag_still_exits_1(self):
        from click.testing import CliRunner
        from cli.main import cli
        result = CliRunner().invoke(cli, ["login", "--email", "x@y.com"])
        assert result.exit_code == 1


# ── init: plain (no --reauth) ─────────────────────────────────────────────────

class TestInitPlain:
    # A. No stored token → direct prompt, no [2] signup menu item
    def test_no_stored_token_no_signup_menu(self, tmp_path):
        token = "vl_live_" + "a" * 64
        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_ok_validate()), \
             patch.dict(os.environ, _NO_TOKEN_ENV):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init"], input=token + "\n", catch_exceptions=False
            )
        assert "[2]" not in result.output
        assert result.exit_code == 0

    def test_no_stored_token_shows_invite_guidance(self, tmp_path):
        token = "vl_live_" + "a" * 64
        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_ok_validate()), \
             patch.dict(os.environ, _NO_TOKEN_ENV):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init"], input=token + "\n", catch_exceptions=False
            )
        # Should mention vaultlayer.com — shown only when no token is stored/passed
        assert "vaultlayer.com" in result.output

    # B. Stored token in config.env → skips prompt
    def test_stored_token_skips_prompt(self, tmp_path):
        token = "vl_live_" + "b" * 64
        cfg = tmp_path / ".vaultlayer"
        cfg.mkdir(mode=0o700)
        (cfg / "config.env").write_text(f"VAULTLAYER_TOKEN={token}\n")

        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_ok_validate(email="stored@example.com")):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(cli, ["init"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "stored@example.com" in result.output

    # C. --token flag → validates directly
    def test_token_flag_validates(self, tmp_path):
        token = "vl_live_" + "c" * 64
        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_ok_validate(email="flag@example.com")):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--token", token], catch_exceptions=False
            )
        assert result.exit_code == 0
        assert "flag@example.com" in result.output

    # D. Invite token → redeems, swaps to live token
    def test_invite_token_redeemed(self, tmp_path):
        invite = "vl_invite_" + "d" * 32
        live = "vl_live_" + "d" * 64

        redeem_resp = MagicMock()
        redeem_resp.status_code = 200
        redeem_resp.raise_for_status = lambda: None
        redeem_resp.json = lambda: {"user_token": live, "email": "invite@example.com"}

        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", side_effect=[redeem_resp, _ok_validate(email="invite@example.com")]):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--token", invite], catch_exceptions=False
            )
        assert result.exit_code == 0
        assert "invite@example.com" in result.output
        saved = (tmp_path / ".vaultlayer" / "config.env").read_text()
        assert live in saved

    # E. Invalid invite token → exits 1
    def test_invite_token_invalid_exits_1(self, tmp_path):
        invite = "vl_invite_" + "e" * 32
        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_http_error(400)):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--token", invite], catch_exceptions=False
            )
        assert result.exit_code == 1
        assert "invalid" in result.output.lower() or "revoked" in result.output.lower() \
               or "expired" in result.output.lower()

    # F. Invalid token format → exits 1
    def test_invalid_token_format_exits_1(self, tmp_path):
        with patch("pathlib.Path.home", return_value=tmp_path):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--token", "not_a_real_token"], catch_exceptions=False
            )
        assert result.exit_code == 1
        assert "invalid token format" in result.output.lower()

    # G. API 401 → exits 1, revoked/reauth message
    def test_api_401_revoked_message(self, tmp_path):
        token = "vl_live_" + "g" * 64
        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_http_error(401)):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--token", token], catch_exceptions=False
            )
        assert result.exit_code == 1
        assert "revoked" in result.output.lower() or "reauth" in result.output.lower()

    # H. API returns valid=False → exits 1
    def test_api_valid_false_exits_1(self, tmp_path):
        token = "vl_test_" + "h" * 64
        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_invalid_validate("Token not found")):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--token", token], catch_exceptions=False
            )
        assert result.exit_code == 1
        assert "invalid" in result.output.lower() or "not found" in result.output.lower()

    # I. Network error during validate → non-fatal (warns + exits 0)
    def test_network_error_during_validate_nonfatal(self, tmp_path):
        import httpx
        token = "vl_live_" + "i" * 64
        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", side_effect=httpx.ConnectError("unreachable")):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--token", token], catch_exceptions=False
            )
        assert result.exit_code == 0 or "could not reach" in result.output.lower()

    # J. Token written to config.env on success
    def test_token_written_to_config_env(self, tmp_path):
        token = "vl_live_" + "j" * 64
        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_ok_validate()):
            from click.testing import CliRunner
            from cli.main import cli
            CliRunner().invoke(
                cli, ["init", "--token", token], catch_exceptions=False
            )
        saved = (tmp_path / ".vaultlayer" / "config.env").read_text()
        assert token in saved


# ── init: --reauth ────────────────────────────────────────────────────────────

class TestInitReauth:
    def _stored(self, tmp_path, token):
        cfg = tmp_path / ".vaultlayer"
        cfg.mkdir(mode=0o700, exist_ok=True)
        (cfg / "config.env").write_text(f"VAULTLAYER_TOKEN={token}\n")

    # K. --reauth shows [1] and [2] only, no signup option
    def test_reauth_shows_two_options_no_signup(self, tmp_path):
        old = "vl_live_" + "k" * 64
        new = "vl_live_" + "knew" + "k" * 60
        self._stored(tmp_path, old)

        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_ok_validate()), \
             patch.dict(os.environ, _NO_TOKEN_ENV):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--reauth", "--output-dir", str(tmp_path / "out")],
                input=f"1\n{new}\n",
                catch_exceptions=False,
            )
        assert "[1]" in result.output
        assert "[2]" in result.output
        assert "fresh invite/token" in result.output
        assert "Rotate my current stored token" in result.output
        assert "only if it still works" in result.output

    # L. --reauth choice [1] → paste token → validates + saves
    def test_reauth_choice1_paste_new_token(self, tmp_path):
        old = "vl_live_" + "l" * 64
        new = "vl_live_" + "lnew" + "l" * 60
        self._stored(tmp_path, old)

        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_ok_validate(email="new@example.com")), \
             patch.dict(os.environ, _NO_TOKEN_ENV):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--reauth", "--output-dir", str(tmp_path / "out")],
                input=f"1\n{new}\n",
                catch_exceptions=False,
            )
        assert result.exit_code == 0
        assert "new@example.com" in result.output
        saved = (tmp_path / ".vaultlayer" / "config.env").read_text()
        assert new in saved

    # M. --reauth choice [2] → rotate → success → new token saved
    def test_reauth_choice3_rotates_token(self, tmp_path):
        old = "vl_live_" + "m" * 64
        new = "vl_live_" + "rotated" + "m" * 57
        self._stored(tmp_path, old)

        rotate_resp = MagicMock()
        rotate_resp.status_code = 200
        rotate_resp.raise_for_status = lambda: None
        rotate_resp.json = lambda: {"token": new, "email": "rotated@example.com", "user_id": "u-1"}

        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", side_effect=[rotate_resp, _ok_validate(email="rotated@example.com")]), \
             patch.dict(os.environ, _NO_TOKEN_ENV):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--reauth", "--output-dir", str(tmp_path / "out")],
                input="2\n",
                catch_exceptions=False,
            )
        assert result.exit_code == 0
        assert "rotated@example.com" in result.output
        assert "revoked" in result.output.lower()
        saved = (tmp_path / ".vaultlayer" / "config.env").read_text()
        assert new in saved

    # N. --reauth choice [2], no stored token → exits 1
    def test_reauth_choice3_no_stored_token_exits_1(self, tmp_path):
        cfg = tmp_path / ".vaultlayer"
        cfg.mkdir(mode=0o700)
        (cfg / "config.env").write_text("LAMBDA_LABS_API_KEY=abc\n")  # no token

        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch.dict(os.environ, _NO_TOKEN_ENV):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--reauth"], input="2\n", catch_exceptions=False
            )
        assert result.exit_code == 1
        assert "no stored token" in result.output.lower()
        assert "fresh invite/token" in result.output

    # O. --reauth choice [2], rotate API 401 → exits 1
    def test_reauth_choice3_rotate_401_exits_1(self, tmp_path):
        old = "vl_live_" + "o" * 64
        self._stored(tmp_path, old)

        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_http_error(401)), \
             patch.dict(os.environ, _NO_TOKEN_ENV):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--reauth"], input="2\n", catch_exceptions=False
            )
        assert result.exit_code == 1
        assert "revoked" in result.output.lower() or "recognised" in result.output.lower()
        assert "choose [1]" in result.output.lower()

    # P. --reauth choice [2], rotate API 5xx → exits 1
    def test_reauth_choice3_rotate_5xx_exits_1(self, tmp_path):
        old = "vl_live_" + "p" * 64
        self._stored(tmp_path, old)

        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_http_error(500)), \
             patch.dict(os.environ, _NO_TOKEN_ENV):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--reauth"], input="2\n", catch_exceptions=False
            )
        assert result.exit_code == 1
        assert "api error" in result.output.lower() or "500" in result.output

    def test_reauth_choice2_rotate_network_error_explains_revoked_recovery(self, tmp_path):
        import httpx

        old = "vl_live_" + "n" * 64
        self._stored(tmp_path, old)

        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", side_effect=httpx.ConnectError("[Errno 8] nodename nor servname provided")), \
             patch.dict(os.environ, _NO_TOKEN_ENV), \
             patch("cli.main._api_url", return_value="https://api.test"):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--reauth"], input="2\n", catch_exceptions=False
            )

        assert result.exit_code == 1
        assert "Could not reach VaultLayer API at https://api.test" in result.output
        assert "still-valid stored token" in result.output
        assert "choose [1]" in result.output.lower()

    def test_init_revoked_token_points_to_fresh_invite_recovery(self, tmp_path):
        token = "vl_live_" + "r" * 64

        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_invalid_validate("Token revoked")), \
             patch.dict(os.environ, _NO_TOKEN_ENV):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli, ["init", "--token", token], catch_exceptions=False
            )

        assert result.exit_code == 1
        assert "Token revoked" in result.output
        assert "fresh invite/token" in result.output
        assert "Choose [1]" in result.output

    # Q. --reauth with explicit --token flag → skips menu, validates directly
    def test_reauth_explicit_token_flag_skips_menu(self, tmp_path):
        token = "vl_live_" + "q" * 64
        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("httpx.post", return_value=_ok_validate(email="explicit@example.com")):
            from click.testing import CliRunner
            from cli.main import cli
            result = CliRunner().invoke(
                cli,
                ["init", "--reauth", "--token", token, "--output-dir", str(tmp_path / "out")],
                catch_exceptions=False,
            )
        assert result.exit_code == 0
        assert "explicit@example.com" in result.output
        # No menu shown when token is explicitly passed
        assert "[1]" not in result.output
        assert "[3]" not in result.output
