"""
Tests for account + payment system:
  - Token generation and hashing
  - Credit balance arithmetic
  - Stripe webhook idempotency
  - Fraud prevention (IP rate limit, card dedup, staged release)
  - CLI credit preflight logic
"""
import hashlib
import math
import pytest
from unittest.mock import AsyncMock, MagicMock, patch


# ── Token helpers ─────────────────────────────────────────────────────────────

class TestTokenHelpers:
    def test_generate_token_format(self):
        from api.db import generate_token
        raw, hashed = generate_token("live")
        assert raw.startswith("vl_live_")
        assert len(raw) == len("vl_live_") + 64   # 32 hex bytes = 64 chars
        assert hashed == hashlib.sha256(raw.encode()).hexdigest()

    def test_generate_token_test_env(self):
        from api.db import generate_token
        raw, _ = generate_token("test")
        assert raw.startswith("vl_test_")

    def test_hash_token_deterministic(self):
        from api.db import hash_token
        token = "vl_live_abc123"
        assert hash_token(token) == hash_token(token)
        assert hash_token(token) != hash_token("vl_live_other")

    def test_tokens_are_unique(self):
        from api.db import generate_token
        tokens = {generate_token("live")[0] for _ in range(100)}
        assert len(tokens) == 100   # no collisions in 100 draws


# ── Credit balance arithmetic ─────────────────────────────────────────────────

class TestCreditArithmetic:
    def test_usd_to_credits(self):
        from api.credits import _usd_to_credits
        assert _usd_to_credits(1.00) == 100
        assert _usd_to_credits(0.01) == 1
        assert _usd_to_credits(2.864) == 287    # ceil($2.864 * 100)
        assert _usd_to_credits(0.001) == 1      # always at least 1

    def test_estimate_credits_includes_buffer(self):
        from api.credits import _estimate_credits
        # $2.86/hr * 2hr = $5.72, + 20% buffer = $6.864 → 687 credits
        result = _estimate_credits(hourly_rate_usd=2.86, hours=2.0)
        expected = math.ceil(2.86 * 2.0 * 1.20 * 100)
        assert result == expected

    def test_estimate_credits_zero_hours(self):
        from api.credits import _estimate_credits
        result = _estimate_credits(hourly_rate_usd=2.86, hours=0.0)
        assert result == 0

    def test_credits_to_usd(self):
        from api.credits import _credits_to_usd
        assert _credits_to_usd(100) == 1.0
        assert _credits_to_usd(1000) == 10.0
        assert _credits_to_usd(286) == 2.86


# ── Stripe webhook idempotency ────────────────────────────────────────────────

class TestStripeWebhookIdempotency:
    @pytest.mark.asyncio
    async def test_duplicate_payment_skipped(self):
        """If the same payment_intent_id is processed twice, credits are added once."""
        from api.stripe_routes import _handle_checkout_completed

        existing_record = [{"id": 1}]  # simulate already-processed

        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.eq.return_value.execute.return_value \
            = MagicMock(data=existing_record)

        with patch("api.stripe_routes.get_user", new_callable=AsyncMock,
                   return_value={"user_id": "usr_1", "email": "test@example.com"}), \
             patch("api.stripe_routes.get_db", return_value=mock_db), \
             patch("api.stripe_routes.add_credit_event") as mock_add, \
             patch("api.stripe_routes.check_card_fingerprint",
                   new_callable=AsyncMock, return_value=(True, "ok")):

            session = {
                "metadata": {"user_id": "usr_1", "package": "starter", "credits": "1000"},
                "payment_intent": "pi_duplicate",
                "customer": None,
                "id": "cs_test",
            }
            await _handle_checkout_completed(session)

        mock_add.assert_not_called()   # no credits added on duplicate

    @pytest.mark.asyncio
    async def test_new_payment_credits_user(self):
        """A fresh payment_intent adds credits to the ledger."""
        from api.stripe_routes import _handle_checkout_completed

        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.eq.return_value.execute.return_value \
            = MagicMock(data=[])   # no existing record → fresh

        with patch("api.stripe_routes.get_user", new_callable=AsyncMock,
                   return_value={"user_id": "usr_1", "email": "test@example.com"}), \
             patch("api.stripe_routes.get_db", return_value=mock_db), \
             patch("api.stripe_routes.add_credit_event") as mock_add, \
             patch("api.stripe_routes.get_balance",
                   return_value={"available_credits": 2000}), \
             patch("api.stripe_routes.send_topup_confirmation",
                   new_callable=AsyncMock), \
             patch("api.stripe_routes.check_card_fingerprint",
                   new_callable=AsyncMock, return_value=(True, "ok")), \
             patch("stripe.PaymentIntent.retrieve",
                   return_value=MagicMock(payment_method=MagicMock(
                       card=MagicMock(fingerprint="fp_abc")))):

            session = {
                "metadata": {"user_id": "usr_1", "package": "starter", "credits": "1000"},
                "payment_intent": "pi_new",
                "customer": "cus_abc",
                "id": "cs_test",
            }
            await _handle_checkout_completed(session)

        mock_add.assert_called_once()
        call_kwargs = mock_add.call_args.kwargs
        assert call_kwargs["amount_credits"] == 1000
        assert call_kwargs["event_type"] == "purchased"


# ── Fraud: IP rate limit ──────────────────────────────────────────────────────

class TestIpRateLimit:
    @pytest.mark.asyncio
    async def test_first_signup_from_subnet_allowed(self):
        from api.fraud import check_ip_rate_limit

        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.eq.return_value.execute.return_value \
            = MagicMock(data=[])   # no existing row

        with patch("api.fraud.get_db", return_value=mock_db):
            allowed, reason = await check_ip_rate_limit("192.168.1.5")
        assert allowed is True

    @pytest.mark.asyncio
    async def test_subnet_at_limit_blocked(self):
        from api.fraud import check_ip_rate_limit, MAX_ACCOUNTS_PER_SUBNET

        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.eq.return_value.execute.return_value \
            = MagicMock(data=[{"subnet": "10.0.0", "account_count": MAX_ACCOUNTS_PER_SUBNET}])

        with patch("api.fraud.get_db", return_value=mock_db):
            allowed, reason = await check_ip_rate_limit("10.0.0.99")
        assert allowed is False
        assert "Too many accounts" in reason

    @pytest.mark.asyncio
    async def test_ipv6_bypasses_subnet_check(self):
        from api.fraud import check_ip_rate_limit
        allowed, reason = await check_ip_rate_limit("2001:db8::1")
        assert allowed is True

    @pytest.mark.asyncio
    async def test_empty_ip_bypasses_check(self):
        from api.fraud import check_ip_rate_limit
        allowed, _ = await check_ip_rate_limit("")
        assert allowed is True


# ── Fraud: card fingerprint dedup ─────────────────────────────────────────────

class TestCardFingerprintDedup:
    @pytest.mark.asyncio
    async def test_same_user_same_card_allowed(self):
        from api.fraud import check_card_fingerprint

        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.eq.return_value.execute.return_value \
            = MagicMock(data=[{"user_id": "usr_1"}])

        with patch("api.fraud.get_db", return_value=mock_db):
            allowed, _ = await check_card_fingerprint("usr_1", "fp_abc")
        assert allowed is True

    @pytest.mark.asyncio
    async def test_different_user_same_card_blocked(self):
        from api.fraud import check_card_fingerprint

        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.eq.return_value.execute.return_value \
            = MagicMock(data=[{"user_id": "usr_existing"}])

        with patch("api.fraud.get_db", return_value=mock_db):
            allowed, reason = await check_card_fingerprint("usr_new", "fp_abc")
        assert allowed is False
        assert "already associated" in reason

    @pytest.mark.asyncio
    async def test_fresh_card_allowed(self):
        from api.fraud import check_card_fingerprint

        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.eq.return_value.execute.return_value \
            = MagicMock(data=[])
        mock_db.table.return_value.upsert.return_value.execute.return_value = MagicMock()

        with patch("api.fraud.get_db", return_value=mock_db):
            allowed, _ = await check_card_fingerprint("usr_1", "fp_new")
        assert allowed is True


# ── Fraud: staged credit release ─────────────────────────────────────────────

class TestStagedCreditRelease:
    @pytest.mark.asyncio
    async def test_staged_bonus_released_after_10_min(self):
        from api.fraud import maybe_release_staged_bonus

        with patch("api.fraud.release_staged_bonus", new_callable=AsyncMock) as mock_release:
            await maybe_release_staged_bonus("usr_1", job_runtime_seconds=601)
            mock_release.assert_called_once_with("usr_1")

    @pytest.mark.asyncio
    async def test_staged_bonus_not_released_before_10_min(self):
        from api.fraud import maybe_release_staged_bonus

        with patch("api.fraud.release_staged_bonus", new_callable=AsyncMock) as mock_release:
            await maybe_release_staged_bonus("usr_1", job_runtime_seconds=599)
            mock_release.assert_not_called()


# ── CLI: GPU hourly rates ─────────────────────────────────────────────────────

class TestGpuRates:
    def test_known_gpu_returns_rate(self):
        import cli.main as _cli_main
        from cli.main import _gpu_hourly_rate
        # Rates are built dynamically; read _GPU_RATES via module ref AFTER build
        # to avoid capturing the pre-build fallback dict via 'from ... import'.
        rate = _gpu_hourly_rate("H100_80GB_SXM")
        assert rate == _cli_main._GPU_RATES["H100_80GB_SXM"]
        assert rate > 0

    def test_unknown_gpu_returns_fallback(self):
        from cli.main import _gpu_hourly_rate
        assert _gpu_hourly_rate("UNKNOWN_GPU_9000") == 1.50

    def test_preflight_credit_estimate(self):
        """CLI estimate should match credits API estimate formula."""
        import math
        import cli.main as _cli_main
        from cli.main import _gpu_hourly_rate
        rate = _gpu_hourly_rate("H100_80GB_SXM")
        estimated_hours = 2.0
        cli_estimate = math.ceil(rate * estimated_hours * 1.20 * 100)
        expected = math.ceil(_cli_main._GPU_RATES["H100_80GB_SXM"] * 2.0 * 1.20 * 100)
        assert cli_estimate == expected


# ── Credit packages ───────────────────────────────────────────────────────────

class TestCreditPackages:
    def test_starter_package_credits(self):
        from api.stripe_routes import CREDITS_PER_PACKAGE, PACKAGE_USD
        assert CREDITS_PER_PACKAGE["starter"] == 1_000
        assert PACKAGE_USD["starter"] == 10

    def test_growth_bonus(self):
        from api.stripe_routes import CREDITS_PER_PACKAGE, PACKAGE_USD
        # Growth: $50 at base rate = 5,000; actual = 5,500 (+10%)
        base = PACKAGE_USD["growth"] * 100
        assert CREDITS_PER_PACKAGE["growth"] > base   # has bonus

    def test_scale_bonus(self):
        from api.stripe_routes import CREDITS_PER_PACKAGE, PACKAGE_USD
        base = PACKAGE_USD["scale"] * 100
        assert CREDITS_PER_PACKAGE["scale"] > base   # has bonus

    def test_signup_bonus_totals(self):
        from api.db import (SIGNUP_BONUS_IMMEDIATE_CREDITS,
                             SIGNUP_BONUS_STAGED_CREDITS,
                             SIGNUP_BONUS_TOTAL_CREDITS)
        # Testing phase: 10,000 immediate credits ($100), 0 staged, 10,000 total.
        # Controlled by SIGNUP_BONUS_CREDITS env var (default 10000 during testing).
        assert SIGNUP_BONUS_IMMEDIATE_CREDITS + SIGNUP_BONUS_STAGED_CREDITS \
               == SIGNUP_BONUS_TOTAL_CREDITS
        assert SIGNUP_BONUS_IMMEDIATE_CREDITS >= 1_000  # at least $10 always
