"""
VaultLayer — 11-Provider Bootstrap Matrix
==========================================

One parametrized test per requirement column × 11 provider rows.

Providers (11)
--------------
VM providers (9):  AWS · Lambda Labs · CoreWeave · GCP · Azure
                   Crusoe · Nebius · Hyperstack · Voltage Park
Container (2):     RunPod · Vast.ai

Requirements checked per provider (columns)
-------------------------------------------
  job_id      — VAULTLAYER_JOB_ID present in bootstrap script
  env_vars    — job.environment keys propagated
  rclone      — rclone installed/invoked
  r2_creds    — job-scoped R2 access_key_id + secret present
  r2_endpoint — R2 endpoint URL present
  r2_mount    — rclone mount /mnt/vaultlayer present
  dataset_cp  — rclone copy r2:<bucket>/datasets/<id>/ present when dataset_id set
  no_dataset  — rclone copy r2: NOT present when dataset_id is absent
  nvme        — NVMe detection block present (VM only; False for containers)
  docker_pull — docker pull present (VM only; False for containers — already in image)
  api_key     — provision method calls the correct bootstrap builder (source check)
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import base64
import contextlib
import inspect
import pytest
from unittest.mock import patch, AsyncMock, MagicMock

from conftest import MockAgentQueue, make_job
from shared.models import GPUType


# ── Fixtures & helpers ────────────────────────────────────────────────────────

@pytest.fixture
def cfg():
    from shared.config import (VaultLayerConfig, AWSConfig, LambdaLabsConfig,
                               CoreWeaveConfig, CloudflareConfig, RedisConfig,
                               AnthropicConfig)
    return VaultLayerConfig(
        token="vl_test_" + "a" * 64,
        user_id="test-user",
        aws=AWSConfig(access_key_id="AK_MASTER", secret_access_key="SK_MASTER"),
        lambda_labs=LambdaLabsConfig(api_key="ll-key"),
        coreweave=CoreWeaveConfig(api_key="cw-key", namespace="ns"),
        cloudflare=CloudflareConfig(
            account_id="cf-acct",
            r2_access_key_id="R2_KEY_ID",
            r2_secret_access_key="R2_SECRET",
            r2_bucket="vl-checkpoints",
            r2_endpoint="https://cf-acct.r2.cloudflarestorage.com",
        ),
        redis=RedisConfig(url="redis://localhost:6379"),
        anthropic=AnthropicConfig(api_key="ant-key"),
    )


def _broker(cfg):
    from agents.broker.agent import BrokerAgent
    return BrokerAgent(cfg, MockAgentQueue())


def _job(dataset_id="ds-pile", env=None):
    j = make_job(job_id="matrix-job-01")
    j.dataset_id = dataset_id
    j.docker_image = "pytorch/pytorch:2.3-cuda12.1"
    j.environment = env or {"CUSTOM_VAR": "custom_val"}
    return j


def _job_no_dataset(env=None):
    j = make_job(job_id="matrix-job-nodataset")
    j.dataset_id = None
    j.docker_image = "pytorch/pytorch:2.3-cuda12.1"
    j.environment = env or {}
    return j


def _decode(s: str) -> str:
    return base64.b64decode(s).decode()


def _script(broker, provider: str, job) -> str:
    """Get the bootstrap script text for a given provider."""
    if provider == "AWS":
        return _decode(broker._build_userdata(job))
    elif provider in ("RunPod", "Vast.ai"):
        return broker._build_container_onstart(job)
    else:
        return broker._build_vm_startup_script(job)


# ── The matrix ───────────────────────────────────────────────────────────────
#
# Columns:
#   provider       display name
#   builder        which _build_* method generates the script
#   nvme           True → must contain NVMe detection block
#   docker_pull    True → must contain "docker pull"  (containers skip this)
#
# Every provider MUST have: job_id, env_vars, rclone, r2_creds, r2_endpoint,
#                           r2_mount, dataset_cp, no_dataset.
#
MATRIX = [
    # provider         builder                     nvme    docker_pull
    ("AWS",           "_build_userdata",           True,   True),
    ("Lambda Labs",   "_build_vm_startup_script",  True,   True),
    ("CoreWeave",     "_build_vm_startup_script",  True,   True),
    ("GCP",           "_build_vm_startup_script",  True,   True),
    ("Azure",         "_build_vm_startup_script",  True,   True),
    ("Crusoe",        "_build_vm_startup_script",  True,   True),
    ("Nebius",        "_build_vm_startup_script",  True,   True),
    ("Hyperstack",    "_build_vm_startup_script",  True,   True),
    ("Voltage Park",  "_build_vm_startup_script",  True,   True),
    ("RunPod",        "_build_container_onstart",  False,  False),
    ("Vast.ai",       "_build_container_onstart",  False,  False),
]

IDS = [row[0] for row in MATRIX]


# ── Column 1: VAULTLAYER_JOB_ID ──────────────────────────────────────────────

@pytest.mark.parametrize("provider,builder,nvme,docker_pull", MATRIX, ids=IDS)
def test_job_id_injected(provider, builder, nvme, docker_pull, cfg):
    s = _script(_broker(cfg), provider, _job())
    # Container onstart uses single-quoted values (KEY='value'), VM uses unquoted
    assert "VAULTLAYER_JOB_ID=" in s and "matrix-job-01" in s, \
        f"[{provider}] VAULTLAYER_JOB_ID not found in bootstrap script"


def test_vm_bootstrap_injects_vaultlayer_ssh_key(cfg, monkeypatch):
    """VM bootstrap must install the broker's public key for root and ubuntu SSH."""
    pubkey = "ssh-ed25519 AAAATEST vaultlayer@test"
    monkeypatch.setenv("VL_SSH_PUBLIC_KEY", pubkey)

    s = _script(_broker(cfg), "Nebius", _job())

    assert pubkey in s
    assert "/root/.ssh/authorized_keys" in s
    assert "/home/ubuntu/.ssh/authorized_keys" in s
    assert "chmod 600 /root/.ssh/authorized_keys" in s
    assert "chmod 600 /home/ubuntu/.ssh/authorized_keys" in s
    assert "chown -R ubuntu:ubuntu /home/ubuntu/.ssh" in s


def test_vm_bootstrap_warns_when_vaultlayer_ssh_key_missing(cfg, monkeypatch):
    """Missing broker SSH key should be explicit in generated VM bootstrap."""
    monkeypatch.delenv("VL_SSH_PUBLIC_KEY", raising=False)

    s = _script(_broker(cfg), "Nebius", _job())

    assert "VL_SSH_PUBLIC_KEY not set" in s
    assert "broker SSH access will fail" in s


# ── Column 2: job.environment propagated ─────────────────────────────────────

@pytest.mark.parametrize("provider,builder,nvme,docker_pull", MATRIX, ids=IDS)
def test_env_vars_propagated(provider, builder, nvme, docker_pull, cfg):
    s = _script(_broker(cfg), provider, _job(env={"MY_KEY": "my_val_42"}))
    # Container onstart uses single-quoted values (KEY='value'), VM uses unquoted
    assert "MY_KEY=" in s and "my_val_42" in s, \
        f"[{provider}] job.environment not propagated into bootstrap script"


# ── Column 3: rclone present ──────────────────────────────────────────────────

@pytest.mark.parametrize("provider,builder,nvme,docker_pull", MATRIX, ids=IDS)
def test_rclone_present(provider, builder, nvme, docker_pull, cfg):
    s = _script(_broker(cfg), provider, _job())
    assert "rclone" in s, \
        f"[{provider}] rclone not found in bootstrap script"


# ── Column 4: R2 access_key_id present ───────────────────────────────────────

@pytest.mark.parametrize("provider,builder,nvme,docker_pull", MATRIX, ids=IDS)
def test_r2_access_key_present(provider, builder, nvme, docker_pull, cfg):
    s = _script(_broker(cfg), provider, _job())
    assert "R2_KEY_ID" in s, \
        f"[{provider}] R2 access_key_id not found in bootstrap script"


# ── Column 5: R2 secret_access_key present ───────────────────────────────────

@pytest.mark.parametrize("provider,builder,nvme,docker_pull", MATRIX, ids=IDS)
def test_r2_secret_present(provider, builder, nvme, docker_pull, cfg):
    s = _script(_broker(cfg), provider, _job())
    assert "R2_SECRET" in s, \
        f"[{provider}] R2 secret_access_key not found in bootstrap script"


# ── Column 6: R2 endpoint URL present ────────────────────────────────────────

@pytest.mark.parametrize("provider,builder,nvme,docker_pull", MATRIX, ids=IDS)
def test_r2_endpoint_present(provider, builder, nvme, docker_pull, cfg):
    s = _script(_broker(cfg), provider, _job())
    assert "r2.cloudflarestorage.com" in s, \
        f"[{provider}] R2 endpoint URL not found in bootstrap script"


# ── Column 7: R2 sync protocol (contract §4: sync-only, no FUSE on validated providers) ──
#
# Contract change 2026-04-21: `rclone mount` removed from every provider
# except AWS (which is out of scope — see docs/job_contract.md §4 and
# tests/test_job_contract.py). The reason: mount needs privileged / CAP_SYS_ADMIN
# which Vast.ai / RunPod containers don't grant, and the silent-fallback path
# doubled bug surface area. Sync-only works everywhere.
_PROVIDERS_STILL_USING_FUSE = {"AWS"}  # build_userdata is not in session scope


@pytest.mark.parametrize("provider,builder,nvme,docker_pull", MATRIX, ids=IDS)
def test_r2_mount_absent_on_validated_providers(provider, builder, nvme, docker_pull, cfg):
    s = _script(_broker(cfg), provider, _job())
    if provider in _PROVIDERS_STILL_USING_FUSE:
        assert "rclone mount" in s, \
            f"[{provider}] still uses FUSE path (build_userdata unchanged this session)"
    else:
        assert "rclone mount" not in s, \
            f"[{provider}] must NOT use rclone mount — sync-only per docs/job_contract.md §4"
        # Sync-only replacement must exist: checkpoint restore + background sync loop
        assert "rclone copy r2:" in s, \
            f"[{provider}] missing rclone-copy restore on sync-only path"


# ── Column 8: dataset rclone copy present when dataset_id set ────────────────

@pytest.mark.parametrize("provider,builder,nvme,docker_pull", MATRIX, ids=IDS)
def test_dataset_copy_with_dataset_id(provider, builder, nvme, docker_pull, cfg):
    s = _script(_broker(cfg), provider, _job(dataset_id="ds-openwebtext"))
    assert "datasets/ds-openwebtext" in s, \
        f"[{provider}] dataset R2 prefix not found when dataset_id='ds-openwebtext'"
    assert "rclone copy r2:" in s, \
        f"[{provider}] 'rclone copy r2:' not found when dataset_id is set"


# ── Column 9: no dataset copy when dataset_id absent ─────────────────────────

@pytest.mark.parametrize("provider,builder,nvme,docker_pull", MATRIX, ids=IDS)
def test_no_dataset_copy_without_dataset_id(provider, builder, nvme, docker_pull, cfg):
    s = _script(_broker(cfg), provider, _job_no_dataset())
    # Contract §4 change 2026-04-21: `rclone copy r2:<bucket>/checkpoints/...`
    # now runs on every leg (for resume-from-R2 restore), so we can't just
    # assert "rclone copy r2:" is absent. Narrow the check to the dataset
    # path specifically: no `r2:<bucket>/datasets/` copy when dataset_id
    # isn't set.
    assert "/datasets/" not in s, \
        f"[{provider}] dataset prefix '/datasets/' must not appear when dataset_id is absent"


# ── Column 10: NVMe detection (VM only) ──────────────────────────────────────

@pytest.mark.parametrize("provider,builder,nvme,docker_pull", MATRIX, ids=IDS)
def test_nvme_detection(provider, builder, nvme, docker_pull, cfg):
    s = _script(_broker(cfg), provider, _job())
    if nvme:
        assert "nvme" in s.lower(), \
            f"[{provider}] NVMe detection block missing from VM bootstrap script"
        assert "VL_DATA_ROOT" in s, \
            f"[{provider}] VL_DATA_ROOT missing from VM bootstrap script"
    else:
        assert "lsblk" not in s, \
            f"[{provider}] container script must not probe block devices (lsblk)"
        assert "mdadm" not in s, \
            f"[{provider}] container script must not attempt NVMe RAID (mdadm)"


# ── Column 11: docker pull (VM) / no docker pull (container) ─────────────────

@pytest.mark.parametrize("provider,builder,nvme,docker_pull", MATRIX, ids=IDS)
def test_docker_handling(provider, builder, nvme, docker_pull, cfg):
    s = _script(_broker(cfg), provider, _job())
    if docker_pull:
        assert "docker pull" in s, \
            f"[{provider}] VM bootstrap must pull the Docker image"
    else:
        assert "docker pull" not in s, \
            f"[{provider}] container onstart must not 'docker pull' (already in container)"


# ── Column 12: correct bootstrap builder wired into provision_* ───────────────
#
# For AWS: provision_aws → _create_launch_template → _build_userdata
# For containers: provision_* → _build_container_onstart
# For all other VMs: provision_* → _build_vm_startup_script

PROVISION_MAP = [
    ("AWS",           "provision_aws",           "aws",           "_create_launch_template"),
    ("Lambda Labs",   "provision_lambda",        "lambda_labs",   "prepare_startup"),
    ("CoreWeave",     "provision_coreweave",     "coreweave",     "_build_vm_startup_script"),
    ("GCP",           "provision_gcp",           "gcp",           "_build_vm_startup_script"),
    ("Azure",         "provision_azure",         "azure",         "_build_vm_startup_script"),
    ("Crusoe",        "provision_crusoe",        "crusoe",        "_build_vm_startup_script"),
    ("Nebius",        "provision_nebius",        "nebius",        "_build_vm_startup_script"),
    ("Hyperstack",    "provision_hyperstack",    "hyperstack",    "_build_vm_startup_script"),
    ("Voltage Park",  "provision_voltage_park",  "voltage_park",  "_build_vm_startup_script"),
    ("RunPod",        "provision_runpod",        "runpod",        "prepare_startup"),
    ("Vast.ai",       "provision_vast",          "vast_ai",       "prepare_startup"),
]

@pytest.mark.parametrize("provider,method,mod_name,builder", PROVISION_MAP, ids=[r[0] for r in PROVISION_MAP])
def test_provision_calls_correct_builder(provider, method, mod_name, builder, cfg):
    """Verify provision delegates to provider module and module calls correct builder."""
    from agents.broker.agent import BrokerAgent
    # Check delegation exists
    fn = getattr(BrokerAgent, method, None)
    assert fn is not None, f"BrokerAgent.{method} not found"
    src = inspect.getsource(fn)
    assert mod_name in src, f"[{provider}] {method}() must delegate to providers.{mod_name}"
    # Check provider module calls the correct builder
    import importlib
    mod = importlib.import_module(f"agents.broker.providers.{mod_name}")
    mod_src = inspect.getsource(mod.provision)
    assert builder in mod_src or "prepare_startup" in mod_src, \
        f"[{provider}] providers/{mod_name}.py provision() must call {builder}()"


def test_aws_launch_template_calls_build_userdata(cfg):
    """_create_launch_template must call _build_userdata (the AWS full bootstrap)."""
    from agents.broker.agent import BrokerAgent
    src = inspect.getsource(BrokerAgent._create_launch_template)
    assert "_build_userdata" in src


# ── Spot-check: injection key per provider API call ───────────────────────────
#
# Verifies that each provider's provision_* sends the bootstrap via the correct
# field name in its API payload (source-code check).

INJECTION_KEY_MAP = [
    ("Lambda Labs",   "lambda_labs",    "user_data"),
    ("CoreWeave",     "coreweave",      "cloudInitNoCloud"),
    ("GCP",           "gcp",            "startup-script"),
    ("Azure",         "azure",          "custom_data"),
    ("Crusoe",        "crusoe",         "startup_script"),
    ("Nebius",        "nebius",         "user-data"),
    ("Hyperstack",    "hyperstack",     "user_data"),
    ("Voltage Park",  "voltage_park",   "user_data"),
    ("RunPod",        "runpod",         "dockerEntrypoint"),
    ("Vast.ai",       "vast_ai",        "onstart"),
]

@pytest.mark.parametrize("provider,mod_name,api_key", INJECTION_KEY_MAP,
                          ids=[r[0] for r in INJECTION_KEY_MAP])
def test_api_injection_key_present(provider, mod_name, api_key, cfg):
    import importlib
    mod = importlib.import_module(f"agents.broker.providers.{mod_name}")
    src = inspect.getsource(mod.provision)
    assert api_key in src, \
        f"[{provider}] provision call must use API field '{api_key}' to inject bootstrap"


# ── Live API call: RunPod ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_runpod_live_payload(cfg):
    """provision_runpod sends bootstrap via env dict + REST API body."""
    broker = _broker(cfg)
    job = _job(dataset_id="ds-pile", env={"RP_VAR": "rp_val"})

    mock_resp = MagicMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.status = 200
    # REST API response structure
    mock_resp.json = AsyncMock(return_value={"id": "rp-pod-abc"})

    mock_session = MagicMock()
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=False)
    mock_session.post = MagicMock(return_value=mock_resp)

    rp_cfg = MagicMock(); rp_cfg.api_key = "rp-key"
    cfg.runpod = rp_cfg

    with patch("agents.broker.agent.aiohttp.ClientSession", return_value=mock_session):
        with patch("shared.data_loader.is_gpu_available", return_value=True):
            with patch("shared.data_loader.get_instance_string", return_value="H100"):
                with patch("shared.data_loader.resolve_gpu_key", return_value="H100_80GB"):
                    result = await broker.provision_runpod(GPUType.H100_80GB_SXM, job)

    assert result == "rp-pod-abc"
    # REST API sends top-level body — env is a dict (not array of {key, value})
    rest_payload = mock_session.post.call_args[1]["json"]
    env_dict = rest_payload["env"]
    assert isinstance(env_dict, dict), f"env must be a dict, got {type(env_dict)}"
    assert env_dict["VAULTLAYER_JOB_ID"] == job.job_id
    assert env_dict["RP_VAR"] == "rp_val"
    # Bootstrap script is passed via VL_ONSTART_B64 env var (base64 encoded)
    import base64
    on_start_b64 = env_dict["VL_ONSTART_B64"]
    on_start = base64.b64decode(on_start_b64).decode()
    assert "rclone" in on_start
    assert "R2_KEY_ID" in on_start
    assert "datasets/ds-pile" in on_start
    assert "docker pull" not in on_start
    # dockerEntrypoint should decode and execute the onstart script
    docker_entrypoint = rest_payload["dockerEntrypoint"]
    entrypoint_str = " ".join(docker_entrypoint) if isinstance(docker_entrypoint, list) else docker_entrypoint
    assert "VL_ONSTART_B64" in entrypoint_str
    assert "base64 -d" in entrypoint_str


# ── Live API call: Vast.ai ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_vast_live_payload(cfg):
    """provision_vast sends onstart with full R2 + dataset bootstrap."""
    broker = _broker(cfg)
    job = _job(dataset_id="ds-c4")

    mock_balance = MagicMock()
    mock_balance.__aenter__ = AsyncMock(return_value=mock_balance)
    mock_balance.__aexit__ = AsyncMock(return_value=False)
    mock_balance.status = 200
    mock_balance.json = AsyncMock(return_value={"credit": 100.0})

    mock_search = MagicMock()
    mock_search.__aenter__ = AsyncMock(return_value=mock_search)
    mock_search.__aexit__ = AsyncMock(return_value=False)
    mock_search.status = 200
    mock_search.json = AsyncMock(return_value={"offers": [{"id": "offer-7"}]})

    def _get_side(url, **kw):
        if "/users/current" in str(url):
            return mock_balance
        return mock_search

    mock_put = MagicMock()
    mock_put.__aenter__ = AsyncMock(return_value=mock_put)
    mock_put.__aexit__ = AsyncMock(return_value=False)
    mock_put.status = 200
    mock_put.json = AsyncMock(return_value={"new_contract": "vast-7"})

    mock_session = MagicMock()
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=False)
    mock_session.get = MagicMock(side_effect=_get_side)
    # /api/v0/bundles/ search is POST per current Vast.ai docs.
    mock_session.post = MagicMock(return_value=mock_search)
    mock_session.put = MagicMock(return_value=mock_put)

    vast_cfg = MagicMock(); vast_cfg.api_key = "vast-key"
    cfg.vast_ai = vast_cfg

    with patch("agents.broker.agent.aiohttp.ClientSession", return_value=mock_session):
        with patch("shared.data_loader.is_gpu_available", return_value=True):
            with patch("shared.data_loader.get_instance_string", return_value="RTX_4090"):
                with patch("shared.data_loader.resolve_gpu_key", return_value="H100_80GB"):
                    await broker.provision_vast(GPUType.H100_80GB_SXM, job)

    payload = mock_session.put.call_args[1]["json"]
    on_start = payload["onstart"]
    assert "rclone" in on_start
    assert "R2_KEY_ID" in on_start
    assert "datasets/ds-c4" in on_start
    assert "VAULTLAYER_JOB_ID=" in on_start and job.job_id in on_start
    assert "docker pull" not in on_start


# ── Live API call: Lambda Labs ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_lambda_live_payload(cfg):
    """provision_lambda sends user_data (b64) with full rclone + R2 bootstrap."""
    broker = _broker(cfg)
    job = _job(dataset_id="ds-openwebtext")

    def _make_resp(payload, status=200):
        r = MagicMock()
        r.__aenter__ = AsyncMock(return_value=r)
        r.__aexit__ = AsyncMock(return_value=False)
        r.status = status
        r.json = AsyncMock(return_value=payload)
        r.text = AsyncMock(return_value=str(payload))
        return r

    # GET /ssh-keys → key exists so no creation needed
    # GET /instance-types → capacity in us-east-1
    get_payloads = {
        "ssh-keys": {"data": [{"name": "vaultlayer-key"}]},
        "instance-types": {"data": {"gpu_1x_h100_sxm5": {
            "regions_with_capacity_available": [{"name": "us-east-1"}]}}},
    }
    def _get_side(url, **kw):
        for frag, payload in get_payloads.items():
            if frag in str(url):
                return _make_resp(payload)
        return _make_resp({})

    launch_resp = _make_resp({"data": {"instance_ids": ["ll-i-1"]}})

    mock_session = MagicMock()
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=False)
    mock_session.get = MagicMock(side_effect=_get_side)
    mock_session.post = MagicMock(return_value=launch_resp)

    with patch("agents.broker.agent.aiohttp.ClientSession", return_value=mock_session):
        result = await broker.provision_lambda(GPUType.H100_80GB_SXM, job)

    assert result == "ll-i-1"
    payload = mock_session.post.call_args[1]["json"]
    # Lambda user_data is now plain text (not base64) — fixed via provider registry
    user_data = payload["user_data"]
    assert user_data.startswith("#!/bin/bash"), \
        f"Lambda user_data must be plain text, got: {user_data[:40]}"
    assert "rclone" in user_data
    assert "datasets/ds-openwebtext" in user_data
    assert f"VAULTLAYER_JOB_ID" in user_data


# ── Live API call: CoreWeave ──────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_coreweave_live_payload(cfg):
    """provision_coreweave sends cloudInitNoCloud.userData with full bootstrap."""
    broker = _broker(cfg)
    job = _job(dataset_id="ds-pile")

    mock_resp = MagicMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.status = 201
    mock_resp.json = AsyncMock(return_value={"metadata": {"name": "vl-cw"}})

    mock_session = MagicMock()
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=False)
    mock_session.post = MagicMock(return_value=mock_resp)

    with patch("agents.broker.agent.aiohttp.ClientSession", return_value=mock_session):
        await broker.provision_coreweave(GPUType.H100_80GB_SXM, job)

    body = mock_session.post.call_args[1]["json"]
    vols = body["spec"]["volumes"]
    ci_vol = next(v for v in vols if "cloudInitNoCloud" in v)
    ud = ci_vol["cloudInitNoCloud"]["userData"]
    assert "rclone" in ud
    assert "R2_KEY_ID" in ud
    assert "datasets/ds-pile" in ud
    assert f"VAULTLAYER_JOB_ID={job.job_id}" in ud
