"""Regression tests for AWS EC2 UserData R2 startup shimming."""
from __future__ import annotations

import base64
import os
import sys
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from agents.broker.providers import aws
from shared.failure_codes import JobFailureCode
from shared.models import GPUType


def _job():
    return SimpleNamespace(
        job_id="job-aws-shim-1234",
        docker_image="",
        name="aws-shim-test",
        failure_code=None,
        failure_detail=None,
    )


def _broker(script: str):
    broker = MagicMock()
    broker._build_vm_startup_script.return_value = script
    return broker


def _ec2():
    ec2 = MagicMock()
    ec2.describe_images.return_value = {
        "Images": [
            {"ImageId": "ami-0mock0000000000a1", "CreationDate": "2024-01-01T00:00:00.000Z"}
        ]
    }
    ec2.describe_key_pairs.return_value = {"KeyPairs": [{"KeyName": "vaultlayer-us-east-1"}]}
    ec2.create_launch_template.return_value = {}
    return ec2


def _decoded_userdata(ec2) -> str:
    data = ec2.create_launch_template.call_args.kwargs["LaunchTemplateData"]
    return base64.b64decode(data["UserData"]).decode()


def test_aws_launch_template_routes_oversized_userdata_via_checked_r2_shim(monkeypatch):
    """Oversized AWS startup script must be uploaded and fetched with checked failure semantics."""
    startup_script = "#!/bin/bash\n" + ("echo bootstrap\n" * 2000)
    job = _job()
    ec2 = _ec2()
    uploaded = {}

    def _fake_upload(**kwargs):
        uploaded.update(kwargs)
        return "https://r2.example/jobs/job-aws-shim-1234-startup/vl_startup.sh?X-Amz-Signature=abc"

    monkeypatch.setenv("VL_STARTUP_SCRIPT_URL_TTL", "900")
    with patch("shared.script_upload.upload_script_and_sign", side_effect=_fake_upload):
        template_name = aws._create_launch_template(
            _broker(startup_script), ec2, job, GPUType.A10G, "us-east-1"
        )

    assert template_name == "vl-job-aws--A10G"
    assert base64.b64decode(uploaded["script_b64"]).decode() == startup_script
    assert uploaded["job_id"] == "job-aws-shim-1234-startup"
    assert uploaded["script_name"] == "vl_startup.sh"
    assert uploaded["ttl_seconds"] == 900

    shim = _decoded_userdata(ec2)
    assert len(shim.encode()) < 16384
    assert "set -euo pipefail" in shim
    assert "curl -fsSL" in shim
    assert "-o \"${_vl_startup}\"" in shim
    assert "python3 - \"${_vl_url}\" \"${_vl_startup}\"" in shim
    assert "exec bash \"${_vl_startup}\"" in shim
    assert "| bash" not in shim
    assert "echo bootstrap" not in shim


def test_aws_launch_template_marks_upload_failure_when_userdata_is_oversized():
    """If full startup upload fails, AWS provisioning should surface a specific failure code."""
    startup_script = "#!/bin/bash\n" + ("echo bootstrap\n" * 2000)
    job = _job()
    ec2 = _ec2()

    def _fail_upload(**kwargs):
        import shared.script_upload as script_upload
        script_upload.LAST_UPLOAD_ERROR = "R2 creds missing: R2_ENDPOINT"
        return None

    with patch("shared.script_upload.upload_script_and_sign", side_effect=_fail_upload), \
         pytest.raises(ValueError, match="R2 upload of startup script also failed"):
        aws._create_launch_template(_broker(startup_script), ec2, job, GPUType.A10G, "us-east-1")

    assert job.failure_code == JobFailureCode.PROV_SCRIPT_UPLOAD_FAILED.value
    assert "R2 creds missing: R2_ENDPOINT" in job.failure_detail
    ec2.create_launch_template.assert_not_called()
