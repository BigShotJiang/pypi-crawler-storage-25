"""Tests for issue #126 — recovered running jobs must restore full job intent.

Before this fix, the recovery path hardcoded script_b64='', script_name='',
environment={}, and failover=True for all recovered running rows. After an API
restart, any subsequent failover would try to relaunch a job with no script,
no environment, and with failover forcibly enabled even for jobs submitted with
failover=False.

The fix reads the original submission from job_runs.queue_state (written at
submit time) and uses those values when rebuilding the in-memory job dict.
Legacy rows without queue_state now default to protected recovery.
"""
from __future__ import annotations

import os
import sys
import time
from datetime import datetime, timezone
from unittest.mock import MagicMock

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def _make_row(job_id, instance_id, queue_state=None, docker_image=""):
    prov_ts = time.time() - 60  # 1 minute ago
    prov_iso = datetime.fromtimestamp(prov_ts, tz=timezone.utc).isoformat()
    return {
        "run_id": f"run-{job_id}",
        "job_id": job_id,
        "account_id": "user-1",
        "instance_id": instance_id,
        "provider": "lambda_labs",
        "gpu_type": "A100_40GB",
        "rate_per_hr": 2.5,
        "status": "running",
        "spend_ledger_id": "sl-1",
        "provisioned_at": prov_iso,
        "docker_image": docker_image,
        "queue_state": queue_state or {},
    }


def _recover(rows):
    """Simulate the recovery logic from _job_worker() startup for running rows."""
    active_jobs = {}
    for row in rows:
        jid = row["job_id"]
        inst = row.get("instance_id")
        if jid in active_jobs or not inst or inst == "pending":
            continue
        _prov_ts = None
        if row.get("provisioned_at"):
            try:
                from dateutil.parser import parse as _p
                _prov_ts = _p(row["provisioned_at"]).timestamp()
            except Exception:
                pass
        _qs = row.get("queue_state") or {}
        active_jobs[jid] = {
            "job_id": jid,
            "user_id": _qs.get("user_id") or row.get("account_id", ""),
            "gpu_type": row.get("gpu_type", ""),
            "script_b64":  _qs.get("script_b64", ""),
            "script_name": _qs.get("script_name", ""),
            "environment": _qs.get("environment") or {},
            "docker_image": (_qs.get("docker_image") or row.get("docker_image") or ""),
            "failover": bool(_qs.get("failover", True)),
            "status": "running",
            "instance_id": inst,
            "provider": row.get("provider"),
            "price_per_hr": row.get("rate_per_hr"),
            "actual_gpu_type": row.get("gpu_type", ""),
            "log_line_count": 0,
            "started_at": _prov_ts,
            "completed_at": None, "duration": None,
            "error": None, "checkpoint_step": None,
            "preferred_providers":  _qs.get("preferred_providers") or [],
            "excluded_providers":   _qs.get("excluded_providers") or [],
            "regions":              _qs.get("regions") or [],
            "excluded_regions":     _qs.get("excluded_regions") or [],
            "resume_from_job_id":   _qs.get("resume_from_job_id"),
            "min_vram_gb":          float(_qs.get("min_vram_gb") or 0),
            "gpu_auto_selected":    bool(_qs.get("gpu_auto_selected")),
            "dataset_id":           _qs.get("dataset_id") or "",
            "dataset_r2_prefix":    _qs.get("dataset_r2_prefix") or "",
            "queued_at": _prov_ts or time.time(),
            "_run_id": row.get("run_id"),
            "_spend_id": row.get("spend_ledger_id"),
        }
    return active_jobs


def test_script_restored_from_queue_state():
    """script_b64 and script_name from queue_state survive restart."""
    qs = {
        "script_b64": "aW1wb3J0IHRvcmNo",  # base64 of "import torch"
        "script_name": "train.py",
        "environment": {"LR": "0.001"},
        "failover": True,
    }
    row = _make_row("job-script", "inst-001", queue_state=qs)
    active = _recover([row])
    assert active["job-script"]["script_b64"] == "aW1wb3J0IHRvcmNo"
    assert active["job-script"]["script_name"] == "train.py"
    assert active["job-script"]["environment"] == {"LR": "0.001"}


def test_failover_false_preserved():
    """failover=False from original submission must NOT become True after recovery."""
    qs = {"failover": False, "script_b64": "abc", "script_name": "train.py"}
    row = _make_row("job-nofail", "inst-002", queue_state=qs)
    active = _recover([row])
    assert active["job-nofail"]["failover"] is False, \
        "failover=False must survive recovery — must not auto-restart job user opted out"


def test_failover_true_preserved():
    """failover=True from original submission is preserved."""
    qs = {"failover": True, "script_b64": "abc", "script_name": "train.py"}
    row = _make_row("job-fail", "inst-003", queue_state=qs)
    active = _recover([row])
    assert active["job-fail"]["failover"] is True


def test_legacy_row_no_queue_state_failover_defaults_true():
    """Legacy rows (no queue_state) default to protected recovery."""
    row = _make_row("job-legacy", "inst-004", queue_state={})
    active = _recover([row])
    assert active["job-legacy"]["failover"] is True, \
        "Legacy row without queue_state must default failover=True"
    assert active["job-legacy"]["script_b64"] == ""
    assert active["job-legacy"]["environment"] == {}


def test_provider_constraints_restored():
    """Original provider/region constraints survive restart for correct failover routing."""
    qs = {
        "failover": True,
        "preferred_providers": ["lambda_labs"],
        "excluded_providers": ["aws"],
        "regions": ["us-east-1"],
        "excluded_regions": ["eu-west-1"],
        "min_vram_gb": 40.0,
        "gpu_auto_selected": True,
    }
    row = _make_row("job-constraints", "inst-005", queue_state=qs)
    active = _recover([row])
    j = active["job-constraints"]
    assert j["preferred_providers"] == ["lambda_labs"]
    assert j["excluded_providers"] == ["aws"]
    assert j["regions"] == ["us-east-1"]
    assert j["excluded_regions"] == ["eu-west-1"]
    assert j["min_vram_gb"] == 40.0
    assert j["gpu_auto_selected"] is True


def test_dataset_fields_restored():
    """Dataset id and r2_prefix survive restart for correct warmup on failover."""
    qs = {
        "failover": True,
        "dataset_id": "ds-abc123",
        "dataset_r2_prefix": "datasets/ds-abc123/",
    }
    row = _make_row("job-dataset", "inst-006", queue_state=qs)
    active = _recover([row])
    assert active["job-dataset"]["dataset_id"] == "ds-abc123"
    assert active["job-dataset"]["dataset_r2_prefix"] == "datasets/ds-abc123/"


def test_docker_image_from_queue_state_preferred():
    """docker_image from queue_state takes priority over the direct DB column."""
    qs = {"docker_image": "ghcr.io/hector25/vl-training-base:1.0", "failover": False}
    row = _make_row("job-docker", "inst-007", queue_state=qs, docker_image="old-image:latest")
    active = _recover([row])
    assert active["job-docker"]["docker_image"] == "ghcr.io/hector25/vl-training-base:1.0"


def test_resume_from_job_id_restored():
    """resume_from_job_id is restored so failover chains correctly."""
    qs = {"failover": True, "resume_from_job_id": "job-prev-123"}
    row = _make_row("job-resume", "inst-008", queue_state=qs)
    active = _recover([row])
    assert active["job-resume"]["resume_from_job_id"] == "job-prev-123"


def test_old_running_job_recovered_without_stale_cutoff():
    """Running recovery should preserve timestamps without failing old jobs."""
    old_ts = time.time() - (5 * 3600)
    row = _make_row("job-old-running", "inst-old", queue_state={"failover": True})
    row["provisioned_at"] = datetime.fromtimestamp(old_ts, tz=timezone.utc).isoformat()

    active = _recover([row])

    assert "job-old-running" in active
    assert active["job-old-running"]["started_at"] == pytest.approx(old_ts, abs=1)
