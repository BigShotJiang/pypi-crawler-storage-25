"""Integration-style tests for the provider+region constraint-satisfaction feature.

Complements test_constraint_satisfaction.py (which is unit-level — pure model,
helper, and single-route assertions). The tests here exercise composed flows
using mocks at module boundaries:

  - CLI consent prompt (`_handle_expand_consent`): drives select.select +
    sys.stdin + httpx.post to verify the menu choices, timeout, and
    Ctrl-C/Cancel paths translate to the right HTTP calls.
  - Cancel endpoint email integration: verifies that POST /cancel?reason=
    actually invokes shared.email.send_cancel_email for the two reasons
    that should trigger an email (consent_timeout, resume_no_capacity).
  - Worker resume-exhaustion branch (`_handle_provision_result`): exercises
    the post-provision-result helper directly under all four outcomes
    (running / cancelled_resume / failed / requeue).

These tests are mock-heavy on purpose — full E2E (real DB, real provider
APIs) belongs in PROD_USER_TEST_PLAN, not pytest.
"""
from __future__ import annotations

import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ── Shared isolation fixture (mirrors test_constraint_satisfaction.py) ───────

@pytest.fixture(autouse=True)
def _isolate_env(monkeypatch):
    monkeypatch.setenv("VL_TESTING_MODE", "1")
    monkeypatch.setenv("SUPABASE_URL", os.environ.get("SUPABASE_URL", "https://fake.supabase.co"))
    monkeypatch.setenv("SUPABASE_KEY", os.environ.get("SUPABASE_KEY", "fake-key"))
    import api.flags
    monkeypatch.setattr(api.flags, "TESTING_MODE", True)
    yield
    import api.job_worker as jw
    jw._broker_instance = None
    jw._active_jobs.clear()
    jw._job_queue.clear()
    jw._worker_debug.update({"started": False, "last_error": None,
                             "broker_ok": False, "cycle_count": 0,
                             "last_provision_attempts": []})
    try:
        from api.db import get_db
        get_db.cache_clear()
    except Exception:
        pass


@pytest.fixture
def client():
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from api.job_routes import jobs_router
    from api.auth import require_auth

    async def _fake_auth():
        return {"user_id": "test-user", "email": "test@test.com"}

    app = FastAPI()
    app.dependency_overrides[require_auth] = _fake_auth
    app.include_router(jobs_router)
    return TestClient(app)


# ===========================================================================
# 1. CLI consent prompt — _handle_expand_consent
# ===========================================================================
#
# `_handle_expand_consent(api, headers, data, job)` is the gnarliest piece of
# new CLI code: it blocks on select.select(stdin, 900), parses user input,
# decides between expand-consent / cancel / re-poll, and recurses on still-202
# responses. We mock at module boundaries: select, sys.stdin, httpx.

class _FakeStdin:
    """Stand-in for sys.stdin whose readline() returns a queued value."""
    def __init__(self, line: str):
        self._line = line
    def readline(self) -> str:
        return self._line


def _suggestions_payload() -> dict:
    return {
        "job_id": "job-abc",
        "status": "awaiting_expand_consent",
        "suggestions": {
            "add_regions": {
                "nearby": ["us-east-2", "us-west-2"],
                "all":    ["us-east-2", "us-west-2", "eu-west-1"],
            },
            "add_providers": {"add": ["Lambda Labs"]},
        },
    }


class TestCliConsentPrompt:
    @pytest.mark.asyncio
    async def test_user_picks_first_region_calls_expand_consent(self):
        """Numeric '1' → POST /expand-consent with the first nearby region.
        Successful 200 → enter the post-expand poll loop (which we short-circuit
        by returning a completed status)."""
        from cli import _remote
        import sys as _sys
        post_calls: list[tuple] = []
        def _fake_post(url, **kw):
            post_calls.append((url, kw.get("json"), kw.get("params")))
            return MagicMock(status_code=200, json=lambda: {"status": "queued"})
        def _fake_get(url, **kw):
            return MagicMock(status_code=200, json=lambda: {"status": "completed"})
        with patch("select.select", return_value=([_sys.stdin], [], [])), \
             patch("sys.stdin", _FakeStdin("1\n")), \
             patch("httpx.post", side_effect=_fake_post), \
             patch("httpx.get", side_effect=_fake_get):
            rc = await _remote._handle_expand_consent(
                api="https://api.test", headers={"X": "1"},
                data=_suggestions_payload(), job=MagicMock(),
            )
        assert rc == 0  # eventually completed
        assert post_calls[0][0].endswith("/api/v1/jobs/job-abc/expand-consent")
        assert post_calls[0][1] == {"add_regions": ["us-east-2"]}

    @pytest.mark.asyncio
    async def test_user_types_c_calls_cancel_with_user_declined(self):
        from cli import _remote
        import sys as _sys
        post_calls: list[tuple] = []
        def _fake_post(url, **kw):
            post_calls.append((url, kw.get("params")))
            return MagicMock(status_code=200, json=lambda: {})
        with patch("select.select", return_value=([_sys.stdin], [], [])), \
             patch("sys.stdin", _FakeStdin("c\n")), \
             patch("httpx.post", side_effect=_fake_post):
            rc = await _remote._handle_expand_consent(
                api="https://api.test", headers={}, data=_suggestions_payload(), job=MagicMock(),
            )
        assert rc == 1
        assert len(post_calls) == 1
        assert post_calls[0][0].endswith("/cancel")
        assert post_calls[0][1] == {"reason": "user_declined"}

    @pytest.mark.asyncio
    async def test_timeout_calls_cancel_with_consent_timeout(self):
        """select returning ([], [], []) means the 900s window elapsed.
        CLI must fire /cancel with reason=consent_timeout."""
        from cli import _remote
        post_calls: list[tuple] = []
        def _fake_post(url, **kw):
            post_calls.append((url, kw.get("params")))
            return MagicMock(status_code=200, json=lambda: {})
        with patch("select.select", return_value=([], [], [])), \
             patch("sys.stdin", _FakeStdin("")), \
             patch("httpx.post", side_effect=_fake_post):
            rc = await _remote._handle_expand_consent(
                api="https://api.test", headers={}, data=_suggestions_payload(), job=MagicMock(),
            )
        assert rc == 1
        assert post_calls[0][1] == {"reason": "consent_timeout"}

    @pytest.mark.asyncio
    async def test_out_of_range_choice_treated_as_cancel(self):
        from cli import _remote
        import sys as _sys
        post_calls: list[tuple] = []
        def _fake_post(url, **kw):
            post_calls.append((url, kw.get("params")))
            return MagicMock(status_code=200, json=lambda: {})
        with patch("select.select", return_value=([_sys.stdin], [], [])), \
             patch("sys.stdin", _FakeStdin("99\n")), \
             patch("httpx.post", side_effect=_fake_post):
            rc = await _remote._handle_expand_consent(
                api="https://api.test", headers={}, data=_suggestions_payload(), job=MagicMock(),
            )
        assert rc == 1
        assert post_calls[0][1] == {"reason": "user_declined"}

    @pytest.mark.asyncio
    async def test_pick_provider_after_all_regions(self):
        """Menu order: regions first, then 'add ALL', then providers. With
        nearby=[us-east-2, us-west-2] and providers=[Lambda Labs], picking
        [4] = add provider Lambda Labs."""
        from cli import _remote
        import sys as _sys
        post_calls: list[tuple] = []
        def _fake_post(url, **kw):
            post_calls.append((url, kw.get("json"), kw.get("params")))
            return MagicMock(status_code=200, json=lambda: {"status": "queued"})
        def _fake_get(url, **kw):
            return MagicMock(status_code=200, json=lambda: {"status": "completed"})
        with patch("select.select", return_value=([_sys.stdin], [], [])), \
             patch("sys.stdin", _FakeStdin("4\n")), \
             patch("httpx.post", side_effect=_fake_post), \
             patch("httpx.get",  side_effect=_fake_get):
            rc = await _remote._handle_expand_consent(
                api="https://api.test", headers={}, data=_suggestions_payload(), job=MagicMock(),
            )
        assert rc == 0
        assert post_calls[0][0].endswith("/expand-consent")
        assert post_calls[0][1] == {"add_providers": ["Lambda Labs"]}

    @pytest.mark.asyncio
    async def test_still_infeasible_after_widen_recurses_with_new_suggestions(self):
        """If expand-consent returns 202 (still infeasible), CLI re-prompts.
        We drive '1' first, then 'c' so recursion terminates in cancel."""
        from cli import _remote
        import sys as _sys
        inputs = iter(["1\n", "c\n"])
        class _ChainedStdin:
            def readline(self):
                return next(inputs)
        post_calls: list[tuple] = []
        def _fake_post(url, **kw):
            post_calls.append((url, kw.get("json"), kw.get("params")))
            if url.endswith("/expand-consent"):
                return MagicMock(status_code=202, json=lambda: _suggestions_payload())
            return MagicMock(status_code=200, json=lambda: {})
        with patch("select.select", return_value=([_sys.stdin], [], [])), \
             patch("sys.stdin", _ChainedStdin()), \
             patch("httpx.post", side_effect=_fake_post):
            rc = await _remote._handle_expand_consent(
                api="https://api.test", headers={}, data=_suggestions_payload(), job=MagicMock(),
            )
        assert rc == 1
        kinds = [(c[0].split("/")[-1], c[2]) for c in post_calls]
        assert kinds[0][0] == "expand-consent"
        assert kinds[1] == ("cancel", {"reason": "user_declined"})


# ===========================================================================
# 2. Cancel endpoint email integration
# ===========================================================================

class TestCancelEmailIntegration:
    def _submit(self, client) -> str:
        """Submit a feasible job and return its job_id. Uses a production-
        included provider (RunPod) so the three-state allowlist doesn't
        reject the request — we're testing the cancel-email flow, not
        the provider-state gate."""
        with patch("api.job_routes._has_dispatchable_candidate", return_value=True):
            r = client.post("/api/v1/jobs/run", json={
                "gpu_type": "H100",
                "preferred_providers": ["RunPod"],
                "regions":             ["us-east-1"],
            }, headers={"Authorization": "Bearer vl_test_xxx"})
        return r.json()["job_id"]

    def test_cancel_consent_timeout_invokes_send_cancel_email(self, client):
        job_id = self._submit(client)
        with patch("shared.email.send_cancel_email") as mock_send:
            r = client.post(
                f"/api/v1/jobs/{job_id}/cancel?reason=consent_timeout",
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert r.status_code == 200
        assert mock_send.called
        kwargs = mock_send.call_args.kwargs
        assert kwargs["job_id"] == job_id
        assert kwargs["reason"] == "consent_timeout"
        assert kwargs["preferred_providers"] == ["RunPod"]
        assert kwargs["regions"] == ["us-east-1"]
        assert kwargs["user_email"] == "test@test.com"

    def test_cancel_resume_no_capacity_invokes_send_cancel_email(self, client):
        job_id = self._submit(client)
        with patch("shared.email.send_cancel_email") as mock_send:
            r = client.post(
                f"/api/v1/jobs/{job_id}/cancel?reason=resume_no_capacity",
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert r.status_code == 200
        assert mock_send.called
        assert mock_send.call_args.kwargs["reason"] == "resume_no_capacity"

    def test_cancel_user_request_does_not_email(self, client):
        """user_request and user_declined are CLI-driven cancels — no email
        needed (the user already knows they cancelled)."""
        job_id = self._submit(client)
        with patch("shared.email.send_cancel_email") as mock_send:
            r = client.post(
                f"/api/v1/jobs/{job_id}/cancel?reason=user_request",
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert r.status_code == 200
        assert not mock_send.called

    def test_cancel_user_declined_does_not_email(self, client):
        job_id = self._submit(client)
        with patch("shared.email.send_cancel_email") as mock_send:
            r = client.post(
                f"/api/v1/jobs/{job_id}/cancel?reason=user_declined",
                headers={"Authorization": "Bearer vl_test_xxx"},
            )
        assert r.status_code == 200
        assert not mock_send.called


# ===========================================================================
# 3. Worker resume-exhaustion branch — _handle_provision_result
# ===========================================================================

class TestHandleProvisionResult:
    def _make_job(self, **overrides) -> dict:
        base = {
            "job_id": "wj-001",
            "user_id": "u-1",
            "gpu_type": "H100",
            "environment": {},
            "docker_image": "",
            "preferred_providers": [],
            "excluded_providers": [],
            "regions": [],
            "excluded_regions": [],
            "_provision_attempts": [],
        }
        base.update(overrides)
        return base

    def test_running_outcome_sets_status_and_clears_resume_markers(self):
        from api.job_worker import _handle_provision_result
        job = self._make_job(_is_resume_leg=True, _resume_prefer_provider="runpod")
        with patch("api.job_worker._record_provision_to_db"):
            outcome = _handle_provision_result(
                job=job, job_id="wj-001", instance_id="inst-rp", pref_label="auto",
            )
        assert outcome == "running"
        assert job["status"] == "running"
        assert job["instance_id"] == "inst-rp"
        # Resume markers cleared so a future death doesn't loop the resume path
        assert "_is_resume_leg" not in job
        assert "_resume_prefer_provider" not in job

    def test_resume_leg_exhaustion_cancels_and_emails(self):
        """The marquee test: resume leg + no instance → status=cancelled,
        failure_reason=resume_no_capacity, send_cancel_email called once."""
        from api.job_worker import _handle_provision_result
        job = self._make_job(
            _is_resume_leg=True,
            preferred_providers=["RunPod"],
            regions=["us-east-1"],
            _run_id="run-99",
            user_email="alice@example.com",
        )
        with patch("api.job_worker._sync_job_status") as mock_sync, \
             patch("shared.email.send_cancel_email") as mock_email:
            outcome = _handle_provision_result(
                job=job, job_id="wj-001", instance_id=None, pref_label="RunPod",
            )
        assert outcome == "cancelled_resume"
        assert job["status"] == "cancelled"
        assert job["cancel_reason"] == "resume_no_capacity"
        # job_runs row updated to mirror the in-memory cancel
        mock_sync.assert_called_once_with(
            "run-99", "cancelled", failure_reason="resume_no_capacity",
        )
        # Email fired with the right context
        assert mock_email.called
        kw = mock_email.call_args.kwargs
        assert kw["reason"] == "resume_no_capacity"
        assert kw["preferred_providers"] == ["RunPod"]
        assert kw["regions"] == ["us-east-1"]
        assert kw["user_email"] == "alice@example.com"
        assert kw["run_id"] == "run-99"

    def test_initial_submit_failure_with_preferred_requeues_with_backoff(self):
        """Non-resume leg + preferred_providers + retryable failure → requeue
        with backoff (was: fail immediately). The old 'one-strike' behavior
        killed every user job during any transient capacity drought (e.g.
        the AWS V100 spot-pool shortage on 2026-04-22). Email is still
        resume-only — this path must NOT send email on any outcome."""
        from api.job_worker import _handle_provision_result
        job = self._make_job(
            preferred_providers=["RunPod"],
            _provision_attempts=[{"provider": "RunPod", "error": "no capacity"}],
        )
        with patch("api.job_worker._sync_job_status") as mock_sync, \
             patch("shared.email.send_cancel_email") as mock_email:
            outcome = _handle_provision_result(
                job=job, job_id="wj-001", instance_id=None, pref_label="RunPod",
            )
        assert outcome == "requeue"
        assert job["status"] == "queued"
        assert job["_provision_retry_count"] == 1
        assert job["_next_retry_at"] is not None
        # Error surfaces so the UI can show WHY it's waiting.
        assert "RunPod" in job["error"] and "no capacity" in job["error"]
        # No DB status sync on requeue (we only hit _sync for terminal states).
        assert not mock_sync.called
        assert not mock_email.called

    def test_unconstrained_failure_requeues_for_next_cycle(self):
        """No preferred filter and no resume marker → just re-queue (status=queued)
        so the worker tries again next tick. This is the long-standing fallback
        for jobs with no user-provided constraint."""
        from api.job_worker import _handle_provision_result
        job = self._make_job()
        outcome = _handle_provision_result(
            job=job, job_id="wj-001", instance_id=None, pref_label="auto",
        )
        assert outcome == "requeue"
        assert job["status"] == "queued"

    def test_resume_email_failure_does_not_break_cancel(self):
        """If send_cancel_email blows up (e.g. DB outage), the worker must
        still mark the job cancelled — the email is best-effort."""
        from api.job_worker import _handle_provision_result
        job = self._make_job(_is_resume_leg=True, _run_id="run-99")
        with patch("api.job_worker._sync_job_status"), \
             patch("shared.email.send_cancel_email", side_effect=RuntimeError("smtp down")):
            outcome = _handle_provision_result(
                job=job, job_id="wj-001", instance_id=None, pref_label="auto",
            )
        assert outcome == "cancelled_resume"
        assert job["status"] == "cancelled"


# ===========================================================================
# 4. CLI POST body shape — verify the 4 new arrays reach /jobs/run
# ===========================================================================

class TestCliSubmitBody:
    @pytest.mark.asyncio
    async def test_run_remote_posts_constraint_arrays(self, tmp_path):
        """run_remote should serialize all 4 constraint arrays from the Job
        model into the /jobs/run body. Catches drift between model and wire."""
        from cli import _remote
        from shared.models import GPUType

        job = MagicMock()
        job.gpu_type = GPUType.H100_80GB_SXM
        job.environment = {}
        job.docker_image = ""
        job.failover_enabled = False
        job.preferred_providers = ["RunPod", "Lambda Labs"]
        job.excluded_providers  = ["RunPod"]
        job.regions             = ["us-east-1"]
        job.excluded_regions    = ["cn-north-1"]
        train = tmp_path / "train.py"
        train.write_text("print('ok')\n")
        run_cmd = MagicMock()
        run_cmd.command = ["python", str(train)]

        captured: list[dict] = []
        def _fake_post(url, **kw):
            captured.append({"url": url, "json": kw.get("json")})
            return MagicMock(status_code=200, json=lambda: {"job_id": "j-1", "status": "completed"})
        def _fake_get(url, **kw):
            return MagicMock(status_code=200, json=lambda: {
                "status": "completed", "duration": 1.0, "price_per_hr": 0.0,
                "log_line_count": 0,
            })
        with patch("shared.api_utils.get_api_url", return_value="https://api.test"), \
             patch("shared.api_utils.get_token",   return_value="tk"), \
             patch("httpx.post", side_effect=_fake_post), \
             patch("httpx.get",  side_effect=_fake_get):
            await _remote.run_remote(run_cmd, job, broker=MagicMock(), queue=MagicMock())
        submit = next(c for c in captured if c["url"].endswith("/api/v1/jobs/run"))
        assert submit["json"]["preferred_providers"] == ["RunPod", "Lambda Labs"]
        assert submit["json"]["excluded_providers"]  == ["RunPod"]
        assert submit["json"]["regions"]             == ["us-east-1"]
        assert submit["json"]["excluded_regions"]    == ["cn-north-1"]
