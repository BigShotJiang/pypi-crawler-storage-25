"""Regression tests for shared GPU sizing policy."""
from __future__ import annotations

import pytest


def test_32b_qlora_requires_40gb_floor():
    from shared.gpu_sizing import min_vram_for_model

    assert min_vram_for_model(32.0, "qlora") == pytest.approx(40.0)


def test_72b_qlora_requires_96gb_floor():
    from shared.gpu_sizing import min_vram_for_model

    assert min_vram_for_model(72.0, "qlora") == pytest.approx(96.0)


def test_72b_qlora_requires_large_disk_for_full_shard_download():
    from shared.gpu_sizing import disk_gb_for_model

    assert disk_gb_for_model(72.0, "qlora") == 300


def test_small_qlora_keeps_legacy_100gb_disk():
    from shared.gpu_sizing import disk_gb_for_model

    assert disk_gb_for_model(7.0, "qlora") == 100


def test_32b_qlora_uses_200gb_disk():
    from shared.gpu_sizing import disk_gb_for_model

    assert disk_gb_for_model(32.0, "qlora") == 200


def test_h100_is_not_valid_for_72b_qlora():
    from shared.gpu_sizing import gpu_meets_vram, min_vram_for_model

    assert not gpu_meets_vram("H100", min_vram_for_model(72.0, "qlora"))


def test_rtx5090_is_not_valid_for_32b_qlora():
    from shared.gpu_sizing import gpu_meets_vram, min_vram_for_model

    assert not gpu_meets_vram("RTX5090", min_vram_for_model(32.0, "qlora"))


def test_infers_largest_model_id_from_command():
    from shared.gpu_sizing import infer_model_params_billion

    assert infer_model_params_billion(
        "env MODEL_ID=Qwen/Qwen2.5-32B-Instruct python train_llama3_2_3b_qlora.py"
    ) == pytest.approx(32.0)


def test_fallback_skips_under_vram_consumer_gpus():
    from shared.gpu_sizing import bfs_gpu_fallback

    assert bfs_gpu_fallback(
        "RTX3090",
        40.0,
        check_candidate=lambda gpu: gpu in {"RTX4090", "RTX5090", "A40"},
    ) == "A40"


def test_h100_fallback_reaches_gh200_for_72b_qlora():
    from shared.gpu_sizing import bfs_gpu_fallback, min_vram_for_model

    assert bfs_gpu_fallback(
        "H100",
        min_vram_for_model(72.0, "qlora"),
        check_candidate=lambda gpu: gpu in {"GH200", "H200", "B200"},
    ) == "GH200"
