"""Tests for issue #132: Nebius managed credential field mapping.

The old code mapped service_account_key → api_key, but _get_iam_token()
reads service_account_key. This caused every managed Nebius provision to
fail with 'could not obtain IAM token'. The fence path also silently skipped
termination when BYOC config was absent.
"""
from __future__ import annotations

import os
import sys
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def _make_broker(managed_creds: dict | None = None, byoc_cfg=None):
    broker = MagicMock()
    broker._get_provider_config.return_value = byoc_cfg
    broker._nebius_token_cache = None
    if managed_creds is not None:
        broker._get_managed_credentials = AsyncMock(return_value=managed_creds)
    else:
        broker._get_managed_credentials = AsyncMock(return_value=None)
    return broker


def _make_job(job_id: str = "job-neb-1"):
    job = MagicMock()
    job.job_id = job_id
    job.last_provision_error = None
    job.failure_code = None
    job._provision_attempts = []
    return job


class _FakeNebiusSDK:
    def __init__(self, *args, **kwargs):
        self.kwargs = kwargs

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        return False


class _FakeDeleteOp:
    async def wait(self):
        return None


class _FakeInstanceServiceClient:
    delete_calls = []

    def __init__(self, sdk):
        self.sdk = sdk

    async def delete(self, req):
        self.__class__.delete_calls.append(req)
        return _FakeDeleteOp()


@pytest.mark.asyncio
async def test_resolve_nebius_host_uses_managed_creds_and_public_ip():
    """Nebius host resolution must query the SDK and return the assigned public IP."""
    from agents.broker import ssh as ssh_mod
    from agents.broker.providers import nebius as neb

    managed_creds = {
        "service_account_key": "-----BEGIN RSA PRIVATE KEY-----\nFAKE\n-----END RSA PRIVATE KEY-----",
        "key_id": "key-001",
        "service_account_id": "sa-001",
        "region": "eu",
        "folder_id": "folder-001",
        "subnet_id": "subnet-001",
    }
    broker = _make_broker(managed_creds=managed_creds)
    captured = {}

    class _FakeResolveSDK:
        def __init__(self, *args, **kwargs):
            captured["sdk_credentials"] = kwargs.get("credentials")

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return False

    class _FakeResolveInstanceServiceClient:
        def __init__(self, sdk):
            captured["sdk"] = sdk

        async def get(self, req):
            captured["get_id"] = req.id
            return SimpleNamespace(
                status=SimpleNamespace(
                    network_interfaces=[
                        SimpleNamespace(
                            public_ip_address=SimpleNamespace(address="203.0.113.42")
                        )
                    ]
                )
            )

    async def _fake_iam_token(b, cfg):
        captured["service_account_key"] = getattr(cfg, "service_account_key", None)
        captured["subnet_id"] = getattr(cfg, "subnet_id", None)
        return "fake-token"

    import types

    _fake_nebius_sdk_mod = types.ModuleType("nebius.sdk")
    _fake_nebius_sdk_mod.SDK = _FakeResolveSDK
    _fake_nebius_compute_mod = types.ModuleType("nebius.api.nebius.compute.v1")
    _fake_nebius_compute_mod.InstanceServiceClient = _FakeResolveInstanceServiceClient
    _fake_nebius_compute_mod.GetInstanceRequest = MagicMock(
        side_effect=lambda **kw: SimpleNamespace(**kw)
    )

    with patch.object(neb, "_get_iam_token", new=_fake_iam_token), \
         patch.dict(sys.modules, {
             "nebius": types.ModuleType("nebius"),
             "nebius.sdk": _fake_nebius_sdk_mod,
             "nebius.api": types.ModuleType("nebius.api"),
             "nebius.api.nebius": types.ModuleType("nebius.api.nebius"),
             "nebius.api.nebius.compute": types.ModuleType("nebius.api.nebius.compute"),
             "nebius.api.nebius.compute.v1": _fake_nebius_compute_mod,
         }):
        host = await ssh_mod._resolve_nebius_host(broker, "inst-neb-123")

    assert host == "203.0.113.42"
    assert captured["get_id"] == "inst-neb-123"
    assert captured["sdk_credentials"] == "fake-token"
    assert captured["service_account_key"] == managed_creds["service_account_key"]
    assert captured["subnet_id"] == "subnet-001"
    broker._get_managed_credentials.assert_awaited_once_with("nebius", "inst-neb-123")


# ── provision: managed credentials map onto correct _get_iam_token fields ────

@pytest.mark.asyncio
async def test_managed_provision_maps_service_account_key():
    """Managed credentials must set service_account_key (not api_key) on cfg."""
    from agents.broker.providers import nebius as neb

    managed_creds = {
        "service_account_key": "-----BEGIN RSA PRIVATE KEY-----\nFAKE\n-----END RSA PRIVATE KEY-----",
        "key_id": "key-001",
        "service_account_id": "sa-001",
        "region": "eu",
        "folder_id": "folder-001",
        "subnet_id": "subnet-001",
    }
    broker = _make_broker(managed_creds=managed_creds)
    job = _make_job()

    captured_cfg = {}

    async def _fake_iam_token(b, cfg):
        captured_cfg["service_account_key"] = getattr(cfg, "service_account_key", None)
        captured_cfg["key_id"] = getattr(cfg, "key_id", None)
        captured_cfg["service_account_id"] = getattr(cfg, "service_account_id", None)
        captured_cfg["region"] = getattr(cfg, "region", None)
        # Return None to abort provision early — we only test cfg mapping
        return None

    with patch.object(neb, "_get_iam_token", new=_fake_iam_token):
        result = await neb.provision(broker, SimpleNamespace(value="H100"), job)

    assert result is None  # aborted because token is None
    assert job.last_provision_error == "Nebius: could not obtain IAM token"
    assert captured_cfg["service_account_key"] == managed_creds["service_account_key"], \
        "service_account_key must be mapped from managed credentials"
    assert captured_cfg["key_id"] == "key-001"
    assert captured_cfg["service_account_id"] == "sa-001"
    assert captured_cfg["region"] == "eu"


@pytest.mark.asyncio
async def test_managed_provision_missing_service_account_key_is_auth_error():
    """Empty service_account_key from managed creds must produce a non-retryable
    PROV_AUTH_BAD failure, not a generic provision error."""
    from agents.broker.providers import nebius as neb
    from shared.failure_codes import JobFailureCode

    managed_creds = {
        "service_account_key": "",  # missing
        "key_id": "key-001",
        "service_account_id": "sa-001",
        "folder_id": "folder-001",
    }
    broker = _make_broker(managed_creds=managed_creds)
    job = _make_job()

    result = await neb.provision(broker, SimpleNamespace(value="H100"), job)

    assert result is None
    assert "missing service_account_key" in (job.last_provision_error or "")
    assert job.failure_code == JobFailureCode.PROV_AUTH_BAD.value, \
        "Missing service_account_key must produce PROV_AUTH_BAD (non-retryable)"


@pytest.mark.asyncio
async def test_managed_provision_no_credentials_returns_none():
    """No managed credentials → clear error, no exception."""
    from agents.broker.providers import nebius as neb

    broker = _make_broker(managed_creds=None)
    job = _make_job()

    result = await neb.provision(broker, SimpleNamespace(value="H100"), job)

    assert result is None
    assert "no credentials" in (job.last_provision_error or "")


# ── hard_fence: managed credentials used when BYOC config absent ──────────────

@pytest.mark.asyncio
async def test_broker_nebius_fence_wrapper_forwards_job_context():
    """Broker wrapper must pass job context so managed creds can be loaded."""
    from agents.broker.agent import BrokerAgent
    from agents.broker.providers import nebius as neb

    broker = BrokerAgent(
        config=SimpleNamespace(cloudflare=None, sts=None, aws=None, nebius=None),
        queue=MagicMock(),
    )
    job = _make_job()
    captured = {}

    async def _fake_hard_fence(b, instance_id, forwarded_job=None):
        captured["broker"] = b
        captured["instance_id"] = instance_id
        captured["job"] = forwarded_job

    with patch.object(neb, "hard_fence", new=_fake_hard_fence):
        await broker._hard_fence_nebius("inst-123", job=job)

    assert captured["broker"] is broker
    assert captured["instance_id"] == "inst-123"
    assert captured["job"] is job


@pytest.mark.asyncio
async def test_broker_hard_fence_and_confirm_forwards_job_to_nebius():
    """STONITH dispatch must preserve job context for managed Nebius cleanup."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider

    broker = BrokerAgent(
        config=SimpleNamespace(cloudflare=None, sts=None, aws=None, nebius=None),
        queue=MagicMock(),
    )
    job = SimpleNamespace(
        job_id="job-neb-1",
        instance_id="inst-123",
        provider=Provider.NEBIUS,
        ssh_host="",
    )
    captured = {}

    async def _fake_nebius_fence(instance_id, forwarded_job=None):
        captured["instance_id"] = instance_id
        captured["job"] = forwarded_job

    broker._hard_fence_nebius = _fake_nebius_fence

    await broker._hard_fence_and_confirm(job)

    assert captured["instance_id"] == "inst-123"
    assert captured["job"] is job


@pytest.mark.asyncio
async def test_fence_uses_managed_credentials_when_no_byoc():
    """hard_fence() must attempt managed creds when BYOC config is absent,
    so VL-managed Nebius instances can be terminated without BYOC setup."""
    from agents.broker.providers import nebius as neb

    managed_creds = {
        "service_account_key": "-----BEGIN RSA PRIVATE KEY-----\nFAKE\n-----END RSA PRIVATE KEY-----",
        "key_id": "key-001",
        "service_account_id": "sa-001",
        "region": "eu",
    }
    broker = _make_broker(managed_creds=managed_creds)
    job = _make_job()

    captured_cfg = {}

    async def _fake_iam_token(b, cfg):
        captured_cfg["service_account_key"] = getattr(cfg, "service_account_key", None)
        return "fake-token"

    _FakeInstanceServiceClient.delete_calls = []

    # Patch at the nebius.py import site (lazy imports inside try block),
    # using sys.modules so the 'from nebius.sdk import SDK' succeeds without
    # the nebius package being installed in the test environment.
    import sys
    import types
    _fake_nebius_sdk_mod = types.ModuleType("nebius.sdk")
    _fake_nebius_sdk_mod.SDK = _FakeNebiusSDK
    _fake_nebius_compute_mod = types.ModuleType("nebius.api.nebius.compute.v1")
    _fake_nebius_compute_mod.InstanceServiceClient = _FakeInstanceServiceClient
    _fake_nebius_compute_mod.DeleteInstanceRequest = MagicMock(side_effect=lambda **kw: SimpleNamespace(**kw))

    with patch.object(neb, "_get_iam_token", new=_fake_iam_token), \
         patch.dict(sys.modules, {
             "nebius": types.ModuleType("nebius"),
             "nebius.sdk": _fake_nebius_sdk_mod,
             "nebius.api": types.ModuleType("nebius.api"),
             "nebius.api.nebius": types.ModuleType("nebius.api.nebius"),
             "nebius.api.nebius.compute": types.ModuleType("nebius.api.nebius.compute"),
             "nebius.api.nebius.compute.v1": _fake_nebius_compute_mod,
             "nebius.api.nebius.common": types.ModuleType("nebius.api.nebius.common"),
             "nebius.api.nebius.common.v1": types.ModuleType("nebius.api.nebius.common.v1"),
         }):
        await neb.hard_fence(broker, "inst-123", job=job)

    assert captured_cfg.get("service_account_key") == managed_creds["service_account_key"], \
        "Fence must use managed service_account_key when BYOC config is absent"
    assert _FakeInstanceServiceClient.delete_calls[0].id == "inst-123"


@pytest.mark.asyncio
async def test_fence_raises_when_no_config_and_no_managed_creds():
    """Missing BYOC and managed credentials must leave deletion unconfirmed."""
    from agents.broker.providers import nebius as neb

    broker = _make_broker(managed_creds=None)
    job = _make_job()

    with pytest.raises(RuntimeError, match="config not found"):
        await neb.hard_fence(broker, "inst-xyz", job=job)


@pytest.mark.asyncio
async def test_fence_raises_when_no_config_and_no_job():
    """Without config or job context, deletion cannot be confirmed."""
    from agents.broker.providers import nebius as neb

    broker = _make_broker(managed_creds=None)

    with pytest.raises(RuntimeError, match="config not found"):
        await neb.hard_fence(broker, "inst-xyz", job=None)
