---
inclusion: auto
---

# omie-sdk — Contexto do Projeto

## O que é
`omie-sdk` é um SDK Python para a API do **Omie**, um ERP brasileiro. A API usa **SOAP 1.1 sobre HTTP POST com body JSON**.
Toda requisição vai para `https://app.omie.com.br/api/v1/{modulo}/{endpoint}/` com payload:
```json
{"app_key": "...", "app_secret": "...", "call": "NomeDaCall", "param": [{ ...campos... }]}
```
Documentação oficial: https://developer.omie.com.br/service-list/

## Comportamento crítico da API
- Status HTTP não-confiável — erros de negócio chegam como `200` ou `500`, sempre com `faultcode`/`faultstring` no body JSON
- Datas sempre no formato `DD/MM/YYYY`
- Rate limit: 240 req/min por IP+AppKey+Método
- Requisições redundantes (mesmo ID em <60s) retornam erro com `"Aguarde N segundos"`
- Após 10 erros consecutivos no mesmo IP+AppKey+Método: bloqueio de 30 min (HTTP 425)

## Arquitetura

### Camadas
- `omie/__init__.py` — classe `Omie` (entrypoint único)
- `omie/base.py` — `_BaseModule` (construtor comum dos módulos)
- `omie/http.py` — `OmieHttp` (transporte HTTP + retry + throttle)
- `omie/retry.py` — `RetryConfig`, `RetryOverride`, `BackoffStrategy`
- `omie/validators.py` — funções de validação compartilhadas (datas, etc.)
- `omie/errors/__init__.py` — exceções tipadas + `parse_omie_response`

### Padrão de módulo
Cada módulo herda `_BaseModule`. Métodos seguem:
```python
def incluir_xyz(self, param: XyzParam, *, retry=None, timeout=None, time_range=None) -> dict:
    return self._http.post("modulo/endpoint", "NomeDaCall", [param.to_omie_dict()],
        retry=retry, timeout=timeout, time_range=time_range)
```

### Padrão de models
Todos herdam `BaseOmieModel`:
```python
class BaseOmieModel(BaseModel):
    model_config = {"frozen": True, "coerce_numbers_to_str": True}
    def to_omie_dict(self) -> dict:
        return self.model_dump(exclude_none=True)
```

### Uso
```python
from omie import Omie
omie = Omie(app_key="...", app_secret="...")
omie.financas.incluir_conta_receber(param)
omie.vendas.incluir_pedido(param)
omie.clientes.incluir_cliente(param)
omie.produtos.incluir_produto(param)
```

## Módulos implementados
- `omie.financas` — contas a receber/pagar (`financas/contareceber`, `financas/contapagar`)
- `omie.vendas` — pedidos de venda (`produtos/pedido`)
- `omie.clientes` — clientes (`geral/clientes`)
- `omie.produtos` — produtos (`produtos/produto`)
- `omie.servicos` — **em desenvolvimento** (models.py já existe)

## Padrão para novo módulo
1. Criar `omie/modules/{nome}/models.py` — Pydantic models herdando `BaseOmieModel`
2. Criar `omie/modules/{nome}/__init__.py` — classe `Omie{Nome}` herdando `_BaseModule`
3. Registrar em `omie/__init__.py` como `self.{nome} = Omie{Nome}(...)`
4. Checar calls e campos na documentação: https://developer.omie.com.br/service-list/
