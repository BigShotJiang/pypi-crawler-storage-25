# Plano de Implementação

- [-] 1. Escrever teste exploratório da condição de bug
  - **Property 1: Bug Condition** — Imports quebrados lançam ModuleNotFoundError
  - **CRITICAL**: Este teste DEVE FALHAR no código não corrigido — a falha confirma que o bug existe
  - **NÃO tente corrigir o teste ou o código quando ele falhar**
  - **NOTE**: Este teste codifica o comportamento esperado — ele validará o fix quando passar após a implementação
  - **GOAL**: Demonstrar contraexemplos que provam a existência do bug
  - **Abordagem PBT com escopo definido**: Testar imports concretos que falham com `ModuleNotFoundError`
  - Tentar `import omie` e verificar que NÃO lança `ModuleNotFoundError` (condição de bug: referências a `omie._core.*`)
  - Tentar `from omie.modules.financas import OmieFinancas` e verificar que NÃO lança erro (condição de bug: `__init__.py` importa de `omie._core`)
  - Tentar `from omie.modules.financas.models import ContaReceberParam` e verificar que NÃO lança erro
  - Tentar `from omie.modules.vendas import OmieVendas` e verificar que NÃO lança erro
  - Tentar `from omie.modules.clientes.models import ClienteParam` e verificar que NÃO lança erro
  - Tentar `from omie.modules.produtos.models import ProdutoParam` e verificar que NÃO lança erro
  - Executar no código NÃO CORRIGIDO — esperar FALHA (confirma que o bug existe)
  - Documentar contraexemplos encontrados (ex: `ModuleNotFoundError: No module named 'omie._core'`)
  - Marcar tarefa como completa quando o teste estiver escrito, executado e a falha documentada
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9_

- [~] 2. Escrever testes de preservação baseados em propriedades (ANTES de implementar o fix)
  - **Property 2: Preservation** — API pública e lógica de negócio inalteradas
  - **IMPORTANTE**: Seguir metodologia observation-first
  - Observar: `omie.errors` resolve corretamente no código não corrigido (módulo `errors` não depende de `_core`)
  - Observar: Os modelos Pydantic dos submódulos expõem as mesmas classes e campos
  - Observar: A API pública do SDK (`__init__.py`) exporta os mesmos símbolos
  - Escrever teste baseado em propriedades: para todos os módulos que NÃO referenciam `omie._core`, os imports continuam funcionando
  - Escrever teste: `from omie.errors import OmieApiError` funciona corretamente
  - Escrever teste: verificar que os símbolos públicos exportados por `omie.errors` não mudaram
  - Verificar que os testes passam no código NÃO CORRIGIDO
  - **RESULTADO ESPERADO**: Testes PASSAM (confirma comportamento baseline a preservar)
  - Marcar tarefa como completa quando os testes estiverem escritos, executados e passando no código não corrigido
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

- [ ] 3. Corrigir imports quebrados em todos os arquivos afetados

  - [~] 3.1 Corrigir imports dos módulos core (`omie/__init__.py`, `omie/base.py`, `omie/http.py`)
    - Em `omie/__init__.py`: substituir `from omie._core.http import ...` por `from omie.http import ...` e `from omie._core.retry import ...` por `from omie.retry import ...`
    - Em `omie/base.py`: substituir `from omie._core.http import ...` por `from omie.http import ...` e `from omie._core.retry import ...` por `from omie.retry import ...`
    - Em `omie/http.py`: substituir `from omie._core.retry import ...` por `from omie.retry import ...`
    - _Bug_Condition: isBugCondition(import) onde import CONTÉM "omie._core."_
    - _Expected_Behavior: imports resolvem para `omie.http`, `omie.retry` sem ModuleNotFoundError_
    - _Preservation: Mesmos símbolos importados, mesma lógica de negócio_
    - _Requirements: 2.1, 2.2, 2.3, 2.5, 2.6_

  - [~] 3.2 Corrigir imports dos módulos de domínio (`financas`, `vendas`, `clientes`, `produtos`)
    - Em `omie/modules/financas/__init__.py`: substituir `omie._core.base` → `omie.base`, `omie._core.http` → `omie.http`, `omie._core.retry` → `omie.retry`, `omie.financas.models` → `omie.modules.financas.models`
    - Em `omie/modules/vendas/__init__.py`: substituir `omie._core.base` → `omie.base`, `omie._core.http` → `omie.http`, `omie._core.retry` → `omie.retry`, `omie.vendas.models` → `omie.modules.vendas.models`
    - Em `omie/modules/clientes/__init__.py`: substituir `omie._core.base` → `omie.base`, `omie._core.http` → `omie.http`, `omie._core.retry` → `omie.retry`, `omie.clientes.models` → `omie.modules.clientes.models`
    - Em `omie/modules/produtos/__init__.py`: substituir `omie._core.base` → `omie.base`, `omie._core.http` → `omie.http`, `omie._core.retry` → `omie.retry`, `omie.produtos.models` → `omie.modules.produtos.models`
    - _Bug_Condition: isBugCondition(import) onde import CONTÉM "omie._core." OU "omie.<modulo>.models" sem "modules"_
    - _Expected_Behavior: imports resolvem para `omie.base`, `omie.http`, `omie.retry`, `omie.modules.<modulo>.models`_
    - _Preservation: Mesmas classes importadas, mesma interface pública dos módulos_
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.7, 2.8, 2.9, 2.10_

  - [~] 3.3 Corrigir imports dos models de domínio (`financas`, `vendas`, `clientes`, `produtos`, `servicos`)
    - Em `omie/modules/financas/models.py`: substituir `omie._core.base` → `omie.base`, `omie._core.validators` → `omie.validators`
    - Em `omie/modules/vendas/models.py`: substituir `omie._core.base` → `omie.base`, `omie._core.validators` → `omie.validators`
    - Em `omie/modules/clientes/models.py`: substituir `omie._core.base` → `omie.base`, `omie._core.validators` → `omie.validators`
    - Em `omie/modules/produtos/models.py`: substituir `omie._core.base` → `omie.base`, `omie._core.validators` → `omie.validators`
    - Em `omie/modules/servicos/models.py`: substituir `omie._core.base` → `omie.base`, `omie._core.validators` → `omie.validators`
    - _Bug_Condition: isBugCondition(import) onde import CONTÉM "omie._core."_
    - _Expected_Behavior: imports resolvem para `omie.base`, `omie.validators` sem ModuleNotFoundError_
    - _Preservation: Mesmos modelos Pydantic com mesmos campos e validações_
    - _Requirements: 2.1, 2.4_

  - [~] 3.4 Corrigir imports dos arquivos de teste
    - Em `tests/test_sdk.py`: substituir `from omie.financas import ...` → `from omie.modules.financas import ...` e `from omie.financas.models import ...` → `from omie.modules.financas.models import ...`
    - Em `tests/test_real_http.py`: substituir `from omie.vendas import ...` → `from omie.modules.vendas import ...` e `from omie.vendas.models import ...` → `from omie.modules.vendas.models import ...`
    - _Bug_Condition: isBugCondition(import) onde import CONTÉM "omie.financas" ou "omie.vendas" sem "modules"_
    - _Expected_Behavior: imports resolvem para `omie.modules.financas` e `omie.modules.vendas`_
    - _Preservation: Mesmos testes executando a mesma lógica_
    - _Requirements: 2.11, 2.12_

  - [~] 3.5 Verificar que o teste exploratório da condição de bug agora passa
    - **Property 1: Expected Behavior** — Imports resolvem para módulos existentes
    - **IMPORTANTE**: Re-executar o MESMO teste da tarefa 1 — NÃO escrever um novo teste
    - O teste da tarefa 1 codifica o comportamento esperado
    - Quando este teste passar, confirma que o comportamento esperado está satisfeito
    - Executar teste exploratório da condição de bug da tarefa 1
    - **RESULTADO ESPERADO**: Teste PASSA (confirma que o bug foi corrigido)
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 2.10, 2.11, 2.12_

  - [~] 3.6 Verificar que os testes de preservação ainda passam
    - **Property 2: Preservation** — API pública e lógica de negócio inalteradas
    - **IMPORTANTE**: Re-executar os MESMOS testes da tarefa 2 — NÃO escrever novos testes
    - Executar testes de preservação baseados em propriedades da tarefa 2
    - **RESULTADO ESPERADO**: Testes PASSAM (confirma que não houve regressão)
    - Confirmar que todos os testes ainda passam após o fix (sem regressões)

- [~] 4. Checkpoint — Garantir que todos os testes passam
  - Executar todos os testes do projeto (`test_sdk.py`, `test_real_http.py`, e os testes de propriedade criados)
  - Garantir que nenhum `ModuleNotFoundError` ocorre ao importar qualquer módulo do SDK
  - Perguntar ao usuário se houver dúvidas
