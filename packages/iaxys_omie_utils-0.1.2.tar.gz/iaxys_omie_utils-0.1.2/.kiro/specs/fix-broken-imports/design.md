# Correção de Imports Quebrados — Design do Bugfix

## Visão Geral

Após a reestruturação do projeto omie-sdk, os caminhos de importação ficaram inconsistentes com a estrutura real de diretórios. O pacote `omie._core` não existe — os módulos `base.py`, `http.py`, `retry.py` e `validators.py` estão diretamente em `omie/`. Além disso, os módulos de domínio (financas, vendas, clientes, produtos) estão em `omie/modules/`, mas vários imports omitem o prefixo `modules/`. O fix consiste em atualizar todos os imports para refletir a estrutura real do projeto.

## Glossário

- **Bug_Condition (C)**: Qualquer instrução `import` ou `from ... import` que referencia um caminho de módulo inexistente (ex: `omie._core.base`, `omie.financas.models`)
- **Property (P)**: Todos os imports devem resolver para módulos existentes na estrutura de diretórios atual, permitindo que o SDK seja importado e executado sem `ModuleNotFoundError`
- **Preservation**: A API pública do SDK (classes, funções, parâmetros) não deve mudar — apenas os caminhos internos de importação são corrigidos
- **`omie._core.*`**: Caminho fantasma que não existe; os arquivos reais estão em `omie/base.py`, `omie/http.py`, `omie/retry.py`, `omie/validators.py`
- **`omie.modules.*`**: Caminho real dos módulos de domínio (financas, vendas, clientes, produtos, servicos)

## Detalhes do Bug

### Condição do Bug

O bug se manifesta quando qualquer código tenta importar o SDK. Todas as instruções `import` que referenciam `omie._core.*` ou `omie.<modulo>` (sem `modules/`) falham com `ModuleNotFoundError` porque esses caminhos não correspondem à estrutura real de diretórios.

**Especificação Formal:**
```
FUNCTION isBugCondition(importStatement)
  INPUT: importStatement do tipo string (instrução de import Python)
  OUTPUT: boolean

  modulePath := extrairCaminhoModulo(importStatement)

  RETURN modulePath CONTÉM "omie._core."
         OR (modulePath CONTÉM "omie.financas" AND NOT modulePath CONTÉM "omie.modules.financas")
         OR (modulePath CONTÉM "omie.vendas" AND NOT modulePath CONTÉM "omie.modules.vendas")
         OR (modulePath CONTÉM "omie.clientes" AND NOT modulePath CONTÉM "omie.modules.clientes")
         OR (modulePath CONTÉM "omie.produtos" AND NOT modulePath CONTÉM "omie.modules.produtos")
         OR (modulePath CONTÉM "omie.servicos" AND NOT modulePath CONTÉM "omie.modules.servicos")
END FUNCTION
```

### Exemplos

- `from omie._core.http import OmieHttp` → `ModuleNotFoundError` — correto: `from omie.http import OmieHttp`
- `from omie._core.base import _BaseContext` → `ModuleNotFoundError` — correto: `from omie.base import _BaseContext`
- `from omie._core.retry import RetryConfig` → `ModuleNotFoundError` — correto: `from omie.retry import RetryConfig`
- `from omie._core.validators import validate_date` → `ModuleNotFoundError` — correto: `from omie.validators import validate_date`
- `from omie.financas.models import ContaReceberParam` → `ModuleNotFoundError` — correto: `from omie.modules.financas.models import ContaReceberParam`
- `from omie.vendas.models import PedidoVendaParam` → `ModuleNotFoundError` — correto: `from omie.modules.vendas.models import PedidoVendaParam`
- `from omie.financas import OmieFinancas` (em testes) → `ModuleNotFoundError` — correto: `from omie.modules.financas import OmieFinancas`
- `from omie.vendas import OmieVendas` (em testes) → `ModuleNotFoundError` — correto: `from omie.modules.vendas import OmieVendas`
- `from omie._core.retry import RetryConfig, RetryOverride` em `omie/http.py` → auto-referência quebrada — correto: `from omie.retry import RetryConfig, RetryOverride`

## Comportamento Esperado

### Requisitos de Preservação

**Comportamentos Inalterados:**
- A API pública do SDK (`Omie`, `OmieFinancas`, `OmieVendas`, `OmieClientes`, `OmieProdutos`) deve continuar expondo os mesmos métodos com as mesmas assinaturas
- Os modelos Pydantic (validações, campos, `to_omie_dict()`) devem funcionar exatamente como antes
- O sistema de erros (`omie.errors`) deve continuar classificando e levantando exceções corretamente
- A lógica de retry, timeout e throttle em `OmieHttp` deve permanecer inalterada
- Os testes existentes devem passar (após correção dos seus próprios imports)

**Escopo:**
Todas as alterações são estritamente em instruções `import`/`from ... import`. Nenhuma lógica de negócio, assinatura de função, ou estrutura de dados é modificada.

## Causa Raiz Hipotética

Com base na análise do código, a causa raiz é clara e singular:

1. **Reestruturação incompleta**: O projeto foi reorganizado movendo arquivos de `omie/_core/` para `omie/` (nível raiz do pacote) e módulos de domínio para `omie/modules/`, mas as instruções de import nos arquivos fonte não foram atualizadas para refletir a nova estrutura.

2. **Imports `omie._core.*` em 10 arquivos**: Os arquivos `omie/base.py`, `omie/http.py`, `omie/__init__.py`, e todos os `__init__.py` e `models.py` dos módulos de domínio referenciam `omie._core.base`, `omie._core.http`, `omie._core.retry` e `omie._core.validators` — caminhos que não existem.

3. **Imports sem prefixo `modules/` em 6 arquivos**: Os `__init__.py` dos módulos de domínio importam models usando `omie.<modulo>.models` ao invés de `omie.modules.<modulo>.models`. Os arquivos de teste importam `omie.financas` e `omie.vendas` ao invés de `omie.modules.financas` e `omie.modules.vendas`.

4. **Auto-referências quebradas**: `omie/base.py` importa de `omie._core.http` e `omie._core.retry` (que são seus vizinhos diretos), e `omie/http.py` importa de `omie._core.retry` — todos caminhos inexistentes.

## Propriedades de Corretude

Property 1: Bug Condition — Imports resolvem para módulos existentes

_Para qualquer_ instrução de import no projeto onde a condição de bug se aplica (isBugCondition retorna true), o import corrigido DEVE resolver para um módulo Python existente na estrutura de diretórios, eliminando todo `ModuleNotFoundError` ao importar o SDK.

**Valida: Requisitos 2.1, 2.2, 2.3, 2.4**

Property 2: Preservation — API pública e lógica de negócio inalteradas

_Para qualquer_ código que NÃO envolva caminhos de import (lógica de negócio, validações, assinaturas de métodos, tratamento de erros), o código corrigido DEVE produzir exatamente o mesmo comportamento que o código original, preservando toda a funcionalidade existente do SDK.

**Valida: Requisitos 3.1, 3.2, 3.3, 3.4, 3.5**

## Implementação do Fix

### Alterações Necessárias

Assumindo que a análise de causa raiz está correta:

**Arquivo**: `omie/__init__.py`

**Alterações**:
1. `from omie._core.http import TimeoutConfig, TimeRangeConfig` → `from omie.http import TimeoutConfig, TimeRangeConfig`
2. `from omie._core.retry import RetryConfig` → `from omie.retry import RetryConfig`

---

**Arquivo**: `omie/base.py`

**Alterações**:
1. `from omie._core.http import OmieHttp, TimeoutConfig, TimeRangeConfig` → `from omie.http import OmieHttp, TimeoutConfig, TimeRangeConfig`
2. `from omie._core.retry import RetryConfig` → `from omie.retry import RetryConfig`

---

**Arquivo**: `omie/http.py`

**Alterações**:
1. `from omie._core.retry import RetryConfig, RetryOverride` → `from omie.retry import RetryConfig, RetryOverride`

---

**Arquivo**: `omie/modules/financas/__init__.py`

**Alterações**:
1. `from omie._core.base import _BaseContext` → `from omie.base import _BaseContext`
2. `from omie._core.http import TimeoutConfig, TimeoutOverride, TimeRangeConfig, TimeRangeOverride` → `from omie.http import TimeoutConfig, TimeoutOverride, TimeRangeConfig, TimeRangeOverride`
3. `from omie._core.retry import RetryConfig, RetryOverride` → `from omie.retry import RetryConfig, RetryOverride`
4. `from omie.financas.models import ...` → `from omie.modules.financas.models import ...`

---

**Arquivo**: `omie/modules/vendas/__init__.py`

**Alterações**:
1. `from omie._core.base import _BaseContext` → `from omie.base import _BaseContext`
2. `from omie._core.http import ...` → `from omie.http import ...`
3. `from omie._core.retry import ...` → `from omie.retry import ...`
4. `from omie.vendas.models import ...` → `from omie.modules.vendas.models import ...`

---

**Arquivo**: `omie/modules/clientes/__init__.py`

**Alterações**:
1. `from omie._core.base import _BaseContext` → `from omie.base import _BaseContext`
2. `from omie._core.http import ...` → `from omie.http import ...`
3. `from omie._core.retry import ...` → `from omie.retry import ...`
4. `from omie.clientes.models import ...` → `from omie.modules.clientes.models import ...`

---

**Arquivo**: `omie/modules/produtos/__init__.py`

**Alterações**:
1. `from omie._core.base import _BaseContext` → `from omie.base import _BaseContext`
2. `from omie._core.http import ...` → `from omie.http import ...`
3. `from omie._core.retry import ...` → `from omie.retry import ...`
4. `from omie.produtos.models import ...` → `from omie.modules.produtos.models import ...`

---

**Arquivo**: `omie/modules/financas/models.py`

**Alterações**:
1. `from omie._core.base import BaseOmieModel` → `from omie.base import BaseOmieModel`
2. `from omie._core.validators import validate_date, validate_date_optional` → `from omie.validators import validate_date, validate_date_optional`

---

**Arquivo**: `omie/modules/vendas/models.py`

**Alterações**:
1. `from omie._core.base import BaseOmieModel` → `from omie.base import BaseOmieModel`
2. `from omie._core.validators import validate_date, validate_date_optional` → `from omie.validators import validate_date, validate_date_optional`

---

**Arquivo**: `omie/modules/clientes/models.py`

**Alterações**:
1. `from omie._core.base import BaseOmieModel` → `from omie.base import BaseOmieModel`
2. `from omie._core.validators import validate_date_optional` → `from omie.validators import validate_date_optional`

---

**Arquivo**: `omie/modules/produtos/models.py`

**Alterações**:
1. `from omie._core.base import BaseOmieModel` → `from omie.base import BaseOmieModel`
2. `from omie._core.validators import validate_date_optional` → `from omie.validators import validate_date_optional`

---

**Arquivo**: `omie/modules/servicos/models.py`

**Alterações**:
1. `from omie._core.base import BaseOmieModel` → `from omie.base import BaseOmieModel`
2. `from omie._core.validators import validate_date_optional` → `from omie.validators import validate_date_optional`

---

**Arquivo**: `tests/test_sdk.py`

**Alterações**:
1. `from omie.financas import OmieFinancas` → `from omie.modules.financas import OmieFinancas`
2. `from omie.financas.models import ...` → `from omie.modules.financas.models import ...`

---

**Arquivo**: `tests/test_real_http.py`

**Alterações**:
1. `from omie.vendas import OmieVendas` → `from omie.modules.vendas import OmieVendas`
2. `from omie.vendas.models import ListarPedidosParam` → `from omie.modules.vendas.models import ListarPedidosParam`

## Estratégia de Testes

### Abordagem de Validação

A estratégia de testes segue duas fases: primeiro, demonstrar que os imports estão quebrados no código atual, depois verificar que o fix resolve todos os imports e preserva o comportamento existente.

### Verificação Exploratória da Condição de Bug

**Objetivo**: Demonstrar os `ModuleNotFoundError` no código não corrigido para confirmar a causa raiz.

**Plano de Teste**: Tentar importar o SDK e cada módulo individualmente, observando os erros de importação.

**Casos de Teste**:
1. **Import do SDK principal**: `import omie` — falhará com `ModuleNotFoundError: No module named 'omie._core'`
2. **Import de módulo de domínio**: `from omie.modules.financas import OmieFinancas` — falhará porque `financas/__init__.py` importa de `omie._core`
3. **Import de models**: `from omie.modules.financas.models import ContaReceberParam` — falhará porque `models.py` importa de `omie._core`
4. **Import nos testes**: `from omie.financas import OmieFinancas` — falhará porque `omie.financas` não existe (é `omie.modules.financas`)

**Contraexemplos Esperados**:
- `ModuleNotFoundError: No module named 'omie._core'` em qualquer tentativa de import
- Causa: diretório `omie/_core/` não existe na estrutura atual

### Verificação do Fix

**Objetivo**: Verificar que para todos os imports onde a condição de bug se aplica, o import corrigido resolve corretamente.

**Pseudocódigo:**
```
PARA TODO importStatement ONDE isBugCondition(importStatement) FAÇA
  resultado := executarImport(importCorrigido(importStatement))
  ASSERT resultado NÃO levanta ModuleNotFoundError
  ASSERT módulo importado contém os símbolos esperados
FIM PARA
```

### Verificação de Preservação

**Objetivo**: Verificar que para todo código que NÃO envolve caminhos de import, o comportamento permanece idêntico.

**Pseudocódigo:**
```
PARA TODO input ONDE NOT isBugCondition(input) FAÇA
  ASSERT comportamento_original(input) = comportamento_corrigido(input)
FIM PARA
```

**Abordagem de Teste**: Testes baseados em propriedades são recomendados para verificação de preservação porque:
- Geram muitos casos de teste automaticamente cobrindo o domínio de entrada
- Capturam edge cases que testes manuais podem perder
- Fornecem garantias fortes de que o comportamento não mudou para inputs não afetados pelo bug

**Plano de Teste**: Executar os testes existentes (`test_sdk.py`) após a correção dos imports para verificar que toda a lógica de validação, serialização e tratamento de erros continua funcionando.

**Casos de Teste**:
1. **Preservação de validações Pydantic**: Verificar que modelos continuam validando campos corretamente após o fix
2. **Preservação de serialização**: Verificar que `to_omie_dict()` produz os mesmos resultados
3. **Preservação de erros**: Verificar que `parse_omie_response` continua classificando erros corretamente
4. **Preservação de retry/timeout**: Verificar que configurações de retry e timeout funcionam como antes

### Testes Unitários

- Verificar que `import omie` funciona sem erro
- Verificar que cada módulo de domínio pode ser importado individualmente
- Verificar que todos os modelos Pydantic podem ser instanciados
- Verificar que os testes existentes em `test_sdk.py` passam integralmente

### Testes Baseados em Propriedades

- Gerar inputs aleatórios para modelos Pydantic e verificar que validações funcionam corretamente após o fix
- Gerar respostas de API aleatórias e verificar que `parse_omie_response` classifica erros identicamente
- Testar que `to_omie_dict()` produz output consistente para inputs variados

### Testes de Integração

- Executar o fluxo completo de criação do client `Omie` e verificar que todos os sub-módulos são inicializados
- Verificar que chamadas de API (com mock) funcionam end-to-end após a correção
- Executar `test_sdk.py` e `test_real_http.py` (com imports corrigidos) para validação completa
