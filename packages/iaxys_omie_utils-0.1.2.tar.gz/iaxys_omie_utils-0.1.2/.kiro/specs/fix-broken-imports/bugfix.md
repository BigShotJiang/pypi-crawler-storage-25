# Documento de Requisitos do Bugfix

## Introdução

Após a reestruturação do projeto omie-sdk, os caminhos de importação ficaram quebrados em diversos arquivos. O diretório `omie/_core/` não existe mais — os módulos `base.py`, `http.py`, `retry.py` e `validators.py` agora residem diretamente em `omie/`. Além disso, os submódulos (clientes, financas, produtos, vendas) foram movidos para `omie/modules/`, mas as importações internas e nos testes ainda referenciam os caminhos antigos sem o prefixo `modules/`. Isso impede a execução do SDK e dos testes.

## Bug Analysis

### Current Behavior (Defect)

1.1 WHEN qualquer módulo importa de `omie._core.base`, `omie._core.http`, `omie._core.retry` ou `omie._core.validators` THEN o sistema lança `ModuleNotFoundError` pois o diretório `omie/_core/` não existe

1.2 WHEN `omie/base.py` importa de `omie._core.http` e `omie._core.retry` THEN o sistema lança `ModuleNotFoundError` por auto-referência circular a um caminho inexistente

1.3 WHEN `omie/http.py` importa de `omie._core.retry` THEN o sistema lança `ModuleNotFoundError` pois `omie/_core/` não existe

1.4 WHEN `omie/modules/clientes/__init__.py` importa de `omie.clientes.models` THEN o sistema lança `ModuleNotFoundError` pois o caminho correto é `omie.modules.clientes.models`

1.5 WHEN `omie/modules/financas/__init__.py` importa de `omie.financas.models` THEN o sistema lança `ModuleNotFoundError` pois o caminho correto é `omie.modules.financas.models`

1.6 WHEN `omie/modules/produtos/__init__.py` importa de `omie.produtos.models` THEN o sistema lança `ModuleNotFoundError` pois o caminho correto é `omie.modules.produtos.models`

1.7 WHEN `omie/modules/vendas/__init__.py` importa de `omie.vendas.models` THEN o sistema lança `ModuleNotFoundError` pois o caminho correto é `omie.modules.vendas.models`

1.8 WHEN `tests/test_sdk.py` importa de `omie.financas` e `omie.financas.models` THEN o sistema lança `ModuleNotFoundError` pois o caminho correto inclui `modules/`

1.9 WHEN `tests/test_real_http.py` importa de `omie.vendas` e `omie.vendas.models` THEN o sistema lança `ModuleNotFoundError` pois o caminho correto inclui `modules/`

### Expected Behavior (Correct)

2.1 WHEN qualquer módulo precisa importar de `omie._core.base` THEN o sistema SHALL importar de `omie.base` com sucesso

2.2 WHEN qualquer módulo precisa importar de `omie._core.http` THEN o sistema SHALL importar de `omie.http` com sucesso

2.3 WHEN qualquer módulo precisa importar de `omie._core.retry` THEN o sistema SHALL importar de `omie.retry` com sucesso

2.4 WHEN qualquer módulo precisa importar de `omie._core.validators` THEN o sistema SHALL importar de `omie.validators` com sucesso

2.5 WHEN `omie/base.py` precisa de classes de `http.py` e `retry.py` THEN o sistema SHALL importar de `omie.http` e `omie.retry` sem erro

2.6 WHEN `omie/http.py` precisa de classes de `retry.py` THEN o sistema SHALL importar de `omie.retry` sem erro

2.7 WHEN `omie/modules/clientes/__init__.py` importa seus models THEN o sistema SHALL importar de `omie.modules.clientes.models` com sucesso

2.8 WHEN `omie/modules/financas/__init__.py` importa seus models THEN o sistema SHALL importar de `omie.modules.financas.models` com sucesso

2.9 WHEN `omie/modules/produtos/__init__.py` importa seus models THEN o sistema SHALL importar de `omie.modules.produtos.models` com sucesso

2.10 WHEN `omie/modules/vendas/__init__.py` importa seus models THEN o sistema SHALL importar de `omie.modules.vendas.models` com sucesso

2.11 WHEN `tests/test_sdk.py` importa módulos de financas THEN o sistema SHALL importar de `omie.modules.financas` e `omie.modules.financas.models` com sucesso

2.12 WHEN `tests/test_real_http.py` importa módulos de vendas THEN o sistema SHALL importar de `omie.modules.vendas` e `omie.modules.vendas.models` com sucesso

### Unchanged Behavior (Regression Prevention)

3.1 WHEN módulos importam de `omie.errors` THEN o sistema SHALL CONTINUE TO resolver as importações corretamente

3.2 WHEN os models dos submódulos (clientes, financas, produtos, vendas, servicos) são utilizados THEN o sistema SHALL CONTINUE TO expor as mesmas classes e funções públicas com a mesma interface

3.3 WHEN `omie/__init__.py` exporta a API pública do SDK THEN o sistema SHALL CONTINUE TO expor os mesmos símbolos públicos (classes, funções) disponíveis antes da correção

3.4 WHEN os testes existentes são executados com os imports corrigidos THEN o sistema SHALL CONTINUE TO passar todos os testes que passavam antes da reestruturação

3.5 WHEN código externo importa diretamente de `omie` (ex: `from omie import OmieHttp`) THEN o sistema SHALL CONTINUE TO resolver essas importações corretamente
