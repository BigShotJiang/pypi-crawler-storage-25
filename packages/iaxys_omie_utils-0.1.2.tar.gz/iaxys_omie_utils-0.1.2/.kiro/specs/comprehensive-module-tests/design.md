# Design Document: Comprehensive Module Tests

## Overview

This design establishes a comprehensive testing framework for all five Omie SDK Python modules (clientes, financas, produtos, servicos, vendas). The testing strategy employs a dual approach combining traditional unit tests with property-based testing to ensure correctness, robustness, and maintainability.

The design addresses three critical testing dimensions:

1. **Model Validation Testing**: Verifies Pydantic model field validators, type coercion, and business rules
2. **Serialization Testing**: Ensures bidirectional consistency between Python models and Omie API dictionaries
3. **Client Method Testing**: Validates HTTP client behavior with mocked responses

The testing framework will use pytest as the test runner, pytest-mock for HTTP mocking, and Hypothesis for property-based testing. All tests will execute without making real HTTP calls to the Omie API, ensuring fast, deterministic, and isolated test execution.

## Architecture

### Test Organization Structure

```
tests/
├── conftest.py                    # Shared fixtures and configuration
├── test_models_clientes.py        # Model validation tests for clientes
├── test_models_financas.py        # Model validation tests for financas
├── test_models_produtos.py        # Model validation tests for produtos
├── test_models_servicos.py        # Model validation tests for servicos
├── test_models_vendas.py          # Model validation tests for vendas
├── test_client_clientes.py        # Client method tests for clientes
├── test_client_financas.py        # Client method tests for financas
├── test_client_produtos.py        # Client method tests for produtos
├── test_client_servicos.py        # Client method tests for servicos
├── test_client_vendas.py          # Client method tests for vendas
├── test_serialization.py          # Cross-module serialization tests
└── properties/                    # Property-based tests
    ├── test_properties_clientes.py
    ├── test_properties_financas.py
    ├── test_properties_produtos.py
    ├── test_properties_servicos.py
    └── test_properties_vendas.py
```

### Testing Layers

**Layer 1: Model Validation Tests**
- Test Pydantic field validators
- Test model_validator logic
- Test edge cases (empty strings, boundary values, invalid formats)
- Test immutability (frozen models)
- Test type coercion behavior

**Layer 2: Serialization Tests**
- Test to_omie_dict() excludes None values
- Test field name preservation
- Test value transformation correctness
- Test round-trip consistency (where applicable)

**Layer 3: Client Method Tests**
- Test correct API path and call name
- Test parameter serialization and passing
- Test default parameter handling
- Test retry/timeout/time_range override passing
- Test error propagation from HTTP layer

**Layer 4: Property-Based Tests**
- Test universal invariants across all valid inputs
- Test round-trip properties for serialization
- Test model validation boundaries
- Test client behavior consistency

### Mocking Strategy

All HTTP calls will be mocked at the `OmieHttp.post` method level using pytest-mock. This approach:

- Prevents real API calls during testing
- Allows verification of correct parameters passed to HTTP layer
- Enables testing of error handling paths
- Provides fast, deterministic test execution

Mock implementation pattern:
```python
def test_client_method(mocker):
    mock_post = mocker.patch.object(OmieHttp, 'post', return_value={'result': 'success'})
    client = OmieClientes(app_key='test', app_secret='test')
    
    result = client.incluir_cliente(param)
    
    mock_post.assert_called_once_with(
        'geral/clientes',
        'IncluirCliente',
        [param.to_omie_dict()],
        retry=None,
        timeout=None,
        time_range=None
    )
```

## Components and Interfaces

### Test Fixtures (conftest.py)

**Purpose**: Provide reusable test data and mock configurations

```python
@pytest.fixture
def valid_cliente_data():
    """Returns valid data for ClienteParam"""
    return {
        'razao_social': 'Test Company',
        'cnpj_cpf': '12345678901234',
        'email': 'test@example.com',
        # ... other fields
    }

@pytest.fixture
def mock_http_success(mocker):
    """Mocks OmieHttp.post to return success"""
    return mocker.patch.object(
        OmieHttp, 
        'post', 
        return_value={'codigo_cliente_omie': 123}
    )

@pytest.fixture
def mock_http_error(mocker):
    """Mocks OmieHttp.post to raise OmieError"""
    def _mock_error(error_class, message):
        mocker.patch.object(
            OmieHttp,
            'post',
            side_effect=error_class('SOAP-ENV:Client', message)
        )
    return _mock_error
```

### Model Test Pattern

Each model test file follows this structure:

1. **Valid Construction Tests**: Verify models can be created with valid data
2. **Validation Tests**: Test each field validator with invalid inputs
3. **Model Validator Tests**: Test cross-field validation logic
4. **Immutability Tests**: Verify frozen model behavior
5. **Serialization Tests**: Test to_omie_dict() behavior

Example test structure:
```python
class TestClienteParam:
    def test_valid_construction(self, valid_cliente_data):
        """Should create model with valid data"""
        param = ClienteParam(**valid_cliente_data)
        assert param.razao_social == valid_cliente_data['razao_social']
    
    def test_razao_social_empty_rejected(self):
        """Should reject empty razao_social"""
        with pytest.raises(ValidationError):
            ClienteParam(razao_social='', cnpj_cpf='12345678901234')
    
    def test_cnpj_cpf_invalid_length(self):
        """Should reject CNPJ/CPF with invalid digit count"""
        with pytest.raises(ValidationError):
            ClienteParam(razao_social='Test', cnpj_cpf='123')
    
    def test_to_omie_dict_excludes_none(self, valid_cliente_data):
        """Should exclude None values from serialization"""
        param = ClienteParam(**valid_cliente_data)
        result = param.to_omie_dict()
        assert 'codigo_cliente_omie' not in result
    
    def test_immutability(self, valid_cliente_data):
        """Should prevent field mutation"""
        param = ClienteParam(**valid_cliente_data)
        with pytest.raises(TypeError):
            param.razao_social = 'New Name'
```

### Client Test Pattern

Each client test file follows this structure:

1. **Method Call Tests**: Verify correct HTTP parameters
2. **Default Parameter Tests**: Test optional parameter defaults
3. **Override Tests**: Test retry/timeout/time_range overrides
4. **Error Propagation Tests**: Verify errors bubble up correctly

Example test structure:
```python
class TestOmieClientes:
    def test_incluir_cliente_calls_correct_endpoint(self, mocker, valid_cliente_data):
        """Should call correct API path and method"""
        mock_post = mocker.patch.object(OmieHttp, 'post', return_value={})
        client = OmieClientes(app_key='test', app_secret='test')
        param = ClienteParam(**valid_cliente_data)
        
        client.incluir_cliente(param)
        
        mock_post.assert_called_once()
        args = mock_post.call_args
        assert args[0][0] == 'geral/clientes'
        assert args[0][1] == 'IncluirCliente'
    
    def test_listar_clientes_uses_defaults(self, mocker):
        """Should use default pagination when no param provided"""
        mock_post = mocker.patch.object(OmieHttp, 'post', return_value={})
        client = OmieClientes(app_key='test', app_secret='test')
        
        client.listar_clientes()
        
        call_param = mock_post.call_args[0][2][0]
        assert call_param['pagina'] == 1
        assert call_param['registros_por_pagina'] == 50
    
    def test_error_propagation(self, mocker, valid_cliente_data):
        """Should propagate OmieError from HTTP layer"""
        mocker.patch.object(
            OmieHttp,
            'post',
            side_effect=OmieDuplicateError('SOAP-ENV:Client-6', 'duplicate')
        )
        client = OmieClientes(app_key='test', app_secret='test')
        param = ClienteParam(**valid_cliente_data)
        
        with pytest.raises(OmieDuplicateError):
            client.incluir_cliente(param)
```

### Property-Based Test Pattern

Property tests use Hypothesis to generate random valid inputs and verify invariants:

```python
from hypothesis import given, strategies as st
from hypothesis.strategies import composite

@composite
def cliente_param_strategy(draw):
    """Generates valid ClienteParam data"""
    return {
        'razao_social': draw(st.text(min_size=1, max_size=100)),
        'cnpj_cpf': draw(st.sampled_from([
            ''.join(str(i) for i in range(11)),  # CPF
            ''.join(str(i) for i in range(14)),  # CNPJ
        ])),
        'email': draw(st.emails()),
    }

@given(cliente_param_strategy())
def test_property_serialization_excludes_none(data):
    """Property: to_omie_dict should never include None values"""
    param = ClienteParam(**data)
    result = param.to_omie_dict()
    assert all(v is not None for v in result.values())

@given(cliente_param_strategy())
def test_property_immutability(data):
    """Property: All model instances should be immutable"""
    param = ClienteParam(**data)
    with pytest.raises(TypeError):
        param.razao_social = 'modified'
```

## Data Models

### Test Data Categories

**Valid Data Sets**: Minimal valid data for each model type
- Used for positive test cases
- Stored as fixtures in conftest.py
- One fixture per model class

**Invalid Data Sets**: Data that should trigger validation errors
- Empty strings for required fields
- Invalid date formats
- Out-of-range numeric values
- Invalid CNPJ/CPF formats
- Negative values where positive required

**Edge Case Data**: Boundary conditions
- Maximum string lengths
- Minimum/maximum numeric values
- Special characters in text fields
- Date boundaries (past/future limits)

**Mock Response Data**: Simulated API responses
- Success responses with expected structure
- Error responses with faultcode/faultstring
- Pagination responses with multiple pages
- Empty result sets

### Data Generation Strategy

For property-based tests, Hypothesis strategies will generate:

1. **Text Fields**: Non-empty strings with reasonable length constraints
2. **Numeric Fields**: Positive numbers within valid ranges
3. **Date Fields**: Valid DD/MM/YYYY format strings
4. **CNPJ/CPF**: Valid 11 or 14 digit strings
5. **Optional Fields**: Mix of None and valid values
6. **Enum Fields**: Sample from valid options only

Example strategy definitions:
```python
# Date strategy (DD/MM/YYYY format)
date_strategy = st.dates(
    min_value=date(2020, 1, 1),
    max_value=date(2030, 12, 31)
).map(lambda d: d.strftime('%d/%m/%Y'))

# CNPJ/CPF strategy
cnpj_cpf_strategy = st.one_of(
    st.text(min_size=11, max_size=11, alphabet=st.characters(whitelist_categories=('Nd',))),
    st.text(min_size=14, max_size=14, alphabet=st.characters(whitelist_categories=('Nd',)))
)

# Positive float strategy
positive_float_strategy = st.floats(min_value=0.01, max_value=999999.99, allow_nan=False, allow_infinity=False)
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property Reflection

After analyzing all acceptance criteria, I identified the following redundancies:

- Properties 1.3 and 1.4 (None exclusion and value preservation) can be combined into a single comprehensive serialization property
- Properties 2.1 and 2.2 (correct path and call name) are specific examples, not universal properties - they belong in unit tests
- Properties 3.2, 3.3, 3.4 (specific validation types) are all instances of the general property 1.2 (validators reject invalid data)
- Property 3.5 (pagination limits) is an edge case that will be covered by property 1.2

The consolidated properties below eliminate this redundancy while maintaining complete coverage.

### Property 1: Model Construction with Valid Data

*For any* model class (ClienteParam, ProdutoParam, ContaReceberParam, etc.) and any valid data dictionary conforming to that model's schema, constructing the model should succeed without raising ValidationError.

**Validates: Requirements 1.1**

### Property 2: Model Validation Rejects Invalid Data

*For any* model class and any invalid data (empty required strings, wrong date formats, negative values where positive required, invalid CNPJ/CPF lengths, out-of-range pagination), attempting to construct the model should raise ValidationError.

**Validates: Requirements 1.2, 3.1, 3.2, 3.3, 3.4, 3.5**

### Property 3: Serialization Preserves Non-None Values

*For any* model instance, calling to_omie_dict() should return a dictionary that:
- Contains all fields that were set to non-None values
- Excludes all fields that are None
- Preserves the exact values of all included fields

**Validates: Requirements 1.3, 1.4**

### Property 4: Model Immutability

*For any* model instance and any field name, attempting to modify that field after construction should raise TypeError (frozen model behavior).

**Validates: Requirements 1.5**

### Property 5: Client Parameter Serialization

*For any* client method that accepts a parameter object, the method should serialize the parameter using to_omie_dict() before passing it to OmieHttp.post.

**Validates: Requirements 2.3**

### Property 6: Client Override Propagation

*For any* client method and any combination of retry/timeout/time_range overrides, the method should pass these overrides to OmieHttp.post without modification.

**Validates: Requirements 2.5**

### Property 7: Client Error Propagation

*For any* client method, when OmieHttp.post raises an OmieError (or any subclass), the client method should propagate that error to the caller without catching or transforming it.

**Validates: Requirements 2.6**

## Error Handling

### Error Detection Strategy

The test suite will identify existing errors through:

1. **Validation Errors**: Tests that trigger field validators will expose incorrect validation logic
2. **Serialization Errors**: Tests comparing to_omie_dict() output will reveal missing or incorrect field mappings
3. **Client Errors**: Mocked HTTP tests will expose incorrect API paths, call names, or parameter passing
4. **Type Errors**: Immutability tests will reveal models that aren't properly frozen

### Error Reporting

When tests fail, they should provide:
- Clear description of what was expected
- Actual behavior observed
- Minimal reproduction case
- Specific file and line number where the error occurs

Example error output:
```
FAILED test_models_clientes.py::test_cnpj_cpf_validation
Expected: ValidationError for CNPJ with 10 digits
Actual: Model constructed successfully with invalid CNPJ
Input: {'razao_social': 'Test', 'cnpj_cpf': '1234567890'}
Location: omie/modules/clientes/models.py:45
```

### Error Fixing Workflow

1. **Run Full Test Suite**: Execute all tests to identify failures
2. **Categorize Failures**: Group by error type (validation, serialization, client)
3. **Fix Root Cause**: Modify model validators, serialization logic, or client methods
4. **Verify Fix**: Re-run specific test to confirm fix
5. **Regression Check**: Run full suite to ensure fix didn't break other tests
6. **Document**: Update any relevant documentation or comments

### Known Error Categories

Based on analysis of existing code, potential errors include:

**Validation Errors**:
- Missing validators for required fields
- Incorrect regex patterns for format validation
- Wrong boundary checks for numeric fields
- Inconsistent date format validation

**Serialization Errors**:
- None values not properly excluded
- Field name mismatches between Python and API
- Missing fields in serialization output
- Incorrect type conversions

**Client Errors**:
- Wrong API path strings
- Incorrect call method names
- Parameters not properly serialized
- Overrides not passed through to HTTP layer
- Default parameters not applied correctly

## Testing Strategy

### Dual Testing Approach

The testing strategy employs both unit tests and property-based tests as complementary techniques:

**Unit Tests** focus on:
- Specific examples of correct behavior
- Edge cases with known inputs and outputs
- Integration points between components
- Concrete error conditions
- Specific API endpoint paths and call names

**Property-Based Tests** focus on:
- Universal invariants that hold for all inputs
- Comprehensive input coverage through randomization
- Discovering unexpected edge cases
- Verifying mathematical properties (like round-trips)
- Testing behavior across the entire input space

Together, these approaches provide comprehensive coverage: unit tests catch concrete bugs with specific scenarios, while property tests verify general correctness across thousands of generated inputs.

### Property-Based Testing Configuration

**Library Selection**: Hypothesis (https://hypothesis.readthedocs.io/)
- Industry-standard property-based testing library for Python
- Excellent integration with pytest
- Sophisticated input generation strategies
- Automatic shrinking of failing examples
- Stateful testing capabilities

**Test Configuration**:
```python
from hypothesis import given, settings, strategies as st

@settings(max_examples=100)  # Minimum 100 iterations per property
@given(st.data())
def test_property_name(data):
    # Property test implementation
    pass
```

**Tagging Convention**:
Each property-based test must include a comment referencing the design property:
```python
# Feature: comprehensive-module-tests, Property 1: Model Construction with Valid Data
@settings(max_examples=100)
@given(cliente_param_strategy())
def test_property_model_construction(data):
    param = ClienteParam(**data)
    assert param is not None
```

### Test Execution Strategy

**Test Organization**:
- Model tests run first (fastest, no mocking required)
- Serialization tests run second (fast, no mocking required)
- Client tests run third (require mocking setup)
- Property tests run last (slowest due to iteration count)

**Parallel Execution**:
Tests can run in parallel using pytest-xdist since all HTTP is mocked:
```bash
pytest -n auto  # Use all available CPU cores
```

**Selective Execution**:
```bash
# Run only model tests
pytest tests/test_models_*.py

# Run only client tests
pytest tests/test_client_*.py

# Run only property tests
pytest tests/properties/

# Run tests for specific module
pytest tests/test_models_clientes.py tests/test_client_clientes.py
```

### Coverage Goals

**Minimum Coverage Targets**:
- Model validation: 100% of field validators
- Serialization: 100% of model classes
- Client methods: 100% of public methods
- Error paths: All OmieError subclasses

**Coverage Measurement**:
```bash
pytest --cov=omie --cov-report=html --cov-report=term
```

Coverage should exclude:
- `__init__.py` files (re-exports only)
- Type stubs and protocol definitions
- Deprecated code paths

### Test Data Management

**Fixture Organization**:
- Shared fixtures in `conftest.py`
- Module-specific fixtures in respective test files
- Property strategies in separate `strategies.py` module

**Data Isolation**:
- Each test uses fresh data (no shared mutable state)
- Fixtures use `scope="function"` by default
- Mock objects reset between tests

**Hypothesis Strategy Organization**:
```python
# tests/strategies.py
from hypothesis import strategies as st
from hypothesis.strategies import composite

@composite
def cliente_param_strategy(draw):
    """Generate valid ClienteParam data"""
    # Implementation
    pass

@composite
def produto_param_strategy(draw):
    """Generate valid ProdutoParam data"""
    # Implementation
    pass

# Reusable component strategies
cnpj_cpf_strategy = st.one_of(
    st.text(min_size=11, max_size=11, alphabet='0123456789'),
    st.text(min_size=14, max_size=14, alphabet='0123456789')
)

date_dd_mm_yyyy_strategy = st.dates(
    min_value=date(2020, 1, 1),
    max_value=date(2030, 12, 31)
).map(lambda d: d.strftime('%d/%m/%Y'))
```

### Continuous Integration

**CI Pipeline Steps**:
1. Install dependencies (pytest, pytest-mock, hypothesis)
2. Run linter (ruff or flake8)
3. Run type checker (mypy)
4. Run test suite with coverage
5. Generate coverage report
6. Fail if coverage below threshold (e.g., 90%)

**GitHub Actions Example**:
```yaml
name: Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.10'
      - run: pip install -e ".[dev]" pytest-cov hypothesis pytest-mock
      - run: pytest --cov=omie --cov-fail-under=90
```

### Test Maintenance

**When Adding New Models**:
1. Add model validation tests in `test_models_{module}.py`
2. Add serialization tests in `test_serialization.py`
3. Add property strategy in `strategies.py`
4. Add property tests in `properties/test_properties_{module}.py`

**When Adding New Client Methods**:
1. Add method tests in `test_client_{module}.py`
2. Test correct path and call name
3. Test parameter serialization
4. Test default parameter handling
5. Test override propagation
6. Test error propagation

**When Modifying Validators**:
1. Update corresponding validation tests
2. Update property strategies if validation rules changed
3. Re-run property tests to catch edge cases
4. Update test data fixtures if needed

### Dependencies

**Required Test Dependencies**:
```toml
[project.optional-dependencies]
dev = [
    "pytest>=7.0",
    "pytest-mock>=3.10",
    "pytest-cov>=4.0",
    "pytest-xdist>=3.0",  # For parallel execution
    "hypothesis>=6.0",
    "hatch"
]
```

**Installation**:
```bash
pip install -e ".[dev]"
```

### Success Criteria

The test suite is considered complete when:

1. All five modules have comprehensive test coverage
2. All model classes have validation tests
3. All model classes have serialization tests
4. All client methods have mocked HTTP tests
5. All seven correctness properties have property-based tests
6. Test coverage exceeds 90% for omie package
7. All tests pass consistently
8. Tests execute in under 60 seconds
9. No real HTTP calls are made during testing
10. CI pipeline runs successfully

