from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass
from typing import Any, Optional

import httpx

from iaxys_omie_utils.errors import OmieClientError, OmieServerError, parse_omie_response
from iaxys_omie_utils.retry import RetryConfig, RetryOverride


@dataclass
class TimeoutConfig:
    connect: float = 5.0
    read: float = 30.0

    def as_httpx(self) -> httpx.Timeout:
        return httpx.Timeout(connect=self.connect, read=self.read, write=self.connect, pool=self.connect)


@dataclass
class TimeoutOverride:
    connect: Optional[float] = None
    read: Optional[float] = None

    def apply_to(self, base: TimeoutConfig) -> TimeoutConfig:
        return TimeoutConfig(
            connect=self.connect if self.connect is not None else base.connect,
            read=self.read if self.read is not None else base.read,
        )


@dataclass
class TimeRangeConfig:
    min_interval: float = 0.0


@dataclass
class TimeRangeOverride:
    min_interval: Optional[float] = None

    def apply_to(self, base: TimeRangeConfig) -> TimeRangeConfig:
        return TimeRangeConfig(
            min_interval=self.min_interval
            if self.min_interval is not None
            else base.min_interval,
        )


class OmieHttp:
    """Executa chamadas autenticadas à API Omie com retry, throttle e timeout configuráveis."""

    BASE_URL = "https://app.omie.com.br/api/v1"
    HEADERS = {"Content-Type": "application/json"}

    def __init__(
        self,
        app_key: str,
        app_secret: str,
        *,
        retry: Optional[RetryConfig] = None,
        timeout: Optional[TimeoutConfig] = None,
        time_range: Optional[TimeRangeConfig] = None,
    ) -> None:
        if not app_key or not app_secret:
            raise ValueError("app_key e app_secret são obrigatórios")
        self._app_key = app_key
        self._app_secret = app_secret
        self._retry = retry if retry is not None else RetryConfig()
        self._timeout = timeout if timeout is not None else TimeoutConfig()
        self._time_range = time_range if time_range is not None else TimeRangeConfig()
        self._last_call = 0.0

    def _build_payload(self, call: str, param: list[dict[str, Any]]) -> str:
        return json.dumps({
            "app_key": self._app_key,
            "app_secret": self._app_secret,
            "call": call,
            "param": param,
        })

    def _resolve_configs(
        self,
        retry: Optional[RetryOverride],
        timeout: Optional[TimeoutOverride],
        time_range: Optional[TimeRangeOverride],
    ) -> tuple[RetryConfig, TimeoutConfig, TimeRangeConfig]:
        return (
            retry.apply_to(self._retry) if retry else self._retry,
            timeout.apply_to(self._timeout) if timeout else self._timeout,
            time_range.apply_to(self._time_range) if time_range else self._time_range,
        )

    @staticmethod
    def _parse(response: httpx.Response) -> dict:
        try:
            data = response.json()
        except (ValueError, json.JSONDecodeError):
            response.raise_for_status()
            return {}
        return parse_omie_response(data)

    # ── Sync ──────────────────────────────────────────────────────

    def post(
        self,
        path: str,
        call: str,
        param: list[dict[str, Any]],
        *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        cfg_retry, cfg_timeout, cfg_time_range = self._resolve_configs(retry, timeout, time_range)
        url = f"{self.BASE_URL}/{path.strip('/')}/"
        payload = self._build_payload(call, param)
        last_exc: BaseException = RuntimeError("nenhuma tentativa realizada")

        for attempt in range(1, cfg_retry.attempts + 1):
            self._throttle(cfg_time_range)
            try:
                resp = httpx.post(url, headers=self.HEADERS, content=payload, timeout=cfg_timeout.as_httpx())
                return self._parse(resp)
            except OmieClientError:
                raise
            except OmieServerError as e:
                last_exc = e
            except (httpx.TimeoutException, httpx.ConnectError) as e:
                last_exc = e

            if attempt < cfg_retry.attempts:
                time.sleep(cfg_retry.delay_for(attempt))

        raise last_exc

    # ── Async ─────────────────────────────────────────────────────

    async def apost(
        self,
        path: str,
        call: str,
        param: list[dict[str, Any]],
        *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        cfg_retry, cfg_timeout, cfg_time_range = self._resolve_configs(retry, timeout, time_range)
        url = f"{self.BASE_URL}/{path.strip('/')}/"
        payload = self._build_payload(call, param)
        last_exc: BaseException = RuntimeError("nenhuma tentativa realizada")

        for attempt in range(1, cfg_retry.attempts + 1):
            await self._athrottle(cfg_time_range)
            try:
                async with httpx.AsyncClient() as client:
                    resp = await client.post(url, headers=self.HEADERS, content=payload, timeout=cfg_timeout.as_httpx())
                return self._parse(resp)
            except OmieClientError:
                raise
            except OmieServerError as e:
                last_exc = e
            except (httpx.TimeoutException, httpx.ConnectError) as e:
                last_exc = e

            if attempt < cfg_retry.attempts:
                await asyncio.sleep(cfg_retry.delay_for(attempt))

        raise last_exc

    # ── Throttle ──────────────────────────────────────────────────

    def _throttle(self, cfg: TimeRangeConfig) -> None:
        if cfg.min_interval <= 0:
            return
        elapsed = time.monotonic() - self._last_call
        wait = cfg.min_interval - elapsed
        if wait > 0:
            time.sleep(wait)
        self._last_call = time.monotonic()

    async def _athrottle(self, cfg: TimeRangeConfig) -> None:
        if cfg.min_interval <= 0:
            return
        elapsed = time.monotonic() - self._last_call
        wait = cfg.min_interval - elapsed
        if wait > 0:
            await asyncio.sleep(wait)
        self._last_call = time.monotonic()
