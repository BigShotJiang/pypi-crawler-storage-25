from __future__ import annotations

from datetime import datetime
from typing import Optional


def validate_date(v: str) -> str:
    try:
        datetime.strptime(v, "%d/%m/%Y")
    except ValueError:
        raise ValueError(f"Data deve estar no formato DD/MM/YYYY, recebido: {v!r}")
    return v


def validate_date_optional(v: Optional[str]) -> Optional[str]:
    if v is None:
        return v
    return validate_date(v)
