from __future__ import annotations

from typing import Optional

from iaxys_omie_utils.base import _BaseContext
from iaxys_omie_utils.http import TimeoutConfig, TimeoutOverride, TimeRangeConfig, TimeRangeOverride
from iaxys_omie_utils.retry import RetryConfig, RetryOverride
from iaxys_omie_utils.modules.servicos.models import (
    ConsultarOsParam,
    ExcluirOsParam,
    ListarOsParam,
    OsCadastroParam,
    StatusOsParam,
    TrocarEtapaOsParam,
)

_PATH = "servicos/os"


class OmieServicos(_BaseContext):
    def __init__(
        self,
        app_key: str,
        app_secret: str,
        *,
        retry:      Optional[RetryConfig]     = None,
        timeout:    Optional[TimeoutConfig]   = None,
        time_range: Optional[TimeRangeConfig] = None,
    ) -> None:
        super().__init__(app_key, app_secret, retry=retry, timeout=timeout, time_range=time_range)

    # ── CRUD ──────────────────────────────────────────────────────

    def incluir_os(
        self,
        param: OsCadastroParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "IncluirOS", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aincluir_os(
        self,
        param: OsCadastroParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "IncluirOS", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def alterar_os(
        self,
        param: OsCadastroParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "AlterarOS", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aalterar_os(
        self,
        param: OsCadastroParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "AlterarOS", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def excluir_os(
        self,
        param: ExcluirOsParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "ExcluirOS", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aexcluir_os(
        self,
        param: ExcluirOsParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "ExcluirOS", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    # ── Consulta / Listagem ───────────────────────────────────────

    def consultar_os(
        self,
        param: ConsultarOsParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "ConsultarOS", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aconsultar_os(
        self,
        param: ConsultarOsParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "ConsultarOS", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def listar_os(
        self,
        param: Optional[ListarOsParam] = None,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        p = param or ListarOsParam()
        return self._http.post(
            _PATH, "ListarOS", [p.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def alistar_os(
        self,
        param: Optional[ListarOsParam] = None,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        p = param or ListarOsParam()
        return await self._http.apost(
            _PATH, "ListarOS", [p.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    # ── Status / Etapa ────────────────────────────────────────────

    def status_os(
        self,
        param: StatusOsParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "StatusOS", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def astatus_os(
        self,
        param: StatusOsParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "StatusOS", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def trocar_etapa_os(
        self,
        param: TrocarEtapaOsParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "TrocarEtapaOS", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def atrocar_etapa_os(
        self,
        param: TrocarEtapaOsParam,
        *,
        retry:      Optional[RetryOverride]     = None,
        timeout:    Optional[TimeoutOverride]   = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "TrocarEtapaOS", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )
