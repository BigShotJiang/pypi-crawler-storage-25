from __future__ import annotations

from typing import Optional
from pydantic import field_validator, model_validator

from iaxys_omie_utils.base import BaseOmieModel
from iaxys_omie_utils.validators import validate_date, validate_date_optional

_SIM_NAO = {"S", "N"}
_ETAPAS_VALIDAS = {"10", "20", "30", "40", "50"}


# ── Sub-models da OS ──────────────────────────────────────────────


class ImpostosServico(BaseOmieModel):
    nAliqISS: Optional[float] = None
    nAliqIRRF: Optional[float] = None
    nAliqPIS: Optional[float] = None
    nAliqCOFINS: Optional[float] = None
    nAliqCSLL: Optional[float] = None
    nAliqINSS: Optional[float] = None
    cRetemIRRF: Optional[str] = None
    cRetemPIS: Optional[str] = None
    cRetemCOFINS: Optional[str] = None
    cRetemCSLL: Optional[str] = None
    cRetemINSS: Optional[str] = None

    @field_validator(
        "cRetemIRRF", "cRetemPIS", "cRetemCOFINS", "cRetemCSLL", "cRetemINSS",
    )
    @classmethod
    def _validar_sim_nao(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and v not in _SIM_NAO:
            raise ValueError(f"Valor deve ser 'S' ou 'N', recebido: {v!r}")
        return v


class ServicoPrestado(BaseOmieModel):
    nCodServico: Optional[int] = None
    cDescServ: Optional[str] = None
    nQtde: float
    nValUnit: float
    cTribServ: Optional[str] = None
    cCodServLC116: Optional[str] = None
    cCodServMun: Optional[str] = None
    cRetemISS: Optional[str] = None
    cDadosAdicItem: Optional[str] = None
    impostos: Optional[ImpostosServico] = None
    cNaoGerarFinanceiro: Optional[str] = None
    cCodCategItem: Optional[str] = None
    nSeqItem: Optional[int] = None
    nIdItem: Optional[int] = None
    cAcaoItem: Optional[str] = None
    cReembolso: Optional[str] = None

    @field_validator("nQtde")
    @classmethod
    def _validar_qtde(cls, v: float) -> float:
        if v <= 0:
            raise ValueError(f"nQtde deve ser > 0, recebido: {v}")
        return v

    @field_validator("nValUnit")
    @classmethod
    def _validar_valor(cls, v: float) -> float:
        if v <= 0:
            raise ValueError(f"nValUnit deve ser > 0, recebido: {v}")
        return v

    def to_omie_dict(self) -> dict:
        d = self.model_dump(exclude_none=True, exclude={"impostos"})
        if self.impostos is not None:
            d["impostos"] = self.impostos.to_omie_dict()
        return d


class CabecalhoOs(BaseOmieModel):
    cCodIntOS: Optional[str] = None
    nCodOS: Optional[int] = None
    cNumOS: Optional[str] = None
    nCodCli: Optional[int] = None
    cCodIntCli: Optional[str] = None
    dDtPrevisao: str
    cEtapa: str = "10"
    cCodParc: Optional[str] = None
    nQtdeParc: Optional[int] = None
    nCodVend: Optional[int] = None
    nCodCtr: Optional[int] = None

    @field_validator("dDtPrevisao")
    @classmethod
    def _validar_data(cls, v: str) -> str:
        return validate_date(v)

    @field_validator("cEtapa")
    @classmethod
    def _validar_etapa(cls, v: str) -> str:
        if v not in _ETAPAS_VALIDAS:
            raise ValueError(f"cEtapa deve ser uma de {_ETAPAS_VALIDAS}, recebido: {v!r}")
        return v


class InformacoesAdicionaisOs(BaseOmieModel):
    cCodCateg: Optional[str] = None
    nCodCC: Optional[int] = None
    cDadosAdicNF: Optional[str] = None
    cCidPrestServ: Optional[str] = None
    nCodProjeto: Optional[int] = None


class EmailOs(BaseOmieModel):
    cEnviarPara: Optional[str] = None
    cEnvBoleto: Optional[str] = None
    cEnvLink: Optional[str] = None

    @field_validator("cEnvBoleto", "cEnvLink")
    @classmethod
    def _validar_sim_nao(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and v not in _SIM_NAO:
            raise ValueError(f"Valor deve ser 'S' ou 'N', recebido: {v!r}")
        return v


class ObservacoesOs(BaseOmieModel):
    cObsOS: Optional[str] = None


class DepartamentoOs(BaseOmieModel):
    cCodDepto: Optional[str] = None
    nPerc: Optional[float] = None
    nValor: Optional[float] = None


class ParcelaOs(BaseOmieModel):
    nParcela: int
    dDtVenc: str
    nValor: float
    nPercentual: Optional[float] = None

    @field_validator("dDtVenc")
    @classmethod
    def _validar_data(cls, v: str) -> str:
        return validate_date(v)


# ── Param principal ───────────────────────────────────────────────


class OsCadastroParam(BaseOmieModel):
    Cabecalho: CabecalhoOs
    InformacoesAdicionais: Optional[InformacoesAdicionaisOs] = None
    Email: Optional[EmailOs] = None
    ServicosPrestados: list[ServicoPrestado]
    Departamentos: Optional[list[DepartamentoOs]] = None
    Parcelas: Optional[list[ParcelaOs]] = None
    Observacoes: Optional[ObservacoesOs] = None

    @field_validator("ServicosPrestados")
    @classmethod
    def _validar_servicos(cls, v: list[ServicoPrestado]) -> list[ServicoPrestado]:
        if not v:
            raise ValueError("ServicosPrestados deve ter ao menos 1 item")
        return v

    def to_omie_dict(self) -> dict:
        d: dict = {
            "Cabecalho": self.Cabecalho.to_omie_dict(),
            "ServicosPrestados": [s.to_omie_dict() for s in self.ServicosPrestados],
        }
        if self.InformacoesAdicionais is not None:
            d["InformacoesAdicionais"] = self.InformacoesAdicionais.to_omie_dict()
        if self.Email is not None:
            d["Email"] = self.Email.to_omie_dict()
        if self.Departamentos is not None:
            d["Departamentos"] = [dep.to_omie_dict() for dep in self.Departamentos]
        if self.Parcelas is not None:
            d["Parcelas"] = [p.to_omie_dict() for p in self.Parcelas]
        if self.Observacoes is not None:
            d["Observacoes"] = self.Observacoes.to_omie_dict()
        return d


# ── Excluir OS ────────────────────────────────────────────────────


class ExcluirOsParam(BaseOmieModel):
    nCodOS: Optional[int] = None
    cCodIntOS: Optional[str] = None
    cNumOS: Optional[str] = None

    @model_validator(mode="after")
    def _exige_um(self) -> ExcluirOsParam:
        if not self.nCodOS and not self.cCodIntOS and not self.cNumOS:
            raise ValueError("Informe nCodOS, cCodIntOS ou cNumOS")
        return self


# ── Trocar Etapa ──────────────────────────────────────────────────


class TrocarEtapaOsParam(BaseOmieModel):
    nCodOS: Optional[int] = None
    cCodIntOS: Optional[str] = None
    cNumOS: Optional[str] = None
    cEtapa: str

    @model_validator(mode="after")
    def _exige_um(self) -> TrocarEtapaOsParam:
        if not self.nCodOS and not self.cCodIntOS and not self.cNumOS:
            raise ValueError("Informe nCodOS, cCodIntOS ou cNumOS")
        return self

    @field_validator("cEtapa")
    @classmethod
    def _validar_etapa(cls, v: str) -> str:
        if v not in _ETAPAS_VALIDAS:
            raise ValueError(f"cEtapa deve ser uma de {_ETAPAS_VALIDAS}, recebido: {v!r}")
        return v


# ── Status OS ─────────────────────────────────────────────────────


class StatusOsParam(BaseOmieModel):
    nCodOS: Optional[int] = None
    cCodIntOS: Optional[str] = None

    @model_validator(mode="after")
    def _exige_um(self) -> StatusOsParam:
        if not self.nCodOS and not self.cCodIntOS:
            raise ValueError("Informe nCodOS ou cCodIntOS")
        return self


# ── Consultar / Listar (já existiam) ─────────────────────────────


class ConsultarOsParam(BaseOmieModel):
    nCodOS: Optional[int] = None
    cCodIntOS: Optional[str] = None
    cNumOS: Optional[str] = None

    @model_validator(mode="after")
    def _exige_um(self) -> ConsultarOsParam:
        if not self.nCodOS and not self.cCodIntOS and not self.cNumOS:
            raise ValueError("Informe nCodOS, cCodIntOS ou cNumOS")
        return self


class ListarOsParam(BaseOmieModel):
    pagina: int = 1
    registros_por_pagina: int = 50
    apenas_importado_api: Optional[str] = None
    filtrar_por_data_de: Optional[str] = None
    filtrar_por_data_ate: Optional[str] = None

    @field_validator(
        "filtrar_por_data_de",
        "filtrar_por_data_ate",
        mode="before",
    )
    @classmethod
    def _validar_datas(cls, v: Optional[str]) -> Optional[str]:
        return validate_date_optional(v)

    @field_validator("pagina", "registros_por_pagina")
    @classmethod
    def _validar_positivo(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"Deve ser >= 1, recebido: {v}")
        return v

    @field_validator("registros_por_pagina")
    @classmethod
    def _validar_limite(cls, v: int) -> int:
        if v > 100:
            raise ValueError("registros_por_pagina máximo é 100 (limite da Omie)")
        return v
