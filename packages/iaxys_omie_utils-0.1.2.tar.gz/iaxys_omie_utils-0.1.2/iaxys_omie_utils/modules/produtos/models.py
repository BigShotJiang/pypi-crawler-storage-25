from __future__ import annotations

from typing import Optional

from pydantic import field_validator, model_validator

from iaxys_omie_utils.base import BaseOmieModel
from iaxys_omie_utils.validators import validate_date_optional


class ProdutoParam(BaseOmieModel):
    codigo_produto_integracao: Optional[str] = None
    codigo_produto: Optional[int] = None
    codigo: Optional[str] = None
    descricao: str
    codigo_familia: Optional[str] = None
    unidade: Optional[str] = None
    ncm: Optional[str] = None
    ean: Optional[str] = None
    valor_unitario: Optional[float] = None
    quantidade_estoque: Optional[float] = None
    inativo: Optional[str] = None
    bloqueado: Optional[str] = None
    descricao_detalhada: Optional[str] = None
    codigo_categoria: Optional[str] = None
    peso_liq: Optional[float] = None
    peso_bruto: Optional[float] = None

    @field_validator("descricao")
    @classmethod
    def _validar_descricao(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("descricao não pode ser vazia")
        return v

    @field_validator("valor_unitario")
    @classmethod
    def _validar_valor(cls, v: Optional[float]) -> Optional[float]:
        if v is not None and v < 0:
            raise ValueError(f"valor_unitario não pode ser negativo, recebido: {v}")
        return v


class ConsultarProdutoParam(BaseOmieModel):
    codigo_produto_integracao: Optional[str] = None
    codigo_produto: Optional[int] = None

    @model_validator(mode="after")
    def _exige_um(self) -> ConsultarProdutoParam:
        if not self.codigo_produto_integracao and not self.codigo_produto:
            raise ValueError("Informe codigo_produto_integracao ou codigo_produto")
        return self


class ListarProdutosParam(BaseOmieModel):
    pagina: int = 1
    registros_por_pagina: int = 50
    apenas_importado_api: Optional[str] = None
    filtrar_por_data_de: Optional[str] = None
    filtrar_por_data_ate: Optional[str] = None
    inativo: Optional[str] = None
    bloqueado: Optional[str] = None

    @field_validator("filtrar_por_data_de", "filtrar_por_data_ate", mode="before")
    @classmethod
    def _validar_datas(cls, v: Optional[str]) -> Optional[str]:
        return validate_date_optional(v)

    @field_validator("pagina", "registros_por_pagina")
    @classmethod
    def _validar_positivo(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"Deve ser >= 1, recebido: {v}")
        return v

    @field_validator("registros_por_pagina")
    @classmethod
    def _validar_limite(cls, v: int) -> int:
        if v > 100:
            raise ValueError("registros_por_pagina máximo é 100 (limite da Omie)")
        return v
