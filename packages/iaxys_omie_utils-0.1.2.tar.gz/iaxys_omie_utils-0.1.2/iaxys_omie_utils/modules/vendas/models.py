from __future__ import annotations

from typing import Optional

from pydantic import field_validator, model_validator

from iaxys_omie_utils.base import BaseOmieModel
from iaxys_omie_utils.validators import validate_date, validate_date_optional

_ETAPAS_VALIDAS = {"00", "10", "20", "50", "60"}
_MODALIDADES_FRETE = {"0", "1", "2", "9"}
_SIM_NAO = {"S", "N"}


class CabecalhoPedido(BaseOmieModel):
    etapa: str
    codigo_parceiro: Optional[int] = None
    quantidade_itens: int

    @field_validator("etapa")
    @classmethod
    def _validar_etapa(cls, v: str) -> str:
        if v not in _ETAPAS_VALIDAS:
            raise ValueError(
                f"etapa deve ser uma de {_ETAPAS_VALIDAS}, recebido: {v!r}"
            )
        return v

    @field_validator("quantidade_itens")
    @classmethod
    def _validar_qtd(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"quantidade_itens deve ser >= 1, recebido: {v}")
        return v


class ProdutoItem(BaseOmieModel):
    codigo_produto: Optional[str] = None
    codigo_produto_integracao: Optional[str] = None
    quantidade: float
    valor_unitario: float
    codigo_categoria: Optional[str] = None
    tipo_desconto: Optional[str] = None
    percentual_desconto: Optional[float] = None
    valor_desconto: Optional[float] = None

    @field_validator("quantidade")
    @classmethod
    def _validar_quantidade(cls, v: float) -> float:
        if v <= 0:
            raise ValueError(f"quantidade deve ser > 0, recebido: {v}")
        return v

    @field_validator("valor_unitario")
    @classmethod
    def _validar_valor(cls, v: float) -> float:
        if v <= 0:
            raise ValueError(f"valor_unitario deve ser > 0, recebido: {v}")
        return v


class IdeItem(BaseOmieModel):
    codigo_item_integracao: str

    @field_validator("codigo_item_integracao")
    @classmethod
    def _validar_integracao(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("codigo_item_integracao não pode ser vazio")
        return v


class ItemPedido(BaseOmieModel):
    ide: IdeItem
    produto: ProdutoItem

    def to_omie_dict(self) -> dict:
        return {
            "ide": self.ide.to_omie_dict(),
            "produto": self.produto.to_omie_dict(),
        }


class FretePedido(BaseOmieModel):
    modalidade: str = "9"

    @field_validator("modalidade")
    @classmethod
    def _validar_modalidade(cls, v: str) -> str:
        if v not in _MODALIDADES_FRETE:
            raise ValueError(
                f"modalidade deve ser uma de {_MODALIDADES_FRETE}, recebido: {v!r}"
            )
        return v


class InformacoesAdicionais(BaseOmieModel):
    consumidor_final: Optional[str] = None
    enviar_email: Optional[str] = None
    codigo_parceiro: Optional[int] = None
    obs_venda: Optional[str] = None

    @field_validator("consumidor_final", "enviar_email")
    @classmethod
    def _validar_sim_nao(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and v not in _SIM_NAO:
            raise ValueError(f"Valor deve ser 'S' ou 'N', recebido: {v!r}")
        return v


class Parcela(BaseOmieModel):
    percentual: float
    valor: float
    data_vencimento: Optional[str] = None

    @field_validator("percentual")
    @classmethod
    def _validar_percentual(cls, v: float) -> float:
        if not (0 < v <= 100):
            raise ValueError(f"percentual deve estar em (0, 100], recebido: {v}")
        return v

    @field_validator("valor")
    @classmethod
    def _validar_valor(cls, v: float) -> float:
        if v <= 0:
            raise ValueError(f"valor deve ser > 0, recebido: {v}")
        return v

    @field_validator("data_vencimento", mode="before")
    @classmethod
    def _validar_data(cls, v: Optional[str]) -> Optional[str]:
        return validate_date_optional(v)


class PedidoVendaParam(BaseOmieModel):
    cabecalho: CabecalhoPedido
    det: list[ItemPedido]
    frete: Optional[FretePedido] = None
    informacoes_adicionais: Optional[InformacoesAdicionais] = None
    parcelas: Optional[list[Parcela]] = None

    @model_validator(mode="after")
    def _validar_pedido(self) -> PedidoVendaParam:
        if len(self.det) != self.cabecalho.quantidade_itens:
            raise ValueError(
                f"quantidade_itens={self.cabecalho.quantidade_itens} "
                f"mas det tem {len(self.det)} item(ns)"
            )
        if self.parcelas:
            total = sum(p.percentual for p in self.parcelas)
            if abs(total - 100.0) > 0.01:
                raise ValueError(
                    f"Soma dos percentuais das parcelas deve ser 100%, recebido: {total:.4f}%"
                )
        return self

    def to_omie_dict(self) -> dict:
        d: dict = {
            "cabecalho": self.cabecalho.to_omie_dict(),
            "det": [item.to_omie_dict() for item in self.det],
        }

        if self.frete is not None:
            d["frete"] = self.frete.to_omie_dict()

        if self.informacoes_adicionais is not None:
            d["informacoes_adicionais"] = self.informacoes_adicionais.to_omie_dict()

        if self.parcelas is not None:
            d["parcelas"] = [p.to_omie_dict() for p in self.parcelas]

        return d


class ConsultarPedidoParam(BaseOmieModel):
    codigo_pedido_integracao: Optional[str] = None
    codigo_pedido: Optional[int] = None

    @model_validator(mode="after")
    def _exige_um(self) -> ConsultarPedidoParam:
        if not self.codigo_pedido_integracao and not self.codigo_pedido:
            raise ValueError("Informe codigo_pedido_integracao ou codigo_pedido")
        return self


class ListarPedidosParam(BaseOmieModel):
    pagina: int = 1
    registros_por_pagina: int = 50
    apenas_importado_api: Optional[str] = None
    etapa: Optional[str] = None
    filtrar_por_data_de: Optional[str] = None
    filtrar_por_data_ate: Optional[str] = None

    @field_validator(
        "filtrar_por_data_de",
        "filtrar_por_data_ate",
        mode="before",
    )
    @classmethod
    def _validar_datas(cls, v: Optional[str]) -> Optional[str]:
        return validate_date_optional(v)

    @field_validator("pagina", "registros_por_pagina")
    @classmethod
    def _validar_positivo(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"Deve ser >= 1, recebido: {v}")
        return v

    @field_validator("registros_por_pagina")
    @classmethod
    def _validar_limite(cls, v: int) -> int:
        if v > 100:
            raise ValueError("registros_por_pagina máximo é 100 (limite da Omie)")
        return v
