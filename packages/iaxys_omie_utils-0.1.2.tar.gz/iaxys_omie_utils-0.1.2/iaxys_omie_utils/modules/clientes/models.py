from __future__ import annotations

from typing import Optional

from pydantic import field_validator, model_validator

from iaxys_omie_utils.base import BaseOmieModel
from iaxys_omie_utils.validators import validate_date_optional

_PESSOA_FISICA_JURIDICA = {"F", "J"}


class ClienteParam(BaseOmieModel):
    codigo_cliente_integracao: Optional[str] = None
    codigo_cliente_omie:       Optional[int] = None
    razao_social:              str
    cnpj_cpf:                  str
    email:                     Optional[str] = None
    telefone1_ddd:             Optional[str] = None
    telefone1_numero:          Optional[str] = None
    contato:                   Optional[str] = None
    endereco:                  Optional[str] = None
    endereco_numero:           Optional[str] = None
    bairro:                    Optional[str] = None
    complemento:               Optional[str] = None
    estado:                    Optional[str] = None
    cidade:                    Optional[str] = None
    cep:                       Optional[str] = None
    codigo_pais:               Optional[str] = None
    pessoa_fisica:             Optional[str] = None
    inativo:                   Optional[str] = None
    produtor_rural:            Optional[str] = None
    contribuinte:              Optional[str] = None
    optante_simples_nacional:  Optional[str] = None
    observacao:                Optional[str] = None

    @field_validator("razao_social")
    @classmethod
    def _validar_razao(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("razao_social não pode ser vazio")
        return v

    @field_validator("cnpj_cpf")
    @classmethod
    def _validar_cnpj_cpf(cls, v: str) -> str:
        digits = "".join(c for c in v if c.isdigit())
        if len(digits) not in (11, 14):
            raise ValueError(
                f"cnpj_cpf deve ter 11 (CPF) ou 14 (CNPJ) dígitos, recebido: {v!r}"
            )
        return v


class UpsertClienteParam(BaseOmieModel):
    codigo_cliente_integracao: str
    razao_social:              str
    cnpj_cpf:                  str
    email:                     Optional[str] = None
    telefone1_ddd:             Optional[str] = None
    telefone1_numero:          Optional[str] = None
    contato:                   Optional[str] = None
    endereco:                  Optional[str] = None
    endereco_numero:           Optional[str] = None
    bairro:                    Optional[str] = None
    complemento:               Optional[str] = None
    estado:                    Optional[str] = None
    cidade:                    Optional[str] = None
    cep:                       Optional[str] = None
    codigo_pais:               Optional[str] = None
    pessoa_fisica:             Optional[str] = None
    inativo:                   Optional[str] = None
    observacao:                Optional[str] = None

    @field_validator("codigo_cliente_integracao")
    @classmethod
    def _validar_integracao(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("codigo_cliente_integracao não pode ser vazio")
        return v

    @field_validator("razao_social")
    @classmethod
    def _validar_razao(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("razao_social não pode ser vazio")
        return v

    @field_validator("cnpj_cpf")
    @classmethod
    def _validar_cnpj_cpf(cls, v: str) -> str:
        digits = "".join(c for c in v if c.isdigit())
        if len(digits) not in (11, 14):
            raise ValueError(
                f"cnpj_cpf deve ter 11 (CPF) ou 14 (CNPJ) dígitos, recebido: {v!r}"
            )
        return v


class ConsultarClienteParam(BaseOmieModel):
    codigo_cliente_integracao: Optional[str] = None
    codigo_cliente_omie:       Optional[int] = None

    @model_validator(mode="after")
    def _exige_um(self) -> ConsultarClienteParam:
        if not self.codigo_cliente_integracao and not self.codigo_cliente_omie:
            raise ValueError(
                "Informe codigo_cliente_integracao ou codigo_cliente_omie"
            )
        return self


class ListarClientesParam(BaseOmieModel):
    pagina:               int = 1
    registros_por_pagina: int = 50
    apenas_importado_api: Optional[str] = None
    filtrar_por_data_de:  Optional[str] = None
    filtrar_por_data_ate: Optional[str] = None
    inativo:              Optional[str] = None

    @field_validator("filtrar_por_data_de", "filtrar_por_data_ate", mode="before")
    @classmethod
    def _validar_datas(cls, v: Optional[str]) -> Optional[str]:
        return validate_date_optional(v)

    @field_validator("pagina", "registros_por_pagina")
    @classmethod
    def _validar_positivo(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"Deve ser >= 1, recebido: {v}")
        return v

    @field_validator("registros_por_pagina")
    @classmethod
    def _validar_limite(cls, v: int) -> int:
        if v > 100:
            raise ValueError("registros_por_pagina máximo é 100 (limite da Omie)")
        return v
