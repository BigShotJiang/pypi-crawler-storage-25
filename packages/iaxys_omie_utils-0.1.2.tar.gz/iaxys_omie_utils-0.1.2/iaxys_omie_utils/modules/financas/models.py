from __future__ import annotations

from typing import Optional

from pydantic import field_validator, model_validator

from iaxys_omie_utils.base import BaseOmieModel
from iaxys_omie_utils.validators import validate_date, validate_date_optional


class _OmieFinancaBase(BaseOmieModel):
    codigo_lancamento_integracao: str
    codigo_cliente_fornecedor:    int
    data_vencimento:              str
    valor_documento:              float
    codigo_categoria:             str
    data_previsao:                str
    id_conta_corrente:            str
    data_emissao:                 str
    observacao:                   str = ""

    @field_validator("data_vencimento", "data_previsao", "data_emissao")
    @classmethod
    def _validar_data(cls, v: str) -> str:
        return validate_date(v)

    @field_validator("valor_documento")
    @classmethod
    def _validar_valor(cls, v: float) -> float:
        if v <= 0:
            raise ValueError(f"valor_documento deve ser positivo, recebido: {v}")
        return v

    @field_validator("codigo_lancamento_integracao")
    @classmethod
    def _validar_integracao(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("codigo_lancamento_integracao não pode ser vazio")
        return v


class ContaReceberParam(_OmieFinancaBase):
    nsu:                     str          = ""
    codigo_lancamento_omie:  Optional[int] = None


class ConsultarContaReceberParam(BaseOmieModel):
    codigo_lancamento_integracao: Optional[str] = None
    codigo_lancamento_omie:       Optional[int] = None

    @model_validator(mode="after")
    def _exige_um(self) -> ConsultarContaReceberParam:
        if not self.codigo_lancamento_integracao and not self.codigo_lancamento_omie:
            raise ValueError(
                "Informe codigo_lancamento_integracao ou codigo_lancamento_omie"
            )
        return self


class ListarContasReceberParam(BaseOmieModel):
    pagina:               int = 1
    registros_por_pagina: int = 50

    data_vencimento_de:  Optional[str] = None
    data_vencimento_ate: Optional[str] = None
    data_emissao_de:     Optional[str] = None
    data_emissao_ate:    Optional[str] = None
    codigo_cliente:      Optional[int] = None
    status_titulo:       Optional[str] = None

    @field_validator(
        "data_vencimento_de",
        "data_vencimento_ate",
        "data_emissao_de",
        "data_emissao_ate",
        mode="before",
    )
    @classmethod
    def _validar_datas_filtro(cls, v: Optional[str]) -> Optional[str]:
        return validate_date_optional(v)

    @field_validator("pagina", "registros_por_pagina")
    @classmethod
    def _validar_positivo(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"Deve ser >= 1, recebido: {v}")
        return v

    @field_validator("registros_por_pagina")
    @classmethod
    def _validar_limite(cls, v: int) -> int:
        if v > 100:
            raise ValueError("registros_por_pagina máximo é 100 (limite da Omie)")
        return v


class ContaPagarParam(_OmieFinancaBase):
    codigo_lancamento_omie: Optional[int] = None


class ConsultarContaPagarParam(BaseOmieModel):
    codigo_lancamento_integracao: Optional[str] = None
    codigo_lancamento_omie:       Optional[int] = None

    @model_validator(mode="after")
    def _exige_um(self) -> ConsultarContaPagarParam:
        if not self.codigo_lancamento_integracao and not self.codigo_lancamento_omie:
            raise ValueError(
                "Informe codigo_lancamento_integracao ou codigo_lancamento_omie"
            )
        return self


class ListarContasPagarParam(BaseOmieModel):
    pagina:               int = 1
    registros_por_pagina: int = 50

    data_vencimento_de:  Optional[str] = None
    data_vencimento_ate: Optional[str] = None
    data_emissao_de:     Optional[str] = None
    data_emissao_ate:    Optional[str] = None
    codigo_fornecedor:   Optional[int] = None
    status_titulo:       Optional[str] = None

    @field_validator(
        "data_vencimento_de",
        "data_vencimento_ate",
        "data_emissao_de",
        "data_emissao_ate",
        mode="before",
    )
    @classmethod
    def _validar_datas_filtro(cls, v: Optional[str]) -> Optional[str]:
        return validate_date_optional(v)

    @field_validator("pagina", "registros_por_pagina")
    @classmethod
    def _validar_positivo(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"Deve ser >= 1, recebido: {v}")
        return v

    @field_validator("registros_por_pagina")
    @classmethod
    def _validar_limite(cls, v: int) -> int:
        if v > 100:
            raise ValueError("registros_por_pagina máximo é 100 (limite da Omie)")
        return v
