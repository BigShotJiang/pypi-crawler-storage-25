from __future__ import annotations

from typing import Optional

from iaxys_omie_utils.base import _BaseContext
from iaxys_omie_utils.http import TimeoutConfig, TimeoutOverride, TimeRangeConfig, TimeRangeOverride
from iaxys_omie_utils.retry import RetryConfig, RetryOverride
from iaxys_omie_utils.modules.conta_receber.models import (
    CancelarRecebimentoParam,
    ConciliarRecebimentoParam,
    ConsultarContaReceberParam,
    ContaReceberCadastroParam,
    ContaReceberChaveParam,
    ContaReceberLoteParam,
    LancarRecebimentoParam,
    ListarContasReceberParam,
    RateioCadastroParam,
)

_PATH = "financas/contareceber"


class OmieContaReceber(_BaseContext):
    def __init__(
        self,
        app_key: str,
        app_secret: str,
        *,
        retry:      Optional[RetryConfig]     = None,
        timeout:    Optional[TimeoutConfig]   = None,
        time_range: Optional[TimeRangeConfig] = None,
    ) -> None:
        super().__init__(app_key, app_secret, retry=retry, timeout=timeout, time_range=time_range)

    # --- CRUD unitário ---

    def incluir(
        self, param: ContaReceberCadastroParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "IncluirContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aincluir(
        self, param: ContaReceberCadastroParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "IncluirContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def alterar(
        self, param: ContaReceberCadastroParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "AlterarContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aalterar(
        self, param: ContaReceberCadastroParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "AlterarContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def upsert(
        self, param: ContaReceberCadastroParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "UpsertContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aupsert(
        self, param: ContaReceberCadastroParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "UpsertContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def consultar(
        self, param: ConsultarContaReceberParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "ConsultarContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aconsultar(
        self, param: ConsultarContaReceberParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "ConsultarContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def listar(
        self, param: Optional[ListarContasReceberParam] = None, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        p = param or ListarContasReceberParam()
        return self._http.post(
            _PATH, "ListarContasReceber", [p.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def alistar(
        self, param: Optional[ListarContasReceberParam] = None, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        p = param or ListarContasReceberParam()
        return await self._http.apost(
            _PATH, "ListarContasReceber", [p.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def excluir(
        self, param: ContaReceberChaveParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "ExcluirContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aexcluir(
        self, param: ContaReceberChaveParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "ExcluirContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def cancelar(
        self, param: ContaReceberChaveParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "CancelarContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def acancelar(
        self, param: ContaReceberChaveParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "CancelarContaReceber", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    # --- Lote ---

    def incluir_por_lote(
        self, param: ContaReceberLoteParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "IncluirContaReceberPorLote", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aincluir_por_lote(
        self, param: ContaReceberLoteParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "IncluirContaReceberPorLote", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def upsert_por_lote(
        self, param: ContaReceberLoteParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "UpsertContaReceberPorLote", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aupsert_por_lote(
        self, param: ContaReceberLoteParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "UpsertContaReceberPorLote", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    # --- Recebimento (baixa) ---

    def lancar_recebimento(
        self, param: LancarRecebimentoParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "LancarRecebimento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def alancar_recebimento(
        self, param: LancarRecebimentoParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "LancarRecebimento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def cancelar_recebimento(
        self, param: CancelarRecebimentoParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "CancelarRecebimento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def acancelar_recebimento(
        self, param: CancelarRecebimentoParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "CancelarRecebimento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    # --- Conciliação ---

    def conciliar_recebimento(
        self, param: ConciliarRecebimentoParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "ConciliarRecebimento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aconciliar_recebimento(
        self, param: ConciliarRecebimentoParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "ConciliarRecebimento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def desconciliar_recebimento(
        self, param: ConciliarRecebimentoParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "DesconciliarRecebimento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def adesconciliar_recebimento(
        self, param: ConciliarRecebimentoParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "DesconciliarRecebimento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    # --- Distribuição por Departamento ---

    def incluir_distribuicao(
        self, param: RateioCadastroParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "IncluirDistribuicaoDepartamento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aincluir_distribuicao(
        self, param: RateioCadastroParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "IncluirDistribuicaoDepartamento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def alterar_distribuicao(
        self, param: RateioCadastroParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "AlterarDistribuicaoDepartamento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aalterar_distribuicao(
        self, param: RateioCadastroParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "AlterarDistribuicaoDepartamento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    def excluir_distribuicao(
        self, param: ContaReceberChaveParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return self._http.post(
            _PATH, "ExcluirDistribuicaoDepartamento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )

    async def aexcluir_distribuicao(
        self, param: ContaReceberChaveParam, *,
        retry: Optional[RetryOverride] = None,
        timeout: Optional[TimeoutOverride] = None,
        time_range: Optional[TimeRangeOverride] = None,
    ) -> dict:
        return await self._http.apost(
            _PATH, "ExcluirDistribuicaoDepartamento", [param.to_omie_dict()],
            retry=retry, timeout=timeout, time_range=time_range,
        )
