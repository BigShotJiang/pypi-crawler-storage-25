from __future__ import annotations

from typing import Optional

from pydantic import field_validator, model_validator

from iaxys_omie_utils.base import BaseOmieModel
from iaxys_omie_utils.validators import validate_date, validate_date_optional


# ---------------------------------------------------------------------------
# Inclusão / Alteração / Upsert
# ---------------------------------------------------------------------------

class ContaReceberCadastroParam(BaseOmieModel):
    codigo_lancamento_integracao:         str
    codigo_cliente_fornecedor:            int
    data_vencimento:                      str
    valor_documento:                      float
    codigo_categoria:                     str
    data_previsao:                        str
    id_conta_corrente:                    str
    data_emissao:                         str
    observacao:                           str           = ""
    nsu:                                  str           = ""
    codigo_lancamento_omie:               Optional[int] = None
    codigo_cliente_fornecedor_integracao: Optional[str] = None
    numero_documento:                     Optional[str] = None
    numero_parcela:                       Optional[str] = None
    codigo_tipo_documento:                Optional[str] = None
    numero_documento_fiscal:              Optional[str] = None
    numero_pedido:                        Optional[str] = None
    chave_nfe:                            Optional[str] = None
    codigo_barras_ficha_compensacao:      Optional[str] = None
    codigo_cmc7_cheque:                   Optional[str] = None
    id_origem:                            Optional[str] = None
    operacao:                             Optional[str] = None
    valor_pis:                            Optional[float] = None
    retem_pis:                            Optional[str] = None
    valor_cofins:                         Optional[float] = None
    retem_cofins:                         Optional[str] = None
    valor_csll:                           Optional[float] = None
    retem_csll:                           Optional[str] = None
    valor_ir:                             Optional[float] = None
    retem_ir:                             Optional[str] = None
    valor_iss:                            Optional[float] = None
    retem_iss:                            Optional[str] = None
    valor_inss:                           Optional[float] = None
    retem_inss:                           Optional[str] = None
    bloqueado:                            Optional[str] = None
    bloquear_baixa:                       Optional[str] = None
    baixar_documento:                     Optional[str] = None
    conciliar_documento:                  Optional[str] = None
    acao:                                 Optional[str] = None
    codigo_vendedor:                      Optional[int] = None
    codigo_projeto:                       Optional[int] = None
    data_registro:                        Optional[str] = None
    nCodPedido:                           Optional[int] = None
    bloquear_exclusao:                    Optional[str] = None
    nCodOS:                               Optional[int] = None
    cPedidoCliente:                       Optional[str] = None
    cNumeroContrato:                      Optional[str] = None
    aprendizado_rateio:                   Optional[str] = None

    @field_validator("data_vencimento", "data_previsao", "data_emissao")
    @classmethod
    def _validar_data(cls, v: str) -> str:
        return validate_date(v)

    @field_validator("data_registro", mode="before")
    @classmethod
    def _validar_data_registro(cls, v: Optional[str]) -> Optional[str]:
        return validate_date_optional(v)

    @field_validator("valor_documento")
    @classmethod
    def _validar_valor(cls, v: float) -> float:
        if v <= 0:
            raise ValueError(f"valor_documento deve ser positivo, recebido: {v}")
        return v

    @field_validator("codigo_lancamento_integracao")
    @classmethod
    def _validar_integracao(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("codigo_lancamento_integracao não pode ser vazio")
        return v


# ---------------------------------------------------------------------------
# Consultar
# ---------------------------------------------------------------------------

class ConsultarContaReceberParam(BaseOmieModel):
    codigo_lancamento_omie:       Optional[int] = None
    codigo_lancamento_integracao: Optional[str] = None

    @model_validator(mode="after")
    def _exige_um(self) -> ConsultarContaReceberParam:
        if not self.codigo_lancamento_integracao and not self.codigo_lancamento_omie:
            raise ValueError(
                "Informe codigo_lancamento_integracao ou codigo_lancamento_omie"
            )
        return self


# ---------------------------------------------------------------------------
# Listar
# ---------------------------------------------------------------------------

class ListarContasReceberParam(BaseOmieModel):
    pagina:               int = 1
    registros_por_pagina: int = 50

    apenas_importado_api:            Optional[str] = None
    ordenar_por:                     Optional[str] = None
    ordem_descrescente:              Optional[str] = None
    filtrar_por_data_de:             Optional[str] = None
    filtrar_por_data_ate:            Optional[str] = None
    filtrar_apenas_inclusao:         Optional[str] = None
    filtrar_apenas_alteracao:        Optional[str] = None
    filtrar_por_emissao_de:          Optional[str] = None
    filtrar_por_emissao_ate:         Optional[str] = None
    filtrar_por_registro_de:         Optional[str] = None
    filtrar_por_registro_ate:        Optional[str] = None
    filtrar_conta_corrente:          Optional[int] = None
    filtrar_apenas_titulos_em_aberto: Optional[str] = None
    filtrar_cliente:                 Optional[int] = None
    filtrar_por_status:              Optional[str] = None
    filtrar_por_cpf_cnpj:            Optional[str] = None
    filtrar_por_projeto:             Optional[int] = None
    filtrar_por_vendedor:            Optional[int] = None
    exibir_obs:                      Optional[str] = None

    @field_validator(
        "filtrar_por_data_de", "filtrar_por_data_ate",
        "filtrar_por_emissao_de", "filtrar_por_emissao_ate",
        "filtrar_por_registro_de", "filtrar_por_registro_ate",
        mode="before",
    )
    @classmethod
    def _validar_datas(cls, v: Optional[str]) -> Optional[str]:
        return validate_date_optional(v)

    @field_validator("pagina", "registros_por_pagina")
    @classmethod
    def _validar_positivo(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"Deve ser >= 1, recebido: {v}")
        return v

    @field_validator("registros_por_pagina")
    @classmethod
    def _validar_limite(cls, v: int) -> int:
        if v > 100:
            raise ValueError("registros_por_pagina máximo é 100 (limite da Omie)")
        return v


# ---------------------------------------------------------------------------
# Excluir / Cancelar boleto
# ---------------------------------------------------------------------------

class ContaReceberChaveParam(BaseOmieModel):
    chave_lancamento:             Optional[int] = None
    codigo_lancamento_integracao: Optional[str] = None

    @model_validator(mode="after")
    def _exige_um(self) -> ContaReceberChaveParam:
        if not self.chave_lancamento and not self.codigo_lancamento_integracao:
            raise ValueError(
                "Informe chave_lancamento ou codigo_lancamento_integracao"
            )
        return self


# ---------------------------------------------------------------------------
# Lote (Incluir / Upsert por lote)
# ---------------------------------------------------------------------------

class ContaReceberLoteParam(BaseOmieModel):
    lote:                   int
    conta_receber_cadastro: list[ContaReceberCadastroParam]


# ---------------------------------------------------------------------------
# Lançar Recebimento (baixa)
# ---------------------------------------------------------------------------

class LancarRecebimentoParam(BaseOmieModel):
    codigo_lancamento:                Optional[int]   = None
    codigo_lancamento_integracao:     Optional[str]   = None
    codigo_baixa:                     Optional[int]   = None
    codigo_baixa_integracao:          Optional[str]   = None
    codigo_conta_corrente:            Optional[int]   = None
    codigo_conta_corrente_integracao: Optional[str]   = None
    valor:                            Optional[float] = None
    juros:                            Optional[float] = None
    desconto:                         Optional[float] = None
    multa:                            Optional[float] = None
    data:                             Optional[str]   = None
    observacao:                       str             = ""
    bloqueado:                        Optional[str]   = None
    conciliar_documento:              Optional[str]   = None
    nsu:                              Optional[str]   = None

    @field_validator("data", mode="before")
    @classmethod
    def _validar_data(cls, v: Optional[str]) -> Optional[str]:
        return validate_date_optional(v)


# ---------------------------------------------------------------------------
# Cancelar Recebimento
# ---------------------------------------------------------------------------

class CancelarRecebimentoParam(BaseOmieModel):
    codigo_baixa:             Optional[int] = None
    codigo_baixa_integracao:  Optional[str] = None

    @model_validator(mode="after")
    def _exige_um(self) -> CancelarRecebimentoParam:
        if not self.codigo_baixa and not self.codigo_baixa_integracao:
            raise ValueError("Informe codigo_baixa ou codigo_baixa_integracao")
        return self


# ---------------------------------------------------------------------------
# Conciliar / Desconciliar Recebimento
# ---------------------------------------------------------------------------

class ConciliarRecebimentoParam(BaseOmieModel):
    codigo_baixa:             Optional[int] = None
    codigo_baixa_integracao:  Optional[str] = None

    @model_validator(mode="after")
    def _exige_um(self) -> ConciliarRecebimentoParam:
        if not self.codigo_baixa and not self.codigo_baixa_integracao:
            raise ValueError("Informe codigo_baixa ou codigo_baixa_integracao")
        return self


# ---------------------------------------------------------------------------
# Distribuição por Departamento
# ---------------------------------------------------------------------------

class RateioCadastroParam(BaseOmieModel):
    chave_lancamento:          Optional[int]   = None
    codigo_departamento:       Optional[str]   = None
    percentual_rateio:         Optional[float] = None
    valor:                     Optional[float] = None
    valor_fixado:              Optional[str]   = None
    codigo_tipo_credito:       Optional[str]   = None
    conta_financeira:          Optional[str]   = None
    codigo_base_calculo:       Optional[str]   = None
    cst_cofins:                Optional[int]   = None
    cst_pis:                   Optional[int]   = None
    job:                       Optional[str]   = None
    codigo_contribuicao_social: Optional[str]  = None
