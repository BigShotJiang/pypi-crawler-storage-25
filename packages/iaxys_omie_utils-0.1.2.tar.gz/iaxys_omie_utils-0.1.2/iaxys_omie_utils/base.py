from __future__ import annotations

from typing import Optional

from pydantic import BaseModel

from iaxys_omie_utils.http import OmieHttp, TimeoutConfig, TimeRangeConfig
from iaxys_omie_utils.retry import RetryConfig


class BaseOmieModel(BaseModel):
    model_config = {"frozen": True, "coerce_numbers_to_str": True}

    def to_omie_dict(self) -> dict:
        return self.model_dump(exclude_none=True)


class _BaseContext:
    def __init__(
        self,
        app_key: str,
        app_secret: str,
        *,
        retry: Optional[RetryConfig] = None,
        timeout: Optional[TimeoutConfig] = None,
        time_range: Optional[TimeRangeConfig] = None,
    ) -> None:
        self._http = OmieHttp(
            app_key,
            app_secret,
            retry=retry if retry is not None else RetryConfig(),
            timeout=timeout if timeout is not None else TimeoutConfig(),
            time_range=time_range if time_range is not None else TimeRangeConfig(),
        )
