from __future__ import annotations

from typing import Optional

# Core
from iaxys_omie_utils.http import TimeoutConfig, TimeRangeConfig
from iaxys_omie_utils.retry import RetryConfig

# Modules
from iaxys_omie_utils.modules.financas import OmieFinancas
from iaxys_omie_utils.modules.vendas import OmieVendas
from iaxys_omie_utils.modules.clientes import OmieClientes
from iaxys_omie_utils.modules.produtos import OmieProdutos
from iaxys_omie_utils.modules.servicos import OmieServicos
from iaxys_omie_utils.modules.conta_receber import OmieContaReceber

__version__ = "0.1.0"


class Omie:
    def __init__(
        self,
        app_key: str,
        app_secret: str,
        *,
        retry: Optional[RetryConfig] = None,
        timeout: Optional[TimeoutConfig] = None,
        time_range: Optional[TimeRangeConfig] = None,
    ) -> None:
        _retry = retry if retry is not None else RetryConfig()
        _timeout = timeout if timeout is not None else TimeoutConfig()
        _time_range = time_range if time_range is not None else TimeRangeConfig()

        self.financas = OmieFinancas(
            app_key,
            app_secret,
            retry=_retry,
            timeout=_timeout,
            time_range=_time_range,
        )
        self.vendas = OmieVendas(
            app_key,
            app_secret,
            retry=_retry,
            timeout=_timeout,
            time_range=_time_range,
        )
        self.clientes = OmieClientes(
            app_key,
            app_secret,
            retry=_retry,
            timeout=_timeout,
            time_range=_time_range,
        )
        self.produtos = OmieProdutos(
            app_key,
            app_secret,
            retry=_retry,
            timeout=_timeout,
            time_range=_time_range,
        )
        self.servicos = OmieServicos(
            app_key,
            app_secret,
            retry=_retry,
            timeout=_timeout,
            time_range=_time_range,
        )
        self.conta_receber = OmieContaReceber(
            app_key,
            app_secret,
            retry=_retry,
            timeout=_timeout,
            time_range=_time_range,
        )


__all__ = ["Omie"]
