import unittest
import sys

sys.path.insert(0, ".")

from iaxys_omie_utils.modules.financas import OmieFinancas
from iaxys_omie_utils.modules.financas.models import (
    ContaReceberParam,
    ConsultarContaReceberParam,
    ListarContasReceberParam,
    ContaPagarParam,
    ConsultarContaPagarParam,
    ListarContasPagarParam,
)
from iaxys_omie_utils.modules.clientes import OmieClientes
from iaxys_omie_utils.modules.clientes.models import ListarClientesParam
from iaxys_omie_utils.errors import OmieDuplicateError


class TestOmieFinancasRealHTTP(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from conftest import get_omie_credentials
        cls.app_key, cls.app_secret = get_omie_credentials()
        cls.client = OmieFinancas(app_key=cls.app_key, app_secret=cls.app_secret)

        # Busca cliente e conta corrente reais
        clientes = OmieClientes(app_key=cls.app_key, app_secret=cls.app_secret)
        resp = clientes.listar_clientes(ListarClientesParam(pagina=1, registros_por_pagina=1))
        lista = resp.get("clientes_cadastro", [])
        cls.codigo_cliente = lista[0]["codigo_cliente_omie"] if lista else None

        from iaxys_omie_utils.http import OmieHttp
        h = OmieHttp(cls.app_key, cls.app_secret)
        resp_cc = h.post("geral/contacorrente", "ListarContasCorrentes", [{"pagina": 1, "registros_por_pagina": 1}])
        cc_list = resp_cc.get("ListarContasCorrentes", [])
        cls.id_conta_corrente = str(cc_list[0]["nCodCC"]) if cc_list else None

    # ── Contas a Receber ──────────────────────────────────────────────

    def test_listar_contas_receber_pagination(self):
        param = ListarContasReceberParam(pagina=1, registros_por_pagina=10)
        response = self.client.listar_contas_receber(param)

        self.assertIn("pagina", response)
        self.assertIn("total_de_paginas", response)
        self.assertIn("registros", response)
        self.assertIn("total_de_registros", response)
        self.assertIn("conta_receber_cadastro", response)

    def test_listar_contas_receber_default(self):
        response = self.client.listar_contas_receber()
        self.assertIn("pagina", response)
        self.assertIn("conta_receber_cadastro", response)

    def test_incluir_consultar_conta_receber(self):
        if not self.codigo_cliente or not self.id_conta_corrente:
            self.skipTest("Sem cliente ou conta corrente cadastrados")

        integracao = "sdk-test-receber-001"
        param = ContaReceberParam(
            codigo_lancamento_integracao=integracao,
            codigo_cliente_fornecedor=self.codigo_cliente,
            data_vencimento="31/12/2025",
            valor_documento=1500.00,
            codigo_categoria="1.01.02",
            data_previsao="31/12/2025",
            id_conta_corrente=self.id_conta_corrente,
            data_emissao="01/01/2025",
        )

        try:
            resp = self.client.incluir_conta_receber(param)
        except OmieDuplicateError:
            # Já existe — consulta pelo código de integração
            consulta = self.client.consultar_conta_receber(
                ConsultarContaReceberParam(codigo_lancamento_integracao=integracao)
            )
        else:
            self.assertIn("codigo_lancamento_omie", resp)
            consulta = self.client.consultar_conta_receber(
                ConsultarContaReceberParam(codigo_lancamento_omie=resp["codigo_lancamento_omie"])
            )

        self.assertIn("codigo_lancamento_omie", consulta)

    def test_consultar_conta_receber_da_listagem(self):
        listagem = self.client.listar_contas_receber(
            ListarContasReceberParam(pagina=1, registros_por_pagina=1)
        )
        contas = listagem.get("conta_receber_cadastro", [])
        if not contas:
            self.skipTest("Nenhuma conta a receber cadastrada")

        codigo_omie = contas[0]["codigo_lancamento_omie"]
        consulta = self.client.consultar_conta_receber(
            ConsultarContaReceberParam(codigo_lancamento_omie=codigo_omie)
        )
        self.assertEqual(consulta["codigo_lancamento_omie"], codigo_omie)

    # ── Contas a Pagar ────────────────────────────────────────────────

    def test_listar_contas_pagar_pagination(self):
        param = ListarContasPagarParam(pagina=1, registros_por_pagina=10)
        response = self.client.listar_contas_pagar(param)

        self.assertIn("pagina", response)
        self.assertIn("total_de_paginas", response)
        self.assertIn("registros", response)
        self.assertIn("total_de_registros", response)
        self.assertIn("conta_pagar_cadastro", response)

    def test_listar_contas_pagar_default(self):
        response = self.client.listar_contas_pagar()
        self.assertIn("pagina", response)
        self.assertIn("conta_pagar_cadastro", response)

    def test_incluir_consultar_conta_pagar(self):
        if not self.codigo_cliente or not self.id_conta_corrente:
            self.skipTest("Sem cliente ou conta corrente cadastrados")

        integracao = "sdk-test-pagar-001"
        param = ContaPagarParam(
            codigo_lancamento_integracao=integracao,
            codigo_cliente_fornecedor=self.codigo_cliente,
            data_vencimento="31/12/2025",
            valor_documento=800.00,
            codigo_categoria="2.01.01",
            data_previsao="31/12/2025",
            id_conta_corrente=self.id_conta_corrente,
            data_emissao="01/01/2025",
        )

        try:
            resp = self.client.incluir_conta_pagar(param)
        except OmieDuplicateError:
            consulta = self.client.consultar_conta_pagar(
                ConsultarContaPagarParam(codigo_lancamento_integracao=integracao)
            )
        else:
            self.assertIn("codigo_lancamento_omie", resp)
            consulta = self.client.consultar_conta_pagar(
                ConsultarContaPagarParam(codigo_lancamento_omie=resp["codigo_lancamento_omie"])
            )

        self.assertIn("codigo_lancamento_omie", consulta)

    def test_consultar_conta_pagar_da_listagem(self):
        listagem = self.client.listar_contas_pagar(
            ListarContasPagarParam(pagina=1, registros_por_pagina=1)
        )
        contas = listagem.get("conta_pagar_cadastro", [])
        if not contas:
            self.skipTest("Nenhuma conta a pagar cadastrada")

        codigo_omie = contas[0]["codigo_lancamento_omie"]
        consulta = self.client.consultar_conta_pagar(
            ConsultarContaPagarParam(codigo_lancamento_omie=codigo_omie)
        )
        self.assertEqual(consulta["codigo_lancamento_omie"], codigo_omie)


if __name__ == "__main__":
    unittest.main()
