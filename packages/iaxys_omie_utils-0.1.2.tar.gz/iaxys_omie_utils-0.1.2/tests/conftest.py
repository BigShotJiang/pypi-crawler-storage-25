"""Shared test data for unittest test suite."""

import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")


def get_omie_credentials():
    """Returns (app_key, app_secret) from env or raises SkipTest."""
    key = os.getenv("OMIE_APP_KEY")
    secret = os.getenv("OMIE_APP_SECRET")
    if not key or not secret:
        import unittest
        raise unittest.SkipTest("OMIE_APP_KEY / OMIE_APP_SECRET não definidos")
    return key, secret


def get_valid_cliente_data():
    """Returns valid data for ClienteParam."""
    return {
        'razao_social': 'Test Company LTDA',
        'cnpj_cpf': '12345678901234',
        'email': 'test@example.com',
        'telefone1_ddd': '11',
        'telefone1_numero': '999999999',
    }


def get_valid_conta_receber_data():
    """Returns valid data for ContaReceberParam."""
    return {
        'codigo_lancamento_integracao': 'TEST-001',
        'codigo_cliente_fornecedor': 12345,
        'data_vencimento': '31/12/2025',
        'valor_documento': 1000.50,
        'codigo_categoria': 'CAT-001',
        'data_previsao': '31/12/2025',
        'id_conta_corrente': 'CC-001',
        'data_emissao': '01/01/2025',
        'observacao': 'Test observation',
    }


def get_valid_conta_pagar_data():
    """Returns valid data for ContaPagarParam."""
    return {
        'codigo_lancamento_integracao': 'TEST-PAG-001',
        'codigo_cliente_fornecedor': 54321,
        'data_vencimento': '31/12/2025',
        'valor_documento': 500.75,
        'codigo_categoria': 'CAT-002',
        'data_previsao': '31/12/2025',
        'id_conta_corrente': 'CC-002',
        'data_emissao': '01/01/2025',
        'observacao': 'Payment test',
    }


def get_valid_produto_data():
    """Returns valid data for ProdutoParam."""
    return {
        'descricao': 'Test Product',
        'codigo_familia': 'FAM-001',
        'unidade': 'UN',
        'valor_unitario': 99.99,
    }
