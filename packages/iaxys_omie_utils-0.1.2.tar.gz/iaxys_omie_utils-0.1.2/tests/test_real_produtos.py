import unittest
import sys

sys.path.insert(0, ".")

from iaxys_omie_utils.modules.produtos import OmieProdutos
from iaxys_omie_utils.modules.produtos.models import (
    ProdutoParam,
    ConsultarProdutoParam,
    ListarProdutosParam,
)
from iaxys_omie_utils.errors import OmieDuplicateError


class TestOmieProdutosRealHTTP(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from conftest import get_omie_credentials
        cls.app_key, cls.app_secret = get_omie_credentials()
        cls.client = OmieProdutos(app_key=cls.app_key, app_secret=cls.app_secret)

    def test_listar_produtos_pagination(self):
        param = ListarProdutosParam(pagina=1, registros_por_pagina=10)
        response = self.client.listar_produtos(param)

        self.assertIn("pagina", response)
        self.assertIn("total_de_paginas", response)
        self.assertIn("registros", response)
        self.assertIn("total_de_registros", response)
        self.assertIn("produto_servico_cadastro", response)

    def test_listar_produtos_default(self):
        response = self.client.listar_produtos()
        self.assertIn("pagina", response)
        self.assertIn("produto_servico_cadastro", response)

    def test_incluir_consultar_produto(self):
        param = ProdutoParam(
            codigo_produto_integracao="sdk-test-prod-001",
            codigo="SDK-PROD-001",
            descricao="Produto Teste SDK",
            unidade="UN",
            ncm="84713012",
            valor_unitario=99.99,
        )

        try:
            resp = self.client.incluir_produto(param)
        except OmieDuplicateError:
            consulta = self.client.consultar_produto(
                ConsultarProdutoParam(codigo_produto_integracao="sdk-test-prod-001")
            )
        else:
            self.assertIn("codigo_produto", resp)
            consulta = self.client.consultar_produto(
                ConsultarProdutoParam(codigo_produto=resp["codigo_produto"])
            )

        self.assertIn("codigo_produto", consulta)
        self.assertIn("descricao", consulta)

    def test_consultar_produto_da_listagem(self):
        """Consultar um produto retornado pela listagem."""
        listagem = self.client.listar_produtos(
            ListarProdutosParam(pagina=1, registros_por_pagina=1)
        )
        produtos = listagem.get("produto_servico_cadastro", [])
        if not produtos:
            self.skipTest("Nenhum produto cadastrado")

        codigo = produtos[0]["codigo_produto"]
        consulta = self.client.consultar_produto(
            ConsultarProdutoParam(codigo_produto=codigo)
        )
        self.assertEqual(consulta["codigo_produto"], codigo)
        self.assertIn("descricao", consulta)


if __name__ == "__main__":
    unittest.main()
