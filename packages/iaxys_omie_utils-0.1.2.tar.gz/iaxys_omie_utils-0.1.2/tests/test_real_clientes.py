import unittest
import sys

sys.path.insert(0, ".")

from iaxys_omie_utils.modules.clientes import OmieClientes
from iaxys_omie_utils.modules.clientes.models import (
    ClienteParam,
    ConsultarClienteParam,
    ListarClientesParam,
    UpsertClienteParam,
)
from iaxys_omie_utils.errors import OmieError, OmieDuplicateError


class TestOmieClientesRealHTTP(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from conftest import get_omie_credentials
        cls.app_key, cls.app_secret = get_omie_credentials()
        cls.client = OmieClientes(app_key=cls.app_key, app_secret=cls.app_secret)

    def test_listar_clientes_pagination(self):
        """Listar clientes com paginação e validar estrutura da resposta."""
        param = ListarClientesParam(pagina=1, registros_por_pagina=10)
        response = self.client.listar_clientes(param)

        self.assertIn("pagina", response)
        self.assertIn("total_de_paginas", response)
        self.assertIn("registros", response)
        self.assertIn("total_de_registros", response)
        self.assertIn("clientes_cadastro", response)

        for cli in response.get("clientes_cadastro", []):
            self.assertIn("codigo_cliente_omie", cli)
            self.assertIn("razao_social", cli)

    def test_incluir_consultar_cliente(self):
        """Incluir um cliente e depois consultá-lo pelo código Omie."""
        integracao = "sdk-test-real-001"

        param = ClienteParam(
            codigo_cliente_integracao=integracao,
            razao_social="Cliente Teste SDK",
            cnpj_cpf="00000000000191",  # CNPJ genérico
            email="teste@exemplo.com",
        )

        try:
            resp = self.client.incluir_cliente(param)
        except OmieDuplicateError as e:
            # Já existe — usa o ID retornado para consultar
            codigo_omie = int(e.omie_id)
        else:
            self.assertIn("codigo_cliente_omie", resp)
            codigo_omie = resp["codigo_cliente_omie"]

        # Consultar pelo código Omie
        consulta = self.client.consultar_cliente(
            ConsultarClienteParam(codigo_cliente_omie=codigo_omie)
        )
        self.assertEqual(consulta["codigo_cliente_omie"], codigo_omie)
        self.assertIn("razao_social", consulta)

    def test_upsert_cliente(self):
        """Upsert deve incluir ou atualizar sem erro."""
        param = UpsertClienteParam(
            codigo_cliente_integracao="sdk-test-real-001",
            razao_social="Cliente Upsert SDK",
            cnpj_cpf="00000000000191",
            email="upsert@exemplo.com",
        )

        resp = self.client.upsert_cliente(param)
        self.assertIn("codigo_cliente_omie", resp)


if __name__ == "__main__":
    unittest.main()
