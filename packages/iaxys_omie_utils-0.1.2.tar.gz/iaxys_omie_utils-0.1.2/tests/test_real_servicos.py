import unittest
import sys

sys.path.insert(0, ".")

from iaxys_omie_utils.modules.servicos import OmieServicos
from iaxys_omie_utils.modules.servicos.models import ConsultarOsParam, ListarOsParam
from iaxys_omie_utils.errors import OmieError


class TestOmieServicosRealHTTP(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from conftest import get_omie_credentials
        cls.app_key, cls.app_secret = get_omie_credentials()
        cls.client = OmieServicos(app_key=cls.app_key, app_secret=cls.app_secret)

    def test_listar_os_pagination(self):
        """Listar OS com paginação e validar estrutura da resposta."""
        param = ListarOsParam(pagina=1, registros_por_pagina=10)
        response = self.client.listar_os(param)

        self.assertIn("pagina", response)
        self.assertIn("total_de_paginas", response)
        self.assertIn("registros", response)
        self.assertIn("total_de_registros", response)
        self.assertIn("osCadastro", response)

    def test_listar_os_default(self):
        """Listar OS sem parâmetros usa defaults."""
        response = self.client.listar_os()

        self.assertIn("pagina", response)
        self.assertIn("osCadastro", response)

    def test_consultar_os_existente(self):
        """Consultar uma OS retornada pela listagem."""
        listagem = self.client.listar_os(ListarOsParam(pagina=1, registros_por_pagina=1))
        os_list = listagem.get("osCadastro", [])

        if not os_list:
            self.skipTest("Nenhuma OS cadastrada para consultar")

        # Pega o código da primeira OS
        primeira = os_list[0]
        codigo = primeira.get("Cabecalho", {}).get("nCodOS")
        self.assertIsNotNone(codigo, "OS deve ter nCodOS no Cabecalho")

        consulta = self.client.consultar_os(ConsultarOsParam(nCodOS=codigo))
        self.assertIn("Cabecalho", consulta)
        self.assertEqual(consulta["Cabecalho"]["nCodOS"], codigo)


if __name__ == "__main__":
    unittest.main()
