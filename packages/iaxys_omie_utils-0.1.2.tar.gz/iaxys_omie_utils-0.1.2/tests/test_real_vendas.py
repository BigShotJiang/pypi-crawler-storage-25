import unittest
import sys

sys.path.insert(0, ".")

from iaxys_omie_utils.modules.vendas import OmieVendas
from iaxys_omie_utils.modules.vendas.models import (
    ConsultarPedidoParam,
    ListarPedidosParam,
)
from iaxys_omie_utils.errors import OmieDuplicateError


class TestOmieVendasRealHTTP(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from conftest import get_omie_credentials
        cls.app_key, cls.app_secret = get_omie_credentials()
        cls.client = OmieVendas(app_key=cls.app_key, app_secret=cls.app_secret)

    def test_listar_pedidos_pagination(self):
        param = ListarPedidosParam(pagina=1, registros_por_pagina=10)
        response = self.client.listar_pedidos(param)

        self.assertIn("pagina", response)
        self.assertIn("total_de_paginas", response)
        self.assertIn("registros", response)
        self.assertIn("total_de_registros", response)
        self.assertIn("pedido_venda_produto", response)

    def test_listar_pedidos_default(self):
        response = self.client.listar_pedidos()
        self.assertIn("pagina", response)
        self.assertIn("pedido_venda_produto", response)

    def test_consultar_pedido_da_listagem(self):
        """Consultar um pedido retornado pela listagem."""
        listagem = self.client.listar_pedidos(
            ListarPedidosParam(pagina=1, registros_por_pagina=1)
        )
        pedidos = listagem.get("pedido_venda_produto", [])
        if not pedidos:
            self.skipTest("Nenhum pedido cadastrado para consultar")

        primeiro = pedidos[0]
        cabecalho = primeiro.get("cabecalho", primeiro)
        codigo = cabecalho.get("codigo_pedido")
        self.assertIsNotNone(codigo, "Pedido deve ter codigo_pedido")

        consulta = self.client.consultar_pedido(
            ConsultarPedidoParam(codigo_pedido=codigo)
        )
        # Consulta individual retorna {pedido_venda_produto: {cabecalho: {...}}}
        pedido = consulta.get("pedido_venda_produto", consulta)
        self.assertIn("cabecalho", pedido)
        self.assertEqual(pedido["cabecalho"]["codigo_pedido"], codigo)

    def test_listar_pedidos_com_filtro_etapa(self):
        """Listar pedidos filtrando por etapa."""
        param = ListarPedidosParam(pagina=1, registros_por_pagina=10, etapa="50")
        response = self.client.listar_pedidos(param)

        self.assertIn("pagina", response)
        self.assertIn("pedido_venda_produto", response)


if __name__ == "__main__":
    unittest.main()
