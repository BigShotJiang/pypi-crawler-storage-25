# permisapi-mcp

Serveur **MCP** (Model Context Protocol, Anthropic) pour [PermisAPI](https://permisapi.fr).

Permet à **Claude Desktop**, **Cursor**, **Windsurf** ou tout client MCP-compatible de consulter les **311 000 permis de construire France** en langage naturel.

## Installation

```bash
pip install permisapi-mcp
```

Vous avez besoin d'une clé API PermisAPI (gratuite pour commencer) :
[https://permisapi.fr/#pricing](https://permisapi.fr/#pricing)

## Configuration Claude Desktop

Éditez `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) ou `%APPDATA%\Claude\claude_desktop_config.json` (Windows) :

```json
{
  "mcpServers": {
    "permisapi": {
      "command": "permisapi-mcp",
      "env": {
        "PERMISAPI_KEY": "pk_live_VOTRE_CLE"
      }
    }
  }
}
```

Redémarrez Claude Desktop. Vous pouvez maintenant demander :

> *« Liste les permis de logement déposés à Bordeaux ce mois avec un score MDB > 70 »*
>
> *« Trouve-moi des opportunités MDB autour de la rue de Passy à Paris »*
>
> *« Quel est le zonage PLU du permis PC07404021K1 ? »*

## Configuration Cursor / Windsurf / autres clients

Voir le guide complet : [https://permisapi.fr/mcp](https://permisapi.fr/mcp)

## Tools disponibles (6)

| Tool | Endpoint | Plan requis |
|---|---|:---:|
| `search_permits` | GET /v1/permits | Free |
| `get_permit_details` | GET /v1/permits/{num_pa} | Free |
| `find_dvf_neighbors` | GET /v1/permits/{num_pa}/dvf | Pro |
| `get_mdb_score` | GET /v1/permits/{num_pa}/score | Pro |
| `get_plu_zoning` | GET /v1/permits/{num_pa}/plu | Pro |
| `get_risks` | GET /v1/permits/{num_pa}/risks | Pro |

## Sécurité

- La clé API reste **côté user** (env var locale, jamais transmise au LLM)
- Le LLM voit uniquement les arguments des tools (pas la clé)
- Validation stricte des inputs (regex sur `num_pa`, ranges Pydantic)
- Pas de side-effects : tous les tools sont **read-only** (GET uniquement)

## Licence

MIT.

## Support

evan@permisapi.fr — réponse 24-72h.
