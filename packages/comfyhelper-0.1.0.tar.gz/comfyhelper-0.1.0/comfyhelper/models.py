from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from comfyhelper.client import ComfyClient


@dataclass
class ImageRef:
    filename: str
    subfolder: str
    type: str


@dataclass
class Result:
    prompt_id: str
    images: list[ImageRef]

    def download(self, client: ComfyClient) -> list[bytes]:
        """Fetch raw image bytes for all output images."""
        return [client.download_image(ref) for ref in self.images]
