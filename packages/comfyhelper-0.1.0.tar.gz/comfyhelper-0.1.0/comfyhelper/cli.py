from __future__ import annotations

import os
from typing import Optional

import typer

from comfyhelper.client import ComfyClient
from comfyhelper.workflow import Workflow

app = typer.Typer()


def _unique_output_path(output_dir: str, subfolder: str, filename: str) -> str:
    safe_subfolder = os.path.normpath(subfolder).lstrip(os.sep)
    if safe_subfolder == ".":
        safe_subfolder = ""
    target_dir = os.path.abspath(os.path.join(output_dir, safe_subfolder))
    output_root = os.path.abspath(output_dir)
    if os.path.commonpath([output_root, target_dir]) != output_root:
        raise ValueError(f"Invalid image subfolder: {subfolder!r}")
    os.makedirs(target_dir, exist_ok=True)

    base, ext = os.path.splitext(os.path.basename(filename))
    path = os.path.join(target_dir, os.path.basename(filename))
    counter = 1
    while os.path.exists(path):
        path = os.path.join(target_dir, f"{base}_{counter}{ext}")
        counter += 1
    return path


@app.callback(invoke_without_command=True)
def main() -> None:
    """ComfyUI helper CLI"""
    pass


@app.command(name="run")
def run(
    workflow_path: str = typer.Argument(..., help="Path to workflow JSON file"),
    positive: Optional[str] = typer.Option(None, help="Positive prompt"),
    negative: Optional[str] = typer.Option(None, help="Negative prompt"),
    seed: Optional[int] = typer.Option(None, help="Seed"),
    steps: Optional[int] = typer.Option(None, help="Sampling steps"),
    cfg: Optional[float] = typer.Option(None, help="CFG scale"),
    sampler: Optional[str] = typer.Option(None, help="Sampler name"),
    scheduler: Optional[str] = typer.Option(None, help="Scheduler name"),
    denoise: Optional[float] = typer.Option(None, help="Denoise amount"),
    width: Optional[int] = typer.Option(None, help="Image width"),
    height: Optional[int] = typer.Option(None, help="Image height"),
    batch_size: Optional[int] = typer.Option(None, help="Latent batch size"),
    filename_prefix: Optional[str] = typer.Option(None, help="SaveImage filename prefix"),
    image: Optional[list[str]] = typer.Option(None, help="LoadImage filename"),
    checkpoint: Optional[str] = typer.Option(None, help="Checkpoint filename"),
    diffusion_model: Optional[str] = typer.Option(
        None,
        help="Diffusion model filename",
    ),
    clip: Optional[list[str]] = typer.Option(None, help="CLIP filename"),
    vae: Optional[str] = typer.Option(None, help="VAE filename"),
    lora: Optional[list[str]] = typer.Option(None, help="LoRA filename"),
    lora_strength: Optional[list[float]] = typer.Option(None, help="LoRA strength"),
    host: str = typer.Option("localhost", help="ComfyUI host"),
    port: int = typer.Option(8188, help="ComfyUI port"),
    request_timeout: Optional[float] = typer.Option(
        30.0,
        help="HTTP request timeout in seconds; use 0 to disable",
    ),
    output_dir: str = typer.Option("./output", help="Directory to save images"),
    no_wait: bool = typer.Option(False, help="Submit only, print prompt_id and exit"),
) -> None:
    workflow = Workflow.from_file(workflow_path)

    if positive is not None:
        workflow.set_positive_prompt(positive)
    if negative is not None:
        workflow.set_negative_prompt(negative)
    if seed is not None:
        workflow.set_seed(seed)
    if steps is not None:
        workflow.set_steps(steps)
    if cfg is not None:
        workflow.set_cfg(cfg)
    if sampler is not None:
        workflow.set_sampler(sampler)
    if scheduler is not None:
        workflow.set_scheduler(scheduler)
    if denoise is not None:
        workflow.set_denoise(denoise)
    if (width is None) != (height is None):
        raise typer.BadParameter("--width and --height must be provided together")
    if width is not None and height is not None:
        workflow.set_dimensions(width, height)
    if batch_size is not None:
        workflow.set_batch_size(batch_size)
    if filename_prefix is not None:
        workflow.set_filename_prefix(filename_prefix)
    if image:
        workflow.set_load_images(image)
    if checkpoint is not None:
        workflow.set_checkpoint(checkpoint)
    if diffusion_model is not None:
        workflow.set_diffusion_model(diffusion_model)
    if clip:
        workflow.set_clips(clip)
    if vae is not None:
        workflow.set_vae(vae)
    if lora:
        if not lora_strength:
            strengths = [1.0] * len(lora)
        elif len(lora_strength) == 1:
            strengths = lora_strength * len(lora)
        elif len(lora_strength) == len(lora):
            strengths = lora_strength
        else:
            raise typer.BadParameter(
                "--lora-strength must be provided once or once per --lora"
            )
        workflow.set_loras(list(zip(lora, strengths)))

    timeout = None if request_timeout == 0 else request_timeout
    client = ComfyClient(host=host, port=port, request_timeout=timeout)

    if no_wait:
        prompt_id = client.submit(workflow)
        typer.echo(f"Submitted. prompt_id: {prompt_id}")
        return

    result = client.run(workflow)
    for image_ref in result.images:
        data = client.download_image(image_ref)
        out_path = _unique_output_path(
            output_dir,
            image_ref.subfolder,
            image_ref.filename,
        )
        with open(out_path, "wb") as f:
            f.write(data)
        typer.echo(f"Saved: {out_path}")
