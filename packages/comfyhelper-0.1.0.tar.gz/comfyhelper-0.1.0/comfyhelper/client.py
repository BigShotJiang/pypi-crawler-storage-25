from __future__ import annotations

import time
import uuid

import requests

from comfyhelper.models import ImageRef, Result
from comfyhelper.workflow import Workflow


class ComfyClient:
    def __init__(
        self,
        host: str = "localhost",
        port: int = 8188,
        request_timeout: float | None = 30.0,
    ) -> None:
        self._base_url = f"http://{host}:{port}"
        self._client_id = str(uuid.uuid4())
        self._request_timeout = request_timeout

    def _get_history(self, prompt_id: str) -> dict:
        response = requests.get(
            f"{self._base_url}/history/{prompt_id}",
            timeout=self._request_timeout,
        )
        response.raise_for_status()
        return response.json()

    def _extract_error(self, prompt_id: str, history: dict) -> str | None:
        entry = history.get(prompt_id)
        if not isinstance(entry, dict):
            return None
        status = entry.get("status")
        if not isinstance(status, dict):
            return None
        status_str = str(status.get("status_str", "")).lower()
        if "error" not in status_str and "failed" not in status_str:
            return None
        messages = status.get("messages", [])
        if messages:
            return f"Prompt {prompt_id!r} failed: {messages}"
        return f"Prompt {prompt_id!r} failed with status {status_str!r}"

    def submit(self, workflow: Workflow) -> str:
        workflow.validate_or_raise()
        payload = {
            "prompt": workflow.to_dict(),
            "client_id": self._client_id,
        }
        response = requests.post(
            f"{self._base_url}/prompt",
            json=payload,
            timeout=self._request_timeout,
        )
        response.raise_for_status()
        return response.json()["prompt_id"]

    def get_status(self, prompt_id: str) -> str:
        history = self._get_history(prompt_id)
        if self._extract_error(prompt_id, history) is not None:
            return "error"
        if prompt_id in history:
            return "done"
        return "pending"

    def get_result(self, prompt_id: str) -> Result:
        history = self._get_history(prompt_id)
        if prompt_id not in history:
            raise RuntimeError(f"Prompt {prompt_id!r} is not complete yet")
        error = self._extract_error(prompt_id, history)
        if error is not None:
            raise RuntimeError(error)
        outputs = history[prompt_id].get("outputs", {})
        images: list[ImageRef] = []
        for node_output in outputs.values():
            for img in node_output.get("images", []):
                images.append(ImageRef(
                    filename=img["filename"],
                    subfolder=img["subfolder"],
                    type=img["type"],
                ))
        return Result(prompt_id=prompt_id, images=images)

    def download_image(self, image_ref: ImageRef) -> bytes:
        params = {
            "filename": image_ref.filename,
            "subfolder": image_ref.subfolder,
            "type": image_ref.type,
        }
        response = requests.get(
            f"{self._base_url}/view",
            params=params,
            timeout=self._request_timeout,
        )
        response.raise_for_status()
        return response.content

    def run(self, workflow: Workflow, timeout: float = 300.0) -> Result:
        prompt_id = self.submit(workflow)
        start = time.monotonic()
        while True:
            if time.monotonic() - start > timeout:
                raise TimeoutError(
                    f"Prompt {prompt_id!r} timed out after {timeout}s"
                )
            status = self.get_status(prompt_id)
            if status == "done":
                return self.get_result(prompt_id)
            if status == "error":
                self.get_result(prompt_id)
            time.sleep(1.0)
