from __future__ import annotations

import copy
import json
from collections.abc import Sequence

CLIP_LOADER_FIELDS = {
    "CLIPLoader": ("clip_name",),
    "DualCLIPLoader": ("clip_name1", "clip_name2"),
    "TripleCLIPLoader": ("clip_name1", "clip_name2", "clip_name3"),
    "QuadrupleCLIPLoader": ("clip_name1", "clip_name2", "clip_name3", "clip_name4"),
}
CLIP_LOADER_TYPES = tuple(CLIP_LOADER_FIELDS)


class Workflow:
    def __init__(self, data: dict) -> None:
        self._data: dict = data
        self._index: dict[str, list[str]] = self._build_index()
        self._positive_node_id: str | None = None
        self._negative_node_id: str | None = None
        self._resolve_prompt_nodes()

    def __str__(self) -> str:
        return f"""{self._data}"""

    def _build_index(self) -> dict[str, list[str]]:
        index: dict[str, list[str]] = {}
        for node_id, node in self._data.items():
            ct = node["class_type"]
            index.setdefault(ct, []).append(node_id)
        return index

    def _resolve_prompt_nodes(self) -> None:
        ksampler_ids = self._index.get("KSampler", [])
        if not ksampler_ids:
            return
        self._positive_node_id, self._negative_node_id = (
            self._resolve_prompt_nodes_for_sampler(ksampler_ids[0])
        )

    def _resolve_prompt_nodes_for_sampler(self, sampler_id: str) -> tuple[str, str]:
        if sampler_id not in self._data:
            raise ValueError(f"No sampler node with id {sampler_id!r} found")
        ksampler_inputs = self._data[sampler_id]["inputs"]
        pos_ref = ksampler_inputs.get("positive")
        neg_ref = ksampler_inputs.get("negative")
        if not isinstance(pos_ref, list) or not isinstance(neg_ref, list):
            raise ValueError(
                f"Could not resolve prompt nodes for sampler {sampler_id!r}"
            )
        return pos_ref[0], neg_ref[0]

    def _get_node_id(self, class_type: str) -> str:
        node_ids = self._index.get(class_type, [])
        if not node_ids:
            raise ValueError(f"No node of type {class_type!r} found in workflow")
        if len(node_ids) > 1:
            raise ValueError(
                f"Multiple nodes of type {class_type!r} found; use a typed setter or resolve manually"
            )
        return node_ids[0]

    def _get_first_existing_node_id(self, class_types: Sequence[str]) -> str:
        for class_type in class_types:
            node_ids = self._index.get(class_type, [])
            if not node_ids:
                continue
            if len(node_ids) > 1:
                raise ValueError(
                    f"Multiple nodes of type {class_type!r} found; use set_node_input or resolve manually"
                )
            return node_ids[0]
        names = ", ".join(repr(class_type) for class_type in class_types)
        raise ValueError(f"No node of type {names} found in workflow")

    def _next_node_id(self) -> str:
        numeric_ids = [int(node_id) for node_id in self._data if node_id.isdigit()]
        if numeric_ids:
            return str(max(numeric_ids) + 1)
        return "1"

    def _resolve_lora_base_refs(
        self,
        lora_node_ids: set[str],
    ) -> tuple[list, list]:
        ksampler_id = self._get_node_id("KSampler")
        model_ref = self._data[ksampler_id]["inputs"].get("model")

        if isinstance(model_ref, list) and model_ref[0] in lora_node_ids:
            lora_inputs = self._data[model_ref[0]]["inputs"]
            while (
                isinstance(lora_inputs.get("model"), list)
                and lora_inputs["model"][0] in lora_node_ids
            ):
                lora_inputs = self._data[lora_inputs["model"][0]]["inputs"]
            return list(lora_inputs["model"]), list(lora_inputs["clip"])

        clip_ref = None
        for node_id in (self._positive_node_id, self._negative_node_id):
            if node_id is None:
                continue
            candidate = self._data[node_id]["inputs"].get("clip")
            if isinstance(candidate, list):
                clip_ref = candidate
                break

        if not isinstance(model_ref, list):
            model_loader_id = self._get_first_existing_node_id(
                [
                    "CheckpointLoaderSimple",
                    "UNETLoader",
                ]
            )
            model_ref = [model_loader_id, 0]
        if clip_ref is None:
            clip_loader_id = self._get_first_existing_node_id(
                [
                    "CheckpointLoaderSimple",
                    *CLIP_LOADER_TYPES,
                ]
            )
            clip_output_index = (
                1
                if self._data[clip_loader_id]["class_type"] == "CheckpointLoaderSimple"
                else 0
            )
            clip_ref = [clip_loader_id, clip_output_index]

        return list(model_ref), list(clip_ref)

    def set_node_input(self, class_type: str, field: str, value) -> None:
        node_id = self._get_node_id(class_type)
        self.set_node_input_by_id(node_id, field, value)

    def set_node_input_by_id(self, node_id: str, field: str, value) -> None:
        if node_id not in self._data:
            raise ValueError(f"No node with id {node_id!r} found in workflow")
        self._data[node_id]["inputs"][field] = value

    def set_positive_prompt(self, text: str, sampler_id: str | None = None) -> None:
        if sampler_id is not None:
            positive_node_id, _ = self._resolve_prompt_nodes_for_sampler(sampler_id)
        elif self._positive_node_id is None:
            raise ValueError(
                "Could not resolve positive prompt node: no KSampler found"
            )
        else:
            positive_node_id = self._positive_node_id
        self._data[positive_node_id]["inputs"]["text"] = text

    def set_negative_prompt(self, text: str, sampler_id: str | None = None) -> None:
        if sampler_id is not None:
            _, negative_node_id = self._resolve_prompt_nodes_for_sampler(sampler_id)
        elif self._negative_node_id is None:
            raise ValueError(
                "Could not resolve negative prompt node: no KSampler found"
            )
        else:
            negative_node_id = self._negative_node_id
        self._data[negative_node_id]["inputs"]["text"] = text

    def set_prompt_node(self, node_id: str, text: str) -> None:
        self.set_node_input_by_id(node_id, "text", text)

    def set_seed(self, seed: int) -> None:
        self.set_node_input("KSampler", "seed", seed)

    def set_steps(self, steps: int) -> None:
        self.set_node_input("KSampler", "steps", steps)

    def set_cfg(self, cfg: float) -> None:
        self.set_node_input("KSampler", "cfg", cfg)

    def set_sampler(self, sampler_name: str) -> None:
        self.set_node_input("KSampler", "sampler_name", sampler_name)

    def set_scheduler(self, scheduler: str) -> None:
        self.set_node_input("KSampler", "scheduler", scheduler)

    def set_denoise(self, denoise: float) -> None:
        self.set_node_input("KSampler", "denoise", denoise)

    def set_dimensions(self, width: int, height: int) -> None:
        self.set_node_input("EmptyLatentImage", "width", width)
        self.set_node_input("EmptyLatentImage", "height", height)

    def set_batch_size(self, batch_size: int) -> None:
        self.set_node_input("EmptyLatentImage", "batch_size", batch_size)

    def set_filename_prefix(self, prefix: str) -> None:
        self.set_node_input("SaveImage", "filename_prefix", prefix)

    def get_load_image_count(self) -> int:
        return len(self._index.get("LoadImage", []))

    def set_load_image(self, image: str) -> None:
        self.set_load_images([image])

    def set_load_images(self, images: Sequence[str]) -> None:
        node_ids = self._index.get("LoadImage", [])
        if len(images) != len(node_ids):
            raise ValueError(
                f"Workflow has {len(node_ids)} LoadImage nodes; got {len(images)} images"
            )
        for node_id, image in zip(node_ids, images):
            self._data[node_id]["inputs"]["image"] = image

    def set_checkpoint(self, name: str) -> None:
        self.set_node_input("CheckpointLoaderSimple", "ckpt_name", name)

    def set_diffusion_model(self, name: str) -> None:
        self.set_node_input("UNETLoader", "unet_name", name)

    def set_clip(self, name: str) -> None:
        self.set_clips([name])

    def set_clips(self, names: Sequence[str]) -> None:
        node_id = self._get_first_existing_node_id(CLIP_LOADER_TYPES)
        node = self._data[node_id]
        fields = CLIP_LOADER_FIELDS[node["class_type"]]
        if len(names) != len(fields):
            raise ValueError(
                f"{node['class_type']} requires {len(fields)} CLIP filenames; got {len(names)}"
            )
        for field, name in zip(fields, names):
            node["inputs"][field] = name

    def set_vae(self, name: str) -> None:
        self.set_node_input("VAELoader", "vae_name", name)

    def set_lora(self, name: str, strength: float = 1.0) -> None:
        self.set_loras([(name, strength)])

    def set_loras(self, loras: Sequence[tuple[str, float]]) -> None:
        lora_node_ids = set(self._index.get("LoraLoader", []))
        base_model_ref, base_clip_ref = self._resolve_lora_base_refs(lora_node_ids)

        for node_id in lora_node_ids:
            del self._data[node_id]

        current_model_ref = base_model_ref
        current_clip_ref = base_clip_ref
        for name, strength in loras:
            node_id = self._next_node_id()
            self._data[node_id] = {
                "inputs": {
                    "lora_name": name,
                    "strength_model": strength,
                    "strength_clip": strength,
                    "model": current_model_ref,
                    "clip": current_clip_ref,
                },
                "class_type": "LoraLoader",
                "_meta": {"title": "Load LoRA"},
            }
            current_model_ref = [node_id, 0]
            current_clip_ref = [node_id, 1]

        for node in self._data.values():
            for field, value in node["inputs"].items():
                if not (
                    isinstance(value, list)
                    and len(value) == 2
                    and value[0] in lora_node_ids
                ):
                    continue
                node["inputs"][field] = (
                    current_model_ref if value[1] == 0 else current_clip_ref
                )

        ksampler_id = self._get_node_id("KSampler")
        self._data[ksampler_id]["inputs"]["model"] = current_model_ref
        for node_id in (self._positive_node_id, self._negative_node_id):
            if node_id is not None:
                self._data[node_id]["inputs"]["clip"] = current_clip_ref

        self._index = self._build_index()

    def validate(self) -> list[str]:
        issues: list[str] = []
        ksampler_ids = self._index.get("KSampler", [])
        if not ksampler_ids:
            issues.append("No KSampler node found")
        for sampler_id in ksampler_ids:
            inputs = self._data[sampler_id].get("inputs", {})
            for field in ("model", "positive", "negative", "latent_image"):
                ref = inputs.get(field)
                if not (isinstance(ref, list) and ref and ref[0] in self._data):
                    issues.append(
                        f"KSampler {sampler_id!r} has invalid {field!r} input"
                    )

        for node_id in self._index.get("VAEDecode", []):
            inputs = self._data[node_id].get("inputs", {})
            for field in ("samples", "vae"):
                ref = inputs.get(field)
                if not (isinstance(ref, list) and ref and ref[0] in self._data):
                    issues.append(
                        f"VAEDecode {node_id!r} has invalid {field!r} input"
                    )

        for node_id, node in self._data.items():
            for field, value in node.get("inputs", {}).items():
                if (
                    isinstance(value, list)
                    and len(value) == 2
                    and isinstance(value[0], str)
                    and value[0] not in self._data
                ):
                    issues.append(
                        f"Node {node_id!r} field {field!r} references missing node {value[0]!r}"
                    )

        for node_id in self._index.get("EmptyLatentImage", []):
            inputs = self._data[node_id].get("inputs", {})
            width = inputs.get("width")
            height = inputs.get("height")
            if isinstance(width, int) and width <= 0:
                issues.append(f"EmptyLatentImage {node_id!r} width must be positive")
            if isinstance(height, int) and height <= 0:
                issues.append(f"EmptyLatentImage {node_id!r} height must be positive")

        return issues

    def validate_or_raise(self) -> None:
        issues = self.validate()
        if issues:
            raise ValueError("Invalid workflow: " + "; ".join(issues))

    @classmethod
    def from_dict(cls, data: dict) -> Workflow:
        return cls(copy.deepcopy(data))

    @classmethod
    def from_file(cls, path: str) -> Workflow:
        with open(path) as f:
            return cls(json.load(f))

    def to_dict(self) -> dict:
        return copy.deepcopy(self._data)
