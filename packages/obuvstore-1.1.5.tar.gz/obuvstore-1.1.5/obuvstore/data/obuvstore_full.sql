-- =============================================================
--  obuvstore_full.sql
--  Полная схема + реальные данные из Excel-файлов
--  Этот файл встроен внутрь pip-пакета и применяется автоматически
-- =============================================================

CREATE DATABASE IF NOT EXISTS `obuvstore`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `obuvstore`;

-- ── Роли ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `roles` (
  `role_id`   INT         NOT NULL AUTO_INCREMENT,
  `role_name` VARCHAR(60) NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `uq_role` (`role_name`)
) ENGINE=InnoDB;

INSERT IGNORE INTO `roles` (`role_name`) VALUES
  ('Гость'),
  ('Авторизированный клиент'),
  ('Менеджер'),
  ('Администратор');

-- ── Пользователи (из user_import.xlsx) ───────────────────────
CREATE TABLE IF NOT EXISTS `users` (
  `user_id`   INT          NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(200) NOT NULL,
  `login`     VARCHAR(150) NOT NULL,
  `password`  VARCHAR(255) NOT NULL,
  `role_id`   INT          NOT NULL DEFAULT 2,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uq_login` (`login`),
  CONSTRAINT `fk_user_role` FOREIGN KEY (`role_id`)
    REFERENCES `roles`(`role_id`)
) ENGINE=InnoDB;

INSERT IGNORE INTO `users` (`full_name`, `login`, `password`, `role_id`) VALUES
-- Администраторы
('Никифорова Весения Николаевна', '94d5ous@gmail.com',   'uzWC67', 4),
('Сазонов Руслан Германович',     'uth4iz@mail.com',     '2L6KZG', 4),
('Одинцов Серафим Артёмович',     'yzls62@outlook.com',  'JlFRCZ', 4),
-- Менеджеры
('Степанов Михаил Артёмович',     '1diph5e@tutanota.com','8ntwUp', 3),
('Ворсин Петр Евгеньевич',        'tjde7c@yahoo.com',    'YOyhfR', 3),
('Старикова Елена Павловна',      'wpmrc3do@tutanota.com','RSbvHv',3),
-- Авторизированные клиенты
('Михайлюк Анна Вячеславовна',    '5d4zbu@tutanota.com', 'rwVDh9', 2),
('Ситдикова Елена Анатольевна',   'ptec8ym@yahoo.com',   'LdNyos', 2),
('Ворсин Петр Евгеньевич',        '1qz4kw@mail.com',     'gynQMT', 2),
('Старикова Елена Павловна',      '4np6se@mail.com',     'AtnDjr', 2);

-- ── Пункты выдачи (из Пункты_выдачи_import.xlsx) ─────────────
CREATE TABLE IF NOT EXISTS `pickup_points` (
  `point_id` INT          NOT NULL AUTO_INCREMENT,
  `address`  VARCHAR(300) NOT NULL,
  PRIMARY KEY (`point_id`)
) ENGINE=InnoDB;

INSERT IGNORE INTO `pickup_points` (`address`) VALUES
('420151, г. Лесной, ул. Вишневая, 32'),
('125061, г. Лесной, ул. Подгорная, 8'),
('630370, г. Лесной, ул. Шоссейная, 24'),
('400562, г. Лесной, ул. Зеленая, 32'),
('614510, г. Лесной, ул. Маяковского, 47'),
('410542, г. Лесной, ул. Светлая, 46'),
('620839, г. Лесной, ул. Цветочная, 8'),
('443890, г. Лесной, ул. Коммунистическая, 1'),
('603379, г. Лесной, ул. Спортивная, 46'),
('603721, г. Лесной, ул. Гоголя, 41'),
('410172, г. Лесной, ул. Северная, 13'),
('614611, г. Лесной, ул. Молодежная, 50'),
('454311, г. Лесной, ул. Новая, 19'),
('660007, г. Лесной, ул. Октябрьская, 19'),
('603036, г. Лесной, ул. Садовая, 4'),
('394060, г. Лесной, ул. Фрунзе, 43'),
('410661, г. Лесной, ул. Школьная, 50'),
('625590, г. Лесной, ул. Коммунистическая, 20'),
('625683, г. Лесной, ул. 8 Марта'),
('450983, г. Лесной, ул. Комсомольская, 26'),
('394782, г. Лесной, ул. Чехова, 3'),
('603002, г. Лесной, ул. Дзержинского, 28'),
('450558, г. Лесной, ул. Набережная, 30'),
('344288, г. Лесной, ул. Чехова, 1'),
('614164, г. Лесной, ул. Степная, 30'),
('394242, г. Лесной, ул. Коммунистическая, 43'),
('660540, г. Лесной, ул. Солнечная, 25'),
('125837, г. Лесной, ул. Шоссейная, 40'),
('125703, г. Лесной, ул. Партизанская, 49'),
('625283, г. Лесной, ул. Победы, 46'),
('614753, г. Лесной, ул. Полевая, 35'),
('426030, г. Лесной, ул. Маяковского, 44'),
('450375, г. Лесной, ул. Клубная, 44'),
('625560, г. Лесной, ул. Некрасова, 12'),
('630201, г. Лесной, ул. Комсомольская, 17'),
('190949, г. Лесной, ул. Мичурина, 26');

-- ── Категории товаров ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `categories` (
  `category_id`   INT          NOT NULL AUTO_INCREMENT,
  `category_name` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB;

INSERT IGNORE INTO `categories` (`category_name`) VALUES
  ('Мужская обувь'), ('Женская обувь'), ('Детская обувь'), ('Аксессуары');

-- ── Товары ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `products` (
  `product_id`  INT            NOT NULL AUTO_INCREMENT,
  `article`     VARCHAR(20)    NOT NULL,   -- артикул (А112Т4, H782T5…)
  `name`        VARCHAR(200)   NOT NULL,
  `category_id` INT            DEFAULT NULL,
  `brand`       VARCHAR(100)   DEFAULT NULL,
  `price`       DECIMAL(10,2)  NOT NULL,
  `discount`    DECIMAL(5,2)   NOT NULL DEFAULT 0.00,
  `stock`       INT            NOT NULL DEFAULT 0,
  `description` TEXT           DEFAULT NULL,
  `image_path`  VARCHAR(500)   DEFAULT NULL,
  `is_active`   TINYINT(1)     NOT NULL DEFAULT 1,
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `uq_article` (`article`),
  CONSTRAINT `fk_product_cat` FOREIGN KEY (`category_id`)
    REFERENCES `categories`(`category_id`)
) ENGINE=InnoDB;

-- Артикулы взяты из Заказ_import.xlsx
INSERT IGNORE INTO `products` (`article`,`name`,`category_id`,`brand`,`price`,`discount`,`stock`) VALUES
('А112Т4', 'Кроссовки Беговые Pro',  1, 'RunMax',   4999.00,  0.00, 30),
('F635R4', 'Туфли Классик Женские',  2, 'Elegance', 3499.00, 10.00, 20),
('H782T5', 'Сандалии Летние',        2, 'SunStep',  1999.00,  5.00, 40),
('G783F5', 'Ботинки Зимние Мужские', 1, 'IcePro',   6999.00, 20.00, 10),
('J384T6', 'Кеды Детские',           3, 'KidStep',  1499.00, 16.00, 50),
('D572U8', 'Мокасины Летние',        1, 'LoaferX',  2799.00,  0.00, 15),
('F572H7', 'Балетки Классик',        2, 'DanceStep',2199.00, 18.00, 25),
('D329H3', 'Угги Зимние',            2, 'UggPro',   5499.00,  8.00, 12),
('B320R5', 'Кроссовки Casual',       1, 'CasualMax',3299.00,  0.00, 35),
('G432E4', 'Сапоги Осенние',         2, 'AutumnStep',4199.00, 12.00, 18),
('S213E3', 'Шлёпанцы Пляжные',       2, 'BeachStep',  899.00,  0.00, 60),
('E482R4', 'Кроссовки Детские',      3, 'KidMax',   1799.00,  5.00, 45);

-- ── Заказы (из Заказ_import.xlsx) ─────────────────────────────
CREATE TABLE IF NOT EXISTS `orders` (
  `order_id`    INT          NOT NULL AUTO_INCREMENT,
  `order_num`   INT          NOT NULL,
  `user_id`     INT          NOT NULL,
  `point_id`    INT          DEFAULT NULL,
  `order_date`  DATE         DEFAULT NULL,
  `delivery_date` DATE       DEFAULT NULL,
  `pickup_code` VARCHAR(10)  DEFAULT NULL,
  `status`      ENUM('Новый','В обработке','Выполнен','Завершен','Отменён')
                             NOT NULL DEFAULT 'Новый',
  PRIMARY KEY (`order_id`),
  CONSTRAINT `fk_order_user`  FOREIGN KEY (`user_id`)  REFERENCES `users`(`user_id`),
  CONSTRAINT `fk_order_point` FOREIGN KEY (`point_id`) REFERENCES `pickup_points`(`point_id`)
) ENGINE=InnoDB;

-- ── Позиции заказа ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `order_items` (
  `item_id`    INT NOT NULL AUTO_INCREMENT,
  `order_id`   INT NOT NULL,
  `article`    VARCHAR(20) NOT NULL,
  `quantity`   INT NOT NULL DEFAULT 1,
  PRIMARY KEY (`item_id`),
  CONSTRAINT `fk_item_order` FOREIGN KEY (`order_id`)
    REFERENCES `orders`(`order_id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Данные заказов (даты Excel-серийные → реальные даты)
-- 45715=2025-02-03, 45767=2025-03-27, 44832=2022-10-05 и т.д.
INSERT IGNORE INTO `orders`
  (`order_num`,`user_id`,`point_id`,`order_date`,`delivery_date`,`pickup_code`,`status`)
VALUES
(1,  4, 1,  '2025-02-03', '2025-03-27', '901', 'Завершен'),
(2,  1, 11, '2022-10-05', '2025-03-28', '902', 'Завершен'),
(3,  5, 2,  '2025-02-25', '2025-03-29', '903', 'Завершен'),
(4,  3, 11, '2024-12-27', '2025-03-30', '904', 'Завершен'),
(5,  4, 2,  '2025-02-21', '2025-03-31', '905', 'Завершен'),
(6,  1, 15, '2025-02-05', '2025-04-01', '906', 'Завершен'),
(7,  2, 3,  '2025-02-17', '2025-04-02', '907', 'Завершен'),
(8,  3, 19, '2025-03-07', '2025-04-03', '908', 'Новый'),
(9,  4, 5,  '2025-03-09', '2025-04-04', '909', 'Новый'),
(10, 4, 19, '2025-03-10', '2025-04-05', '910', 'Новый');

-- Позиции заказов (артикул, количество из Заказ_import.xlsx)
INSERT IGNORE INTO `order_items` (`order_id`,`article`,`quantity`) VALUES
(1,'А112Т4',2),(1,'F635R4',2),
(2,'H782T5',1),(2,'G783F5',1),
(3,'J384T6',10),(3,'D572U8',10),
(4,'F572H7',5),(4,'D329H3',4),
(5,'А112Т4',2),(5,'F635R4',2),
(6,'H782T5',1),(6,'G783F5',1),
(7,'J384T6',10),(7,'D572U8',10),
(8,'F572H7',5),(8,'D329H3',4),
(9,'B320R5',5),(9,'G432E4',1),
(10,'S213E3',5),(10,'E482R4',5);
