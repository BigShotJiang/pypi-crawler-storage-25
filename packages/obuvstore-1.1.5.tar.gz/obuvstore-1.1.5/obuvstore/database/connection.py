"""
database/connection.py
Singleton-менеджер подключения к MySQL.
"""
import mysql.connector
from mysql.connector import Error
from obuvstore import config


_connection = None   # единственный экземпляр соединения


def get_connection():
    """Возвращает активное соединение (создаёт при первом вызове)."""
    global _connection
    if _connection is None or not _connection.is_connected():
        _connection = mysql.connector.connect(
            host=config.DB_HOST,
            port=config.DB_PORT,
            user=config.DB_USER,
            password=config.DB_PASSWORD,
            database=config.DB_NAME,
            charset="utf8mb4",
            autocommit=False,
        )
        print(f"[obuvstore] Подключено к MySQL: {config.DB_HOST}/{config.DB_NAME}")
    return _connection


def close_connection():
    global _connection
    if _connection and _connection.is_connected():
        _connection.close()
        _connection = None


def execute_query(sql: str, params: tuple = (), fetch: bool = False):
    """
    Универсальный хелпер для запросов.
    fetch=True  → возвращает список строк (SELECT)
    fetch=False → выполняет INSERT/UPDATE/DELETE, возвращает lastrowid
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(sql, params)
    if fetch:
        result = cursor.fetchall()
        cursor.close()
        return result
    else:
        conn.commit()
        last_id = cursor.lastrowid
        cursor.close()
        return last_id


# ── Готовые запросы для модулей ────────────────────────────────

def get_user_by_login(login: str, password: str):
    row = execute_query(
        "SELECT u.*, r.role_name FROM users u "
        "JOIN roles r ON u.role_id = r.role_id "
        "WHERE u.login=%s AND u.password=%s LIMIT 1",
        (login, password), fetch=True
    )
    return row[0] if row else None


def get_all_products(search: str = "", category_id: int = None,
                     sort_by: str = "name", sort_dir: str = "ASC"):
    conditions, params = ["p.is_active=1"], []
    if search:
        conditions.append("(p.name LIKE %s OR p.brand LIKE %s)")
        params += [f"%{search}%", f"%{search}%"]
    if category_id:
        conditions.append("p.category_id=%s")
        params.append(category_id)
    where = " AND ".join(conditions)
    allowed_sort = {"name", "price", "discount", "stock", "brand"}
    col = sort_by if sort_by in allowed_sort else "name"
    direction = "DESC" if sort_dir.upper() == "DESC" else "ASC"
    sql = (f"SELECT p.*, c.category_name FROM products p "
           f"LEFT JOIN categories c ON p.category_id=c.category_id "
           f"WHERE {where} ORDER BY p.{col} {direction}")
    return execute_query(sql, tuple(params), fetch=True)


def get_all_orders():
    return execute_query(
        "SELECT o.*, u.full_name, u.login FROM orders o "
        "JOIN users u ON o.user_id=u.user_id ORDER BY o.created_at DESC",
        fetch=True
    )


def add_product(name, category_id, brand, price, discount, stock, description="", image_path=""):
    return execute_query(
        "INSERT INTO products (name,category_id,brand,price,discount,stock,description,image_path) "
        "VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
        (name, category_id, brand, price, discount, stock, description, image_path)
    )


def update_product(product_id, name, category_id, brand, price, discount, stock):
    execute_query(
        "UPDATE products SET name=%s,category_id=%s,brand=%s,"
        "price=%s,discount=%s,stock=%s WHERE product_id=%s",
        (name, category_id, brand, price, discount, stock, product_id)
    )


def delete_product(product_id: int):
    execute_query("UPDATE products SET is_active=0 WHERE product_id=%s", (product_id,))


def add_order(user_id, comment=""):
    return execute_query(
        "INSERT INTO orders (user_id, comment) VALUES (%s,%s)",
        (user_id, comment)
    )


def update_order_status(order_id: int, status: str):
    execute_query("UPDATE orders SET status=%s WHERE order_id=%s", (status, order_id))
