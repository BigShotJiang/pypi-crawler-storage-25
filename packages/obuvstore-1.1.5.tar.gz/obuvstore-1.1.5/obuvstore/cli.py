"""
obuvstore/cli.py
Запускается командой: obuvstore-init
Копирует все файлы пакета в текущую папку проекта.
"""
import os
import shutil


def init_project():
    # Папка где установлен пакет
    package_dir = os.path.dirname(os.path.abspath(__file__))

    # Текущая папка (где открыт терминал PyCharm = корень проекта)
    project_dir = os.getcwd()

    print("\n[obuvstore] Инициализация проекта...")
    print(f"[obuvstore] Куда копируем: {project_dir}\n")

    # ── Копируем папку obuvstore ──────────────────────────────
    dst_obuvstore = os.path.join(project_dir, "obuvstore")
    if os.path.exists(dst_obuvstore):
        print("[obuvstore] ⚠️  Папка obuvstore уже существует — пропускаем.")
    else:
        shutil.copytree(package_dir, dst_obuvstore)
        print("[obuvstore] ✅ Папка obuvstore/ скопирована в проект")

    # ── Создаём папку resources ───────────────────────────────
    dst_resources = os.path.join(project_dir, "resources")
    os.makedirs(dst_resources, exist_ok=True)
    print("[obuvstore] ✅ Папка resources/ готова (положи сюда icon.ico и logo.png)")

    # ── Создаём main.py если нет ─────────────────────────────
    dst_main = os.path.join(project_dir, "main.py")
    if os.path.exists(dst_main):
        print("[obuvstore] ⚠️  main.py уже существует — пропускаем.")
    else:
        with open(dst_main, "w", encoding="utf-8") as f:
            f.write(
                "import obuvstore\n"
                "obuvstore.run_app()\n"
            )
        print("[obuvstore] ✅ main.py создан")

    # ── Итог ─────────────────────────────────────────────────
    print("\n[obuvstore] 🎉 Готово! Структура проекта:")
    print("   ├── main.py")
    print("   ├── resources/      ← положи сюда icon.ico и logo.png")
    print("   └── obuvstore/")
    print("       ├── config.py   ← меняй цвета и БД здесь")
    print("       ├── data/")
    print("       ├── database/")
    print("       └── ui/")
    print("\n   Открой obuvstore/config.py и укажи настройки БД.")
    print("   Затем запускай main.py!\n")


if __name__ == "__main__":
    init_project()
