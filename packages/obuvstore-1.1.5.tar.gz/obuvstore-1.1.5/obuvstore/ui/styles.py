"""
ui/styles.py
Генерирует QSS-стили из config.py.
Меняй цвета в config.py — стили обновятся автоматически.
"""
from obuvstore import config


def get_app_stylesheet() -> str:
    """Возвращает глобальную QSS-тему приложения."""
    bg    = config.COLOR_BG_PRIMARY
    sec   = config.COLOR_BG_SECONDARY
    acc   = config.COLOR_ACCENT
    disc  = config.COLOR_DISCOUNT
    txt   = config.COLOR_TEXT
    brd   = config.COLOR_BORDER
    font  = config.FONT_FAMILY
    fsz   = config.FONT_SIZE_NORMAL

    return f"""
/* ── Глобальные настройки ── */
QWidget {{
    font-family: "{font}";
    font-size: {fsz}pt;
    color: {txt};
    background-color: {bg};
}}

/* ── Главное окно ── */
QMainWindow, QDialog {{
    background-color: {bg};
}}

/* ── Заголовки секций ── */
QLabel#sectionTitle {{
    font-size: {config.FONT_SIZE_TITLE}pt;
    font-weight: bold;
    color: {txt};
    padding: 6px 0px;
}}

/* ── Строка меню ── */
QMenuBar {{
    background-color: {sec};
    color: {txt};
    font-size: {fsz}pt;
    padding: 2px;
}}
QMenuBar::item:selected {{
    background-color: {acc};
    border-radius: 4px;
}}
QMenu {{
    background-color: {bg};
    border: 1px solid {brd};
}}
QMenu::item:selected {{
    background-color: {acc};
}}

/* ── Панель инструментов ── */
QToolBar {{
    background-color: {sec};
    spacing: 6px;
    padding: 4px;
    border-bottom: 1px solid {brd};
}}
QToolButton {{
    background-color: transparent;
    border: none;
    padding: 4px 8px;
    border-radius: 4px;
    font-family: "{font}";
    font-size: {fsz}pt;
}}
QToolButton:hover {{
    background-color: {acc};
}}

/* ── Кнопки ── */
QPushButton {{
    background-color: {sec};
    color: {txt};
    border: 1px solid {brd};
    border-radius: 5px;
    padding: 6px 16px;
    font-family: "{font}";
    font-size: {fsz}pt;
}}
QPushButton:hover {{
    background-color: {acc};
}}
QPushButton:pressed {{
    background-color: {disc};
    color: #ffffff;
}}
QPushButton#btnAccent {{
    background-color: {acc};
    font-weight: bold;
}}
QPushButton#btnDanger {{
    background-color: #e74c3c;
    color: #ffffff;
    border: none;
}}
QPushButton#btnDanger:hover {{
    background-color: #c0392b;
}}

/* ── Поля ввода ── */
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTextEdit {{
    background-color: {bg};
    border: 1px solid {brd};
    border-radius: 4px;
    padding: 4px 8px;
    font-family: "{font}";
    font-size: {fsz}pt;
}}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus,
QDoubleSpinBox:focus, QTextEdit:focus {{
    border: 1px solid {acc};
}}

/* ── Таблица ── */
QTableWidget {{
    gridline-color: {brd};
    border: 1px solid {brd};
    alternate-background-color: #f9f9f9;
    selection-background-color: {acc};
    selection-color: {txt};
}}
QHeaderView::section {{
    background-color: {sec};
    font-weight: bold;
    padding: 6px;
    border: none;
    border-right: 1px solid {brd};
    font-family: "{font}";
    font-size: {fsz}pt;
}}
QTableWidget::item {{
    padding: 4px 8px;
}}

/* ── Вкладки ── */
QTabWidget::pane {{
    border: 1px solid {brd};
}}
QTabBar::tab {{
    background-color: #ececec;
    padding: 6px 20px;
    border: 1px solid {brd};
    border-bottom: none;
    font-family: "{font}";
}}
QTabBar::tab:selected {{
    background-color: {sec};
    font-weight: bold;
}}

/* ── Статус-бар ── */
QStatusBar {{
    background-color: {sec};
    color: {txt};
    font-size: {config.FONT_SIZE_SMALL}pt;
}}

/* ── Панель входа ── */
QFrame#loginFrame {{
    background-color: {bg};
    border: 2px solid {sec};
    border-radius: 10px;
}}
"""


# Цвет строки таблицы при скидке > 15%
DISCOUNT_ROW_COLOR = config.COLOR_DISCOUNT
DISCOUNT_ROW_TEXT  = "#ffffff"
