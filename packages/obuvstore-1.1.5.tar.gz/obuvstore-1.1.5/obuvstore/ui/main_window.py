"""
ui/main_window.py — Главное окно с меню и модулями (Модуль 1 + 2)
Доступ по ролям: Гость / Клиент / Менеджер / Администратор
"""
import os
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget,
    QTableWidgetItem, QLabel, QLineEdit, QPushButton, QComboBox,
    QHeaderView, QAction, QToolBar, QStatusBar, QMessageBox,
    QDialog, QFormLayout, QDoubleSpinBox, QSpinBox, QTextEdit,
    QTabWidget
)
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QFont, QIcon, QColor

from obuvstore import config
from obuvstore.ui.styles import DISCOUNT_ROW_COLOR, DISCOUNT_ROW_TEXT
from obuvstore.database import connection as db


# ─────────────────────────────────────────────────────────────
#  Диалог добавления / редактирования товара
# ─────────────────────────────────────────────────────────────
class ProductDialog(QDialog):
    def __init__(self, product: dict = None, parent=None):
        super().__init__(parent)
        self.product = product
        self.setWindowTitle("Товар" if not product else f"Редактировать: {product['name']}")
        self.setMinimumWidth(400)
        self._build()

    def _build(self):
        layout = QFormLayout(self)
        layout.setSpacing(10)

        self.name_edit  = QLineEdit(self.product["name"]  if self.product else "")
        self.brand_edit = QLineEdit(self.product["brand"] if self.product else "")

        self.price_spin = QDoubleSpinBox()
        self.price_spin.setRange(0, 999999)
        self.price_spin.setPrefix("₽ ")
        self.price_spin.setValue(float(self.product["price"]) if self.product else 0)

        self.disc_spin = QDoubleSpinBox()
        self.disc_spin.setRange(0, 100)
        self.disc_spin.setSuffix(" %")
        self.disc_spin.setValue(float(self.product["discount"]) if self.product else 0)

        self.stock_spin = QSpinBox()
        self.stock_spin.setRange(0, 99999)
        self.stock_spin.setValue(int(self.product["stock"]) if self.product else 0)

        layout.addRow("Название:", self.name_edit)
        layout.addRow("Бренд:", self.brand_edit)
        layout.addRow("Цена:", self.price_spin)
        layout.addRow("Скидка:", self.disc_spin)
        layout.addRow("Остаток:", self.stock_spin)

        btn_row = QHBoxLayout()
        btn_ok = QPushButton("Сохранить")
        btn_ok.setObjectName("btnAccent")
        btn_ok.clicked.connect(self.accept)
        btn_cancel = QPushButton("Отмена")
        btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(btn_ok)
        btn_row.addWidget(btn_cancel)
        layout.addRow(btn_row)

    def get_data(self) -> dict:
        return {
            "name":     self.name_edit.text().strip(),
            "brand":    self.brand_edit.text().strip(),
            "price":    self.price_spin.value(),
            "discount": self.disc_spin.value(),
            "stock":    self.stock_spin.value(),
        }


# ─────────────────────────────────────────────────────────────
#  Вкладка «Товары»
# ─────────────────────────────────────────────────────────────
class ProductsTab(QWidget):
    COLUMNS = ["ID", "Название", "Бренд", "Категория", "Цена", "Скидка %", "Остаток"]

    def __init__(self, role: str, parent=None):
        super().__init__(parent)
        self.role = role
        self._build()
        self.refresh()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        # ── Заголовок ──
        title = QLabel("Каталог товаров")
        title.setObjectName("sectionTitle")
        layout.addWidget(title)

        # ── Панель фильтрации (только менеджер и выше) ──
        if self.role in ("Менеджер", "Администратор"):
            flt = QHBoxLayout()
            self.search_edit = QLineEdit()
            self.search_edit.setPlaceholderText("Поиск по названию / бренду…")
            self.search_edit.textChanged.connect(self.refresh)

            self.sort_combo = QComboBox()
            self.sort_combo.addItems(["Название ↑", "Название ↓",
                                      "Цена ↑", "Цена ↓", "Скидка ↓"])
            self.sort_combo.currentIndexChanged.connect(self.refresh)

            btn_refresh = QPushButton("Обновить")
            btn_refresh.clicked.connect(self.refresh)

            flt.addWidget(QLabel("Поиск:"))
            flt.addWidget(self.search_edit, 3)
            flt.addWidget(QLabel("Сортировка:"))
            flt.addWidget(self.sort_combo, 2)
            flt.addWidget(btn_refresh)
            layout.addLayout(flt)

        # ── Таблица ──
        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        layout.addWidget(self.table)

        # ── Кнопки (только администратор) ──
        if self.role == "Администратор":
            btns = QHBoxLayout()
            btn_add  = QPushButton("➕ Добавить")
            btn_edit = QPushButton("✏️ Редактировать")
            btn_del  = QPushButton("🗑 Удалить")
            btn_del.setObjectName("btnDanger")
            btn_add.clicked.connect(self._add)
            btn_edit.clicked.connect(self._edit)
            btn_del.clicked.connect(self._delete)
            btns.addWidget(btn_add)
            btns.addWidget(btn_edit)
            btns.addWidget(btn_del)
            btns.addStretch()
            layout.addLayout(btns)

    # ── Данные ───────────────────────────────────────────────
    def refresh(self):
        search = ""
        sort_by, sort_dir = "name", "ASC"
        if self.role in ("Менеджер", "Администратор"):
            search = self.search_edit.text()
            idx = self.sort_combo.currentIndex()
            mapping = [("name","ASC"),("name","DESC"),
                       ("price","ASC"),("price","DESC"),("discount","DESC")]
            sort_by, sort_dir = mapping[idx]

        products = db.get_all_products(search=search, sort_by=sort_by, sort_dir=sort_dir)
        self.products = products
        self.table.setRowCount(0)
        for row_idx, p in enumerate(products):
            self.table.insertRow(row_idx)
            values = [
                p["product_id"], p["name"], p["brand"] or "",
                p.get("category_name") or "", f"₽ {p['price']:.2f}",
                f"{p['discount']:.1f}%", p["stock"]
            ]
            for col, val in enumerate(values):
                item = QTableWidgetItem(str(val))
                item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(row_idx, col, item)

            # ── Подсветка скидки > 15% ──────────────────────
            if float(p["discount"]) > 15:
                for col in range(len(self.COLUMNS)):
                    self.table.item(row_idx, col).setBackground(
                        QColor(DISCOUNT_ROW_COLOR))
                    self.table.item(row_idx, col).setForeground(
                        QColor(DISCOUNT_ROW_TEXT))

    def _selected_product(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Выбор", "Выберите товар в таблице.")
            return None
        return self.products[row]

    def _add(self):
        dlg = ProductDialog(parent=self)
        if dlg.exec_() == QDialog.Accepted:
            d = dlg.get_data()
            db.add_product(d["name"], None, d["brand"],
                           d["price"], d["discount"], d["stock"])
            self.refresh()

    def _edit(self):
        p = self._selected_product()
        if not p:
            return
        dlg = ProductDialog(product=p, parent=self)
        if dlg.exec_() == QDialog.Accepted:
            d = dlg.get_data()
            db.update_product(p["product_id"], d["name"], p.get("category_id"),
                              d["brand"], d["price"], d["discount"], d["stock"])
            self.refresh()

    def _delete(self):
        p = self._selected_product()
        if not p:
            return
        reply = QMessageBox.question(
            self, "Удаление",
            f"Удалить товар «{p['name']}»?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            db.delete_product(p["product_id"])
            self.refresh()


# ─────────────────────────────────────────────────────────────
#  Вкладка «Заказы»
# ─────────────────────────────────────────────────────────────
class OrdersTab(QWidget):
    COLUMNS = ["ID", "Пользователь", "Статус", "Сумма", "Дата"]
    STATUSES = ["Новый", "В обработке", "Выполнен", "Отменён"]

    def __init__(self, role: str, parent=None):
        super().__init__(parent)
        self.role = role
        self._build()
        self.refresh()

    def _build(self):
        layout = QVBoxLayout(self)

        title = QLabel("Заказы")
        title.setObjectName("sectionTitle")
        layout.addWidget(title)

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        layout.addWidget(self.table)

        if self.role == "Администратор":
            btns = QHBoxLayout()
            self.status_combo = QComboBox()
            self.status_combo.addItems(self.STATUSES)
            btn_change = QPushButton("Изменить статус")
            btn_change.setObjectName("btnAccent")
            btn_change.clicked.connect(self._change_status)
            btns.addWidget(QLabel("Новый статус:"))
            btns.addWidget(self.status_combo)
            btns.addWidget(btn_change)
            btns.addStretch()
            layout.addLayout(btns)

    def refresh(self):
        orders = db.get_all_orders()
        self.orders = orders
        self.table.setRowCount(0)
        for i, o in enumerate(orders):
            self.table.insertRow(i)
            vals = [
                o["order_id"],
                o.get("full_name") or o["login"],
                o["status"],
                f"₽ {o['total_price']:.2f}" if o["total_price"] else "—",
                str(o["created_at"])[:16],
            ]
            for col, val in enumerate(vals):
                item = QTableWidgetItem(str(val))
                item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(i, col, item)

    def _change_status(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Выбор", "Выберите заказ.")
            return
        order = self.orders[row]
        db.update_order_status(order["order_id"], self.status_combo.currentText())
        self.refresh()


# ─────────────────────────────────────────────────────────────
#  Главное окно
# ─────────────────────────────────────────────────────────────
class MainWindow(QMainWindow):
    def __init__(self, user: dict = None):
        """
        user — dict из БД (None → режим гостя)
        """
        super().__init__()
        self.user = user
        self.role = user["role_name"] if user else "Гость"
        self.setWindowTitle(f"{config.WINDOW_TITLE} — {self.role}")
        self.setMinimumSize(config.WINDOW_MIN_W, config.WINDOW_MIN_H)
        if os.path.exists(config.ICON_APP):
            self.setWindowIcon(QIcon(config.ICON_APP))
        self._build_menu()
        self._build_toolbar()
        self._build_central()
        self._build_statusbar()

    # ── Меню ─────────────────────────────────────────────────
    def _build_menu(self):
        menubar = self.menuBar()

        # Файл
        file_menu = menubar.addMenu("Файл")
        act_exit = QAction("Выход", self)
        act_exit.setShortcut("Ctrl+Q")
        act_exit.triggered.connect(self.close)
        file_menu.addAction(act_exit)

        # Данные — только авторизованным
        if self.role != "Гость":
            data_menu = menubar.addMenu("Данные")
            act_refresh = QAction("Обновить", self)
            act_refresh.setShortcut("F5")
            act_refresh.triggered.connect(self._refresh_current)
            data_menu.addAction(act_refresh)

        # Помощь
        help_menu = menubar.addMenu("Справка")
        act_about = QAction("О программе", self)
        act_about.triggered.connect(self._show_about)
        help_menu.addAction(act_about)

    # ── Панель инструментов с иконками ───────────────────────
    def _build_toolbar(self):
        tb = QToolBar("Главная панель")
        tb.setIconSize(QSize(24, 24))
        tb.setMovable(False)
        self.addToolBar(tb)

        def _action(icon_char: str, label: str, slot=None):
            btn = QAction(f"{icon_char}  {label}", self)
            if slot:
                btn.triggered.connect(slot)
            tb.addAction(btn)
            return btn

        _action("🏠", "Главная")
        tb.addSeparator()

        if self.role in ("Менеджер", "Администратор"):
            _action("🔄", "Обновить", self._refresh_current)

        if self.role == "Администратор":
            tb.addSeparator()
            _action("➕", "Добавить товар", self._add_product_shortcut)
            _action("📦", "Добавить заказ")

        tb.addSeparator()
        _action("🚪", "Выход", self.close)

        # Информация о пользователе справа
        spacer = QWidget()
        spacer.setSizePolicy(
            spacer.sizePolicy().horizontalPolicy(),  # type: ignore
            spacer.sizePolicy().verticalPolicy()
        )
        from PyQt5.QtWidgets import QSizePolicy
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        tb.addWidget(spacer)
        user_label = QLabel(
            f"👤 {self.user['full_name'] if self.user else 'Гость'}  |  {self.role}"
        )
        user_label.setStyleSheet("padding-right: 12px; font-weight: bold;")
        tb.addWidget(user_label)

    # ── Центральная область (вкладки) ─────────────────────────
    def _build_central(self):
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        # Вкладка «Товары» — всем
        self.products_tab = ProductsTab(role=self.role)
        self.tabs.addTab(self.products_tab, "📋 Товары")

        # Вкладка «Заказы» — менеджер и выше
        if self.role in ("Менеджер", "Администратор"):
            self.orders_tab = OrdersTab(role=self.role)
            self.tabs.addTab(self.orders_tab, "🛒 Заказы")

    # ── Статус-бар ───────────────────────────────────────────
    def _build_statusbar(self):
        sb = QStatusBar()
        self.setStatusBar(sb)
        role_label = QLabel(f"Роль: {self.role}")
        sb.addPermanentWidget(role_label)
        sb.showMessage("Добро пожаловать в ООО «Обувь»!", 5000)

    # ── Вспомогательные слоты ────────────────────────────────
    def _refresh_current(self):
        widget = self.tabs.currentWidget()
        if hasattr(widget, "refresh"):
            widget.refresh()

    def _add_product_shortcut(self):
        self.tabs.setCurrentWidget(self.products_tab)
        if hasattr(self.products_tab, "_add"):
            self.products_tab._add()

    def _show_about(self):
        QMessageBox.information(
            self, "О программе",
            f"{config.WINDOW_TITLE}\n"
            "Информационная система магазина обуви\n\n"
            f"Сервер БД: {config.DB_HOST}:{config.DB_PORT}\n"
            f"База данных: {config.DB_NAME}"
        )
