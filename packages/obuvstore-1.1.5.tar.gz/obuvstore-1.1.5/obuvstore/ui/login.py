"""
ui/login.py  — Форма авторизации (Модуль 1)
"""
import os
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QMessageBox, QFrame, QSpacerItem,
    QSizePolicy
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QPixmap, QFont, QIcon

from obuvstore import config
from obuvstore.database.connection import get_user_by_login


class LoginDialog(QDialog):
    """
    Первое окно приложения.
    Сигналы:
      login_success(user_dict) — пользователь вошёл
      guest_mode()             — просмотр без авторизации
    """
    login_success = pyqtSignal(dict)
    guest_mode    = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(config.WINDOW_TITLE + " — Вход")
        self.setFixedSize(420, 500)
        if os.path.exists(config.ICON_APP):
            self.setWindowIcon(QIcon(config.ICON_APP))
        self._build_ui()

    # ── Построение интерфейса ─────────────────────────────────
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(30, 20, 30, 20)
        root.setSpacing(0)

        # ── Логотип ──
        logo_label = QLabel()
        logo_label.setAlignment(Qt.AlignCenter)
        if os.path.exists(config.LOGO_FILE):
            pix = QPixmap(config.LOGO_FILE).scaledToWidth(
                180, Qt.SmoothTransformation
            )
            logo_label.setPixmap(pix)
        else:
            logo_label.setText("🥿 ООО «Обувь»")
            logo_label.setFont(QFont(config.FONT_FAMILY, config.FONT_SIZE_TITLE, QFont.Bold))
            logo_label.setAlignment(Qt.AlignCenter)
        root.addWidget(logo_label)
        root.addSpacing(16)

        # ── Заголовок ──
        title = QLabel("Вход в систему")
        title.setObjectName("sectionTitle")
        title.setAlignment(Qt.AlignCenter)
        root.addWidget(title)
        root.addSpacing(20)

        # ── Карточка формы ──
        frame = QFrame()
        frame.setObjectName("loginFrame")
        fl = QVBoxLayout(frame)
        fl.setContentsMargins(24, 24, 24, 24)
        fl.setSpacing(14)

        fl.addWidget(QLabel("Логин"))
        self.login_edit = QLineEdit()
        self.login_edit.setPlaceholderText("Введите логин")
        fl.addWidget(self.login_edit)

        fl.addWidget(QLabel("Пароль"))
        self.pass_edit = QLineEdit()
        self.pass_edit.setPlaceholderText("Введите пароль")
        self.pass_edit.setEchoMode(QLineEdit.Password)
        fl.addWidget(self.pass_edit)

        self.btn_login = QPushButton("Войти")
        self.btn_login.setObjectName("btnAccent")
        self.btn_login.setMinimumHeight(38)
        self.btn_login.clicked.connect(self._handle_login)
        fl.addWidget(self.btn_login)

        root.addWidget(frame)
        root.addSpacing(16)

        # ── Кнопка гостя ──
        self.btn_guest = QPushButton("Продолжить как гость")
        self.btn_guest.setFixedHeight(36)
        self.btn_guest.clicked.connect(self._handle_guest)
        root.addWidget(self.btn_guest)

        root.addStretch()

        # Enter → войти
        self.pass_edit.returnPressed.connect(self._handle_login)

    # ── Логика ───────────────────────────────────────────────
    def _handle_login(self):
        login    = self.login_edit.text().strip()
        password = self.pass_edit.text().strip()

        if not login or not password:
            QMessageBox.warning(self, "Ошибка", "Введите логин и пароль.")
            return

        user = get_user_by_login(login, password)
        if user:
            self.login_success.emit(user)
            self.accept()
        else:
            QMessageBox.critical(self, "Отказано", "Неверный логин или пароль.")
            self.pass_edit.clear()
            self.pass_edit.setFocus()

    def _handle_guest(self):
        self.guest_mode.emit()
        self.accept()
