import sys
from setuptools import setup

if sys.platform == "win32":
    # On Windows the NSIS installer handles file placement.
    # pip install only delivers the Python package itself.
    data_files = []
else:
    # Linux: place example config and service template in /opt/hawk/etc/.
    # hawk-soard -install copies the service template to /etc/systemd/system/
    # with the correct ExecStart path patched in.
    data_files = [
        ("/opt/hawk/etc", [
            "etc/hawk-soard.cfg.example",
            "etc/hawk-soard.service",
        ]),
    ]

setup(data_files=data_files)
