
import os
import traceback

import time
import json

from multiprocessing import Queue, Event, Process
from queue import Empty
from concurrent.futures import ThreadPoolExecutor


from hawkSoar.common.plugin import import_plugins
from hawkSoar.common.logger import get_logger

from hawkSoar.common.process import ExceptionSafeProcess
from hawkSoar.objects.workflow import InvestigateObject


class Scheduler(object):
    """ This Scheduler processes request for Ingest objects. """

    def __init__(self, name, config, db_interface=None):
        self.name = name
        self.logger = get_logger()
        self.config = config
        self.plugins = {}
        self.db_interface = db_interface
        self.stop_condition = Event()
        self.outgoing_queue = Queue()
        self.incoming_queue = Queue()  # For plugins to put events to be analyzed
        self.plugin_processes = []
        self.load_plugins()
        self.start_result_collector()
        self.start_scheduling_process()

    def shutdown(self):
        """ Shutdown the scheduler and all loaded plugins."""
        self.logger.debug("Scheduler[%s]: Shutting down..." % self.name)
        self.set_stop()

        plugins = self.get_plugins()
        if plugins:
            for _, plugin in plugins.items():
                try:
                    self.logger.debug(
                        "Scheduler[%s]: Calling shutdown for: %s..." % (self.name, _))
                    with ThreadPoolExecutor() as executor:
                        executor.submit(plugin.shutdown)
                    plugin.shutdown()
                except Exception as e:
                    self.logger.exception(e)

                plugin.kill()

        self.logger.debug("Scheduler[%s]: Calling shutdown for: %d processes" % (
            self.name, len(self.plugin_processes)))
        if self.plugin_processes:
            for plugin_process in self.plugin_processes:
                plugin_process.shutdown()
                plugin_process.join()
                plugin_process.terminate()

        self.logger.debug(
            "Scheduler[%s]: waiting for schedule process to complete..." % self.name)

        """
        with ThreadPoolExecutor() as executor:
            if self.schedule_process:
                executor.submit(self.schedule_process.join)
        """
        self.logger.debug(
            "Scheduler[%s]: Calling schedule process terminate..." % self.name)
        self.schedule_process.terminate()

        self.logger.debug(
            "Scheduler[%s]: waiting for result collector process to complete..." % self.name)
        """
        with ThreadPoolExecutor() as executor:
            executor.submit(self.result_collector_process.join)
        """
        self.result_collector_process.terminate()

        try:
            if getattr(self.db_interface, 'shutdown', False):
                self.logger.debug(
                    "Scheduler: executing db shutdown process...")
                self.db_interface.shutdown()
        except Exception as e:
            self.logger.debug("Scheduler shutdown exception: %s, %s" %
                              (e, traceback.format_exc()))

        self.outgoing_queue.close()
        self.incoming_queue.close()
        self.logger.info('Scheduler[%s] shutdown completed' % self.name)

    def register_plugin(self, name, plugin_instance):
        """ This function is called when plugin initializes to announce itself"""
        self.plugins[name] = plugin_instance

    def load_plugins(self):
        raise NotImplementedError

    def get_plugins(self):
        return self.plugins

    def get_list_of_available_plugins(self):
        """ Returns a list of all loaded plugins """
        plugin_list = list(self.plugins.keys())
        return sorted(plugin_list, key=str.lower)

    def get_plugin_dict(self):
        """ Returns a dictionary of plugins with the following format:
        {NAME: (DESCRIPTION, PLUGIN_TYPE, VERSION)}
        """
        result = {}
        plugin_list = self.get_list_of_available_plugins()
        if not plugin_list:
            raise Exception("No plugins available")

        for plugin in plugin_list:
            result[plugin] = (self.plugins[plugin].DESCRIPTION,
                              self.plugins[plugin].TYPE, self.plugins[plugin].VERSION)
            self.logger.info("Successfully loaded plugin: %s (%s) %s (%s)" % (
                plugin, self.plugins[plugin].DESCRIPTION,  self.plugins[plugin].VERSION,  self.plugins[plugin].TYPE))

        return result

    def start_scheduling_process(self):
        self.logger.debug('Starting %s scheduler...' % (self.name))
        self.schedule_process = ExceptionSafeProcess(
            # self.schedule_process = Process(
            target=self.scheduler, process_name=self.name + ' (scheduler)',
            args=(self.stop_condition,)
        )
        self.schedule_process.start()

    def start_result_collector(self):
        # noisy
        # self.logger.debug('Starting plugin result collector')
        self.result_collector_process = ExceptionSafeProcess(
            # self.result_collector_process = Process(
            target=self.result_collector,
            process_name=self.name + ' (collector)',
            args=(self.stop_condition,)
        )
        self.result_collector_process.start()

    def get_response(self):
        try:
            return self.outgoing_queue.get_nowait()
        except:
            return None

    # assign all playbooks locally, which is then each is iterated and the matching steps are then assigned locally
    def set_playbooks(self, playbooks):
        # for each playbook
        # for each playbook step
        # - for each plugin:
        #   - if step matches both MODULE and plugin ID
        #       - add step and step config to specific plugin

        for playbook in playbooks:
            if not 'enabled' in playbook or playbook['enabled'] == False:
                continue

            for step in playbook['workspace']:
                if not 'enabled' in step or step['enabled'] == False:
                    # ignore
                    continue

                # self.logger.debug(step)
                if step['type'] == 'action':
                    for _, plugin in self.get_plugins().items():
                        if step['module'] == plugin.MODULE:
                            # now does id match?
                            # now for each enalbed module
                            # {'id': 'BVWLGDIP', 'editable': True, 'edgeType': 'round', 'type': 'action', 'module': 'playbook.ingest.Events', 'name': 'Ingest Events', 'description': 'vstream events', 'enabled': True, 'priorty': 'Critical', 'tags': ['vstream', 'kafka'], 'previous': 'A', 'text': 'Ingest Events', 'tooltip': 'vstream events', 'data': [], 'next': ['AWAIMWOB', 'YPKLPUCX'], 'style': ''}
                            if not plugin.ID in step['config']:
                                self.logger.warn("Scheduler: no configuration found for plugin (%s) %s, playbook: %s, step: %s, ignoring..." % (
                                    plugin.ID, plugin.NAME, playbook.name, step.name))
                                continue

                            stepConfig = step['config'][plugin.ID]
                            # this may be called in the wrong context
                            plugin.add_playbook_step(
                                playbook, step, stepConfig)

                elif step['type'] == 'match':
                    # only 1 match plugin exists and it lives internally
                    stepConfig = step
                    for _, plugin in self.get_plugins().items():
                        # only 1 type
                        if plugin.TYPE == 'match':
                            plugin.add_playbook_step(
                                playbook, step, stepConfig)
                            break

                elif step['type'] == 'decision':
                    # only 1 match plugin exists and it lives internally
                    # self.logger.debug(step)
                    stepConfig = step
                    for _, plugin in self.get_plugins().items():
                        # only 1 type
                        if plugin.TYPE == 'decision':
                            plugin.add_playbook_step(
                                playbook, step, stepConfig)
                            break

    def set_task(self, plugin, task):
        # XXX: find out in task object which plugin it goes to, and place this request only in that plugin or set of plugins (can be duplicated?)
        # plugin = 'dummy' # example
        """
        with ThreadPoolExecutor() as executor:
            executor.submit(self.plugins[plugin].set_task, task)
        """
        # shared process ipc queue
        self.plugins[plugin].set_task(task)

    def get_task(self):
        try:
            return self.incoming_queue.get(False, 1)
        except:
            return None

    def process_task(self, task):
        if not task:
            return

        # print("Task, checking module: %s" % task['module'])
        module = task['module']
        for _, plugin in self.get_plugins().items():
            if plugin.MODULE == module:
                # TODO: Make sure the plugin gets the task and processes it.
                return plugin.set_task(task)

        # XXX:
        # send back to api so it can be ensured its processed?
        raise Exception(
            "Task assigned, but no plugin available to process request.")

    def set_stop(self):
        # self.logger.debug("Scheduler setting stop condition")
        self.stop_condition.set()

    def result_collector(self, stop_condition):

        while not stop_condition.is_set():
            # self.logger.debug("Collector[%s] processing..." % self.name)
            pause = True
            for plugin in self.plugins:
                try:
                    obj = self.plugins[plugin].outgoing_queue.get(False, 1)
                except Empty:
                    continue
                else:
                    pause = False
                    # process the output of the plugin

                    # XXX
                    # check if next step is disabled, if so discard it
                    self.outgoing_queue.put(obj)
            if pause:
                time.sleep(int(self.config['block_delay']))

        self.logger.debug("Collector[%s] halted." % self.name)

    def scheduler(self, stop_condition):

        while not stop_condition.is_set():
            # self.logger.debug("Scheduler[%s]: incoming task request..." % self.name)
            task = self.get_task()
            if not task:
                time.sleep(0.01)
                continue

            try:
                self.process_task(task)
            except Exception as e:
                self.logger.exception(e)

    def start(self):
        """Start the scheduler processes if not already running."""
        if not self.schedule_process.is_alive():
            self.start_scheduling_process()
        if not self.result_collector_process.is_alive():
            self.start_result_collector()

    def get_scheduled_workload(self):
        """Return the current workload for this scheduler."""
        workload = {
            'scheduler': self.name,
            'incoming_queue_size': 0,
            'outgoing_queue_size': 0,
            'plugins': {},
            'processes': {
                'scheduler_alive': self.schedule_process.is_alive() if self.schedule_process else False,
                'collector_alive': self.result_collector_process.is_alive() if self.result_collector_process else False,
            },
        }
        try:
            workload['incoming_queue_size'] = self.incoming_queue.qsize()
        except Exception:
            pass
        try:
            workload['outgoing_queue_size'] = self.outgoing_queue.qsize()
        except Exception:
            pass
        for name, plugin in self.plugins.items():
            plugin_workload = {}
            if hasattr(plugin, 'incoming_queue'):
                try:
                    plugin_workload['queue'] = plugin.incoming_queue.qsize()
                except Exception:
                    pass
            if hasattr(plugin, 'active'):
                try:
                    plugin_workload['active'] = sum(
                        plugin.active[i].value for i in range(plugin.thread_count))
                except Exception:
                    pass
            workload['plugins'][name] = plugin_workload
        return workload


if __name__ == '__main__':
    pass
