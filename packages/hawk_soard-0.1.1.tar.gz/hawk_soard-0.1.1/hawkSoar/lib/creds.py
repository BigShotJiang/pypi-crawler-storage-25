import logging
import os

from hawkSoar.common.logger import get_logger
logger = get_logger("lib.creds")

# hvac is the official HashiCorp Vault Python client.
# Install: pip install hvac
try:
    import hvac
    _HVAC_AVAILABLE = True
except ImportError:
    _HVAC_AVAILABLE = False


class credsAPI(object):
    """Retrieve credentials from HashiCorp Vault.

    Supports three auth methods, tried in priority order:
      1. Token auth  (vault_token in config)
      2. AppRole     (vault_role_id + vault_secret_id in config)
      3. Userpass    (vault_username + vault_password in config)

    Config keys (all under [SETTINGS]):
        vault_url       - Vault server URL, e.g. https://vault.example.com:8200
        vault_token     - Static token (simplest; fine for service accounts)
        vault_role_id   - AppRole role_id
        vault_secret_id - AppRole secret_id
        vault_username  - Userpass username
        vault_password  - Userpass password
        vault_namespace - Enterprise namespace (optional)
        vault_ca_cert   - Path to CA cert bundle for TLS verification (optional)
    """

    def __init__(self, config=None):
        self.config = config or {}
        self._client = None

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def get_credentials(self, path, key=None):
        """Read a secret from Vault.

        Args:
            path (str): KV secret path, e.g. ``"secret/data/hawk/db"``
                        or ``"secret/hawk/db"`` for KV v1.
            key  (str): If given, return only this key from the secret dict.
                        If None, return the full ``data`` dict.

        Returns:
            dict or str: The secret data or a single value.

        Raises:
            RuntimeError: If hvac is not installed or Vault is unreachable.
            KeyError: If ``key`` is specified but not found in the secret.
        """
        client = self._get_client()
        try:
            # Try KV v2 first (most common in modern Vault deployments)
            secret = client.secrets.kv.v2.read_secret_version(path=path)
            data = secret["data"]["data"]
        except Exception:
            try:
                # Fall back to KV v1
                secret = client.secrets.kv.v1.read_secret(path=path)
                data = secret["data"]
            except Exception as e:
                logger.error("Failed to read Vault secret at %s: %s", path, e)
                raise

        if key is not None:
            return data[key]
        return data

    def list_secrets(self, path):
        """List secret keys at a Vault path.

        Args:
            path (str): KV path prefix.

        Returns:
            list[str]: Key names found at that path.
        """
        client = self._get_client()
        try:
            result = client.secrets.kv.v2.list_secrets(path=path)
            return result["data"]["keys"]
        except Exception:
            result = client.secrets.kv.v1.list_secrets(path=path)
            return result["data"]["keys"]

    def is_authenticated(self):
        """Return True if the current Vault client has a valid token."""
        try:
            return self._get_client().is_authenticated()
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_client(self):
        if not _HVAC_AVAILABLE:
            raise RuntimeError(
                "hvac is required for Vault credential support. "
                "Install it with: pip install hvac"
            )
        if self._client and self._client.is_authenticated():
            return self._client
        self._client = self._build_client()
        return self._client

    def _build_client(self):
        url = self.config.get("vault_url") or os.environ.get("VAULT_ADDR")
        if not url:
            raise RuntimeError(
                "vault_url is not set in config and VAULT_ADDR env var is not set."
            )

        namespace = self.config.get(
            "vault_namespace") or os.environ.get("VAULT_NAMESPACE")
        ca_cert = self.config.get(
            "vault_ca_cert") or os.environ.get("VAULT_CACERT")

        client = hvac.Client(
            url=url,
            namespace=namespace,
            verify=ca_cert if ca_cert else True,
        )

        # 1. Token auth
        token = self.config.get("vault_token") or os.environ.get("VAULT_TOKEN")
        if token:
            client.token = token
            logger.debug("Vault: using token auth")
            return client

        # 2. AppRole auth
        role_id = self.config.get(
            "vault_role_id") or os.environ.get("VAULT_ROLE_ID")
        secret_id = self.config.get(
            "vault_secret_id") or os.environ.get("VAULT_SECRET_ID")
        if role_id and secret_id:
            client.auth.approle.login(role_id=role_id, secret_id=secret_id)
            logger.debug("Vault: authenticated via AppRole")
            return client

        # 3. Userpass auth
        username = self.config.get(
            "vault_username") or os.environ.get("VAULT_USERNAME")
        password = self.config.get(
            "vault_password") or os.environ.get("VAULT_PASSWORD")
        if username and password:
            client.auth.userpass.login(username=username, password=password)
            logger.debug("Vault: authenticated via userpass")
            return client

        # 4. OctoRepl secrets_manager
        try:
            from octorepl.secrets_manager import get_vault_token as _octo_get_vault_token
            octo_token = _octo_get_vault_token()
            if octo_token:
                client.token = octo_token
                logger.debug(
                    "Vault: using token provided by OctoRepl secrets_manager")
                return client
        except ImportError:
            pass  # OctoRepl not installed on this node — skip silently

        raise RuntimeError(
            "No Vault auth method configured. Set vault_token, "
            "(vault_role_id + vault_secret_id), (vault_username + vault_password) "
            "in config or environment variables, or store a token via OctoRepl "
            "secrets_manager.set_vault_token()."
        )
