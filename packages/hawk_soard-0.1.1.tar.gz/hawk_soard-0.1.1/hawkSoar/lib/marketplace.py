import logging
import os

import requests

from hawkSoar.common.logger import get_logger

logger = get_logger("lib.marketplace")


class marketplaceAPI(object):
    """Client for the HAWK marketplace plugin API.

    Mirrors the auth pattern used by ``hawkSoar.lib.auth.Authentication``:
    uses a ``requests.Session`` with token auth against the configured server.

    Config keys (passed as a dict):
        server          - Base URL of the HAWK server, e.g. ``https://ir.hawk.io``
        access_token    - AMY access token
        secret_key      - AMY secret key
        insecure        - If True, TLS verification is skipped (default False)
        data_path       - Local path where downloaded plugins are stored
    """

    MARKETPLACE_PATH = "/api/marketplace"
    PLUGIN_DOWNLOAD_PATH = "/api/marketplace/plugin/download"

    def __init__(self, config=None):
        self.config = config or {}
        self._session = None
        self._token = None
        self._base_url = None

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------

    def login(self):
        """Authenticate against the HAWK server and obtain a session token.

        Returns:
            bool: True on success.

        Raises:
            RuntimeError: If authentication fails.
        """
        servers = self.config.get("server", [])
        if isinstance(servers, str):
            servers = [servers]
        if not servers:
            raise RuntimeError("No server URL configured.")

        self._base_url = servers[0].rstrip("/")
        verify = not self.config.get("insecure", False)

        self._session = requests.Session()
        self._session.verify = verify

        url = f"{self._base_url}/api/auth/token"
        payload = {
            "access_token": self.config.get("access_token", ""),
            "secret_key": self.config.get("secret_key", ""),
        }

        try:
            resp = self._session.post(url, json=payload, timeout=30)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            logger.error("Marketplace login failed: %s", e)
            raise RuntimeError("Marketplace login failed: %s" % e)

        self._token = data.get("token") or data.get("access_token")
        if not self._token:
            raise RuntimeError(
                "Marketplace login: no token in response: %s" % data)

        self._session.headers.update(
            {"Authorization": "Bearer %s" % self._token})
        logger.info("Marketplace login successful")
        return True

    # ------------------------------------------------------------------
    # Remote queries
    # ------------------------------------------------------------------

    def query_plugins(self):
        """Return all plugins available in the marketplace for this account.

        Returns:
            list[dict]: Each dict describes a marketplace plugin.
        """
        self._ensure_session()
        url = f"{self._base_url}{self.MARKETPLACE_PATH}/plugins"
        try:
            resp = self._session.get(url, timeout=30)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            logger.error("query_plugins failed: %s", e)
            return []

    # ------------------------------------------------------------------
    # Local queries
    # ------------------------------------------------------------------

    def query_local_plugins(self, filter=None):
        """List plugins installed locally.

        Args:
            filter (str): One of ``"active"``, ``"deactivated"``, or ``"all"``
                          (default: ``"all"``).

        Returns:
            list[dict]: Each dict has at least ``plugin_id``, ``plugin_name``,
                        ``active``, and ``data_path`` keys.
        """
        data_path = self.config.get("data_path", "/opt/hawk/data")
        plugins = []

        if not os.path.isdir(data_path):
            return plugins

        for category in os.listdir(data_path):
            cat_path = os.path.join(data_path, category)
            if not os.path.isdir(cat_path):
                continue
            for plugin_name in os.listdir(cat_path):
                plugin_path = os.path.join(cat_path, plugin_name)
                if not os.path.isdir(plugin_path):
                    continue
                active = os.path.exists(os.path.join(plugin_path, "enabled"))
                record = {
                    "plugin_name": plugin_name,
                    "category": category,
                    "data_path": plugin_path,
                    "active": active,
                }
                if filter == "active" and not active:
                    continue
                if filter == "deactivated" and active:
                    continue
                plugins.append(record)

        return plugins

    def get_new_plugins(self):
        """Return marketplace plugins not yet installed locally.

        Returns:
            list[dict]: Marketplace plugin records that are not present locally.
        """
        remote = self.query_plugins()
        local_names = {p["plugin_name"]
                       for p in self.query_local_plugins(filter="all")}
        return [p for p in remote if p.get("plugin_name") not in local_names]

    # ------------------------------------------------------------------
    # Download / install
    # ------------------------------------------------------------------

    def download_plugin(self, uuid=None, plugin_name=None):
        """Download and install a plugin from the marketplace.

        Args:
            uuid (str): Plugin UUID from ``query_plugins()``.
            plugin_name (str): Alternatively identify the plugin by name.

        Returns:
            str: Path to the installed plugin directory on success.

        Raises:
            ValueError: If neither uuid nor plugin_name is given.
            RuntimeError: If the download or install fails.
        """
        if not uuid and not plugin_name:
            raise ValueError("Provide either uuid or plugin_name.")

        self._ensure_session()
        params = {}
        if uuid:
            params["uuid"] = uuid
        if plugin_name:
            params["name"] = plugin_name

        url = f"{self._base_url}{self.PLUGIN_DOWNLOAD_PATH}"
        try:
            resp = self._session.get(
                url, params=params, timeout=60, stream=True)
            resp.raise_for_status()
        except Exception as e:
            logger.error("download_plugin failed: %s", e)
            raise RuntimeError("Plugin download failed: %s" % e)

        # Determine install path from Content-Disposition or plugin metadata
        content_disp = resp.headers.get("Content-Disposition", "")
        filename = None
        for part in content_disp.split(";"):
            part = part.strip()
            if part.startswith("filename="):
                filename = part[len("filename="):].strip('"')
                break
        if not filename:
            filename = (uuid or plugin_name) + ".zip"

        data_path = self.config.get("data_path", "/opt/hawk/data")
        tmp_path = os.path.join(data_path, filename)

        os.makedirs(data_path, exist_ok=True)
        with open(tmp_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=65536):
                if chunk:
                    f.write(chunk)

        # Unzip into data_path
        import zipfile
        try:
            with zipfile.ZipFile(tmp_path, "r") as zf:
                # Expect top-level structure: <category>/<plugin_name>/...
                install_dir = data_path
                zf.extractall(install_dir)
            os.remove(tmp_path)
            logger.info("Plugin installed to %s", install_dir)
            return install_dir
        except zipfile.BadZipFile as e:
            raise RuntimeError("Downloaded plugin archive is invalid: %s" % e)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _ensure_session(self):
        if self._session is None or self._token is None:
            self.login()
