import unittest
from unittest import mock
from hawkSoar.lib.auth import Authentication


class FakeResponse(object):
    # default response attributes
    status_code = 200
    content = "Some content"

    def __init__(self, status, content):
        self.status_code = status
        self.content = content

    def json(self):
        import json
        return json.loads(self.content)


class TestAuth(unittest.TestCase):

    def test_auth_init(self):
        a = Authentication("https://localhost:8443")
        a.setVerify(False)
        a.setPrivateKey("/tmp/hawk-soard-test.key")
        a.setPublicKey("/tmp/hawk-soard-test.key")
        a.setUUIDFile("/tmp/hawk-soard-test-client-id")
        self.assertEqual(a.verify, False)

    def test_login_api_user(self):
        a = Authentication("https://localhost:8443")
        a.setVerify(False)
        a.setUUIDFile("/tmp/hawk-soard-test-client-id")

        with mock.patch.object(a.Session, 'post') as mock_request:
            fake_response = FakeResponse(
                200,
                '{"status": true, "data": {"@class": "Nodes", "group": "96edb385-650a-46d3-ae19-cd9e369f5a4a", "id": "26ec338e-c99f-43ba-a8e4-5baf95e269b1"}}',
            )
            mock_request.return_value = fake_response
            self.assertEqual(a.loginApiUser("test_access_token", "test_secret_key"), True)
            self.assertEqual(a.tokenData, {"access_token": "api_token_session"})

    def test_login_api_user_missing_credentials(self):
        a = Authentication("https://localhost:8443")
        with self.assertRaises(Exception) as ctx:
            a.loginApiUser("", "secret")
        self.assertIn("requires access_token and secret_key", str(ctx.exception))

        with self.assertRaises(Exception) as ctx:
            a.loginApiUser("token", "")
        self.assertIn("requires access_token and secret_key", str(ctx.exception))

    def test_get_parent_group(self):
        a = Authentication("https://localhost:8443")
        a.profile = {"group": "test-group"}
        self.assertEqual(a.getParentGroup(), "test-group")

    def test_get_parent_group_no_profile(self):
        a = Authentication("https://localhost:8443")
        a.profile = None
        with self.assertRaises(Exception) as ctx:
            a.getParentGroup()
        self.assertIn("profile is unavailable", str(ctx.exception))

    def test_get_parent_group_no_group_key(self):
        a = Authentication("https://localhost:8443")
        a.profile = {"other": "value"}
        with self.assertRaises(Exception) as ctx:
            a.getParentGroup()
        self.assertIn("does not include group", str(ctx.exception))

    def test_uuid_file_round_trip(self):
        import tempfile
        import os
        a = Authentication("https://localhost:8443")
        with tempfile.NamedTemporaryFile(mode='w', suffix='.id', delete=False) as f:
            f.write('6ebc3468-3eae-4bc5-b17f-0ef84ada4c0b\n')
            tmp_path = f.name
        try:
            a.setUUIDFile(tmp_path)
            self.assertEqual(a.getUUID(), '6ebc3468-3eae-4bc5-b17f-0ef84ada4c0b')
        finally:
            os.unlink(tmp_path)

    def test_uuid_file_generates_when_missing(self):
        import tempfile
        import os
        a = Authentication("https://localhost:8443")
        fd, tmp_path = tempfile.mkstemp(suffix='.id')
        os.close(fd)
        os.unlink(tmp_path)
        try:
            a.setUUIDFile(tmp_path)
            uuid_val = a.getUUID()
            self.assertTrue(len(uuid_val) > 0)
            with open(tmp_path) as f:
                self.assertEqual(f.read().strip(), uuid_val)
        finally:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)


if __name__ == '__main__':
    unittest.main()
