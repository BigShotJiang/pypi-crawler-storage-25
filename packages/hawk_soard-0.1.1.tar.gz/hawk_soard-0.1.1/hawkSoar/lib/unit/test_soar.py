"""
Unit tests for soarAPI WebSocket reconnection, re-authentication, node profile
enrichment, and per-node channel subscription.

Regression coverage for the infinite reconnect storm bug:

    BEFORE FIX:
        WebSocketApp was built *once* before the reconnect loop, baking in the
        session cookie from the initial login().  When the server expired that
        session the reconnect loop kept calling run_forever() on the same stale
        WebSocketApp.  The server immediately rejected every new connection
        (expired cookie → HTTP 401/close), producing the observed rapid
        connect/subscribe/disconnect storm logged in production.

    AFTER FIX:
        _build_ws() calls self.login() before constructing each WebSocketApp,
        so every reconnect attempt carries a freshly authenticated session cookie.
"""
import json
import socket
import unittest
from unittest import mock

from hawkSoar.lib.soar import soarAPI


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _config():
    return {
        'server': ['https://localhost:8443'],
        'websocket_server': ['wss://localhost:8443'],
        'insecure': True,
        'debug': False,
        'access_token': 'test-access',
        'secret_key': 'test-secret-key',
        'client_id_file': None,
        'private_key': None,
        'public_key': None,
    }


def _make_api():
    """Build a soarAPI with a fully mocked Authentication object."""
    with mock.patch('hawkSoar.lib.soar.Authentication') as MockAuth, \
            mock.patch('hawkSoar.lib.soar.Queue', side_effect=lambda: mock.MagicMock()):
        mock_auth = mock.MagicMock()
        mock_auth.Session = mock.MagicMock()
        mock_auth.Session.cookies.get_dict.return_value = {
            'session': 'cookie-0'}
        mock_auth.getParentGroup.return_value = 'test-group'
        MockAuth.return_value = mock_auth
        api = soarAPI(_config())
    return api, mock_auth


def _patched_login(api, mock_auth):
    """
    Replace api.login with a mock that bumps the cookie value on every call,
    simulating the server issuing a fresh session token each time.
    Returns the mock so call counts can be inspected.
    """
    call_count = [0]

    def _login():
        call_count[0] += 1
        mock_auth.Session.cookies.get_dict.return_value = {
            'session': 'cookie-%d' % call_count[0]
        }
        return True

    login_mock = mock.MagicMock(side_effect=_login)
    api.login = login_mock
    api.authObj = mock_auth
    return login_mock, call_count


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestSoarWebsocketReauth(unittest.TestCase):

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_login_called_before_initial_connect(self, _sleep):
        """login() is called exactly once before the first WebSocket connect."""
        api, mock_auth = _make_api()
        login_mock, call_count = _patched_login(api, mock_auth)

        def fake_run_forever(**kw):
            api.isRunning = False  # immediate disconnect

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp') as MockWS:
            ws = mock.MagicMock()
            ws.run_forever.side_effect = fake_run_forever
            MockWS.return_value = ws
            api.run_loop(lambda msg: None)

        self.assertEqual(call_count[0], 1,
                         "login() must be called once before the first WebSocket connection")

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_login_called_again_after_disconnect(self, _sleep):
        """
        REGRESSION: login() must be called again after every disconnect.

        Without re-auth the reconnect loop reuses the original WebSocketApp
        with its expired cookie.  The server rejects the connection immediately
        on every attempt, creating an infinite connect/disconnect storm.
        """
        api, mock_auth = _make_api()
        login_mock, call_count = _patched_login(api, mock_auth)

        disconnect_count = [0]

        def fake_run_forever(**kw):
            disconnect_count[0] += 1
            if disconnect_count[0] >= 2:
                api.isRunning = False  # stop after one reconnect

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp') as MockWS:
            ws = mock.MagicMock()
            ws.run_forever.side_effect = fake_run_forever
            MockWS.return_value = ws
            api.run_loop(lambda msg: None)

        self.assertEqual(call_count[0], 2,
                         "login() must be called for the initial connect AND every reconnect; "
                         "failing to re-auth caused the observed infinite reconnect storm")

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_fresh_cookies_used_on_reconnect(self, _sleep):
        """
        REGRESSION: each WebSocketApp must be built with freshly authenticated
        cookies.

        The old code baked the original cookie into a single WebSocketApp
        instance that was reused forever.  The server would see the same expired
        cookie on every reconnect and close the socket immediately.
        """
        api, mock_auth = _make_api()
        _patched_login(api, mock_auth)

        cookies_at_construction = []
        disconnect_count = [0]

        def make_ws(url, on_message, on_error, on_close, cookie):
            cookies_at_construction.append(cookie)
            ws = mock.MagicMock()

            def fake_run(**kw):
                disconnect_count[0] += 1
                if disconnect_count[0] >= 2:
                    api.isRunning = False

            ws.run_forever.side_effect = fake_run
            return ws

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp', side_effect=make_ws):
            api.run_loop(lambda msg: None)

        self.assertEqual(len(cookies_at_construction), 2,
                         "WebSocketApp should be constructed twice: initial connect + one reconnect")

        self.assertNotEqual(
            cookies_at_construction[0],
            cookies_at_construction[1],
            "Reconnect must carry a new session cookie from a fresh login(); "
            "reusing the stale cookie is what caused the infinite reconnect storm"
        )
        self.assertIn('cookie-1', cookies_at_construction[0],
                      "First connect should use the cookie from the first login()")
        self.assertIn('cookie-2', cookies_at_construction[1],
                      "Reconnect should use the cookie from the second login(), not cookie-1")

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_reauth_failure_retries_and_uses_extended_sleep(self, mock_sleep):
        """
        If re-authentication throws after a disconnect the loop must log the
        error, sleep for the extended backoff period, and retry — not crash.
        """
        api, mock_auth = _make_api()
        login_count = [0]

        def fake_login():
            login_count[0] += 1
            if login_count[0] == 2:
                raise Exception("Auth server unreachable")
            # First login and third login succeed; third also ends the loop
            if login_count[0] >= 3:
                api.isRunning = False
            mock_auth.Session.cookies.get_dict.return_value = {
                'session': 'cookie-%d' % login_count[0]
            }
            return True

        api.login = mock.MagicMock(side_effect=fake_login)
        api.authObj = mock_auth

        disconnect_count = [0]

        def make_ws(url, on_message, on_error, on_close, cookie):
            ws = mock.MagicMock()

            def fake_run(**kw):
                disconnect_count[0] += 1
                # Safety cap: stop the loop if login() never drives termination
                # (e.g. when running against buggy code that never calls login).
                if disconnect_count[0] >= 10:
                    api.isRunning = False

            ws.run_forever.side_effect = fake_run
            return ws

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp', side_effect=make_ws):
            api.run_loop(lambda msg: None)

        self.assertGreaterEqual(login_count[0], 3,
                                "After a failed re-auth the loop must retry login()")
        mock_sleep.assert_any_call(5)

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_no_reconnect_after_shutdown(self, _sleep):
        """Calling shutdown() (isRunning=False) must stop the reconnect loop."""
        api, mock_auth = _make_api()
        _patched_login(api, mock_auth)

        ws_build_count = [0]
        disconnect_count = [0]

        def make_ws(url, on_message, on_error, on_close, cookie):
            ws_build_count[0] += 1
            ws = mock.MagicMock()

            def fake_run(**kw):
                disconnect_count[0] += 1
                api.isRunning = False  # simulate shutdown on first disconnect

            ws.run_forever.side_effect = fake_run
            return ws

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp', side_effect=make_ws):
            api.run_loop(lambda msg: None)

        self.assertEqual(ws_build_count[0], 1,
                         "After shutdown (isRunning=False) no second WebSocketApp should be built")


class TestNodeProfile(unittest.TestCase):

    def test_node_profile_includes_platform(self):
        """build_node_profile() must include a 'platform' key for octorepl scoring."""
        api, _ = _make_api()
        profile = api.build_node_profile()
        self.assertIn('platform', profile)
        self.assertIsInstance(profile['platform'], str)
        self.assertGreater(len(profile['platform']), 0)


class TestHybridSubscriptionShapes(unittest.TestCase):

    def test_subscribe_node_channel_uses_hybrid_task_contract(self):
        api, mock_auth = _make_api()
        mock_auth.getUUID.return_value = 'node-123'
        mock_auth.getParentGroup.return_value = 'group-123'
        api.authObj = mock_auth
        api.send_response = mock.MagicMock()

        api.subscribe_node_channel()

        api.send_response.assert_called_once()
        payload = json.loads(api.send_response.call_args[0][0])
        self.assertEqual(
            payload,
            {
                'id': mock.ANY,
                'cmd': 'hybrid_task',
                'route': 'subscribeNode',
                'node_id': 'node-123',
                'group_id': 'group-123',
                'data': {},
            },
        )

    def test_subscribe_services_uses_hybrid_catalog_contract(self):
        api, mock_auth = _make_api()
        mock_auth.getParentGroup.return_value = 'group-123'
        api.authObj = mock_auth
        api.send_response = mock.MagicMock()

        api.subscribe_services()

        api.send_response.assert_called_once()
        payload = json.loads(api.send_response.call_args[0][0])
        self.assertEqual(
            payload,
            {
                'id': mock.ANY,
                'cmd': 'hybrid_catalog',
                'route': 'subscribeServices',
                'group_id': 'group-123',
                'data': {},
            },
        )

    def test_node_profile_includes_type_from_config(self):
        api, _ = _make_api()
        api.config['node_type'] = 'domain_controller'
        profile = api.build_node_profile()
        self.assertEqual(profile['type'], 'domain_controller')

    def test_node_profile_type_defaults_to_endpoint(self):
        api, _ = _make_api()
        api.config.pop('node_type', None)
        profile = api.build_node_profile()
        self.assertEqual(profile['type'], 'endpoint')

    def test_node_profile_includes_tags_from_config(self):
        api, _ = _make_api()
        api.config['tags'] = ['prod', 'finance', 'dc1']
        profile = api.build_node_profile()
        for tag in ['prod', 'finance', 'dc1']:
            self.assertIn(tag, profile['tags'])
        self.assertIsInstance(profile['tags'], list)

    def test_node_profile_tags_empty_when_not_configured(self):
        api, _ = _make_api()
        api.config.pop('tags', None)
        profile = api.build_node_profile()
        self.assertIsInstance(profile['tags'], list)
        # Auto-tags may be present; only require the field exists as a list.

    def test_node_profile_hawk_engine_true_when_configured(self):
        api, _ = _make_api()
        api.config['hawk_engine'] = True
        profile = api.build_node_profile()
        self.assertIs(profile['hawk_engine'], True)

    def test_node_profile_hawk_engine_false_by_default(self):
        api, _ = _make_api()
        api.config.pop('hawk_engine', None)
        profile = api.build_node_profile()
        self.assertIs(profile['hawk_engine'], False)

    def test_auto_tags_includes_os_platform(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar._platform.system', return_value='Linux'):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('linux', auto_tags)

    def test_auto_tags_multi_homed_when_multiple_interfaces(self):
        api, _ = _make_api()
        interfaces = [
            {'name': 'eth0', 'ip': '10.0.0.1', 'netmask': '255.255.255.0'},
            {'name': 'eth1', 'ip': '192.168.1.1', 'netmask': '255.255.255.0'},
        ]
        auto_tags = api._build_auto_tags(interfaces=interfaces)
        self.assertIn('multi-homed', auto_tags)

    def test_auto_tags_vpn_gateway_detected_by_interface_name(self):
        api, _ = _make_api()
        interfaces = [
            {'name': 'tun0', 'ip': '10.8.0.1', 'netmask': '255.255.255.0'}]
        auto_tags = api._build_auto_tags(interfaces=interfaces)
        self.assertIn('vpn-gateway', auto_tags)

    def test_auto_tags_nmap_detected_when_in_path(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.shutil.which',
                        side_effect=lambda name: '/usr/bin/nmap' if name == 'nmap' else None):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('nmap', auto_tags)

    def test_auto_tags_hawk_engine_tag_when_configured(self):
        api, _ = _make_api()
        api.config['hawk_engine'] = True
        auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('hawk-engine', auto_tags)

    def test_merged_tags_union_with_manual_tags(self):
        api, _ = _make_api()
        api.config['tags'] = ['prod']
        with mock.patch('hawkSoar.lib.soar._platform.system', return_value='Linux'):
            profile = api.build_node_profile()
        self.assertIn('prod', profile['tags'])
        self.assertIn('linux', profile['tags'])

    def test_manual_tags_preserved_no_duplicate_when_auto_tag_same(self):
        api, _ = _make_api()
        api.config['tags'] = ['linux']
        with mock.patch('hawkSoar.lib.soar._platform.system', return_value='Linux'):
            profile = api.build_node_profile()
        self.assertIn('linux', profile['tags'])
        self.assertEqual(profile['tags'].count('linux'), 1)

    # --- Additional innovative auto-tag tests ---

    def test_auto_tags_container_when_dockerenv_present(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.os.path.exists',
                        side_effect=lambda p: p == '/.dockerenv'):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('container', auto_tags)

    def test_auto_tags_container_windows_sandbox_env_var(self):
        api, _ = _make_api()
        with mock.patch.dict('os.environ',
                             {'CONTAINER_SANDBOX_MOUNT_POINT': 'C:\\ContainerMappedDirectories'}):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('container', auto_tags)

    def test_auto_tags_cloud_vm_aws_when_env_var_set(self):
        api, _ = _make_api()
        with mock.patch.dict('os.environ', {'AWS_EXECUTION_ENV': 'AWS_ECS_FARGATE'}):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('cloud-vm', auto_tags)
        self.assertIn('aws', auto_tags)

    def test_auto_tags_high_cpu_when_8_or_more_cores(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.psutil.cpu_count', return_value=16):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('high-cpu', auto_tags)

    def test_auto_tags_low_memory_when_under_2gb(self):
        api, _ = _make_api()
        mem_mock = mock.MagicMock()
        mem_mock.total = 1 * 1024 ** 3  # 1 GB
        with mock.patch('hawkSoar.lib.soar.psutil.virtual_memory', return_value=mem_mock):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('low-memory', auto_tags)

    def test_auto_tags_storage_rich_when_over_100gb_free(self):
        api, _ = _make_api()
        disk_mock = mock.MagicMock()
        disk_mock.free = 200 * 1024 ** 3  # 200 GB
        with mock.patch('hawkSoar.lib.soar.psutil.disk_usage', return_value=disk_mock):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('storage-rich', auto_tags)

    def test_auto_tags_gpu_capable_when_nvidia_smi_present(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.shutil.which',
                        side_effect=lambda n: '/usr/bin/nvidia-smi' if n == 'nvidia-smi' else None):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('gpu-capable', auto_tags)

    def test_auto_tags_docker_when_docker_in_path(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.shutil.which',
                        side_effect=lambda n: '/usr/bin/docker' if n == 'docker' else None):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('docker', auto_tags)

    def test_auto_tags_python3_when_python3_in_path(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.shutil.which',
                        side_effect=lambda n: '/usr/bin/python3' if n == 'python3' else None):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('python3', auto_tags)

    def test_auto_tags_powershell_when_pwsh_in_path(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.shutil.which',
                        side_effect=lambda n: '/usr/bin/pwsh' if n == 'pwsh' else None):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('powershell', auto_tags)

    def test_auto_tags_ipv6_capable_when_global_ipv6_present(self):
        api, _ = _make_api()
        mock_addr = mock.MagicMock()
        mock_addr.family = socket.AF_INET6
        mock_addr.address = '2001:db8::1'
        with mock.patch('hawkSoar.lib.soar.psutil.net_if_addrs',
                        return_value={'eth0': [mock_addr]}):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('ipv6-capable', auto_tags)

    def test_subscribe_node_channel_sends_subscribeNode_message(self):
        """subscribe_node_channel() must send a subscribeNode message with node_id and group_id."""
        api, mock_auth = _make_api()
        mock_auth.getUUID.return_value = 'node-uuid-123'
        mock_auth.getParentGroup.return_value = 'group-abc'
        api.authObj = mock_auth
        api.uuid = 'node-uuid-123'
        sent = []
        api.send_response = lambda msg: sent.append(
            json.loads(msg) if isinstance(msg, str) else msg)
        api.subscribe_node_channel()
        self.assertEqual(len(sent), 1)
        msg = sent[0]
        self.assertEqual(msg['cmd'], 'hybrid_task')
        self.assertEqual(msg['route'], 'subscribeNode')
        self.assertEqual(msg['node_id'], 'node-uuid-123')
        self.assertEqual(msg['group_id'], 'group-abc')

    def test_runtime_registration_messages_include_node_id(self):
        """registerApps/registerProfile must carry explicit node_id where the IR API expects it."""
        api, mock_auth = _make_api()
        mock_auth.getUUID.return_value = 'node-uuid-123'
        api.authObj = mock_auth
        api.uuid = 'node-uuid-123'
        sent = []
        api.send_response = lambda msg: sent.append(
            json.loads(msg) if isinstance(msg, str) else msg)

        api.register_apps([{"id": "hybrid-task-api"}])
        api.register_profile({"hostname": "node-a"})

        self.assertEqual(2, len(sent))
        self.assertEqual('registerApps', sent[0]['route'])
        self.assertEqual('node-uuid-123', sent[0].get('node_id'))
        self.assertEqual(
            [{"id": "hybrid-task-api", "node_id": "node-uuid-123"}],
            sent[0].get('data'),
        )
        self.assertEqual('registerProfile', sent[1]['route'])
        self.assertEqual('node-uuid-123', sent[1].get('node_id'))

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_on_open_replays_registration_callbacks_after_subscriptions(self, _sleep):
        """WebSocket on_open must replay node registration after service/node subscriptions."""
        api, mock_auth = _make_api()
        _patched_login(api, mock_auth)
        mock_auth.getUUID.return_value = 'node-uuid-123'
        mock_auth.getParentGroup.return_value = 'group-abc'
        api.authObj = mock_auth
        api.uuid = 'node-uuid-123'
        sent = []
        callback_calls = []
        api.send_response = lambda msg: sent.append(
            json.loads(msg) if isinstance(msg, str) else msg)
        api.add_on_connect_callback(lambda: callback_calls.append('ran'))

        def make_ws(url, on_message, on_error, on_close, cookie):
            ws = mock.MagicMock()

            def fake_run(**kw):
                ws.on_open(ws)
                api.isRunning = False

            ws.run_forever.side_effect = fake_run
            return ws

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp', side_effect=make_ws):
            api.run_loop(lambda msg: None)

        self.assertEqual(callback_calls, ['ran'])
        self.assertGreaterEqual(len(sent), 2)
        self.assertEqual(sent[0]['cmd'], 'hybrid_catalog')
        self.assertEqual(sent[0]['route'], 'subscribeServices')
        self.assertEqual(sent[1]['cmd'], 'hybrid_task')
        self.assertEqual(sent[1]['route'], 'subscribeNode')

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_on_open_replays_registration_callbacks_on_reconnect(self, _sleep):
        """Registration callbacks must replay on every reconnect, not just first connect."""
        api, mock_auth = _make_api()
        _patched_login(api, mock_auth)
        callback_calls = []
        api.add_on_connect_callback(lambda: callback_calls.append('ran'))

        connect_count = [0]

        def make_ws(url, on_message, on_error, on_close, cookie):
            ws = mock.MagicMock()

            def fake_run(**kw):
                connect_count[0] += 1
                ws.on_open(ws)
                if connect_count[0] >= 2:
                    api.isRunning = False

            ws.run_forever.side_effect = fake_run
            return ws

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp', side_effect=make_ws):
            api.run_loop(lambda msg: None)

        self.assertEqual(callback_calls, ['ran', 'ran'])

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_send_response_queues_failed_send_without_blocking_manager_loop(self, _sleep):
        """send_response() must not retry forever on a broken socket from the manager thread."""
        api, _mock_auth = _make_api()
        api.isRunning = True
        api.ws = mock.MagicMock()
        api.ws.send.side_effect = RuntimeError("socket closed")
        api.outgoing_queue = mock.MagicMock()
        _sleep.side_effect = lambda *_args, **_kwargs: setattr(
            api, "isRunning", False)

        response = {
            "id": "req-1",
            "cmd": "hybrid_task",
            "route": "result",
            "data": {"task_id": "task-1", "status": "FAILED"},
        }

        sent = api.send_response(response)

        self.assertFalse(sent)
        api.outgoing_queue.put.assert_called_once_with(response)
        self.assertEqual(api.ws.send.call_count, 1)
        _sleep.assert_not_called()

    def test_send_response_skips_direct_send_when_websocket_not_definitely_open(self):
        """send_response() must queue immediately when the websocket is not definitely open."""
        api, _mock_auth = _make_api()
        api.ws = mock.MagicMock()
        api.ws.sock = mock.MagicMock()
        api.ws.sock.connected = False
        api.outgoing_queue = mock.MagicMock()

        response = {
            "id": "req-2",
            "cmd": "hybrid_task",
            "route": "result",
            "data": {"task_id": "task-2", "status": "SUCCESS"},
        }

        sent = api.send_response(response)

        self.assertFalse(sent)
        api.ws.send.assert_not_called()
        api.outgoing_queue.put.assert_called_once_with(response)


class TestNodeRegistrationVisibility(unittest.TestCase):

    def test_register_profile_tracks_exact_pending_status_shape(self):
        """Tracked node registrations must expose an exact pending status shape."""
        api, mock_auth = _make_api()
        mock_auth.getUUID.return_value = 'node-uuid-123'
        api.authObj = mock_auth
        api.uuid = 'node-uuid-123'
        api.ws = mock.MagicMock()
        api.ws.send = mock.MagicMock()

        request_id = api.register_profile({"hostname": "node-a"})

        self.assertIsInstance(request_id, str)
        self.assertNotEqual('', request_id)
        self.assertEqual(
            {
                'id': request_id,
                'route': 'registerProfile',
                'node_id': 'node-uuid-123',
                'status': 'pending',
                'code': None,
                'details': None,
                'dispatched': True,
                'acknowledged': False,
                'timed_out': False,
            },
            api.get_node_registration_status(request_id),
        )

    def test_registration_response_marks_acknowledged_status_shape(self):
        """A successful nodes.register* response must mark the tracked request acknowledged."""
        api, mock_auth = _make_api()
        mock_auth.getUUID.return_value = 'node-uuid-123'
        api.authObj = mock_auth
        api.uuid = 'node-uuid-123'
        api.ws = mock.MagicMock()
        api.ws.send = mock.MagicMock()

        request_id = api.register_profile({"hostname": "node-a"})

        handled = api._handle_control_message({
            "id": request_id,
            "cmd": "nodes",
            "route": "registerProfile",
            "status": True,
            "code": 200,
            "details": "Successfully registered node profile for user-1.",
            "data": {
                "nodeId": "node-uuid-123",
                "group": "group-abc",
                "profile_id": "node-uuid-123",
                "available_tasks_count": 3,
            },
        })

        self.assertIs(True, handled)
        self.assertEqual(
            {
                'id': request_id,
                'route': 'registerProfile',
                'node_id': 'node-uuid-123',
                'status': 'acknowledged',
                'code': 200,
                'details': 'Successfully registered node profile for user-1.',
                'dispatched': True,
                'acknowledged': True,
                'timed_out': False,
            },
            api.get_node_registration_status(request_id),
        )

    def test_registration_timeout_marks_timeout_and_logs_error(self):
        """Timed out registration requests must become visible failures, not silent hangs."""
        api, mock_auth = _make_api()
        mock_auth.getUUID.return_value = 'node-uuid-123'
        api.authObj = mock_auth
        api.uuid = 'node-uuid-123'
        api.ws = mock.MagicMock()
        api.ws.send = mock.MagicMock()
        api.logging = mock.MagicMock()

        request_id = api.register_hybrid_tools({
            "node_id": "node-uuid-123",
            "group_id": "group-abc",
            "catalog_version": "1.0.0",
            "tools": [],
        })

        api._mark_node_registration_timeout(request_id)

        self.assertEqual(
            {
                'id': request_id,
                'route': 'registerHybridTools',
                'node_id': 'node-uuid-123',
                'status': 'timeout',
                'code': None,
                'details': 'Timed out waiting for acknowledgement from backend.',
                'dispatched': True,
                'acknowledged': False,
                'timed_out': True,
            },
            api.get_node_registration_status(request_id),
        )
        api.logging.error.assert_called()


class TestNodeRegistrationFlow(unittest.TestCase):
    """Step-by-step walk through the node registration lifecycle.

    Each test covers one discrete state transition so failures pinpoint
    exactly which step broke:

        Step 1  queue    → status='pending',  dispatched=False
        Step 2  dispatch → status='pending',  dispatched=True
        Step 3a ack      → status='acknowledged'
        Step 3b timeout  → status='timeout'
        Step 3c reject   → status='rejected'
        Step 3d late-ack → status='acknowledged', warning logged
    """

    def _api(self):
        api, mock_auth = _make_api()
        mock_auth.getUUID.return_value = 'node-uuid-123'
        api.authObj = mock_auth
        api.uuid = 'node-uuid-123'
        api.ws = mock.MagicMock()
        api.ws.send = mock.MagicMock()
        api.logging = mock.MagicMock()
        return api

    # ------------------------------------------------------------------
    # Step 1: _track_node_registration sets status=pending, dispatched=False
    # ------------------------------------------------------------------

    def test_step1_track_sets_pending_before_send(self):
        """_track_node_registration must set status=pending before the WS send."""
        api = self._api()
        # Build the message manually (same shape as register_apps internally does)
        from uuid import uuid4
        msg = {
            "id": str(uuid4()),
            "cmd": "nodes",
            "route": "registerApps",
            "node_id": "node-uuid-123",
            "data": [],
        }
        request_id = api._track_node_registration(msg)

        status = api.get_node_registration_status(request_id)
        self.assertEqual(status["status"], "pending")
        self.assertFalse(status["dispatched"])
        self.assertFalse(status["acknowledged"])
        self.assertFalse(status["timed_out"])

    # ------------------------------------------------------------------
    # Step 2: send_response calls _mark_node_registration_dispatched
    # ------------------------------------------------------------------

    def test_step2_dispatch_marks_dispatched_true(self):
        """After send_response() the tracker must show dispatched=True."""
        api = self._api()
        request_id = api.register_apps(
            [{"app_id": "app-1", "node_id": "node-uuid-123"}])

        status = api.get_node_registration_status(request_id)
        self.assertTrue(status["dispatched"],
                        "dispatched must be True immediately after send_response(); "
                        "if False the WS send path is not calling _mark_node_registration_dispatched")

    def test_step2_register_hybrid_tools_dispatch(self):
        api = self._api()
        request_id = api.register_hybrid_tools({
            "node_id": "node-uuid-123",
            "group_id": "group-abc",
            "catalog_version": "1.0.0",
            "tools": [],
        })
        self.assertTrue(api.get_node_registration_status(
            request_id)["dispatched"])

    def test_step2_register_profile_dispatch(self):
        api = self._api()
        request_id = api.register_profile(
            {"hostname": "node-a", "os": "windows"})
        self.assertTrue(api.get_node_registration_status(
            request_id)["dispatched"])

    # ------------------------------------------------------------------
    # Step 3a: server ACK → acknowledged
    # ------------------------------------------------------------------

    def _ack(self, request_id, route, status=True, code=200,
             details="OK", node_id="node-uuid-123"):
        return {
            "id": request_id,
            "cmd": "nodes",
            "route": route,
            "status": status,
            "code": code,
            "details": details,
            "data": {"nodeId": node_id},
        }

    def test_step3a_ack_register_apps(self):
        """Server ACK for registerApps must transition tracker to acknowledged."""
        api = self._api()
        request_id = api.register_apps([{"app_id": "app-1"}])

        handled = api._handle_control_message(
            self._ack(request_id, "registerApps"))

        self.assertTrue(handled)
        status = api.get_node_registration_status(request_id)
        self.assertEqual(status["status"], "acknowledged")
        self.assertTrue(status["acknowledged"])
        self.assertEqual(status["code"], 200)

    def test_step3a_ack_register_hybrid_tools(self):
        api = self._api()
        request_id = api.register_hybrid_tools({
            "node_id": "node-uuid-123", "tools": []})

        api._handle_control_message(
            self._ack(request_id, "registerHybridTools"))

        self.assertEqual(
            api.get_node_registration_status(request_id)["status"],
            "acknowledged")

    def test_step3a_ack_register_profile(self):
        api = self._api()
        request_id = api.register_profile({"hostname": "node-a"})

        api._handle_control_message(
            self._ack(request_id, "registerProfile",
                      details="Successfully registered node profile."))

        status = api.get_node_registration_status(request_id)
        self.assertEqual(status["status"], "acknowledged")
        self.assertEqual(status["details"],
                         "Successfully registered node profile.")

    def test_step3a_ack_cancels_timeout_timer(self):
        """ACK received before the timer fires must cancel the timer."""
        api = self._api()
        api._node_registration_timeout = 60  # long timeout so it won't fire
        request_id = api.register_apps([])

        # Timer must be registered before ACK
        with api._node_registration_lock:
            self.assertIn(request_id, api._node_registration_timers)

        api._handle_control_message(self._ack(request_id, "registerApps"))

        # Timer must be gone after ACK
        with api._node_registration_lock:
            self.assertNotIn(request_id, api._node_registration_timers)

    # ------------------------------------------------------------------
    # Step 3b: no response within timeout → timeout fires
    # ------------------------------------------------------------------

    def test_step3b_timeout_fires_on_short_deadline(self):
        """Timer must fire and mark timeout when no ACK arrives."""
        import threading

        api = self._api()
        api._node_registration_timeout = 0.05  # 50 ms for test speed

        timed_out = threading.Event()
        original = api._mark_node_registration_timeout

        def capture(request_id):
            original(request_id)
            timed_out.set()

        api._mark_node_registration_timeout = capture

        request_id = api.register_profile({"hostname": "node-b"})
        self.assertTrue(timed_out.wait(timeout=2),
                        "Timer did not fire within 2 s; check _schedule_node_registration_timeout")

        status = api.get_node_registration_status(request_id)
        self.assertEqual(status["status"], "timeout")
        self.assertTrue(status["timed_out"])

    def test_step3b_manual_timeout_marks_all_fields(self):
        api = self._api()
        request_id = api.register_apps([])

        api._mark_node_registration_timeout(request_id)

        self.assertEqual(
            api.get_node_registration_status(request_id),
            {
                'id': request_id,
                'route': 'registerApps',
                'node_id': 'node-uuid-123',
                'status': 'timeout',
                'code': None,
                'details': 'Timed out waiting for acknowledgement from backend.',
                'dispatched': True,
                'acknowledged': False,
                'timed_out': True,
            },
        )
        api.logging.error.assert_called()

    def test_step3b_timeout_noop_if_already_acked(self):
        """Timer firing after ACK must not overwrite acknowledged status."""
        api = self._api()
        request_id = api.register_apps([])

        api._handle_control_message(self._ack(request_id, "registerApps"))
        api._mark_node_registration_timeout(request_id)

        self.assertEqual(
            api.get_node_registration_status(request_id)["status"],
            "acknowledged",
            "Timeout must not clobber an already-acknowledged registration")

    # ------------------------------------------------------------------
    # Step 3c: server explicit rejection (status falsy)
    # ------------------------------------------------------------------

    def test_step3c_server_rejection_marks_rejected(self):
        """A response with status=False must mark the tracker as rejected."""
        api = self._api()
        request_id = api.register_apps([])

        api._handle_control_message({
            "id": request_id,
            "cmd": "nodes",
            "route": "registerApps",
            "status": False,
            "code": 403,
            "details": "Node not authorized.",
        })

        status = api.get_node_registration_status(request_id)
        self.assertEqual(status["status"], "rejected")
        self.assertFalse(status["acknowledged"])
        self.assertEqual(status["code"], 403)
        api.logging.error.assert_called()

    # ------------------------------------------------------------------
    # Step 3d: late ACK (after timeout has already fired)
    # ------------------------------------------------------------------

    def test_step3d_late_ack_after_timeout_logs_warning(self):
        """An ACK arriving after timeout must log a warning, not an info message."""
        api = self._api()
        request_id = api.register_apps([])

        # Simulate timeout firing first
        api._mark_node_registration_timeout(request_id)
        self.assertEqual(
            api.get_node_registration_status(request_id)["status"], "timeout")

        # Now ACK arrives late
        api._handle_control_message(self._ack(request_id, "registerApps"))

        # Status updated to acknowledged despite being late
        self.assertEqual(
            api.get_node_registration_status(request_id)["status"],
            "acknowledged")
        api.logging.warning.assert_called()

    # ------------------------------------------------------------------
    # _handle_control_message routing
    # ------------------------------------------------------------------

    def test_handle_control_message_passes_through_non_dict(self):
        api = self._api()
        self.assertFalse(api._handle_control_message("not-a-dict"))
        self.assertFalse(api._handle_control_message(None))
        self.assertFalse(api._handle_control_message(42))

    def test_handle_control_message_passes_through_wrong_cmd(self):
        api = self._api()
        self.assertFalse(api._handle_control_message({
            "id": "req-1", "cmd": "hybrid_catalog",
            "route": "registerApps", "status": True}))

    def test_handle_control_message_passes_through_unknown_route(self):
        api = self._api()
        self.assertFalse(api._handle_control_message({
            "id": "req-1", "cmd": "nodes",
            "route": "unknownRoute", "status": True}))

    def test_handle_control_message_returns_true_for_all_registration_routes(self):
        api = self._api()
        for route in ("registerApps", "registerHybridTools", "registerProfile"):
            # No tracker registered — _record_node_registration_result returns False
            # but _handle_control_message still returns the inner result, which is
            # False when no tracker is found.  Verify it does NOT raise and DOES
            # return a bool (not None / not raising).
            result = api._handle_control_message({
                "id": "unknown-req", "cmd": "nodes",
                "route": route, "status": True})
            self.assertIsInstance(result, bool,
                                  "Expected bool for route=%s, got %r" % (route, result))

    # ------------------------------------------------------------------
    # on_message integration: ACK consumed before the main callback
    # ------------------------------------------------------------------

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_on_message_ack_consumed_before_user_callback(self, _sleep):
        """A nodes registration ACK must NOT reach the user message callback."""
        api = self._api()
        _patched_login(api, mock_auth:= mock.MagicMock())
        api.authObj = mock_auth
        mock_auth.getParentGroup.return_value = 'group-abc'
        mock_auth.getUUID.return_value = 'node-uuid-123'
        api.uuid = 'node-uuid-123'

        user_messages = []
        request_id = api.register_profile({"hostname": "node-a"})

        ack_json = json.dumps(self._ack(request_id, "registerProfile"))

        # Simulate the on_message path directly (bypass run_loop)
        import json as _json
        data = _json.loads(ack_json)
        consumed = api._handle_control_message(data)

        if not consumed:
            user_messages.append(data)

        self.assertTrue(consumed,
                        "Registration ACK must be consumed by _handle_control_message; "
                        "if False the ACK would reach the user callback and not update tracker")
        self.assertEqual(user_messages, [],
                         "Registration ACK must not reach the user callback")

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_on_message_non_registration_reaches_user_callback(self, _sleep):
        """Non-registration messages must pass through to the user callback."""
        api = self._api()

        hybrid_task_msg = {
            "id": "task-1",
            "cmd": "hybrid_task",
            "route": "dispatch",
            "action": "ping",
            "data": {},
        }
        consumed = api._handle_control_message(hybrid_task_msg)
        self.assertFalse(consumed,
                         "Non-registration messages must not be consumed by _handle_control_message")

    # ------------------------------------------------------------------
    # register_apps node_id propagation into app records
    # ------------------------------------------------------------------

    def test_register_apps_injects_node_id_into_app_records(self):
        """register_apps must stamp node_id into each app dict that lacks one."""
        api = self._api()
        sent_payloads = []
        api.ws.send.side_effect = lambda p: sent_payloads.append(json.loads(p))

        api.register_apps([
            {"app_id": "app-1"},
            {"app_id": "app-2", "node_id": "existing-node"},
        ])

        self.assertEqual(len(sent_payloads), 1)
        records = sent_payloads[0]["data"]
        self.assertEqual(records[0]["node_id"], "node-uuid-123",
                         "node_id must be injected into app records that lack one")
        self.assertEqual(records[1]["node_id"], "existing-node",
                         "existing node_id must not be overwritten by register_apps")


class TestGetUUIDWhitespaceBug(unittest.TestCase):
    """
    Regression tests for getUUID() stripping whitespace from the UUID file.

    On Windows, text files frequently end with a trailing newline.  The
    original f.read() call returned the raw file contents including that
    newline, so the node UUID propagated through the system with a '\n'
    suffix.  The server's OrientDB UPSERT received a malformed node ID,
    threw a synchronous exception, and routes.js closed the socket before
    sending an ACK — every registration timed out on the client side.

    These tests confirm:
      1. getUUID() strips trailing '\n'  (Unix-style files)
      2. getUUID() strips trailing '\r\n' (Windows CRLF files, after Python
         text-mode converts \r\n → \n on read, the \n must still be stripped)
      3. getUUID() strips leading/trailing whitespace generally
      4. A freshly written UUID file is re-read cleanly (no double-strip issue)
    """

    def _auth_pointing_at(self, tmp_path):
        """Return an Authentication instance whose clientIdFile is tmp_path."""
        from hawkSoar.lib.auth import Authentication
        with mock.patch('hawkSoar.lib.auth.requests.Session'):
            auth = Authentication.__new__(Authentication)
            auth.uuid = None
            auth.clientIdFile = tmp_path
            auth.Session = mock.MagicMock()
            auth.tokenData = {}
            auth.profile = {}
            auth.verify = True
            auth.apiUrl = 'https://localhost:8443'
        return auth

    def test_uuid_file_with_trailing_newline(self):
        """getUUID() must strip trailing \\n from the UUID file contents."""
        import tempfile
        import os
        raw_uuid = '6ebc3468-3eae-4bc5-b17f-0ef84ada4c0b'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.id', delete=False) as f:
            f.write(raw_uuid + '\n')
            tmp = f.name
        try:
            auth = self._auth_pointing_at(tmp)
            result = auth.getUUID()
            self.assertEqual(result, raw_uuid,
                             "getUUID() must strip trailing \\n — Windows node IDs were "
                             "being sent with embedded newlines, breaking server UPSERT")
        finally:
            os.unlink(tmp)

    def test_uuid_file_with_crlf(self):
        """getUUID() must strip trailing \\r\\n (Windows CRLF files opened in binary-written form)."""
        import tempfile
        import os
        raw_uuid = 'aabbccdd-1234-5678-9abc-def012345678'
        # Write the file in binary mode so the \r\n is literal on disk,
        # then Python text-mode read converts \r\n → \n, leaving \n to strip.
        with tempfile.NamedTemporaryFile(mode='wb', suffix='.id', delete=False) as f:
            f.write((raw_uuid + '\r\n').encode())
            tmp = f.name
        try:
            auth = self._auth_pointing_at(tmp)
            result = auth.getUUID()
            self.assertEqual(result, raw_uuid,
                             "getUUID() must strip \\r\\n from UUID files written with Windows line endings")
        finally:
            os.unlink(tmp)

    def test_uuid_file_with_surrounding_whitespace(self):
        """getUUID() must strip leading and trailing whitespace of any kind."""
        import tempfile
        import os
        raw_uuid = 'deadbeef-dead-beef-dead-beefdeadbeef'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.id', delete=False) as f:
            f.write('  ' + raw_uuid + '  \n')
            tmp = f.name
        try:
            auth = self._auth_pointing_at(tmp)
            result = auth.getUUID()
            self.assertEqual(result, raw_uuid,
                             "getUUID() must strip all surrounding whitespace from UUID file")
        finally:
            os.unlink(tmp)

    def test_uuid_file_clean_no_whitespace(self):
        """getUUID() must still work correctly when the file has no trailing whitespace."""
        import tempfile
        import os
        raw_uuid = '11111111-2222-3333-4444-555555555555'
        with tempfile.NamedTemporaryFile(mode='w', suffix='.id', delete=False) as f:
            f.write(raw_uuid)
            tmp = f.name
        try:
            auth = self._auth_pointing_at(tmp)
            result = auth.getUUID()
            self.assertEqual(result, raw_uuid,
                             "getUUID() must return unchanged UUID when file has no trailing whitespace")
        finally:
            os.unlink(tmp)


if __name__ == '__main__':
    unittest.main()
