#!/usr/bin/python3

import sys
import os
import logging
import requests
from urllib.parse import urlencode
from io import BytesIO
import ujson
import uuid
import socket
import platform
import time
from cryptography.hazmat.primitives import serialization as crypto_serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend as crypto_default_backend

from hawkSoar.common.logger import get_logger
logger = get_logger("lib.auth")


class Authentication(object):
    uuid = None
    apiUrl = None
    verify = True
    Session = None

    tokenData = None

    clientIdFile = '/opt/hawk/etc/hawk-soard-id'

    globalKey = None

    privateKeyFilename = '/opt/hawk/etc/hawk-soard.key'
    privateKey = None

    publicKey = None
    publicKeyFilename = '/opt/hawk/etc/hawk-soard.pub'
    profile = None

    def __init__(self, apiUrl):
        self.apiUrl = apiUrl
        self.Session = requests.Session()
        self.profile = {}

    def setVerify(self, b=True):
        self.verify = self.Session.verify = b

    def setUUIDFile(self, f):
        self.clientIdFile = f

    def getUUID(self):

        if self.uuid:
            return self.uuid

        try:
            with open(self.clientIdFile) as f:
                self.uuid = f.read().strip()
                f.close()
                return self.uuid
        except:
            pass

        # generate
        self.uuid = str(uuid.uuid4())
        with open(self.clientIdFile, 'w') as f:
            f.write(self.uuid)
            f.close()

        return self.uuid

    def __getDeviceInfo(self):
        # TODO: move to common.common.py from common.common import get_device_info, call hostname, address, platform = get_device_info()
        self.tokenData['hostname'] = socket.gethostname()
        self.tokenData['address'] = socket.gethostbyname(
            self.tokenData['hostname'])
        """
        # new cpe implementation in future
        syst = platform.system().lower()
        if syst == 'windows':
            plat = "microsoft"
        elif syst == "osx":
            plat = "mac"
        elif syst == "linux":
            plat = "linux"
        self.tokenData['platform'] = 'cpe:/o:' + plat.lower() + ':' + platform.platform().replace("-","_") + "::" + platform.version().lower()
        """
        self.tokenData['platform'] = os.name + "/" + \
            platform.system() + " " + platform.release()

    def getParentGroup(self):
        if not isinstance(self.profile, dict):
            raise Exception("Authentication profile is unavailable.")
        if 'group' not in self.profile:
            raise Exception("Authentication profile does not include group.")
        return self.profile['group']

    def loginApiUser(self, access_token, secret_key):
        if not access_token or not secret_key:
            raise Exception(
                "Service-account authentication requires access_token and secret_key.")

        response = self.Session.post(
            self.apiUrl + "/api/auth",
            json={"access_token": access_token, "secret_key": secret_key},
            verify=self.verify,
        )
        try:
            data = response.json()
        except Exception:
            raise Exception(
                "Service-account authentication returned invalid JSON: %s" % response.text)

        if not isinstance(data, dict) or not data.get("status"):
            raise Exception(
                "Service-account authentication failed: %s" % response.text)

        if not isinstance(data.get("data"), dict):
            raise Exception(
                "Service-account authentication missing user profile: %s" % response.text)

        self.profile = dict(data["data"])
        # Mark auth state for runtime paths that check for token existence.
        self.tokenData = {"access_token": "api_token_session"}
        return True

    def setPrivateKey(self, fn):
        self.privateKeyFilename = fn

    def setPublicKey(self, fn):
        self.publicKeyFilename = fn

    def loadKeys(self):
        self.loadPrivateKey()
        self.loadPublicKey()

    def loadPrivateKey(self):
        self.privateKey = None
        self.globalKey = None
        if not os.path.isfile(self.privateKeyFilename):
            self.generateKeys()
            self.saveKeys()
            return True

        with open(self.privateKeyFilename, 'rb') as pem_in:
            pemlines = pem_in.read()
            self.globalKey = crypto_serialization.load_pem_private_key(
                pemlines, None, crypto_default_backend())

            self.privateKey = self.globalKey.private_bytes(
                crypto_serialization.Encoding.PEM,
                crypto_serialization.PrivateFormat.PKCS8,
                crypto_serialization.NoEncryption())

    def loadPublicKey(self):
        self.publicKey = None
        if not os.path.isfile(self.publicKeyFilename):
            if not self.globalKey:
                raise Exception(
                    "No RSA private key available to export public key")

            self.publicKey = self.globalKey.public_key().public_bytes(
                crypto_serialization.Encoding.OpenSSH,
                crypto_serialization.PublicFormat.OpenSSH)
            self.savePublicKey()

        if not os.path.isfile(self.publicKeyFilename):
            raise Exception("Unable to save public key to disk: %s" %
                            self.publicKeyFilename)

        with open(self.publicKeyFilename, 'rb') as pem_in:
            pemlines = pem_in.read()
            self.publicKey = pemlines

        return True

    def generateKeys(self):

        if self.privateKey and self.publicKey:
            return True

        self.globalKey = rsa.generate_private_key(
            backend=crypto_default_backend(),
            public_exponent=65537,
            key_size=2048)

        self.privateKey = self.globalKey.private_bytes(
            crypto_serialization.Encoding.PEM,
            crypto_serialization.PrivateFormat.PKCS8,
            crypto_serialization.NoEncryption())

        self.publicKey = self.globalKey.public_key().public_bytes(
            crypto_serialization.Encoding.OpenSSH,
            crypto_serialization.PublicFormat.OpenSSH)

        return True

    def saveKeys(self):
        self.savePublicKey()
        self.savePrivateKey()

    def savePrivateKey(self):
        pem = self.globalKey.private_bytes(
            encoding=crypto_serialization.Encoding.PEM,
            format=crypto_serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=crypto_serialization.NoEncryption())
        with open(self.privateKeyFilename, 'wb') as pem_out:
            pem_out.write(pem)

    def savePublicKey(self):
        with open(self.publicKeyFilename, 'wb') as pem_out:
            pem_out.write(self.publicKey)

    def finish(self):
        return self.__finished()

    def __finished(self):
        try:
            self.Session.close()
        except:
            pass

        return True


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage %s: <host> <access_token> <secret_key>" % sys.argv[0])
        sys.exit(-1)

    a = Authentication(sys.argv[1])

    a.setVerify(False)

    if a.loginApiUser(sys.argv[2], sys.argv[3]):
        print(a.tokenData)

    a.finish()
