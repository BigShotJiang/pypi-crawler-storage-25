# marketplace manager code.

# Check to see if this local instance needs to install new plugin from marketplace.

import os
import shutil
import tempfile
import zipfile

from hawkSoar.lib.marketplace import marketplaceAPI as mpAPI
from hawkSoar.common.logger import get_logger


class marketplaceManager(object):

    def __init__(self, config=None):
        self.config = config or {}
        self.logger = get_logger()
        self.init = True
        self.plugin_data_path = self.config.get(
            'plugin_data_path', os.path.join(os.getcwd(), 'plugins'))
        self.poll_interval = int(self.config.get('marketplace_poll_interval', 60))

    def _get_new_plugins(self):
        try:
            return mpAPI.get_new_plugins()
        except Exception as e:
            self.logger.exception("Failed to fetch new plugins: %s" % e)
            return []

    def install_plugin(self, plugin):
        """Downloads plugin, then installs the plugin."""
        try:
            download_path = os.path.join(tempfile.gettempdir(), "%s.zip" % plugin.uuid)
            mpAPI.download_plugin(uuid=plugin.uuid, destination=download_path)

            extract_dir = os.path.join(self.plugin_data_path, plugin.uuid)
            os.makedirs(extract_dir, exist_ok=True)

            with zipfile.ZipFile(download_path, 'r') as z:
                z.extractall(extract_dir)

            os.remove(download_path)

            self.notify_plugin_manager(plugin)
            self.logger.info("Installed plugin %s to %s" % (plugin.uuid, extract_dir))
            return True
        except Exception as e:
            self.logger.exception("Failed to install plugin %s: %s" % (plugin.uuid, e))
            return False

    def notify_plugin_manager(self, plugin):
        """Notify plugin manager of new plugin."""
        try:
            mpAPI.notify_plugin_manager(plugin.uuid)
        except Exception as e:
            self.logger.exception("Failed to notify plugin manager: %s" % e)

    def run(self):
        while self.init:
            new_plugins = self._get_new_plugins()
            if new_plugins:
                for plugin in new_plugins:
                    self.install_plugin(plugin)
            import time
            time.sleep(self.poll_interval)
