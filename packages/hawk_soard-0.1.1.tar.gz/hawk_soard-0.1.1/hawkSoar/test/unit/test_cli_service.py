import unittest
from unittest import mock
from types import SimpleNamespace

from hawkSoar import cli


class CliWindowsServiceTest(unittest.TestCase):
    def test_build_self_service_bin_path_emits_exact_service_run_shape(self):
        with mock.patch.object(cli, "sys") as mocked_sys, mock.patch.object(cli.os.path, "abspath", side_effect=lambda value: value):
            mocked_sys.executable = r"C:\Program Files\Python\python.exe"
            mocked_sys.argv = [r"C:\repo\hawk-soard"]
            mocked_sys.frozen = False

            result = cli._build_self_service_bin_path(
                config_path=r"C:\Program Files\HAWK\SOAR\hawk-soard.cfg",
                service_name=cli.DEFAULT_WINDOWS_SERVICE_NAME,
            )

        self.assertEqual(
            (
                r'"C:\Program Files\Python\python.exe" "C:\repo\hawk-soard" '
                r'--service-run --service-name "HawkSoard" '
                r'-c "C:\Program Files\HAWK\SOAR\hawk-soard.cfg"'
            ),
            result,
        )

    def test_install_windows_service_fails_when_service_does_not_reach_running_state(self):
        details = {
            "name": cli.DEFAULT_WINDOWS_SERVICE_NAME,
            "display_name": cli.DEFAULT_WINDOWS_SERVICE_DISPLAY_NAME,
            "state": "Stopped",
            "start_mode": "Auto",
            "path_name": '"C:\\hawk-soard.exe" --service-run --service-name "HawkSoard" -c "C:\\hawk-soard.cfg"',
        }
        with mock.patch.object(cli.os, "name", "nt"), \
                mock.patch.object(cli, "_is_windows_admin", return_value=True), \
                mock.patch.object(cli.os.path, "abspath", side_effect=lambda value: value), \
                mock.patch.object(cli.os.path, "isfile", return_value=True), \
                mock.patch.object(cli, "_build_self_service_bin_path", return_value=details["path_name"]), \
                mock.patch.object(cli, "_run_powershell", return_value=(0, "SERVICE_INSTALL_OK", "")), \
                mock.patch.object(cli, "_get_windows_service_details", return_value=(details, None)):
            result = cli.install_windows_service(
                config_path=r"C:\hawk-soard.cfg")

        self.assertEqual(4, result)

    def test_main_routes_service_run_flag_to_windows_service_host(self):
        with mock.patch.object(cli.os, "name", "nt"), \
                mock.patch.object(cli, "_run_windows_service_host", return_value=0) as host_runner:
            result = cli.main(["--service-run", "-c", r"C:\hawk-soard.cfg"])

        self.assertEqual(0, result)
        host_runner.assert_called_once_with(
            config_path=r"C:\hawk-soard.cfg",
            service_name=cli.DEFAULT_WINDOWS_SERVICE_NAME,
            display_name=cli.DEFAULT_WINDOWS_SERVICE_DISPLAY_NAME,
            description=cli.DEFAULT_WINDOWS_SERVICE_DESCRIPTION,
        )

    def test_windows_service_host_parses_config_before_startup(self):
        expected_config = {
            "pid_file": r"C:\Program Files\HAWK\SOAR\hawk-soard.pid",
            "auto_upgrade": False,
        }
        fake_daemon = mock.Mock()

        def fake_start_service_dispatcher():
            fake_service = captured["service_class"]([])
            fake_service.SvcDoRun()

        class FakeServiceFramework(object):
            def __init__(self, args):
                self.args = args

            def ReportServiceStatus(self, status):
                return None

        captured = {}
        fake_servicemanager = SimpleNamespace(
            EVENTLOG_INFORMATION_TYPE=0,
            PYS_SERVICE_STARTED=1,
            PYS_SERVICE_STOPPED=2,
            Initialize=lambda: None,
            PrepareToHostSingle=lambda service_class: captured.update(
                {"service_class": service_class}),
            StartServiceCtrlDispatcher=fake_start_service_dispatcher,
            LogMsg=lambda *args, **kwargs: None,
        )
        fake_win32event = SimpleNamespace(
            CreateEvent=lambda *args, **kwargs: object(),
            SetEvent=lambda *args, **kwargs: None,
        )
        fake_win32service = SimpleNamespace(SERVICE_STOP_PENDING=3)
        fake_win32serviceutil = SimpleNamespace(
            ServiceFramework=FakeServiceFramework)

        def assert_startup(register_signal_handlers=False):
            self.assertFalse(register_signal_handlers)
            self.assertEqual(expected_config, cli.masterConfig)

        fake_daemon.startUp.side_effect = assert_startup

        had_master_config = hasattr(cli, "masterConfig")
        previous_master_config = getattr(cli, "masterConfig", None)
        if had_master_config:
            delattr(cli, "masterConfig")

        self.addCleanup(
            lambda: setattr(cli, "masterConfig", previous_master_config)
            if had_master_config
            else (delattr(cli, "masterConfig") if hasattr(cli, "masterConfig") else None)
        )

        with mock.patch.object(cli.os, "name", "nt"), \
            mock.patch.object(cli, "parseConfig", return_value=expected_config) as parse_config, \
            mock.patch.object(cli, "hawkDaemon", return_value=fake_daemon), \
            mock.patch.dict(
            "sys.modules",
            {
                "servicemanager": fake_servicemanager,
                "win32event": fake_win32event,
                "win32service": fake_win32service,
                "win32serviceutil": fake_win32serviceutil,
            },
        ):
            result = cli._run_windows_service_host(
                config_path=r"C:\Program Files\HAWK\SOAR\hawk-soard.cfg")

        self.assertEqual(0, result)
        parse_config.assert_called_once_with(
            r"C:\Program Files\HAWK\SOAR\hawk-soard.cfg")
        fake_daemon.startUp.assert_called_once_with(
            register_signal_handlers=False)

    def test_main_uses_startup_instead_of_daemonize_for_windows_console_mode(self):
        fake_daemon = mock.Mock()
        fake_daemon.startUp.return_value = None
        with mock.patch.object(cli.os, "name", "nt"), \
                mock.patch.object(cli, "parseConfig", return_value={}), \
                mock.patch.object(cli, "hawkDaemon", return_value=fake_daemon), \
                mock.patch.object(cli, "set_proc_name"), \
                mock.patch.object(cli.urllib3, "disable_warnings"), \
                mock.patch.object(cli.logging, "FileHandler"), \
                mock.patch.object(cli.logging, "getLogger", return_value=mock.Mock()):
            result = cli.main(["-c", r"C:\hawk-soard.cfg"])

        self.assertEqual(0, result)
        fake_daemon.startUp.assert_called_once_with(
            register_signal_handlers=True)
        fake_daemon.daemonize.assert_not_called()


if __name__ == "__main__":
    unittest.main()
