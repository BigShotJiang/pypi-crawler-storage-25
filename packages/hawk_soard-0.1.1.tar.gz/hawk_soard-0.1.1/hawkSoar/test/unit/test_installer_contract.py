from pathlib import Path
import unittest


class InstallerContractTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.repo_root = Path(__file__).resolve().parents[3]

    def _read_installer_text(self):
        return (self.repo_root / "installer" / "hawk-soard.nsi").read_text(encoding="utf-8")

    def test_nsis_service_identity_matches_runtime_defaults(self):
        installer_text = self._read_installer_text()

        self.assertIn('!define SERVICE_NAME        "HawkSoard"',
                      installer_text)
        self.assertIn(
            '!define SERVICE_DISPLAY     "Hawk SOARD Service"', installer_text)
        self.assertIn(
            '!define SERVICE_DESC        "Hawk SOARD daemon service"', installer_text)

    def test_pyinstaller_spec_includes_windows_service_hiddenimports(self):
        spec_text = (self.repo_root / "installer" /
                     "hawk-soard.spec").read_text(encoding="utf-8")

        for module_name in (
            "pywintypes",
            "servicemanager",
            "win32event",
            "win32service",
            "win32serviceutil",
        ):
            self.assertIn("'%s'" % module_name, spec_text)

    def test_nsis_reinstall_reads_existing_credentials_into_the_form_contract(self):
        installer_text = self._read_installer_text()

        self.assertIn(
            'ReadINIStr $R0 "$INSTDIR\\hawk-soard.cfg" "SETTINGS" "access_token"', installer_text)
        self.assertIn(
            'ReadINIStr $R1 "$INSTDIR\\hawk-soard.cfg" "SETTINGS" "secret_key"', installer_text)
        self.assertIn(
            '${NSD_SetText} $AccessTokenField $AccessToken', installer_text)
        self.assertIn(
            '${NSD_SetText} $SecretKeyField $SecretKey', installer_text)
        self.assertNotIn('StrCmp $AccessToken "" 0 skip_page', installer_text)
        self.assertNotIn('StrCmp $SecretKey "" 0 skip_page', installer_text)

    def test_nsis_existing_config_is_only_overridden_when_credentials_are_explicitly_replaced(self):
        installer_text = self._read_installer_text()

        self.assertIn("Var AccessTokenOverride", installer_text)
        self.assertIn("Var SecretKeyOverride", installer_text)
        self.assertIn(
            'WriteINIStr "$INSTDIR\\hawk-soard.cfg" "SETTINGS" "access_token" "$AccessToken"', installer_text)
        self.assertIn(
            'WriteINIStr "$INSTDIR\\hawk-soard.cfg" "SETTINGS" "secret_key" "$SecretKey"', installer_text)
        self.assertIn('StrCmp $AccessTokenOverride "1" 0 +2', installer_text)
        self.assertIn('StrCmp $SecretKeyOverride "1" 0 +2', installer_text)
        self.assertNotIn(
            'IfFileExists "$INSTDIR\\hawk-soard.cfg" ConfigExists WriteDefaultConfig', installer_text)

    def test_nsis_reinstall_force_terminates_running_agent_before_overwriting_executable(self):
        installer_text = self._read_installer_text()

        stop_idx = installer_text.index(
            'DetailPrint "Stopping existing service (if running)..."')
        kill_idx = installer_text.index(
            'DetailPrint "Terminating any remaining hawk-soard.exe processes..."')
        stop_cmd_idx = installer_text.index(
            'nsExec::ExecToLog \'sc stop "${SERVICE_NAME}"\'')
        kill_cmd_idx = installer_text.index(
            'nsExec::ExecToLog \'taskkill /F /T /IM "${EXE_NAME}"\'')
        file_idx = installer_text.index('File "${DIST_DIR}\\${EXE_NAME}"')

        self.assertLess(stop_idx, kill_idx)
        self.assertLess(stop_cmd_idx, kill_cmd_idx)
        self.assertLess(kill_cmd_idx, file_idx)
        self.assertIn("Sleep 2000", installer_text)
        self.assertNotIn("Get-Service -Name", installer_text)


if __name__ == "__main__":
    unittest.main()
