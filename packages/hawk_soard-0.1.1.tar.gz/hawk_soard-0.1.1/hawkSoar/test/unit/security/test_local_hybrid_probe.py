import os
import unittest

from hawkSoar.security.local_hybrid_probe import (
    build_local_probe_task,
    classify_local_probe_result,
    determine_local_skip_reason,
    summarize_local_probe_results,
)


class TestLocalHybridProbe(unittest.TestCase):

    def test_determine_local_skip_reason_marks_remote_actions_not_locally_probeable(self):
        tool = {
            "tool_id": "deploy.hawk_soard.verify",
            "action": "verify_hawk_soard",
            "category": "DEPLOY",
            "requires_approval": False,
        }

        skip_reason = determine_local_skip_reason(
            tool,
            include_approval_required=False,
            host_context={"userdnsdomain": "corp.example"},
        )

        self.assertEqual(skip_reason, "remote_target_required")

    def test_determine_local_skip_reason_marks_domain_actions_when_host_is_not_domain_joined(self):
        tool = {
            "tool_id": "ad.get_user_details",
            "action": "get_user_details",
            "category": "AD",
            "requires_approval": False,
        }

        skip_reason = determine_local_skip_reason(
            tool,
            include_approval_required=False,
            host_context={"userdnsdomain": ""},
        )

        self.assertEqual(skip_reason, "domain_context_required")

    def test_determine_local_skip_reason_allows_domain_actions_when_domain_context_exists(self):
        tool = {
            "tool_id": "ad.get_user_details",
            "action": "get_user_details",
            "category": "AD",
            "requires_approval": False,
        }

        skip_reason = determine_local_skip_reason(
            tool,
            include_approval_required=False,
            host_context={"userdnsdomain": "corp.example"},
        )

        self.assertIsNone(skip_reason)

    def test_build_local_probe_task_emits_exact_shape(self):
        tool = {
            "tool_id": "network.dns_lookup",
            "action": "dns_lookup",
            "category": "NETWORK",
            "requires_approval": False,
            "parameters_schema": {"target": "ignored"},
        }

        task = build_local_probe_task(
            tool,
            group_id="local-probe",
            task_timeout=45,
            priority="LOW",
            task_id="task-1",
            case_id="case-1",
        )

        self.assertEqual(
            task,
            {
                "task_id": "task-1",
                "group_id": "local-probe",
                "case_id": "case-1",
                "category": "NETWORK",
                "action": "dns_lookup",
                "parameters": {"target": "localhost"},
                "requires_approval": False,
                "timeout": 45,
                "priority": "LOW",
            },
        )

    def test_build_local_probe_task_overrides_event_log_extraction_to_local_safe_log(self):
        tool = {
            "tool_id": "endpoint.event_log_extraction",
            "action": "event_log_extraction",
            "category": "ENDPOINT",
            "requires_approval": False,
            "parameters_schema": {"log_name": "Security", "count": 500},
        }

        task = build_local_probe_task(
            tool,
            group_id="local-probe",
            task_timeout=45,
            priority="LOW",
            task_id="task-event-log",
            case_id="case-event-log",
        )

        self.assertEqual(
            task,
            {
                "task_id": "task-event-log",
                "group_id": "local-probe",
                "case_id": "case-event-log",
                "category": "ENDPOINT",
                "action": "event_log_extraction",
                "parameters": {"log_name": "System", "count": 50},
                "requires_approval": False,
                "timeout": 45,
                "priority": "LOW",
            },
        )

    def test_build_local_probe_task_overrides_ping_to_local_loopback(self):
        tool = {
            "tool_id": "net.ping",
            "action": "ping",
            "category": "NETWORK",
            "requires_approval": False,
            "parameters_schema": {"target": "192.168.1.1", "count": 4},
        }

        task = build_local_probe_task(
            tool,
            group_id="local-probe",
            task_timeout=45,
            priority="LOW",
            task_id="task-ping",
            case_id="case-ping",
        )

        self.assertEqual(
            task,
            {
                "task_id": "task-ping",
                "group_id": "local-probe",
                "case_id": "case-ping",
                "category": "NETWORK",
                "action": "ping",
                "parameters": {"target": "127.0.0.1", "count": 2},
                "requires_approval": False,
                "timeout": 45,
                "priority": "LOW",
            },
        )

    def test_build_local_probe_task_overrides_rpc_query_to_local_loopback(self):
        tool = {
            "tool_id": "net.rpc.query",
            "action": "rpc_query",
            "category": "NETWORK",
            "requires_approval": False,
            "parameters_schema": {"target": "hostname_or_ip", "endpoint": "optional_rpc_endpoint"},
        }

        task = build_local_probe_task(
            tool,
            group_id="local-probe",
            task_timeout=45,
            priority="LOW",
            task_id="task-rpc",
            case_id="case-rpc",
        )

        self.assertEqual(
            task,
            {
                "task_id": "task-rpc",
                "group_id": "local-probe",
                "case_id": "case-rpc",
                "category": "NETWORK",
                "action": "rpc_query",
                "parameters": {"target": "127.0.0.1"},
                "requires_approval": False,
                "timeout": 45,
                "priority": "LOW",
            },
        )

    def test_build_local_probe_task_overrides_smb_share_targets_to_local_loopback(self):
        tool = {
            "tool_id": "net.smb.client",
            "action": "smb_client",
            "category": "NETWORK",
            "requires_approval": False,
            "parameters_schema": {
                "target": "windows-hostname",
                "operation": "list_shares",
                "share": "C$",
                "path": "\\\\",
            },
        }

        task = build_local_probe_task(
            tool,
            group_id="local-probe",
            task_timeout=45,
            priority="LOW",
            task_id="task-smb-client",
            case_id="case-smb-client",
        )

        self.assertEqual(
            task,
            {
                "task_id": "task-smb-client",
                "group_id": "local-probe",
                "case_id": "case-smb-client",
                "category": "NETWORK",
                "action": "smb_client",
                "parameters": {
                    "target": "127.0.0.1",
                    "operation": "list_shares",
                    "share": "C$",
                    "path": "\\\\",
                },
                "requires_approval": False,
                "timeout": 45,
                "priority": "LOW",
            },
        )

    def test_build_local_probe_task_overrides_office_macro_scan_to_local_home(self):
        tool = {
            "tool_id": "endpoint.office_macro_scan",
            "action": "office_macro_scan",
            "category": "ENDPOINT",
            "requires_approval": False,
            "parameters_schema": {"path": r"C:\Users\jsmith\Documents", "max_files": 500},
        }

        task = build_local_probe_task(
            tool,
            group_id="local-probe",
            task_timeout=45,
            priority="LOW",
            task_id="task-office",
            case_id="case-office",
        )

        self.assertEqual(
            task,
            {
                "task_id": "task-office",
                "group_id": "local-probe",
                "case_id": "case-office",
                "category": "ENDPOINT",
                "action": "office_macro_scan",
                "parameters": {"path": os.path.expanduser("~"), "max_files": 100},
                "requires_approval": False,
                "timeout": 45,
                "priority": "LOW",
            },
        )

    def test_build_local_probe_task_strips_optional_remote_target_for_local_lolbin_scan(self):
        tool = {
            "tool_id": "endpoint.living_off_land_detector",
            "action": "living_off_land_detector",
            "category": "ENDPOINT",
            "requires_approval": False,
            "parameters_schema": {"target_host": "optional_windows_host"},
        }

        task = build_local_probe_task(
            tool,
            group_id="local-probe",
            task_timeout=45,
            priority="LOW",
            task_id="task-lol",
            case_id="case-lol",
        )

        self.assertEqual(
            task,
            {
                "task_id": "task-lol",
                "group_id": "local-probe",
                "case_id": "case-lol",
                "category": "ENDPOINT",
                "action": "living_off_land_detector",
                "parameters": {},
                "requires_approval": False,
                "timeout": 45,
                "priority": "LOW",
            },
        )

    def test_build_local_probe_task_uses_current_pid_for_process_memory_actions(self):
        tool = {
            "tool_id": "endpoint.process_hook_scan",
            "action": "process_hook_scan",
            "category": "ENDPOINT",
            "requires_approval": False,
            "parameters_schema": {"pid": 1234},
        }

        task = build_local_probe_task(
            tool,
            group_id="local-probe",
            task_timeout=45,
            priority="LOW",
            task_id="task-hook",
            case_id="case-hook",
        )

        self.assertEqual(
            task,
            {
                "task_id": "task-hook",
                "group_id": "local-probe",
                "case_id": "case-hook",
                "category": "ENDPOINT",
                "action": "process_hook_scan",
                "parameters": {"pid": os.getpid()},
                "requires_approval": False,
                "timeout": 45,
                "priority": "LOW",
            },
        )

    def test_build_local_probe_task_uses_safe_registry_query_defaults(self):
        tool = {
            "tool_id": "endpoint.registry.query",
            "action": "registry_query",
            "category": "ENDPOINT",
            "requires_approval": False,
            "parameters_schema": {
                "path": r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
                "value_name": "optional_value_name",
            },
        }

        task = build_local_probe_task(
            tool,
            group_id="local-probe",
            task_timeout=45,
            priority="LOW",
            task_id="task-reg",
            case_id="case-reg",
        )

        self.assertEqual(
            task,
            {
                "task_id": "task-reg",
                "group_id": "local-probe",
                "case_id": "case-reg",
                "category": "ENDPOINT",
                "action": "registry_query",
                "parameters": {"path": r"HKLM\SOFTWARE"},
                "requires_approval": False,
                "timeout": 45,
                "priority": "LOW",
            },
        )

    def test_build_local_probe_task_uses_current_pid_for_token_privilege_inspect(self):
        tool = {
            "tool_id": "endpoint.token_privilege_inspect",
            "action": "token_privilege_inspect",
            "category": "ENDPOINT",
            "requires_approval": False,
            "parameters_schema": {},
        }

        task = build_local_probe_task(
            tool,
            group_id="local-probe",
            task_timeout=45,
            priority="LOW",
            task_id="task-token",
            case_id="case-token",
        )

        self.assertEqual(
            task,
            {
                "task_id": "task-token",
                "group_id": "local-probe",
                "case_id": "case-token",
                "category": "ENDPOINT",
                "action": "token_privilege_inspect",
                "parameters": {"pid": os.getpid()},
                "requires_approval": False,
                "timeout": 45,
                "priority": "LOW",
            },
        )

    def test_build_local_probe_task_uses_allowlisted_wmic_query_string(self):
        tool = {
            "tool_id": "endpoint.wmic_query",
            "action": "wmic_query",
            "category": "ENDPOINT",
            "requires_approval": False,
            "parameters_schema": {"query": ["process_list_brief", "computersystem_get_username"]},
        }

        task = build_local_probe_task(
            tool,
            group_id="local-probe",
            task_timeout=45,
            priority="LOW",
            task_id="task-wmic",
            case_id="case-wmic",
        )

        self.assertEqual(
            task,
            {
                "task_id": "task-wmic",
                "group_id": "local-probe",
                "case_id": "case-wmic",
                "category": "ENDPOINT",
                "action": "wmic_query",
                "parameters": {"query": "process_list_brief"},
                "requires_approval": False,
                "timeout": 45,
                "priority": "LOW",
            },
        )

    def test_classify_local_probe_result_keeps_executor_response_shape(self):
        tool = {
            "tool_id": "network.dns_lookup",
            "action": "dns_lookup",
            "category": "NETWORK",
            "requires_approval": False,
        }
        task = {
            "task_id": "task-1",
            "group_id": "local-probe",
            "case_id": "case-1",
            "category": "NETWORK",
            "action": "dns_lookup",
            "parameters": {"target": "example.com"},
            "requires_approval": False,
            "timeout": 45,
            "priority": "LOW",
        }
        response = {
            "task_id": "task-1",
            "group_id": "local-probe",
            "status": "SUCCESS",
            "host": "HOST1",
            "execution_time_ms": 18,
            "output": {"addresses": ["93.184.216.34"]},
            "raw_output_hash": "abc123",
            "error": None,
        }

        result = classify_local_probe_result(
            tool, task=task, response=response)

        self.assertEqual(
            result,
            {
                "tool_id": "network.dns_lookup",
                "action": "dns_lookup",
                "category": "NETWORK",
                "requires_approval": False,
                "probe_status": "SUCCESS",
                "task": task,
                "response": response,
                "skip_reason": None,
            },
        )

    def test_classify_local_probe_result_marks_skipped_actions_explicitly(self):
        tool = {
            "tool_id": "containment.host_isolation",
            "action": "host_isolation",
            "category": "CONTAINMENT",
            "requires_approval": True,
        }
        task = {
            "task_id": "task-2",
            "group_id": "local-probe",
            "case_id": "case-2",
            "category": "CONTAINMENT",
            "action": "host_isolation",
            "parameters": {},
            "requires_approval": True,
            "timeout": 45,
            "priority": "LOW",
        }

        result = classify_local_probe_result(
            tool,
            task=task,
            response=None,
            skip_reason="approval_required",
        )

        self.assertEqual(
            result,
            {
                "tool_id": "containment.host_isolation",
                "action": "host_isolation",
                "category": "CONTAINMENT",
                "requires_approval": True,
                "probe_status": "SKIPPED",
                "task": task,
                "response": None,
                "skip_reason": "approval_required",
            },
        )

    def test_summarize_local_probe_results_counts_success_failures_and_skips(self):
        results = [
            {
                "tool_id": "network.dns_lookup",
                "action": "dns_lookup",
                "category": "NETWORK",
                "requires_approval": False,
                "probe_status": "SUCCESS",
                "task": {"action": "dns_lookup"},
                "response": {"status": "SUCCESS"},
                "skip_reason": None,
            },
            {
                "tool_id": "endpoint.registry_read",
                "action": "registry_read",
                "category": "ENDPOINT",
                "requires_approval": False,
                "probe_status": "FAILED",
                "task": {"action": "registry_read"},
                "response": {"status": "FAILED"},
                "skip_reason": None,
            },
            {
                "tool_id": "containment.host_isolation",
                "action": "host_isolation",
                "category": "CONTAINMENT",
                "requires_approval": True,
                "probe_status": "SKIPPED",
                "task": {"action": "host_isolation"},
                "response": None,
                "skip_reason": "approval_required",
            },
        ]

        summary = summarize_local_probe_results(results)

        self.assertEqual(
            summary,
            {
                "total": 3,
                "executed": 2,
                "skipped": 1,
                "by_probe_status": {
                    "SUCCESS": 1,
                    "FAILED": 1,
                    "BLOCKED": 0,
                    "SKIPPED": 1,
                },
                "failed_actions": ["registry_read"],
                "blocked_actions": [],
                "skipped_actions": ["host_isolation"],
            },
        )


if __name__ == "__main__":
    unittest.main()
