import json
import os
import shutil
import socket
import tempfile
import unittest
import ctypes
from unittest import mock

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

from hawkSoar.security.hybrid_catalog import HybridToolCatalog
from hawkSoar.security.hybrid_execution import HybridTaskExecutor


def _base_task():
    return {
        "task_id": "11111111-1111-1111-1111-111111111111",
        "group_id": "22222222-2222-2222-2222-222222222222",
        "case_id": "33333333-3333-3333-3333-333333333333",
        "category": "NETWORK",
        "action": "ping",
        "parameters": {"target": "127.0.0.1", "count": 1},
        "requires_approval": True,
        "timeout": 5,
        "priority": "LOW",
    }


class HybridExecutionTest(unittest.TestCase):
    def setUp(self):
        temp_root = os.path.join(os.getcwd(), ".pytest_tmp")
        os.makedirs(temp_root, exist_ok=True)
        self.temp_dir_path = os.path.join(
            temp_root, "hybrid-exec-%s" % next(tempfile._get_candidate_names())
        )
        os.makedirs(self.temp_dir_path, exist_ok=True)
        self.private_key = rsa.generate_private_key(
            public_exponent=65537, key_size=2048
        )
        public_key = self.private_key.public_key().public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        self.pub_path = os.path.join(self.temp_dir_path, "public.pem")
        with open(self.pub_path, "wb") as handle:
            handle.write(public_key)

    def tearDown(self):
        shutil.rmtree(self.temp_dir_path, ignore_errors=True)

    def _sign(self, task):
        canonical = json.dumps(task, sort_keys=True, separators=(",", ":")).encode(
            "utf-8"
        )
        sig = self.private_key.sign(
            canonical, padding.PKCS1v15(), hashes.SHA256())
        return sig.hex()

    def _executor(self, expected_group_getter=None, command_runner=None, **overrides):
        config = {
            "task_signing_public_key": self.pub_path,
            "enforce_signed_hybrid_tasks": True,
            "enforce_group_id": True,
            "max_task_timeout": 60,
            "plugin_data_path": self.temp_dir_path,
            "hybrid_dynamic_tools_file": os.path.join(
                self.temp_dir_path, "hybrid_dynamic_tools.json"
            ),
            "enable_command_execution": True,
        }
        config.update(overrides)

        def fake_runner(cmd, timeout):
            del timeout
            return 0, "ok: %s" % " ".join(cmd), ""

        return HybridTaskExecutor(
            config=config,
            expected_group_id_getter=expected_group_getter
            or (lambda: "22222222-2222-2222-2222-222222222222"),
            command_runner=command_runner or fake_runner,
        )

    def test_blocks_missing_signature(self):
        executor = self._executor()
        response = executor.process(_base_task(), signature=None)
        self.assertEqual(response["status"], "BLOCKED")
        self.assertIn("signature", response["error"].lower())

    def test_blocks_non_object_task_payload(self):
        executor = self._executor()
        response = executor.process(None, signature=None)
        self.assertEqual(response["status"], "BLOCKED")
        self.assertIn("json object", response["error"].lower())

    def test_blocks_group_mismatch(self):
        executor = self._executor()
        task = _base_task()
        task["group_id"] = "aaaaaaaa-2222-2222-2222-222222222222"
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")
        self.assertIn("group_id", response["error"])

    def test_blocks_disallowed_wmic(self):
        executor = self._executor()
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "wmic_query"
        task["parameters"] = {"query": "process_create"}
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")
        self.assertIn("allowlisted", response["error"])

    def test_blocks_containment_without_approval(self):
        executor = self._executor()
        task = _base_task()
        task["category"] = "CONTAINMENT"
        task["action"] = "kill_process"
        task["requires_approval"] = False
        task["parameters"] = {"pid": 100}
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")
        self.assertIn("require approval", response["error"].lower())

    def test_successful_signed_task(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        native_result = {
            "target": "127.0.0.1",
            "resolved_ip": "127.0.0.1",
            "count": 1,
            "sent": 1,
            "received": 1,
            "lost": 0,
            "loss_percent": 0,
            "source": "native_windows_icmp",
            "responses": [
                {
                    "seq": 1,
                    "status": "SUCCESS",
                    "status_code": 0,
                    "round_trip_time_ms": 1,
                },
            ],
        }

        with mock.patch.object(
            executor, "_is_windows", return_value=True
        ), mock.patch.object(
            executor,
            "_windows_icmp_ping",
            return_value=(native_result, json.dumps(
                native_result, sort_keys=True)),
        ):
            response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(response["output"], native_result)

    def test_blocks_remote_process_snapshot_when_policy_disabled(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "remote_process_snapshot"
        task["requires_approval"] = True
        task["parameters"] = {
            "target_host": "host01",
            "pid": 1234,
            "username": "admin",
            "password": "pw",
        }
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")
        self.assertIn("disabled by policy", response["error"].lower())

    def test_blocks_remote_process_snapshot_by_name_without_approval(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "remote_process_snapshot_by_name"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "host01",
            "process_name": "lsass",
            "username": "admin",
            "password": "pw",
        }
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")
        self.assertIn("requires approval", response["error"].lower())

    def test_blocks_remote_file_collect_when_policy_disabled(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "remote_file_collect"
        task["requires_approval"] = True
        task["parameters"] = {
            "target_host": "host01",
            "remote_path": "C:\\Windows\\Temp\\a.bin",
            "username": "admin",
            "password": "pw",
        }
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")
        self.assertIn("disabled by policy", response["error"].lower())

    def test_blocks_run_command_without_approval(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "run_command"
        task["requires_approval"] = False
        task["parameters"] = {"argv": ["whoami"]}
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")
        self.assertIn("requires approval", response["error"].lower())

    def test_register_and_execute_dynamic_tool(self):
        executor = self._executor(enforce_group_id=False)
        register = _base_task()
        register["category"] = "ENDPOINT"
        register["action"] = "register_dynamic_tool"
        register["requires_approval"] = True
        register["parameters"] = {
            "tool_id": "custom.echo",
            "name": "Custom Echo",
            "category": "ENDPOINT",
            "action": "custom_echo",
            "description": "Echo a message.",
            "command": ["echo", "{message}"],
            "parameters_schema": {"message": "hello"},
            "requires_approval": True,
            "risk": "HIGH",
        }
        register_response = executor.process(
            register, signature=self._sign(register))
        self.assertEqual(register_response["status"], "SUCCESS")

        run_custom = _base_task()
        run_custom["category"] = "ENDPOINT"
        run_custom["action"] = "custom_echo"
        run_custom["requires_approval"] = True
        run_custom["parameters"] = {"message": "hello"}
        run_response = executor.process(
            run_custom, signature=self._sign(run_custom))
        self.assertEqual(run_response["status"], "SUCCESS")
        self.assertIn("stdout", run_response["output"])

    def test_blocks_remote_command_execute_when_policy_disabled(self):
        executor = self._executor(
            enforce_group_id=False, enable_remote_command_execution=False
        )
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "remote_command_execute"
        task["requires_approval"] = True
        task["parameters"] = {
            "target_host": "host01",
            "username": "admin",
            "password": "pw",
            "argv": ["whoami"],
        }
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")

    def test_blocks_remote_registry_query_when_policy_disabled(self):
        executor = self._executor(
            enforce_group_id=False, enable_remote_registry_read=False
        )
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "remote_registry_query"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "host01",
            "path": "HKLM\\SOFTWARE",
        }
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")

    def test_blocks_register_windows_service_without_approval(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "register_windows_service"
        task["requires_approval"] = False
        task["parameters"] = {
            "service_name": "HawkSoard",
            "executable_path": "C:\\does-not-exist\\hawk-soard.exe",
        }
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")
        self.assertIn("requires approval", response["error"].lower())

    def test_blocks_restart_windows_service_without_approval(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "restart_windows_service"
        task["requires_approval"] = False
        task["parameters"] = {"service_name": "HawkSoard"}
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")
        self.assertIn("requires approval", response["error"].lower())

    def test_catalog_executable_actions_are_wired(self):
        executor = self._executor(enforce_group_id=False)
        catalog = HybridToolCatalog(
            config=executor.config).export(group_id="g-1")
        executable_actions = set(
            tool["action"]
            for tool in catalog["tools"]
            if tool.get("execution_mode") == "executable"
            and isinstance(tool.get("action"), str)
        )
        allowlisted = set()
        for actions in executor.ALLOWED_ACTIONS.values():
            allowlisted.update(actions)
        missing_allowlist = sorted(
            x for x in executable_actions if x not in allowlisted
        )
        missing_handlers = sorted(
            x
            for x in executable_actions
            if x not in executor._action_handlers
            and x not in executor.dynamic_tool_actions
        )
        self.assertEqual([], missing_allowlist)
        self.assertEqual([], missing_handlers)

    def test_remote_config_update_not_blocked_for_approval_when_enabled(self):
        executor = self._executor(
            enforce_group_id=False, enable_remote_config_management=True
        )
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "remote_config_update"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "host01",
            "remote_path": "C:\\ProgramData\\Hawk\\hawk-soard.cfg",
            "content": "[SETTINGS]\n",
            "username": "admin",
            "password": "pw",
        }
        response = executor.process(task, signature=self._sign(task))
        self.assertNotIn("requires approval", (response.get("error") or "").lower())

    def test_blocks_remote_service_restart_when_policy_disabled(self):
        executor = self._executor(
            enforce_group_id=False, enable_remote_config_management=False
        )
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "remote_service_restart"
        task["requires_approval"] = True
        task["parameters"] = {
            "target_host": "host01",
            "service_name": "HawkSoard",
            "username": "admin",
            "password": "pw",
        }
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")

    def test_blocks_remote_process_restart_when_policy_disabled(self):
        executor = self._executor(
            enforce_group_id=False, enable_remote_config_management=False
        )
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "remote_process_restart"
        task["requires_approval"] = True
        task["parameters"] = {
            "target_host": "host01",
            "process_name": "hawk-soard",
            "executable_path": "C:\\Program Files\\Hawk\\hawk-soard.exe",
            "arguments": ["-c", "C:\\ProgramData\\Hawk\\hawk-soard.cfg"],
            "username": "admin",
            "password": "pw",
        }
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")

    def test_blocks_when_local_group_unavailable(self):
        executor = self._executor(expected_group_getter=lambda: None)
        task = _base_task()
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")
        self.assertIn("local node group is unavailable",
                      response["error"].lower())

    def test_blocks_when_group_getter_missing(self):
        executor = HybridTaskExecutor(
            config={
                "task_signing_public_key": self.pub_path,
                "enforce_signed_hybrid_tasks": True,
                "enforce_group_id": True,
                "max_task_timeout": 60,
            },
            expected_group_id_getter=None,
            command_runner=lambda cmd, timeout: (0, "ok", ""),
        )
        task = _base_task()
        response = executor.process(task, signature=self._sign(task))
        self.assertEqual(response["status"], "BLOCKED")
        self.assertIn("group resolver", response["error"].lower())

    def test_deploy_hawk_soard_falls_back_to_pypsrp_when_impacket_not_supported(self):
        executor = self._executor(
            enforce_group_id=False,
            server="https://ir.hawk.io",
            access_token="local-access",
            secret_key="local-secret",
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "deploy_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "10.40.19.76",
            "username": "hawkscan",
            "password": "pw",
            "domain": "",
            "transport": "impacket",
        }

        with mock.patch(
            "hawkSoar.security.remote_deploy.find_local_installer", return_value=None
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_impacket",
            side_effect=RuntimeError(
                "SMB SessionError: code: 0xc00000bb - STATUS_NOT_SUPPORTED - The request is not supported."
            ),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_pypsrp",
            return_value={
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "pypsrp",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
            },
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_sccm",
            side_effect=RuntimeError("SCCM evaluation trigger failed."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_bits_smb",
            side_effect=RuntimeError("BITS download failed."),
        ), mock.patch.object(executor, "_is_windows", return_value=False):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "pypsrp",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
                "fallback_used": True,
                "fallback_from": "impacket",
                "fallback_reason": "SMB SessionError: code: 0xc00000bb - STATUS_NOT_SUPPORTED - The request is not supported.",
                "attempted_transports": ["impacket", "sccm", "bits_smb", "pypsrp"],
                "attempt_errors": [
                    {
                        "transport": "impacket",
                        "error": "SMB SessionError: code: 0xc00000bb - STATUS_NOT_SUPPORTED - The request is not supported.",
                    },
                    {
                        "transport": "sccm",
                        "error": "sccm transport failed: SCCM evaluation trigger failed.",
                    },
                    {
                        "transport": "bits_smb",
                        "error": "bits_smb transport failed: BITS download failed.",
                    },
                ],
            },
        )

    def test_deploy_hawk_soard_falls_back_to_winrm_when_impacket_and_pypsrp_fail(self):
        def fake_runner(cmd, timeout):
            self.assertEqual(timeout, 5)
            self.assertEqual(cmd[0], "/usr/bin/pwsh")
            self.assertEqual(
                cmd[1:4],
                ["-NoProfile", "-NonInteractive", "-Command"],
            )
            return (
                0,
                json.dumps(
                    {
                        "deployed": True,
                        "status": "Running",
                        "service_name": "HawkSoard",
                        "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                    }
                ),
                "",
            )

        executor = self._executor(
            enforce_group_id=False,
            command_runner=fake_runner,
            server="https://ir.hawk.io",
            access_token="local-access",
            secret_key="local-secret",
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "deploy_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "10.40.19.76",
            "username": "hawkscan",
            "password": "pw",
            "domain": "",
            "transport": "impacket",
        }

        with mock.patch(
            "hawkSoar.security.remote_deploy.find_local_installer", return_value=None
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_impacket",
            side_effect=RuntimeError(
                "SMB SessionError: code: 0xc00000bb - STATUS_NOT_SUPPORTED - The request is not supported."
            ),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_pypsrp",
            side_effect=RuntimeError(
                "pypsrp WinRM deployment failed: WSManFault"),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_sccm",
            side_effect=RuntimeError("SCCM evaluation trigger failed."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_bits_smb",
            side_effect=RuntimeError("BITS download failed."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.build_deploy_script",
            return_value="Write-Output fallback",
        ), mock.patch(
            "hawkSoar.security.hybrid_execution.shutil.which",
            side_effect=lambda name: "/usr/bin/pwsh" if name == "pwsh" else None,
        ), mock.patch.object(executor, "_is_windows", return_value=False):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "target_host": "10.40.19.76",
                "transport": "winrm",
                "exit_code": 0,
                "stdout": json.dumps(
                    {
                        "deployed": True,
                        "status": "Running",
                        "service_name": "HawkSoard",
                        "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                    }
                ),
                "stderr": "",
                "deployed": True,
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "fallback_used": True,
                "fallback_from": "impacket",
                "fallback_reason": "SMB SessionError: code: 0xc00000bb - STATUS_NOT_SUPPORTED - The request is not supported.",
                "attempted_transports": [
                    "impacket",
                    "sccm",
                    "bits_smb",
                    "pypsrp",
                    "winrm",
                ],
                "attempt_errors": [
                    {
                        "transport": "impacket",
                        "error": "SMB SessionError: code: 0xc00000bb - STATUS_NOT_SUPPORTED - The request is not supported.",
                    },
                    {
                        "transport": "sccm",
                        "error": "sccm transport failed: SCCM evaluation trigger failed.",
                    },
                    {
                        "transport": "bits_smb",
                        "error": "bits_smb transport failed: BITS download failed.",
                    },
                    {
                        "transport": "pypsrp",
                        "error": "pypsrp transport failed: pypsrp WinRM deployment failed: WSManFault",
                    },
                ],
            },
        )

    def test_deploy_hawk_soard_falls_back_to_ssh_when_impacket_pypsrp_and_winrm_are_unavailable(
        self,
    ):
        executor = self._executor(
            enforce_group_id=False,
            server="https://ir.hawk.io",
            access_token="local-access",
            secret_key="local-secret",
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "deploy_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "10.40.19.76",
            "username": "hawkscan",
            "password": "pw",
            "domain": "",
            "transport": "impacket",
        }

        with mock.patch(
            "hawkSoar.security.remote_deploy.find_local_installer", return_value=None
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_impacket",
            side_effect=RuntimeError(
                "SMB SessionError: code: 0xc00000bb - STATUS_NOT_SUPPORTED - The request is not supported."
            ),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_pypsrp",
            side_effect=RuntimeError(
                "pypsrp WinRM deployment failed: connection refused"
            ),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_sccm",
            side_effect=RuntimeError("SCCM evaluation trigger failed."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_bits_smb",
            side_effect=RuntimeError("BITS download failed."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_ssh",
            return_value={
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "ssh",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
            },
        ), mock.patch.object(
            executor, "_is_windows", return_value=False
        ), mock.patch.object(executor, "_get_powershell_executable", return_value=None):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "ssh",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
                "fallback_used": True,
                "fallback_from": "impacket",
                "fallback_reason": "SMB SessionError: code: 0xc00000bb - STATUS_NOT_SUPPORTED - The request is not supported.",
                "attempted_transports": [
                    "impacket",
                    "sccm",
                    "bits_smb",
                    "pypsrp",
                    "winrm",
                    "ssh",
                ],
                "attempt_errors": [
                    {
                        "transport": "impacket",
                        "error": "SMB SessionError: code: 0xc00000bb - STATUS_NOT_SUPPORTED - The request is not supported.",
                    },
                    {
                        "transport": "sccm",
                        "error": "sccm transport failed: SCCM evaluation trigger failed.",
                    },
                    {
                        "transport": "bits_smb",
                        "error": "bits_smb transport failed: BITS download failed.",
                    },
                    {
                        "transport": "pypsrp",
                        "error": "pypsrp transport failed: pypsrp WinRM deployment failed: connection refused",
                    },
                    {
                        "transport": "winrm",
                        "error": "winrm transport failed: transport=winrm requires PowerShell on the deploying host. Install pwsh/powershell or use transport=impacket.",
                    },
                ],
            },
        )

    def test_deploy_hawk_soard_falls_back_from_winrm_to_pip_impacket(self):
        def fake_runner(cmd, timeout):
            self.assertEqual(timeout, 5)
            self.assertEqual(cmd[0], "powershell")
            self.assertEqual(
                cmd[1:4],
                ["-NoProfile", "-NonInteractive", "-Command"],
            )
            return (1, "", "WinRM cannot process the request.")

        executor = self._executor(
            enforce_group_id=False,
            command_runner=fake_runner,
            server="https://ir.hawk.io",
            access_token="local-access",
            secret_key="local-secret",
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "deploy_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "10.40.19.76",
            "username": "hawkscan",
            "password": "pw",
            "domain": "",
            "transport": "winrm",
        }

        with mock.patch(
            "hawkSoar.security.remote_deploy.find_local_installer", return_value=None
        ), mock.patch(
            "hawkSoar.security.remote_deploy.build_deploy_script",
            return_value="Write-Output primary",
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_pypsrp",
            side_effect=RuntimeError(
                "pypsrp WinRM deployment failed: connection refused"
            ),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_impacket",
            side_effect=RuntimeError("Installer service registration failed."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_service_impacket",
            side_effect=RuntimeError(
                "CreateServiceW temporary execution failed."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_pip_impacket",
            return_value={
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "pip_impacket",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
            },
        ), mock.patch.object(executor, "_is_windows", return_value=True):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "pip_impacket",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
                "fallback_used": True,
                "fallback_from": "winrm",
                "fallback_reason": "winrm transport failed: verify_hawk_soard failed with exit code 1: WinRM cannot process the request.",
                "attempted_transports": [
                    "winrm",
                    "pypsrp",
                    "impacket",
                    "service_impacket",
                    "pip_impacket",
                ],
                "attempt_errors": [
                    {
                        "transport": "winrm",
                        "error": "winrm transport failed: verify_hawk_soard failed with exit code 1: WinRM cannot process the request.",
                    },
                    {
                        "transport": "pypsrp",
                        "error": "pypsrp transport failed: pypsrp WinRM deployment failed: connection refused",
                    },
                    {
                        "transport": "impacket",
                        "error": "Installer service registration failed.",
                    },
                    {
                        "transport": "service_impacket",
                        "error": "CreateServiceW temporary execution failed.",
                    },
                ],
            },
        )

    def test_deploy_hawk_soard_reports_exhausted_fallback_chain(self):
        def fake_runner(cmd, timeout):
            self.assertEqual(timeout, 5)
            self.assertEqual(cmd[0], "powershell")
            return (1, "", "WinRM cannot complete the operation.")

        executor = self._executor(
            enforce_group_id=False,
            command_runner=fake_runner,
            server="https://ir.hawk.io",
            access_token="local-access",
            secret_key="local-secret",
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "deploy_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "10.40.19.76",
            "username": "hawkscan",
            "password": "pw",
            "domain": "",
            "transport": "winrm",
        }

        with mock.patch(
            "hawkSoar.security.remote_deploy.find_local_installer", return_value=None
        ), mock.patch(
            "hawkSoar.security.remote_deploy.build_deploy_script",
            return_value="Write-Output primary",
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_pypsrp",
            side_effect=RuntimeError(
                "pypsrp WinRM deployment failed: connection refused"
            ),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_impacket",
            side_effect=RuntimeError("Installer service registration failed."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_service_impacket",
            side_effect=RuntimeError("Temporary service execution failed."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_pip_impacket",
            side_effect=RuntimeError("Remote host is missing py.exe."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_pip_service_impacket",
            side_effect=RuntimeError(
                "Temporary service pip execution failed."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_sccm",
            side_effect=RuntimeError("SCCM evaluation trigger failed."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_bits_smb",
            side_effect=RuntimeError(
                "BITS download job failed on remote host."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_ssh",
            side_effect=RuntimeError("SSH transport unavailable."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_ivanti",
            side_effect=RuntimeError("Ivanti authentication failed."),
        ), mock.patch.object(executor, "_is_windows", return_value=True):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertEqual(
            response["error"],
            "deploy_hawk_soard failed after transports winrm, pypsrp, impacket, service_impacket, pip_impacket, pip_service_impacket, sccm, bits_smb, ssh, ivanti: "
            "winrm=winrm transport failed: verify_hawk_soard failed with exit code 1: WinRM cannot complete the operation.; "
            "pypsrp=pypsrp transport failed: pypsrp WinRM deployment failed: connection refused; "
            "impacket=Installer service registration failed.; "
            "service_impacket=Temporary service execution failed.; "
            "pip_impacket=Remote host is missing py.exe.; "
            "pip_service_impacket=Temporary service pip execution failed.; "
            "sccm=sccm transport failed: SCCM evaluation trigger failed.; "
            "bits_smb=bits_smb transport failed: BITS download job failed on remote host.; "
            "ssh=SSH transport unavailable.; "
            "ivanti=ivanti transport failed: Ivanti authentication failed.",
        )

    def test_deploy_hawk_soard_falls_back_to_service_impacket_when_wmi_exec_fails(self):
        executor = self._executor(
            enforce_group_id=False,
            server="https://ir.hawk.io",
            access_token="local-access",
            secret_key="local-secret",
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "deploy_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "10.40.19.76",
            "username": "hawkscan",
            "password": "pw",
            "domain": "",
            "transport": "impacket",
        }

        with mock.patch(
            "hawkSoar.security.remote_deploy.find_local_installer", return_value=None
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_impacket",
            side_effect=RuntimeError(
                "WMI Win32_Process.Create failed on remote host."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_service_impacket",
            return_value={
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "service_impacket",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
            },
        ), mock.patch.object(executor, "_is_windows", return_value=False):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "service_impacket",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
                "fallback_used": True,
                "fallback_from": "impacket",
                "fallback_reason": "WMI Win32_Process.Create failed on remote host.",
                "attempted_transports": ["impacket", "service_impacket"],
                "attempt_errors": [
                    {
                        "transport": "impacket",
                        "error": "WMI Win32_Process.Create failed on remote host.",
                    }
                ],
            },
        )

    def test_deploy_hawk_soard_falls_back_to_pip_service_impacket_when_service_installer_fails(
        self,
    ):
        executor = self._executor(
            enforce_group_id=False,
            server="https://ir.hawk.io",
            access_token="local-access",
            secret_key="local-secret",
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "deploy_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "10.40.19.76",
            "username": "hawkscan",
            "password": "pw",
            "domain": "",
            "transport": "service_impacket",
        }

        with mock.patch(
            "hawkSoar.security.remote_deploy.find_local_installer", return_value=None
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_service_impacket",
            side_effect=RuntimeError(
                "Temporary service installer execution failed."),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_pip_service_impacket",
            return_value={
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "pip_service_impacket",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
            },
        ), mock.patch.object(executor, "_is_windows", return_value=False):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "pip_service_impacket",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
                "fallback_used": True,
                "fallback_from": "service_impacket",
                "fallback_reason": "Temporary service installer execution failed.",
                "attempted_transports": ["service_impacket", "pip_service_impacket"],
                "attempt_errors": [
                    {
                        "transport": "service_impacket",
                        "error": "Temporary service installer execution failed.",
                    }
                ],
            },
        )

    def test_deploy_hawk_soard_supports_explicit_ssh_transport(self):
        executor = self._executor(
            enforce_group_id=False,
            server="https://ir.hawk.io",
            access_token="local-access",
            secret_key="local-secret",
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "deploy_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "10.40.19.76",
            "username": "hawkscan",
            "password": "pw",
            "domain": "",
            "transport": "ssh",
        }

        with mock.patch(
            "hawkSoar.security.remote_deploy.find_local_installer", return_value=None
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_ssh",
            return_value={
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "ssh",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
            },
        ), mock.patch.object(executor, "_is_windows", return_value=False):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "ssh",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
                "attempted_transports": ["ssh"],
            },
        )

    def test_windows_ad_user_lookup_returns_found_false_for_missing_user(self):
        def fake_runner(cmd, timeout):
            del cmd, timeout
            return (
                2,
                "",
                "The user name could not be found.\n\nMore help is available by typing NET HELPMSG 2221.\n\n",
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fake_runner)
        task = _base_task()
        task["category"] = "AD"
        task["action"] = "get_user_details"
        task["requires_approval"] = False
        task["parameters"] = {"username": "jsmith"}

        with mock.patch.object(executor, "_is_windows", return_value=True):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "found": False,
                "username": "jsmith",
                "exit_code": 2,
                "stdout": "",
                "stderr": "The user name could not be found.\n\nMore help is available by typing NET HELPMSG 2221.\n\n",
            },
        )
        self.assertIsNone(response["error"])

    def test_ad_replication_drift_probe_reports_missing_repadmin_cleanly(self):
        def fake_runner(cmd, timeout):
            del timeout
            raise FileNotFoundError(
                2, "The system cannot find the file specified", cmd[0]
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fake_runner)
        task = _base_task()
        task["category"] = "AD"
        task["action"] = "ad_replication_drift_probe"
        task["requires_approval"] = False
        task["parameters"] = {}

        with mock.patch.object(executor, "_is_windows", return_value=True):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("repadmin", response["error"].lower())
        self.assertIn("not found", response["error"].lower())

    def test_gpo_startup_script_view_fails_on_nonzero_powershell_exit(self):
        def fake_runner(cmd, timeout):
            del cmd, timeout
            return 1, "No USERDNSDOMAIN found", ""

        executor = self._executor(
            enforce_group_id=False, command_runner=fake_runner)
        task = _base_task()
        task["category"] = "AD"
        task["action"] = "gpo_startup_script_view"
        task["requires_approval"] = False
        task["parameters"] = {"limit": 30}

        with mock.patch.object(executor, "_is_windows", return_value=True):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("exit code 1", response["error"].lower())
        self.assertIn("userdnsdomain", response["error"].lower())

    def test_verify_hawk_soard_fails_when_winrm_probe_exits_nonzero(self):
        def fake_runner(cmd, timeout):
            del cmd, timeout
            return 1, "", "ConvertTo-SecureString failed"

        executor = self._executor(
            enforce_group_id=False,
            enable_remote_deploy=True,
            command_runner=fake_runner,
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "verify_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "windows-hostname-or-ip",
            "username": "DOMAIN\\administrator",
            "password": "credential-password",
            "domain": "optional-domain",
            "service_name": "HawkSoard",
            "transport": "winrm",
        }

        with mock.patch.object(executor, "_is_windows", return_value=True):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("verify_hawk_soard", response["error"])
        self.assertIn("exit code 1", response["error"].lower())
        self.assertIn("securestring failed", response["error"].lower())

    def test_installed_software_uses_native_inventory_instead_of_binary_wrapper(self):
        def fail_if_called(cmd, timeout):
            raise AssertionError(
                "command_runner should not be used for installed_software: %r" % (
                    cmd,)
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fail_if_called)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "installed_software"
        task["requires_approval"] = False
        task["parameters"] = {}

        with mock.patch.object(
            executor, "_is_windows", return_value=True
        ), mock.patch.object(
            executor,
            "_windows_installed_software_inventory",
            return_value=(
                {
                    "source": "registry_uninstall",
                    "count": 1,
                    "items": [
                        {
                            "display_name": "Example App",
                            "display_version": "1.2.3",
                            "publisher": "Example Corp",
                            "scope": "machine",
                        }
                    ],
                },
                '{"source":"registry_uninstall","count":1}',
            ),
            create=True,
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "source": "registry_uninstall",
                "count": 1,
                "items": [
                    {
                        "display_name": "Example App",
                        "display_version": "1.2.3",
                        "publisher": "Example Corp",
                        "scope": "machine",
                    }
                ],
            },
        )

    def test_event_log_extraction_fails_on_nonzero_exit(self):
        def fake_runner(cmd, timeout):
            del cmd, timeout
            return (
                5,
                "",
                "Failed to open event query.\nThe system cannot find the file specified.\n",
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fake_runner)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "event_log_extraction"
        task["requires_approval"] = False
        task["parameters"] = {"log_name": "Security", "count": 500}

        with mock.patch.object(executor, "_is_windows", return_value=True):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("event_log_extraction", response["error"])
        self.assertIn("exit code 5", response["error"].lower())
        self.assertIn("cannot find the file specified", response["error"].lower())

    def test_com_hijack_detector_treats_missing_hkcu_clsid_root_as_empty_result(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "com_hijack_detector"
        task["requires_approval"] = False
        task["parameters"] = {}

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch(
            "winreg.OpenKey",
            side_effect=FileNotFoundError(
                2, "The system cannot find the file specified"
            ),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "command": "com_hijack_detector",
                "stdout": '{\n  "clsids_scanned": 0,\n  "hijacks_found": 0,\n  "hijacks": [],\n  "errors": []\n}',
                "stderr": "",
                "exit_code": 0,
            },
        )

    def test_list_event_log_channels_accepts_partial_results_when_stdout_is_valid(self):
        stdout = json.dumps(
            [
                {
                    "LogName": "System",
                    "RecordCount": 44503,
                    "IsEnabled": True,
                    "LogType": 0,
                }
            ]
        )

        def fake_runner(cmd, timeout):
            del cmd, timeout
            return 1, stdout, "Access is denied for one or more channels."

        executor = self._executor(
            enforce_group_id=False, command_runner=fake_runner)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "list_event_log_channels"
        task["requires_approval"] = False
        task["parameters"] = {}

        with mock.patch.object(executor, "_is_windows", return_value=True):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "exit_code": 1,
                "stderr": "Access is denied for one or more channels.",
                "channels": [
                    {
                        "LogName": "System",
                        "RecordCount": 44503,
                        "IsEnabled": True,
                        "LogType": 0,
                    }
                ],
                "count": 1,
                "command": [
                    "powershell",
                    "-NoProfile",
                    "-NonInteractive",
                    "-Command",
                    "<event-log-channel-list-script>",
                ],
            },
        )
        self.assertIsNone(response["error"])

    def test_memory_ioc_extractor_fails_when_open_process_is_denied(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "memory_ioc_extractor"
        task["requires_approval"] = False
        task["parameters"] = {"pid": 1234, "min_b64": 64}

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch(
            "ctypes.windll.kernel32.OpenProcess",
            return_value=0,
        ), mock.patch(
            "ctypes.get_last_error",
            return_value=5,
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("memory_ioc_extractor", response["error"])
        self.assertIn("openprocess failed", response["error"].lower())
        self.assertIn("error 5", response["error"].lower())

    def test_ntfs_journal_analysis_fails_on_nonzero_exit(self):
        def fake_runner(cmd, timeout):
            del cmd, timeout
            return (
                1,
                "",
                "You must provide a value expression following the '-like' operator.",
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fake_runner)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "ntfs_journal_analysis"
        task["requires_approval"] = False
        task["parameters"] = {"volume": "C:", "hours": 2}

        with mock.patch.object(executor, "_is_windows", return_value=True):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("ntfs_journal_analysis", response["error"])
        self.assertIn("exit code 1", response["error"].lower())
        self.assertIn("-like", response["error"])

    def test_living_off_land_detector_uses_native_local_process_listing_without_wmic(
        self,
    ):
        def fail_if_called(cmd, timeout):
            raise AssertionError(
                "command_runner should not be used for local living_off_land_detector: %r"
                % (cmd,)
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fail_if_called)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "living_off_land_detector"
        task["requires_approval"] = False
        task["parameters"] = {}

        with mock.patch.object(
            executor, "_is_windows", return_value=True
        ), mock.patch.object(
            executor,
            "_list_processes_windows_api",
            return_value=[
                {
                    "pid": 100,
                    "ppid": 4,
                    "name": "powershell.exe",
                    "cmdline": "powershell.exe -enc AAAA",
                    "exe_path": "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
                },
                {
                    "pid": 101,
                    "ppid": 4,
                    "name": "notepad.exe",
                    "cmdline": "notepad.exe",
                    "exe_path": "C:\\Windows\\System32\\notepad.exe",
                },
            ],
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "matched_lolbins": ["powershell.exe"],
                "raw_scan": {
                    "source": "windows_api",
                    "count": 2,
                    "processes": [
                        {
                            "pid": 100,
                            "ppid": 4,
                            "name": "powershell.exe",
                            "cmdline": "powershell.exe -enc AAAA",
                            "exe_path": "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
                        },
                        {
                            "pid": 101,
                            "ppid": 4,
                            "name": "notepad.exe",
                            "cmdline": "notepad.exe",
                            "exe_path": "C:\\Windows\\System32\\notepad.exe",
                        },
                    ],
                },
            },
        )
        self.assertIsNone(response["error"])

    def test_pointer_value_normalizes_ctypes_pointer_like_values(self):
        executor = self._executor(enforce_group_id=False)

        self.assertEqual(executor._pointer_value(None), 0)
        self.assertEqual(executor._pointer_value(123), 123)
        self.assertEqual(executor._pointer_value(
            ctypes.c_void_p(0x1234)), 0x1234)
        self.assertEqual(executor._pointer_value(
            ctypes.c_size_t(0x5678)), 0x5678)
        self.assertTrue(
            executor._is_access_denied_detail(
                "(-2147352567, 'Exception occurred.', (0, None, None, None, 0, -2147024893), None)"
            )
        )

    def test_running_processes_uses_native_api_listing_instead_of_tasklist(self):
        def fail_if_called(cmd, timeout):
            raise AssertionError(
                "command_runner should not be used for running_processes: %r" % (
                    cmd,)
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fail_if_called)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "running_processes"
        task["requires_approval"] = False
        task["parameters"] = {}

        with mock.patch.object(
            executor, "_is_windows", return_value=True
        ), mock.patch.object(
            executor,
            "_list_processes_windows_api",
            return_value=[
                {
                    "pid": 10,
                    "ppid": 4,
                    "name": "example.exe",
                    "exe_path": "C:\\example.exe",
                }
            ],
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "count": 1,
                "processes": [
                    {
                        "pid": 10,
                        "ppid": 4,
                        "name": "example.exe",
                        "exe_path": "C:\\example.exe",
                    }
                ],
            },
        )
        self.assertIsNone(response["error"])

    def test_scheduled_tasks_uses_native_com_listing(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "scheduled_tasks"
        task["requires_approval"] = False
        task["parameters"] = {}

        native_result = {
            "source": "taskschd.com",
            "count": 1,
            "tasks": [
                {"TaskName": "ExampleTask", "TaskPath": "\\", "State": "Ready"},
            ],
        }

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch.object(
            executor,
            "_windows_list_scheduled_tasks_native",
            return_value=(native_result, json.dumps(
                native_result, sort_keys=True)),
        ) as native_mock:
            response = executor.process(task, signature=self._sign(task))

        native_mock.assert_called_once_with()
        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(response["output"], native_result)

    def test_scheduled_tasks_blocks_on_access_denied(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "scheduled_tasks"
        task["requires_approval"] = False
        task["parameters"] = {}

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch.object(
            executor,
            "_windows_list_scheduled_tasks_native",
            side_effect=PermissionError(
                "scheduled_tasks failed: Access is denied."),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "BLOCKED")
        self.assertEqual(response["output"], {})
        self.assertIn("scheduled_tasks", response["error"])
        self.assertIn("access is denied", response["error"].lower())

    def test_scheduled_tasks_fails_on_native_error(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "scheduled_tasks"
        task["requires_approval"] = False
        task["parameters"] = {}

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch.object(
            executor,
            "_windows_list_scheduled_tasks_native",
            side_effect=RuntimeError(
                "scheduled_tasks failed: COM initialization failed."),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("scheduled_tasks failed", response["error"])

    def test_scheduled_task_deep_fails_on_nonzero_powershell_exit(self):
        def fake_runner(cmd, timeout):
            del cmd, timeout
            return (
                1,
                '{ "total_tasks": 0 }',
                "Missing closing '}' in statement block or type definition.",
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fake_runner)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "scheduled_task_deep"
        task["requires_approval"] = False
        task["parameters"] = {}

        with mock.patch.object(executor, "_is_windows", return_value=True):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("scheduled_task_deep", response["error"])
        self.assertIn("exit code 1", response["error"].lower())
        self.assertIn("missing closing", response["error"].lower())

    def test_wmi_persistence_deep_accepts_namespaces_parameter_shape(self):
        def fake_runner(cmd, timeout):
            del timeout
            self.assertEqual(
                cmd[0:4], ["powershell", "-NoProfile",
                           "-NonInteractive", "-Command"]
            )
            self.assertIn("root\\\\subscription", cmd[4])
            self.assertIn("root\\custom", cmd[4])
            return (
                0,
                '{"total_objects":1,"subscription_namespaces":["root\\\\subscription","root\\\\default","root\\\\cimv2","root\\\\custom"],"objects":[]}',
                "",
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fake_runner)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "wmi_persistence_deep"
        task["requires_approval"] = False
        task["parameters"] = {"namespaces": "root\\custom"}

        with mock.patch.object(executor, "_is_windows", return_value=True):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "command": [
                    "powershell",
                    "-NoProfile",
                    "-NonInteractive",
                    "-Command",
                    mock.ANY,
                ],
                "exit_code": 0,
                "stderr": "",
                "stdout": '{"total_objects":1,"subscription_namespaces":["root\\\\subscription","root\\\\default","root\\\\cimv2","root\\\\custom"],"objects":[]}',
            },
        )

    def test_smb_client_prefers_windows_netapi_share_enum_over_shell_path(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "smb_client"
        task["requires_approval"] = False
        task["parameters"] = {
            "target": "fileserver",
            "operation": "list_shares",
        }

        native_result = {
            "target": "fileserver",
            "source": "netapi32.NetShareEnum",
            "count": 1,
            "shares": [
                {"name": "C$", "type": 0, "remark": "Default share"},
            ],
        }

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch.object(
            executor,
            "_windows_net_share_enum",
            return_value=(native_result, json.dumps(
                native_result, sort_keys=True)),
        ) as native_mock:
            response = executor.process(task, signature=self._sign(task))

        native_mock.assert_called_once_with("fileserver")
        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(response["output"], native_result)

    def test_smb_client_fails_on_nonzero_windows_native_exit(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "smb_client"
        task["requires_approval"] = False
        task["parameters"] = {
            "target": "fileserver",
            "operation": "list_shares",
        }

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch.object(
            executor,
            "_windows_net_share_enum",
            side_effect=RuntimeError(
                "smb_share_query failed with status 53 (fileserver): The network path was not found."),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("smb_share_query failed with status 53",
                      response["error"])

    def test_smb_client_blocks_on_access_denied_windows_native_exit(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "smb_client"
        task["requires_approval"] = False
        task["parameters"] = {
            "target": "127.0.0.1",
            "operation": "list_shares",
        }

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch.object(
            executor,
            "_windows_net_share_enum",
            side_effect=PermissionError(
                "smb_share_query failed with status 5 (127.0.0.1): Access is denied."),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "BLOCKED")
        self.assertEqual(response["output"], {})
        self.assertIn("smb_share_query failed with status 5",
                      response["error"])
        self.assertIn("access is denied", response["error"].lower())

    def test_smb_client_list_path_prefers_native_scandir_over_cmd_dir(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "smb_client"
        task["requires_approval"] = False
        task["parameters"] = {
            "target": "fileserver",
            "operation": "list_path",
            "share": "tools",
            "path": "\\subdir",
        }

        fake_entry = mock.Mock()
        fake_entry.name = "agent.exe"
        fake_entry.is_dir.return_value = False
        fake_entry.stat.return_value = mock.Mock(st_size=1234)

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch.object(
            executor,
            "_windows_list_unc_path",
            return_value=(
                {
                    "target": "fileserver",
                    "share": "tools",
                    "path": "\\subdir",
                    "source": "native_os_scandir",
                    "count": 1,
                    "entries": [{"name": "agent.exe", "type": "file", "size_bytes": 1234}],
                },
                '{"count":1}',
            ),
        ) as native_mock:
            response = executor.process(task, signature=self._sign(task))

        native_mock.assert_called_once_with(
            "fileserver", "tools", "\\subdir", None, None, "")
        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "target": "fileserver",
                "share": "tools",
                "path": "\\subdir",
                "source": "native_os_scandir",
                "count": 1,
                "entries": [{"name": "agent.exe", "type": "file", "size_bytes": 1234}],
            },
        )

    def test_wmic_query_falls_back_to_native_process_list_when_wmic_missing(self):
        def fake_runner(cmd, timeout):
            del timeout
            raise FileNotFoundError(
                2, "The system cannot find the file specified", cmd[0]
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fake_runner)
        task = _base_task()
        task["category"] = "ENDPOINT"
        task["action"] = "wmic_query"
        task["requires_approval"] = False
        task["parameters"] = {"query": "process_list_brief"}

        with mock.patch.object(
            executor, "_is_windows", return_value=True
        ), mock.patch.object(
            executor,
            "_list_processes_windows_api",
            return_value=[{"pid": 22, "ppid": 4, "name": "proc.exe"}],
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "query": "process_list_brief",
                "source": "native_windows_api",
                "count": 1,
                "processes": [{"pid": 22, "ppid": 4, "name": "proc.exe"}],
            },
        )

    def test_dns_lookup_uses_native_socket_resolution_and_emits_exact_shape(self):
        def fail_if_called(cmd, timeout):
            raise AssertionError(
                "command_runner should not be used for dns_lookup: %r" % (cmd,)
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fail_if_called)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "dns_lookup"
        task["requires_approval"] = False
        task["parameters"] = {"target": "localhost"}

        fake_addrinfo = [
            (socket.AF_INET6, socket.SOCK_STREAM, 6, "", ("::1", 0, 0, 0)),
            (socket.AF_INET, socket.SOCK_STREAM, 6, "localhost", ("127.0.0.1", 0)),
            (socket.AF_INET, socket.SOCK_DGRAM, 17, "", ("127.0.0.1", 0)),
        ]

        with mock.patch(
            "hawkSoar.security.hybrid_execution.socket.getaddrinfo",
            return_value=fake_addrinfo,
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "target": "localhost",
                "canonical_name": "localhost",
                "addresses": ["127.0.0.1", "::1"],
                "source": "native_socket_getaddrinfo",
            },
        )
        self.assertIsNone(response["error"])

    def test_dns_lookup_fails_when_native_resolution_fails(self):
        def fail_if_called(cmd, timeout):
            raise AssertionError(
                "command_runner should not be used for dns_lookup: %r" % (cmd,)
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fail_if_called)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "dns_lookup"
        task["requires_approval"] = False
        task["parameters"] = {"target": "does-not-resolve.invalid"}

        with mock.patch(
            "hawkSoar.security.hybrid_execution.socket.getaddrinfo",
            side_effect=socket.gaierror(-2, "Name or service not known"),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("dns_lookup failed", response["error"])
        self.assertIn("does-not-resolve.invalid", response["error"])

    def test_ping_uses_native_windows_icmp_instead_of_ping_binary(self):
        def fail_if_called(cmd, timeout):
            raise AssertionError(
                "command_runner should not be used for ping on Windows: %r" % (
                    cmd,)
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fail_if_called)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "ping"
        task["requires_approval"] = False
        task["parameters"] = {"target": "127.0.0.1", "count": 2}

        native_result = {
            "target": "127.0.0.1",
            "resolved_ip": "127.0.0.1",
            "count": 2,
            "sent": 2,
            "received": 2,
            "lost": 0,
            "loss_percent": 0,
            "source": "native_windows_icmp",
            "responses": [
                {
                    "seq": 1,
                    "status": "SUCCESS",
                    "status_code": 0,
                    "round_trip_time_ms": 1,
                },
                {
                    "seq": 2,
                    "status": "SUCCESS",
                    "status_code": 0,
                    "round_trip_time_ms": 2,
                },
            ],
        }

        with mock.patch.object(
            executor, "_is_windows", return_value=True
        ), mock.patch.object(
            executor,
            "_windows_icmp_ping",
            return_value=(native_result, json.dumps(
                native_result, sort_keys=True)),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(response["output"], native_result)
        self.assertIsNone(response["error"])

    def test_ping_fails_when_native_windows_icmp_reports_no_replies(self):
        def fail_if_called(cmd, timeout):
            raise AssertionError(
                "command_runner should not be used for ping on Windows: %r" % (
                    cmd,)
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fail_if_called)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "ping"
        task["requires_approval"] = False
        task["parameters"] = {"target": "192.0.2.10", "count": 2}

        with mock.patch.object(
            executor, "_is_windows", return_value=True
        ), mock.patch.object(
            executor,
            "_windows_icmp_ping",
            side_effect=RuntimeError(
                "ping failed: no echo replies received for 192.0.2.10"
            ),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("ping failed", response["error"])
        self.assertIn("192.0.2.10", response["error"])

    def test_http_client_uses_native_winhttp_on_windows_and_emits_exact_shape(self):
        def fail_if_called(cmd, timeout):
            raise AssertionError(
                "command_runner should not be used for http_client on Windows: %r"
                % (cmd,)
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fail_if_called)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "http_client"
        task["requires_approval"] = False
        task["parameters"] = {
            "url": "https://example.com/api",
            "method": "GET",
            "headers": {"Accept": "application/json"},
        }

        native_result = {
            "url": "https://example.com/api",
            "method": "GET",
            "status_code": 200,
            "headers": {"Content-Type": "application/json"},
            "body": '{"ok":true}',
            "bytes": 11,
            "source": "native_winhttp",
        }

        with mock.patch.object(
            executor, "_is_windows", return_value=True
        ), mock.patch.object(
            executor,
            "_windows_http_request_native",
            return_value=(
                native_result,
                json.dumps(
                    {
                        "url": "https://example.com/api",
                        "method": "GET",
                        "status_code": 200,
                        "bytes": 11,
                        "source": "native_winhttp",
                    },
                    sort_keys=True,
                ),
            ),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(response["output"], native_result)
        self.assertIsNone(response["error"])

    def test_http_client_blocks_on_native_access_denied(self):
        def fail_if_called(cmd, timeout):
            raise AssertionError(
                "command_runner should not be used for http_client on Windows: %r"
                % (cmd,)
            )

        executor = self._executor(
            enforce_group_id=False, command_runner=fail_if_called)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "http_client"
        task["requires_approval"] = False
        task["parameters"] = {"url": "https://example.com/api"}

        with mock.patch.object(
            executor, "_is_windows", return_value=True
        ), mock.patch.object(
            executor,
            "_windows_http_request_native",
            side_effect=PermissionError(
                "http_client failed: Access is denied"),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "BLOCKED")
        self.assertEqual(response["output"], {})
        self.assertEqual(
            "http_client failed: Access is denied", response["error"])

    def test_rpc_query_fails_on_nonzero_windows_exit(self):
        def fake_runner(cmd, timeout):
            del cmd, timeout
            return 1706, "Exception 1706 (0x000006AA)\n", ""

        executor = self._executor(
            enforce_group_id=False, command_runner=fake_runner)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "rpc_query"
        task["requires_approval"] = False
        task["parameters"] = {
            "target": "hostname_or_ip",
            "endpoint": "optional_rpc_endpoint",
        }

        with mock.patch.object(executor, "_is_windows", return_value=True):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("rpc_query failed with exit code 1706",
                      response["error"])

    def test_rpc_query_blocks_on_access_denied_windows_exit(self):
        def fake_runner(cmd, timeout):
            del cmd, timeout
            return 5, "Exception 5 (0x00000005)\n", ""

        executor = self._executor(
            enforce_group_id=False, command_runner=fake_runner)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "rpc_query"
        task["requires_approval"] = False
        task["parameters"] = {"target": "127.0.0.1"}

        with mock.patch.object(executor, "_is_windows", return_value=True):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "BLOCKED")
        self.assertEqual(response["output"], {})
        self.assertIn("rpc_query failed with exit code 5", response["error"])

    def test_smb_sessions_fails_on_nonzero_exit(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "smb_sessions"
        task["requires_approval"] = False
        task["parameters"] = {}

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch.object(
            executor,
            "_windows_net_session_enum",
            side_effect=RuntimeError(
                "smb_sessions failed with status 67 (local): The network name cannot be found."),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("smb_sessions failed with status 67", response["error"])

    def test_smb_sessions_prefers_windows_netapi_session_enum(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "smb_sessions"
        task["requires_approval"] = False
        task["parameters"] = {}

        native_result = {
            "source": "netapi32.NetSessionEnum",
            "count": 1,
            "sessions": [
                {"client": "\\\\10.0.0.5", "username": "alice",
                    "active_seconds": 10, "idle_seconds": 3},
            ],
        }

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch.object(
            executor,
            "_windows_net_session_enum",
            return_value=(native_result, json.dumps(
                native_result, sort_keys=True)),
        ) as native_mock:
            response = executor.process(task, signature=self._sign(task))

        native_mock.assert_called_once_with(None)
        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(response["output"], native_result)

    def test_smb_sessions_block_on_access_denied(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "smb_sessions"
        task["requires_approval"] = False
        task["parameters"] = {}

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch.object(
            executor,
            "_windows_net_session_enum",
            side_effect=PermissionError(
                "smb_sessions failed with status 5 (local): Access is denied."),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "BLOCKED")
        self.assertEqual(response["output"], {})
        self.assertIn("smb_sessions failed with status 5", response["error"])
        self.assertIn("access is denied", response["error"].lower())

    def test_smb_share_query_fails_on_nonzero_exit(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "smb_share_query"
        task["requires_approval"] = False
        task["parameters"] = {"target": "windows-hostname"}

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch.object(
            executor,
            "_windows_net_share_enum",
            side_effect=RuntimeError(
                "smb_share_query failed with status 53 (windows-hostname): The network path was not found."),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "FAILED")
        self.assertEqual(response["output"], {})
        self.assertIn("smb_share_query failed with status 53",
                      response["error"])

    def test_smb_share_query_prefers_windows_netapi_share_enum(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "smb_share_query"
        task["requires_approval"] = False
        task["parameters"] = {"target": "fileserver"}

        native_result = {
            "target": "fileserver",
            "source": "netapi32.NetShareEnum",
            "count": 2,
            "shares": [
                {"name": "ADMIN$", "type": 0, "remark": "Remote Admin"},
                {"name": "C$", "type": 0, "remark": "Default share"},
            ],
        }

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch.object(
            executor,
            "_windows_net_share_enum",
            return_value=(native_result, json.dumps(
                native_result, sort_keys=True)),
        ) as native_mock:
            response = executor.process(task, signature=self._sign(task))

        native_mock.assert_called_once_with("fileserver")
        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(response["output"], native_result)

    def test_smb_share_query_blocks_on_access_denied(self):
        executor = self._executor(enforce_group_id=False)
        task = _base_task()
        task["category"] = "NETWORK"
        task["action"] = "smb_share_query"
        task["requires_approval"] = False
        task["parameters"] = {"target": "127.0.0.1"}

        with mock.patch.object(executor, "_is_windows", return_value=True), mock.patch.object(
            executor,
            "_windows_net_share_enum",
            side_effect=PermissionError(
                "smb_share_query failed with status 5 (127.0.0.1): Access is denied."),
        ):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "BLOCKED")
        self.assertEqual(response["output"], {})
        self.assertIn("smb_share_query failed with status 5",
                      response["error"])
        self.assertIn("access is denied", response["error"].lower())

    def test_deploy_hawk_soard_supports_explicit_sccm_transport(self):
        executor = self._executor(
            enforce_group_id=False,
            server="https://ir.hawk.io",
            access_token="local-access",
            secret_key="local-secret",
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "deploy_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "10.40.19.76",
            "username": "hawkscan",
            "password": "pw",
            "domain": "",
            "transport": "sccm",
        }

        with mock.patch(
            "hawkSoar.security.remote_deploy.find_local_installer", return_value=None
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_sccm",
            return_value={
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "sccm",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
            },
        ), mock.patch.object(executor, "_is_windows", return_value=False):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "sccm",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
                "attempted_transports": ["sccm"],
            },
        )

    def test_deploy_hawk_soard_supports_explicit_bits_smb_transport(self):
        executor = self._executor(
            enforce_group_id=False,
            server="https://ir.hawk.io",
            access_token="local-access",
            secret_key="local-secret",
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "deploy_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "10.40.19.76",
            "username": "hawkscan",
            "password": "pw",
            "domain": "",
            "transport": "bits_smb",
        }

        with mock.patch(
            "hawkSoar.security.remote_deploy.find_local_installer", return_value=None
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_bits_smb",
            return_value={
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "bits_smb",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
            },
        ), mock.patch.object(executor, "_is_windows", return_value=False):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "bits_smb",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
                "attempted_transports": ["bits_smb"],
            },
        )

    def test_deploy_hawk_soard_supports_explicit_ivanti_transport(self):
        executor = self._executor(
            enforce_group_id=False,
            server="https://ir.hawk.io",
            access_token="local-access",
            secret_key="local-secret",
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "deploy_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "10.40.19.76",
            "username": "hawkscan",
            "password": "pw",
            "domain": "",
            "transport": "ivanti",
            "ivanti_tenant_url": "https://tenant.ivanticloud.com",
            "ivanti_client_id": "cid-123",
            "ivanti_client_secret": "csecret-456",
            "ivanti_package_id": "pkg-789",
        }

        with mock.patch(
            "hawkSoar.security.remote_deploy.find_local_installer", return_value=None
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_ivanti",
            return_value={
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "ivanti",
                "status": "Completed",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": False,
                "error": None,
                "task_id": "ivanti-task-001",
            },
        ), mock.patch.object(executor, "_is_windows", return_value=False):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "ivanti",
                "status": "Completed",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": False,
                "error": None,
                "task_id": "ivanti-task-001",
                "attempted_transports": ["ivanti"],
            },
        )

    def test_deploy_hawk_soard_falls_back_to_bits_smb_when_sccm_fails(self):
        executor = self._executor(
            enforce_group_id=False,
            server="https://ir.hawk.io",
            access_token="local-access",
            secret_key="local-secret",
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "deploy_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "10.40.19.76",
            "username": "hawkscan",
            "password": "pw",
            "domain": "",
            "transport": "sccm",
        }

        with mock.patch(
            "hawkSoar.security.remote_deploy.find_local_installer", return_value=None
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_sccm",
            side_effect=RuntimeError(
                "SCCM evaluation trigger failed: connection refused."
            ),
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_bits_smb",
            return_value={
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "bits_smb",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
            },
        ), mock.patch.object(executor, "_is_windows", return_value=False):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "bits_smb",
                "status": "Running",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": True,
                "error": None,
                "fallback_used": True,
                "fallback_from": "sccm",
                "fallback_reason": "sccm transport failed: SCCM evaluation trigger failed: connection refused.",
                "attempted_transports": ["sccm", "bits_smb"],
                "attempt_errors": [
                    {
                        "transport": "sccm",
                        "error": "sccm transport failed: SCCM evaluation trigger failed: connection refused.",
                    },
                ],
            },
        )

    def test_deploy_hawk_soard_falls_back_to_ivanti_when_impacket_sccm_and_bits_fail(
        self,
    ):
        executor = self._executor(
            enforce_group_id=False,
            server="https://ir.hawk.io",
            access_token="local-access",
            secret_key="local-secret",
        )
        task = _base_task()
        task["category"] = "DEPLOY"
        task["action"] = "deploy_hawk_soard"
        task["requires_approval"] = False
        task["parameters"] = {
            "target_host": "10.40.19.76",
            "username": "hawkscan",
            "password": "pw",
            "domain": "",
            "transport": "ivanti",
            "ivanti_tenant_url": "https://tenant.ivanticloud.com",
            "ivanti_client_id": "cid-123",
            "ivanti_client_secret": "csecret-456",
            "ivanti_package_id": "pkg-789",
        }

        with mock.patch(
            "hawkSoar.security.remote_deploy.find_local_installer", return_value=None
        ), mock.patch(
            "hawkSoar.security.remote_deploy.deploy_via_ivanti",
            return_value={
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "ivanti",
                "status": "Completed",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": False,
                "error": None,
                "task_id": "ivanti-task-001",
            },
        ), mock.patch.object(executor, "_is_windows", return_value=False):
            response = executor.process(task, signature=self._sign(task))

        self.assertEqual(response["status"], "SUCCESS")
        self.assertEqual(
            response["output"],
            {
                "deployed": True,
                "target_host": "10.40.19.76",
                "transport": "ivanti",
                "status": "Completed",
                "service_name": "HawkSoard",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR",
                "config_written": False,
                "error": None,
                "task_id": "ivanti-task-001",
                "attempted_transports": ["ivanti"],
            },
        )


if __name__ == "__main__":
    unittest.main()
