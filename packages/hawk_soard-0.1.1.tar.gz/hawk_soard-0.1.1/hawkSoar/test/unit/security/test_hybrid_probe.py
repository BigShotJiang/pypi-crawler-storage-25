import unittest

from hawkSoar.security.hybrid_probe import (
    build_probe_envelope,
    build_probe_task,
    classify_probe_result,
    summarize_probe_results,
)


class TestHybridProbe(unittest.TestCase):

    def test_build_probe_task_emits_exact_targeted_task_shape(self):
        tool = {
            "tool_id": "network.dns_lookup",
            "action": "dns_lookup",
            "category": "NETWORK",
            "requires_approval": False,
            "parameters_schema": {
                "target": "ignored-by-override",
            },
        }

        task = build_probe_task(
            tool,
            group_id="group-123",
            target_node_id="node-456",
            task_id="task-789",
            case_id="case-0001",
            task_timeout=45,
            priority="LOW",
        )

        self.assertEqual(
            task,
            {
                "task_id": "task-789",
                "group_id": "group-123",
                "case_id": "case-0001",
                "category": "NETWORK",
                "action": "dns_lookup",
                "parameters": {
                    "target": "localhost",
                },
                "requires_approval": False,
                "timeout": 45,
                "priority": "LOW",
                "target_node_id": "node-456",
            },
        )

    def test_build_probe_envelope_emits_exact_shape(self):
        task = {
            "task_id": "task-789",
            "group_id": "group-123",
            "case_id": "case-0001",
            "category": "NETWORK",
            "action": "dns_lookup",
            "parameters": {
                "target": "example.com",
            },
            "requires_approval": False,
            "timeout": 45,
            "priority": "LOW",
            "target_node_id": "node-456",
        }

        envelope = build_probe_envelope(
            task,
            group_id="group-123",
            message_id="msg-abc",
        )

        self.assertEqual(
            envelope,
            {
                "id": "msg-abc",
                "cmd": "hybrid_task",
                "route": "execute",
                "group_id": "group-123",
                "target_node_id": "node-456",
                "data": task,
            },
        )

    def test_classify_probe_result_marks_failed_tool_with_healthy_manager(self):
        tool = {
            "tool_id": "deploy.hawk_soard",
            "action": "deploy_hawk_soard",
            "category": "DEPLOY",
            "requires_approval": True,
        }

        result = classify_probe_result(
            tool,
            target_node_id="node-456",
            dispatch_result={
                "task_status": "FAILED",
                "timed_out": False,
                "duration_ms": 4773,
                "error": "STATUS_NOT_SUPPORTED",
            },
            sentinel_result={
                "action": "list_processes",
                "task_status": "SUCCESS",
                "timed_out": False,
                "duration_ms": 52,
                "error": None,
                "reconnect_used": False,
            },
        )

        self.assertEqual(
            result,
            {
                "tool_id": "deploy.hawk_soard",
                "action": "deploy_hawk_soard",
                "category": "DEPLOY",
                "requires_approval": True,
                "target_node_id": "node-456",
                "probe_status": "FAILED",
                "task_status": "FAILED",
                "timed_out": False,
                "duration_ms": 4773,
                "error": "STATUS_NOT_SUPPORTED",
                "manager_state_after": "HEALTHY",
                "sentinel": {
                    "action": "list_processes",
                    "task_status": "SUCCESS",
                    "timed_out": False,
                    "duration_ms": 52,
                    "error": None,
                    "reconnect_used": False,
                },
            },
        )

    def test_classify_probe_result_marks_wedged_manager_when_probe_hangs_and_sentinel_fails(self):
        tool = {
            "tool_id": "endpoint.run_command",
            "action": "run_command",
            "category": "ENDPOINT",
            "requires_approval": False,
        }

        result = classify_probe_result(
            tool,
            target_node_id="node-456",
            dispatch_result={
                "task_status": None,
                "timed_out": True,
                "duration_ms": 30000,
                "error": "Timed out waiting for hybrid_task result",
            },
            sentinel_result={
                "action": "list_processes",
                "task_status": None,
                "timed_out": True,
                "duration_ms": 15000,
                "error": "Timed out waiting for sentinel result",
                "reconnect_used": True,
            },
        )

        self.assertEqual(
            result,
            {
                "tool_id": "endpoint.run_command",
                "action": "run_command",
                "category": "ENDPOINT",
                "requires_approval": False,
                "target_node_id": "node-456",
                "probe_status": "WEDGED_MANAGER",
                "task_status": None,
                "timed_out": True,
                "duration_ms": 30000,
                "error": "Timed out waiting for hybrid_task result",
                "manager_state_after": "WEDGED",
                "sentinel": {
                    "action": "list_processes",
                    "task_status": None,
                    "timed_out": True,
                    "duration_ms": 15000,
                    "error": "Timed out waiting for sentinel result",
                    "reconnect_used": True,
                },
            },
        )

    def test_summarize_probe_results_counts_failures_hangs_and_wedges(self):
        results = [
            {
                "tool_id": "network.dns_lookup",
                "action": "dns_lookup",
                "category": "NETWORK",
                "requires_approval": False,
                "target_node_id": "node-456",
                "probe_status": "SUCCESS",
                "task_status": "SUCCESS",
                "timed_out": False,
                "duration_ms": 30,
                "error": None,
                "manager_state_after": "HEALTHY",
                "sentinel": {
                    "action": "list_processes",
                    "task_status": "SUCCESS",
                    "timed_out": False,
                    "duration_ms": 12,
                    "error": None,
                    "reconnect_used": False,
                },
            },
            {
                "tool_id": "deploy.hawk_soard",
                "action": "deploy_hawk_soard",
                "category": "DEPLOY",
                "requires_approval": True,
                "target_node_id": "node-456",
                "probe_status": "FAILED",
                "task_status": "FAILED",
                "timed_out": False,
                "duration_ms": 4773,
                "error": "STATUS_NOT_SUPPORTED",
                "manager_state_after": "HEALTHY",
                "sentinel": {
                    "action": "list_processes",
                    "task_status": "SUCCESS",
                    "timed_out": False,
                    "duration_ms": 52,
                    "error": None,
                    "reconnect_used": False,
                },
            },
            {
                "tool_id": "endpoint.run_command",
                "action": "run_command",
                "category": "ENDPOINT",
                "requires_approval": False,
                "target_node_id": "node-456",
                "probe_status": "WEDGED_MANAGER",
                "task_status": None,
                "timed_out": True,
                "duration_ms": 30000,
                "error": "Timed out waiting for hybrid_task result",
                "manager_state_after": "WEDGED",
                "sentinel": {
                    "action": "list_processes",
                    "task_status": None,
                    "timed_out": True,
                    "duration_ms": 15000,
                    "error": "Timed out waiting for sentinel result",
                    "reconnect_used": True,
                },
            },
        ]

        summary = summarize_probe_results(results)

        self.assertEqual(
            summary,
            {
                "total": 3,
                "by_probe_status": {
                    "SUCCESS": 1,
                    "FAILED": 1,
                    "BLOCKED": 0,
                    "NO_RESPONSE": 0,
                    "WEDGED_MANAGER": 1,
                },
                "by_manager_state": {
                    "HEALTHY": 2,
                    "RECOVERED_AFTER_RECONNECT": 0,
                    "WEDGED": 1,
                },
                "failed_actions": [
                    "deploy_hawk_soard",
                ],
                "no_response_actions": [],
                "wedged_actions": [
                    "run_command",
                ],
            },
        )


if __name__ == "__main__":
    unittest.main()
