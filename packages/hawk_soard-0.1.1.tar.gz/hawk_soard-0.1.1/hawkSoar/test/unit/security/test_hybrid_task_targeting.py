"""Tests for target_node_id enforcement in TaskBroker.handle_hybrid_task."""
import unittest
from unittest import mock

from hawkSoar.manager.manager import TaskBroker


def _make_broker(my_node_id='my-node-id'):
    mock_api = mock.MagicMock()
    mock_api.authObj.getParentGroup.return_value = 'group-xyz'
    mock_api.authObj.getUUID.return_value = my_node_id
    mock_api.config = {}
    null = mock.MagicMock()
    broker = TaskBroker(mock_api, [], null, null, null,
                        null, null, null, null, null, null)
    return broker, mock_api


class TestHybridTaskTargeting(unittest.TestCase):

    def test_task_without_target_node_id_is_executed(self):
        """Broadcast tasks (no target_node_id) must be accepted by all nodes."""
        broker, mock_api = _make_broker()
        msg = {
            'id': 'req-broadcast-1',
            'cmd': 'hybrid_task', 'route': 'execute',
            'group_id': 'group-xyz',
            'data': {'task_id': 't1', 'group_id': 'group-xyz',
                     'category': 'NETWORK', 'action': 'ping',
                     'parameters': {}, 'requires_approval': False,
                     'timeout': 5, 'priority': 'LOW'},
        }
        broker.handle_hybrid_task(msg)
        mock_api.send_response.assert_called_once()
        response = mock_api.send_response.call_args[0][0]
        self.assertEqual(
            response,
            {
                'id': 'req-broadcast-1',
                'cmd': 'hybrid_task',
                'route': 'result',
                'group_id': 'group-xyz',
                'data': mock.ANY,
            },
        )

    def test_task_targeted_at_this_node_is_executed(self):
        """Tasks with target_node_id matching this node must be executed."""
        broker, mock_api = _make_broker('my-node-id')
        msg = {
            'id': 'req-targeted-1',
            'cmd': 'hybrid_task', 'route': 'execute',
            'group_id': 'group-xyz',
            'target_node_id': 'my-node-id',
            'data': {'task_id': 't2', 'group_id': 'group-xyz',
                     'category': 'NETWORK', 'action': 'ping',
                     'parameters': {}, 'requires_approval': False,
                     'timeout': 5, 'priority': 'LOW'},
        }
        broker.handle_hybrid_task(msg)
        mock_api.send_response.assert_called_once()
        response = mock_api.send_response.call_args[0][0]
        self.assertEqual(
            response,
            {
                'id': 'req-targeted-1',
                'cmd': 'hybrid_task',
                'route': 'result',
                'group_id': 'group-xyz',
                'data': mock.ANY,
            },
        )

    def test_task_targeted_at_other_node_is_silently_discarded(self):
        """
        REGRESSION: Tasks with target_node_id NOT matching this node must be silently
        discarded — not executed. Without this check, every node in the group executes
        every targeted task because the old server broadcast to all nodes regardless.
        """
        broker, mock_api = _make_broker('my-node-id')
        msg = {
            'cmd': 'hybrid_task', 'route': 'execute',
            'group_id': 'group-xyz',
            'target_node_id': 'other-node-id',
            'data': {'task_id': 't3', 'group_id': 'group-xyz',
                     'category': 'NETWORK', 'action': 'ping',
                     'parameters': {}, 'requires_approval': False,
                     'timeout': 5, 'priority': 'LOW'},
        }
        broker.handle_hybrid_task(msg)
        mock_api.send_response.assert_not_called()

    def test_target_node_id_in_data_envelope_also_filtered(self):
        """target_node_id nested inside data.target_node_id must also be honoured."""
        broker, mock_api = _make_broker('my-node-id')
        msg = {
            'id': 'req-filtered-1',
            'cmd': 'hybrid_task', 'route': 'execute',
            'group_id': 'group-xyz',
            'data': {'task_id': 't4', 'group_id': 'group-xyz',
                     'target_node_id': 'other-node-id',
                     'category': 'NETWORK', 'action': 'ping',
                     'parameters': {}, 'requires_approval': False,
                     'timeout': 5, 'priority': 'LOW'},
        }
        broker.handle_hybrid_task(msg)
        mock_api.send_response.assert_not_called()

    def test_result_must_preserve_inbound_request_id_exactly(self):
        broker, mock_api = _make_broker('my-node-id')
        msg = {
            'id': 'req-preserve-123',
            'cmd': 'hybrid_task',
            'route': 'execute',
            'group_id': 'group-xyz',
            'target_node_id': 'my-node-id',
            'data': {
                'task_id': 'task-preserve-123',
                'group_id': 'group-xyz',
                'case_id': 'case-preserve-123',
                'category': 'NETWORK',
                'action': 'ping',
                'parameters': {'target': '127.0.0.1', 'count': 1},
                'requires_approval': False,
                'timeout': 5,
                'priority': 'LOW',
            },
        }

        broker.handle_hybrid_task(msg)

        mock_api.send_response.assert_called_once()
        response = mock_api.send_response.call_args[0][0]
        self.assertEqual(response['id'], 'req-preserve-123')
        self.assertEqual(response['cmd'], 'hybrid_task')
        self.assertEqual(response['route'], 'result')
        self.assertEqual(response['group_id'], 'group-xyz')
        self.assertIsInstance(response['data'], dict)
        self.assertEqual(response['data'].get('task_id'), 'task-preserve-123')

    def test_missing_inbound_request_id_is_rejected_instead_of_generating_new_id(self):
        broker, mock_api = _make_broker('my-node-id')
        msg = {
            'cmd': 'hybrid_task',
            'route': 'execute',
            'group_id': 'group-xyz',
            'target_node_id': 'my-node-id',
            'data': {
                'task_id': 'task-missing-id-123',
                'group_id': 'group-xyz',
                'case_id': 'case-missing-id-123',
                'category': 'NETWORK',
                'action': 'ping',
                'parameters': {'target': '127.0.0.1', 'count': 1},
                'requires_approval': False,
                'timeout': 5,
                'priority': 'LOW',
            },
        }

        broker.handle_hybrid_task(msg)

        mock_api.send_response.assert_not_called()


if __name__ == '__main__':
    unittest.main()
