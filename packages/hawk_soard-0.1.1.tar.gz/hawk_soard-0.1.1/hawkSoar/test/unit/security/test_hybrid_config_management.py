import configparser
import json
import os
import shutil
import tempfile
import unittest

from hawkSoar.security.hybrid_execution import HybridTaskExecutor


def _base_task(**overrides):
    task = {
        "task_id": "11111111-1111-1111-1111-111111111111",
        "group_id": "22222222-2222-2222-2222-222222222222",
        "case_id": "33333333-3333-3333-3333-333333333333",
        "category": "CONFIG",
        "action": "config_read",
        "parameters": {},
        "requires_approval": True,
        "timeout": 30,
        "priority": "LOW",
    }
    task.update(overrides)
    return task


class _ConfigTestBase(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp(prefix="hybrid-config-test-")
        self.config_path = os.path.join(self.temp_dir, "hawk-soard.cfg")
        parser = configparser.ConfigParser()
        parser.add_section("SETTINGS")
        parser.set("SETTINGS", "server", "https://example.com")
        parser.set("SETTINGS", "access_token", "tok-abc123")
        parser.set("SETTINGS", "secret_key", "sek-xyz789")
        parser.set("SETTINGS", "insecure", "false")
        parser.set("SETTINGS", "timeout", "30")
        parser.set("SETTINGS", "enable_remote_config_management", "true")
        parser.set("SETTINGS", "enable_command_execution", "true")
        parser.set("SETTINGS", "hybrid_advertise_interval", "60")
        parser.add_section("MANAGER")
        parser.set("MANAGER", "poll", "1")
        parser.set("MANAGER", "block", "1")
        parser.set("MANAGER", "db_type", "sqlite")
        parser.add_section("PLUGINS")
        parser.set("PLUGINS", "data_path", self.temp_dir)
        with open(self.config_path, "w") as fp:
            parser.write(fp)
        self.config = {
            "_config_file_path": self.config_path,
            "enable_remote_config_management": True,
            "enable_command_execution": True,
            "enforce_signed_hybrid_tasks": False,
            "enforce_group_id": False,
            "max_task_timeout": 900,
            "plugin_data_path": self.temp_dir,
            "hybrid_dynamic_tools_file": "",
            "server": ["https://example.com"],
            "access_token": "tok-abc123",
            "secret_key": "sek-xyz789",
            "timeout": "30",
            "hybrid_advertise_interval": 60,
        }

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def _executor(self, **overrides):
        cfg = dict(self.config)
        cfg.update(overrides)
        return HybridTaskExecutor(
            config=cfg,
            expected_group_id_getter=lambda: "22222222-2222-2222-2222-222222222222",
        )


class TestConfigRead(_ConfigTestBase):
    def test_config_read_returns_settings(self):
        ex = self._executor()
        task = _base_task(action="config_read", parameters={})
        result = ex.process(task)
        self.assertEqual(result["status"], "SUCCESS")
        self.assertIsInstance(result["output"], dict)
        settings = result["output"].get("settings", {})
        self.assertIn("enable_command_execution", settings)

    def test_config_read_masks_sensitive_keys(self):
        ex = self._executor()
        task = _base_task(action="config_read", parameters={})
        result = ex.process(task)
        settings = result["output"].get("settings", {})
        self.assertNotEqual(settings.get("access_token"), "tok-abc123")
        self.assertNotEqual(settings.get("secret_key"), "sek-xyz789")
        self.assertIn("***", settings.get("access_token", ""))

    def test_config_read_filters_by_keys_string(self):
        ex = self._executor()
        task = _base_task(
            action="config_read",
            parameters={"keys": "enable_command_execution,timeout"},
        )
        result = ex.process(task)
        settings = result["output"].get("settings", {})
        self.assertIn("enable_command_execution", settings)
        self.assertIn("timeout", settings)
        self.assertNotIn("access_token", settings)

    def test_config_read_filters_by_keys_list(self):
        ex = self._executor()
        task = _base_task(
            action="config_read",
            parameters={"keys": ["hybrid_advertise_interval"]},
        )
        result = ex.process(task)
        settings = result["output"].get("settings", {})
        self.assertIn("hybrid_advertise_interval", settings)
        self.assertIn("_config_file_path", settings)

    def test_config_read_blocked_when_disabled(self):
        ex = self._executor(enable_remote_config_management=False)
        task = _base_task(action="config_read", parameters={})
        result = ex.process(task)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertIn("disabled by policy", result["error"])

    def test_config_read_succeeds_without_approval_when_remote_enabled(self):
        ex = self._executor(enable_remote_config_management=True)
        task = _base_task(
            action="config_read", parameters={}, requires_approval=False
        )
        result = ex.process(task)
        self.assertEqual(result["status"], "SUCCESS")

    def test_config_read_blocked_without_approval_when_remote_disabled(self):
        ex = self._executor(enable_remote_config_management=False)
        task = _base_task(
            action="config_read", parameters={}, requires_approval=False
        )
        result = ex.process(task)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertIn("requires approval", result["error"].lower())

    def test_config_read_in_allowed_categories(self):
        self.assertIn("CONFIG", HybridTaskExecutor.ALLOWED_CATEGORIES)

    def test_config_read_in_allowed_actions(self):
        self.assertIn(
            "config_read", HybridTaskExecutor.ALLOWED_ACTIONS.get(
                "CONFIG", set())
        )


class TestConfigUpdate(_ConfigTestBase):
    def test_config_update_writes_to_file(self):
        ex = self._executor()
        task = _base_task(
            action="config_update",
            parameters={"settings": {"hybrid_advertise_interval": "120"}},
        )
        result = ex.process(task)
        self.assertEqual(result["status"], "SUCCESS")
        output = result["output"]
        self.assertIn("hybrid_advertise_interval",
                      output.get("updated_keys", []))
        parser = configparser.ConfigParser()
        parser.read(self.config_path)
        self.assertEqual(parser.get(
            "SETTINGS", "hybrid_advertise_interval"), "120")

    def test_config_update_applies_live(self):
        ex = self._executor()
        task = _base_task(
            action="config_update",
            parameters={"settings": {"enable_command_execution": "false"}},
        )
        result = ex.process(task)
        self.assertEqual(result["status"], "SUCCESS")
        self.assertEqual(result["output"].get("live_applied"), True)
        self.assertFalse(ex.enable_command_execution)

    def test_config_update_creates_backup(self):
        ex = self._executor()
        task = _base_task(
            action="config_update",
            parameters={"settings": {"timeout": "60"}},
        )
        result = ex.process(task)
        self.assertEqual(result["status"], "SUCCESS")
        self.assertTrue(os.path.exists(self.config_path + ".backup"))

    def test_config_update_blocks_internal_keys(self):
        ex = self._executor()
        task = _base_task(
            action="config_update",
            parameters={"settings": {"_config_file_path": "/evil/path"}},
        )
        result = ex.process(task)
        output = result["output"]
        self.assertIn("_config_file_path", output.get("skipped", {}))

    def test_config_update_rejects_empty_settings(self):
        ex = self._executor()
        task = _base_task(
            action="config_update",
            parameters={"settings": {}},
        )
        result = ex.process(task)
        self.assertEqual(result["status"], "BLOCKED")

    def test_config_update_rejects_missing_settings(self):
        ex = self._executor()
        task = _base_task(
            action="config_update",
            parameters={},
        )
        result = ex.process(task)
        self.assertEqual(result["status"], "BLOCKED")

    def test_config_update_blocked_when_disabled(self):
        ex = self._executor(enable_remote_config_management=False)
        task = _base_task(
            action="config_update",
            parameters={"settings": {"timeout": "60"}},
        )
        result = ex.process(task)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertIn("disabled by policy", result["error"])

    def test_config_update_succeeds_without_approval_when_remote_enabled(self):
        ex = self._executor(enable_remote_config_management=True)
        task = _base_task(
            action="config_update",
            parameters={"settings": {"timeout": "60"}},
            requires_approval=False,
        )
        result = ex.process(task)
        self.assertEqual(result["status"], "SUCCESS")

    def test_config_update_blocked_without_approval_when_remote_disabled(self):
        ex = self._executor(enable_remote_config_management=False)
        task = _base_task(
            action="config_update",
            parameters={"settings": {"timeout": "60"}},
            requires_approval=False,
        )
        result = ex.process(task)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertIn("requires approval", result["error"].lower())

    def test_config_update_in_allowed_actions(self):
        self.assertIn(
            "config_update", HybridTaskExecutor.ALLOWED_ACTIONS.get(
                "CONFIG", set())
        )

    def test_config_update_rejects_missing_config_file(self):
        ex = self._executor(_config_file_path="/nonexistent/path.cfg")
        task = _base_task(
            action="config_update",
            parameters={"settings": {"timeout": "60"}},
        )
        result = ex.process(task)
        self.assertEqual(result["status"], "FAILED")

    def test_config_update_multiple_keys(self):
        ex = self._executor()
        task = _base_task(
            action="config_update",
            parameters={
                "settings": {
                    "timeout": "45",
                    "hybrid_advertise_interval": "120",
                    "enable_remote_config_management": "true",
                }
            },
        )
        result = ex.process(task)
        self.assertEqual(result["status"], "SUCCESS")
        self.assertEqual(len(result["output"].get("updated_keys", [])), 3)
        parser = configparser.ConfigParser()
        parser.read(self.config_path)
        self.assertEqual(parser.get("SETTINGS", "timeout"), "45")
        self.assertEqual(parser.get(
            "SETTINGS", "hybrid_advertise_interval"), "120")


class TestConfigCategoryCatalog(unittest.TestCase):
    def test_config_tools_in_catalog(self):
        from hawkSoar.security.hybrid_catalog import HybridToolCatalog

        catalog = HybridToolCatalog(config={})
        data = catalog.export(group_id="test-group")
        tool_ids = [t["tool_id"] for t in data.get("tools", [])]
        self.assertIn("config.read", tool_ids)
        self.assertIn("config.update", tool_ids)

    def test_config_tools_have_correct_category(self):
        from hawkSoar.security.hybrid_catalog import HybridToolCatalog

        catalog = HybridToolCatalog(config={})
        data = catalog.export(group_id="test-group")
        config_tools = [
            t for t in data.get("tools", []) if t.get("category") == "CONFIG"
        ]
        self.assertTrue(len(config_tools) >= 2)
        for tool in config_tools:
            self.assertEqual(tool["category"], "CONFIG")
            self.assertTrue(tool.get("requires_approval"))

    def test_config_read_requires_approval(self):
        from hawkSoar.security.hybrid_catalog import HybridToolCatalog

        catalog = HybridToolCatalog(config={})
        data = catalog.export(group_id="test-group")
        read_tool = next(
            (t for t in data["tools"] if t.get(
                "action") == "config_read"), None
        )
        self.assertIsNotNone(read_tool)
        self.assertTrue(read_tool.get("requires_approval"))

    def test_config_update_requires_approval(self):
        from hawkSoar.security.hybrid_catalog import HybridToolCatalog

        catalog = HybridToolCatalog(config={})
        data = catalog.export(group_id="test-group")
        update_tool = next(
            (t for t in data["tools"] if t.get(
                "action") == "config_update"), None
        )
        self.assertIsNotNone(update_tool)
        self.assertTrue(update_tool.get("requires_approval"))
