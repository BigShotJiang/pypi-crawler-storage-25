
__version__ = '0.2'
__author__ = 'Jason Wheeler'


def to_unicode(obj, encoding='utf-8', errors='replace'):
    ''' convert a 'str' to 'unicode' '''
    if isinstance(obj, basestring):
        if not isinstance(obj, unicode):
            obj = unicode(obj, encoding, errors)
    return obj


def to_utf8(obj, errors='replace'):
    '''convert 'unicode' to an encoded utf-8 byte string '''
    if isinstance(obj, unicode):
        obj = obj.encode('utf-8', errors)
    return obj


class HawkIOException(Exception):
    """Base Hawk Error. All other Errors thrown by hawk should inherit from this. """

    def __init__(self, value=None):
        # super(Exception).__init__(self)
        self.value = value

    def __str__(self):
        return "%s" % to_utf8(self.value)

    def __unicode__(self):
        return "%s" % to_unicode(self.value)


class HawkBaseError(HawkIOException):
    def __init__(self, msg, errors=None):
        HawkIOException.__init__(self, msg)


class HawkCoreError(HawkIOException):
    """Class to catch hawk core errors. """

    def __init__(self, msg, errors=None, api_server=None):
        HawkBaseError.__init__(self, msg)
        if api_server is not None:
            self.api_server = api_server
        self.errors = errors


class HawkApiError(HawkIOException):
    """Class to catch hawk api errors. """

    def __init__(self, msg, errors=None):
        HawkBaseError.__init__(self, msg)
        self.errors = errors

class HawkApiValidationError(HawkApiError):
    """Pre-check if json is valid, If not raise this error. """

    def __init__(self, msg, errors=None):
        HawkApiError.__init__(self, msg, errors)
        self.validation_errors = errors


class HawkApiIncidentAddError(HawkApiError):
    """Class to catch error adding incident to api. """

    def __init__(self, msg, errors=None):
        HawkApiError.__init__(self, msg, errors)


class HawkLoginError(HawkIOException):
    """ This class means Login to API failed. """

    def __init__(self, msg, errors=None, user=None):
        HawkBaseError.__init__(self, msg)
        if user is not None:
            self.user = user
        self.errors = errors


class HawkLogoutError(HawkIOException):
    """ This class means Login to API failed. """

    def __init__(self, msg, errors=None, user=None):
        HawkBaseError.__init__(self, msg)
        if user is not None:
            self.user = user
        self.errors = errors
