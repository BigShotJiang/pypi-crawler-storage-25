

import os
import sys
import json
import requests
import time
from urllib.parse import urlparse

import xml
import radix
import csv
import zipfile
import pickle
import pysos

import shutil

from hawkSoar.common.logger import get_logger
from hawkSoar.common.process import ExceptionSafeProcess
from hawkSoar.plugins.base import BasePlugin
from hawkSoar.lib.query_parser import QueryInterpreter


class InvestigatePlugin(BasePlugin):

    ID = 'hawk-case-management'
    NAME = 'Promote Case (HAWK Case Management)'
    DESCRIPTION = ''
    TYPE = 'investigate'
    DEPENDENCIES = []
    VERSION = '0.0.1'
    MODULE = "playbook.investigate.PromoteCase"
    ENABLED = True
    Exceptions = []
    playbookCache = {}
    activeRequests = []
    activeURL = {}

    def __init__(self, plugin_administrator, config=None):
        super().__init__(plugin_administrator, config=config, plugin_path=__file__)
        self.config = config
        self.logger = get_logger()
        self.playbookCache = {}

    def process_task(self, task):
        self.logger.debug("DATA ENRICHMENT TASK RECEIVED: %s" % task['cmd'])
        self.logger.debug(json.dumps(task))
        if task['cmd'] == 'addPlaybookStep':

            # make sure we have everything we need to start making incident stuff...

            self._add_playbook_step(task['data'])
            # start up new worker when new task arrives.

            if not task['data']['id'] in self.playbookCache:
                self.playbookCache[task['data']['id']] = {}

            playbookId = task['data']['id']
            stepId = task['data']['step']['id']
            self.logger.debug(task['data']['step'])
            self.playbookCache[playbookId][stepId] = {
                'config':  task['data']['config'],
                'step':  task['data']['step']
            }

            # load up and additional configs

            # query for all available columns
            t2 = task.deepcopy()
            t2['cmd'] = 'getNormalization'
            self.outgoing_queue.put(t2)
        elif task['cmd'] == 'getNormalization':
            # save column fields
            print(task)
            self.columns = task['data']
        else:

            self.logger.debug("DATA ENRICHMENT DO IT TASK")
            # self.logger.debug(task)
            playbookId = task['data']['playbookId']
            stepId = task['data']['step']

            step = self.playbookCache[playbookId][stepId]

            # print(self.get_step_by_id(task['data']['playbookId'], task['data']['step']))

            task['data']['data']['artifacts'].append(
                {"plugin_id": self.ID, "name": "version", "module": self.MODULE, "type": "app.version",  "value": self.VERSION})

            result = None

            stepObj = self.get_step_by_id(
                task['data']['playbookId'], task['data']['step'])

            # make web request and post data to the API.  this api point will create the
            # orient record, de-dupe it, and create vertice links with timerange
            # the UX/api will allow us to query the relationships in any way, and start by viewing by incident name

            """
            for column in step['config']['lookup']:
                if column in task['data']['data'][step['config']['class']]:
                    val = task['data']['data'][step['config']['class']][column]
                    print("LOOKUP ENRICHMENT RECORD FOR value: %s" % str(val))
                    if self.playbookCache[playbookId][stepId]['config']['index_type'] == 'text':
                        try:
                            result = step['index'][val.strip()]
                        except KeyError as e:
                            result = None
                    elif self.playbookCache[playbookId][stepId]['config']['index_type'] == 'cidr':
                        res = step['index'].search_exact(val)
                        print(res)
                        if res and hasattr(res, 'data'):
                            result = res.data
                    else:
                        raise Exception(
                            "Unknown index type: %s" % self.playbookCache[playbookId][stepId]['config']['index_type'])

                if result:
                    # add data
                    print("FOUND ENRICHMENT DATA")
                    # print(result)
                    task['data']['data']['artifacts'].append(
                        {"plugin_id": self.ID, "type": "data.enrichment", "module": self.MODULE, "name": "%s.%s" % (stepObj['config']['class'], column), "value": result})

                    if 'tags' in stepObj:
                        for tag in stepObj['tags']:
                            if tag not in task['data']['data']['tags']:
                                task['data']['data']['tags'].append(tag)

                result = None
            """

            # submit fields to API for saving in classes

            task['data']['data']['return_value'] = True

            task['route'] = 'publish'

            # print(step)
            task['data']['step'] = step['step']['next']

            #self.logger.debug("OUTGOING ENRICHMENT TASK")
            # self.logger.debug(json.dumps(task))

            self.outgoing_queue.put(task)

    def add_exception(self, msg):
        self.Exceptions.append(msg)

    def check_exceptions(self):
        # if exceptiosn found, then log out
        return self.Exceptions

    def shutdown(self):
        # stop all on-going workers here
        self.logger.debug('Case management plugin is now shutting down.')
        self.logger.debug('Case management shutdown complete.')
