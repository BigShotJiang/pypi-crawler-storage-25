
from hawkSoar.storage.db_interface import DBInterface


class ViewSyncDb(DBInterface):
    '''
    View Syncing
    '''

    def __init__(self, config=None):
        super().__init__(config=config)


class ViewUpdater(ViewSyncDb):
    """ Updates the HTML view for a given plugin."""

    READ_ONLY = False

    def update_view(self, plugin_name, content):
        query = 'UPDATE plugin_view set html=? WHERE plugin_name=?'
        with self.client.connect() as conn:
            try:
                conn.execute(query, (content, plugin_name))
                conn.commit()
            except Exception as e:
                self.logger.exception("Failed to update view for %s: %s" % (plugin_name, e))
                raise


class ViewReader(ViewSyncDb):

    READ_ONLY = True

    def get_view(self, plugin_name):
        query = 'SELECT html FROM plugin_view WHERE plugin_name=?'
        with self.client.connect() as conn:
            try:
                result = conn.execute(query, (plugin_name,))
                row = result.fetchone()
                if row:
                    return row[0]
                return None
            except Exception as e:
                self.logger.exception("Failed to get view for %s: %s" % (plugin_name, e))
                raise
