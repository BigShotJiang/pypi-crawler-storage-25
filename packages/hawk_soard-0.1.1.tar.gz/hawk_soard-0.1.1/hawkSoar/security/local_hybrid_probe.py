from uuid import uuid4

from hawkSoar.security.hybrid_probe import override_probe_params, schema_to_params


LOCAL_PROBE_STATUSES = (
    "SUCCESS",
    "FAILED",
    "BLOCKED",
    "SKIPPED",
)

REMOTE_REQUIRED_ACTIONS = {
    "deploy_hawk_soard",
    "verify_hawk_soard",
    "remote_wmic_query",
    "remote_command_execute",
    "remote_registry_query",
    "remote_config_update",
    "remote_service_restart",
    "remote_process_restart",
    "remote_process_snapshot",
    "remote_process_snapshot_by_name",
    "remote_file_system_list",
    "remote_file_collect",
}

DOMAIN_CONTEXT_ACTIONS = {
    "ad_replication_drift_probe",
    "enumerate_group_membership",
    "get_user_details",
    "gpo_startup_script_view",
    "retrieve_last_logon",
}


def build_local_probe_task(
    tool,
    *,
    group_id,
    task_timeout,
    priority,
    task_id=None,
    case_id=None,
):
    action = str(tool.get("action"))
    return {
        "task_id": task_id or str(uuid4()),
        "group_id": group_id,
        "case_id": case_id or ("local-probe-%s" % str(uuid4())),
        "category": str(tool.get("category", "NETWORK")),
        "action": action,
        "parameters": override_probe_params(
            action,
            schema_to_params(tool.get("parameters_schema", {})),
        ),
        "requires_approval": bool(tool.get("requires_approval", False)),
        "timeout": int(task_timeout),
        "priority": priority,
    }


def determine_local_skip_reason(tool, *, include_approval_required, host_context):
    action = str(tool.get("action") or "")
    if bool(tool.get("requires_approval")) and not include_approval_required:
        return "approval_required"
    if action in REMOTE_REQUIRED_ACTIONS:
        return "remote_target_required"
    if action in DOMAIN_CONTEXT_ACTIONS and not str((host_context or {}).get("userdnsdomain") or "").strip():
        return "domain_context_required"
    return None


def classify_local_probe_result(tool, *, task, response=None, skip_reason=None):
    if skip_reason:
        probe_status = "SKIPPED"
    else:
        probe_status = str((response or {}).get("status") or "FAILED").upper()
        if probe_status not in LOCAL_PROBE_STATUSES:
            probe_status = "FAILED"

    return {
        "tool_id": tool.get("tool_id"),
        "action": tool.get("action"),
        "category": tool.get("category"),
        "requires_approval": bool(tool.get("requires_approval", False)),
        "probe_status": probe_status,
        "task": task,
        "response": response,
        "skip_reason": skip_reason,
    }


def summarize_local_probe_results(results):
    by_probe_status = dict((status, 0) for status in LOCAL_PROBE_STATUSES)
    failed_actions = []
    blocked_actions = []
    skipped_actions = []
    executed = 0
    skipped = 0

    for result in results:
        probe_status = result.get("probe_status")
        action = result.get("action")
        if probe_status in by_probe_status:
            by_probe_status[probe_status] += 1
        if probe_status == "SKIPPED":
            skipped += 1
            skipped_actions.append(action)
        else:
            executed += 1
        if probe_status == "FAILED":
            failed_actions.append(action)
        if probe_status == "BLOCKED":
            blocked_actions.append(action)

    return {
        "total": len(results),
        "executed": executed,
        "skipped": skipped,
        "by_probe_status": by_probe_status,
        "failed_actions": failed_actions,
        "blocked_actions": blocked_actions,
        "skipped_actions": skipped_actions,
    }
