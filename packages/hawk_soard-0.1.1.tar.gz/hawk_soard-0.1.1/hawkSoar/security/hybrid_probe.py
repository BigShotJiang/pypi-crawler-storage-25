import os
from uuid import uuid4


PROBE_STATUSES = (
    "SUCCESS",
    "FAILED",
    "BLOCKED",
    "NO_RESPONSE",
    "WEDGED_MANAGER",
)

MANAGER_STATES = (
    "HEALTHY",
    "RECOVERED_AFTER_RECONNECT",
    "WEDGED",
)


def schema_to_params(value):
    if isinstance(value, dict):
        return {k: schema_to_params(v) for k, v in value.items()}
    if isinstance(value, list):
        return [schema_to_params(item) for item in value]
    if isinstance(value, (bool, int, float)) or value is None:
        return value
    return str(value)


def override_probe_params(action, params):
    params = dict(params or {})
    if action == "dns_lookup":
        return {"target": "localhost"}
    if action == "ping":
        return {"target": "127.0.0.1", "count": 2}
    if action == "rpc_query":
        return {"target": "127.0.0.1"}
    if action == "smb_client":
        params["target"] = "127.0.0.1"
        params["operation"] = "list_shares"
        return params
    if action == "smb_share_query":
        return {"target": "127.0.0.1"}
    if action == "http_client":
        return {"url": "https://example.com", "method": "GET", "timeout": 10}
    if action == "event_log_extraction":
        return {"log_name": "System", "count": 50}
    if action == "run_command":
        return {"argv": ["whoami"]}
    if action == "wmic_query":
        return {"query": "process_list_brief"}
    if action == "list_processes":
        return {}
    if action == "list_users":
        return {}
    if action == "process_hook_scan":
        return {"pid": os.getpid()}
    if action == "process_modules":
        return {"pid": os.getpid()}
    if action == "token_privilege_inspect":
        return {"pid": os.getpid()}
    if action == "logged_in_users_login_time":
        return {}
    if action == "list_drives":
        return {}
    if action == "list_event_log_channels":
        return {}
    if action == "registry_query":
        return {"path": "HKLM\\SOFTWARE"}
    if action == "living_off_land_detector":
        return {}
    if action == "memory_suspect_modules":
        return {"pid": os.getpid()}
    if action == "memory_ioc_extractor":
        return {"pid": os.getpid(), "min_b64": 64}
    if action == "office_macro_scan":
        return {"path": os.path.expanduser("~"), "max_files": 100}
    if action == "event_log_enriched":
        return {"channel": "System", "count": 10}
    if action == "registry_read":
        return {"path": "HKLM\\SOFTWARE", "recursive": False}
    if action == "disk_read":
        return {"path": os.getcwd(), "recursive": False, "max_items": 25}
    if action == "register_dynamic_tool":
        return {
            "tool_id": "test.echo.tool",
            "name": "Test Echo Tool",
            "category": "ENDPOINT",
            "action": "test_echo_tool",
            "description": "Temporary e2e test tool",
            "command": ["echo", "{message}"],
            "parameters_schema": {"message": "hello"},
            "requires_approval": True,
            "risk": "LOW",
        }
    if action == "test_echo_tool":
        return {"message": "hello"}
    return params


def build_probe_task(
    tool,
    *,
    group_id,
    target_node_id,
    task_timeout,
    priority,
    task_id=None,
    case_id=None,
):
    action = str(tool.get("action"))
    task = {
        "task_id": task_id or str(uuid4()),
        "group_id": group_id,
        "case_id": case_id or ("probe-%s" % str(uuid4())),
        "category": str(tool.get("category", "NETWORK")),
        "action": action,
        "parameters": override_probe_params(
            action,
            schema_to_params(tool.get("parameters_schema", {})),
        ),
        "requires_approval": bool(tool.get("requires_approval", False)),
        "timeout": int(task_timeout),
        "priority": priority,
        "target_node_id": target_node_id,
    }
    return task


def build_probe_envelope(task, *, group_id, message_id=None):
    return {
        "id": message_id or str(uuid4()),
        "cmd": "hybrid_task",
        "route": "execute",
        "group_id": group_id,
        "target_node_id": task.get("target_node_id"),
        "data": task,
    }


def classify_probe_result(tool, *, target_node_id, dispatch_result, sentinel_result):
    manager_state = "HEALTHY"
    probe_status = dispatch_result.get("task_status")
    if sentinel_result.get("timed_out"):
        manager_state = "WEDGED"
        probe_status = "WEDGED_MANAGER"
    elif sentinel_result.get("reconnect_used"):
        manager_state = "RECOVERED_AFTER_RECONNECT"
        if dispatch_result.get("timed_out"):
            probe_status = "NO_RESPONSE"
    elif dispatch_result.get("timed_out"):
        probe_status = "NO_RESPONSE"

    if probe_status not in PROBE_STATUSES:
        probe_status = "FAILED"

    return {
        "tool_id": tool.get("tool_id"),
        "action": tool.get("action"),
        "category": tool.get("category"),
        "requires_approval": bool(tool.get("requires_approval", False)),
        "target_node_id": target_node_id,
        "probe_status": probe_status,
        "task_status": dispatch_result.get("task_status"),
        "timed_out": bool(dispatch_result.get("timed_out", False)),
        "duration_ms": int(dispatch_result.get("duration_ms", 0)),
        "error": dispatch_result.get("error"),
        "manager_state_after": manager_state,
        "sentinel": {
            "action": sentinel_result.get("action"),
            "task_status": sentinel_result.get("task_status"),
            "timed_out": bool(sentinel_result.get("timed_out", False)),
            "duration_ms": int(sentinel_result.get("duration_ms", 0)),
            "error": sentinel_result.get("error"),
            "reconnect_used": bool(sentinel_result.get("reconnect_used", False)),
        },
    }


def summarize_probe_results(results):
    by_probe_status = dict((status, 0) for status in PROBE_STATUSES)
    by_manager_state = dict((state, 0) for state in MANAGER_STATES)
    failed_actions = []
    no_response_actions = []
    wedged_actions = []

    for result in results:
        probe_status = result.get("probe_status")
        manager_state = result.get("manager_state_after")
        action = result.get("action")
        if probe_status in by_probe_status:
            by_probe_status[probe_status] += 1
        if manager_state in by_manager_state:
            by_manager_state[manager_state] += 1
        if probe_status == "FAILED":
            failed_actions.append(action)
        if probe_status == "NO_RESPONSE":
            no_response_actions.append(action)
        if probe_status == "WEDGED_MANAGER":
            wedged_actions.append(action)

    return {
        "total": len(results),
        "by_probe_status": by_probe_status,
        "by_manager_state": by_manager_state,
        "failed_actions": failed_actions,
        "no_response_actions": no_response_actions,
        "wedged_actions": wedged_actions,
    }
