import copy
import json
import os
import re


class HybridToolCatalog(object):
    VERSION = "1.0.0"

    TOOLS = [
        {
            "tool_id": "dns.tunnel_score",
            "name": "DNS Tunnel Score",
            "category": "NETWORK",
            "action": "dns_tunnel_score",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": "Scores internal DNS query behavior for tunneling indicators.",
            "triggers": ["dns_exfiltration_suspected", "high_entropy_dns_queries"],
            "parameters_schema": {"query_names": ["host.internal.example"]},
        },
        {
            "tool_id": "ad.replication_drift_probe",
            "name": "AD Replication Drift Probe",
            "category": "AD",
            "action": "ad_replication_drift_probe",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": "Checks AD replication health/drift directly from domain infrastructure.",
            "triggers": ["dc_replication_errors", "directory_sync_drift"],
            "parameters_schema": {},
        },
        {
            "tool_id": "gpo.startup_script_view",
            "name": "GPO Startup Script View",
            "category": "AD",
            "action": "gpo_startup_script_view",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": "Returns GPO startup/logon script contents for analyst inspection.",
            "triggers": ["suspicious_gpo_change", "gpo_script_execution_alert"],
            "parameters_schema": {"limit": 30},
        },
        {
            "tool_id": "tier0.admin_path_mapper",
            "name": "Tier0 Admin Path Mapper",
            "category": "AD",
            "action": "tier0_admin_path_mapper",
            "execution_mode": "trigger_only",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "TRIGGER-ONLY (not directly executable) — Maps high-value admin paths and privilege "
                "chokepoints inside customer AD. Fires automatically on tier0_access_anomaly and "
                "admin_escalation_suspected triggers. Cannot be invoked via hybrid_task directly; "
                "use hybrid_catalog route=trigger to generate a plan for these triggers instead. "
                "NOTE: action handler is pending implementation — trigger plans will include this "
                "entry but execution will return an action-not-found error until implemented."
            ),
            "triggers": ["tier0_access_anomaly", "admin_escalation_suspected"],
            "parameters_schema": {"seed_accounts": ["Administrator"]},
            "status": "pending_implementation",
        },
        {
            "tool_id": "legacy_protocol_exposure_map",
            "name": "Legacy Protocol Exposure Map",
            "category": "NETWORK",
            "action": "legacy_protocol_exposure_map",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": "Maps on-prem exposure to NTLM/SMBv1/LDAP signing gaps.",
            "triggers": ["legacy_auth_usage_detected", "protocol_downgrade_suspected"],
            "parameters_schema": {},
        },
        {
            "tool_id": "deception.honeypot.early_warning",
            "name": "Honeypot Early Warning",
            "category": "NETWORK",
            "action": "honeypot_early_warning",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": "Routes internal honeypot trip signals into high-confidence early warning workflow.",
            "triggers": [
                "honeypot_trip",
                "honeypot_trip_smb",
                "honeypot_trip_ssh",
                "honeypot_trip_rdp",
                "honeypot_trip_ftp",
                "honeypot_trip_telnet",
                "honeypot_trip_http",
                "honeypot_trip_https",
                "honeypot_trip_dns",
                "honeypot_trip_ldap",
                "honeypot_trip_rpc",
                "deception_artifact_access",
            ],
            "parameters_schema": {
                "sensor_id": "honeypot-01",
                "event_count": 0,
                "recent_minutes": 15,
                "protocol": "smb",
            },
            "supported_protocols": [
                "smb",
                "ssh",
                "rdp",
                "ftp",
                "telnet",
                "http",
                "https",
                "dns",
                "ldap",
                "rpc",
            ],
        },
        {
            "tool_id": "memory.suspect_modules",
            "name": "Memory Suspect Modules",
            "category": "ENDPOINT",
            "action": "memory_suspect_modules",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": "Enumerates suspicious loaded modules on Windows endpoints from on-prem sensors.",
            "triggers": ["code_injection_suspected", "unbacked_module_detected"],
            "parameters_schema": {"pid": 0, "target_host": "optional_windows_host"},
        },
        {
            "tool_id": "endpoint.process_list",
            "name": "Endpoint Process List",
            "category": "ENDPOINT",
            "action": "list_processes",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": "Lists local running processes with basic metadata.",
            "triggers": ["process_forensics_requested"],
            "parameters_schema": {"include_verbose": True},
        },
        {
            "tool_id": "endpoint.user.list",
            "name": "Endpoint User List",
            "category": "ENDPOINT",
            "action": "list_users",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": "Lists local user accounts.",
            "triggers": ["identity_investigation_requested"],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.logged_in_users.login_time",
            "name": "Logged In Users With Login Time",
            "category": "ENDPOINT",
            "action": "logged_in_users_login_time",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": "Lists currently logged-in users with session/login timing details.",
            "triggers": ["session_investigation_requested"],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.registry.read",
            "name": "Endpoint Registry Read",
            "category": "ENDPOINT",
            "action": "registry_read",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": "Reads registry keys/values, with optional recursive traversal.",
            "triggers": ["registry_forensics_requested"],
            "parameters_schema": {"path": "HKLM\\SOFTWARE", "recursive": True},
        },
        {
            "tool_id": "endpoint.eventlog.enriched",
            "name": "Endpoint Event Log Enriched",
            "category": "ENDPOINT",
            "action": "event_log_enriched",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": "Reads Windows event logs and returns enriched structured JSON fields.",
            "triggers": ["event_log_investigation_requested"],
            "parameters_schema": {
                "channel": "Security",
                "count": 100,
                "event_id": 4624,
            },
        },
        {
            "tool_id": "endpoint.eventlog.channels",
            "name": "Endpoint Event Log Channels",
            "category": "ENDPOINT",
            "action": "list_event_log_channels",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": "Lists available Windows event log channels.",
            "triggers": ["event_log_investigation_requested"],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.disk.read",
            "name": "Endpoint Disk Read",
            "category": "ENDPOINT",
            "action": "disk_read",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": "Reads files or lists directories from local disk.",
            "triggers": ["artifact_collection_requested", "disk_forensics_requested"],
            "parameters_schema": {
                "path": "C:\\Windows\\Temp",
                "recursive": False,
                "max_items": 200,
            },
        },
        {
            "tool_id": "endpoint.disk.drives",
            "name": "Endpoint Drive List",
            "category": "ENDPOINT",
            "action": "list_drives",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": "Lists local mounted drives/volumes.",
            "triggers": ["disk_forensics_requested"],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.task.terminate",
            "name": "Endpoint Task Terminate",
            "category": "ENDPOINT",
            "action": "terminate_task",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": "Terminates a process by PID on the local endpoint.",
            "triggers": ["process_containment_requested"],
            "parameters_schema": {"pid": 1234},
        },
        {
            "tool_id": "endpoint.process_snapshot_to_disk",
            "name": "Endpoint Process Snapshot To Disk",
            "category": "ENDPOINT",
            "action": "process_snapshot_to_disk",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "CRITICAL",
            "description": "Captures a local process memory dump to disk as an artifact.",
            "triggers": [
                "process_forensics_requested",
                "malware_memory_capture_required",
            ],
            "parameters_schema": {"pid": 1234},
        },
        {
            "tool_id": "endpoint.windows_service.register",
            "name": "Register Windows Service",
            "category": "ENDPOINT",
            "action": "register_windows_service",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": "Registers hawk-soard as a visible Windows service configured for automatic startup.",
            "triggers": ["agent_persistence_setup_requested"],
            "parameters_schema": {
                "service_name": "HawkSoard",
                "display_name": "Hawk SOARD Service",
                "executable_path": "C:\\Program Files\\Hawk\\hawk-soard.exe",
                "config_path": "C:\\ProgramData\\Hawk\\hawk-soard.cfg",
                "description": "Hawk SOAR daemon service",
                "start_now": True,
            },
        },
        {
            "tool_id": "endpoint.windows_service.unregister",
            "name": "Unregister Windows Service",
            "category": "ENDPOINT",
            "action": "unregister_windows_service",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": "Stops and removes the Windows service.",
            "triggers": ["agent_persistence_remove_requested"],
            "parameters_schema": {"service_name": "HawkSoard"},
        },
        {
            "tool_id": "endpoint.windows_service.status",
            "name": "Windows Service Status",
            "category": "ENDPOINT",
            "action": "windows_service_status",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": "Returns status and startup mode for the Windows service.",
            "triggers": ["agent_persistence_status_requested"],
            "parameters_schema": {"service_name": "HawkSoard"},
        },
        {
            "tool_id": "endpoint.windows_service.restart",
            "name": "Restart Windows Service",
            "category": "ENDPOINT",
            "action": "restart_windows_service",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": "Restarts a local Windows service to apply configuration updates.",
            "triggers": [
                "agent_persistence_status_requested",
                "remote_configuration_update_requested",
            ],
            "parameters_schema": {"service_name": "HawkSoard"},
        },
        {
            "tool_id": "endpoint.command.run",
            "name": "Endpoint Command Run",
            "category": "ENDPOINT",
            "action": "run_command",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "CRITICAL",
            "description": "Executes a local command using argv (no shell). Requires enable_command_execution=true in daemon config.",
            "triggers": ["manual_investigation_command"],
            "parameters_schema": {
                "argv": ["whoami"],
                "cwd": "optional_working_directory",
            },
        },
        {
            "tool_id": "endpoint.dynamic_tool.register",
            "name": "Register Dynamic Tool",
            "category": "ENDPOINT",
            "action": "register_dynamic_tool",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "CRITICAL",
            "description": "Creates or updates executable tools that are persisted and advertised. Requires enable_command_execution=true in daemon config.",
            "triggers": ["dynamic_tooling_requested"],
            "parameters_schema": {
                "tool_id": "custom.echo",
                "name": "Custom Echo",
                "category": "ENDPOINT",
                "action": "custom_echo",
                "description": "Echo input.",
                "command": ["cmd", "/c", "echo", "{message}"],
                "parameters_schema": {"message": "hello"},
                "requires_approval": True,
                "risk": "HIGH",
            },
        },
        {
            "tool_id": "endpoint.remote_process_snapshot",
            "name": "Remote Process Snapshot",
            "category": "ENDPOINT",
            "action": "remote_process_snapshot",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": "Captures a remote Windows process dump and returns it as an artifact. Requires enable_remote_process_snapshot=true in daemon config.",
            "triggers": [
                "malware_memory_capture_required",
                "process_forensics_requested",
            ],
            "parameters_schema": {
                "target_host": "windows-hostname",
                "pid": 1234,
                "username": "administrator",
                "password": "secret",
                "domain": "optional_domain",
                "submit_to_octorepl": True,
                "submission_provider": "virustotal",
                "submission_labels": ["memory", "forensics"],
            },
        },
        {
            "tool_id": "endpoint.remote_process_snapshot_by_name",
            "name": "Remote Process Snapshot By Name",
            "category": "ENDPOINT",
            "action": "remote_process_snapshot_by_name",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": "Resolves remote PID by process name, captures dump, and returns artifact. Requires enable_remote_process_snapshot=true in daemon config.",
            "triggers": [
                "malware_memory_capture_required",
                "process_name_forensics_requested",
            ],
            "parameters_schema": {
                "target_host": "windows-hostname",
                "process_name": "lsass",
                "username": "administrator",
                "password": "secret",
                "domain": "optional_domain",
                "submit_to_octorepl": True,
                "submission_provider": "virustotal",
                "submission_labels": ["memory", "forensics"],
            },
        },
        {
            "tool_id": "endpoint.remote_file_system_list",
            "name": "Remote File System List",
            "category": "ENDPOINT",
            "action": "remote_file_system_list",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": "Lists files/folders on remote Windows host with provided credentials. Requires enable_remote_file_collection=true in daemon config.",
            "triggers": ["remote_triage_requested", "suspicious_path_investigation"],
            "parameters_schema": {
                "target_host": "windows-hostname",
                "remote_path": "C:\\Windows\\Temp",
                "recursive": False,
                "max_items": 200,
                "username": "administrator",
                "password": "secret",
                "domain": "optional_domain",
            },
        },
        {
            "tool_id": "endpoint.remote_file_collect",
            "name": "Remote File Collect",
            "category": "ENDPOINT",
            "action": "remote_file_collect",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": "Copies a remote file as an artifact for malware scanning and analysis. Requires enable_remote_file_collection=true in daemon config.",
            "triggers": ["artifact_collection_requested", "suspicious_file_retrieval"],
            "parameters_schema": {
                "target_host": "windows-hostname",
                "remote_path": "C:\\Windows\\Temp\\suspicious.bin",
                "username": "administrator",
                "password": "secret",
                "domain": "optional_domain",
                "submit_to_octorepl": True,
                "submission_provider": "virustotal",
                "submission_labels": ["file", "triage"],
            },
        },
        {
            "tool_id": "living_off_land.detector",
            "name": "Living-Off-The-Land Detector",
            "category": "ENDPOINT",
            "action": "living_off_land_detector",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": "Detects suspicious LOLBin chains from local process telemetry.",
            "triggers": ["lolbin_behavior_pattern", "script_proxy_execution"],
            "parameters_schema": {"target_host": "optional_windows_host"},
        },
        {
            "tool_id": "deception.signal_fuser",
            "name": "Deception Signal Fuser",
            "category": "NETWORK",
            "action": "deception_signal_fuser",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": "Fuses honeypot/honeytoken/deception signals into escalation confidence.",
            "triggers": [
                "multi_deception_signal",
                "honeytoken_and_honeypot_correlation",
                "honeypot_trip",
            ],
            "parameters_schema": {
                "window_minutes": 60,
                "signals": ["honeypot_trip", "honeytoken_access"],
            },
        },
        {
            "tool_id": "net.rpc.query",
            "name": "RPC Endpoint Query",
            "category": "NETWORK",
            "action": "rpc_query",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": "Enumerate RPC endpoint mappings for a target host.",
            "triggers": ["lateral_movement_suspected", "svc_create_detected"],
            "parameters_schema": {
                "target": "hostname_or_ip",
                "endpoint": "optional_rpc_endpoint",
            },
        },
        {
            "tool_id": "net.http.client",
            "name": "HTTP/HTTPS Client",
            "category": "NETWORK",
            "action": "http_client",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": "Performs simple HTTP/HTTPS requests for investigation workflows.",
            "triggers": [
                "url_investigation_requested",
                "ioc_http_validation_requested",
            ],
            "parameters_schema": {
                "url": "https://example.com",
                "method": "GET",
                "timeout": 10,
                "headers": {"User-Agent": "hawk-soard"},
                "body": "",
            },
        },
        {
            "tool_id": "net.smb.client",
            "name": "SMB Client",
            "category": "NETWORK",
            "action": "smb_client",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": "Lists SMB shares or directory content on remote hosts.",
            "triggers": ["remote_share_investigation_requested"],
            "parameters_schema": {
                "target": "windows-hostname",
                "operation": "list_shares",
                "share": "C$",
                "path": "\\\\",
                "username": "optional_user",
                "password": "optional_password",
                "domain": "optional_domain",
            },
        },
        {
            "tool_id": "endpoint.remote_wmic.query",
            "name": "Remote WMIC Query",
            "category": "ENDPOINT",
            "action": "remote_wmic_query",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": "Executes an allowlisted WMIC query against a remote Windows host. Requires enable_remote_wmi_collection=true in daemon config.",
            "triggers": ["remote_endpoint_triage_requested"],
            "parameters_schema": {
                "target_host": "windows-hostname",
                "query": [
                    "process_list_brief",
                    "computersystem_get_username",
                    "service_list",
                    "qfe_list",
                ],
                "username": "optional_user",
                "password": "optional_password",
            },
        },
        {
            "tool_id": "endpoint.remote_command.execute",
            "name": "Remote Command Execute",
            "category": "ENDPOINT",
            "action": "remote_command_execute",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "CRITICAL",
            "description": "Runs a command remotely on a Windows host via PowerShell remoting. Requires enable_remote_command_execution=true in daemon config.",
            "triggers": ["remote_response_action_requested"],
            "parameters_schema": {
                "target_host": "windows-hostname",
                "argv": ["whoami"],
                "username": "administrator",
                "password": "secret",
                "domain": "optional_domain",
            },
        },
        {
            "tool_id": "endpoint.remote_registry.query",
            "name": "Remote Registry Query",
            "category": "ENDPOINT",
            "action": "remote_registry_query",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": "Queries remote Windows registry keys/values. Requires enable_remote_registry_read=true in daemon config.",
            "triggers": ["remote_registry_investigation_requested"],
            "parameters_schema": {
                "target_host": "windows-hostname",
                "path": "HKLM\\SOFTWARE\\Microsoft",
                "recursive": True,
                "value_name": "optional_value",
            },
        },
        {
            "tool_id": "endpoint.remote_config.update",
            "name": "Remote Config Update",
            "category": "ENDPOINT",
            "action": "remote_config_update",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "CRITICAL",
            "description": "Updates a remote config file content (supports backup) for credential rotation and policy changes. Requires enable_remote_config_management=true in daemon config.",
            "triggers": ["remote_configuration_update_requested"],
            "parameters_schema": {
                "target_host": "windows-hostname",
                "remote_path": "C:\\ProgramData\\Hawk\\hawk-soard.cfg",
                "content": "[SETTINGS]\\n...",
                "backup": True,
                "username": "administrator",
                "password": "secret",
                "domain": "optional_domain",
            },
        },
        {
            "tool_id": "endpoint.remote_service.restart",
            "name": "Remote Service Restart",
            "category": "ENDPOINT",
            "action": "remote_service_restart",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": "Restarts a service on remote host so new configuration is applied. Requires enable_remote_config_management=true in daemon config.",
            "triggers": ["remote_configuration_update_requested"],
            "parameters_schema": {
                "target_host": "windows-hostname",
                "service_name": "HawkSoard",
                "username": "administrator",
                "password": "secret",
                "domain": "optional_domain",
            },
        },
        {
            "tool_id": "endpoint.remote_process.restart",
            "name": "Remote Process Restart",
            "category": "ENDPOINT",
            "action": "remote_process_restart",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "CRITICAL",
            "description": "Restarts a process on a remote host (stop by name, start executable). Requires enable_remote_config_management=true in daemon config.",
            "triggers": ["remote_configuration_update_requested"],
            "parameters_schema": {
                "target_host": "windows-hostname",
                "process_name": "hawk-soard",
                "executable_path": "C:\\Program Files\\Hawk\\hawk-soard.exe",
                "arguments": ["-c", "C:\\ProgramData\\Hawk\\hawk-soard.cfg"],
                "username": "administrator",
                "password": "secret",
                "domain": "optional_domain",
            },
        },
        # ------------------------------------------------------------------
        # DEPLOY category — remote agent installation workflow (2-step)
        #
        # Step 1: deploy_hawk_soard
        #   Push (or download) the hawk-soard installer to a remote Windows
        #   host via WinRM, run it silently, write the agent config with the
        #   provided credentials, and start the HawkSoard Windows service.
        #
        # Step 2: verify_hawk_soard
        #   Confirm the Windows service is Running on the remote host before
        #   treating the node as available.
        #
        # After Step 2 returns running=true the remote agent connects back to
        # the HAWK platform using its own credentials and registers as a new
        # node.  It will appear in the platform with its own group_id and can
        # then receive hybrid_task commands directly.
        #
        # Prerequisites (both steps):
        #   - WinRM must be enabled and reachable on the target host.
        #   - Admin credentials with WinRM access are required.
        #   - The local daemon must have enable_remote_deploy = true in its
        #     hawk-soard.cfg (and optionally remote_deploy_allowed_targets).
        # ------------------------------------------------------------------
        {
            "tool_id": "deploy.hawk_soard",
            "name": "Deploy Hawk-Soard Agent (Step 1 of 2)",
            "category": "DEPLOY",
            "action": "deploy_hawk_soard",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": (
                "STEP 1 OF 2 — Installs the hawk-soard agent on a remote Windows host via WinRM. "
                "The local agent pushes its own NSIS installer to the target (or the target downloads "
                "it from the HAWK download server when no local copy is found). The installer runs "
                "silently, writes a config with the provided access_token and secret_key, and starts "
                "the HawkSoard Windows service. "
                "Returns: {deployed, service_name, status, pid, install_dir, exe_exists, config_written}. "
                "ALWAYS call verify_hawk_soard (Step 2) immediately after to confirm the service is "
                "Running before treating the node as available. "
                "Prerequisites: WinRM enabled on target; admin credentials; "
                "enable_remote_deploy=true in local daemon config."
            ),
            "triggers": [
                "remote_agent_install_requested",
                "new_endpoint_onboarding",
                "agent_missing_on_host",
                "lateral_coverage_gap_detected",
            ],
            "workflow": {
                "step": 1,
                "total_steps": 2,
                "next_action": "verify_hawk_soard",
                "next_tool_id": "deploy.hawk_soard.verify",
            },
            "parameters_schema": {
                "target_host": "windows-hostname-or-ip",
                "username": "DOMAIN\\administrator",
                "password": "credential-password",
                "domain": "optional-domain",
                "access_token": "hawk-service-account-access-token (defaults to local agent token)",
                "secret_key": "hawk-service-account-secret-key (defaults to local agent key)",
                "hawk_server": "https://ir.hawk.io (defaults to local agent server)",
                "install_dir": "C:\\Program Files\\HAWK\\SOAR (optional, uses default if omitted)",
                "service_name": "HawkSoard (optional, uses default if omitted)",
                "source_url": "optional URL to download installer from (uses HAWK download server if omitted)",
                "insecure": False,
            },
        },
        {
            "tool_id": "deploy.hawk_soard.verify",
            "name": "Verify Hawk-Soard Deployment (Step 2 of 2)",
            "category": "DEPLOY",
            "action": "verify_hawk_soard",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "STEP 2 OF 2 — Confirms that the hawk-soard Windows service is Running on a remote "
                "host after deploy_hawk_soard (Step 1) completes. "
                "Connects to the target via WinRM and queries the HawkSoard service state using "
                "Get-CimInstance. "
                "Returns: {service_name, status, pid, start_mode, running}. "
                "SUCCESS condition: running=true and status='Running'. "
                "If running=false, re-run deploy_hawk_soard or investigate the remote host manually. "
                "Once this step confirms running=true, the remote agent will connect back to the HAWK "
                "platform with its own credentials and register as a new node — it will then be "
                "available to receive hybrid_task commands using its own group_id. "
                "Prerequisites: WinRM enabled on target; same admin credentials used in Step 1; "
                "enable_remote_deploy=true in local daemon config."
            ),
            "triggers": [
                "remote_agent_install_requested",
                "agent_health_check_requested",
                "agent_missing_on_host",
            ],
            "workflow": {
                "step": 2,
                "total_steps": 2,
                "previous_action": "deploy_hawk_soard",
                "previous_tool_id": "deploy.hawk_soard",
            },
            "parameters_schema": {
                "target_host": "windows-hostname-or-ip",
                "username": "DOMAIN\\administrator",
                "password": "credential-password",
                "domain": "optional-domain",
                "service_name": "HawkSoard (optional, uses default if omitted)",
            },
        },
        # ------------------------------------------------------------------
        # CONFIG — remote configuration management tools
        # ------------------------------------------------------------------
        {
            "tool_id": "config.read",
            "name": "Read Node Configuration",
            "category": "CONFIG",
            "action": "config_read",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "MEDIUM",
            "description": (
                "Reads the current hawk-soard configuration from the local node. Returns the full "
                "INI-parsed configuration as a structured object. The response includes all settings, "
                "their current values, and the config file path. Requires enable_remote_config_management "
                "to be enabled. Use this to inspect configuration before making changes with config_update."
            ),
            "triggers": ["config_drift_detected", "node_misconfiguration_alert"],
            "parameters_schema": {
                "keys": "comma-separated list of keys to read (optional, returns all if omitted)",
            },
        },
        {
            "tool_id": "config.update",
            "name": "Update Node Configuration",
            "category": "CONFIG",
            "action": "config_update",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": (
                "Updates one or more configuration keys on the local hawk-soard node. Changes are "
                "written to the INI config file on disk AND applied to the live in-memory configuration "
                "immediately without requiring a process restart. After update, the hybrid tool catalog "
                "and node profile are re-advertised to the cloud platform. Requires "
                "enable_remote_config_management to be enabled. Parameters must include 'settings' as a "
                "dict of key-value pairs. Sensitive keys (access_token, secret_key, clientSecret) are "
                "masked in the response."
            ),
            "triggers": ["config_drift_detected", "node_misconfiguration_alert"],
            "parameters_schema": {
                "settings": {"key": "value"},
                "restart_services": "false",
            },
        },
        # ------------------------------------------------------------------
        # NETWORK — basic connectivity and discovery tools
        # ------------------------------------------------------------------
        {
            "tool_id": "net.ping",
            "name": "Network Ping",
            "category": "NETWORK",
            "action": "ping",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Sends ICMP echo requests to a target host and reports round-trip latency and packet "
                "loss. Required parameter: target (hostname or IP). Optional: count (1–10, default 4). "
                "Returns raw ping output including per-packet RTT and summary statistics. "
                "Cross-platform: uses 'ping -n' on Windows and 'ping -c' on Linux."
            ),
            "triggers": [
                "host_reachability_check",
                "network_connectivity_investigation",
                "incident_initial_triage",
                "lateral_movement_suspected",
            ],
            "parameters_schema": {"target": "192.168.1.1", "count": 4},
        },
        {
            "tool_id": "net.dns_lookup",
            "name": "Network DNS Lookup",
            "category": "NETWORK",
            "action": "dns_lookup",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Performs a DNS resolution on a target hostname or IP using nslookup. "
                "Required parameter: target (hostname or IP address to resolve). "
                "Returns raw nslookup output including resolved addresses, reverse DNS, and responding "
                "DNS server. Useful for validating IOC hostnames and checking for fast-flux or "
                "suspicious DNS responses. Cross-platform."
            ),
            "triggers": [
                "suspicious_domain_investigation",
                "ioc_dns_validation_requested",
                "c2_domain_suspected",
                "phishing_domain_check",
            ],
            "parameters_schema": {"target": "suspicious.example.com"},
        },
        {
            "tool_id": "net.traceroute",
            "name": "Network Traceroute",
            "category": "NETWORK",
            "action": "traceroute",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Traces the network path to a target host, showing each hop's IP and latency. "
                "Required parameter: target (hostname or IP). "
                "Returns the full hop-by-hop path output. Useful for identifying unexpected network "
                "routing, detecting traffic interception or proxying, and mapping egress paths. "
                "Uses 'tracert' on Windows and 'traceroute' on Linux."
            ),
            "triggers": [
                "suspicious_outbound_traffic",
                "network_path_investigation",
                "traffic_interception_suspected",
                "egress_route_analysis",
            ],
            "parameters_schema": {"target": "8.8.8.8"},
        },
        {
            "tool_id": "net.arp_table",
            "name": "Network ARP Table",
            "category": "NETWORK",
            "action": "arp_table",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Displays the local ARP cache mapping IP addresses to MAC addresses. "
                "No parameters required. "
                "Returns the full ARP table. Useful for identifying rogue hosts, ARP spoofing, and "
                "lateral movement via unexpected MAC/IP pairings. "
                "Cross-platform: uses 'arp -a' on Windows and 'arp -an' on Linux."
            ),
            "triggers": [
                "arp_spoofing_suspected",
                "rogue_device_on_subnet",
                "lateral_movement_suspected",
                "network_discovery_activity",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "net.route_table",
            "name": "Network Route Table",
            "category": "NETWORK",
            "action": "route_table",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Displays the local IP routing table showing all static and dynamic routes. "
                "No parameters required. "
                "Returns the full routing table. Useful for detecting added persistence routes, "
                "VPN or proxy route injection, and unexpected routing changes made by malware. "
                "Cross-platform: uses 'route print' on Windows and 'route -n' on Linux."
            ),
            "triggers": [
                "suspicious_route_added",
                "vpn_tunnel_investigation",
                "network_persistence_suspected",
                "traffic_redirection_detected",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "net.port_scan",
            "name": "Network Port Scan",
            "category": "NETWORK",
            "action": "port_scan",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Performs a TCP connect scan against a target host to determine which ports are open. "
                "Required parameters: target (hostname or IP), ports (list of integers, max 64 ports). "
                "Returns: {target, open_ports: [...], closed_ports: [...]}. "
                "Port values must be in range 1–65535. Uses a 1-second per-port timeout. "
                "Cross-platform. Use to verify if a suspected C2 port is reachable or to confirm "
                "that a firewall rule has taken effect after containment."
            ),
            "triggers": [
                "c2_port_validation",
                "firewall_rule_verification",
                "lateral_movement_service_discovery",
                "open_service_enumeration",
            ],
            "parameters_schema": {
                "target": "192.168.1.100",
                "ports": [22, 80, 443, 445, 3389, 8080],
            },
        },
        {
            "tool_id": "net.smb_sessions",
            "name": "SMB Active Sessions",
            "category": "NETWORK",
            "action": "smb_sessions",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Enumerates active SMB sessions connected to this host via 'net session'. "
                "No parameters required. "
                "Returns a list of currently connected remote hosts, their share paths, and session "
                "metadata. Windows-only. Useful for detecting unauthorized SMB access, lateral "
                "movement, and identifying hosts that have active sessions on a compromised server."
            ),
            "triggers": [
                "lateral_movement_suspected",
                "smb_unauthorized_access",
                "compromised_server_triage",
                "active_intrusion_response",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "net.smb_share_query",
            "name": "SMB Share Query",
            "category": "NETWORK",
            "action": "smb_share_query",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Enumerates SMB shares exposed by a remote host. "
                "Required parameter: target (hostname or IP of remote host). "
                "On Windows uses 'net view \\\\target'; on Linux falls back to smbclient -L. "
                "Returns the list of available shares and their types. "
                "Useful for identifying unauthorized file shares, data staging directories, and "
                "confirming that containment has removed attacker-controlled shares."
            ),
            "triggers": [
                "data_staging_suspected",
                "unauthorized_share_detected",
                "lateral_movement_suspected",
                "remote_share_investigation_requested",
            ],
            "parameters_schema": {"target": "windows-hostname"},
        },
        # ------------------------------------------------------------------
        # AD — Active Directory user and group management
        # ------------------------------------------------------------------
        {
            "tool_id": "ad.get_user_details",
            "name": "AD Get User Details",
            "category": "AD",
            "action": "get_user_details",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Retrieves detailed information for an Active Directory or local user account. "
                "Required parameter: username (SAM account name). "
                "Returns account metadata including full name, status (active/disabled), last logon "
                "time, password change date, group memberships, and logon hour restrictions via "
                "'net user'. Windows-only."
            ),
            "triggers": [
                "suspicious_account_activity",
                "identity_investigation_requested",
                "compromised_account_suspected",
                "insider_threat_investigation",
            ],
            "parameters_schema": {"username": "jsmith"},
        },
        {
            "tool_id": "ad.enumerate_group_membership",
            "name": "AD Enumerate Group Membership",
            "category": "AD",
            "action": "enumerate_group_membership",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Enumerates the group memberships for a specified user account. "
                "Required parameter: username (SAM account name). "
                "Returns all local and domain group memberships for the account via 'net user'. "
                "Windows-only. Use to verify whether a compromised account has elevated group "
                "membership (e.g., Domain Admins, local Administrators)."
            ),
            "triggers": [
                "privilege_escalation_suspected",
                "compromised_account_suspected",
                "admin_account_investigation",
                "identity_investigation_requested",
            ],
            "parameters_schema": {"username": "jsmith"},
        },
        {
            "tool_id": "ad.disable_account",
            "name": "AD Disable Account",
            "category": "AD",
            "action": "disable_account",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": (
                "Disables an Active Directory or local user account to prevent login. "
                "Required parameter: username (SAM account name). "
                "Executes 'net user <username> /active:no'. Windows-only. "
                "Returns command output confirming the account has been disabled. "
                "Use during active incident containment to prevent further unauthorized access. "
                "This action requires approval before execution."
            ),
            "triggers": [
                "compromised_account_containment",
                "active_intrusion_response",
                "insider_threat_containment",
                "account_takeover_response",
            ],
            "parameters_schema": {"username": "jsmith"},
        },
        {
            "tool_id": "ad.enable_account",
            "name": "AD Enable Account",
            "category": "AD",
            "action": "enable_account",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "MEDIUM",
            "description": (
                "Re-enables a previously disabled Active Directory or local user account. "
                "Required parameter: username (SAM account name). "
                "Executes 'net user <username> /active:yes'. Windows-only. "
                "Returns command output confirming the account has been enabled. "
                "Use during remediation after credential reset and account review are complete. "
                "This action requires approval before execution."
            ),
            "triggers": [
                "account_remediation_requested",
                "incident_remediation",
                "account_restoration_requested",
            ],
            "parameters_schema": {"username": "jsmith"},
        },
        {
            "tool_id": "ad.reset_password",
            "name": "AD Reset Password",
            "category": "AD",
            "action": "reset_password",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": (
                "Resets the password for an Active Directory or local user account. "
                "Required parameters: username (SAM account name), new_password (new credential). "
                "Executes 'net user <username> <new_password>'. Windows-only. "
                "Returns command output confirming the password change. "
                "Use during active incident response to invalidate attacker-held credentials. "
                "This action requires approval before execution."
            ),
            "triggers": [
                "compromised_credential_response",
                "account_takeover_response",
                "compromised_account_containment",
                "active_intrusion_response",
            ],
            "parameters_schema": {
                "username": "jsmith",
                "new_password": "NewSecurePassword123!",
            },
        },
        {
            "tool_id": "ad.retrieve_last_logon",
            "name": "AD Retrieve Last Logon",
            "category": "AD",
            "action": "retrieve_last_logon",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Retrieves the last logon timestamp and logon-related metadata for a user account. "
                "Required parameter: username (SAM account name). "
                "Returns account detail output via 'net user' including last logon date, logon count, "
                "and password age. Windows-only. Useful for identifying dormant accounts being "
                "reactivated during an attack or verifying the timeline of unauthorized access."
            ),
            "triggers": [
                "suspicious_account_activity",
                "dormant_account_reactivation",
                "identity_investigation_requested",
                "compromised_account_suspected",
            ],
            "parameters_schema": {"username": "jsmith"},
        },
        {
            "tool_id": "ad.audit_privileged_group_membership",
            "name": "AD Audit Privileged Group Membership",
            "category": "AD",
            "action": "audit_privileged_group_membership",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Audits membership of the local Administrators privileged group. "
                "No parameters required. "
                "Executes 'net localgroup Administrators' and returns all current members. "
                "Windows-only. Use to detect unauthorized privilege escalation, verify that a "
                "compromised account has not been added to the Administrators group, and confirm "
                "that remediation steps have been effective."
            ),
            "triggers": [
                "privilege_escalation_suspected",
                "admin_group_membership_check",
                "compromised_account_suspected",
                "post_remediation_verification",
            ],
            "parameters_schema": {},
        },
        # ------------------------------------------------------------------
        # CONTAINMENT — destructive/write actions, all require approval
        # ------------------------------------------------------------------
        {
            "tool_id": "containment.logoff_user",
            "name": "Containment Logoff User",
            "category": "CONTAINMENT",
            "action": "logoff_user",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": (
                "Force-logs-off all interactive sessions owned by the specified user account. "
                "Required parameter: username (local or domain account, e.g. 'jsmith' or "
                "'DOMAIN\\\\jsmith'). "
                "On Windows uses WTSEnumerateSessions + WTSLogoffSession via wtsapi32 to terminate "
                "every matching session without spawning a child process. On Linux uses loginctl or "
                "pkill as fallback. "
                "Returns a list of terminated session IDs and any errors. "
                "Windows-only for WTS path. This action requires approval before execution."
            ),
            "triggers": [
                "active_intrusion_response",
                "compromised_account_containment",
                "unauthorized_interactive_session",
                "insider_threat_containment",
            ],
            "parameters_schema": {"username": "jsmith"},
        },
        {
            "tool_id": "containment.kill_process",
            "name": "Containment Kill Process",
            "category": "CONTAINMENT",
            "action": "kill_process",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": (
                "Forcibly terminates a running process by PID. "
                "Required parameter: pid (integer process ID, 1–2147483647). "
                "On Windows uses OpenProcess + TerminateProcess via the Windows API directly "
                "(no child process). On Linux falls back to 'kill -9 <pid>'. "
                "Returns exit code and confirmation message. "
                "This action requires approval before execution. Use to stop malware, C2 implants, "
                "or ransomware processes immediately during active incident response."
            ),
            "triggers": [
                "malware_process_termination",
                "active_intrusion_response",
                "c2_implant_contained",
                "ransomware_process_kill",
            ],
            "parameters_schema": {"pid": 4321},
        },
        {
            "tool_id": "containment.stop_service",
            "name": "Containment Stop Service",
            "category": "CONTAINMENT",
            "action": "stop_service",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": (
                "Stops a Windows service by name using 'sc stop'. "
                "Required parameter: service_name (service short name, e.g. 'wuauserv'). "
                "Returns sc output confirming the stop request and current service state. "
                "Windows-only. Use to stop malicious services installed for persistence or lateral "
                "movement. This action requires approval before execution."
            ),
            "triggers": [
                "malicious_service_detected",
                "persistence_mechanism_containment",
                "active_intrusion_response",
                "lateral_movement_service_stop",
            ],
            "parameters_schema": {"service_name": "SuspiciousServiceName"},
        },
        {
            "tool_id": "containment.add_firewall_block_rule",
            "name": "Containment Add Firewall Block Rule",
            "category": "CONTAINMENT",
            "action": "add_firewall_block_rule",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": (
                "Adds a Windows Firewall inbound block rule for a specific remote IP address using "
                "netsh advfirewall. "
                "Required parameters: rule_name (string label for the rule), remote_ip (IP or CIDR "
                "to block). "
                "Returns netsh output confirming rule creation. Windows-only. "
                "Use to block inbound connections from a known attacker IP, C2 server, or lateral "
                "movement source as an immediate containment action. "
                "This action requires approval before execution."
            ),
            "triggers": [
                "attacker_ip_block_requested",
                "c2_connection_containment",
                "active_intrusion_response",
                "ransomware_lateral_block",
            ],
            "parameters_schema": {
                "rule_name": "HAWK-Block-C2",
                "remote_ip": "198.51.100.42",
            },
        },
        {
            "tool_id": "containment.host_isolation",
            "name": "Containment Host Isolation",
            "category": "CONTAINMENT",
            "action": "host_isolation",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "CRITICAL",
            "description": (
                "Placeholder for full network isolation of the local host. "
                "This action currently returns a PermissionError because host isolation is not "
                "supported by the default node policy — full isolation requires platform-level "
                "network enforcement. "
                "No parameters accepted. "
                "This action requires approval before execution. "
                "For partial containment, use containment.add_firewall_block_rule to block specific "
                "attacker IPs instead."
            ),
            "triggers": [
                "ransomware_active_on_host",
                "full_host_containment_requested",
                "active_intrusion_response",
                "critical_malware_detected",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "containment.disable_user",
            "name": "Containment Disable User",
            "category": "CONTAINMENT",
            "action": "disable_user",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "HIGH",
            "description": (
                "Disables a local user account on this endpoint via 'net user <username> /active:no'. "
                "Required parameter: username (local account SAM name). "
                "Returns command output confirming account is disabled. Windows-only. "
                "This is a containment-category action enforced by the execution engine; it always "
                "requires approval. Use during active incident response to immediately revoke local "
                "account access on a compromised host."
            ),
            "triggers": [
                "compromised_account_containment",
                "active_intrusion_response",
                "unauthorized_local_account_detected",
                "insider_threat_containment",
            ],
            "parameters_schema": {"username": "malicious_user"},
        },
        # ------------------------------------------------------------------
        # ENDPOINT — High-Value Forensics
        # ------------------------------------------------------------------
        {
            "tool_id": "endpoint.running_processes",
            "name": "Endpoint Running Processes",
            "category": "ENDPOINT",
            "action": "running_processes",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Lists all currently running processes via 'tasklist'. "
                "No parameters required. Windows-only. "
                "Returns a table of process names, PIDs, session names, and memory usage. "
                "Unlike the endpoint.process_list action (which uses 'tasklist /v' and is "
                "cross-platform), this action is Windows-specific and returns the compact tasklist "
                "format. Use for rapid process enumeration during triage."
            ),
            "triggers": [
                "process_forensics_requested",
                "malware_process_hunt",
                "active_intrusion_response",
                "endpoint_triage_requested",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.logged_in_users",
            "name": "Endpoint Logged In Users",
            "category": "ENDPOINT",
            "action": "logged_in_users",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Lists all users currently logged into this endpoint via 'query user'. "
                "No parameters required. Windows-only. "
                "Returns session IDs, logon times, idle time, and session state for each user. "
                "Use to detect unauthorized interactive sessions or to confirm a target user is "
                "still active before triggering logoff containment."
            ),
            "triggers": [
                "unauthorized_interactive_session",
                "session_investigation_requested",
                "active_intrusion_response",
                "compromised_account_suspected",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.network_connections",
            "name": "Endpoint Network Connections",
            "category": "ENDPOINT",
            "action": "network_connections",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Returns all active network connections and listening ports with owning process IDs "
                "via 'netstat -ano'. Windows-only. "
                "No parameters required. "
                "Returns a table of local/remote addresses, port numbers, connection state, and PID. "
                "Use for rapid C2 connection discovery and to identify what processes are making "
                "network connections on a compromised host."
            ),
            "triggers": [
                "c2_connection_suspected",
                "suspicious_outbound_traffic",
                "active_intrusion_response",
                "endpoint_triage_requested",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.installed_software",
            "name": "Endpoint Installed Software",
            "category": "ENDPOINT",
            "action": "installed_software",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Enumerates all installed software on this endpoint via WMIC product query. "
                "No parameters required. Windows-only. "
                "Returns a list of installed product names and versions. May be slow on hosts with "
                "many installed packages. Use to detect unauthorized software installations, verify "
                "attacker tooling presence, or audit endpoint for vulnerable software versions."
            ),
            "triggers": [
                "software_inventory_requested",
                "unauthorized_software_detected",
                "vulnerability_assessment_requested",
                "endpoint_triage_requested",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.services_status",
            "name": "Endpoint Services Status",
            "category": "ENDPOINT",
            "action": "services_status",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Returns the status of all Windows services via 'sc query'. "
                "No parameters required. Windows-only. "
                "Returns service names, display names, current state (Running/Stopped), and type. "
                "Use to detect malicious services installed for persistence, identify stopped "
                "security services (e.g., antivirus, EDR), or verify containment actions."
            ),
            "triggers": [
                "malicious_service_detected",
                "persistence_mechanism_investigation",
                "security_service_tampering_suspected",
                "endpoint_triage_requested",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.scheduled_tasks",
            "name": "Endpoint Scheduled Tasks",
            "category": "ENDPOINT",
            "action": "scheduled_tasks",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Lists all scheduled tasks on this Windows endpoint in CSV format via schtasks. "
                "No parameters required. Windows-only. "
                "Returns task names, status, next run time, and last run time. "
                "Use for quick enumeration of scheduled task persistence; for deeper analysis "
                "including full XML export and obfuscation detection, use endpoint.scheduled_task_deep."
            ),
            "triggers": [
                "persistence_mechanism_investigation",
                "scheduled_task_anomaly_detected",
                "endpoint_triage_requested",
                "malware_persistence_hunt",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.scheduled_task_deep",
            "name": "Endpoint Scheduled Task Deep Analysis",
            "category": "ENDPOINT",
            "action": "scheduled_task_deep",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Performs deep forensic analysis of all scheduled tasks, exporting full XML, decoding "
                "base64-encoded command arguments, flagging inline scripts, obfuscated PowerShell "
                "('-Enc' arguments), and tasks whose action binary lives in a suspicious path. "
                "No parameters required. Windows-only. "
                "Returns per-task objects including: name, path, state, author, run_as_user, "
                "run_level, actions (with decoded_arg if base64-encoded), triggers, last_run, "
                "next_run, and full XML. Use when quick schtasks output is insufficient and "
                "obfuscated or attacker-created tasks are suspected."
            ),
            "triggers": [
                "persistence_mechanism_investigation",
                "scheduled_task_anomaly_detected",
                "malware_persistence_hunt",
                "obfuscated_task_suspected",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.startup_programs",
            "name": "Endpoint Startup Programs",
            "category": "ENDPOINT",
            "action": "startup_programs",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Enumerates all programs configured to run at startup or logon from multiple sources. "
                "No parameters required. Cross-platform. "
                "On Windows covers: registry Run/RunOnce/RunServices keys (HKLM + HKCU, 32 & 64-bit), "
                "AppInit_DLLs, Winlogon Shell/Userinit, startup folders, scheduled tasks with "
                "boot/logon triggers, auto-start services, and WMI event subscriptions. "
                "On Linux covers: systemd enabled units, SysV rc*.d symlinks, autostart .desktop "
                "files, @reboot crontab entries, and /etc/profile.d scripts. "
                "Returns structured objects: {source, name, command, location}. "
                "Use to detect all persistence mechanisms on an endpoint in a single call."
            ),
            "triggers": [
                "persistence_mechanism_investigation",
                "malware_persistence_hunt",
                "endpoint_triage_requested",
                "post_compromise_forensics",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.file_exists_hash",
            "name": "Endpoint File Exists and Hash",
            "category": "ENDPOINT",
            "action": "file_exists_hash",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Checks whether a file exists at the specified path and returns its SHA-256 hash. "
                "Required parameter: path (absolute file path to check). "
                "Returns: {path, exists, sha256} where sha256 is only included if the file exists. "
                "Cross-platform. Use to verify the presence of IOC files, confirm malware samples, "
                "validate remediation by confirming file deletion, or check file integrity."
            ),
            "triggers": [
                "ioc_file_validation",
                "malware_file_hunt",
                "remediation_verification",
                "artifact_hash_check",
            ],
            "parameters_schema": {"path": "C:\\Windows\\Temp\\suspicious.exe"},
        },
        {
            "tool_id": "endpoint.registry_query",
            "name": "Endpoint Registry Query",
            "category": "ENDPOINT",
            "action": "registry_query",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Queries a Windows registry key or specific value using 'reg query'. "
                "Required parameter: path (registry key path, e.g. "
                "'HKLM\\\\SOFTWARE\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Run'). "
                "Optional parameter: value_name (specific value name to query; if omitted, all "
                "values under the key are returned). "
                "Windows-only. Returns the raw reg query output. "
                "Compared to endpoint.registry.read, this action uses the simpler reg.exe interface "
                "without recursive traversal options."
            ),
            "triggers": [
                "registry_forensics_requested",
                "persistence_mechanism_investigation",
                "malware_registry_artifact_hunt",
                "ioc_registry_key_check",
            ],
            "parameters_schema": {
                "path": "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",
                "value_name": "optional_value_name",
            },
        },
        {
            "tool_id": "endpoint.event_log_extraction",
            "name": "Endpoint Event Log Extraction",
            "category": "ENDPOINT",
            "action": "event_log_extraction",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Extracts raw Windows event log entries using wevtutil in text format. "
                "Required parameters: log_name (event log channel name, e.g. 'Security'), "
                "count (number of entries to return, 1–5000). "
                "Returns the most recent N entries from the specified log in plain text format. "
                "Windows-only. For structured JSON output with filtering by event ID, use "
                "endpoint.eventlog.enriched instead."
            ),
            "triggers": [
                "event_log_investigation_requested",
                "post_compromise_forensics",
                "security_event_analysis",
                "incident_timeline_reconstruction",
            ],
            "parameters_schema": {"log_name": "Security", "count": 500},
        },
        {
            "tool_id": "endpoint.wmic_query",
            "name": "Endpoint WMIC Query",
            "category": "ENDPOINT",
            "action": "wmic_query",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Executes an allowlisted WMIC query on the local Windows endpoint. "
                "Required parameter: query (must be one of the 4 allowed preset values — see enum). "
                "Only these 4 query aliases are accepted: "
                "'process_list_brief' (lists running processes with brief output), "
                "'computersystem_get_username' (returns the currently logged-in user), "
                "'service_list' (lists all services with state and start mode), "
                "'qfe_list' (lists installed hotfixes/patches). "
                "Windows-only. Any other query value will be rejected with a PermissionError. "
                "For remote WMIC queries, use endpoint.remote_wmic.query instead."
            ),
            "triggers": [
                "endpoint_triage_requested",
                "patch_level_investigation",
                "process_forensics_requested",
                "service_inventory_requested",
            ],
            "parameters_schema": {
                "query": [
                    "process_list_brief",
                    "computersystem_get_username",
                    "service_list",
                    "qfe_list",
                ],
            },
        },
        {
            "tool_id": "endpoint.dns_query_history",
            "name": "Endpoint DNS Query History",
            "category": "ENDPOINT",
            "action": "dns_query_history",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Returns a deduplicated list of DNS hostnames queried by this endpoint in the past "
                "N hours. Optional parameter: hours (1–168, default 24). "
                "On Windows reads from the Microsoft-Windows-DNS-Client/Operational event log "
                "(EID 3006). If the log is disabled, it is automatically enabled for future runs. "
                "On Linux parses systemd-resolved journal logs. "
                "Returns: {hours_back, total_unique, hosts: [...]}. "
                "Use to identify C2 domains, DGA activity, or data exfiltration via DNS."
            ),
            "triggers": [
                "c2_domain_suspected",
                "dns_exfiltration_suspected",
                "dga_activity_detected",
                "post_compromise_forensics",
            ],
            "parameters_schema": {"hours": 24},
        },
        {
            "tool_id": "endpoint.open_ports",
            "name": "Endpoint Open Ports",
            "category": "ENDPOINT",
            "action": "open_ports",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Lists all TCP listening ports and UDP open endpoints on this host with their "
                "associated process name and PID. "
                "No parameters required. Cross-platform. "
                "On Windows uses Get-NetTCPConnection and Get-NetUDPEndpoint via PowerShell. "
                "On Linux falls back to 'ss -tulnp'. "
                "Returns: [{protocol, local_address, local_port, state, pid, process_name}]. "
                "Use to identify unauthorized listeners, backdoor ports, or verify firewall rules."
            ),
            "triggers": [
                "backdoor_port_suspected",
                "unauthorized_listener_detected",
                "c2_connection_suspected",
                "endpoint_triage_requested",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.active_connections",
            "name": "Endpoint Active Connections",
            "category": "ENDPOINT",
            "action": "active_connections",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Lists all active TCP network connections (all states except Listen) with remote "
                "address and owning process. "
                "No parameters required. Cross-platform. "
                "On Windows uses Get-NetTCPConnection filtered to non-listen states via PowerShell. "
                "On Linux uses 'ss -tanp'. "
                "Returns: [{protocol, local_address, local_port, remote_address, remote_port, "
                "state, pid, process_name}]. "
                "Complements endpoint.open_ports by showing established and in-progress connections "
                "rather than listeners."
            ),
            "triggers": [
                "c2_connection_suspected",
                "suspicious_outbound_traffic",
                "active_intrusion_response",
                "lateral_movement_suspected",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.process_modules",
            "name": "Endpoint Process Modules",
            "category": "ENDPOINT",
            "action": "process_modules",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Lists every DLL loaded into a specific process and flags suspicious modules. "
                "Required parameter: pid (integer process ID). Windows-only. "
                "Returns: {pid, process_name, total_modules, suspicious_count, modules: [{module_name, "
                "file_path, base_address, module_size, file_version, company, signed, suspicious, "
                "suspect_reason}]}. "
                "Flags modules loaded from user-writable paths (AppData, Downloads, Temp, "
                "ProgramData) or outside standard system paths (System32, SysWOW64, Program Files). "
                "Also checks Authenticode signature status. Use to detect DLL injection, reflective "
                "loading, and hijacked process modules."
            ),
            "triggers": [
                "code_injection_suspected",
                "dll_injection_suspected",
                "process_forensics_requested",
                "malware_module_hunt",
            ],
            "parameters_schema": {"pid": 1234},
        },
        {
            "tool_id": "endpoint.process_injection_scan",
            "name": "Endpoint Process Injection Scan",
            "category": "ENDPOINT",
            "action": "process_injection_scan",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Scans all running processes for process injection indicators using Windows API "
                "calls via ctypes (no child processes spawned). Windows-only. No parameters required. "
                "Detects: (1) RWX/RX memory regions with no backing image (orphaned shellcode or "
                "reflectively loaded PE), (2) MEM_PRIVATE protection in executable memory areas "
                "(VirtualAllocEx + WriteProcessMemory injection), (3) remote thread start addresses "
                "outside known module ranges (CreateRemoteThread injection), (4) PE headers in "
                "non-image regions (process hollowing). "
                "Returns findings per process with memory region details."
            ),
            "triggers": [
                "code_injection_suspected",
                "process_hollowing_suspected",
                "shellcode_execution_suspected",
                "active_intrusion_response",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.process_hook_scan",
            "name": "Endpoint Process Hook Scan",
            "category": "ENDPOINT",
            "action": "process_hook_scan",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Scans loaded modules in running processes for inline API hooks (JMP/CALL patches "
                "at function prologues) that indicate rootkit or security tool evasion techniques. "
                "Windows-only. No parameters required. "
                "Compares in-memory function bytes against on-disk module bytes for key Windows "
                "API functions. Returns a list of detected hook locations including the process, "
                "module, function, and patched byte sequence. "
                "Use when AMSI or EDR bypass is suspected."
            ),
            "triggers": [
                "api_hooking_suspected",
                "security_tool_evasion_suspected",
                "rootkit_suspected",
                "amsi_bypass_detected",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.lsass_access_indicators",
            "name": "Endpoint LSASS Access Indicators",
            "category": "ENDPOINT",
            "action": "lsass_access_indicators",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Detects credential-dumping activity targeting LSASS (Local Security Authority "
                "Subsystem Service). Windows-only. "
                "Optional parameter: hours (event log look-back window, 1–168, default 24). "
                "Checks: PPL (Protected Process Light) protection status of LSASS, Security event "
                "log EID 4656/4663 object-access events against lsass.exe, and enumerates processes "
                "with names known to be used for LSASS dumping (mimikatz, procdump, comsvcs, etc.). "
                "Returns: {ppl_enabled, lsass_pid, suspicious_processes, access_events}. "
                "Use immediately when credential theft or pass-the-hash activity is suspected."
            ),
            "triggers": [
                "credential_theft_suspected",
                "mimikatz_activity_detected",
                "pass_the_hash_suspected",
                "lsass_access_alert",
            ],
            "parameters_schema": {"hours": 24},
        },
        {
            "tool_id": "endpoint.credential_theft_indicators",
            "name": "Endpoint Credential Theft Indicators",
            "category": "ENDPOINT",
            "action": "credential_theft_indicators",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Hunts for broad credential theft indicators beyond LSASS access. Windows-only. "
                "No parameters required. "
                "Checks: SAM/SYSTEM/SECURITY hive access attempts in event logs, DPAPI master key "
                "access, credential manager events, suspicious processes accessing credential stores, "
                "and known credential dumping tool artifacts in running process names and loaded "
                "modules. "
                "Returns a consolidated list of findings with severity and evidence. "
                "Use in conjunction with lsass_access_indicators for a complete credential theft "
                "investigation."
            ),
            "triggers": [
                "credential_theft_suspected",
                "credential_access_alert",
                "post_compromise_forensics",
                "active_intrusion_response",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.lateral_movement_artifacts",
            "name": "Endpoint Lateral Movement Artifacts",
            "category": "ENDPOINT",
            "action": "lateral_movement_artifacts",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Extracts lateral movement evidence from the Windows Security event log. "
                "Windows-only. Optional parameter: hours (look-back window 1–720, default 48). "
                "Queries EID 4624 (network/remote-interactive logon), 4648 (explicit-credential "
                "logon), 4776 (NTLM authentication), 4625 (failed logon), and 4672 (privileged "
                "logon) filtered to logon types 3 (network) and 10 (remote interactive). "
                "Returns a structured event timeline with source IP, target user, auth package, "
                "logon type, and lateral movement flag per event. "
                "Use to reconstruct inbound lateral movement paths during an active incident."
            ),
            "triggers": [
                "lateral_movement_suspected",
                "pass_the_hash_suspected",
                "unauthorized_remote_logon",
                "active_intrusion_response",
            ],
            "parameters_schema": {"hours": 48},
        },
        {
            "tool_id": "endpoint.memory_ioc_extractor",
            "name": "Endpoint Memory IOC Extractor",
            "category": "ENDPOINT",
            "action": "memory_ioc_extractor",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Extracts IOC strings from a live process's readable memory regions. Windows-only. "
                "Required parameter: pid (integer process ID). "
                "Optional parameter: min_b64 (minimum Base64 blob length to capture, 32–512, "
                "default 64). "
                "Scans all committed readable memory via VirtualQueryEx + ReadProcessMemory and "
                "applies regex patterns for: IPv4/IPv6, URLs, domains, Windows paths, UNC paths, "
                "named pipes, and suspicious base64 blobs. Results are deduplicated and grouped by "
                "type. Returns: {pid, iocs: {ips, urls, domains, paths, pipes, base64_blobs}}. "
                "Use to extract live C2 configuration from a running implant."
            ),
            "triggers": [
                "c2_configuration_extraction",
                "malware_process_forensics",
                "live_memory_ioc_hunt",
                "implant_analysis_requested",
            ],
            "parameters_schema": {"pid": 1234, "min_b64": 64},
        },
        {
            "tool_id": "endpoint.ransomware_indicators",
            "name": "Endpoint Ransomware Indicators",
            "category": "ENDPOINT",
            "action": "ransomware_indicators",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Hunts for ransomware activity indicators across multiple detection vectors. "
                "Windows-only. Optional parameter: hours (look-back window 1–48, default 4). "
                "Checks: (1) VSS deletion commands in Security EID 4688 and PowerShell EID 4104 "
                "(vssadmin, bcdedit, wbadmin, shadow delete patterns), (2) bulk file renames/"
                "extension changes in the NTFS USN journal, (3) known ransomware mutex names in "
                "running processes' named objects, (4) recovery mode tamper (bcdedit recoveryenabled "
                "no), (5) mass file entropy spike detection by sampling files. "
                "Returns findings grouped by detection source with timestamps and evidence."
            ),
            "triggers": [
                "ransomware_active_on_host",
                "vss_deletion_detected",
                "bulk_file_encryption_suspected",
                "shadow_copy_deletion_alert",
            ],
            "parameters_schema": {"hours": 4},
        },
        {
            "tool_id": "endpoint.ntfs_journal_analysis",
            "name": "Endpoint NTFS Journal Analysis",
            "category": "ENDPOINT",
            "action": "ntfs_journal_analysis",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Parses the NTFS Change Journal ($UsnJrnl:$J) for recently deleted, renamed, or "
                "modified files in suspicious directories. Windows-only. "
                "Optional parameters: volume (drive letter, e.g. 'C:', default 'C:'), "
                "hours (look-back window 1–72, default 2). "
                "Uses 'fsutil usn readjournal' and flags high-value paths: System32, Temp, user "
                "profiles, AppData, and ProgramData. "
                "Returns structured entries with filename, reason (FILE_CREATE, FILE_DELETE, "
                "RENAME_OLD_NAME, etc.), and timestamp. "
                "Use to detect anti-forensics activity, ransomware file operations, and staged "
                "data exfiltration."
            ),
            "triggers": [
                "anti_forensics_suspected",
                "ransomware_active_on_host",
                "file_deletion_investigation",
                "data_staging_suspected",
            ],
            "parameters_schema": {"volume": "C:", "hours": 2},
        },
        {
            "tool_id": "endpoint.mft_analyzer",
            "name": "Endpoint MFT Analyzer",
            "category": "ENDPOINT",
            "action": "mft_analyzer",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Analyzes the NTFS Master File Table ($MFT) for timestamp anomalies and recently "
                "created executables in suspicious directories. Windows-only. "
                "Optional parameters: hours (look-back window 1–168, default 24), "
                "volume (drive letter, e.g. 'C:', default 'C:'). "
                "Detects: $SI vs $FN timestamp mismatches (timestomping), files with zeroed "
                "timestamps, $SI created-time earlier than $FN created-time (definitive timestomp), "
                "and recently created executables (.exe/.dll/.ps1/.bat etc.) in Temp, Public, "
                "PerfLogs, Tasks, System32, and SysWOW64 directories. "
                "Returns findings with file paths, timestamps, and anomaly descriptions."
            ),
            "triggers": [
                "timestomping_suspected",
                "anti_forensics_suspected",
                "malware_dropper_investigation",
                "post_compromise_forensics",
            ],
            "parameters_schema": {"hours": 24, "volume": "C:"},
        },
        {
            "tool_id": "endpoint.wmi_persistence_deep",
            "name": "Endpoint WMI Persistence Deep Scan",
            "category": "ENDPOINT",
            "action": "wmi_persistence_deep",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Performs deep enumeration of WMI event subscriptions used for persistence. "
                "Windows-only. No parameters required. "
                "Queries the root\\subscription WMI namespace for all "
                "__EventFilter, __EventConsumer (CommandLineEventConsumer and "
                "ActiveScriptEventConsumer), and __FilterToConsumerBinding instances. "
                "Returns all subscription triplets with filter query, consumer command/script, and "
                "binding details. WMI subscriptions are a stealthy persistence mechanism used by "
                "APTs that survives reboots and is not covered by standard scheduled task or "
                "registry run key analysis."
            ),
            "triggers": [
                "wmi_persistence_suspected",
                "malware_persistence_hunt",
                "post_compromise_forensics",
                "apt_indicators_detected",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.shadow_copy_status",
            "name": "Endpoint Shadow Copy Status",
            "category": "ENDPOINT",
            "action": "shadow_copy_status",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Checks the status of Windows Volume Shadow Copies (VSS). Windows-only. "
                "No parameters required. "
                "Returns all shadow copy instances with creation time, volume, and state. "
                "Use to verify whether shadow copies have been deleted (a key ransomware indicator) "
                "or to assess recovery options before triggering ransomware response procedures."
            ),
            "triggers": [
                "ransomware_active_on_host",
                "vss_deletion_detected",
                "recovery_option_assessment",
                "shadow_copy_deletion_alert",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.usb_media_history",
            "name": "Endpoint USB Media History",
            "category": "ENDPOINT",
            "action": "usb_media_history",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Reconstructs USB and removable media connection history from Windows registry "
                "and setup logs. Windows-only. No parameters required. "
                "Reads HKLM\\SYSTEM\\CurrentControlSet\\Enum\\USBSTOR for device metadata and "
                "serial numbers, parses C:\\Windows\\INF\\setupapi.dev.log for first-connect "
                "timestamps, and checks HKLM\\SYSTEM\\CurrentControlSet\\Enum\\USB for raw USB "
                "device records. "
                "Returns device list with vendor, model, serial number, and first-seen timestamp. "
                "Use to investigate data exfiltration via physical media or unauthorized USB device "
                "connections."
            ),
            "triggers": [
                "data_exfiltration_suspected",
                "usb_device_investigation",
                "insider_threat_investigation",
                "removable_media_policy_violation",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.browser_history",
            "name": "Endpoint Browser History",
            "category": "ENDPOINT",
            "action": "browser_history",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Extracts browser history from installed browsers on this endpoint. Windows-only. "
                "No parameters required. "
                "Reads SQLite history databases from Chrome, Edge, Firefox, and other Chromium-based "
                "browsers in the current user's profile directories. "
                "Returns a list of visited URLs with timestamps and visit counts. "
                "Use to reconstruct attacker web activity (phishing, malware download sites, C2 "
                "panels accessed via browser) or investigate insider threat web behavior."
            ),
            "triggers": [
                "insider_threat_investigation",
                "phishing_investigation",
                "malware_download_source_hunt",
                "post_compromise_forensics",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.prefetch_analysis",
            "name": "Endpoint Prefetch Analysis",
            "category": "ENDPOINT",
            "action": "prefetch_analysis",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Parses Windows Prefetch files to recover program execution history. Windows-only. "
                "Optional parameter: filter (substring to match against executable names, e.g. "
                "'mimikatz'). "
                "Reads all .pf files in C:\\Windows\\Prefetch and recovers executable name, run "
                "count, and up to 8 last-run timestamps. Handles MAM-compressed Win10 prefetch via "
                "RtlDecompressBufferEx (ntdll). "
                "Returns a list of executables with run counts and timestamps. "
                "Use to prove program execution of attacker tools even after the files have been "
                "deleted — prefetch entries persist independently of the executable."
            ),
            "triggers": [
                "attacker_tool_execution_hunt",
                "program_execution_investigation",
                "post_compromise_forensics",
                "malware_execution_evidence",
            ],
            "parameters_schema": {"filter": "optional_executable_name_filter"},
        },
        {
            "tool_id": "endpoint.run_powershell",
            "name": "Endpoint Run PowerShell",
            "category": "ENDPOINT",
            "action": "run_powershell",
            "execution_mode": "executable",
            "requires_approval": True,
            "risk": "CRITICAL",
            "description": (
                "Executes an arbitrary PowerShell script on the local endpoint and returns stdout/"
                "stderr. Windows-only. "
                "Required parameter: script (PowerShell script text to execute). "
                "Runs in a non-interactive, no-profile PowerShell session (-NoProfile "
                "-NonInteractive). Null bytes in the script are rejected. "
                "PREREQUISITE: Requires enable_command_execution=true in daemon config. If the "
                "config flag is not set, this action returns a PermissionError. "
                "This action requires approval before execution due to CRITICAL risk level. "
                "Use only when no purpose-built action covers the investigation need."
            ),
            "triggers": [
                "manual_investigation_command",
                "dynamic_forensics_script_execution",
                "custom_ir_script_requested",
            ],
            "parameters_schema": {
                "script": "Get-Process | Select-Object Name,Id | ConvertTo-Json"
            },
        },
        {
            "tool_id": "endpoint.kerberos_ticket_inspect",
            "name": "Endpoint Kerberos Ticket Inspect",
            "category": "ENDPOINT",
            "action": "kerberos_ticket_inspect",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Enumerates Kerberos tickets cached in the current logon session for golden/silver "
                "ticket and pass-the-ticket indicators. Windows-only. No parameters required. "
                "Returns ticket details including service name, client name, server realm, flags, "
                "start time, end time, and renew-until time. Flags tickets with anomalous lifetimes "
                "(>10 hours), forged realm mismatches, or RC4 encryption (ARCFOUR-HMAC) that "
                "indicate potential golden ticket attacks."
            ),
            "triggers": [
                "golden_ticket_suspected",
                "silver_ticket_suspected",
                "pass_the_ticket_detected",
                "kerberos_anomaly_alert",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.logon_session_enum",
            "name": "Endpoint Logon Session Enumeration",
            "category": "ENDPOINT",
            "action": "logon_session_enum",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Enumerates all active logon sessions on this Windows endpoint including their "
                "type, authentication package, and credentials cached. Windows-only. "
                "No parameters required. "
                "Returns session details including logon ID, session type (Interactive, Network, "
                "RemoteInteractive etc.), logon time, username, domain, and auth package. "
                "Use to detect forged logon sessions, identify active attacker sessions, and "
                "audit all credential caches present on the system."
            ),
            "triggers": [
                "suspicious_logon_session_detected",
                "credential_theft_suspected",
                "active_intrusion_response",
                "lateral_movement_suspected",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.token_privilege_inspect",
            "name": "Endpoint Token Privilege Inspect",
            "category": "ENDPOINT",
            "action": "token_privilege_inspect",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Inspects access tokens of running processes for dangerous privilege enablement "
                "indicating privilege escalation or token impersonation. Windows-only. "
                "No parameters required. "
                "Enumerates all running process tokens and flags those with SeDebugPrivilege, "
                "SeImpersonatePrivilege, SeTcbPrivilege, SeAssignPrimaryTokenPrivilege, or other "
                "high-risk privileges enabled. "
                "Returns per-process privilege listing with enabled/disabled status. "
                "Use to detect potato-style escalation, token theft, and processes running with "
                "elevated token privileges they should not have."
            ),
            "triggers": [
                "privilege_escalation_suspected",
                "token_impersonation_detected",
                "process_injection_suspected",
                "active_intrusion_response",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.named_pipe_enumeration",
            "name": "Endpoint Named Pipe Enumeration",
            "category": "ENDPOINT",
            "action": "named_pipe_enumeration",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Enumerates all named pipes on this Windows endpoint. Windows-only. "
                "No parameters required. "
                "Lists all currently open named pipe instances with their names and connection count. "
                "Flags pipes with names matching known C2 framework default pipe names (Cobalt Strike, "
                "Metasploit, Empire, etc.). "
                "Returns: [{pipe_name, instances, flagged, reason}]. "
                "Named pipes are commonly used by C2 frameworks for lateral movement via "
                "pass-the-hash or SMB-based beacon communication."
            ),
            "triggers": [
                "c2_implant_suspected",
                "cobalt_strike_indicator",
                "lateral_movement_suspected",
                "named_pipe_c2_detected",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.amcache_shimcache",
            "name": "Endpoint Amcache and Shimcache Analysis",
            "category": "ENDPOINT",
            "action": "amcache_shimcache",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Parses Windows Amcache.hve and AppCompatCache (Shimcache) registry entries for "
                "program execution history. Windows-only. No parameters required. "
                "Amcache records executable file paths, SHA-1 hashes, and compilation timestamps "
                "of programs that have been run. Shimcache records file system metadata for "
                "compatibility checks (does not require execution on Win10+). "
                "Returns a list of recently recorded executables with file paths, timestamps, and "
                "SHA-1 hashes where available. "
                "Use to prove prior execution of attacker tools even after deletion."
            ),
            "triggers": [
                "attacker_tool_execution_hunt",
                "program_execution_investigation",
                "post_compromise_forensics",
                "malware_execution_evidence",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.autoruns_deep",
            "name": "Endpoint Autoruns Deep Scan",
            "category": "ENDPOINT",
            "action": "autoruns_deep",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Performs comprehensive enumeration of all autorun/persistence locations on the "
                "endpoint, going deeper than endpoint.startup_programs. Windows-only. "
                "No parameters required. "
                "Covers additional vectors beyond startup_programs including: LSA notification "
                "packages, print monitor DLLs, network provider DLLs, boot execute entries, "
                "browser helper objects (BHOs), explorer extensions, image file execution options "
                "(IFEO debugger hijacks), SilentProcessExit, and COM object hijack points. "
                "Returns structured findings with source, name, executable path, and whether the "
                "path is verified as signed."
            ),
            "triggers": [
                "persistence_mechanism_investigation",
                "malware_persistence_hunt",
                "post_compromise_forensics",
                "apt_indicators_detected",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.kernel_driver_scan",
            "name": "Endpoint Kernel Driver Scan",
            "category": "ENDPOINT",
            "action": "kernel_driver_scan",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Enumerates all loaded kernel drivers and flags unsigned, unknown, or suspicious "
                "drivers. Windows-only. No parameters required. "
                "Uses Get-CimInstance Win32_SystemDriver and checks each driver's binary for "
                "Authenticode signature validity. Flags drivers not in System32\\drivers or "
                "System32\\DriverStore, drivers with missing version info, and known malicious "
                "driver names. "
                "Returns: [{driver_name, path, state, start_mode, signed, suspect_reason}]. "
                "Use when kernel-level rootkit or BYOVD (Bring Your Own Vulnerable Driver) attack "
                "is suspected."
            ),
            "triggers": [
                "rootkit_suspected",
                "byovd_attack_suspected",
                "kernel_level_malware_detected",
                "driver_anomaly_alert",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.dll_hijack_detector",
            "name": "Endpoint DLL Hijack Detector",
            "category": "ENDPOINT",
            "action": "dll_hijack_detector",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Detects potential DLL hijacking across all running processes by comparing on-disk "
                "DLL paths against expected system locations. Windows-only. No parameters required. "
                "Uses EnumProcessModulesEx + GetModuleFileNameExW via ctypes (no child processes). "
                "Flags DLLs loaded from unexpected paths (not System32, SysWOW64, WinSxS, or "
                "Program Files). Also checks DLL search order vulnerabilities for key application "
                "directories. "
                "Returns findings per process with the suspicious DLL path and expected location. "
                "Use to detect phantom DLL hijacking and side-loading attacks."
            ),
            "triggers": [
                "dll_hijacking_suspected",
                "code_injection_suspected",
                "side_loading_attack_suspected",
                "process_forensics_requested",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.com_hijack_detector",
            "name": "Endpoint COM Hijack Detector",
            "category": "ENDPOINT",
            "action": "com_hijack_detector",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Detects COM object hijacking by comparing HKCU COM registrations against HKLM "
                "baseline to find user-level COM overrides used for persistence or privilege "
                "escalation. Windows-only. No parameters required. "
                "Checks HKCU\\Software\\Classes\\CLSID for entries that shadow HKLM\\Software\\"
                "Classes\\CLSID registrations. Flags InprocServer32 and LocalServer32 paths pointing "
                "to user-writable locations. "
                "Returns a list of hijacked CLSIDs with user path, system path, and risk assessment. "
                "Use to detect UAC bypass via COM hijack and stealthy persistence."
            ),
            "triggers": [
                "com_hijacking_suspected",
                "uac_bypass_suspected",
                "persistence_mechanism_investigation",
                "malware_persistence_hunt",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.lsa_provider_audit",
            "name": "Endpoint LSA Provider Audit",
            "category": "ENDPOINT",
            "action": "lsa_provider_audit",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Audits LSA (Local Security Authority) security packages and authentication "
                "providers for unauthorized additions used as persistence or credential capture "
                "mechanisms. Windows-only. No parameters required. "
                "Reads HKLM\\SYSTEM\\CurrentControlSet\\Control\\Lsa for Security Packages, "
                "Authentication Packages, and Notification Packages. Flags any provider that is "
                "not a known Microsoft component or has an unexpected file path. "
                "Returns the full list of registered providers with paths and verification status. "
                "LSA provider injection is used by attackers to capture credentials at logon."
            ),
            "triggers": [
                "credential_theft_suspected",
                "lsa_tampering_suspected",
                "persistence_mechanism_investigation",
                "post_compromise_forensics",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.etw_tamper_detection",
            "name": "Endpoint ETW Tamper Detection",
            "category": "ENDPOINT",
            "action": "etw_tamper_detection",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Detects ETW (Event Tracing for Windows) tampering used to blind security tooling "
                "and evade detection. Windows-only. No parameters required. "
                "Checks for: ETW providers that have been disabled, patched EtwEventWrite function "
                "in ntdll (inline hook), suspicious processes that have killed ETW sessions, and "
                "missing or disabled critical security-relevant ETW providers (Microsoft-Windows-"
                "Threat-Intelligence, PowerShell/Operational, etc.). "
                "Returns findings with provider names, status, and evidence of tampering. "
                "Use when security tools appear blind or event logs show unexplained gaps."
            ),
            "triggers": [
                "security_tool_evasion_suspected",
                "event_log_gaps_detected",
                "amsi_bypass_detected",
                "etw_tampering_suspected",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.wdigest_credential_check",
            "name": "Endpoint WDigest Credential Check",
            "category": "ENDPOINT",
            "action": "wdigest_credential_check",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Checks whether WDigest plaintext credential caching is enabled in the registry, "
                "which allows tools like Mimikatz to extract cleartext passwords from LSASS. "
                "Windows-only. No parameters required. "
                "Reads HKLM\\SYSTEM\\CurrentControlSet\\Control\\SecurityProviders\\WDigest for the "
                "UseLogonCredential value. Returns: {wdigest_enabled, registry_value, risk_level}. "
                "If WDigest is enabled on a system where it should be disabled (modern Windows), "
                "this indicates potential attacker registry modification to enable credential "
                "harvesting."
            ),
            "triggers": [
                "credential_theft_suspected",
                "mimikatz_activity_detected",
                "lsass_access_alert",
                "post_compromise_forensics",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.defender_exclusion_audit",
            "name": "Endpoint Defender Exclusion Audit",
            "category": "ENDPOINT",
            "action": "defender_exclusion_audit",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Audits Windows Defender exclusion rules to detect attacker-added exclusions that "
                "allow malware to evade real-time protection. Windows-only. No parameters required. "
                "Reads all configured exclusions from "
                "HKLM\\SOFTWARE\\Microsoft\\Windows Defender\\Exclusions for paths, extensions, "
                "and processes. Flags exclusions pointing to temporary directories, user-writable "
                "paths, or non-standard executables. "
                "Returns the full exclusion list with a risk flag per entry. "
                "Use when malware evades AV or when Defender appears to have been neutered."
            ),
            "triggers": [
                "security_tool_evasion_suspected",
                "defender_tampered_suspected",
                "malware_evading_av_detected",
                "post_compromise_forensics",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.powershell_profile_audit",
            "name": "Endpoint PowerShell Profile Audit",
            "category": "ENDPOINT",
            "action": "powershell_profile_audit",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Audits all PowerShell profile script files for unauthorized or malicious content. "
                "Windows-only. No parameters required. "
                "Checks all-users and current-user profile locations for both PowerShell 5 and "
                "PowerShell 7: $PROFILE.AllUsersAllHosts, $PROFILE.AllUsersCurrentHost, "
                "$PROFILE.CurrentUserAllHosts, $PROFILE.CurrentUserCurrentHost, and the "
                "Microsoft.PowerShell_profile.ps1 variants. "
                "Returns file content and flags any profile containing download cradles, "
                "persistence-related cmdlets, or encoded commands. "
                "PowerShell profile hijacking is used for persistent code execution that fires "
                "on every new PowerShell session."
            ),
            "triggers": [
                "powershell_persistence_suspected",
                "persistence_mechanism_investigation",
                "post_compromise_forensics",
                "malware_persistence_hunt",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.powershell_script_block_history",
            "name": "Endpoint PowerShell Script Block History",
            "category": "ENDPOINT",
            "action": "powershell_script_block_history",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Extracts the full PowerShell script text logged via EID 4104 (Script Block "
                "Logging) from the Microsoft-Windows-PowerShell/Operational event log. "
                "Windows-only. Optional parameters: hours (look-back window 1–168, default 24), "
                "limit (max entries returned 1–5000, default 500). "
                "If script block logging was disabled, it is automatically enabled for future "
                "sessions. Returns: {hours_back, total_returned, warning, entries: [{timestamp, "
                "script_block_id, script_text (up to 8192 chars), script_path, user_sid, pid}]}. "
                "Use to recover attacker PowerShell commands including obfuscated and in-memory "
                "cradles that were executed without leaving files on disk."
            ),
            "triggers": [
                "powershell_attack_suspected",
                "malware_powershell_execution",
                "obfuscated_powershell_detected",
                "post_compromise_forensics",
            ],
            "parameters_schema": {"hours": 24, "limit": 500},
        },
        {
            "tool_id": "endpoint.office_macro_scan",
            "name": "Endpoint Office Macro Scan",
            "category": "ENDPOINT",
            "action": "office_macro_scan",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Scans Office documents for embedded VBA macros without executing them. "
                "Windows-only. Optional parameter: path (directory to scan; defaults to user home). "
                "Scans .docm, .xlsm, .dotm, .pptm, .xlam, .xla, .doc, .xls files for dangerous "
                "VBA patterns: Shell(), WScript, CreateObject, AutoOpen, Document_Open, Base64/"
                "Chr() obfuscation, download cradles (URLDownloadToFile, XMLHTTP, WinHttp), "
                "Environ() credential harvesting, and certutil/powershell/cmd.exe references. "
                "Returns file-by-file findings with matched patterns and risk score. "
                "Use to scan email attachments or user directories for macro-enabled malware."
            ),
            "triggers": [
                "phishing_macro_document_suspected",
                "office_document_malware_alert",
                "user_file_scan_requested",
                "maldoc_investigation",
            ],
            "parameters_schema": {"path": "C:\\Users\\jsmith\\Documents"},
        },
        {
            "tool_id": "endpoint.ads_scanner",
            "name": "Endpoint ADS Scanner",
            "category": "ENDPOINT",
            "action": "ads_scanner",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Scans a directory for NTFS Alternate Data Streams (ADS) beyond the legitimate "
                "Zone.Identifier stream. Windows-only. "
                "Required parameter: path (directory to scan). "
                "Optional parameters: recursive (bool, default false), "
                "include_zone_id (bool, include Zone.Identifier streams, default false). "
                "Returns a list of files with ADS entries including stream name, size, and content "
                "preview. ADS are used by attackers to hide malware, configuration data, or scripts "
                "inside the metadata of legitimate files, making them invisible to normal dir listings."
            ),
            "triggers": [
                "data_hiding_suspected",
                "anti_forensics_suspected",
                "malware_hiding_in_ads",
                "post_compromise_forensics",
            ],
            "parameters_schema": {
                "path": "C:\\Windows\\Temp",
                "recursive": False,
                "include_zone_id": False,
            },
        },
        {
            "tool_id": "endpoint.network_proxy_config",
            "name": "Endpoint Network Proxy Config",
            "category": "ENDPOINT",
            "action": "network_proxy_config",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "LOW",
            "description": (
                "Retrieves the current network proxy configuration for this endpoint. "
                "No parameters required. Cross-platform. "
                "On Windows reads from HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\"
                "Internet Settings (ProxyEnable, ProxyServer, ProxyOverride) and checks WinHTTP "
                "proxy settings. On Linux reads http_proxy/https_proxy/no_proxy environment "
                "variables and /etc/environment. "
                "Returns proxy settings with enabled status and server address. "
                "Use to detect attacker-configured proxy redirection used to intercept or redirect "
                "traffic through a C2 infrastructure."
            ),
            "triggers": [
                "traffic_redirection_detected",
                "proxy_misconfiguration_suspected",
                "c2_via_proxy_suspected",
                "network_configuration_audit",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.certificate_store_audit",
            "name": "Endpoint Certificate Store Audit",
            "category": "ENDPOINT",
            "action": "certificate_store_audit",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Audits the Windows certificate store for unauthorized or rogue root/intermediate "
                "CA certificates that could enable HTTPS interception. Windows-only. "
                "No parameters required. "
                "Enumerates Trusted Root CA and Intermediate CA stores (LocalMachine and "
                "CurrentUser) and flags certificates not issued by known Microsoft or major "
                "commercial CAs. Also checks for recently added certificates and those with "
                "suspiciously short validity periods. "
                "Returns: {trusted_roots: [...], intermediate_cas: [...], suspicious: [...]}. "
                "Use when SSL/TLS interception or rogue CA persistence is suspected."
            ),
            "triggers": [
                "tls_interception_suspected",
                "rogue_ca_certificate_detected",
                "https_traffic_decryption_suspected",
                "post_compromise_forensics",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.clipboard_history",
            "name": "Endpoint Clipboard History",
            "category": "ENDPOINT",
            "action": "clipboard_history",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Reads the current clipboard content and Windows clipboard history. Windows-only. "
                "No parameters required. "
                "Returns the current clipboard text content and, where clipboard history is enabled "
                "(Windows 10+), retrieves recent clipboard history entries. "
                "Returns: {current_content, history: [...]}. "
                "Use during active incident response to check if an attacker copied credentials, "
                "commands, or other sensitive data to the clipboard in an active session."
            ),
            "triggers": [
                "active_intrusion_response",
                "credential_theft_suspected",
                "interactive_session_forensics",
                "insider_threat_investigation",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.file_anomaly_detector",
            "name": "Endpoint File Anomaly Detector",
            "category": "ENDPOINT",
            "action": "file_anomaly_detector",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Scans a directory for files with suspicious characteristics. Windows-only. "
                "Required parameter: path (directory to scan). "
                "Optional parameters: recursive (bool, default false), "
                "hours (flag files modified in the past N hours, 1–720, default 24). "
                "Checks: magic-byte vs extension mismatches (PE hidden as .jpg, .pdf, etc.), "
                "executables in user-writable paths, recently modified system files, files with "
                "future timestamps (timestomping indicator), zero-byte executables, and PE files "
                "with no version information. Each finding is scored 0–100. "
                "Returns findings with anomaly type, file path, and score."
            ),
            "triggers": [
                "malware_dropper_investigation",
                "suspicious_file_investigation",
                "anti_forensics_suspected",
                "post_compromise_forensics",
            ],
            "parameters_schema": {
                "path": "C:\\Windows\\Temp",
                "recursive": False,
                "hours": 24,
            },
        },
        {
            "tool_id": "endpoint.share_open_file_enum",
            "name": "Endpoint Share Open File Enumeration",
            "category": "ENDPOINT",
            "action": "share_open_file_enum",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Enumerates files currently open via SMB shares on this Windows host. "
                "Windows-only. No parameters required. "
                "Returns a list of files opened by remote clients via SMB, including the file "
                "path, the user who has it open, and the remote host. "
                "Use to detect data staging, exfiltration of files via SMB from a compromised "
                "file server, or unauthorized access to sensitive share contents."
            ),
            "triggers": [
                "data_exfiltration_suspected",
                "unauthorized_share_access",
                "smb_unauthorized_access",
                "compromised_server_triage",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.pipe_and_rpc_server_enum",
            "name": "Endpoint Pipe and RPC Server Enumeration",
            "category": "ENDPOINT",
            "action": "pipe_and_rpc_server_enum",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "MEDIUM",
            "description": (
                "Enumerates named pipes and RPC server endpoints registered on this Windows host. "
                "Windows-only. No parameters required. "
                "Lists all named pipes accessible via \\\\.\\pipe\\ and RPC endpoint bindings "
                "registered in the local endpoint mapper. Flags pipe names matching known C2 "
                "framework defaults and RPC interfaces registered by unexpected processes. "
                "Returns: {pipes: [...], rpc_endpoints: [...], flagged: [...]}. "
                "Use to detect C2 framework named pipe communication channels and unauthorized RPC "
                "server registrations."
            ),
            "triggers": [
                "c2_implant_suspected",
                "named_pipe_c2_detected",
                "lateral_movement_suspected",
                "active_intrusion_response",
            ],
            "parameters_schema": {},
        },
        {
            "tool_id": "endpoint.ad_recon_indicators",
            "name": "Endpoint AD Recon Indicators",
            "category": "ENDPOINT",
            "action": "ad_recon_indicators",
            "execution_mode": "executable",
            "requires_approval": False,
            "risk": "HIGH",
            "description": (
                "Detects Active Directory reconnaissance activity on this endpoint by analyzing "
                "event logs and process activity. Windows-only. No parameters required. "
                "Checks for: Security event log entries indicating LDAP queries, BloodHound/ADExplorer "
                "process names in running or recently-run processes (via Amcache/Prefetch), "
                "net.exe commands enumerating domain users/groups/trusts in PowerShell script block "
                "logs (EID 4104), and anomalous LDAP bind counts in the Directory Service event log. "
                "Returns findings with source, timestamp, and evidence. "
                "Use when BloodHound, SharpHound, or LDAP enumeration activity is suspected."
            ),
            "triggers": [
                "ad_enumeration_suspected",
                "bloodhound_activity_detected",
                "ldap_reconnaissance_alert",
                "domain_recon_activity",
            ],
            "parameters_schema": {},
        },
    ]

    TRIGGER_MAP = {
        "dns_exfiltration_suspected": [
            "dns.tunnel_score",
            "deception.signal_fuser",
            "endpoint.dns_query_history",
        ],
        "dc_replication_errors": [
            "ad.replication_drift_probe",
            "tier0.admin_path_mapper",
        ],
        "suspicious_gpo_change": [
            "gpo.startup_script_view",
            "living_off_land.detector",
        ],
        "legacy_auth_usage_detected": [
            "legacy_protocol_exposure_map",
            "tier0.admin_path_mapper",
        ],
        "honeypot_trip": ["deception.honeypot.early_warning", "deception.signal_fuser"],
        "honeypot_trip_smb": [
            "deception.honeypot.early_warning",
            "deception.signal_fuser",
        ],
        "honeypot_trip_ssh": [
            "deception.honeypot.early_warning",
            "deception.signal_fuser",
        ],
        "honeypot_trip_rdp": [
            "deception.honeypot.early_warning",
            "deception.signal_fuser",
        ],
        "honeypot_trip_ftp": [
            "deception.honeypot.early_warning",
            "deception.signal_fuser",
        ],
        "honeypot_trip_telnet": [
            "deception.honeypot.early_warning",
            "deception.signal_fuser",
        ],
        "honeypot_trip_http": [
            "deception.honeypot.early_warning",
            "deception.signal_fuser",
        ],
        "honeypot_trip_https": [
            "deception.honeypot.early_warning",
            "deception.signal_fuser",
        ],
        "honeypot_trip_dns": [
            "deception.honeypot.early_warning",
            "deception.signal_fuser",
        ],
        "honeypot_trip_ldap": [
            "deception.honeypot.early_warning",
            "deception.signal_fuser",
        ],
        "honeypot_trip_rpc": [
            "deception.honeypot.early_warning",
            "deception.signal_fuser",
        ],
        "code_injection_suspected": [
            "memory.suspect_modules",
            "living_off_land.detector",
            "endpoint.process_injection_scan",
            "endpoint.process_modules",
        ],
        "artifact_collection_requested": [
            "endpoint.remote_file_system_list",
            "endpoint.remote_file_collect",
        ],
        "rpc_lateral_movement": ["net.rpc.query", "tier0.admin_path_mapper"],
        "remote_agent_install_requested": [
            "deploy.hawk_soard",
            "deploy.hawk_soard.verify",
        ],
        "new_endpoint_onboarding": ["deploy.hawk_soard", "deploy.hawk_soard.verify"],
        "agent_missing_on_host": ["deploy.hawk_soard", "deploy.hawk_soard.verify"],
        "lateral_coverage_gap_detected": ["deploy.hawk_soard"],
        "agent_health_check_requested": ["deploy.hawk_soard.verify"],
        # Network
        "host_reachability_check": ["net.ping"],
        "network_connectivity_investigation": ["net.ping", "net.traceroute"],
        "incident_initial_triage": [
            "net.ping",
            "endpoint.running_processes",
            "endpoint.network_connections",
        ],
        "arp_spoofing_suspected": ["net.arp_table", "net.ping"],
        "rogue_device_on_subnet": ["net.arp_table", "net.port_scan"],
        "network_discovery_activity": ["net.arp_table", "net.route_table"],
        "suspicious_route_added": ["net.route_table", "net.traceroute"],
        "vpn_tunnel_investigation": ["net.route_table", "net.traceroute"],
        "network_persistence_suspected": [
            "net.route_table",
            "endpoint.startup_programs",
        ],
        "traffic_redirection_detected": [
            "net.route_table",
            "endpoint.network_proxy_config",
        ],
        "c2_port_validation": ["net.port_scan", "net.ping"],
        "firewall_rule_verification": ["net.port_scan"],
        "lateral_movement_service_discovery": ["net.port_scan", "net.smb_sessions"],
        "open_service_enumeration": ["net.port_scan", "endpoint.open_ports"],
        "suspicious_domain_investigation": ["net.dns_lookup", "dns.tunnel_score"],
        "ioc_dns_validation_requested": ["net.dns_lookup"],
        "c2_domain_suspected": [
            "net.dns_lookup",
            "endpoint.dns_query_history",
            "dns.tunnel_score",
        ],
        "phishing_domain_check": ["net.dns_lookup"],
        "network_path_investigation": ["net.traceroute"],
        "traffic_interception_suspected": [
            "net.traceroute",
            "endpoint.certificate_store_audit",
        ],
        "egress_route_analysis": ["net.traceroute", "net.route_table"],
        "smb_unauthorized_access": [
            "net.smb_sessions",
            "net.smb_share_query",
            "endpoint.share_open_file_enum",
        ],
        "compromised_server_triage": [
            "net.smb_sessions",
            "endpoint.running_processes",
            "endpoint.logged_in_users",
            "endpoint.active_connections",
        ],
        "data_staging_suspected": [
            "net.smb_share_query",
            "endpoint.share_open_file_enum",
            "endpoint.ntfs_journal_analysis",
        ],
        "unauthorized_share_detected": [
            "net.smb_share_query",
            "endpoint.share_open_file_enum",
        ],
        "remote_share_investigation_requested": [
            "net.smb_share_query",
            "net.smb_client",
        ],
        # AD
        "suspicious_account_activity": [
            "ad.get_user_details",
            "ad.retrieve_last_logon",
            "ad.enumerate_group_membership",
        ],
        "identity_investigation_requested": [
            "ad.get_user_details",
            "ad.enumerate_group_membership",
        ],
        "compromised_account_suspected": [
            "ad.get_user_details",
            "ad.retrieve_last_logon",
            "endpoint.lateral_movement_artifacts",
        ],
        "insider_threat_investigation": [
            "ad.get_user_details",
            "endpoint.browser_history",
            "endpoint.usb_media_history",
        ],
        "privilege_escalation_suspected": [
            "ad.enumerate_group_membership",
            "ad.audit_privileged_group_membership",
            "endpoint.token_privilege_inspect",
        ],
        "admin_account_investigation": [
            "ad.enumerate_group_membership",
            "ad.audit_privileged_group_membership",
        ],
        "compromised_account_containment": [
            "ad.disable_account",
            "containment.disable_user",
            "containment.logoff_user",
        ],
        "active_intrusion_response": [
            "endpoint.running_processes",
            "endpoint.logged_in_users",
            "endpoint.active_connections",
            "containment.logoff_user",
        ],
        "insider_threat_containment": [
            "containment.logoff_user",
            "containment.disable_user",
            "ad.disable_account",
        ],
        "account_takeover_response": [
            "ad.disable_account",
            "ad.reset_password",
            "containment.logoff_user",
        ],
        "compromised_credential_response": ["ad.reset_password", "ad.disable_account"],
        "account_remediation_requested": ["ad.enable_account"],
        "incident_remediation": ["ad.enable_account"],
        "account_restoration_requested": ["ad.enable_account"],
        "dormant_account_reactivation": [
            "ad.retrieve_last_logon",
            "ad.get_user_details",
        ],
        "admin_group_membership_check": ["ad.audit_privileged_group_membership"],
        "post_remediation_verification": ["ad.audit_privileged_group_membership"],
        # CONTAINMENT
        "malware_process_termination": ["containment.kill_process"],
        "c2_implant_contained": [
            "containment.kill_process",
            "containment.add_firewall_block_rule",
        ],
        "ransomware_process_kill": [
            "containment.kill_process",
            "containment.host_isolation",
        ],
        "malicious_service_detected": [
            "containment.stop_service",
            "endpoint.services_status",
        ],
        "persistence_mechanism_containment": ["containment.stop_service"],
        "lateral_movement_service_stop": ["containment.stop_service"],
        "attacker_ip_block_requested": ["containment.add_firewall_block_rule"],
        "c2_connection_containment": [
            "containment.add_firewall_block_rule",
            "containment.kill_process",
        ],
        "ransomware_lateral_block": [
            "containment.add_firewall_block_rule",
            "containment.host_isolation",
        ],
        "ransomware_active_on_host": [
            "endpoint.ransomware_indicators",
            "endpoint.shadow_copy_status",
            "containment.host_isolation",
        ],
        "full_host_containment_requested": ["containment.host_isolation"],
        "critical_malware_detected": [
            "containment.host_isolation",
            "containment.kill_process",
        ],
        "unauthorized_local_account_detected": ["containment.disable_user"],
        "unauthorized_interactive_session": [
            "endpoint.logged_in_users",
            "containment.logoff_user",
        ],
        # ENDPOINT — process and session
        "process_forensics_requested": [
            "endpoint.running_processes",
            "endpoint.process_modules",
            "endpoint.process_injection_scan",
        ],
        "malware_process_hunt": [
            "endpoint.running_processes",
            "endpoint.process_injection_scan",
        ],
        "endpoint_triage_requested": [
            "endpoint.running_processes",
            "endpoint.network_connections",
            "endpoint.open_ports",
            "endpoint.startup_programs",
        ],
        "session_investigation_requested": [
            "endpoint.logged_in_users",
            "endpoint.logon_session_enum",
        ],
        "suspicious_logon_session_detected": [
            "endpoint.logon_session_enum",
            "endpoint.lateral_movement_artifacts",
        ],
        # ENDPOINT — persistence
        "persistence_mechanism_investigation": [
            "endpoint.startup_programs",
            "endpoint.scheduled_tasks",
            "endpoint.scheduled_task_deep",
            "endpoint.wmi_persistence_deep",
            "endpoint.autoruns_deep",
        ],
        "scheduled_task_anomaly_detected": [
            "endpoint.scheduled_tasks",
            "endpoint.scheduled_task_deep",
        ],
        "malware_persistence_hunt": [
            "endpoint.startup_programs",
            "endpoint.wmi_persistence_deep",
            "endpoint.autoruns_deep",
            "endpoint.powershell_profile_audit",
        ],
        "obfuscated_task_suspected": ["endpoint.scheduled_task_deep"],
        "wmi_persistence_suspected": ["endpoint.wmi_persistence_deep"],
        "powershell_persistence_suspected": [
            "endpoint.powershell_profile_audit",
            "endpoint.powershell_script_block_history",
        ],
        "apt_indicators_detected": [
            "endpoint.wmi_persistence_deep",
            "endpoint.autoruns_deep",
            "endpoint.lsass_access_indicators",
        ],
        # ENDPOINT — credential theft
        "credential_theft_suspected": [
            "endpoint.lsass_access_indicators",
            "endpoint.credential_theft_indicators",
            "endpoint.wdigest_credential_check",
        ],
        "mimikatz_activity_detected": [
            "endpoint.lsass_access_indicators",
            "endpoint.wdigest_credential_check",
            "endpoint.process_injection_scan",
        ],
        "pass_the_hash_suspected": [
            "endpoint.lsass_access_indicators",
            "endpoint.lateral_movement_artifacts",
            "endpoint.logon_session_enum",
        ],
        "lsass_access_alert": [
            "endpoint.lsass_access_indicators",
            "endpoint.wdigest_credential_check",
        ],
        "credential_access_alert": [
            "endpoint.credential_theft_indicators",
            "endpoint.lsass_access_indicators",
        ],
        # ENDPOINT — lateral movement
        "lateral_movement_suspected": [
            "endpoint.lateral_movement_artifacts",
            "endpoint.active_connections",
            "net.smb_sessions",
        ],
        "pass_the_ticket_detected": [
            "endpoint.kerberos_ticket_inspect",
            "endpoint.logon_session_enum",
        ],
        "golden_ticket_suspected": ["endpoint.kerberos_ticket_inspect"],
        "silver_ticket_suspected": ["endpoint.kerberos_ticket_inspect"],
        "kerberos_anomaly_alert": [
            "endpoint.kerberos_ticket_inspect",
            "endpoint.lateral_movement_artifacts",
        ],
        "unauthorized_remote_logon": [
            "endpoint.lateral_movement_artifacts",
            "endpoint.logon_session_enum",
        ],
        # ENDPOINT — network on endpoint
        "c2_connection_suspected": [
            "endpoint.active_connections",
            "endpoint.open_ports",
            "endpoint.dns_query_history",
        ],
        "suspicious_outbound_traffic": [
            "endpoint.active_connections",
            "net.traceroute",
            "endpoint.dns_query_history",
        ],
        "backdoor_port_suspected": ["endpoint.open_ports", "net.port_scan"],
        "unauthorized_listener_detected": ["endpoint.open_ports"],
        "named_pipe_c2_detected": [
            "endpoint.named_pipe_enumeration",
            "endpoint.pipe_and_rpc_server_enum",
        ],
        "c2_implant_suspected": [
            "endpoint.named_pipe_enumeration",
            "endpoint.process_injection_scan",
            "endpoint.memory_ioc_extractor",
        ],
        "cobalt_strike_indicator": [
            "endpoint.named_pipe_enumeration",
            "endpoint.process_injection_scan",
            "endpoint.process_hook_scan",
        ],
        # ENDPOINT — memory forensics
        "c2_configuration_extraction": ["endpoint.memory_ioc_extractor"],
        "malware_process_forensics": [
            "endpoint.memory_ioc_extractor",
            "endpoint.process_modules",
        ],
        "live_memory_ioc_hunt": ["endpoint.memory_ioc_extractor"],
        "implant_analysis_requested": [
            "endpoint.memory_ioc_extractor",
            "endpoint.process_modules",
        ],
        "process_hollowing_suspected": [
            "endpoint.process_injection_scan",
            "endpoint.process_modules",
        ],
        "shellcode_execution_suspected": [
            "endpoint.process_injection_scan",
            "endpoint.memory_ioc_extractor",
        ],
        "dll_injection_suspected": [
            "endpoint.process_modules",
            "endpoint.dll_hijack_detector",
        ],
        "malware_module_hunt": [
            "endpoint.process_modules",
            "endpoint.dll_hijack_detector",
        ],
        # ENDPOINT — anti-forensics and evasion
        "api_hooking_suspected": ["endpoint.process_hook_scan"],
        "security_tool_evasion_suspected": [
            "endpoint.process_hook_scan",
            "endpoint.etw_tamper_detection",
            "endpoint.defender_exclusion_audit",
        ],
        "rootkit_suspected": [
            "endpoint.kernel_driver_scan",
            "endpoint.process_hook_scan",
        ],
        "amsi_bypass_detected": [
            "endpoint.process_hook_scan",
            "endpoint.etw_tamper_detection",
        ],
        "etw_tampering_suspected": ["endpoint.etw_tamper_detection"],
        "security_service_tampering_suspected": [
            "endpoint.services_status",
            "endpoint.etw_tamper_detection",
        ],
        "defender_tampered_suspected": ["endpoint.defender_exclusion_audit"],
        "malware_evading_av_detected": [
            "endpoint.defender_exclusion_audit",
            "endpoint.process_hook_scan",
        ],
        "event_log_gaps_detected": [
            "endpoint.etw_tamper_detection",
            "endpoint.event_log_extraction",
        ],
        "byovd_attack_suspected": ["endpoint.kernel_driver_scan"],
        "kernel_level_malware_detected": ["endpoint.kernel_driver_scan"],
        "driver_anomaly_alert": ["endpoint.kernel_driver_scan"],
        # ENDPOINT — ransomware
        "vss_deletion_detected": [
            "endpoint.shadow_copy_status",
            "endpoint.ransomware_indicators",
        ],
        "bulk_file_encryption_suspected": [
            "endpoint.ransomware_indicators",
            "endpoint.ntfs_journal_analysis",
        ],
        "shadow_copy_deletion_alert": [
            "endpoint.shadow_copy_status",
            "endpoint.ransomware_indicators",
        ],
        "recovery_option_assessment": ["endpoint.shadow_copy_status"],
        # ENDPOINT — file system forensics
        "anti_forensics_suspected": [
            "endpoint.ntfs_journal_analysis",
            "endpoint.mft_analyzer",
            "endpoint.ads_scanner",
        ],
        "file_deletion_investigation": ["endpoint.ntfs_journal_analysis"],
        "timestomping_suspected": ["endpoint.mft_analyzer"],
        "malware_dropper_investigation": [
            "endpoint.mft_analyzer",
            "endpoint.file_anomaly_detector",
        ],
        "post_compromise_forensics": [
            "endpoint.startup_programs",
            "endpoint.lateral_movement_artifacts",
            "endpoint.prefetch_analysis",
            "endpoint.amcache_shimcache",
        ],
        "attacker_tool_execution_hunt": [
            "endpoint.prefetch_analysis",
            "endpoint.amcache_shimcache",
        ],
        "program_execution_investigation": [
            "endpoint.prefetch_analysis",
            "endpoint.amcache_shimcache",
        ],
        "malware_execution_evidence": [
            "endpoint.prefetch_analysis",
            "endpoint.amcache_shimcache",
        ],
        "ioc_file_validation": ["endpoint.file_exists_hash"],
        "malware_file_hunt": [
            "endpoint.file_exists_hash",
            "endpoint.file_anomaly_detector",
        ],
        "remediation_verification": ["endpoint.file_exists_hash"],
        "artifact_hash_check": ["endpoint.file_exists_hash"],
        "suspicious_file_investigation": [
            "endpoint.file_anomaly_detector",
            "endpoint.file_exists_hash",
        ],
        "data_hiding_suspected": ["endpoint.ads_scanner"],
        "malware_hiding_in_ads": ["endpoint.ads_scanner"],
        # ENDPOINT — exfiltration and insider
        "data_exfiltration_suspected": [
            "endpoint.usb_media_history",
            "endpoint.share_open_file_enum",
            "endpoint.dns_query_history",
        ],
        "usb_device_investigation": ["endpoint.usb_media_history"],
        "removable_media_policy_violation": ["endpoint.usb_media_history"],
        "insider_threat_investigation": [
            "endpoint.browser_history",
            "endpoint.usb_media_history",
            "endpoint.clipboard_history",
        ],
        "interactive_session_forensics": [
            "endpoint.clipboard_history",
            "endpoint.logon_session_enum",
        ],
        "phishing_investigation": [
            "endpoint.browser_history",
            "endpoint.dns_query_history",
        ],
        "malware_download_source_hunt": [
            "endpoint.browser_history",
            "endpoint.dns_query_history",
        ],
        # ENDPOINT — PowerShell and scripting
        "powershell_attack_suspected": [
            "endpoint.powershell_script_block_history",
            "endpoint.powershell_profile_audit",
        ],
        "malware_powershell_execution": ["endpoint.powershell_script_block_history"],
        "obfuscated_powershell_detected": [
            "endpoint.powershell_script_block_history",
            "endpoint.powershell_profile_audit",
        ],
        "manual_investigation_command": [
            "endpoint.command.run",
            "endpoint.run_powershell",
        ],
        "dynamic_forensics_script_execution": ["endpoint.run_powershell"],
        "custom_ir_script_requested": ["endpoint.run_powershell"],
        # ENDPOINT — Office and documents
        "phishing_macro_document_suspected": ["endpoint.office_macro_scan"],
        "office_document_malware_alert": ["endpoint.office_macro_scan"],
        "user_file_scan_requested": ["endpoint.office_macro_scan"],
        "maldoc_investigation": ["endpoint.office_macro_scan"],
        # ENDPOINT — DLL/COM hijack
        "dll_hijacking_suspected": ["endpoint.dll_hijack_detector"],
        "side_loading_attack_suspected": [
            "endpoint.dll_hijack_detector",
            "endpoint.process_modules",
        ],
        "com_hijacking_suspected": ["endpoint.com_hijack_detector"],
        "uac_bypass_suspected": [
            "endpoint.com_hijack_detector",
            "endpoint.token_privilege_inspect",
        ],
        # ENDPOINT — token and privilege
        "token_impersonation_detected": ["endpoint.token_privilege_inspect"],
        "process_injection_suspected": [
            "endpoint.token_privilege_inspect",
            "endpoint.process_injection_scan",
        ],
        # ENDPOINT — registry and services
        "registry_forensics_requested": ["endpoint.registry_query"],
        "malware_registry_artifact_hunt": ["endpoint.registry_query"],
        "ioc_registry_key_check": ["endpoint.registry_query"],
        "service_inventory_requested": [
            "endpoint.services_status",
            "endpoint.wmic_query",
        ],
        # ENDPOINT — LSA and credential providers
        "lsa_tampering_suspected": [
            "endpoint.lsa_provider_audit",
            "endpoint.lsass_access_indicators",
        ],
        # ENDPOINT — network proxy/certs
        "proxy_misconfiguration_suspected": ["endpoint.network_proxy_config"],
        "c2_via_proxy_suspected": [
            "endpoint.network_proxy_config",
            "endpoint.active_connections",
        ],
        "network_configuration_audit": [
            "endpoint.network_proxy_config",
            "net.route_table",
        ],
        "tls_interception_suspected": [
            "endpoint.certificate_store_audit",
            "endpoint.network_proxy_config",
        ],
        "rogue_ca_certificate_detected": ["endpoint.certificate_store_audit"],
        "https_traffic_decryption_suspected": ["endpoint.certificate_store_audit"],
        # ENDPOINT — AD recon
        "ad_enumeration_suspected": [
            "endpoint.ad_recon_indicators",
            "ad.audit_privileged_group_membership",
        ],
        "bloodhound_activity_detected": ["endpoint.ad_recon_indicators"],
        "ldap_reconnaissance_alert": ["endpoint.ad_recon_indicators"],
        "domain_recon_activity": ["endpoint.ad_recon_indicators"],
        # ENDPOINT — software and patches
        "software_inventory_requested": ["endpoint.installed_software"],
        "unauthorized_software_detected": ["endpoint.installed_software"],
        "vulnerability_assessment_requested": [
            "endpoint.installed_software",
            "endpoint.wmic_query",
        ],
        "patch_level_investigation": ["endpoint.wmic_query"],
        # ENDPOINT — events
        "event_log_investigation_requested": ["endpoint.event_log_extraction"],
        "post_compromise_forensics_events": [
            "endpoint.event_log_extraction",
            "endpoint.lateral_movement_artifacts",
        ],
        "security_event_analysis": ["endpoint.event_log_extraction"],
        "incident_timeline_reconstruction": [
            "endpoint.event_log_extraction",
            "endpoint.lateral_movement_artifacts",
            "endpoint.prefetch_analysis",
        ],
    }
    DEFAULT_PRIORITY_BY_RISK = {
        "LOW": "MEDIUM",
        "MEDIUM": "HIGH",
        "HIGH": "HIGH",
    }

    def __init__(self, config=None):
        self.config = config or {}
        self.dynamic_tools_file = self._get_dynamic_tools_file()

    def export(self, group_id=None):
        tools = self._all_tools()
        exported = []
        for tool in tools:
            if self._is_windows_only(tool["action"]) and os.name != "nt":
                continue
            tool["group_id"] = group_id
            tool["supported_on"] = (
                "windows" if self._is_windows_only(
                    tool["action"]) else "cross_platform"
            )
            exported.append(tool)
        return {
            "catalog_version": self.VERSION,
            "group_id": group_id,
            "tools": exported,
            "trigger_map": self._build_trigger_map(exported),
        }

    def get_executable_count(self):
        return len(
            [
                x
                for x in self._all_tools()
                if x["execution_mode"] == "executable"
                and (os.name == "nt" or not self._is_windows_only(x["action"]))
            ]
        )

    def get_tool(self, tool_id):
        for tool in self._all_tools():
            if tool["tool_id"] == tool_id:
                return copy.deepcopy(tool)
        return None

    def build_trigger_plan(
        self, trigger, group_id, case_id=None, include_trigger_only=False
    ):
        tool_ids = self._build_trigger_map().get(trigger, [])
        plan = []
        for rank, tool_id in enumerate(tool_ids, start=1):
            tool = self.get_tool(tool_id)
            if not tool:
                continue
            if tool["execution_mode"] == "trigger_only" and not include_trigger_only:
                continue
            plan.append(
                self._build_task_template(
                    tool=tool,
                    group_id=group_id,
                    case_id=case_id,
                    rank=rank,
                    trigger=trigger,
                )
            )
        return {
            "catalog_version": self.VERSION,
            "group_id": group_id,
            "trigger": trigger,
            "tasks": plan,
        }

    def _build_task_template(self, tool, group_id, case_id, rank, trigger):
        risk = str(tool.get("risk", "LOW")).upper()
        priority = self.DEFAULT_PRIORITY_BY_RISK.get(risk, "MEDIUM")
        action = tool["action"]
        category = tool["category"]
        parameters = copy.deepcopy(tool.get("parameters_schema", {}))
        return {
            "rank": rank,
            "tool_id": tool["tool_id"],
            "name": tool["name"],
            "reasoning": "Mapped from trigger '%s' based on risk '%s' and category '%s'."
            % (
                trigger,
                risk,
                category,
            ),
            "task_template": {
                "task_id": "GENERATE_UUID",
                "group_id": group_id,
                "case_id": case_id or "SET_CASE_ID",
                "category": category,
                "action": action,
                "parameters": parameters,
                "requires_approval": bool(tool["requires_approval"]),
                "timeout": 60,
                "priority": priority,
            },
        }

    def _is_windows_only(self, action):
        windows_only = {
            # --- original entries ---
            "smb_sessions",
            "smb_share_query",
            "reset_password",
            "disable_user",
            "kill_process",
            "rpc_query",
            "ad_replication_drift_probe",
            "gpo_startup_script_view",
            "legacy_protocol_exposure_map",
            "memory_suspect_modules",
            "living_off_land_detector",
            "remote_process_snapshot",
            "remote_process_snapshot_by_name",
            "remote_file_system_list",
            "remote_file_collect",
            "registry_read",
            "list_drives",
            "terminate_task",
            "process_snapshot_to_disk",
            "event_log_enriched",
            "list_event_log_channels",
            "remote_wmic_query",
            "remote_command_execute",
            "remote_registry_query",
            "remote_config_update",
            "remote_service_restart",
            "remote_process_restart",
            "register_windows_service",
            "unregister_windows_service",
            "windows_service_status",
            "restart_windows_service",
            # --- AD actions (Windows-only: net user / net localgroup) ---
            "get_user_details",
            "enumerate_group_membership",
            "disable_account",
            "enable_account",
            "retrieve_last_logon",
            "audit_privileged_group_membership",
            # reset_password already listed above
            # --- CONTAINMENT actions (Windows-only or primary Windows path) ---
            "logoff_user",
            "stop_service",
            "add_firewall_block_rule",
            "host_isolation",
            # kill_process already listed above
            # disable_user already listed above
            # --- ENDPOINT forensics: Windows-only ---
            "running_processes",
            "logged_in_users",
            "network_connections",
            "installed_software",
            "services_status",
            "scheduled_tasks",
            "scheduled_task_deep",
            "wmic_query",
            "event_log_extraction",
            "dns_query_history",
            "process_modules",
            "process_injection_scan",
            "process_hook_scan",
            "lsass_access_indicators",
            "credential_theft_indicators",
            "lateral_movement_artifacts",
            "memory_ioc_extractor",
            "ransomware_indicators",
            "ntfs_journal_analysis",
            "mft_analyzer",
            "wmi_persistence_deep",
            "shadow_copy_status",
            "usb_media_history",
            "browser_history",
            "prefetch_analysis",
            "run_powershell",
            "kerberos_ticket_inspect",
            "logon_session_enum",
            "token_privilege_inspect",
            "named_pipe_enumeration",
            "amcache_shimcache",
            "autoruns_deep",
            "kernel_driver_scan",
            "dll_hijack_detector",
            "com_hijack_detector",
            "lsa_provider_audit",
            "etw_tamper_detection",
            "wdigest_credential_check",
            "defender_exclusion_audit",
            "powershell_profile_audit",
            "powershell_script_block_history",
            "office_macro_scan",
            "ads_scanner",
            "certificate_store_audit",
            "clipboard_history",
            "file_anomaly_detector",
            "share_open_file_enum",
            "pipe_and_rpc_server_enum",
            "ad_recon_indicators",
            "registry_query",
        }
        return action in windows_only

    def _get_dynamic_tools_file(self):
        configured = self.config.get("hybrid_dynamic_tools_file")
        if isinstance(configured, str) and configured.strip():
            return configured.strip()
        data_root = self.config.get("plugin_data_path", ".")
        return os.path.join(data_root, "hybrid_dynamic_tools.json")

    def _all_tools(self):
        tools = copy.deepcopy(self.TOOLS)
        tools.extend(self._load_dynamic_tools())
        return tools

    def _load_dynamic_tools(self):
        path = self.dynamic_tools_file
        if not path or not os.path.isfile(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as handle:
                payload = json.load(handle)
        except Exception:
            return []
        if not isinstance(payload, list):
            return []
        tools = []
        for item in payload:
            if not isinstance(item, dict):
                continue
            normalized = self._normalize_dynamic_tool(item)
            if normalized:
                tools.append(normalized)
        return tools

    def _normalize_dynamic_tool(self, item):
        required = ("tool_id", "name", "category", "action", "command")
        for key in required:
            if key not in item:
                return None
        if str(item.get("execution_mode", "executable")) != "executable":
            return None
        category = str(item.get("category", "")).upper()
        if category not in ("AD", "ENDPOINT", "NETWORK", "CONTAINMENT"):
            return None
        action = str(item.get("action", "")).strip()
        if not re.match(r"^[a-z0-9_]{2,128}$", action):
            return None
        command = item.get("command")
        if not isinstance(command, list) or len(command) == 0:
            return None
        for part in command:
            if not isinstance(part, str):
                return None
        normalized = {
            "tool_id": str(item["tool_id"]),
            "name": str(item["name"]),
            "category": category,
            "action": action,
            "execution_mode": "executable",
            "requires_approval": bool(item.get("requires_approval", True)),
            "risk": str(item.get("risk", "HIGH")).upper(),
            "description": str(item.get("description", "Dynamic executable tool.")),
            "triggers": item.get("triggers", []),
            "parameters_schema": item.get("parameters_schema", {}),
            "command": command,
        }
        if not isinstance(normalized["triggers"], list):
            normalized["triggers"] = []
        if not isinstance(normalized["parameters_schema"], dict):
            normalized["parameters_schema"] = {}
        return normalized

    def _build_trigger_map(self, tools=None):
        merged = copy.deepcopy(self.TRIGGER_MAP)
        source = tools if isinstance(tools, list) else self._all_tools()
        for tool in source:
            tool_id = tool.get("tool_id")
            triggers = tool.get("triggers", [])
            if not isinstance(tool_id, str) or not isinstance(triggers, list):
                continue
            for trigger in triggers:
                if not isinstance(trigger, str) or not trigger:
                    continue
                merged.setdefault(trigger, [])
                if tool_id not in merged[trigger]:
                    merged[trigger].append(tool_id)
        return merged
