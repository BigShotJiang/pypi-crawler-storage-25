"""Remote deployment of hawk-soard to Windows target hosts.

Provides helpers called by HybridTaskExecutor._deploy_hawk_soard().

Available transports:

  winrm (default on Windows nodes)
    Uses PowerShell Invoke-Command / New-PSSession over WinRM (port 5985/5986).
    Requires PowerShell on the deploying host — suitable for Windows bounce boxes.

  pypsrp (native Python WinRM, no local PowerShell required)
    Uses the pypsrp library to communicate over WinRM (port 5985/5986) from
    Python directly.  Works from Linux hosts where pwsh/PowerShell is not
    installed.  Fallback between the PowerShell-based winrm transport and
    impacket-based transports.

  impacket (default on Linux nodes, or explicit transport="impacket")
    Uses impacket for the full deployment without requiring PowerShell:
      - SMB (port 445) to copy the NSIS installer and write the config file.
      - WMI Win32_Process.Create over DCOM/RPC to execute the installer silently.
      - SCMR (Service Control Manager Remote Protocol) to stop/start the service.
    Works from Linux or any host that cannot run PowerShell Invoke-Command.

  sccm (Microsoft SCCM / MECM application deployment)
    Uses impacket WMI to trigger the SCCM client's Application Deployment
    Evaluation Cycle on the remote host.  The hawk-soard NSIS installer must
    already be published as an Application in SCCM.  This transport triggers
    the evaluation and waits for the deployment to complete.
    Requires: impacket, the target must have the SCCM client installed.

  bits_smb (BITS download + SMB config push + SCMR service restart)
    Uses impacket SMB to push the config file and then creates a BITS transfer
    job via WMI on the remote host.  The remote host downloads the installer
    from ``source_url`` using BITS (Background Intelligent Transfer Service).
    After download the installer is executed via SCMR temp-service and the
    service is restarted.  Useful when direct SMB file copy fails but the
    target can reach the download URL.
    Requires: impacket, target must have BITS service running.

  ivanti (Ivanti Neurons for ITAM cloud API)
    Uses the Ivanti Neurons REST API to trigger a package deployment to the
    target machine.  The hawk-soard installer package must already be
    configured in the Ivanti console.  This transport sends a deployment
    request via the API and polls for completion.
    Requires: ``requests``, Ivanti tenant URL, client ID, and client secret.

Deployment strategies:

  Push (preferred)
    When a local NSIS installer is found on disk (see ``find_local_installer``),
    it is copied to the remote host and then run silently.

  Download (impacket, pypsrp, and bits_smb)
    When no local installer is available, the NSIS installer is fetched from
    ``source_url`` — either pushed via SMB (impacket), downloaded on the
    remote host via PowerShell (pypsrp), or downloaded via BITS on the
    remote host (bits_smb).

In both strategies the config is always (re-)written after install so
credentials are current even on re-deployment.

Config flags required in hawk-soard.cfg to enable this action:
    enable_remote_deploy = true

Optional allowlist (CSV of hostnames/IPs):
    remote_deploy_allowed_targets = host1,host2,...
"""

import base64
import io
import json
import logging
import os
import time
import uuid

from hawkSoar.common.logger import get_logger

logger = get_logger("security.remote_deploy")

HAWK_DOWNLOAD_BASE = "https://downloads.hawkdefense.com/agent"
HAWK_INSTALLER_URL = (
    "https://downloads.hawkdefense.com/agent/hawk-soard-setup-latest.exe"
)
DEFAULT_SERVICE_NAME = "HawkSoard"
DEFAULT_INSTALL_DIR = "C:\\Program Files\\HAWK\\SOAR"
LOCAL_INSTALLER_FILENAME = "hawk-soard-setup.exe"
_SERVICE_DISPLAY_NAME = "Hawk SOAR Agent"
_SERVICE_DESCRIPTION = "Hawk Security Orchestration, Automation and Response daemon"


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------


def find_local_installer(config=None):
    """Return the path of a locally cached NSIS installer, or ``None``.

    Checks (in order):

    1. Directory containing the running binary.  In a PyInstaller-frozen exe
       ``sys.executable`` is the actual exe path; in development ``sys.argv[0]``
       is used.  When hawk-soard is installed via NSIS the installer copies
       itself there (``hawk-soard-setup.exe``) so it is always available for
       push-based remote deployment.
    2. Directory derived from the ``pid_file`` config key (the agent install
       directory as written by the NSIS installer).

    Args:
        config (dict, optional): The local agent's parsed config dict.

    Returns:
        str | None: Absolute path to the installer, or ``None`` when not found.
    """
    import sys

    candidates = []

    # Frozen PyInstaller exe: sys.executable is the real exe path.
    # Development: use sys.argv[0].
    if getattr(sys, "frozen", False):
        base = os.path.dirname(os.path.abspath(sys.executable))
    else:
        base = os.path.dirname(os.path.abspath(sys.argv[0]))
    candidates.append(os.path.join(base, LOCAL_INSTALLER_FILENAME))

    if config:
        pid_file = config.get("pid_file", "")
        if pid_file:
            install_dir = os.path.dirname(os.path.abspath(pid_file))
            candidate = os.path.join(install_dir, LOCAL_INSTALLER_FILENAME)
            if candidate not in candidates:
                candidates.append(candidate)

    for path in candidates:
        if os.path.isfile(path):
            logger.debug("find_local_installer: found %s" % path)
            return path

    return None


def build_config_content(
    hawk_server, access_token, secret_key, install_dir, insecure=False
):
    """Build the hawk-soard.cfg INI file content for a newly deployed agent.

    Args:
        hawk_server:  HAWK platform URL (e.g. https://ir.hawk.io).
        access_token: Service-account access_token for the remote agent.
        secret_key:   Service-account secret_key for the remote agent.
        install_dir:  Install directory on the remote host.
        insecure:     If True, write ``insecure = true``.

    Returns:
        str: INI-formatted config file content.
    """
    idir = install_dir.rstrip("\\")
    return (
        "[SETTINGS]\n"
        "server = {server}\n"
        "access_token = {token}\n"
        "secret_key = {secret}\n"
        "insecure = {insecure}\n"
        "timeout = 30\n"
        "retry = 3\n"
        "pid_file = {idir}\\hawk-soard.pid\n"
        "private_key = {idir}\\hawk-soard.key\n"
        "public_key = {idir}\\hawk-soard.crt\n"
        "client_id_file = {idir}\\hawk-soard-id\n"
        "enforce_signed_hybrid_tasks = true\n"
        "enforce_group_id = true\n"
        "max_task_timeout = 300\n"
        "enable_command_execution = true\n"
        "auto_upgrade = true\n"
        "auto_upgrade_interval = 3600\n"
        "\n"
        "[MANAGER]\n"
        "poll = 1\n"
        "block = 1\n"
        "db_type = sqlite\n"
        "\n"
        "[PLUGINS]\n"
        "data_path = {idir}\\data\n"
    ).format(
        server=hawk_server,
        token=access_token,
        secret=secret_key,
        insecure="true" if insecure else "false",
        idir=idir,
    )


def build_deploy_script(
    target_host,
    user_ref,
    password,
    hawk_server,
    access_token,
    secret_key,
    install_dir=None,
    service_name=None,
    source_url=None,
    source_path=None,
    insecure=False,
    ps_quote_fn=None,
):
    """Build a PowerShell script that deploys hawk-soard to a remote Windows host.

    The returned string is a complete PowerShell command ready to pass to
    ``["powershell", "-NoProfile", "-NonInteractive", "-Command", script]``.

    Both strategies (push and download) unconditionally write the config file
    via PowerShell after the installer runs, then perform a service restart, so
    credentials are always current even when re-deploying to a host that already
    has hawk-soard installed.

    Args:
        target_host:  Remote hostname or IP address (must have WinRM enabled).
        user_ref:     WinRM credential user, e.g. ``"DOMAIN\\\\admin"``.
        password:     WinRM credential password.
        hawk_server:  HAWK platform URL written into the remote agent config.
        access_token: Service-account access_token for the remote agent.
        secret_key:   Service-account secret_key for the remote agent.
        install_dir:  Destination directory on the remote host.
                      Defaults to ``C:\\\\Program Files\\\\HAWK\\\\SOAR``.
        service_name: Windows service name.  Defaults to ``HawkSoard``.
        source_url:   URL the remote host downloads the hawk-soard package from.
                      Only used when ``source_path`` is not provided.
                      Defaults to the HAWK download server URL.
        source_path:  Local filesystem path to the NSIS installer on the
                      deploying host.  When provided the file is pushed to the
                      remote host via ``Copy-Item -ToSession`` (preferred).
        insecure:     Write ``insecure = true`` in the remote agent config.
        ps_quote_fn:  Optional callable ``(str) -> str`` for PowerShell string
                      escaping.  Uses the built-in single-quote escaper by default.

    Returns:
        str: Complete PowerShell command.
    """
    q = ps_quote_fn or _ps_quote
    idir = (install_dir or DEFAULT_INSTALL_DIR).rstrip("\\")
    svc = service_name or DEFAULT_SERVICE_NAME

    # Always build cfg_b64 for both strategies.  The NSIS installer has an
    # IfFileExists guard that skips config-writing when a prior config exists,
    # so we always write the config via PowerShell afterwards to ensure
    # credentials are current on re-deployment.
    cfg_text = build_config_content(
        hawk_server, access_token, secret_key, idir, insecure
    )
    cfg_b64 = base64.b64encode(cfg_text.encode("utf-8")).decode("ascii")

    if source_path and os.path.isfile(source_path):
        logger.info(
            "build_deploy_script: push strategy — local installer %s -> %s"
            % (source_path, target_host)
        )
        return _build_push_script(
            target_host,
            user_ref,
            password,
            access_token,
            secret_key,
            idir,
            svc,
            source_path,
            cfg_b64,
            q,
        )

    if not source_url:
        source_url = HAWK_INSTALLER_URL

    logger.info(
        "build_deploy_script: download strategy — %s -> %s" % (
            source_url, target_host)
    )
    return _build_url_script(
        target_host,
        user_ref,
        password,
        access_token,
        secret_key,
        idir,
        svc,
        source_url,
        cfg_b64,
        q,
    )


def build_verify_script(
    target_host, user_ref, password, service_name=None, ps_quote_fn=None
):
    """Build a lightweight PowerShell script that queries the remote service status.

    Returns:
        str: PowerShell command that emits a JSON service-status object.
    """
    q = ps_quote_fn or _ps_quote
    svc = service_name or DEFAULT_SERVICE_NAME

    remote_block = (
        "$svcName='%s';"
        '$s=Get-CimInstance Win32_Service -Filter ("Name=\'"+ $svcName +"\'") -ErrorAction SilentlyContinue;'
        'if(-not $s){Write-Output \'{"status":"NotFound","running":false}\';exit 0;};'
        "[PSCustomObject]@{"
        "service_name=$s.Name;status=$s.State;pid=$s.ProcessId;"
        "start_mode=$s.StartMode;running=($s.State -eq 'Running')"
        "}|ConvertTo-Json -Depth 2;"
    ) % q(svc)

    return (
        "$credSec=ConvertTo-SecureString '%s' -AsPlainText -Force;"
        "$cred=New-Object System.Management.Automation.PSCredential('%s',$credSec);"
        "Invoke-Command -ComputerName '%s' -Credential $cred -ScriptBlock {%s};"
    ) % (
        q(password),
        q(user_ref),
        q(target_host),
        remote_block,
    )


# ---------------------------------------------------------------------------
# Impacket transport (Linux-compatible, no PowerShell required)
# ---------------------------------------------------------------------------


def deploy_via_impacket(
    target_host,
    username,
    password,
    domain,
    hawk_server,
    access_token,
    secret_key,
    install_dir=None,
    service_name=None,
    source_path=None,
    source_url=None,
    insecure=False,
):
    """Deploy hawk-soard to a remote Windows host using impacket (no PowerShell).

    Transport path:
      1. SMB (port 445) — copy the NSIS installer to ADMIN$\\Temp\\.
      2. WMI Win32_Process.Create over DCOM — run the installer silently.
      3. SMB — write hawk-soard.cfg to the install directory on C$.
      4. SCMR — stop (if running) then start the HawkSoard service.

    When ``source_path`` is not supplied (or not found on disk) and
    ``source_url`` is provided, the installer is downloaded to a local temp
    file first and then pushed via SMB.

    Args:
        target_host:  Hostname or IP of the remote Windows host.
        username:     Account username (without domain prefix).
        password:     Account password.
        domain:       Active Directory domain (e.g. ``"CORP"``).
        hawk_server:  HAWK platform URL for the remote agent config.
        access_token: Service-account access_token for the remote agent.
        secret_key:   Service-account secret_key for the remote agent.
        install_dir:  Install directory on the remote host.
        service_name: Windows service name (default: ``HawkSoard``).
        source_path:  Local path to the NSIS installer to push via SMB.
        source_url:   Fallback download URL when no local installer is found.
        insecure:     Write ``insecure = true`` in the remote agent config.

    Returns:
        dict: ``{deployed, target_host, status, service_name, install_dir,
                 exe_exists, config_written, error}``
    """
    try:
        from impacket.smbconnection import SMBConnection
        from impacket.dcerpc.v5 import transport as dcerpc_transport, scmr
        from impacket.dcerpc.v5.dtypes import NULL

        try:
            from impacket.dcerpc.v5.dcom import wmi as impacket_wmi  # impacket >= 0.11
        except ImportError:
            from impacket.dcerpc.v5 import wmi as impacket_wmi  # impacket < 0.11
    except ImportError as exc:
        raise RuntimeError(
            "impacket is required for Linux-based remote deployment. "
            "Install it with: pip install impacket"
        ) from exc

    idir = (install_dir or DEFAULT_INSTALL_DIR).rstrip("\\")
    svc = service_name or DEFAULT_SERVICE_NAME
    cfg_text = build_config_content(
        hawk_server, access_token, secret_key, idir, insecure
    )

    # Resolve installer: local path first, then download to a temp file.
    if not source_path or not os.path.isfile(source_path):
        if source_url:
            source_path = _download_installer(source_url)
        else:
            source_path = _download_installer(HAWK_INSTALLER_URL)

    if not os.path.isfile(source_path):
        raise FileNotFoundError(
            "No installer found at %s and download failed." % source_path
        )

    logger.info(
        "deploy_via_impacket: connecting to %s as %s\\%s", target_host, domain, username
    )

    # ── 1. SMB connect ──────────────────────────────────────────────────────
    smb = SMBConnection(target_host, target_host, sess_port=445)
    smb.login(username, password, domain)
    logger.info("deploy_via_impacket: SMB connected to %s", target_host)

    # ── 2. Copy installer to ADMIN$\Temp\ ───────────────────────────────────
    remote_tmp_rel = "Temp\\%s" % LOCAL_INSTALLER_FILENAME  # relative to ADMIN$
    # absolute on C:
    remote_tmp_unc = "\\Windows\\Temp\\%s" % LOCAL_INSTALLER_FILENAME
    with open(source_path, "rb") as fh:
        smb.putFile("ADMIN$", remote_tmp_rel, fh.read)
    logger.info(
        "deploy_via_impacket: uploaded installer to \\\\%s\\ADMIN$\\%s",
        target_host,
        remote_tmp_rel,
    )

    # ── 3. Ensure install dir exists on C$ ──────────────────────────────────
    # Convert absolute Windows path (C:\...) to C$-relative path for SMB.
    c_rel = _abs_to_share_rel(idir)
    data_rel = c_rel + "\\data"
    _smb_makedirs(smb, "C$", c_rel)
    _smb_makedirs(smb, "C$", data_rel)

    # ── 4. Run installer via WMI Win32_Process.Create ───────────────────────
    nsis_cmd = '"%s" /S /ACCESS_TOKEN=%s /SECRET_KEY=%s /D=%s' % (
        remote_tmp_unc,
        access_token,
        secret_key,
        idir,
    )
    _wmi_create_process(target_host, username, password, domain, nsis_cmd)
    logger.info("deploy_via_impacket: installer launched via WMI, waiting 15s")
    time.sleep(15)  # NSIS silent install typically completes in <10s

    # ── 5. Write config via SMB (always overwrite to keep creds current) ────
    cfg_rel = c_rel + "\\hawk-soard.cfg"
    cfg_bytes = cfg_text.encode("utf-8")
    smb.putFile("C$", cfg_rel, io.BytesIO(cfg_bytes).read)
    logger.info("deploy_via_impacket: wrote config to C$\\%s", cfg_rel)

    # ── 6. Stop/start service via SCMR ──────────────────────────────────────
    svc_status = _scmr_restart_service(
        target_host, username, password, domain, svc)
    logger.info(
        "deploy_via_impacket: service %s state=%s pid=%s",
        svc,
        svc_status.get("status"),
        svc_status.get("pid"),
    )

    smb.logoff()

    return {
        "deployed": svc_status.get("running", False),
        "target_host": target_host,
        "status": svc_status.get("status", "Unknown"),
        "service_name": svc,
        "install_dir": idir,
        "exe_exists": True,  # installer ran; assume exe present
        "config_written": True,
        "error": None
        if svc_status.get("running")
        else "Service did not reach Running state",
    }


def verify_via_impacket(target_host, username, password, domain, service_name=None):
    """Query the hawk-soard service status on a remote Windows host via SCMR.

    Args:
        target_host:  Hostname or IP of the remote Windows host.
        username:     Account username.
        password:     Account password.
        domain:       Active Directory domain.
        service_name: Windows service name (default: ``HawkSoard``).

    Returns:
        dict: ``{target_host, service_name, status, running, pid, start_mode}``
    """
    svc = service_name or DEFAULT_SERVICE_NAME
    try:
        result = _scmr_query_service(
            target_host, username, password, domain, svc)
    except Exception as exc:
        return {
            "target_host": target_host,
            "service_name": svc,
            "status": "Error",
            "running": False,
            "error": str(exc),
        }
    result["target_host"] = target_host
    return result


def deploy_via_pip_impacket(
    target_host,
    username,
    password,
    domain,
    hawk_server,
    access_token,
    secret_key,
    install_dir=None,
    service_name=None,
    insecure=False,
    package="hawk-soard",
    pip_timeout=120,
):
    """Deploy hawk-soard to a remote Windows host using pip (no NSIS installer).

    Requires Python + pip already present on the remote Windows host.

    Steps (all executed from a Linux deploying node via impacket):
      1. SMB: create install dir on C$.
      2. SMB: write hawk-soard.cfg with supplied credentials.
      3. WMI: ``py -m pip install --upgrade <package>``
      4. Sleep *pip_timeout* seconds for pip to complete.
      5. WMI: ``hawk-soard -install -c <cfg_path> --no-start``
      6. SCMR: start the service.

    Returns:
        dict: ``{deployed, target_host, status, service_name, install_dir,
                 config_written, error}``
    """
    try:
        from impacket.smbconnection import SMBConnection
        from impacket.dcerpc.v5 import transport as dcerpc_transport, scmr
        from impacket.dcerpc.v5.dtypes import NULL

        try:
            from impacket.dcerpc.v5.dcom import wmi as impacket_wmi
        except ImportError:
            from impacket.dcerpc.v5 import wmi as impacket_wmi
    except ImportError as exc:
        raise RuntimeError(
            "impacket is required for Linux-based remote deployment. "
            "Install it with: pip install impacket"
        ) from exc

    idir = (install_dir or DEFAULT_INSTALL_DIR).rstrip("\\")
    svc = service_name or DEFAULT_SERVICE_NAME
    cfg_text = build_config_content(
        hawk_server, access_token, secret_key, idir, insecure
    )

    logger.info(
        "deploy_via_pip: connecting to %s as %s\\%s", target_host, domain, username
    )

    smb = SMBConnection(target_host, target_host, sess_port=445)
    smb.login(username, password, domain)
    logger.info("deploy_via_pip: SMB connected to %s", target_host)

    c_rel = _abs_to_share_rel(idir)
    data_rel = c_rel + "\\data"
    _smb_makedirs(smb, "C$", c_rel)
    _smb_makedirs(smb, "C$", data_rel)

    cfg_rel = c_rel + "\\hawk-soard.cfg"
    cfg_bytes = cfg_text.encode("utf-8")
    smb.putFile("C$", cfg_rel, io.BytesIO(cfg_bytes).read)
    logger.info("deploy_via_pip: wrote config to C$\\%s", cfg_rel)
    smb.logoff()

    cfg_abs = idir + "\\hawk-soard.cfg"

    pip_cmd = "py -m pip install --upgrade %s" % package
    logger.info("deploy_via_pip: running pip via WMI: %s", pip_cmd)
    _wmi_create_process(target_host, username, password, domain, pip_cmd)
    logger.info("deploy_via_pip: waiting %ss for pip to complete", pip_timeout)
    time.sleep(pip_timeout)

    install_cmd = 'hawk-soard -install -c "%s" --no-start' % cfg_abs
    logger.info(
        "deploy_via_pip: running hawk-soard -install via WMI: %s", install_cmd)
    _wmi_create_process(target_host, username, password, domain, install_cmd)
    time.sleep(5)

    svc_status = _scmr_restart_service(
        target_host, username, password, domain, svc)
    logger.info(
        "deploy_via_pip: service %s state=%s pid=%s",
        svc,
        svc_status.get("status"),
        svc_status.get("pid"),
    )

    return {
        "deployed": svc_status.get("running", False),
        "target_host": target_host,
        "status": svc_status.get("status", "Unknown"),
        "service_name": svc,
        "install_dir": idir,
        "config_written": True,
        "error": None
        if svc_status.get("running")
        else "Service did not reach Running state",
    }


def deploy_via_service_impacket(
    target_host,
    username,
    password,
    domain,
    hawk_server,
    access_token,
    secret_key,
    install_dir=None,
    service_name=None,
    source_path=None,
    source_url=None,
    insecure=False,
):
    """Deploy hawk-soard via SMB upload + temporary SCM service execution.

    This path avoids WMI/DCOM entirely. It is useful when SMB/SCMR access works
    but Win32_Process.Create is blocked or unreliable.
    """
    try:
        from impacket.smbconnection import SMBConnection
    except ImportError as exc:
        raise RuntimeError(
            "impacket is required for Linux-based remote deployment. "
            "Install it with: pip install impacket"
        ) from exc

    idir = (install_dir or DEFAULT_INSTALL_DIR).rstrip("\\")
    svc = service_name or DEFAULT_SERVICE_NAME
    cfg_text = build_config_content(
        hawk_server, access_token, secret_key, idir, insecure
    )

    if not source_path or not os.path.isfile(source_path):
        source_path = _download_installer(source_url or HAWK_INSTALLER_URL)
    if not os.path.isfile(source_path):
        raise FileNotFoundError(
            "No installer found at %s and download failed." % source_path
        )

    logger.info(
        "deploy_via_service_impacket: connecting to %s as %s\\%s",
        target_host,
        domain,
        username,
    )

    smb = SMBConnection(target_host, target_host, sess_port=445)
    smb.login(username, password, domain)
    logger.info("deploy_via_service_impacket: SMB connected to %s", target_host)

    remote_tmp_rel = "Temp\\%s" % LOCAL_INSTALLER_FILENAME
    remote_tmp_abs = "C:\\Windows\\Temp\\%s" % LOCAL_INSTALLER_FILENAME
    with open(source_path, "rb") as fh:
        smb.putFile("ADMIN$", remote_tmp_rel, fh.read)
    logger.info(
        "deploy_via_service_impacket: uploaded installer to \\\\%s\\ADMIN$\\%s",
        target_host,
        remote_tmp_rel,
    )

    c_rel = _abs_to_share_rel(idir)
    data_rel = c_rel + "\\data"
    _smb_makedirs(smb, "C$", c_rel)
    _smb_makedirs(smb, "C$", data_rel)

    nsis_cmd = '"%s" /S /ACCESS_TOKEN=%s /SECRET_KEY=%s /D=%s' % (
        remote_tmp_abs,
        access_token,
        secret_key,
        idir,
    )
    _scmr_execute_via_temp_service(
        smb=smb,
        target_host=target_host,
        username=username,
        password=password,
        domain=domain,
        command_line=nsis_cmd,
        wait_seconds=20,
    )

    cfg_rel = c_rel + "\\hawk-soard.cfg"
    smb.putFile("C$", cfg_rel, io.BytesIO(cfg_text.encode("utf-8")).read)
    logger.info("deploy_via_service_impacket: wrote config to C$\\%s", cfg_rel)

    svc_status = _scmr_restart_service(
        target_host, username, password, domain, svc)
    smb.logoff()

    return {
        "deployed": svc_status.get("running", False),
        "target_host": target_host,
        "status": svc_status.get("status", "Unknown"),
        "service_name": svc,
        "install_dir": idir,
        "config_written": True,
        "error": None
        if svc_status.get("running")
        else "Service did not reach Running state",
    }


def deploy_via_pip_service_impacket(
    target_host,
    username,
    password,
    domain,
    hawk_server,
    access_token,
    secret_key,
    install_dir=None,
    service_name=None,
    insecure=False,
    package="hawk-soard",
    pip_timeout=120,
):
    """Deploy hawk-soard via pip + temporary SCM service execution.

    This path avoids WMI/DCOM and the NSIS installer, assuming Python/pip
    already exists on the remote Windows host.
    """
    try:
        from impacket.smbconnection import SMBConnection
    except ImportError as exc:
        raise RuntimeError(
            "impacket is required for Linux-based remote deployment. "
            "Install it with: pip install impacket"
        ) from exc

    idir = (install_dir or DEFAULT_INSTALL_DIR).rstrip("\\")
    svc = service_name or DEFAULT_SERVICE_NAME
    cfg_text = build_config_content(
        hawk_server, access_token, secret_key, idir, insecure
    )

    logger.info(
        "deploy_via_pip_service_impacket: connecting to %s as %s\\%s",
        target_host,
        domain,
        username,
    )

    smb = SMBConnection(target_host, target_host, sess_port=445)
    smb.login(username, password, domain)

    c_rel = _abs_to_share_rel(idir)
    data_rel = c_rel + "\\data"
    _smb_makedirs(smb, "C$", c_rel)
    _smb_makedirs(smb, "C$", data_rel)

    cfg_rel = c_rel + "\\hawk-soard.cfg"
    smb.putFile("C$", cfg_rel, io.BytesIO(cfg_text.encode("utf-8")).read)
    logger.info(
        "deploy_via_pip_service_impacket: wrote config to C$\\%s", cfg_rel)

    cfg_abs = idir + "\\hawk-soard.cfg"
    _scmr_execute_via_temp_service(
        smb=smb,
        target_host=target_host,
        username=username,
        password=password,
        domain=domain,
        command_line="py -m pip install --upgrade %s" % package,
        wait_seconds=pip_timeout,
    )
    _scmr_execute_via_temp_service(
        smb=smb,
        target_host=target_host,
        username=username,
        password=password,
        domain=domain,
        command_line='hawk-soard -install -c "%s" --no-start' % cfg_abs,
        wait_seconds=10,
    )

    svc_status = _scmr_restart_service(
        target_host, username, password, domain, svc)
    smb.logoff()

    return {
        "deployed": svc_status.get("running", False),
        "target_host": target_host,
        "status": svc_status.get("status", "Unknown"),
        "service_name": svc,
        "install_dir": idir,
        "config_written": True,
        "error": None
        if svc_status.get("running")
        else "Service did not reach Running state",
    }


def deploy_via_ssh(
    target_host,
    username,
    password,
    hawk_server,
    access_token,
    secret_key,
    install_dir=None,
    service_name=None,
    source_path=None,
    source_url=None,
    insecure=False,
    port=22,
):
    """Deploy hawk-soard via Windows OpenSSH + PowerShell."""
    try:
        import paramiko
    except ImportError as exc:
        raise RuntimeError(
            "paramiko is required for ssh-based remote deployment. "
            "Install it with: pip install paramiko"
        ) from exc

    idir = (install_dir or DEFAULT_INSTALL_DIR).rstrip("\\")
    svc = service_name or DEFAULT_SERVICE_NAME
    cfg_text = build_config_content(
        hawk_server, access_token, secret_key, idir, insecure
    )
    cfg_b64 = base64.b64encode(cfg_text.encode("utf-8")).decode("ascii")
    remote_installer = "C:\\Windows\\Temp\\%s" % LOCAL_INSTALLER_FILENAME

    script = _build_local_windows_deploy_script(
        install_dir=idir,
        service_name=svc,
        source_url=source_url or HAWK_INSTALLER_URL,
        cfg_b64=cfg_b64,
        installer_path=remote_installer
        if source_path and os.path.isfile(source_path)
        else None,
    )
    encoded_script = _to_powershell_encoded_command(script)

    logger.info(
        "deploy_via_ssh: connecting to %s:%s as %s", target_host, port, username
    )
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        hostname=target_host,
        port=int(port),
        username=username,
        password=password,
        look_for_keys=False,
        allow_agent=False,
        timeout=20,
    )

    try:
        if source_path and os.path.isfile(source_path):
            sftp = client.open_sftp()
            try:
                _sftp_put_windows_file(sftp, remote_installer, source_path)
            finally:
                sftp.close()

        stdin, stdout, stderr = client.exec_command(
            "powershell -NoProfile -NonInteractive -EncodedCommand %s" % encoded_script
        )
        del stdin
        out = stdout.read().decode("utf-8", "replace")
        err = stderr.read().decode("utf-8", "replace")
    finally:
        client.close()

    parsed = None
    if out.strip():
        try:
            parsed = json.loads(out.strip())
        except Exception:
            parsed = None

    if not isinstance(parsed, dict):
        raise RuntimeError(
            err or out or "ssh deployment did not return JSON output.")

    result = {
        "target_host": target_host,
        "transport": "ssh",
        "stdout": out,
        "stderr": err,
    }
    result.update(parsed)
    return result


def deploy_via_pypsrp(
    target_host,
    username,
    password,
    domain,
    hawk_server,
    access_token,
    secret_key,
    install_dir=None,
    service_name=None,
    source_path=None,
    source_url=None,
    insecure=False,
    port=None,
):
    """Deploy hawk-soard to a remote Windows host using pypsrp (native Python WinRM).

    This transport uses the pypsrp library to communicate over WinRM without
    requiring PowerShell on the deploying host.  It works from Linux nodes where
    pwsh/PowerShell is not installed.

    Steps:
      1. Connect to the remote host via WinRM (port 5985/5986).
      2. If a local NSIS installer is available, push it via pypsrp file copy.
      3. Execute the deployment PowerShell script on the remote host.
      4. Parse the JSON status output.

    Args:
        target_host:  Hostname or IP of the remote Windows host.
        username:     Account username (without domain prefix).
        password:     Account password.
        domain:       Active Directory domain (e.g. ``"CORP"``).
        hawk_server:  HAWK platform URL for the remote agent config.
        access_token: Service-account access_token for the remote agent.
        secret_key:   Service-account secret_key for the remote agent.
        install_dir:  Install directory on the remote host.
        service_name: Windows service name (default: ``HawkSoard``).
        source_path:  Local path to the NSIS installer to push.
        source_url:   Fallback download URL when no local installer is found.
        insecure:     If True, connect without SSL/cert verification.
        port:         WinRM port (default: 5985 for HTTP, 5986 for HTTPS).

    Returns:
        dict: ``{deployed, target_host, status, service_name, install_dir,
                 exe_exists, config_written, error, transport}``
    """
    try:
        from pypsrp.client import Client
    except ImportError as exc:
        raise RuntimeError(
            "pypsrp is required for native-Python WinRM deployment. "
            "Install it with: pip install pypsrp"
        ) from exc

    idir = (install_dir or DEFAULT_INSTALL_DIR).rstrip("\\")
    svc = service_name or DEFAULT_SERVICE_NAME
    cfg_text = build_config_content(
        hawk_server, access_token, secret_key, idir, insecure
    )
    cfg_b64 = base64.b64encode(cfg_text.encode("utf-8")).decode("ascii")

    source_url = source_url or HAWK_INSTALLER_URL
    remote_installer = "C:\\Windows\\Temp\\%s" % LOCAL_INSTALLER_FILENAME

    use_ssl = bool(port == 5986) if port else False
    effective_port = port or (5986 if use_ssl else 5985)

    logger.info(
        "deploy_via_pypsrp: connecting to %s:%s as %s\\%s (ssl=%s)",
        target_host,
        effective_port,
        domain,
        username,
        use_ssl,
    )

    push_file = None
    if source_path and os.path.isfile(source_path):
        push_file = remote_installer
        logger.info(
            "deploy_via_pypsrp: push strategy — local installer %s -> %s",
            source_path,
            remote_installer,
        )
    else:
        logger.info(
            "deploy_via_pypsrp: download strategy — %s -> %s",
            source_url,
            target_host,
        )

    script = _build_local_windows_deploy_script(
        install_dir=idir,
        service_name=svc,
        source_url=source_url,
        cfg_b64=cfg_b64,
        installer_path=push_file,
    )

    client_kw = {
        "server": target_host,
        "username": username,
        "password": password,
        "ssl": use_ssl,
        "port": effective_port,
        "auth": "ntlm",
        "cert_validation": not insecure,
    }
    if domain:
        client_kw["username"] = "%s\\%s" % (domain, username)

    client = Client(**client_kw)
    try:
        if push_file:
            try:
                client.copy(source_path, remote_installer)
                logger.info(
                    "deploy_via_pypsrp: pushed installer to %s", remote_installer
                )
            except Exception as copy_exc:
                logger.warning(
                    "deploy_via_pypsrp: file copy failed: %s", copy_exc)

        output, errors = client.execute_ps(script)
    except Exception as conn_exc:
        raise RuntimeError(
            "pypsrp WinRM deployment failed: %s" % conn_exc
        ) from conn_exc

    parsed = None
    if output and output.strip():
        try:
            parsed = json.loads(output.strip())
        except (json.JSONDecodeError, ValueError):
            pass

    if not isinstance(parsed, dict):
        error_detail = ""
        if errors:
            error_detail = "; ".join(str(e) for e in errors)
        raise RuntimeError(
            error_detail or output or "pypsrp deployment did not return JSON output."
        )

    parsed["target_host"] = target_host
    parsed["transport"] = "pypsrp"
    return parsed


def verify_via_pypsrp(
    target_host,
    username,
    password,
    domain,
    service_name=None,
    port=None,
    insecure=False,
):
    """Query the hawk-soard service status on a remote Windows host via pypsrp.

    Args:
        target_host:  Hostname or IP of the remote Windows host.
        username:     Account username.
        password:     Account password.
        domain:       Active Directory domain.
        service_name: Windows service name (default: ``HawkSoard``).
        port:         WinRM port (default: 5985 for HTTP, 5986 for HTTPS).
        insecure:     If True, connect without SSL/cert verification.

    Returns:
        dict: ``{target_host, service_name, status, running, pid, start_mode}``
    """
    try:
        from pypsrp.client import Client
    except ImportError as exc:
        raise RuntimeError(
            "pypsrp is required for native-Python WinRM verification. "
            "Install it with: pip install pypsrp"
        ) from exc

    svc = service_name or DEFAULT_SERVICE_NAME

    use_ssl = bool(port == 5986) if port else False
    effective_port = port or (5986 if use_ssl else 5985)

    client_kw = {
        "server": target_host,
        "username": username,
        "password": password,
        "ssl": use_ssl,
        "port": effective_port,
        "auth": "ntlm",
        "cert_validation": not insecure,
    }
    if domain:
        client_kw["username"] = "%s\\%s" % (domain, username)

    query_script = (
        "$s = Get-CimInstance Win32_Service -Filter \"Name='%s'\" "
        "-ErrorAction SilentlyContinue; "
        "if (-not $s) { "
        "@{status='NotFound';running=$false;service_name='%s';pid=0;start_mode='Unknown'} "
        "| ConvertTo-Json -Depth 2 } else { "
        "@{service_name=$s.Name;status=$s.State;pid=$s.ProcessId;"
        "start_mode=$s.StartMode;running=($s.State -eq 'Running')} "
        "| ConvertTo-Json -Depth 2 }"
    ) % (svc, svc)

    client = Client(**client_kw)
    try:
        output, errors = client.execute_ps(query_script)
    except Exception as exc:
        return {
            "target_host": target_host,
            "service_name": svc,
            "status": "Error",
            "running": False,
            "error": str(exc),
        }

    parsed = None
    if output and output.strip():
        try:
            parsed = json.loads(output.strip())
        except (json.JSONDecodeError, ValueError):
            pass

    if isinstance(parsed, dict):
        parsed["target_host"] = target_host
        return parsed

    return {
        "target_host": target_host,
        "service_name": svc,
        "status": "Error",
        "running": False,
        "error": errors
        and "; ".join(str(e) for e in errors)
        or "verify_via_pypsrp did not return JSON",
    }


# ---------------------------------------------------------------------------
# SCCM / MECM transport (trigger via WMI on the remote SCCM client)
# ---------------------------------------------------------------------------


def deploy_via_sccm(
    target_host,
    username,
    password,
    domain,
    hawk_server,
    access_token,
    secret_key,
    install_dir=None,
    service_name=None,
    source_url=None,
    insecure=False,
    sccm_app_name=None,
    poll_interval=10,
    poll_timeout=300,
):
    """Deploy hawk-soard by triggering an SCCM/MECM application deployment.

    This transport assumes the hawk-soard NSIS installer has already been
    published as an Application in SCCM.  It connects to the remote host
    via impacket WMI, triggers the CCM_Scheduler scheduled action
    ``CCMEvaluateAppPolicy`` to force an application evaluation cycle, and
    then polls the service status via SCMR until the hawk-soard service is
    running or the timeout expires.

    If ``sccm_app_name`` is provided, the function also triggers a targeted
    application install via the ``CCM_Application`` WMI class.

    After the SCCM deployment is triggered, the config file is written via
    SMB to ensure credentials are current.

    Args:
        target_host:  Hostname or IP of the remote Windows host.
        username:     Account username (without domain prefix).
        password:     Account password.
        domain:       Active Directory domain.
        hawk_server:  HAWK platform URL for the remote agent config.
        access_token: Service-account access_token for the remote agent.
        secret_key:   Service-account secret_key for the remote agent.
        install_dir:  Install directory on the remote host.
        service_name: Windows service name (default: ``HawkSoard``).
        source_url:   Not used for SCCM (installer comes from distribution point).
        insecure:     Write ``insecure = true`` in the remote agent config.
        sccm_app_name: Name of the SCCM Application to deploy.  If ``None``,
                       only the machine-wide evaluation cycle is triggered.
        poll_interval: Seconds between status polls (default: 10).
        poll_timeout:  Maximum seconds to wait for the service to start
                       (default: 300).

    Returns:
        dict: ``{deployed, target_host, status, service_name, install_dir,
                 config_written, error, transport}``
    """
    try:
        from impacket.smbconnection import SMBConnection
        from impacket.dcerpc.v5 import transport as dcerpc_transport, scmr
        from impacket.dcerpc.v5.dtypes import NULL
    except ImportError as exc:
        raise RuntimeError(
            "impacket is required for SCCM-based remote deployment. "
            "Install it with: pip install impacket"
        ) from exc

    idir = (install_dir or DEFAULT_INSTALL_DIR).rstrip("\\")
    svc = service_name or DEFAULT_SERVICE_NAME
    cfg_text = build_config_content(
        hawk_server, access_token, secret_key, idir, insecure
    )

    logger.info(
        "deploy_via_sccm: connecting to %s as %s\\%s", target_host, domain, username
    )

    # ── 1. Trigger SCCM evaluation via WMI ──────────────────────────────────
    scheduler_cmd = (
        "powershell -NoProfile -NonInteractive -Command "
        '"Invoke-CimMethod -Namespace root\\ccm -ClassName SMS_Client '
        "-MethodName EvaluateMachinePolicy | Out-Null; "
        "Invoke-CimMethod -Namespace root\\ccm -ClassName SMS_Client "
        "-MethodName TriggerSchedule -Arguments @{sScheduleID='00000000-0000-0000-0000-000000000021'} | Out-Null\""
    )
    if sccm_app_name:
        scheduler_cmd += (
            "; Invoke-CimMethod -Namespace root\\ccm\\SoftwareUpdates "
            "-ClassName CCM_Application -MethodName Install "
            "-Arguments @{Id='%s'; Revision=1; IsMachineTarget=$true} | Out-Null\""
            % sccm_app_name
        )

    try:
        _wmi_create_process(target_host, username,
                            password, domain, scheduler_cmd)
        logger.info(
            "deploy_via_sccm: triggered SCCM evaluation on %s", target_host)
    except Exception as exc:
        raise RuntimeError(
            "deploy_via_sccm: failed to trigger SCCM evaluation: %s" % exc
        ) from exc

    # ── 2. Write config via SMB ──────────────────────────────────────────────
    smb = SMBConnection(target_host, target_host, sess_port=445)
    try:
        smb.login(username, password, domain)
        logger.info("deploy_via_sccm: SMB connected to %s", target_host)

        c_rel = _abs_to_share_rel(idir)
        data_rel = c_rel + "\\data"
        _smb_makedirs(smb, "C$", c_rel)
        _smb_makedirs(smb, "C$", data_rel)

        cfg_rel = c_rel + "\\hawk-soard.cfg"
        cfg_bytes = cfg_text.encode("utf-8")
        smb.putFile("C$", cfg_rel, io.BytesIO(cfg_bytes).read)
        logger.info("deploy_via_sccm: wrote config to C$\\%s", cfg_rel)
    finally:
        try:
            smb.logoff()
        except Exception:
            pass

    # ── 3. Poll for service status via SCMR ─────────────────────────────────
    waited = 0
    svc_status = {"status": "Unknown", "running": False}
    while waited < poll_timeout:
        time.sleep(poll_interval)
        waited += poll_interval
        try:
            svc_status = _scmr_query_service(
                target_host, username, password, domain, svc
            )
            svc_status["target_host"] = target_host
        except Exception:
            pass
        if svc_status.get("running"):
            logger.info(
                "deploy_via_sccm: service %s is running after %ds", svc, waited)
            break
        logger.info(
            "deploy_via_sccm: service %s status=%s, polling (%d/%ds)",
            svc,
            svc_status.get("status"),
            waited,
            poll_timeout,
        )

    return {
        "deployed": svc_status.get("running", False),
        "target_host": target_host,
        "status": svc_status.get("status", "Unknown"),
        "service_name": svc,
        "install_dir": idir,
        "config_written": True,
        "transport": "sccm",
        "error": None
        if svc_status.get("running")
        else "Service did not reach Running state within %ds" % poll_timeout,
    }


def verify_via_sccm(target_host, username, password, domain, service_name=None):
    """Query the hawk-soard service status on a remote Windows host via SCMR.

    This is a thin wrapper around ``verify_via_impacket`` since SCCM uses
    the same impacket SCMR connection for verification.

    Args:
        target_host:  Hostname or IP of the remote Windows host.
        username:     Account username.
        password:     Account password.
        domain:       Active Directory domain.
        service_name: Windows service name (default: ``HawkSoard``).

    Returns:
        dict: ``{target_host, service_name, status, running, pid, start_mode}``
    """
    return verify_via_impacket(target_host, username, password, domain, service_name)


# ---------------------------------------------------------------------------
# BITS + SMB transport (BITS download on remote host + SMB config push)
# ---------------------------------------------------------------------------


def deploy_via_bits_smb(
    target_host,
    username,
    password,
    domain,
    hawk_server,
    access_token,
    secret_key,
    install_dir=None,
    service_name=None,
    source_url=None,
    insecure=False,
    poll_interval=10,
    poll_timeout=600,
):
    """Deploy hawk-soard via BITS transfer on the remote host + SMB for config.

    This transport uses impacket for SMB file copy (config only) and SCMR for
    service control, and triggers a BITS download job via WMI on the remote
    host.  The remote host downloads the installer from ``source_url`` using
    BITS (Background Intelligent Transfer Service), which handles retries and
    throttling automatically.

    Steps:
      1. Connect to the remote host via impacket SMB.
      2. Create install and data directories on C$.
      3. Write the hawk-soard.cfg config file via SMB.
      4. Create a .cmd wrapper script via SMB that starts the BITS job, waits
         for completion, runs the installer silently, and starts the service.
      5. Execute the .cmd wrapper via SCMR temp-service.
      6. Poll SCMR for the service to reach Running state.

    Args:
        target_host:    Hostname or IP of the remote Windows host.
        username:       Account username (without domain prefix).
        password:       Account password.
        domain:         Active Directory domain.
        hawk_server:    HAWK platform URL for the remote agent config.
        access_token:   Service-account access_token for the remote agent.
        secret_key:     Service-account secret_key for the remote agent.
        install_dir:    Install directory on the remote host.
        service_name:   Windows service name (default: ``HawkSoard``).
        source_url:     URL the remote host downloads the installer from.
        insecure:       Write ``insecure = true`` in the remote agent config.
        poll_interval:  Seconds between status polls (default: 10).
        poll_timeout:   Maximum seconds to wait for the service to start
                        (default: 600).

    Returns:
        dict: ``{deployed, target_host, status, service_name, install_dir,
                 config_written, error, transport}``
    """
    try:
        from impacket.smbconnection import SMBConnection
    except ImportError as exc:
        raise RuntimeError(
            "impacket is required for BITS+SMB remote deployment. "
            "Install it with: pip install impacket"
        ) from exc

    idir = (install_dir or DEFAULT_INSTALL_DIR).rstrip("\\")
    svc = service_name or DEFAULT_SERVICE_NAME
    cfg_text = build_config_content(
        hawk_server, access_token, secret_key, idir, insecure
    )
    dl_url = source_url or HAWK_INSTALLER_URL

    logger.info(
        "deploy_via_bits_smb: connecting to %s as %s\\%s", target_host, domain, username
    )

    smb = SMBConnection(target_host, target_host, sess_port=445)
    smb.login(username, password, domain)
    logger.info("deploy_via_bits_smb: SMB connected to %s", target_host)

    try:
        # ── 1. Ensure install dir exists ────────────────────────────────────
        c_rel = _abs_to_share_rel(idir)
        data_rel = c_rel + "\\data"
        _smb_makedirs(smb, "C$", c_rel)
        _smb_makedirs(smb, "C$", data_rel)

        # ── 2. Write config via SMB ─────────────────────────────────────────
        cfg_rel = c_rel + "\\hawk-soard.cfg"
        cfg_bytes = cfg_text.encode("utf-8")
        smb.putFile("C$", cfg_rel, io.BytesIO(cfg_bytes).read)
        logger.info("deploy_via_bits_smb: wrote config to C$\\%s", cfg_rel)

        # ── 3. Create BITS wrapper .cmd ─────────────────────────────────────
        remote_cmd_rel = "Temp\\hawk-soard-bits-deploy.cmd"
        remote_cmd_abs = "C:\\Windows\\Temp\\hawk-soard-bits-deploy.cmd"
        idir_escaped = idir.replace("'", "''")
        svc_escaped = svc.replace("'", "''")
        dl_url_escaped = dl_url.replace("'", "''")

        cmd_script = (
            "@echo off\r\n"
            "bitsadmin.exe /transfer hawksoard /download /priority high "
            '"%s" "C:\\Windows\\Temp\\hawk-soard-setup.exe"\r\n'
            "if errorlevel 1 (\r\n"
            "  echo BITS_DOWNLOAD_FAILED\r\n"
            "  exit /b 1\r\n"
            ")\r\n"
            '"C:\\Windows\\Temp\\hawk-soard-setup.exe" /S /ACCESS_TOKEN=%s /SECRET_KEY=%s /D="%s"\r\n'
            "timeout /t 5 /nobreak >nul\r\n"
            "net stop %s >nul 2>&1\r\n"
            "net start %s\r\n"
        ) % (
            dl_url_escaped,
            access_token,
            secret_key,
            idir_escaped,
            svc_escaped,
            svc_escaped,
        )
        cmd_bytes = cmd_script.encode("utf-8")
        smb.putFile("ADMIN$", remote_cmd_rel, io.BytesIO(cmd_bytes).read)
        logger.info(
            "deploy_via_bits_smb: uploaded wrapper to \\\\%s\\ADMIN$\\%s",
            target_host,
            remote_cmd_rel,
        )

        # ── 4. Execute via SCMR temp-service ────────────────────────────────
        _scmr_execute_via_temp_service(
            smb=smb,
            target_host=target_host,
            username=username,
            password=password,
            domain=domain,
            command_line="cmd.exe /Q /c %s" % remote_cmd_abs,
            wait_seconds=60,
        )
    finally:
        try:
            smb.logoff()
        except Exception:
            pass

    # ── 5. Poll for service status via SCMR ─────────────────────────────────
    logger.info(
        "deploy_via_bits_smb: waiting up to %ds for service %s", poll_timeout, svc
    )
    waited = 0
    svc_status = {"status": "Unknown", "running": False}
    while waited < poll_timeout:
        time.sleep(poll_interval)
        waited += poll_interval
        try:
            svc_status = _scmr_query_service(
                target_host, username, password, domain, svc
            )
        except Exception:
            pass
        if svc_status.get("running"):
            logger.info(
                "deploy_via_bits_smb: service %s is running after %ds", svc, waited
            )
            break
        logger.info(
            "deploy_via_bits_smb: service %s status=%s, polling (%d/%ds)",
            svc,
            svc_status.get("status"),
            waited,
            poll_timeout,
        )

    return {
        "deployed": svc_status.get("running", False),
        "target_host": target_host,
        "status": svc_status.get("status", "Unknown"),
        "service_name": svc,
        "install_dir": idir,
        "config_written": True,
        "transport": "bits_smb",
        "error": None
        if svc_status.get("running")
        else "Service did not reach Running state within %ds" % poll_timeout,
    }


def verify_via_bits_smb(target_host, username, password, domain, service_name=None):
    """Query service status via SCMR after BITS+SMB deployment."""
    return verify_via_impacket(target_host, username, password, domain, service_name)


# ---------------------------------------------------------------------------
# Ivanti Neurons transport (REST API deployment trigger)
# ---------------------------------------------------------------------------


def deploy_via_ivanti(
    target_host,
    hawk_server,
    access_token,
    secret_key,
    install_dir=None,
    service_name=None,
    insecure=False,
    ivanti_tenant_url=None,
    ivanti_client_id=None,
    ivanti_client_secret=None,
    ivanti_package_id=None,
    poll_interval=10,
    poll_timeout=600,
    **kwargs,
):
    """Deploy hawk-soard via the Ivanti Neurons for ITAM REST API.

    This transport triggers a software deployment through the Ivanti cloud
    platform.  The hawk-soard installer package must already be configured
    as a package in Ivanti Neurons.  The function authenticates with the
    Ivanti API, triggers the deployment to the target machine, and polls
    for completion.

    Note: Credentials for the target host are NOT used — Ivanti pushes the
    package via its own agent infrastructure.  The ``username`` and
    ``password`` parameters are accepted for API consistency but are not
    needed for this transport.

    Args:
        target_host:    Hostname or FQDN of the target machine as registered
                        in Ivanti Neurons.
        hawk_server:    HAWK platform URL (unused for Ivanti, kept for API
                        consistency — the Ivanti package includes the server
                        config).
        access_token:   HAWK access_token (unused for Ivanti).
        secret_key:     HAWK secret_key (unused for Ivanti).
        install_dir:    Install directory on the remote host (informational).
        service_name:   Windows service name (informational).
        insecure:      If True, disable TLS cert verification for API calls.
        ivanti_tenant_url:  Ivanti Neurons tenant URL
                            (e.g. ``https://tenant.ivanticloud.com``).
        ivanti_client_id:    Ivanti API client ID.
        ivanti_client_secret: Ivanti API client secret.
        ivanti_package_id:   The Ivanti package ID for hawk-soard.
        poll_interval:  Seconds between status polls (default: 10).
        poll_timeout:   Maximum seconds to wait for deployment (default: 600).

    Returns:
        dict: ``{deployed, target_host, status, service_name, install_dir,
                 transport, error}``
    """
    import requests as http_requests

    if not ivanti_tenant_url or not ivanti_client_id or not ivanti_client_secret:
        raise ValueError(
            "deploy_via_ivanti requires ivanti_tenant_url, ivanti_client_id, "
            "and ivanti_client_secret parameters."
        )
    if not ivanti_package_id:
        raise ValueError(
            "deploy_via_ivanti requires ivanti_package_id parameter.")

    idir = (install_dir or DEFAULT_INSTALL_DIR).rstrip("\\")
    svc = service_name or DEFAULT_SERVICE_NAME
    base = ivanti_tenant_url.rstrip("/")

    # ── 1. Authenticate and get access token ────────────────────────────────
    token_url = "%s/api/identity/connect/token" % base
    logger.info("deploy_via_ivanti: authenticating with Ivanti at %s", base)

    auth_resp = http_requests.post(
        token_url,
        data={
            "grant_type": "client_credentials",
            "client_id": ivanti_client_id,
            "client_secret": ivanti_client_secret,
        },
        verify=not insecure,
        timeout=30,
    )
    if auth_resp.status_code != 200:
        raise RuntimeError(
            "deploy_via_ivanti: authentication failed (HTTP %d): %s"
            % (auth_resp.status_code, auth_resp.text[:500])
        )
    ivanti_token = auth_resp.json().get("access_token", "")
    if not ivanti_token:
        raise RuntimeError(
            "deploy_via_ivanti: authentication succeeded but no access_token in response."
        )

    headers = {
        "Authorization": "Bearer %s" % ivanti_token,
        "Content-Type": "application/json",
    }

    # ── 2. Resolve the target device key ────────────────────────────────────
    device_url = "%s/api/computers?$filter=HostName eq '%s'" % (
        base, target_host)
    logger.info("deploy_via_ivanti: looking up device %s", target_host)

    device_resp = http_requests.get(
        device_url, headers=headers, verify=not insecure, timeout=30
    )
    if device_resp.status_code != 200:
        raise RuntimeError(
            "deploy_via_ivanti: device lookup failed (HTTP %d): %s"
            % (device_resp.status_code, device_resp.text[:500])
        )

    devices = device_resp.json().get("value", device_resp.json().get("Items", []))
    if not devices:
        raise RuntimeError(
            "deploy_via_ivanti: device '%s' not found in Ivanti." % target_host
        )
    device_key = (
        devices[0].get("DeviceKey") or devices[0].get(
            "Key") or devices[0].get("Id")
    )
    if not device_key:
        raise RuntimeError(
            "deploy_via_ivanti: cannot determine device key for '%s'." % target_host
        )

    # ── 3. Trigger package deployment ───────────────────────────────────────
    deploy_url = "%s/api/computers/%s/deploypackage/%s" % (
        base,
        device_key,
        ivanti_package_id,
    )
    logger.info(
        "deploy_via_ivanti: triggering package %s deployment to %s (key=%s)",
        ivanti_package_id,
        target_host,
        device_key,
    )

    deploy_resp = http_requests.post(
        deploy_url, headers=headers, json={}, verify=not insecure, timeout=30
    )
    if deploy_resp.status_code not in (200, 201, 202):
        raise RuntimeError(
            "deploy_via_ivanti: deployment trigger failed (HTTP %d): %s"
            % (deploy_resp.status_code, deploy_resp.text[:500])
        )

    deploy_data = deploy_resp.json() if deploy_resp.text else {}
    task_id = (
        deploy_data.get("TaskId")
        or deploy_data.get("taskId")
        or deploy_data.get("id", "")
    )

    # ── 4. Poll for deployment completion ────────────────────────────────────
    logger.info(
        "deploy_via_ivanti: deployment triggered (task_id=%s), polling...", task_id
    )
    waited = 0
    final_status = "Unknown"
    while waited < poll_timeout:
        time.sleep(poll_interval)
        waited += poll_interval

        if task_id:
            poll_url = "%s/api/deploymenttasks/%s" % (base, task_id)
            try:
                poll_resp = http_requests.get(
                    poll_url, headers=headers, verify=not insecure, timeout=30
                )
                if poll_resp.status_code == 200:
                    poll_data = poll_resp.json()
                    status_val = (
                        poll_data.get("Status")
                        or poll_data.get("State")
                        or poll_data.get("status")
                        or ""
                    )
                    final_status = str(status_val)
                    if status_val and str(status_val).lower() in (
                        "completed",
                        "success",
                        "installed",
                        "done",
                    ):
                        logger.info(
                            "deploy_via_ivanti: deployment completed after %ds", waited
                        )
                        return {
                            "deployed": True,
                            "target_host": target_host,
                            "status": final_status,
                            "service_name": svc,
                            "install_dir": idir,
                            "transport": "ivanti",
                            "config_written": False,
                            "error": None,
                            "task_id": task_id,
                        }
                    if status_val and str(status_val).lower() in (
                        "failed",
                        "error",
                        "cancelled",
                    ):
                        logger.error(
                            "deploy_via_ivanti: deployment %s after %ds",
                            status_val,
                            waited,
                        )
                        return {
                            "deployed": False,
                            "target_host": target_host,
                            "status": final_status,
                            "service_name": svc,
                            "install_dir": idir,
                            "transport": "ivanti",
                            "config_written": False,
                            "error": "Ivanti deployment %s" % status_val,
                            "task_id": task_id,
                        }
            except Exception:
                pass

    logger.warning(
        "deploy_via_ivanti: deployment did not complete within %ds", poll_timeout
    )
    return {
        "deployed": False,
        "target_host": target_host,
        "status": final_status or "TimedOut",
        "service_name": svc,
        "install_dir": idir,
        "transport": "ivanti",
        "config_written": False,
        "error": "Ivanti deployment did not complete within %ds" % poll_timeout,
        "task_id": task_id,
    }


def verify_via_ivanti(target_host, service_name=None, **kwargs):
    """Verification for Ivanti deployments is not available via SCMR.

    Returns a placeholder status indicating the device was targeted.

    Args:
        target_host:  Hostname or IP of the remote Windows host.
        service_name: Windows service name (default: ``HawkSoard``).

    Returns:
        dict: ``{target_host, service_name, status, running, error}``
    """
    return {
        "target_host": target_host,
        "service_name": service_name or DEFAULT_SERVICE_NAME,
        "status": "Unknown",
        "running": None,
        "error": "Ivanti verification requires SCMR; use transport=impacket or transport=sccm for verification.",
    }


# ---------------------------------------------------------------------------
# Impacket internals
# ---------------------------------------------------------------------------


def _download_installer(url):
    """Download the NSIS installer from *url* to a local temp file.  Returns the path."""
    import tempfile
    import urllib.request

    tmp = tempfile.NamedTemporaryFile(
        suffix=".exe", prefix="hawk-soard-dl-", delete=False
    )
    tmp.close()
    logger.info(
        "deploy_via_impacket: downloading installer from %s -> %s", url, tmp.name
    )
    urllib.request.urlretrieve(url, tmp.name)
    return tmp.name


def _to_powershell_encoded_command(script_text):
    return base64.b64encode(script_text.encode("utf-16le")).decode("ascii")


def _abs_to_share_rel(abs_path):
    """Convert ``C:\\Foo\\Bar`` → ``Foo\\Bar`` (strips drive letter for SMB C$ access)."""
    p = abs_path
    if len(p) >= 2 and p[1] == ":":
        p = p[2:]
    return p.lstrip("\\")


def _smb_makedirs(smb, share, rel_path):
    """Create *rel_path* (and parents) on *share* if they don't already exist."""
    parts = rel_path.replace("/", "\\").split("\\")
    current = ""
    for part in parts:
        if not part:
            continue
        current = (current + "\\" + part) if current else part
        try:
            smb.createDirectory(share, current)
        except Exception:
            pass  # directory already exists


def _sftp_put_windows_file(sftp, remote_windows_path, local_path):
    """Upload *local_path* to a Windows OpenSSH SFTP target.

    Windows OpenSSH SFTP path handling varies by configuration, so try the two
    common drive-letter forms before failing.
    """
    normalized = remote_windows_path.replace("\\", "/")
    candidates = [normalized, "/" + normalized]
    last_error = None
    for candidate in candidates:
        try:
            sftp.put(local_path, candidate)
            return
        except Exception as exc:
            last_error = exc
    raise last_error


def _wmi_create_process(target_host, username, password, domain, command_line):
    """Execute *command_line* on *target_host* via WMI Win32_Process.Create.

    Does not wait for the process to finish — the caller is responsible for
    sleeping long enough for the installer to complete.
    """
    from impacket.dcerpc.v5 import transport as dcerpc_transport
    from impacket.dcerpc.v5.dtypes import NULL

    try:
        from impacket.dcerpc.v5.dcom import wmi as impacket_wmi  # impacket >= 0.11
    except ImportError:
        from impacket.dcerpc.v5 import wmi as impacket_wmi  # impacket < 0.11

    string_binding = "ncacn_ip_tcp:%s[135]" % target_host
    trans = dcerpc_transport.DCERPCTransportFactory(string_binding)
    trans.set_credentials(username, password, domain, "", "", None)
    iface = trans.get_dce_rpc()
    iface.connect()
    iface.bind(impacket_wmi.MSRPC_UUID_WMI)

    # Locate the WMI service endpoint via the IWbemLevel1Login interface.
    iwbem_login = impacket_wmi.IWbemLevel1Login(iface)
    iwbem_services = iwbem_login.NTLMLogin("//./root/cimv2", NULL, NULL)
    iwbem_login.RemRelease()

    win32_process, _ = iwbem_services.GetObject("Win32_Process")
    win32_process.SpawnInstance()
    result = win32_process.Create(command_line, "C:\\Windows\\Temp", None)
    pid = result.ProcessId
    iface.disconnect()

    logger.info("_wmi_create_process: launched pid=%s cmd=%r",
                pid, command_line[:120])
    return pid


def _scmr_execute_via_temp_service(
    smb,
    target_host,
    username,
    password,
    domain,
    command_line,
    wait_seconds=15,
):
    """Run *command_line* via a one-shot temporary service.

    The command is written to ``ADMIN$\\Temp\\<uuid>.cmd`` and then launched as
    ``cmd.exe /Q /c <script>`` through SCMR. No stdout capture is attempted;
    callers verify deployment success afterwards by querying the real service.
    """
    from impacket.dcerpc.v5 import scmr

    temp_name = "hawksoar-%s" % uuid.uuid4().hex[:8]
    remote_rel = "Temp\\%s.cmd" % temp_name
    remote_abs = "C:\\Windows\\Temp\\%s.cmd" % temp_name
    script_body = "@echo off\r\n%s\r\nexit /b %%errorlevel%%\r\n" % command_line
    smb.putFile("ADMIN$", remote_rel, io.BytesIO(
        script_body.encode("utf-8")).read)

    dce, scm = _scmr_connect(target_host, username, password, domain)
    service_handle = None
    try:
        response = scmr.hRCreateServiceW(
            dce,
            scm,
            temp_name,
            temp_name,
            lpBinaryPathName="cmd.exe /Q /c %s" % remote_abs,
            dwStartType=scmr.SERVICE_DEMAND_START,
        )
        service_handle = response["lpServiceHandle"]
        scmr.hRStartServiceW(dce, service_handle)
        time.sleep(wait_seconds)
        scmr.hRDeleteService(dce, service_handle)
    finally:
        if service_handle is not None:
            try:
                scmr.hRCloseServiceHandle(dce, service_handle)
            except Exception:
                pass
        try:
            scmr.hRCloseServiceHandle(dce, scm)
        except Exception:
            pass
        dce.disconnect()
        try:
            smb.deleteFile("ADMIN$", remote_rel)
        except Exception:
            pass


def _scmr_connect(target_host, username, password, domain):
    """Open an authenticated SCMR DCERPC connection and return (dce, scm_handle)."""
    from impacket.dcerpc.v5 import transport as dcerpc_transport, scmr

    string_binding = r"ncacn_np:%s[\pipe\svcctl]" % target_host
    trans = dcerpc_transport.DCERPCTransportFactory(string_binding)
    trans.set_credentials(username, password, domain, "", "", None)
    trans.set_connect_timeout(10)
    dce = trans.get_dce_rpc()
    dce.connect()
    dce.bind(scmr.MSRPC_UUID_SCMR)
    scm_handle = scmr.hROpenSCManagerW(dce)["lpScHandle"]
    return dce, scm_handle


def _scmr_restart_service(target_host, username, password, domain, service_name):
    """Stop (if running) then start *service_name* via SCMR. Returns status dict."""
    from impacket.dcerpc.v5 import scmr

    dce, scm = _scmr_connect(target_host, username, password, domain)
    try:
        svc_handle = scmr.hROpenServiceW(dce, scm, service_name)[
            "lpServiceHandle"]
        try:
            # Stop if currently running (ignore error if already stopped).
            try:
                scmr.hRControlService(
                    dce, svc_handle, scmr.SERVICE_CONTROL_STOP)
                time.sleep(3)
            except Exception:
                pass
            scmr.hRStartServiceW(dce, svc_handle)
            time.sleep(3)
            return _scmr_query_handle(dce, svc_handle, service_name)
        finally:
            scmr.hRCloseServiceHandle(dce, svc_handle)
    finally:
        scmr.hRCloseServiceHandle(dce, scm)
        dce.disconnect()


def _scmr_query_service(target_host, username, password, domain, service_name):
    """Query *service_name* status via SCMR. Returns status dict."""
    from impacket.dcerpc.v5 import scmr

    dce, scm = _scmr_connect(target_host, username, password, domain)
    try:
        svc_handle = scmr.hROpenServiceW(dce, scm, service_name)[
            "lpServiceHandle"]
        try:
            return _scmr_query_handle(dce, svc_handle, service_name)
        finally:
            scmr.hRCloseServiceHandle(dce, svc_handle)
    finally:
        scmr.hRCloseServiceHandle(dce, scm)
        dce.disconnect()


def _scmr_query_handle(dce, svc_handle, service_name):
    """Return a status dict for an already-open service handle."""
    from impacket.dcerpc.v5 import scmr

    resp = scmr.hRQueryServiceStatus(dce, svc_handle)
    state = resp["lpServiceStatus"]["dwCurrentState"]
    pid = resp.get("lpServiceStatus", {}).get("dwProcessId", 0)

    state_map = {
        scmr.SERVICE_STOPPED: "Stopped",
        scmr.SERVICE_START_PENDING: "StartPending",
        scmr.SERVICE_STOP_PENDING: "StopPending",
        scmr.SERVICE_RUNNING: "Running",
        scmr.SERVICE_CONTINUE_PENDING: "ContinuePending",
        scmr.SERVICE_PAUSE_PENDING: "PausePending",
        scmr.SERVICE_PAUSED: "Paused",
    }
    status_str = state_map.get(state, "Unknown")

    return {
        "service_name": service_name,
        "status": status_str,
        "running": state == scmr.SERVICE_RUNNING,
        "pid": pid,
    }


def _build_local_windows_deploy_script(
    install_dir,
    service_name,
    source_url,
    cfg_b64,
    installer_path=None,
):
    """Build a PowerShell install script for local execution on the target host."""
    idir = _ps_quote(install_dir.rstrip("\\"))
    svc = _ps_quote(service_name or DEFAULT_SERVICE_NAME)
    src = _ps_quote(source_url or HAWK_INSTALLER_URL)
    cfg = _ps_quote(cfg_b64)
    tmp = _ps_quote(
        installer_path or ("C:\\Windows\\Temp\\%s" % LOCAL_INSTALLER_FILENAME)
    )
    display_name = _ps_quote(_SERVICE_DISPLAY_NAME)
    description = _ps_quote(_SERVICE_DESCRIPTION)

    return (
        "$ErrorActionPreference='Stop';"
        "$idir='%s';"
        "$svcName='%s';"
        "$srcUrl='%s';"
        "$cfgB64='%s';"
        "$tmp='%s';"
        "$exePath=$idir+'\\hawk-soard.exe';"
        "$cfgPath=$idir+'\\hawk-soard.cfg';"
        "function Invoke-HawkDownload {"
        "param($Url,$Path);"
        "try{Invoke-WebRequest -Uri $Url -OutFile $Path -UseBasicParsing -ErrorAction Stop;if(Test-Path $Path){return $true}}catch{};"
        "try{Start-BitsTransfer -Source $Url -Destination $Path -ErrorAction Stop;if(Test-Path $Path){return $true}}catch{};"
        "try{& certutil.exe -urlcache -split -f $Url $Path | Out-Null;if(Test-Path $Path){return $true}}catch{};"
        "try{& curl.exe -L $Url -o $Path | Out-Null;if(Test-Path $Path){return $true}}catch{};"
        "return $false"
        "};"
        "try{"
        "New-Item -ItemType Directory -Path $idir -Force|Out-Null;"
        "New-Item -ItemType Directory -Path ($idir+'\\data') -Force|Out-Null;"
        "if(-not(Test-Path $exePath)){"
        "if(-not(Test-Path $tmp)){if(-not(Invoke-HawkDownload $srcUrl $tmp)){throw 'failed to download installer'}};"
        "$nsisArgs='/S /D='+$idir;"
        "Start-Process -FilePath $tmp -ArgumentList $nsisArgs -Wait -WindowStyle Hidden -ErrorAction Stop;"
        "Start-Sleep -Seconds 5;"
        "};"
        "$cfgBytes=[Convert]::FromBase64String($cfgB64);"
        "$cfgText=[Text.Encoding]::UTF8.GetString($cfgBytes);"
        "Set-Content -Path $cfgPath -Value $cfgText -Encoding UTF8 -Force;"
        "$existing=Get-Service -Name $svcName -ErrorAction SilentlyContinue;"
        "if(-not $existing){"
        "$binPath='\"'+$exePath+'\" -c \"'+$cfgPath+'\" -service';"
        "New-Service -Name $svcName -BinaryPathName $binPath -DisplayName '%s' -Description '%s' -StartupType Automatic|Out-Null"
        "};"
        "Stop-Service -Name $svcName -Force -ErrorAction SilentlyContinue;"
        "Start-Sleep -Seconds 2;"
        "Start-Service -Name $svcName -ErrorAction Stop;"
        "Start-Sleep -Seconds 3;"
        '$s=Get-CimInstance Win32_Service -Filter ("Name=\'"+ $svcName +"\'") -ErrorAction SilentlyContinue;'
        "$st=if($s){$s.State}else{'NotFound'};"
        "[PSCustomObject]@{"
        "deployed=($st -eq 'Running');service_name=$svcName;status=$st;install_dir=$idir;config_written=$true"
        "}|ConvertTo-Json -Depth 2;"
        "}catch{"
        "[PSCustomObject]@{deployed=$false;error=$_.Exception.Message;service_name=$svcName;install_dir=$idir}|ConvertTo-Json -Depth 2"
        "}"
    ) % (idir, svc, src, cfg, tmp, display_name, description)


# ---------------------------------------------------------------------------
# Internal script builders (WinRM/PowerShell transport)
# ---------------------------------------------------------------------------


def _build_push_script(
    target_host,
    user_ref,
    password,
    access_token,
    secret_key,
    idir,
    svc,
    source_path,
    cfg_b64,
    q,
):
    """PSSession + Copy-Item push strategy.

    1. Opens a PSSession to the remote host.
    2. Creates the install and data directories on the remote host.
    3. Copies the local NSIS installer to the remote host via Copy-Item -ToSession.
    4. Runs the installer using Start-Process so the /D= path-with-spaces
       argument is passed verbatim to NSIS (avoids PowerShell re-parsing it).
    5. Unconditionally writes the config via a base64-decoded blob so that
       credentials are current even when re-deploying over an existing install.
    6. Stops then starts the service so the new config takes effect.

    Credentials travel via -ArgumentList over the encrypted WinRM channel and
    are never embedded as string literals in the remote ScriptBlock.
    """
    # ScriptBlock 1: create directories before the file copy.
    setup_block = (
        "param($d);"
        "New-Item -ItemType Directory -Path $d -Force|Out-Null;"
        "New-Item -ItemType Directory -Path ($d+'\\data') -Force|Out-Null"
    )

    # ScriptBlock 2: run installer, write config, restart service.
    # Parameters: idir, svcName, tok (access_token), secKey (secret_key), cfgB64.
    # Note: $secKey avoids any name collision with the outer $credSec variable.
    install_block = (
        "param($idir,$svcName,$tok,$secKey,$cfgB64);"
        "$tmp=$idir+'\\hawk-soard-setup.exe';"
        "try{"
        # Use Start-Process so PowerShell does not re-tokenise the argument
        # string.  NSIS requires /D= to be the last argument and its path must
        # not be quoted — Start-Process -ArgumentList passes the string verbatim
        # to CreateProcess, which is exactly what NSIS expects.
        "$nsisArgs='/S /ACCESS_TOKEN='+$tok+' /SECRET_KEY='+$secKey+' /D='+$idir;"
        "Start-Process -FilePath $tmp -ArgumentList $nsisArgs -Wait -WindowStyle Hidden -ErrorAction Stop;"
        "Start-Sleep -Seconds 5;"
        # Always overwrite config to guarantee correct credentials on re-deploy.
        "$cfgBytes=[Convert]::FromBase64String($cfgB64);"
        "$cfgText=[Text.Encoding]::UTF8.GetString($cfgBytes);"
        "Set-Content -Path ($idir+'\\hawk-soard.cfg') -Value $cfgText -Encoding UTF8 -Force;"
        # Stop then start so the service reads the freshly written config.
        "Stop-Service -Name $svcName -Force -ErrorAction SilentlyContinue;"
        "Start-Sleep -Seconds 2;"
        "Start-Service -Name $svcName -ErrorAction Stop;"
        "Start-Sleep -Seconds 3;"
        '$s=Get-CimInstance Win32_Service -Filter ("Name=\'"+ $svcName +"\'") -ErrorAction SilentlyContinue;'
        "$st=if($s){$s.State}else{'NotFound'};"
        "$spid=if($s){$s.ProcessId}else{0};"
        "[PSCustomObject]@{"
        "deployed=$true;service_name=$svcName;status=$st;pid=$spid;"
        "install_dir=$idir;exe_exists=(Test-Path ($idir+'\\hawk-soard.exe'));config_written=$true"
        "}|ConvertTo-Json -Depth 2;"
        "}catch{"
        "[PSCustomObject]@{deployed=$false;error=$_.Exception.Message;service_name=$svcName;install_dir=$idir}"
        "|ConvertTo-Json -Depth 2;}"
    )

    remote_installer_path = idir + "\\" + LOCAL_INSTALLER_FILENAME

    # Outer script: session lifecycle with catch so failures always emit JSON.
    # $credSec is used for the local SecureString to avoid any name clash with
    # the $secKey parameter inside the remote ScriptBlock.
    return (
        "$credSec=ConvertTo-SecureString '%s' -AsPlainText -Force;"
        "$cred=New-Object System.Management.Automation.PSCredential('%s',$credSec);"
        "$sess=New-PSSession -ComputerName '%s' -Credential $cred -ErrorAction Stop;"
        "try{"
        "Invoke-Command -Session $sess -ScriptBlock {%s} -ArgumentList '%s' -ErrorAction Stop;"
        "Copy-Item -Path '%s' -Destination '%s' -ToSession $sess -Force -ErrorAction Stop;"
        "Invoke-Command -Session $sess -ScriptBlock {%s} -ArgumentList '%s','%s','%s','%s','%s';"
        "}catch{"
        "[PSCustomObject]@{deployed=$false;error=$_.Exception.Message;service_name='%s';install_dir='%s'}"
        "|ConvertTo-Json -Depth 2;"
        "}finally{"
        "if($sess){Remove-PSSession $sess -ErrorAction SilentlyContinue}}"
    ) % (
        q(password),
        q(user_ref),
        q(target_host),
        setup_block,
        q(idir),
        q(source_path),
        q(remote_installer_path),
        install_block,
        q(idir),
        q(svc),
        q(access_token),
        q(secret_key),
        q(cfg_b64),
        q(svc),
        q(idir),
    )


def _build_url_script(
    target_host,
    user_ref,
    password,
    access_token,
    secret_key,
    idir,
    svc,
    source_url,
    cfg_b64,
    q,
):
    """Self-contained Invoke-Command download-and-install strategy.

    Downloads the package from source_url on the remote host.

    - ``.exe`` packages: run via Start-Process with NSIS CLI args.
    - ``.zip`` packages: extract then register the service manually.

    In both cases the config is unconditionally written via a base64-decoded
    PowerShell blob and the service is restarted so credentials are always
    current, including on re-deployment.
    """
    remote_block = (
        "$idir='%s';"
        "$svcName='%s';"
        "$accessToken='%s';"
        "$secretKey='%s';"
        "$exePath=$idir+'\\hawk-soard.exe';"
        "$cfgPath=$idir+'\\hawk-soard.cfg';"
        "$srcUrl='%s';"
        "$cfgB64='%s';"
        # Derive temp-file extension from the URL, not the fixed filename, so
        # the .exe/.zip branch detection further down is always correct.
        "$tmpExt=if($srcUrl -match '\\.zip([?#]|$)'){'zip'}else{'exe'};"
        "$tmp=$env:TEMP+'\\hawk-soard-dl.'+$tmpExt;"
        "try{"
        # 1. Ensure directories exist.
        "New-Item -ItemType Directory -Path $idir -Force|Out-Null;"
        "New-Item -ItemType Directory -Path ($idir+'\\data') -Force|Out-Null;"
        # 2. Download and install only when the binary is not already present.
        "if(-not(Test-Path $exePath)){"
        "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;"
        "Invoke-WebRequest -Uri $srcUrl -OutFile $tmp -UseBasicParsing -ErrorAction Stop;"
        "if($tmpExt -eq 'exe'){"
        # Use Start-Process so the /D= path-with-spaces reaches NSIS verbatim.
        "$nsisArgs='/S /ACCESS_TOKEN='+$accessToken+' /SECRET_KEY='+$secretKey+' /D='+$idir;"
        "Start-Process -FilePath $tmp -ArgumentList $nsisArgs -Wait -WindowStyle Hidden -ErrorAction Stop;"
        "Start-Sleep -Seconds 5;"
        "}"
        "elseif($tmpExt -eq 'zip'){"
        "Expand-Archive -Path $tmp -DestinationPath $idir -Force;"
        # Manual service registration for zip installs.
        "$binPath='\"'+$exePath+'\" -c \"'+$cfgPath+'\" -service';"
        "$existing=Get-Service -Name $svcName -ErrorAction SilentlyContinue;"
        "if($existing){"
        "Stop-Service -Name $svcName -Force -ErrorAction SilentlyContinue;"
        "sc.exe config $svcName binPath= $binPath start= auto|Out-Null;}"
        "else{"
        "New-Service -Name $svcName -BinaryPathName $binPath "
        "-DisplayName '%s' -Description '%s' -StartupType Automatic|Out-Null;}"
        "};"
        "Remove-Item $tmp -Force -ErrorAction SilentlyContinue;"
        "};"
        # 3. Always write config — guarantees credentials are current even when
        #    the binary was already installed and the NSIS guard skipped writing.
        "$cfgBytes=[Convert]::FromBase64String($cfgB64);"
        "$cfgText=[Text.Encoding]::UTF8.GetString($cfgBytes);"
        "Set-Content -Path $cfgPath -Value $cfgText -Encoding UTF8 -Force;"
        # 4. Restart service so the new config takes effect.
        "Stop-Service -Name $svcName -Force -ErrorAction SilentlyContinue;"
        "Start-Sleep -Seconds 2;"
        "Start-Service -Name $svcName -ErrorAction Stop;"
        "Start-Sleep -Seconds 3;"
        # 5. Report status.
        '$s=Get-CimInstance Win32_Service -Filter ("Name=\'"+ $svcName +"\'") -ErrorAction SilentlyContinue;'
        "$st=if($s){$s.State}else{'NotFound'};"
        "$spid=if($s){$s.ProcessId}else{0};"
        "[PSCustomObject]@{"
        "deployed=$true;service_name=$svcName;status=$st;pid=$spid;"
        "install_dir=$idir;exe_exists=(Test-Path $exePath);config_written=$true"
        "}|ConvertTo-Json -Depth 2;"
        "}catch{"
        "[PSCustomObject]@{"
        "deployed=$false;error=$_.Exception.Message;service_name=$svcName;install_dir=$idir"
        "}|ConvertTo-Json -Depth 2;"
        "}"
    ) % (
        q(idir),
        q(svc),
        q(access_token),
        q(secret_key),
        q(source_url),
        q(cfg_b64),
        q(_SERVICE_DISPLAY_NAME),
        q(_SERVICE_DESCRIPTION),
    )

    return (
        "$credSec=ConvertTo-SecureString '%s' -AsPlainText -Force;"
        "$cred=New-Object System.Management.Automation.PSCredential('%s',$credSec);"
        "Invoke-Command -ComputerName '%s' -Credential $cred -ScriptBlock {%s};"
    ) % (
        q(password),
        q(user_ref),
        q(target_host),
        remote_block,
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _ps_quote(value):
    """Escape a value for safe embedding inside a PowerShell single-quoted string."""
    if value is None:
        return ""
    return str(value).replace("'", "''")
