import pytest
import tempfile
from pathlib import Path
from unittest.mock import patch
from testkit.aggregator import aggregate_test_components_from_yaml

class TestAggregateTestComponentsFromYaml:
    """Tests for aggregate_test_components_from_yaml function"""

    @pytest.fixture
    def valid_yaml_content(self):
        """Fixture providing valid YAML test suite content"""
        return """test_suite:
  metadata:
    name: Sample Test Suite
    component:
      - comp1
      - comp2
      - comp1
    tags:
      - smoke
  test_cases:
    - name: test logout
      description: Test user logout functionality
      metadata:
        components:
          - logout_module
        enable: true
        tags:
          - critical
      steps:
        - command:
            executable: /bin/true
          timeout_sec: 5
          expectations:
            exit_code: 0
"""

    @pytest.fixture
    def valid_yaml_file(self, tmp_path, valid_yaml_content):
        """Fixture that creates a valid YAML file"""
        yaml_file = tmp_path / "test_suite.yaml"
        yaml_file.write_text(valid_yaml_content)
        return yaml_file

    def test_file_not_found(self):
        """Test FileNotFoundError when file does not exist"""
        with pytest.raises(FileNotFoundError, match="does not exist or is not a file"):
            aggregate_test_components_from_yaml("/nonexistent/path/file.yaml")

    def test_invalid_file_extension(self):
        """Test FileNotFoundError when file extension is not .yaml or .yml"""
        with tempfile.NamedTemporaryFile(suffix=".txt") as tmp:
            with pytest.raises(FileNotFoundError, match="not a YAML file"):
                aggregate_test_components_from_yaml(tmp.name)

    def test_missing_test_suite_key(self):
        """Test ValueError when YAML doesn't contain 'test_suite' key"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as tmp:
            tmp.write("other_key: value\n")
            tmp.flush()
            try:
                with pytest.raises(RuntimeError, match="must contain 'test_suite' key"):
                    aggregate_test_components_from_yaml(tmp.name)
            finally:
                Path(tmp.name).unlink()

    def test_yaml_not_dict(self):
        """Test ValueError when YAML root is not a dictionary"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as tmp:
            tmp.write("- item1\n- item2\n")
            tmp.flush()
            try:
                with pytest.raises(RuntimeError, match="must contain 'test_suite' key"):
                    aggregate_test_components_from_yaml(tmp.name)
            finally:
                Path(tmp.name).unlink()

    def test_successful_aggregation(self, valid_yaml_file):
        """Test successful aggregation of components"""

        result = aggregate_test_components_from_yaml(str(valid_yaml_file))
        assert result == {"comp1": 2, "comp2": 1}

    def test_yml_extension(self):
        """Test that .yml extension is accepted"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False) as tmp:
            tmp.write("test_suite:\n  name: test\n")
            tmp.flush()
            try:
                with patch("testkit.aggregator.TestSuite") as mock_suite:
                    mock_suite.return_value.metadata.component = []
                    result = aggregate_test_components_from_yaml(tmp.name)
                    assert result == {}
            finally:
                Path(tmp.name).unlink()
