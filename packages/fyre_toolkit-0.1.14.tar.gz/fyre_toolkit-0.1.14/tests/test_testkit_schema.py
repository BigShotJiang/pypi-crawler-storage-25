from pydantic import ValidationError
import pytest
from testkit.schema import (
    Command,
    Expectations,
    Step,
    TestCase,
    TestCaseMetadata,
    TestSuite,
    TestSuiteMetadata,
    PreConditions,
    PostConditions,
    SetupCommand,
    CleanupCommand,
)

# --- Test Command Model ---
def test_command_valid():
    cmd = Command(executable="/bin/ls", args=["-la"])
    assert cmd.executable == "/bin/ls"
    assert cmd.args == ["-la"]

def test_command_missing_executable():
    with pytest.raises(ValueError, match="command.executable is mandatory"):
        Command(executable="", args=[])

def test_command_invalid_executable_empty():
    with pytest.raises(ValidationError):
        Command(executable="", args=["--option"])

def test_command_valid_with_default_args():
    command = Command(executable="path/to/command")
    assert command.args == []

# --- Test Expectations Model ---
def test_expectations_valid():
    exp = Expectations(exit_code=0, keywords=["success"])
    assert exp.exit_code == 0
    assert exp.keywords == ["success"]

def test_expectations_empty_validation():
    with pytest.raises(ValueError, match="expectations must have exit_code or keywords"):
        Expectations(exit_code=None, keywords=[])

def test_expectations_valid_with_only_keywords():
    expectations = Expectations(exit_code=None, keywords=["key"])
    assert expectations.exit_code == None
    assert expectations.keywords == ["key"]

def test_valid_with_exit_code_only():
    exp = Expectations(exit_code=0)
    assert exp.exit_code == 0
    assert exp.keywords == []

# --- Test Step Model ---
def test_step_valid():
    step = Step(
        command=Command(executable="/bin/echo", args=["hello"]),
        timeout_sec=30,
        expectations=Expectations(exit_code=0, keywords=["hello"]),
    )
    assert step.timeout_sec == 30

def test_step_missing_command():
    with pytest.raises(ValueError, match="step.command is mandatory and cannot be empty"):
        Step(
            command=None,  # type: ignore
            timeout_sec=10,
            expectations=Expectations(exit_code=0),
        )

# --- Test Steps Model ---
def test_steps_valid():
    steps = [
        Step(
            command=Command(executable="/bin/true"),
            expectations=Expectations(exit_code=0),
        )
    ]
    assert len(steps) == 1

# --- Test TestCase Model ---
def test_test_case_valid():
    test_case = TestCase(
        name="valid_test",
        description="description",
        metadata=TestCaseMetadata(),
        steps=[
            Step(
                command=Command(executable="/bin/true"),
                expectations=Expectations(exit_code=0),
            )
        ])
    assert test_case.name == "valid_test"

def test_test_case_missing_name():
    with pytest.raises(ValueError, match="test_cases.name is mandatory and cannot be empty"):
        TestCase(
            name="",
            description="",
            metadata=TestCaseMetadata(),
            steps=[Step(
                command=Command(executable="/bin/true"),
                expectations=Expectations(exit_code=0),
            )])

# --- Test TestSuite Model ---
def test_test_suite_valid():
    suite = TestSuite(
        metadata=TestSuiteMetadata(name="suite", component=["core"]),
        test_cases=[
            TestCase(
                name="test1",
                description="desc",
                metadata=TestCaseMetadata(),
                steps=[
                    Step(
                        command=Command(executable="/bin/true"),
                        expectations=Expectations(exit_code=0),
                    )
                ]
            ),
        ],
    )
    assert suite.metadata.name == "suite"

def test_test_suite_invalid():
    with pytest.raises(ValueError, match="test_suite.test_cases is mandatory"):
        TestSuite(
            metadata=TestSuiteMetadata(name="suite", component=["core"]),
            test_cases=[],
        )

# --- Test Pre/Post Conditions ---
def test_pre_conditions():
    pre = PreConditions(setup_command=[
        SetupCommand(executable="/bin/mkdir", args=["/tmp"])
    ])
    assert pre.setup_command[0].executable == "/bin/mkdir"

def test_post_conditions():
    post = PostConditions(cleanup_command=[
        CleanupCommand(executable="/bin/rm", args=["-rf"])
    ])
    assert post.cleanup_command[0].args == ["-rf"]

# --- Test Metadata Validations ---
def test_suite_metadata_validation():
    with pytest.raises(ValueError, match="test_suite.name is mandatory and cannot be empty"):
        TestSuiteMetadata(name="", component=["core"])

def test_suite_metadata_component_validation():
    with pytest.raises(ValueError, match="test_suite.metadata.component is mandatory"):
        TestSuiteMetadata(name="valid", component=[])

# --- Test Full Schema Integration ---
def test_full_schema_validation():
    valid_data = {
        "metadata": {
            "name": "integration_test",
            "component": ["auth"],
            "tags": ["smoke"]
        },
        "test_cases": [{
            "name": "login_test",
            "description": "Test user login",
            "metadata": {"enable": True},
            "steps": [
                {
                    "command": {"executable": "/bin/login", "args": ["user"]},
                    "expectations": {"exit_code": 0, "keywords": ["welcome"]}
                }
            ]
        }]
    }
    suite = TestSuite(**valid_data)
    assert suite.test_cases[0].name == "login_test"
