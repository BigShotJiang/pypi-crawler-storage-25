import tempfile
from time import sleep
from unittest.mock import MagicMock
import pytest
from testkit.utils import convert_kd_to_csv, uniq_workspace_dir, convert_xml_to_csv, generate_summary_result
from pathlib import Path
import datetime
import os
import csv
import re
import xml.etree.ElementTree as ET


class TestUniqWorkspaceDir:
    """Test suite for uniq_workspace_dir function"""

    def test_default_parameters(self, tmp_path):
        """Test with default parameters"""
        with pytest.MonkeyPatch.context() as mp:
            mp.chdir(tmp_path)  # Change working directory to temp dir
            path = uniq_workspace_dir(root=str(tmp_path))
            assert Path(path).exists()
            assert path.startswith(str(tmp_path))
            assert "workspace-" in path
            assert path.endswith(
                datetime.datetime.now(datetime.UTC).strftime("%Y%m%d%H%M%S")
            )

    def test_custom_root_and_prefix(self, tmp_path):
        """Test with custom root and prefix"""
        custom_root = tmp_path / "custom"
        path = uniq_workspace_dir(root=str(custom_root), prefix="mytests")
        assert Path(path).exists()
        assert str(custom_root) in path
        assert "mytests-" in path
        assert path.endswith(
            datetime.datetime.now(datetime.UTC).strftime("%Y%m%d%H%M%S")
        )

    def test_nonexistent_root(self, tmp_path):
        """Test with non-existent root directory"""
        custom_root = tmp_path / "nonexistent"
        path = uniq_workspace_dir(root=str(custom_root))
        assert Path(path).exists()
        assert str(custom_root) in path

    def test_directory_creation(self, tmp_path):
        """Test that directory is actually created"""
        path = uniq_workspace_dir(root=str(tmp_path))
        assert os.path.isdir(path)

    def test_return_resolved_path(self, tmp_path):
        """Test that returned path is resolved (absolute)"""
        path = uniq_workspace_dir(root=str(tmp_path))
        assert Path(path).is_absolute()
        assert str(Path(path).resolve()) == path  # Already resolved

    def test_unique_timestamps(self, tmp_path):
        """Test that subsequent calls produce different paths"""
        path1 = uniq_workspace_dir(root=str(tmp_path))
        sleep(1)
        path2 = uniq_workspace_dir(root=str(tmp_path))
        assert path1 != path2

    def test_fixed_timestamp(self, tmp_path, monkeypatch):
        """Test with controlled timestamp"""
        fixed_time = datetime.datetime(2023, 1, 1, 12, 0, 0)
        monkeypatch.setattr(
            datetime, "datetime", MagicMock(now=MagicMock(return_value=fixed_time))
        )

        path = uniq_workspace_dir(root=str(tmp_path))
        assert "20230101120000" in path

    def test_special_characters_in_prefix(self, tmp_path):
        """Test with special characters in prefix"""
        path = uniq_workspace_dir(root=str(tmp_path), prefix="test@123!")
        assert Path(path).exists()
        assert "test@123!-" in path

    @pytest.mark.parametrize(
        "root,prefix",
        [
            (".", ""),  # Empty prefix
            ("", "test"),  # Empty root (current dir)
            (".", "a" * 255),  # Long prefix
        ],
    )
    def test_edge_cases(self, root, prefix, tmp_path):
        """Test various edge cases"""
        with pytest.MonkeyPatch.context() as mp:
            mp.chdir(tmp_path)
            path = uniq_workspace_dir(root=root, prefix=prefix)
            assert Path(path).exists()

    @pytest.mark.parametrize(
        "root,prefix",
        [
            (".", ""),  # Empty prefix
            ("", "test"),  # Empty root (current dir)
            (".", "a" * 255),  # Long prefix
        ],
    )
    def test_long_prefix_cases(self, root, prefix, tmp_path):
        """Test various edge cases"""
        with pytest.MonkeyPatch.context() as mp:
            mp.chdir(tmp_path)
            try:
                path = uniq_workspace_dir(root=root, prefix=prefix)
                assert Path(path).exists()

                # For long prefixes, verify truncation occurred
                if len(prefix) > 50:
                    assert (
                        len(Path(path).name) <= 50 + 1 + 14
                    )  # prefix + '-' + timestamp
            except OSError as e:
                if "File name too long" in str(e):
                    pytest.skip(f"Filesystem doesn't support long names: {e}")
                raise

    def test_long_prefix_handling(self, tmp_path):
        """Test automatic truncation of long prefixes"""
        long_prefix = "a" * 300
        path = uniq_workspace_dir(root=str(tmp_path), prefix=long_prefix)

        assert Path(path).exists()
        assert len(Path(path).name) <= 65  # 50 (prefix) + 1 (hyphen) + 14 (timestamp)
        assert Path(path).name.startswith("a" * 50)

    def test_permission_denied(self, tmp_path):
        """Test behavior when directory creation fails"""
        read_only_dir = tmp_path / "readonly"
        read_only_dir.mkdir()
        os.chmod(read_only_dir, 0o444)  # Read-only permissions

        with pytest.raises(PermissionError):
            uniq_workspace_dir(root=str(read_only_dir))

    def test_timestamp_format(self, tmp_path):
        """Test the timestamp format in directory name"""
        path = uniq_workspace_dir(root=str(tmp_path))
        timestamp_part = path.split("-")[-1]
        try:
            datetime.datetime.strptime(timestamp_part, "%Y%m%d%H%M%S")
        except ValueError:
            pytest.fail("Timestamp format is incorrect")

    def test_return_type(self, tmp_path):
        """Test that return value is always a string"""
        path = uniq_workspace_dir(root=str(tmp_path))
        assert isinstance(path, str)


class TestConvertXmlToCsv:
    """Test suite for convert_xml_to_csv function"""

    @pytest.fixture
    def sample_xml_content(self):
        """Sample XML content with various test results"""
        return """<?xml version="1.0" encoding="utf-8"?>
<testsuites>
    <testsuite name="pytest" tests="5" failures="1" errors="1" skipped="1" time="10.5">
        <testcase classname="tests.test_example" name="test_success" time="1.5"/>
        <testcase classname="tests.test_example" name="test_failure" time="2.0">
            <failure message="AssertionError: expected 5 but got 3"/>
        </testcase>
        <testcase classname="tests.test_example" name="test_error" time="1.0">
            <error message="ValueError: invalid input"/>
        </testcase>
        <testcase classname="tests.test_example" name="test_skipped" time="0.0">
            <skipped message="Test skipped"/>
        </testcase>
        <testcase classname="tests.test_example" name="test_success2" time="6.0"/>
    </testsuite>
</testsuites>"""

    @pytest.fixture
    def xml_with_root_testsuite(self):
        """XML where root itself is testsuite"""
        return """<?xml version="1.0" encoding="utf-8"?>
<testsuite name="pytest" tests="2" failures="0" errors="0" skipped="0" time="3.0">
    <testcase classname="tests.test_example" name="test_one" time="1.5"/>
    <testcase classname="tests.test_example" name="test_two" time="1.5"/>
</testsuite>"""

    @pytest.fixture
    def xml_with_missing_attributes(self):
        """XML with missing optional attributes"""
        return """<?xml version="1.0" encoding="utf-8"?>
<testsuite tests="2" time="2.0">
    <testcase classname="tests.test_example" name="test_no_attrs" time="1.0"/>
    <testcase name="test_no_classname" time="1.0"/>
</testsuite>"""

    @pytest.fixture
    def invalid_xml_content(self):
        """Invalid XML without testsuite element"""
        return """<?xml version="1.0" encoding="utf-8"?>
<root>
    <invalid>This is not a valid pytest XML</invalid>
</root>"""

    def test_basic_conversion(self, tmp_path, sample_xml_content):
        """Test basic XML to CSV conversion"""
        xml_file = tmp_path / "test.xml"
        csv_file = tmp_path / "output.csv"

        xml_file.write_text(sample_xml_content)

        result = convert_xml_to_csv(str(xml_file), str(csv_file))

        # Verify return statistics
        assert result["total_cases"] == 5
        assert result["success_cases"] == 2
        assert result["failures"] == 1
        assert result["skipped"] == 1
        assert result["total_time"] == 10.5

        # Verify CSV file exists and has correct content
        assert csv_file.exists()

        with open(csv_file, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)

            assert len(rows) == 5
            assert rows[0]["TEST_RESULT"] == "SUCCESS"
            assert rows[1]["TEST_RESULT"] == "FAILURE"
            assert rows[2]["TEST_RESULT"] == "ERROR"
            assert rows[3]["TEST_RESULT"] == "SKIPPED"
            assert rows[4]["TEST_RESULT"] == "SUCCESS"

    def test_root_as_testsuite(self, tmp_path, xml_with_root_testsuite):
        """Test when root element itself is testsuite"""
        xml_file = tmp_path / "root_testsuite.xml"
        csv_file = tmp_path / "output.csv"

        xml_file.write_text(xml_with_root_testsuite)

        result = convert_xml_to_csv(str(xml_file), str(csv_file))

        assert result["total_cases"] == 2
        assert result["success_cases"] == 2
        assert csv_file.exists()

    def test_missing_attributes(self, tmp_path, xml_with_missing_attributes):
        """Test handling of missing optional attributes"""
        xml_file = tmp_path / "missing_attrs.xml"
        csv_file = tmp_path / "output.csv"

        xml_file.write_text(xml_with_missing_attributes)

        result = convert_xml_to_csv(str(xml_file), str(csv_file))

        assert result["total_cases"] == 2
        assert result["failures"] == 0
        assert result["skipped"] == 0

        with open(csv_file, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)

            # Check that empty classname is handled
            assert rows[1]["CASE_CLASSNAME"] == ""

    def test_invalid_xml_format(self, tmp_path, invalid_xml_content):
        """Test error handling for invalid XML format"""
        xml_file = tmp_path / "invalid.xml"
        csv_file = tmp_path / "output.csv"

        xml_file.write_text(invalid_xml_content)

        with pytest.raises(ValueError, match="Invalid XML format"):
            convert_xml_to_csv(str(xml_file), str(csv_file))

    def test_csv_headers(self, tmp_path, sample_xml_content):
        """Test that CSV has correct headers"""
        xml_file = tmp_path / "test.xml"
        csv_file = tmp_path / "output.csv"

        xml_file.write_text(sample_xml_content)
        convert_xml_to_csv(str(xml_file), str(csv_file))

        with open(csv_file, newline="", encoding="utf-8") as f:
            reader = csv.reader(f)
            headers = next(reader)

            assert headers == ["CASE_CLASSNAME", "CASE_NAME", "TIME", "TEST_RESULT", "MESSAGE"]

    def test_failure_message_extraction(self, tmp_path, sample_xml_content):
        """Test that failure messages are correctly extracted"""
        xml_file = tmp_path / "test.xml"
        csv_file = tmp_path / "output.csv"

        xml_file.write_text(sample_xml_content)
        convert_xml_to_csv(str(xml_file), str(csv_file))

        with open(csv_file, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)

            # Check failure message
            assert "AssertionError" in rows[1]["MESSAGE"]
            # Check error message
            assert "ValueError" in rows[2]["MESSAGE"]
            # Check skipped message
            assert "Test skipped" in rows[3]["MESSAGE"]
            # Check success has no message
            assert rows[0]["MESSAGE"] == "-"

    def test_nonexistent_file(self, tmp_path):
        """Test error handling for nonexistent XML file"""
        xml_file = tmp_path / "nonexistent.xml"
        csv_file = tmp_path / "output.csv"

        with pytest.raises(FileNotFoundError):
            convert_xml_to_csv(str(xml_file), str(csv_file))

    def test_malformed_xml(self, tmp_path):
        """Test error handling for malformed XML"""
        xml_file = tmp_path / "malformed.xml"
        csv_file = tmp_path / "output.csv"

        xml_file.write_text("This is not valid XML at all!")

        with pytest.raises(ET.ParseError):
            convert_xml_to_csv(str(xml_file), str(csv_file))

    def test_empty_testsuite(self, tmp_path):
        """Test handling of empty testsuite"""
        xml_content = """<?xml version="1.0" encoding="utf-8"?>
<testsuite tests="0" failures="0" errors="0" skipped="0" time="0.0">
</testsuite>"""

        xml_file = tmp_path / "empty.xml"
        csv_file = tmp_path / "output.csv"

        xml_file.write_text(xml_content)
        result = convert_xml_to_csv(str(xml_file), str(csv_file))

        assert result["total_cases"] == 0
        assert result["success_cases"] == 0

    def test_all_failure_types(self, tmp_path):
        """Test all different failure types are handled correctly"""
        xml_content = """<?xml version="1.0" encoding="utf-8"?>
<testsuite tests="4" failures="1" errors="1" skipped="1" time="4.0">
    <testcase classname="test.example" name="test_fail" time="1.0">
        <failure message="Fail message"/>
    </testcase>
    <testcase classname="test.example" name="test_err" time="1.0">
        <error message="Error message"/>
    </testcase>
    <testcase classname="test.example" name="test_skip" time="1.0">
        <skipped message="Skip message"/>
    </testcase>
    <testcase classname="test.example" name="test_pass" time="1.0"/>
</testsuite>"""

        xml_file = tmp_path / "all_types.xml"
        csv_file = tmp_path / "output.csv"

        xml_file.write_text(xml_content)
        result = convert_xml_to_csv(str(xml_file), str(csv_file))

        assert result["total_cases"] == 4
        assert result["success_cases"] == 1
        assert result["failures"] == 1
        assert result["skipped"] == 1

    def test_time_precision(self, tmp_path):
        """Test that time values are correctly preserved"""
        xml_content = """<?xml version="1.0" encoding="utf-8"?>
<testsuite tests="1" failures="0" errors="0" skipped="0" time="1.234567">
    <testcase classname="test.example" name="test_time" time="1.234567"/>
</testsuite>"""

        xml_file = tmp_path / "time_test.xml"
        csv_file = tmp_path / "output.csv"

        xml_file.write_text(xml_content)
        result = convert_xml_to_csv(str(xml_file), str(csv_file))

        assert result["total_time"] == 1.234567

        with open(csv_file, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            row = next(reader)
            assert row["TIME"] == "1.234567"


class TestGenerateSummaryResult:
    """Test suite for generate_summary_result function"""

    @pytest.fixture
    def sample_case_csv(self, tmp_path):
        """Create a sample case result CSV file"""
        csv_file = tmp_path / "case_result.csv"
        with open(csv_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["CASE_CLASSNAME", "CASE_NAME", "TIME", "TEST_RESULT", "MESSAGE"])
            writer.writerow(["tests.test_example", "test_one", "1.5", "SUCCESS", "-"])
            writer.writerow(["tests.test_example", "test_two", "2.0", "FAILURE", "Failed"])
            writer.writerow(["tests.test_example", "test_three", "1.0", "ERROR", "Error"])
            writer.writerow(["tests.test_example", "test_four", "0.5", "SKIPPED", "Skipped"])
            writer.writerow(["tests.test_example", "test_five", "3.0", "SUCCESS", "-"])
        return csv_file

    def test_basic_summary_generation(self, tmp_path, sample_case_csv):
        """Test basic summary generation"""
        summary_file = tmp_path / "summary.csv"

        generate_summary_result(str(sample_case_csv), str(summary_file))

        # Verify summary file exists
        assert summary_file.exists()

        # Read and verify summary content
        with open(summary_file, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            row = next(reader)

            assert int(row["TOTAL_CASES"]) == 5
            assert int(row["SUCCESS_CASES"]) == 2
            assert int(row["FAILURE_CASES"]) == 2  # ERROR + FAILURE
            assert int(row["SKIPPED_CASES"]) == 1
            assert float(row["TOTAL_TIME"]) == 8.0

    def test_summary_headers(self, tmp_path, sample_case_csv):
        """Test that summary CSV has correct headers"""
        summary_file = tmp_path / "summary.csv"

        generate_summary_result(str(sample_case_csv), str(summary_file))

        with open(summary_file, newline="", encoding="utf-8") as f:
            reader = csv.reader(f)
            headers = next(reader)

            expected_headers = [
                "TOTAL_CASES",
                "SUCCESS_CASES",
                "FAILURE_CASES",
                "SKIPPED_CASES",
                "TOTAL_TIME"
            ]
            assert headers == expected_headers

    def test_empty_case_csv(self, tmp_path):
        """Test handling of empty case CSV"""
        case_file = tmp_path / "empty_case.csv"
        summary_file = tmp_path / "summary.csv"

        # Create empty CSV with only headers
        with open(case_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["CASE_CLASSNAME", "CASE_NAME", "TIME", "TEST_RESULT", "MESSAGE"])

        generate_summary_result(str(case_file), str(summary_file))

        with open(summary_file, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            row = next(reader)

            assert int(row["TOTAL_CASES"]) == 0
            assert int(row["SUCCESS_CASES"]) == 0
            assert int(row["FAILURE_CASES"]) == 0
            assert int(row["SKIPPED_CASES"]) == 0
            assert float(row["TOTAL_TIME"]) == 0.0

    def test_all_success_cases(self, tmp_path):
        """Test summary when all tests pass"""
        case_file = tmp_path / "all_success.csv"
        summary_file = tmp_path / "summary.csv"

        with open(case_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["CASE_CLASSNAME", "CASE_NAME", "TIME", "TEST_RESULT", "MESSAGE"])
            writer.writerow(["tests.test_example", "test_one", "1.0", "SUCCESS", "-"])
            writer.writerow(["tests.test_example", "test_two", "2.0", "SUCCESS", "-"])
            writer.writerow(["tests.test_example", "test_three", "1.5", "SUCCESS", "-"])

        generate_summary_result(str(case_file), str(summary_file))

        with open(summary_file, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            row = next(reader)

            assert int(row["TOTAL_CASES"]) == 3
            assert int(row["SUCCESS_CASES"]) == 3
            assert int(row["FAILURE_CASES"]) == 0
            assert int(row["SKIPPED_CASES"]) == 0

    def test_all_failure_cases(self, tmp_path):
        """Test summary when all tests fail"""
        case_file = tmp_path / "all_failures.csv"
        summary_file = tmp_path / "summary.csv"

        with open(case_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["CASE_CLASSNAME", "CASE_NAME", "TIME", "TEST_RESULT", "MESSAGE"])
            writer.writerow(["tests.test_example", "test_one", "1.0", "FAILURE", "Failed"])
            writer.writerow(["tests.test_example", "test_two", "2.0", "ERROR", "Error"])

        generate_summary_result(str(case_file), str(summary_file))

        with open(summary_file, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            row = next(reader)

            assert int(row["TOTAL_CASES"]) == 2
            assert int(row["SUCCESS_CASES"]) == 0
            assert int(row["FAILURE_CASES"]) == 2

    def test_time_precision_in_summary(self, tmp_path):
        """Test that time is properly summed and formatted"""
        case_file = tmp_path / "time_test.csv"
        summary_file = tmp_path / "summary.csv"

        with open(case_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["CASE_CLASSNAME", "CASE_NAME", "TIME", "TEST_RESULT", "MESSAGE"])
            writer.writerow(["tests.test", "test_one", "1.123", "SUCCESS", "-"])
            writer.writerow(["tests.test", "test_two", "2.456", "SUCCESS", "-"])
            writer.writerow(["tests.test", "test_three", "0.789", "SUCCESS", "-"])

        generate_summary_result(str(case_file), str(summary_file))

        with open(summary_file, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            row = next(reader)

            # Total should be 4.368, formatted to 3 decimal places
            assert float(row["TOTAL_TIME"]) == pytest.approx(4.368, abs=0.001)

    def test_nonexistent_case_file(self, tmp_path):
        """Test error handling for nonexistent case file"""
        case_file = tmp_path / "nonexistent.csv"
        summary_file = tmp_path / "summary.csv"

        with pytest.raises(FileNotFoundError):
            generate_summary_result(str(case_file), str(summary_file))

    def test_integration_with_convert_xml_to_csv(self, tmp_path):
        """Integration test: XML -> case CSV -> summary CSV"""
        xml_content = """<?xml version="1.0" encoding="utf-8"?>
<testsuite tests="3" failures="1" errors="0" skipped="1" time="5.0">
    <testcase classname="test.example" name="test_pass" time="2.0"/>
    <testcase classname="test.example" name="test_fail" time="2.0">
        <failure message="Failed"/>
    </testcase>
    <testcase classname="test.example" name="test_skip" time="1.0">
        <skipped message="Skipped"/>
    </testcase>
</testsuite>"""

        xml_file = tmp_path / "test.xml"
        case_file = tmp_path / "case.csv"
        summary_file = tmp_path / "summary.csv"

        xml_file.write_text(xml_content)

        # Step 1: Convert XML to case CSV
        result = convert_xml_to_csv(str(xml_file), str(case_file))

        # Step 2: Generate summary from case CSV
        generate_summary_result(str(case_file), str(summary_file))

        # Verify summary matches XML statistics
        with open(summary_file, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            row = next(reader)

            assert int(row["TOTAL_CASES"]) == result["total_cases"]
            assert int(row["SUCCESS_CASES"]) == result["success_cases"]
            assert int(row["FAILURE_CASES"]) == result["failures"]
            assert int(row["SKIPPED_CASES"]) == result["skipped"]
            assert float(row["TOTAL_TIME"]) == result["total_time"]

    def test_large_dataset(self, tmp_path):
        """Test with a large number of test cases"""
        case_file = tmp_path / "large_case.csv"
        summary_file = tmp_path / "summary.csv"

        with open(case_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["CASE_CLASSNAME", "CASE_NAME", "TIME", "TEST_RESULT", "MESSAGE"])

            # Generate 1000 test cases
            for i in range(1000):
                result = "SUCCESS" if i % 4 != 0 else "FAILURE"
                writer.writerow([f"test.class{i}", f"test_{i}", "0.1", result, "-"])

        generate_summary_result(str(case_file), str(summary_file))

        with open(summary_file, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            row = next(reader)

            assert int(row["TOTAL_CASES"]) == 1000
            assert int(row["SUCCESS_CASES"]) == 750
            assert int(row["FAILURE_CASES"]) == 250
            assert float(row["TOTAL_TIME"]) == pytest.approx(100.0, abs=0.1)


class TestCheckPackage:
    """Test suite for _check_package function"""
    
    def test_check_package_output(self, capsys):
        """Test that _check_package prints the expected output"""
        from testkit.utils import _check_package

        _check_package()

        captured = capsys.readouterr()
        pattern = r"^Fyre TestKit package is installed with version \d+\.\d+\.\d+ and working correctly\. ;-\)$"

        assert re.match(pattern, captured.out)
        assert "Fyre TestKit package is installed with version" in captured.out


class TestConvertKDToCsv:
    """
    Test suite for convert_kd_to_csv function.

    This validates the KD to CSV conversion with different input formats.
    """

    def create_test_kd_file_format1(self, filepath):
        """Create test KD file with Format 1 (double tabs)."""
        content = """    测试内容		模型维护功能
        测试开始时间	2025-12-24_135033
        总测试用例数	3
        通过用例数		1
        失败用例数		2
        通过率		33%
        测试耗时		6.88秒
    1		失败	模型插入操作成功	关系库入库成功，实时库入库失败
    2		失败	模型更新操作成功	关系库入库成功，实时库入库失败
    3		成功	模型删除操作成功	关系库入库成功，实时库入库成功
    """
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)


    def create_test_kd_file_format2(self, filepath):
        """Create test KD file with Format 2 (multiple spaces)."""
        content = """测试内容                rtdbc-middata测试
    测试开始时间            20251224-140204
    总测试用例数            3
    通过用例数              3
    失败用例数              0
    通过率                  100.00%
    测试耗时                1秒

    1		成功		读全表测试
    2		成功		读多列测试
    3		成功		条件读测试
    """
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)


    def create_test_kd_file_gb2312(self, filepath):
        """Create test KD file with GB2312 encoding."""
        content = """测试内容		数据库测试
    测试开始时间	2025-12-24
    总测试用例数	2
    通过用例数		1
    失败用例数		1
    测试耗时		3.5秒
    1		成功	数据库连接测试	连接成功
    2		失败	数据库查询测试	查询超时
    """
        with open(filepath, 'w', encoding='gb2312') as f:
            f.write(content)


    def verify_csv_output(self, csv_filepath, expected_rows):
        """Verify CSV output matches expected format."""
        with open(csv_filepath, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        
        print(f"\n{'='*60}")
        print(f"CSV Output Verification ({len(rows)} rows)")
        print(f"{'='*60}")
        
        for idx, row in enumerate(rows):
            print(f"\nRow {idx + 1}:")
            print(f"  CASE_CLASSNAME: {row['CASE_CLASSNAME']}")
            print(f"  CASE_NAME: {row['CASE_NAME']}")
            print(f"  TIME: {row['TIME']}")
            print(f"  TEST_RESULT: {row['TEST_RESULT']}")
            print(f"  MESSAGE: {row['MESSAGE']}")
        
        assert len(rows) == expected_rows, f"Expected {expected_rows} rows, got {len(rows)}"
        
        # Verify all required columns exist
        required_columns = ['CASE_CLASSNAME', 'CASE_NAME', 'TIME', 'TEST_RESULT', 'MESSAGE']
        for col in required_columns:
            assert col in rows[0].keys(), f"Missing required column: {col}"
        
        # Verify TIME is 0 for all rows
        for row in rows:
            assert row['TIME'] == '0', f"Expected TIME to be 0, got {row['TIME']}"
        
        print(f"\n✅ CSV verification passed!")
        return rows


    def test_format1(self):
        """Test KD Format 1 (double tabs) conversion."""
        print("\n" + "="*60)
        print("TEST 1: KD Format 1 (模型维护功能)")
        print("="*60)
        
        with tempfile.TemporaryDirectory() as tmpdir:
            kd_file = os.path.join(tmpdir, 'test_format1.kd')
            csv_file = os.path.join(tmpdir, 'case_result.csv')
            
            self.create_test_kd_file_format1(kd_file)
            
            # Convert
            summary = convert_kd_to_csv(kd_file, csv_file)
            
            # Verify summary statistics
            print("\nSummary Statistics:")
            print(f"  Total cases: {summary['total_cases']}")
            print(f"  Success cases: {summary['success_cases']}")
            print(f"  Failures: {summary['failures']}")
            print(f"  Skipped: {summary['skipped']}")
            print(f"  Total time: {summary['total_time']}")
            
            assert summary['total_cases'] == 3
            assert summary['success_cases'] == 1
            assert summary['failures'] == 2
            assert summary['skipped'] == 0
            assert summary['total_time'] == 6.88
            
            # Verify CSV output
            rows = self.verify_csv_output(csv_file, 3)
            
            # Verify specific content
            assert rows[0]['CASE_CLASSNAME'] == 'cases.模型维护功能'
            assert rows[0]['CASE_NAME'] == 'test_模型维护功能_1'
            assert rows[0]['TEST_RESULT'] == 'FAILURE'
            assert '关系库入库成功，实时库入库失败' in rows[0]['MESSAGE']
            
            print("\n✅ Test Format 1 PASSED!")


    def test_format2(self):
        """Test KD Format 2 (multiple spaces) conversion."""
        print("\n" + "="*60)
        print("TEST 2: KD Format 2 (rtdbc-middata测试)")
        print("="*60)
        
        with tempfile.TemporaryDirectory() as tmpdir:
            kd_file = os.path.join(tmpdir, 'test_format2.kd')
            csv_file = os.path.join(tmpdir, 'case_result.csv')
            
            self.create_test_kd_file_format2(kd_file)
            
            # Convert
            summary = convert_kd_to_csv(kd_file, csv_file)
            
            # Verify summary statistics
            print("\nSummary Statistics:")
            print(f"  Total cases: {summary['total_cases']}")
            print(f"  Success cases: {summary['success_cases']}")
            print(f"  Failures: {summary['failures']}")
            print(f"  Skipped: {summary['skipped']}")
            print(f"  Total time: {summary['total_time']}")
            
            assert summary['total_cases'] == 3
            assert summary['success_cases'] == 3
            assert summary['failures'] == 0
            assert summary['skipped'] == 0
            assert summary['total_time'] == 1.0
            
            # Verify CSV output
            rows = self.verify_csv_output(csv_file, 3)
            
            # Verify specific content
            assert rows[0]['CASE_CLASSNAME'] == 'cases.rtdbc-middata测试'
            assert rows[0]['CASE_NAME'] == 'test_rtdbc-middata测试_1'
            assert rows[0]['TEST_RESULT'] == 'SUCCESS'
            assert rows[0]['MESSAGE'] == '读全表测试'
            
            print("\n✅ Test Format 2 PASSED!")


    def test_gb2312_encoding(self):
        """Test GB2312 encoding support."""
        print("\n" + "="*60)
        print("TEST 3: GB2312 Encoding Support")
        print("="*60)
        
        with tempfile.TemporaryDirectory() as tmpdir:
            kd_file = os.path.join(tmpdir, 'test_gb2312.kd')
            csv_file = os.path.join(tmpdir, 'case_result.csv')
            
            self.create_test_kd_file_gb2312(kd_file)
            
            # Convert
            summary = convert_kd_to_csv(kd_file, csv_file)
            
            # Verify summary statistics
            print("\nSummary Statistics:")
            print(f"  Total cases: {summary['total_cases']}")
            print(f"  Success cases: {summary['success_cases']}")
            print(f"  Failures: {summary['failures']}")
            print(f"  Total time: {summary['total_time']}")
            
            assert summary['total_cases'] == 2
            assert summary['success_cases'] == 1
            assert summary['failures'] == 1
            assert summary['total_time'] == 3.5
            
            # Verify CSV output
            rows = self.verify_csv_output(csv_file, 2)
            
            assert rows[0]['CASE_CLASSNAME'] == 'cases.数据库测试'
            assert rows[1]['TEST_RESULT'] == 'FAILURE'
            
            print("\n✅ Test GB2312 Encoding PASSED!")


    def test_edge_cases(self):
        """Test edge cases and error handling."""
        print("\n" + "="*60)
        print("TEST 4: Edge Cases & Error Handling")
        print("="*60)
        
        with tempfile.TemporaryDirectory() as tmpdir:
            # Test missing mandatory field
            kd_file = os.path.join(tmpdir, 'test_invalid.kd')
            csv_file = os.path.join(tmpdir, 'case_result.csv')
            
            # Create KD file without 测试内容
            with open(kd_file, 'w', encoding='utf-8') as f:
                f.write("""测试开始时间	2025-12-24
    总测试用例数	1
    1		成功	测试用例
    """)
            
            try:
                convert_kd_to_csv(kd_file, csv_file)
                assert False, "Should have raised ValueError for missing 测试内容"
            except ValueError as e:
                print(f"✅ Correctly raised ValueError: {e}")
            
            print("\n✅ Edge Cases Test PASSED!")

    def test_unsupported_encoding(self):
        """Test handling of files with unsupported encoding.
        
        Coverage: Line 144 - UnicodeDecodeError when both UTF-8 and GB2312 fail.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            kd_file = os.path.join(tmpdir, 'test_invalid_encoding.kd')
            csv_file = os.path.join(tmpdir, 'case_result.csv')
            
            # Create a file with UTF-16 encoding that will fail UTF-8 and GB2312
            with open(kd_file, 'wb') as f:
                # Write bytes that are invalid in both UTF-8 and GB2312
                f.write(b'\xff\xfe' + '测试内容\t\t测试\n'.encode('utf-16-le'))
            
            # Should raise UnicodeDecodeError
            with pytest.raises(UnicodeDecodeError) as excinfo:
                convert_kd_to_csv(kd_file, csv_file)
            
            assert 'Failed to decode KD file' in str(excinfo.value)


    def test_invalid_time_format(self):
        """Test handling of invalid time format.
        
        Coverage: Lines 193-194 - ValueError exception when parsing time fails.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            kd_file = os.path.join(tmpdir, 'test_invalid_time.kd')
            csv_file = os.path.join(tmpdir, 'case_result.csv')
            
            # Create KD file with invalid time format
            content = """测试内容		测试项目
    总测试用例数	1
    通过用例数		1
    失败用例数		0
    测试耗时		invalid_time秒
    1		成功	测试用例1	测试描述
    """
            with open(kd_file, 'w', encoding='utf-8') as f:
                f.write(content)
            
            # Should handle invalid time gracefully and set to 0.0
            summary = convert_kd_to_csv(kd_file, csv_file)
            assert summary['total_time'] == 0.0


    def test_empty_lines_in_test_cases(self):
        """Test handling of empty lines in test case section.
        
        Coverage: Line 210/212 - Empty lines and non-digit starting lines.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            kd_file = os.path.join(tmpdir, 'test_empty_lines.kd')
            csv_file = os.path.join(tmpdir, 'case_result.csv')
            
            # Create KD file with empty lines and comments
            content = """测试内容		测试项目
    总测试用例数	2
    通过用例数		2
    失败用例数		0
    测试耗时		2秒
    1		成功	测试用例1	描述1

    # This is a comment line
            
    2		成功	测试用例2	描述2
    """
            with open(kd_file, 'w', encoding='utf-8') as f:
                f.write(content)
            
            summary = convert_kd_to_csv(kd_file, csv_file)
            assert summary['total_cases'] == 2
            
            # Verify CSV has exactly 2 data rows
            with open(csv_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                assert len(rows) == 2


    def test_regex_separator_split(self):
        """Test regex-based separator splitting.
        
        Coverage: Line 220 - Regex split fallback for multiple spaces.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            kd_file = os.path.join(tmpdir, 'test_regex_split.kd')
            csv_file = os.path.join(tmpdir, 'case_result.csv')
            
            # Create KD file with multiple spaces (not tabs)
            content = """测试内容                空格分隔测试
    总测试用例数            2
    通过用例数              2
    失败用例数              0
    测试耗时                1.5秒
    1    成功    测试用例    这是描述
    2    失败    测试用例2   这是描述2
    """
            with open(kd_file, 'w', encoding='utf-8') as f:
                f.write(content)
            
            summary = convert_kd_to_csv(kd_file, csv_file)
            assert summary['total_cases'] == 2
            
            # Verify the CSV was created correctly
            with open(csv_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                assert len(rows) == 2
                assert rows[0]['CASE_NAME'] == 'test_空格分隔测试_1'
                assert rows[0]['TEST_RESULT'] == 'SUCCESS'


    def test_malformed_test_case_lines(self):
        """Test handling of malformed test case lines.
        
        Coverage: Line 222 - Skip lines with fewer than 3 parts.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            kd_file = os.path.join(tmpdir, 'test_malformed.kd')
            csv_file = os.path.join(tmpdir, 'case_result.csv')
            
            # Create KD file with malformed lines
            content = """测试内容		格式测试
    总测试用例数	3
    通过用例数		2
    失败用例数		0
    测试耗时		2秒
    1		成功	正常用例	正常描述
    2		缺少描述
    3	只有编号
    4		成功	正常用例2	正常描述2
    """
            with open(kd_file, 'w', encoding='utf-8') as f:
                f.write(content)
            
            summary = convert_kd_to_csv(kd_file, csv_file)
            
            # Verify only valid lines were processed
            with open(csv_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                # Only cases 1 and 4 should be present
                assert len(rows) == 2
                assert rows[0]['CASE_NAME'] == 'test_格式测试_1'
                assert rows[1]['CASE_NAME'] == 'test_格式测试_4'


    def test_unknown_status_mapping(self):
        """Test handling of unknown status values.
        
        Coverage: Line 240 - UNKNOWN result mapping.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            kd_file = os.path.join(tmpdir, 'test_unknown_status.kd')
            csv_file = os.path.join(tmpdir, 'case_result.csv')
            
            # Create KD file with various status values
            content = """测试内容		状态测试
    总测试用例数	5
    通过用例数		1
    失败用例数		1
    测试耗时		5秒
    1		成功	成功案例	正常成功
    2		失败	失败案例	正常失败
    3		跳过	跳过案例	这个被跳过了
    4		警告	警告案例	有警告
    5		未知	未知案例	未知状态
    """
            with open(kd_file, 'w', encoding='utf-8') as f:
                f.write(content)
            
            summary = convert_kd_to_csv(kd_file, csv_file)
            
            # Verify all cases were processed
            with open(csv_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                assert len(rows) == 5
                
                # Check status mappings
                assert rows[0]['TEST_RESULT'] == 'SUCCESS'
                assert rows[1]['TEST_RESULT'] == 'FAILURE'
                assert rows[2]['TEST_RESULT'] == 'UNKNOWN'  # 跳过
                assert rows[3]['TEST_RESULT'] == 'UNKNOWN'  # 警告
                assert rows[4]['TEST_RESULT'] == 'UNKNOWN'  # 未知


    def test_time_without_seconds_suffix(self):
        """Test time parsing without '秒' suffix.
        
        Coverage: Lines 191-194 - Time parsing alternative path.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            kd_file = os.path.join(tmpdir, 'test_time_no_suffix.kd')
            csv_file = os.path.join(tmpdir, 'case_result.csv')
            
            # Create KD file with time without '秒' suffix
            content = """测试内容		时间测试
    总测试用例数	1
    通过用例数		1
    失败用例数		0
    测试耗时		7.25
    1		成功	测试用例	描述
    """
            with open(kd_file, 'w', encoding='utf-8') as f:
                f.write(content)
            
            summary = convert_kd_to_csv(kd_file, csv_file)
            assert summary['total_time'] == 7.25


    def test_combined_edge_cases(self):
        """Comprehensive test combining multiple edge cases.
        
        Coverage: Multiple lines - Ensures all edge cases work together.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            kd_file = os.path.join(tmpdir, 'test_combined.kd')
            csv_file = os.path.join(tmpdir, 'case_result.csv')
            
            # Complex KD file with various edge cases
            content = """测试内容    综合测试
    总测试用例数    10
    通过用例数      5
    失败用例数      3
    测试耗时        15.75秒

    1    成功    案例1    描述1

    2    失败    案例2    描述2
    # Comment
    3		仅两部分
    4    跳过    案例3    跳过了
            
    5    成功    案例4    描述5
    6		缺少内容
    7    警告    案例5    警告
    8    成功    案例6    描述8
    9		错误	案例7	错误
    10   成功    案例8    描述10
    """
            with open(kd_file, 'w', encoding='utf-8') as f:
                f.write(content)
            
            summary = convert_kd_to_csv(kd_file, csv_file)
            
            # Verify summary
            assert summary['total_cases'] == 10
            assert summary['success_cases'] == 5
            assert summary['failures'] == 3
            assert summary['total_time'] == 15.75
            
            # Verify CSV content
            with open(csv_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                
                # Valid lines: 1, 2, 4, 5, 7, 8, 9, 10 (skip 3, 6)
                assert len(rows) == 8
                
                # Verify status mappings
                success_count = sum(1 for row in rows if row['TEST_RESULT'] == 'SUCCESS')
                failure_count = sum(1 for row in rows if row['TEST_RESULT'] == 'FAILURE')
                unknown_count = sum(1 for row in rows if row['TEST_RESULT'] == 'UNKNOWN')
                
                assert success_count == 4  # Cases 1, 5, 8, 10
                assert failure_count == 1  # Cases 2,
                assert unknown_count == 3  # Cases 4, 7, 9
