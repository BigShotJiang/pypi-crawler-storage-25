import pytest
from unittest.mock import patch
import yaml
from pydantic import ValidationError

from testkit.schema import TestSuite
from testkit.parser import _load_yaml_file, load_and_validate_yaml


# --- Test cases for _load_yaml_file ---
class TestLoadYamlFile:
    def test_load_valid_file(self, valid_yaml_file):
        """Test loading a valid YAML file"""

        result = _load_yaml_file(valid_yaml_file)
        assert "test_suite" in result
        assert result["test_suite"]["metadata"]["name"] == "Test Suite"

    def test_file_not_found(self):
        """Test with non-existent file"""
        with pytest.raises(FileNotFoundError):
            _load_yaml_file("nonexistent.yaml")

    def test_invalid_yaml(self, tmp_path):
        """Test with invalid YAML content"""
        test_file = tmp_path / "invalid.yaml"
        test_file.write_text("invalid: yaml: [")
        
        with pytest.raises(yaml.YAMLError):
            _load_yaml_file(str(test_file))

# --- Test cases for load_and_validate_yaml ---
class TestLoadAndValidateYaml:
    @patch("testkit.parser._load_yaml_file")
    def test_successful_validation(self, mock_load, valid_yaml_file):
        """Test successful YAML validation"""
        result = _load_yaml_file(valid_yaml_file)
        mock_load.return_value = {"test_suite": yaml.safe_load(yaml.dump(result))["test_suite"]}

        result = load_and_validate_yaml("dummy.yaml")
        assert isinstance(result, TestSuite)
        assert result.metadata.name == "Test Suite"

    @patch("testkit.parser._load_yaml_file")
    def test_missing_test_suite_key(self, mock_load):
        """Test YAML missing test_suite root key"""
        mock_load.return_value = {"wrong_key": {}}
        
        with pytest.raises(ValueError, match="Root key 'test_suite' not found"):
            load_and_validate_yaml("invalid.yaml")

    @patch("testkit.parser._load_yaml_file")
    def test_validation_error(self, mock_load, invalid_yaml_file):
        """Test schema validation failure"""
        result = _load_yaml_file(invalid_yaml_file)
        mock_load.return_value = {"test_suite": yaml.safe_load(yaml.dump(result))["test_suite"]}
        
        with pytest.raises(ValidationError):
            load_and_validate_yaml("invalid.yaml")

    @patch("pathlib.Path.exists", return_value=False)
    def test_file_not_found_propagation(self, mock_exists):
        """Test FileNotFoundError propagation"""
        with pytest.raises(FileNotFoundError):
            load_and_validate_yaml("nonexistent.yaml")

def test_integration_with_real_file(valid_yaml_file):
    """Integration test with actual file I/O"""

    result = load_and_validate_yaml(str(valid_yaml_file))
    assert result.metadata.name == "Test Suite"
    assert len(result.test_cases) == 1

def test_integration_with_multiple_cases(multicase_yaml_file):
    """Integration multiple test cases with actual file I/O"""

    result = load_and_validate_yaml(str(multicase_yaml_file))
    assert result.metadata.name == "Test Suite"
    assert len(result.test_cases) == 3
