import pytest
import tempfile
import os
import yaml
from testkit.validator import YAMLSchemaValidator


class TestYAMLSchemaValidator:
    """Test suite for YAMLSchemaValidator class."""
    
    @pytest.fixture
    def validator(self):
        """Create a fresh validator instance for each test."""
        return YAMLSchemaValidator()
    
    @pytest.fixture
    def valid_yaml_content(self):
        """Return a valid YAML structure."""
        return {
            'test_suite': {
                'metadata': {
                    'name': 'Test Suite Name',
                    'component': ['feature1', 'feature2'],
                    'tags': ['tag1', 'tag2']
                },
                'test_cases': [
                    {
                        'name': 'test_case_1',
                        'description': 'Test case description',
                        'metadata': {
                            'components': ['function1'],
                            'enable': True,
                            'tags': ['unit']
                        },
                        'pre_conditions': {
                            'setup_command': [
                                {
                                    'executable': '/usr/bin/setup',
                                    'args': ['--init', '--verbose']
                                }
                            ]
                        },
                        'steps': [
                            {
                                'command': {
                                    'executable': '/usr/bin/test',
                                    'args': ['--run']
                                },
                                'timeout_sec': 30,
                                'expectations': {
                                    'exit_code': 0,
                                    'keywords': ['pass', 'success']
                                }
                            }
                        ],
                        'post_conditions': {
                            'cleanup_command': [
                                {
                                    'executable': '/usr/bin/cleanup',
                                    'args': ['--remove']
                                }
                            ]
                        }
                    }
                ]
            }
        }
    
    @pytest.fixture
    def temp_yaml_file(self, valid_yaml_content):
        """Create a temporary YAML file with valid content."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(valid_yaml_content, f)
            temp_file = f.name
        yield temp_file
        os.unlink(temp_file)
    
    # Test validate_string
    def test_validate_string_valid(self, validator):
        """Test validate_string with valid string."""
        assert validator.validate_string("test_string", "field_name") == True
        assert len(validator.errors) == 0
    
    def test_validate_string_invalid_type(self, validator):
        """Test validate_string with non-string type."""
        assert validator.validate_string(123, "field_name") == False
        assert len(validator.errors) == 1
        assert "must be a string" in validator.errors[0]
    
    def test_validate_string_with_spaces_allowed(self, validator):
        """Test validate_string with spaces when allowed."""
        assert validator.validate_string("test string", "field_name", no_spaces=False) == True
        assert len(validator.errors) == 0
    
    def test_validate_string_with_spaces_not_allowed(self, validator):
        """Test validate_string with spaces when not allowed."""
        assert validator.validate_string("test string", "field_name", no_spaces=True) == False
        assert len(validator.errors) == 1
        assert "cannot contain blank spaces" in validator.errors[0]
    
    # Test validate_array
    def test_validate_array_valid(self, validator):
        """Test validate_array with valid array of strings."""
        assert validator.validate_array(["item1", "item2"], "field_name") == True
        assert len(validator.errors) == 0
    
    def test_validate_array_invalid_type(self, validator):
        """Test validate_array with non-array type."""
        assert validator.validate_array("not_an_array", "field_name") == False
        assert len(validator.errors) == 1
        assert "must be an array" in validator.errors[0]
    
    def test_validate_array_invalid_element_type(self, validator):
        """Test validate_array with wrong element type."""
        assert validator.validate_array([1, 2, 3], "field_name", element_type=str) == False
        assert len(validator.errors) == 1
        assert "must be str" in validator.errors[0]
    
    def test_validate_array_empty(self, validator):
        """Test validate_array with empty array."""
        assert validator.validate_array([], "field_name") == True
        assert len(validator.errors) == 0
    
    # Test validate_int
    def test_validate_int_valid(self, validator):
        """Test validate_int with valid integer."""
        assert validator.validate_int(42, "field_name") == True
        assert len(validator.errors) == 0
    
    def test_validate_int_invalid_type(self, validator):
        """Test validate_int with non-integer type."""
        assert validator.validate_int("123", "field_name") == False
        assert len(validator.errors) == 1
        assert "must be an integer" in validator.errors[0]
    
    def test_validate_int_boolean_rejected(self, validator):
        """Test validate_int rejects boolean (which is subclass of int in Python)."""
        assert validator.validate_int(True, "field_name") == False
        assert len(validator.errors) == 1
    
    # Test validate_bool
    def test_validate_bool_valid(self, validator):
        """Test validate_bool with valid boolean."""
        assert validator.validate_bool(True, "field_name") == True
        assert len(validator.errors) == 0
    
    def test_validate_bool_invalid_type(self, validator):
        """Test validate_bool with non-boolean type."""
        assert validator.validate_bool(1, "field_name") == False
        assert len(validator.errors) == 1
        assert "must be a boolean" in validator.errors[0]
    
    # Test check_field_exists and get_nested_value
    def test_check_field_exists_valid(self, validator):
        """Test check_field_exists with existing field."""
        data = {'level1': {'level2': {'level3': 'value'}}}
        assert validator.check_field_exists(data, "level1.level2.level3") == True
        assert len(validator.errors) == 0
    
    def test_check_field_exists_missing(self, validator):
        """Test check_field_exists with missing field."""
        data = {'level1': {'level2': {}}}
        assert validator.check_field_exists(data, "level1.level2.level3") == False
        assert len(validator.errors) == 1
        assert "is missing" in validator.errors[0]
    
    def test_check_field_exists_with_parent_path(self, validator):
        """Test check_field_exists with parent path."""
        data = {'field': 'value'}
        assert validator.check_field_exists(data, "field", parent_path="root") == True
    
    def test_get_nested_value_valid(self, validator):
        """Test get_nested_value with existing nested field."""
        data = {'level1': {'level2': {'level3': 'value'}}}
        assert validator.get_nested_value(data, "level1.level2.level3") == 'value'
    
    def test_get_nested_value_missing(self, validator):
        """Test get_nested_value with missing field."""
        data = {'level1': {'level2': {}}}
        assert validator.get_nested_value(data, "level1.level2.level3") is None
    
    # Test validate_metadata
    def test_validate_metadata_valid(self, validator):
        """Test validate_metadata with valid metadata."""
        metadata = {
            'name': 'Test Name',
            'component': ['comp1', 'comp2'],
            'tags': ['tag1']
        }
        assert validator.validate_metadata(metadata) == True
        assert len(validator.errors) == 0
    
    def test_validate_metadata_missing_name(self, validator):
        """Test validate_metadata with missing name."""
        metadata = {
            'component': ['comp1'],
            'tags': ['tag1']
        }
        assert validator.validate_metadata(metadata) == False
        assert any("name" in error and "missing" in error for error in validator.errors)
    
    def test_validate_metadata_missing_component(self, validator):
        """Test validate_metadata with missing component."""
        metadata = {
            'name': 'Test',
            'tags': ['tag1']
        }
        assert validator.validate_metadata(metadata) == False
        assert any("component" in error and "missing" in error for error in validator.errors)
    
    def test_validate_metadata_missing_tags(self, validator):
        """Test validate_metadata with missing tags."""
        metadata = {
            'name': 'Test',
            'component': ['comp1']
        }
        assert validator.validate_metadata(metadata) == False
        assert any("tags" in error and "missing" in error for error in validator.errors)
    
    def test_validate_metadata_invalid_types(self, validator):
        """Test validate_metadata with invalid types."""
        metadata = {
            'name': 123,
            'component': 'not_array',
            'tags': 'not_array'
        }
        assert validator.validate_metadata(metadata) == False
        assert len(validator.errors) >= 3
    
    # Test validate_setup_command
    def test_validate_setup_command_valid(self, validator):
        """Test validate_setup_command with valid setup commands."""
        commands = [
            {'executable': '/usr/bin/setup', 'args': ['--init']}
        ]
        assert validator.validate_setup_command(commands, "path") == True
        assert len(validator.errors) == 0
    
    def test_validate_setup_command_not_array(self, validator):
        """Test validate_setup_command with non-array."""
        assert validator.validate_setup_command("not_array", "path") == False
        assert any("must be an array" in error for error in validator.errors)
    
    def test_validate_setup_command_missing_executable(self, validator):
        """Test validate_setup_command with missing executable."""
        commands = [{'args': ['--init']}]
        assert validator.validate_setup_command(commands, "path") == False
        assert any("executable" in error and "missing" in error for error in validator.errors)
    
    def test_validate_setup_command_missing_args(self, validator):
        """Test validate_setup_command with missing args."""
        commands = [{'executable': '/usr/bin/setup'}]
        assert validator.validate_setup_command(commands, "path") == False
        assert any("args" in error and "missing" in error for error in validator.errors)
    
    def test_validate_setup_command_executable_with_spaces(self, validator):
        """Test validate_setup_command with executable containing spaces."""
        commands = [{'executable': '/usr/bin/set up', 'args': []}]
        assert validator.validate_setup_command(commands, "path") == False
        assert any("blank spaces" in error for error in validator.errors)
    
    # Test validate_steps
    def test_validate_steps_valid(self, validator):
        """Test validate_steps with valid steps."""
        steps = [
            {
                'command': {
                    'executable': '/usr/bin/test',
                    'args': ['--run']
                },
                'timeout_sec': 30,
                'expectations': {
                    'exit_code': 0,
                    'keywords': ['pass']
                }
            }
        ]
        assert validator.validate_steps(steps, "path") == True
        assert len(validator.errors) == 0
    
    def test_validate_steps_not_array(self, validator):
        """Test validate_steps with non-array."""
        assert validator.validate_steps("not_array", "path") == False
        assert any("must be an array" in error for error in validator.errors)
    
    def test_validate_steps_missing_command(self, validator):
        """Test validate_steps with missing command."""
        steps = [{'timeout_sec': 30}]
        assert validator.validate_steps(steps, "path") == False
        assert any("command" in error and "missing" in error for error in validator.errors)
    
    def test_validate_steps_missing_executable(self, validator):
        """Test validate_steps with missing command.executable."""
        steps = [
            {
                'command': {'args': []},
                'expectations': {'exit_code': 0, 'keywords': []}
            }
        ]
        assert validator.validate_steps(steps, "path") == False
        assert any("executable" in error and "missing" in error for error in validator.errors)
    
    def test_validate_steps_missing_args(self, validator):
        """Test validate_steps with missing command.args."""
        steps = [
            {
                'command': {'executable': '/usr/bin/test'},
                'expectations': {'exit_code': 0, 'keywords': []}
            }
        ]
        assert validator.validate_steps(steps, "path") == False
        assert any("args" in error and "missing" in error for error in validator.errors)
    
    def test_validate_steps_missing_expectations(self, validator):
        """Test validate_steps with missing expectations."""
        steps = [
            {
                'command': {'executable': '/usr/bin/test', 'args': []}
            }
        ]
        assert validator.validate_steps(steps, "path") == False
        assert any("expectations" in error and "missing" in error for error in validator.errors)
    
    def test_validate_steps_missing_exit_code(self, validator):
        """Test validate_steps with missing exit_code."""
        steps = [
            {
                'command': {'executable': '/usr/bin/test', 'args': []},
                'expectations': {'keywords': ['pass']}
            }
        ]
        assert validator.validate_steps(steps, "path") == False
        assert any("exit_code" in error and "missing" in error for error in validator.errors)
    
    def test_validate_steps_missing_keywords(self, validator):
        """Test validate_steps with missing keywords."""
        steps = [
            {
                'command': {'executable': '/usr/bin/test', 'args': []},
                'expectations': {'exit_code': 0}
            }
        ]
        assert validator.validate_steps(steps, "path") == False
        assert any("keywords" in error and "missing" in error for error in validator.errors)
    
    def test_validate_steps_invalid_timeout_type(self, validator):
        """Test validate_steps with invalid timeout_sec type."""
        steps = [
            {
                'command': {'executable': '/usr/bin/test', 'args': []},
                'timeout_sec': "not_int",
                'expectations': {'exit_code': 0, 'keywords': []}
            }
        ]
        validator.validate_steps(steps, "path")
        assert any("timeout_sec" in error for error in validator.errors)
    
    def test_validate_steps_executable_with_spaces(self, validator):
        """Test validate_steps with executable containing spaces."""
        steps = [
            {
                'command': {'executable': '/usr/bin/te st', 'args': []},
                'expectations': {'exit_code': 0, 'keywords': []}
            }
        ]
        assert validator.validate_steps(steps, "path") == False
        assert any("blank spaces" in error for error in validator.errors)
    
    # Test validate_cleanup_command
    def test_validate_cleanup_command_valid(self, validator):
        """Test validate_cleanup_command with valid commands."""
        commands = [
            {'executable': '/usr/bin/cleanup', 'args': ['--remove']}
        ]
        assert validator.validate_cleanup_command(commands, "path") == True
        assert len(validator.errors) == 0
    
    def test_validate_cleanup_command_not_array(self, validator):
        """Test validate_cleanup_command with non-array."""
        assert validator.validate_cleanup_command("not_array", "path") == False
        assert any("must be an array" in error for error in validator.errors)
    
    def test_validate_cleanup_command_missing_fields(self, validator):
        """Test validate_cleanup_command with missing fields."""
        commands = [{}]
        assert validator.validate_cleanup_command(commands, "path") == False
        assert len(validator.errors) >= 2
    
    # Test validate_test_case
    def test_validate_test_case_valid(self, validator):
        """Test validate_test_case with valid test case."""
        test_case = {
            'name': 'test_1',
            'description': 'Test description',
            'metadata': {
                'components': ['comp1'],
                'enable': True,
                'tags': ['tag1']
            },
            'pre_conditions': {
                'setup_command': [
                    {'executable': '/usr/bin/setup', 'args': []}
                ]
            },
            'steps': [
                {
                    'command': {'executable': '/usr/bin/test', 'args': []},
                    'expectations': {'exit_code': 0, 'keywords': []}
                }
            ],
            'post_conditions': {
                'cleanup_command': [
                    {'executable': '/usr/bin/cleanup', 'args': []}
                ]
            }
        }
        assert validator.validate_test_case(test_case, 0) == True
        assert len(validator.errors) == 0
    
    def test_validate_test_case_missing_name(self, validator):
        """Test validate_test_case with missing name."""
        test_case = {
            'pre_conditions': {'setup_command': [{'executable': 'cmd', 'args': []}]},
            'steps': [{'command': {'executable': 'cmd', 'args': []}, 'expectations': {'exit_code': 0, 'keywords': []}}],
            'post_conditions': {'cleanup_command': [{'executable': 'cmd', 'args': []}]}
        }
        assert validator.validate_test_case(test_case, 0) == False
        assert any("name" in error and "missing" in error for error in validator.errors)
    
    def test_validate_test_case_missing_pre_conditions(self, validator):
        """Test validate_test_case with missing pre_conditions."""
        test_case = {
            'name': 'test_1',
            'steps': [{'command': {'executable': 'cmd', 'args': []}, 'expectations': {'exit_code': 0, 'keywords': []}}],
            'post_conditions': {'cleanup_command': [{'executable': 'cmd', 'args': []}]}
        }
        assert validator.validate_test_case(test_case, 0) == False
        assert any("pre_conditions" in error and "missing" in error for error in validator.errors)
    
    def test_validate_test_case_missing_setup_command(self, validator):
        """Test validate_test_case with missing setup_command."""
        test_case = {
            'name': 'test_1',
            'pre_conditions': {},
            'steps': [{'command': {'executable': 'cmd', 'args': []}, 'expectations': {'exit_code': 0, 'keywords': []}}],
            'post_conditions': {'cleanup_command': [{'executable': 'cmd', 'args': []}]}
        }
        assert validator.validate_test_case(test_case, 0) == False
        assert any("setup_command" in error and "missing" in error for error in validator.errors)
    
    def test_validate_test_case_missing_steps(self, validator):
        """Test validate_test_case with missing steps."""
        test_case = {
            'name': 'test_1',
            'pre_conditions': {'setup_command': [{'executable': 'cmd', 'args': []}]},
            'post_conditions': {'cleanup_command': [{'executable': 'cmd', 'args': []}]}
        }
        assert validator.validate_test_case(test_case, 0) == False
        assert any("steps" in error and "missing" in error for error in validator.errors)
    
    def test_validate_test_case_missing_post_conditions(self, validator):
        """Test validate_test_case with missing post_conditions."""
        test_case = {
            'name': 'test_1',
            'pre_conditions': {'setup_command': [{'executable': 'cmd', 'args': []}]},
            'steps': [{'command': {'executable': 'cmd', 'args': []}, 'expectations': {'exit_code': 0, 'keywords': []}}]
        }
        assert validator.validate_test_case(test_case, 0) == False
        assert any("post_conditions" in error and "missing" in error for error in validator.errors)
    
    def test_validate_test_case_missing_cleanup_command(self, validator):
        """Test validate_test_case with missing cleanup_command."""
        test_case = {
            'name': 'test_1',
            'pre_conditions': {'setup_command': [{'executable': 'cmd', 'args': []}]},
            'steps': [{'command': {'executable': 'cmd', 'args': []}, 'expectations': {'exit_code': 0, 'keywords': []}}],
            'post_conditions': {}
        }
        assert validator.validate_test_case(test_case, 0) == False
        assert any("cleanup_command" in error and "missing" in error for error in validator.errors)
    
    def test_validate_test_case_with_optional_metadata(self, validator):
        """Test validate_test_case with optional metadata fields."""
        test_case = {
            'name': 'test_1',
            'description': 'Test',
            'metadata': {
                'components': ['comp1'],
                'enable': True,
                'tags': ['tag1']
            },
            'pre_conditions': {'setup_command': [{'executable': 'cmd', 'args': []}]},
            'steps': [{'command': {'executable': 'cmd', 'args': []}, 'expectations': {'exit_code': 0, 'keywords': []}}],
            'post_conditions': {'cleanup_command': [{'executable': 'cmd', 'args': []}]}
        }
        assert validator.validate_test_case(test_case, 0) == True
    
    def test_validate_test_case_invalid_metadata_types(self, validator):
        """Test validate_test_case with invalid metadata types."""
        test_case = {
            'name': 'test_1',
            'metadata': {
                'components': 'not_array',
                'enable': 'not_bool',
                'tags': 'not_array'
            },
            'pre_conditions': {'setup_command': [{'executable': 'cmd', 'args': []}]},
            'steps': [{'command': {'executable': 'cmd', 'args': []}, 'expectations': {'exit_code': 0, 'keywords': []}}],
            'post_conditions': {'cleanup_command': [{'executable': 'cmd', 'args': []}]}
        }
        validator.validate_test_case(test_case, 0)
        assert len(validator.errors) >= 3
    
    # Test validate (main method)
    def test_validate_valid_file(self, validator, temp_yaml_file):
        """Test validate with valid YAML file."""
        assert validator.validate(temp_yaml_file) == True
        assert len(validator.errors) == 0
    
    def test_validate_file_not_found(self, validator):
        """Test validate with non-existent file."""
        assert validator.validate("nonexistent.yaml") == False
        assert any("File not found" in error for error in validator.errors)
    
    def test_validate_invalid_yaml(self, validator):
        """Test validate with invalid YAML syntax."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write("invalid: yaml: content:")
            temp_file = f.name
        
        try:
            assert validator.validate(temp_file) == False
            assert any("YAML parsing error" in error for error in validator.errors)
        finally:
            os.unlink(temp_file)
    
    def test_validate_root_not_dict(self, validator):
        """Test validate with root element not being a dictionary."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(["not", "a", "dict"], f)
            temp_file = f.name
        
        try:
            assert validator.validate(temp_file) == False
            assert any("must be a dictionary" in error for error in validator.errors)
        finally:
            os.unlink(temp_file)
    
    def test_validate_missing_test_suite(self, validator):
        """Test validate with missing test_suite."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump({'other_key': 'value'}, f)
            temp_file = f.name
        
        try:
            assert validator.validate(temp_file) == False
            assert any("test_suite" in error and "missing" in error for error in validator.errors)
        finally:
            os.unlink(temp_file)
    
    def test_validate_missing_metadata(self, validator):
        """Test validate with missing metadata."""
        data = {
            'test_suite': {
                'test_cases': []
            }
        }
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(data, f)
            temp_file = f.name
        
        try:
            assert validator.validate(temp_file) == False
            assert any("metadata" in error and "missing" in error for error in validator.errors)
        finally:
            os.unlink(temp_file)
    
    def test_validate_missing_test_cases(self, validator):
        """Test validate with missing test_cases."""
        data = {
            'test_suite': {
                'metadata': {
                    'name': 'Test',
                    'component': ['comp'],
                    'tags': ['tag']
                }
            }
        }
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(data, f)
            temp_file = f.name
        
        try:
            assert validator.validate(temp_file) == False
            assert any("test_cases" in error and "missing" in error for error in validator.errors)
        finally:
            os.unlink(temp_file)
    
    def test_validate_test_cases_not_array(self, validator):
        """Test validate with test_cases not being an array."""
        data = {
            'test_suite': {
                'metadata': {
                    'name': 'Test',
                    'component': ['comp'],
                    'tags': ['tag']
                },
                'test_cases': 'not_an_array'
            }
        }
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(data, f)
            temp_file = f.name
        
        try:
            assert validator.validate(temp_file) == False
            assert any("test_cases" in error and "must be an array" in error for error in validator.errors)
        finally:
            os.unlink(temp_file)
    
    def test_validate_multiple_test_cases(self, validator, valid_yaml_content):
        """Test validate with multiple test cases."""
        # Add a second test case
        valid_yaml_content['test_suite']['test_cases'].append(
            valid_yaml_content['test_suite']['test_cases'][0].copy()
        )
        valid_yaml_content['test_suite']['test_cases'][1]['name'] = 'test_case_2'
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(valid_yaml_content, f)
            temp_file = f.name
        
        try:
            assert validator.validate(temp_file) == True
            assert len(validator.errors) == 0
        finally:
            os.unlink(temp_file)
    
    # Test get_errors and print_errors
    def test_get_errors(self, validator):
        """Test get_errors method."""
        validator.errors = ["error1", "error2"]
        errors = validator.get_errors()
        assert errors == ["error1", "error2"]
        assert len(errors) == 2
    
    def test_print_errors_with_errors(self, validator, capsys):
        """Test print_errors with errors present."""
        validator.errors = ["error1", "error2"]
        validator.print_errors()
        captured = capsys.readouterr()
        assert "Validation failed" in captured.out
        assert "error1" in captured.out
        assert "error2" in captured.out
    
    def test_print_errors_without_errors(self, validator, capsys):
        """Test print_errors without errors."""
        validator.errors = []
        validator.print_errors()
        captured = capsys.readouterr()
        assert "Validation successful" in captured.out
    
    # Edge cases and additional coverage
    def test_validate_empty_arrays(self, validator):
        """Test validation with empty arrays."""
        data = {
            'test_suite': {
                'metadata': {
                    'name': 'Test',
                    'component': [],
                    'tags': []
                },
                'test_cases': []
            }
        }
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(data, f)
            temp_file = f.name
        
        try:
            # Should pass as arrays can be empty
            assert validator.validate(temp_file) == True
        finally:
            os.unlink(temp_file)
    
    def test_validate_test_case_without_optional_fields(self, validator):
        """Test validate_test_case without optional description and metadata."""
        test_case = {
            'name': 'test_1',
            'pre_conditions': {'setup_command': [{'executable': 'cmd', 'args': []}]},
            'steps': [{'command': {'executable': 'cmd', 'args': []}, 'expectations': {'exit_code': 0, 'keywords': []}}],
            'post_conditions': {'cleanup_command': [{'executable': 'cmd', 'args': []}]}
        }
        assert validator.validate_test_case(test_case, 0) == True
    
    def test_validate_steps_without_optional_timeout(self, validator):
        """Test validate_steps without optional timeout_sec field."""
        steps = [
            {
                'command': {'executable': '/usr/bin/test', 'args': []},
                'expectations': {'exit_code': 0, 'keywords': ['pass']}
            }
        ]
        assert validator.validate_steps(steps, "path") == True
        assert len(validator.errors) == 0
    
    def test_complex_nested_structure(self, validator, valid_yaml_content):
        """Test validation with complex nested structure."""
        # Add multiple commands and steps
        valid_yaml_content['test_suite']['test_cases'][0]['pre_conditions']['setup_command'].append({
            'executable': '/usr/bin/setup2',
            'args': ['--arg1', '--arg2']
        })
        valid_yaml_content['test_suite']['test_cases'][0]['steps'].append({
            'command': {'executable': '/usr/bin/test2', 'args': ['--test']},
            'expectations': {'exit_code': 0, 'keywords': ['success']}
        })
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(valid_yaml_content, f)
            temp_file = f.name
        
        try:
            assert validator.validate(temp_file) == True
            assert len(validator.errors) == 0
        finally:
            os.unlink(temp_file)
    
    def test_get_nested_value_with_non_dict(self, validator):
        """Test get_nested_value when intermediate value is not a dict."""
        data = {'level1': 'not_a_dict'}
        result = validator.get_nested_value(data, "level1.level2")
        assert result is None
    
    def test_check_field_exists_with_non_dict_intermediate(self, validator):
        """Test check_field_exists when intermediate value is not a dict."""
        data = {'level1': 'not_a_dict'}
        result = validator.check_field_exists(data, "level1.level2")
        assert result == False
        assert len(validator.errors) == 1


# Additional integration tests
class TestIntegration:
    """Integration tests for complete validation scenarios."""
    
    def test_full_validation_workflow(self):
        """Test complete validation workflow from file to result."""
        validator = YAMLSchemaValidator()
        
        # Create a complete valid YAML
        data = {
            'test_suite': {
                'metadata': {
                    'name': 'Integration Test Suite',
                    'component': ['component_a', 'component_b'],
                    'tags': ['integration', 'smoke']
                },
                'test_cases': [
                    {
                        'name': 'integration_test_1',
                        'description': 'First integration test',
                        'metadata': {
                            'components': ['func1', 'func2'],
                            'enable': True,
                            'tags': ['priority_high']
                        },
                        'pre_conditions': {
                            'setup_command': [
                                {
                                    'executable': '/bin/bash',
                                    'args': ['-c', 'echo setup']
                                }
                            ]
                        },
                        'steps': [
                            {
                                'command': {
                                    'executable': '/usr/bin/python3',
                                    'args': ['test.py', '--verbose']
                                },
                                'timeout_sec': 60,
                                'expectations': {
                                    'exit_code': 0,
                                    'keywords': ['PASSED', 'SUCCESS']
                                }
                            },
                            {
                                'command': {
                                    'executable': '/usr/bin/pytest',
                                    'args': ['-v']
                                },
                                'expectations': {
                                    'exit_code': 0,
                                    'keywords': ['passed']
                                }
                            }
                        ],
                        'post_conditions': {
                            'cleanup_command': [
                                {
                                    'executable': '/bin/rm',
                                    'args': ['-rf', '/tmp/test']
                                }
                            ]
                        }
                    },
                    {
                        'name': 'integration_test_2',
                        'pre_conditions': {
                            'setup_command': [
                                {'executable': '/bin/true', 'args': []}
                            ]
                        },
                        'steps': [
                            {
                                'command': {'executable': '/bin/echo', 'args': ['test']},
                                'expectations': {'exit_code': 0, 'keywords': ['test']}
                            }
                        ],
                        'post_conditions': {
                            'cleanup_command': [
                                {'executable': '/bin/true', 'args': []}
                            ]
                        }
                    }
                ]
            }
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(data, f)
            temp_file = f.name
        
        try:
            result = validator.validate(temp_file)
            assert result == True
            assert len(validator.get_errors()) == 0
        finally:
            os.unlink(temp_file)
    
    def test_validation_with_multiple_errors(self):
        """Test that validator collects all errors, not just the first one."""
        validator = YAMLSchemaValidator()
        
        # Create YAML with multiple errors
        data = {
            'test_suite': {
                'metadata': {
                    'name': 123,  # Wrong type
                    'component': 'not_array',  # Wrong type
                    'tags': 'not_array'  # Wrong type
                },
                'test_cases': [
                    {
                        'name': 456,  # Wrong type
                        'pre_conditions': {
                            'setup_command': [
                                {
                                    'executable': 'has spaces',  # Contains spaces
                                    'args': 'not_array'  # Wrong type
                                }
                            ]
                        },
                        'steps': [
                            {
                                'command': {
                                    'executable': 'also spaces',  # Contains spaces
                                    'args': 'not_array'  # Wrong type
                                },
                                'expectations': {
                                    'exit_code': 'not_int',  # Wrong type
                                    'keywords': 'not_array'  # Wrong type
                                }
                            }
                        ],
                        'post_conditions': {
                            'cleanup_command': [
                                {
                                    'executable': 'more spaces',  # Contains spaces
                                    'args': 'not_array'  # Wrong type
                                }
                            ]
                        }
                    }
                ]
            }
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(data, f)
            temp_file = f.name
        
        try:
            result = validator.validate(temp_file)
            assert result == False
            errors = validator.get_errors()
            assert len(errors) > 5  # Should have collected multiple errors
        finally:
            os.unlink(temp_file)
