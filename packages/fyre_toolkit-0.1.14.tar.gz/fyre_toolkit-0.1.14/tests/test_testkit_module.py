"""Test suite for testkit module-level functionality"""
import sys
import pytest


class TestModuleDunderAll:
    """Test suite for __all__ behavior in testkit module"""

    def test_all_attribute_exists(self):
        """Test that __all__ attribute exists in testkit module"""
        import testkit

        assert hasattr(testkit, "__all__")
        assert isinstance(testkit.__all__, list)

    def test_all_contains_pytest_generator(self):
        """Test that __all__ contains pytest_generator"""
        import testkit

        assert "pytest_generator_from_yaml" in testkit.__all__

    def test_all_contains_expected_exports(self):
        """Test that __all__ contains expected public exports"""
        import testkit

        assert testkit.__all__ == ["pytest_generator_from_yaml", "convert_xml_to_csv", "convert_kd_to_csv", "generate_summary_result", "aggregate_test_components_from_yaml", "_check_package"]

    def test_wildcard_import_exports_pytest_generator(self):
        """Test that wildcard import exports pytest_generator"""
        # Create a fresh namespace
        namespace = {}
        exec("from testkit import *", namespace)

        # pytest_generator should be available
        assert "pytest_generator_from_yaml" in namespace

    def test_wildcard_import_exports_check_package(self):
        """Test that wildcard import exports _check_package"""
        # Create a fresh namespace
        namespace = {}
        exec("from testkit import *", namespace)

        # _check_package should be available
        assert "_check_package" in namespace

    def test_wildcard_import_does_not_export_pname(self):
        """Test that wildcard import does not export __pname__"""
        # Create a fresh namespace
        namespace = {}
        exec("from testkit import *", namespace)

        # __pname__ should NOT be available
        assert "__pname__" not in namespace

    def test_wildcard_import_does_not_export_submodules(self):
        """Test that wildcard import does not export internal submodules"""
        # Create a fresh namespace
        namespace = {}
        exec("from testkit import *", namespace)

        # Internal modules should NOT be available via wildcard import
        assert "generator" not in namespace
        assert "utils" not in namespace
        assert "schema" not in namespace

    def test_regular_import_has_all_attributes(self):
        """Test that regular import has access to all module attributes"""
        import testkit

        # Regular import should have access to everything
        assert hasattr(testkit, "pytest_generator_from_yaml")
        assert hasattr(testkit, "__pname__")
        assert hasattr(testkit, "generator")
        assert hasattr(testkit, "utils")
        assert hasattr(testkit, "schema")

    def test_explicit_import_works_for_all_listed(self):
        """Test that explicit import works for items in __all__"""
        # This should work without error
        from testkit import pytest_generator_from_yaml

        assert callable(pytest_generator_from_yaml)

    def test_wildcard_import_limited_namespace(self):
        """Test that wildcard import creates a limited namespace"""
        namespace = {}
        exec("from testkit import *", namespace)

        # Count non-dunder attributes (excluding __builtins__, etc.)
        public_names = [name for name in namespace.keys() if not name.startswith("__")]

        # Should have pytest_generator, pytest_generator_from_yaml, and _check_package
        assert len(public_names) == 6
        assert set(public_names) == {"convert_kd_to_csv", "convert_xml_to_csv", "generate_summary_result", "pytest_generator_from_yaml", "aggregate_test_components_from_yaml", "_check_package"}

    def test_all_items_are_importable(self):
        """Test that all items in __all__ are actually importable"""
        import testkit

        for item_name in testkit.__all__:
            assert hasattr(testkit, item_name), f"{item_name} in __all__ but not in module"

    def test_all_items_are_callable_or_classes(self):
        """Test that all exported items are callable or classes"""
        import testkit

        for item_name in testkit.__all__:
            item = getattr(testkit, item_name)
            # Should be either a function or a class
            assert callable(item), f"{item_name} should be callable"

    def test_pname_is_internal_variable(self):
        """Test that __pname__ is internal and not exported"""
        import testkit

        # __pname__ exists in the module
        assert hasattr(testkit, "__pname__")
        assert testkit.__pname__ == "fyre_toolkit"

        # But it's not in __all__
        assert "__pname__" not in testkit.__all__

    def test_dir_testkit_includes_more_than_all(self):
        """Test that dir() on testkit shows more than __all__"""
        import testkit

        dir_result = dir(testkit)
        all_result = testkit.__all__

        # dir() should show more items than __all__
        assert len(dir_result) > len(all_result)

        # But __all__ items should be in dir()
        for item in all_result:
            assert item in dir_result

    def test_wildcard_import_pytest_generator_is_same_object(self):
        """Test that wildcard imported pytest_generator_from_yaml is the same object"""
        import testkit

        namespace = {}
        exec("from testkit import *", namespace)

        # Should be the exact same object
        assert namespace["pytest_generator_from_yaml"] is testkit.pytest_generator_from_yaml
