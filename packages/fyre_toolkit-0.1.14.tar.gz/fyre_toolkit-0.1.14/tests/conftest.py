from pathlib import Path
import pytest


@pytest.fixture
def resource_dir():
    """Path to directory containing YAML data"""
    return Path(__file__).parent / "resources"

@pytest.fixture
def valid_yaml_file(resource_dir):
    """Load valid test suite from file"""
    file_path = resource_dir / "valid_one_case.yaml"
    return file_path

@pytest.fixture
def multicase_yaml_file(resource_dir):
    """Load multi-case test suite from file"""
    file_path = resource_dir / "multiple_valid_cases.yaml"
    return file_path

@pytest.fixture
def invalid_yaml_file(resource_dir):
    """Load invalid test suite from file"""
    file_path = resource_dir / "invalid_case.yaml"
    return file_path
