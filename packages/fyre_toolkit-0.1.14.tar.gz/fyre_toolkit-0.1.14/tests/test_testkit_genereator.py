import json
import ast
from typing import Iterator
from pydantic import ValidationError
from unittest.mock import patch
import pytest
import tempfile
import os
from pathlib import Path
from testkit.generator import (
    pytest_generator,
    pytest_generator_from_yaml,
    sanitize_identifier,
    generate_step_execution_code,
    generate_pytest_function,
    generate_pytest_module_code,
    write_test_cases_to_disk,
)
from testkit.schema import (
    Command,
    Expectations,
    Step,
    TestCase,
    TestCaseMetadata,
    TestSuite,
    TestSuiteMetadata,
)

# -- Test data --
VALID_TEST_SUITE = {
    "test_cases": [
        {"name": "Login Test", "description": "Test user login"},
        {"name": "Logout Test", "description": ""},
        {"name": "Data Upload", "description": "Test file upload"},
    ]
}

INVALID_TEST_SUITE_MISSING_NAME = {"test_cases": [{"description": "Test without name"}]}


class TestSanitizeIdentifier:
    """Test suite for the sanitize_identifier function"""

    @pytest.mark.parametrize(
        "input_str, expected",
        [
            ("Simple Test", "simple_test"),
            ("Mixed-Case-123", "mixed_case_123"),
            ("  trimmed  ", "trimmed"),
            ("special!@#chars", "specialchars"),
            ("numbers123", "numbers123"),
            ("UPPER_CASE", "upper_case"),
            ("multiple   spaces", "multiple___spaces"),
            ("dash-case", "dash_case"),
            ("unicode-文字", "unicode_"),
            ("", ""),
        ],
    )
    def test_valid_cases(self, input_str, expected):
        """Test that valid strings are properly sanitized"""
        assert sanitize_identifier(input_str) == expected

    def test_all_special_chars(self):
        """Test string with all special characters"""
        assert sanitize_identifier("!@#$%^&*()") == ""

    def test_only_spaces(self):
        """Test string containing only spaces"""
        assert sanitize_identifier("   ") == ""

    def test_single_char(self):
        """Test single character inputs"""
        assert sanitize_identifier("a") == "a"
        assert sanitize_identifier("1") == "1"
        assert sanitize_identifier("_") == "_"
        assert sanitize_identifier("-") == "_"
        assert sanitize_identifier(" ") == ""

    @pytest.mark.parametrize(
        "invalid_input",
        [
            None,
            123,
            ["list"],
            {"dict": "value"},
            True,
        ],
    )
    def test_invalid_input_types(self, invalid_input):
        """Test that non-string inputs raise TypeError"""
        with pytest.raises(TypeError):
            sanitize_identifier(invalid_input)

    def test_no_double_underscores(self):
        """Test that multiple consecutive special chars don't create double underscores"""
        assert sanitize_identifier("a!!b  c--d") == "ab__c__d"

    def test_case_normalization(self):
        """Test that output is always lowercase"""
        assert sanitize_identifier("UpperCase") == "uppercase"
        assert sanitize_identifier("MIXED_case") == "mixed_case"

    def test_unicode_handling(self):
        """Test handling of unicode characters"""
        assert sanitize_identifier("café") == "caf"
        assert sanitize_identifier("東京") == ""
        assert sanitize_identifier("a1b2c3文字") == "a1b2c3"


class TestGenerateStepExecutionCode:
    """Test suite for generate_step_execution_code function"""

    def test_default_parameters(self):
        """Test generation with default parameters"""
        code = generate_step_execution_code()
        assert "cmd = [step['command']['executable']]" in code
        assert "proc = subprocess.run(cmd," in code
        assert "assert exit_code == step['expectations']['exit_code']" in code
        assert " " * 4 in code

    def test_custom_step_var(self):
        """Test with custom step variable name"""
        code = generate_step_execution_code(step_var="custom_step")
        assert "cmd = [custom_step['command']['executable']]" in code
        assert "timeout=custom_step['timeout_sec']" in code
        assert "custom_step['expectations']['exit_code']" in code

    def test_indentation(self):
        """Test different indentation levels"""
        for indent in [0, 2, 4, 8]:
            code = generate_step_execution_code(indent=indent)
            if indent > 0:
                assert " " * indent in code
            else:
                assert not code.startswith(" ")

    def test_output_structure(self):
        """Verify the generated code structure"""
        code = generate_step_execution_code()

        sections = [
            "# execute command",
            "cmd = [",
            "proc = subprocess.run(",
            "output = proc.stdout",
            "# expectations",
            "assert exit_code ==",
            "for kw in",
        ]
        for section in sections:
            assert section in code

    def test_keyword_assertion_format(self):
        """Test the keyword assertion formatting"""
        code = generate_step_execution_code()
        assert (
            "assert kw in output, f\"Keyword '{kw}' not found in output: {output!r}\""
            in code
        )

    def test_exit_code_assertion_format(self):
        """Test the exit code assertion formatting"""
        code = generate_step_execution_code()
        assert 'f"Exit code mismatch, got {exit_code}"' in code

    @pytest.mark.parametrize("indent", [-1, -4, 1.5, "2"])
    def test_invalid_indent(self, indent):
        """Test invalid indentation values"""
        with pytest.raises((TypeError, ValueError)):
            generate_step_execution_code(indent=indent)

    def test_empty_step_var(self):
        """Test with empty step variable name"""
        with pytest.raises(ValueError):
            generate_step_execution_code(step_var="")

    @pytest.mark.parametrize("step_var", [None, 123, True, ["step"]])
    def test_invalid_step_var_types(self, step_var):
        """Test invalid step_var types"""
        with pytest.raises(TypeError):
            generate_step_execution_code(step_var=step_var)

    def test_complete_output(self):
        """Verify complete generated code matches snapshot"""
        expected = """
    # execute command
    cmd = [step['command']['executable']] + list(step['command'].get('args', []))
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=step['timeout_sec'])
    output = proc.stdout or ""
    exit_code = proc.returncode
    # expectations
    assert exit_code == step['expectations']['exit_code'], f"Exit code mismatch, got {exit_code}"
    for kw in step['expectations'].get('keywords', []):
        assert kw in output, f"Keyword '{kw}' not found in output: {output!r}"
"""
        assert generate_step_execution_code(indent=4).strip() == expected.strip()


class TestGeneratePytestFunction:
    """Test suite for generate_pytest_function"""

    @pytest.fixture
    def sample_test_case(self):
        """Fixture providing a basic valid TestCase"""
        return TestCase(
            name="Sample Test",
            steps=[
                Step(
                    command=Command(executable="/bin/true"),
                    expectations=Expectations(exit_code=0),
                )
            ],
        )

    def test_function_name_generation(self, sample_test_case):
        """Test that function name is properly sanitized"""

        code = generate_pytest_function(sample_test_case)
        assert "def test_sample_test():" in code

        weird_case = sample_test_case.copy()
        weird_case.name = "Weird @Test-123"
        code = generate_pytest_function(weird_case)
        assert "def test_weird_test_123():" in code

    def test_test_case_embedding(self, sample_test_case):
        """Test that TEST_CASE is properly embedded as JSON"""
        code = generate_pytest_function(sample_test_case)

        # Check for unique variable name pattern TEST_CASE_<FUNC_NAME>
        assert "TEST_CASE_SAMPLE_TEST = {" in code
        assert '"name": "Sample Test"' in code

        json_start = code.find("TEST_CASE_SAMPLE_TEST = {")
        json_end = code.rfind("}\n") + 1
        json_str = code[json_start + len("TEST_CASE_SAMPLE_TEST = ") : json_end]

        try:
            # Use ast.literal_eval instead of json.loads because the generated code
            # uses Python-style booleans (True/False) not JSON-style (true/false)
            parsed = ast.literal_eval(json_str)
            assert parsed["name"] == "Sample Test"
            assert len(parsed["steps"]) == 1
            assert parsed["steps"][0]["command"]["executable"] == "/bin/true"
            # Verify that enable field is a Python boolean
            assert isinstance(parsed["metadata"]["enable"], bool)
            assert parsed["metadata"]["enable"] is True
        except (ValueError, SyntaxError) as e:
            pytest.fail(f"Generated Python dict is invalid: {e}\nDict content:\n{json_str}")

    def test_setup_commands_generation(self, sample_test_case):
        """Test setup commands generation"""
        test_case = sample_test_case.copy()
        test_case.pre_conditions.setup_command = [
            {"executable": "/bin/setup", "args": ["--verbose"]}
        ]
        code = generate_pytest_function(test_case)
        assert (
            "for setup in TEST_CASE_SAMPLE_TEST.get('pre_conditions', {}).get('setup_command', []):"
            in code
        )
        assert "cmd = [setup['executable']] + list(setup.get('args', []))" in code
        assert "subprocess.run(cmd, check=True)" in code

    def test_step_execution_generation(self, sample_test_case):
        """Test step execution code generation"""
        code = generate_pytest_function(sample_test_case)
        assert "for step in TEST_CASE_SAMPLE_TEST.get('steps', []):" in code
        assert "cmd = [step['command']['executable']]" in code
        assert "assert exit_code == step['expectations']['exit_code']" in code

    def test_cleanup_commands_generation(self, sample_test_case):
        """Test cleanup commands generation"""
        test_case = sample_test_case.copy()
        test_case.post_conditions.cleanup_command = [
            {"executable": "/bin/cleanup", "args": ["--all"]}
        ]
        code = generate_pytest_function(test_case)
        assert (
            "for cleanup in TEST_CASE_SAMPLE_TEST.get('post_conditions', {}).get('cleanup_command', []):"
            in code
        )
        assert "cmd = [cleanup['executable']] + list(cleanup.get('args', []))" in code
        assert "subprocess.run(cmd, check=True)" in code

    def test_empty_test_case(self):
        """Test with minimal valid TestCase"""
        minimal_case = TestCase(
            name="Minimal",
            description="",
            metadata=TestCaseMetadata(),
            steps=[
                Step(
                    command=Command(executable="/bin/true"),
                    expectations=Expectations(exit_code=0),
                )
            ],
        )
        code = generate_pytest_function(minimal_case)
        assert "def test_minimal():" in code
        assert "TEST_CASE" in code

    def test_indentation(self, sample_test_case):
        """Test proper indentation in generated code"""
        code = generate_pytest_function(sample_test_case)
        lines = code.splitlines()
        # Last line should be indented (inside function)
        assert lines[-1].strip().startswith("subprocess.run")
        # Function body should have indented lines
        assert any(line.startswith("        ") for line in lines)

    @pytest.mark.parametrize("invalid_input", [None, "string", 123, {}])
    def test_invalid_input_types(self, invalid_input):
        """Test that non-TestCase inputs raise errors"""
        with pytest.raises((AttributeError, ValidationError)):
            generate_pytest_function(invalid_input)

    def test_disabled_test_cases(self, sample_test_case):
        """Test that disabled test cases are handled"""
        disabled_case = sample_test_case.copy()
        disabled_case.metadata.enable = False
        code = generate_pytest_function(disabled_case)
        assert code == ""


class TestGeneratePytestModuleCodeGenerator:
    """Test suite for generator version of generate_pytest_module_code"""

    @pytest.fixture
    def sample_test_suite(self):
        """Fixture providing a basic valid TestSuite"""
        return TestSuite(
            metadata=TestSuiteMetadata(name="Sample Suite"),
            test_cases=[
                TestCase(name="Test1"),
                TestCase(name="Test2"),
                TestCase(name="Disabled", metadata=TestCaseMetadata(enable=False)),
            ],
        )

    def test_returns_generator(self, sample_test_suite):
        """Test that function returns a generator"""
        result = generate_pytest_module_code(sample_test_suite)
        assert isinstance(result, Iterator)

    def test_first_chunk_is_header(self, sample_test_suite):
        """Test first yielded chunk contains header"""
        gen = generate_pytest_module_code(sample_test_suite)
        first_chunk = next(gen)
        assert "import pytest" in first_chunk
        assert "# Auto-generated" in first_chunk

    def test_yields_test_functions(self, sample_test_suite):
        """Test yields test function chunks"""
        gen = generate_pytest_module_code(sample_test_suite)
        chunks = list(gen)
        assert any("def test_test1():" in chunk for chunk in chunks)
        assert any("def test_test2():" in chunk for chunk in chunks)
        assert not any("def test_disabled():" in chunk for chunk in chunks)

    def test_chunk_separation(self, sample_test_suite):
        """Test proper separation between test cases"""
        gen = generate_pytest_module_code(sample_test_suite)
        chunks = list(gen)

        test_indices = [
            i for i, chunk in enumerate(chunks) if chunk.startswith("def test_")
        ]

        for i in test_indices[1:]:
            assert chunks[i - 1] == "\n\n"

    def test_empty_suite(self):
        """Test with empty test suite"""
        empty_suite = TestSuite(
            metadata=TestSuiteMetadata(name="Empty"),
            test_cases=[TestCase(name="Test Case")],
        )
        gen = generate_pytest_module_code(empty_suite)
        chunks = list(gen)
        assert len(chunks) == 3  # Header + final newline
        assert "import" in chunks[0]
        assert "TEST_CASE" in chunks[1]

    def test_all_disabled(self, sample_test_suite):
        """Test suite with all test cases disabled"""
        for tc in sample_test_suite.test_cases:
            tc.metadata.enable = False
        gen = generate_pytest_module_code(sample_test_suite)
        chunks = list(gen)
        assert not any("def test_" in chunk for chunk in chunks)

    def test_file_writing(self, sample_test_suite, tmp_path):
        """Test streaming directly to file"""
        test_file = tmp_path / "test_output.py"
        with open(test_file, "w") as f:
            for chunk in generate_pytest_module_code(sample_test_suite):
                f.write(chunk)

        content = test_file.read_text()
        assert "def test_test1():" in content
        assert "def test_test2():" in content

    def test_large_suite_handling(self):
        """Test memory efficiency with large suite"""
        large_suite = TestSuite(
            metadata=TestSuiteMetadata(name="Large"),
            test_cases=[TestCase(name=f"Test{i}") for i in range(1000)],
        )

        count = 0
        for chunk in generate_pytest_module_code(large_suite):
            count += 1
            assert isinstance(chunk, str)
        assert count > 1000  # Should yield many chunks

    def test_join_behavior(self, sample_test_suite):
        """Test joining chunks produces valid module"""
        gen = generate_pytest_module_code(sample_test_suite)
        full_code = "".join(gen)
        assert "def test_test1():" in full_code
        assert "def test_test2():" in full_code
        assert "\n\ndef test_test2" in full_code

    def test_consistent_string_output(self, sample_test_suite):
        """Verify all chunks are strings"""
        for chunk in generate_pytest_module_code(sample_test_suite):
            assert isinstance(chunk, str)

    def test_text_file_writing(self, sample_test_suite, tmp_path):
        """Test writing to text file"""
        test_file = tmp_path / "test_output.py"
        with open(test_file, "wb") as f:
            for chunk in generate_pytest_module_code(sample_test_suite):
                if isinstance(chunk, str):
                    f.write(chunk.encode("utf-8"))
                else:
                    f.write(chunk)

        assert "def test_" in test_file.read_text()


class TestWriteTestCasesToDisk:
    """Test suite for write_test_cases_to_disk function"""

    @pytest.fixture
    def sample_test_suite(self):
        """Fixture providing a basic valid TestSuite"""
        return TestSuite(
            metadata=TestSuiteMetadata(name="Sample Suite", component=["core"]),
            test_cases=[TestCase(name="Sample Case")],
        )

    def test_successful_write(self, sample_test_suite, tmp_path):
        """Test successful file generation with default parameters"""
        # Mock workspace generator to use temp dir
        mock_generator = lambda r, p: str(tmp_path / f"{p}-mock")

        paths = write_test_cases_to_disk(
            sample_test_suite, workspace_generator=mock_generator
        )

        assert len(paths) == 1
        assert paths[0].endswith("test_sample_suite.py")
        assert os.path.exists(paths[0])
        with open(paths[0], "r") as f:
            content = f.read()
            assert "def test_" in content

    def test_custom_parameters(self, sample_test_suite, tmp_path):
        """Test with custom workspace parameters"""
        mock_generator = lambda r, p: str(tmp_path / f"{r}" / f"custom_{p}")

        paths = write_test_cases_to_disk(
            sample_test_suite,
            workspace_generator=mock_generator,
            out_root="custom_reports",
            workspace_prefix="tests",
        )

        assert "custom_tests" in paths[0]
        assert "custom_reports" in paths[0]

    def test_invalid_workspace_generator(self, sample_test_suite):
        """Test non-callable workspace generator"""
        with pytest.raises(TypeError) as excinfo:
            write_test_cases_to_disk(sample_test_suite, workspace_generator="not_callable")  # type: ignore
        assert "must be a callable function" in str(excinfo.value)

    def test_directory_creation(self, sample_test_suite, tmp_path):
        """Test directory creation for nested paths"""
        mock_generator = lambda r, p: str(tmp_path / "deep" / "nested" / p)

        paths = write_test_cases_to_disk(
            sample_test_suite, workspace_generator=mock_generator
        )

        assert os.path.exists(os.path.dirname(paths[0]))

    def test_special_chars_in_names(self, tmp_path):
        """Test handling of special characters in suite names"""
        mock_generator = lambda r, p: str(tmp_path)
        weird_suite = TestSuite(
            metadata=TestSuiteMetadata(name="Weird @Suite/Name!123"),
            test_cases=[TestCase(name="Case")],
        )

        paths = write_test_cases_to_disk(
            weird_suite, workspace_generator=mock_generator
        )

        assert "test_weird_suitename123.py" in paths[0]

    def test_file_encoding(self, sample_test_suite, tmp_path):
        """Test proper UTF-8 file encoding"""
        mock_generator = lambda r, p: str(tmp_path)

        paths = write_test_cases_to_disk(
            sample_test_suite, workspace_generator=mock_generator
        )

        with open(paths[0], "rb") as f:
            content = f.read()
            try:
                content.decode("utf-8")
            except UnicodeDecodeError:
                pytest.fail("File is not properly UTF-8 encoded")

    def test_return_value_structure(self, sample_test_suite, tmp_path):
        """Test return value is always a list"""
        mock_generator = lambda r, p: str(tmp_path)

        paths = write_test_cases_to_disk(
            sample_test_suite, workspace_generator=mock_generator
        )

        assert isinstance(paths, list)
        assert len(paths) == 1
        assert all(isinstance(p, str) for p in paths)

    @patch("pathlib.Path.mkdir")
    def test_directory_creation_failure(self, mock_mkdir, sample_test_suite):
        """Test handling of directory creation failures"""
        mock_mkdir.side_effect = OSError("Permission denied")
        mock_generator = lambda r, p: "/invalid/path"

        with pytest.raises(OSError):
            write_test_cases_to_disk(
                sample_test_suite, workspace_generator=mock_generator
            )

    @patch("builtins.open")
    def test_file_write_failure(self, mock_open, sample_test_suite, tmp_path):
        """Test handling of file write failures"""
        mock_open.side_effect = OSError("Disk full")
        mock_generator = lambda r, p: str(tmp_path)

        with pytest.raises(OSError):
            write_test_cases_to_disk(
                sample_test_suite, workspace_generator=mock_generator
            )

    def test_empty_suite_name(self, tmp_path):
        """Test handling of invalid suite names that pass initial validation"""
        mock_generator = lambda r, p: str(tmp_path)

        with pytest.raises((ValueError, OSError)):
            # Case 1: Name that's invalid for paths but valid for model
            suite = TestSuite(
                metadata=TestSuiteMetadata(name="   "),
                test_cases=[TestCase(name="case")],
            )
            write_test_cases_to_disk(suite, workspace_generator=mock_generator)

        # Case 2: Verify sanitization handles edge cases
        suite = TestSuite(
            metadata=TestSuiteMetadata(name="  valid-after-trim  "),
            test_cases=[TestCase(name="case")],
        )
        paths = write_test_cases_to_disk(suite, workspace_generator=mock_generator)
        assert "valid_after_trim" in paths[0]

    def test_multiple_test_cases(self, tmp_path):
        """Test with suite containing multiple test cases"""
        suite = TestSuite(
            metadata=TestSuiteMetadata(name="Multi Test"),
            test_cases=[
                TestCase(name=f"case{n}") for n in range(2)
            ]
        )
        mock_generator = lambda r, p: str(tmp_path)
        paths = write_test_cases_to_disk(suite, workspace_generator=mock_generator)
        assert len(paths) == 1, "the test case should be equal to 1"
        assert "test_multi_test" in paths[0]

        with open(paths[0], "r", encoding='utf-8') as f:
            test_suite = f.read()
            assert "def test_case0(" in test_suite
            assert "def test_case1(" in test_suite


class TestPytestGenerator:
    """Test suite for pytest_generator function"""

    @pytest.fixture
    def output_file(self):
        """Fixture that creates and cleans up a temporary output file"""
        with tempfile.NamedTemporaryFile(delete=False, suffix=".py") as tmp:
            tmp_path = tmp.name
        yield tmp_path
        try:
            os.unlink(tmp_path)
        except FileNotFoundError:
            pass

    def test_generates_valid_pytest_file(self, output_file):
        """Test that function generates valid pytest file"""
        pytest_generator(VALID_TEST_SUITE, output_file)

        assert Path(output_file).exists()

        content = Path(output_file).read_text()
        assert "def test_login_test():" in content
        assert "def test_logout_test():" in content
        assert "def test_data_upload():" in content
        assert '"Test user login"' in content
        assert "assert True" in content

    def test_handles_empty_description(self, output_file):
        """Test that function handles cases with empty description"""
        pytest_generator(VALID_TEST_SUITE, output_file)
        content = Path(output_file).read_text()
        assert '""""""' in content  # Empty docstring for logout test

    def test_raises_keyerror_missing_name(self, output_file):
        """Test that KeyError is raised when name is missing"""
        with pytest.raises(KeyError):
            pytest_generator(INVALID_TEST_SUITE_MISSING_NAME, output_file)

    def test_raises_typeerror_invalid_input(self, output_file):
        """Test that TypeError is raised for invalid input types"""
        with pytest.raises(TypeError):
            pytest_generator("not_a_dict", output_file)  # type: ignore
        with pytest.raises(TypeError):
            pytest_generator({"test_cases": "not_a_list"}, output_file)

    def test_creates_file_in_nonexistent_dir(self, tmp_path):
        """Test that function creates parent directories if needed"""

        output_file = tmp_path / "new_dir" / "sub_dir" / "tests.py"

        assert not output_file.parent.exists()

        pytest_generator(VALID_TEST_SUITE, str(output_file))

        assert output_file.exists()
        assert output_file.parent.exists()
        assert (output_file.parent.parent).exists()

    def test_file_permissions(self, output_file):
        """Test that generated file has correct permissions"""
        pytest_generator(VALID_TEST_SUITE, output_file)
        assert os.access(output_file, os.R_OK)
        assert os.access(output_file, os.W_OK)

    def test_sanitizes_function_names(self, output_file):
        """Test that special characters are sanitized in function names"""
        suite = {"test_cases": [{"name": "User Login (Chrome)", "description": ""}]}
        pytest_generator(suite, output_file)
        content = Path(output_file).read_text()
        assert "def test_user_login_chrome():" in content


class TestPytestGeneratorFromYaml:
    """Test suite for pytest_generator_from_yaml function"""

    @pytest.fixture
    def valid_yaml_content(self):
        """Fixture providing valid YAML test suite content"""
        return """test_suite:
  metadata:
    name: Sample Test Suite
    component:
      - authentication
    tags:
      - smoke
  test_cases:
    - name: test login
      description: Test user login functionality
      metadata:
        components:
          - login_module
        enable: true
        tags:
          - critical
      pre_conditions:
        setup_command:
          - executable: /bin/echo
            args:
              - "Setting up test"
      steps:
        - command:
            executable: /bin/echo
            args:
              - "Running test"
          timeout_sec: 10
          expectations:
            exit_code: 0
            keywords:
              - Running
      post_conditions:
        cleanup_command:
          - executable: /bin/echo
            args:
              - "Cleaning up"
    - name: test logout
      description: Test user logout functionality
      metadata:
        components:
          - logout_module
        enable: true
        tags:
          - critical
      steps:
        - command:
            executable: /bin/true
          timeout_sec: 5
          expectations:
            exit_code: 0
"""

    @pytest.fixture
    def valid_yaml_file(self, tmp_path, valid_yaml_content):
        """Fixture that creates a valid YAML file"""
        yaml_file = tmp_path / "test_suite.yaml"
        yaml_file.write_text(valid_yaml_content)
        return yaml_file

    @pytest.fixture
    def output_file(self, tmp_path):
        """Fixture for output file path"""
        return tmp_path / "generated_tests.py"

    def test_successful_generation(self, valid_yaml_file, output_file):
        """Test successful pytest generation from valid YAML"""
        result = pytest_generator_from_yaml(str(valid_yaml_file), str(output_file))

        assert result is True
        assert output_file.exists()

        content = output_file.read_text()
        assert "def test_test_login():" in content
        assert "def test_test_logout():" in content
        assert "import pytest" in content
        assert "import subprocess" in content

    def test_nonexistent_input_file(self, tmp_path, output_file):
        """Test FileNotFoundError for non-existent input file"""
        non_existent = tmp_path / "nonexistent.yaml"

        with pytest.raises(FileNotFoundError, match="Input file does not exist"):
            pytest_generator_from_yaml(str(non_existent), str(output_file))

    def test_invalid_file_extension(self, tmp_path, output_file):
        """Test FileNotFoundError for non-YAML file extension"""
        txt_file = tmp_path / "test.txt"
        txt_file.write_text("some content")

        with pytest.raises(FileNotFoundError, match="not a YAML file"):
            pytest_generator_from_yaml(str(txt_file), str(output_file))

    def test_yml_extension_accepted(self, tmp_path, valid_yaml_content, output_file):
        """Test that .yml extension is also accepted"""
        yml_file = tmp_path / "test_suite.yml"
        yml_file.write_text(valid_yaml_content)

        result = pytest_generator_from_yaml(str(yml_file), str(output_file))

        assert result is True
        assert output_file.exists()

    def test_invalid_yaml_syntax(self, tmp_path, output_file):
        """Test ValueError for invalid YAML syntax"""
        invalid_yaml = tmp_path / "invalid.yaml"
        invalid_yaml.write_text("invalid: yaml: syntax: [[[")

        with pytest.raises(Exception):  # yaml.YAMLError or similar
            pytest_generator_from_yaml(str(invalid_yaml), str(output_file))

    def test_missing_test_suite_key(self, tmp_path, output_file):
        """Test ValueError when 'test_suite' key is missing"""
        yaml_file = tmp_path / "missing_key.yaml"
        yaml_file.write_text("""
metadata:
  name: Test
test_cases: []
""")

        with pytest.raises(RuntimeError, match="must contain 'test_suite' key"):
            pytest_generator_from_yaml(str(yaml_file), str(output_file))

    def test_invalid_test_suite_structure(self, tmp_path, output_file):
        """Test ValidationError for invalid TestSuite structure"""
        yaml_file = tmp_path / "invalid_structure.yaml"
        yaml_file.write_text("""
test_suite:
  metadata:
    name: ""
  test_cases: []
""")

        with pytest.raises(RuntimeError):
            pytest_generator_from_yaml(str(yaml_file), str(output_file))

    def test_creates_output_directory(self, tmp_path, valid_yaml_file):
        """Test that output directory is created if it doesn't exist"""
        output_file = tmp_path / "deep" / "nested" / "dir" / "output.py"

        assert not output_file.parent.exists()

        result = pytest_generator_from_yaml(str(valid_yaml_file), str(output_file))

        assert result is True
        assert output_file.exists()
        assert output_file.parent.exists()

    def test_disabled_test_cases(self, tmp_path, output_file):
        """Test that disabled test cases are not generated"""
        yaml_content = """test_suite:
  metadata:
    name: Disabled Tests
    component:
      - test_component
  test_cases:
    - name: enabled test
      metadata:
        enable: true
      steps:
        - command:
            executable: /bin/true
          timeout_sec: 5
          expectations:
            exit_code: 0
    - name: disabled test
      metadata:
        enable: false
      steps:
        - command:
            executable: /bin/true
          timeout_sec: 5
          expectations:
            exit_code: 0
"""
        yaml_file = tmp_path / "disabled.yaml"
        yaml_file.write_text(yaml_content)

        result = pytest_generator_from_yaml(str(yaml_file), str(output_file))

        assert result is True
        content = output_file.read_text()
        assert "def test_enabled_test():" in content
        assert "def test_disabled_test():" not in content

    def test_special_characters_in_names(self, tmp_path, output_file):
        """Test handling of special characters in test names"""
        yaml_content = """test_suite:
  metadata:
    name: Special @Suite! Name
    component:
      - component
  test_cases:
    - name: Test-With-Dashes & Special!
      steps:
        - command:
            executable: /bin/true
          timeout_sec: 5
          expectations:
            exit_code: 0
"""
        yaml_file = tmp_path / "special.yaml"
        yaml_file.write_text(yaml_content)

        result = pytest_generator_from_yaml(str(yaml_file), str(output_file))

        assert result is True
        content = output_file.read_text()
        assert "def test_test_with_dashes__special():" in content

    def test_utf8_encoding(self, tmp_path, output_file):
        """Test proper UTF-8 encoding handling"""
        yaml_content = """test_suite:
  metadata:
    name: UTF-8 Test Suite
    component:
      - component
  test_cases:
    - name: Test UTF-8 Characters
      description: Testing with UTF-8 ñ é ü
      steps:
        - command:
            executable: /bin/echo
            args:
              - "UTF-8 test: ñ é ü"
              - '--input'
              - '/abc'
              - '--verbose'
          timeout_sec: 5
          expectations:
            exit_code: 0
"""
        yaml_file = tmp_path / "utf8.yaml"
        yaml_file.write_text(yaml_content, encoding='utf-8')

        result = pytest_generator_from_yaml(str(yaml_file), str(output_file))

        assert result is True
        content = output_file.read_text(encoding='utf-8')
        assert "UTF-8 test" in content
        assert "--input" in content
        assert "/abc" in content
        assert "--verbose" in content

    def test_empty_test_cases_list(self, tmp_path, output_file):
        """Test handling of empty test cases list"""
        yaml_content = """test_suite:
  metadata:
    name: Empty Suite
    component:
      - component
  test_cases: []
"""
        yaml_file = tmp_path / "empty.yaml"
        yaml_file.write_text(yaml_content)

        with pytest.raises(RuntimeError):
            pytest_generator_from_yaml(str(yaml_file), str(output_file))

    def test_multiple_test_cases(self, tmp_path, output_file):
        """Test generation with multiple test cases"""
        yaml_content = """test_suite:
  metadata:
    name: Multiple Tests
    component:
      - component
  test_cases:
"""
        for i in range(5):
            yaml_content += f"""    - name: test case {i}
      steps:
        - command:
            executable: /bin/true
          timeout_sec: 5
          expectations:
            exit_code: 0
"""
        yaml_file = tmp_path / "multiple.yaml"
        yaml_file.write_text(yaml_content)

        result = pytest_generator_from_yaml(str(yaml_file), str(output_file))

        assert result is True
        content = output_file.read_text()
        for i in range(5):
            assert f"def test_test_case_{i}():" in content

    def test_overwrites_existing_output_file(self, tmp_path, valid_yaml_file):
        """Test that existing output file is overwritten"""
        output_file = tmp_path / "existing.py"
        output_file.write_text("# Old content")

        result = pytest_generator_from_yaml(str(valid_yaml_file), str(output_file))

        assert result is True
        content = output_file.read_text()
        assert "# Old content" not in content
        assert "def test_" in content

    def test_file_write_permission_error(self, tmp_path, valid_yaml_file):
        """Test handling of file write permission errors"""
        output_file = tmp_path / "readonly.py"
        output_file.write_text("")
        output_file.chmod(0o444)  # Read-only

        try:
            with pytest.raises(RuntimeError):
                pytest_generator_from_yaml(str(valid_yaml_file), str(output_file))
        finally:
            output_file.chmod(0o644)  # Restore permissions

    def test_all_test_suite_fields(self, tmp_path, output_file):
        """Test with all optional fields populated"""
        yaml_content = """test_suite:
  metadata:
    name: Complete Test Suite
    component:
      - comp1
      - comp2
    tags:
      - tag1
      - tag2
  test_cases:
    - name: complete test
      description: Full test with all fields
      metadata:
        components:
          - module1
          - module2
        enable: true
        tags:
          - smoke
          - regression
      pre_conditions:
        setup_command:
          - executable: /bin/mkdir
            args:
              - /tmp/test
          - executable: /bin/touch
            args:
              - /tmp/test/file
      steps:
        - command:
            executable: /bin/cat
            args:
              - /tmp/test/file
          timeout_sec: 30
          expectations:
            exit_code: 0
            keywords:
              - success
              - complete
      post_conditions:
        cleanup_command:
          - executable: /bin/rm
            args:
              - -rf
              - /tmp/test
"""
        yaml_file = tmp_path / "complete.yaml"
        yaml_file.write_text(yaml_content)

        result = pytest_generator_from_yaml(str(yaml_file), str(output_file))

        assert result is True
        content = output_file.read_text()
        assert "def test_complete_test():" in content
        assert "TEST_CASE" in content

    def test_return_value_type(self, valid_yaml_file, output_file):
        """Test that function returns boolean True"""
        result = pytest_generator_from_yaml(str(valid_yaml_file), str(output_file))

        assert isinstance(result, bool)
        assert result is True

    def test_case_insensitive_yaml_extension(self, tmp_path, valid_yaml_content, output_file):
        """Test that YAML extension checking is case-insensitive"""
        yaml_file = tmp_path / "test.YAML"
        yaml_file.write_text(valid_yaml_content)

        result = pytest_generator_from_yaml(str(yaml_file), str(output_file))

        assert result is True

        yml_file = tmp_path / "test.YML"
        yml_file.write_text(valid_yaml_content)

        result = pytest_generator_from_yaml(str(yml_file), str(output_file))

        assert result is True
