![pypi version](https://img.shields.io/pypi/v/setuptools.svg)
![py version](https://img.shields.io/pypi/pyversions/setuptools.svg)
![test-badge](https://github.com/pypa/setuptools/actions/workflows/main.yml/badge.svg)
![ruff-badge](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/charliermarsh/ruff/main/assets/badge/v2.json)
![docs-badge](https://img.shields.io/readthedocs/setuptools/latest.svg)
![skeleton-badge](https://img.shields.io/badge/skeleton-2025-informational)
![codecov-badge](https://img.shields.io/codecov/c/github/pypa/setuptools/master.svg?logo=codecov&logoColor=white)


# Fyre Tool Kit

## Description
A blazing-fast toolkit to generate test cases using pytest framework.

## Features:
In `testki` module, it has
- YAML -> Pydantic schema validation
- Mandatory field checks
- Generate pytest-compatible test modules (one module per test_suite)
- Utilities for writing generated tests to disk

## Build

1.  To build a package with uv
```bash
$ uv build --wheel
```
2.  To verify the package with uv
```bash
$ uv run --with fyre-toolkit --no-project -- python -c "import testkit as tk; print(tk.__pname__)"
```
3.  The output of step 2 should be version like `fyre_toolkit`
4.  Before publishing the package, bump the version via running following command with uv
```bash
$ uv version --bump patch --frozen
```
5.  To publish the package to PyPi Index, run the following command with uv
```bash
$ uv publish
```

## Publish a package to Gitea PyPI package registry
1. Configure the package registry to edit local `~/.pypirc` file.
```init
[distutils]
index-servers = gitea

[gitea]
repository = https://gitea.example.com/api/packages/{owner}/pypi
username = {username}
password = {password}
```

Placeholder |	Description
--- | ---
`owner` |	The owner of the package.
`username` |	Your Gitea username.
`password` |	Your Gitea password. If you are using 2FA or OAuth use a personal access token instead of the password.

2. Publish a package by running following command
```bash
$ uv run python3 -m twine upload --repository gitea /path/to/files/*
```

3. To install a PyPI package from the package registry, execute the following command:
```bash
$ uv pip install --index-url https://{username}:{password}@gitea.example.com/api/packages/{owner}/pypi/simple --no-deps {package_name}
```

Parameter |	Description
--- | ---
username |	Your Gitea username.
password |	Your Gitea password or a personal access token.
owner |	The owner of the package.
package_name |	The package name.

For example:
```bash
$ uv pip install --index-url https://testuser:password123@gitea.example.com/api/packages/testuser/pypi/simple --no-deps test_package
```
You can use `--extra-index-url` instead of `--index-url` but that makes you vulnerable to dependency confusion attacks because `pip` checks the official PyPi repository for the package before it checks the specified custom repository. Read the `pip` docs for more information.

## Install the package for other projects
1. To install a local project with "editable" mode
```bash
$ uv pip install -e <project_dir>
```

2. To install a project from VCS in "editable" mode
```bash
$ uv pip install -e "fyre-toolkit@git+https://gitea.com/marc_pango/fyre_toolkit.git"   # from git
```

## Contribution

1. Clone the repository
2. Create `feature-xxx` branch
3. Commit your code
4. Create a new Issue and Pull Request
5. Request a code review for your PR

**Reference List:**  
- **Gitea Package** https://docs.gitea.com/usage/packages/pypi  
- **PIP Install** https://pip.pypa.io/en/stable/cli/pip_install  
- **UV Build** https://docs.astral.sh/uv/concepts/projects/build  
