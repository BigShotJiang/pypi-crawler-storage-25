import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

from testkit import pytest_generator_from_yaml
from testkit.utils import convert_xml_to_csv, generate_summary_result


def generate_pytest_from_yaml(input_yaml: Path) -> tuple[int, str]:
    """Main function to demonstrate pytest_generator_from_yaml usage."""

    # Define input and output paths

    output_dir = Path("/tmp")
    output_file = output_dir / "test_suite_from_yaml.py"

    print("=" * 60)
    print("pytest_generator_from_yaml - Example Usage")
    print("=" * 60)

    # Verify input file exists
    if not input_yaml.exists():
        print(f"\n❌ Error: Input file not found: {input_yaml}")
        return 1, ""

    print(f"\n📄 Input YAML file: {input_yaml}")
    print(f"📝 Output test file: {output_file}")

    # Display YAML content
    print("\n" + "─" * 60)
    print("YAML Test Suite Content:")
    print("─" * 60)
    with open(input_yaml, encoding="utf-8") as f:
        yaml_content = f.read()
        print(yaml_content)

    # Generate pytest file from YAML
    print("─" * 60)
    print("Generating pytest tests...")
    print("─" * 60)

    try:
        success = pytest_generator_from_yaml(str(input_yaml), str(output_file))

        if success:
            print("\n✅ Success! Pytest tests generated successfully!")
            print(f"\n📁 Generated file location: {output_file}")

            # Display generated content
            print("\n" + "─" * 60)
            print("Generated Pytest Test Code:")
            print("─" * 60)
            with open(output_file, encoding="utf-8") as f:
                generated_content = f.read()
                print(generated_content)

            # Show file statistics
            print("\n" + "─" * 60)
            print("Statistics:")
            print("─" * 60)
            lines = generated_content.split("\n")
            test_functions = [
                line for line in lines if line.strip().startswith("def test_")
            ]

            print(f"  - Total lines: {len(lines)}")
            print(f"  - Test functions: {len(test_functions)}")
            print(f"  - File size: {output_file.stat().st_size} bytes")

            if test_functions:
                print("\n  Generated test functions:")
                for func_line in test_functions:
                    func_name = func_line.strip().split("(")[0].replace("def ", "")
                    print(f"    • {func_name}")

            print("\n" + "=" * 60)
            print("✨ You can now run these tests with:")
            print(f"   pytest {output_file} -v")
            print("=" * 60)

            return 0, output_file.as_posix()
        else:
            print("\n❌ Failed to generate tests (returned False)")
            return 1, ""

    except FileNotFoundError as e:
        print(f"\n❌ File Error: {e}")
        return 1, ""
    except ValueError as e:
        print(f"\n❌ Validation Error: {e}")
        return 1, ""
    except Exception as e:
        print(f"\n❌ Unexpected Error: {type(e).__name__}: {e}")
        return 1, ""


def main() -> None:
    """Entry point for the script."""
    # Define common variables
    yaml_file = (
        Path(__file__).parent.parent
        / "tests"
        / "resources"
        / "multiple_valid_cases.yaml"
    )
    xml_file = Path("/tmp") / "test_result.xml"
    case_result_csv = Path("/tmp") / "case_result.csv"
    total_result_csv = Path("/tmp") / "total_result.csv"
    runtime_timeout = 60  # seconds

    print(f"\nStep 1: Generate pytest tests from YAML {yaml_file}...")
    exit_code, test_result_file = generate_pytest_from_yaml(yaml_file)
    if exit_code != 0 or not test_result_file:
        print("\n❌ Pytest generation failed, exiting.")
        return
    print(f"\nStep 1: Pytest generation exited with code {exit_code}")

    print("\nStep 2: Running generated pytest tests...")
    result = subprocess.run(
        ["uv", "run", "pytest", test_result_file, f"--junitxml={xml_file}"],
        timeout=runtime_timeout,
        check=False,
        capture_output=True,
        text=True,
    )
    status = "passed" if result.returncode == 0 else "executed with failures"
    print(f"\nStep 2: Tests {status} (exit code: {result.returncode})")

    if result.returncode != 0:
        if result.stdout:
            print(f"\n--- Test Output ---\n{result.stdout}")
        if result.stderr:
            print(f"\n--- Test Errors ---\n{result.stderr}")

    print(f"\nStep 3: Converting XML to {case_result_csv}...")
    if not xml_file.exists():
        print(f"\n⚠️  Warning: XML file not found at {xml_file}")
        return
    summary = convert_xml_to_csv(xml_file, case_result_csv)
    print(f"\nStep 3: Completed with {summary}")

    print(f"\nStep 4: Generating {total_result_csv}...")
    generate_summary_result(case_result_csv, total_result_csv)
    print(f"\nStep 4: Summary CSV generated at {total_result_csv}")


if __name__ == "__main__":
    """ Demostrate how to run YAML-type test using pytest framework"""

    try:
        print("\nStarting pytest execution...")
        main()
        print("\n✓ All tests completed successfully!")
    except ValueError as e:
        print(f"\nError: {e}")
    except ET.ParseError as e:
        print(f"\nError parsing XML file: {e}")
    except FileNotFoundError as e:
        print(f"\nError: File not found - {e}")
    except subprocess.TimeoutExpired as e:
        print(f"\nError: Test execution exceeded the timeout limit - {e}")
    except Exception as e:
        print(f"\nUnexpected error: {e}")
