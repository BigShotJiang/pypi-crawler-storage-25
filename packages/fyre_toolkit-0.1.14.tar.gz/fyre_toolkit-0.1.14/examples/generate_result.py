import xml.etree.ElementTree as ET
from pathlib import Path

from testkit.utils import convert_xml_to_csv, generate_summary_result

if __name__ == "__main__":
    # File paths
    xml_file = "resources/test_result.xml"
    case_result_csv = "resources/test_case_result.csv"
    total_result_csv = "resources/total_test_result.csv"

    # Check if XML file exists
    if not Path(xml_file).exists():
        print(f"Error: XML file '{xml_file}' not found!")
        print("Please update the xml_file variable with the correct path.")
    else:
        try:
            # Generate test_case_result.csv
            print(f"Step 1: Converting XML to {case_result_csv}...")
            summary = convert_xml_to_csv(xml_file, case_result_csv)

            print(f"\nStep 2: Generating {total_result_csv}...")
            # Generate total_test_result.csv from test_case_result.csv
            generate_summary_result(case_result_csv, total_result_csv)

            print("\n✓ Conversion completed successfully!")

        except ValueError as e:
            print(f"Error: {e}")
        except ET.ParseError as e:
            print(f"Error parsing XML file: {e}")
        except FileNotFoundError as e:
            print(f"Error: File not found - {e}")
        except Exception as e:
            print(f"Unexpected error: {e}")
