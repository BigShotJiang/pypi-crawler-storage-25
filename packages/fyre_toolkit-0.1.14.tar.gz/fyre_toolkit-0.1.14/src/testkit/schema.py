from pydantic import BaseModel, Field, field_validator, model_validator


class Command(BaseModel):
    executable: str = Field(..., description="Command executable path")
    args: list[str] = Field(default_factory=list, description="List of command args")

    @field_validator("executable")
    @classmethod
    def _validate_executable(cls, v):
        if not v:
            raise ValueError("command.executable is mandatory and cannot be empty")
        return v


class Expectations(BaseModel):
    exit_code: int | None = Field(None, description="Expected exit code")
    keywords: list[str] = Field(
        default_factory=list, description="Expected keywords in output"
    )

    @model_validator(mode="after")
    @classmethod
    def _validate_at_least_one_field(cls, v):
        if (not v.exit_code and v.exit_code != 0) and not v.keywords:
            raise ValueError("expectations must have exit_code or keywords")
        return v


class Step(BaseModel):
    command: Command | None = Field(None, description="test command in each step")
    timeout_sec: int = Field(default=60, ge=0)
    expectations: Expectations

    @field_validator("command")
    @classmethod
    def _validate_command(cls, v):
        if not v:
            raise ValueError("step.command is mandatory and cannot be empty")
        return v


class SetupCommand(BaseModel):
    executable: str
    args: list[str] = Field(default_factory=list)


class CleanupCommand(BaseModel):
    executable: str
    args: list[str] = Field(default_factory=list)


class PreConditions(BaseModel):
    setup_command: list[SetupCommand] = Field(
        default_factory=list, description="Setup command before the test case"
    )


class PostConditions(BaseModel):
    cleanup_command: list[CleanupCommand] = Field(
        default_factory=list, description="Cleanup command after the test case"
    )


class TestCaseMetadata(BaseModel):
    components: list[str] = Field(default_factory=list)
    enable: bool = Field(default=True)
    tags: list[str] = Field(default_factory=list)


class TestCase(BaseModel):
    name: str
    description: str | None = Field(default="")
    metadata: TestCaseMetadata = Field(default_factory=TestCaseMetadata)
    pre_conditions: PreConditions | None = Field(
        default_factory=PreConditions, description="Precondition if have"
    )
    steps: list[Step] = Field(default_factory=list, description="Test case steps")
    post_conditions: PostConditions | None = Field(
        default_factory=PostConditions, description="Postcondition if have"
    )

    @field_validator("name")
    @classmethod
    def _validate_name(cls, v):
        if not v or not v.strip():
            raise ValueError("test_cases.name is mandatory and cannot be empty")
        return v

    @field_validator("steps")
    @classmethod
    def _validate_steps(cls, v):
        if not v and len(v) == 0:
            raise ValueError("test_cases.steps is mandatory and cannot be empty")
        return v


class TestSuiteMetadata(BaseModel):
    name: str
    component: list[str] = Field(default_factory=list)
    tags: set[str] = Field(default_factory=set)

    @field_validator("name")
    @classmethod
    def _validate_name(cls, v):
        if not v or not v.strip():
            raise ValueError("test_suite.name is mandatory and cannot be empty")
        return v

    @field_validator("component")
    @classmethod
    def _validate_metadata_component(cls, v):
        if not v:
            raise ValueError(
                "test_suite.metadata.component is mandatory and cannot be empty"
            )
        return v


class TestSuite(BaseModel):
    metadata: TestSuiteMetadata
    test_cases: list[TestCase] = Field(
        default_factory=list, description="a group of test case"
    )

    @field_validator("metadata")
    @classmethod
    def _validate_suite_name(cls, v):
        if not v.name or not v.name.strip():
            raise ValueError(
                "test_suite.metadata.name is mandatory and cannot be empty"
            )
        return v

    @field_validator("test_cases")
    @classmethod
    def _validate_test_cases(cls, v):
        if len(v) == 0:
            raise ValueError("test_suite.test_cases is mandatory and cannot be empty")
        return v
