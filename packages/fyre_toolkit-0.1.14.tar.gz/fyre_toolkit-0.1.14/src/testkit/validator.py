from typing import Any

import yaml


class SchemaValidationError(Exception):
    """Custom exception for schema validation errors."""

    pass


class YAMLSchemaValidator:
    def __init__(self):
        self.errors = []

    def validate_string(
        self, value: Any, field_name: str, no_spaces: bool = False
    ) -> bool:
        """Validate that a value is a string."""
        if not isinstance(value, str):
            self.errors.append(
                f"Field '{field_name}' must be a string, got {type(value).__name__}"
            )
            return False

        if no_spaces and " " in value:
            self.errors.append(f"Field '{field_name}' cannot contain blank spaces")
            return False

        return True

    def validate_array(
        self, value: Any, field_name: str, element_type: type = str
    ) -> bool:
        """Validate that a value is an array of specified type."""
        if not isinstance(value, list):
            self.errors.append(
                f"Field '{field_name}' must be an array, got {type(value).__name__}"
            )
            return False

        for idx, item in enumerate(value):
            if not isinstance(item, element_type):
                self.errors.append(
                    f"Field '{field_name}[{idx}]' must be {element_type.__name__}, got {type(item).__name__}"
                )
                return False

        return True

    def validate_int(self, value: Any, field_name: str) -> bool:
        """Validate that a value is an integer."""
        if not isinstance(value, int) or isinstance(value, bool):
            self.errors.append(
                f"Field '{field_name}' must be an integer, got {type(value).__name__}"
            )
            return False
        return True

    def validate_bool(self, value: Any, field_name: str) -> bool:
        """Validate that a value is a boolean."""
        if not isinstance(value, bool):
            self.errors.append(
                f"Field '{field_name}' must be a boolean, got {type(value).__name__}"
            )
            return False
        return True

    def check_field_exists(
        self, data: dict, field_path: str, parent_path: str = ""
    ) -> bool:
        """Check if a field exists in nested dictionary structure."""
        keys = field_path.split(".")
        current = data
        full_path = parent_path

        for key in keys:
            full_path = f"{full_path}.{key}" if full_path else key
            if not isinstance(current, dict) or key not in current:
                self.errors.append(f"Mandatory field '{full_path}' is missing")
                return False
            current = current[key]

        return True

    def get_nested_value(self, data: dict, field_path: str) -> Any:
        """Get value from nested dictionary structure."""
        keys = field_path.split(".")
        current = data

        for key in keys:
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                return None

        return current

    def validate_metadata(
        self, metadata: dict, parent_path: str = "test_suite.metadata"
    ) -> bool:
        """Validate metadata section."""
        valid = True

        # Mandatory: name
        if "name" not in metadata:
            self.errors.append(f"Mandatory field '{parent_path}.name' is missing")
            valid = False
        elif not self.validate_string(metadata["name"], f"{parent_path}.name"):
            valid = False

        # Mandatory: component
        if "component" not in metadata:
            self.errors.append(f"Mandatory field '{parent_path}.component' is missing")
            valid = False
        elif not self.validate_array(metadata["component"], f"{parent_path}.component"):
            valid = False

        # Mandatory: tags
        if "tags" not in metadata:
            self.errors.append(f"Mandatory field '{parent_path}.tags' is missing")
            valid = False
        elif not self.validate_array(metadata["tags"], f"{parent_path}.tags"):
            valid = False

        return valid

    def validate_setup_command(self, setup_commands: list, parent_path: str) -> bool:
        """Validate setup_command section."""
        valid = True

        if not isinstance(setup_commands, list):
            self.errors.append(f"Field '{parent_path}' must be an array")
            return False

        for idx, cmd in enumerate(setup_commands):
            cmd_path = f"{parent_path}[{idx}]"

            # Mandatory: executable
            if "executable" not in cmd:
                self.errors.append(
                    f"Mandatory field '{cmd_path}.executable' is missing"
                )
                valid = False
            elif not self.validate_string(
                cmd["executable"], f"{cmd_path}.executable", no_spaces=True
            ):
                valid = False

            # Mandatory: args
            if "args" not in cmd:
                self.errors.append(f"Mandatory field '{cmd_path}.args' is missing")
                valid = False
            elif not self.validate_array(cmd["args"], f"{cmd_path}.args"):
                valid = False

        return valid

    def validate_steps(self, steps: list, parent_path: str) -> bool:
        """Validate steps section."""
        valid = True

        if not isinstance(steps, list):
            self.errors.append(f"Field '{parent_path}' must be an array")
            return False

        for idx, step in enumerate(steps):
            step_path = f"{parent_path}[{idx}]"

            # Mandatory: command
            if "command" not in step:
                self.errors.append(f"Mandatory field '{step_path}.command' is missing")
                valid = False
                continue

            command = step["command"]

            # Mandatory: command.executable
            if "executable" not in command:
                self.errors.append(
                    f"Mandatory field '{step_path}.command.executable' is missing"
                )
                valid = False
            elif not self.validate_string(
                command["executable"], f"{step_path}.command.executable", no_spaces=True
            ):
                valid = False

            # Mandatory: command.args
            if "args" not in command:
                self.errors.append(
                    f"Mandatory field '{step_path}.command.args' is missing"
                )
                valid = False
            elif not self.validate_array(command["args"], f"{step_path}.command.args"):
                valid = False

            # Optional: timeout_sec (if present, must be int)
            if "timeout_sec" in step:
                self.validate_int(step["timeout_sec"], f"{step_path}.timeout_sec")

            # Mandatory: expectations
            if "expectations" not in step:
                self.errors.append(
                    f"Mandatory field '{step_path}.expectations' is missing"
                )
                valid = False
                continue

            expectations = step["expectations"]

            # Mandatory: expectations.exit_code
            if "exit_code" not in expectations:
                self.errors.append(
                    f"Mandatory field '{step_path}.expectations.exit_code' is missing"
                )
                valid = False
            elif not self.validate_int(
                expectations["exit_code"], f"{step_path}.expectations.exit_code"
            ):
                valid = False

            # Mandatory: expectations.keywords
            if "keywords" not in expectations:
                self.errors.append(
                    f"Mandatory field '{step_path}.expectations.keywords' is missing"
                )
                valid = False
            elif not self.validate_array(
                expectations["keywords"], f"{step_path}.expectations.keywords"
            ):
                valid = False

        return valid

    def validate_cleanup_command(
        self, cleanup_commands: list, parent_path: str
    ) -> bool:
        """Validate cleanup_command section."""
        valid = True

        if not isinstance(cleanup_commands, list):
            self.errors.append(f"Field '{parent_path}' must be an array")
            return False

        for idx, cmd in enumerate(cleanup_commands):
            cmd_path = f"{parent_path}[{idx}]"

            # Mandatory: executable
            if "executable" not in cmd:
                self.errors.append(
                    f"Mandatory field '{cmd_path}.executable' is missing"
                )
                valid = False
            elif not self.validate_string(
                cmd["executable"], f"{cmd_path}.executable", no_spaces=True
            ):
                valid = False

            # Mandatory: args
            if "args" not in cmd:
                self.errors.append(f"Mandatory field '{cmd_path}.args' is missing")
                valid = False
            elif not self.validate_array(cmd["args"], f"{cmd_path}.args"):
                valid = False

        return valid

    def validate_test_case(self, test_case: dict, idx: int) -> bool:
        """Validate a single test case."""
        valid = True
        tc_path = f"test_suite.test_cases[{idx}]"

        # Mandatory: name
        if "name" not in test_case:
            self.errors.append(f"Mandatory field '{tc_path}.name' is missing")
            valid = False
        elif not self.validate_string(test_case["name"], f"{tc_path}.name"):
            valid = False

        # Optional: description
        if "description" in test_case:
            self.validate_string(test_case["description"], f"{tc_path}.description")

        # Optional: metadata
        if "metadata" in test_case:
            metadata = test_case["metadata"]
            if "components" in metadata:
                self.validate_array(
                    metadata["components"], f"{tc_path}.metadata.components"
                )
            if "enable" in metadata:
                self.validate_bool(metadata["enable"], f"{tc_path}.metadata.enable")
            if "tags" in metadata:
                self.validate_array(metadata["tags"], f"{tc_path}.metadata.tags")

        # Mandatory: pre_conditions.setup_command
        if "pre_conditions" not in test_case:
            self.errors.append(f"Mandatory field '{tc_path}.pre_conditions' is missing")
            valid = False
        elif "setup_command" not in test_case["pre_conditions"]:
            self.errors.append(
                f"Mandatory field '{tc_path}.pre_conditions.setup_command' is missing"
            )
            valid = False
        else:
            if not self.validate_setup_command(
                test_case["pre_conditions"]["setup_command"],
                f"{tc_path}.pre_conditions.setup_command",
            ):
                valid = False

        # Mandatory: steps
        if "steps" not in test_case:
            self.errors.append(f"Mandatory field '{tc_path}.steps' is missing")
            valid = False
        else:
            if not self.validate_steps(test_case["steps"], f"{tc_path}.steps"):
                valid = False

        # Mandatory: post_conditions.cleanup_command
        if "post_conditions" not in test_case:
            self.errors.append(
                f"Mandatory field '{tc_path}.post_conditions' is missing"
            )
            valid = False
        elif "cleanup_command" not in test_case["post_conditions"]:
            self.errors.append(
                f"Mandatory field '{tc_path}.post_conditions.cleanup_command' is missing"
            )
            valid = False
        else:
            if not self.validate_cleanup_command(
                test_case["post_conditions"]["cleanup_command"],
                f"{tc_path}.post_conditions.cleanup_command",
            ):
                valid = False

        return valid

    def validate(self, yaml_file_path: str) -> bool:
        """Main validation method."""
        self.errors = []

        try:
            # Load YAML file
            with open(yaml_file_path) as file:
                data = yaml.safe_load(file)
        except FileNotFoundError:
            self.errors.append(f"File not found: {yaml_file_path}")
            return False
        except yaml.YAMLError as e:
            self.errors.append(f"YAML parsing error: {e}")
            return False

        if not isinstance(data, dict):
            self.errors.append("Root element must be a dictionary")
            return False

        # Mandatory: test_suite
        if "test_suite" not in data:
            self.errors.append("Mandatory field 'test_suite' is missing")
            return False

        test_suite = data["test_suite"]
        valid = True

        # Mandatory: metadata
        if "metadata" not in test_suite:
            self.errors.append("Mandatory field 'test_suite.metadata' is missing")
            valid = False
        else:
            if not self.validate_metadata(test_suite["metadata"]):
                valid = False

        # Mandatory: test_cases
        if "test_cases" not in test_suite:
            self.errors.append("Mandatory field 'test_suite.test_cases' is missing")
            valid = False
        elif not isinstance(test_suite["test_cases"], list):
            self.errors.append("Field 'test_suite.test_cases' must be an array")
            valid = False
        else:
            for idx, test_case in enumerate(test_suite["test_cases"]):
                if not self.validate_test_case(test_case, idx):
                    valid = False

        return valid

    def get_errors(self) -> list[str]:
        """Return list of validation errors."""
        return self.errors

    def print_errors(self):
        """Print all validation errors."""
        if self.errors:
            print(f"\n❌ Validation failed with {len(self.errors)} error(s):\n")
            for idx, error in enumerate(self.errors, 1):
                print(f"  {idx}. {error}")
        else:
            print("\n✅ Validation successful! YAML file conforms to the schema.")
