import csv
import datetime
import xml.etree.ElementTree as ET
from pathlib import Path


def uniq_workspace_dir(root: str = ".", prefix: str = "workspace") -> str:
    """Creates a unique workspace directory with timestamp suffix.

    Args:
        root: Parent directory path. Defaults to current directory.
        prefix: Directory name prefix. Will be truncated if too long.

    Returns:
        Absolute path to created directory

    Raises:
        OSError: If directory creation fails
    """
    ts = datetime.datetime.now(datetime.UTC).strftime("%Y%m%d%H%M%S")

    # Limit prefix length to avoid filesystem errors
    max_prefix_length = 50  # Conservative limit for most filesystems
    safe_prefix = prefix[:max_prefix_length]

    path = Path(root) / f"{safe_prefix}-{ts}"
    path.mkdir(parents=True, exist_ok=True)
    return str(path.resolve())


def convert_xml_to_csv(xml_file_path, csv_file_path):
    """
    Convert pytest XML report to CSV format with test case details.

    Args:
        xml_file_path: Path to the input XML file
        csv_file_path: Path to the output CSV file (case_result.csv)

    Returns:
        dict: Summary statistics containing total_cases, success_cases,
              failures, skipped, and total_time
    """
    # Parse XML file
    tree = ET.parse(xml_file_path)
    root = tree.getroot()

    # Get testsuite element
    testsuite = root.find("testsuite")

    # Verify testsuite exists
    if testsuite is None:
        # Check if root itself is testsuite
        if root.tag == "testsuite":
            testsuite = root
        else:
            raise ValueError(
                "Invalid XML format: 'testsuite' element not found in the XML file"
            )

    # Extract summary statistics
    total_cases: int = int(testsuite.get("tests", 0))
    failures: int = int(testsuite.get("failures", 0))
    skipped: int = int(testsuite.get("skipped", 0))
    errors: int = int(testsuite.get("errors", 0))
    total_time: float = float(testsuite.get("time", 0))

    # Calculate success cases (total - failures - skipped - errors)
    success_cases = total_cases - failures - skipped - errors

    # Open CSV file for writing
    with open(csv_file_path, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)

        # Write test case details header
        writer.writerow(["CASE_CLASSNAME", "CASE_NAME", "TIME", "TEST_RESULT", "MESSAGE"])

        # Process each testcase
        for testcase in testsuite.findall("testcase"):
            classname = testcase.get("classname", "")
            name = testcase.get("name", "")
            time = testcase.get("time", "0")
            message = "-"

            # Determine test result
            if testcase.find("failure") is not None:
                result = "FAILURE"
                failure = testcase.find("failure")
                if failure is not None:
                    message = failure.get("message", "-")
            elif testcase.find("error") is not None:
                result = "ERROR"
                error = testcase.find("error")
                if error is not None:
                    message = error.get("message", "-")
            elif testcase.find("skipped") is not None:
                result = "SKIPPED"
                skip = testcase.find("skipped")
                if skip is not None:
                    message = skip.get("message", "-")
            else:
                result = "SUCCESS"

            writer.writerow([classname, name, time, result, message])

    print(f"Case results saved to: {csv_file_path}")

    # Return summary statistics
    return {
        "total_cases": total_cases,
        "success_cases": success_cases,
        "failures": failures,
        "skipped": skipped,
        "total_time": total_time,
    }


def convert_kd_to_csv(kd_file_path, csv_file_path):
    """
    Convert KD test report to CSV format with test case details.

    Args:
        kd_file_path: Path to the input KD file
        csv_file_path: Path to the output CSV file (case_result.csv)

    Returns:
        dict: Summary statistics containing total_cases, success_cases,
              failures, skipped, and total_time

    Raises:
        ValueError: If mandatory fields are missing or file format is invalid
        UnicodeDecodeError: If file cannot be decoded with UTF-8 or GB2312
    """
    # Try reading with UTF-8 first, then fall back to GB2312
    content = None
    for encoding in ["utf-8", "gb2312"]:
        try:
            with open(kd_file_path, encoding=encoding) as f:
                content = f.read()
            break
        except UnicodeDecodeError:
            continue

    if content is None:
        raise UnicodeDecodeError(
            "utf-8", b"", 0, 1, "Failed to decode KD file with UTF-8 or GB2312 encoding"
        )

    lines = content.strip().split("\n")

    # Parse metadata section
    metadata = {}
    test_cases_start_idx = 0

    for idx, line in enumerate(lines):
        line = line.strip()
        if not line:
            continue

        # Check if this line starts a test case (begins with a number)
        if line[0].isdigit():
            test_cases_start_idx = idx
            break

        # Parse metadata using flexible separator (tabs or multiple spaces)
        parts = [p.strip() for p in line.split("\t") if p.strip()]
        if len(parts) < 2:
            # Try splitting by multiple spaces
            parts = [p.strip() for p in line.split() if p.strip()]

        if len(parts) >= 2:
            key = parts[0]
            value = parts[1] if len(parts) == 2 else " ".join(parts[1:])
            metadata[key] = value

    # Validate mandatory fields
    if "测试内容" not in metadata:
        raise ValueError("Mandatory field '测试内容' not found in KD file")

    test_content = metadata["测试内容"]

    # Extract summary statistics from metadata
    total_cases = int(metadata.get("总测试用例数", 0))
    success_cases = int(metadata.get("通过用例数", metadata.get("通过测试用例数", 0)))
    failures = int(metadata.get("失败用例数", metadata.get("失败测试用例数", 0)))
    skipped = 0  # KD format doesn't have skipped cases

    # Parse total time
    time_str = metadata.get("测试耗时", "0秒")
    # Remove '秒' and extract numeric value
    time_str = time_str.replace("秒", "").strip()
    try:
        total_time = float(time_str)
    except ValueError:
        total_time = 0.0

    # Generate CASE_CLASSNAME pattern
    case_classname = f"cases.{test_content}"

    # Open CSV file for writing
    with open(csv_file_path, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)

        # Write test case details header
        writer.writerow(
            ["CASE_CLASSNAME", "CASE_NAME", "TIME", "TEST_RESULT", "MESSAGE"]
        )

        # Process each test case line
        for line in lines[test_cases_start_idx:]:
            line = line.strip()
            if not line or not line[0].isdigit():
                continue

            # Parse test case line with flexible separator handling
            # First try splitting by tabs
            parts = [p.strip() for p in line.split("\t") if p.strip()]

            # If we get less than 3 parts, try splitting by multiple spaces
            if len(parts) < 3:
                parts = [p.strip() for p in line.split() if p.strip()]

            if len(parts) < 3:
                continue  # Skip malformed lines

            # Parse fields
            case_number = parts[0]
            status = parts[1]

            # Description is everything from index 2 onwards
            description = " ".join(parts[2:]) if len(parts) > 2 else "-"

            # Map status to standard format
            if status == "成功":
                result = "SUCCESS"
            elif status == "失败":
                result = "FAILURE"
            else:
                result = "UNKNOWN"

            # Generate CASE_NAME pattern
            case_name = f"test_{test_content}_{case_number}"

            # Write row with time as 0
            writer.writerow([case_classname, case_name, 0, result, description])

    print(f"Case results saved to: {csv_file_path}")

    # Return summary statistics (matching convert_xml_to_csv signature)
    return {
        "total_cases": total_cases,
        "success_cases": success_cases,
        "failures": failures,
        "skipped": skipped,
        "total_time": total_time,
    }


def generate_summary_result(case_result_csv_path, total_result_csv_path):
    """
    Generate summary CSV file from case result CSV file.

    Args:
        case_result_csv_path: Path to the case_result.csv file
        total_result_csv_path: Path to the output total_result.csv file
    """
    # Read case results and calculate summary
    total_cases = 0
    success_cases = 0
    failure_cases = 0
    skipped_cases = 0
    total_time = 0.0

    with open(case_result_csv_path, newline="", encoding="utf-8") as csvfile:
        reader = csv.DictReader(csvfile)

        for row in reader:
            total_cases += 1
            result = row["TEST_RESULT"]

            if result == "SUCCESS":
                success_cases += 1
            elif result == "FAILURE" or result == "ERROR":
                failure_cases += 1
            elif result == "SKIPPED":
                skipped_cases += 1

            total_time += float(row["TIME"])

    # Write summary to total_result.csv
    with open(total_result_csv_path, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)

        # Write summary header
        writer.writerow(
            [
                "TOTAL_CASES",
                "SUCCESS_CASES",
                "FAILURE_CASES",
                "SKIPPED_CASES",
                "TOTAL_TIME",
            ]
        )

        # Write summary data
        writer.writerow(
            [
                total_cases,
                success_cases,
                failure_cases,
                skipped_cases,
                f"{total_time:.3f}",
            ]
        )

    print(f"Total results saved to: {total_result_csv_path}")
    print("\nSummary:")
    print(f"  Total test cases: {total_cases}")
    print(f"  Success: {success_cases}")
    print(f"  Failures: {failure_cases}")
    print(f"  Skipped: {skipped_cases}")
    print(f"  Total time: {total_time:.3f}s")


def _check_package():
    from testkit.__init__ import __version__
    print(
        f"Fyre TestKit package is installed with version {__version__} and working correctly. ;-)"
    )
