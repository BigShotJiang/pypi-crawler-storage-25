import logging
from pathlib import Path
from typing import Any

import yaml

from .schema import TestSuite


def aggregate_test_components_from_yaml(
    file_path: str,
) -> dict[str, Any]:
    """Aggregates test components

    Args:
        suite (TestSuite): The test suite containing test cases.

    Returns:
        dict[str, Any]: A dictionary  component names to .
    """
    aggregated: dict[str, int] = {}

    # Validate input file
    input_path = Path(file_path)

    if not input_path.is_file():
        raise FileNotFoundError(
            f"The case file does not exist or is not a file: {file_path}"
        )

    if not input_path.suffixes or input_path.suffixes[-1].lower() not in [
        ".yaml",
        ".yml",
    ]:
        raise FileNotFoundError(f"The case file is not a YAML file: {file_path}")

    try:
        # Parse YAML file
        with open(input_path, encoding="utf-8") as f:
            yaml_content = yaml.safe_load(f)

        # Extract test_suite from YAML structure
        if not isinstance(yaml_content, dict) or "test_suite" not in yaml_content:
            raise ValueError(
                "YAML file must contain 'test_suite' key at root level and be a dictionary"
            )

        # Parse into TestSuite object
        test_suite = TestSuite(**yaml_content["test_suite"])

        # Aggregate components
        for comp in test_suite.metadata.component:
            aggregated[comp] = aggregated[comp] + 1 if comp in aggregated.keys() else 1

    except Exception as e:
        logging.exception(f"Error in aggregate_test_components_from_yaml: {e}")
        raise RuntimeError(f"Error in aggregate_test_components_from_yaml: {e}") from e

    return aggregated
