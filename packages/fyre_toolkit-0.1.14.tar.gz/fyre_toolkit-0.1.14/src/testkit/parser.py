import pathlib

import yaml
from pydantic import ValidationError

from .schema import TestSuite


def _load_yaml_file(file_path: str) -> dict:
    p = pathlib.Path(file_path)
    if not p.exists():
        raise FileNotFoundError(f"YAML file not found: {file_path}")
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_and_validate_yaml(file_path: str) -> TestSuite:
    """Loads and validates a YAML file against the TestSuite schema.

    The function performs the following operations:
    1. Loads the YAML file content
    2. Validates the presence of the root 'test_suite' key
    3. Parses and validates the content against the TestSuite Pydantic model

    Args:
        file_path (str): Path to the YAML file containing the test suite definition.

    Returns:
        TestSuite: Validated TestSuite object parsed from the YAML file.

    Raises:
        FileNotFoundError: If the specified YAML file does not exist.
        ValueError: If the root 'test_suite' key is missing in the YAML.
        ValidationError: If the YAML content fails schema validation.
        yaml.YAMLError: If the YAML file contains syntax errors.

    Example:
        >>> suite = load_and_validate_yaml("tests/test_suite.yaml")
        >>> print(suite.metadata.name)
        "Sample Test Suite"
    """
    data = _load_yaml_file(file_path)
    if "test_suite" not in data:
        raise ValueError("Root key 'test_suite' not found in YAML")

    try:
        ts = TestSuite.model_validate(data["test_suite"])
        return ts
    except ValidationError as e:
        raise e
