# Fyre Tool Kit

## 介绍
一款使用pytest框架生成测试用例的便捷开发工具包.

## 软件架构
软件架构说明

## 特点:
- YAML -> Pydantic模式验证
- 强制字段检查
- 生成与pytest兼容的测试模块（每个test_suite一个模块）
- 用于将生成的测试写入磁盘的实用程序

## 发布包到 Gitea PyPI 包注册表
1. 配置包注册表以编辑本地 `~/.pypirc` 文件
```init
[distutils]
index-servers = gitea
[gitea]
repository = https://gitea.example.com/api/packages/{owner}/pypi
username = {username}
password = {password}
```
占位符 | 描述
--- | ---
`owner` | 包的所有者。
`username` | 您的 Gitea 用户名。
`password` | 您的 Gitea 密码。如果您使用 2FA 或 OAuth，请使用个人访问令牌代替密码。
2. 通过运行以下命令发布包
```bash
$ uv run python3 -m twine upload --repository gitea /path/to/files/*
```
3. 从包注册表安装 PyPI 包，执行以下命令：
```bash
$ uv pip install --index-url https://{username}:{password}@gitea.example.com/api/packages/{owner}/pypi/simple --no-deps {package_name}
```
参数 | 描述
--- | ---
username | 您的 Gitea 用户名。
password | 您的 Gitea 密码或个人访问令牌。
owner | 包的所有者。
package_name | 包的名称。
例如：
```bash
$ uv pip install --index-url https://xxx:xxxx@gitea.example.com/api/packages/testuser/pypi/simple --no-deps test_package
```
您可以使用 `--extra-index-url` 代替 `--index-url`，但这会使您容易受到依赖混淆攻击，因为 `pip` 在检查指定的自定义仓库之前会检查官方 PyPi 仓库中的包。阅读 `pip` 文档以获取更多信息。
## 安装包以供其他项目使用
1. 以“可编辑”模式安装本地项目
```bash
$ uv pip install -e <project_dir>
```
2. 从 VCS 以“可编辑”模式安装项目
```bash
$ uv pip install -e "fyre-toolkit@git+https://gitea.com/marc_pango/fyre_toolkit.git"   # 从 git 安装
```

## 参与贡献

1.  克隆本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建工单和Pull Request


**参考资料表**  
- **Gitea Package** https://docs.gitea.com/usage/packages/pypi  
- **PIP Install** https://pip.pypa.io/en/stable/cli/pip_install  
- **UV Build** https://docs.astral.sh/uv/concepts/projects/build  
