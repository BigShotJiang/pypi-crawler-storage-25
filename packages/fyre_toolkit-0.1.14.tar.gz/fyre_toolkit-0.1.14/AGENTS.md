# AGENTS.md — Fyre Toolkit

> Guidelines for agentic coding agents operating in this repository.

## Project Overview

Python 3.12+ package (`fyre-toolkit`) that generates pytest test cases from YAML definitions using Pydantic schema validation. Built with `uv` + `hatchling`.

## Build / Lint / Test Commands

### Dependency Management
```bash
uv sync                    # Install all deps (including dev)
uv lock --no-cache         # Re-lock dependencies
```

### Linting
```bash
uv run ruff check           # Lint src/ (excludes tests/)
uv run ruff check --fix     # Auto-fix linting issues
```

### Type Checking
```bash
uv run mypy src/            # Strict type checking
```

### Testing
```bash
uv run pytest               # Run all tests (with coverage)
uv run pytest -k "keyword"  # Run tests matching keyword
uv run pytest tests/test_testkit_parser.py                    # Single file
uv run pytest tests/test_testkit_parser.py::TestLoadYamlFile  # Single class
uv run pytest tests/test_testkit_parser.py::TestLoadYamlFile::test_load_valid_file  # Single test
uv run pytest -v            # Verbose output
uv run pytest --no-cov      # Run without coverage (faster)
```

### Coverage
```bash
uv run pytest --cov=src --cov-report=term    # Terminal report
uv run pytest --cov=src --cov-report=html    # HTML report in htmlcov/
```

### Building
```bash
uv build --wheel             # Build wheel distribution
uv run twine upload ...      # Publish to PyPI
```

### CI Pipeline (Jenkinsfile)
- **PR branches**: `pytest --cov=src` + `diff-cover --fail-under=80`
- **Main branch**: `pytest --cov=src --cov-fail-under=80` + SonarQube scan

## Code Style

### Imports
- Standard library → third-party → local, separated by blank lines (isort ordering via ruff `I`)
- Use `from pathlib import Path` instead of `os.path`
- Use `collections.abc` for type hints (`Callable`, `Iterator`)

### Formatting
- 4-space indentation, UTF-8 encoding
- Max line length: 80 characters (ruff ignores E501 but .editorconfig enforces 80)
- LF line endings, trailing newline required
- Use `uv run ruff check --fix` before committing

### Type Hints
- **mypy strict mode** is enforced — no `Any`, no suppressed errors
- All function parameters and return types must be annotated
- Use `collections.abc` types: `Callable[[str, str], str]`, `Iterator[str]`
- Pydantic v2 models for data structures (`model_dump()`, not `.dict()`)

### Naming Conventions
- Modules: `snake_case` (e.g., `generator.py`, `testkit_utils.py`)
- Classes: `PascalCase` (e.g., `TestCase`, `TestSuite`, `TestLoadYamlFile`)
- Functions/variables: `snake_case` (e.g., `sanitize_identifier`, `test_suite`)
- Constants: `UPPER_SNAKE_CASE` (e.g., `PYTEST_MODULE_HEADER`)
- Private helpers: leading underscore (e.g., `_load_yaml_file`, `_check_package`)
- Test classes: `Test` + CamelCase (e.g., `TestLoadYamlFile`)
- Test methods: `test_` + snake_case (e.g., `test_load_valid_file`)

### Docstrings
- Google-style with triple-quoted strings
- Include: brief description, Args, Returns, Raises, Example sections
- Doctest examples encouraged for pure functions

### Error Handling
- Raise specific exceptions: `TypeError`, `ValueError`, `FileNotFoundError`, `RuntimeError`
- Use descriptive error messages with context (e.g., f-strings with file paths)
- Chain exceptions with `from e` when re-raising (except where ruff allows `B904`)
- Use `pytest.raises` for testing expected exceptions
- Log exceptions with `logging.exception()` before re-raising in library code

### Testing Patterns
- Use pytest fixtures in `conftest.py` for shared test data
- Class-based tests for grouping related test methods
- Use `unittest.mock.patch` for mocking external dependencies
- Use `tmp_path` fixture for temporary file testing
- Integration tests alongside unit tests (see `test_integration_*`)
- Test resources (YAML files) go in `tests/resources/`

### Pydantic Models
- Use Pydantic v2 (`model_dump()`, not `.dict()`)
- Models defined in `testkit/schema.py` — do not duplicate
- Validation errors surface as `pydantic.ValidationError`

## Project Structure
```
src/testkit/          # Main package
  __init__.py         # Public API exports, __version__
  schema.py           # Pydantic models (TestCase, TestSuite, etc.)
  parser.py           # YAML loading and validation
  generator.py        # Pytest code generation
  aggregator.py       # Component aggregation
  utils.py            # Utility functions
tests/                # Test suite
  conftest.py         # Shared pytest fixtures
  resources/          # Test data (YAML files)
  test_testkit_*.py   # Test modules (one per source module)
examples/             # Usage examples
```

## Key Constraints
- **Never suppress type errors** (`as any`, `# type: ignore`, `@ts-ignore`)
- **Never commit** unless explicitly requested
- **Match existing patterns** — this codebase is disciplined; follow its style
- **Fix minimally** — do not refactor while fixing bugs
- **Run `ruff check`** on changed files before declaring work complete
