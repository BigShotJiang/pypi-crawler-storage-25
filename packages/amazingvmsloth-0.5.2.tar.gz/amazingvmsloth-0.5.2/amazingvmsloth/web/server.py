import threading
import queue
import json
import os
import sys
import time
from typing import Optional, Dict, Any
from dataclasses import dataclass, asdict

try:
    from flask import Flask, request, jsonify, Response, send_from_directory
    _flask_available = True
except ImportError:
    _flask_available = False

_app: Optional[Any] = None
_training_thread: Optional[threading.Thread] = None
_stop_event = threading.Event()
_log_queue: queue.Queue = queue.Queue()
_status: Dict[str, Any] = {"state": "idle", "step": 0, "total_steps": 0, "loss": 0.0, "vram": 0.0, "start_time": None, "elapsed": 0, "history": []}


def _update_status(**kwargs):
    _status.update(kwargs)


def _parse_log_line(line: str) -> Optional[Dict[str, Any]]:
    """Parse training log lines for metrics."""
    line = line.strip()
    if not line:
        return None
    # Parse: Step [X/Y] Loss: N | Speed: S | VRAM: V
    if "Step [" in line and "Loss:" in line:
        try:
            step_part = line.split("Step [")[1].split("]")[0]
            current, total = step_part.split("/")
            loss = float(line.split("Loss:")[1].split("|")[0].strip())
            vram_part = line.split("VRAM:")[1].split("|")[0].strip() if "VRAM:" in line else "0/0"
            vram = float(vram_part.split("/")[0].strip())
            return {"step": int(current), "total_steps": int(total), "loss": loss, "vram": vram}
        except Exception:
            pass
    # Parse tqdm-like: N%|...| X/Y [... loss=N, vram=VGB]
    if "%|" in line and "step" in line:
        try:
            parts = line.split("|")
            for p in parts:
                if "/" in p and p.strip().replace("/", "").replace(" ", "").isdigit():
                    current, total = p.strip().split("/")[:2]
                    _status["step"] = int(current)
                    _status["total_steps"] = int(total)
            if "loss=" in line:
                loss_str = line.split("loss=")[1].split(",")[0].strip()
                _status["loss"] = float(loss_str)
            if "vram=" in line or "vram=" in line.lower():
                vram_str = line.split("vram=")[1].split("GB")[0].strip() if "vram=" in line else "0"
                _status["vram"] = float(vram_str)
        except Exception:
            pass
    # Parse progress bar: 10/1000 [...]
    if "/" in line and ("Training" in line or "step" in line.lower()):
        try:
            ratio = line.split("|")[1].strip().split(" ")[0] if "|" in line else ""
            if "/" in ratio:
                current, total = ratio.split("/")[:2]
                _status["step"] = int(current)
                _status["total_steps"] = int(total)
        except Exception:
            pass
    return None


class _LogCapture:
    """Context manager to capture stdout/stderr to a queue."""
    def __init__(self, q: queue.Queue):
        self.q = q
        self._stdout = sys.stdout
        self._stderr = sys.stderr

    def write(self, s: str):
        self._stdout.write(s)
        self._stdout.flush()
        self.q.put(s)

    def flush(self):
        self._stdout.flush()

    def __enter__(self):
        sys.stdout = self
        sys.stderr = self
        return self

    def __exit__(self, *args):
        sys.stdout = self._stdout
        sys.stderr = self._stderr


def _run_training(params: Dict[str, Any]):
    import torch
    from transformers import AutoTokenizer
    from datasets import load_dataset
    from amazingvmsloth import (
        quantize_model_4bit,
        apply_lora,
        LoRAConfig,
        AmazingTrainer,
        TrainingConfig,
        auto_patch_model,
    )
    from amazingvmsloth.utils.banner import get_system_info

    try:
        _update_status(state="loading", message="Loading model...")
        _log_queue.put("[web] Starting training with parameters: " + json.dumps(params) + "\n")

        model_name = params.get("model", "Qwen/Qwen2.5-0.5B")
        dataset_name = params.get("dataset", "tatsu-lab/alpaca")
        max_steps = int(params.get("max_steps", 100))
        batch_size = int(params.get("batch_size", 2))
        grad_accum = int(params.get("grad_accum", 4))
        lora_r = int(params.get("lora_r", 16))
        lora_alpha = int(params.get("lora_alpha", 32))
        lr = float(params.get("lr", 2e-4))
        max_seq_length = int(params.get("max_seq_length", 512))
        quant = params.get("quant", "none")
        optimizer = params.get("optimizer", "adamw")
        bf16 = params.get("bf16", True)
        cpu = params.get("cpu", False)
        modality = params.get("modality", "text")
        image_size = int(params.get("image_size", 336))
        num_video_frames = int(params.get("num_video_frames", 8))
        output_dir = params.get("output_dir", "./web_output")
        dataset_format = params.get("dataset_format", "auto")

        info = get_system_info()
        _log_queue.put(f"[web] GPU: {info.get('gpu_name', 'N/A')} | VRAM: {info.get('gpu_memory_gb', 0)}GB\n")

        # Warn if GPU training requested but torch is CPU-only
        if not cpu and not torch.cuda.is_available():
            _log_queue.put("\n[web] WARNING: GPU training requested but CUDA is not available!\n")
            _log_queue.put("[web] PyTorch is CPU-only. To fix:\n")
            _log_queue.put("[web]   1. Close this server (Ctrl+C)\n")
            _log_queue.put("[web]   2. Run: pip install torch==2.11.0+cu128 --force-reinstall --no-deps --extra-index-url https://download.pytorch.org/whl/cu128\n")
            _log_queue.put("[web]   3. Reinstall amazingvmsloth: pip install --no-deps --force-reinstall amazingvmsloth[web]==0.3.1\n")
            _log_queue.put("[web]   4. Relaunch: amazingvmsloth web\n")
            _log_queue.put("[web] Forcing CPU mode. Training will be very slow.\n\n")
            cpu = True

        # Task routing
        task = params.get("task", "text-generation")
        if task in ("text-to-speech", "tts"):
            _log_queue.put(f"[web] Task: {task} — TTS training not yet supported in web UI. Use CLI: amazingvmsloth train --task {task} ...\n")
            _update_status(state="error", message="TTS training requires CLI")
            return
        elif task in ("text-to-image", "image-generation", "text-to-video", "video-generation"):
            _log_queue.put(f"[web] Task: {task} — Diffusion training not yet supported in web UI. Use CLI: amazingvmsloth train --task {task} ...\n")
            _update_status(state="error", message="Diffusion training requires CLI")
            return

        tokenizer = AutoTokenizer.from_pretrained(model_name)
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token

        _update_status(state="loading", message="Loading model weights...")
        if cpu:
            from transformers import AutoModelForCausalLM
            _log_queue.put("[web] CPU mode selected — loading model on CPU\n")
            dtype = torch.bfloat16 if bf16 else torch.float32
            try:
                model = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype=dtype, device_map="cpu", low_cpu_mem_usage=True)
            except Exception:
                _log_queue.put("[web] bf16 load failed on CPU, falling back to fp32\n")
                model = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype=torch.float32, device_map="cpu", low_cpu_mem_usage=True)
        elif quant == "4bit":
            model = quantize_model_4bit(model_name)
        else:
            from transformers import AutoModelForCausalLM
            model = AutoModelForCausalLM.from_pretrained(
                model_name,
                torch_dtype=torch.bfloat16 if bf16 else torch.float32,
                device_map="auto",
            )

        lora_config = LoRAConfig(r=lora_r, lora_alpha=lora_alpha)
        model = auto_patch_model(model, apply_lora_patch=True, lora_config=lora_config)

        _update_status(state="loading", message="Loading dataset...")
        try:
            ds = load_dataset(dataset_name, split="train")
        except Exception as e:
            _log_queue.put(f"[web] Dataset loading failed: {e}, trying streaming...\n")
            ds = load_dataset(dataset_name, split="train", streaming=True)
            ds = ds.to_list()
            from datasets import Dataset
            ds = Dataset.from_list(ds)

        max_samples = int(params.get("max_samples", 0))
        if max_samples > 0 and len(ds) > max_samples:
            ds = ds.select(range(max_samples))

        # Format dataset
        if dataset_format == "auto":
            if "messages" in ds.column_names:
                dataset_format = "chat"
            elif "instruction" in ds.column_names and "output" in ds.column_names:
                dataset_format = "alpaca"
            else:
                dataset_format = "text"

        if dataset_format == "chat":
            has_template = hasattr(tokenizer, "apply_chat_template") and tokenizer.chat_template is not None
            def fmt(examples):
                sanitized = []
                for msgs in examples["messages"]:
                    if not isinstance(msgs, list):
                        msgs = [msgs] if msgs is not None else []
                    clean = []
                    for msg in msgs:
                        if msg is None:
                            continue
                        if isinstance(msg, dict):
                            cm = {}
                            for k, v in msg.items():
                                cm[k] = "" if v is None else (v if isinstance(v, str) else str(v))
                            clean.append(cm)
                        elif isinstance(msg, str):
                            clean.append({"role": "user", "content": msg})
                    sanitized.append(clean)
                if has_template:
                    texts = [tokenizer.apply_chat_template(m, tokenize=False, add_generation_prompt=False) for m in sanitized]
                else:
                    texts = []
                    for msgs in sanitized:
                        parts = [f"<{m.get('role','user')}>\n{m.get('content','')}" for m in msgs]
                        texts.append("\n".join(parts) + "\n<assistant>\n")
                return tokenizer(texts, truncation=True, max_length=max_seq_length)
            tokenized = ds.map(fmt, batched=True, remove_columns=ds.column_names)
        elif dataset_format == "alpaca":
            inst_col = "instruction" if "instruction" in ds.column_names else "prompt"
            out_col = None
            for c in ["output", "response", "answer"]:
                if c in ds.column_names:
                    out_col = c
                    break
            def fmt(examples):
                texts = []
                for i in range(len(examples[inst_col])):
                    inst = examples[inst_col][i]
                    out = examples[out_col][i] if out_col else ""
                    texts.append(f"### Instruction:\n{inst}\n\n### Response:\n{out}")
                return tokenizer(texts, truncation=True, max_length=max_seq_length)
            tokenized = ds.map(fmt, batched=True, remove_columns=ds.column_names)
        else:
            text_col = None
            for c in ["text", "input", "content", "prompt"]:
                if c in ds.column_names:
                    text_col = c
                    break
            if text_col is None:
                text_col = ds.column_names[0]
            tokenized = ds.map(lambda ex: tokenizer(ex[text_col], truncation=True, max_length=max_seq_length), batched=True, remove_columns=ds.column_names)

        tokenized = tokenized.map(lambda x: {"labels": x["input_ids"]}, batched=True)

        if cpu:
            from amazingvmsloth.cpu_trainer import CpuTrainingConfig, CpuTrainer
            config = CpuTrainingConfig(
                output_dir=output_dir,
                num_train_epochs=1,
                per_device_train_batch_size=batch_size,
                gradient_accumulation_steps=grad_accum,
                learning_rate=lr,
                optim=optimizer,
                max_seq_length=max_seq_length,
                max_steps=max_steps,
                compile_model=False,
                packing=False,
                silent=True,
            )
            trainer = CpuTrainer(model=model, tokenizer=tokenizer, train_dataset=tokenized, config=config)
        else:
            config = TrainingConfig(
                output_dir=output_dir,
                num_train_epochs=1,
                per_device_train_batch_size=batch_size,
                gradient_accumulation_steps=grad_accum,
                learning_rate=lr,
                bf16=bf16,
                optim=optimizer,
                max_seq_length=max_seq_length,
                max_steps=max_steps,
                compile_model=False,
                packing=False,
                silent=True,
            )
            trainer = AmazingTrainer(model=model, tokenizer=tokenizer, train_dataset=tokenized, config=config)

        _update_status(state="training", step=0, total_steps=max_steps, loss=0.0, vram=0.0, start_time=time.time(), elapsed=0, history=[])
        _log_queue.put("[web] Training started!\n")

        with _LogCapture(_log_queue):
            result = trainer.train()

        _update_status(state="done", message=f"Training complete! Loss: {result.get('final_loss', 0):.4f}")
        _log_queue.put(f"[web] Training complete! Result: {json.dumps({k:v for k,v in result.items() if k!='log_history'}, default=str)}\n")

    except Exception as e:
        _update_status(state="error", message=str(e))
        _log_queue.put(f"[web] ERROR: {type(e).__name__}: {e}\n")
        import traceback
        _log_queue.put(traceback.format_exc())


def create_app() -> Any:
    if not _flask_available:
        raise ImportError("Flask is required for the web dashboard. Install: pip install flask")

    app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), "static"))

    @app.route("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    @app.route("/api/status")
    def api_status():
        d = dict(_status)
        if d.get("start_time"):
            d["elapsed"] = round(time.time() - d["start_time"], 1)
        return jsonify(d)

    @app.route("/api/start", methods=["POST"])
    def api_start():
        global _training_thread, _stop_event
        if _training_thread and _training_thread.is_alive():
            return jsonify({"error": "Training already running"}), 409

        _stop_event.clear()
        _log_queue.queue.clear()
        _status.update({"state": "starting", "step": 0, "total_steps": 0, "loss": 0.0, "vram": 0.0, "history": [], "message": "Initializing..."})

        params = request.get_json(force=True) if request.is_json else request.form.to_dict()
        _training_thread = threading.Thread(target=_run_training, args=(params,), daemon=True)
        _training_thread.start()
        return jsonify({"status": "started"})

    @app.route("/api/stop", methods=["POST"])
    def api_stop():
        _stop_event.set()
        _update_status(state="stopping", message="Stop requested...")
        return jsonify({"status": "stopping"})

    @app.route("/api/logs")
    def api_logs():
        def generate():
            last_id = 0
            while True:
                try:
                    line = _log_queue.get(timeout=1)
                    last_id += 1
                    # Parse metrics from line
                    metrics = _parse_log_line(line)
                    if metrics:
                        _status.update(metrics)
                        h = _status.get("history", [])
                        h.append({"step": metrics.get("step", 0), "loss": metrics.get("loss", 0), "vram": metrics.get("vram", 0)})
                        _status["history"] = h[-500:]  # keep last 500 points
                    data = json.dumps({"id": last_id, "line": line, "status": _status})
                    yield f"data: {data}\n\n"
                except queue.Empty:
                    # Send heartbeat to keep connection alive
                    data = json.dumps({"id": last_id, "line": "", "status": _status})
                    yield f"data: {data}\n\n"
                    if _status.get("state") in ("done", "error", "idle"):
                        break
        return Response(generate(), mimetype="text/event-stream")

    return app


def run_server(host: str = "127.0.0.1", port: int = 7860):
    if not _flask_available:
        print("[amazingvmsloth] Flask not installed. Run: pip install flask")
        sys.exit(1)
    app = create_app()
    print(f"[amazingvmsloth] Web dashboard running at http://{host}:{port}")
    print("[amazingvmsloth] Press Ctrl+C to stop")
    app.run(host=host, port=port, threaded=True, debug=False)
