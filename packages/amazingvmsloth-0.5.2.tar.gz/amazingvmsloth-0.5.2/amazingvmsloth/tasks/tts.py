"""
Text-to-Speech (TTS) trainer for transformer-based TTS models.

Supports:
  - Qwen3-TTS (Qwen3TTSForConditionalGeneration)
  - Bark (SunoBarkModel)
  - ParlerTTS (ParlerTTSForConditionalGeneration)
  - Any transformers TTS model with ForConditionalGeneration or auto-regressive audio decoder

Training data: text transcripts paired with audio files (wav, mp3, flac).
The model learns to generate audio codec tokens from text input.
"""
import os
import json
import time
import math
from typing import Optional, Dict, Any, List, Tuple, Union
from dataclasses import dataclass
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

from transformers import PreTrainedTokenizer, PreTrainedModel


try:
    from datasets import Dataset as HFDataset
    _DATASETS_AVAILABLE = True
except ImportError:
    _DATASETS_AVAILABLE = False


@dataclass
class TTSConfig:
    """Configuration for TTS training."""
    output_dir: str = "./tts_output"
    num_train_epochs: int = 3
    per_device_train_batch_size: int = 1
    gradient_accumulation_steps: int = 4
    learning_rate: float = 2e-4
    max_seq_length: int = 512  # text token length
    max_audio_length: int = 4096  # audio codec token length
    max_steps: int = 0
    bf16: bool = True
    fp16: bool = False
    optim: str = "adamw"
    max_grad_norm: float = 1.0
    logging_steps: int = 10
    save_steps: int = 0
    seed: int = 42
    compile_model: bool = False
    silent: bool = False
    # TTS-specific
    transcript_column: str = "text"  # column with text transcript
    audio_column: str = "audio"  # column with audio path or bytes
    sample_rate: int = 24000  # target sample rate
    max_audio_seconds: float = 30.0  # max audio duration in seconds


class LocalAudioDataset(Dataset):
    """Dataset for local audio files with transcripts.

    Supports:
      - Single audio file + transcript
      - Folder of audio files + metadata.json/csv
      - HF dataset with audio column
    """

    def __init__(
        self,
        data_source: Union[str, List[Dict[str, Any]]],
        tokenizer: PreTrainedTokenizer,
        transcript_column: str = "text",
        audio_column: str = "audio",
        max_audio_seconds: float = 30.0,
    ):
        self.tokenizer = tokenizer
        self.transcript_column = transcript_column
        self.audio_column = audio_column
        self.max_audio_seconds = max_audio_seconds
        self.samples = []

        if isinstance(data_source, str):
            if os.path.isfile(data_source):
                # Single file - need a transcript
                ext = Path(data_source).suffix.lower()
                if ext in ('.wav', '.mp3', '.flac', '.ogg', '.m4a', '.aac'):
                    # Single audio file
                    self.samples.append(self._make_sample(data_source))
                elif ext in ('.json', '.jsonl'):
                    self._load_json(data_source)
                elif ext == '.csv':
                    self._load_csv(data_source)
                else:
                    raise ValueError(f"Unsupported file type: {ext}")
            elif os.path.isdir(data_source):
                # Folder of audio files
                self._load_folder(data_source)
            else:
                raise FileNotFoundError(f"Path not found: {data_source}")
        elif isinstance(data_source, list):
            self.samples = data_source
        elif _DATASETS_AVAILABLE and isinstance(data_source, HFDataset):
            self._load_hf_dataset(data_source)
        else:
            raise TypeError(f"Unsupported data_source type: {type(data_source)}")

    def _make_sample(self, audio_path: str, transcript: Optional[str] = None) -> Dict[str, Any]:
        """Create a sample dict from audio path."""
        if transcript is None:
            # Use filename without extension as transcript
            transcript = Path(audio_path).stem.replace("_", " ").replace("-", " ")
        return {
            self.transcript_column: transcript,
            self.audio_column: audio_path,
        }

    def _load_json(self, path: str):
        with open(path, 'r', encoding='utf-8') as f:
            if path.endswith('.jsonl'):
                self.samples = [json.loads(line) for line in f if line.strip()]
            else:
                data = json.load(f)
                if isinstance(data, list):
                    self.samples = data
                elif isinstance(data, dict) and 'data' in data:
                    self.samples = data['data']
                else:
                    # Single sample
                    self.samples = [data]

    def _load_csv(self, path: str):
        import csv
        with open(path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            self.samples = list(reader)

    def _load_folder(self, folder: str):
        """Load all audio files from a folder.
        Look for metadata.json, metadata.csvl, or use filenames as transcripts."""
        # Check for metadata files
        meta_json = os.path.join(folder, "metadata.json")
        meta_jsonl = os.path.join(folder, "metadata.jsonl")
        meta_csv = os.path.join(folder, "metadata.csv")

        if os.path.exists(meta_jsonl):
            self._load_json(meta_jsonl)
            return
        elif os.path.exists(meta_json):
            self._load_json(meta_json)
            return
        elif os.path.exists(meta_csv):
            self._load_csv(meta_csv)
            return

        # No metadata - use filenames as transcripts
        audio_exts = ('.wav', '.mp3', '.flac', '.ogg', '.m4a', '.aac')
        files = [f for f in os.listdir(folder) if f.lower().endswith(audio_exts)]
        files.sort()
        for f in files:
            path = os.path.join(folder, f)
            transcript = Path(f).stem.replace("_", " ").replace("-", " ")
            self.samples.append(self._make_sample(path, transcript))

    def _load_hf_dataset(self, dataset):
        """Load from a HuggingFace datasets Dataset object."""
        self.samples = []
        for i in range(len(dataset)):
            item = dataset[i]
            self.samples.append(dict(item))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        return self.samples[idx]


class TTSTrainer:
    """Trainer for transformer-based TTS models.

    Handles models like Qwen3-TTS, Bark, ParlerTTS that generate
    discrete audio tokens (codec tokens) from text input.

    Training loop:
      1. Tokenize text → input_ids
      2. Load audio → raw waveform or pre-encoded codec tokens
      3. Forward: model(text) → predicted audio tokens
      4. Loss: cross-entropy(predicted, target_audio_tokens)
      5. Backward + optimizer step
    """

    def __init__(
        self,
        model: PreTrainedModel,
        tokenizer: PreTrainedTokenizer,
        train_dataset: Dataset,
        config: Optional[TTSConfig] = None,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.train_dataset = train_dataset
        self.config = config or TTSConfig()
        self._global_step = 0
        self._log_history: List[Dict[str, Any]] = []

    def _setup(self):
        self._setup_seed()
        self._setup_device()
        self._setup_optimizer()
        self._setup_dataloader()

    def _setup_seed(self):
        torch.manual_seed(self.config.seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(self.config.seed)

    def _setup_device(self):
        if torch.cuda.is_available():
            self.device = torch.device("cuda:0")
            self.model = self.model.to(self.device)
        else:
            self.device = torch.device("cpu")

    def _setup_optimizer(self):
        trainable = [p for p in self.model.parameters() if p.requires_grad]
        if self.config.optim.lower() == "adamw":
            from torch.optim import AdamW
            self.optimizer = AdamW(trainable, lr=self.config.learning_rate)
        elif "8bit" in self.config.optim.lower():
            try:
                import bitsandbytes as bnb
                self.optimizer = bnb.optim.Adam8bit(trainable, lr=self.config.learning_rate)
            except ImportError:
                from torch.optim import AdamW
                self.optimizer = AdamW(trainable, lr=self.config.learning_rate)
        else:
            from torch.optim import AdamW
            self.optimizer = AdamW(trainable, lr=self.config.learning_rate)

    def _setup_dataloader(self):
        self.dataloader = DataLoader(
            self.train_dataset,
            batch_size=self.config.per_device_train_batch_size,
            shuffle=True,
            collate_fn=self._collate_fn,
            num_workers=0,  # Windows safe
        )

    def _collate_fn(self, batch: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        """Collate a batch of TTS samples."""
        texts = [item[self.config.transcript_column] for item in batch]
        audio_paths = [item[self.config.audio_column] for item in batch]

        # Tokenize text
        text_inputs = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=self.config.max_seq_length,
            return_tensors="pt",
        )

        result = {
            "input_ids": text_inputs["input_ids"],
            "attention_mask": text_inputs["attention_mask"],
            "audio_paths": audio_paths,
        }

        # Try to load audio and encode to tokens if the model supports it
        # This is model-specific; we'll try common patterns
        audio_tokens = self._encode_audio_batch(audio_paths)
        if audio_tokens is not None:
            result["labels"] = audio_tokens

        return result

    def _encode_audio_batch(self, audio_paths: List[str]) -> Optional[torch.Tensor]:
        """Try to encode audio files to target tokens for the model.

        Different TTS models use different audio representations:
          - Qwen3-TTS: uses internal codec, may auto-encode in forward()
          - Bark: uses EnCodec tokens
          - ParlerTTS: uses DAC tokens

        If the model has an audio encoder, we use it. Otherwise the model
        may handle raw audio in its forward() pass.
        """
        # Check if model has an audio encoder / codec
        if hasattr(self.model, "encode_audio"):
            try:
                tokens = self.model.encode_audio(audio_paths)
                return tokens
            except Exception:
                pass

        if hasattr(self.model, "audio_encoder"):
            try:
                # Load raw audio
                waveforms = self._load_waveforms(audio_paths)
                tokens = self.model.audio_encoder(waveforms)
                return tokens
            except Exception:
                pass

        # For models that handle audio internally (e.g., Qwen3-TTS with audio_paths in forward)
        # Return None and let the model's forward() handle it
        return None

    def _load_waveforms(self, audio_paths: List[str]) -> torch.Tensor:
        """Load audio files to waveform tensors."""
        import torchaudio
        waveforms = []
        max_len = int(self.config.sample_rate * self.config.max_audio_seconds)
        for path in audio_paths:
            try:
                wf, sr = torchaudio.load(path)
                # Resample if needed
                if sr != self.config.sample_rate:
                    wf = torchaudio.functional.resample(wf, sr, self.config.sample_rate)
                # Convert to mono
                if wf.shape[0] > 1:
                    wf = wf.mean(dim=0, keepdim=True)
                # Pad or truncate
                if wf.shape[1] > max_len:
                    wf = wf[:, :max_len]
                elif wf.shape[1] < max_len:
                    wf = torch.nn.functional.pad(wf, (0, max_len - wf.shape[1]))
                waveforms.append(wf.squeeze(0))
            except Exception as e:
                print(f"[tts] Warning: failed to load audio {path}: {e}")
                # Return silence
                waveforms.append(torch.zeros(max_len))
        return torch.stack(waveforms)

    def _detect_forward_mode(self) -> str:
        """Auto-detect how the model's forward() should be called for training."""
        # Try different signatures
        test_input = torch.zeros(1, 4, dtype=torch.long, device=self.device)

        # Mode 1: standard seq2seq (input_ids + labels)
        try:
            with torch.no_grad():
                out = self.model(input_ids=test_input, labels=test_input)
                if hasattr(out, "loss"):
                    return "seq2seq"
        except Exception:
            pass

        # Mode 2: requires audio input (input_ids + audio_input)
        try:
            with torch.no_grad():
                dummy_audio = torch.zeros(1, 1, self.config.sample_rate, device=self.device)
                out = self.model(input_ids=test_input, audio_input=dummy_audio)
                if hasattr(out, "loss"):
                    return "audio_input"
        except Exception:
            pass

        # Mode 3: requires audio_tokens (input_ids + audio_tokens)
        try:
            with torch.no_grad():
                dummy_tokens = torch.zeros(1, 100, dtype=torch.long, device=self.device)
                out = self.model(input_ids=test_input, audio_tokens=dummy_tokens)
                if hasattr(out, "loss"):
                    return "audio_tokens"
        except Exception:
            pass

        # Mode 4: requires audio_paths or raw audio in forward
        try:
            with torch.no_grad():
                out = self.model(input_ids=test_input, audio=test_input)
                if hasattr(out, "loss"):
                    return "audio_key"
        except Exception:
            pass

        # Default: assume seq2seq with labels
        return "seq2seq"

    def train(self) -> Dict[str, Any]:
        self._setup()

        # Auto-detect forward mode
        forward_mode = self._detect_forward_mode()
        print(f"[tts] Detected forward mode: {forward_mode}")

        if not self.config.silent:
            print(f"\n{'='*60}")
            print(f"  amazingvmsloth TTS Training")
            print(f"{'='*60}")
            print(f"  Forward mode: {forward_mode}")
            print(f"  Epochs:       {self.config.num_train_epochs}")
            print(f"  Batch size:   {self.config.per_device_train_batch_size}")
            print(f"  Grad accum:   {self.config.gradient_accumulation_steps}")
            print(f"  LR:           {self.config.learning_rate}")
            print(f"  Max text:     {self.config.max_seq_length}")
            print(f"  Max audio:    {self.config.max_audio_length}")
            print(f"{'='*60}\n")

        from tqdm import tqdm

        total_epochs = self.config.num_train_epochs
        total_steps_estimated = len(self.dataloader) * total_epochs // self.config.gradient_accumulation_steps
        pbar = tqdm(total=total_steps_estimated, desc="TTS Training", unit="step")

        self.model.train()
        epoch_loss = 0.0
        step_count = 0
        data_step = 0
        n_batches = len(self.dataloader)
        start_time = time.time()

        for epoch in range(total_epochs):
            for batch in self.dataloader:
                data_step += 1

                # Move to device
                input_ids = batch["input_ids"].to(self.device)
                attention_mask = batch.get("attention_mask")
                if attention_mask is not None:
                    attention_mask = attention_mask.to(self.device)

                # Build forward kwargs based on detected mode
                kwargs = {"input_ids": input_ids}
                if attention_mask is not None:
                    kwargs["attention_mask"] = attention_mask

                if forward_mode == "audio_input":
                    # Model expects raw audio waveform
                    audio_paths = batch["audio_paths"]
                    audio_wave = self._load_waveforms(audio_paths).to(self.device)
                    kwargs["audio_input"] = audio_wave.unsqueeze(1)  # (B, 1, T)
                elif forward_mode == "audio_tokens":
                    # Model expects pre-encoded audio tokens
                    if "labels" in batch:
                        kwargs["audio_tokens"] = batch["labels"].to(self.device)
                        kwargs["labels"] = batch["labels"].to(self.device)
                elif forward_mode == "seq2seq":
                    if "labels" in batch:
                        kwargs["labels"] = batch["labels"].to(self.device)

                # Forward pass
                with torch.autocast(device_type=self.device.type, dtype=torch.bfloat16 if self.config.bf16 else torch.float32, enabled=self.config.bf16 or self.config.fp16):
                    outputs = self.model(**kwargs)

                # Extract loss
                if hasattr(outputs, "loss") and outputs.loss is not None:
                    loss = outputs.loss
                elif hasattr(outputs, "logits"):
                    # Compute cross-entropy manually
                    logits = outputs.logits
                    labels = kwargs.get("labels")
                    if labels is not None:
                        loss = F.cross_entropy(
                            logits.view(-1, logits.size(-1)),
                            labels.view(-1),
                            ignore_index=-100,
                        )
                    else:
                        raise ValueError("Model returned logits but no labels were provided. Cannot compute loss.")
                else:
                    raise ValueError(f"Model output has no 'loss' or 'logits': {type(outputs)}")

                # Scale for gradient accumulation
                loss = loss / self.config.gradient_accumulation_steps
                loss.backward()

                epoch_loss += loss.item() * self.config.gradient_accumulation_steps

                if data_step % self.config.gradient_accumulation_steps == 0 or data_step == n_batches:
                    if self.config.max_grad_norm > 0:
                        nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)

                    self.optimizer.step()
                    self.optimizer.zero_grad(set_to_none=True)

                    self._global_step += 1
                    step_count += 1
                    pbar.update(1)

                    avg_loss = epoch_loss / step_count
                    pbar.set_postfix({"loss": f"{avg_loss:.4f}"})

                    # Logging
                    if self._global_step % self.config.logging_steps == 0:
                        elapsed = time.time() - start_time
                        steps_per_sec = self._global_step / elapsed if elapsed > 0 else 0
                        print(
                            f"Epoch [{epoch+1}/{total_epochs}] "
                            f"Step [{self._global_step}] "
                            f"Loss: {avg_loss:.4f} | "
                            f"Speed: {steps_per_sec:.2f} steps/s"
                        )

                    # Early stop
                    if self.config.max_steps > 0 and self._global_step >= self.config.max_steps:
                        print(f"\n[tts] Max steps reached ({self.config.max_steps}). Stopping.")
                        pbar.close()
                        return self._build_result(start_time)

        pbar.close()
        return self._build_result(start_time)

    def _build_result(self, start_time: float) -> Dict[str, Any]:
        total_time = time.time() - start_time
        final_loss = self._log_history[-1]["loss"] if self._log_history else 0.0
        return {
            "final_loss": final_loss,
            "total_time": total_time,
            "global_step": self._global_step,
            "log_history": self._log_history,
        }
