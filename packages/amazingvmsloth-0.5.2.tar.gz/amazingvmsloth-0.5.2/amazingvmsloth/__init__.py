import os
import sys

# Suppress transformers loading progress bars that can crash on Windows terminal
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")

# Runtime torch check: warn user if CPU-only torch is installed but GPU is available
try:
    import torch
    _torch_version = torch.__version__
    _cuda_available = torch.cuda.is_available()
    if not _cuda_available and _torch_version.endswith("+cpu"):
        import warnings
        warnings.warn(
            "CPU-only PyTorch detected (torch==" + _torch_version + "). "
            "If you have an NVIDIA GPU, reinstall torch with CUDA:\n"
            "  pip install torch --index-url https://download.pytorch.org/whl/cu128\n"
            "Then install amazingvmsloth with --no-deps to avoid pip overwriting it.",
            RuntimeWarning,
            stacklevel=2,
        )
except ImportError:
    raise ImportError(
        "torch is required but not installed.\n"
        "Install torch with CUDA first (replace cu128 with your CUDA version):\n"
        "  pip install torch --index-url https://download.pytorch.org/whl/cu128\n"
        "Then install amazingvmsloth: pip install --no-deps amazingvmsloth[web]"
    )

from amazingvmsloth.lora import apply_lora, LoRAConfig
from amazingvmsloth.trainer import AmazingTrainer, TrainingConfig
from amazingvmsloth.quantization import quantize_model_4bit
from amazingvmsloth.attention import patch_attention
from amazingvmsloth.models import auto_patch_model
from amazingvmsloth.multi_gpu import setup_distributed
from amazingvmsloth.offload import apply_dispatch_offload, estimate_model_size_gb
from amazingvmsloth.cpu_trainer import CpuTrainer, CpuTrainingConfig

__version__ = "0.5.2"
__all__ = [
    "apply_lora",
    "LoRAConfig",
    "AmazingTrainer",
    "TrainingConfig",
    "quantize_model_4bit",
    "patch_attention",
    "auto_patch_model",
    "setup_distributed",
]
