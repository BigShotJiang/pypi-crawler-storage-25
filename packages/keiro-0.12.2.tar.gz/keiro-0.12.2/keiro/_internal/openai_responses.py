"""Payload-merge helpers for the OpenAI Responses API.

Vendored copy of ``ember.models.providers.openai._responses._merge_payload_instructions``.
"""

from __future__ import annotations

from keiro._internal.errors import ProviderAPIError


def merge_payload_instructions(
    payload: dict[str, object],
    instructions: object | None,
    *,
    model: str,
    source: str,
) -> None:
    """Merge a single instructions source into a payload, failing on conflicts.

    Args:
        payload: Responses API payload under construction.
        instructions: Instructions string to merge, or ``None`` to skip.
        model: Canonical model id, included in the error context.
        source: Human-readable label identifying where ``instructions``
            came from (used in the error context).

    Raises:
        ProviderAPIError: If ``payload`` already carries a different
            ``instructions`` string.
    """
    if instructions is None:
        return
    existing = payload.get("instructions")
    if existing is None:
        payload["instructions"] = instructions
        return
    if existing != instructions:
        raise ProviderAPIError(
            "Cannot combine conflicting instructions sources in an OpenAI Responses payload",
            context={
                "model": model,
                "parameter": "instructions",
                "source": source,
            },
        )
