"""Vendored helpers for the keiro client wheel.

Self-contained copies of small utilities that previously lived in the
ember monorepo. Ember is not a PyPI dependency of keiro, so these
helpers are inlined here to keep the client wheel importable in any
environment.
"""
