"""Minimal provider error used by the vendored OpenAI payload helpers.

Simplified copy of ``ember._internal.exceptions.ProviderAPIError``. The
vendored helpers only need a distinct exception class they can raise
and that callers can catch; they do not use the full EmberError
context/recovery infrastructure.
"""

from __future__ import annotations

from typing import Any


class ProviderAPIError(Exception):
    """Raised when a provider payload cannot be constructed.

    Mirrors the surface area used by the vendored OpenAI helpers: a
    message and an optional ``context`` dict for structured debugging.
    """

    def __init__(
        self,
        message: str = "",
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.context = context or {}
