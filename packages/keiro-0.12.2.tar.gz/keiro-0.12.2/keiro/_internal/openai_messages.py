"""Chat Completions -> Responses API message conversion.

Vendored copy of the narrow slice of
``ember.models.providers.openai._messages`` that keiro's ``model_api``
needs at runtime. Specifically: ``as_responses_request_parts`` plus
its transitive helpers.

Not vendored: ``_clone``, ``normalize_context``, ``build_messages``,
which are only used by ember's own provider layer.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence

MessageDict = Mapping[str, object]
MessageList = Sequence[MessageDict]


def as_responses_request_parts(
    messages: MessageList,
) -> tuple[list[dict[str, object]], str | None]:
    """Convert chat-style messages to Responses API input plus instructions.

    ``as_responses_turns`` intentionally omits ``role="system"`` entries
    because the OpenAI Responses API rejects them in ``input``. Higher
    level callers performing a full Chat Completions to Responses
    conversion must also preserve those system prompts as
    ``instructions``.
    """
    return as_responses_turns(messages), _extract_system_instructions(messages)


def as_responses_turns(messages: MessageList) -> list[dict[str, object]]:
    """Convert messages to Responses API input format.

    The Responses API uses a flat list of input items where function_call
    and function_call_output are top-level items (not nested in message
    content).

    Input items can be:
        {"type": "message", "role": "...", "content": [...]}
        {"type": "function_call", "call_id": "...", "name": "...", "arguments": "..."}
        {"type": "function_call_output", "call_id": "...", "output": "..."}
    """
    items: list[dict[str, object]] = []

    for message in messages:
        role = str(message["role"])
        content = message.get("content", "")

        if role == "system":
            continue

        if role == "tool":
            tool_call_id = message.get("tool_call_id", "")
            content_val = message.get("content")
            if isinstance(content_val, list):
                emitted = False
                for part in content_val:
                    if isinstance(part, dict) and part.get("type") == "function_call_output":
                        items.append(
                            {
                                "type": "function_call_output",
                                "call_id": (part.get("call_id") or str(tool_call_id) or ""),
                                "output": str(part.get("output", "")),
                            }
                        )
                        emitted = True
                if emitted:
                    continue
            items.append(
                {
                    "type": "function_call_output",
                    "call_id": str(tool_call_id),
                    "output": _stringify_tool_message_content(content_val),
                }
            )
            continue

        if role == "assistant":
            tool_calls = message.get("tool_calls")
            content_val = message.get("content")

            if isinstance(content_val, list) and not tool_calls:
                text_parts: list[str] = []
                for part in content_val:
                    if not isinstance(part, dict):
                        continue
                    part_type = part.get("type", "")
                    if part_type == "function_call":
                        items.append(
                            {
                                "type": "function_call",
                                "call_id": (part.get("call_id") or part.get("id", "")),
                                "name": part.get("name", ""),
                                "arguments": part.get("arguments", "{}"),
                            }
                        )
                    elif part_type in ("output_text", "input_text", "text"):
                        text_parts.append(str(part.get("text", "")))
                if text_parts:
                    items.append(
                        {
                            "type": "message",
                            "role": "assistant",
                            "content": [{"type": "output_text", "text": t} for t in text_parts],
                        }
                    )
                continue

            if content:
                items.append(
                    {
                        "type": "message",
                        "role": "assistant",
                        "content": [
                            {"type": "output_text", "text": str(content)},
                        ],
                    }
                )

            if tool_calls:
                for tc in tool_calls:
                    if isinstance(tc, dict):
                        func = tc.get("function", {})
                        items.append(
                            {
                                "type": "function_call",
                                "call_id": tc.get("id", ""),
                                "name": (func.get("name", "") if isinstance(func, dict) else ""),
                                "arguments": (
                                    func.get("arguments", "{}") if isinstance(func, dict) else "{}"
                                ),
                            }
                        )
                    else:
                        func = getattr(tc, "function", None)
                        items.append(
                            {
                                "type": "function_call",
                                "call_id": getattr(tc, "id", ""),
                                "name": getattr(func, "name", "") if func else "",
                                "arguments": (getattr(func, "arguments", "{}") if func else "{}"),
                            }
                        )
            continue

        content_type = "output_text" if role == "assistant" else "input_text"
        items.append(
            {
                "type": "message",
                "role": role,
                "content": _coerce_responses_content(content, content_type),
            }
        )

    return items


def _extract_system_instructions(messages: MessageList) -> str | None:
    """Collect system-role message text for the Responses ``instructions`` field."""
    parts: list[str] = []
    for message in messages:
        role = str(message["role"])
        if role != "system":
            continue
        parts.extend(_extract_instruction_parts(message.get("content")))
    return "\n\n".join(parts) if parts else None


def _extract_instruction_parts(content: object) -> list[str]:
    if isinstance(content, str):
        return [content] if content else []
    if isinstance(content, bytes):
        text = content.decode("utf-8", errors="ignore")
        return [text] if text else []
    if isinstance(content, Mapping):
        text = content.get("text")
        if isinstance(text, str):
            return [text] if text else []
        if isinstance(text, bytes):
            decoded = text.decode("utf-8", errors="ignore")
            return [decoded] if decoded else []
        return []
    if isinstance(content, Sequence) and not isinstance(content, (str, bytes, bytearray)):
        parts: list[str] = []
        for part in content:
            parts.extend(_extract_instruction_parts(part))
        return parts
    return []


def _coerce_responses_content(
    content: object, content_type: str = "input_text"
) -> list[dict[str, object]]:
    if isinstance(content, str):
        return [{"type": content_type, "text": content}]
    if isinstance(content, bytes):
        return [{"type": content_type, "text": content.decode("utf-8", errors="ignore")}]
    if isinstance(content, Mapping):
        return [_coerce_responses_part(content, content_type)]
    if isinstance(content, Sequence):
        parts: list[dict[str, object]] = []
        for part in content:
            if isinstance(part, Mapping):
                parts.append(_coerce_responses_part(part, content_type))
            elif isinstance(part, str):
                parts.append({"type": content_type, "text": part})
            elif isinstance(part, bytes):
                parts.append(
                    {
                        "type": content_type,
                        "text": part.decode("utf-8", errors="ignore"),
                    }
                )
            else:
                parts.append({"type": content_type, "text": str(part)})
        return parts
    if content is None:
        return [{"type": content_type, "text": ""}]
    return [{"type": content_type, "text": str(content)}]


def _coerce_responses_part(
    part: Mapping[str, object], default_type: str = "input_text"
) -> dict[str, object]:
    """Coerce a content part to use the role-appropriate text type.

    OpenAI Responses API requires ``output_text`` for assistant messages
    and ``input_text`` for user/system/developer messages. When content
    parts carry the wrong text type (e.g., ``input_text`` on an assistant
    message from Chat Completions conversion), remap to the correct type.
    """
    converted: dict[str, object] = dict(part)
    part_type = str(converted.get("type") or default_type)
    if part_type == "text":
        part_type = default_type
    if part_type == "input_text" and default_type == "output_text":
        part_type = "output_text"
    elif part_type == "output_text" and default_type == "input_text":
        part_type = "input_text"
    converted["type"] = part_type
    return converted


def _stringify_tool_message_content(value: object) -> str:
    """Serialize tool message content for function_call_output (Chat Completions)."""
    if isinstance(value, str):
        return value
    if value is None:
        return ""
    try:
        return json.dumps(value, ensure_ascii=False)
    except TypeError:
        return str(value)


__all__ = [
    "MessageDict",
    "MessageList",
    "as_responses_request_parts",
    "as_responses_turns",
]
