"""Allow ``python -m keiro.cli`` invocation."""

from keiro.cli import cli_entry

cli_entry()
