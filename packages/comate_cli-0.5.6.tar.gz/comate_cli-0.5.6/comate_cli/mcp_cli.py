from __future__ import annotations

import argparse
import asyncio
import sys
from typing import Any

from comate_agent_sdk.mcp import (
    McpConfigError,
    collect_mcp_server_health,
    load_effective_servers,
    load_scope_servers,
    scope_mcp_path,
    write_mcp_servers_to_path,
)
from comate_agent_sdk.mcp.types import McpServerConfig
from comate_agent_sdk.utils.paths import PathInput

from comate_cli.terminal_agent.figures import (
    CHECK_MARK,
    CROSS_MARK,
    ELLIPSIS,
)


class McpCliError(ValueError):
    def __init__(self, message: str, *, exit_code: int = 2) -> None:
        super().__init__(message)
        self.exit_code = int(exit_code)


class _McpArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise McpCliError(message)


def _build_parser() -> argparse.ArgumentParser:
    parser = _McpArgumentParser(
        prog="comate mcp",
        description="Configure and manage MCP servers",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  # Add HTTP server:\n"
            "  comate mcp add --transport http sentry https://mcp.sentry.dev/mcp\n\n"
            "  # Add HTTP server with headers:\n"
            "  comate mcp add --transport http corridor https://app.corridor.dev/api/mcp "
            '--header "Authorization: Bearer ..."\n\n'
            "  # Add stdio server with environment variables:\n"
            "  comate mcp add -e API_KEY=xxx my-server -- npx my-mcp-server\n\n"
            "  # Add stdio server with subprocess flags:\n"
            "  comate mcp add my-server -- my-command --some-flag arg1"
        ),
    )
    subparsers = parser.add_subparsers(dest="command")

    add_parser = subparsers.add_parser("add", help="Add an MCP server to comate")
    add_parser.add_argument(
        "--scope",
        choices=("user", "project"),
        default="user",
        help="Config scope (default: user)",
    )
    add_parser.add_argument(
        "--transport",
        choices=("http", "stdio"),
        help="Server transport (default: stdio)",
    )
    add_parser.add_argument(
        "--header",
        action="append",
        default=[],
        help='HTTP header in format "Key: Value" (can repeat)',
    )
    add_parser.add_argument(
        "-e",
        "--env",
        action="append",
        default=[],
        help='Environment variable in format "KEY=VALUE" (can repeat)',
    )
    add_parser.add_argument("name")
    add_parser.add_argument("command_or_url", nargs="?")

    get_parser = subparsers.add_parser("get", help="Get details about an MCP server")
    get_parser.add_argument("name")
    get_parser.add_argument(
        "--scope",
        choices=("user", "project", "effective"),
        default="effective",
        help="Read from specific scope or merged effective view (default: effective)",
    )

    list_parser = subparsers.add_parser("list", help="List configured MCP servers")
    list_parser.add_argument(
        "--scope",
        choices=("user", "project", "effective"),
        default="effective",
        help="List specific scope or merged effective view (default: effective)",
    )

    remove_parser = subparsers.add_parser("remove", help="Remove an MCP server")
    remove_parser.add_argument("name")
    remove_parser.add_argument(
        "--scope",
        choices=("user", "project"),
        default="user",
        help="Delete from scope (default: user)",
    )

    return parser


def _scope_label(scope: str) -> str:
    if scope == "project":
        return "Project config (private to this project)"
    return "User config (~/.agent/.mcp.json)"


def _effective_source_label(source: str) -> str:
    if source == "project":
        return "Project config (private to this project)"
    return "User config (~/.agent/.mcp.json)"


def _parse_header_entries(entries: list[str]) -> dict[str, str]:
    headers: dict[str, str] = {}
    for raw in entries:
        if ":" not in raw:
            raise McpCliError(
                f"Invalid --header value: {raw!r}. Expected format: Key: Value"
            )
        key, value = raw.split(":", 1)
        normalized_key = key.strip()
        normalized_value = value.strip()
        if not normalized_key:
            raise McpCliError(f"Invalid --header key: {raw!r}")
        headers[normalized_key] = normalized_value
    return headers


def _parse_env_entries(entries: list[str]) -> dict[str, str]:
    env: dict[str, str] = {}
    for raw in entries:
        if "=" not in raw:
            raise McpCliError(
                f"Invalid --env value: {raw!r}. Expected format: KEY=VALUE"
            )
        key, value = raw.split("=", 1)
        normalized_key = key.strip()
        if not normalized_key:
            raise McpCliError(f"Invalid --env key: {raw!r}")
        env[normalized_key] = value
    return env


def _split_trailing_command_args(argv: list[str]) -> tuple[list[str], list[str]]:
    if "--" not in argv:
        return list(argv), []
    separator_index = argv.index("--")
    return list(argv[:separator_index]), list(argv[separator_index + 1 :])


def _build_add_server_config(args: argparse.Namespace) -> McpServerConfig:
    transport = str(args.transport or "stdio").strip().lower()
    header_entries = [str(item) for item in list(args.header or [])]
    env_entries = [str(item) for item in list(args.env or [])]
    command_or_url = str(args.command_or_url or "").strip()
    remainder = [str(item) for item in list(getattr(args, "extra_args", []) or [])]

    if transport == "http":
        if env_entries:
            raise McpCliError("--env is only supported for stdio transport")
        if not command_or_url:
            raise McpCliError("HTTP transport requires <commandOrUrl> as URL")
        if remainder:
            raise McpCliError("HTTP transport does not accept trailing command args")
        headers = _parse_header_entries(header_entries)
        cfg: dict[str, Any] = {
            "type": "http",
            "url": command_or_url,
        }
        if headers:
            cfg["headers"] = headers
        return cfg  # type: ignore[return-value]

    if header_entries:
        raise McpCliError("--header is only supported for http transport")
    stdio_args = list(remainder)
    if not command_or_url and stdio_args:
        command_or_url = stdio_args.pop(0)
    if not command_or_url:
        raise McpCliError("stdio transport requires command after <name>")

    env = _parse_env_entries(env_entries)
    cfg = {
        "command": command_or_url,
    }
    if stdio_args:
        cfg["args"] = stdio_args
    if env:
        cfg["env"] = env
    return cfg  # type: ignore[return-value]


def _load_servers_by_scope(*, scope: str, project_root: PathInput | None) -> dict[str, McpServerConfig]:
    if scope == "effective":
        return load_effective_servers(project_root=project_root)
    return load_scope_servers(scope=scope, project_root=project_root)  # type: ignore[arg-type]


def _read_effective_server_with_source(
    *,
    name: str,
    project_root: PathInput | None,
) -> tuple[McpServerConfig, str] | None:
    user_servers = load_scope_servers(scope="user", project_root=project_root)
    project_servers = load_scope_servers(scope="project", project_root=project_root)
    if name in project_servers:
        return project_servers[name], "project"
    if name in user_servers:
        return user_servers[name], "user"
    return None


def _render_health_status(
    *,
    status: str | None,
    connected: bool,
    reason: str | None,
) -> str:
    normalized = str(status or "").strip().lower()
    if normalized == "connected" or (normalized in {"", "idle"} and connected):
        return f"{CHECK_MARK} Connected"
    if normalized == "connecting":
        return f"{ELLIPSIS} Connecting"
    if reason:
        return f"{CROSS_MARK} {reason}"
    return f"{CROSS_MARK} Not connected"


def _format_server_endpoint(cfg: McpServerConfig) -> str:
    server_type = str(cfg.get("type", "stdio")).strip().lower()  # type: ignore[attr-defined]
    if server_type in {"http", "sse"}:
        return str(cfg.get("url", "")).strip()  # type: ignore[attr-defined]

    command = str(cfg.get("command", "")).strip()  # type: ignore[attr-defined]
    args = cfg.get("args") or []  # type: ignore[attr-defined]
    str_args = [str(item) for item in args] if isinstance(args, list) else []
    return " ".join([command, *str_args]).strip()


def _cmd_add(args: argparse.Namespace, *, project_root: PathInput | None) -> None:
    scope = str(args.scope)
    name = str(args.name).strip()
    if not name:
        raise McpCliError("Server name cannot be empty")

    config = _build_add_server_config(args)
    servers = load_scope_servers(scope=scope, project_root=project_root)  # type: ignore[arg-type]
    existed = name in servers
    servers[name] = config

    path = scope_mcp_path(scope=scope, project_root=project_root)  # type: ignore[arg-type]
    write_mcp_servers_to_path(path=path, servers=servers)

    action = "Updated" if existed else "Added"
    sys.stdout.write(
        f"{action} MCP server '{name}' in {scope} scope: {path.expanduser()}\n"
    )


def _cmd_remove(args: argparse.Namespace, *, project_root: PathInput | None) -> None:
    scope = str(args.scope)
    name = str(args.name).strip()
    if not name:
        raise McpCliError("Server name cannot be empty")

    servers = load_scope_servers(scope=scope, project_root=project_root)  # type: ignore[arg-type]
    if name not in servers:
        raise McpCliError(
            f"MCP server '{name}' not found in {scope} scope.",
            exit_code=1,
        )

    servers.pop(name, None)
    path = scope_mcp_path(scope=scope, project_root=project_root)  # type: ignore[arg-type]
    write_mcp_servers_to_path(path=path, servers=servers)
    sys.stdout.write(
        f"Removed MCP server '{name}' from {scope} scope: {path.expanduser()}\n"
    )


def _cmd_list(args: argparse.Namespace, *, project_root: PathInput | None) -> None:
    scope = str(args.scope)
    servers = _load_servers_by_scope(scope=scope, project_root=project_root)
    if not servers:
        sys.stdout.write("No MCP servers configured.\n")
        return

    sys.stdout.write("Checking MCP server health...\n\n")
    health_rows = asyncio.run(collect_mcp_server_health(servers=servers))
    health_by_alias = {row.alias: row for row in health_rows}

    for alias in sorted(servers.keys()):
        cfg = servers[alias]
        server_type = str(cfg.get("type", "stdio")).strip().upper()  # type: ignore[attr-defined]
        endpoint = _format_server_endpoint(cfg)
        health = health_by_alias.get(alias)
        status = (
            _render_health_status(
                status=getattr(health, "status", None),
                connected=health.connected,
                reason=health.reason,
            )
            if health is not None
            else f"{CROSS_MARK} Unknown"
        )
        sys.stdout.write(f"{alias}: {endpoint} ({server_type}) - {status}\n")


def _cmd_get(args: argparse.Namespace, *, project_root: PathInput | None) -> None:
    name = str(args.name).strip()
    scope = str(args.scope)
    if not name:
        raise McpCliError("Server name cannot be empty")

    if scope == "effective":
        resolved = _read_effective_server_with_source(
            name=name,
            project_root=project_root,
        )
        if resolved is None:
            raise McpCliError(f"MCP server '{name}' not found.", exit_code=1)
        cfg, source = resolved
        scope_line = _effective_source_label(source)
    else:
        servers = load_scope_servers(scope=scope, project_root=project_root)  # type: ignore[arg-type]
        cfg = servers.get(name)
        if cfg is None:
            raise McpCliError(
                f"MCP server '{name}' not found in {scope} scope.",
                exit_code=1,
            )
        scope_line = _scope_label(scope)

    health_rows = asyncio.run(collect_mcp_server_health(servers={name: cfg}))
    status = f"{CROSS_MARK} Not connected"
    if health_rows:
        row = health_rows[0]
        status = _render_health_status(
            status=getattr(row, "status", None),
            connected=row.connected,
            reason=row.reason,
        )

    server_type = str(cfg.get("type", "stdio")).strip().lower()  # type: ignore[attr-defined]
    lines = [
        f"{name}:",
        f"  Scope: {scope_line}",
        f"  Status: {status}",
        f"  Type: {server_type}",
    ]

    if server_type in {"http", "sse"}:
        lines.append(f"  URL: {str(cfg.get('url', '')).strip()}")  # type: ignore[attr-defined]
        headers = cfg.get("headers") or {}  # type: ignore[attr-defined]
        if isinstance(headers, dict) and headers:
            lines.append("  Headers:")
            for key in sorted(headers.keys()):
                lines.append(f"    {key}: {headers[key]}")
    else:
        lines.append(f"  Command: {str(cfg.get('command', '')).strip()}")  # type: ignore[attr-defined]
        raw_args = cfg.get("args") or []  # type: ignore[attr-defined]
        if isinstance(raw_args, list) and raw_args:
            lines.append(f"  Args: {' '.join(str(item) for item in raw_args)}")
        env = cfg.get("env") or {}  # type: ignore[attr-defined]
        if isinstance(env, dict) and env:
            lines.append("  Env:")
            for key in sorted(env.keys()):
                lines.append(f"    {key}: {env[key]}")

    if scope == "effective":
        remove_scope = "project" if "Project config" in scope_line else "user"
    else:
        remove_scope = scope
    lines.append("")
    lines.append(
        f'To remove this server, run: comate mcp remove "{name}" --scope {remove_scope}'
    )
    sys.stdout.write("\n".join(lines) + "\n")


def run_mcp_command(argv: list[str], *, project_root: PathInput | None = None) -> None:
    parser = _build_parser()
    parser_argv, trailing_args = _split_trailing_command_args(argv)
    parsed = parser.parse_args(parser_argv)
    command = str(getattr(parsed, "command", "") or "").strip()
    if not command:
        parser.print_help(sys.stdout)
        return
    if command != "add" and trailing_args:
        joined = " ".join(["--", *trailing_args])
        raise McpCliError(f"Unrecognized arguments: {joined}")
    if command == "add":
        setattr(parsed, "extra_args", list(trailing_args))

    handlers = {
        "add": _cmd_add,
        "list": _cmd_list,
        "get": _cmd_get,
        "remove": _cmd_remove,
    }
    handler = handlers.get(command)
    if handler is None:
        raise McpCliError(f"Unknown mcp command: {command}")

    try:
        handler(parsed, project_root=project_root)
    except McpConfigError as exc:
        raise McpCliError(str(exc), exit_code=1) from exc
