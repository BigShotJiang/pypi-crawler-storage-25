from __future__ import annotations

from enum import Enum


class UIMode(Enum):
    NORMAL = "normal"
    QUESTION = "question"
    SELECTION = "selection"
    PLUGIN = "plugin"
    MARKETPLACE_INSTALL = "marketplace_install"
    MCP_CONNECTING = "mcp_connecting"
