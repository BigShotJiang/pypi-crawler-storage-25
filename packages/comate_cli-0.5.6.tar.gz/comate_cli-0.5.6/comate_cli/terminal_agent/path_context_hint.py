"""Generate lightweight path-context hints for @path mentions in user messages."""
from __future__ import annotations

import logging
from pathlib import Path

from comate_cli.terminal_agent.custom_slash_commands import FILE_REF_PATTERN
from comate_cli.terminal_agent.figures import INJECTED_ARROW

logger = logging.getLogger(__name__)

_MAX_MENTIONS = 10
_LINE_COUNT_MAX_BYTES = 256 * 1024  # 256KB


def build_path_context_hint(text: str, project_root: Path) -> str | None:
    """Parse @path mentions from text and return a hint string, or None if no valid paths."""
    resolved_root = project_root.expanduser().resolve()
    matches = list(FILE_REF_PATTERN.finditer(text))
    if not matches:
        return None

    hint_lines: list[str] = []
    for match in matches[:_MAX_MENTIONS]:
        raw_path = match.group(1).strip()
        if not raw_path:
            continue

        candidate = (resolved_root / raw_path).resolve()
        # Safety: skip paths that escape project root
        try:
            candidate.relative_to(resolved_root)
        except ValueError:
            continue

        try:
            if candidate.is_dir():
                desc = _describe_dir(raw_path, candidate)
                hint_lines.append(f"{desc} [{candidate}]")
            elif candidate.is_file():
                desc = _describe_file(raw_path, candidate)
                hint_lines.append(f"{desc} [{candidate}]")
            else:
                # Not found — only include if path looks like a filesystem path
                if "/" in raw_path or "." in raw_path:
                    hint_lines.append(f"- @{raw_path} {INJECTED_ARROW} not found")
        except OSError:
            continue

    if not hint_lines:
        return None

    return "<system_reminder>\n" + "\n".join(hint_lines) + "\n</system_reminder>"


def _describe_dir(raw_path: str, candidate: Path) -> str:
    try:
        entries = list(candidate.iterdir())
    except OSError:
        return f"- @{raw_path} {INJECTED_ARROW} directory (unreadable)"

    if not entries:
        return f"- @{raw_path} {INJECTED_ARROW} directory (empty)"

    files = sum(1 for e in entries if e.is_file())
    subdirs = sum(1 for e in entries if e.is_dir())

    parts: list[str] = []
    if files > 0:
        parts.append(f"{files} file{'s' if files != 1 else ''}")
    if subdirs > 0:
        parts.append(f"{subdirs} subdir{'s' if subdirs != 1 else ''}")
    return f"- @{raw_path} {INJECTED_ARROW} directory ({', '.join(parts)})" if parts else f"- @{raw_path} {INJECTED_ARROW} directory ({len(entries)} entries)"


def _describe_file(raw_path: str, candidate: Path) -> str:
    suffix = candidate.suffix or "no ext"
    try:
        size = candidate.stat().st_size
    except OSError:
        return f"- @{raw_path} {INJECTED_ARROW} file ({suffix})"

    if size > _LINE_COUNT_MAX_BYTES:
        return f"- @{raw_path} {INJECTED_ARROW} file ({suffix}, ~large)"

    try:
        with open(candidate, "rb") as fh:
            line_count = sum(1 for _ in fh)
        return f"- @{raw_path} {INJECTED_ARROW} file ({suffix}, {line_count} lines)"
    except OSError:
        return f"- @{raw_path} {INJECTED_ARROW} file ({suffix})"
