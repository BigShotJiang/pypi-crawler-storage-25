"""图形 / 图标 / Unicode 字符常量集中管理。

设计原则
--------
1. 与 ``claude_code_codebase/src/constants/figures.ts`` 严格对齐：
   同名常量 = 同一字符语义。
2. darwin 平台分支保留：``BLACK_CIRCLE`` 在 macOS 用 ``⏺`` 居中更好，
   其它平台回退到 ``●``。
3. comate-only 扩展常量遵循 figures.ts 的 SCREAMING_SNAKE_CASE 风格，
   按语义分组放在文件后半段。
4. 字符以 ``\\uXXXX`` 转义书写，便于 grep / diff 时直接定位 codepoint，
   并防止编辑器字体规范化误改。
"""

from __future__ import annotations

import sys

_IS_DARWIN = sys.platform == "darwin"


# ─────────────────────────────────────────────────────────────────────
# 与 figures.ts 一一对应（25 个常量）
# ─────────────────────────────────────────────────────────────────────

# ⏺ (darwin) / ● (other) — 主要 marker（assistant prefix、history entry 等）
BLACK_CIRCLE = "⏺" if _IS_DARWIN else "●"

BULLET_OPERATOR = "∙"        # ∙

TEARDROP_ASTERISK = "✻"      # ✻

UP_ARROW = "↑"               # ↑
DOWN_ARROW = "↓"             # ↓

LIGHTNING_BOLT = "↯"         # ↯ — fast mode 指示

# Effort levels（语义：满程度）
EFFORT_LOW = "○"             # ○
EFFORT_MEDIUM = "◐"          # ◐
EFFORT_HIGH = "●"            # ●
EFFORT_MAX = "◉"             # ◉

# 媒体 / 触发器状态
PLAY_ICON = "▶"              # ▶
PAUSE_ICON = "⏸"             # ⏸

# MCP 订阅与跨会话指示
REFRESH_ARROW = "↻"          # ↻
CHANNEL_ARROW = "←"          # ←
INJECTED_ARROW = "→"         # →
FORK_GLYPH = "⑂"             # ⑂

# Review / 审查状态（ultrareview diamond）
DIAMOND_OPEN = "◇"           # ◇
DIAMOND_FILLED = "◆"         # ◆
REFERENCE_MARK = "※"         # ※

# Issue flag
FLAG_ICON = "⚑"              # ⚑

# Blockquote / 装饰横线
BLOCKQUOTE_BAR = "▎"         # ▎
HEAVY_HORIZONTAL = "━"       # ━

# Bridge 状态指示
BRIDGE_SPINNER_FRAMES: tuple[str, ...] = (
    "·|·",
    "·/·",
    "·—·",
    "·\\·",
)
BRIDGE_READY_INDICATOR = "·✔︎·"   # ·✔︎·
BRIDGE_FAILED_INDICATOR = "×"                    # ×


# ─────────────────────────────────────────────────────────────────────
# comate-only 扩展（命名风格延续 figures.ts）
# figures.ts 没有定义但 comate_cli 实际需要的字符。
# ─────────────────────────────────────────────────────────────────────

# 状态符号（√ × ✖ ✔）
CHECK_MARK = "✓"             # ✓ — 工具成功 / MCP connected / 任务 completed
CROSS_MARK = "✗"             # ✗ — 失败 / 未连接
HEAVY_MULTIPLICATION = "✖"   # ✖ — 工具错误前缀
HEAVY_CHECK_MARK = "✔"       # ✔ — 问题全部回答完成的 submit marker

# 嵌套行 / 子项前缀
BOTTOM_LEFT_CROP = "⎿"       # ⎿ — tool subtitle / file_ref 前缀
BULLET = "•"                 # • — 默认 entry prefix

# Task 状态
TASK_IN_PROGRESS = "◼"       # ◼
TASK_PENDING = "▢"           # ▢
TASK_BLOCKED = "▫"           # ▫

# Mode 指示 & 中断
FAST_PLAY_ICON = "⏵"         # ⏵ — Act mode（成对使用 ⏵⏵）
STOP_ICON = "⏹"              # ⏹

# 警告 & 省略
WARNING_ICON = "⚠"           # ⚠
ELLIPSIS = "…"               # …

# Thinking 提示
THINKING_BUBBLE = "\U0001f4ad"    # 💭

# 选择框
CHECKBOX_CHECKED = "☒"       # ☒
CHECKBOX_UNCHECKED = "☐"     # ☐

# Pulse 动画（tool_view loading 旋转 4 帧）
PULSE_GLYPHS: tuple[str, ...] = (
    "◐",                     # ◐
    "◓",                     # ◓
    "◑",                     # ◑
    "◒",                     # ◒
)

# Breathing 动画（assistant 思考期 marker 呼吸：暗 / 亮）
BREATH_DOT_GLYPHS: tuple[str, ...] = (
    EFFORT_LOW,                   # ○
    BLACK_CIRCLE,                 # ⏺ / ●（随平台）
)
