"""Version codenames — one entry per memorable release."""

from __future__ import annotations

CODENAMES: dict[str, str] = {
    "0.3.4": "",
    "0.3.3": "Update for My Brothers",
    "0.3.2": "We are with Ukraine",
}


def get_codename(ver: str) -> str | None:
    """Return codename for a version string like '0.3.2' or 'v0.3.2'."""
    stripped = ver.lstrip("v")
    return CODENAMES.get(stripped)
