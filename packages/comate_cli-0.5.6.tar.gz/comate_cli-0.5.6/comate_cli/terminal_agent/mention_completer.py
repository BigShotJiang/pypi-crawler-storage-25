from __future__ import annotations

import os
import re
import subprocess
import time
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

import logging
from prompt_toolkit.completion import CompleteEvent, Completer, Completion
from prompt_toolkit.document import Document

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class MentionContext:
    marker_index: int
    fragment: str


class LocalFileMentionCompleter(Completer):
    """Offer fuzzy `@` path suggestions backed by workspace files."""

    _TRIGGER_GUARDS = frozenset((".", "-", "_", "`", "'", '"', ":", "@", "#", "~"))
    _IGNORED_NAME_GROUPS: dict[str, tuple[str, ...]] = {
        "vcs_metadata": (".DS_Store", ".bzr", ".git", ".hg", ".svn"),
        "tooling_caches": (
            ".build",
            ".cache",
            ".coverage",
            ".fleet",
            ".gradle",
            ".idea",
            ".ipynb_checkpoints",
            ".pnpm-store",
            ".pytest_cache",
            ".pub-cache",
            ".ruff_cache",
            ".swiftpm",
            ".tox",
            ".venv",
            ".vs",
            ".vscode",
            ".yarn",
            ".yarn-cache",
        ),
        "js_frontend": (
            ".next",
            ".nuxt",
            ".parcel-cache",
            ".svelte-kit",
            ".turbo",
            ".vercel",
            "node_modules",
        ),
        "python_packaging": (
            "__pycache__",
            "coverage",
            "htmlcov",
            "pip-wheel-metadata",
            "venv",
        ),
        "java_jvm": (".mvn", "out", "target"),
        "dotnet_native": ("bin", "cmake-build-debug", "cmake-build-release", "obj"),
        "bazel_buck": ("bazel-bin", "bazel-out", "bazel-testlogs", "buck-out"),
        "misc_artifacts": (
            ".dart_tool",
            ".serverless",
            ".stack-work",
            ".terraform",
            ".terragrunt-cache",
            "DerivedData",
            "Pods",
            "deps",
            "tmp",
            "vendor",
        ),
    }
    _IGNORED_NAMES = frozenset(name for group in _IGNORED_NAME_GROUPS.values() for name in group)
    _IGNORED_PATTERN_PARTS: tuple[str, ...] = (
        r".*_cache$",
        r".*-cache$",
        r".*\.egg-info$",
        r".*\.dist-info$",
        r".*\.py[co]$",
        r".*\.class$",
        r".*\.sw[po]$",
        r".*~$",
        r".*\.(?:tmp|bak)$",
    )
    _IGNORED_PATTERNS = re.compile(
        "|".join(f"(?:{part})" for part in _IGNORED_PATTERN_PARTS),
        re.IGNORECASE,
    )

    def __init__(
        self,
        root: Path,
        *,
        refresh_interval: float = 2.0,
        limit: int = 1000,
    ) -> None:
        self._root = root
        self._refresh_interval = refresh_interval
        self._limit = limit

        self._top_cache_time: float = 0.0
        self._top_cached_paths: list[str] = []

        self._deep_cache_time: float = 0.0
        self._deep_cached_paths: list[str] = []
        self._directory_cached_paths: dict[str, tuple[float, list[str]]] = {}

    @classmethod
    def _is_ignored(cls, name: str) -> bool:
        if not name:
            return True
        if name in cls._IGNORED_NAMES:
            return True
        return bool(cls._IGNORED_PATTERNS.fullmatch(name))

    def extract_context(self, text_before_cursor: str) -> MentionContext | None:
        marker_index = text_before_cursor.rfind("@")
        if marker_index == -1:
            return None

        if marker_index > 0:
            previous = text_before_cursor[marker_index - 1]
            if previous.isalnum() or previous in self._TRIGGER_GUARDS:
                return None

        fragment = text_before_cursor[marker_index + 1 :]
        if any(char.isspace() for char in fragment):
            return None

        return MentionContext(marker_index=marker_index, fragment=fragment)

    def suggest(self, text_before_cursor: str, *, max_items: int = 12) -> tuple[MentionContext, list[str]] | None:
        context = self.extract_context(text_before_cursor)
        if context is None:
            return None
        if self._is_completed_file(context.fragment):
            return None

        result_limit = max(max_items, 1)
        if self._limit > 0:
            result_limit = min(result_limit, self._limit)

        if not context.fragment:
            source = self._get_top_level_paths()
            if not source:
                return None
            return context, source[:result_limit]

        fragment_lower = context.fragment.lower()
        directory_source = self._get_directory_candidates(context.fragment)
        if directory_source is not None:
            matched = [
                path
                for path in directory_source
                if not fragment_lower or path.lower().startswith(fragment_lower)
            ]
            if not matched:
                return None
            matched.sort(key=str.lower)
            return context, matched
        if "/" in context.fragment:
            return None

        source = self._candidate_paths(context.fragment)
        if not source:
            return None

        matched: list[tuple[tuple[int, int, int, int, int, int, int, int, str], str]] = []
        for path in source:
            rank = self._rank_match(path, context.fragment)
            if rank is not None:
                matched.append((rank, path))

        if not matched:
            return None

        matched.sort(key=lambda item: item[0])
        return context, [path for _, path in matched[:result_limit]]

    def apply_completion(
        self,
        *,
        full_text: str,
        cursor_position: int,
        context: MentionContext,
        completion: str,
        append_space: bool,
    ) -> tuple[str, int]:
        before_cursor = full_text[:cursor_position]
        after_cursor = full_text[cursor_position:]
        fragment_start = context.marker_index + 1
        replacement_before = f"{before_cursor[:fragment_start]}{completion}"
        new_cursor = len(replacement_before)
        replacement_after = after_cursor

        if append_space:
            should_insert_space = not replacement_after.startswith(" ")
            if should_insert_space:
                replacement_before = f"{replacement_before} "
                new_cursor += 1

        return f"{replacement_before}{replacement_after}", new_cursor

    def _candidate_paths(self, fragment: str) -> list[str]:
        if "/" not in fragment and len(fragment) < 3:
            return self._get_top_level_paths()
        return self._get_deep_paths()

    def _get_directory_candidates(self, fragment: str) -> list[str] | None:
        directory_fragment = self._directory_fragment(fragment)
        if directory_fragment is None:
            return None
        return self._get_directory_paths(directory_fragment)

    def _directory_fragment(self, fragment: str) -> str | None:
        if "/" not in fragment:
            return None
        if fragment.startswith(("/", "~")):
            return None
        directory_fragment = fragment if fragment.endswith("/") else fragment.rpartition("/")[0]
        if directory_fragment in ("", "."):
            return ""
        return directory_fragment

    def _get_directory_paths(self, directory_fragment: str) -> list[str]:
        cache_key = directory_fragment or "."
        now = time.monotonic()
        cached = self._directory_cached_paths.get(cache_key)
        if cached is not None:
            cached_at, cached_paths = cached
            if now - cached_at <= self._refresh_interval:
                return cached_paths

        directory = self._resolve_directory(directory_fragment)
        if directory is None:
            return []

        prefix = f"{directory_fragment.rstrip('/')}/" if directory_fragment else ""
        entries: list[str] = []
        try:
            for entry in sorted(directory.iterdir(), key=lambda path: path.name):
                name = entry.name
                if self._is_ignored(name):
                    continue
                entries.append(f"{prefix}{name}/" if entry.is_dir() else f"{prefix}{name}")
        except OSError as exc:
            logger.debug("directory mention scan failed for %s: %s", directory_fragment, exc)
            return cached[1] if cached is not None else []

        self._directory_cached_paths[cache_key] = (now, entries)
        return entries

    def _resolve_directory(self, directory_fragment: str) -> Path | None:
        try:
            candidate = (self._root / directory_fragment).resolve()
            candidate.relative_to(self._root.resolve())
        except (OSError, ValueError):
            return None
        if not candidate.is_dir():
            return None
        return candidate

    def _get_top_level_paths(self) -> list[str]:
        now = time.monotonic()
        if now - self._top_cache_time <= self._refresh_interval:
            return self._top_cached_paths

        entries: list[str] = []
        try:
            for entry in sorted(
                self._root.iterdir(),
                key=lambda path: (
                    1 if path.name.startswith(".") else 0,
                    0 if path.is_dir() else 1,
                    path.name.lower(),
                ),
            ):
                name = entry.name
                if self._is_ignored(name):
                    continue
                entries.append(f"{name}/" if entry.is_dir() else name)
        except OSError as exc:
            logger.debug("top-level mention scan failed: %s", exc)
            return self._top_cached_paths

        self._top_cached_paths = entries
        self._top_cache_time = now
        return self._top_cached_paths

    def _get_deep_paths(self) -> list[str]:
        now = time.monotonic()
        if now - self._deep_cache_time <= self._refresh_interval:
            return self._deep_cached_paths

        file_paths = self._load_indexed_file_paths()
        paths = self._build_deep_paths(file_paths)

        self._deep_cached_paths = paths
        self._deep_cache_time = now
        return self._deep_cached_paths

    def _load_indexed_file_paths(self) -> list[str]:
        git_paths = self._get_paths_from_git()
        if git_paths is not None:
            return git_paths

        ripgrep_paths = self._get_paths_from_ripgrep()
        if ripgrep_paths is not None:
            return ripgrep_paths

        return self._get_paths_from_walk()

    def _get_paths_from_git(self) -> list[str] | None:
        return self._run_index_command(
            ["git", "ls-files", "--cached", "--others", "--exclude-standard"],
            source_name="git",
        )

    def _get_paths_from_ripgrep(self) -> list[str] | None:
        return self._run_index_command(
            [
                "rg",
                "--files",
                "--hidden",
                "--glob",
                "!.git/",
                "--glob",
                "!.svn/",
                "--glob",
                "!.hg/",
                "--glob",
                "!.bzr/",
            ],
            source_name="ripgrep",
        )

    def _run_index_command(self, args: list[str], *, source_name: str) -> list[str] | None:
        try:
            completed = subprocess.run(
                args,
                cwd=self._root,
                capture_output=True,
                text=True,
                check=False,
                timeout=5,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            logger.debug("%s mention index command failed: %s", source_name, exc)
            return None

        if completed.returncode != 0:
            logger.debug(
                "%s mention index command exited with %s: %s",
                source_name,
                completed.returncode,
                completed.stderr.strip(),
            )
            return None

        indexed_paths: set[str] = set()
        for line in completed.stdout.splitlines():
            normalized = self._normalize_indexed_path(line)
            if normalized is None or not self._should_include_relative_path(normalized):
                continue
            indexed_paths.add(normalized)
        return sorted(indexed_paths, key=str.lower)

    def _get_paths_from_walk(self) -> list[str]:
        indexed_paths: set[str] = set()
        try:
            for current_root, dirs, files in os.walk(self._root):
                relative_root = Path(current_root).relative_to(self._root)
                dirs[:] = sorted(directory for directory in dirs if not self._is_ignored(directory))

                if relative_root.parts and any(self._is_ignored(part) for part in relative_root.parts):
                    dirs[:] = []
                    continue

                for file_name in sorted(files):
                    if self._is_ignored(file_name):
                        continue
                    relative = (relative_root / file_name).as_posix()
                    normalized = self._normalize_indexed_path(relative)
                    if normalized is None or not self._should_include_relative_path(normalized):
                        continue
                    indexed_paths.add(normalized)
        except OSError as exc:
            logger.debug("deep mention walk fallback failed: %s", exc)
            return self._deep_cached_paths
        return sorted(indexed_paths, key=str.lower)

    def _build_deep_paths(self, file_paths: list[str]) -> list[str]:
        directory_paths: set[str] = set()
        normalized_files: list[str] = []
        for file_path in file_paths:
            normalized = self._normalize_indexed_path(file_path)
            if normalized is None or not self._should_include_relative_path(normalized):
                continue
            normalized_files.append(normalized)
            parent = PurePosixPath(normalized).parent
            while str(parent) not in {"", "."}:
                directory_paths.add(parent.as_posix() + "/")
                parent = parent.parent

        combined = sorted(directory_paths, key=str.lower)
        combined.extend(sorted(set(normalized_files), key=str.lower))
        return combined

    def _normalize_indexed_path(self, raw_path: str) -> str | None:
        normalized = raw_path.strip().replace("\\", "/")
        if normalized.startswith("./"):
            normalized = normalized[2:]
        if not normalized:
            return None
        if normalized.startswith("/") or normalized.startswith("../"):
            return None
        if re.match(r"^[A-Za-z]:/", normalized):
            return None
        return normalized

    def _should_include_relative_path(self, relative_path: str) -> bool:
        parts = [part for part in PurePosixPath(relative_path).parts if part not in {"", "."}]
        if not parts:
            return False
        return not any(self._is_ignored(part) for part in parts)

    def _rank_match(
        self,
        path: str,
        fragment: str,
    ) -> tuple[int, int, int, int, int, int, int, int, str] | None:
        needle = fragment.lower()
        normalized = path.rstrip("/")
        normalized_lower = normalized.lower()
        basename = normalized.split("/")[-1]
        basename_lower = basename.lower()
        basename_offset = len(normalized) - len(basename)

        match_candidates: list[tuple[int, int, int, int, int, int, int, int, str]] = []

        basename_substring = self._find_substring_positions(basename_lower, needle)
        if basename_substring is not None:
            positions = [basename_offset + position for position in basename_substring]
            category = 0 if basename_substring[0] == 0 else 1
            match_candidates.append(self._build_rank(path, positions, category=category))

        path_substring = self._find_substring_positions(normalized_lower, needle)
        if path_substring is not None:
            match_candidates.append(self._build_rank(path, path_substring, category=2))

        basename_subsequence = self._find_subsequence_positions(basename_lower, needle)
        if basename_subsequence is not None:
            positions = [basename_offset + position for position in basename_subsequence]
            match_candidates.append(self._build_rank(path, positions, category=3))

        path_subsequence = self._find_subsequence_positions(normalized_lower, needle)
        if path_subsequence is not None:
            match_candidates.append(self._build_rank(path, path_subsequence, category=4))

        return min(match_candidates) if match_candidates else None

    @staticmethod
    def _find_substring_positions(haystack: str, needle: str) -> list[int] | None:
        start = haystack.find(needle)
        if start == -1:
            return None
        return list(range(start, start + len(needle)))

    @staticmethod
    def _find_subsequence_positions(haystack: str, needle: str) -> list[int] | None:
        positions: list[int] = []
        next_index = 0
        for char in needle:
            found = haystack.find(char, next_index)
            if found == -1:
                return None
            positions.append(found)
            next_index = found + 1
        return positions

    def _build_rank(
        self,
        path: str,
        positions: list[int],
        *,
        category: int,
    ) -> tuple[int, int, int, int, int, int, int, int, str]:
        normalized = path.rstrip("/")
        span = positions[-1] - positions[0]
        total_gap = span - (len(positions) - 1)
        boundary_bonus = self._boundary_bonus(normalized, positions)
        consecutive_bonus = self._consecutive_bonus(positions)
        depth = normalized.count("/")
        is_directory = path.endswith("/")
        return (
            category,
            -boundary_bonus,
            -consecutive_bonus,
            span,
            total_gap,
            0 if is_directory else 1,
            depth,
            len(normalized),
            normalized.lower(),
        )

    @staticmethod
    def _consecutive_bonus(positions: list[int]) -> int:
        bonus = 0
        for previous, current in zip(positions, positions[1:]):
            if current == previous + 1:
                bonus += 1
        return bonus

    @staticmethod
    def _boundary_bonus(path: str, positions: list[int]) -> int:
        bonus = 0
        for position in positions:
            if position <= 0:
                bonus += 2
                continue
            previous = path[position - 1]
            current = path[position]
            if previous in "/._-":
                bonus += 2
                continue
            if previous.islower() and current.isupper():
                bonus += 1
        return bonus

    def _is_completed_file(self, fragment: str) -> bool:
        candidate = fragment.rstrip("/")
        if not candidate:
            return False
        try:
            return (self._root / candidate).is_file()
        except OSError:
            return False

    def get_completions(
        self, document: Document, complete_event: CompleteEvent
    ) -> Iterable[Completion]:
        del complete_event
        completion_limit = self._limit if self._limit > 0 else 200
        result = self.suggest(document.text_before_cursor, max_items=completion_limit)
        if result is None:
            return

        context, candidates = result
        for candidate in candidates:
            append_space = not candidate.endswith("/") and not document.text_after_cursor.startswith(" ")
            insert_text = f"{candidate} " if append_space else candidate
            yield Completion(
                text=insert_text,
                start_position=-len(context.fragment),
                display=candidate,
            )
