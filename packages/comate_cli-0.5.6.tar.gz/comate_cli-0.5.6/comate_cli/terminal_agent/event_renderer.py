from __future__ import annotations

import logging
import re
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Literal

from comate_agent_sdk.agent.events import (
    CompactionResultEvent,
    PlanApprovalRequiredEvent,
    SessionInitEvent,
    StepCompleteEvent,
    StopEvent,
    SubagentProgressEvent,
    SubagentStartEvent,
    SubagentStopEvent,
    SubagentToolCallEvent,
    SubagentToolResultEvent,
    TeamMessageEvent,
    TextEvent,
    TextDeltaEvent,
    ThinkingEvent,
    ThinkingDeltaEvent,
    TaskUpdatedEvent,
    ToolCallEvent,
    ToolCallStartEvent,
    ToolResultEvent,
    UsageDeltaEvent,
    UserQuestionEvent,
)

from rich.console import RenderableType
from rich.text import Text

from comate_cli.terminal_agent.figures import (
    BOTTOM_LEFT_CROP,
    BULLET_OPERATOR,
    CHECK_MARK,
    CROSS_MARK,
    ELLIPSIS,
    HEAVY_HORIZONTAL,
    INJECTED_ARROW,
    TASK_BLOCKED,
    TASK_IN_PROGRESS,
    TASK_PENDING,
)
from comate_cli.terminal_agent.models import HistoryEntry, LoadingState
from comate_cli.terminal_agent.tool_view import summarize_tool_args, resolve_display_tool_name, should_show_tool_in_scrollback
from comate_cli.terminal_agent.env_utils import read_env_int
from comate_cli.terminal_agent.custom_slash_commands import FILE_REF_PATTERN
from comate_cli.terminal_agent.markdown_render import (
    render_markdown_to_plain,
)

logger = logging.getLogger(__name__)

_DEFAULT_TOOL_ERROR_SUMMARY_MAX_LEN = 160
_DEFAULT_TOOL_PANEL_MAX_LINES = 4
_DEFAULT_TASK_PANEL_MAX_LINES = 6
_RECENT_TEAM_EVENT_CACHE_SIZE = 128
_FILE_REF_MAX_COUNT_BYTES = 10 * 1024 * 1024  # 10 MB
_SYSTEM_MESSAGE_DEDUPE_WINDOW_SECONDS = 0.5


def _truncate(content: str, max_len: int = 120) -> str:
    if len(content) <= max_len:
        return content
    return f"{content[:max_len]}..."


def _format_duration(seconds: float) -> str:
    elapsed = max(seconds, 0.0)
    if elapsed < 60:
        return f"{elapsed:.1f}s"
    minutes = int(elapsed // 60)
    remaining_seconds = int(elapsed % 60)
    if minutes < 60:
        return f"{minutes}m{remaining_seconds:02d}s"
    hours = minutes // 60
    remaining_minutes = minutes % 60
    return f"{hours}h{remaining_minutes:02d}m"


def _format_tokens(token_count: int) -> str:
    tokens = max(int(token_count), 0)
    if tokens < 1_000:
        return f"{tokens} tok"
    compact = f"{tokens / 1_000:.1f}".rstrip("0").rstrip(".")
    return f"{compact}k tok"


def _split_fragments_by_newline(
    fragments: list[tuple[str, str]],
) -> list[list[tuple[str, str]]]:
    """Split prompt_toolkit fragments into lines, removing newline tokens."""
    lines: list[list[tuple[str, str]]] = [[]]
    for style, text in fragments:
        parts = text.split("\n")
        for idx, part in enumerate(parts):
            if part:
                lines[-1].append((style, part))
            if idx < len(parts) - 1:
                lines.append([])
    return lines


def _extract_task_title(args: dict[str, Any]) -> str:
    description = str(args.get("description", "")).strip()
    if description:
        return description

    subagent_name = str(args.get("subagent_type", "")).strip() or "Agent"
    return subagent_name


def _one_line(text: str) -> str:
    return " ".join(str(text).split())


def _tool_signature(tool_name: str, args_summary: str) -> str:
    normalized = args_summary.strip()
    if normalized:
        return f"{tool_name}({normalized})"
    return f"{tool_name}()"


def _task_sort_key(task: dict[str, Any]) -> tuple[int, int]:
    status = str(task.get("status", "pending")).strip().lower()
    open_blocked_by = task.get("open_blocked_by", [])
    is_blocked = isinstance(open_blocked_by, list) and len(open_blocked_by) > 0
    if status == "in_progress":
        rank = 0
    elif status == "pending" and not is_blocked:
        rank = 1
    elif status == "pending":
        rank = 2
    else:
        rank = 3

    try:
        numeric_id = int(task.get("id", 0))
    except (TypeError, ValueError):
        numeric_id = 0
    return rank, numeric_id


def _task_stats_header(tasks: list[dict[str, Any]]) -> str:
    """生成 task 统计标题，如 '3 tasks (1 done, 2 open)'。"""
    total = len(tasks)
    done = sum(
        1 for t in tasks
        if str(t.get("status", "")).strip().lower() == "completed"
    )
    open_count = total - done
    noun = "task" if total == 1 else "tasks"
    return f"{total} {noun} ({done} done, {open_count} open)"


def _format_task_row(task: dict[str, Any]) -> str:
    """格式化单条 task 行。

    符号约定：
    - ✓ completed
    - ◼ in_progress
    - ▢ pending (unblocked)
    - ▫ pending (blocked) — 视觉相似的中间符号，渲染层统一显示为 ▢ 但应用不同颜色
    """
    subject = str(task.get("subject", "")).strip() or "(untitled)"
    status = str(task.get("status", "pending")).strip().lower()
    open_blocked_by = task.get("open_blocked_by", [])

    if status == "completed":
        return f"{CHECK_MARK} {subject}"
    if status == "in_progress":
        return f"{TASK_IN_PROGRESS} {subject}"
    if isinstance(open_blocked_by, list) and open_blocked_by:
        return f"{TASK_BLOCKED} {subject}"
    return f"{TASK_PENDING} {subject}"


@dataclass
class _SubagentTool:
    """Subagent 内部的工具调用"""
    tool_name: str
    args_summary: str
    started_at_monotonic: float
    status: Literal["running", "completed", "error"] = "running"
    duration_ms: float = 0.0


@dataclass
class _RunningTool:
    tool_name: str
    title: str
    started_at_monotonic: float
    is_task: bool
    args_summary: str
    display_tool_name: str = ""
    progress_tokens: int = 0
    subagent_name: str = ""
    subagent_status: str = ""
    subagent_description: str = ""
    nested_tools: list[tuple[str, _SubagentTool]] = field(default_factory=list)
    show_init: bool = False
    subagent_model_name: str = ""


@dataclass
class ContainerState:
    """正在缓冲的 markdown 容器。仅 fence 与 table 两种 —— list / blockquote
    单行渲染效果可接受，不进入容器。"""

    kind: Literal["fence", "table"]
    lines: list[str] = field(default_factory=list)
    fence_marker: str | None = None
    """fence kind 用，verbatim 存开 fence 行的 marker（如 "```" / "~~~~"）。
    turn-end synthetic close 时直接 append 这个字符串作为闭合行，与
    _is_fence_close 的"同 char + ≥ 同长度"判定天然满足。"""
    fence_lang: str | None = None
    """fence kind 用，仅供 _loading_aux_text 显示（"正在写 python 代码块..."）。
    渲染时 rich.Markdown 自己从 lines[0] 重新解析。"""


# spec §6.3：fence 开 marker 正则。CommonMark 允许 ≥ 3 个 backtick / tilde；
# lang 字段允许空（裸 fence），但 lang 后不允许有其他内容（仅 trailing whitespace）。
_FENCE_OPEN_RE = re.compile(r"^(?P<marker>`{3,}|~{3,})\s*(?P<lang>\S*)\s*$")

# spec §6.3：GFM table 分隔符行正则。要求 ≥ 2 列（即 ≥ 1 个内部 | 分隔符）。
# 每个 cell 形如 [可选:]-+[可选:]，cell 之间用 | 分隔；首尾 | 可选。
_TABLE_SEP_RE = re.compile(r"^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)+\|?\s*$")


@dataclass
class FenceMatch:
    """spec §6.3：_detect_fence_open 返回值。"""

    marker: str
    lang: str


class EventRenderer:
    """Convert SDK events to lightweight terminal state for prompt_toolkit UI."""

    def __init__(self, project_root: Path | None = None) -> None:
        self._history: list[HistoryEntry] = []
        self._running_tools: dict[str, _RunningTool] = {}
        self._tool_call_args: dict[str, dict[str, Any]] = {}
        self._assistant_buffer = ""
        self._pending_tool_starts: set[str] = set()
        self._loading_state: LoadingState = LoadingState.idle()
        self._current_tasks: list[dict[str, Any]] = []
        self._current_task_title: str | None = None
        self._task_started_at_monotonic: float | None = None
        self._project_root = project_root
        self._tool_error_summary_max_len = read_env_int(
            "AGENT_SDK_TUI_TOOL_ERROR_SUMMARY_MAX_LEN",
            _DEFAULT_TOOL_ERROR_SUMMARY_MAX_LEN,
        )
        self._tool_panel_max_lines = read_env_int(
            "AGENT_SDK_TUI_TOOL_PANEL_MAX_LINES",
            _DEFAULT_TOOL_PANEL_MAX_LINES,
        )
        self._task_panel_max_lines = read_env_int(
            "AGENT_SDK_TUI_TASK_PANEL_MAX_LINES",
            _DEFAULT_TASK_PANEL_MAX_LINES,
        )
        self._diff_max_lines = read_env_int(
            "AGENT_SDK_TUI_DIFF_MAX_LINES",
            50,
        )
        self._latest_diff_lines: list[str] | None = None
        self._recent_team_event_keys: deque[tuple[str, str, str, str, str, str]] = deque(
            maxlen=_RECENT_TEAM_EVENT_CACHE_SIZE
        )
        self._last_history_append_at: float = 0.0
        self._show_thinking_cb: Callable[[], bool] = lambda: True
        self._turn_received_text_delta: bool = False
        self._turn_received_thinking_delta: bool = False
        self._text_delta_started: bool = False
        # ━━━━━ spec §4.1 新管道状态字段（Phase 1.2 引入，Phase 4-6 接入） ━━━━━
        # Pipeline A: text line-commit
        self._text_pending: str = ""
        self._held_pipe_line: str | None = None
        self._container: ContainerState | None = None
        # Pipeline B: thinking line-commit + tail
        self._thinking_batch: str = ""
        # Pipeline C: loading 行 aux
        self._loading_aux_text: str = ""

    def _append_history_entry(self, entry: HistoryEntry) -> None:
        self._history.append(entry)
        self._last_history_append_at = time.monotonic()

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # spec §6 流式新管道方法集（Phase 1-6 新增；Phase 7 接入 handle_event）
    # 容器检测原语（spec §6.3）
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def _detect_fence_open(self, line: str) -> FenceMatch | None:
        """spec §6.3：识别 fence 开行。
        规则：行首 ≥ 3 个 backtick / tilde + 可选 lang 标识符（不含空格）。
        lang 后不允许有其他内容（仅 trailing whitespace）。"""
        m = _FENCE_OPEN_RE.match(line)
        if m is None:
            return None
        return FenceMatch(marker=m.group("marker"), lang=m.group("lang") or "")

    def _is_fence_close(self, line: str) -> bool:
        """spec §6.3：判定 line 是否当前 fence 容器的闭合标记。
        要求：line.strip() 仅由 marker char (` 或 ~) 组成，且长度 ≥ 开 marker。"""
        assert self._container is not None and self._container.kind == "fence"
        expected = self._container.fence_marker
        assert expected is not None
        char = expected[0]
        stripped = line.strip()
        return (
            len(stripped) >= len(expected)
            and len(stripped) > 0
            and all(c == char for c in stripped)
        )

    def _is_table_separator(self, line: str) -> bool:
        """spec §6.3：判定 line 是否 GFM table 分隔符行（如 "| --- | --- |"）。
        要求至少 2 列（即 ≥ 1 个内部 | 分隔符）。"""
        return bool(_TABLE_SEP_RE.match(line))

    def _looks_like_table_row(self, line: str) -> bool:
        """spec §6.3：判定 line 是否"看起来像 table row"。
        用于 held 候选 + table 续行判定（共用同一谓词保证对称语义）。

        规则：
        - 空行 / 仅空白 → False
        - 行首（去首部空白）以 | → True
        - 否则要求至少 2 个 |（GFM 允许无围栏 table 但需 ≥ 2 内部分隔符）
        """
        if not line.strip():
            return False
        if line.lstrip().startswith("|"):
            return True
        return line.count("|") >= 2

    # spec §6.3 别名机制：三方法语义完全等价，分别对应不同语境的可读性，
    # 但实现共用 —— 保证 held 候选与续行判定语义对称（避免分裂导致的 corner-case bug）。
    _is_table_continuation = _looks_like_table_row
    _has_pipe_chars = _looks_like_table_row

    # ── commit 出口（spec §6.5）──

    def _emit_text_line(self, line: str) -> None:
        """spec §6.5：单行 assistant text → HistoryEntry → 入队。"""
        self._append_history_entry(
            HistoryEntry(entry_type="assistant", text=line + "\n")
        )

    def _flush_container(self) -> None:
        """spec §6.5：容器整段 → HistoryEntry → 入队。
        rich.Markdown 在 history_printer 里把整段渲染为 syntax-highlighted
        code block / aligned table。flush 后必须清 aux 避免 stale phrase。"""
        assert self._container is not None
        full_text = "\n".join(self._container.lines) + "\n"
        self._append_history_entry(
            HistoryEntry(entry_type="assistant", text=full_text)
        )
        self._container = None
        self._loading_aux_text = ""

    def _flush_thinking_batch(self) -> None:
        """spec §6.5：thinking 残段 → HistoryEntry（受 _show_thinking_cb 过滤）。
        即使 hidden 也清空 batch 避免持续累积。"""
        text = self._thinking_batch
        self._thinking_batch = ""
        if not text:
            return
        if not self._show_thinking_cb():
            return
        self._append_history_entry(
            HistoryEntry(entry_type="thinking", text=text)
        )

    def _consume_thinking_delta(self, delta: str) -> None:
        """spec §6.1：thinking delta 主入口。

        与 text delta 对称：按完整行即时 commit 到 scrollback，未换行尾巴留在
        _thinking_batch，等待 text/tool/turn 边界通过 _flush_thinking_batch 落盘。
        """
        if not delta:
            return
        self._thinking_batch += delta
        while "\n" in self._thinking_batch:
            line, self._thinking_batch = self._thinking_batch.split("\n", 1)
            if self._show_thinking_cb():
                self._append_history_entry(
                    HistoryEntry(entry_type="thinking", text=line + "\n")
                )

    # ── 行级路由（spec §6.2，Task 4.1-4.4 渐进扩展）──

    def _handle_complete_line(self, line: str) -> None:
        """spec §6.2 行级路由 —— Task 4.1-4.4 全分支完成。"""
        # ━━━ 容器内 ━━━
        if self._container is not None:
            if self._container.kind == "fence":
                self._container.lines.append(line)
                if self._is_fence_close(line):
                    self._flush_container()
                else:
                    self._refresh_loading_aux()
                return
            if self._container.kind == "table":
                if self._is_table_continuation(line):
                    self._container.lines.append(line)
                    self._refresh_loading_aux()
                    return
                # table 结束（空行 / 非 table-row）：先 flush 容器，
                # 当前 line 继续走容器外逻辑（递归 1 次）
                self._flush_container()
                # plan 第 3 轮加固：flush_container 后 _container 必须为 None，
                # 否则递归无 bound（防御 _flush_container 实现退化）
                assert self._container is None, "table flush 后 container 必须为 None，防递归无 bound"
                self._handle_complete_line(line)
                return

        # ━━━ 容器外 ━━━

        # 持有的 pipe 候选行待确认 table（1-line lookahead）
        if self._held_pipe_line is not None:
            held = self._held_pipe_line
            self._held_pipe_line = None
            if self._is_table_separator(line):
                # 确认 table → 进入容器（held + sep 一起入容器）
                self._container = ContainerState(
                    kind="table", lines=[held, line],
                )
                self._refresh_loading_aux()
                return
            # 不是 separator → held 不是 table 头，落地为普通行
            self._emit_text_line(held)
            # 不 return：line 继续判定（可能它自己是 fence open / 新 pipe 候选）

        fm = self._detect_fence_open(line)
        if fm is not None:
            self._container = ContainerState(
                kind="fence", lines=[line],
                fence_marker=fm.marker, fence_lang=fm.lang,
            )
            self._refresh_loading_aux()
            return

        # 检测 pipe 候选行（潜在 table 头）—— spec §6.3 收紧判定
        if self._looks_like_table_row(line) and not self._is_table_separator(line):
            self._held_pipe_line = line
            return

        self._emit_text_line(line)

    def _refresh_loading_aux(self) -> None:
        """spec §6.7：容器缓冲期 spinner phrase 后的 dim 后缀文案。
        无容器时清空（防止旧 phrase 残留）。"""
        if self._container is None:
            self._loading_aux_text = ""
            return
        n = len(self._container.lines)
        if self._container.kind == "fence":
            lang = self._container.fence_lang or "code"
            self._loading_aux_text = f"正在写 {lang} 代码块（{n} 行）..."
        else:  # table
            self._loading_aux_text = f"正在写表格（{n} 行）..."

    def _consume_text_delta(self, delta: str) -> None:
        """spec §6.1：text delta 主入口。

        把 delta 累到 _text_pending，按 \\n 切完整行送 _handle_complete_line。

        关键顺序保证：text 进入前先 flush 待 thinking 残段 —— 保证
        scrollback 看到 "thinking → text" 而非 "text → thinking" 错序。
        """
        if not delta:
            return
        if self._thinking_batch:
            self._flush_thinking_batch()
        self._text_pending += delta
        while "\n" in self._text_pending:
            line, self._text_pending = self._text_pending.split("\n", 1)
            if line == "" and not self._text_delta_started:
                continue
            self._text_delta_started = True
            self._handle_complete_line(line)

    # ── turn 边界（spec §6.4）──

    def _force_flush_all(self) -> None:
        """spec §6.4：StopEvent / finalize_turn 调用。
        保证 scrollback 看到完整 turn 内容。

        顺序：held → container[fence synthetic close] → text_pending
        → thinking → 清 aux。
        """
        # ① held 落地
        if self._held_pipe_line is not None:
            self._emit_text_line(self._held_pipe_line)
            self._held_pipe_line = None
        # ② 容器残留：fence 自动追加 synthetic close（fence_marker verbatim
        #    存的就是开 fence 用的 marker，append 后 _is_fence_close 天然满足）；
        #    table 直接 flush，rich.Markdown 容错渲染
        if self._container is not None:
            if self._container.kind == "fence":
                assert self._container.fence_marker is not None
                self._container.lines.append(self._container.fence_marker)
            self._flush_container()
        # ③ text_pending 未换行残段（按完整行 emit）
        if self._text_pending:
            self._emit_text_line(self._text_pending)
            self._text_pending = ""
        # ④ thinking
        if self._thinking_batch:
            self._flush_thinking_batch()
        # ⑤ aux
        self._loading_aux_text = ""

    def _drop_all_pending(self) -> None:
        """spec §6.4：interrupt_turn 调用。
        语义：用户不要剩下的内容 —— 全部丢弃不入队（与 _force_flush_all
        相反，本方法不调用任何 _emit / _flush 出口）。"""
        self._text_pending = ""
        self._held_pipe_line = None
        self._container = None
        self._thinking_batch = ""
        self._loading_aux_text = ""
        self._text_delta_started = False

    def _should_drop_duplicate_system_message(
        self,
        *,
        content: str,
        severity: Literal["info", "warning", "error"],
    ) -> bool:
        if severity not in {"warning", "error"}:
            return False
        if not self._history:
            return False
        last_entry = self._history[-1]
        if last_entry.entry_type != "system":
            return False
        if last_entry.severity != severity:
            return False
        if str(last_entry.text).strip() != content:
            return False
        if time.monotonic() - self._last_history_append_at > _SYSTEM_MESSAGE_DEDUPE_WINDOW_SECONDS:
            return False
        logger.debug(
            "Skip duplicate system message in scrollback: severity=%s content=%r",
            severity,
            content,
        )
        return True

    def start_turn(self) -> None:
        self._flush_assistant_segment()
        self._pending_tool_starts.clear()
        self._turn_received_text_delta = False
        self._turn_received_thinking_delta = False
        self._text_delta_started = False
        # spec §6.4：清空新 5 字段（每 turn 起点保证状态干净）
        self._text_pending = ""
        self._held_pipe_line = None
        self._container = None
        self._thinking_batch = ""
        self._loading_aux_text = ""
        self._rebuild_loading_line()

    def seed_user_message(self, content: str) -> None:
        normalized = content.strip()
        if not normalized:
            return
        self._flush_assistant_segment()
        self._append_history_entry(HistoryEntry(entry_type="user", text=normalized))
        self._maybe_append_file_ref_hint(normalized)

    def _maybe_append_file_ref_hint(self, text: str) -> None:
        """Append a dim ⎿ hint for the first valid @path reference."""
        if self._project_root is None:
            return
        for match in FILE_REF_PATTERN.finditer(text):
            raw_path = match.group(1)
            candidate = self._project_root / raw_path
            try:
                if candidate.is_dir():
                    self._append_history_entry(
                        HistoryEntry(entry_type="file_ref", text=f"Listed directory {raw_path}")
                    )
                    return
                if candidate.is_file():
                    hint = f"Read {raw_path}"
                    if candidate.stat().st_size <= _FILE_REF_MAX_COUNT_BYTES:
                        try:
                            with open(candidate, "rb") as fh:
                                line_count = sum(1 for _ in fh)
                            hint += f"  ({line_count} lines)"
                        except OSError:
                            pass
                    self._append_history_entry(HistoryEntry(entry_type="file_ref", text=hint))
                    return
            except OSError:
                continue

    def close(self) -> None:
        return

    def finalize_turn(self) -> None:
        # spec §6.4：turn 结束 force flush 所有 pending（held / container /
        # text_pending / thinking）保证 scrollback 看到完整内容
        self._force_flush_all()
        self._flush_assistant_segment()
        self._pending_tool_starts.clear()
        self._rebuild_loading_line()

    def tick_progress(self) -> None:
        self._rebuild_loading_line()

    def refresh_loading_animation(self) -> None:
        self._rebuild_loading_line()

    def interrupt_turn(self) -> None:
        if self._running_tools:
            self._append_history_entry(
                HistoryEntry(
                    entry_type="system",
                    text=f"Current task interrupted ({len(self._running_tools)} running tools)",
                    severity="warning",
                )
            )
        self._running_tools.clear()
        self._flush_assistant_segment()
        self._pending_tool_starts.clear()
        # spec §6.4：用户中断 → 5 个新字段全部丢弃不入队
        self._drop_all_pending()
        self._rebuild_loading_line()

    def history_entries(self) -> list[HistoryEntry]:
        return list(self._history)

    def reset_history_view(self) -> None:
        """重置 history 视图状态（用于会话切换后的重新加载）。"""
        self._history = []
        self._recent_team_event_keys.clear()
        self._running_tools.clear()
        self._tool_call_args.clear()
        self._assistant_buffer = ""
        self._pending_tool_starts.clear()
        self._turn_received_text_delta = False
        self._turn_received_thinking_delta = False
        self._text_delta_started = False
        # spec §6.4：清空 5 个新字段（与 start_turn 同语义）
        self._text_pending = ""
        self._held_pipe_line = None
        self._container = None
        self._thinking_batch = ""
        self._loading_aux_text = ""
        self._loading_state = LoadingState.idle()
        self._current_tasks = []
        self._current_task_title = None
        self._task_started_at_monotonic = None
        self._latest_diff_lines = None

    @property
    def latest_diff_lines(self) -> list[str] | None:
        return self._latest_diff_lines

    def has_running_tools(self) -> bool:
        return bool(self._running_tools)

    def has_running_subagents(self) -> bool:
        """Return whether any running tool is an Agent(subagent) tool."""
        return any(state.is_task for state in self._running_tools.values())

    def has_active_tasks(self) -> bool:
        return bool(self._current_tasks)

    def has_active_todos(self) -> bool:
        return self.has_active_tasks()

    def has_in_progress_tasks(self) -> bool:
        return any(
            str(t.get("status", "")).strip().lower() == "in_progress"
            for t in self._current_tasks
        )

    def compute_required_tool_panel_lines(self) -> int:
        """计算显示所有 running tools 所需的最小行数。"""
        if not self._running_tools:
            return 0
        total_lines = 0
        for tool_call_id, state in self._running_tools.items():
            if state.is_task:
                total_lines += 1  # 主标题行
                # 嵌套工具（最多 3 个）
                total_lines += min(len(state.nested_tools), 3)
                # init 行（仅在创建后、首个有效子事件前显示）
                if state.show_init:
                    total_lines += 1
            else:
                total_lines += 1
        return total_lines

    def loading_state(self) -> LoadingState:
        """返回语义化的 loading 状态，用于 UI 层决定渲染策略。"""
        return self._loading_state

    def loading_line(self) -> str:
        """兼容旧接口，返回 loading 状态的文本内容。"""
        return self._loading_state.text

    def loading_aux_text(self) -> str:
        """spec §6.7 / §7.1：返回容器缓冲期 aux 文案，供 render_panels
        拼接到 spinner phrase。无容器时返回 ""。"""
        return self._loading_aux_text

    def append_subtitle(self, text: str) -> None:
        """Append a ⎿ subtitle entry, visually attached to the preceding entry."""
        normalized = text.strip()
        if not normalized:
            return
        self._append_history_entry(HistoryEntry(entry_type="file_ref", text=normalized))

    def append_system_message(
        self,
        content: str,
        *,
        severity: Literal["info", "warning", "error"] = "info",
    ) -> None:
        normalized = content.strip()
        if not normalized:
            return
        if self._should_drop_duplicate_system_message(
            content=normalized,
            severity=severity,
        ):
            return
        self._flush_assistant_segment()
        self._append_history_entry(
            HistoryEntry(entry_type="system", text=normalized, severity=severity)
        )

    @staticmethod
    def _team_event_key(
        *,
        agent_name: str,
        from_agent: str,
        to_agent: str | None,
        message_type: str,
        timestamp: str,
        content_preview: str,
    ) -> tuple[str, str, str, str, str, str]:
        return (
            str(agent_name or "").strip(),
            str(from_agent or "").strip(),
            str(to_agent or "").strip(),
            str(message_type or "").strip(),
            str(timestamp or "").strip(),
            str(content_preview or "").strip(),
        )

    def append_team_message_event(
        self,
        *,
        agent_name: str,
        from_agent: str,
        to_agent: str | None,
        message_type: str,
        content_preview: str,
        timestamp: str,
    ) -> bool:
        event_key = self._team_event_key(
            agent_name=agent_name,
            from_agent=from_agent,
            to_agent=to_agent,
            message_type=message_type,
            timestamp=timestamp,
            content_preview=content_preview,
        )
        if event_key in self._recent_team_event_keys:
            logger.debug(
                "[team-diag] renderer_dedupe "
                "agent=%r from=%r to=%r type=%r timestamp=%r preview=%r",
                agent_name,
                from_agent,
                to_agent,
                message_type,
                timestamp,
                content_preview,
            )
            return False

        self._recent_team_event_keys.append(event_key)
        target = to_agent or "[broadcast]"
        preview_str = f' "{content_preview}"' if content_preview else ""
        text = f"[team] {from_agent} {INJECTED_ARROW} {target}: ({message_type}){preview_str}"
        logger.debug(
            "[team-diag] renderer_append "
            "agent=%r from=%r to=%r type=%r timestamp=%r preview=%r history_len_before=%d",
            agent_name,
            from_agent,
            to_agent,
            message_type,
            timestamp,
            content_preview,
            len(self._history),
        )
        self.append_system_message(text)
        return True

    def append_elapsed_message(self, content: str) -> None:
        """追加一条灰色无前缀的计时统计行到 history scrollback."""
        normalized = content.strip()
        if not normalized:
            return
        self._flush_assistant_segment()
        self._append_history_entry(HistoryEntry(entry_type="elapsed", text=normalized))

    def append_assistant_message(self, content: str) -> None:
        normalized = content.strip()
        if not normalized:
            return
        self._flush_assistant_segment()
        self._append_history_entry(HistoryEntry(entry_type="assistant", text=normalized))

    def tool_panel_entries(
        self, *, max_lines: int | None = None
    ) -> list[tuple[int, str | list[tuple[str, str]]]]:
        """Return panel entries for running tools.

        Each entry is a tuple: (indent_level, content).
        content is either a plain str or a list of (style, text) prompt_toolkit fragments.
        indent_level == 0 means a primary tool line; >0 means nested status.
        indent_level < 0 means a meta line (no dot prefix).
        """
        limit = max_lines if max_lines is not None else self._tool_panel_max_lines
        normalized_limit = max(1, int(limit))
        if not self._running_tools:
            return []

        now = time.monotonic()
        entries: list[tuple[int, str]] = []
        tool_items = list(self._running_tools.items())
        for idx, (tool_call_id, state) in enumerate(tool_items):
            elapsed = _format_duration(now - state.started_at_monotonic)
            lines_to_add = 1
            if state.is_task:
                tokens_suffix = (
                    f" {BULLET_OPERATOR} {_format_tokens(state.progress_tokens)}"
                    if state.progress_tokens > 0
                    else ""
                )
                # 主标题行 + 嵌套工具（最多 3 个）+ 状态行（如果有状态）
                lines_to_add = 1 + min(len(state.nested_tools), 3)
                if state.show_init:
                    lines_to_add += 1
            else:
                lines_to_add = 1

            if len(entries) + lines_to_add > normalized_limit:
                remaining_tools = len(tool_items) - idx
                entries.append((-1, f"{ELLIPSIS} (+{remaining_tools})"))
                break

            if state.is_task:
                tokens_suffix = (
                    f" {BULLET_OPERATOR} {_format_tokens(state.progress_tokens)}"
                    if state.progress_tokens > 0
                    else ""
                )
                # 格式：SubagentName(描述) ∙ model(dim) ∙ elapsed ∙ tools ∙ tokens
                subagent_name = state.subagent_name or "Agent"
                description = state.subagent_description or state.title
                title = f"{subagent_name}({description})"
                tool_count = len(state.nested_tools)
                tool_count_suffix = f" {BULLET_OPERATOR} +{tool_count} tool uses" if tool_count > 0 else ""
                rest = f" {BULLET_OPERATOR} {elapsed}{tool_count_suffix}{tokens_suffix}"
                if state.subagent_model_name:
                    # Return styled fragments: model_name in dim
                    frags: list[tuple[str, str]] = [
                        ("", title),
                        ("class:dim", f" {BULLET_OPERATOR} {state.subagent_model_name}"),
                        ("", rest),
                    ]
                    entries.append((0, frags))
                else:
                    entries.append((0, f"{title}{rest}"))

                # 嵌套工具调用（最多显示最近 3 个）
                for child_id, child_tool in state.nested_tools[-3:]:
                    child_display = resolve_display_tool_name(child_tool.tool_name, {})
                    signature = _tool_signature(child_display, child_tool.args_summary)
                    if child_tool.status == "running":
                        entries.append((1, f"{BOTTOM_LEFT_CROP} {signature}"))
                    else:
                        icon = CHECK_MARK if child_tool.status == "completed" else CROSS_MARK
                        entries.append((1, f"{BOTTOM_LEFT_CROP} {icon} {signature}"))

                if state.show_init:
                    entries.append((1, f"{BOTTOM_LEFT_CROP} init"))
            else:
                display_name = state.display_tool_name or state.tool_name
                signature = _tool_signature(display_name, state.args_summary)
                entries.append((0, f"{signature} {BULLET_OPERATOR} {elapsed}"))

        return entries[:normalized_limit]

    def task_panel_lines(self, *, max_lines: int | None = None) -> list[str]:
        lines = self.full_task_panel_lines()
        if not lines:
            return []

        limit = max_lines if max_lines is not None else self._task_panel_max_lines
        normalized_limit = max(1, int(limit))
        if len(lines) <= normalized_limit:
            return lines

        clipped = lines[: normalized_limit - 1]
        clipped.append(f"{ELLIPSIS} (+{len(lines) - (normalized_limit - 1)})")
        return clipped

    def full_task_panel_lines(self) -> list[str]:
        tasks = list(self._current_tasks)
        if not tasks:
            return []

        header = str(self._current_task_title or "").strip()
        if not header:
            header = _task_stats_header(tasks)
        lines: list[str] = [header]
        for task in sorted(tasks, key=_task_sort_key):
            lines.append(_format_task_row(task))
        return lines

    def _flush_assistant_segment(self) -> None:
        if not self._assistant_buffer:
            return
        self._append_history_entry(
            HistoryEntry(entry_type="assistant", text=self._assistant_buffer)
        )
        self._assistant_buffer = ""

    def _append_assistant_text(self, text: str) -> None:
        self._assistant_buffer += text

    def _append_tool_call(self, tool_name: str, args: dict[str, Any], tool_call_id: str) -> None:
        self._running_tools[tool_call_id] = self._make_running_tool(tool_name, args)

    def _build_tool_subtitle(
        self, tool_name: str, result: str, metadata: dict[str, Any] | None = None,
        output: Any = None,
    ) -> str | None:
        """Build a subtitle string for tool result display.

        Returns None for tools that don't need a subtitle line.
        """
        import re

        lowered = tool_name.lower()

        # ── typed output 优先路径 ──
        if output is not None:
            try:
                from comate_agent_sdk.tool_schemas.write import WriteOutput
                from comate_agent_sdk.tool_schemas.read import ReadOutput
                from comate_agent_sdk.tool_schemas.bash import BashOutput
                from comate_agent_sdk.tool_schemas.search import GlobOutput, GrepOutput, LSOutput

                if lowered == "write" and isinstance(output, WriteOutput):
                    return f"Write {output.lines_written} lines"

                if lowered == "read" and isinstance(output, ReadOutput):
                    return f"Read {output.lines_returned} lines of {output.total_lines}"

                if lowered == "bash" and isinstance(output, BashOutput):
                    return f"Exit code {output.exit_code}"

                if lowered in ("glob", "ls") and isinstance(output, (GlobOutput, LSOutput)):
                    if isinstance(output, GlobOutput) and output.count_is_lower_bound:
                        return f"Found at least {output.count} files"
                    return f"Found {output.count} files"

                if lowered == "grep" and isinstance(output, GrepOutput):
                    if output.files is not None:
                        if output.total_matches_is_lower_bound:
                            return f"Found matches in at least {output.total_matches} files"
                        return f"Found matches in {output.total_matches} files"
                    if output.total_matches_is_lower_bound:
                        return f"Found at least {output.total_matches} matches"
                    return f"Found {output.total_matches} matches"
            except ImportError:
                pass  # SDK not available, fall through to legacy

        if lowered == "skill":
            return "Successfully loaded skill"

        if lowered == "read":
            if isinstance(metadata, dict):
                lines_returned = metadata.get("lines_returned")
                start_line = metadata.get("start_line")
                end_line = metadata.get("end_line")
                total_lines = metadata.get("total_lines")
                if (
                    isinstance(lines_returned, int)
                    and lines_returned >= 0
                    and isinstance(start_line, int)
                    and start_line >= 0
                    and isinstance(end_line, int)
                    and end_line >= 0
                    and isinstance(total_lines, int)
                    and total_lines >= 0
                ):
                    return f"Read {lines_returned} lines {BULLET_OPERATOR} Lines {start_line}-{end_line} of {total_lines}"
            lines = result.split("\n") if result else []
            if lines and lines[-1] == "":
                lines = lines[:-1]
            return f"Read {len(lines)} lines"

        if lowered == "write":
            lines = result.split("\n") if result else []
            if lines and lines[-1] == "":
                lines = lines[:-1]
            return f"Write {len(lines)} lines"

        if lowered in ("edit", "multiedit"):
            if not metadata:
                return None
            diff_lines = metadata.get("diff")
            if not isinstance(diff_lines, list) or not diff_lines:
                return None
            added = sum(1 for line in diff_lines if line.startswith("+") and not line.startswith("+++"))
            removed = sum(1 for line in diff_lines if line.startswith("-") and not line.startswith("---"))
            parts = []
            if added:
                a_unit = "line" if added == 1 else "lines"
                parts.append(f"Added {added} {a_unit}")
            if removed:
                r_unit = "line" if removed == 1 else "lines"
                prefix = "Removed" if not parts else "removed"
                parts.append(f"{prefix} {removed} {r_unit}")
            if not parts:
                return "No changes"
            return ", ".join(parts)

        if lowered == "bash":
            match = re.search(r"Exit code (\d+)", result or "")
            if match:
                return f"Exit code {match.group(1)}"
            return "Completed"

        if lowered in ("glob", "ls"):
            lines = [line for line in (result or "").splitlines() if line.strip()]
            return f"Found {len(lines)} files"

        if lowered == "grep":
            lines = [line for line in (result or "").splitlines() if line.strip()]
            if not lines:
                return "Found matches"

            count_summary = re.search(
                r"^Found\s+(at least\s+)?(\d+)\s+total occurrences across\s+(\d+)\s+(file|files)\.",
                result or "",
                re.MULTILINE,
            )
            if count_summary:
                qualifier = count_summary.group(1) or ""
                occurrences = count_summary.group(2)
                file_count = count_summary.group(3)
                file_word = count_summary.group(4)
                return f"Found {qualifier}{occurrences} matches across {file_count} {file_word}"

            if lines[0] == "No matches found":
                return "Found 0 matches"

            if lines[0] == "No files found":
                return "Found matches in 0 files"

            file_summary = re.match(r"^Found\s+(at least\s+)?(\d+)\s+files?\b", lines[0])
            if file_summary:
                qualifier = file_summary.group(1) or ""
                return f"Found matches in {qualifier}{file_summary.group(2)} files"

            if all(
                not re.search(r":\d+(?::|$)", line)
                for line in lines
            ):
                return f"Found matches in {len(lines)} files"

            return "Found matches"

        return None

    def append_static_tool_result(
        self,
        signature: str,
        is_error: bool = False,
        diff_lines: list[str] | None = None,
        model_name: str = "",
        subtitle: str | None = None,
    ) -> None:
        """Append a tool result to history as a static entry (no timer).

        Args:
            signature: 工具签名，例如 "Read(path=xxx)"
            is_error: 是否为错误结果
            diff_lines: optional diff lines for Edit
            model_name: model name for Agent tools (rendered dim)
            subtitle: optional subtitle rendered as `⎿ ...`
        """
        sev: Literal["info", "warning", "error"] = "error" if is_error else "info"
        if not is_error and diff_lines and len(diff_lines) > 0:
            self._latest_diff_lines = diff_lines
            text_obj = Text(signature)
            if model_name:
                text_obj.append(f" {BULLET_OPERATOR} {model_name}", style="dim")
            text_obj.append("\n")
            text_obj.append(self._render_diff_text(diff_lines, max_lines=self._diff_max_lines))
            self._append_history_entry(
                HistoryEntry(entry_type="tool_result", text=text_obj, severity="info", subtitle=subtitle)
            )
            return
        if model_name:
            text_obj = Text(signature)
            text_obj.append(f" {BULLET_OPERATOR} {model_name}", style="dim")
            self._append_history_entry(
                HistoryEntry(entry_type="tool_result", text=text_obj, severity=sev, subtitle=subtitle)
            )
            return
        self._append_history_entry(
            HistoryEntry(
                entry_type="tool_result",
                text=signature,
                severity=sev,
                subtitle=subtitle,
            )
        )

    def _make_running_tool(self, tool_name: str, args: dict[str, Any]) -> _RunningTool:
        """Create a _RunningTool from tool name and args dict."""
        title = tool_name
        is_task = tool_name.lower() == "agent"
        summary = summarize_tool_args(tool_name, args, self._project_root).strip()
        display_name = resolve_display_tool_name(tool_name, args)
        subagent_name = ""
        subagent_description = ""
        if is_task:
            title = _extract_task_title(args)
            summary = ""
            subagent_name = str(args.get("subagent_type", "")).strip() or "Agent"
            subagent_description = str(args.get("description", "")).strip()

        return _RunningTool(
            tool_name=tool_name,
            display_tool_name=display_name,
            title=title,
            started_at_monotonic=time.monotonic(),
            is_task=is_task,
            args_summary=summary,
            show_init=is_task,
            subagent_name=subagent_name,
            subagent_description=subagent_description,
        )

    def _append_tool_result(
        self,
        tool_name: str,
        tool_call_id: str,
        is_error: bool,
        result: Any,
        metadata: dict[str, Any] | None = None,
        output: Any = None,
    ) -> None:
        sev: Literal["info", "warning", "error"] = "error" if is_error else "info"
        if is_error:
            subtitle = _truncate(_one_line(result), self._tool_error_summary_max_len)
        else:
            subtitle = self._build_tool_subtitle(tool_name, str(result), metadata, output)
        state = self._running_tools.pop(tool_call_id, None)
        if state is None:
            display_name = resolve_display_tool_name(tool_name, {})
            signature = _tool_signature(display_name, "")
            self._append_history_entry(
                HistoryEntry(entry_type="tool_result", text=signature, severity=sev, subtitle=subtitle)
            )
            return

        if state.is_task:
            subagent_name = state.subagent_name or "Agent"
            description = state.subagent_description or state.title
            if description and description != subagent_name:
                task_title = f"{subagent_name}({description})"
            else:
                task_title = subagent_name

            model_name = ""
            if metadata and isinstance(metadata, dict):
                model_name = metadata.get("model_name", "")

            tool_count = len(state.nested_tools)
            base = Text(task_title)
            if model_name:
                base.append(f" {BULLET_OPERATOR} {model_name}", style="dim")
            if tool_count > 0:
                base.append(f" {BULLET_OPERATOR} +{tool_count} tool uses")
            if state.progress_tokens > 0:
                base.append(f" {BULLET_OPERATOR} {_format_tokens(state.progress_tokens)}")
        else:
            display_name = state.display_tool_name or state.tool_name
            summary = state.args_summary
            # Append line range for Edit
            if display_name == "Update" and metadata:
                sl = metadata.get("start_line")
                el = metadata.get("end_line")
                if isinstance(sl, int) and sl > 0:
                    line_suffix = f":L{sl}-L{el}" if isinstance(el, int) and el > sl else f":L{sl}"
                    summary = f"{summary}{line_suffix}" if summary else line_suffix
            signature = _tool_signature(display_name, summary)
            base = f"{signature}"

        # Render diff for Edit if metadata contains diff lines
        if not is_error and metadata:
            diff_lines = metadata.get("diff")
            if isinstance(diff_lines, list) and len(diff_lines) > 0:
                self._latest_diff_lines = diff_lines
                if isinstance(base, Text):
                    text_obj = base
                else:
                    text_obj = Text(base)
                text_obj.append("\n")
                text_obj.append(self._render_diff_text(diff_lines, max_lines=self._diff_max_lines))
                self._append_history_entry(
                    HistoryEntry(entry_type="tool_result", text=text_obj, severity="info", subtitle=subtitle)
                )
                return

        if isinstance(base, Text):
            self._append_history_entry(
                HistoryEntry(entry_type="tool_result", text=base, severity=sev, subtitle=subtitle)
            )
        else:
            self._append_history_entry(
                HistoryEntry(entry_type="tool_result", text=base, severity=sev, subtitle=subtitle)
            )

    @staticmethod
    def _render_diff_text(diff_lines: list[str], max_lines: int = 50) -> Text:
        """Render diff lines as colored Rich Text with line numbers."""
        import re
        import shutil

        result = Text()
        visible_lines = [
            line for line in diff_lines if not (line.startswith("---") or line.startswith("+++"))
        ]
        total_lines = len(visible_lines)
        displayed_lines = visible_lines[:max_lines] if max_lines > 0 else visible_lines

        # Get terminal width for padding
        try:
            terminal_width = shutil.get_terminal_size().columns
        except Exception:
            terminal_width = 120

        old_line = 0
        new_line = 0
        hunk_pattern = re.compile(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@")

        for line in displayed_lines:
            m = hunk_pattern.match(line)
            if m:
                old_line = int(m.group(1))
                new_line = int(m.group(2))
                result.append(line, style="cyan")
                result.append("\n")
                continue

            if line.startswith("-"):
                result.append(f"{old_line:>4} ", style="#ffffff on #4a0202")
                result.append(line, style="#ffffff on #4a0202")
                # Calculate padding to fill the entire line
                content_width = 5 + len(line)  # line number (4) + space (1) + content
                padding = max(0, terminal_width - content_width)
                result.append(" " * padding, style="#ffffff on #4a0202")
                result.append("\n")
                old_line += 1
            elif line.startswith("+"):
                result.append(f"{new_line:>4} ", style="#c6c6c6 on #2e502e")
                result.append(line, style="#ffffff on #2e502e")
                # Calculate padding to fill the entire line
                content_width = 5 + len(line)  # line number (4) + space (1) + content
                padding = max(0, terminal_width - content_width)
                result.append(" " * padding, style="#ffffff on #2e502e")
                result.append("\n")
                new_line += 1
            else:
                result.append(f"{new_line:>4} ", style="dim")
                result.append(line, style="dim")
                result.append("\n")
                old_line += 1
                new_line += 1

        if max_lines > 0 and total_lines > max_lines:
            result.append(
                f"... ({total_lines - max_lines} more lines, Ctrl+O to expand)",
                style="dim italic",
            )

        return result

    def _rebuild_loading_line(self) -> None:
        self._loading_state = LoadingState.idle()

    def _append_questions(self, questions: list[dict[str, Any]]) -> None:
        if not questions:
            return
        self._append_history_entry(
            HistoryEntry(
                entry_type="tool_result",
                text=f"Input required: {len(questions)} question(s) pending.",
            )
        )
        for idx, question in enumerate(questions, 1):
            question_text = str(question.get("question", "")).strip()
            header = str(question.get("header", f"Question {idx}")).strip()
            options = question.get("options", [])
            labels: list[str] = []
            if isinstance(options, list):
                for option in options[:3]:
                    if not isinstance(option, dict):
                        continue
                    label = str(option.get("label", "")).strip()
                    if label:
                        labels.append(label)
            choice_preview = f" (Options: {' / '.join(labels)})" if labels else ""
            self._append_history_entry(
                HistoryEntry(
                    entry_type="tool_result",
                    text=f"  {idx}. {header}: {question_text} {choice_preview}".strip(),
                )
            )

    def _update_tasks(self, tasks: list[dict[str, Any]], *, list_id: str) -> None:
        """更新当前共享任务列表状态。"""
        normalized = list(tasks) if tasks else []
        if not normalized:
            self._current_tasks = []
            self._current_task_title = None
            self._task_started_at_monotonic = None
            return

        all_completed = all(str(item.get("status", "")).strip().lower() == "completed" for item in normalized)
        # 标题：显示 ID 最小的 in_progress task 的 subject，否则统计摘要
        in_progress_tasks = [
            t for t in normalized
            if str(t.get("status", "")).strip().lower() == "in_progress"
        ]
        if in_progress_tasks:
            in_progress_tasks.sort(key=lambda t: int(t.get("id", 0)))
            header = str(in_progress_tasks[0].get("subject", "")).strip() or "Tasks"
        else:
            header = _task_stats_header(normalized)
        if not all_completed:
            if not self._current_tasks:
                self._task_started_at_monotonic = time.monotonic()
            self._current_task_title = header
            self._current_tasks = normalized
            return

        # All completed: hide panel and write a summary entry once.
        # 守卫：_current_tasks 已空说明完成总结已写过，跳过重复写入
        if not self._current_tasks:
            return
        started = self._task_started_at_monotonic
        elapsed_suffix = ""
        if started is not None:
            elapsed_suffix = f" {BULLET_OPERATOR} {_format_duration(time.monotonic() - started)}"
        total = len(normalized)
        self._append_history_entry(
            HistoryEntry(
                entry_type="tool_result",
                text=f"tasks {total}/{total} completed{elapsed_suffix}",
                severity="info",
            )
        )
        self._current_tasks = []
        self._current_task_title = None
        self._task_started_at_monotonic = None

    def task_renderable(self) -> RenderableType | None:
        """将当前任务工作集渲染为 Rich 组件。

        Returns:
            Rich RenderableType 或 None（如果没有 task）
        """
        if not self._current_tasks:
            return None

        tasks = list(sorted(self._current_tasks, key=_task_sort_key))
        total = len(tasks)
        completed = sum(1 for task in tasks if task.get("status") == "completed")

        # 构建 Rich Text 组件
        result = Text()

        # 标题
        result.append(f"{self._current_task_title or 'Tasks'} ({completed}/{total} completed)\n")

        for task in tasks:
            line = _format_task_row(task)
            if line.startswith(f"{CHECK_MARK} "):
                result.append(f"  {CHECK_MARK} ")
                result.append(line[2:], style="green strike")
            elif line.startswith(f"{TASK_IN_PROGRESS} "):
                result.append(f"  {TASK_IN_PROGRESS} ")
                result.append(line[2:], style="#F97316")
            elif line.startswith(f"{TASK_BLOCKED} "):
                # blocked pending: display as TASK_PENDING glyph + dim
                result.append(f"  {TASK_PENDING} ")
                result.append(line[2:], style="dim")
            elif line.startswith(f"{TASK_PENDING} "):
                result.append(f"  {TASK_PENDING} ")
                result.append(line[2:])
            else:
                result.append(f"  {line}")
            result.append("\n")

        # 移除末尾的换行
        if result.plain.endswith("\n"):
            result = result[:-1]

        return result

    def task_lines(self) -> list[str]:
        """返回当前任务面板行列表（用于测试）。"""
        return self.task_panel_lines(max_lines=6)

    def todo_panel_lines(self, *, max_lines: int | None = None) -> list[str]:
        return self.task_panel_lines(max_lines=max_lines)

    def todo_all_lines(self) -> list[str]:
        return self.full_task_panel_lines()

    def todo_renderable(self) -> RenderableType | None:
        return self.task_renderable()

    def todo_lines(self) -> list[str]:
        return self.task_lines()

    def handle_event(self, event: Any) -> tuple[bool, list[dict[str, Any]] | None]:
        if not isinstance(
            event,
            (TextEvent, TextDeltaEvent, ThinkingDeltaEvent, ToolCallStartEvent),
        ):
            self._flush_assistant_segment()

        match event:
            case SessionInitEvent(session_id=_):
                pass
            case TextDeltaEvent(delta=delta, message_id=_):
                if delta:
                    # spec §6.1：text delta → 累到 _text_pending → 按 \n 切完整行入队
                    self._consume_text_delta(delta)
                    self._turn_received_text_delta = True
            case ThinkingDeltaEvent(delta=delta, message_id=_):
                if delta:
                    # spec §6.1：thinking delta → 按 \n 切完整行入队，残段留 batch
                    self._turn_received_thinking_delta = True
                    self._consume_thinking_delta(delta)
            case ToolCallStartEvent(tool_call_id=tool_call_id, tool=tool_name):
                # tool 调用前先把 _text_pending / _thinking_batch 落到 scrollback，
                # 保证说明文字出现在 tool UI 之前（无 \n 结尾的模型也适用）。
                self._force_flush_all()
                normalized_id = str(tool_call_id or "").strip()
                if normalized_id and normalized_id not in self._pending_tool_starts:
                    self._pending_tool_starts.add(normalized_id)
            case ThinkingEvent(content=thinking):
                if self._turn_received_thinking_delta:
                    pass
                elif self._show_thinking_cb():
                    self._append_history_entry(
                        HistoryEntry(entry_type="thinking", text=thinking)
                    )
            case CompactionResultEvent(
                current_tokens=tokens,
                threshold=threshold,
                trigger=trigger,
                attempted=attempted,
                compacted=compacted,
                reason=reason,
                tokens_before=tokens_before,
                tokens_after=tokens_after,
            ):
                pct = int(tokens / threshold * 100) if threshold > 0 else 0
                if compacted:
                    self.append_system_message(
                        (
                            f"Context compaction completed ({trigger}): "
                            f"{tokens_before:,} {INJECTED_ARROW} {tokens_after:,} tokens "
                            f"(check {tokens:,}/{threshold:,}, {pct}%)"
                        ),
                        severity="info",
                    )
                elif attempted:
                    self.append_system_message(
                        (
                            f"Context compaction attempt failed ({trigger}): "
                            f"kept {tokens_after:,} tokens "
                            f"(check {tokens:,}/{threshold:,}, {pct}%, reason={reason})"
                        ),
                        severity="warning",
                    )
                else:
                    self.append_system_message(
                        (
                            f"Context compaction skipped ({trigger}): "
                            f"{tokens:,}/{threshold:,} tokens ({pct}%), reason={reason}"
                        ),
                        severity="warning",
                    )
            case ToolCallEvent(tool=tool_name, args=arguments, tool_call_id=tool_call_id):
                args_dict = arguments if isinstance(arguments, dict) else {"_raw": str(arguments)}
                # Store args for ToolResult phase lookup.
                self._tool_call_args[tool_call_id] = args_dict
                if not should_show_tool_in_scrollback(tool_name, args_dict):
                    self._rebuild_loading_line()
                    return (False, None)
                self._append_tool_call(tool_name, args_dict, tool_call_id)
            case ToolResultEvent(tool=tool_name, result=result, tool_call_id=tool_call_id, is_error=is_error, metadata=metadata, output=output):
                stored_args = self._tool_call_args.pop(tool_call_id, {})
                if not should_show_tool_in_scrollback(tool_name, stored_args, is_result=True, is_error=is_error):
                    self._running_tools.pop(tool_call_id, None)
                    self._rebuild_loading_line()
                    return (False, None)
                self._append_tool_result(
                    tool_name=tool_name,
                    tool_call_id=tool_call_id,
                    is_error=is_error,
                    result=result,
                    metadata=metadata,
                    output=output,
                )
            case UsageDeltaEvent(
                source=_,
                model=_,
                level=_,
                delta_prompt_tokens=_,
                delta_prompt_cached_tokens=_,
                delta_completion_tokens=_,
                delta_total_tokens=_,
            ):
                pass
            case SubagentStartEvent(tool_call_id=_, subagent_name=_, description=_):
                pass
            case SubagentProgressEvent(
                tool_call_id=tool_call_id,
                subagent_name=subagent_name,
                description=description,
                status=status,
                elapsed_ms=elapsed_ms,
                tokens=tokens,
                model_name=model_name,
            ):
                state = self._running_tools.get(tool_call_id)
                if state is not None:
                    if tokens is not None:
                        state.progress_tokens = max(int(tokens), 0)
                    if elapsed_ms is not None:
                        normalized = max(float(elapsed_ms), 0.0)
                        state.started_at_monotonic = time.monotonic() - (normalized / 1000)
                    # Subagent-specific status for task tool panel.
                    state.subagent_name = str(subagent_name or "").strip()
                    state.subagent_status = str(status or "").strip()
                    state.subagent_description = str(description or "").strip()
                    if model_name:
                        state.subagent_model_name = str(model_name)
                    # 首个有效子事件后移除 init 占位。
                    progress_status = str(status or "").strip().lower()
                    has_activity = bool(tokens and int(tokens) > 0) or bool(
                        elapsed_ms and float(elapsed_ms) > 0.0
                    )
                    if has_activity or progress_status in {"completed", "error", "timeout", "cancelled"}:
                        state.show_init = False
            case SubagentStopEvent(tool_call_id=_, subagent_name=_, status=_, duration_ms=_, error=_):
                pass
            case SubagentToolCallEvent(
                parent_tool_call_id=parent_tool_call_id,
                subagent_name=_,
                tool=tool,
                args=args,
                tool_call_id=tool_call_id,
            ):
                # 将嵌套工具调用添加到父 Agent 的 nested_tools
                parent_state = self._running_tools.get(parent_tool_call_id)
                if parent_state is not None:
                    args_summary = summarize_tool_args(tool, args, self._project_root).strip()
                    nested_tool = _SubagentTool(
                        tool_name=tool,
                        args_summary=args_summary,
                        started_at_monotonic=time.monotonic(),
                        status="running",
                    )
                    parent_state.nested_tools.append((tool_call_id, nested_tool))
                    parent_state.show_init = False
            case SubagentToolResultEvent(
                parent_tool_call_id=parent_tool_call_id,
                subagent_name=_,
                tool=_,
                tool_call_id=tool_call_id,
                is_error=is_error,
                duration_ms=duration_ms,
            ):
                # 更新嵌套工具的状态
                parent_state = self._running_tools.get(parent_tool_call_id)
                if parent_state is not None:
                    for nested_id, nested_tool in parent_state.nested_tools:
                        if nested_id == tool_call_id:
                            nested_tool.status = "error" if is_error else "completed"
                            nested_tool.duration_ms = duration_ms
                            parent_state.show_init = False
                            break
            case TaskUpdatedEvent(list_id=list_id, tasks=tasks):
                self._update_tasks(tasks, list_id=list_id)
            case UserQuestionEvent(questions=questions, tool_call_id=_):
                self._append_questions(questions)
                self._rebuild_loading_line()
                return (True, questions)
            case TextEvent(content=text):
                if self._turn_received_text_delta:
                    pass
                elif text:
                    self._append_assistant_text(text)
            case StepCompleteEvent(step_id=step_id, status=_, duration_ms=_):
                # Cancellation/error paths may emit StepCompleteEvent without ToolResultEvent.
                # Ensure tool panel state is cleaned up by step id.
                self._running_tools.pop(step_id, None)
            case StopEvent(reason=reason):
                self._flush_assistant_segment()
                self._pending_tool_starts.clear()
                # Safety net: if any running tool rows remain, stop event means this turn is ending.
                self._running_tools.clear()
                self._rebuild_loading_line()
                if reason == "waiting_for_input":
                    return (True, None)
                if reason == "waiting_for_plan_approval":
                    return (False, None)
                if reason == "interrupted" and "error" not in event.metadata:
                    self._append_history_entry(
                        HistoryEntry(entry_type="system", text="Current task interrupted.", severity="warning")
                    )
            case PlanApprovalRequiredEvent(
                plan_path=plan_path,
                summary=summary,
                execution_prompt=_,
                plan_markdown=plan_markdown,
            ):
                # 在 scrollback 渲染计划内容，让用户审阅后再决策。
                # 优先使用事件携带正文，避免依赖本地二次读文件。
                plan_content = str(plan_markdown or "")
                if not plan_content:
                    try:
                        plan_content = Path(plan_path).read_text(encoding="utf-8")
                    except Exception:
                        logger.warning("ExitPlanMode: Failed to read plan file %s", plan_path)
                if plan_content:
                    self._append_history_entry(
                        HistoryEntry(
                            entry_type="system",
                            text=f"{HEAVY_HORIZONTAL * 3} Here is the plan, please review and approve or reject {HEAVY_HORIZONTAL * 3}",
                        )
                    )
                    self._append_history_entry(HistoryEntry(entry_type="assistant", text=plan_content))

                text = f"Plan ready for review: {plan_path}"
                if summary:
                    text = f"{text} | {summary}"
                self._append_history_entry(
                    HistoryEntry(entry_type="system", text=text)
                )
            case TeamMessageEvent(
                agent_name=agent_name,
                from_agent=from_agent,
                to_agent=to_agent,
                message_type=message_type,
                content_preview=content_preview,
                timestamp=timestamp,
            ):
                self.append_team_message_event(
                    agent_name=agent_name,
                    from_agent=from_agent,
                    to_agent=to_agent,
                    message_type=message_type,
                    content_preview=content_preview,
                    timestamp=timestamp,
                )
            case _:
                logger.debug("Unhandled event type: %s", type(event).__name__)

        self._rebuild_loading_line()
        return (False, None)
