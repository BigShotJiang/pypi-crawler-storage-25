"""Unified error formatter for terminal agent."""
from __future__ import annotations

import re


def format_error(exc: Exception) -> tuple[str, str, str]:
    """Convert exception to user-friendly (message, transient_summary, severity).

    - message: full error text for scrollback (plain English, no icons)
    - transient_summary: short text for status bar transient notification
    - severity: "error" or "warning"
    """
    exc_type = type(exc).__name__
    exc_msg = str(exc)

    # LLM Provider errors
    if exc_type == "ModelRateLimitError":
        return "Rate limit exceeded", "Rate limited", "warning"

    if exc_type == "ModelProviderError":
        code = getattr(exc, "status_code", None)

        # Context size exceeded (400 with specific body pattern)
        if code == 400:
            ctx = _parse_context_size_error(exc_msg)
            if ctx:
                return (
                    f"Request ({ctx[0]} tokens) exceeds context limit ({ctx[1]})",
                    "Context limit exceeded",
                    "error",
                )
            return f"API error: {_truncate(exc_msg, 80)}", "API error", "error"

        if code == 401:
            return "Invalid or expired API key", "Auth failed", "error"
        if code == 403:
            return "Access denied to this model", "Access denied", "error"
        if code == 404:
            return "Model not found or invalid API path", "Model not found", "error"
        if code and code >= 500:
            return f"Server error ({code})", "Server error", "warning"
        return f"API error: {_truncate(exc_msg, 80)}", "API error", "error"

    # Session errors
    if exc_type == "ChatSessionClosedError":
        return "Session closed", "Session closed", "error"

    # Network errors (heuristic)
    lower_msg = exc_msg.lower()
    if "timeout" in lower_msg or "timed out" in lower_msg:
        return "Request timed out", "Timed out", "warning"
    if "connection" in lower_msg:
        return "Connection failed", "Connection failed", "error"

    # Generic fallback
    return f"Error: {_truncate(exc_msg, 80)}", "Error occurred", "error"


def _parse_context_size_error(msg: str) -> tuple[str, str] | None:
    """Extract (prompt_tokens, ctx_limit) from context size error body.

    Matches patterns like 'n_prompt_tokens': 35099, 'n_ctx': 32768
    or 'request (35099 tokens) exceeds the available context size (32768 tokens)'.
    """
    m = re.search(r"n_prompt_tokens['\"]?:\s*(\d+)", msg)
    n = re.search(r"n_ctx['\"]?:\s*(\d+)", msg)
    if m and n:
        return m.group(1), n.group(1)

    m2 = re.search(r"request\s*\((\d+)\s*tokens?\)", msg, re.IGNORECASE)
    n2 = re.search(r"context\s*size\s*\((\d+)\s*tokens?\)", msg, re.IGNORECASE)
    if m2 and n2:
        return m2.group(1), n2.group(1)

    if "exceed_context_size_error" in msg:
        return None  # Type matches but can't parse numbers — fall through to generic 400

    return None


def _truncate(s: str, max_len: int) -> str:
    return s[:max_len] + "..." if len(s) > max_len else s
