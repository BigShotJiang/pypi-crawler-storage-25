"""Plugin picker 标签栏组件。

纯状态 + formatted text 渲染，不依赖 prompt_toolkit Application 即可测试。
"""

from __future__ import annotations


class TabBar:
    """标签栏：支持左右切换、badge 计数显示。

    渲染为 prompt_toolkit style tuples，由上层 layout 消费。
    """

    def __init__(
        self,
        tabs: list[str],
        badge_counts: dict[str, int] | None = None,
    ) -> None:
        self._tabs = list(tabs)
        self._badge_counts = dict(badge_counts) if badge_counts else {}
        self._active_tab = 0

    @property
    def active_tab(self) -> int:
        return self._active_tab

    @active_tab.setter
    def active_tab(self, value: int) -> None:
        if self._tabs:
            self._active_tab = value % len(self._tabs)

    @property
    def active_tab_name(self) -> str:
        if not self._tabs:
            return ""
        return self._tabs[self._active_tab]

    def next_tab(self) -> None:
        """切换到下一个标签（循环）。"""
        if self._tabs:
            self._active_tab = (self._active_tab + 1) % len(self._tabs)

    def prev_tab(self) -> None:
        """切换到上一个标签（循环）。"""
        if self._tabs:
            self._active_tab = (self._active_tab - 1) % len(self._tabs)

    def set_badge(self, tab_name: str, count: int) -> None:
        """设置指定标签的 badge 计数。"""
        if count > 0:
            self._badge_counts[tab_name] = count
        else:
            self._badge_counts.pop(tab_name, None)

    def get_formatted_text(self) -> list[tuple[str, str]]:
        """返回 prompt_toolkit style tuples。

        - 活跃标签：bold underline 样式
        - 非活跃标签：默认样式
        - Badge：class:error 样式，显示为 (N)
        - 前缀：'Plugins  '，标签间用 '   ' 分隔
        """
        if not self._tabs:
            return [("", "Plugins")]

        fragments: list[tuple[str, str]] = [("bold", "Plugins  ")]

        for idx, tab_name in enumerate(self._tabs):
            if idx > 0:
                fragments.append(("", "   "))

            if idx == self._active_tab:
                style = "bold underline"
            else:
                style = ""

            fragments.append((style, tab_name))

            badge = self._badge_counts.get(tab_name, 0)
            if badge > 0:
                fragments.append(("class:error", f" ({badge})"))

        return fragments
