"""Plugin picker 详情视图组件。

纯状态 + formatted text 渲染，显示插件详细信息和操作菜单。
"""

from __future__ import annotations


class DetailView:
    """插件详情视图：显示名称、来源、版本、描述、信任警告、操作列表。

    渲染为 prompt_toolkit style tuples，由上层 layout 消费。
    """

    def __init__(
        self,
        plugin_info: dict | None = None,
        actions: list[str] | None = None,
    ) -> None:
        self._plugin_info: dict = plugin_info or {}
        self._actions: list[str] = actions or ["Install for user", "Install for project", "Back"]
        self._selected_action = 0

    @property
    def plugin_info(self) -> dict:
        return self._plugin_info

    @plugin_info.setter
    def plugin_info(self, value: dict) -> None:
        self._plugin_info = value or {}
        self._selected_action = 0

    @property
    def actions(self) -> list[str]:
        return self._actions

    @actions.setter
    def actions(self, value: list[str]) -> None:
        self._actions = value or []
        self._selected_action = 0

    @property
    def selected_action(self) -> int:
        return self._selected_action

    def move_up(self) -> None:
        """向上移动操作选择。"""
        if self._actions:
            self._selected_action = (self._selected_action - 1) % len(self._actions)

    def move_down(self) -> None:
        """向下移动操作选择。"""
        if self._actions:
            self._selected_action = (self._selected_action + 1) % len(self._actions)

    def get_selected_action(self) -> str | None:
        """返回当前选中的操作名。"""
        if not self._actions:
            return None
        return self._actions[self._selected_action]

    def get_formatted_text(self) -> list[tuple[str, str]]:
        """返回 prompt_toolkit style tuples。

        布局：
        - 名称（bold）
        - 来源 / 版本
        - 描述
        - 信任警告（如适用）
        - 操作列表
        """
        if not self._plugin_info:
            return [("class:detail.empty", "  Select a plugin to view details")]

        fragments: list[tuple[str, str]] = []
        info = self._plugin_info

        # 名称
        name = info.get("name", "unknown")
        fragments.append(("bold", f"  {name}"))
        fragments.append(("", "\n"))

        # 来源
        source = info.get("source", "")
        if source:
            fragments.append(("class:detail.meta", f"  Source: {source}"))
            fragments.append(("", "\n"))

        # 版本
        version = info.get("version", "")
        if version:
            fragments.append(("class:detail.meta", f"  Version: {version}"))
            fragments.append(("", "\n"))

        # 描述
        description = info.get("description", "")
        if description:
            fragments.append(("", "\n"))
            fragments.append(("class:detail.description", f"  {description}"))
            fragments.append(("", "\n"))

        # 信任警告
        trusted = info.get("trusted", True)
        if not trusted:
            fragments.append(("", "\n"))
            fragments.append(
                ("class:detail.warning", "  Warning: This plugin is from an untrusted source.")
            )
            fragments.append(("", "\n"))

        # 操作列表
        if self._actions:
            fragments.append(("", "\n"))
            fragments.append(("bold", "  Actions:"))
            fragments.append(("", "\n"))
            for idx, action in enumerate(self._actions):
                is_selected = idx == self._selected_action
                cursor = ">" if is_selected else " "
                style = "bold" if is_selected else ""
                fragments.append((style, f"  {cursor} {action}"))
                fragments.append(("", "\n"))

        return fragments
