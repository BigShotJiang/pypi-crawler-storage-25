"""Plugin picker 搜索框组件。

封装 prompt_toolkit TextArea，提供实时过滤回调。
"""

from __future__ import annotations

from typing import Callable

from prompt_toolkit.widgets import TextArea


class SearchBox:
    """搜索框：单行输入，支持实时过滤回调。"""

    def __init__(
        self,
        on_change: Callable[[str], None] | None = None,
        placeholder: str = "Search plugins...",
    ) -> None:
        self._on_change = on_change
        self._text_area = TextArea(
            height=1,
            multiline=False,
            prompt=[("class:plugin-search-icon", "🔍 ")],
            style="class:plugin-search-input",
            dont_extend_height=True,
        )
        self._text_area.buffer.on_text_changed += self._handle_change

    @property
    def text(self) -> str:
        return self._text_area.text

    @text.setter
    def text(self, value: str) -> None:
        self._text_area.text = value

    @property
    def text_area(self) -> TextArea:
        """返回底层 TextArea，供 layout 使用。"""
        return self._text_area

    def clear(self) -> None:
        """清空搜索框。"""
        self._text_area.text = ""

    def _handle_change(self, _buffer: object) -> None:
        if self._on_change:
            self._on_change(self._text_area.text)
