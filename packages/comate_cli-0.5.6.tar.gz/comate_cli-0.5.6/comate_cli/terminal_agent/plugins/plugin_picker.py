"""Plugin picker 入口与参数解析。

PluginPickerContext 保存 /plugin 子命令解析结果。
PluginPickerUI 是嵌入式 TUI 组件，供主 TUI ConditionalContainer 使用。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from prompt_toolkit.application.current import get_app_or_none
from prompt_toolkit.document import Document
from prompt_toolkit.filters import Condition
from prompt_toolkit.layout.containers import ConditionalContainer, HSplit, Window
from prompt_toolkit.layout.controls import FormattedTextControl
from prompt_toolkit.layout.processors import Processor, Transformation, TransformationInput
from prompt_toolkit.widgets import Frame, TextArea

from comate_agent_sdk.plugins import (
    MarketplaceManager,
    PluginLoader,
    PluginManager,
    PluginRegistry,
)

logger = logging.getLogger(__name__)


class _PlaceholderProcessor(Processor):
    """Buffer 为空时在 TextArea 内显示灰色占位文字。占位符不能含换行符。"""

    def __init__(self, placeholder: str) -> None:
        self._placeholder = placeholder

    def apply_transformation(self, ti: TransformationInput) -> Transformation:
        if not ti.document.text:
            # Buffer is empty: replace with placeholder. Length invariant is
            # intentionally broken here because placeholder text is never
            # selectable or cursor-positioned.
            return Transformation([("class:plugin-search-placeholder", self._placeholder)])
        return Transformation(ti.fragments)


@dataclass
class PluginPickerContext:
    """解析 /plugin 子命令后的上下文。"""

    initial_tab: str = "discover"
    target_plugin: str | None = None
    target_marketplace: str | None = None
    action: str | None = None


@dataclass
class PluginPickerResult:
    """Plugin picker 返回结果 — 指示发生了哪些变更。"""

    needs_reload: bool = False
    installed_count: int = 0
    uninstalled_count: int = 0


@dataclass(frozen=True, slots=True)
class PluginPickerAction:
    """Plugin picker 交互动作输出，对齐 QuestionAction 模式。"""

    kind: str  # "exit" | "noop"
    result: PluginPickerResult = field(default_factory=PluginPickerResult)


def parse_plugin_args(args: str) -> PluginPickerContext:
    """解析 /plugin 子命令参数。

    支持的格式：
    - ``（空）-> discover 标签
    - ``install <name>`` -> discover 标签 + install 动作
    - ``uninstall <name>`` -> installed 标签 + uninstall 动作
    - ``enable <name>`` -> installed 标签 + enable 动作
    - ``disable <name>`` -> installed 标签 + disable 动作
    - ``update <name>`` -> installed 标签 + update 动作
    - ``marketplace add <repo>`` -> marketplaces 标签 + add 动作
    - ``marketplace update <name>`` -> marketplaces 标签 + update 动作
    - ``marketplace remove <name>`` -> marketplaces 标签 + remove 动作
    """
    parts = args.strip().split()
    if not parts:
        return PluginPickerContext()

    cmd = parts[0].lower()

    # Plugin lifecycle: install -> discover tab
    if cmd == "install":
        return PluginPickerContext(
            initial_tab="discover",
            action="install",
            target_plugin=parts[1] if len(parts) > 1 else None,
        )

    # Plugin lifecycle: uninstall/enable/disable/update -> installed tab
    if cmd in ("uninstall", "enable", "disable", "update"):
        return PluginPickerContext(
            initial_tab="installed",
            action=cmd,
            target_plugin=parts[1] if len(parts) > 1 else None,
        )

    # Marketplace subcommands
    if cmd == "marketplace" and len(parts) >= 2:
        sub = parts[1].lower()
        return PluginPickerContext(
            initial_tab="marketplaces",
            action=sub,
            target_marketplace=parts[2] if len(parts) > 2 else None,
        )

    return PluginPickerContext()


@dataclass(slots=True)
class PluginPickerUIState:
    """Plugin picker 全局 UI 状态。"""

    active_tab: int = 0
    search_query: str = ""
    loading_message: str | None = None


class PluginPickerUI:
    """嵌入式 plugin picker 组件，包含 4 个标签：Discover、Installed、Marketplaces、Errors。

    无参构造，依赖通过 enter() 注入。container property 供主 TUI ConditionalContainer 使用。
    """

    TAB_NAMES = ["Discover", "Installed", "Marketplaces", "Errors"]

    _TAB_INDEX_MAP: dict[str, int] = {
        "discover": 0,
        "installed": 1,
        "marketplaces": 2,
        "errors": 3,
    }

    def __init__(self) -> None:
        self._registry = None
        self._plugin_mgr = None
        self._mkt_mgr = None
        self._loader = None
        self._context = PluginPickerContext()
        self._result = PluginPickerResult()

        self._ui_state = PluginPickerUIState()
        self._tabs: list[object] = []
        self._root: object = None  # 惰性构建

        # Search area（与 question_view._custom_input_area 同模式）
        self._search_area = TextArea(
            text="",
            multiline=False,
            prompt="🔍 ",
            wrap_lines=False,
            style="class:plugin-search-input",
            input_processors=[_PlaceholderProcessor("Search...")],
        )

        @self._search_area.buffer.on_text_changed.add_handler
        def _sync_search(buffer) -> None:  # type: ignore[no-untyped-def]
            self._ui_state.search_query = buffer.text
            tab = self._active_tab()
            if hasattr(tab, "apply_filter"):
                tab.apply_filter(buffer.text)

    # ------------------------------------------------------------------
    # Enter / container / focus
    # ------------------------------------------------------------------

    def enter(
        self,
        registry: PluginRegistry,
        plugin_manager: PluginManager,
        marketplace_manager: MarketplaceManager,
        loader: PluginLoader,
        context: PluginPickerContext | None = None,
    ) -> None:
        """注入依赖，重置状态，激活初始 tab。纯同步。"""
        self._registry = registry
        self._plugin_mgr = plugin_manager
        self._mkt_mgr = marketplace_manager
        self._loader = loader
        self._context = context or PluginPickerContext()
        self._result = PluginPickerResult()

        # 重置 tabs（旧 tab 实例及其持有的旧依赖引用一并丢弃）
        self._tabs = []

        self._ui_state = PluginPickerUIState()
        self._ui_state.active_tab = self._TAB_INDEX_MAP.get(self._context.initial_tab, 0)
        self._clear_search()
        self._ensure_tabs()
        tab = self._active_tab()
        if hasattr(tab, "activate"):
            tab.activate()

    @property
    def container(self) -> HSplit:
        """惰性构建 layout 根节点（HSplit），供主 TUI ConditionalContainer 使用。"""
        if self._root is None:
            self._root = self._build_layout()
        return self._root

    def focus_target(self) -> Window:
        """返回应获得焦点的 Window。主 TUI 在切换到 PLUGIN 模式时调用。"""
        return self._content_window

    @property
    def search_area_window(self) -> Window:
        """Public accessor for the search TextArea window, used by key bindings filter."""
        return self._search_area.window

    @property
    def content_window(self) -> Window:
        """Public accessor for the content Window, used by key bindings filter."""
        return self._content_window

    def inject_search_char(self, char: str) -> None:
        """将字符注入搜索框 buffer 末尾。供 key_bindings 焦点转移时调用。"""
        self._search_area.buffer.insert_text(char)

    def take_result(self) -> PluginPickerResult:
        """返回当前结果并将 _result 重置为初始状态。"""
        result = self._result
        self._result = PluginPickerResult()
        return result

    # ------------------------------------------------------------------
    # Handler methods
    # ------------------------------------------------------------------

    def handle_enter(self) -> PluginPickerAction | None:
        tab = self._active_tab()
        if hasattr(tab, "handle_enter"):
            tab.handle_enter()
        return None

    def handle_up(self) -> None:
        tab = self._active_tab()
        if hasattr(tab, "handle_up"):
            tab.handle_up()

    def handle_down(self) -> None:
        tab = self._active_tab()
        if hasattr(tab, "handle_down"):
            tab.handle_down()

    def handle_space(self) -> None:
        tab = self._active_tab()
        if hasattr(tab, "handle_space"):
            tab.handle_space()

    def handle_escape(self) -> PluginPickerAction | None:
        """三级 escape 逻辑：
        1. search area 有文字 → 清除搜索，返回 None
        2. 当前 tab 有 go_back() 且处理成功 → 返回 None
        3. 否则 → 返回 PluginPickerAction(kind="exit")
        """
        if self._search_area.text:
            self._clear_search()
            return None
        tab = self._active_tab()
        if hasattr(tab, "go_back") and tab.go_back():
            return None
        return PluginPickerAction(kind="exit", result=self._result)

    def handle_tab(self) -> None:
        self._switch_tab(1)

    def handle_shift_tab(self) -> None:
        self._switch_tab(-1)

    # ------------------------------------------------------------------
    # Tab management
    # ------------------------------------------------------------------

    def _ensure_tabs(self) -> None:
        """惰性初始化标签实现，避免循环导入。"""
        if self._tabs:
            return

        from .tabs.discover_tab import DiscoverTab
        from .tabs.errors_tab import ErrorsTab
        from .tabs.installed_tab import InstalledTab
        from .tabs.marketplaces_tab import MarketplacesTab

        self._tabs = [
            DiscoverTab(
                self._plugin_mgr,
                self._mkt_mgr,
                self._registry,
                self._loader,
                self._context,
            ),
            InstalledTab(self._plugin_mgr, self._registry, self._context),
            MarketplacesTab(self._mkt_mgr, self._registry, self._context),
            ErrorsTab(self._loader, self._registry),
        ]

    def _active_tab(self) -> object:
        self._ensure_tabs()
        return self._tabs[self._ui_state.active_tab]

    # ------------------------------------------------------------------
    # Fragment callbacks
    # ------------------------------------------------------------------

    def _tabs_fragments(self) -> list[tuple[str, str]]:
        fragments: list[tuple[str, str]] = [("bold", "Plugins  ")]
        for idx, name in enumerate(self.TAB_NAMES):
            if idx > 0:
                fragments.append(("", "   "))
            style = "bold reverse" if idx == self._ui_state.active_tab else ""
            fragments.append((style, name))
            if name == "Errors":
                self._ensure_tabs()
                tab = self._tabs[3]
                if hasattr(tab, "error_count") and tab.error_count > 0:
                    fragments.append(("class:error", f" ({tab.error_count})"))
        return fragments

    def _status_fragments(self) -> list[tuple[str, str]]:
        tab_name = self.TAB_NAMES[self._ui_state.active_tab]
        tab = self._active_tab()
        text = f"  {tab_name}"
        if hasattr(tab, "get_cursor_info"):
            info = tab.get_cursor_info()
            if info is not None:
                cursor, total = info
                text = f"  {tab_name} plugins ({cursor}/{total})"
        loading = self._ui_state.loading_message
        if loading:
            text += f"  {loading}"
        return [("class:dim", text)]

    def _content_fragments(self) -> list[tuple[str, str]]:
        tab = self._active_tab()
        if hasattr(tab, "get_formatted_text"):
            return tab.get_formatted_text()
        return [("", "No content")]

    def _footer_fragments(self) -> list[tuple[str, str]]:
        tab = self._active_tab()
        if hasattr(tab, "get_footer_hint"):
            return [("class:status", tab.get_footer_hint())]
        return [("class:status", "Esc: back")]

    def show_search(self) -> bool:
        """当前 tab 是否支持搜索。"""
        tab = self._active_tab()
        if hasattr(tab, "is_searchable"):
            return tab.is_searchable()
        return False


    # ------------------------------------------------------------------
    # Layout
    # ------------------------------------------------------------------

    def _build_layout(self) -> HSplit:
        self._ensure_tabs()

        tab_bar_window = Window(
            content=FormattedTextControl(self._tabs_fragments),
            height=1,
            dont_extend_height=True,
        )
        divider = Window(height=1, char="\u2500", style="class:plugin.divider")
        status_window = Window(
            content=FormattedTextControl(self._status_fragments),
            height=1,
            dont_extend_height=True,
        )

        search_container = ConditionalContainer(
            content=Frame(self._search_area, style="class:plugin-search-frame"),
            filter=Condition(self.show_search),
        )

        self._content_window = Window(
            content=FormattedTextControl(self._content_fragments, focusable=True),
            wrap_lines=True,
            dont_extend_height=False,
            always_hide_cursor=True,
        )

        footer_window = Window(
            content=FormattedTextControl(self._footer_fragments),
            height=1,
            dont_extend_height=True,
        )

        root = HSplit([
            tab_bar_window,
            divider,
            status_window,
            search_container,
            self._content_window,
            footer_window,
        ])
        self._root = root
        return root

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _switch_tab(self, delta: int) -> None:
        count = len(self.TAB_NAMES)
        self._ui_state.active_tab = (self._ui_state.active_tab + delta) % count
        self._clear_search()
        tab = self._active_tab()
        if hasattr(tab, "activate"):
            tab.activate()

    def _clear_search(self) -> None:
        self._ui_state.search_query = ""
        if self._search_area.text:
            self._search_area.buffer.document = Document(text="", cursor_position=0)
        if self._tabs:
            tab = self._active_tab()
            if hasattr(tab, "apply_filter"):
                tab.apply_filter("")
