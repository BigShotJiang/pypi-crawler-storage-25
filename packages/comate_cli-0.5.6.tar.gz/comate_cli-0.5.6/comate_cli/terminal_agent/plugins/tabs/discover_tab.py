"""Discover 标签 — 浏览 marketplace 中可安装的插件。

状态机：LIST -> DETAIL（Enter）-> LIST（Esc / 安装后）
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Literal

from prompt_toolkit.application.current import get_app_or_none

from comate_cli.terminal_agent.figures import (
    BULLET_OPERATOR,
    CHECK_MARK,
    DOWN_ARROW,
    EFFORT_HIGH,
    EFFORT_LOW,
    UP_ARROW,
)

if TYPE_CHECKING:
    from comate_agent_sdk.plugins import (
        PluginLoader,
        PluginManager,
        PluginRegistry,
        MarketplaceManager,
    )
    from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerContext

logger = logging.getLogger(__name__)

_State = Literal["LIST", "DETAIL"]

class DiscoverTab:
    """Discover 标签：浏览 marketplace 插件、批量选择、安装。"""

    def __init__(
        self,
        plugin_mgr: PluginManager,
        mkt_mgr: MarketplaceManager,
        registry: PluginRegistry,
        loader: PluginLoader,
        context: PluginPickerContext,
    ) -> None:
        self._plugin_mgr = plugin_mgr
        self._mkt_mgr = mkt_mgr
        self._registry = registry
        self._loader = loader
        self._context = context

        # 全量插件列表（activate 后填充）
        self._all_items: list[dict] = []

        # 内联状态字段（替代 PluginListControl / DetailView）
        self._cursor: int = 0
        self._selected_items: set[int] = set()
        self._detail_item: dict | None = None
        self._detail_cursor: int = 0
        self._detail_actions: list[str] = ["Install for user", "Install for project", "Back"]
        self._filtered_items: list[dict] | None = None

        # 状态机
        self._state: _State = "LIST"

        # 安装状态消息（inline 提示）
        self._status_message: str = ""

        # 跟踪正在执行的安装任务，防止 GC 回收
        self._install_tasks: list[asyncio.Task[None]] = []

    # ------------------------------------------------------------------
    # 数据访问
    # ------------------------------------------------------------------

    @property
    def _visible_items(self) -> list[dict]:
        return self._filtered_items if self._filtered_items is not None else self._all_items

    # ------------------------------------------------------------------
    # 激活
    # ------------------------------------------------------------------

    def activate(self) -> None:
        """标签被激活：从所有 marketplace 加载可用插件，交叉对比已安装列表。"""
        logger.debug("DiscoverTab.activate: loading available plugins")
        try:
            available = self._mkt_mgr.list_all_available_plugins()
        except Exception:
            logger.exception("Failed to load available plugins")
            available = {}

        try:
            installed = self._registry.list_installed()
        except Exception:
            logger.exception("Failed to load installed plugins")
            installed = {}

        installed_keys: set[str] = set(installed.keys())

        items: list[dict] = []
        for mkt_name, entries in available.items():
            for entry in entries:
                plugin_key = f"{entry.name}@{mkt_name}"
                items.append(
                    {
                        "name": entry.name,
                        "description": entry.description,
                        "source": entry.source.to_dict(),
                        "author": entry.author,
                        "tags": entry.tags,
                        "homepage": entry.homepage,
                        "marketplace": mkt_name,
                        "plugin_key": plugin_key,
                        "installed": plugin_key in installed_keys,
                    }
                )

        self._all_items = items
        self._cursor = 0
        self._selected_items.clear()
        self._filtered_items = None
        self._state = "LIST"
        self._status_message = ""
        logger.debug("DiscoverTab.activate: loaded %d plugins", len(items))

    # ------------------------------------------------------------------
    # 过滤
    # ------------------------------------------------------------------

    def _apply_filter(self, query: str) -> None:
        """按 query 过滤插件列表（名称 + 描述，大小写不敏感）。"""
        q = query.strip().lower()
        if not q:
            self._filtered_items = None
            self._cursor = 0
            return
        self._filtered_items = [
            item
            for item in self._all_items
            if q in item.get("name", "").lower() or q in item.get("description", "").lower()
        ]
        self._cursor = 0

    # ------------------------------------------------------------------
    # 渲染 — 列表
    # ------------------------------------------------------------------

    def _render_list(
        self,
        viewport_height: int = 16,
        max_width: int = 120,
    ) -> list[tuple[str, str]]:
        """渲染 viewport 窗口内的条目列表。

        每项两行：
        - 第一行：cursor + checkbox + 名称 · marketplace
        - 第二行：描述（缩进，超长截断）

        viewport 跟随光标滚动，光标尽量保持在中间位置。
        """
        items = self._visible_items
        if not items:
            return [("class:plugin.empty", "  No plugins found")]

        items_per_viewport = max(1, viewport_height // 2)
        half = items_per_viewport // 2
        viewport_start = max(0, self._cursor - half)
        viewport_end = viewport_start + items_per_viewport
        if viewport_end > len(items):
            viewport_end = len(items)
            viewport_start = max(0, viewport_end - items_per_viewport)

        fragments: list[tuple[str, str]] = []

        if viewport_start > 0:
            fragments.append(("class:plugin.scroll-hint", f"  {UP_ARROW} more above"))
            fragments.append(("", "\n"))

        for idx in range(viewport_start, viewport_end):
            item = items[idx]
            is_cursor = idx == self._cursor
            is_selected = idx in self._selected_items
            is_installed = item.get("installed", False)

            if is_installed:
                checkbox_style = "class:plugin.checkbox.installed"
                checkbox = CHECK_MARK
            elif is_selected:
                checkbox_style = "class:plugin.checkbox.selected"
                checkbox = EFFORT_HIGH
            else:
                checkbox_style = "class:plugin.checkbox"
                checkbox = EFFORT_LOW

            name = item.get("name", "unknown")
            marketplace = item.get("marketplace", "")

            name_style = "class:plugin.name.cursor" if is_cursor else "class:plugin.name"
            fragments.append((checkbox_style, checkbox))
            fragments.append(("", " "))
            fragments.append((name_style, name))
            if marketplace:
                fragments.append(("class:plugin.separator", f" {BULLET_OPERATOR} "))
                fragments.append(("class:plugin.marketplace", marketplace))
            fragments.append(("", "\n"))

            description = item.get("description", "")
            if description:
                indent = "  "
                max_desc = max_width - len(indent)
                if len(description) > max_desc:
                    description = description[: max_desc - 3] + "..."
                fragments.append(("class:plugin.description", f"{indent}{description}"))
                fragments.append(("", "\n"))

        if viewport_end < len(items):
            fragments.append(("class:plugin.scroll-hint", f"  {DOWN_ARROW} more below"))
            fragments.append(("", "\n"))

        return fragments

    # ------------------------------------------------------------------
    # 渲染 — 详情
    # ------------------------------------------------------------------

    def _render_detail(self) -> list[tuple[str, str]]:
        """渲染插件详情：名称、来源、作者、marketplace、描述 + 操作菜单。"""
        if not self._detail_item:
            return [("class:detail.empty", "  Select a plugin to view details")]

        fragments: list[tuple[str, str]] = []
        info = self._detail_item

        # 名称
        name = info.get("name", "unknown")
        fragments.append(("bold", f"  {name}"))
        fragments.append(("", "\n"))

        # 来源
        source = info.get("source", "")
        if source:
            fragments.append(("class:detail.meta", f"  Source: {source}"))
            fragments.append(("", "\n"))

        # 作者
        author = info.get("author", "")
        if author:
            fragments.append(("class:detail.meta", f"  Author: {author}"))
            fragments.append(("", "\n"))

        # Marketplace
        marketplace = info.get("marketplace", "")
        if marketplace:
            fragments.append(("class:detail.meta", f"  Marketplace: {marketplace}"))
            fragments.append(("", "\n"))

        # 描述
        description = info.get("description", "")
        if description:
            fragments.append(("", "\n"))
            fragments.append(("class:detail.description", f"  {description}"))
            fragments.append(("", "\n"))

        # 信任警告
        trusted = info.get("trusted", True)
        if not trusted:
            fragments.append(("", "\n"))
            fragments.append(
                ("class:detail.warning", "  Warning: This plugin is from an untrusted source.")
            )
            fragments.append(("", "\n"))

        # 操作列表
        if self._detail_actions:
            fragments.append(("", "\n"))
            fragments.append(("bold", "  Actions:"))
            fragments.append(("", "\n"))
            for idx, action in enumerate(self._detail_actions):
                is_selected = idx == self._detail_cursor
                cursor = ">" if is_selected else " "
                style = "bold" if is_selected else ""
                fragments.append((style, f"  {cursor} {action}"))
                fragments.append(("", "\n"))

        return fragments

    # ------------------------------------------------------------------
    # 渲染 — 主入口
    # ------------------------------------------------------------------

    def get_formatted_text(self) -> list[tuple[str, str]]:
        """返回 prompt_toolkit style tuples。"""
        if self._state == "DETAIL":
            return self._render_detail()

        # LIST 状态
        fragments: list[tuple[str, str]] = []

        if self._status_message:
            fragments.append(("class:plugin.hint", f"  {self._status_message}"))
            fragments.append(("", "\n"))

        fragments.append(("", "\n"))

        # 从终端尺寸动态计算 viewport
        app = get_app_or_none()
        viewport_height = 16  # fallback
        max_width = 120
        if app:
            size = app.output.get_size()
            viewport_height = max(4, size.rows - 6)  # 减去固定行
            max_width = max(40, size.columns)

        fragments.extend(
            self._render_list(
                viewport_height=viewport_height,
                max_width=max_width,
            )
        )
        return fragments

    # ------------------------------------------------------------------
    # 导航
    # ------------------------------------------------------------------

    def handle_up(self) -> None:
        if self._state == "LIST":
            items = self._visible_items
            if items:
                self._cursor = (self._cursor - 1) % len(items)
        else:
            if self._detail_actions:
                self._detail_cursor = (self._detail_cursor - 1) % len(self._detail_actions)

    def handle_down(self) -> None:
        if self._state == "LIST":
            items = self._visible_items
            if items:
                self._cursor = (self._cursor + 1) % len(items)
        else:
            if self._detail_actions:
                self._detail_cursor = (self._detail_cursor + 1) % len(self._detail_actions)

    # ------------------------------------------------------------------
    # 选择
    # ------------------------------------------------------------------

    def handle_space(self) -> None:
        """LIST 态：切换当前项的选中状态。"""
        if self._state == "LIST":
            items = self._visible_items
            if not items:
                return
            idx = self._cursor
            if idx in self._selected_items:
                self._selected_items.discard(idx)
            else:
                self._selected_items.add(idx)

    def handle_enter(self) -> None:
        """LIST 态：有选中项时批量安装；无选中时进入详情。DETAIL 态：执行选中操作。"""
        if self._state == "LIST":
            items = self._visible_items
            if self._selected_items:
                selected = [
                    items[i] for i in sorted(self._selected_items) if i < len(items)
                ]
                for item in selected:
                    self._schedule_install(item, scope="user")
                count = len(selected)
                self._status_message = f"Installing {count} plugin(s)..."
                self._selected_items.clear()
                logger.info("DiscoverTab: batch install %d plugins via Enter", count)
                return
            if not items or self._cursor >= len(items):
                return
            item = items[self._cursor]
            self._detail_item = item
            self._detail_actions = ["Install for user", "Install for project", "Back"]
            self._detail_cursor = 0
            self._state = "DETAIL"
            logger.debug("DiscoverTab: enter DETAIL for %s", item.get("name"))
            return

        # DETAIL 态
        if not self._detail_actions:
            return
        action = self._detail_actions[self._detail_cursor]

        if action == "Back":
            self._state = "LIST"
            return

        if action == "Install for user":
            self._trigger_install(scope="user")
        elif action == "Install for project":
            self._trigger_install(scope="local")

    # ------------------------------------------------------------------
    # 统一接口
    # ------------------------------------------------------------------

    def get_cursor_info(self) -> tuple[int, int] | None:
        """返回 (当前位置, 总数)，无列表时返回 None。"""
        items = self._visible_items
        if not items:
            return None
        return (self._cursor + 1, len(items))

    def get_footer_hint(self) -> str:
        """返回当前状态的底栏提示文本。"""
        if self._state == "DETAIL":
            return "Up/Down: navigate | Enter: select action | Esc: back to list"
        if self._selected_items:
            n = len(self._selected_items)
            return f"Space: toggle | Enter: install {n} selected | Esc: back"
        return "Tab: switch tabs | type to search | Space: toggle | Enter: details | Esc: back"

    def is_searchable(self) -> bool:
        """当前状态是否允许搜索。"""
        return self._state == "LIST"

    def apply_filter(self, query: str) -> None:
        """公共过滤接口（委托给内部 _apply_filter）。"""
        self._apply_filter(query)

    def go_back(self) -> bool:
        """Esc：DETAIL 态返回 LIST；LIST 态不处理（由 PluginPickerUI 退出）。"""
        if self._state == "DETAIL":
            self._state = "LIST"
            logger.debug("DiscoverTab: go_back to LIST")
            return True
        return False

    # ------------------------------------------------------------------
    # 安装内部逻辑
    # ------------------------------------------------------------------

    def _trigger_install(self, scope: Literal["user", "local"]) -> None:
        """从 DETAIL 视图触发安装，安装完成后返回 LIST。"""
        item = self._detail_item
        if not item:
            return
        self._schedule_install(item, scope=scope)
        self._status_message = f"Installing {item.get('name', '')}..."
        self._state = "LIST"

    def _schedule_install(self, item: dict, scope: Literal["user", "local"]) -> None:
        """异步调度安装任务，存储 Task 引用防止 GC 回收。"""
        plugin_key = item.get("plugin_key") or item.get("name", "")
        task = asyncio.create_task(self._do_install(plugin_key, item, scope))
        self._install_tasks.append(task)
        task.add_done_callback(self._on_install_done)

    def _on_install_done(self, task: asyncio.Task[None]) -> None:
        """安装任务完成后清理引用并触发 UI 重绘。"""
        if task in self._install_tasks:
            self._install_tasks.remove(task)
        app = get_app_or_none()
        if app is not None:
            app.invalidate()

    async def _do_install(
        self, plugin_key: str, item: dict, scope: Literal["user", "local"]
    ) -> None:
        """执行安装：调用 plugin_manager.install()，更新 item 的 installed 标志。"""
        name = item.get("name", plugin_key)
        logger.info("DiscoverTab._do_install: installing %s (scope=%s)", plugin_key, scope)
        try:
            await self._plugin_mgr.install(plugin_key, scope=scope)
            # 更新 _all_items 中对应条目的 installed 状态
            for stored in self._all_items:
                if stored.get("plugin_key") == plugin_key:
                    stored["installed"] = True
            # 同步到 _filtered_items（如果存在）
            if self._filtered_items is not None:
                for stored in self._filtered_items:
                    if stored.get("plugin_key") == plugin_key:
                        stored["installed"] = True
            self._status_message = f"Installed: {name}"
            logger.info("DiscoverTab._do_install: installed %s successfully", plugin_key)
        except Exception as exc:
            self._status_message = f"Failed to install {name}: {exc}"
            logger.error("DiscoverTab._do_install: failed to install %s: %s", plugin_key, exc)
