"""Marketplaces 标签 — 管理 marketplace 源。

状态机：
  LIST           - marketplace 列表（含 "+ Add Marketplace" 操作行）
  DETAIL         - marketplace 详情页（Browse / Update / Remove）
  CONFIRM_REMOVE - 删除确认（当 marketplace 有已安装插件时）
  INPUT_ADD      - 等待用户确认添加（简化：显示提示，Enter 提交 context.target_marketplace）
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Literal

from prompt_toolkit.application.current import get_app_or_none

if TYPE_CHECKING:
    from comate_agent_sdk.plugins import MarketplaceManager, PluginRegistry
    from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerContext

logger = logging.getLogger(__name__)

_State = Literal["LIST", "DETAIL", "CONFIRM_REMOVE", "INPUT_ADD"]

# "+ Add Marketplace" 哨兵 key
_ADD_ROW_KEY = "__add_marketplace__"


class MarketplacesTab:
    """Marketplaces 标签：查看、添加、更新、删除 marketplace 源。"""

    def __init__(
        self,
        mkt_mgr: MarketplaceManager,
        registry: PluginRegistry,
        context: PluginPickerContext,
    ) -> None:
        self._mkt_mgr = mkt_mgr
        self._registry = registry
        self._context = context

        # 导航条目列表：[{"key": ..., "name": ..., "is_add_row": bool, ...}]
        self._items: list[dict] = []
        self._cursor: int = 0

        # 当前选中的 marketplace 名称（进入 DETAIL/CONFIRM 时设置）
        self._selected_name: str = ""

        # 状态机
        self._state: _State = "LIST"

        # 状态消息（inline 提示）
        self._status_message: str = ""

        # 跟踪正在执行的异步任务，防止 GC 回收
        self._tasks: list[asyncio.Task[None]] = []

        # 供 PluginPickerUI 读取以切换到 Discover 标签浏览插件
        self.browse_target: str | None = None

        # 详情视图状态
        self._detail_item: dict | None = None
        self._detail_cursor: int = 0
        self._detail_actions: list[str] = []

    # ------------------------------------------------------------------
    # 激活
    # ------------------------------------------------------------------

    def activate(self) -> None:
        """标签被激活：从 registry 加载已注册 marketplace 列表。"""
        logger.debug("MarketplacesTab.activate: loading marketplaces")
        self._reload_items()
        self._cursor = 0
        self._state = "LIST"
        self._status_message = ""

    def _reload_items(self) -> None:
        """从 registry 重新加载 marketplace 条目（含 Add 行）。"""
        try:
            marketplaces = self._registry.list_marketplaces()
        except Exception:
            logger.exception("Failed to load marketplaces")
            marketplaces = {}

        try:
            installed = self._registry.list_installed()
        except Exception:
            logger.exception("Failed to load installed plugins")
            installed = {}

        items: list[dict] = []
        # 第一行：+ Add Marketplace
        items.append({"key": _ADD_ROW_KEY, "is_add_row": True})

        for name, info in marketplaces.items():
            # 统计该 marketplace 下已安装插件数
            count = sum(
                1 for k in installed if k.endswith(f"@{name}")
            )
            items.append(
                {
                    "key": name,
                    "name": name,
                    "repo": info.source.repo if info.source else "",
                    "install_location": str(info.install_location),
                    "last_updated": info.last_updated,
                    "installed_count": count,
                    "is_add_row": False,
                }
            )

        self._items = items
        # 修正 cursor 越界
        if self._cursor >= len(self._items):
            self._cursor = max(0, len(self._items) - 1)

    # ------------------------------------------------------------------
    # 当前条目
    # ------------------------------------------------------------------

    def _current_item(self) -> dict | None:
        if not self._items:
            return None
        return self._items[self._cursor]

    # ------------------------------------------------------------------
    # 渲染
    # ------------------------------------------------------------------

    def get_formatted_text(self) -> list[tuple[str, str]]:
        """返回 prompt_toolkit style tuples。"""
        if self._state == "DETAIL":
            return self._render_detail()
        if self._state == "CONFIRM_REMOVE":
            return self._render_confirm_remove()
        if self._state == "INPUT_ADD":
            return self._render_input_add()
        return self._render_list()

    def _render_list(self) -> list[tuple[str, str]]:
        fragments: list[tuple[str, str]] = []
        hint = "Tab: switch tabs | type to search | Enter: details | Esc: back"
        fragments.append(("class:plugin.hint", f"  {hint}"))
        fragments.append(("", "\n"))

        if self._status_message:
            fragments.append(("class:plugin.hint", f"  {self._status_message}"))
            fragments.append(("", "\n"))

        fragments.append(("", "\n"))

        for idx, item in enumerate(self._items):
            is_cursor = idx == self._cursor
            cursor_str = "> " if is_cursor else "  "

            if item.get("is_add_row"):
                style = "bold" if is_cursor else "class:plugin.hint"
                fragments.append((style, f"{cursor_str}+ Add Marketplace"))
                fragments.append(("", "\n"))
                continue

            name = item.get("name", "unknown")
            repo = item.get("repo", "")
            count = item.get("installed_count", 0)
            last_updated = item.get("last_updated", "")

            count_str = f"  [{count} installed]" if count > 0 else ""
            repo_str = f"  ({repo})" if repo else ""

            label = f"{cursor_str}■ {name}{repo_str}{count_str}"
            style = "bold" if is_cursor else ""
            fragments.append((style, label))
            if last_updated:
                fragments.append(("class:dim", f"   updated: {last_updated[:10]}"))
            fragments.append(("", "\n"))

        return fragments

    def _render_detail(self) -> list[tuple[str, str]]:
        if not self._detail_item:
            return [("class:dim", "  No marketplace selected")]
        fragments: list[tuple[str, str]] = []
        info = self._detail_item
        fragments.append(("bold", f"  {info.get('name', 'unknown')}\n"))
        repo = info.get("repo", "")
        if repo:
            fragments.append(("class:dim", f"  Repository: {repo}\n"))
        location = info.get("install_location", "")
        if location:
            fragments.append(("class:dim", f"  Location: {location}\n"))
        last_updated = info.get("last_updated", "")
        if last_updated:
            fragments.append(("class:dim", f"  Last updated: {last_updated[:19]}\n"))
        count = info.get("installed_count", 0)
        fragments.append(("class:dim", f"  Installed plugins: {count}\n"))
        fragments.append(("", "\n"))
        fragments.append(("bold", "  Actions:\n"))
        for idx, action in enumerate(self._detail_actions):
            cursor = ">" if idx == self._detail_cursor else " "
            style = "bold" if idx == self._detail_cursor else ""
            fragments.append((style, f"  {cursor} {action}\n"))
        return fragments

    def _render_confirm_remove(self) -> list[tuple[str, str]]:
        fragments: list[tuple[str, str]] = []
        fragments.append(("bold", f"  Remove marketplace '{self._selected_name}'?"))
        fragments.append(("", "\n"))
        fragments.append(("class:plugin.hint", "  Enter: confirm | Esc: cancel"))
        fragments.append(("", "\n"))
        return fragments

    def _render_input_add(self) -> list[tuple[str, str]]:
        fragments: list[tuple[str, str]] = []
        hint = "Enter: confirm add | Esc: cancel"
        fragments.append(("class:plugin.hint", f"  {hint}"))
        fragments.append(("", "\n\n"))

        target = self._context.target_marketplace or ""
        if target:
            fragments.append(("", f"  Will add marketplace: "))
            fragments.append(("bold", target))
            fragments.append(("", "\n"))
            fragments.append(("class:dim", "  Press Enter to confirm, Esc to cancel."))
        else:
            fragments.append(("class:dim", "  No marketplace specified (use /plugin marketplace add <repo>)."))

        fragments.append(("", "\n"))

        if self._status_message:
            fragments.append(("", "\n"))
            fragments.append(("class:plugin.hint", f"  {self._status_message}"))
            fragments.append(("", "\n"))

        return fragments

    # ------------------------------------------------------------------
    # 导航
    # ------------------------------------------------------------------

    def handle_up(self) -> None:
        if self._state == "LIST" and self._items:
            self._cursor = (self._cursor - 1) % len(self._items)
        elif self._state == "DETAIL" and self._detail_actions:
            self._detail_cursor = (self._detail_cursor - 1) % len(self._detail_actions)

    def handle_down(self) -> None:
        if self._state == "LIST" and self._items:
            self._cursor = (self._cursor + 1) % len(self._items)
        elif self._state == "DETAIL" and self._detail_actions:
            self._detail_cursor = (self._detail_cursor + 1) % len(self._detail_actions)

    # ------------------------------------------------------------------
    # 动作
    # ------------------------------------------------------------------

    def handle_enter(self) -> None:
        """LIST 态：进入 DETAIL 或 INPUT_ADD；DETAIL 态：执行选中操作；INPUT_ADD 态：确认添加；CONFIRM_REMOVE 态：确认删除。"""
        if self._state == "INPUT_ADD":
            self._confirm_add()
            return

        if self._state == "CONFIRM_REMOVE":
            self._execute_remove()
            return

        if self._state == "DETAIL":
            action = self._detail_actions[self._detail_cursor] if self._detail_actions else None
            if action == "Back":
                self._state = "LIST"
            elif action == "Browse plugins":
                self.browse_target = self._selected_name
                self._status_message = f"Browse plugins in '{self._selected_name}' — switch to Discover tab."
            elif action == "Update":
                self._schedule_update(self._selected_name)
                self._status_message = f"Updating {self._selected_name}..."
            elif action == "Remove":
                detail_item = self._find_item(self._selected_name)
                count = detail_item.get("installed_count", 0) if detail_item else 0
                if count > 0:
                    self._state = "CONFIRM_REMOVE"
                else:
                    self._schedule_remove(self._selected_name)
                    self._state = "LIST"
                    self._status_message = f"Removing {self._selected_name}..."
            return

        if self._state == "LIST":
            item = self._current_item()
            if item is None:
                return
            if item.get("is_add_row"):
                self._state = "INPUT_ADD"
                self._status_message = ""
                return
            self._selected_name = item.get("name", "")
            self._detail_item = {
                "name": item.get("name", ""),
                "repo": item.get("repo", ""),
                "install_location": item.get("install_location", ""),
                "last_updated": item.get("last_updated", ""),
                "installed_count": item.get("installed_count", 0),
            }
            self._detail_actions = ["Browse plugins", "Update", "Remove", "Back"]
            self._detail_cursor = 0
            self._state = "DETAIL"
            self._status_message = ""
            logger.debug("MarketplacesTab: enter DETAIL for %s", self._selected_name)

    def go_back(self) -> bool:
        """Esc：CONFIRM_REMOVE 返回 DETAIL；DETAIL/INPUT_ADD 返回 LIST；LIST 态不处理。"""
        if self._state == "CONFIRM_REMOVE":
            self._state = "DETAIL"
            self._status_message = ""
            logger.debug("MarketplacesTab: go_back to DETAIL from CONFIRM_REMOVE")
            return True
        if self._state in ("DETAIL", "INPUT_ADD"):
            self._state = "LIST"
            self._status_message = ""
            logger.debug("MarketplacesTab: go_back to LIST from %s", self._state)
            return True
        return False

    # ------------------------------------------------------------------
    # 统一接口
    # ------------------------------------------------------------------

    def get_cursor_info(self) -> tuple[int, int] | None:
        if not self._items:
            return None
        return (self._cursor + 1, len(self._items))

    def get_footer_hint(self) -> str:
        if self._state == "DETAIL":
            return "Up/Down: navigate | Enter: select action | Esc: back to list"
        if self._state == "CONFIRM_REMOVE":
            return "Enter: confirm | Esc: cancel"
        if self._state == "INPUT_ADD":
            return "Enter: confirm add | Esc: cancel"
        return "Tab: switch tabs | type to search | Enter: details | Esc: back"

    def is_searchable(self) -> bool:
        return self._state == "LIST"

    def apply_filter(self, query: str) -> None:
        # Marketplace list is typically very small (1-3 items + Add row), skip filter
        self._cursor = 0

    # ------------------------------------------------------------------
    # 内部逻辑
    # ------------------------------------------------------------------

    def _find_item(self, name: str) -> dict | None:
        """按名称查找条目。"""
        for item in self._items:
            if not item.get("is_add_row") and item.get("name") == name:
                return item
        return None

    def _confirm_add(self) -> None:
        """INPUT_ADD 态：确认添加 context.target_marketplace。"""
        repo = self._context.target_marketplace
        if not repo:
            self._status_message = "No marketplace specified."
            return
        self._schedule_add(repo)
        self._status_message = f"Adding {repo}..."
        self._state = "LIST"
        logger.debug("MarketplacesTab: schedule add for %s", repo)

    def _execute_remove(self) -> None:
        """执行删除（CONFIRM_REMOVE 态或直接删除）。"""
        name = self._selected_name
        self._state = "LIST"
        self._schedule_remove(name)
        self._status_message = f"Removing {name}..."
        logger.debug("MarketplacesTab: execute remove for %s", name)

    def _schedule_add(self, repo: str) -> None:
        task = asyncio.create_task(self._do_add(repo))
        self._tasks.append(task)
        task.add_done_callback(self._on_task_done)

    def _schedule_update(self, name: str) -> None:
        task = asyncio.create_task(self._do_update(name))
        self._tasks.append(task)
        task.add_done_callback(self._on_task_done)

    def _schedule_remove(self, name: str) -> None:
        task = asyncio.create_task(self._do_remove(name))
        self._tasks.append(task)
        task.add_done_callback(self._on_task_done)

    def _on_task_done(self, task: asyncio.Task[None]) -> None:
        """任务完成后清理引用并触发 UI 重绘。"""
        if task in self._tasks:
            self._tasks.remove(task)
        app = get_app_or_none()
        if app is not None:
            app.invalidate()

    async def _do_add(self, repo: str) -> None:
        logger.info("MarketplacesTab._do_add: adding %s", repo)
        try:
            info = await self._mkt_mgr.add(repo)
            self._reload_items()
            self._status_message = f"Added: {info.name}"
            logger.info("MarketplacesTab._do_add: added %s successfully", repo)
        except Exception as exc:
            self._status_message = f"Failed to add {repo}: {exc}"
            logger.error("MarketplacesTab._do_add: failed to add %s: %s", repo, exc)

    async def _do_update(self, name: str) -> None:
        logger.info("MarketplacesTab._do_update: updating %s", name)
        try:
            await self._mkt_mgr.update(name)
            self._reload_items()
            self._status_message = f"Updated: {name}"
            logger.info("MarketplacesTab._do_update: updated %s successfully", name)
        except Exception as exc:
            self._status_message = f"Failed to update {name}: {exc}"
            logger.error("MarketplacesTab._do_update: failed to update %s: %s", name, exc)

    async def _do_remove(self, name: str) -> None:
        logger.info("MarketplacesTab._do_remove: removing %s", name)
        try:
            await self._mkt_mgr.remove(name)
            self._reload_items()
            self._status_message = f"Removed: {name}"
            logger.info("MarketplacesTab._do_remove: removed %s successfully", name)
        except Exception as exc:
            self._status_message = f"Failed to remove {name}: {exc}"
            logger.error("MarketplacesTab._do_remove: failed to remove %s: %s", name, exc)
