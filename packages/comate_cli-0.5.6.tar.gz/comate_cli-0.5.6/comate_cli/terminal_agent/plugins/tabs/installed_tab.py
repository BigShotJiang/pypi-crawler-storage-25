"""Installed 标签 — 管理已安装的插件。

状态机：LIST -> DETAIL（Enter）-> LIST（Esc）
        LIST -> CONFIRM_UNINSTALL（x）-> LIST（y/n）
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Literal

from prompt_toolkit.application.current import get_app_or_none

from comate_cli.terminal_agent.figures import (
    EFFORT_HIGH,
    EFFORT_LOW,
    HEAVY_HORIZONTAL,
)

if TYPE_CHECKING:
    from comate_agent_sdk.plugins import PluginManager, PluginRegistry
    from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerContext

logger = logging.getLogger(__name__)

_State = Literal["LIST", "DETAIL", "CONFIRM_UNINSTALL"]


class InstalledTab:
    """Installed 标签：查看、启用/禁用、卸载、更新已安装插件。"""

    def __init__(
        self,
        plugin_mgr: PluginManager,
        registry: PluginRegistry,
        context: PluginPickerContext,
    ) -> None:
        self._plugin_mgr = plugin_mgr
        self._registry = registry
        self._context = context

        # 导航条目（含 section header 占位项）
        self._items: list[dict] = []
        # 仅包含可导航（非 header）条目对应的 _items 下标
        self._nav_indices: list[int] = []
        # 原始完整导航下标（用于搜索过滤后恢复）
        self._all_nav_indices: list[int] = []
        # 当前在 _nav_indices 中的位置
        self._nav_cursor: int = 0

        # DETAIL 态内联状态
        self._detail_item: dict | None = None
        self._detail_cursor: int = 0
        self._detail_actions: list[str] = []

        # 状态机
        self._state: _State = "LIST"

        # 状态消息（inline 提示）
        self._status_message: str = ""

        # 跟踪正在执行的异步任务，防止 GC 回收
        self._update_tasks: list[asyncio.Task[None]] = []

    # ------------------------------------------------------------------
    # 激活
    # ------------------------------------------------------------------

    def activate(self) -> None:
        """标签被激活：从 registry 加载已安装插件，按 scope 分组。"""
        logger.debug("InstalledTab.activate: loading installed plugins")
        try:
            installed = self._registry.list_installed()
        except Exception:
            logger.exception("Failed to load installed plugins")
            installed = {}

        # 按 scope 分组
        user_items: list[dict] = []
        local_items: list[dict] = []

        for plugin_key, entries in installed.items():
            parts = plugin_key.rsplit("@", 1)
            name = parts[0]
            marketplace = parts[1] if len(parts) == 2 else ""
            for entry in entries:
                item = {
                    "plugin_key": plugin_key,
                    "name": name,
                    "marketplace": marketplace,
                    "version": entry.version,
                    "scope": entry.scope,
                    "enabled": entry.enabled,
                    "project_path": entry.project_path,
                    "is_header": False,
                }
                if entry.scope == "user":
                    user_items.append(item)
                else:
                    local_items.append(item)

        # 构建含 section header 的展平列表
        flat: list[dict] = []
        nav_indices: list[int] = []

        if user_items:
            flat.append(
                {
                    "is_header": True,
                    "scope": "user",
                    "label": f"User Plugins ({len(user_items)})",
                }
            )
            for item in user_items:
                nav_indices.append(len(flat))
                flat.append(item)

        if local_items:
            flat.append(
                {
                    "is_header": True,
                    "scope": "local",
                    "label": f"Local Plugins ({len(local_items)})",
                }
            )
            for item in local_items:
                nav_indices.append(len(flat))
                flat.append(item)

        self._items = flat
        self._nav_indices = nav_indices
        self._all_nav_indices = list(nav_indices)
        self._nav_cursor = 0
        self._state = "LIST"
        self._status_message = ""
        logger.debug(
            "InstalledTab.activate: %d plugins (%d user, %d local)",
            len(user_items) + len(local_items),
            len(user_items),
            len(local_items),
        )

    # ------------------------------------------------------------------
    # 当前条目
    # ------------------------------------------------------------------

    def _current_item(self) -> dict | None:
        """返回当前光标所在的可导航条目（非 header）。"""
        if not self._nav_indices:
            return None
        flat_idx = self._nav_indices[self._nav_cursor]
        return self._items[flat_idx]

    # ------------------------------------------------------------------
    # 统一接口
    # ------------------------------------------------------------------

    def get_cursor_info(self) -> tuple[int, int] | None:
        if not self._nav_indices:
            return None
        return (self._nav_cursor + 1, len(self._nav_indices))

    def get_footer_hint(self) -> str:
        if self._state == "DETAIL":
            return "Up/Down: navigate | Enter: select action | Esc: back to list"
        if self._state == "CONFIRM_UNINSTALL":
            return "Enter: confirm | Esc: cancel"
        return "Tab: switch tabs | type to search | Space: toggle | Enter: details | Esc: back"

    def is_searchable(self) -> bool:
        return self._state == "LIST"

    def apply_filter(self, query: str) -> None:
        """按 name 过滤已安装插件列表。每次从原始列表过滤。"""
        q = query.strip().lower()
        if not q:
            self._nav_indices = list(self._all_nav_indices)
            self._nav_cursor = 0
            return
        self._nav_indices = [
            i for i in self._all_nav_indices
            if q in self._items[i].get("name", "").lower()
        ]
        self._nav_cursor = 0

    # ------------------------------------------------------------------
    # 渲染
    # ------------------------------------------------------------------

    def get_formatted_text(self) -> list[tuple[str, str]]:
        """返回 prompt_toolkit style tuples。"""
        if self._state == "DETAIL":
            return self._render_detail()

        if self._state == "CONFIRM_UNINSTALL":
            return self._render_confirm_uninstall()

        return self._render_list()

    def _render_detail(self) -> list[tuple[str, str]]:
        if not self._detail_item:
            return [("class:dim", "  No plugin selected")]
        fragments: list[tuple[str, str]] = []
        info = self._detail_item
        name = info.get("name", "unknown")
        fragments.append(("bold", f"  {name}\n"))
        version = info.get("version", "")
        if version:
            fragments.append(("class:dim", f"  Version: v{version}\n"))
        scope = info.get("scope", "")
        if scope:
            fragments.append(("class:dim", f"  Scope: {scope}\n"))
        marketplace = info.get("marketplace", "")
        if marketplace:
            fragments.append(("class:dim", f"  Marketplace: {marketplace}\n"))
        enabled = info.get("enabled", True)
        status = "Enabled" if enabled else "Disabled"
        fragments.append(("class:dim", f"  Status: {status}\n"))
        fragments.append(("", "\n"))
        fragments.append(("bold", "  Actions:\n"))
        for idx, action in enumerate(self._detail_actions):
            cursor = ">" if idx == self._detail_cursor else " "
            style = "bold" if idx == self._detail_cursor else ""
            fragments.append((style, f"  {cursor} {action}\n"))
        return fragments

    def _render_list(self) -> list[tuple[str, str]]:
        fragments: list[tuple[str, str]] = []

        if self._status_message:
            fragments.append(("class:plugin.hint", f"  {self._status_message}"))
            fragments.append(("", "\n"))

        fragments.append(("", "\n"))

        if not self._items:
            fragments.append(("class:dim", "  No plugins installed."))
            fragments.append(("", "\n"))
            return fragments

        for flat_idx, item in enumerate(self._items):
            if item.get("is_header"):
                label = item.get("label", "")
                fragments.append(("bold", f"  {HEAVY_HORIZONTAL * 2} {label} {HEAVY_HORIZONTAL * 2}"))
                fragments.append(("", "\n"))
                continue

            # 判断是否为光标所在行
            is_cursor = (
                self._nav_indices[self._nav_cursor] == flat_idx
                if self._nav_indices
                else False
            )
            cursor_str = "> " if is_cursor else "  "

            name = item.get("name", "unknown")
            version = item.get("version", "")
            marketplace = item.get("marketplace", "")
            enabled = item.get("enabled", True)

            version_str = f"  v{version}" if version else ""
            mkt_str = f"  ({marketplace})" if marketplace else ""

            if enabled:
                label_str = f"{cursor_str}{EFFORT_HIGH} {name}{version_str}{mkt_str}"
                style = "bold" if is_cursor else ""
            else:
                label_str = f"{cursor_str}{EFFORT_LOW} {name}{version_str}{mkt_str}  (disabled)"
                style = "class:dim"

            fragments.append((style, label_str))
            fragments.append(("", "\n"))

        return fragments

    def _render_confirm_uninstall(self) -> list[tuple[str, str]]:
        item = self._current_item()
        name = item.get("name", "unknown") if item else "unknown"
        fragments: list[tuple[str, str]] = []
        fragments.append(("bold", f"  Uninstall {name}?"))
        fragments.append(("", "\n"))
        fragments.append(("class:plugin.hint", "  Enter: confirm | Esc: cancel"))
        fragments.append(("", "\n"))
        return fragments

    # ------------------------------------------------------------------
    # 导航
    # ------------------------------------------------------------------

    def handle_up(self) -> None:
        if self._state == "LIST":
            if self._nav_indices:
                self._nav_cursor = (self._nav_cursor - 1) % len(self._nav_indices)
        elif self._state == "DETAIL":
            if self._detail_actions:
                self._detail_cursor = (self._detail_cursor - 1) % len(self._detail_actions)

    def handle_down(self) -> None:
        if self._state == "LIST":
            if self._nav_indices:
                self._nav_cursor = (self._nav_cursor + 1) % len(self._nav_indices)
        elif self._state == "DETAIL":
            if self._detail_actions:
                self._detail_cursor = (self._detail_cursor + 1) % len(self._detail_actions)

    # ------------------------------------------------------------------
    # 动作
    # ------------------------------------------------------------------

    def handle_space(self) -> None:
        """no-op（Installed 标签无多选需求）。"""

    def handle_enter(self) -> None:
        """LIST 态：进入详情；DETAIL 态：执行选中操作；CONFIRM_UNINSTALL 态：确认卸载。"""
        if self._state == "CONFIRM_UNINSTALL":
            self._execute_uninstall()
            return

        if self._state == "LIST":
            item = self._current_item()
            if item is None:
                return
            self._detail_item = item
            enabled = item.get("enabled", True)
            self._detail_actions = [
                "Disable" if enabled else "Enable",
                "Update",
                "Uninstall",
                "Back",
            ]
            self._detail_cursor = 0
            self._state = "DETAIL"
            logger.debug("InstalledTab: enter DETAIL for %s", item.get("name"))
            return

        # DETAIL 态
        action = self._detail_actions[self._detail_cursor] if self._detail_actions else None
        if action is None:
            return

        if action == "Back":
            self._state = "LIST"
            return

        if action in ("Enable", "Disable"):
            self._execute_enable_toggle_from_detail()
        elif action == "Update":
            item = self._detail_item
            if item:
                self._schedule_update(item)
                self._status_message = f"Updating {item.get('name', '')}..."
            self._state = "LIST"
        elif action == "Uninstall":
            self._state = "LIST"
            self.handle_uninstall()

    def handle_uninstall(self) -> None:
        """'x' 键：进入卸载确认态。"""
        if self._state != "LIST":
            return
        item = self._current_item()
        if item is None:
            return
        self._state = "CONFIRM_UNINSTALL"
        logger.debug("InstalledTab: enter CONFIRM_UNINSTALL for %s", item.get("name"))

    def handle_update(self) -> None:
        """'u' 键：异步触发更新当前插件（LIST 态）。"""
        if self._state != "LIST":
            return
        item = self._current_item()
        if item is None:
            return
        self._schedule_update(item)

    def go_back(self) -> bool:
        """Esc：DETAIL/CONFIRM_UNINSTALL 态返回 LIST；LIST 态不处理。"""
        if self._state in ("DETAIL", "CONFIRM_UNINSTALL"):
            prev_state = self._state
            self._state = "LIST"
            logger.debug("InstalledTab: go_back to LIST from %s", prev_state)
            return True
        return False

    # ------------------------------------------------------------------
    # 内部逻辑
    # ------------------------------------------------------------------

    def _toggle_enabled(self, item: dict) -> None:
        """同步切换 enable/disable 并刷新列表。"""
        plugin_key = item.get("plugin_key", "")
        scope = item.get("scope", "user")
        project_path = item.get("project_path")
        enabled = item.get("enabled", True)
        name = item.get("name", plugin_key)
        msg = ""
        try:
            if enabled:
                self._plugin_mgr.disable(plugin_key, scope=scope, project_path=project_path)
                logger.info("InstalledTab: disabled %s", plugin_key)
                msg = f"Disabled: {name}"
            else:
                self._plugin_mgr.enable(plugin_key, scope=scope, project_path=project_path)
                logger.info("InstalledTab: enabled %s", plugin_key)
                msg = f"Enabled: {name}"
        except Exception as exc:
            msg = f"Failed: {exc}"
            logger.error("InstalledTab: toggle enable failed for %s: %s", plugin_key, exc)
        # 刷新列表以反映最新状态（activate 会清空 _status_message，所以在之后恢复）
        self.activate()
        self._status_message = msg

    def _execute_enable_toggle_from_detail(self) -> None:
        """从 DETAIL 态执行 enable/disable，完成后返回 LIST。"""
        item = self._detail_item
        if not item:
            self._state = "LIST"
            return
        self._state = "LIST"
        self._toggle_enabled(item)

    def _execute_uninstall(self) -> None:
        """执行异步卸载，完成后刷新列表。"""
        item = self._current_item()
        if item is None:
            self._state = "LIST"
            return
        self._state = "LIST"
        self._schedule_uninstall(item)

    def _schedule_uninstall(self, item: dict) -> None:
        """调度异步卸载任务，存储 Task 引用防止 GC 回收。"""
        plugin_key = item.get("plugin_key", "")
        task = asyncio.create_task(self._do_uninstall(plugin_key, item))
        self._update_tasks.append(task)
        task.add_done_callback(self._on_task_done)

    def _schedule_update(self, item: dict) -> None:
        """调度异步更新任务，存储 Task 引用防止 GC 回收。"""
        plugin_key = item.get("plugin_key", "")
        task = asyncio.create_task(self._do_update(plugin_key, item))
        self._update_tasks.append(task)
        task.add_done_callback(self._on_task_done)

    def _on_task_done(self, task: asyncio.Task[None]) -> None:
        """任务完成后清理引用并触发 UI 重绘。"""
        if task in self._update_tasks:
            self._update_tasks.remove(task)
        app = get_app_or_none()
        if app is not None:
            app.invalidate()

    async def _do_uninstall(self, plugin_key: str, item: dict) -> None:
        """执行卸载操作，完成后刷新列表。"""
        name = item.get("name", plugin_key)
        scope = item.get("scope", "user")
        project_path = item.get("project_path")
        logger.info("InstalledTab._do_uninstall: uninstalling %s (scope=%s)", plugin_key, scope)
        msg = ""
        try:
            await self._plugin_mgr.uninstall(plugin_key, scope=scope, project_path=project_path)
            msg = f"Uninstalled: {name}"
            logger.info("InstalledTab._do_uninstall: uninstalled %s successfully", plugin_key)
        except Exception as exc:
            msg = f"Failed to uninstall {name}: {exc}"
            logger.error(
                "InstalledTab._do_uninstall: failed to uninstall %s: %s", plugin_key, exc
            )
        # activate 会清空 _status_message，在之后恢复
        self.activate()
        self._status_message = msg

    async def _do_update(self, plugin_key: str, item: dict) -> None:
        """执行更新操作，完成后刷新列表。"""
        name = item.get("name", plugin_key)
        logger.info("InstalledTab._do_update: updating %s", plugin_key)
        msg = ""
        try:
            await self._plugin_mgr.update(plugin_key)
            msg = f"Updated: {name}"
            logger.info("InstalledTab._do_update: updated %s successfully", plugin_key)
        except Exception as exc:
            msg = f"Failed to update {name}: {exc}"
            logger.error("InstalledTab._do_update: failed to update %s: %s", plugin_key, exc)
        # activate 会清空 _status_message，在之后恢复
        self.activate()
        self._status_message = msg
