"""Errors 标签 — 显示插件加载错误。

支持：
  - 列表展示 PluginError 条目
  - Enter 进入详情，选择 Retry / Dismiss / Back 操作
  - Esc 从详情返回列表
  - 文本过滤（apply_filter）
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Literal

from prompt_toolkit.application.current import get_app_or_none

from comate_cli.terminal_agent.figures import CROSS_MARK

if TYPE_CHECKING:
    from comate_agent_sdk.plugins import PluginLoader, PluginRegistry
    from comate_agent_sdk.plugins.models import PluginError

logger = logging.getLogger(__name__)

_State = Literal["LIST", "DETAIL"]


class ErrorsTab:
    """Errors 标签：展示插件加载错误，支持重试和忽略。"""

    def __init__(
        self,
        loader: PluginLoader,
        registry: PluginRegistry,
    ) -> None:
        self._loader = loader
        self._registry = registry

        # 可变错误列表（由外部调用 set_errors 填充）
        self._errors: list[PluginError] = []
        self._cursor: int = 0

        # 过滤后的列表（None = 无过滤）
        self._filtered_errors: list[PluginError] | None = None

        # 状态机
        self._state: _State = "LIST"
        self._detail_item: dict | None = None
        self._detail_cursor: int = 0
        self._detail_actions: list[str] = ["Retry", "Dismiss", "Back"]

        # 状态消息（inline 提示）
        self._status_message: str = ""

        # 跟踪正在执行的异步任务，防止 GC 回收
        self._tasks: list[asyncio.Task[None]] = []

    # ------------------------------------------------------------------
    # 外部接口
    # ------------------------------------------------------------------

    def set_errors(self, errors: list[PluginError]) -> None:
        """由外部（如 PluginPickerUI 或 loader）填充错误列表。"""
        self._errors = list(errors)
        self._filtered_errors = None
        self._cursor = 0
        logger.debug("ErrorsTab.set_errors: %d errors", len(self._errors))

    @property
    def error_count(self) -> int:
        """当前错误数量（用于 tab bar badge 显示）。"""
        return len(self._errors)

    # ------------------------------------------------------------------
    # 激活
    # ------------------------------------------------------------------

    def activate(self) -> None:
        """标签被激活：修正 cursor 越界，清空状态消息，重置到 LIST 状态。"""
        logger.debug("ErrorsTab.activate: %d errors", len(self._errors))
        self._state = "LIST"
        errors = self._visible_errors
        if self._cursor >= len(errors):
            self._cursor = max(0, len(errors) - 1)
        self._status_message = ""

    # ------------------------------------------------------------------
    # 可见列表
    # ------------------------------------------------------------------

    @property
    def _visible_errors(self) -> list:
        return self._filtered_errors if self._filtered_errors is not None else self._errors

    # ------------------------------------------------------------------
    # 当前条目
    # ------------------------------------------------------------------

    def _current_error(self) -> PluginError | None:
        errors = self._visible_errors
        if not errors:
            return None
        return errors[self._cursor]

    # ------------------------------------------------------------------
    # 渲染
    # ------------------------------------------------------------------

    def _render_detail(self) -> list[tuple[str, str]]:
        if not self._detail_item:
            return [("class:dim", "  No error selected")]
        fragments: list[tuple[str, str]] = []
        info = self._detail_item
        fragments.append(("bold", f"  {info.get('name', 'unknown')}\n"))
        error_type = info.get("source", "")
        if error_type:
            fragments.append(("class:error", f"  Error type: {error_type}\n"))
        description = info.get("description", "")
        if description:
            fragments.append(("", f"\n  {description}\n"))
        fragments.append(("", "\n"))
        fragments.append(("bold", "  Actions:\n"))
        for idx, action in enumerate(self._detail_actions):
            cursor = ">" if idx == self._detail_cursor else " "
            style = "bold" if idx == self._detail_cursor else ""
            fragments.append((style, f"  {cursor} {action}\n"))
        return fragments

    def get_formatted_text(self) -> list[tuple[str, str]]:
        """返回 prompt_toolkit style tuples。"""
        if self._state == "DETAIL":
            return self._render_detail()

        fragments: list[tuple[str, str]] = []

        if self._status_message:
            fragments.append(("class:plugin.hint", f"  {self._status_message}"))
            fragments.append(("", "\n"))

        fragments.append(("", "\n"))

        errors = self._visible_errors
        if not errors:
            fragments.append(("class:dim", "  No plugin errors."))
            fragments.append(("", "\n"))
            return fragments

        for idx, error in enumerate(errors):
            is_cursor = idx == self._cursor
            cursor_str = "> " if is_cursor else "  "
            style = "bold" if is_cursor else ""

            # 主行：✗ plugin_key  [error_type]
            label = f"{cursor_str}{CROSS_MARK} {error.plugin_key}  [{error.error_type}]"
            fragments.append((style, label))
            fragments.append(("", "\n"))

            # 错误消息（缩进）
            msg_preview = error.message[:80] + "..." if len(error.message) > 80 else error.message
            fragments.append(("class:dim", f"     {msg_preview}"))
            fragments.append(("", "\n"))

        return fragments

    # ------------------------------------------------------------------
    # 导航
    # ------------------------------------------------------------------

    def handle_up(self) -> None:
        if self._state == "LIST":
            errors = self._visible_errors
            if errors:
                self._cursor = (self._cursor - 1) % len(errors)
        elif self._state == "DETAIL":
            if self._detail_actions:
                self._detail_cursor = (self._detail_cursor - 1) % len(self._detail_actions)

    def handle_down(self) -> None:
        if self._state == "LIST":
            errors = self._visible_errors
            if errors:
                self._cursor = (self._cursor + 1) % len(errors)
        elif self._state == "DETAIL":
            if self._detail_actions:
                self._detail_cursor = (self._detail_cursor + 1) % len(self._detail_actions)

    # ------------------------------------------------------------------
    # 动作
    # ------------------------------------------------------------------

    def handle_enter(self) -> None:
        if self._state == "LIST":
            error = self._current_error()
            if error is None:
                return
            self._detail_item = {
                "name": error.plugin_key,
                "description": error.message,
                "source": error.error_type,
            }
            self._detail_actions = ["Retry", "Dismiss", "Back"]
            self._detail_cursor = 0
            self._state = "DETAIL"
            return
        # DETAIL 状态
        action = self._detail_actions[self._detail_cursor] if self._detail_actions else None
        if action == "Back":
            self._state = "LIST"
        elif action == "Retry":
            self._state = "LIST"
            self.handle_retry()
        elif action == "Dismiss":
            self._state = "LIST"
            self.handle_dismiss()

    def handle_retry(self) -> None:
        """重试当前错误的插件加载。"""
        error = self._current_error()
        if error is None:
            return
        self._schedule_retry(error)
        self._status_message = f"Retrying {error.plugin_key}..."
        logger.debug("ErrorsTab.handle_retry: retrying %s", error.plugin_key)

    def handle_dismiss(self) -> None:
        """忽略当前错误（从内存列表中移除）。"""
        errors = self._visible_errors
        if not errors:
            return
        error = errors[self._cursor]
        # 从全量列表中移除
        self._errors = [e for e in self._errors if e.error_id != error.error_id]
        # 清空过滤列表，让其下次重新计算（或由调用方重新 apply_filter）
        self._filtered_errors = None
        # 修正 cursor 越界
        visible = self._visible_errors
        if self._cursor >= len(visible):
            self._cursor = max(0, len(visible) - 1)
        logger.info("ErrorsTab.handle_dismiss: dismissed error %s", error.error_id)

    def go_back(self) -> bool:
        """Esc：DETAIL → LIST 返回 True；LIST 状态返回 False 由 App 处理退出。"""
        if self._state == "DETAIL":
            self._state = "LIST"
            return True
        return False

    # ------------------------------------------------------------------
    # 统一接口（与其他 Tab 对齐）
    # ------------------------------------------------------------------

    def get_cursor_info(self) -> tuple[int, int] | None:
        errors = self._visible_errors
        if not errors:
            return None
        return (self._cursor + 1, len(errors))

    def get_footer_hint(self) -> str:
        if self._state == "DETAIL":
            return "Up/Down: navigate | Enter: select action | Esc: back to list"
        return "Tab: switch tabs | type to search | Enter: details | Esc: back"

    def is_searchable(self) -> bool:
        return self._state == "LIST"

    def apply_filter(self, query: str) -> None:
        q = query.strip().lower()
        if not q:
            self._filtered_errors = None
            self._cursor = 0
            return
        self._filtered_errors = [e for e in self._errors if q in e.plugin_key.lower()]
        self._cursor = 0

    # ------------------------------------------------------------------
    # 内部逻辑
    # ------------------------------------------------------------------

    def _schedule_retry(self, error: PluginError) -> None:
        task = asyncio.create_task(self._do_retry(error))
        self._tasks.append(task)
        task.add_done_callback(self._on_task_done)

    def _on_task_done(self, task: asyncio.Task[None]) -> None:
        """任务完成后清理引用并触发 UI 重绘。"""
        if task in self._tasks:
            self._tasks.remove(task)
        app = get_app_or_none()
        if app is not None:
            app.invalidate()

    async def _do_retry(self, error: PluginError) -> None:
        """重新尝试加载失败的插件。成功后从 _errors 中移除该条目。"""
        plugin_key = error.plugin_key
        logger.info("ErrorsTab._do_retry: retrying %s", plugin_key)
        try:
            # 从 registry 中找到安装路径
            installed = self._registry.list_installed()
            install_path = None
            for key, entries in installed.items():
                if key == plugin_key:
                    for entry in entries:
                        install_path = entry.install_path
                        break
                    break

            if install_path is None:
                self._status_message = f"Cannot retry {plugin_key}: install path not found"
                logger.warning("ErrorsTab._do_retry: install path not found for %s", plugin_key)
                return

            self._loader.load_from_path(install_path, source_type="registry")
            # 成功 → 从错误列表中移除
            self._errors = [e for e in self._errors if e.error_id != error.error_id]
            if self._cursor >= len(self._errors):
                self._cursor = max(0, len(self._errors) - 1)
            self._status_message = f"Loaded: {plugin_key}"
            logger.info("ErrorsTab._do_retry: successfully loaded %s", plugin_key)
        except Exception as exc:
            self._status_message = f"Failed: {exc}"
            logger.error("ErrorsTab._do_retry: failed to load %s: %s", plugin_key, exc)
