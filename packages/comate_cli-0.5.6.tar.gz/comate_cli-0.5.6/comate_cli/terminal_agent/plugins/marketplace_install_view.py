"""Marketplace 安装面板 — 轻量级 TUI 组件。

状态机：
  CONFIRM  - 显示待安装 repo，等待用户确认（Enter/Esc）
  LOADING  - 正在 git clone，显示进度（Esc 可取消）
  DONE     - 安装完成（由调用方自动退出面板）
  ERROR    - 安装失败，显示错误信息（Esc 退出）
"""

from __future__ import annotations

import asyncio
import logging
import shutil
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from prompt_toolkit.application.current import get_app_or_none
from prompt_toolkit.layout.containers import Window
from prompt_toolkit.layout.controls import FormattedTextControl

if TYPE_CHECKING:
    from comate_agent_sdk.plugins import MarketplaceManager, PluginRegistry

logger = logging.getLogger(__name__)

_State = Literal["CONFIRM", "LOADING", "DONE", "ERROR"]

# 面板固定高度（含上下边框 + footer hint 行）
_PANEL_HEIGHT = 15

# 边框字符
_H = "\u2500"  # ─
_TL = "\u256d"  # ╭
_TR = "\u256e"  # ╮
_BL = "\u2570"  # ╰
_BR = "\u256f"  # ╯
_V = "\u2502"  # │


@dataclass(slots=True)
class MarketplaceInstallResult:
    """安装面板返回结果。"""

    installed: bool = False
    marketplace_name: str = ""


class MarketplaceInstallView:
    """轻量 marketplace 安装面板，嵌入主 TUI 底部交互带。"""

    def __init__(self) -> None:
        self._repo: str = ""
        self._state: _State = "CONFIRM"
        self._error_message: str = ""
        self._result = MarketplaceInstallResult()
        self._task: asyncio.Task[None] | None = None

        # 依赖注入（enter 时设置）
        self._mkt_mgr: MarketplaceManager | None = None
        self._registry: PluginRegistry | None = None

        # 安装完成后的回调（由调用方通过 enter() 设置）
        self._on_done: callable | None = None

        # layout 组件
        self._content_window = Window(
            content=FormattedTextControl(self._render, focusable=True),
            height=_PANEL_HEIGHT,
            dont_extend_height=True,
            always_hide_cursor=True,
        )

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------

    def enter(
        self,
        repo: str,
        mkt_mgr: MarketplaceManager,
        registry: PluginRegistry,
        on_done: callable | None = None,
    ) -> None:
        """初始化面板状态，准备显示。

        Args:
            on_done: 安装成功后自动调用的回调，用于关闭面板并输出 scrollback 消息。
        """
        self._repo = repo
        self._mkt_mgr = mkt_mgr
        self._registry = registry
        self._on_done = on_done
        self._state = "CONFIRM"
        self._error_message = ""
        self._result = MarketplaceInstallResult()
        self._task = None

    @property
    def container(self) -> Window:
        return self._content_window

    def focus_target(self) -> Window:
        return self._content_window

    def take_result(self) -> MarketplaceInstallResult:
        result = self._result
        self._result = MarketplaceInstallResult()
        return result

    # ------------------------------------------------------------------
    # 事件处理
    # ------------------------------------------------------------------

    def handle_enter(self) -> bool:
        """Enter 键：CONFIRM 态启动安装。返回 True 表示面板应关闭。"""
        if self._state == "CONFIRM":
            self._start_install()
            return False
        if self._state == "DONE":
            return True
        return False

    def handle_escape(self) -> bool:
        """Esc 键：取消/退出。返回 True 表示面板应关闭。"""
        if self._state == "CONFIRM":
            return True
        if self._state == "LOADING":
            self._cancel_install()
            return True
        if self._state in ("DONE", "ERROR"):
            return True
        return False

    # ------------------------------------------------------------------
    # 安装逻辑
    # ------------------------------------------------------------------

    def _start_install(self) -> None:
        """启动异步安装任务。"""
        self._state = "LOADING"
        self._task = asyncio.create_task(self._do_install())
        self._task.add_done_callback(self._on_task_done)

    def _cancel_install(self) -> None:
        """取消正在进行的安装并清理半成品目录。"""
        if self._task and not self._task.done():
            self._task.cancel()
        # 清理可能残留的 clone 目录
        if self._registry:
            name = self._repo.split("/")[-1]
            dest = self._registry.base_dir / "marketplaces" / name
            if dest.exists():
                shutil.rmtree(dest, ignore_errors=True)
                logger.info("Cleaned up partial clone: %s", dest)
        self._state = "CONFIRM"

    async def _do_install(self) -> None:
        """执行安装：git clone + 注册。"""
        try:
            info = await self._mkt_mgr.add(self._repo)
            self._result = MarketplaceInstallResult(
                installed=True,
                marketplace_name=info.name,
            )
            self._state = "DONE"
            logger.info("Marketplace installed: %s", info.name)
        except asyncio.CancelledError:
            logger.info("Marketplace install cancelled: %s", self._repo)
            raise
        except Exception as exc:
            self._error_message = str(exc)
            self._state = "ERROR"
            logger.error("Marketplace install failed: %s: %s", self._repo, exc)

    def _on_task_done(self, task: asyncio.Task[None]) -> None:
        self._task = None
        # 安装成功：自动关闭面板
        if self._state == "DONE" and self._on_done is not None:
            self._on_done()
        app = get_app_or_none()
        if app is not None:
            app.invalidate()

    # ------------------------------------------------------------------
    # 渲染
    # ------------------------------------------------------------------

    def _render(self) -> list[tuple[str, str]]:
        """根据当前状态渲染带边框的面板。"""
        # 计算终端宽度
        app = get_app_or_none()
        width = 80
        if app is not None:
            try:
                width = app.output.get_size().columns
            except Exception:
                pass
        # 面板内容宽度（扣除左右边框各 1 字符 + 各 1 空格 padding）
        inner_w = width - 4
        if inner_w < 20:
            inner_w = 20

        lines = self._build_content_lines(inner_w)

        # 填充到固定行数（上下边框各 1 行 + footer 1 行 = 3 行开销）
        content_lines = _PANEL_HEIGHT - 3
        while len(lines) < content_lines:
            lines.append([])

        fragments: list[tuple[str, str]] = []

        # 顶部边框
        fragments.append(("class:plugin.divider", f"{_TL}{_H * (width - 2)}{_TR}"))
        fragments.append(("", "\n"))

        # 内容行
        for line_frags in lines[:content_lines]:
            fragments.append(("class:plugin.divider", f"{_V} "))
            line_len = sum(len(text) for _, text in line_frags)
            for style, text in line_frags:
                fragments.append((style, text))
            pad = inner_w - line_len
            if pad > 0:
                fragments.append(("", " " * pad))
            fragments.append(("class:plugin.divider", f" {_V}"))
            fragments.append(("", "\n"))

        # 底部边框
        fragments.append(("class:plugin.divider", f"{_BL}{_H * (width - 2)}{_BR}"))
        fragments.append(("", "\n"))

        # footer hint
        if self._state == "CONFIRM":
            fragments.append(("class:dim", "   Enter to add \u00b7 Esc to cancel"))
        elif self._state == "LOADING":
            fragments.append(("class:dim", "   Esc to cancel"))
        elif self._state == "ERROR":
            fragments.append(("class:dim", "   Esc to close"))

        return fragments

    def _build_content_lines(self, inner_w: int) -> list[list[tuple[str, str]]]:
        """构建面板内容行（不含边框）。"""
        lines: list[list[tuple[str, str]]] = []

        # 标题
        lines.append([("bold", "Add Marketplace")])
        lines.append([])  # 空行

        if self._state == "CONFIRM":
            lines.append([("", "Enter marketplace source:")])
            lines.append([("class:dim", "Examples:")])
            lines.append([("class:dim", " \u00b7 owner/repo (GitHub)")])
            lines.append([("class:dim", " \u00b7 git@github.com:owner/repo.git (SSH)")])
            lines.append([("class:dim", " \u00b7 https://example.com/marketplace.json")])
            lines.append([("class:dim", " \u00b7 ./path/to/marketplace")])
            lines.append([])  # 空行
            lines.append([("bold", self._repo)])

        elif self._state == "LOADING":
            lines.append([("", "Enter marketplace source:")])
            lines.append([("class:dim", "Examples:")])
            lines.append([("class:dim", " \u00b7 owner/repo (GitHub)")])
            lines.append([("class:dim", " \u00b7 git@github.com:owner/repo.git (SSH)")])
            lines.append([("class:dim", " \u00b7 https://example.com/marketplace.json")])
            lines.append([("class:dim", " \u00b7 ./path/to/marketplace")])
            lines.append([])  # 空行
            lines.append([("bold", self._repo)])
            lines.append([])  # 空行
            lines.append([
                ("class:plugin.hint", "\u273d Cloning repository (timeout: 120s): "),
                ("", f"https://github.com/{self._repo}.git"),
            ])

        elif self._state == "DONE":
            lines.append([("bold", f"Successfully added: {self._result.marketplace_name}")])

        elif self._state == "ERROR":
            lines.append([("class:error", f"Failed to add {self._repo}:")])
            lines.append([("class:error", self._error_message[:inner_w])])

        return lines
