from __future__ import annotations

import time
import unittest
from unittest.mock import patch

from comate_cli.terminal_agent.status_bar import StatusBar


class _FakeSession:
    """Minimal stub so StatusBar.__init__ does not need a real ChatSession."""
    class _agent:
        class llm:
            model = "test-model"


def _make_status_bar() -> StatusBar:
    with patch.object(StatusBar, "_resolve_git_branch", return_value="main"):
        return StatusBar(_FakeSession())  # type: ignore[arg-type]


class TestStatusBarTransient(unittest.TestCase):
    def test_show_transient_sets_message(self) -> None:
        sb = _make_status_bar()
        assert sb.transient_message is None
        assert sb.has_transient is False

        sb.show_transient("hello", duration_s=5.0)

        assert sb.transient_message == "hello"
        assert sb.has_transient is True

    def test_clear_transient_if_expired_returns_false_when_no_message(self) -> None:
        sb = _make_status_bar()
        assert sb.clear_transient_if_expired() is False

    def test_clear_transient_if_expired_returns_false_while_active(self) -> None:
        sb = _make_status_bar()
        sb.show_transient("active", duration_s=10.0)
        assert sb.clear_transient_if_expired() is False
        assert sb.has_transient is True

    def test_clear_transient_if_expired_returns_true_and_clears_when_expired(self) -> None:
        sb = _make_status_bar()
        sb.show_transient("expired", duration_s=0.0)
        # duration_s=0.0 means it expires immediately at monotonic() + 0.0
        # Give a tiny margin
        time.sleep(0.01)
        assert sb.clear_transient_if_expired() is True
        assert sb.transient_message is None
        assert sb.has_transient is False

    def test_show_transient_overwrites_previous(self) -> None:
        sb = _make_status_bar()
        sb.show_transient("first", duration_s=10.0)
        sb.show_transient("second", duration_s=10.0)
        assert sb.transient_message == "second"

    def test_show_transient_default_severity_is_info(self) -> None:
        sb = _make_status_bar()
        sb.show_transient("hello")
        assert sb.transient_severity == "info"

    def test_show_transient_with_error_severity(self) -> None:
        sb = _make_status_bar()
        sb.show_transient("fail", severity="error")
        assert sb.transient_message == "fail"
        assert sb.transient_severity == "error"

    def test_show_transient_with_warning_severity(self) -> None:
        sb = _make_status_bar()
        sb.show_transient("warn", severity="warning")
        assert sb.transient_severity == "warning"

    def test_transient_severity_returns_info_when_no_message(self) -> None:
        sb = _make_status_bar()
        assert sb.transient_severity == "info"

    def test_clear_transient_resets_severity(self) -> None:
        sb = _make_status_bar()
        sb.show_transient("err", duration_s=0.0, severity="error")
        import time; time.sleep(0.01)
        sb.clear_transient_if_expired()
        assert sb.transient_severity == "info"


if __name__ == "__main__":
    unittest.main(verbosity=2)
