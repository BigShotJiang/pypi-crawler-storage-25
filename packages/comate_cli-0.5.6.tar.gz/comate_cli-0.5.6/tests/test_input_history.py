from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from prompt_toolkit.buffer import Buffer
from prompt_toolkit.document import Document
from prompt_toolkit.history import FileHistory, InMemoryHistory


class TestGetInputHistoryPath(unittest.TestCase):
    def test_slug_basic_path(self) -> None:
        from comate_cli.terminal_agent.tui import _get_input_history_path
        with patch("comate_cli.terminal_agent.tui._INPUT_HISTORY_DIR", Path(tempfile.mkdtemp())):
            path = _get_input_history_path("/Users/andy/works/agent-sdk")
            self.assertEqual(path.name, "Users_andy_works_agent-sdk.txt")

    def test_slug_long_path_uses_hash(self) -> None:
        from comate_cli.terminal_agent.tui import _get_input_history_path
        with patch("comate_cli.terminal_agent.tui._INPUT_HISTORY_DIR", Path(tempfile.mkdtemp())):
            long_cwd = "/" + "/".join(f"segment{i}" for i in range(60))
            path = _get_input_history_path(long_cwd)
            self.assertTrue(len(path.stem) <= 109)  # 100 chars + _ + 8 hex
            self.assertTrue(path.name.endswith(".txt"))

    def test_slug_windows_path(self) -> None:
        """Windows paths with backslashes and drive letter produce a safe slug."""
        from comate_cli.terminal_agent.tui import _get_input_history_path
        with patch("comate_cli.terminal_agent.tui._INPUT_HISTORY_DIR", Path(tempfile.mkdtemp())):
            path = _get_input_history_path(r"C:\Users\ligj\projects\agent-sdk")
            # Colon, backslashes all replaced; no absolute-path hijacking
            self.assertEqual(path.name, "C__Users_ligj_projects_agent-sdk.txt")
            self.assertTrue(str(path).startswith(str(path.parent)))

    def test_creates_parent_directory(self) -> None:
        from comate_cli.terminal_agent.tui import _get_input_history_path
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "subdir" / "history"
            with patch("comate_cli.terminal_agent.tui._INPUT_HISTORY_DIR", target):
                path = _get_input_history_path("/some/path")
                self.assertTrue(path.parent.exists())


class TestTruncateFileHistory(unittest.TestCase):
    def _write_entries(self, path: Path, count: int) -> None:
        """Write N fake FileHistory entries (single-line)."""
        with open(path, "w") as f:
            for i in range(count):
                f.write(f"+entry {i}\n\n")

    def test_truncate_removes_old_entries(self) -> None:
        from comate_cli.terminal_agent.tui import _truncate_file_history
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            path = Path(f.name)
        self._write_entries(path, 250)
        _truncate_file_history(path, max_entries=200)
        content = path.read_text()
        blocks = [b for b in content.split("\n\n") if b.strip()]
        self.assertEqual(len(blocks), 200)
        self.assertIn("entry 50", content)
        self.assertNotIn("entry 49", content)

    def test_truncate_noop_when_under_limit(self) -> None:
        from comate_cli.terminal_agent.tui import _truncate_file_history
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            path = Path(f.name)
        self._write_entries(path, 10)
        original = path.read_text()
        _truncate_file_history(path, max_entries=200)
        self.assertEqual(path.read_text(), original)

    def test_truncate_multiline_entries(self) -> None:
        """Multi-line entries (multiple + lines per block) are preserved correctly."""
        from comate_cli.terminal_agent.tui import _truncate_file_history
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            path = Path(f.name)
        with open(path, "w") as f:
            for i in range(5):
                f.write(f"+line1 of entry {i}\n+line2 of entry {i}\n\n")
        _truncate_file_history(path, max_entries=3)
        content = path.read_text()
        blocks = [b for b in content.split("\n\n") if b.strip()]
        self.assertEqual(len(blocks), 3)
        self.assertIn("entry 2", content)
        self.assertNotIn("entry 1", content)

    def test_truncate_preserves_utf8_entries(self) -> None:
        from comate_cli.terminal_agent.tui import _truncate_file_history
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "history.txt"
            history = FileHistory(str(path))
            history.append_string("hello")
            history.append_string("中文🙂")

            _truncate_file_history(path, max_entries=200)

            reloaded = list(FileHistory(str(path)).load_history_strings())
            self.assertEqual(reloaded, ["中文🙂", "hello"])

    def test_truncate_normalizes_crlf_history(self) -> None:
        from comate_cli.terminal_agent.tui import _truncate_file_history
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "history.txt"
            history = FileHistory(str(path))
            history.append_string("hello")
            history.append_string("中文")

            content = path.read_text(encoding="utf-8")
            path.write_text(content, encoding="utf-8", newline="\r\n")

            _truncate_file_history(path, max_entries=200)

            reloaded = list(FileHistory(str(path)).load_history_strings())
            self.assertEqual(reloaded, ["中文", "hello"])

    def test_truncate_nonexistent_file_is_noop(self) -> None:
        from comate_cli.terminal_agent.tui import _truncate_file_history
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "nonexistent_history_test.txt"
            _truncate_file_history(path, max_entries=200)  # Should not raise


class TestCreateInputHistory(unittest.TestCase):
    def test_create_input_history_keeps_file_history_when_truncate_fails(self) -> None:
        from comate_cli.terminal_agent.tui import TerminalAgentTUI

        tui = TerminalAgentTUI.__new__(TerminalAgentTUI)
        tui._session = type("Session", (), {"_cwd": tempfile.mkdtemp()})()

        with patch("comate_cli.terminal_agent.tui._truncate_file_history", side_effect=UnicodeDecodeError("utf-8", b"", 0, 1, "boom")):
            history = TerminalAgentTUI._create_input_history(tui)

        self.assertIsInstance(history, FileHistory)


class TestBufferResetSavesHistory(unittest.TestCase):
    """验证 buffer.reset(append_to_history=True) 正确保存输入到历史。

    这是 _clear_input_area(save_to_history=True) 的底层机制。
    """

    def test_reset_appends_text_to_history(self) -> None:
        history = InMemoryHistory()
        buf = Buffer(history=history)

        buf.text = "first command"
        buf.reset(Document(""), append_to_history=True)

        buf.text = "second command"
        buf.reset(Document(""), append_to_history=True)

        stored = history.get_strings()
        self.assertEqual(stored, ["first command", "second command"])

    def test_reset_skips_empty_text(self) -> None:
        history = InMemoryHistory()
        buf = Buffer(history=history)

        buf.text = ""
        buf.reset(Document(""), append_to_history=True)

        self.assertEqual(history.get_strings(), [])

    def test_reset_deduplicates_consecutive(self) -> None:
        history = InMemoryHistory()
        buf = Buffer(history=history)

        buf.text = "same input"
        buf.reset(Document(""), append_to_history=True)
        buf.text = "same input"
        buf.reset(Document(""), append_to_history=True)

        stored = history.get_strings()
        self.assertEqual(stored, ["same input"])

    def test_set_document_does_not_save_history(self) -> None:
        """对照组：set_document 不保存历史（这是修复前的 bug 行为）。"""
        history = InMemoryHistory()
        buf = Buffer(history=history)

        buf.text = "typed text"
        buf.set_document(Document("", cursor_position=0), bypass_readonly=True)

        self.assertEqual(history.get_strings(), [])
