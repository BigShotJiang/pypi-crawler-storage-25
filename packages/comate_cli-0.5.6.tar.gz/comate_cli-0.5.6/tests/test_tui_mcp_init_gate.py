from __future__ import annotations

import asyncio
import unittest
from contextlib import contextmanager
from typing import Any
from unittest.mock import patch

from comate_cli.terminal_agent.tui import TerminalAgentTUI


class _FakeRenderer:
    def __init__(self) -> None:
        self.messages: list[tuple[str, str | None]] = []
        self.closed = False

    def append_system_message(self, text: str, severity: str | None = None) -> None:
        self.messages.append((text, severity))

    def close(self) -> None:
        self.closed = True


class _FakeApp:
    def __init__(self, *, run_sleep_s: float) -> None:
        self._run_sleep_s = run_sleep_s

    async def run_async(self) -> None:
        await asyncio.sleep(self._run_sleep_s)


@contextmanager
def _noop_patch_stdout(*args: Any, **kwargs: Any):
    del args, kwargs
    yield


async def _async_noop() -> None:
    return None


class TestTUIMcpBackgroundInit(unittest.IsolatedAsyncioTestCase):
    async def test_run_starts_mcp_init_in_background_without_gate(self) -> None:
        tui = TerminalAgentTUI.__new__(TerminalAgentTUI)
        tui._app = _FakeApp(run_sleep_s=0.05)
        tui._renderer = _FakeRenderer()
        tui._refresh_layers = lambda: None
        tui._busy = False
        tui._closing = False
        tui._mcp_init_cancel_timeout_s = 0.05
        tui._mcp_init_task = None
        tui._ui_tick_task = None
        tui._init_plugins = lambda: _async_noop()

        async def _fake_ui_tick() -> None:
            await asyncio.Event().wait()

        tui._ui_tick = _fake_ui_tick
        started = asyncio.Event()
        cancelled = asyncio.Event()

        async def _stuck_mcp_init() -> None:
            started.set()
            try:
                await asyncio.Event().wait()
            finally:
                cancelled.set()

        with patch("comate_cli.terminal_agent.tui.patch_stdout", _noop_patch_stdout):
            await tui.run(mcp_init=_stuck_mcp_init)

        self.assertTrue(started.is_set())
        self.assertTrue(cancelled.is_set())
        self.assertIsNone(tui._mcp_init_task)
        self.assertTrue(tui._renderer.closed)
        self.assertEqual(tui._renderer.messages, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
