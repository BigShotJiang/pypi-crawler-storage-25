"""spec §8.2 端到端集成测试 (T-J 系列)。

每个 case 模拟一个完整 turn：start_turn → handle_event(...) →
StopEvent → finalize_turn。重点验证 scrollback (history) 内容
顺序与新管道行为吻合。

注意：plan 提及的 force flush 在 EventRenderer.finalize_turn() 体内
触发（不是 handle_event 的 StopEvent 分支）—— 测试中模拟 tui.py
真实序列：handle_event(StopEvent) + finalize_turn()。
"""

from __future__ import annotations

import unittest

from comate_agent_sdk.agent.events import (
    StopEvent,
    TextDeltaEvent,
    TextEvent,
    ThinkingDeltaEvent,
    ToolCallStartEvent,
)

from comate_cli.terminal_agent.event_renderer import EventRenderer


def _last_n_assistant_texts(renderer: EventRenderer, n: int) -> list[str]:
    """辅助：取最后 N 个 assistant entry 的 text，便于断言顺序。"""
    return [e.text for e in renderer._history if e.entry_type == "assistant"][-n:]


def _stream(renderer: EventRenderer, *deltas: str) -> None:
    """辅助：连续 emit 多个 TextDeltaEvent，message_id 共用 'm1'。"""
    for d in deltas:
        renderer.handle_event(TextDeltaEvent(delta=d, message_id="m1"))


def _finish_turn(renderer: EventRenderer) -> None:
    """辅助：模拟 tui.py 真实 turn 收尾序列 — handle_event(StopEvent) +
    finalize_turn（后者触发 _force_flush_all）。"""
    renderer.handle_event(StopEvent(reason="completed"))
    renderer.finalize_turn()


class TestE2E(unittest.TestCase):
    # ── T-J1：simple hello ──

    def test_j1_simple_hello(self):
        renderer = EventRenderer()
        renderer.start_turn()
        _stream(renderer, "Hello\n")
        _finish_turn(renderer)
        self.assertEqual(_last_n_assistant_texts(renderer, 1), ["Hello\n"])

    # ── T-J2：a single rendered code fence ──

    def test_j2_code_fence(self):
        renderer = EventRenderer()
        renderer.start_turn()
        _stream(renderer, "```py\n", "x=1\n", "```\n")
        _finish_turn(renderer)
        # fence 整段一次性入 _history（一条 entry）
        fence_entries = [e for e in renderer._history if "```py" in e.text]
        self.assertEqual(len(fence_entries), 1)
        self.assertEqual(fence_entries[0].text, "```py\nx=1\n```\n")

    # ── T-J3：paragraph + fence + paragraph ──

    def test_j3_para_fence_para(self):
        renderer = EventRenderer()
        renderer.start_turn()
        _stream(
            renderer,
            "Para 1\n", "\n", "```py\n", "x=1\n", "```\n", "\n", "Para 2\n",
        )
        _finish_turn(renderer)
        # 期望（按序）：Para 1\n / \n / ```py\nx=1\n```\n / \n / Para 2\n
        texts = [e.text for e in renderer._history if e.entry_type == "assistant"]
        self.assertEqual(
            texts[-5:],
            ["Para 1\n", "\n", "```py\nx=1\n```\n", "\n", "Para 2\n"],
        )

    # ── T-J4：thinking + text 顺序 ──

    def test_j4_thinking_then_text(self):
        renderer = EventRenderer()
        renderer._show_thinking_cb = lambda: True
        renderer.start_turn()
        renderer.handle_event(ThinkingDeltaEvent(delta="let me think", message_id="m1"))
        # text delta 来时会先 flush thinking batch（spec §6.1 顺序保证）
        _stream(renderer, "answer\n")
        _finish_turn(renderer)
        # 顺序保证：thinking 块在 text 行之前
        types = [
            e.entry_type for e in renderer._history
            if e.entry_type in ("thinking", "assistant")
        ]
        idx_thinking = types.index("thinking")
        idx_assistant = types.index("assistant")
        self.assertLess(idx_thinking, idx_assistant)

    # ── T-J5：tool call 与 text 交错 ──

    def test_j5_tool_text_ordering(self):
        renderer = EventRenderer()
        renderer.start_turn()
        _stream(renderer, "checking\n")
        # ToolCallStartEvent 现 trunk 签名：(tool_call_id, tool) 无 args
        renderer.handle_event(ToolCallStartEvent(tool_call_id="t1", tool="Read"))
        _stream(renderer, "result is X\n")
        _finish_turn(renderer)
        # 验证顺序：text "checking\n" → 任何 tool 状态变化 →
        # text "result is X\n"。两个 text entry 都要存在且前后顺序正确。
        try:
            idx_checking = next(
                i for i, e in enumerate(renderer._history)
                if e.text == "checking\n"
            )
            idx_result = next(
                i for i, e in enumerate(renderer._history)
                if e.text == "result is X\n"
            )
        except StopIteration:
            self.fail("expected both 'checking' and 'result is X' entries")
        self.assertLess(idx_checking, idx_result)

    # ── T-J6：interrupt 丢弃未闭合 fence ──

    def test_j6_interrupt_drops_unfinished_fence(self):
        renderer = EventRenderer()
        renderer.start_turn()
        # 开 fence 但没闭合
        _stream(renderer, "```py\n", "x=1\n")
        before_history_len = len(renderer._history)
        # 中断
        renderer.interrupt_turn()
        # 容器内未 commit 内容应被丢弃 → scrollback 无新增 fence entry
        new_entries = renderer._history[before_history_len:]
        # 仅可能新增 system warning entry，不会有 ```py 内容
        self.assertFalse(any("```py" in e.text for e in new_entries))
        # 5 个新字段全清
        self.assertEqual(renderer._text_pending, "")
        self.assertIsNone(renderer._container)

    # ── T-J7：未闭合 fence stop → synthetic close ──

    def test_j7_stop_synthetic_close_fence(self):
        renderer = EventRenderer()
        renderer.start_turn()
        # 没发 ```\n 闭合行
        _stream(renderer, "```py\n", "x=1\n")
        _finish_turn(renderer)
        # finalize_turn 内的 _force_flush_all 会把 fence_marker append
        # 作 synthetic close → scrollback 看到完整 fence
        fence_entries = [e for e in renderer._history if "```py" in e.text]
        self.assertEqual(len(fence_entries), 1)
        self.assertEqual(fence_entries[0].text, "```py\nx=1\n```\n")

    # ── T-J8：non-stream 整段 TextEvent (Q11 兜底) ──

    def test_j8_non_stream_text_event(self):
        renderer = EventRenderer()
        renderer.start_turn()
        # 不发任何 delta，直接整段 TextEvent → Q11 兜底走
        # _append_assistant_text → _flush_assistant_segment 入 history
        renderer.handle_event(TextEvent(content="full response in one shot"))
        _finish_turn(renderer)
        # legacy 路径：scrollback 看到整段
        last_assistant = [
            e for e in renderer._history if e.entry_type == "assistant"
        ][-1]
        self.assertIn("full response in one shot", last_assistant.text)


if __name__ == "__main__":
    unittest.main()
