from __future__ import annotations

import unittest

from prompt_toolkit.layout import Window

from comate_agent_sdk.agent.events import ExternalTurnScheduledEvent, StopEvent

from comate_cli.terminal_agent.tui import TerminalAgentTUI
from comate_cli.terminal_agent.question_view import AskUserQuestionUI
from comate_cli.terminal_agent.tui_parts.key_bindings import KeyBindingsMixin
from comate_cli.terminal_agent.tui_parts.ui_mode import UIMode


class _StubSelectionUI:
    def confirm(self):  # noqa: ANN201
        return None

    def move_selection(self, _delta: int) -> None:
        return None

    def cancel(self):  # noqa: ANN201
        return None

    def focus_target(self):  # noqa: ANN201
        return None


class _StubPluginUI:
    search_area_window = Window()
    content_window = Window()


class _StubRunController:
    def __init__(self) -> None:
        self.interrupt_calls: list[str] = []

    def interrupt(self, reason: str) -> None:
        self.interrupt_calls.append(reason)

    def clear(self) -> None:
        return None


class _StubSession:
    def __init__(self, events: list[object] | None = None) -> None:
        self.run_controller = _StubRunController()
        self._events = list(events or [])

    async def events(self):  # noqa: ANN202
        for event in self._events:
            yield event


class _StubRenderer:
    def __init__(self) -> None:
        self.messages: list[str] = []
        self.handle_event_calls = 0
        self.start_turn_calls = 0
        self.finalize_turn_calls = 0

    def has_active_todos(self) -> bool:
        return False

    def interrupt_turn(self) -> None:
        return None

    def start_turn(self) -> None:
        self.start_turn_calls += 1

    def finalize_turn(self) -> None:
        self.finalize_turn_calls += 1

    def append_system_message(self, text: str, severity: str | None = None) -> None:
        del severity
        self.messages.append(text)

    def append_elapsed_message(self, text: str) -> None:
        self.messages.append(text)

    def handle_event(self, event):  # noqa: ANN001, ANN201
        del event
        self.handle_event_calls += 1
        return False, None


class _StubMentionCompleter:
    def extract_context(self, _text: str):  # noqa: ANN201
        return None


class _StubAnimationController:
    def __init__(self) -> None:
        self.on_event_calls = 0
        self.start_calls = 0
        self.shutdown_calls = 0

    async def on_event(self, event) -> None:  # noqa: ANN001
        del event
        self.on_event_calls += 1

    async def start(self) -> None:
        self.start_calls += 1

    async def shutdown(self) -> None:
        self.shutdown_calls += 1


class _StubStatusBar:
    def __init__(self) -> None:
        self.refresh_calls = 0

    async def refresh(self) -> None:
        self.refresh_calls += 1

    def set_mode(self, _mode: str) -> None:
        return None

    def show_transient(self, _message: str, *, severity: str = "error") -> None:
        return None


class _StubKeyBindingHost(KeyBindingsMixin):
    def __init__(self) -> None:
        self._ui_mode = UIMode.NORMAL
        self._question_ui = AskUserQuestionUI()
        self._question_ui.set_questions(
            [
                {
                    "question": "Q",
                    "header": "H",
                    "options": [{"label": "A", "description": ""}],
                    "multiSelect": False,
                }
            ]
        )
        self._selection_ui = _StubSelectionUI()
        self._plugin_ui = _StubPluginUI()
        self._install_view = object()
        self._mcp_connecting_view = object()
        self._mention_completer = _StubMentionCompleter()
        self._busy = True
        self._initializing = False
        self._app = None
        self._stream_task = None
        self._interrupt_requested_at = None
        self._interrupt_force_window_seconds = 1.5
        self._session = _StubSession()
        self._renderer = _StubRenderer()
        self._waiting_for_input = False
        self._pending_questions = None
        self._esc_press_count = 0
        self._esc_last_pressed_at = 0.0
        self._esc_clear_window_seconds = 1.0
        self._ctrl_c_press_count = 0
        self._ctrl_c_last_pressed_at = 0.0
        self._ctrl_c_exit_window_seconds = 1.0
        self._input_area = type("InputArea", (), {"window": None})()
        self._diff_panel_visible = False
        self._todo_panel_expanded = False
        self.exit_requests = 0
        self.refresh_calls = 0

    def _handle_selection_result(self, *_args, **_kwargs) -> None:
        return None

    def _handle_plugin_action(self, *_args, **_kwargs) -> None:
        return None

    def _exit_install_view(self) -> None:
        return None

    def _invalidate(self) -> None:
        return None

    def _sync_focus_for_mode(self) -> None:
        return None

    def _handle_question_action(self, *_args, **_kwargs) -> None:
        return None

    def _submit_from_input(self) -> None:
        return None

    def _cycle_agent_mode(self) -> None:
        return None

    def _move_completion_selection(self, *_args, **_kwargs) -> bool:
        return False

    def _move_cursor_visual(self, *_args, **_kwargs) -> bool:
        return False

    def _should_handle_history(self) -> bool:
        return False

    def _clear_input_area(self, **_kw: object) -> None:
        return None

    def _set_busy(self, *_args, **_kwargs) -> None:
        return None

    def _exit_question_mode(self) -> None:
        return None

    def _refresh_layers(self) -> None:
        self.refresh_calls += 1

    def _request_exit(self) -> None:
        self.exit_requests += 1


def _is_named_key(binding, name: str) -> bool:
    if len(binding.keys) != 1:
        return False
    key_name = str(binding.keys[0]).lower()
    normalized = name.lower().replace("-", "")
    if normalized.startswith("c") and len(normalized) == 2:
        return key_name.endswith(f"control{normalized[1]}")
    return key_name.endswith(normalized)


def _find_binding(host: _StubKeyBindingHost, key_name: str):
    bindings = host._build_key_bindings().bindings
    for binding in bindings:
        if _is_named_key(binding, key_name):
            return binding
    raise AssertionError(f"Cannot find key binding for '{key_name}'.")


class TestInterruptExitSemantics(unittest.IsolatedAsyncioTestCase):
    def test_busy_second_ctrl_c_requests_exit_instead_of_force_interrupt(self) -> None:
        host = _StubKeyBindingHost()
        binding = _find_binding(host, "c-c")

        binding.handler(None)
        binding.handler(None)

        self.assertEqual(host._session.run_controller.interrupt_calls, ["user"])
        self.assertEqual(host.exit_requests, 1)
        self.assertEqual(
            host._renderer.messages,
            [
                "已发送中断信号。再次按 Ctrl+C 将强制中断。",
                "已请求退出，正在关闭会话。",
            ],
        )

    async def test_closing_tui_ignores_followup_external_turn_events(self) -> None:
        tui = TerminalAgentTUI.__new__(TerminalAgentTUI)
        tui._session = _StubSession(
            events=[
                ExternalTurnScheduledEvent(
                    turn_id="team_inbox:evt-1",
                    source="team_inbox",
                    dispatch_reason="idle_auto",
                    queue_size_remaining=0,
                )
            ]
        )
        tui._closing = True
        tui._renderer = _StubRenderer()
        tui._animation_controller = _StubAnimationController()
        tui._maybe_cancel_tool_result_flash = lambda event: None
        tui._maybe_flash_tool_result = lambda event: None
        tui._refresh_layers = lambda: None
        tui._busy = False

        await tui._consume_event_stream()

        self.assertEqual(tui._animation_controller.on_event_calls, 0)
        self.assertEqual(tui._renderer.handle_event_calls, 0)

    async def test_team_idle_auto_turn_uses_lightweight_ui_path(self) -> None:
        tui = TerminalAgentTUI.__new__(TerminalAgentTUI)
        tui._session = _StubSession(
            events=[
                ExternalTurnScheduledEvent(
                    turn_id="team_inbox:evt-1",
                    source="team_inbox",
                    dispatch_reason="idle_auto",
                    queue_size_remaining=0,
                ),
                StopEvent(reason="completed"),
            ]
        )
        tui._closing = False
        tui._renderer = _StubRenderer()
        tui._animation_controller = _StubAnimationController()
        tui._status_bar = _StubStatusBar()
        tui._maybe_cancel_tool_result_flash = lambda event: None
        tui._maybe_flash_tool_result = lambda event: None
        tui._refresh_layers = lambda: None
        tui._set_busy = lambda value: setattr(tui, "_busy", value)
        tui._busy = False
        tui._waiting_for_input = False
        tui._pending_questions = None
        tui._pending_plan_approval = None
        tui._interrupt_requested_at = None
        tui._run_start_time = None
        tui._last_turn_user_preview = None
        tui._background_turn_source = None
        tui._open_plan_approval_menu = lambda approval: None
        tui._enter_question_mode = lambda questions: None
        tui._exit_question_mode = lambda: None
        tui._append_run_elapsed_to_history = lambda stop_reason=None: None

        await tui._consume_event_stream()

        self.assertFalse(tui._busy)
        self.assertEqual(tui._renderer.start_turn_calls, 0)
        self.assertEqual(tui._renderer.finalize_turn_calls, 1)
        self.assertEqual(tui._animation_controller.start_calls, 0)
        self.assertEqual(tui._animation_controller.shutdown_calls, 0)
        self.assertEqual(tui._status_bar.refresh_calls, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
