from __future__ import annotations

import asyncio
import unittest
from types import SimpleNamespace
from typing import Any

from comate_agent_sdk.agent.chat_session import ChatSessionQueueFullError
from comate_agent_sdk.agent.events import (
    QueueDirtyEvent,
    QueueDirtyReason,
    QueuedMessageInjectedEvent,
)
from comate_agent_sdk.agent.queue_types import MessageOrigin

from comate_cli.terminal_agent.slash_commands import SlashCommandSpec
from comate_cli.terminal_agent.tui import TerminalAgentTUI, UIMode
from comate_cli.terminal_agent.tui_parts.slash_command_registry import (
    SlashCommandRegistry,
)


class _FakeBuffer:
    def __init__(self, text: str) -> None:
        self.text = text
        self.cursor_position = len(text)
        self.complete_state = None

    def cancel_completion(self) -> None:
        return None


class _FakeInputArea:
    def __init__(self, text: str) -> None:
        self.text = text
        self.buffer = _FakeBuffer(text)


class _FakeRenderer:
    def __init__(self) -> None:
        self.messages: list[tuple[str, str | None]] = []
        self.user_messages: list[str] = []
        self.turn_starts = 0

    def append_system_message(self, text: str, severity: str | None = None) -> None:
        self.messages.append((text, severity))

    def seed_user_message(self, text: str) -> None:
        self.user_messages.append(text)

    def start_turn(self) -> None:
        self.turn_starts += 1

    def handle_event(self, _event: object) -> tuple[bool, None]:
        return False, None


class _FakeSession:
    def __init__(self) -> None:
        self.sent: list[str] = []
        self.error: Exception | None = None

    async def send(self, content: str) -> str:
        if self.error is not None:
            raise self.error
        self.sent.append(content)
        return f"msg-{len(self.sent)}"


def _build_tui() -> tuple[TerminalAgentTUI, _FakeSession, _FakeRenderer]:
    tui = TerminalAgentTUI.__new__(TerminalAgentTUI)
    session = _FakeSession()
    renderer = _FakeRenderer()
    tui._session = session
    tui._renderer = renderer
    tui._busy = True
    tui._ui_mode = UIMode.NORMAL
    tui._input_area = _FakeInputArea("")
    tui._active_paste_token = None
    tui._paste_placeholder_text = None
    tui._paste_payload_by_token = {}
    tui._queued_display_by_message_id = {}
    tui._clear_input_area = lambda **_kw: None
    tui._refresh_layers = lambda: None
    tui._invalidate = lambda: None
    tui._slash_registry = SlashCommandRegistry()
    return tui, session, renderer


def _run_scheduled_immediately(tui: TerminalAgentTUI) -> list[Any]:
    scheduled: list[Any] = []

    def _schedule(coro: Any) -> None:
        scheduled.append(coro)
        asyncio.run(coro)

    tui._schedule_background = _schedule
    return scheduled


async def _noop_async() -> None:
    return None


class _FakeAnimationController:
    def __init__(self) -> None:
        self.start_calls = 0

    async def start(self) -> None:
        self.start_calls += 1

    async def on_event(self, _event: object) -> None:
        return None


class TestTUIQueueSdkSource(unittest.TestCase):
    def test_busy_text_uses_chat_session_send_instead_of_local_deque(self) -> None:
        tui, session, renderer = _build_tui()
        scheduled = _run_scheduled_immediately(tui)
        tui._input_area = _FakeInputArea("second message")

        tui._submit_from_input()

        self.assertEqual(session.sent, ["second message"])
        self.assertEqual(len(scheduled), 1)
        self.assertEqual(renderer.turn_starts, 0)
        self.assertEqual(renderer.user_messages, [])
        self.assertEqual(
            tui._queued_display_by_message_id,
            {"msg-1": "second message"},
        )

    def test_busy_text_with_leading_space_before_slash_is_sent_as_user_message(
        self,
    ) -> None:
        tui, session, renderer = _build_tui()
        scheduled = _run_scheduled_immediately(tui)
        tui._input_area = _FakeInputArea(" /help")

        tui._submit_from_input()

        self.assertEqual(session.sent, ["/help"])
        self.assertEqual(len(scheduled), 1)
        self.assertEqual(renderer.turn_starts, 0)
        self.assertEqual(renderer.user_messages, [])
        self.assertEqual(tui._queued_display_by_message_id, {"msg-1": "/help"})

    def test_busy_custom_slash_command_is_not_queued_or_sent(self) -> None:
        tui, session, renderer = _build_tui()
        scheduled = _run_scheduled_immediately(tui)
        registry = SlashCommandRegistry()
        registry.register(
            spec=SlashCommandSpec(
                name="review-config",
                description="review config",
                execution_kind="hybrid",
            ),
            handler=lambda _args: None,
            source="custom",
        )
        tui._slash_registry = registry
        tui._input_area = _FakeInputArea("/review-config package.json")

        tui._submit_from_input()

        self.assertEqual(session.sent, [])
        self.assertEqual(scheduled, [])
        self.assertTrue(renderer.messages)
        message, severity = renderer.messages[-1]
        self.assertEqual(
            message,
            "当前任务运行中，custom slash command 不能排队执行，请等待当前任务结束后再运行。",
        )
        self.assertEqual(severity, "error")

    def test_busy_queue_full_error_is_rendered_without_starting_turn(self) -> None:
        tui, session, renderer = _build_tui()
        session.error = ChatSessionQueueFullError("queue full")
        _run_scheduled_immediately(tui)
        tui._input_area = _FakeInputArea("overflow")

        tui._submit_from_input()

        self.assertEqual(session.sent, [])
        self.assertEqual(renderer.turn_starts, 0)
        self.assertTrue(renderer.messages)
        message, severity = renderer.messages[-1]
        self.assertIn("消息队列已满", message)
        self.assertEqual(severity, "error")
        self.assertEqual(renderer.user_messages, [])
        self.assertEqual(tui._queued_display_by_message_id, {})

    def test_injected_human_queue_message_is_seeded_to_scrollback(self) -> None:
        tui, _session, renderer = _build_tui()
        tui._queued_display_by_message_id = {
            "human-1": "queued one",
            "human-2": "queued two",
        }
        event = QueuedMessageInjectedEvent(
            message_ids=("human-1", "external-1", "human-2"),
            origins=(
                MessageOrigin.HUMAN,
                MessageOrigin.EXTERNAL,
                MessageOrigin.HUMAN,
            ),
            injected_at_turn=1,
            call_index=1,
            trigger_message_id="trigger-1",
        )

        class _EventSession:
            async def events(self):
                yield event

        tui._session = _EventSession()
        tui._closing = False
        tui._maybe_cancel_tool_result_flash = lambda _event: None
        tui._animation_controller = SimpleNamespace(
            on_event=lambda _event: _noop_async()
        )
        tui._maybe_flash_tool_result = lambda _event: None

        asyncio.run(tui._consume_event_stream())

        self.assertEqual(renderer.user_messages, ["queued one", "queued two"])
        self.assertEqual(tui._queued_display_by_message_id, {})

    def test_consumed_human_queue_trigger_starts_turn_and_seeds_scrollback(self) -> None:
        tui, _session, renderer = _build_tui()
        tui._busy = False
        tui._render_dirty = False
        tui._interrupt_requested_at = 1.0
        tui._waiting_for_input = True
        tui._pending_questions = [{"question": "old"}]
        tui._pending_plan_approval = {"plan_path": "old"}
        tui._run_start_time = None
        tui._last_turn_user_preview = None
        tui._queued_display_by_message_id = {"human-1": "queued one"}
        animation = _FakeAnimationController()
        event = QueueDirtyEvent(
            reason=QueueDirtyReason.CONSUMED,
            queue_size=0,
            message_ids=("human-1",),
            origins=(MessageOrigin.HUMAN,),
        )
        clear_calls = {"count": 0}

        class _EventSession:
            run_controller = SimpleNamespace(
                clear=lambda: clear_calls.__setitem__(
                    "count",
                    clear_calls["count"] + 1,
                )
            )

            async def events(self):
                yield event

        tui._session = _EventSession()
        tui._closing = False
        tui._maybe_cancel_tool_result_flash = lambda _event: None
        tui._animation_controller = animation
        tui._maybe_flash_tool_result = lambda _event: None

        asyncio.run(tui._consume_event_stream())

        self.assertEqual(renderer.turn_starts, 1)
        self.assertEqual(renderer.user_messages, ["queued one"])
        self.assertEqual(tui._queued_display_by_message_id, {})
        self.assertTrue(tui._busy)
        self.assertIsNotNone(tui._run_start_time)
        self.assertIsNone(tui._interrupt_requested_at)
        self.assertFalse(tui._waiting_for_input)
        self.assertIsNone(tui._pending_questions)
        self.assertIsNone(tui._pending_plan_approval)
        self.assertEqual(tui._last_turn_user_preview, "queued one")
        self.assertEqual(animation.start_calls, 1)
        self.assertEqual(clear_calls["count"], 1)

    def test_idle_text_still_uses_submit_user_message_path(self) -> None:
        tui, session, _renderer = _build_tui()
        tui._busy = False
        scheduled = _run_scheduled_immediately(tui)
        captured: dict[str, str | None] = {"text": None, "display_text": None}

        async def _fake_submit_user_message(
            text: str,
            *,
            display_text: str | None = None,
        ) -> None:
            captured["text"] = text
            captured["display_text"] = display_text

        tui._submit_user_message = _fake_submit_user_message
        tui._input_area = _FakeInputArea("first message")

        tui._submit_from_input()

        self.assertEqual(session.sent, [])
        self.assertEqual(len(scheduled), 1)
        self.assertEqual(
            captured,
            {"text": "first message", "display_text": "first message"},
        )

    def test_mcp_preload_marker_does_not_block_idle_submit_path(self) -> None:
        tui, session, _renderer = _build_tui()
        tui._busy = False
        # 防止回退到旧的 MCP init gate：即便旧测试替身或调用方留下这个标记，
        # submit 也只能由 busy 状态决定。
        tui._initializing = True
        scheduled = _run_scheduled_immediately(tui)
        captured: dict[str, str | None] = {"text": None, "display_text": None}

        async def _fake_submit_user_message(
            text: str,
            *,
            display_text: str | None = None,
        ) -> None:
            captured["text"] = text
            captured["display_text"] = display_text

        tui._submit_user_message = _fake_submit_user_message
        tui._input_area = _FakeInputArea("first while mcp warms")

        tui._submit_from_input()

        self.assertEqual(session.sent, [])
        self.assertEqual(len(scheduled), 1)
        self.assertEqual(
            captured,
            {
                "text": "first while mcp warms",
                "display_text": "first while mcp warms",
            },
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
