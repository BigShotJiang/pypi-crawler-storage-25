from __future__ import annotations

import io
import logging
import sys
from unittest.mock import patch

import pytest

from comate_cli.terminal_agent.logging_adapter import (
    TUILoggingHandler,
    TUILoggingSession,
    setup_tui_logging,
)


class _FakeRenderer:
    def __init__(self) -> None:
        self.messages: list[tuple[str, str]] = []

    def append_system_message(self, message: str, *, severity: str) -> None:
        self.messages.append((message, severity))


@pytest.fixture(autouse=True)
def _isolate_log_level_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """每个测试运行前重置 COMATE_LOG_LEVEL 来源，防止外部环境污染断言。

    - 清掉 os.environ 中的 COMATE_LOG_LEVEL
    - 把 settings.json 读取桩成返回空串
    - 重置 invalid-level warned flag
    这样默认就是 INFO；需要其他值的测试自己覆盖。
    """
    monkeypatch.delenv("COMATE_LOG_LEVEL", raising=False)
    monkeypatch.setattr(
        "comate_cli.terminal_agent.logging_adapter._read_level_from_settings_env",
        lambda project_root=None: "",
    )
    monkeypatch.setattr(
        "comate_cli.terminal_agent.logging_adapter._invalid_log_level_warned",
        False,
    )


def _find_file_handler(root: logging.Logger) -> logging.Handler | None:
    for handler in root.handlers:
        if not getattr(handler, "_comate_tui_logging_session", False):
            continue
        if isinstance(handler, TUILoggingHandler):
            continue
        return handler
    return None


def test_setup_tui_logging_preserves_existing_root_handlers_and_restores_them() -> None:
    root = logging.getLogger()
    original_handlers = list(root.handlers)
    original_level = root.level
    stderr_handler = logging.StreamHandler(sys.stderr)
    root.addHandler(stderr_handler)

    session: TUILoggingSession | None = None
    try:
        session = setup_tui_logging(_FakeRenderer())

        assert stderr_handler in root.handlers
        assert any(isinstance(handler, TUILoggingHandler) for handler in root.handlers)
        # 默认日志级别为 INFO；需要 DEBUG 时通过 COMATE_LOG_LEVEL 开启（见其他测试）
        assert root.level == logging.INFO
        assert len(stderr_handler.filters) == 1
    finally:
        if session is not None:
            session.close()
        if stderr_handler in root.handlers:
            root.removeHandler(stderr_handler)
        root.handlers[:] = original_handlers
        root.setLevel(original_level)

    assert stderr_handler.filters == []
    assert root.handlers == original_handlers
    assert root.level == original_level


def test_setup_tui_logging_does_not_mute_non_terminal_stream_handlers() -> None:
    root = logging.getLogger()
    original_handlers = list(root.handlers)
    original_level = root.level
    buffer_handler = logging.StreamHandler(io.StringIO())
    root.addHandler(buffer_handler)

    session: TUILoggingSession | None = None
    try:
        session = setup_tui_logging(_FakeRenderer())
        assert buffer_handler in root.handlers
        assert buffer_handler.filters == []
    finally:
        if session is not None:
            session.close()
        if buffer_handler in root.handlers:
            root.removeHandler(buffer_handler)
        root.handlers[:] = original_handlers
        root.setLevel(original_level)


def test_setup_tui_logging_replaces_stale_managed_handlers_before_installing_new_ones() -> None:
    root = logging.getLogger()
    original_handlers = list(root.handlers)
    original_level = root.level
    renderer1 = _FakeRenderer()
    renderer2 = _FakeRenderer()

    session1: TUILoggingSession | None = None
    session2: TUILoggingSession | None = None
    try:
        session1 = setup_tui_logging(renderer1)
        session2 = setup_tui_logging(renderer2)

        tui_handlers = [h for h in root.handlers if isinstance(h, TUILoggingHandler)]
        managed_handlers = [
            h for h in root.handlers if getattr(h, "_comate_tui_logging_session", False)
        ]

        assert len(tui_handlers) == 1
        assert len(managed_handlers) == 2

        logging.getLogger("test.logging").warning("duplicate-warning-check")

        assert renderer1.messages == []
        assert renderer2.messages == [("duplicate-warning-check", "warning")]
    finally:
        if session2 is not None:
            session2.close()
        if session1 is not None:
            session1.close()
        root.handlers[:] = original_handlers
        root.setLevel(original_level)


def test_tui_logging_handler_deduplicates_recent_duplicate_across_handlers() -> None:
    renderer = _FakeRenderer()
    handler1 = TUILoggingHandler(renderer)
    handler2 = TUILoggingHandler(renderer)
    record = logging.LogRecord(
        name="test.logging",
        level=logging.WARNING,
        pathname=__file__,
        lineno=1,
        msg="duplicate-warning-check",
        args=(),
        exc_info=None,
    )

    with patch(
        "comate_cli.terminal_agent.logging_adapter._recent_log_message_times",
        {},
    ):
        handler1.emit(record)
        handler2.emit(record)

    assert renderer.messages == [("duplicate-warning-check", "warning")]


def test_tui_logging_handler_does_not_wrap_run_in_terminal_with_background_task() -> None:
    renderer = _FakeRenderer()
    handler = TUILoggingHandler(renderer)
    record = logging.LogRecord(
        name="test.logging",
        level=logging.WARNING,
        pathname=__file__,
        lineno=1,
        msg="background-task-race-check",
        args=(),
        exc_info=None,
    )

    class _FakeApp:
        def create_background_task(self, _coroutine) -> None:
            raise AssertionError("create_background_task should not be called")

    def _run_in_terminal_now(func, render_cli_done=False, in_executor=False):  # type: ignore[no-untyped-def]
        assert render_cli_done is False
        assert in_executor is False
        func()
        return object()

    with (
        patch("prompt_toolkit.application.get_app", return_value=_FakeApp()),
        patch(
            "comate_cli.terminal_agent.logging_adapter.run_in_terminal",
            side_effect=_run_in_terminal_now,
        ),
        patch(
            "comate_cli.terminal_agent.logging_adapter._recent_log_message_times",
            {},
        ),
    ):
        handler.emit(record)

    assert renderer.messages == [("background-task-race-check", "warning")]


def test_setup_tui_logging_default_log_level_is_info() -> None:
    """无 env、无 settings 时，root 与 file handler 都应该是 INFO。"""
    root = logging.getLogger()
    original_handlers = list(root.handlers)
    original_level = root.level

    session: TUILoggingSession | None = None
    try:
        session = setup_tui_logging(_FakeRenderer())

        assert root.level == logging.INFO
        file_handler = _find_file_handler(root)
        assert file_handler is not None
        assert file_handler.level == logging.INFO

        tui_handlers = [h for h in root.handlers if isinstance(h, TUILoggingHandler)]
        assert len(tui_handlers) == 1
        assert tui_handlers[0].level == logging.WARNING
    finally:
        if session is not None:
            session.close()
        root.handlers[:] = original_handlers
        root.setLevel(original_level)


def test_setup_tui_logging_env_var_overrides_to_debug(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """COMATE_LOG_LEVEL=DEBUG → root 与 file handler 都 DEBUG，TUI 仍 WARNING。"""
    root = logging.getLogger()
    original_handlers = list(root.handlers)
    original_level = root.level
    monkeypatch.setenv("COMATE_LOG_LEVEL", "DEBUG")

    session: TUILoggingSession | None = None
    try:
        session = setup_tui_logging(_FakeRenderer())

        assert root.level == logging.DEBUG
        file_handler = _find_file_handler(root)
        assert file_handler is not None
        assert file_handler.level == logging.DEBUG

        # TUI handler 不受 COMATE_LOG_LEVEL 影响，永远 WARNING（避免 DEBUG 刷屏）
        tui_handlers = [h for h in root.handlers if isinstance(h, TUILoggingHandler)]
        assert len(tui_handlers) == 1
        assert tui_handlers[0].level == logging.WARNING
    finally:
        if session is not None:
            session.close()
        root.handlers[:] = original_handlers
        root.setLevel(original_level)


def test_setup_tui_logging_reads_level_from_settings_env(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """os.environ 没设时，fallback 到 settings.json 的 env.COMATE_LOG_LEVEL。"""
    root = logging.getLogger()
    original_handlers = list(root.handlers)
    original_level = root.level
    monkeypatch.setattr(
        "comate_cli.terminal_agent.logging_adapter._read_level_from_settings_env",
        lambda project_root=None: "DEBUG",
    )

    session: TUILoggingSession | None = None
    try:
        session = setup_tui_logging(_FakeRenderer())

        assert root.level == logging.DEBUG
        file_handler = _find_file_handler(root)
        assert file_handler is not None
        assert file_handler.level == logging.DEBUG
    finally:
        if session is not None:
            session.close()
        root.handlers[:] = original_handlers
        root.setLevel(original_level)


def test_setup_tui_logging_os_env_takes_precedence_over_settings(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """os.environ 同时存在时优先于 settings.json；settings 读取不应发生。"""
    root = logging.getLogger()
    original_handlers = list(root.handlers)
    original_level = root.level
    monkeypatch.setenv("COMATE_LOG_LEVEL", "WARNING")

    settings_calls: list[object] = []

    def _tracking_reader(project_root=None):  # type: ignore[no-untyped-def]
        settings_calls.append(project_root)
        return "DEBUG"

    monkeypatch.setattr(
        "comate_cli.terminal_agent.logging_adapter._read_level_from_settings_env",
        _tracking_reader,
    )

    session: TUILoggingSession | None = None
    try:
        session = setup_tui_logging(_FakeRenderer())

        assert root.level == logging.WARNING
        assert settings_calls == [], "os.environ 命中时不应再读取 settings"
    finally:
        if session is not None:
            session.close()
        root.handlers[:] = original_handlers
        root.setLevel(original_level)


def test_setup_tui_logging_invalid_level_falls_back_to_info(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """非法值（大小写无关的未知级别）降级为 INFO，不应抛异常。"""
    root = logging.getLogger()
    original_handlers = list(root.handlers)
    original_level = root.level
    monkeypatch.setenv("COMATE_LOG_LEVEL", "spam")

    session: TUILoggingSession | None = None
    try:
        session = setup_tui_logging(_FakeRenderer())
        assert root.level == logging.INFO
        file_handler = _find_file_handler(root)
        assert file_handler is not None
        assert file_handler.level == logging.INFO
    finally:
        if session is not None:
            session.close()
        root.handlers[:] = original_handlers
        root.setLevel(original_level)


def test_setup_tui_logging_lowercase_env_value_is_accepted(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """小写 debug 也应被接受（大小写无关解析）。"""
    root = logging.getLogger()
    original_handlers = list(root.handlers)
    original_level = root.level
    monkeypatch.setenv("COMATE_LOG_LEVEL", "debug")

    session: TUILoggingSession | None = None
    try:
        session = setup_tui_logging(_FakeRenderer())
        assert root.level == logging.DEBUG
    finally:
        if session is not None:
            session.close()
        root.handlers[:] = original_handlers
        root.setLevel(original_level)
