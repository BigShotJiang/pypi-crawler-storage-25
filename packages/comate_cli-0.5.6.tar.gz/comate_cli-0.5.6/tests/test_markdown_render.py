from __future__ import annotations

import unittest

from comate_cli.terminal_agent.markdown_render import render_markdown_to_plain


class TestSingleLineNoLeadingBlank(unittest.TestCase):
    """流式管线把每行 commit 成独立 entry 后逐条调用本函数。
    rich.Markdown 会在 list / blockquote / 有序列表等 block 元素前自动插 "\\n"，
    若仅 rstrip 则前置空行会被 splitlines 切出 → printer 把空首行当正文打印 →
    每个 list item 之间多一个空行（用户实际观察到的 bug）。
    本测试锁定不变量：单行 block 元素的渲染输出不得以空行开头。"""

    def _first_line_nonempty(self, src: str) -> None:
        out = render_markdown_to_plain(src, width=80)
        lines = out.splitlines()
        self.assertTrue(lines, f"empty render output for {src!r}")
        self.assertNotEqual(
            lines[0].strip(), "",
            f"leading blank line in render output for {src!r}: {lines!r}",
        )

    def test_unordered_list_dash(self) -> None:
        self._first_line_nonempty("- foo\n")

    def test_unordered_list_star(self) -> None:
        self._first_line_nonempty("* foo\n")

    def test_unordered_list_plus(self) -> None:
        self._first_line_nonempty("+ foo\n")

    def test_ordered_list(self) -> None:
        self._first_line_nonempty("1. foo\n")

    def test_blockquote(self) -> None:
        self._first_line_nonempty("> quote\n")

    def test_plain_text_unchanged(self) -> None:
        self.assertEqual(
            render_markdown_to_plain("plain text\n", width=80).splitlines(),
            ["plain text"],
        )

    def test_heading_unchanged(self) -> None:
        self.assertEqual(
            render_markdown_to_plain("# heading\n", width=80).splitlines(),
            ["heading"],
        )


if __name__ == "__main__":
    unittest.main()
