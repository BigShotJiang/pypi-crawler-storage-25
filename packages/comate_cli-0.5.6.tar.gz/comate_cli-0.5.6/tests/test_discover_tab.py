"""Tests for DiscoverTab (Task 11)."""

from __future__ import annotations

import asyncio
import unittest
from unittest.mock import AsyncMock, MagicMock, patch


def _make_plugin_entry(name: str, description: str = "", mkt: str = "default-mkt") -> object:
    """构造一个 PluginEntry mock。"""
    from comate_agent_sdk.plugins.models import PluginSource

    entry = MagicMock()
    entry.name = name
    entry.description = description
    entry.source = PluginSource(type="local", path=f"./plugins/{name}")
    entry.author = None
    entry.tags = []
    entry.homepage = None
    return entry


def _make_context(initial_tab: str = "discover") -> object:
    from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerContext

    return PluginPickerContext(initial_tab=initial_tab)


def _make_tab(available: dict | None = None, installed: dict | None = None) -> object:
    """构造 DiscoverTab，注入 mock 依赖。"""
    from comate_cli.terminal_agent.plugins.tabs.discover_tab import DiscoverTab

    plugin_mgr = MagicMock()
    plugin_mgr.install = AsyncMock()

    mkt_mgr = MagicMock()
    mkt_mgr.list_all_available_plugins = MagicMock(return_value=available or {})

    registry = MagicMock()
    registry.list_installed = MagicMock(return_value=installed or {})

    loader = MagicMock()
    context = _make_context()

    return DiscoverTab(plugin_mgr, mkt_mgr, registry, loader, context)


class TestDiscoverTabActivate(unittest.TestCase):
    def test_activate_populates_list(self) -> None:
        """activate() 后 list_ctrl 应包含所有可用插件。"""
        entries = [
            _make_plugin_entry("plugin-a", "Alpha plugin"),
            _make_plugin_entry("plugin-b", "Beta plugin"),
        ]
        tab = _make_tab(available={"my-mkt": entries})
        tab.activate()

        items = tab._list_ctrl.items
        self.assertEqual(len(items), 2)
        names = {item["name"] for item in items}
        self.assertIn("plugin-a", names)
        self.assertIn("plugin-b", names)

    def test_activate_marks_installed_plugins(self) -> None:
        """activate() 应将已安装插件的 installed 字段设为 True。"""
        entries = [_make_plugin_entry("plugin-a"), _make_plugin_entry("plugin-b")]
        installed = {"plugin-a@my-mkt": [MagicMock()]}
        tab = _make_tab(available={"my-mkt": entries}, installed=installed)
        tab.activate()

        items = {item["name"]: item for item in tab._list_ctrl.items}
        self.assertTrue(items["plugin-a"]["installed"])
        self.assertFalse(items["plugin-b"]["installed"])

    def test_activate_empty_marketplace(self) -> None:
        """没有 marketplace 时，插件列表应为空。"""
        tab = _make_tab(available={})
        tab.activate()
        self.assertEqual(len(tab._list_ctrl.items), 0)

    def test_activate_resets_state_to_list(self) -> None:
        """activate() 应将状态重置为 LIST。"""
        entries = [_make_plugin_entry("plugin-a")]
        tab = _make_tab(available={"m": entries})
        tab._state = "DETAIL"
        tab.activate()
        self.assertEqual(tab._state, "LIST")


class TestDiscoverTabFilter(unittest.TestCase):
    def setUp(self) -> None:
        entries = [
            _make_plugin_entry("search-alpha", "The alpha plugin"),
            _make_plugin_entry("beta-tool", "Beta tooling for devs"),
            _make_plugin_entry("gamma-util", "Gamma utility"),
        ]
        self.tab = _make_tab(available={"mkt": entries})
        self.tab.activate()

    def test_filter_by_name(self) -> None:
        self.tab._apply_filter("alpha")
        items = self.tab._list_ctrl.items
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["name"], "search-alpha")

    def test_filter_by_description(self) -> None:
        self.tab._apply_filter("tooling")
        items = self.tab._list_ctrl.items
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["name"], "beta-tool")

    def test_filter_case_insensitive(self) -> None:
        self.tab._apply_filter("GAMMA")
        items = self.tab._list_ctrl.items
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["name"], "gamma-util")

    def test_filter_empty_query_restores_all(self) -> None:
        self.tab._apply_filter("alpha")
        self.tab._apply_filter("")
        self.assertEqual(len(self.tab._list_ctrl.items), 3)

    def test_filter_no_match_returns_empty(self) -> None:
        self.tab._apply_filter("zzz-no-match")
        self.assertEqual(len(self.tab._list_ctrl.items), 0)


class TestDiscoverTabStateTransitions(unittest.TestCase):
    def setUp(self) -> None:
        entries = [_make_plugin_entry("plugin-a", "desc-a")]
        self.tab = _make_tab(available={"mkt": entries})
        self.tab.activate()

    def test_initial_state_is_list(self) -> None:
        self.assertEqual(self.tab._state, "LIST")

    def test_enter_transitions_to_detail(self) -> None:
        self.tab.handle_enter()
        self.assertEqual(self.tab._state, "DETAIL")

    def test_go_back_from_detail_returns_list(self) -> None:
        self.tab.handle_enter()
        handled = self.tab.go_back()
        self.assertTrue(handled)
        self.assertEqual(self.tab._state, "LIST")

    def test_go_back_from_list_returns_false(self) -> None:
        handled = self.tab.go_back()
        self.assertFalse(handled)
        self.assertEqual(self.tab._state, "LIST")

    @patch("asyncio.create_task")
    def test_enter_detail_back_action_returns_list(self, _mock_create: MagicMock) -> None:
        """在 DETAIL 态选 'Back' action 后应返回 LIST。"""
        self.tab.handle_enter()  # go to DETAIL
        # 选到 Back 动作（默认顺序：Install for user, Install for project, Back）
        self.tab.handle_down()
        self.tab.handle_down()
        self.tab.handle_enter()  # execute Back
        self.assertEqual(self.tab._state, "LIST")

    @patch("asyncio.create_task")
    def test_enter_detail_install_action_triggers_install(self, mock_create: MagicMock) -> None:
        """在 DETAIL 态选 'Install for user' 后触发安装并返回 LIST。"""
        self.tab.handle_enter()  # go to DETAIL
        self.tab.handle_enter()  # execute "Install for user" (first action)
        self.assertEqual(self.tab._state, "LIST")
        mock_create.assert_called_once()


class TestDiscoverTabNavigation(unittest.TestCase):
    def setUp(self) -> None:
        entries = [
            _make_plugin_entry("p0"),
            _make_plugin_entry("p1"),
            _make_plugin_entry("p2"),
        ]
        self.tab = _make_tab(available={"mkt": entries})
        self.tab.activate()

    def test_handle_down_moves_cursor(self) -> None:
        self.tab.handle_down()
        self.assertEqual(self.tab._list_ctrl.selected_index, 1)

    def test_handle_up_moves_cursor(self) -> None:
        self.tab.handle_down()
        self.tab.handle_up()
        self.assertEqual(self.tab._list_ctrl.selected_index, 0)

    def test_handle_up_down_in_detail_delegates_to_detail_view(self) -> None:
        self.tab.handle_enter()  # go to DETAIL
        initial = self.tab._detail_view.selected_action
        self.tab.handle_down()
        self.assertNotEqual(self.tab._detail_view.selected_action, initial)


class TestDiscoverTabHandleSpace(unittest.TestCase):
    def test_handle_space_toggles_selection(self) -> None:
        entries = [_make_plugin_entry("p0"), _make_plugin_entry("p1")]
        tab = _make_tab(available={"mkt": entries})
        tab.activate()

        tab.handle_space()
        self.assertIn(0, tab._list_ctrl.selected_items)

        tab.handle_space()
        self.assertNotIn(0, tab._list_ctrl.selected_items)

    def test_handle_space_ignored_in_detail(self) -> None:
        entries = [_make_plugin_entry("p0")]
        tab = _make_tab(available={"mkt": entries})
        tab.activate()
        tab.handle_enter()  # go to DETAIL
        tab.handle_space()  # should be no-op
        self.assertNotIn(0, tab._list_ctrl.selected_items)


class TestDiscoverTabHandleInstall(unittest.TestCase):
    @patch("asyncio.create_task")
    def test_handle_install_with_selected_items(self, mock_create: MagicMock) -> None:
        """Space 选中多项后 handle_enter() 应对每个调度安装任务（批量安装）。"""
        entries = [
            _make_plugin_entry("plugin-a"),
            _make_plugin_entry("plugin-b"),
        ]
        tab = _make_tab(available={"mkt": entries})
        tab.activate()

        # 选中两个
        tab.handle_space()
        tab.handle_down()
        tab.handle_space()

        tab.handle_enter()

        # create_task 应被调用两次
        self.assertEqual(mock_create.call_count, 2)
        self.assertIn("Installing", tab._status_message)
        # 安装后选中状态应被清除
        self.assertEqual(len(tab._list_ctrl.selected_items), 0)


class TestDiscoverTabDoInstall(unittest.IsolatedAsyncioTestCase):
    """测试 _do_install 异步安装逻辑。"""

    async def test_do_install_success_marks_installed(self) -> None:
        """安装成功后更新 installed 标志和状态消息。"""
        tab = _make_tab(available={"mkt": [_make_plugin_entry("plugin-a")]})
        tab.activate()

        item = tab._all_items[0]
        self.assertFalse(item["installed"])

        with patch("comate_cli.terminal_agent.plugins.tabs.discover_tab.get_app_or_none", return_value=None):
            await tab._do_install("plugin-a@mkt", item, "user")

        self.assertTrue(item["installed"])
        self.assertIn("Installed", tab._status_message)
        tab._plugin_mgr.install.assert_awaited_once_with("plugin-a@mkt", scope="user")

    async def test_do_install_failure_sets_error_message(self) -> None:
        """安装失败后设置错误消息。"""
        tab = _make_tab(available={"mkt": [_make_plugin_entry("plugin-a")]})
        tab.activate()
        tab._plugin_mgr.install = AsyncMock(side_effect=ValueError("boom"))

        item = tab._all_items[0]
        with patch("comate_cli.terminal_agent.plugins.tabs.discover_tab.get_app_or_none", return_value=None):
            await tab._do_install("plugin-a@mkt", item, "user")

        self.assertFalse(item["installed"])
        self.assertIn("Failed", tab._status_message)
        self.assertIn("boom", tab._status_message)

    async def test_do_install_updates_list_ctrl_items(self) -> None:
        """安装成功后 list_ctrl.items 中对应项也应标记为 installed。"""
        tab = _make_tab(available={"mkt": [_make_plugin_entry("plugin-a")]})
        tab.activate()

        with patch("comate_cli.terminal_agent.plugins.tabs.discover_tab.get_app_or_none", return_value=None):
            await tab._do_install("plugin-a@mkt", tab._all_items[0], "user")

        list_item = tab._list_ctrl.items[0]
        self.assertTrue(list_item["installed"])


class TestDiscoverTabGetFormattedText(unittest.TestCase):
    def test_list_state_does_not_include_inline_hint(self) -> None:
        """提示信息已移入 footer，content 区不应再包含 '[i] Install'。"""
        tab = _make_tab()
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertNotIn("[i] Install", flat)

    def test_detail_state_shows_detail_view(self) -> None:
        entries = [_make_plugin_entry("plugin-a", "Alpha desc")]
        tab = _make_tab(available={"mkt": entries})
        tab.activate()
        tab.handle_enter()  # go to DETAIL
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("plugin-a", flat)
        self.assertNotIn("[i] Install", flat)
