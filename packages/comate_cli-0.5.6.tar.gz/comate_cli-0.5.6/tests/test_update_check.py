from __future__ import annotations

import tomllib
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from comate_cli.terminal_agent import app as app_module
from comate_cli.terminal_agent.preflight import PreflightResult


class _FakeResponse:
    def __init__(self, latest: str) -> None:
        self._latest = latest

    def raise_for_status(self) -> None:
        return None

    def json(self) -> dict[str, object]:
        return {"info": {"version": self._latest}}


class _FakeClient:
    def __init__(self, latest: str) -> None:
        self._latest = latest

    async def __aenter__(self) -> _FakeClient:
        return self

    async def __aexit__(self, exc_type, exc, tb) -> bool:
        return False

    async def get(self, url: str) -> _FakeResponse:
        return _FakeResponse(self._latest)


class _FailingClient:
    async def __aenter__(self) -> _FailingClient:
        return self

    async def __aexit__(self, exc_type, exc, tb) -> bool:
        return False

    async def get(self, url: str) -> _FakeResponse:
        raise RuntimeError("boom")


class TestCheckUpdate(unittest.IsolatedAsyncioTestCase):
    async def test_check_update_returns_hint_when_latest_is_newer(self) -> None:
        with (
            patch.object(app_module, "_is_chinese_locale", return_value=False),
            patch.object(app_module.importlib.metadata, "version", return_value="0.3.3"),
            patch("httpx.AsyncClient", side_effect=lambda **_: _FakeClient("0.3.6")),
        ):
            hint = await app_module._check_update()

        self.assertIsNotNone(hint)
        assert hint is not None
        self.assertIn("0.3.6", hint)
        self.assertIn("0.3.3", hint)
        self.assertIn("uv tool upgrade comate-cli", hint)

    async def test_check_update_returns_none_when_versions_match(self) -> None:
        with (
            patch.object(app_module, "_is_chinese_locale", return_value=False),
            patch.object(app_module.importlib.metadata, "version", return_value="0.3.6"),
            patch("httpx.AsyncClient", side_effect=lambda **_: _FakeClient("0.3.6")),
        ):
            hint = await app_module._check_update()

        self.assertIsNone(hint)

    async def test_check_update_logs_and_returns_none_on_network_error(self) -> None:
        with (
            patch.object(app_module, "_is_chinese_locale", return_value=False),
            patch.object(app_module.importlib.metadata, "version", return_value="0.3.3"),
            patch("httpx.AsyncClient", side_effect=lambda **_: _FailingClient()),
            self.assertLogs(app_module.logger, level="DEBUG") as logs,
        ):
            hint = await app_module._check_update()

        self.assertIsNone(hint)
        self.assertTrue(
            any("update check failed" in message for message in logs.output),
            logs.output,
        )

    async def test_run_prints_update_hint(self) -> None:
        session = MagicMock()
        session.get_mode.return_value = "default"
        session.get_usage = AsyncMock(
            return_value=SimpleNamespace(
                total_prompt_tokens=0,
                total_prompt_cached_tokens=0,
                total_completion_tokens=0,
                total_reasoning_tokens=0,
            )
        )

        renderer = MagicMock()
        logging_session = MagicMock()
        status_bar = MagicMock()
        tui = MagicMock()
        tui.run = AsyncMock()
        tui.session = session
        tui.initialized_session_id = None

        with (
            patch.object(
                app_module,
                "run_preflight_if_needed",
                AsyncMock(return_value=PreflightResult(status="configured")),
            ),
            patch.object(app_module, "_build_agent", return_value=MagicMock()),
            patch.object(app_module, "print_logo"),
            patch.object(app_module, "EventRenderer", return_value=renderer),
            patch("comate_cli.terminal_agent.logging_adapter.setup_tui_logging", return_value=logging_session),
            patch.object(app_module, "_resolve_session", return_value=(session, "new")),
            patch.object(app_module, "_check_update", AsyncMock(return_value="[dim] New version available: 0.3.6[/]")),
            patch.object(app_module, "StatusBar", return_value=status_bar),
            patch.object(app_module, "TerminalAgentTUI", return_value=tui),
            patch.object(app_module, "_graceful_shutdown", AsyncMock()),
            patch.object(app_module.console, "print") as mock_console_print,
            patch.object(app_module.random, "choice", return_value="test-tip"),
        ):
            await app_module.run()

        self.assertTrue(
            any(
                "New version available" in str(call.args[0])
                for call in mock_console_print.call_args_list
                if call.args
            ),
            mock_console_print.call_args_list,
        )


class TestCliPyproject(unittest.TestCase):
    def test_pyproject_declares_packaging_runtime_dependency(self) -> None:
        pyproject_path = Path(__file__).resolve().parents[1] / "pyproject.toml"
        data = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
        dependencies = data["project"]["dependencies"]

        self.assertTrue(
            any(str(dep).startswith("packaging") for dep in dependencies),
            dependencies,
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
