from __future__ import annotations

import unittest

from prompt_toolkit.document import Document

from comate_cli.terminal_agent.slash_commands import (
    SlashArgumentHintAutoSuggest,
    SlashCommandSpec,
)


class TestSlashArgumentHintAutoSuggest(unittest.TestCase):
    def test_suggests_hint_after_command_and_space(self) -> None:
        spec_map = {
            "fix-issue": SlashCommandSpec(
                name="fix-issue",
                description="fix issue",
                execution_kind="hybrid",
                argument_hint="[issue-number] [priority]",
            )
        }
        suggest = SlashArgumentHintAutoSuggest(resolve_spec=lambda name: spec_map.get(name))

        suggestion = suggest.get_suggestion(None, Document(text="/fix-issue ", cursor_position=11))

        self.assertIsNotNone(suggestion)
        assert suggestion is not None
        self.assertEqual(suggestion.text, "[issue-number] [priority]")

    def test_no_suggestion_without_trailing_space(self) -> None:
        spec_map = {
            "test": SlashCommandSpec(
                name="test",
                description="run test",
                execution_kind="hybrid",
                argument_hint="[pattern]",
            )
        }
        suggest = SlashArgumentHintAutoSuggest(resolve_spec=lambda name: spec_map.get(name))

        suggestion = suggest.get_suggestion(None, Document(text="/test", cursor_position=5))
        self.assertIsNone(suggestion)

    def test_no_suggestion_for_unknown_command(self) -> None:
        suggest = SlashArgumentHintAutoSuggest(resolve_spec=lambda _name: None)
        suggestion = suggest.get_suggestion(None, Document(text="/unknown ", cursor_position=9))
        self.assertIsNone(suggestion)


if __name__ == "__main__":
    unittest.main(verbosity=2)
