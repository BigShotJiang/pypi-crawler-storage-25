"""Tests for InstalledTab (Task 12)."""

from __future__ import annotations

import asyncio
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch


def _make_installed_plugin(
    scope: str = "user",
    version: str = "1.0.0",
    enabled: bool = True,
    project_path: Path | None = None,
) -> object:
    """构造一个 InstalledPlugin mock。"""
    entry = MagicMock()
    entry.scope = scope
    entry.version = version
    entry.enabled = enabled
    entry.project_path = project_path
    entry.install_path = Path("/fake/path")
    entry.installed_at = "2026-01-01T00:00:00+00:00"
    entry.last_updated = "2026-01-01T00:00:00+00:00"
    entry.git_commit_sha = None
    return entry


def _make_context() -> object:
    from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerContext

    return PluginPickerContext(initial_tab="installed")


def _make_tab(installed: dict | None = None) -> object:
    """构造 InstalledTab，注入 mock 依赖。"""
    from comate_cli.terminal_agent.plugins.tabs.installed_tab import InstalledTab

    plugin_mgr = MagicMock()
    plugin_mgr.enable = MagicMock()
    plugin_mgr.disable = MagicMock()
    plugin_mgr.uninstall = AsyncMock()
    plugin_mgr.update = AsyncMock()

    registry = MagicMock()
    registry.list_installed = MagicMock(return_value=installed or {})

    context = _make_context()
    return InstalledTab(plugin_mgr, registry, context)


# ---------------------------------------------------------------------------
# activate
# ---------------------------------------------------------------------------


class TestInstalledTabActivate(unittest.TestCase):
    def test_activate_empty_registry(self) -> None:
        """没有已安装插件时，_items 应为空。"""
        tab = _make_tab(installed={})
        tab.activate()
        self.assertEqual(tab._items, [])
        self.assertEqual(tab._nav_indices, [])

    def test_activate_user_scope_creates_header_and_items(self) -> None:
        """user scope 插件应产生一个 header + 一个条目。"""
        installed = {
            "my-plugin@my-mkt": [_make_installed_plugin(scope="user", version="2.0.0")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()

        # flat 列表：header + 1 plugin
        self.assertEqual(len(tab._items), 2)
        self.assertTrue(tab._items[0]["is_header"])
        self.assertEqual(tab._items[0]["scope"], "user")
        self.assertFalse(tab._items[1]["is_header"])
        self.assertEqual(tab._items[1]["name"], "my-plugin")
        self.assertEqual(tab._items[1]["marketplace"], "my-mkt")
        self.assertEqual(tab._items[1]["version"], "2.0.0")

    def test_activate_local_scope_creates_header_and_items(self) -> None:
        """local scope 插件应产生 Local Plugins header。"""
        installed = {
            "local-plugin@mkt": [
                _make_installed_plugin(scope="local", project_path=Path("/proj"))
            ]
        }
        tab = _make_tab(installed=installed)
        tab.activate()

        headers = [item for item in tab._items if item.get("is_header")]
        self.assertEqual(len(headers), 1)
        self.assertIn("Local", headers[0]["label"])

    def test_activate_groups_by_scope(self) -> None:
        """user 和 local 插件应分别有各自的 section header。"""
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")],
            "plugin-b@mkt": [
                _make_installed_plugin(scope="local", project_path=Path("/proj"))
            ],
        }
        tab = _make_tab(installed=installed)
        tab.activate()

        headers = [item for item in tab._items if item.get("is_header")]
        header_scopes = {h["scope"] for h in headers}
        self.assertIn("user", header_scopes)
        self.assertIn("local", header_scopes)

    def test_activate_nav_indices_skip_headers(self) -> None:
        """_nav_indices 不应包含 header 条目的下标。"""
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")],
        }
        tab = _make_tab(installed=installed)
        tab.activate()

        for idx in tab._nav_indices:
            self.assertFalse(tab._items[idx].get("is_header"))

    def test_activate_header_count_label(self) -> None:
        """header 的 label 应包含插件数量。"""
        installed = {
            "p1@mkt": [_make_installed_plugin(scope="user")],
            "p2@mkt": [_make_installed_plugin(scope="user")],
        }
        tab = _make_tab(installed=installed)
        tab.activate()

        header = tab._items[0]
        self.assertIn("2", header["label"])

    def test_activate_resets_state_to_list(self) -> None:
        """activate() 应将状态重置为 LIST。"""
        tab = _make_tab()
        tab._state = "DETAIL"
        tab.activate()
        self.assertEqual(tab._state, "LIST")

    def test_activate_resets_status_message(self) -> None:
        """activate() 应清空状态消息。"""
        tab = _make_tab()
        tab._status_message = "old message"
        tab.activate()
        self.assertEqual(tab._status_message, "")


# ---------------------------------------------------------------------------
# 渲染
# ---------------------------------------------------------------------------


class TestInstalledTabRendering(unittest.TestCase):
    def test_empty_list_renders_no_plugins_message(self) -> None:
        tab = _make_tab(installed={})
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("No plugins", flat)

    def test_list_state_shows_no_hint_line(self) -> None:
        """_HINT 常量已移除，LIST 态渲染不再包含旧的按键提示行。"""
        tab = _make_tab()
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertNotIn("[e]", flat)
        self.assertNotIn("[x]", flat)

    def test_enabled_plugin_shows_filled_marker(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user", enabled=True)]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("●", flat)

    def test_disabled_plugin_shows_disabled_label(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user", enabled=False)]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("(disabled)", flat)

    def test_disabled_plugin_uses_dim_style(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user", enabled=False)]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        text = tab.get_formatted_text()
        styles = [t[0] for t in text]
        self.assertTrue(any("dim" in s for s in styles))

    def test_section_header_shows_scope_label(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("User Plugins", flat)

    def test_detail_state_shows_detail_view(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        tab.handle_enter()  # go to DETAIL
        self.assertEqual(tab._state, "DETAIL")
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("plugin-a", flat)

    def test_confirm_uninstall_state_shows_prompt(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        tab.handle_uninstall()
        self.assertEqual(tab._state, "CONFIRM_UNINSTALL")
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("Uninstall", flat)
        self.assertIn("plugin-a", flat)


# ---------------------------------------------------------------------------
# 导航（跳过 header）
# ---------------------------------------------------------------------------


class TestInstalledTabNavigation(unittest.TestCase):
    def setUp(self) -> None:
        self.installed = {
            "p0@mkt": [_make_installed_plugin(scope="user")],
            "p1@mkt": [_make_installed_plugin(scope="user")],
            "p2@mkt": [_make_installed_plugin(scope="user")],
        }
        self.tab = _make_tab(installed=self.installed)
        self.tab.activate()

    def test_initial_cursor_on_first_navigable_item(self) -> None:
        item = self.tab._current_item()
        self.assertIsNotNone(item)
        self.assertFalse(item.get("is_header"))

    def test_handle_down_advances_cursor(self) -> None:
        self.tab.handle_down()
        self.assertEqual(self.tab._nav_cursor, 1)

    def test_handle_up_moves_cursor_back(self) -> None:
        self.tab.handle_down()
        self.tab.handle_up()
        self.assertEqual(self.tab._nav_cursor, 0)

    def test_navigation_wraps_around(self) -> None:
        for _ in range(3):
            self.tab.handle_down()
        self.assertEqual(self.tab._nav_cursor, 0)

    def test_navigation_never_lands_on_header(self) -> None:
        """所有 _nav_indices 对应的条目均非 header。"""
        for idx in self.tab._nav_indices:
            self.assertFalse(self.tab._items[idx].get("is_header"))

    def test_handle_down_in_detail_delegates_to_detail_view(self) -> None:
        self.tab.handle_enter()  # go to DETAIL
        initial = self.tab._detail_view.selected_action
        self.tab.handle_down()
        self.assertNotEqual(self.tab._detail_view.selected_action, initial)

    def test_handle_up_in_detail_delegates_to_detail_view(self) -> None:
        self.tab.handle_enter()  # go to DETAIL
        self.tab.handle_down()
        before = self.tab._detail_view.selected_action
        self.tab.handle_up()
        self.assertNotEqual(self.tab._detail_view.selected_action, before)


# ---------------------------------------------------------------------------
# handle_uninstall
# ---------------------------------------------------------------------------


class TestInstalledTabHandleUninstall(unittest.TestCase):
    def test_handle_uninstall_enters_confirm_state(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        tab.handle_uninstall()
        self.assertEqual(tab._state, "CONFIRM_UNINSTALL")

    def test_handle_uninstall_ignored_when_no_items(self) -> None:
        tab = _make_tab(installed={})
        tab.activate()
        tab.handle_uninstall()
        self.assertEqual(tab._state, "LIST")

    def test_handle_uninstall_ignored_in_detail_state(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        tab.handle_enter()  # go to DETAIL
        tab.handle_uninstall()
        self.assertEqual(tab._state, "DETAIL")

    @patch("asyncio.create_task")
    def test_handle_enter_in_confirm_state_triggers_uninstall(
        self, mock_create: MagicMock
    ) -> None:
        """CONFIRM_UNINSTALL 态 handle_enter 应调度卸载任务。"""
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        tab.handle_uninstall()  # enter CONFIRM_UNINSTALL
        # 关闭 create_task 收到的协程对象，避免 unawaited 警告
        mock_create.side_effect = lambda coro: coro.close() or MagicMock()
        tab.handle_enter()  # confirm
        mock_create.assert_called_once()
        self.assertEqual(tab._state, "LIST")

    def test_go_back_from_confirm_returns_list(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        tab.handle_uninstall()
        handled = tab.go_back()
        self.assertTrue(handled)
        self.assertEqual(tab._state, "LIST")


# ---------------------------------------------------------------------------
# go_back
# ---------------------------------------------------------------------------


class TestInstalledTabGoBack(unittest.TestCase):
    def test_go_back_from_list_returns_false(self) -> None:
        tab = _make_tab()
        tab.activate()
        self.assertFalse(tab.go_back())

    def test_go_back_from_detail_returns_true(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        tab.handle_enter()  # go to DETAIL
        self.assertTrue(tab.go_back())
        self.assertEqual(tab._state, "LIST")

    def test_go_back_from_confirm_returns_true(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        tab.handle_uninstall()  # go to CONFIRM_UNINSTALL
        self.assertTrue(tab.go_back())
        self.assertEqual(tab._state, "LIST")


# ---------------------------------------------------------------------------
# 状态迁移
# ---------------------------------------------------------------------------


class TestInstalledTabStateTransitions(unittest.TestCase):
    def setUp(self) -> None:
        self.installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        self.tab = _make_tab(installed=self.installed)
        self.tab.activate()

    def test_initial_state_is_list(self) -> None:
        self.assertEqual(self.tab._state, "LIST")

    def test_enter_transitions_to_detail(self) -> None:
        self.tab.handle_enter()
        self.assertEqual(self.tab._state, "DETAIL")

    def test_detail_back_action_returns_list(self) -> None:
        self.tab.handle_enter()  # go to DETAIL
        # Back 是 actions 列表中的最后一项
        while self.tab._detail_view.get_selected_action() != "Back":
            self.tab.handle_down()
        self.tab.handle_enter()
        self.assertEqual(self.tab._state, "LIST")

    @patch("asyncio.create_task")
    def test_detail_uninstall_action_triggers_confirm_flow(
        self, mock_create: MagicMock
    ) -> None:
        """DETAIL 态选 Uninstall 应转至 CONFIRM_UNINSTALL 流程。"""
        self.tab.handle_enter()  # go to DETAIL
        while self.tab._detail_view.get_selected_action() != "Uninstall":
            self.tab.handle_down()
        self.tab.handle_enter()  # execute Uninstall
        # 应先返回 LIST 然后进入 CONFIRM_UNINSTALL
        self.assertEqual(self.tab._state, "CONFIRM_UNINSTALL")

    @patch("asyncio.create_task")
    def test_detail_enable_action_toggles_and_returns_list(
        self, mock_create: MagicMock
    ) -> None:
        """DETAIL 态选 Disable/Enable 应执行切换并返回 LIST。"""
        self.tab.handle_enter()  # go to DETAIL
        # 第一个 action 是 Disable（因为 enabled=True）
        self.assertEqual(self.tab._detail_view.get_selected_action(), "Disable")
        self.tab.handle_enter()
        self.assertEqual(self.tab._state, "LIST")
        self.tab._plugin_mgr.disable.assert_called_once()


# ---------------------------------------------------------------------------
# 异步操作 (_do_update, _do_uninstall)
# ---------------------------------------------------------------------------


class TestInstalledTabAsyncUpdate(unittest.IsolatedAsyncioTestCase):
    async def test_do_update_success_sets_status(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        item = tab._current_item()

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.installed_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_update("plugin-a@mkt", item)

        tab._plugin_mgr.update.assert_awaited_once_with("plugin-a@mkt")
        self.assertIn("Updated", tab._status_message)

    async def test_do_update_failure_sets_error_message(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        tab._plugin_mgr.update = AsyncMock(side_effect=ValueError("network error"))
        item = tab._current_item()

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.installed_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_update("plugin-a@mkt", item)

        self.assertIn("Failed", tab._status_message)
        self.assertIn("network error", tab._status_message)

    async def test_do_uninstall_success_sets_status(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        item = tab._current_item()

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.installed_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_uninstall("plugin-a@mkt", item)

        tab._plugin_mgr.uninstall.assert_awaited_once_with(
            "plugin-a@mkt", scope="user", project_path=None
        )
        self.assertIn("Uninstalled", tab._status_message)

    async def test_do_uninstall_failure_sets_error_message(self) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        tab._plugin_mgr.uninstall = AsyncMock(side_effect=RuntimeError("disk error"))
        item = tab._current_item()

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.installed_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_uninstall("plugin-a@mkt", item)

        self.assertIn("Failed", tab._status_message)
        self.assertIn("disk error", tab._status_message)

    @patch("asyncio.create_task")
    def test_handle_update_schedules_task(self, mock_create: MagicMock) -> None:
        """handle_update 应调度 asyncio 任务，防止 GC 回收。"""
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        # 关闭 create_task 收到的协程对象，避免 unawaited 警告
        mock_create.side_effect = lambda coro: coro.close() or MagicMock()
        tab.handle_update()
        mock_create.assert_called_once()

    @patch("asyncio.create_task")
    def test_handle_update_ignored_in_detail_state(self, mock_create: MagicMock) -> None:
        installed = {
            "plugin-a@mkt": [_make_installed_plugin(scope="user")]
        }
        tab = _make_tab(installed=installed)
        tab.activate()
        tab.handle_enter()  # go to DETAIL
        tab.handle_update()  # should be no-op
        mock_create.assert_not_called()
