"""Tests for SubmissionAnimator phrase shuffle behavior."""
import asyncio
from unittest.mock import patch

from comate_cli.terminal_agent.animations import SubmissionAnimator


async def _start_and_stop(animator: SubmissionAnimator) -> None:
    """Helper: start animator, yield once, then stop."""
    await animator.start()
    await asyncio.sleep(0)
    await animator.stop()


def test_start_shuffles_phrases():
    """start() should shuffle the phrase order, not use the original sequence."""
    phrases = ["Alpha", "Bravo", "Charlie", "Delta", "Echo"]
    animator = SubmissionAnimator(phrases=phrases)

    # We run start() many times and collect the first phrase each time.
    # With shuffling, it's extremely unlikely to always be "Alpha".
    first_phrases: list[str] = []
    for _ in range(20):
        asyncio.run(_start_and_stop(animator))
        first_phrases.append(animator._shuffled[0])

    # At least one run should differ from the original first phrase.
    assert not all(p == "Alpha" for p in first_phrases), (
        f"All 20 runs started with 'Alpha' — shuffle is not working: {first_phrases}"
    )


def test_shuffled_contains_all_original_phrases():
    """Shuffled list must be a permutation — no loss, no duplication."""
    phrases = ["Alpha", "Bravo", "Charlie", "Delta", "Echo"]
    animator = SubmissionAnimator(phrases=phrases)

    asyncio.run(_start_and_stop(animator))

    assert sorted(animator._shuffled) == sorted(phrases)


def test_shuffled_is_tuple():
    """_shuffled must be immutable (tuple), not a mutable list."""
    phrases = ["Alpha", "Bravo"]
    animator = SubmissionAnimator(phrases=phrases)

    asyncio.run(_start_and_stop(animator))

    assert isinstance(animator._shuffled, tuple)


def test_random_shuffle_is_called_on_start():
    """Verify random.shuffle is called exactly once per start()."""
    phrases = ["Alpha", "Bravo", "Charlie"]
    animator = SubmissionAnimator(phrases=phrases)

    with patch("comate_cli.terminal_agent.animations.random.shuffle") as mock_shuffle:
        asyncio.run(_start_and_stop(animator))
        mock_shuffle.assert_called_once()


def test_each_start_reshuffles():
    """Multiple start/stop cycles should produce different orderings."""
    phrases = ["A", "B", "C", "D", "E", "F", "G", "H"]
    animator = SubmissionAnimator(phrases=phrases)

    orderings: list[tuple[str, ...]] = []
    for _ in range(10):
        asyncio.run(_start_and_stop(animator))
        orderings.append(animator._shuffled)

    unique = set(orderings)
    assert len(unique) > 1, (
        f"All 10 start() calls produced the same ordering — shuffle not re-running"
    )
