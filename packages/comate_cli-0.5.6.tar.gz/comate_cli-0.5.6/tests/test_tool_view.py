from __future__ import annotations

import unittest

from comate_cli.terminal_agent.figures import BULLET_OPERATOR
from comate_cli.terminal_agent.tool_view import (
    ToolEventView,
    should_show_tool_in_scrollback,
    _truncate,
    _truncate_path_middle,
    TOOL_SUMMARY_MAX_LENGTH,
)


class TestToolEventView(unittest.TestCase):
    def test_render_result_mutates_same_text_reference(self) -> None:
        view = ToolEventView(fancy_progress_effect=False)
        text_ref = view.render_call(
            "Read",
            {"path": "/tmp/demo.py", "offset_line": 1, "limit_lines": 50},
            "tc_read_1",
        )

        self.assertIn("→ Read", text_ref.plain)
        self.assertIn("path=/tmp/demo.py", text_ref.plain)

        view.render_result(
            tool_name="Read",
            tool_call_id="tc_read_1",
            result="ok",
            is_error=False,
        )
        self.assertIn("✓ Read", text_ref.plain)
        self.assertIn("path=/tmp/demo.py", text_ref.plain)

    def test_interrupt_running_marks_text_ref_as_interrupted(self) -> None:
        view = ToolEventView(fancy_progress_effect=False)
        text_ref = view.render_call(
            "Bash",
            {"command": "npm test"},
            "tc_bash_1",
        )

        view.interrupt_running()
        self.assertIn("已中断", text_ref.plain)
        self.assertIn("⏹ Bash", text_ref.plain)

    def test_has_running_tasks_only_counts_task_tool(self) -> None:
        view = ToolEventView(fancy_progress_effect=False)
        view.render_call("Read", {"path": "/tmp/a.py"}, "tc_read_2")
        self.assertFalse(view.has_running_tasks())

        task_ref = view.render_call(
            "Task",
            {"subagent_type": "Planner", "description": "拆解任务"},
            "tc_task_1",
        )
        self.assertTrue(view.has_running_tasks())

        view.render_result(
            tool_name="Agent",
            tool_call_id="tc_task_1",
            result="done",
            is_error=False,
        )
        self.assertFalse(view.has_running_tasks())
        self.assertIn(f"✓ Planner(拆解任务) {BULLET_OPERATOR} 完成", task_ref.plain)


class TestShouldShowToolInScrollback(unittest.TestCase):
    # --- TaskCreate: hidden except error ---
    def test_taskcreate_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskCreate", {"subject": "do X"}))

    def test_taskcreate_result_success_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskCreate", {"subject": "do X"}, is_result=True))

    def test_taskcreate_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("TaskCreate", {}, is_result=True, is_error=True))

    # --- TaskUpdate: hidden except error ---
    def test_taskupdate_completed_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskUpdate", {"taskId": "1", "status": "completed"}))

    def test_taskupdate_completed_result_success_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskUpdate", {"taskId": "1", "status": "completed"}, is_result=True))

    def test_taskupdate_completed_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("TaskUpdate", {"taskId": "1", "status": "completed"}, is_result=True, is_error=True))

    def test_taskupdate_in_progress_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskUpdate", {"taskId": "1", "status": "in_progress"}))

    def test_taskupdate_in_progress_result_success_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskUpdate", {"taskId": "1", "status": "in_progress"}, is_result=True))

    def test_taskupdate_in_progress_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("TaskUpdate", {"taskId": "1", "status": "in_progress"}, is_result=True, is_error=True))

    def test_taskupdate_empty_args_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskUpdate", {}))

    def test_taskupdate_empty_args_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("TaskUpdate", {}, is_result=True, is_error=True))

    # --- TaskList: hidden except error ---
    def test_tasklist_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskList", {}))

    def test_tasklist_result_success_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskList", {}, is_result=True))

    def test_tasklist_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("TaskList", {}, is_result=True, is_error=True))

    # --- TaskGet: hidden except error ---
    def test_taskget_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskGet", {}))

    def test_taskget_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("TaskGet", {}, is_result=True, is_error=True))

    # --- AskUserQuestion: hidden except error ---
    def test_askuserquestion_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("AskUserQuestion", {}))

    def test_askuserquestion_result_success_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("AskUserQuestion", {}, is_result=True))

    def test_askuserquestion_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("AskUserQuestion", {}, is_result=True, is_error=True))

    # --- ExitPlanMode: hidden except error ---
    def test_exitplanmode_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("ExitPlanMode", {}))

    def test_exitplanmode_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("ExitPlanMode", {}, is_result=True, is_error=True))

    # --- Normal tools: always show ---
    def test_read_always_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("Read", {"file_path": "/tmp/a.py"}))

    def test_edit_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("Edit", {}, is_result=True, is_error=True))

    # --- Case insensitivity ---
    def test_case_insensitive(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("tasklist", {}))
        self.assertFalse(should_show_tool_in_scrollback("TASKCREATE", {"subject": "x"}))


class TestTruncateSemantics(unittest.TestCase):
    """Verify _truncate output is strictly <= max_len."""

    def test_truncate_output_within_max_len(self) -> None:
        result = _truncate("x" * 100, 50)
        self.assertLessEqual(len(result), 50)
        self.assertTrue(result.endswith("..."))

    def test_truncate_short_input_unchanged(self) -> None:
        self.assertEqual(_truncate("hello", 50), "hello")


class TestTruncatePathMiddle(unittest.TestCase):
    def test_short_path_unchanged(self) -> None:
        self.assertEqual(_truncate_path_middle("src/main.py", 50), "src/main.py")

    def test_long_path_preserves_filename(self) -> None:
        path = "a/b/c/d/very/deep/nested/file.ts"
        result = _truncate_path_middle(path, 20)
        self.assertTrue(result.endswith("file.ts"))
        self.assertTrue(result.startswith("…/"))
        self.assertLessEqual(len(result), 20)

    def test_filename_only_no_separator(self) -> None:
        result = _truncate_path_middle("file.ts", 50)
        self.assertEqual(result, "file.ts")

    def test_filename_exceeds_max_len_end_truncates(self) -> None:
        result = _truncate_path_middle("very_long_filename_that_is_way_too_long.ts", 15)
        self.assertLessEqual(len(result), 15)
        self.assertTrue(result.endswith("..."))

    def test_empty_path(self) -> None:
        self.assertEqual(_truncate_path_middle("", 50), "")

    def test_none_path_returns_empty(self) -> None:
        self.assertEqual(_truncate_path_middle(None, 50), "")

    def test_preserves_multiple_trailing_segments(self) -> None:
        path = "a/b/c/deep/file.ts"
        result = _truncate_path_middle(path, 16)
        self.assertIn("deep/file.ts", result)
        self.assertTrue(result.startswith("…/"))
        self.assertLessEqual(len(result), 16)

    def test_backslash_path_normalized(self) -> None:
        path = "a\\b\\c\\deep\\file.ts"
        result = _truncate_path_middle(path, 16)
        self.assertIn("file.ts", result)
        self.assertNotIn("\\", result)

    def test_constant_value(self) -> None:
        self.assertEqual(TOOL_SUMMARY_MAX_LENGTH, 160)


class TestSummarizeToolArgsTruncation(unittest.TestCase):
    """Verify all tool branches respect truncation limits."""

    _long_path = "claude-code-source-code-3da94d5e5f2b99c9d82b0d8f09448b04775cd41f/src/utils/swarm/inProcessRunner.ts"

    def test_read_within_budget(self) -> None:
        from comate_cli.terminal_agent.tool_view import summarize_tool_args
        args = {"file_path": self._long_path, "offset_line": 595, "limit_lines": 35}
        result = summarize_tool_args("Read", args, None)
        self.assertLessEqual(len(result), 160)
        self.assertIn("inProcessRunner.ts", result)

    def test_write_within_budget(self) -> None:
        from comate_cli.terminal_agent.tool_view import summarize_tool_args
        args = {"file_path": self._long_path}
        result = summarize_tool_args("Write", args, None)
        self.assertLessEqual(len(result), TOOL_SUMMARY_MAX_LENGTH)
        self.assertIn("inProcessRunner.ts", result)

    def test_edit_within_budget(self) -> None:
        from comate_cli.terminal_agent.tool_view import summarize_tool_args
        args = {"file_path": self._long_path}
        result = summarize_tool_args("Edit", args, None)
        self.assertLessEqual(len(result), TOOL_SUMMARY_MAX_LENGTH)

    def test_grep_within_budget(self) -> None:
        from comate_cli.terminal_agent.tool_view import summarize_tool_args
        args = {"path": self._long_path, "pattern": "function findAvailableTask"}
        result = summarize_tool_args("Grep", args, None)
        self.assertLessEqual(len(result), TOOL_SUMMARY_MAX_LENGTH)

    def test_bash_within_budget(self) -> None:
        from comate_cli.terminal_agent.tool_view import summarize_tool_args
        args = {"args": ["echo"] + ["x" * 200]}
        result = summarize_tool_args("Bash", args, None)
        self.assertLessEqual(len(result), 200)

    def test_bash_command_within_budget(self) -> None:
        from comate_cli.terminal_agent.tool_view import summarize_tool_args
        args = {"command": "x" * 200}
        result = summarize_tool_args("Bash", args, None)
        self.assertLessEqual(len(result), 200)

    def test_fallback_within_budget(self) -> None:
        from comate_cli.terminal_agent.tool_view import summarize_tool_args
        args = {"key": "x" * 300}
        result = summarize_tool_args("UnknownTool", args, None)
        self.assertLessEqual(len(result), TOOL_SUMMARY_MAX_LENGTH)

    def test_short_args_unchanged(self) -> None:
        from comate_cli.terminal_agent.tool_view import summarize_tool_args
        args = {"file_path": "src/main.py"}
        result = summarize_tool_args("Read", args, None)
        self.assertIn("src/main.py", result)

    def test_webfetch_within_budget(self) -> None:
        from comate_cli.terminal_agent.tool_view import summarize_tool_args
        args = {"url": "https://example.com/" + "x" * 200}
        result = summarize_tool_args("WebFetch", args, None)
        self.assertLessEqual(len(result), TOOL_SUMMARY_MAX_LENGTH)

    def test_agent_within_budget(self) -> None:
        from comate_cli.terminal_agent.tool_view import summarize_tool_args
        args = {"subagent_type": "Explore", "description": "x" * 200}
        result = summarize_tool_args("Agent", args, None)
        self.assertLessEqual(len(result), TOOL_SUMMARY_MAX_LENGTH)

    def test_skill_within_budget(self) -> None:
        from comate_cli.terminal_agent.tool_view import summarize_tool_args
        args = {"skill": "x" * 200}
        result = summarize_tool_args("Skill", args, None)
        self.assertLessEqual(len(result), TOOL_SUMMARY_MAX_LENGTH)

    def test_grep_pattern_only_within_budget(self) -> None:
        from comate_cli.terminal_agent.tool_view import summarize_tool_args
        args = {"pattern": "x" * 200}
        result = summarize_tool_args("Grep", args, None)
        self.assertLessEqual(len(result), TOOL_SUMMARY_MAX_LENGTH)


if __name__ == "__main__":
    unittest.main(verbosity=2)
