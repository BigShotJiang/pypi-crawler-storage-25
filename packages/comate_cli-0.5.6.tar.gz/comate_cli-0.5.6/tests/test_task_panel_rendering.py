"""Tests for task panel multi-fragment rendering in _todo_text."""
from __future__ import annotations

import unittest

from comate_cli.terminal_agent.tui_parts.render_panels import RenderPanelsMixin


class _StubRenderer:
    def __init__(self, lines: list[str]) -> None:
        self._lines = lines

    def has_active_todos(self) -> bool:
        return bool(self._lines)

    def has_running_tools(self) -> bool:
        return False

    def todo_all_lines(self) -> list[str]:
        return list(self._lines)

    def todo_panel_lines(self, *, max_lines: int | None = None) -> list[str]:
        if max_lines and len(self._lines) > max_lines:
            clipped = self._lines[:max_lines - 1]
            clipped.append(f"… (+{len(self._lines) - (max_lines - 1)})")
            return clipped
        return list(self._lines)


class _StubMixin(RenderPanelsMixin):
    """Minimal stub to test _todo_text."""
    def __init__(self, lines: list[str]) -> None:
        self._renderer = _StubRenderer(lines)
        self._loading_frame = 0
        self._todo_panel_expanded = False
        self._todo_panel_scroll = 0
        self._todo_panel_max_lines = 6
        self._todo_panel_expanded_max_lines = 12
        self._run_start_time = None
        self._tool_result_flash_active = False
        self._busy = False

    def _terminal_width(self) -> int:
        return 80


def _extract_text(fragments: list[tuple[str, str]]) -> str:
    return "".join(text for _, text in fragments)


def _find_fragment_with(fragments: list[tuple[str, str]], char: str) -> tuple[str, str] | None:
    for style, text in fragments:
        if char in text:
            return style, text
    return None


class TestTodoTextFragments(unittest.TestCase):
    def test_in_progress_has_orange_symbol(self):
        lines = ["Implement auth", "◼ Implement auth", "▢ Write tests"]
        mixin = _StubMixin(lines)
        fragments = mixin._todo_text()
        frag = _find_fragment_with(fragments, "◼")
        self.assertIsNotNone(frag)
        self.assertIn("#F97316", frag[0])

    def test_in_progress_text_is_bright_white(self):
        lines = ["Implement auth", "◼ Implement auth"]
        mixin = _StubMixin(lines)
        fragments = mixin._todo_text()
        text_frags = [(s, t) for s, t in fragments if "Implement auth" in t and "◼" not in t]
        self.assertTrue(len(text_frags) > 0)
        self.assertIn("#E2E8F0", text_frags[0][0])

    def test_completed_has_green_checkmark_and_grey_strikethrough_text(self):
        lines = ["Tasks", "✓ Set up project"]
        mixin = _StubMixin(lines)
        fragments = mixin._todo_text()
        check_frag = _find_fragment_with(fragments, "✓")
        self.assertIsNotNone(check_frag)
        self.assertIn("#86EFAC", check_frag[0])
        text_frags = [(s, t) for s, t in fragments if "Set up project" in t]
        self.assertTrue(len(text_frags) > 0)
        self.assertIn("#4B5563", text_frags[0][0])
        self.assertIn("strike", text_frags[0][0])

    def test_pending_unblocked_has_grey_symbol(self):
        lines = ["Tasks", "▢ Write tests"]
        mixin = _StubMixin(lines)
        fragments = mixin._todo_text()
        frag = _find_fragment_with(fragments, "▢")
        self.assertIsNotNone(frag)
        self.assertIn("#6B7280", frag[0])

    def test_pending_blocked_has_deep_grey(self):
        """▫ intermediate symbol is rendered as ▢ but with deeper grey."""
        lines = ["Tasks", "▫ Deploy"]
        mixin = _StubMixin(lines)
        fragments = mixin._todo_text()
        # Rendered symbol should be ▢ (not ▫)
        frag = _find_fragment_with(fragments, "▢")
        self.assertIsNotNone(frag, "blocked pending should render as ▢")
        self.assertIn("#4B5563", frag[0])

    def test_first_row_has_hook_prefix(self):
        lines = ["Tasks", "▢ Write tests", "▢ Deploy"]
        mixin = _StubMixin(lines)
        fragments = mixin._todo_text()
        frag = _find_fragment_with(fragments, "⎿")
        self.assertIsNotNone(frag, "First task row should have ⎿ prefix")

    def test_subsequent_rows_have_space_prefix_not_hook(self):
        lines = ["Tasks", "▢ Task A", "▢ Task B"]
        mixin = _StubMixin(lines)
        fragments = mixin._todo_text()
        text = _extract_text(fragments)
        self.assertEqual(text.count("⎿"), 1)
