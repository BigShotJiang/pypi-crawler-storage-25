from __future__ import annotations

import unittest
from datetime import datetime, timezone
from types import SimpleNamespace
from typing import Any

from prompt_toolkit.layout import Window

from comate_agent_sdk.agent.queue_types import MessageOrigin, QueuedMessage

from comate_cli.terminal_agent.tui_parts.key_bindings import KeyBindingsMixin
from comate_cli.terminal_agent.tui_parts.ui_mode import UIMode


class _FakeRunController:
    def __init__(self) -> None:
        self.interrupt_calls: list[str] = []

    def interrupt(self, *, reason: str) -> None:
        self.interrupt_calls.append(reason)


class _FakeSession:
    def __init__(self) -> None:
        self.run_controller = _FakeRunController()
        self.busy = False
        self.queue: tuple[QueuedMessage, ...] = ()
        self.cancelled: list[tuple[str, ...]] = []

    def is_busy(self) -> bool:
        return self.busy

    def peek_queue(self) -> tuple[QueuedMessage, ...]:
        return self.queue

    def cancel_many(self, message_ids) -> int:  # type: ignore[no-untyped-def]
        ids = tuple(str(message_id) for message_id in message_ids)
        self.cancelled.append(ids)
        return len(ids)


class _FakeBuffer:
    def __init__(self, text: str = "") -> None:
        self.text = text
        self.cursor_position = len(text)
        self.complete_state: Any | None = None
        self.cancel_completion_calls = 0
        self.clear_calls = 0
        self.auto_up_calls = 0

    def cancel_completion(self) -> None:
        self.cancel_completion_calls += 1
        self.complete_state = None

    def auto_up(self, count: int = 1) -> None:
        self.auto_up_calls += count


class _FakeEvent:
    def __init__(self, buffer: _FakeBuffer) -> None:
        self.current_buffer = buffer


class _FakeRenderer:
    latest_diff_lines: list[str] = []

    def has_active_todos(self) -> bool:
        return False


class _FakeQuestionUI:
    custom_input_window = Window()


class _FakePluginUI:
    search_area_window = Window()
    content_window = Window()


class _Host(KeyBindingsMixin):
    def __init__(self) -> None:
        self._ui_mode = UIMode.NORMAL
        self._selection_ui = SimpleNamespace()
        self._plugin_ui = _FakePluginUI()
        self._install_view = SimpleNamespace()
        self._mcp_connecting_view = SimpleNamespace()
        self._question_ui = _FakeQuestionUI()
        self._mention_completer = SimpleNamespace(extract_context=lambda _text: None)
        self._diff_panel_visible = False
        self._todo_panel_expanded = False
        self._todo_panel_scroll = 0
        self._todo_panel_expanded_max_lines = 8
        self._renderer = _FakeRenderer()
        self._session = _FakeSession()
        self._queued_display_by_message_id: dict[str, str] = {}
        self._busy = False
        self._initializing = False
        self._esc_press_count = 0
        self._esc_last_pressed_at = 0.0
        self._esc_clear_window_seconds = 1.0
        self._input_area = SimpleNamespace(window=Window())
        self.focus_calls = 0
        self.invalidate_calls = 0
        self.clear_input_calls = 0
        self.should_handle_history = False
        self._app = SimpleNamespace(
            layout=SimpleNamespace(focus=lambda _target: self._focus())
        )

    def _focus(self) -> None:
        self.focus_calls += 1

    def _invalidate(self) -> None:
        self.invalidate_calls += 1

    def _clear_input_area(self) -> None:
        self.clear_input_calls += 1

    def _move_completion_selection(self, *_args, **_kwargs) -> bool:  # type: ignore[no-untyped-def]
        return False

    def _move_cursor_visual(self, *_args, **_kwargs) -> bool:  # type: ignore[no-untyped-def]
        return False

    def _should_handle_history(self) -> bool:
        return self.should_handle_history

    def _submit_from_input(self) -> None:
        return None

    def _cycle_agent_mode(self) -> None:
        return None


def _message(
    message_id: str,
    content: Any,
    origin: MessageOrigin = MessageOrigin.HUMAN,
) -> QueuedMessage:
    return QueuedMessage(
        message_id=message_id,
        content=content,
        origin=origin,
        enqueued_at=datetime(2026, 4, 28, tzinfo=timezone.utc),
    )


def _find_escape_binding(host: _Host):
    for binding in host._build_key_bindings().bindings:
        if (
            str(binding.keys[0]).lower().endswith("escape")
            and binding.handler.__name__ == "_esc"
        ):
            return binding
    raise AssertionError("Cannot find escape binding.")


def _find_up_binding(host: _Host):
    for binding in host._build_key_bindings().bindings:
        if (
            str(binding.keys[0]).lower().endswith("up")
            and binding.handler.__name__ == "_active_prev_up"
        ):
            return binding
    raise AssertionError("Cannot find up binding.")


class TestTUIEscQueue(unittest.TestCase):
    def test_escape_cancels_completion_before_interrupt_or_queue_pop(self) -> None:
        host = _Host()
        host._session.busy = True
        buffer = _FakeBuffer()
        buffer.complete_state = object()
        binding = _find_escape_binding(host)

        binding.handler(_FakeEvent(buffer))

        self.assertEqual(buffer.cancel_completion_calls, 1)
        self.assertEqual(host._session.run_controller.interrupt_calls, [])
        self.assertEqual(host._session.cancelled, [])

    def test_escape_interrupts_session_busy_without_clearing_queue(self) -> None:
        host = _Host()
        host._session.busy = True
        host._session.queue = (_message("human-1", "queued"),)
        buffer = _FakeBuffer()
        binding = _find_escape_binding(host)

        binding.handler(_FakeEvent(buffer))

        self.assertEqual(host._session.run_controller.interrupt_calls, ["user_esc"])
        self.assertEqual(host._session.cancelled, [])
        self.assertEqual(buffer.text, "")
        self.assertEqual(host.clear_input_calls, 0)

    def test_escape_when_idle_pops_human_messages_back_to_input(self) -> None:
        host = _Host()
        host._session.queue = (
            _message("human-1", "first"),
            _message("external-1", "external", MessageOrigin.EXTERNAL),
            _message("human-2", "second\nmessage"),
        )
        host._queued_display_by_message_id = {
            "human-1": "first",
            "human-2": "second\nmessage",
        }
        buffer = _FakeBuffer()
        binding = _find_escape_binding(host)

        binding.handler(_FakeEvent(buffer))

        self.assertEqual(buffer.text, "first\n\nsecond\nmessage")
        self.assertEqual(buffer.cursor_position, len(buffer.text))
        self.assertEqual(host._session.cancelled, [("human-1", "human-2")])
        self.assertEqual(host._queued_display_by_message_id, {})
        self.assertEqual(host.invalidate_calls, 1)
        self.assertEqual(host.clear_input_calls, 0)

    def test_up_when_idle_pops_human_messages_back_to_input_before_history(self) -> None:
        host = _Host()
        host.should_handle_history = True
        host._session.queue = (
            _message("human-1", "first"),
            _message("external-1", "external", MessageOrigin.EXTERNAL),
            _message("human-2", "second\nmessage"),
        )
        host._queued_display_by_message_id = {
            "human-1": "first",
            "human-2": "second\nmessage",
        }
        buffer = _FakeBuffer()
        binding = _find_up_binding(host)

        binding.handler(_FakeEvent(buffer))

        self.assertEqual(buffer.text, "first\n\nsecond\nmessage")
        self.assertEqual(buffer.cursor_position, len(buffer.text))
        self.assertEqual(buffer.auto_up_calls, 0)
        self.assertEqual(host._session.cancelled, [("human-1", "human-2")])
        self.assertEqual(host._queued_display_by_message_id, {})
        self.assertEqual(host.invalidate_calls, 1)

    def test_escape_falls_back_to_double_press_clear_when_queue_empty(self) -> None:
        host = _Host()
        buffer = _FakeBuffer("typing")
        binding = _find_escape_binding(host)

        binding.handler(_FakeEvent(buffer))
        binding.handler(_FakeEvent(buffer))

        self.assertEqual(host.clear_input_calls, 1)
        self.assertEqual(host._session.cancelled, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
