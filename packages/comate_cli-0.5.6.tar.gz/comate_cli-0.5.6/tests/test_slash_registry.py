from __future__ import annotations

import unittest

from comate_cli.terminal_agent.slash_commands import SLASH_COMMAND_SPECS, SlashCommandSpec
from comate_cli.terminal_agent.tui_parts.slash_command_registry import SlashCommandRegistry


class TestSlashCommandRegistry(unittest.TestCase):
    def test_register_and_resolve_alias(self) -> None:
        registry = SlashCommandRegistry()

        def _handler(_args: str) -> None:
            return None

        spec = SlashCommandSpec(
            name="help",
            description="help",
            execution_kind="local",
            aliases=("h",),
        )
        registry.register(spec=spec, handler=_handler, allow_when_busy=True)

        by_name = registry.resolve("help")
        by_alias = registry.resolve("h")
        self.assertIsNotNone(by_name)
        self.assertIs(by_name, by_alias)
        assert by_name is not None
        self.assertTrue(by_name.allow_when_busy)

    def test_duplicate_registration_raises(self) -> None:
        registry = SlashCommandRegistry()

        def _handler(_args: str) -> None:
            return None

        registry.register(
            spec=SlashCommandSpec(
                name="help",
                description="help",
                execution_kind="local",
            ),
            handler=_handler,
        )

        with self.assertRaises(ValueError):
            registry.register(
                spec=SlashCommandSpec(
                    name="help",
                    description="duplicate",
                    execution_kind="local",
                ),
                handler=_handler,
            )

    def test_builtin_specs_define_execution_kind(self) -> None:
        allowed = {"local", "llm", "hybrid"}
        for spec in SLASH_COMMAND_SPECS:
            self.assertIn(spec.execution_kind, allowed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
