from __future__ import annotations

import json
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from comate_agent_sdk.context.items import ContextItem, ItemType
from comate_agent_sdk.context.items import TOOL_OBSERVABLE_INPUTS_METADATA_KEY
from comate_agent_sdk.llm.messages import (
    AssistantMessage,
    Function,
    ToolCall,
    ToolMessage,
    UserMessage,
)

from comate_cli.terminal_agent.event_renderer import EventRenderer
from comate_cli.terminal_agent.tui_parts.history_sync import HistorySyncMixin


class _DummyHistorySync(HistorySyncMixin):
    def __init__(self, items: list[ContextItem]) -> None:
        self._session = SimpleNamespace(
            _agent=SimpleNamespace(
                _context=SimpleNamespace(
                    get_conversation_items_snapshot=lambda: list(items)
                )
            )
        )
        self._renderer = EventRenderer(project_root=Path.cwd())
        self._printed_history_index = 0
        self._show_thinking = True

    def _drain_history_sync(self) -> None:
        return

    def _terminal_width(self) -> int:
        return 100


def _task_tool_call(*, tool_call_id: str, description: str, prompt: str) -> ToolCall:
    return ToolCall(
        id=tool_call_id,
        type="function",
        function=Function(
            name="Agent",
            arguments=json.dumps(
                {
                    "subagent_type": "Plan",
                    "description": description,
                    "prompt": prompt,
                },
                ensure_ascii=False,
            ),
        ),
    )


class TestHistorySync(unittest.TestCase):
    def test_resume_history_skips_meta_user_messages(self) -> None:
        items = [
            ContextItem(
                item_type=ItemType.USER_MESSAGE,
                message=UserMessage(content="<session-state>hidden</session-state>", is_meta=True),
                content_text="<session-state>hidden</session-state>",
            ),
            ContextItem(
                item_type=ItemType.USER_MESSAGE,
                message=UserMessage(content="visible user input"),
                content_text="visible user input",
            ),
        ]
        sync = _DummyHistorySync(items)

        sync.add_resume_history("resume")

        user_entries = [entry for entry in sync._renderer.history_entries() if entry.entry_type == "user"]
        self.assertEqual(len(user_entries), 1)
        self.assertEqual(user_entries[0].text, "visible user input")

        system_entries = [entry for entry in sync._renderer.history_entries() if entry.entry_type == "system"]
        self.assertTrue(system_entries)
        self.assertIn("history loaded: 1 messages", str(system_entries[-1].text))

    def test_resume_history_task_signature_uses_subagent_and_description(self) -> None:
        task_call = _task_tool_call(
            tool_call_id="tc_plan_ok",
            description="设计 Queue Panel 实现方案",
            prompt="MODE: create\nPLAN_FILE: ~/.agent/plans/terminal-agent-queue-panel.md",
        )
        items = [
            ContextItem(
                item_type=ItemType.ASSISTANT_MESSAGE,
                message=AssistantMessage(content="", tool_calls=[task_call]),
                content_text="",
            ),
            ContextItem(
                item_type=ItemType.TOOL_RESULT,
                message=ToolMessage(
                    tool_call_id="tc_plan_ok",
                    tool_name="Agent",
                    content="done",
                    is_error=False,
                ),
                content_text="done",
                tool_name="Agent",
            ),
        ]
        sync = _DummyHistorySync(items)

        sync.add_resume_history("resume")

        tool_results = [
            entry for entry in sync._renderer.history_entries() if entry.entry_type == "tool_result"
        ]
        self.assertEqual(len(tool_results), 1)
        text = str(tool_results[0].text)
        self.assertIn("Plan(设计 Queue Panel 实现方案)", text)
        self.assertNotIn("MODE: create", text)
        self.assertNotIn("Task({", text)

    def test_resume_history_task_error_keeps_error_severity(self) -> None:
        task_call = _task_tool_call(
            tool_call_id="tc_plan_err",
            description="设计 Queue Panel 实现方案",
            prompt="MODE: create\nPLAN_FILE: ~/.agent/plans/terminal-agent-queue-panel.md",
        )
        items = [
            ContextItem(
                item_type=ItemType.ASSISTANT_MESSAGE,
                message=AssistantMessage(content="", tool_calls=[task_call]),
                content_text="",
            ),
            ContextItem(
                item_type=ItemType.TOOL_RESULT,
                message=ToolMessage(
                    tool_call_id="tc_plan_err",
                    tool_name="Agent",
                    content="Error: something failed",
                    is_error=True,
                ),
                content_text="Error: something failed",
                tool_name="Agent",
            ),
        ]
        sync = _DummyHistorySync(items)

        sync.add_resume_history("resume")

        tool_results = [
            entry for entry in sync._renderer.history_entries() if entry.entry_type == "tool_result"
        ]
        self.assertEqual(len(tool_results), 1)
        self.assertEqual(tool_results[0].severity, "error")
        self.assertIn("Plan(设计 Queue Panel 实现方案)", str(tool_results[0].text))

    def test_resume_history_edit_result_keeps_diff_subtitle(self) -> None:
        edit_call = ToolCall(
            id="tc_edit_ok",
            type="function",
            function=Function(
                name="Edit",
                arguments=json.dumps(
                    {
                        "file_path": str(Path.cwd() / "docs/superpowers/specs/2026-04-01-conditional-diff-subtitle-design.md"),
                        "old_string": "old",
                        "new_string": "new",
                    }
                ),
            ),
        )
        items = [
            ContextItem(
                item_type=ItemType.ASSISTANT_MESSAGE,
                message=AssistantMessage(content="", tool_calls=[edit_call]),
                content_text="",
            ),
            ContextItem(
                item_type=ItemType.TOOL_RESULT,
                message=ToolMessage(
                    tool_call_id="tc_edit_ok",
                    tool_name="Edit",
                    content="ok",
                    is_error=False,
                ),
                content_text="ok",
                tool_name="Edit",
                metadata={
                    "tool_raw_envelope": {
                        "data": {
                            "diff": ["@@ -1 +1 @@", "+added", "-removed"],
                        }
                    }
                },
            ),
        ]
        sync = _DummyHistorySync(items)

        sync.add_resume_history("resume")

        tool_results = [
            entry for entry in sync._renderer.history_entries() if entry.entry_type == "tool_result"
        ]
        self.assertEqual(len(tool_results), 1)
        self.assertEqual(tool_results[0].subtitle, "Added 1 line, removed 1 line")
        self.assertIn("Update(", str(tool_results[0].text))

    def test_resume_history_edit_no_changes_keeps_no_changes_subtitle(self) -> None:
        edit_call = ToolCall(
            id="tc_edit_noop",
            type="function",
            function=Function(
                name="Edit",
                arguments=json.dumps(
                    {
                        "file_path": str(Path.cwd() / "docs/superpowers/specs/2026-04-01-conditional-diff-subtitle-design.md"),
                        "old_string": "same",
                        "new_string": "same",
                    }
                ),
            ),
        )
        items = [
            ContextItem(
                item_type=ItemType.ASSISTANT_MESSAGE,
                message=AssistantMessage(content="", tool_calls=[edit_call]),
                content_text="",
            ),
            ContextItem(
                item_type=ItemType.TOOL_RESULT,
                message=ToolMessage(
                    tool_call_id="tc_edit_noop",
                    tool_name="Edit",
                    content="ok",
                    is_error=False,
                ),
                content_text="ok",
                tool_name="Edit",
                metadata={
                    "tool_raw_envelope": {
                        "data": {
                            "diff": ["@@ -1 +1 @@", " unchanged"],
                        }
                    }
                },
            ),
        ]
        sync = _DummyHistorySync(items)

        sync.add_resume_history("resume")

        tool_results = [
            entry for entry in sync._renderer.history_entries() if entry.entry_type == "tool_result"
        ]
        self.assertEqual(len(tool_results), 1)
        self.assertEqual(tool_results[0].subtitle, "No changes")

    def test_resume_history_prefers_observable_tool_args(self) -> None:
        read_call = ToolCall(
            id="tc_read_observable",
            type="function",
            function=Function(
                name="Read",
                arguments=json.dumps(
                    {
                        "file_path": str(Path.cwd() / "README.md"),
                    }
                ),
            ),
        )
        items = [
            ContextItem(
                item_type=ItemType.ASSISTANT_MESSAGE,
                message=AssistantMessage(content="", tool_calls=[read_call]),
                content_text="",
                metadata={
                    TOOL_OBSERVABLE_INPUTS_METADATA_KEY: {
                        "tc_read_observable": {
                            "file_path": str(Path.cwd() / "README.md"),
                            "offset_line": 1,
                            "limit_lines": 200,
                        }
                    }
                },
            ),
            ContextItem(
                item_type=ItemType.TOOL_RESULT,
                message=ToolMessage(
                    tool_call_id="tc_read_observable",
                    tool_name="Read",
                    content="ok",
                    is_error=False,
                ),
                content_text="ok",
                tool_name="Read",
            ),
        ]
        sync = _DummyHistorySync(items)

        sync.add_resume_history("resume")

        tool_results = [
            entry for entry in sync._renderer.history_entries() if entry.entry_type == "tool_result"
        ]
        self.assertEqual(len(tool_results), 1)
        self.assertIn("offset=1", str(tool_results[0].text))
        self.assertIn("limit=200", str(tool_results[0].text))

    def test_resume_history_bash_uses_observable_env_summary(self) -> None:
        bash_call = ToolCall(
            id="tc_bash_env",
            type="function",
            function=Function(
                name="Bash",
                arguments=json.dumps(
                    {
                        "args": ["npm", "test"],
                    }
                ),
            ),
        )
        items = [
            ContextItem(
                item_type=ItemType.ASSISTANT_MESSAGE,
                message=AssistantMessage(content="", tool_calls=[bash_call]),
                content_text="",
                metadata={
                    TOOL_OBSERVABLE_INPUTS_METADATA_KEY: {
                        "tc_bash_env": {
                            "command": "npm test",
                            "env": {"NODE_ENV": "test"},
                            "timeout_ms": 120000,
                            "max_output_chars": 30000,
                        }
                    }
                },
            ),
            ContextItem(
                item_type=ItemType.TOOL_RESULT,
                message=ToolMessage(
                    tool_call_id="tc_bash_env",
                    tool_name="Bash",
                    content="ok",
                    is_error=False,
                ),
                content_text="ok",
                tool_name="Bash",
            ),
        ]
        sync = _DummyHistorySync(items)

        sync.add_resume_history("resume")

        tool_results = [
            entry for entry in sync._renderer.history_entries() if entry.entry_type == "tool_result"
        ]
        self.assertEqual(len(tool_results), 1)
        rendered = str(tool_results[0].text)
        self.assertIn("env=NODE_ENV=test", rendered)
        self.assertIn("command=npm test", rendered)


class TestHistorySyncAsync(unittest.IsolatedAsyncioTestCase):
    async def test_drain_history_async_uses_executor_terminal_print(self) -> None:
        sync = _DummyHistorySync([])
        sync._renderer.append_system_message("hello")

        with mock.patch(
            "comate_cli.terminal_agent.tui_parts.history_sync.run_in_terminal",
            new=mock.AsyncMock(),
        ) as mock_run_in_terminal:
            await sync._drain_history_async()

        mock_run_in_terminal.assert_awaited_once()
        self.assertTrue(mock_run_in_terminal.await_args.kwargs["in_executor"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
