from __future__ import annotations

import unittest
from types import SimpleNamespace

from comate_agent_sdk.context import ContextIR, TokenCounter
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.skill.models import SkillDefinition
from comate_cli.terminal_agent.slash_commands import SlashCommandSpec
from comate_cli.terminal_agent.tui import TerminalAgentTUI
from comate_cli.terminal_agent.tui_parts.slash_command_registry import SlashCommandRegistry
from comate_cli.terminal_agent.tui_parts.commands import CommandsMixin
from comate_cli.terminal_agent.tui_parts.ui_mode import UIMode


class _FakeRenderer:
    def __init__(self) -> None:
        self.messages: list[tuple[str, str]] = []

    def append_system_message(self, text: str, *, severity: str = "info") -> None:
        self.messages.append((text, severity))


class _FakeSelectionUI:
    def __init__(self, *, set_options_ok: bool = True) -> None:
        self.set_options_ok = set_options_ok
        self.last_kwargs: dict | None = None
        self.on_confirm = None
        self.on_cancel = None
        self.refresh_calls = 0

    def set_options(self, **kwargs) -> bool:  # type: ignore[no-untyped-def]
        self.last_kwargs = kwargs
        self.on_confirm = kwargs.get("on_confirm")
        self.on_cancel = kwargs.get("on_cancel")
        return self.set_options_ok

    def refresh(self) -> None:
        self.refresh_calls += 1


class _FakeSlashCompleter:
    def __init__(self) -> None:
        self.updated_specs: tuple[SlashCommandSpec, ...] = ()

    def update_commands(self, commands: tuple[SlashCommandSpec, ...]) -> None:
        self.updated_specs = commands


class _Harness(CommandsMixin):
    def __init__(
        self,
        *,
        session: object,
        renderer: _FakeRenderer,
        selection_ui: _FakeSelectionUI,
    ) -> None:
        self._session = session
        self._renderer = renderer
        self._selection_ui = selection_ui
        self._ui_mode = UIMode.NORMAL
        self._prefill_text: str | None = None
        self._preserve_trailing_space = False
        self._sync_focus_calls = 0
        self._invalidate_calls = 0
        self._refresh_calls = 0
        self._skill_slash_command_names: set[str] = set()
        self._loaded_plugins: list[object] = []
        self.submitted: list[tuple[str, str | None]] = []

    def _terminal_width(self) -> int:
        return 80

    def _prefill_user_input(
        self,
        text: str,
        *,
        preserve_trailing_space: bool = False,
    ) -> None:
        self._prefill_text = text
        self._preserve_trailing_space = preserve_trailing_space

    async def _submit_user_message(
        self,
        text: str,
        *,
        display_text: str | None = None,
    ) -> None:
        self.submitted.append((text, display_text))

    def _sync_focus_for_mode(self) -> None:
        self._sync_focus_calls += 1

    def _invalidate(self) -> None:
        self._invalidate_calls += 1

    def _refresh_layers(self) -> None:
        self._refresh_calls += 1


def _build_session(skills: list[object] | None) -> object:
    agent = SimpleNamespace(_runtime_state=SimpleNamespace(skills=skills))
    return SimpleNamespace(_agent=agent)


def _noop_handler(_args: str) -> None:
    return None


class TestSkillsSlashCommand(unittest.TestCase):
    def test_slash_skills_usage_error(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(skills=[]),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        app._slash_skills("--bad")

        self.assertEqual(renderer.messages[-1], ("Usage: /skills", "error"))

    def test_slash_skills_no_active_skills(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(
                skills=[
                    SimpleNamespace(
                        name="hidden",
                        description="hidden",
                        disable_model_invocation=True,
                    )
                ]
            ),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        app._slash_skills("")

        self.assertEqual(renderer.messages[-1], ("No active skills loaded.", "info"))
        self.assertIsNone(selection_ui.last_kwargs)

    def test_slash_skills_opens_inline_selection_with_filtered_skills(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(
                skills=[
                    SimpleNamespace(
                        name="find-skills",
                        description="discover and install skills",
                        when_to_use="Use when discovery is needed",
                        disable_model_invocation=False,
                    ),
                    SimpleNamespace(
                        name="hidden",
                        description="should be filtered",
                        disable_model_invocation=True,
                    ),
                ]
            ),
            renderer=renderer,
            selection_ui=selection_ui,
        )
        app._skill_slash_command_names = {"find-skills"}

        app._slash_skills("")

        token_count = TokenCounter().count(
            "find-skills discover and install skills Use when discovery is needed"
        )
        self.assertIsNotNone(selection_ui.last_kwargs)
        assert selection_ui.last_kwargs is not None
        self.assertEqual(selection_ui.last_kwargs["title"], "Select Skill")
        self.assertEqual(
            selection_ui.last_kwargs["options"],
            [
                {
                    "value": "find-skills",
                    "label": "find-skills",
                    "description": f"· user · ~{token_count} tok",
                }
            ],
        )
        self.assertEqual(selection_ui.last_kwargs["layout_mode"], "inline")
        self.assertFalse(selection_ui.last_kwargs["line_wrap"])
        self.assertEqual(selection_ui.last_kwargs["inline_total_width"], 80)
        self.assertEqual(selection_ui.refresh_calls, 1)
        self.assertEqual(app._ui_mode, UIMode.SELECTION)
        self.assertEqual(app._sync_focus_calls, 1)
        self.assertEqual(app._invalidate_calls, 1)

    def test_slash_skills_confirm_prefills_input(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(
                skills=[
                    SimpleNamespace(
                        name="Skill Creator",
                        description="Create or update a skill",
                        disable_model_invocation=False,
                    )
                ]
            ),
            renderer=renderer,
            selection_ui=selection_ui,
        )
        app._skill_slash_command_names = {"Skill Creator"}

        app._slash_skills("")
        assert selection_ui.on_confirm is not None
        selection_ui.on_confirm("Skill Creator")

        self.assertEqual(app._prefill_text, "/Skill Creator ")
        self.assertTrue(app._preserve_trailing_space)
        self.assertGreaterEqual(app._refresh_calls, 1)

    def test_active_session_skills_fills_empty_description(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(
                skills=[
                    SimpleNamespace(
                        name="skill-a",
                        description="",
                        disable_model_invocation=False,
                    )
                ]
            ),
            renderer=renderer,
            selection_ui=selection_ui,
        )
        app._skill_slash_command_names = {"skill-a"}

        active = app._active_session_skills()

        token_count = TokenCounter().count("skill-a")
        self.assertEqual(
            active,
            [{"name": "skill-a", "description": f"· user · ~{token_count} tok"}],
        )

    def test_active_session_skills_marks_plugin_source(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        app = _Harness(
            session=_build_session(
                skills=[
                    SimpleNamespace(
                        name="tools:review",
                        description="review",
                        when_to_use="review code",
                    )
                ]
            ),
            renderer=renderer,
            selection_ui=selection_ui,
        )
        app._skill_slash_command_names = {"tools:review"}
        app._loaded_plugins = [SimpleNamespace(namespace="tools")]

        active = app._active_session_skills()

        token_count = TokenCounter().count("tools:review review review code")
        self.assertEqual(
            active,
            [
                {
                    "name": "tools:review",
                    "description": f"· plugin · ~{token_count} tok",
                }
            ],
        )


class TestSkillSlashHandler(unittest.IsolatedAsyncioTestCase):
    async def test_slash_skill_injects_prompt_and_submits_short_continuation(self) -> None:
        renderer = _FakeRenderer()
        selection_ui = _FakeSelectionUI()
        agent = SimpleNamespace(
            _context=ContextIR(),
            _session_id="session-123",
            _runtime_state=SimpleNamespace(
                skills=[
                    SkillDefinition(
                        name="review",
                        description="review",
                        prompt="Review $target.",
                        argument_names=("target",),
                    )
                ]
            ),
        )
        app = _Harness(
            session=SimpleNamespace(_agent=agent),
            renderer=renderer,
            selection_ui=selection_ui,
        )

        await app._slash_skill(skill_name="review", args="README.md")

        self.assertEqual(
            agent._context.conversation.items[0].content_text,
            "<command-message>review</command-message>\n"
            "<command-name>/review</command-name>\n"
            "<command-args>README.md</command-args>",
        )
        skill_items = [
            item
            for item in agent._context.conversation.items
            if item.item_type == ItemType.SKILL_PROMPT
        ]
        self.assertEqual(len(skill_items), 1)
        self.assertIsNotNone(skill_items[0].message)
        assert skill_items[0].message is not None
        self.assertEqual(skill_items[0].message.text, "Review README.md.")
        self.assertEqual(
            app.submitted,
            [
                (
                    "The requested skill has already been loaded. Continue using the injected skill instructions.\n\n"
                    "Arguments: README.md",
                    "/review README.md",
                )
            ],
        )


class TestSkillSlashRegistration(unittest.TestCase):
    def test_sync_registers_only_user_invocable_non_conflicting_skills(self) -> None:
        registry = SlashCommandRegistry()
        registry.register(
            spec=SlashCommandSpec(
                name="help",
                description="help",
                execution_kind="local",
            ),
            handler=_noop_handler,
        )
        completer = _FakeSlashCompleter()
        app = TerminalAgentTUI.__new__(TerminalAgentTUI)
        app._session = _build_session(
            [
                SkillDefinition(
                    name="demo",
                    description="demo",
                    prompt="Prompt.",
                    disable_model_invocation=True,
                ),
                SkillDefinition(
                    name="hidden",
                    description="hidden",
                    prompt="Prompt.",
                    user_invocable=False,
                ),
                SkillDefinition(
                    name="help",
                    description="conflict",
                    prompt="Prompt.",
                ),
            ]
        )
        app._slash_registry = registry
        app._skill_slash_command_names = set()
        app._slash_completer = completer

        app._sync_skill_slash_commands()

        demo = registry.resolve("demo")
        self.assertIsNotNone(demo)
        assert demo is not None
        self.assertEqual(demo.source, "skill")
        self.assertEqual(demo.spec.execution_kind, "hybrid")
        self.assertIsNone(registry.resolve("hidden"))
        self.assertEqual(registry.resolve("help").source, "builtin")  # type: ignore[union-attr]
        self.assertEqual(app._skill_slash_command_names, {"demo"})
        self.assertIn("demo", {spec.name for spec in completer.updated_specs})


if __name__ == "__main__":
    unittest.main()
