"""Tests for _format_task_row after visual redesign."""
from __future__ import annotations

from comate_cli.terminal_agent.event_renderer import _format_task_row


def test_completed_task_row():
    task = {"id": "1", "subject": "Set up project", "status": "completed", "owner": "alice", "open_blocked_by": []}
    result = _format_task_row(task)
    assert result == "✓ Set up project"
    assert "[#" not in result
    assert "owner=" not in result


def test_in_progress_task_row():
    task = {"id": "2", "subject": "Implement auth", "status": "in_progress", "owner": "bob", "open_blocked_by": []}
    result = _format_task_row(task)
    assert result == "◼ Implement auth"
    assert "[#" not in result
    assert "owner=" not in result


def test_pending_unblocked_task_row():
    task = {"id": "3", "subject": "Write tests", "status": "pending", "owner": "", "open_blocked_by": []}
    result = _format_task_row(task)
    assert result == "▢ Write tests"


def test_pending_blocked_task_row():
    """Blocked pending uses ▫ (U+25AB) as intermediate symbol for color differentiation."""
    task = {"id": "4", "subject": "Deploy", "status": "pending", "owner": "", "open_blocked_by": ["1", "2"]}
    result = _format_task_row(task)
    assert result == "▫ Deploy"
    assert "blocked by" not in result
    assert "owner=" not in result


def test_untitled_task_row():
    task = {"id": "5", "subject": "", "status": "pending", "owner": "", "open_blocked_by": []}
    result = _format_task_row(task)
    assert result == "▢ (untitled)"


from comate_cli.terminal_agent.event_renderer import EventRenderer


def _make_renderer_for_title_test() -> EventRenderer:
    """创建最小化 EventRenderer 用于测试 _update_tasks 的标题逻辑。"""
    renderer = object.__new__(EventRenderer)
    renderer._current_tasks = []
    renderer._current_task_title = None
    renderer._task_started_at_monotonic = None
    renderer._history = []
    return renderer


def test_title_shows_in_progress_subject():
    renderer = _make_renderer_for_title_test()
    tasks = [
        {"id": "1", "subject": "Set up project", "status": "completed", "open_blocked_by": []},
        {"id": "2", "subject": "Implement auth", "status": "in_progress", "open_blocked_by": []},
        {"id": "3", "subject": "Write tests", "status": "pending", "open_blocked_by": []},
    ]
    renderer._update_tasks(tasks, list_id="default")
    assert renderer._current_task_title == "Implement auth"


def test_title_shows_smallest_id_in_progress():
    renderer = _make_renderer_for_title_test()
    tasks = [
        {"id": "3", "subject": "Task C", "status": "in_progress", "open_blocked_by": []},
        {"id": "1", "subject": "Task A", "status": "in_progress", "open_blocked_by": []},
        {"id": "2", "subject": "Task B", "status": "pending", "open_blocked_by": []},
    ]
    renderer._update_tasks(tasks, list_id="default")
    assert renderer._current_task_title == "Task A"


def test_title_falls_back_to_stats_when_no_in_progress():
    renderer = _make_renderer_for_title_test()
    tasks = [
        {"id": "1", "subject": "Set up project", "status": "pending", "open_blocked_by": []},
        {"id": "2", "subject": "Write tests", "status": "pending", "open_blocked_by": []},
    ]
    renderer._update_tasks(tasks, list_id="default")
    assert renderer._current_task_title == "2 tasks (0 done, 2 open)"


def test_title_ignores_list_id():
    renderer = _make_renderer_for_title_test()
    tasks = [
        {"id": "1", "subject": "Task A", "status": "pending", "open_blocked_by": []},
    ]
    renderer._update_tasks(tasks, list_id="team-alpha")
    assert renderer._current_task_title == "1 task (0 done, 1 open)"
    assert "team-alpha" not in (renderer._current_task_title or "")
