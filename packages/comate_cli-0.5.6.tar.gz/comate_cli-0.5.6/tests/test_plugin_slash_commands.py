import unittest

from comate_cli.terminal_agent.slash_commands import SLASH_COMMAND_SPECS


class TestPluginSlashCommandRegistration(unittest.TestCase):
    def test_plugin_command_registered(self) -> None:
        names = {cmd.name for cmd in SLASH_COMMAND_SPECS}
        self.assertIn("plugin", names)

    def test_reload_plugins_command_registered(self) -> None:
        names = {cmd.name for cmd in SLASH_COMMAND_SPECS}
        self.assertIn("reload-plugins", names)

    def test_plugin_command_is_local(self) -> None:
        cmd = next(c for c in SLASH_COMMAND_SPECS if c.name == "plugin")
        self.assertEqual(cmd.execution_kind, "local")
