import unittest


class TestParsePluginArgs(unittest.TestCase):
    def test_empty_args(self) -> None:
        from comate_cli.terminal_agent.plugins.plugin_picker import parse_plugin_args
        ctx = parse_plugin_args("")
        self.assertEqual(ctx.initial_tab, "discover")
        self.assertIsNone(ctx.target_plugin)

    def test_install_command(self) -> None:
        from comate_cli.terminal_agent.plugins.plugin_picker import parse_plugin_args
        ctx = parse_plugin_args("install compound-engineering")
        self.assertEqual(ctx.initial_tab, "discover")
        self.assertEqual(ctx.target_plugin, "compound-engineering")
        self.assertEqual(ctx.action, "install")

    def test_uninstall_command(self) -> None:
        from comate_cli.terminal_agent.plugins.plugin_picker import parse_plugin_args
        ctx = parse_plugin_args("uninstall compound-engineering@mkt")
        self.assertEqual(ctx.initial_tab, "installed")
        self.assertEqual(ctx.target_plugin, "compound-engineering@mkt")
        self.assertEqual(ctx.action, "uninstall")

    def test_marketplace_add(self) -> None:
        from comate_cli.terminal_agent.plugins.plugin_picker import parse_plugin_args
        ctx = parse_plugin_args("marketplace add EveryInc/compound-engineering-plugin")
        self.assertEqual(ctx.initial_tab, "marketplaces")
        self.assertEqual(ctx.target_marketplace, "EveryInc/compound-engineering-plugin")
        self.assertEqual(ctx.action, "add")

    def test_enable_command(self) -> None:
        from comate_cli.terminal_agent.plugins.plugin_picker import parse_plugin_args
        ctx = parse_plugin_args("enable my-plugin")
        self.assertEqual(ctx.initial_tab, "installed")
        self.assertEqual(ctx.action, "enable")

    def test_marketplace_update(self) -> None:
        from comate_cli.terminal_agent.plugins.plugin_picker import parse_plugin_args
        ctx = parse_plugin_args("marketplace update superpowers-marketplace")
        self.assertEqual(ctx.initial_tab, "marketplaces")
        self.assertEqual(ctx.action, "update")


class TestDiscoverTabInterfaces(unittest.TestCase):
    def _make_entry(self, name, description, **kwargs):
        """创建一个正确设置 .name 属性的 mock entry。"""
        from unittest.mock import MagicMock
        entry = MagicMock()
        # MagicMock(name=...) 是 mock 内部名称而非 .name 属性，需要单独赋值
        entry.name = name
        entry.description = description
        from comate_agent_sdk.plugins.models import PluginSource
        entry.source = kwargs.get("source", PluginSource(type="local", path="s"))
        entry.author = kwargs.get("author", "a")
        entry.tags = kwargs.get("tags", [])
        entry.homepage = kwargs.get("homepage", "")
        return entry

    def _make_tab(self):
        from unittest.mock import MagicMock
        from comate_cli.terminal_agent.plugins.tabs.discover_tab import DiscoverTab
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerContext
        plugin_mgr = MagicMock()
        mkt_mgr = MagicMock()
        mkt_mgr.list_all_available_plugins.return_value = {
            "test-mkt": [
                self._make_entry("plugin-a", "desc a"),
                self._make_entry("plugin-b", "desc b"),
            ]
        }
        registry = MagicMock()
        registry.list_installed.return_value = {}
        loader = MagicMock()
        ctx = PluginPickerContext()
        tab = DiscoverTab(plugin_mgr, mkt_mgr, registry, loader, ctx)
        tab.activate()
        return tab

    def test_get_cursor_info(self):
        tab = self._make_tab()
        self.assertEqual(tab.get_cursor_info(), (1, 2))

    def test_get_cursor_info_empty(self):
        from unittest.mock import MagicMock
        from comate_cli.terminal_agent.plugins.tabs.discover_tab import DiscoverTab
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerContext
        plugin_mgr = MagicMock()
        mkt_mgr = MagicMock()
        mkt_mgr.list_all_available_plugins.return_value = {}
        registry = MagicMock()
        registry.list_installed.return_value = {}
        tab = DiscoverTab(plugin_mgr, mkt_mgr, registry, MagicMock(), PluginPickerContext())
        tab.activate()
        self.assertIsNone(tab.get_cursor_info())

    def test_get_footer_hint_list(self):
        tab = self._make_tab()
        self.assertIn("Space", tab.get_footer_hint())

    def test_get_footer_hint_detail(self):
        tab = self._make_tab()
        tab._state = "DETAIL"
        self.assertIn("action", tab.get_footer_hint().lower())

    def test_is_searchable(self):
        tab = self._make_tab()
        self.assertTrue(tab.is_searchable())
        tab._state = "DETAIL"
        self.assertFalse(tab.is_searchable())

    def test_apply_filter(self):
        tab = self._make_tab()
        tab.apply_filter("plugin-a")
        self.assertEqual(len(tab._visible_items), 1)
        tab.apply_filter("")
        self.assertEqual(len(tab._visible_items), 2)

    def test_enter_with_selected_items_triggers_batch(self):
        from unittest.mock import patch, MagicMock
        tab = self._make_tab()
        tab.handle_space()  # select item 0
        mock_task = MagicMock()
        with patch("asyncio.create_task", return_value=mock_task) as mock_create:
            tab.handle_enter()
        self.assertEqual(tab._state, "LIST")
        self.assertIn("Installing", tab._status_message)
        mock_create.assert_called_once()


class TestInstalledTabInterfaces(unittest.TestCase):
    def _make_tab(self):
        from unittest.mock import MagicMock
        from comate_cli.terminal_agent.plugins.tabs.installed_tab import InstalledTab
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerContext
        plugin_mgr = MagicMock()
        registry = MagicMock()
        entry = MagicMock(version="1.0", scope="user", enabled=True, project_path=None)
        registry.list_installed.return_value = {"my-plugin@mkt": [entry]}
        tab = InstalledTab(plugin_mgr, registry, PluginPickerContext())
        tab.activate()
        return tab

    def test_get_cursor_info(self):
        tab = self._make_tab()
        self.assertEqual(tab.get_cursor_info(), (1, 1))

    def test_get_footer_hint_list(self):
        tab = self._make_tab()
        self.assertIn("Space", tab.get_footer_hint())

    def test_get_footer_hint_confirm(self):
        tab = self._make_tab()
        tab._state = "CONFIRM_UNINSTALL"
        self.assertIn("confirm", tab.get_footer_hint().lower())

    def test_is_searchable(self):
        tab = self._make_tab()
        self.assertTrue(tab.is_searchable())
        tab._state = "DETAIL"
        self.assertFalse(tab.is_searchable())

    def test_detail_actions_include_update(self):
        tab = self._make_tab()
        tab.handle_enter()
        self.assertEqual(tab._state, "DETAIL")
        self.assertIn("Update", tab._detail_actions)

    def test_confirm_text_uses_enter_esc(self):
        tab = self._make_tab()
        tab._state = "CONFIRM_UNINSTALL"
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("Enter", flat)
        self.assertNotIn("[y]", flat)


class TestErrorsTabInterfaces(unittest.TestCase):
    def _make_tab(self):
        from unittest.mock import MagicMock
        from comate_cli.terminal_agent.plugins.tabs.errors_tab import ErrorsTab
        loader = MagicMock()
        registry = MagicMock()
        registry.list_installed.return_value = {}
        tab = ErrorsTab(loader, registry)
        error1 = MagicMock(plugin_key="bad-plugin@mkt", error_type="LoadError", message="Failed to load", error_id="e1")
        error2 = MagicMock(plugin_key="other-plugin@mkt", error_type="ParseError", message="Invalid manifest", error_id="e2")
        tab.set_errors([error1, error2])
        return tab

    def test_get_cursor_info(self):
        tab = self._make_tab()
        self.assertEqual(tab.get_cursor_info(), (1, 2))

    def test_get_cursor_info_empty(self):
        from unittest.mock import MagicMock
        from comate_cli.terminal_agent.plugins.tabs.errors_tab import ErrorsTab
        tab = ErrorsTab(MagicMock(), MagicMock())
        self.assertIsNone(tab.get_cursor_info())

    def test_enter_goes_to_detail(self):
        tab = self._make_tab()
        tab.handle_enter()
        self.assertEqual(tab._state, "DETAIL")

    def test_detail_shows_actions(self):
        tab = self._make_tab()
        tab.handle_enter()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("Retry", flat)
        self.assertIn("Dismiss", flat)

    def test_esc_from_detail(self):
        tab = self._make_tab()
        tab.handle_enter()
        self.assertTrue(tab.go_back())
        self.assertEqual(tab._state, "LIST")

    def test_apply_filter(self):
        tab = self._make_tab()
        tab.apply_filter("bad")
        info = tab.get_cursor_info()
        self.assertEqual(info, (1, 1))
        tab.apply_filter("")
        self.assertEqual(tab.get_cursor_info(), (1, 2))

    def test_is_searchable(self):
        tab = self._make_tab()
        self.assertTrue(tab.is_searchable())
        tab.handle_enter()
        self.assertFalse(tab.is_searchable())


class TestMarketplacesTabInterfaces(unittest.TestCase):
    def _make_tab(self):
        from unittest.mock import MagicMock
        from comate_cli.terminal_agent.plugins.tabs.marketplaces_tab import MarketplacesTab
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerContext
        mkt_mgr = MagicMock()
        registry = MagicMock()
        mkt_info = MagicMock()
        mkt_info.source = MagicMock(repo="org/repo")
        mkt_info.install_location = "/tmp/mkt"
        mkt_info.last_updated = "2026-03-31T00:00:00"
        registry.list_marketplaces.return_value = {"test-mkt": mkt_info}
        registry.list_installed.return_value = {}
        tab = MarketplacesTab(mkt_mgr, registry, PluginPickerContext())
        tab.activate()
        return tab

    def test_get_cursor_info(self):
        tab = self._make_tab()
        self.assertEqual(tab.get_cursor_info(), (1, 2))  # Add row + 1 marketplace

    def test_detail_has_action_list(self):
        tab = self._make_tab()
        tab.handle_down()  # past Add row
        tab.handle_enter()
        self.assertEqual(tab._state, "DETAIL")
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("Browse", flat)
        self.assertIn("Update", flat)
        self.assertIn("Remove", flat)

    def test_detail_up_down(self):
        tab = self._make_tab()
        tab.handle_down()
        tab.handle_enter()  # DETAIL
        tab.handle_down()
        self.assertEqual(tab._detail_actions[tab._detail_cursor], "Update")

    def test_confirm_remove_esc_returns_to_detail(self):
        tab = self._make_tab()
        tab.handle_down()
        tab.handle_enter()  # DETAIL
        tab._state = "CONFIRM_REMOVE"
        tab.go_back()
        self.assertEqual(tab._state, "DETAIL")

    def test_confirm_text(self):
        tab = self._make_tab()
        tab._state = "CONFIRM_REMOVE"
        tab._selected_name = "test-mkt"
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("Enter", flat)
        self.assertNotIn("[y]", flat)

    def test_is_searchable(self):
        tab = self._make_tab()
        self.assertTrue(tab.is_searchable())
        tab._state = "DETAIL"
        self.assertFalse(tab.is_searchable())
        tab._state = "INPUT_ADD"
        self.assertFalse(tab.is_searchable())


class TestPluginPickerLayout(unittest.TestCase):
    def _make_picker(self):
        from unittest.mock import MagicMock
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerUI, PluginPickerContext
        registry = MagicMock()
        registry.list_installed.return_value = {}
        registry.list_marketplaces.return_value = {}
        plugin_mgr = MagicMock()
        mkt_mgr = MagicMock()
        mkt_mgr.list_all_available_plugins.return_value = {}
        loader = MagicMock()
        loader.errors = []
        ui = PluginPickerUI()
        ui.enter(
            registry=registry, plugin_manager=plugin_mgr,
            marketplace_manager=mkt_mgr, loader=loader,
            context=PluginPickerContext(),
        )
        return ui

    def test_layout_has_six_children(self):
        picker = self._make_picker()
        container = picker.container
        self.assertEqual(len(container.children), 6)

    def test_status_line_shows_tab_name(self):
        picker = self._make_picker()
        picker._ensure_tabs()
        status = picker._status_fragments()
        flat = "".join(t[1] for t in status)
        self.assertIn("Discover", flat)

    def test_footer_shows_hint(self):
        picker = self._make_picker()
        picker._ensure_tabs()
        tab = picker._active_tab()
        if hasattr(tab, "activate"):
            tab.activate()
        footer = picker._footer_fragments()
        flat = "".join(t[1] for t in footer)
        self.assertIn("Esc", flat)


class TestPluginPickerTypes(unittest.TestCase):
    def test_ui_mode_plugin_exists(self):
        from comate_cli.terminal_agent.tui_parts.ui_mode import UIMode
        self.assertEqual(UIMode.PLUGIN.value, "plugin")

    def test_plugin_picker_action_exit(self):
        from comate_cli.terminal_agent.plugins.plugin_picker import (
            PluginPickerAction,
            PluginPickerResult,
        )
        action = PluginPickerAction(kind="exit")
        self.assertEqual(action.kind, "exit")
        self.assertIsInstance(action.result, PluginPickerResult)

    def test_plugin_picker_action_noop(self):
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerAction
        action = PluginPickerAction(kind="noop")
        self.assertEqual(action.kind, "noop")


class TestPluginPickerUI(unittest.TestCase):
    def _make_ui(self):
        """创建 PluginPickerUI 并触发 layout 构建。"""
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerUI
        ui = PluginPickerUI()
        _ = ui.container  # 触发惰性 layout 构建（保证 _content_window 已赋值）
        return ui

    def _make_deps(self):
        from unittest.mock import MagicMock
        registry = MagicMock()
        plugin_mgr = MagicMock()
        mkt_mgr = MagicMock()
        mkt_mgr.list_all_available_plugins.return_value = {}
        registry.list_installed.return_value = {}
        loader = MagicMock()
        return registry, plugin_mgr, mkt_mgr, loader

    def test_no_arg_constructor(self):
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerUI
        ui = PluginPickerUI()
        self.assertIsNotNone(ui)

    def test_container_returns_hsplit(self):
        from prompt_toolkit.layout.containers import HSplit
        ui = self._make_ui()
        self.assertIsInstance(ui.container, HSplit)

    def test_container_same_object_on_repeated_access(self):
        ui = self._make_ui()
        self.assertIs(ui.container, ui.container)

    def test_enter_sets_active_tab_discover(self):
        ui = self._make_ui()
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerContext
        registry, plugin_mgr, mkt_mgr, loader = self._make_deps()
        ui.enter(
            registry=registry,
            plugin_manager=plugin_mgr,
            marketplace_manager=mkt_mgr,
            loader=loader,
            context=PluginPickerContext(initial_tab="discover"),
        )
        self.assertEqual(ui._ui_state.active_tab, 0)

    def test_enter_sets_active_tab_installed(self):
        ui = self._make_ui()
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerContext
        registry, plugin_mgr, mkt_mgr, loader = self._make_deps()
        ui.enter(
            registry=registry,
            plugin_manager=plugin_mgr,
            marketplace_manager=mkt_mgr,
            loader=loader,
            context=PluginPickerContext(initial_tab="installed"),
        )
        self.assertEqual(ui._ui_state.active_tab, 1)

    def test_enter_resets_tabs(self):
        """多次调用 enter() 时 _tabs 被重建（旧实例被丢弃）。"""
        ui = self._make_ui()
        registry, plugin_mgr, mkt_mgr, loader = self._make_deps()
        ui.enter(registry=registry, plugin_manager=plugin_mgr,
                 marketplace_manager=mkt_mgr, loader=loader)
        # 记录第一次构建后的 tab 实例
        first_tabs = list(ui._tabs)
        self.assertEqual(len(first_tabs), 4)
        # 再次 enter，enter() 内部会先重置再重建
        ui.enter(registry=registry, plugin_manager=plugin_mgr,
                 marketplace_manager=mkt_mgr, loader=loader)
        # _tabs 应被重建为新实例（旧实例已丢弃）
        self.assertEqual(len(ui._tabs), 4)
        self.assertIsNot(ui._tabs[0], first_tabs[0])

    def test_handle_escape_returns_exit_action(self):
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerAction
        ui = self._make_ui()
        action = ui.handle_escape()
        self.assertIsInstance(action, PluginPickerAction)
        self.assertEqual(action.kind, "exit")

    def test_handle_escape_clears_search_first(self):
        """search area 有文字时，第一次 escape 清除搜索而非退出。"""
        from prompt_toolkit.document import Document
        ui = self._make_ui()
        # 给 search area 填入文字
        ui._search_area.buffer.document = Document(text="hello", cursor_position=5)
        action = ui.handle_escape()
        self.assertIsNone(action)  # 第一次 escape：清搜索，不退出
        self.assertEqual(ui._search_area.text, "")

    def test_take_result_returns_result_and_resets(self):
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerResult
        ui = self._make_ui()
        ui._result.needs_reload = True
        result = ui.take_result()
        self.assertTrue(result.needs_reload)
        # 取走后 _result 重置
        self.assertFalse(ui._result.needs_reload)

    def test_handle_tab_advances_active_tab(self):
        ui = self._make_ui()
        registry, plugin_mgr, mkt_mgr, loader = self._make_deps()
        ui.enter(registry=registry, plugin_manager=plugin_mgr,
                 marketplace_manager=mkt_mgr, loader=loader)
        initial_tab = ui._ui_state.active_tab
        ui.handle_tab()
        self.assertEqual(ui._ui_state.active_tab, (initial_tab + 1) % 4)

    def test_handle_shift_tab_retreats_active_tab(self):
        ui = self._make_ui()
        registry, plugin_mgr, mkt_mgr, loader = self._make_deps()
        ui.enter(registry=registry, plugin_manager=plugin_mgr,
                 marketplace_manager=mkt_mgr, loader=loader)
        initial_tab = ui._ui_state.active_tab
        ui.handle_shift_tab()
        self.assertEqual(ui._ui_state.active_tab, (initial_tab - 1) % 4)

    def test_focus_target_always_returns_content_window(self):
        """focus_target() 始终返回 content_window（fzf 式焦点模型）。"""
        ui = self._make_ui()
        registry, plugin_mgr, mkt_mgr, loader = self._make_deps()
        ui.enter(registry=registry, plugin_manager=plugin_mgr,
                 marketplace_manager=mkt_mgr, loader=loader)
        ui._ensure_tabs()
        result = ui.focus_target()
        self.assertIs(result, ui.content_window)

    def test_no_run_method(self):
        """确认 run() 方法已被删除。"""
        ui = self._make_ui()
        self.assertFalse(hasattr(ui, "run"))

    def test_no_build_key_bindings_method(self):
        """确认 _build_key_bindings() 方法已被删除。"""
        ui = self._make_ui()
        self.assertFalse(hasattr(ui, "_build_key_bindings"))

    def test_enter_calls_activate_on_initial_tab(self):
        """enter() 应激活初始 tab（调用其 activate 方法）。"""
        ui = self._make_ui()
        registry, plugin_mgr, mkt_mgr, loader = self._make_deps()
        ui.enter(registry=registry, plugin_manager=plugin_mgr,
                 marketplace_manager=mkt_mgr, loader=loader)
        # DiscoverTab.activate() 会调用 mkt_mgr.list_all_available_plugins()
        mkt_mgr.list_all_available_plugins.assert_called_once()


class TestPluginPickerTabStyle(unittest.TestCase):
    def _make_ui_with_mock_tabs(self):
        from unittest.mock import MagicMock
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerUI
        ui = PluginPickerUI()
        # 注入 mock tabs 避免触发依赖初始化
        mock_errors_tab = MagicMock()
        mock_errors_tab.error_count = 0
        ui._tabs = [MagicMock(), MagicMock(), MagicMock(), mock_errors_tab]
        return ui

    def test_active_tab_uses_bold_reverse(self):
        """选中的 tab 应该使用 bold reverse 而不是 bold underline。"""
        ui = self._make_ui_with_mock_tabs()
        frags = ui._tabs_fragments()
        discover_style = next(style for style, text in frags if text == "Discover")
        self.assertIn("reverse", discover_style)
        self.assertNotIn("underline", discover_style)

    def test_inactive_tabs_have_no_style(self):
        """未选中的 tab 应该没有样式。"""
        ui = self._make_ui_with_mock_tabs()
        frags = ui._tabs_fragments()
        installed_style = next(style for style, text in frags if text == "Installed")
        self.assertEqual(installed_style, "")


class TestPlaceholderProcessor(unittest.TestCase):
    def _get_processor(self):
        from comate_cli.terminal_agent.plugins.plugin_picker import _PlaceholderProcessor
        return _PlaceholderProcessor("Search...")

    def test_empty_buffer_returns_placeholder(self):
        """buffer 为空时应返回占位符文字片段。"""
        from unittest.mock import MagicMock
        proc = self._get_processor()
        ti = MagicMock()
        ti.document.text = ""
        ti.fragments = []
        result = proc.apply_transformation(ti)
        self.assertEqual(len(result.fragments), 1)
        style, text = result.fragments[0]
        self.assertEqual(text, "Search...")
        self.assertIn("placeholder", style)

    def test_non_empty_buffer_passes_through(self):
        """buffer 有内容时应原样返回 fragments。"""
        from unittest.mock import MagicMock
        proc = self._get_processor()
        ti = MagicMock()
        ti.document.text = "context7"
        ti.fragments = [("", "context7")]
        result = proc.apply_transformation(ti)
        self.assertEqual(result.fragments, [("", "context7")])

    def test_placeholder_uses_plugin_scoped_style(self):
        """占位符样式应避免命中 prompt_toolkit 内置 search 类。"""
        from unittest.mock import MagicMock
        proc = self._get_processor()
        ti = MagicMock()
        ti.document.text = ""
        ti.fragments = []
        result = proc.apply_transformation(ti)
        style, _ = result.fragments[0]
        self.assertEqual(style, "class:plugin-search-placeholder")


class TestDiscoverTabListSymbols(unittest.TestCase):
    def _make_tab(self, installed_keys=None):
        from unittest.mock import MagicMock
        from comate_agent_sdk.plugins.models import PluginSource
        from comate_cli.terminal_agent.plugins.tabs.discover_tab import DiscoverTab
        from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerContext

        def _entry(name):
            e = MagicMock()
            e.name = name
            e.description = f"desc {name}"
            e.source = PluginSource(type="local", path=f"./{name}")
            e.author = None
            e.tags = []
            e.homepage = None
            return e

        mkt_mgr = MagicMock()
        mkt_mgr.list_all_available_plugins.return_value = {
            "mkt": [_entry("p0"), _entry("p1"), _entry("p2")]
        }
        registry = MagicMock()
        registry.list_installed.return_value = (
            {"p2@mkt": [MagicMock()]} if installed_keys else {}
        )
        tab = DiscoverTab(MagicMock(), mkt_mgr, registry, MagicMock(), PluginPickerContext())
        tab.activate()
        return tab

    def _flat_text(self, tab):
        return "".join(t[1] for t in tab.get_formatted_text())

    def test_normal_item_shows_circle(self):
        """未选中、未安装的条目应显示 ○。"""
        tab = self._make_tab()
        flat = self._flat_text(tab)
        self.assertIn("○", flat)

    def test_no_old_checkbox_style(self):
        """旧式括号 checkbox 不应出现。"""
        tab = self._make_tab()
        flat = self._flat_text(tab)
        self.assertNotIn("( )", flat)
        self.assertNotIn("(*)", flat)
        self.assertNotIn("(x)", flat)

    def test_no_cursor_arrow(self):
        """不应有 > 光标箭头。"""
        tab = self._make_tab()
        flat = self._flat_text(tab)
        self.assertNotIn("> ", flat)

    def test_installed_item_shows_checkmark(self):
        """已安装条目应显示 ✓。"""
        tab = self._make_tab(installed_keys=True)
        flat = self._flat_text(tab)
        self.assertIn("✓", flat)

    def test_selected_item_shows_filled_circle(self):
        """space 勾选后应显示 ●。"""
        tab = self._make_tab()
        tab.handle_space()  # 选中 cursor 所在的 item 0
        flat = self._flat_text(tab)
        self.assertIn("●", flat)
