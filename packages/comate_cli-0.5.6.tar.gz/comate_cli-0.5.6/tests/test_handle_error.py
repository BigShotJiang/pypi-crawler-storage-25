"""Tests for unified _handle_error() in TUI."""
from __future__ import annotations

import asyncio
import unittest
from unittest.mock import AsyncMock, MagicMock


def _make_tui_stub():
    """Create a minimal TUI stub with mocked dependencies."""
    tui = MagicMock()
    tui._renderer = MagicMock()
    tui._animation_controller = AsyncMock()
    tui._status_bar = MagicMock()
    tui._status_bar.refresh = AsyncMock()
    tui._last_turn_user_preview = "some preview"
    tui._run_start_time = 12345.0
    tui._interrupt_requested_at = 67890.0
    return tui


class TestHandleError(unittest.TestCase):
    def test_handle_error_stops_animation(self):
        """Regression: animation must be stopped on any error."""
        from comate_cli.terminal_agent.tui import TerminalAgentTUI

        tui = _make_tui_stub()
        exc = Exception("test error")

        asyncio.run(TerminalAgentTUI._handle_error(tui, exc))

        tui._animation_controller.shutdown.assert_awaited_once()

    def test_handle_error_sets_busy_false(self):
        from comate_cli.terminal_agent.tui import TerminalAgentTUI

        tui = _make_tui_stub()
        exc = Exception("test error")

        asyncio.run(TerminalAgentTUI._handle_error(tui, exc))

        tui._set_busy.assert_called_once_with(False)

    def test_handle_error_writes_to_scrollback(self):
        from comate_cli.terminal_agent.tui import TerminalAgentTUI

        tui = _make_tui_stub()
        exc = Exception("something broke")

        asyncio.run(TerminalAgentTUI._handle_error(tui, exc))

        tui._renderer.append_system_message.assert_called_once()
        call_args = tui._renderer.append_system_message.call_args
        assert "something broke" in call_args[0][0]
        assert call_args[1]["severity"] == "error"

    def test_handle_error_sets_transient_with_severity(self):
        from comate_cli.terminal_agent.tui import TerminalAgentTUI

        tui = _make_tui_stub()
        exc = Exception("something broke")

        asyncio.run(TerminalAgentTUI._handle_error(tui, exc))

        tui._status_bar.show_transient.assert_called_once()
        call_args = tui._status_bar.show_transient.call_args
        assert call_args[1]["severity"] == "error"

    def test_handle_error_resets_run_state(self):
        from comate_cli.terminal_agent.tui import TerminalAgentTUI

        tui = _make_tui_stub()
        exc = Exception("test")

        asyncio.run(TerminalAgentTUI._handle_error(tui, exc))

        assert tui._last_turn_user_preview is None
        assert tui._run_start_time is None
        assert tui._interrupt_requested_at is None

    def test_handle_error_calls_interrupt_turn(self):
        from comate_cli.terminal_agent.tui import TerminalAgentTUI

        tui = _make_tui_stub()
        exc = Exception("test")

        asyncio.run(TerminalAgentTUI._handle_error(tui, exc))

        tui._renderer.interrupt_turn.assert_called_once()

    def test_handle_error_refreshes_layers(self):
        from comate_cli.terminal_agent.tui import TerminalAgentTUI

        tui = _make_tui_stub()
        exc = Exception("test")

        asyncio.run(TerminalAgentTUI._handle_error(tui, exc))

        tui._refresh_layers.assert_called_once()

    def test_handle_error_warning_severity_for_rate_limit(self):
        """Rate limit errors should propagate warning severity to transient."""
        from comate_cli.terminal_agent.tui import TerminalAgentTUI

        tui = _make_tui_stub()
        exc = type("ModelRateLimitError", (Exception,), {})("rate limited")

        asyncio.run(TerminalAgentTUI._handle_error(tui, exc))

        call_args = tui._status_bar.show_transient.call_args
        assert call_args[1]["severity"] == "warning"


if __name__ == "__main__":
    unittest.main(verbosity=2)
