"""Tests for MarketplacesTab (Task 13)."""

from __future__ import annotations

import asyncio
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch


def _make_marketplace_info(
    name: str = "test-mkt",
    repo: str = "owner/test-mkt",
    last_updated: str = "2026-01-01T00:00:00+00:00",
) -> object:
    """构造一个 MarketplaceInfo mock。"""
    info = MagicMock()
    info.name = name
    info.source = MagicMock()
    info.source.repo = repo
    info.install_location = Path(f"/fake/marketplaces/{name}")
    info.last_updated = last_updated
    return info


def _make_context(
    target_marketplace: str | None = None,
    action: str | None = None,
) -> object:
    from comate_cli.terminal_agent.plugins.plugin_picker import PluginPickerContext

    return PluginPickerContext(
        initial_tab="marketplaces",
        target_marketplace=target_marketplace,
        action=action,
    )


def _make_tab(
    marketplaces: dict | None = None,
    installed: dict | None = None,
    target_marketplace: str | None = None,
) -> object:
    """构造 MarketplacesTab，注入 mock 依赖。"""
    from comate_cli.terminal_agent.plugins.tabs.marketplaces_tab import MarketplacesTab

    mkt_mgr = MagicMock()
    mkt_mgr.add = AsyncMock()
    mkt_mgr.update = AsyncMock()
    mkt_mgr.remove = AsyncMock()

    registry = MagicMock()
    registry.list_marketplaces = MagicMock(return_value=marketplaces or {})
    registry.list_installed = MagicMock(return_value=installed or {})

    context = _make_context(target_marketplace=target_marketplace)
    return MarketplacesTab(mkt_mgr, registry, context)


# ---------------------------------------------------------------------------
# activate
# ---------------------------------------------------------------------------


class TestMarketplacesTabActivate(unittest.TestCase):
    def test_activate_resets_state_to_list(self) -> None:
        tab = _make_tab()
        tab._state = "DETAIL"
        tab.activate()
        self.assertEqual(tab._state, "LIST")

    def test_activate_resets_cursor(self) -> None:
        tab = _make_tab(marketplaces={"mkt-a": _make_marketplace_info("mkt-a")})
        tab._cursor = 99
        tab.activate()
        self.assertEqual(tab._cursor, 0)

    def test_activate_resets_status_message(self) -> None:
        tab = _make_tab()
        tab._status_message = "stale message"
        tab.activate()
        self.assertEqual(tab._status_message, "")

    def test_activate_loads_marketplaces(self) -> None:
        marketplaces = {
            "mkt-a": _make_marketplace_info("mkt-a"),
            "mkt-b": _make_marketplace_info("mkt-b"),
        }
        tab = _make_tab(marketplaces=marketplaces)
        tab.activate()
        # items = [Add row, mkt-a, mkt-b]
        self.assertEqual(len(tab._items), 3)

    def test_activate_includes_add_row_at_top(self) -> None:
        tab = _make_tab()
        tab.activate()
        self.assertTrue(tab._items[0].get("is_add_row"))

    def test_activate_counts_installed_plugins(self) -> None:
        marketplaces = {"mkt-a": _make_marketplace_info("mkt-a")}
        installed = {
            "plugin-x@mkt-a": [MagicMock()],
            "plugin-y@mkt-a": [MagicMock()],
        }
        tab = _make_tab(marketplaces=marketplaces, installed=installed)
        tab.activate()
        # items[0] = Add row, items[1] = mkt-a
        mkt_item = tab._items[1]
        self.assertEqual(mkt_item["installed_count"], 2)


# ---------------------------------------------------------------------------
# 渲染
# ---------------------------------------------------------------------------


class TestMarketplacesTabRendering(unittest.TestCase):
    def test_list_state_shows_hint(self) -> None:
        tab = _make_tab()
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("Tab: switch tabs", flat)

    def test_list_state_shows_add_row(self) -> None:
        tab = _make_tab()
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("+ Add Marketplace", flat)

    def test_list_state_shows_marketplace_names(self) -> None:
        marketplaces = {"my-mkt": _make_marketplace_info("my-mkt", repo="owner/my-mkt")}
        tab = _make_tab(marketplaces=marketplaces)
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("my-mkt", flat)

    def test_empty_list_shows_no_marketplaces_message(self) -> None:
        tab = _make_tab()
        tab.activate()
        # 只有 Add 行，没有 marketplace 条目
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        # Add 行仍然存在
        self.assertIn("+ Add Marketplace", flat)

    def test_status_message_shows_in_list(self) -> None:
        tab = _make_tab()
        tab.activate()
        tab._status_message = "some status"
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("some status", flat)

    def test_detail_state_shows_marketplace_info(self) -> None:
        marketplaces = {"my-mkt": _make_marketplace_info("my-mkt", repo="owner/my-mkt")}
        tab = _make_tab(marketplaces=marketplaces)
        tab.activate()
        tab.handle_down()  # cursor to mkt item (idx 1)
        tab.handle_enter()  # enter DETAIL
        self.assertEqual(tab._state, "DETAIL")
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("my-mkt", flat)
        self.assertIn("owner/my-mkt", flat)

    def test_confirm_remove_shows_marketplace_name(self) -> None:
        marketplaces = {"my-mkt": _make_marketplace_info("my-mkt")}
        tab = _make_tab(marketplaces=marketplaces)
        tab.activate()
        tab._selected_name = "my-mkt"
        tab._state = "CONFIRM_REMOVE"
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("my-mkt", flat)
        self.assertIn("Enter: confirm", flat)

    def test_input_add_shows_target_marketplace(self) -> None:
        tab = _make_tab(target_marketplace="owner/new-mkt")
        tab.activate()
        tab._state = "INPUT_ADD"
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("owner/new-mkt", flat)

    def test_input_add_no_target_shows_hint(self) -> None:
        tab = _make_tab(target_marketplace=None)
        tab.activate()
        tab._state = "INPUT_ADD"
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("No marketplace specified", flat)


# ---------------------------------------------------------------------------
# 导航
# ---------------------------------------------------------------------------


class TestMarketplacesTabNavigation(unittest.TestCase):
    def setUp(self) -> None:
        self.marketplaces = {
            "mkt-a": _make_marketplace_info("mkt-a"),
            "mkt-b": _make_marketplace_info("mkt-b"),
        }
        self.tab = _make_tab(marketplaces=self.marketplaces)
        self.tab.activate()

    def test_initial_cursor_is_zero(self) -> None:
        self.assertEqual(self.tab._cursor, 0)

    def test_handle_down_advances_cursor(self) -> None:
        self.tab.handle_down()
        self.assertEqual(self.tab._cursor, 1)

    def test_handle_up_moves_cursor_back(self) -> None:
        self.tab.handle_down()
        self.tab.handle_up()
        self.assertEqual(self.tab._cursor, 0)

    def test_navigation_wraps_around(self) -> None:
        # 3 items total (Add + mkt-a + mkt-b), cursor starts at 0
        for _ in range(3):
            self.tab.handle_down()
        self.assertEqual(self.tab._cursor, 0)

    def test_navigation_ignored_in_detail_state(self) -> None:
        self.tab.handle_down()  # cursor = 1 (mkt-a)
        self.tab.handle_enter()  # enter DETAIL
        cursor_before = self.tab._cursor
        self.tab.handle_down()
        self.tab.handle_up()
        # 在 DETAIL 态导航不改变 cursor
        self.assertEqual(self.tab._cursor, cursor_before)


# ---------------------------------------------------------------------------
# 状态迁移
# ---------------------------------------------------------------------------


class TestMarketplacesTabStateTransitions(unittest.TestCase):
    def setUp(self) -> None:
        self.marketplaces = {"my-mkt": _make_marketplace_info("my-mkt")}
        self.tab = _make_tab(marketplaces=self.marketplaces)
        self.tab.activate()

    def test_initial_state_is_list(self) -> None:
        self.assertEqual(self.tab._state, "LIST")

    def test_enter_on_add_row_enters_input_add(self) -> None:
        # cursor 在 Add row（idx=0）
        self.assertEqual(self.tab._cursor, 0)
        self.tab.handle_enter()
        self.assertEqual(self.tab._state, "INPUT_ADD")

    def test_enter_on_marketplace_enters_detail(self) -> None:
        self.tab.handle_down()  # cursor = 1 (my-mkt)
        self.tab.handle_enter()
        self.assertEqual(self.tab._state, "DETAIL")
        self.assertEqual(self.tab._selected_name, "my-mkt")

    def test_go_back_from_detail_returns_list(self) -> None:
        self.tab.handle_down()
        self.tab.handle_enter()
        handled = self.tab.go_back()
        self.assertTrue(handled)
        self.assertEqual(self.tab._state, "LIST")

    def test_go_back_from_input_add_returns_list(self) -> None:
        self.tab.handle_enter()  # enter INPUT_ADD
        handled = self.tab.go_back()
        self.assertTrue(handled)
        self.assertEqual(self.tab._state, "LIST")

    def test_go_back_from_list_returns_false(self) -> None:
        self.assertFalse(self.tab.go_back())

    def test_enter_detail_remove_action_no_installed_triggers_remove(self) -> None:
        """DETAIL 态选 Remove 且无已安装插件时，应直接调度删除并返回 LIST。"""
        tab = _make_tab(marketplaces=self.marketplaces, installed={})
        tab.activate()
        tab.handle_down()  # cursor to my-mkt
        tab.handle_enter()  # enter DETAIL
        self.assertEqual(tab._state, "DETAIL")

        # 选到 Remove 动作（顺序：Browse plugins / Update / Remove / Back）
        tab.handle_down()
        tab.handle_down()

        with patch("asyncio.create_task") as mock_create:
            mock_create.side_effect = lambda coro: coro.close() or MagicMock()
            tab.handle_enter()

        self.assertEqual(tab._state, "LIST")
        self.assertIn("Removing", tab._status_message)
        mock_create.assert_called_once()

    def test_enter_detail_remove_action_with_installed_enters_confirm(self) -> None:
        """DETAIL 态选 Remove 且有已安装插件时，应进入 CONFIRM_REMOVE 状态。"""
        installed = {"plugin-x@my-mkt": [MagicMock()]}
        tab = _make_tab(marketplaces=self.marketplaces, installed=installed)
        tab.activate()
        tab.handle_down()  # cursor to my-mkt
        tab.handle_enter()  # enter DETAIL
        self.assertEqual(tab._state, "DETAIL")

        # 选到 Remove 动作
        tab.handle_down()
        tab.handle_down()
        tab.handle_enter()

        self.assertEqual(tab._state, "CONFIRM_REMOVE")
        self.assertEqual(tab._selected_name, "my-mkt")

    def test_go_back_from_confirm_remove_returns_detail(self) -> None:
        """go_back() 从 CONFIRM_REMOVE 返回 DETAIL（不是 LIST）。"""
        installed = {"plugin-x@my-mkt": [MagicMock()]}
        tab = _make_tab(marketplaces=self.marketplaces, installed=installed)
        tab.activate()
        tab.handle_down()
        tab.handle_enter()  # enter DETAIL
        # 选到 Remove 并进入 CONFIRM_REMOVE
        tab.handle_down()
        tab.handle_down()
        tab.handle_enter()
        self.assertEqual(tab._state, "CONFIRM_REMOVE")

        handled = tab.go_back()
        self.assertTrue(handled)
        self.assertEqual(tab._state, "DETAIL")

    def test_handle_enter_in_confirm_remove_triggers_remove(self) -> None:
        installed = {"plugin-x@my-mkt": [MagicMock()]}
        tab = _make_tab(marketplaces=self.marketplaces, installed=installed)
        tab.activate()
        tab.handle_down()
        tab.handle_enter()  # enter DETAIL
        # 选到 Remove 进入 CONFIRM_REMOVE
        tab.handle_down()
        tab.handle_down()
        tab.handle_enter()
        self.assertEqual(tab._state, "CONFIRM_REMOVE")

        with patch("asyncio.create_task") as mock_create:
            mock_create.side_effect = lambda coro: coro.close() or MagicMock()
            tab.handle_enter()  # confirm

        self.assertEqual(tab._state, "LIST")
        mock_create.assert_called_once()

    @patch("asyncio.create_task")
    def test_detail_update_action_schedules_task(
        self, mock_create: MagicMock
    ) -> None:
        """DETAIL 态选 Update 应调度 asyncio 任务。"""
        tab = _make_tab(marketplaces=self.marketplaces)
        tab.activate()
        tab.handle_down()  # cursor to my-mkt
        tab.handle_enter()  # enter DETAIL
        self.assertEqual(tab._state, "DETAIL")

        # 选到 Update 动作（顺序：Browse plugins / Update / Remove / Back）
        tab.handle_down()
        mock_create.side_effect = lambda coro: coro.close() or MagicMock()
        tab.handle_enter()

        mock_create.assert_called_once()
        self.assertIn("Updating", tab._status_message)

    @patch("asyncio.create_task")
    def test_detail_update_action_not_triggered_on_add_row(self, mock_create: MagicMock) -> None:
        """cursor 在 Add row 时 Enter 进入 INPUT_ADD，不调度 update 任务。"""
        tab = _make_tab(marketplaces=self.marketplaces)
        tab.activate()
        # cursor 在 Add row (idx=0)
        tab.handle_enter()
        self.assertEqual(tab._state, "INPUT_ADD")
        mock_create.assert_not_called()


# ---------------------------------------------------------------------------
# INPUT_ADD 确认
# ---------------------------------------------------------------------------


class TestMarketplacesTabInputAdd(unittest.TestCase):
    @patch("asyncio.create_task")
    def test_enter_in_input_add_with_target_schedules_add(
        self, mock_create: MagicMock
    ) -> None:
        tab = _make_tab(target_marketplace="owner/new-mkt")
        tab.activate()
        tab._state = "INPUT_ADD"
        mock_create.side_effect = lambda coro: coro.close() or MagicMock()
        tab.handle_enter()
        mock_create.assert_called_once()
        self.assertIn("Adding", tab._status_message)
        self.assertEqual(tab._state, "LIST")

    def test_enter_in_input_add_without_target_sets_error(self) -> None:
        tab = _make_tab(target_marketplace=None)
        tab.activate()
        tab._state = "INPUT_ADD"
        tab.handle_enter()
        self.assertIn("No marketplace specified", tab._status_message)
        self.assertEqual(tab._state, "INPUT_ADD")


# ---------------------------------------------------------------------------
# 异步操作
# ---------------------------------------------------------------------------


class TestMarketplacesTabAsync(unittest.IsolatedAsyncioTestCase):
    async def test_do_add_success_sets_status(self) -> None:
        tab = _make_tab()
        info_mock = MagicMock()
        info_mock.name = "new-mkt"
        tab._mkt_mgr.add = AsyncMock(return_value=info_mock)

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.marketplaces_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_add("owner/new-mkt")

        tab._mkt_mgr.add.assert_awaited_once_with("owner/new-mkt")
        self.assertIn("Added", tab._status_message)
        self.assertIn("new-mkt", tab._status_message)

    async def test_do_add_failure_sets_error_message(self) -> None:
        tab = _make_tab()
        tab._mkt_mgr.add = AsyncMock(side_effect=RuntimeError("git clone failed"))

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.marketplaces_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_add("owner/bad-mkt")

        self.assertIn("Failed", tab._status_message)
        self.assertIn("git clone failed", tab._status_message)

    async def test_do_update_success_sets_status(self) -> None:
        tab = _make_tab(marketplaces={"my-mkt": _make_marketplace_info("my-mkt")})
        tab.activate()

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.marketplaces_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_update("my-mkt")

        tab._mkt_mgr.update.assert_awaited_once_with("my-mkt")
        self.assertIn("Updated", tab._status_message)

    async def test_do_update_failure_sets_error_message(self) -> None:
        tab = _make_tab(marketplaces={"my-mkt": _make_marketplace_info("my-mkt")})
        tab.activate()
        tab._mkt_mgr.update = AsyncMock(side_effect=RuntimeError("network error"))

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.marketplaces_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_update("my-mkt")

        self.assertIn("Failed", tab._status_message)
        self.assertIn("network error", tab._status_message)

    async def test_do_remove_success_sets_status(self) -> None:
        tab = _make_tab(marketplaces={"my-mkt": _make_marketplace_info("my-mkt")})
        tab.activate()

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.marketplaces_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_remove("my-mkt")

        tab._mkt_mgr.remove.assert_awaited_once_with("my-mkt")
        self.assertIn("Removed", tab._status_message)

    async def test_do_remove_failure_sets_error_message(self) -> None:
        tab = _make_tab(marketplaces={"my-mkt": _make_marketplace_info("my-mkt")})
        tab.activate()
        tab._mkt_mgr.remove = AsyncMock(side_effect=ValueError("has installed plugins"))

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.marketplaces_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_remove("my-mkt")

        self.assertIn("Failed", tab._status_message)
        self.assertIn("has installed plugins", tab._status_message)

    async def test_do_add_reloads_items(self) -> None:
        """_do_add 成功后应重新加载条目列表。"""
        tab = _make_tab()
        tab.activate()
        initial_count = len(tab._items)

        info_mock = MagicMock()
        info_mock.name = "new-mkt"
        tab._mkt_mgr.add = AsyncMock(return_value=info_mock)
        # 模拟 registry 加载后新增了一个 marketplace
        new_mkt_info = _make_marketplace_info("new-mkt")
        tab._registry.list_marketplaces = MagicMock(return_value={"new-mkt": new_mkt_info})

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.marketplaces_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_add("owner/new-mkt")

        # 重新加载后条目数应增加
        self.assertGreater(len(tab._items), initial_count)
