from __future__ import annotations

import asyncio
import unittest
from io import StringIO
from unittest.mock import AsyncMock, MagicMock, patch

from comate_agent_sdk.agent import TextEvent, StopEvent, SessionInitEvent


class TestRunPrintMode(unittest.TestCase):
    """Tests for _run_print_mode in app.py."""

    def test_print_mode_outputs_last_text_event(self):
        """Should output only the last TextEvent.content to stdout."""
        from comate_cli.terminal_agent.app import _run_print_mode

        mock_session = MagicMock()
        mock_session.query_stream = MagicMock(return_value=_async_iter([
            SessionInitEvent(session_id="test"),
            TextEvent(content="first answer"),
            TextEvent(content="final answer"),
            StopEvent(reason="completed"),
        ]))
        mock_session.close = AsyncMock()
        mock_session.shutdown = AsyncMock()

        captured = StringIO()
        with patch("comate_cli.terminal_agent.app.ChatSession", return_value=mock_session):
            with patch("comate_cli.terminal_agent.app._preload_mcp_in_tui", new_callable=AsyncMock):
                with patch("comate_cli.terminal_agent.app._graceful_shutdown", new_callable=AsyncMock):
                    with patch("sys.stdout", captured):
                        asyncio.run(_run_print_mode(
                            MagicMock(), "test prompt", project_root=MagicMock()
                        ))

        self.assertIn("final answer", captured.getvalue())
        self.assertNotIn("first answer", captured.getvalue())

    def test_print_mode_no_text_event_silent_exit(self):
        """No TextEvent → silent exit, no output."""
        from comate_cli.terminal_agent.app import _run_print_mode

        mock_session = MagicMock()
        mock_session.query_stream = MagicMock(return_value=_async_iter([
            SessionInitEvent(session_id="test"),
            StopEvent(reason="completed"),
        ]))
        mock_session.close = AsyncMock()
        mock_session.shutdown = AsyncMock()

        captured = StringIO()
        with patch("comate_cli.terminal_agent.app.ChatSession", return_value=mock_session):
            with patch("comate_cli.terminal_agent.app._preload_mcp_in_tui", new_callable=AsyncMock):
                with patch("comate_cli.terminal_agent.app._graceful_shutdown", new_callable=AsyncMock):
                    with patch("sys.stdout", captured):
                        asyncio.run(_run_print_mode(
                            MagicMock(), "test", project_root=MagicMock()
                        ))

        self.assertEqual(captured.getvalue(), "")

    def test_print_mode_appends_newline_if_missing(self):
        """Output should end with newline even if content doesn't."""
        from comate_cli.terminal_agent.app import _run_print_mode

        mock_session = MagicMock()
        mock_session.query_stream = MagicMock(return_value=_async_iter([
            SessionInitEvent(session_id="test"),
            TextEvent(content="no newline"),
            StopEvent(reason="completed"),
        ]))
        mock_session.close = AsyncMock()
        mock_session.shutdown = AsyncMock()

        captured = StringIO()
        with patch("comate_cli.terminal_agent.app.ChatSession", return_value=mock_session):
            with patch("comate_cli.terminal_agent.app._preload_mcp_in_tui", new_callable=AsyncMock):
                with patch("comate_cli.terminal_agent.app._graceful_shutdown", new_callable=AsyncMock):
                    with patch("sys.stdout", captured):
                        asyncio.run(_run_print_mode(
                            MagicMock(), "test", project_root=MagicMock()
                        ))

        self.assertTrue(captured.getvalue().endswith("\n"))


async def _async_iter(items):
    for item in items:
        yield item
