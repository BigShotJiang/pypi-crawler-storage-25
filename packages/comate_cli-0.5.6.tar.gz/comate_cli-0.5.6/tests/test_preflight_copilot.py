from __future__ import annotations

import unittest
from pathlib import Path
from unittest.mock import patch

from comate_cli.terminal_agent.preflight import (
    PROVIDER_PRESETS,
    _PROVIDER_ENV_VARS,
    PreflightCheckResult,
    _PreflightWizard,
)


class TestPreflightCopilotPreset(unittest.TestCase):
    def _build_wizard(self) -> _PreflightWizard:
        return _PreflightWizard(
            check=PreflightCheckResult(
                needs_preflight=True,
                reasons=("Model levels not fully configured: LOW, MID, HIGH",),
                mode="env",
                llm_levels_source=None,
                llm_levels={},
                missing_levels=("LOW", "MID", "HIGH"),
                missing_key_levels=(),
            ),
            project_root=Path("/tmp/project"),
        )

    def test_copilot_preset_defaults(self) -> None:
        preset_map = {preset.preset_id: preset for preset in PROVIDER_PRESETS}
        self.assertIn("copilot", preset_map)
        copilot = preset_map["copilot"]
        self.assertEqual(copilot.label, "GitHub Copilot Plan")
        self.assertEqual(copilot.provider, "copilot")
        self.assertEqual(copilot.base_url, "https://api.githubcopilot.com")
        self.assertEqual(copilot.models["LOW"], "gpt-5-mini")
        self.assertEqual(copilot.models["MID"], "gpt-5.3-codex")
        self.assertEqual(copilot.models["HIGH"], "gpt-5.3-codex")

    def test_provider_env_mapping_uses_github_token(self) -> None:
        self.assertEqual(_PROVIDER_ENV_VARS["copilot"], "GITHUB_TOKEN")

    def test_provider_menu_places_copilot_after_openai_and_anthropic(self) -> None:
        wizard = self._build_wizard()
        wizard._open_provider_menu()
        values = [opt.value for opt in wizard._selection_ui._state.options]
        self.assertIn("copilot", values)
        self.assertIn("openai", values)
        self.assertIn("anthropic", values)

        copilot_index = values.index("copilot")
        self.assertGreater(copilot_index, values.index("openai"))
        self.assertGreater(copilot_index, values.index("anthropic"))

    def test_copilot_edit_menu_has_no_endpoint_edit_action(self) -> None:
        wizard = self._build_wizard()
        wizard._selected_preset = next(p for p in PROVIDER_PRESETS if p.preset_id == "copilot")
        wizard._draft = wizard._selected_preset.build_draft()

        wizard._open_edit_menu()
        values = [opt.value for opt in wizard._selection_ui._state.options]
        self.assertNotIn("edit:endpoint", values)

    def test_copilot_model_edit_skips_endpoint_input(self) -> None:
        wizard = self._build_wizard()
        wizard._selected_preset = next(p for p in PROVIDER_PRESETS if p.preset_id == "copilot")
        wizard._draft = wizard._selected_preset.build_draft()

        wizard._on_edit_model_submitted("LOW", "gpt-5.3-codex")

        self.assertEqual(wizard._draft["LOW"].model, "gpt-5.3-codex")
        self.assertEqual(wizard._draft["LOW"].base_url, "https://api.githubcopilot.com")
        self.assertEqual(wizard._mode, "selection")

    def test_copilot_key_collection_uses_github_token_env(self) -> None:
        wizard = self._build_wizard()
        wizard._selected_preset = next(p for p in PROVIDER_PRESETS if p.preset_id == "copilot")
        wizard._draft = wizard._selected_preset.build_draft()

        with patch.dict("os.environ", {"GITHUB_TOKEN": "gh_test_token"}, clear=True):
            wizard._prepare_key_collection()

        self.assertEqual(wizard._providers_need_key, [])
        self.assertIn("copilot", wizard._provider_to_key)
        self.assertIsNone(wizard._provider_to_key["copilot"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
