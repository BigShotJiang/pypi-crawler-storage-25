from __future__ import annotations

import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document

from comate_cli.terminal_agent.mention_completer import LocalFileMentionCompleter


class TestLocalFileMentionCompleter(unittest.TestCase):
    def setUp(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory()
        self.root = Path(self._tmpdir.name)
        (self.root / "main.py").write_text("print('ok')", encoding="utf-8")
        (self.root / "README.md").write_text("# readme", encoding="utf-8")
        (self.root / "build").mkdir(parents=True, exist_ok=True)
        (self.root / "comate_agent_sdk").mkdir(parents=True, exist_ok=True)
        (self.root / "dist").mkdir(parents=True, exist_ok=True)
        (self.root / "docs").mkdir(parents=True, exist_ok=True)
        (self.root / "packages").mkdir(parents=True, exist_ok=True)
        (self.root / "src").mkdir(parents=True, exist_ok=True)
        (self.root / "src" / "main_helper.py").write_text("x = 1", encoding="utf-8")
        self.completer = LocalFileMentionCompleter(self.root, refresh_interval=0.0, limit=200)

    def tearDown(self) -> None:
        self._tmpdir.cleanup()

    def _populate_many_src_directories(self) -> None:
        names = [
            "assistant",
            "bootstrap",
            "bridge",
            "buddy",
            "cli",
            "commands",
            "components",
            "constants",
            "context",
            "coordinator",
            "entrypoints",
            "history",
            "hooks",
            "ink",
            "keybindings",
            "memdir",
            "migrations",
            "moreright",
            "native-ts",
            "outputStyles",
            "plugins",
            "query",
            "remote",
            "schemas",
            "screens",
            "server",
            "services",
            "skills",
            "state",
            "tasks",
            "tools",
            "types",
            "upstreamproxy",
            "utils",
            "vim",
            "voice",
        ]
        for name in names:
            (self.root / "src" / name).mkdir(parents=True, exist_ok=True)

    def test_guard_ignores_email_trigger(self) -> None:
        context = self.completer.extract_context("contact me: foo@example.com")
        self.assertIsNone(context)

    def test_suggest_prefers_basename_prefix_match(self) -> None:
        result = self.completer.suggest("@main", max_items=8)
        self.assertIsNotNone(result)
        assert result is not None
        _, candidates = result
        self.assertTrue(candidates)
        self.assertEqual(candidates[0], "main.py")
        self.assertIn("src/main_helper.py", candidates)

    def test_suggest_does_not_drop_late_deep_match_in_large_tree(self) -> None:
        for index in range(1200):
            nested = self.root / "bulk" / f"dir{index}"
            nested.mkdir(parents=True, exist_ok=True)
            (nested / f"file{index}.txt").write_text("x", encoding="utf-8")

        target = self.root / "workspace" / "memoryScan.ts"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("export {};\n", encoding="utf-8")

        result = self.completer.suggest("@memoryS", max_items=8)

        self.assertIsNotNone(result)
        assert result is not None
        _, candidates = result
        self.assertIn("workspace/memoryScan.ts", candidates)

    def test_suggest_prefers_shallower_basename_prefix_match(self) -> None:
        shallow = self.root / "src" / "memdir" / "memoryScan.ts"
        shallow.parent.mkdir(parents=True, exist_ok=True)
        shallow.write_text("export {};\n", encoding="utf-8")

        deep = (
            self.root
            / "src"
            / "components"
            / "agents"
            / "new-agent-creation"
            / "wizard-steps"
            / "MemoryStep.tsx"
        )
        deep.parent.mkdir(parents=True, exist_ok=True)
        deep.write_text("export {};\n", encoding="utf-8")

        result = self.completer.suggest("@memoryS", max_items=8)

        self.assertIsNotNone(result)
        assert result is not None
        _, candidates = result
        self.assertGreaterEqual(len(candidates), 2)
        self.assertEqual(candidates[0], "src/memdir/memoryScan.ts")
        self.assertIn(
            "src/components/agents/new-agent-creation/wizard-steps/MemoryStep.tsx",
            candidates,
        )

    def test_empty_mention_returns_top_level_entries_without_dropping_sdk_dirs(self) -> None:
        result = self.completer.suggest("@", max_items=32)

        self.assertIsNotNone(result)
        assert result is not None
        _, candidates = result
        self.assertIn("comate_agent_sdk/", candidates)
        self.assertIn("packages/", candidates)
        self.assertIn("docs/", candidates)
        self.assertIn("dist/", candidates)

    def test_build_and_dist_are_suggested_for_prefix_queries(self) -> None:
        dist_result = self.completer.suggest("@di", max_items=16)
        build_result = self.completer.suggest("@bu", max_items=16)

        self.assertIsNotNone(dist_result)
        self.assertIsNotNone(build_result)
        assert dist_result is not None
        assert build_result is not None
        self.assertIn("dist/", dist_result[1])
        self.assertIn("build/", build_result[1])

    def test_suggest_returns_none_for_completed_file(self) -> None:
        result = self.completer.suggest("open @main.py")
        self.assertIsNone(result)

    def test_apply_completion_replaces_fragment_and_appends_space(self) -> None:
        original = "open @ma"
        suggest_result = self.completer.suggest(original, max_items=8)
        self.assertIsNotNone(suggest_result)
        assert suggest_result is not None
        context, _ = suggest_result
        new_text, new_cursor = self.completer.apply_completion(
            full_text=original,
            cursor_position=len(original),
            context=context,
            completion="main.py",
            append_space=True,
        )
        self.assertEqual(new_text, "open @main.py ")
        self.assertEqual(new_cursor, len("open @main.py "))

    def test_prompt_toolkit_completion_appends_space_for_files(self) -> None:
        doc = Document(text="open @ma", cursor_position=len("open @ma"))
        event = CompleteEvent(completion_requested=True)
        completions = list(self.completer.get_completions(doc, event))
        self.assertTrue(completions)
        texts = [completion.text for completion in completions]
        self.assertIn("main.py ", texts)

    def test_directory_prefix_completion_is_not_lost_after_large_tree_scan(self) -> None:
        for index in range(1200):
            nested = self.root / "bulk" / f"dir{index}"
            nested.mkdir(parents=True, exist_ok=True)
            (nested / f"file{index}.txt").write_text("x", encoding="utf-8")

        target_dir = self.root / "target" / "sub"
        target_dir.mkdir(parents=True, exist_ok=True)
        (target_dir / "wanted.py").write_text("pass", encoding="utf-8")

        result = self.completer.suggest("@target/", max_items=8)

        self.assertIsNotNone(result)
        assert result is not None
        _, candidates = result
        self.assertIn("target/sub/", candidates)

    def test_existing_directory_prefix_continues_to_suggest_children(self) -> None:
        for index in range(1200):
            nested = self.root / "bulk" / f"dir{index}"
            nested.mkdir(parents=True, exist_ok=True)
            (nested / f"file{index}.txt").write_text("x", encoding="utf-8")

        target_dir = self.root / "target" / "sub"
        target_dir.mkdir(parents=True, exist_ok=True)
        (target_dir / "wanted.py").write_text("pass", encoding="utf-8")

        result = self.completer.suggest("@target/s", max_items=8)

        self.assertIsNotNone(result)
        assert result is not None
        _, candidates = result
        self.assertIn("target/sub/", candidates)

    def test_directory_completion_does_not_truncate_late_entries(self) -> None:
        self._populate_many_src_directories()

        doc = Document(text="@src/", cursor_position=len("@src/"))
        event = CompleteEvent(completion_requested=True)

        completions = list(self.completer.get_completions(doc, event))

        self.assertTrue(completions)
        display_texts = [completion.display_text for completion in completions]
        self.assertIn("src/tools/", display_texts)

    def test_root_completion_does_not_truncate_entries_after_first_twelve(self) -> None:
        for index in range(20):
            (self.root / f"zz_dir_{index:02d}").mkdir(parents=True, exist_ok=True)

        doc = Document(text="@", cursor_position=1)
        event = CompleteEvent(completion_requested=True)

        completions = list(self.completer.get_completions(doc, event))

        self.assertGreater(len(completions), 12)
        display_texts = [completion.display_text for completion in completions]
        self.assertIn("zz_dir_19/", display_texts)
        self.assertIn("comate_agent_sdk/", display_texts)

    def test_dot_slash_directory_fragment_suggests_root_children(self) -> None:
        result = self.completer.suggest("@./", max_items=32)

        self.assertIsNotNone(result)
        assert result is not None
        _, candidates = result
        self.assertIn("./packages/", candidates)
        self.assertIn("./comate_agent_sdk/", candidates)

    def test_invalid_directory_like_fragment_does_not_fall_back_to_fuzzy_search(self) -> None:
        self.assertIsNone(self.completer.suggest("@../"))
        self.assertIsNone(self.completer.suggest("@missing/path"))

    def test_deep_search_prefers_git_index_when_available(self) -> None:
        with patch(
            "comate_cli.terminal_agent.mention_completer.subprocess.run",
            return_value=subprocess.CompletedProcess(
                args=["git"],
                returncode=0,
                stdout="src/from_git.py\npackages/cli/app.py\n",
                stderr="",
            ),
        ) as mock_run:
            result = self.completer.suggest("@from_g", max_items=16)

        self.assertIsNotNone(result)
        assert result is not None
        self.assertIn("src/from_git.py", result[1])
        mock_run.assert_called_once()
        self.assertEqual(mock_run.call_args.args[0][:2], ["git", "ls-files"])

    def test_deep_search_falls_back_to_ripgrep_when_git_fails(self) -> None:
        with patch(
            "comate_cli.terminal_agent.mention_completer.subprocess.run",
            side_effect=[
                subprocess.CompletedProcess(
                    args=["git"],
                    returncode=1,
                    stdout="",
                    stderr="fatal: not a git repository",
                ),
                subprocess.CompletedProcess(
                    args=["rg"],
                    returncode=0,
                    stdout="src/from_rg.py\n",
                    stderr="",
                ),
            ],
        ) as mock_run:
            result = self.completer.suggest("@from_r", max_items=16)

        self.assertIsNotNone(result)
        assert result is not None
        self.assertIn("src/from_rg.py", result[1])
        self.assertEqual(mock_run.call_count, 2)
        self.assertEqual(mock_run.call_args_list[0].args[0][:2], ["git", "ls-files"])
        self.assertEqual(mock_run.call_args_list[1].args[0][:2], ["rg", "--files"])

    def test_deep_search_falls_back_to_walk_when_commands_fail(self) -> None:
        target = self.root / "walkdir" / "walkfile.py"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("pass\n", encoding="utf-8")

        with patch(
            "comate_cli.terminal_agent.mention_completer.subprocess.run",
            side_effect=FileNotFoundError("command not found"),
        ):
            result = self.completer.suggest("@walkf", max_items=16)

        self.assertIsNotNone(result)
        assert result is not None
        self.assertIn("walkdir/walkfile.py", result[1])

    def test_command_index_results_still_filter_hard_ignored_paths(self) -> None:
        with patch(
            "comate_cli.terminal_agent.mention_completer.subprocess.run",
            return_value=subprocess.CompletedProcess(
                args=["git"],
                returncode=0,
                stdout=".venv/bin/python\nsrc/app.py\n",
                stderr="",
            ),
        ):
            result = self.completer.suggest("@app", max_items=16)

        self.assertIsNotNone(result)
        assert result is not None
        self.assertIn("src/app.py", result[1])
        self.assertNotIn(".venv/bin/python", result[1])

    def test_deep_path_cache_avoids_rebuilding_within_refresh_interval(self) -> None:
        cached = LocalFileMentionCompleter(self.root, refresh_interval=60.0, limit=200)
        with patch(
            "comate_cli.terminal_agent.mention_completer.subprocess.run",
            return_value=subprocess.CompletedProcess(
                args=["git"],
                returncode=0,
                stdout="src/cached.py\n",
                stderr="",
            ),
        ) as mock_run:
            first = cached._get_deep_paths()
            second = cached._get_deep_paths()

        self.assertEqual(first, second)
        mock_run.assert_called_once()

    def test_context_query_prefers_matching_directory_over_deeper_files(self) -> None:
        (self.root / "comate_agent_sdk" / "context").mkdir(parents=True, exist_ok=True)
        (self.root / "comate_agent_sdk" / "context" / "ir.py").write_text("x = 1\n", encoding="utf-8")
        (self.root / "docs" / "context_filesystem.md").write_text("# docs\n", encoding="utf-8")
        (self.root / "src" / "runtime_context_helper.py").write_text("x = 1\n", encoding="utf-8")

        result = self.completer.suggest("@context", max_items=8)

        self.assertIsNotNone(result)
        assert result is not None
        _, candidates = result
        self.assertEqual(candidates[0], "comate_agent_sdk/context/")

    def test_short_query_prefers_tighter_subsequence_match(self) -> None:
        (self.root / "src" / "context.py").write_text("x = 1\n", encoding="utf-8")
        (self.root / "src" / "current_text_executor.py").write_text("x = 1\n", encoding="utf-8")

        result = self.completer.suggest("@ctx", max_items=8)

        self.assertIsNotNone(result)
        assert result is not None
        _, candidates = result
        self.assertLess(candidates.index("src/context.py"), candidates.index("src/current_text_executor.py"))

    def test_boundary_and_basename_match_prefers_mcp_cli(self) -> None:
        (self.root / "src" / "mcp_cli.py").write_text("x = 1\n", encoding="utf-8")
        (self.root / "src" / "mycoolproject.py").write_text("x = 1\n", encoding="utf-8")
        (self.root / "docs" / "alpha_mcp_notes.md").write_text("# docs\n", encoding="utf-8")

        result = self.completer.suggest("@mcp", max_items=8)

        self.assertIsNotNone(result)
        assert result is not None
        _, candidates = result
        self.assertEqual(candidates[0], "src/mcp_cli.py")


if __name__ == "__main__":
    unittest.main(verbosity=2)
