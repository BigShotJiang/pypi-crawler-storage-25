import unittest

from comate_agent_sdk.agent.events import (
    StopEvent,
    TextDeltaEvent,
    TextEvent,
    ThinkingDeltaEvent,
    ThinkingEvent,
    ToolCallStartEvent,
)

from comate_cli.terminal_agent.event_renderer import (
    ContainerState,
    EventRenderer,
    FenceMatch,
)


class TestQ11Fallback(unittest.TestCase):
    """spec §5 Q11：当本 turn 已收到 Delta，整段 TextEvent / ThinkingEvent
    应被忽略；当未收到 Delta 时走 legacy 兜底（_append_assistant_text /
    直接 history entry）。新管道下行为不变。"""

    def test_text_event_no_op_when_delta_received(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(TextDeltaEvent(delta="hello", message_id="m1"))
        self.assertTrue(renderer._turn_received_text_delta)
        before = list(renderer.history_entries())
        renderer.handle_event(TextEvent(content="hello"))
        # delta 路径已处理 → TextEvent 不再 append
        self.assertEqual(renderer._assistant_buffer, "")
        self.assertEqual(len(renderer.history_entries()), len(before))

    def test_text_event_legacy_fallback_when_no_delta(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        self.assertFalse(renderer._turn_received_text_delta)
        renderer.handle_event(TextEvent(content="legacy hello"))
        # 兜底走 _append_assistant_text → buffer 累
        self.assertEqual(renderer._assistant_buffer, "legacy hello")

    def test_provider_error_stop_does_not_add_interrupted_message(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            StopEvent(reason="interrupted", metadata={"error": Exception("Connection refused")})
        )

        texts = [entry.text for entry in renderer.history_entries()]
        self.assertNotIn("Current task interrupted.", texts)

    def test_thinking_event_no_op_when_delta_received(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(ThinkingDeltaEvent(delta="reasoning", message_id="m1"))
        renderer.handle_event(ThinkingEvent(content="reasoning"))
        thinking_entries = [
            entry for entry in renderer.history_entries() if entry.entry_type == "thinking"
        ]
        # delta 路径仍待 batch flush，TextEvent 不补 thinking entry
        self.assertEqual(thinking_entries, [])

    def test_thinking_event_legacy_fallback_when_no_delta(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(ThinkingEvent(content="legacy thought"))
        thinking_entries = [
            entry for entry in renderer.history_entries() if entry.entry_type == "thinking"
        ]
        self.assertEqual(len(thinking_entries), 1)
        self.assertEqual(thinking_entries[0].text, "legacy thought")

    def test_start_turn_resets_delta_flags(self) -> None:
        renderer = EventRenderer()
        renderer.handle_event(TextDeltaEvent(delta="hi", message_id="m1"))
        renderer.handle_event(ThinkingDeltaEvent(delta="think", message_id="m1"))
        renderer.start_turn()
        self.assertFalse(renderer._turn_received_text_delta)
        self.assertFalse(renderer._turn_received_thinking_delta)


class TestEventRendererToolCallStartPending(unittest.TestCase):
    """ToolCallStart 只做文本 flush + 去重登记，不再预注册 running_tools。"""

    def test_tool_call_start_does_not_register_running_tool(self) -> None:
        renderer = EventRenderer()
        renderer.handle_event(ToolCallStartEvent(tool_call_id="tc1", tool="Edit"))

        # 不写 scrollback
        self.assertEqual(renderer.history_entries(), [])
        # 不再在 running_tools 里登记 pending —— 等 ToolCallEvent 携带完整 args 后再注册
        self.assertFalse(renderer.has_running_tools())

    def test_tool_call_start_is_deduplicated(self) -> None:
        renderer = EventRenderer()
        event = ToolCallStartEvent(tool_call_id="tc1", tool="Edit")
        renderer.handle_event(event)
        renderer.handle_event(event)

        # 去重：_pending_tool_starts 里只有一条，running_tools 为空
        self.assertEqual(len(renderer._pending_tool_starts), 1)
        self.assertEqual(len(renderer._running_tools), 0)

    def test_tool_call_start_skipped_for_hidden_tools(self) -> None:
        """AskUserQuestion / TaskCreate / 静默任务工具等：行为与普通工具一致，均不登记 running_tools。"""
        renderer = EventRenderer()
        for hidden_tool in ("AskUserQuestion", "TaskCreate", "TaskUpdate"):
            renderer.handle_event(
                ToolCallStartEvent(tool_call_id=f"tc_{hidden_tool}", tool=hidden_tool)
            )
        self.assertFalse(renderer.has_running_tools())
        self.assertEqual(renderer.history_entries(), [])


class TestDetectFenceOpen(unittest.TestCase):
    """spec §6.3：fence open 行识别（^(```{3,}|~~~{3,})\\s*(\\S*)\\s*$）。"""

    def test_python_fence(self):
        renderer = EventRenderer()
        fm = renderer._detect_fence_open("```python")
        self.assertIsNotNone(fm)
        self.assertEqual(fm.marker, "```")
        self.assertEqual(fm.lang, "python")

    def test_no_lang(self):
        renderer = EventRenderer()
        fm = renderer._detect_fence_open("```")
        self.assertIsNotNone(fm)
        self.assertEqual(fm.marker, "```")
        self.assertEqual(fm.lang, "")

    def test_tilde_marker(self):
        renderer = EventRenderer()
        fm = renderer._detect_fence_open("~~~~ts")
        self.assertIsNotNone(fm)
        self.assertEqual(fm.marker, "~~~~")
        self.assertEqual(fm.lang, "ts")

    def test_not_fence(self):
        renderer = EventRenderer()
        # 仅 2 个 backtick
        self.assertIsNone(renderer._detect_fence_open("``hello"))
        # 普通文本
        self.assertIsNone(renderer._detect_fence_open("normal text"))
        # 空行
        self.assertIsNone(renderer._detect_fence_open(""))
        # lang 后还有内容
        self.assertIsNone(renderer._detect_fence_open("```py code"))


class TestIsFenceClose(unittest.TestCase):
    """spec §6.3 + Task 2.1 的 fence_marker verbatim 存储：
    CommonMark close 规则 — 同 char (` 或 ~) + ≥ 同长度。"""

    def test_exact_match(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="fence",
            lines=["```python"],
            fence_marker="```",
            fence_lang="python",
        )
        self.assertTrue(renderer._is_fence_close("```"))
        # trailing whitespace allowed
        self.assertTrue(renderer._is_fence_close("```   "))

    def test_longer_close(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="fence", lines=["~~~"], fence_marker="~~~",
        )
        # longer is OK
        self.assertTrue(renderer._is_fence_close("~~~~~"))

    def test_shorter_close_rejected(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="fence", lines=["~~~~"], fence_marker="~~~~",
        )
        # shorter NOT OK
        self.assertFalse(renderer._is_fence_close("~~~"))

    def test_wrong_char(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="fence", lines=["```py"], fence_marker="```",
        )
        # backtick fence cannot close with tilde
        self.assertFalse(renderer._is_fence_close("~~~"))

    def test_with_extra_content(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="fence", lines=["```"], fence_marker="```",
        )
        # close marker line cannot have other content
        self.assertFalse(renderer._is_fence_close("``` py"))


class TestIsTableSeparator(unittest.TestCase):
    """spec §6.3：GFM table 分隔符行判定。"""

    def test_basic_separators(self):
        renderer = EventRenderer()
        self.assertTrue(renderer._is_table_separator("| --- | --- |"))
        self.assertTrue(renderer._is_table_separator("|---|---|"))
        # alignment markers
        self.assertTrue(renderer._is_table_separator("| :--- | :---: | ---: |"))
        # no surrounding |
        self.assertTrue(renderer._is_table_separator("--- | ---"))

    def test_rejects_single_cell(self):
        renderer = EventRenderer()
        # only 1 cell (no internal |) → not a valid GFM separator
        self.assertFalse(renderer._is_table_separator("| --- |"))

    def test_rejects_non_separator(self):
        renderer = EventRenderer()
        self.assertFalse(renderer._is_table_separator("normal text"))
        # has letters → not separator (data row)
        self.assertFalse(renderer._is_table_separator("| a | b |"))
        self.assertFalse(renderer._is_table_separator(""))


class TestLooksLikeTableRow(unittest.TestCase):
    """spec §6.3 收紧判定 + 别名机制：
    - 行首 | → True；否则需 ≥ 2 个 | 才算 table row
    - _is_table_continuation / _has_pipe_chars 是 _looks_like_table_row 别名
      （held 候选与续行判定共用同一谓词保证语义对称）"""

    def test_leading_pipe(self):
        renderer = EventRenderer()
        self.assertTrue(renderer._looks_like_table_row("| a | b |"))
        # leading whitespace 仍允许
        self.assertTrue(renderer._looks_like_table_row("  | a | b |"))
        # bare leading pipe
        self.assertTrue(renderer._looks_like_table_row("|"))

    def test_two_pipes_mid_line(self):
        renderer = EventRenderer()
        self.assertTrue(renderer._looks_like_table_row("a | b | c"))
        self.assertTrue(renderer._looks_like_table_row("a|b|c"))

    def test_rejects_single_pipe(self):
        # spec §6.3 关键示例：单 | 不是 table 候选
        renderer = EventRenderer()
        self.assertFalse(renderer._looks_like_table_row("see section 3 | 4 above"))
        self.assertFalse(renderer._looks_like_table_row("use a|b operator"))

    def test_rejects_blank(self):
        renderer = EventRenderer()
        self.assertFalse(renderer._looks_like_table_row(""))
        self.assertFalse(renderer._looks_like_table_row("   "))

    def test_aliases_match_main(self):
        # spec §6.3：三方法语义完全等价
        renderer = EventRenderer()
        self.assertTrue(renderer._is_table_continuation("| a |"))
        self.assertTrue(renderer._has_pipe_chars("| a |"))
        self.assertFalse(renderer._is_table_continuation("see section 3 | 4 above"))
        self.assertFalse(renderer._has_pipe_chars("see section 3 | 4 above"))


class TestEmitTextLine(unittest.TestCase):
    """spec §6.5：单行 assistant text → HistoryEntry → 入队。"""

    def test_emit_appends_history_entry(self):
        renderer = EventRenderer()
        initial_len = len(renderer._history)
        renderer._emit_text_line("Hello world")
        self.assertEqual(len(renderer._history), initial_len + 1)
        entry = renderer._history[-1]
        self.assertEqual(entry.entry_type, "assistant")
        self.assertEqual(entry.text, "Hello world\n")


class TestFlushContainer(unittest.TestCase):
    """spec §6.5：容器整段 → HistoryEntry → 入队。"""

    def test_flush_fence(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="fence",
            lines=["```python", "x = 1", "```"],
            fence_marker="```",
            fence_lang="python",
        )
        renderer._loading_aux_text = "正在写 python 代码块（3 行）..."
        initial_len = len(renderer._history)
        renderer._flush_container()
        self.assertEqual(len(renderer._history), initial_len + 1)
        entry = renderer._history[-1]
        self.assertEqual(entry.entry_type, "assistant")
        self.assertEqual(entry.text, "```python\nx = 1\n```\n")
        self.assertIsNone(renderer._container)
        # flush 后必须清 aux（避免 stale spinner phrase）
        self.assertEqual(renderer._loading_aux_text, "")

    def test_flush_table(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="table",
            lines=["| a | b |", "| - | - |", "| 1 | 2 |"],
        )
        renderer._flush_container()
        entry = renderer._history[-1]
        self.assertIn("| a | b |", entry.text)
        self.assertIn("| 1 | 2 |", entry.text)
        self.assertIsNone(renderer._container)


class TestFlushThinkingBatch(unittest.TestCase):
    """spec §6.5：thinking 残段 → HistoryEntry，受 _show_thinking_cb 过滤。"""

    def test_emits_when_visible(self):
        renderer = EventRenderer()
        renderer._show_thinking_cb = lambda: True
        renderer._thinking_batch = "let me think about this"
        initial_len = len(renderer._history)
        renderer._flush_thinking_batch()
        self.assertEqual(len(renderer._history), initial_len + 1)
        entry = renderer._history[-1]
        self.assertEqual(entry.entry_type, "thinking")
        self.assertEqual(entry.text, "let me think about this")
        self.assertEqual(renderer._thinking_batch, "")

    def test_drops_when_hidden(self):
        renderer = EventRenderer()
        renderer._show_thinking_cb = lambda: False
        renderer._thinking_batch = "hidden thought"
        initial_len = len(renderer._history)
        renderer._flush_thinking_batch()
        # 不入队
        self.assertEqual(len(renderer._history), initial_len)
        # 但 batch 仍被清空（避免持续累积）
        self.assertEqual(renderer._thinking_batch, "")

    def test_empty_noop(self):
        renderer = EventRenderer()
        renderer._show_thinking_cb = lambda: True
        initial_len = len(renderer._history)
        renderer._flush_thinking_batch()
        self.assertEqual(len(renderer._history), initial_len)


class TestConsumeThinkingDelta(unittest.TestCase):
    """spec §6.1：thinking delta 主入口，与 text delta 一样按完整行流式入队。"""

    def test_partial_line(self):
        renderer = EventRenderer()
        initial_len = len(renderer._history)
        renderer._consume_thinking_delta("Thinking ")
        self.assertEqual(renderer._thinking_batch, "Thinking ")
        self.assertEqual(len(renderer._history), initial_len)

    def test_emits_complete_lines(self):
        renderer = EventRenderer()
        renderer._show_thinking_cb = lambda: True
        renderer._consume_thinking_delta("line1\nline")
        renderer._consume_thinking_delta("2\nline3\n")
        thinking_entries = [
            entry for entry in renderer._history if entry.entry_type == "thinking"
        ]
        self.assertEqual(
            [entry.text for entry in thinking_entries],
            ["line1\n", "line2\n", "line3\n"],
        )
        self.assertEqual(renderer._thinking_batch, "")

    def test_drops_complete_lines_when_hidden(self):
        renderer = EventRenderer()
        renderer._show_thinking_cb = lambda: False
        renderer._consume_thinking_delta("hidden\n")
        thinking_entries = [
            entry for entry in renderer._history if entry.entry_type == "thinking"
        ]
        self.assertEqual(thinking_entries, [])
        self.assertEqual(renderer._thinking_batch, "")

    def test_remainder_flushed_on_finalize(self):
        renderer = EventRenderer()
        renderer._show_thinking_cb = lambda: True
        renderer.handle_event(ThinkingDeltaEvent(delta="incomplete", message_id="m1"))
        renderer.finalize_turn()
        thinking_entries = [
            entry for entry in renderer._history if entry.entry_type == "thinking"
        ]
        self.assertEqual(len(thinking_entries), 1)
        self.assertEqual(thinking_entries[0].text, "incomplete")

    def test_thinking_then_text_preserves_order(self):
        renderer = EventRenderer()
        renderer._show_thinking_cb = lambda: True
        renderer.handle_event(ThinkingDeltaEvent(delta="thought\nresidue", message_id="m1"))
        renderer.handle_event(TextDeltaEvent(delta="answer\n", message_id="m1"))
        visible_entries = [
            entry for entry in renderer._history
            if entry.entry_type in ("thinking", "assistant")
        ]
        self.assertEqual(
            [(entry.entry_type, entry.text) for entry in visible_entries],
            [
                ("thinking", "thought\n"),
                ("thinking", "residue"),
                ("assistant", "answer\n"),
            ],
        )

    def test_interrupt_drops_pending_remainder_only(self):
        renderer = EventRenderer()
        renderer._show_thinking_cb = lambda: True
        renderer.handle_event(ThinkingDeltaEvent(delta="visible\nresidue", message_id="m1"))
        renderer.interrupt_turn()
        thinking_entries = [
            entry for entry in renderer._history if entry.entry_type == "thinking"
        ]
        self.assertEqual(len(thinking_entries), 1)
        self.assertEqual(thinking_entries[0].text, "visible\n")
        self.assertEqual(renderer._thinking_batch, "")


class TestHandleCompleteLine(unittest.TestCase):
    """spec §6.2：行级路由。Task 4.1 / 4.2 / 4.3 / 4.4 渐进扩展。"""

    # ── 普通行（Task 4.1）──

    def test_plain_text(self):
        renderer = EventRenderer()
        initial_len = len(renderer._history)
        renderer._handle_complete_line("Hello world")
        self.assertEqual(len(renderer._history), initial_len + 1)
        self.assertEqual(renderer._history[-1].text, "Hello world\n")

    def test_blank_line(self):
        renderer = EventRenderer()
        initial_len = len(renderer._history)
        renderer._handle_complete_line("")
        self.assertEqual(len(renderer._history), initial_len + 1)
        self.assertEqual(renderer._history[-1].text, "\n")

    # ── fence 容器（Task 4.2）──

    def test_opens_fence(self):
        renderer = EventRenderer()
        renderer._handle_complete_line("```python")
        self.assertIsNotNone(renderer._container)
        self.assertEqual(renderer._container.kind, "fence")
        self.assertEqual(renderer._container.lines, ["```python"])
        self.assertEqual(renderer._container.fence_marker, "```")
        self.assertEqual(renderer._container.fence_lang, "python")

    def test_in_fence_appends(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="fence", lines=["```py"], fence_marker="```", fence_lang="py",
        )
        renderer._handle_complete_line("x = 1")
        self.assertEqual(renderer._container.lines, ["```py", "x = 1"])
        # 容器仍开（未闭合）
        self.assertIsNotNone(renderer._container)

    def test_closes_fence(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="fence", lines=["```py", "x=1"], fence_marker="```", fence_lang="py",
        )
        initial_len = len(renderer._history)
        renderer._handle_complete_line("```")
        self.assertIsNone(renderer._container)
        self.assertEqual(len(renderer._history), initial_len + 1)
        entry = renderer._history[-1]
        self.assertEqual(entry.text, "```py\nx=1\n```\n")

    # ── table held 候选 + 确认（Task 4.3）──

    def test_holds_pipe_candidate(self):
        renderer = EventRenderer()
        initial_len = len(renderer._history)
        renderer._handle_complete_line("| a | b |")
        # held 不入队，等下一行确认
        self.assertEqual(renderer._held_pipe_line, "| a | b |")
        self.assertEqual(len(renderer._history), initial_len)

    def test_confirms_table(self):
        renderer = EventRenderer()
        renderer._handle_complete_line("| a | b |")
        initial_len = len(renderer._history)
        renderer._handle_complete_line("| --- | --- |")
        self.assertIsNotNone(renderer._container)
        self.assertEqual(renderer._container.kind, "table")
        self.assertEqual(renderer._container.lines, ["| a | b |", "| --- | --- |"])
        self.assertIsNone(renderer._held_pipe_line)
        # held 进入容器尚未 emit
        self.assertEqual(len(renderer._history), initial_len)

    def test_held_not_table(self):
        renderer = EventRenderer()
        renderer._handle_complete_line("| a | b |")
        initial_len = len(renderer._history)
        renderer._handle_complete_line("regular text")
        # held 落地为普通 entry + current line 也 emit
        self.assertEqual(len(renderer._history), initial_len + 2)
        self.assertEqual(renderer._history[-2].text, "| a | b |\n")
        self.assertEqual(renderer._history[-1].text, "regular text\n")
        self.assertIsNone(renderer._held_pipe_line)

    def test_single_pipe_not_held(self):
        renderer = EventRenderer()
        initial_len = len(renderer._history)
        renderer._handle_complete_line("see section 3 | 4 above")
        # 单 | 非 held 候选 → 直接 emit
        self.assertIsNone(renderer._held_pipe_line)
        self.assertEqual(len(renderer._history), initial_len + 1)

    # ── table 容器内续行 / 结束（Task 4.4）──

    def test_in_table_continues(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="table", lines=["| a | b |", "| - | - |"],
        )
        renderer._handle_complete_line("| 1 | 2 |")
        self.assertIsNotNone(renderer._container)
        self.assertEqual(renderer._container.lines[-1], "| 1 | 2 |")

    def test_table_ends_on_blank(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="table", lines=["| a |", "| - |"],
        )
        initial_len = len(renderer._history)
        renderer._handle_complete_line("")
        # table flush + 空行作为普通行 emit
        self.assertIsNone(renderer._container)
        self.assertEqual(len(renderer._history), initial_len + 2)
        self.assertTrue(renderer._history[-2].text.startswith("| a |"))
        self.assertEqual(renderer._history[-1].text, "\n")

    def test_table_ends_on_paragraph(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="table", lines=["| a |", "| - |"],
        )
        initial_len = len(renderer._history)
        renderer._handle_complete_line("Then comes a paragraph.")
        self.assertIsNone(renderer._container)
        self.assertEqual(len(renderer._history), initial_len + 2)

    def test_table_ends_on_fence(self):
        """spec §8.1 T-D2：table 内出现 ```python → table flush → 开 fence
        容器（递归路径，含 plan 第 3 轮加的 防递归无 bound assert）。"""
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="table", lines=["| a |", "| - |"],
        )
        renderer._handle_complete_line("```python")
        # table flush + fence opened
        self.assertIsNotNone(renderer._container)
        self.assertEqual(renderer._container.kind, "fence")
        self.assertEqual(renderer._container.fence_lang, "python")


class TestConsumeTextDelta(unittest.TestCase):
    """spec §6.1：text delta 主入口 + thinking 顺序保证。"""

    def test_partial_line(self):
        renderer = EventRenderer()
        initial_len = len(renderer._history)
        renderer._consume_text_delta("Hello ")
        # 无 \n → 仅累到 _text_pending 不入队
        self.assertEqual(renderer._text_pending, "Hello ")
        self.assertEqual(len(renderer._history), initial_len)

    def test_full_line(self):
        renderer = EventRenderer()
        renderer._consume_text_delta("Hello world\n")
        self.assertEqual(renderer._text_pending, "")
        self.assertEqual(renderer._history[-1].text, "Hello world\n")

    def test_multiple_lines(self):
        renderer = EventRenderer()
        initial_len = len(renderer._history)
        renderer._consume_text_delta("a\nb\nc\n")
        self.assertEqual(len(renderer._history), initial_len + 3)
        self.assertEqual(
            [e.text for e in renderer._history[-3:]],
            ["a\n", "b\n", "c\n"],
        )

    def test_leading_blank_line_is_not_emitted(self):
        renderer = EventRenderer()
        renderer._consume_text_delta("\n已完成提交并推送。\n")
        self.assertEqual(
            [e.text for e in renderer._history],
            ["已完成提交并推送。\n"],
        )

    def test_internal_blank_line_is_preserved(self):
        renderer = EventRenderer()
        renderer._consume_text_delta("第一段\n\n第二段\n")
        self.assertEqual(
            [e.text for e in renderer._history],
            ["第一段\n", "\n", "第二段\n"],
        )

    def test_accumulates_across_calls(self):
        renderer = EventRenderer()
        renderer._consume_text_delta("He")
        renderer._consume_text_delta("llo ")
        renderer._consume_text_delta("world\n")
        self.assertEqual(renderer._history[-1].text, "Hello world\n")

    def test_flushes_thinking_first(self):
        """spec §6.1 顺序保证：text delta 进入前先 flush 待 thinking。"""
        renderer = EventRenderer()
        renderer._show_thinking_cb = lambda: True
        renderer._thinking_batch = "thought"
        initial_len = len(renderer._history)
        renderer._consume_text_delta("text\n")
        # thinking 先 flush，然后 text emit
        self.assertEqual(len(renderer._history), initial_len + 2)
        self.assertEqual(renderer._history[-2].entry_type, "thinking")
        self.assertEqual(renderer._history[-1].entry_type, "assistant")
        self.assertEqual(renderer._thinking_batch, "")

    def test_empty_noop(self):
        renderer = EventRenderer()
        initial_len = len(renderer._history)
        renderer._consume_text_delta("")
        self.assertEqual(len(renderer._history), initial_len)
        self.assertEqual(renderer._text_pending, "")


class TestRefreshLoadingAux(unittest.TestCase):
    """spec §6.7：容器缓冲期的 spinner phrase 后缀文案。"""

    def test_fence_with_lang(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="fence", lines=["```python", "x=1"],
            fence_marker="```", fence_lang="python",
        )
        renderer._refresh_loading_aux()
        self.assertIn("正在写 python 代码块", renderer._loading_aux_text)
        self.assertIn("2 行", renderer._loading_aux_text)

    def test_fence_no_lang(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="fence", lines=["```", "raw"],
            fence_marker="```", fence_lang="",
        )
        renderer._refresh_loading_aux()
        # 空 lang fallback 为 "code"
        self.assertIn("正在写 code 代码块", renderer._loading_aux_text)

    def test_table(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="table", lines=["| a |", "| - |", "| 1 |"],
        )
        renderer._refresh_loading_aux()
        self.assertIn("正在写表格", renderer._loading_aux_text)
        self.assertIn("3 行", renderer._loading_aux_text)

    def test_no_container_clears(self):
        renderer = EventRenderer()
        renderer._loading_aux_text = "stale"
        renderer._container = None
        renderer._refresh_loading_aux()
        self.assertEqual(renderer._loading_aux_text, "")


class TestLoadingAuxAccessor(unittest.TestCase):
    """spec §6.7 / §7.1：loading_aux_text 访问器（render_panels 拼接 spinner phrase 用）。"""

    def test_default_empty(self):
        renderer = EventRenderer()
        self.assertEqual(renderer.loading_aux_text(), "")

    def test_returns_field(self):
        renderer = EventRenderer()
        renderer._loading_aux_text = "正在写 py 代码块（3 行）..."
        self.assertEqual(
            renderer.loading_aux_text(),
            "正在写 py 代码块（3 行）...",
        )


class TestSpinnerAuxIntegration(unittest.TestCase):
    """验证容器激活时 loading_aux_text 状态正确（render_panels 实际拼接靠
    §8.6 手动验收覆盖 —— mixin 难独立 unit test）。"""

    def test_aux_appended_to_phrase_when_container_active(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="fence", lines=["```py"],
            fence_marker="```", fence_lang="py",
        )
        renderer._refresh_loading_aux()
        self.assertIn("正在写 py 代码块", renderer.loading_aux_text())


class TestForceFlushAll(unittest.TestCase):
    """spec §6.4：StopEvent / finalize_turn 调用，保证 scrollback 看到完整 turn。
    顺序：held → container[fence synthetic close] → text_pending → thinking → 清 aux。"""

    def test_text_pending(self):
        renderer = EventRenderer()
        renderer._text_pending = "halfline"
        initial_len = len(renderer._history)
        renderer._force_flush_all()
        self.assertEqual(len(renderer._history), initial_len + 1)
        self.assertEqual(renderer._history[-1].text, "halfline\n")
        self.assertEqual(renderer._text_pending, "")

    def test_held_pipe(self):
        renderer = EventRenderer()
        renderer._held_pipe_line = "| a | b |"
        initial_len = len(renderer._history)
        renderer._force_flush_all()
        self.assertEqual(len(renderer._history), initial_len + 1)
        self.assertIsNone(renderer._held_pipe_line)

    def test_fence_synthetic_close(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="fence", lines=["```python", "x=1"],
            fence_marker="```", fence_lang="python",
        )
        initial_len = len(renderer._history)
        renderer._force_flush_all()
        self.assertEqual(len(renderer._history), initial_len + 1)
        entry = renderer._history[-1]
        # synthetic close 自动追加
        self.assertEqual(entry.text, "```python\nx=1\n```\n")
        self.assertIsNone(renderer._container)

    def test_table_best_effort(self):
        renderer = EventRenderer()
        renderer._container = ContainerState(
            kind="table", lines=["| a |", "| - |"],
        )
        initial_len = len(renderer._history)
        renderer._force_flush_all()
        self.assertIsNone(renderer._container)
        # table 也整段入队（rich 容错渲染）
        self.assertEqual(len(renderer._history), initial_len + 1)
        self.assertIn("| a |", renderer._history[-1].text)
        self.assertIn("| - |", renderer._history[-1].text)
        self.assertEqual(renderer._history[-1].entry_type, "assistant")

    def test_thinking_batch(self):
        renderer = EventRenderer()
        renderer._show_thinking_cb = lambda: True
        renderer._thinking_batch = "final thought"
        initial_len = len(renderer._history)
        renderer._force_flush_all()
        self.assertEqual(len(renderer._history), initial_len + 1)
        self.assertEqual(renderer._history[-1].entry_type, "thinking")
        self.assertEqual(renderer._thinking_batch, "")

    def test_clears_aux(self):
        renderer = EventRenderer()
        renderer._loading_aux_text = "stale"
        renderer._force_flush_all()
        self.assertEqual(renderer._loading_aux_text, "")

    def test_order_held_container_pending_thinking(self):
        """spec §6.4 顺序：held → container → text_pending → thinking"""
        renderer = EventRenderer()
        renderer._show_thinking_cb = lambda: True
        renderer._held_pipe_line = "| heldrow |"
        renderer._container = ContainerState(
            kind="fence", lines=["```py", "x=1"],
            fence_marker="```", fence_lang="py",
        )
        renderer._text_pending = "tail"
        renderer._thinking_batch = "think"
        initial_len = len(renderer._history)
        renderer._force_flush_all()
        new_entries = renderer._history[initial_len:]
        self.assertEqual(len(new_entries), 4)
        self.assertEqual(new_entries[0].text, "| heldrow |\n")
        self.assertEqual(new_entries[1].text, "```py\nx=1\n```\n")
        self.assertEqual(new_entries[2].text, "tail\n")
        self.assertEqual(new_entries[3].entry_type, "thinking")


class TestDropAllPending(unittest.TestCase):
    """spec §6.4：interrupt_turn 调用，语义 = 用户不要剩下的内容，全丢弃不入队。"""

    def test_clears_everything(self):
        renderer = EventRenderer()
        renderer._text_pending = "abc"
        renderer._held_pipe_line = "| a |"
        renderer._container = ContainerState(
            kind="fence", lines=["```py"], fence_marker="```",
        )
        renderer._thinking_batch = "thinking"
        renderer._loading_aux_text = "aux"
        initial_len = len(renderer._history)

        renderer._drop_all_pending()

        self.assertEqual(renderer._text_pending, "")
        self.assertIsNone(renderer._held_pipe_line)
        self.assertIsNone(renderer._container)
        self.assertEqual(renderer._thinking_batch, "")
        self.assertEqual(renderer._loading_aux_text, "")
        # 关键：drop 不入队任何 entry
        self.assertEqual(len(renderer._history), initial_len)


class TestEventRendererNewFields(unittest.TestCase):
    """spec §4.1：EventRenderer 新增 5 个字段（pipeline A/B/C 状态）。"""

    def test_renderer_has_new_fields_with_defaults(self):
        renderer = EventRenderer()
        # Pipeline A: text line-commit
        self.assertEqual(renderer._text_pending, "")
        self.assertIsNone(renderer._held_pipe_line)
        self.assertIsNone(renderer._container)
        # Pipeline B: thinking line-commit + tail
        self.assertEqual(renderer._thinking_batch, "")
        # Pipeline C: loading 行 aux
        self.assertEqual(renderer._loading_aux_text, "")


class TestContainerState(unittest.TestCase):
    def test_fence_init(self):
        state = ContainerState(
            kind="fence",
            lines=["```python"],
            fence_marker="```",
            fence_lang="python",
        )
        self.assertEqual(state.kind, "fence")
        self.assertEqual(state.lines, ["```python"])
        self.assertEqual(state.fence_marker, "```")
        self.assertEqual(state.fence_lang, "python")

    def test_table_init(self):
        state = ContainerState(
            kind="table",
            lines=["| a | b |", "| --- | --- |"],
        )
        self.assertEqual(state.kind, "table")
        self.assertIsNone(state.fence_marker)
        self.assertIsNone(state.fence_lang)

    def test_default_lines_factory(self):
        s1 = ContainerState(kind="fence", fence_marker="```")
        s2 = ContainerState(kind="fence", fence_marker="```")
        s1.lines.append("line 1")
        # 验证 default_factory 不共享 list 实例
        self.assertEqual(s2.lines, [])


if __name__ == "__main__":
    unittest.main()
