from __future__ import annotations

import unittest
from datetime import datetime, timezone
from types import SimpleNamespace
from typing import Any, AsyncIterator

from comate_agent_sdk.agent.events import QueueDirtyEvent, QueueDirtyReason
from comate_agent_sdk.agent.queue_types import MessageOrigin, QueuedMessage

from comate_cli.terminal_agent.tui import TerminalAgentTUI, UIMode


class _FakeInputArea:
    def __init__(self, text: str) -> None:
        self.text = text


class _FakeSession:
    def __init__(self, messages: tuple[QueuedMessage, ...]) -> None:
        self._messages = messages

    def peek_queue(self) -> tuple[QueuedMessage, ...]:
        return self._messages


def _message(
    message_id: str,
    content: Any,
    origin: MessageOrigin = MessageOrigin.HUMAN,
) -> QueuedMessage:
    return QueuedMessage(
        message_id=message_id,
        content=content,
        origin=origin,
        enqueued_at=datetime(2026, 4, 28, tzinfo=timezone.utc),
    )


def _build_tui(messages: tuple[QueuedMessage, ...]) -> TerminalAgentTUI:
    tui = TerminalAgentTUI.__new__(TerminalAgentTUI)
    tui._session = _FakeSession(messages)
    tui._ui_mode = UIMode.NORMAL
    tui._input_area = _FakeInputArea("")
    tui._queued_preview_max_chars = 24
    tui._queued_input_hint = "Press ↑ to edit"
    tui._app = None
    tui._terminal_width = lambda: 80
    return tui


def _join(fragments: list[tuple[str, str]]) -> str:
    return "".join(text for _style, text in fragments)


class TestTUIQueuePreview(unittest.IsolatedAsyncioTestCase):
    def test_queue_panel_reads_human_messages_from_session_snapshot(self) -> None:
        tui = _build_tui(
            (
                _message("human-1", "first message"),
                _message("external-1", "from slack", MessageOrigin.EXTERNAL),
                _message("human-2", "second\nmessage"),
                _message("task-1", "task notice", MessageOrigin.TASK_NOTIFICATION),
            )
        )

        rendered = _join(tui._queue_text())

        self.assertTrue(tui._should_show_queue_panel())
        self.assertIn("     > first message", rendered)
        self.assertIn("     > second message", rendered)
        self.assertNotIn("from slack", rendered)
        self.assertNotIn("task notice", rendered)
        self.assertEqual(tui._queue_height(), 2)

    def test_queue_panel_defaults_to_three_preview_rows(self) -> None:
        tui = _build_tui(
            tuple(_message(f"human-{index}", f"message {index}") for index in range(4))
        )

        rendered = _join(tui._queue_text())

        self.assertIn("message 0", rendered)
        self.assertIn("message 1", rendered)
        self.assertIn("message 2", rendered)
        self.assertNotIn("message 3", rendered)
        self.assertEqual(tui._queue_height(), 3)

    def test_input_placeholder_uses_single_human_preview_and_truncates(self) -> None:
        tui = _build_tui((_message("human-1", "this is a very long queued message"),))
        tui._queued_preview_max_chars = 12

        hint = tui._input_placeholder_hint()

        self.assertIsNotNone(hint)
        assert hint is not None
        self.assertIn("queued message:", hint)
        self.assertIn("...", hint)
        self.assertIn("Press ↑ to edit", hint)

    def test_input_placeholder_hidden_when_input_has_text(self) -> None:
        tui = _build_tui((_message("human-1", "queued message"),))
        tui._input_area = _FakeInputArea("typing")

        self.assertIsNone(tui._input_placeholder_hint())

    async def test_queue_dirty_event_refreshes_bottom_band(self) -> None:
        event = QueueDirtyEvent(
            reason=QueueDirtyReason.ENQUEUED,
            queue_size=1,
            message_ids=("human-1",),
            origins=(MessageOrigin.HUMAN,),
        )

        class _EventSession:
            async def events(self) -> AsyncIterator[QueueDirtyEvent]:
                yield event

        tui = TerminalAgentTUI.__new__(TerminalAgentTUI)
        tui._session = _EventSession()
        tui._closing = False
        tui._maybe_cancel_tool_result_flash = lambda _event: None
        tui._animation_controller = SimpleNamespace(
            on_event=lambda _event: _noop_async()
        )
        tui._renderer = SimpleNamespace(
            handle_event=lambda _event: (False, None),
        )
        tui._maybe_flash_tool_result = lambda _event: None
        counters = {"refresh": 0, "invalidate": 0}
        tui._refresh_layers = lambda: counters.__setitem__(
            "refresh",
            counters["refresh"] + 1,
        )
        tui._invalidate = lambda: counters.__setitem__(
            "invalidate",
            counters["invalidate"] + 1,
        )

        await tui._consume_event_stream()

        self.assertGreaterEqual(counters["refresh"], 1)
        self.assertEqual(counters["invalidate"], 1)


async def _noop_async() -> None:
    return None


if __name__ == "__main__":
    unittest.main(verbosity=2)
