from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from comate_cli.terminal_agent.mention_completer import LocalFileMentionCompleter
from comate_cli.terminal_agent.tui import TerminalAgentTUI


class TestCompletionContextActivation(unittest.TestCase):
    def setUp(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory()
        self.tui = TerminalAgentTUI.__new__(TerminalAgentTUI)
        self.tui._mention_completer = LocalFileMentionCompleter(
            Path(self._tmpdir.name),
            refresh_interval=0.0,
            limit=200,
        )

    def tearDown(self) -> None:
        self._tmpdir.cleanup()

    def test_slash_completion_requires_cursor_at_end(self) -> None:
        self.assertTrue(self.tui._completion_context_active("/model", ""))
        self.assertFalse(self.tui._completion_context_active("/model", " trailing"))

    def test_mention_completion_triggers_at_line_end(self) -> None:
        self.assertTrue(self.tui._completion_context_active("message @file", ""))

    def test_mention_completion_triggers_at_line_start(self) -> None:
        self.assertTrue(self.tui._completion_context_active("@file", " message"))

    def test_mention_completion_triggers_in_middle_with_space_boundaries(self) -> None:
        self.assertTrue(
            self.tui._completion_context_active("message @file", " message")
        )

    def test_mention_completion_rejects_middle_without_right_space(self) -> None:
        self.assertFalse(
            self.tui._completion_context_active("message @file", "message")
        )

    def test_mention_completion_rejects_middle_without_left_space(self) -> None:
        self.assertFalse(
            self.tui._completion_context_active("message@file", " message")
        )

    def test_mention_completion_rejects_inside_token_editing(self) -> None:
        self.assertFalse(
            self.tui._completion_context_active("message @fi", "le message")
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
