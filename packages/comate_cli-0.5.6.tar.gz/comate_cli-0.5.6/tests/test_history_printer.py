from __future__ import annotations

import re
import unittest

from rich.console import Console
from rich.text import Text

from comate_cli.terminal_agent.figures import BLACK_CIRCLE
from comate_cli.terminal_agent.history_printer import render_history_group, print_history_group_sync
from comate_cli.terminal_agent.models import HistoryEntry


def _identity_md(text: str, **kwargs) -> str:
    return text


_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def _strip_ansi(s: str) -> str:
    return _ANSI_RE.sub("", s)


class TestSubtitleRendering(unittest.TestCase):
    """Verify that subtitle lines are rendered for tool_result entries."""

    def _render_to_str(self, entries: list[HistoryEntry]) -> str:
        console = Console(file=None, force_terminal=True, width=120)
        group = render_history_group(
            console, entries, terminal_width=120, render_markdown_to_plain=_identity_md,
        )
        if group is None:
            return ""
        with console.capture() as capture:
            console.print(group)
        return capture.get()

    def test_tool_result_with_subtitle_renders_hook_line(self) -> None:
        entry = HistoryEntry(
            entry_type="tool_result", text="Read(path=test.py)", subtitle="Read 10 lines"
        )
        output = self._render_to_str([entry])
        self.assertIn("⎿", output)
        self.assertIn("Read 10 lines", output)

    def test_tool_result_without_subtitle_no_hook_line(self) -> None:
        entry = HistoryEntry(entry_type="tool_result", text="Agent(task)")
        output = self._render_to_str([entry])
        self.assertNotIn("⎿", output)

    def test_rich_text_tool_result_with_subtitle(self) -> None:
        text_obj = Text("Update(test.py)")
        text_obj.append("\n")
        text_obj.append("+added line", style="green")
        entry = HistoryEntry(
            entry_type="tool_result", text=text_obj, subtitle="Added 1 line, removed 0 lines"
        )
        output = self._render_to_str([entry])
        self.assertIn("⎿", output)
        self.assertIn("Added 1 line, removed 0 lines", output)
        self.assertLess(output.index("Update(test.py)"), output.index("⎿"))
        self.assertLess(output.index("⎿"), output.index("+added line"))

    def test_error_tool_result_with_subtitle(self) -> None:
        entry = HistoryEntry(
            entry_type="tool_result", text="Read(path=bad.py)",
            severity="error", subtitle="File not found",
        )
        output = self._render_to_str([entry])
        self.assertIn("⎿", output)
        self.assertIn("File not found", output)

    def test_file_ref_entry_renders_subtitle_style(self) -> None:
        """file_ref entries render with ⎿ subtitle style, no bullet prefix."""
        entry = HistoryEntry(entry_type="file_ref", text="Read main.py  (42 lines)")
        output = self._render_to_str([entry])
        self.assertIn("⎿", output)
        self.assertIn("Read main.py", output)
        self.assertIn("42 lines", output)
        self.assertNotIn("•", output)

    def test_file_ref_directory_renders_subtitle_style(self) -> None:
        """file_ref entries for directories render with ⎿ subtitle style."""
        entry = HistoryEntry(entry_type="file_ref", text="Listed directory src/components/")
        output = self._render_to_str([entry])
        self.assertIn("⎿", output)
        self.assertIn("Listed directory src/components/", output)
        self.assertNotIn("•", output)


class TestSoftWrapPrefixProtection(unittest.TestCase):
    """Verify ● prefix never gets separated from tool content via print_history_group_sync."""

    def test_long_tool_result_prefix_on_same_line(self) -> None:
        """print_history_group_sync must keep ● on the same line as tool name."""
        entry = HistoryEntry(
            entry_type="tool_result",
            text="Read(path=very/long/path/that/exceeds/terminal/width/file.ts offset=595 limit=35)",
        )
        console = Console(file=None, force_terminal=True, width=40)
        group = render_history_group(
            console, [entry], terminal_width=40, render_markdown_to_plain=_identity_md,
        )
        self.assertIsNotNone(group)
        with console.capture() as capture:
            print_history_group_sync(console, group)
        output = capture.get()
        lines = output.strip().split("\n")
        first_content_line = lines[0]
        self.assertIn(BLACK_CIRCLE, first_content_line)
        self.assertIn("Read", first_content_line)


class TestAssistantRunCollapse(unittest.TestCase):
    """spec §6.5：streaming 管线把每行 commit 成一条 HistoryEntry(assistant)。
    history_printer 必须把"连续 assistant entries"识别为同一条逻辑 message——
    只在 run 起始处加 `●`，其余以 2 空格缩进续接（对照 claude code utils/messages.ts
    normalizeMessages 的"1 dot = 1 logical block"不变量）。"""

    def _render_to_str(
        self,
        entries: list[HistoryEntry],
        *,
        prev_was_assistant: bool = False,
    ) -> str:
        console = Console(file=None, force_terminal=True, width=120)
        group = render_history_group(
            console,
            entries,
            terminal_width=120,
            render_markdown_to_plain=_identity_md,
            prev_was_assistant=prev_was_assistant,
        )
        if group is None:
            return ""
        with console.capture() as capture:
            console.print(group)
        return capture.get()

    def test_single_assistant_entry_keeps_dot(self) -> None:
        entry = HistoryEntry(entry_type="assistant", text="hello world\n")
        output = self._render_to_str([entry])
        self.assertEqual(output.count(BLACK_CIRCLE), 1)
        self.assertIn("hello world", output)

    def test_consecutive_assistant_entries_emit_one_dot(self) -> None:
        """spec §6.5 case：streaming 把多行 commit 成多条 entry，prefix 只在首行出现。"""
        entries = [
            HistoryEntry(entry_type="assistant", text="line one\n"),
            HistoryEntry(entry_type="assistant", text="line two\n"),
            HistoryEntry(entry_type="assistant", text="line three\n"),
        ]
        output = _strip_ansi(self._render_to_str(entries))
        self.assertEqual(output.count(BLACK_CIRCLE), 1, msg=output)
        # 续接行用 2 空格缩进，与首行 marker 对齐
        self.assertRegex(output, rf"{BLACK_CIRCLE}\s+line one")
        self.assertRegex(output, r"\n {2}line two")
        self.assertRegex(output, r"\n {2}line three")

    def test_non_assistant_entry_breaks_run(self) -> None:
        """thinking / tool_result / system 任何非 assistant entry 都会重置 run，下一段 assistant 重新加 dot。"""
        entries = [
            HistoryEntry(entry_type="assistant", text="msg A line 1\n"),
            HistoryEntry(entry_type="assistant", text="msg A line 2\n"),
            HistoryEntry(entry_type="tool_result", text="Read(file)"),
            HistoryEntry(entry_type="assistant", text="msg B line 1\n"),
            HistoryEntry(entry_type="assistant", text="msg B line 2\n"),
        ]
        output = self._render_to_str(entries)
        # tool_result 自身是 BLACK_CIRCLE（绿色），加上两段 assistant 起始的两个 marker，共 3 个。
        self.assertEqual(output.count(BLACK_CIRCLE), 3, msg=output)

    def test_thinking_breaks_run(self) -> None:
        entries = [
            HistoryEntry(entry_type="assistant", text="before\n"),
            HistoryEntry(entry_type="thinking", text="hmm"),
            HistoryEntry(entry_type="assistant", text="after\n"),
        ]
        output = self._render_to_str(entries)
        self.assertEqual(output.count(BLACK_CIRCLE), 2, msg=output)

    def test_prev_was_assistant_seed_suppresses_dot(self) -> None:
        """跨 drain：上一次 drain 末尾是 assistant，本次 drain 起始的 assistant 不应再加 dot。"""
        entries = [
            HistoryEntry(entry_type="assistant", text="continuation line\n"),
        ]
        output = self._render_to_str(entries, prev_was_assistant=True)
        self.assertNotIn(BLACK_CIRCLE, output)
        self.assertIn("continuation line", output)

    def test_prev_was_assistant_seed_does_not_leak_to_non_assistant(self) -> None:
        """seed=True 但当前 entry 不是 assistant，按各自规则正常渲染。"""
        entries = [
            HistoryEntry(entry_type="tool_result", text="Read(x)"),
        ]
        output = self._render_to_str(entries, prev_was_assistant=True)
        self.assertIn(BLACK_CIRCLE, output)  # tool_result 自带绿色 marker
        self.assertIn("Read(x)", output)


class TestLooseListBlankSuppression(unittest.TestCase):
    """CommonMark loose list ("- a\\n\\n- b\\n") 流式按行 commit 后，items 之间
    会变成 text="\\n" 的空 assistant entry，渲染产生多余空行。printer 在两个块
    标记 entry 之间精准跳过空 entry，与 claude code 整段 marked.lexer 视觉对齐。"""

    def _render_to_str(self, entries: list[HistoryEntry]) -> str:
        console = Console(file=None, force_terminal=True, width=120)
        group = render_history_group(
            console, entries, terminal_width=120, render_markdown_to_plain=_identity_md,
        )
        if group is None:
            return ""
        with console.capture() as capture:
            console.print(group)
        return _strip_ansi(capture.get())

    def _content_lines(self, output: str) -> list[str]:
        return [ln for ln in output.split("\n") if ln != ""]

    def test_blank_between_list_items_suppressed(self) -> None:
        entries = [
            HistoryEntry(entry_type="assistant", text="- foo\n"),
            HistoryEntry(entry_type="assistant", text="\n"),
            HistoryEntry(entry_type="assistant", text="- bar\n"),
            HistoryEntry(entry_type="assistant", text="\n"),
            HistoryEntry(entry_type="assistant", text="- baz\n"),
        ]
        lines = self._content_lines(self._render_to_str(entries))
        # 期望仅 3 行 list 内容，无中间空白行
        self.assertEqual(len(lines), 3, msg=lines)
        self.assertIn("- foo", lines[0])
        self.assertIn("- bar", lines[1])
        self.assertIn("- baz", lines[2])

    def test_blank_between_ordered_list_items_suppressed(self) -> None:
        entries = [
            HistoryEntry(entry_type="assistant", text="1. step\n"),
            HistoryEntry(entry_type="assistant", text="\n"),
            HistoryEntry(entry_type="assistant", text="2. next\n"),
        ]
        lines = self._content_lines(self._render_to_str(entries))
        self.assertEqual(len(lines), 2, msg=lines)

    def test_blank_between_blockquote_items_suppressed(self) -> None:
        entries = [
            HistoryEntry(entry_type="assistant", text="> quote a\n"),
            HistoryEntry(entry_type="assistant", text="\n"),
            HistoryEntry(entry_type="assistant", text="> quote b\n"),
        ]
        lines = self._content_lines(self._render_to_str(entries))
        self.assertEqual(len(lines), 2, msg=lines)

    def test_blank_between_paragraphs_preserved(self) -> None:
        """两个普通段落之间的空行不应被吃 —— 仅在两端都是块标记时才跳过。"""
        entries = [
            HistoryEntry(entry_type="assistant", text="paragraph one\n"),
            HistoryEntry(entry_type="assistant", text="\n"),
            HistoryEntry(entry_type="assistant", text="paragraph two\n"),
        ]
        output = self._render_to_str(entries)
        # 段落 1 与段落 2 之间应当存在一行仅空白的内容（来自空 entry 渲染）
        between = output.split("paragraph one")[1].split("paragraph two")[0]
        self.assertIn("\n", between)
        self.assertTrue(
            any(ln.strip() == "" for ln in between.split("\n")),
            msg=f"expected blank line preserved between paragraphs, got {output!r}",
        )

    def test_blank_at_list_to_paragraph_boundary_preserved(self) -> None:
        """list 末尾 → 普通段落：空行保留（next 不是块标记）。"""
        entries = [
            HistoryEntry(entry_type="assistant", text="- foo\n"),
            HistoryEntry(entry_type="assistant", text="\n"),
            HistoryEntry(entry_type="assistant", text="trailing paragraph\n"),
        ]
        output = self._render_to_str(entries)
        between = output.split("- foo")[1].split("trailing paragraph")[0]
        self.assertTrue(
            any(ln.strip() == "" for ln in between.split("\n")),
            msg=f"expected blank preserved between list end and paragraph, got {output!r}",
        )

    def test_blank_at_start_or_end_preserved(self) -> None:
        """首尾的空 entry：无 prev/next，按现状保留（不跳过）。"""
        entries = [
            HistoryEntry(entry_type="assistant", text="\n"),
            HistoryEntry(entry_type="assistant", text="- only item\n"),
            HistoryEntry(entry_type="assistant", text="\n"),
        ]
        # 不抛异常即可；当前实现不会跳过首尾空 entry，行为与之前一致。
        self._render_to_str(entries)


class TestAssumeRunContinuesAtTail(unittest.TestCase):
    """drain 在 streaming 4-6fps 节奏下把同一 run 的 entry 切碎成多个 batch。
    如果 render_history_group 在每个 batch 末尾的 assistant entry 后都加 trailing
    Text("")，跨 batch 拼接的视觉就是 "每条 entry 间多一空行"（用户实际看到的 bug）。
    assume_run_continues_at_tail=True 让 history_printer 把 batch 末尾的 assistant
    entry 当作 "run 仍在续" 处理，不加 trailing 空行。"""

    def _render_lines(
        self,
        entries: list[HistoryEntry],
        *,
        prev_was_assistant: bool = False,
        assume_run_continues_at_tail: bool = False,
    ) -> list[str]:
        console = Console(file=None, force_terminal=True, width=120)
        group = render_history_group(
            console, entries, terminal_width=120,
            render_markdown_to_plain=_identity_md,
            prev_was_assistant=prev_was_assistant,
            assume_run_continues_at_tail=assume_run_continues_at_tail,
        )
        if group is None:
            return []
        with console.capture() as capture:
            console.print(group, soft_wrap=True)
        return _strip_ansi(capture.get()).split("\n")

    def test_default_off_preserves_trailing_blank_line(self) -> None:
        """默认 False：保持原行为，末尾 assistant entry 后加 trailing 空行。"""
        entry = HistoryEntry(entry_type="assistant", text="- foo\n")
        lines = self._render_lines([entry])
        self.assertTrue(
            any(ln.strip() == "" for ln in lines),
            msg=f"default behaviour expected trailing blank, got {lines!r}",
        )

    def test_on_suppresses_trailing_blank_for_assistant_tail(self) -> None:
        """开启后：batch 末尾是 assistant entry 时不加 trailing 空行。"""
        entry = HistoryEntry(entry_type="assistant", text="- foo\n")
        lines = self._render_lines([entry], assume_run_continues_at_tail=True)
        # 只剩一行实质内容（list-marker 行），无 trailing 空白行
        non_empty = [ln for ln in lines if ln.strip() != ""]
        self.assertEqual(len(non_empty), 1, msg=lines)

    def test_on_does_not_affect_non_assistant_tail(self) -> None:
        """开启后：batch 末尾是非 assistant entry 时，trailing 空行仍保留。"""
        entry = HistoryEntry(entry_type="tool_result", text="Read(x)")
        lines_off = self._render_lines([entry], assume_run_continues_at_tail=False)
        lines_on = self._render_lines([entry], assume_run_continues_at_tail=True)
        # 视觉一致：参数仅影响 assistant 末尾，不影响其它 entry 类型
        self.assertEqual(lines_off, lines_on)

    def test_split_batch_visual_matches_single_batch(self) -> None:
        """核心不变量：同样 entry 序列分两批传（前批 assume=True 模拟 streaming
        中的 drain）拼接出来的视觉，应当等价于一次性传 + 默认参数的视觉。"""
        entries = [
            HistoryEntry(entry_type="assistant", text="- foo\n"),
            HistoryEntry(entry_type="assistant", text="- bar\n"),
            HistoryEntry(entry_type="assistant", text="- baz\n"),
        ]
        # 一次性 batch（以前的视觉，作为基准）
        single_lines = self._render_lines(entries)

        # 拆成 2+1 两批：前批末尾 assume=True（模拟 streaming 中），后批默认（turn 结束）
        first = self._render_lines(
            entries[:2], assume_run_continues_at_tail=True,
        )
        # 拼接：前批末尾 + 后批（用 prev_was_assistant=True 续 run）
        second = self._render_lines(
            entries[2:], prev_was_assistant=True,
        )
        # console.print 自带 trailing \n，两次 print 拼接 = first + second
        merged = first + second

        # 两种渲染方式产生的"实质内容行"应当一致（去掉空行 / 边界差异后比较）
        single_content = [ln for ln in single_lines if ln.strip() != ""]
        merged_content = [ln for ln in merged if ln.strip() != ""]
        self.assertEqual(single_content, merged_content)

        # 关键不变量：merged 内部不应出现连续两个空行（即 list 项之间无多余空行）
        for i in range(len(merged) - 1):
            if merged[i].strip() == "" and merged[i + 1].strip() == "":
                # 允许 trailing 部分有连续空行；只检查实质内容之间
                rest_has_content = any(
                    ln.strip() != "" for ln in merged[i + 2 :]
                )
                if rest_has_content:
                    self.fail(
                        f"unexpected blank-line gap inside list run at index {i}: {merged!r}"
                    )

    def test_consecutive_thinking_entries_do_not_insert_blank_lines(self) -> None:
        """thinking 按行流式后，连续 thinking entry 仍应像一个视觉 run。"""
        entries = [
            HistoryEntry(entry_type="thinking", text="line one\n"),
            HistoryEntry(entry_type="thinking", text="line two\n"),
        ]
        lines = self._render_lines(entries)
        self.assertIn("  line one", lines)
        first_idx = lines.index("  line one")
        self.assertEqual(lines[first_idx + 1], "  line two", msg=lines)

    def test_assume_tail_suppresses_trailing_blank_for_thinking_tail(self) -> None:
        entry = HistoryEntry(entry_type="thinking", text="streamed thought\n")
        lines = self._render_lines([entry], assume_run_continues_at_tail=True)
        non_empty = [ln for ln in lines if ln.strip() != ""]
        self.assertEqual(non_empty, ["  streamed thought"], msg=lines)

    def test_split_thinking_batch_visual_matches_single_batch(self) -> None:
        entries = [
            HistoryEntry(entry_type="thinking", text="line one\n"),
            HistoryEntry(entry_type="thinking", text="line two\n"),
            HistoryEntry(entry_type="thinking", text="line three\n"),
        ]
        single_lines = self._render_lines(entries)
        first = self._render_lines(
            entries[:2], assume_run_continues_at_tail=True,
        )
        second = self._render_lines(entries[2:])
        merged = first + second

        single_content = [ln for ln in single_lines if ln.strip() != ""]
        merged_content = [ln for ln in merged if ln.strip() != ""]
        self.assertEqual(single_content, merged_content)

        # 关键不变量：merged 内部不应出现连续两个空行（即 thinking 行之间无多余空行）
        for i in range(len(merged) - 1):
            if merged[i].strip() == "" and merged[i + 1].strip() == "":
                # 允许 trailing 部分有连续空行；只检查实质内容之间
                rest_has_content = any(
                    ln.strip() != "" for ln in merged[i + 2 :]
                )
                if rest_has_content:
                    self.fail(
                        f"unexpected blank-line gap inside thinking run at index {i}: {merged!r}"
                    )
