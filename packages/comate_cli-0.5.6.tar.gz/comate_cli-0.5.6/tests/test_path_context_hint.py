from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from comate_cli.terminal_agent.path_context_hint import build_path_context_hint


class TestBuildPathContextHint(unittest.TestCase):
    def setUp(self) -> None:
        self._tmpdir_obj = tempfile.TemporaryDirectory()
        self.root = Path(self._tmpdir_obj.name)

    def tearDown(self) -> None:
        self._tmpdir_obj.cleanup()

    def test_hint_wrapped_in_system_reminder_tags(self) -> None:
        f = self.root / "x.py"
        f.write_text("a\n")
        hint = build_path_context_hint("@x.py", self.root)
        self.assertTrue(hint.startswith("<system_reminder>\n"))
        self.assertTrue(hint.endswith("\n</system_reminder>"))

    def test_file_with_line_count(self) -> None:
        f = self.root / "app.py"
        f.write_text("line1\nline2\nline3\n")
        hint = build_path_context_hint("check @app.py please", self.root)
        self.assertIn("@app.py", hint)
        self.assertIn("file", hint)
        self.assertIn(".py", hint)
        self.assertIn("3 lines", hint)

    def test_empty_directory(self) -> None:
        d = self.root / "novel"
        d.mkdir()
        hint = build_path_context_hint("look at @novel/ dir", self.root)
        self.assertIn("@novel/", hint)
        self.assertIn("directory", hint)
        self.assertIn("empty", hint)

    def test_non_empty_directory(self) -> None:
        d = self.root / "src"
        d.mkdir()
        (d / "a.py").write_text("x")
        (d / "b.py").write_text("y")
        sub = d / "utils"
        sub.mkdir()
        hint = build_path_context_hint("check @src/ dir", self.root)
        self.assertIn("2 files", hint)
        self.assertIn("1 subdir", hint)

    def test_not_found_with_dot(self) -> None:
        hint = build_path_context_hint("read @missing.txt", self.root)
        self.assertIn("@missing.txt", hint)
        self.assertIn("not found", hint)

    def test_not_found_with_slash(self) -> None:
        hint = build_path_context_hint("check @some/path", self.root)
        self.assertIn("not found", hint)

    def test_pure_word_mention_filtered(self) -> None:
        """@user without . or / should be filtered when not found."""
        hint = build_path_context_hint("ask @user about this", self.root)
        self.assertIsNone(hint)

    def test_no_mentions_returns_none(self) -> None:
        hint = build_path_context_hint("hello world", self.root)
        self.assertIsNone(hint)

    def test_max_10_paths(self) -> None:
        for i in range(15):
            (self.root / f"f{i}.py").write_text(f"file {i}")
        text = " ".join(f"@f{i}.py" for i in range(15))
        hint = build_path_context_hint(text, self.root)
        self.assertEqual(hint.count("→"), 10)

    def test_large_file_skips_line_count(self) -> None:
        f = self.root / "big.bin"
        f.write_bytes(b"x" * (256 * 1024 + 1))
        hint = build_path_context_hint("check @big.bin", self.root)
        self.assertIn("~large", hint)
        self.assertNotIn("lines", hint)

    def test_file_no_extension(self) -> None:
        f = self.root / "Makefile"
        f.write_text("all:\n\techo hi\n")
        hint = build_path_context_hint("check @Makefile", self.root)
        self.assertIn("no ext", hint)

    def test_path_traversal_filtered(self) -> None:
        """@../escape should be silently filtered."""
        hint = build_path_context_hint("check @../escape", self.root)
        self.assertIsNone(hint)

    def test_absolute_path_filtered(self) -> None:
        """Absolute paths should be filtered (resolve escapes root)."""
        hint = build_path_context_hint("check @/etc/passwd", self.root)
        self.assertIsNone(hint)

    def test_broken_symlink_treated_as_not_found(self) -> None:
        target = self.root / "gone.txt"
        link = self.root / "link.txt"
        link.symlink_to(target)  # target doesn't exist
        hint = build_path_context_hint("check @link.txt", self.root)
        self.assertIn("not found", hint)

    def test_file_hint_includes_absolute_path(self) -> None:
        """File hints should include [absolute_path] suffix."""
        f = self.root / "demo.py"
        f.write_text("x\n")
        hint = build_path_context_hint("check @demo.py", self.root)
        expected_abs = str(f.resolve())
        self.assertIn(f"[{expected_abs}]", hint)

    def test_dir_hint_includes_absolute_path(self) -> None:
        """Directory hints should include [absolute_path] suffix."""
        d = self.root / "src"
        d.mkdir()
        (d / "a.py").write_text("x")
        hint = build_path_context_hint("check @src/", self.root)
        expected_abs = str(d.resolve())
        self.assertIn(f"[{expected_abs}]", hint)

    def test_not_found_has_no_absolute_path(self) -> None:
        """'not found' lines should NOT include [absolute_path] suffix."""
        hint = build_path_context_hint("read @missing.txt", self.root)
        self.assertIn("not found", hint)
        self.assertNotIn("[", hint.split("not found")[1])
