from __future__ import annotations

import unittest
from importlib import import_module
from unittest.mock import patch

main_module = import_module("comate_cli.main")


class TestMainArgs(unittest.TestCase):
    def test_parse_args_defaults_to_new_session(self) -> None:
        rpc_stdio, resume_session_id, resume_select, print_prompt = main_module._parse_args([])
        self.assertFalse(rpc_stdio)
        self.assertIsNone(resume_session_id)
        self.assertFalse(resume_select)
        self.assertIsNone(print_prompt)

    def test_parse_args_resume_subcommand(self) -> None:
        rpc_stdio, resume_session_id, resume_select, print_prompt = main_module._parse_args(
            ["resume", "sid-001", "--rpc-stdio"]
        )
        self.assertTrue(rpc_stdio)
        self.assertEqual(resume_session_id, "sid-001")
        self.assertFalse(resume_select)
        self.assertIsNone(print_prompt)

    def test_parse_args_resume_without_session_id_enters_selection_mode(self) -> None:
        rpc_stdio, resume_session_id, resume_select, print_prompt = main_module._parse_args(
            ["resume"]
        )
        self.assertFalse(rpc_stdio)
        self.assertIsNone(resume_session_id)
        self.assertTrue(resume_select)
        self.assertIsNone(print_prompt)

    def test_parse_args_rejects_legacy_implicit_session_id(self) -> None:
        with self.assertRaises(main_module._ArgumentError):
            main_module._parse_args(["sid-legacy"])

    def test_parse_args_rejects_resume_without_session_id_with_rpc_stdio(self) -> None:
        with self.assertRaises(main_module._ArgumentError):
            main_module._parse_args(["resume", "--rpc-stdio"])

    def test_parse_args_rejects_unknown_option(self) -> None:
        with self.assertRaises(main_module._ArgumentError):
            main_module._parse_args(["--unknown"])

    def test_parse_args_print_with_prompt(self) -> None:
        rpc_stdio, resume_session_id, resume_select, print_prompt = main_module._parse_args(
            ["-p", "explain this code"]
        )
        self.assertFalse(rpc_stdio)
        self.assertIsNone(resume_session_id)
        self.assertFalse(resume_select)
        self.assertEqual(print_prompt, "explain this code")

    def test_parse_args_print_long_flag(self) -> None:
        _, _, _, print_prompt = main_module._parse_args(["--print", "hello"])
        self.assertEqual(print_prompt, "hello")

    def test_parse_args_print_without_prompt(self) -> None:
        _, _, _, print_prompt = main_module._parse_args(["-p"])
        self.assertEqual(print_prompt, "")

    def test_parse_args_print_treats_positionals_as_prompt(self) -> None:
        """comate -p resume → prompt is 'resume', not resume subcommand."""
        _, _, _, print_prompt = main_module._parse_args(["-p", "resume"])
        self.assertEqual(print_prompt, "resume")

    def test_parse_args_print_rejects_rpc_stdio(self) -> None:
        with self.assertRaises(main_module._ArgumentError):
            main_module._parse_args(["-p", "hello", "--rpc-stdio"])

    def test_parse_args_print_absorbs_all_positionals(self) -> None:
        """-p absorbs all positionals as prompt, including 'resume'."""
        _, _, _, print_prompt = main_module._parse_args(["resume", "-p", "hello"])
        self.assertEqual(print_prompt, "resume hello")

    def test_main_print_mode_empty_input_exits(self) -> None:
        """comate -p (no prompt, no stdin pipe) → exit(1)."""
        with patch("sys.stdin") as mock_stdin:
            mock_stdin.isatty.return_value = True
            with self.assertRaises(SystemExit) as ctx:
                main_module.main(["-p"])
            self.assertEqual(ctx.exception.code, 1)

    def test_main_print_mode_stdin_pipe_assembly(self) -> None:
        """echo 'code' | comate -p 'explain' → message = 'code\\n\\nexplain'."""
        from io import StringIO
        from unittest.mock import AsyncMock

        with patch("comate_cli.terminal_agent.app.run", new_callable=AsyncMock) as mock_run:
            with patch("sys.stdin", StringIO("piped code")):
                main_module.main(["-p", "explain"])
        call_kwargs = mock_run.call_args.kwargs
        self.assertEqual(call_kwargs["print_message"], "piped code\n\nexplain")

    def test_main_print_mode_stdin_only(self) -> None:
        """echo 'code' | comate -p → message = 'code'."""
        from io import StringIO
        from unittest.mock import AsyncMock

        with patch("comate_cli.terminal_agent.app.run", new_callable=AsyncMock) as mock_run:
            with patch("sys.stdin", StringIO("just stdin")):
                main_module.main(["-p"])
        call_kwargs = mock_run.call_args.kwargs
        self.assertEqual(call_kwargs["print_message"], "just stdin")

    def test_main_print_mode_passes_message_to_run(self) -> None:
        """main(['-p', 'hello world']) should call run(print_message='hello world')."""
        from unittest.mock import AsyncMock

        with patch("comate_cli.terminal_agent.app.run", new_callable=AsyncMock) as mock_run:
            with patch("sys.stdin") as mock_stdin:
                mock_stdin.isatty.return_value = True
                main_module.main(["-p", "hello world"])
        mock_run.assert_called_once()
        call_kwargs = mock_run.call_args.kwargs
        self.assertEqual(call_kwargs["print_message"], "hello world")
        self.assertFalse(call_kwargs["rpc_stdio"])

    def test_main_routes_mcp_subcommand(self) -> None:
        with patch("comate_cli.mcp_cli.run_mcp_command") as mock_run:
            main_module.main(["mcp", "list"])
        mock_run.assert_called_once_with(["list"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
