"""Tests for ErrorsTab (Task 13)."""

from __future__ import annotations

import asyncio
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch


def _make_plugin_error(
    plugin_key: str = "plugin-a@mkt",
    error_type: str = "load_failure",
    message: str = "Something went wrong",
    error_id: str | None = None,
    timestamp: str = "2026-01-01T00:00:00+00:00",
) -> object:
    """构造一个 PluginError mock。"""
    from comate_agent_sdk.plugins.models import PluginError

    return PluginError(
        error_id=error_id or f"err-{plugin_key}",
        plugin_key=plugin_key,
        error_type=error_type,  # type: ignore[arg-type]
        message=message,
        timestamp=timestamp,
    )


def _make_installed_entry(install_path: Path = Path("/fake/path")) -> object:
    entry = MagicMock()
    entry.install_path = install_path
    return entry


def _make_tab(
    errors: list | None = None,
    installed: dict | None = None,
) -> object:
    """构造 ErrorsTab，注入 mock 依赖。"""
    from comate_cli.terminal_agent.plugins.tabs.errors_tab import ErrorsTab

    loader = MagicMock()
    loader.load_from_path = MagicMock(return_value=MagicMock())

    registry = MagicMock()
    registry.list_installed = MagicMock(return_value=installed or {})

    tab = ErrorsTab(loader, registry)
    if errors is not None:
        tab.set_errors(errors)
    return tab


# ---------------------------------------------------------------------------
# set_errors / error_count
# ---------------------------------------------------------------------------


class TestErrorsTabSetErrors(unittest.TestCase):
    def test_set_errors_populates_list(self) -> None:
        tab = _make_tab()
        errors = [
            _make_plugin_error("plugin-a@mkt"),
            _make_plugin_error("plugin-b@mkt"),
        ]
        tab.set_errors(errors)
        self.assertEqual(tab.error_count, 2)

    def test_error_count_initially_zero(self) -> None:
        tab = _make_tab()
        self.assertEqual(tab.error_count, 0)

    def test_set_errors_resets_cursor(self) -> None:
        tab = _make_tab(errors=[_make_plugin_error("p0"), _make_plugin_error("p1")])
        tab._cursor = 1
        tab.set_errors([_make_plugin_error("p2")])
        self.assertEqual(tab._cursor, 0)

    def test_set_errors_replaces_existing(self) -> None:
        tab = _make_tab(errors=[_make_plugin_error("old@mkt")])
        tab.set_errors([_make_plugin_error("new1@mkt"), _make_plugin_error("new2@mkt")])
        self.assertEqual(tab.error_count, 2)


# ---------------------------------------------------------------------------
# activate
# ---------------------------------------------------------------------------


class TestErrorsTabActivate(unittest.TestCase):
    def test_activate_clears_status_message(self) -> None:
        tab = _make_tab()
        tab._status_message = "stale"
        tab.activate()
        self.assertEqual(tab._status_message, "")

    def test_activate_fixes_cursor_overflow(self) -> None:
        errors = [_make_plugin_error("p0"), _make_plugin_error("p1")]
        tab = _make_tab(errors=errors)
        tab._cursor = 5  # 越界
        tab.activate()
        self.assertLess(tab._cursor, len(errors))

    def test_activate_cursor_zero_when_empty(self) -> None:
        tab = _make_tab(errors=[])
        tab._cursor = 3
        tab.activate()
        self.assertEqual(tab._cursor, 0)


# ---------------------------------------------------------------------------
# 渲染
# ---------------------------------------------------------------------------


class TestErrorsTabRendering(unittest.TestCase):
    def test_empty_list_shows_no_errors_message(self) -> None:
        tab = _make_tab(errors=[])
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("No plugin errors", flat)

    def test_list_does_not_show_inline_hint(self) -> None:
        """提示信息已移入 footer，content 区不应包含快捷键提示。"""
        tab = _make_tab(errors=[])
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertNotIn("[r] Retry", flat)
        self.assertNotIn("[d] Dismiss", flat)

    def test_list_shows_plugin_key_with_error_marker(self) -> None:
        errors = [_make_plugin_error("plugin-a@mkt")]
        tab = _make_tab(errors=errors)
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("✗", flat)
        self.assertIn("plugin-a@mkt", flat)

    def test_list_shows_error_type(self) -> None:
        errors = [_make_plugin_error("plugin-a@mkt", error_type="manifest_error")]
        tab = _make_tab(errors=errors)
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("manifest_error", flat)

    def test_list_shows_error_message_preview(self) -> None:
        errors = [_make_plugin_error("plugin-a@mkt", message="Detailed error info")]
        tab = _make_tab(errors=errors)
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("Detailed error info", flat)

    def test_long_error_message_truncated(self) -> None:
        long_msg = "x" * 100
        errors = [_make_plugin_error("plugin-a@mkt", message=long_msg)]
        tab = _make_tab(errors=errors)
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("...", flat)

    def test_cursor_row_uses_bold_style(self) -> None:
        errors = [_make_plugin_error("plugin-a@mkt")]
        tab = _make_tab(errors=errors)
        tab.activate()
        text = tab.get_formatted_text()
        styles = [t[0] for t in text]
        self.assertIn("bold", styles)

    def test_status_message_shows_in_list(self) -> None:
        tab = _make_tab(errors=[])
        tab.activate()
        tab._status_message = "retry in progress"
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("retry in progress", flat)

    def test_multiple_errors_all_shown(self) -> None:
        errors = [
            _make_plugin_error("plugin-a@mkt"),
            _make_plugin_error("plugin-b@mkt"),
            _make_plugin_error("plugin-c@mkt"),
        ]
        tab = _make_tab(errors=errors)
        tab.activate()
        text = tab.get_formatted_text()
        flat = "".join(t[1] for t in text)
        self.assertIn("plugin-a@mkt", flat)
        self.assertIn("plugin-b@mkt", flat)
        self.assertIn("plugin-c@mkt", flat)


# ---------------------------------------------------------------------------
# 导航
# ---------------------------------------------------------------------------


class TestErrorsTabNavigation(unittest.TestCase):
    def setUp(self) -> None:
        self.errors = [
            _make_plugin_error("p0@mkt"),
            _make_plugin_error("p1@mkt"),
            _make_plugin_error("p2@mkt"),
        ]
        self.tab = _make_tab(errors=self.errors)
        self.tab.activate()

    def test_initial_cursor_is_zero(self) -> None:
        self.assertEqual(self.tab._cursor, 0)

    def test_handle_down_advances_cursor(self) -> None:
        self.tab.handle_down()
        self.assertEqual(self.tab._cursor, 1)

    def test_handle_up_moves_cursor_back(self) -> None:
        self.tab.handle_down()
        self.tab.handle_up()
        self.assertEqual(self.tab._cursor, 0)

    def test_navigation_wraps_around(self) -> None:
        for _ in range(3):
            self.tab.handle_down()
        self.assertEqual(self.tab._cursor, 0)

    def test_navigation_ignored_when_empty(self) -> None:
        tab = _make_tab(errors=[])
        tab.activate()
        tab.handle_down()
        tab.handle_up()
        self.assertEqual(tab._cursor, 0)


# ---------------------------------------------------------------------------
# handle_dismiss
# ---------------------------------------------------------------------------


class TestErrorsTabHandleDismiss(unittest.TestCase):
    def test_dismiss_removes_current_error(self) -> None:
        errors = [
            _make_plugin_error("p0@mkt", error_id="err-0"),
            _make_plugin_error("p1@mkt", error_id="err-1"),
        ]
        tab = _make_tab(errors=errors)
        tab.activate()
        tab.handle_dismiss()
        self.assertEqual(tab.error_count, 1)
        # 第一个错误（p0）被删除，剩下 p1
        self.assertEqual(tab._errors[0].plugin_key, "p1@mkt")

    def test_dismiss_fixes_cursor_on_last_item(self) -> None:
        errors = [
            _make_plugin_error("p0@mkt", error_id="err-0"),
            _make_plugin_error("p1@mkt", error_id="err-1"),
        ]
        tab = _make_tab(errors=errors)
        tab.activate()
        tab.handle_down()  # cursor = 1 (last)
        tab.handle_dismiss()
        # cursor 应修正为 0（新的最后一个有效位置）
        self.assertEqual(tab._cursor, 0)

    def test_dismiss_on_empty_list_is_noop(self) -> None:
        tab = _make_tab(errors=[])
        tab.activate()
        tab.handle_dismiss()  # should not raise
        self.assertEqual(tab.error_count, 0)

    def test_dismiss_decrements_error_count(self) -> None:
        errors = [_make_plugin_error("p0@mkt"), _make_plugin_error("p1@mkt")]
        tab = _make_tab(errors=errors)
        tab.activate()
        tab.handle_dismiss()
        self.assertEqual(tab.error_count, 1)


# ---------------------------------------------------------------------------
# handle_retry
# ---------------------------------------------------------------------------


class TestErrorsTabHandleRetry(unittest.TestCase):
    @patch("asyncio.create_task")
    def test_handle_retry_schedules_task(self, mock_create: MagicMock) -> None:
        errors = [_make_plugin_error("plugin-a@mkt")]
        tab = _make_tab(errors=errors)
        tab.activate()
        mock_create.side_effect = lambda coro: coro.close() or MagicMock()
        tab.handle_retry()
        mock_create.assert_called_once()
        self.assertIn("Retrying", tab._status_message)

    @patch("asyncio.create_task")
    def test_handle_retry_ignored_when_empty(self, mock_create: MagicMock) -> None:
        tab = _make_tab(errors=[])
        tab.activate()
        tab.handle_retry()
        mock_create.assert_not_called()

    def test_handle_retry_sets_status_message(self) -> None:
        errors = [_make_plugin_error("plugin-a@mkt")]
        tab = _make_tab(errors=errors)
        tab.activate()
        with patch("asyncio.create_task") as mock_create:
            mock_create.side_effect = lambda coro: coro.close() or MagicMock()
            tab.handle_retry()
        self.assertIn("plugin-a@mkt", tab._status_message)


# ---------------------------------------------------------------------------
# go_back
# ---------------------------------------------------------------------------


class TestErrorsTabGoBack(unittest.TestCase):
    def test_go_back_always_returns_false(self) -> None:
        tab = _make_tab(errors=[_make_plugin_error("plugin-a@mkt")])
        tab.activate()
        self.assertFalse(tab.go_back())


# ---------------------------------------------------------------------------
# 异步操作 (_do_retry)
# ---------------------------------------------------------------------------


class TestErrorsTabAsync(unittest.IsolatedAsyncioTestCase):
    async def test_do_retry_success_removes_error(self) -> None:
        """重试成功后应从 _errors 中移除该条目。"""
        error = _make_plugin_error("plugin-a@mkt", error_id="err-001")
        install_path = Path("/fake/plugin-a")
        installed = {"plugin-a@mkt": [_make_installed_entry(install_path)]}

        tab = _make_tab(errors=[error], installed=installed)
        tab.activate()

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.errors_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_retry(error)

        tab._loader.load_from_path.assert_called_once_with(install_path, source_type="registry")
        self.assertEqual(tab.error_count, 0)
        self.assertIn("Loaded", tab._status_message)

    async def test_do_retry_failure_keeps_error_and_sets_message(self) -> None:
        """重试失败后应保留错误条目并设置错误消息。"""
        error = _make_plugin_error("plugin-a@mkt", error_id="err-001")
        install_path = Path("/fake/plugin-a")
        installed = {"plugin-a@mkt": [_make_installed_entry(install_path)]}

        tab = _make_tab(errors=[error], installed=installed)
        tab.activate()
        tab._loader.load_from_path = MagicMock(side_effect=ValueError("manifest missing"))

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.errors_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_retry(error)

        self.assertEqual(tab.error_count, 1)
        self.assertIn("Failed", tab._status_message)
        self.assertIn("manifest missing", tab._status_message)

    async def test_do_retry_not_in_registry_sets_error_message(self) -> None:
        """install_path 找不到时应设置错误消息，不崩溃。"""
        error = _make_plugin_error("plugin-a@mkt", error_id="err-001")
        # 空 installed 列表
        tab = _make_tab(errors=[error], installed={})
        tab.activate()

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.errors_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_retry(error)

        self.assertEqual(tab.error_count, 1)
        self.assertIn("install path not found", tab._status_message)

    async def test_do_retry_only_removes_matched_error(self) -> None:
        """重试成功后只应移除对应 error_id 的条目，其他错误保留。"""
        error_a = _make_plugin_error("plugin-a@mkt", error_id="err-a")
        error_b = _make_plugin_error("plugin-b@mkt", error_id="err-b")
        install_path_a = Path("/fake/plugin-a")
        installed = {"plugin-a@mkt": [_make_installed_entry(install_path_a)]}

        tab = _make_tab(errors=[error_a, error_b], installed=installed)
        tab.activate()

        with patch(
            "comate_cli.terminal_agent.plugins.tabs.errors_tab.get_app_or_none",
            return_value=None,
        ):
            await tab._do_retry(error_a)

        self.assertEqual(tab.error_count, 1)
        self.assertEqual(tab._errors[0].plugin_key, "plugin-b@mkt")
