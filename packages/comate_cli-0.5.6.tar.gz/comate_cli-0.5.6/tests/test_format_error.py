"""Tests for unified error formatter."""
from __future__ import annotations

import unittest


class TestFormatError(unittest.TestCase):
    """Each test verifies (message, transient_summary, severity) for one error type."""

    def _make_exc(self, cls_name: str, msg: str = "", **attrs):
        """Create a fake exception with a given class name and attributes."""
        exc = type(cls_name, (Exception,), {})(msg)
        for k, v in attrs.items():
            setattr(exc, k, v)
        return exc

    def test_rate_limit(self):
        from comate_cli.terminal_agent.error_display import format_error

        exc = self._make_exc("ModelRateLimitError")
        msg, transient, severity = format_error(exc)
        assert severity == "warning"
        assert "Rate limit" in msg
        assert transient == "Rate limited"

    def test_provider_401(self):
        from comate_cli.terminal_agent.error_display import format_error

        exc = self._make_exc("ModelProviderError", status_code=401)
        msg, transient, severity = format_error(exc)
        assert severity == "error"
        assert "API key" in msg
        assert transient == "Auth failed"

    def test_provider_403(self):
        from comate_cli.terminal_agent.error_display import format_error

        exc = self._make_exc("ModelProviderError", status_code=403)
        msg, transient, severity = format_error(exc)
        assert severity == "error"
        assert "Access denied" in msg
        assert transient == "Access denied"

    def test_provider_404(self):
        from comate_cli.terminal_agent.error_display import format_error

        exc = self._make_exc("ModelProviderError", status_code=404)
        msg, transient, severity = format_error(exc)
        assert severity == "error"
        assert "not found" in msg.lower()
        assert transient == "Model not found"

    def test_provider_5xx(self):
        from comate_cli.terminal_agent.error_display import format_error

        exc = self._make_exc("ModelProviderError", status_code=502)
        msg, transient, severity = format_error(exc)
        assert severity == "warning"
        assert "502" in msg
        assert transient == "Server error"

    def test_context_size_exceeded(self):
        from comate_cli.terminal_agent.error_display import format_error

        body = (
            "Error code: 400 - {'error': {'code': 400, "
            "'message': 'request (35099 tokens) exceeds the available context size (32768 tokens)', "
            "'type': 'exceed_context_size_error', 'n_prompt_tokens': 35099, 'n_ctx': 32768}}"
        )
        exc = self._make_exc("ModelProviderError", body, status_code=400)
        msg, transient, severity = format_error(exc)
        assert severity == "error"
        assert "35099" in msg
        assert "32768" in msg
        assert transient == "Context limit exceeded"

    def test_context_size_type_without_parseable_numbers(self):
        from comate_cli.terminal_agent.error_display import format_error

        exc = self._make_exc(
            "ModelProviderError",
            "exceed_context_size_error without parseable numbers",
            status_code=400,
        )
        msg, transient, severity = format_error(exc)
        assert severity == "error"
        assert transient == "API error"  # Falls through to generic 400

    def test_provider_400_generic(self):
        from comate_cli.terminal_agent.error_display import format_error

        exc = self._make_exc("ModelProviderError", "bad request", status_code=400)
        msg, transient, severity = format_error(exc)
        assert severity == "error"
        assert "API error" in msg
        assert transient == "API error"

    def test_session_closed(self):
        from comate_cli.terminal_agent.error_display import format_error

        exc = self._make_exc("ChatSessionClosedError")
        msg, transient, severity = format_error(exc)
        assert severity == "error"
        assert "Session closed" in msg
        assert transient == "Session closed"

    def test_timeout(self):
        from comate_cli.terminal_agent.error_display import format_error

        exc = Exception("request timed out after 30s")
        msg, transient, severity = format_error(exc)
        assert severity == "warning"
        assert "timed out" in msg.lower()
        assert transient == "Timed out"

    def test_connection_error(self):
        from comate_cli.terminal_agent.error_display import format_error

        exc = Exception("Connection refused")
        msg, transient, severity = format_error(exc)
        assert severity == "error"
        assert "Connection failed" in msg
        assert transient == "Connection failed"

    def test_generic_fallback(self):
        from comate_cli.terminal_agent.error_display import format_error

        exc = Exception("something unexpected")
        msg, transient, severity = format_error(exc)
        assert severity == "error"
        assert "something unexpected" in msg
        assert transient == "Error occurred"

    def test_no_icons_in_messages(self):
        """All messages must be plain text, no emoji icons."""
        from comate_cli.terminal_agent.error_display import format_error

        test_cases = [
            self._make_exc("ModelRateLimitError"),
            self._make_exc("ModelProviderError", status_code=401),
            self._make_exc("ChatSessionClosedError"),
            Exception("timeout"),
            Exception("generic error"),
        ]
        for exc in test_cases:
            msg, transient, severity = format_error(exc)
            assert "⚠" not in msg, f"Icon found in: {msg}"
            assert "✖" not in msg, f"Icon found in: {msg}"
            assert "💡" not in msg, f"Icon found in: {msg}"


if __name__ == "__main__":
    unittest.main(verbosity=2)
