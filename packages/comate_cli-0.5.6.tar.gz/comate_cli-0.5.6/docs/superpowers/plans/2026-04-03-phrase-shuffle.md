# Phrase Shuffle Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the loading animation show phrases in a random order per message instead of a fixed sequential order.

**Architecture:** Add a `_shuffled` field to `SubmissionAnimator` that holds a Fisher-Yates shuffled copy of `_phrases`. Shuffle on every `start()` call. All reads of the current phrase go through `_shuffled` instead of `_phrases`.

**Tech Stack:** Python 3.12, asyncio, `random.shuffle`, pytest

---

### Task 1: Write failing tests for shuffle behavior

**Files:**
- Create: `tests/test_animator_shuffle.py`

- [ ] **Step 1: Write the failing test file**

```python
"""Tests for SubmissionAnimator phrase shuffle behavior."""
import asyncio
from unittest.mock import patch

from comate_cli.terminal_agent.animations import SubmissionAnimator


async def _start_and_stop(animator: SubmissionAnimator) -> None:
    """Helper: start animator, yield once, then stop."""
    await animator.start()
    await asyncio.sleep(0)
    await animator.stop()


def test_start_shuffles_phrases():
    """start() should shuffle the phrase order, not use the original sequence."""
    phrases = ["Alpha", "Bravo", "Charlie", "Delta", "Echo"]
    animator = SubmissionAnimator(phrases=phrases)

    # We run start() many times and collect the first phrase each time.
    # With shuffling, it's extremely unlikely to always be "Alpha".
    first_phrases: list[str] = []
    for _ in range(20):
        asyncio.run(_start_and_stop(animator))
        first_phrases.append(animator._shuffled[0])

    # At least one run should differ from the original first phrase.
    assert not all(p == "Alpha" for p in first_phrases), (
        f"All 20 runs started with 'Alpha' — shuffle is not working: {first_phrases}"
    )


def test_shuffled_contains_all_original_phrases():
    """Shuffled list must be a permutation — no loss, no duplication."""
    phrases = ["Alpha", "Bravo", "Charlie", "Delta", "Echo"]
    animator = SubmissionAnimator(phrases=phrases)

    asyncio.run(_start_and_stop(animator))

    assert sorted(animator._shuffled) == sorted(phrases)


def test_shuffled_is_tuple():
    """_shuffled must be immutable (tuple), not a mutable list."""
    phrases = ["Alpha", "Bravo"]
    animator = SubmissionAnimator(phrases=phrases)

    asyncio.run(_start_and_stop(animator))

    assert isinstance(animator._shuffled, tuple)


def test_random_shuffle_is_called_on_start():
    """Verify random.shuffle is called exactly once per start()."""
    phrases = ["Alpha", "Bravo", "Charlie"]
    animator = SubmissionAnimator(phrases=phrases)

    with patch("comate_cli.terminal_agent.animations.random.shuffle") as mock_shuffle:
        asyncio.run(_start_and_stop(animator))
        mock_shuffle.assert_called_once()


def test_each_start_reshuffles():
    """Multiple start/stop cycles should produce different orderings."""
    phrases = ["A", "B", "C", "D", "E", "F", "G", "H"]
    animator = SubmissionAnimator(phrases=phrases)

    orderings: list[tuple[str, ...]] = []
    for _ in range(10):
        asyncio.run(_start_and_stop(animator))
        orderings.append(animator._shuffled)

    unique = set(orderings)
    assert len(unique) > 1, (
        f"All 10 start() calls produced the same ordering — shuffle not re-running"
    )
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_animator_shuffle.py -v`
Expected: FAIL — `SubmissionAnimator` has no `_shuffled` attribute yet.

- [ ] **Step 3: Commit the failing test**

```bash
git add tests/test_animator_shuffle.py
git commit -m "test: add failing tests for phrase shuffle behavior"
```

---

### Task 2: Implement shuffle in SubmissionAnimator

**Files:**
- Modify: `comate_cli/terminal_agent/animations.py`

- [ ] **Step 1: Add `import random` at the top of the file**

In `animations.py` line 3 area (after existing imports), add:

```python
import random
```

- [ ] **Step 2: Add `_shuffled` field in `__init__`**

In `__init__`, after line 307 (`self._phrases = ...`), add:

```python
        self._shuffled: tuple[str, ...] = tuple(self._phrases)
```

- [ ] **Step 3: Shuffle on `start()`**

In `start()`, after line 336 (`self._phrase_duration_seconds = ...`), add:

```python
        shuffled = list(self._phrases)
        random.shuffle(shuffled)
        self._shuffled = tuple(shuffled)
```

- [ ] **Step 4: Read from `_shuffled` in `renderable()`**

Change line 380 from:

```python
        phrase = self._status_hint if self._status_hint else (self._phrases[self._phrase_idx] + "…")
```

to:

```python
        phrase = self._status_hint if self._status_hint else (self._shuffled[self._phrase_idx] + "…")
```

- [ ] **Step 5: Read from `_shuffled` in `_run()`**

Change line 395 from:

```python
                self._phrase_idx = (self._phrase_idx + 1) % len(self._phrases)
```

to:

```python
                self._phrase_idx = (self._phrase_idx + 1) % len(self._shuffled)
```

- [ ] **Step 6: Run tests to verify they pass**

Run: `python -m pytest tests/test_animator_shuffle.py -v`
Expected: All 5 tests PASS.

- [ ] **Step 7: Run full test suite to verify no regressions**

Run: `python -m pytest tests/ -v --timeout=30`
Expected: All existing tests still pass.

- [ ] **Step 8: Commit**

```bash
git add comate_cli/terminal_agent/animations.py
git commit -m "feat: shuffle status phrases randomly per message"
```
