# Phrase Shuffle Design

## Problem

`SubmissionAnimator` cycles through `DEFAULT_STATUS_PHRASES` in fixed order. Every time a user sends a message, the animation starts from index 0 ("Embellishing") and increments sequentially. This produces an identical phrase sequence for every message, making the loading animation feel repetitive.

**Root cause:** `_run()` uses `(self._phrase_idx + 1) % len(self._phrases)` and `start()` always resets `_phrase_idx = 0`.

## Solution

Shuffle the phrase list once per `start()` call using Fisher-Yates (`random.shuffle`). Each message gets an independent random ordering while maintaining the same no-repeat-within-cycle guarantee as before.

## Changes

### File: `comate_cli/terminal_agent/animations.py`

**1. Add `import random` at the top of the file.**

**2. `SubmissionAnimator.__init__` — add `_shuffled` field:**

```python
self._shuffled: tuple[str, ...] = tuple(self._phrases)
```

**3. `SubmissionAnimator.start` — shuffle on each activation:**

After setting `self._phrase_idx = 0`:

```python
shuffled = list(self._phrases)
random.shuffle(shuffled)
self._shuffled = tuple(shuffled)
```

**4. `SubmissionAnimator.renderable` — read from `_shuffled`:**

```python
# Before:
phrase = self._status_hint if self._status_hint else (self._phrases[self._phrase_idx] + "…")
# After:
phrase = self._status_hint if self._status_hint else (self._shuffled[self._phrase_idx] + "…")
```

### What stays unchanged

- `_run()` — `_phrase_idx` increment logic unchanged, now traverses shuffled list
- `_compute_phrase_duration()` — still deterministic per `_phrase_idx`
- `StreamAnimationController` — no changes
- `DEFAULT_STATUS_PHRASES` constant — no changes

## Testing

- Inject a small `phrases=["A", "B", "C"]` list
- Mock `random.shuffle` to verify it is called on `start()`
- Assert `start()` produces a `_shuffled` tuple containing all original elements (no loss, no duplication)
