# Conditional Diff Subtitle for Edit/MultiEdit

**Date**: 2026-04-01
**Status**: 完成

## Problem

When Edit or MultiEdit completes, the scrollback always shows:

```
⎿  Added 6 lines, removed 3 lines
```

Even when only lines were added or only removed, both words appear. This is verbose and less scannable.

## Solution

Make the subtitle conditionally show only the relevant parts:

| Scenario | Display |
|---|---|
| Only additions | `⎿  Added 6 lines` |
| Only removals | `⎿  Removed 3 lines` |
| Both | `⎿  Added 6 lines, removed 3 lines` |
| Neither (0 changes) | No subtitle |

## Changes

### File: `comate_cli/terminal_agent/event_renderer.py`

**Function**: `_build_tool_subtitle()` (lines 592-602)

Replace the fixed-format return with conditional logic:

```python
if lowered in ("edit", "multiedit"):
    if not metadata:
        return None
    diff_lines = metadata.get("diff")
    if not isinstance(diff_lines, list) or not diff_lines:
        return None
    added = sum(1 for line in diff_lines if line.startswith("+") and not line.startswith("+++"))
    removed = sum(1 for line in diff_lines if line.startswith("-") and not line.startswith("---"))

    parts = []
    if added:
        a_unit = "line" if added == 1 else "lines"
        parts.append(f"Added {added} {a_unit}")
    if removed:
        r_unit = "line" if removed == 1 else "lines"
        parts.append(f"Removed {removed} {r_unit}")
    if not parts:
        return None
    return ", ".join(parts)
```

### No other files need changes

The downstream consumers (`history_printer.py` `_render_subtitle_line()`, `render_history_group()`) already handle `None` subtitle (skip rendering) and arbitrary subtitle strings. No changes needed there.

## Testing

Update existing tests in `tests/test_event_renderer.py` that assert on Edit/MultiEdit subtitle output to cover all four scenarios (add-only, remove-only, both, neither).

## Scope

Single function, single file. No new dependencies, no UI framework changes.
