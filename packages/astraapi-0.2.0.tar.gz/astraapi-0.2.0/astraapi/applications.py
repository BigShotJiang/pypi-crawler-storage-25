from __future__ import annotations

import asyncio
import itertools
import re
import inspect
import threading
from collections.abc import Awaitable, Coroutine, Sequence
from enum import Enum
from typing import (
    TYPE_CHECKING,
    Annotated,
    Any,
    Callable,
    Optional,
    TypeVar,
    Union,
)

from annotated_doc import Doc
# Lightweight imports only — no pydantic triggering:
from astraapi.datastructures import Default, DefaultPlaceholder
from astraapi.exception_handlers import (
    http_exception_handler,
    request_validation_exception_handler,
    websocket_request_validation_exception_handler,
)
from astraapi.exceptions import RequestValidationError, WebSocketRequestValidationError
from astraapi.logger import logger
# openapi.docs, openapi.utils, routing, and params are imported lazily
# to avoid pulling in pydantic at module import time.
from astraapi._app_base import AppBase
from astraapi._datastructures_impl import State
from astraapi.exceptions import HTTPException
from astraapi._middleware_impl import Middleware
from astraapi._middleware_impl import BaseHTTPMiddleware
from astraapi._request import Request
from astraapi._response import HTMLResponse, JSONResponse, Response
from astraapi._routing_base import BaseRoute
from astraapi._types import Lifespan
from typing_extensions import deprecated

from astraapi._core_bridge import CoreApp, openapi_dict_to_json_bytes

if TYPE_CHECKING:
    from astraapi import routing
    from astraapi.params import Depends
    from astraapi.types import DecoratedCallable, IncEx


def _generate_unique_id(route: routing.APIRoute) -> str:
    """Inline copy of astraapi.utils.generate_unique_id to avoid importing pydantic."""
    operation_id = re.sub(r"\W", "_", f"{route.name}{route.path_format}")
    assert route.methods
    return f"{operation_id}_{list(route.methods)[0].lower()}"

AppType = TypeVar("AppType", bound="AstraAPI")

# Module-level constants for batch spec conversion (avoid dict recreation per call)
_BATCH_SPEC_LOC = {"query": 0, "header": 1, "cookie": 2, "path": 3}
_BATCH_SPEC_TYPE = {"": 0, "str": 0, "int": 1, "float": 2, "bool": 3}

# Serialises concurrent _sync_routes_to_core calls across all app instances.
# Prevents data races in C++ route registration (shared module-level state).
_global_sync_lock = threading.Lock()

# Monotonic counter for unique app instance IDs — used by TestClient to avoid
# server reuse when Python's memory allocator reuses object addresses (id()).
_app_instance_counter = itertools.count(1)


class AstraAPI(AppBase):
    """
    `AstraAPI` app class, the main entrypoint to use AstraAPI.

    Read more in the
    [AstraAPI docs for First Steps](https://astraapi.tiangolo.com/tutorial/first-steps/).

    ## Example

    ```python
    from astraapi import AstraAPI

    app = AstraAPI()
    ```
    """

    def __init__(
        self: AppType,
        *,
        debug: Annotated[
            bool,
            Doc(
                """
                Boolean indicating if debug tracebacks should be returned on server
                errors.

                Read more in the
                [Starlette docs for Applications](https://www.starlette.dev/applications/#instantiating-the-application).
                """
            ),
        ] = False,
        routes: Annotated[
            Optional[list[BaseRoute]],
            Doc(
                """
                **Note**: you probably shouldn't use this parameter, it is inherited
                from Starlette and supported for compatibility.

                ---

                A list of routes to serve incoming HTTP and WebSocket requests.
                """
            ),
            deprecated(
                """
                You normally wouldn't use this parameter with AstraAPI, it is inherited
                from Starlette and supported for compatibility.

                In AstraAPI, you normally would use the *path operation methods*,
                like `app.get()`, `app.post()`, etc.
                """
            ),
        ] = None,
        title: Annotated[
            str,
            Doc(
                """
                The title of the API.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more in the
                [AstraAPI docs for Metadata and Docs URLs](https://astraapi.tiangolo.com/tutorial/metadata/#metadata-for-api).

                **Example**

                ```python
                from astraapi import AstraAPI

                app = AstraAPI(title="ChimichangApp")
                ```
                """
            ),
        ] = "AstraAPI",
        summary: Annotated[
            Optional[str],
            Doc(
                """
                A short summary of the API.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more in the
                [AstraAPI docs for Metadata and Docs URLs](https://astraapi.tiangolo.com/tutorial/metadata/#metadata-for-api).

                **Example**

                ```python
                from astraapi import AstraAPI

                app = AstraAPI(summary="Deadpond's favorite app. Nuff said.")
                ```
                """
            ),
        ] = None,
        description: Annotated[
            str,
            Doc(
                '''
                A description of the API. Supports Markdown (using
                [CommonMark syntax](https://commonmark.org/)).

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more in the
                [AstraAPI docs for Metadata and Docs URLs](https://astraapi.tiangolo.com/tutorial/metadata/#metadata-for-api).

                **Example**

                ```python
                from astraapi import AstraAPI

                app = AstraAPI(
                    description="""
                                ChimichangApp API helps you do awesome stuff. 🚀

                                ## Items

                                You can **read items**.

                                ## Users

                                You will be able to:

                                * **Create users** (_not implemented_).
                                * **Read users** (_not implemented_).

                                """
                )
                ```
                '''
            ),
        ] = "",
        version: Annotated[
            str,
            Doc(
                """
                The version of the API.

                **Note** This is the version of your application, not the version of
                the OpenAPI specification nor the version of AstraAPI being used.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more in the
                [AstraAPI docs for Metadata and Docs URLs](https://astraapi.tiangolo.com/tutorial/metadata/#metadata-for-api).

                **Example**

                ```python
                from astraapi import AstraAPI

                app = AstraAPI(version="0.0.1")
                ```
                """
            ),
        ] = "0.1.0",
        openapi_url: Annotated[
            Optional[str],
            Doc(
                """
                The URL where the OpenAPI schema will be served from.

                If you set it to `None`, no OpenAPI schema will be served publicly, and
                the default automatic endpoints `/docs` and `/redoc` will also be
                disabled.

                Read more in the
                [AstraAPI docs for Metadata and Docs URLs](https://astraapi.tiangolo.com/tutorial/metadata/#openapi-url).

                **Example**

                ```python
                from astraapi import AstraAPI

                app = AstraAPI(openapi_url="/api/v1/openapi.json")
                ```
                """
            ),
        ] = "/openapi.json",
        openapi_tags: Annotated[
            Optional[list[dict[str, Any]]],
            Doc(
                """
                A list of tags used by OpenAPI, these are the same `tags` you can set
                in the *path operations*, like:

                * `@app.get("/users/", tags=["users"])`
                * `@app.get("/items/", tags=["items"])`

                The order of the tags can be used to specify the order shown in
                tools like Swagger UI, used in the automatic path `/docs`.

                It's not required to specify all the tags used.

                The tags that are not declared MAY be organized randomly or based
                on the tools' logic. Each tag name in the list MUST be unique.

                The value of each item is a `dict` containing:

                * `name`: The name of the tag.
                * `description`: A short description of the tag.
                    [CommonMark syntax](https://commonmark.org/) MAY be used for rich
                    text representation.
                * `externalDocs`: Additional external documentation for this tag. If
                    provided, it would contain a `dict` with:
                    * `description`: A short description of the target documentation.
                        [CommonMark syntax](https://commonmark.org/) MAY be used for
                        rich text representation.
                    * `url`: The URL for the target documentation. Value MUST be in
                        the form of a URL.

                Read more in the
                [AstraAPI docs for Metadata and Docs URLs](https://astraapi.tiangolo.com/tutorial/metadata/#metadata-for-tags).

                **Example**

                ```python
                from astraapi import AstraAPI

                tags_metadata = [
                    {
                        "name": "users",
                        "description": "Operations with users. The **login** logic is also here.",
                    },
                    {
                        "name": "items",
                        "description": "Manage items. So _fancy_ they have their own docs.",
                        "externalDocs": {
                            "description": "Items external docs",
                            "url": "https://astraapi.tiangolo.com/",
                        },
                    },
                ]

                app = AstraAPI(openapi_tags=tags_metadata)
                ```
                """
            ),
        ] = None,
        servers: Annotated[
            Optional[list[dict[str, Union[str, Any]]]],
            Doc(
                """
                A `list` of `dict`s with connectivity information to a target server.

                You would use it, for example, if your application is served from
                different domains and you want to use the same Swagger UI in the
                browser to interact with each of them (instead of having multiple
                browser tabs open). Or if you want to leave fixed the possible URLs.

                If the servers `list` is not provided, or is an empty `list`, the
                `servers` property in the generated OpenAPI will be:

                * a `dict` with a `url` value of the application's mounting point
                (`root_path`) if it's different from `/`.
                * otherwise, the `servers` property will be omitted from the OpenAPI
                schema.

                Each item in the `list` is a `dict` containing:

                * `url`: A URL to the target host. This URL supports Server Variables
                and MAY be relative, to indicate that the host location is relative
                to the location where the OpenAPI document is being served. Variable
                substitutions will be made when a variable is named in `{`brackets`}`.
                * `description`: An optional string describing the host designated by
                the URL. [CommonMark syntax](https://commonmark.org/) MAY be used for
                rich text representation.
                * `variables`: A `dict` between a variable name and its value. The value
                    is used for substitution in the server's URL template.

                Read more in the
                [AstraAPI docs for Behind a Proxy](https://astraapi.tiangolo.com/advanced/behind-a-proxy/#additional-servers).

                **Example**

                ```python
                from astraapi import AstraAPI

                app = AstraAPI(
                    servers=[
                        {"url": "https://stag.example.com", "description": "Staging environment"},
                        {"url": "https://prod.example.com", "description": "Production environment"},
                    ]
                )
                ```
                """
            ),
        ] = None,
        dependencies: Annotated[
            Optional[Sequence[Depends]],
            Doc(
                """
                A list of global dependencies, they will be applied to each
                *path operation*, including in sub-routers.

                Read more about it in the
                [AstraAPI docs for Global Dependencies](https://astraapi.tiangolo.com/tutorial/dependencies/global-dependencies/).

                **Example**

                ```python
                from astraapi import Depends, AstraAPI

                from .dependencies import func_dep_1, func_dep_2

                app = AstraAPI(dependencies=[Depends(func_dep_1), Depends(func_dep_2)])
                ```
                """
            ),
        ] = None,
        default_response_class: Annotated[
            type[Response],
            Doc(
                """
                The default response class to be used.

                Read more in the
                [AstraAPI docs for Custom Response - HTML, Stream, File, others](https://astraapi.tiangolo.com/advanced/custom-response/#default-response-class).

                **Example**

                ```python
                from astraapi import AstraAPI
                from astraapi.responses import ORJSONResponse

                app = AstraAPI(default_response_class=ORJSONResponse)
                ```
                """
            ),
        ] = Default(JSONResponse),
        redirect_slashes: Annotated[
            bool,
            Doc(
                """
                Whether to detect and redirect slashes in URLs when the client doesn't
                use the same format.

                **Example**

                ```python
                from astraapi import AstraAPI

                app = AstraAPI(redirect_slashes=True)  # the default

                @app.get("/items/")
                async def read_items():
                    return [{"item_id": "Foo"}]
                ```

                With this app, if a client goes to `/items` (without a trailing slash),
                they will be automatically redirected with an HTTP status code of 307
                to `/items/`.
                """
            ),
        ] = True,
        docs_url: Annotated[
            Optional[str],
            Doc(
                """
                The path to the automatic interactive API documentation.
                It is handled in the browser by Swagger UI.

                The default URL is `/docs`. You can disable it by setting it to `None`.

                If `openapi_url` is set to `None`, this will be automatically disabled.

                Read more in the
                [AstraAPI docs for Metadata and Docs URLs](https://astraapi.tiangolo.com/tutorial/metadata/#docs-urls).

                **Example**

                ```python
                from astraapi import AstraAPI

                app = AstraAPI(docs_url="/documentation", redoc_url=None)
                ```
                """
            ),
        ] = "/docs",
        redoc_url: Annotated[
            Optional[str],
            Doc(
                """
                The path to the alternative automatic interactive API documentation
                provided by ReDoc.

                The default URL is `/redoc`. You can disable it by setting it to `None`.

                If `openapi_url` is set to `None`, this will be automatically disabled.

                Read more in the
                [AstraAPI docs for Metadata and Docs URLs](https://astraapi.tiangolo.com/tutorial/metadata/#docs-urls).

                **Example**

                ```python
                from astraapi import AstraAPI

                app = AstraAPI(docs_url="/documentation", redoc_url="redocumentation")
                ```
                """
            ),
        ] = "/redoc",
        swagger_ui_oauth2_redirect_url: Annotated[
            Optional[str],
            Doc(
                """
                The OAuth2 redirect endpoint for the Swagger UI.

                By default it is `/docs/oauth2-redirect`.

                This is only used if you use OAuth2 (with the "Authorize" button)
                with Swagger UI.
                """
            ),
        ] = "/docs/oauth2-redirect",
        swagger_ui_init_oauth: Annotated[
            Optional[dict[str, Any]],
            Doc(
                """
                OAuth2 configuration for the Swagger UI, by default shown at `/docs`.

                Read more about the available configuration options in the
                [Swagger UI docs](https://swagger.io/docs/open-source-tools/swagger-ui/usage/oauth2/).
                """
            ),
        ] = None,
        middleware: Annotated[
            Optional[Sequence[Middleware]],
            Doc(
                """
                List of middleware to be added when creating the application.

                In AstraAPI you would normally do this with `app.add_middleware()`
                instead.

                Read more in the
                [AstraAPI docs for Middleware](https://astraapi.tiangolo.com/tutorial/middleware/).
                """
            ),
        ] = None,
        exception_handlers: Annotated[
            Optional[
                dict[
                    Union[int, type[Exception]],
                    Callable[[Request, Any], Coroutine[Any, Any, Response]],
                ]
            ],
            Doc(
                """
                A dictionary with handlers for exceptions.

                In AstraAPI, you would normally use the decorator
                `@app.exception_handler()`.

                Read more in the
                [AstraAPI docs for Handling Errors](https://astraapi.tiangolo.com/tutorial/handling-errors/).
                """
            ),
        ] = None,
        on_startup: Annotated[
            Optional[Sequence[Callable[[], Any]]],
            Doc(
                """
                A list of startup event handler functions.

                You should instead use the `lifespan` handlers.

                Read more in the [AstraAPI docs for `lifespan`](https://astraapi.tiangolo.com/advanced/events/).
                """
            ),
        ] = None,
        on_shutdown: Annotated[
            Optional[Sequence[Callable[[], Any]]],
            Doc(
                """
                A list of shutdown event handler functions.

                You should instead use the `lifespan` handlers.

                Read more in the
                [AstraAPI docs for `lifespan`](https://astraapi.tiangolo.com/advanced/events/).
                """
            ),
        ] = None,
        lifespan: Annotated[
            Optional[Lifespan[AppType]],
            Doc(
                """
                A `Lifespan` context manager handler. This replaces `startup` and
                `shutdown` functions with a single context manager.

                Read more in the
                [AstraAPI docs for `lifespan`](https://astraapi.tiangolo.com/advanced/events/).
                """
            ),
        ] = None,
        terms_of_service: Annotated[
            Optional[str],
            Doc(
                """
                A URL to the Terms of Service for your API.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more at the
                [AstraAPI docs for Metadata and Docs URLs](https://astraapi.tiangolo.com/tutorial/metadata/#metadata-for-api).

                **Example**

                ```python
                app = AstraAPI(terms_of_service="http://example.com/terms/")
                ```
                """
            ),
        ] = None,
        contact: Annotated[
            Optional[dict[str, Union[str, Any]]],
            Doc(
                """
                A dictionary with the contact information for the exposed API.

                It can contain several fields.

                * `name`: (`str`) The name of the contact person/organization.
                * `url`: (`str`) A URL pointing to the contact information. MUST be in
                    the format of a URL.
                * `email`: (`str`) The email address of the contact person/organization.
                    MUST be in the format of an email address.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more at the
                [AstraAPI docs for Metadata and Docs URLs](https://astraapi.tiangolo.com/tutorial/metadata/#metadata-for-api).

                **Example**

                ```python
                app = AstraAPI(
                    contact={
                        "name": "Deadpoolio the Amazing",
                        "url": "http://x-force.example.com/contact/",
                        "email": "dp@x-force.example.com",
                    }
                )
                ```
                """
            ),
        ] = None,
        license_info: Annotated[
            Optional[dict[str, Union[str, Any]]],
            Doc(
                """
                A dictionary with the license information for the exposed API.

                It can contain several fields.

                * `name`: (`str`) **REQUIRED** (if a `license_info` is set). The
                    license name used for the API.
                * `identifier`: (`str`) An [SPDX](https://spdx.dev/) license expression
                    for the API. The `identifier` field is mutually exclusive of the `url`
                    field. Available since OpenAPI 3.1.0, AstraAPI 0.99.0.
                * `url`: (`str`) A URL to the license used for the API. This MUST be
                    the format of a URL.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more at the
                [AstraAPI docs for Metadata and Docs URLs](https://astraapi.tiangolo.com/tutorial/metadata/#metadata-for-api).

                **Example**

                ```python
                app = AstraAPI(
                    license_info={
                        "name": "Apache 2.0",
                        "url": "https://www.apache.org/licenses/LICENSE-2.0.html",
                    }
                )
                ```
                """
            ),
        ] = None,
        openapi_prefix: Annotated[
            str,
            Doc(
                """
                A URL prefix for the OpenAPI URL.
                """
            ),
            deprecated(
                """
                "openapi_prefix" has been deprecated in favor of "root_path", which
                follows more closely the ASGI standard, is simpler, and more
                automatic.
                """
            ),
        ] = "",
        root_path: Annotated[
            str,
            Doc(
                """
                A path prefix handled by a proxy that is not seen by the application
                but is seen by external clients, which affects things like Swagger UI.

                Read more about it at the
                [AstraAPI docs for Behind a Proxy](https://astraapi.tiangolo.com/advanced/behind-a-proxy/).

                **Example**

                ```python
                from astraapi import AstraAPI

                app = AstraAPI(root_path="/api/v1")
                ```
                """
            ),
        ] = "",
        root_path_in_servers: Annotated[
            bool,
            Doc(
                """
                To disable automatically generating the URLs in the `servers` field
                in the autogenerated OpenAPI using the `root_path`.

                Read more about it in the
                [AstraAPI docs for Behind a Proxy](https://astraapi.tiangolo.com/advanced/behind-a-proxy/#disable-automatic-server-from-root-path).

                **Example**

                ```python
                from astraapi import AstraAPI

                app = AstraAPI(root_path_in_servers=False)
                ```
                """
            ),
        ] = True,
        responses: Annotated[
            Optional[dict[Union[int, str], dict[str, Any]]],
            Doc(
                """
                Additional responses to be shown in OpenAPI.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Additional Responses in OpenAPI](https://astraapi.tiangolo.com/advanced/additional-responses/).

                And in the
                [AstraAPI docs for Bigger Applications](https://astraapi.tiangolo.com/tutorial/bigger-applications/#include-an-apirouter-with-a-custom-prefix-tags-responses-and-dependencies).
                """
            ),
        ] = None,
        callbacks: Annotated[
            Optional[list[BaseRoute]],
            Doc(
                """
                OpenAPI callbacks that should apply to all *path operations*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for OpenAPI Callbacks](https://astraapi.tiangolo.com/advanced/openapi-callbacks/).
                """
            ),
        ] = None,
        webhooks: Annotated[
            Optional[routing.APIRouter],
            Doc(
                """
                Add OpenAPI webhooks. This is similar to `callbacks` but it doesn't
                depend on specific *path operations*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                **Note**: This is available since OpenAPI 3.1.0, AstraAPI 0.99.0.

                Read more about it in the
                [AstraAPI docs for OpenAPI Webhooks](https://astraapi.tiangolo.com/advanced/openapi-webhooks/).
                """
            ),
        ] = None,
        deprecated: Annotated[
            Optional[bool],
            Doc(
                """
                Mark all *path operations* as deprecated. You probably don't need it,
                but it's available.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/#deprecate-a-path-operation).
                """
            ),
        ] = None,
        include_in_schema: Annotated[
            bool,
            Doc(
                """
                To include (or not) all the *path operations* in the generated OpenAPI.
                You probably don't need it, but it's available.

                This affects the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Query Parameters and String Validations](https://astraapi.tiangolo.com/tutorial/query-params-str-validations/#exclude-parameters-from-openapi).
                """
            ),
        ] = True,
        swagger_ui_parameters: Annotated[
            Optional[dict[str, Any]],
            Doc(
                """
                Parameters to configure Swagger UI, the autogenerated interactive API
                documentation (by default at `/docs`).

                Read more about it in the
                [AstraAPI docs about how to Configure Swagger UI](https://astraapi.tiangolo.com/how-to/configure-swagger-ui/).
                """
            ),
        ] = None,
        generate_unique_id_function: Annotated[
            Callable[[routing.APIRoute], str],
            Doc(
                """
                Customize the function used to generate unique IDs for the *path
                operations* shown in the generated OpenAPI.

                This is particularly useful when automatically generating clients or
                SDKs for your API.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = Default(_generate_unique_id),
        separate_input_output_schemas: Annotated[
            bool,
            Doc(
                """
                Whether to generate separate OpenAPI schemas for request body and
                response body when the results would be more precise.

                This is particularly useful when automatically generating clients.

                For example, if you have a model like:

                ```python
                from pydantic import BaseModel

                class Item(BaseModel):
                    name: str
                    tags: list[str] = []
                ```

                When `Item` is used for input, a request body, `tags` is not required,
                the client doesn't have to provide it.

                But when using `Item` for output, for a response body, `tags` is always
                available because it has a default value, even if it's just an empty
                list. So, the client should be able to always expect it.

                In this case, there would be two different schemas, one for input and
                another one for output.

                Read more about it in the
                [AstraAPI docs about how to separate schemas for input and output](https://astraapi.tiangolo.com/how-to/separate-openapi-schemas)
                """
            ),
        ] = True,
        openapi_external_docs: Annotated[
            Optional[dict[str, Any]],
            Doc(
                """
                This field allows you to provide additional external documentation links.
                If provided, it must be a dictionary containing:

                * `description`: A brief description of the external documentation.
                * `url`: The URL pointing to the external documentation. The value **MUST**
                be a valid URL format.

                **Example**:

                ```python
                from astraapi import AstraAPI

                external_docs = {
                    "description": "Detailed API Reference",
                    "url": "https://example.com/api-docs",
                }

                app = AstraAPI(openapi_external_docs=external_docs)
                ```
                """
            ),
        ] = None,
        **extra: Annotated[
            Any,
            Doc(
                """
                Extra keyword arguments to be stored in the app, not used by AstraAPI
                anywhere.
                """
            ),
        ],
    ) -> None:
        self.debug = debug
        self.title = title
        self.summary = summary
        self.description = description
        self.version = version
        self.terms_of_service = terms_of_service
        self.contact = contact
        self.license_info = license_info
        # Auto-enable OpenAPI schema if user requested any docs endpoint
        if openapi_url is None and (docs_url is not None or redoc_url is not None):
            openapi_url = "/openapi.json"
        self.openapi_url = openapi_url
        self.openapi_tags = openapi_tags
        self.root_path_in_servers = root_path_in_servers
        self.docs_url = docs_url
        self.redoc_url = redoc_url
        self.swagger_ui_oauth2_redirect_url = swagger_ui_oauth2_redirect_url
        self.swagger_ui_init_oauth = swagger_ui_init_oauth
        self.swagger_ui_parameters = swagger_ui_parameters
        self.servers = servers or []
        self.separate_input_output_schemas = separate_input_output_schemas
        self.openapi_external_docs = openapi_external_docs
        self.extra = extra
        self.openapi_version: Annotated[
            str,
            Doc(
                """
                The version string of OpenAPI.

                AstraAPI will generate OpenAPI version 3.1.0, and will output that as
                the OpenAPI version. But some tools, even though they might be
                compatible with OpenAPI 3.1.0, might not recognize it as a valid.

                So you could override this value to trick those tools into using
                the generated OpenAPI. Have in mind that this is a hack. But if you
                avoid using features added in OpenAPI 3.1.0, it might work for your
                use case.

                This is not passed as a parameter to the `AstraAPI` class to avoid
                giving the false idea that AstraAPI would generate a different OpenAPI
                schema. It is only available as an attribute.

                **Example**

                ```python
                from astraapi import AstraAPI

                app = AstraAPI()

                app.openapi_version = "3.0.2"
                ```
                """
            ),
        ] = "3.1.0"
        self.openapi_schema: Optional[dict[str, Any]] = None
        self._openapi_bytes: Optional[bytes] = None
        if self.openapi_url:
            assert self.title, "A title must be provided for OpenAPI, e.g.: 'My API'"
            assert self.version, "A version must be provided for OpenAPI, e.g.: '2.1.0'"
        # TODO: remove when discarding the openapi_prefix parameter
        if openapi_prefix:
            logger.warning(
                '"openapi_prefix" has been deprecated in favor of "root_path", which '
                "follows more closely the ASGI standard, is simpler, and more "
                "automatic. Check the docs at "
                "https://astraapi.tiangolo.com/advanced/sub-applications/"
            )
        self.root_path = root_path or openapi_prefix
        self.state: Annotated[
            State,
            Doc(
                """
                A state object for the application. This is the same object for the
                entire application, it doesn't change from request to request.

                You normally wouldn't use this in AstraAPI, for most of the cases you
                would instead use AstraAPI dependencies.

                This is simply inherited from Starlette.

                Read more about it in the
                [Starlette docs for Applications](https://www.starlette.dev/applications/#storing-state-on-the-app-instance).
                """
            ),
        ] = State()
        self.dependency_overrides: Annotated[
            dict[Callable[..., Any], Callable[..., Any]],
            Doc(
                """
                A dictionary with overrides for the dependencies.

                Each key is the original dependency callable, and the value is the
                actual dependency that should be called.

                This is for testing, to replace expensive dependencies with testing
                versions.

                Read more about it in the
                [AstraAPI docs for Testing Dependencies with Overrides](https://astraapi.tiangolo.com/advanced/testing-dependencies/).
                """
            ),
        ] = {}

        # ── Lazy router: defer routing + pydantic import to first access ──
        self._router_params = dict(
            routes=routes,
            redirect_slashes=redirect_slashes,
            dependency_overrides_provider=self,
            on_startup=on_startup,
            on_shutdown=on_shutdown,
            lifespan=lifespan,
            default_response_class=default_response_class,
            dependencies=dependencies,
            callbacks=callbacks,
            deprecated=deprecated,
            include_in_schema=include_in_schema,
            responses=responses,
            generate_unique_id_function=generate_unique_id_function,
        )
        self._webhooks_arg = webhooks
        self._router = None
        self._webhooks = None
        self._setup_done = False

        self.exception_handlers: dict[
            Any, Callable[[Request, Any], Union[Response, Awaitable[Response]]]
        ] = {} if exception_handlers is None else dict(exception_handlers)
        self.exception_handlers.setdefault(HTTPException, http_exception_handler)
        self.exception_handlers.setdefault(
            RequestValidationError, request_validation_exception_handler
        )
        self.exception_handlers.setdefault(
            WebSocketRequestValidationError,
            websocket_request_validation_exception_handler,  # type: ignore
        )

        self.user_middleware: list[Middleware] = (
            [] if middleware is None else list(middleware)
        )
        # ── v2.0: Initialize C++ core ─────────────────────────────────────
        self._core_app = CoreApp()
        self._core_app.redirect_slashes = bool(redirect_slashes)
        self._routes_synced: bool = False
        # Unique ID for this app instance — prevents TestClient server reuse
        # when id(app) gets recycled by Python's allocator.
        self._app_instance_id = next(_app_instance_counter)

    # ── Lazy router + webhooks properties ─────────────────────────────────
    # Defers `from astraapi import routing` (and thus pydantic) until the
    # first time the router is actually accessed (e.g. @app.get()).

    @property
    def router(self) -> routing.APIRouter:
        if self._router is None:
            from astraapi import routing as _routing
            self._webhooks = self._webhooks_arg or _routing.APIRouter()
            self._webhooks_arg = None
            self._router = _routing.APIRouter(**self._router_params)
            self._router_params = None  # free memory
            if not self._setup_done:
                self.setup()
                self._setup_done = True
        return self._router

    @router.setter
    def router(self, value: routing.APIRouter) -> None:
        self._router = value

    @property
    def webhooks(self) -> routing.APIRouter:
        if self._router is None:
            _ = self.router  # trigger lazy init
        return self._webhooks

    @webhooks.setter
    def webhooks(self, value: routing.APIRouter) -> None:
        self._webhooks = value

    def openapi(self) -> dict[str, Any]:
        """
        Generate the OpenAPI schema of the application. This is called by AstraAPI
        internally.

        The first time it is called it stores the result in the attribute
        `app.openapi_schema`, and next times it is called, it just returns that same
        result. To avoid the cost of generating the schema every time.

        If you need to modify the generated OpenAPI schema, you could modify it.

        Read more in the
        [AstraAPI docs for OpenAPI](https://astraapi.tiangolo.com/how-to/extending-openapi/).
        """
        if not self.openapi_schema:
            from astraapi.openapi.utils import get_openapi
            self.openapi_schema = get_openapi(
                title=self.title,
                version=self.version,
                openapi_version=self.openapi_version,
                summary=self.summary,
                description=self.description,
                terms_of_service=self.terms_of_service,
                contact=self.contact,
                license_info=self.license_info,
                routes=self.routes,
                webhooks=self.webhooks.routes,
                tags=self.openapi_tags,
                servers=self.servers,
                separate_input_output_schemas=self.separate_input_output_schemas,
                external_docs=self.openapi_external_docs,
            )
            # Serialize to JSON bytes in C++ core.
            # Cached so /openapi.json serves pre-built bytes directly.
            self._openapi_bytes = openapi_dict_to_json_bytes(self.openapi_schema)
        return self.openapi_schema

    def setup(self) -> None:
        from astraapi.openapi.docs import (
            get_redoc_html,
            get_swagger_ui_html,
            get_swagger_ui_oauth2_redirect_html,
        )
        if self.openapi_url:
            urls = (server_data.get("url") for server_data in self.servers)
            server_urls = {url for url in urls if url}
            # OPT: No Request param - read root_path from _server_root_path module var.
            # Prevents internal docs routes from forcing _needs_request_context=True
            # on ALL requests (adds 3-4us Python header parse per request).
            _app_ref = self

            async def openapi(request: Request = None) -> Response:
                from astraapi._cpp_server import _server_root_path, _current_root_path
                # ASGI path passes request; C++ fast path passes nothing
                _rp = (request.scope.get("root_path", "") if request else None)
                root_path = (_rp or _current_root_path.get() or _server_root_path).rstrip("/")
                if root_path not in server_urls:
                    if root_path and _app_ref.root_path_in_servers:
                        _app_ref.servers.insert(0, {"url": root_path})
                        server_urls.add(root_path)
                        _app_ref.openapi_schema = None
                        _app_ref._openapi_bytes = None
                _app_ref.openapi()
                return Response(
                    content=_app_ref._openapi_bytes,
                    media_type="application/json",
                )

            self.add_route(self.openapi_url, openapi, include_in_schema=False)
        if self.openapi_url and self.docs_url:

            async def swagger_ui_html(request: Request = None) -> HTMLResponse:
                from astraapi._cpp_server import _server_root_path, _current_root_path
                _rp = (request.scope.get("root_path", "") if request else None)
                root_path = (_rp or _current_root_path.get() or _server_root_path).rstrip("/")
                openapi_url = root_path + _app_ref.openapi_url
                oauth2_redirect_url = _app_ref.swagger_ui_oauth2_redirect_url
                if oauth2_redirect_url:
                    oauth2_redirect_url = root_path + oauth2_redirect_url
                return get_swagger_ui_html(
                    openapi_url=openapi_url,
                    title=f"{_app_ref.title} - Swagger UI",
                    oauth2_redirect_url=oauth2_redirect_url,
                    init_oauth=_app_ref.swagger_ui_init_oauth,
                    swagger_ui_parameters=_app_ref.swagger_ui_parameters,
                )

            self.add_route(self.docs_url, swagger_ui_html, include_in_schema=False)

            if self.swagger_ui_oauth2_redirect_url:

                async def swagger_ui_redirect() -> HTMLResponse:
                    return get_swagger_ui_oauth2_redirect_html()

                self.add_route(
                    self.swagger_ui_oauth2_redirect_url,
                    swagger_ui_redirect,
                    include_in_schema=False,
                )
        if self.openapi_url and self.redoc_url:

            async def redoc_html(request: Request = None) -> HTMLResponse:
                from astraapi._cpp_server import _server_root_path, _current_root_path
                _rp = (request.scope.get("root_path", "") if request else None)
                root_path = (_rp or _current_root_path.get() or _server_root_path).rstrip("/")
                openapi_url = root_path + _app_ref.openapi_url
                return get_redoc_html(
                    openapi_url=openapi_url, title=f"{_app_ref.title} - ReDoc"
                )

            self.add_route(self.redoc_url, redoc_html, include_in_schema=False)
    @staticmethod
    def _convert_batch_specs(
        batch_specs: list[tuple],
    ) -> list[dict]:
        """Convert routing.py batch_specs tuples to C++ register_fast_spec dicts.

        Tuple format: (location, alias, type_tag, field_name, is_seq, is_json,
                       convert_underscores, required, default_value)
        Dict format: {field_name, alias, header_lookup_key, location, type_tag,
                      required, default_value}
        """
        result = []
        for spec in batch_specs:
            loc_str, alias, tag_str, field_name = spec[0], spec[1], spec[2], spec[3]
            # Extended tuple (9 elements) now carries required + default_value
            is_required = spec[7] if len(spec) > 7 else False
            default_value = spec[8] if len(spec) > 8 else None
            # For headers, the lookup key is lowercase with - replaced by _
            # unless convert_underscores=False, in which case keep as-is
            convert_underscores = spec[6] if len(spec) > 6 else True
            if loc_str == "header":
                # Use alias for header lookup (alias is the actual header name to look for)
                lookup = alias if alias else field_name
                header_key = lookup.lower().replace("-", "_") if convert_underscores else lookup.lower()
            else:
                header_key = ""
            is_sequence = spec[4] if len(spec) > 4 else False
            seq_underscore_only = spec[9] if len(spec) > 9 else False
            result.append({
                "field_name": field_name,
                "alias": alias,
                "header_lookup_key": header_key,
                "location": _BATCH_SPEC_LOC.get(loc_str, 0),
                "type_tag": _BATCH_SPEC_TYPE.get(tag_str, 0),
                "required": is_required,
                "default_value": default_value,
                "convert_underscores": convert_underscores,
                "is_sequence": is_sequence,
                "seq_underscore_only": seq_underscore_only,
            })
        return result

    @staticmethod
    def _make_response_model_shim(route: Any) -> Callable[..., Any]:
        """Wrap a fast-path endpoint to apply response model serialization."""
        original_endpoint = route.endpoint
        response_field = route.response_field
        response_model_include = route.response_model_include
        response_model_exclude = route.response_model_exclude
        response_model_by_alias = route.response_model_by_alias
        response_model_exclude_unset = route.response_model_exclude_unset
        response_model_exclude_defaults = route.response_model_exclude_defaults
        response_model_exclude_none = route.response_model_exclude_none
        _is_async = inspect.iscoroutinefunction(original_endpoint) or inspect.iscoroutinefunction(inspect.unwrap(original_endpoint))

        async def _response_model_shim(**kwargs: Any) -> Any:
            if _is_async:
                raw = await original_endpoint(**kwargs)
            else:
                raw = original_endpoint(**kwargs)
            from astraapi._response import Response as _Response
            if isinstance(raw, _Response):
                return raw
            value, errors = response_field.validate(raw, {}, loc=("response",))
            if errors:
                from astraapi.exceptions import ResponseValidationError
                exc = ResponseValidationError(errors=errors, body=raw)
                # Store for re-raise in TestClient._check_exc
                try:
                    from astraapi._cpp_server import _set_last_server_exception
                    _set_last_server_exception(exc)
                except Exception:
                    pass
                raise exc
            return response_field.serialize(
                value,
                include=response_model_include,
                exclude=response_model_exclude,
                by_alias=response_model_by_alias,
                exclude_unset=response_model_exclude_unset,
                exclude_defaults=response_model_exclude_defaults,
                exclude_none=response_model_exclude_none,
            )

        _response_model_shim.__name__ = getattr(original_endpoint, "__name__", "_response_model_shim")
        return _response_model_shim

    @staticmethod
    def _make_param_validation_shim(route: Any) -> Callable[..., Any]:
        """Wrap a fast-path endpoint to validate/coerce path and query params."""
        original_endpoint = route.endpoint
        _is_async = inspect.iscoroutinefunction(original_endpoint)
        # Use _make_param_validator which handles model-based params correctly
        try:
            from astraapi.routing import _make_param_validator as _mpv
            _flat = getattr(route, '_flat_dependant', None) or route.dependant
            _validator = _mpv(_flat)
        except Exception:
            _validator = None
        if _validator is None:
            return original_endpoint

        _exc_handlers = getattr(route, '_app_exception_handlers', None)

        async def _param_shim(**kwargs: Any) -> Any:
            _result = _validator(kwargs)
            _values, _errors = _result[0], _result[1]
            _consumed = _result[2] if len(_result) > 2 else set()
            if _errors:
                from astraapi.exceptions import RequestValidationError
                # Extract body from kwargs for exc.body
                _body = None
                try:
                    _flat2 = getattr(route, '_flat_dependant', None) or route.dependant
                    _bp = _flat2.body_params
                    if _bp:
                        _bname = _bp[0].name
                        _body = kwargs.get(_bname)
                        if _body is None and len(_bp) > 1:
                            _body = {p.name: kwargs.get(p.name) for p in _bp if p.name in kwargs}
                except Exception:
                    pass
                _rve = RequestValidationError(_errors, body=_body)
                if _exc_handlers:
                    for _exc_cls, _exc_handler in _exc_handlers.items():
                        if isinstance(_rve, _exc_cls):
                            from astraapi.routing import _make_lightweight_request as _mlr
                            _req = _mlr(None, 'GET', '/', route)
                            import inspect as _insp
                            _hr = _exc_handler(_req, _rve)
                            if _insp.isawaitable(_hr):
                                _hr = await _hr
                            return _hr
                raise _rve
            # Remove raw individual fields consumed by model assembly
            for _k in _consumed:
                kwargs.pop(_k, None)
            # Update with validated/coerced values
            kwargs.update(_values)
            try:
                if _is_async:
                    return await original_endpoint(**kwargs)
                return original_endpoint(**kwargs)
            except Exception as _exc:
                if _exc_handlers:
                    for _exc_cls, _exc_handler in _exc_handlers.items():
                        if isinstance(_exc, _exc_cls):
                            from astraapi.routing import _make_lightweight_request as _mlr
                            _req = _mlr(None, 'GET', '/', route)
                            import inspect as _insp
                            _hr = _exc_handler(_req, _exc)
                            if _insp.isawaitable(_hr):
                                _hr = await _hr
                            return _hr
                raise

        _param_shim.__name__ = getattr(original_endpoint, '__name__', '_param_shim')
        return _param_shim

    @staticmethod
    def _make_asgi_route_shim(route: Any) -> Callable[..., Any]:
        """Shim for custom APIRoute subclasses: calls route.app (ASGI) and returns Response."""
        _asgi_app = route.app

        async def _asgi_shim(**kwargs: Any) -> Any:
            from astraapi._cpp_server import (
                _current_raw_headers as _crh, _current_method as _cm,
                _current_path as _cp, _current_query_string as _cqs,
            )
            from astraapi.routing import _make_lightweight_request
            _raw_headers = kwargs.pop('__raw_headers__', None) or _crh.get() or []
            _method = kwargs.pop('__method__', None) or _cm.get() or 'GET'
            _path = kwargs.pop('__path__', None) or _cp.get() or '/'
            # Prefer __body__ injected by C++ dep_solver path (avoids ContextVar race)
            _body = kwargs.pop('__body__', None)
            if _body is None:
                from astraapi._cpp_server import _current_body as _cb
                _body = _cb.get() if hasattr(_cb, 'get') else b''

            kwargs.pop('__auth_scheme__', None); kwargs.pop('__auth_credentials__', None)
            kwargs.pop('__content_type__', None); kwargs.pop('__deps_ran__', None)
            _qs = _cqs.get() if hasattr(_cqs, 'get') else b''
            _app_ref = getattr(route, 'dependency_overrides_provider', None)
            _req = _make_lightweight_request(_raw_headers, _method, _path, app=_app_ref, _shim_route=route)
            # Patch body into scope so request.body() works
            _req.scope['_body'] = _body or b''
            _req.scope['query_string'] = _qs if isinstance(_qs, bytes) else (_qs.encode() if _qs else b'')
            # Add required AsyncExitStack entries to scope
            from contextlib import AsyncExitStack as _AES
            _req.scope['astraapi_middleware_astack'] = _AES()
            _req.scope['astraapi_inner_astack'] = _AES()
            _req.scope['astraapi_function_astack'] = _AES()
            # Build receive callable
            _body_sent = False
            async def _receive():
                nonlocal _body_sent
                if not _body_sent:
                    _body_sent = True
                    return {'type': 'http.request', 'body': _body or b'', 'more_body': False}
                return {'type': 'http.disconnect'}
            # Collect ASGI response
            _resp_status = [200]
            _resp_headers = [[]]
            _resp_body = [b'']
            async def _send(msg):
                if msg['type'] == 'http.response.start':
                    _resp_status[0] = msg.get('status', 200)
                    _resp_headers[0] = list(msg.get('headers', []))
                elif msg['type'] == 'http.response.body':
                    _resp_body[0] += msg.get('body', b'')
            try:
                await _asgi_app(_req.scope, _receive, _send)
            except Exception as _exc:
                from astraapi.exceptions import HTTPException as _HTTPExc
                from astraapi._response import JSONResponse as _JR
                if isinstance(_exc, _HTTPExc):
                    _det = _exc.detail
                    _hdrs = getattr(_exc, 'headers', None) or {}
                    _er = _JR({'detail': _det}, status_code=_exc.status_code)
                    for _k, _v in _hdrs.items():
                        _er.headers[_k] = _v
                    return _er
                raise
            from astraapi._response import Response as _Resp
            _r = _Resp(content=_resp_body[0], status_code=_resp_status[0])
            for _hn, _hv in _resp_headers[0]:
                _hn_s = _hn.decode('latin-1') if isinstance(_hn, bytes) else _hn
                _hv_s = _hv.decode('latin-1') if isinstance(_hv, bytes) else _hv
                if _hn_s.lower() not in ('content-length',):
                    _r.headers[_hn_s] = _hv_s
            return _r

        return _asgi_shim

    @staticmethod
    def _make_response_class_shim(route: Any) -> Callable[..., Any]:
        """Create an async endpoint shim that wraps the result in the route's response_class.

        For non-fast-path routes (e.g. response_class=HTMLResponse), C++ calls the
        endpoint directly and then tries to serialize the result as JSON. This shim
        intercepts the return value and wraps it in the correct response class so
        C++ receives an actual Response object and uses the raw_headers path.

        Handles special cases:
        - RedirectResponse: passes URL as positional arg not content=
        - StreamingResponse: collects iterator into bytes
        - FileResponse: reads file into bytes
        - Other Response subclasses: checks isinstance before re-wrapping
        """
        from astraapi.routing import DefaultPlaceholder
        from astraapi._response import (
            Response as _Response,
            StreamingResponse as _StreamingResponse,
            FileResponse as _FileResponse,
            RedirectResponse as _RedirectResponse,
        )

        original_endpoint = route.endpoint
        _response_field = getattr(route, "response_field", None)
        _rm_include = getattr(route, "response_model_include", None)
        _rm_exclude = getattr(route, "response_model_exclude", None)
        _rm_by_alias = getattr(route, "response_model_by_alias", True)
        _rm_exclude_unset = getattr(route, "response_model_exclude_unset", False)
        _rm_exclude_defaults = getattr(route, "response_model_exclude_defaults", False)
        _rm_exclude_none = getattr(route, "response_model_exclude_none", False)
        _is_async = inspect.iscoroutinefunction(original_endpoint)

        rc = route.response_class
        if isinstance(rc, DefaultPlaceholder):
            rc = rc.value
        actual_rc = rc  # the response class to wrap with
        status_code = route.status_code or 200

        _is_redirect = isinstance(actual_rc, type) and issubclass(actual_rc, _RedirectResponse)

        # BackgroundTasks support: inject a fresh instance if the endpoint declares it,
        # then fire-and-forget the tasks after the response is returned to C++ for writing.
        _bg_param = getattr(getattr(route, 'dependant', None), 'background_tasks_param_name', None)
        _dep_solver = getattr(route, '_dep_solver', None)

        _req_param = getattr(getattr(route, 'dependant', None), 'request_param_name', None)
        _http_conn_param = getattr(getattr(route, 'dependant', None), 'http_connection_param_name', None)
        if _req_param or _http_conn_param:
            import astraapi._cpp_server as _s; _s._needs_request_context = True
        _resp_param_name = getattr(getattr(route, 'dependant', None), 'response_param_name', None)

        # Collect response_param_names from all deps (for __deps_ran__ path)
        _dep_resp_param_names: set = set()
        _dep_for_resp = getattr(route, 'dependant', None)
        if _dep_for_resp:
            def _collect_resp_params(d):
                for sub in getattr(d, 'dependencies', []):
                    if sub.call is not None:
                        rp = getattr(sub, 'response_param_name', None)
                        if rp:
                            _dep_resp_param_names.add(rp)
                        _collect_resp_params(sub)
            _collect_resp_params(_dep_for_resp)

        # Pre-compute path param coercions for _response_shim
        _path_coercions = {}
        for _pp in getattr(getattr(route, 'dependant', None), 'path_params', []):
            _pt = getattr(_pp, 'type_', None) or getattr(_pp, 'annotation', None)
            if _pt is not None and _pt is not str:
                _path_coercions[_pp.name] = _pt

        # Pre-build param validator for Pydantic model params (header/query/cookie)
        _param_validator_shim = None
        try:
            from astraapi.routing import _make_param_validator as _mpv
            from pydantic import BaseModel as _BM
            from astraapi._compat import lenient_issubclass as _lis
            _dep = getattr(route, 'dependant', None)
            if _dep and any(
                _lis(f.type_, _BM)
                for f in list(getattr(_dep, 'header_params', []))
                + list(getattr(_dep, 'query_params', []))
                + list(getattr(_dep, 'cookie_params', []))
            ):
                _flat = getattr(route, '_flat_dependant', None) or _dep
                _param_validator_shim = _mpv(_flat)
        except Exception:
            pass

        # Body params for non-fast-path routes (aliases or GET+body need Python-side parsing)
        _dep_for_body = getattr(route, 'dependant', None)
        _has_alias_body = (
            _dep_for_body and _dep_for_body.body_params
            and not getattr(route, '_fast_path_eligible', True)
            and any(
                (getattr(f.field_info, 'alias', None) not in (None, f.name))
                or (getattr(f.field_info, 'validation_alias', None) not in (None, f.name))
                for f in _dep_for_body.body_params
            )
        )
        # Also set for GET+body routes (C++ doesn't parse body for GET)
        _is_get_with_body = (
            _dep_for_body and _dep_for_body.body_params
            and route.methods and not any(m in ('POST', 'PUT', 'PATCH', 'DELETE') for m in route.methods)
        )
        _body_params_shim = _dep_for_body.body_params if (_has_alias_body or _is_get_with_body) else None
        _embed_body_shim = getattr(route, '_embed_body_fields', False)

        async def _response_shim(**kwargs: Any) -> Any:
            # Validate/assemble Pydantic model params (header/query/cookie)
            if _param_validator_shim is not None:
                _pv_result = _param_validator_shim(kwargs)
                _pv_values, _pv_errors = _pv_result[0], _pv_result[1]
                _pv_consumed = _pv_result[2] if len(_pv_result) > 2 else set()
                if _pv_errors:
                    from astraapi.responses import JSONResponse
                    return JSONResponse({"detail": _pv_errors}, status_code=422)
                for _k in _pv_consumed:
                    kwargs.pop(_k, None)
                kwargs.update(_pv_values)
            # Coerce path params (C++ passes them as strings)
            for _pname, _ptype in _path_coercions.items():
                if _pname in kwargs and isinstance(kwargs[_pname], str):
                    try: kwargs[_pname] = _ptype(kwargs[_pname])
                    except (ValueError, TypeError): pass
            _bg = None
            if _bg_param:
                from astraapi.background import BackgroundTasks as _BackgroundTasks
                _bg = _BackgroundTasks()
                kwargs[_bg_param] = _bg
            # Inject Request/HTTPConnection if endpoint needs it
            if _req_param or _http_conn_param:
                from astraapi.routing import _make_lightweight_request
                from astraapi._cpp_server import _current_raw_headers as _crh, _current_method as _cm, _current_path as _cp
                _rh = kwargs.pop('__raw_headers__', None) or _crh.get()
                _meth = kwargs.pop('__method__', None) or _cm.get() or 'GET'
                _pth = kwargs.pop('__path__', None) or _cp.get() or '/'
                _app_ref = getattr(route, 'dependency_overrides_provider', None)
                _req_obj = _make_lightweight_request(_rh, _meth, _pth, app=_app_ref, _shim_route=route)
                if _req_param:
                    kwargs[_req_param] = _req_obj
                if _http_conn_param:
                    kwargs[_http_conn_param] = _req_obj
            else:
                pass  # dep solver will pop __raw_headers__ etc. if needed
            # Inject Response if endpoint needs it
            _sub_resp = None
            if _resp_param_name:
                from astraapi._response import Response as _Resp
                _sub_resp = _Resp()
                kwargs[_resp_param_name] = _sub_resp
            # Collect sub_response from C++ dep_solver result (headers set by deps)
            _cpp_sub_resp = kwargs.pop('__sub_response__', None)
            if _cpp_sub_resp is not None:
                if _sub_resp is None:
                    _sub_resp = _cpp_sub_resp
                else:
                    for _k, _v in _cpp_sub_resp.headers.items():
                        _sub_resp.headers[_k] = _v
            # Collect Response objects injected by deps (when C++ already ran dep_solver)
            if _dep_resp_param_names:
                from astraapi._response import Response as _Resp
                for _drp in _dep_resp_param_names:
                    _dep_resp_obj = kwargs.get(_drp)
                    if isinstance(_dep_resp_obj, _Resp):
                        if _sub_resp is None:
                            _sub_resp = _dep_resp_obj
                        else:
                            for _k, _v in _dep_resp_obj.headers.items():
                                _sub_resp.headers[_k] = _v
                        # Don't pop — endpoint may need it as a parameter
            kwargs.pop('__auth_scheme__', None)
            kwargs.pop('__auth_credentials__', None)
            # Run dep solver for sub-deps (e.g. deps needing BackgroundTasks)
            # Skip if C++ dep engine already ran deps (indicated by __bg_tasks__ in kwargs)
            _shim_bg_tasks = _bg  # may be None if endpoint has no bg param
            _cpp_bg = kwargs.pop('__bg_tasks__', None)  # C++ dep engine result
            _deps_ran = kwargs.pop('__deps_ran__', False)  # C++ already ran dep_solver
            if _deps_ran and _dep_solver is not None:
                # C++ dep engine already ran; merge bg_tasks if present
                _cpp_bg2 = _cpp_bg  # already popped above
                if _cpp_bg2 is not None:
                    if _shim_bg_tasks is None:
                        _shim_bg_tasks = _cpp_bg2
                        if _bg_param: kwargs[_bg_param] = _shim_bg_tasks
                    else:
                        _shim_bg_tasks.tasks.extend(_cpp_bg2.tasks)
            elif _cpp_bg is not None:
                # C++ already ran deps; merge its bg tasks into _shim_bg_tasks
                if _shim_bg_tasks is None:
                    _shim_bg_tasks = _cpp_bg
                    if _bg_param:
                        kwargs[_bg_param] = _shim_bg_tasks
                else:
                    _shim_bg_tasks.tasks.extend(_cpp_bg.tasks)
            elif _dep_solver is not None and not kwargs.get('__gen_deps_ran__'):
                import inspect as _inspect
                # Share endpoint's BackgroundTasks with deps
                if _shim_bg_tasks is not None and '__bg_tasks__' not in kwargs:
                    kwargs['__bg_tasks__'] = _shim_bg_tasks
                _dep_coro = _dep_solver(kwargs)
                _dep_result = (await _dep_coro) if _inspect.isawaitable(_dep_coro) else _dep_coro
                if isinstance(_dep_result, tuple) and len(_dep_result) >= 2:
                    _dep_injected, _dep_errors = _dep_result[0], _dep_result[1]
                    if _dep_errors:
                        from astraapi._response import JSONResponse as _JR
                        return _JR({"detail": list(_dep_errors)}, status_code=422)
                    if _dep_injected:
                        kwargs.update(_dep_injected)
                    kwargs.pop('__bg_tasks__', None)  # internal key, not an endpoint param
                    # Merge bg_tasks from deps
                    _dep_bg = _dep_result[2] if len(_dep_result) > 2 else None
                    if _dep_bg is not None:
                        if _shim_bg_tasks is None:
                            _shim_bg_tasks = _dep_bg
                            if _bg_param:
                                kwargs[_bg_param] = _shim_bg_tasks
                        else:
                            _shim_bg_tasks.tasks.extend(_dep_bg.tasks)
                    # Merge sub_response headers
                    _dep_sub_resp = _dep_result[3] if len(_dep_result) > 3 else None
                    if _dep_sub_resp is not None and _sub_resp is None:
                        _sub_resp = _dep_sub_resp
                    elif _dep_sub_resp is not None and _sub_resp is not None:
                        for _dk, _dv in _dep_sub_resp.headers.items():
                            _sub_resp.headers[_dk] = _dv
            # Clean up any remaining C++ injected keys
            kwargs.pop('__raw_headers__', None)
            kwargs.pop('__method__', None)
            kwargs.pop('__path__', None)
            kwargs.pop('__auth_scheme__', None)
            kwargs.pop('__auth_credentials__', None)
            _raw_body = kwargs.pop('__body__', None)
            _raw_ct = kwargs.pop('__content_type__', None)
            # Parse body for non-fast-path routes with body params (e.g. alias/validation_alias, GET+body)
            if _body_params_shim:
                try:
                    import json as _json
                    _body_to_parse = _raw_body
                    if not _body_to_parse:
                        # Fall back to ContextVar (e.g. GET requests where C++ skips body)
                        try:
                            from astraapi._cpp_server import _current_body as _cb
                            _body_to_parse = _cb.get() or b''
                        except Exception:
                            _body_to_parse = b''
                    _parsed_body = _json.loads(_body_to_parse) if _body_to_parse else None
                    from astraapi.dependencies.utils import request_body_to_args as _rbta
                    _bvals, _berrs = await _rbta(_body_params_shim, _parsed_body, _embed_body_shim)
                    if _berrs:
                        from astraapi.responses import JSONResponse
                        return JSONResponse({"detail": _berrs}, status_code=422)
                    kwargs.update(_bvals)
                except (ValueError, TypeError):
                    pass
            _exit_stack = kwargs.pop('__exit_stack__', None)
            kwargs.pop('__deps_ran__', None)
            _gen_deps_ran = kwargs.pop('__gen_deps_ran__', False)
            _exc_handlers_shim = getattr(route, '_app_exception_handlers', None)
            # Unpack dual stacks: function_stack closes before streaming, request_stack after
            _function_stack = None
            _request_stack = None
            if isinstance(_exit_stack, tuple) and len(_exit_stack) == 2:
                _function_stack, _request_stack = _exit_stack
                _exit_stack = None  # use individual stacks below
            elif _exit_stack is not None:
                # Legacy single stack — treat as request-scoped (default for gen deps)
                _request_stack = _exit_stack
                _exit_stack = None

            async def _close_stack(stack):
                if stack is not None:
                    await stack.aclose()  # let exceptions propagate

            async def _exit_stack_on_error(exc):
                """Propagate exception through both stacks, return True if suppressed."""
                suppressed = False
                if _function_stack is not None:
                    try:
                        suppressed = await _function_stack.__aexit__(type(exc), exc, exc.__traceback__)
                    except Exception as _new_exc:
                        # Stack raised a different exception (e.g. dep caught and re-raised)
                        raise _new_exc from exc
                if _request_stack is not None:
                    try:
                        suppressed = await _request_stack.__aexit__(type(exc), exc, exc.__traceback__) or suppressed
                    except Exception as _new_exc:
                        raise _new_exc from exc
                return suppressed

            async def _call_with_exc_handling():
                try:
                    if _is_async:
                        _r = await original_endpoint(**kwargs)
                    else:
                        _r = original_endpoint(**kwargs)
                    return _r
                except Exception as _exc:
                    _suppressed = await _exit_stack_on_error(_exc)
                    if _suppressed:
                        from astraapi.exceptions import AstraAPIError as _FAE
                        raise _FAE(
                            "Response not awaited. There's a high chance that the "
                            "application code is raising an exception and a dependency with yield "
                            "has a block with a bare except, or a block with except Exception, "
                            "and is not raising the exception again."
                        )
                    if _exc_handlers_shim:
                        for _exc_cls, _exc_handler in _exc_handlers_shim.items():
                            if isinstance(_exc, _exc_cls):
                                # Store exception for raise_server_exceptions=True
                                # (non-HTTP exceptions should propagate in test mode)
                                from astraapi.exceptions import HTTPException as _HE
                                from astraapi.exceptions import RequestValidationError as _RVE
                                if not isinstance(_exc, (_HE, _RVE)):
                                    try:
                                        import astraapi._cpp_server as _srv_exc
                                        if _srv_exc._raise_server_exceptions:
                                            _srv_exc._set_last_server_exception(_exc)
                                    except Exception:
                                        pass
                                from astraapi.routing import _make_lightweight_request as _mlr
                                _req = _mlr(None, 'GET', '/', route)
                                import inspect as _insp
                                _hr = _exc_handler(_req, _exc)
                                if _insp.isawaitable(_hr):
                                    _hr = await _hr
                                return _hr
                    raise

            result = await _call_with_exc_handling()

            # Apply HTTP middleware (e.g. GZipMiddleware) if registered
            try:
                import astraapi._cpp_server as _mw_srv
                _mw_dispatchers = _mw_srv._http_middleware_dispatchers
                if _mw_dispatchers:
                    from astraapi._cpp_server import _current_raw_headers as _mw_crh, _current_method as _mw_cm, _current_path as _mw_cp
                    from astraapi.routing import _make_lightweight_request as _mw_mlr
                    _mw_req = _mw_mlr(_mw_crh.get(), _mw_cm.get() or 'GET', _mw_cp.get() or '/')
                    # Wrap non-Response results in JSONResponse for middleware
                    _raw_type = type(result)
                    if not isinstance(result, _Response):
                        from astraapi.responses import JSONResponse as _JR
                        _mw_resp = _JR(content=result, status_code=status_code or 200)
                    else:
                        _mw_resp = result
                    for _mw_fn in reversed(_mw_dispatchers):
                        async def _mw_call_next(_req, _r=_mw_resp):
                            return _r
                        _mw_resp = await _mw_fn(_mw_req, _mw_call_next)
                        if _mw_resp is None:
                            break
                    if _mw_resp is not None:
                        result = _mw_resp
                        # Mark so _handle_async_di doesn't run middleware again
                        result.__middleware_ran__ = True
            except Exception:
                pass

            # If already a Response object, handle based on type
            _final: Any = None
            if isinstance(result, _FileResponse):
                # Read file and return as plain Response
                try:
                    with open(result.path, 'rb') as fh:
                        body_bytes = fh.read()
                    _final = _Response(
                        content=body_bytes,
                        status_code=result.status_code,
                        media_type=result.media_type,
                    )
                except OSError as exc:
                    from astraapi import HTTPException
                    raise HTTPException(status_code=404, detail="File not found") from exc

            elif isinstance(result, _StreamingResponse):
                # Collect iterator into bytes and return as plain Response.
                # function-scoped deps close before body consumed; request-scoped after.
                await _close_stack(_function_stack)
                chunks = []
                body_iter = result.body_iterator
                _stream_exc = None
                try:
                    if hasattr(body_iter, '__aiter__'):
                        async for chunk in body_iter:
                            chunks.append(chunk if isinstance(chunk, bytes) else chunk.encode())
                    else:
                        for chunk in body_iter:
                            chunks.append(chunk if isinstance(chunk, bytes) else chunk.encode())
                except Exception as _se:
                    _stream_exc = _se
                await _close_stack(_request_stack)
                if _stream_exc is not None:
                    # Exception during streaming — response already started (200), capture as server error
                    import logging as _logging
                    _logging.getLogger("astraapi").error(
                        "Exception during streaming response: %s", _stream_exc)
                    try:
                        import astraapi._cpp_server as _srv
                        _srv._last_server_exception = _stream_exc
                    except Exception:
                        pass
                _final = _Response(
                    content=b"".join(chunks),
                    status_code=result.status_code,
                    media_type=result.media_type,
                )

            elif isinstance(result, _Response):
                _final = result

            elif hasattr(result, 'body') and isinstance(getattr(result, 'body', None), bytes):
                # Response-like object from a different framework (e.g. starlette.responses)
                _final = result

            else:
                # Apply response model filtering if set
                if _response_field is not None:
                    _val, _errs = _response_field.validate(result, {}, loc=("response",))
                    if _errs:
                        from astraapi.exceptions import ResponseValidationError as _RVE
                        from astraapi.routing import _extract_endpoint_context
                        _rve_ctx = _extract_endpoint_context(original_endpoint)
                        _dep = getattr(route, 'dependant', None)
                        if _dep and getattr(_dep, 'path', None):
                            _rve_ctx['path'] = f"GET {_dep.path}"
                        _rve = _RVE(errors=_errs, body=result, endpoint_ctx=_rve_ctx)
                        try:
                            from astraapi._cpp_server import _set_last_server_exception as _slse
                            _slse(_rve)
                        except Exception:
                            pass
                        raise _rve
                    result = _response_field.serialize(
                        _val,
                        include=_rm_include,
                        exclude=_rm_exclude,
                        by_alias=_rm_by_alias,
                        exclude_unset=_rm_exclude_unset,
                        exclude_defaults=_rm_exclude_defaults,
                        exclude_none=_rm_exclude_none,
                    )
                # Not a Response — wrap using the route's response_class
                if _is_redirect:
                    # Pass only the URL; let RedirectResponse use its own default status_code
                    # (307), unless route explicitly overrides it
                    if status_code and status_code != 200:
                        _final = actual_rc(result, status_code=status_code)
                    else:
                        _final = actual_rc(result)
                elif actual_rc is _FileResponse:
                    # response_class=FileResponse, endpoint returns file path string
                    try:
                        with open(str(result), 'rb') as fh:
                            body_bytes = fh.read()
                        _final = _Response(
                            content=body_bytes,
                            status_code=status_code,
                            media_type=None,
                        )
                    except OSError as exc:
                        from astraapi import HTTPException
                        raise HTTPException(status_code=404, detail="File not found") from exc
                else:
                    _final = actual_rc(content=result, status_code=status_code)

            # Apply response headers set by endpoint (response: Response param)
            # Skip content-length/content-type to avoid overwriting the actual response body headers
            if _sub_resp is not None and _final is not None:
                _skip = {'content-length', 'content-type'}
                for _hk, _hv in _sub_resp.headers.items():
                    if _hk.lower() not in _skip:
                        _final.headers[_hk] = _hv
                _sub_sc = getattr(_sub_resp, 'status_code', None)
                if _sub_sc is not None and _sub_sc != 200:
                    _final.status_code = _sub_sc
                    # If original status was 204/no-content but override has body, rebuild
                    if status_code == 204 and _sub_sc not in (204, 205) and not getattr(_final, 'body', b''):
                        _final = actual_rc(content=result, status_code=_sub_sc)

            # Attach bg tasks to response for _handle_async_di to run
            # inside the exit_stack (before gen dep cleanup).
            # Run bg tasks before returning so they complete before response is sent
            if _shim_bg_tasks is not None and getattr(_shim_bg_tasks, 'tasks', None):
                await _shim_bg_tasks()

            # Close both stacks for non-streaming paths.
            # function_stack: HTTPException → becomes response; other → server error
            # request_stack: all exceptions → server error (response already built)
            from astraapi.exceptions import HTTPException as _HTTPExcCleanup
            if _function_stack is not None:
                try:
                    await _function_stack.aclose()
                except _HTTPExcCleanup:
                    raise  # becomes HTTP response
                except Exception as _stack_exc:
                    import logging as _logging
                    _logging.getLogger("astraapi").error(
                        "Exception in dependency cleanup (after yield): %s", _stack_exc)
                    try:
                        import astraapi._cpp_server as _srv
                        _srv._last_server_exception = _stack_exc
                    except Exception:
                        pass
            if _request_stack is not None:
                try:
                    await _request_stack.aclose()
                except Exception as _stack_exc:
                    import logging as _logging
                    _logging.getLogger("astraapi").error(
                        "Exception in dependency cleanup (after yield): %s", _stack_exc)
                    try:
                        import astraapi._cpp_server as _srv
                        _srv._last_server_exception = _stack_exc
                    except Exception:
                        pass

            return _final

        _response_shim.__name__ = getattr(original_endpoint, '__name__', '_response_shim')
        return _response_shim

    @staticmethod
    def _make_form_endpoint_shim(route: Any) -> Callable[..., Any]:
        """Create an async endpoint shim for form-based (UploadFile/File) routes.

        The C++ multipart parser produces raw dicts for file fields:
            {"name": "file", "filename": "upload.txt", "data": b"...", "content_type": "..."}

        This shim converts those dicts to proper ``UploadFile`` objects before
        calling the original endpoint, enabling the C++ fast path (which handles
        multipart parsing natively) to work correctly with UploadFile parameters.
        """
        import io
        from astraapi.params import File as _FileParam
        from astraapi._datastructures_impl import UploadFile as _UploadFile, Headers as _Headers

        original_endpoint = route.endpoint

        # Collect File/UploadFile params: name -> (is_upload, is_list, alias)
        file_param_names: dict[str, tuple[bool, bool, str]] = {}
        for bp in route.dependant.body_params:
            fi = getattr(bp, 'field_info', None)
            if fi is not None and isinstance(fi, _FileParam):
                ann = getattr(bp, 'type_', None) or getattr(bp, 'annotation', None)
                is_upload = False
                is_list = False
                if ann is not None:
                    import typing as _typing
                    origin = getattr(ann, '__origin__', None)
                    args = getattr(ann, '__args__', None) or ()
                    def _is_upload_type(t):
                        return t is _UploadFile or (isinstance(t, type) and issubclass(t, _UploadFile))
                    if origin is list:
                        is_list = True
                        if any(_is_upload_type(a) for a in args):
                            is_upload = True
                    elif _is_upload_type(ann):
                        is_upload = True
                    elif origin is _typing.Union and any(_is_upload_type(a) for a in args):
                        # Union[UploadFile, None] etc.
                        is_upload = True
                    elif origin is _typing.Union:
                        # Union[list[UploadFile], None] etc. — unwrap and check
                        for _ua in args:
                            _uo = getattr(_ua, '__origin__', None)
                            _ua_args = getattr(_ua, '__args__', None) or ()
                            if _uo is list:
                                is_list = True
                                if any(_is_upload_type(a) for a in _ua_args):
                                    is_upload = True
                                break
                            elif _is_upload_type(_ua):
                                is_upload = True
                                break
                from astraapi.dependencies.utils import get_validation_alias as _gva
                _alias = _gva(bp)
                _fi_alias = getattr(getattr(bp, 'field_info', None), 'alias', None)
                file_param_names[bp.name] = (is_upload, is_list, _alias, _fi_alias)

        _is_async = inspect.iscoroutinefunction(original_endpoint)

        from astraapi.dependencies.utils import get_validation_alias as _gva_form
        from astraapi.params import File as _FileParam2
        # Collect required form params: use alias as the lookup key (C++ uses form field name = alias)
        _required_form_params = [(f.name, _gva_form(f)) for f in route.dependant.body_params if f.required]
        _optional_form_defaults = {(f.name, _gva_form(f)): f.field_info.default for f in route.dependant.body_params
                                    if not f.required and hasattr(f.field_info, 'default')}
        # Alias→fieldname mapping for non-file params (C++ injects under alias, endpoint expects fieldname)
        _alias_to_name = {
            _gva_form(f): f.name
            for f in route.dependant.body_params
            if not isinstance(getattr(f, 'field_info', None), _FileParam2)
            and _gva_form(f) != f.name
        }

        if not file_param_names and not _alias_to_name:
            # No file params and no aliases — original endpoint is fine as-is
            return original_endpoint

        # Build set of all known aliases to clean up (regular alias != validation_alias)
        _extra_aliases_to_remove: set = set()
        for f in route.dependant.body_params:
            if not isinstance(getattr(f, 'field_info', None), _FileParam2):
                _val_alias = _gva_form(f)
                _reg_alias = getattr(getattr(f, 'field_info', None), 'alias', None)
                if _reg_alias and _reg_alias != f.name and _reg_alias != _val_alias:
                    _extra_aliases_to_remove.add(_reg_alias)

        async def _form_shim(**kwargs: Any) -> Any:
            # Track which fields were provided via alias (not just field name)
            _alias_provided: set = set()
            # Pre-scan file params to track alias provision before required check
            for _fn, (_iu, _il, _al, _fia) in file_param_names.items():
                if _al != _fn and kwargs.get(_al) is not None:
                    _alias_provided.add(_fn)
            # Remap alias keys to field name keys for non-file params
            for _alias, _fname in _alias_to_name.items():
                if _alias in kwargs:
                    # Alias sent — use it (overrides any field name injection from C++)
                    kwargs[_fname] = kwargs.pop(_alias)
                    _alias_provided.add(_fname)
                elif _fname in kwargs:
                    # Field name sent but alias required — only remove for optional params
                    if _fname not in {fn for fn, _ in _required_form_params}:
                        kwargs.pop(_fname, None)
            # Remove regular aliases that differ from validation_alias (not accepted)
            for _ea in _extra_aliases_to_remove:
                kwargs.pop(_ea, None)
            # Validate required form params
            _missing = []
            for _fname, _falias in _required_form_params:
                if _falias != _fname:
                    # Alias required: only valid if alias was sent (tracked above)
                    if _fname not in _alias_provided:
                        _missing.append(_falias)
                else:
                    if kwargs.get(_fname) is None:
                        _missing.append(_falias)
            if _missing:
                from astraapi.responses import JSONResponse
                _errs = [{'type': 'missing', 'loc': ('body', p), 'msg': 'Field required', 'input': None} for p in _missing]
                return JSONResponse({"detail": _errs}, status_code=422)
            # Inject defaults for optional params not in kwargs
            for (_pn, _palias), _pdef in _optional_form_defaults.items():
                if _palias not in kwargs and _pn not in kwargs:
                    kwargs[_pn] = _pdef
            created_files: list[Any] = []
            for name, (is_upload, is_list, alias, fi_alias) in file_param_names.items():
                # Look up by alias (C++ uses form field name = alias)
                # If alias differs from name, only accept alias (not field name)
                if alias != name:
                    raw = kwargs.get(alias)
                else:
                    raw = kwargs.get(name)
                # Track if file was provided via alias
                if raw is not None and alias != name:
                    _alias_provided.add(name)
                # C++ passes UploadFile, list of UploadFile, or dict
                if isinstance(raw, _UploadFile):
                    if is_list:
                        # Wrap single UploadFile in list
                        if not is_upload:
                            raw.file.seek(0)
                            kwargs[name] = [raw.file.read()]
                        else:
                            kwargs[name] = [raw]
                    elif not is_upload:
                        raw.file.seek(0)
                        kwargs[name] = raw.file.read()
                    else:
                        # Already UploadFile — assign to field name
                        kwargs[name] = raw
                elif isinstance(raw, list):
                    converted = []
                    for item in raw:
                        if isinstance(item, _UploadFile):
                            if not is_upload:
                                item.file.seek(0)
                                converted.append(item.file.read())
                            else:
                                converted.append(item)
                        elif isinstance(item, dict) and 'data' in item:
                            d = item.get('data') or b''
                            if is_upload:
                                # Use SpooledTemporaryFile directly if C++ provided one (avoids BytesIO copy)
                                _file_obj = d if hasattr(d, 'read') else io.BytesIO(d)
                                _size = item.get('size') or (len(d) if isinstance(d, (bytes, bytearray)) else 0)
                                uf = _UploadFile(filename=item.get('filename') or '', file=_file_obj,
                                                 content_type=item.get('content_type') or 'application/octet-stream',
                                                 headers=_Headers(raw=[]), size=_size)
                                converted.append(uf)
                                created_files.append(uf)
                            else:
                                converted.append(d)
                        else:
                            # Raw bytes — wrap in UploadFile if needed
                            if is_upload and isinstance(item, (bytes, bytearray)):
                                _file_obj = io.BytesIO(item)
                                uf = _UploadFile(filename='', file=_file_obj,
                                                 content_type='application/octet-stream',
                                                 headers=_Headers(raw=[]), size=len(item))
                                converted.append(uf)
                                created_files.append(uf)
                            else:
                                converted.append(item)
                    kwargs[name] = converted
                elif isinstance(raw, dict) and 'data' in raw:
                    data = raw.get('data') or b''
                    if is_upload:
                        # Use SpooledTemporaryFile directly if C++ provided one
                        _file_obj = data if hasattr(data, 'read') else io.BytesIO(data)
                        _size = raw.get('size') or (len(data) if isinstance(data, (bytes, bytearray)) else 0)
                        uf = _UploadFile(
                            filename=raw.get('filename') or '',
                            file=_file_obj,
                            content_type=raw.get('content_type') or 'application/octet-stream',
                            headers=_Headers(raw=[]),
                            size=_size,
                        )
                        if is_list:
                            kwargs[name] = [uf]
                        else:
                            kwargs[name] = uf
                        created_files.append(uf)
                    else:
                        kwargs[name] = [data] if is_list else data
                # Remove alias key if different from field name (endpoint expects field name)
                if alias != name:
                    kwargs.pop(alias, None)
                    # Also remove the regular alias (when validation_alias is used as lookup key)
                    if fi_alias and fi_alias != name and fi_alias != alias:
                        kwargs.pop(fi_alias, None)
                    # If raw was None (file sent by field name, not alias), clear field name too
                    # so endpoint gets the default (None for optional params)
                    if raw is None and name in kwargs:
                        kwargs.pop(name, None)
            try:
                if _is_async:
                    return await original_endpoint(**kwargs)
                else:
                    return original_endpoint(**kwargs)
            finally:
                # Close UploadFile objects after the request completes
                # (mirrors standard AstraAPI's FormData.close() cleanup)
                for uf in created_files:
                    uf.file.close()
                # Also close UploadFile objects injected directly by C++ build_kwargs
                for _k, _v in kwargs.items():
                    if isinstance(_v, _UploadFile) and _v not in created_files:
                        try: _v.file.close()
                        except Exception: pass

        _form_shim.__name__ = getattr(original_endpoint, '__name__', '_form_shim')
        return _form_shim

    def _sync_routes_to_core(self) -> None:
        """Register all router routes with CoreApp.

        @app.get(...) decorators go through self.router, bypassing
        AstraAPI.add_api_route, so core never sees them at decoration time.
        This scans the router once and bulk-registers everything.
        Called from build_middleware_stack() during startup.
        """
        with _global_sync_lock:
            if self._routes_synced:
                return
            self._routes_synced = True

            self._sync_routes_to_core_locked()

    def _sync_routes_to_core_locked(self) -> None:
        """Body of _sync_routes_to_core — called with _global_sync_lock held."""
        self._core_app.begin_registration()
        try:
            self._sync_routes_to_core_body()
        finally:
            self._core_app.end_registration()

    def _sync_routes_to_core_body(self) -> None:
        """Actual route registration — mutex-free (protected by begin/end_registration)."""
        import astraapi._cpp_server as _srv_mod
        _srv_mod._needs_request_context = False  # reset; set True below if any route needs it

        from astraapi.routing import APIRoute, APIWebSocketRoute, _make_dep_solver
        from astraapi import params as _astraapi_params

        # Check if any non-BaseHTTPMiddleware middleware is registered (e.g. GZipMiddleware)
        # If so, force all routes through _response_shim to apply middleware
        _has_asgi_middleware = any(
            getattr(getattr(_mw, 'cls', None), '__name__', '') not in ('BaseHTTPMiddleware', 'HTTPSRedirectMiddleware', 'TrustedHostMiddleware', 'CORSMiddleware')
            for _mw in getattr(self, 'user_middleware', [])
        )
        if _has_asgi_middleware:
            _srv_mod._needs_request_context = True

        # Group routes by path to handle same-path multi-method routes
        from collections import defaultdict as _dd
        _path_routes: dict = _dd(list)
        for _r in self.routes:
            if isinstance(_r, APIRoute):
                _path_routes[_r.path].append(_r)

        for route in self.routes:
            if not isinstance(route, APIRoute):
                continue
            # Skip non-first routes in same-path groups (handled by first)
            _path_group = _path_routes.get(route.path, [])
            if len(_path_group) > 1 and route is not _path_group[0]:
                continue
            endpoint = route.endpoint
            _is_coro = inspect.iscoroutinefunction(endpoint) or inspect.iscoroutinefunction(inspect.unwrap(endpoint))
            _methods = sorted(route.methods) if route.methods else ["GET"]
            # HTTP spec §9.3.1: any resource supporting GET MUST also support HEAD.
            if "GET" in _methods and "HEAD" not in _methods:
                _methods = sorted(_methods + ["HEAD"])
            # Merge methods from all same-path routes
            if len(_path_group) > 1:
                _all_m: set = set(_methods)
                for _gr in _path_group[1:]:
                    _gm = sorted(_gr.methods) if _gr.methods else ["GET"]
                    _all_m.update(_gm)
                    if "GET" in _gm:
                        _all_m.add("HEAD")
                _methods = sorted(_all_m)
            _has_body = any(m in ("POST", "PUT", "PATCH", "DELETE") for m in _methods) or bool(
                getattr(route, 'dependant', None) and getattr(route.dependant, 'body_params', None)
            )

            # Detect form-based routes (File / UploadFile / Form body params)
            _is_form = bool(
                route.body_field
                and isinstance(route.body_field.field_info, _astraapi_params.Form)
            )

            # Same-path groups: build a method-dispatching shim registered as non-fast-path
            _in_group = len(_path_group) > 1
            if _in_group:
                # Build per-method shims and a dispatcher
                _method_shim_map: dict = {}
                # First pass: register explicit routes
                for _gr in _path_group:
                    _gr_shim = self._make_response_class_shim(_gr)
                    _gm = sorted(_gr.methods) if _gr.methods else ["GET"]
                    for _m in _gm:
                        if _m.upper() not in _method_shim_map:
                            _method_shim_map[_m.upper()] = _gr_shim
                # Second pass: auto-add HEAD for GET routes (only if no explicit HEAD)
                if "GET" in _method_shim_map and "HEAD" not in _method_shim_map:
                    _method_shim_map["HEAD"] = _method_shim_map["GET"]
                _captured_shim_map = dict(_method_shim_map)
                def _make_group_dispatcher(_smap: dict, _route_map: dict) -> Any:
                    # Pre-compute known param names per method to filter cross-method kwargs
                    _method_params: dict = {}
                    for _mm, _mgr in _route_map.items():
                        _flat_dep = getattr(_mgr, "_flat_dependant", None) or getattr(_mgr, "dependant", None)
                        _known: set = set()
                        for _plist in (getattr(_flat_dep, "query_params", []),
                                       getattr(_flat_dep, "path_params", []),
                                       getattr(_flat_dep, "header_params", []),
                                       getattr(_flat_dep, "cookie_params", [])):
                            for _pf in _plist:
                                _known.add(_pf.name)
                                from astraapi.dependencies.utils import get_validation_alias as _gva
                                _known.add(_gva(_pf))
                        _method_params[_mm] = _known
                    _INTERNAL = frozenset({"__method__", "__raw_headers__", "__path__",
                                           "__auth_scheme__", "__auth_credentials__",
                                           "__body__", "__content_type__"})
                    async def _group_dispatcher(**kwargs: Any) -> Any:
                        _m = kwargs.get("__method__", "GET").upper()
                        _shim = _smap.get(_m)
                        if _shim is None:
                            from astraapi.responses import JSONResponse
                            return JSONResponse({"detail": "Method Not Allowed"}, status_code=405)
                        # Filter out query params from other methods in the group
                        _known_for_method = _method_params.get(_m, set())
                        kwargs = {k: v for k, v in kwargs.items()
                                  if k in _INTERNAL or k in _known_for_method}
                        # Parse body for methods that need it
                        _body_bytes = kwargs.pop("__body__", None)
                        _ct = kwargs.pop("__content_type__", "")
                        _gr = _route_map.get(_m)
                        if _body_bytes and _gr is not None:
                            _bp = getattr(getattr(_gr, "dependant", None), "body_params", [])
                            if _bp:
                                try:
                                    import json as _json
                                    _parsed = _json.loads(_body_bytes)
                                    if isinstance(_parsed, dict):
                                        from astraapi.dependencies.utils import request_body_to_args as _rbta
                                        _embed = getattr(_gr, "_embed_body_fields", False)
                                        _vals, _errs = await _rbta(_bp, _parsed, _embed)
                                        if _errs:
                                            from astraapi.responses import JSONResponse
                                            return JSONResponse({"detail": _errs}, status_code=422)
                                        kwargs.update(_vals)
                                except (ValueError, KeyError):
                                    pass
                        return await _shim(**kwargs)
                    return _group_dispatcher
                _route_map: dict = {}
                for _gr2 in _path_group:
                    _gm2 = sorted(_gr2.methods) if _gr2.methods else ["GET"]
                    for _m2 in _gm2:
                        if _m2.upper() not in _route_map:
                            _route_map[_m2.upper()] = _gr2
                    if "GET" in _gm2 and "HEAD" not in _route_map:
                        _route_map["HEAD"] = _gr2
                _group_dispatcher = _make_group_dispatcher(_captured_shim_map, dict(_route_map))
                _group_dispatcher.__name__ = f"_group_{route.path.replace('/', '_')}"
                # Register as non-fast-path: C++ passes raw kwargs, dispatcher handles routing
                try:
                    self._core_app.add_route(
                        route.path, _methods, _group_dispatcher, True,
                        status_code=route.status_code or 200, tags=[],
                        summary=route.summary, description=route.description,
                        operation_id=route.operation_id,
                        has_body=_has_body, is_form=False, is_multi_method=True,
                        exclude_unset=False, exclude_defaults=False, exclude_none=False,
                    )
                    _route_index = self._core_app.route_count() - 1
                    # Collect union of field specs from all routes in group
                    _group_specs: list = []
                    _seen_spec_names: set = set()
                    for _gsr in _path_group:
                        for _spec in getattr(_gsr, '_batch_specs', []):
                            _sname = _spec[3]  # field_name
                            if _sname not in _seen_spec_names:
                                _seen_spec_names.add(_sname)
                                _group_specs.append(_spec)
                    _group_field_specs = self._convert_batch_specs(_group_specs) if _group_specs else None
                    self._core_app.register_fast_spec(
                        _route_index, None, _group_field_specs, None, False,
                        None, None,
                    )
                except Exception as _exc:
                    logger.debug("C++ group route registration failed for %s: %s", route.path, _exc)
                continue  # skip normal registration below

            # For form routes: wrap endpoint so C++ raw file dicts become UploadFile
            _registered_endpoint = endpoint
            # Detect custom APIRoute subclass (overrides get_route_handler)
            from astraapi.routing import APIRoute as _APIRoute
            _has_custom_route_class = type(route) is not _APIRoute
            if _has_custom_route_class:
                _registered_endpoint = self._make_asgi_route_shim(route)
                _is_coro = True
                _srv_mod._needs_request_context = True
            # Check if any dep (including sub-deps) needs Request injection
            if not _srv_mod._needs_request_context:
                try:
                    from pydantic import BaseModel as _BM
                    from astraapi._compat import lenient_issubclass as _lis
                    def _dep_needs_ctx(d, _visited=None):
                        if _visited is None: _visited = set()
                        if id(d) in _visited: return False
                        _visited.add(id(d))
                        if getattr(d, 'request_param_name', None) or getattr(d, 'http_connection_param_name', None):
                            return True
                        _all_model_params = (getattr(d, 'header_params', []) +
                                            getattr(d, 'cookie_params', []) +
                                            getattr(d, 'query_params', []))
                        for _hf in _all_model_params:
                            # Any model-based param (Query/Header/Cookie with BaseModel type)
                            # needs the raw ContextVar data to handle extra fields correctly.
                            if _lis(_hf.type_, _BM):
                                return True
                        for _sub in getattr(d, 'dependencies', []):
                            if _dep_needs_ctx(_sub, _visited): return True
                        return False
                    _dep = getattr(route, 'dependant', None)
                    if _dep and _dep_needs_ctx(_dep):
                        _srv_mod._needs_request_context = True
                    # Non-fast-path routes with body params use the ASGI shim which reads
                    # _current_body ContextVar — they need request context populated.
                    elif not getattr(route, '_fast_path_eligible', False) and _dep and getattr(_dep, 'body_params', None):
                        _srv_mod._needs_request_context = True
                except Exception:
                    pass
            if _is_form and not _has_custom_route_class:
                _has_dep_solver_form = getattr(route, '_dep_solver', None) is not None
                if _has_dep_solver_form:
                    # Form route with dep_solver: use response_class_shim which handles deps
                    try:
                        from astraapi.exception_handlers import http_exception_handler as _dh, request_validation_exception_handler as _dvh
                        _default_exc_handlers = {_dh, _dvh}
                    except ImportError:
                        _default_exc_handlers = set()
                    _type_exc_handlers = {k: v for k, v in self.exception_handlers.items() if isinstance(k, type) and v not in _default_exc_handlers}
                    if _type_exc_handlers:
                        route._app_exception_handlers = _type_exc_handlers
                    _registered_endpoint = self._make_response_class_shim(route)
                    _is_coro = True
                else:
                    _registered_endpoint = self._make_form_endpoint_shim(route)
                    # The shim is async, but if no file params the original endpoint
                    # is returned unchanged — use its actual coroutine status.
                    _is_coro = inspect.iscoroutinefunction(_registered_endpoint)
            elif not _has_custom_route_class and not getattr(route, '_fast_path_eligible', False):
                # Non-fast-path, non-form routes (e.g. response_class=HTMLResponse).
                # Wrap endpoint so result is a Response object for C++ raw_headers path.
                # Attach app-level exception handlers (type-keyed) to route for shim
                _type_exc_handlers = {k: v for k, v in self.exception_handlers.items() if isinstance(k, type)}
                if _type_exc_handlers:
                    route._app_exception_handlers = _type_exc_handlers
                _registered_endpoint = self._make_response_class_shim(route)
                route.dependant.call = _registered_endpoint
                endpoint = _registered_endpoint
                _is_coro = True  # shim is always async
            elif not _has_custom_route_class and getattr(route, 'response_field', None) is not None:
                _has_dep_solver_rm = getattr(route, '_dep_solver', None) is not None
                # Also use response_class_shim if there's a custom ResponseValidationError handler
                from astraapi.exceptions import ResponseValidationError as _RVE_check
                _has_custom_rve = _RVE_check in self.exception_handlers
                if _has_dep_solver_rm or _has_asgi_middleware or _has_custom_rve:
                    try:
                        from astraapi.exception_handlers import http_exception_handler as _dh, request_validation_exception_handler as _dvh
                        _default_exc_handlers = {_dh, _dvh}
                    except ImportError:
                        _default_exc_handlers = set()
                    _type_exc_handlers = {k: v for k, v in self.exception_handlers.items() if isinstance(k, type) and v not in _default_exc_handlers}
                    if _type_exc_handlers:
                        route._app_exception_handlers = _type_exc_handlers
                    _registered_endpoint = self._make_response_class_shim(route)
                else:
                    _registered_endpoint = self._make_response_model_shim(route)
                _is_coro = True  # shim is always async
                # Update dependant.call and endpoint so C++ fast path uses the shim
                route.dependant.call = _registered_endpoint
                endpoint = _registered_endpoint
            elif not _has_custom_route_class:
                # Fast-path route without response_model.
                # If route has a dep_solver, use _response_shim (handles deps).
                # Otherwise use _param_validation_shim (lighter weight).
                _has_dep_solver = getattr(route, '_dep_solver', None) is not None
                if _has_dep_solver or _has_asgi_middleware:
                    try:
                        from astraapi.exception_handlers import http_exception_handler as _dh, request_validation_exception_handler as _dvh
                        _default_exc_handlers = {_dh, _dvh}
                    except ImportError:
                        _default_exc_handlers = set()
                    _type_exc_handlers = {k: v for k, v in self.exception_handlers.items() if isinstance(k, type) and v not in _default_exc_handlers}
                    if _type_exc_handlers:
                        route._app_exception_handlers = _type_exc_handlers
                    _registered_endpoint = self._make_response_class_shim(route)
                    _is_coro = True
                else:
                    try:
                        from astraapi.exception_handlers import http_exception_handler as _dh, request_validation_exception_handler as _dvh
                        _default_exc_handlers = {_dh, _dvh}
                    except ImportError:
                        _default_exc_handlers = set()
                    _type_exc_handlers = {k: v for k, v in self.exception_handlers.items() if isinstance(k, type) and v not in _default_exc_handlers}
                    if _type_exc_handlers:
                        route._app_exception_handlers = _type_exc_handlers
                    _pv_shim = self._make_param_validation_shim(route)
                    # When Exception base class handler is registered, wrap endpoint to
                    # store non-HTTP exceptions for raise_server_exceptions=True
                    if Exception in self.exception_handlers and _pv_shim is endpoint:
                        _orig_ep = endpoint
                        _is_async_ep = inspect.iscoroutinefunction(_orig_ep)
                        if _is_async_ep:
                            async def _exc_store_shim(_ep=_orig_ep, **_kw):
                                try:
                                    return await _ep(**_kw)
                                except Exception as _e:
                                    from astraapi.exceptions import HTTPException as _HE
                                    from astraapi.exceptions import RequestValidationError as _RVE
                                    if not isinstance(_e, (_HE, _RVE)):
                                        try:
                                            import astraapi._cpp_server as _s
                                            if _s._raise_server_exceptions:
                                                _s._set_last_server_exception(_e)
                                        except Exception:
                                            pass
                                    raise
                        else:
                            def _exc_store_shim(_ep=_orig_ep, **_kw):
                                try:
                                    return _ep(**_kw)
                                except Exception as _e:
                                    from astraapi.exceptions import HTTPException as _HE
                                    from astraapi.exceptions import RequestValidationError as _RVE
                                    if not isinstance(_e, (_HE, _RVE)):
                                        try:
                                            import astraapi._cpp_server as _s
                                            if _s._raise_server_exceptions:
                                                _s._set_last_server_exception(_e)
                                        except Exception:
                                            pass
                                    raise
                        _pv_shim = _exc_store_shim
                        _is_coro = _is_async_ep
                    if _pv_shim is not endpoint:
                        _registered_endpoint = _pv_shim
                        _is_coro = True
                        route.dependant.call = _registered_endpoint
                        endpoint = _registered_endpoint

            try:
                self._core_app.add_route(
                    route.path,
                    _methods,
                    _registered_endpoint,
                    _is_coro,
                    status_code=route.status_code or 200,
                    tags=[],
                    summary=route.summary,
                    description=route.description,
                    operation_id=route.operation_id,
                    has_body=False if _has_custom_route_class else _has_body,
                    is_form=False if _has_custom_route_class else _is_form,
                    exclude_unset=False,
                    exclude_defaults=False,
                    exclude_none=False,
                )
                route_index = self._core_app.route_count() - 1
                # For custom route class routes, register with a body-injecting dep_solver
                # so C++ injects __body__ into kwargs (avoids ContextVar race with anyio).
                if _has_custom_route_class:
                    async def _body_injector(kwargs_dict):
                        return ({}, [], None, None)
                    # dep_inject_mask = 0x01|0x02|0x04 = 7 so C++ injects
                    # __raw_headers__, __method__, __path__ into kwargs.
                    # Without this, _asgi_shim falls back to ContextVars which
                    # race when multiple connections are active on the same loop.
                    self._core_app.register_fast_spec(
                        route_index, None, None, None, False,
                        _registered_endpoint, _body_injector,
                        dep_inject_mask=0x07,
                    )
                # Register fast-path metadata for eligible routes
                elif getattr(route, '_fast_path_eligible', False):
                    dep = route.dependant
                    # Collect all body params: route's own + deps' body params
                    _all_body_params = list(dep.body_params)
                    _seen_bp = {f.name for f in _all_body_params}
                    def _collect_dep_body_params(d):
                        for sub in d.dependencies:
                            if sub.call is None:
                                continue
                            for f in sub.body_params:
                                if f.name not in _seen_bp:
                                    _seen_bp.add(f.name)
                                    _all_body_params.append(f)
                            _collect_dep_body_params(sub)
                    _collect_dep_body_params(dep)
                    body_param_name = (
                        dep.body_params[0].name if dep.body_params else None
                    )
                    raw_specs = getattr(route, '_batch_specs', [])
                    field_specs = (
                        self._convert_batch_specs(raw_specs) if raw_specs
                        else None
                    )
                    dep_solver = getattr(route, '_dep_solver', None)
                    # Wrap dep_solver to propagate sub_response (headers set by deps)
                    if dep_solver is not None:
                        _orig_ds = dep_solver
                        import inspect as _insp2
                        if _insp2.iscoroutinefunction(_orig_ds):
                            async def _ds_wrap(kd, _s=_orig_ds):
                                r = await _s(kd)
                                if isinstance(r, tuple) and len(r) >= 4 and r[3] is not None:
                                    kd['__sub_response__'] = r[3]
                                return r
                        else:
                            def _ds_wrap(kd, _s=_orig_ds):
                                r = _s(kd)
                                if isinstance(r, tuple) and len(r) >= 4 and r[3] is not None:
                                    kd['__sub_response__'] = r[3]
                                return r
                        dep_solver = _ds_wrap
                    # For dep-solver routes, mark all field specs as not-required
                    # so C++ does not return 422 for missing dep params.
                    # The dep solver handles validation and raises HTTPExceptions.
                    if dep_solver is not None and field_specs:
                        for _fs in field_specs:
                            _fs['required'] = False
                    _raw_pv = getattr(route, '_param_validator', None)
                    # For fast-path routes, build param_validator from _flat_dependant
                    if _raw_pv is None and getattr(route, '_fast_path_eligible', False):
                        try:
                            from astraapi.routing import _make_param_validator as _mpv
                            _flat = getattr(route, '_flat_dependant', None) or dep
                            _raw_pv = _mpv(_flat)
                        except Exception:
                            _raw_pv = None
                    # Wrap param_validator to handle dependency_overrides:
                    # - skip original validation (override may change required params)
                    # - validate override dep's required query params instead
                    if _raw_pv is not None and dep_solver is not None:
                        _app_ref = self
                        _inner_pv = _raw_pv
                        _route_dep = dep
                        def _pv_with_override_check(kwargs_dict, _pv=_inner_pv, _app=_app_ref, _dep=_route_dep):
                            overrides = getattr(_app, 'dependency_overrides', None)
                            if not overrides:
                                # No overrides: run coercion but ignore 'missing' errors
                                # (dep solver handles required validation)
                                _vals, _errs, _consumed = _pv(kwargs_dict)
                                _errs = [e for e in _errs if e.get('type') != 'missing']
                                return (_vals, _errs, _consumed)
                            # Validate required params of override deps (including sub-deps)
                            # Also check query string for params not extracted by C++ FieldSpec.
                            # When dependency_overrides are active, the override dep may need
                            # query params that weren't in the original route's batch_specs.
                            # Read from _current_query_string ContextVar (populated when
                            # _needs_req_ctx=True) OR fall back to re-parsing from C++ raw buf.
                            from astraapi.dependencies.utils import get_dependant
                            from urllib.parse import parse_qs
                            _qs_params: set = set()
                            try:
                                from astraapi._cpp_server import _current_query_string
                                _qs_bytes = _current_query_string.get()
                                if not _qs_bytes:
                                    # _needs_req_ctx=False path: ContextVar not populated.
                                    # Re-parse from the C++ http buffer via the raw request.
                                    # The query string is in kwargs_dict as __query_string__
                                    # if C++ injected it, otherwise we can't recover it here.
                                    # Best effort: check kwargs_dict for any injected qs.
                                    _raw_qs = kwargs_dict.get('__query_string__', b'')
                                    if isinstance(_raw_qs, str):
                                        _raw_qs = _raw_qs.encode('latin-1')
                                    _qs_bytes = _raw_qs
                                if _qs_bytes:
                                    _qs_params = set(parse_qs(_qs_bytes.decode('latin-1'), keep_blank_values=True).keys())
                            except Exception:
                                pass
                            # kwargs_dict already contains C++-extracted params — include them
                            _available = set(kwargs_dict.keys()) | _qs_params
                            errors = []
                            visited = set()
                            def _collect_required(d):
                                """Recursively collect required query params from dep tree."""
                                override = overrides.get(d.call)
                                target = get_dependant(path='/', call=override) if override is not None else d
                                for f in target.query_params:
                                    if f.required and f.name not in _available:
                                        errors.append({"type": "missing", "loc": ["query", f.name], "msg": "Field required", "input": None})
                                for sub in target.dependencies:
                                    if sub.call and id(sub.call) not in visited:
                                        visited.add(id(sub.call))
                                        _collect_required(sub)
                            for sub in _dep.dependencies:
                                if sub.call and id(sub.call) not in visited:
                                    visited.add(id(sub.call))
                                    _collect_required(sub)
                            return ({}, errors)
                        param_validator = _pv_with_override_check
                    elif dep_solver is not None:
                        # Dep solver handles all validation; skip param_validator
                        param_validator = None
                    else:
                        param_validator = _raw_pv
                    # If custom RequestValidationError handler exists, skip C++ param_validator
                    # so the shim can catch validation errors and call the custom handler
                    if param_validator is not None:
                        try:
                            from astraapi.exception_handlers import request_validation_exception_handler as _def_rv
                        except ImportError:
                            _def_rv = None
                        _custom_rv = self.exception_handlers.get(RequestValidationError)
                        if _custom_rv is not None and _custom_rv is not _def_rv:
                            param_validator = None
                    self._core_app.register_fast_spec(
                        route_index,
                        body_param_name,
                        field_specs,
                        _all_body_params if _all_body_params else None,
                        getattr(route, '_embed_body_fields', False),
                        dep if dep.dependencies else None,
                        dep_solver,
                        param_validator=param_validator,
                    )
                    logger.debug("register_fast_spec OK for %s route_index=%s body_param_name=%s embed=%s", route.path, route_index, body_param_name, getattr(route, '_embed_body_fields', False))
                elif _is_form:
                    # Form route: register fast_spec so C++ dispatch handles it.
                    # - No file params (original endpoint returned, not shim): pass
                    #   body_params so C++ calls request_body_to_args for validation.
                    #   This gives proper 422 for missing required fields.
                    # - File params present (shim created): skip body_params validation
                    #   because raw file dicts from C++ multipart parser can't be
                    #   validated as UploadFile by Pydantic — the shim handles that.
                    dep = route.dependant
                    dep_solver = None
                    if dep.dependencies:
                        try:
                            dep_solver = _make_dep_solver(dep, self)
                        except Exception:
                            pass
                    raw_specs = getattr(route, '_batch_specs', [])
                    field_specs = (
                        self._convert_batch_specs(raw_specs) if raw_specs
                        else None
                    )
                    # If shim was created (file params), skip C++ body validation
                    _has_file_params = _registered_endpoint is not endpoint
                    self._core_app.register_fast_spec(
                        route_index,
                        None,       # body_param_name: individual fields go into kwargs
                        field_specs,
                        None if _has_file_params else (dep.body_params or None),
                        getattr(route, '_embed_body_fields', True),  # form fields are embedded
                        dep if dep.dependencies else None,
                        dep_solver,
                    )
                else:
                    # Non-fast-path, non-form routes (e.g. HTMLResponse, FileResponse,
                    # StreamingResponse, routes with request_param_name, etc.).
                    # Must still call register_fast_spec so C++ dispatches the
                    # endpoint. The endpoint returns a Response object which C++
                    # handles via the raw_headers path.
                    dep = route.dependant
                    dep_solver = None
                    if dep.dependencies:
                        try:
                            dep_solver = _make_dep_solver(dep, self)
                        except Exception:
                            pass
                    raw_specs = getattr(route, '_batch_specs', [])
                    field_specs = (
                        self._convert_batch_specs(raw_specs) if raw_specs
                        else None
                    )
                    # If route has body params with aliases, use a body-injecting dep_solver so C++
                    # injects __body__ into kwargs (shim then parses it with request_body_to_args)
                    _has_alias_bp = dep.body_params and any(
                        (getattr(f.field_info, 'alias', None) not in (None, f.name))
                        or (getattr(f.field_info, 'validation_alias', None) not in (None, f.name))
                        for f in dep.body_params
                    )
                    if _has_alias_bp and dep_solver is None:
                        async def _body_injector(kwargs_dict):
                            return ({}, [], None, None)
                        dep_solver = _body_injector
                    # Wrap dep_solver to inject __sub_response__ into kwargs
                    # so _response_shim can apply headers set by deps (e.g. set_cookie)
                    if dep_solver is not None:
                        _orig_solver = dep_solver
                        import inspect as _insp
                        if _insp.iscoroutinefunction(_orig_solver):
                            async def _solver_with_sub_resp(kd, _s=_orig_solver):
                                r = await _s(kd)
                                if isinstance(r, tuple) and len(r) >= 4 and r[3] is not None:
                                    kd['__sub_response__'] = r[3]
                                return r
                        else:
                            def _solver_with_sub_resp(kd, _s=_orig_solver):
                                r = _s(kd)
                                if isinstance(r, tuple) and len(r) >= 4 and r[3] is not None:
                                    kd['__sub_response__'] = r[3]
                                return r
                        dep_solver = _solver_with_sub_resp
                    self._core_app.register_fast_spec(
                        route_index,
                        None,       # no JSON body param — shim handles body parsing
                        field_specs,
                        None,       # no body_params validation
                        False,
                        dep if (dep.dependencies or _has_alias_bp) else None,
                        dep_solver,
                    )
            except Exception as exc:
                logger.debug("C++ core route registration failed for %s: %s", route.path, exc)

        # Register Mount routes as ASGI fallback endpoints
        from astraapi._routing_base import Mount as _Mount
        for route in self.routes:
            if not isinstance(route, _Mount):
                continue
            _mount_path = route.path
            _mount_app = route.app
            if _mount_app is None:
                continue
            # Register wildcard path for the mount
            _wildcard_path = _mount_path.rstrip('/') + '/{__mount_path__:path}'
            _exact_path = _mount_path.rstrip('/') or '/'
            _srv_mod._needs_request_context = True  # mounted apps need full request context
            def _make_mount_endpoint(_app, _prefix):
                async def _mount_endpoint(**kwargs):
                    from astraapi._cpp_server import _current_raw_headers as _crh, _current_method as _cm, _current_path as _cp, _current_body as _cb, _current_query_string as _cqs
                    _raw_headers = _crh.get() or []
                    _method = _cm.get() or 'GET'
                    _full_path = _cp.get() or '/'
                    _body = _cb.get() or b''
                    _qs = _cqs.get() if hasattr(_cqs, 'get') else b''
                    # Strip mount prefix from path for sub-app
                    _sub_path = _full_path[len(_prefix.rstrip('/')):] or '/'
                    if not _sub_path.startswith('/'):
                        _sub_path = '/' + _sub_path
                    # Build ASGI headers
                    _headers = []
                    for _h in _raw_headers:
                        if isinstance(_h, (list, tuple)) and len(_h) == 2:
                            _hn, _hv = _h
                            if isinstance(_hn, str): _hn = _hn.encode('latin-1')
                            if isinstance(_hv, str): _hv = _hv.encode('latin-1')
                            _headers.append((_hn, _hv))
                    # Check if this is a WebSocket request
                    _ws_obj = kwargs.get('websocket') or kwargs.get('ws')
                    if _ws_obj is not None:
                        # WebSocket request — dispatch with websocket scope
                        _ws_scope = dict(_ws_obj.scope)
                        _ws_scope['path'] = _sub_path
                        _ws_scope['raw_path'] = _sub_path.encode('utf-8')
                        _ws_scope['root_path'] = _prefix.rstrip('/')
                        from astraapi._cpp_server import _app_exc_handlers
                        if 'starlette.exception_handlers' not in _ws_scope:
                            _cls_h = {k: v for k, v in _app_exc_handlers.items() if not isinstance(k, int)}
                            _status_h = {k: v for k, v in _app_exc_handlers.items() if isinstance(k, int)}
                            _ws_scope['starlette.exception_handlers'] = (_cls_h, _status_h)
                        from astraapi._cpp_server import _current_root_path as _crp
                        _prev_rp = _crp.get()
                        _crp.set(_ws_scope['root_path'])
                        try:
                            await _app(_ws_scope, _ws_obj.receive, _ws_obj.send)
                        finally:
                            _crp.set(_prev_rp)
                        return None
                    _scope = {
                        'type': 'http',
                        'asgi': {'version': '3.0'},
                        'http_version': '1.1',
                        'method': _method,
                        'headers': _headers,
                        'path': _sub_path,
                        'raw_path': _sub_path.encode('utf-8'),
                        'query_string': _qs if isinstance(_qs, bytes) else b'',
                        'root_path': _prefix.rstrip('/'),
                        'scheme': 'http',
                        'server': ('127.0.0.1', 8000),
                    }
                    # Build receive callable
                    _body_sent = False
                    async def _receive():
                        nonlocal _body_sent
                        if not _body_sent:
                            _body_sent = True
                            return {'type': 'http.request', 'body': _body, 'more_body': False}
                        return {'type': 'http.disconnect'}
                    # Collect response via send callable
                    _resp_status = [200]
                    _resp_headers = [[]]
                    _resp_body = [b'']
                    async def _send(msg):
                        if msg['type'] == 'http.response.start':
                            _resp_status[0] = msg['status']
                            _resp_headers[0] = msg.get('headers', [])
                        elif msg['type'] == 'http.response.body':
                            _resp_body[0] += msg.get('body', b'')
                    import warnings as _warnings
                    with _warnings.catch_warnings():
                        _warnings.simplefilter('ignore', DeprecationWarning)
                        # Set root_path ContextVar so sub-app openapi() reads correct path
                        from astraapi._cpp_server import _current_root_path as _crp
                        _prev_rp = _crp.get()
                        _crp.set(_scope['root_path'])
                        try:
                            await _app(_scope, _receive, _send)
                        finally:
                            _crp.set(_prev_rp)
                    from astraapi._response import Response as _Resp
                    _r = _Resp(content=_resp_body[0], status_code=_resp_status[0])
                    for _hn, _hv in _resp_headers[0]:
                        if isinstance(_hn, bytes): _hn = _hn.decode('latin-1')
                        if isinstance(_hv, bytes): _hv = _hv.decode('latin-1')
                        if _hn.lower() not in ('content-length',):
                            _r.headers[_hn] = _hv
                    return _r
                _mount_endpoint.__mount_app__ = _app
                _mount_endpoint.__mount_prefix__ = _prefix
                return _mount_endpoint
            _ep = _make_mount_endpoint(_mount_app, _mount_path)
            for _mp in [_wildcard_path, _exact_path]:
                try:
                    self._core_app.add_route(
                        _mp,
                        ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'],
                        _ep,
                        True,
                        status_code=200,
                        tags=[],
                        has_body=True,
                        exclude_unset=False,
                        exclude_defaults=False,
                        exclude_none=False,
                    )
                    _ridx = self._core_app.route_count() - 1
                    self._core_app.register_fast_spec(
                        _ridx, None, None, None, False, None, None, None
                    )
                except Exception as exc:
                    logger.debug('Mount route registration failed for %s: %s', _mp, exc)

        # Register plain Route objects (from router.route() decorator)
        from astraapi._routing_base import Route as _PlainRoute
        # Pre-compute internal OpenAPI/docs paths — these are served by C++ and
        # never need Python header context. Only user-registered plain Routes do.
        _internal_paths = {
            getattr(self, 'openapi_url', '/openapi.json') or '',
            getattr(self, 'docs_url', '/docs') or '',
            getattr(self, 'redoc_url', '/redoc') or '',
            getattr(self, 'swagger_ui_oauth2_redirect_url', '/docs/oauth2-redirect') or '',
        }
        for route in self.routes:
            if not isinstance(route, _PlainRoute) or isinstance(route, (APIRoute, APIWebSocketRoute)):
                continue
            _ep = route.endpoint
            _methods = list(route.methods) if route.methods else ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']
            # Only set _needs_request_context for user-registered plain Routes,
            # not for internal OpenAPI/docs routes that C++ serves directly.
            if getattr(route, 'path', '') not in _internal_paths:
                _srv_mod._needs_request_context = True
            _shim = self._make_asgi_route_shim(route)
            try:
                self._core_app.add_route(
                    route.path, _methods, _shim, True,
                    status_code=200, tags=[], has_body=True,
                    exclude_unset=False, exclude_defaults=False, exclude_none=False,
                )
                _ridx = self._core_app.route_count() - 1
                self._core_app.register_fast_spec(_ridx, None, None, None, False, None, None, None)
            except Exception as exc:
                logger.debug("Plain Route registration failed for %s: %s", route.path, exc)

        # Register WebSocket routes in C++ core for app.run() fast-path
        from astraapi._routing_base import WebSocketRoute as _WebSocketRoute
        for route in self.routes:
            if not isinstance(route, (APIWebSocketRoute, _WebSocketRoute)):
                continue
            try:
                self._core_app.add_route(
                    route.path,
                    ["GET"],  # WS upgrade is always GET
                    route.endpoint,
                    True,  # WS endpoints are always async
                    status_code=0,
                    tags=[],
                    has_body=False,
                    exclude_unset=False,
                    exclude_defaults=False,
                    exclude_none=False,
                )
            except Exception as exc:
                logger.debug("C++ core WebSocket registration failed for %s: %s", route.path, exc)

        # Store per-app-instance flag so protocols read correct value regardless of test ordering
        _srv_mod._core_app_needs_req_ctx[id(self._core_app)] = (self._core_app, _srv_mod._needs_request_context)
        # Clear protocol pool so reused protocols pick up the new _needs_req_ctx value
        _srv_mod._protocol_pool._pool.clear()

    def add_api_route(
        self,
        path: str,
        endpoint: Callable[..., Any],
        *,
        response_model: Any = Default(None),
        status_code: Optional[int] = None,
        tags: Optional[list[Union[str, Enum]]] = None,
        dependencies: Optional[Sequence[Depends]] = None,
        summary: Optional[str] = None,
        description: Optional[str] = None,
        response_description: str = "Successful Response",
        responses: Optional[dict[Union[int, str], dict[str, Any]]] = None,
        deprecated: Optional[bool] = None,
        methods: Optional[list[str]] = None,
        operation_id: Optional[str] = None,
        response_model_include: Optional[IncEx] = None,
        response_model_exclude: Optional[IncEx] = None,
        response_model_by_alias: bool = True,
        response_model_exclude_unset: bool = False,
        response_model_exclude_defaults: bool = False,
        response_model_exclude_none: bool = False,
        include_in_schema: bool = True,
        response_class: Union[type[Response], DefaultPlaceholder] = Default(
            JSONResponse
        ),
        name: Optional[str] = None,
        openapi_extra: Optional[dict[str, Any]] = None,
        generate_unique_id_function: Callable[[routing.APIRoute], str] = Default(
            _generate_unique_id
        ),
    ) -> None:
        self.router.add_api_route(
            path,
            endpoint=endpoint,
            response_model=response_model,
            status_code=status_code,
            tags=tags,
            dependencies=dependencies,
            summary=summary,
            description=description,
            response_description=response_description,
            responses=responses,
            deprecated=deprecated,
            methods=methods,
            operation_id=operation_id,
            response_model_include=response_model_include,
            response_model_exclude=response_model_exclude,
            response_model_by_alias=response_model_by_alias,
            response_model_exclude_unset=response_model_exclude_unset,
            response_model_exclude_defaults=response_model_exclude_defaults,
            response_model_exclude_none=response_model_exclude_none,
            include_in_schema=include_in_schema,
            response_class=response_class,
            name=name,
            openapi_extra=openapi_extra,
            generate_unique_id_function=generate_unique_id_function,
        )
        # C++ core registration is handled by _sync_routes_to_core() during
        # build_middleware_stack() — no need to register here (avoids double registration).

    def api_route(
        self,
        path: str,
        *,
        response_model: Any = Default(None),
        status_code: Optional[int] = None,
        tags: Optional[list[Union[str, Enum]]] = None,
        dependencies: Optional[Sequence[Depends]] = None,
        summary: Optional[str] = None,
        description: Optional[str] = None,
        response_description: str = "Successful Response",
        responses: Optional[dict[Union[int, str], dict[str, Any]]] = None,
        deprecated: Optional[bool] = None,
        methods: Optional[list[str]] = None,
        operation_id: Optional[str] = None,
        response_model_include: Optional[IncEx] = None,
        response_model_exclude: Optional[IncEx] = None,
        response_model_by_alias: bool = True,
        response_model_exclude_unset: bool = False,
        response_model_exclude_defaults: bool = False,
        response_model_exclude_none: bool = False,
        include_in_schema: bool = True,
        response_class: type[Response] = Default(JSONResponse),
        name: Optional[str] = None,
        openapi_extra: Optional[dict[str, Any]] = None,
        generate_unique_id_function: Callable[[routing.APIRoute], str] = Default(
            _generate_unique_id
        ),
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        def decorator(func: DecoratedCallable) -> DecoratedCallable:
            self.router.add_api_route(
                path,
                func,
                response_model=response_model,
                status_code=status_code,
                tags=tags,
                dependencies=dependencies,
                summary=summary,
                description=description,
                response_description=response_description,
                responses=responses,
                deprecated=deprecated,
                methods=methods,
                operation_id=operation_id,
                response_model_include=response_model_include,
                response_model_exclude=response_model_exclude,
                response_model_by_alias=response_model_by_alias,
                response_model_exclude_unset=response_model_exclude_unset,
                response_model_exclude_defaults=response_model_exclude_defaults,
                response_model_exclude_none=response_model_exclude_none,
                include_in_schema=include_in_schema,
                response_class=response_class,
                name=name,
                openapi_extra=openapi_extra,
                generate_unique_id_function=generate_unique_id_function,
            )
            return func

        return decorator

    def add_api_websocket_route(
        self,
        path: str,
        endpoint: Callable[..., Any],
        name: Optional[str] = None,
        *,
        dependencies: Optional[Sequence[Depends]] = None,
    ) -> None:
        self.router.add_api_websocket_route(
            path,
            endpoint,
            name=name,
            dependencies=dependencies,
        )

    def websocket(
        self,
        path: Annotated[
            str,
            Doc(
                """
                WebSocket path.
                """
            ),
        ],
        name: Annotated[
            Optional[str],
            Doc(
                """
                A name for the WebSocket. Only used internally.
                """
            ),
        ] = None,
        *,
        dependencies: Annotated[
            Optional[Sequence[Depends]],
            Doc(
                """
                A list of dependencies (using `Depends()`) to be used for this
                WebSocket.

                Read more about it in the
                [AstraAPI docs for WebSockets](https://astraapi.tiangolo.com/advanced/websockets/).
                """
            ),
        ] = None,
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        """
        Decorate a WebSocket function.

        Read more about it in the
        [AstraAPI docs for WebSockets](https://astraapi.tiangolo.com/advanced/websockets/).

        **Example**

        ```python
        from astraapi import AstraAPI, WebSocket

        app = AstraAPI()

        @app.websocket("/ws")
        async def websocket_endpoint(websocket: WebSocket):
            await websocket.accept()
            while True:
                data = await websocket.receive_text()
                await websocket.send_text(f"Message text was: {data}")
        ```
        """

        def decorator(func: DecoratedCallable) -> DecoratedCallable:
            self.add_api_websocket_route(
                path,
                func,
                name=name,
                dependencies=dependencies,
            )
            return func

        return decorator

    def include_router(
        self,
        router: Annotated[routing.APIRouter, Doc("The `APIRouter` to include.")],
        *,
        prefix: Annotated[str, Doc("An optional path prefix for the router.")] = "",
        tags: Annotated[
            Optional[list[Union[str, Enum]]],
            Doc(
                """
                A list of tags to be applied to all the *path operations* in this
                router.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        dependencies: Annotated[
            Optional[Sequence[Depends]],
            Doc(
                """
                A list of dependencies (using `Depends()`) to be applied to all the
                *path operations* in this router.

                Read more about it in the
                [AstraAPI docs for Bigger Applications - Multiple Files](https://astraapi.tiangolo.com/tutorial/bigger-applications/#include-an-apirouter-with-a-custom-prefix-tags-responses-and-dependencies).

                **Example**

                ```python
                from astraapi import Depends, AstraAPI

                from .dependencies import get_token_header
                from .internal import admin

                app = AstraAPI()

                app.include_router(
                    admin.router,
                    dependencies=[Depends(get_token_header)],
                )
                ```
                """
            ),
        ] = None,
        responses: Annotated[
            Optional[dict[Union[int, str], dict[str, Any]]],
            Doc(
                """
                Additional responses to be shown in OpenAPI.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Additional Responses in OpenAPI](https://astraapi.tiangolo.com/advanced/additional-responses/).

                And in the
                [AstraAPI docs for Bigger Applications](https://astraapi.tiangolo.com/tutorial/bigger-applications/#include-an-apirouter-with-a-custom-prefix-tags-responses-and-dependencies).
                """
            ),
        ] = None,
        deprecated: Annotated[
            Optional[bool],
            Doc(
                """
                Mark all the *path operations* in this router as deprecated.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                **Example**

                ```python
                from astraapi import AstraAPI

                from .internal import old_api

                app = AstraAPI()

                app.include_router(
                    old_api.router,
                    deprecated=True,
                )
                ```
                """
            ),
        ] = None,
        include_in_schema: Annotated[
            bool,
            Doc(
                """
                Include (or not) all the *path operations* in this router in the
                generated OpenAPI schema.

                This affects the generated OpenAPI (e.g. visible at `/docs`).

                **Example**

                ```python
                from astraapi import AstraAPI

                from .internal import old_api

                app = AstraAPI()

                app.include_router(
                    old_api.router,
                    include_in_schema=False,
                )
                ```
                """
            ),
        ] = True,
        default_response_class: Annotated[
            type[Response],
            Doc(
                """
                Default response class to be used for the *path operations* in this
                router.

                Read more in the
                [AstraAPI docs for Custom Response - HTML, Stream, File, others](https://astraapi.tiangolo.com/advanced/custom-response/#default-response-class).

                **Example**

                ```python
                from astraapi import AstraAPI
                from astraapi.responses import ORJSONResponse

                from .internal import old_api

                app = AstraAPI()

                app.include_router(
                    old_api.router,
                    default_response_class=ORJSONResponse,
                )
                ```
                """
            ),
        ] = Default(JSONResponse),
        callbacks: Annotated[
            Optional[list[BaseRoute]],
            Doc(
                """
                List of *path operations* that will be used as OpenAPI callbacks.

                This is only for OpenAPI documentation, the callbacks won't be used
                directly.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for OpenAPI Callbacks](https://astraapi.tiangolo.com/advanced/openapi-callbacks/).
                """
            ),
        ] = None,
        generate_unique_id_function: Annotated[
            Callable[[routing.APIRoute], str],
            Doc(
                """
                Customize the function used to generate unique IDs for the *path
                operations* shown in the generated OpenAPI.

                This is particularly useful when automatically generating clients or
                SDKs for your API.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = Default(_generate_unique_id),
    ) -> None:
        """
        Include an `APIRouter` in the same app.

        Read more about it in the
        [AstraAPI docs for Bigger Applications](https://astraapi.tiangolo.com/tutorial/bigger-applications/).

        ## Example

        ```python
        from astraapi import AstraAPI

        from .users import users_router

        app = AstraAPI()

        app.include_router(users_router)
        ```
        """
        self.router.include_router(
            router,
            prefix=prefix,
            tags=tags,
            dependencies=dependencies,
            responses=responses,
            deprecated=deprecated,
            include_in_schema=include_in_schema,
            default_response_class=default_response_class,
            callbacks=callbacks,
            generate_unique_id_function=generate_unique_id_function,
        )

    def get(
        self,
        path: Annotated[
            str,
            Doc(
                """
                The URL path to be used for this *path operation*.

                For example, in `http://example.com/items`, the path is `/items`.
                """
            ),
        ],
        *,
        response_model: Annotated[
            Any,
            Doc(
                """
                The type to use for the response.

                It could be any valid Pydantic *field* type. So, it doesn't have to
                be a Pydantic model, it could be other things, like a `list`, `dict`,
                etc.

                It will be used for:

                * Documentation: the generated OpenAPI (and the UI at `/docs`) will
                    show it as the response (JSON Schema).
                * Serialization: you could return an arbitrary object and the
                    `response_model` would be used to serialize that object into the
                    corresponding JSON.
                * Filtering: the JSON sent to the client will only contain the data
                    (fields) defined in the `response_model`. If you returned an object
                    that contains an attribute `password` but the `response_model` does
                    not include that field, the JSON sent to the client would not have
                    that `password`.
                * Validation: whatever you return will be serialized with the
                    `response_model`, converting any data as necessary to generate the
                    corresponding JSON. But if the data in the object returned is not
                    valid, that would mean a violation of the contract with the client,
                    so it's an error from the API developer. So, AstraAPI will raise an
                    error and return a 500 error code (Internal Server Error).

                Read more about it in the
                [AstraAPI docs for Response Model](https://astraapi.tiangolo.com/tutorial/response-model/).
                """
            ),
        ] = Default(None),
        status_code: Annotated[
            Optional[int],
            Doc(
                """
                The default status code to be used for the response.

                You could override the status code by returning a response directly.

                Read more about it in the
                [AstraAPI docs for Response Status Code](https://astraapi.tiangolo.com/tutorial/response-status-code/).
                """
            ),
        ] = None,
        tags: Annotated[
            Optional[list[Union[str, Enum]]],
            Doc(
                """
                A list of tags to be applied to the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/#tags).
                """
            ),
        ] = None,
        dependencies: Annotated[
            Optional[Sequence[Depends]],
            Doc(
                """
                A list of dependencies (using `Depends()`) to be applied to the
                *path operation*.

                Read more about it in the
                [AstraAPI docs for Dependencies in path operation decorators](https://astraapi.tiangolo.com/tutorial/dependencies/dependencies-in-path-operation-decorators/).
                """
            ),
        ] = None,
        summary: Annotated[
            Optional[str],
            Doc(
                """
                A summary for the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        description: Annotated[
            Optional[str],
            Doc(
                """
                A description for the *path operation*.

                If not provided, it will be extracted automatically from the docstring
                of the *path operation function*.

                It can contain Markdown.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        response_description: Annotated[
            str,
            Doc(
                """
                The description for the default response.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = "Successful Response",
        responses: Annotated[
            Optional[dict[Union[int, str], dict[str, Any]]],
            Doc(
                """
                Additional responses that could be returned by this *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        deprecated: Annotated[
            Optional[bool],
            Doc(
                """
                Mark this *path operation* as deprecated.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        operation_id: Annotated[
            Optional[str],
            Doc(
                """
                Custom operation ID to be used by this *path operation*.

                By default, it is generated automatically.

                If you provide a custom operation ID, you need to make sure it is
                unique for the whole API.

                You can customize the
                operation ID generation with the parameter
                `generate_unique_id_function` in the `AstraAPI` class.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = None,
        response_model_include: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to include only certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_exclude: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to exclude certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_by_alias: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response model
                should be serialized by alias when an alias is used.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = True,
        response_model_exclude_unset: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that were not set and
                have their default values. This is different from
                `response_model_exclude_defaults` in that if the fields are set,
                they will be included in the response, even if the value is the same
                as the default.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_defaults: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that have the same value
                as the default. This is different from `response_model_exclude_unset`
                in that if the fields are set but contain the same default values,
                they will be excluded from the response.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_none: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data should
                exclude fields set to `None`.

                This is much simpler (less smart) than `response_model_exclude_unset`
                and `response_model_exclude_defaults`. You probably want to use one of
                those two instead of this one, as those allow returning `None` values
                when it makes sense.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_exclude_none).
                """
            ),
        ] = False,
        include_in_schema: Annotated[
            bool,
            Doc(
                """
                Include this *path operation* in the generated OpenAPI schema.

                This affects the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Query Parameters and String Validations](https://astraapi.tiangolo.com/tutorial/query-params-str-validations/#exclude-parameters-from-openapi).
                """
            ),
        ] = True,
        response_class: Annotated[
            type[Response],
            Doc(
                """
                Response class to be used for this *path operation*.

                This will not be used if you return a response directly.

                Read more about it in the
                [AstraAPI docs for Custom Response - HTML, Stream, File, others](https://astraapi.tiangolo.com/advanced/custom-response/#redirectresponse).
                """
            ),
        ] = Default(JSONResponse),
        name: Annotated[
            Optional[str],
            Doc(
                """
                Name for this *path operation*. Only used internally.
                """
            ),
        ] = None,
        callbacks: Annotated[
            Optional[list[BaseRoute]],
            Doc(
                """
                List of *path operations* that will be used as OpenAPI callbacks.

                This is only for OpenAPI documentation, the callbacks won't be used
                directly.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for OpenAPI Callbacks](https://astraapi.tiangolo.com/advanced/openapi-callbacks/).
                """
            ),
        ] = None,
        openapi_extra: Annotated[
            Optional[dict[str, Any]],
            Doc(
                """
                Extra metadata to be included in the OpenAPI schema for this *path
                operation*.

                Read more about it in the
                [AstraAPI docs for Path Operation Advanced Configuration](https://astraapi.tiangolo.com/advanced/path-operation-advanced-configuration/#custom-openapi-path-operation-schema).
                """
            ),
        ] = None,
        generate_unique_id_function: Annotated[
            Callable[[routing.APIRoute], str],
            Doc(
                """
                Customize the function used to generate unique IDs for the *path
                operations* shown in the generated OpenAPI.

                This is particularly useful when automatically generating clients or
                SDKs for your API.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = Default(_generate_unique_id),
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        """
        Add a *path operation* using an HTTP GET operation.

        ## Example

        ```python
        from astraapi import AstraAPI

        app = AstraAPI()

        @app.get("/items/")
        def read_items():
            return [{"name": "Empanada"}, {"name": "Arepa"}]
        ```
        """
        return self.router.get(
            path,
            response_model=response_model,
            status_code=status_code,
            tags=tags,
            dependencies=dependencies,
            summary=summary,
            description=description,
            response_description=response_description,
            responses=responses,
            deprecated=deprecated,
            operation_id=operation_id,
            response_model_include=response_model_include,
            response_model_exclude=response_model_exclude,
            response_model_by_alias=response_model_by_alias,
            response_model_exclude_unset=response_model_exclude_unset,
            response_model_exclude_defaults=response_model_exclude_defaults,
            response_model_exclude_none=response_model_exclude_none,
            include_in_schema=include_in_schema,
            response_class=response_class,
            name=name,
            callbacks=callbacks,
            openapi_extra=openapi_extra,
            generate_unique_id_function=generate_unique_id_function,
        )

    def put(
        self,
        path: Annotated[
            str,
            Doc(
                """
                The URL path to be used for this *path operation*.

                For example, in `http://example.com/items`, the path is `/items`.
                """
            ),
        ],
        *,
        response_model: Annotated[
            Any,
            Doc(
                """
                The type to use for the response.

                It could be any valid Pydantic *field* type. So, it doesn't have to
                be a Pydantic model, it could be other things, like a `list`, `dict`,
                etc.

                It will be used for:

                * Documentation: the generated OpenAPI (and the UI at `/docs`) will
                    show it as the response (JSON Schema).
                * Serialization: you could return an arbitrary object and the
                    `response_model` would be used to serialize that object into the
                    corresponding JSON.
                * Filtering: the JSON sent to the client will only contain the data
                    (fields) defined in the `response_model`. If you returned an object
                    that contains an attribute `password` but the `response_model` does
                    not include that field, the JSON sent to the client would not have
                    that `password`.
                * Validation: whatever you return will be serialized with the
                    `response_model`, converting any data as necessary to generate the
                    corresponding JSON. But if the data in the object returned is not
                    valid, that would mean a violation of the contract with the client,
                    so it's an error from the API developer. So, AstraAPI will raise an
                    error and return a 500 error code (Internal Server Error).

                Read more about it in the
                [AstraAPI docs for Response Model](https://astraapi.tiangolo.com/tutorial/response-model/).
                """
            ),
        ] = Default(None),
        status_code: Annotated[
            Optional[int],
            Doc(
                """
                The default status code to be used for the response.

                You could override the status code by returning a response directly.

                Read more about it in the
                [AstraAPI docs for Response Status Code](https://astraapi.tiangolo.com/tutorial/response-status-code/).
                """
            ),
        ] = None,
        tags: Annotated[
            Optional[list[Union[str, Enum]]],
            Doc(
                """
                A list of tags to be applied to the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/#tags).
                """
            ),
        ] = None,
        dependencies: Annotated[
            Optional[Sequence[Depends]],
            Doc(
                """
                A list of dependencies (using `Depends()`) to be applied to the
                *path operation*.

                Read more about it in the
                [AstraAPI docs for Dependencies in path operation decorators](https://astraapi.tiangolo.com/tutorial/dependencies/dependencies-in-path-operation-decorators/).
                """
            ),
        ] = None,
        summary: Annotated[
            Optional[str],
            Doc(
                """
                A summary for the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        description: Annotated[
            Optional[str],
            Doc(
                """
                A description for the *path operation*.

                If not provided, it will be extracted automatically from the docstring
                of the *path operation function*.

                It can contain Markdown.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        response_description: Annotated[
            str,
            Doc(
                """
                The description for the default response.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = "Successful Response",
        responses: Annotated[
            Optional[dict[Union[int, str], dict[str, Any]]],
            Doc(
                """
                Additional responses that could be returned by this *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        deprecated: Annotated[
            Optional[bool],
            Doc(
                """
                Mark this *path operation* as deprecated.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        operation_id: Annotated[
            Optional[str],
            Doc(
                """
                Custom operation ID to be used by this *path operation*.

                By default, it is generated automatically.

                If you provide a custom operation ID, you need to make sure it is
                unique for the whole API.

                You can customize the
                operation ID generation with the parameter
                `generate_unique_id_function` in the `AstraAPI` class.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = None,
        response_model_include: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to include only certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_exclude: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to exclude certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_by_alias: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response model
                should be serialized by alias when an alias is used.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = True,
        response_model_exclude_unset: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that were not set and
                have their default values. This is different from
                `response_model_exclude_defaults` in that if the fields are set,
                they will be included in the response, even if the value is the same
                as the default.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_defaults: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that have the same value
                as the default. This is different from `response_model_exclude_unset`
                in that if the fields are set but contain the same default values,
                they will be excluded from the response.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_none: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data should
                exclude fields set to `None`.

                This is much simpler (less smart) than `response_model_exclude_unset`
                and `response_model_exclude_defaults`. You probably want to use one of
                those two instead of this one, as those allow returning `None` values
                when it makes sense.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_exclude_none).
                """
            ),
        ] = False,
        include_in_schema: Annotated[
            bool,
            Doc(
                """
                Include this *path operation* in the generated OpenAPI schema.

                This affects the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Query Parameters and String Validations](https://astraapi.tiangolo.com/tutorial/query-params-str-validations/#exclude-parameters-from-openapi).
                """
            ),
        ] = True,
        response_class: Annotated[
            type[Response],
            Doc(
                """
                Response class to be used for this *path operation*.

                This will not be used if you return a response directly.

                Read more about it in the
                [AstraAPI docs for Custom Response - HTML, Stream, File, others](https://astraapi.tiangolo.com/advanced/custom-response/#redirectresponse).
                """
            ),
        ] = Default(JSONResponse),
        name: Annotated[
            Optional[str],
            Doc(
                """
                Name for this *path operation*. Only used internally.
                """
            ),
        ] = None,
        callbacks: Annotated[
            Optional[list[BaseRoute]],
            Doc(
                """
                List of *path operations* that will be used as OpenAPI callbacks.

                This is only for OpenAPI documentation, the callbacks won't be used
                directly.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for OpenAPI Callbacks](https://astraapi.tiangolo.com/advanced/openapi-callbacks/).
                """
            ),
        ] = None,
        openapi_extra: Annotated[
            Optional[dict[str, Any]],
            Doc(
                """
                Extra metadata to be included in the OpenAPI schema for this *path
                operation*.

                Read more about it in the
                [AstraAPI docs for Path Operation Advanced Configuration](https://astraapi.tiangolo.com/advanced/path-operation-advanced-configuration/#custom-openapi-path-operation-schema).
                """
            ),
        ] = None,
        generate_unique_id_function: Annotated[
            Callable[[routing.APIRoute], str],
            Doc(
                """
                Customize the function used to generate unique IDs for the *path
                operations* shown in the generated OpenAPI.

                This is particularly useful when automatically generating clients or
                SDKs for your API.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = Default(_generate_unique_id),
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        """
        Add a *path operation* using an HTTP PUT operation.

        ## Example

        ```python
        from astraapi import AstraAPI
        from pydantic import BaseModel

        class Item(BaseModel):
            name: str
            description: str | None = None

        app = AstraAPI()

        @app.put("/items/{item_id}")
        def replace_item(item_id: str, item: Item):
            return {"message": "Item replaced", "id": item_id}
        ```
        """
        return self.router.put(
            path,
            response_model=response_model,
            status_code=status_code,
            tags=tags,
            dependencies=dependencies,
            summary=summary,
            description=description,
            response_description=response_description,
            responses=responses,
            deprecated=deprecated,
            operation_id=operation_id,
            response_model_include=response_model_include,
            response_model_exclude=response_model_exclude,
            response_model_by_alias=response_model_by_alias,
            response_model_exclude_unset=response_model_exclude_unset,
            response_model_exclude_defaults=response_model_exclude_defaults,
            response_model_exclude_none=response_model_exclude_none,
            include_in_schema=include_in_schema,
            response_class=response_class,
            name=name,
            callbacks=callbacks,
            openapi_extra=openapi_extra,
            generate_unique_id_function=generate_unique_id_function,
        )

    def post(
        self,
        path: Annotated[
            str,
            Doc(
                """
                The URL path to be used for this *path operation*.

                For example, in `http://example.com/items`, the path is `/items`.
                """
            ),
        ],
        *,
        response_model: Annotated[
            Any,
            Doc(
                """
                The type to use for the response.

                It could be any valid Pydantic *field* type. So, it doesn't have to
                be a Pydantic model, it could be other things, like a `list`, `dict`,
                etc.

                It will be used for:

                * Documentation: the generated OpenAPI (and the UI at `/docs`) will
                    show it as the response (JSON Schema).
                * Serialization: you could return an arbitrary object and the
                    `response_model` would be used to serialize that object into the
                    corresponding JSON.
                * Filtering: the JSON sent to the client will only contain the data
                    (fields) defined in the `response_model`. If you returned an object
                    that contains an attribute `password` but the `response_model` does
                    not include that field, the JSON sent to the client would not have
                    that `password`.
                * Validation: whatever you return will be serialized with the
                    `response_model`, converting any data as necessary to generate the
                    corresponding JSON. But if the data in the object returned is not
                    valid, that would mean a violation of the contract with the client,
                    so it's an error from the API developer. So, AstraAPI will raise an
                    error and return a 500 error code (Internal Server Error).

                Read more about it in the
                [AstraAPI docs for Response Model](https://astraapi.tiangolo.com/tutorial/response-model/).
                """
            ),
        ] = Default(None),
        status_code: Annotated[
            Optional[int],
            Doc(
                """
                The default status code to be used for the response.

                You could override the status code by returning a response directly.

                Read more about it in the
                [AstraAPI docs for Response Status Code](https://astraapi.tiangolo.com/tutorial/response-status-code/).
                """
            ),
        ] = None,
        tags: Annotated[
            Optional[list[Union[str, Enum]]],
            Doc(
                """
                A list of tags to be applied to the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/#tags).
                """
            ),
        ] = None,
        dependencies: Annotated[
            Optional[Sequence[Depends]],
            Doc(
                """
                A list of dependencies (using `Depends()`) to be applied to the
                *path operation*.

                Read more about it in the
                [AstraAPI docs for Dependencies in path operation decorators](https://astraapi.tiangolo.com/tutorial/dependencies/dependencies-in-path-operation-decorators/).
                """
            ),
        ] = None,
        summary: Annotated[
            Optional[str],
            Doc(
                """
                A summary for the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        description: Annotated[
            Optional[str],
            Doc(
                """
                A description for the *path operation*.

                If not provided, it will be extracted automatically from the docstring
                of the *path operation function*.

                It can contain Markdown.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        response_description: Annotated[
            str,
            Doc(
                """
                The description for the default response.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = "Successful Response",
        responses: Annotated[
            Optional[dict[Union[int, str], dict[str, Any]]],
            Doc(
                """
                Additional responses that could be returned by this *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        deprecated: Annotated[
            Optional[bool],
            Doc(
                """
                Mark this *path operation* as deprecated.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        operation_id: Annotated[
            Optional[str],
            Doc(
                """
                Custom operation ID to be used by this *path operation*.

                By default, it is generated automatically.

                If you provide a custom operation ID, you need to make sure it is
                unique for the whole API.

                You can customize the
                operation ID generation with the parameter
                `generate_unique_id_function` in the `AstraAPI` class.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = None,
        response_model_include: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to include only certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_exclude: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to exclude certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_by_alias: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response model
                should be serialized by alias when an alias is used.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = True,
        response_model_exclude_unset: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that were not set and
                have their default values. This is different from
                `response_model_exclude_defaults` in that if the fields are set,
                they will be included in the response, even if the value is the same
                as the default.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_defaults: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that have the same value
                as the default. This is different from `response_model_exclude_unset`
                in that if the fields are set but contain the same default values,
                they will be excluded from the response.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_none: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data should
                exclude fields set to `None`.

                This is much simpler (less smart) than `response_model_exclude_unset`
                and `response_model_exclude_defaults`. You probably want to use one of
                those two instead of this one, as those allow returning `None` values
                when it makes sense.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_exclude_none).
                """
            ),
        ] = False,
        include_in_schema: Annotated[
            bool,
            Doc(
                """
                Include this *path operation* in the generated OpenAPI schema.

                This affects the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Query Parameters and String Validations](https://astraapi.tiangolo.com/tutorial/query-params-str-validations/#exclude-parameters-from-openapi).
                """
            ),
        ] = True,
        response_class: Annotated[
            type[Response],
            Doc(
                """
                Response class to be used for this *path operation*.

                This will not be used if you return a response directly.

                Read more about it in the
                [AstraAPI docs for Custom Response - HTML, Stream, File, others](https://astraapi.tiangolo.com/advanced/custom-response/#redirectresponse).
                """
            ),
        ] = Default(JSONResponse),
        name: Annotated[
            Optional[str],
            Doc(
                """
                Name for this *path operation*. Only used internally.
                """
            ),
        ] = None,
        callbacks: Annotated[
            Optional[list[BaseRoute]],
            Doc(
                """
                List of *path operations* that will be used as OpenAPI callbacks.

                This is only for OpenAPI documentation, the callbacks won't be used
                directly.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for OpenAPI Callbacks](https://astraapi.tiangolo.com/advanced/openapi-callbacks/).
                """
            ),
        ] = None,
        openapi_extra: Annotated[
            Optional[dict[str, Any]],
            Doc(
                """
                Extra metadata to be included in the OpenAPI schema for this *path
                operation*.

                Read more about it in the
                [AstraAPI docs for Path Operation Advanced Configuration](https://astraapi.tiangolo.com/advanced/path-operation-advanced-configuration/#custom-openapi-path-operation-schema).
                """
            ),
        ] = None,
        generate_unique_id_function: Annotated[
            Callable[[routing.APIRoute], str],
            Doc(
                """
                Customize the function used to generate unique IDs for the *path
                operations* shown in the generated OpenAPI.

                This is particularly useful when automatically generating clients or
                SDKs for your API.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = Default(_generate_unique_id),
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        """
        Add a *path operation* using an HTTP POST operation.

        ## Example

        ```python
        from astraapi import AstraAPI
        from pydantic import BaseModel

        class Item(BaseModel):
            name: str
            description: str | None = None

        app = AstraAPI()

        @app.post("/items/")
        def create_item(item: Item):
            return {"message": "Item created"}
        ```
        """
        return self.router.post(
            path,
            response_model=response_model,
            status_code=status_code,
            tags=tags,
            dependencies=dependencies,
            summary=summary,
            description=description,
            response_description=response_description,
            responses=responses,
            deprecated=deprecated,
            operation_id=operation_id,
            response_model_include=response_model_include,
            response_model_exclude=response_model_exclude,
            response_model_by_alias=response_model_by_alias,
            response_model_exclude_unset=response_model_exclude_unset,
            response_model_exclude_defaults=response_model_exclude_defaults,
            response_model_exclude_none=response_model_exclude_none,
            include_in_schema=include_in_schema,
            response_class=response_class,
            name=name,
            callbacks=callbacks,
            openapi_extra=openapi_extra,
            generate_unique_id_function=generate_unique_id_function,
        )

    def delete(
        self,
        path: Annotated[
            str,
            Doc(
                """
                The URL path to be used for this *path operation*.

                For example, in `http://example.com/items`, the path is `/items`.
                """
            ),
        ],
        *,
        response_model: Annotated[
            Any,
            Doc(
                """
                The type to use for the response.

                It could be any valid Pydantic *field* type. So, it doesn't have to
                be a Pydantic model, it could be other things, like a `list`, `dict`,
                etc.

                It will be used for:

                * Documentation: the generated OpenAPI (and the UI at `/docs`) will
                    show it as the response (JSON Schema).
                * Serialization: you could return an arbitrary object and the
                    `response_model` would be used to serialize that object into the
                    corresponding JSON.
                * Filtering: the JSON sent to the client will only contain the data
                    (fields) defined in the `response_model`. If you returned an object
                    that contains an attribute `password` but the `response_model` does
                    not include that field, the JSON sent to the client would not have
                    that `password`.
                * Validation: whatever you return will be serialized with the
                    `response_model`, converting any data as necessary to generate the
                    corresponding JSON. But if the data in the object returned is not
                    valid, that would mean a violation of the contract with the client,
                    so it's an error from the API developer. So, AstraAPI will raise an
                    error and return a 500 error code (Internal Server Error).

                Read more about it in the
                [AstraAPI docs for Response Model](https://astraapi.tiangolo.com/tutorial/response-model/).
                """
            ),
        ] = Default(None),
        status_code: Annotated[
            Optional[int],
            Doc(
                """
                The default status code to be used for the response.

                You could override the status code by returning a response directly.

                Read more about it in the
                [AstraAPI docs for Response Status Code](https://astraapi.tiangolo.com/tutorial/response-status-code/).
                """
            ),
        ] = None,
        tags: Annotated[
            Optional[list[Union[str, Enum]]],
            Doc(
                """
                A list of tags to be applied to the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/#tags).
                """
            ),
        ] = None,
        dependencies: Annotated[
            Optional[Sequence[Depends]],
            Doc(
                """
                A list of dependencies (using `Depends()`) to be applied to the
                *path operation*.

                Read more about it in the
                [AstraAPI docs for Dependencies in path operation decorators](https://astraapi.tiangolo.com/tutorial/dependencies/dependencies-in-path-operation-decorators/).
                """
            ),
        ] = None,
        summary: Annotated[
            Optional[str],
            Doc(
                """
                A summary for the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        description: Annotated[
            Optional[str],
            Doc(
                """
                A description for the *path operation*.

                If not provided, it will be extracted automatically from the docstring
                of the *path operation function*.

                It can contain Markdown.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        response_description: Annotated[
            str,
            Doc(
                """
                The description for the default response.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = "Successful Response",
        responses: Annotated[
            Optional[dict[Union[int, str], dict[str, Any]]],
            Doc(
                """
                Additional responses that could be returned by this *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        deprecated: Annotated[
            Optional[bool],
            Doc(
                """
                Mark this *path operation* as deprecated.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        operation_id: Annotated[
            Optional[str],
            Doc(
                """
                Custom operation ID to be used by this *path operation*.

                By default, it is generated automatically.

                If you provide a custom operation ID, you need to make sure it is
                unique for the whole API.

                You can customize the
                operation ID generation with the parameter
                `generate_unique_id_function` in the `AstraAPI` class.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = None,
        response_model_include: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to include only certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_exclude: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to exclude certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_by_alias: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response model
                should be serialized by alias when an alias is used.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = True,
        response_model_exclude_unset: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that were not set and
                have their default values. This is different from
                `response_model_exclude_defaults` in that if the fields are set,
                they will be included in the response, even if the value is the same
                as the default.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_defaults: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that have the same value
                as the default. This is different from `response_model_exclude_unset`
                in that if the fields are set but contain the same default values,
                they will be excluded from the response.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_none: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data should
                exclude fields set to `None`.

                This is much simpler (less smart) than `response_model_exclude_unset`
                and `response_model_exclude_defaults`. You probably want to use one of
                those two instead of this one, as those allow returning `None` values
                when it makes sense.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_exclude_none).
                """
            ),
        ] = False,
        include_in_schema: Annotated[
            bool,
            Doc(
                """
                Include this *path operation* in the generated OpenAPI schema.

                This affects the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Query Parameters and String Validations](https://astraapi.tiangolo.com/tutorial/query-params-str-validations/#exclude-parameters-from-openapi).
                """
            ),
        ] = True,
        response_class: Annotated[
            type[Response],
            Doc(
                """
                Response class to be used for this *path operation*.

                This will not be used if you return a response directly.

                Read more about it in the
                [AstraAPI docs for Custom Response - HTML, Stream, File, others](https://astraapi.tiangolo.com/advanced/custom-response/#redirectresponse).
                """
            ),
        ] = Default(JSONResponse),
        name: Annotated[
            Optional[str],
            Doc(
                """
                Name for this *path operation*. Only used internally.
                """
            ),
        ] = None,
        callbacks: Annotated[
            Optional[list[BaseRoute]],
            Doc(
                """
                List of *path operations* that will be used as OpenAPI callbacks.

                This is only for OpenAPI documentation, the callbacks won't be used
                directly.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for OpenAPI Callbacks](https://astraapi.tiangolo.com/advanced/openapi-callbacks/).
                """
            ),
        ] = None,
        openapi_extra: Annotated[
            Optional[dict[str, Any]],
            Doc(
                """
                Extra metadata to be included in the OpenAPI schema for this *path
                operation*.

                Read more about it in the
                [AstraAPI docs for Path Operation Advanced Configuration](https://astraapi.tiangolo.com/advanced/path-operation-advanced-configuration/#custom-openapi-path-operation-schema).
                """
            ),
        ] = None,
        generate_unique_id_function: Annotated[
            Callable[[routing.APIRoute], str],
            Doc(
                """
                Customize the function used to generate unique IDs for the *path
                operations* shown in the generated OpenAPI.

                This is particularly useful when automatically generating clients or
                SDKs for your API.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = Default(_generate_unique_id),
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        """
        Add a *path operation* using an HTTP DELETE operation.

        ## Example

        ```python
        from astraapi import AstraAPI

        app = AstraAPI()

        @app.delete("/items/{item_id}")
        def delete_item(item_id: str):
            return {"message": "Item deleted"}
        ```
        """
        return self.router.delete(
            path,
            response_model=response_model,
            status_code=status_code,
            tags=tags,
            dependencies=dependencies,
            summary=summary,
            description=description,
            response_description=response_description,
            responses=responses,
            deprecated=deprecated,
            operation_id=operation_id,
            response_model_include=response_model_include,
            response_model_exclude=response_model_exclude,
            response_model_by_alias=response_model_by_alias,
            response_model_exclude_unset=response_model_exclude_unset,
            response_model_exclude_defaults=response_model_exclude_defaults,
            response_model_exclude_none=response_model_exclude_none,
            include_in_schema=include_in_schema,
            response_class=response_class,
            name=name,
            callbacks=callbacks,
            openapi_extra=openapi_extra,
            generate_unique_id_function=generate_unique_id_function,
        )

    def options(
        self,
        path: Annotated[
            str,
            Doc(
                """
                The URL path to be used for this *path operation*.

                For example, in `http://example.com/items`, the path is `/items`.
                """
            ),
        ],
        *,
        response_model: Annotated[
            Any,
            Doc(
                """
                The type to use for the response.

                It could be any valid Pydantic *field* type. So, it doesn't have to
                be a Pydantic model, it could be other things, like a `list`, `dict`,
                etc.

                It will be used for:

                * Documentation: the generated OpenAPI (and the UI at `/docs`) will
                    show it as the response (JSON Schema).
                * Serialization: you could return an arbitrary object and the
                    `response_model` would be used to serialize that object into the
                    corresponding JSON.
                * Filtering: the JSON sent to the client will only contain the data
                    (fields) defined in the `response_model`. If you returned an object
                    that contains an attribute `password` but the `response_model` does
                    not include that field, the JSON sent to the client would not have
                    that `password`.
                * Validation: whatever you return will be serialized with the
                    `response_model`, converting any data as necessary to generate the
                    corresponding JSON. But if the data in the object returned is not
                    valid, that would mean a violation of the contract with the client,
                    so it's an error from the API developer. So, AstraAPI will raise an
                    error and return a 500 error code (Internal Server Error).

                Read more about it in the
                [AstraAPI docs for Response Model](https://astraapi.tiangolo.com/tutorial/response-model/).
                """
            ),
        ] = Default(None),
        status_code: Annotated[
            Optional[int],
            Doc(
                """
                The default status code to be used for the response.

                You could override the status code by returning a response directly.

                Read more about it in the
                [AstraAPI docs for Response Status Code](https://astraapi.tiangolo.com/tutorial/response-status-code/).
                """
            ),
        ] = None,
        tags: Annotated[
            Optional[list[Union[str, Enum]]],
            Doc(
                """
                A list of tags to be applied to the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/#tags).
                """
            ),
        ] = None,
        dependencies: Annotated[
            Optional[Sequence[Depends]],
            Doc(
                """
                A list of dependencies (using `Depends()`) to be applied to the
                *path operation*.

                Read more about it in the
                [AstraAPI docs for Dependencies in path operation decorators](https://astraapi.tiangolo.com/tutorial/dependencies/dependencies-in-path-operation-decorators/).
                """
            ),
        ] = None,
        summary: Annotated[
            Optional[str],
            Doc(
                """
                A summary for the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        description: Annotated[
            Optional[str],
            Doc(
                """
                A description for the *path operation*.

                If not provided, it will be extracted automatically from the docstring
                of the *path operation function*.

                It can contain Markdown.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        response_description: Annotated[
            str,
            Doc(
                """
                The description for the default response.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = "Successful Response",
        responses: Annotated[
            Optional[dict[Union[int, str], dict[str, Any]]],
            Doc(
                """
                Additional responses that could be returned by this *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        deprecated: Annotated[
            Optional[bool],
            Doc(
                """
                Mark this *path operation* as deprecated.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        operation_id: Annotated[
            Optional[str],
            Doc(
                """
                Custom operation ID to be used by this *path operation*.

                By default, it is generated automatically.

                If you provide a custom operation ID, you need to make sure it is
                unique for the whole API.

                You can customize the
                operation ID generation with the parameter
                `generate_unique_id_function` in the `AstraAPI` class.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = None,
        response_model_include: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to include only certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_exclude: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to exclude certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_by_alias: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response model
                should be serialized by alias when an alias is used.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = True,
        response_model_exclude_unset: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that were not set and
                have their default values. This is different from
                `response_model_exclude_defaults` in that if the fields are set,
                they will be included in the response, even if the value is the same
                as the default.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_defaults: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that have the same value
                as the default. This is different from `response_model_exclude_unset`
                in that if the fields are set but contain the same default values,
                they will be excluded from the response.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_none: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data should
                exclude fields set to `None`.

                This is much simpler (less smart) than `response_model_exclude_unset`
                and `response_model_exclude_defaults`. You probably want to use one of
                those two instead of this one, as those allow returning `None` values
                when it makes sense.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_exclude_none).
                """
            ),
        ] = False,
        include_in_schema: Annotated[
            bool,
            Doc(
                """
                Include this *path operation* in the generated OpenAPI schema.

                This affects the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Query Parameters and String Validations](https://astraapi.tiangolo.com/tutorial/query-params-str-validations/#exclude-parameters-from-openapi).
                """
            ),
        ] = True,
        response_class: Annotated[
            type[Response],
            Doc(
                """
                Response class to be used for this *path operation*.

                This will not be used if you return a response directly.

                Read more about it in the
                [AstraAPI docs for Custom Response - HTML, Stream, File, others](https://astraapi.tiangolo.com/advanced/custom-response/#redirectresponse).
                """
            ),
        ] = Default(JSONResponse),
        name: Annotated[
            Optional[str],
            Doc(
                """
                Name for this *path operation*. Only used internally.
                """
            ),
        ] = None,
        callbacks: Annotated[
            Optional[list[BaseRoute]],
            Doc(
                """
                List of *path operations* that will be used as OpenAPI callbacks.

                This is only for OpenAPI documentation, the callbacks won't be used
                directly.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for OpenAPI Callbacks](https://astraapi.tiangolo.com/advanced/openapi-callbacks/).
                """
            ),
        ] = None,
        openapi_extra: Annotated[
            Optional[dict[str, Any]],
            Doc(
                """
                Extra metadata to be included in the OpenAPI schema for this *path
                operation*.

                Read more about it in the
                [AstraAPI docs for Path Operation Advanced Configuration](https://astraapi.tiangolo.com/advanced/path-operation-advanced-configuration/#custom-openapi-path-operation-schema).
                """
            ),
        ] = None,
        generate_unique_id_function: Annotated[
            Callable[[routing.APIRoute], str],
            Doc(
                """
                Customize the function used to generate unique IDs for the *path
                operations* shown in the generated OpenAPI.

                This is particularly useful when automatically generating clients or
                SDKs for your API.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = Default(_generate_unique_id),
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        """
        Add a *path operation* using an HTTP OPTIONS operation.

        ## Example

        ```python
        from astraapi import AstraAPI

        app = AstraAPI()

        @app.options("/items/")
        def get_item_options():
            return {"additions": ["Aji", "Guacamole"]}
        ```
        """
        return self.router.options(
            path,
            response_model=response_model,
            status_code=status_code,
            tags=tags,
            dependencies=dependencies,
            summary=summary,
            description=description,
            response_description=response_description,
            responses=responses,
            deprecated=deprecated,
            operation_id=operation_id,
            response_model_include=response_model_include,
            response_model_exclude=response_model_exclude,
            response_model_by_alias=response_model_by_alias,
            response_model_exclude_unset=response_model_exclude_unset,
            response_model_exclude_defaults=response_model_exclude_defaults,
            response_model_exclude_none=response_model_exclude_none,
            include_in_schema=include_in_schema,
            response_class=response_class,
            name=name,
            callbacks=callbacks,
            openapi_extra=openapi_extra,
            generate_unique_id_function=generate_unique_id_function,
        )

    def head(
        self,
        path: Annotated[
            str,
            Doc(
                """
                The URL path to be used for this *path operation*.

                For example, in `http://example.com/items`, the path is `/items`.
                """
            ),
        ],
        *,
        response_model: Annotated[
            Any,
            Doc(
                """
                The type to use for the response.

                It could be any valid Pydantic *field* type. So, it doesn't have to
                be a Pydantic model, it could be other things, like a `list`, `dict`,
                etc.

                It will be used for:

                * Documentation: the generated OpenAPI (and the UI at `/docs`) will
                    show it as the response (JSON Schema).
                * Serialization: you could return an arbitrary object and the
                    `response_model` would be used to serialize that object into the
                    corresponding JSON.
                * Filtering: the JSON sent to the client will only contain the data
                    (fields) defined in the `response_model`. If you returned an object
                    that contains an attribute `password` but the `response_model` does
                    not include that field, the JSON sent to the client would not have
                    that `password`.
                * Validation: whatever you return will be serialized with the
                    `response_model`, converting any data as necessary to generate the
                    corresponding JSON. But if the data in the object returned is not
                    valid, that would mean a violation of the contract with the client,
                    so it's an error from the API developer. So, AstraAPI will raise an
                    error and return a 500 error code (Internal Server Error).

                Read more about it in the
                [AstraAPI docs for Response Model](https://astraapi.tiangolo.com/tutorial/response-model/).
                """
            ),
        ] = Default(None),
        status_code: Annotated[
            Optional[int],
            Doc(
                """
                The default status code to be used for the response.

                You could override the status code by returning a response directly.

                Read more about it in the
                [AstraAPI docs for Response Status Code](https://astraapi.tiangolo.com/tutorial/response-status-code/).
                """
            ),
        ] = None,
        tags: Annotated[
            Optional[list[Union[str, Enum]]],
            Doc(
                """
                A list of tags to be applied to the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/#tags).
                """
            ),
        ] = None,
        dependencies: Annotated[
            Optional[Sequence[Depends]],
            Doc(
                """
                A list of dependencies (using `Depends()`) to be applied to the
                *path operation*.

                Read more about it in the
                [AstraAPI docs for Dependencies in path operation decorators](https://astraapi.tiangolo.com/tutorial/dependencies/dependencies-in-path-operation-decorators/).
                """
            ),
        ] = None,
        summary: Annotated[
            Optional[str],
            Doc(
                """
                A summary for the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        description: Annotated[
            Optional[str],
            Doc(
                """
                A description for the *path operation*.

                If not provided, it will be extracted automatically from the docstring
                of the *path operation function*.

                It can contain Markdown.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        response_description: Annotated[
            str,
            Doc(
                """
                The description for the default response.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = "Successful Response",
        responses: Annotated[
            Optional[dict[Union[int, str], dict[str, Any]]],
            Doc(
                """
                Additional responses that could be returned by this *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        deprecated: Annotated[
            Optional[bool],
            Doc(
                """
                Mark this *path operation* as deprecated.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        operation_id: Annotated[
            Optional[str],
            Doc(
                """
                Custom operation ID to be used by this *path operation*.

                By default, it is generated automatically.

                If you provide a custom operation ID, you need to make sure it is
                unique for the whole API.

                You can customize the
                operation ID generation with the parameter
                `generate_unique_id_function` in the `AstraAPI` class.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = None,
        response_model_include: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to include only certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_exclude: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to exclude certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_by_alias: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response model
                should be serialized by alias when an alias is used.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = True,
        response_model_exclude_unset: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that were not set and
                have their default values. This is different from
                `response_model_exclude_defaults` in that if the fields are set,
                they will be included in the response, even if the value is the same
                as the default.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_defaults: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that have the same value
                as the default. This is different from `response_model_exclude_unset`
                in that if the fields are set but contain the same default values,
                they will be excluded from the response.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_none: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data should
                exclude fields set to `None`.

                This is much simpler (less smart) than `response_model_exclude_unset`
                and `response_model_exclude_defaults`. You probably want to use one of
                those two instead of this one, as those allow returning `None` values
                when it makes sense.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_exclude_none).
                """
            ),
        ] = False,
        include_in_schema: Annotated[
            bool,
            Doc(
                """
                Include this *path operation* in the generated OpenAPI schema.

                This affects the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Query Parameters and String Validations](https://astraapi.tiangolo.com/tutorial/query-params-str-validations/#exclude-parameters-from-openapi).
                """
            ),
        ] = True,
        response_class: Annotated[
            type[Response],
            Doc(
                """
                Response class to be used for this *path operation*.

                This will not be used if you return a response directly.

                Read more about it in the
                [AstraAPI docs for Custom Response - HTML, Stream, File, others](https://astraapi.tiangolo.com/advanced/custom-response/#redirectresponse).
                """
            ),
        ] = Default(JSONResponse),
        name: Annotated[
            Optional[str],
            Doc(
                """
                Name for this *path operation*. Only used internally.
                """
            ),
        ] = None,
        callbacks: Annotated[
            Optional[list[BaseRoute]],
            Doc(
                """
                List of *path operations* that will be used as OpenAPI callbacks.

                This is only for OpenAPI documentation, the callbacks won't be used
                directly.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for OpenAPI Callbacks](https://astraapi.tiangolo.com/advanced/openapi-callbacks/).
                """
            ),
        ] = None,
        openapi_extra: Annotated[
            Optional[dict[str, Any]],
            Doc(
                """
                Extra metadata to be included in the OpenAPI schema for this *path
                operation*.

                Read more about it in the
                [AstraAPI docs for Path Operation Advanced Configuration](https://astraapi.tiangolo.com/advanced/path-operation-advanced-configuration/#custom-openapi-path-operation-schema).
                """
            ),
        ] = None,
        generate_unique_id_function: Annotated[
            Callable[[routing.APIRoute], str],
            Doc(
                """
                Customize the function used to generate unique IDs for the *path
                operations* shown in the generated OpenAPI.

                This is particularly useful when automatically generating clients or
                SDKs for your API.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = Default(_generate_unique_id),
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        """
        Add a *path operation* using an HTTP HEAD operation.

        ## Example

        ```python
        from astraapi import AstraAPI, Response

        app = AstraAPI()

        @app.head("/items/", status_code=204)
        def get_items_headers(response: Response):
            response.headers["X-Cat-Dog"] = "Alone in the world"
        ```
        """
        return self.router.head(
            path,
            response_model=response_model,
            status_code=status_code,
            tags=tags,
            dependencies=dependencies,
            summary=summary,
            description=description,
            response_description=response_description,
            responses=responses,
            deprecated=deprecated,
            operation_id=operation_id,
            response_model_include=response_model_include,
            response_model_exclude=response_model_exclude,
            response_model_by_alias=response_model_by_alias,
            response_model_exclude_unset=response_model_exclude_unset,
            response_model_exclude_defaults=response_model_exclude_defaults,
            response_model_exclude_none=response_model_exclude_none,
            include_in_schema=include_in_schema,
            response_class=response_class,
            name=name,
            callbacks=callbacks,
            openapi_extra=openapi_extra,
            generate_unique_id_function=generate_unique_id_function,
        )

    def patch(
        self,
        path: Annotated[
            str,
            Doc(
                """
                The URL path to be used for this *path operation*.

                For example, in `http://example.com/items`, the path is `/items`.
                """
            ),
        ],
        *,
        response_model: Annotated[
            Any,
            Doc(
                """
                The type to use for the response.

                It could be any valid Pydantic *field* type. So, it doesn't have to
                be a Pydantic model, it could be other things, like a `list`, `dict`,
                etc.

                It will be used for:

                * Documentation: the generated OpenAPI (and the UI at `/docs`) will
                    show it as the response (JSON Schema).
                * Serialization: you could return an arbitrary object and the
                    `response_model` would be used to serialize that object into the
                    corresponding JSON.
                * Filtering: the JSON sent to the client will only contain the data
                    (fields) defined in the `response_model`. If you returned an object
                    that contains an attribute `password` but the `response_model` does
                    not include that field, the JSON sent to the client would not have
                    that `password`.
                * Validation: whatever you return will be serialized with the
                    `response_model`, converting any data as necessary to generate the
                    corresponding JSON. But if the data in the object returned is not
                    valid, that would mean a violation of the contract with the client,
                    so it's an error from the API developer. So, AstraAPI will raise an
                    error and return a 500 error code (Internal Server Error).

                Read more about it in the
                [AstraAPI docs for Response Model](https://astraapi.tiangolo.com/tutorial/response-model/).
                """
            ),
        ] = Default(None),
        status_code: Annotated[
            Optional[int],
            Doc(
                """
                The default status code to be used for the response.

                You could override the status code by returning a response directly.

                Read more about it in the
                [AstraAPI docs for Response Status Code](https://astraapi.tiangolo.com/tutorial/response-status-code/).
                """
            ),
        ] = None,
        tags: Annotated[
            Optional[list[Union[str, Enum]]],
            Doc(
                """
                A list of tags to be applied to the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/#tags).
                """
            ),
        ] = None,
        dependencies: Annotated[
            Optional[Sequence[Depends]],
            Doc(
                """
                A list of dependencies (using `Depends()`) to be applied to the
                *path operation*.

                Read more about it in the
                [AstraAPI docs for Dependencies in path operation decorators](https://astraapi.tiangolo.com/tutorial/dependencies/dependencies-in-path-operation-decorators/).
                """
            ),
        ] = None,
        summary: Annotated[
            Optional[str],
            Doc(
                """
                A summary for the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        description: Annotated[
            Optional[str],
            Doc(
                """
                A description for the *path operation*.

                If not provided, it will be extracted automatically from the docstring
                of the *path operation function*.

                It can contain Markdown.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        response_description: Annotated[
            str,
            Doc(
                """
                The description for the default response.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = "Successful Response",
        responses: Annotated[
            Optional[dict[Union[int, str], dict[str, Any]]],
            Doc(
                """
                Additional responses that could be returned by this *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        deprecated: Annotated[
            Optional[bool],
            Doc(
                """
                Mark this *path operation* as deprecated.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        operation_id: Annotated[
            Optional[str],
            Doc(
                """
                Custom operation ID to be used by this *path operation*.

                By default, it is generated automatically.

                If you provide a custom operation ID, you need to make sure it is
                unique for the whole API.

                You can customize the
                operation ID generation with the parameter
                `generate_unique_id_function` in the `AstraAPI` class.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = None,
        response_model_include: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to include only certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_exclude: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to exclude certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_by_alias: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response model
                should be serialized by alias when an alias is used.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = True,
        response_model_exclude_unset: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that were not set and
                have their default values. This is different from
                `response_model_exclude_defaults` in that if the fields are set,
                they will be included in the response, even if the value is the same
                as the default.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_defaults: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that have the same value
                as the default. This is different from `response_model_exclude_unset`
                in that if the fields are set but contain the same default values,
                they will be excluded from the response.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_none: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data should
                exclude fields set to `None`.

                This is much simpler (less smart) than `response_model_exclude_unset`
                and `response_model_exclude_defaults`. You probably want to use one of
                those two instead of this one, as those allow returning `None` values
                when it makes sense.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_exclude_none).
                """
            ),
        ] = False,
        include_in_schema: Annotated[
            bool,
            Doc(
                """
                Include this *path operation* in the generated OpenAPI schema.

                This affects the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Query Parameters and String Validations](https://astraapi.tiangolo.com/tutorial/query-params-str-validations/#exclude-parameters-from-openapi).
                """
            ),
        ] = True,
        response_class: Annotated[
            type[Response],
            Doc(
                """
                Response class to be used for this *path operation*.

                This will not be used if you return a response directly.

                Read more about it in the
                [AstraAPI docs for Custom Response - HTML, Stream, File, others](https://astraapi.tiangolo.com/advanced/custom-response/#redirectresponse).
                """
            ),
        ] = Default(JSONResponse),
        name: Annotated[
            Optional[str],
            Doc(
                """
                Name for this *path operation*. Only used internally.
                """
            ),
        ] = None,
        callbacks: Annotated[
            Optional[list[BaseRoute]],
            Doc(
                """
                List of *path operations* that will be used as OpenAPI callbacks.

                This is only for OpenAPI documentation, the callbacks won't be used
                directly.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for OpenAPI Callbacks](https://astraapi.tiangolo.com/advanced/openapi-callbacks/).
                """
            ),
        ] = None,
        openapi_extra: Annotated[
            Optional[dict[str, Any]],
            Doc(
                """
                Extra metadata to be included in the OpenAPI schema for this *path
                operation*.

                Read more about it in the
                [AstraAPI docs for Path Operation Advanced Configuration](https://astraapi.tiangolo.com/advanced/path-operation-advanced-configuration/#custom-openapi-path-operation-schema).
                """
            ),
        ] = None,
        generate_unique_id_function: Annotated[
            Callable[[routing.APIRoute], str],
            Doc(
                """
                Customize the function used to generate unique IDs for the *path
                operations* shown in the generated OpenAPI.

                This is particularly useful when automatically generating clients or
                SDKs for your API.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = Default(_generate_unique_id),
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        """
        Add a *path operation* using an HTTP PATCH operation.

        ## Example

        ```python
        from astraapi import AstraAPI
        from pydantic import BaseModel

        class Item(BaseModel):
            name: str
            description: str | None = None

        app = AstraAPI()

        @app.patch("/items/")
        def update_item(item: Item):
            return {"message": "Item updated in place"}
        ```
        """
        return self.router.patch(
            path,
            response_model=response_model,
            status_code=status_code,
            tags=tags,
            dependencies=dependencies,
            summary=summary,
            description=description,
            response_description=response_description,
            responses=responses,
            deprecated=deprecated,
            operation_id=operation_id,
            response_model_include=response_model_include,
            response_model_exclude=response_model_exclude,
            response_model_by_alias=response_model_by_alias,
            response_model_exclude_unset=response_model_exclude_unset,
            response_model_exclude_defaults=response_model_exclude_defaults,
            response_model_exclude_none=response_model_exclude_none,
            include_in_schema=include_in_schema,
            response_class=response_class,
            name=name,
            callbacks=callbacks,
            openapi_extra=openapi_extra,
            generate_unique_id_function=generate_unique_id_function,
        )

    def trace(
        self,
        path: Annotated[
            str,
            Doc(
                """
                The URL path to be used for this *path operation*.

                For example, in `http://example.com/items`, the path is `/items`.
                """
            ),
        ],
        *,
        response_model: Annotated[
            Any,
            Doc(
                """
                The type to use for the response.

                It could be any valid Pydantic *field* type. So, it doesn't have to
                be a Pydantic model, it could be other things, like a `list`, `dict`,
                etc.

                It will be used for:

                * Documentation: the generated OpenAPI (and the UI at `/docs`) will
                    show it as the response (JSON Schema).
                * Serialization: you could return an arbitrary object and the
                    `response_model` would be used to serialize that object into the
                    corresponding JSON.
                * Filtering: the JSON sent to the client will only contain the data
                    (fields) defined in the `response_model`. If you returned an object
                    that contains an attribute `password` but the `response_model` does
                    not include that field, the JSON sent to the client would not have
                    that `password`.
                * Validation: whatever you return will be serialized with the
                    `response_model`, converting any data as necessary to generate the
                    corresponding JSON. But if the data in the object returned is not
                    valid, that would mean a violation of the contract with the client,
                    so it's an error from the API developer. So, AstraAPI will raise an
                    error and return a 500 error code (Internal Server Error).

                Read more about it in the
                [AstraAPI docs for Response Model](https://astraapi.tiangolo.com/tutorial/response-model/).
                """
            ),
        ] = Default(None),
        status_code: Annotated[
            Optional[int],
            Doc(
                """
                The default status code to be used for the response.

                You could override the status code by returning a response directly.

                Read more about it in the
                [AstraAPI docs for Response Status Code](https://astraapi.tiangolo.com/tutorial/response-status-code/).
                """
            ),
        ] = None,
        tags: Annotated[
            Optional[list[Union[str, Enum]]],
            Doc(
                """
                A list of tags to be applied to the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/#tags).
                """
            ),
        ] = None,
        dependencies: Annotated[
            Optional[Sequence[Depends]],
            Doc(
                """
                A list of dependencies (using `Depends()`) to be applied to the
                *path operation*.

                Read more about it in the
                [AstraAPI docs for Dependencies in path operation decorators](https://astraapi.tiangolo.com/tutorial/dependencies/dependencies-in-path-operation-decorators/).
                """
            ),
        ] = None,
        summary: Annotated[
            Optional[str],
            Doc(
                """
                A summary for the *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        description: Annotated[
            Optional[str],
            Doc(
                """
                A description for the *path operation*.

                If not provided, it will be extracted automatically from the docstring
                of the *path operation function*.

                It can contain Markdown.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Path Operation Configuration](https://astraapi.tiangolo.com/tutorial/path-operation-configuration/).
                """
            ),
        ] = None,
        response_description: Annotated[
            str,
            Doc(
                """
                The description for the default response.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = "Successful Response",
        responses: Annotated[
            Optional[dict[Union[int, str], dict[str, Any]]],
            Doc(
                """
                Additional responses that could be returned by this *path operation*.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        deprecated: Annotated[
            Optional[bool],
            Doc(
                """
                Mark this *path operation* as deprecated.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).
                """
            ),
        ] = None,
        operation_id: Annotated[
            Optional[str],
            Doc(
                """
                Custom operation ID to be used by this *path operation*.

                By default, it is generated automatically.

                If you provide a custom operation ID, you need to make sure it is
                unique for the whole API.

                You can customize the
                operation ID generation with the parameter
                `generate_unique_id_function` in the `AstraAPI` class.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = None,
        response_model_include: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to include only certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_exclude: Annotated[
            Optional[IncEx],
            Doc(
                """
                Configuration passed to Pydantic to exclude certain fields in the
                response data.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = None,
        response_model_by_alias: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response model
                should be serialized by alias when an alias is used.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_include-and-response_model_exclude).
                """
            ),
        ] = True,
        response_model_exclude_unset: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that were not set and
                have their default values. This is different from
                `response_model_exclude_defaults` in that if the fields are set,
                they will be included in the response, even if the value is the same
                as the default.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_defaults: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data
                should have all the fields, including the ones that have the same value
                as the default. This is different from `response_model_exclude_unset`
                in that if the fields are set but contain the same default values,
                they will be excluded from the response.

                When `True`, default values are omitted from the response.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#use-the-response_model_exclude_unset-parameter).
                """
            ),
        ] = False,
        response_model_exclude_none: Annotated[
            bool,
            Doc(
                """
                Configuration passed to Pydantic to define if the response data should
                exclude fields set to `None`.

                This is much simpler (less smart) than `response_model_exclude_unset`
                and `response_model_exclude_defaults`. You probably want to use one of
                those two instead of this one, as those allow returning `None` values
                when it makes sense.

                Read more about it in the
                [AstraAPI docs for Response Model - Return Type](https://astraapi.tiangolo.com/tutorial/response-model/#response_model_exclude_none).
                """
            ),
        ] = False,
        include_in_schema: Annotated[
            bool,
            Doc(
                """
                Include this *path operation* in the generated OpenAPI schema.

                This affects the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for Query Parameters and String Validations](https://astraapi.tiangolo.com/tutorial/query-params-str-validations/#exclude-parameters-from-openapi).
                """
            ),
        ] = True,
        response_class: Annotated[
            type[Response],
            Doc(
                """
                Response class to be used for this *path operation*.

                This will not be used if you return a response directly.

                Read more about it in the
                [AstraAPI docs for Custom Response - HTML, Stream, File, others](https://astraapi.tiangolo.com/advanced/custom-response/#redirectresponse).
                """
            ),
        ] = Default(JSONResponse),
        name: Annotated[
            Optional[str],
            Doc(
                """
                Name for this *path operation*. Only used internally.
                """
            ),
        ] = None,
        callbacks: Annotated[
            Optional[list[BaseRoute]],
            Doc(
                """
                List of *path operations* that will be used as OpenAPI callbacks.

                This is only for OpenAPI documentation, the callbacks won't be used
                directly.

                It will be added to the generated OpenAPI (e.g. visible at `/docs`).

                Read more about it in the
                [AstraAPI docs for OpenAPI Callbacks](https://astraapi.tiangolo.com/advanced/openapi-callbacks/).
                """
            ),
        ] = None,
        openapi_extra: Annotated[
            Optional[dict[str, Any]],
            Doc(
                """
                Extra metadata to be included in the OpenAPI schema for this *path
                operation*.

                Read more about it in the
                [AstraAPI docs for Path Operation Advanced Configuration](https://astraapi.tiangolo.com/advanced/path-operation-advanced-configuration/#custom-openapi-path-operation-schema).
                """
            ),
        ] = None,
        generate_unique_id_function: Annotated[
            Callable[[routing.APIRoute], str],
            Doc(
                """
                Customize the function used to generate unique IDs for the *path
                operations* shown in the generated OpenAPI.

                This is particularly useful when automatically generating clients or
                SDKs for your API.

                Read more about it in the
                [AstraAPI docs about how to Generate Clients](https://astraapi.tiangolo.com/advanced/generate-clients/#custom-generate-unique-id-function).
                """
            ),
        ] = Default(_generate_unique_id),
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        """
        Add a *path operation* using an HTTP TRACE operation.

        ## Example

        ```python
        from astraapi import AstraAPI

        app = AstraAPI()

        @app.trace("/items/{item_id}")
        def trace_item(item_id: str):
            return None
        ```
        """
        return self.router.trace(
            path,
            response_model=response_model,
            status_code=status_code,
            tags=tags,
            dependencies=dependencies,
            summary=summary,
            description=description,
            response_description=response_description,
            responses=responses,
            deprecated=deprecated,
            operation_id=operation_id,
            response_model_include=response_model_include,
            response_model_exclude=response_model_exclude,
            response_model_by_alias=response_model_by_alias,
            response_model_exclude_unset=response_model_exclude_unset,
            response_model_exclude_defaults=response_model_exclude_defaults,
            response_model_exclude_none=response_model_exclude_none,
            include_in_schema=include_in_schema,
            response_class=response_class,
            name=name,
            callbacks=callbacks,
            openapi_extra=openapi_extra,
            generate_unique_id_function=generate_unique_id_function,
        )

    def websocket_route(
        self, path: str, name: Union[str, None] = None
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        def decorator(func: DecoratedCallable) -> DecoratedCallable:
            self.router.add_websocket_route(path, func, name=name)
            return func

        return decorator

    @deprecated(
        """
        on_event is deprecated, use lifespan event handlers instead.

        Read more about it in the
        [AstraAPI docs for Lifespan Events](https://astraapi.tiangolo.com/advanced/events/).
        """
    )
    def on_event(
        self,
        event_type: Annotated[
            str,
            Doc(
                """
                The type of event. `startup` or `shutdown`.
                """
            ),
        ],
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        """
        Add an event handler for the application.

        `on_event` is deprecated, use `lifespan` event handlers instead.

        Read more about it in the
        [AstraAPI docs for Lifespan Events](https://astraapi.tiangolo.com/advanced/events/#alternative-events-deprecated).
        """
        return self.router.on_event(event_type)

    def middleware(
        self,
        middleware_type: Annotated[
            str,
            Doc(
                """
                The type of middleware. Currently only supports `http`.
                """
            ),
        ],
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        """
        Add a middleware to the application.

        Read more about it in the
        [AstraAPI docs for Middleware](https://astraapi.tiangolo.com/tutorial/middleware/).

        ## Example

        ```python
        import time
        from typing import Awaitable, Callable

        from astraapi import AstraAPI, Request, Response

        app = AstraAPI()


        @app.middleware("http")
        async def add_process_time_header(
            request: Request, call_next: Callable[[Request], Awaitable[Response]]
        ) -> Response:
            start_time = time.time()
            response = await call_next(request)
            process_time = time.time() - start_time
            response.headers["X-Process-Time"] = str(process_time)
            return response
        ```
        """

        def decorator(func: DecoratedCallable) -> DecoratedCallable:
            self.add_middleware(BaseHTTPMiddleware, dispatch=func)
            return func

        return decorator

    def exception_handler(
        self,
        exc_class_or_status_code: Annotated[
            Union[int, type[Exception]],
            Doc(
                """
                The Exception class this would handle, or a status code.
                """
            ),
        ],
    ) -> Callable[[DecoratedCallable], DecoratedCallable]:
        """
        Add an exception handler to the app.

        Read more about it in the
        [AstraAPI docs for Handling Errors](https://astraapi.tiangolo.com/tutorial/handling-errors/).

        ## Example

        ```python
        from astraapi import AstraAPI, Request
        from astraapi.responses import JSONResponse


        class UnicornException(Exception):
            def __init__(self, name: str):
                self.name = name


        app = AstraAPI()


        @app.exception_handler(UnicornException)
        async def unicorn_exception_handler(request: Request, exc: UnicornException):
            return JSONResponse(
                status_code=418,
                content={"message": f"Oops! {exc.name} did something. There goes a rainbow..."},
            )
        ```
        """

        def decorator(func: DecoratedCallable) -> DecoratedCallable:
            self.add_exception_handler(exc_class_or_status_code, func)
            return func

        return decorator

    def run(
        self,
        host: str = "127.0.0.1",
        port: int = 8000,
        reload: bool = False,
        reload_dirs: Optional[Sequence[str]] = None,
        reload_includes: Optional[Sequence[str]] = None,
        reload_excludes: Optional[Sequence[str]] = None,
        workers: int = 1,
        keep_alive_timeout: float = 30.0,
        max_body_size: int = 0,
        max_body_size_kb: float = 0,
        max_body_size_mb: float = 0,
    ) -> None:
        """Run the app with the built-in C++ HTTP server.

        Args:
            host: Bind address.
            port: Bind port.
            reload: Enable hot reloading (development only). Watches for
                file changes and restarts the server automatically.
                Zero overhead when disabled.
            reload_dirs: Directories to watch. Defaults to cwd.
            reload_includes: Extra glob patterns to include (e.g. ``"*.yaml"``).
            reload_excludes: Paths to exclude from watching.
            workers: Number of worker processes. Each worker has its own GIL,
                memory space, and event loop — zero locks, zero shared state.
                Kernel load-balances via SO_REUSEPORT. Default 1 (single process).
        """
        import asyncio

        if reload:
            from astraapi._reloader import is_reload_worker, run_with_reload

            if not is_reload_worker():
                run_with_reload(
                    reload_dirs=reload_dirs,
                    reload_includes=reload_includes,
                    reload_excludes=reload_excludes,
                )
                return
            # Worker subprocess — fall through to normal startup

        # Multi-worker mode: fork N independent processes, each with its own
        # GIL + memory + event loop. Zero locks, zero shared state.
        # Skip if this process is already a spawned worker.
        from astraapi._multiworker import is_worker
        if workers > 1 and not is_worker():
            from astraapi._multiworker import run_multiworker
            run_multiworker(self, host, port, workers)
            return

        from astraapi._cpp_server import run_server

        self._sync_routes_to_core()

        try:
            import uvloop
            _max_bytes = max_body_size or int(max_body_size_kb * 1024) or int(max_body_size_mb * 1024 * 1024)
            uvloop.run(run_server(self, host, port, keep_alive_timeout=keep_alive_timeout, max_body_size=_max_bytes))
        except ImportError:
            try:
                import winloop
                winloop.run(run_server(self, host, port, keep_alive_timeout=keep_alive_timeout, max_body_size=_max_bytes))
            except ImportError:
                asyncio.run(run_server(self, host, port, keep_alive_timeout=keep_alive_timeout, max_body_size=_max_bytes))


# Copy real (non-stringified) annotations and defaults from APIRouter to AstraAPI
# so that inspect.signature() returns the actual types instead of string literals,
# and DefaultPlaceholder defaults compare equal.
# This is needed because applications.py uses `from __future__ import annotations`
# which makes all annotations strings, while routing.py does not.
def _copy_router_annotations() -> None:
    import inspect as _inspect
    from astraapi.routing import APIRouter as _APIRouter
    _method_names = ["get", "put", "post", "delete", "options", "head", "patch", "trace"]
    for _name in _method_names:
        _router_method = getattr(_APIRouter, _name, None)
        _app_method = getattr(AstraAPI, _name, None)
        if _router_method is None or _app_method is None:
            continue
        try:
            _app_method.__annotations__ = _router_method.__annotations__
        except (AttributeError, TypeError):
            pass
        # Also sync defaults so DefaultPlaceholder(generate_unique_id) compares equal
        try:
            _router_sig = _inspect.signature(_router_method)
            _app_sig = _inspect.signature(_app_method)
            _new_params = []
            for _key, _app_param in _app_sig.parameters.items():
                _router_param = _router_sig.parameters.get(_key)
                if _router_param is not None and _app_param.default != _router_param.default:
                    _new_params.append(_app_param.replace(default=_router_param.default))
                else:
                    _new_params.append(_app_param)
            _app_method.__signature__ = _app_sig.replace(parameters=_new_params)
        except (AttributeError, TypeError, ValueError):
            pass

_copy_router_annotations()
