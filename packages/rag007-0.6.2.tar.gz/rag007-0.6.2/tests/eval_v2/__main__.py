"""Run the full eval_v2 suite. Usage: uv run python -m tests.eval_v2"""

from __future__ import annotations

import asyncio
import time

from tests.eval_v2.adversarial import build_adversarial_cases
from tests.eval_v2.runner import (
    paraphrase_groups,
    run_consistency,
    run_hits,
    synthetic_cases,
)


async def _build_rag(label: str, index: str, embed_fn: object | None) -> object:
    from rag007 import AgenticRAG  # type: ignore[import-not-found]
    from rag007.backend import MeilisearchBackend  # type: ignore[import-not-found]

    return AgenticRAG(
        index=index,
        backend=MeilisearchBackend(index=index),
        embed_fn=embed_fn,
        auto_strategy=True,
    )


async def main() -> None:
    from tests.intelligence_eval import (  # type: ignore[import-not-found]
        CATALOG_DE_HITS,
        CUSTOMER_HITS,
        MULTILINGUAL_HITS,
        ONETRADE_DE_HITS,
        ONETRADE_FR_HITS,
    )
    from rag007.utils import _make_azure_embed_fn  # type: ignore[import-not-found]

    embed_fn = _make_azure_embed_fn()
    sem = asyncio.Semaphore(20)

    suites = [
        ("onetrade_articles_de", "OneTrade DE", ONETRADE_DE_HITS),
        ("onetrade_articles_fr", "OneTrade FR", ONETRADE_FR_HITS),
        ("supplier_catalogs_de", "Catalog DE", CATALOG_DE_HITS),
        ("customer", "Customer", CUSTOMER_HITS),
        ("rag_multilingual", "Multilingual", MULTILINGUAL_HITS),
    ]

    t0 = time.perf_counter()
    grand_hits = 0
    grand_total = 0
    consistency_sum = 0.0
    consistency_groups = 0
    stable_sum = 0.0

    for index, label, base in suites:
        rag = await _build_rag(label, index, embed_fn)

        adversarial = build_adversarial_cases(base)
        print(f"\n══ {label}: adversarial ({len(adversarial)} variants) ══")
        hits, total = await run_hits(rag, adversarial, sem, label=f"{label}/adv")
        grand_hits += hits
        grand_total += total

        groups = paraphrase_groups(base)
        if groups:
            print(f"══ {label}: paraphrase consistency ({len(groups)} groups) ══")
            avg, stable, n = await run_consistency(
                rag, groups, sem, label=f"{label}/para"
            )
            consistency_sum += avg * n
            consistency_groups += n
            stable_sum += stable * n

        syn = synthetic_cases()
        if syn and label == "OneTrade DE":
            print(f"══ {label}: synthetic ({len(syn)} queries) ══")
            h, t = await run_hits(rag, syn, sem, label=f"{label}/syn")
            grand_hits += h
            grand_total += t

    elapsed = time.perf_counter() - t0
    avg_consistency = consistency_sum / consistency_groups if consistency_groups else 0.0
    avg_stable = stable_sum / consistency_groups if consistency_groups else 0.0

    print("\n════════════════════════════════════════════════════════════")
    print(f"eval_v2 summary: {elapsed:.1f}s")
    print(f"  adversarial+synthetic hit@5: {grand_hits}/{grand_total} = "
          f"{grand_hits / grand_total if grand_total else 0:.4f}")
    print(f"  paraphrase consistency:      {avg_consistency:.4f}")
    print(f"  paraphrase stable_top1:      {avg_stable:.4f}")
    print("════════════════════════════════════════════════════════════")


if __name__ == "__main__":
    asyncio.run(main())
