"""Packaged client-install assets."""
