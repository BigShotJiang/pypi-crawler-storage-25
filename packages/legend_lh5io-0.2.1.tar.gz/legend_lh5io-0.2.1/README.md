# legend-lh5io

[![PyPI](https://img.shields.io/pypi/v/legend-lh5io?logo=pypi)](https://pypi.org/project/legend-lh5io/)
![GitHub tag (latest by date)](https://img.shields.io/github/v/tag/legend-exp/legend-lh5io?logo=git)
[![GitHub Workflow Status](https://img.shields.io/github/checks-status/legend-exp/legend-lh5io/main?label=main%20branch&logo=github)](https://github.com/legend-exp/legend-lh5io/actions)
[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/pre-commit/pre-commit)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Codecov](https://img.shields.io/codecov/c/github/legend-exp/legend-lh5io?logo=codecov)](https://app.codecov.io/gh/legend-exp/legend-lh5io)
![GitHub issues](https://img.shields.io/github/issues/legend-exp/legend-lh5io?logo=github)
![GitHub pull requests](https://img.shields.io/github/issues-pr/legend-exp/legend-lh5io?logo=github)
![License](https://img.shields.io/github/license/legend-exp/legend-lh5io)
[![Read the Docs](https://img.shields.io/readthedocs/legend-lh5io?logo=readthedocs)](https://legend-lh5io.readthedocs.io)
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.18700604.svg)](https://doi.org/10.5281/zenodo.18700604)

This package provides a Python implementation of I/O to HDF5 for the LEGEND Data
Objects (LGDOs), including [Numba](https://numba.pydata.org/)-accelerated custom
compression algorithms for particle detector signals. More documentation is
available in the
[LEGEND data format specification](https://legend-exp.github.io/legend-data-format-specs).

If you are using this software,
[consider citing](https://doi.org/10.5281/zenodo.18700604)!
