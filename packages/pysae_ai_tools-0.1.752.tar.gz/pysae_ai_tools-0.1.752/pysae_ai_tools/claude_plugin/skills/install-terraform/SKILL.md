---
name: install-terraform
description: >
  Install, update, and verify the Terraform CLI.
  Use when the user says /install-terraform, 'install terraform', 'setup terraform',
  'configurer terraform', or needs the terraform CLI configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install, verify, and update the Terraform CLI.

## Step 1 — Check current state

```bash
pysae-ai-tools tools check terraform --json
```

Returns JSON with `binary`, `latest` (from HashiCorp checkpoint API), `needs_install`, `needs_update`.

| `needs_install` | `needs_update` | Action |
|---|---|---|
| `true` | — | Step 2 (install) |
| `false` | `true` | Step 2 (update) |
| `false` | `false` | **Done** — tell the user everything is OK |

## Step 2 — Install or update Terraform

```bash
pysae-ai-tools tools install terraform --json
```

Downloads `terraform_<ver>_<os>_<arch>.zip` from `releases.hashicorp.com`, extracts the binary, and installs it:
- **Linux/macOS** → `/usr/local/bin/terraform` via `sudo install`.
- **Windows** → `%LOCALAPPDATA%\Programs\pysae\bin\terraform.exe`.

> **macOS alternative:** `brew tap hashicorp/tap && brew install hashicorp/tap/terraform`.
>
> **Windows alternative:** `choco install terraform` or `winget install Hashicorp.Terraform`.
>
> **Debian/Ubuntu APT alternative:** the official HashiCorp APT repo (handles updates automatically). Only use this if the user explicitly asks for it — the binary install path is simpler.

## Step 3 — Final verification

```bash
terraform version
```

## Gotchas

- **`terraform init` is mandatory.** Every Terraform command (except `version`, `fmt`, `validate`) requires `terraform init` to have been run in the project directory at least once. New project? Run `terraform init` before anything else.
- **Backend in `.tf` files.** Terraform state at Pysae is stored in S3. The backend is configured in each project's `.tf` files — no global config to set up here.
- **Project version pinning.** Some Pysae repos pin a Terraform version via `.terraform-version` (tfenv) or `required_version` in `main.tf`. Check before using the latest version.
- **AWS credentials.** Terraform reads AWS credentials from the standard chain — ensure `/install-aws-cli` is done first if working with AWS resources.
- **Windows PATH.** Add `%LOCALAPPDATA%\Programs\pysae\bin` to `%PATH%` if `terraform` is not found after install.

$ARGUMENTS
