---
name: install-kubectl
description: >
  Install, update, and verify kubectl and configure EKS contexts for dev/prod.
  Use when the user says /install-kubectl, 'install kubectl', 'setup kubectl',
  'configurer kubectl', or needs kubectl configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install, verify, and update kubectl, then configure Kubernetes contexts for Pysae EKS clusters.

## Step 1 — Check current state

```bash
pysae-ai-tools tools check kubectl --json
```

Returns JSON with `binary`, `latest` (from `dl.k8s.io/release/stable.txt`), `contexts` (list of configured kubeconfig contexts), `cluster_ok` (current context reachable), `needs_install`, `needs_update`.

| `needs_install` | `needs_update` | Contexts OK | Action |
|---|---|---|---|
| `true` | — | — | Step 2 (install) then Step 3 (contexts) |
| `false` | `true` | — | Step 2 (update) then verify contexts |
| `false` | `false` | Missing/broken | Step 3 (contexts) |
| `false` | `false` | OK | **Done** — tell the user everything is OK |

## Step 2 — Install or update kubectl

```bash
pysae-ai-tools tools install kubectl --json
```

Downloads the raw binary from `dl.k8s.io/release/<ver>/bin/<os>/<arch>/kubectl[.exe]`:
- **Linux/macOS** → `/usr/local/bin/kubectl` via `sudo install`.
- **Windows** → `%LOCALAPPDATA%\Programs\pysae\bin\kubectl.exe`.

> **Windows alternative:** `choco install kubernetes-cli` or `winget install Kubernetes.kubectl`.

## Step 3 — Configure EKS contexts

**Prerequisite:** EKS auth requires the AWS CLI configured. If `aws sts get-caller-identity` fails, tell the user:

> kubectl a besoin de l'AWS CLI pour s'authentifier auprès des clusters EKS. Lance `/install-aws-cli` d'abord.

Once AWS is ready, ask the user for the EKS cluster names (or look them up via `aws eks list-clusters`), then update kubeconfig per environment:

```bash
aws eks update-kubeconfig --name <cluster-name> --region <region> --alias <env>
```

Convention: `--alias dev` and `--alias prod`. Set the default namespace per context:

```bash
kubectl config set-context dev --namespace=pysae-dev
kubectl config set-context prod --namespace=pysae-prod
```

## Step 4 — Final verification

```bash
pysae-ai-tools tools check kubectl --json
kubectl config get-contexts
for ctx in dev prod; do
  kubectl --context "${ctx}" get pods --no-headers 2>/dev/null | head -1 \
    && echo "✔ ${ctx}: OK" \
    || echo "✘ ${ctx}: FAILED"
done
```

## Gotchas

- **Version skew policy.** Stay within ±1 minor version of the cluster. The script downloads the latest stable, which may exceed the cluster minor — downgrade manually if needed via `https://dl.k8s.io/release/v<x.y.z>/bin/<os>/<arch>/kubectl`.
- **AWS SSO expiry.** kubectl uses `aws eks get-token` under the hood. When the SSO session expires, every kubectl command fails — re-run `aws sso login`.
- **Context names matter.** Use exactly `dev` and `prod` so `/infra` and other skills can switch contexts cleanly.
- **Windows PATH.** Add `%LOCALAPPDATA%\Programs\pysae\bin` to `%PATH%` if `kubectl` is not found after install.

## Notes

- The script also reports `cluster_ok` so you can detect a broken active context (expired tokens, network) without running additional commands.
- Other skills (`/infra`, `/perf`, `/ci-deploy-status`) depend on `dev` and `prod` contexts.

$ARGUMENTS
