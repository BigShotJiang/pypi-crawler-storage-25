---
name: install-all
description: >
  Install or update every Pysae CLI/MCP at once (aws-cli, glab, kubectl,
  helm, argocd, docker, terraform, gh, prefect, mongo-tools, postman + every MCP server).
  Use when the user says /install-all, 'install everything', 'setup my machine',
  'install tous les outils', 'configure tout', 'bootstrap dev env', or wants a
  one-shot install/update of the full Pysae toolchain.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Bootstrap or refresh the entire Pysae toolchain in one command. Wraps the 16 individual `install-*` skills with the right dependency order, skip rules, and update detection.

## Step 1 — List what will be managed

```bash
pysae-ai-tools tools status
```

Returns the ordered list of tools, each with its mode:
- **required** — failure aborts the chain (currently `aws-cli`, `glab`)
- **optional** — failure is logged, chain continues
- **skip_on_missing_env** — silently skipped when its env vars are absent (most MCP servers requiring API keys)

## Step 2 — Dry-run check

```bash
pysae-ai-tools tools check --json
```

Returns one entry per tool with status `installed` (would be installed/updated), `up-to-date`, `skipped`, or `failed`. Nothing is mutated. Use this to preview what `install` would do.

## Step 3 — Run the install

```bash
pysae-ai-tools tools install --json
```

Per-tool flow:
1. Call `get_state()` — if `needs_install: false` AND `needs_update: false`, mark as `up-to-date` and skip.
2. Otherwise call `do_install()` and capture the result.
3. On a `required` tool failure, abort the chain immediately.

The script also accepts:
- `--only <tool>` (repeatable) — install only the named tools
- `--skip <tool>` (repeatable) — skip the named tools

Example: install only the binary CLIs, no MCPs:

```bash
pysae-ai-tools tools install --json \
  --only aws-cli --only glab --only gh --only kubectl --only helm \
  --only argocd --only docker --only terraform --only prefect \
  --only mongo-tools --only postman
```

## Step 4 — Optional: configure MCP servers requiring secrets

The MCP servers `datadog-mcp`, `postman-mcp`, and `mongo-mcp` are skipped unless their env vars are present. To install them, set the vars first, then re-run:

```bash
# Datadog
DD_API_KEY=... DD_APP_KEY=... pysae-ai-tools tools install --json --only datadog-mcp

# Postman
POSTMAN_API_KEY=... pysae-ai-tools tools install --json --only postman-mcp

# MongoDB Atlas (URIs come from /aws-secret-env)
MONGO_URI_DEV='mongodb+srv://...' MONGO_URI_PROD='mongodb+srv://...' \
  pysae-ai-tools tools install --json --only mongo-mcp
```

`mongodb-atlas-mcp` reads keys directly from AWS Secrets Manager (`pysae/mongodb-atlas/{dev,prod}`) and runs without env vars when AWS auth is valid.

## Step 5 — Verify

Re-run the check:

```bash
pysae-ai-tools tools check --json
```

All required tools should be `up-to-date`. Optional tools may remain `skipped` (MCP secrets not set) or `failed` (e.g., Docker Desktop on macOS — manual install is normal).

## Order of tools

| # | Tool | Mode | Notes |
|---|---|---|---|
| 1 | aws-cli | required | Auth foundation; kubectl, mongodb-atlas-mcp, aws-secret-env all depend on it |
| 2 | glab | required | GitLab CLI; many skills break without it |
| 3 | gh | optional | GitHub CLI |
| 4 | kubectl | optional | Needs aws-cli for EKS auth |
| 5 | helm | optional | Reuses kubeconfig from kubectl |
| 6 | argocd | optional | Pysae dev/prod ArgoCD CLI |
| 7 | docker | optional | Docker Engine (Linux) / Docker Desktop manual instructions (macOS/Windows) |
| 8 | terraform | optional | HashiCorp Terraform |
| 9 | prefect | optional | Prefect CLI via uv tool |
| 10 | mongo-tools | optional | mongosh + mongodump suite |
| 11 | postman | optional | Postman desktop app |
| 12 | chrome-mcp | optional | MCP server, no env required |
| 13 | datadog-mcp | skip_on_missing_env | DD_API_KEY + DD_APP_KEY |
| 14 | postman-mcp | skip_on_missing_env | POSTMAN_API_KEY |
| 15 | mongo-mcp | skip_on_missing_env | MONGO_URI_DEV + MONGO_URI_PROD |
| 16 | mongodb-atlas-mcp | optional | Reads keys from AWS Secrets Manager |

## Gotchas

- **AWS CLI is REQUIRED first.** If `aws-cli` install fails, the chain aborts. Many downstream tools (kubectl EKS auth, mongodb-atlas-mcp, aws-secret-env) cannot work without it.
- **Updates work via re-install.** Every `install` command always downloads the latest version and overwrites the binary/config. Re-run `install-all` periodically to keep everything current — no separate `update` flow needed.
- **`up-to-date` ≠ "perfectly configured".** It means the binary is installed and the version is current. SSO sessions, contexts, and registry logins are NOT checked — those need each individual skill (`/install-aws-cli` Step 3, `/install-kubectl` Step 3, etc.).
- **Interactive auth steps are NOT automated.** AWS SSO login, ArgoCD SSO login, glab auth, prefect cloud login, GitHub PAT, Docker registry login — all remain manual. `install-all` only installs/updates binaries and MCP configs.
- **Docker on macOS/Windows.** The script reports a manual install message (Docker Desktop). The chain marks docker as `installed` even when only the manual message was returned — verify with `docker version` afterward.
- **Windows install path.** All binaries land in `%LOCALAPPDATA%\Programs\pysae\bin`. Add to `%PATH%` once: `setx PATH "%PATH%;%LOCALAPPDATA%\Programs\pysae\bin"`.
- **Skipping an MCP doesn't fail the chain.** `skip_on_missing_env` is silent. Use `check` to spot what was skipped and why.

## Notes

- The script imports each `install_<tool>.install` module and calls its `get_state()` + `do_install()` functions in-process — no subprocess overhead, fast iteration.
- Failures are isolated per tool: a failing optional tool does not abort the chain, only `required` tools do.
- For first-time machine bootstrap, always pair this skill with manual SSO/auth steps from the individual install skills.

$ARGUMENTS
