---
name: install-glab
description: >
  Install, update, and verify the glab CLI (GitLab CLI) and authenticate to gitlab.com.
  Use when the user says /install-glab, 'install glab', 'setup glab',
  'configurer glab', or needs the glab CLI configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install, verify, and update the glab CLI, then authenticate to GitLab.

## Step 1 — Check current state

```bash
pysae-ai-tools tools check glab --json
```

The script returns a single JSON line with: `binary` (name, path, version, installed), `latest` (latest GitLab release), `auth_ok`, `auth_message`, `needs_install`, `needs_update`.

| `needs_install` | `needs_update` | `auth_ok` | Action |
|---|---|---|---|
| `true` | — | — | Step 2 (install) then Step 3 (auth) |
| `false` | `true` | — | Step 2 (update) then Step 3 (re-check auth) |
| `false` | `false` | `false` | Step 3 (auth) |
| `false` | `false` | `true` | **Done** — tell the user everything is OK |

## Step 2 — Install or update glab

```bash
pysae-ai-tools tools install glab --json
```

The script detects the platform (Linux, macOS, Windows × x86_64/arm64), downloads the matching release from the GitLab project `gitlab-org/cli`, extracts the archive, and installs the binary:
- **Linux/macOS** → `/usr/local/bin/glab` via `sudo install` (falls back to direct copy when the prefix is user-writable).
- **Windows** → `%LOCALAPPDATA%\Programs\pysae\bin\glab.exe` (no admin required). The user must add this directory to `%PATH%` if not already present.

Returns a JSON line with `version` and `path` on success, or `error` on failure.

> **macOS alternative:** `brew install glab` (optional, Homebrew handles updates automatically).
>
> **Windows alternative:** `winget install GLab.GLab` or `scoop install glab` if the user prefers a package manager.

## Step 3 — Authenticate to GitLab

SSO login opens a browser — it MUST be run interactively by the user (suggest `! <command>`), never via the Bash tool.

> Pour t'authentifier sur **gitlab.com**, lance cette commande puis connecte-toi via le navigateur :
>
> `! glab auth login --hostname gitlab.com`

Wait for the user to confirm before continuing.

## Step 4 — Final verification

Re-run the check to confirm everything is green:

```bash
pysae-ai-tools tools check glab --json
```

Confirm to the user that glab is installed, up to date, and authenticated.

## Gotchas

- **GitLab project, not GitHub.** glab releases are hosted on `gitlab.com/gitlab-org/cli`, not GitHub. The script uses the GitLab API (`/api/v4/projects/.../releases`), not the GitHub releases API.
- **SSO must be interactive.** `glab auth login` opens a browser. Always suggest `! <command>` so the user runs it in their own session — never invoke it via the Bash tool.
- **Token-based auth for CI/headless.** When no browser is available:
  ```bash
  ! glab auth login --hostname gitlab.com --token <PAT>
  ```
- **Token storage.** `glab auth login` stores tokens in `~/.config/glab-cli/config.yml`.
- **sudo prompt on Linux/macOS.** The install step calls `sudo install` to write to `/usr/local/bin`. The user's password may be required.
- **Windows PATH.** The script installs to `%LOCALAPPDATA%\Programs\pysae\bin`. Add it to `%PATH%` once via `setx PATH "%PATH%;%LOCALAPPDATA%\Programs\pysae\bin"` if `glab` is not found after install.

## Notes

- All Pysae repos are hosted on `gitlab.com` — no self-managed instance to configure.
- Other skills (`/glab-mr`, `/glab-issue-create`, `/ci-run`, `/ci-debug`) depend on glab being authenticated. Run `/install-glab` first if any of them fail with auth errors.

$ARGUMENTS
