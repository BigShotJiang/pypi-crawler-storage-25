---
name: install-mongo-mcp
description: >
  Install and configure the MongoDB MCP servers (dev read/write + prod read-only) for Claude Code.
  Use when the user says /install-mongo-mcp, 'install mongo mcp', 'install mongodb mcp',
  'setup mongo mcp', 'configurer mongo mcp', or needs the MongoDB MCP servers configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
  - Skill
---

Install and configure two MongoDB MCP servers: **mongodb-dev** (read/write) and **mongodb-prod** (read-only).

## Step 1 — Check current state

```bash
pysae-ai-tools tools check mongo-mcp --json
```

Returns JSON for both `mongodb-dev` and `mongodb-prod` with `configured`, `has_uri`, `read_only`. Plus a top-level `needs_install` boolean.

| `needs_install` | Action |
|---|---|
| `true` | Step 2 (URIs) → Step 3 (install) |
| `false` | **Done** — tell the user everything is OK |

## Step 2 — Get connection URIs from AWS Secrets Manager

Use `/aws-secret-env` to read `MONGO_URI` for the **api** application:
- **dev**: `/aws-secret-env api dev MONGO_URI`
- **prod**: `/aws-secret-env api prod MONGO_URI`

URIs follow `mongodb+srv://<user>:<password>@<cluster>.mongodb.net`.

## Step 3 — Install

Pass the URIs via env vars and run:

```bash
MONGO_URI_DEV='<dev-uri>' MONGO_URI_PROD='<prod-uri>' pysae-ai-tools tools install mongo-mcp --json
```

The script:
1. Upserts `mongodb-dev` (read/write) and `mongodb-prod` (with `--readOnly` enforced) into `~/.claude.json`.
2. Returns `{"mongodb-dev": {"changed": ...}, "mongodb-prod": {"changed": ..., "read_only_enforced": true}}`.

## Step 4 — Verify

> Redémarre Claude Code puis essaie : « liste les bases de données en dev ».

## Gotchas

- **Prod is ALWAYS read-only.** The script enforces `--readOnly` in the prod args. Never bypass this — Pysae's data integrity policy depends on it.
- **URIs contain credentials.** Never echo them in plaintext. Pass them as env vars on a single command line; do NOT export them globally.
- **Restart Claude Code after install.** MCP servers are loaded at startup.
- **`npx` required.** Node.js must be on `PATH`.
- **Don't ask the user for URIs.** Always fetch them via `/aws-secret-env` — manual entry risks typos and leaks.

## Notes

- Package: `mongodb-mcp-server@latest` from npm (official MongoDB).
- Both servers use `type: "stdio"` (required field).

$ARGUMENTS
