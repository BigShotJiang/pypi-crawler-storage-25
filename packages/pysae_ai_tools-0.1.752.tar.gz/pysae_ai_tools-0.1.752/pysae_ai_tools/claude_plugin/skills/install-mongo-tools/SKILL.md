---
name: install-mongo-tools
description: >
  Install, update, and verify MongoDB tools (mongodump, mongorestore, mongoimport, mongoexport)
  and mongosh. Use when the user says /install-mongo-tools, 'install mongo', 'install mongosh',
  'setup mongodump', or needs MongoDB CLI tools configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install, verify, and update mongosh (MongoDB shell) and the MongoDB Database Tools (mongodump, mongorestore, mongoimport, mongoexport, etc.).

## Step 1 — Check current state

```bash
pysae-ai-tools tools check mongo-tools --json
```

Returns JSON with `mongosh` (binary status), `dbtools` (binary status), `latest_tools` (latest mongo-tools release from GitHub), plus `needs_install_mongosh`, `needs_install_dbtools`, `needs_update_dbtools`.

| Action depending on flags |
|---|
| `needs_install_mongosh: true` OR `needs_install_dbtools: true` → Step 2 (install) |
| `needs_update_dbtools: true` → Step 2 (update) |
| both installed and up to date → **Done** |

## Step 2 — Install or update

```bash
pysae-ai-tools tools install mongo-tools --json
```

The script:
1. Installs mongosh via `npm install -g mongosh` (works cross-platform when Node is available).
2. Downloads the platform-matched mongo-database-tools archive from `fastdl.mongodb.org`, extracts every binary, and installs each one (`mongodump`, `mongorestore`, `mongoimport`, `mongoexport`, `mongostat`, `mongotop`, `bsondump`, `mongofiles`).

Returns `{"mongosh_method": "npm" | "already-installed", "dbtools_version": "100.x.y"}` or `{"error": "..."}`.

> **macOS alternative:** `brew install mongosh` and `brew tap mongodb/brew && brew install mongodb-database-tools` for automatic Homebrew updates.
>
> **Windows alternative:** MSI installers from https://www.mongodb.com/try/download/shell and https://www.mongodb.com/try/download/database-tools, or `winget install MongoDB.Shell` and `winget install MongoDB.DatabaseTools`.

## Step 3 — Final verification

```bash
mongosh --version
mongodump --version
```

## Gotchas

- **mongosh via npm requires Node.js.** If `npm` is missing, the script returns an explicit error. On macOS, suggest `brew install mongosh` instead. On Windows, install Node from nodejs.org first.
- **Database Tools archive distro key.** The script defaults to `ubuntu2404` for Linux. If the user is on RHEL/Fedora and reports compatibility issues, the manual install option uses `rhel90-<arch>` or `amazon2023-<arch>` — adjust the URL accordingly.
- **APT repo conflicts.** If the user previously installed via the official MongoDB APT repo, future `apt upgrade` calls may overwrite the binaries installed by this skill. Either pick one method and stick with it, or pin the APT package versions.
- **No connection strings stored.** The script installs binaries only — connection URIs to Atlas come from `/aws-secret-env` (look up `MONGO_URI` for the relevant app/env).
- **Windows install path.** Database Tools install to `%LOCALAPPDATA%\Programs\pysae\bin` via the shared install logic. Add to `%PATH%` if `mongodump` is not found.

## Notes

- Pysae uses MongoDB Atlas — the MCP servers (`/install-mongo-mcp`) are usually preferable to `mongosh` for ad-hoc queries.
- For `mongodump`/`mongorestore` operations, fetch the URI via `/aws-secret-env api dev MONGO_URI`.

$ARGUMENTS
