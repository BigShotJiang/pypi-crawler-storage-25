"""Base classes for the install tool framework.

All installable tools inherit from ``BaseTool``. Two concrete subclasses
handle the two families:

- ``BinaryTool`` — CLI binaries installed on the system (glab, aws, kubectl, …)
- ``McpTool`` — MCP server configs upserted into ``~/.claude.json``

Each tool module exposes ``_tool``, ``get_state``, ``do_install``, and ``cli``
at module level for backward compatibility with ``all.py``.
"""

import json
import subprocess
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Annotated, Any

import typer

from . import binary, platform
from .interactive import ensure_env_vars

# ---------------------------------------------------------------------------
# Shared dataclasses
# ---------------------------------------------------------------------------


@dataclass
class ToolState:
    """Universal tool state with needs_install / needs_update contract."""

    needs_install: bool = True
    needs_update: bool = False
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"needs_install": self.needs_install, "needs_update": self.needs_update}
        out.update(self.extra)
        return out


@dataclass
class InstallReport:
    """Universal install report."""

    action: str = "install"
    version: str = ""
    path: str = ""
    method: str = ""
    error: str = ""
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"action": self.action}
        for f in ("version", "path", "method", "error"):
            v = getattr(self, f)
            if v:
                out[f] = v
        if self.extra:
            out.update(self.extra)
        return out


@dataclass
class EnvVar:
    """Environment variable definition for a tool."""

    name: str
    help: str = ""
    auto_resolve: str = ""  # Shell command to auto-resolve the value


@dataclass
class Context:
    """A named context/profile that can be checked."""

    name: str
    ok: bool = False
    error: str = ""


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------


class BaseTool(ABC):
    """Abstract base for all installable tools."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Tool name as used in the CLI (e.g. 'glab', 'aws-cli', 'mongo-mcp')."""

    @property
    def cli_help(self) -> str:
        return f"Install/check {self.name}"

    @property
    def env_vars(self) -> list[EnvVar]:
        """Env vars required for installation. Override in subclass."""
        return []

    @property
    def env_required(self) -> tuple[str, ...]:
        return tuple(v.name for v in self.env_vars)

    @property
    def env_help(self) -> dict[str, str]:
        return {v.name: v.help for v in self.env_vars if v.help}

    # --- State ---

    @abstractmethod
    def get_state(self) -> ToolState:
        """Return current state of this tool."""

    # --- Install ---

    @abstractmethod
    def do_install(self) -> InstallReport:
        """Perform the installation. Returns a report."""

    # --- Identity for status display ---

    def extract_identity(self, state: dict[str, Any]) -> list[tuple[str, str | None]]:
        """Return identity/context lines for the status display."""
        return []

    # --- Human-readable output ---

    def format_check(self, state: ToolState) -> None:
        """Print human-readable check output. Override for custom formatting."""
        d = state.to_dict()
        bin_info = d.get("binary", {})
        if isinstance(bin_info, dict) and bin_info.get("installed"):
            version = bin_info.get("version", "n/a")
            latest = d.get("latest", "")
            update = f" (latest {latest})" if latest and latest != version else ""
            typer.echo(f"{self.name}: {version}{update}")
        else:
            typer.echo(f"{self.name}: NOT installed")

    def format_install(self, report: InstallReport) -> None:
        """Print human-readable install output."""
        if report.error:
            typer.echo(f"FAILED: {report.error}", err=True)
        else:
            parts = [f"installed {self.name}"]
            if report.version:
                parts[0] += f" {report.version}"
            if report.method:
                parts.append(f"via {report.method}")
            if report.path:
                parts.append(f"at {report.path}")
            typer.echo(" ".join(parts))

    # --- CLI generation ---

    def make_cli(self) -> typer.Typer:
        """Generate a standard check/install typer CLI."""
        tool = self
        cli = typer.Typer(no_args_is_help=True, help=tool.cli_help)

        @cli.command()
        def check(
            json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
        ) -> None:
            state = tool.get_state()
            if json_output:
                typer.echo(json.dumps(state.to_dict()))
            else:
                tool.format_check(state)

        @cli.command()
        def install(
            json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
            interactive: Annotated[bool, typer.Option("--interactive", "-i", help="Prompt for missing config")] = False,
        ) -> None:
            # Resolve env vars
            if tool.env_vars:
                missing = [v.name for v in tool.env_vars if not __import__("os").environ.get(v.name)]
                if missing:
                    if not ensure_env_vars(tool.env_required, tool.name, tool.env_help, interactive=interactive):
                        msg = f"Missing env vars: {', '.join(missing)}"
                        if json_output:
                            typer.echo(json.dumps({"action": "install", "error": msg}))
                        else:
                            typer.echo(f"FAILED: {msg}", err=True)
                        raise typer.Exit(code=1)

            report = tool.do_install()
            if json_output:
                typer.echo(json.dumps(report.to_dict()))
            elif report.error:
                typer.echo(f"FAILED: {report.error}", err=True)
                raise typer.Exit(code=1)
            else:
                tool.format_install(report)

        return cli


# ---------------------------------------------------------------------------
# BinaryTool
# ---------------------------------------------------------------------------


class BinaryTool(BaseTool, ABC):
    """Tool installed as a system binary."""

    @property
    @abstractmethod
    def binary_name(self) -> str:
        """Name of the binary on PATH (e.g. 'glab', 'aws', 'kubectl')."""

    @property
    def version_arg(self) -> str:
        return "--version"

    @property
    def version_timeout(self) -> int:
        """Timeout in seconds for version detection. Override for slow tools."""
        return 5

    @abstractmethod
    def fetch_latest_version(self) -> str:
        """Fetch the latest available version string."""

    @abstractmethod
    def install_binary(self) -> InstallReport:
        """Download and install the binary."""

    # --- Optional overrides ---

    def check_auth(self) -> dict[str, Any] | None:
        """Return auth info dict (e.g. {'auth_ok': True, 'auth_message': '...'}) or None."""
        return None

    def check_contexts(self) -> dict[str, Any] | None:
        """Return contexts/profiles dict or None."""
        return None

    # --- Concrete implementations ---

    def get_state(self) -> ToolState:
        bin_status = binary.status(self.binary_name, version_arg=self.version_arg, timeout=self.version_timeout)
        try:
            latest = self.fetch_latest_version().lstrip("v")
        except Exception:  # noqa: BLE001
            latest = ""

        extra: dict[str, Any] = {
            "binary": bin_status.to_dict(),
            "latest": latest,
        }

        auth = self.check_auth()
        if auth is not None:
            extra.update(auth)

        contexts = self.check_contexts()
        if contexts is not None:
            extra.update(contexts)

        return ToolState(
            needs_install=not bin_status.installed,
            needs_update=bin_status.installed and bool(latest) and binary.needs_update(bin_status.version, latest),
            extra=extra,
        )

    def do_install(self) -> InstallReport:
        return self.install_binary()

    def format_check(self, state: ToolState) -> None:
        d = state.to_dict()
        bin_info = d.get("binary", {})
        if isinstance(bin_info, dict) and bin_info.get("installed"):
            version = bin_info.get("version", "n/a")
            latest = d.get("latest", "")
            update = f" (latest {latest})" if latest and latest != version else ""
            typer.echo(f"{self.name}: {version}{update}")

            # Auth
            if "auth_ok" in d:
                typer.echo(f"  auth: {'OK' if d['auth_ok'] else 'FAILED'}")

            # Contexts
            for line_text, _ in self.extract_identity(d):
                typer.echo(f"  {line_text}")
        else:
            typer.echo(f"{self.name}: NOT installed")


# ---------------------------------------------------------------------------
# McpTool
# ---------------------------------------------------------------------------


class McpTool(BaseTool, ABC):
    """Tool that upserts an MCP server config into ~/.claude.json."""

    from . import mcp

    @property
    @abstractmethod
    def server_name(self) -> str:
        """MCP server name in claude.json."""

    @abstractmethod
    def build_config(self) -> dict[str, Any]:
        """Build the MCP server config dict."""

    def get_state(self) -> ToolState:
        from .mcp_cli import status_dict

        status = status_dict(self.server_name, env_keys=self.env_required)
        installed = status.get("configured", False)
        return ToolState(
            needs_install=not installed,
            needs_update=False,
            extra=status,
        )

    def do_install(self) -> InstallReport:
        from . import mcp

        try:
            config = self.build_config()
        except Exception as exc:  # noqa: BLE001
            return InstallReport(error=str(exc))

        changed = mcp.upsert_server(self.server_name, config)
        return InstallReport(
            extra={"name": self.server_name, "changed": changed},
        )

    def format_check(self, state: ToolState) -> None:
        d = state.to_dict()
        if d.get("configured"):
            typer.echo(f"{self.server_name}: configured")
        else:
            typer.echo(f"{self.server_name}: NOT configured")

    def format_install(self, report: InstallReport) -> None:
        changed = report.extra.get("changed", False)
        if report.error:
            typer.echo(f"FAILED: {report.error}", err=True)
        elif changed:
            typer.echo(f"{self.server_name}: updated")
        else:
            typer.echo(f"{self.server_name}: already configured (no changes)")


# ---------------------------------------------------------------------------
# Convenience: download-and-install binary tool
# ---------------------------------------------------------------------------


class ArchiveBinaryTool(BinaryTool, ABC):
    """Binary tool installed from a downloaded archive."""

    @abstractmethod
    def archive_info(self, version: str, plat: platform.Platform) -> tuple[str, str | None]:
        """Return (download_url, archive_member_path_or_None) for the given version and platform."""

    def install_binary(self) -> InstallReport:
        try:
            plat = platform.detect()
        except ValueError as exc:
            return InstallReport(error=str(exc))

        try:
            version = self.fetch_latest_version()
        except Exception as exc:  # noqa: BLE001
            return InstallReport(error=f"could not fetch latest version: {exc}")

        url, member = self.archive_info(version.lstrip("v"), plat)

        from .download import download_and_install_binary

        try:
            path = download_and_install_binary(url, self.binary_name, archive_member=member)
        except Exception as exc:  # noqa: BLE001
            return InstallReport(error=f"download/install failed: {exc}")

        installed_v = binary.get_version(self.binary_name, version_arg=self.version_arg)
        return InstallReport(version=installed_v or version.lstrip("v"), path=str(path))


# ---------------------------------------------------------------------------
# UvTool — installed via `uv tool install`
# ---------------------------------------------------------------------------


class UvTool(BinaryTool, ABC):
    """Binary tool installed via ``uv tool install``."""

    @property
    @abstractmethod
    def pip_package(self) -> str:
        """PyPI package name (e.g. 'prefect')."""

    def install_binary(self) -> InstallReport:
        r = subprocess.run(
            ["uv", "tool", "install", "--force", "--reinstall", self.pip_package],
            capture_output=True,
            text=True,
            check=False,
        )
        if r.returncode != 0:
            return InstallReport(error=f"uv tool failed: {r.stderr.strip() or r.stdout.strip()}")
        installed_v = binary.get_version(self.binary_name, version_arg=self.version_arg)
        return InstallReport(version=installed_v, method="uv tool")
