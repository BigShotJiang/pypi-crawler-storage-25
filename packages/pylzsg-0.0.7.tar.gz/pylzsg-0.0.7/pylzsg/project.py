# fmt: off
name = 'pylzsg'
version = '0.0.7'
description = 'CLI bridge project that exposes the legacy Typer commands from pylizlib as the pylzsg command.'
requires_python = '>=3.13'
authors = []
# fmt: on
