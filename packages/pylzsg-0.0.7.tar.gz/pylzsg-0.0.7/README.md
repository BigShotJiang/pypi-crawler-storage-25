# pylzsg

`pylzsg` è una CLI Python basata su Typer che reimpacchetta i vecchi comandi CLI di `pylizlib` in un comando dedicato a questo progetto.

## Comandi disponibili

- `expFileList`
- `iniDup`
- `gen-project-py`
- `gen-qrc`
- `gen-res-ids`
- `gen-css-py`
- `temp`

## Avvio rapido

```bash
uv sync
uv run pylzsg --help
```

## Esempi

```bash
uv run pylzsg expFileList ./input ./output files.txt --recursive
uv run pylzsg iniDup ./config --sections --keys
uv run pylzsg gen-project-py ./pyproject.toml ./generated/project.py
uv run pylzsg gen-qrc --qrc-path ./resources.qrc --res-dir ./assets --res-dir ./icons
uv run pylzsg gen-res-ids ./resources.qrc ./generated/resources_ids.py --class-name ResourcesIds
uv run pylzsg gen-css-py ./styles ./generated/styles.py
uv run pylzsg temp
```

## Nota su `pylizlib`

Il progetto usa `pylizlib` come dipendenza locale `uv` tramite il path `../pyliz`.
