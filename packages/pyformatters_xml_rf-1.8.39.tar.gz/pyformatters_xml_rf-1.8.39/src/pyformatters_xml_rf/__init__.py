"""Sherpa XML RF formatter"""

__version__ = "1.8.39"
