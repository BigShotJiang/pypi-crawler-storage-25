# NOTE: 2026-05-07 11:28:37, self-evolved by tea_agent --- _execute_tool_call 添加工具执行的 DEBUG/WARNING 日志
"""
会话工具执行模块
负责工具调用执行、结果收集等功能
"""

import json
import logging
from typing import List, Dict, Tuple, Any, Optional, Callable
from types import SimpleNamespace

logger = logging.getLogger("session.tool")


class SessionToolMixin:
    """
    工具执行 mixin 类。
    期望使用者提供以下属性：
    - toolkit: Toolkit 实例
    - tool_log: 可选日志回调
    - _rounds_collector: 轮次收集器列表
    - messages: 消息列表
    """

# NOTE: 2026-05-04 16:44:39, self-evolved by tea_agent --- 修复 SessionToolMixin.__init__ 覆盖 self.messages 为空列表的 bug
    def __init__(self):
        self.toolkit = None
        self.tool_log: Optional[Callable[[str], None]] = None
        self._rounds_collector: List[Dict] = []
        # NOTE: 不设置 self.messages，由 BaseChatSession.__init__ 负责初始化

    def _build_tools(self):
        """构建工具定义列表"""
        tools = []
        for name, meta in self.toolkit.meta_map.items():
            tools.append(meta)
        return tools

# NOTE: 2026-04-30 16:22:21, self-evolved by tea_agent --- _execute_tool_call增加反思追踪记录：计时、成功/失败状态
    def _execute_tool_call(self, call) -> Tuple[str, str, str]:
        """
        执行单个工具调用。

        Args:
            call: 工具调用对象（需有 .id, .function.name, .function.arguments）

        Returns:
            Tuple[str, str, str]: (call_id, func_name, result_string)
        """
        import time
        func_name = call.function.name
        call_id = call.id
        start_time = time.time()

# NOTE: 2026-05-07 11:28:52, self-evolved by tea_agent --- _execute_tool_call 中工具失败时添加 WARNING 日志，执行成功添加 DEBUG 日志
        if func_name not in self.toolkit.func_map:
            err = f"错误：未知工具 {func_name}"
            logger.warning(f"tool call failed: unknown function '{func_name}'")
            self._add_tool_result(call_id, err)
            self._record_tool_to_trace(func_name, False, err, start_time)
            return call_id, func_name, err

        try:
            args = json.loads(call.function.arguments)
        except json.JSONDecodeError:
            err = "错误：参数解析失败"
            logger.warning(f"tool call failed: JSON decode error, func={func_name}, raw_args={call.function.arguments[:200]}")
            self._add_tool_result(call_id, err)
            self._record_tool_to_trace(func_name, False, err, start_time)
            return call_id, func_name, err

        if self.tool_log:
            self.tool_log(f"🔧 调用工具: {func_name}({args})")

        success = True
        error_msg = ""
# NOTE: 2026-05-07 11:29:02, self-evolved by tea_agent --- 工具执行 try/except 添加 WARNING 日志
# NOTE: 2026-05-09 19:34:47, self-evolved by tea_agent --- _execute_tool_call 用 toolkit.call_tool() 替代直接 func_map 调用，启用缓存
        try:
            result = self.toolkit.call_tool(func_name, **args)
            if self.tool_log:
                self.tool_log(f"✅ 结果: {result}")
        except Exception as e:
            result = f"工具执行错误: {e}"
            logger.warning(f"tool execution failed: {func_name}, error={e}")
            success = False
            error_msg = str(e)
            if self.tool_log:
                self.tool_log(f"❌ 错误: {e}")

        result_str = str(result)
        self._add_tool_result(call_id, result_str)
        self._record_tool_to_trace(func_name, success, error_msg, start_time)
        return call_id, func_name, result_str

    # 2026-04-30 gen by deepseek-v4-pro, 记录工具调用到反思追踪
    def _record_tool_to_trace(self, func_name: str, success: bool, error_msg: str, start_time: float):
        """记录工具调用到当前反思追踪"""
        import time
        trace = getattr(self, '_current_trace', None)
        if trace is None:
            return
        reflection_mgr = getattr(self, 'reflection_manager', None)
        if reflection_mgr is None:
            return
        duration_ms = (time.time() - start_time) * 1000
        reflection_mgr.record_tool_call(trace, func_name, success, error_msg, duration_ms)

    def _add_tool_result(self, tool_call_id: str, content: str):
        """添加工具执行结果到消息列表"""
        self.messages.append({
            "role": "tool",
            "tool_call_id": tool_call_id,
            "content": content
        })

    def _collect_tool_call_round(self, call_id: str, result_str: str):
        """收集 tool result 到 rounds 收集器"""
        self._rounds_collector.append({
            "role": "tool",
            "content": result_str,
            "tool_call_id": call_id,
        })

    # NOTE: 2026-04-28, self-evolved by claude-agent ---
    # 增加 reasoning_content 参数，确保 DeepSeek 推理模型的思维链内容
    # 在持久化到 rounds_json 时不会丢失。
    def _collect_assistant_tool_calls_round(self, content: str, tool_calls: list, reasoning_content: str = ""):
        """收集 assistant tool_calls 到 rounds 收集器"""
        tc_list_for_collector = [{
            "id": tc.id,
            "type": "function",
            "function": {
                "name": tc.function.name,
                "arguments": tc.function.arguments
            }
        } for tc in tool_calls]

        entry = {
            "role": "assistant",
            "content": content if content else "",
            "tool_calls": tc_list_for_collector,
        }
        if reasoning_content:
            entry["reasoning_content"] = reasoning_content
        self._rounds_collector.append(entry)

    # NOTE: 2026-04-28, self-evolved by claude-agent ---
    # 增加 reasoning_content 参数，确保 DeepSeek 推理模型的思维链内容
    # 在持久化时不丢失。
    def _collect_assistant_text_round(self, content: str, reasoning_content: str = ""):
        """收集最终 assistant 文本回答到 rounds 收集器"""
        entry = {
            "role": "assistant",
            "content": content,
        }
        if reasoning_content:
            entry["reasoning_content"] = reasoning_content
        self._rounds_collector.append(entry)

    def _collect_api_error_round(self, content: str):
        """收集 API 错误到 rounds 收集器"""
        self._rounds_collector.append({
            "role": "assistant",
            "content": content,
        })

    def _collect_max_iterations_round(self, content: str):
        """收集迭代超限警告到 rounds 收集器"""
        self._rounds_collector.append({
            "role": "assistant",
            "content": content,
        })

    def _collect_interruption_round(self, content: str):
        """收集打断消息到 rounds 收集器"""
        self._rounds_collector.append({
            "role": "assistant",
            "content": content,
        })

    def _parse_tool_calls_from_stream(self, tool_calls_data: List[Dict]) -> list:
        """
        将流式解析中的工具调用数据转为有效的工具调用对象列表。

        Args:
            tool_calls_data: 流式累积的工具调用数据

        Returns:
            有效的工具调用对象列表（SimpleNamespace）
        """
        valid_tool_calls = []
        for tc_data in tool_calls_data:
            if tc_data["id"] and tc_data["name"]:
                valid_tool_calls.append(SimpleNamespace(
                    id=tc_data["id"],
                    function=SimpleNamespace(
                        name=tc_data["name"],
                        arguments=tc_data["arguments"]
                    )
                ))
        return valid_tool_calls

    def _accumulate_tool_calls_from_delta(self, delta, tool_calls_data: List[Dict]):
        """
        从流式 chunk 的 delta 中累积工具调用数据。

        Args:
            delta: 流式响应的 delta 对象
            tool_calls_data: 用于累积的工具调用数据列表
        """
        if not delta.tool_calls:
            return

        for tc in delta.tool_calls:
            idx = tc.index

            # 扩展列表
            while len(tool_calls_data) <= idx:
                tool_calls_data.append({
                    "id": "",
                    "name": "",
                    "arguments": ""
                })

            if tc.id:
                tool_calls_data[idx]["id"] = tc.id
            if tc.function:
                if tc.function.name:
                    tool_calls_data[idx]["name"] = tc.function.name
                if tc.function.arguments:
                    tool_calls_data[idx]["arguments"] += tc.function.arguments
