"""CLI command handlers."""

from .build import handle_build
from .card_add import handle_card_add
from .card_inspect import handle_card_add_event, handle_card_list_events, handle_card_view
from .card_list import handle_card_list
from .card_pull import handle_card_pull
from .card_push import handle_card_push
from .card_remote import handle_card_remote_list
from .create import handle_create
from .login import handle_login
from .page_create import handle_page_add, handle_page_view
from .web import handle_web, handle_web_verify

__all__ = [
    "handle_build",
    "handle_web",
    "handle_web_verify",
    "handle_card_add",
    "handle_card_add_event",
    "handle_card_list",
    "handle_card_list_events",
    "handle_card_pull",
    "handle_card_push",
    "handle_card_remote_list",
    "handle_card_view",
    "handle_create",
    "handle_login",
    "handle_page_add",
    "handle_page_view",
]
