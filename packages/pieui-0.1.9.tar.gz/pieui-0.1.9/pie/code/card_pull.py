from pathlib import Path

from pie.code.card_add import normalize_class_name
from pie.code.services.storage import PieStorageService
from pie.config import get_settings


def _parse_user_component(remote_ref: str) -> tuple[str, str]:
    s = remote_ref.strip()
    if "/" not in s:
        raise ValueError(
            "Expected USER/COMPONENT, e.g. alice/MyCard — use: pie card pull USER/COMPONENT"
        )
    user_id, raw_name = s.split("/", 1)
    user_id = user_id.strip()
    raw_name = raw_name.strip()
    if not user_id or not raw_name:
        raise ValueError("USER and COMPONENT must be non-empty")
    if user_id in {".", ".."} or ".." in user_id or "/" in user_id or "\\" in user_id:
        raise ValueError("Invalid USER in USER/COMPONENT")
    if raw_name in {".", ".."} or ".." in raw_name or "/" in raw_name or "\\" in raw_name:
        raise ValueError("Invalid COMPONENT in USER/COMPONENT (must be a single name, no path)")
    return user_id, raw_name


def handle_card_pull(remote_ref: str) -> list[Path]:
    user_id, raw_name = _parse_user_component(remote_ref)
    class_name = normalize_class_name(raw_name)
    settings = get_settings()
    target_dir = settings.components_dir.resolve()
    target_dir.mkdir(parents=True, exist_ok=True)

    paths = PieStorageService(settings).download_component_directory(
        component_name=class_name,
        target_dir=target_dir,
        user_id=user_id,
        project_slug=None,
    )
    if not paths:
        raise ValueError(
            f"No python files found for component {class_name!r} under user {user_id!r}"
        )
    print(f"[pie] Pulled card: {class_name} (user={user_id!r})")
    for p in paths:
        print(f"[pie] Path: {p}")
    return paths
