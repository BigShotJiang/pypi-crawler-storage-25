from dataclasses import dataclass, field
from typing import Optional

from dataclasses_json import DataClassJsonMixin, dataclass_json, LetterCase
from pydantic import BaseModel, ConfigDict


class ComponentTree(BaseModel):
    """Remote component listing (prefix + language groups). Extra keys are allowed."""

    model_config = ConfigDict(extra="allow")

    prefix: str


class ProjectComponentEntry(BaseModel):
    """One component name under a user/project (OpenAPI ProjectComponentList.components[]."""

    model_config = ConfigDict(extra="ignore")

    name: str


class ProjectComponentList(BaseModel):
    """Response of GET /api/components/{user_id}/{project_slug}."""

    model_config = ConfigDict(extra="ignore")

    user_id: str
    project_slug: str
    components: list[ProjectComponentEntry]


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class ComponentObject(DataClassJsonMixin):
    key: str
    size: int | None = None
    content_type: Optional[str] = None
    signed_url: Optional[str] = None
