"""CLI handlers for remote PieUI storage (see OpenAPI: /api/components/...)."""

from dotenv import load_dotenv

from pie.code.services.storage import PieStorageService
from pie.config import get_settings


def handle_card_remote_list(
    *,
    user_id: str | None = None,
    project_slug: str | None = None,
) -> None:
    load_dotenv()
    get_settings.cache_clear()
    settings = get_settings()
    uid = user_id or settings.user_id
    slug = project_slug or settings.project_slug
    if not uid:
        raise ValueError("user_id is required (use --user or set PIE_USER_ID)")
    if not slug:
        raise ValueError("project is required (use --project or set PIE_PROJECT)")

    result = PieStorageService(settings).list_project_components(
        user_id=uid,
        project_slug=slug,
    )
    print(
        f"[pie] Remote components for user_id={result.user_id!r} "
        f"project_slug={result.project_slug!r}:"
    )
    for entry in sorted(result.components, key=lambda c: c.name.lower()):
        print(entry.name)
