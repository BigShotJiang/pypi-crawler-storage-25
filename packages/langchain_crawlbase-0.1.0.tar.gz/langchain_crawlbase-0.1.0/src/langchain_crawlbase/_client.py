"""Thin HTTP wrapper around the Crawlbase Crawling API."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from urllib.parse import quote

import requests

API_ENDPOINT = "https://api.crawlbase.com/"
DEFAULT_TIMEOUT = 90


class CrawlbaseError(Exception):
    """Raised when the Crawlbase API returns an unrecoverable error."""


@dataclass
class CrawlbaseResponse:
    url: str
    original_url: str
    body: str
    pc_status: int | None
    original_status: int | None
    content_type: str | None
    headers: dict[str, str]

    def metadata(self) -> dict[str, Any]:
        meta: dict[str, Any] = {"source": self.original_url}
        if self.url and self.url != self.original_url:
            meta["resolved_url"] = self.url
        if self.pc_status is not None:
            meta["pc_status"] = self.pc_status
        if self.original_status is not None:
            meta["original_status"] = self.original_status
        if self.content_type:
            meta["content_type"] = self.content_type
        return meta


class CrawlbaseClient:
    """Synchronous Crawlbase API client.

    Pass your normal token for static pages, or your JavaScript token for
    SPA / JS-rendered pages — Crawlbase routes the request based on which
    token you send.
    """

    def __init__(
        self,
        token: str,
        *,
        timeout: int = DEFAULT_TIMEOUT,
        session: requests.Session | None = None,
    ) -> None:
        if not token:
            raise ValueError("token is required")
        self.token = token
        self.timeout = timeout
        self._session = session or requests.Session()

    def fetch(
        self,
        url: str,
        *,
        format: str = "md",
        extra_params: dict[str, Any] | None = None,
    ) -> CrawlbaseResponse:
        """Fetch a single URL through the Crawlbase API.

        ``format`` defaults to ``md`` so the body is GitHub-flavored Markdown,
        ready for chunking by LangChain text splitters.
        """
        if not url:
            raise ValueError("url is required")

        params: dict[str, Any] = {
            "token": self.token,
            "url": quote(url, safe=""),
            "format": format,
        }
        if extra_params:
            params.update(extra_params)

        # Build the query string manually to avoid double-encoding the URL.
        query = "&".join(f"{k}={v}" for k, v in params.items())
        full_url = f"{API_ENDPOINT}?{query}"

        response = self._session.get(full_url, timeout=self.timeout)

        if response.status_code == 401:
            raise CrawlbaseError("Crawlbase rejected the token (401 Unauthorized)")
        if response.status_code == 429:
            raise CrawlbaseError("Crawlbase rate limit exceeded (429)")
        if response.status_code >= 500:
            raise CrawlbaseError(
                f"Crawlbase server error {response.status_code}: {response.text[:200]}"
            )

        headers = {k.lower(): v for k, v in response.headers.items()}
        pc_status = _maybe_int(headers.get("pc_status"))
        original_status = _maybe_int(headers.get("original_status"))
        resolved_url = headers.get("url", url)

        if pc_status is not None and pc_status >= 400:
            raise CrawlbaseError(
                f"Crawlbase returned pc_status={pc_status} for {url}"
            )

        return CrawlbaseResponse(
            url=resolved_url,
            original_url=url,
            body=response.text,
            pc_status=pc_status,
            original_status=original_status,
            content_type=headers.get("content-type"),
            headers=headers,
        )


def _maybe_int(value: str | None) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None
