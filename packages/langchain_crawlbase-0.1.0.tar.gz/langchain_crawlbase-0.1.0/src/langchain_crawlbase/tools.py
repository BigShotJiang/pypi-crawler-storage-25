"""LangChain tool that fetches a URL through Crawlbase and returns Markdown."""

from typing import Any, Dict, Optional, Type

from langchain_core.callbacks import CallbackManagerForToolRun
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, PrivateAttr

from ._client import CrawlbaseClient, CrawlbaseError


class _CrawlbaseToolInput(BaseModel):
    url: str = Field(description="The fully-qualified URL to fetch.")


class CrawlbaseTool(BaseTool):
    """Fetch a web page via Crawlbase and return its Markdown contents.

    Designed for use with LLM agents that need to read live web pages
    mid-conversation. The output is GitHub-flavored Markdown.

    Pass your normal Crawlbase token for static pages, or your JavaScript
    token for SPA / JS-rendered pages.
    """

    name: str = "crawlbase_fetch"
    description: str = (
        "Fetches the content of a web page via the Crawlbase API and returns "
        "it as Markdown. Input must be a single URL string."
    )
    args_schema: Type[BaseModel] = _CrawlbaseToolInput

    extra_params: Optional[Dict[str, Any]] = None

    _client: CrawlbaseClient = PrivateAttr()

    def __init__(
        self,
        token: str,
        *,
        extra_params: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(extra_params=extra_params, **kwargs)
        self._client = CrawlbaseClient(token=token)

    def _run(
        self,
        url: str,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        try:
            response = self._client.fetch(
                url,
                format="md",
                extra_params=self.extra_params,
            )
        except CrawlbaseError as exc:
            return f"Error fetching {url}: {exc}"
        return response.body
