"""LangChain document loader backed by the Crawlbase API."""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

from langchain_core.document_loaders import BaseLoader
from langchain_core.documents import Document

from ._client import CrawlbaseClient, CrawlbaseError


class CrawlbaseLoader(BaseLoader):
    """Load web pages as Markdown ``Document`` objects via Crawlbase.

    Pass your normal Crawlbase token for static pages, or your JavaScript
    token for SPA / JS-rendered pages — Crawlbase routes the request based
    on which token you send.

    Example:
        .. code-block:: python

            from langchain_crawlbase import CrawlbaseLoader

            loader = CrawlbaseLoader(
                token="YOUR_TOKEN",
                urls=["https://example.com", "https://example.org"],
            )
            docs = loader.load()
    """

    def __init__(
        self,
        token: str,
        urls: list[str],
        *,
        extra_params: dict[str, Any] | None = None,
        continue_on_failure: bool = True,
    ) -> None:
        if not urls:
            raise ValueError("urls must contain at least one URL")
        self._client = CrawlbaseClient(token=token)
        self.urls = list(urls)
        self.extra_params = extra_params
        self.continue_on_failure = continue_on_failure

    def lazy_load(self) -> Iterator[Document]:
        for url in self.urls:
            try:
                response = self._client.fetch(
                    url,
                    format="md",
                    extra_params=self.extra_params,
                )
            except CrawlbaseError:
                if self.continue_on_failure:
                    continue
                raise
            yield Document(page_content=response.body, metadata=response.metadata())
