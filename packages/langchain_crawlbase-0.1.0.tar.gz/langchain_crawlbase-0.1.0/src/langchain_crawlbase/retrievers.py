"""LangChain retriever that fetches seed URLs via Crawlbase and filters by query."""

from typing import Any, Dict, List, Optional

from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from pydantic import PrivateAttr

from ._client import CrawlbaseClient, CrawlbaseError


class CrawlbaseRetriever(BaseRetriever):
    """Retrieve documents from a fixed set of seed URLs via Crawlbase.

    Pass your normal Crawlbase token for static pages, or your JavaScript
    token for SPA / JS-rendered pages.

    v0.1 uses a simple case-insensitive substring match on the Markdown body.
    Smarter retrieval (embeddings, BM25) can be layered on top in v0.2.
    """

    urls: List[str]
    extra_params: Optional[Dict[str, Any]] = None
    top_k: Optional[int] = None

    _client: CrawlbaseClient = PrivateAttr()

    def __init__(
        self,
        token: str,
        urls: List[str],
        *,
        extra_params: Optional[Dict[str, Any]] = None,
        top_k: Optional[int] = None,
        **kwargs: Any,
    ) -> None:
        if not urls:
            raise ValueError("urls must contain at least one URL")
        super().__init__(
            urls=list(urls),
            extra_params=extra_params,
            top_k=top_k,
            **kwargs,
        )
        self._client = CrawlbaseClient(token=token)

    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: CallbackManagerForRetrieverRun,
    ) -> List[Document]:
        needle = query.lower().strip()
        results: List[Document] = []
        for url in self.urls:
            try:
                response = self._client.fetch(
                    url,
                    format="md",
                    extra_params=self.extra_params,
                )
            except CrawlbaseError:
                continue
            if not needle or needle in response.body.lower():
                results.append(
                    Document(page_content=response.body, metadata=response.metadata())
                )
        if self.top_k is not None:
            results = results[: self.top_k]
        return results
