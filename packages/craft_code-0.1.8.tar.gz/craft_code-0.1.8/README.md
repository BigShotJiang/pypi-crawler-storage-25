# Code Craft

A Claude Code-like AI coding assistant built with [LangChain Deep Agents](https://docs.langchain.com/oss/python/deepagents/overview).

## Features

- **File system access** — reads, writes, and edits project files
- **Shell execution** — runs commands (tests, linters, build tools)
- **Agentic planning** — breaks tasks into steps with `write_todos`
- **Human-in-the-loop** — asks approval before destructive operations
- **Persistent memory** — remembers project context across sessions
- **Subagent delegation** — spawns code-reviewer and researcher subagents
- **Skill system** — lazy-loaded workflows for testing, code review, etc.

## Installation

### Homebrew (macOS / Linux)

```bash
brew tap Shubham-1994/craft-code
brew install craft-code
```

### pip / pipx

```bash
pipx install craft-code      # recommended — installs in an isolated env
# or
pip install craft-code
```

### From source

```bash
git clone https://github.com/Shubham-1994/code-craft.git
cd code-craft
uv venv && source .venv/bin/activate
uv pip install -e .
```

## Quick Start

```bash
# 1. Install (see above)

# 2. Set your API key
export ANTHROPIC_API_KEY="sk-ant-..."
# or add it to a .env file in your project directory

# 3. Run
craft-code
```

## Usage

```bash
# Interactive CLI
craft-code

# Or run directly
python -m code_craft
```

Inside the CLI:
- Type your coding request
- The agent will ask for approval before file writes and shell commands
- Use `/new` to start a fresh thread, `/quit` to exit

## Programmatic Usage

```python
from code_craft.agent import build_agent
from code_craft.config import AgentConfig

config = AgentConfig(project_root="/path/to/your/project")
agent, checkpointer, store = build_agent(config)
```

## Configuration

Set these in `.env` or as environment variables:

| Variable | Default | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | (required) | Your Anthropic API key |
| `MODEL` | `anthropic:claude-sonnet-4-6` | Model to use |
| `PROJECT_ROOT` | `.` | Root directory for file operations |

## Architecture

```
code_craft/
  agent.py              — Agent factory with backends, subagents, skills
  cli.py                — Interactive Rich-powered CLI
  config.py             — AgentConfig dataclass
  interrupt_handler.py  — Human-in-the-loop approval UI
  prompts.py            — System prompts
  tools.py              — Custom tools (git, delete, tests)
skills/
  testing/SKILL.md      — Test writing workflow
  code_review/SKILL.md  — Code review workflow
AGENTS.md               — Project context for the agent
```
