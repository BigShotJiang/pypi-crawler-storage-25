"""Custom tools that extend the built-in Deep Agents toolset."""

import os
import subprocess

from langchain_core.tools import tool


@tool
def delete_file(path: str) -> str:
    """Permanently delete a file. Use with caution — this cannot be undone."""
    if not os.path.exists(path):
        return f"Error: {path} does not exist"
    os.remove(path)
    return f"Deleted {path}"


@tool
def git_status() -> str:
    """Show the current git status of the project."""
    result = subprocess.run(
        ["git", "status", "--short"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        return f"Error: {result.stderr}"
    return result.stdout or "Working tree clean"


@tool
def git_diff(path: str = "") -> str:
    """Show git diff for staged and unstaged changes. Optionally filter by path."""
    cmd = ["git", "diff"]
    if path:
        cmd.append(path)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        return f"Error: {result.stderr}"
    return result.stdout or "No changes"


@tool
def run_tests(command: str = "pytest") -> str:
    """Run the project's test suite. Defaults to pytest."""
    result = subprocess.run(
        command.split(),
        capture_output=True,
        text=True,
        timeout=300,
    )
    output = result.stdout
    if result.stderr:
        output += f"\nSTDERR:\n{result.stderr}"
    return output


CUSTOM_TOOLS = [delete_file, git_status, git_diff, run_tests]
