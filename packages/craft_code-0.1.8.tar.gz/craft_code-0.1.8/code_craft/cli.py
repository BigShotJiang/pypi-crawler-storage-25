"""Interactive CLI for the deep coding agent — the main entry point."""

from __future__ import annotations

import sys
import uuid
from pathlib import Path

from langgraph.types import Command
from rich.console import Console
from rich.markdown import Markdown
from rich.rule import Rule

from .agent import build_agent
from .auth import ensure_api_key, logout, purge_config
from .config import AgentConfig
from .interrupt_handler import collect_decisions

from prompt_toolkit import prompt as pt_prompt
from prompt_toolkit.formatted_text import HTML

console = Console()

BANNER = r"""
[bold cyan]╔══════════════════════════════════════════╗
║       Code-Craft Coding Agent v0.1.0     ║
╚══════════════════════════════════════════╝[/bold cyan]

Type your request, or use these commands:
  [green]/help[/green]    — show this help
  [green]/new[/green]     — start a new thread
  [green]/logout[/green]  — remove saved API key
  [green]/quit[/green]    — exit

"""


def _trust_check(project_root: Path) -> bool:
    """Show a Claude Code-style trust prompt before granting filesystem access.

    Returns True if the user trusts the folder, False to abort.
    """
    console.print()
    console.print(Rule("[bold yellow]Accessing workspace[/bold yellow]"))
    console.print()
    console.print(f"  [bold]{project_root}[/bold]")
    console.print()
    console.print(
        "  Quick safety check: Is this a project you created or one you trust?\n"
        "  (Like your own code, a well-known open source project, or work from\n"
        "  your team.) If not, take a moment to review what's in this folder first."
    )
    console.print()
    console.print("  [dim]The agent will be able to read, edit, and execute files here.[/dim]")
    console.print()

    options = [
        ("1", "Yes, I trust this folder", True),
        ("2", "No, exit",                 False),
    ]

    for key, label, _ in options:
        console.print(f"  [bold cyan]>[/bold cyan] [bold]{key}.[/bold] {label}")

    console.print()

    while True:
        try:
            choice = console.input("  Enter number to confirm (or Ctrl+C to cancel): ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print()
            return False

        if choice == "1":
            console.print()
            return True
        elif choice == "2":
            console.print()
            return False
        else:
            console.print("  [yellow]Please enter 1 or 2.[/yellow]")


def _tool_call_detail(name: str, args: dict) -> str:
    """Brief inline detail for a tool call."""
    if name in ("read_file", "edit_file", "write_file", "delete_file"):
        return f"  [dim]{args.get('file_path', '')}[/dim]"
    if name == "execute":
        cmd = args.get("command", "")
        if len(cmd) > 80:
            cmd = cmd[:80] + "..."
        return f"  [dim]{cmd}[/dim]"
    if name == "run_tests":
        return f"  [dim]{args.get('command', 'pytest')}[/dim]"
    return ""


def _display_stream_chunk(chunk: dict) -> None:
    """Display a single stream update chunk — shows tool calls as they happen."""
    if not isinstance(chunk, dict):
        return
    for node_name, output in chunk.items():
        if node_name == "__interrupt__":
            continue
        if not isinstance(output, dict):
            continue
        messages = output.get("messages", [])
        if not isinstance(messages, list):
            continue
        for msg in messages:
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                for tc in msg.tool_calls:
                    name = tc["name"]
                    detail = _tool_call_detail(name, tc.get("args", {}))
                    console.print(f"  [bold cyan]→ {name}[/bold cyan]{detail}")


def _has_interrupts(state) -> bool:
    """Check whether a LangGraph state snapshot has pending interrupts."""
    return bool(state.tasks and any(t.interrupts for t in state.tasks))


def _get_interrupt_value(state) -> dict:
    """Extract the first interrupt value from a state snapshot."""
    for task in state.tasks:
        for interrupt in task.interrupts:
            return interrupt.value
    return {}


def _print_response(content: str) -> None:
    """Render the agent's response as markdown."""
    console.print()
    console.print(Markdown(content))
    console.print()


def main():
    """Run the interactive coding agent CLI."""
    import sys

    # Handle top-level subcommands before anything else
    if len(sys.argv) > 1:
        subcmd = sys.argv[1].lower()
        if subcmd == "logout":
            logout()
            sys.exit(0)
        elif subcmd == "uninstall":
            purge_config()
            console.print()
            console.print("  To fully uninstall the package, run:")
            console.print("  [bold]pip uninstall code-craft[/bold]")
            console.print("  [dim]or, if installed with uv:[/dim]")
            console.print("  [bold]uv pip uninstall code-craft[/bold]")
            sys.exit(0)
        elif subcmd in ("--help", "-h", "help"):
            console.print(BANNER)
            sys.exit(0)

    # Ensure API key is available before anything else — prompts once if missing
    ensure_api_key()

    config = AgentConfig()

    console.print(BANNER)

    # --- Trust gate: must pass before the agent is built or any files touched ---
    if not _trust_check(config.resolved_root):
        console.print("[dim]Exiting. No files were accessed.[/dim]")
        sys.exit(0)

    console.print(f"[dim]Model: {config.model}[/dim]")
    console.print(f"[dim]Project root: {config.resolved_root}[/dim]")
    console.print()

    try:
        agent, checkpointer, store = build_agent(config)
    except Exception as e:
        console.print(f"[red]Failed to build agent: {e}[/red]")
        sys.exit(1)

    thread_id = str(uuid.uuid4())
    lang_config = {"configurable": {"thread_id": thread_id}}

    console.print(f"[dim]Thread: {thread_id[:8]}...[/dim]")

    while True:
        try:
            console.rule()
            user_input = pt_prompt(HTML("<ansigreen><b>&gt;</b></ansigreen> ")).strip()
            console.rule()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Goodbye![/dim]")
            break

        if not user_input:
            continue

        # Handle commands
        if user_input.startswith("/"):
            cmd = user_input.lower()
            if cmd in ("/quit", "/exit", "/q"):
                console.print("[dim]Goodbye![/dim]")
                break
            elif cmd == "/new":
                thread_id = str(uuid.uuid4())
                lang_config = {"configurable": {"thread_id": thread_id}}
                console.print(f"[dim]New thread: {thread_id[:8]}...[/dim]")
                continue
            elif cmd == "/help":
                console.print(BANNER)
                continue
            elif cmd == "/logout":
                logout()
                continue
            else:
                console.print(f"[yellow]Unknown command: {user_input}[/yellow]")
                continue

        # Stream agent execution with real-time step display
        try:
            input_data = {"messages": [{"role": "user", "content": user_input}]}

            for chunk in agent.stream(input_data, lang_config, stream_mode="updates"):
                _display_stream_chunk(chunk)

            # Handle interrupts (approval loop)
            state = agent.get_state(lang_config)
            while _has_interrupts(state):
                decisions = collect_decisions(_get_interrupt_value(state))
                for chunk in agent.stream(
                    Command(resume={"decisions": decisions}),
                    lang_config,
                    stream_mode="updates",
                ):
                    _display_stream_chunk(chunk)
                state = agent.get_state(lang_config)

            # Print the final response
            messages = state.values.get("messages", [])
            if messages:
                last_msg = messages[-1]
                content = getattr(last_msg, "content", str(last_msg))
                if content:
                    _print_response(content)

        except KeyboardInterrupt:
            console.print("\n[yellow]Interrupted.[/yellow]")
        except Exception as e:
            console.print(f"\n[red]Error: {e}[/red]")


if __name__ == "__main__":
    main()
