"""Human-in-the-loop interrupt handling for tool approval."""

from __future__ import annotations

import difflib

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

console = Console()


def _format_action(action: dict) -> Panel:
    """Format a tool call action as a rich panel for display."""
    name = action.get("name", "unknown")
    args = action.get("args", {})

    table = Table(show_header=False, box=None, padding=(0, 1))
    for key, value in args.items():
        display_value = str(value)
        if len(display_value) > 200:
            display_value = display_value[:200] + "..."
        table.add_row(f"[bold]{key}[/bold]", display_value)

    return Panel(table, title=f"[bold yellow]{name}[/bold yellow]", border_style="yellow")


def _print_edit_diff(action: dict) -> None:
    """Print an edit_file action as a colored unified diff between horizontal rules."""
    args = action.get("args", {})
    old_string = args.get("old_string")
    new_string = args.get("new_string")
    file_path = args.get("file_path", "unknown file")

    if old_string is None or new_string is None:
        console.print(_format_action(action))
        return

    old_lines = old_string.splitlines(keepends=True)
    new_lines = new_string.splitlines(keepends=True)
    diff = list(difflib.unified_diff(old_lines, new_lines, fromfile=file_path, tofile=file_path))

    console.rule(f"[bold yellow]edit_file[/bold yellow] → {file_path}")

    text = Text()
    for line in diff:
        stripped = line.rstrip("\n")
        if line.startswith("---") or line.startswith("+++"):
            text.append(stripped + "\n", style="bold")
        elif line.startswith("@@"):
            text.append(stripped + "\n", style="dim cyan")
        elif line.startswith("-"):
            text.append(stripped + "\n", style="red strike")
        elif line.startswith("+"):
            text.append(stripped + "\n", style="green")
        else:
            text.append(stripped + "\n")

    # Remove trailing newline for cleaner display
    if text.plain.endswith("\n"):
        text.right_crop(1)

    console.print(text)
    console.rule()


def collect_decisions(interrupt_value: dict) -> list[dict]:
    """Display pending actions and collect user approve/edit/reject decisions.

    Args:
        interrupt_value: The interrupt value dict with action_requests and review_configs.

    Returns:
        List of decision dicts (one per action).
    """
    action_requests = interrupt_value.get("action_requests", [])
    review_configs = interrupt_value.get("review_configs", [])

    decisions = []
    for i, action in enumerate(action_requests):
        console.print()
        if action.get("name") == "edit_file":
            _print_edit_diff(action)
        else:
            console.print(_format_action(action))

        # Determine allowed decisions
        allowed = ["approve", "edit", "reject"]
        if i < len(review_configs):
            rc = review_configs[i]
            if isinstance(rc, dict) and "allowed_decisions" in rc:
                allowed = rc["allowed_decisions"]

        prompt_parts = []
        if "approve" in allowed:
            prompt_parts.append("[green]a[/green]pprove")
        if "edit" in allowed:
            prompt_parts.append("[yellow]e[/yellow]dit")
        if "reject" in allowed:
            prompt_parts.append("[red]r[/red]eject")

        prompt = " / ".join(prompt_parts) + "? "
        console.rule()
        choice = console.input(prompt).strip().lower()
        console.rule()

        if choice in ("a", "approve"):
            decisions.append({"type": "approve"})
        elif choice in ("r", "reject"):
            decisions.append({"type": "reject"})
        elif choice in ("e", "edit") and "edit" in allowed:
            console.print("[dim]Enter edited arguments as key=value pairs (blank line to finish):[/dim]")
            new_args = dict(action.get("args", {}))
            while True:
                line = console.input("  > ").strip()
                if not line:
                    break
                if "=" in line:
                    key, _, value = line.partition("=")
                    new_args[key.strip()] = value.strip()
            decisions.append({
                "type": "edit",
                "edited_action": {"name": action["name"], "args": new_args},
            })
        else:
            console.print("[red]Invalid choice, defaulting to reject.[/red]")
            decisions.append({"type": "reject"})

    return decisions
