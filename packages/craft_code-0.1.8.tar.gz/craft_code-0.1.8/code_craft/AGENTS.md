# Project: Code Craft

## Overview
A Claude Code-like AI coding assistant built with LangChain Deep Agents.

## Tech Stack
- Python 3.11+
- LangChain Deep Agents framework
- LangGraph for orchestration
- Rich for terminal UI

## Project Structure
```
code_craft/
  __init__.py       — package metadata
  agent.py          — core agent factory (build_agent)
  cli.py            — interactive CLI entry point
  config.py         — AgentConfig dataclass
  interrupt_handler.py — human-in-the-loop approval UI
  prompts.py        — system prompts for agent and subagents
  tools.py          — custom tools (git, delete, test runner)
skills/
  testing/SKILL.md
  code_review/SKILL.md
```

## Commands
- Run: `code-craft` or `python -m code_craft.cli`
- Test: `pytest`
- Lint: `ruff check .`

## Conventions
- Use type hints on public functions
- Keep modules focused — one responsibility per file
- Use Rich for all terminal output
