---
name: testing
description: Use when asked to write, run, or debug tests for any module or function.
---

# Testing Skill

Use this when asked to write, run, or debug tests.

## Workflow
1. Read the source file being tested
2. Identify all public functions/methods and their edge cases
3. Write unit tests using the project's test framework (default: pytest)
4. Run the tests to verify they pass
5. Fix any failures and re-run until green

## Conventions
- Test file path: `tests/test_<module>.py`
- Use fixtures for shared setup
- Mock external dependencies (network, DB) but not internal logic
- Each test should be independent and deterministic
- Name tests: `test_<function>_<scenario>_<expected>`
