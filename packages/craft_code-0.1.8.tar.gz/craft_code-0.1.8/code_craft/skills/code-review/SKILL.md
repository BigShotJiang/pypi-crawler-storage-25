---
name: code-review
description: Use when asked to review code, check for bugs, security issues, or audit a file.
---

# Code Review Skill

Use this when asked to review code, check for issues, or audit a file.

## Workflow
1. Read the file(s) to review
2. Analyze for bugs, security issues, performance, and style
3. Categorize findings by severity: critical, warning, info
4. Suggest specific fixes with code snippets
5. Summarize the overall health of the code

## Focus Areas
- **Security**: injection, XSS, auth flaws, hardcoded secrets
- **Bugs**: off-by-one, null refs, race conditions, logic errors
- **Performance**: N+1 queries, unnecessary allocations, blocking I/O
- **Style**: naming, structure, dead code, missing types
