"""Deep Coding Agent — A Claude Code-like AI coding assistant built with Deep Agents."""

__version__ = "0.1.0"
