"""First-run API key setup — checks env, checks ~/.config, prompts once if missing."""

from __future__ import annotations

import os
import shutil
from pathlib import Path

from rich.console import Console
from rich.rule import Rule

console = Console()

# Where we persist credentials between sessions (never stored in the project dir)
_CONFIG_DIR = Path.home() / ".config" / "deep-coding-agent"
_CREDENTIALS_FILE = _CONFIG_DIR / "credentials"

# Credential keys written to / read from the file
_CRED_KEY = "OPENROUTER_API_KEY"
_PERSISTED_KEYS = ("OPENROUTER_API_KEY", "MODEL", "SUBAGENT_MODEL")


def _load_saved_credentials() -> dict[str, str]:
    """Read saved credentials from ~/.config/deep-coding-agent/credentials."""
    result: dict[str, str] = {}
    if _CREDENTIALS_FILE.exists():
        for line in _CREDENTIALS_FILE.read_text().splitlines():
            line = line.strip()
            for key in _PERSISTED_KEYS:
                if line.startswith(f"{key}="):
                    result[key] = line.split("=", 1)[1].strip()
    return result


def _load_saved_key() -> str | None:
    """Read a previously saved API key from ~/.config/deep-coding-agent/credentials."""
    return _load_saved_credentials().get(_CRED_KEY)


def _save_key(api_key: str) -> None:
    """Persist the API key (and current model settings) to ~/.config/deep-coding-agent/credentials."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines = [f"{_CRED_KEY}={api_key}"]
    for key in ("MODEL", "SUBAGENT_MODEL"):
        value = os.environ.get(key)
        if value:
            lines.append(f"{key}={value}")
    _CREDENTIALS_FILE.write_text("\n".join(lines) + "\n")
    _CREDENTIALS_FILE.chmod(0o600)  # owner read/write only


def _prompt_for_key() -> str:
    """Interactively ask the user for their OpenRouter API key."""
    console.print()
    console.print(Rule("[bold yellow]Welcome to Deep Coding Agent[/bold yellow]"))
    console.print()
    console.print("  To get started, you need an [bold]OpenRouter API key[/bold].")
    console.print(
        "  Get one at: [link=https://openrouter.ai/settings/keys]"
        "https://openrouter.ai/settings/keys[/link]"
    )
    console.print()

    while True:
        try:
            key = console.input("  [bold]Enter your OpenRouter API key:[/bold] ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print()
            console.print("[dim]Setup cancelled.[/dim]")
            raise SystemExit(0)

        if not key:
            console.print("  [yellow]API key cannot be empty. Try again.[/yellow]")
            continue

        if not key.startswith("sk-or-"):
            console.print(
                "  [yellow]That doesn't look like an OpenRouter key "
                "(should start with 'sk-or-'). Try again.[/yellow]"
            )
            continue

        break

    # Ask whether to save for future sessions
    console.print()
    try:
        save = console.input(
            "  Save key to [dim]~/.config/deep-coding-agent/credentials[/dim]"
            " for future sessions? [bold][Y/n][/bold]: "
        ).strip().lower()
    except (EOFError, KeyboardInterrupt):
        save = "n"

    if save in ("", "y", "yes"):
        _save_key(key)
        console.print("  [green]✓ Key saved.[/green]")
    else:
        console.print("  [dim]Key will be used for this session only.[/dim]")

    console.print()
    return key


def ensure_api_key() -> None:
    """Guarantee OPENROUTER_API_KEY (and model settings) are in the environment.

    Resolution order:
      1. Already set in the shell environment  →  use it, done
      2. Saved in ~/.config/deep-coding-agent/credentials  →  load it, done
      3. Neither found  →  prompt once, optionally save, inject into env
    """
    # 2. Load any previously saved credentials (API key + model settings)
    saved = _load_saved_credentials()
    for key, value in saved.items():
        if not os.environ.get(key):
            os.environ[key] = value

    # 1. API key already set (shell export, CI secret, or just loaded above)
    if os.environ.get(_CRED_KEY):
        return

    # 3. First run — prompt the user
    key = _prompt_for_key()
    os.environ[_CRED_KEY] = key


def logout() -> None:
    """Remove saved credentials from ~/.config/deep-coding-agent/credentials."""
    if not _CREDENTIALS_FILE.exists():
        console.print("[dim]No saved credentials found — nothing to remove.[/dim]")
        return

    _CREDENTIALS_FILE.unlink()
    console.print("[green]✓ Credentials removed.[/green]")
    console.print(f"[dim]Deleted: {_CREDENTIALS_FILE}[/dim]")


def purge_config() -> None:
    """Remove the entire ~/.config/deep-coding-agent directory."""
    if not _CONFIG_DIR.exists():
        console.print("[dim]No config directory found — nothing to remove.[/dim]")
        return

    shutil.rmtree(_CONFIG_DIR)
    console.print(f"[green]✓ Config directory removed: {_CONFIG_DIR}[/green]")
