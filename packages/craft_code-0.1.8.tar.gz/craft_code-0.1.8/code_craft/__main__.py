"""Allow running with: python -m code_craft"""

from .cli import main

main()
