"""Example: programmatic usage of the code craft agent."""

import uuid

from code_craft.agent import build_agent
from code_craft.config import AgentConfig
from code_craft.interrupt_handler import handle_interrupts


def run_task(task: str, project_root: str = "."):
    """Run a single task against a project and print the result."""
    config = AgentConfig(project_root=project_root)
    agent, checkpointer, store = build_agent(config)

    thread_id = str(uuid.uuid4())
    lang_config = {"configurable": {"thread_id": thread_id}}

    result = agent.invoke(
        {"messages": [{"role": "user", "content": task}]},
        lang_config,
        version="v2",
    )

    # Handle approvals
    result = handle_interrupts(result, agent, lang_config)

    # Print final response
    messages = result.get("messages", [])
    if messages:
        print(messages[-1].content)


if __name__ == "__main__":
    run_task("List all Python files in this project and summarize the architecture.")
