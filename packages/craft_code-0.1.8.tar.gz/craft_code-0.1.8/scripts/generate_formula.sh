#!/usr/bin/env bash
# Generate a complete Homebrew formula for craft-code.
# Requires: Python 3, pip, homebrew-pypi-poet
#
# Usage:
#   ./scripts/generate_formula.sh [VERSION]
#
# Example:
#   ./scripts/generate_formula.sh 0.1.4
#
# OUTPUT: homebrew-tap/Formula/craft-code.rb (overwritten)

set -euo pipefail

VERSION="${1:-$(python3 -c "import tomllib; d=tomllib.load(open('pyproject.toml','rb')); print(d['project']['version'])")}"
FORMULA_PATH="homebrew-tap/Formula/craft-code.rb"
REPO="Shubham-1994/code-craft"
TARBALL_URL="https://github.com/${REPO}/archive/refs/tags/v${VERSION}.tar.gz"

echo "==> Generating formula for craft-code v${VERSION}"

# ---- 1. Compute tarball SHA256 ----------------------------------------
LOCAL_TARBALL="dist/craft_code-${VERSION}.tar.gz"

if [[ -f "${LOCAL_TARBALL}" ]]; then
  echo "==> Using local tarball: ${LOCAL_TARBALL}"
  SHA256=$(shasum -a 256 "${LOCAL_TARBALL}" | awk '{print $1}')
else
  echo "==> Fetching tarball from GitHub to compute SHA256..."
  TMPFILE=$(mktemp)
  if ! curl -fsSL "${TARBALL_URL}" -o "${TMPFILE}"; then
    echo ""
    echo "ERROR: Could not fetch ${TARBALL_URL}"
    echo "  Either push the tag first:  git tag v${VERSION} && git push origin v${VERSION}"
    echo "  Or build the package first: python -m build"
    rm "${TMPFILE}"
    exit 1
  fi
  SHA256=$(shasum -a 256 "${TMPFILE}" | awk '{print $1}')
  rm "${TMPFILE}"
fi
echo "    sha256: ${SHA256}"

# ---- 2. Install homebrew-pypi-poet if missing --------------------------
if ! command -v poet &>/dev/null; then
  echo "==> Installing homebrew-pypi-poet..."
  pip install --quiet setuptools homebrew-pypi-poet
fi

# ---- 3. Generate resource blocks with poet -----------------------------
echo "==> Generating resource blocks (this may take a moment)..."
RESOURCES=$(poet craft-code)

if [[ -z "${RESOURCES}" ]]; then
  echo "ERROR: poet returned empty output for craft-code."
  exit 1
fi

# ---- 4. Write the formula ----------------------------------------------
cat > "${FORMULA_PATH}" <<RUBY
class CraftCode < Formula
  include Language::Python::Virtualenv

  desc "An AI coding assistant"
  homepage "https://github.com/${REPO}"
  url "${TARBALL_URL}"
  sha256 "${SHA256}"
  license "MIT"

  depends_on "python@3.12"

  # Resources generated with homebrew-pypi-poet on $(date -u +%Y-%m-%d)
${RESOURCES}

  def install
    virtualenv_install_with_resources
  end

  test do
    assert_match version.to_s, shell_output("#{bin}/craft-code --version 2>&1", 1)
    system bin/"craft-code", "--help"
  end
end
RUBY

echo "==> Written to ${FORMULA_PATH}"
echo ""
echo "Next steps:"
echo "  1. Review ${FORMULA_PATH}"
echo "  2. Push homebrew-tap/ contents to: https://github.com/shubhamagarwal/homebrew-craft-code"
echo "  3. Users can then install with:"
echo "       brew tap shubhamagarwal/craft-code"
echo "       brew install craft-code"
