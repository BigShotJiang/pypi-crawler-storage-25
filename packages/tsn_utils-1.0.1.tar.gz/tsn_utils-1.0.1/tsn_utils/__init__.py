#+------------------------------------------------------------------+
#| Imports                                                          |
#+------------------------------------------------------------------+
# Simple logger a su vez ya importa a Funciones
from .SimpleLogger import CLoggerBase
from . import Funciones
 

#+------------------------------------------------------------------+
#| General                                                          |
#+------------------------------------------------------------------+
__version__ = "1.0.1"             
__author__ = "TradeSystemsNique"    
__license__ = "Nique & Leo NL-NC"                
__copyright__ = "Copyright 2025, TradeSystemsNique"   


__all__ = [
    'CLoggerBase',
    'Funciones'
]