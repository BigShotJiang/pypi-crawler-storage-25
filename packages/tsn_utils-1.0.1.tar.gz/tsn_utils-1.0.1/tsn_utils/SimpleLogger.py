# Copyright 2025, Niquel Mendoza.
# https://www.mql5.com/es/users/nique_372
# SimpleLogger.py

#+------------------------------------------------------------------+
#| Imports                                                          |
#+------------------------------------------------------------------+
import inspect

#+------------------------------------------------------------------+
#| Base Logging Class with Flag System                              |
#+------------------------------------------------------------------+
class CLoggerBase:
    
    #--- Defines nivels value
    LOG_LEVEL_ERROR    = 1    # 0001 - Critical errors
    LOG_LEVEL_WARNING  = 2    # 0010 - Warnings
    LOG_LEVEL_INFO     = 4    # 0100 - General information
    LOG_LEVEL_CAUTION  = 8    # 1000 - Cautions
    LOG_ALL = (LOG_LEVEL_CAUTION|LOG_LEVEL_INFO|LOG_LEVEL_WARNING)
    
    #--- Defines niveles name
    WARNING_TEXT = "WARNING"
    CAUTION_TEXT = "CAUTION"
    INFO_TEXT = "INFO"
    ERROR_TEXT = "ERROR"
    CRITICAL_ERROR_TEXT = "CRITICAL ERROR"
    FATAL_ERROR_TEXT = "FATAL ERROR"
    
    @staticmethod      
    def FastLog(function : str, class_info : str, message : str) -> None: 
        print(f"[{class_info}] {function} | {message}") 
      
            
    #--- Funcion de incilizacion
    def __init__(self):
          self.m_log_flags = CLoggerBase.LOG_LEVEL_ERROR
          self.m_last_flags = CLoggerBase.LOG_LEVEL_ERROR
          self.m_warning_enable = False
          self.m_caution_enable = False
          self.m_info_enable = False
          self.UpdateLogLevels()
          

    #---  
    def RemoveFlag(self, flags : int) -> None: 
        self.m_log_flags &= ~flags; 

    def UpdateLogLevels(self) -> None: 
        self.m_warning_enable = (self.m_log_flags & CLoggerBase.LOG_LEVEL_WARNING) != 0
        self.m_info_enable = (self.m_log_flags & CLoggerBase.LOG_LEVEL_INFO) != 0
        self.m_caution_enable = (self.m_log_flags &CLoggerBase.LOG_LEVEL_CAUTION) != 0

    #---
    def LogWarning(self, message : str) -> None: 
        if(self.m_warning_enable):
            CLoggerBase.FastLog(inspect.currentframe().f_back.f_code.co_name, CLoggerBase.WARNING_TEXT, message)                
    
    def LogInfo(self, message : str) -> None: 
        if(self.m_info_enable):
            CLoggerBase.FastLog(inspect.currentframe().f_back.f_code.co_name, CLoggerBase.INFO_TEXT, message)  
            
    def LogCaution(self, message : str) -> None: 
        if(self.m_caution_enable):
            CLoggerBase.FastLog(inspect.currentframe().f_back.f_code.co_name, CLoggerBase.CAUTION_TEXT, message)  
    
    #---
    @staticmethod
    def LogError(message : str)-> None: 
        CLoggerBase.FastLog(inspect.currentframe().f_back.f_code.co_name, CLoggerBase.ERROR_TEXT, message)  
    
    @staticmethod
    def LogFatalError(message : str)-> None: 
        CLoggerBase.FastLog(inspect.currentframe().f_back.f_code.co_name, CLoggerBase.FATAL_ERROR_TEXT, message)  
    
    @staticmethod
    def LogCriticalError(message : str )-> None: 
        CLoggerBase.FastLog(inspect.currentframe().f_back.f_code.co_name, CLoggerBase.CRITICAL_ERROR_TEXT, message)  
                  

    #--- Methods to check if a flag is active
    def IsWarningLogEnabled(self) -> bool: 
        return self.m_warning_enable
    
    def IsInfoLogEnabled(self) -> bool: 
        return self.m_info_enable
    
    def IsCautionLogEnabled(self) -> bool:  
        return self.m_caution_enable
   
        
    #--- Getters
    def LogFlags(self) -> int:
        return self.m_log_flags
        
    def IsLogEnabled(self, flag : int) -> bool: 
        return (self.m_log_flags & flag) != 0

    #--- Main configuration using flags
    def ResetLastStateFlags(self) -> None:
        self.m_log_flags = self.m_last_flags; 
    
    def AddLogFlags(self, flags : int):
        self.m_last_flags = self.m_log_flags
        self.m_log_flags |= flags
        self.UpdateLogLevels()
        
        
    def RemoveLogFlags(self, flags : int):
        self.m_last_flags = self.m_log_flags
        safe_flags = flags & ~CLoggerBase.LOG_LEVEL_ERROR
        self.RemoveFlag(safe_flags)
        self.m_log_flags |= CLoggerBase.LOG_LEVEL_ERROR
        self.UpdateLogLevels()
    

    #--- Disbale and Enable all logs
    def EnableAllLogs(self) -> None:
        self.m_log_flags |= CLoggerBase.LOG_ALL
        self.UpdateLogLevels()
  
    
    def DisableAllLogs(self) -> None:
        self.m_log_flags = CLoggerBase.LOG_LEVEL_ERROR
        self.UpdateLogLevels()
 
 
# def Main():
#    object = CLoggerBase()
#    object.EnableAllLogs()
#    object.LogWarning()
#    object.LogWarning("Hola con advertencia" , CLoggerBase.FUNCION_ACTUAL()) 
#    object.LogInfo("Hola con info" , CLoggerBase.FUNCION_ACTUAL()) 
   
 

 