# pyAthina

A lightweight PyQt6 + pyqtgraph skeleton for PEEM-style image-stack workflows.

## Install

```bash
pip install -r requirements.txt
```

## Run

Any of these should work from the extracted project folder:

```bash
python -m pyAthina.main
```

```bash
python -m pyAthina
```

```bash
python run_pyAthina.py
```

If you `cd` into the `pyAthina/` subfolder itself, you can also run:

```bash
python main.py
```


## Alignment modes

- **Phase correlation**: translation-only drift correction with sub-pixel shift estimation.
- **Image registration**: ECC-based registration on the ROI, with the estimated transform applied to the full image.
  - default: sub-pixel translation
  - optional: rotation
  - optional: scale
  - optional: skew

When scale or skew is enabled, the registration model becomes affine.


## Z profile improvements

- live ROI-driven z-profile updates while moving or resizing the ROI
- standalone popup plot window
- plot styling controls (grid, markers, line width)
- export z-profile as TXT (x, y columns)
- export plot as PNG


## Line profile

- Click **Line profile using line ROI**.
- Then press and drag on the image to draw the line.
- The popup profile updates when you move the line endpoints or change stack layer with the slider.
- The profile width is controlled by **Profile width (px)** in the Profiles dock.


## Xarray-backed import and axis metadata

The stack import layer creates an `xarray.DataArray` with dims `(z, y, x)`.

No sample data or synthetic coordinate ranges are enabled by default.
When file metadata is missing, pyAthina falls back to:

- `x`: pixel index (`0 .. nx-1`)
- `y`: pixel index (`0 .. ny-1`)
- `z`: layer index (`0 .. nz-1`)

HDF5 metadata parsing helpers are included, but the final mapping of file metadata into domain-specific xarray attrs is intentionally left as a placeholder for user customization.
Commented debug snippets remain in the codebase so synthetic data can be re-enabled temporarily when needed.

## Multi-core alignment and headless cluster use

The alignment backend can now use multiple worker processes.

- In the GUI, set **Worker processes** to `1` for the original serial path, or a larger value to use a process pool.
- For headless cluster jobs, use:

```bash
python -m pyAthina.batch_align input.h5 aligned_stack.tif \
  --dataset-path /root/entry/instrument/tvips/data \
  --workers 8 \
  --reference-index 0 \
  --method image_registration
```

`phase_correlation` is also available with `--method phase_correlation`.

