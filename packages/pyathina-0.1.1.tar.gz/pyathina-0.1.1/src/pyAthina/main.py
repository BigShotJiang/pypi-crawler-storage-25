import sys
from pathlib import Path

# Allow both:
#   python -m pyAthina.main
# and, if the user is inside the pyAthina package directory:
#   python main.py
package_dir = Path(__file__).resolve().parent
project_root = package_dir.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

import pyqtgraph as pg
from PyQt6.QtWidgets import QApplication

from pyAthina.app import MainWindow


def main() -> None:
    pg.setConfigOptions(imageAxisOrder="row-major")
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
