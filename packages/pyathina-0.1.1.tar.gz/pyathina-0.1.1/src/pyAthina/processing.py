from __future__ import annotations

from typing import Callable, Optional, Sequence, Tuple

from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp
from multiprocessing import shared_memory

import cv2
import numpy as np
from scipy.ndimage import map_coordinates, shift as nd_shift
from skimage.registration import phase_cross_correlation


ROI = Tuple[int, int, int, int]

ALIGNMENT_METHOD_PHASE = "phase_correlation"
ALIGNMENT_METHOD_ECC = "image_registration"

WARP_MODEL_TRANSLATION = "translation"
WARP_MODEL_EUCLIDEAN = "euclidean"
WARP_MODEL_AFFINE = "affine"


_SHARED_STACK: np.ndarray | None = None
_SHARED_STACK_SHM: shared_memory.SharedMemory | None = None


def _init_alignment_shared_stack(shm_name: str, shape: Sequence[int], dtype_str: str) -> None:
    """Attach worker processes to the shared stack buffer."""
    global _SHARED_STACK, _SHARED_STACK_SHM
    shm = shared_memory.SharedMemory(name=shm_name)
    _SHARED_STACK_SHM = shm
    _SHARED_STACK = np.ndarray(tuple(shape), dtype=np.dtype(dtype_str), buffer=shm.buf)
    try:
        cv2.setNumThreads(1)
    except Exception:
        pass


def _close_alignment_shared_stack() -> None:
    global _SHARED_STACK, _SHARED_STACK_SHM
    _SHARED_STACK = None
    if _SHARED_STACK_SHM is not None:
        try:
            _SHARED_STACK_SHM.close()
        except Exception:
            pass
    _SHARED_STACK_SHM = None


def _identity_transform_result(image: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, str]:
    return (
        np.asarray(image).copy(),
        np.zeros(2, dtype=np.float64),
        np.eye(3, dtype=np.float32),
        WARP_MODEL_TRANSLATION,
    )


def _align_single_image(
    reference: np.ndarray,
    moving: np.ndarray,
    *,
    roi: Optional[ROI],
    method: str,
    upsample_factor: int,
    allow_rotation: bool,
    allow_scale: bool,
    allow_skew: bool,
    interpolation_order: int,
    mode: str,
    cval: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, str]:
    if method == ALIGNMENT_METHOD_PHASE:
        try:
            shift_yx, _, _ = estimate_shift_phase_correlation(
                reference,
                moving,
                roi=roi,
                upsample_factor=upsample_factor,
            )
            transform = np.eye(3, dtype=np.float32)
            transform[0, 2] = float(shift_yx[1])
            transform[1, 2] = float(shift_yx[0])
            aligned = apply_shift(
                moving,
                shift_yx,
                order=interpolation_order,
                mode=mode,
                cval=cval,
            )
            return aligned, np.asarray(shift_yx, dtype=np.float64), transform, WARP_MODEL_TRANSLATION
        except Exception:
            return (
                np.asarray(moving).copy(),
                np.zeros(2, dtype=np.float64),
                np.eye(3, dtype=np.float32),
                f"{WARP_MODEL_TRANSLATION} [fallback]",
            )

    if method == ALIGNMENT_METHOD_ECC:
        try:
            full_warp, model_name, _ = estimate_ecc_transform(
                reference,
                moving,
                roi=roi,
                allow_rotation=allow_rotation,
                allow_scale=allow_scale,
                allow_skew=allow_skew,
            )
            shift = np.array([float(full_warp[1, 2]), float(full_warp[0, 2])], dtype=np.float64)
            aligned = apply_warp(
                moving,
                full_warp,
                mode=mode,
                cval=cval,
            )
            return aligned, shift, full_warp.astype(np.float32), model_name
        except Exception:
            try:
                shift_yx, _, _ = estimate_shift_phase_correlation(
                    reference,
                    moving,
                    roi=roi,
                    upsample_factor=10,
                )
                transform = np.eye(3, dtype=np.float32)
                transform[0, 2] = float(shift_yx[1])
                transform[1, 2] = float(shift_yx[0])
                aligned = apply_shift(
                    moving,
                    shift_yx,
                    order=1,
                    mode=mode,
                    cval=cval,
                )
                return aligned, np.asarray(shift_yx, dtype=np.float64), transform, f"{WARP_MODEL_TRANSLATION} [fallback]"
            except Exception:
                return (
                    np.asarray(moving).copy(),
                    np.zeros(2, dtype=np.float64),
                    np.eye(3, dtype=np.float32),
                    f"{WARP_MODEL_TRANSLATION} [identity fallback]",
                )

    raise ValueError(f"Unknown alignment method: {method}")


def _align_single_index_from_shared(
    index: int,
    reference_index: int,
    roi: Optional[ROI],
    method: str,
    upsample_factor: int,
    allow_rotation: bool,
    allow_scale: bool,
    allow_skew: bool,
    interpolation_order: int,
    mode: str,
    cval: float,
) -> tuple[int, np.ndarray, np.ndarray, np.ndarray, str]:
    if _SHARED_STACK is None:
        raise RuntimeError("Shared alignment stack is not initialized in worker process")

    if index == reference_index:
        aligned, shift, transform, model_name = _identity_transform_result(_SHARED_STACK[index])
        return index, aligned, shift, transform, model_name

    aligned, shift, transform, model_name = _align_single_image(
        np.asarray(_SHARED_STACK[reference_index]),
        np.asarray(_SHARED_STACK[index]),
        roi=roi,
        method=method,
        upsample_factor=upsample_factor,
        allow_rotation=allow_rotation,
        allow_scale=allow_scale,
        allow_skew=allow_skew,
        interpolation_order=interpolation_order,
        mode=mode,
        cval=cval,
    )
    return index, aligned, shift, transform, model_name


def _validate_alignment_inputs(stack: np.ndarray, reference_index: int) -> int:
    if stack.ndim != 3:
        raise ValueError("stack must have shape (n_images, ny, nx)")

    n_images = int(stack.shape[0])
    if not (0 <= reference_index < n_images):
        raise ValueError("reference_index is out of range")
    return n_images


def _align_stack_parallel(
    stack: np.ndarray,
    reference_index: int = 0,
    roi: Optional[ROI] = None,
    method: str = ALIGNMENT_METHOD_PHASE,
    upsample_factor: int = 10,
    interpolation_order: int = 1,
    mode: str = "nearest",
    cval: float = 0.0,
    allow_rotation: bool = False,
    allow_scale: bool = False,
    allow_skew: bool = False,
    num_workers: int = 1,
    progress_callback: Optional[Callable[[int, int], None]] = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str]]:
    n_images = _validate_alignment_inputs(stack, reference_index)
    roi = normalize_alignment_roi(roi, stack.shape[1:])
    arr = np.ascontiguousarray(stack)

    aligned = np.empty_like(arr)
    shifts = np.zeros((n_images, 2), dtype=np.float64)
    transforms = np.repeat(np.eye(3, dtype=np.float32)[None, :, :], n_images, axis=0)
    transform_models = [WARP_MODEL_TRANSLATION for _ in range(n_images)]

    aligned[reference_index], shifts[reference_index], transforms[reference_index], transform_models[reference_index] = _identity_transform_result(arr[reference_index])
    done = 1
    if progress_callback is not None:
        progress_callback(done, n_images)

    if n_images == 1:
        return aligned, shifts, transforms, transform_models

    shm = shared_memory.SharedMemory(create=True, size=arr.nbytes)
    try:
        shm_view = np.ndarray(arr.shape, dtype=arr.dtype, buffer=shm.buf)
        shm_view[...] = arr
        del shm_view

        ctx = mp.get_context("spawn")
        with ProcessPoolExecutor(
            max_workers=max(1, int(num_workers)),
            mp_context=ctx,
            initializer=_init_alignment_shared_stack,
            initargs=(shm.name, arr.shape, arr.dtype.str),
        ) as executor:
            futures = [
                executor.submit(
                    _align_single_index_from_shared,
                    i,
                    reference_index,
                    roi,
                    method,
                    upsample_factor,
                    allow_rotation,
                    allow_scale,
                    allow_skew,
                    interpolation_order,
                    mode,
                    cval,
                )
                for i in range(n_images)
                if i != reference_index
            ]

            for future in as_completed(futures):
                idx, aligned_i, shift_i, transform_i, model_name = future.result()
                aligned[idx] = np.asarray(aligned_i, dtype=arr.dtype)
                shifts[idx] = np.asarray(shift_i, dtype=np.float64)
                transforms[idx] = np.asarray(transform_i, dtype=np.float32)
                transform_models[idx] = str(model_name)
                done += 1
                if progress_callback is not None:
                    progress_callback(done, n_images)
    finally:
        try:
            shm.close()
        finally:
            shm.unlink()

    return aligned, shifts, transforms, transform_models


def normalize_alignment_roi(roi: Optional[ROI], shape: Sequence[int]) -> Optional[ROI]:
    """Return a valid ROI for alignment, or None to use the full image.

    A missing ROI, or one that collapses to a tiny/empty region after clipping,
    is treated as ``None`` so alignment falls back to the full image.
    """
    if roi is None:
        return None
    x, y, w, h = clip_roi_to_shape(roi, shape)
    if w <= 1 or h <= 1:
        return None
    return x, y, w, h


def _sanitize_alignment_image(image: np.ndarray) -> np.ndarray:
    """Prepare an image for alignment quickly and robustly.

    The fast path returns a float32 view/cast when all pixels are finite. Only if
    non-finite values are present do we allocate a copy and replace them with the
    median of the finite pixels.
    """
    arr = np.asarray(image, dtype=np.float32)
    if arr.size == 0:
        raise ValueError("Empty image provided")
    finite = np.isfinite(arr)
    if finite.all():
        return arr
    if not finite.any():
        raise ValueError("Alignment region contains no finite pixels")
    out = arr.copy()
    fill_value = float(np.median(out[finite]))
    out[~finite] = fill_value
    return out


def clip_roi_to_shape(roi: ROI, shape: Sequence[int]) -> ROI:
    """Clip an ROI (x, y, w, h) to image bounds."""
    x, y, w, h = roi
    ny, nx = int(shape[0]), int(shape[1])

    x0 = max(0, min(int(x), nx))
    y0 = max(0, min(int(y), ny))
    x1 = max(x0, min(int(x + w), nx))
    y1 = max(y0, min(int(y + h), ny))

    return x0, y0, x1 - x0, y1 - y0


def crop_to_roi(image: np.ndarray, roi: Optional[ROI]) -> np.ndarray:
    if roi is None:
        return image
    x, y, w, h = clip_roi_to_shape(roi, image.shape)
    if w <= 0 or h <= 0:
        raise ValueError("ROI is empty after clipping to the image bounds")
    return image[y:y + h, x:x + w]


def bin_image(image: np.ndarray, bin_y: int, bin_x: Optional[int] = None) -> np.ndarray:
    if bin_x is None:
        bin_x = bin_y
    if bin_y <= 0 or bin_x <= 0:
        raise ValueError("Binning factors must be positive integers")

    ny, nx = image.shape
    ny2 = (ny // bin_y) * bin_y
    nx2 = (nx // bin_x) * bin_x
    cropped = image[:ny2, :nx2]
    return cropped.reshape(ny2 // bin_y, bin_y, nx2 // bin_x, bin_x).mean(axis=(1, 3))


def bin_stack(stack: np.ndarray, bin_y: int, bin_x: Optional[int] = None) -> np.ndarray:
    return np.stack([bin_image(img, bin_y, bin_x) for img in stack], axis=0)


def estimate_shift_phase_correlation(
    reference: np.ndarray,
    moving: np.ndarray,
    roi: Optional[ROI] = None,
    upsample_factor: int = 10,
) -> Tuple[Tuple[float, float], float, float]:
    roi = normalize_alignment_roi(roi, reference.shape)
    ref = _sanitize_alignment_image(crop_to_roi(reference, roi))
    mov = _sanitize_alignment_image(crop_to_roi(moving, roi))

    shift_yx, error, phasediff = phase_cross_correlation(
        ref,
        mov,
        upsample_factor=max(1, int(upsample_factor)),
    )

    dy, dx = float(shift_yx[0]), float(shift_yx[1])
    return (dy, dx), float(error), float(phasediff)


def apply_shift(
    image: np.ndarray,
    shift_yx: Tuple[float, float],
    order: int = 1,
    mode: str = "nearest",
    cval: float = 0.0,
) -> np.ndarray:
    shifted = nd_shift(
        image,
        shift=shift_yx,
        order=order,
        mode=mode,
        cval=cval,
        prefilter=(order > 1),
    )
    return np.asarray(shifted, dtype=image.dtype)


def _normalize_to_float32(image: np.ndarray) -> np.ndarray:
    arr = _sanitize_alignment_image(image)
    min_val = float(arr.min())
    max_val = float(arr.max())
    if max_val <= min_val:
        return np.zeros_like(arr, dtype=np.float32)
    return (arr - min_val) / (max_val - min_val)


def _ecc_motion_model(rotation: bool, scale: bool, skew: bool) -> tuple[int, str]:
    if skew or scale:
        return cv2.MOTION_AFFINE, WARP_MODEL_AFFINE
    if rotation:
        return cv2.MOTION_EUCLIDEAN, WARP_MODEL_EUCLIDEAN
    return cv2.MOTION_TRANSLATION, WARP_MODEL_TRANSLATION


def estimate_ecc_transform(
    reference: np.ndarray,
    moving: np.ndarray,
    roi: Optional[ROI] = None,
    allow_rotation: bool = False,
    allow_scale: bool = False,
    allow_skew: bool = False,
    max_iterations: int = 500,
    termination_eps: float = 1e-6,
    gaussian_filter_size: int = 5,
) -> tuple[np.ndarray, str, float]:
    roi = normalize_alignment_roi(roi, reference.shape)
    ref_roi = crop_to_roi(reference, roi)
    mov_roi = crop_to_roi(moving, roi)

    ref_norm = _normalize_to_float32(ref_roi)
    mov_norm = _normalize_to_float32(mov_roi)

    motion_type, warp_model_name = _ecc_motion_model(
        allow_rotation,
        allow_scale,
        allow_skew,
    )

    if motion_type == cv2.MOTION_HOMOGRAPHY:
        warp_roi = np.eye(3, dtype=np.float32)
    else:
        warp_roi = np.eye(2, 3, dtype=np.float32)

    criteria = (
        cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT,
        int(max_iterations),
        float(termination_eps),
    )

    cc, warp_roi = cv2.findTransformECC(
        templateImage=ref_norm,
        inputImage=mov_norm,
        warpMatrix=warp_roi,
        motionType=motion_type,
        criteria=criteria,
        inputMask=None,
        gaussFiltSize=int(gaussian_filter_size),
    )

    full_warp = np.eye(3, dtype=np.float32)
    if warp_roi.shape == (2, 3):
        full_warp[:2, :] = warp_roi
    else:
        full_warp = warp_roi.astype(np.float32, copy=True)

    if roi is not None:
        x, y, _, _ = clip_roi_to_shape(roi, reference.shape)
        to_roi = np.array([[1.0, 0.0, -x], [0.0, 1.0, -y], [0.0, 0.0, 1.0]], dtype=np.float32)
        from_roi = np.array([[1.0, 0.0, x], [0.0, 1.0, y], [0.0, 0.0, 1.0]], dtype=np.float32)
        full_warp = from_roi @ full_warp @ to_roi

    return full_warp.astype(np.float32), warp_model_name, float(cc)


def apply_warp(
    image: np.ndarray,
    warp_matrix: np.ndarray,
    mode: str = "nearest",
    cval: float = 0.0,
) -> np.ndarray:
    image_np = np.asarray(image)
    h, w = image_np.shape[:2]

    border_map = {
        "nearest": cv2.BORDER_REPLICATE,
        "constant": cv2.BORDER_CONSTANT,
        "reflect": cv2.BORDER_REFLECT,
        "mirror": cv2.BORDER_REFLECT_101,
        "wrap": cv2.BORDER_WRAP,
    }
    border_mode = border_map.get(mode, cv2.BORDER_REPLICATE)

    matrix = np.asarray(warp_matrix, dtype=np.float32)
    if matrix.shape == (3, 3):
        if np.allclose(matrix[2], np.array([0.0, 0.0, 1.0], dtype=np.float32)):
            warped = cv2.warpAffine(
                image_np,
                matrix[:2, :],
                (w, h),
                flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                borderMode=border_mode,
                borderValue=float(cval),
            )
        else:
            warped = cv2.warpPerspective(
                image_np,
                matrix,
                (w, h),
                flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                borderMode=border_mode,
                borderValue=float(cval),
            )
    elif matrix.shape == (2, 3):
        warped = cv2.warpAffine(
            image_np,
            matrix,
            (w, h),
            flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
            borderMode=border_mode,
            borderValue=float(cval),
        )
    else:
        raise ValueError("warp_matrix must have shape (2, 3) or (3, 3)")

    return np.asarray(warped, dtype=image_np.dtype)


def align_stack_phase_correlation(
    stack: np.ndarray,
    reference_index: int = 0,
    roi: Optional[ROI] = None,
    upsample_factor: int = 10,
    interpolation_order: int = 1,
    mode: str = "nearest",
    cval: float = 0.0,
    progress_callback: Optional[Callable[[int, int], None]] = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str]]:
    n_images = _validate_alignment_inputs(stack, reference_index)

    roi = normalize_alignment_roi(roi, stack.shape[1:])
    reference = stack[reference_index]
    aligned = np.empty_like(stack)
    shifts = np.zeros((n_images, 2), dtype=np.float64)
    transforms = np.repeat(np.eye(3, dtype=np.float32)[None, :, :], n_images, axis=0)
    transform_models = [WARP_MODEL_TRANSLATION for _ in range(n_images)]

    for i in range(n_images):
        if i == reference_index:
            aligned[i], shifts[i], transforms[i], transform_models[i] = _identity_transform_result(stack[i])
        else:
            aligned[i], shifts[i], transforms[i], transform_models[i] = _align_single_image(
                reference,
                stack[i],
                roi=roi,
                method=ALIGNMENT_METHOD_PHASE,
                upsample_factor=upsample_factor,
                allow_rotation=False,
                allow_scale=False,
                allow_skew=False,
                interpolation_order=interpolation_order,
                mode=mode,
                cval=cval,
            )

        if progress_callback is not None:
            progress_callback(i + 1, n_images)

    return aligned, shifts, transforms, transform_models


def align_stack_image_registration(
    stack: np.ndarray,
    reference_index: int = 0,
    roi: Optional[ROI] = None,
    allow_rotation: bool = False,
    allow_scale: bool = False,
    allow_skew: bool = False,
    mode: str = "nearest",
    cval: float = 0.0,
    progress_callback: Optional[Callable[[int, int], None]] = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str]]:
    n_images = _validate_alignment_inputs(stack, reference_index)

    roi = normalize_alignment_roi(roi, stack.shape[1:])
    reference = stack[reference_index]
    aligned = np.empty_like(stack)
    shifts = np.zeros((n_images, 2), dtype=np.float64)
    transforms = np.repeat(np.eye(3, dtype=np.float32)[None, :, :], n_images, axis=0)
    transform_models = [WARP_MODEL_TRANSLATION for _ in range(n_images)]

    for i in range(n_images):
        if i == reference_index:
            aligned[i], shifts[i], transforms[i], transform_models[i] = _identity_transform_result(stack[i])
        else:
            aligned[i], shifts[i], transforms[i], transform_models[i] = _align_single_image(
                reference,
                stack[i],
                roi=roi,
                method=ALIGNMENT_METHOD_ECC,
                upsample_factor=10,
                allow_rotation=allow_rotation,
                allow_scale=allow_scale,
                allow_skew=allow_skew,
                interpolation_order=1,
                mode=mode,
                cval=cval,
            )

        if progress_callback is not None:
            progress_callback(i + 1, n_images)

    return aligned, shifts, transforms, transform_models


def align_stack_to_reference(
    stack: np.ndarray,
    reference_index: int = 0,
    roi: Optional[ROI] = None,
    method: str = ALIGNMENT_METHOD_PHASE,
    upsample_factor: int = 10,
    interpolation_order: int = 1,
    mode: str = "nearest",
    cval: float = 0.0,
    allow_rotation: bool = False,
    allow_scale: bool = False,
    allow_skew: bool = False,
    num_workers: int = 1,
    progress_callback: Optional[Callable[[int, int], None]] = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str]]:
    """Align a stack to a reference frame using either phase correlation or ECC registration.

    The ROI is used only to estimate the transform. The resulting shift/affine parameters are
    then applied to the full image.
    """
    if int(num_workers) > 1:
        return _align_stack_parallel(
            stack,
            reference_index=reference_index,
            roi=roi,
            method=method,
            upsample_factor=upsample_factor,
            interpolation_order=interpolation_order,
            mode=mode,
            cval=cval,
            allow_rotation=allow_rotation,
            allow_scale=allow_scale,
            allow_skew=allow_skew,
            num_workers=int(num_workers),
            progress_callback=progress_callback,
        )

    if method == ALIGNMENT_METHOD_PHASE:
        return align_stack_phase_correlation(
            stack,
            reference_index=reference_index,
            roi=roi,
            upsample_factor=upsample_factor,
            interpolation_order=interpolation_order,
            mode=mode,
            cval=cval,
            progress_callback=progress_callback,
        )
    if method == ALIGNMENT_METHOD_ECC:
        return align_stack_image_registration(
            stack,
            reference_index=reference_index,
            roi=roi,
            allow_rotation=allow_rotation,
            allow_scale=allow_scale,
            allow_skew=allow_skew,
            mode=mode,
            cval=cval,
            progress_callback=progress_callback,
        )
    raise ValueError(f"Unknown alignment method: {method}")


def average_stack(stack: np.ndarray) -> np.ndarray:
    if stack.ndim != 3:
        raise ValueError("stack must have shape (n_images, ny, nx)")
    return np.mean(stack, axis=0)


def roi_integrated_signal(stack: np.ndarray, roi: ROI) -> np.ndarray:
    """Return the summed ROI intensity for each layer in a stack.

    This is a sum over the in-plane ROI pixels (y, x) for every z layer, not a
    mean. Pixels outside the image contribute zero. If the ROI lies fully
    outside the image bounds, this returns an all-zero z-profile instead of
    sampling the nearest edge pixel.
    """
    if stack.ndim != 3:
        raise ValueError("stack must have shape (n_images, ny, nx)")

    x, y, w, h = clip_roi_to_shape(roi, stack.shape[1:])
    if w <= 0 or h <= 0:
        return np.zeros(stack.shape[0], dtype=np.float64)

    roi_view = stack[:, y:y + h, x:x + w]
    return np.sum(roi_view, axis=(1, 2), dtype=np.float64)


def roi_mean_signal(stack: np.ndarray, roi: ROI) -> np.ndarray:
    """Return the ImageJ-style ROI mean gray value for each layer in a stack.

    ImageJ's Image > Stacks > Plot Z-axis Profile reports the ROI selection mean
    gray value versus slice number. This helper reproduces that statistic on a
    stack with shape (n_images, ny, nx). Pixels outside the image are ignored by
    clipping the ROI to the valid image area. If the ROI lies fully outside the
    image bounds, this returns an all-zero z-profile.
    """
    if stack.ndim != 3:
        raise ValueError("stack must have shape (n_images, ny, nx)")

    x, y, w, h = clip_roi_to_shape(roi, stack.shape[1:])
    if w <= 0 or h <= 0:
        return np.zeros(stack.shape[0], dtype=np.float64)

    roi_view = np.asarray(stack[:, y:y + h, x:x + w], dtype=np.float64)
    return np.mean(roi_view, axis=(1, 2), dtype=np.float64)


def average_stack_in_roi(stack: np.ndarray, roi: ROI) -> np.ndarray:
    cropped = crop_to_roi(stack[0], roi)
    x, y, w, h = clip_roi_to_shape(roi, stack.shape[1:])
    if cropped.size == 0:
        raise ValueError("ROI is empty")
    return np.mean(stack[:, y:y + h, x:x + w], axis=0)



def line_profile_from_image(
    image: np.ndarray,
    start_xy: tuple[float, float],
    end_xy: tuple[float, float],
    width_px: int = 1,
    interpolation_order: int = 1,
) -> tuple[np.ndarray, np.ndarray]:
    """Sample a line profile from an image, optionally averaged across a perpendicular width."""
    arr = np.asarray(image, dtype=np.float64)
    if arr.ndim != 2:
        raise ValueError("image must be 2D")

    x0, y0 = float(start_xy[0]), float(start_xy[1])
    x1, y1 = float(end_xy[0]), float(end_xy[1])
    width_px = max(1, int(width_px))

    dx = x1 - x0
    dy = y1 - y0
    length = float(np.hypot(dx, dy))
    n_samples = max(2, int(np.ceil(length)) + 1)

    xs = np.linspace(x0, x1, n_samples, dtype=np.float64)
    ys = np.linspace(y0, y1, n_samples, dtype=np.float64)

    if length <= 1e-12:
        distances = np.zeros(n_samples, dtype=np.float64)
        xi = int(round(x0))
        yi = int(round(y0))
        if 0 <= yi < arr.shape[0] and 0 <= xi < arr.shape[1]:
            value = float(arr[yi, xi])
        else:
            value = 0.0
        profile = np.full(n_samples, value, dtype=np.float64)
        return distances, profile

    perp_x = -dy / length
    perp_y = dx / length
    offsets = np.linspace(-(width_px - 1) / 2.0, (width_px - 1) / 2.0, width_px, dtype=np.float64)

    samples = np.empty((width_px, n_samples), dtype=np.float64)
    for i, off in enumerate(offsets):
        x_coords = xs + perp_x * off
        y_coords = ys + perp_y * off
        samples[i] = map_coordinates(arr, [y_coords, x_coords], order=int(interpolation_order), mode="constant", cval=0.0)

    profile = np.mean(samples, axis=0)
    distances = np.linspace(0.0, length, n_samples, dtype=np.float64)
    return distances, profile


def line_slice_from_stack(
    stack: np.ndarray,
    start_xy: tuple[float, float],
    end_xy: tuple[float, float],
    width_px: int = 1,
    interpolation_order: int = 1,
) -> tuple[np.ndarray, np.ndarray]:
    """Return a z-slice image sampled along a line for every layer in the stack.

    Returns
    -------
    distance_px : ndarray, shape (n_samples,)
        Distance along the line in pixels.
    slice_image : ndarray, shape (n_layers, n_samples)
        Sampled line profile for each layer.
    """
    arr = np.asarray(stack)
    if arr.ndim != 3:
        raise ValueError("stack must have shape (n_images, ny, nx)")

    distance_px, first_profile = line_profile_from_image(
        arr[0],
        start_xy,
        end_xy,
        width_px=width_px,
        interpolation_order=interpolation_order,
    )

    slice_image = np.empty((arr.shape[0], first_profile.size), dtype=np.float64)
    slice_image[0] = first_profile
    for i in range(1, arr.shape[0]):
        _, profile = line_profile_from_image(
            arr[i],
            start_xy,
            end_xy,
            width_px=width_px,
            interpolation_order=interpolation_order,
        )
        slice_image[i] = profile

    return distance_px, slice_image
