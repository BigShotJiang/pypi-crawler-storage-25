from __future__ import annotations

import argparse
from pathlib import Path
import sys

import numpy as np

from pyAthina.io import load_stack_auto, save_stack_tiff
from pyAthina.processing import ALIGNMENT_METHOD_ECC, ALIGNMENT_METHOD_PHASE, align_stack_to_reference


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Headless batch alignment for pyAthina stacks.",
    )
    parser.add_argument("input_path", help="Input stack file (.h5/.hdf5/.tif/.tiff/.npy)")
    parser.add_argument("output_path", help="Output aligned stack (.tif/.tiff or .npy)")
    parser.add_argument("--dataset-path", default=None, help="Optional HDF5 dataset path override")
    parser.add_argument("--reference-index", type=int, default=0, help="Reference frame index")
    parser.add_argument(
        "--method",
        choices=(ALIGNMENT_METHOD_PHASE, ALIGNMENT_METHOD_ECC),
        default=ALIGNMENT_METHOD_ECC,
        help="Alignment method",
    )
    parser.add_argument("--upsample-factor", type=int, default=10, help="Sub-pixel upsample factor for phase correlation")
    parser.add_argument("--workers", type=int, default=1, help="Worker processes to use. 1 keeps serial execution.")
    parser.add_argument(
        "--roi",
        nargs=4,
        type=int,
        metavar=("X", "Y", "W", "H"),
        help="Optional alignment ROI in pixel coordinates",
    )
    parser.add_argument("--allow-rotation", action="store_true", help="Allow rotation in ECC mode")
    parser.add_argument("--allow-scale", action="store_true", help="Allow scale in ECC mode")
    parser.add_argument("--allow-skew", action="store_true", help="Allow skew in ECC mode")
    parser.add_argument("--mode", default="nearest", help="Border mode for the resampling step")
    parser.add_argument("--cval", type=float, default=0.0, help="Constant fill value when mode=constant")
    parser.add_argument("--dtype", default="float32", help="Load dtype for the stack, e.g. float32 or uint16")
    parser.add_argument("--save-shifts", default=None, help="Optional .npy path for saving per-frame shifts")
    parser.add_argument("--save-transforms", default=None, help="Optional .npy path for saving per-frame 3x3 transforms")
    return parser


def _save_output_stack(path: Path, stack: np.ndarray) -> None:
    suffix = path.suffix.lower()
    if suffix in {".tif", ".tiff"}:
        save_stack_tiff(path, stack)
        return
    if suffix == ".npy":
        np.save(path, np.asarray(stack))
        return
    raise ValueError("Output path must end with .tif, .tiff, or .npy")


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    dtype = np.dtype(args.dtype)
    stack = load_stack_auto(args.input_path, dataset_path=args.dataset_path, dtype=dtype)

    total = int(stack.n_images)

    def _progress(done: int, n_total: int) -> None:
        print(f"[{done}/{n_total}] aligned", file=sys.stderr, flush=True)

    aligned, shifts, transforms, transform_models = align_stack_to_reference(
        stack.data,
        reference_index=int(args.reference_index),
        roi=tuple(args.roi) if args.roi is not None else None,
        method=args.method,
        upsample_factor=int(args.upsample_factor),
        allow_rotation=bool(args.allow_rotation),
        allow_scale=bool(args.allow_scale),
        allow_skew=bool(args.allow_skew),
        mode=str(args.mode),
        cval=float(args.cval),
        num_workers=max(1, int(args.workers)),
        progress_callback=_progress,
    )

    output_path = Path(args.output_path)
    _save_output_stack(output_path, aligned)

    if args.save_shifts:
        np.save(args.save_shifts, np.asarray(shifts, dtype=np.float64))
    if args.save_transforms:
        np.save(args.save_transforms, np.asarray(transforms, dtype=np.float32))

    print(
        f"Saved aligned stack to {output_path} using {max(1, int(args.workers))} worker(s) for {total} frames.",
        file=sys.stderr,
        flush=True,
    )
    if transform_models:
        unique_models = sorted(set(str(m) for m in transform_models))
        print(f"Transform models encountered: {', '.join(unique_models)}", file=sys.stderr, flush=True)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
