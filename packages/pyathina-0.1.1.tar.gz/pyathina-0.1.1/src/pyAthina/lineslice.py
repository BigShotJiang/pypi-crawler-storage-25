from __future__ import annotations

from pathlib import Path

import numpy as np
import pyqtgraph as pg
import pyqtgraph.exporters
from PyQt6.QtCore import Qt, QRectF, pyqtSignal
from PyQt6.QtWidgets import (
    QCheckBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QVBoxLayout,
    QWidget,
)


def _coord_edges(values: np.ndarray) -> np.ndarray:
    vals = np.asarray(values, dtype=np.float64)
    if vals.size == 1:
        return np.array([vals[0] - 0.5, vals[0] + 0.5], dtype=np.float64)
    mids = 0.5 * (vals[:-1] + vals[1:])
    first = vals[0] - (mids[0] - vals[0])
    last = vals[-1] + (vals[-1] - mids[-1])
    return np.concatenate([[first], mids, [last]]).astype(np.float64)


class LineSliceWindow(QMainWindow):
    hidden = pyqtSignal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Z-slice from line ROI")
        self.resize(980, 620)

        self._distance = np.array([], dtype=np.float64)
        self._z_values = np.array([], dtype=np.float64)
        self._slice_image = np.empty((0, 0), dtype=np.float64)
        self._stack_name = ""
        self._profile_width = 1
        self._line_points = None
        self._x_label = "distance"
        self._y_label = "z"

        central = QWidget(self)
        outer = QVBoxLayout(central)
        outer.setContentsMargins(8, 8, 8, 8)

        controls = QHBoxLayout()
        self.btn_autorange = QPushButton("Fit view")
        self.btn_export_txt = QPushButton("Export TXT")
        self.btn_export_png = QPushButton("Export PNG")
        self.chk_autolevels = QCheckBox("Auto levels on update")
        self.chk_autolevels.setChecked(True)
        controls.addWidget(self.btn_autorange)
        controls.addWidget(self.btn_export_txt)
        controls.addWidget(self.btn_export_png)
        controls.addSpacing(12)
        controls.addWidget(self.chk_autolevels)
        controls.addStretch()

        self.info_label = QLabel("No z-slice computed")
        self.info_label.setWordWrap(True)

        self.graphics = pg.GraphicsLayoutWidget()
        self.plot = self.graphics.addPlot()
        self.plot.setLabel("left", self._y_label)
        self.plot.setLabel("bottom", self._x_label)
        self.plot.setMenuEnabled(True)
        self.plot.showGrid(x=True, y=True, alpha=0.25)
        self.image_item = pg.ImageItem()
        self.plot.addItem(self.image_item)
        self.current_index_line = pg.InfiniteLine(angle=0, movable=False, pen=pg.mkPen(style=Qt.PenStyle.DashLine, width=1))
        self.plot.addItem(self.current_index_line)
        self.current_index_line.hide()

        self.graphics.nextColumn()
        self.hist = pg.HistogramLUTItem()
        self.hist.setImageItem(self.image_item)
        self.graphics.addItem(self.hist)

        outer.addLayout(controls)
        outer.addWidget(self.info_label)
        outer.addWidget(self.graphics, stretch=1)
        self.setCentralWidget(central)

        self.btn_autorange.clicked.connect(self.autorange)
        self.btn_export_txt.clicked.connect(self.export_txt)
        self.btn_export_png.clicked.connect(self.export_png)

    def hideEvent(self, event) -> None:
        super().hideEvent(event)
        self.hidden.emit()

    def clear_profile(self) -> None:
        self._distance = np.array([], dtype=np.float64)
        self._z_values = np.array([], dtype=np.float64)
        self._slice_image = np.empty((0, 0), dtype=np.float64)
        self._stack_name = ""
        self._profile_width = 1
        self._line_points = None
        self._x_label = "distance"
        self._y_label = "z"
        self.image_item.setImage(np.empty((0, 0)), autoLevels=False)
        self.current_index_line.hide()
        self.info_label.setText("No z-slice computed")
        self.plot.setTitle("")
        self.plot.setLabel("left", self._y_label)
        self.plot.setLabel("bottom", self._x_label)

    def set_slice(self, distance_axis, z_axis, slice_image, stack_name, line_points, profile_width, x_label="distance", y_label="z", width_text=None) -> None:
        self._distance = np.asarray(distance_axis, dtype=np.float64)
        self._z_values = np.asarray(z_axis, dtype=np.float64)
        self._slice_image = np.asarray(slice_image, dtype=np.float64)
        self._stack_name = str(stack_name)
        self._profile_width = int(profile_width)
        self._line_points = line_points
        self._x_label = str(x_label)
        self._y_label = str(y_label)
        self.plot.setLabel("bottom", self._x_label)
        self.plot.setLabel("left", self._y_label)

        auto_levels = self.chk_autolevels.isChecked() or self.image_item.image is None
        self.image_item.setImage(self._slice_image, autoLevels=auto_levels)

        if self._slice_image.size > 0 and self._distance.size > 0 and self._z_values.size > 0:
            x_edges = _coord_edges(self._distance)
            y_edges = _coord_edges(self._z_values)
            rect = QRectF(float(x_edges[0]), float(y_edges[0]), float(x_edges[-1] - x_edges[0]), float(y_edges[-1] - y_edges[0]))
            self.image_item.setRect(rect)
            self.current_index_line.show()
        else:
            self.current_index_line.hide()

        (x1, y1), (x2, y2) = line_points
        width_info = str(width_text) if width_text else f"{self._profile_width} px"
        self.info_label.setText(
            f"Stack: {self._stack_name} | Line: ({x1:.3f}, {y1:.3f}) → ({x2:.3f}, {y2:.3f}) | "
            f"Profile width: {width_info} | Slice shape: {self._slice_image.shape}"
        )
        self.plot.setTitle("Z-direction slice from line ROI")
        self.autorange()

    def set_current_value(self, value: float) -> None:
        if self._slice_image.size == 0:
            self.current_index_line.hide()
            return
        self.current_index_line.setPos(float(value))
        self.current_index_line.show()

    def autorange(self) -> None:
        self.plot.enableAutoRange(x=True, y=True)
        self.plot.autoRange()
        self.plot.enableAutoRange(x=False, y=False)

    def export_txt(self) -> None:
        if self._slice_image.size == 0:
            return
        default_name = "z_slice_line_roi.txt"
        if self._stack_name:
            safe = self._stack_name.replace(":", "_").replace("/", "_")
            default_name = f"{safe}_z_slice_line_roi.txt"
        path, _ = QFileDialog.getSaveFileName(self, "Export z-slice as TXT", str(Path.home() / default_name), "Text files (*.txt);;All files (*)")
        if not path:
            return
        yy = np.broadcast_to(self._z_values[:, None], self._slice_image.shape)
        xx = np.broadcast_to(self._distance[None, :], self._slice_image.shape)
        data = np.column_stack([yy.ravel(), xx.ravel(), self._slice_image.ravel()])
        header = f"{self._y_label}	{self._x_label}	signal"
        np.savetxt(path, data, fmt=["%.12g", "%.12g", "%.12g"], delimiter="	", header=header, comments="")

    def export_png(self) -> None:
        if self._slice_image.size == 0:
            return
        default_name = "z_slice_line_roi.png"
        if self._stack_name:
            safe = self._stack_name.replace(":", "_").replace("/", "_")
            default_name = f"{safe}_z_slice_line_roi.png"
        path, _ = QFileDialog.getSaveFileName(self, "Export z-slice as PNG", str(Path.home() / default_name), "PNG files (*.png)")
        if not path:
            return
        exporter = pg.exporters.ImageExporter(self.plot)
        exporter.export(path)
