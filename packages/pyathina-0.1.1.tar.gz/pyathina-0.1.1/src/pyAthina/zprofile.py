from __future__ import annotations

from pathlib import Path

import numpy as np
import pyqtgraph as pg
import pyqtgraph.exporters
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QCheckBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)


class ZProfileWindow(QMainWindow):
    hidden = pyqtSignal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Z profile (summed ROI intensity)")
        self.resize(900, 560)

        self._x = np.array([], dtype=np.float64)
        self._y = np.array([], dtype=np.float64)
        self._stack_name = ""
        self._roi = None
        self._x_label = "z"
        self._y_label = "Value"
        self._title = ""
        self._export_column_name = "value"

        central = QWidget(self)
        outer = QVBoxLayout(central)
        outer.setContentsMargins(8, 8, 8, 8)

        controls = QHBoxLayout()
        self.btn_autoscale = QPushButton("Autoscale now")
        self.btn_export_txt = QPushButton("Export TXT")
        self.btn_export_png = QPushButton("Export PNG")
        self.chk_autoscale = QCheckBox("Autoscale on update")
        self.chk_autoscale.setChecked(True)
        self.chk_grid = QCheckBox("Grid")
        self.chk_grid.setChecked(True)
        self.chk_symbols = QCheckBox("Markers")
        self.chk_symbols.setChecked(False)
        self.spin_linewidth = QSpinBox()
        self.spin_linewidth.setRange(1, 10)
        self.spin_linewidth.setValue(2)
        controls.addWidget(self.btn_autoscale)
        controls.addWidget(self.btn_export_txt)
        controls.addWidget(self.btn_export_png)
        controls.addSpacing(12)
        controls.addWidget(self.chk_autoscale)
        controls.addWidget(self.chk_grid)
        controls.addWidget(self.chk_symbols)
        controls.addWidget(QLabel("Line width"))
        controls.addWidget(self.spin_linewidth)
        controls.addStretch()

        self.info_label = QLabel("No z profile computed")
        self.info_label.setWordWrap(True)

        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setLabel("left", self._y_label)
        self.plot_widget.setLabel("bottom", self._x_label)
        self.plot_widget.showGrid(x=True, y=True, alpha=0.25)
        self.plot_widget.setMenuEnabled(True)
        self.curve = self.plot_widget.plot([], [], pen=pg.mkPen(width=2), symbol="o", symbolSize=6)
        self.current_index_line = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen(style=Qt.PenStyle.DashLine, width=1))
        self.plot_widget.addItem(self.current_index_line)
        self.current_index_line.hide()

        outer.addLayout(controls)
        outer.addWidget(self.info_label)
        outer.addWidget(self.plot_widget, stretch=1)
        self.setCentralWidget(central)

        self.btn_autoscale.clicked.connect(self.autoscale)
        self.btn_export_txt.clicked.connect(self.export_txt)
        self.btn_export_png.clicked.connect(self.export_png)
        self.chk_grid.toggled.connect(self._apply_plot_style)
        self.chk_symbols.toggled.connect(self._apply_plot_style)
        self.spin_linewidth.valueChanged.connect(self._apply_plot_style)
        self._apply_plot_style()

    def hideEvent(self, event) -> None:
        super().hideEvent(event)
        self.hidden.emit()

    def clear_profile(self) -> None:
        self._x = np.array([], dtype=np.float64)
        self._y = np.array([], dtype=np.float64)
        self._stack_name = ""
        self._roi = None
        self._x_label = "z"
        self._y_label = "Value"
        self._title = ""
        self._export_column_name = "value"
        self.curve.setData([], [])
        self.plot_widget.enableAutoRange(x=False, y=False)
        self.current_index_line.hide()
        self.info_label.setText("No z profile computed")
        self.plot_widget.setTitle("")
        self.plot_widget.setLabel("bottom", self._x_label)
        self.plot_widget.setLabel("left", self._y_label)

    def set_profile(self, profile, z_values, roi, stack_name, x_label="z", y_label="Value", title="", statistic_text="value", export_column_name="value") -> None:
        old_size = int(self._x.size)
        self._x = np.asarray(z_values, dtype=np.float64)
        self._y = np.asarray(profile, dtype=np.float64)
        self._stack_name = str(stack_name)
        self._roi = tuple(float(v) for v in roi)
        self._x_label = str(x_label)
        self._y_label = str(y_label)
        self._title = str(title)
        self._export_column_name = str(export_column_name)
        self.plot_widget.setLabel("bottom", self._x_label)
        self.plot_widget.setLabel("left", self._y_label)
        self._refresh_curve()
        rx, ry, rw, rh = self._roi
        self.info_label.setText(f"Stack: {self._stack_name} | ROI: x={rx:.3f}, y={ry:.3f}, w={rw:.3f}, h={rh:.3f} | Statistic: {statistic_text} | Points: {self._y.size}")
        self.plot_widget.setTitle(self._title)
        if self.chk_autoscale.isChecked() or old_size == 0 or old_size != self._x.size:
            self.autoscale()

    def set_current_value(self, value: float) -> None:
        self.current_index_line.setPos(float(value))
        self.current_index_line.show()

    def autoscale(self) -> None:
        self.plot_widget.enableAutoRange(x=True, y=True)
        self.plot_widget.autoRange()
        self.plot_widget.enableAutoRange(x=False, y=False)

    def export_txt(self) -> None:
        if self._x.size == 0 or self._y.size == 0:
            return
        default_name = "z_profile.txt"
        if self._stack_name:
            safe = self._stack_name.replace(":", "_").replace("/", "_")
            default_name = f"{safe}_z_profile.txt"
        path, _ = QFileDialog.getSaveFileName(self, "Export z profile as TXT", str(Path.home() / default_name), "Text files (*.txt);;All files (*)")
        if not path:
            return
        header = f"{self._x_label}\t{self._export_column_name}"
        data = np.column_stack([self._x, self._y])
        np.savetxt(path, data, fmt=["%.12g", "%.12g"], delimiter="	", header=header, comments="")

    def export_png(self) -> None:
        if self._x.size == 0 or self._y.size == 0:
            return
        default_name = "z_profile.png"
        if self._stack_name:
            safe = self._stack_name.replace(":", "_").replace("/", "_")
            default_name = f"{safe}_z_profile.png"
        path, _ = QFileDialog.getSaveFileName(self, "Export z profile as PNG", str(Path.home() / default_name), "PNG files (*.png)")
        if not path:
            return
        exporter = pg.exporters.ImageExporter(self.plot_widget.plotItem)
        exporter.export(path)

    def _apply_plot_style(self) -> None:
        self.plot_widget.showGrid(x=self.chk_grid.isChecked(), y=self.chk_grid.isChecked(), alpha=0.25)
        self._refresh_curve()

    def _refresh_curve(self) -> None:
        pen = pg.mkPen(width=int(self.spin_linewidth.value()))
        use_symbols = self.chk_symbols.isChecked() and self._x.size <= 1000
        symbol = "o" if use_symbols else None
        symbol_size = 6 if use_symbols else 0
        self.curve.setData(self._x, self._y, pen=pen, symbol=symbol, symbolSize=symbol_size, connect="finite")
