from PyQt6.QtCore import QObject, pyqtSignal


class PEEMSignals(QObject):
    mouse_moved = pyqtSignal(float, float, float)  # x, y, value
    left_clicked = pyqtSignal(float, float)
    right_clicked = pyqtSignal(float, float)
    double_clicked = pyqtSignal(float, float)
    roi_changed = pyqtSignal(float, float, float, float)  # x, y, w, h
    crosshair_moved = pyqtSignal(float, float)
    frame_changed = pyqtSignal(int)
    stack_loaded = pyqtSignal(str, int, int, int)  # name, n, ny, nx
    line_profile_changed = pyqtSignal(float, float, float, float)  # x1, y1, x2, y2
    line_profile_finished = pyqtSignal(float, float, float, float)  # x1, y1, x2, y2
