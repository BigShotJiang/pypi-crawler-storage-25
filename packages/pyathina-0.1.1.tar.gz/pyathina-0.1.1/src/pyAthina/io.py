from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

import h5py
import numpy as np
import tifffile
import xarray as xr

from pyAthina.models import DEFAULT_AXIS_UNITS, ImageStack


_SUPPORTED_STACK_EXTENSIONS = {".npy", ".h5", ".hdf5", ".hdf", ".tif", ".tiff"}

# Preferred TVIPS stack dataset paths.
#
# The current user dataset convention is:
#   /root/entry/instrument/tvips/data
#
# We keep a few normalized variants as fallbacks because some HDF5 files may expose
# the same logical path with or without a leading slash, or without the top-level
# 'root' group. If none of these paths exists, pyAthina falls back to the previous
# automatic dataset search.
_PREFERRED_H5_DATASET_PATHS = (
    "/root/entry/instrument/tvips/data",
    "root/entry/instrument/tvips/data",
    "/entry/instrument/tvips/data",
    "entry/instrument/tvips/data",
)


def _is_numeric_image_dataset(obj) -> bool:
    return isinstance(obj, h5py.Dataset) and obj.ndim in {2, 3} and np.issubdtype(obj.dtype, np.number)


def _decode_h5_value(value: Any) -> Any:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if isinstance(value, np.ndarray):
        if value.ndim == 0:
            return _decode_h5_value(value.item())
        if value.dtype.kind in {"S", "O", "U"}:
            return [_decode_h5_value(v) for v in value.tolist()]
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def _read_h5_attrs(obj) -> Dict[str, Any]:
    return {str(k): _decode_h5_value(v) for k, v in obj.attrs.items()}


def _collect_h5_scalar_and_string_datasets(h5: h5py.File) -> Dict[str, Any]:
    items: Dict[str, Any] = {}

    def visitor(name: str, obj) -> None:
        if not isinstance(obj, h5py.Dataset):
            return
        try:
            if obj.ndim == 0:
                items[f"/{name}"] = _decode_h5_value(obj[()])
            elif obj.dtype.kind in {"S", "O", "U"} and obj.size <= 128:
                items[f"/{name}"] = _decode_h5_value(obj[()])
        except Exception:
            pass

    h5.visititems(visitor)
    return items


def _default_pixel_index_axis_info(shape: tuple[int, int, int]) -> dict[str, dict[str, Any]]:
    """Return the safe fallback axis metadata.

    Fallback behavior requested by the user:
    - x axis: pixel index 0 .. nx-1, units='px'
    - y axis: pixel index 0 .. ny-1, units='px'
    - z axis: layer number 0 .. nz-1, units='index'

    These defaults are used whenever the HDF5 file does not provide readable axis
    ranges/coordinates for one or more dimensions.
    """
    nz, ny, nx = shape
    return {
        "z": {
            "values": np.arange(nz, dtype=np.float64),
            "label": "layer",
            "units": "index",
        },
        "y": {
            "values": np.arange(ny, dtype=np.float64),
            "label": "y",
            "units": "px",
        },
        "x": {
            "values": np.arange(nx, dtype=np.float64),
            "label": "x",
            "units": "px",
        },
    }


def _as_float_1d_array(value: Any, expected_size: int | None = None) -> np.ndarray | None:
    """Try to convert HDF5 metadata into a 1D float coordinate array.

    Returns None if the value is missing, not numeric, or not compatible with the
    expected axis length.
    """
    if value is None:
        return None
    arr = np.asarray(value)
    if arr.ndim == 0:
        arr = arr.reshape(1)
    if arr.ndim != 1:
        return None
    try:
        arr = arr.astype(np.float64)
    except (TypeError, ValueError):
        return None
    if expected_size is not None and arr.size != int(expected_size):
        return None
    return arr


def _linspace_from_range(start: Any, stop: Any, size: int) -> np.ndarray | None:
    """Build a coordinate vector from a start/stop pair, or return None."""
    try:
        start_f = float(start)
        stop_f = float(stop)
    except (TypeError, ValueError):
        return None
    if size <= 0:
        return None
    if size == 1:
        return np.array([start_f], dtype=np.float64)
    return np.linspace(start_f, stop_f, int(size), dtype=np.float64)


def _read_optional_h5_value(h5: h5py.File, path: str | None) -> Any:
    """Read a dataset by absolute HDF5 path, returning None when unavailable.

    This is intended for the user-editable axis-mapping helper below.
    """
    if not path:
        return None
    try:
        if path in h5:
            return _decode_h5_value(h5[path][()])
    except Exception:
        return None
    return None


def _extract_h5_axis_info_for_user_tags(
    h5: h5py.File,
    dataset_path: str,
    shape: tuple[int, int, int],
) -> dict[str, dict[str, Any]]:
    """User-editable HDF5 axis mapping helper.

    Edit this function to connect your HDF5 tags/datasets to pyAthina's axis model.
    The expected return value is a dictionary with keys 'x', 'y', and 'z'.
    For each axis you may provide:

        {
            "values": 1D numeric array with exactly the axis length,
            "label":  axis name shown in the UI, e.g. 'energy', 'x', 'sample x',
            "units":  unit string, e.g. 'eV', 'um', 'mm', 'px'
        }

    You do NOT need to fill everything. Any missing or unreadable field falls back to:
        x -> pixel index 0..nx-1 in px
        y -> pixel index 0..ny-1 in px
        z -> layer number 0..nz-1

    Two common ways to populate an axis are shown below:

    1) Exact coordinate vector already stored in the file:
         x_values = _read_optional_h5_value(h5, '/entry/instrument/x_axis')
         axis_info['x']['values'] = _as_float_1d_array(x_values, expected_size=shape[2])

    2) Only a range is stored, so coordinates must be constructed:
         x_start = ds.attrs.get('x_start_um')
         x_stop  = ds.attrs.get('x_stop_um')
         axis_info['x']['values'] = _linspace_from_range(x_start, x_stop, shape[2])
         axis_info['x']['label'] = 'x'
         axis_info['x']['units'] = 'um'

    Notes:
    - shape is always ordered as (z, y, x)
    - dataset_path is the HDF5 path of the selected image stack
    - ds.attrs contains dataset attributes, parent.attrs group attributes, and h5.attrs
      file attributes are also available if you need them
    """
    axis_info = _default_pixel_index_axis_info(shape)

    ds = h5[dataset_path]
    parent = ds.parent if isinstance(ds.parent, h5py.Group) else h5

    # ---------------------------------------------------------------------
    # Fill in your real HDF5 tags below.
    # Everything in this block is optional. If a tag is absent or invalid,
    # pyAthina will automatically fall back to pixels / layer index.
    # ---------------------------------------------------------------------

    # Example placeholders for direct 1D coordinate datasets.
    # Replace the HDF5 paths with the ones used at your beamline / facility.
    x_values = _read_optional_h5_value(h5, None)  # e.g. '/entry/axes/x'
    y_values = _read_optional_h5_value(h5, None)  # e.g. '/entry/axes/y'
    z_values = _read_optional_h5_value(h5, None)  # e.g. '/entry/axes/energy'

    x_values = _as_float_1d_array(x_values, expected_size=shape[2])
    y_values = _as_float_1d_array(y_values, expected_size=shape[1])
    z_values = _as_float_1d_array(z_values, expected_size=shape[0])

    if x_values is not None:
        axis_info['x']['values'] = x_values
        axis_info['x']['label'] = 'x'
        axis_info['x']['units'] = 'px'  # e.g. change to 'um'

    if y_values is not None:
        axis_info['y']['values'] = y_values
        axis_info['y']['label'] = 'y'
        axis_info['y']['units'] = 'px'  # e.g. change to 'um'

    if z_values is not None:
        axis_info['z']['values'] = z_values
        axis_info['z']['label'] = 'z'   # e.g. change to 'energy'
        axis_info['z']['units'] = DEFAULT_AXIS_UNITS['z']  # e.g. change to 'eV'

    # Example placeholders for start/stop metadata stored in attributes.
    # Uncomment/adapt if your file stores only a range and not the full axis vector.
    #
    # x_start = ds.attrs.get('x_start') or parent.attrs.get('x_start') or h5.attrs.get('x_start')
    # x_stop = ds.attrs.get('x_stop') or parent.attrs.get('x_stop') or h5.attrs.get('x_stop')
    # x_from_range = _linspace_from_range(x_start, x_stop, shape[2])
    # if x_from_range is not None:
    #     axis_info['x']['values'] = x_from_range
    #     axis_info['x']['label'] = 'x'
    #     axis_info['x']['units'] = 'um'
    #
    # y_start = ds.attrs.get('y_start') or parent.attrs.get('y_start') or h5.attrs.get('y_start')
    # y_stop = ds.attrs.get('y_stop') or parent.attrs.get('y_stop') or h5.attrs.get('y_stop')
    # y_from_range = _linspace_from_range(y_start, y_stop, shape[1])
    # if y_from_range is not None:
    #     axis_info['y']['values'] = y_from_range
    #     axis_info['y']['label'] = 'y'
    #     axis_info['y']['units'] = 'um'
    #
    # z_start = ds.attrs.get('z_start') or parent.attrs.get('z_start') or h5.attrs.get('z_start')
    # z_stop = ds.attrs.get('z_stop') or parent.attrs.get('z_stop') or h5.attrs.get('z_stop')
    # z_from_range = _linspace_from_range(z_start, z_stop, shape[0])
    # if z_from_range is not None:
    #     axis_info['z']['values'] = z_from_range
    #     axis_info['z']['label'] = 'energy'
    #     axis_info['z']['units'] = 'eV'

    # Optional axis-name placeholders from attributes. Replace these keys with your own.
    # axis_info['x']['label'] = str(ds.attrs.get('x_name', axis_info['x']['label']))
    # axis_info['y']['label'] = str(ds.attrs.get('y_name', axis_info['y']['label']))
    # axis_info['z']['label'] = str(ds.attrs.get('z_name', axis_info['z']['label']))

    return axis_info


def _build_coords_from_axis_info(shape: tuple[int, int, int], axis_info: dict[str, dict[str, Any]]) -> dict[str, xr.DataArray]:
    defaults = _default_pixel_index_axis_info(shape)
    coords: dict[str, xr.DataArray] = {}

    for axis, size in zip(("z", "y", "x"), shape):
        meta = dict(defaults[axis])
        meta.update(axis_info.get(axis, {}))

        values = _as_float_1d_array(meta.get("values"), expected_size=size)
        if values is None:
            values = np.asarray(defaults[axis]["values"], dtype=np.float64)

        label = str(meta.get("label", axis)) if meta.get("label", axis) is not None else axis
        units = str(meta.get("units", defaults[axis]["units"])) if meta.get("units", defaults[axis]["units"]) is not None else ""

        coords[axis] = xr.DataArray(
            values,
            dims=(axis,),
            attrs={"units": units, "long_name": label},
        )

    return coords


def _normalize_image_array(data: np.ndarray) -> np.ndarray:
    arr = np.asarray(data)
    if arr.ndim == 2:
        return arr[np.newaxis, :, :]
    if arr.ndim == 3:
        return arr
    raise ValueError(
        "Unsupported image shape. Expected a 2D image or 3D stack with shape (ny, nx) or (n_images, ny, nx)."
    )


def _build_xarray_from_numpy(
    data: np.ndarray,
    *,
    name: str,
    metadata: dict[str, Any] | None = None,
    coords: dict[str, xr.DataArray] | None = None,
) -> xr.DataArray:
    arr = _normalize_image_array(np.asarray(data))
    coord_map = coords if coords is not None else _build_coords_from_axis_info(arr.shape, {})
    attrs = dict(metadata or {})
    attrs.setdefault("signal_name", name)
    return xr.DataArray(arr, dims=("z", "y", "x"), coords=coord_map, attrs=attrs, name=name)


def list_h5_image_datasets(path: str | Path) -> List[str]:
    path = Path(path)
    dataset_paths: List[str] = []
    with h5py.File(path, "r") as h5:
        def visitor(name, obj):
            if _is_numeric_image_dataset(obj):
                dataset_paths.append(f"/{name}")
        h5.visititems(visitor)
    return dataset_paths


def _normalize_h5_path(path: str) -> str:
    path = str(path).strip()
    if not path:
        return "/"
    return path if path.startswith("/") else f"/{path}"


# Small user-editable hook for the primary image dataset path.
#
# If your facility later changes the stack location, edit the tuple near the top of
# this file (_PREFERRED_H5_DATASET_PATHS). For now, pyAthina will first try:
#   /root/entry/instrument/tvips/data
# and only if that is absent will it revert to automatic dataset discovery.
def choose_h5_dataset(path: str | Path) -> str:
    path = Path(path)
    with h5py.File(path, "r") as h5:
        for preferred in _PREFERRED_H5_DATASET_PATHS:
            normalized = _normalize_h5_path(preferred)
            if normalized in h5 and _is_numeric_image_dataset(h5[normalized]):
                return normalized

        candidates = []

        def visitor(name, obj):
            if _is_numeric_image_dataset(obj):
                candidates.append(f"/{name}")

        h5.visititems(visitor)

        if not candidates:
            raise ValueError(
                "No numeric 2D or 3D image datasets were found in this HDF5 file. "
                "Expected TVIPS data at /root/entry/instrument/tvips/data."
            )
        if len(candidates) == 1:
            return candidates[0]

        def sort_key(name: str) -> tuple[int, int]:
            ds = h5[name]
            return (int(ds.ndim), int(np.prod(ds.shape)))

        return max(candidates, key=sort_key)


def _read_h5_metadata_template(path: Path, dataset_path: str) -> dict[str, Any]:
    with h5py.File(path, "r") as h5:
        ds = h5[dataset_path]
        parent = ds.parent if isinstance(ds.parent, h5py.Group) else h5
        axis_info = _extract_h5_axis_info_for_user_tags(h5, dataset_path, _normalize_image_array(np.asarray(ds)).shape)
        return {
            "h5_dataset_path": dataset_path,
            "h5_file_attrs": _read_h5_attrs(h5),
            "h5_group_attrs": _read_h5_attrs(parent),
            "h5_dataset_attrs": _read_h5_attrs(ds),
            "h5_scalar_and_string_items": _collect_h5_scalar_and_string_datasets(h5),
            "h5_axis_info": {
                axis: {
                    "label": str(meta.get("label", axis)),
                    "units": str(meta.get("units", "")),
                    "n_values": int(np.asarray(meta.get("values", [])).size),
                }
                for axis, meta in axis_info.items()
            },
            # Placeholder for user mapping of HDF5 metadata into domain-specific attrs.
            "user_metadata": {},
        }


def load_stack_from_h5(path: str | Path, dataset_path: str | None = None, dtype=np.float32) -> ImageStack:
    path = Path(path)
    chosen_dataset = _normalize_h5_path(dataset_path) if dataset_path else choose_h5_dataset(path)
    with h5py.File(path, "r") as h5:
        if chosen_dataset not in h5:
            raise ValueError(
                f"Requested HDF5 dataset not found: {chosen_dataset}. "
                "Expected TVIPS data at /root/entry/instrument/tvips/data."
            )
        ds = h5[chosen_dataset]
        data = np.asarray(ds, dtype=dtype)
        arr = _normalize_image_array(data)
        axis_info = _extract_h5_axis_info_for_user_tags(h5, chosen_dataset, arr.shape)
        coords = _build_coords_from_axis_info(arr.shape, axis_info)
    metadata = _read_h5_metadata_template(path, chosen_dataset)
    data_array = _build_xarray_from_numpy(data, name="intensity", metadata=metadata, coords=coords)
    return ImageStack.from_xarray(data_array, name=f"{path.name}:{chosen_dataset}", source_path=str(path))


def load_stack_from_npy(path: str | Path, dtype=np.float32) -> ImageStack:
    path = Path(path)
    data = np.asarray(np.load(path), dtype=dtype)
    data_array = _build_xarray_from_numpy(data, name="intensity", metadata={"user_metadata": {}})
    return ImageStack.from_xarray(data_array, name=path.name, source_path=str(path))


def load_stack_from_tiff(path: str | Path, dtype=np.float32) -> ImageStack:
    path = Path(path)
    data = tifffile.imread(path)
    data = np.asarray(_normalize_image_array(data), dtype=dtype)
    metadata = {"user_metadata": {}, "source_format": "tiff"}
    data_array = _build_xarray_from_numpy(data, name="intensity", metadata=metadata)
    return ImageStack.from_xarray(data_array, name=path.name, source_path=str(path))


# Backward-compatible alias kept in case other modules import the old helper name.
list_h5_3d_datasets = list_h5_image_datasets

def load_stack_auto(path: str | Path, dataset_path: str | None = None, dtype=np.float32) -> ImageStack:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix not in _SUPPORTED_STACK_EXTENSIONS:
        raise ValueError(f"Unsupported file type: {suffix}")
    if suffix == ".npy":
        return load_stack_from_npy(path, dtype=dtype)
    if suffix in {".tif", ".tiff"}:
        return load_stack_from_tiff(path, dtype=dtype)
    return load_stack_from_h5(path, dataset_path=dataset_path, dtype=dtype)


def save_image_tiff(path: str | Path, image: np.ndarray) -> None:
    tifffile.imwrite(str(path), np.asarray(image))


def save_stack_tiff(path: str | Path, stack: np.ndarray) -> None:
    tifffile.imwrite(str(path), np.asarray(stack))
