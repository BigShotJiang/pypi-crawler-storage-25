from __future__ import annotations

from typing import Tuple

import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import QEvent, QPointF, QRectF, Qt
from PyQt6.QtGui import QBrush, QColor, QPen, QPolygonF
from PyQt6.QtWidgets import QGraphicsPolygonItem


def _coord_edges(values: np.ndarray) -> np.ndarray:
    vals = np.asarray(values, dtype=np.float64)
    if vals.size == 1:
        return np.array([vals[0] - 0.5, vals[0] + 0.5], dtype=np.float64)
    mids = 0.5 * (vals[:-1] + vals[1:])
    first = vals[0] - (mids[0] - vals[0])
    last = vals[-1] + (vals[-1] - mids[-1])
    return np.concatenate([[first], mids, [last]]).astype(np.float64)


class PEEMImageView(pg.GraphicsLayoutWidget):
    """Central image viewer with histogram, ROI, crosshair, and line-profile overlays."""

    def __init__(self, signals, parent=None):
        super().__init__(parent)
        self.signals = signals

        self.plot = self.addPlot()
        self.plot.setAspectLocked(True)
        self.plot.invertY(True)
        self.plot.setLabel("left", "y")
        self.plot.setLabel("bottom", "x")

        self.image_item = pg.ImageItem()
        self.plot.addItem(self.image_item)

        self.hist = pg.HistogramLUTItem()
        self.hist.setImageItem(self.image_item)
        self.addItem(self.hist)

        self.roi = pg.ROI([0.5, 0.5], [1.0, 1.0], movable=True, resizable=True, rotatable=False)
        self.roi.addScaleHandle([1, 1], [0, 0])
        self.roi.addScaleHandle([0, 0], [1, 1])
        self.plot.addItem(self.roi)
        self.roi.hide()
        self.roi.sigRegionChanged.connect(self._emit_roi_changed)

        self.vline = pg.InfiniteLine(angle=90, movable=True, pen=pg.mkPen(width=1))
        self.hline = pg.InfiniteLine(angle=0, movable=True, pen=pg.mkPen(width=1))
        self.plot.addItem(self.vline)
        self.plot.addItem(self.hline)
        self.vline.hide()
        self.hline.hide()
        self.vline.sigPositionChanged.connect(self._crosshair_changed)
        self.hline.sigPositionChanged.connect(self._crosshair_changed)

        self.line_profile_width_px = 1

        self.line_profile_band = QGraphicsPolygonItem(self.plot.vb.childGroup)
        self.line_profile_band.setBrush(QBrush(QColor(255, 105, 180, 90)))
        # Keep the band outline disabled. A non-cosmetic pen is interpreted in
        # scene/image coordinates, which becomes visually huge once the axes are
        # expressed in physical units (for example 0→5 instead of pixel indices).
        # The yellow line ROI already marks the center line, so a fill-only band
        # is the clearest overlay here.
        self.line_profile_band.setPen(QPen(Qt.PenStyle.NoPen))
        self.line_profile_band.setZValue(15)
        self.line_profile_band.hide()

        self.line_roi = pg.LineSegmentROI([[0.6, 0.6], [1.8, 1.4]], pen=pg.mkPen("y", width=2), hoverPen=pg.mkPen("c", width=2))
        self.plot.addItem(self.line_roi)
        self.line_roi.hide()
        self.line_roi.sigRegionChanged.connect(self._on_line_roi_changed)
        if hasattr(self.line_roi, "sigRegionChangeFinished"):
            self.line_roi.sigRegionChangeFinished.connect(self._on_line_roi_change_finished)

        self.proxy = pg.SignalProxy(self.plot.scene().sigMouseMoved, rateLimit=60, slot=self._mouse_moved)
        self.plot.scene().sigMouseClicked.connect(self._mouse_clicked)
        self.viewport().installEventFilter(self)

        self.current_image: np.ndarray | None = None
        self.x_coords = np.array([], dtype=np.float64)
        self.y_coords = np.array([], dtype=np.float64)
        self._line_draw_mode = False
        self._line_drag_active = False
        self._line_profile_defined = False
        self._line_start = QPointF(0.0, 0.0)

    def set_image(self, image: np.ndarray, x_coords=None, y_coords=None, axis_labels=None, auto_levels: bool = True) -> None:
        previous_levels = self.hist.getLevels()
        self.current_image = np.asarray(image)
        ny, nx = self.current_image.shape
        self.x_coords = np.asarray(x_coords if x_coords is not None else np.arange(nx), dtype=np.float64)
        self.y_coords = np.asarray(y_coords if y_coords is not None else np.arange(ny), dtype=np.float64)
        self.image_item.setImage(self.current_image, autoLevels=auto_levels)
        if not auto_levels and previous_levels is not None:
            low, high = previous_levels
            if np.isfinite(low) and np.isfinite(high):
                self.hist.setLevels(float(low), float(high))
        rect = self._image_rect()
        self.image_item.setRect(rect)
        labels = axis_labels or {}
        self.plot.setLabel("bottom", labels.get("x", "x"))
        self.plot.setLabel("left", labels.get("y", "y"))
        self._update_line_profile_band()

    def clear_image(self) -> None:
        self.current_image = None
        self.x_coords = np.array([], dtype=np.float64)
        self.y_coords = np.array([], dtype=np.float64)
        self.image_item.clear()
        self.plot.setLabel("bottom", "x")
        self.plot.setLabel("left", "y")
        self.line_profile_band.hide()

    def _image_rect(self) -> QRectF:
        if self.x_coords.size == 0 or self.y_coords.size == 0:
            return QRectF(0.0, 0.0, 1.0, 1.0)
        x_edges = _coord_edges(self.x_coords)
        y_edges = _coord_edges(self.y_coords)
        return QRectF(float(x_edges[0]), float(y_edges[0]), float(x_edges[-1] - x_edges[0]), float(y_edges[-1] - y_edges[0]))

    def show_roi(self, visible: bool) -> None:
        self.roi.setVisible(visible)
        if visible:
            self._emit_roi_changed()

    def show_crosshair(self, visible: bool) -> None:
        self.vline.setVisible(visible)
        self.hline.setVisible(visible)
        if visible and self.current_image is not None:
            self.vline.setPos(float(self.x_coords[len(self.x_coords) // 2]))
            self.hline.setPos(float(self.y_coords[len(self.y_coords) // 2]))
            self._crosshair_changed()

    def set_roi(self, x: float, y: float, w: float, h: float) -> None:
        self.roi.setPos([float(x), float(y)])
        self.roi.setSize([float(w), float(h)])
        self._emit_roi_changed()

    def get_roi_bounds(self) -> Tuple[float, float, float, float]:
        pos = self.roi.pos()
        size = self.roi.size()
        return float(pos.x()), float(pos.y()), float(size.x()), float(size.y())

    def has_roi(self) -> bool:
        return bool(self.roi.isVisible())

    def start_line_profile_drawing(self) -> None:
        self._line_draw_mode = True
        self._line_drag_active = False
        self._line_profile_defined = False
        self.line_roi.hide()
        self.line_profile_band.hide()

    def has_line_profile_roi(self) -> bool:
        return bool(self.line_roi.isVisible())

    def line_profile_is_defined(self) -> bool:
        return bool(self._line_profile_defined)

    def show_line_profile_roi(self) -> None:
        if self._line_profile_defined:
            self.line_roi.show()
            self._update_line_profile_band()

    def hide_line_profile_roi(self) -> None:
        self._line_draw_mode = False
        self._line_drag_active = False
        self.line_roi.hide()
        self.line_profile_band.hide()

    def clear_line_profile_roi(self) -> None:
        self._line_draw_mode = False
        self._line_drag_active = False
        self._line_profile_defined = False
        self.line_roi.hide()
        self.line_profile_band.hide()

    def get_line_profile_points(self) -> tuple[tuple[float, float], tuple[float, float]]:
        if not self.line_roi.isVisible():
            raise ValueError("Line ROI is not visible")
        handles = self.line_roi.getSceneHandlePositions()
        if len(handles) < 2:
            raise ValueError("Line ROI has insufficient handles")
        points = []
        for _, scene_pos in handles[:2]:
            view_pos = self.plot.vb.mapSceneToView(scene_pos)
            points.append((float(view_pos.x()), float(view_pos.y())))
        return points[0], points[1]

    def set_line_profile_width(self, width_px: int) -> None:
        self.line_profile_width_px = max(1, int(width_px))
        self._update_line_profile_band()

    def _coord_to_pixel_float(self, axis_vals: np.ndarray, value: float, extrapolate: bool = False) -> float:
        vals = np.asarray(axis_vals, dtype=np.float64)
        if vals.size <= 1:
            return 0.0

        original_descending = bool(vals[0] > vals[-1])
        if original_descending:
            vals_work = vals[::-1]
        else:
            vals_work = vals
        idx_work = np.arange(vals_work.size, dtype=np.float64)
        value = float(value)

        if not extrapolate:
            pix = float(np.interp(value, vals_work, idx_work))
        elif value < vals_work[0]:
            denom = vals_work[1] - vals_work[0]
            slope = 1.0 / denom if abs(denom) > 0.0 else 0.0
            pix = (value - vals_work[0]) * slope
        elif value > vals_work[-1]:
            denom = vals_work[-1] - vals_work[-2]
            slope = 1.0 / denom if abs(denom) > 0.0 else 0.0
            pix = (vals_work.size - 1) + (value - vals_work[-1]) * slope
        else:
            pix = float(np.interp(value, vals_work, idx_work))

        if original_descending:
            pix = (vals.size - 1) - pix
        return float(pix)

    def _pixel_to_coord_float(self, axis_vals: np.ndarray, pixel_value: float) -> float:
        vals = np.asarray(axis_vals, dtype=np.float64)
        if vals.size == 0:
            return 0.0
        if vals.size == 1:
            return float(vals[0])
        coord_edges = _coord_edges(vals)
        pixel_edges = np.arange(vals.size + 1, dtype=np.float64) - 0.5
        pixel_value = float(pixel_value)
        if pixel_value < pixel_edges[0]:
            slope = (coord_edges[1] - coord_edges[0]) / (pixel_edges[1] - pixel_edges[0])
            return float(coord_edges[0] + (pixel_value - pixel_edges[0]) * slope)
        if pixel_value > pixel_edges[-1]:
            slope = (coord_edges[-1] - coord_edges[-2]) / (pixel_edges[-1] - pixel_edges[-2])
            return float(coord_edges[-1] + (pixel_value - pixel_edges[-1]) * slope)
        return float(np.interp(pixel_value, pixel_edges, coord_edges))

    def _update_line_profile_band(self) -> None:
        if not self.line_roi.isVisible() or self.x_coords.size == 0 or self.y_coords.size == 0:
            self.line_profile_band.hide()
            return
        try:
            (x1, y1), (x2, y2) = self.get_line_profile_points()
        except Exception:
            self.line_profile_band.hide()
            return

        # Keep the integration width defined strictly in pixels, matching the
        # sampling done by the line-profile extraction code. The overlay is then
        # converted back to the physical axis units for display.
        start_px = np.array([
            self._coord_to_pixel_float(self.x_coords, x1, extrapolate=True),
            self._coord_to_pixel_float(self.y_coords, y1, extrapolate=True),
        ], dtype=np.float64)
        end_px = np.array([
            self._coord_to_pixel_float(self.x_coords, x2, extrapolate=True),
            self._coord_to_pixel_float(self.y_coords, y2, extrapolate=True),
        ], dtype=np.float64)

        width_px = max(1, int(self.line_profile_width_px))
        delta_px = end_px - start_px
        length_px = float(np.hypot(delta_px[0], delta_px[1]))
        half_width_px = 0.5 * float(width_px)

        if length_px <= 1e-12:
            cx, cy = start_px
            corners_px = np.array([
                [cx - half_width_px, cy - half_width_px],
                [cx + half_width_px, cy - half_width_px],
                [cx + half_width_px, cy + half_width_px],
                [cx - half_width_px, cy + half_width_px],
            ], dtype=np.float64)
        else:
            perp_px = np.array([-delta_px[1], delta_px[0]], dtype=np.float64) / length_px
            offset_px = perp_px * half_width_px
            corners_px = np.array([
                start_px + offset_px,
                end_px + offset_px,
                end_px - offset_px,
                start_px - offset_px,
            ], dtype=np.float64)

        polygon = QPolygonF([
            QPointF(
                self._pixel_to_coord_float(self.x_coords, px),
                self._pixel_to_coord_float(self.y_coords, py),
            )
            for px, py in corners_px
        ])

        self.line_profile_band.setPolygon(polygon)
        self.line_profile_band.show()

    def eventFilter(self, watched, event):
        if watched is self.viewport() and self._line_draw_mode and self.current_image is not None:
            etype = event.type()
            if etype == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
                scene_pos = self.mapToScene(event.position().toPoint())
                start = self._scene_pos_to_image_point(scene_pos, clip=False)
                if start is None:
                    return False
                self._line_start = start
                self._line_drag_active = True
                self._set_line_roi_points(start, start)
                self.line_roi.show()
                self._emit_line_profile_changed()
                return True
            if etype == QEvent.Type.MouseMove and self._line_drag_active:
                scene_pos = self.mapToScene(event.position().toPoint())
                end = self._scene_pos_to_image_point(scene_pos, clip=False)
                if end is None:
                    return True
                self._set_line_roi_points(self._line_start, end)
                self._emit_line_profile_changed()
                return True
            if etype == QEvent.Type.MouseButtonRelease and self._line_drag_active and event.button() == Qt.MouseButton.LeftButton:
                scene_pos = self.mapToScene(event.position().toPoint())
                end = self._scene_pos_to_image_point(scene_pos, clip=False)
                if end is None:
                    end = self._line_start
                self._set_line_roi_points(self._line_start, end)
                self._line_drag_active = False
                self._line_draw_mode = False
                self._line_profile_defined = True
                self._emit_line_profile_changed()
                self._emit_line_profile_finished()
                return True
        return super().eventFilter(watched, event)

    def _set_line_roi_points(self, start: QPointF, end: QPointF) -> None:
        x1, y1 = float(start.x()), float(start.y())
        x2, y2 = float(end.x()), float(end.y())
        state = self.line_roi.saveState()
        state["pos"] = (0.0, 0.0)
        state["size"] = (1.0, 1.0)
        state["angle"] = 0.0
        state["points"] = [(x1, y1), (x2, y2)]
        self.line_roi.setState(state)
        self.line_roi.setZValue(20)
        self._update_line_profile_band()

    def _scene_pos_to_image_point(self, scene_pos, clip: bool) -> QPointF | None:
        if self.current_image is None or self.x_coords.size == 0 or self.y_coords.size == 0:
            return None
        view_pos = self.plot.vb.mapSceneToView(scene_pos)
        x = float(view_pos.x())
        y = float(view_pos.y())
        x_min, x_max = float(self.x_coords.min()), float(self.x_coords.max())
        y_min, y_max = float(self.y_coords.min()), float(self.y_coords.max())
        if clip:
            x = min(max(x, x_min), x_max)
            y = min(max(y, y_min), y_max)
        return QPointF(x, y)

    def _coord_to_nearest_index(self, axis_vals: np.ndarray, value: float) -> int:
        return int(np.argmin(np.abs(axis_vals - value)))

    def _emit_roi_changed(self) -> None:
        x, y, w, h = self.get_roi_bounds()
        self.signals.roi_changed.emit(x, y, w, h)

    def _crosshair_changed(self) -> None:
        self.signals.crosshair_moved.emit(float(self.vline.value()), float(self.hline.value()))

    def _emit_line_profile_changed(self) -> None:
        if not self.line_roi.isVisible():
            return
        self._update_line_profile_band()
        (x1, y1), (x2, y2) = self.get_line_profile_points()
        self.signals.line_profile_changed.emit(x1, y1, x2, y2)

    def _emit_line_profile_finished(self) -> None:
        if not self.line_roi.isVisible():
            return
        self._line_profile_defined = True
        self._update_line_profile_band()
        (x1, y1), (x2, y2) = self.get_line_profile_points()
        self.signals.line_profile_finished.emit(x1, y1, x2, y2)

    def _on_line_roi_changed(self) -> None:
        if self.line_roi.isVisible() and not self._line_drag_active:
            self._emit_line_profile_changed()

    def _on_line_roi_change_finished(self) -> None:
        if self.line_roi.isVisible() and not self._line_drag_active:
            self._line_profile_defined = True
            self._emit_line_profile_finished()

    def _mouse_moved(self, evt) -> None:
        pos = evt[0]
        vb = self.plot.vb
        mouse_point = vb.mapSceneToView(pos)
        x = float(mouse_point.x())
        y = float(mouse_point.y())
        value = np.nan
        if self.current_image is not None and self.x_coords.size > 0 and self.y_coords.size > 0:
            iy = self._coord_to_nearest_index(self.y_coords, y)
            ix = self._coord_to_nearest_index(self.x_coords, x)
            if 0 <= iy < self.current_image.shape[0] and 0 <= ix < self.current_image.shape[1]:
                value = float(self.current_image[iy, ix])
        self.signals.mouse_moved.emit(x, y, value)

    def _mouse_clicked(self, event) -> None:
        pos = self.plot.vb.mapSceneToView(event.scenePos())
        x, y = float(pos.x()), float(pos.y())
        if event.double():
            self.signals.double_clicked.emit(x, y)
        elif event.button() == Qt.MouseButton.LeftButton:
            self.signals.left_clicked.emit(x, y)
        elif event.button() == Qt.MouseButton.RightButton:
            self.signals.right_clicked.emit(x, y)
