"""Tests for gridfab.gui.app CLI entry-point behavior.

Only covers the early-exit paths that run before the GUI event loop
(argparse --help/--version, invalid directory). The GUI itself is
tested manually.
"""

import sys

import pytest

from gridfab.gui.app import main


def test_help_prints_usage_and_exits_zero(capsys, monkeypatch):
    monkeypatch.setattr(sys, "argv", ["gridfab-gui", "--help"])
    with pytest.raises(SystemExit) as exc_info:
        main()
    assert exc_info.value.code == 0
    out = capsys.readouterr().out
    assert "usage: gridfab-gui" in out
    assert "directory" in out


def test_version_prints_version_and_exits_zero(capsys, monkeypatch):
    from gridfab import __version__

    monkeypatch.setattr(sys, "argv", ["gridfab-gui", "--version"])
    with pytest.raises(SystemExit) as exc_info:
        main()
    assert exc_info.value.code == 0
    out = capsys.readouterr().out
    assert __version__ in out


def test_missing_directory_prints_error_and_exits_one(capsys, monkeypatch, tmp_path):
    missing = tmp_path / "does-not-exist"
    monkeypatch.setattr(sys, "argv", ["gridfab-gui", str(missing)])
    with pytest.raises(SystemExit) as exc_info:
        main()
    assert exc_info.value.code == 1
    err = capsys.readouterr().err
    assert "is not a directory" in err
    assert str(missing) in err
