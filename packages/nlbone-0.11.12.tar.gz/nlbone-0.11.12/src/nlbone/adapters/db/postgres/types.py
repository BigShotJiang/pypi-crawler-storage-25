from typing import Any
from sqlalchemy import BigInteger
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy import TypeDecorator
from pydantic import BaseModel


class BaseIntegerIdType(TypeDecorator):
    """Maps BaseId subclasses <-> BIGINT transparently (Infrastructure-only)."""

    impl = BigInteger
    cache_ok = True

    def __init__(self, id_cls):
        super().__init__()
        self.id_cls = id_cls

    def process_bind_param(self, value, dialect):
        # Python -> DB
        if value is None:
            return None
        return int(value)

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        return self.id_cls(int(value))


class PydanticJSONB(TypeDecorator):
    impl = JSONB
    cache_ok = True

    def __init__(self, pydantic_model: type[BaseModel], *args: Any, **kwargs: Any):
        super().__init__(*args, **kwargs)
        self._pydantic_model = pydantic_model

    def process_bind_param(self, value: BaseModel | dict | None, dialect: Any) -> dict | None:
        """Python → DB"""
        if value is None:
            return None
        if isinstance(value, self._pydantic_model):
            return value.model_dump()
        if isinstance(value, dict):
            return self._pydantic_model.model_validate(value).model_dump()
        raise ValueError(f"Expected {self._pydantic_model.__name__} or dict, got {type(value)}")

    def process_result_value(self, value: dict | None, dialect: Any) -> BaseModel | None:
        """DB → Python"""
        if value is None:
            return None
        return self._pydantic_model.model_validate(value)
