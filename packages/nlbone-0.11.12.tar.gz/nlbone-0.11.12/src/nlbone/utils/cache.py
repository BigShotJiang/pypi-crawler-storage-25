import asyncio
import dataclasses
import hashlib
import inspect
import json
from enum import Enum
from typing import Any, Callable, Optional, Type, TypeVar, get_args, get_origin, Iterable


import orjson
from makefun import wraps as mf_wraps

from nlbone.utils.cache_registry import get_cache

try:
    from pydantic import BaseModel  # v1/v2
except Exception:  # pragma: no cover

    class BaseModel:  # minimal fallback
        pass


# -------- helpers --------


def _bind(func: Callable, args, kwargs):
    sig = inspect.signature(func)
    bound = sig.bind_partial(*args, **kwargs)
    bound.apply_defaults()
    return bound


PRIMITIVES = (str, int, float, bool, type(None))


def to_jsonable(obj):
    from nlbone.interfaces.api.additional_filed import AdditionalFieldsRequest
    from nlbone.interfaces.api.pagination import PaginateRequest

    if isinstance(obj, PRIMITIVES):
        return obj

    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}

    if isinstance(obj, (list, tuple, set)):
        return [to_jsonable(v) for v in obj]

    if isinstance(obj, PaginateRequest):
        return {
            "limit": obj.limit,
            "offset": obj.offset,
            "sort": obj.sort,
            "filters": obj.filters,
            "include_ids": obj.include_ids,
        }

    if isinstance(obj, AdditionalFieldsRequest):
        return {
            "fields": obj.fields,
            "bundles": obj.bundles,
        }

    return f"<{obj.__class__.__name__}>"


def _key_from_template(
    tpl: Optional[str],
    func: Callable,
    args,
    kwargs,
) -> str:
    """Format key template with bound arguments or build a stable default."""
    bound = _bind(func, args, kwargs)
    if tpl:
        return tpl.format(**bound.arguments)

    # Default stable key: module:qualname:sha of args

    clean_args = to_jsonable(bound.arguments)
    payload = json.dumps(clean_args, sort_keys=True)

    payload = json.dumps(
        payload,
        sort_keys=True,
    )
    return f"{func.__module__}:{func.__qualname__}:{hashlib.sha1(payload.encode('utf-8')).hexdigest()}"


def _format_tags(
    tag_tpls: Optional[Iterable[str]],
    func: Callable,
    args,
    kwargs,
) -> list[str] | None:
    if not tag_tpls:
        return None
    bound = _bind(func, args, kwargs)
    return [t.format(**bound.arguments) for t in tag_tpls]


def _json_default(obj: Any) -> Any:
    if isinstance(obj, BaseModel):
        if hasattr(obj, "model_dump"):  # pydantic v2
            return obj.model_dump(mode="json")
        return obj.dict()  # pydantic v1

    if isinstance(obj, Enum):
        return obj.value

    if dataclasses.is_dataclass(obj):
        return dataclasses.asdict(obj)

    if isinstance(obj, set):
        return list(obj)

    if hasattr(obj, "__dict__"):
        return vars(obj)

    raise TypeError(f"Unsupported type for JSON serialization: {type(obj)!r}")


def default_serialize(val: Any) -> bytes:
    if val is None:
        return b"null"

    if isinstance(val, (bytes, bytearray, memoryview)):
        return bytes(val)

    if isinstance(val, str):
        return val.encode("utf-8")

    return orjson.dumps(
        val,
        default=_json_default,
        option=(orjson.OPT_NON_STR_KEYS | orjson.OPT_SERIALIZE_NUMPY | orjson.OPT_UTC_Z),
    )


def default_deserialize(b: bytes) -> Any:
    if b is None:
        return None
    if b == b"":
        return None
    return orjson.loads(b)


def make_typed_deserializer(type_hint: Any) -> Callable[[bytes], Any]:
    origin = get_origin(type_hint)
    args = get_args(type_hint)

    is_optional = origin is Optional or (origin is type(None)) or (origin is type | None)  # py3.10 union edge
    if origin is None and hasattr(type_hint, "__args__") and getattr(type_hint, "__origin__", None) is None:
        pass

    model_type: Optional[Type[BaseModel]] = None

    if inspect.isclass(type_hint) and issubclass(type_hint, BaseModel):
        model_type = type_hint
    elif origin in (list, tuple, set) and args and inspect.isclass(args[0]) and issubclass(args[0], BaseModel):
        model_type = args[0]

    def _build_model(item: Any) -> Any:
        if model_type is None:
            return item
        if item is None:
            return None
        if hasattr(model_type, "model_validate"):  # pydantic v2
            return model_type.model_validate(item)
        return model_type.parse_obj(item)  # pydantic v1

    def deser(data: bytes) -> Any:
        raw = default_deserialize(data)
        if model_type is None:
            return raw

        if origin in (list, tuple, set):
            if raw is None:
                return raw
            built = [_build_model(x) for x in raw]
            if origin is tuple:
                return tuple(built)
            if origin is set:
                return set(built)
            return built

        return _build_model(raw)

    return deser


def default_deserialize(b: bytes) -> Any:
    return json.loads(b)


def _is_async_method(obj: Any, name: str) -> bool:
    meth = getattr(obj, name, None)
    return inspect.iscoroutinefunction(meth)


def _run_maybe_async(func: Callable, *args, **kwargs):
    """Call a function that may be async from sync context."""
    result = func(*args, **kwargs)
    if inspect.isawaitable(result):
        try:
            return asyncio.run(result)
        except RuntimeError:
            result.close()
            raise
    return result


# -------- cache decorators --------


def cached(
    *,
    ttl: int,
    key: str | None = None,
    tags: Iterable[str] | None = None,
    serializer: Callable[[Any], bytes] = default_serialize,
    deserializer: Callable[[bytes], Any] = default_deserialize,
    cache_resolver: Optional[Callable[[], Any]] = None,
):
    def deco(func: Callable):
        is_async_func = inspect.iscoroutinefunction(func)

        if is_async_func:

            @mf_wraps(func)
            async def aw(*args, **kwargs):
                cache = (cache_resolver or get_cache)()
                if not cache:
                    return await func(*args, **kwargs)
                k = _key_from_template(key, func, args, kwargs)
                tg = _format_tags(tags, func, args, kwargs)

                # SAFE GET
                cached_bytes = None
                try:
                    result = cache.get(k)
                    if inspect.isawaitable(result):
                        cached_bytes = await result
                    else:
                        cached_bytes = result
                except Exception:
                    pass

                if cached_bytes is not None:
                    return deserializer(cached_bytes)

                # MISS → compute
                result = await func(*args, **kwargs)
                if not result:
                    return result

                # SAFE SET
                data = serializer(result)
                try:
                    res = cache.set(k, data, ttl=ttl, tags=tg)
                    if inspect.isawaitable(res):
                        await res
                except Exception:
                    pass

                return result

            return aw

        # SYNC callable
        @mf_wraps(func)
        def sw(*args, **kwargs):
            cache = (cache_resolver or get_cache)()
            if not cache:
                return func(*args, **kwargs)

            k = _key_from_template(key, func, args, kwargs)
            tg = _format_tags(tags, func, args, kwargs)

            # SAFE GET (maybe async)
            cached_bytes = None
            try:
                cached_bytes = _run_maybe_async(cache.get, k)
            except Exception:
                pass

            if cached_bytes is not None:
                return deserializer(cached_bytes)

            # MISS → compute
            result = func(*args, **kwargs)

            # SAFE SET (maybe async)
            data = serializer(result)
            try:
                _run_maybe_async(cache.set, k, data, ttl=ttl, tags=tg)
            except Exception:
                pass

            return result

        return sw

    return deco


def invalidate_by_tags(tags_builder: Callable[..., Iterable[str]]):
    """
    Invalidate computed tags after function finishes.
    Works with sync or async functions and cache backends.
    """

    def deco(func: Callable):
        is_async_func = inspect.iscoroutinefunction(func)

        if is_async_func:

            @mf_wraps(func)
            async def aw(*args, **kwargs):
                out = await func(*args, **kwargs)
                cache = get_cache()
                tags = list(tags_builder(*args, **kwargs))

                res = cache.invalidate_tags(tags)
                if inspect.isawaitable(res):
                    await res

                return out

            return aw

        @mf_wraps(func)
        def sw(*args, **kwargs):
            out = func(*args, **kwargs)
            cache = get_cache()
            tags = list(tags_builder(*args, **kwargs))

            _run_maybe_async(cache.invalidate_tags, tags)

            return out

        return sw

    return deco
