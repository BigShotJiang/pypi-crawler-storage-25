"""测试权限控制模块"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
from file_server.core.permission import (
    PERM_READ,
    PERM_READWRITE,
    _has_sufficient,
    _is_path_under,
    _normalize_path,
    check_permission,
    get_accessible_directories,
)


class TestNormalizePath:
    def test_empty_path(self):
        assert _normalize_path("") == ""
        assert _normalize_path(".") == ""

    def test_leading_trailing_slashes(self):
        assert _normalize_path("/project-a/") == "project-a"

    def test_backslash_conversion(self):
        assert _normalize_path("project-a\\subdir") == "project-a/subdir"

    def test_plain_path(self):
        assert _normalize_path("project-a") == "project-a"

    def test_nested_path(self):
        assert _normalize_path("a/b/c") == "a/b/c"


class TestIsPathUnder:
    def test_root_contains_all(self):
        assert _is_path_under("", "anything") is True
        assert _is_path_under(".", "file.txt") is True

    def test_child_not_under_parent(self):
        assert _is_path_under("", "") is True  # root contains root

    def test_exact_match(self):
        assert _is_path_under("project-a", "project-a") is True

    def test_child_under_parent(self):
        assert _is_path_under("project-a", "project-a/sub/file.txt") is True

    def test_wrong_parent(self):
        assert _is_path_under("project-b", "project-a/file.txt") is False

    def test_sibling_not_match(self):
        assert _is_path_under("project-a/sub", "project-a/file.txt") is False

    def test_root_path_under_parent(self):
        # 空路径（根）不在任何子目录下
        assert _is_path_under("project-a", "") is False


class TestHasSufficient:
    def test_rw_satisfies_r(self):
        assert _has_sufficient(PERM_READWRITE, PERM_READ) is True

    def test_rw_satisfies_rw(self):
        assert _has_sufficient(PERM_READWRITE, PERM_READWRITE) is True

    def test_r_does_not_satisfy_rw(self):
        assert _has_sufficient(PERM_READ, PERM_READWRITE) is False

    def test_r_satisfies_r(self):
        assert _has_sufficient(PERM_READ, PERM_READ) is True

    def test_invalid_granted(self):
        assert _has_sufficient("x", PERM_READ) is False

    def test_invalid_required(self):
        assert _has_sufficient(PERM_READWRITE, "x") is False


class TestCheckPermission:
    def test_none_user_returns_false(self):
        assert check_permission(None, "any/path", PERM_READ) is False

    def test_admin_always_has_access(self):
        admin = {"is_admin": True, "permissions": {}}
        assert check_permission(admin, "any/path", PERM_READ) is True
        assert check_permission(admin, "any/path", PERM_READWRITE) is True
        assert check_permission(admin, "restricted/area", PERM_READWRITE) is True

    def test_no_permissions_uses_default(self):
        user = {"is_admin": False, "permissions": {}}
        assert check_permission(user, "any/path", PERM_READ, PERM_READWRITE) is True
        assert check_permission(user, "any/path", PERM_READWRITE, PERM_READWRITE) is True
        assert check_permission(user, "any/path", PERM_READWRITE, PERM_READ) is False

    def test_no_permissions_key_uses_default(self):
        user = {"is_admin": False}
        assert check_permission(user, "any/path", PERM_READ, PERM_READWRITE) is True
        assert check_permission(user, "any/path", PERM_READWRITE, PERM_READ) is False

    def test_exact_path_match(self):
        user = {"is_admin": False, "permissions": {"project-a": "rw"}}
        assert check_permission(user, "project-a", PERM_READWRITE) is True
        assert check_permission(user, "project-a", PERM_READ) is True

    def test_child_inherits_parent_permission(self):
        user = {"is_admin": False, "permissions": {"project-a": "rw"}}
        assert check_permission(user, "project-a/sub/file.txt", PERM_READWRITE) is True

    def test_read_only_on_dir(self):
        user = {"is_admin": False, "permissions": {"docs": "r"}}
        assert check_permission(user, "docs/report.pdf", PERM_READ) is True
        assert check_permission(user, "docs/report.pdf", PERM_READWRITE) is False

    def test_longest_prefix_wins(self):
        user = {
            "is_admin": False,
            "permissions": {
                "project-a": "rw",
                "project-a/readonly": "r",
            }
        }
        assert check_permission(user, "project-a/data/file.txt", PERM_READWRITE) is True
        assert check_permission(user, "project-a/readonly/file.txt", PERM_READWRITE) is False
        assert check_permission(user, "project-a/readonly/file.txt", PERM_READ) is True

    def test_wildcard_matches_all(self):
        user = {"is_admin": False, "permissions": {"*": "r"}}
        assert check_permission(user, "any/path/file.txt", PERM_READ) is True
        assert check_permission(user, "any/path/file.txt", PERM_READWRITE) is False

    def test_wildcard_overridden_by_specific(self):
        user = {
            "is_admin": False,
            "permissions": {"*": "r", "writable": "rw"}
        }
        assert check_permission(user, "other/file.txt", PERM_READWRITE) is False
        assert check_permission(user, "other/file.txt", PERM_READ) is True
        assert check_permission(user, "writable/file.txt", PERM_READWRITE) is True

    def test_unmatched_path_uses_default(self):
        user = {"is_admin": False, "permissions": {"only-this": "rw"}}
        # "other" doesn't match "only-this", so default applies
        assert check_permission(user, "other", PERM_READ, PERM_READWRITE) is True
        # When default is "r", write is denied for unmatched paths
        assert check_permission(user, "other", PERM_READWRITE, PERM_READ) is False

    def test_root_path_with_permission(self):
        user = {"is_admin": False, "permissions": {"public": "rw"}}
        # 空路径（根目录列表）应该用 default
        assert check_permission(user, "", PERM_READ, PERM_READWRITE) is True

    def test_windows_backslash_path(self):
        user = {"is_admin": False, "permissions": {"project-a": "rw"}}
        assert check_permission(user, "project-a\\sub\\file.txt", PERM_READWRITE) is True


class TestGetAccessibleDirectories:
    def test_admin_sees_all(self):
        admin = {"is_admin": True}
        dirs = ["dir1", "dir2", "secret"]
        assert get_accessible_directories(admin, Path("/tmp"), dirs) == dirs

    def test_none_user_sees_nothing(self):
        assert get_accessible_directories(None, Path("/tmp"), ["dir1"]) == []

    def test_filter_by_permissions(self):
        user = {"is_admin": False, "permissions": {"allowed": "rw", "readonly": "r"}}
        dirs = ["allowed", "readonly", "forbidden"]
        result = get_accessible_directories(user, Path("/tmp"), dirs)
        assert "allowed" in result
        assert "readonly" in result
        # default_permission is "rw" so unmatched "forbidden" is still readable
        assert "forbidden" in result

    def test_wildcard_includes_all(self):
        user = {"is_admin": False, "permissions": {"*": "r"}}
        dirs = ["a", "b", "c"]
        assert get_accessible_directories(user, Path("/tmp"), dirs) == dirs
