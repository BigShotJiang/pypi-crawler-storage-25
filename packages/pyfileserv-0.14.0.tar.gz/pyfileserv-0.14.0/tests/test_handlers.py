"""测试 HTTP 处理器模块"""
import platform
import sys
import tempfile
from pathlib import Path

import pytest

# 确保使用本地源代码
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from datetime import datetime

from file_server.handle.utils import _is_safe_path, _resolve_safe_path, _sanitize_filename
from file_server.handle.file_ops import _parse_size, _parse_date


class TestIsSafePath:
    """测试路径安全验证函数"""

    def test_safe_path_inside_base(self):
        """测试基础目录内的路径是安全的"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            target = base / "subdir" / "file.txt"
            # 创建文件
            target.parent.mkdir(parents=True, exist_ok=True)
            target.touch()

            assert _is_safe_path(base, target) is True

    def test_safe_path_direct_child(self):
        """测试直接子文件是安全的"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            target = base / "file.txt"
            target.touch()

            assert _is_safe_path(base, target) is True

    def test_unsafe_path_traversal_parent(self):
        """测试路径遍历攻击 (../)"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            # 尝试访问父目录
            target = base / ".." / "etc" / "passwd"

            assert _is_safe_path(base, target) is False

    def test_unsafe_path_absolute_outside(self):
        """测试绝对路径访问外部目录"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            # 绝对路径到系统目录
            target = Path("/etc/passwd")

            assert _is_safe_path(base, target) is False

    def test_unsafe_path_deep_traversal(self):
        """测试多层路径遍历攻击"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            target = base / "subdir" / ".." / ".." / ".." / "etc" / "passwd"

            assert _is_safe_path(base, target) is False

    @pytest.mark.skipif(platform.system() == "Windows", reason="Windows requires admin for symlinks")
    def test_safe_path_symlink_inside(self):
        """测试符号链接在基础目录内"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            real_file = base / "real.txt"
            real_file.touch()

            symlink = base / "link.txt"
            symlink.symlink_to(real_file)

            # 符号链接指向基础目录内的文件，应该是安全的
            assert _is_safe_path(base, symlink) is True

    def test_nonexistent_path(self):
        """测试不存在的路径"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            target = base / "nonexistent" / "file.txt"

            # 不存在的路径解析后仍在基础目录内，应该是安全的
            assert _is_safe_path(base, target) is True

    def test_base_dir_itself(self):
        """测试基础目录本身"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)

            # 基础目录本身是安全的
            assert _is_safe_path(base, base) is True

    def test_relative_path_with_dots(self):
        """测试包含点号的相对路径"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            # 创建子目录和文件
            subdir = base / "subdir"
            subdir.mkdir()
            (subdir / "file.txt").touch()

            # 使用点号的路径
            target = base / "subdir" / "." / "file.txt"

            assert _is_safe_path(base, target) is True


class TestResolveSafePath:
    """测试安全路径解析函数"""

    def test_resolve_safe_path_valid(self):
        """测试有效路径解析"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            (base / "subdir").mkdir()
            (base / "subdir" / "file.txt").touch()

            result = _resolve_safe_path(base, "subdir/file.txt")
            assert result is not None
            assert result.name == "file.txt"

    def test_resolve_safe_path_traversal(self):
        """测试路径遍历攻击防护"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            result = _resolve_safe_path(base, "../outside.txt")
            assert result is None

    def test_resolve_safe_path_nonexistent(self):
        """测试不存在的路径解析"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            result = _resolve_safe_path(base, "nonexistent/file.txt")
            # 路径不存在但位置安全，应返回解析后的 Path
            assert result is not None
            assert result.name == "file.txt"

    def test_resolve_safe_path_absolute_outside(self):
        """测试外部绝对路径解析"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            # 使用系统路径
            result = _resolve_safe_path(base, "/etc/passwd" if platform.system() != "Windows" else "C:/Windows/System32")
            assert result is None


class TestSanitizeFilename:
    """测试文件名清理函数"""

    def test_sanitize_filename_normal(self):
        """测试正常文件名"""
        assert _sanitize_filename("file.txt") == "file.txt"
        assert _sanitize_filename("my-file 123.jpg") == "my-file 123.jpg"

    def test_sanitize_filename_replaces_dangerous_chars(self):
        """测试替换危险字符为下划线"""
        assert _sanitize_filename("file.txt") == "file.txt"
        assert _sanitize_filename("file/with/slashes.txt") == "slashes.txt"  # basename 只保留最后部分
        assert _sanitize_filename('file"with"quotes.txt') == "file_with_quotes.txt"
        assert _sanitize_filename("file<with>angle.txt") == "file_with_angle.txt"
        assert _sanitize_filename("file|with|pipes.txt") == "file_with_pipes.txt"
        assert _sanitize_filename("file?with?marks.txt") == "file_with_marks.txt"
        assert _sanitize_filename("file*with*stars.txt") == "file_with_stars.txt"

    def test_sanitize_filename_removes_leading_dots(self):
        """测试移除开头的点号"""
        assert _sanitize_filename(".htaccess") == "htaccess"
        assert _sanitize_filename("..") == "unnamed_file"
        assert _sanitize_filename("...") == "unnamed_file"

    def test_sanitize_filename_empty_result(self):
        """测试清理后为空的情况"""
        assert _sanitize_filename("") == "unnamed_file"
        assert _sanitize_filename("...") == "unnamed_file"
        assert _sanitize_filename("<<<>>>") == "______"  # 替换为下划线
        assert _sanitize_filename('""""') == "____"

    def test_sanitize_filename_removes_path_components(self):
        """测试移除路径组件 (只保留 basename)"""
        assert _sanitize_filename("../../etc/passwd") == "passwd"
        assert _sanitize_filename("/absolute/path/file.txt") == "file.txt"
        assert _sanitize_filename("dir/subdir/file.txt") == "file.txt"


class TestParseSize:
    """测试文件大小解析函数"""

    def test_empty_value_returns_none(self):
        assert _parse_size("") is None
        assert _parse_size("   ") is None

    def test_none_value(self):
        assert _parse_size(None) is None

    def test_bytes(self):
        assert _parse_size("100") == 100
        assert _parse_size("0") == 0
        assert _parse_size("100B") == 100
        assert _parse_size("1.5B") == 1

    def test_kilobytes(self):
        assert _parse_size("1KB") == 1024
        assert _parse_size("10KB") == 10240
        assert _parse_size("1.5KB") == 1536

    def test_megabytes(self):
        assert _parse_size("1MB") == 1048576
        assert _parse_size("10MB") == 10485760
        assert _parse_size("0.5MB") == 524288

    def test_gigabytes(self):
        assert _parse_size("1GB") == 1073741824
        assert _parse_size("2GB") == 2147483648

    def test_case_insensitive(self):
        assert _parse_size("1mb") == 1048576
        assert _parse_size("1kb") == 1024
        assert _parse_size("1gb") == 1073741824
        assert _parse_size("1Kb") == 1024

    def test_strips_whitespace(self):
        assert _parse_size("  10MB  ") == 10485760

    def test_plain_number_as_string(self):
        assert _parse_size("1024") == 1024
        assert _parse_size("3.14") == 3

    def test_invalid_value_returns_none(self):
        assert _parse_size("invalid") is None
        assert _parse_size("MB") is None
        assert _parse_size("abcMB") is None
        assert _parse_size("1.2.3MB") is None


class TestParseDate:
    """测试日期解析函数"""

    def test_empty_value_returns_none(self):
        assert _parse_date("") is None
        assert _parse_date("   ") is None

    def test_none_value(self):
        assert _parse_date(None) is None

    def test_iso_format(self):
        result = _parse_date("2024-01-15T12:30:00")
        assert result == datetime(2024, 1, 15, 12, 30, 0)

    def test_iso_format_with_timezone(self):
        result = _parse_date("2024-01-15T12:30:00+08:00")
        assert result == datetime(2024, 1, 15, 12, 30, 0,
                                  tzinfo=result.tzinfo)  # fromisoformat preserves tz

    def test_date_only_format(self):
        result = _parse_date("2024-01-15")
        assert result == datetime(2024, 1, 15, 0, 0, 0)

    def test_datetime_format(self):
        result = _parse_date("2024-01-15 14:30:45")
        assert result == datetime(2024, 1, 15, 14, 30, 45)

    def test_strips_whitespace(self):
        result = _parse_date("  2024-01-15  ")
        assert result == datetime(2024, 1, 15, 0, 0, 0)

    def test_is_end_sets_end_of_day(self):
        result = _parse_date("2024-01-15", is_end=True)
        assert result == datetime(2024, 1, 15, 23, 59, 59)

    def test_is_end_no_change_for_datetime(self):
        """含时间的日期不应被 is_end 修改"""
        result = _parse_date("2024-01-15 14:30:45", is_end=True)
        assert result == datetime(2024, 1, 15, 14, 30, 45)

    def test_is_end_iso_with_time(self):
        """含时间的ISO日期不应被 is_end 修改"""
        result = _parse_date("2024-01-15T12:30:00", is_end=True)
        assert result == datetime(2024, 1, 15, 12, 30, 0)

    def test_invalid_date_returns_none(self):
        assert _parse_date("not-a-date") is None
        assert _parse_date("2024/01/15") is None
        assert _parse_date("15-01-2024") is None
        assert _parse_date("2024-13-01") is None
