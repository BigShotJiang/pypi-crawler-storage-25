"""测试访问日志模块"""
import json
import sys
import tempfile
import threading
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
from file_server.core.access_log import AccessLogger


class TestAccessLogger:
    @pytest.fixture
    def tmp_log(self):
        with tempfile.TemporaryDirectory() as td:
            log_path = Path(td) / "access.log"
            yield log_path

    def test_log_writes_json_line(self, tmp_log):
        logger = AccessLogger(tmp_log)
        logger.log("alice", "download", "doc/report.pdf", file_size=1024)
        # Force flush by reading back
        assert tmp_log.exists()
        lines = tmp_log.read_text(encoding="utf-8").strip().split("\n")
        assert len(lines) == 1
        entry = json.loads(lines[0])
        assert entry["username"] == "alice"
        assert entry["action"] == "download"
        assert entry["path"] == "doc/report.pdf"
        assert entry["details"] == {"file_size": 1024}
        assert entry["client_ip"] == "unknown"
        assert "timestamp" in entry

    def test_log_multiple_entries(self, tmp_log):
        logger = AccessLogger(tmp_log)
        logger.log("alice", "download", "a.pdf")
        logger.log("bob", "upload", "b.txt")
        logger.log("carol", "delete", "c.py")
        lines = tmp_log.read_text(encoding="utf-8").strip().split("\n")
        assert len(lines) == 3
        entries = [json.loads(l) for l in lines]
        assert entries[0]["username"] == "alice"
        assert entries[0]["client_ip"] == "unknown"
        assert entries[1]["username"] == "bob"
        assert entries[1]["client_ip"] == "unknown"
        assert entries[2]["username"] == "carol"
        assert entries[2]["client_ip"] == "unknown"

    def test_log_with_client_ip(self, tmp_log):
        logger = AccessLogger(tmp_log)
        logger.log("alice", "download", "file.txt", client_ip="192.168.1.100")
        entry = json.loads(tmp_log.read_text(encoding="utf-8").strip())
        assert entry["client_ip"] == "192.168.1.100"

    def test_log_with_ipv6(self, tmp_log):
        logger = AccessLogger(tmp_log)
        logger.log("alice", "download", "file.txt", client_ip="::1")
        entry = json.loads(tmp_log.read_text(encoding="utf-8").strip())
        assert entry["client_ip"] == "::1"

    def test_log_no_details(self, tmp_log):
        logger = AccessLogger(tmp_log)
        logger.log("alice", "login", "/")
        lines = tmp_log.read_text(encoding="utf-8").strip().split("\n")
        entry = json.loads(lines[0])
        assert "details" not in entry
        assert entry["client_ip"] == "unknown"

    def test_auto_create_file(self, tmp_log):
        assert not tmp_log.exists()
        logger = AccessLogger(tmp_log)
        logger.log("alice", "login", "/")
        assert tmp_log.exists()

    def test_auto_create_parent_dir(self):
        with tempfile.TemporaryDirectory() as td:
            log_path = Path(td) / "subdir" / "access.log"
            logger = AccessLogger(log_path)
            logger.log("alice", "login", "/")
            assert log_path.exists()

    def test_timestamp_format(self, tmp_log):
        logger = AccessLogger(tmp_log)
        logger.log("alice", "download", "file.txt")
        entry = json.loads(tmp_log.read_text(encoding="utf-8").strip())
        # 应该是 ISO 8601 格式
        assert "T" in entry["timestamp"]
        assert "+" in entry["timestamp"] or "Z" in entry["timestamp"]

    def test_thread_safety(self, tmp_log):
        logger = AccessLogger(tmp_log)
        errors = []

        def worker(n):
            for i in range(50):
                try:
                    logger.log(f"user{n}", "download", f"file{n}_{i}.txt")
                except Exception as e:
                    errors.append(e)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0
        lines = tmp_log.read_text(encoding="utf-8").strip().split("\n")
        assert len(lines) == 500

    def test_rotation_by_size(self, tmp_log):
        logger = AccessLogger(tmp_log, max_size_mb=0, keep=2)  # 0MB 立即触发轮转
        logger.log("alice", "download", "file1.txt")
        logger.log("alice", "download", "file2.txt")
        # 第二次写入后应该至少有一个备份
        backup = tmp_log.parent / f"{tmp_log.name}.1"
        assert backup.exists() or tmp_log.exists()

    def test_rotation_keeps_limit(self, tmp_log):
        logger = AccessLogger(tmp_log, max_size_mb=0, keep=2)
        for i in range(5):
            logger.log("alice", "download", f"file{i}.txt")
        # 旧的备份不应超过 keep 数量
        extra_backup = tmp_log.parent / f"{tmp_log.name}.3"
        assert not extra_backup.exists()

    def test_unicode_content(self, tmp_log):
        logger = AccessLogger(tmp_log)
        logger.log("用户", "下载", "文件/报告.pdf")
        entry = json.loads(tmp_log.read_text(encoding="utf-8").strip())
        assert entry["username"] == "用户"
        assert entry["action"] == "下载"
        assert entry["path"] == "文件/报告.pdf"

    def test_special_characters_in_path(self, tmp_log):
        logger = AccessLogger(tmp_log)
        logger.log("alice", "download", "path/with spaces/and&amp;chars.txt")
        entry = json.loads(tmp_log.read_text(encoding="utf-8").strip())
        assert entry["path"] == "path/with spaces/and&amp;chars.txt"

    def test_log_with_details_dict(self, tmp_log):
        logger = AccessLogger(tmp_log)
        logger.log("alice", "rename", "old.txt", new_name="new.txt", old_size=100)
        entry = json.loads(tmp_log.read_text(encoding="utf-8").strip())
        assert entry["details"] == {"new_name": "new.txt", "old_size": 100}
