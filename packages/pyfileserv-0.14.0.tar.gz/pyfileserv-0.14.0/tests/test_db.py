"""数据库模块测试 - PostgreSQL 支持"""
from datetime import datetime
from unittest.mock import patch, MagicMock

import pytest

# 导入时可能没有 psycopg2，所以我们用 patch 来模拟
with patch('file_server.db.POSTGRES_AVAILABLE', True):
    from file_server.db import (
        DatabaseConnection,
        DatabaseUserStore,
        DatabaseAccessLogger,
        CREATE_TABLES_SQL
    )


class TestDatabaseConnectionWithoutPsycopg2:
    """没有 psycopg2 时的测试"""

    def test_init_raises_import_error_without_psycopg2(self):
        """测试没有 psycopg2 时初始化抛出 ImportError"""
        with patch('file_server.db.POSTGRES_AVAILABLE', False):
            with pytest.raises(ImportError, match="psycopg2-binary is required"):
                DatabaseConnection()


class TestDatabaseConnection:
    """DatabaseConnection 测试"""

    @pytest.fixture
    def mock_psycopg2(self):
        """模拟 psycopg2"""
        with patch('file_server.db.psycopg2') as mock:
            # 设置模拟连接
            mock_conn = MagicMock()
            mock_cursor = MagicMock()
            mock_conn.cursor.return_value.__enter__.return_value = mock_cursor
            mock.connect.return_value = mock_conn
            yield mock

    @pytest.fixture
    def db(self, mock_psycopg2):
        """创建 DatabaseConnection 实例"""
        return DatabaseConnection(
            host="testhost",
            port=5433,
            database="testdb",
            username="testuser",
            password="testpass"
        )

    def test_init_stores_parameters(self, mock_psycopg2):
        """测试初始化存储参数"""
        db = DatabaseConnection(
            host="myhost",
            port=5434,
            database="mydb",
            username="myuser",
            password="mypass"
        )

        assert db.host == "myhost"
        assert db.port == 5434
        assert db.database == "mydb"
        assert db.username == "myuser"
        assert db.password == "mypass"

    def test_init_default_parameters(self, mock_psycopg2):
        """测试初始化默认参数"""
        db = DatabaseConnection()

        assert db.host == "localhost"
        assert db.port == 5432
        assert db.database == "pyfileserv"
        assert db.username is None
        assert db.password is None

    def test_connect_creates_connection(self, db, mock_psycopg2):
        """测试连接创建"""
        db.connect()

        mock_psycopg2.connect.assert_called_once_with(
            host="testhost",
            port=5433,
            database="testdb",
            user="testuser",
            password="testpass"
        )

    def test_connect_reuses_existing_connection(self, db, mock_psycopg2):
        """测试连接重用"""
        db.connect()
        db.connect()

        mock_psycopg2.connect.assert_called_once()

    def test_disconnect_closes_connection(self, db, mock_psycopg2):
        """测试断开连接"""
        db.connect()
        conn = db._conn

        db.disconnect()

        conn.close.assert_called_once()
        assert db._conn is None

    def test_disconnect_noop_when_not_connected(self, db):
        """测试未连接时断开连接无操作"""
        db.disconnect()  # 不应抛出异常

    def test_get_connection_connects_if_needed(self, db, mock_psycopg2):
        """测试获取连接时按需连接"""
        conn = db.get_connection()

        mock_psycopg2.connect.assert_called_once()
        assert conn is not None

    def test_initialize_tables_executes_sql(self, db, mock_psycopg2):
        """测试初始化表执行 SQL"""
        mock_cursor = mock_psycopg2.connect.return_value.cursor.return_value.__enter__.return_value

        db.initialize_tables()

        mock_cursor.execute.assert_called_once_with(CREATE_TABLES_SQL)
        mock_psycopg2.connect.return_value.commit.assert_called_once()

    def test_execute_without_fetch(self, db, mock_psycopg2):
        """测试执行查询不获取结果"""
        mock_cursor = mock_psycopg2.connect.return_value.cursor.return_value.__enter__.return_value

        result = db.execute("INSERT INTO users (name) VALUES (%s)", ("test",), fetch=False)

        mock_cursor.execute.assert_called_once_with("INSERT INTO users (name) VALUES (%s)", ("test",))
        mock_psycopg2.connect.return_value.commit.assert_called_once()
        assert result is None

    def test_execute_with_fetch(self, db, mock_psycopg2):
        """测试执行查询获取结果"""
        mock_cursor = mock_psycopg2.connect.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchall.return_value = [
            {"id": 1, "name": "user1"},
            {"id": 2, "name": "user2"}
        ]

        result = db.execute("SELECT * FROM users", fetch=True)

        mock_cursor.execute.assert_called_once_with("SELECT * FROM users", ())
        assert result == [
            {"id": 1, "name": "user1"},
            {"id": 2, "name": "user2"}
        ]

    def test_execute_one_returns_first_result(self, db, mock_psycopg2):
        """测试执行查询返回单条结果"""
        mock_cursor = mock_psycopg2.connect.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchall.return_value = [{"id": 1, "name": "user1"}]

        result = db.execute_one("SELECT * FROM users WHERE id = %s", (1,))

        mock_cursor.execute.assert_called_once_with("SELECT * FROM users WHERE id = %s", (1,))
        assert result == {"id": 1, "name": "user1"}

    def test_execute_one_returns_none_when_no_results(self, db, mock_psycopg2):
        """测试无结果时返回 None"""
        mock_cursor = mock_psycopg2.connect.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchall.return_value = []

        result = db.execute_one("SELECT * FROM users WHERE id = %s", (999,))

        assert result is None


class TestDatabaseUserStore:
    """DatabaseUserStore 测试"""

    @pytest.fixture
    def mock_db(self):
        """模拟数据库连接"""
        mock_db = MagicMock()
        return mock_db

    @pytest.fixture
    def user_store(self, mock_db):
        """创建 DatabaseUserStore 实例"""
        return DatabaseUserStore(mock_db)

    def test_init_stores_db_connection(self, user_store, mock_db):
        """测试初始化存储数据库连接"""
        assert user_store.db == mock_db

    def test_load_users_queries_all_users(self, user_store, mock_db):
        """测试加载用户查询所有用户"""
        created_at = datetime(2024, 1, 1, 12, 0, 0)
        updated_at = datetime(2024, 1, 2, 12, 0, 0)
        mock_db.execute.return_value = [
            {
                "username": "user1",
                "password_hash": "hash1",
                "is_admin": True,
                "created_at": created_at,
                "updated_at": updated_at
            },
            {
                "username": "user2",
                "password_hash": "hash2",
                "is_admin": False,
                "created_at": None,
                "updated_at": None
            }
        ]

        users = user_store.load_users()

        mock_db.execute.assert_called_once_with(
            "SELECT username, password_hash, is_admin, permissions, created_at, updated_at FROM users",
            fetch=True
        )
        assert users == {
            "user1": {
                "password": "hash1",
                "is_admin": True,
                "permissions": {},
                "created_at": "2024-01-01T12:00:00",
                "updated_at": "2024-01-02T12:00:00"
            },
            "user2": {
                "password": "hash2",
                "is_admin": False,
                "permissions": {},
                "created_at": None,
                "updated_at": None
            }
        }

    def test_load_users_handles_empty_result(self, user_store, mock_db):
        """测试加载用户处理空结果"""
        mock_db.execute.return_value = None

        users = user_store.load_users()

        assert users == {}

    def test_get_user_queries_single_user(self, user_store, mock_db):
        """测试获取单个用户"""
        created_at = datetime(2024, 1, 1, 12, 0, 0)
        mock_db.execute_one.return_value = {
            "username": "testuser",
            "password_hash": "testhash",
            "is_admin": True,
            "permissions": None,
            "created_at": created_at,
            "updated_at": None
        }

        user = user_store.get_user("testuser")

        mock_db.execute_one.assert_called_once_with(
            "SELECT username, password_hash, is_admin, permissions, created_at, updated_at FROM users WHERE username = %s",
            ("testuser",)
        )
        assert user == {
            "password": "testhash",
            "is_admin": True,
            "permissions": {},
            "created_at": "2024-01-01T12:00:00",
            "updated_at": None
        }

    def test_get_user_returns_none_when_not_found(self, user_store, mock_db):
        """测试用户不存在时返回 None"""
        mock_db.execute_one.return_value = None

        user = user_store.get_user("nonexistent")

        assert user is None

    def test_user_exists_returns_true_when_user_exists(self, user_store, mock_db):
        """测试用户存在时返回 True"""
        mock_db.execute_one.return_value = {"1": 1}

        exists = user_store.user_exists("existing")

        mock_db.execute_one.assert_called_once_with(
            "SELECT 1 FROM users WHERE username = %s",
            ("existing",)
        )
        assert exists is True

    def test_user_exists_returns_false_when_user_not_found(self, user_store, mock_db):
        """测试用户不存在时返回 False"""
        mock_db.execute_one.return_value = None

        exists = user_store.user_exists("nonexistent")

        assert exists is False

    def test_add_user_inserts_user(self, user_store, mock_db):
        """测试添加用户"""
        user_store.add_user("newuser", "newhash", is_admin=False)

        mock_db.execute.assert_called_once_with(
            "INSERT INTO users (username, password_hash, is_admin, permissions) VALUES (%s, %s, %s, %s)",
            ("newuser", "newhash", False, "{}")
        )

    def test_update_password_updates_password(self, user_store, mock_db):
        """测试更新密码"""
        user_store.update_password("user", "newhash")

        mock_db.execute.assert_called_once_with(
            "UPDATE users SET password_hash = %s, updated_at = CURRENT_TIMESTAMP WHERE username = %s",
            ("newhash", "user")
        )

    def test_delete_user_deletes_user(self, user_store, mock_db):
        """测试删除用户"""
        user_store.delete_user("user")

        mock_db.execute.assert_called_once_with(
            "DELETE FROM users WHERE username = %s",
            ("user",)
        )

    def test_get_permissions_returns_dict(self, user_store, mock_db):
        """测试获取用户权限"""
        mock_db.execute_one.return_value = {
            "username": "testuser",
            "password_hash": "hash",
            "is_admin": False,
            "permissions": {"project-a": "rw", "docs": "r"},
            "created_at": None,
            "updated_at": None,
        }
        perms = user_store.get_permissions("testuser")
        assert perms == {"project-a": "rw", "docs": "r"}

    def test_get_permissions_returns_empty_for_no_perms(self, user_store, mock_db):
        """测试无权限用户返回空字典"""
        mock_db.execute_one.return_value = {
            "username": "testuser",
            "password_hash": "hash",
            "is_admin": False,
            "permissions": None,
            "created_at": None,
            "updated_at": None,
        }
        perms = user_store.get_permissions("testuser")
        assert perms == {}

    def test_set_permissions_updates_user(self, user_store, mock_db):
        """测试设置用户权限"""
        import json
        mock_db.execute_one.return_value = {"1": 1}  # 用户存在
        perms = {"project-a": "rw"}
        result = user_store.set_permissions("testuser", perms)
        assert result is True
        mock_db.execute.assert_called_once_with(
            "UPDATE users SET permissions = %s, updated_at = CURRENT_TIMESTAMP WHERE username = %s",
            (json.dumps(perms, ensure_ascii=False), "testuser")
        )

    def test_set_permissions_user_not_found(self, user_store, mock_db):
        """测试设置不存在用户权限"""
        mock_db.execute_one.return_value = None
        result = user_store.set_permissions("nonexistent", {"a": "rw"})
        assert result is False


class TestDatabaseAccessLogger:
    """DatabaseAccessLogger 测试"""

    @pytest.fixture
    def mock_db(self):
        return MagicMock()

    @pytest.fixture
    def db_logger(self, mock_db):
        return DatabaseAccessLogger(mock_db)

    def test_log_inserts_record(self, db_logger, mock_db):
        """测试写入日志到数据库"""
        import json
        db_logger.log("alice", "download", "doc/report.pdf", file_size=1024)
        mock_db.execute.assert_called_once()
        args = mock_db.execute.call_args[0]
        assert args[0].startswith("INSERT INTO access_logs")
        assert args[1][0] == "alice"
        assert args[1][1] == "download"
        assert args[1][2] == "doc/report.pdf"
        details = json.loads(args[1][3])
        assert details == {"file_size": 1024}
        assert args[1][4] == "unknown"  # default client_ip

    def test_log_without_details(self, db_logger, mock_db):
        """测试无详情写入日志"""
        import json
        db_logger.log("bob", "login", "/")
        args = mock_db.execute.call_args[0]
        assert args[1][0] == "bob"
        assert args[1][1] == "login"
        assert json.loads(args[1][3]) == {}
        assert args[1][4] == "unknown"  # default client_ip

    def test_log_handles_db_error(self, db_logger, mock_db):
        """测试数据库写入异常不抛出"""
        mock_db.execute.side_effect = RuntimeError("DB down")
        # 不应抛出异常
        db_logger.log("alice", "download", "file.txt")

    def test_log_with_client_ip(self, db_logger, mock_db):
        """测试带 client_ip 的日志写入"""
        db_logger.log("alice", "download", "file.txt", client_ip="10.0.0.1")
        args = mock_db.execute.call_args[0]
        assert args[1][4] == "10.0.0.1"

    def test_log_unicode(self, db_logger, mock_db):
        """测试写入中文内容"""
        import json
        db_logger.log("用户", "下载", "文件.txt")
        args = mock_db.execute.call_args[0]
        assert args[1][0] == "用户"
        assert args[1][1] == "下载"
        assert args[1][4] == "unknown"  # default client_ip


class TestCreateTablesSQL:
    """测试建表 SQL 包含所有必要元素"""

    def test_users_table_exists(self):
        assert "CREATE TABLE IF NOT EXISTS users" in CREATE_TABLES_SQL

    def test_shares_table_exists(self):
        assert "CREATE TABLE IF NOT EXISTS shares" in CREATE_TABLES_SQL

    def test_access_logs_table_exists(self):
        assert "CREATE TABLE IF NOT EXISTS access_logs" in CREATE_TABLES_SQL

    def test_access_logs_indexes(self):
        assert "idx_access_logs_timestamp" in CREATE_TABLES_SQL
        assert "idx_access_logs_username" in CREATE_TABLES_SQL
        assert "idx_access_logs_action" in CREATE_TABLES_SQL
        assert "idx_access_logs_client_ip" in CREATE_TABLES_SQL

    def test_client_ip_column_in_access_logs(self):
        assert "client_ip" in CREATE_TABLES_SQL

    def test_client_ip_migration_exists(self):
        assert "ALTER TABLE access_logs ADD COLUMN client_ip" in CREATE_TABLES_SQL

    def test_permissions_column_in_users(self):
        assert "permissions" in CREATE_TABLES_SQL

    def test_permissions_migration(self):
        """测试兼容旧数据库的迁移存在"""
        assert "permissions" in CREATE_TABLES_SQL
        assert "ALTER TABLE users ADD COLUMN permissions" in CREATE_TABLES_SQL
