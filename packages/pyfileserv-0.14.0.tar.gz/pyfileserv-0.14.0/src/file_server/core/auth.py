"""认证模块 - 密码哈希、用户存储、会话管理"""
import json
import logging
import os
import secrets
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Tuple

import bcrypt

logger = logging.getLogger(__name__)


@dataclass
class Session:
    """会话数据"""
    session_id: str
    username: str
    expires: float
    created_at: float

    def to_dict(self) -> dict:
        """转换为字典（用于序列化）"""
        return {
            "session_id": self.session_id,
            "username": self.username,
            "expires": self.expires,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Session":
        """从字典创建（用于反序列化）"""
        return cls(
            session_id=data["session_id"],
            username=data["username"],
            expires=data["expires"],
            created_at=data["created_at"],
        )


class SessionStorage(ABC):
    """会话存储抽象基类"""

    @abstractmethod
    def save(self, session: Session) -> None:
        """保存会话"""
        pass

    @abstractmethod
    def get(self, session_id: str) -> Optional[Session]:
        """获取会话"""
        pass

    @abstractmethod
    def delete(self, session_id: str) -> bool:
        """删除会话"""
        pass

    @abstractmethod
    def exists(self, session_id: str) -> bool:
        """检查会话是否存在"""
        pass


class MemorySessionStorage(SessionStorage):
    """内存会话存储（默认实现）"""

    def __init__(self):
        self._sessions: Dict[str, Session] = {}

    def save(self, session: Session) -> None:
        """保存会话到内存"""
        self._sessions[session.session_id] = session

    def get(self, session_id: str) -> Optional[Session]:
        """从内存获取会话"""
        return self._sessions.get(session_id)

    def delete(self, session_id: str) -> bool:
        """从内存删除会话"""
        if session_id in self._sessions:
            del self._sessions[session_id]
            return True
        return False

    def exists(self, session_id: str) -> bool:
        """检查会话是否在内存中存在"""
        return session_id in self._sessions


class RedisSessionStorage(SessionStorage):
    """Redis 会话存储"""

    def __init__(self, host: str = "localhost", port: int = 6379, 
                 db: int = 0, password: Optional[str] = None,
                 key_prefix: str = "pyfileserv:session:"):
        self.key_prefix = key_prefix
        
        # 延迟导入 redis 模块
        try:
            import redis
            self.redis_client = redis.Redis(
                host=host,
                port=port,
                db=db,
                password=password,
                decode_responses=True,
            )
            # 测试连接
            self.redis_client.ping()
            logger.info(f"Redis 连接成功: {host}:{port}")
        except ImportError:
            raise ImportError("redis 模块未安装。请运行: pip install redis")
        except Exception as e:
            logger.error(f"Redis 连接失败: {e}")
            raise

    def _get_key(self, session_id: str) -> str:
        """生成 Redis 键名"""
        return f"{self.key_prefix}{session_id}"

    def save(self, session: Session, ttl: Optional[int] = None) -> None:
        """保存会话到 Redis
        
        Args:
            session: 会话对象
            ttl: 过期时间（秒），如果为 None 则使用会话的剩余时间
        """
        key = self._get_key(session.session_id)
        data = json.dumps(session.to_dict())
        
        # 计算 TTL
        if ttl is None:
            ttl = max(int(session.expires - time.time()), 1)
        
        self.redis_client.setex(key, ttl, data)

    def get(self, session_id: str) -> Optional[Session]:
        """从 Redis 获取会话"""
        key = self._get_key(session_id)
        data = self.redis_client.get(key)
        
        if data is None:
            return None
        
        try:
            session_data = json.loads(data)
            return Session.from_dict(session_data)
        except (json.JSONDecodeError, KeyError) as e:
            logger.error(f"解析会话数据失败: {e}")
            return None

    def delete(self, session_id: str) -> bool:
        """从 Redis 删除会话"""
        key = self._get_key(session_id)
        return self.redis_client.delete(key) > 0

    def exists(self, session_id: str) -> bool:
        """检查会话是否在 Redis 中存在"""
        key = self._get_key(session_id)
        return self.redis_client.exists(key) > 0


class PasswordHasher:
    """密码哈希工具"""

    def __init__(self, rounds: int = 12):
        self.rounds = rounds

    def hash_password(self, password: str) -> str:
        """使用 bcrypt 加密密码"""
        salt = bcrypt.gensalt(rounds=self.rounds)
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed.decode('utf-8')

    def verify_password(self, password: str, hashed_password: str) -> bool:
        """验证密码"""
        try:
            return bcrypt.checkpw(
                password.encode('utf-8'),
                hashed_password.encode('utf-8')
            )
        except Exception:
            return False


class UserStore:
    """用户存储 - 负责用户数据的读写（带 mtime 缓存减少磁盘 I/O）"""

    def __init__(self, users_file_path: Path):
        self.users_file_path = Path(users_file_path)
        self._cache: Optional[Dict[str, dict]] = None
        self._cache_mtime: float = 0.0

    def load_users(self) -> Dict[str, dict]:
        """加载用户数据（mtime 校验，命中缓存时避免磁盘读取）"""
        if not self.users_file_path.exists():
            self._cache = {}
            self._cache_mtime = 0.0
            return {}
        try:
            mtime = self.users_file_path.stat().st_mtime
        except OSError:
            return self._cache or {}
        if self._cache is not None and mtime == self._cache_mtime:
            return self._cache
        with open(self.users_file_path, 'r', encoding='utf-8') as f:
            self._cache = json.load(f)
        self._cache_mtime = mtime
        return self._cache

    def save_users(self, users: Dict[str, dict]) -> None:
        """保存用户数据并更新缓存"""
        self.users_file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.users_file_path, 'w', encoding='utf-8') as f:
            json.dump(users, f, indent=2, ensure_ascii=False)
        # 更新内存缓存，刷新 mtime
        self._cache = users
        self._cache_mtime = self.users_file_path.stat().st_mtime
        # 设置文件权限为仅所有者可读写 (防止其他用户读取密码哈希)
        try:
            os.chmod(self.users_file_path, 0o600)
        except OSError:
            pass  # Windows 或权限不足时忽略

    def user_exists(self, username: str) -> bool:
        """检查用户是否存在"""
        return username in self.load_users()

    def get_user(self, username: str) -> Optional[dict]:
        """获取用户数据"""
        users = self.load_users()
        return users.get(username)

    def add_user(self, username: str, password_hash: str, is_admin: bool = False,
                 permissions: dict = None) -> None:
        """添加用户

        Args:
            username: 用户名
            password_hash: 密码哈希
            is_admin: 是否为管理员，默认 False
            permissions: 权限字典，如 {"dir1": "rw", "dir2": "r"}，None 使用空字典
        """
        users = self.load_users()
        users[username] = {
            "password": password_hash,
            "created_at": str(time.time()),
            "is_admin": is_admin,
            "permissions": permissions or {}
        }
        self.save_users(users)

    def update_password(self, username: str, password_hash: str) -> None:
        """更新密码"""
        users = self.load_users()
        if username in users:
            users[username]["password"] = password_hash
            self.save_users(users)

    def delete_user(self, username: str) -> bool:
        """删除用户"""
        users = self.load_users()
        if username in users:
            del users[username]
            self.save_users(users)
            return True
        return False

    def set_admin_status(self, username: str, is_admin: bool) -> bool:
        """设置用户管理员状态
        
        Args:
            username: 用户名
            is_admin: 是否为管理员
            
        Returns:
            是否成功
        """
        users = self.load_users()
        if username in users:
            users[username]["is_admin"] = is_admin
            self.save_users(users)
            return True
        return False

    def is_admin(self, username: str) -> bool:
        """检查用户是否为管理员

        Args:
            username: 用户名

        Returns:
            是否为管理员
        """
        user_data = self.get_user(username)
        if user_data:
            return user_data.get("is_admin", False)
        return False

    def get_permissions(self, username: str) -> Optional[dict]:
        """获取用户的权限配置

        Args:
            username: 用户名

        Returns:
            权限字典，如 {"dir1": "rw"}，用户不存在返回 None
        """
        user_data = self.get_user(username)
        if user_data:
            return user_data.get("permissions", {})
        return None

    def set_permissions(self, username: str, permissions: dict) -> bool:
        """设置用户的权限配置

        Args:
            username: 用户名
            permissions: 权限字典，如 {"dir1": "rw", "dir2": "r"}

        Returns:
            是否成功
        """
        users = self.load_users()
        if username in users:
            users[username]["permissions"] = permissions
            self.save_users(users)
            return True
        return False


class SessionManager:
    """会话管理器"""

    def __init__(self, timeout_seconds: int = 3600, storage: Optional[SessionStorage] = None):
        self.timeout = timeout_seconds
        # 如果没有提供存储，默认使用内存存储
        self.storage = storage if storage is not None else MemorySessionStorage()

    def create_session(self, username: str) -> str:
        """创建新会话，返回 session_id"""
        session_id = secrets.token_hex(32)
        now = time.time()
        session = Session(
            session_id=session_id,
            username=username,
            expires=now + self.timeout,
            created_at=now
        )
        self.storage.save(session)
        return session_id

    def validate_session(self, session_id: str) -> Tuple[bool, Optional[str]]:
        """验证会话，返回 (是否有效, 用户名)"""
        if not session_id:
            return False, None

        session = self.storage.get(session_id)
        if session is None:
            return False, None

        if time.time() > session.expires:
            self.storage.delete(session_id)
            return False, None

        # 滑动窗口续期：仅在剩余时间 < 25% 时刷新过期时间
        remaining = session.expires - time.time()
        if remaining < self.timeout * 0.25:
            session.expires = time.time() + self.timeout
            self.storage.save(session)
        return True, session.username

    def get_username(self, session_id: str) -> Optional[str]:
        """获取会话对应的用户名"""
        valid, username = self.validate_session(session_id)
        return username if valid else None

    def destroy_session(self, session_id: str) -> Optional[str]:
        """销毁会话，返回被销毁会话的用户名"""
        session = self.storage.get(session_id)
        if session:
            self.storage.delete(session_id)
            return session.username
        return None


class LoginAttemptTracker:
    """登录尝试跟踪器 - 防止暴力破解"""

    MAX_ENTRIES = 10000  # 最大记录用户数，防止内存无限增长

    def __init__(self, max_attempts: int = 5, lockout_duration: int = 900):
        """
        初始化登录尝试跟踪器

        Args:
            max_attempts: 最大失败尝试次数，默认 5 次
            lockout_duration: 锁定时长（秒），默认 15 分钟 (900秒)
        """
        self.max_attempts = max_attempts
        self.lockout_duration = lockout_duration
        self._attempts: Dict[str, list] = {}  # username -> [timestamps]

    def _evict_lru(self) -> None:
        """当条目数超过上限时，驱逐最久未活动的记录"""
        if len(self._attempts) <= self.MAX_ENTRIES:
            return
        # 按最近活动时间排序，驱逐最旧的超出部分
        sorted_entries = sorted(
            self._attempts.items(),
            key=lambda item: max(item[1], default=0)
        )
        for username, _ in sorted_entries[:len(self._attempts) - self.MAX_ENTRIES]:
            del self._attempts[username]

    def record_attempt(self, username: str, success: bool) -> None:
        """
        记录登录尝试

        Args:
            username: 用户名
            success: 是否成功
        """
        now = time.time()

        if username not in self._attempts:
            self._attempts[username] = []
            self._evict_lru()

        # 清理过期的尝试记录
        self._cleanup_old_attempts(username, now)

        # 清理后可能删除了记录，需要重新确保存在
        if username not in self._attempts:
            self._attempts[username] = []

        if not success:
            # 记录失败尝试
            self._attempts[username].append(now)
            logger.warning(f"登录失败记录 - 用户: {username}, "
                          f"失败次数: {len(self._attempts[username])}")
        else:
            # 登录成功，清除失败记录
            if username in self._attempts:
                del self._attempts[username]
                logger.info(f"登录成功，清除失败记录 - 用户: {username}")

    def is_locked(self, username: str) -> Tuple[bool, int]:
        """
        检查用户是否被锁定

        Args:
            username: 用户名

        Returns:
            (是否锁定, 剩余锁定时间秒数)
        """
        if username not in self._attempts:
            return False, 0

        now = time.time()
        self._cleanup_old_attempts(username, now)

        attempts = self._attempts.get(username, [])

        if len(attempts) >= self.max_attempts:
            # 计算锁定时间（从第一次失败开始）
            first_attempt = attempts[0]
            lockout_end = first_attempt + self.lockout_duration
            remaining = int(lockout_end - now)

            if remaining > 0:
                logger.warning(f"账户已锁定 - 用户: {username}, "
                              f"剩余时间: {remaining}秒")
                return True, remaining
            else:
                # 锁定已过期，清除记录
                del self._attempts[username]
                return False, 0

        return False, 0

    def get_remaining_attempts(self, username: str) -> int:
        """
        获取剩余尝试次数

        Args:
            username: 用户名

        Returns:
            剩余尝试次数
        """
        if username not in self._attempts:
            return self.max_attempts

        now = time.time()
        self._cleanup_old_attempts(username, now)

        attempts = self._attempts.get(username, [])
        remaining = self.max_attempts - len(attempts)
        return max(0, remaining)

    def _cleanup_old_attempts(self, username: str, now: float) -> None:
        """
        清理过期的尝试记录（超过锁定时长的记录）

        Args:
            username: 用户名
            now: 当前时间戳
        """
        if username not in self._attempts:
            return

        cutoff = now - self.lockout_duration
        self._attempts[username] = [
            ts for ts in self._attempts[username] if ts > cutoff
        ]

        # 如果清空了，删除该用户的记录
        if not self._attempts[username]:
            del self._attempts[username]

    def reset(self, username: str) -> None:
        """
        重置用户的登录尝试记录

        Args:
            username: 用户名
        """
        if username in self._attempts:
            del self._attempts[username]
            logger.info(f"重置登录尝试记录 - 用户: {username}")


class Authenticator:
    """认证器 - 整合密码验证和会话管理"""

    def __init__(self, user_store: UserStore, hasher: PasswordHasher,
                 session_manager: SessionManager,
                 login_tracker: Optional[LoginAttemptTracker] = None):
        self.user_store = user_store
        self.hasher = hasher
        self.session_manager = session_manager
        # 如果没有提供跟踪器，创建默认的（5次失败，锁定15分钟）
        self.login_tracker = login_tracker if login_tracker is not None else LoginAttemptTracker()

    def authenticate(self, username: str, password: str) -> Tuple[bool, Optional[str]]:
        """
        验证用户凭据

        返回: (是否成功, 失败原因或session_id)
        """
        # 检查账户是否被锁定
        locked, remaining_time = self.login_tracker.is_locked(username)
        if locked:
            minutes = remaining_time // 60
            seconds = remaining_time % 60
            error_msg = f"账户已锁定，请在 {minutes}分{seconds}秒 后重试"
            logger.warning(f"登录被拒绝 - 账户锁定: {username}, 剩余时间: {remaining_time}秒")
            return False, error_msg

        # 验证用户和密码
        user_data = self.user_store.get_user(username)
        if not user_data:
            # 即使用户不存在，也记录尝试（防止枚举用户）
            self.login_tracker.record_attempt(username, False)
            logger.warning(f"登录失败 - 用户不存在: {username}")
            return False, "用户不存在或密码错误"

        stored_hash = user_data['password']
        if not self.hasher.verify_password(password, stored_hash):
            # 记录失败尝试
            self.login_tracker.record_attempt(username, False)
            
            # 获取剩余尝试次数
            remaining = self.login_tracker.get_remaining_attempts(username)
            
            if remaining == 0:
                error_msg = f"密码错误次数过多，账户已锁定 15 分钟"
            else:
                error_msg = f"用户不存在或密码错误（还剩 {remaining} 次尝试机会）"
            
            logger.warning(f"登录失败 - 密码错误: {username}, 剩余尝试: {remaining}")
            return False, error_msg

        # 登录成功，记录成功尝试（会清除失败记录）
        self.login_tracker.record_attempt(username, True)
        
        session_id = self.session_manager.create_session(username)
        logger.info(f"登录成功 - 用户: {username}")
        return True, session_id
