"""权限控制模块 - 细粒度目录级权限检查"""
import logging
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)

# 权限常量
PERM_READ = "r"
PERM_READWRITE = "rw"


def _normalize_path(path: str) -> str:
    """规范化路径用于前缀匹配

    - 统一使用正斜杠
    - 移除前导/尾部斜杠
    - 空路径（根目录）返回空字符串
    """
    if not path or path == '.':
        return ''
    return path.replace('\\', '/').strip('/')


def _is_path_under(parent: str, child: str) -> bool:
    """检查 child 路径是否在 parent 路径下（或等于）"""
    parent = _normalize_path(parent)
    child = _normalize_path(child)
    if parent == '':
        return True  # 根目录包含所有路径
    if child == '':
        return False  # 根路径不在任何子目录下
    # child 必须以 parent/ 开头，或完全等于 parent
    return child == parent or child.startswith(parent + '/')


def check_permission(user_data: Optional[dict], path: str, required: str,
                     default_permission: str = PERM_READWRITE) -> bool:
    """检查用户是否有指定路径的访问权限

    使用最长前缀匹配（longest-prefix match）策略：
    从用户的 permissions 字典中找到最匹配 path 的条目。

    管理员始终拥有所有权限。

    Args:
        user_data: 用户数据字典（来自 UserStore.get_user()），None 表示无权限
        path: 要检查的相对路径
        required: 所需权限级别，PERM_READ ("r") 或 PERM_READWRITE ("rw")
        default_permission: 当用户无匹配条目时的默认权限

    Returns:
        是否拥有所需权限
    """
    if user_data is None:
        return False

    # 管理员拥有所有权限
    if user_data.get('is_admin', False):
        return True

    permissions = user_data.get('permissions', {})
    if not permissions:
        # 无权限配置时使用默认权限
        return _has_sufficient(default_permission, required)

    # 特殊处理：空路径（根目录列表）只要求读权限
    norm_path = _normalize_path(path)

    # 最长前缀匹配
    best_match = None
    best_len = -1

    for perm_path, perm_value in permissions.items():
        perm_norm = _normalize_path(perm_path)
        # 通配符 * 匹配所有路径（但优先级最低）
        if perm_norm == '*':
            if best_len < 0:
                best_match = perm_value
                best_len = 0
            continue
        if _is_path_under(perm_norm, norm_path):
            match_len = len(perm_norm)
            if match_len > best_len:
                best_match = perm_value
                best_len = match_len

    if best_match is None:
        # 检查通配符匹配
        for perm_path, perm_value in permissions.items():
            if _normalize_path(perm_path) == '*':
                best_match = perm_value
                break
        if best_match is None:
            return _has_sufficient(default_permission, required)

    return _has_sufficient(best_match, required)


def _has_sufficient(granted: str, required: str) -> bool:
    """检查授予的权限是否满足所需权限

    "rw" 满足 "r" 和 "rw"；"r" 只满足 "r"
    """
    if required == PERM_READ:
        return granted in (PERM_READ, PERM_READWRITE)
    if required == PERM_READWRITE:
        return granted == PERM_READWRITE
    return False


def get_accessible_directories(user_data: Optional[dict], base_dir: Path,
                               all_dirs: list) -> list:
    """从目录列表中筛选用户可读的目录

    Args:
        user_data: 用户数据
        base_dir: 服务根目录
        all_dirs: 所有可用目录的列表（相对路径字符串列表）

    Returns:
        用户可读的目录列表
    """
    if user_data is None:
        return []
    if user_data.get('is_admin', False):
        return all_dirs
    return [d for d in all_dirs if check_permission(user_data, d, PERM_READ)]
