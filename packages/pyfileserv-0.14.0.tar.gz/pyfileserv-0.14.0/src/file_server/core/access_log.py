"""访问日志模块 - 记录文件操作审计日志

写入 JSON 行格式的访问日志，支持基于文件大小的自动轮转。
"""
import json
import logging
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class AccessLogger:
    """访问日志记录器

    将操作记录以 JSON 行格式写入日志文件，线程安全。
    支持按文件大小自动轮转（达到 max_size_mb 时轮转，保留 keep 个旧文件）。
    """

    def __init__(self, log_path: Path, max_size_mb: int = 10, keep: int = 7):
        """
        Args:
            log_path: 日志文件路径
            max_size_mb: 超过此大小（MB）后自动轮转
            keep: 保留的旧日志文件数量
        """
        self._log_path = log_path
        self._max_size = max_size_mb * 1024 * 1024
        self._keep = keep
        self._lock = threading.Lock()

        # 确保日志目录存在
        log_path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, username: str, action: str, path: str, client_ip: str = "unknown", **details) -> None:
        """记录一条访问日志

        Args:
            username: 操作用户
            action: 操作类型 (download/upload/delete/rename/move/copy/mkdir/preview/login/logout)
            path: 文件/目录路径（相对路径）
            client_ip: 操作者 IP 地址
            **details: 额外信息（如 file_size, dest_path, old_name 等）
        """
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "username": username,
            "action": action,
            "path": path,
            "client_ip": client_ip,
        }
        if details:
            entry["details"] = details

        line = json.dumps(entry, ensure_ascii=False) + "\n"

        with self._lock:
            try:
                # 文件不存在则自动创建
                if not self._log_path.exists():
                    self._log_path.touch()
                # 检查是否需要轮转
                self._rotate_if_needed()
                with open(self._log_path, 'a', encoding='utf-8') as f:
                    f.write(line)
            except Exception as e:
                logger.error(f"写入访问日志失败: {e}")

    def _rotate_if_needed(self) -> None:
        """检查并执行日志轮转"""
        if not self._log_path.exists():
            return
        try:
            size = self._log_path.stat().st_size
            if size >= self._max_size:
                self._rotate()
        except OSError:
            pass

    def _rotate(self) -> None:
        """执行日志轮转"""
        # 删除最旧的日志文件（如果有太多备份）
        for i in range(self._keep, 0, -1):
            old_path = self._log_path.parent / f"{self._log_path.name}.{i}"
            if i >= self._keep:
                try:
                    old_path.unlink()
                except OSError:
                    pass
            else:
                src = self._log_path.parent / f"{self._log_path.name}.{i}"
                dst = self._log_path.parent / f"{self._log_path.name}.{i + 1}"
                try:
                    if src.exists():
                        src.rename(dst)
                except OSError:
                    pass

        # 重命名当前日志文件
        backup = self._log_path.parent / f"{self._log_path.name}.1"
        try:
            self._log_path.rename(backup)
        except OSError:
            pass
