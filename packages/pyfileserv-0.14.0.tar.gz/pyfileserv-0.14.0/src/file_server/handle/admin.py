"""管理员页面和API处理"""
import json
import logging
from datetime import datetime

from ..config import MIN_PASSWORD_LENGTH
from ..core.auth import PasswordHasher, UserStore
from ..template.admin import render_admin_page

logger = logging.getLogger(__name__)


def _format_created_at(created_at: str) -> str:
    """将时间戳字符串转换为可读日期格式"""
    try:
        if created_at and created_at.replace('.', '').isdigit():
            dt = datetime.fromtimestamp(float(created_at))
            return dt.strftime('%Y-%m-%d %H:%M:%S')
        return created_at
    except (ValueError, OSError):
        return '未知'


class AdminHandler:
    """管理员处理器 - 处理用户管理、权限管理、访问日志查看相关请求"""

    def __init__(self, user_store: UserStore, access_logger=None, db=None,
                 serve_dir=None, default_permission="rw"):
        self.user_store = user_store
        self.hasher = PasswordHasher()
        self.access_logger = access_logger
        self.db = db
        self.serve_dir = serve_dir
        self.default_permission = default_permission

    def handle_admin_page(self, handler) -> None:
        """处理管理员页面GET请求
        
        Args:
            handler: HTTP请求处理器实例
        """
        username = handler.get_current_username() or 'Unknown'
        
        # 检查是否为管理员
        if not self.user_store.is_admin(username):
            logger.warning(f"非管理员尝试访问管理页面: {username}")
            handler.send_error(403, "Forbidden - Admin access required")
            return
        
        # 获取所有用户列表
        users_data = self.user_store.load_users()
        users_list = []
        
        for uname, udata in users_data.items():
            created_at = udata.get('created_at', '')
            is_admin = udata.get('is_admin', False)

            users_list.append({
                'username': uname,
                'created_at': _format_created_at(created_at),
                'is_admin': is_admin
            })
        
        # 按用户名排序
        users_list.sort(key=lambda x: x['username'])
        
        html = render_admin_page(username, users_list)
        handler._send_html_response(html)

    def handle_get_users(self, handler) -> None:
        """处理获取用户列表API请求（GET /api/admin/users）
        
        Args:
            handler: HTTP请求处理器实例
        """
        users_data = self.user_store.load_users()
        users_list = []
        
        for uname, udata in users_data.items():
            created_at = udata.get('created_at', '')

            users_list.append({
                'username': uname,
                'created_at': _format_created_at(created_at)
            })

        users_list.sort(key=lambda x: x['username'])
        handler._send_json_response({'success': True, 'users': users_list})

    def handle_create_user(self, handler) -> None:
        """处理创建用户API请求（POST /api/admin/users）
        
        Args:
            handler: HTTP请求处理器实例
        """
        # 检查是否为管理员
        username = handler.get_current_username() or 'Unknown'
        if not self.user_store.is_admin(username):
            logger.warning(f"非管理员尝试创建用户: {username}")
            handler._send_error_response('需要管理员权限', 403)
            return
        
        try:
            content_length = int(handler.headers.get('Content-Length', 0))
            body = handler.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))
            
            new_username = data.get('username', '').strip()
            password = data.get('password', '')
            is_admin = data.get('is_admin', False)
            
            # 验证参数
            if not new_username:
                handler._send_error_response('用户名不能为空')
                return
            
            if len(password) < MIN_PASSWORD_LENGTH:
                handler._send_error_response(f'密码长度至少为{MIN_PASSWORD_LENGTH}位')
                return
            
            # 检查用户是否已存在
            if self.user_store.user_exists(new_username):
                handler._send_error_response(f'用户 {new_username} 已存在')
                return
            
            # 创建用户
            password_hash = self.hasher.hash_password(password)
            self.user_store.add_user(new_username, password_hash, is_admin)
            
            logger.info(f"管理员创建用户: {new_username}, is_admin={is_admin}")
            handler._send_json_response({'success': True, 'message': '用户创建成功'})
            
        except json.JSONDecodeError:
            handler._send_error_response('无效的JSON数据')
        except Exception as e:
            logger.error(f"创建用户失败: {e}")
            handler._send_error_response('创建用户失败，请稍后重试')

    def handle_delete_user(self, handler, username: str) -> None:
        """处理删除用户API请求（DELETE /api/admin/users/{username}）
        
        Args:
            handler: HTTP请求处理器实例
            username: 要删除的用户名
        """
        # 检查是否为管理员
        current_user = handler.get_current_username() or 'Unknown'
        if not self.user_store.is_admin(current_user):
            logger.warning(f"非管理员尝试删除用户: {current_user}")
            handler._send_error_response('需要管理员权限', 403)
            return
        
        try:
            # 检查用户是否存在
            if not self.user_store.user_exists(username):
                handler._send_error_response(f'用户 {username} 不存在')
                return
            
            # 删除用户
            success = self.user_store.delete_user(username)
            
            if success:
                logger.info(f"管理员删除用户: {username}")
                handler._send_json_response({'success': True, 'message': '用户删除成功'})
            else:
                handler._send_error_response('删除失败')
                
        except Exception as e:
            logger.error(f"删除用户失败: {e}")
            handler._send_error_response('删除用户失败，请稍后重试')

    def handle_change_password(self, handler, username: str) -> None:
        """处理修改密码API请求（PUT /api/admin/users/{username}/password）
        
        Args:
            handler: HTTP请求处理器实例
            username: 要修改密码的用户名
        """
        # 检查是否为管理员
        current_user = handler.get_current_username() or 'Unknown'
        if not self.user_store.is_admin(current_user):
            logger.warning(f"非管理员尝试修改密码: {current_user}")
            handler._send_error_response('需要管理员权限', 403)
            return
        
        try:
            content_length = int(handler.headers.get('Content-Length', 0))
            body = handler.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))
            
            new_password = data.get('new_password', '')
            
            # 验证参数
            if len(new_password) < MIN_PASSWORD_LENGTH:
                handler._send_error_response(f'密码长度至少为{MIN_PASSWORD_LENGTH}位')
                return
            
            # 检查用户是否存在
            if not self.user_store.user_exists(username):
                handler._send_error_response(f'用户 {username} 不存在')
                return
            
            # 更新密码
            password_hash = self.hasher.hash_password(new_password)
            self.user_store.update_password(username, password_hash)
            
            logger.info(f"管理员修改用户密码: {username}")
            handler._send_json_response({'success': True, 'message': '密码修改成功'})
            
        except json.JSONDecodeError:
            handler._send_error_response('无效的JSON数据')
        except Exception as e:
            logger.error(f"修改密码失败: {e}")
            handler._send_error_response('修改密码失败，请稍后重试')

    # ── 权限管理 ──

    def handle_permission_page(self, handler) -> None:
        """处理权限管理页面"""
        username = handler.get_current_username() or 'Unknown'
        if not self.user_store.is_admin(username):
            handler.send_error(403, "Forbidden")
            return

        from ..template.permission_admin import render_permission_admin_page
        users_data = self.user_store.load_users()
        users_list = []
        for uname, udata in users_data.items():
            users_list.append({
                'username': uname,
                'permissions': udata.get('permissions', {}),
                'is_admin': udata.get('is_admin', False),
                'created_at': udata.get('created_at', ''),
            })
        users_list.sort(key=lambda x: (not x['is_admin'], x['username']))

        # 收集所有可用目录：已配置的权限目录 + serve_dir 下的子目录
        all_dirs = set()
        for u in users_list:
            for p in u['permissions']:
                if p != '*':
                    all_dirs.add(p)
        # 扫描文件服务目录下的子目录
        if self.serve_dir and self.serve_dir.exists():
            try:
                for entry in self.serve_dir.iterdir():
                    if entry.is_dir() and not entry.name.startswith('.'):
                        all_dirs.add(entry.name)
            except OSError:
                pass

        html = render_permission_admin_page(
            username, users_list, sorted(all_dirs),
            default_permission=self.default_permission
        )
        handler._send_html_response(html)

    def handle_permission_api(self, handler, method: str) -> None:
        """处理权限管理 API"""
        username = handler.get_current_username() or 'Unknown'
        if not self.user_store.is_admin(username):
            handler._send_error_response('需要管理员权限', 403)
            return

        if method == 'GET':
            self._handle_get_permissions(handler)
        elif method == 'POST':
            self._handle_set_permission(handler)
        elif method == 'DELETE':
            self._handle_remove_permission(handler)

    def _handle_get_permissions(self, handler) -> None:
        users_data = self.user_store.load_users()
        users_list = []
        for uname, udata in users_data.items():
            users_list.append({
                'username': uname,
                'permissions': udata.get('permissions', {}),
                'is_admin': udata.get('is_admin', False),
            })
        users_list.sort(key=lambda x: (not x['is_admin'], x['username']))
        handler._send_json_response({'success': True, 'users': users_list})

    def _handle_set_permission(self, handler) -> None:
        try:
            content_length = int(handler.headers.get('Content-Length', 0))
            body = handler.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))
            target_user = data.get('username', '').strip()
            perm_dir = data.get('directory', '').strip()
            perm_value = data.get('permission', 'r').strip()

            if not target_user or not perm_dir:
                handler._send_error_response('用户名和目录不能为空')
                return
            if perm_value not in ('r', 'rw'):
                handler._send_error_response('权限值必须为 r 或 rw')
                return

            current_perms = self.user_store.get_permissions(target_user)
            if current_perms is None:
                handler._send_error_response(f'用户 {target_user} 不存在')
                return

            current_perms[perm_dir] = perm_value
            self.user_store.set_permissions(target_user, current_perms)
            logger.info(f"管理员设置权限: 用户={target_user}, 目录={perm_dir}, 权限={perm_value}")
            handler._send_json_response({'success': True})
        except Exception as e:
            logger.error(f"设置权限失败: {e}")
            handler._send_error_response('设置权限失败')

    def _handle_remove_permission(self, handler) -> None:
        try:
            content_length = int(handler.headers.get('Content-Length', 0))
            body = handler.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))
            target_user = data.get('username', '').strip()
            perm_dir = data.get('directory', '').strip()

            if not target_user or not perm_dir:
                handler._send_error_response('用户名和目录不能为空')
                return

            current_perms = self.user_store.get_permissions(target_user)
            if current_perms is None:
                handler._send_error_response(f'用户 {target_user} 不存在')
                return

            if perm_dir in current_perms:
                del current_perms[perm_dir]
                self.user_store.set_permissions(target_user, current_perms)
                logger.info(f"管理员移除权限: 用户={target_user}, 目录={perm_dir}")
            handler._send_json_response({'success': True})
        except Exception as e:
            logger.error(f"移除权限失败: {e}")
            handler._send_error_response('移除权限失败')

    # ── 访问日志查看 ──

    def handle_access_log_page(self, handler) -> None:
        """处理访问日志查看页面"""
        username = handler.get_current_username() or 'Unknown'
        if not self.user_store.is_admin(username):
            handler.send_error(403, "Forbidden")
            return

        from ..template.access_log_viewer import render_access_log_page
        is_db = self.db is not None

        # 收集可选的用户名和文件路径（用于下拉选择）
        users_data = self.user_store.load_users()
        usernames = sorted(users_data.keys())
        known_paths = self._collect_known_paths()

        html = render_access_log_page(username, is_db, usernames, known_paths)
        handler._send_html_response(html)

    def _collect_known_paths(self) -> list:
        """从现有日志和文件系统收集已知的文件路径"""
        paths = set()
        # 从已有日志收集
        try:
            if self.db:
                rows = self.db.execute(
                    "SELECT DISTINCT path FROM access_logs WHERE path IS NOT NULL AND path != '' ORDER BY path",
                    fetch=True
                )
                for row in rows or []:
                    paths.add(row['path'])
            elif self.access_logger:
                log_path = self.access_logger._log_path
                if log_path.exists():
                    import json as _json
                    with open(log_path, 'r', encoding='utf-8') as f:
                        for line in f:
                            line = line.strip()
                            if not line:
                                continue
                            try:
                                entry = _json.loads(line)
                                p = entry.get('path', '')
                                if p:
                                    paths.add(p)
                            except _json.JSONDecodeError:
                                continue
        except Exception:
            pass
        # 从文件系统收集
        if self.serve_dir and self.serve_dir.exists():
            try:
                for entry in self.serve_dir.iterdir():
                    if not entry.name.startswith('.'):
                        paths.add(entry.name)
                        if entry.is_dir():
                            for sub in entry.rglob('*'):
                                if not sub.name.startswith('.'):
                                    rel = str(sub.relative_to(self.serve_dir)).replace('\\', '/')
                                    paths.add(rel)
            except OSError:
                pass
        return sorted(paths)

    def handle_access_log_api(self, handler) -> None:
        """处理访问日志查询 API"""
        username = handler.get_current_username() or 'Unknown'
        if not self.user_store.is_admin(username):
            handler._send_error_response('需要管理员权限', 403)
            return

        import urllib.parse
        parsed = urllib.parse.urlparse(handler.path)
        params = urllib.parse.parse_qs(parsed.query)

        search_username = params.get('username', [''])[0].strip()
        search_action = params.get('action', [''])[0].strip()
        search_path = params.get('path', [''])[0].strip()
        search_detail = params.get('detail', [''])[0].strip()
        search_ip = params.get('ip', [''])[0].strip()
        try:
            page = int(params.get('page', ['1'])[0])
        except ValueError:
            page = 1
        try:
            per_page = int(params.get('per_page', ['20'])[0])
        except ValueError:
            per_page = 20
        per_page = min(per_page, 100)

        if self.db is not None:
            result = self._query_logs_db(search_username, search_action, search_path,
                                         search_detail, search_ip, page, per_page)
        elif self.access_logger is not None:
            result = self._query_logs_file(search_username, search_action, search_path,
                                           search_detail, search_ip, page, per_page)
        else:
            handler._send_json_response({'success': True, 'entries': [], 'total': 0, 'page': 1, 'per_page': per_page, 'total_pages': 0})
            return

        handler._send_json_response({'success': True, **result})

    def _query_logs_db(self, username: str, action: str, path: str,
                       detail: str, ip: str, page: int, per_page: int) -> dict:
        """从数据库查询访问日志"""
        conditions = []
        params_list = []
        if username:
            conditions.append("username = %s")
            params_list.append(username)
        if action:
            conditions.append("action = %s")
            params_list.append(action)
        if path:
            conditions.append("path ILIKE %s")
            params_list.append(f"%{path}%")
        if detail:
            conditions.append("details::text ILIKE %s")
            params_list.append(f"%{detail}%")
        if ip:
            conditions.append("client_ip ILIKE %s")
            params_list.append(f"%{ip}%")

        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        count_sql = f"SELECT COUNT(*) as cnt FROM access_logs {where}"
        total_row = self.db.execute_one(count_sql, tuple(params_list))
        total = total_row['cnt'] if total_row else 0

        offset = (page - 1) * per_page
        data_sql = f"SELECT timestamp, username, action, path, details, client_ip FROM access_logs {where} ORDER BY timestamp DESC LIMIT %s OFFSET %s"
        rows = self.db.execute(data_sql, tuple(params_list + [per_page, offset]), fetch=True)

        entries = []
        for row in rows or []:
            entries.append({
                'timestamp': row['timestamp'].isoformat() if row['timestamp'] else '',
                'username': row['username'],
                'action': row['action'],
                'path': row['path'],
                'details': row.get('details') or {},
                'client_ip': row.get('client_ip', 'unknown'),
            })

        total_pages = max(1, (total + per_page - 1) // per_page)
        return {'entries': entries, 'total': total, 'page': page, 'per_page': per_page, 'total_pages': total_pages}

    def _query_logs_file(self, username: str, action: str, path: str,
                         detail: str, ip: str, page: int, per_page: int) -> dict:
        """从文件查询访问日志"""
        import json as _json
        log_path = self.access_logger._log_path
        entries = []
        try:
            if log_path.exists():
                with open(log_path, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            entry = _json.loads(line)
                            # 过滤
                            if username and entry.get('username', '') != username:
                                continue
                            if action and entry.get('action', '') != action:
                                continue
                            if path and path.lower() not in entry.get('path', '').lower():
                                continue
                            # 详情模糊搜索
                            if detail:
                                details = entry.get('details')
                                if details:
                                    details_str = _json.dumps(details, ensure_ascii=False).lower()
                                    if detail.lower() not in details_str:
                                        continue
                                else:
                                    continue
                            if ip and ip.lower() not in entry.get('client_ip', '').lower():
                                continue
                            entries.append(entry)
                        except _json.JSONDecodeError:
                            continue
        except OSError:
            pass

        # 按时间倒序
        entries.sort(key=lambda e: e.get('timestamp', ''), reverse=True)
        total = len(entries)
        total_pages = max(1, (total + per_page - 1) // per_page)
        start = (page - 1) * per_page
        paged = entries[start:start + per_page]

        return {'entries': paged, 'total': total, 'page': page, 'per_page': per_page, 'total_pages': total_pages}
