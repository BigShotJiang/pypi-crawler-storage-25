"""文件操作功能 Mixin"""
import json
import logging
import mimetypes
import os
import shutil
import ssl
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime
from importlib.metadata import version
from pathlib import Path
from typing import Optional

from jinja2 import Template

from ..core.permission import check_permission, PERM_READ, PERM_READWRITE
from .utils import (
    detect_file_type, _is_safe_path, _parse_multipart, _sanitize_filename, _resolve_safe_path,
)

logger = logging.getLogger(__name__)




class EDDXToHTMLConverter:
    """Enterprise Architect .eddx 文件转换为 HTML"""

    def __init__(self):
        self.template = Template('''
        <!DOCTYPE html>
        <html lang="zh-CN">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>{{ title }}</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    padding: 20px;
                    color: #333;
                }
                .container {
                    max-width: 1400px;
                    margin: 0 auto;
                    background: white;
                    border-radius: 15px;
                    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                    overflow: hidden;
                }
                .header {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    padding: 40px;
                    text-align: center;
                }
                .header h1 {
                    font-size: 2.5em;
                    margin-bottom: 10px;
                    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
                }
                .header .subtitle {
                    font-size: 1.2em;
                    opacity: 0.9;
                }
                .stats {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 20px;
                    padding: 30px;
                    background: #f8f9fa;
                    border-bottom: 3px solid #667eea;
                }
                .stat-card {
                    background: white;
                    padding: 20px;
                    border-radius: 10px;
                    text-align: center;
                    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                    border-left: 4px solid #667eea;
                }
                .stat-card .number {
                    font-size: 2em;
                    font-weight: bold;
                    color: #667eea;
                    margin-bottom: 5px;
                }
                .stat-card .label {
                    color: #666;
                    font-size: 0.9em;
                }
                .content {
                    padding: 30px;
                }
                .section {
                    margin-bottom: 40px;
                }
                .section h2 {
                    color: #667eea;
                    font-size: 1.8em;
                    margin-bottom: 20px;
                    padding-bottom: 10px;
                    border-bottom: 3px solid #667eea;
                }
                .diagram-card {
                    background: #f8f9fa;
                    border-radius: 10px;
                    padding: 20px;
                    margin-bottom: 15px;
                    border-left: 5px solid #667eea;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                }
                .diagram-card h3 {
                    color: #333;
                    margin-bottom: 10px;
                    font-size: 1.3em;
                }
                .diagram-card p {
                    color: #666;
                    line-height: 1.6;
                    margin: 8px 0;
                }
                .diagram-card .meta {
                    font-size: 0.9em;
                    color: #999;
                    margin-top: 10px;
                    padding-top: 10px;
                    border-top: 1px solid #ddd;
                }
                .package-tree {
                    background: #f8f9fa;
                    padding: 20px;
                    border-radius: 10px;
                    margin-top: 20px;
                }
                .package-item {
                    margin-left: 20px;
                    padding: 10px;
                    border-left: 2px solid #667eea;
                }
                .package-item h4 {
                    color: #667eea;
                    font-size: 1.1em;
                    margin-bottom: 5px;
                }
                .elements-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
                    gap: 20px;
                    margin-top: 20px;
                }
                .element-card {
                    background: white;
                    border: 2px solid #e0e0e0;
                    border-radius: 8px;
                    padding: 15px;
                    transition: all 0.3s;
                }
                .element-card:hover {
                    border-color: #667eea;
                    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
                }
                .element-card h4 {
                    color: #333;
                    margin-bottom: 10px;
                    font-size: 1.1em;
                }
                .element-card .stereotype {
                    font-size: 0.85em;
                    color: #667eea;
                    font-style: italic;
                    margin-bottom: 8px;
                }
                .element-card .attributes,
                .element-card .operations {
                    font-size: 0.9em;
                    color: #666;
                    margin-top: 8px;
                }
                .metadata {
                    background: #e8f4f8;
                    padding: 20px;
                    border-radius: 10px;
                    margin-top: 30px;
                }
                .metadata p {
                    margin: 8px 0;
                    color: #666;
                }
                .tag {
                    display: inline-block;
                    background: #667eea;
                    color: white;
                    padding: 4px 12px;
                    border-radius: 15px;
                    font-size: 0.85em;
                    margin-right: 8px;
                    margin-bottom: 8px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🎯 {{ title }}</h1>
                    <div class="subtitle">{{ filename }}</div>
                </div>

                <div class="stats">
                    <div class="stat-card">
                        <div class="number">{{ stats.diagrams }}</div>
                        <div class="label">图表数量</div>
                    </div>
                    <div class="stat-card">
                        <div class="number">{{ stats.packages }}</div>
                        <div class="label">包数量</div>
                    </div>
                    <div class="stat-card">
                        <div class="number">{{ stats.classes }}</div>
                        <div class="label">类数量</div>
                    </div>
                    <div class="stat-card">
                        <div class="number">{{ stats.elements }}</div>
                        <div class="label">元素总数</div>
                    </div>
                </div>

                <div class="content">
                    {% if packages %}
                    <div class="section">
                        <h2>📦 包结构</h2>
                        <div class="package-tree">
                            {% for package in packages %}
                            <div class="package-item">
                                <h4>📦 {{ package.name }}</h4>
                                {% if package.children %}
                                <div style="margin-left: 20px;">
                                    {% for child in package.children %}
                                    <div class="package-item">
                                        <h4>📦 {{ child.name }}</h4>
                                        {% if child.diagrams %}
                                        <div style="margin-top: 10px;">
                                            {% for diagram in child.diagrams %}
                                            <div style="font-size: 0.9em; color: #666; margin: 5px 0;">
                                                📊 {{ diagram.name }}
                                            </div>
                                            {% endfor %}
                                        </div>
                                        {% endif %}
                                    </div>
                                    {% endfor %}
                                </div>
                                {% endif %}
                                {% if package.diagrams %}
                                <div style="margin-top: 10px;">
                                    {% for diagram in package.diagrams %}
                                    <div style="font-size: 0.9em; color: #666; margin: 5px 0;">
                                        📊 {{ diagram.name }}
                                    </div>
                                    {% endfor %}
                                </div>
                                {% endif %}
                            </div>
                            {% endfor %}
                        </div>
                    </div>
                    {% endif %}

                    {% if diagrams %}
                    <div class="section">
                        <h2>📊 图表列表</h2>
                        {% for diagram in diagrams %}
                        <div class="diagram-card">
                            <h3>📊 {{ diagram.name }}</h3>
                            {% if diagram.type %}
                            <p><strong>类型:</strong> {{ diagram.type }}</p>
                            {% endif %}
                            {% if diagram.author %}
                            <p><strong>作者:</strong> {{ diagram.author }}</p>
                            {% endif %}
                            {% if diagram.created %}
                            <p><strong>创建时间:</strong> {{ diagram.created }}</p>
                            {% endif %}
                            {% if diagram.description %}
                            <p><strong>描述:</strong> {{ diagram.description }}</p>
                            {% endif %}
                            <div class="meta">
                                {% if diagram.elements_count %}
                                元素数量: {{ diagram.elements_count }} |
                                {% endif %}
                                {% if diagram.connectors_count %}
                                连接线: {{ diagram.connectors_count }}
                                {% endif %}
                            </div>
                        </div>
                        {% endfor %}
                    </div>
                    {% endif %}

                    {% if classes %}
                    <div class="section">
                        <h2>CppClass 元素</h2>
                        <div class="elements-grid">
                            {% for cls in classes %}
                            <div class="element-card">
                                <h4>{{ cls.name }}</h4>
                                {% if cls.stereotype %}
                                <div class="stereotype">&laquo;{{ cls.stereotype }}&raquo;</div>
                                {% endif %}
                                {% if cls.attributes %}
                                <div class="attributes">
                                    <strong>属性:</strong>
                                    {% for attr in cls.attributes %}
                                    <div>• {{ attr }}</div>
                                    {% endfor %}
                                </div>
                                {% endif %}
                                {% if cls.operations %}
                                <div class="operations">
                                    <strong>方法:</strong>
                                    {% for op in cls.operations %}
                                    <div>• {{ op }}</div>
                                    {% endfor %}
                                </div>
                                {% endif %}
                            </div>
                            {% endfor %}
                        </div>
                    </div>
                    {% endif %}

                    <div class="metadata">
                        <h3>📋 元数据</h3>
                        <p><strong>文件名:</strong> {{ filename }}</p>
                        <p><strong>文件大小:</strong> {{ file_size }} 字节</p>
                        <p><strong>生成时间:</strong> {{ generation_time }}</p>
                        <p><strong>EA 版本:</strong> {% if ea_version %}{{ ea_version }}{% else %}未知{% endif %}</p>
                        {% if tags %}
                        <p><strong>标签:</strong> 
                            {% for tag in tags %}
                            <span class="tag">{{ tag }}</span>
                            {% endfor %}
                        </p>
                        {% endif %}
                    </div>
                </div>
            </div>
        </body>
        </html>
        ''')

    def parse_eddx_file(self, file_path):
        """解析 .eddx 文件"""
        try:
            # 解析 XML
            tree = ET.parse(file_path)
            root = tree.getroot()

            # 提取基本信息
            model_data = {
                'title': 'Enterprise Architect 模型',
                'filename': os.path.basename(file_path),
                'file_size': os.path.getsize(file_path),
                'packages': [],
                'diagrams': [],
                'classes': [],
                'stats': {
                    'diagrams': 0,
                    'packages': 0,
                    'classes': 0,
                    'elements': 0
                },
                'ea_version': None,
                'tags': []
            }

            # 查找包 (Packages)
            packages_elem = root.find('.//Packages')
            if packages_elem is not None:
                for package in packages_elem.findall('.//Package'):
                    package_data = self._parse_package(package)
                    model_data['packages'].append(package_data)
                    model_data['stats']['packages'] += 1

            # 查找图表 (Diagrams)
            diagrams_elem = root.find('.//Diagrams')
            if diagrams_elem is not None:
                for diagram in diagrams_elem.findall('.//Diagram'):
                    diagram_data = self._parse_diagram(diagram)
                    model_data['diagrams'].append(diagram_data)
                    model_data['stats']['diagrams'] += 1

            # 查找类 (Classes)
            classes_elem = root.find('.//Classes')
            if classes_elem is not None:
                for cls in classes_elem.findall('.//Class'):
                    class_data = self._parse_class(cls)
                    model_data['classes'].append(class_data)
                    model_data['stats']['classes'] += 1

            # 统计元素总数
            model_data['stats']['elements'] = (
                    model_data['stats']['diagrams'] +
                    model_data['stats']['packages'] +
                    model_data['stats']['classes']
            )

            # 提取 EA 版本信息
            version_elem = root.find('.//Version')
            if version_elem is not None:
                model_data['ea_version'] = version_elem.text

            return model_data

        except ET.ParseError as e:
            print(f"XML 解析错误: {e}")
            return None
        except Exception as e:
            print(f"解析失败: {e}")
            return None

    def _parse_package(self, package_elem):
        """解析包信息"""
        package_data = {
            'name': package_elem.get('name', 'Unnamed Package'),
            'id': package_elem.get('package_id', ''),
            'children': [],
            'diagrams': []
        }

        # 查找子包
        child_packages = package_elem.findall('.//Package')
        for child in child_packages:
            package_data['children'].append(self._parse_package(child))

        # 查找包内的图表
        diagrams = package_elem.findall('.//Diagram')
        for diagram in diagrams:
            package_data['diagrams'].append({
                'name': diagram.get('name', 'Unnamed Diagram'),
                'id': diagram.get('diagram_id', '')
            })

        return package_data

    def _parse_diagram(self, diagram_elem):
        """解析图表信息"""
        diagram_data = {
            'name': diagram_elem.get('name', 'Unnamed Diagram'),
            'id': diagram_elem.get('diagram_id', ''),
            'type': diagram_elem.get('type', 'Unknown'),
            'author': diagram_elem.get('author', ''),
            'created': diagram_elem.get('created', ''),
            'description': diagram_elem.get('description', ''),
            'elements_count': 0,
            'connectors_count': 0
        }

        # 统计元素和连接线
        elements = diagram_elem.findall('.//Element')
        connectors = diagram_elem.findall('.//Connector')

        diagram_data['elements_count'] = len(elements)
        diagram_data['connectors_count'] = len(connectors)

        return diagram_data

    def _parse_class(self, class_elem):
        """解析类信息"""
        class_data = {
            'name': class_elem.get('name', 'Unnamed Class'),
            'id': class_elem.get('class_id', ''),
            'stereotype': class_elem.get('stereotype', ''),
            'attributes': [],
            'operations': []
        }

        # 提取属性
        attributes = class_elem.findall('.//Attribute')
        for attr in attributes:
            attr_name = attr.get('name', '')
            attr_type = attr.get('type', '')
            attr_info = f"{attr_name}: {attr_type}" if attr_type else attr_name
            class_data['attributes'].append(attr_info)

        # 提取操作/方法
        operations = class_elem.findall('.//Operation')
        for op in operations:
            op_name = op.get('name', '')
            op_return = op.get('returnType', '')
            op_info = f"{op_name}(): {op_return}" if op_return else f"{op_name}()"
            class_data['operations'].append(op_info)

        return class_data

    def convert_to_html(self, input_file ):
        """转换 .eddx 文件为 HTML"""
        # 解析 .eddx 文件
        model_data = self.parse_eddx_file(input_file)

        if model_data is None:
            print(f"✗ 无法解析文件: {input_file}")
            return None

        # 生成 HTML
        html_content = self.template.render(
            title=model_data.get('title', 'EA Model'),
            filename=model_data.get('filename', ''),
            file_size=model_data.get('file_size', 0),
            generation_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            stats=model_data.get('stats', {}),
            packages=model_data.get('packages', []),
            diagrams=model_data.get('diagrams', []),
            classes=model_data.get('classes', [])[:20],  # 限制显示数量
            ea_version=model_data.get('ea_version', ''),
            tags=model_data.get('tags', [])
        )
        return html_content

    def batch_convert(self, input_folder, output_folder=None):
        """批量转换 .eddx 文件"""
        if output_folder is None:
            output_folder = os.path.join(input_folder, 'html_output')

        os.makedirs(output_folder, exist_ok=True)

        eddx_files = [
            f for f in os.listdir(input_folder)
            if f.lower().endswith('.eddx')
        ]

        print(f"找到 {len(eddx_files)} 个 .eddx 文件")

        results = []
        for file in eddx_files:
            input_path = os.path.join(input_folder, file)
            output_path = os.path.join(output_folder, os.path.splitext(file)[0] + '.html')

            try:
                result = self.convert_to_html(input_path, output_path)
                if result:
                    results.append({'file': file, 'status': 'success', 'output': output_path})
                else:
                    results.append({'file': file, 'status': 'failed', 'error': '解析失败'})
            except Exception as e:
                print(f"✗ 转换失败 {file}: {e}")
                results.append({'file': file, 'status': 'failed', 'error': str(e)})

        return results




def _parse_size(value: str) -> Optional[int]:
    """解析大小字符串为字节数

    支持: 数字（字节）, 数字+KB/MB/GB/单位后缀
    """
    if not value:
        return None
    value = value.strip().upper()
    if not value:
        return None
    try:
        if value.endswith('GB'):
            return int(float(value[:-2]) * 1024 * 1024 * 1024)
        if value.endswith('MB'):
            return int(float(value[:-2]) * 1024 * 1024)
        if value.endswith('KB'):
            return int(float(value[:-2]) * 1024)
        if value.endswith('B'):
            return int(float(value[:-1]))
        return int(float(value))
    except (ValueError, TypeError):
        return None


def _parse_date(value: str, is_end: bool = False) -> Optional[datetime]:
    """解析日期字符串为 datetime 对象

    支持: YYYY-MM-DD, YYYY-MM-DD HH:MM:SS, ISO格式
    is_end=True 时将日期设为当天结束时刻
    """
    if not value:
        return None
    value = value.strip()
    if not value:
        return None
    try:
        # 尝试 ISO 格式
        dt = datetime.fromisoformat(value)
    except ValueError:
        try:
            # 尝试 YYYY-MM-DD
            dt = datetime.strptime(value, '%Y-%m-%d')
        except ValueError:
            try:
                # 尝试 YYYY-MM-DD HH:MM:SS
                dt = datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
            except ValueError:
                return None
    if is_end and dt.hour == 0 and dt.minute == 0 and dt.second == 0:
        # 日期只有日期部分，作为结束日期时设为当天 23:59:59
        dt = dt.replace(hour=23, minute=59, second=59)
    return dt


def _parse_range_header(range_header: str, file_size: int) -> tuple | None:
    """解析 HTTP Range 头，返回 (start, end) 字节偏移或 None

    支持: bytes=0-1023, bytes=1024-, bytes=-512
    不支持多范围（返回 None 回退到 200）
    范围无效/无法满足时返回 None
    """
    if not range_header or file_size <= 0:
        return None

    try:
        prefix, value = range_header.strip().split('=', 1)
        if prefix.strip() != 'bytes':
            return None

        # 多范围不支持
        if ',' in value:
            return None

        value = value.strip()
        if '-' not in value:
            return None

        start_str, end_str = value.split('-', 1)
        start_str = start_str.strip()
        end_str = end_str.strip()

        if start_str and end_str:
            start = int(start_str)
            end = min(int(end_str), file_size - 1)
        elif start_str:
            start = int(start_str)
            end = file_size - 1
        elif end_str:
            suffix = int(end_str)
            start = max(0, file_size - suffix)
            end = file_size - 1
        else:
            return None

        if start > end or start >= file_size:
            return None

        return (start, end)
    except (ValueError, IndexError):
        return None


class FileOpsMixin:
    """文件操作方法（下载、上传、删除、重命名、移动、复制、创建目录、ZIP下载）"""

    config = None
    authenticator = None
    session_manager = None
    user_store = None
    share_manager = None
    trash_manager = None
    access_logger = None

    def _log_access(self, action: str, path: str, **details) -> None:
        """记录访问日志"""
        if self.access_logger:
            username = self.get_current_username() or 'Unknown'
            client_ip = self.client_address[0]
            self.access_logger.log(username, action, path, client_ip=client_ip, **details)

    def _check_path_permission(self, path: str, required: str) -> bool:
        """检查当前用户对指定路径的权限

        Args:
            path: 相对于 serve_dir 的路径
            required: PERM_READ 或 PERM_READWRITE

        Returns:
            是否有权限
        """
        username = self.get_current_username()
        if not username or not self.user_store:
            return False
        user_data = self.user_store.get_user(username)
        default_perm = self.config.default_permission if self.config else "rw"
        return check_permission(user_data, path, required, default_perm)

    def _handle_download(self) -> None:
        """处理文件下载"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            logger.warning("未认证用户尝试下载文件")
            self.send_error(403, "Forbidden")
            return

        file_path_rel = self.path[len('/download/'):].lstrip('/')
        file_path_rel = urllib.parse.unquote(file_path_rel)
        file_path = Path(self.directory) / file_path_rel

        if not _is_safe_path(Path(self.directory), file_path):
            logger.warning(f"路径遍历攻击尝试 - 用户: {username}, 路径: {file_path_rel}")
            self.send_error(403, "Forbidden")
            return

        if not self._check_path_permission(file_path_rel, PERM_READ):
            logger.warning(f"权限不足(读) - 用户: {username}, 路径: {file_path_rel}")
            self.send_error(403, "Forbidden")
            return

        if file_path.exists() and file_path.is_file():
            try:
                file_size = file_path.stat().st_size
                encoded_filename = urllib.parse.quote(file_path.name)
                content_disposition = f"attachment; filename*=UTF-8''{encoded_filename}"

                # 确定 MIME 类型
                mime_type, _ = mimetypes.guess_type(str(file_path))
                if mime_type is None:
                    mime_type = 'application/octet-stream'

                # 检查 Range 请求
                range_header = self.headers.get('Range', '')
                byte_range = _parse_range_header(range_header, file_size)

                if byte_range is not None:
                    start, end = byte_range
                    content_length = end - start + 1
                    logger.info(f"文件部分下载(Range) - 用户: {username}, 文件: {file_path_rel}, "
                                f"范围: {start}-{end}/{file_size}")

                    self.send_response(206)
                    self.send_header('Content-Type', mime_type)
                    self.send_header('Content-Range', f'bytes {start}-{end}/{file_size}')
                    self.send_header('Content-Length', str(content_length))
                    self.send_header('Accept-Ranges', 'bytes')
                    self.send_header('Content-Disposition', 'inline')
                    self.end_headers()

                    with open(file_path, 'rb') as f:
                        f.seek(start)
                        remaining = content_length
                        while remaining > 0:
                            chunk_size = min(65536, remaining)
                            data = f.read(chunk_size)
                            if not data:
                                break
                            self.wfile.write(data)
                            remaining -= len(data)
                else:
                    logger.info(f"文件下载 - 用户: {username}, 文件: {file_path_rel}")

                    self.send_response(200)
                    self.send_header('Content-Type', mime_type)
                    self.send_header('Content-Disposition', content_disposition)
                    self.send_header('Content-Length', str(file_size))
                    self.send_header('Accept-Ranges', 'bytes')
                    self.end_headers()

                    with open(file_path, 'rb') as f:
                        self.copyfile(f, self.wfile)
                    logger.info(f"文件下载完成 - {file_path_rel}")
                    self._log_access('download', file_path_rel, file_size=file_size)

            except (ConnectionResetError, BrokenPipeError, ssl.SSLError) as e:
                logger.debug(f"客户端断开连接 - 文件: {file_path_rel}, 错误: {e}")
            except Exception as e:
                logger.error(f"下载文件出错 - 文件: {file_path_rel}, 错误: {e}")
                try:
                    self.send_error(500, "Download error")
                except (ConnectionResetError, BrokenPipeError, ssl.SSLError):
                    pass
        else:
            logger.warning(f"文件不存在 - {file_path}")
            self.send_error(404, "File not found")

    def _handle_upload_page(self, error_msg: str = "", success_msg: str = "") -> None:
        """显示上传页面"""
        from ..template import render_upload_page
        username = self.get_current_username() or 'Unknown'
        is_admin = False
        if self.user_store:
            is_admin = self.user_store.is_admin(username)
        html = render_upload_page(username, error_msg, success_msg, is_admin=is_admin)
        self._send_html_response(html)

    def _handle_upload(self) -> None:
        """处理文件上传"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            logger.warning("未认证用户尝试上传文件")
            self.send_error(403, "Forbidden")
            return

        if not self._check_path_permission("", PERM_READWRITE):
            logger.warning(f"权限不足(写) - 用户: {username}, 路径: /")
            self.send_error(403, "Forbidden")
            return

        content_type = self.headers.get('Content-Type', '')
        if not content_type.startswith('multipart/form-data'):
            self._handle_upload_page(error_msg="无效的请求格式")
            return

        boundary = None
        for part in content_type.split(';'):
            part = part.strip()
            if part.startswith('boundary='):
                boundary = part[9:]
                if boundary.startswith('"') and boundary.endswith('"'):
                    boundary = boundary[1:-1]
                break

        if not boundary:
            self._handle_upload_page(error_msg="缺少边界参数")
            return

        content_length = int(self.headers.get('Content-Length', 0))
        if content_length == 0:
            self._handle_upload_page(error_msg="没有文件数据")
            return

        max_upload_mb = self.config.max_upload_size_mb if self.config else 100
        max_size = max_upload_mb * 1024 * 1024
        if content_length > max_size:
            self._handle_upload_page(error_msg=f"文件大小超过限制 (最大 {max_upload_mb}MB)")
            return

        try:
            body = self.rfile.read(content_length)
            parts = _parse_multipart(body, boundary)
        except Exception as e:
            logger.error(f"解析上传数据失败: {e}")
            self._handle_upload_page(error_msg="解析上传数据失败")
            return

        uploaded_files = []
        errors = []
        upload_dir = Path(self.directory)

        for part in parts:
            if part['filename']:
                original_filename = part['filename']
                filename = _sanitize_filename(original_filename)
                file_data = part['data']

                target_path = upload_dir / filename
                counter = 1
                while target_path.exists():
                    name, ext = os.path.splitext(filename)
                    filename = f"{name}_{counter}{ext}"
                    target_path = upload_dir / filename
                    counter += 1

                if not _is_safe_path(upload_dir, target_path):
                    errors.append(f"文件名不安全: {original_filename}")
                    continue

                try:
                    with open(target_path, 'wb') as f:
                        f.write(file_data)
                    uploaded_files.append(filename)
                    logger.info(f"文件上传成功 - 用户: {username}, 文件: {filename}, 大小: {len(file_data)} bytes")
                    self._log_access('upload', filename, file_size=len(file_data))
                except Exception as e:
                    logger.error(f"保存文件失败: {filename}, 错误: {e}")
                    errors.append(f"保存失败: {original_filename}")

        if uploaded_files:
            success_msg = f"成功上传 {len(uploaded_files)} 个文件"
            if errors:
                success_msg += f"，{len(errors)} 个文件失败"
            self._handle_upload_page(success_msg=success_msg)
        else:
            error_msg = "没有文件被上传" if not errors else "，".join(errors)
            self._handle_upload_page(error_msg=error_msg)

    def list_directory(self, path: str):
        """重写目录列表方法"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            logger.warning(f"未认证用户尝试访问目录列表: {path}")
            self.send_error(403, "Forbidden")
            return None

        logger.info(f"目录列表访问 - 用户: {username}, 路径: {path}")

        parsed = urllib.parse.urlparse(self.path)
        query_params = urllib.parse.parse_qs(parsed.query)
        sort_by = query_params.get('sort', ['name'])[0]
        search_query = query_params.get('q', [''])[0]
        file_type_filter = query_params.get('type', ['all'])[0]

        # 高级搜索参数
        size_min_str = query_params.get('size_min', [''])[0]
        size_max_str = query_params.get('size_max', [''])[0]
        date_from_str = query_params.get('date_from', [''])[0]
        date_to_str = query_params.get('date_to', [''])[0]
        extensions_str = query_params.get('extensions', [''])[0]

        if sort_by not in ('name', 'size', 'time'):
            sort_by = 'name'

        # 解析高级搜索筛选条件
        size_min = _parse_size(size_min_str)
        size_max = _parse_size(size_max_str)
        date_from = _parse_date(date_from_str)
        date_to = _parse_date(date_to_str, is_end=True)
        extension_filter = set()
        if extensions_str:
            extension_filter = {e.strip().lower() for e in extensions_str.split(',') if e.strip()}

        try:
            scandir_iter = os.scandir(path)
        except OSError as e:
            logger.error(f"无法列出目录: {path}, 错误: {e}")
            self.send_error(404, "No permission to list directory")
            return None

        base_dir = Path(self.directory)
        current_path = Path(path)
        try:
            relative_path = current_path.relative_to(base_dir)
        except ValueError:
            relative_path = Path('.')

        relative_path_str = str(relative_path).replace('\\', '/')
        if relative_path_str == '.':
            relative_path_str = ''

        # 检查当前用户对当前目录的读权限
        if not self._check_path_permission(relative_path_str, PERM_READ):
            logger.warning(f"权限不足(读) - 用户: {username}, 路径: {relative_path_str}")
            self.send_error(403, "Forbidden")
            return None

        # 检查当前用户对当前目录的写权限（用于控制UI按钮显示）
        can_write = self._check_path_permission(relative_path_str, PERM_READWRITE)

        # 使用 os.scandir() 替代 os.listdir() + per-file stat()
        # DirEntry 缓存了 stat 信息，避免每文件 2 次 syscall
        directories = []
        files = []
        with scandir_iter:
            for entry in scandir_iter:
                if entry.name.startswith('.'):
                    continue
                try:
                    st = entry.stat()
                except OSError:
                    continue
                if entry.is_dir():
                    directories.append((entry.name, st.st_mtime))
                elif entry.is_file():
                    files.append((entry.name, st.st_size, st.st_mtime))

        # 应用高级搜索筛选（扩展名筛选时排除目录）
        if extension_filter:
            directories = []
        if size_min is not None or size_max is not None or date_from or date_to or extension_filter:
            filtered_files = []
            for f, size, mtime in files:
                if size_min is not None and size < size_min:
                    continue
                if size_max is not None and size > size_max:
                    continue
                if date_from:
                    dt = datetime.fromtimestamp(mtime)
                    if dt < date_from:
                        continue
                if date_to:
                    dt = datetime.fromtimestamp(mtime)
                    if dt > date_to:
                        continue
                if extension_filter:
                    ext = os.path.splitext(f)[1].lower()
                    if ext not in extension_filter:
                        continue
                filtered_files.append((f, size, mtime))
            files = filtered_files

        files_by_type = {}
        for f, size, mtime in files:
            ftype = detect_file_type(f)
            files_by_type.setdefault(ftype, []).append((f, size, mtime))

        from ..template import render_file_list_page

        is_admin = False
        if self.user_store:
            is_admin = self.user_store.is_admin(username)

        html = render_file_list_page(
            username, files_by_type,
            directories, relative_path_str, sort_by, search_query, file_type_filter, is_admin,
            can_write=can_write
        )

        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(html.encode('utf-8'))))
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))
        return None

    def _handle_view_json(self) -> None:
        """处理JSON文件查看请求"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            logger.warning("未认证用户尝试查看JSON文件")
            self.send_error(403, "Forbidden")
            return

        file_path_rel = self.path[len('/view/'):].lstrip('/')
        file_path_rel = urllib.parse.unquote(file_path_rel)
        file_path = Path(self.directory) / file_path_rel
        file_name = file_path.name

        if not _is_safe_path(Path(self.directory), file_path):
            logger.warning(f"路径遍历攻击尝试 - 用户: {username}, 路径: {file_path_rel}")
            self.send_error(403, "Forbidden")
            return

        if not file_path.exists() or not file_path.is_file():
            self.send_error(404, "File not found")
            return

        if not file_name.lower().endswith('.json'):
            self.send_error(400, "Not a JSON file")
            return

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                json_content = f.read()
            json_data = json.loads(json_content)
            formatted_json = json.dumps(json_data, indent=2, ensure_ascii=False)
            logger.info(f"JSON文件查看 - 用户: {username}, 文件: {file_path_rel}")
        except json.JSONDecodeError as e:
            formatted_json = f"JSON 解析错误: {e}"
        except Exception as e:
            logger.error(f"读取JSON文件失败: {e}")
            self.send_error(500, "Failed to read file")
            return

        project_name = None
        try:
            if isinstance(json_data, dict) and 'project' in json_data:
                if isinstance(json_data['project'], dict) and 'name' in json_data['project']:
                    project_name = json_data['project']['name']
        except Exception:
            pass

        from ..template import render_json_view_page
        is_admin = False
        if self.user_store:
            is_admin = self.user_store.is_admin(username)
        html = render_json_view_page(username, file_path_rel, formatted_json, project_name, is_admin=is_admin)
        self._send_html_response(html)

    def _handle_convert_json(self) -> None:
        """处理JSON转XMind请求"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            logger.warning("未认证用户尝试转换JSON")
            self.send_error(403, "Forbidden")
            return

        file_name = self.path[len('/convert/'):].lstrip('/')
        file_name = urllib.parse.unquote(file_name)
        file_path = Path(self.directory) / file_name

        if not _is_safe_path(Path(self.directory), file_path):
            logger.warning(f"路径遍历攻击尝试 - 用户: {username}, 路径: {file_name}")
            self.send_error(403, "Forbidden")
            return

        if not file_path.exists() or not file_path.is_file():
            self.send_error(404, "File not found")
            return

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                json_data = json.load(f)

            project_name = None
            if isinstance(json_data, dict) and 'project' in json_data:
                if isinstance(json_data['project'], dict) and 'name' in json_data['project']:
                    project_name = json_data['project']['name']

            if not project_name:
                project_name = file_name.rsplit('.json', 1)[0]

            xmind_name = f"{project_name}.xmind"
            xmind_path = Path(self.directory) / xmind_name

            counter = 1
            while xmind_path.exists():
                xmind_name = f"{project_name}_{counter}.xmind"
                xmind_path = Path(self.directory) / xmind_name
                counter += 1

            xmind_content = self._build_xmind_content(json_data, project_name)
            self._write_xmind_file(xmind_path, xmind_content)

            logger.info(f"JSON转XMind成功 - 用户: {username}, 原文件: {file_name}, 输出: {xmind_name}")

            response = json.dumps({"success": True, "xmind_file": xmind_name})
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Content-Length', len(response))
            self.end_headers()
            self.wfile.write(response.encode('utf-8'))

        except json.JSONDecodeError as e:
            response = json.dumps({"success": False, "error": f"JSON解析错误: {e}"})
            self.send_response(400)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(response.encode('utf-8'))
        except Exception as e:
            logger.error(f"JSON转XMind失败: {e}")
            response = json.dumps({"success": False, "error": str(e)})
            self.send_response(500)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(response.encode('utf-8'))

    def _build_xmind_content(self, data: dict, root_title: str) -> dict:
        """构建XMind内容结构"""
        content = {
            "root": {
                "title": root_title,
                "children": []
            }
        }

        def add_children(node, parent_children):
            if isinstance(node, dict):
                for key, value in node.items():
                    child = {"title": str(key)}
                    if isinstance(value, (dict, list)) and value:
                        child["children"] = []
                        add_children(value, child["children"])
                    elif value is not None:
                        child["title"] = f"{key}: {value}"
                    parent_children.append(child)
            elif isinstance(node, list):
                for i, item in enumerate(node):
                    child = {"title": f"[{i}]"}
                    if isinstance(item, (dict, list)) and item:
                        child["children"] = []
                        add_children(item, child["children"])
                    elif item is not None:
                        child["title"] = str(item)
                    parent_children.append(child)

        add_children(data, content["root"]["children"])
        return content

    def _write_xmind_file(self, path: Path, content: dict) -> None:
        """写入XMind文件"""
        from datetime import datetime
        with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as zf:
            content_json = json.dumps([content], ensure_ascii=False, indent=2)
            zf.writestr('content.json', content_json.encode('utf-8'))

            manifest = {
                "file-entries": {
                    "content.json": {},
                    "metadata.json": {}
                }
            }
            zf.writestr('manifest.json', json.dumps(manifest).encode('utf-8'))

            metadata = {
                "creator": {
                    "name": "pyfileserv",
                    "version": version("pyfileserv")
                },
                "created": datetime.now().isoformat()
            }
            zf.writestr('metadata.json', json.dumps(metadata).encode('utf-8'))

    def _handle_delete(self) -> None:
        """处理删除文件/目录（移动到回收站）"""
        username = self.get_current_username() or 'Unknown'

        path_rel = self.path[len('/api/delete/'):]
        path_rel = path_rel.lstrip('/')
        path_rel = urllib.parse.unquote(path_rel)
        path_rel = path_rel.replace('\\', '/')
        path_rel = path_rel.lstrip('/')

        if not path_rel:
            self._send_error_response('文件或目录不存在')
            return

        target_path = _resolve_safe_path(Path(self.directory), path_rel)
        if not target_path:
            logger.warning(f"路径安全检查失败 - 用户: {username}, 路径: {path_rel}")
            self._send_error_response('文件或目录不存在')
            return

        if not target_path.exists():
            logger.warning(f"文件不存在 - 用户: {username}, 路径: {path_rel}, 完整路径: {target_path}")
            self._send_error_response('文件或目录不存在')
            return

        if not self._check_path_permission(path_rel, PERM_READWRITE):
            logger.warning(f"权限不足(写) - 用户: {username}, 路径: {path_rel}")
            self._send_error_response('权限不足', 403)
            return

        try:
            if self.trash_manager:
                logger.info(f"尝试移动到回收站 - 用户: {username}, 路径: {path_rel}")
                item_id = self.trash_manager.move_to_trash(path_rel)
                if item_id:
                    logger.info(f"已移至回收站 - 用户: {username}, 路径: {path_rel}, ID: {item_id}")
                    self._log_access('delete', path_rel)
                    self._send_json_response({'success': True, 'trash_id': item_id})
                    return
                logger.warning(f"回收站移动失败，回退到直接删除 - 用户: {username}, 路径: {path_rel}")

            if target_path.is_dir():
                shutil.rmtree(target_path)
            else:
                target_path.unlink()
            logger.info(f"删除成功 - 用户: {username}, 路径: {path_rel}")
            self._log_access('delete', path_rel)
            self._send_json_response({'success': True})
        except Exception as e:
            logger.error(f"删除失败 - 用户: {username}, 路径: {path_rel}, 错误: {e}")
            self._send_error_response('删除失败，请稍后重试')

    def _handle_rename(self) -> None:
        """处理重命名文件/目录"""
        username = self.get_current_username() or 'Unknown'

        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))

            old_path_rel = data.get('old_path', '').strip()
            new_name = data.get('new_name', '').strip()

            if not old_path_rel or not new_name:
                self._send_error_response('缺少必要参数')
                return

            old_path_rel = old_path_rel.lstrip('/')
            old_path_rel = urllib.parse.unquote(old_path_rel)
            old_path_rel = old_path_rel.replace('\\', '/').lstrip('/')

            new_name = _sanitize_filename(new_name)
            if not new_name:
                self._send_error_response('新文件名无效')
                return

            old_path = _resolve_safe_path(Path(self.directory), old_path_rel)
            if not old_path or not old_path.exists():
                self._send_error_response('源文件不存在')
                return

            parent_dir = old_path.parent
            new_path = parent_dir / new_name

            if new_path.exists():
                self._send_error_response('目标路径已存在')
                return

            if not self._check_path_permission(old_path_rel, PERM_READWRITE):
                logger.warning(f"权限不足(写) - 用户: {username}, 路径: {old_path_rel}")
                self._send_error_response('权限不足', 403)
                return

            old_path.rename(new_path)
            logger.info(f"重命名成功 - 用户: {username}, 旧路径: {old_path_rel}, 新名称: {new_name}")
            self._log_access('rename', old_path_rel, new_name=new_name)
            self._send_json_response({'success': True})
        except Exception as e:
            logger.error(f"重命名失败 - 用户: {username}, 错误: {e}")
            self._send_error_response('重命名失败，请稍后重试')

    def _handle_move(self) -> None:
        """处理移动文件/目录"""
        username = self.get_current_username() or 'Unknown'

        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))

            src_path_rel = data.get('src_path', '').strip()
            dest_dir_rel = data.get('dest_dir', '').strip()

            if not src_path_rel or dest_dir_rel is None:
                self._send_error_response('缺少必要参数')
                return

            src_path_rel = src_path_rel.lstrip('/')
            src_path_rel = urllib.parse.unquote(src_path_rel)
            src_path_rel = src_path_rel.replace('\\', '/').lstrip('/')
            dest_dir_rel = dest_dir_rel.lstrip('/')
            dest_dir_rel = urllib.parse.unquote(dest_dir_rel)
            dest_dir_rel = dest_dir_rel.replace('\\', '/').lstrip('/')

            src_path = _resolve_safe_path(Path(self.directory), src_path_rel)
            dest_dir = _resolve_safe_path(Path(self.directory), dest_dir_rel)

            if not src_path or not src_path.exists():
                self._send_error_response('源文件不存在')
                return
            if not dest_dir or not dest_dir.is_dir():
                self._send_error_response('目标目录不存在')
                return

            dest_path = dest_dir / src_path.name
            counter = 1
            base_name = src_path.stem
            ext = src_path.suffix
            while dest_path.exists():
                dest_path = dest_dir / f"{base_name}_{counter}{ext}"
                counter += 1

            if not self._check_path_permission(src_path_rel, PERM_READWRITE):
                logger.warning(f"权限不足(写) - 用户: {username}, 路径: {src_path_rel}")
                self._send_error_response('权限不足', 403)
                return

            shutil.move(str(src_path), str(dest_path))
            logger.info(f"移动成功 - 用户: {username}, 源: {src_path_rel}, 目标: {dest_dir_rel}")
            self._log_access('move', src_path_rel, dest_dir=dest_dir_rel)
            self._send_json_response({'success': True})
        except Exception as e:
            logger.error(f"移动失败 - 用户: {username}, 错误: {e}")
            self._send_error_response('移动失败，请稍后重试')

    def _handle_copy(self) -> None:
        """处理复制文件/目录"""
        username = self.get_current_username() or 'Unknown'

        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))

            src_path_rel = data.get('src_path', '').strip()

            if not src_path_rel:
                self._send_error_response('缺少必要参数')
                return

            src_path_rel = src_path_rel.lstrip('/')
            src_path_rel = urllib.parse.unquote(src_path_rel)
            src_path_rel = src_path_rel.replace('\\', '/').lstrip('/')

            src_path = _resolve_safe_path(Path(self.directory), src_path_rel)

            if not src_path or not src_path.exists():
                self._send_error_response('源文件不存在')
                return

            parent_dir = src_path.parent
            base_name = src_path.stem
            ext = src_path.suffix
            counter = 1
            dest_path = parent_dir / f"{base_name}_copy{ext}"
            while dest_path.exists():
                dest_path = parent_dir / f"{base_name}_copy_{counter}{ext}"
                counter += 1

            if not self._check_path_permission(src_path_rel, PERM_READWRITE):
                logger.warning(f"权限不足(写) - 用户: {username}, 路径: {src_path_rel}")
                self._send_error_response('权限不足', 403)
                return

            if src_path.is_dir():
                shutil.copytree(src_path, dest_path)
            else:
                shutil.copy2(src_path, dest_path)

            logger.info(f"复制成功 - 用户: {username}, 源: {src_path_rel}")
            self._log_access('copy', src_path_rel)
            self._send_json_response({'success': True})
        except Exception as e:
            logger.error(f"复制失败 - 用户: {username}, 错误: {e}")
            self._send_error_response('复制失败，请稍后重试')

    def _handle_mkdir(self) -> None:
        """处理创建目录"""
        username = self.get_current_username() or 'Unknown'

        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))

            dir_name = data.get('dir_name', '').strip()
            parent_dir_rel = data.get('parent_dir', '').strip()

            if not dir_name:
                self._send_error_response('目录名不能为空')
                return

            dir_name = _sanitize_filename(dir_name)
            if not dir_name:
                self._send_error_response('目录名无效')
                return

            if parent_dir_rel:
                parent_dir_rel = parent_dir_rel.replace('\\', '/')
                parent_dir = Path(self.directory) / parent_dir_rel
            else:
                parent_dir = Path(self.directory)

            if not _is_safe_path(Path(self.directory), parent_dir):
                self._send_error_response('非法的父目录路径')
                return

            if not parent_dir.exists() or not parent_dir.is_dir():
                self._send_error_response('父目录不存在')
                return

            new_dir = parent_dir / dir_name
            if new_dir.exists():
                self._send_error_response('目录已存在')
                return

            # Check permission on parent directory
            if not self._check_path_permission(parent_dir_rel if parent_dir_rel else '', PERM_READWRITE):
                logger.warning(f"权限不足(写) - 用户: {username}, 路径: {parent_dir_rel}")
                self._send_error_response('权限不足', 403)
                return

            new_dir.mkdir()
            logger.info(f"创建目录成功 - 用户: {username}, 目录: {dir_name}")
            self._log_access('mkdir', f"{parent_dir_rel}/{dir_name}" if parent_dir_rel else dir_name)
            self._send_json_response({'success': True})
        except Exception as e:
            logger.error(f"创建目录失败 - 用户: {username}, 错误: {e}")
            self._send_error_response('创建目录失败，请稍后重试')

    def _handle_list_directories(self) -> None:
        """获取目录列表（仅返回用户可读的目录）"""
        username = self.get_current_username() or 'Unknown'

        try:
            base_dir = Path(self.directory)
            directories = []

            for root, dirs, _ in os.walk(base_dir):
                rel_root = Path(root).relative_to(base_dir)
                for d in dirs:
                    if not d.startswith('.'):
                        dir_path = rel_root / d
                        dir_path_str = str(dir_path)
                        # 只包含用户可读的目录
                        if self._check_path_permission(dir_path_str, PERM_READ):
                            directories.append(dir_path_str)

            directories.sort(key=lambda x: (x.count(os.sep), x))
            self._send_json_response({'success': True, 'directories': [''] + directories})
        except Exception as e:
            logger.error(f"获取目录列表失败 - 用户: {username}, 错误: {e}")
            self._send_error_response('获取目录列表失败，请稍后重试')

    def _handle_zip_download(self) -> None:
        """处理 ZIP 批量下载"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            self._send_error_response('未认证', 403)
            return

        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))

            paths = data.get('paths', [])
            if not paths:
                self._send_error_response('未选择文件')
                return

            base_dir = Path(self.directory)
            valid_paths = []

            for p in paths:
                resolved = _resolve_safe_path(base_dir, p)
                if resolved and resolved.exists():
                    valid_paths.append((p, resolved))

            if not valid_paths:
                self._send_error_response('没有有效文件')
                return

            import tempfile
            with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp:
                tmp_path = tmp.name

            try:
                with zipfile.ZipFile(tmp_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                    for _rel_path, abs_path in valid_paths:
                        if abs_path.is_file():
                            zf.write(abs_path, abs_path.name)
                        elif abs_path.is_dir():
                            for root, dirs, files in os.walk(abs_path):
                                rel_root = os.path.relpath(root, abs_path)
                                if rel_root == '.':
                                    zip_dir_prefix = abs_path.name
                                else:
                                    zip_dir_prefix = os.path.join(abs_path.name, rel_root)
                                if rel_root != '.':
                                    zf.writestr(zip_dir_prefix + '/', '')
                                for f in files:
                                    file_abs = Path(root) / f
                                    arc_name = os.path.join(zip_dir_prefix, f)
                                    zf.write(file_abs, arc_name)

                zip_size = os.path.getsize(tmp_path)
                self.send_response(200)
                self.send_header('Content-Type', 'application/zip')
                self.send_header('Content-Disposition', 'attachment; filename=download.zip')
                self.send_header('Content-Length', str(zip_size))
                self.end_headers()

                with open(tmp_path, 'rb') as f:
                    self.copyfile(f, self.wfile)

                logger.info(f"ZIP 下载 - 用户: {username}, 文件数: {len(valid_paths)}")
            finally:
                os.unlink(tmp_path)

        except Exception as e:
            logger.error(f"ZIP 下载失败 - 用户: {username}, 错误: {e}")
            self._send_error_response('ZIP 下载失败，请稍后重试')

    def _serve_raw_file(self, file_path: Path) -> None:
        """提供原始文件（用于预览中的图片、音频等）"""
        if not file_path.exists() or not file_path.is_file():
            self.send_error(404, "File not found")
            return

        try:
            import mimetypes
            mime_type, _ = mimetypes.guess_type(str(file_path))
            if not mime_type:
                mime_type = 'application/octet-stream'

            file_size = file_path.stat().st_size
            self.send_response(200)
            self.send_header('Content-Type', mime_type)
            self.send_header('Content-Length', str(file_size))
            self.send_header('Cache-Control', 'public, max-age=3600')
            self.end_headers()

            with open(file_path, 'rb') as f:
                self.copyfile(f, self.wfile)
        except Exception as e:
            logger.error(f"提供文件失败: {e}")
            self.send_error(500, "File serve error")

    def _get_directory_items(self, dir_path: Path, rel_prefix: str) -> list:
        """获取目录内容列表"""
        items = []
        try:
            for entry in sorted(dir_path.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
                if entry.name.startswith('.'):
                    continue

                item_rel_path = str(entry.relative_to(Path(self.directory)))
                item = {
                    'name': entry.name,
                    'is_dir': entry.is_dir(),
                    'size': entry.stat().st_size if entry.is_file() else 0,
                    'path': item_rel_path
                }
                items.append(item)
        except Exception as e:
            logger.error(f"读取目录失败: {e}")

        return items
