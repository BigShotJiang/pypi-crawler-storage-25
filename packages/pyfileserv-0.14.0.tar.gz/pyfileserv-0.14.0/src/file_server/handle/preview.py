"""HTTP 处理器 - 文档预览渲染模块 + 预览功能 Mixin"""
import base64
import json
import logging
import re
import urllib.parse
import zipfile
from pathlib import Path

from ..core.permission import check_permission, PERM_READ
from .utils import detect_file_type

logger = logging.getLogger(__name__)

# Optional markdown support
try:
    import markdown as _markdown
    MARKDOWN_AVAILABLE = True
except ImportError:
    MARKDOWN_AVAILABLE = False

# Optional Office document support
try:
    import mammoth
    MAMMOTH_AVAILABLE = True
except ImportError:
    MAMMOTH_AVAILABLE = False

try:
    from spire.xls import Workbook, Stream as XlsStream
    from spire.xls.common import *
    XLSX_AVAILABLE = True
except ImportError:
    XLSX_AVAILABLE = False

try:
    from spire.presentation import Presentation, FileFormat
    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False

try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

# 任务列表正则：匹配 <li>[ ] 或 <li>[x] 或 <li>[X]
_TASKLIST_RE = re.compile(r'<li>\[([ xX])\]\s*')


def _render_task_lists(html: str) -> str:
    """将 Markdown 任务列表语法转换为可点击的复选框 HTML"""
    def _replace(match: re.Match) -> str:
        state = match.group(1)
        checked = ' checked' if state in ('x', 'X') else ''
        return f'<li class="task-list-item"><input type="checkbox"{checked} disabled>'
    return _TASKLIST_RE.sub(_replace, html)


def _render_office_unavailable(doc_type: str) -> str:
    """当 Office 库不可用时，返回提示 HTML"""
    return f"""<div class="unavailable-msg">
    <h2>预览不可用</h2>
    <p>{doc_type} 文档预览需要安装额外的依赖库。</p>
    <p>请运行以下命令安装：</p>
    <pre><code>pip install pyfileserv[office]</code></pre>
    <p>或单独安装：</p>
    <pre><code>pip install Spire.Presentation.Free Spire.Xls.Free mammoth</code></pre>
</div>"""


_SVG_BASE = (
    '<svg xmlns="http://www.w3.org/2000/svg" width="320" height="60">'
    '<rect width="100%" height="100%" fill="#f5f5f5" stroke="#ccc" stroke-width="1.5" rx="6"/>'
    '<text x="50%" y="50%" text-anchor="middle" dominant-baseline="central"'
    ' font-family="sans-serif" font-size="13" fill="#999">{text}</text>'
    '</svg>'
)
# 预计算常用占位 SVG data URI
_PLACEHOLDER_IMAGE_NA = 'data:image/svg+xml,' + urllib.parse.quote(
    _SVG_BASE.format(text='[Image not available]'), safe='')
_PLACEHOLDER_CONV_FAILED = 'data:image/svg+xml,' + urllib.parse.quote(
    _SVG_BASE.format(text='[Conversion failed]'), safe='')


def _placeholder_svg(text: str) -> str:
    """返回显示提示文字的 SVG 占位图 data URI（常用文字走预计算常量）"""
    if text == '[Image not available]':
        return _PLACEHOLDER_IMAGE_NA
    if text == '[Conversion failed]':
        return _PLACEHOLDER_CONV_FAILED
    return 'data:image/svg+xml,' + urllib.parse.quote(
        _SVG_BASE.format(text=text), safe='')


def _emf_to_png_datauri(image_bytes: bytes) -> str:
    """将 EMF/WMF 字节数据转换为 PNG data URI（PIL on Windows 可通过 GDI 渲染元文件）"""
    import io
    from PIL import Image as PilImage
    try:
        with io.BytesIO(image_bytes) as buf:
            img = PilImage.open(buf)
            img.load()
            # 渲染到 RGBA 避免调色板模式导致的问题
            if img.mode not in ('RGB', 'RGBA'):
                img = img.convert('RGBA')
            out_buf = io.BytesIO()
            img.save(out_buf, format='PNG')
        b64 = base64.b64encode(out_buf.getvalue()).decode('ascii')
        return f'data:image/png;base64,{b64}'
    except Exception as e:
        logger.warning(f"EMF/WMF 转换失败: {e}")
        return _placeholder_svg('[EMF/WMF 图像 — 无法转换]')


def _docx_image_converter(image):
    """Mammoth 图片转换器：将图片转为 base64 data URI 嵌入 HTML"""
    content_type = image.content_type
    try:
        with image.open() as img_file:
            img_bytes = img_file.read()
    except Exception as e:
        logger.warning(f"DOCX 读取图片失败 ({content_type}): {e}")
        return {'src': _placeholder_svg('[图像读取失败]')}

    # EMF/WMF 需要转换；PIL on Windows 可通过 GDI 渲染，否则回退到占位图
    if content_type in ('image/x-emf', 'image/x-wmf'):
        if not PIL_AVAILABLE:
            return {'src': _placeholder_svg('[EMF/WMF 图像 — 需安装 Pillow]')}
        return {'src': _emf_to_png_datauri(img_bytes)}

    # 常规图片格式直接 base64 嵌入
    b64 = base64.b64encode(img_bytes).decode('ascii')
    return {'src': f'data:{content_type};base64,{b64}'}


# ——— EDDX → SVG 转换 ———

# EDDX 坐标单位：mm → SVG px（~3.78 px/mm @ 96dpi，取 4 便于整数对齐）
_EDDX_SCALE = 4.0

# 形状 NameU → SVG 渲染方式
_SHAPE_RENDERERS: dict[str, str] = {
    'Start or Terminator': 'pill',
    'Decision': 'diamond',
    'Process': 'rect',
    'Document': 'document',
    'Predefined Process': 'rect_sub',
}


def _eddx_parse_color(v: str) -> str:
    """EDDX ARGB 颜色 (#ff191919) → SVG 颜色 (#191919)"""
    v = (v or '').strip()
    if v.startswith('#') and len(v) >= 8:
        # #AARRGGBB → #RRGGBB（丢弃 Alpha）
        return '#' + v[3:]
    if v.startswith('#') and len(v) == 7:
        return v
    return '#333333'


def _eddx_shape_to_svg(shape_el, nums: dict[str, float], scale: float) -> str:
    """将单个 EDDX Shape 或 ConnectLine 转为 SVG 元素"""
    shape_type = shape_el.get('Type', 'Shape')
    name_u = shape_el.get('NameU', '')
    shape_id = shape_el.get('ID', '')

    # 连接线类型 — CPoints 为公式依赖的相对坐标，实际路径由 Connects 中心连线表示
    if shape_type == 'ConnectLine':
        return ''

    # 位置与尺寸
    tr = shape_el.find('Transform')
    w_mm = float((tr.find('Width').get('V', '0') if tr is not None and tr.find('Width') is not None else '0'))
    h_mm = float((tr.find('Height').get('V', '0') if tr is not None and tr.find('Height') is not None else '0'))
    w = w_mm * scale
    h = h_mm * scale
    gx = float((tr.find('GPinX').get('V', '0') if tr is not None and tr.find('GPinX') is not None else '0')) * scale
    gy = float((tr.find('GPinY').get('V', '0') if tr is not None and tr.find('GPinY') is not None else '0')) * scale
    lpx_el = tr.find('LocPinX')
    lpy_el = tr.find('LocPinY')
    lpx = _eddx_eval_cp_value(lpx_el, w_mm, h_mm) * scale if lpx_el is not None else 0.0
    lpy = _eddx_eval_cp_value(lpy_el, w_mm, h_mm) * scale if lpy_el is not None else 0.0
    angle = float((tr.find('Angle').get('V', '0') if tr is not None and tr.find('Angle') is not None else '0'))

    x = gx - lpx
    y = gy - lpy

    # 填充与描边
    sfmt = shape_el.find('ShapeFormat')
    fill_color = '#ffffff'
    stroke_color = '#333333'
    stroke_width = 1
    if sfmt is not None:
        ff = sfmt.find('FillFormat')
        if ff is not None:
            fc_el = ff.find('Color')
            if fc_el is not None:
                fill_color = _eddx_parse_color(fc_el.get('V', ''))
        lf = sfmt.find('LineFormat')
        if lf is not None:
            lw = lf.find('LineWeight')
            if lw is not None:
                stroke_width = float(lw.get('V', '1'))
            lfl = lf.find('LineFill')
            if lfl is not None:
                lc = lfl.find('Color')
                if lc is not None:
                    stroke_color = _eddx_parse_color(lc.get('V', ''))

    # 文本
    texts_el = shape_el.find('Texts')
    text_content = ''
    text_color = '#191919'
    font_size = 10
    font_family = 'Microsoft YaHei, sans-serif'
    if texts_el is not None:
        for txt in texts_el.findall('Text'):
            tb = txt.find('TextBlock')
            if tb is not None:
                col_el = tb.find('Color')
                if col_el is not None:
                    text_color = _eddx_parse_color(col_el.get('V', ''))
                ch = tb.find('Character')
                if ch is not None:
                    font_size = int(ch.get('Size', '10'))
                    font_family = ch.get('Family', 'Microsoft YaHei') + ', sans-serif'
                # 提取段落文本
                text_el = tb.find('Text')
                if text_el is not None:
                    paras = []
                    for pp in text_el.findall('pp'):
                        line_parts = []
                        for tp in pp.findall('tp'):
                            if tp.text:
                                line_parts.append(tp.text)
                        if line_parts:
                            paras.append(''.join(line_parts))
                    text_content = '<br/>'.join(paras)

    # 缩放文本（字体放大便于阅读）
    scaled_font_size = font_size * 5

    # 渲染图形
    renderer = _SHAPE_RENDERERS.get(name_u, 'rect')
    shape_svg = ''

    if renderer == 'pill':
        rx = min(w, h) / 2
        shape_svg = f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{rx:.1f}" fill="{fill_color}" stroke="{stroke_color}" stroke-width="{stroke_width}"/>'
    elif renderer == 'diamond':
        cx, cy = x + w / 2, y + h / 2
        pts = f'{cx:.1f},{y:.1f} {x+w:.1f},{cy:.1f} {cx:.1f},{y+h:.1f} {x:.1f},{cy:.1f}'
        shape_svg = f'<polygon points="{pts}" fill="{fill_color}" stroke="{stroke_color}" stroke-width="{stroke_width}"/>'
    elif renderer == 'document':
        curve_h = min(h * 0.08, 8)
        path = (f'M {x:.1f},{y:.1f} L {x+w:.1f},{y:.1f} L {x+w:.1f},{y+h-curve_h:.1f} '
                f'C {x+w:.1f},{y+h+curve_h:.1f} {x:.1f},{y+h+curve_h:.1f} {x:.1f},{y+h-curve_h:.1f} Z')
        shape_svg = f'<path d="{path}" fill="{fill_color}" stroke="{stroke_color}" stroke-width="{stroke_width}"/>'
    elif renderer == 'rect_sub':
        # 双边矩形（子流程样式）
        shape_svg = (f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" '
                     f'fill="{fill_color}" stroke="{stroke_color}" stroke-width="{stroke_width}"/>'
                     f'<line x1="{x+4:.1f}" y1="{y:.1f}" x2="{x+4:.1f}" y2="{y+h:.1f}" '
                     f'stroke="{stroke_color}" stroke-width="{stroke_width}"/>'
                     f'<line x1="{x+w-4:.1f}" y1="{y:.1f}" x2="{x+w-4:.1f}" y2="{y+h:.1f}" '
                     f'stroke="{stroke_color}" stroke-width="{stroke_width}"/>')
    else:
        shape_svg = f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" fill="{fill_color}" stroke="{stroke_color}" stroke-width="{stroke_width}"/>'

    # 文本
    text_svg = ''
    if text_content:
        text_x = x + w / 2
        text_y = y + h / 2
        text_svg = (f'<foreignObject x="{x+2:.1f}" y="{y+2:.1f}" width="{w-4:.1f}" height="{h-4:.1f}">'
                    f'<div xmlns="http://www.w3.org/1999/xhtml" style="display:table;width:100%;height:100%;'
                    f'color:{text_color};font-size:{scaled_font_size:.0f}px;font-family:{font_family};'
                    f'word-break:break-word;overflow-wrap:break-word;">'
                    f'<span style="display:table-cell;vertical-align:middle;text-align:left;'
                    f'line-height:1.3;padding-left:4px;">{text_content}</span>'
                    f'</div></foreignObject>')

    # 如果有旋转
    if abs(angle) > 0.01:
        cx, cy = x + w / 2, y + h / 2
        rot_attrs = f' transform="rotate({angle:.1f},{cx:.1f},{cy:.1f})"'
    else:
        rot_attrs = ''

    return f'<g id="shape-{shape_id}"{rot_attrs}>{shape_svg}{text_svg}</g>'


def _eddx_eval_cp_value(el, dim_w: float, dim_h: float) -> float:
    """计算 EDDX CPoint / LocPin 的实际值（考虑 R 比例和 M 基数）

    M="1" → 基数为 Width; M="2" → 基数为 Height; 无 M → 绝对值 (V)
    R 存在时: 实际值 = 基数 × R
    """
    v = float(el.get('V', '0'))
    r_str = el.get('R', '')
    m_str = el.get('M', '')
    if r_str and m_str:
        r = float(r_str)
        base = {'1': dim_w, '2': dim_h}.get(m_str, v)
        return base * r
    return v


def _eddx_shape_bounds(shape_el, scale: float) -> tuple[float, float, float, float] | None:
    """返回形状的包围盒 (x, y, w, h) 在 SVG 坐标系中，或 None"""
    tr = shape_el.find('Transform')
    if tr is None:
        return None
    w_mm = float((tr.find('Width').get('V', '0') if tr.find('Width') is not None else '0'))
    h_mm = float((tr.find('Height').get('V', '0') if tr.find('Height') is not None else '0'))
    gx_mm = float((tr.find('GPinX').get('V', '0') if tr.find('GPinX') is not None else '0'))
    gy_mm = float((tr.find('GPinY').get('V', '0') if tr.find('GPinY') is not None else '0'))
    lpx_el = tr.find('LocPinX')
    lpy_el = tr.find('LocPinY')
    lpx_mm = _eddx_eval_cp_value(lpx_el, w_mm, h_mm) if lpx_el is not None else 0.0
    lpy_mm = _eddx_eval_cp_value(lpy_el, w_mm, h_mm) if lpy_el is not None else 0.0
    return ((gx_mm - lpx_mm) * scale, (gy_mm - lpy_mm) * scale, w_mm * scale, h_mm * scale)


def _eddx_boundary_in_direction(shape_el, scale: float, dx: float, dy: float) -> tuple[float, float]:
    """计算从形状中心沿 (dx, dy) 方向与形状边界的交点"""
    bounds = _eddx_shape_bounds(shape_el, scale)
    if bounds is None:
        return (0, 0)
    x, y, w, h = bounds
    cx = x + w / 2
    cy = y + h / 2
    if abs(dx) < 0.001 and abs(dy) < 0.001:
        return (cx, cy)

    name_u = shape_el.get('NameU', '')
    if name_u == 'Decision':
        # 菱形: |x|/half_w + |y|/half_h = 1
        hw, hh = w / 2, h / 2
        t = 1.0 / (abs(dx) / hw + abs(dy) / hh)
    else:
        # 矩形: 到四条边的最小正 t
        hw, hh = w / 2, h / 2
        tx = hw / abs(dx) if abs(dx) > 0.001 else float('inf')
        ty = hh / abs(dy) if abs(dy) > 0.001 else float('inf')
        t = min(tx, ty)
    return (cx + dx * t, cy + dy * t)


def _eddx_get_cpoint_pos(shape_el, cp_id_or_name: str, scale: float) -> tuple[float, float] | None:
    """获取形状上指定 CPoint 在 SVG 坐标系中的绝对位置

    通过 CPoint 的 ID 或 Name 查找。
    """
    bounds = _eddx_shape_bounds(shape_el, scale)
    if bounds is None:
        return None
    sx, sy, sw, sh = bounds

    # 无 CPoint 信息时回退到形状中心
    tr = shape_el.find('Transform')
    w_mm = float((tr.find('Width').get('V', '0') if tr.find('Width') is not None else '0')) if tr is not None else 0
    h_mm = float((tr.find('Height').get('V', '0') if tr.find('Height') is not None else '0')) if tr is not None else 0

    cpoints = shape_el.find('CPoints')
    target_cp = None
    if cpoints is not None:
        for cp in cpoints.findall('CPoint'):
            if cp.get('ID', '') == cp_id_or_name or cp.get('Name', '') == cp_id_or_name:
                target_cp = cp
                break

    if target_cp is None:
        return None

    x_el = target_cp.find('X')
    y_el = target_cp.find('Y')
    cp_x_mm = _eddx_eval_cp_value(x_el, w_mm, h_mm) if x_el is not None else 0.0
    cp_y_mm = _eddx_eval_cp_value(y_el, w_mm, h_mm) if y_el is not None else 0.0

    # CPoint 在形状局部坐标中，转换为页面绝对坐标
    return (sx + cp_x_mm * scale, sy + cp_y_mm * scale)


def _eddx_page_to_svg(page_xml: str) -> str:
    """将 .eddx 的单页 XML 转换为 SVG 字符串"""
    import xml.etree.ElementTree as ET
    root = ET.fromstring(page_xml)

    # 页面尺寸
    pp = root.find('PageProps')
    pw = float((pp.find('Width').get('V', '210') if pp is not None and pp.find('Width') is not None else '210')) * _EDDX_SCALE
    ph = float((pp.find('Height').get('V', '297') if pp is not None and pp.find('Height') is not None else '297')) * _EDDX_SCALE

    # 收集所有形状的 ID 和 Connects（每个 ConnectLine 对应 2 个 Connect 指向两端的目标形状）
    shapes: dict[str, ET.Element] = {}
    # ConnectLine ID → [(target_shape_id, target_part, target_name), ...]
    connector_targets: dict[str, list[tuple[str, str, str]]] = {}

    for el in root:
        if el.tag == 'Shape' and el.get('Type') == 'Shape':
            sid = el.get('ID', '')
            shapes[sid] = el
        elif el.tag == 'Connects':
            for c in el.findall('Connect'):
                from_s = c.get('FromShape', '')
                to_s = c.get('ToShape', '')
                to_part = c.get('ToPart', '')
                to_name = c.get('ToName', '')
                if to_s:
                    connector_targets.setdefault(from_s, []).append((to_s, to_part, to_name))

    # 渲染形状
    svg_parts = []
    for sid, shape in shapes.items():
        nums = {}
        nums_el = shape.find('Numbers')
        if nums_el is not None:
            for n in nums_el.findall('Number'):
                for child in n:
                    if child.tag in ('X', 'Y', 'A', 'B'):
                        nums[child.tag] = float(child.get('V', '0'))

        svg_parts.append(_eddx_shape_to_svg(shape, nums, _EDDX_SCALE))

    # 渲染连接线：使用形状上的 CPoint 锚点
    connector_lines = []
    for connector_id, refs in connector_targets.items():
        if len(refs) < 2:
            continue

        # 对每个连续的目标形状对，找到它们各自的 CPoint 位置
        for j in range(len(refs) - 1):
            id1, part1, name1 = refs[j]
            id2, part2, name2 = refs[j + 1]
            if id1 not in shapes or id2 not in shapes:
                continue

            s1, s2 = shapes[id1], shapes[id2]

            # 尝试按 ToPart / ToName 找到 CPoint 位置
            pt1 = _eddx_get_cpoint_pos(s1, part1, _EDDX_SCALE) or _eddx_get_cpoint_pos(s1, name1, _EDDX_SCALE)
            pt2 = _eddx_get_cpoint_pos(s2, part2, _EDDX_SCALE) or _eddx_get_cpoint_pos(s2, name2, _EDDX_SCALE)

            # 回退：计算从中心指向对方方向的边界交点
            if pt1 is None or pt2 is None:
                b1 = _eddx_shape_bounds(s1, _EDDX_SCALE)
                b2 = _eddx_shape_bounds(s2, _EDDX_SCALE)
                if b1 and b2:
                    cx1 = b1[0] + b1[2] / 2
                    cy1 = b1[1] + b1[3] / 2
                    cx2 = b2[0] + b2[2] / 2
                    cy2 = b2[1] + b2[3] / 2
                    if pt1 is None:
                        pt1 = _eddx_boundary_in_direction(s1, _EDDX_SCALE, cx2 - cx1, cy2 - cy1)
                    if pt2 is None:
                        pt2 = _eddx_boundary_in_direction(s2, _EDDX_SCALE, cx1 - cx2, cy1 - cy2)

            x1, y1 = pt1
            x2, y2 = pt2
            connector_lines.append(
                f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                f'stroke="#666" stroke-width="1.5" marker-end="url(#arrowhead)"/>'
            )

    arrow_def = (
        '<defs><marker id="arrowhead" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">'
        '<polygon points="0 0, 8 3, 0 6" fill="#666"/></marker></defs>'
    )

    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {pw:.1f} {ph:.1f}" '
            f'width="{pw:.1f}" height="{ph:.1f}">'
            f'{arrow_def}'
            f'{"".join(svg_parts)}'
            f'{"".join(connector_lines)}'
            f'</svg>')


class PreviewMixin:
    """预览功能方法（图片、视频、音频、PDF、Office文档、文本、Markdown、HTML、XMind、JSON）"""

    config = None
    session_manager = None
    user_store = None
    access_logger = None

    def _log_preview(self, file_path_rel: str) -> None:
        """记录预览访问日志"""
        if self.access_logger:
            username = self.get_current_username() or 'Unknown'
            client_ip = self.client_address[0]
            self.access_logger.log(username, 'preview', file_path_rel, client_ip=client_ip)

    def _handle_preview(self) -> None:
        """处理文件预览请求"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            self.send_error(403, "Forbidden")
            return

        file_path_rel = self.path[len('/preview/'):].lstrip('/')
        file_path_rel = urllib.parse.unquote(file_path_rel)
        file_path = Path(self.directory) / file_path_rel

        from .utils import _is_safe_path
        if not _is_safe_path(Path(self.directory), file_path):
            self.send_error(403, "Forbidden")
            return

        if not file_path.exists() or not file_path.is_file():
            self.send_error(404, "File not found")
            return

        # 检查读权限（仅在有 user_store 时进行）
        try:
            if self.user_store:
                user_data = self.user_store.get_user(username)
                if user_data:
                    default_perm = self.config.default_permission if self.config else "rw"
                    if not check_permission(user_data, file_path_rel, PERM_READ, default_perm):
                        logger.warning(f"权限不足(读) - 用户: {username}, 路径: {file_path_rel}")
                        self.send_error(403, "Forbidden")
                        return
        except Exception:
            pass  # 权限检查异常时放行，避免阻塞正常预览

        file_name = file_path.name
        file_type = detect_file_type(file_name)

        self._log_preview(file_path_rel)

        if file_type == 'image':
            self._handle_image_preview(username, file_path_rel, file_name)
        elif file_type == 'video':
            self._handle_video_preview(username, file_path_rel, file_name)
        elif file_type == 'audio':
            self._handle_audio_preview(username, file_path_rel, file_name)
        elif file_type == 'pdf':
            self._handle_pdf_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'markdown':
            self._handle_markdown_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'xmind':
            self._handle_xmind_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'drawio':
            self._handle_drawio_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'eddx':
            self._handle_eddx_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'docx':
            self._handle_docx_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'xlsx':
            self._handle_xlsx_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'pptx':
            self._handle_pptx_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'json':
            self._handle_json_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'text':
            ext = os.path.splitext(file_name)[1].lower()
            if ext in ('.html', '.htm'):
                self._handle_html_preview(username, file_path_rel, file_name, file_path)
            else:
                self._handle_text_preview(username, file_path_rel, file_name, file_path)
        else:
            self._serve_raw_file(file_path)

    def _handle_media_preview(self, username: str, file_path_rel: str, file_name: str,
                              media_type: str, render_func) -> None:
        """通用媒体预览（图片/视频/音频）"""
        parent_dir = (Path(self.directory) / file_path_rel).parent
        media_urls = []
        current_index = 0

        try:
            for f in sorted(os.listdir(parent_dir)):
                if not f.startswith('.') and os.path.isfile(os.path.join(parent_dir, f)):
                    if detect_file_type(f) == media_type:
                        rel = os.path.join(os.path.dirname(file_path_rel), f) if os.path.dirname(file_path_rel) else f
                        media_urls.append(rel)
                        if f == file_name:
                            current_index = len(media_urls) - 1
        except OSError:
            media_urls = [file_path_rel]
            current_index = 0

        is_admin = False
        if self.user_store:
            is_admin = self.user_store.is_admin(username)
        html = render_func(username, file_path_rel, file_name, media_urls, current_index, is_admin=is_admin)
        self._send_html_response(html)

    def _handle_image_preview(self, username: str, file_path_rel: str, file_name: str) -> None:
        """图片预览"""
        from ..template import render_image_preview_page
        self._handle_media_preview(username, file_path_rel, file_name, 'image', render_image_preview_page)

    def _handle_video_preview(self, username: str, file_path_rel: str, file_name: str) -> None:
        """视频预览"""
        from ..template import render_video_preview_page
        self._handle_media_preview(username, file_path_rel, file_name, 'video', render_video_preview_page)

    def _handle_audio_preview(self, username: str, file_path_rel: str, file_name: str) -> None:
        """音频预览"""
        from ..template import render_audio_preview_page
        self._handle_media_preview(username, file_path_rel, file_name, 'audio', render_audio_preview_page)

    def _handle_pdf_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """PDF 预览"""
        try:
            if file_path.stat().st_size > 50 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 50MB）')
                return

            from ..template import render_pdf_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_pdf_preview_page(username, file_path_rel, file_name, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"PDF 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_docx_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """Word 文档预览（使用 Mammoth 转换为 HTML）"""
        try:
            if file_path.stat().st_size > 50 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 50MB）')
                return

            from ..template import render_docx_preview_page

            rendered_html = ''
            if MAMMOTH_AVAILABLE:
                try:
                    with open(file_path, 'rb') as f:
                        result = mammoth.convert_to_html(
                            f,
                            convert_image=mammoth.images.img_element(_docx_image_converter),
                        )
                    rendered_html = result.value
                    if result.messages:
                        logger.warning(f"Mammoth 转换警告: {result.messages}")
                except Exception as e:
                    logger.warning(f"DOCX 解析出错: {e}")
                    rendered_html = '<div class="error-msg">文档解析失败</div>'
            else:
                rendered_html = _render_office_unavailable('Word (.docx)')

            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_docx_preview_page(username, file_path_rel, file_name, rendered_html, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"DOCX 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_xlsx_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """Excel 表格预览（使用 Spire.Xls 转换为 HTML）"""
        try:
            if file_path.stat().st_size > 50 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 50MB）')
                return

            from ..template import render_xlsx_preview_page

            rendered_html = ''
            sheet_names = []
            if XLSX_AVAILABLE:
                try:
                    wb = Workbook()
                    wb.LoadFromFile(str(file_path))
                    sheet_names = [wb.Worksheets[i].Name for i in range(wb.Worksheets.Count)]
                    parts = []
                    for i, name in enumerate(sheet_names):
                        stream = XlsStream()
                        wb.Worksheets[i].SaveToHtml(stream)
                        table_html = bytes(stream.ToArray()).decode('utf-8')
                        stream.Close()
                        active = 'active' if i == 0 else ''
                        parts.append(f'<div class="sheet-pane {active}" id="sheet-{i}">')
                        parts.append(f'<div class="table-wrapper">{table_html}</div>')
                        parts.append('</div>')
                    rendered_html = '\n'.join(parts)
                    wb.Dispose()
                except Exception as e:
                    logger.warning(f"XLSX 解析出错: {e}")
                    err_msg = str(e)
                    if 'Cannot found font' in err_msg:
                        rendered_html = (
                            '<div class="error-msg" style="padding:20px;line-height:1.8;">'
                            '<h3>Excel 预览需要系统字体支持</h3>'
                            '<p>Spire.Xls 渲染表格需要系统安装 TrueType 字体。</p>'
                            '<p><b>Debian/Ubuntu:</b><br>'
                            '<code>sudo apt install ttf-mscorefonts-installer</code><br>'
                            '或使用内置替代字体：<code>sudo apt install fonts-liberation</code></p>'
                            '<p><b>CentOS/RHEL:</b><br>'
                            '<code>sudo yum install liberation-fonts</code></p>'
                            '<p><b>通用方案:</b><br>手动复制 .ttf 文件到 <code>/usr/share/fonts/truetype/</code>，然后运行'
                            '<code>fc-cache -fv</code></p>'
                            '</div>'
                        )
                    else:
                        rendered_html = '<div class="error-msg">表格解析失败</div>'
            else:
                rendered_html = _render_office_unavailable('Excel (.xlsx)')

            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_xlsx_preview_page(username, file_path_rel, file_name, rendered_html, sheet_names, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"XLSX 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_pptx_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """PowerPoint 演示文稿预览（使用 Spire.Presentation 转换为 HTML，iframe 嵌入）"""
        import tempfile

        try:
            if file_path.stat().st_size > 50 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 50MB）')
                return

            from ..template import render_pptx_preview_page

            slide_htmls = []
            slide_count = 0
            if PPTX_AVAILABLE:
                try:
                    ppt = Presentation()
                    ppt.LoadFromFile(str(file_path))
                    slide_count = ppt.Slides.Count
                    with tempfile.TemporaryDirectory() as tmpdir:
                        for i in range(slide_count):
                            tmp_path = os.path.join(tmpdir, f'slide_{i}.html')
                            ppt.Slides[i].SaveToFile(tmp_path, FileFormat.Html)
                            with open(tmp_path, 'r', encoding='utf-8') as f:
                                slide_htmls.append(f.read())
                    ppt.Dispose()
                except Exception as e:
                    logger.warning(f"PPTX 解析出错: {e}")
                    err_msg = str(e)
                    if 'Cannot found font' in err_msg:
                        slide_htmls.append(
                            '<div class="error-msg" style="padding:40px;text-align:center;line-height:1.8;">'
                            '<h3>PPT 预览需要系统字体支持</h3>'
                            '<p>Spire.Presentation 渲染幻灯片需要系统安装 TrueType 字体。</p>'
                            '<p><b>Debian/Ubuntu:</b><br>'
                            '<code>sudo apt install ttf-mscorefonts-installer</code></p>'
                            '<p><b>CentOS/RHEL:</b><br>'
                            '<code>sudo yum install liberation-fonts</code></p>'
                            '<p><b>通用方案:</b><br>手动复制 .ttf 文件到 <code>/usr/share/fonts/truetype/</code></p>'
                            '</div>'
                        )

            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_pptx_preview_page(username, file_path_rel, file_name, slide_htmls, slide_count, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"PPTX 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_text_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """文本/代码预览"""
        try:
            if file_path.stat().st_size > 5 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 5MB）')
                return

            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()

            ext = os.path.splitext(file_name)[1].lower()
            lang_map = {
                '.py': 'python', '.js': 'javascript', '.ts': 'typescript',
                '.java': 'java', '.c': 'c', '.cpp': 'cpp', '.h': 'c',
                '.hpp': 'cpp', '.cs': 'csharp', '.go': 'go', '.rs': 'rust',
                '.rb': 'ruby', '.php': 'php', '.swift': 'swift',
                '.html': 'html', '.htm': 'html', '.css': 'css',
                '.scss': 'scss', '.xml': 'xml', '.sql': 'sql',
                '.sh': 'bash', '.bash': 'bash', '.yaml': 'yaml', '.yml': 'yaml',
                '.toml': 'toml', '.json': 'json', '.ini': 'ini',
                '.cfg': 'ini', '.conf': 'ini',
            }
            language = lang_map.get(ext, 'plaintext')

            from ..template import render_text_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_text_preview_page(username, file_path_rel, file_name, content, language, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"文本预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_markdown_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """Markdown 预览"""
        try:
            if file_path.stat().st_size > 5 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 5MB）')
                return

            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()

            rendered_html = ''
            if MARKDOWN_AVAILABLE:
                try:
                    # Extract Mermaid blocks before rendering (codehilite can't handle them)
                    mermaid_blocks = []
                    def _save_mermaid(m):
                        mermaid_blocks.append(m.group(1))
                        return f'<!--MERMAID_{len(mermaid_blocks) - 1}-->'
                    import re
                    content = re.sub(r'```mermaid\s*\n(.*?)```', _save_mermaid, content, flags=re.DOTALL)

                    rendered_html = _markdown.markdown(
                        content,
                        extensions=['extra', 'codehilite', 'tables', 'fenced_code'],
                        extension_configs={'codehilite': {'css_class': 'highlight'}}
                    )

                    # Restore Mermaid blocks as proper divs
                    for i, src in enumerate(mermaid_blocks):
                        escaped = src.strip().replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
                        replacement = f'<div class="mermaid-container"><div class="mermaid">{escaped}</div></div>'
                        rendered_html = rendered_html.replace(f'<!--MERMAID_{i}-->', replacement)

                    rendered_html = _render_task_lists(rendered_html)
                except Exception as e:
                    logger.warning(f"Markdown 渲染出错，使用备用方案: {e}")
                    from ..template import _escape_html
                    rendered_html = f'<pre style="white-space: pre-wrap; word-wrap: break-word;">{_escape_html(content)}</pre>'
            else:
                from ..template import _escape_html
                rendered_html = f'<pre style="white-space: pre-wrap; word-wrap: break-word;">{_escape_html(content)}</pre>'

            from ..template import render_markdown_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_markdown_preview_page(username, file_path_rel, file_name, content, rendered_html, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"Markdown 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_html_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """HTML 预览"""
        try:
            if file_path.stat().st_size > 5 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 5MB）')
                return

            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()

            from ..template import render_html_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_html_preview_page(username, file_path_rel, file_name, content, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"HTML 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_xmind_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """XMind 预览"""
        try:
            if file_path.stat().st_size > 10 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 10MB）')
                return

            content_json = ''
            try:
                with zipfile.ZipFile(file_path, 'r') as zf:
                    if 'content.json' in zf.namelist():
                        with zf.open('content.json') as cf:
                            raw_data = cf.read().decode('utf-8', errors='replace')
                            try:
                                parsed = json.loads(raw_data)
                                content_json = json.dumps(parsed, indent=2, ensure_ascii=False)
                            except json.JSONDecodeError:
                                content_json = raw_data
                    else:
                        file_list = '\\n'.join(zf.namelist())
                        content_json = f"# XMind 文件结构\\n\\n此 XMind 文件包含以下文件:\\n\\n{file_list}\\n\\n注意: 未找到 content.json，可能是旧版 XMind 格式。"
            except zipfile.BadZipFile:
                content_json = "# 错误\\n\\n此文件不是有效的 ZIP 格式，可能已损坏或不是真正的 XMind 文件。"
            except Exception as e:
                content_json = f"# 读取错误\\n\\n无法读取 XMind 文件内容: {str(e)}"

            from ..template import render_xmind_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_xmind_preview_page(username, file_path_rel, file_name, content_json, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"XMind 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_json_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """JSON 预览"""
        try:
            if file_path.stat().st_size > 5 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 5MB）')
                return

            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()

            formatted_json = content
            try:
                json_data = json.loads(content)
                formatted_json = json.dumps(json_data, indent=2, ensure_ascii=False)
            except json.JSONDecodeError:
                pass

            from ..template import render_json_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_json_preview_page(username, file_path_rel, file_name, content, formatted_json, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"JSON 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")


    def _handle_drawio_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """Draw.io 图表预览"""
        import xml.etree.ElementTree as ET
        try:
            if file_path.stat().st_size > 10 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 10MB）')
                return

            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                raw_xml = f.read()

            diagrams = []
            try:
                root = ET.fromstring(raw_xml)
                for diag_el in root.findall('diagram'):
                    name = diag_el.get('name', '')
                    # 图表内容是 mxGraphModel XML（作为文本节点存储在 <diagram> 中）
                    inner = diag_el.text or ''
                    # 尝试提取完整的 mxGraphModel
                    inner = inner.strip()
                    diagrams.append({'name': name, 'xml': inner})
            except ET.ParseError:
                pass

            if not diagrams:
                # 如果无法解析到 diagram，整体当作一个图表显示
                diagrams = [{'name': 'Diagram', 'xml': raw_xml}]

            from ..template import render_drawio_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_drawio_preview_page(username, file_path_rel, file_name, raw_xml, diagrams, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"Draw.io 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_eddx_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """Edraw Max (.eddx) 图表预览 → 渲染为 SVG"""
        import xml.etree.ElementTree as ET
        try:
            if file_path.stat().st_size > 20 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 20MB）')
                return

            pages = []
            page_svgs = []
            page_xmls = []
            try:
                with zipfile.ZipFile(file_path, 'r') as zf:
                    page_files = sorted([
                        n for n in zf.namelist()
                        if n.endswith('.xml') and n.startswith('pages/')
                    ])
                    if not page_files:
                        file_list = '\n'.join(zf.namelist())
                        pages = [{'name': '文件结构'}]
                        page_svgs = ['']
                        page_xmls = [file_list]
                    else:
                        for pf in page_files:
                            raw = zf.read(pf).decode('utf-8', errors='replace')
                            page_name = pf.rsplit('/', 1)[-1].replace('.xml', '')
                            pages.append({'name': page_name})
                            # 生成 SVG
                            try:
                                svg_str = _eddx_page_to_svg(raw)
                                page_svgs.append(svg_str)
                            except Exception as svg_err:
                                logger.warning(f"EDDX 页面 {page_name} SVG 转换失败: {svg_err}")
                                page_svgs.append('')
                            # 保留原始 XML 用于源码视图
                            try:
                                parsed = ET.fromstring(raw)
                                ET.indent(parsed, space='  ')
                                page_xmls.append(ET.tostring(parsed, encoding='unicode'))
                            except ET.ParseError:
                                page_xmls.append(raw)
            except zipfile.BadZipFile:
                pages = [{'name': '错误'}]
                page_svgs = ['']
                page_xmls = ['此文件不是有效的 ZIP 格式，可能已损坏或不是真正的 .eddx 文件。']
            except Exception as e:
                pages = [{'name': '错误'}]
                page_svgs = ['']
                page_xmls = [f'无法读取 .eddx 文件内容: {str(e)}']

            from ..template import render_eddx_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_eddx_preview_page(
                username, file_path_rel, file_name,
                pages, page_svgs, page_xmls,
                is_admin=is_admin,
            )
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"Eddx 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")


__all__ = [
    '_render_task_lists',
    '_render_office_unavailable',
    '_placeholder_svg',
    '_docx_image_converter',
    '_eddx_page_to_svg',
    'PreviewMixin',
]
