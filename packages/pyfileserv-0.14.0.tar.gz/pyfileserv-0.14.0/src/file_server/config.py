"""配置模块"""
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Dict, Any

# 可选的 ipaddress 模块支持
_ipaddress_available = False
_ipaddress = None
try:
    import ipaddress
    _ipaddress = ipaddress
    _ipaddress_available = True
except ImportError:
    pass

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

# 密码最小长度
MIN_PASSWORD_LENGTH = 6


@dataclass
class RedisConfig:
    """Redis 配置"""
    # 是否启用 Redis
    enabled: bool = False

    # Redis 连接配置
    host: str = "localhost"
    port: int = 6379
    db: int = 0
    password: Optional[str] = None

    # 键前缀（用于隔离不同应用的数据）
    key_prefix: str = "pyfileserv:session:"

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "enabled": self.enabled,
            "host": self.host,
            "port": self.port,
            "db": self.db,
            "password": self.password,
            "key_prefix": self.key_prefix,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RedisConfig":
        """从字典创建"""
        return cls(
            enabled=data.get("enabled", False),
            host=data.get("host", "localhost"),
            port=data.get("port", 6379),
            db=data.get("db", 0),
            password=data.get("password"),
            key_prefix=data.get("key_prefix", "pyfileserv:session:"),
        )


@dataclass
class DatabaseConfig:
    """数据库配置"""
    # 数据库类型：'json' (文件) 或 'postgres'
    type: str = "json"

    # PostgreSQL 配置
    host: str = "localhost"
    port: int = 5432
    database: str = "pyfileserv"
    username: Optional[str] = None
    password: Optional[str] = None

    # 连接池配置
    pool_size: int = 5
    max_overflow: int = 10

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "type": self.type,
            "host": self.host,
            "port": self.port,
            "database": self.database,
            "username": self.username,
            "password": self.password,
            "pool_size": self.pool_size,
            "max_overflow": self.max_overflow,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DatabaseConfig":
        """从字典创建"""
        return cls(
            type=data.get("type", "json"),
            host=data.get("host", "localhost"),
            port=data.get("port", 5432),
            database=data.get("database", "pyfileserv"),
            username=data.get("username"),
            password=data.get("password"),
            pool_size=data.get("pool_size", 5),
            max_overflow=data.get("max_overflow", 10),
        )


@dataclass
class ServerConfig:
    """服务器配置"""
    # 服务配置
    port: int = 8000
    host: str = ""
    workers: int = 0  # 工作线程数，0 = CPU 核数 × 2

    # SSL/HTTPS 配置
    ssl_cert: Optional[Path] = None
    ssl_key: Optional[Path] = None

    # 路径配置
    config_dir: Optional[Path] = None
    static_dir: Optional[Path] = None
    serve_dir: Optional[Path] = None

    # 用户文件（仅用于 JSON 存储）
    users_file: str = "users.json"

    # 数据库配置
    database: DatabaseConfig = field(default_factory=DatabaseConfig)

    # 会话配置
    session_timeout: int = 3600  # 秒 (1小时)
    session_storage: str = "memory"  # 会话存储方式: 'memory' 或 'redis'

    # Redis 配置（当 session_storage='redis' 时使用）
    redis: RedisConfig = field(default_factory=RedisConfig)

    # 密码哈希配置
    bcrypt_rounds: int = 12

    # 登录保护配置
    login_max_attempts: int = 5  # 最大失败尝试次数
    login_lockout_duration: int = 900  # 锁定时长（秒），默认 15 分钟

    # 上传配置
    max_upload_size_mb: int = 100  # 最大上传大小 (MB)

    # 日志配置
    log_file: Optional[Path] = None  # None → 使用 serve_dir/pyfileserv.log

    # 访问日志配置
    access_log_enabled: bool = True
    access_log_file: Optional[Path] = None  # None → 使用 serve_dir/access.log
    access_log_max_size_mb: int = 10  # 轮转大小阈值 (MB)
    access_log_keep: int = 7  # 保留旧文件数量

    # IP 限制配置
    ip_whitelist: list = field(default_factory=list)
    ip_blacklist: list = field(default_factory=list)

    # 权限配置
    default_permission: str = "rw"  # 默认权限：rw（读写）或 r（只读）

    @property
    def use_https(self) -> bool:
        """是否启用 HTTPS"""
        return self.ssl_cert is not None and self.ssl_key is not None

    @property
    def use_database(self) -> bool:
        """是否使用数据库存储"""
        return self.database.type != "json"

    def is_ip_allowed(self, client_ip: str) -> bool:
        """检查客户端 IP 是否允许访问

        Args:
            client_ip: 客户端 IP 地址

        Returns:
            是否允许访问
        """
        # 如果白名单和黑名单都为空，允许所有 IP
        if not self.ip_whitelist and not self.ip_blacklist:
            return True

        # 如果有白名单，只允许白名单中的 IP
        if self.ip_whitelist:
            return self._ip_in_list(client_ip, self.ip_whitelist)

        # 如果只有黑名单，检查 IP 是否在黑名单中
        if self.ip_blacklist:
            return not self._ip_in_list(client_ip, self.ip_blacklist)

        return True

    def _ip_in_list(self, client_ip: str, ip_list: list) -> bool:
        """检查 IP 是否在列表中（支持 CIDR 格式）

        Args:
            client_ip: 客户端 IP 地址
            ip_list: IP 列表（包含单个 IP 或 CIDR 格式）

        Returns:
            是否匹配
        """
        if not ip_list:
            return False

        # 如果 ipaddress 模块不可用，只进行简单的字符串匹配
        if not _ipaddress_available:
            return client_ip in ip_list

        try:
            ip_obj = _ipaddress.ip_address(client_ip)
            for ip_or_cidr in ip_list:
                try:
                    if "/" in ip_or_cidr:
                        network = _ipaddress.ip_network(ip_or_cidr, strict=False)
                        if ip_obj in network:
                            return True
                    else:
                        if str(ip_obj) == ip_or_cidr:
                            return True
                except ValueError:
                    continue
        except ValueError:
            return False

        return False

    def get_users_file_path(self) -> Path:
        """获取用户文件完整路径"""
        if self.config_dir:
            return self.config_dir / self.users_file
        return Path(self.users_file)

    def get_config_file_path(self) -> Optional[Path]:
        """获取配置文件路径"""
        if self.config_dir:
            return self.config_dir / "config.yml"
        # 检查常见位置
        locations = [
            Path("config.yml"),
            Path("config.yaml"),
            Path.home() / ".pyfileserv" / "config.yml",
            Path("/etc/pyfileserv/config.yml"),
        ]
        for loc in locations:
            if loc.exists():
                return loc
        return None

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典（用于保存到 YAML）"""
        result = {
            "server": {
                "port": self.port,
                "host": self.host,
                "workers": self.workers,
            },
            "paths": {
                "serve_dir": str(self.serve_dir) if self.serve_dir else None,
                "static_dir": str(self.static_dir) if self.static_dir else None,
                "users_file": self.users_file,
                "log_file": str(self.log_file) if self.log_file else None,
            },
            "ssl": {
                "cert_file": str(self.ssl_cert) if self.ssl_cert else None,
                "key_file": str(self.ssl_key) if self.ssl_key else None,
            },
            "database": self.database.to_dict(),
            "session": {
                "timeout": self.session_timeout,
                "storage": self.session_storage,
            },
            "redis": self.redis.to_dict() if self.session_storage == "redis" else None,
            "security": {
                "bcrypt_rounds": self.bcrypt_rounds,
                "login_max_attempts": self.login_max_attempts,
                "login_lockout_duration": self.login_lockout_duration,
            },
            "ip_restriction": {
                "whitelist": self.ip_whitelist,
                "blacklist": self.ip_blacklist,
            },
            "permissions": {
                "default_permission": self.default_permission,
            },
            "access_log": {
                "enabled": self.access_log_enabled,
                "log_file": str(self.access_log_file) if self.access_log_file else None,
                "max_size_mb": self.access_log_max_size_mb,
                "keep": self.access_log_keep,
            },
        }
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ServerConfig":
        """从字典创建配置"""
        config = cls()

        # 服务配置
        if "server" in data:
            server = data["server"]
            config.port = server.get("port", 8000)
            config.host = server.get("host", "")
            config.workers = server.get("workers", 0)

        # 路径配置
        if "paths" in data:
            paths = data["paths"]
            if paths.get("serve_dir"):
                config.serve_dir = Path(paths["serve_dir"])
            if paths.get("static_dir"):
                config.static_dir = Path(paths["static_dir"])
            config.users_file = paths.get("users_file", "users.json")
            if paths.get("log_file"):
                config.log_file = Path(paths["log_file"])

        # SSL 配置
        if "ssl" in data:
            ssl = data["ssl"]
            if ssl.get("cert_file"):
                config.ssl_cert = Path(ssl["cert_file"])
            if ssl.get("key_file"):
                config.ssl_key = Path(ssl["key_file"])

        # 数据库配置
        if "database" in data:
            config.database = DatabaseConfig.from_dict(data["database"])

        # 会话配置
        if "session" in data:
            config.session_timeout = data["session"].get("timeout", 3600)
            config.session_storage = data["session"].get("storage", "memory")

        # Redis 配置（仅当 session_storage='redis' 时加载）
        if config.session_storage == "redis" and "redis" in data:
            config.redis = RedisConfig.from_dict(data["redis"])

        # 安全配置
        if "security" in data:
            config.bcrypt_rounds = data["security"].get("bcrypt_rounds", 12)
            config.login_max_attempts = data["security"].get("login_max_attempts", 5)
            config.login_lockout_duration = data["security"].get("login_lockout_duration", 900)

        # IP 限制配置
        if "ip_restriction" in data:
            ip_restriction = data["ip_restriction"]
            config.ip_whitelist = ip_restriction.get("whitelist", [])
            config.ip_blacklist = ip_restriction.get("blacklist", [])

        # 权限配置
        if "permissions" in data:
            config.default_permission = data["permissions"].get("default_permission", "rw")

        # 访问日志配置
        if "access_log" in data:
            alog = data["access_log"]
            config.access_log_enabled = alog.get("enabled", True)
            if alog.get("log_file"):
                config.access_log_file = Path(alog["log_file"])
            config.access_log_max_size_mb = alog.get("max_size_mb", 10)
            config.access_log_keep = alog.get("keep", 7)

        return config

    @classmethod
    def from_yaml(cls, path: Path) -> "ServerConfig":
        """从 YAML 文件加载配置"""
        if not YAML_AVAILABLE:
            raise ImportError("pyyaml is required to load YAML config files. "
                            "Install it with: pip install pyyaml")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        config = cls.from_dict(data)
        config.config_dir = path.parent

        # 将相对路径转换为相对于配置文件目录的绝对路径
        config_dir = path.parent
        if config.ssl_cert and not config.ssl_cert.is_absolute():
            config.ssl_cert = config_dir / config.ssl_cert
        if config.ssl_key and not config.ssl_key.is_absolute():
            config.ssl_key = config_dir / config.ssl_key
        if config.serve_dir and not config.serve_dir.is_absolute():
            config.serve_dir = config_dir / config.serve_dir
        if config.static_dir and not config.static_dir.is_absolute():
            config.static_dir = config_dir / config.static_dir
        if config.log_file and not config.log_file.is_absolute():
            config.log_file = config_dir / config.log_file

        return config

    def save_yaml(self, path: Path) -> None:
        """保存配置到 YAML 文件"""
        if not YAML_AVAILABLE:
            raise ImportError("pyyaml is required to save YAML config files. "
                            "Install it with: pip install pyyaml")

        data = self.to_dict()
        with open(path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)

    @classmethod
    def from_args(cls, port: int = 8000, directory: str = ".",
                  config_dir: Optional[str] = None,
                  static_dir: Optional[str] = None,
                  ssl_cert: Optional[str] = None,
                  ssl_key: Optional[str] = None,
                  config_file: Optional[str] = None) -> "ServerConfig":
        """从命令行参数创建配置

        优先级: 命令行参数 > 配置文件 > 环境变量 > 默认值
        """
        # 1. 首先尝试加载配置文件
        config = cls()

        if config_file:
            config_path = Path(config_file)
            if config_path.exists():
                config = cls.from_yaml(config_path)
                config.config_dir = config_path.parent
        elif config_dir:
            config.config_dir = Path(config_dir)
            config_path = config.get_config_file_path()
            if config_path and config_path.exists():
                config = cls.from_yaml(config_path)
                config.config_dir = config_path.parent
        else:
            # 检查默认配置文件位置
            config_path = config.get_config_file_path()
            if config_path and config_path.exists():
                config = cls.from_yaml(config_path)
                config.config_dir = config_path.parent

        # 2. 从环境变量加载
        config.load_from_env()

        # 3. 命令行参数覆盖
        if port != 8000:
            config.port = port
        if directory != ".":
            config.serve_dir = Path(directory)
        if config_dir:
            config.config_dir = Path(config_dir)
        if static_dir:
            config.static_dir = Path(static_dir)
        if ssl_cert:
            config.ssl_cert = Path(ssl_cert)
        if ssl_key:
            config.ssl_key = Path(ssl_key)

        return config

    def load_from_env(self) -> None:
        """从环境变量加载配置（修改当前对象）"""
        # 服务配置
        if "PYFILESERV_PORT" in os.environ:
            self.port = int(os.environ["PYFILESERV_PORT"])
        if "PYFILESERV_HOST" in os.environ:
            self.host = os.environ["PYFILESERV_HOST"]
        if "PYFILESERV_WORKERS" in os.environ:
            self.workers = int(os.environ["PYFILESERV_WORKERS"])

        # 路径配置
        if "PYFILESERV_SERVE_DIR" in os.environ:
            self.serve_dir = Path(os.environ["PYFILESERV_SERVE_DIR"])
        if "PYFILESERV_STATIC_DIR" in os.environ:
            self.static_dir = Path(os.environ["PYFILESERV_STATIC_DIR"])
        if "PYFILESERV_USERS_FILE" in os.environ:
            self.users_file = os.environ["PYFILESERV_USERS_FILE"]
        if "PYFILESERV_LOG_FILE" in os.environ:
            self.log_file = Path(os.environ["PYFILESERV_LOG_FILE"])

        # SSL 配置
        if "PYFILESERV_SSL_CERT" in os.environ:
            self.ssl_cert = Path(os.environ["PYFILESERV_SSL_CERT"])
        if "PYFILESERV_SSL_KEY" in os.environ:
            self.ssl_key = Path(os.environ["PYFILESERV_SSL_KEY"])

        # 数据库配置
        if "PYFILESERV_DB_TYPE" in os.environ:
            self.database.type = os.environ["PYFILESERV_DB_TYPE"]
        if "PYFILESERV_DB_HOST" in os.environ:
            self.database.host = os.environ["PYFILESERV_DB_HOST"]
        if "PYFILESERV_DB_PORT" in os.environ:
            self.database.port = int(os.environ["PYFILESERV_DB_PORT"])
        if "PYFILESERV_DB_NAME" in os.environ:
            self.database.database = os.environ["PYFILESERV_DB_NAME"]
        if "PYFILESERV_DB_USER" in os.environ:
            self.database.username = os.environ["PYFILESERV_DB_USER"]
        if "PYFILESERV_DB_PASSWORD" in os.environ:
            self.database.password = os.environ["PYFILESERV_DB_PASSWORD"]

        # 会话配置
        if "PYFILESERV_SESSION_TIMEOUT" in os.environ:
            self.session_timeout = int(os.environ["PYFILESERV_SESSION_TIMEOUT"])
        if "PYFILESERV_SESSION_STORAGE" in os.environ:
            self.session_storage = os.environ["PYFILESERV_SESSION_STORAGE"]

        # Redis 配置
        if "PYFILESERV_REDIS_ENABLED" in os.environ:
            self.redis.enabled = os.environ["PYFILESERV_REDIS_ENABLED"].lower() in ("true", "1", "yes")
        if "PYFILESERV_REDIS_HOST" in os.environ:
            self.redis.host = os.environ["PYFILESERV_REDIS_HOST"]
        if "PYFILESERV_REDIS_PORT" in os.environ:
            self.redis.port = int(os.environ["PYFILESERV_REDIS_PORT"])
        if "PYFILESERV_REDIS_DB" in os.environ:
            self.redis.db = int(os.environ["PYFILESERV_REDIS_DB"])
        if "PYFILESERV_REDIS_PASSWORD" in os.environ:
            self.redis.password = os.environ["PYFILESERV_REDIS_PASSWORD"]
        if "PYFILESERV_REDIS_KEY_PREFIX" in os.environ:
            self.redis.key_prefix = os.environ["PYFILESERV_REDIS_KEY_PREFIX"]

        # 安全配置
        if "PYFILESERV_BCRYPT_ROUNDS" in os.environ:
            self.bcrypt_rounds = int(os.environ["PYFILESERV_BCRYPT_ROUNDS"])
        if "PYFILESERV_LOGIN_MAX_ATTEMPTS" in os.environ:
            self.login_max_attempts = int(os.environ["PYFILESERV_LOGIN_MAX_ATTEMPTS"])
        if "PYFILESERV_LOGIN_LOCKOUT_DURATION" in os.environ:
            self.login_lockout_duration = int(os.environ["PYFILESERV_LOGIN_LOCKOUT_DURATION"])

        # IP 限制配置
        if "PYFILESERV_IP_WHITELIST" in os.environ:
            self.ip_whitelist = [ip.strip() for ip in os.environ["PYFILESERV_IP_WHITELIST"].split(",") if ip.strip()]
        if "PYFILESERV_IP_BLACKLIST" in os.environ:
            self.ip_blacklist = [ip.strip() for ip in os.environ["PYFILESERV_IP_BLACKLIST"].split(",") if ip.strip()]

        # 权限配置
        if "PYFILESERV_DEFAULT_PERMISSION" in os.environ:
            self.default_permission = os.environ["PYFILESERV_DEFAULT_PERMISSION"]

        # 访问日志配置
        if "PYFILESERV_ACCESS_LOG_ENABLED" in os.environ:
            self.access_log_enabled = os.environ["PYFILESERV_ACCESS_LOG_ENABLED"].lower() in ("true", "1", "yes")
        if "PYFILESERV_ACCESS_LOG_FILE" in os.environ:
            self.access_log_file = Path(os.environ["PYFILESERV_ACCESS_LOG_FILE"])
        if "PYFILESERV_ACCESS_LOG_MAX_SIZE_MB" in os.environ:
            self.access_log_max_size_mb = int(os.environ["PYFILESERV_ACCESS_LOG_MAX_SIZE_MB"])
        if "PYFILESERV_ACCESS_LOG_KEEP" in os.environ:
            self.access_log_keep = int(os.environ["PYFILESERV_ACCESS_LOG_KEEP"])


def get_default_config_yaml() -> str:
    """获取默认配置文件内容（YAML 格式）"""
    return '''# pyfileserv 配置文件
# 生成时间: {timestamp}

# 服务器配置
server:
  # 监听端口
  port: 8000
  # 监听地址（空字符串表示所有网卡）
  host: ""
  # 工作线程数（0 = CPU 核数 x 2）
  workers: 0

# 路径配置
paths:
  # 文件服务目录（默认当前目录）
  serve_dir: null
  # 静态文件目录
  static_dir: null
  # 用户数据文件（仅 JSON 存储时使用）
  users_file: "users.json"
  # 日志文件路径（null 表示使用 serve_dir/pyfileserv.log）
  log_file: null

# SSL/HTTPS 配置
ssl:
  # SSL 证书文件路径
  cert_file: null
  # SSL 私钥文件路径
  key_file: null

# 数据库配置
database:
  # 存储类型: json (文件) 或 postgres
  type: "json"

  # PostgreSQL 配置（仅 type=postgres 时使用）
  host: "localhost"
  port: 5432
  database: "pyfileserv"
  username: null
  password: null

  # 连接池配置
  pool_size: 5
  max_overflow: 10

# 会话配置
session:
  # 会话超时时间（秒），默认 1 小时
  timeout: 3600
  # 会话存储方式: memory (内存) 或 redis
  storage: "memory"

# Redis 配置（仅当 session.storage='redis' 时使用）
redis:
  # 是否启用 Redis
  enabled: true
  # Redis 服务器地址
  host: "localhost"
  # Redis 端口
  port: 6379
  # Redis 数据库编号
  db: 0
  # Redis 密码（可选）
  password: null
  # 键前缀（用于隔离不同应用的数据）
  key_prefix: "pyfileserv:session:"

# 安全配置
security:
  # bcrypt 加密轮数
  bcrypt_rounds: 12
  # 登录保护：最大失败尝试次数
  login_max_attempts: 5
  # 登录保护：锁定时长（秒），默认 15 分钟
  login_lockout_duration: 900

# IP 限制配置
# 注意：白名单优先于黑名单，两者都为空时不限制
ip_restriction:
  # IP 白名单（仅允许列表中的 IP 访问）
  # 支持单个 IP 或 CIDR 格式，例如:
  #   - "192.168.1.100"
  #   - "192.168.1.0/24"
  whitelist: []

  # IP 黑名单（禁止列表中的 IP 访问）
  blacklist: []

# 权限配置
permissions:
  # 默认权限：rw（读写）或 r（只读）
  # 当用户没有显式配置权限时使用此值
  default_permission: "rw"

# 访问日志配置
access_log:
  # 是否启用访问日志
  enabled: true
  # 日志文件路径（null 表示使用 serve_dir/access.log）
  log_file: null
  # 日志文件轮转大小（MB）
  max_size_mb: 10
  # 保留的旧日志文件数量
  keep: 7
'''.format(timestamp=__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
