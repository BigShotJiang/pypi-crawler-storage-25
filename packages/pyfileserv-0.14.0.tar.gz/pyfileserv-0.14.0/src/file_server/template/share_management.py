"""share_management template"""
from .base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    format_time,
    _escape_html,
    css_links,
    js_scripts,
)

def render_share_management_page(username: str, shares: list, is_admin: bool = False) -> str:
    """渲染分享管理页面

    Args:
        username: 当前用户名
        shares: 分享列表，每项为字典包含:
            - share_id: 分享ID
            - file_path: 文件/目录路径
            - password: 访问密码（可选）
            - expires_at: 过期时间戳（可选）
            - max_downloads: 最大下载次数（可选）
            - download_count: 已下载次数
            - created_at: 创建时间戳
            - created_by: 创建者（可选）
    """
    share_rows = ""
    if not shares:
        share_rows = '<tr><td colspan="9" style="text-align:center;color:var(--text-secondary);padding:40px;">暂无分享链接</td></tr>'
    else:
        for s in shares:
            share_id = _escape_html(s.get('share_id', ''))
            file_path = _escape_html(s.get('file_path', ''))
            file_name = file_path.split('/')[-1] if file_path else ''
            has_password = '是' if s.get('has_password') else '否'
            status = s.get('status', 'active')
            if status == 'active':
                status_badge = '<span class="status-badge status-active">活跃</span>'
            elif status == 'expired':
                status_badge = '<span class="status-badge status-expired">已过期</span>'
            else:
                status_badge = '<span class="status-badge status-deleted">已删除</span>'
            expires_at = s.get('expires_at')
            if expires_at:
                import datetime
                expire_str = datetime.datetime.fromtimestamp(expires_at).strftime('%Y-%m-%d %H:%M')
            else:
                expire_str = '永不过期'
            max_dl = s.get('max_downloads')
            dl_count = s.get('download_count', 0)
            dl_str = f'{dl_count}/{max_dl}' if max_dl else f'{dl_count}/不限'
            created_at = s.get('created_at', 0)
            if created_at:
                created_str = format_time(created_at)
            else:
                created_str = '-'
            share_url = f'/share/access/{share_id}'
            # 按状态显示不同的操作按钮
            if status == 'active':
                actions_html = (
                    f'<button class="action-btn primary" onclick="copyShareLink(\'{share_id}\')">📋 复制</button>'
                    f'<button class="action-btn info" onclick="editShare(\'{share_id}\', {expires_at or "null"})">✏️ 修改</button>'
                    f'<button class="action-btn danger" onclick="deleteShare(\'{share_id}\', \'{_escape_html(file_name)}\')">🗑️ 删除</button>'
                )
            elif status == 'expired':
                actions_html = (
                    f'<button class="action-btn danger" onclick="deleteShare(\'{share_id}\', \'{_escape_html(file_name)}\')">🗑️ 删除</button>'
                )
            else:
                actions_html = (
                    f'<button class="action-btn danger" onclick="permanentDeleteShare(\'{share_id}\', \'{_escape_html(file_name)}\')">🗑️ 永久删除</button>'
                )
            share_rows += f"""
                    <tr class="row-{status}">
                        <td data-label="分享文件">📄 {_escape_html(file_name)}</td>
                        <td data-label="分享路径" class="path-cell" title="{file_path}">{file_path}</td>
                        <td data-label="分享链接" class="url-cell">
                            <code class="share-url-text">{share_url}</code>
                            <button class="action-btn small" onclick="copyShareLink('{share_id}')" title="复制链接">📋</button>
                        </td>
                        <td data-label="密码">{has_password}</td>
                        <td data-label="下载次数">{dl_str}</td>
                        <td data-label="过期时间">{expire_str}</td>
                        <td data-label="状态">{status_badge}</td>
                        <td data-label="创建时间">{created_str}</td>
                        <td data-label="操作" class="action-cell">
                            {actions_html}
                        </td>
                    </tr>"""

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>分享管理 - 文件服务器</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    {js_scripts("clipboard.js")}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .header h1 {{
            font-size: 20px;
            margin: 0;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .share-table {{
            width: 100%;
            background: var(--bg-secondary);
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            border-collapse: separate;
            border-spacing: 0;
            overflow: hidden;
        }}
        .share-table th {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
            padding: 12px 15px;
            text-align: left;
            font-size: 14px;
            font-weight: 600;
        }}
        .share-table td {{
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            font-size: 14px;
            color: var(--text-primary);
        }}
        .share-table tr:last-child td {{
            border-bottom: none;
        }}
        .share-table tr:hover td {{
            background: rgba(102, 126, 234, 0.03);
        }}
        .share-url-text {{
            font-size: 12px;
            background: var(--bg-primary);
            padding: 2px 6px;
            border-radius: 4px;
            color: var(--text-secondary);
            max-width: 200px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            display: inline-block;
            vertical-align: middle;
        }}
        .path-cell {{
            max-width: 200px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }}
        .action-cell {{
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }}
        .action-btn {{
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            font-weight: 600;
        }}
        .action-btn.small {{
            padding: 2px 6px;
            font-size: 12px;
        }}
        .action-btn.primary {{
            background: #667eea;
            color: white;
        }}
        .action-btn.primary:hover {{
            background: #5a6fd6;
        }}
        .action-btn.danger {{
            background: #ff416c;
            color: white;
        }}
        .action-btn.danger:hover {{
            background: #e03a5e;
        }}
        .action-btn.info {{
            background: #17a2b8;
            color: white;
        }}
        .action-btn.info:hover {{
            background: #138496;
        }}
        .status-badge {{
            display: inline-block;
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            white-space: nowrap;
        }}
        .status-active {{
            background: #d4edda;
            color: #155724;
        }}
        [data-theme="dark"] .status-active {{
            background: #1e3a2a;
            color: #82e0aa;
        }}
        .status-expired {{
            background: #fff3cd;
            color: #856404;
        }}
        [data-theme="dark"] .status-expired {{
            background: #3d3520;
            color: #ffd54f;
        }}
        .status-deleted {{
            background: #f8d7da;
            color: #721c24;
        }}
        [data-theme="dark"] .status-deleted {{
            background: #3a2024;
            color: #f5a0a8;
        }}
        .row-expired td {{
            opacity: 0.6;
        }}
        .row-deleted td {{
            opacity: 0.45;
            text-decoration: line-through;
        }}
        @media (max-width: 768px) {{
            .share-table {{
                font-size: 12px;
            }}
            .share-table thead {{
                display: none;
            }}
            .share-table tr {{
                display: block;
                margin-bottom: 15px;
                border: 1px solid var(--border-color);
                border-radius: 8px;
                padding: 10px;
            }}
            .share-table td {{
                display: flex;
                justify-content: space-between;
                padding: 6px 10px;
                border-bottom: 1px solid var(--border-color);
            }}
            .share-table td::before {{
                content: attr(data-label);
                font-weight: 600;
                color: var(--text-secondary);
                margin-right: 10px;
                white-space: nowrap;
            }}
            .action-cell {{
                justify-content: flex-end;
            }}
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>🔗 分享管理</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2>共 {len(shares)} 个分享链接</h2>
            <a href="/" class="btn btn-secondary">↩️ 返回文件列表</a>
        </div>

        <table class="share-table">
            <thead>
                <tr>
                    <th>分享文件</th>
                    <th>分享路径</th>
                    <th>分享链接</th>
                    <th>密码</th>
                    <th>下载次数</th>
                    <th>过期时间</th>
                    <th>状态</th>
                    <th>创建时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                {share_rows}
            </tbody>
        </table>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        function copyShareLink(shareId) {{
            const fullUrl = window.location.origin + '/share/access/' + shareId;
            copyToClipboard(fullUrl).then(() => {{
                showToast('已复制分享链接');
            }}).catch(err => {{
                showToast('复制失败: ' + err, 'error');
            }});
        }}

        function editShare(shareId, currentExpires) {{
            let message = '请输入新的过期时间（小时）:'
                    + '\\n0 = 永不过期\\n-1 = 取消';
            let hours = prompt(message, '');
            if (hours === null) return;
            hours = parseInt(hours);
            if (isNaN(hours) || hours < -1) {{
                showToast('请输入有效数字', 'error');
                return;
            }}
            let expiresIn;
            if (hours === 0) {{
                expiresIn = 0;
            }} else if (hours === -1) {{
                return;
            }} else {{
                expiresIn = hours * 3600;
            }}

            fetch('/api/share/update/' + shareId, {{
                method: 'POST',
                headers: {{'Content-Type': 'application/json'}},
                body: JSON.stringify({{expires_in: expiresIn}})
            }})
            .then(response => response.json())
            .then(data => {{
                if (data.success) {{
                    showToast('修改成功');
                    setTimeout(() => location.reload(), 500);
                }} else {{
                    showToast('修改失败: ' + (data.error || '未知错误'), 'error');
                }}
            }})
            .catch(err => {{
                showToast('修改失败: ' + err.message, 'error');
            }});
        }}

        function deleteShare(shareId, fileName) {{
            if (!confirm('确定要删除"' + fileName + '"的分享链接吗？\\n删除后可在管理页面恢复或永久删除。')) {{
                return;
            }}

            fetch('/api/share/delete/' + shareId, {{
                method: 'POST'
            }})
            .then(response => response.json())
            .then(data => {{
                if (data.success) {{
                    showToast('已删除（可永久删除）');
                    setTimeout(() => location.reload(), 500);
                }} else {{
                    showToast('删除失败: ' + (data.error || '未知错误'), 'error');
                }}
            }})
            .catch(err => {{
                showToast('删除失败: ' + err.message, 'error');
            }});
        }}

        function permanentDeleteShare(shareId, fileName) {{
            if (!confirm('确定要永久删除"' + fileName + '"的分享链接吗？\\n此操作不可恢复！')) {{
                return;
            }}

            fetch('/api/share/permanent-delete/' + shareId, {{
                method: 'POST'
            }})
            .then(response => response.json())
            .then(data => {{
                if (data.success) {{
                    showToast('已永久删除');
                    setTimeout(() => location.reload(), 500);
                }} else {{
                    showToast('删除失败: ' + (data.error || '未知错误'), 'error');
                }}
            }})
            .catch(err => {{
                showToast('删除失败: ' + err.message, 'error');
            }});
        }}

        initTheme();
    </script>
</body>
</html>
"""

__all__ = ['render_share_management_page']
