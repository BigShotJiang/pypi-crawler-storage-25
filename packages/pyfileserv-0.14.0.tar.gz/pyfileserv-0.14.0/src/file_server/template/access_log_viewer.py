"""访问日志查看页面模板"""
from typing import List

from .base import (
    CSS_GRADIENT_PRIMARY, LOGO_SVG, _escape_html,
    css_links, js_scripts,
)

ACTION_LABELS = {
    'download': '下载', 'upload': '上传', 'delete': '删除',
    'rename': '重命名', 'move': '移动', 'copy': '复制',
    'mkdir': '创建目录', 'preview': '预览',
    'login': '登录', 'logout': '登出',
}


def render_access_log_page(username: str, is_db: bool,
                           usernames: List[str] = None,
                           known_paths: List[str] = None) -> str:
    if usernames is None:
        usernames = []
    if known_paths is None:
        known_paths = []

    user_options = '\n'.join(
        f'<option value="{_escape_html(u)}">{_escape_html(u)}</option>'
        for u in usernames
    )
    path_options = '\n'.join(
        f'<option value="{_escape_html(p)}">{_escape_html(p)}</option>'
        for p in known_paths
    )

    action_options = '\n'.join(
        f'<option value="{k}">{v}</option>'
        for k, v in ACTION_LABELS.items()
    )

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>访问日志 - 文件服务器</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'modal.css', 'forms.css', 'buttons.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            padding: 20px;
        }}

        .header h1 {{
            font-size: 24px;
        }}

        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}

        .toolbar {{
            background: var(--bg-secondary);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            gap: 15px;
        }}

        .toolbar h2 {{
            color: var(--text-primary);
            font-size: 20px;
            margin: 0;
            white-space: nowrap;
        }}

        .btn {{
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }}

        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}

        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}

        .btn-secondary {{
            background: var(--border-color);
            color: var(--text-primary);
        }}

        .btn-secondary:hover {{
            background: var(--bg-hover);
        }}

        .search-bar {{
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: flex-end;
            flex: 1;
            justify-content: flex-end;
        }}

        .search-field {{
            display: flex;
            flex-direction: column;
            gap: 4px;
            min-width: 120px;
        }}

        .search-field label {{
            font-size: 11px;
            color: var(--text-secondary);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }}

        .search-field input,
        .search-field select {{
            padding: 9px 12px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 13px;
            background: var(--bg-primary);
            color: var(--text-primary);
            transition: border-color 0.2s;
            min-width: 120px;
        }}

        .search-field input:focus,
        .search-field select:focus {{
            outline: none;
            border-color: #667eea;
        }}

        .search-field select {{
            cursor: pointer;
            appearance: auto;
        }}

        .search-actions {{
            display: flex;
            gap: 8px;
            align-items: flex-end;
        }}

        .users-table {{
            background: var(--bg-secondary);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }}

        thead {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}

        th {{
            padding: 14px 15px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
        }}

        td {{
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-primary);
            font-size: 13px;
            vertical-align: middle;
        }}

        tbody tr:hover {{
            background: var(--bg-hover);
        }}

        .time-col {{ width: 170px; }}
        .user-col {{ width: 100px; }}
        .action-col {{ width: 90px; text-align: center; }}
        .ip-col {{ width: 130px; }}
        .detail-col {{ width: 220px; }}

        .action-tag {{
            display: inline-block;
            padding: 3px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }}

        .action-download, .action-upload, .action-preview {{
            background: rgba(76,175,80,0.12);
            color: #4CAF50;
        }}
        .action-delete {{
            background: rgba(255,65,108,0.12);
            color: #ff416c;
        }}
        .action-login, .action-logout {{
            background: rgba(102,126,234,0.12);
            color: #667eea;
        }}
        .action-rename, .action-move, .action-copy, .action-mkdir {{
            background: rgba(255,152,0,0.12);
            color: #FF9800;
        }}

        .details-popup {{
            position: relative;
            cursor: pointer;
        }}

        .details-text {{
            max-width: 200px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: 12px;
            color: var(--text-secondary);
            display: inline-block;
        }}

        .details-tooltip {{
            display: none;
            position: absolute;
            bottom: 100%;
            left: 0;
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            padding: 8px 12px;
            font-size: 12px;
            color: var(--text-primary);
            max-width: 350px;
            white-space: pre-wrap;
            word-break: break-all;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
            z-index: 50;
            min-width: 180px;
        }}

        .details-popup:hover .details-tooltip {{
            display: block;
        }}

        .pagination {{
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            margin-top: 20px;
            flex-wrap: wrap;
        }}

        .page-btn {{
            padding: 8px 14px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 13px;
            cursor: pointer;
            background: var(--bg-primary);
            color: var(--text-primary);
            text-decoration: none;
            transition: all 0.2s;
        }}

        .page-btn:hover {{
            border-color: #667eea;
        }}

        .page-btn.active {{
            background: #667eea;
            color: white;
            border-color: #667eea;
        }}

        .page-btn:disabled {{
            opacity: 0.4;
            cursor: default;
        }}

        .page-info {{
            font-size: 13px;
            color: var(--text-secondary);
            margin: 0 10px;
        }}

        .empty-state {{
            text-align: center;
            padding: 60px;
            color: var(--text-secondary);
            font-size: 14px;
        }}

        .storage-badge {{
            display: inline-block;
            padding: 2px 10px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 500;
            margin-left: 10px;
        }}

        {'.storage-db {{ background: rgba(76,175,80,0.12); color: #4CAF50; }}' if is_db else '.storage-file {{ background: rgba(255,152,0,0.12); color: #FF9800; }}'}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>访问日志<span class="storage-badge {'storage-db' if is_db else 'storage-file'}">{'PostgreSQL' if is_db else '本地文件'}</span></h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {_escape_html(username)}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                <a href="/admin" target="_blank" class="dropdown-item">⚙️ 用户管理</a>
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div style="max-width:1200px;margin:0 auto 20px;display:flex;gap:10px;">
        <a href="/admin" class="nav-link" style="padding:8px 16px;border-radius:6px;text-decoration:none;font-size:14px;color:var(--text-secondary);border:1px solid var(--border-color);">用户管理</a>
        <a href="/admin/permissions" class="nav-link" style="padding:8px 16px;border-radius:6px;text-decoration:none;font-size:14px;color:var(--text-secondary);border:1px solid var(--border-color);">权限管理</a>
        <a href="/admin/access-log" class="nav-link" style="padding:8px 16px;border-radius:6px;text-decoration:none;font-size:14px;color:var(--text-secondary);border:1px solid var(--border-color);border-color:#667eea;color:#667eea;">访问日志</a>
        <a href="/" class="nav-link" style="padding:8px 16px;border-radius:6px;text-decoration:none;font-size:14px;color:var(--text-secondary);border:1px solid var(--border-color);">← 返回文件列表</a>
    </div>

    <div class="container">
        <div class="toolbar">
            <h2>📋 操作记录</h2>
            <div class="search-bar">
                <div class="search-field">
                    <label>用户</label>
                    <select id="searchUser">
                        <option value="">全部用户</option>
                        {user_options}
                    </select>
                </div>
                <div class="search-field">
                    <label>操作类型</label>
                    <select id="searchAction">
                        <option value="">全部操作</option>
                        {action_options}
                    </select>
                </div>
                <div class="search-field">
                    <label>文件路径</label>
                    <select id="searchPath">
                        <option value="">全部路径</option>
                        {path_options}
                    </select>
                </div>
                <div class="search-field">
                    <label>IP 地址</label>
                    <input type="text" id="searchIp" placeholder="搜索 IP...">
                </div>
                <div class="search-field">
                    <label>详情搜索</label>
                    <input type="text" id="searchDetail" placeholder="模糊搜索详情...">
                </div>
                <div class="search-actions">
                    <button class="btn btn-primary" onclick="doSearch()">🔍 搜索</button>
                    <button class="btn btn-secondary" onclick="resetSearch()">↺ 重置</button>
                </div>
            </div>
        </div>

        <div class="users-table">
            <div id="logTable">
                <div class="empty-state">正在加载...</div>
            </div>
        </div>

        <div class="pagination" id="pagination"></div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js', 'modal.js')}
    <script>
        const ACTION_LABELS = {{'download':'下载','upload':'上传','delete':'删除','rename':'重命名','move':'移动','copy':'复制','mkdir':'创建目录','preview':'预览','login':'登录','logout':'登出'}};
        let currentPage = 1;

        function restoreSearch() {{
            const params = new URLSearchParams(window.location.search);
            const u = params.get('username');
            const a = params.get('action');
            const p = params.get('path');
            const d = params.get('detail');
            const ip = params.get('ip');
            const pg = params.get('page');
            if (u) document.getElementById('searchUser').value = u;
            if (a) document.getElementById('searchAction').value = a;
            if (p) document.getElementById('searchPath').value = p;
            if (d) document.getElementById('searchDetail').value = d;
            if (ip) document.getElementById('searchIp').value = ip;
            if (pg) currentPage = parseInt(pg) || 1;
        }}

        function getSearchParams() {{
            const params = new URLSearchParams();
            const u = document.getElementById('searchUser').value;
            const a = document.getElementById('searchAction').value;
            const p = document.getElementById('searchPath').value;
            const d = document.getElementById('searchDetail').value.trim();
            const ip = document.getElementById('searchIp').value.trim();
            if (u) params.set('username', u);
            if (a) params.set('action', a);
            if (p) params.set('path', p);
            if (d) params.set('detail', d);
            if (ip) params.set('ip', ip);
            params.set('page', currentPage);
            params.set('per_page', '20');
            return params.toString();
        }}

        async function loadLogs() {{
            try {{
                const resp = await fetch('/api/admin/access-log?' + getSearchParams());
                const data = await resp.json();
                if (!data.success) {{
                    document.getElementById('logTable').innerHTML = '<div class="empty-state">加载失败</div>';
                    return;
                }}
                renderTable(data);
                renderPagination(data);
            }} catch(e) {{
                document.getElementById('logTable').innerHTML = '<div class="empty-state">加载失败: ' + e.message + '</div>';
            }}
        }}

        function renderTable(data) {{
            if (!data.entries || data.entries.length === 0) {{
                document.getElementById('logTable').innerHTML = '<div class="empty-state">暂无日志记录</div>';
                return;
            }}

            let rows = '';
            for (const e of data.entries) {{
                const ts = e.timestamp ? e.timestamp.replace('T', ' ').substring(0, 19) : '-';
                const uname = escapeHtml(e.username || '-');
                const ip = escapeHtml(e.client_ip || '-');
                const actionClass = 'action-' + (e.action || '');
                const actionLabel = ACTION_LABELS[e.action] || e.action || '-';
                const path = escapeHtml(e.path || '-');
                const details = e.details && Object.keys(e.details).length > 0 ? JSON.stringify(e.details) : '';
                const detailsDisplay = details ? JSON.stringify(e.details, null, 2) : '-';
                rows += `<tr>
                    <td class="time-col">${{ts}}</td>
                    <td class="user-col">${{uname}}</td>
                    <td class="ip-col">${{ip}}</td>
                    <td class="action-col"><span class="action-tag ${{actionClass}}">${{actionLabel}}</span></td>
                    <td class="path-col" title="${{path}}">${{path}}</td>
                    <td class="detail-col">
                        <div class="details-popup">
                            <span class="details-text">${{escapeHtml(detailsDisplay.substring(0, 60))}}${{detailsDisplay.length > 60 ? '...' : ''}}</span>
                            ${{details ? '<div class="details-tooltip">' + escapeHtml(detailsDisplay) + '</div>' : ''}}
                        </div>
                    </td>
                </tr>`;
            }}
            document.getElementById('logTable').innerHTML = '<table><thead><tr><th class="time-col">时间</th><th class="user-col">用户</th><th class="ip-col">IP</th><th class="action-col">操作</th><th class="path-col">路径</th><th class="detail-col">详情</th></tr></thead><tbody>' + rows + '</tbody></table>';
        }}

        function renderPagination(data) {{
            let html = '';
            const totalPages = data.total_pages || 1;
            html += `<button class="page-btn" onclick="goPage(${{currentPage - 1}})" ${{currentPage <= 1 ? 'disabled' : ''}}>&#8249; 上一页</button>`;
            for (let i = 1; i <= totalPages; i++) {{
                if (i === 1 || i === totalPages || Math.abs(i - currentPage) <= 2) {{
                    html += `<button class="page-btn ${{i === currentPage ? 'active' : ''}}" onclick="goPage(${{i}})">${{i}}</button>`;
                }} else if (Math.abs(i - currentPage) === 3) {{
                    html += `<span style="color:var(--text-secondary);margin:0 4px;">...</span>`;
                }}
            }}
            html += `<button class="page-btn" onclick="goPage(${{currentPage + 1}})" ${{currentPage >= totalPages ? 'disabled' : ''}}>下一页 &#8250;</button>`;
            html += `<span class="page-info">共 ${{data.total}} 条，第 ${{currentPage}}/${{totalPages}} 页</span>`;
            document.getElementById('pagination').innerHTML = html;
        }}

        function goPage(n) {{
            if (n < 1) return;
            currentPage = n;
            loadLogs();
            window.scrollTo(0, 0);
        }}

        function doSearch() {{
            currentPage = 1;
            loadLogs();
        }}

        function resetSearch() {{
            document.getElementById('searchUser').value = '';
            document.getElementById('searchAction').value = '';
            document.getElementById('searchPath').value = '';
            document.getElementById('searchDetail').value = '';
            document.getElementById('searchIp').value = '';
            currentPage = 1;
            loadLogs();
        }}

        function escapeHtml(text) {{
            return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
        }}

        restoreSearch();
        loadLogs();
        initTheme();
    </script>
</body>
</html>
"""
