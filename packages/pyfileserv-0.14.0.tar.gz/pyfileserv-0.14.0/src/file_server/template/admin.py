"""管理员页面模板"""
from typing import List, Dict

from .base import (
    CSS_GRADIENT_PRIMARY, LOGO_SVG, _escape_html,
    css_links, js_scripts,
)


def render_admin_page(username: str, users: List[Dict]) -> str:
    """渲染管理员页面

    Args:
        username: 当前登录用户名
        users: 用户列表，每个用户包含 username, created_at, is_admin 等信息
    """
    # 生成用户列表HTML
    users_html = ""
    for user in users:
        user_name = _escape_html(user['username'])
        created_at = _escape_html(user.get('created_at', '未知'))
        is_admin = user.get('is_admin', False)
        is_current = "current-user" if user['username'] == username else ""
        admin_badge = ' <span class="admin-badge">管理员</span>' if is_admin else ''

        users_html += f"""
            <tr class="{is_current}">
                <td>{user_name}{admin_badge}</td>
                <td>{created_at}</td>
                <td>
                    <button class="action-btn" onclick="showChangePasswordModal('{user_name}')" title="修改密码">🔑</button>
                    {f'<button class="action-btn danger" onclick="showDeleteUserModal(\'{user_name}\')" title="删除用户">🗑️</button>' if user['username'] != username else ''}
                </td>
            </tr>
        """

    if not users:
        users_html = '<tr><td colspan="3" style="text-align:center;color:var(--text-secondary);">暂无用户</td></tr>'

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户管理 - 文件服务器</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'modal.css', 'forms.css', 'buttons.css', 'error.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            padding: 20px;
        }}

        .header h1 {{
            font-size: 24px;
        }}

        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}

        .toolbar {{
            background: var(--bg-secondary);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }}

        .toolbar h2 {{
            color: var(--text-primary);
            font-size: 20px;
            margin: 0;
        }}

        .btn {{
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }}

        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}

        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}

        .btn-secondary {{
            background: var(--border-color);
            color: var(--text-primary);
        }}

        .btn-secondary:hover {{
            background: var(--bg-hover);
        }}

        .users-table {{
            background: var(--bg-secondary);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
        }}

        thead {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}

        th {{
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
        }}

        td {{
            padding: 15px;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-primary);
        }}

        tbody tr:hover {{
            background: var(--bg-hover);
        }}

        tbody tr.current-user {{
            background: rgba(102, 126, 234, 0.1);
        }}

        .action-btn {{
            background: transparent;
            border: none;
            cursor: pointer;
            font-size: 18px;
            padding: 5px 10px;
            border-radius: 4px;
            transition: all 0.2s;
        }}

        .action-btn:hover {{
            background: var(--bg-hover);
            transform: scale(1.1);
        }}

        .action-btn.danger:hover {{
            background: #ff6b6b;
        }}

        .admin-badge {{
            display: inline-block;
            background: rgba(255,65,108,0.12);
            color: #ff416c;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            margin-left: 6px;
            font-weight: 500;
        }}

        .modal-input {{
            width: 100%;
            padding: 12px 15px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            background: var(--bg-secondary);
            color: var(--text-primary);
            transition: border-color 0.3s;
            margin-bottom: 15px;
        }}

        .modal-input:focus {{
            outline: none;
            border-color: #667eea;
        }}

        .modal-label {{
            display: block;
            margin-bottom: 8px;
            color: var(--text-primary);
            font-weight: 600;
            font-size: 14px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>用户管理</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {_escape_html(username)}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                <a href="/admin" target="_blank" class="dropdown-item">⚙️ 用户管理</a>
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div style="max-width:1200px;margin:0 auto 20px;display:flex;gap:10px;">
        <a href="/admin" class="nav-link active" style="padding:8px 16px;border-radius:6px;text-decoration:none;font-size:14px;color:var(--text-secondary);border:1px solid var(--border-color);border-color:#667eea;color:#667eea;">用户管理</a>
        <a href="/admin/permissions" class="nav-link" style="padding:8px 16px;border-radius:6px;text-decoration:none;font-size:14px;color:var(--text-secondary);border:1px solid var(--border-color);">权限管理</a>
        <a href="/admin/access-log" class="nav-link" style="padding:8px 16px;border-radius:6px;text-decoration:none;font-size:14px;color:var(--text-secondary);border:1px solid var(--border-color);">访问日志</a>
        <a href="/" class="nav-link" style="padding:8px 16px;border-radius:6px;text-decoration:none;font-size:14px;color:var(--text-secondary);border:1px solid var(--border-color);">← 返回文件列表</a>
    </div>

    <div class="container">
        <div class="toolbar">
            <h2>👥 用户列表</h2>
            <button class="btn btn-primary" onclick="showCreateUserModal()">➕ 创建用户</button>
        </div>

        <div class="users-table">
            <table>
                <thead>
                    <tr>
                        <th>用户名</th>
                        <th>创建时间</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    {users_html}
                </tbody>
            </table>
        </div>
    </div>

    <!-- 创建用户模态框 -->
    <div class="modal-overlay" id="createUserModal">
        <div class="modal">
            <h3 class="modal-title">创建新用户</h3>
            <div class="modal-content">
                <label class="modal-label">用户名</label>
                <input type="text" id="newUsername" class="modal-input" placeholder="输入用户名">

                <label class="modal-label">密码</label>
                <input type="password" id="newPassword" class="modal-input" placeholder="输入密码（至少6位）">

                <label class="modal-label">确认密码</label>
                <input type="password" id="confirmPassword" class="modal-input" placeholder="再次输入密码">
            </div>
            <div class="modal-actions">
                <button class="modal-btn cancel" onclick="closeModal('createUserModal')">取消</button>
                <button class="modal-btn primary" onclick="createUser()">创建</button>
            </div>
        </div>
    </div>

    <!-- 修改密码模态框 -->
    <div class="modal-overlay" id="changePasswordModal">
        <div class="modal">
            <h3 class="modal-title">修改密码</h3>
            <div class="modal-content">
                <input type="hidden" id="targetUsername">

                <label class="modal-label">新密码</label>
                <input type="password" id="newPasswordChange" class="modal-input" placeholder="输入新密码（至少6位）">

                <label class="modal-label">确认新密码</label>
                <input type="password" id="confirmPasswordChange" class="modal-input" placeholder="再次输入新密码">
            </div>
            <div class="modal-actions">
                <button class="modal-btn cancel" onclick="closeModal('changePasswordModal')">取消</button>
                <button class="modal-btn primary" onclick="changePassword()">修改</button>
            </div>
        </div>
    </div>

    <!-- 删除用户确认模态框 -->
    <div class="modal-overlay" id="deleteUserModal">
        <div class="modal">
            <h3 class="modal-title">确认删除用户</h3>
            <div class="modal-content">
                <p>确定要删除用户 <strong id="deleteUsername"></strong> 吗？此操作不可恢复。</p>
            </div>
            <div class="modal-actions">
                <button class="modal-btn cancel" onclick="closeModal('deleteUserModal')">取消</button>
                <button class="modal-btn danger" onclick="deleteUser()">删除</button>
            </div>
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js', 'modal.js')}
    <script>
        // Admin-specific closeModal that also clears inputs
        const _closeModal = closeModal;
        closeModal = function(modalId) {{
            _closeModal(modalId);
            const inputs = document.querySelectorAll('#' + modalId + ' input');
            inputs.forEach(function(input) {{ input.value = ''; }});
        }};

        function showCreateUserModal() {{
            showModal('createUserModal');
        }}

        function showChangePasswordModal(username) {{
            document.getElementById('targetUsername').value = username;
            showModal('changePasswordModal');
        }}

        function showDeleteUserModal(username) {{
            document.getElementById('deleteUsername').textContent = username;
            showModal('deleteUserModal');
        }}

        async function createUser() {{
            const username = document.getElementById('newUsername').value.trim();
            const password = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            if (!username) {{
                showToast('请输入用户名', 'error');
                return;
            }}

            if (password.length < 6) {{
                showToast('密码长度至少为6位', 'error');
                return;
            }}

            if (password !== confirmPassword) {{
                showToast('两次密码不一致', 'error');
                return;
            }}

            try {{
                const response = await fetch('/api/admin/users', {{
                    method: 'POST',
                    headers: {{'Content-Type': 'application/json'}},
                    body: JSON.stringify({{username, password}})
                }});

                const result = await response.json();

                if (result.success) {{
                    showToast('用户创建成功');
                    closeModal('createUserModal');
                    setTimeout(() => location.reload(), 1000);
                }} else {{
                    showToast(result.error || '创建失败', 'error');
                }}
            }} catch (error) {{
                showToast('网络错误: ' + error.message, 'error');
            }}
        }}

        async function changePassword() {{
            const username = document.getElementById('targetUsername').value;
            const newPassword = document.getElementById('newPasswordChange').value;
            const confirmPassword = document.getElementById('confirmPasswordChange').value;

            if (newPassword.length < 6) {{
                showToast('密码长度至少为6位', 'error');
                return;
            }}

            if (newPassword !== confirmPassword) {{
                showToast('两次密码不一致', 'error');
                return;
            }}

            try {{
                const response = await fetch(`/api/admin/users/${{encodeURIComponent(username)}}/password`, {{
                    method: 'PUT',
                    headers: {{'Content-Type': 'application/json'}},
                    body: JSON.stringify({{new_password: newPassword}})
                }});

                const result = await response.json();

                if (result.success) {{
                    showToast('密码修改成功');
                    closeModal('changePasswordModal');
                }} else {{
                    showToast(result.error || '修改失败', 'error');
                }}
            }} catch (error) {{
                showToast('网络错误: ' + error.message, 'error');
            }}
        }}

        async function deleteUser() {{
            const username = document.getElementById('deleteUsername').textContent;

            try {{
                const response = await fetch(`/api/admin/users/${{encodeURIComponent(username)}}`, {{
                    method: 'DELETE'
                }});

                const result = await response.json();

                if (result.success) {{
                    showToast('用户删除成功');
                    closeModal('deleteUserModal');
                    setTimeout(() => location.reload(), 1000);
                }} else {{
                    showToast(result.error || '删除失败', 'error');
                }}
            }} catch (error) {{
                showToast('网络错误: ' + error.message, 'error');
            }}
        }}

        // 点击模态框外部关闭
        document.querySelectorAll('.modal-overlay').forEach(function(overlay) {{
            overlay.addEventListener('click', function(e) {{
                if (e.target === overlay) {{
                    overlay.classList.remove('show');
                }}
            }});
        }});

        initTheme();
    </script>
</body>
</html>
"""

__all__ = ['render_admin_page']
