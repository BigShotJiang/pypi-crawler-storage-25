"""权限管理页面模板"""
from typing import List, Dict

from .base import (
    CSS_GRADIENT_PRIMARY, LOGO_SVG, _escape_html,
    css_links, js_scripts,
)


def render_permission_admin_page(username: str, users: List[Dict],
                                  all_dirs: List[str],
                                  default_permission: str = "rw") -> str:
    default_label = '读写' if default_permission == 'rw' else '只读'
    default_cls = 'perm-rw' if default_permission == 'rw' else 'perm-ro'

    users_html = ""
    for user in users:
        uname = _escape_html(user['username'])
        is_admin = user.get('is_admin', False)
        perms = user.get('permissions', {})

        perms_html = ""
        if is_admin:
            perms_html = '<span style="color:var(--text-secondary);font-size:13px;">👑 管理员 — 全部读写</span>'
        elif perms:
            items = []
            for d, p in perms.items():
                label = '读写' if p == 'rw' else '只读'
                cls = 'perm-rw' if p == 'rw' else 'perm-ro'
                icon = '📝' if p == 'rw' else '👁️'
                if d == '*':
                    dir_display = '<em>全部(通配符)</em>'
                else:
                    dir_display = _escape_html(d)
                items.append(
                    f'<span class="perm-tag {cls}">'
                    f'{icon} '
                    f'<span class="perm-dir">{dir_display}</span>'
                    f'<span class="perm-val">· {label}</span>'
                    f'<button class="perm-remove" onclick="removePermission(\'{_escape_html(uname)}\', \'{_escape_html(d)}\')" title="移除权限">✕</button>'
                    f'</span>'
                )
            perms_html = ''.join(items) if items else '<span style="color:var(--text-secondary);font-size:13px;">默认权限 ({default_label})</span>'
        else:
            perms_html = f'<span class="perm-tag {default_cls}" style="font-size:13px;">默认 · {default_label}</span>'

        action_html = ''
        if not is_admin:
            action_html = f'<button class="btn btn-primary" onclick="showAddPerm(\'{uname}\')" style="padding:6px 14px;font-size:13px;">➕ 添加权限</button>'

        users_html += f"""
            <tr>
                <td class="user-col">{uname}{' <span class="admin-badge">管理员</span>' if is_admin else ''}</td>
                <td class="perms-col">{perms_html}</td>
                <td class="action-col">{action_html}</td>
            </tr>
        """

    dir_options = '\n'.join(
        f'<option value="{_escape_html(d)}">{_escape_html(d)}</option>'
        for d in all_dirs
    )

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>权限管理 - 文件服务器</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'modal.css', 'forms.css', 'buttons.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            padding: 20px;
        }}

        .header h1 {{
            font-size: 24px;
        }}

        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}

        .toolbar {{
            background: var(--bg-secondary);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }}

        .toolbar h2 {{
            color: var(--text-primary);
            font-size: 20px;
            margin: 0;
        }}

        .toolbar .default-info {{
            font-size: 13px;
            color: var(--text-secondary);
        }}

        .btn {{
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }}

        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}

        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}

        .btn-secondary {{
            background: var(--border-color);
            color: var(--text-primary);
        }}

        .btn-secondary:hover {{
            background: var(--bg-hover);
        }}

        .users-table {{
            background: var(--bg-secondary);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }}

        thead {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}

        th {{
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
        }}

        td {{
            padding: 15px;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-primary);
            vertical-align: middle;
        }}

        tbody tr:hover {{
            background: var(--bg-hover);
        }}

        .user-col {{
            width: 180px;
        }}

        .action-col {{
            width: 130px;
            text-align: center;
        }}

        .admin-badge {{
            display: inline-block;
            background: rgba(255,65,108,0.12);
            color: #ff416c;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            margin-left: 6px;
            font-weight: 500;
        }}

        .perms-col {{
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            align-items: center;
            padding: 12px 15px;
        }}

        .perm-tag {{
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 5px 12px;
            border-radius: 6px;
            font-size: 13px;
            white-space: nowrap;
        }}

        .perm-rw {{
            background: rgba(76,175,80,0.1);
            border: 1px solid rgba(76,175,80,0.3);
        }}

        .perm-ro {{
            background: rgba(255,152,0,0.1);
            border: 1px solid rgba(255,152,0,0.3);
        }}

        .perm-dir {{
            font-weight: 600;
            max-width: 200px;
            overflow: hidden;
            text-overflow: ellipsis;
        }}

        .perm-val {{
            opacity: 0.6;
            font-size: 11px;
        }}

        .perm-remove {{
            background: none;
            border: none;
            cursor: pointer;
            color: var(--text-secondary);
            font-size: 14px;
            padding: 0 4px;
            line-height: 1;
            border-radius: 3px;
            transition: all 0.15s;
        }}

        .perm-remove:hover {{
            color: #fff;
            background: #ff416c;
        }}

        .modal-input {{
            width: 100%;
            padding: 12px 15px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            background: var(--bg-secondary);
            color: var(--text-primary);
            transition: border-color 0.3s;
            margin-bottom: 15px;
        }}

        .modal-input:focus {{
            outline: none;
            border-color: #667eea;
        }}

        .modal-label {{
            display: block;
            margin-bottom: 8px;
            color: var(--text-primary);
            font-weight: 600;
            font-size: 14px;
        }}

        .multi-select {{
            position: relative;
        }}

        .multi-select-trigger {{
            padding: 10px 14px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            background: var(--bg-secondary);
            color: var(--text-primary);
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            min-height: 44px;
        }}

        .multi-select-trigger:hover {{
            border-color: #667eea;
        }}

        .multi-select-trigger .placeholder {{
            color: var(--text-secondary);
            opacity: 0.6;
        }}

        .multi-select-dropdown {{
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            max-height: 200px;
            overflow-y: auto;
            background: var(--bg-secondary);
            border: 2px solid #667eea;
            border-top: none;
            border-radius: 0 0 8px 8px;
            z-index: 100;
        }}

        .multi-select-dropdown.open {{
            display: block;
        }}

        .multi-select-item {{
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 14px;
            cursor: pointer;
            font-size: 14px;
            color: var(--text-primary);
            transition: background 0.15s;
        }}

        .multi-select-item:hover {{
            background: var(--bg-hover);
        }}

        .multi-select-item input[type="checkbox"] {{
            accent-color: #667eea;
            width: 16px;
            height: 16px;
        }}

        .selected-tags {{
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
            margin-top: 10px;
        }}

        .selected-tag {{
            display: inline-flex;
            align-items: center;
            gap: 4px;
            background: rgba(102,126,234,0.12);
            color: #667eea;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
        }}

        .selected-tag .remove-tag {{
            cursor: pointer;
            font-weight: bold;
            opacity: 0.6;
        }}

        .selected-tag .remove-tag:hover {{
            opacity: 1;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>权限管理</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {_escape_html(username)}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                <a href="/admin" target="_blank" class="dropdown-item">⚙️ 用户管理</a>
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div style="max-width:1200px;margin:0 auto 20px;display:flex;gap:10px;">
        <a href="/admin" class="nav-link" style="padding:8px 16px;border-radius:6px;text-decoration:none;font-size:14px;color:var(--text-secondary);border:1px solid var(--border-color);">用户管理</a>
        <a href="/admin/permissions" class="nav-link" style="padding:8px 16px;border-radius:6px;text-decoration:none;font-size:14px;color:var(--text-secondary);border:1px solid var(--border-color);border-color:#667eea;color:#667eea;">权限管理</a>
        <a href="/admin/access-log" class="nav-link" style="padding:8px 16px;border-radius:6px;text-decoration:none;font-size:14px;color:var(--text-secondary);border:1px solid var(--border-color);">访问日志</a>
        <a href="/" class="nav-link" style="padding:8px 16px;border-radius:6px;text-decoration:none;font-size:14px;color:var(--text-secondary);border:1px solid var(--border-color);">← 返回文件列表</a>
    </div>

    <div class="container">
        <div class="toolbar">
            <div>
                <h2>🔐 权限列表</h2>
                <span class="default-info">默认权限：<strong>{default_label}</strong></span>
            </div>
        </div>

        <div class="users-table">
            <table>
                <thead>
                    <tr>
                        <th class="user-col">用户</th>
                        <th>权限配置</th>
                        <th class="action-col">操作</th>
                    </tr>
                </thead>
                <tbody>
                    {users_html}
                </tbody>
            </table>
        </div>
    </div>

    <!-- 添加权限弹窗 -->
    <div class="modal-overlay" id="addPermModal">
        <div class="modal">
            <h3 class="modal-title">添加权限 — <span id="addPermUser"></span></h3>
            <div class="modal-content">
                <label class="modal-label">项目路径（支持多选，* 表示所有目录）</label>
                <div class="multi-select" id="dirMultiSelect">
                    <div class="multi-select-trigger" onclick="toggleDirDropdown()">
                        <span class="placeholder" id="dirPlaceholder">选择目录...</span>
                        <span>▼</span>
                    </div>
                    <div class="multi-select-dropdown" id="dirDropdown">
                        <div class="multi-select-item" onclick="event.stopPropagation()">
                            <input type="checkbox" value="*" onchange="onDirCheckboxChange()" id="dir_opt_wildcard">
                            <label for="dir_opt_wildcard">* (全部目录 — 通配符)</label>
                        </div>
                        {''.join(f'<div class="multi-select-item" onclick="event.stopPropagation()"><input type="checkbox" value="{_escape_html(d)}" onchange="onDirCheckboxChange()" id="dir_opt_{i}"><label for="dir_opt_{i}">{_escape_html(d)}</label></div>' for i, d in enumerate(all_dirs) if d != '*')}
                    </div>
                </div>
                <div class="selected-tags" id="selectedDirs"></div>

                <label class="modal-label" style="margin-top:15px;">权限级别</label>
                <select id="permValue" class="modal-input">
                    <option value="rw">📝 读写 (rw)</option>
                    <option value="r">👁️ 只读 (r)</option>
                </select>
            </div>
            <div class="modal-actions">
                <button class="modal-btn cancel" onclick="closeAddPermModal()">取消</button>
                <button class="modal-btn primary" onclick="confirmAddPerm()">确定添加</button>
            </div>
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js', 'modal.js')}
    <script>
        let currentPermUser = '';
        let selectedDirs = [];

        function showAddPerm(username) {{
            currentPermUser = username;
            selectedDirs = [];
            document.getElementById('addPermUser').textContent = username;
            document.getElementById('permValue').value = 'rw';
            // 清除所有勾选
            document.querySelectorAll('#dirDropdown input[type="checkbox"]').forEach(function(cb) {{ cb.checked = false; }});
            updateSelectedTags();
            showModal('addPermModal');
        }}

        function toggleDirDropdown() {{
            document.getElementById('dirDropdown').classList.toggle('open');
        }}

        function onDirCheckboxChange() {{
            selectedDirs = [];
            document.querySelectorAll('#dirDropdown input[type="checkbox"]:checked').forEach(function(cb) {{
                selectedDirs.push(cb.value);
            }});
            updateSelectedTags();
        }}

        function updateSelectedTags() {{
            var container = document.getElementById('selectedDirs');
            var placeholder = document.getElementById('dirPlaceholder');
            if (selectedDirs.length === 0) {{
                container.innerHTML = '';
                placeholder.textContent = '\u9009\u62e9\u76ee\u5f55...';
                placeholder.style.color = '';
            }} else {{
                placeholder.textContent = '\u5df2\u9009\u62e9 ' + selectedDirs.length + ' \u4e2a\u76ee\u5f55';
                placeholder.style.color = '#667eea';
                var tags = '';
                for (var i = 0; i < selectedDirs.length; i++) {{
                    tags += '<span class="selected-tag">' + escapeHtml(selectedDirs[i]) + ' <span class="remove-tag" data-dir="' + escapeHtml(selectedDirs[i]).replace(/"/g, '&quot;') + '">\u2715</span></span>';
                }}
                container.innerHTML = tags;
            }}
        }}

        // Use event delegation for remove-tag clicks
        document.getElementById('selectedDirs').addEventListener('click', function(e) {{
            var removeEl = e.target.closest('.remove-tag');
            if (removeEl) {{
                e.stopPropagation();
                var dir = removeEl.getAttribute('data-dir');
                selectedDirs = selectedDirs.filter(function(d) {{ return d !== dir; }});
                document.querySelectorAll('#dirDropdown input[type="checkbox"]').forEach(function(cb) {{
                    if (cb.value === dir) cb.checked = false;
                }});
                updateSelectedTags();
            }}
        }});

        // 点击外部关闭下拉
        document.addEventListener('click', function(e) {{
            var ms = document.getElementById('dirMultiSelect');
            if (ms && !ms.contains(e.target)) {{
                document.getElementById('dirDropdown').classList.remove('open');
            }}
        }});

        function closeAddPermModal() {{
            closeModal('addPermModal');
            document.getElementById('dirDropdown').classList.remove('open');
        }}

        async function confirmAddPerm() {{
            if (selectedDirs.length === 0) {{
                showToast('\u8bf7\u81f3\u5c11\u9009\u62e9\u4e00\u4e2a\u76ee\u5f55', 'warning');
                return;
            }}
            var perm = document.getElementById('permValue').value;
            var errors = [];

            for (var i = 0; i < selectedDirs.length; i++) {{
                var dir = selectedDirs[i];
                try {{
                    var resp = await fetch('/api/admin/permissions', {{
                        method: 'POST',
                        headers: {{'Content-Type': 'application/json'}},
                        body: JSON.stringify({{username: currentPermUser, directory: dir, permission: perm}})
                    }});
                    var data = await resp.json();
                    if (!data.success) {{
                        errors.push(dir + ': ' + (data.error || '\u5931\u8d25'));
                    }}
                }} catch(e) {{
                    errors.push(dir + ': ' + e.message);
                }}
            }}

            if (errors.length === 0) {{
                showToast('\u6743\u9650\u5df2\u6dfb\u52a0 (' + selectedDirs.length + ' \u9879)');
                closeAddPermModal();
                setTimeout(function() {{ location.reload(); }}, 400);
            }} else {{
                showToast('\u90e8\u5206\u5931\u8d25: ' + errors.join('; '), 'error');
            }}
        }}

        async function removePermission(username, directory) {{
            if (!confirm('\u786e\u5b9a\u79fb\u9664 ' + username + ' \u5bf9 "' + directory + '" \u7684\u6743\u9650\uff1f')) return;

            try {{
                var resp = await fetch('/api/admin/permissions', {{
                    method: 'DELETE',
                    headers: {{'Content-Type': 'application/json'}},
                    body: JSON.stringify({{username: username, directory: directory}})
                }});
                var data = await resp.json();
                if (data.success) {{
                    showToast('\u6743\u9650\u5df2\u79fb\u9664');
                    setTimeout(function() {{ location.reload(); }}, 400);
                }} else {{
                    showToast(data.error || '\u64cd\u4f5c\u5931\u8d25', 'error');
                }}
            }} catch(e) {{
                showToast('\u64cd\u4f5c\u5931\u8d25: ' + e.message, 'error');
            }}
        }}

        function escapeHtml(text) {{
            return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
        }}

        // 点击模态框外部关闭
        document.querySelectorAll('.modal-overlay').forEach(function(overlay) {{
            overlay.addEventListener('click', function(e) {{
                if (e.target === overlay) {{
                    overlay.classList.remove('show');
                    document.getElementById('dirDropdown').classList.remove('open');
                }}
            }});
        }});

        initTheme();
    </script>
</body>
</html>
"""
