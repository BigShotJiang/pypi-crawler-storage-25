"""VIBE Airforce CLI — Web3 trading and data at your fingertips."""

__version__ = "0.1.1"
