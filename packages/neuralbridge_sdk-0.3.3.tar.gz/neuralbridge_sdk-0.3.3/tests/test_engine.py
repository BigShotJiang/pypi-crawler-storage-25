"""
Test suite for diagnosis and flywheel engines
Coverage target: DiagnosisEngine + FlywheelEngine (heal/heal_async/诊断/恢复/健康状态)
"""
import pytest
import asyncio
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from src.types import ErrorCategory, CascadeLevel, JitterConfig
from src.engine import DiagnosisEngine, FlywheelEngine


class TestDiagnosisEngine:
    """Test diagnosis engine"""
    
    def test_diagnose_network_timeout(self):
        """Test diagnosing network timeout"""
        engine = DiagnosisEngine()
        result = engine.diagnose("Connection timeout after 30 seconds")
        
        assert result.error_category == ErrorCategory.NETWORK_TIMEOUT
        assert result.suggested_action == CascadeLevel.RETRY
        assert result.is_recoverable() is True
    
    def test_diagnose_rate_limit(self):
        """Test diagnosing rate limit"""
        engine = DiagnosisEngine()
        result = engine.diagnose("Rate limit exceeded for user")
        
        assert result.error_category == ErrorCategory.RATE_LIMIT
        assert result.suggested_action == CascadeLevel.RETRY
        assert result.is_recoverable() is True
    
    def test_diagnose_quota_exceeded(self):
        """Test diagnosing quota exceeded"""
        engine = DiagnosisEngine()
        result = engine.diagnose("Quota exceeded for this API")
        
        assert result.error_category == ErrorCategory.RATE_LIMIT
        assert result.suggested_action == CascadeLevel.RETRY
    
    def test_diagnose_invalid_api_key(self):
        """Test diagnosing authentication error"""
        engine = DiagnosisEngine()
        result = engine.diagnose("Invalid API key provided")
        
        assert result.error_category == ErrorCategory.AUTHENTICATION
        assert result.suggested_action == CascadeLevel.TERMINATE
        assert result.is_recoverable() is False
    
    def test_diagnose_model_not_found(self):
        """Test diagnosing model error"""
        engine = DiagnosisEngine()
        result = engine.diagnose("Model qwen-nonexistent not found")
        
        assert result.error_category == ErrorCategory.MODEL_ERROR
        assert result.suggested_action == CascadeLevel.FALLBACK_MODEL
        assert result.is_recoverable() is True
    
    def test_diagnose_context_length(self):
        """Test diagnosing context length error"""
        engine = DiagnosisEngine()
        result = engine.diagnose("Context length exceeded maximum of 32768 tokens")
        
        assert result.error_category == ErrorCategory.CONTEXT_LENGTH
        assert result.suggested_action == CascadeLevel.TERMINATE
        assert result.is_recoverable() is False
    
    def test_diagnose_with_status_code_500(self):
        """Test diagnosis with HTTP 500 status code"""
        engine = DiagnosisEngine()
        result = engine.diagnose("Internal server error", status_code=500)
        
        assert result.error_category == ErrorCategory.API_ERROR
        assert result.suggested_action == CascadeLevel.RETRY
    
    def test_diagnose_with_status_code_429(self):
        """Test diagnosis with HTTP 429 status code"""
        engine = DiagnosisEngine()
        result = engine.diagnose("Too many requests", status_code=429)
        
        assert result.error_category == ErrorCategory.RATE_LIMIT
    
    def test_diagnose_with_status_code_401(self):
        """Test diagnosis with HTTP 401 status code"""
        engine = DiagnosisEngine()
        result = engine.diagnose("Unauthorized", status_code=401)
        
        assert result.error_category == ErrorCategory.AUTHENTICATION
        assert result.suggested_action == CascadeLevel.TERMINATE
    
    def test_diagnose_unknown_error(self):
        """Test diagnosing unknown error"""
        engine = DiagnosisEngine()
        result = engine.diagnose("Some weird error happened")
        
        assert result.error_category == ErrorCategory.UNKNOWN
        assert result.suggested_action == CascadeLevel.RETRY
        assert result.confidence == 0.8


class TestFlywheelEngine:
    """Test flywheel self-healing engine"""
    
    def test_heal_network_timeout(self):
        """Test healing network timeout with retry"""
        engine = FlywheelEngine()
        result = engine.heal(
            error_message="Connection timeout",
            current_model="qwen-turbo"
        )
        
        assert result["action_taken"] == "retry"
        assert result["success"] is True
        assert result["retry_delay"] is not None
    
    def test_heal_rate_limit(self):
        """Test healing rate limit with retry"""
        engine = FlywheelEngine()
        result = engine.heal(
            error_message="Rate limit exceeded",
            current_model="qwen-turbo"
        )
        
        assert result["action_taken"] == "retry"
        assert result["success"] is True
    
    def test_heal_authentication_error(self):
        """Test handling authentication error (terminate)"""
        engine = FlywheelEngine()
        result = engine.heal(
            error_message="Invalid API key",
            current_model="qwen-turbo"
        )
        
        assert result["action_taken"] == "terminate"
        assert result["success"] is False
    
    def test_heal_model_fallback(self):
        """Test model fallback"""
        engine = FlywheelEngine()
        result = engine.heal(
            error_message="Model not found",
            current_model="nonexistent-model",
            available_models=["qwen-turbo", "qwen-plus"]
        )
        
        assert result["action_taken"] == "fallback_model"
        assert result["new_model"] in ["qwen-turbo", "qwen-plus"]
        assert result["success"] is True
    
    def test_heal_no_available_models(self):
        """Test fallback with no available models"""
        engine = FlywheelEngine()
        result = engine.heal(
            error_message="Model not found",
            current_model="broken-model",
            available_models=[]
        )
        
        assert result["action_taken"] != "fallback_model" or result["success"] is False
    
    @pytest.mark.asyncio
    async def test_heal_async(self):
        """Test asynchronous healing"""
        engine = FlywheelEngine()
        result = await engine.heal_async(
            error_message="Timeout error",
            current_model="qwen-turbo"
        )
        
        assert result["action_taken"] == "retry"
        assert result["success"] is True
    
    @pytest.mark.asyncio
    async def test_heal_async_with_delay(self):
        """Test async healing respects delay"""
        import time
        
        engine = FlywheelEngine(jitter_config=JitterConfig(
            base_delay=0.1,
            max_delay=1.0,
            jitter_factor=0.0
        ))
        
        start_time = time.time()
        result = await engine.heal_async(
            error_message="Timeout",
            current_model="qwen-turbo"
        )
        elapsed = time.time() - start_time
        
        assert result["retry_delay"] is not None
        assert elapsed >= result["retry_delay"] * 0.9
    
    def test_get_health_status_unknown_model(self):
        """Test health status for unknown model"""
        engine = FlywheelEngine()
        status = engine.get_health_status("nonexistent-model")
        
        assert status["status"] == "unknown"
        assert status["health_score"] == 0
    
    def test_get_health_status_healthy(self):
        """Test health status for healthy model"""
        engine = FlywheelEngine()
        engine.record_performance("qwen-turbo", latency_ms=200.0, success=True)
        engine.record_performance("qwen-turbo", latency_ms=250.0, success=True)
        engine.record_performance("qwen-turbo", latency_ms=180.0, success=True)
        
        status = engine.get_health_status("qwen-turbo")
        
        assert status["status"] == "healthy"
        assert status["health_score"] > 80
        assert status["total_requests"] == 3
    
    def test_get_health_status_degraded(self):
        """Test health status for degraded model"""
        engine = FlywheelEngine()
        
        for _ in range(5):
            engine.record_performance("slow-model", latency_ms=5000.0, success=False)
        
        status = engine.get_health_status("slow-model")
        
        assert status["status"] in ["degraded", "unhealthy"]
        assert status["health_score"] < 80
    
    def test_record_performance_updates_metrics(self):
        """Test performance recording updates metrics"""
        engine = FlywheelEngine()
        
        engine.record_performance("test-model", latency_ms=300.0, success=True)
        engine.record_performance("test-model", latency_ms=400.0, success=False, error_message="timeout")
        
        perf = engine.model_performances["test-model"]
        
        assert perf.total_requests == 2
        assert perf.failed_requests == 1
        assert abs(perf.avg_latency_ms - 350.0) < 0.1
        assert perf.success_rate == 0.5
        assert perf.last_error == "timeout"
    
    def test_healing_history_tracking(self):
        """Test healing events are tracked"""
        engine = FlywheelEngine()
        
        engine.heal(error_message="Timeout", current_model="model-a")
        engine.heal(error_message="Rate limit", current_model="model-a")
        engine.heal(error_message="Timeout", current_model="model-b")
        
        assert len(engine.healing_history) == 3
        
        model_a_events = [e for e in engine.healing_history if e["model"] == "model-a"]
        assert len(model_a_events) == 2
    
    def test_custom_strategy_integration(self):
        """Test custom strategy integration"""
        from src.strategies import CircuitBreakerStrategy
        
        strategy = CircuitBreakerStrategy(failure_threshold=2)
        engine = FlywheelEngine(strategy=strategy)
        
        # Need to trigger with errors that cause retries
        result1 = engine.heal(error_message="Timeout error", current_model="test")
        result2 = engine.heal(error_message="Timeout error", current_model="test")
        
        # Circuit should open after 2 failures
        assert strategy.state == "open" or len(engine.healing_history) >= 2
