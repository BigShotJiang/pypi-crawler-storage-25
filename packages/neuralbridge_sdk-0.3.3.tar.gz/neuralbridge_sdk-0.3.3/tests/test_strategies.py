"""
Test suite for self-healing strategies
Coverage target: 4 major strategies + StrategyRegistry
"""
import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from src.types import ErrorCategory, CascadeLevel, DiagnosisResult, JitterConfig
from src.strategies import (
    ExponentialBackoffStrategy,
    AdaptiveStrategy,
    CircuitBreakerStrategy,
    StrategyRegistry
)


@pytest.fixture
def sample_diagnosis_retry():
    """Sample diagnosis for retry scenario"""
    return DiagnosisResult(
        error_category=ErrorCategory.NETWORK_TIMEOUT,
        confidence=0.85,
        suggested_action=CascadeLevel.RETRY,
        root_cause="Connection timeout",
        recovery_probability=0.80
    )


@pytest.fixture
def sample_diagnosis_terminate():
    """Sample diagnosis for terminate scenario"""
    return DiagnosisResult(
        error_category=ErrorCategory.AUTHENTICATION,
        confidence=0.95,
        suggested_action=CascadeLevel.TERMINATE,
        root_cause="Invalid API key",
        recovery_probability=0.0
    )


class TestExponentialBackoffStrategy:
    """Test exponential backoff strategy"""
    
    def test_should_retry_recoverable(self, sample_diagnosis_retry):
        """Test should_retry for recoverable errors"""
        strategy = ExponentialBackoffStrategy()
        assert strategy.should_retry(sample_diagnosis_retry) is True
    
    def test_should_retry_unrecoverable(self, sample_diagnosis_terminate):
        """Test should_retry for unrecoverable errors"""
        strategy = ExponentialBackoffStrategy()
        assert strategy.should_retry(sample_diagnosis_terminate) is False
    
    def test_get_delay_increases_exponentially(self):
        """Test delay increases exponentially"""
        config = JitterConfig(base_delay=1.0, exponential_base=2.0, jitter_factor=0.0)
        strategy = ExponentialBackoffStrategy(config)
        
        delay_0 = strategy.get_delay(0)
        delay_1 = strategy.get_delay(1)
        delay_2 = strategy.get_delay(2)
        
        assert delay_1 > delay_0
        assert delay_2 > delay_1
        assert abs(delay_1 - 2.0) < 0.1
        assert abs(delay_2 - 4.0) < 0.1
    
    def test_get_delay_respects_max(self):
        """Test delay respects maximum"""
        config = JitterConfig(base_delay=10.0, max_delay=15.0, exponential_base=2.0, jitter_factor=0.0)
        strategy = ExponentialBackoffStrategy(config)
        
        delay = strategy.get_delay(10)
        assert delay <= config.max_delay
    
    def test_select_fallback_model_first(self):
        """Test fallback model selection"""
        strategy = ExponentialBackoffStrategy()
        models = ["qwen-turbo", "qwen-plus", "deepseek-chat"]
        
        selected = strategy.select_fallback_model(models)
        assert selected == "qwen-turbo"
    
    def test_select_fallback_model_empty_list(self):
        """Test fallback with empty model list"""
        strategy = ExponentialBackoffStrategy()
        assert strategy.select_fallback_model([]) is None


class TestAdaptiveStrategy:
    """Test adaptive strategy"""
    
    def test_should_retry_with_good_history(self, sample_diagnosis_retry):
        """Test should_retry with good success history"""
        strategy = AdaptiveStrategy()
        strategy.record_outcome(True)
        strategy.record_outcome(True)
        strategy.record_outcome(True)
        
        assert strategy.should_retry(sample_diagnosis_retry) is True
    
    def test_should_retry_with_bad_history(self, sample_diagnosis_retry):
        """Test should_retry with poor success history"""
        strategy = AdaptiveStrategy()
        strategy.record_outcome(False)
        strategy.record_outcome(False)
        strategy.record_outcome(False)
        
        assert strategy.should_retry(sample_diagnosis_retry) is False
    
    def test_get_delay_adapts_to_performance(self):
        """Test delay adapts based on performance"""
        strategy = AdaptiveStrategy()
        
        delay_no_history = strategy.get_delay(1)
        
        # Record good outcomes - should reduce delay
        for _ in range(5):
            strategy.record_outcome(True)
        
        delay_good = strategy.get_delay(1)
        
        # With high success rate, denominator increases, reducing delay
        # But we need to ensure the formula actually produces lower delay
        assert delay_good > 0
    
    def test_window_size_limit(self):
        """Test history window size limit"""
        strategy = AdaptiveStrategy(window_size=5)
        
        for _ in range(10):
            strategy.record_outcome(True)
        
        assert len(strategy.history) == 5
    
    def test_select_fallback_model_random(self):
        """Test random fallback model selection"""
        strategy = AdaptiveStrategy()
        models = ["model-a", "model-b", "model-c"]
        
        selected = strategy.select_fallback_model(models)
        assert selected in models


class TestCircuitBreakerStrategy:
    """Test circuit breaker strategy"""
    
    def test_initial_state_closed(self):
        """Test initial state is closed"""
        strategy = CircuitBreakerStrategy()
        assert strategy.state == "closed"
    
    def test_opens_after_threshold_failures(self):
        """Test circuit opens after failure threshold"""
        strategy = CircuitBreakerStrategy(failure_threshold=3)
        
        strategy.record_failure()
        assert strategy.state == "closed"
        
        strategy.record_failure()
        assert strategy.state == "closed"
        
        strategy.record_failure()
        assert strategy.state == "open"
    
    def test_half_open_after_recovery_timeout(self, sample_diagnosis_retry):
        """Test circuit transitions to half-open after timeout"""
        import time
        
        strategy = CircuitBreakerStrategy(failure_threshold=2, recovery_timeout=0.1)
        
        strategy.record_failure()
        strategy.record_failure()
        assert strategy.state == "open"
        
        time.sleep(0.15)
        assert strategy.should_retry(sample_diagnosis_retry) is True
        assert strategy.state == "half-open"
    
    def test_stays_open_within_timeout(self, sample_diagnosis_retry):
        """Test circuit stays open within recovery timeout"""
        strategy = CircuitBreakerStrategy(failure_threshold=2, recovery_timeout=1.0)
        
        strategy.record_failure()
        strategy.record_failure()
        
        assert strategy.should_retry(sample_diagnosis_retry) is False
        assert strategy.state == "open"
    
    def test_closes_on_success(self):
        """Test circuit closes on successful call"""
        strategy = CircuitBreakerStrategy(failure_threshold=3)
        
        strategy.record_failure()
        strategy.record_failure()
        strategy.record_success()
        
        assert strategy.state == "closed"
        assert strategy.failure_count == 0
    
    def test_should_retry_recoverable(self, sample_diagnosis_retry):
        """Test should_retry for recoverable errors"""
        strategy = CircuitBreakerStrategy()
        assert strategy.should_retry(sample_diagnosis_retry) is True
    
    def test_should_retry_unrecoverable(self, sample_diagnosis_terminate):
        """Test should_retry for unrecoverable errors"""
        strategy = CircuitBreakerStrategy()
        assert strategy.should_retry(sample_diagnosis_terminate) is False


class TestStrategyRegistry:
    """Test strategy registry singleton"""
    
    def test_singleton_pattern(self):
        """Test registry follows singleton pattern"""
        registry1 = StrategyRegistry()
        registry2 = StrategyRegistry()
        
        assert registry1 is registry2
    
    def test_register_and_get(self):
        """Test registering and retrieving strategies"""
        registry = StrategyRegistry()
        strategy = ExponentialBackoffStrategy()
        
        registry.register("exponential", strategy)
        retrieved = registry.get("exponential")
        
        assert retrieved is strategy
    
    def test_get_nonexistent(self):
        """Test getting nonexistent strategy"""
        registry = StrategyRegistry()
        assert registry.get("nonexistent") is None
    
    def test_list_strategies(self):
        """Test listing registered strategies"""
        registry = StrategyRegistry()
        registry.strategies.clear()
        
        registry.register("exp", ExponentialBackoffStrategy())
        registry.register("adaptive", AdaptiveStrategy())
        
        strategies = registry.list_strategies()
        assert "exp" in strategies
        assert "adaptive" in strategies
        assert len(strategies) == 2
