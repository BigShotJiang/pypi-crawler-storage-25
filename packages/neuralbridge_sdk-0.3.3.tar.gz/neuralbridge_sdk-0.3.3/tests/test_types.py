"""
Test suite for core type definitions
Coverage target: ErrorCategory, CascadeLevel, DiagnosisResult, ModelPerformance
"""
import pytest
from datetime import datetime
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from src.types import (
    ErrorCategory,
    CascadeLevel,
    ModelPerformance,
    DiagnosisResult,
    JitterConfig
)


class TestErrorCategory:
    """Test ErrorCategory enum"""
    
    def test_error_category_values(self):
        """Verify all error categories are defined"""
        assert ErrorCategory.NETWORK_TIMEOUT.value == "network_timeout"
        assert ErrorCategory.RATE_LIMIT.value == "rate_limit"
        assert ErrorCategory.API_ERROR.value == "api_error"
        assert ErrorCategory.MODEL_ERROR.value == "model_error"
        assert ErrorCategory.CONTEXT_LENGTH.value == "context_length"
        assert ErrorCategory.AUTHENTICATION.value == "authentication"
        assert ErrorCategory.UNKNOWN.value == "unknown"
    
    def test_error_category_count(self):
        """Verify correct number of error categories"""
        assert len(ErrorCategory) == 7


class TestCascadeLevel:
    """Test CascadeLevel enum"""
    
    def test_cascade_level_values(self):
        """Verify all cascade levels are defined"""
        assert CascadeLevel.RETRY.value == "retry"
        assert CascadeLevel.FALLBACK_MODEL.value == "fallback_model"
        assert CascadeLevel.FALLBACK_PROVIDER.value == "fallback_provider"
        assert CascadeLevel.TERMINATE.value == "terminate"
    
    def test_cascade_level_count(self):
        """Verify correct number of cascade levels"""
        assert len(CascadeLevel) == 4


class TestModelPerformance:
    """Test ModelPerformance dataclass"""
    
    def test_create_model_performance(self):
        """Test creating ModelPerformance instance"""
        perf = ModelPerformance(
            model_name="qwen-turbo",
            avg_latency_ms=500.0,
            success_rate=0.95,
            total_requests=100,
            failed_requests=5
        )
        
        assert perf.model_name == "qwen-turbo"
        assert perf.avg_latency_ms == 500.0
        assert perf.success_rate == 0.95
        assert perf.total_requests == 100
        assert perf.failed_requests == 5
    
    def test_health_score_calculation(self):
        """Test health score calculation"""
        perf = ModelPerformance(
            model_name="test-model",
            avg_latency_ms=200.0,
            success_rate=0.98,
            total_requests=50,
            failed_requests=1
        )
        
        health_score = perf.health_score()
        latency_score = max(0, 100 - (200.0 / 10))
        success_score = 0.98 * 100
        expected_score = (latency_score + success_score) / 2
        
        assert abs(health_score - expected_score) < 0.01
    
    def test_health_score_with_high_latency(self):
        """Test health score with high latency"""
        perf = ModelPerformance(
            model_name="slow-model",
            avg_latency_ms=2000.0,
            success_rate=0.90,
            total_requests=100,
            failed_requests=10
        )
        
        health_score = perf.health_score()
        assert health_score >= 0
        assert health_score <= 100
    
    def test_model_performance_with_optional_fields(self):
        """Test ModelPerformance with optional fields"""
        perf = ModelPerformance(
            model_name="test-model",
            avg_latency_ms=300.0,
            success_rate=0.92,
            total_requests=75,
            failed_requests=6,
            last_error="timeout",
            last_success_at=datetime.now()
        )
        
        assert perf.last_error == "timeout"
        assert perf.last_success_at is not None


class TestDiagnosisResult:
    """Test DiagnosisResult dataclass"""
    
    def test_create_diagnosis_result(self):
        """Test creating DiagnosisResult instance"""
        diagnosis = DiagnosisResult(
            error_category=ErrorCategory.NETWORK_TIMEOUT,
            confidence=0.85,
            suggested_action=CascadeLevel.RETRY,
            root_cause="Connection timeout after 30s",
            recovery_probability=0.80
        )
        
        assert diagnosis.error_category == ErrorCategory.NETWORK_TIMEOUT
        assert diagnosis.confidence == 0.85
        assert diagnosis.suggested_action == CascadeLevel.RETRY
        assert "timeout" in diagnosis.root_cause.lower()
        assert diagnosis.recovery_probability == 0.80
    
    def test_is_recoverable_true(self):
        """Test is_recoverable returns True for retry actions"""
        diagnosis = DiagnosisResult(
            error_category=ErrorCategory.RATE_LIMIT,
            confidence=0.75,
            suggested_action=CascadeLevel.RETRY,
            root_cause="Rate limit exceeded",
            recovery_probability=0.70
        )
        
        assert diagnosis.is_recoverable() is True
    
    def test_is_recoverable_false(self):
        """Test is_recoverable returns False for terminate action"""
        diagnosis = DiagnosisResult(
            error_category=ErrorCategory.AUTHENTICATION,
            confidence=0.95,
            suggested_action=CascadeLevel.TERMINATE,
            root_cause="Invalid API key",
            recovery_probability=0.0
        )
        
        assert diagnosis.is_recoverable() is False
    
    def test_metadata_default(self):
        """Test metadata defaults to empty dict"""
        diagnosis = DiagnosisResult(
            error_category=ErrorCategory.UNKNOWN,
            confidence=0.50,
            suggested_action=CascadeLevel.RETRY,
            root_cause="Unknown error",
            recovery_probability=0.50
        )
        
        assert diagnosis.metadata == {}
    
    def test_metadata_custom(self):
        """Test custom metadata"""
        diagnosis = DiagnosisResult(
            error_category=ErrorCategory.API_ERROR,
            confidence=0.60,
            suggested_action=CascadeLevel.FALLBACK_MODEL,
            root_cause="API returned 500",
            recovery_probability=0.65,
            metadata={"status_code": 500, "provider": "dashscope"}
        )
        
        assert diagnosis.metadata["status_code"] == 500
        assert diagnosis.metadata["provider"] == "dashscope"


class TestJitterConfig:
    """Test JitterConfig dataclass"""
    
    def test_default_config(self):
        """Test default jitter configuration"""
        config = JitterConfig()
        
        assert config.algorithm == "exponential"
        assert config.base_delay == 1.0
        assert config.max_delay == 60.0
        assert config.exponential_base == 2.0
        assert config.jitter_factor == 0.1
        assert config.max_retries == 3
    
    def test_custom_config(self):
        """Test custom jitter configuration"""
        config = JitterConfig(
            algorithm="full",
            base_delay=0.5,
            max_delay=30.0,
            exponential_base=1.5,
            jitter_factor=0.2,
            max_retries=5
        )
        
        assert config.algorithm == "full"
        assert config.base_delay == 0.5
        assert config.max_delay == 30.0
        assert config.exponential_base == 1.5
        assert config.jitter_factor == 0.2
        assert config.max_retries == 5
