"""
Test suite for jitter algorithms
Coverage target: 3 Jitter algorithms + with_jitter decorator (sync/async)
"""
import pytest
import asyncio
import time
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from src.types import JitterConfig
from src.jitter import (
    ExponentialJitter,
    FullJitter,
    EqualJitter,
    with_jitter,
    with_jitter_async
)


class TestExponentialJitter:
    """Test exponential jitter algorithm"""
    
    def test_default_config(self):
        """Test with default configuration"""
        jitter = ExponentialJitter()
        
        delay = jitter.calculate_delay(0)
        assert delay >= 0
        assert delay <= 60.0
    
    def test_delay_increases_with_attempts(self):
        """Test delay increases exponentially"""
        config = JitterConfig(
            base_delay=1.0,
            exponential_base=2.0,
            jitter_factor=0.0,
            max_delay=120.0
        )
        jitter = ExponentialJitter(config)
        
        delay_0 = jitter.calculate_delay(0)
        delay_1 = jitter.calculate_delay(1)
        delay_2 = jitter.calculate_delay(2)
        
        assert abs(delay_0 - 1.0) < 0.1
        assert abs(delay_1 - 2.0) < 0.1
        assert abs(delay_2 - 4.0) < 0.1
    
    def test_respects_max_delay(self):
        """Test delay respects maximum"""
        config = JitterConfig(
            base_delay=10.0,
            max_delay=15.0,
            exponential_base=2.0,
            jitter_factor=0.0
        )
        jitter = ExponentialJitter(config)
        
        delay = jitter.calculate_delay(10)
        assert delay <= config.max_delay
    
    def test_jitter_adds_randomness(self):
        """Test jitter introduces randomness"""
        config = JitterConfig(
            base_delay=1.0,
            exponential_base=2.0,
            jitter_factor=0.5,
            max_delay=60.0
        )
        jitter = ExponentialJitter(config)
        
        delays = [jitter.calculate_delay(1) for _ in range(10)]
        unique_delays = set(delays)
        
        assert len(unique_delays) > 1
    
    def test_custom_base_delay(self):
        """Test custom base delay"""
        config = JitterConfig(base_delay=0.5, jitter_factor=0.0)
        jitter = ExponentialJitter(config)
        
        delay = jitter.calculate_delay(0)
        assert abs(delay - 0.5) < 0.1


class TestFullJitter:
    """Test full jitter algorithm"""
    
    def test_random_between_zero_and_max(self):
        """Test delay is random between 0 and exponential max"""
        config = JitterConfig(
            base_delay=1.0,
            exponential_base=2.0,
            max_delay=100.0
        )
        jitter = FullJitter(config)
        
        for _ in range(20):
            delay = jitter.calculate_delay(2)
            assert delay >= 0
            assert delay <= 4.0
    
    def test_distribution_spread(self):
        """Test delay values show spread"""
        config = JitterConfig(base_delay=10.0, exponential_base=2.0, max_delay=100.0)
        jitter = FullJitter(config)
        
        delays = [jitter.calculate_delay(3) for _ in range(50)]
        
        min_delay = min(delays)
        max_delay = max(delays)
        
        assert max_delay > min_delay
        assert min_delay >= 0
        assert max_delay <= 80.0


class TestEqualJitter:
    """Test equal jitter algorithm"""
    
    def test_half_fixed_half_random(self):
        """Test delay is half fixed + half random"""
        config = JitterConfig(
            base_delay=2.0,
            exponential_base=2.0,
            jitter_factor=0.0,
            max_delay=100.0
        )
        jitter = EqualJitter(config)
        
        # With jitter_factor=0, delay should be exactly half
        # But EqualJitter adds random(0, base_delay), so we test the range
        delay = jitter.calculate_delay(1)
        expected_base = (2.0 * 2.0) / 2  # = 2.0
        
        # Delay should be between base and 2*base (base + random(0, base))
        assert expected_base <= delay <= (expected_base * 2)
    
    def test_jitter_range(self):
        """Test jitter adds randomness to half delay"""
        config = JitterConfig(
            base_delay=2.0,
            exponential_base=2.0,
            jitter_factor=0.5,
            max_delay=100.0
        )
        jitter = EqualJitter(config)
        
        delays = [jitter.calculate_delay(1) for _ in range(20)]
        unique_delays = set(delays)
        
        assert len(unique_delays) > 1


class TestWithJitterDecorator:
    """Test with_jitter decorator for sync functions"""
    
    def test_successful_call_no_retry(self):
        """Test successful call doesn't retry"""
        call_count = 0
        
        @with_jitter(jitter_type="exponential", config=JitterConfig(max_retries=3))
        def always_succeeds():
            nonlocal call_count
            call_count += 1
            return "success"
        
        result = always_succeeds()
        assert result == "success"
        assert call_count == 1
    
    def test_retry_on_failure_then_success(self):
        """Test retry after failures then success"""
        call_count = 0
        
        @with_jitter(jitter_type="exponential", config=JitterConfig(max_retries=3, jitter_factor=0.0))
        def fails_twice():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("Temporary error")
            return "success"
        
        result = fails_twice()
        assert result == "success"
        assert call_count == 3
    
    def test_exhausts_retries_then_raises(self):
        """Test raises exception after exhausting retries"""
        @with_jitter(jitter_type="exponential", config=JitterConfig(max_retries=2))
        def always_fails():
            raise ValueError("Permanent error")
        
        with pytest.raises(ValueError):
            always_fails()
    
    def test_different_jitter_types(self):
        """Test different jitter types work"""
        for jitter_type in ["exponential", "full", "equal"]:
            call_count = 0
            
            @with_jitter(jitter_type=jitter_type, config=JitterConfig(max_retries=1, jitter_factor=0.1))
            def test_func():
                nonlocal call_count
                call_count += 1
                if call_count == 1:
                    raise Exception("First fail")
                return "ok"
            
            result = test_func()
            assert result == "ok"


class TestWithJitterAsync:
    """Test with_jitter_async for async functions"""
    
    @pytest.mark.asyncio
    async def test_successful_async_call(self):
        """Test successful async call"""
        call_count = 0
        
        async def succeeds():
            nonlocal call_count
            call_count += 1
            return "async success"
        
        result = await with_jitter_async(
            succeeds,
            jitter_type="exponential",
            config=JitterConfig(max_retries=3)
        )
        
        assert result == "async success"
        assert call_count == 1
    
    @pytest.mark.asyncio
    async def test_retry_async_on_failure(self):
        """Test async retry after failures"""
        call_count = 0
        
        async def fails_once():
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise ValueError("Async temporary error")
            return "async success"
        
        result = await with_jitter_async(
            fails_once,
            jitter_type="exponential",
            config=JitterConfig(max_retries=2, jitter_factor=0.0)
        )
        
        assert result == "async success"
        assert call_count == 2
    
    @pytest.mark.asyncio
    async def test_async_exhausts_retries(self):
        """Test async function exhausts retries"""
        async def always_fails_async():
            raise ValueError("Async permanent error")
        
        with pytest.raises(ValueError):
            await with_jitter_async(
                always_fails_async,
                jitter_type="exponential",
                config=JitterConfig(max_retries=2)
            )
    
    @pytest.mark.asyncio
    async def test_async_respects_delay(self):
        """Test async respects delay timing"""
        start_time = time.time()
        
        async def fails_quickly():
            raise ValueError("Error")
        
        config = JitterConfig(base_delay=0.1, max_retries=1, jitter_factor=0.0)
        
        with pytest.raises(ValueError):
            await with_jitter_async(
                fails_quickly,
                jitter_type="exponential",
                config=config
            )
        
        elapsed = time.time() - start_time
        assert elapsed >= 0.1
