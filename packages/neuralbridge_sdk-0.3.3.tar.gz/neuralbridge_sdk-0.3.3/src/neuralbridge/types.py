"""
Core type definitions for NeuralBridge SDK v3
"""
from enum import Enum
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from datetime import datetime


class ErrorCategory(str, Enum):
    """LLM error classification"""
    NETWORK_TIMEOUT = "network_timeout"
    RATE_LIMIT = "rate_limit"
    API_ERROR = "api_error"
    MODEL_ERROR = "model_error"
    CONTEXT_LENGTH = "context_length"
    AUTHENTICATION = "authentication"
    UNKNOWN = "unknown"


class CascadeLevel(str, Enum):
    """Self-healing cascade levels"""
    RETRY = "retry"
    FALLBACK_MODEL = "fallback_model"
    FALLBACK_PROVIDER = "fallback_provider"
    TERMINATE = "terminate"


@dataclass
class ModelPerformance:
    """Model performance metrics"""
    model_name: str
    avg_latency_ms: float
    success_rate: float
    total_requests: int
    failed_requests: int
    last_error: Optional[str] = None
    last_success_at: Optional[datetime] = None
    
    def health_score(self) -> float:
        """Calculate health score (0-100)"""
        latency_score = max(0, 100 - (self.avg_latency_ms / 10))
        success_score = self.success_rate * 100
        return (latency_score + success_score) / 2


@dataclass
class DiagnosisResult:
    """Diagnosis result from error analysis"""
    error_category: ErrorCategory
    confidence: float
    suggested_action: CascadeLevel
    root_cause: str
    recovery_probability: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def is_recoverable(self) -> bool:
        """Check if error is recoverable via self-healing"""
        return self.suggested_action != CascadeLevel.TERMINATE


@dataclass
class JitterConfig:
    """Configuration for jitter algorithms"""
    algorithm: str = "exponential"
    base_delay: float = 1.0
    max_delay: float = 60.0
    exponential_base: float = 2.0
    jitter_factor: float = 0.1
    max_retries: int = 3
