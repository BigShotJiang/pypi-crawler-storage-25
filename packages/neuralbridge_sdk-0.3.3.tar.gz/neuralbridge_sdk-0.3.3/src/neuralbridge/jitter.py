"""
Jitter algorithms for retry delay randomization
"""
import random
import asyncio
import time
from typing import Callable, Any, Optional
from functools import wraps
from .types import JitterConfig


class BaseJitter:
    """Base jitter algorithm"""
    
    def __init__(self, config: Optional[JitterConfig] = None):
        self.config = config or JitterConfig()
    
    def calculate_delay(self, attempt: int) -> float:
        """Calculate delay with jitter for given attempt"""
        raise NotImplementedError


class ExponentialJitter(BaseJitter):
    """Exponential backoff with full jitter"""
    
    def calculate_delay(self, attempt: int) -> float:
        base_delay = self.config.base_delay * (
            self.config.exponential_base ** attempt
        )
        jitter_range = self.config.jitter_factor * base_delay
        jitter = random.uniform(-jitter_range, jitter_range)
        return max(0, min(base_delay + jitter, self.config.max_delay))


class FullJitter(BaseJitter):
    """Full jitter: random between 0 and exponential backoff"""
    
    def calculate_delay(self, attempt: int) -> float:
        max_delay = self.config.base_delay * (
            self.config.exponential_base ** attempt
        )
        return min(random.uniform(0, max_delay), self.config.max_delay)


class EqualJitter(BaseJitter):
    """Equal jitter: half fixed, half random"""
    
    def calculate_delay(self, attempt: int) -> float:
        base_delay = self.config.base_delay * (
            self.config.exponential_base ** attempt
        ) / 2
        jitter = random.uniform(0, base_delay)
        return min(base_delay + jitter, self.config.max_delay)


def with_jitter(
    jitter_type: str = "exponential",
    config: Optional[JitterConfig] = None
) -> Callable:
    """Decorator to add jitter-based retry logic to sync functions"""
    
    jitter_map = {
        "exponential": ExponentialJitter,
        "full": FullJitter,
        "equal": EqualJitter
    }
    
    jitter_instance = jitter_map.get(jitter_type, ExponentialJitter)(config)
    
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            max_retries = config.max_retries if config else 3
            
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries:
                        raise
                    
                    delay = jitter_instance.calculate_delay(attempt)
                    time.sleep(delay)
            
            return None
        
        return wrapper
    
    return decorator


async def with_jitter_async(
    func: Callable,
    *args,
    jitter_type: str = "exponential",
    config: Optional[JitterConfig] = None,
    **kwargs
) -> Any:
    """Async context manager for jitter-based retries"""
    
    jitter_map = {
        "exponential": ExponentialJitter,
        "full": FullJitter,
        "equal": EqualJitter
    }
    
    jitter_instance = jitter_map.get(jitter_type, ExponentialJitter)(config)
    max_retries = config.max_retries if config else 3
    
    for attempt in range(max_retries + 1):
        try:
            return await func(*args, **kwargs)
        except Exception as e:
            if attempt == max_retries:
                raise
            
            delay = jitter_instance.calculate_delay(attempt)
            await asyncio.sleep(delay)
    
    return None
