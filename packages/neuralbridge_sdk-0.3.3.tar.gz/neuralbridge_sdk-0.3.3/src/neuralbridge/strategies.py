"""
Self-healing strategy implementations
"""
import random
import time
from abc import ABC, abstractmethod
from typing import Optional, List
from .types import ErrorCategory, CascadeLevel, DiagnosisResult, JitterConfig


class SelfHealingStrategy(ABC):
    """Base class for self-healing strategies"""
    
    @abstractmethod
    def should_retry(self, diagnosis: DiagnosisResult) -> bool:
        """Determine if retry should be attempted"""
        pass
    
    @abstractmethod
    def get_delay(self, attempt: int) -> float:
        """Calculate delay before next retry"""
        pass
    
    @abstractmethod
    def select_fallback_model(self, available_models: List[str]) -> Optional[str]:
        """Select fallback model from available options"""
        pass


class ExponentialBackoffStrategy(SelfHealingStrategy):
    """Exponential backoff with jitter"""
    
    def __init__(self, config: Optional[JitterConfig] = None):
        self.config = config or JitterConfig()
    
    def should_retry(self, diagnosis: DiagnosisResult) -> bool:
        return diagnosis.is_recoverable() and \
               diagnosis.error_category in [
                   ErrorCategory.NETWORK_TIMEOUT,
                   ErrorCategory.RATE_LIMIT
               ]
    
    def get_delay(self, attempt: int) -> float:
        base_delay = self.config.base_delay * (
            self.config.exponential_base ** attempt
        )
        jitter = random.uniform(
            -self.config.jitter_factor * base_delay,
            self.config.jitter_factor * base_delay
        )
        return min(base_delay + jitter, self.config.max_delay)
    
    def select_fallback_model(self, available_models: List[str]) -> Optional[str]:
        if not available_models:
            return None
        return available_models[0]


class AdaptiveStrategy(SelfHealingStrategy):
    """Adaptive strategy based on historical performance"""
    
    def __init__(self, window_size: int = 10):
        self.window_size = window_size
        self.history: List[float] = []
    
    def should_retry(self, diagnosis: DiagnosisResult) -> bool:
        if not diagnosis.is_recoverable():
            return False
        
        avg_success_rate = sum(self.history) / len(self.history) if self.history else 0.5
        return avg_success_rate > 0.3
    
    def get_delay(self, attempt: int) -> float:
        if not self.history:
            return 1.0
        
        recent_avg = sum(self.history[-5:]) / min(len(self.history[-5:]), 5)
        base_delay = 1.0 / (recent_avg + 0.1)
        return min(base_delay * (attempt + 1), 60.0)
    
    def select_fallback_model(self, available_models: List[str]) -> Optional[str]:
        if not available_models:
            return None
        return random.choice(available_models)
    
    def record_outcome(self, success: bool):
        """Record outcome for adaptive learning"""
        self.history.append(1.0 if success else 0.0)
        if len(self.history) > self.window_size:
            self.history.pop(0)


class CircuitBreakerStrategy(SelfHealingStrategy):
    """Circuit breaker pattern implementation"""
    
    def __init__(self, failure_threshold: int = 5, recovery_timeout: float = 30.0):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failure_count = 0
        self.last_failure_time: Optional[float] = None
        self.state = "closed"
    
    def should_retry(self, diagnosis: DiagnosisResult) -> bool:
        if self.state == "open":
            if time.time() - self.last_failure_time > self.recovery_timeout:
                self.state = "half-open"
                return True
            return False
        
        return diagnosis.is_recoverable()
    
    def get_delay(self, attempt: int) -> float:
        return 0.0
    
    def select_fallback_model(self, available_models: List[str]) -> Optional[str]:
        if not available_models:
            return None
        return available_models[-1]
    
    def record_success(self):
        """Record successful call"""
        self.failure_count = 0
        self.state = "closed"
    
    def record_failure(self):
        """Record failed call"""
        self.failure_count += 1
        self.last_failure_time = time.time()
        if self.failure_count >= self.failure_threshold:
            self.state = "open"


class StrategyRegistry:
    """Registry for managing healing strategies"""
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.strategies = {}
        return cls._instance
    
    def register(self, name: str, strategy: SelfHealingStrategy):
        """Register a strategy"""
        self.strategies[name] = strategy
    
    def get(self, name: str) -> Optional[SelfHealingStrategy]:
        """Get strategy by name"""
        return self.strategies.get(name)
    
    def list_strategies(self) -> List[str]:
        """List all registered strategy names"""
        return list(self.strategies.keys())
