"""
Diagnosis and self-healing engine for NeuralBridge SDK
"""
import asyncio
import time
from typing import Optional, List, Dict, Any, Callable
from .types import (
    ErrorCategory, CascadeLevel, DiagnosisResult, 
    ModelPerformance, JitterConfig
)
from .strategies import SelfHealingStrategy, ExponentialBackoffStrategy


class DiagnosisEngine:
    """LLM error diagnosis engine"""
    
    def __init__(self):
        self.error_patterns = {
            "timeout": ErrorCategory.NETWORK_TIMEOUT,
            "rate limit": ErrorCategory.RATE_LIMIT,
            "quota": ErrorCategory.RATE_LIMIT,
            "invalid api key": ErrorCategory.AUTHENTICATION,
            "model not found": ErrorCategory.MODEL_ERROR,
            "context length": ErrorCategory.CONTEXT_LENGTH,
            "not found": ErrorCategory.MODEL_ERROR,
        }
    
    def diagnose(self, error_message: str, status_code: Optional[int] = None) -> DiagnosisResult:
        """Diagnose error and suggest recovery action"""
        error_lower = error_message.lower()
        
        for pattern, category in self.error_patterns.items():
            if pattern in error_lower:
                return self._create_diagnosis(category, error_message)
        
        if status_code:
            if status_code >= 500:
                return self._create_diagnosis(ErrorCategory.API_ERROR, error_message)
            elif status_code == 429:
                return self._create_diagnosis(ErrorCategory.RATE_LIMIT, error_message)
            elif status_code in [401, 403]:
                return self._create_diagnosis(ErrorCategory.AUTHENTICATION, error_message)
        
        return self._create_diagnosis(ErrorCategory.UNKNOWN, error_message)
    
    def _create_diagnosis(
        self, 
        category: ErrorCategory, 
        error_message: str
    ) -> DiagnosisResult:
        """Create diagnosis result based on error category"""
        action_map = {
            ErrorCategory.NETWORK_TIMEOUT: CascadeLevel.RETRY,
            ErrorCategory.RATE_LIMIT: CascadeLevel.RETRY,
            ErrorCategory.API_ERROR: CascadeLevel.RETRY,
            ErrorCategory.MODEL_ERROR: CascadeLevel.FALLBACK_MODEL,
            ErrorCategory.CONTEXT_LENGTH: CascadeLevel.TERMINATE,
            ErrorCategory.AUTHENTICATION: CascadeLevel.TERMINATE,
            ErrorCategory.UNKNOWN: CascadeLevel.RETRY,
        }
        
        recovery_probs = {
            ErrorCategory.NETWORK_TIMEOUT: 0.85,
            ErrorCategory.RATE_LIMIT: 0.75,
            ErrorCategory.API_ERROR: 0.60,
            ErrorCategory.MODEL_ERROR: 0.90,
            ErrorCategory.CONTEXT_LENGTH: 0.0,
            ErrorCategory.AUTHENTICATION: 0.0,
            ErrorCategory.UNKNOWN: 0.50,
        }
        
        return DiagnosisResult(
            error_category=category,
            confidence=0.8,
            suggested_action=action_map[category],
            root_cause=error_message,
            recovery_probability=recovery_probs[category]
        )


class FlywheelEngine:
    """Self-healing flywheel engine with continuous improvement"""
    
    def __init__(
        self,
        strategy: Optional[SelfHealingStrategy] = None,
        jitter_config: Optional[JitterConfig] = None
    ):
        self.diagnosis_engine = DiagnosisEngine()
        self.strategy = strategy or ExponentialBackoffStrategy(jitter_config)
        self.jitter_config = jitter_config or JitterConfig()
        self.model_performances: Dict[str, ModelPerformance] = {}
        self.healing_history: List[Dict[str, Any]] = []
    
    def heal(
        self,
        error_message: str,
        current_model: str,
        available_models: Optional[List[str]] = None,
        status_code: Optional[int] = None
    ) -> Dict[str, Any]:
        """Synchronous self-healing execution"""
        diagnosis = self.diagnosis_engine.diagnose(error_message, status_code)
        
        result = {
            "diagnosis": diagnosis,
            "action_taken": None,
            "success": False,
            "new_model": None,
            "retry_delay": None
        }
        
        if diagnosis.suggested_action == CascadeLevel.TERMINATE:
            result["action_taken"] = "terminate"
            return result
        
        if diagnosis.suggested_action == CascadeLevel.RETRY:
            delay = self.strategy.get_delay(self._get_retry_count(current_model))
            result["action_taken"] = "retry"
            result["retry_delay"] = delay
            result["success"] = diagnosis.is_recoverable()
        
        elif diagnosis.suggested_action == CascadeLevel.FALLBACK_MODEL:
            fallback = self.strategy.select_fallback_model(available_models or [])
            if fallback:
                result["action_taken"] = "fallback_model"
                result["new_model"] = fallback
                result["success"] = True
        
        self._record_healing_event(current_model, result)
        return result
    
    async def heal_async(
        self,
        error_message: str,
        current_model: str,
        available_models: Optional[List[str]] = None,
        status_code: Optional[int] = None
    ) -> Dict[str, Any]:
        """Asynchronous self-healing execution"""
        result = self.heal(error_message, current_model, available_models, status_code)
        
        if result["retry_delay"]:
            await asyncio.sleep(result["retry_delay"])
        
        return result
    
    def get_health_status(self, model_name: str) -> Dict[str, Any]:
        """Get health status for a specific model"""
        if model_name not in self.model_performances:
            return {"status": "unknown", "health_score": 0}
        
        perf = self.model_performances[model_name]
        health_score = perf.health_score()
        
        return {
            "status": "healthy" if health_score > 80 else "degraded" if health_score > 50 else "unhealthy",
            "health_score": health_score,
            "avg_latency_ms": perf.avg_latency_ms,
            "success_rate": perf.success_rate,
            "total_requests": perf.total_requests
        }
    
    def record_performance(
        self,
        model_name: str,
        latency_ms: float,
        success: bool,
        error_message: Optional[str] = None
    ):
        """Record model performance metrics"""
        if model_name not in self.model_performances:
            self.model_performances[model_name] = ModelPerformance(
                model_name=model_name,
                avg_latency_ms=latency_ms,
                success_rate=1.0 if success else 0.0,
                total_requests=1,
                failed_requests=0 if success else 1
            )
        else:
            perf = self.model_performances[model_name]
            n = perf.total_requests
            perf.avg_latency_ms = ((perf.avg_latency_ms * n) + latency_ms) / (n + 1)
            perf.total_requests += 1
            if not success:
                perf.failed_requests += 1
            perf.success_rate = 1.0 - (perf.failed_requests / perf.total_requests)
            if success:
                perf.last_success_at = time.time()
            perf.last_error = error_message
    
    def _get_retry_count(self, model_name: str) -> int:
        """Get retry count for model"""
        events = [e for e in self.healing_history if e["model"] == model_name]
        return len(events)
    
    def _record_healing_event(self, model_name: str, result: Dict[str, Any]):
        """Record healing event to history"""
        self.healing_history.append({
            "timestamp": time.time(),
            "model": model_name,
            "action": result["action_taken"],
            "success": result["success"]
        })


# Backward compatibility alias for v0.2.0 API
NeuralBridge = FlywheelEngine
