"""
NeuralBridge SDK v3 - Self-healing engine for LLM APIs
"""
from .types import (
    ErrorCategory,
    CascadeLevel,
    ModelPerformance,
    DiagnosisResult,
    JitterConfig
)
from .engine import DiagnosisEngine, FlywheelEngine, NeuralBridge
from .strategies import (
    ExponentialBackoffStrategy,
    AdaptiveStrategy,
    CircuitBreakerStrategy,
    StrategyRegistry
)
from .jitter import (
    ExponentialJitter,
    FullJitter,
    EqualJitter,
    with_jitter,
    with_jitter_async
)

__version__ = "0.3.2"
__all__ = [
    # Core classes
    "NeuralBridge",  # Backward compatibility alias
    "DiagnosisEngine",
    "FlywheelEngine",
    # Types
    "ErrorCategory",
    "CascadeLevel",
    "ModelPerformance",
    "DiagnosisResult",
    "JitterConfig",
    # Strategies
    "ExponentialBackoffStrategy",
    "AdaptiveStrategy",
    "CircuitBreakerStrategy",
    "StrategyRegistry",
    # Jitter functions
    "ExponentialJitter",
    "FullJitter",
    "EqualJitter",
    "with_jitter",
    "with_jitter_async"
]
