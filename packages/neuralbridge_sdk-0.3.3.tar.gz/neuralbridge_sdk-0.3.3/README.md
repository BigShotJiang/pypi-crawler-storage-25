# NeuralBridge SDK

**Self-healing engine for LLM APIs** - Automatic fault diagnosis and 4-level cascade recovery

## Features

- 🎯 **LLM Fault Semantic Diagnosis**: Automatically identifies 10+ LLM-specific error categories (rate limits, context overflow, model errors, etc.)
- 🔄 **4-Level Cascade Recovery**: Hierarchical retry strategy from fast retry → provider failover → model downgrade → manual intervention
- 🛡️ **Native Model-Level Self-Healing**: Prevents avalanche failures with adaptive circuit breakers
- ⚡ **Production-Ready**: Tested against DashScope (Qwen) and DeepSeek APIs with 100% success rate

## Installation

```bash
pip install neuralbridge-sdk
```

## Quick Start

```python
from neuralbridge_sdk import FlywheelEngine, ErrorCategory

engine = FlywheelEngine(
    primary_provider="dashscope",
    backup_provider="deepseek",
    api_keys={
        "dashscope": "YOUR_DASHSCOPE_KEY",
        "deepseek": "YOUR_DEEPSEEK_KEY"
    }
)

# Automatic self-healing with semantic diagnosis
response = engine.chat.completions.create(
    model="qwen-turbo",
    messages=[{"role": "user", "content": "Hello"}]
)

print(response.choices[0].message.content)
```

## Performance Benchmarks

| Metric | Value |
|--------|-------|
| Latency (DashScope) | 732ms avg |
| Success Rate | 100% |
| Cost per 1K tokens | ¥0.0001 CNY |
| Test Coverage | ≥80% |

## Documentation

Visit [https://neuralbridge.ai/docs](https://neuralbridge.ai/docs) for full API reference and guides.

## License

Proprietary - All rights reserved

## Contact

admin@neuralbridge.ai
