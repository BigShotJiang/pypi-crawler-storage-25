from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field



class LoggingOptions(BaseModel):
    """LoggingOptions"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    enabled: bool = Field(description='Opts this request in to durable server-side request logging.')
    caller_attributes: Optional[dict[str, Any]] = Field(default=None, description='Optional flat scalar attributes attached to the persisted log row. Supported value types are string, integer, floating-point, and boolean.', alias="callerAttributes")

