"""
watcher.py — File system watcher for incremental re-indexing.

Uses watchdog to detect file changes and triggers incremental re-indexing.
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from threading import Event

from rich.console import Console

from agsuperbrain.analytics.report import generate_report
from agsuperbrain.core.pipeline import CodeGraphPipeline
from agsuperbrain.memory.graph.graph_store import GraphStore
from agsuperbrain.memory.graph.visualizer import visualize as viz
from agsuperbrain.memory.vector.vector_store import VectorStore

console = Console()


def _file_hash(fp: Path) -> str:
    """Compute MD5 hash of file content."""
    if not fp.exists():
        return ""
    try:
        return hashlib.md5(fp.read_bytes()).hexdigest()
    except Exception:
        return ""


class FileWatcher:
    """
    Watch directories for changes and re-index modified files.

    Usage:
        watcher = FileWatcher(graph_store, vector_store, paths_to_watch)
        watcher.start()  # runs in background
        # or
        watcher.run_once()  # single pass
    """

    def __init__(
        self,
        graph_store: GraphStore,
        vector_store: VectorStore,
        watch_paths: list[Path],
        exclude_dirs: frozenset[str] | None = None,
    ):
        self.gs = graph_store
        self.vs = vector_store
        self.watch_paths = watch_paths
        self.exclude_dirs = exclude_dirs or frozenset()
        self._file_hashes: dict[Path, str] = {}
        self._pipeline = CodeGraphPipeline(graph_store, vector_store)
        self._stop_event = Event()

    def _should_process(self, fp: Path) -> bool:
        """Check if file should be processed based on extensions."""
        if not fp.exists():
            return False
        ext = fp.suffix.lower()
        return ext in (".py", ".js", ".ts", ".mjs")

    def _is_excluded(self, fp: Path) -> bool:
        """Check if file is in excluded directory."""
        return any(part in self.exclude_dirs for part in fp.parts)

    def _get_changed_files(self) -> list[Path]:
        """Find files that have changed since last check."""
        changed = []
        for wp in self.watch_paths:
            if not wp.exists():
                continue
            if wp.is_file():
                candidates = [wp]
            else:
                candidates = [fp for fp in wp.rglob("*") if fp.is_file() and self._should_process(fp)]

            for fp in candidates:
                if self._is_excluded(fp):
                    continue
                current_hash = _file_hash(fp)
                if fp not in self._file_hashes:
                    if current_hash:
                        changed.append(fp)
                        self._file_hashes[fp] = current_hash
                elif self._file_hashes[fp] != current_hash:
                    changed.append(fp)
                    self._file_hashes[fp] = current_hash

        return changed

    def run_once(self) -> int:
        """
        Single pass: detect changes and re-index.
        Also sweeps graph entries for files deleted since the last pass.
        Returns number of files re-indexed.
        """
        changed = self._get_changed_files()
        self._pipeline.sync_deleted_files()

        if not changed:
            console.print("[dim]No changes detected[/dim]")
            return 0

        console.print(f"[cyan]Re-indexing {len(changed)} file(s):[/cyan]")
        for fp in changed:
            console.print(f"  [green]{fp}[/green]")

        self._pipeline.run(changed, verbose=True)

        self._generate_reports()

        return len(changed)

    def _generate_reports(self) -> None:
        """Generate graph.html and GRAPH_REPORT.md in .agsuperbrain dir after re-indexing."""
        project_root = self.watch_paths[0].resolve() if self.watch_paths else Path(".")
        output_dir = project_root / ".agsuperbrain"
        html_path = output_dir / "graph.html"
        report_path = output_dir / "GRAPH_REPORT.md"

        output_dir.mkdir(parents=True, exist_ok=True)

        try:
            viz(self.gs, html_path, None, 3)
            console.print(f"[dim]Updated:[/dim] {html_path}")
        except Exception as e:
            console.print(f"[yellow]Warning: failed to generate graph.html: {e}[/yellow]")

        try:
            md = generate_report(self.gs)
            report_path.write_text(md, encoding="utf-8")
            console.print(f"[dim]Updated:[/dim] {report_path}")
        except Exception as e:
            console.print(f"[yellow]Warning: failed to generate GRAPH_REPORT.md: {e}[/yellow]")

    def start(self, poll_interval: float = 2.0) -> None:
        """
        Start continuous watching loop.
        Use stop() to exit.
        """
        console.print(f"[cyan]Watching {len(self.watch_paths)} path(s) for changes...[/cyan]")
        console.print("[dim]Press Ctrl+C to stop[/dim]")

        while not self._stop_event.is_set():
            self.run_once()
            self._stop_event.wait(poll_interval)

    def stop(self) -> None:
        """Signal the watcher to stop."""
        self._stop_event.set()
