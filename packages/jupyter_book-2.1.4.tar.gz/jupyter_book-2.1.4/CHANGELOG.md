# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 2.1.4

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/v2.1.3...a3f7741f752c1b5c20467fbb70f337907e44f567))

### Maintenance and upkeep improvements

- bump myst version [#2607](https://github.com/jupyter-book/jupyter-book/pull/2607) ([@choldgraf](https://github.com/choldgraf))
- 🔑 Remove NPM_TOKEN in publish workflow [#2605](https://github.com/jupyter-book/jupyter-book/pull/2605) ([@agoose77](https://github.com/agoose77))
- Bump MyST and add toc children option [#2600](https://github.com/jupyter-book/jupyter-book/pull/2600) ([@choldgraf](https://github.com/choldgraf))
- Bump actions/setup-python from 5 to 6 in /.github/workflows in the actions group [#2596](https://github.com/jupyter-book/jupyter-book/pull/2596) ([@agoose77](https://github.com/agoose77))

### Documentation improvements

- Docs: patch url for v1 docs (`*/v1` --> `*/v1/intro.html`) [#2598](https://github.com/jupyter-book/jupyter-book/pull/2598) ([@evdcush](https://github.com/evdcush), [@bsipocz](https://github.com/bsipocz))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2026-02-13&to=2026-04-01&type=c))

@agoose77 ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2026-02-13..2026-04-01&type=Issues)) | @bsipocz ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Absipocz+updated%3A2026-02-13..2026-04-01&type=Issues)) | @choldgraf ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Acholdgraf+updated%3A2026-02-13..2026-04-01&type=Issues)) | @evdcush ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aevdcush+updated%3A2026-02-13..2026-04-01&type=Issues))

<!-- <END NEW CHANGELOG ENTRY> -->

## 2.1.3

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/v2.1.2...9440c9b3b69838ba9829bca5e5e0dcd7c3237501))

### Maintenance and upkeep improvements

- Add release documentation to our docs and bump mystmd version [#2586](https://github.com/jupyter-book/jupyter-book/pull/2586) ([@choldgraf](https://github.com/choldgraf))
- Bump actions/setup-node from 6.1.0 to 6.2.0 in /.github/workflows in the actions group [#2577](https://github.com/jupyter-book/jupyter-book/pull/2577) ([@bsipocz](https://github.com/bsipocz))

### Documentation improvements

- Move some repo-specific documentation back here [#2582](https://github.com/jupyter-book/jupyter-book/pull/2582) ([@choldgraf](https://github.com/choldgraf))
- Fix broken quick links in CONTRIBUTING.md [#2580](https://github.com/jupyter-book/jupyter-book/pull/2580) ([@Varshiniputtabakula](https://github.com/Varshiniputtabakula), [@choldgraf](https://github.com/choldgraf))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2026-02-01&to=2026-02-13&type=c))

@bsipocz ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Absipocz+updated%3A2026-02-01..2026-02-13&type=Issues)) | @choldgraf ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Acholdgraf+updated%3A2026-02-01..2026-02-13&type=Issues)) | @Varshiniputtabakula ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3AVarshiniputtabakula+updated%3A2026-02-01..2026-02-13&type=Issues))

## 2.1.2

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/v2.1.1...cc93a6372815c53eb404b4b7477156704220b785))

### Maintenance and upkeep improvements

- Bump the actions group across 1 directory with 2 updates [#2571](https://github.com/jupyter-book/jupyter-book/pull/2571) ([@bsipocz](https://github.com/bsipocz))
- fix: specify `files` in package.json [#2568](https://github.com/jupyter-book/jupyter-book/pull/2568) ([@agoose77](https://github.com/agoose77), [@bsipocz](https://github.com/bsipocz), [@choldgraf](https://github.com/choldgraf))
- Bump actions/create-github-app-token from 1 to 2 [#2555](https://github.com/jupyter-book/jupyter-book/pull/2555) ([@bsipocz](https://github.com/bsipocz))

### Documentation improvements

- Move content to jupyterbook.org repo [#2575](https://github.com/jupyter-book/jupyter-book/pull/2575) ([@choldgraf](https://github.com/choldgraf))
- doc: fix the stated math engine to be KaTeX [#2570](https://github.com/jupyter-book/jupyter-book/pull/2570) ([@akhmerov](https://github.com/akhmerov), [@bsipocz](https://github.com/bsipocz), [@rowanc1](https://github.com/rowanc1))
- Update release instructions [#2562](https://github.com/jupyter-book/jupyter-book/pull/2562) ([@choldgraf](https://github.com/choldgraf), [@agoose77](https://github.com/agoose77), [@bsipocz](https://github.com/bsipocz))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2026-01-22&to=2026-02-01&type=c))

@agoose77 ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2026-01-22..2026-02-01&type=Issues)) | @akhmerov ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aakhmerov+updated%3A2026-01-22..2026-02-01&type=Issues)) | @bsipocz ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Absipocz+updated%3A2026-01-22..2026-02-01&type=Issues)) | @choldgraf ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Acholdgraf+updated%3A2026-01-22..2026-02-01&type=Issues)) | @rowanc1 ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Arowanc1+updated%3A2026-01-22..2026-02-01&type=Issues))

## 2.1.1

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/v2.1.0...c6641134ad9ec769c6a44243d435a0b2d07abd0a))

### Bugs fixed

- Remove description from dynamic [#2518](https://github.com/jupyter-book/jupyter-book/pull/2518) ([@choldgraf](https://github.com/choldgraf), [@agoose77](https://github.com/agoose77))

### Maintenance and upkeep improvements

- Update latest myst cli [#2563](https://github.com/jupyter-book/jupyter-book/pull/2563) ([@choldgraf](https://github.com/choldgraf), [@agoose77](https://github.com/agoose77))
- MAINT: adding more dependabot config to ensure less noise and passing PRs [#2560](https://github.com/jupyter-book/jupyter-book/pull/2560) ([@bsipocz](https://github.com/bsipocz))
- Bump actions/upload-pages-artifact from 3 to 4 [#2558](https://github.com/jupyter-book/jupyter-book/pull/2558) ([@bsipocz](https://github.com/bsipocz))
- Bump actions/checkout from 2 to 6 [#2557](https://github.com/jupyter-book/jupyter-book/pull/2557) ([@bsipocz](https://github.com/bsipocz))
- Bump actions/setup-node from 4 to 6 [#2556](https://github.com/jupyter-book/jupyter-book/pull/2556) ([@bsipocz](https://github.com/bsipocz))
- Bump actions/configure-pages from 3 to 5 [#2554](https://github.com/jupyter-book/jupyter-book/pull/2554) ([@bsipocz](https://github.com/bsipocz))
- update GitHub Actions via Dependabot [#2535](https://github.com/jupyter-book/jupyter-book/pull/2535) ([@afeld](https://github.com/afeld), [@bsipocz](https://github.com/bsipocz), [@choldgraf](https://github.com/choldgraf))
- MAINT: adding description metadata [#2516](https://github.com/jupyter-book/jupyter-book/pull/2516) ([@bsipocz](https://github.com/bsipocz), [@choldgraf](https://github.com/choldgraf), [@rowanc1](https://github.com/rowanc1))

### Documentation improvements

- include custom css [#2551](https://github.com/jupyter-book/jupyter-book/pull/2551) ([@FreekPols](https://github.com/FreekPols))
- Surface JB v1 docs more prominently, and reorganize General FAQs [#2545](https://github.com/jupyter-book/jupyter-book/pull/2545) ([@emiliom](https://github.com/emiliom), [@bsipocz](https://github.com/bsipocz), [@choldgraf](https://github.com/choldgraf), [@rowanc1](https://github.com/rowanc1))
- document breaking changes in web page path behavior [#2536](https://github.com/jupyter-book/jupyter-book/pull/2536) ([@afeld](https://github.com/afeld), [@choldgraf](https://github.com/choldgraf))
- Add Protein–Peptide Molecular Mimicry Study entry [#2532](https://github.com/jupyter-book/jupyter-book/pull/2532) ([@singh-sanju](https://github.com/singh-sanju), [@FreekPols](https://github.com/FreekPols))
- DOC: rewrite Fornax gallery entries [#2531](https://github.com/jupyter-book/jupyter-book/pull/2531) ([@bsipocz](https://github.com/bsipocz), [@choldgraf](https://github.com/choldgraf))
- Un-comment blog in nav [#2529](https://github.com/jupyter-book/jupyter-book/pull/2529) ([@choldgraf](https://github.com/choldgraf))
- Update gallery.yml [#2527](https://github.com/jupyter-book/jupyter-book/pull/2527) ([@snowch](https://github.com/snowch), [@bsipocz](https://github.com/bsipocz))
- DOC: update IRSA title to have astronomy mentioned somewhere [#2524](https://github.com/jupyter-book/jupyter-book/pull/2524) ([@bsipocz](https://github.com/bsipocz), [@rowanc1](https://github.com/rowanc1))
- :book: Add RELEASE [#2521](https://github.com/jupyter-book/jupyter-book/pull/2521) ([@agoose77](https://github.com/agoose77))
- update myst tables plugin [#2519](https://github.com/jupyter-book/jupyter-book/pull/2519) ([@choldgraf](https://github.com/choldgraf), [@bsipocz](https://github.com/bsipocz))
- randomized gallery [#2512](https://github.com/jupyter-book/jupyter-book/pull/2512) ([@FreekPols](https://github.com/FreekPols), [@bsipocz](https://github.com/bsipocz))

### Other merged PRs

- Fix image mechanics book [#2550](https://github.com/jupyter-book/jupyter-book/pull/2550) ([@FreekPols](https://github.com/FreekPols))
- Add `dolfiny` to gallery [#2548](https://github.com/jupyter-book/jupyter-book/pull/2548) ([@schnellerhase](https://github.com/schnellerhase), [@FreekPols](https://github.com/FreekPols))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2025-12-05&to=2026-01-22&type=c))

@afeld ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aafeld+updated%3A2025-12-05..2026-01-22&type=Issues)) | @agoose77 ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2025-12-05..2026-01-22&type=Issues)) | @bsipocz ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Absipocz+updated%3A2025-12-05..2026-01-22&type=Issues)) | @choldgraf ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Acholdgraf+updated%3A2025-12-05..2026-01-22&type=Issues)) | @emiliom ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aemiliom+updated%3A2025-12-05..2026-01-22&type=Issues)) | @FreekPols ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3AFreekPols+updated%3A2025-12-05..2026-01-22&type=Issues)) | @rowanc1 ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Arowanc1+updated%3A2025-12-05..2026-01-22&type=Issues)) | @schnellerhase ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aschnellerhase+updated%3A2025-12-05..2026-01-22&type=Issues)) | @singh-sanju ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Asingh-sanju+updated%3A2025-12-05..2026-01-22&type=Issues)) | @snowch ([activity](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Asnowch+updated%3A2025-12-05..2026-01-22&type=Issues))

## 2.1.0

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/v2.0.2...c75d44db5e5015ad93d35aff0c27d8510c948a1d))

### Enhancements made

- Gallery of Jupyter Books (with the myst stack) [#2461](https://github.com/jupyter-book/jupyter-book/pull/2461) ([@FreekPols](https://github.com/FreekPols))

### Maintenance and upkeep improvements

- MAINT: exclude non-third-party packages from dependabot cooldown [#2488](https://github.com/jupyter-book/jupyter-book/pull/2488) ([@bsipocz](https://github.com/bsipocz))
- MAINT: adding cooldown for dependabot [#2470](https://github.com/jupyter-book/jupyter-book/pull/2470) ([@bsipocz](https://github.com/bsipocz))
- MAINT: dependabot PRs should auto pass label linting CI [#2466](https://github.com/jupyter-book/jupyter-book/pull/2466) ([@bsipocz](https://github.com/bsipocz))

### Documentation improvements

- 📖 adding fornax documentation to the gallery [#2510](https://github.com/jupyter-book/jupyter-book/pull/2510) ([@bsipocz](https://github.com/bsipocz))
- 📖 Adding NASA-Fornax demo notebooks to the gallery [#2509](https://github.com/jupyter-book/jupyter-book/pull/2509) ([@bsipocz](https://github.com/bsipocz))
- 📖 adding numpy tutorials to the gallery [#2507](https://github.com/jupyter-book/jupyter-book/pull/2507) ([@bsipocz](https://github.com/bsipocz))
- Fix formatting in init.md for clarity [#2501](https://github.com/jupyter-book/jupyter-book/pull/2501) ([@FreekPols](https://github.com/FreekPols))
- DOC: there are more emojis in the calculation [#2499](https://github.com/jupyter-book/jupyter-book/pull/2499) ([@bsipocz](https://github.com/bsipocz))
- docs: fix conda-forge warning [#2497](https://github.com/jupyter-book/jupyter-book/pull/2497) ([@agoose77](https://github.com/agoose77))
- 📖 Remove references "Jupyter Book 2" [#2496](https://github.com/jupyter-book/jupyter-book/pull/2496) ([@JimMadge](https://github.com/JimMadge))
- Remove warning about conda-forge [#2492](https://github.com/jupyter-book/jupyter-book/pull/2492) ([@rgaiacs](https://github.com/rgaiacs))
- Add a table for our team priorities roadmap and use the github-issue-tables plugin [#2490](https://github.com/jupyter-book/jupyter-book/pull/2490) ([@choldgraf](https://github.com/choldgraf))
- Add pointer in README to v1 source [#2471](https://github.com/jupyter-book/jupyter-book/pull/2471) ([@stefanv](https://github.com/stefanv))
- Gallery of Jupyter Books (with the myst stack) [#2461](https://github.com/jupyter-book/jupyter-book/pull/2461) ([@FreekPols](https://github.com/FreekPols))
- Fix link to v1 docs [#2457](https://github.com/jupyter-book/jupyter-book/pull/2457) ([@matthew-brett](https://github.com/matthew-brett))
- Fix typo in project frontmatter description [#2451](https://github.com/jupyter-book/jupyter-book/pull/2451) ([@surodeep26](https://github.com/surodeep26))
- Update installation instructions for Jupyter Book [#2449](https://github.com/jupyter-book/jupyter-book/pull/2449) ([@FreekPols](https://github.com/FreekPols))
- Add small comment to nav [#2447](https://github.com/jupyter-book/jupyter-book/pull/2447) ([@choldgraf](https://github.com/choldgraf))

### Other merged PRs

- Update dependencies to pull in MyST [#2513](https://github.com/jupyter-book/jupyter-book/pull/2513) ([@agoose77](https://github.com/agoose77))
- Add gallery entry for Topology in Condensed Matter course [#2482](https://github.com/jupyter-book/jupyter-book/pull/2482) ([@akhmerov](https://github.com/akhmerov))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2025-11-03&to=2025-12-05&type=c))

[@agoose77](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2025-11-03..2025-12-05&type=Issues) | [@akhmerov](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aakhmerov+updated%3A2025-11-03..2025-12-05&type=Issues) | [@bsipocz](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Absipocz+updated%3A2025-11-03..2025-12-05&type=Issues) | [@choldgraf](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Acholdgraf+updated%3A2025-11-03..2025-12-05&type=Issues) | [@FreekPols](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3AFreekPols+updated%3A2025-11-03..2025-12-05&type=Issues) | [@JimMadge](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3AJimMadge+updated%3A2025-11-03..2025-12-05&type=Issues) | [@matthew-brett](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Amatthew-brett+updated%3A2025-11-03..2025-12-05&type=Issues) | [@rgaiacs](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Argaiacs+updated%3A2025-11-03..2025-12-05&type=Issues) | [@rowanc1](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Arowanc1+updated%3A2025-11-03..2025-12-05&type=Issues) | [@stefanv](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Astefanv+updated%3A2025-11-03..2025-12-05&type=Issues) | [@surodeep26](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Asurodeep26+updated%3A2025-11-03..2025-12-05&type=Issues)

## 2.0.2

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/b1a14ef6e617997685419d89fff09c7b955135ff...6e81c24f7001edfe3a12d8267813c127b02fd347))

### Bugs fixed

- fix: bump cli [#2448](https://github.com/jupyter-book/jupyter-book/pull/2448) ([@agoose77](https://github.com/agoose77))

### Maintenance and upkeep improvements

- 🤖 Use grouping in dependabot [#2440](https://github.com/jupyter-book/jupyter-book/pull/2440) ([@agoose77](https://github.com/agoose77))

### Documentation improvements

- Update DOI badge and governance section in README [#2445](https://github.com/jupyter-book/jupyter-book/pull/2445) ([@rowanc1](https://github.com/rowanc1))

### Other merged PRs

- Fix broken link to jupyterbook 1 documentation [#2441](https://github.com/jupyter-book/jupyter-book/pull/2441) ([@Tom-van-Woudenberg](https://github.com/Tom-van-Woudenberg))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2025-11-03&to=2025-11-03&type=c))

[@agoose77](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2025-11-03..2025-11-03&type=Issues) | [@rowanc1](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Arowanc1+updated%3A2025-11-03..2025-11-03&type=Issues) | [@Tom-van-Woudenberg](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3ATom-van-Woudenberg+updated%3A2025-11-03..2025-11-03&type=Issues)

## 2.0.1

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/v2.0.0...6e81c24f7001edfe3a12d8267813c127b02fd347))

### Bugs fixed

- fix: bump cli [#2448](https://github.com/jupyter-book/jupyter-book/pull/2448) ([@agoose77](https://github.com/agoose77))

### Maintenance and upkeep improvements

- 🤖 Use grouping in dependabot [#2440](https://github.com/jupyter-book/jupyter-book/pull/2440) ([@agoose77](https://github.com/agoose77))

### Documentation improvements

- Update DOI badge and governance section in README [#2445](https://github.com/jupyter-book/jupyter-book/pull/2445) ([@rowanc1](https://github.com/rowanc1))

### Other merged PRs

- Fix broken link to jupyterbook 1 documentation [#2441](https://github.com/jupyter-book/jupyter-book/pull/2441) ([@Tom-van-Woudenberg](https://github.com/Tom-van-Woudenberg))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2025-11-03&to=2025-11-03&type=c))

[@agoose77](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2025-11-03..2025-11-03&type=Issues) | [@rowanc1](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Arowanc1+updated%3A2025-11-03..2025-11-03&type=Issues) | [@Tom-van-Woudenberg](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3ATom-van-Woudenberg+updated%3A2025-11-03..2025-11-03&type=Issues)

## 2.0.0

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/28e190a2757fcc6be3719d24d79e7d990ae79fcc...bdcfdd486cf83f344b909f9b3806cd8f63475dfb))

### New features added

- FEAT: ✨Add Launch in Deepnote button setting [#1434](https://github.com/jupyter-book/jupyter-book/pull/1434) ([@jakubzitny](https://github.com/jakubzitny))

### Enhancements made

- chore: bump MyST version [#2432](https://github.com/jupyter-book/jupyter-book/pull/2432) ([@agoose77](https://github.com/agoose77))

### Bugs fixed

- FIX: use 'main' for branch name [#2329](https://github.com/jupyter-book/jupyter-book/pull/2329) ([@agoose77](https://github.com/agoose77))
- FIX: bring tests in line with config [#2216](https://github.com/jupyter-book/jupyter-book/pull/2216) ([@agoose77](https://github.com/agoose77))

### Maintenance and upkeep improvements

- Enable execution for ReadTheDocs [#2436](https://github.com/jupyter-book/jupyter-book/pull/2436) ([@choldgraf](https://github.com/choldgraf))
- Add small comment to nav [#2435](https://github.com/jupyter-book/jupyter-book/pull/2435) ([@choldgraf](https://github.com/choldgraf))
- chore: bump MyST version [#2432](https://github.com/jupyter-book/jupyter-book/pull/2432) ([@agoose77](https://github.com/agoose77))
- Remove hard-coded URLs in navbar [#2431](https://github.com/jupyter-book/jupyter-book/pull/2431) ([@choldgraf](https://github.com/choldgraf))
- Update docs/ to stable/ [#2430](https://github.com/jupyter-book/jupyter-book/pull/2430) ([@choldgraf](https://github.com/choldgraf))
- Fix BASE_URL for new URL on RTD [#2429](https://github.com/jupyter-book/jupyter-book/pull/2429) ([@choldgraf](https://github.com/choldgraf))
- Updated pyproject.toml [#2406](https://github.com/jupyter-book/jupyter-book/pull/2406) ([@dsblank](https://github.com/dsblank))
- Fix macOS spelling in issue template [#2359](https://github.com/jupyter-book/jupyter-book/pull/2359) ([@dstansby](https://github.com/dstansby))
- DOCS: fix RTD configuration [#2330](https://github.com/jupyter-book/jupyter-book/pull/2330) ([@agoose77](https://github.com/agoose77))
- FIX: use 'main' for branch name [#2329](https://github.com/jupyter-book/jupyter-book/pull/2329) ([@agoose77](https://github.com/agoose77))
- MAINT: prepare for new release [#2327](https://github.com/jupyter-book/jupyter-book/pull/2327) ([@agoose77](https://github.com/agoose77))
- Update actions version in docs [#2318](https://github.com/jupyter-book/jupyter-book/pull/2318) ([@fmaussion](https://github.com/fmaussion))
- MAINT: add description back to bug report template [#2293](https://github.com/jupyter-book/jupyter-book/pull/2293) ([@choldgraf](https://github.com/choldgraf))
- MAINT: update new issues template to point to discussions forum [#2292](https://github.com/jupyter-book/jupyter-book/pull/2292) ([@choldgraf](https://github.com/choldgraf))
- MAINT: update banner to use github issue [#2282](https://github.com/jupyter-book/jupyter-book/pull/2282) ([@choldgraf](https://github.com/choldgraf))
- MAINT: add discussion of Jupyter Book 2, along with directions to documentation for 2.x. [#2280](https://github.com/jupyter-book/jupyter-book/pull/2280) ([@nickeubank](https://github.com/nickeubank))
- MAINT: rename branch from 'master' to 'main' in \_config.yaml [#2275](https://github.com/jupyter-book/jupyter-book/pull/2275) ([@jroettenbacher](https://github.com/jroettenbacher))
- MAINT: add issue templates [#2263](https://github.com/jupyter-book/jupyter-book/pull/2263) ([@agoose77](https://github.com/agoose77))
- MAINT: 🤖 Backport #2257 (Add Jupyter releaser) [#2259](https://github.com/jupyter-book/jupyter-book/pull/2259) ([@agoose77](https://github.com/agoose77))
- MAINT: fix expression [#2231](https://github.com/jupyter-book/jupyter-book/pull/2231) ([@agoose77](https://github.com/agoose77))
- MAINT: update changelog [#2230](https://github.com/jupyter-book/jupyter-book/pull/2230) ([@agoose77](https://github.com/agoose77))
- MAINT: bump version [#2229](https://github.com/jupyter-book/jupyter-book/pull/2229) ([@agoose77](https://github.com/agoose77))
- MAINT: only use v1 job for v1 releases [#2225](https://github.com/jupyter-book/jupyter-book/pull/2225) ([@agoose77](https://github.com/agoose77))
- MAINT: update entry-points usage [#2121](https://github.com/jupyter-book/jupyter-book/pull/2121) ([@agoose77](https://github.com/agoose77))
- MAINT: bump sphinx-thebe LB [#2116](https://github.com/jupyter-book/jupyter-book/pull/2116) ([@agoose77](https://github.com/agoose77))

### Documentation improvements

- Site url fix [#2434](https://github.com/jupyter-book/jupyter-book/pull/2434) ([@choldgraf](https://github.com/choldgraf))
- Fixing nav links for the Nth time [#2433](https://github.com/jupyter-book/jupyter-book/pull/2433) ([@choldgraf](https://github.com/choldgraf))
- Add jupytercon banner [#2407](https://github.com/jupyter-book/jupyter-book/pull/2407) ([@choldgraf](https://github.com/choldgraf))
- Update README.md [#2368](https://github.com/jupyter-book/jupyter-book/pull/2368) ([@agoose77](https://github.com/agoose77))
- Formatting for thebe config [#2352](https://github.com/jupyter-book/jupyter-book/pull/2352) ([@RemDelaporteMathurin](https://github.com/RemDelaporteMathurin))
- DOC: minor fixes [#2348](https://github.com/jupyter-book/jupyter-book/pull/2348) ([@bsipocz](https://github.com/bsipocz))
- fix broken URL to blog/update [#2343](https://github.com/jupyter-book/jupyter-book/pull/2343) ([@rlanzafame](https://github.com/rlanzafame))
- DOCS: update gh-pages guidance [#2332](https://github.com/jupyter-book/jupyter-book/pull/2332) ([@agoose77](https://github.com/agoose77))
- DOCS: fix RTD configuration [#2330](https://github.com/jupyter-book/jupyter-book/pull/2330) ([@agoose77](https://github.com/agoose77))
- DOCS: update Turing way URL [#2236](https://github.com/jupyter-book/jupyter-book/pull/2236) ([@da5nsy](https://github.com/da5nsy))
- DOCS: fall-back to `fontawesome` in LaTeX (and format \_config) [#2228](https://github.com/jupyter-book/jupyter-book/pull/2228) ([@agoose77](https://github.com/agoose77))
- DOCS: add structured data example [#2129](https://github.com/jupyter-book/jupyter-book/pull/2129) ([@jmshea](https://github.com/jmshea))
- DOCS: update citations document [#2108](https://github.com/jupyter-book/jupyter-book/pull/2108) ([@drsimonmartin](https://github.com/drsimonmartin))

### Other merged PRs

- Clarify GitHub Pages instructions [#2421](https://github.com/jupyter-book/jupyter-book/pull/2421) ([@afeld](https://github.com/afeld))
- add a sample GitHub Actions config using Conda [#2415](https://github.com/jupyter-book/jupyter-book/pull/2415) ([@afeld](https://github.com/afeld))
- update GitHub Actions example to use latest versions [#2414](https://github.com/jupyter-book/jupyter-book/pull/2414) ([@afeld](https://github.com/afeld))
- Update The Turing Way logo path [#2385](https://github.com/jupyter-book/jupyter-book/pull/2385) ([@JimMadge](https://github.com/JimMadge))
- include the path of the generated config.py file [#2302](https://github.com/jupyter-book/jupyter-book/pull/2302) ([@afeld](https://github.com/afeld))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2024-03-19&to=2025-11-03&type=c))

[@afeld](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aafeld+updated%3A2024-03-19..2025-11-03&type=Issues) | [@agoose77](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2024-03-19..2025-11-03&type=Issues) | [@bsipocz](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Absipocz+updated%3A2024-03-19..2025-11-03&type=Issues) | [@choldgraf](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Acholdgraf+updated%3A2024-03-19..2025-11-03&type=Issues) | [@codecov](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Acodecov+updated%3A2024-03-19..2025-11-03&type=Issues) | [@da5nsy](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Ada5nsy+updated%3A2024-03-19..2025-11-03&type=Issues) | [@drsimonmartin](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Adrsimonmartin+updated%3A2024-03-19..2025-11-03&type=Issues) | [@dsblank](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Adsblank+updated%3A2024-03-19..2025-11-03&type=Issues) | [@dstansby](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Adstansby+updated%3A2024-03-19..2025-11-03&type=Issues) | [@fmaussion](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Afmaussion+updated%3A2024-03-19..2025-11-03&type=Issues) | [@jakubzitny](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Ajakubzitny+updated%3A2024-03-19..2025-11-03&type=Issues) | [@JimMadge](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3AJimMadge+updated%3A2024-03-19..2025-11-03&type=Issues) | [@jmshea](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Ajmshea+updated%3A2024-03-19..2025-11-03&type=Issues) | [@jroettenbacher](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Ajroettenbacher+updated%3A2024-03-19..2025-11-03&type=Issues) | [@LoicGrobol](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3ALoicGrobol+updated%3A2024-03-19..2025-11-03&type=Issues) | [@nickeubank](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Anickeubank+updated%3A2024-03-19..2025-11-03&type=Issues) | [@psychemedia](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Apsychemedia+updated%3A2024-03-19..2025-11-03&type=Issues) | [@RemDelaporteMathurin](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3ARemDelaporteMathurin+updated%3A2024-03-19..2025-11-03&type=Issues) | [@rlanzafame](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Arlanzafame+updated%3A2024-03-19..2025-11-03&type=Issues) | [@rowanc1](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Arowanc1+updated%3A2024-03-19..2025-11-03&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Awelcome+updated%3A2024-03-19..2025-11-03&type=Issues)

## 2.0.0b3

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/v2.0.0b2...24422c41eb92839a7fd07dca6d5d87ce281c210f))

### Bugs fixed

- ✳️ Bump `NODEENV_VERSION` [#2401](https://github.com/jupyter-book/jupyter-book/pull/2401) ([@alanmlewis](https://github.com/alanmlewis))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2025-07-21&to=2025-08-20&type=c))

[@agoose77](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2025-07-21..2025-08-20&type=Issues) | [@alanmlewis](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aalanmlewis+updated%3A2025-07-21..2025-08-20&type=Issues)

## 2.0.0b2

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/v2.0.0b1...0522b33ff29772ed4b8ed11656869a0fa22500fd))

### Enhancements made

- 🔼 Bump `myst-cli` to 1.6.0 for release [#2393](https://github.com/jupyter-book/jupyter-book/pull/2393) ([@agoose77](https://github.com/agoose77))

### Bugs fixed

- 🏷️ Set new NPM\_ binary name variable [#2391](https://github.com/jupyter-book/jupyter-book/pull/2391) ([@agoose77](https://github.com/agoose77))

### Documentation improvements

- ✨ Use wildcard to define install version in docs [#2390](https://github.com/jupyter-book/jupyter-book/pull/2390) ([@agoose77](https://github.com/agoose77))
- ✍️ Fix install command [#2389](https://github.com/jupyter-book/jupyter-book/pull/2389) ([@agoose77](https://github.com/agoose77))

### Other merged PRs

- ✍️ Update community.md [#2386](https://github.com/jupyter-book/jupyter-book/pull/2386) ([@partev](https://github.com/partev))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2025-07-11&to=2025-07-21&type=c))

[@agoose77](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2025-07-11..2025-07-21&type=Issues) | [@choldgraf](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Acholdgraf+updated%3A2025-07-11..2025-07-21&type=Issues) | [@partev](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Apartev+updated%3A2025-07-11..2025-07-21&type=Issues)

## 2.0.0b1

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/v2.0.0b0...db9e4b2b0061bb7db2685f492071979e70c22da0))

### Maintenance and upkeep improvements

- Update site assets to use Jupyter Book rather than meta [#2381](https://github.com/jupyter-book/jupyter-book/pull/2381) ([@choldgraf](https://github.com/choldgraf))
- 🗑️ Delete DS_STORE [#2380](https://github.com/jupyter-book/jupyter-book/pull/2380) ([@agoose77](https://github.com/agoose77))

### Documentation improvements

- Make the logo point to jupyterbook.org/stable [#2382](https://github.com/jupyter-book/jupyter-book/pull/2382) ([@choldgraf](https://github.com/choldgraf))
- ↔️ Correct myst.yml ToC entry. [#2379](https://github.com/jupyter-book/jupyter-book/pull/2379) ([@agoose77](https://github.com/agoose77))
- 🚧 Fix broken site links [#2378](https://github.com/jupyter-book/jupyter-book/pull/2378) ([@agoose77](https://github.com/agoose77))
- Update some documentation before 2.0 [#2374](https://github.com/jupyter-book/jupyter-book/pull/2374) ([@choldgraf](https://github.com/choldgraf))

### Other merged PRs

- 🛠️ Bump Node version [#2383](https://github.com/jupyter-book/jupyter-book/pull/2383) ([@agoose77](https://github.com/agoose77))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2025-07-06&to=2025-07-11&type=c))

[@agoose77](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2025-07-06..2025-07-11&type=Issues) | [@choldgraf](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Acholdgraf+updated%3A2025-07-06..2025-07-11&type=Issues)

## 2.0.0b0

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/v2.0.0a3...a8b87f963089532cec368293fb8cdf6832a4fa77))

### Enhancements made

- 🐫 Bump MyST CLI version [#2376](https://github.com/jupyter-book/jupyter-book/pull/2376) ([@agoose77](https://github.com/agoose77))
- 🎬 Improve whitelabelling for `jupyter book init` [#2372](https://github.com/jupyter-book/jupyter-book/pull/2372) ([@agoose77](https://github.com/agoose77))

### Documentation improvements

- 🧹 Cleanups of casing, etc. in documentation [#2373](https://github.com/jupyter-book/jupyter-book/pull/2373) ([@agoose77](https://github.com/agoose77))
- 🛠️ Fix install instructions for JB2 [#2370](https://github.com/jupyter-book/jupyter-book/pull/2370) ([@agoose77](https://github.com/agoose77))
- DOCS: Add missing backticks in code block [#2367](https://github.com/jupyter-book/jupyter-book/pull/2367) ([@aknierim](https://github.com/aknierim))
- Fix links on docs `Get Started` page [#2366](https://github.com/jupyter-book/jupyter-book/pull/2366) ([@StFroese](https://github.com/StFroese))
- Add extra links to the upgrading docs page [#2301](https://github.com/jupyter-book/jupyter-book/pull/2301) ([@bryanwweber](https://github.com/bryanwweber))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2025-03-25&to=2025-07-06&type=c))

[@agoose77](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2025-03-25..2025-07-06&type=Issues) | [@aknierim](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aaknierim+updated%3A2025-03-25..2025-07-06&type=Issues) | [@bryanwweber](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Abryanwweber+updated%3A2025-03-25..2025-07-06&type=Issues) | [@StFroese](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3AStFroese+updated%3A2025-03-25..2025-07-06&type=Issues)

## 2.0.0a3

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/v2.0.0a2...a363d687aeca09cb97c8cd2433cd5182590cec49))

### Enhancements made

- 🔼 Bump `myst-cli` version for release [#2342](https://github.com/jupyter-book/jupyter-book/pull/2342) ([@agoose77](https://github.com/agoose77))
- 🔼 Bump myst-cli version [#2335](https://github.com/jupyter-book/jupyter-book/pull/2335) ([@JimMadge](https://github.com/JimMadge))

### Documentation improvements

- ✏️ Add note about pre-release availability [#2336](https://github.com/jupyter-book/jupyter-book/pull/2336) ([@agoose77](https://github.com/agoose77))
- 📝 Drop reference to execution workaround, as it does not work [#2326](https://github.com/jupyter-book/jupyter-book/pull/2326) ([@agoose77](https://github.com/agoose77))
- 🕰️ Fix deploy action versions [#2325](https://github.com/jupyter-book/jupyter-book/pull/2325) ([@agoose77](https://github.com/agoose77))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2025-02-20&to=2025-03-25&type=c))

[@agoose77](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2025-02-20..2025-03-25&type=Issues) | [@JimMadge](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3AJimMadge+updated%3A2025-02-20..2025-03-25&type=Issues)

## 2.0.0a2

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/v2.0.0a1...a51e4dc35766b7d4b4d5d47d4258b7a248fa3c3d))

### Enhancements made

- ⬆️ Bump `myst-cli` version [#2324](https://github.com/jupyter-book/jupyter-book/pull/2324) ([@agoose77](https://github.com/agoose77))

### Bugs fixed

- 🏷️ Set whitelabelling on NPM package rather than Python [#2313](https://github.com/jupyter-book/jupyter-book/pull/2313) ([@agoose77](https://github.com/agoose77))

### Maintenance and upkeep improvements

- cd within same command as build for RTD [#2299](https://github.com/jupyter-book/jupyter-book/pull/2299) ([@choldgraf](https://github.com/choldgraf))
- Convert readthedocs pushd to cd [#2298](https://github.com/jupyter-book/jupyter-book/pull/2298) ([@choldgraf](https://github.com/choldgraf))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2025-01-14&to=2025-02-20&type=c))

[@agoose77](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2025-01-14..2025-02-20&type=Issues) | [@choldgraf](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Acholdgraf+updated%3A2025-01-14..2025-02-20&type=Issues)

## 2.0.0a1

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/v2.0.0a0...5b2af435b1720298c1b411d510064167d0e662a0))

### Bugs fixed

- 🪢 Loosen PyPI dependencies for nodeenv etc. [#2295](https://github.com/jupyter-book/jupyter-book/pull/2295) ([@agoose77](https://github.com/agoose77))

### Maintenance and upkeep improvements

- 🤜 Bump version to 2.0.0a1 [#2297](https://github.com/jupyter-book/jupyter-book/pull/2297) ([@agoose77](https://github.com/agoose77))

### Documentation improvements

- 🔰 Add badge to docs [#2286](https://github.com/jupyter-book/jupyter-book/pull/2286) ([@agoose77](https://github.com/agoose77))
- 🖼️ Fix path to images in README [#2285](https://github.com/jupyter-book/jupyter-book/pull/2285) ([@agoose77](https://github.com/agoose77))
- 🐝 Fix reference to `ctx` for role plugins [#2270](https://github.com/jupyter-book/jupyter-book/pull/2270) ([@agoose77](https://github.com/agoose77))
- ✏️ Add authoring and admonition instructions [#2269](https://github.com/jupyter-book/jupyter-book/pull/2269) ([@choldgraf](https://github.com/choldgraf))
- 🔌 Add how-to for plugin dependencies [#2266](https://github.com/jupyter-book/jupyter-book/pull/2266) ([@choldgraf](https://github.com/choldgraf))
- 🔌 Add a plugin tutorial [#2264](https://github.com/jupyter-book/jupyter-book/pull/2264) ([@choldgraf](https://github.com/choldgraf))
- 📕 Show how you can programmatically include content [#2256](https://github.com/jupyter-book/jupyter-book/pull/2256) ([@choldgraf](https://github.com/choldgraf))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2024-11-15&to=2025-01-14&type=c))

[@agoose77](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2024-11-15..2025-01-14&type=Issues) | [@choldgraf](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Acholdgraf+updated%3A2024-11-15..2025-01-14&type=Issues)

## 2.0.0a0

([Full Changelog](https://github.com/jupyter-book/jupyter-book/compare/2.0-first-commit...62d51da689ee657020ba6048fbb14ecef283e51b))

### Enhancements made

- ✏️ Hardcode binary name [#2253](https://github.com/jupyter-book/jupyter-book/pull/2253) ([@agoose77](https://github.com/agoose77))
- 🪐 Make jupyter a dependency [#2245](https://github.com/jupyter-book/jupyter-book/pull/2245) ([@agoose77](https://github.com/agoose77))
- ⚙️ Add support for `nodeenv`, and build JS CLI [#2219](https://github.com/jupyter-book/jupyter-book/pull/2219) ([@agoose77](https://github.com/agoose77))

### Bugs fixed

- 🐜 Fix reference to deleted directives [#2251](https://github.com/jupyter-book/jupyter-book/pull/2251) ([@agoose77](https://github.com/agoose77))

### Maintenance and upkeep improvements

- 📝 Add simple CI testing of CLI version [#2262](https://github.com/jupyter-book/jupyter-book/pull/2262) ([@agoose77](https://github.com/agoose77))
- 📦 Install before clean during release [#2261](https://github.com/jupyter-book/jupyter-book/pull/2261) ([@agoose77](https://github.com/agoose77))
- 🛠️ Set up Node.js version handling [#2260](https://github.com/jupyter-book/jupyter-book/pull/2260) ([@agoose77](https://github.com/agoose77))
- :rock: Bump version to 2.0.0a0 [#2258](https://github.com/jupyter-book/jupyter-book/pull/2258) ([@agoose77](https://github.com/agoose77))
- 🤖 Add jupyter releaser [#2257](https://github.com/jupyter-book/jupyter-book/pull/2257) ([@agoose77](https://github.com/agoose77))
- 🖇️ Use shared config in docs [#2243](https://github.com/jupyter-book/jupyter-book/pull/2243) ([@agoose77](https://github.com/agoose77))
- ❄️ Add Nix devshell flake [#2221](https://github.com/jupyter-book/jupyter-book/pull/2221) ([@agoose77](https://github.com/agoose77))

### Documentation improvements

- ✏️ Remove references to executablebooks [#2255](https://github.com/jupyter-book/jupyter-book/pull/2255) ([@choldgraf](https://github.com/choldgraf))
- 🌍 Add documentation about plugin origin [#2252](https://github.com/jupyter-book/jupyter-book/pull/2252) ([@agoose77](https://github.com/agoose77))
- ✨ Iterate on `next` docs [#2250](https://github.com/jupyter-book/jupyter-book/pull/2250) ([@agoose77](https://github.com/agoose77))
- ❔ Add tutorials to Jupyter Book 2.0 docs [#2249](https://github.com/jupyter-book/jupyter-book/pull/2249) ([@choldgraf](https://github.com/choldgraf))
- 💼 More docs improvements [#2248](https://github.com/jupyter-book/jupyter-book/pull/2248) ([@agoose77](https://github.com/agoose77))
- 📙 Next documentation improvements [#2244](https://github.com/jupyter-book/jupyter-book/pull/2244) ([@agoose77](https://github.com/agoose77))
- 🖇️ Use shared config in docs [#2243](https://github.com/jupyter-book/jupyter-book/pull/2243) ([@agoose77](https://github.com/agoose77))
- 🔗 Fix GitHub URL [#2241](https://github.com/jupyter-book/jupyter-book/pull/2241) ([@agoose77](https://github.com/agoose77))
- 🖇️ Use shared config for myst.yml [#2240](https://github.com/jupyter-book/jupyter-book/pull/2240) ([@agoose77](https://github.com/agoose77))
- 📔 Add note about 2.0 to README [#2224](https://github.com/jupyter-book/jupyter-book/pull/2224) ([@agoose77](https://github.com/agoose77))
- ⚙️ Drop `BASE_URL` in GitHub Pages [#2223](https://github.com/jupyter-book/jupyter-book/pull/2223) ([@agoose77](https://github.com/agoose77))
- 📔 Simplify readme [#2222](https://github.com/jupyter-book/jupyter-book/pull/2222) ([@agoose77](https://github.com/agoose77))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-book/jupyter-book/graphs/contributors?from=2024-03-19&to=2024-11-15&type=c))

[@agoose77](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Aagoose77+updated%3A2024-03-19..2024-11-15&type=Issues) | [@choldgraf](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Acholdgraf+updated%3A2024-03-19..2024-11-15&type=Issues) | [@codecov](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Acodecov+updated%3A2024-03-19..2024-11-15&type=Issues) | [@jmshea](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Ajmshea+updated%3A2024-03-19..2024-11-15&type=Issues) | [@LoicGrobol](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3ALoicGrobol+updated%3A2024-03-19..2024-11-15&type=Issues) | [@psychemedia](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Apsychemedia+updated%3A2024-03-19..2024-11-15&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyter-book%2Fjupyter-book+involves%3Awelcome+updated%3A2024-03-19..2024-11-15&type=Issues)
