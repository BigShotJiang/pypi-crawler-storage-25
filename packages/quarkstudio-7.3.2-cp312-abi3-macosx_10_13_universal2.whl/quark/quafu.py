# Copyright (c) 2024 YL Feng <fengyulong@pku.org.cn>

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files(the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and / or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


import json
import os
import time
from typing import Literal

import requests

__author__ = "YL Feng"
__email__ = "fengyl@baqis.ac.cn | fengyulong@pku.org.cn"


class Task(object):

    """This guide provides the essential steps to get started with QuarkStudio for accessing the Quafu Superconducting Quantum Computing Cloud.

    ---
    ## 🚀 Getting Started

    ### 1.Installation
    Ensure you have **Python 3.12 or higher** installed. Then, install the package using pip:
    ```
    pip install -U quarkstudio
    ```

    ### 2. Authentication
    You need a personal **token** to access the platform.
    1.  **Get a Token**: **[SQCLab website](https://quafu-sqc.baqis.ac.cn/)**. Keep your token secure and do not share it, as it expires after **30 days**.
    2.  **Initialize**:
        ```python
        from quark import Task
        tmgr = Task('your_token_here')
        ```

    ---
    ## ⚙️ Core Workflow

    ### 1. Check Backend Status
    Before submitting, check the queue status of available quantum processors (backends):
    ```python
    print(tmgr.status())
    ```
    Output example:
    ```python
    {'Dongling': 0,      # No tasks queued
    'Baihua': 10,     # 10 tasks queued
    'Miaofeng': 'Offline' # Backend unavailable
    }
    ```

    ### 2. Submit a Quantum Task
    Define your task as a dictionary. Your quantum circuit must be written in **OpenQASM 2.0**.
    ```python
    task = {
    'chip': 'Dongling',  # chip name
    'name': 'MyJob',  # task name
    'circuit': circuit, # circuit written in OpenQASM2.0
    'shots': 1024, # an integer multiple of 1024
    'options':{
        'compiler': None|'quarkcircuit'|'qsteed'|'qiskit', # defaults to 'quarkcircuit'
        'correct': False, # readout error correction 
        'open_dd': None|'XY4'|'CPMG', # dynamial decoupling,  # defaults to None
        'target_qubits': [] # [0, 1]
    }
    }
    ```
    Submit the task asynchronously. You will receive a Task ID (`tid`) immediately.
    ```python
    tid = tmgr.run(task)
    print(tid)  # e.g., 2024041917095371986
    ```
    **Note**: Users can submit up to **1000 tasks per day**. Excess tasks will be queued for the next day.

    ### 3. Retrieve Results
    Use the `tid` to get your results. The result is a dictionary containing the measurement counts and task metadata.
    ```python
    result = tmgr.result(tid)
    print(result['count'])  # Dictionary of measurement results
    print(result['status']) # e.g., 'Finished'
    ```
    """

    URL = 'https://quafu-sqc.baqis.ac.cn'

    session = requests.Session()

    def __new__(cls, *args, **kwds):
        if not hasattr(cls, 'instance'):
            cls.instance = super().__new__(cls)
        return cls.instance

    def __init__(self, token: str = '') -> None:
        self.token = os.getenv('QPU_API_TOKEN', token)
        assert self.token, f'token is required, get it from SQCLab[{self.URL}]!'

        v = self.verify()
        if isinstance(v, dict):
            raise Exception(f'{v}')

        self.tasks = {}
        self.cache = {}

    def request(self, url: str, data: dict = {}, method: str = 'get'):
        if method == 'get':
            res = self.session.get(url, headers={'token': self.token})
        elif method == 'post':
            res = self.session.post(url,
                                    data=json.dumps(data),
                                    headers={'token': self.token})
        return json.loads(res.content.decode())

    def verify(self):
        return self.request(f'{self.URL}/task/verify')

    def query(self, tid: int = 2, chips: str = 'Baihua', status: str = 'Finished,Failed',
              start: str = '2024-04-01-01-23-45', end: str = time.strftime('%Y-%m-%d-%H-%M-%S'),
              offset: int = 0, limit: int = 10,
              sort: Literal['taskId', 'taskName', 'chipName',
                            'status', 'submitTime'] = 'submitTime',
              order: Literal['asc', 'desc'] = 'desc'):
        return self.request(f'{self.URL}/task/query/?tid={tid}&chips={chips}&status={status}&start={start}&end={end}&offset={offset}&limit={limit}&sort={sort}&order={order}')

    def delete(self, tid: int):
        return self.request(f'{self.URL}/task/delete/{tid}')

    def result(self, tid: int, timeout: float = 0.0):
        if timeout:
            st = time.time()
            while True:
                res = self.request(f'{self.URL}/task/result/{tid}')
                if isinstance(res, dict) and res:
                    return res
                if time.time() - st > timeout:
                    raise TimeoutError(
                        f'Task {tid} result timeout after {timeout} seconds')
                time.sleep(0.2)
        else:
            time.sleep(0.2)
        return self.request(f'{self.URL}/task/result/{tid}')

    def status(self, tid: int = 0):
        time.sleep(0.2)
        return self.request(f'{self.URL}/task/status/{tid}')

    def cancel(self, tid: int):
        time.sleep(0.2)
        return self.request(f'{self.URL}/task/cancel/{tid}')

    def run(self, task: dict, repeat: int = 1):
        """run a task

        Args:
            task (dict): task description.

        Returns:
            int: task id
        """
        time.sleep(0.2)
        name = task.get('name', 'MyQuantumJob')
        chip = task['chip']
        shots = task.get('shots', repeat * 1024)
        circuit = str(task['circuit'])
        tid = self.request(f'{self.URL}/task/run/?name={name}&chip={chip}&shots={shots}',
                           data={'circuit': circuit,
                                 'compile': task.get('compile', True),
                                 'options': task.get('options', {
                                     'clientip': os.getenv('CLIENT_REAL_IP', '')
                                 })},
                           method='post')
        if isinstance(tid, int):
            self.tasks[tid] = task
        return tid

    def backend(self, chip: str, show_couplers_fidelity: bool = False, show_quibts_attributes: Literal['T1', 'T2', 'fidelity', 'frequancy', ''] = '', highlight_nodes: list = [], save_svg_fname: str | None = None):
        try:
            from quark.circuit import Backend
            bk = Backend(chip)
            bk.draw(show_couplers_fidelity,
                    show_quibts_attributes,
                    highlight_nodes,
                    save_svg_fname)
            return bk.chip_info
        except Exception as e:
            print(f'{e}, install it using "pip install quarkcircuit"')
