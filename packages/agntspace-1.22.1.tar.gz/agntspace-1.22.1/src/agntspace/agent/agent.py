"""Main agent: ties vault identity, LLM reasoning, and conversation memory together."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import re
import time
from collections.abc import AsyncIterator
from pathlib import Path
from typing import TYPE_CHECKING

from agntspace.llm.base import LLMProvider, StreamChunk
from agntspace.llm.prompt import build_system_prompt
from agntspace.memory.conversation import ConversationMemory
from agntspace.vault.reader import VaultReader

if TYPE_CHECKING:
    from agntspace.agent.registry import ToolRegistry
    from agntspace.agent.tools import ToolExecutor
    from agntspace.automation.heartbeat import Heartbeat
    from agntspace.journal.service import JournalService
    from agntspace.memory.engine import MemoryEngine
    from agntspace.projects.service import ProjectService
    from agntspace.skills.loader import SkillLoader
    from agntspace.tasks.service import TaskService
    from agntspace.trust.service import TrustService

log = logging.getLogger(__name__)


_NO_RESPONSE_PLACEHOLDER = "⚠ The model returned no response. Please try again."


def _is_junk_assistant_text(text: str | None) -> bool:
    """True when an LLM 'final answer' is empty, whitespace, or a bare tool-call JSON blob.

    Small local models and occasionally cloud models can emit ``{}``, ``[]``,
    ``null``, or a literal tool-call JSON (``{"name": ..., "arguments": ...}``)
    as the assistant message. Saving any of those pollutes history and makes the
    conversation look empty in the sidebar.
    """
    if not text:
        return True
    s = text.strip()
    if not s:
        return True
    if s in ("{}", "[]", "null"):
        return True
    # Bare tool-call JSON shape from local models
    if s.startswith("{") and s.endswith("}"):
        import json as _json

        try:
            obj = _json.loads(s)
        except Exception:
            return False
        if isinstance(obj, dict):
            # Empty dict or single-key tool-call wrapper
            if not obj:
                return True
            keys = set(obj.keys())
            if keys <= {"name", "arguments", "input", "parameters", "tool_code", "tool_name"}:
                return True
            if keys == {"type", "function"} or keys == {"type"}:
                return True
            # Shape: {"<tool_name>": {...}} with no prose
            if len(obj) == 1 and isinstance(next(iter(obj.values())), dict):
                return True
            # Shape: {"action": "...", ...} — narrated tool call from local LLMs
            if keys & {"action", "tool", "command", "function"}:
                return True
    return False


def _sanitize_assistant_text(text: str | None) -> str:
    """Replace empty/junk assistant text with a user-visible placeholder."""
    if _is_junk_assistant_text(text):
        return _NO_RESPONSE_PLACEHOLDER
    return text  # type: ignore[return-value]


# ── Narrated tool-call recovery (local-mode guard #6) ──
# Local LLMs sometimes return JSON that *describes* a tool call as their
# text response instead of using the structured tool-calling protocol.
# Examples:
#   {"action": "create_knowledge_base", "kb_name": "ai-frameworks"}
#   {"tool": "search_vault", "query": "AI agents"}
#   {"name": "run_wiki_job", "arguments": {"kb": "general"}}
#
# This function detects those shapes and maps them to (tool_name, params).
# It's called when the LLM returned no structured tool_calls but produced
# a JSON-like text response.

# Maps common narrated action names → registered tool names
_NARRATED_ACTION_MAP: dict[str, str] = {  # arch:deterministic — structural name mapping (LLM output key → tool registry name), same shape as TOOL_CONTRACT_MAP
    # KB actions
    "create_knowledge_base": "create_kb",
    "create_kb": "create_kb",
    "create_knowledgebase": "create_kb",
    # Research actions
    "search": "search_vault",
    "search_vault": "search_vault",
    "web_search": "web_search",
    "scrape": "scrape_url",
    "scrape_url": "scrape_url",
    "research": "research_scrape",
    "research_scrape": "research_scrape",
    # Wiki actions
    "run_wiki_job": "run_wiki_job",
    "run_wiki_pipeline": "run_wiki_job",
    "wiki_pipeline": "run_wiki_job",
    "run_workflow": "run_workflow",
    # Presentation
    "create_presentation": "create_presentation",
    "generate_presentation": "generate_kb_presentation",
    "make_presentation": "generate_kb_presentation",
    "build_presentation": "generate_kb_presentation",
    "generate_kb_presentation": "generate_kb_presentation",
    # Presentation update/refine
    "update_presentation": "update_presentation",
    "modify_presentation": "update_presentation",
    "refine_presentation": "update_presentation",
    # Research + present pipeline
    "research_and_present": "research_and_present",
    "research_and_make_presentation": "research_and_present",
    # Tasks/goals/projects
    "create_task": "create_task",
    "create_goal": "create_goal",
    "create_project": "create_project",
    # Memory
    "recall_memory": "recall_memory",
    "query_knowledge": "query_knowledge",
    # Journal
    "journal_write": "journal_write",
}

# Keys the LLM uses to name the action inside the JSON
_ACTION_KEYS = ("action", "tool", "tool_name", "function", "command", "name")  # arch:deterministic — JSON key detection for structured parsing

# Keys that are action-naming metadata, not tool parameters.
# Deliberately minimal — "description" is NOT here because many tools accept it.
_META_KEYS = _ACTION_KEYS + ("type",)


def _extract_narrated_tool_call(
    text: str, valid_tools: set[str] | None = None,
) -> tuple[str, dict] | None:
    """Try to parse a JSON text response as a narrated tool call.

    Returns ``(tool_name, params)`` if the text looks like a tool action
    description that maps to a registered tool. Returns ``None`` otherwise.
    """
    if not text:
        return None
    s = text.strip()
    if not (s.startswith("{") and s.endswith("}")):
        return None

    import json as _json
    try:
        obj = _json.loads(s)
    except Exception:
        return None

    if not isinstance(obj, dict) or not obj:
        return None

    # Find the action name from known keys
    action_name = ""
    for key in _ACTION_KEYS:
        val = obj.get(key)
        if isinstance(val, str) and val.strip():
            action_name = val.strip().lower().replace("-", "_").replace(" ", "_")
            break

    if not action_name:
        return None

    # Map to registered tool name
    tool_name = _NARRATED_ACTION_MAP.get(action_name, action_name)

    # Validate against registered tools if provided
    if valid_tools and tool_name not in valid_tools:
        return None

    # Extract params — everything except the meta keys
    params = {k: v for k, v in obj.items() if k.lower() not in _META_KEYS}

    # Normalize common param name variants
    if "kb_name" in params and "topic" not in params:
        params["topic"] = params.pop("kb_name")
    if "kb" in params and "topic" not in params:
        params["topic"] = params.pop("kb")

    return (tool_name, params)


class Agent:
    """The main AgntSpace agent.

    Loads identity from vault files, maintains conversation context,
    and delegates reasoning to an LLM provider.
    """

    def __init__(
        self,
        llm: LLMProvider,
        memory: ConversationMemory,
        vault: VaultReader,
        journal: JournalService | None = None,
        task_service: TaskService | None = None,
        trust_service: TrustService | None = None,
        tool_executor: ToolExecutor | None = None,
        memory_engine: MemoryEngine | None = None,
        skill_loader: SkillLoader | None = None,
        heartbeat: Heartbeat | None = None,
        registry: ToolRegistry | None = None,
        project_service: ProjectService | None = None,
        local_mode: bool = False,
        cost_tracker: object | None = None,
    ) -> None:
        self._llm = llm
        self._memory = memory
        self._vault = vault
        self._journal = journal
        self._task_service = task_service
        self._trust_service = trust_service
        self._last_tool_contract_action: str = ""  # for correction signal domain lookup
        self._tool_executor = tool_executor
        self._memory_engine = memory_engine
        self._skill_loader = skill_loader
        self._heartbeat = heartbeat
        self._registry = registry
        self._project_service = project_service
        self._local_mode = local_mode
        self._cost_tracker = cost_tracker
        self._model_router: object | None = None  # injected post-hoc from main.py
        self._activity: object | None = None  # injected post-hoc — ActivityLogger
        self._decisions: object | None = None  # injected post-hoc — DecisionLogger
        self._orchestrator: object | None = None  # injected post-hoc — Orchestrator (for invoke_skill)
        self._hooks: object | None = None  # injected post-hoc — HookBus (plugin hook dispatcher)
        # Rolling window of memory/knowledge references the agent has seen
        # in the current chat turn. Populated by memory-recall tool
        # execution; read by _execute_tool() when recording the "why" of
        # the NEXT tool call. Cleared at the start of each chat turn.
        self._recent_memory_refs: list[str] = []
        self._system_prompt: str | None = None
        self._identity_mtimes: dict[str, float] = {}
        self._last_identity_check: float = 0
        _IDENTITY_CHECK_COOLDOWN = 5.0  # seconds between file-stat checks

    async def initialize(self) -> None:
        """Load identity files and build the system prompt.

        Called at startup and automatically re-invoked when identity files change.
        """
        identity = self._vault.read_identity_files()
        self._snapshot_identity_mtimes()

        if "SOUL" not in identity:
            log.warning("SOUL.md not found in vault — agent has no identity")

        # Gather live context
        journal_today = None
        if self._journal:
            with contextlib.suppress(Exception):
                doc = self._journal.get_today()
                journal_today = doc.content

        active_tasks = None
        if self._task_service:
            with contextlib.suppress(Exception):
                active_tasks = [
                    t for t in self._task_service.list_tasks()
                    if t.get("status") not in ("done", "cancelled")
                ]

        active_projects = None
        if self._project_service:
            with contextlib.suppress(Exception):
                active_projects = [
                    p for p in self._project_service.list_projects()
                    if p.get("status") not in ("completed", "archived")
                ]

        trust_summary = None
        if self._trust_service:
            try:
                trust_data = self._trust_service.get_trust_data()
                if trust_data:
                    trust_summary = ", ".join(
                        f"{t['domain']}: {t['level']}" for t in trust_data
                    )
            except Exception:
                pass

        skills_summary = None
        if self._skill_loader:
            with contextlib.suppress(Exception):
                skills_summary = self._skill_loader.get_full_prompt_section()

        # Get capabilities and integrations from registry (auto-discovers everything)
        capabilities_text = None
        connected = None
        if self._registry:
            capabilities_text = self._registry.get_capabilities_text()
            connected = self._registry.get_connected_integrations() or None

        # Activity context for real-time awareness
        activity_context = None
        if self._activity and hasattr(self._activity, "get_relationship_context"):
            ctx = self._activity.get_relationship_context()
            if ctx:
                activity_context = ctx

        # Phase 6E: inject prediction accuracy so the agent knows how
        # well its model of the user is performing. This is the self-
        # awareness signal: "my prediction accuracy on user preferences
        # this month is 67%" gives the agent calibration data.
        prediction_engine = getattr(self, "_prediction_engine", None)
        if prediction_engine is not None:
            try:
                ps = prediction_engine.stats()
                if ps.get("total_resolved", 0) > 0:
                    accuracy_pct = round((ps.get("accuracy") or 0) * 100)
                    pred_line = (
                        f"Prediction loop: {ps['confirmed']} confirmed, "
                        f"{ps['surprising']} surprising, {ps['pending']} pending. "
                        f"Accuracy: {accuracy_pct}%."
                    )
                    if activity_context:
                        activity_context += "\n" + pred_line
                    else:
                        activity_context = pred_line
            except Exception:
                pass

        # Agent insights: inject top observations so the agent leads
        # conversations with what it's been thinking about. This is the
        # key agent-first behavior — the agent doesn't wait to be asked.
        insights_engine = getattr(self, "_insights_engine", None)
        if insights_engine is not None:
            try:
                nudges = insights_engine.get_chat_nudges(max_count=3)
                if nudges:
                    if activity_context:
                        activity_context += "\n\n" + nudges
                    else:
                        activity_context = nudges
            except Exception:
                pass

        self._system_prompt = build_system_prompt(
            soul=identity["SOUL"].content if "SOUL" in identity else "",
            user=identity["USER"].content if "USER" in identity else "",
            contract=identity["CONTRACT"].content if "CONTRACT" in identity else "",
            memory=identity["MEMORY"].content if "MEMORY" in identity else "",
            profile=identity["PROFILE"].content if "PROFILE" in identity else None,
            relationship=identity["RELATIONSHIP"].content if "RELATIONSHIP" in identity else None,
            activity_context=activity_context,
            journal_today=journal_today,
            active_tasks=active_tasks,
            active_projects=active_projects,
            trust_summary=trust_summary,
            skills_summary=skills_summary,
            connected_integrations=connected,
            capabilities_text=capabilities_text,
            local_mode=self._local_mode,
            skills_dir=str(self._skill_loader._skills_dir) if self._skill_loader else None,
            skill_loader=self._skill_loader,
        )
        log.debug(
            "Agent initialized — system prompt: %d chars, identity files: %s",
            len(self._system_prompt),
            ", ".join(identity.keys()),
        )

    # ── Identity file hot-reload ──

    _IDENTITY_PATHS = [  # arch:deterministic — fixed identity file layout; these paths are structural invariants of the vault, not user-tunable strategy
        "system/identity/SOUL.md",
        "system/identity/USER.md",
        "system/identity/PROFILE.md",
        "system/identity/RELATIONSHIP.md",
        "memory/MEMORY.md",
    ]

    def _resolve_identity_path(self, rel: str) -> Path:
        """Resolve an identity file logical path to a physical path."""
        if hasattr(self._vault, "paths") and self._vault.paths:
            return self._vault.paths.resolve(rel)
        return self._vault._vault_dir / rel

    def _snapshot_identity_mtimes(self) -> None:
        """Record current mtimes of identity files."""
        for rel in self._IDENTITY_PATHS:
            path = self._resolve_identity_path(rel)
            try:
                self._identity_mtimes[rel] = path.stat().st_mtime if path.is_file() else 0
            except OSError:
                self._identity_mtimes[rel] = 0

    def _identity_files_changed(self) -> bool:
        """Check if any identity file has been modified since last snapshot."""
        for rel in self._IDENTITY_PATHS:
            path = self._resolve_identity_path(rel)
            try:
                mtime = path.stat().st_mtime if path.is_file() else 0
            except OSError:
                mtime = 0
            if mtime != self._identity_mtimes.get(rel, 0):
                return True
        return False

    async def _ensure_fresh_prompt(self) -> None:
        """Re-build system prompt if identity files changed on disk.

        Checks at most every 5 seconds to avoid stat() on every message.
        """
        now = time.monotonic()
        if (now - self._last_identity_check) < 5.0:
            return
        self._last_identity_check = now
        if self._identity_files_changed():
            log.info("Identity files changed on disk — rebuilding system prompt")
            await self.initialize()

    async def chat(
        self, conversation_id: str, user_message: str,
        provenance: dict | None = None,
    ) -> str:
        """Non-streaming chat with tool use. Provider-independent.

        Uses the LLM abstraction layer — works with Anthropic, OpenAI, Ollama.
        Every event and decision produced in this call shares a single
        correlation_id so you can trace the full causal chain.

        *provenance* is stamped on the user message at the channel boundary
        (``{kind, source_channel, origin_session, source_tool}``).
        """
        import json

        from agntspace.activity.decisions import (
            current_correlation_id,
            new_correlation_id,
            reset_authorized_actions,
            set_correlation_id,
        )
        from agntspace.llm.base import Message as LLMMessage

        # Begin a causal chain for this chat turn unless one is already
        # set by the channel/webhook caller (e.g. WhatsApp bridge).
        _corr_token = None
        if not current_correlation_id():
            _corr_token = set_correlation_id(new_correlation_id("chat"))
        # Every chat turn starts with an empty authorized-contract-actions
        # set, regardless of whether we opened a fresh scope or inherited
        # one. Without this, actions from the previous turn would leak
        # into this one and defeat the VaultWriter runtime guard — the
        # whole point of per-scope authorization. The token is not
        # restored at turn end: contextvars don't leak across asyncio
        # tasks, so the next turn (in a different task) starts clean
        # regardless.
        reset_authorized_actions()

        # Fresh memory provenance window for this turn
        self._recent_memory_refs = []

        await self._ensure_fresh_prompt()
        await self._check_budget()

        # Same tool path for cloud and local — contract-filtered so the
        # LLM never wastes rounds on tools the contract blocks.
        if self._registry:
            tool_defs = self._registry.get_contract_filtered_definitions()
        else:
            from agntspace.agent.tools import TOOL_DEFINITIONS
            tool_defs = TOOL_DEFINITIONS

        valid_tools = {t["name"] for t in tool_defs} if tool_defs else set()

        self._check_journal_candidate(user_message)
        await self._memory.add_message(conversation_id, "user", user_message, provenance=provenance)
        asyncio.create_task(self._extract_entities(user_message))
        # Capture the user message for the prediction hook later.
        # The prediction hook runs as a background task AFTER the
        # response is sent so it never blocks the user-visible path.
        _user_message_for_prediction = user_message

        # Track user activity for silence detection + word count for engagement
        if self._activity and hasattr(self._activity, "record_user_activity"):
            self._activity.record_user_activity("chat")
            word_count = len(user_message.split())
            self._log_activity("chat", "user_message", f"{user_message[:60]}",
                               {"user_words": word_count, "conversation_id": conversation_id},
                               importance="low")
        history = await self._memory.get_context_messages(conversation_id)

        # Inject artifact context so the LLM knows what's "in focus"
        artifact = await self._memory.get_artifact(conversation_id)
        if artifact:
            artifact_ctx = (
                f"[Artifact in focus: {artifact['type']} at {artifact['path']}. "
                f"If the user asks to refine, update, or change something, "
                f"it refers to this artifact. Metadata: {artifact.get('metadata', {})}]"
            )
            history = [LLMMessage(role="system", content=artifact_ctx)] + list(history)

        from agntspace.llm.base import LLMError

        # Local-mode intent fast path — match user message to tool call
        # via regex patterns before calling the LLM (same logic as chat_stream)
        if self._local_mode and tool_defs and self._tool_executor:
            _last_asst = None
            if history:
                for m in reversed(history):
                    if m.role == "assistant":
                        _last_asst = m.content
                        break
            intent = self._match_local_intent(user_message, last_assistant=_last_asst)
            if intent:
                tool_name, tool_params = intent
                # Inject artifact path for refinement tools
                if artifact and not tool_params.get("path"):
                    tool_params["path"] = artifact["path"]
                log.info("Local intent matched (chat): %s(%s)", tool_name, json.dumps(tool_params)[:100])
                result = await self._execute_tool(tool_name, tool_params)
                await self._capture_artifact(conversation_id, tool_name, result)
                await self._record_pulse("tool_use", f"{tool_name} (intent)")
                self._log_activity("tool", "invoked", f"{tool_name} (intent)",
                                   {"tool": tool_name, "input_keys": list(tool_params.keys())})
                result_json = json.dumps(result)
                if len(result_json) > 2000:
                    result_json = result_json[:2000] + "..."
                summary_response = await self._llm.complete(
                    messages=list(history) + [
                        LLMMessage(
                            role="user",
                            content=(
                                f"I asked: {user_message}\n\n"
                                f"The tool `{tool_name}` was executed with result:\n{result_json}\n\n"
                                f"Tell the user what was done. Be brief and positive. If the result contains a 'message' or 'created' or 'scraped' field, report success. Only report an error if there is an 'error' field."
                            ),
                        ),
                    ],
                    system=self._system_prompt,
                )
                final_text = _sanitize_assistant_text(summary_response.content)
                await self._memory.add_message(conversation_id, "assistant", final_text)
                return final_text

        # Use tool-enabled completion if we have tools
        if tool_defs and self._tool_executor:
            try:
                messages = list(history)  # copy
                max_rounds = 5

                for _ in range(max_rounds):
                    response = await self._llm.complete_with_tools(
                        messages=messages,
                        tools=tool_defs,
                        system=self._system_prompt,
                    )

                    # Check if LLM wants to use tools
                    if response.tool_calls:
                        # Validate tool names — local models may hallucinate
                        invalid = [tc for tc in response.tool_calls if tc.name not in valid_tools]
                        if invalid:
                            log.warning("Hallucinated tool calls: %s", ", ".join(tc.name for tc in invalid))
                            break  # fall through to basic completion

                        # Append assistant response with raw content
                        messages.append(LLMMessage(role="assistant", content=response.raw_content or response.content))

                        # Execute each tool call and send results back
                        _any_blocked = False
                        for tc in response.tool_calls:
                            log.info("Tool call: %s(%s)", tc.name, json.dumps(tc.input)[:100])
                            result = await self._execute_tool(tc.name, tc.input)
                            await self._capture_artifact(conversation_id, tc.name, result)
                            await self._record_pulse("tool_use", f"{tc.name}")
                            self._log_activity("tool", "invoked", f"{tc.name}",
                                               {"tool": tc.name, "input_keys": list(tc.input.keys())})
                            # Use "tool" role with tool_call_id (OpenAI/LiteLLM format)
                            messages.append(LLMMessage(
                                role="tool",
                                content=json.dumps(result),
                                tool_call_id=tc.id,
                            ))
                            if isinstance(result, dict) and result.get("contract_blocked"):
                                _any_blocked = True

                        if _any_blocked:
                            _block_msg = (
                                "I can't perform that action — it's blocked by "
                                "your Contract settings. You can change the "
                                "permission in the Contract Editor (Settings → "
                                "Contract) if you'd like to allow it."
                            )
                            await self._memory.add_message(
                                conversation_id, "assistant", _block_msg,
                            )
                            return _block_msg

                        continue

                    # No tool calls — check if the LLM narrated a tool call as JSON text
                    narrated = _extract_narrated_tool_call(response.content, valid_tools)
                    if narrated:
                        tool_name, tool_params = narrated
                        log.info("Recovered narrated tool call: %s(%s)", tool_name, json.dumps(tool_params)[:100])
                        result = await self._execute_tool(tool_name, tool_params)
                        await self._capture_artifact(conversation_id, tool_name, result)
                        await self._record_pulse("tool_use", f"{tool_name} (recovered)")
                        self._log_activity("tool", "invoked", f"{tool_name} (narrated recovery)",
                                           {"tool": tool_name, "input_keys": list(tool_params.keys())})
                        # Ask the LLM to summarize the result for the user
                        result_json = json.dumps(result)
                        if len(result_json) > 2000:
                            result_json = result_json[:2000] + "..."
                        summary_response = await self._llm.complete(
                            messages=list(history) + [
                                LLMMessage(
                                    role="user",
                                    content=(
                                        f"I asked: {user_message}\n\n"
                                        f"The tool `{tool_name}` was executed with result:\n{result_json}\n\n"
                                        f"Tell the user what was done. Be brief and positive. If the result contains a 'message' or 'created' or 'scraped' field, report success. Only report an error if there is an 'error' field."
                                    ),
                                ),
                            ],
                            system=self._system_prompt,
                        )
                        final_text = _sanitize_assistant_text(summary_response.content)
                        await self._memory.add_message(conversation_id, "assistant", final_text)
                        return final_text

                    # No tool calls — final response
                    final_text = _sanitize_assistant_text(response.content)
                    final_text = await self._apply_reply_hook(final_text, conversation_id)
                    await self._memory.add_message(conversation_id, "assistant", final_text)
                    await self._extract_entities(final_text, is_user=False)
                    log.info("Chat (tools): %d in, %d out tokens", response.input_tokens, response.output_tokens)
                    await self._record_cost(
                        response.input_tokens, response.output_tokens, conversation_id, "chat",
                        cache_read_tokens=response.cache_read_tokens, cache_write_tokens=response.cache_write_tokens,
                        provider_cost=response.provider_cost,
                    )
                    await self._record_pulse("chat", f"Response: {final_text[:80]}")
                    self._log_activity("chat", "responded", f"{user_message[:60]}",
                                       {"tokens_in": response.input_tokens, "tokens_out": response.output_tokens},
                                       importance="low")
                    self._fire_prediction_hook(_user_message_for_prediction, final_text)
                    return final_text

                return "I tried multiple tool calls but couldn't complete. Please try again."

            except LLMError:
                raise  # surface to caller with clear reason
            except Exception:
                log.exception("Tool-enabled chat failed, falling back to basic")

        # Fallback: basic completion without tools
        try:
            response = await self._llm.complete(
                messages=history,
                system=self._system_prompt,
            )
        except LLMError:
            raise  # surface to caller with clear reason
        clean = _sanitize_assistant_text(response.content)
        clean = await self._apply_reply_hook(clean, conversation_id)
        await self._memory.add_message(conversation_id, "assistant", clean)
        await self._record_pulse("chat", f"Response: {clean[:80]}")
        self._fire_prediction_hook(_user_message_for_prediction, clean)
        return clean

    def _fire_prediction_hook(
        self, user_message: str, assistant_response: str
    ) -> None:
        """Fire the prediction loop as a background task after a chat response.

        Phase 6E integration: the ``PredictionEngine.chat_hook_post_response``
        method implements the three configurable modes (every_turn / daily /
        every_nth) per ``memory-prediction/config/prediction.yaml``. We call
        it via ``asyncio.create_task`` so the user never waits for it.

        The context_text is the system prompt (summarizes the agent's current
        understanding of the conversation); the observation_text is the user's
        latest message (what the agent should validate predictions against).

        If the prediction engine isn't wired (``app.state.prediction_engine``
        not set, or no running loop), this is a silent no-op.
        """
        prediction_engine = getattr(self, "_prediction_engine", None)
        if prediction_engine is None:
            return
        try:
            context = f"{self._system_prompt[:2000]}\n\nUser: {user_message}\nAssistant: {assistant_response[:500]}"
            asyncio.create_task(
                prediction_engine.chat_hook_post_response(
                    context_text=context,
                    observation_text=user_message,
                )
            )
        except Exception:
            log.debug("prediction hook fire failed", exc_info=True)

    def _resolve_model(self, model_tier: str | None) -> str | None:
        """Resolve a model tier to a specific model name via model_router."""
        if model_tier and self._model_router and hasattr(self._model_router, "resolve"):
            return self._model_router.resolve(model_tier)
        return None

    async def process_task(self, task: str, context: str = "", model_tier: str | None = None) -> str:
        """Process an internal system task using the agent's full capabilities.

        Like chat() but does NOT save to conversation memory — intended for
        automation tasks (daily briefing, EOD, reflections, memory compaction)
        that should not appear in the user's chat history.

        The agent's full system prompt (identity, skills, memory) is used,
        and tools are available for the agent to call during processing.

        Args:
            model_tier: Optional tier override ("fast", "capable", "reasoning").
                        Background tasks should use "fast" to save costs.
        """
        import json
        from datetime import datetime as _dt

        from agntspace.llm.base import LLMError
        from agntspace.llm.base import Message as LLMMessage

        # Deterministic date header — process_task callers are background
        # automation (briefing, EOD, reflection, compaction) where the LLM must
        # know the exact date/weekday.  The system prompt has # Current Time in
        # UTC, but fast-tier models often ignore it.  Prepending it to the user
        # message makes it impossible to miss.

        _now = _dt.now()
        date_header = f"TODAY: {_now.strftime('%A, %B %d, %Y')} (local time)\n\n"

        # Build the user message from task + context
        if context:
            user_content = f"{date_header}{context}\n\n---\n\n{task}"
        else:
            user_content = f"{date_header}{task}"

        messages = [LLMMessage(role="user", content=user_content)]

        # Resolve model tier to specific model name (e.g., "fast" → "claude-haiku-4-5")
        resolved_model = self._resolve_model(model_tier)

        # No budget gate here — process_task is called by background automation
        # (daily cycle, reflections, memory compaction) where a hard crash would
        # break the pipeline.  Budget enforcement is on interactive paths only
        # (chat, chat_stream).  Background callers already have retry/queue.

        # Get tool definitions — skip for local mode (small models hallucinate
        # tool JSON instead of generating content; automation tasks have
        # pre-gathered context and don't need tools)
        tool_defs = None
        if self._registry and self._tool_executor and not self._local_mode:
            tool_defs = self._registry.get_contract_filtered_definitions()
        valid_tools = {t["name"] for t in tool_defs} if tool_defs else set()

        if tool_defs and self._tool_executor:
            try:
                max_rounds = 5
                for _ in range(max_rounds):
                    response = await self._llm.complete_with_tools(
                        messages=messages,
                        tools=tool_defs,
                        system=self._system_prompt,
                        model=resolved_model,
                    )

                    if response.tool_calls:
                        invalid = [tc for tc in response.tool_calls if tc.name not in valid_tools]
                        if invalid:
                            log.warning("process_task: hallucinated tool calls: %s", ", ".join(tc.name for tc in invalid))
                            break

                        messages.append(LLMMessage(role="assistant", content=response.raw_content or response.content))

                        for tc in response.tool_calls:
                            log.info("process_task tool: %s(%s)", tc.name, json.dumps(tc.input)[:100])
                            result = await self._execute_tool(tc.name, tc.input)
                            await self._record_pulse("tool_use", f"{tc.name}")
                            messages.append(LLMMessage(
                                role="tool",
                                content=json.dumps(result),
                                tool_call_id=tc.id,
                            ))
                        continue

                    # No tool calls — final response
                    final_text = response.content
                    if self._is_junk_response(final_text):
                        log.warning("process_task: LLM returned junk JSON instead of content, falling back to basic")
                        break
                    await self._extract_entities(final_text, is_user=False)
                    log.info("process_task: %d in, %d out tokens", response.input_tokens, response.output_tokens)
                    await self._record_cost(
                        response.input_tokens, response.output_tokens, action="process_task",
                        cache_read_tokens=response.cache_read_tokens, cache_write_tokens=response.cache_write_tokens,
                        provider_cost=response.provider_cost,
                    )
                    await self._record_pulse("automation", f"process_task: {task[:80]}")
                    return final_text

                # Exhausted tool rounds or junk response — fall through to basic completion
                log.warning("process_task: tool loop ended without clean response, falling back to basic")

            except LLMError:
                raise
            except Exception:
                log.exception("process_task tool loop failed, falling back to basic")

        # Fallback: basic completion without tools
        try:
            response = await self._llm.complete(
                messages=messages,
                system=self._system_prompt,
                model=resolved_model,
            )
        except LLMError:
            raise
        await self._extract_entities(response.content, is_user=False)
        await self._record_cost(
            response.input_tokens, response.output_tokens, action="process_task",
            cache_read_tokens=response.cache_read_tokens, cache_write_tokens=response.cache_write_tokens,
            provider_cost=response.provider_cost,
        )
        await self._record_pulse("automation", f"process_task: {task[:80]}")
        return response.content

    async def chat_stream(
        self, conversation_id: str, user_message: str, skip_tools: bool = False,
        system_suffix: str = "", provenance: dict | None = None,
        store_message: str | None = None,
    ) -> AsyncIterator[StreamChunk]:
        """Streaming chat with tool use support.

        Tool calls are executed non-streaming in a loop. Once the LLM
        produces a final text response (no more tool calls), that
        response is streamed to the client.

        skip_tools: if True, don't provide tools to the LLM (used in
        answering mode where the agent should respond conversationally).

        system_suffix: optional text appended to the system prompt for
        this call only (e.g. channel answering-mode instructions). Not
        persisted — keeps conversation history clean.

        provenance: stamped on the user message at the channel boundary.

        store_message: if provided, this is what gets saved to conversation
        history instead of user_message. Use this when user_message contains
        ephemeral wrapping (e.g. prompt injection defense envelopes) that
        should reach the LLM but not pollute the stored conversation.
        """
        import json

        from agntspace.llm.base import LLMError
        from agntspace.llm.base import Message as LLMMessage

        await self._ensure_fresh_prompt()
        await self._check_budget()

        # Build the effective system prompt for this call.  The suffix
        # is NOT persisted — it only exists in the LLM call so that
        # channel instructions (answering mode) appear once in the system
        # prompt rather than repeated on every stored user message.
        _effective_system = self._system_prompt
        if system_suffix:
            _effective_system = (self._system_prompt or "") + "\n\n" + system_suffix
        # Store the clean version in conversation history (without prompt
        # guard envelopes), but send the full version to the LLM.
        _stored = store_message or user_message
        self._check_journal_candidate(_stored)
        await self._memory.add_message(conversation_id, "user", _stored, provenance=provenance)
        # Fire-and-forget: correction detection for trust + entity extraction
        self._check_correction_signal(_stored)
        asyncio.create_task(self._extract_entities(_stored))
        history = await self._memory.get_context_messages(conversation_id)

        # Inject artifact context so the LLM knows what's "in focus"
        _artifact = await self._memory.get_artifact(conversation_id)
        if _artifact:
            _art_ctx = (
                f"[Artifact in focus: {_artifact['type']} at {_artifact['path']}. "
                f"If the user asks to refine, update, or change something, "
                f"it refers to this artifact. Metadata: {_artifact.get('metadata', {})}]"
            )
            history = [LLMMessage(role="system", content=_art_ctx)] + list(history)

        # When store_message differs from user_message (prompt guard envelope),
        # the DB has the clean text.  Swap the last user message in the LLM
        # history with the full sanitized version so the model sees the
        # security wrapping for the *current* turn only.
        if store_message and history:
            for i in range(len(history) - 1, -1, -1):
                if history[i].role == "user":
                    history[i] = LLMMessage(role="user", content=user_message)
                    break

        # Get tool definitions — same path for cloud and local (cached).
        # Use contract-filtered list so the LLM never sees tools the
        # contract blocks outright (avoids wasting rounds on blocked calls).
        tool_defs = None
        if self._registry and self._tool_executor and not skip_tools:
            tool_defs = self._registry.get_contract_filtered_definitions()

        # Build set of valid tool names for hallucination detection
        valid_tools = {t["name"] for t in tool_defs} if tool_defs else set()

        try:
            # ── Local-mode fast path: intent matching BEFORE complete_with_tools ──
            # For local models, try regex-based intent matching first (instant,
            # no LLM call).  If we get a match, execute the tool and summarize
            # in ONE LLM call instead of two (complete_with_tools + stream).
            # This avoids queuing behind other Ollama requests for the expensive
            # tool-definition-laden first call that often returns junk JSON anyway.
            if self._local_mode and tool_defs and self._tool_executor:
                # Local models (Ollama) can't do structured tool calling
                # reliably — they return text JSON instead of tool_use blocks.
                # Skip complete_with_tools entirely: intent matching handles
                # tool calls, plain streaming handles conversation.
                # Extract last assistant message for affirmative follow-up matching
                _last_asst = None
                for _h in reversed(history):
                    if _h.role == "assistant":
                        _last_asst = _h.content
                        break
                intent = self._match_local_intent(user_message, last_assistant=_last_asst)
                if intent:
                    tool_name, tool_input = intent
                    # Inject artifact path for refinement tools
                    if _artifact and not tool_input.get("path"):
                        tool_input["path"] = _artifact["path"]
                    log.info("Local fast-path intent: %s(%s)", tool_name, json.dumps(tool_input)[:100])
                    yield StreamChunk(delta="", tool_name=tool_name, tool_status="running")
                    result = await self._execute_tool(tool_name, tool_input)
                    await self._capture_artifact(conversation_id, tool_name, result)
                    await self._record_pulse("tool_use", tool_name)
                    yield StreamChunk(delta="", tool_name=tool_name, tool_status="done")
                    result_json = json.dumps(result, default=str)
                    if len(result_json) > 2000:
                        result_json = result_json[:2000] + "..."
                    summary_msgs = list(history) + [
                        LLMMessage(
                            role="user",
                            content=f"I asked: {user_message}\n\nThe tool `{tool_name}` returned:\n{result_json}\n\nSummarize this result concisely for the user.",
                        ),
                    ]
                    full_response = ""
                    async for chunk in self._llm.stream(messages=summary_msgs, system=_effective_system):
                        full_response += chunk.delta
                        yield chunk
                        if chunk.done:
                            await self._memory.add_message(
                                conversation_id, "assistant", _sanitize_assistant_text(full_response)
                            )
                    return
                else:
                    # No intent match — skip to plain streaming (no tool loop).
                    # This avoids the 90-100s complete_with_tools call that
                    # always returns junk JSON for local models.
                    log.info("Local mode: no intent match, skipping tool loop for plain streaming")
                    tool_defs = None  # signals "skip tool loop" below
                    # Tell the model not to attempt tool calls in text —
                    # the system prompt mentions tools but we're streaming
                    # without tool support now.
                    _effective_system = (_effective_system or "") + (
                        "\n\nIMPORTANT: You cannot call tools right now. "
                        "Do NOT output JSON, tool_code, or any tool call syntax. "
                        "Respond conversationally in plain natural language only."
                    )

            if tool_defs and self._tool_executor:
                # Tool-enabled path: run tool loop non-streaming, then stream the final answer
                messages = list(history)
                max_rounds = 5
                last_tool_results: dict[str, str] = {}  # tool_name → result json

                for _ in range(max_rounds):
                    response = await self._llm.complete_with_tools(
                        messages=messages,
                        tools=tool_defs,
                        system=_effective_system,
                    )

                    if response.tool_calls:
                        # Validate tool names — local models may hallucinate
                        invalid = [tc for tc in response.tool_calls if tc.name not in valid_tools]
                        if invalid:
                            log.warning(
                                "Hallucinated tool calls: %s — falling back to conversation",
                                ", ".join(tc.name for tc in invalid),
                            )
                            break  # fall through to streaming

                        # Detect repeated tool call (local models loop instead of summarizing)
                        repeated = any(tc.name in last_tool_results for tc in response.tool_calls)
                        if repeated and self._local_mode:
                            log.info("Local model repeated tool call — summarizing previous result")
                            # Use the last tool result to generate a summary
                            tool_name = response.tool_calls[0].name
                            result_json = last_tool_results[tool_name]
                            if len(result_json) > 2000:
                                result_json = result_json[:2000] + "..."
                            summary_msgs = list(history) + [
                                LLMMessage(
                                    role="user",
                                    content=f"I asked: {user_message}\n\nThe tool `{tool_name}` returned:\n{result_json}\n\nSummarize this result concisely for the user.",
                                ),
                            ]
                            full_response = ""
                            async for chunk in self._llm.stream(messages=summary_msgs, system=_effective_system):
                                full_response += chunk.delta
                                yield chunk
                                if chunk.done:
                                    await self._memory.add_message(
                                        conversation_id, "assistant", _sanitize_assistant_text(full_response)
                                    )
                            return

                        messages.append(LLMMessage(
                            role="assistant",
                            content=response.raw_content or response.content,
                        ))

                        _any_blocked = False
                        for tc in response.tool_calls:
                            log.info("Tool call (stream): %s(%s)", tc.name, json.dumps(tc.input)[:100])
                            yield StreamChunk(delta="", tool_name=tc.name, tool_status="running")
                            result = await self._execute_tool(tc.name, tc.input)
                            await self._capture_artifact(conversation_id, tc.name, result)
                            await self._record_pulse("tool_use", f"{tc.name}")
                            result_str = json.dumps(result)
                            last_tool_results[tc.name] = result_str
                            yield StreamChunk(delta="", tool_name=tc.name, tool_status="done")
                            messages.append(LLMMessage(
                                role="tool",
                                content=result_str,
                                tool_call_id=tc.id,
                            ))
                            if isinstance(result, dict) and result.get("contract_blocked"):
                                _any_blocked = True

                        # If any tool was contract-blocked, tell the user
                        # immediately instead of letting the LLM loop and
                        # retry (which shows as infinite "thinking").
                        if _any_blocked:
                            _block_msg = (
                                "I can't perform that action — it's blocked by "
                                "your Contract settings. You can change the "
                                "permission in the Contract Editor (Settings → "
                                "Contract) if you'd like to allow it."
                            )
                            for i in range(0, len(_block_msg), 12):
                                yield StreamChunk(delta=_block_msg[i:i + 12])
                            await self._memory.add_message(
                                conversation_id, "assistant", _block_msg,
                            )
                            yield StreamChunk(delta="", done=True)
                            return

                        continue

                    # No tool calls — check for narrated tool call (local-mode guard #6)
                    narrated = _extract_narrated_tool_call(response.content, valid_tools)
                    if narrated:
                        _nt_tool, _nt_params = narrated
                        log.info("Recovered narrated tool call (stream): %s(%s)", _nt_tool, json.dumps(_nt_params)[:100])
                        _nt_result = await self._execute_tool(_nt_tool, _nt_params)
                        await self._capture_artifact(conversation_id, _nt_tool, _nt_result)
                        await self._record_pulse("tool_use", f"{_nt_tool} (recovered)")
                        self._log_activity("tool", "invoked", f"{_nt_tool} (narrated recovery)",
                                           {"tool": _nt_tool, "input_keys": list(_nt_params.keys())})
                        _nt_result_json = json.dumps(_nt_result)
                        if len(_nt_result_json) > 2000:
                            _nt_result_json = _nt_result_json[:2000] + "..."
                        _nt_summary_msgs = list(history) + [
                            LLMMessage(
                                role="user",
                                content=(
                                    f"I asked: {user_message}\n\n"
                                    f"The tool `{_nt_tool}` was executed with result:\n{_nt_result_json}\n\n"
                                    f"Tell the user what was done. Be brief and positive. If the result contains a 'message' or 'created' or 'scraped' field, report success. Only report an error if there is an 'error' field."
                                ),
                            ),
                        ]
                        _nt_full = ""
                        async for chunk in self._llm.stream(messages=_nt_summary_msgs, system=_effective_system):
                            _nt_full += chunk.delta
                            yield chunk
                            if chunk.done:
                                await self._memory.add_message(
                                    conversation_id, "assistant", _sanitize_assistant_text(_nt_full)
                                )
                        return

                    # Stream the final text response
                    final_text = response.content
                    # Reply hook runs BEFORE chunking so plugins can rewrite
                    # the text the user actually sees (not just what's persisted).
                    final_text = await self._apply_reply_hook(final_text, conversation_id)
                    # Detect junk output (raw JSON tool calls, empty braces).
                    # Cloud models can also emit tool-call JSON as text, so
                    # check unconditionally — not just in local mode.
                    is_junk = _is_junk_assistant_text(final_text)
                    if is_junk and last_tool_results:
                        log.info("Empty response after tool call — summarizing")
                        tool_name, result_json = next(iter(last_tool_results.items()))
                        if len(result_json) > 2000:
                            result_json = result_json[:2000] + "..."
                        summary_msgs = list(history) + [
                            LLMMessage(
                                role="user",
                                content=f"I asked: {user_message}\n\nThe tool `{tool_name}` returned:\n{result_json}\n\nSummarize this result concisely for the user.",
                            ),
                        ]
                        full_response = ""
                        async for chunk in self._llm.stream(messages=summary_msgs, system=_effective_system):
                            full_response += chunk.delta
                            yield chunk
                            if chunk.done:
                                await self._memory.add_message(
                                    conversation_id, "assistant", _sanitize_assistant_text(full_response)
                                )
                        return

                    # Junk output with no tool results — fall through to plain streaming
                    if is_junk:
                        log.info("Junk output from local model (%s) — falling to plain streaming", repr(final_text.strip()))
                        break

                    # Stream it chunk by chunk for a natural feel
                    chunk_size = 12
                    for i in range(0, len(final_text), chunk_size):
                        piece = final_text[i : i + chunk_size]
                        yield StreamChunk(delta=piece)

                    # Save message and send done BEFORE slow post-processing
                    final_text = _sanitize_assistant_text(final_text)
                    await self._memory.add_message(conversation_id, "assistant", final_text)
                    log.info(
                        "Stream response (tools): %d in, %d out tokens",
                        response.input_tokens, response.output_tokens,
                    )
                    yield StreamChunk(delta="", done=True, response=response)

                    # Post-processing — fire-and-forget so the generator
                    # exits immediately and the WS handler can process the
                    # next user message without waiting for entity extraction
                    # or prediction hooks (which involve LLM calls).
                    _resp_copy = response

                    async def _post_process(_ft=final_text, _rc=_resp_copy) -> None:
                        try:
                            await self._extract_entities(_ft, is_user=False)
                            await self._record_cost(
                                _rc.input_tokens, _rc.output_tokens,
                                conversation_id, "chat_stream",
                                cache_read_tokens=_rc.cache_read_tokens,
                                cache_write_tokens=_rc.cache_write_tokens,
                                provider_cost=_rc.provider_cost,
                            )
                            await self._record_pulse("chat", f"Response: {_ft[:80]}")
                            self._fire_prediction_hook(user_message, _ft)
                        except Exception:
                            log.debug("chat_stream post-processing failed", exc_info=True)

                    asyncio.create_task(_post_process())
                    return

                # Fell through — either exhausted rounds or hallucinated tools
                # For local mode: try intent matching as fallback, or summarize any tool results
                if self._local_mode:
                    if last_tool_results:
                        log.info("Exhausted rounds with tool results — summarizing")
                        tool_name, result_json = next(iter(last_tool_results.items()))
                        if len(result_json) > 2000:
                            result_json = result_json[:2000] + "..."
                        summary_msgs = list(history) + [
                            LLMMessage(
                                role="user",
                                content=f"I asked: {user_message}\n\nThe tool `{tool_name}` returned:\n{result_json}\n\nSummarize this result concisely for the user.",
                            ),
                        ]
                        full_response = ""
                        async for chunk in self._llm.stream(messages=summary_msgs, system=_effective_system):
                            full_response += chunk.delta
                            yield chunk
                            if chunk.done:
                                await self._memory.add_message(
                                    conversation_id, "assistant", _sanitize_assistant_text(full_response)
                                )
                        return

                    intent = self._match_local_intent(user_message)
                    if intent:
                        tool_name, tool_input = intent
                        log.info("Intent fallback: %s(%s)", tool_name, json.dumps(tool_input)[:100])
                        yield StreamChunk(delta=f"Running {tool_name}...\n\n")
                        result = await self._execute_local_tool(tool_name, tool_input)
                        await self._record_pulse("tool_use", tool_name)
                        result_json = json.dumps(result, default=str)
                        if len(result_json) > 2000:
                            result_json = result_json[:2000] + "..."
                        summary_msgs = list(history) + [
                            LLMMessage(
                                role="user",
                                content=f"I asked: {user_message}\n\nThe tool `{tool_name}` returned:\n{result_json}\n\nSummarize this result concisely for the user.",
                            ),
                        ]
                        full_response = ""
                        async for chunk in self._llm.stream(messages=summary_msgs, system=_effective_system):
                            full_response += chunk.delta
                            yield chunk
                            if chunk.done:
                                await self._memory.add_message(
                                    conversation_id, "assistant", _sanitize_assistant_text(full_response)
                                )
                        return

                # No intent match either — fall through to plain streaming

            # No tools or fallback — pure streaming.
            # When we land here after junk detection broke us out of the tool
            # loop, the model saw tool descriptions in the system prompt and
            # tried to call them via text JSON.  Append a stern instruction so
            # the plain-stream retry doesn't repeat the same mistake.
            _stream_system = _effective_system
            if self._local_mode and tool_defs:
                _stream_system = (_effective_system or "") + (
                    "\n\nIMPORTANT: Do NOT output JSON tool calls. "
                    "Respond in plain natural language only."
                )
            full_response = ""
            async for chunk in self._llm.stream(
                messages=history,
                system=_stream_system,
            ):
                full_response += chunk.delta
                yield chunk
                if chunk.done:
                    await self._memory.add_message(
                        conversation_id, "assistant", _sanitize_assistant_text(full_response)
                    )
                    if chunk.response:
                        log.info(
                            "Stream response: %d input tokens, %d output tokens",
                            chunk.response.input_tokens,
                            chunk.response.output_tokens,
                        )
                        await self._record_cost(
                            chunk.response.input_tokens,
                            chunk.response.output_tokens,
                            conversation_id, "chat_stream",
                            cache_read_tokens=chunk.response.cache_read_tokens,
                            cache_write_tokens=chunk.response.cache_write_tokens,
                            provider_cost=chunk.response.provider_cost,
                        )
                    self._fire_prediction_hook(user_message, full_response)

        except LLMError as e:
            error_msg = f"⚠ {e.user_message}"
            await self._memory.add_message(conversation_id, "assistant", error_msg)
            yield StreamChunk(delta=error_msg, done=True)
        except Exception as e:
            log.exception("Streaming failed")
            error_msg = f"⚠ Unexpected error: {e!s}"
            with contextlib.suppress(Exception):
                await self._memory.add_message(conversation_id, "assistant", error_msg)
            yield StreamChunk(delta=error_msg, done=True)

    def _log_activity(self, category: str, action: str, summary: str,
                      details: dict | None = None, importance: str = "medium") -> None:
        """Log to the centralized activity logger if available."""
        if self._activity and hasattr(self._activity, "log"):
            try:
                self._activity.log(category, action, summary, details, importance)
            except Exception:
                pass

    async def _execute_tool(self, tool_name: str, tool_input: dict) -> dict:
        """Execute a tool call — handles built-in, registry, and MCP tools.

        Records a Decision with the active skill context so the user can
        trace back *why* this tool was called.
        """
        result: dict

        # ── contract pre-check (all modes) ────────────────────
        # Catches blocks BEFORE any execution branch so the tool loop
        # never wastes a round on a tool the contract refuses.  The
        # local-mode path had this; the standard path relied on
        # ToolExecutor.execute() which returns the same dict — but
        # the LLM saw it as an ambiguous error and retried.  Now the
        # result includes a `contract_blocked` flag the chat loop can
        # detect and break out immediately with a user-facing message.
        if self._registry and not tool_name.startswith("mcp_"):
            _tool = self._registry._tools.get(tool_name)
            if _tool and _tool.contract_action and self._registry._contract:
                _check = self._registry._contract.check(_tool.contract_action)
                if not _check.allowed and not _check.requires_confirmation:
                    self._log_activity(
                        "contract", "tool_blocked",
                        f"Contract blocked tool {tool_name}: {_check.reason}",
                        {"tool": tool_name, "action": _tool.contract_action},
                        importance="high",
                    )
                    return {
                        "error": f"Contract blocked: {_check.reason}",
                        "contract_blocked": True,
                    }

        # ── trust pre-check (autonomous actions only) ─────────
        # Trust can ESCALATE (require confirmation) or RELAX (auto-allow).
        # Runs after contract — contract blocks are absolute.
        # User-initiated calls (chat-* / http-* correlation) bypass.
        _trust_result = None
        if self._trust_service and self._registry and not tool_name.startswith("mcp_"):
            _t_tool = self._registry._tools.get(tool_name)
            _t_action = getattr(_t_tool, "contract_action", None) if _t_tool else None
            if _t_action:
                from agntspace.activity.decisions import current_correlation_id as _cur_cid
                _cid = _cur_cid()
                _is_auto = bool(_cid) and not _cid.startswith("chat-") and not _cid.startswith("http-")
                _proactivity = (
                    self._registry._contract.rules.proactivity
                    if self._registry._contract else "advisor"
                )
                _trust_result = self._trust_service.check_tool_trust(
                    _t_action, _proactivity, is_autonomous=_is_auto,
                )
                if not _trust_result.action_allowed:
                    self._log_activity(
                        "trust", "tool_blocked",
                        f"Trust blocked tool {tool_name}: {_trust_result.reason}",
                        {"tool": tool_name, "action": _t_action,
                         "domain": _trust_result.domain,
                         "effective_level": _trust_result.effective_level},
                        importance="high",
                    )
                    return {
                        "error": f"Trust blocked: {_trust_result.reason}",
                        "trust_blocked": True,
                    }
                if _trust_result.requires_confirmation:
                    # Only escalate if contract didn't already require confirmation
                    _contract_confirms = (
                        "_check" in dir()
                        and getattr(_check, "requires_confirmation", False)  # noqa: F821
                    )
                    if not _contract_confirms:
                        return {
                            "needs_confirmation": True,
                            "action": tool_name,
                            "reason": _trust_result.reason,
                            "trust_level": _trust_result.effective_level,
                        }

        # Track last tool's contract action for correction signal domain lookup
        if self._registry and not tool_name.startswith("mcp_"):
            _lt = self._registry._tools.get(tool_name)
            if _lt and getattr(_lt, "contract_action", None):
                self._last_tool_contract_action = _lt.contract_action

        # ── before_tool_call hook ──────────────────────────────
        # Plugins can veto the call (e.g. budget guard, rate limiter) or
        # rewrite tool_input. Fires AFTER contract gating — plugins can only
        # narrow permissions, never widen them.
        if self._hooks is not None:
            try:
                from agntspace.plugins.hooks import HookContext, HookName
                pre_ctx = HookContext(
                    hook=HookName.BEFORE_TOOL_CALL,
                    tool_name=tool_name,
                    tool_input=tool_input,
                )
                await self._hooks.fire(HookName.BEFORE_TOOL_CALL, pre_ctx)
                if pre_ctx.veto:
                    return {"error": f"Tool vetoed by plugin: {pre_ctx.veto_reason}"}
                tool_input = pre_ctx.tool_input  # handlers may have rewritten args
            except Exception:
                # Hook bus exceptions are non-fatal here — fail_closed semantics
                # are enforced inside HookBus.fire(), which converts handler
                # errors into a veto. Anything that escapes is a bug in the
                # bus itself, not a reason to break the agent loop.
                log.exception("hook bus error in before_tool_call")

        # MCP external tools (mcp_servername_toolname)
        if tool_name.startswith("mcp_") and self._registry and self._registry._mcp_client:
            try:
                result = await self._registry._mcp_client.call_tool(tool_name, tool_input)
            except Exception as e:
                log.exception("MCP tool execution failed: %s", tool_name)
                result = {"error": f"MCP tool failed: {e}"}
        # Local mode uses async handlers to avoid deadlocks
        elif self._local_mode:
            result = await self._execute_local_tool(tool_name, tool_input)
        # Standard sync execution — run in thread pool so blocking I/O
        # (IMAP, SMTP, file ops) doesn't freeze the event loop and
        # prevent WebSocket frames (tool status, thinking indicator)
        # from reaching the client.
        elif self._tool_executor:
            import asyncio
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None, self._tool_executor.execute, tool_name, tool_input,
            )
        else:
            result = {"error": f"No executor available for {tool_name}"}

        # ── after_tool_call hook ───────────────────────────────
        # Plugins can rewrite tool_result (redaction, transformation, caching).
        # fail_open: handler errors do not abort the call.
        if self._hooks is not None and isinstance(result, dict):
            try:
                from agntspace.plugins.hooks import HookContext, HookName
                post_ctx = HookContext(
                    hook=HookName.AFTER_TOOL_CALL,
                    tool_name=tool_name,
                    tool_input=tool_input,
                    tool_result=result,
                )
                await self._hooks.fire(HookName.AFTER_TOOL_CALL, post_ctx)
                if isinstance(post_ctx.tool_result, dict):
                    result = post_ctx.tool_result
            except Exception:
                log.exception("hook bus error in after_tool_call")

        # Record as a verifiable mutation in the current skill scope (if any).
        # An error dict still counts as a "real attempt" — only tools that
        # were never invoked are absent from the counter. This is what
        # Agent.invoke_skill uses to distinguish real work from narration.
        if isinstance(result, dict) and "error" not in result:
            try:
                from agntspace.activity.decisions import note_tool_call
                note_tool_call()
            except Exception:
                pass

        # Memory provenance window: if this was a memory/knowledge recall
        # tool, stash the returned entity/triple IDs so future tool calls
        # in the same turn can cite them in their decision record.
        _memory_tools = {
            "recall_memory", "deep_memory_recall",
            "query_memory_graph", "query_knowledge",
        }
        if tool_name in _memory_tools and isinstance(result, dict):
            try:
                refs = self._extract_memory_refs(result)
                if refs:
                    self._recent_memory_refs.extend(refs)
                    # Keep the window bounded
                    if len(self._recent_memory_refs) > 50:
                        self._recent_memory_refs = self._recent_memory_refs[-50:]
            except Exception:
                pass

        # Decision log — record WHY this tool was called
        if self._decisions:
            contract_action = ""
            contract_result = "allowed"
            if self._registry:
                tool = self._registry._tools.get(tool_name) if hasattr(self._registry, "_tools") else None
                if tool and getattr(tool, "contract_action", None):
                    contract_action = tool.contract_action
            if isinstance(result, dict) and "Contract blocked" in str(result.get("error", "")):
                contract_result = "blocked"
            if isinstance(result, dict) and result.get("trust_blocked"):
                contract_result = "trust_blocked"
            try:
                skills = self._active_skills() if hasattr(self, "_active_skills") else []
            except Exception:
                skills = []
            _tl = _trust_result.effective_level if _trust_result else ""
            _td = _trust_result.domain if _trust_result else ""
            try:
                await self._decisions.record(
                    actor="main",
                    action_type="tool",
                    action_target=tool_name,
                    contract_action=contract_action,
                    contract_result=contract_result,
                    triggered_by="chat_tool",
                    context_skills=skills,
                    context_memories=list(self._recent_memory_refs),
                    rationale=f"Tool {tool_name} invoked during chat",
                    details={"input_keys": sorted(tool_input.keys()) if isinstance(tool_input, dict) else []},
                    trust_level=_tl,
                    trust_domain=_td,
                )
            except Exception:
                log.debug("Decision log record failed for tool %s", tool_name, exc_info=True)

        return result

    # ── Artifact context (feedback loop) ──

    # Tools whose output creates a mutable artifact the user can refine.
    _ARTIFACT_TOOLS: frozenset[str] = frozenset({  # arch:deterministic — tool classification for artifact tracking
        "create_presentation", "generate_kb_presentation", "research_and_present",
        "update_presentation",
        "scrape_url", "research_scrape",
    })

    # How to extract artifact info from each tool's result dict.
    @staticmethod
    def _extract_artifact(tool_name: str, result: dict) -> dict | None:
        """Extract artifact metadata from a tool result, if it produced one."""
        if not isinstance(result, dict) or result.get("error"):
            return None

        path = result.get("path") or result.get("saved_to") or result.get("companion") or ""
        if not path:
            return None
        # Normalize path separators — Windows backslashes break path resolution
        path = path.replace("\\", "/")

        # Infer type from tool name or file extension
        if "presentation" in tool_name or path.endswith(".pptx"):
            atype = "presentation"
        elif "scrape" in tool_name or "research" in tool_name:
            atype = "source"
        else:
            atype = "document"

        meta = {}
        for key in ("slides", "scraped", "kb", "project", "topic", "message"):
            if key in result:
                meta[key] = result[key]

        return {"type": atype, "path": path, "metadata": meta}

    async def _capture_artifact(
        self, conversation_id: str, tool_name: str, result: dict,
    ) -> None:
        """If a tool produced an artifact, set it as the in-focus artifact."""
        if tool_name not in self._ARTIFACT_TOOLS:
            return
        artifact = self._extract_artifact(tool_name, result)
        if artifact and self._memory:
            await self._memory.set_artifact(
                conversation_id,
                artifact["type"],
                artifact["path"],
                artifact.get("metadata"),
            )

    async def _apply_reply_hook(self, text: str, conversation_id: str) -> str:
        """Run the before_agent_reply plugin hook chain on `text`.

        Returns the (possibly mutated) reply text. fail_closed: a handler
        exception or explicit veto replaces the reply with a stub message
        rather than letting tampered/incomplete content through.
        """
        if self._hooks is None or not text:
            return text
        try:
            from agntspace.plugins.hooks import HookContext, HookName
            ctx = HookContext(
                hook=HookName.BEFORE_AGENT_REPLY,
                reply_text=text,
                conversation_id=conversation_id,
            )
            await self._hooks.fire(HookName.BEFORE_AGENT_REPLY, ctx)
            if ctx.veto:
                log.info("reply vetoed by plugin %s: %s", ctx.plugin_name, ctx.veto_reason)
                return "⚠ Reply withheld by plugin policy."
            return ctx.reply_text or text
        except Exception:
            log.exception("hook bus error in before_agent_reply")
            return text

    def _extract_memory_refs(self, result: dict) -> list[str]:
        """Pull entity/triple/memory IDs from a memory-recall tool result.

        Heuristic: looks for common keys across our memory tools — `entities`,
        `triples`, `results`, `hits`, `articles`, `memories` — and extracts
        a best-guess identifier from each item (slug, id, path, or name).
        Returns a deduped list, capped at 20 refs.
        """
        refs: list[str] = []
        if not isinstance(result, dict):
            return refs

        def _take(item: object) -> str | None:
            if isinstance(item, str):
                return item
            if isinstance(item, dict):
                for key in ("slug", "id", "path", "entity", "subject", "name", "title"):
                    val = item.get(key)
                    if isinstance(val, str) and val:
                        return val
            return None

        for key in ("entities", "triples", "results", "hits", "articles", "memories"):
            items = result.get(key)
            if isinstance(items, list):
                for item in items[:20]:
                    ref = _take(item)
                    if ref and ref not in refs:
                        refs.append(ref)
                        if len(refs) >= 20:
                            return refs
        return refs

    def _active_skills(self) -> list[str]:
        """Return the names of skills currently loaded into the system prompt.

        Used by the decision logger to capture which skills were in force when
        an action was taken. Returns empty list if no loader is available.
        """
        if not self._skill_loader:
            return []
        try:
            return [s.name for s in self._skill_loader.get_active_skills()]  # type: ignore[attr-defined]
        except Exception:
            try:
                return sorted(self._skill_loader._skills.keys())  # type: ignore[attr-defined]
            except Exception:
                return []

    async def _execute_local_tool(self, tool_name: str, tool_input: dict) -> dict:
        """Execute a tool in local mode. Tries registry first, then tool executor.

        Uses async_handler when available (we're already in an event loop,
        so sync wrappers that call run_until_complete would deadlock).
        """
        # Registry has dynamically registered tools (run_wiki_job, etc.)
        if self._registry:
            tool = self._registry._tools.get(tool_name)
            if tool:
                # Contract check
                if tool.contract_action and self._registry._contract:
                    check = self._registry._contract.check(tool.contract_action)
                    if not check.allowed:
                        return {"error": f"Contract blocked: {check.reason}"}

                    # Prompt injection defense: if the current correlation
                    # scope contains untrusted content (scraped web, channel
                    # message, MCP result) AND this tool call is destructive
                    # (writes, sends, deletes), escalate to user confirmation
                    # even if the contract would normally allow it. This is
                    # the "if the LLM was tricked, at least the user sees a
                    # confirmation dialog" last-resort defense.
                    # See docs/threat-model.md §9.1 mitigation #4.
                    _DESTRUCTIVE_ACTIONS = frozenset({
                        "write_vault", "send_email", "send_message",
                        "delete_vault_file", "reset_wiki", "modify_wiki",
                        "manage_channels", "create_task", "modify_project",
                    })
                    try:
                        from agntspace.security.prompt_guard import is_scope_untrusted
                        if (
                            is_scope_untrusted()
                            and tool.contract_action in _DESTRUCTIVE_ACTIONS
                            and not check.requires_confirmation
                        ):
                            log.warning(
                                "Untrusted content in scope — escalating %s to confirmation",
                                tool.contract_action,
                            )
                            return {
                                "error": (
                                    f"Action '{tool.contract_action}' requires confirmation "
                                    f"because this conversation contains untrusted external "
                                    f"content (web scraping, channel message, or MCP result). "
                                    f"Please confirm you want to proceed."
                                ),
                                "requires_confirmation": True,
                                "reason": "untrusted_content_escalation",
                            }
                    except Exception:
                        pass  # Non-fatal: defense-in-depth, not gating
                # Prefer async handler (avoids run_until_complete deadlock)
                try:
                    if tool.async_handler:
                        return await tool.async_handler(tool_input)
                    return tool.handler(tool_input)
                except Exception as e:
                    log.exception("Local tool execution failed: %s", tool_name)
                    return {"error": str(e)}

        # Fall back to built-in tool executor
        if self._tool_executor:
            return self._tool_executor.execute(tool_name, tool_input)
        return {"error": f"No executor available for {tool_name}"}

    def _load_local_intents(self) -> list[dict]:
        """Load intent patterns from the local-intents skill config."""
        if hasattr(self, "_local_intents_cache"):
            return self._local_intents_cache

        import yaml

        intents = []
        # Search skills directories for local-intents config
        if self._skill_loader:
            skills_dir = self._skill_loader._skills_dir
            config_path = skills_dir / "_meta" / "local-intents" / "config" / "intents.yaml"
            if config_path.is_file():
                try:
                    with open(config_path) as f:
                        intents = yaml.safe_load(f) or []
                    log.info("Loaded %d local intents from %s", len(intents), config_path)
                except Exception:
                    log.warning("Failed to load local intents config", exc_info=True)

        self._local_intents_cache = intents
        return intents

    _AFFIRMATIVE_RE = re.compile(
        r"^(yes|yeah|yep|yup|sure|ok|okay|go ahead|do it|please|please do|"
        r"absolutely|definitely|of course|go for it|let'?s do it|affirmative)\.?!?$",
        re.IGNORECASE,
    )

    def _match_local_intent(
        self, message: str, last_assistant: str | None = None,
    ) -> tuple[str, dict] | None:
        """Match user message to a tool call using skill-defined intent patterns.

        Returns (tool_name, tool_input) or None if no match.
        Patterns are loaded from skills/_meta/local-intents/config/intents.yaml.

        When the user sends an affirmative follow-up ("yes", "do it", etc.)
        AND the last assistant message offered to do something, we match
        the *assistant's* text against intents. This handles the common
        pattern: agent asks "would you like me to check email?" → user "yes".
        """
        import re as _re

        msg = message.lower().strip()
        intents = self._load_local_intents()

        for intent in intents:
            patterns = intent.get("patterns", [])
            for pattern in patterns:
                if _re.search(pattern, msg, _re.IGNORECASE):
                    tool = intent["tool"]
                    params = dict(intent.get("params", {}))

                    # Extract dynamic parameter if configured
                    extract = intent.get("param_extract")
                    param_key = intent.get("param_key")
                    if extract and param_key:
                        m = _re.search(extract, msg, _re.IGNORECASE)
                        if m:
                            params[param_key] = m.group(1).strip() if m.lastindex else msg

                    # Support multiple extracts (param_extracts: [{pattern, key}])
                    for extra in intent.get("param_extracts", []):
                        ep = extra.get("pattern")
                        ek = extra.get("key")
                        if ep and ek:
                            em = _re.search(ep, msg, _re.IGNORECASE)
                            if em:
                                params[ek] = em.group(1).strip() if em.lastindex else ""

                    return (tool, params)

        # Affirmative follow-up: match the assistant's offer against intents
        if last_assistant and self._AFFIRMATIVE_RE.match(msg):
            for intent in intents:
                for pattern in intent.get("patterns", []):
                    if _re.search(pattern, last_assistant.lower(), _re.IGNORECASE):
                        log.info("Affirmative follow-up matched intent %s from assistant context",
                                 intent["name"])
                        return (intent["tool"], dict(intent.get("params", {})))

        return None

    async def _record_cost(
        self, input_tokens: int, output_tokens: int,
        conversation_id: str | None = None, action: str = "chat",
        model: str | None = None,
        cache_read_tokens: int = 0, cache_write_tokens: int = 0,
        provider_cost: float | None = None,
        goal_id: str | None = None,
    ) -> None:
        """Record token cost if cost tracker is available."""
        if not self._cost_tracker:
            return
        try:
            # Auto-inherit goal_id from contextvar when not explicitly passed
            if not goal_id:
                from agntspace.activity.decisions import current_goal_id
                goal_id = current_goal_id() or None
            actual_model = model or getattr(self._llm, "_model", "unknown")
            await self._cost_tracker.record(
                model=actual_model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                conversation_id=conversation_id,
                action=action,
                cache_read_tokens=cache_read_tokens,
                cache_write_tokens=cache_write_tokens,
                provider_cost=provider_cost,
                goal_id=goal_id,
            )
        except Exception:
            pass

    async def _check_budget(self) -> None:
        """Pre-flight budget gate.  Raises BudgetExceededError when over budget."""
        if not self._cost_tracker:
            return
        await self._cost_tracker.check_budget_or_raise()

    @staticmethod
    def _is_junk_response(text: str) -> bool:
        """Detect junk JSON that small models output instead of real content.

        Local models (especially small ones) sometimes emit raw tool call JSON,
        schema definitions, or empty objects instead of following instructions.
        """
        if not text or not text.strip():
            return True
        stripped = text.strip()
        # Raw JSON object (tool call, schema, empty)
        if stripped.startswith("{") and stripped.endswith("}"):
            if any(k in stripped for k in ('"function"', '"type":', '"$schema"', '"name":', '"parameters"', '"tool_code"', '"tool_name"')):
                return True
            if len(stripped) < 20:  # e.g. {} or {"type": "text"}
                return True
        # JSON array of tool calls
        if stripped.startswith("[") and '"function"' in stripped:
            return True
        return False

    async def _record_pulse(self, pulse_type: str, details: str | None = None) -> None:
        """Record agent activity as a pulse on the cardiogram."""
        if self._heartbeat:
            try:
                await self._heartbeat.record_pulse(pulse_type, details)
            except Exception:
                pass

    async def _extract_entities(self, message: str, is_user: bool = True) -> None:
        """Extract entities and triples from messages in real-time.

        User messages: authority=explicit (user stated it)
        Assistant messages: authority=system (agent synthesized it)
        Fast regex runs always. LLM triple extraction for 50+ word messages.
        """
        if not self._memory_engine:
            return
        try:
            links = await self._memory_engine.extract_from_conversation(message, is_user=is_user)
            if links:
                log.debug("Entities extracted (%s): %s",
                          "user" if is_user else "assistant", ", ".join(links))
        except Exception:
            log.debug("Entity extraction failed", exc_info=True)

    def _check_journal_candidate(self, message: str) -> None:
        """Check if a message is thinking-out-loud and flag it for journaling."""
        if not self._journal:
            return
        from agntspace.journal.service import JournalService

        if JournalService.is_thinking_out_loud(message):
            log.info("Thinking-out-loud detected: %s...", message[:60])
            # The agent's system prompt tells it to ask "Save to journal?"
            # Actual saving happens when user confirms via the journal API

    def _check_correction_signal(self, user_text: str) -> None:
        """Scan user message for correction patterns that feed trust.

        When the user says "no", "wrong", "fix this", etc., this is an
        implicit negative trust signal for the domain of the last tool call.
        Patterns are loaded from signals.yaml (Rule #12).
        """
        if not self._trust_service:
            return
        try:
            from agntspace.trust.service import detect_correction, domain_for_action
            result = detect_correction(user_text)
            if not result:
                return
            rating, weight = result
            # Find the domain of the last tool call in this conversation
            domain = "general"
            if hasattr(self, "_last_tool_contract_action") and self._last_tool_contract_action:
                domain = domain_for_action(self._last_tool_contract_action)
            self._trust_service.record_feedback(domain, rating, weight=weight)
            log.debug("Trust correction signal: %s (%.1f) for domain '%s'", rating, weight, domain)
        except Exception:
            log.debug("Correction signal check failed", exc_info=True)

    # ─────────────────────────────────────────────────────────────────
    # Agent-mediated work primitive (Rule #9 / #17)
    # ─────────────────────────────────────────────────────────────────
    #
    # Every non-chat mutating flow (watcher, heartbeat, daily cycle, cron,
    # webhook, work queue handler, etc.) routes through ``invoke_skill``
    # instead of calling a service method directly. This gives each flow:
    #
    #   1. A correlation scope prefixed with the skill name → visible in
    #      /decisions as its own causal chain.
    #   2. Contract gating via the dispatched subagent's tool grants and
    #      the global ContractEnforcer.
    #   3. A mutation counter that verifies real work actually happened —
    #      a hallucinated "I ingested the files!" with no tool calls or
    #      vault writes gets flagged as SkillZeroEffect.
    #   4. A structured outcome the caller can log, re-queue, or surface
    #      in an action plan item for SkillSchool / the tuner.
    #
    # Callers who hit ``SkillZeroEffect`` should enqueue retry through
    # the persistent work queue — never silently fall back. The whole
    # point of this primitive is that silent fallbacks obscure real
    # failure modes of the current LLM and block the learning loop.

    async def invoke_skill(
        self,
        skill_name: str,
        args: dict | None = None,
        *,
        agent_name: str = "librarian",
        caller: str = "system",
        task_override: str | None = None,
    ) -> SkillOutcome:
        """Run a skill through the full agent pipeline and verify effect.

        Args:
            skill_name: The skill SKILL.md name (e.g. ``kb-ingest``). Used
                only for correlation scope + decision logging metadata —
                the actual tools the subagent may call come from the
                subagent's own skill/tier grants.
            args: Arguments describing the work unit, e.g. ``{"slug": "general"}``.
                Serialized into the dispatched task text.
            agent_name: Which specialist subagent runs the skill. Defaults
                to ``librarian`` because Stage 1 migrates the KB ingest
                watcher path. Callers for other skills (memory, reflection,
                research) pass the matching specialist explicitly.
            caller: Short identifier for the upstream caller (``watcher``,
                ``heartbeat``, ``cron``, ``webhook``). Surfaced in the
                decision record's ``triggered_by`` field so the /decisions
                page shows origin.
            task_override: Full task string, used when callers want to
                pass a pre-built prompt. When None, ``args`` is rendered
                into a minimal JSON-ish task body.

        Returns:
            SkillOutcome with the verdict + counter snapshot + the
            subagent's narrative reply. Never returns a silent failure.

        Raises:
            SkillZeroEffect: When the dispatch completed but nothing the
                skill claimed to do actually happened — zero tool calls,
                zero vault writes, zero triples added. The caller MUST
                re-queue (work queue + action plan item) instead of
                trusting the narrative.
            ValueError: When the target agent or skill is unknown.
        """
        from agntspace.activity.decisions import (
            correlation_scope,
            current_correlation_id,
            mutation_scope,
            new_correlation_id,
        )

        _args = dict(args or {})
        task = task_override or _build_skill_task(skill_name, _args)

        # Inherit the outer scope if one already exists (e.g. chat turn
        # that called this via a tool), otherwise start a fresh
        # skill-<name> chain so the /decisions timeline shows it as a
        # first-class causal chain.
        _existing_id = current_correlation_id()
        _corr_ctx = correlation_scope(
            _existing_id or new_correlation_id(f"skill-{skill_name}"),
        )

        with _corr_ctx, mutation_scope() as counter:
            # Log the intent INSIDE the scope so the event inherits
            # the correlation id — the /decisions chain view needs
            # every event in one batch to share one id.
            self._log_activity(
                "skill", "skill_invoked",
                f"Invoked skill {skill_name} via {agent_name} (caller={caller})",
                {"skill": skill_name, "agent": agent_name, "caller": caller, "args": _args},
                importance="low",
            )
            # Dispatch through the orchestrator so contract gating, tool
            # filtering, and the decision log all fire automatically.
            if self._orchestrator is None:
                raise ValueError(
                    "Agent.invoke_skill requires an Orchestrator — "
                    "this is a programming bug, main.py should wire it",
                )
            try:
                result = await self._orchestrator.dispatch(
                    agent_name=agent_name,
                    task=task,
                    context=(
                        f"You were invoked by {caller} to run the "
                        f"'{skill_name}' skill. Call real tools to do the "
                        f"work. Do not claim success without tool calls."
                    ),
                    skill_scope=skill_name,
                )
            except Exception as exc:
                outcome = SkillOutcome(
                    skill=skill_name,
                    agent=agent_name,
                    caller=caller,
                    correlation_id=current_correlation_id(),
                    succeeded=False,
                    mutations=counter.summary(),
                    content="",
                    error=f"{type(exc).__name__}: {exc}",
                )
                self._log_activity(
                    "skill", "skill_dispatch_failed",
                    f"Skill {skill_name} dispatch raised {type(exc).__name__}",
                    {"skill": skill_name, "agent": agent_name, "error": str(exc)[:500]},
                    importance="high",
                )
                if self._decisions is not None:
                    try:
                        await self._decisions.record(
                            actor=agent_name,
                            action_type="skill_invoke",
                            action_target=skill_name,
                            contract_result="failed",
                            triggered_by=caller,
                            rationale=f"Dispatch raised: {type(exc).__name__}",
                            details={"skill": skill_name, "error": str(exc)[:500], **outcome.mutations},
                        )
                    except Exception:
                        log.debug("decision record failed", exc_info=True)
                raise
            # At this point the dispatch returned — now verify the
            # mutation counter actually moved. A dispatch that said
            # "done!" with zero effect is the exact failure mode that
            # the pre-invoke_skill architecture silently tolerated.
            mutations = counter.summary()
            zero_effect = counter.is_zero_effect()
            outcome = SkillOutcome(
                skill=skill_name,
                agent=agent_name,
                caller=caller,
                correlation_id=current_correlation_id(),
                succeeded=not zero_effect,
                mutations=mutations,
                content=getattr(result, "content", "") or "",
                error=None if not zero_effect else "skill_zero_effect",
            )

            # IMPORTANT: log + decision stay inside the correlation
            # scope so their correlation_id is inherited automatically.
            # Moving them outside the `with` block would produce events
            # with empty correlation_id — breaking the /decisions chain
            # view and the regression tests that assert one id per
            # batch.
            if outcome.succeeded:
                self._log_activity(
                    "skill", "skill_completed",
                    f"{skill_name} completed via {agent_name}: {mutations}",
                    {"skill": skill_name, "agent": agent_name, **mutations},
                    importance="medium",
                )
            else:
                self._log_activity(
                    "skill", "skill_zero_effect",
                    f"{skill_name} via {agent_name} produced no real mutations — re-queue",
                    {"skill": skill_name, "agent": agent_name, **mutations, "content": outcome.content[:500]},
                    importance="high",
                )
            if self._decisions is not None:
                try:
                    await self._decisions.record(
                        actor=agent_name,
                        action_type="skill_invoke",
                        action_target=skill_name,
                        contract_action="delegate_task",
                        contract_result="allowed" if outcome.succeeded else "zero_effect",
                        triggered_by=caller,
                        context_skills=[skill_name],
                        rationale=(
                            f"Skill {skill_name} produced {mutations['vault_writes']} writes, "
                            f"{mutations['tool_calls']} tools, {mutations['graph_triples']} triples"
                        ),
                        details={
                            "skill": skill_name,
                            "agent": agent_name,
                            "caller": caller,
                            "args": _args,
                            "mutations": mutations,
                            "succeeded": outcome.succeeded,
                        },
                    )
                except Exception:
                    log.debug("decision record failed for skill_invoke", exc_info=True)

        if not outcome.succeeded:
            raise SkillZeroEffect(
                skill=skill_name,
                agent=agent_name,
                caller=caller,
                mutations=mutations,
                content=outcome.content,
            )
        return outcome


# ─────────────────────────────────────────────────────────────────
# Supporting types for Agent.invoke_skill
# ─────────────────────────────────────────────────────────────────

from dataclasses import dataclass, field  # noqa: E402


@dataclass
class SkillOutcome:
    """Structured result from ``Agent.invoke_skill``.

    Callers inspect ``succeeded`` to decide whether to re-queue. The
    ``mutations`` dict gives concrete numbers that action plan items and
    SkillSchool can feed back into the learning loop.
    """

    skill: str
    agent: str
    caller: str
    correlation_id: str
    succeeded: bool
    mutations: dict = field(default_factory=dict)
    content: str = ""
    error: str | None = None


class SkillZeroEffect(Exception):
    """Raised when ``Agent.invoke_skill`` completed but verified zero
    effect — no vault writes, no tool calls, no graph triples.

    Callers (RawWatcher, heartbeat, cron, webhook handlers) must catch
    this and enqueue retry through the persistent work queue. Do NOT
    fall back to calling the service method directly — that defeats
    the whole point of routing through the agent.
    """

    def __init__(
        self,
        *,
        skill: str,
        agent: str,
        caller: str,
        mutations: dict,
        content: str = "",
    ) -> None:
        self.skill = skill
        self.agent = agent
        self.caller = caller
        self.mutations = mutations
        self.content = content
        super().__init__(
            f"SkillZeroEffect: {skill} via {agent} (caller={caller}) "
            f"produced no verifiable mutations — {mutations}. "
            f"Narrative: {content[:200]!r}",
        )


def _build_skill_task(skill_name: str, args: dict) -> str:
    """Render a minimal, unambiguous task message for a skill invocation.

    The subagent receives this as the user message. We keep it short,
    machine-parseable, and explicit about what's expected so small
    models have less room to improvise.
    """
    import json as _json

    try:
        args_json = _json.dumps(args, ensure_ascii=False, sort_keys=True)
    except Exception:
        args_json = str(args)
    return (
        f"Run skill `{skill_name}` with the following arguments:\n\n"
        f"{args_json}\n\n"
        "Use the tools you have been granted to do the actual work. "
        "Do not describe what you would do — DO it. Return a short "
        "factual summary of what was accomplished."
    )
