"""Skills and SkillSchool API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/skills", tags=["skills"])


class SkillUpdateRequest(BaseModel):
    content: str


class SkillCreateRequest(BaseModel):
    name: str
    title: str
    description: str
    category: str = "custom"
    triggers: list[str] = []
    instructions: str = ""
    author: str = "user"
    tools_granted: list[str] = []
    depends_on: list[str] = []
    priority: int = 0
    model_tier: str = ""
    examples: list[dict] = []
    output_format: str = ""


class SkillImportRequest(BaseModel):
    path: str
    category: str = "custom"


class SkillFileRequest(BaseModel):
    content: str


@router.get("")
async def list_skills(request: Request) -> list[dict]:
    """List all loaded skills."""
    skills = request.app.state.skills
    return skills.list_skills()


@router.post("/analyze")
async def analyze_patterns(request: Request) -> list[dict]:
    """Run SkillSchool pattern analysis on completed tasks."""
    skillschool = request.app.state.skillschool
    return await skillschool.analyze_patterns()


@router.post("/import")
async def import_skill(request: Request, body: SkillImportRequest) -> dict:
    """Import a skill from an external folder path.

    The folder must contain a SKILL.md file. The entire folder is copied
    into system/skills/{category}/{slug}/ and the skill loader is reloaded.
    """
    import re
    import shutil
    from pathlib import Path as P

    source = P(body.path).resolve()

    # --- Validate source ---
    if not source.is_dir():
        # Maybe they pointed at the SKILL.md file itself
        if source.is_file() and source.name == "SKILL.md":
            source = source.parent
        else:
            raise HTTPException(status_code=400, detail=f"Path is not a directory: {body.path}")

    skill_md = source / "SKILL.md"
    if not skill_md.is_file():
        raise HTTPException(status_code=400, detail="No SKILL.md found in the given path")

    # --- Parse SKILL.md to get the slug ---
    import frontmatter as fm

    try:
        post = fm.loads(skill_md.read_text(encoding="utf-8"))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Failed to parse SKILL.md: {exc}")

    meta = post.metadata
    name = meta.get("name", source.name)
    slug = re.sub(r"[^a-z0-9-]", "", str(name).lower().replace(" ", "-"))[:60]
    if not slug:
        slug = re.sub(r"[^a-z0-9-]", "", source.name.lower().replace(" ", "-"))[:60]
    if not slug:
        raise HTTPException(status_code=400, detail="Could not derive a valid skill slug")

    # --- Check for conflicts ---
    skills = request.app.state.skills
    existing = skills.get_skill(slug)
    if existing:
        raise HTTPException(
            status_code=409,
            detail=f"Skill '{slug}' already exists at {existing.path}. Rename or delete it first.",
        )

    # --- Copy into vault ---
    settings = request.app.state.settings
    dest = P(settings.vault_dir) / "agntspace" / "system" / "skills" / body.category / slug
    dest.mkdir(parents=True, exist_ok=True)

    # Copy all files from source into dest
    copied_files: list[str] = []
    for item in source.rglob("*"):
        if not item.is_file():
            continue
        rel = item.relative_to(source)
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, target)
        copied_files.append(str(rel).replace("\\", "/"))

    # --- Reload skill loader ---
    skills.load_all()

    loaded = skills.get_skill(slug)
    return {
        "status": "imported",
        "name": slug,
        "title": loaded.title if loaded else meta.get("title", slug),
        "category": body.category,
        "path": f"system/skills/{body.category}/{slug}/SKILL.md",
        "files_copied": len(copied_files),
        "files": copied_files,
    }


@router.get("/{skill_name}")
async def get_skill(request: Request, skill_name: str) -> dict:
    """Get a single skill's full content."""
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")
    return {
        "name": skill.name,
        "title": skill.title,
        "description": skill.description,
        "category": skill.category,
        "status": skill.status,
        "triggers": skill.triggers,
        "body": skill.body,
        "path": str(skill.path),
        "files": skill.files,
        "author": skill.author,
        "tools_granted": skill.tools_granted,
        "depends_on": skill.depends_on,
        "priority": skill.priority,
        "model_tier": skill.model_tier,
        "examples": skill.examples,
        "output_format": skill.output_format,
        "version": skill.version,
        "signature": skill.signature,
        "publisher": skill.publisher,
        "content_hash": skill.content_hash,
        "signature_valid": _signature_valid(skill),
        "verification": _verification(skill),
    }


def _signature_valid(skill) -> bool | None:  # noqa: ANN001
    """Back-compat thin wrapper over `verify_signature` returning bool|None."""
    from agntspace.skills.signing import verify_signature
    status, _ = verify_signature(
        getattr(skill, "body", "") or "",
        getattr(skill, "signature", "") or "",
    )
    if status == "valid":
        return True
    if status == "invalid":
        return False
    return None  # unsigned or unknown scheme


def _verification(skill) -> dict:  # noqa: ANN001
    """Full verification report for the skill (gap #8)."""
    from agntspace.skills.signing import skill_verification_result
    return skill_verification_result(skill)


@router.put("/{skill_name}")
async def update_skill(request: Request, skill_name: str, body: SkillUpdateRequest) -> dict:
    """Update a skill's raw content (frontmatter + body)."""
    settings = request.app.state.settings
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")

    from agntspace.vault.writer import VaultWriter

    writer = VaultWriter(settings.vault_dir)
    writer.write(f"system/skills/{skill.path}", body.content)
    skills.load_all()
    return {"status": "updated", "name": skill_name}


@router.post("/create")
async def create_skill(request: Request, body: SkillCreateRequest) -> dict:
    """Create a new custom skill."""
    import re

    settings = request.app.state.settings
    skills = request.app.state.skills

    slug = re.sub(r"[^a-z0-9-]", "", body.name.lower().replace(" ", "-"))[:60]
    if not slug:
        raise HTTPException(status_code=400, detail="Invalid skill name")

    # Build SKILL.md content
    triggers_yaml = "\n".join(f'  - "{t}"' for t in body.triggers) if body.triggers else '  - "' + slug + '"'
    tools_yaml = "\n".join(f'  - "{t}"' for t in body.tools_granted) if body.tools_granted else ""
    deps_yaml = "\n".join(f'  - "{d}"' for d in body.depends_on) if body.depends_on else ""

    # Build examples YAML
    examples_yaml = ""
    if body.examples:
        lines = []
        for ex in body.examples:
            lines.append(f'  - input: "{ex.get("input", "")}"')
            lines.append(f'    output: "{ex.get("output", "")}"')
        examples_yaml = "\n".join(lines)

    content = f"""---
name: {slug}
title: "{body.title}"
description: "{body.description}"
category: {body.category}
status: active
author: {body.author}
priority: {body.priority}
model_tier: "{body.model_tier}"
output_format: "{body.output_format}"
triggers:
{triggers_yaml}
tools_granted:
{tools_yaml}
depends_on:
{deps_yaml}
examples:
{examples_yaml}
---

## Instructions

{body.instructions or "Define the step-by-step instructions for this skill."}

## Rules

- Follow the user's preferences from PROFILE.md
- Check CONTRACT.md permissions before taking action
"""

    from agntspace.vault.writer import VaultWriter

    writer = VaultWriter(settings.vault_dir)
    path = f"system/skills/{body.category}/{slug}/SKILL.md"
    writer.write(path, content)
    skills.load_all()
    return {"status": "created", "name": slug, "path": path}


@router.get("/{skill_name}/files/{file_path:path}")
async def get_skill_file(request: Request, skill_name: str, file_path: str) -> dict:
    """Read an additional file from a skill folder (template, example, etc.)."""
    skills = request.app.state.skills
    content = skills.get_skill_file(skill_name, file_path)
    if content is None:
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")
    return {"path": file_path, "content": content}


@router.put("/{skill_name}/files/{file_path:path}")
async def update_skill_file(request: Request, skill_name: str, file_path: str, body: SkillFileRequest) -> dict:
    """Write an additional file to a skill folder."""
    settings = request.app.state.settings
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")

    from pathlib import Path as P

    skill_dir = P(skill.path).parent
    full_path = f"system/skills/{skill_dir}/{file_path}"

    from agntspace.vault.writer import VaultWriter

    writer = VaultWriter(settings.vault_dir)
    writer.write(full_path, body.content)
    skills.load_all()
    return {"status": "updated", "path": full_path}
