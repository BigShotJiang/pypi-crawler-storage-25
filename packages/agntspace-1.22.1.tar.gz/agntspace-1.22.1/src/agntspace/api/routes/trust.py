"""Trust API — Bayesian trust data, domain management, and explanations."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from agntspace.trust.service import (
    BetaTrustScore,
    _level_from_score,
    get_bayesian_config,
)

router = APIRouter(prefix="/trust", tags=["trust"])


class TrustLevelUpdate(BaseModel):
    domain: str
    level: str


class DomainAdd(BaseModel):
    domain: str
    level: str = "Advisor"


@router.get("")
async def get_trust_data(request: Request) -> dict:
    """Get structured trust data with Bayesian scores and change log."""
    trust = request.app.state.trust_service
    rows = trust.get_trust_data()
    changes = trust.get_recent_changes()
    cfg = get_bayesian_config()

    # Enrich each domain with effective score and path-to-next
    enriched = []
    for row in rows:
        score = trust._make_beta_score(row)  # noqa: SLF001
        hl = trust._half_life_for_domain(row["domain"])  # noqa: SLF001
        eff = score.effective_score(hl, trust._prior_mean())  # noqa: SLF001
        level = _level_from_score(eff, cfg.level_thresholds)
        enriched.append({
            **row,
            "score": round(score.mean, 4),
            "effective_score": round(eff, 4),
            "level": level,
        })

    return {
        "domains": enriched,
        "changes": changes[-20:],
        "levels": ["Observer", "Advisor", "Assistant", "Partner"],
        "level_thresholds": list(cfg.level_thresholds),
    }


@router.get("/explain/{domain}")
async def explain_trust(request: Request, domain: str) -> dict:
    """Detailed trust explanation for a domain — score, decay, path to next level."""
    trust = request.app.state.trust_service
    return trust.explain_domain(domain)


@router.put("/level")
async def update_trust_level(request: Request, body: TrustLevelUpdate) -> dict:
    """Manually set trust level for a domain (sets score to midpoint of target band)."""
    trust = request.app.state.trust_service
    if body.level not in ("Observer", "Advisor", "Assistant", "Partner"):
        raise HTTPException(status_code=400, detail=f"Invalid level: {body.level}")

    cfg = get_bayesian_config()
    rows = trust.get_trust_data()
    found = False
    for row in rows:
        if row["domain"].lower() == body.domain.lower():
            old = row.get("level", "Advisor")
            # Set alpha/beta to the migration values for the target level
            migration = cfg.migration.get(body.level, {"alpha": 3.7, "beta": 8.7})
            row["alpha"] = migration["alpha"]
            row["beta_param"] = migration["beta"]
            row["level"] = body.level
            from datetime import UTC, datetime
            row["last_updated"] = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
            found = True
            break

    if not found:
        raise HTTPException(status_code=404, detail=f"Domain not found: {body.domain}")

    trust._write_trust_table(rows)  # noqa: SLF001
    trust.invalidate_cache()
    return {"domain": body.domain, "old_level": old, "new_level": body.level}


@router.post("/domain")
async def add_domain(request: Request, body: DomainAdd) -> dict:
    """Add a new trust domain with the global prior."""
    trust = request.app.state.trust_service
    rows = trust.get_trust_data()

    for row in rows:
        if row["domain"].lower() == body.domain.lower():
            raise HTTPException(status_code=409, detail=f"Domain already exists: {body.domain}")

    cfg = get_bayesian_config()
    migration = cfg.migration.get(body.level, {"alpha": 3.7, "beta": 8.7})
    rows.append({
        "domain": body.domain,
        "agent": "",
        "level": body.level,
        "alpha": migration["alpha"],
        "beta_param": migration["beta"],
        "completed": 0,
        "good": 0,
        "needs_improvement": 0,
        "redo": 0,
        "last_updated": "",
    })
    trust._write_trust_table(rows)  # noqa: SLF001
    trust.invalidate_cache()
    return {"domain": body.domain, "level": body.level}


@router.delete("/domain/{domain}")
async def remove_domain(request: Request, domain: str) -> dict:
    """Remove a trust domain."""
    trust = request.app.state.trust_service
    rows = trust.get_trust_data()
    new_rows = [r for r in rows if r["domain"].lower() != domain.lower()]
    if len(new_rows) == len(rows):
        raise HTTPException(status_code=404, detail=f"Domain not found: {domain}")
    trust._write_trust_table(new_rows)  # noqa: SLF001
    trust.invalidate_cache()
    return {"domain": domain, "status": "removed"}
