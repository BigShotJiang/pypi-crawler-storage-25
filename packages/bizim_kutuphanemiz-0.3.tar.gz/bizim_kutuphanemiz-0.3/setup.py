from setuptools import setup, find_packages

setup(
    name='bizim_kutuphanemiz', 
    version='0.3',
    packages=find_packages(),
    description='Sevgilime özel doğum günü kütüphanesi',
    author='Didenur Sezen'
)