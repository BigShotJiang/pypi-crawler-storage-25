import math
from datetime import datetime
import time
import sys
import webbrowser
import os

# ==========================================
# 1. IMPORT ANINDA ÇALIŞACAK GİRİŞ EFEKTİ
# (Bu kısım "import" dendiği an ekrana basılır)
# ==========================================
print("\n[INFO] Belfort sunucularından (yani didoşşş ehehheh) bağlantı kuruluyor...")
print("[INFO] Kalbiniz güvenlik protokollerini başarıyla geçti! Didenur'un kalbine erişim sağlandı ehehehe")
print("[INFO] DİKKAT, bu çko önemli bi uyarıdır beyfendi! Lütfen şuandan itibaren karakterlere dikkatlice bakınız ki oluşturdukları emojileri fark ediniz..")
print("[INFO] Vee modül kullanıma hazır. Peki sen hazır mısınn???? ദ്ദി(˵ •̀ ᴗ - ˵ ) 💭 Seni çok seviyorum! ❤️\n")

# ==========================================
# 2. SABİT DEĞİŞKENLER (CONSTANTS)
# ==========================================
ASK_SEVIYESI = math.inf
GUNCEL_KONUM = "Belfort, Fransa ┈┈┈┈➤ İstanbul, Türkiye (Veri aktarımı sürüyor...)"
KAVUSMA_TARIHI = "3 Temmuz 2026"

# ==========================================
# 3. ÖZEL HATA SINIFLARI (CUSTOM EXCEPTIONS)
# ==========================================
class AyrilikHatasi(Exception):
    """Mesafeler çok uzadığında fırlatılan kritik sistem hatası."""
    def __init__(self, mesaj="Sistem hatası: Çok fazla özlem birikti ദ്ദി ༎ຶ‿༎ຶ )  Acil sarılma gerekiyor hemide aşırı acil !!!"):
        super().__init__(mesaj)

# ==========================================
# 4. ANA SINIF VE SİHİRLİ METOTLAR
# ==========================================

class Sevgilim:
    def __init__(self):
        self.durum = "Yunus Emre'ye çok aşık  ( ˶˘ ³˘) ♡♡♡♡"

    def tahmin_et_bakalim(self):
        return """
        Sencee şu an Fransa'da yurt odamda oturmuş ne düşünüyo olabilirim?
        Cevap: Tabii ki seni! Ve kavuştuğumuzda yanyana da çukk güselce kutlayacağımız doğum gününüüü...   જ⁀➴ ♡
        """

    def biraz_da_matematik_hediye_de_olsa_matematik_onemlidir(self, isim="Yunus Emre"):
        if isim.lower() in ["yunus emre", "yunus"]:
            return f"Didenur + {isim.title()} = Dünyanın yenilmez ikilisii ehehehe  (⸝⸝> ᴗ•⸝⸝)"
        else:
            return "Hata İşlemi: Hoşttt !!! Didenur sadece Yunus Emre ile toplanabilir!"

    def bnei_ne_kadar_sevionn(self, miktar="sonsuz"):
        if miktar == "sonsuz":
            return "Öncelikle, bnei sonsuz sevdiğin için tişikkür ederiimmm heheheee :)) Ben de snei çokkk sonsuz seviommm! Hem de aradaki binlerce kilometreye rağmen her gün daha da çokk.. ♡ ♾ ♡"
        else:
            return "Hata: Sevgi miktarı 'sonsuz'dan az olamaz(emir 🗡️🗡️), lütfen tekrar deneyin (yoksa 2828 gün boyunca triplenirsiniz una göre)"

    def buuciyan_opcuk_bombardimani(self):
        return """
             (っ˶ ˘ ᵕ˘)❤︎❤︎❤︎❤︎(ˆᵕ ˆ˶ς)
        Belfort'tan yola çıkan bissürü buuuciyan öpücük hedefe ulaşdııı!
        """

    def surprizzz(self):
        mesaj = """

               ꧁⎝ 𓆩༺✧༻𓆪 ⎠꧂

        🎉 İYİ Kİ DOĞDUN SEVGİLİMMMMM! 🎉

        Şu an sana sımsıkı sarılamadığımı, o mozaik pastadaki tek mumu beraber üfleyemediğimizi düşüyor olabilirsin
        ama ikimiz de biliyoruz ki bizim kalplerimiz hep sımsıkı sarılı, asla ayrılmaz. Aralarındaki mesafe fark
        etmeksizin o mumu birlikte üflerler. Umarım kendi ellerimle yazdığım bu kütüphaneyi keşfederken çok eğlenirsin ehehehe

        Seni çokkk seviyorummm canımın enn içiii.
        Yeni yaşın sana, bize , bolca yan yana olacağımız, mesafeleri sıfırlayacağımız harika günler getirsin inşallahh hehhee!
        """
        return mesaj

    def kac_gun_kalmiskine(self):
        bugun = datetime.now()
        kavusma = datetime(2026, 7, 3)
        kalan = (kavusma - bugun).days
        return f"  .ೃ࿔ ✈︎ *:･  3 Temmuz'daki uçağa binip yanına gelmeme şunun şurasında {kalan} gün kaldıkine! Sonraa ver elini biissürü birlikte güzelce geçireceğimiz datelerr ehehehe :))"

    def gercek_zamanli_opcuk_yukleniyo_hehee(self):
        import time
        import sys
        print("Zütlac'dan Surub'a özel paket hazırlanıyo hehehe...  (❀ˆᴗˆ)(•́ᴗ•̀✿)")
        print("Biraccık uzun süreblir malsef, lütfen sabırla beklein ━╬٨ـﮩﮩ❤٨ـﮩﮩـ╬━")
        for i in range(1, 6):
            time.sleep(2)
            print(f"%{i*20} yüklendi... " + "💋" * i)
        return "\nVeeee bombardıman tamamlandııı hehehe! (っ˶ ˘ ᵕ˘) ❤︎❤︎❤︎"

    def triplendin_hihh(self):
        return """
        ( ˘︹˘ ) Hıhhh!
        Şu an sna trib atıorum habern olsn(nokta). Gidip 47 sn duvarla bakışma sürecim başladı...
        Yani kodu ne kadar çalıştırırsan çalıştır cevap vermicem surub ok?
        """

    def quiz_vakktiii(self):
        import webbrowser
        print("Demek quiz için hazırsınn, o zaman göster bakalım hünerleriniii hehehee  ◝(ᵔᗜᵔ)◜ ")
        print("Tarayıcın açılıyor, lütfen bekleee... ⏳")
        time.sleep(2)
        webbrowser.open("https://kahoot.it/challenge/02694545?challenge-id=456402cb-7a4a-4622-86a9-60ca55bf40b1_1778762592860")
        return "Eeee quizini de başarıyla (umarım..) tamamladığına göree, ufaktan bu yolculuğun sonuna yaklaşmış oluyoruz  ദ്ദി ༎ຶ‿༎ຶ )"

    def masaustune_hediye_birak(self):
        import os
        
        kullanici = os.path.expanduser("~")
        # Önce OneDrive'ı, sonra diğerlerini denemesi için sırayı güncelledik. 
        # En sona da her ihtimale karşı 'bulunduğu klasörü' (getcwd) ekledik.
        olasi_yollar = [
            os.path.join(kullanici, "OneDrive", "Masaüstü"),
            os.path.join(kullanici, "OneDrive", "Desktop"),
            os.path.join(kullanici, "Desktop"),
            os.path.join(kullanici, "Masaüstü"),
            os.getcwd() 
        ]
        
        icerik = """
                  ⊹₊˚‧︵‿₊୨ᰔ୧₊‿︵‧˚₊⊹

                   ( ´･ ᵕ･)ﾉ(´ ᵕ `˶)

        TEBRİKLER SURUB BEYYY! BU KUPONLARI KAZANDINIZZ HEHEHE!
        
        Temmuz'da kavuştuğumuzda geçerli olacak özel haklarınız:
        🎫 1. KUPON: Sınırsız "Sımmsıkı Sarılma" Hakkı (süresi bitmezz hehehe)
        🎫 2. KUPON: 1 Adet "Zutlac'ın Tribini Anında İptal Etme" Hakkı (dikkatli kullan!)
        🎫 3. KUPON: İstediğin Bir Tatlıyı Bana Ismarlatma Hakkıı (hayır, benim dışımda bi tatlı seçmen lzm..)
        
        Seni çuukkk seviyorummm! 
        - Didoşun
        """
        
        basarili_yol = ""
        
        for yol in olasi_yollar:
            # Garanti olsun diye dosya isminden kalp emojisini kaldırdık
            deneme_yolu = os.path.join(yol, "SURUBA_MEKTUP.txt")
            try:
                with open(deneme_yolu, "w", encoding="utf-8") as dosya:
                    dosya.write(icerik)
                basarili_yol = deneme_yolu
                break # Dosya başarıyla oluştuysa döngüyü kır ve çık!
            except Exception:
                continue # Hata verirse pes etme, listedeki diğer yola geç
                
        print(f"\nHeyy, bilgisayarına bi baksanayhaaa... Oraya (tam olarak şuraya: {basarili_yol}) senin için minik bi sürpriz bıraktımkine hehehee 🎁\n")