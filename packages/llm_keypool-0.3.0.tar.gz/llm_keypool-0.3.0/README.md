# llm-aggregator 

Free-tier LLM key pool manager. Register API keys from multiple providers once - the aggregator round-robins across them, handles 429 cooldowns, and retries transparently. No paid API needed.

Exposes a CLI, a Textual TUI, and a LangChain drop-in (`AggregatorChat`).

**Roadmap:** OpenAI-compatible local proxy server (`llm-aggregator proxy`) - point any agent at `http://localhost:8000/v1`, llm-keypool handles routing and rotation transparently. Session affinity ensures consistent provider within a conversation.

---

## Screenshots

![Keys tab](docs/screenshots/home.jpg)

![Add Key tab](docs/screenshots/add_key.jpg)

---

## What it does

- **Multi-provider pooling** - pool keys across Groq, Cerebras, Mistral, OpenRouter, SambaNova, and more
- **Automatic rotation** - round-robin across keys, rotates every N requests (default: 5)
- **429 handling** - on rate limit, key enters cooldown; next call retries a different key automatically
- **Think-token stripping** - removes `<think>...</think>` from reasoning model outputs
- **Persistent state** - SQLite, WAL mode; rotation position and cooldowns survive restarts
- **LangSmith compatible** - works with LangChain tracing out of the box

Keys DB lives at: `~/.llm-aggregator/keys.db`

Override path: `export LLM_AGGREGATOR_DB=/custom/path/keys.db`

---

## Installation

**PyPI:** `llm-keypool`

```bash
# Recommended - with TUI
uv tool install "llm-keypool[gui]"

# Without TUI
uv tool install llm-keypool

# pip
pip install llm-keypool
```

If installing alongside mdcore (so mdcore can import it):

```bash
uv tool install --force "markdowncore-ai[gui]" --with llm-keypool
```

### Upgrading

```bash
uv tool upgrade llm-keypool
# re-add to mdcore environment too
uv tool install --force "markdowncore-ai[gui]" --with llm-keypool
```

---

## Quickstart

```bash
# Register keys (one-time)
llm-aggregator add groq gsk_... --model llama-3.3-70b-versatile --category general_purpose
llm-aggregator add cerebras csk_... --model llama-3.3-70b --category general_purpose

# Check status
llm-aggregator status

# Launch TUI
llm-aggregator gui
```

---

## CLI Reference

### `llm-aggregator status`

Show all registered keys with cooldown and usage info.

```
llm-aggregator status
```

```
 ID  Provider    Category          Model                       Active  Req Today  Cooldown Until
 1   groq        general_purpose   llama-3.3-70b-versatile     yes     42         -
 2   cerebras    general_purpose   llama-3.3-70b               yes     18         -
 3   mistral     general_purpose   mistral-small-latest        yes     0          2026-04-27T00:00:00
```

---

### `llm-aggregator add`

Register an API key for a provider.

```bash
llm-aggregator add <provider> <key> --model <model> --category <category>
```

| Flag | Default | Description |
|---|---|---|
| `--model` | provider default | Override the model used for this key |
| `--category` | `general_purpose` | Key pool category |

Examples:

```bash
llm-aggregator add groq gsk_...          --model llama-3.3-70b-versatile --category general_purpose
llm-aggregator add cerebras csk_...      --model llama-3.3-70b           --category general_purpose
llm-aggregator add mistral sk_...        --model mistral-small-latest     --category general_purpose
llm-aggregator add openrouter sk-or-...  --model meta-llama/llama-3.3-70b-instruct:free --category general_purpose
```

---

### `llm-aggregator deactivate`

Deactivate a revoked or expired key. Does not delete it.

```bash
llm-aggregator deactivate --id 3
```

---

### `llm-aggregator clear-cooldown`

Manually clear a key's cooldown after you've confirmed the quota has reset.

```bash
llm-aggregator clear-cooldown --id 2
```

---

### `llm-aggregator providers`

List all supported providers, their categories, default models, and OpenAI compatibility.

```bash
llm-aggregator providers
```

---

### `llm-aggregator gui`

Launch the Textual TUI. Requires `[gui]` extra.

```bash
llm-aggregator gui
```

Features: tabular key view, inline deactivate/clear-cooldown, add key form.

---

## Registering keys - free tier providers

All providers below have a free tier. No credit card required.

| Provider | Suggested model | Signup |
|---|---|---|
| Groq | `llama-3.3-70b-versatile` | https://console.groq.com/keys |
| Cerebras | `llama-3.3-70b` | https://cloud.cerebras.ai |
| Mistral | `mistral-small-latest` | https://console.mistral.ai/api-keys |
| OpenRouter | `meta-llama/llama-3.3-70b-instruct:free` | https://openrouter.ai/settings/keys |

Full provider details and rate limits: [PROVIDER_GUIDE.md](PROVIDER_GUIDE.md)

---

## LangChain integration

`AggregatorChat` is a `BaseChatModel` drop-in:

```python
from llm_aggregator import AggregatorChat

llm = AggregatorChat(
    category="general_purpose",
    max_tokens=4096,
    temperature=0.7,
    rotate_every=5,
)

response = llm.invoke("What is the capital of France?")
print(response.content)
print(response.response_metadata)
# {"provider": "groq", "model": "llama-3.3-70b-versatile", "tokens_used": 42}
```

Async:

```python
response = await llm.ainvoke("Explain async Python.")
```

Works in chains:

```python
from langchain_core.prompts import ChatPromptTemplate

chain = ChatPromptTemplate.from_template("Answer: {question}") | llm
result = chain.invoke({"question": "What is Python?"})
```

LangSmith tracing works automatically if `LANGCHAIN_TRACING_V2` and `LANGCHAIN_API_KEY` are set.

---

## Direct Python usage

```python
import asyncio, json
from llm_aggregator.key_store import KeyStore
from llm_aggregator.rotator import Rotator
from llm_aggregator.providers.dispatch import complete
from pathlib import Path

with open(Path(__file__).parent / "llm_aggregator/config/providers.json") as f:
    configs = json.load(f)["providers"]

rotator = Rotator(KeyStore(), configs, rotate_every=5)

async def ask(question: str) -> str:
    result, key_data = await complete(
        rotator,
        category="general_purpose",
        messages=[{"role": "user", "content": question}],
        max_tokens=1024,
    )
    if result.error:
        raise RuntimeError(result.error)
    print(f"[{key_data['provider']} / {key_data['model']}]")
    return result.text

print(asyncio.run(ask("What is 2 + 2?")))
```

---

## Cooldown behaviour per provider

Cooldown timestamps are derived from response headers where available, so the key is released at the earliest possible moment rather than a conservative guess.

| Provider | Source | Behaviour |
|---|---|---|
| **Groq** | `x-ratelimit-reset-requests` header | Exact reset duration parsed from the header (e.g. `1m26.4s`). On 429 with `retry-after`, uses that instead. |
| **Cerebras** | `x-ratelimit-remaining-requests-{minute,hour,day}` | Tiered: minute exhausted → 60s; hour exhausted → 3600s; day exhausted → next UTC midnight. |
| **Mistral** | `x-ratelimit-remaining-req-minute` | 60s rolling when per-minute quota hits zero. |
| **OpenRouter** | none (no headers returned) | Next UTC midnight (RPD is binding limit). |
| **SambaNova** | none | 65s rolling. |
| **Cohere** | none | First of next calendar month (monthly call cap). |
| **Cloudflare** | none | Next UTC midnight (daily neuron budget). |
| **Jina** | none | 65s rolling. |
| **HuggingFace** | none | 120s rolling. |

Header parsing was verified against live API responses. Providers without header support fall back to the `cooldown_fallback.strategy` field in `providers.json`, so the strategy is config-driven rather than hardcoded.

---

## Project structure

```
llm-aggregator/
- llm_aggregator/
  - cli.py               # Typer CLI (status, add, deactivate, clear-cooldown, providers, gui)
  - tui.py               # Textual TUI
  - key_store.py         # SQLite persistence (~/.llm-aggregator/keys.db)
  - rotator.py           # round-robin rotation + cooldown logic
  - langchain_wrapper.py # AggregatorChat (BaseChatModel)
  - providers/
    - dispatch.py        # retry loop, 429 handling, provider routing
    - headers.py         # rate-limit header parsing + per-provider cooldown extraction
    - openai_compat.py   # AsyncOpenAI client + think-token stripping
    - cohere.py
    - cloudflare.py
  - config/
    - providers.json     # provider metadata, limits, models, reset schedules
- PROVIDER_GUIDE.md      # signup URLs and rate limits per provider
- TODO.md                # known limitations and planned improvements
```
