from __future__ import annotations

import httpx

from anusara._contracts.agent_result import AgentResult
from anusara._registry.executable_definition import ExecutableDefinition
from anusara._registry.invocation_spec import RemoteHttpInvocationSpec
from anusara._runtime.http_retry_policy import HttpRetryPolicy
from anusara._runtime.worker_invocation import WorkerInvocationRequest


class RemoteHttpInvoker:
    """
    Invokes executables exposed via HTTP endpoints.
    """

    def __init__(self, retry_policy: HttpRetryPolicy | None = None) -> None:
        self._retry_policy = retry_policy or HttpRetryPolicy()

    async def invoke(
        self,
        definition: ExecutableDefinition,
        request: WorkerInvocationRequest,
    ) -> AgentResult:
        spec = definition.invocation

        if not isinstance(spec, RemoteHttpInvocationSpec):
            raise TypeError("Invalid invocation spec for RemoteHttpInvoker")

        payload = {
            "request_id": request.request_id,
            "node_id": request.node_id,
            "agent_id": request.agent_id,
            "attempt": request.attempt,
            "payload": request.payload,
            "metadata": request.metadata,
            "scenario": (
                request.scenario.to_dict() if request.scenario is not None else None
            ),
        }

        invocation_key = f"{request.request_id}:{request.node_id}:{request.attempt}"

        timeout_seconds = spec.timeout_ms / 1000.0

        async with httpx.AsyncClient(timeout=timeout_seconds) as client:
            response = await client.request(
                method=spec.method,
                url=spec.url,
                json=payload,
                headers={
                    "X-Anusara-Invocation-Key": invocation_key,
                },
            )

            if response.status_code >= 400:
                if self._is_retryable_status(response.status_code):
                    ...
                response.raise_for_status()

            data = response.json()

        if not isinstance(data, dict):
            raise TypeError("Remote worker response must be a JSON object")

        raw_success = data.get("success", False)
        if not isinstance(raw_success, bool):
            raise TypeError("Remote worker field 'success' must be a boolean")

        raw_output = data.get("output")
        raw_errors = data.get("errors", [])
        raw_confidence = data.get("confidence", 0.0)
        raw_metadata = data.get("metadata", {})

        if not isinstance(raw_errors, list) or not all(
            isinstance(e, str) for e in raw_errors
        ):
            raise TypeError("Remote worker field 'errors' must be a list[str]")

        if not isinstance(raw_confidence, (int, float)):
            raise TypeError("Remote worker field 'confidence' must be numeric")

        if not isinstance(raw_metadata, dict):
            raise TypeError("Remote worker field 'metadata' must be an object")

        return AgentResult(
            success=raw_success,
            output=raw_output,
            errors=list(raw_errors),
            confidence=float(raw_confidence),
            metadata=dict(raw_metadata),
        )

    def _is_retryable_exception(self, exc: Exception) -> bool:
        return isinstance(
            exc, (httpx.ConnectError, httpx.ConnectTimeout, httpx.ReadTimeout)
        )

    def _is_retryable_status(self, status_code: int) -> bool:
        return status_code in {429, 502, 503, 504}
