# cf_service_contracts

Shared Python service contracts, DTOs, and provider registry for Cogniflow packages.
