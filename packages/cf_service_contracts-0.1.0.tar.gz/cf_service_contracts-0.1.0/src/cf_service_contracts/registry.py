from __future__ import annotations

from importlib import metadata
from typing import Any, Callable


ProviderFactory = Callable[[], object]


class ProviderRegistry:
    def __init__(self) -> None:
        self._providers: dict[str, object] = {}
        self._factories: dict[str, ProviderFactory] = {}
        self._entry_points_loaded = False

    def clear(self) -> None:
        self._providers.clear()
        self._factories.clear()
        self._entry_points_loaded = False

    def register(self, key: str, provider: object) -> object:
        self._providers[str(key)] = provider
        return provider

    def register_factory(self, key: str, factory: ProviderFactory) -> None:
        self._factories[str(key)] = factory

    def _load_entry_points(self) -> None:
        if self._entry_points_loaded:
            return
        self._entry_points_loaded = True
        try:
            entry_points = metadata.entry_points(group="cogniflow.service_providers")
        except TypeError:
            entry_points = metadata.entry_points().select(group="cogniflow.service_providers")
        for entry_point in entry_points:
            key = str(entry_point.name)
            if key in self._providers or key in self._factories:
                continue

            def _factory(ep=entry_point):
                loaded = ep.load()
                return loaded() if callable(loaded) else loaded

            self._factories[key] = _factory

    def get(self, key: str) -> object | None:
        lookup = str(key)
        if lookup in self._providers:
            return self._providers[lookup]
        self._load_entry_points()
        factory = self._factories.get(lookup)
        if factory is None:
            return None
        provider = factory()
        self._providers[lookup] = provider
        return provider

    def require(self, key: str) -> object:
        provider = self.get(key)
        if provider is None:
            raise RuntimeError(f"Provider not registered for key '{key}'.")
        return provider


_REGISTRY = ProviderRegistry()


def get_registry() -> ProviderRegistry:
    return _REGISTRY


def clear_provider_registry() -> None:
    _REGISTRY.clear()


def register_provider(key: str, provider: object) -> object:
    return _REGISTRY.register(key, provider)


def get_provider(key: str) -> Any:
    return _REGISTRY.get(key)


def require_provider(key: str) -> Any:
    return _REGISTRY.require(key)
