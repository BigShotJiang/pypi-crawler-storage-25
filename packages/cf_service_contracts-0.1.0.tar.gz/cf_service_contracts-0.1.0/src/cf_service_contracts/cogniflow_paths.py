from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class CogniflowPaths:
    root: Path
    workspace: Path
    tools: Path
    cache: Path
    native_cache: Path
    native_env_file: Path


def resolve_cogniflow_root() -> Path:
    return (Path.home() / ".cogniflow").resolve()


def resolve_workspace_dir() -> Path:
    return (resolve_cogniflow_root() / "workspace").resolve()


def resolve_tools_dir() -> Path:
    return (resolve_cogniflow_root() / "tools").resolve()


def resolve_cache_dir() -> Path:
    return (resolve_cogniflow_root() / "cache").resolve()


def resolve_native_cache_dir() -> Path:
    return (resolve_cache_dir() / "native").resolve()


def resolve_native_env_file() -> Path:
    return (resolve_native_cache_dir() / "env.ps1").resolve()


def resolve_cogniflow_paths() -> CogniflowPaths:
    root = resolve_cogniflow_root()
    return CogniflowPaths(
        root=root,
        workspace=(root / "workspace").resolve(),
        tools=(root / "tools").resolve(),
        cache=(root / "cache").resolve(),
        native_cache=(root / "cache" / "native").resolve(),
        native_env_file=(root / "cache" / "native" / "env.ps1").resolve(),
    )


__all__ = [
    "CogniflowPaths",
    "resolve_cache_dir",
    "resolve_cogniflow_paths",
    "resolve_cogniflow_root",
    "resolve_native_cache_dir",
    "resolve_native_env_file",
    "resolve_tools_dir",
    "resolve_workspace_dir",
]
