from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol, TypedDict, runtime_checkable


class ProviderKey:
    DATAHIVE_RUNS = "datahive_runs"
    SEMANTICS_STORE = "semantics_store"
    SEMANTICS_RUNTIME = "semantics_runtime"
    ONTOLOGY_READ = "ontology_read"
    STEP_CATALOGUE = "step_catalogue"
    STEP_DISCOVERY = "step_discovery"
    PIPELINE_DRAFT = "pipeline_draft"
    PIPELINE_AUTHORING = "pipeline_authoring"
    PIPELINE_MANAGER = "pipeline_manager"
    PIPELINE_RUNTIME = "pipeline_runtime"
    WORKSPACE_STORE = "workspace_store"
    SETUP_BOOTSTRAP = "setup_bootstrap"
    SETUP_ORCHESTRATION = "setup_orchestration"
    ENGINE_RUNNER = "engine_runner"


class ValidationResult(TypedDict):
    conforms: bool
    report_text: str


class DataHiveRunEvidence(TypedDict):
    pipeline_root: str
    run_id: str
    manifest_path: str
    manifest_status: str
    latest_path: str
    parquet_files: list[str]


class SemanticsStoreRuntimeInfo(TypedDict):
    workspace_dir: str
    semantics_dir: str
    store_root: str
    tdb2_dir: str
    graphs_dir: str
    catalog_path: str
    dataset_state_path: str
    pid_file: str
    fuseki_base_url: str
    admin_url: str
    dataset_name: str
    dataset_url: str
    query_url: str
    update_url: str
    data_url: str
    dataset_exists: bool
    dataset_ready: bool
    dataset_sync_state: str
    runtime_source_mode: str
    dataset_synced_at: str | None
    synced_graph_count: int
    backend_kind: str
    service_managed: bool
    service_running: bool
    service_endpoint_reachable: bool
    service_health: str
    java_command: str | None
    fuseki_home: str | None
    fuseki_launcher: str | None


class SemanticsGraphRecord(TypedDict):
    graph_id: str
    graph_type: str
    package: str
    path: str | None
    context: dict[str, Any]
    graph_kind: str
    is_active: bool
    content_hash: str | None
    package_name: str | None
    package_version: str | None
    canonical_id: str | None
    compact_id: str | None
    local_id: str | None
    aliases: list[str]
    updated_at: str | None


class SemanticsRuntimeGraph(TypedDict):
    graph_id: str
    graph_type: str
    graph_kind: str
    aliases: list[str]
    nquads: str


class SemanticsRuntimeSnapshot(TypedDict):
    graph_ids: list[str]
    data_graph_ids: list[str]
    shapes_graph_ids: list[str]
    active_dataset_nquads: str
    active_data_graph_nquads: str
    shapes_graph_nquads: str


class SemanticsValidationResult(TypedDict):
    conforms: bool
    report_text: str
    report_nquads: str


@dataclass(frozen=True)
class EngineExecutionRequest:
    pipeline_path: str
    steps_paths: list[str]
    plugin_paths: list[str]
    workspace_dir: str
    runtime: dict[str, Any]


@runtime_checkable
class DataHiveRunsContractV1(Protocol):
    def resolve_data_hive_root(self, workspace_root: Any) -> Any: ...

    def find_latest_run(
        self, workspace_root: Any, pipeline_id: str
    ) -> DataHiveRunEvidence | None: ...

    def find_run(
        self, workspace_root: Any, pipeline_id: str, run_id: str
    ) -> DataHiveRunEvidence | None: ...


@runtime_checkable
class SemanticsStoreContractV1(Protocol):
    def resolve_workspace_dir(self) -> Any: ...

    def resolve_semantics_dir(self) -> Any: ...

    def resolve_dataset_name(self) -> str: ...

    def ensure_dataset(self) -> SemanticsStoreRuntimeInfo: ...

    def ensure_dataset_ready(self) -> SemanticsStoreRuntimeInfo: ...

    def get_service_status(self) -> SemanticsStoreRuntimeInfo: ...

    def rebuild_live_dataset_from_catalog(self) -> SemanticsStoreRuntimeInfo: ...

    def list_live_named_graphs(self) -> list[str]: ...

    def get_graph_from_dataset(self, graph_id: str) -> str: ...

    def put_graph_to_dataset(
        self,
        *,
        graph_id: str,
        nquads: str,
        graph_type: str = "",
        package: str = "",
        path: str | None = None,
        context: dict[str, Any] | None = None,
        graph_kind: str = "",
        is_active: bool = True,
        package_name: str | None = None,
        package_version: str | None = None,
        canonical_id: str | None = None,
        compact_id: str | None = None,
        local_id: str | None = None,
        aliases: list[str] | None = None,
    ) -> SemanticsGraphRecord: ...

    def delete_graph_from_dataset(
        self, graph_id: str, *, missing_ok: bool = True
    ) -> bool: ...

    def select(self, query: str, *, timeout_sec: float = 5.0) -> dict[str, object]: ...

    def construct(self, query: str, *, timeout_sec: float = 5.0) -> str: ...

    def ask(self, query: str, *, timeout_sec: float = 5.0) -> bool: ...

    def update(self, statement: str, *, timeout_sec: float = 5.0) -> None: ...

    def reset_dataset(self) -> SemanticsStoreRuntimeInfo: ...


@runtime_checkable
class SemanticsRuntimeContractV1(Protocol):
    def get_active_semantics_snapshot(
        self,
        *,
        include_shapes: bool = True,
        prefer_cached: bool = False,
    ) -> SemanticsRuntimeSnapshot: ...

    def get_shapes_graph_nquads(self) -> str: ...

    def list_step_graphs(self) -> list[SemanticsRuntimeGraph]: ...

    def get_referenced_step_graphs(
        self, step_ids: list[str]
    ) -> list[SemanticsRuntimeGraph]: ...

    def validate_pipeline_document(
        self,
        pipeline_doc: Any,
        *,
        include_referenced_steps: bool = True,
    ) -> SemanticsValidationResult: ...


@runtime_checkable
class OntologyReadContractV1(Protocol):
    @property
    def graph(self) -> Any: ...

    @property
    def shapes(self) -> Any: ...

    def get_semantics_update_token(self, *, refresh: bool = False) -> str: ...
    def get_graph_nquads(self) -> str: ...
    def get_active_dataset(self) -> Any: ...
    def get_active_graph(self, *, include_shapes: bool = True) -> Any: ...
    def get_quads_context(self) -> dict[str, str]: ...
    def list_active_graph_catalog(self) -> list[dict[str, Any]]: ...
    def query_quads(self, **filters: Any) -> list[dict[str, Any]]: ...
    def refresh_installed_step_packages(self, *, force: bool = False) -> list[str]: ...
    def discover_step_packages(self) -> list[Any]: ...
    def load_rdf_document(
        self, source: Any, *, label: str = "document"
    ) -> dict[str, Any]: ...


@runtime_checkable
class StepCatalogueContractV1(Protocol):
    def list_steps(self) -> list[dict[str, Any]]: ...
    def get_step_builder_options(self) -> dict[str, list[str]]: ...


@runtime_checkable
class PipelineDraftContractV1(Protocol):
    def list_pipelines(self) -> list[dict[str, Any]]: ...
    def get_pipeline(
        self, pipeline_id: str, rev: int | None = None
    ) -> dict[str, Any]: ...
    def save_pipeline(
        self,
        pipeline_id: str,
        pipeline_nquads: str,
        *,
        user: str | None = None,
        message: str | None = None,
    ) -> dict[str, Any]: ...
    def save_draft(
        self,
        pipeline_id: str,
        pipeline_nquads: str,
        *,
        user: str | None = None,
        message: str | None = None,
    ) -> dict[str, Any]: ...
    def load_draft(self, pipeline_id: str) -> dict[str, Any]: ...
    def discard_draft(self, pipeline_id: str) -> None: ...
    def validate_pipeline(self, pipeline_nquads: str) -> ValidationResult: ...


@runtime_checkable
class StepDiscoveryContractV1(Protocol):
    def get_processing_steps(self) -> list[dict[str, Any]]: ...
    def get_processing_steps_info_quads_bulk(
        self, step_ids: list[str] | None = None
    ) -> list[dict[str, Any]]: ...
    def get_step_info(self, step_id: str) -> dict[str, Any] | None: ...
    def get_step_packages(self) -> list[dict[str, Any]]: ...


@runtime_checkable
class PipelineAuthoringContractV1(Protocol):
    def quads_available(self) -> bool: ...
    def list_pipeline_rows(self) -> list[dict[str, Any]]: ...
    def list_pipeline_state_rows(self) -> list[dict[str, Any]]: ...
    def get_pipeline_revision(
        self,
        pipeline_id: str,
        rev: int | None = None,
        *,
        flatten: bool = True,
    ) -> dict[str, Any]: ...
    def get_pipeline_revision_nquads(
        self, pipeline_id: str, rev: int | None = None
    ) -> str: ...
    def get_pipeline_current_rev(self, pipeline_id: str) -> int: ...
    def get_pipeline_revision_source_path(
        self,
        pipeline_id: str,
        rev: int | None = None,
    ) -> Any: ...
    def commit_pipeline(
        self,
        pipeline_id: str,
        document: Any,
        *,
        user: str | None = None,
        message: str | None = None,
    ) -> int: ...
    def save_pipeline_draft(
        self,
        pipeline_id: str,
        quads_nq: str,
        *,
        user: str | None = None,
        message: str | None = None,
    ) -> None: ...
    def load_pipeline_draft(self, pipeline_id: str) -> str: ...
    def discard_pipeline_draft(self, pipeline_id: str) -> None: ...
    def pipeline_draft_exists(self, pipeline_id: str) -> bool: ...
    def list_pipeline_drafts(self) -> list[dict[str, Any]]: ...
    def validate_pipeline_document(self, pipeline_doc: Any) -> ValidationResult: ...


@runtime_checkable
class PipelineRuntimeContractV1(Protocol):
    def list_runtime_summaries(self) -> dict[str, Any]: ...
    def get_runtime(
        self, pipeline_id: str, *, selected_run_id: str | None = None
    ) -> dict[str, Any]: ...
    def get_pipeline_state(self, pipeline_id: str) -> dict[str, Any] | None: ...
    def get_runtime_context(self, pipeline_id: str) -> dict[str, Any]: ...
    def fetch_next_pending_event(
        self,
        *,
        pipeline_id: str | None = None,
        now: Any = None,
    ) -> dict[str, Any] | None: ...
    def defer_event(self, **kwargs: Any) -> dict[str, Any]: ...
    def consume_event_to_queued_run(self, **kwargs: Any) -> dict[str, Any] | None: ...
    def fetch_next_queued_run(
        self,
        *,
        pipeline_id: str | None = None,
        now: Any = None,
    ) -> dict[str, Any] | None: ...
    def count_running_runs(self, pipeline_id: str) -> int: ...
    def get_execution_context(self, run_id: str) -> dict[str, Any]: ...
    def update_pipeline_state(
        self, pipeline_id: str, **kwargs: Any
    ) -> dict[str, Any]: ...
    def mark_run_started(self, **kwargs: Any) -> dict[str, Any]: ...
    def mark_run_finished(self, **kwargs: Any) -> dict[str, Any]: ...
    def emit_event(self, **kwargs: Any) -> dict[str, Any]: ...


@runtime_checkable
class PipelineManagerContractV1(Protocol):
    def status(self, *, ensure_daemon: bool = False) -> dict[str, Any]: ...
    def ensure_daemon(self, *, timeout: float | None = None) -> dict[str, Any]: ...
    def start_daemon(self) -> dict[str, Any]: ...
    def stop_daemon(self) -> dict[str, Any]: ...
    def submit_run(
        self,
        pipeline_id: str,
        *,
        source: str = "cf_pipeline_manager",
        request_id: str | None = None,
        runner_overrides: dict[str, Any] | None = None,
        input_overrides: list[dict[str, Any]] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]: ...
    def snapshot(
        self,
        pipeline_id: str,
        *,
        selected_run_id: str | None = None,
    ) -> dict[str, Any]: ...
    def summaries(self) -> dict[str, Any]: ...
    def stop_run(
        self,
        pipeline_id: str,
        run_id: str,
        *,
        reason: str = "stopped_by_user",
    ) -> dict[str, Any]: ...
    def emit_event(
        self,
        *,
        pipeline_id: str,
        event_type: str,
        source: str = "external",
        payload: Any = None,
        source_event_id: str | None = None,
        dedupe_key: str | None = None,
    ) -> dict[str, Any]: ...
    def register_pipeline(self, pipeline_id: str, rev: int) -> dict[str, Any]: ...
    def purge_orphans(self) -> dict[str, Any]: ...


@runtime_checkable
class EngineRunnerContractV1(Protocol):
    def resolve_cf_pipeline_v2_executable(self) -> str: ...


@runtime_checkable
class WorkspaceStoreContractV1(Protocol):
    def resolve_semantics_dir(self) -> Any: ...
    def resolve_workspace_dir(self) -> Any: ...
    def resolve_named_store_path(
        self, kind: str, *, semantics_dir: Any = None
    ) -> Any: ...
    def resolve_workspace_store_paths(self, *, semantics_dir: Any = None) -> Any: ...
    def open_named(self, kind: str, *, semantics_dir: Any = None, read_only: bool): ...
    def open_path(self, path: Any, *, read_only: bool): ...
    @property
    def constraint_exception(self) -> type[Exception]: ...


@runtime_checkable
class SetupBootstrapContractV1(Protocol):
    def derive_pipeline_id_from_document(self, value: Any) -> str: ...
    def get_pipeline_revision_nquads(self, pipeline_id: str) -> str: ...
    def list_pipeline_state_rows(self) -> list[dict[str, Any]]: ...
    def commit_pipeline(
        self,
        pipeline_id: str,
        document: Any,
        *,
        user: str | None = None,
        message: str | None = None,
    ) -> int: ...


class SetupPlanRequest(TypedDict, total=False):
    repo_root: str | None
    manifest_path: str | None
    profile: str
    execution_mode: str
    editable: list[str]


class SetupInstallRequest(TypedDict, total=False):
    repo_root: str | None
    manifest_path: str | None
    profile: str
    execution_mode: str
    python_exe: str
    editable: list[str]
    wheel_only: bool
    clean: bool
    skip_native_deps: bool
    auto_install_missing_prereqs: bool
    skip_engine_build: bool
    skip_web_build: bool
    show_details: bool
    run_demo: bool | None
    dry_run: bool
    log_path: str | None
    event_path: str | None
    output: str | None


@runtime_checkable
class SetupOrchestrationContractV1(Protocol):
    def resolve_repo_root(self) -> str | None: ...
    def default_manifest_path(self) -> str: ...
    def plan_installation(self, request: SetupPlanRequest) -> dict[str, Any]: ...
    def diagnose_prerequisites(self) -> dict[str, Any]: ...
    def execute_install(self, request: SetupInstallRequest) -> dict[str, Any]: ...
