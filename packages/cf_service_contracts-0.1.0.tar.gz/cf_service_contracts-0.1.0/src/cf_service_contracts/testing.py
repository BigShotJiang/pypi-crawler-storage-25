from __future__ import annotations

from pathlib import Path
from typing import Any

from .contracts import DataHiveRunEvidence, DataHiveRunsContractV1, ProviderKey
from .registry import register_provider


class FakeDataHiveRunsProvider(DataHiveRunsContractV1):
    def resolve_data_hive_root(self, workspace_root: Any) -> Any:
        return Path(workspace_root).expanduser().resolve() / "data_hive"

    def find_latest_run(
        self, workspace_root: Any, pipeline_id: str
    ) -> DataHiveRunEvidence | None:
        return None

    def find_run(
        self, workspace_root: Any, pipeline_id: str, run_id: str
    ) -> DataHiveRunEvidence | None:
        return None


def register_datahive_runs_test_provider() -> None:
    register_provider(ProviderKey.DATAHIVE_RUNS, FakeDataHiveRunsProvider())