from __future__ import annotations

from typing import Any

import pytest

from cf_service_contracts import (
    DataHiveRunsContractV1,
    EngineRunnerContractV1,
    OntologyReadContractV1,
    PipelineAuthoringContractV1,
    PipelineManagerContractV1,
    ProviderKey,
    SemanticsRuntimeContractV1,
    SemanticsStoreContractV1,
    SetupOrchestrationContractV1,
    StepDiscoveryContractV1,
    clear_provider_registry,
    get_provider,
    register_provider,
    require_provider,
)


# ---------------------------------------------------------------------------
# Reusable contract conformance helpers
# ---------------------------------------------------------------------------

CONTRACT_KEY_PAIRS: list[tuple[str, type[Any]]] = [
    (ProviderKey.SEMANTICS_STORE, SemanticsStoreContractV1),
    (ProviderKey.SEMANTICS_RUNTIME, SemanticsRuntimeContractV1),
    (ProviderKey.ONTOLOGY_READ, OntologyReadContractV1),
    (ProviderKey.STEP_DISCOVERY, StepDiscoveryContractV1),
    (ProviderKey.PIPELINE_AUTHORING, PipelineAuthoringContractV1),
    (ProviderKey.PIPELINE_MANAGER, PipelineManagerContractV1),
    (ProviderKey.ENGINE_RUNNER, EngineRunnerContractV1),
    (ProviderKey.DATAHIVE_RUNS, DataHiveRunsContractV1),
    (ProviderKey.SETUP_ORCHESTRATION, SetupOrchestrationContractV1),
]


def _require_installed_provider(provider_key: str) -> Any:
    provider = get_provider(provider_key)
    if provider is None:
        pytest.skip(f"Provider {provider_key!r} is not installed in the isolated package environment")
    return provider


# ---------------------------------------------------------------------------
# Actual provider conformance
# ---------------------------------------------------------------------------

class TestActualProviderConformance:
    """Verify installed providers satisfy their declared contract protocols."""

    @pytest.mark.parametrize("provider_key,contract", CONTRACT_KEY_PAIRS)
    def test_provider_isinstance_of_contract(self, provider_key: str, contract: type[Any]) -> None:
        provider = _require_installed_provider(provider_key)
        assert isinstance(provider, contract), (
            f"Provider {provider_key!r} does not implement {contract.__name__}"
        )


class TestEngineRunnerContract:
    """Contract behavior tests for EngineRunnerContractV1."""

    def test_resolve_cf_pipeline_v2_executable_returns_str(self) -> None:
        provider = _require_installed_provider(ProviderKey.ENGINE_RUNNER)
        result = provider.resolve_cf_pipeline_v2_executable()
        assert isinstance(result, str)
        assert result.strip() != ""


class TestDataHiveRunsContract:
    """Contract behavior tests for DataHiveRunsContractV1."""

    def test_resolve_data_hive_root_returns_pathlike(self) -> None:
        provider = _require_installed_provider(ProviderKey.DATAHIVE_RUNS)
        result = provider.resolve_data_hive_root("/tmp/workspace")
        assert result is not None

    def test_find_latest_run_returns_evidence_or_none(self) -> None:
        provider = _require_installed_provider(ProviderKey.DATAHIVE_RUNS)
        result = provider.find_latest_run("/tmp/workspace", "nonexistent_pipeline")
        assert result is None

    def test_find_run_returns_evidence_or_none(self) -> None:
        provider = _require_installed_provider(ProviderKey.DATAHIVE_RUNS)
        result = provider.find_run("/tmp/workspace", "nonexistent_pipeline", "run_001")
        assert result is None


class TestSetupOrchestrationContract:
    """Contract behavior tests for SetupOrchestrationContractV1."""

    def test_resolve_repo_root_returns_str_or_none(self) -> None:
        provider = _require_installed_provider(ProviderKey.SETUP_ORCHESTRATION)
        result = provider.resolve_repo_root()
        assert result is None or isinstance(result, str)

    def test_default_manifest_path_returns_str(self) -> None:
        provider = _require_installed_provider(ProviderKey.SETUP_ORCHESTRATION)
        result = provider.default_manifest_path()
        assert isinstance(result, str)
        assert result.strip() != ""


class TestOntologyReadContract:
    """Contract behavior tests for OntologyReadContractV1."""

    def test_get_semantics_update_token_returns_str(self) -> None:
        provider = _require_installed_provider(ProviderKey.ONTOLOGY_READ)
        result = provider.get_semantics_update_token()
        assert isinstance(result, str)
        assert result.strip() != ""

    def test_get_graph_nquads_returns_str(self) -> None:
        provider = _require_installed_provider(ProviderKey.ONTOLOGY_READ)
        result = provider.get_graph_nquads()
        assert isinstance(result, str)

    def test_has_graph_and_shapes_properties(self) -> None:
        provider = _require_installed_provider(ProviderKey.ONTOLOGY_READ)
        assert hasattr(provider, "graph")
        assert hasattr(provider, "shapes")


class TestStepDiscoveryContract:
    """Contract behavior tests for StepDiscoveryContractV1."""

    def test_get_processing_steps_returns_list(self) -> None:
        provider = _require_installed_provider(ProviderKey.STEP_DISCOVERY)
        result = provider.get_processing_steps()
        assert isinstance(result, list)

    def test_get_step_packages_returns_list(self) -> None:
        provider = _require_installed_provider(ProviderKey.STEP_DISCOVERY)
        result = provider.get_step_packages()
        assert isinstance(result, list)

    def test_get_step_info_returns_dict_or_none(self) -> None:
        provider = _require_installed_provider(ProviderKey.STEP_DISCOVERY)
        result = provider.get_step_info("nonexistent_step")
        assert result is None or isinstance(result, dict)


class TestPipelineAuthoringContract:
    """Contract behavior tests for PipelineAuthoringContractV1."""

    def test_quads_available_returns_bool(self) -> None:
        provider = _require_installed_provider(ProviderKey.PIPELINE_AUTHORING)
        result = provider.quads_available()
        assert isinstance(result, bool)

    def test_list_pipeline_rows_returns_list(self) -> None:
        provider = _require_installed_provider(ProviderKey.PIPELINE_AUTHORING)
        result = provider.list_pipeline_rows()
        assert isinstance(result, list)

    def test_list_pipeline_state_rows_returns_list(self) -> None:
        provider = _require_installed_provider(ProviderKey.PIPELINE_AUTHORING)
        result = provider.list_pipeline_state_rows()
        assert isinstance(result, list)


class TestSemanticsStoreContract:
    """Contract behavior tests for SemanticsStoreContractV1."""

    def test_resolve_workspace_dir_returns_pathlike(self) -> None:
        provider = _require_installed_provider(ProviderKey.SEMANTICS_STORE)
        result = provider.resolve_workspace_dir()
        assert result is not None

    def test_resolve_semantics_dir_returns_pathlike(self) -> None:
        provider = _require_installed_provider(ProviderKey.SEMANTICS_STORE)
        result = provider.resolve_semantics_dir()
        assert result is not None

    def test_resolve_dataset_name_returns_str(self) -> None:
        provider = _require_installed_provider(ProviderKey.SEMANTICS_STORE)
        result = provider.resolve_dataset_name()
        assert isinstance(result, str)
        assert result.strip() != ""

    def test_list_live_named_graphs_returns_list_of_str(self) -> None:
        provider = _require_installed_provider(ProviderKey.SEMANTICS_STORE)
        result = provider.list_live_named_graphs()
        assert isinstance(result, list)


class TestSemanticsRuntimeContract:
    """Contract behavior tests for SemanticsRuntimeContractV1."""

    def test_get_shapes_graph_nquads_returns_str(self) -> None:
        provider = _require_installed_provider(ProviderKey.SEMANTICS_RUNTIME)
        result = provider.get_shapes_graph_nquads()
        assert isinstance(result, str)

    def test_list_step_graphs_returns_list(self) -> None:
        provider = _require_installed_provider(ProviderKey.SEMANTICS_RUNTIME)
        result = provider.list_step_graphs()
        assert isinstance(result, list)


class TestPipelineManagerContract:
    """Contract behavior tests for PipelineManagerContractV1."""

    def test_status_returns_dict(self) -> None:
        provider = _require_installed_provider(ProviderKey.PIPELINE_MANAGER)
        result = provider.status()
        assert isinstance(result, dict)


# ---------------------------------------------------------------------------
# Mock-provider conformance
# ---------------------------------------------------------------------------

class TestMockProviderConformance:
    """Verify minimal mock providers satisfy contract protocols."""

    def test_mock_engine_runner_isinstance(self) -> None:
        clear_provider_registry()

        class MockEngineRunner:
            def resolve_cf_pipeline_v2_executable(self) -> str:
                return "mock_cf_pipeline_v2"

        register_provider(ProviderKey.ENGINE_RUNNER, MockEngineRunner())
        provider = require_provider(ProviderKey.ENGINE_RUNNER)
        assert isinstance(provider, EngineRunnerContractV1)
        assert provider.resolve_cf_pipeline_v2_executable() == "mock_cf_pipeline_v2"

    def test_mock_datahive_runs_isinstance(self) -> None:
        clear_provider_registry()

        class MockDataHiveRuns:
            def resolve_data_hive_root(self, workspace_root: Any) -> Any:
                return f"{workspace_root}/data_hive"

            def find_latest_run(
                self, workspace_root: Any, pipeline_id: str
            ) -> None:
                return None

            def find_run(
                self, workspace_root: Any, pipeline_id: str, run_id: str
            ) -> None:
                return None

        register_provider(ProviderKey.DATAHIVE_RUNS, MockDataHiveRuns())
        provider = require_provider(ProviderKey.DATAHIVE_RUNS)
        assert isinstance(provider, DataHiveRunsContractV1)
        assert provider.resolve_data_hive_root("/ws") == "/ws/data_hive"

    def test_mock_step_discovery_isinstance(self) -> None:
        clear_provider_registry()

        class MockStepDiscovery:
            def get_processing_steps(self) -> list[dict[str, Any]]:
                return []

            def get_processing_steps_info_quads_bulk(
                self, step_ids: list[str] | None = None
            ) -> list[dict[str, Any]]:
                return []

            def get_step_info(self, step_id: str) -> dict[str, Any] | None:
                return None

            def get_step_packages(self) -> list[dict[str, Any]]:
                return []

        register_provider(ProviderKey.STEP_DISCOVERY, MockStepDiscovery())
        provider = require_provider(ProviderKey.STEP_DISCOVERY)
        assert isinstance(provider, StepDiscoveryContractV1)
        assert provider.get_processing_steps() == []

    def test_mock_setup_orchestration_isinstance(self) -> None:
        clear_provider_registry()

        class MockSetupOrchestration:
            def resolve_repo_root(self) -> str | None:
                return None

            def default_manifest_path(self) -> str:
                return "mock_manifest.toml"

            def plan_installation(self, request: Any) -> dict[str, Any]:
                return {}

            def diagnose_prerequisites(self) -> dict[str, Any]:
                return {}

            def execute_install(self, request: Any) -> dict[str, Any]:
                return {}

        register_provider(ProviderKey.SETUP_ORCHESTRATION, MockSetupOrchestration())
        provider = require_provider(ProviderKey.SETUP_ORCHESTRATION)
        assert isinstance(provider, SetupOrchestrationContractV1)
        assert provider.default_manifest_path() == "mock_manifest.toml"


# ---------------------------------------------------------------------------
# Missing-provider behavior
# ---------------------------------------------------------------------------

class TestMissingProviderBehavior:
    """Verify registry handles missing providers predictably."""

    def test_get_provider_returns_none_for_missing(self) -> None:
        clear_provider_registry()
        assert get_provider("missing_provider_for_contract_test") is None

    def test_require_provider_raises_for_missing(self) -> None:
        clear_provider_registry()
        with pytest.raises(RuntimeError, match="missing_provider_for_contract_test"):
            require_provider("missing_provider_for_contract_test")
