from __future__ import annotations

from cf_service_contracts import ProviderKey, clear_provider_registry, get_provider, register_provider, require_provider


def test_registry_round_trips_explicit_provider() -> None:
    clear_provider_registry()
    provider = object()
    register_provider(ProviderKey.ENGINE_RUNNER, provider)
    assert get_provider(ProviderKey.ENGINE_RUNNER) is provider
    assert require_provider(ProviderKey.ENGINE_RUNNER) is provider


def test_registry_missing_provider_raises() -> None:
    clear_provider_registry()
    try:
        require_provider("missing_provider_for_test")
    except RuntimeError as exc:
        assert "missing_provider_for_test" in str(exc)
    else:  # pragma: no cover
        raise AssertionError("missing provider should raise")


def test_registry_supports_typed_stub_usage() -> None:
    clear_provider_registry()

    class Stub:
        def resolve_cf_pipeline_v2_executable(self) -> str:
            return "cf_pipeline_v2"

    register_provider(ProviderKey.ENGINE_RUNNER, Stub())
    provider = require_provider(ProviderKey.ENGINE_RUNNER)
    assert provider.resolve_cf_pipeline_v2_executable() == "cf_pipeline_v2"


def test_registry_round_trips_pipeline_manager_stub() -> None:
    clear_provider_registry()

    class Stub:
        def ensure_daemon(self, *, timeout=None):
            return {"running": True, "timeout": timeout}

    register_provider(ProviderKey.PIPELINE_MANAGER, Stub())
    provider = require_provider(ProviderKey.PIPELINE_MANAGER)
    assert provider.ensure_daemon(timeout=5.0) == {"running": True, "timeout": 5.0}


def test_registry_round_trips_workspace_store_stub() -> None:
    clear_provider_registry()

    class Stub:
        def resolve_workspace_dir(self) -> str:
            return "workspace"

    register_provider(ProviderKey.WORKSPACE_STORE, Stub())
    provider = require_provider(ProviderKey.WORKSPACE_STORE)
    assert provider.resolve_workspace_dir() == "workspace"


def test_registry_round_trips_semantics_store_stub() -> None:
    clear_provider_registry()

    class Stub:
        def list_live_named_graphs(self) -> list[str]:
            return ["urn:graph:test"]

    register_provider(ProviderKey.SEMANTICS_STORE, Stub())
    provider = require_provider(ProviderKey.SEMANTICS_STORE)
    assert provider.list_live_named_graphs() == ["urn:graph:test"]


def test_registry_round_trips_step_discovery_stub() -> None:
    clear_provider_registry()

    class Stub:
        def get_processing_steps(self) -> list[dict[str, str]]:
            return [{"@id": "cf:step/demo"}]

    register_provider(ProviderKey.STEP_DISCOVERY, Stub())
    provider = require_provider(ProviderKey.STEP_DISCOVERY)
    assert provider.get_processing_steps() == [{"@id": "cf:step/demo"}]


def test_registry_round_trips_setup_bootstrap_stub() -> None:
    clear_provider_registry()

    class Stub:
        def derive_pipeline_id_from_document(self, value):
            return f"pipe:{value}"

    register_provider(ProviderKey.SETUP_BOOTSTRAP, Stub())
    provider = require_provider(ProviderKey.SETUP_BOOTSTRAP)
    assert provider.derive_pipeline_id_from_document("demo") == "pipe:demo"
