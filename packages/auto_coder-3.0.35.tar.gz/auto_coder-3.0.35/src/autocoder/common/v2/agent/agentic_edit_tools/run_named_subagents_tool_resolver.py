"""
Run Named Subagents Tool Resolver

运行 .autocoderagents 中预定义的命名子代理。支持 JSON/YAML 配置解析，
前台通过 SubagentClient + CLI_PROCESS 执行，后台通过共享 CLI argv 准备
+ execute_command_background + BackgroundProcessNotifier 执行。

实现了 resolve_stream()，在前台子代理执行期间向 TUI 推送进度信息。
"""

import json
import os
import typing
from typing import Any, Dict, Generator, List, Optional

import yaml
from loguru import logger

from autocoder.common import AutoCoderArgs
from autocoder.common.agents import AgentManager
from autocoder.common.v2.agent.agentic_edit_tools.base_tool_resolver import (
    BaseToolResolver,
)
from autocoder.common.v2.agent.agentic_edit_types import (
    RunNamedSubagentsTool,
    ToolResult,
)

if typing.TYPE_CHECKING:
    from autocoder.common.v2.agent.agentic_edit import AgenticEdit


def _check_subagent_recursion(agent: Optional["AgenticEdit"]) -> Optional[ToolResult]:
    """统一的子 agent 递归防护，run_subagents 和 run_named_subagents 共用。"""
    if agent and hasattr(agent, "agent_context"):
        ctx = agent.agent_context
        if ctx.is_sub_agent or not ctx.can_spawn_subagents:
            logger.warning(
                "Blocked recursive subagent call "
                f"(is_sub_agent={ctx.is_sub_agent}, "
                f"can_spawn={ctx.can_spawn_subagents}, "
                f"name={ctx.subagent_name})"
            )
            return ToolResult(
                success=False,
                message=(
                    "当前已经是 subagent，禁止再次调用子代理工具。"
                    "子代理不允许递归创建更多子代理。"
                ),
                content={"error_type": "recursive_subagent_blocked"},
            )
    return None


class RunNamedSubagentsToolResolver(BaseToolResolver):
    """运行 .autocoderagents 中预定义命名子代理的工具解析器。

    前台路径 (background=false):
        SubagentClient.run_many(backend=CLI_PROCESS)
    后台路径 (background=true):
        CLIProcessBackend.prepare_argv() + execute_command_background() + notifier
    """

    def __init__(
        self,
        agent: Optional["AgenticEdit"],
        tool: RunNamedSubagentsTool,
        args: AutoCoderArgs,
    ):
        super().__init__(agent, tool, args)
        self.tool = tool

        project_root = args.source_dir if args.source_dir else "."
        self.agent_manager = AgentManager(project_root)

    def resolve(self) -> ToolResult:
        blocked = _check_subagent_recursion(self.agent)
        if blocked is not None:
            return blocked

        subagents_str = self.tool.subagents
        background = getattr(self.tool, "background", False)

        logger.info(
            f"RunNamedSubagentsToolResolver: background={background}"
        )

        try:
            parsed = self._parse_subagents_config(subagents_str)
            if not parsed["success"]:
                return ToolResult(
                    success=False,
                    message=parsed["error"],
                    content={"error_type": "config_parse_error"},
                )

            subagents_list: List[Dict[str, str]] = parsed["subagents"]
            execution_mode: str = parsed["mode"]

            logger.info(
                f"Parsed {len(subagents_list)} named subagents, mode={execution_mode}"
            )

            validation = self._validate_subagents(subagents_list)
            if not validation["success"]:
                return ToolResult(
                    success=False,
                    message=validation["error"],
                    content={
                        "error_type": "agent_validation_error",
                        "details": validation["details"],
                    },
                )

            if background:
                return self._execute_background(subagents_list)
            else:
                return self._execute_foreground(subagents_list, execution_mode)

        except Exception as e:
            logger.exception("RunNamedSubagentsToolResolver error")
            return ToolResult(
                success=False,
                message=f"执行子代理时发生错误: {e}",
                content={"error_type": "execution_error", "error_details": str(e)},
            )

    # ── streaming interface ──

    def resolve_stream(self) -> Generator[str, None, ToolResult]:
        """流式执行前台命名子代理，逐步 yield 进度文本，最终 return ToolResult。

        后台模式（background=True）不需要流式，直接委托 resolve()。
        """
        blocked = _check_subagent_recursion(self.agent)
        if blocked is not None:
            return blocked

        background = getattr(self.tool, "background", False)
        if background:
            return self.resolve()

        subagents_str = self.tool.subagents
        try:
            parsed = self._parse_subagents_config(subagents_str)
            if not parsed["success"]:
                return ToolResult(
                    success=False,
                    message=parsed["error"],
                    content={"error_type": "config_parse_error"},
                )

            subagents_list: List[Dict[str, str]] = parsed["subagents"]
            execution_mode: str = parsed["mode"]

            validation = self._validate_subagents(subagents_list)
            if not validation["success"]:
                return ToolResult(
                    success=False,
                    message=validation["error"],
                    content={
                        "error_type": "agent_validation_error",
                        "details": validation["details"],
                    },
                )

            total = len(subagents_list)
            agent_names = [entry["name"] for entry in subagents_list]

            model_display = self.args.model or "unknown"
            yield f"Starting {total} named sub-agents ({execution_mode} mode, backend=cli_process, model={model_display})...\n"
            for i, name in enumerate(agent_names):
                task_preview = subagents_list[i]["task"][:60]
                yield f"  [{i+1}] {name}: {task_preview}...\n"

            result = self._execute_foreground(subagents_list, execution_mode)
            return result

        except Exception as e:
            logger.exception("RunNamedSubagentsToolResolver stream error")
            return ToolResult(
                success=False,
                message=f"执行子代理时发生错误: {e}",
                content={"error_type": "execution_error", "error_details": str(e)},
            )

    # ── foreground: SubagentClient + CLI_PROCESS ──

    def _execute_foreground(
        self, subagents_list: List[Dict[str, str]], execution_mode: str
    ) -> ToolResult:
        from autocoder.common.v2.agent.subagents import (
            SubagentBackend,
            SubagentClient,
            SubagentRequest,
        )

        requests = self._build_requests(subagents_list, SubagentBackend.CLI_PROCESS)

        client = SubagentClient(
            args=self.args,
            llm=None,
            project_root=self.args.source_dir or ".",
        )

        parallel = execution_mode == "parallel"
        results = client.run_many(requests, parallel=parallel)

        return self._build_foreground_result(results, subagents_list, execution_mode)

    def _build_requests(
        self,
        subagents_list: List[Dict[str, str]],
        backend: "Any",
    ) -> list:
        from autocoder.common.v2.agent.subagents import SubagentRequest

        requests = []
        timeout = self.args.call_subagent_timeout

        for entry in subagents_list:
            requests.append(
                SubagentRequest(
                    task=entry["task"],
                    agent_name=entry["name"],
                    backend=backend,
                    timeout_seconds=int(timeout) if timeout else None,
                )
            )
        return requests

    @staticmethod
    def _build_foreground_result(
        results: list,
        subagents_list: List[Dict[str, str]],
        execution_mode: str,
    ) -> ToolResult:
        successful = 0
        failed = 0
        timed_out = 0
        detailed: List[Dict[str, Any]] = []

        for i, result in enumerate(results):
            entry = (
                subagents_list[i]
                if i < len(subagents_list)
                else {"name": "unknown", "task": "unknown"}
            )
            error = result.error or ""
            if result.success:
                successful += 1
                status = "success"
            elif "timeout" in error:
                timed_out += 1
                status = "timed_out"
            else:
                failed += 1
                status = "failed"

            detailed.append({
                "agent_name": entry["name"],
                "task": entry["task"],
                "status": status,
                "backend": result.backend.value if result.backend else None,
                "conversation_id": result.conversation_id,
                "attempt_result": result.attempt_result or None,
                "error": error,
                "timed_out": status == "timed_out",
            })

        all_ok = failed == 0 and timed_out == 0
        total = len(subagents_list)

        if all_ok:
            message = f"所有 {total} 个子代理执行成功"
        else:
            message = (
                f"子代理执行完成，但有失败: {successful}/{total} 成功"
            )

        return ToolResult(
            success=all_ok,
            message=message,
            content={
                "execution_mode": execution_mode,
                "total_subagents": total,
                "successful_count": successful,
                "failed_count": failed,
                "timed_out_count": timed_out,
                "results": detailed,
            },
        )

    # ── background: shared CLI argv + execute_command_background ──

    def _execute_background(
        self, subagents_list: List[Dict[str, str]]
    ) -> ToolResult:
        from autocoder.common.v2.agent.subagents import (
            SubagentBackend,
            SubagentClient,
            SubagentRequest,
        )
        from autocoder.common.v2.agent.subagents.backends.cli_process import (
            CLIProcessBackend,
        )
        from autocoder.common.shell_commands import execute_command_background
        from autocoder.common.shell_commands import get_background_process_notifier

        client = SubagentClient(
            args=self.args,
            llm=None,
            project_root=self.args.source_dir or ".",
        )

        background_processes: List[Dict[str, Any]] = []

        for i, entry in enumerate(subagents_list):
            agent_name = entry["name"]
            task = entry["task"]

            try:
                logger.info(
                    f"启动后台子代理 {i + 1}/{len(subagents_list)}: {agent_name}"
                )

                request = SubagentRequest(
                    task=task,
                    agent_name=agent_name,
                    backend=SubagentBackend.CLI_PROCESS,
                    timeout_seconds=None,
                )
                resolved = client._resolve_prompt(request)

                argv, temp_files = CLIProcessBackend.prepare_argv(
                    resolved, self.args
                )

                project_root = self.args.source_dir or "."
                process_info = execute_command_background(
                    command=argv, cwd=project_root, verbose=True
                )

                bg_proc: Dict[str, Any] = {
                    "agent_name": agent_name,
                    "task": task,
                    "pid": process_info["pid"],
                    "process_uniq_id": process_info.get("process_uniq_id"),
                    "command": process_info["command"],
                    "working_directory": process_info["working_directory"],
                    "start_time": process_info["start_time"],
                    "status": process_info["status"],
                }

                try:
                    conversation_id = (
                        self.agent.conversation_config.conversation_id
                        if self.agent
                        else None
                    )
                    if conversation_id:
                        notifier = get_background_process_notifier()
                        notifier.register_process(
                            conversation_id=conversation_id,
                            pid=process_info["pid"],
                            tool_name="RunNamedSubagentsTool",
                            command=process_info["command"],
                            cwd=process_info.get("working_directory"),
                            agent_name=agent_name,
                            task=task,
                        )
                except Exception as e:
                    logger.warning(
                        f"Failed to register background process to notifier: {e}"
                    )

                background_processes.append(bg_proc)
                logger.info(
                    f"成功启动后台子代理 '{agent_name}' "
                    f"(PID: {process_info['pid']})"
                )

            except Exception as e:
                logger.error(f"启动后台子代理 '{agent_name}' 失败: {e}")
                background_processes.append({
                    "agent_name": agent_name,
                    "task": task,
                    "pid": None,
                    "command": None,
                    "working_directory": None,
                    "start_time": None,
                    "status": "failed",
                    "error": str(e),
                })

        return ToolResult(
            success=True,
            message=f"成功启动 {len(background_processes)} 个后台子代理",
            content={
                "execution_mode": "background",
                "total_subagents": len(subagents_list),
                "background_processes": background_processes,
            },
        )

    # ── shared parsing / validation ──

    @staticmethod
    def _parse_subagents_config(subagents_str: str) -> Dict[str, Any]:
        """解析 JSON / YAML 格式的子代理配置。"""
        try:
            try:
                json_data = json.loads(subagents_str)
                if isinstance(json_data, list):
                    return {"success": True, "subagents": json_data, "mode": "parallel"}
                return {
                    "success": False,
                    "error": "JSON 格式必须是数组: [{\"name\": ..., \"task\": ...}]",
                }
            except json.JSONDecodeError:
                pass

            try:
                yaml_data = yaml.safe_load(subagents_str)
                if isinstance(yaml_data, dict) and "subagents" in yaml_data:
                    mode = yaml_data.get("mode", "parallel")
                    if mode not in ("parallel", "serial"):
                        return {
                            "success": False,
                            "error": f"无效的执行模式: {mode}，必须是 'parallel' 或 'serial'",
                        }
                    subagents = yaml_data["subagents"]
                    if not isinstance(subagents, list):
                        return {
                            "success": False,
                            "error": "YAML 中 subagents 必须是列表",
                        }
                    return {"success": True, "subagents": subagents, "mode": mode}
                elif isinstance(yaml_data, list):
                    return {"success": True, "subagents": yaml_data, "mode": "parallel"}
                else:
                    return {
                        "success": False,
                        "error": "YAML 格式必须包含 'subagents' 字段或直接为列表",
                    }
            except yaml.YAMLError as e:
                return {"success": False, "error": f"YAML 解析错误: {e}"}

        except Exception as e:
            return {"success": False, "error": f"配置解析失败: {e}"}

    def _validate_subagents(
        self, subagents_list: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        errors: List[str] = []
        available = self.agent_manager.get_agent_names()

        for i, entry in enumerate(subagents_list):
            if not isinstance(entry, dict):
                errors.append(f"子代理 {i}: 必须是字典格式")
                continue
            if "name" not in entry:
                errors.append(f"子代理 {i}: 缺少 'name' 字段")
                continue
            if "task" not in entry:
                errors.append(f"子代理 {i}: 缺少 'task' 字段")
                continue

            if not self.agent_manager.get_agent(entry["name"]):
                errors.append(f"子代理 {i}: 未找到名为 '{entry['name']}' 的代理")
                continue
            if not entry["task"] or not entry["task"].strip():
                errors.append(f"子代理 {i}: task 不能为空")

        if errors:
            msg = "子代理验证失败:\n" + "\n".join(errors)
            msg += f"\n\n可用的代理有：{', '.join(available)}"
            return {"success": False, "error": msg, "details": errors}

        return {"success": True}
