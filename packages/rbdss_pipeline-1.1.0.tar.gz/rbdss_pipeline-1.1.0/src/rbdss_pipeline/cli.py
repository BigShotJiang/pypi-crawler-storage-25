from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from .classification import validate_full_classification_file, validate_minimal_classification_file
from .config import AppConfig, load_mcda
from .mcda import evaluate_mcda
from .models import AuditResult, PipelineExecutionConfig, PipelineSpec
from .pipeline import PipelineRunner, validate_audit_file
from .project_manager import add_stage, create_project, materialize_stage
from .providers import make_provider

app = typer.Typer(help="CLI do pipeline RB-DSS/MCDA.")
console = Console()


@app.command()
def run(
    objective: Annotated[
        str | None, typer.Option(help="Objetivo do artefato ou override do execution config.")
    ] = None,
    context_file: Annotated[
        Path | None, typer.Option(exists=True, readable=True, help="Arquivo de contexto.")
    ] = None,
    provider: Annotated[
        str | None, typer.Option(help="Provider LLM ou override do execution config.")
    ] = None,
    constraints: Annotated[list[str] | None, typer.Option(help="Restrições do problema.")] = None,
    task_mnemonic: Annotated[
        str | None, typer.Option(help="Nome mnemônico da tarefa para a pasta de run.")
    ] = None,
    artifacts_dir: Annotated[Path | None, typer.Option(help="Diretório de artefatos.")] = None,
    out_dir: Annotated[Path | None, typer.Option(help="Diretório de saída das runs.")] = None,
    spec_file: Annotated[
        Path | None,
        typer.Option(exists=True, readable=True, help="Arquivo JSON com PipelineSpec."),
    ] = None,
    phase_handler_registry_refs: Annotated[
        list[str] | None,
        typer.Option(
            "--phase-handler-registry-ref",
            help="Referência module:attribute para carregar PhaseHandlerRegistry.",
        ),
    ] = None,
    phase_handler_entry_point_group: Annotated[
        str | None,
        typer.Option(help="Grupo de entry points para registries de handlers."),
    ] = None,
    execution_config_file: Annotated[
        Path | None,
        typer.Option(
            "--execution-config",
            exists=True,
            readable=True,
            help="Arquivo JSON com PipelineExecutionConfig.",
        ),
    ] = None,
) -> None:
    execution_config = _load_execution_config(execution_config_file)
    config_base_dir = execution_config_file.parent if execution_config_file else None
    objective_value = _coalesce_required(
        objective, execution_config.objective, field_name="objective"
    )
    context_file_value = context_file or _resolve_config_path(
        execution_config.context_file, config_base_dir
    )
    context = _resolve_context(
        context_file=context_file_value,
        inline_context=execution_config.context,
    )
    artifacts_dir_value = (
        artifacts_dir
        or _resolve_config_path(execution_config.artifacts_dir, config_base_dir)
        or Path("artifacts")
    )
    out_dir_value = (
        out_dir or _resolve_config_path(execution_config.out_dir, config_base_dir) or Path("runs")
    )
    spec_file_value = spec_file or _resolve_config_path(execution_config.spec_file, config_base_dir)
    registry_refs = (
        phase_handler_registry_refs
        if phase_handler_registry_refs is not None
        else execution_config.phase_handler_registry_refs
    )
    entry_point_group = (
        phase_handler_entry_point_group
        if phase_handler_entry_point_group is not None
        else execution_config.phase_handler_entry_point_group
    )
    constraints_value = constraints if constraints is not None else execution_config.constraints
    execution_overrides = _collect_execution_overrides(
        objective=objective,
        context_file=context_file,
        provider=provider,
        constraints=constraints,
        task_mnemonic=task_mnemonic,
        artifacts_dir=artifacts_dir,
        out_dir=out_dir,
        spec_file=spec_file,
        phase_handler_registry_refs=phase_handler_registry_refs,
        phase_handler_entry_point_group=phase_handler_entry_point_group,
    )
    execution_metadata = _build_execution_metadata(
        base_metadata=execution_config.metadata,
        context=context,
        context_file=context_file_value,
        execution_config_file=execution_config_file,
    )
    effective_config = PipelineExecutionConfig(
        objective=objective_value,
        context=execution_config.context if context_file_value is None else None,
        context_file=context_file_value,
        provider=provider or execution_config.provider,
        constraints=constraints_value,
        task_mnemonic=task_mnemonic or execution_config.task_mnemonic,
        artifacts_dir=artifacts_dir_value,
        out_dir=out_dir_value,
        spec_file=spec_file_value,
        phase_handler_registry_refs=registry_refs,
        phase_handler_entry_point_group=entry_point_group,
        metadata=execution_metadata,
    )

    cfg = AppConfig(artifacts_dir=artifacts_dir_value)
    spec = _load_pipeline_spec(spec_file_value) if spec_file_value else None
    runner = PipelineRunner(
        provider=make_provider(provider or execution_config.provider),
        config=cfg,
        spec=spec,
        phase_handler_registry_refs=registry_refs,
        phase_handler_entry_point_group=entry_point_group,
    )
    result = runner.run(
        objective=objective_value,
        context=context,
        constraints=constraints_value,
        out_dir=out_dir_value,
        task_mnemonic=task_mnemonic or execution_config.task_mnemonic,
        execution_config=effective_config,
        execution_overrides=execution_overrides,
    )

    console.print("[bold green]Pipeline finalizado[/bold green]")
    console.print(json.dumps(result, indent=2, ensure_ascii=False))


def _load_execution_config(execution_config_file: Path | None) -> PipelineExecutionConfig:
    if execution_config_file is None:
        return PipelineExecutionConfig()
    return PipelineExecutionConfig.model_validate_json(
        execution_config_file.read_text(encoding="utf-8")
    )


def _load_pipeline_spec(spec_file: Path) -> PipelineSpec:
    return PipelineSpec.model_validate_json(spec_file.read_text(encoding="utf-8"))


def _resolve_config_path(path: Path | None, base_dir: Path | None) -> Path | None:
    if path is None:
        return None
    if path.is_absolute() or base_dir is None:
        return path
    return base_dir / path


def _coalesce_required(primary: str | None, fallback: str | None, field_name: str) -> str:
    value = primary or fallback
    if not value:
        raise typer.BadParameter(
            f"{field_name} is required; pass --{field_name.replace('_', '-')} or --execution-config."
        )
    return value


def _resolve_context(context_file: Path | None, inline_context: str | None) -> str:
    if context_file is not None:
        return context_file.read_text(encoding="utf-8")
    if inline_context:
        return inline_context
    raise typer.BadParameter(
        "context is required; pass --context-file or execution_config.context."
    )


def _normalize_execution_config(
    execution_config: PipelineExecutionConfig, base_dir: Path | None
) -> PipelineExecutionConfig:
    return PipelineExecutionConfig(
        objective=execution_config.objective,
        context=execution_config.context,
        context_file=_resolve_config_path(execution_config.context_file, base_dir),
        provider=execution_config.provider,
        constraints=execution_config.constraints,
        task_mnemonic=execution_config.task_mnemonic,
        artifacts_dir=_resolve_config_path(execution_config.artifacts_dir, base_dir),
        out_dir=_resolve_config_path(execution_config.out_dir, base_dir),
        spec_file=_resolve_config_path(execution_config.spec_file, base_dir),
        phase_handler_registry_refs=execution_config.phase_handler_registry_refs,
        phase_handler_entry_point_group=execution_config.phase_handler_entry_point_group,
        metadata=execution_config.metadata,
    )


def _validate_execution_config(execution_config: PipelineExecutionConfig) -> None:
    if not execution_config.context and not execution_config.context_file:
        raise typer.BadParameter("execution_config requires context or context_file to be defined.")
    if execution_config.context_file and not execution_config.context_file.exists():
        raise typer.BadParameter(f"context_file not found: {execution_config.context_file}")
    if execution_config.spec_file and not execution_config.spec_file.exists():
        raise typer.BadParameter(f"spec_file not found: {execution_config.spec_file}")
    if execution_config.artifacts_dir and not execution_config.artifacts_dir.exists():
        raise typer.BadParameter(f"artifacts_dir not found: {execution_config.artifacts_dir}")


def _collect_execution_overrides(**values: object) -> list[str]:
    return [key for key, value in values.items() if value is not None]


def _build_execution_metadata(
    base_metadata: dict,
    context: str,
    context_file: Path | None,
    execution_config_file: Path | None,
) -> dict:
    metadata = dict(base_metadata)
    metadata.setdefault("context_sha256", _hash_text(context))
    metadata.setdefault("context_source", "file" if context_file else "inline")
    if execution_config_file is not None:
        metadata.setdefault("execution_config_file", str(execution_config_file))
    return metadata


def _hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


@app.command()
def validate(
    audit_file: Annotated[
        Path, typer.Option(exists=True, readable=True, help="Arquivo audit.json.")
    ],
    artifacts_dir: Annotated[Path, typer.Option(help="Diretório de artefatos.")] = Path(
        "artifacts"
    ),
) -> None:
    cfg = AppConfig(artifacts_dir=artifacts_dir)
    result = validate_audit_file(audit_file=audit_file, config=cfg)
    console.print("[bold blue]Resultado de validação[/bold blue]")
    console.print(result.model_dump_json(indent=2))


@app.command("validate-execution-config")
def validate_execution_config_cmd(
    execution_config_file: Annotated[
        Path,
        typer.Option(
            "--execution-config",
            exists=True,
            readable=True,
            help="Arquivo JSON com PipelineExecutionConfig.",
        ),
    ],
) -> None:
    execution_config = _load_execution_config(execution_config_file)
    normalized = _normalize_execution_config(execution_config, execution_config_file.parent)
    _validate_execution_config(normalized)
    console.print("[bold blue]Execution config valido[/bold blue]")
    console.print(normalized.model_dump_json(indent=2))


@app.command("create-project")
def create_project_cmd(
    project_id: Annotated[str, typer.Option(help="Identificador estavel do projeto.")],
    project_name: Annotated[str, typer.Option(help="Nome de exibicao do projeto.")],
    objetivo: Annotated[str, typer.Option(help="Objetivo do projeto.")],
    contexto: Annotated[str, typer.Option(help="Contexto inicial do projeto.")],
    projects_dir: Annotated[Path, typer.Option(help="Diretorio raiz de projetos.")] = Path(
        "projects"
    ),
) -> None:
    """Cria um manifesto de projeto e a estrutura inicial de stages."""
    result = create_project(
        project_id=project_id,
        project_name=project_name,
        objetivo=objetivo,
        contexto=contexto,
        projects_dir=projects_dir,
    )
    console.print("[bold green]Projeto criado[/bold green]")
    console.print(json.dumps(result, indent=2, ensure_ascii=False))


@app.command("add-stage")
def add_stage_cmd(
    project_id: Annotated[str, typer.Option(help="Identificador do projeto.")],
    stage_id: Annotated[str, typer.Option(help="Identificador da etapa.")],
    objetivo: Annotated[str, typer.Option(help="Objetivo da etapa.")],
    instancia_pipeline_sugerida: Annotated[
        str, typer.Option(help="Rota ou instancia de pipeline sugerida.")
    ],
    projects_dir: Annotated[Path, typer.Option(help="Diretorio raiz de projetos.")] = Path(
        "projects"
    ),
) -> None:
    """Adiciona uma etapa planejada ao manifesto de projeto."""
    result = add_stage(
        project_id=project_id,
        stage_id=stage_id,
        objetivo=objetivo,
        instancia_pipeline_sugerida=instancia_pipeline_sugerida,
        projects_dir=projects_dir,
    )
    console.print("[bold green]Etapa adicionada[/bold green]")
    console.print(json.dumps(result, indent=2, ensure_ascii=False))


@app.command("materialize-stage")
def materialize_stage_cmd(
    project_id: Annotated[str, typer.Option(help="Identificador do projeto.")],
    stage_id: Annotated[str, typer.Option(help="Identificador da etapa.")],
    run_path: Annotated[str, typer.Option(help="Caminho da run consubstanciada.")],
    projects_dir: Annotated[Path, typer.Option(help="Diretorio raiz de projetos.")] = Path(
        "projects"
    ),
) -> None:
    """Vincula uma run concreta a uma etapa do projeto."""
    result = materialize_stage(
        project_id=project_id,
        stage_id=stage_id,
        run_path=run_path,
        projects_dir=projects_dir,
    )
    console.print("[bold green]Etapa consubstanciada[/bold green]")
    console.print(json.dumps(result, indent=2, ensure_ascii=False))


@app.command()
def validate_classification(
    classification_file: Annotated[
        Path,
        typer.Option(exists=True, readable=True, help="Arquivo classification_minimal.json."),
    ],
    schema_file: Annotated[
        Path,
        typer.Option(exists=True, readable=True, help="Schema JSON da classificacao minima."),
    ] = Path("artifacts/schemas/classification_schema_minimal.json"),
) -> None:
    result = validate_minimal_classification_file(
        classification_file=classification_file,
        schema_file=schema_file,
    )
    if result.valid:
        console.print("[bold green]Classificacao valida[/bold green]")
        return

    console.print("[bold red]Classificacao invalida[/bold red]")
    for error in result.errors:
        console.print(f"- {error}")
    raise typer.Exit(code=1)


@app.command()
def validate_full_classification(
    classification_file: Annotated[
        Path,
        typer.Option(exists=True, readable=True, help="Arquivo classification_full.json."),
    ],
    schema_file: Annotated[
        Path,
        typer.Option(exists=True, readable=True, help="Schema JSON da classificacao minima."),
    ] = Path("artifacts/schemas/classification_schema_minimal.json"),
) -> None:
    result = validate_full_classification_file(
        classification_file=classification_file,
        schema_file=schema_file,
    )
    if result.valid:
        console.print("[bold green]Classificacao completa valida[/bold green]")
        return

    console.print("[bold red]Classificacao completa invalida[/bold red]")
    for error in result.errors:
        console.print(f"- {error}")
    raise typer.Exit(code=1)


@app.command()
def validate_mcda(
    audit_file: Annotated[
        Path,
        typer.Option(exists=True, readable=True, help="Arquivo audit.json com metricas C1-C4."),
    ],
    execution_instance_type: Annotated[
        str,
        typer.Option(help="Tipo de instancia: projecta | regulara | vitalia | scholara | dominia."),
    ] = "projecta",
    artifacts_dir: Annotated[Path, typer.Option(help="Diretorio de artefatos.")] = Path(
        "artifacts"
    ),
) -> None:
    """Calcula o Global Score MCDA e emite decisao ACCEPT | REFINE | REJECT.

    Le metricas C1-C4 do audit.json (campos: precisao_tecnica, seguranca_compliance,
    completude, clareza_formato), carrega pesos de artifacts/schemas/mcda_weights.yaml
    respeitando execution_instance_type, e exibe o resultado estruturado.
    """
    cfg = AppConfig(artifacts_dir=artifacts_dir)
    mcda_cfg = load_mcda(cfg, execution_instance_type=execution_instance_type)

    raw = json.loads(audit_file.read_text(encoding="utf-8"))
    # Suporta audit.json com chave "metrics" ou campos diretamente na raiz
    metrics_raw: dict = raw.get("metrics", raw)
    audit = AuditResult(
        metrics={k: float(v) for k, v in metrics_raw.items() if isinstance(v, int | float)}
    )

    result = evaluate_mcda(audit, mcda_cfg, execution_instance_type=execution_instance_type)

    # Tabela de criterios
    table = Table(title=f"MCDA — {execution_instance_type}", show_lines=True)
    table.add_column("Criterio", style="cyan")
    table.add_column("Nota", justify="right")
    table.add_column("Peso", justify="right")
    table.add_column("Parcela", justify="right")
    criterion_map = {
        "precisao_tecnica": "C1 Precisao Tecnica",
        "seguranca_compliance": "C2 Seguranca & Compliance",
        "completude": "C3 Completude",
        "clareza_formato": "C4 Clareza e Formato",
    }
    for key, label in criterion_map.items():
        nota = audit.metrics.get(key, 0.0)
        peso = mcda_cfg.weights.get(key, 0.0)
        table.add_row(label, f"{nota:.2f}", f"{peso:.2f}", f"{nota * peso:.4f}")

    console.print(table)

    decision_color = {"ACCEPT": "green", "REFINE": "yellow", "REJECT": "red"}.get(
        result.decision.value, "white"
    )
    console.print(
        f"\n[bold {decision_color}]Decisao: {result.decision.value}[/bold {decision_color}]"
    )
    console.print(result.explanation)

    if result.decision.value != "ACCEPT":
        raise typer.Exit(code=1)


if __name__ == "__main__":
    app()
