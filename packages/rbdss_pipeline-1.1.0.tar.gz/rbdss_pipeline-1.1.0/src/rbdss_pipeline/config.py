from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, Field

from .mcda import MCDAConfig, load_mcda_config
from .models import RBRuleSet
from .rules import load_rules


class AppConfig(BaseModel):
    artifacts_dir: Path = Field(default=Path("artifacts"))
    # Motor legado — mantido para compatibilidade; motor primario: mcda_weights_file
    rules_file: str = "rb_dss.yaml"
    mcda_weights_file: str = "schemas/mcda_weights.yaml"
    input_contract_file: str = "input_contract.md"
    output_contract_file: str = "output_contract.md"
    prompt_master_file: str = "prompt_master.md"
    generic_rules_file: str = "rules.yaml"

    @property
    def rules_path(self) -> Path:
        return self.artifacts_dir / self.rules_file

    @property
    def mcda_weights_path(self) -> Path:
        return self.artifacts_dir / self.mcda_weights_file

    @property
    def input_contract_path(self) -> Path:
        return self.artifacts_dir / self.input_contract_file

    @property
    def output_contract_path(self) -> Path:
        return self.artifacts_dir / self.output_contract_file

    @property
    def prompt_master_path(self) -> Path:
        return self.artifacts_dir / self.prompt_master_file

    @property
    def generic_rules_path(self) -> Path:
        return self.artifacts_dir / self.generic_rules_file


def load_ruleset(config: AppConfig) -> RBRuleSet:
    """Carrega o motor legado rb_dss.yaml. Usar load_mcda para o motor primario."""
    return load_rules(config.rules_path)


def load_mcda(config: AppConfig, execution_instance_type: str = "projecta") -> MCDAConfig:
    """Carrega MCDAConfig a partir de mcda_weights.yaml respeitando a instancia."""
    return load_mcda_config(
        weights_path=config.mcda_weights_path,
        execution_instance_type=execution_instance_type,
    )
