"""RB-DSS pipeline scaffold — API pública.

Motor primário: MCDA v1.0.0 (artifacts/schemas/mcda_weights.yaml).
"""

from __future__ import annotations

__all__ = [
    "__version__",
    # Pipeline
    "DEFAULT_PIPELINE_PHASES",
    "PhaseHandler",
    "PhaseHandlerMap",
    "PhaseHandlerRegistry",
    "PipelineRunner",
    "PipelineState",
    "EvalResult",
    "HITLApprover",
    "HITLGateBlockedError",
    "PhaseEval",
    "PhaseEvalAssertion",
    "PhaseEvalFailedError",
    "PipelineEvent",
    "PipelineEventHook",
    "PipelineEventType",
    "UnsupportedPipelineSpecError",
    "default_pipeline_spec",
    "load_phase_handler_registry",
    "normalize_phase_handlers",
    "phase_key",
    # Motor MCDA
    "evaluate_mcda",
    "compute_global_score",
    "load_mcda_config",
    "MCDAConfig",
    # Configuração
    "AppConfig",
    "load_mcda",
    # Modelos
    "AuditResult",
    "AuditEvent",
    "AuditEventLevel",
    "Decision",
    "HITLGate",
    "HITLGateStatus",
    "PipelinePhase",
    "PipelinePhaseId",
    "PipelineExecutionConfig",
    "PipelineRun",
    "PipelineRunStatus",
    "PipelineSpec",
    "TaskProfile",
    "ValidationResult",
    # Providers
    "LLMProvider",
    "MockProvider",
    # Projeto
    "create_project",
    "add_stage",
    "materialize_stage",
]

__version__ = "1.1.0"

from .config import AppConfig, load_mcda
from .mcda import MCDAConfig, compute_global_score, evaluate_mcda, load_mcda_config
from .models import (
    AuditEvent,
    AuditEventLevel,
    AuditResult,
    Decision,
    EvalResult,
    HITLGate,
    HITLGateStatus,
    PhaseEval,
    PipelineEvent,
    PipelineEventType,
    PipelineExecutionConfig,
    PipelinePhase,
    PipelinePhaseId,
    PipelineRun,
    PipelineRunStatus,
    PipelineSpec,
    TaskProfile,
    ValidationResult,
)
from .pipeline import (
    DEFAULT_PIPELINE_PHASES,
    HITLApprover,
    HITLGateBlockedError,
    PhaseEvalAssertion,
    PhaseEvalFailedError,
    PhaseHandler,
    PhaseHandlerMap,
    PhaseHandlerRegistry,
    PipelineEventHook,
    PipelineRunner,
    PipelineState,
    UnsupportedPipelineSpecError,
    default_pipeline_spec,
    load_phase_handler_registry,
    normalize_phase_handlers,
    phase_key,
)
from .project_manager import add_stage, create_project, materialize_stage
from .providers import LLMProvider, MockProvider
