from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field


class PipelinePhase(StrEnum):
    ASK = "ask"
    PLAN = "plan"
    GENERATE = "generate"
    SHAPE = "shape"
    CRITIQUE = "critique"
    CORRECT = "correct"
    AUDIT = "audit"
    HARDEN = "harden"
    VALIDATE = "validate"
    DEEP_RESEARCH = "deep_research"


PipelinePhaseId = PipelinePhase | str


class Decision(StrEnum):
    ACCEPT = "ACCEPT"
    REFINE = "REFINE"
    REJECT = "REJECT"


class HITLGateStatus(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    WAIVED = "waived"


class PipelineRunStatus(StrEnum):
    CREATED = "created"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


class AuditEventLevel(StrEnum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    SECURITY = "security"


class HITLGate(BaseModel):
    id: str
    question: str
    phase: PipelinePhaseId | None = None
    required: bool = True
    status: HITLGateStatus = HITLGateStatus.PENDING
    approvers: list[str] = Field(default_factory=list)
    risk_if_rejected: str | None = None


class TaskProfile(BaseModel):
    id: str
    name: str
    description: str = ""
    phases: list[PipelinePhaseId]
    provider: str = "mock"
    policy_sets: list[str] = Field(default_factory=list)
    hitl_gates: list[HITLGate] = Field(default_factory=list)


class PhaseEval(BaseModel):
    id: str
    phase: PipelinePhaseId
    assertion: str | None = None
    weight: float = 1.0
    required: bool = False


class EvalResult(BaseModel):
    eval_id: str
    phase: PipelinePhaseId
    passed: bool
    score: float = 1.0
    detail: str = ""


class PipelineSpec(BaseModel):
    id: str
    name: str
    version: str = "1.0.0"
    description: str = ""
    phases: list[PipelinePhaseId]
    phase_dependencies: dict[str, list[PipelinePhaseId]] = Field(default_factory=dict)
    default_profile: TaskProfile | None = None
    hitl_gates: list[HITLGate] = Field(default_factory=list)
    evals: list[PhaseEval] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class PipelineExecutionConfig(BaseModel):
    objective: str | None = None
    context: str | None = None
    context_file: Path | None = None
    provider: str = "mock"
    constraints: list[str] = Field(default_factory=list)
    task_mnemonic: str | None = None
    artifacts_dir: Path | None = None
    out_dir: Path | None = None
    spec_file: Path | None = None
    phase_handler_registry_refs: list[str] = Field(default_factory=list)
    phase_handler_entry_point_group: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class AuditEvent(BaseModel):
    event_id: str
    run_id: str
    phase: PipelinePhaseId | None = None
    level: AuditEventLevel = AuditEventLevel.INFO
    message: str
    payload: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class PipelineRun(BaseModel):
    run_id: str
    spec_id: str
    objective: str
    task_profile_id: str | None = None
    status: PipelineRunStatus = PipelineRunStatus.CREATED
    run_dir: str | None = None
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: datetime | None = None
    decision: Decision | None = None
    triggered_rules: list[RuleTrigger] = Field(default_factory=list)
    audit_events: list[AuditEvent] = Field(default_factory=list)


class PipelineEventType(StrEnum):
    RUN_STARTED = "run_started"
    PHASE_STARTED = "phase_started"
    PHASE_COMPLETED = "phase_completed"
    RUN_COMPLETED = "run_completed"
    RUN_BLOCKED = "run_blocked"


class PipelineEvent(BaseModel):
    event_type: PipelineEventType
    run_id: str
    spec_id: str
    phase: PipelinePhaseId | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class AuditResult(BaseModel):
    metrics: dict[str, float] = Field(default_factory=dict)
    flags: dict[str, bool] = Field(default_factory=dict)
    notes: dict[str, str] = Field(default_factory=dict)


class RBRuleCondition(BaseModel):
    metric: str
    op: str
    value: Any


class RBRule(BaseModel):
    id: str
    if_: RBRuleCondition = Field(alias="if")
    then: str
    reason: str | None = None


class RBRuleSet(BaseModel):
    rules: list[RBRule]


class RuleTrigger(BaseModel):
    rule_id: str
    action: str
    reason: str | None = None


class ValidationResult(BaseModel):
    decision: Decision
    triggered_rules: list[RuleTrigger] = Field(default_factory=list)
    explanation: str
