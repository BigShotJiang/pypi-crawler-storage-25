from __future__ import annotations


def ask_prompt(objective: str, context: str, constraints: list[str]) -> str:
    joined = "\n".join(f"- {item}" for item in constraints) if constraints else "- N/A"
    return f"""Voce e um analista de requisitos.

Objetivo:
{objective}

Contexto:
{context}

Restricoes:
{joined}

Saida:
- Liste duvidas criticas
- Liste suposicoes
- Estruture entendimento do problema
"""


def plan_prompt(ask_output: str) -> str:
    return f"""Com base no entendimento abaixo:

{ask_output}

1. Estruture um plano de execucao
2. Defina etapas
3. Defina criterios de sucesso por etapa
4. Identifique riscos

Formato: checklist estruturado
"""


def generate_prompt(plan_output: str) -> str:
    return f"""Execute o plano abaixo.

{plan_output}

Regras:
- Nao simplifique demais
- Nao omita etapas
- Priorize clareza e estrutura
"""


def shape_prompt(generated: str, output_contract: str) -> str:
    return f"""Reestruture a resposta para o contrato abaixo:

{output_contract}

Resposta base:
{generated}
"""


def critique_prompt(shaped: str) -> str:
    return f"""Aja como auditor critico.

Avalie:
- inconsistencias
- lacunas
- erros conceituais
- redundancias

Saida:
- lista priorizada de problemas

Artefato:
{shaped}
"""


def correct_prompt(shaped: str, critique: str) -> str:
    return f"""Corrija TODOS os problemas listados.

Regras:
- Nao reescreva tudo sem necessidade
- Preserve partes corretas
- Foque em precisao

Problemas:
{critique}

Versao atual:
{shaped}
"""


def audit_prompt(corrected: str) -> str:
    return f"""Avalie a resposta com nota de 0 a 10 nos criterios MCDA abaixo.

Criterios:
- precisao_tecnica (C1): rigor factual, ausencia de alucinacoes, fontes verificaveis
- seguranca_compliance (C2): ausencia de PII, dados sensiveis ou riscos regulatorios
- completude (C3): cobertura do escopo definido no ASK, sem lacunas criticas
- clareza_formato (C4): estrutura, legibilidade e conformidade com o output_contract

Retorne JSON valido no formato:
{{
  "metrics": {{
    "precisao_tecnica": 0.0,
    "seguranca_compliance": 0.0,
    "completude": 0.0,
    "clareza_formato": 0.0
  }},
  "flags": {{
    "inconsistencia_detectada": false,
    "audit_fallback": false
  }},
  "notes": {{
    "precisao_tecnica": "",
    "seguranca_compliance": "",
    "completude": "",
    "clareza_formato": ""
  }}
}}

Resposta para auditoria:
{corrected}
"""


def harden_prompt(corrected: str, audit_summary: str) -> str:
    return f"""Transforme na versao final:

- Remova redundancias
- Padronize linguagem
- Garanta consistencia
- Otimize para leitura humana + maquina

Contexto da auditoria:
{audit_summary}

Conteudo:
{corrected}
"""


def deep_research_prompt(hardened: str, validation_summary: str) -> str:
    return f"""Produza uma etapa DEEP_RESEARCH / HOMOLOGACAO.

Objetivo:
- Declarar evidencias disponiveis
- Declarar limites de verificacao
- Registrar se houve ou nao homologacao externa
- Indicar fontes ou gates necessarios quando a materia for normativa, regulatoria ou temporalmente instavel

Contexto RB-DSS:
{validation_summary}

Conteudo final:
{hardened}
"""
