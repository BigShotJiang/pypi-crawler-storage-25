from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


class LLMProvider(Protocol):
    def generate(self, prompt: str, *, system: str | None = None) -> str: ...


@dataclass
class MockProvider:
    name: str = "mock"

    def generate(self, prompt: str, *, system: str | None = None) -> str:
        system_tag = f"[{system}] " if system else ""
        snippet = prompt.strip().replace("\n", " ")
        snippet = snippet[:180]
        return f"{system_tag}Mock output para: {snippet}..."


class UnsupportedProviderError(ValueError):
    pass


def make_provider(name: str) -> LLMProvider:
    normalized = name.strip().lower()
    if normalized == "mock":
        return MockProvider()

    raise UnsupportedProviderError(
        f"Provider '{name}' ainda nao implementado neste scaffold. Use --provider mock."
    )
