from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Callable, Mapping
from datetime import datetime
from importlib import import_module
from importlib.metadata import entry_points
from pathlib import Path
from typing import cast

from .config import AppConfig, load_mcda
from .mcda import evaluate_mcda
from .models import (
    AuditEvent,
    AuditEventLevel,
    AuditResult,
    EvalResult,
    HITLGate,
    HITLGateStatus,
    PipelineEvent,
    PipelineEventType,
    PipelineExecutionConfig,
    PipelinePhase,
    PipelinePhaseId,
    PipelineRun,
    PipelineRunStatus,
    PipelineSpec,
    TaskProfile,
    ValidationResult,
)
from .prompts import (
    ask_prompt,
    audit_prompt,
    correct_prompt,
    critique_prompt,
    deep_research_prompt,
    generate_prompt,
    harden_prompt,
    plan_prompt,
    shape_prompt,
)
from .providers import LLMProvider

PipelineState = dict[str, object]
PhaseHandler = Callable[[Path, list[dict[str, str]], PipelineState], None]
PhaseHandlerMap = Mapping[PipelinePhaseId, PhaseHandler]
HITLApprover = Callable[[HITLGate], HITLGateStatus]
PipelineEventHook = Callable[[PipelineEvent], None]
PhaseEvalAssertion = Callable[[PipelineState], EvalResult]

DEFAULT_PIPELINE_PHASES: tuple[PipelinePhase, ...] = (
    PipelinePhase.ASK,
    PipelinePhase.PLAN,
    PipelinePhase.GENERATE,
    PipelinePhase.SHAPE,
    PipelinePhase.CRITIQUE,
    PipelinePhase.CORRECT,
    PipelinePhase.AUDIT,
    PipelinePhase.HARDEN,
    PipelinePhase.VALIDATE,
    PipelinePhase.DEEP_RESEARCH,
)

_PHASE_DEPENDENCIES: dict[str, tuple[str, ...]] = {
    PipelinePhase.PLAN: (PipelinePhase.ASK,),
    PipelinePhase.GENERATE: (PipelinePhase.PLAN,),
    PipelinePhase.SHAPE: (PipelinePhase.GENERATE,),
    PipelinePhase.CRITIQUE: (PipelinePhase.SHAPE,),
    PipelinePhase.CORRECT: (PipelinePhase.SHAPE, PipelinePhase.CRITIQUE),
    PipelinePhase.AUDIT: (PipelinePhase.CORRECT,),
    PipelinePhase.HARDEN: (PipelinePhase.CORRECT, PipelinePhase.AUDIT),
    PipelinePhase.VALIDATE: (PipelinePhase.AUDIT,),
    PipelinePhase.DEEP_RESEARCH: (PipelinePhase.HARDEN, PipelinePhase.AUDIT),
}


def phase_key(phase: PipelinePhaseId) -> str:
    """Normaliza o identificador de fase para chave textual estavel."""
    return phase.value if isinstance(phase, PipelinePhase) else phase


def normalize_phase_handlers(handlers: PhaseHandlerMap) -> dict[str, PhaseHandler]:
    """Normaliza handlers declarados por enum ou string para o mapa interno."""
    return {phase_key(phase): handler for phase, handler in handlers.items()}


class PhaseHandlerRegistry:
    """Registro reutilizavel de handlers para fases customizadas de pipeline."""

    def __init__(self, handlers: PhaseHandlerMap | None = None) -> None:
        self._handlers: dict[str, PhaseHandler] = {}
        if handlers:
            self.update(handlers)

    def register(self, phase: PipelinePhaseId, handler: PhaseHandler) -> None:
        self._handlers[phase_key(phase)] = handler

    def update(self, handlers: PhaseHandlerMap) -> None:
        self._handlers.update(normalize_phase_handlers(handlers))

    def merge(self, source: PhaseHandlerMap | PhaseHandlerRegistry) -> None:
        if isinstance(source, PhaseHandlerRegistry):
            self._handlers.update(source.as_dict())
            return
        self.update(source)

    def get(self, phase: PipelinePhaseId) -> PhaseHandler | None:
        return self._handlers.get(phase_key(phase))

    def as_dict(self) -> dict[str, PhaseHandler]:
        return dict(self._handlers)


def load_phase_handler_registry(
    *registry_refs: str,
    entry_point_group: str | None = None,
) -> PhaseHandlerRegistry:
    """Carrega registries de handlers por referencia Python ou entry points."""
    registry = PhaseHandlerRegistry()
    for registry_ref in registry_refs:
        registry.merge(_coerce_phase_handler_registry(_import_registry_source(registry_ref)))

    if entry_point_group:
        for entry_point in entry_points(group=entry_point_group):
            registry.merge(_coerce_phase_handler_registry(entry_point.load()))

    return registry


def _import_registry_source(registry_ref: str) -> object:
    module_name, separator, attribute_path = registry_ref.partition(":")
    if not separator or not module_name or not attribute_path:
        raise UnsupportedPipelineSpecError(
            "Phase handler registry references must use 'module:attribute'."
        )

    source: object = import_module(module_name)
    for attribute_name in attribute_path.split("."):
        source = getattr(source, attribute_name)
    return source


def _coerce_phase_handler_registry(source: object) -> PhaseHandlerRegistry:
    if isinstance(source, PhaseHandlerRegistry):
        return source

    if isinstance(source, Mapping):
        registry = PhaseHandlerRegistry()
        for phase, handler in source.items():
            if not isinstance(phase, PipelinePhase | str):
                raise UnsupportedPipelineSpecError(
                    "Phase handler registry mappings must use PipelinePhase or str keys."
                )
            if not callable(handler):
                raise UnsupportedPipelineSpecError(
                    f"Handler for phase '{phase_key(phase)}' is not callable."
                )
            registry.register(phase, cast(PhaseHandler, handler))
        return registry

    if callable(source):
        return _coerce_phase_handler_registry(source())

    raise UnsupportedPipelineSpecError(
        "Phase handler registry sources must be a registry, mapping, or factory."
    )


def default_pipeline_spec() -> PipelineSpec:
    """Contrato versionavel para o pipeline padrao preservado pelo runner atual."""
    phases: list[PipelinePhaseId] = list(DEFAULT_PIPELINE_PHASES)
    return PipelineSpec(
        id="rbdss-default-10phase",
        name="RB-DSS default 10-phase pipeline",
        version="1.0.0",
        description="Pipeline padrao compativel com PipelineRunner.run().",
        phases=phases,
        default_profile=TaskProfile(
            id="default",
            name="Default task profile",
            description="Perfil generico para execucao local auditavel.",
            phases=phases,
            provider="mock",
            policy_sets=["mcda-v1"],
        ),
        metadata={
            "compatibility": "PipelineRunner.run",
            "decision_engine": "mcda-v1",
        },
    )


class UnsupportedPipelineSpecError(ValueError):
    """Raised when a PipelineSpec cannot be executed by the current runner."""


class HITLGateBlockedError(RuntimeError):
    """Raised when a required HITL gate is rejected, blocking the pipeline run."""

    def __init__(self, gate: HITLGate) -> None:
        suffix = f" Risk: {gate.risk_if_rejected}." if gate.risk_if_rejected else ""
        super().__init__(f"Required HITL gate '{gate.id}' was rejected.{suffix}")
        self.gate = gate


class PhaseEvalFailedError(RuntimeError):
    """Raised when a required phase eval fails, blocking the pipeline run."""

    def __init__(self, result: EvalResult) -> None:
        super().__init__(
            f"Required eval '{result.eval_id}' failed on phase '{result.phase}'"
            + (f": {result.detail}" if result.detail else ".")
        )
        self.eval_result = result


class PipelineRunner:
    def __init__(
        self,
        provider: LLMProvider,
        config: AppConfig | None = None,
        spec: PipelineSpec | None = None,
        phase_handlers: PhaseHandlerMap | PhaseHandlerRegistry | None = None,
        phase_handler_registry_refs: list[str] | None = None,
        phase_handler_entry_point_group: str | None = None,
        hitl_approver: HITLApprover | None = None,
        event_hooks: list[PipelineEventHook] | None = None,
        eval_assertions: dict[str, PhaseEvalAssertion] | None = None,
    ) -> None:
        self.provider = provider
        self.config = config or AppConfig()
        self.spec = spec or default_pipeline_spec()
        self.hitl_approver = hitl_approver
        self.event_hooks: list[PipelineEventHook] = list(event_hooks) if event_hooks else []
        self.eval_assertions: dict[str, PhaseEvalAssertion] = (
            dict(eval_assertions) if eval_assertions else {}
        )
        self.phase_handlers = self._default_phase_handlers()
        if phase_handler_registry_refs or phase_handler_entry_point_group:
            self.phase_handlers.update(
                load_phase_handler_registry(
                    *(phase_handler_registry_refs or []),
                    entry_point_group=phase_handler_entry_point_group,
                ).as_dict()
            )
        if isinstance(phase_handlers, PhaseHandlerRegistry):
            self.phase_handlers.update(phase_handlers.as_dict())
        elif phase_handlers:
            self.phase_handlers.update(normalize_phase_handlers(phase_handlers))
        self._ensure_supported_spec(self.spec)

    def run(
        self,
        objective: str,
        context: str,
        constraints: list[str] | None = None,
        out_dir: Path = Path("runs"),
        task_mnemonic: str | None = None,
        execution_config: PipelineExecutionConfig | None = None,
        execution_overrides: list[str] | None = None,
    ) -> dict:
        constraints = constraints or []
        run_id = datetime.now().strftime("%Y%m%d-%H%M%S")
        mnemonic = self._to_mnemonic(task_mnemonic or objective)
        run_dir = out_dir / mnemonic / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        (run_dir / "pipeline_spec.json").write_text(
            self.spec.model_dump_json(indent=2),
            encoding="utf-8",
        )
        execution_snapshot: dict[str, object] | None = None
        if execution_config:
            execution_snapshot = self._save_execution_config(
                run_dir,
                execution_config,
                execution_overrides,
            )

        input_contract = self.config.input_contract_path.read_text(encoding="utf-8")
        output_contract = self.config.output_contract_path.read_text(encoding="utf-8")
        generic_rules = self.config.generic_rules_path.read_text(encoding="utf-8")
        prompt_summaries: list[dict[str, str]] = []
        state: PipelineState = {
            "objective": objective,
            "context": context,
            "constraints": constraints,
            "input_contract": input_contract,
            "output_contract": output_contract,
            "generic_rules": generic_rules,
        }

        all_gates = self._collect_gates()
        gate_events: list[AuditEvent] = []
        eval_results: list[EvalResult] = []
        eval_events: list[AuditEvent] = []

        self._fire_event(
            PipelineEvent(
                event_type=PipelineEventType.RUN_STARTED,
                run_id=run_id,
                spec_id=self.spec.id,
                payload={
                    "objective": objective,
                    "phases": [self._phase_key(p) for p in self.spec.phases],
                },
            )
        )

        try:
            for phase in self.spec.phases:
                self._fire_event(
                    PipelineEvent(
                        event_type=PipelineEventType.PHASE_STARTED,
                        run_id=run_id,
                        spec_id=self.spec.id,
                        phase=phase,
                    )
                )
                self._run_phase(phase, run_dir, prompt_summaries, state)
                self._fire_event(
                    PipelineEvent(
                        event_type=PipelineEventType.PHASE_COMPLETED,
                        run_id=run_id,
                        spec_id=self.spec.id,
                        phase=phase,
                    )
                )
                self._evaluate_hitl_gates(self._phase_key(phase), all_gates, gate_events, run_id)
                self._evaluate_phase_evals(
                    self._phase_key(phase), eval_results, eval_events, run_id, state
                )
            self._evaluate_hitl_gates(None, all_gates, gate_events, run_id)
        except (HITLGateBlockedError, PhaseEvalFailedError):
            self._save_prompt_summaries(run_dir, prompt_summaries)
            if eval_results:
                (run_dir / "eval_results.json").write_text(
                    json.dumps(
                        [r.model_dump() for r in eval_results], indent=2, ensure_ascii=False
                    ),
                    encoding="utf-8",
                )
            pipeline_run = self._make_pipeline_run(
                run_id,
                objective,
                PipelineRunStatus.BLOCKED,
                run_dir,
                mcda_result=state.get("mcda_result"),
                execution_snapshot=execution_snapshot,
                gate_events=gate_events,
                eval_events=eval_events,
            )
            (run_dir / "pipeline_run.json").write_text(
                pipeline_run.model_dump_json(indent=2), encoding="utf-8"
            )
            self._fire_event(
                PipelineEvent(
                    event_type=PipelineEventType.RUN_BLOCKED,
                    run_id=run_id,
                    spec_id=self.spec.id,
                )
            )
            raise

        self._save_prompt_summaries(run_dir, prompt_summaries)
        if eval_results:
            (run_dir / "eval_results.json").write_text(
                json.dumps([r.model_dump() for r in eval_results], indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        mcda_result = state.get("mcda_result")
        pipeline_run = self._make_pipeline_run(
            run_id,
            objective,
            PipelineRunStatus.COMPLETED,
            run_dir,
            mcda_result=mcda_result,
            execution_snapshot=execution_snapshot,
            gate_events=gate_events,
            eval_events=eval_events,
        )
        (run_dir / "pipeline_run.json").write_text(
            pipeline_run.model_dump_json(indent=2),
            encoding="utf-8",
        )
        self._fire_event(
            PipelineEvent(
                event_type=PipelineEventType.RUN_COMPLETED,
                run_id=run_id,
                spec_id=self.spec.id,
                payload={
                    "decision": mcda_result.decision.value
                    if isinstance(mcda_result, ValidationResult)
                    else None,
                },
            )
        )

        return {
            "run_dir": str(run_dir),
            "spec_id": self.spec.id,
            "decision": mcda_result.decision.value
            if isinstance(mcda_result, ValidationResult)
            else None,
            "triggered_rules": (
                [r.model_dump() for r in mcda_result.triggered_rules]
                if isinstance(mcda_result, ValidationResult)
                else []
            ),
        }

    @classmethod
    def _save_text(cls, run_dir: Path, phase: PipelinePhaseId, content: str) -> None:
        (run_dir / f"{cls._phase_key(phase)}.md").write_text(content, encoding="utf-8")

    def _save_execution_config(
        self,
        run_dir: Path,
        execution_config: PipelineExecutionConfig,
        execution_overrides: list[str] | None,
    ) -> dict[str, object]:
        effective = execution_config.model_copy(deep=True)
        metadata = dict(effective.metadata)
        metadata.setdefault("spec_id", self.spec.id)
        if execution_overrides is not None:
            metadata["overrides"] = execution_overrides
        effective.metadata = metadata
        snapshot_content = effective.model_dump_json(indent=2)
        snapshot_path = run_dir / "execution_config.json"
        snapshot_path.write_text(snapshot_content, encoding="utf-8")
        PipelineExecutionConfig.model_validate_json(snapshot_content)
        snapshot_sha256 = hashlib.sha256(snapshot_content.encode("utf-8")).hexdigest()
        return {
            "path": str(snapshot_path),
            "sha256": snapshot_sha256,
            "overrides": metadata.get("overrides", []),
        }

    def _collect_gates(self) -> list[HITLGate]:
        gates: list[HITLGate] = list(self.spec.hitl_gates)
        if self.spec.default_profile:
            gates = gates + list(self.spec.default_profile.hitl_gates)
        return [gate.model_copy() for gate in gates]

    def _evaluate_hitl_gates(
        self,
        phase_filter: str | None,
        gates: list[HITLGate],
        gate_events: list[AuditEvent],
        run_id: str,
    ) -> None:
        for gate in gates:
            if gate.status != HITLGateStatus.PENDING:
                continue
            gate_phase = self._phase_key(gate.phase) if gate.phase is not None else None
            if gate_phase != phase_filter:
                continue
            if self.hitl_approver is not None:
                gate.status = self.hitl_approver(gate)
            else:
                gate.status = HITLGateStatus.WAIVED
            level = (
                AuditEventLevel.WARNING
                if gate.status == HITLGateStatus.WAIVED
                else AuditEventLevel.INFO
            )
            gate_events.append(
                AuditEvent(
                    event_id=f"{run_id}:hitl_gate:{gate.id}",
                    run_id=run_id,
                    phase=gate.phase,
                    level=level,
                    message=f"HITL gate '{gate.id}' resolved: {gate.status.value}.",
                    payload={
                        "gate_id": gate.id,
                        "status": gate.status.value,
                        "required": gate.required,
                        "question": gate.question,
                    },
                )
            )
            if gate.required and gate.status == HITLGateStatus.REJECTED:
                raise HITLGateBlockedError(gate)

    def _evaluate_phase_evals(
        self,
        phase_filter: str,
        eval_results: list[EvalResult],
        eval_events: list[AuditEvent],
        run_id: str,
        state: PipelineState,
    ) -> None:
        import sys

        for phase_eval in self.spec.evals:
            if self._phase_key(phase_eval.phase) != phase_filter:
                continue
            assertion = self.eval_assertions.get(phase_eval.id)
            if assertion is None and phase_eval.assertion:
                source = _import_registry_source(phase_eval.assertion)
                if callable(source):
                    assertion = cast(PhaseEvalAssertion, source)
            if assertion is None:
                print(
                    f"[EVAL WARNING] No assertion found for eval '{phase_eval.id}'; skipping.",
                    file=sys.stderr,
                )
                continue
            result = assertion(state)
            result = result.model_copy(update={"eval_id": phase_eval.id, "phase": phase_eval.phase})
            eval_results.append(result)
            level = AuditEventLevel.INFO if result.passed else AuditEventLevel.WARNING
            eval_events.append(
                AuditEvent(
                    event_id=f"{run_id}:eval:{phase_eval.id}",
                    run_id=run_id,
                    phase=phase_eval.phase,
                    level=level,
                    message=f"Eval '{phase_eval.id}' {'passed' if result.passed else 'failed'} on phase '{phase_filter}'.",
                    payload={
                        "eval_id": phase_eval.id,
                        "passed": result.passed,
                        "score": result.score,
                        "detail": result.detail,
                        "required": phase_eval.required,
                        "weight": phase_eval.weight,
                    },
                )
            )
            if phase_eval.required and not result.passed:
                raise PhaseEvalFailedError(result)

    def _make_pipeline_run(
        self,
        run_id: str,
        objective: str,
        status: PipelineRunStatus,
        run_dir: Path,
        mcda_result: object,
        execution_snapshot: dict[str, object] | None,
        gate_events: list[AuditEvent],
        eval_events: list[AuditEvent] | None = None,
    ) -> PipelineRun:
        audit_events: list[AuditEvent] = [
            AuditEvent(
                event_id=f"{run_id}:pipeline_spec_registered",
                run_id=run_id,
                level=AuditEventLevel.INFO,
                message="PipelineSpec registrado para a execucao.",
                payload={"spec_id": self.spec.id},
            ),
            *(
                [self._execution_config_event(run_id, execution_snapshot)]
                if execution_snapshot
                else []
            ),
            *gate_events,
            *(eval_events or []),
            *self._mcda_audit_events(run_id, mcda_result),
        ]
        return PipelineRun(
            run_id=run_id,
            spec_id=self.spec.id,
            task_profile_id=self.spec.default_profile.id if self.spec.default_profile else None,
            objective=objective,
            status=status,
            run_dir=str(run_dir),
            completed_at=datetime.utcnow(),
            decision=mcda_result.decision if isinstance(mcda_result, ValidationResult) else None,
            triggered_rules=(
                mcda_result.triggered_rules if isinstance(mcda_result, ValidationResult) else []
            ),
            audit_events=audit_events,
        )

    def _fire_event(self, event: PipelineEvent) -> None:
        import sys

        for hook in self.event_hooks:
            try:
                hook(event)
            except Exception as exc:
                print(
                    f"[HOOK WARNING] Event hook failed for '{event.event_type}': {exc}",
                    file=sys.stderr,
                )

    @staticmethod
    def _execution_config_event(run_id: str, execution_snapshot: dict[str, object]) -> AuditEvent:
        return AuditEvent(
            event_id=f"{run_id}:execution_config_registered",
            run_id=run_id,
            level=AuditEventLevel.INFO,
            message="Execution config efetivo registrado para auditoria.",
            payload=execution_snapshot,
        )

    def _ensure_supported_spec(self, spec: PipelineSpec) -> None:
        if not spec.phases:
            raise UnsupportedPipelineSpecError(
                "PipelineSpec.phases must include at least one phase."
            )

        phase_keys = [self._phase_key(phase) for phase in spec.phases]
        if len(set(phase_keys)) != len(phase_keys):
            raise UnsupportedPipelineSpecError("PipelineSpec.phases cannot contain duplicates.")

        for phase_key in phase_keys:
            if phase_key not in self.phase_handlers:
                raise UnsupportedPipelineSpecError(
                    f"No handler registered for phase '{phase_key}'."
                )

        default_order = {
            self._phase_key(phase): index for index, phase in enumerate(DEFAULT_PIPELINE_PHASES)
        }
        phase_indexes = [default_order[phase] for phase in phase_keys if phase in default_order]
        if phase_indexes != sorted(phase_indexes):
            raise UnsupportedPipelineSpecError(
                "PipelineSpec.phases must follow the default phase dependency order."
            )

        selected_phases = set(phase_keys)
        dependencies = {
            **_PHASE_DEPENDENCIES,
            **{
                self._phase_key(phase): tuple(
                    self._phase_key(dependency) for dependency in phase_dependencies
                )
                for phase, phase_dependencies in spec.phase_dependencies.items()
            },
        }

        for phase in spec.phases:
            phase_key = self._phase_key(phase)
            missing_dependencies = [
                dependency
                for dependency in dependencies.get(phase_key, ())
                if dependency not in selected_phases
            ]
            if missing_dependencies:
                missing = ", ".join(missing_dependencies)
                raise UnsupportedPipelineSpecError(
                    f"Pipeline phase '{phase_key}' requires missing dependencies: {missing}."
                )

        if (
            spec.default_profile
            and [self._phase_key(phase) for phase in spec.default_profile.phases] != phase_keys
        ):
            raise UnsupportedPipelineSpecError(
                "PipelineSpec.default_profile.phases must match PipelineSpec.phases."
            )

    def _run_phase(
        self,
        phase: PipelinePhaseId,
        run_dir: Path,
        prompt_summaries: list[dict[str, str]],
        state: PipelineState,
    ) -> None:
        phase_key = self._phase_key(phase)
        handler = self.phase_handlers.get(phase_key)
        if handler is None:
            raise UnsupportedPipelineSpecError(f"No handler registered for phase '{phase_key}'.")
        handler(run_dir, prompt_summaries, state)

    def _default_phase_handlers(self) -> dict[str, PhaseHandler]:
        return {
            self._phase_key(PipelinePhase.ASK): self._run_ask_phase,
            self._phase_key(PipelinePhase.PLAN): self._run_plan_phase,
            self._phase_key(PipelinePhase.GENERATE): self._run_generate_phase,
            self._phase_key(PipelinePhase.SHAPE): self._run_shape_phase,
            self._phase_key(PipelinePhase.CRITIQUE): self._run_critique_phase,
            self._phase_key(PipelinePhase.CORRECT): self._run_correct_phase,
            self._phase_key(PipelinePhase.AUDIT): self._run_audit_phase,
            self._phase_key(PipelinePhase.HARDEN): self._run_harden_phase,
            self._phase_key(PipelinePhase.VALIDATE): self._run_validate_phase,
            self._phase_key(PipelinePhase.DEEP_RESEARCH): self._run_deep_research_phase,
        }

    def _run_ask_phase(
        self, run_dir: Path, prompt_summaries: list[dict[str, str]], state: PipelineState
    ) -> None:
        prompt_text = ask_prompt(
            self._state_str(state, "objective"),
            f"{self._state_str(state, 'input_contract')}\n\n{self._state_str(state, 'context')}",
            self._state_list(state, "constraints"),
        )
        state["ask"] = self._generate_phase(
            run_dir, prompt_summaries, PipelinePhase.ASK, prompt_text
        )

    def _run_plan_phase(
        self, run_dir: Path, prompt_summaries: list[dict[str, str]], state: PipelineState
    ) -> None:
        prompt_text = plan_prompt(self._state_str(state, "ask"))
        state["plan"] = self._generate_phase(
            run_dir, prompt_summaries, PipelinePhase.PLAN, prompt_text
        )

    def _run_generate_phase(
        self, run_dir: Path, prompt_summaries: list[dict[str, str]], state: PipelineState
    ) -> None:
        prompt_text = generate_prompt(
            f"{self._state_str(state, 'plan')}\n\nRegras gerais:\n{self._state_str(state, 'generic_rules')}"
        )
        state["generated"] = self._generate_phase(
            run_dir, prompt_summaries, PipelinePhase.GENERATE, prompt_text
        )

    def _run_shape_phase(
        self, run_dir: Path, prompt_summaries: list[dict[str, str]], state: PipelineState
    ) -> None:
        prompt_text = shape_prompt(
            self._state_str(state, "generated"), self._state_str(state, "output_contract")
        )
        state["shaped"] = self._generate_phase(
            run_dir, prompt_summaries, PipelinePhase.SHAPE, prompt_text
        )

    def _run_critique_phase(
        self, run_dir: Path, prompt_summaries: list[dict[str, str]], state: PipelineState
    ) -> None:
        prompt_text = critique_prompt(self._state_str(state, "shaped"))
        state["critique"] = self._generate_phase(
            run_dir, prompt_summaries, PipelinePhase.CRITIQUE, prompt_text
        )

    def _run_correct_phase(
        self, run_dir: Path, prompt_summaries: list[dict[str, str]], state: PipelineState
    ) -> None:
        prompt_text = correct_prompt(
            self._state_str(state, "shaped"), self._state_str(state, "critique")
        )
        state["corrected"] = self._generate_phase(
            run_dir, prompt_summaries, PipelinePhase.CORRECT, prompt_text
        )

    def _run_audit_phase(
        self, run_dir: Path, prompt_summaries: list[dict[str, str]], state: PipelineState
    ) -> None:
        prompt_text = audit_prompt(self._state_str(state, "corrected"))
        audit_raw = self._generate_phase(
            run_dir, prompt_summaries, PipelinePhase.AUDIT, prompt_text
        )
        audit = self._parse_audit(audit_raw)
        (run_dir / "audit.json").write_text(
            json.dumps(audit.model_dump(), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

        # Motor primario MCDA v1.0.0 — unico motor de decisao do pipeline
        mcda_cfg = load_mcda(self.config)
        mcda_result = evaluate_mcda(audit, mcda_cfg)
        state["audit"] = audit
        state["mcda_result"] = mcda_result
        (run_dir / "mcda_result.json").write_text(
            json.dumps(mcda_result.model_dump(), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    def _run_harden_phase(
        self, run_dir: Path, prompt_summaries: list[dict[str, str]], state: PipelineState
    ) -> None:
        mcda_result = self._state_validation_result(state, "mcda_result")
        prompt_text = harden_prompt(self._state_str(state, "corrected"), mcda_result.explanation)
        state["harden"] = self._generate_phase(
            run_dir, prompt_summaries, PipelinePhase.HARDEN, prompt_text
        )

    def _run_validate_phase(
        self, run_dir: Path, prompt_summaries: list[dict[str, str]], state: PipelineState
    ) -> None:
        del prompt_summaries
        mcda_result = self._state_validation_result(state, "mcda_result")
        self._save_text(run_dir, PipelinePhase.VALIDATE, mcda_result.model_dump_json(indent=2))

    def _run_deep_research_phase(
        self, run_dir: Path, prompt_summaries: list[dict[str, str]], state: PipelineState
    ) -> None:
        mcda_result = self._state_validation_result(state, "mcda_result")
        prompt_text = deep_research_prompt(
            self._state_str(state, "harden"), mcda_result.explanation
        )
        state["deep_research"] = self._generate_phase(
            run_dir, prompt_summaries, PipelinePhase.DEEP_RESEARCH, prompt_text
        )

    def _generate_phase(
        self,
        run_dir: Path,
        prompt_summaries: list[dict[str, str]],
        phase: PipelinePhaseId,
        prompt_text: str,
    ) -> str:
        self._record_prompt_summary(prompt_summaries, phase, prompt_text)
        result = self.provider.generate(prompt_text, system=self._phase_key(phase).upper())
        self._save_text(run_dir, phase, result)
        return result

    @staticmethod
    def _phase_key(phase: PipelinePhaseId) -> str:
        return phase_key(phase)

    @staticmethod
    def _state_str(state: PipelineState, key: str) -> str:
        value = state.get(key)
        if not isinstance(value, str):
            raise UnsupportedPipelineSpecError(f"Pipeline state missing string value '{key}'.")
        return value

    @staticmethod
    def _state_list(state: PipelineState, key: str) -> list[str]:
        value = state.get(key)
        if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
            raise UnsupportedPipelineSpecError(f"Pipeline state missing string list '{key}'.")
        return value

    @staticmethod
    def _state_validation_result(state: PipelineState, key: str) -> ValidationResult:
        value = state.get(key)
        if not isinstance(value, ValidationResult):
            raise UnsupportedPipelineSpecError(
                f"Pipeline state missing ValidationResult value '{key}'."
            )
        return value

    @staticmethod
    def _mcda_audit_events(run_id: str, mcda_result: object) -> list[AuditEvent]:
        if not isinstance(mcda_result, ValidationResult):
            return []
        return [
            AuditEvent(
                event_id=f"{run_id}:mcda_decision",
                run_id=run_id,
                phase=PipelinePhase.VALIDATE,
                level=AuditEventLevel.INFO,
                message="Decisao MCDA calculada.",
                payload={
                    "decision": mcda_result.decision.value,
                    "triggered_rules": [rule.model_dump() for rule in mcda_result.triggered_rules],
                },
            )
        ]

    @staticmethod
    def _record_prompt_summary(
        records: list[dict[str, str]], phase: PipelinePhaseId, prompt: str
    ) -> None:
        compact = re.sub(r"\s+", " ", prompt).strip()
        records.append(
            {
                "phase": PipelineRunner._phase_key(phase),
                "summary": compact[:280],
            }
        )

    @staticmethod
    def _save_prompt_summaries(run_dir: Path, records: list[dict[str, str]]) -> None:
        lines = ["# Prompt Summary", ""]
        for record in records:
            lines.append(f"## {record['phase'].upper()}")
            lines.append(record["summary"])
            lines.append("")
        (run_dir / "prompt_summary.md").write_text("\n".join(lines), encoding="utf-8")

    @staticmethod
    def _to_mnemonic(text: str) -> str:
        normalized = re.sub(r"[^a-zA-Z0-9]+", "-", text.strip().lower()).strip("-")
        return normalized[:64] or "task"

    @staticmethod
    def _parse_audit(raw: str) -> AuditResult:
        try:
            parsed = json.loads(raw)
            return AuditResult.model_validate(parsed)
        except Exception:
            import sys

            print(
                "\n[AUDIT WARNING] Nao foi possivel parsear o JSON da auditoria.\n"
                "Usando valores de fallback (7.0 em todos os criterios).\n"
                "O resultado desta run NAO deve ser aceito sem revisao HITL manual.\n",
                file=sys.stderr,
            )
            return AuditResult(
                metrics={
                    "precisao_tecnica": 7.0,
                    "seguranca_compliance": 7.0,
                    "completude": 7.0,
                    "clareza_formato": 7.0,
                    "clareza": 7.0,
                    "coerencia": 7.0,
                    "aplicabilidade": 7.0,
                    "nota_geral": 7.0,
                },
                flags={"inconsistencia_detectada": False, "audit_fallback": True},
                notes={
                    "fallback": "[AUDIT FALLBACK ATIVO] JSON invalido recebido do LLM. Notas sinteticas. Requer revisao HITL."
                },
            )


def validate_audit_file(audit_file: Path, config: AppConfig | None = None) -> ValidationResult:
    """Valida um audit.json usando o motor primario MCDA v1.0.0."""
    cfg = config or AppConfig()
    data = json.loads(audit_file.read_text(encoding="utf-8"))
    audit = AuditResult.model_validate(data)
    mcda_cfg = load_mcda(cfg)
    return evaluate_mcda(audit, mcda_cfg)
