"""Motor MCDA (Multi-Criteria Decision Analysis) para calculo do Global Score.

Carrega pesos e limiares de artifacts/schemas/mcda_weights.yaml e aplica
a formula ponderada sobre as metricas do AuditResult, emitindo ValidationResult
com decisao ACCEPT | REFINE | REJECT e explicacao estruturada.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from .models import AuditResult, Decision, RuleTrigger, ValidationResult

# ─────────────────────────────────────────────────────────────────────────────
# Mapeamento canonico: chave do YAML → metrica do AuditResult
# ─────────────────────────────────────────────────────────────────────────────
_CRITERION_KEYS = ("precisao_tecnica", "seguranca_compliance", "completude", "clareza_formato")

# Valor sentinel em instance_weights que indica uso dos pesos padrao de mcda_weights
_REF_DEFAULT = "mcda_weights"

_CRITERION_LABELS: dict[str, str] = {
    "precisao_tecnica": "C1 Precisao Tecnica",
    "seguranca_compliance": "C2 Seguranca & Compliance",
    "completude": "C3 Completude",
    "clareza_formato": "C4 Clareza e Formato",
}


@dataclass(frozen=True)
class MCDAConfig:
    """Configuracao carregada do mcda_weights.yaml."""

    weights: dict[str, float]
    accept_min_global: float
    accept_min_seguranca: float
    accept_min_precisao: float
    refine_min_global: float
    refine_min_seguranca: float
    vitalia_escalada_c2: float | None = None


def load_mcda_config(
    weights_path: Path,
    execution_instance_type: str = "projecta",
) -> MCDAConfig:
    """Carrega pesos e limiares do mcda_weights.yaml.

    Se execution_instance_type tiver entrada em instance_weights, usa esses
    pesos. Instancias com _ref: mcda_weights usam o bloco padrao.
    """
    raw: dict[str, Any] = yaml.safe_load(weights_path.read_text(encoding="utf-8")) or {}

    default_weights: dict[str, float] = {
        key: float(raw.get("mcda_weights", {}).get(key, 0.0)) for key in _CRITERION_KEYS
    }

    instance_block = raw.get("instance_weights", {}).get(execution_instance_type, {})
    if instance_block.get("_ref") == _REF_DEFAULT or not instance_block:
        active_weights = default_weights
    else:
        active_weights = {
            key: float(instance_block.get(key, default_weights[key])) for key in _CRITERION_KEYS
        }

    vitalia_escalada: float | None = None
    if execution_instance_type == "vitalia":
        vitalia_escalada = float(
            instance_block.get("escalada_automatica_hitl_l2_se_c2_abaixo", 9.5)
        )

    thresholds = raw.get("mcda_thresholds", {})
    accept = thresholds.get("accept", {})
    refine = thresholds.get("refine", {})

    return MCDAConfig(
        weights=active_weights,
        accept_min_global=float(accept.get("min_global_score", 9.2)),
        accept_min_seguranca=float(accept.get("min_seguranca_compliance", 9.5)),
        accept_min_precisao=float(accept.get("min_precisao_tecnica", 9.0)),
        refine_min_global=float(refine.get("min_global_score", 8.0)),
        refine_min_seguranca=float(refine.get("min_seguranca_compliance", 9.0)),
        vitalia_escalada_c2=vitalia_escalada,
    )


def compute_global_score(audit: AuditResult, weights: dict[str, float]) -> float:
    """Calcula o Global Score S = sum(C_i * W_i)."""
    total = 0.0
    for key in _CRITERION_KEYS:
        score = audit.metrics.get(key)
        if score is None:
            score = 0.0
        total += score * weights.get(key, 0.0)
    return round(total, 4)


def evaluate_mcda(
    audit: AuditResult,
    config: MCDAConfig,
    execution_instance_type: str = "projecta",
) -> ValidationResult:
    """Aplica a logica MCDA e retorna ValidationResult com decisao e explicacao."""
    global_score = compute_global_score(audit, config.weights)
    c2 = audit.metrics.get("seguranca_compliance", 0.0)
    c1 = audit.metrics.get("precisao_tecnica", 0.0)

    triggered: list[RuleTrigger] = []
    lines: list[str] = []

    # Calculo e log do score
    lines.append(f"Global Score S = {global_score:.4f}")
    for key in _CRITERION_KEYS:
        label = _CRITERION_LABELS[key]
        nota = audit.metrics.get(key, 0.0)
        peso = config.weights.get(key, 0.0)
        lines.append(f"  {label}: nota={nota:.2f}, peso={peso:.2f}, parcela={nota * peso:.4f}")

    # Verificacao dos interlocks
    interlocks_ok = True
    if c2 < config.accept_min_seguranca:
        interlocks_ok = False
        lines.append(
            f"INTERLOCK FALHOU: C2 seguranca_compliance={c2:.2f} < minimo={config.accept_min_seguranca}"
        )
        triggered.append(
            RuleTrigger(
                rule_id="interlock_c2_seguranca",
                action="REJECT_OR_REFINE",
                reason=f"seguranca_compliance {c2:.2f} abaixo do minimo de aceite {config.accept_min_seguranca}",
            )
        )

    if c1 < config.accept_min_precisao:
        interlocks_ok = False
        lines.append(
            f"INTERLOCK FALHOU: C1 precisao_tecnica={c1:.2f} < minimo={config.accept_min_precisao}"
        )
        triggered.append(
            RuleTrigger(
                rule_id="interlock_c1_precisao",
                action="REJECT_OR_REFINE",
                reason=f"precisao_tecnica {c1:.2f} abaixo do minimo de aceite {config.accept_min_precisao}",
            )
        )

    # Vitalia: escalada automatica
    if (
        execution_instance_type == "vitalia"
        and config.vitalia_escalada_c2 is not None
        and c2 < config.vitalia_escalada_c2
    ):
        triggered.append(
            RuleTrigger(
                rule_id="vitalia_escalada_hitl_l2",
                action="ESCALATE_L2",
                reason=f"vitalia: C2={c2:.2f} abaixo de {config.vitalia_escalada_c2}; escalar para HITL L2.",
            )
        )
        lines.append(
            f"VITALIA ESCALADA: C2={c2:.2f} < {config.vitalia_escalada_c2} -> HITL L2 requerido"
        )

    # Decisao principal
    if global_score >= config.accept_min_global and interlocks_ok:
        decision = Decision.ACCEPT
        triggered.append(
            RuleTrigger(
                rule_id="mcda_accept",
                action="ACCEPT",
                reason=f"Global Score {global_score:.4f} >= {config.accept_min_global} e interlocks satisfeitos.",
            )
        )
    elif global_score >= config.refine_min_global and c2 >= config.refine_min_seguranca:
        decision = Decision.REFINE
        triggered.append(
            RuleTrigger(
                rule_id="mcda_refine",
                action="REFINE",
                reason=f"Global Score {global_score:.4f} entre {config.refine_min_global} e {config.accept_min_global}, ou interlock parcialmente falhou.",
            )
        )
    else:
        decision = Decision.REJECT
        triggered.append(
            RuleTrigger(
                rule_id="mcda_reject",
                action="REJECT",
                reason=f"Global Score {global_score:.4f} < {config.refine_min_global} ou C2 {c2:.2f} < {config.refine_min_seguranca}.",
            )
        )

    lines.append(f"Decisao MCDA: {decision.value}")
    explanation = "\n".join(lines)

    return ValidationResult(
        decision=decision,
        triggered_rules=triggered,
        explanation=explanation,
    )
