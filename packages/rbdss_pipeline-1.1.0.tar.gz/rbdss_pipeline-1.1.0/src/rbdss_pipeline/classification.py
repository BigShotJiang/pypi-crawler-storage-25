from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ClassificationValidation:
    valid: bool
    errors: list[str] = field(default_factory=list)


def load_json(path: Path) -> dict[str, Any]:
    return dict(json.loads(path.read_text(encoding="utf-8")))


def allowed_values_from_schema(schema: dict[str, Any], field_name: str) -> set[str]:
    properties = schema.get("properties", {})
    field_schema = properties.get(field_name, {})
    values = field_schema.get("enum", [])
    return {str(value) for value in values}


def validate_minimal_classification(
    classification: dict[str, Any],
    schema: dict[str, Any],
) -> ClassificationValidation:
    errors: list[str] = []

    for field_name in schema.get("required", []):
        if field_name not in classification:
            errors.append(f"missing required field: {field_name}")

    allowed_keys = set(schema.get("properties", {}).keys())
    for field_name in classification:
        if field_name not in allowed_keys:
            errors.append(f"unexpected field: {field_name}")

    for field_name, field_schema in schema.get("properties", {}).items():
        if field_name not in classification:
            continue

        value = classification[field_name]
        expected_type = field_schema.get("type")
        if expected_type == "string" and not isinstance(value, str):
            errors.append(f"field {field_name} must be a string")
        if expected_type == "array" and not isinstance(value, list):
            errors.append(f"field {field_name} must be an array")

        enum_values = field_schema.get("enum")
        if enum_values and value not in enum_values:
            errors.append(
                f"field {field_name} has invalid value {value!r}; allowed: {', '.join(enum_values)}"
            )

    project_relation = classification.get("project_relation")
    if project_relation == "owned_by_project":
        for field_name in ("project_id", "project_stage_id"):
            if not classification.get(field_name):
                errors.append(f"{field_name} is required when project_relation is owned_by_project")
    elif project_relation == "referenced_by_project":
        referenced = classification.get("referenced_project_ids")
        if not isinstance(referenced, list) or not referenced:
            errors.append(
                "referenced_project_ids is required when project_relation is referenced_by_project"
            )
    elif project_relation == "standalone":
        for field_name in ("project_stage_id", "referenced_project_ids"):
            if field_name in classification:
                errors.append(f"{field_name} is not allowed when project_relation is standalone")

    return ClassificationValidation(valid=not errors, errors=errors)


def validate_minimal_classification_file(
    classification_file: Path,
    schema_file: Path = Path("artifacts/schemas/classification_schema_minimal.json"),
) -> ClassificationValidation:
    classification = load_json(classification_file)
    schema = load_json(schema_file)
    return validate_minimal_classification(classification=classification, schema=schema)


FULL_REQUIRED_LAYERS = {
    "classification_minimal",
}

DEFAULT_REQUIRED_FIELDS = {
    "lifecycle_status",
    "horizon",
    "delivery_type",
    "primary_audience",
    "pipeline_route",
    "next_action_owner",
}

GOVERNANCE_REQUIRED_FIELDS = {
    "regulatory_sensitivity",
    "reuse_policy",
    "sanitization_status",
    "blocked_by",
}

LLMOPS_REQUIRED_FIELDS = {
    "model_family",
    "model_role",
    "prompt_artifact",
    "input_contract_path",
    "output_contract_path",
    "ruleset_path",
    "artifact_manifest_path",
    "rb_dss_ruleset_path",
    "artifact_hash",
    "human_approval_required",
}

DECISION_REQUIRED_FIELDS = {
    "evidence_level",
    "rb_dss_decision",
    "rules_fired",
    "hitl_required",
    "hitl_override",
    "hitl_decision",
    "hitl_level",
    "escalation_triggers",
    "downgrade_log_path",
    "decided_at",
}

ENUMS = {
    "lifecycle_status": {"draft", "active", "blocked", "completed", "superseded", "archived"},
    "horizon": {"now", "next", "later", "archive"},
    "pipeline_route": {"main_10_step", "urgent_4_step", "validate_local", "custom"},
    "next_action_owner": {"hitl", "codex", "local_engine", "external_tool", "business_owner"},
    "regulatory_sensitivity": {
        "none",
        "internal_policy",
        "regulated_domain",
        "personal_data",
        "sensitive_business_data",
    },
    "reuse_policy": {"none", "internal_reuse", "sanitized_reuse", "public_reuse"},
    "sanitization_status": {"not_required", "required", "in_progress", "completed", "blocked"},
    "evidence_level": {"exploratory", "internally_audited", "validated", "homologated"},
    "rb_dss_decision": {"ACCEPT", "REFINE", "REJECT", "BLOCKED"},
    "hitl_decision": {"pending", "accepted", "accepted_with_risk", "rejected", "blocked"},
    "hitl_level": {"L1", "L2", "L3"},
}


def _require_fields(layer_name: str, layer: dict[str, Any], fields: set[str]) -> list[str]:
    return [f"{layer_name}.{field_name} is required" for field_name in sorted(fields - set(layer))]


def _validate_enum(layer_name: str, field_name: str, value: Any, errors: list[str]) -> None:
    allowed = ENUMS.get(field_name)
    if allowed and value not in allowed:
        errors.append(
            f"{layer_name}.{field_name} has invalid value {value!r}; allowed: {', '.join(sorted(allowed))}"
        )


def _validate_existing_path(
    layer_name: str, field_name: str, value: Any, errors: list[str]
) -> None:
    if value is None:
        return
    if not isinstance(value, str) or not value:
        errors.append(f"{layer_name}.{field_name} must be a non-empty path string or null")
        return
    if not Path(value).exists():
        errors.append(f"{layer_name}.{field_name} path does not exist: {value}")


def validate_full_classification(
    classification: dict[str, Any],
    minimal_schema: dict[str, Any],
) -> ClassificationValidation:
    errors: list[str] = []

    missing_layers = FULL_REQUIRED_LAYERS - set(classification)
    errors.extend(f"missing required layer: {layer}" for layer in sorted(missing_layers))

    unexpected_layers = set(classification) - {
        "classification_minimal",
        "classification_defaults",
        "governance_trace",
        "llmops_trace",
        "decision_trace",
    }
    errors.extend(f"unexpected layer: {layer}" for layer in sorted(unexpected_layers))

    if errors:
        return ClassificationValidation(valid=False, errors=errors)

    minimal = classification["classification_minimal"]
    if not isinstance(minimal, dict):
        return ClassificationValidation(
            valid=False,
            errors=["classification_minimal must be an object"],
        )

    minimal_result = validate_minimal_classification(minimal, minimal_schema)
    errors.extend(f"classification_minimal.{error}" for error in minimal_result.errors)

    defaults = classification.get("classification_defaults", {})
    governance = classification.get("governance_trace", {})
    llmops = classification.get("llmops_trace", {})
    decision = classification.get("decision_trace", {})

    for layer_name, layer in (
        ("classification_defaults", defaults),
        ("governance_trace", governance),
        ("llmops_trace", llmops),
        ("decision_trace", decision),
    ):
        if not isinstance(layer, dict):
            errors.append(f"{layer_name} must be an object")

    if errors:
        return ClassificationValidation(valid=False, errors=errors)

    if defaults:
        errors.extend(_require_fields("classification_defaults", defaults, DEFAULT_REQUIRED_FIELDS))
    if governance:
        errors.extend(_require_fields("governance_trace", governance, GOVERNANCE_REQUIRED_FIELDS))
    if llmops:
        errors.extend(_require_fields("llmops_trace", llmops, LLMOPS_REQUIRED_FIELDS))
    if decision:
        errors.extend(_require_fields("decision_trace", decision, DECISION_REQUIRED_FIELDS))

    for layer_name, layer in (
        ("classification_defaults", defaults),
        ("governance_trace", governance),
        ("decision_trace", decision),
    ):
        for field_name, value in layer.items():
            _validate_enum(layer_name, field_name, value, errors)

    for field_name in (
        "prompt_artifact",
        "input_contract_path",
        "output_contract_path",
        "ruleset_path",
        "artifact_manifest_path",
        "rb_dss_ruleset_path",
    ):
        _validate_existing_path("llmops_trace", field_name, llmops.get(field_name), errors)

    if (
        llmops
        and "human_approval_required" in llmops
        and not isinstance(llmops.get("human_approval_required"), bool)
    ):
        errors.append("llmops_trace.human_approval_required must be a boolean")

    if decision:
        if not isinstance(decision.get("rules_fired", []), list):
            errors.append("decision_trace.rules_fired must be an array")
        if not isinstance(decision.get("escalation_triggers", []), list):
            errors.append("decision_trace.escalation_triggers must be an array")
        for field_name in ("hitl_required", "hitl_override"):
            if field_name in decision and not isinstance(decision.get(field_name), bool):
                errors.append(f"decision_trace.{field_name} must be a boolean")
        if decision.get("hitl_override") and not decision.get("downgrade_log_path"):
            errors.append(
                "decision_trace.downgrade_log_path is required when hitl_override is true"
            )

    confidentiality = minimal.get("confidentiality")
    reuse_policy = governance.get("reuse_policy") if governance else None
    sanitization_status = governance.get("sanitization_status") if governance else None

    if governance:
        if confidentiality in {"restricted", "sensitive"} and reuse_policy == "public_reuse":
            errors.append("public_reuse is not allowed for restricted or sensitive classification")
        if reuse_policy == "public_reuse" and (
            confidentiality != "public_ok"
            or sanitization_status not in {"completed", "not_required"}
        ):
            errors.append(
                "public_reuse requires public_ok confidentiality and completed/not_required sanitization"
            )

        risk_order = {"low": 0, "medium": 1, "high": 2, "critical": 3}
        if governance.get("regulatory_sensitivity") != "none":
            risk_tier = str(minimal.get("risk_tier", ""))
            if risk_order.get(risk_tier, -1) < risk_order["medium"]:
                errors.append(
                    "regulatory_sensitivity different from none requires risk_tier at least medium"
                )

    execution_instance_type = minimal.get("execution_instance_type")

    if decision:
        hitl_level = decision.get("hitl_level")
        escalation_triggers = set(decision.get("escalation_triggers") or [])
        if execution_instance_type == "regulara" and hitl_level == "L1":
            errors.append("regulara requires final HITL level L2 or L3")
        if execution_instance_type == "vitalia":
            sensitive_context = confidentiality in {"restricted", "sensitive"}
            if (
                sensitive_context
                and hitl_level == "L1"
                and "dado_sensivel" not in escalation_triggers
            ):
                errors.append(
                    "vitalia with restricted or sensitive data requires escalation trigger dado_sensivel"
                )

    return ClassificationValidation(valid=not errors, errors=errors)


def validate_full_classification_file(
    classification_file: Path,
    schema_file: Path = Path("artifacts/schemas/classification_schema_minimal.json"),
) -> ClassificationValidation:
    classification = load_json(classification_file)
    schema = load_json(schema_file)
    return validate_full_classification(classification=classification, minimal_schema=schema)
