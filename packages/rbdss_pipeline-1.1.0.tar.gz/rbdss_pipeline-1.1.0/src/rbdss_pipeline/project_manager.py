from __future__ import annotations

import json
import re
from datetime import date
from pathlib import Path
from typing import Any


def create_project(
    project_id: str,
    project_name: str,
    objetivo: str,
    contexto: str,
    *,
    projects_dir: Path = Path("projects"),
) -> dict[str, Any]:
    """Create a lightweight project manifest on disk."""
    project_dir = projects_dir / project_id
    project_dir.mkdir(parents=True, exist_ok=True)
    (project_dir / "stages").mkdir(exist_ok=True)

    manifest = {
        "project_id": project_id,
        "project_name": project_name,
        "status": "em_planejamento_execucao",
        "created_at": date.today().isoformat(),
        "objetivo": objetivo,
        "contexto": contexto,
        "stages": [],
    }
    _write_project_files(project_dir, manifest)
    return {"project_dir": str(project_dir), "manifest": manifest}


def add_stage(
    project_id: str,
    stage_id: str,
    objetivo: str,
    instancia_pipeline_sugerida: str,
    *,
    projects_dir: Path = Path("projects"),
) -> dict[str, Any]:
    """Add a planned stage to an existing project manifest."""
    project_dir = projects_dir / project_id
    manifest_path = project_dir / "project_manifest.json"
    manifest = _read_manifest(manifest_path)

    stage_slug = _slug(stage_id)
    existing_count = len(manifest.get("stages", []))
    stage_dir = project_dir / "stages" / f"{existing_count:02d}-{stage_slug}"
    stage_dir.mkdir(parents=True, exist_ok=True)

    stage = {
        "project_stage_id": stage_id,
        "status": "planejada",
        "objetivo": objetivo,
        "instancia_pipeline_sugerida": instancia_pipeline_sugerida,
        "stage_dir": str(stage_dir),
        "linked_run_path": None,
    }
    manifest.setdefault("stages", []).append(stage)
    _write_project_files(project_dir, manifest)

    (stage_dir / "stage_brief.md").write_text(_stage_brief(stage), encoding="utf-8")
    (stage_dir / "linked_runs.md").write_text(
        f"# Linked Runs - {stage_id}\n\n| Tipo | Path | Status |\n| --- | --- | --- |\n",
        encoding="utf-8",
    )
    return {"stage_dir": str(stage_dir), "stage": stage}


def materialize_stage(
    project_id: str,
    stage_id: str,
    run_path: str,
    *,
    projects_dir: Path = Path("projects"),
) -> dict[str, Any]:
    """Link a concrete run path to a project stage."""
    project_dir = projects_dir / project_id
    manifest_path = project_dir / "project_manifest.json"
    manifest = _read_manifest(manifest_path)

    target_stage: dict[str, Any] | None = None
    for stage in manifest.get("stages", []):
        if stage.get("project_stage_id") == stage_id:
            target_stage = stage
            break

    if target_stage is None:
        raise ValueError(f"Stage '{stage_id}' not found in project '{project_id}'.")

    target_stage["status"] = "consubstanciada"
    target_stage["linked_run_path"] = run_path
    _write_project_files(project_dir, manifest)

    stage_dir_value = target_stage.get("stage_dir")
    if stage_dir_value:
        linked_runs = Path(stage_dir_value) / "linked_runs.md"
        with linked_runs.open("a", encoding="utf-8") as fh:
            fh.write(f"| Run principal | `{run_path}` | `consubstanciada` |\n")

    return {"project_id": project_id, "project_stage_id": stage_id, "run_path": run_path}


def _read_manifest(manifest_path: Path) -> dict[str, Any]:
    if not manifest_path.exists():
        raise FileNotFoundError(f"Project manifest not found: {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict):
        raise ValueError(f"Project manifest must be a JSON object: {manifest_path}")
    return manifest


def _write_project_files(project_dir: Path, manifest: dict[str, Any]) -> None:
    (project_dir / "project_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    (project_dir / "project_manifest.md").write_text(_manifest_markdown(manifest), encoding="utf-8")


def _manifest_markdown(manifest: dict[str, Any]) -> str:
    lines = [
        f"# Projeto - {manifest['project_name']}",
        "",
        "## Identificacao",
        "",
        "| Campo | Valor |",
        "| --- | --- |",
        f"| `project_id` | `{manifest['project_id']}` |",
        f"| Status | `{manifest['status']}` |",
        f"| Criado em | {manifest['created_at']} |",
        "",
        "## Objetivo",
        "",
        manifest["objetivo"],
        "",
        "## Contexto",
        "",
        manifest["contexto"],
        "",
        "## Etapas",
        "",
        "| Ordem | `project_stage_id` | Status | Run |",
        "| ---: | --- | --- | --- |",
    ]
    for index, stage in enumerate(manifest.get("stages", [])):
        run_path = stage.get("linked_run_path") or "A consubstanciar"
        lines.append(
            f"| {index} | `{stage['project_stage_id']}` | `{stage['status']}` | `{run_path}` |"
        )
    lines.append("")
    return "\n".join(lines)


def _stage_brief(stage: dict[str, Any]) -> str:
    return "\n".join(
        [
            f"# {stage['project_stage_id']}",
            "",
            "## Status",
            "",
            f"`{stage['status']}`",
            "",
            "## Objetivo",
            "",
            stage["objetivo"],
            "",
            "## Instancia Pipeline Sugerida",
            "",
            f"`{stage['instancia_pipeline_sugerida']}`",
            "",
        ]
    )


def _slug(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower()).strip("-") or "stage"
