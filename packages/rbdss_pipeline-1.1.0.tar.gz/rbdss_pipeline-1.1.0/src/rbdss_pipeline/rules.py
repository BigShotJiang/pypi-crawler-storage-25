from __future__ import annotations

from collections.abc import Callable
from operator import eq, ge, gt, le, lt, ne
from pathlib import Path
from typing import Any

import yaml

from .models import AuditResult, Decision, RBRule, RBRuleSet, RuleTrigger, ValidationResult

OPS: dict[str, Callable[[Any, Any], bool]] = {
    "<": lt,
    "<=": le,
    ">": gt,
    ">=": ge,
    "==": eq,
    "!=": ne,
}

ACTION_TO_DECISION: dict[str, Decision] = {
    "ACCEPT": Decision.ACCEPT,
    "REFINE": Decision.REFINE,
    "REJECT": Decision.REJECT,
    "CORRECT": Decision.REFINE,
    "ADD_EXAMPLES": Decision.REFINE,
}

DECISION_PRIORITY: dict[Decision, int] = {
    Decision.ACCEPT: 0,
    Decision.REFINE: 1,
    Decision.REJECT: 2,
}


def load_rules(path: Path) -> RBRuleSet:
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    data = raw.get("rb_dss_rules", raw)
    return RBRuleSet.model_validate(data)


def _read_metric(rule: RBRule, audit: AuditResult) -> Any:
    if rule.if_.metric in audit.metrics:
        return audit.metrics[rule.if_.metric]
    if rule.if_.metric in audit.flags:
        return audit.flags[rule.if_.metric]
    return None


def _match(rule: RBRule, audit: AuditResult) -> bool:
    operator = OPS.get(rule.if_.op)
    if operator is None:
        raise ValueError(f"Operador invalido em {rule.id}: {rule.if_.op}")

    left = _read_metric(rule, audit)
    right = rule.if_.value
    if left is None:
        return False
    return bool(operator(left, right))


def evaluate_rules(audit: AuditResult, ruleset: RBRuleSet) -> ValidationResult:
    triggered: list[RuleTrigger] = []

    for rule in ruleset.rules:
        if not _match(rule, audit):
            continue

        action = rule.then.strip().upper()
        triggered.append(RuleTrigger(rule_id=rule.id, action=action, reason=rule.reason))

    if not triggered:
        return ValidationResult(
            decision=Decision.REFINE,
            triggered_rules=[],
            explanation="Nenhuma regra positiva de aceite foi acionada; decisao default: REFINE.",
        )

    current = Decision.ACCEPT
    saw_accept = False
    for item in triggered:
        decision = ACTION_TO_DECISION.get(item.action, Decision.REFINE)
        if decision == Decision.ACCEPT:
            saw_accept = True
        if DECISION_PRIORITY[decision] > DECISION_PRIORITY[current]:
            current = decision

    if current == Decision.ACCEPT and not saw_accept:
        current = Decision.REFINE

    parts = [f"{item.rule_id} -> {item.action}" for item in triggered]
    explanation = "Regras acionadas: " + "; ".join(parts)

    return ValidationResult(decision=current, triggered_rules=triggered, explanation=explanation)
