"""Testes do motor legado RB-DSS (rules.py).

Usa YAML inline em vez de carregar artifacts/rb_dss.yaml para evitar
acoplamento ao CWD ou ao arquivo de producao.
"""

from __future__ import annotations

import textwrap

import yaml
from rbdss_pipeline.models import AuditResult, RBRuleSet
from rbdss_pipeline.rules import evaluate_rules

_RULES_YAML = textwrap.dedent("""\
    rules:
      - id: reject_low_precision
        if:
          metric: precisao_tecnica
          op: "<"
          value: 9.5
        then: REJECT
        reason: Precisao tecnica abaixo do minimo exigido.
      - id: accept_high_overall
        if:
          metric: nota_geral
          op: ">="
          value: 9.5
        then: ACCEPT
        reason: Nota geral acima do piso de aceite.
""")


def _load_inline_rules() -> RBRuleSet:
    raw = yaml.safe_load(_RULES_YAML)
    return RBRuleSet.model_validate(raw)


def test_reject_when_precision_low():
    rules = _load_inline_rules()
    audit = AuditResult(
        metrics={
            "precisao_tecnica": 8.5,
            "completude": 9.8,
            "aplicabilidade": 9.0,
            "nota_geral": 9.4,
        },
        flags={"inconsistencia_detectada": False},
    )
    result = evaluate_rules(audit, rules)
    assert result.decision.value == "REJECT"
    assert any(item.rule_id == "reject_low_precision" for item in result.triggered_rules)


def test_accept_when_all_thresholds_met():
    rules = _load_inline_rules()
    audit = AuditResult(
        metrics={
            "precisao_tecnica": 9.8,
            "completude": 9.7,
            "aplicabilidade": 9.6,
            "nota_geral": 9.8,
        },
        flags={"inconsistencia_detectada": False},
    )
    result = evaluate_rules(audit, rules)
    assert result.decision.value == "ACCEPT"
    assert any(item.rule_id == "accept_high_overall" for item in result.triggered_rules)


def test_refine_when_no_positive_accept_rule_triggers():
    rules = _load_inline_rules()
    audit = AuditResult(
        metrics={
            "precisao_tecnica": 9.6,
            "completude": 9.4,
            "aplicabilidade": 9.5,
            "nota_geral": 9.4,  # abaixo de 9.5; nenhuma regra positiva aciona
        },
        flags={"inconsistencia_detectada": False},
    )
    result = evaluate_rules(audit, rules)
    assert result.decision.value == "REFINE"
    assert result.triggered_rules == []
    assert "Nenhuma regra positiva de aceite" in result.explanation
