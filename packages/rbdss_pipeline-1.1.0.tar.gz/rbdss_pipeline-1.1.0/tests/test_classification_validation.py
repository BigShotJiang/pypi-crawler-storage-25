from pathlib import Path

from rbdss_pipeline.classification import (
    load_json,
    validate_full_classification,
    validate_full_classification_file,
    validate_minimal_classification,
    validate_minimal_classification_file,
)


def test_vitalia_run_classification_validates_against_minimal_schema():
    result = validate_minimal_classification_file(
        Path(
            "runs/implantar-taxonomia-instancias-vitalia/20260501-vitalia/classification_minimal.json"
        )
    )

    assert result.valid
    assert result.errors == []


def test_rejects_unknown_execution_instance_type():
    schema = load_json(Path("artifacts/schemas/classification_schema_minimal.json"))
    classification = {
        "execution_instance_type": "unknown",
        "portfolio": "pipeline_governance",
        "instance_class": "pipeline_governance",
        "project_relation": "standalone",
        "risk_tier": "medium",
        "confidentiality": "internal",
        "next_action_type": "audit",
    }

    result = validate_minimal_classification(classification=classification, schema=schema)

    assert not result.valid
    assert any("execution_instance_type" in error for error in result.errors)


def test_owned_by_project_requires_project_identifiers():
    schema = load_json(Path("artifacts/schemas/classification_schema_minimal.json"))
    classification = {
        "execution_instance_type": "projecta",
        "portfolio": "product_engineering",
        "instance_class": "app_delivery",
        "project_relation": "owned_by_project",
        "risk_tier": "high",
        "confidentiality": "internal",
        "next_action_type": "continue",
    }

    result = validate_minimal_classification(classification=classification, schema=schema)

    assert not result.valid
    assert "project_id is required when project_relation is owned_by_project" in result.errors
    assert "project_stage_id is required when project_relation is owned_by_project" in result.errors


def test_full_classification_example_validates():
    result = validate_full_classification_file(Path("artifacts/schemas/classification_full.json"))

    assert result.valid
    assert result.errors == []


def test_full_classification_rejects_missing_llmops_path():
    schema = load_json(Path("artifacts/schemas/classification_schema_minimal.json"))
    classification = load_json(Path("artifacts/schemas/classification_full.json"))
    classification["llmops_trace"]["prompt_artifact"] = "missing/prompt.md"

    result = validate_full_classification(classification=classification, minimal_schema=schema)

    assert not result.valid
    assert "llmops_trace.prompt_artifact path does not exist: missing/prompt.md" in result.errors


def test_full_classification_rejects_public_reuse_for_restricted_data():
    schema = load_json(Path("artifacts/schemas/classification_schema_minimal.json"))
    classification = load_json(Path("artifacts/schemas/classification_full.json"))
    classification["classification_minimal"]["confidentiality"] = "restricted"
    classification["governance_trace"]["reuse_policy"] = "public_reuse"
    classification["governance_trace"]["sanitization_status"] = "completed"

    result = validate_full_classification(classification=classification, minimal_schema=schema)

    assert not result.valid
    assert "public_reuse is not allowed for restricted or sensitive classification" in result.errors


def test_full_classification_rejects_regalara_with_hitl_l1():
    schema = load_json(Path("artifacts/schemas/classification_schema_minimal.json"))
    classification = load_json(Path("artifacts/schemas/classification_full.json"))
    classification["classification_minimal"]["execution_instance_type"] = "regulara"
    classification["decision_trace"]["hitl_level"] = "L1"

    result = validate_full_classification(classification=classification, minimal_schema=schema)

    assert not result.valid
    assert "regulara requires final HITL level L2 or L3" in result.errors


def test_full_classification_rejects_vitalia_sensitive_without_escalation():
    schema = load_json(Path("artifacts/schemas/classification_schema_minimal.json"))
    classification = load_json(Path("artifacts/schemas/classification_full.json"))
    classification["classification_minimal"]["execution_instance_type"] = "vitalia"
    classification["classification_minimal"]["confidentiality"] = "sensitive"
    classification["decision_trace"]["hitl_level"] = "L1"
    classification["decision_trace"]["escalation_triggers"] = []

    result = validate_full_classification(classification=classification, minimal_schema=schema)

    assert not result.valid
    assert (
        "vitalia with restricted or sensitive data requires escalation trigger dado_sensivel"
        in result.errors
    )
