from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest
from rbdss_pipeline.project_manager import add_stage, create_project, materialize_stage

_FIXTURE_BASE = Path(__file__).parent.parent / "runs-test" / "_project_manager_tests"


@pytest.fixture
def project_workspace():
    if _FIXTURE_BASE.exists():
        shutil.rmtree(_FIXTURE_BASE)
    _FIXTURE_BASE.mkdir(parents=True)
    yield _FIXTURE_BASE
    shutil.rmtree(_FIXTURE_BASE, ignore_errors=True)


def test_create_project_writes_manifest_files(project_workspace):
    result = create_project(
        project_id="demo-project",
        project_name="Demo Project",
        objetivo="Deliver a demo",
        contexto="Local test context",
        projects_dir=project_workspace,
    )

    project_dir = project_workspace / "demo-project"
    assert result["project_dir"] == str(project_dir)
    assert (project_dir / "project_manifest.json").exists()
    assert (project_dir / "project_manifest.md").exists()
    assert (project_dir / "stages").is_dir()

    manifest = json.loads((project_dir / "project_manifest.json").read_text(encoding="utf-8"))
    assert manifest["project_id"] == "demo-project"
    assert manifest["project_name"] == "Demo Project"
    assert manifest["stages"] == []


def test_add_stage_appends_manifest_and_writes_stage_files(project_workspace):
    create_project(
        project_id="demo-project",
        project_name="Demo Project",
        objetivo="Deliver a demo",
        contexto="Local test context",
        projects_dir=project_workspace,
    )

    result = add_stage(
        project_id="demo-project",
        stage_id="APP-IMPL-01",
        objetivo="Implement SharePoint provisioning",
        instancia_pipeline_sugerida="PLAN",
        projects_dir=project_workspace,
    )

    stage_dir = project_workspace / "demo-project" / "stages" / "00-app-impl-01"
    assert result["stage_dir"] == str(stage_dir)
    assert (stage_dir / "stage_brief.md").exists()
    assert (stage_dir / "linked_runs.md").exists()

    manifest = json.loads(
        (project_workspace / "demo-project" / "project_manifest.json").read_text(encoding="utf-8")
    )
    assert manifest["stages"][0]["project_stage_id"] == "APP-IMPL-01"
    assert manifest["stages"][0]["status"] == "planejada"


def test_materialize_stage_links_run_path(project_workspace):
    create_project(
        project_id="demo-project",
        project_name="Demo Project",
        objetivo="Deliver a demo",
        contexto="Local test context",
        projects_dir=project_workspace,
    )
    add_stage(
        project_id="demo-project",
        stage_id="APP-IMPL-01",
        objetivo="Implement SharePoint provisioning",
        instancia_pipeline_sugerida="PLAN",
        projects_dir=project_workspace,
    )

    result = materialize_stage(
        project_id="demo-project",
        stage_id="APP-IMPL-01",
        run_path="runs/demo/20260502",
        projects_dir=project_workspace,
    )

    assert result == {
        "project_id": "demo-project",
        "project_stage_id": "APP-IMPL-01",
        "run_path": "runs/demo/20260502",
    }

    manifest = json.loads(
        (project_workspace / "demo-project" / "project_manifest.json").read_text(encoding="utf-8")
    )
    stage = manifest["stages"][0]
    assert stage["status"] == "consubstanciada"
    assert stage["linked_run_path"] == "runs/demo/20260502"

    linked_runs = (
        project_workspace / "demo-project" / "stages" / "00-app-impl-01" / "linked_runs.md"
    ).read_text(encoding="utf-8")
    assert "runs/demo/20260502" in linked_runs


def test_materialize_stage_errors_when_stage_is_missing(project_workspace):
    create_project(
        project_id="demo-project",
        project_name="Demo Project",
        objetivo="Deliver a demo",
        contexto="Local test context",
        projects_dir=project_workspace,
    )

    with pytest.raises(ValueError, match="Stage 'MISSING' not found"):
        materialize_stage(
            project_id="demo-project",
            stage_id="MISSING",
            run_path="runs/demo/20260502",
            projects_dir=project_workspace,
        )
