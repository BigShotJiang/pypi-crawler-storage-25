"""Testes de cobertura da CLI e do make_provider.

Cobre os paths nao exercidos pela suite existente:
- make_provider: mock e erro para provider desconhecido
- CLI validate-mcda: invocacao basica e saida de decisao
"""

from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest
from rbdss_pipeline.cli import app
from rbdss_pipeline.providers import MockProvider, UnsupportedProviderError, make_provider
from typer.testing import CliRunner

_FIXTURE_BASE = Path(__file__).parent.parent / "runs-test" / "_cli_tests"
runner = CliRunner()


# ─────────────────────────────────────────────────────────────────────────────
# make_provider
# ─────────────────────────────────────────────────────────────────────────────
def test_make_provider_mock_returns_mock_provider():
    p = make_provider("mock")
    assert isinstance(p, MockProvider)


def test_make_provider_mock_case_insensitive():
    p = make_provider("MOCK")
    assert isinstance(p, MockProvider)


def test_make_provider_unknown_raises():
    with pytest.raises(UnsupportedProviderError, match="ainda nao implementado"):
        make_provider("openai")


# ─────────────────────────────────────────────────────────────────────────────
# CLI — validate-mcda
# ─────────────────────────────────────────────────────────────────────────────
def test_cli_validate_mcda_accept():
    audit_dir = _FIXTURE_BASE / "mcda_accept"
    audit_dir.mkdir(parents=True, exist_ok=True)
    audit = {
        "metrics": {
            "precisao_tecnica": 9.8,
            "seguranca_compliance": 9.9,
            "completude": 9.7,
            "clareza_formato": 9.6,
        }
    }
    audit_file = audit_dir / "audit.json"
    audit_file.write_text(json.dumps(audit), encoding="utf-8")

    result = runner.invoke(
        app,
        [
            "validate-mcda",
            "--audit-file",
            str(audit_file),
            "--execution-instance-type",
            "projecta",
        ],
    )
    assert result.exit_code == 0, result.output
    assert "ACCEPT" in result.output


def test_cli_validate_mcda_reject_low_c2():
    audit_dir = _FIXTURE_BASE / "mcda_reject"
    audit_dir.mkdir(parents=True, exist_ok=True)
    audit = {
        "metrics": {
            "precisao_tecnica": 9.5,
            "seguranca_compliance": 5.0,
            "completude": 9.0,
            "clareza_formato": 9.0,
        }
    }
    audit_file = audit_dir / "audit.json"
    audit_file.write_text(json.dumps(audit), encoding="utf-8")

    result = runner.invoke(
        app,
        [
            "validate-mcda",
            "--audit-file",
            str(audit_file),
            "--execution-instance-type",
            "projecta",
        ],
    )
    assert result.exit_code == 1
    assert "REJECT" in result.output or "REFINE" in result.output


def test_cli_project_lifecycle_commands(tmp_path):
    projects_dir = tmp_path / "projects"

    create_result = runner.invoke(
        app,
        [
            "create-project",
            "--project-id",
            "demo-project",
            "--project-name",
            "Demo Project",
            "--objetivo",
            "Deliver demo",
            "--contexto",
            "Local context",
            "--projects-dir",
            str(projects_dir),
        ],
    )
    assert create_result.exit_code == 0, create_result.output
    assert "Projeto criado" in create_result.output

    add_stage_result = runner.invoke(
        app,
        [
            "add-stage",
            "--project-id",
            "demo-project",
            "--stage-id",
            "APP-01",
            "--objetivo",
            "Implement app",
            "--instancia-pipeline-sugerida",
            "PLAN",
            "--projects-dir",
            str(projects_dir),
        ],
    )
    assert add_stage_result.exit_code == 0, add_stage_result.output
    assert "Etapa adicionada" in add_stage_result.output

    materialize_result = runner.invoke(
        app,
        [
            "materialize-stage",
            "--project-id",
            "demo-project",
            "--stage-id",
            "APP-01",
            "--run-path",
            "runs/demo/20260503",
            "--projects-dir",
            str(projects_dir),
        ],
    )
    assert materialize_result.exit_code == 0, materialize_result.output
    assert "Etapa consubstanciada" in materialize_result.output

    manifest = json.loads(
        (projects_dir / "demo-project" / "project_manifest.json").read_text(encoding="utf-8")
    )
    assert manifest["stages"][0]["linked_run_path"] == "runs/demo/20260503"


def test_cli_run_accepts_pipeline_spec_and_registry_ref(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
):
    registry_module = tmp_path / "cli_registry.py"
    registry_module.write_text(
        textwrap.dedent(
            """
            from rbdss_pipeline import PhaseHandlerRegistry


            def build_registry():
                registry = PhaseHandlerRegistry()

                def cli_review(run_dir, prompt_summaries, state):
                    state["cli_review"] = "cli handler"
                    prompt_summaries.append({"phase": "cli_review", "summary": "cli handler"})
                    (run_dir / "cli_review.md").write_text("cli handler", encoding="utf-8")

                registry.register("cli_review", cli_review)
                return registry
            """
        ),
        encoding="utf-8",
    )
    monkeypatch.syspath_prepend(str(tmp_path))

    context_file = tmp_path / "context.md"
    context_file.write_text("Contexto CLI customizado", encoding="utf-8")
    spec_file = tmp_path / "pipeline_spec.json"
    spec_file.write_text(
        json.dumps(
            {
                "id": "cli-custom-spec",
                "name": "CLI Custom Spec",
                "version": "1.0.0",
                "phases": ["cli_review"],
                "default_profile": None,
            }
        ),
        encoding="utf-8",
    )
    out_dir = tmp_path / "runs"

    result = runner.invoke(
        app,
        [
            "run",
            "--objective",
            "Executar CLI customizada",
            "--context-file",
            str(context_file),
            "--provider",
            "mock",
            "--task-mnemonic",
            "cli-custom",
            "--out-dir",
            str(out_dir),
            "--spec-file",
            str(spec_file),
            "--phase-handler-registry-ref",
            "cli_registry:build_registry",
        ],
    )

    assert result.exit_code == 0, result.output
    run_dir = next((out_dir / "cli-custom").iterdir())
    assert (run_dir / "cli_review.md").read_text(encoding="utf-8") == "cli handler"
    assert (
        json.loads((run_dir / "pipeline_spec.json").read_text(encoding="utf-8"))["id"]
        == "cli-custom-spec"
    )


def test_cli_run_accepts_execution_config_file(monkeypatch: pytest.MonkeyPatch, tmp_path: Path):
    registry_module = tmp_path / "config_registry.py"
    registry_module.write_text(
        textwrap.dedent(
            """
            from rbdss_pipeline import PhaseHandlerRegistry


            def build_registry():
                registry = PhaseHandlerRegistry()

                def config_review(run_dir, prompt_summaries, state):
                    state["config_review"] = "config handler"
                    prompt_summaries.append(
                        {"phase": "config_review", "summary": "config handler"}
                    )
                    (run_dir / "config_review.md").write_text(
                        "config handler",
                        encoding="utf-8",
                    )

                registry.register("config_review", config_review)
                return registry
            """
        ),
        encoding="utf-8",
    )
    monkeypatch.syspath_prepend(str(tmp_path))

    spec_file = tmp_path / "pipeline_spec.json"
    spec_file.write_text(
        json.dumps(
            {
                "id": "config-custom-spec",
                "name": "Config Custom Spec",
                "phases": ["config_review"],
                "default_profile": None,
            }
        ),
        encoding="utf-8",
    )
    execution_config_file = tmp_path / "execution_config.json"
    execution_config_file.write_text(
        json.dumps(
            {
                "objective": "Executar config unificada",
                "context": "Contexto inline no config",
                "provider": "mock",
                "task_mnemonic": "config-custom",
                "out_dir": "runs",
                "spec_file": "pipeline_spec.json",
                "phase_handler_registry_refs": ["config_registry:build_registry"],
                "metadata": {"owner": "tests"},
            }
        ),
        encoding="utf-8",
    )

    result = runner.invoke(
        app,
        [
            "run",
            "--execution-config",
            str(execution_config_file),
        ],
    )

    assert result.exit_code == 0, result.output
    run_dir = next((tmp_path / "runs" / "config-custom").iterdir())
    assert (run_dir / "config_review.md").read_text(encoding="utf-8") == "config handler"
    assert (
        json.loads((run_dir / "pipeline_spec.json").read_text(encoding="utf-8"))["id"]
        == "config-custom-spec"
    )
    execution_snapshot = json.loads((run_dir / "execution_config.json").read_text(encoding="utf-8"))
    assert execution_snapshot["objective"] == "Executar config unificada"
    assert Path(execution_snapshot["spec_file"]).name == "pipeline_spec.json"
    assert execution_snapshot["phase_handler_registry_refs"] == ["config_registry:build_registry"]
    assert execution_snapshot["metadata"]["owner"] == "tests"
    assert execution_snapshot["metadata"]["context_source"] == "inline"
    assert execution_snapshot["metadata"]["overrides"] == []
    assert execution_snapshot["metadata"]["spec_id"] == "config-custom-spec"


def test_cli_validate_execution_config_resolves_paths(tmp_path: Path):
    context_file = tmp_path / "context.md"
    context_file.write_text("Contexto de validacao", encoding="utf-8")
    spec_file = tmp_path / "pipeline_spec.json"
    spec_file.write_text(
        json.dumps(
            {
                "id": "validation-spec",
                "name": "Validation Spec",
                "phases": ["ask"],
                "default_profile": None,
            }
        ),
        encoding="utf-8",
    )
    execution_config_file = tmp_path / "execution_config.json"
    execution_config_file.write_text(
        json.dumps(
            {
                "objective": "Validar config",
                "context_file": "context.md",
                "provider": "mock",
                "spec_file": "pipeline_spec.json",
            }
        ),
        encoding="utf-8",
    )

    result = runner.invoke(
        app,
        [
            "validate-execution-config",
            "--execution-config",
            str(execution_config_file),
        ],
    )

    assert result.exit_code == 0, result.output
    assert "Execution config valido" in result.output
    assert '"context_file"' in result.output
    assert "context.md" in result.output
    assert '"spec_file"' in result.output
    assert "pipeline_spec.json" in result.output
