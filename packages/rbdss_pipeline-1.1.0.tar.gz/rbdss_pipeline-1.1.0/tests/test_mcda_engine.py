"""Testes automatizados do motor MCDA.

Cobre:
- Calculo correto do Global Score com pesos padrao
- Decisao ACCEPT quando score e interlocks satisfeitos
- Decisao REFINE quando score intermediario
- Decisao REJECT por score baixo
- Decisao REJECT por falha no interlock C2 mesmo com score alto
- Carregamento de pesos de instancia (regulara, scholara)
- Escalada automatica vitalia
"""

from __future__ import annotations

from pathlib import Path

import pytest
from rbdss_pipeline.mcda import (
    MCDAConfig,
    compute_global_score,
    evaluate_mcda,
    load_mcda_config,
)
from rbdss_pipeline.models import AuditResult, Decision

# ─────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────
WEIGHTS_PATH = Path("artifacts/schemas/mcda_weights.yaml")

DEFAULT_CONFIG = MCDAConfig(
    weights={
        "precisao_tecnica": 0.35,
        "seguranca_compliance": 0.35,
        "completude": 0.15,
        "clareza_formato": 0.15,
    },
    accept_min_global=9.2,
    accept_min_seguranca=9.5,
    accept_min_precisao=9.0,
    refine_min_global=8.0,
    refine_min_seguranca=9.0,
)


def _audit(c1: float, c2: float, c3: float, c4: float) -> AuditResult:
    return AuditResult(
        metrics={
            "precisao_tecnica": c1,
            "seguranca_compliance": c2,
            "completude": c3,
            "clareza_formato": c4,
        }
    )


# ─────────────────────────────────────────────
# Testes de calculo do Global Score
# ─────────────────────────────────────────────
def test_global_score_exact():
    audit = _audit(9.7, 9.8, 9.5, 9.6)
    score = compute_global_score(audit, DEFAULT_CONFIG.weights)
    expected = (9.7 * 0.35) + (9.8 * 0.35) + (9.5 * 0.15) + (9.6 * 0.15)
    assert abs(score - round(expected, 4)) < 1e-6


def test_global_score_zero_metrics():
    audit = AuditResult(metrics={})
    score = compute_global_score(audit, DEFAULT_CONFIG.weights)
    assert score == 0.0


# ─────────────────────────────────────────────
# Testes de decisao
# ─────────────────────────────────────────────
def test_accept_all_above_threshold():
    # C1=9.5, C2=9.8, C3=9.5, C4=9.5
    # S = 9.5*0.35 + 9.8*0.35 + 9.5*0.15 + 9.5*0.15 = 3.325+3.43+1.425+1.425 = 9.605
    audit = _audit(9.5, 9.8, 9.5, 9.5)
    result = evaluate_mcda(audit, DEFAULT_CONFIG)
    assert result.decision == Decision.ACCEPT


def test_refine_score_between_thresholds():
    # C1=8.5, C2=9.2, C3=8.0, C4=8.0
    # S = 8.5*0.35 + 9.2*0.35 + 8.0*0.15 + 8.0*0.15 = 2.975+3.22+1.2+1.2 = 8.595
    audit = _audit(8.5, 9.2, 8.0, 8.0)
    result = evaluate_mcda(audit, DEFAULT_CONFIG)
    assert result.decision == Decision.REFINE


def test_reject_score_below_minimum():
    # Score muito baixo
    audit = _audit(5.0, 9.5, 6.0, 6.0)
    result = evaluate_mcda(audit, DEFAULT_CONFIG)
    assert result.decision == Decision.REJECT


def test_reject_c2_interlock_blocks_high_score():
    """Interlock C2: mesmo com score alto, C2 < 9.5 impede ACCEPT e pode causar REJECT."""
    # C1=9.8, C2=8.5 (abaixo do minimo de REFINE), C3=9.8, C4=9.8
    # S = 9.8*0.35 + 8.5*0.35 + 9.8*0.15 + 9.8*0.15 = 3.43+2.975+1.47+1.47 = 9.345
    # Score passa 9.2, mas C2=8.5 < refine_min_seguranca=9.0 => REJECT
    audit = _audit(9.8, 8.5, 9.8, 9.8)
    result = evaluate_mcda(audit, DEFAULT_CONFIG)
    assert result.decision == Decision.REJECT


def test_refine_c2_low_but_above_refine_floor():
    """C2 abaixo do minimo de ACCEPT (9.5) mas acima do REFINE (9.0) => REFINE."""
    # C1=9.5, C2=9.1, C3=9.5, C4=9.5
    # S = 9.5*0.35+9.1*0.35+9.5*0.15+9.5*0.15 = 3.325+3.185+1.425+1.425 = 9.36
    audit = _audit(9.5, 9.1, 9.5, 9.5)
    result = evaluate_mcda(audit, DEFAULT_CONFIG)
    assert result.decision == Decision.REFINE


# ─────────────────────────────────────────────
# Testes de carregamento de instancias
# ─────────────────────────────────────────────
@pytest.mark.skipif(not WEIGHTS_PATH.exists(), reason="mcda_weights.yaml nao encontrado")
def test_load_mcda_config_default():
    cfg = load_mcda_config(WEIGHTS_PATH, execution_instance_type="projecta")
    assert abs(cfg.weights["precisao_tecnica"] - 0.35) < 1e-6
    assert abs(cfg.weights["seguranca_compliance"] - 0.35) < 1e-6
    assert abs(sum(cfg.weights.values()) - 1.0) < 1e-6


@pytest.mark.skipif(not WEIGHTS_PATH.exists(), reason="mcda_weights.yaml nao encontrado")
def test_load_mcda_config_regulara():
    cfg = load_mcda_config(WEIGHTS_PATH, execution_instance_type="regulara")
    # regulara eleva C2 para 0.45 e reduz C4 para 0.10
    assert abs(cfg.weights["seguranca_compliance"] - 0.45) < 1e-6
    assert abs(cfg.weights["clareza_formato"] - 0.10) < 1e-6
    assert abs(sum(cfg.weights.values()) - 1.0) < 1e-6


@pytest.mark.skipif(not WEIGHTS_PATH.exists(), reason="mcda_weights.yaml nao encontrado")
def test_load_mcda_config_scholara():
    cfg = load_mcda_config(WEIGHTS_PATH, execution_instance_type="scholara")
    # scholara eleva C1 para 0.40 e reduz C2 para 0.30
    assert abs(cfg.weights["precisao_tecnica"] - 0.40) < 1e-6
    assert abs(cfg.weights["seguranca_compliance"] - 0.30) < 1e-6
    assert abs(sum(cfg.weights.values()) - 1.0) < 1e-6


# ─────────────────────────────────────────────
# Vitalia: escalada automatica
# ─────────────────────────────────────────────
def test_vitalia_escalada_trigger():
    """Vitalia com C2 < 9.5 deve adicionar trigger de escalada HITL L2."""
    vitalia_cfg = MCDAConfig(
        weights=DEFAULT_CONFIG.weights,
        accept_min_global=9.2,
        accept_min_seguranca=9.5,
        accept_min_precisao=9.0,
        refine_min_global=8.0,
        refine_min_seguranca=9.0,
        vitalia_escalada_c2=9.5,
    )
    audit = _audit(9.5, 9.2, 9.5, 9.5)  # C2=9.2 < 9.5
    result = evaluate_mcda(audit, vitalia_cfg, execution_instance_type="vitalia")
    rule_ids = {r.rule_id for r in result.triggered_rules}
    assert "vitalia_escalada_hitl_l2" in rule_ids


def test_vitalia_no_escalada_when_c2_sufficient():
    vitalia_cfg = MCDAConfig(
        weights=DEFAULT_CONFIG.weights,
        accept_min_global=9.2,
        accept_min_seguranca=9.5,
        accept_min_precisao=9.0,
        refine_min_global=8.0,
        refine_min_seguranca=9.0,
        vitalia_escalada_c2=9.5,
    )
    audit = _audit(9.5, 9.6, 9.5, 9.5)  # C2=9.6 >= 9.5
    result = evaluate_mcda(audit, vitalia_cfg, execution_instance_type="vitalia")
    rule_ids = {r.rule_id for r in result.triggered_rules}
    assert "vitalia_escalada_hitl_l2" not in rule_ids
