import shutil
import textwrap
from pathlib import Path
from uuid import uuid4

import pytest
import rbdss_pipeline as sdk
from rbdss_pipeline.models import (
    EvalResult,
    HITLGate,
    HITLGateStatus,
    PhaseEval,
    PipelineEvent,
    PipelineEventType,
    PipelineExecutionConfig,
    PipelinePhase,
    PipelineRun,
    PipelineRunStatus,
    PipelineSpec,
)
from rbdss_pipeline.pipeline import (
    HITLGateBlockedError,
    PhaseEvalFailedError,
    PhaseHandlerRegistry,
    PipelineRunner,
    PipelineState,
    UnsupportedPipelineSpecError,
    default_pipeline_spec,
)
from rbdss_pipeline.providers import MockProvider


def test_public_api_exports_pipeline_contracts():
    assert sdk.DEFAULT_PIPELINE_PHASES[0] == sdk.PipelinePhase.ASK
    assert sdk.default_pipeline_spec().id == "rbdss-default-10phase"
    assert sdk.PhaseHandler is not None
    assert sdk.PhaseHandlerMap is not None
    assert sdk.PhaseHandlerRegistry is PhaseHandlerRegistry
    assert sdk.load_phase_handler_registry is not None
    assert sdk.PipelineState is not None
    assert sdk.PipelineSpec is PipelineSpec
    assert sdk.PipelinePhaseId is not None
    assert sdk.TaskProfile is not None
    assert sdk.PipelineRun is PipelineRun
    assert sdk.AuditEvent is not None
    assert sdk.HITLGate is not None
    assert sdk.phase_key(PipelinePhase.ASK) == "ask"


def test_default_pipeline_spec_preserves_current_10_phase_order():
    spec = default_pipeline_spec()

    assert spec.id == "rbdss-default-10phase"
    assert spec.phases == [
        PipelinePhase.ASK,
        PipelinePhase.PLAN,
        PipelinePhase.GENERATE,
        PipelinePhase.SHAPE,
        PipelinePhase.CRITIQUE,
        PipelinePhase.CORRECT,
        PipelinePhase.AUDIT,
        PipelinePhase.HARDEN,
        PipelinePhase.VALIDATE,
        PipelinePhase.DEEP_RESEARCH,
    ]
    assert spec.default_profile is not None
    assert spec.default_profile.phases == spec.phases


def test_pipeline_runner_accepts_custom_spec_metadata_for_current_phase_order():
    spec = default_pipeline_spec().model_copy(update={"id": "custom-task", "name": "Custom Task"})
    runner = PipelineRunner(provider=MockProvider(), spec=spec)

    assert runner.spec.id == "custom-task"


def test_pipeline_runner_executes_phase_subset_from_spec():
    spec = default_pipeline_spec().model_copy(
        update={
            "id": "ask-only",
            "phases": [PipelinePhase.ASK],
            "default_profile": None,
        }
    )
    runner = PipelineRunner(provider=MockProvider(), spec=spec)
    out_dir = Path("runs-test") / uuid4().hex

    try:
        result = runner.run(
            objective="Executar apenas ask",
            context="IDE context",
            out_dir=out_dir,
            task_mnemonic="ask-only",
        )

        run_dir = Path(result["run_dir"])
        pipeline_run = PipelineRun.model_validate_json(
            (run_dir / "pipeline_run.json").read_text(encoding="utf-8")
        )
        assert result["spec_id"] == "ask-only"
        assert result["decision"] is None
        assert (run_dir / "ask.md").exists()
        assert not (run_dir / "plan.md").exists()
        assert pipeline_run.decision is None
        assert pipeline_run.audit_events[0].event_id.endswith(":pipeline_spec_registered")
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_pipeline_runner_accepts_custom_phase_handler():
    def custom_ask(
        run_dir: Path,
        prompt_summaries: list[dict[str, str]],
        state: dict[str, object],
    ) -> None:
        state["ask"] = "custom ask"
        prompt_summaries.append({"phase": "ask", "summary": "custom handler"})
        (run_dir / "ask.md").write_text("custom ask", encoding="utf-8")

    spec = default_pipeline_spec().model_copy(
        update={
            "id": "custom-handler",
            "phases": [PipelinePhase.ASK],
            "default_profile": None,
        }
    )
    runner = PipelineRunner(
        provider=MockProvider(),
        spec=spec,
        phase_handlers={PipelinePhase.ASK: custom_ask},
    )
    out_dir = Path("runs-test") / uuid4().hex

    try:
        result = runner.run(
            objective="Executar handler customizado",
            context="IDE context",
            out_dir=out_dir,
            task_mnemonic="custom-handler",
        )

        run_dir = Path(result["run_dir"])
        assert (run_dir / "ask.md").read_text(encoding="utf-8") == "custom ask"
        assert "custom handler" in (run_dir / "prompt_summary.md").read_text(encoding="utf-8")
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_pipeline_runner_accepts_string_phase_with_registered_handler_and_dependencies():
    def custom_review(
        run_dir: Path,
        prompt_summaries: list[dict[str, str]],
        state: dict[str, object],
    ) -> None:
        state["custom_review"] = state["ask"]
        prompt_summaries.append({"phase": "custom_review", "summary": "custom review"})
        (run_dir / "custom_review.md").write_text("custom review", encoding="utf-8")

    spec = default_pipeline_spec().model_copy(
        update={
            "id": "custom-string-phase",
            "phases": [PipelinePhase.ASK, "custom_review"],
            "phase_dependencies": {"custom_review": [PipelinePhase.ASK]},
            "default_profile": None,
        }
    )
    runner = PipelineRunner(
        provider=MockProvider(),
        spec=spec,
        phase_handlers={"custom_review": custom_review},
    )
    out_dir = Path("runs-test") / uuid4().hex

    try:
        result = runner.run(
            objective="Executar fase string",
            context="IDE context",
            out_dir=out_dir,
            task_mnemonic="custom-string-phase",
        )

        run_dir = Path(result["run_dir"])
        spec_file = PipelineSpec.model_validate_json(
            (run_dir / "pipeline_spec.json").read_text(encoding="utf-8")
        )
        assert "custom_review" in spec_file.phases
        assert (run_dir / "custom_review.md").read_text(encoding="utf-8") == "custom review"
        assert "custom review" in (run_dir / "prompt_summary.md").read_text(encoding="utf-8")
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_phase_handler_registry_registers_named_handlers():
    def custom_review(
        run_dir: Path,
        prompt_summaries: list[dict[str, str]],
        state: dict[str, object],
    ) -> None:
        state["custom_review"] = "registry handler"
        prompt_summaries.append({"phase": "custom_review", "summary": "registry handler"})
        (run_dir / "custom_review.md").write_text("registry handler", encoding="utf-8")

    registry = PhaseHandlerRegistry()
    registry.register("custom_review", custom_review)
    assert registry.get("custom_review") is custom_review

    spec = default_pipeline_spec().model_copy(
        update={
            "id": "registry-handler",
            "phases": ["custom_review"],
            "default_profile": None,
        }
    )
    runner = PipelineRunner(provider=MockProvider(), spec=spec, phase_handlers=registry)
    out_dir = Path("runs-test") / uuid4().hex

    try:
        result = runner.run(
            objective="Executar registry handler",
            context="IDE context",
            out_dir=out_dir,
            task_mnemonic="registry-handler",
        )

        run_dir = Path(result["run_dir"])
        assert (run_dir / "custom_review.md").read_text(encoding="utf-8") == "registry handler"
        assert "registry handler" in (run_dir / "prompt_summary.md").read_text(encoding="utf-8")
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_pipeline_runner_loads_phase_handler_registry_from_python_reference(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
):
    registry_module = tmp_path / "custom_registry.py"
    registry_module.write_text(
        textwrap.dedent(
            """
            from rbdss_pipeline import PhaseHandlerRegistry


            def build_registry():
                registry = PhaseHandlerRegistry()

                def imported_review(run_dir, prompt_summaries, state):
                    state["imported_review"] = "imported handler"
                    prompt_summaries.append(
                        {"phase": "imported_review", "summary": "imported handler"}
                    )
                    (run_dir / "imported_review.md").write_text(
                        "imported handler",
                        encoding="utf-8",
                    )

                registry.register("imported_review", imported_review)
                return registry
            """
        ),
        encoding="utf-8",
    )
    monkeypatch.syspath_prepend(str(tmp_path))

    spec = default_pipeline_spec().model_copy(
        update={
            "id": "imported-registry",
            "phases": ["imported_review"],
            "default_profile": None,
        }
    )
    runner = PipelineRunner(
        provider=MockProvider(),
        spec=spec,
        phase_handler_registry_refs=["custom_registry:build_registry"],
    )
    out_dir = Path("runs-test") / uuid4().hex

    try:
        result = runner.run(
            objective="Executar registry importado",
            context="IDE context",
            out_dir=out_dir,
            task_mnemonic="imported-registry",
        )

        run_dir = Path(result["run_dir"])
        assert (run_dir / "imported_review.md").read_text(encoding="utf-8") == ("imported handler")
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_load_phase_handler_registry_rejects_invalid_reference():
    with pytest.raises(UnsupportedPipelineSpecError, match="module:attribute"):
        sdk.load_phase_handler_registry("invalid-reference")


def test_pipeline_runner_rejects_string_phase_without_handler():
    spec = default_pipeline_spec().model_copy(
        update={
            "id": "missing-handler",
            "phases": [PipelinePhase.ASK, "custom_review"],
            "phase_dependencies": {"custom_review": [PipelinePhase.ASK]},
            "default_profile": None,
        }
    )

    with pytest.raises(UnsupportedPipelineSpecError, match="No handler registered"):
        PipelineRunner(provider=MockProvider(), spec=spec)


def test_pipeline_runner_rejects_phase_order_without_dependencies():
    spec = default_pipeline_spec().model_copy(
        update={"id": "unsupported", "phases": [PipelinePhase.ASK, PipelinePhase.SHAPE]}
    )

    with pytest.raises(UnsupportedPipelineSpecError, match="requires missing dependencies"):
        PipelineRunner(provider=MockProvider(), spec=spec)


def test_pipeline_runner_rejects_out_of_order_phases():
    spec = default_pipeline_spec().model_copy(
        update={
            "id": "out-of-order",
            "phases": [PipelinePhase.PLAN, PipelinePhase.ASK],
            "default_profile": None,
        }
    )

    with pytest.raises(UnsupportedPipelineSpecError, match="dependency order"):
        PipelineRunner(provider=MockProvider(), spec=spec)


def test_pipeline_run_uses_mnemonic_before_timestamp_and_logs_prompt_summary():
    runner = PipelineRunner(provider=MockProvider())
    out_dir = Path("runs-test") / uuid4().hex

    try:
        result = runner.run(
            objective="Validar este repositorio",
            context="IDE context",
            constraints=["seguir as regras atuais do repositorio"],
            out_dir=out_dir,
            task_mnemonic="validar-este-repositorio",
        )

        run_dir = Path(result["run_dir"])
        assert run_dir.parent.name == "validar-este-repositorio"
        assert result["spec_id"] == "rbdss-default-10phase"
        assert (run_dir / "prompt_summary.md").exists()
        assert (run_dir / "deep_research.md").exists()
        assert (run_dir / "pipeline_spec.json").exists()
        assert (run_dir / "pipeline_run.json").exists()

        summary = (run_dir / "prompt_summary.md").read_text(encoding="utf-8")
        assert "## ASK" in summary
        assert "## AUDIT" in summary
        assert "## DEEP_RESEARCH" in summary

        spec = PipelineSpec.model_validate_json(
            (run_dir / "pipeline_spec.json").read_text(encoding="utf-8")
        )
        pipeline_run = PipelineRun.model_validate_json(
            (run_dir / "pipeline_run.json").read_text(encoding="utf-8")
        )
        assert spec.id == "rbdss-default-10phase"
        assert pipeline_run.spec_id == spec.id
        assert pipeline_run.decision is not None
        assert [
            event.event_id.split(":", maxsplit=1)[1] for event in pipeline_run.audit_events
        ] == [
            "pipeline_spec_registered",
            "mcda_decision",
        ]
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_pipeline_run_registers_execution_config_snapshot():
    runner = PipelineRunner(provider=MockProvider())
    out_dir = Path("runs-test") / uuid4().hex
    execution_config = PipelineExecutionConfig(
        objective="Executar snapshot",
        context="Contexto inline",
        task_mnemonic="snapshot-run",
        metadata={"owner": "tests"},
    )

    try:
        result = runner.run(
            objective="Executar snapshot",
            context="Contexto inline",
            out_dir=out_dir,
            task_mnemonic="snapshot-run",
            execution_config=execution_config,
            execution_overrides=["objective"],
        )

        run_dir = Path(result["run_dir"])
        snapshot = PipelineExecutionConfig.model_validate_json(
            (run_dir / "execution_config.json").read_text(encoding="utf-8")
        )
        assert snapshot.metadata["overrides"] == ["objective"]
        pipeline_run = PipelineRun.model_validate_json(
            (run_dir / "pipeline_run.json").read_text(encoding="utf-8")
        )
        event_ids = [
            event.event_id.split(":", maxsplit=1)[1] for event in pipeline_run.audit_events
        ]
        assert "execution_config_registered" in event_ids
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_hitl_gate_auto_waived_without_approver():
    gate = HITLGate(id="g1", question="Aprovado?", phase=PipelinePhase.ASK, required=True)
    spec = default_pipeline_spec().model_copy(
        update={
            "id": "hitl-waive",
            "phases": [PipelinePhase.ASK],
            "default_profile": None,
            "hitl_gates": [gate],
        }
    )
    runner = PipelineRunner(provider=MockProvider(), spec=spec)
    out_dir = Path("runs-test") / uuid4().hex

    try:
        result = runner.run(
            objective="Gate auto-waive", context="ctx", out_dir=out_dir, task_mnemonic="hitl-waive"
        )
        run_dir = Path(result["run_dir"])
        pipeline_run = PipelineRun.model_validate_json(
            (run_dir / "pipeline_run.json").read_text(encoding="utf-8")
        )
        assert pipeline_run.status == PipelineRunStatus.COMPLETED
        gate_events = [e for e in pipeline_run.audit_events if "hitl_gate" in e.event_id]
        assert len(gate_events) == 1
        assert gate_events[0].payload["status"] == HITLGateStatus.WAIVED
        from rbdss_pipeline.models import AuditEventLevel

        assert gate_events[0].level == AuditEventLevel.WARNING
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_hitl_gate_approved_with_approver():
    gate = HITLGate(id="g2", question="Confirma?", phase=None, required=True)
    spec = default_pipeline_spec().model_copy(
        update={
            "id": "hitl-approve",
            "phases": [PipelinePhase.ASK],
            "default_profile": None,
            "hitl_gates": [gate],
        }
    )
    runner = PipelineRunner(
        provider=MockProvider(),
        spec=spec,
        hitl_approver=lambda _gate: HITLGateStatus.APPROVED,
    )
    out_dir = Path("runs-test") / uuid4().hex

    try:
        result = runner.run(
            objective="Gate aprovado", context="ctx", out_dir=out_dir, task_mnemonic="hitl-approve"
        )
        run_dir = Path(result["run_dir"])
        pipeline_run = PipelineRun.model_validate_json(
            (run_dir / "pipeline_run.json").read_text(encoding="utf-8")
        )
        assert pipeline_run.status == PipelineRunStatus.COMPLETED
        gate_events = [e for e in pipeline_run.audit_events if "hitl_gate" in e.event_id]
        assert gate_events[0].payload["status"] == HITLGateStatus.APPROVED
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_hitl_gate_required_rejection_blocks_run():
    gate = HITLGate(
        id="g3",
        question="Seguro?",
        phase=PipelinePhase.ASK,
        required=True,
        risk_if_rejected="Dados sensiveis expostos.",
    )
    spec = default_pipeline_spec().model_copy(
        update={
            "id": "hitl-block",
            "phases": [PipelinePhase.ASK],
            "default_profile": None,
            "hitl_gates": [gate],
        }
    )
    runner = PipelineRunner(
        provider=MockProvider(),
        spec=spec,
        hitl_approver=lambda _gate: HITLGateStatus.REJECTED,
    )
    out_dir = Path("runs-test") / uuid4().hex

    try:
        with pytest.raises(HITLGateBlockedError) as exc_info:
            runner.run(
                objective="Gate bloqueado",
                context="ctx",
                out_dir=out_dir,
                task_mnemonic="hitl-block",
            )
        assert exc_info.value.gate.id == "g3"
        assert "Dados sensiveis expostos." in str(exc_info.value)
        run_dirs = list(out_dir.glob("hitl-block/*"))
        assert run_dirs, "pipeline_run.json deve ser persistido mesmo em BLOCKED"
        run_dir = run_dirs[0]
        pipeline_run = PipelineRun.model_validate_json(
            (run_dir / "pipeline_run.json").read_text(encoding="utf-8")
        )
        assert pipeline_run.status == PipelineRunStatus.BLOCKED
        gate_events = [e for e in pipeline_run.audit_events if "hitl_gate" in e.event_id]
        assert gate_events[0].payload["status"] == HITLGateStatus.REJECTED
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_event_hooks_fire_for_each_phase():
    captured: list[PipelineEvent] = []
    spec = default_pipeline_spec().model_copy(
        update={"id": "hooks-test", "phases": [PipelinePhase.ASK], "default_profile": None}
    )
    runner = PipelineRunner(provider=MockProvider(), spec=spec, event_hooks=[captured.append])
    out_dir = Path("runs-test") / uuid4().hex

    try:
        runner.run(
            objective="Hook test", context="ctx", out_dir=out_dir, task_mnemonic="hooks-test"
        )

        event_types = [e.event_type for e in captured]
        assert PipelineEventType.RUN_STARTED in event_types
        assert PipelineEventType.PHASE_STARTED in event_types
        assert PipelineEventType.PHASE_COMPLETED in event_types
        assert PipelineEventType.RUN_COMPLETED in event_types
        assert PipelineEventType.RUN_BLOCKED not in event_types

        run_started = next(e for e in captured if e.event_type == PipelineEventType.RUN_STARTED)
        assert run_started.spec_id == "hooks-test"
        assert "ask" in run_started.payload["phases"]

        phase_started = next(e for e in captured if e.event_type == PipelineEventType.PHASE_STARTED)
        assert phase_started.phase == PipelinePhase.ASK
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_event_hook_error_does_not_fail_run():
    def bad_hook(event: PipelineEvent) -> None:
        raise RuntimeError("hook explodiu")

    spec = default_pipeline_spec().model_copy(
        update={"id": "hook-error", "phases": [PipelinePhase.ASK], "default_profile": None}
    )
    runner = PipelineRunner(provider=MockProvider(), spec=spec, event_hooks=[bad_hook])
    out_dir = Path("runs-test") / uuid4().hex

    try:
        result = runner.run(
            objective="Hook error test", context="ctx", out_dir=out_dir, task_mnemonic="hook-error"
        )
        assert result["spec_id"] == "hook-error"
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_event_hook_fires_run_blocked_on_gate_rejection():
    captured: list[PipelineEvent] = []
    gate = HITLGate(id="g-block", question="Ok?", phase=PipelinePhase.ASK, required=True)
    spec = default_pipeline_spec().model_copy(
        update={
            "id": "hooks-block",
            "phases": [PipelinePhase.ASK],
            "default_profile": None,
            "hitl_gates": [gate],
        }
    )
    runner = PipelineRunner(
        provider=MockProvider(),
        spec=spec,
        hitl_approver=lambda _gate: HITLGateStatus.REJECTED,
        event_hooks=[captured.append],
    )
    out_dir = Path("runs-test") / uuid4().hex

    try:
        with pytest.raises(HITLGateBlockedError):
            runner.run(
                objective="Hook block test",
                context="ctx",
                out_dir=out_dir,
                task_mnemonic="hooks-block",
            )
        event_types = [e.event_type for e in captured]
        assert PipelineEventType.RUN_BLOCKED in event_types
        assert PipelineEventType.RUN_COMPLETED not in event_types
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def _ask_not_empty(state: PipelineState) -> EvalResult:
    passed = bool(state.get("ask"))
    return EvalResult(
        eval_id="ask-not-empty",
        phase=PipelinePhase.ASK,
        passed=passed,
        score=1.0 if passed else 0.0,
        detail="" if passed else "ask output was empty",
    )


def _ask_always_fails(state: PipelineState) -> EvalResult:
    return EvalResult(
        eval_id="ask-fail",
        phase=PipelinePhase.ASK,
        passed=False,
        score=0.0,
        detail="intentional failure",
    )


def test_phase_eval_passes_and_recorded_in_eval_results():
    eval_def = PhaseEval(id="ask-not-empty", phase=PipelinePhase.ASK, required=False)
    spec = default_pipeline_spec().model_copy(
        update={
            "id": "eval-pass",
            "phases": [PipelinePhase.ASK],
            "default_profile": None,
            "evals": [eval_def],
        }
    )
    runner = PipelineRunner(
        provider=MockProvider(),
        spec=spec,
        eval_assertions={"ask-not-empty": _ask_not_empty},
    )
    out_dir = Path("runs-test") / uuid4().hex

    try:
        result = runner.run(
            objective="Eval pass test",
            context="ctx",
            out_dir=out_dir,
            task_mnemonic="eval-pass",
        )
        run_dir = Path(result["run_dir"])
        assert (run_dir / "eval_results.json").exists()
        import json as _json

        results = _json.loads((run_dir / "eval_results.json").read_text(encoding="utf-8"))
        assert len(results) == 1
        assert results[0]["eval_id"] == "ask-not-empty"
        assert results[0]["passed"] is True

        pipeline_run = PipelineRun.model_validate_json(
            (run_dir / "pipeline_run.json").read_text(encoding="utf-8")
        )
        eval_events = [e for e in pipeline_run.audit_events if ":eval:" in e.event_id]
        assert len(eval_events) == 1
        assert eval_events[0].payload["passed"] is True
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_phase_eval_required_failure_blocks_run():
    eval_def = PhaseEval(id="ask-fail", phase=PipelinePhase.ASK, required=True)
    spec = default_pipeline_spec().model_copy(
        update={
            "id": "eval-block",
            "phases": [PipelinePhase.ASK],
            "default_profile": None,
            "evals": [eval_def],
        }
    )
    runner = PipelineRunner(
        provider=MockProvider(),
        spec=spec,
        eval_assertions={"ask-fail": _ask_always_fails},
    )
    out_dir = Path("runs-test") / uuid4().hex

    try:
        with pytest.raises(PhaseEvalFailedError) as exc_info:
            runner.run(
                objective="Eval block test",
                context="ctx",
                out_dir=out_dir,
                task_mnemonic="eval-block",
            )
        assert exc_info.value.eval_result.eval_id == "ask-fail"
        assert "intentional failure" in str(exc_info.value)
        run_dirs = list(out_dir.glob("eval-block/*"))
        assert run_dirs
        pipeline_run = PipelineRun.model_validate_json(
            (run_dirs[0] / "pipeline_run.json").read_text(encoding="utf-8")
        )
        assert pipeline_run.status == PipelineRunStatus.BLOCKED
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)


def test_phase_eval_non_required_failure_does_not_block():
    eval_def = PhaseEval(id="ask-fail", phase=PipelinePhase.ASK, required=False)
    spec = default_pipeline_spec().model_copy(
        update={
            "id": "eval-nonreq",
            "phases": [PipelinePhase.ASK],
            "default_profile": None,
            "evals": [eval_def],
        }
    )
    runner = PipelineRunner(
        provider=MockProvider(),
        spec=spec,
        eval_assertions={"ask-fail": _ask_always_fails},
    )
    out_dir = Path("runs-test") / uuid4().hex

    try:
        result = runner.run(
            objective="Eval non-req test",
            context="ctx",
            out_dir=out_dir,
            task_mnemonic="eval-nonreq",
        )
        run_dir = Path(result["run_dir"])
        pipeline_run = PipelineRun.model_validate_json(
            (run_dir / "pipeline_run.json").read_text(encoding="utf-8")
        )
        assert pipeline_run.status == PipelineRunStatus.COMPLETED
        import json as _json

        results = _json.loads((run_dir / "eval_results.json").read_text(encoding="utf-8"))
        assert results[0]["passed"] is False
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)
