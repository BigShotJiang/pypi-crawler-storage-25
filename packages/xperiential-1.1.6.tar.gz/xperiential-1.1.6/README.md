# Xperiential

## Overview
Xperiential is a Python package developed by the Cloudberry Pi Foundations.  
It provides both Graphical User Interface (GUI) and Text User Interface (TUI) capabilities, enabling interactive experiences through ASCII art, turtle graphics, and text-based animations.  

The package is designed to support creative visualization, interactive console effects, and lightweight GUI components for educational and experiential applications.

## Copyright and Ownership
Xperiential© Team  
Owner: Cloudberry Pi Foundations  

Unauthorized reproduction, distribution, or modification of this package constitutes a violation of copyright law and may lead to severe consequences.

## Features
* **Typewriter Animation** – Display text with a typewriter-style animation.
* **Background Music Playback** – Play audio files in the background without opening a media player.
* **Turtle Graphics** – Draw geometric shapes such as squares, triangles, circles, and composite figures.
* **Composite Graphics** – Merge shapes (square-triangle, triangle-circle, square-triangle-circle) with fill effects.
* **File Operations** – Save and read text files with ease.
* **ASCII Art Rendering** – Generate ASCII art from text or images using `pyfiglet` and `ascii-magic`.
* **ASCII Animation** – Animate ASCII text or images line by line.
* **GUI Widgets** – Add buttons, text input boxes, entry fields, and checkboxes using Tkinter.
* **System Utilities** – Clone Git repositories, echo text, print file contents (`cat`), and run local HTTP servers.

## Installation
To install Xperiential, use Poetry or pip:

```bash
poetry add xperiential==1.1.6
```

or

```bash
pip install xperiential==1.1.6
```

## Usage Example

```python
from xperiential import typewriter, square, ascii_print

# Typewriter animation
typewriter("Welcome to Xperiential!", duration=0.05)

# Draw a square
square()

# Print ASCII text
ascii_print("Xperiential")
```

## Dependencies
Xperiential requires the following Python packages:
* ascii-magic
* pillow
* pyfiglet
* tkinter (standard library)
* turtle (standard library)

## License
This package is proprietary software owned by Cloudberry Pi Foundations.  
All rights reserved. Redistribution or modification without explicit permission is strictly prohibited.

## Contact
For inquiries, collaborations, or licensing requests, please contact:  
Cloudberry Pi Foundations  
Xperiential© Team
