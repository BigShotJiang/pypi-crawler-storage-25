"""dazzle perf CLI implementations."""
