import sys

from app.cli import run_cli
from app.logging_config import setup_logging


def main() -> None:
    """Run the application entry point."""
    setup_logging()

    final_path = run_cli()
    sys.stdout.write(f"{final_path}\n")


if __name__ == "__main__":
    main()
