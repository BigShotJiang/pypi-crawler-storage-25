from dataclasses import dataclass


@dataclass(slots=True)
class AppConfig:
    """Application configuration."""

    app_name: str = "cd-browser"
    debug: bool = False
