from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from app.filesystem import list_directories
from app.history import SessionHistory


@dataclass(frozen=True, slots=True)
class VisibleEntry:
    """A directory row visible in the navigator."""

    name: str
    path: Path
    depth: int
    has_children: bool
    is_expanded: bool
    is_parent: bool = False


@dataclass(slots=True)
class Navigator:
    """State container for directory navigation behavior."""

    start_path: Path
    history: SessionHistory = field(default_factory=SessionHistory)
    current_path: Path = field(init=False)
    selected_index: int = field(init=False, default=0)
    _expanded_paths: set[Path] = field(init=False, default_factory=set)
    show_hidden: bool = False

    def __post_init__(self) -> None:
        self.current_path = self.start_path.expanduser().resolve()
        self.history.visit(self.current_path)

    @property
    def visible_entries(self) -> tuple[VisibleEntry, ...]:
        """Return the current flattened directory view."""

        entries = [
            VisibleEntry(
                name="..",
                path=self.current_path.parent,
                depth=0,
                has_children=True,
                is_expanded=False,
                is_parent=True,
            )
        ]
        entries.extend(self._build_entries(self.current_path, depth=0))
        return tuple(entries)

    @property
    def selected_entry(self) -> VisibleEntry:
        """Return the currently selected visible entry."""

        return self.visible_entries[self.selected_index]

    def set_selected_index(self, index: int) -> None:
        """Set the selected index within the visible entry range."""

        entry_count = len(self.visible_entries)
        if index < 0 or index >= entry_count:
            raise IndexError("Selected index out of range")

        self.selected_index = index

    def enter_selected_directory(self) -> Path:
        """Enter the currently selected directory and record it in history."""

        return self._change_directory(self.selected_entry.path)

    def go_to_parent_directory(self) -> Path:
        """Navigate to the parent directory of the current path."""

        return self._change_directory(self.current_path.parent)

    def expand_selected_directory(self) -> bool:
        """Expand the selected directory if it has children."""

        return self.expand_directory(self.selected_entry.path)

    def collapse_selected_directory(self) -> bool:
        """Collapse the selected directory when possible."""

        selected = self.selected_entry
        if selected.is_parent:
            return False

        if selected.path in self._expanded_paths:
            self._collapse_path(selected.path)
            return True

        if selected.depth > 0:
            parent = self._find_visible_parent(selected)
            self.set_selected_index(self.visible_entries.index(parent))
            return self.collapse_selected_directory()

        return False

    def expand_directory(self, path: Path) -> bool:
        """Expand a visible directory by path."""

        resolved_path = path.expanduser().resolve()

        for entry in self.visible_entries:
            if (
                entry.path == resolved_path
                and not entry.is_parent
                and entry.has_children
            ):
                self._expanded_paths.add(resolved_path)
                return True

        return False

    def collapse_directory(self, path: Path) -> bool:
        """Collapse a previously expanded directory by path."""

        resolved_path = path.expanduser().resolve()
        if resolved_path not in self._expanded_paths:
            return False

        self._collapse_path(resolved_path)
        return True

    def go_back(self) -> Path | None:
        """Move backward through navigation history."""

        path = self.history.back()
        if path is None:
            return None

        self._set_current_path(path)
        return path

    def go_forward(self) -> Path | None:
        """Move forward through navigation history."""

        path = self.history.forward()
        if path is None:
            return None

        self._set_current_path(path)
        return path

    def toggle_hidden(self) -> None:
        """Toggle showing/hiding hidden directory entries."""

        self.show_hidden = not self.show_hidden
        self.selected_index = 0
        self._expanded_paths.clear()

    def select_history_entry(self, index: int) -> Path:
        """Jump to a directory stored in session history."""

        path = self.history.select(index)
        self._set_current_path(path)
        return path

    def _build_entries(self, path: Path, depth: int) -> list[VisibleEntry]:
        entries: list[VisibleEntry] = []

        for directory in list_directories(path, show_hidden=self.show_hidden):
            is_expanded = directory.path in self._expanded_paths
            entries.append(
                VisibleEntry(
                    name=directory.name,
                    path=directory.path,
                    depth=depth,
                    has_children=directory.has_children,
                    is_expanded=is_expanded,
                )
            )

            if is_expanded:
                entries.extend(self._build_entries(directory.path, depth=depth + 1))

        return entries

    def _change_directory(self, path: Path) -> Path:
        resolved_path = path.expanduser().resolve()
        self.history.visit(resolved_path)
        self._set_current_path(resolved_path)
        return resolved_path

    def _set_current_path(self, path: Path) -> None:
        self.current_path = path.expanduser().resolve()
        self.selected_index = 0
        self._expanded_paths.clear()

    def _collapse_path(self, path: Path) -> None:
        self._expanded_paths = {
            expanded_path
            for expanded_path in self._expanded_paths
            if expanded_path != path and path not in expanded_path.parents
        }

    def _find_visible_parent(self, entry: VisibleEntry) -> VisibleEntry:
        entries = self.visible_entries
        current_index = entries.index(entry)

        for candidate_index in range(current_index - 1, -1, -1):
            candidate = entries[candidate_index]
            if (
                candidate.depth == entry.depth - 1
                and entry.path.parent == candidate.path
            ):
                return candidate

        raise ValueError("Visible parent entry not found")
