from __future__ import annotations

import curses
import os
import sys
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import TextIO

from app.navigator import Navigator, VisibleEntry

ESCAPE_KEY = 27


@dataclass(frozen=True, slots=True)
class RenderLine:
    """A rendered navigator row ready for terminal output."""

    text: str
    is_selected: bool


@dataclass(frozen=True, slots=True)
class HistoryLine:
    """A rendered history row ready for terminal output."""

    text: str
    is_selected: bool


def move_selection(current_index: int, step: int, entry_count: int) -> int:
    """Move the selected index within the available entry range."""

    if entry_count <= 0:
        return 0

    return max(0, min(current_index + step, entry_count - 1))


def format_entry(entry: VisibleEntry) -> str:
    """Format a visible entry for terminal display."""

    if entry.is_parent:
        return entry.name

    indent = "    " * entry.depth
    indicator = " "
    if entry.has_children:
        indicator = "▼" if entry.is_expanded else "▶"

    return f"{indent}{indicator} {entry.name}"


def build_render_lines(navigator: Navigator) -> list[RenderLine]:
    """Build all visible lines for the current navigator state."""

    return [
        RenderLine(
            text=format_entry(entry),
            is_selected=index == navigator.selected_index,
        )
        for index, entry in enumerate(navigator.visible_entries)
    ]


def build_history_lines(
    entries: tuple[Path, ...], selected_index: int
) -> list[HistoryLine]:
    """Build all visible lines for history mode."""

    return [
        HistoryLine(text=str(path), is_selected=index == selected_index)
        for index, path in enumerate(entries)
    ]


def clamp_scroll_offset(
    selected_index: int, scroll_offset: int, visible_count: int, total_count: int
) -> int:
    """Keep the selected row within the visible scrolling window."""

    if visible_count <= 0 or total_count <= visible_count:
        return 0

    max_offset = total_count - visible_count
    offset = max(0, min(scroll_offset, max_offset))

    if selected_index < offset:
        return selected_index

    if selected_index >= offset + visible_count:
        return selected_index - visible_count + 1

    return offset


class TerminalUI:
    """Minimal curses UI for the directory navigator MVP."""

    def __init__(self) -> None:
        self._history_mode = False
        self._history_selected_index = 0
        self._tree_scroll_offset = 0
        self._history_scroll_offset = 0

    def run(self, navigator: Navigator) -> Path:
        """Start the interactive session and return the final directory path."""

        with open_terminal_streams() as (input_stream, output_stream):
            with redirect_standard_streams(input_stream, output_stream):
                return curses.wrapper(self._run_session, navigator)

    def _run_session(self, stdscr: curses.window, navigator: Navigator) -> Path:
        curses.curs_set(0)
        stdscr.keypad(True)
        original_path = navigator.current_path

        while True:
            self._render(stdscr, navigator)
            key = stdscr.getch()

            if key == ESCAPE_KEY:
                return original_path

            if key == ord("h"):
                self._toggle_history_mode(navigator)
                continue

            if self._history_mode:
                self._handle_history_key(key, navigator)
                continue

            tree_result = self._handle_tree_key(key, navigator)
            if tree_result is not None:
                return tree_result

    def _render(self, stdscr: curses.window, navigator: Navigator) -> None:
        stdscr.erase()
        height, width = stdscr.getmaxyx()

        if self._history_mode:
            self._render_history_mode(stdscr, navigator, width=width, height=height)
            stdscr.refresh()
            return

        hidden_status = "on" if navigator.show_hidden else "off"
        path_text = f"{navigator.current_path} [hidden: {hidden_status}]"
        stdscr.addnstr(0, 0, path_text, width - 1)

        lines = build_render_lines(navigator)
        visible_count = max(0, height - 2)
        self._tree_scroll_offset = clamp_scroll_offset(
            navigator.selected_index,
            self._tree_scroll_offset,
            visible_count,
            len(lines),
        )

        for row, line in enumerate(
            lines[self._tree_scroll_offset : self._tree_scroll_offset + visible_count],
            start=2,
        ):
            if row >= height:
                break

            attributes = curses.A_REVERSE if line.is_selected else curses.A_NORMAL
            stdscr.addnstr(row, 0, line.text, width - 1, attributes)

        stdscr.refresh()

    def _render_history_mode(
        self, stdscr: curses.window, navigator: Navigator, width: int, height: int
    ) -> None:
        history_lines = build_history_lines(
            navigator.history.entries(), self._history_selected_index
        )
        start_row = 1
        visible_count = max(0, height - start_row - 1)
        self._history_scroll_offset = clamp_scroll_offset(
            self._history_selected_index,
            self._history_scroll_offset,
            visible_count,
            len(history_lines),
        )

        stdscr.addnstr(start_row, 0, "History:", width - 1, curses.A_BOLD)

        for index, line in enumerate(
            history_lines[
                self._history_scroll_offset : self._history_scroll_offset
                + visible_count
            ],
            start=1,
        ):
            row = start_row + index
            if row >= height:
                break

            attributes = curses.A_REVERSE if line.is_selected else curses.A_NORMAL
            stdscr.addnstr(row, 0, line.text, width - 1, attributes)

    def _toggle_history_mode(self, navigator: Navigator) -> None:
        self._history_mode = not self._history_mode
        if self._history_mode:
            self._history_selected_index = self._get_current_history_index(navigator)
            self._history_scroll_offset = 0

    def _handle_history_key(self, key: int, navigator: Navigator) -> None:
        history_entries = navigator.history.entries()

        if key == curses.KEY_UP:
            self._history_selected_index = move_selection(
                self._history_selected_index,
                step=-1,
                entry_count=len(history_entries),
            )
            return

        if key == curses.KEY_DOWN:
            self._history_selected_index = move_selection(
                self._history_selected_index,
                step=1,
                entry_count=len(history_entries),
            )
            return

        if key in (curses.KEY_ENTER, 10, 13) and history_entries:
            navigator.select_history_entry(self._history_selected_index)
            self._history_mode = False
            self._tree_scroll_offset = 0

    def _handle_tree_key(self, key: int, navigator: Navigator) -> Path | None:
        if key == curses.KEY_UP:
            navigator.set_selected_index(
                move_selection(
                    navigator.selected_index,
                    step=-1,
                    entry_count=len(navigator.visible_entries),
                )
            )
            return None

        if key == curses.KEY_DOWN:
            navigator.set_selected_index(
                move_selection(
                    navigator.selected_index,
                    step=1,
                    entry_count=len(navigator.visible_entries),
                )
            )
            return None

        if key == curses.KEY_RIGHT:
            was_expanded = navigator.selected_entry.is_expanded

            if not navigator.expand_selected_directory():
                navigator.enter_selected_directory()
                self._tree_scroll_offset = 0
                return None

            if was_expanded:
                navigator.enter_selected_directory()
                self._tree_scroll_offset = 0

            return None

        if key == curses.KEY_LEFT:
            if not navigator.collapse_selected_directory():
                navigator.go_to_parent_directory()
                self._tree_scroll_offset = 0

            return None

        if key == ord("b"):
            navigator.go_back()
            self._tree_scroll_offset = 0
            return None

        if key == ord("f"):
            navigator.go_forward()
            self._tree_scroll_offset = 0
            return None

        if key == ord("."):
            navigator.toggle_hidden()
            self._tree_scroll_offset = 0
            return None

        if key in (curses.KEY_ENTER, 10, 13):
            return navigator.selected_entry.path

        return None

    def _get_current_history_index(self, navigator: Navigator) -> int:
        history_entries = navigator.history.entries()

        for index in range(len(history_entries) - 1, -1, -1):
            if history_entries[index] == navigator.current_path:
                return index

        return 0


@contextmanager
def open_terminal_streams() -> Iterator[tuple[TextIO, TextIO]]:
    """Open terminal streams suitable for interactive rendering."""

    try:
        with (
            open("/dev/tty", encoding="utf-8") as input_stream,
            open("/dev/tty", "w", encoding="utf-8") as output_stream,
        ):
            yield input_stream, output_stream
            return
    except OSError:
        if not sys.stdin.isatty() or not sys.stderr.isatty():
            raise RuntimeError("Interactive terminal is required") from None

    yield sys.stdin, sys.stderr


@contextmanager
def redirect_standard_streams(
    input_stream: TextIO, output_stream: TextIO
) -> Iterator[None]:
    """Temporarily redirect stdin and stdout to terminal-backed streams."""

    sys.stdout.flush()
    sys.stderr.flush()

    original_stdin = os.dup(0)
    original_stdout = os.dup(1)

    try:
        os.dup2(input_stream.fileno(), 0)
        os.dup2(output_stream.fileno(), 1)
        yield
    finally:
        os.dup2(original_stdin, 0)
        os.dup2(original_stdout, 1)
        os.close(original_stdin)
        os.close(original_stdout)
