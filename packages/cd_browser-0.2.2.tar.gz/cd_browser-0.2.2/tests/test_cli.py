from pathlib import Path

import pytest

from app.cli import run_cli
from app.navigator import Navigator
from app.ui import TerminalUI


class StubUI(TerminalUI):
    def __init__(self, result: Path) -> None:
        self.result = result
        self.navigator: Navigator | None = None

    def run(self, navigator: Navigator) -> Path:
        self.navigator = navigator
        return self.result


def test_run_cli_uses_current_working_directory(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    stub_ui = StubUI(tmp_path)
    monkeypatch.setattr(Path, "cwd", lambda: tmp_path)

    result = run_cli(ui=stub_ui)

    assert result == tmp_path.resolve()
    assert stub_ui.navigator is not None
    assert stub_ui.navigator.current_path == tmp_path.resolve()


def test_run_cli_uses_provided_start_path(tmp_path: Path) -> None:
    start_path = tmp_path / "workspace"
    start_path.mkdir()
    final_path = tmp_path / "final"
    final_path.mkdir()
    stub_ui = StubUI(final_path)

    result = run_cli(start_path=start_path, ui=stub_ui)

    assert result == final_path.resolve()
    assert stub_ui.navigator is not None
    assert stub_ui.navigator.current_path == start_path.resolve()
