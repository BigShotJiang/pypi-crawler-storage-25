from pathlib import Path

import pytest

from app.main import main


def test_main_runs(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setattr("app.main.run_cli", lambda: Path("/tmp/final"))

    main()

    captured = capsys.readouterr()

    assert captured.out == "/tmp/final\n"
    assert captured.err == ""
