from pathlib import Path

import pytest

from app.history import SessionHistory


def test_visit_records_current_directory(tmp_path: Path) -> None:
    history = SessionHistory()
    first = tmp_path / "first"
    first.mkdir()

    visited = history.visit(first)

    assert visited == first.resolve()
    assert history.current == first.resolve()
    assert history.entries() == (first.resolve(),)


def test_visit_drops_forward_history_after_new_branch(tmp_path: Path) -> None:
    history = SessionHistory()
    first = tmp_path / "first"
    second = tmp_path / "second"
    third = tmp_path / "third"
    for path in (first, second, third):
        path.mkdir()

    history.visit(first)
    history.visit(second)
    assert history.back() == first.resolve()

    history.visit(third)

    assert history.entries() == (first.resolve(), third.resolve())
    assert history.current == third.resolve()
    assert history.forward() is None


def test_visit_does_not_duplicate_current_entry(tmp_path: Path) -> None:
    history = SessionHistory()
    directory = tmp_path / "directory"
    directory.mkdir()

    history.visit(directory)
    history.visit(directory)

    assert history.entries() == (directory.resolve(),)


def test_back_and_forward_move_through_history(tmp_path: Path) -> None:
    history = SessionHistory()
    first = tmp_path / "first"
    second = tmp_path / "second"
    for path in (first, second):
        path.mkdir()

    history.visit(first)
    history.visit(second)

    assert history.back() == first.resolve()
    assert history.back() is None
    assert history.forward() == second.resolve()
    assert history.forward() is None


def test_select_moves_to_specific_history_entry(tmp_path: Path) -> None:
    history = SessionHistory()
    first = tmp_path / "first"
    second = tmp_path / "second"
    for path in (first, second):
        path.mkdir()

    history.visit(first)
    history.visit(second)

    assert history.select(0) == first.resolve()
    assert history.current == first.resolve()


def test_select_raises_for_invalid_index() -> None:
    history = SessionHistory()

    with pytest.raises(IndexError):
        history.select(0)
