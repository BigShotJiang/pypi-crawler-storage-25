from pathlib import Path

import pytest

from app.filesystem import DirectoryEntry, has_subdirectories, list_directories


def test_has_subdirectories_detects_nested_directory(tmp_path: Path) -> None:
    parent = tmp_path / "parent"
    child = parent / "child"
    child.mkdir(parents=True)

    assert has_subdirectories(parent) is True


def test_has_subdirectories_returns_false_without_nested_directories(
    tmp_path: Path,
) -> None:
    directory = tmp_path / "empty"
    directory.mkdir()
    (directory / "file.txt").write_text("content", encoding="utf-8")

    assert has_subdirectories(directory) is False


def test_list_directories_returns_sorted_directory_metadata(tmp_path: Path) -> None:
    alpha = tmp_path / "alpha"
    beta = tmp_path / "Beta"
    file_path = tmp_path / "notes.txt"

    alpha.mkdir()
    beta.mkdir()
    (beta / "nested").mkdir()
    file_path.write_text("ignore me", encoding="utf-8")

    assert list_directories(tmp_path) == [
        DirectoryEntry(name="alpha", path=alpha, has_children=False),
        DirectoryEntry(name="Beta", path=beta, has_children=True),
    ]


def test_list_directories_raises_for_missing_directory(tmp_path: Path) -> None:
    missing_path = tmp_path / "missing"

    with pytest.raises(FileNotFoundError):
        list_directories(missing_path)


def test_list_directories_skips_permission_errors_for_children(tmp_path: Path) -> None:
    root = tmp_path / "root"
    root.mkdir()
    allowed = root / "allowed"
    blocked = root / "blocked"
    allowed.mkdir()
    blocked.mkdir()

    blocked.chmod(0)
    try:
        entries = list_directories(root)
    finally:
        blocked.chmod(0o700)

    assert any(entry.name == "allowed" for entry in entries)


def test_has_subdirectories_returns_false_on_permission_error(tmp_path: Path) -> None:
    blocked = tmp_path / "blocked"
    blocked.mkdir()

    blocked.chmod(0)
    try:
        result = has_subdirectories(blocked)
    finally:
        blocked.chmod(0o700)

    assert result is False
