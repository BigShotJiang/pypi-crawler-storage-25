from pathlib import Path

import pytest

from app.history import SessionHistory
from app.navigator import Navigator


def test_navigator_initial_state_includes_parent_entry(tmp_path: Path) -> None:
    current = tmp_path / "workspace"
    current.mkdir()
    alpha = current / "alpha"
    beta = current / "beta"
    alpha.mkdir()
    beta.mkdir()

    navigator = Navigator(current)

    assert navigator.current_path == current.resolve()
    assert navigator.selected_index == 0
    assert [entry.name for entry in navigator.visible_entries] == [
        "..",
        "alpha",
        "beta",
    ]


def test_toggle_hidden_directories(tmp_path: Path) -> None:
    root = tmp_path / "root"
    root.mkdir()
    visible = root / "visible"
    visible.mkdir()
    hidden = root / ".hidden"
    hidden.mkdir()

    navigator = Navigator(root)

    assert [entry.name for entry in navigator.visible_entries] == ["..", "visible"]

    navigator.toggle_hidden()
    assert navigator.show_hidden is True
    assert [entry.name for entry in navigator.visible_entries] == [
        "..",
        ".hidden",
        "visible",
    ]

    navigator.toggle_hidden()
    assert navigator.show_hidden is False
    assert [entry.name for entry in navigator.visible_entries] == ["..", "visible"]


def test_expand_selected_directory_reveals_nested_entries(tmp_path: Path) -> None:
    current = tmp_path / "workspace"
    current.mkdir()
    scripts = current / "scripts"
    scripts.mkdir()
    build = scripts / "build"
    build.mkdir()

    navigator = Navigator(current)
    navigator.set_selected_index(1)

    assert navigator.expand_selected_directory() is True
    assert [(entry.name, entry.depth) for entry in navigator.visible_entries] == [
        ("..", 0),
        ("scripts", 0),
        ("build", 1),
    ]


def test_expand_selected_directory_returns_false_without_children(
    tmp_path: Path,
) -> None:
    current = tmp_path / "workspace"
    current.mkdir()
    docs = current / "docs"
    docs.mkdir()

    navigator = Navigator(current)
    navigator.set_selected_index(1)

    assert navigator.expand_selected_directory() is False
    assert [entry.name for entry in navigator.visible_entries] == ["..", "docs"]


def test_collapse_selected_directory_hides_nested_entries(tmp_path: Path) -> None:
    current = tmp_path / "workspace"
    current.mkdir()
    scripts = current / "scripts"
    scripts.mkdir()
    (scripts / "build").mkdir()

    navigator = Navigator(current)
    navigator.set_selected_index(1)
    navigator.expand_selected_directory()

    assert navigator.collapse_selected_directory() is True
    assert [entry.name for entry in navigator.visible_entries] == ["..", "scripts"]


def test_collapse_selected_child_moves_to_parent_and_collapses(tmp_path: Path) -> None:
    current = tmp_path / "workspace"
    current.mkdir()
    scripts = current / "scripts"
    scripts.mkdir()
    (scripts / "build").mkdir()

    navigator = Navigator(current)
    navigator.set_selected_index(1)
    navigator.expand_selected_directory()
    navigator.set_selected_index(2)

    assert navigator.collapse_selected_directory() is True
    assert navigator.selected_entry.name == "scripts"
    assert [entry.name for entry in navigator.visible_entries] == ["..", "scripts"]


def test_enter_selected_directory_changes_current_path_and_updates_history(
    tmp_path: Path,
) -> None:
    current = tmp_path / "workspace"
    current.mkdir()
    child = current / "child"
    child.mkdir()

    history = SessionHistory()
    navigator = Navigator(current, history=history)
    navigator.set_selected_index(1)

    selected_path = navigator.enter_selected_directory()

    assert selected_path == child.resolve()
    assert navigator.current_path == child.resolve()
    assert navigator.selected_index == 0
    assert navigator.history.entries() == (current.resolve(), child.resolve())


def test_enter_parent_entry_moves_to_parent_directory(tmp_path: Path) -> None:
    parent = tmp_path / "parent"
    parent.mkdir()
    current = parent / "current"
    current.mkdir()

    navigator = Navigator(current)

    moved_path = navigator.enter_selected_directory()

    assert moved_path == parent.resolve()
    assert navigator.current_path == parent.resolve()


def test_go_to_parent_directory_moves_up_one_level(tmp_path: Path) -> None:
    parent = tmp_path / "parent"
    parent.mkdir()
    current = parent / "current"
    current.mkdir()

    navigator = Navigator(current)

    assert navigator.go_to_parent_directory() == parent.resolve()
    assert navigator.current_path == parent.resolve()


def test_history_navigation_restores_previous_path(tmp_path: Path) -> None:
    root = tmp_path / "root"
    root.mkdir()
    first = root / "first"
    second = root / "second"
    first.mkdir()
    second.mkdir()

    navigator = Navigator(root)
    navigator.set_selected_index(1)
    navigator.enter_selected_directory()
    navigator.go_to_parent_directory()
    navigator.set_selected_index(2)
    navigator.enter_selected_directory()

    assert navigator.go_back() == root.resolve()
    assert navigator.current_path == root.resolve()
    assert navigator.go_back() == first.resolve()
    assert navigator.go_forward() == root.resolve()
    assert navigator.go_forward() == second.resolve()


def test_select_history_entry_changes_current_path(tmp_path: Path) -> None:
    root = tmp_path / "root"
    root.mkdir()
    child = root / "child"
    child.mkdir()

    navigator = Navigator(root)
    navigator.set_selected_index(1)
    navigator.enter_selected_directory()

    assert navigator.select_history_entry(0) == root.resolve()
    assert navigator.current_path == root.resolve()


def test_set_selected_index_raises_for_invalid_index(tmp_path: Path) -> None:
    current = tmp_path / "workspace"
    current.mkdir()
    navigator = Navigator(current)

    with pytest.raises(IndexError):
        navigator.set_selected_index(1)
