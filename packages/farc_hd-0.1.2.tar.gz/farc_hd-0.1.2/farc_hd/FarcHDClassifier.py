from typing import OrderedDict
import warnings

import numpy as np
import time
import sys
import os
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.utils.validation import check_X_y, check_array, check_is_fitted
from sklearn.utils.multiclass import unique_labels
from sklearn.preprocessing import LabelEncoder

# Importamos tus componentes internos
from .FARCHD.myDataSetV2 import myDataSet
from .FARCHD.DataBase import DataBase
from .FARCHD.RuleBase import RuleBase
from .FARCHD.Apriori import Apriori
from .FARCHD.Population import Population
from .org.core.Randomize import Randomize
from .FARCHD.Fuzzy import fuzzificacion_total_numba

# --- CLASE AUXILIAR PARA SILENCIAR SALIDA ---
class HiddenPrints:
    def __enter__(self):
        self._original_stdout = sys.stdout
        self.devnull = open(os.devnull, 'w')
        sys.stdout = self.devnull

    def __exit__(self, exc_type, exc_val, exc_tb):
        sys.stdout = self._original_stdout
        self.devnull.close()

class FarcHDClassifier(BaseEstimator, ClassifierMixin):
    def __init__(self,
                 n_labels=5,                    # Number of Labels
                 minsup=0.05,                   # Minimum Support
                 minconf=0.8,                   # Minimum Confidence
                 depth=3,                       # Deph of Trees
                 k_parameter=2,                 # K
                 max_trials=20000,              # Maximum Evaluations (¡Importante! Esto soluciona tu problema del bucle)
                 population_size=50,            # Population Size
                 alpha=0.05,                    # Alpha (Ojo: en tu código por defecto tenías 0.05, aquí es 0.02)
                 bits_gen=30,                   # Bits per Gene
                 type_inference=1,              # Type of Inference
                 seed=53743421,                 # Seed
                 keel_dataset = None,           # keel's dataset for fast experiments
                 categorical_variables = None             # Scikit-learn can't know the difference between cat and num y the values are 0,1,2,3...N 
                 ):
        self.n_labels = n_labels
        self.minsup = minsup
        self.minconf = minconf
        self.depth = depth
        self.k_parameter = k_parameter
        self.max_trials = max_trials
        self.population_size = population_size
        self.alpha = alpha
        self.bits_gen = bits_gen
        self.type_inference = type_inference
        self.seed = seed
        self.keel_dataset = keel_dataset
        self.categorical_variables = categorical_variables

        self.keel_flag = False
        self.categorical_flag = False
        # 2 different extra inputs (keel dataset or array with categorical position values)
        if self.keel_dataset is not None:
            self.train_dataset_ = myDataSet()
            self.train_dataset_.lecturaDatos (keel_dataset, True)
            self.keel_flag = True
        if self.categorical_variables is not None:
            self.categorical_flag = True
        if self.keel_dataset is None and not self.categorical_flag:
            print("\n" + "!"*60)
            print("WARNING: FARC-HD Autodetection Mode Active")
            print("-" * 60)
            print("The program will automatically infer variable types:")
            print("1. Real Variables: Any column containing values with decimals (e.g., 1.5).")
            print("2. Categorical: Integer columns with a range 0 to N (max 10 categories).")
            print("3. Integer: Integer columns that don't fit the 0-N sequence or have > 10 values.")
            print("\nTo manually set types, use: model.set_categorical_variables([1, 5])")
            print("or a boolean list: [True, False, False, ...]")
            print("!"*60 + "\n")
    
    def fit(self, X = None, y = None):
        Randomize.setSeed(self.seed) 
        if self.keel_flag: # si es keel declaramos la X e y ahora
            if X is not None or y is not None:
                warnings.warn("Aviso: Has pasado X e y a fit(), pero serán ignorados porque configuraste 'keel_dataset' al crear el modelo.")
            X = self.train_dataset_.data

            y_strings = [self.train_dataset_.target_names[i] for i in self.train_dataset_.target]
            y = np.array(y_strings)
        else:
            #si no es keel, comprobar si usuario metio X e y
            if X is None or y is None:
                raise ValueError("En modo estándar, debes proporcionar X e y.")
        # Comprobar si son aptas para scikit-learn
        X, y = check_X_y(X, y)
        
        # Convertir clase de salida a 0,1,2...
        self.label_encoder_ = LabelEncoder()
        y_encoded = self.label_encoder_.fit_transform(y)
        self.classes_ = self.label_encoder_.classes_
        
        # Convertir Numpy a myDataSet si no es keel
        if self.keel_flag == False:
            self.train_dataset_ = myDataSet()
            self.train_dataset_.set_data_from_numpy(X, y_encoded, self.categorical_flag, self.categorical_variables)
        # Base de Datos y Fuzzificación
        self.data_base_ = DataBase(self.n_labels, self.train_dataset_)
        self.data_base_.fuzzificacion(self.train_dataset_)
        # Generación de Reglas (Apriori) y selección de reglas candidatas
        temp_rule_base = RuleBase(self.data_base_, self.train_dataset_, self.k_parameter, self.type_inference)
        self.apriori_ = Apriori(temp_rule_base, self.data_base_, self.train_dataset_, 
                                self.minsup, self.minconf, self.depth)
        self.apriori_.generateRB()
        # Optimización Evolutiva
        actual_pop_size = self.population_size + 1 if self.population_size % 2 > 0 else self.population_size
        
        self.pop_ = Population(self.train_dataset_, self.data_base_, temp_rule_base, 
                               actual_pop_size, self.bits_gen, self.max_trials, self.alpha)
        
        self.pop_.Generation()
        # Guardar el mejor modelo
        self.final_rule_base_ = self.pop_.getBestRB()
        self.final_rule_base_.almacenaPesos() 
        
        return self

    def predict(self, X):
        # Validaciones
        check_is_fitted(self, ['final_rule_base_', 'data_base_', 'label_encoder_'])
        # si usuario introduce un dataset entero, solo tiene en cuenta los datos
        if isinstance(X, str):
            print(f"Detectado archivo en predict. Leyendo: {X}")
            ds_test = myDataSet()
            ds_test.lecturaDatos(X, False)
            X = ds_test.data
        
        X = check_array(X)

        # Preparación de argumentos para Fuzzificación
        n_variables = X.shape[1]
        
        # Si en un futuro el numero de labels por cada variable es diferente
        # Crea un array con el numero de labels de cada variable
        if hasattr(self.data_base_, 'nLabels') and isinstance(self.data_base_.nLabels, np.ndarray):
             labels_per_var = self.data_base_.nLabels
        else:
             labels_per_var = np.full(n_variables, self.n_labels, dtype=np.int32)

        x0 = self.data_base_.x0_arr
        x1 = self.data_base_.x1_arr
        x3 = self.data_base_.x3_arr
        total_labels = self.data_base_.labelTotales

        # Fuzzificación Masiva (Batch)
        X_fuzz = fuzzificacion_total_numba(
            X, 
            n_variables, 
            labels_per_var, 
            x0, 
            x1, 
            x3, 
            total_labels
        )
        
        # Inferencia Masiva
        predictions_indices = self.final_rule_base_.predict_dataset(X_fuzz)
        
        # Decodificar etiquetas
        self.predicciones = self.label_encoder_.inverse_transform(predictions_indices)
        return self.predicciones
    def set_categorical_variables (self, categorical):
        self.categorical_variables = categorical
        self.categorical_flag = True

    def warm_up(self):
        print("\n" + "="*60)
        print(">>> INICIANDO SUPER CALENTAMIENTO (JIT COMPILATION)")
        print("="*60)
        
        start_warmup = time.time()
        
        # Guardamos los parámetros originales del usuario para no perderlos
        original_trials = self.max_trials
        original_pop = self.population_size
        original_inf = self.type_inference
        # 1. Generamos datos dummy aleatorios
        # 20 muestras, 3 variables, 2 clases
        X_dummy = (np.random.rand(20, 3) * 10).astype(np.float64) 
        y_dummy = np.random.choice([0, 1], 20).astype(np.int32)
    
        self.max_trials = 2
        self.population_size = 4
        
        try:
            # 2. Forzamos compilación para ambos modos de inferencia (0 y 1)
            # Esto compila todas las ramas del código de Numba
            for inf_mode in [0, 1]:
                self.type_inference = inf_mode
                
                # Usamos HiddenPrints para que no ensucie la consola
                with HiddenPrints():
                    # Llamamos a fit() real: esto activa toda la maquinaria (DataBase, Apriori, Population, Numba)
                    self.fit(X_dummy, y_dummy)
                    
                    # Llamamos a predict() para compilar la parte de test
                    self.predict(X_dummy)
                    
        except Exception as e:
            print(f"Advertencia durante WarmUp: {e}")
            
        finally:
            # 3. RESTAURAMOS la configuración original del usuario
            self.max_trials = original_trials
            self.population_size = original_pop
            self.type_inference = original_inf
            
            # Reseteamos los atributos de entrenamiento para dejar el objeto limpio
            if hasattr(self, 'train_dataset_'): del self.train_dataset_
            if hasattr(self, 'data_base_'): del self.data_base_
            if hasattr(self, 'apriori_'): del self.apriori_
            if hasattr(self, 'pop_'): del self.pop_
            if hasattr(self, 'final_rule_base_'): del self.final_rule_base_

        print(f">>> Calentamiento completado en {time.time() - start_warmup:.2f}s.")

    def print_rules(self, variables = None, classes = None):
        """
        Imprime las reglas difusas generadas por el modelo entrenado.
        
        Requiere que el modelo haya sido ajustado (fitted) previamente.
        """
        # 1. Validación de seguridad: ¿Está entrenado el modelo?
        check_is_fitted(self, ['final_rule_base_'])
        
        print("\n--- Base de Reglas Generada ---")
        self.final_rule_base_.setOriginalNamesToRules(variables,classes)
        print(self.final_rule_base_.printString())
        print("-------------------------------\n")
    
    # -------------------------------------------------------------------------
    # NOMBRE: print_predictions
    # DESCRIPCIÓN: 
    #   Muestra las predicciones de forma legible. 
    #   Permite comparar con el valor real (y_true) si se proporciona.
    # -------------------------------------------------------------------------
    def print_predictions(self, y_pred=None, y_true=None):
        # 1. Si no nos pasan predicciones externas, intentamos usar las internas
        if y_pred is None:
            if hasattr(self, 'predicciones'):
                y_pred = self.predicciones
            else:
                print("No hay predicciones disponibles para mostrar.")
                return

        print("\n--- Detalle de Predicciones ---")
        
        limit = 20 # Límite para no saturar la consola
        n_items = len(y_pred)
        count = min(n_items, limit)
        
        for i in range(count):
            pred_val = y_pred[i]
            
            # Si tenemos el valor real para comparar
            if y_true is not None and len(y_true) == n_items:
                real_val = y_true[i]
                match = "✅" if pred_val == real_val else "❌"
                print(f"Ejemplo {i:03d}: Pred={pred_val} | Real={real_val} {match}")
            else:
                # Solo predicción
                print(f"Ejemplo {i:03d}: {pred_val}")
                
        if n_items > limit:
            print(f"... y {n_items - limit} ejemplos más.")
        print("-------------------------------\n")