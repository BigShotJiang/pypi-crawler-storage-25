"""IM 服务（与 npm ImService 对齐）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage


class ImService(BaseClient):
    service_path = "im"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "im"

    def list_groups(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/groups", RequestOptions(
            method="GET",
            params=params or {},
        ))

    def create_group(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/groups", RequestOptions(method="POST", body=request))

    def get_room_messages(
        self,
        room_id: str,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/rooms/{room_id}/messages", RequestOptions(
            method="GET",
            params=params or {},
        ))
