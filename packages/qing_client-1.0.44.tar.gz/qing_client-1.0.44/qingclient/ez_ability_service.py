"""Ez 能力服务（与 npm EzAbilityService 对齐）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage


class EzAbilityService(BaseClient):
    service_path = "ez-ability"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "ez-ability"

    def enumerate_requirements(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/requirements/enumerate", RequestOptions(
            method="POST",
            body=request,
        ))

    def generate_prd(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/prd/generate", RequestOptions(method="POST", body=request))

    def get_tasks(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/tasks", RequestOptions(
            method="GET",
            params=params or {},
        ))

    def ability_call(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/ability/call", RequestOptions(method="POST", body=request))
