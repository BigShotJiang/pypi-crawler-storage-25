"""投递流服务（与 npm DeliveryStreamService 对齐）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage, PaginatedResponse


class DeliveryStreamService(BaseClient):
    service_path = "delivery-stream"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "delivery-stream"

    def list_streams(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("", RequestOptions(
            method="GET",
            params=params or {},
        ))

    def get_stream(
        self,
        stream_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/{stream_id}", RequestOptions(method="GET"))

    def create_stream(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("", RequestOptions(method="POST", body=request))

    def update_stream(
        self,
        stream_id: str,
        update_data: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/{stream_id}", RequestOptions(
            method="PUT",
            body=update_data,
        ))
