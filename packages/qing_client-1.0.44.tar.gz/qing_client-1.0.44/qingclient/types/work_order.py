"""工单服务类型（与 npm work-order types 对齐）。"""
from typing import Literal

WorkOrderStatus = Literal[
    "DRAFT",
    "PENDING",
    "ASSIGNED",
    "IN_PROGRESS",
    "PENDING_REVIEW",
    "COMPLETED",
    "CANCELLED",
    "REJECTED",
]

WorkOrderPriority = Literal["LOW", "MEDIUM", "HIGH"]
