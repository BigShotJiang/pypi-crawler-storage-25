"""通用类型：API 响应、分页、配置、请求选项。"""
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Generic, TypeVar

T = TypeVar("T")


@dataclass
class ApiResponse:
    success: bool
    message: str
    data: Any = None


@dataclass
class Pagination:
    page: int
    per_page: int
    total: int
    total_pages: int


@dataclass
class PaginatedResponse(Generic[T]):
    data: List[T]
    success: bool
    message: str = ""
    pagination: Optional[Dict[str, Any]] = None


@dataclass
class UserContext:
    """用户上下文（后端模式）。"""
    user_id: str
    role: str  # SUPER_ADMIN | ADMIN | STAFF | USER | SYSTEM | CAPABILITY_NODE
    project_id: str
    org_id: Optional[str] = None
    app_id: Optional[str] = None


@dataclass
class RequestOptions:
    method: str = "GET"
    headers: Optional[Dict[str, str]] = None
    params: Optional[Dict[str, Any]] = None
    body: Optional[Any] = None
    user_context: Optional[UserContext] = None
    project_id: Optional[str] = None
    org_id: Optional[str] = None
    app_id: Optional[str] = None


class TokenStorage:
    """同步内存 Token 存储，与 npm createMemoryTokenStorage 行为一致。"""

    def __init__(self) -> None:
        self._token: Optional[str] = None

    def get_token(self) -> Optional[str]:
        return self._token

    def set_token(self, token: str) -> None:
        self._token = token

    def clear_token(self) -> None:
        self._token = None


def create_memory_token_storage() -> TokenStorage:
    return TokenStorage()
