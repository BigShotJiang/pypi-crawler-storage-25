"""
Qing 平台统一 SDK - Python 客户端（与 npm 版 qing-client 对齐）。
"""
from ._version import __version__
from .client import Client
from .base_client import BaseClient
from . import types

from .auth_service import AuthService
from .msg_service import MsgService
from .user_service import UserService
from .token_service import TokenService
from .file_service import FileService
from .ai_service import AiService
from .aigc_service import AigcService
from .provider_service import ProviderService
from .usage_service import UsageService
from .audit_service import AuditLogService
from .fronthost_service import FrontHostService
from .org_service import OrgService
from .delivery_stream_service import DeliveryStreamService
from .ez_ability_service import EzAbilityService
from .im_service import ImService
from .hub_service import HubService
from .task_service import TaskService
from .notes_service import NotesService
from .memory_service import MemoryService
from .chat_service import ChatService
from .work_order_service import WorkOrderService

__all__ = [
    "__version__",
    "Client",
    "BaseClient",
    "AuthService",
    "MsgService",
    "UserService",
    "TokenService",
    "FileService",
    "AiService",
    "AigcService",
    "ProviderService",
    "UsageService",
    "AuditLogService",
    "FrontHostService",
    "OrgService",
    "DeliveryStreamService",
    "EzAbilityService",
    "ImService",
    "HubService",
    "TaskService",
    "NotesService",
    "MemoryService",
    "ChatService",
    "WorkOrderService",
    "types",
]
