"""审计日志服务（与 npm AuditLogService 对齐，servicePath: logs）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage, PaginatedResponse


class AuditLogService(BaseClient):
    service_path = "logs"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "audit"

    def list_logs(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("", RequestOptions(
            method="GET",
            params=params or {},
        ))

    def create_test_log(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/test", RequestOptions(method="POST", body=request))
