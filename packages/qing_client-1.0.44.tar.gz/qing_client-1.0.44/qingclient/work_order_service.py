"""工单服务（与 npm WorkOrderService 对齐）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage, PaginatedResponse


class WorkOrderService(BaseClient):
    """
    Work Order Service SDK
    通用工单中心 - 支持多租户、权限控制、审计存证、状态机、SOP 执行、证据链
    """
    service_path = "work-order"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "work-order"

    # ==================== Work Order CRUD ====================

    def create(self, dto: dict, options: Optional[RequestOptions] = None) -> Any:
        """创建工单。POST /work-orders"""
        return self.request("/work-orders", RequestOptions(method="POST", body=dto))

    def get_work_order(self, order_id: str, options: Optional[RequestOptions] = None) -> Any:
        """获取工单详情。GET /work-orders/:id"""
        return self.request(f"/work-orders/{order_id}", RequestOptions(method="GET"))

    def list_work_orders(
        self, query: Optional[dict] = None, options: Optional[RequestOptions] = None
    ) -> PaginatedResponse:
        """获取工单列表（分页）。GET /work-orders"""
        return self.paginated_request(
            "/work-orders", RequestOptions(method="GET", params=query or {})
        )

    def update_work_order(
        self, order_id: str, dto: dict, options: Optional[RequestOptions] = None
    ) -> Any:
        """更新工单。PATCH /work-orders/:id"""
        return self.request(
            f"/work-orders/{order_id}", RequestOptions(method="PATCH", body=dto)
        )

    def delete_work_order(self, order_id: str, options: Optional[RequestOptions] = None) -> Any:
        """删除工单（软删除）。DELETE /work-orders/:id"""
        return self.request(f"/work-orders/{order_id}", RequestOptions(method="DELETE"))

    # ==================== 状态与生命周期 ====================

    def change_status(
        self, order_id: str, status: str, reason: Optional[str] = None,
        options: Optional[RequestOptions] = None
    ) -> Any:
        """变更工单状态。PATCH /work-orders/:id/status"""
        body: dict = {"status": status, "reason": reason}
        return self.request(
            f"/work-orders/{order_id}/status",
            RequestOptions(method="PATCH", body=body),
        )

    def check_in(
        self, order_id: str, location: dict, options: Optional[RequestOptions] = None
    ) -> Any:
        """定位打卡。POST /work-orders/:orderId/checkin"""
        return self.request(
            f"/work-orders/{order_id}/checkin",
            RequestOptions(method="POST", body=location),
        )

    def complete_work_order(
        self, order_id: str, signature: Optional[str] = None,
        options: Optional[RequestOptions] = None
    ) -> Any:
        """完成工单。PATCH /work-orders/:id/complete"""
        return self.request(
            f"/work-orders/{order_id}/complete",
            RequestOptions(method="PATCH", body={"signature": signature}),
        )

    def verify_work_order(
        self, order_id: str, data: dict, options: Optional[RequestOptions] = None
    ) -> Any:
        """验收工单。PATCH /work-orders/:id/verify"""
        return self.request(
            f"/work-orders/{order_id}/verify",
            RequestOptions(method="PATCH", body=data),
        )

    # ==================== SOP 相关 ====================

    def create_sop_template(
        self, dto: dict, options: Optional[RequestOptions] = None
    ) -> Any:
        """创建 SOP 模板。POST /sop-templates"""
        return self.request("/sop-templates", RequestOptions(method="POST", body=dto))

    def list_sop_templates(
        self, query: Optional[dict] = None, options: Optional[RequestOptions] = None
    ) -> PaginatedResponse:
        """获取 SOP 模板列表（分页）。GET /sop-templates"""
        return self.paginated_request(
            "/sop-templates", RequestOptions(method="GET", params=query or {})
        )

    def activate_sop_template(self, id: str, options: Optional[RequestOptions] = None) -> Any:
        """启用 SOP 模板。PATCH /sop-templates/:id/activate"""
        return self.request(
            f"/sop-templates/{id}/activate", RequestOptions(method="PATCH")
        )

    def deactivate_sop_template(self, id: str, options: Optional[RequestOptions] = None) -> Any:
        """禁用 SOP 模板。PATCH /sop-templates/:id/deactivate"""
        return self.request(
            f"/sop-templates/{id}/deactivate", RequestOptions(method="PATCH")
        )

    def execute_check_item(
        self, order_id: str, dto: dict, options: Optional[RequestOptions] = None
    ) -> Any:
        """执行 checklist 项。PATCH /work-orders/:orderId/checklist"""
        return self.request(
            f"/work-orders/{order_id}/checklist",
            RequestOptions(method="PATCH", body=dto),
        )

    # ==================== 存证相关 ====================

    def add_evidence(
        self, order_id: str, dto: dict, options: Optional[RequestOptions] = None
    ) -> Any:
        """添加存证。POST /work-orders/:orderId/evidence"""
        return self.request(
            f"/work-orders/{order_id}/evidence",
            RequestOptions(method="POST", body=dto),
        )

    def get_evidence_chain(
        self, order_id: str, options: Optional[RequestOptions] = None
    ) -> Any:
        """获取完整证据链。GET /work-orders/:orderId/evidence"""
        return self.request(
            f"/work-orders/{order_id}/evidence", RequestOptions(method="GET")
        )

    # ==================== 查询与看板 ====================

    def list_by_subject(
        self,
        subject_type: str,
        subject_id: str,
        status: Optional[str] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse:
        """按业务主体查询工单。GET /work-orders?subjectType=&subjectId="""
        params: dict = {"subjectType": subject_type, "subjectId": subject_id}
        if status:
            params["status"] = status
        return self.paginated_request(
            "/work-orders", RequestOptions(method="GET", params=params)
        )

    def list_by_customer(
        self, customer_id: str, options: Optional[RequestOptions] = None
    ) -> PaginatedResponse:
        """查看顾客自己的工单。GET /customers/:customerId/work-orders"""
        return self.paginated_request(
            f"/customers/{customer_id}/work-orders", RequestOptions(method="GET")
        )

    def list_by_assignee(
        self, assignee_id: str, options: Optional[RequestOptions] = None
    ) -> PaginatedResponse:
        """查看执行人的工单。GET /assignees/:assigneeId/work-orders"""
        return self.paginated_request(
            f"/assignees/{assignee_id}/work-orders", RequestOptions(method="GET")
        )

    def get_detail_with_evidence(
        self, order_id: str, options: Optional[RequestOptions] = None
    ) -> Any:
        """获取工单详情（含完整证据链）。GET /work-orders/:id/detail"""
        return self.request(
            f"/work-orders/{order_id}/detail", RequestOptions(method="GET")
        )

    def get_sop_completion_rate(
        self, order_id: str, options: Optional[RequestOptions] = None
    ) -> Any:
        """获取 SOP 完成度。GET /work-orders/:id/sop-completion-rate"""
        return self.request(
            f"/work-orders/{order_id}/sop-completion-rate",
            RequestOptions(method="GET"),
        )

    def generate_report(
        self, order_id: str, payload: Optional[dict] = None,
        options: Optional[RequestOptions] = None
    ) -> Any:
        """生成服务报告。POST /work-orders/:orderId/report"""
        return self.request(
            f"/work-orders/{order_id}/report",
            RequestOptions(method="POST", body=payload or {}),
        )

    def list_reports(
        self, order_id: str, options: Optional[RequestOptions] = None
    ) -> Any:
        """获取报告列表。GET /work-orders/:orderId/reports"""
        return self.request(
            f"/work-orders/{order_id}/reports", RequestOptions(method="GET")
        )
