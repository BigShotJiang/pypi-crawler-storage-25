"""Usage 服务（与 npm UsageService 对齐，servicePath: providers）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage


class UsageService(BaseClient):
    """用量统计，与 Provider 共用 providers 路径。"""
    service_path = "providers"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "usage"

    def usage_summary(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/usage/summary", RequestOptions(
            method="GET",
            params=params or {},
        ))

    def usage_daily(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/usage/daily", RequestOptions(
            method="GET",
            params=params or {},
        ))
