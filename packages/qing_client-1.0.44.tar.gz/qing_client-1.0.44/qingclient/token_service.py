"""Token 服务（与 npm TokenService 对齐）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import (
    ClientConfig,
    RequestOptions,
    TokenStorage,
    WxOfficialAccountTokenResponse,
    WxJsapiTicketResponse,
    WxSignatureRequest,
    WxSignatureResponse,
    WxMiniProgramTokenResponse,
    WxMiniProgramLoginResponse,
    WxMiniProgramPhoneResponse,
)


class TokenService(BaseClient):
    service_path = "token"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "token"

    def get_wx_official_account_token(
        self,
        appid: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/wxh5/accesstoken", RequestOptions(
            method="GET",
            params={"appid": appid},
        ))

    def get_wx_jsapi_ticket(
        self,
        appid: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/wxh5/jsapi_ticket", RequestOptions(
            method="GET",
            params={"appid": appid},
        ))

    def get_wx_signature(
        self,
        signature_request: WxSignatureRequest,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        body = {
            "appid": signature_request.appid,
            "url": signature_request.url,
            "imgUrl": signature_request.imgUrl,
        }
        return self.request("/wxh5/signature", RequestOptions(
            method="POST",
            body=body,
        ))

    def get_wx_mini_program_token(
        self,
        appid: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/wxmp/accesstoken", RequestOptions(
            method="GET",
            params={"appid": appid},
        ))

    def wx_mini_program_login(
        self,
        appid: str,
        code: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/wxmp/login", RequestOptions(
            method="POST",
            body={"appid": appid, "code": code},
        ))

    def get_wx_mini_program_phone_number(
        self,
        appid: str,
        code: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """微信小程序获取用户手机号（与 token-service POST /wxmp/phone 对齐）."""
        return self.request("/wxmp/phone", RequestOptions(
            method="POST",
            body={"appid": appid, "code": code},
        ))
