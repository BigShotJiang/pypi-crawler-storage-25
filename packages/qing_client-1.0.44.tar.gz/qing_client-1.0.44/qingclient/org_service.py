"""组织服务（与 npm OrgService 对齐）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage, PaginatedResponse


class OrgService(BaseClient):
    service_path = "org"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "org"

    def resolve(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/org/resolve", RequestOptions(method="POST", body=request))

    def get_project(
        self,
        config_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/projects/{config_id}", RequestOptions(method="GET"))

    def get_project_apps(
        self,
        config_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/projects/{config_id}/apps", RequestOptions(method="GET"))

    def get_app(
        self,
        config_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/apps/{config_id}", RequestOptions(method="GET"))

    def admin_list_projects(
        self,
        query: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse:
        return self.paginated_request("/admin/projects", RequestOptions(
            method="GET",
            params=query or {},
        ))

    def admin_get_project(
        self,
        project_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/admin/projects/{project_id}", RequestOptions(method="GET"))
