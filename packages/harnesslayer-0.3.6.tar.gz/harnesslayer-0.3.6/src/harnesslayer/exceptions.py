class HarnesslayerError(Exception):
    """Base exception for the Harnesslayer SDK."""


class HarnesslayerHTTPError(HarnesslayerError):
    """Raised when the underlying HTTP request fails."""


class HarnesslayerResponseError(HarnesslayerError):
    """Raised when an API response cannot be parsed as expected."""


class HarnesslayerAPIError(HarnesslayerError):
    """Raised when the Harnesslayer API returns an error."""
