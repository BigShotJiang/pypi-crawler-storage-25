from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import (
    TYPE_CHECKING, 
    Any, 
    Mapping, 
    Optional
)

if TYPE_CHECKING:
    from ..resources.state import HarnesslayerState

@dataclass(frozen=True, slots=True)
class HarnesslayerProfileModel:
    id: str
    appId: str
    identifier: str
    currentSpending: float
    totalSpending: float
    metadata: Optional[dict[str, Any]]
    headStateId: Optional[str]
    initialChannelId: Optional[str]
    accessGroupId: Optional[str]
    lastResetAt: Optional[datetime]
    createdAt: datetime
    updatedAt: datetime

    state: HarnesslayerState

    @staticmethod
    def _parse_optional_datetime(value: Any) -> Optional[datetime]:
        if value is None:
            return None
        if isinstance(value, datetime):
            return value
        if isinstance(value, str):
            return datetime.fromisoformat(value)
        raise ValueError("Expected datetime, ISO datetime string, or None")

    @classmethod
    def _from_api(
        cls, 
        payload: Mapping[str, Any],
        state: HarnesslayerState,
    ) -> "HarnesslayerProfileModel":
        return cls(
            id=payload["id"],
            appId=payload["appId"],
            identifier=payload["identifier"],
            currentSpending=payload["currentSpending"],
            totalSpending=payload["totalSpending"],
            metadata=payload.get("metadata"),
            headStateId=payload.get("headStateId"),
            initialChannelId=payload.get("initialChannelId"),
            accessGroupId=payload.get("accessGroupId"),
            lastResetAt=cls._parse_optional_datetime(payload.get("lastResetAt")),
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),

            state=state,
        )
