from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class HarnesslayerOrganizationModel:
    id: str
    name: str
    slug: str
    createdBy: str
    createdAt: datetime
    updatedAt: datetime

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "HarnesslayerOrganizationModel":
        return cls(
            id=payload["id"],
            name=payload["name"],
            slug=payload["slug"],
            createdBy=str(payload["createdBy"]),
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
        )
