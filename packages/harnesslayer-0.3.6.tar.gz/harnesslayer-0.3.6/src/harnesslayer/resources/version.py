from __future__ import annotations

import io
import shutil
import tempfile
import time
import uuid
import zipfile
import hashlib
import mimetypes
from pathlib import Path
from typing import Any, Literal, Optional, TypedDict
from urllib.parse import quote

import httpx

from .._internal.constants import DEFAULT_DRIFTSTONE_API_BASE_URL
from .._internal.utils import safe_parse_json
from ..models.app import ApplicationType
from ..exceptions import (
    HarnesslayerHTTPError,
    HarnesslayerError, 
    HarnesslayerResponseError, 
    HarnesslayerAPIError
)
from ._base import AppBase, ResourceBase


FIXED_ZIP_TIME = (1980, 1, 1, 0, 0, 0)
IGNORED_ZIP_PATH_PARTS = {"__MACOSX"}
OPENCLAW_IGNORED_ZIP_PATH_PARTS = {
    "backups",
    "browser",
    "credentials",
    "mail-bridge",
    "scripts",
    "subagents",
    "tasks",
    "logs",
    "plugin-runtime-deps",
}
OPENCLAW_AGENT_SESSIONS_JSON = "sessions.json"
OPENCLAW_VERSION_INIT_EXTENSION_ID = "ext-1de79c32-d8e9-4f35-9c83-9e837e025769"
VERSION_SOURCE_CACHE_READY_SUFFIX = ".ready"
CloneTransformValue = dict[str, Any] | str

class VersionPathData(TypedDict):
    type: ApplicationType
    path: Path 

class HarnesslayerClientVersion(ResourceBase):
    def init(
        self,
        version_path: str,
        *,
        preset: Literal["openclaw"],
        poll_interval: float = 5.0,
        poll_timeout: float = 3600.0,
    ) -> str:
        if preset != "openclaw":
            raise HarnesslayerError("preset must be 'openclaw'")
        if poll_interval <= 0:
            raise HarnesslayerError("poll_interval must be greater than 0")
        if poll_timeout <= 0:
            raise HarnesslayerError("poll_timeout must be greater than 0")

        path_data = HarnesslayerVersion._validate_version_path(version_path)
        if path_data["type"] != preset:
            raise HarnesslayerError(
                f"preset '{preset}' does not match version_path type '{path_data['type']}'"
            )

        root = path_data["path"]
        source_sha256 = HarnesslayerVersion._hash_directory_contents(root)
        temp_version_res = self._client._request("POST", "/version/temp", {
            "sourceSha256": source_sha256,
            "type": preset,
            "extensionId": OPENCLAW_VERSION_INIT_EXTENSION_ID,
        })
        temp_version_data = temp_version_res.get("data")
        if not isinstance(temp_version_data, dict):
            raise HarnesslayerResponseError("Missing temp version data")

        version_id = temp_version_data.get("id")
        if not isinstance(version_id, str) or not version_id.strip():
            raise HarnesslayerResponseError("Temp version response did not include id")
        version_id = version_id.strip()

        if temp_version_data.get("exists") is True:
            return version_id

        source_cache_path = f"version/{source_sha256}"
        source_cache_ready_path = f"{source_cache_path}{VERSION_SOURCE_CACHE_READY_SUFFIX}"
        version_upload_path = f"versions/{version_id}"

        temp_dir = Path(tempfile.gettempdir()) / f"harnesslayer-version-{uuid.uuid4().hex}"
        temp_dir.mkdir(parents=True)
        completed = False

        try:
            for file_path in HarnesslayerVersion._iter_archive_files(root):
                destination = temp_dir / file_path.relative_to(root)
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(file_path, destination)

            headers = self._client._transport.headers
            with httpx.Client(
                base_url=f"{DEFAULT_DRIFTSTONE_API_BASE_URL}/{self._client.api_version}",
                timeout=self._client.timeout,
                headers=headers,
            ) as driftstone:
                copied_from_cache = self._copy_driftstone_contents(
                    driftstone=driftstone,
                    source_path=source_cache_path,
                    destination_path=version_upload_path,
                    source_ready_path=source_cache_ready_path,
                    cache_miss_ok=True,
                )
                if not copied_from_cache:
                    for file_path in sorted(
                        (path for path in temp_dir.rglob("*") if path.is_file()),
                        key=lambda path: path.relative_to(temp_dir).as_posix(),
                    ):
                        rel_path = file_path.relative_to(temp_dir).as_posix()
                        content_type = mimetypes.guess_type(rel_path)[0] or "application/octet-stream"
                        upload_path = quote(f"{version_upload_path}/{rel_path}", safe="/")
                        upload_response = driftstone.post(
                            f"repos/_tmp/contents/upload/{upload_path}",
                            json={"contentType": content_type},
                        )
                        upload_data = upload_response.json()
                        if upload_response.status_code >= 400 or upload_data.get("success") is False:
                            raise HarnesslayerAPIError(
                                f"Driftstone API returned error status {upload_response.status_code}: {upload_data}"
                            )

                        data = upload_data.get("data")
                        if not isinstance(data, dict) or not isinstance(data.get("url"), str):
                            raise HarnesslayerResponseError("Missing Driftstone upload URL")

                        put_response = httpx.put(
                            data["url"],
                            content=file_path.read_bytes(),
                            headers={"Content-Type": content_type},
                            timeout=900.0,
                        )
                        if put_response.status_code >= 400:
                            raise HarnesslayerAPIError(
                                f"Failed to upload version file {rel_path}: status {put_response.status_code}"
                            )

                    self._copy_driftstone_contents(
                        driftstone=driftstone,
                        source_path=version_upload_path,
                        destination_path=source_cache_path,
                        destination_ready_path=source_cache_ready_path,
                        cache_miss_ok=False,
                    )

                self._run_version_extension(
                    driftstone=driftstone,
                    extension_id=OPENCLAW_VERSION_INIT_EXTENSION_ID,
                    path=f"_tmp/versions/{version_id}",
                    poll_interval=poll_interval,
                    poll_timeout=poll_timeout,
                )

            self._client._request("POST", "/version/temp", {
                "sourceSha256": source_sha256,
                "type": preset,
                "extensionId": OPENCLAW_VERSION_INIT_EXTENSION_ID,
                "versionId": version_id,
                "status": "ready",
            })
            completed = True
        finally:
            if not completed:
                try:
                    self._client._request("POST", "/version/temp", {
                        "sourceSha256": source_sha256,
                        "type": preset,
                        "extensionId": OPENCLAW_VERSION_INIT_EXTENSION_ID,
                        "versionId": version_id,
                        "status": "failed",
                    })
                except Exception:
                    pass
            shutil.rmtree(temp_dir, ignore_errors=True)

        return version_id

    def _copy_driftstone_contents(
        self,
        *,
        driftstone: httpx.Client,
        source_path: str,
        destination_path: str,
        source_ready_path: str | None = None,
        destination_ready_path: str | None = None,
        cache_miss_ok: bool,
    ) -> bool:
        payload: dict[str, Any] = {
            "sourcePath": source_path,
            "destinationPath": destination_path,
            "overwrite": True,
        }
        if source_ready_path is not None:
            payload["sourceReadyPath"] = source_ready_path
        if destination_ready_path is not None:
            payload["destinationReadyPath"] = destination_ready_path

        copy_response = driftstone.post("repos/_tmp/contents/copy", json=payload)
        try:
            copy_data = copy_response.json()
        except ValueError as exc:
            raise HarnesslayerResponseError(
                f"Driftstone content copy returned non-JSON response (status={copy_response.status_code})"
            ) from exc

        if copy_response.status_code == 404 and cache_miss_ok:
            return False

        if copy_response.status_code >= 400 or copy_data.get("success") is False:
            raise HarnesslayerAPIError(
                f"Driftstone content copy returned status {copy_response.status_code}: {copy_data}"
            )

        data = copy_data.get("data")
        if not isinstance(data, dict):
            raise HarnesslayerResponseError("Driftstone content copy response did not include data")

        copied = data.get("copied")
        return isinstance(copied, int) and copied > 0

    def _run_version_extension(
        self,
        *,
        driftstone: httpx.Client,
        extension_id: str,
        path: str,
        poll_interval: float,
        poll_timeout: float,
    ) -> Any:
        run_response = driftstone.post(
            "extensions/run",
            json={
                "extensionId": extension_id,
                "path": path,
            },
        )
        run_data = run_response.json()
        if run_response.status_code >= 400 or run_data.get("success") is False:
            raise HarnesslayerAPIError(
                f"Driftstone extension run returned status {run_response.status_code}: {run_data}"
            )

        run_id = run_data.get("runId")
        if not isinstance(run_id, str) or not run_id.strip():
            raise HarnesslayerResponseError("Driftstone extension run response did not include runId")

        deadline = time.monotonic() + poll_timeout
        while True:
            poll_response = driftstone.get(f"extensions/poll/{run_id.strip()}")
            poll_data = poll_response.json()
            if poll_response.status_code >= 400 or poll_data.get("success") is False:
                raise HarnesslayerAPIError(
                    f"Driftstone extension poll returned status {poll_response.status_code}: {poll_data}"
                )

            status = poll_data.get("status")
            result = poll_data.get("result")
            if status == "failed":
                message = None
                if isinstance(result, dict):
                    message = result.get("error")
                raise HarnesslayerAPIError(
                    f"Driftstone extension run failed: {message or result or run_id}"
                )

            if status == "completed":
                return result

            if time.monotonic() >= deadline:
                raise HarnesslayerAPIError(
                    f"Timed out waiting for Driftstone extension run {run_id.strip()}"
                )

            time.sleep(poll_interval)

class HarnesslayerVersion(AppBase):
    @staticmethod
    def _validate_clone_transform(
        *,
        transform: Optional[dict[str, CloneTransformValue]],
    ) -> dict[str, Any]:
        if transform is None:
            return {}

        if not isinstance(transform, dict):
            raise HarnesslayerError("transform must be a dictionary")

        normalized: dict[str, CloneTransformValue] = {}
        for file_path, patch in transform.items():
            if not isinstance(file_path, str) or not file_path.strip():
                raise HarnesslayerError("transform keys must be non-empty strings")

            normalized_file_path = file_path.strip()
            normalized_file_path_lower = normalized_file_path.lower()
            if normalized_file_path_lower.endswith(".json"):
                if not isinstance(patch, dict):
                    raise HarnesslayerError(
                        f"transform['{file_path}'] must be a JSON object patch"
                    )
            elif normalized_file_path_lower.endswith(".md"):
                if not isinstance(patch, str):
                    raise HarnesslayerError(
                        f"transform['{file_path}'] must be Markdown string content"
                    )
            else:
                raise HarnesslayerError(
                    f"transform target must be a .json or .md file: {file_path}"
                )

            normalized[normalized_file_path] = patch

        return {"transform": normalized}

    @staticmethod
    def _resolve_out_path(out_path: str) -> Path:
        if not out_path or not isinstance(out_path, str):
            raise HarnesslayerError("out_path must be a non-empty string")

        path = Path(out_path)
        if not path.is_absolute():
            path = Path.cwd() / path

        root = path.resolve()
        if root.exists() and not root.is_dir():
            raise HarnesslayerError(f"out_path must be a directory: {root}")

        root.mkdir(parents=True, exist_ok=True)
        return root

    @staticmethod
    def _extract_zip(zip_bytes: bytes, out_dir: Path) -> None:
        with zipfile.ZipFile(io.BytesIO(zip_bytes), mode="r") as archive:
            for zip_info in archive.infolist():
                if not zip_info.filename:
                    continue

                destination = (out_dir / zip_info.filename).resolve()
                if not destination.is_relative_to(out_dir):
                    raise HarnesslayerError(f"Archive contains unsafe path: {zip_info.filename}")

                if zip_info.is_dir():
                    destination.mkdir(parents=True, exist_ok=True)
                    continue

                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(zip_info, mode="r") as source, destination.open("wb") as target:
                    target.write(source.read())

    @staticmethod
    def _validate_version_path(version_path: str) -> VersionPathData:
        path = Path(version_path)
        if not path.is_absolute():
            path = Path.cwd() / path

        root = path.resolve()

        if not root.exists():
            raise HarnesslayerError(f"Version path does not exist: {root}")
        if not root.is_dir():
            raise HarnesslayerError(f"Version path must be a directory: {root}")
        
        if version_path.endswith(".claude"):
            # there must be agent.json file in the root directory
            agent_json_path = root / "agent.json"
            if not agent_json_path.exists() or not agent_json_path.is_file():
                raise HarnesslayerError(f"Invalid Agent version path: missing agent.json in '{root}'")
            
            # there must be an environment.json file in the root directory
            environment_json_path = root / "environment.json"
            if not environment_json_path.exists() or not environment_json_path.is_file():
                raise HarnesslayerError(f"Invalid Agent version path: missing environment.json in '{root}'")

            # agent.json must be a valid JSON file
            raw_agent_json = agent_json_path.read_text()
            agent_json = safe_parse_json(raw_agent_json)
            if not isinstance(agent_json, dict):
                raise ValueError("agent.json is not a valid JSON object")
            
            # if agent.json has skills field, it must be a list of objects with "type" field, and the type must be "anthropic"
            if "skills" in agent_json and isinstance(agent_json["skills"], list):
                for skill in agent_json["skills"]:
                    if not isinstance(skill, dict) or "type" not in skill:
                        raise ValueError("Each skill in agent.json must be an object with a 'name' field")

                    if skill["type"] != "anthropic":
                        raise ValueError("Only skills of type 'anthropic' are supported in agent.json, if you want custom skills you must add them as a folder under 'skills' directory")

            # there cant be other subdirectories except "skills"
            for item in root.iterdir():
                if item.name in IGNORED_ZIP_PATH_PARTS:
                    continue
                if item.is_dir() and item.name != "skills":
                    raise HarnesslayerError(f"Invalid Agent version path: unexpected subdirectory '{item.name}' in '{root}'")
                if item.is_file() and item.name != "agent.json" and item.name != "environment.json":
                    raise HarnesslayerError(f"Invalid Agent version path: unexpected file '{item.name}' in '{root}'")

            skills_dir = root / "skills"
            if skills_dir.exists() and skills_dir.is_dir():
                # each skill must be a directory containing SKILL.md file
                for skill_dir in skills_dir.iterdir():
                    if skill_dir.name in IGNORED_ZIP_PATH_PARTS:
                        continue
                    if not skill_dir.is_dir():
                        raise HarnesslayerError(f"Invalid Agent version path: skill '{skill_dir.name}' is not a directory in '{root}'")
                    skill_md_file = skill_dir / "SKILL.md"
                    if not skill_md_file.exists() or not skill_md_file.is_file():
                        raise HarnesslayerError(f"Invalid Agent version path: missing SKILL.md in skill '{skill_dir.name}' in '{root}'")

        elif version_path.endswith(".openclaw"):
            # there must be openclaw.json file in the root directory
            openclaw_config_file = root / "openclaw.json"
            if not openclaw_config_file.exists() or not openclaw_config_file.is_file():
                raise HarnesslayerError(f"Invalid OpenClaw version path: missing openclaw.json in '{root}'")
            
        else:
            raise HarnesslayerError(f"Version path must end with .claude or .openclaw: {version_path}")

        return {
            "type": "claude" if version_path.endswith(".claude") else "openclaw",
            "path": root,
        }

    @staticmethod
    def _iter_archive_files(root: Path) -> list[Path]:
        ignored_path_parts = {part.lower() for part in IGNORED_ZIP_PATH_PARTS}
        if root.name.lower() == ".openclaw":
            ignored_path_parts.update(OPENCLAW_IGNORED_ZIP_PATH_PARTS)

        return sorted(
            (
                p for p in root.rglob("*")
                if p.is_file()
                and not any(part.lower() in ignored_path_parts for part in p.relative_to(root).parts)
                and not HarnesslayerVersion._is_openclaw_workspace_git_file(root, p)
                and not HarnesslayerVersion._is_openclaw_workspace_public_file(root, p)
                and HarnesslayerVersion._should_include_openclaw_archive_file(
                    root,
                    p,
                )
            ),
            key=lambda p: p.relative_to(root).as_posix(),
        )

    @staticmethod
    def _is_openclaw_workspace_git_file(root: Path, file_path: Path) -> bool:
        if root.name.lower() != ".openclaw":
            return False

        rel_parts = tuple(part.lower() for part in file_path.relative_to(root).parts)
        return len(rel_parts) >= 3 and rel_parts[0] == "workspace" and rel_parts[1] == ".git"

    @staticmethod
    def _is_openclaw_workspace_public_file(root: Path, file_path: Path) -> bool:
        if root.name.lower() != ".openclaw":
            return False

        rel_parts = tuple(part.lower() for part in file_path.relative_to(root).parts)
        return len(rel_parts) >= 3 and rel_parts[0] == "workspace" and rel_parts[1] == "public"

    @staticmethod
    def _should_include_openclaw_archive_file(
        root: Path,
        file_path: Path,
    ) -> bool:
        if root.name.lower() != ".openclaw":
            return True

        rel_parts = file_path.relative_to(root).parts
        if len(rel_parts) < 4:
            return True

        if rel_parts[0].lower() != "agents" or rel_parts[2].lower() != "sessions":
            return True

        filename = rel_parts[3]
        if len(rel_parts) != 4:
            return False

        if filename == OPENCLAW_AGENT_SESSIONS_JSON:
            return True

        return file_path.suffix == ".jsonl" and file_path.stem != "" and not filename.endswith(".trajectory.jsonl")

    @staticmethod
    def _hash_directory_contents(root: Path) -> str:
        files = HarnesslayerVersion._iter_archive_files(root)

        digest = hashlib.sha256()
        for file_path in files:
            rel_path_bytes = file_path.relative_to(root).as_posix().encode("utf-8")
            file_bytes = file_path.read_bytes()
            digest.update(len(rel_path_bytes).to_bytes(8, "big"))
            digest.update(rel_path_bytes)
            digest.update(len(file_bytes).to_bytes(8, "big"))
            digest.update(file_bytes)

        return digest.hexdigest()

    @staticmethod
    def _build_zip(root: Path) -> tuple[Path, str]:
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp_file:
            zip_path = Path(tmp_file.name)

        with zipfile.ZipFile(zip_path, mode="w", compression=zipfile.ZIP_DEFLATED) as archive:
            files = HarnesslayerVersion._iter_archive_files(root)
            for file_path in files:
                arcname = file_path.relative_to(root).as_posix()
                zip_info = zipfile.ZipInfo(arcname, date_time=FIXED_ZIP_TIME)
                zip_info.compress_type = zipfile.ZIP_DEFLATED
                zip_info.external_attr = 0o644 << 16
                archive.writestr(zip_info, file_path.read_bytes())

        sha256 = HarnesslayerVersion._hash_directory_contents(root)
        return zip_path, sha256

    def create(self, version_path: str):
        zip_path: Path | None = None
        try:
            path_data = self._validate_version_path(version_path)
            
            zip_path, _sha256 = self._build_zip(path_data["path"])
            self._client._request_zip(
                "/version/create",
                payload={"appId": self._app_id},
                zip_bytes=zip_path.read_bytes(),
            )
        finally:
            if zip_path and zip_path.exists():
                zip_path.unlink()

    def clone(
        self,
        *,
        version_id: Optional[str] = None,
        transform: Optional[dict[str, CloneTransformValue]] = None,
    ) -> bool:
        try:
            payload: dict[str, Any] = {"appId": self._app_id}

            if version_id is not None:
                if not isinstance(version_id, str) or not version_id.strip():
                    raise Exception("version_id must be a non-empty string")
                payload["versionId"] = version_id.strip()

            payload.update(self._validate_clone_transform(transform=transform))

            self._client._request("POST", "/version/clone", payload)
            return True
        except HarnesslayerAPIError as e:
            if "Clone transforms did not produce any file changes" in str(e):
                return False
            raise
        except (HarnesslayerHTTPError, HarnesslayerResponseError):
            raise
        except HarnesslayerError:
            return False
        except Exception as e:
            raise e

    def download(
        self,
        out_path: str,
        version_id: Optional[str] = None,
    ) -> Path:
        target_version_id = version_id

        if target_version_id is None:
            latest_res = self._client._request("GET", "/version/latest", {
                "appId": self._app_id,
            })
            latest_data = latest_res.get("data")
            if not isinstance(latest_data, dict):
                raise HarnesslayerResponseError("No version exists for this app")

            target_version_id = latest_data.get("id")

        if not isinstance(target_version_id, str) or not target_version_id.strip():
            raise HarnesslayerError("version_id must be a non-empty string")

        download_res = self._client._request("GET", f"/version/download/{target_version_id}")
        data = download_res.get("data")
        if not isinstance(data, dict):
            raise HarnesslayerResponseError("Missing download data for version")

        download_url = data.get("url")
        if not isinstance(download_url, str) or not download_url.strip():
            raise HarnesslayerResponseError("Missing download URL for version")

        response = httpx.get(
            download_url,
            timeout=self._client.timeout,
            follow_redirects=True,
        )
        if response.status_code >= 400:
            raise HarnesslayerAPIError("Failed to download version archive")

        out_dir = self._resolve_out_path(out_path)
        self._extract_zip(response.content, out_dir)
        return out_dir

    def sync(self, strategy: Literal["ours", "theirs"] | None = None) -> bool:
        if strategy is not None and strategy not in {"ours", "theirs"}:
            raise HarnesslayerError("strategy must be 'ours', 'theirs', or None")

        payload: dict[str, Any] = {"appId": self._app_id}
        if strategy is not None:
            payload["strategy"] = strategy

        sync_res = self._client._request("POST", "/version/sync", payload)

        error = sync_res.get("error")
        if error:
            raise HarnesslayerAPIError(f"Failed to sync version: {error}")

        return True
