from __future__ import annotations

from ..exceptions import (
    HarnesslayerAPIError,
    HarnesslayerError,
    HarnesslayerHTTPError,
    HarnesslayerResponseError,
)
from ..models.instance import HarnesslayerInstanceModel
from ._base import AppBase

class HarnesslayerInstance(AppBase):
    def retrieve(self, instance_id: str) -> HarnesslayerInstanceModel:
        try:
            if not instance_id or not isinstance(instance_id, str):
                raise HarnesslayerError("instance_id must be a non-empty string")
        
            instance_get_res = self._client._request("GET", f"/instance/{instance_id}")

            return HarnesslayerInstanceModel._from_api(
                instance_get_res["data"],
            )
        except (HarnesslayerAPIError, HarnesslayerHTTPError, HarnesslayerResponseError):
            raise
        except HarnesslayerError:
            return None
        except Exception as e:
            raise e

    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 10,
    ) -> list[HarnesslayerInstanceModel]:
        if not isinstance(page, int) or page < 1:
            raise HarnesslayerError("page must be a positive integer")
        if not isinstance(page_size, int) or page_size < 1:
            raise HarnesslayerError("page_size must be a positive integer")

        instance_list_res = self._client._request(
            "GET",
            "/instance/list",
            {
                "appId": self._app_id,
                "page": page,
                "pageSize": page_size,
            },
        )

        data = instance_list_res.get("data")
        if not isinstance(data, list):
            raise HarnesslayerError("Expected 'data' to be a list in instance list response")

        return [HarnesslayerInstanceModel._from_api(item) for item in data]
