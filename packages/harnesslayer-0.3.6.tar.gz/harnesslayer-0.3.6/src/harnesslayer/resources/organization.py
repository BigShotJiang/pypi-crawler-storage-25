from __future__ import annotations

from typing import Optional

from ..exceptions import HarnesslayerError
from ..models.organization import HarnesslayerOrganizationModel
from ._base import ResourceBase


class HarnesslayerOrganization(ResourceBase):
    @staticmethod
    def _validate_slug(slug: str) -> str:
        if not isinstance(slug, str) or not slug.strip():
            raise HarnesslayerError("slug must be a non-empty string")

        trimmed_slug = slug.strip()
        if not all(c.isalnum() or c in "-_" for c in trimmed_slug):
            raise HarnesslayerError("slug must be URL-safe (only contain letters, numbers, hyphens, and underscores)")

        if trimmed_slug[0] in "-_" or trimmed_slug[-1] in "-_":
            raise HarnesslayerError("slug cannot start or end with a hyphen or underscore")

        return trimmed_slug

    def create(
        self,
        name: str,
        *,
        slug: str,
    ) -> HarnesslayerOrganizationModel:
        if not isinstance(name, str) or not name.strip():
            raise HarnesslayerError("name must be a non-empty string")

        payload = {
            "name": name.strip(),
            "slug": self._validate_slug(slug),
        }

        organization_create_res = self._client._request("POST", "/organization/create", payload)

        return HarnesslayerOrganizationModel._from_api(organization_create_res["data"])

    def update(
        self,
        organization_id: str,
        *,
        name: Optional[str] = None,
        slug: Optional[str] = None,
    ) -> HarnesslayerOrganizationModel:
        if not isinstance(organization_id, str) or not organization_id.strip():
            raise HarnesslayerError("organization_id must be a non-empty string")
        if name is None and slug is None:
            raise HarnesslayerError("At least one field must be provided to update")

        payload: dict[str, object] = {}
        if name is not None:
            if not isinstance(name, str) or not name.strip():
                raise HarnesslayerError("name must be a non-empty string")
            payload["name"] = name.strip()

        if slug is not None:
            payload["slug"] = self._validate_slug(slug)

        organization_update_res = self._client._request(
            "PATCH",
            f"/organization/{organization_id.strip()}",
            payload,
        )

        return HarnesslayerOrganizationModel._from_api(organization_update_res["data"])
