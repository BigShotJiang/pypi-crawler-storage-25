from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import Harnesslayer

class ResourceBase:
    def __init__(self, client: "Harnesslayer") -> None:
        self._client = client

class AppBase(ResourceBase):
    def __init__(self, client: "Harnesslayer", app_id: str) -> None:
        super().__init__(client)
        self._app_id = app_id

class ProfileBase(AppBase):
    def __init__(self, client: "Harnesslayer", app_id: str, profile_id: str) -> None:
        super().__init__(client, app_id)
        self._profile_id = profile_id
