from __future__ import annotations

from typing import Any

from ..exceptions import HarnesslayerError


class HarnesslayerResponse:
    def __init__(self, client: Any) -> None:
        self._client = client

    def stop(self, instance_id: str) -> dict[str, Any]:
        if not isinstance(instance_id, str) or not instance_id.strip():
            raise HarnesslayerError("instance_id must be a non-empty string")

        response = self._client._request(
            "POST",
            "/response/stop",
            {
                "instanceId": instance_id.strip(),
            },
        )
        data = response.get("data")
        if not isinstance(data, dict):
            raise HarnesslayerError("Expected 'data' to be an object in response stop response")
        return data
