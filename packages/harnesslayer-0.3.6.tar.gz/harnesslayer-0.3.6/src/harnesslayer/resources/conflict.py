from __future__ import annotations

from ..exceptions import (
    HarnesslayerAPIError,
    HarnesslayerError,
    HarnesslayerHTTPError,
    HarnesslayerResponseError,
)
from ..models.conflict import HarnesslayerConflictModel
from ._base import AppBase


class HarnesslayerConflict(AppBase):
    def retrieve(self, conflict_id: str) -> HarnesslayerConflictModel:
        try:
            if not conflict_id or not isinstance(conflict_id, str):
                raise HarnesslayerError("conflict_id must be a non-empty string")

            conflict_get_res = self._client._request("GET", f"/conflict/{conflict_id}")

            return HarnesslayerConflictModel._from_api(
                conflict_get_res["data"],
            )
        except (HarnesslayerAPIError, HarnesslayerHTTPError, HarnesslayerResponseError):
            raise
        except HarnesslayerError:
            return None
        except Exception as e:
            raise e

    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 10,
    ) -> list[HarnesslayerConflictModel]:
        if not isinstance(page, int) or page < 1:
            raise HarnesslayerError("page must be a positive integer")
        if not isinstance(page_size, int) or page_size < 1:
            raise HarnesslayerError("page_size must be a positive integer")

        conflict_list_res = self._client._request(
            "GET",
            "/conflict/list",
            {
                "appId": self._app_id,
                "page": page,
                "pageSize": page_size,
            },
        )

        data = conflict_list_res.get("data")
        if not isinstance(data, list):
            raise HarnesslayerError("Expected 'data' to be a list in conflict list response")

        return [HarnesslayerConflictModel._from_api(item) for item in data]
