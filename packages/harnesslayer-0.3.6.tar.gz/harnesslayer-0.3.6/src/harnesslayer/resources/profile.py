from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from ..exceptions import (
    HarnesslayerAPIError,
    HarnesslayerError,
    HarnesslayerHTTPError,
    HarnesslayerResponseError,
)
from ..models.profile import HarnesslayerProfileModel
from ._base import AppBase
from .state import HarnesslayerState

class HarnesslayerProfile(AppBase):
    def init(
        self, 
        identifier: str,
        *,
        state_path: Optional[str] = None,
        access_group_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
        auto_update_state: bool = True,
    ) -> HarnesslayerProfileModel:
        trimmed_identifier = identifier.strip()
        if not trimmed_identifier:
            raise HarnesslayerError("identifier must be a non-empty string")

        if state_path is not None and (not isinstance(state_path, str) or not state_path.strip()):
            raise HarnesslayerError("state_path must be a non-empty string")
        
        if access_group_id is not None and (not isinstance(access_group_id, str) or not access_group_id.strip()):
            raise HarnesslayerError("name must be a non-empty string")

        if metadata is not None and not isinstance(metadata, dict):
            raise HarnesslayerError("metadata must be a dictionary")

        payload: dict[str, Any] = {
            "appId": self._app_id,
            "identifier": trimmed_identifier,
            "autoUpdateState": auto_update_state,
        }
        zip_path: Path | None = None
        state_zip_bytes: bytes | None = None
        if state_path is not None:
            path_data = HarnesslayerState._validate_state_path(state_path)
            try:
                zip_path, _sha256 = HarnesslayerState._build_zip(path_data["path"])
                state_zip_bytes = zip_path.read_bytes()
            finally:
                if zip_path and zip_path.exists():
                    zip_path.unlink()

        if access_group_id is not None:
            payload["accessGroupId"] = access_group_id.strip()
        if metadata is not None:
            payload["metadata"] = metadata

        if state_zip_bytes is not None:
            profile_res = self._client._request_zip(
                "/profile/init",
                payload=payload,
                zip_bytes=state_zip_bytes,
            )
        else:
            profile_res = self._client._request("POST", "/profile/init", payload)
        profile_id = profile_res["data"]["id"]
        state = HarnesslayerState(self._client, self._app_id, profile_id)

        return HarnesslayerProfileModel._from_api(
            profile_res["data"], 
            state=state,
        )
    
    def retrieve(self, profile_id: str) -> HarnesslayerProfileModel:
        try:
            if not profile_id or not isinstance(profile_id, str):
                raise Exception("profile_id must be a non-empty string")
        
            profile_res = self._client._request("GET", f"/profile/{profile_id}")
            
            state = HarnesslayerState(self._client, self._app_id, profile_res["data"]["id"])

            return HarnesslayerProfileModel._from_api(
                profile_res["data"], 
                state=state,
            )
        except (HarnesslayerAPIError, HarnesslayerHTTPError, HarnesslayerResponseError):
            raise
        except HarnesslayerError:
            return None
        except Exception as e:
            raise e
     
    def state(self, profile_id: str) -> HarnesslayerState:
        trimmed_profile_id = profile_id.strip()
        if not profile_id:
            raise HarnesslayerError("profile_id must be a non-empty string")
        return HarnesslayerState(self._client, self._app_id, trimmed_profile_id)

    def delete(self, profile_id: str) -> bool:
        if not isinstance(profile_id, str) or not profile_id.strip():
            raise HarnesslayerError("profile_id must be a non-empty string")

        self._client._request("DELETE", f"/profile/{profile_id.strip()}")

        return True
