
from __future__ import annotations

from typing import Optional

from .._internal.constants import AVAILABLE_APP_TYPES
from ..models.app import (
    ApplicationType,
    HarnesslayerAppModel, 
    AppInitLimit, 
    AppInitCredential,
)
from ..exceptions import HarnesslayerError
from ._base import ResourceBase
from .version import HarnesslayerVersion
from .access_group import HarnesslayerAccessGroup
from .channel import HarnesslayerChannel
from .session import HarnesslayerSession
from .profile import HarnesslayerProfile
from .instance import HarnesslayerInstance
from .conflict import HarnesslayerConflict

class HarnesslayerApp(ResourceBase):
    def _build_app_model(self, app_data: dict) -> HarnesslayerAppModel:
        app_id = app_data["id"]

        version = HarnesslayerVersion(self._client, app_id)
        access_group = HarnesslayerAccessGroup(self._client, app_id)
        channel = HarnesslayerChannel(self._client, app_id)
        session = HarnesslayerSession(self._client, app_id)
        profile = HarnesslayerProfile(self._client, app_id)
        instance = HarnesslayerInstance(self._client, app_id)
        conflict = HarnesslayerConflict(self._client, app_id)

        return HarnesslayerAppModel._from_api(
            app_data,
            version=version,
            channel=channel,
            session=session,
            access_group=access_group,
            profile=profile,
            instance=instance,
            conflict=conflict,
        )

    def init(
        self, 
        slug: str,
        *,
        type: ApplicationType,
        version_path: Optional[str] = None,
        version_id: Optional[str] = None,
        name: Optional[str] = None,
        limit: Optional[AppInitLimit] = None,
        credentials: Optional[list[AppInitCredential]] = None,
        auto_update_version: bool = True,
    ) -> HarnesslayerAppModel:
        trimmed_slug = slug.strip()
        if not trimmed_slug:
            raise HarnesslayerError("slug must be a non-empty string")
        
        if not all(c.isalnum() or c in "-_" for c in trimmed_slug):
            raise HarnesslayerError("slug must be URL-safe (only contain letters, numbers, hyphens, and underscores)")

        if trimmed_slug[0] in "-_" or trimmed_slug[-1] in "-_":
            raise HarnesslayerError("slug cannot start or end with a hyphen or underscore")
        
        if type not in AVAILABLE_APP_TYPES:
            raise HarnesslayerError(f"type must be one of {AVAILABLE_APP_TYPES}")

        if version_path is not None and version_id is not None:
            raise HarnesslayerError("Only one of version_path or version_id may be provided")

        if version_path is not None and (not isinstance(version_path, str) or not version_path.strip()):
            raise HarnesslayerError("version_path must be a non-empty string")

        if version_id is not None and (
            not isinstance(version_id, str) or not version_id.strip()
        ):
            raise HarnesslayerError("version_id must be a non-empty string")
        
        if name is not None and (not isinstance(name, str) or not name.strip()):
            raise HarnesslayerError("name must be a non-empty string")
        
        if limit is not None and (not isinstance(limit, dict) or "amount" not in limit or "interval" not in limit):
            raise HarnesslayerError("limit must be a dictionary with 'amount' and 'interval' keys")
        
        if credentials is not None and (not isinstance(credentials, list) or not all(isinstance(cred, dict) for cred in credentials)):
            raise HarnesslayerError("credentials must be a list of dictionaries")
        
        zip_path = None
        try:
            additional_payload = {}
            if name is not None:
                additional_payload["name"] = name.strip()
            if limit is not None:
                additional_payload["limit"] = limit
            if credentials is not None:
                additional_payload["credentials"] = credentials

            version_payload = {}
            version_zip_bytes: bytes | None = None
            if version_path is not None:
                path_data = HarnesslayerVersion._validate_version_path(version_path)
                if path_data["type"] != type:
                    raise HarnesslayerError(
                        f"type '{type}' does not match version_path type '{path_data['type']}'"
                    )

                zip_path, _ = HarnesslayerVersion._build_zip(path_data["path"])
                version_zip_bytes = zip_path.read_bytes()
            elif version_id is not None:
                version_payload["tempVersionId"] = version_id.strip()

            app_payload = {
                "slug": trimmed_slug,
                "type": type,
                **additional_payload,
                **version_payload,
                "autoUpdateVersion": auto_update_version,
            }
            if version_zip_bytes is not None:
                app_init_res = self._client._request_zip(
                    "/app/init",
                    payload=app_payload,
                    zip_bytes=version_zip_bytes,
                )
            else:
                app_init_res = self._client._request("POST", "/app/init", app_payload)

            return self._build_app_model(app_init_res["data"])
        finally:
            if zip_path and zip_path.exists():
                zip_path.unlink()

    def retrieve(
        self, 
        *, 
        app_id: Optional[str] = None,
        slug: Optional[str] = None,
    ) -> HarnesslayerAppModel:
        try:
            if not app_id and not slug:
                raise Exception("Either app_id or slug must be provided")
            
            if app_id and slug:
                raise Exception("Only one of app_id or slug can be provided, not both")
            
            if app_id and not isinstance(app_id, str):
                raise Exception("app_id must be a string")
            
            if slug and not isinstance(slug, str):
                raise Exception("slug must be a string")
        
            app_res = self._client._request("GET", f"/app/{app_id or slug}")

            return self._build_app_model(app_res["data"])
        except HarnesslayerError:
            return None
        except Exception as e:
            raise e

    def delete(self, app_id: str) -> bool:
        if not isinstance(app_id, str) or not app_id.strip():
            raise HarnesslayerError("app_id must be a non-empty string")

        self._client._request("DELETE", f"/app/{app_id.strip()}")

        return True
    
    def channel(self, app_id: str) -> HarnesslayerChannel:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise HarnesslayerError("app_id must be a non-empty string")
        return HarnesslayerChannel(self._client, trimmed_app_id)

    def instance(self, app_id: str) -> HarnesslayerInstance:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise HarnesslayerError("app_id must be a non-empty string")
        return HarnesslayerInstance(self._client, trimmed_app_id)

    def access_group(self, app_id: str) -> HarnesslayerAccessGroup:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise HarnesslayerError("app_id must be a non-empty string")
        return HarnesslayerAccessGroup(self._client, trimmed_app_id)

    def profile(self, app_id: str) -> HarnesslayerProfile:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise HarnesslayerError("app_id must be a non-empty string")
        return HarnesslayerProfile(self._client, trimmed_app_id)

    def conflict(self, app_id: str) -> HarnesslayerConflict:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise HarnesslayerError("app_id must be a non-empty string")
        return HarnesslayerConflict(self._client, trimmed_app_id)
