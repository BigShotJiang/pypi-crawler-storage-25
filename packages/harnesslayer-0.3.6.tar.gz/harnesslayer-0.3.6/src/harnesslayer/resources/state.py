from __future__ import annotations

import io
import tempfile
import zipfile
import hashlib
from pathlib import Path
from typing import Any, Optional, TypedDict

import httpx

from .._internal.utils import safe_parse_json
from ..models.app import ApplicationType
from ..exceptions import (
    HarnesslayerHTTPError,
    HarnesslayerError, 
    HarnesslayerResponseError, 
    HarnesslayerAPIError
)
from ._base import ProfileBase


FIXED_ZIP_TIME = (1980, 1, 1, 0, 0, 0)
IGNORED_ZIP_PATH_PARTS = {"__MACOSX"}
CloneTransformValue = dict[str, Any] | str

class StatePathData(TypedDict):
    type: ApplicationType
    path: Path 

class HarnesslayerState(ProfileBase):
    @staticmethod
    def _validate_clone_transform(
        *,
        transform: Optional[dict[str, CloneTransformValue]],
    ) -> dict[str, Any]:
        if transform is None:
            return {}

        if not isinstance(transform, dict):
            raise HarnesslayerError("transform must be a dictionary")

        normalized: dict[str, CloneTransformValue] = {}
        for file_path, patch in transform.items():
            if not isinstance(file_path, str) or not file_path.strip():
                raise HarnesslayerError("transform keys must be non-empty strings")

            normalized_file_path = file_path.strip()
            normalized_file_path_lower = normalized_file_path.lower()
            if normalized_file_path_lower.endswith(".json"):
                if not isinstance(patch, dict):
                    raise HarnesslayerError(
                        f"transform['{file_path}'] must be a JSON object patch"
                    )
            elif normalized_file_path_lower.endswith(".md"):
                if not isinstance(patch, str):
                    raise HarnesslayerError(
                        f"transform['{file_path}'] must be Markdown string content"
                    )
            else:
                raise HarnesslayerError(
                    f"transform target must be a .json or .md file: {file_path}"
                )

            normalized[normalized_file_path] = patch

        return {"transform": normalized}

    @staticmethod
    def _resolve_out_path(out_path: str) -> Path:
        if not out_path or not isinstance(out_path, str):
            raise HarnesslayerError("out_path must be a non-empty string")

        path = Path(out_path)
        if not path.is_absolute():
            path = Path.cwd() / path

        root = path.resolve()
        if root.exists() and not root.is_dir():
            raise HarnesslayerError(f"out_path must be a directory: {root}")

        root.mkdir(parents=True, exist_ok=True)
        return root

    @staticmethod
    def _extract_zip(zip_bytes: bytes, out_dir: Path) -> None:
        with zipfile.ZipFile(io.BytesIO(zip_bytes), mode="r") as archive:
            for zip_info in archive.infolist():
                if not zip_info.filename:
                    continue

                destination = (out_dir / zip_info.filename).resolve()
                if not destination.is_relative_to(out_dir):
                    raise HarnesslayerError(f"Archive contains unsafe path: {zip_info.filename}")

                if zip_info.is_dir():
                    destination.mkdir(parents=True, exist_ok=True)
                    continue

                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(zip_info, mode="r") as source, destination.open("wb") as target:
                    target.write(source.read())

    @staticmethod
    def _validate_state_path(state_path: str) -> StatePathData:
        path = Path(state_path)
        if not path.is_absolute():
            path = Path.cwd() / path

        root = path.resolve()

        if not root.exists():
            raise HarnesslayerError(f"State path does not exist: {root}")
        if not root.is_dir():
            raise HarnesslayerError(f"State path must be a directory: {root}")
        
        if state_path.endswith(".claude"):
            # there must be agent.json file in the root directory
            agent_json_path = root / "agent.json"
            if not agent_json_path.exists() or not agent_json_path.is_file():
                raise HarnesslayerError(f"Invalid Agent state path: missing agent.json in '{root}'")
            
            # there must be an environment.json file in the root directory
            environment_json_path = root / "environment.json"
            if not environment_json_path.exists() or not environment_json_path.is_file():
                raise HarnesslayerError(f"Invalid Agent state path: missing environment.json in '{root}'")

            # agent.json must be a valid JSON file
            raw_agent_json = agent_json_path.read_text()
            agent_json = safe_parse_json(raw_agent_json)
            if not isinstance(agent_json, dict):
                raise ValueError("agent.json is not a valid JSON object")
            
            # if agent.json has skills field, it must be a list of objects with "type" field, and the type must be "anthropic"
            if "skills" in agent_json and isinstance(agent_json["skills"], list):
                for skill in agent_json["skills"]:
                    if not isinstance(skill, dict) or "type" not in skill:
                        raise ValueError("Each skill in agent.json must be an object with a 'name' field")

                    if skill["type"] != "anthropic":
                        raise ValueError("Only skills of type 'anthropic' are supported in agent.json, if you want custom skills you must add them as a folder under 'skills' directory")

            # there cant be other subdirectories except "skills"
            for item in root.iterdir():
                if item.name in IGNORED_ZIP_PATH_PARTS:
                    continue
                if item.is_dir() and item.name != "skills":
                    raise HarnesslayerError(f"Invalid Agent state path: unexpected subdirectory '{item.name}' in '{root}'")
                if item.is_file() and item.name != "agent.json" and item.name != "environment.json":
                    raise HarnesslayerError(f"Invalid Agent state path: unexpected file '{item.name}' in '{root}'")

            skills_dir = root / "skills"
            if skills_dir.exists() and skills_dir.is_dir():
                # each skill must be a directory containing SKILL.md file
                for skill_dir in skills_dir.iterdir():
                    if skill_dir.name in IGNORED_ZIP_PATH_PARTS:
                        continue
                    if not skill_dir.is_dir():
                        raise HarnesslayerError(f"Invalid Agent state path: skill '{skill_dir.name}' is not a directory in '{root}'")
                    skill_md_file = skill_dir / "SKILL.md"
                    if not skill_md_file.exists() or not skill_md_file.is_file():
                        raise HarnesslayerError(f"Invalid Agent state path: missing SKILL.md in skill '{skill_dir.name}' in '{root}'")

        elif state_path.endswith(".openclaw"):
            # there must be openclaw.json file in the root directory
            openclaw_config_file = root / "openclaw.json"
            if not openclaw_config_file.exists() or not openclaw_config_file.is_file():
                raise HarnesslayerError(f"Invalid OpenClaw state path: missing openclaw.json in '{root}'")
            
        else:
            raise HarnesslayerError(f"State path must end with .claude or .openclaw: {state_path}")

        return {
            "type": "claude" if state_path.endswith(".claude") else "openclaw",
            "path": root,
        }

    @staticmethod
    def _iter_archive_files(root: Path) -> list[Path]:
        return sorted(
            (
                p for p in root.rglob("*")
                if p.is_file()
                and not any(part in IGNORED_ZIP_PATH_PARTS for part in p.relative_to(root).parts)
                and not HarnesslayerState._is_openclaw_workspace_public_file(root, p)
            ),
            key=lambda p: p.relative_to(root).as_posix(),
        )

    @staticmethod
    def _is_openclaw_workspace_public_file(root: Path, file_path: Path) -> bool:
        if root.name.lower() != ".openclaw":
            return False

        rel_parts = tuple(part.lower() for part in file_path.relative_to(root).parts)
        return len(rel_parts) >= 3 and rel_parts[0] == "workspace" and rel_parts[1] == "public"

    @staticmethod
    def _hash_directory_contents(root: Path) -> str:
        files = HarnesslayerState._iter_archive_files(root)

        digest = hashlib.sha256()
        for file_path in files:
            rel_path_bytes = file_path.relative_to(root).as_posix().encode("utf-8")
            file_bytes = file_path.read_bytes()
            digest.update(len(rel_path_bytes).to_bytes(8, "big"))
            digest.update(rel_path_bytes)
            digest.update(len(file_bytes).to_bytes(8, "big"))
            digest.update(file_bytes)

        return digest.hexdigest()

    @staticmethod
    def _build_zip(root: Path) -> tuple[Path, str]:
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp_file:
            zip_path = Path(tmp_file.name)

        with zipfile.ZipFile(zip_path, mode="w", compression=zipfile.ZIP_DEFLATED) as archive:
            files = HarnesslayerState._iter_archive_files(root)
            for file_path in files:
                arcname = file_path.relative_to(root).as_posix()
                zip_info = zipfile.ZipInfo(arcname, date_time=FIXED_ZIP_TIME)
                zip_info.compress_type = zipfile.ZIP_DEFLATED
                zip_info.external_attr = 0o644 << 16
                archive.writestr(zip_info, file_path.read_bytes())

        sha256 = HarnesslayerState._hash_directory_contents(root)
        return zip_path, sha256

    def create(self, state_path: str):
        zip_path: Path | None = None
        try:
            path_data = self._validate_state_path(state_path)
            
            zip_path, _sha256 = self._build_zip(path_data["path"])
            self._client._request_zip(
                "/state/create",
                payload={"profileId": self._profile_id},
                zip_bytes=zip_path.read_bytes(),
            )
        finally:
            if zip_path and zip_path.exists():
                zip_path.unlink()

    def create_from_version(self, version_id: str) -> None:
        if not isinstance(version_id, str) or not version_id.strip():
            raise HarnesslayerError("version_id must be a non-empty string")

        version_res = self._client._request("GET", f"/version/{version_id.strip()}")
        version_data = version_res.get("data")
        if not isinstance(version_data, dict):
            raise HarnesslayerResponseError("Missing version data")

        storage_url = version_data.get("storageUrl")
        if not isinstance(storage_url, str) or not storage_url.strip():
            raise HarnesslayerResponseError("Missing storageUrl for version")

        self._client._request("POST", "/state/create", {
            "profileId": self._profile_id,
            "storageUrl": storage_url.strip(),
        })

    def clone(
        self,
        *,
        state_id: Optional[str] = None,
        version_id: Optional[str] = None,
        transform: Optional[dict[str, CloneTransformValue]] = None,
    ) -> bool:
        try:
            payload: dict[str, Any] = {"profileId": self._profile_id}

            if state_id is not None and version_id is not None:
                raise Exception("Cannot specify both state_id and version_id")

            if state_id is not None:
                if not isinstance(state_id, str) or not state_id.strip():
                    raise Exception("state_id must be a non-empty string")
                
                payload["stateId"] = state_id.strip()

            if version_id is not None:
                if not isinstance(version_id, str) or not version_id.strip():
                    raise Exception("version_id must be a non-empty string")
                
                payload["versionId"] = version_id.strip()

            payload.update(self._validate_clone_transform(transform=transform))

            self._client._request("POST", "/state/clone", payload)
            return True
        except HarnesslayerAPIError as e:
            if "Clone transforms did not produce any file changes" in str(e):
                return False
            raise
        except (HarnesslayerHTTPError, HarnesslayerResponseError):
            raise
        except HarnesslayerError:
            return False
        except Exception as e:
            raise e

    def download(
        self,
        out_path: str,
        state_id: Optional[str] = None,
    ) -> Path:
        target_state_id = state_id

        if target_state_id is None:
            latest_res = self._client._request("GET", "/state/latest", {
                "profileId": self._profile_id,
            })
            latest_data = latest_res.get("data")
            if not isinstance(latest_data, dict):
                raise HarnesslayerResponseError("No state exists for this profile")

            target_state_id = latest_data.get("id")

        if not isinstance(target_state_id, str) or not target_state_id.strip():
            raise HarnesslayerError("state_id must be a non-empty string")

        download_res = self._client._request("POST", f"/state/download/{target_state_id}")
        data = download_res.get("data")
        if not isinstance(data, dict):
            raise HarnesslayerResponseError("Missing download data for state")

        download_url = data.get("url")
        if not isinstance(download_url, str) or not download_url.strip():
            raise HarnesslayerResponseError("Missing download URL for state")

        response = httpx.get(
            download_url,
            timeout=self._client.timeout,
            follow_redirects=True,
        )
        if response.status_code >= 400:
            raise HarnesslayerAPIError("Failed to download state archive")

        out_dir = self._resolve_out_path(out_path)
        self._extract_zip(response.content, out_dir)
        return out_dir
