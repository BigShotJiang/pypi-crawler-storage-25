from __future__ import annotations

import asyncio
import sys
import unittest
from pathlib import Path
from typing import Any

ROOT_DIR = Path(__file__).resolve().parents[1]
SRC_DIR = ROOT_DIR / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from harnesslayer.models.channel import HarnesslayerChannelModel


class HarnesslayerChannelModelTests(unittest.TestCase):
    def test_bound_channel_run_accepts_images(self):
        calls: list[dict[str, Any]] = []
        images = [{"type": "input_image", "source": {"type": "url", "url": "https://example.com/cat.png"}}]

        def run(**kwargs: Any):
            calls.append(kwargs)
            return iter(())

        async def run_async(**kwargs: Any):
            calls.append(kwargs)
            if False:
                yield None

        channel = HarnesslayerChannelModel._from_api(
            {
                "id": "chan-123",
                "appId": "app-123",
                "type": "api",
                "name": "API",
                "createdAt": "2026-05-13T00:00:00+00:00",
                "updatedAt": "2026-05-13T00:00:00+00:00",
            },
            run=run,
            run_async=run_async,
        )

        list(channel.run(user_id="user-123", session_id="sess-123", input="hello", images=images))
        asyncio.run(_drain(channel.run_async(user_id="user-123", session_id="sess-123", input="hello", images=images)))

        self.assertEqual(calls, [
            {
                "channel_id": "chan-123",
                "user_id": "user-123",
                "session_id": "sess-123",
                "input": "hello",
                "images": images,
            },
            {
                "channel_id": "chan-123",
                "user_id": "user-123",
                "session_id": "sess-123",
                "input": "hello",
                "images": images,
            },
        ])


async def _drain(iterator: Any) -> None:
    async for _ in iterator:
        pass


if __name__ == "__main__":
    unittest.main()
