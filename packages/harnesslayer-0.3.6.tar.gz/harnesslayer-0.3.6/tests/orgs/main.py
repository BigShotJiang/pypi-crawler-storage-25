from harnesslayer import Harnesslayer

client = Harnesslayer(api_key="dk-af477848-dd2c-409d-84b1-b496c482f7c2")

client.organization.create(
    name="Test Organization",
    slug="test-organization",
)