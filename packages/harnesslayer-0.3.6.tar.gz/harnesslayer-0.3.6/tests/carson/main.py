from pathlib import Path
from harnesslayer import Harnesslayer

USER_IDENTIFIER = "16044401225"

client = Harnesslayer(api_key="dk-bf941a1e-2d8e-44f1-b5c2-25ef9b78a80c")

config_folder = str(Path(__file__).resolve().parent / ".openclaw")

# client.app.delete("app-bfed48cb-876b-460e-9578-2f343cf338a9")

app = client.app.init("carson-agent", 
    type="openclaw",
    version_path=config_folder,
    auto_update_version=False,
)

# app.version.sync(strategy="theirs")

# app.profile.delete("profile-35857f7e-360f-4724-a390-659a24357a61")

# channel = app.channel.init("carson-imessage", 
#     type="imessage",
#     data={
#         "sendBlueAPIKey": "8b93f24cff36b3ba1248402c6a2856bb",
#         "sendBlueSecretKey": "996d24e34c9ed0092c4eeebbbabfe3f9",
#         "fromNumber": "+14244726344",
#     },
# )

# stream = channel.run( 
#     session_id="test-session-1", 
#     user_id=USER_IDENTIFIER,
#     input="Can you change the name of the app to Typedef Claw but keep slug the same"
# )

# for event in stream:
#     if event.data["type"] == "driftstone.session_end":
#         break

#     print(event)
