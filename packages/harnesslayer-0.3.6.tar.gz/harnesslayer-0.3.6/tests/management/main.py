from pathlib import Path
from harnesslayer import Harnesslayer

client = Harnesslayer(api_key="dk-bf941a1e-2d8e-44f1-b5c2-25ef9b78a80c")

config_folder = str(Path(__file__).resolve().parent / ".openclaw")

# client.app.delete("app-1a7e4c06-3f95-4efe-8ae4-db8767509889")

app = client.app.init("management-agent", 
    type="openclaw",
    version_path=config_folder,
    auto_update_version=False,
)

# app.version.sync(strategy="theirs")

# app.profile.delete("profile-70b57efc-3502-4040-bd74-3c5f54583086")

# channel = app.channel.init("management-imessage", 
#     type="imessage",
#     data={
#         "sendBlueAPIKey": "8b93f24cff36b3ba1248402c6a2856bb",
#         "sendBlueSecretKey": "996d24e34c9ed0092c4eeebbbabfe3f9",
#         "fromNumber": "+13632189094",
#     },
# )

# app.profile.init(
#     identifier="15109183162",
#     metadata={
#         "HARNESSLAYER_APP_ID": "app-cc6e9f73-a8a9-4731-996d-4a63808061bd",
#         "HARNESSLAYER_API_KEY": "dk-661f7eb4-ee24-4f73-96c4-2dc0d283a236",
#     },
#     auto_update_state=False,
# )

# app.profile.init(
#     identifier="16044401225",
#     metadata={
#         "HARNESSLAYER_APP_ID": "app-918b5455-dcbd-401f-a372-e18750976eac",
#         "HARNESSLAYER_API_KEY": "dk-bf941a1e-2d8e-44f1-b5c2-25ef9b78a80c",
#     },
#     auto_update_state=False,
# )

# app.profile.init(
#     identifier="17742751688",
#     metadata={
#         "HARNESSLAYER_APP_ID": "app-918b5455-dcbd-401f-a372-e18750976eac",
#         "HARNESSLAYER_API_KEY": "dk-bf941a1e-2d8e-44f1-b5c2-25ef9b78a80c",
#     },
#     auto_update_state=False,
# )

# app.profile.init(
#     identifier="17606223016",
#     metadata={
#         "HARNESSLAYER_APP_ID": "app-f4d65113-f88e-48bd-ad3a-f81a15728ec6",
#         "HARNESSLAYER_API_KEY": "dk-bf941a1e-2d8e-44f1-b5c2-25ef9b78a80c",
#     },
#     auto_update_state=False,
# )
