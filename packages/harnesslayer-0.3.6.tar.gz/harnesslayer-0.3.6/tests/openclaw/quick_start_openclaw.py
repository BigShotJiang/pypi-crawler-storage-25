from pathlib import Path
from harnesslayer import Harnesslayer

CURRENT_USER = "stephen@pickaxe.co"

client = Harnesslayer(api_key="dk-661f7eb4-ee24-4f73-96c4-2dc0d283a236")

config_folder = str(Path(__file__).resolve().parent / ".openclaw")

# client.app.delete("app-1308c046-a238-450a-a8b6-ec27d7268fd3")

# version_id = client.version.init(r"C:\temp\.openclaw", preset="openclaw")

# app = client.app.init("typedef-claw", 
#     type="openclaw",
#     version_id=version_id,
#     auto_update_version=False,
# )

# app = client.app.retrieve(slug="typedef-claw")

# app.profile.delete("profile-89259750-37be-4ad8-a9ba-9f6da1dc24d9")

# app.version.sync(strategy="ours")

# app.version.clone(transform={
#     "cron/jobs.json": {
#         "jobs": {
#             "$all": {
#                 "enabled": True
#             }
#         }
#     }
# })

# channel = app.channel.init("my-api", 
#     type="api",
#     webhook={
#         "name": "Pickaxe Inbound",
#         "url": "https://core-pickaxe-api.pickaxe.co/agent/inbound",
#     }
# )

# channel = app.channel.init("my-imessage", 
#     type="imessage",
#     data={
#         "sendBlueAPIKey": "daf846bdbbd2d193ecc321162ab9ac4c",
#         "sendBlueSecretKey": "6f82d691172cb99fc3bb4ac2a639a242",
#         "fromNumber": "+17862139363",
#     },
# )

# profile = app.profile.init(
#     identifier=CURRENT_USER,
#     auto_update_state=False,
# )

# profile = app.profile.retrieve("profile-6c6e7341-865b-4930-90c8-e1538facc266")
# profile.state.download(r"C:\Users\asunc\Downloads\New folder")

# stream = channel.run(
#     session_id="my-custom-session-id",
#     user_id=CURRENT_USER, 
#     input="Hello"
# )

# for event in stream:
#     if event.data["type"] == "driftstone.session_end":
#         break

#     print(event)
