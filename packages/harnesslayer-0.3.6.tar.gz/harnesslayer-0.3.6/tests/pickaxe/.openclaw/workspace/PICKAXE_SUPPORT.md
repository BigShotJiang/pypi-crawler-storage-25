# PICKAXE_SUPPORT.md - Product Reference

This is the compact support reference for Pickaxe.co. Use it to answer common questions and guide users through Pickaxe workflows.

## Core Concept

Pickaxe is a no-code platform for building, launching, managing, deploying, and monetizing custom AI agents.

Agents are standalone AI tools configured for a specific purpose. Older docs or users may call them "pickaxes"; support should use "agents" and gently clarify the naming if needed.

Typical users include creators, consultants, agencies, businesses, teams, educators, and coaches.

## Build

### Agents Dashboard

The Agents dashboard is the home base for managing agents. Users can see agents, search, filter, sort, bulk-select, review usage, and open an agent in the builder.

### Agent Builder

The Agent Builder has three main areas:

- AI Helper: a guided builder. The user describes what they want, reviews proposed changes, and lets Pickaxe set up or refine the agent.
- Editor: direct control over the agent.
- Preview: live testing, including testing as specific users or access levels when available.

The Editor includes:

- Prompt: tool type, role instructions, model, capabilities, intro message, ice breakers, and model reminder.
- Configure: logo, placeholder text, token allocation, and appearance/resource settings.
- Knowledge: agent-specific knowledge sources and context instructions.
- Actions: external tools, APIs, other agents, and workflows.

### Prompting

Good prompts should:

- Define a specific role and job.
- Set boundaries and escalation rules.
- Specify tone and style.
- Use clear sections and examples.
- Put critical always-on rules in the model reminder.
- Explain exactly when actions should be used.
- Be tested and iterated in Preview.

If a response is poor, first look for unclear or conflicting instructions before adding more prompt text.

### Models

Pickaxe lets users choose among multiple AI models and switch models to balance quality, speed, cost, and action reliability. Do not claim a specific model list unless you checked current docs or the user's workspace.

## Knowledge Base

Knowledge gives agents additional context so responses can be grounded in the user's own content.

Supported source types include:

- Connected apps: Notion, OneNote, Google Drive, OneDrive/SharePoint
- Web URLs
- Audio: mp3
- Text files: pdf, docx, txt, xml, pptx, md
- Video: mp4
- Plain text
- Images: png, jpg, jpeg, webp, gif
- YouTube videos, playlists, or channels
- Data files: json, csv
- RSS feed URLs

Pickaxe checks connected sources daily for updates.

There are two places to manage knowledge:

- Workspace-level Knowledge Base: shared library for the workspace. Files are available to agents but not automatically attached by default.
- Agent-level Knowledge tab: sources and workspace files selected for a specific agent, plus context instructions for how the agent should use each source.

When troubleshooting knowledge:

- Confirm whether the file/source is in the workspace library or attached to the specific agent.
- Confirm the source has refreshed.
- Ask whether context instructions tell the agent when to rely on that source.
- Test in Preview with questions that should be answered by the attached content.

## Actions

Actions let an agent do more than chat, such as looking up data, sending an email, submitting a form, triggering a workflow, connecting to an API, or calling another agent.

For reliable actions, define usage conditions in two places:

- Main role prompt: when and why the agent should use the action.
- Trigger prompt: exact conditions that should fire that action.

Pickaxe recommends keeping a single agent to no more than four actions when possible. For more complex flows, suggest a waterfall setup: a primary routing agent delegates to focused agents with their own smaller action sets.

## Deploy

Deployments make an agent accessible to users. Access control and monetization can apply across deployment types.

Deployment types:

- Portals: branded, multi-agent hubs.
- Pages: standalone web pages for individual agents or collections.
- Direct link: shareable URL to the agent.
- Embeds: chat widget or inline embed on a website.
- Email bot: users interact by email.
- WhatsApp bot: users chat from their phone.
- Slack bot: users interact in a Slack workspace.
- API: programmatic access for custom integrations and workflows.

When helping with deployment, ask which deployment type the user is using and whether the issue is setup, styling, access, authentication, or agent behavior after launch.

## Access

Access management controls who can use tools and how users are segmented.

Two main access group types:

- Public access groups: open access, no login required.
- Member access groups: restricted access requiring signup or invitation.

Access questions often involve deployment settings, portal access tabs, user membership, usage limits, or monetization settings. Do not guess private user membership; ask the user to check the relevant Access or Users area.

## Monetization

Pickaxe supports several monetization models:

- Subscriptions: daily, weekly, monthly, or yearly tiers.
- Pay-per-usage: credits or uses that users can buy more of.
- One-time payment: upfront access.
- External payments: send users to a third-party payment provider and manage access manually.

Common setup path:

1. Go to Access and enable access control.
2. Create a member access group.
3. Open the Monetization and Upgrade tab.
4. Turn on charging for upgrade to that access group.
5. Choose one-time payment or subscription and set the price.
6. Connect Stripe from Settings if needed.

When users hit a limit, Pickaxe can offer more credits/uses, an upgrade to another access group, or an external payment link.

Offers are for selling one-off access to specific agents, pages, or folders of content without creating separate portals or access groups for each product. Offers are configured from the Lock tab in the portal editor.

Processing fees and plan details can change; verify current pricing or account settings before quoting exact commercial terms.

## Integrations

Pickaxe actions can connect to automation platforms through MCP, including Make, Zapier, and n8n.

For Make MCP:

- The user needs a Make API token with the MCP use scope.
- Do not use Make MCP host read or MCP host write scopes for Pickaxe connections.
- In Pickaxe, open Agent Builder, go to Actions, add an MCP server, choose the Make template, fill in the URL details and API token, save, enable the server, select tools/scenarios, and save.
- Prompt the agent with when to trigger the scenario, what inputs to send, and how to display the output.

Use current official docs before giving exact setup details for Zapier, n8n, or API schemas.

## Wingman and CLI

Pickaxe Wingman is an in-workspace assistant that can use the Pickaxe CLI under the hood. It can help build agents, manage knowledge bases, create deployments, write custom pages, configure actions, and more.

Wingman runs inside a workspace and inherits workspace credentials, so users do not need to paste an API key into Wingman. It shows proposed changes before applying them.

If a user asks for a complex build request, suggest Wingman when they are already inside Pickaxe and want a guided, in-product path.

## API

API deployments let users access agents programmatically for custom integrations, internal tools, applications, and workflows. API deployments can still use access control and monetization.

Before giving code-level API details, check the current Pickaxe API docs. Do not invent endpoint paths, auth header names, request fields, or response schemas.

## Troubleshooting Cheatsheet

### Agent gives vague or wrong answers

- Check role prompt specificity.
- Check model reminder for critical rules.
- Check whether the relevant knowledge is attached to the agent.
- Add context instructions to the knowledge source.
- Test in Preview and remove conflicting prompt rules.

### Agent ignores uploaded docs

- Confirm source type is supported.
- Confirm upload or connected source refreshed.
- Confirm workspace-level files were attached to the agent.
- Add explicit knowledge-use instructions.
- Ask a focused Preview question that should match the source.

### Action does not trigger

- Check the main role prompt.
- Check the action trigger prompt.
- Confirm the action or MCP server is enabled.
- Confirm required credentials and scopes are correct.
- Reduce competing actions or split into focused agents.

### User cannot access an agent

- Identify deployment type.
- Check whether it is public or member-only.
- Check the user's group membership.
- Check usage/credit limits.
- Check whether an offer, lock, or upgrade requirement applies.

### Monetization is not working

- Confirm access control is enabled.
- Confirm a member access group exists.
- Confirm monetization is enabled for upgrade to that group.
- Confirm Stripe or external payment setup.
- Confirm the deployment is using the intended access group.

