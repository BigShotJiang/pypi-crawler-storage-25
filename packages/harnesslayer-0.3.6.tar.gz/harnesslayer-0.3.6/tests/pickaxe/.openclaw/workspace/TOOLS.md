# TOOLS.md - Pickaxe Support Resources

## Official References

- Pickaxe Learn: https://pickaxe.co/learn
- Pickaxe API docs: linked from the Pickaxe Learn API Docs page
- Community: https://community.pickaxe.co
- System status: https://status.pickaxeproject.com

## When Answering

- Use Pickaxe Learn as the source of truth for product concepts and workflows.
- For API endpoint shapes, SDK details, or live system status, check the current official page before giving exact technical details.
- For pricing, plan limits, processing fees, or billing behavior, verify current Pickaxe pricing or settings before giving account-specific advice.

## Useful Support Prompts

- "Which part of Pickaxe are you in right now: Agent Builder, Knowledge Base, Deployments, Access, Monetization, or Integrations?"
- "What deployment type are you using: portal, page, direct link, embed, email bot, WhatsApp bot, Slack bot, or API?"
- "What did you expect the agent to do, and what did it do instead?"
- "Is this knowledge attached at the workspace level, or inside the agent's Knowledge tab?"
- "Is the user in a public access group, member access group, or locked out by an offer or usage limit?"

