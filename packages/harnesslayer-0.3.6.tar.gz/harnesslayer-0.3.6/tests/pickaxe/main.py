from pathlib import Path
from harnesslayer import Harnesslayer

USER_IDENTIFIER = "16044401225"

client = Harnesslayer(api_key="dk-bf941a1e-2d8e-44f1-b5c2-25ef9b78a80c")

config_folder = str(Path(__file__).resolve().parent / ".openclaw")

# client.app.delete("app-08c2e619-f1c7-4774-991b-e5f2562b5974")

app = client.app.init("pickaxe-agent", 
    type="openclaw",
    version_path=config_folder,
    auto_update_version=False,
)

# app.profile.delete("profile-bfd3da01-8e59-47fc-ac42-83417c22af0a")

# channel = app.channel.init("pickaxe-imessage", 
#     type="imessage",
#     data={
#         "sendBlueAPIKey": "8b93f24cff36b3ba1248402c6a2856bb",
#         "sendBlueSecretKey": "996d24e34c9ed0092c4eeebbbabfe3f9",
#         "fromNumber": "+15169524249",
#     },
# )

# app.profile.init(
#     identifier=USER_IDENTIFIER,
#     auto_update_state=False,
# )

# stream = channel.run( 
#     session_id="test-session-1", 
#     user_id=USER_IDENTIFIER,
#     input="Can you change the name of the app to Typedef Claw but keep slug the same"
# )

# for event in stream:
#     if event.data["type"] == "driftstone.session_end":
#         break

#     print(event)
