## Harnesslayer - Python

Python SDK for the Harnesslayer API.

### Install

```bash
pip install harnesslayer
```

### Quick Start

```python
from harnesslayer import Harnesslayer

client = Harnesslayer(api_key="your-api-key")

app = client.app.init("typedef-app", 
    type="claude", 
    version_path=".claude"
)

channel = app.channel.init("my-api", 
    type="api"
)

stream = channel.run(
    session_id="my-custom-session-id",
    user_id="stephen@pickaxe.co",
    input="hello world"
)

for event in stream:
    if event.done:
        break

    print(event)

```

### Using A Context Manager

```python
from harnesslayer import Harnesslayer

with Harnesslayer(api_key="your-api-key") as client:
    app = client.app.init("typedef-app", 
        type="claude", 
        version_path=".claude"
    )

    channel = app.channel.init("my-api", 
        type="api"
    )

    stream = channel.run(
        session_id="my-custom-session-id",
        user_id="stephen@pickaxe.co",
        input="hello world"
    )

    for event in stream:
        if event.done:
            break

        print(event)
    
```
