from typing import Any, Dict, List, Optional
from . import tools
from .api import _OllamaAPI
from .chat import Stream, StreamEvent, chat

_client = _OllamaAPI()

__all__ = [
    'chat',
    'Stream',
    'StreamEvent',
    'families',
    'models',
    'get_model_info',
    'list_model_servers',
    'get_server_info',
    'build_api_request',
    'get_llm_params',
    'get_random_llm_params',
    'tools',
]

__version__ = "1.0.0"


def families() -> List[str]:
    """Return all available model families from the package metadata."""
    return _client.list_families()


def models(family: Optional[str] = None) -> List[str]:
    """Return available model names, optionally filtered by family."""
    return _client.list_models(family)


def get_model_info(model: str) -> Dict[str, Any]:
    return _client.get_model_info(model)


def list_model_servers(model: str) -> List[Dict[str, Any]]:
    return _client.list_model_servers(model)


def get_server_info(model: str, server_url: Optional[str] = None) -> Dict[str, Any]:
    return _client.get_server_info(model, server_url)


def build_api_request(model: str, prompt: str, **kwargs: Any) -> Dict[str, Any]:
    return _client.build_api_request(model, prompt, **kwargs)


def get_llm_params(model: Optional[str] = None) -> Dict[str, str]:
    return _client.get_llm_params(model)


def get_random_llm_params() -> Dict[str, str]:
    return _client.get_random_llm_params()
