from dataclasses import dataclass
from typing import Iterator, Literal, Any, Optional
from .api import _OllamaAPI

_client = _OllamaAPI()

EventType = Literal[
    "start",
    "token",
    "end",
    "tool_call",
    "tool_result",
    "error",
    "meta"
]

@dataclass
class StreamEvent:
    type: EventType
    content: Optional[str] = None
    index: Optional[int] = None

    # For tool calling
    tool_name: Optional[str] = None
    tool_args: Optional[dict] = None
    tool_result: Any = None

    # Metadata / debugging
    meta: Optional[dict] = None

    # Timing / tracing (optional but useful)
    timestamp: Optional[float] = None

class Stream:
    def __init__(self):
        self.events: list[StreamEvent] = []

    def add(self, event: StreamEvent):
        self.events.append(event)

    def __iter__(self):
        return iter(self.events)

    def text(self) -> str:
        return "".join(
            e.content or ""
            for e in self.events
            if e.type == "token"
        )

def chat(
    prompt: str,
    *,
    model: str = "gpt-oss:20b",
    stream: bool = False,
    temperature: float = 0.7,
    max_tokens: int | None = None,
    top_p: float = 1.0,
    stop: list[str] | None = None,
) -> str | Stream:
    """Send a prompt to an Ollama model and return the response.

    This function supports both synchronous generation and streaming output.

    Args:
        prompt: The input text prompt for the model.
        model: The model name to use (defaults to 'gpt-oss:20b').
        stream: Whether to return streaming events.
        temperature: Sampling temperature.
        max_tokens: Maximum generated tokens.
        top_p: Nucleus sampling threshold.
        stop: Optional stop sequences.

    Returns:
        The text result when ``stream`` is False, or a ``Stream`` object when
        ``stream`` is True.
    """
    kwargs: dict[str, Any] = {
        'temperature': temperature,
        'top_p': top_p,
    }
    if max_tokens is not None:
        kwargs['num_predict'] = max_tokens
    if stop is not None:
        kwargs['stop'] = stop

    if stream:
        stream_obj = Stream()
        for event in _client._stream_chat(prompt, model, **kwargs):
            stream_obj.add(event)
        return stream_obj
    else:
        return _client._chat(prompt, model, **kwargs)