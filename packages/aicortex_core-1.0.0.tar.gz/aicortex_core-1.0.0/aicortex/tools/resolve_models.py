from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any, Dict, List


def load_ip_metadata(json_dir: Path) -> Dict[str, Dict[str, Any]]:
    """Load existing IP-level metadata from local Ollama model JSON files."""
    metadata: Dict[str, Dict[str, Any]] = {}

    for path in json_dir.rglob('*.json'):
        try:
            payload = json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            continue

        models = payload.get('props', {}).get('pageProps', {}).get('models', [])
        for model in models:
            ip_port = model.get('ip_port', '')
            if not ip_port:
                continue
            if not ip_port.startswith('http'):
                ip_port = 'http://' + ip_port

            if ip_port not in metadata:
                metadata[ip_port] = {
                    key: value
                    for key, value in model.items()
                    if key.startswith('ip_') or key.startswith('perf_')
                }

    return metadata


def resolve_models(
    fetched_file: Path,
    json_dir: Path,
    output_file: Path,
) -> Dict[str, Any]:
    """Resolve fetched model records into the original Ollama JSON structure."""
    fetched_data = json.loads(fetched_file.read_text(encoding='utf-8'))
    metadata = load_ip_metadata(json_dir)

    resolved_models: List[Dict[str, Any]] = []
    for record in fetched_data:
        source_url = record.get('source_url', '')
        base_ip_port = source_url.replace('/api/tags', '')
        if base_ip_port not in metadata:
            base_ip_port = base_ip_port.rstrip('/')

        meta = metadata.get(base_ip_port, {})
        for model_data in record.get('models', []):
            model_name = model_data.get('name') or model_data.get('model')
            resolved_models.append({
                'id': str(uuid.uuid4()),
                'ip_port': base_ip_port,
                'model_name': model_name,
                'model': model_data.get('model'),
                'modified_at': model_data.get('modified_at'),
                'size': str(model_data.get('size', '')),
                'digest': model_data.get('digest'),
                'parent_model': model_data.get('details', {}).get('parent_model', ''),
                'format': model_data.get('details', {}).get('format', ''),
                'family': model_data.get('details', {}).get('family', ''),
                'parameter_size': model_data.get('details', {}).get('parameter_size', ''),
                'quantization_level': model_data.get('details', {}).get('quantization_level', ''),
                'date_added': meta.get('date_added', model_data.get('modified_at')),
                **{k: v for k, v in meta.items() if k not in {
                    'date_added', 'ip_port', 'model_name', 'model', 'modified_at',
                    'size', 'digest', 'parent_model', 'format', 'family',
                    'parameter_size', 'quantization_level'
                }}
            })

    output_payload = {'props': {'pageProps': {'models': resolved_models}}}
    output_file.write_text(json.dumps(output_payload, indent=4, ensure_ascii=False), encoding='utf-8')
    return output_payload

resolve_fetched_models = resolve_models


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description='Resolve fetched Ollama model metadata into JSON output.')
    parser.add_argument('fetched_file', type=Path, help='Path to the fetched_models.json file.')
    parser.add_argument('json_dir', type=Path, help='Directory containing original Ollama JSON files for metadata lookup.')
    parser.add_argument('--output', type=Path, default=Path('resolved_valid_models.json'), help='Output file path.')
    args = parser.parse_args()

    result = resolve_fetched_models(args.fetched_file, args.json_dir, args.output)
    print(f"Resolved {len(result['props']['pageProps']['models'])} models into {args.output}")


if __name__ == '__main__':
    main()
