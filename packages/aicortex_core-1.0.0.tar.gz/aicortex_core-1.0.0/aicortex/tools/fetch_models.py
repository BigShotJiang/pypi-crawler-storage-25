from __future__ import annotations

import json
import socket
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Iterable, List, Optional
from urllib.error import HTTPError, URLError


def fetch_url_models(url: str, timeout: int = 10) -> Optional[dict]:
    """Fetch model metadata from a single validated Ollama endpoint.

    Args:
        url: URL to the Ollama endpoint, including /api/tags.
        timeout: Request timeout in seconds.

    Returns:
        A dictionary containing source_url and models if successful.

    Example:
        >>> from aicortex.tools.fetch_models import fetch_url_models
        >>> print(fetch_url_models('http://127.0.0.1:11434/api/tags'))
    """
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            if response.getcode() == 200:
                payload = json.loads(response.read().decode('utf-8'))
                return {'source_url': url, 'models': payload.get('models', [])}
    except (HTTPError, URLError, socket.timeout, ValueError):
        return None
    except Exception:
        return None
    return None


def read_urls(url_file: Path) -> List[str]:
    """Read endpoint URLs from a plain text file."""
    if not url_file.exists():
        return []

    return [line.strip() for line in url_file.read_text(encoding='utf-8').splitlines() if line.strip()]


def fetch_models(
    url_file: Path,
    output_file: Path,
    max_workers: int = 10,
    timeout: int = 10,
) -> List[dict]:
    """Fetch model JSON from all validated endpoints and save the consolidated result."""
    urls = read_urls(url_file)
    if not urls:
        return []

    results: List[dict] = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        for response in executor.map(lambda url: fetch_url_models(url, timeout=timeout), urls):
            if response:
                results.append(response)

    output_file.write_text(json.dumps(results, indent=4, ensure_ascii=False), encoding='utf-8')
    return results

fetch_models_from_urls = fetch_models


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description='Fetch Ollama models from a list of validated endpoints.')
    parser.add_argument('url_file', type=Path, help='Path to the file containing validated endpoint URLs.')
    parser.add_argument('--output', type=Path, default=Path('fetched_models.json'), help='Output JSON file path.')
    parser.add_argument('--timeout', type=int, default=10, help='Request timeout in seconds.')
    args = parser.parse_args()

    responses = fetch_models_from_urls(args.url_file, args.output, timeout=args.timeout)
    print(f'Saved model data from {len(responses)} endpoints to {args.output}')


if __name__ == '__main__':
    main()
