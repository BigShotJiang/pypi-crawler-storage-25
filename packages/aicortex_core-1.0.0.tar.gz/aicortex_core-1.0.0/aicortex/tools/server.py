from __future__ import annotations

import json
import uuid
import time
import os
from typing import Optional, List, Dict, Any, Iterator

try:
    from fastapi import FastAPI, HTTPException
    from fastapi.responses import StreamingResponse, JSONResponse
    from pydantic import BaseModel, Field
    import uvicorn
    FASTAPI_AVAILABLE = True
except ImportError:
    FASTAPI_AVAILABLE = False
    FastAPI = None
    HTTPException = None
    StreamingResponse = None
    JSONResponse = None
    BaseModel = None
    Field = None
    uvicorn = None

from aicortex.chat import chat
from aicortex.api import _OllamaAPI

_client = _OllamaAPI()


class Config:
    """Server configuration."""
    DEFAULT_MODEL: str
    HOST: str
    PORT: int

    def __init__(self, default_model: str = "gpt-oss:20b", host: str = "127.0.0.1", port: int = 8000):
        self.DEFAULT_MODEL = default_model
        self.HOST = host
        self.PORT = port


if FASTAPI_AVAILABLE:
    class Message(BaseModel):
        role: str
        content: str

    class ChatCompletionRequest(BaseModel):
        model: Optional[str] = Field(None, description="Model to use. If not provided, default model will be used.")
        messages: List[Message]
        stream: Optional[bool] = False
        temperature: Optional[float] = 0.7
        max_tokens: Optional[int] = None
        top_p: Optional[float] = 1.0

    class ModelInfo(BaseModel):
        id: str
        object: str = "model"
        created: int
        owned_by: str = "aicortex"

    class ModelsListResponse(BaseModel):
        object: str = "list"
        data: List[ModelInfo]

    class ModelResponse(BaseModel):
        models: List[str]
        default_model: str
        total_models: int
else:
    # Dummy classes to avoid NameError
    Message = None
    ChatCompletionRequest = None
    ModelInfo = None
    ModelsListResponse = None
    ModelResponse = None


def generate_sse_chunks(model: str, content_generator: Iterator[str], request_id: str) -> Iterator[str]:
    """Convert stream to OpenAI-compatible SSE format."""
    created = int(time.time())

    # First chunk: send role
    role_chunk = {
        "id": request_id,
        "object": "chat.completion.chunk",
        "created": created,
        "model": model,
        "choices": [{
            "index": 0,
            "delta": {"role": "assistant"},
            "finish_reason": None
        }]
    }
    yield f"data: {json.dumps(role_chunk)}\n\n"

    # Content chunks
    for text_piece in content_generator:
        content_chunk = {
            "id": request_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{
                "index": 0,
                "delta": {"content": text_piece},
                "finish_reason": None
            }]
        }
        yield f"data: {json.dumps(content_chunk)}\n\n"

    # Final chunk with finish_reason
    final_chunk = {
        "id": request_id,
        "object": "chat.completion.chunk",
        "created": created,
        "model": model,
        "choices": [{
            "index": 0,
            "delta": {},
            "finish_reason": "stop"
        }]
    }
    yield f"data: {json.dumps(final_chunk)}\n\n"
    yield "data: [DONE]\n\n"


def generate_non_stream_response(model: str, full_response: str, request_id: str) -> dict:
    """Generate standard OpenAI non-streaming response."""
    created = int(time.time())
    return {
        "id": request_id,
        "object": "chat.completion",
        "created": created,
        "model": model,
        "choices": [{
            "index": 0,
            "message": {
                "role": "assistant",
                "content": full_response
            },
            "finish_reason": "stop"
        }],
        "usage": {
            "prompt_tokens": 0,
            "completion_tokens": len(full_response.split()),
            "total_tokens": len(full_response.split())
        }
    }


def create_app(config: Config) -> Any:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title="AICortex OpenAI-Compatible Proxy",
        description=f"Default model: {config.DEFAULT_MODEL}",
        version="1.0.0"
    )

    @app.get("/")
    async def root():
        """Root endpoint with server info."""
        return {
            "service": "AICortex OpenAI-Compatible Proxy",
            "version": "1.0.0",
            "default_model": config.DEFAULT_MODEL,
            "endpoints": {
                "models": "/models",
                "openai_models": "/v1/models",
                "chat_completions": "/v1/chat/completions",
                "health": "/health"
            }
        }

    @app.get("/models")
    async def list_models_simple():
        """Simple endpoint that returns list of available models."""
        try:
            available_models = _client.list_models()
            return ModelResponse(
                models=available_models,
                default_model=config.DEFAULT_MODEL,
                total_models=len(available_models)
            )
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to fetch models: {str(e)}")

    @app.get("/v1/models")
    async def list_models_openai():
        """OpenAI-compatible models endpoint."""
        try:
            available_models = _client.list_models()
            created = int(time.time())
            model_list = [
                ModelInfo(
                    id=model_id,
                    created=created,
                    owned_by="aicortex"
                )
                for model_id in available_models
            ]
            return ModelsListResponse(data=model_list)
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/v1/chat/completions")
    async def chat_completions(request: ChatCompletionRequest):
        """OpenAI-compatible chat completions endpoint."""
        request_id = f"chatcmpl-{uuid.uuid4().hex[:8]}"

        # Use default model if not specified
        model_name = request.model if request.model else config.DEFAULT_MODEL

        # Validate model exists
        try:
            available_models = _client.list_models()
            if model_name not in available_models:
                raise HTTPException(
                    status_code=400,
                    detail=f"Model '{model_name}' not found. Available models: {available_models}"
                )
        except Exception as e:
            print(f"Warning: Could not validate model: {e}")

        # Extract the last user message as prompt
        user_messages = [m.content for m in request.messages if m.role == "user"]
        if not user_messages:
            raise HTTPException(status_code=400, detail="No user message found")
        prompt = user_messages[-1]

        try:
            if request.stream:
                # Streaming mode: return SSE response
                def stream_wrapper():
                    response = chat(
                        prompt,
                        model=model_name,
                        stream=True,
                        temperature=request.temperature,
                        max_tokens=request.max_tokens,
                        top_p=request.top_p
                    )
                    return generate_sse_chunks(
                        model=model_name,
                        content_generator=(event.content for event in response if event.type == "token"),
                        request_id=request_id
                    )

                return StreamingResponse(
                    stream_wrapper(),
                    media_type="text/event-stream",
                    headers={
                        "Cache-Control": "no-cache",
                        "Connection": "keep-alive",
                        "X-Accel-Buffering": "no",
                    }
                )
            else:
                # Non-streaming mode: collect and return full response
                response = chat(
                    prompt,
                    model=model_name,
                    stream=False,
                    temperature=request.temperature,
                    max_tokens=request.max_tokens,
                    top_p=request.top_p
                )
                return JSONResponse(
                    content=generate_non_stream_response(
                        model=model_name,
                        full_response=response,
                        request_id=request_id
                    )
                )

        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.get("/health")
    async def health_check():
        """Health check endpoint."""
        return {"status": "ok", "timestamp": time.time()}

    @app.get("/config")
    async def get_config():
        """Get current server configuration."""
        try:
            available_models = _client.list_models()
        except:
            available_models = []

        return {
            "default_model": config.DEFAULT_MODEL,
            "host": config.HOST,
            "port": config.PORT,
            "available_models": available_models,
            "model_count": len(available_models)
        }

    return app


def run_server(
    host: str = "127.0.0.1",
    port: int = 8000,
    default_model: str = "gpt-oss:20b",
    reload: bool = True,
) -> None:
    """Run the AICortex OpenAI-compatible proxy server.

    Args:
        host: Host to bind the server to.
        port: Port to bind the server to.
        default_model: Default model to use when not specified.
        reload: Whether to enable auto-reload for development.

    Raises:
        ImportError: If required dependencies (fastapi, uvicorn, pydantic) are not installed.
    """
    if not FASTAPI_AVAILABLE:
        raise ImportError(
            "FastAPI server requires additional dependencies. "
            "Install with: pip install fastapi uvicorn pydantic"
        )

    config = Config(default_model=default_model, host=host, port=port)
    app = create_app(config)

    print(f"""
╔══════════════════════════════════════════════════════════════╗
║     AICortex OpenAI-Compatible Proxy Server                ║
╠══════════════════════════════════════════════════════════════╣
║  Default Model: {config.DEFAULT_MODEL:<42} ║
║  Server URL:    http://{config.HOST}:{config.PORT:<32} ║
╠══════════════════════════════════════════════════════════════╣
║  Endpoints:                                                 ║
║    • GET  /models              - List all available models  ║
║    • GET  /v1/models           - OpenAI format models       ║
║    • POST /v1/chat/completions - Chat completions           ║
║    • GET  /health              - Health check               ║
║    • GET  /config              - Server configuration       ║
╚══════════════════════════════════════════════════════════════╝
    """.strip())

    uvicorn.run(
        app,
        host=config.HOST,
        port=config.PORT,
        reload=reload
    )


if __name__ == "__main__":
    run_server()