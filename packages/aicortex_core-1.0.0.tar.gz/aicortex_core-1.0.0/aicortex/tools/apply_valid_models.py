from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional


def infer_family(model: dict) -> str:
    family = model.get('family', '') or ''
    if not family or family == 'unknown':
        name = (model.get('model_name') or model.get('model') or '').lower()
        if 'mistral' in name:
            family = 'mistral'
        elif 'llama' in name:
            family = 'llama'
        elif 'gemma' in name:
            family = 'gemma'
        elif 'qwen' in name:
            family = 'qwen'
        elif 'deepseek' in name:
            family = 'deepseek'
        else:
            family = 'others'

    if family.startswith('qwen'):
        return 'qwen'
    if family.startswith('gemma'):
        return 'gemma'
    if family.startswith('llama'):
        return 'llama'
    if family.startswith('mistral'):
        return 'mistral'
    if family.startswith('deepseek'):
        return 'deepseek'
    return family


def group_models_by_family(models: Iterable[dict]) -> Dict[str, List[dict]]:
    grouped: Dict[str, List[dict]] = defaultdict(list)
    for model in models:
        family = infer_family(model)
        grouped[family].append(model)
    return grouped


def apply_valid_models(
    resolved_file: Path,
    json_dir: Path,
    backup: bool = False,
) -> List[Path]:
    """Write valid resolved models into family JSON files.

    Args:
        resolved_file: Path to the resolved model JSON payload.
        json_dir: Directory where family JSON files should be written.
        backup: If True, back up existing JSON files to a .backup folder.

    Returns:
        List of created JSON file paths.
    """
    resolved_file = Path(resolved_file)
    json_dir = Path(json_dir)
    output_paths: List[Path] = []

    payload = json.loads(resolved_file.read_text(encoding='utf-8'))
    models = payload.get('props', {}).get('pageProps', {}).get('models', [])
    if not isinstance(models, list):
        raise ValueError('Resolved payload does not contain a valid models list')

    if backup and json_dir.exists():
        backup_dir = json_dir.with_name(json_dir.name + '.backup')
        backup_dir.mkdir(parents=True, exist_ok=True)
        for existing_file in sorted(json_dir.glob('*.json')):
            existing_file.rename(backup_dir / existing_file.name)

    json_dir.mkdir(parents=True, exist_ok=True)

    grouped_models = group_models_by_family(models)
    for family, family_models in grouped_models.items():
        output_file = json_dir / f'{family}.json'
        output_payload = {'props': {'pageProps': {'models': family_models}}}
        output_file.write_text(json.dumps(output_payload, indent=4, ensure_ascii=False), encoding='utf-8')
        output_paths.append(output_file)

    return output_paths


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description='Apply resolved Ollama model metadata to family JSON files.')
    parser.add_argument('resolved_file', type=Path, help='Resolved models JSON file.')
    parser.add_argument('json_dir', type=Path, help='Target directory for family JSON files.')
    parser.add_argument('--backup', action='store_true', help='Move existing JSON files to a backup directory.')
    args = parser.parse_args()

    created = apply_valid_models(args.resolved_file, args.json_dir, backup=args.backup)
    print(f'Created {len(created)} model files in {args.json_dir}')


if __name__ == '__main__':
    main()
