from __future__ import annotations

import json
import socket
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Iterable, List, Optional
from urllib.error import HTTPError, URLError


def normalize_url(base_url: str) -> str:
    if not base_url.startswith('http'):
        base_url = 'http://' + base_url
    return base_url.rstrip('/')


def check_url(base_url: str, timeout: int = 5) -> Optional[str]:
    """Check a single Ollama endpoint by requesting /api/tags.

    Args:
        base_url: Base host or IP address for the Ollama endpoint.
        timeout: Request timeout in seconds.

    Returns:
        The validated endpoint URL if valid, otherwise None.

    Example:
        >>> from aicortex.tools.check_models import check_url
        >>> print(check_url('127.0.0.1:11434'))
    """
    test_url = normalize_url(base_url) + '/api/tags'

    try:
        request = urllib.request.Request(test_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            if response.getcode() == 200:
                return test_url
    except (HTTPError, URLError, socket.timeout, ValueError):
        return None
    except Exception:
        return None
    return None


def extract_ips_from_json_dir(json_dir: Path) -> List[str]:
    """Read local model JSON files and extract unique ip_port values."""
    urls: set[str] = set()

    for path in json_dir.rglob('*.json'):
        try:
            with path.open('r', encoding='utf-8') as f:
                payload = json.load(f)
        except Exception:
            continue

        models = payload.get('props', {}).get('pageProps', {}).get('models', [])
        for model in models:
            ip_port = model.get('ip_port')
            if ip_port:
                urls.add(ip_port)

    return sorted(urls)


def find_valid_endpoints(
    json_dir: Path,
    max_workers: int = 20,
    timeout: int = 5,
) -> List[str]:
    """Return all valid Ollama endpoints found in the JSON directory.

    Args:
        json_dir: Directory containing model JSON files.
        max_workers: Number of concurrent checks.
        timeout: Request timeout in seconds.

    Example:
        >>> from pathlib import Path
        >>> from aicortex.tools.check_models import find_valid_endpoints
        >>> valid = find_valid_endpoints(Path('aicortex/models'))
        >>> print(valid)
    """
    json_dir = Path(json_dir)
    ips = extract_ips_from_json_dir(json_dir)
    if not ips:
        return []

    valid_endpoints: List[str] = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        for result in executor.map(lambda url: check_url(url, timeout=timeout), ips):
            if result:
                valid_endpoints.append(result)

    return valid_endpoints


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description='Validate Ollama endpoint URLs from JSON metadata.')
    parser.add_argument('json_dir', type=Path, help='Directory containing Ollama JSON files.')
    parser.add_argument('--output', type=Path, default=Path('valid_models.txt'), help='Path to save valid endpoints.')
    parser.add_argument('--timeout', type=int, default=5, help='Request timeout in seconds.')
    args = parser.parse_args()

    valid = find_valid_endpoints(args.json_dir, timeout=args.timeout)
    args.output.write_text('\n'.join(valid), encoding='utf-8')
    print(f'Saved {len(valid)} valid endpoints to {args.output}')


if __name__ == '__main__':
    main()
