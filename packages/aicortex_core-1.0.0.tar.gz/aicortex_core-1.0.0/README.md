# AICortex

**An LLM API toolkit for accessing any language model through Ollama.** AICortex provides a clean, powerful interface to Gemma, Mistral, Deepseek, Qwen, Llama, and any other model served through Ollama - without any signup, API keys, or fees.

## Why AICortex?

- **100% Free** - No API keys, no signup, no subscriptions, no rate limits, no payment required
- **Any Model** - Access Gemma, Mistral, Deepseek, Qwen, Llama, and dozens more
- **Any Server** - Works with local Ollama, remote servers, or community-hosted endpoints
- **Unified Interface** - Single Python API for any Ollama-compatible model
- **Production Ready** - Type-safe, fully tested, comprehensive error handling
- **Easy to Use** - Simple Python API, OpenAI-compatible REST endpoints

## Features

- **Simple Chat API**: Unified interface for synchronous and streaming chat with Ollama models
- **Model Discovery**: Automatic model family detection and server validation
- **OpenAI-Compatible Server**: Run a FastAPI server that mimics OpenAI's chat completions API
- **Utility Tools**: Scripts for validating endpoints, fetching models, and managing model metadata
- **Type Safety**: Full type annotations and stub files for IDE support

## Installation

```bash
pip install aicortex-core
```

### Optional Dependencies

For the OpenAI-compatible server:

```bash
pip install aicortex-core[server]
```

This installs `fastapi`, `uvicorn`, and `pydantic`.

## Quick Start

```python
from aicortex import chat

# Simple chat
response = chat("What is quantum computing?")
print(response)

# Streaming chat
for event in chat("Tell me a story", stream=True):
    print(event.content, end="", flush=True)
```

## Usage

### Basic Chat

```python
from aicortex import chat

response = chat(
    prompt="Explain machine learning",
    model="llama3.2:3b",
    temperature=0.7,
    max_tokens=500
)
```

### Streaming Responses

```python
from aicortex import chat

stream = chat(
    prompt="Write a poem about AI",
    model="mistral:7b",
    stream=True
)

for event in stream:
    print(event.content, end="")
```

### Model Management

```python
from aicortex import families, models, get_model_info

# List all families
print(families())

# List models in a family
print(models("llama"))

# Get detailed model info
info = get_model_info("llama3.2:3b")
print(info)
```

### Server Mode

Run an OpenAI-compatible API server:

```python
from aicortex.tools import run_server

run_server(host="0.0.0.0", port=8000, default_model="gpt-oss:20b")
```

Then use it like OpenAI's API:

```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-oss:20b",
    "messages": [{"role": "user", "content": "Hello!"}],
    "stream": true
  }'
```

### Tools

AICortex includes utility tools for model management:

```python
from aicortex.tools import find_valid_endpoints, fetch_models, resolve_models

# Validate Ollama endpoints
valid_urls = find_valid_endpoints(Path("aicortex/models"))

# Fetch models from endpoints
fetch_models(Path("valid_models.txt"), Path("fetched_models.json"))

# Resolve into package format
resolve_models(Path("fetched_models.json"), Path("aicortex/models"), Path("resolved.json"))
```

## Configuration

Models are configured via JSON files in the `aicortex/models/` directory. Each file represents a model family (e.g., `llama.json`, `mistral.json`).

Model files contain server URLs and metadata for available models.

## API Reference

### Core Functions

- `chat(prompt, *, model="gpt-oss:20b", stream=False, temperature=0.7, max_tokens=None, top_p=1.0, stop=None)`: Main chat function
- `families()`: List available model families
- `models(family=None)`: List models, optionally filtered by family
- `get_model_info(model)`: Get detailed metadata for a model
- `list_model_servers(model)`: Get servers hosting a specific model
- `get_server_info(model, server_url=None)`: Get server information

### Tools

- `find_valid_endpoints(json_dir, max_workers=20, timeout=5)`: Validate Ollama endpoints
- `fetch_models(url_file, output_file, max_workers=10, timeout=10)`: Fetch models from validated URLs
- `resolve_models(fetched_file, json_dir, output_file)`: Resolve fetched data into package format
- `apply_valid_models(resolved_file, json_dir, backup=False)`: Apply resolved models to JSON files
- `run_server(host="127.0.0.1", port=8000, default_model="gpt-oss:20b", reload=True)`: Start API server

### Classes

- `Stream`: Container for streaming events
- `StreamEvent`: Individual streaming event with type, content, and metadata

## Development

```bash
git clone https://github.com/eirasmx/aicortex.git
cd aicortex
pip install -e .
```

## License

MIT License - see LICENSE file for details.

## Contributing

Contributions welcome! Please see the docs for development guidelines.