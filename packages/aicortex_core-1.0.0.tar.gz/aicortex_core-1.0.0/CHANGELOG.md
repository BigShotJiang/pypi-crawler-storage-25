# Changelog

All notable changes to AICortex will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-05-02

### Initial Release

AICortex v1.0.0 is a comprehensive LLM API toolkit for unified access to any model through Ollama servers. **Completely free, zero signup, zero API keys.**

### Core Features
- **Unified Chat API** - Single Python interface for Gemma, Mistral, Deepseek, Qwen, Llama, and any Ollama-compatible model
- **Any Server** - Works with local Ollama, remote servers, or community-hosted endpoints
- **Full Streaming Support** - Real-time token streaming for responsive, memory-efficient applications
- **Multi-Model Access** - Pre-configured model families: llama, mistral, qwen, deepseek, gemma
- **Server Orchestration** - Automatic discovery, health checks, and load balancing
- **OpenAI-Compatible API** - Drop-in replacement for OpenAI endpoints, works with existing client libraries
- **Production-Grade Tools** - Server validation, concurrent model management, metadata handling
- **Type Safety** - Complete type hints, IDE autocomplete, mypy strict mode
- **Zero Cost, No Auth** - No API keys, no signup, no subscriptions, no rate limits

### What's Included
- Unified `chat()` function for any model with sync/streaming modes
- Access to Gemma, Mistral, Deepseek, Qwen, Llama, and more
- Automatic Ollama server discovery and load balancing
- FastAPI-based OpenAI-compatible REST API server
- Tools for server validation and model orchestration
- Complete type annotations and IDE support
- Comprehensive documentation and real-world examples

### Architecture
- **Clean Public API** - Intuitive wrapper functions with internal OllamaAPI layer
- **Modular Design** - Separated concerns for chat, models, tools, and server functionality
- **Type-Safe** - Full type annotations throughout, enabling IDE autocomplete and runtime validation

### Technical Specifications
- **Python 3.8+** - Compatible with modern Python versions
- **Type Safety** - Full mypy validation with strict mode enabled
- **Streaming Architecture** - Event-based streaming for memory-efficient processing
- **Extensible Tools** - Modular tool system for model administration and management
- **Error Resilience** - Comprehensive error handling with graceful degradation
- **Performance** - Concurrent operations, intelligent caching, and optimized model loading

---

## Pre-Release Development

*No previous releases. This is the initial production release.*

---

## Types of changes
- `Added` for new features
- `Changed` for changes in existing functionality
- `Deprecated` for soon-to-be removed features
- `Removed` for now removed features
- `Fixed` for any bug fixes
- `Security` in case of vulnerabilities