from setuptools import setup, find_packages

setup(
    name="shiroko-netai",
    version="2.0.2",
    author="shiroko",
    author_email="3207774253@qq.com",
    description="终端 AI 聊天工具，支持 OpenAI 及兼容 API",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/shiroko973/shiroko-netai",
    packages=["shiroko_netai"],
    install_requires=[
        "requests>=2.31.0"
    ],
    entry_points={
        "console_scripts": [
            "shiroko-netai = shiroko_netai.core:init_start"
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    license="MIT"
)