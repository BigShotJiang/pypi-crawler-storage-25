"""
shiroko-netai - 终端 AI 聊天工具
"""

from .core import TCC, init_start, quick_chat, send_message

__version__ = "2.0.2"
__all__ = ["TCC", "init_start", "quick_chat", "send_message"]