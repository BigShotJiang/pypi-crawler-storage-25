#!/usr/bin/env python3

import requests
import time
import sys
import argparse
import json


try:
    from text_discoloration import (
        typewriter as tw_typewriter,
        success, info, error, warn
    )
    HAS_DISCOLORATION = True
except ImportError:
    HAS_DISCOLORATION = False
    def tw_typewriter(text, delay=0.05):
        for ch in text:
            sys.stdout.write(ch)
            sys.stdout.flush()
            time.sleep(delay)
        print()
    def success(text):
        print(f"[SUCCESS] {text}")
    def info(text):
        print(f"[INFO] {text}")
    def error(text):
        print(f"[ERROR] {text}")
    def warn(text):
        print(f"[WARNING] {text}")


base_url = ""
api_key = ""
model_name = ""
req_method = "POST"


def stream_print(text, speed=0.02):

    if HAS_DISCOLORATION:
        tw_typewriter(text, delay=speed)
    else:
        for ch in text:
            sys.stdout.write(ch)
            sys.stdout.flush()
            time.sleep(speed)
        print()

def send_message(msg):

    global base_url, api_key, model_name, req_method
    
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    
    data = {
        "model": model_name,
        "messages": [{"role": "user", "content": msg}],
        "stream": False
    }
    
    try:
        if req_method.upper() == "POST":
            res = requests.post(base_url, headers=headers, json=data, timeout=60)
        else:
            res = requests.get(base_url, headers=headers, params=data, timeout=60)
        
        res.raise_for_status()
        res_json = res.json()
        
        if "choices" in res_json:
            return res_json["choices"][0]["message"]["content"]
        elif "response" in res_json:
            return res_json["response"]
        else:
            return str(res_json)
            
    except requests.exceptions.Timeout:
        return "请求超时 / Request timeout"
    except requests.exceptions.ConnectionError:
        return "连接失败 / Connection failed"
    except Exception as e:
        return f"错误 / Error: {str(e)}"


def interactive_setup():
    """交互式配置"""
    global base_url, api_key, model_name, req_method
    
    info("shiroko-netai 配置")
    
    print("\n请求方式 / Request Method:")
    print("1. POST (推荐)")
    print("2. GET")
    while True:
        choice = input("请选择 (1/2): ").strip()
        if choice == "1":
            req_method = "POST"
            break
        elif choice == "2":
            req_method = "GET"
            break
        error("请输入 1 或 2")
    
    base_url = input("\nAPI 地址 / API URL: ").strip()
    while not base_url:
        error("地址不能为空")
        base_url = input("API 地址: ").strip()
    
    api_key = input("API Key (可选): ").strip()
    
    model_name = input("模型名称 (如 gpt-3.5-turbo): ").strip()
    while not model_name:
        error("模型名称不能为空")
        model_name = input("模型名称: ").strip()
    
    success("配置完成！")

def start_chat():
    success("shiroko-netai 已启动")
    info("输入 'exit' 退出 / 'reset' 重新配置")
    
    while True:
        user_input = input(f"\nYou: ")
        
        if user_input.lower() == "exit":
            info("再见！")
            break
        elif user_input.lower() == "reset":
            return False
        
        print("AI: ", end="")
        response = send_message(user_input)
        stream_print(response)
    
    return True


def init_start():
    parser = argparse.ArgumentParser(description="shiroko-netai - 终端 AI 聊天工具")
    parser.add_argument("--url", help="API URL")
    parser.add_argument("--key", help="API Key")
    parser.add_argument("--model", help="Model name")
    parser.add_argument("--method", choices=["POST", "GET"], default="POST")
    parser.add_argument("--send", "-s", help="发送单条消息后退出")
    
    args = parser.parse_args()
    
    global base_url, api_key, model_name, req_method

    if args.send:
        if not args.url or not args.model:
            error("--url 和 --model 是必需的")
            sys.exit(1)
        base_url = args.url
        api_key = args.key or ""
        model_name = args.model
        req_method = args.method
        response = send_message(args.send)
        print(response)
        return

    if args.url and args.model:
        base_url = args.url
        api_key = args.key or ""
        model_name = args.model
        req_method = args.method
        info("使用命令行提供的配置")
    else:
        interactive_setup()
    
    while not start_chat():
        interactive_setup()

def quick_chat(url, model, api_key="", method="POST"):

    global base_url, api_key, model_name, req_method
    base_url = url
    api_key = api_key
    model_name = model
    req_method = method
    start_chat()

class TCC:
    def __init__(self, url, model, api_key="", method="POST"):
        self.url = url
        self.api_key = api_key
        self.model = model
        self.method = method
    
    def send(self, message):
        global base_url, api_key, model_name, req_method
        old_url, old_key, old_model, old_method = base_url, api_key, model_name, req_method
        base_url, api_key, model_name, req_method = self.url, self.api_key, self.model, self.method
        response = send_message(message)
        base_url, api_key, model_name, req_method = old_url, old_key, old_model, old_method
        return response
    
    def chat(self):
        global base_url, api_key, model_name, req_method
        base_url, api_key, model_name, req_method = self.url, self.api_key, self.model, self.method
        start_chat()


if __name__ == "__main__":
    init_start()