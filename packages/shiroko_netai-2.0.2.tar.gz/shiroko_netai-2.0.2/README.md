# shiroko-netai

终端 AI 聊天工具，支持 OpenAI 及兼容 API。

## 安装

```bash
pip install shiroko-netai