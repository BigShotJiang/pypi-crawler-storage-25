"""Tests for Index-TTS adapter."""

from __future__ import annotations

from modern_tts.core.config import ModelConfig
from modern_tts.models.index_tts import IndexTTS


def test_model_id() -> None:
    model = IndexTTS(config=ModelConfig(model_id="index-tts"))
    assert model.model_id == "index-tts"
