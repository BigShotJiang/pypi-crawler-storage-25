"""Tests for CLI."""

from __future__ import annotations

from modern_tts.cli import main


def test_cli_list_json(capsys) -> None:
    ret = main(["list", "--json"])
    assert ret == 0
    captured = capsys.readouterr()
    assert "melotts-zh" in captured.out


def test_cli_list_table(capsys) -> None:
    ret = main(["list"])
    assert ret == 0
    captured = capsys.readouterr()
    assert "Registered TTS Models" in captured.out


def test_cli_no_command(capsys) -> None:
    ret = main([])
    assert ret == 1
    captured = capsys.readouterr()
    assert "usage:" in captured.out
