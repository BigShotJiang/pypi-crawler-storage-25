"""Tests for CosyVoice adapter."""

from __future__ import annotations

import numpy as np
import pytest

from modern_tts.core.config import ModelConfig
from modern_tts.core.types import AudioOutput, TextInput
from modern_tts.models.cosyvoice import CosyVoice300M, CosyVoice300MSFT


def test_load() -> None:
    model = CosyVoice300M(config=ModelConfig(model_id="cosyvoice-300m"))
    try:
        model.load()
    except (ImportError, RuntimeError, AssertionError, OSError):
        pass


def test_clone() -> None:
    model = CosyVoice300M(config=ModelConfig(model_id="cosyvoice-300m"))
    ref = AudioOutput(waveform=np.zeros(22050, dtype=np.float32), sample_rate=22050)
    with pytest.raises((ImportError, RuntimeError, AssertionError)):
        model.clone(TextInput(data="克隆"), reference_audio=ref)


def test_model_id() -> None:
    model = CosyVoice300M(config=ModelConfig(model_id="cosyvoice-300m"))
    assert model.model_id == "cosyvoice-300m"


def test_sft_model_id() -> None:
    model = CosyVoice300MSFT(config=ModelConfig(model_id="cosyvoice-300m-sft"))
    assert model.model_id == "cosyvoice-300m-sft"


def test_supported_languages() -> None:
    assert "zh" in CosyVoice300M.SUPPORTED_LANGUAGES
    assert "en" in CosyVoice300M.SUPPORTED_LANGUAGES
    assert "ja" in CosyVoice300M.SUPPORTED_LANGUAGES


def test_supported_modes() -> None:
    assert "clone" in CosyVoice300M.SUPPORTED_MODES
