"""Tests for ChatTTS adapter."""

from __future__ import annotations

import numpy as np

from modern_tts.core.config import ModelConfig
from modern_tts.core.types import AudioOutput, TextInput
from modern_tts.models.chattts import ChatTTS


def test_load() -> None:
    model = ChatTTS(config=ModelConfig(model_id="chattts"))
    model.load()
    assert model.is_loaded
    model.unload()


def test_synthesize() -> None:
    model = ChatTTS(config=ModelConfig(model_id="chattts"))
    model.load()
    result = model.synthesize(TextInput(data="你好"))
    assert result.text == "你好"
    assert result.audio is not None
    model.unload()


def test_clone() -> None:
    model = ChatTTS(config=ModelConfig(model_id="chattts"))
    model.load()
    ref = AudioOutput(waveform=np.zeros(24000, dtype=np.float32), sample_rate=24000)
    result = model.clone(TextInput(data="克隆测试"), reference_audio=ref)
    assert result.text == "克隆测试"
    model.unload()


def test_emotion() -> None:
    model = ChatTTS(config=ModelConfig(model_id="chattts"))
    model.load()
    result = model.speak_with_emotion(TextInput(data="开心"), emotion="happy")
    assert result.text == "开心"
    model.unload()
