"""Tests for model registry."""

from __future__ import annotations

import pytest

from modern_tts.core.config import ModelConfig
from modern_tts.core.registry import (
    create_model,
    get_model_class,
    list_models,
)


def test_list_models_returns_entries() -> None:
    models = list_models()
    assert isinstance(models, list)
    assert len(models) > 0
    # Check melotts is registered
    ids = [m["model_id"] for m in models]
    assert "melotts-zh" in ids


def test_get_model_class_existing() -> None:
    cls = get_model_class("melotts-zh")
    assert cls.__name__ == "MeloTTSZH"


def test_get_model_class_missing() -> None:
    with pytest.raises(KeyError):
        get_model_class("nonexistent-model")


def test_create_model_without_load() -> None:
    model = create_model("melotts-zh", config=ModelConfig(model_id="melotts-zh"))
    assert model.model_id == "melotts-zh"
    assert not model.is_loaded
