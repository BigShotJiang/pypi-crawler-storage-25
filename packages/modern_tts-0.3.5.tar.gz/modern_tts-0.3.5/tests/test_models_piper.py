"""Tests for Piper-TTS adapter."""

from __future__ import annotations

from modern_tts.core.config import ModelConfig
from modern_tts.core.types import TextInput
from modern_tts.models import piper_tts as piper_mod


def test_load(monkeypatch) -> None:
    monkeypatch.setattr(piper_mod, "_check_deps", lambda: None)
    from modern_tts.models.piper_tts import PiperTTS
    model = PiperTTS(config=ModelConfig(model_id="piper-tts"))
    model.load()
    assert model.is_loaded
    model.unload()


def test_synthesize(monkeypatch) -> None:
    monkeypatch.setattr(piper_mod, "_check_deps", lambda: None)
    from modern_tts.models.piper_tts import PiperTTS
    model = PiperTTS(config=ModelConfig(model_id="piper-tts"))
    model.load()
    result = model.synthesize(TextInput(data="Hello world"))
    assert result.text == "Hello world"
    assert result.audio is not None
    model.unload()
