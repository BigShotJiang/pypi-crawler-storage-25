"""Tests for GLM-TTS adapter."""

from __future__ import annotations

from modern_tts.core.config import ModelConfig
from modern_tts.models.glm_tts import GLMTTS


def test_glm_tts_model_id() -> None:
    model = GLMTTS(config=ModelConfig(model_id="glm-tts"))
    assert model.model_id == "glm-tts"
