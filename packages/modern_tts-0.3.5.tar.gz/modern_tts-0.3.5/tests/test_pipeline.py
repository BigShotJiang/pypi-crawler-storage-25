"""Tests for TTSPipeline."""

from __future__ import annotations

import numpy as np

from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.pipeline import TTSPipeline
from modern_tts.core.types import TextInput


def test_init_with_model_id() -> None:
    pipe = TTSPipeline("piper-tts")
    assert pipe.model is not None
    assert pipe.model.model_id == "piper-tts"
    pipe.unload()


def test_init_without_model_id() -> None:
    pipe = TTSPipeline()
    assert pipe.model is None


def test_context_manager() -> None:
    with TTSPipeline("piper-tts") as pipe:
        assert pipe.model is not None
        assert pipe.model.is_loaded
    assert not pipe.model.is_loaded


def test_switch_model() -> None:
    pipe = TTSPipeline("piper-tts")
    assert pipe.model.model_id == "piper-tts"

    pipe.switch_model("chattts")
    assert pipe.model.model_id == "chattts"
    pipe.unload()


def test_synthesize_string() -> None:
    pipe = TTSPipeline("piper-tts")
    result = pipe("Hello world")
    assert result.text == "Hello world"
    assert result.audio is not None
    assert len(result.audio.waveform) > 0
    assert result.model_id == "piper-tts"
    pipe.unload()


def test_synthesize_textinput() -> None:
    pipe = TTSPipeline("piper-tts")
    text_input = TextInput(data="Hello world", language="en")
    result = pipe(text_input)
    assert result.text == "Hello world"
    pipe.unload()


def test_clone_task() -> None:
    pipe = TTSPipeline("chattts")
    # Use dummy reference audio
    from modern_tts.core.types import AudioOutput
    ref = AudioOutput(waveform=np.zeros(24000, dtype=np.float32), sample_rate=24000)
    result = pipe("测试克隆", task="clone", reference_audio=ref)
    assert result.text == "测试克隆"
    pipe.unload()


def test_unload_releases_model() -> None:
    pipe = TTSPipeline("piper-tts")
    pipe.unload()
    assert pipe.model is not None
    assert not pipe.model.is_loaded
