"""Tests for RedFire-TTS adapter."""

from __future__ import annotations

import numpy as np
import pytest

from modern_tts.core.config import ModelConfig
from modern_tts.core.types import AudioOutput, TextInput
from modern_tts.models.redfire_tts import RedFireTTS


def test_load() -> None:
    model = RedFireTTS(config=ModelConfig(model_id="redfire-tts"))
    try:
        model.load()
    except (ImportError, RuntimeError, AssertionError, OSError):
        pass


def test_synthesize() -> None:
    model = RedFireTTS(config=ModelConfig(model_id="redfire-tts"))
    with pytest.raises(RuntimeError):
        model.synthesize(TextInput(data="你好"))


def test_clone() -> None:
    model = RedFireTTS(config=ModelConfig(model_id="redfire-tts"))
    ref = AudioOutput(waveform=np.zeros(24000, dtype=np.float32), sample_rate=24000)
    with pytest.raises((ImportError, RuntimeError, AssertionError)):
        model.clone(TextInput(data="克隆测试"), reference_audio=ref)


def test_model_id() -> None:
    model = RedFireTTS(config=ModelConfig(model_id="redfire-tts"))
    assert model.model_id == "redfire-tts"


def test_supported_languages() -> None:
    assert "zh" in RedFireTTS.SUPPORTED_LANGUAGES
    assert "en" in RedFireTTS.SUPPORTED_LANGUAGES


def test_supported_modes() -> None:
    assert "clone" in RedFireTTS.SUPPORTED_MODES
