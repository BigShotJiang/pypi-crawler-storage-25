"""Tests for XTTS series adapters."""

from __future__ import annotations

import numpy as np
import pytest

from modern_tts.core.config import ModelConfig
from modern_tts.core.types import AudioOutput, TextInput
from modern_tts.models.xtts import XTTSv1, XTTSv2, XTTSv21


def test_xtts_v1_model_id() -> None:
    model = XTTSv1(config=ModelConfig(model_id="xtts-v1"))
    assert model.model_id == "xtts-v1"


def test_xtts_v2_model_id() -> None:
    model = XTTSv2(config=ModelConfig(model_id="xtts-v2"))
    assert model.model_id == "xtts-v2"


def test_xtts_v21_model_id() -> None:
    model = XTTSv21(config=ModelConfig(model_id="xtts-v2.1"))
    assert model.model_id == "xtts-v2.1"


def test_xtts_v2_synthesize() -> None:
    model = XTTSv2(config=ModelConfig(model_id="xtts-v2"))
    with pytest.raises((ImportError, RuntimeError)):
        model.synthesize(TextInput(data="Hello world"))


def test_xtts_v2_clone() -> None:
    model = XTTSv2(config=ModelConfig(model_id="xtts-v2"))
    ref = AudioOutput(waveform=np.zeros(24000, dtype=np.float32), sample_rate=24000)
    with pytest.raises((ImportError, RuntimeError)):
        model.clone(TextInput(data="克隆测试"), reference_audio=ref)


def test_xtts_v21_stream() -> None:
    model = XTTSv21(config=ModelConfig(model_id="xtts-v2.1"))
    with pytest.raises((ImportError, RuntimeError)):
        model.stream(TextInput(data="Streaming test"))


def test_supported_languages() -> None:
    assert "zh" in XTTSv2.SUPPORTED_LANGUAGES
    assert "en" in XTTSv2.SUPPORTED_LANGUAGES


def test_supported_modes() -> None:
    assert "clone" in XTTSv2.SUPPORTED_MODES
    assert "streaming" in XTTSv21.SUPPORTED_MODES
