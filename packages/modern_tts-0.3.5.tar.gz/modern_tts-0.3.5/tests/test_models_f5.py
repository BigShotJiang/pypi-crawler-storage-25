"""Tests for F5-TTS adapter."""

from __future__ import annotations

import numpy as np
import pytest

from modern_tts.core.config import ModelConfig
from modern_tts.core.types import AudioOutput, TextInput
from modern_tts.models.f5_tts import F5TTS


def test_load() -> None:
    model = F5TTS(config=ModelConfig(model_id="f5-tts"))
    try:
        model.load()
    except (ImportError, RuntimeError, OSError):
        pass


def test_synthesize() -> None:
    model = F5TTS(config=ModelConfig(model_id="f5-tts"))
    with pytest.raises((ImportError, RuntimeError)):
        model.synthesize(TextInput(data="你好"))


def test_clone() -> None:
    model = F5TTS(config=ModelConfig(model_id="f5-tts"))
    ref = AudioOutput(waveform=np.zeros(24000, dtype=np.float32), sample_rate=24000)
    with pytest.raises((ImportError, RuntimeError)):
        model.clone(TextInput(data="克隆"), reference_audio=ref)


def test_model_id() -> None:
    model = F5TTS(config=ModelConfig(model_id="f5-tts"))
    assert model.model_id == "f5-tts"


def test_supported_languages() -> None:
    assert "zh" in F5TTS.SUPPORTED_LANGUAGES
    assert "en" in F5TTS.SUPPORTED_LANGUAGES
