"""Tests for BERT-VITS2 adapter."""

from __future__ import annotations

import pytest

from modern_tts.core.config import ModelConfig
from modern_tts.core.types import TextInput
from modern_tts.models.bertvits2 import BertVITS2EN, BertVITS2JP, BertVITS2ZH


def test_bertvits2_jp() -> None:
    model = BertVITS2JP(config=ModelConfig(model_id="bertvits2-jp"))
    with pytest.raises(RuntimeError):
        model.load()


def test_bertvits2_zh() -> None:
    model = BertVITS2ZH(config=ModelConfig(model_id="bertvits2-zh"))
    with pytest.raises(RuntimeError):
        model.load()


def test_bertvits2_en() -> None:
    model = BertVITS2EN(config=ModelConfig(model_id="bertvits2-en"))
    with pytest.raises(RuntimeError):
        model.load()


def test_emotion() -> None:
    model = BertVITS2ZH(config=ModelConfig(model_id="bertvits2-zh"))
    with pytest.raises(RuntimeError):
        model.speak_with_emotion(TextInput(data="开心"), emotion="happy")
