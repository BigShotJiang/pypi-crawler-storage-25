"""Tests for Parler-TTS adapter."""

from __future__ import annotations

from modern_tts.core.config import ModelConfig
from modern_tts.models.parler_tts import ParlerTTSMini


def test_model_id() -> None:
    model = ParlerTTSMini(config=ModelConfig(model_id="parler-tts-mini"))
    assert model.model_id == "parler-tts-mini"
