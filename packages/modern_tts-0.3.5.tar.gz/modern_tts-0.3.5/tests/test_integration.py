"""Integration tests for Modern TTS."""

from __future__ import annotations

from modern_tts.core.registry import list_models
from modern_tts import TTSPipeline


def test_all_models_registered() -> None:
    models = list_models()
    ids = {m["model_id"] for m in models}
    expected = {
        "melotts-zh", "melotts-en",
        "chattts",
        "parler-tts-mini", "parler-tts-large",
        "cosyvoice-300m", "cosyvoice-300m-sft", "cosyvoice-300m-instruct",
        "fishspeech-1.5",
        "xtts-v1", "xtts-v2", "xtts-v2.1",
        "gptsovits",
        "maskgct",
        "qwen3-tts-0.6b", "qwen3-tts-1.7b",
        "redfire-tts",
        "glm-tts",
        "piper-tts",
        "moss-tts",
        "pocket-tts",
        "f5-tts",
        "index-tts",
        "bertvits2-jp", "bertvits2-zh", "bertvits2-en",
    }
    assert expected.issubset(ids), f"Missing: {expected - ids}"


def test_pipeline_roundtrip() -> None:
    pipe = TTSPipeline("piper-tts")
    result = pipe("Hello, this is a test.")
    assert result.text == "Hello, this is a test."
    assert result.audio.duration is not None
    assert result.audio.duration > 0
    pipe.unload()


def test_hot_swap() -> None:
    with TTSPipeline("piper-tts") as pipe:
        r1 = pipe("Hello")
        assert r1.model_id == "piper-tts"

        pipe.switch_model("chattts")
        r2 = pipe("Hello")
        assert r2.model_id == "chattts"
