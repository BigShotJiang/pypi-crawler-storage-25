"""Tests for TTSModel base class."""

from __future__ import annotations

from modern_tts.core.config import ModelConfig
from modern_tts.core.types import TextInput


def test_unload_releases_model() -> None:
    from modern_tts.models.piper_tts import PiperTTS

    model = PiperTTS(config=ModelConfig(model_id="piper-tts"))
    model.load()
    assert model.is_loaded
    model.unload()
    assert not model.is_loaded


def test_ensure_loaded_auto_loads() -> None:
    from modern_tts.models.piper_tts import PiperTTS

    model = PiperTTS(config=ModelConfig(model_id="piper-tts"))
    assert not model.is_loaded
    model._ensure_loaded()
    assert model.is_loaded
    model.unload()


def test_split_text() -> None:
    from modern_tts.models.piper_tts import PiperTTS

    model = PiperTTS(config=ModelConfig(model_id="piper-tts"))
    long_text = TextInput(data="Hello world. " * 300)
    chunks = model._split_text(long_text, max_chars=100)
    assert len(chunks) > 1
    total = sum(len(c.get_text()) for c in chunks)
    assert total >= len(long_text.get_text()) * 0.9  # approximate
