"""Tests for Pocket-TTS adapter."""

from __future__ import annotations

import pytest

from modern_tts.core.config import ModelConfig
from modern_tts.core.types import TextInput
from modern_tts.models.pocket_tts import PocketTTS


def test_load() -> None:
    model = PocketTTS(config=ModelConfig(model_id="pocket-tts"))
    with pytest.raises(RuntimeError):
        model.load()


def test_synthesize() -> None:
    model = PocketTTS(config=ModelConfig(model_id="pocket-tts"))
    with pytest.raises(RuntimeError):
        model.synthesize(TextInput(data="Hello"))
