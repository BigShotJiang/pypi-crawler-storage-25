"""Tests for Qwen3-TTS adapter."""

from __future__ import annotations

from modern_tts.core.config import ModelConfig
from modern_tts.models.qwen3_tts import Qwen3TTS06B, Qwen3TTS17B


def test_qwen3_tts_06b_model_id() -> None:
    model = Qwen3TTS06B(config=ModelConfig(model_id="qwen3-tts-0.6b"))
    assert model.model_id == "qwen3-tts-0.6b"


def test_qwen3_tts_17b_model_id() -> None:
    model = Qwen3TTS17B(config=ModelConfig(model_id="qwen3-tts-1.7b"))
    assert model.model_id == "qwen3-tts-1.7b"
