"""Tests for MeloTTS adapter."""

from __future__ import annotations

from modern_tts.core.config import ModelConfig
from modern_tts.core.types import TextInput
from modern_tts.models.melotts import MeloTTSZH


def test_load() -> None:
    model = MeloTTSZH(config=ModelConfig(model_id="melotts-zh"))
    model.load()
    assert model.is_loaded
    model.unload()


def test_synthesize() -> None:
    model = MeloTTSZH(config=ModelConfig(model_id="melotts-zh"))
    model.load()
    result = model.synthesize(TextInput(data="Hello world"))
    assert result.text == "Hello world"
    assert result.audio is not None
    assert len(result.audio.waveform) > 0
    model.unload()


def test_model_id() -> None:
    model = MeloTTSZH(config=ModelConfig(model_id="melotts-zh"))
    assert model.model_id == "melotts-zh"
