"""Tests for core types."""

from __future__ import annotations

import numpy as np

from modern_tts.core.types import AudioOutput, Language, SynthesisMode, TextInput, TTSResult


def test_text_input_from_string() -> None:
    t = TextInput(data="Hello world")
    assert t.get_text() == "Hello world"
    assert t.language == "auto"
    assert t.speed == 1.0


def test_audio_output_duration() -> None:
    sr = 24000
    waveform = np.zeros(sr * 2, dtype=np.float32)  # 2 seconds
    audio = AudioOutput(waveform=waveform, sample_rate=sr)
    assert audio.duration == 2.0


def test_tts_result_save(monkeypatch) -> None:
    import tempfile

    waveform = np.zeros(24000, dtype=np.float32)
    audio = AudioOutput(waveform=waveform, sample_rate=24000)
    result = TTSResult(audio=audio, text="test", model_id="melotts-zh")

    calls = []
    def fake_save(audio, path):
        calls.append((audio, path))

    monkeypatch.setattr("modern_tts.utils.audio.save_audio", fake_save)
    result.save("/tmp/test.wav")
    assert len(calls) == 1
