"""Tests for MOSS-TTS adapter."""

from __future__ import annotations

from modern_tts.core.config import ModelConfig
from modern_tts.core.types import TextInput
from modern_tts.models.moss_tts import MossTTS


def test_load() -> None:
    model = MossTTS(config=ModelConfig(model_id="moss-tts"))
    model.load()
    assert model.is_loaded
    model.unload()


def test_synthesize() -> None:
    model = MossTTS(config=ModelConfig(model_id="moss-tts"))
    model.load()
    result = model.synthesize(TextInput(data="Hello world"))
    assert result.text == "Hello world"
    assert result.audio is not None
    assert len(result.audio.waveform) > 0
    model.unload()


def test_emotion() -> None:
    model = MossTTS(config=ModelConfig(model_id="moss-tts"))
    model.load()
    result = model.speak_with_emotion(TextInput(data="Happy day"), emotion="happy")
    assert result.text == "Happy day"
    assert result.audio is not None
    model.unload()
