"""BERT-VITS2 adapter.

Models:
    - bertvits2-jp: Japanese-centric TTS with BERT phoneme guidance
    - bertvits2-zh: Chinese variant
    - bertvits2-en: English variant

References:
    - https://github.com/fishaudio/Bert-VITS2

Note:
    Bert-VITS2 is a BERT-guided VITS model for high-quality TTS.
    The project is no longer actively maintained (fish-speech is the
    recommended successor). It requires user-trained model weights
    for specific voices.

Requirements (auto-installed on first use):
    - Official Bert-VITS2 repository (auto-cloned)
    - Python dependencies (auto-installed)
    - User-trained VITS model weights + BERT models (manual)
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import numpy as np

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


class _BertVITS2Base(TTSModel):
    """Shared base for BERT-VITS2 variants."""

    MODEL_CARD = "https://github.com/fishaudio/Bert-VITS2"
    SUPPORTED_MODES = {"speak", "emotion"}
    REQUIREMENTS = ["torch", "torchaudio"]
    DEFAULT_SAMPLE_RATE = 44100

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)
        self._repo_path: Path | None = None

    def _check_deps(self) -> None:
        """Auto-clone Bert-VITS2 repo and install dependencies."""
        import sys

        repo_path = (
            self.config.extra.get("bertvits2_repo_path")
            or os.environ.get("BERTVITS2_REPO_PATH")
        )
        if repo_path:
            p = str(Path(repo_path).resolve())
            if p not in sys.path:
                sys.path.insert(0, p)
            self._repo_path = Path(repo_path).resolve()
            return

        from modern_tts.core.repo_manager import ensure_repo, inject_repo_path

        repo_root = ensure_repo(
            "https://github.com/fishaudio/Bert-VITS2.git",
            repo_name="Bert-VITS2",
        )
        inject_repo_path(repo_root)
        self._repo_path = repo_root

        from modern_tts.utils.auto_install import ensure_packages

        ensure_packages(["torch", "torchaudio"])
        ensure_packages([
            "soundfile", "librosa", "numba",
            "transformers", "pypinyin", "jieba",
            "cn2an", "pyopenjtalk",
        ], skip_on_failure=True)

    def load(self) -> None:
        self._check_deps()

        model_path = self.config.extra.get("model_path") or self.config.model_path
        config_path = self.config.extra.get("config_path")

        if not model_path or not os.path.exists(str(model_path)):
            raise RuntimeError(
                f"{self.model_id} requires user-trained model weights. "
                "Set 'model_path' and 'config_path' in ModelConfig.extra:\n"
                "  config = ModelConfig(\n"
                f"      model_id='{self.model_id}',\n"
                "      extra={\n"
                "          'model_path': '/path/to/your/G_xxx.pth',\n"
                "          'config_path': '/path/to/your/config.json',\n"
                "      }\n"
                "  )\n"
                "Train your model using the Bert-VITS2 WebUI first.\n"
                "Note: Bert-VITS2 is no longer maintained. Consider using "
                "Fish Speech or CosyVoice instead."
            )

        from infer import get_net_g, infer  # type: ignore[import-not-found]
        import utils as bv2_utils  # type: ignore[import-not-found]

        self._hps = bv2_utils.get_hparams_from_file(str(config_path))
        device = self._resolve_device()
        self._net_g = get_net_g(
            model_path=str(model_path),
            device=device,
            hps=self._hps,
        )
        self._infer_fn = infer
        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()

        gen_text = text.get_text()
        lang = self._default_language()
        emotion = kwargs.pop("emotion", text.emotion or "neutral")
        sdp_ratio = kwargs.pop("sdp_ratio", 0.5)
        noise_scale = kwargs.pop("noise_scale", 0.6)
        noise_scale_w = kwargs.pop("noise_scale_w", 0.8)
        length_scale = kwargs.pop("length_scale", 1.0)

        import torch

        with torch.no_grad():
            audio = self._infer_fn(
                text=gen_text,
                sdp_ratio=sdp_ratio,
                noise_scale=noise_scale,
                noise_scale_w=noise_scale_w,
                length_scale=length_scale,
                language=lang,
                hps=self._hps,
                net_g=self._net_g,
            )

        if not isinstance(audio, np.ndarray):
            audio = audio.cpu().numpy()
        waveform = audio.squeeze().astype(np.float32)

        return TTSResult(
            audio=AudioOutput(
                waveform=waveform,
                sample_rate=self._hps.data.sampling_rate,
            ),
            text=gen_text,
            language=text.language or lang,
            model_id=self.model_id,
        )

    def speak_with_emotion(
        self,
        text: TextInput,
        emotion: str = "neutral",
        **kwargs: Any,
    ) -> TTSResult:
        text.emotion = emotion
        return self.synthesize(text, **kwargs)

    def _default_language(self) -> str:
        return "auto"

    def unload(self) -> None:
        self._repo_path = None
        self._net_g = None
        self._hps = None
        self._infer_fn = None
        super().unload()


@register_model("bertvits2-jp")
class BertVITS2JP(_BertVITS2Base):
    """BERT-VITS2 Japanese: BERT-guided VITS for high-quality Japanese TTS."""

    SUPPORTED_LANGUAGES = {"ja", "en", "auto", "multi"}

    @property
    def model_id(self) -> str:
        return "bertvits2-jp"

    def _default_language(self) -> str:
        return "ja"


@register_model("bertvits2-zh")
class BertVITS2ZH(_BertVITS2Base):
    """BERT-VITS2 Chinese: BERT-guided VITS for Chinese TTS."""

    SUPPORTED_LANGUAGES = {"zh", "en", "auto", "multi"}

    @property
    def model_id(self) -> str:
        return "bertvits2-zh"

    def _default_language(self) -> str:
        return "zh"


@register_model("bertvits2-en")
class BertVITS2EN(_BertVITS2Base):
    """BERT-VITS2 English: BERT-guided VITS for English TTS."""

    SUPPORTED_LANGUAGES = {"en", "auto", "multi"}

    @property
    def model_id(self) -> str:
        return "bertvits2-en"

    def _default_language(self) -> str:
        return "en"
