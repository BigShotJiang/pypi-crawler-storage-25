"""F5-TTS adapter.

Models:
    - f5-tts: flow matching based high-quality TTS with voice cloning

References:
    - https://github.com/SWivid/F5-TTS
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


def _check_deps() -> None:
    try:
        import torch  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "F5-TTS requires 'torch'. Install with: uv sync --extra f5"
        ) from exc


@register_model("f5-tts")
class F5TTS(TTSModel):
    """F5-TTS: flow matching based high-quality TTS with advanced voice cloning.

    Achieves state-of-the-art voice similarity with only a few seconds of reference audio.
    """

    MODEL_CARD = "https://github.com/SWivid/F5-TTS"
    SUPPORTED_LANGUAGES = {"zh", "en", "ja", "ko", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "clone", "emotion"}
    REQUIREMENTS = ["torch", "torchaudio"]
    DEFAULT_SAMPLE_RATE = 24000

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)
        self._model: Any = None

    @property
    def model_id(self) -> str:
        return "f5-tts"

    def load(self) -> None:
        _check_deps()
        from f5_tts.api import F5TTS as F5TTSModel

        self._model = F5TTSModel(model="F5TTS_v1_Base")
        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        import numpy as np

        gen_text = text.get_text()

        ref_audio = kwargs.get("ref_audio") or kwargs.get("reference_audio")
        ref_text = kwargs.get("ref_text", gen_text)

        if ref_audio is None:
            default_ref = self.config.extra.get("default_reference_audio")
            if default_ref and os.path.exists(str(default_ref)):
                ref_audio = str(default_ref)
            else:
                raise RuntimeError(
                    "F5-TTS requires a reference audio. Use task='clone' with "
                    "reference_audio=..., or set 'default_reference_audio' in "
                    "ModelConfig.extra."
                )

        waveform, sr, _ = self._model.infer(
            ref_file=str(ref_audio),
            ref_text=ref_text,
            gen_text=gen_text,
        )

        # waveform is already a numpy array
        if not isinstance(waveform, np.ndarray):
            waveform = np.array(waveform)

        return TTSResult(
            audio=AudioOutput(
                waveform=waveform,
                sample_rate=sr,
            ),
            text=gen_text,
            language=text.language or "zh",
            model_id=self.model_id,
        )

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        self._ensure_loaded()
        ref_path = self._resolve_audio_path(reference_audio)
        return self.synthesize(text, ref_audio=ref_path, **kwargs)

    def _resolve_audio_path(self, reference_audio: "AudioOutput | str | Path") -> str:
        if isinstance(reference_audio, (str, Path)):
            return str(reference_audio)
        return self._save_temp_audio(reference_audio)
