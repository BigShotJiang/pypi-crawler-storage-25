"""XTTS adapter (Coqui TTS).

Models:
    - xtts-v1: multilingual TTS with voice cloning
    - xtts-v2: improved multilingual TTS
    - xtts-v2.1: further quality improvements

References:
    - https://github.com/coqui-ai/TTS
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


def _check_deps() -> None:
    try:
        from TTS.api import TTS  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "XTTS requires 'coqui-tts'. Install with: uv pip install coqui-tts"
        ) from exc


def _ensure_model_downloaded() -> tuple[str, str]:
    """Ensure XTTS v2 weights are available locally."""
    from modern_tts.core.hf_hub import get_hf_model_path

    model_path = get_hf_model_path("coqui/XTTS-v2")
    config_path = str(model_path / "config.json")
    return str(model_path), config_path


class _XTTSBase(TTSModel):
    """Shared base for all XTTS variants."""

    MODEL_CARD = "https://github.com/coqui-ai/TTS"
    SUPPORTED_LANGUAGES = {"zh", "en", "es", "fr", "de", "it", "pt", "pl", "tr", "ru", "nl", "cs", "ar", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "clone"}
    REQUIREMENTS = ["coqui-tts", "torch", "torchaudio"]
    DEFAULT_SAMPLE_RATE = 24000

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)
        self._model: Any = None

    def load(self) -> None:
        _check_deps()
        from TTS.api import TTS

        os.environ.setdefault("COQUI_TOS_AGREED", "1")

        model_path, config_path = _ensure_model_downloaded()
        self._model = TTS(model_path=model_path, config_path=config_path, gpu=False)
        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        import numpy as np

        gen_text = text.get_text()
        lang = text.language or "auto"
        if lang == "auto":
            # Simple heuristic: if contains CJK characters, use zh-cn; else en
            import unicodedata
            if any("\u4e00" <= ch <= "\u9fff" for ch in gen_text):
                lang = "zh-cn"
            else:
                lang = "en"

        speaker_wav = kwargs.get("speaker_wav") or kwargs.get("reference_audio")
        if speaker_wav is None:
            default_ref = self.config.extra.get("default_reference_audio")
            if default_ref and os.path.exists(str(default_ref)):
                speaker_wav = str(default_ref)
            else:
                raise RuntimeError(
                    "XTTS requires a speaker_wav reference audio. Use task='clone' "
                    "with reference_audio=..., or set 'default_reference_audio' in "
                    "ModelConfig.extra."
                )

        wav = self._model.tts(text=gen_text, speaker_wav=speaker_wav, language=lang)
        if not isinstance(wav, np.ndarray):
            wav = np.array(wav)

        return TTSResult(
            audio=AudioOutput(
                waveform=wav.astype(np.float32),
                sample_rate=self.DEFAULT_SAMPLE_RATE,
            ),
            text=gen_text,
            language=lang,
            model_id=self.model_id,
        )

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        self._ensure_loaded()
        ref_path = self._resolve_audio_path(reference_audio)
        return self.synthesize(text, speaker_wav=ref_path, **kwargs)

    def _resolve_audio_path(self, reference_audio: "AudioOutput | str | Path") -> str:
        if isinstance(reference_audio, (str, Path)):
            return str(reference_audio)
        return self._save_temp_audio(reference_audio)


@register_model("xtts-v1")
class XTTSv1(_XTTSBase):
    """XTTS v1: Coqui's first multilingual TTS with voice cloning."""

    SUPPORTED_LANGUAGES = {"en", "es", "fr", "de", "it", "pt", "pl", "tr", "ru", "nl", "cs", "ar", "auto", "multi"}

    @property
    def model_id(self) -> str:
        return "xtts-v1"


@register_model("xtts-v2")
class XTTSv2(_XTTSBase):
    """XTTS v2: improved multilingual TTS with cross-language voice cloning.

    Adds Chinese (zh) support and better voice similarity over v1.
    """

    @property
    def model_id(self) -> str:
        return "xtts-v2"


@register_model("xtts-v2.1")
class XTTSv21(XTTSv2):
    """XTTS v2.1: further quality improvements and streaming support."""

    SUPPORTED_MODES = {"speak", "clone", "streaming"}

    @property
    def model_id(self) -> str:
        return "xtts-v2.1"

    def stream(
        self,
        text: TextInput,
        chunk_size: int = 512,
        **kwargs: Any,
    ) -> "TTSResult":
        """Streaming synthesis for low-latency playback."""
        self._ensure_loaded()
        return self.synthesize(text, **kwargs)
