"""Qwen3-TTS adapter (Alibaba).

Models:
    - qwen3-tts-0.6b: lightweight multilingual TTS
    - qwen3-tts-1.7b: larger variant

References:
    - https://github.com/QwenLM/Qwen3-TTS
"""

from __future__ import annotations

from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


def _check_deps() -> None:
    try:
        import qwen_tts  # noqa: F401
    except ImportError:
        from modern_tts.utils.auto_install import ensure_packages

        ensure_packages(["qwen-tts"])
        import qwen_tts  # noqa: F401


class _Qwen3TTSBase(TTSModel):
    """Shared base for Qwen3-TTS variants."""

    MODEL_CARD = "https://github.com/QwenLM/Qwen3-TTS"
    SUPPORTED_LANGUAGES = {
        "zh", "en", "ja", "ko", "de", "fr", "it", "pt", "es", "ru", "auto", "multi"
    }
    SUPPORTED_MODES = {"speak", "clone"}
    REQUIREMENTS = ["torch", "transformers", "qwen-tts"]
    DEFAULT_SAMPLE_RATE = 24000
    SPEAKER: str = "serena"

    _MODEL_PATH: str = ""

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)

    def load(self) -> None:
        _check_deps()
        from qwen_tts import Qwen3TTSModel

        model_path = self.config.model_path or self._MODEL_PATH
        self._model = Qwen3TTSModel.from_pretrained(str(model_path))
        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        speaker = kwargs.get("speaker", text.speaker_id or self.SPEAKER)
        language = kwargs.get("language", text.language or "auto")

        audios, sr = self._model.generate_custom_voice(
            text.get_text(),
            speaker=speaker,
            language=language,
            non_streaming_mode=True,
        )
        waveform = audios[0].astype("float32")

        return TTSResult(
            audio=AudioOutput(
                waveform=waveform,
                sample_rate=sr,
            ),
            text=text.get_text(),
            language=language,
            speaker_id=speaker,
            model_id=self.model_id,
        )

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        self._ensure_loaded()
        ref_path = reference_audio
        if hasattr(reference_audio, "waveform"):
            import tempfile
            import soundfile as sf
            fd, ref_path = tempfile.mkstemp(suffix=".wav")
            sf.write(ref_path, reference_audio.waveform, reference_audio.sample_rate)

        language = kwargs.get("language", text.language or "auto")
        audios, sr = self._model.generate_voice_clone(
            text.get_text(),
            language=language,
            ref_audio=str(ref_path),
            non_streaming_mode=True,
        )
        waveform = audios[0].astype("float32")

        return TTSResult(
            audio=AudioOutput(waveform=waveform, sample_rate=sr),
            text=text.get_text(),
            language=language,
            model_id=self.model_id,
        )


@register_model("qwen3-tts-0.6b")
class Qwen3TTS06B(_Qwen3TTSBase):
    """Qwen3-TTS 0.6B: lightweight multilingual TTS from Alibaba."""

    _MODEL_PATH = "Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice"

    @property
    def model_id(self) -> str:
        return "qwen3-tts-0.6b"


@register_model("qwen3-tts-1.7b")
class Qwen3TTS17B(_Qwen3TTSBase):
    """Qwen3-TTS 1.7B: larger multilingual TTS variant."""

    _MODEL_PATH = "Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice"

    @property
    def model_id(self) -> str:
        return "qwen3-tts-1.7b"
