"""GPT-SoVITS adapter.

Models:
    - gptsovits: few-shot voice cloning TTS

References:
    - https://github.com/RVC-Boss/GPT-SoVITS

Note:
    GPT-SoVITS is a few-shot voice cloning framework. It requires
    user-trained GPT and SoVITS model weights for specific voices.
    The official repo is auto-cloned and dependencies auto-installed,
    but you must provide your own trained model weights.

Requirements (auto-installed on first use):
    - Official GPT-SoVITS repository (auto-cloned)
    - Python dependencies (auto-installed)
    - User-trained GPT + SoVITS model weights (manual)
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import numpy as np

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


@register_model("gptsovits")
class GPTSoVITS(TTSModel):
    """GPT-SoVITS: few-shot voice cloning with high similarity."""

    MODEL_CARD = "https://github.com/RVC-Boss/GPT-SoVITS"
    SUPPORTED_LANGUAGES = {"zh", "en", "ja", "yue", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "clone"}
    REQUIREMENTS = ["torch", "torchaudio"]
    DEFAULT_SAMPLE_RATE = 32000

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)
        self._repo_path: Path | None = None

    @property
    def model_id(self) -> str:
        return "gptsovits"

    def _check_deps(self) -> None:
        """Auto-clone GPT-SoVITS repo and install dependencies."""
        import sys

        repo_path = (
            self.config.extra.get("gptsovits_repo_path")
            or os.environ.get("GPTSOVITS_REPO_PATH")
        )
        if repo_path:
            p = str(Path(repo_path).resolve())
            if p not in sys.path:
                sys.path.insert(0, p)
            self._repo_path = Path(repo_path).resolve()
            return

        from modern_tts.core.repo_manager import ensure_repo, inject_repo_path

        repo_root = ensure_repo(
            "https://github.com/RVC-Boss/GPT-SoVITS.git",
            repo_name="GPT-SoVITS",
        )
        inject_repo_path(repo_root)
        self._repo_path = repo_root

        from modern_tts.utils.auto_install import ensure_packages

        ensure_packages(["torch", "torchaudio"])
        ensure_packages([
            "soundfile", "librosa", "numba",
            "transformers", "tqdm",
        ], skip_on_failure=True)

    def load(self) -> None:
        self._check_deps()

        gpt_path = self.config.extra.get("gpt_model_path")
        sovits_path = self.config.extra.get("sovits_model_path")

        if not gpt_path or not sovits_path:
            raise RuntimeError(
                "GPT-SoVITS requires user-trained model weights. "
                "Set 'gpt_model_path' and 'sovits_model_path' in ModelConfig.extra:\n"
                "  config = ModelConfig(\n"
                "      model_id='gptsovits',\n"
                "      extra={\n"
                "          'gpt_model_path': '/path/to/your/gpt_weights.ckpt',\n"
                "          'sovits_model_path': '/path/to/your/sovits_weights.pth',\n"
                "      }\n"
                "  )\n"
                "Train your model using the GPT-SoVITS WebUI first."
            )

        if not os.path.exists(gpt_path):
            raise FileNotFoundError(f"GPT model not found: {gpt_path}")
        if not os.path.exists(sovits_path):
            raise FileNotFoundError(f"SoVITS model not found: {sovits_path}")

        from GPT_SoVITS.inference_webui import change_gpt_weights, change_sovits_weights

        change_gpt_weights(gpt_path=gpt_path)
        change_sovits_weights(sovits_path=sovits_path)
        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        default_ref = self.config.extra.get("default_reference_audio")
        ref = kwargs.pop("reference_audio", default_ref)
        if ref is None:
            raise RuntimeError(
                "GPT-SoVITS requires reference audio for synthesis. "
                "Use task='clone' with reference_audio=..., or set "
                "'default_reference_audio' in ModelConfig.extra."
            )
        return self.clone(text, reference_audio=ref, **kwargs)

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        self._ensure_loaded()

        if isinstance(reference_audio, (str, Path)):
            ref_path = str(reference_audio)
        else:
            ref_path = self._save_temp_audio(reference_audio)

        if not os.path.exists(ref_path):
            raise FileNotFoundError(f"Reference audio not found: {ref_path}")

        from GPT_SoVITS.inference_webui import get_tts_wav

        prompt_text = kwargs.pop("prompt_text", "")
        prompt_lang = kwargs.pop("prompt_language", "中文")
        target_lang = kwargs.pop("target_language", "中文")
        top_p = kwargs.pop("top_p", 1)
        temperature = kwargs.pop("temperature", 1)

        results = list(get_tts_wav(
            ref_wav_path=ref_path,
            prompt_text=prompt_text,
            prompt_language=prompt_lang,
            text=text.get_text(),
            text_language=target_lang,
            top_p=top_p,
            temperature=temperature,
        ))

        if not results:
            raise RuntimeError("GPT-SoVITS synthesis returned no results.")

        sr, audio_data = results[-1]
        if not isinstance(audio_data, np.ndarray):
            audio_data = np.array(audio_data)
        waveform = audio_data.astype(np.float32)
        if waveform.max() > 1.0:
            waveform = waveform / 32767.0

        return TTSResult(
            audio=AudioOutput(
                waveform=waveform,
                sample_rate=sr,
            ),
            text=text.get_text(),
            language=text.language,
            model_id=self.model_id,
        )

    def unload(self) -> None:
        self._repo_path = None
        super().unload()
