"""Index-TTS adapter.

Models:
    - index-tts: multilingual zero-shot TTS with high naturalness

References:
    - https://github.com/index-tts/index-tts
    - https://huggingface.co/IndexTeam/Index-TTS

Note:
    Index-TTS is a zero-shot voice-cloning model. It always requires a
    reference audio prompt. Use ``task="clone"`` (or ``clone()``) and
    provide ``reference_audio``.

Requirements:
    - ``indextts`` package (install from GitHub):
      ``pip install git+https://github.com/index-tts/index-tts.git``
    - Compatible PyTorch / transformers versions (see upstream repo).
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Any

import numpy as np

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.hf_hub import get_hf_model_path
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


@register_model("index-tts")
class IndexTTS(TTSModel):
    """Index-TTS: industrial-level zero-shot text-to-speech.

    Supports Chinese, English, Japanese, Korean, Cantonese and more.
    Trained on tens of thousands of hours of data.
    """

    MODEL_CARD = "https://huggingface.co/IndexTeam/Index-TTS"
    SUPPORTED_LANGUAGES = {"zh", "en", "ja", "ko", "yue", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "clone", "emotion", "style"}
    REQUIREMENTS = ["torch", "torchaudio", "omegaconf", "transformers", "tqdm"]
    DEFAULT_SAMPLE_RATE = 24000

    HF_PATH = "IndexTeam/Index-TTS"

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)
        self._model_path: Path | None = None
        self._infer_kwargs: dict[str, Any] = {}

    @property
    def model_id(self) -> str:
        return "index-tts"

    def _check_deps(self) -> None:
        """Verify that the upstream ``indextts`` package is importable.

        If the package is not installed, this method will automatically clone
        the official repository into ``~/.cache/modern-tts/repos/index-tts``
        and add it to ``sys.path`` so the user does not need to set any
        environment variables.
        """
        import sys

        try:
            import indextts  # noqa: F401
            return
        except ImportError:
            pass

        # 1. Try manual override (config.extra or env var)
        repo_path = (
            self.config.extra.get("index_tts_repo_path")
            or os.environ.get("INDEX_TTS_REPO_PATH")
        )
        if repo_path:
            p = str(Path(repo_path).resolve())
            if p not in sys.path:
                sys.path.insert(0, p)
            try:
                import indextts  # noqa: F401
                return
            except ImportError as exc:
                raise ImportError(
                    "Index-TTS requires the 'indextts' package.\n"
                    "Install with:\n"
                    "  pip install git+https://github.com/index-tts/index-tts.git\n"
                    "Or set INDEX_TTS_REPO_PATH to the cloned repository.\n"
                    "Note: upstream requires Python >= 3.10 and specific PyTorch / transformers versions."
                ) from exc

        # 2. Auto-download the official repository
        try:
            from modern_tts.core.repo_manager import ensure_repo, inject_repo_path
            from modern_tts.utils.auto_install import ensure_packages

            ensure_packages(["torch", "torchaudio"])
            ensure_packages([
                "transformers", "soundfile", "librosa",
                "pyyaml", "einops", "safetensors",
            ], skip_on_failure=True)

            repo_path = ensure_repo(
                "https://github.com/index-tts/index-tts.git",
                repo_name="index-tts",
            )
            inject_repo_path(repo_path)
            import indextts  # noqa: F401
        except RuntimeError as exc:
            raise ImportError(
                f"Index-TTS requires the 'indextts' package but auto-download failed: {exc}\n"
                "Install with:\n"
                "  pip install git+https://github.com/index-tts/index-tts.git\n"
                "Or set INDEX_TTS_REPO_PATH to the cloned repository.\n"
                "Note: upstream requires Python >= 3.10 and specific PyTorch / transformers versions."
            ) from exc

    def load(self) -> None:
        self._check_deps()
        from indextts.infer import IndexTTS as _IndexTTS

        # Resolve model path (local override or HF Hub download)
        # indextts sets HF_HUB_CACHE to a relative path on import.
        # Temporarily reset it so snapshot_download uses the standard cache.
        old_hf_hub_cache = os.environ.get("HF_HUB_CACHE")
        if "HF_HUB_CACHE" in os.environ:
            del os.environ["HF_HUB_CACHE"]
        try:
            self._model_path = get_hf_model_path(
                self.HF_PATH,
                model_path=self.config.model_path,
            ).resolve()
        finally:
            if old_hf_hub_cache is not None:
                os.environ["HF_HUB_CACHE"] = old_hf_hub_cache
            elif "HF_HUB_CACHE" in os.environ:
                del os.environ["HF_HUB_CACHE"]

        cfg_path = self._model_path / "config.yaml"
        if not cfg_path.exists():
            raise RuntimeError(
                f"config.yaml not found in {self._model_path}. "
                f"The HuggingFace repository may be incomplete."
            )

        # Workaround: upstream config.yaml references checkpoints/bpe.model
        # but the HF repo places bpe.model at the root. Create a symlink.
        ckpt_dir = self._model_path / "checkpoints"
        bpe_src = self._model_path / "bpe.model"
        bpe_dst = ckpt_dir / "bpe.model"
        if bpe_src.exists():
            ckpt_dir.mkdir(exist_ok=True)
            if not bpe_dst.exists() and not bpe_dst.is_symlink():
                try:
                    bpe_dst.symlink_to(bpe_src)
                except OSError:
                    shutil.copy2(bpe_src, bpe_dst)

        # Read optional inference kwargs from config.extra
        self._infer_kwargs = {
            "verbose": self.config.extra.get("verbose", False),
            "max_text_tokens_per_segment": self.config.extra.get(
                "max_text_tokens_per_segment", 120
            ),
        }
        # Merge generation kwargs
        gen_keys = [
            "do_sample", "top_p", "top_k", "temperature",
            "length_penalty", "num_beams", "repetition_penalty",
            "max_mel_tokens",
        ]
        for key in gen_keys:
            if key in self.config.extra:
                self._infer_kwargs[key] = self.config.extra[key]

        device = self._resolve_device()
        use_fp16 = self.config.extra.get("use_fp16", True)
        use_cuda_kernel = self.config.extra.get("use_cuda_kernel", False)

        self._model = _IndexTTS(
            cfg_path=str(cfg_path),
            model_dir=str(self._model_path),
            use_fp16=use_fp16,
            device=device if device != "auto" else None,
            use_cuda_kernel=use_cuda_kernel,
        )
        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        """Synthesize speech.

        Index-TTS is a zero-shot cloning model; for ``task="speak"`` we
        fall back to cloning if a default reference audio is configured,
        otherwise raise an error directing the user to ``clone()``.
        """
        default_ref = self.config.extra.get("default_reference_audio")
        ref = kwargs.pop("reference_audio", default_ref)
        if ref is None:
            raise RuntimeError(
                "Index-TTS is a zero-shot voice-cloning model and requires "
                "a reference audio. Use TTSPipeline with task='clone' and "
                "reference_audio=..., or set 'default_reference_audio' in "
                "ModelConfig.extra."
            )
        return self.clone(text, reference_audio=ref, **kwargs)

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        """Clone a voice from reference audio and synthesize text."""
        self._ensure_loaded()

        # Resolve reference audio to a file path
        if isinstance(reference_audio, (str, Path)):
            ref_path = str(reference_audio)
        else:
            ref_path = self._save_temp_audio(reference_audio)

        if not os.path.exists(ref_path):
            raise FileNotFoundError(f"Reference audio not found: {ref_path}")

        # Merge inference kwargs with per-call overrides
        infer_kwargs = dict(self._infer_kwargs)
        infer_kwargs.update({k: v for k, v in kwargs.items() if k not in ("language", "task")})

        # Run inference (output_path=None returns (sr, wav_array))
        result = self._model.infer(
            audio_prompt=ref_path,
            text=text.get_text(),
            output_path=None,
            **infer_kwargs,
        )

        # Parse result: (sample_rate, wav_data)
        # wav_data is int16 numpy array, shape (N, 1) or (N,)
        sr, wav_data = result
        if wav_data.ndim > 1:
            wav_data = wav_data.squeeze()
        waveform = wav_data.astype(np.float32) / 32767.0

        return TTSResult(
            audio=AudioOutput(
                waveform=waveform,
                sample_rate=sr,
            ),
            text=text.get_text(),
            language=text.language,
            model_id=self.model_id,
        )

    def unload(self) -> None:
        """Release model weights and clear caches."""
        if self._model is not None:
            # Index-TTS caches reference audio MEL features
            self._model.cache_audio_prompt = None
            self._model.cache_cond_mel = None
        super().unload()
