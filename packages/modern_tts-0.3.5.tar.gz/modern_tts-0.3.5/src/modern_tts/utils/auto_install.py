"""Auto-install missing Python packages at runtime."""

from __future__ import annotations

import importlib
import subprocess
import sys
from pathlib import Path

# pip package name -> import name (for packages where they differ)
_IMPORT_MAP: dict[str, str] = {
    "lingua-language-detector": "lingua",
    "WeTextProcessing": "tn",
    "pytorch-cuda": "torch",
    "sentencex": "sentencex",
    "pyyaml": "yaml",
    "pillow": "PIL",
    "scikit-learn": "sklearn",
    "openai-whisper": "whisper",
    "pypinyin": "pypinyin",
    "cn2an": "cn2an",
    "pyopenjtalk": "pyopenjtalk",
    "grpcio": "grpc",
    "grpcio-tools": "grpc_tools",
    "protobuf": "google.protobuf",
    "hydra-core": "hydra",
    "descript-audiotools": "audiotools",
    "modelscope": "modelscope",
}


def _get_import_name(pkg_spec: str) -> str:
    """Extract the importable module name from a pip package spec."""
    name = pkg_spec.split("==")[0].split(">=")[0].split("<=")[0].split("<")[0].split(">")[0].strip()
    return _IMPORT_MAP.get(name, name.replace("-", "_"))


def _is_installed(import_name: str) -> bool:
    """Check if a package is importable."""
    try:
        importlib.import_module(import_name)
        return True
    except ImportError:
        return False


def _pip_install(*args: str) -> None:
    """Run pip/uv install with the given arguments."""
    import shutil

    if shutil.which("uv"):
        cmd = ["uv", "pip", "install", "--python", sys.executable, *args]
    else:
        cmd = [sys.executable, "-m", "pip", "install", *args]

    try:
        subprocess.check_call(cmd)
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            f"Failed to install packages: {' '.join(args)}\n"
            f"Command: {' '.join(cmd)}\n"
            f"Try installing manually."
        ) from exc


def ensure_packages(packages: list[str], skip_on_failure: bool = False) -> list[str]:
    """Ensure all packages are installed, auto-installing missing ones.

    Args:
        packages: List of pip package specs (e.g. ``["torch", "fairseq==0.12.2"]``).
        skip_on_failure: If True, skip packages that fail to install instead of raising.

    Returns:
        List of package names that failed to install (empty if all succeeded).
    """
    missing = []
    for pkg in packages:
        import_name = _get_import_name(pkg)
        if not _is_installed(import_name):
            missing.append(pkg)

    if not missing:
        return []

    failed = []
    if skip_on_failure:
        for pkg in missing:
            print(f"[auto-install] Installing {pkg} ...")
            try:
                _pip_install(pkg)
            except RuntimeError:
                print(f"[auto-install] Warning: failed to install {pkg}, skipping")
                failed.append(pkg)
    else:
        print(f"[auto-install] Installing {', '.join(missing)} ...")
        _pip_install(*missing)

    return failed


def ensure_requirements(path: str | Path) -> None:
    """Install all packages from a requirements.txt file.

    Args:
        path: Path to the requirements.txt file.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Requirements file not found: {path}")

    print(f"[auto-install] Installing from {path.name} ...")
    _pip_install("-r", str(path))
