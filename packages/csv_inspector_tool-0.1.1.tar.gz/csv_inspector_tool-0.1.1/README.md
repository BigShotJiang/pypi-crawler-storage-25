# csv-inspector

`csv-inspector` is a Python package that reads a CSV file and gives a structured report covering:

- **Table title** — derived from the file name
- **Column headers** — every column found in row 1
- **Row counts per column** — total rows, non-empty rows, empty rows, and fill-rate %

---

# Installation

```bash
pip install csv-inspector-tool
```

Requires Python 3.8 or higher. No third-party dependencies — standard library only.

---

## Quick start

### Command line

```bash
csv-inspector students.csv
```

Output:

```
============================================================
Table  : students
File   : /home/user/data/students.csv
Rows   : 120
Columns: 4

Headers & row counts:
  'student_id'                   total=120  non-empty=120  empty=0   fill=100.0%
  'name'                         total=120  non-empty=118  empty=2   fill=98.33%
  'grade'                        total=120  non-empty=120  empty=0   fill=100.0%
  'email'                        total=120  non-empty=95   empty=25  fill=79.17%
============================================================
```

### Python API

```python
from csv_inspector import inspect

report = inspect("students.csv")

print(report.title)        # "students"
print(report.headers)      # ['student_id', 'name', 'grade', 'email']
print(report.total_rows)   # 120

for stat in report.column_stats:
    print(f"{stat.name}: {stat.fill_rate}% complete")

# Or print the full formatted report:
print(report)
```