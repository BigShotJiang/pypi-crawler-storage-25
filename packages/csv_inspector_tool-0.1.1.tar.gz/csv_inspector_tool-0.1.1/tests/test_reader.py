import os
import textwrap
import tempfile
import pytest

from csv_inspector import inspect, TableReport, ColumnStats


def write_csv(content: str) -> str:
    """Write content to a temp CSV file and return the path."""
    f = tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, encoding="utf-8"
    )
    f.write(textwrap.dedent(content))
    f.close()
    return f.name


# Basic smoke test
def test_basic():
    path = write_csv("""\
        id,name,score
        1,Alice,95
        2,Bob,88
        3,Carol,
    """)
    try:
        report = inspect(path)
        assert isinstance(report, TableReport)
        assert report.total_rows == 3
        assert report.headers == ["id", "name", "score"]
        assert report.title == os.path.splitext(os.path.basename(path))[0]

        by_name = {s.name: s for s in report.column_stats}
        assert by_name["id"].non_empty_count == 3
        assert by_name["score"].empty_count == 1
        assert by_name["score"].fill_rate == pytest.approx(66.67, abs=0.01)
    finally:
        os.unlink(path)


# Single-column CSV
def test_single_column():
    path = write_csv("fruit\napple\nbanana\n\n")
    try:
        report = inspect(path)
        assert report.headers == ["fruit"]
        assert report.total_rows == 2
        assert report.column_stats[0].empty_count == 0
    finally:
        os.unlink(path)


# Auto-detect semicolon delimiter
def test_semicolon_delimiter():
    path = write_csv("a;b;c\n1;2;3\n4;5;6\n")
    try:
        report = inspect(path)
        assert report.headers == ["a", "b", "c"]
        assert report.total_rows == 2
    finally:
        os.unlink(path)


# Explicit delimiter
def test_explicit_tab_delimiter():
    path = write_csv("x\ty\n10\t20\n30\t40\n")
    try:
        report = inspect(path, delimiter="\t")
        assert report.headers == ["x", "y"]
        assert report.total_rows == 2
    finally:
        os.unlink(path)


# File not found
def test_missing_file():
    with pytest.raises(FileNotFoundError):
        inspect("/nonexistent/path/file.csv")


# Empty file (header only)
def test_header_only():
    path = write_csv("col1,col2,col3\n")
    try:
        report = inspect(path)
        assert report.total_rows == 0
        for stat in report.column_stats:
            assert stat.non_empty_count == 0
            assert stat.fill_rate == 0.0
    finally:
        os.unlink(path)


# __str__ sanity check
def test_str_output():
    path = write_csv("name,age\nAlice,30\nBob,\n")
    try:
        report = inspect(path)
        text = str(report)
        assert "name" in text
        assert "age" in text
        assert str(report.total_rows) in text
    finally:
        os.unlink(path)
