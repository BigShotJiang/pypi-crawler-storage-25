"""
Core logic for reading and analysing CSV files.
"""

import csv
import os
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class ColumnStats:
    """Statistics for a single column (header)."""
    name: str
    non_empty_count: int  # rows where the cell is not blank
    empty_count: int      # rows where the cell is blank / missing
    total_count: int      # total data rows (excludes the header row itself)

    @property
    def fill_rate(self) -> float:
        """Percentage of rows that have a value for this column."""
        if self.total_count == 0:
            return 0.0
        return round(self.non_empty_count / self.total_count * 100, 2)

    def __str__(self) -> str:
        return (
            f"  {self.name!r:<30} "
            f"total={self.total_count}  "
            f"non-empty={self.non_empty_count}  "
            f"empty={self.empty_count}  "
            f"fill={self.fill_rate}%"
        )


@dataclass
class TableReport:
    """Full report for one CSV file."""
    file_path: str
    title: str                        # derived from the file name (no extension)
    headers: List[str]
    total_rows: int                   # data rows (excludes header)
    column_stats: List[ColumnStats] = field(default_factory=list)

    def __str__(self) -> str:
        sep = "=" * 60
        lines = [
            sep,
            f"Table  : {self.title}",
            f"File   : {self.file_path}",
            f"Rows   : {self.total_rows}",
            f"Columns: {len(self.headers)}",
            "",
            "Headers & row counts:",
        ]
        for stat in self.column_stats:
            lines.append(str(stat))
        lines.append(sep)
        return "\n".join(lines)


def inspect(
    file_path: str,
    encoding: str = "utf-8",
    delimiter: Optional[str] = None,
) -> TableReport:
    """
    Read a CSV file and return a :class:`TableReport`.

    Parameters
    ----------
    file_path : str
        Path to the CSV file.
    encoding : str
        File encoding (default ``"utf-8"``).
    delimiter : str or None
        Column delimiter.  ``None`` means auto-detect via :pyclass:`csv.Sniffer`.

    Returns
    -------
    TableReport
    """
    file_path = os.path.abspath(file_path)
    title = os.path.splitext(os.path.basename(file_path))[0]

    with open(file_path, newline="", encoding=encoding) as fh:
        raw = fh.read()

    # Auto-detect delimiter when not supplied
    if delimiter is None:
        sample = raw[:4096]
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
            delimiter = dialect.delimiter
        except csv.Error:
            delimiter = ","  # fall back to comma

    reader = csv.DictReader(raw.splitlines(), delimiter=delimiter)
    headers = reader.fieldnames or []

    # Initialise counters
    non_empty: dict = {h: 0 for h in headers}
    empty: dict     = {h: 0 for h in headers}
    total_rows = 0

    for row in reader:
        total_rows += 1
        for h in headers:
            val = (row.get(h) or "").strip()
            if val:
                non_empty[h] += 1
            else:
                empty[h] += 1

    column_stats = [
        ColumnStats(
            name=h,
            non_empty_count=non_empty[h],
            empty_count=empty[h],
            total_count=total_rows,
        )
        for h in headers
    ]

    return TableReport(
        file_path=file_path,
        title=title,
        headers=list(headers),
        total_rows=total_rows,
        column_stats=column_stats,
    )
