"""csv_inspector — inspect CSV files from Python or the command line."""

from .reader import ColumnStats, TableReport, inspect

__all__ = ["inspect", "TableReport", "ColumnStats"]
