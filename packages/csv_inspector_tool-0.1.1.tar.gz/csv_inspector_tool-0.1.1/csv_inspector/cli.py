"""
Command-line interface:  python -m csv_inspector  <file> [file …]
"""

import argparse
import sys

from .reader import inspect


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="csv-inspector",
        description="Inspect CSV files: show title, headers, and row counts per column.",
    )
    parser.add_argument("files", nargs="+", metavar="FILE", help="One or more CSV files to inspect.")
    parser.add_argument("--encoding", default="utf-8", help="File encoding (default: utf-8).")
    parser.add_argument(
        "--delimiter",
        default=None,
        help="Column delimiter.  Omit to auto-detect.",
    )

    args = parser.parse_args()

    exit_code = 0
    for path in args.files:
        try:
            report = inspect(path, encoding=args.encoding, delimiter=args.delimiter)
            print(report)
        except FileNotFoundError:
            print(f"ERROR: file not found — {path}", file=sys.stderr)
            exit_code = 1
        except Exception as exc:  # noqa: BLE001
            print(f"ERROR: {path} — {exc}", file=sys.stderr)
            exit_code = 1

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
