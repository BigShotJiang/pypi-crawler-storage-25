from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np


@dataclass
class Trajectory:
    """Time-ordered pose samples represented in Cartesian coordinates."""

    timestamps: np.ndarray
    positions: np.ndarray
    orientations: Optional[np.ndarray] = None  # Quaternion format: (x, y, z, w)

    def __post_init__(self) -> None:
        self.timestamps = np.asarray(self.timestamps, dtype=float)
        self.positions = np.asarray(self.positions, dtype=float)

        if self.timestamps.ndim != 1:
            raise ValueError("timestamps must be a 1D array")
        if self.positions.ndim != 2 or self.positions.shape[1] != 3:
            raise ValueError("positions must be an Nx3 array")
        if self.positions.shape[0] != self.timestamps.shape[0]:
            raise ValueError("timestamps and positions must have the same length")

        if self.orientations is not None:
            self.orientations = np.asarray(self.orientations, dtype=float)
            if self.orientations.ndim != 2 or self.orientations.shape[1] != 4:
                raise ValueError("orientations must be an Nx4 array")
            if self.orientations.shape[0] != self.timestamps.shape[0]:
                raise ValueError("timestamps and orientations must have the same length")


@dataclass(frozen=True)
class GPSMeasurement:
    timestamp: float
    easting: float
    northing: float
    altitude: float
    zone_number: int
    zone_letter: str


@dataclass(frozen=True)
class GPSReference:
    easting: float
    northing: float
    altitude: float
    zone_number: int
    zone_letter: str


@dataclass
class AlignmentResult:
    optimized_trajectory: Trajectory
    gps_reference: GPSReference
    num_poses: int
    num_gps_factors: int
    num_odom_factors: int
    final_error: float
