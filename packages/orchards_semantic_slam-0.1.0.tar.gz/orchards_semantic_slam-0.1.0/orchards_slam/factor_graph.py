from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from .alignment import smooth_trajectory
from .transforms import matrix_to_quaternion, quaternion_to_matrix
from .types import AlignmentResult, GPSMeasurement, GPSReference, Trajectory

try:
    import gtsam
    from gtsam.symbol_shorthand import X
except ImportError:  # pragma: no cover
    gtsam = None
    X = None


def _require_gtsam() -> None:
    if gtsam is None or X is None:
        raise ImportError(
            "The 'gtsam' package is required for factor graph operations. "
            "Install it with 'pip install gtsam'."
        )


class TrajectoryFactorGraph:
    """Factor graph for fusing odometry with absolute position measurements."""

    def __init__(self, gps_position_sigma: float = 1.0, gps_altitude_sigma: float = 2.0, planar: bool = False):
        _require_gtsam()

        self.graph = gtsam.NonlinearFactorGraph()
        self.initial_estimate = gtsam.Values()

        parameters = gtsam.ISAM2Params()
        parameters.setRelinearizeThreshold(0.01)
        parameters.relinearizeSkip = 1
        self.isam = gtsam.ISAM2(parameters)

        self.pose_ids: List[int] = []
        self.id_counter = 0

        self.gps_position_sigma = gps_position_sigma
        self.gps_altitude_sigma = gps_altitude_sigma
        self.planar = planar

        self.num_gps_factors = 0
        self.num_odom_factors = 0

    def get_new_id(self) -> int:
        new_id = self.id_counter
        self.id_counter += 1
        return new_id

    def add_initial_pose(
        self,
        position: np.ndarray,
        orientation: Tuple[float, float, float, float],
        position_sigma: float = 0.01,
        orientation_sigma: float = 0.01,
    ) -> int:
        pose_id = self.get_new_id()
        self.pose_ids.append(pose_id)

        qx, qy, qz, qw = orientation
        rotation = gtsam.Rot3.Quaternion(qw, qx, qy, qz)
        pose = gtsam.Pose3(rotation, gtsam.Point3(position))

        self.initial_estimate.insert(X(pose_id), pose)

        if self.planar:
            # Keep out-of-plane DOFs weakly constrained to avoid a singular system.
            weak_rot_sigma = max(orientation_sigma * 10.0, 1.0)
            weak_pos_sigma = max(position_sigma * 10.0, 1.0)
            prior_noise = gtsam.noiseModel.Diagonal.Sigmas(
                np.array(
                    [
                        orientation_sigma,
                        orientation_sigma,
                        weak_rot_sigma,
                        position_sigma,
                        position_sigma,
                        weak_pos_sigma,
                    ]
                )
            )
        else:
            prior_noise = gtsam.noiseModel.Diagonal.Sigmas(
                np.array(
                    [
                        orientation_sigma,
                        orientation_sigma,
                        orientation_sigma,
                        position_sigma,
                        position_sigma,
                        position_sigma,
                    ]
                )
            )

        self.graph.push_back(gtsam.PriorFactorPose3(X(pose_id), pose, prior_noise))
        return pose_id

    def add_odometry_factor(
        self,
        relative_pose: Any,
        odom_sigma_translation: float = 0.1,
        odom_sigma_rotation: float = 0.05,
    ) -> int:
        if not self.pose_ids:
            raise RuntimeError("Must add initial pose before adding odometry factors")

        pose_id = self.get_new_id()
        self.pose_ids.append(pose_id)
        prev_pose_id = self.pose_ids[-2]

        if self.initial_estimate.exists(X(prev_pose_id)):
            prev_pose = self.initial_estimate.atPose3(X(prev_pose_id))
        else:
            prev_pose = self.isam.calculateEstimate().atPose3(X(prev_pose_id))

        new_pose = prev_pose.compose(relative_pose)
        self.initial_estimate.insert(X(pose_id), new_pose)

        if self.planar:
            weak_rot_sigma = max(odom_sigma_rotation * 10.0, 1.0)
            weak_pos_sigma = max(odom_sigma_translation * 10.0, 1.0)
            odom_noise = gtsam.noiseModel.Diagonal.Sigmas(
                np.array(
                    [
                        odom_sigma_rotation,
                        odom_sigma_rotation,
                        weak_rot_sigma,
                        odom_sigma_translation,
                        odom_sigma_translation,
                        weak_pos_sigma,
                    ]
                )
            )
        else:
            odom_noise = gtsam.noiseModel.Diagonal.Sigmas(
                np.array(
                    [
                        odom_sigma_rotation,
                        odom_sigma_rotation,
                        odom_sigma_rotation,
                        odom_sigma_translation,
                        odom_sigma_translation,
                        odom_sigma_translation,
                    ]
                )
            )

        self.graph.push_back(
            gtsam.BetweenFactorPose3(X(prev_pose_id), X(pose_id), relative_pose, odom_noise)
        )
        self.num_odom_factors += 1

        return pose_id

    def add_gps_factor(self, pose_id: int, gps_position: np.ndarray) -> None:
        if self.planar:
            weak_altitude_sigma = max(self.gps_altitude_sigma, 5.0)
            gps_noise = gtsam.noiseModel.Diagonal.Sigmas(
                np.array([self.gps_position_sigma, self.gps_position_sigma, weak_altitude_sigma])
            )
        else:
            gps_noise = gtsam.noiseModel.Diagonal.Sigmas(
                np.array([self.gps_position_sigma, self.gps_position_sigma, self.gps_altitude_sigma])
            )

        self.graph.push_back(gtsam.GPSFactor(X(pose_id), gtsam.Point3(gps_position), gps_noise))
        self.num_gps_factors += 1

    def update(self) -> None:
        self.isam.update(self.graph, self.initial_estimate)
        self.isam.update()
        self.graph.resize(0)
        self.initial_estimate.clear()

    def get_optimized_poses(self) -> Dict[int, Tuple[np.ndarray, np.ndarray]]:
        current_estimate = self.isam.calculateEstimate()
        poses: Dict[int, Tuple[np.ndarray, np.ndarray]] = {}

        for pose_id in self.pose_ids:
            pose = current_estimate.atPose3(X(pose_id))
            position = pose.translation()
            quaternion = pose.rotation().toQuaternion()
            poses[pose_id] = (
                np.array(position) if not isinstance(position, np.ndarray) else position,
                np.array([quaternion.x(), quaternion.y(), quaternion.z(), quaternion.w()]),
            )

        return poses

    def get_error(self) -> float:
        current_estimate = self.isam.calculateEstimate()
        return self.isam.getFactorsUnsafe().error(current_estimate)


def fuse_trajectories_with_factor_graph(
    odom_traj: Trajectory,
    gps_measurements: List[GPSMeasurement],
    gps_reference: GPSReference,
    max_time_diff: float = 0.5,
    gps_position_sigma: float = 2.0,
    gps_altitude_sigma: float = 5.0,
    odom_sigma_translation: float = 0.1,
    odom_sigma_rotation: float = 0.05,
    planar: bool = False,
    smooth_window: int = 5,
    smooth_weight: float = 0.3,
    gps_offset: Optional[np.ndarray] = None,
) -> AlignmentResult:
    _require_gtsam()

    if odom_traj.timestamps.size == 0:
        raise ValueError("Odometry trajectory is empty")

    if len(gps_measurements) == 0:
        raise ValueError("No GPS measurements provided")

    if smooth_weight > 0 and smooth_window >= 3:
        odom_traj = smooth_trajectory(odom_traj, window_size=smooth_window, position_weight=smooth_weight)

    fg = TrajectoryFactorGraph(
        gps_position_sigma=gps_position_sigma,
        gps_altitude_sigma=gps_altitude_sigma,
        planar=planar,
    )

    first_gps = gps_measurements[0]
    first_gps_utm = np.array([first_gps.easting, first_gps.northing, first_gps.altitude])

    odom_times = odom_traj.timestamps
    idx = np.searchsorted(odom_times, first_gps.timestamp)
    if idx >= len(odom_times):
        idx = len(odom_times) - 1

    if odom_traj.orientations is not None and len(odom_traj.orientations) > idx:
        initial_quat = tuple(odom_traj.orientations[idx])
    else:
        initial_quat = (0.0, 0.0, 0.0, 1.0)

    pose_id = fg.add_initial_pose(
        position=first_gps_utm,
        orientation=initial_quat,
        position_sigma=0.01,
        orientation_sigma=0.01,
    )

    pose_id_to_timestamp = {pose_id: odom_traj.timestamps[idx]}
    start_idx = idx

    for i in range(start_idx + 1, len(odom_traj.timestamps)):
        prev_pos = odom_traj.positions[i - 1]
        curr_pos = odom_traj.positions[i]

        if odom_traj.orientations is not None:
            prev_quat = odom_traj.orientations[i - 1]
            curr_quat = odom_traj.orientations[i]

            prev_rot = quaternion_to_matrix(prev_quat[0], prev_quat[1], prev_quat[2], prev_quat[3])
            curr_rot = quaternion_to_matrix(curr_quat[0], curr_quat[1], curr_quat[2], curr_quat[3])

            rel_rot = prev_rot.T @ curr_rot
            rel_quat = matrix_to_quaternion(rel_rot)
            rel_trans = prev_rot.T @ (curr_pos - prev_pos)
        else:
            rel_trans = curr_pos - prev_pos
            rel_quat = (0.0, 0.0, 0.0, 1.0)

        rel_rotation = gtsam.Rot3.Quaternion(rel_quat[3], rel_quat[0], rel_quat[1], rel_quat[2])
        rel_pose = gtsam.Pose3(rel_rotation, gtsam.Point3(rel_trans))

        new_pose_id = fg.add_odometry_factor(
            relative_pose=rel_pose,
            odom_sigma_translation=odom_sigma_translation,
            odom_sigma_rotation=odom_sigma_rotation,
        )
        pose_id_to_timestamp[new_pose_id] = odom_traj.timestamps[i]

    timestamp_to_pose_id = {v: k for k, v in pose_id_to_timestamp.items()}

    for gps_meas in gps_measurements:
        idx = np.searchsorted(odom_times[start_idx:], gps_meas.timestamp) + start_idx

        candidates = []
        if idx < len(odom_times):
            time_diff = abs(odom_times[idx] - gps_meas.timestamp)
            if time_diff <= max_time_diff:
                candidates.append((time_diff, idx))

        if idx > start_idx:
            time_diff = abs(odom_times[idx - 1] - gps_meas.timestamp)
            if time_diff <= max_time_diff:
                candidates.append((time_diff, idx - 1))

        if not candidates:
            continue

        _, best_idx = min(candidates, key=lambda x: x[0])
        odom_time = odom_times[best_idx]

        if odom_time in timestamp_to_pose_id:
            associated_pose_id = timestamp_to_pose_id[odom_time]
            gps_utm = np.array([gps_meas.easting, gps_meas.northing, gps_meas.altitude])

            if gps_offset is not None and not np.allclose(gps_offset, 0.0):
                if odom_traj.orientations is not None and best_idx < len(odom_traj.orientations):
                    quat = odom_traj.orientations[best_idx]
                    rot_matrix = quaternion_to_matrix(quat[0], quat[1], quat[2], quat[3])
                    offset_world = rot_matrix @ gps_offset
                    gps_utm = gps_utm - offset_world

            fg.add_gps_factor(associated_pose_id, gps_utm)

    fg.update()
    optimized_poses = fg.get_optimized_poses()

    timestamps = []
    positions = []
    orientations = []
    for pid in fg.pose_ids:
        pos, quat = optimized_poses[pid]
        timestamps.append(pose_id_to_timestamp[pid])
        positions.append(pos)
        orientations.append(tuple(quat))

    optimized_trajectory = Trajectory(
        timestamps=np.array(timestamps),
        positions=np.vstack(positions),
        orientations=np.array(orientations),
    )

    return AlignmentResult(
        optimized_trajectory=optimized_trajectory,
        gps_reference=gps_reference,
        num_poses=len(fg.pose_ids),
        num_gps_factors=fg.num_gps_factors,
        num_odom_factors=fg.num_odom_factors,
        final_error=fg.get_error(),
    )
