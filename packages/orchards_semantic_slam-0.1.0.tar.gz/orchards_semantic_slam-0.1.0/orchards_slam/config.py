from __future__ import annotations

from dataclasses import dataclass


@dataclass
class AlignmentConfig:
    max_time_diff: float = 0.5
    gps_position_sigma: float = 0.2
    gps_altitude_sigma: float = 1.0
    odom_translation_sigma: float = 0.1
    odom_rotation_sigma: float = 0.05
    planar: bool = False
    smooth_window: int = 5
    smooth_weight: float = 0.3


@dataclass
class SemanticGraphConfig:
    pose_sigma: float = 0.1
    orientation_sigma: float = 0.5
    landmark_sigma: float = 0.1
    pairwise_range_sigma: float = 0.01
    odom_translation_sigma: float = 0.08
    odom_rotation_sigma: float = 0.04
