from __future__ import annotations

import math
from typing import List, Tuple

import numpy as np

from .transforms import matrix_to_quaternion, quaternion_to_matrix
from .types import Trajectory


def match_trajectories(
    source: Trajectory,
    target: Trajectory,
    max_time_diff: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    if source.timestamps.size == 0 or target.timestamps.size == 0:
        raise ValueError("Empty trajectory provided for matching")

    source_times = source.timestamps
    target_times = target.timestamps

    matches_source: List[np.ndarray] = []
    matches_target: List[np.ndarray] = []
    match_times: List[float] = []

    for t, target_pos in zip(target_times, target.positions):
        idx = np.searchsorted(source_times, t)
        candidates: List[Tuple[float, np.ndarray]] = []

        if idx < source_times.size:
            candidates.append((abs(source_times[idx] - t), source.positions[idx]))
        if idx > 0:
            candidates.append((abs(source_times[idx - 1] - t), source.positions[idx - 1]))

        if not candidates:
            continue

        best_diff, best_source = min(candidates, key=lambda item: item[0])
        if best_diff <= max_time_diff:
            matches_source.append(best_source)
            matches_target.append(target_pos)
            match_times.append(t)

    if not matches_source:
        raise RuntimeError("No trajectory correspondences found within the provided time tolerance")

    return (
        np.vstack(matches_source),
        np.vstack(matches_target),
        np.asarray(match_times, dtype=float),
    )


def compute_se3_alignment(
    source_points: np.ndarray,
    target_points: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    if source_points.shape != target_points.shape or source_points.shape[1] != 3:
        raise ValueError("Source and target point sets must both be Nx3")

    centroid_source = source_points.mean(axis=0)
    centroid_target = target_points.mean(axis=0)

    src_centered = source_points - centroid_source
    tgt_centered = target_points - centroid_target

    H = src_centered.T @ tgt_centered
    U, _, Vt = np.linalg.svd(H)
    rotation = Vt.T @ U.T

    if np.linalg.det(rotation) < 0:
        Vt[2, :] *= -1
        rotation = Vt.T @ U.T

    translation = centroid_target - rotation @ centroid_source

    residuals = target_points - (rotation @ source_points.T).T - translation
    rmse = math.sqrt(np.mean(np.sum(residuals**2, axis=1)))

    transform = np.eye(4)
    transform[:3, :3] = rotation
    transform[:3, 3] = translation

    return transform, rotation, translation, rmse


def compute_se2_alignment(
    source_points: np.ndarray,
    target_points: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    if source_points.shape != target_points.shape or source_points.shape[1] != 3:
        raise ValueError("Source and target point sets must both be Nx3")

    source_xy = source_points[:, :2]
    target_xy = target_points[:, :2]

    centroid_source = source_xy.mean(axis=0)
    centroid_target = target_xy.mean(axis=0)

    src_centered = source_xy - centroid_source
    tgt_centered = target_xy - centroid_target

    H = src_centered.T @ tgt_centered
    U, _, Vt = np.linalg.svd(H)
    rot2 = Vt.T @ U.T

    if np.linalg.det(rot2) < 0:
        Vt[1, :] *= -1
        rot2 = Vt.T @ U.T

    t2 = centroid_target - rot2 @ centroid_source

    residuals = target_xy - (rot2 @ source_xy.T).T - t2
    rmse = math.sqrt(np.mean(np.sum(residuals**2, axis=1)))

    rotation = np.eye(3)
    rotation[:2, :2] = rot2
    translation = np.array([t2[0], t2[1], 0.0], dtype=float)

    transform = np.eye(4)
    transform[:3, :3] = rotation
    transform[:3, 3] = translation

    return transform, rotation, translation, rmse


def transform_trajectory(
    trajectory: Trajectory,
    rotation: np.ndarray,
    translation: np.ndarray,
) -> Trajectory:
    rotated_positions = (rotation @ trajectory.positions.T).T + translation

    if trajectory.orientations is not None:
        transformed_quats = []
        for quat in trajectory.orientations:
            rot_local = quaternion_to_matrix(quat[0], quat[1], quat[2], quat[3])
            rot_world = rotation @ rot_local
            transformed_quats.append(matrix_to_quaternion(rot_world))
        orientations = np.asarray(transformed_quats, dtype=float)
    else:
        orientations = np.tile(np.array([0.0, 0.0, 0.0, 1.0], dtype=float), (trajectory.timestamps.size, 1))

    return Trajectory(
        timestamps=trajectory.timestamps.copy(),
        positions=rotated_positions,
        orientations=orientations,
    )


def smooth_trajectory(
    trajectory: Trajectory,
    window_size: int = 5,
    position_weight: float = 0.3,
) -> Trajectory:
    if window_size < 3:
        return trajectory

    if window_size % 2 == 0:
        window_size += 1

    n_poses = len(trajectory.positions)
    if n_poses < window_size:
        return trajectory

    smoothed_positions = trajectory.positions.copy()

    half_window = window_size // 2
    sigma = window_size / 6.0
    x_axis = np.arange(-half_window, half_window + 1)
    kernel = np.exp(-0.5 * (x_axis / sigma) ** 2)
    kernel /= kernel.sum()

    for dim in range(3):
        smoothed = np.convolve(trajectory.positions[:, dim], kernel, mode="same")
        smoothed_positions[:, dim] = (
            (1 - position_weight) * trajectory.positions[:, dim] + position_weight * smoothed
        )

    smoothed_positions[:half_window] = trajectory.positions[:half_window]
    smoothed_positions[-half_window:] = trajectory.positions[-half_window:]

    smoothed_orientations = trajectory.orientations.copy() if trajectory.orientations is not None else None
    if smoothed_orientations is not None and position_weight > 0:
        for i in range(half_window, n_poses - half_window):
            window_quats = trajectory.orientations[i - half_window : i + half_window + 1]

            rot_sum = np.zeros((3, 3))
            for quat, weight in zip(window_quats, kernel):
                rot = quaternion_to_matrix(quat[0], quat[1], quat[2], quat[3])
                rot_sum += weight * rot

            U, _, Vt = np.linalg.svd(rot_sum)
            rot_avg = U @ Vt
            if np.linalg.det(rot_avg) < 0:
                U[:, -1] *= -1
                rot_avg = U @ Vt

            quat_smoothed = matrix_to_quaternion(rot_avg)
            quat_original = trajectory.orientations[i]
            quat_blended = (1 - position_weight) * np.array(quat_original) + position_weight * np.array(quat_smoothed)
            quat_blended /= np.linalg.norm(quat_blended)
            smoothed_orientations[i] = tuple(quat_blended)

    return Trajectory(
        timestamps=trajectory.timestamps.copy(),
        positions=smoothed_positions,
        orientations=smoothed_orientations,
    )
