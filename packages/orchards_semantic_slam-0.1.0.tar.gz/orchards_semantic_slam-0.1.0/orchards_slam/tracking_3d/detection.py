from dataclasses import dataclass

import numpy as np


@dataclass
class Detection:
    """Single measurement used by the tracker."""

    z: np.ndarray
    sigma: float
    det_class: int
    confidence: float
    trunk_width: float
    R: np.ndarray = None
    mask: np.ndarray = None

    def __post_init__(self) -> None:
        self.R = np.diag([self.sigma**2] * 6)
