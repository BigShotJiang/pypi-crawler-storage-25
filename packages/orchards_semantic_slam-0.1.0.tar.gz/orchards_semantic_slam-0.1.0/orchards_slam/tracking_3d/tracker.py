from typing import List, Optional, Tuple, Union

import numpy as np

from . import cost
from .track import Track


class Tracker:
    def __init__(
        self,
        n_init: int = 5,
        id_start: int = 0,
        w: float = 0,
        gating_min: float = 0.4,
        gating_max: float = 0.8,
        gating_euclidean: Union[None, float] = None,
    ) -> None:
        self.n_init = n_init
        self.tracks = []
        self.deleted_tracks = []
        self._next_id = 3 + id_start
        assert 0 <= w <= 1
        self.w = w
        self.gating_min = gating_min
        self.gating_max = gating_max
        self.gating_euclidean = gating_euclidean

    def predict(self, Q: np.ndarray) -> None:
        for track in self.tracks:
            track.predict(Q=Q)

    def update(self, detections: List, robot_pose: Optional[List] = None) -> List[int]:
        matches, unmatched_tracks, unmatched_detections = self.match(detections, robot_pose)
        tracks_at_frame = []
        for track_idx, detection_idx in matches:
            self.tracks[track_idx].update(detections[detection_idx])
            tracks_at_frame.append(track_idx)

        if self.n_init > 0:
            for track_idx in unmatched_tracks:
                self.tracks[track_idx].mark_missed()

        for detection_idx in unmatched_detections:
            if self.n_init == 0:
                self.start_confirmed_track(detections[detection_idx])
            else:
                self.start_track(detections[detection_idx])

        self.deleted_tracks = [t for t in self.tracks if t.is_deleted()]
        self.tracks = [t for t in self.tracks if not t.is_deleted()]
        return tracks_at_frame

    def match(self, detections: List, robot_pose: Optional[List] = None) -> Tuple[List[Tuple[int, int]], List[int], List[int]]:
        track_indices = np.arange(len(self.tracks))
        detection_indices = np.arange(len(detections))

        if len(detection_indices) == 0 or len(track_indices) == 0:
            return [], track_indices, detection_indices

        det_positions, det_classes = [], []
        for det in detections:
            det_positions.append(det.z[:3])
            det_classes.append(det.det_class)

        track_positions, track_classes = [], []
        for track in self.tracks:
            track_positions.append(track.kf.x[:3])
            track_classes.append(track.track_class)

        position_cost_matrix = cost.euclidean_cost_matrix(
            row_positions=track_positions,
            col_positions=det_positions,
            gating=self.gating_euclidean,
        )
        class_cost_matrix = cost.class_cost_distance(track_classes, det_classes)
        total_cost_matrix = position_cost_matrix + class_cost_matrix

        return cost.min_cost_matching(
            total_cost_matrix,
            1e4,
            track_indices,
            detection_indices,
        )

    def start_track(self, detection):
        self.tracks.append(
            Track(
                detection.z,
                detection.R,
                detection.det_class,
                self._next_id,
                self.n_init,
                detection.confidence,
                detection.trunk_width,
            )
        )
        self._next_id += 1
        return self._next_id - 1

    def start_confirmed_track(self, detection):
        track = Track(
            detection.z,
            detection.R,
            detection.det_class,
            self._next_id,
            self.n_init,
            detection.confidence,
            detection.trunk_width,
        )
        track.mark_confirmed()

        self.tracks.append(track)
        self._next_id += 1

        return track.track_id
