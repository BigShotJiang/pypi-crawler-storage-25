import numpy as np
import torch
from scipy.optimize import linear_sum_assignment
from scipy.spatial import distance_matrix
from scipy.spatial.distance import mahalanobis
from torchmetrics.functional import pairwise_cosine_similarity


def mahalanobis_distance_vector(points_N, cov_N, points_M):
    N = points_N.shape[0]
    points_M_expanded = np.repeat(points_M[np.newaxis, :, :], N, axis=0)
    diff = points_N[:, np.newaxis, :] - points_M_expanded
    inv_cov_N = np.linalg.inv(cov_N)
    return np.sqrt(np.sum(diff @ inv_cov_N * diff, axis=-1))


def mahalanobis_distance(mean, covariance, measurements):
    distances = []
    for measurement in measurements:
        distances.append(mahalanobis(measurement, mean, np.array(np.matrix(covariance).I)))
    return np.array(distances)


def mahalanobis_cost_matrix(row_positions, row_covariances, col_positions, gating=True):
    matrix = mahalanobis_distance_vector(np.array(row_positions), np.array(row_covariances), np.array(col_positions))
    if gating:
        matrix[matrix > 7.8147] += 1e5
    return matrix


def euclidean_cost_matrix(row_positions, col_positions, gating=None):
    matrix = distance_matrix(np.array(row_positions), np.array(col_positions))
    if gating:
        idx = np.where(matrix > gating)
        matrix[idx] = 1e5
    return matrix


def class_cost_distance(row_classes, col_classes):
    matrix = np.zeros((len(row_classes), len(col_classes)))
    col_classes = np.array(col_classes)
    for i, row_class in enumerate(row_classes):
        idx = np.where(col_classes != row_class)
        matrix[i, idx] += 1e5
    return matrix


def cosine_cost_matrix(row_feats, col_feats):
    return 1 - pairwise_cosine_similarity(torch.cat(row_feats, dim=0), torch.cat(col_feats, dim=0)).cpu().detach().numpy()


def cosine_cost_matrix_from_list(row_feats, col_feats, gating_max=0.8, gating_min=0.4):
    cost_matrix_max = np.zeros((len(row_feats), len(col_feats)))
    cost_matrix_min = np.zeros((len(row_feats), len(col_feats)))

    for i, track_feats in enumerate(row_feats):
        temp_mat = cosine_cost_matrix(track_feats, col_feats)
        cost_matrix_max[i, :] = temp_mat.max(axis=0)
        cost_matrix_min[i, :] = temp_mat.min(axis=0)

    cost_matrix_min[cost_matrix_min > gating_min] += 1e5
    cost_matrix_min[cost_matrix_max > gating_max] += 1e5
    return cost_matrix_min


def min_cost_matching(cost_matrix, max_distance, track_indices=None, detection_indices=None):
    rows, cols = linear_sum_assignment(cost_matrix)

    matches, unmatched_tracks, unmatched_detections = [], [], []
    for col, detection_idx in enumerate(detection_indices):
        if col not in cols:
            unmatched_detections.append(detection_idx)
    for row, track_idx in enumerate(track_indices):
        if row not in rows:
            unmatched_tracks.append(track_idx)
    for row, col in zip(rows, cols):
        track_idx = track_indices[row]
        detection_idx = detection_indices[col]
        if cost_matrix[row, col] >= max_distance:
            unmatched_tracks.append(track_idx)
            unmatched_detections.append(detection_idx)
        else:
            matches.append((track_idx, detection_idx))
    return matches, unmatched_tracks, unmatched_detections
