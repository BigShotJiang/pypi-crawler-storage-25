import numpy as np
from filterpy.kalman import KalmanFilter


class TrackState:
    Tentative = 1
    Confirmed = 2
    Deleted = 3


class Track:
    def __init__(self, mean, covariance, track_class, track_id, n_init, confidence, trunk_width):
        assert mean.shape == (6,)
        self.kf = KalmanFilter(dim_x=6, dim_z=6)
        self.kf.x = mean
        self.kf.P = covariance
        self.kf.F = np.eye(6, 6)
        self.kf.H = np.eye(6, 6)
        self.track_class = track_class
        self.track_id = track_id
        self.hits = 1
        self.age = 1
        self.time_since_update = 0

        self.state = TrackState.Tentative
        self._n_init = n_init

        self.last_det_pos = mean
        self.last_det_cov = covariance
        self.track_last_conf = confidence
        self.trunk_width_kf = KalmanFilter(dim_x=1, dim_z=1)
        self.trunk_width_kf.x = np.asarray([trunk_width], dtype=float)
        self.trunk_width_kf.F = np.eye(1, 1)
        self.trunk_width_kf.H = np.eye(1, 1)

    def predict(self, Q):
        self.trunk_width_kf.predict()
        self.age += 1
        self.time_since_update += 1
        if self.state == TrackState.Tentative and self.time_since_update >= 3:
            self.state = TrackState.Deleted

    def update(self, detection):
        self.last_det_pos = detection.z
        self.last_det_cov = detection.R
        self.hits += 1
        self.time_since_update = 0
        if self.state == TrackState.Tentative and self.hits >= self._n_init:
            self.state = TrackState.Confirmed
            self.kf.x = detection.z
            self.kf.P = detection.R

        self.track_class = detection.det_class
        self.track_last_conf = detection.confidence
        self.last_mask = detection.mask
        self.trunk_width_kf.update(np.asarray([detection.trunk_width], dtype=float))

    def position_from_fg(self, pos, cov):
        self.kf.x = pos
        self.kf.P = cov

    def get_sigma(self):
        return np.sqrt(np.diag(self.last_det_cov))[0]

    def mark_missed(self):
        if self.state == TrackState.Tentative:
            self.state = TrackState.Deleted

    def mark_confirmed(self):
        self.state = TrackState.Confirmed

    def is_tentative(self):
        return self.state == TrackState.Tentative

    def is_confirmed(self):
        return self.state == TrackState.Confirmed

    def is_deleted(self):
        return self.state == TrackState.Deleted
