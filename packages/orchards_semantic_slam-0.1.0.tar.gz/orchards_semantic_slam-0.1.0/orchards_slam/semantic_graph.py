from __future__ import annotations

from typing import Any, Dict, List, Sequence, Tuple

import numpy as np

try:
    import gtsam
    from gtsam.symbol_shorthand import L, X
except ImportError:  # pragma: no cover
    gtsam = None
    L = None
    X = None


def _require_gtsam() -> None:
    if gtsam is None or L is None or X is None:
        raise ImportError(
            "The 'gtsam' package is required for semantic factor graph operations. "
            "Install it with 'pip install gtsam'."
        )


class SemanticFactorGraph:
    """Pose-landmark incremental graph suitable for semantic mapping workflows."""

    def __init__(self) -> None:
        _require_gtsam()

        self.id_counter = 0
        self.landmark_symbols: Dict[int, int] = {}

        self.graph = gtsam.NonlinearFactorGraph()
        self.initial_estimate = gtsam.Values()

        parameters = gtsam.ISAM2Params()
        self.isam = gtsam.ISAM2(parameters)

        self.pose_ids: List[int] = []
        self.current_estimate = gtsam.Values()
        self.last_pose: Any = None

    @staticmethod
    def _pose3_from_rxyz(pose: Sequence[float]) -> Any:
        tx, ty, tz, theta, phi, psi = pose
        return gtsam.Pose3(gtsam.Rot3.Rodrigues(theta, phi, psi), gtsam.Point3(tx, ty, tz))

    def _new_id(self) -> int:
        new_id = self.id_counter
        self.id_counter += 1
        return new_id

    def add_initial_pose(
        self,
        pose: Sequence[float],
        pose_sigma: float = 0.1,
        orientation_sigma: float = 0.5,
    ) -> int:
        if self.pose_ids:
            raise RuntimeError("Initial pose already added; use add_odometry_pose for subsequent poses")

        pose_id = self._new_id()
        pose3 = self._pose3_from_rxyz(pose)
        self.initial_estimate.insert(X(pose_id), pose3)
        self.pose_ids.append(pose_id)
        self.last_pose = pose3

        prior_noise = gtsam.noiseModel.Diagonal.Sigmas(
            np.array(
                [
                    orientation_sigma,
                    orientation_sigma,
                    orientation_sigma,
                    pose_sigma,
                    pose_sigma,
                    pose_sigma,
                ]
            )
        )
        self.graph.push_back(gtsam.PriorFactorPose3(X(pose_id), pose3, prior_noise))
        return pose_id

    def add_odometry_pose(
        self,
        relative_pose: Sequence[float],
        translation_sigma: float = 0.1,
        rotation_sigma: float = 0.05,
    ) -> int:
        if not self.pose_ids:
            raise RuntimeError("Initial pose must be added before odometry factors")

        prev_pose_id = self.pose_ids[-1]
        if self.initial_estimate.exists(X(prev_pose_id)):
            prev_pose = self.initial_estimate.atPose3(X(prev_pose_id))
        else:
            prev_pose = self.current_estimate.atPose3(X(prev_pose_id))

        rel_pose = self._pose3_from_rxyz(relative_pose)
        pose_id = self._new_id()
        new_pose = prev_pose.compose(rel_pose)

        self.initial_estimate.insert(X(pose_id), new_pose)
        self.pose_ids.append(pose_id)
        self.last_pose = new_pose

        odom_noise = gtsam.noiseModel.Diagonal.Sigmas(
            np.array(
                [
                    rotation_sigma,
                    rotation_sigma,
                    rotation_sigma,
                    translation_sigma,
                    translation_sigma,
                    translation_sigma,
                ]
            )
        )
        self.graph.push_back(gtsam.BetweenFactorPose3(X(prev_pose_id), X(pose_id), rel_pose, odom_noise))
        return pose_id

    def add_robot_pose(
        self,
        pose: Sequence[float],
        pose_sigma: float = 0.1,
        orientation_sigma: float = 0.5,
    ) -> int:
        pose_id = self._new_id()
        self.last_pose = self._pose3_from_rxyz(pose)
        self.initial_estimate.insert(X(pose_id), self.last_pose)
        self.pose_ids.append(pose_id)

        pose_noise = gtsam.noiseModel.Diagonal.Sigmas(
            np.array(
                [
                    orientation_sigma,
                    orientation_sigma,
                    orientation_sigma,
                    pose_sigma,
                    pose_sigma,
                    pose_sigma,
                ]
            )
        )
        self.graph.push_back(gtsam.PriorFactorPose3(X(pose_id), self.last_pose, pose_noise))
        return pose_id

    def add_or_update_landmark(self, landmark_id: int, position: np.ndarray, sigma: float) -> int:
        if self.last_pose is None or not self.pose_ids:
            raise RuntimeError("At least one robot pose must be added before landmarks")

        if landmark_id in self.landmark_symbols:
            symbol_id = self.landmark_symbols[landmark_id]
        else:
            symbol_id = self._new_id()
            self.landmark_symbols[landmark_id] = symbol_id
            self.initial_estimate.insert(L(symbol_id), gtsam.Point3(position - 0.001))

        point = gtsam.Point3(position)
        range_measurement = self.last_pose.range(point)
        bearing_measurement = gtsam.BearingRange3D.MeasureBearing(self.last_pose, point)

        self.graph.push_back(
            gtsam.BearingRangeFactor3D(
                X(self.pose_ids[-1]),
                L(symbol_id),
                bearing_measurement,
                range_measurement,
                gtsam.noiseModel.Isotropic.Sigma(3, sigma),
            )
        )
        return symbol_id

    def add_or_update_landmark_relative(self, landmark_id: int, relative_position: np.ndarray, sigma: float) -> int:
        if self.last_pose is None or not self.pose_ids:
            raise RuntimeError("At least one robot pose must be added before landmarks")

        relative_position = np.asarray(relative_position, dtype=float).reshape(3)

        if landmark_id in self.landmark_symbols:
            symbol_id = self.landmark_symbols[landmark_id]
        else:
            symbol_id = self._new_id()
            self.landmark_symbols[landmark_id] = symbol_id

            world_guess = self.last_pose.transformFrom(gtsam.Point3(relative_position))
            world_guess_arr = np.asarray(world_guess, dtype=float).reshape(3)
            self.initial_estimate.insert(L(symbol_id), gtsam.Point3(world_guess_arr - 0.001))

        range_measurement = float(np.linalg.norm(relative_position))
        if range_measurement < 1e-9:
            return symbol_id

        bearing_measurement = gtsam.Unit3(relative_position)
        self.graph.push_back(
            gtsam.BearingRangeFactor3D(
                X(self.pose_ids[-1]),
                L(symbol_id),
                bearing_measurement,
                range_measurement,
                gtsam.noiseModel.Isotropic.Sigma(3, sigma),
            )
        )
        return symbol_id

    def add_landmark_detections(
        self,
        ids: Sequence[int],
        positions: Sequence[np.ndarray],
        sigmas: Sequence[float],
        pairwise_range_sigma: float = 0.01,
    ) -> None:
        ids = list(ids)
        positions = [np.asarray(p, dtype=float) for p in positions]

        for landmark_id, position, sigma in zip(ids, positions, sigmas):
            self.add_or_update_landmark(landmark_id, position, sigma)

        for i in range(len(ids) - 1):
            id_a = ids[i]
            id_b = ids[i + 1]
            distance = np.linalg.norm(positions[i] - positions[i + 1])
            self.graph.push_back(
                gtsam.RangeFactor3(
                    L(self.landmark_symbols[id_a]),
                    L(self.landmark_symbols[id_b]),
                    distance,
                    gtsam.noiseModel.Isotropic.Sigma(1, pairwise_range_sigma),
                )
            )

    def add_landmark_relative_detections(
        self,
        ids: Sequence[int],
        relative_positions: Sequence[np.ndarray],
        sigmas: Sequence[float],
        pairwise_range_sigma: float = 0.01,
    ) -> None:
        ids = list(ids)
        relative_positions = [np.asarray(p, dtype=float).reshape(3) for p in relative_positions]

        for landmark_id, relative_position, sigma in zip(ids, relative_positions, sigmas):
            self.add_or_update_landmark_relative(landmark_id, relative_position, sigma)

        for i in range(len(ids) - 1):
            id_a = ids[i]
            id_b = ids[i + 1]
            distance = np.linalg.norm(relative_positions[i] - relative_positions[i + 1])
            self.graph.push_back(
                gtsam.RangeFactor3(
                    L(self.landmark_symbols[id_a]),
                    L(self.landmark_symbols[id_b]),
                    distance,
                    gtsam.noiseModel.Isotropic.Sigma(1, pairwise_range_sigma),
                )
            )

    def update(self) -> None:
        self.isam.update(self.graph, self.initial_estimate)
        self.isam.update()
        self.current_estimate = self.isam.calculateEstimate()
        self.graph.resize(0)
        self.initial_estimate.clear()

    def get_landmark_estimate(self, landmark_id: int) -> Tuple[np.ndarray, np.ndarray]:
        symbol_id = self.landmark_symbols[landmark_id]
        return self.current_estimate.atPoint3(L(symbol_id)), self.isam.marginalCovariance(L(symbol_id))

    def get_pose_estimate(self, pose_id: int) -> Tuple[np.ndarray, np.ndarray]:
        pose = self.current_estimate.atPose3(X(pose_id))
        return pose.translation(), self.isam.marginalCovariance(X(pose_id))[:3, :3]

    def get_pose3(self, pose_id: int) -> Tuple[Any, float]:
        return self.current_estimate.atPose3(X(pose_id)), self.isam.marginalCovariance(X(pose_id))[0, 0]
