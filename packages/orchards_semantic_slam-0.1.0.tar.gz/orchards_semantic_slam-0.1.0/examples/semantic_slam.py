from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from orchards_slam import SemanticFactorGraph, SemanticGraphConfig
from orchards_slam.tracking_3d import Detection, Tracker


def _assign_tracked_ids(tracker: Tracker, detections: list[Detection]) -> list[int]:
    """Run one tracker update and return a track id for each detection in order."""
    if not detections:
        return []

    matches, unmatched_tracks, unmatched_detections = tracker.match(detections)
    detection_track_ids = [-1] * len(detections)

    for track_idx, detection_idx in matches:
        tracker.tracks[track_idx].update(detections[detection_idx])
        detection_track_ids[detection_idx] = tracker.tracks[track_idx].track_id

    if tracker.n_init > 0:
        for track_idx in unmatched_tracks:
            tracker.tracks[track_idx].mark_missed()

    for detection_idx in unmatched_detections:
        if tracker.n_init == 0:
            track_id = tracker.start_confirmed_track(detections[detection_idx])
        else:
            track_id = tracker.start_track(detections[detection_idx])
        detection_track_ids[detection_idx] = track_id

    tracker.deleted_tracks = [t for t in tracker.tracks if t.is_deleted()]
    tracker.tracks = [t for t in tracker.tracks if not t.is_deleted()]

    return detection_track_ids


def _collect_landmark_estimates(graph: SemanticFactorGraph) -> dict[int, np.ndarray]:
    estimates: dict[int, np.ndarray] = {}
    for landmark_id in sorted(graph.landmark_symbols.keys()):
        est, _ = graph.get_landmark_estimate(landmark_id)
        estimates[landmark_id] = np.asarray(est, dtype=float)
    return estimates


def _landmark_xy(
    landmark_truth: dict[int, np.ndarray],
    landmark_estimates: dict[int, np.ndarray],
) -> tuple[np.ndarray, np.ndarray]:
    common_landmark_ids = sorted(set(landmark_truth.keys()).intersection(landmark_estimates.keys()))
    if not common_landmark_ids:
        empty = np.empty((0, 2), dtype=float)
        return empty, empty

    truth_xy = np.vstack([landmark_truth[k][:2] for k in common_landmark_ids])
    est_xy = np.vstack([landmark_estimates[k][:2] for k in common_landmark_ids])
    return truth_xy, est_xy


def _init_live_semantic_plot() -> tuple[Any, ...] | None:
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("Skipping live plot/GIF: matplotlib not installed.")
        return None

    plt.ion()
    is_interactive_backend = "agg" not in plt.get_backend().lower()
    fig, ax = plt.subplots(figsize=(9, 6))
    gt_line, = ax.plot([], [], label="GT robot", linewidth=2.5)
    pred_line, = ax.plot([], [], label="Pred robot", linewidth=2.0)
    odom_line, = ax.plot([], [], "--", label="Noisy odometry (uncorrected)", linewidth=1.8, alpha=0.9)
    gt_landmarks = ax.scatter([], [], marker="s", s=65, label="GT landmarks")
    pred_landmarks = ax.scatter([], [], marker="x", s=65, label="Pred landmarks")

    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    ax.set_aspect("equal", adjustable="box")
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    return plt, fig, ax, gt_line, pred_line, odom_line, gt_landmarks, pred_landmarks, is_interactive_backend


def _update_live_semantic_plot(
    ax: Any,
    gt_line: Any,
    pred_line: Any,
    odom_line: Any,
    gt_landmarks: Any,
    pred_landmarks: Any,
    true_positions: np.ndarray,
    estimated_positions: np.ndarray,
    noisy_odom_positions: np.ndarray,
    landmark_truth: dict[int, np.ndarray],
    landmark_estimates: dict[int, np.ndarray],
    step: int,
    total_steps: int,
) -> None:
    gt_line.set_data(true_positions[:, 0], true_positions[:, 1])
    pred_line.set_data(estimated_positions[:, 0], estimated_positions[:, 1])
    odom_line.set_data(noisy_odom_positions[:, 0], noisy_odom_positions[:, 1])

    truth_xy, est_xy = _landmark_xy(landmark_truth, landmark_estimates)
    gt_landmarks.set_offsets(truth_xy)
    pred_landmarks.set_offsets(est_xy)

    x_samples = np.concatenate(
        [
            true_positions[:, 0],
            estimated_positions[:, 0],
            noisy_odom_positions[:, 0],
            truth_xy[:, 0],
            est_xy[:, 0],
        ]
    )
    y_samples = np.concatenate(
        [
            true_positions[:, 1],
            estimated_positions[:, 1],
            noisy_odom_positions[:, 1],
            truth_xy[:, 1],
            est_xy[:, 1],
        ]
    )
    margin = 1.2
    ax.set_xlim(float(np.min(x_samples) - margin), float(np.max(x_samples) + margin))
    ax.set_ylim(float(np.min(y_samples) - margin), float(np.max(y_samples) + margin))
    ax.set_title(f"Semantic Full SLAM: GT vs Pred (step {step + 1}/{total_steps})")
    ax.figure.canvas.draw_idle()


def run_full_slam(config: SemanticGraphConfig | None = None, seed: int = 42) -> None:
    rng = np.random.default_rng(seed)
    config = config or SemanticGraphConfig(
        pose_sigma=0.08,
        orientation_sigma=0.08,
        landmark_sigma=0.5,
        pairwise_range_sigma=0.03,
        odom_translation_sigma=1.8,
        odom_rotation_sigma=1.8,
    )
    graph = SemanticFactorGraph()
    tracker = Tracker(n_init=0, gating_euclidean=2.0)

    landmark_truth = {
        100: np.array([5.0, 1.2, 0.0]),
        101: np.array([6.0, -0.7, 0.0]),
        102: np.array([7.0, 1.0, 0.0]),
        103: np.array([8.5, -1.2, 0.0]),
        104: np.array([8.0, 0.5, 0.0]),
        105: np.array([10.0, -0.5, 0.0]),
        106: np.array([11.0, 1.5, 0.0]),
        107: np.array([12.0, -1.0, 0.0]),
        108: np.array([14.0, 0.0, 0.0]),
    }

    true_poses: list[np.ndarray] = []
    noisy_odom_poses: list[np.ndarray] = []
    odom_bias = np.array([0.02, -0.01, 0.0])
    tracked_landmark_truth: dict[int, np.ndarray] = {}
    tracked_to_gt_id: dict[int, int] = {}

    live_plot = _init_live_semantic_plot()
    gif_writer = None
    gif_output_path = Path(__file__).resolve().parents[1] / "assets" / "semantic_slam.gif"
    if live_plot is not None:
        _, fig, *_ = live_plot
        try:
            from matplotlib.animation import PillowWriter

            gif_writer = PillowWriter(fps=2)
            gif_writer.setup(fig, str(gif_output_path), dpi=100)
        except Exception as exc:
            print(f"Skipping GIF save: {exc}")
            gif_writer = None

    for step in range(12):
        x = float(step * 1.2)
        y = float(0.5 * np.sin(0.35 * step))
        yaw = float(0.05 * step)

        true_pose = np.array([x, y, 0.0, 0.0, 0.0, yaw], dtype=float)

        if step == 0:
            initial_odom_pose = true_pose + np.array(
                [
                    rng.normal(0.0, 0.15),
                    rng.normal(0.0, 0.15),
                    0.0,
                    0.0,
                    0.0,
                    rng.normal(0.0, 0.04),
                ],
                dtype=float,
            )
            graph.add_initial_pose(
                initial_odom_pose,
                pose_sigma=config.pose_sigma,
                orientation_sigma=config.orientation_sigma,
            )
            noisy_odom_poses.append(initial_odom_pose.copy())
        else:
            prev_true = true_poses[-1]
            delta_world = true_pose[:3] - prev_true[:3]
            c_prev = float(np.cos(prev_true[5]))
            s_prev = float(np.sin(prev_true[5]))
            rot_world_from_body_prev = np.array(
                [
                    [c_prev, -s_prev, 0.0],
                    [s_prev, c_prev, 0.0],
                    [0.0, 0.0, 1.0],
                ],
                dtype=float,
            )
            rel_translation = (
                rot_world_from_body_prev.T @ delta_world
                + odom_bias
                + rng.normal(0.0, 0.9, size=3)
            )
            rel_yaw = (true_pose[5] - prev_true[5]) + float(rng.normal(0.0, 0.01))
            graph.add_odometry_pose(
                [float(rel_translation[0]), float(rel_translation[1]), float(rel_translation[2]), 0.0, 0.0, rel_yaw],
                translation_sigma=config.odom_translation_sigma,
                rotation_sigma=config.odom_rotation_sigma,
            )

            prev_odom = noisy_odom_poses[-1]
            c_prev_odom = float(np.cos(prev_odom[5]))
            s_prev_odom = float(np.sin(prev_odom[5]))
            rot_world_from_body_prev_odom = np.array(
                [
                    [c_prev_odom, -s_prev_odom, 0.0],
                    [s_prev_odom, c_prev_odom, 0.0],
                    [0.0, 0.0, 1.0],
                ],
                dtype=float,
            )
            odom_pose = prev_odom.copy()
            odom_pose[:3] = prev_odom[:3] + rot_world_from_body_prev_odom @ rel_translation
            odom_pose[5] = prev_odom[5] + rel_yaw
            noisy_odom_poses.append(odom_pose)

        visible_ids = [k for k, v in landmark_truth.items() if abs(v[0] - x) < 8.0]
        c = float(np.cos(yaw))
        s = float(np.sin(yaw))
        rot_world_from_body = np.array(
            [
                [c, -s, 0.0],
                [s, c, 0.0],
                [0.0, 0.0, 1.0],
            ],
            dtype=float,
        )
        noisy_relative_positions = []
        noisy_world_positions = []
        for landmark_id in visible_ids:
            relative_true = rot_world_from_body.T @ (landmark_truth[landmark_id] - true_pose[:3])
            noisy_relative = relative_true + rng.normal(0.0, 0.08, size=3)
            noisy_relative_positions.append(noisy_relative)
            noisy_world_positions.append(true_pose[:3] + rot_world_from_body @ noisy_relative)
        if visible_ids:
            tracker_detections = [
                Detection(
                    z=np.array([p[0], p[1], p[2], 0.0, 0.0, 0.0], dtype=float),
                    sigma=config.landmark_sigma,
                    det_class=0,
                    confidence=1.0,
                    trunk_width=0.2,
                )
                for p in noisy_world_positions
            ]
            tracked_ids = _assign_tracked_ids(tracker, tracker_detections)
            for tracked_id, gt_id in zip(tracked_ids, visible_ids):
                tracked_landmark_truth.setdefault(tracked_id, landmark_truth[gt_id])
                tracked_to_gt_id.setdefault(tracked_id, gt_id)

            graph.add_landmark_relative_detections(
                ids=tracked_ids,
                relative_positions=noisy_relative_positions,
                sigmas=[config.landmark_sigma] * len(visible_ids),
                pairwise_range_sigma=config.pairwise_range_sigma,
            )

        graph.update()
        true_poses.append(true_pose)

        if live_plot is not None:
            plt, _, ax, gt_line, pred_line, odom_line, gt_landmarks, pred_landmarks, is_interactive_backend = live_plot
            iter_estimates = _collect_landmark_estimates(graph)
            _update_live_semantic_plot(
                ax=ax,
                gt_line=gt_line,
                pred_line=pred_line,
                odom_line=odom_line,
                gt_landmarks=gt_landmarks,
                pred_landmarks=pred_landmarks,
                true_positions=np.vstack([pose[:3] for pose in true_poses]),
                estimated_positions=np.vstack([graph.get_pose_estimate(pid)[0] for pid in graph.pose_ids]),
                noisy_odom_positions=np.vstack([pose[:3] for pose in noisy_odom_poses]),
                landmark_truth=tracked_landmark_truth,
                landmark_estimates=iter_estimates,
                step=step,
                total_steps=12,
            )
            if is_interactive_backend:
                plt.pause(0.001)
            if gif_writer is not None:
                gif_writer.grab_frame()

    estimated_positions = np.vstack([graph.get_pose_estimate(pid)[0] for pid in graph.pose_ids])
    true_positions = np.vstack([pose[:3] for pose in true_poses])
    pose_rmse = float(np.sqrt(np.mean(np.sum((estimated_positions - true_positions) ** 2, axis=1))))

    print("Semantic full SLAM run complete")
    print(
        "Sigmas: "
        f"pose={config.pose_sigma}, orient={config.orientation_sigma}, "
        f"odom_t={config.odom_translation_sigma}, odom_r={config.odom_rotation_sigma}, "
        f"landmark={config.landmark_sigma}, pairwise={config.pairwise_range_sigma}"
    )
    print(f"Robot poses in graph: {len(graph.pose_ids)}")
    print(f"Landmarks in graph: {len(graph.landmark_symbols)}")
    print(f"Pose RMSE (m): {pose_rmse:.6f}")
    print(f"Last pose estimate: {estimated_positions[-1].round(6).tolist()}")

    landmark_estimates = _collect_landmark_estimates(graph)
    for landmark_id, est in landmark_estimates.items():
        gt_landmark_id = tracked_to_gt_id.get(landmark_id)
        if gt_landmark_id is None:
            print(f"Landmark track {landmark_id}: {np.array(est).round(6).tolist()}")
        else:
            print(
                f"Landmark track {landmark_id} (GT {gt_landmark_id}): "
                f"{np.array(est).round(6).tolist()}"
            )

    if gif_writer is not None:
        gif_writer.finish()
        print(f"Saved GIF: {gif_output_path}")

    if live_plot is not None:
        plt, fig, *_, is_interactive_backend = live_plot
        plt.ioff()
        if is_interactive_backend:
            plt.show()
        else:
            plt.close(fig)


if __name__ == "__main__":
    run_full_slam()
