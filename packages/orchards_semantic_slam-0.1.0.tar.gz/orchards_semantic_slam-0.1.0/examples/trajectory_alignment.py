from __future__ import annotations

import numpy as np

from orchards_slam import GPSMeasurement, GPSReference, Trajectory, fuse_trajectories_with_factor_graph


def _plot_alignment(
    gt_world: np.ndarray,
    pred_world: np.ndarray,
    odom_world: np.ndarray,
    gps_measurements: list[GPSMeasurement],
) -> None:
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("Skipping plot: matplotlib not installed.")
        return

    gps_xy = np.array([[m.easting, m.northing] for m in gps_measurements], dtype=float)

    fig, ax = plt.subplots(figsize=(9, 6))
    ax.plot(gt_world[:, 0], gt_world[:, 1], label="GT trajectory", linewidth=2.5)
    ax.plot(pred_world[:, 0], pred_world[:, 1], label="Pred trajectory", linewidth=2.0)
    ax.plot(odom_world[:, 0], odom_world[:, 1], "--", label="Raw odom", alpha=0.65)
    ax.scatter(gps_xy[:, 0], gps_xy[:, 1], s=24, label="GPS fixes", alpha=0.85)

    ax.set_title("Alignment Example: GT vs Pred")
    ax.set_xlabel("Easting (m)")
    ax.set_ylabel("Northing (m)")
    ax.axis("equal")
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    plt.show()


def main() -> None:
    rng = np.random.default_rng(7)

    n = 120
    timestamps = np.linspace(0.0, 24.0, n)

    # Synthetic smooth path in local frame.
    x = 0.8 * timestamps + 2.0 * np.sin(0.25 * timestamps)
    y = 4.0 * np.sin(0.15 * timestamps)
    z = np.zeros_like(x)
    true_local = np.column_stack([x, y, z])

    # Odometry has drift and noise.
    drift = np.column_stack([0.02 * timestamps, -0.01 * timestamps, np.zeros_like(timestamps)])
    odom_positions = true_local + drift + rng.normal(0.0, 0.18, size=true_local.shape)

    # World frame anchor (UTM-like numbers) and sparse GPS fixes.
    utm_anchor = np.array([580_000.0, 5_771_000.0, 45.0])
    gps_indices = np.arange(0, n, 6)

    gps_measurements = []
    for idx in gps_indices:
        noisy_world = utm_anchor + true_local[idx] + rng.normal(0.0, [0.06, 0.06, 0.8], size=3)
        gps_measurements.append(
            GPSMeasurement(
                timestamp=float(timestamps[idx]),
                easting=float(noisy_world[0]),
                northing=float(noisy_world[1]),
                altitude=float(noisy_world[2]),
                zone_number=32,
                zone_letter="U",
            )
        )

    odom_traj = Trajectory(
        timestamps=timestamps,
        positions=odom_positions,
        orientations=np.tile([0.0, 0.0, 0.0, 1.0], (n, 1)),
    )

    reference = GPSReference(
        easting=float(utm_anchor[0]),
        northing=float(utm_anchor[1]),
        altitude=float(utm_anchor[2]),
        zone_number=32,
        zone_letter="U",
    )

    result = fuse_trajectories_with_factor_graph(
        odom_traj=odom_traj,
        gps_measurements=gps_measurements,
        gps_reference=reference,
        max_time_diff=0.4,
        gps_position_sigma=0.8,
        gps_altitude_sigma=1.2,
        odom_sigma_translation=2.8,
        odom_sigma_rotation=1.5,
        planar=True,
        smooth_window=7,
        smooth_weight=0.35,
    )

    print("Alignment dummy run complete")
    print(f"Poses: {result.num_poses}")
    print(f"GPS factors: {result.num_gps_factors}")
    print(f"Odom factors: {result.num_odom_factors}")
    print(f"Final graph error: {result.final_error:.3f}")
    print("First optimized pose (UTM):", result.optimized_trajectory.positions[0].round(3).tolist())

    gt_world = utm_anchor + true_local
    odom_world = utm_anchor + odom_positions
    pred_world = result.optimized_trajectory.positions
    _plot_alignment(gt_world, pred_world, odom_world, gps_measurements)


if __name__ == "__main__":
    main()
