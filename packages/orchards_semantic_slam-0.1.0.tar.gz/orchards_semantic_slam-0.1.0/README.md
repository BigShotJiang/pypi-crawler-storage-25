# Orchards Semantic SLAM

Factor-graph python package on top of `gtsam` for:
1. GPS-odometry trajectory alignment
2. Semantic mapping with landmark observations (for example trees)

![Semantic SLAM example](./assets/semantic_slam.gif)

## Installation

Using `uv`:

```bash
uv sync
uv pip install -e .
```

## Run Examples

Alignment-only example:

```bash
python examples/trajectory_alignment.py
```

Semantic full-SLAM example (joint robot pose + landmarks):

```bash
python examples/semantic_slam.py
```

## Related Publication

Part of this codebase was developed for the following paper:

Rapado-Rincon, D., & Kootstra, G. (2025). Tree-SLAM: semantic object SLAM for efficient mapping of individual trees in orchards. Smart Agricultural Technology, 101439.

DOI: https://doi.org/10.1016/j.atech.2025.101439

Note: not all methods from the paper are ported into this library for simplicity.