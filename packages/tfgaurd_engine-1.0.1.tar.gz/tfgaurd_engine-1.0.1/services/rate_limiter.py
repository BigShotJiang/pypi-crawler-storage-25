# rate_limiter.py - Rate limiting for API endpoints

import time
import logging
from functools import wraps
from flask import request, jsonify, g
from collections import defaultdict
from datetime import datetime, timedelta
import threading

logger = logging.getLogger(__name__)

# ============================================================================
# IN-MEMORY RATE LIMITER
# ============================================================================

class InMemoryRateLimiter:
    """
    Simple in-memory rate limiter
    For production, use Redis-backed rate limiting
    """
    
    def __init__(self):
        self.requests = defaultdict(list)
        self.lock = threading.Lock()
    
    def is_allowed(self, key, limit, window_seconds):
        """
        Check if request is allowed under rate limit
        
        Args:
            key: Unique identifier (e.g., user ID, IP address)
            limit: Maximum number of requests
            window_seconds: Time window in seconds
        
        Returns:
            tuple: (allowed: bool, remaining: int, reset_time: int)
        """
        with self.lock:
            now = time.time()
            cutoff = now - window_seconds
            
            # Remove old requests
            self.requests[key] = [req_time for req_time in self.requests[key] if req_time > cutoff]
            
            # Check if under limit
            current_count = len(self.requests[key])
            allowed = current_count < limit
            
            if allowed:
                self.requests[key].append(now)
                remaining = limit - current_count - 1
            else:
                remaining = 0
            
            # Calculate reset time (when oldest request expires)
            if self.requests[key]:
                reset_time = int(self.requests[key][0] + window_seconds)
            else:
                reset_time = int(now + window_seconds)
            
            return allowed, remaining, reset_time
    
    def reset(self, key):
        """Reset rate limit for a key"""
        with self.lock:
            if key in self.requests:
                del self.requests[key]
    
    def cleanup(self, max_age_seconds=3600):
        """Clean up old entries"""
        with self.lock:
            now = time.time()
            cutoff = now - max_age_seconds
            
            keys_to_delete = []
            for key, requests in self.requests.items():
                # Remove old requests
                self.requests[key] = [req_time for req_time in requests if req_time > cutoff]
                
                # Mark empty keys for deletion
                if not self.requests[key]:
                    keys_to_delete.append(key)
            
            for key in keys_to_delete:
                del self.requests[key]
            
            logger.debug(f"Cleaned up {len(keys_to_delete)} rate limit entries")


# Global rate limiter instance
_rate_limiter = InMemoryRateLimiter()


# ============================================================================
# RATE LIMIT CONFIGURATION
# ============================================================================

class RateLimitConfig:
    """Rate limit configuration"""
    
    # Default limits (requests per hour)
    DEFAULT_LIMIT = 100
    ADMIN_LIMIT = 1000
    DEVELOPER_LIMIT = 500
    AUDITOR_LIMIT = 200
    
    # Per-endpoint limits (requests per hour)
    ENDPOINT_LIMITS = {
        '/api/check': 50,  # Policy checks are expensive
        '/api/bulk-check': 10,  # Bulk checks are very expensive
        '/api/policies': 200,
        '/api/rules': 200,
        '/api/stats': 100,
        '/api/history': 100,
    }
    
    # Window in seconds (1 hour = 3600 seconds)
    WINDOW_SECONDS = 3600
    
    @classmethod
    def get_user_limit(cls, user_role):
        """Get rate limit for user role"""
        from core.models import UserRole
        
        if isinstance(user_role, str):
            try:
                user_role = UserRole(user_role)
            except ValueError:
                return cls.DEFAULT_LIMIT
        
        limits = {
            UserRole.ADMIN: cls.ADMIN_LIMIT,
            UserRole.DEVELOPER: cls.DEVELOPER_LIMIT,
            UserRole.AUDITOR: cls.AUDITOR_LIMIT,
        }
        
        return limits.get(user_role, cls.DEFAULT_LIMIT)
    
    @classmethod
    def get_endpoint_limit(cls, endpoint):
        """Get rate limit for specific endpoint"""
        return cls.ENDPOINT_LIMITS.get(endpoint, cls.DEFAULT_LIMIT)


# ============================================================================
# RATE LIMITING FUNCTIONS
# ============================================================================

def check_rate_limit(key, limit=None, window_seconds=None):
    """
    Check if request is within rate limit
    
    Args:
        key: Unique identifier
        limit: Maximum requests (default from config)
        window_seconds: Time window (default from config)
    
    Returns:
        tuple: (allowed: bool, remaining: int, reset_time: int)
    """
    if limit is None:
        limit = RateLimitConfig.DEFAULT_LIMIT
    
    if window_seconds is None:
        window_seconds = RateLimitConfig.WINDOW_SECONDS
    
    return _rate_limiter.is_allowed(key, limit, window_seconds)


def reset_rate_limit(key):
    """Reset rate limit for a key"""
    _rate_limiter.reset(key)


def get_rate_limit_key():
    """
    Get rate limit key for current request
    Uses user ID if authenticated, otherwise IP address
    
    Returns:
        str: Rate limit key
    """
    # Try to get username from g
    if hasattr(g, 'username') and g.username:
        return f"username:{g.username}"
    
    # Try to get username from session
    from flask import session
    if 'username' in session:
        return f"username:{session['username']}"
    
    # Fall back to IP address
    if request.environ.get('HTTP_X_FORWARDED_FOR'):
        ip = request.environ['HTTP_X_FORWARDED_FOR'].split(',')[0].strip()
    else:
        ip = request.environ.get('REMOTE_ADDR', 'unknown')
    
    return f"ip:{ip}"


def get_rate_limit_for_request():
    """
    Get appropriate rate limit for current request
    
    Returns:
        int: Rate limit
    """
    # Check if user has a role
    if hasattr(g, 'user_role'):
        user_role = getattr(g, 'user_role', None) or UserRole.DEVELOPER
        user_limit = RateLimitConfig.get_user_limit(user_role)
    else:
        user_limit = RateLimitConfig.DEFAULT_LIMIT
    
    # Check if endpoint has specific limit
    endpoint_limit = RateLimitConfig.get_endpoint_limit(request.path)
    
    # Use the more restrictive limit
    return min(user_limit, endpoint_limit)


# ============================================================================
# DECORATORS
# ============================================================================

def rate_limit(limit=None, window_seconds=None, key_func=None):
    """
    Decorator to apply rate limiting to a route
    
    Args:
        limit: Maximum requests (default: based on user role and endpoint)
        window_seconds: Time window in seconds (default: 1 hour)
        key_func: Function to generate rate limit key (default: user ID or IP)
    
    Usage:
        @app.route('/api/check')
        @rate_limit(limit=50)
        def check_policy():
            ...
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Get rate limit key
            if key_func:
                key = key_func()
            else:
                key = get_rate_limit_key()
            
            # Get rate limit
            if limit is None:
                request_limit = get_rate_limit_for_request()
            else:
                request_limit = limit
            
            # Get window
            window = window_seconds if window_seconds else RateLimitConfig.WINDOW_SECONDS
            
            # Check rate limit
            allowed, remaining, reset_time = check_rate_limit(key, request_limit, window)
            
            # Add rate limit headers to response
            @wraps(f)
            def add_headers(response):
                if isinstance(response, tuple):
                    response_obj = response[0]
                else:
                    response_obj = response
                
                if hasattr(response_obj, 'headers'):
                    response_obj.headers['X-RateLimit-Limit'] = str(request_limit)
                    response_obj.headers['X-RateLimit-Remaining'] = str(remaining)
                    response_obj.headers['X-RateLimit-Reset'] = str(reset_time)
                
                return response
            
            if not allowed:
                # Record rate limit exceeded
                try:
                    from services.metrics import record_rate_limit_exceeded
                    user = getattr(g, 'username', 'anonymous')
                    record_rate_limit_exceeded(request.path, user)
                except ImportError:
                    pass  # Metrics module not available
                
                logger.warning(f"Rate limit exceeded for {key} on {request.path}")
                
                response = jsonify({
                    'error': 'Rate limit exceeded',
                    'message': f'Too many requests. Limit: {request_limit} per hour',
                    'retry_after': reset_time - int(time.time())
                })
                response.status_code = 429
                response.headers['X-RateLimit-Limit'] = str(request_limit)
                response.headers['X-RateLimit-Remaining'] = '0'
                response.headers['X-RateLimit-Reset'] = str(reset_time)
                response.headers['Retry-After'] = str(reset_time - int(time.time()))
                
                return response
            
            # Execute function and add headers
            result = f(*args, **kwargs)
            return add_headers(result)
        
        return decorated_function
    return decorator


# ============================================================================
# FLASK INTEGRATION
# ============================================================================

def init_rate_limiting(app):
    """
    Initialize rate limiting with Flask app
    
    Usage:
        from rate_limiter import init_rate_limiting
        init_rate_limiting(app)
    """
    
    # Start cleanup task (runs every hour)
    def cleanup_task():
        while True:
            time.sleep(3600)  # 1 hour
            _rate_limiter.cleanup()
    
    cleanup_thread = threading.Thread(target=cleanup_task, daemon=True)
    cleanup_thread.start()
    
    logger.info("Rate limiting initialized successfully")


# ============================================================================
# ADMIN UTILITIES
# ============================================================================

def get_rate_limit_stats():
    """
    Get rate limit statistics
    
    Returns:
        dict: Statistics
    """
    with _rate_limiter.lock:
        return {
            'total_keys': len(_rate_limiter.requests),
            'active_limits': sum(1 for requests in _rate_limiter.requests.values() if requests),
            'total_requests_tracked': sum(len(requests) for requests in _rate_limiter.requests.values())
        }


def clear_all_rate_limits():
    """Clear all rate limits (admin only)"""
    with _rate_limiter.lock:
        _rate_limiter.requests.clear()
    
    logger.info("All rate limits cleared")
