"""
Services module for Policy Engine
Contains enterprise features like RBAC, audit, metrics, rate limiting, and WhatsApp OTP
"""

from .rbac import init_rbac, require_role, require_permission, admin_only
from .audit import init_audit_logging, log_login, log_logout, log_policy_check
from .metrics import init_metrics, record_policy_check, track_request_metrics
from .rate_limiter import init_rate_limiting, rate_limit
from .whatsapp_otp import send_signup_otp, send_login_otp, verify_otp, resend_otp, get_test_otp
from .visitor_tracker import (
    get_visitor_tracker, track_visit, get_stats,
    get_heatmap_data, _query_recent, _get_summary,
)

__all__ = [
    'init_rbac', 'require_role', 'require_permission', 'admin_only',
    'init_audit_logging', 'log_login', 'log_logout', 'log_policy_check',
    'init_metrics', 'record_policy_check', 'track_request_metrics',
    'init_rate_limiting', 'rate_limit',
    'send_signup_otp', 'send_login_otp', 'verify_otp', 'resend_otp', 'get_test_otp',
    'get_visitor_tracker', 'track_visit', 'get_stats', 'get_heatmap_data',
    '_query_recent', '_get_summary',
]
