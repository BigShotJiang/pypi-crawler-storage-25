# metrics.py - Prometheus metrics for monitoring

from prometheus_client import Counter, Histogram, Gauge, Info, generate_latest, CONTENT_TYPE_LATEST
from flask import Response
import time
import logging
from functools import wraps

logger = logging.getLogger(__name__)

# ============================================================================
# METRICS DEFINITIONS
# ============================================================================

# Application info
app_info = Info('policy_engine_app', 'Policy Engine application information')
app_info.info({'version': '2.0.0', 'environment': 'production'})

# HTTP Request metrics
http_requests_total = Counter(
    'http_requests_total',
    'Total HTTP requests',
    ['method', 'endpoint', 'status']
)

http_request_duration_seconds = Histogram(
    'http_request_duration_seconds',
    'HTTP request duration in seconds',
    ['method', 'endpoint'],
    buckets=(0.01, 0.05, 0.1, 0.5, 1.0, 2.5, 5.0, 10.0)
)

# Policy check metrics
policy_checks_total = Counter(
    'policy_checks_total',
    'Total policy checks performed',
    ['status']  # 'passed' or 'failed'
)

policy_check_duration_seconds = Histogram(
    'policy_check_duration_seconds',
    'Policy check duration in seconds',
    buckets=(0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0)
)

policy_violations_total = Counter(
    'policy_violations_total',
    'Total policy violations detected',
    ['severity']  # 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'
)

# API Key metrics
api_key_usage_total = Counter(
    'api_key_usage_total',
    'Total API key usage',
    ['user']
)

api_key_invalid_attempts_total = Counter(
    'api_key_invalid_attempts_total',
    'Total invalid API key attempts'
)

# User metrics
user_logins_total = Counter(
    'user_logins_total',
    'Total user logins',
    ['method', 'status']  # method: 'password' or 'otp', status: 'success' or 'failure'
)

active_users_gauge = Gauge(
    'active_users',
    'Number of currently active users'
)

# Database metrics
database_connections_active = Gauge(
    'database_connections_active',
    'Number of active database connections'
)

database_query_duration_seconds = Histogram(
    'database_query_duration_seconds',
    'Database query duration in seconds',
    ['operation'],
    buckets=(0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1.0)
)

# Audit log metrics
audit_logs_total = Counter(
    'audit_logs_total',
    'Total audit log entries',
    ['action', 'success']
)

# Custom rule metrics
custom_rules_total = Gauge(
    'custom_rules_total',
    'Total number of custom rules'
)

custom_rule_executions_total = Counter(
    'custom_rule_executions_total',
    'Total custom rule executions',
    ['rule_name', 'result']
)

# Rate limiting metrics
rate_limit_exceeded_total = Counter(
    'rate_limit_exceeded_total',
    'Total rate limit exceeded events',
    ['endpoint', 'user']
)


# ============================================================================
# METRIC RECORDING FUNCTIONS
# ============================================================================

def record_http_request(method, endpoint, status_code, duration):
    """Record HTTP request metrics"""
    http_requests_total.labels(method=method, endpoint=endpoint, status=status_code).inc()
    http_request_duration_seconds.labels(method=method, endpoint=endpoint).observe(duration)


def record_policy_check(passed, duration, violations_by_severity=None):
    """Record policy check metrics"""
    status = 'passed' if passed else 'failed'
    policy_checks_total.labels(status=status).inc()
    policy_check_duration_seconds.observe(duration)
    
    if violations_by_severity:
        for severity, count in violations_by_severity.items():
            policy_violations_total.labels(severity=severity).inc(count)


def record_api_key_usage(username):
    """Record API key usage"""
    api_key_usage_total.labels(user=username).inc()


def record_invalid_api_key():
    """Record invalid API key attempt"""
    api_key_invalid_attempts_total.inc()


def record_login(method, success):
    """Record user login"""
    status = 'success' if success else 'failure'
    user_logins_total.labels(method=method, status=status).inc()


def record_audit_log(action, success):
    """Record audit log creation"""
    audit_logs_total.labels(action=action, success='yes' if success else 'no').inc()


def record_rate_limit_exceeded(endpoint, user):
    """Record rate limit exceeded event"""
    rate_limit_exceeded_total.labels(endpoint=endpoint, user=user).inc()


def update_active_users(count):
    """Update active users gauge"""
    active_users_gauge.set(count)


def update_custom_rules_count(count):
    """Update custom rules gauge"""
    custom_rules_total.set(count)


def record_custom_rule_execution(rule_name, passed):
    """Record custom rule execution"""
    result = 'passed' if passed else 'failed'
    custom_rule_executions_total.labels(rule_name=rule_name, result=result).inc()


# ============================================================================
# DECORATORS
# ============================================================================

def track_request_metrics(f):
    """
    Decorator to automatically track HTTP request metrics
    
    Usage:
        @app.route('/api/check')
        @track_request_metrics
        def check_policy():
            ...
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        from flask import request
        
        start_time = time.time()
        
        try:
            response = f(*args, **kwargs)
            
            # Get status code
            if isinstance(response, tuple):
                status_code = response[1] if len(response) > 1 else 200
            else:
                status_code = 200
            
            # Record metrics
            duration = time.time() - start_time
            record_http_request(
                method=request.method,
                endpoint=request.endpoint or request.path,
                status_code=status_code,
                duration=duration
            )
            
            return response
            
        except Exception as e:
            duration = time.time() - start_time
            record_http_request(
                method=request.method,
                endpoint=request.endpoint or request.path,
                status_code=500,
                duration=duration
            )
            raise
    
    return decorated_function


def track_database_query(operation):
    """
    Decorator to track database query duration
    
    Usage:
        @track_database_query('select_users')
        def get_all_users():
            ...
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            start_time = time.time()
            
            try:
                result = f(*args, **kwargs)
                duration = time.time() - start_time
                database_query_duration_seconds.labels(operation=operation).observe(duration)
                return result
            except Exception as e:
                duration = time.time() - start_time
                database_query_duration_seconds.labels(operation=operation).observe(duration)
                raise
        
        return decorated_function
    return decorator


# ============================================================================
# METRICS ENDPOINT
# ============================================================================

def metrics_endpoint():
    """
    Flask endpoint to expose Prometheus metrics
    
    Usage:
        @app.route('/metrics')
        def metrics():
            return metrics_endpoint()
    """
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)


# ============================================================================
# METRICS COLLECTION
# ============================================================================

def collect_system_metrics():
    """
    Collect system-wide metrics
    Should be called periodically (e.g., every minute)
    """
    try:
        from core.database import get_database_stats
        
        # Get database stats
        stats = get_database_stats()
        
        # Update gauges
        if 'active_users' in stats:
            update_active_users(stats['active_users'])
        
        if 'custom_rules' in stats:
            update_custom_rules_count(stats['custom_rules'])
        
        # Update database connection gauge (if available)
        # This would require access to the connection pool
        
        logger.debug("System metrics collected successfully")
        
    except Exception as e:
        logger.error(f"Failed to collect system metrics: {str(e)}")


# ============================================================================
# FLASK INTEGRATION
# ============================================================================

def init_metrics(app):
    """
    Initialize metrics with Flask app
    Adds automatic request tracking
    
    Usage:
        from metrics import init_metrics
        init_metrics(app)
    """
    
    @app.before_request
    def before_request_metrics():
        """Store request start time"""
        from flask import g
        g.request_start_time = time.time()
    
    @app.after_request
    def after_request_metrics(response):
        """Record request metrics"""
        from flask import g, request
        
        if hasattr(g, 'request_start_time'):
            duration = time.time() - g.request_start_time
            
            # Skip static files
            if not request.path.startswith('/static/'):
                record_http_request(
                    method=request.method,
                    endpoint=request.endpoint or request.path,
                    status_code=response.status_code,
                    duration=duration
                )
        
        return response
    
    # Add metrics endpoint
    @app.route('/metrics')
    def metrics():
        """Prometheus metrics endpoint"""
        return metrics_endpoint()
    
    logger.info("Metrics initialized successfully")


# ============================================================================
# HEALTH CHECK METRICS
# ============================================================================

def get_metrics_summary():
    """
    Get a summary of current metrics (for health checks)
    
    Returns:
        dict: Metrics summary
    """
    try:
        from prometheus_client import REGISTRY
        
        # This is a simplified version - in production you'd parse the actual metrics
        return {
            'total_requests': 'See /metrics endpoint',
            'policy_checks': 'See /metrics endpoint',
            'active_users': 'See /metrics endpoint',
            'metrics_endpoint': '/metrics'
        }
    except Exception as e:
        logger.error(f"Failed to get metrics summary: {str(e)}")
        return {'error': str(e)}
