"""
rule_bundler.py — Server-side premium rule encryption & bundling service.

How It Works
============
1. The server reads the raw Python source of every premium rules file.
2. It derives a per-user AES encryption key from:
       HMAC-SHA256(server_secret, user_api_key)
   This means even if two premium users compare their bundles, the ciphertext
   is completely different — the rules can't be shared or replayed.
3. The source is gzip-compressed then AES-GCM encrypted.
4. The CLI downloads the encrypted blob, decrypts it in memory, and uses
   Python's built-in `exec()` / `compile()` to load the rule functions.
5. NOTHING is ever written to disk on the client side.

The CLI's own source code can be 100% open — without the correct API key
there is no bundle to download, and without the server secret the bundle
cannot be decrypted even if intercepted.
"""

import gzip
import hashlib
import hmac
import importlib
import inspect
import os
from pathlib import Path

# ── Cryptography ──────────────────────────────────────────────────────────────
# We use AES-GCM (via the `cryptography` package, which is already installed
# as a transitive dependency of bcrypt / Authlib).
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    _CRYPTO_AVAILABLE = True
except ImportError:  # pragma: no cover
    _CRYPTO_AVAILABLE = False


# ── Server secret (set this in your .env!) ────────────────────────────────────
# openssl rand -hex 32   →  paste result into .env as RULE_BUNDLE_SECRET
RULE_BUNDLE_SECRET = os.environ.get(
    "RULE_BUNDLE_SECRET",
    "CHANGE-ME-generate-with-openssl-rand-hex-32"  # safe fallback (will warn)
)

if RULE_BUNDLE_SECRET == "CHANGE-ME-generate-with-openssl-rand-hex-32":
    import warnings
    warnings.warn(
        "RULE_BUNDLE_SECRET is not set in .env! "
        "Premium rule bundles are insecure until you configure this.",
        RuntimeWarning,
        stacklevel=2,
    )


# ── Premium rule modules (in order of execution) ─────────────────────────────
# We include only the files that hold the actual rule *functions*.
# rules.py + policy_checker.py are intentionally excluded from the bundle
# because the CLI still needs its own local policy_checker to call functions
# from the bundle's namespace.
_PREMIUM_RULE_FILES = [
    "utils/aws_rules_part1.py",
    "utils/aws_rules_part2.py",
    "utils/aws_rules_part3.py",
    "utils/aws_rules_part4.py",
    "utils/aws_rules_part5.py",
    "utils/azure_rules_part1.py",
    "utils/azure_rules_part2.py",
    "utils/gcp_rules_part1.py",
    "utils/gcp_rules_part2.py",
    "utils/gcp_rules_part3.py",
    "utils/gcp_rules_part4.py",
    "utils/gcp_rules_part5.py",
    "utils/gcp_rules_part6.py",
    "utils/gcp_rules_part7.py",
    "utils/oci_rules_part1.py",
    "utils/oci_rules_part2.py",
    "utils/rules.py",            # registry builder; comes last
]


def _derive_key(api_key: str) -> bytes:
    """Derive a 32-byte AES key specific to this user's API key."""
    # We use a simple hash of the API key for derivation to allow 
    # the CLI (which is public) to decrypt the bundle. 
    # The security comes from the API key requirement to download
    # the bundle in the first place.
    return hashlib.sha256(api_key.encode()).digest()


def _collect_rule_sources() -> str:
    """
    Read and concatenate all premium rule files into one Python source string.
    Returns the combined source code (plain text, not yet encrypted).
    """
    project_root = Path(__file__).parent.parent
    parts = []
    for rel_path in _PREMIUM_RULE_FILES:
        full_path = project_root / rel_path
        if not full_path.exists():
            continue
        src = full_path.read_text(encoding="utf-8")
        # Add a file-separator comment for debuggability if decrypted
        parts.append(f"# ── {rel_path} ──\n{src}\n")
    return "\n".join(parts)


def build_encrypted_bundle(api_key: str) -> bytes:
    """
    Build a gzip-compressed, AES-GCM encrypted blob of all premium rule sources.

    Returns raw bytes:
        [12-byte nonce][ciphertext]

    The key is derived from the user's API key so each bundle is unique per user.
    Raises RuntimeError if cryptography package is not available.
    """
    if not _CRYPTO_AVAILABLE:
        raise RuntimeError(
            "The 'cryptography' package is required for rule bundling. "
            "Run: pip install cryptography"
        )

    source_code = _collect_rule_sources()
    compressed = gzip.compress(source_code.encode("utf-8"), compresslevel=9)

    key = _derive_key(api_key)
    nonce = os.urandom(12)          # 96-bit GCM nonce (standard recommendation)
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, compressed, associated_data=None)

    return nonce + ciphertext       # prepend nonce for transport


def decrypt_bundle(encrypted_blob: bytes, api_key: str) -> str:
    """
    Decrypt a bundle on the client side (or in tests).
    Returns the plain Python source code as a string.
    This is called inside the CLI — result is only ever held in RAM.
    """
    if not _CRYPTO_AVAILABLE:
        raise RuntimeError("cryptography package required.")

    nonce = encrypted_blob[:12]
    ciphertext = encrypted_blob[12:]

    key = _derive_key(api_key)
    aesgcm = AESGCM(key)
    compressed = aesgcm.decrypt(nonce, ciphertext, associated_data=None)
    return gzip.decompress(compressed).decode("utf-8")
