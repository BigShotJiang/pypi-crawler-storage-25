# audit.py - Simplified Audit Logging

import uuid
import logging
from datetime import datetime
from flask import request, g, has_request_context, session
from core.models import AuditLog, AuditAction
from core.database import get_db_session

logger = logging.getLogger(__name__)

def log_audit(action, resource_type=None, resource_id=None, details=None, success=True, error_message=None):
    try:
        if isinstance(action, str):
            action = AuditAction(action)
        
        user_id = None
        ip_address = None
        user_agent = None
        correlation_id = None
        
        if has_request_context():
            # Get user_id from g.username or session
            if hasattr(g, 'username') and g.username:
                from core.database import get_db_session
                from core.models import User
                with get_db_session() as db_session:
                    user = db_session.query(User).filter_by(username=g.username).first()
                    if user:
                        user_id = user.id
            elif 'username' in session:
                from core.database import get_db_session
                from core.models import User
                with get_db_session() as session_db:
                    user = session_db.query(User).filter_by(username=session['username']).first()
                    if user:
                        user_id = user.id
            if request.environ.get('HTTP_X_FORWARDED_FOR'):
                ip_address = request.environ['HTTP_X_FORWARDED_FOR'].split(',')[0].strip()
            else:
                ip_address = request.environ.get('REMOTE_ADDR')
            user_agent = request.headers.get('User-Agent', '')[:500]
            correlation_id = getattr(g, 'correlation_id', None)
        
        audit_entry = AuditLog(
            user_id=user_id,
            action=action,
            resource_type=resource_type,
            resource_id=str(resource_id) if resource_id else None,
            ip_address=ip_address,
            user_agent=user_agent,
            correlation_id=correlation_id,
            details=details,
            success=success,
            error_message=error_message,
            timestamp=datetime.utcnow()
        )
        
        with get_db_session() as db_session_commit:
            db_session_commit.add(audit_entry)
            db_session_commit.commit()
        
        logger.debug(f"Audit log created: {action.value} by user {user_id}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to create audit log: {str(e)}")
        return False

def log_login(username, success=True, error_message=None):
    details = {'username': username}
    return log_audit(AuditAction.LOGIN, 'user', username, details, success, error_message)

def log_logout(username):
    return log_audit(AuditAction.LOGOUT, 'user', username)

def log_policy_check(filename, violation_count, execution_time_ms=None):
    details = {
        'filename': filename,
        'violation_count': violation_count,
        'execution_time_ms': execution_time_ms
    }
    return log_audit(AuditAction.CHECK_POLICY, 'policy', filename, details)

def log_api_key_generation(api_key_id, description=None):
    details = {'description': description} if description else None
    return log_audit(AuditAction.GENERATE_API_KEY, 'api_key', str(api_key_id), details)

def log_api_key_revocation(api_key_id):
    return log_audit(AuditAction.REVOKE_API_KEY, 'api_key', str(api_key_id))

def init_audit_logging(app):
    @app.before_request
    def before_request_audit():
        g.correlation_id = str(uuid.uuid4())
        g.request_start_time = datetime.utcnow()
    
    logger.info("Audit logging initialized successfully")
