# whatsapp_otp.py - WhatsApp OTP Service

import os
import secrets
import string
from datetime import datetime, timedelta
from twilio.rest import Client
import json

# Configuration
OTP_LENGTH = 6
OTP_EXPIRY_MINUTES = 10
OTP_STORAGE_FILE = 'otp_store.json'

# Twilio Configuration (set these in .env)
TWILIO_ACCOUNT_SID = os.getenv('TWILIO_ACCOUNT_SID', '')
TWILIO_AUTH_TOKEN = os.getenv('TWILIO_AUTH_TOKEN', '')
TWILIO_WHATSAPP_FROM = os.getenv('TWILIO_WHATSAPP_FROM', 'whatsapp:+14155238886')  # Twilio Sandbox number

# ============================================================================
# OTP STORAGE
# ============================================================================

def load_otp_store():
    """Load OTP storage from file"""
    if not os.path.exists(OTP_STORAGE_FILE):
        return {}
    try:
        with open(OTP_STORAGE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def save_otp_store(otp_store):
    """Save OTP storage to file"""
    with open(OTP_STORAGE_FILE, 'w', encoding='utf-8') as f:
        json.dump(otp_store, f, indent=2)

def cleanup_expired_otps():
    """Remove expired OTPs from storage"""
    otp_store = load_otp_store()
    now = datetime.now()
    
    expired_phones = []
    for phone, data in otp_store.items():
        expiry = datetime.fromisoformat(data['expiry'])
        if expiry < now:
            expired_phones.append(phone)
    
    for phone in expired_phones:
        del otp_store[phone]
    
    if expired_phones:
        save_otp_store(otp_store)

# ============================================================================
# OTP GENERATION
# ============================================================================

def generate_otp():
    """Generate a random 6-digit OTP"""
    return ''.join(secrets.choice(string.digits) for _ in range(OTP_LENGTH))

def store_otp(phone_number, otp, purpose='login'):
    """Store OTP with expiry time"""
    cleanup_expired_otps()
    
    otp_store = load_otp_store()
    
    # Normalize phone number (remove spaces, add + if missing)
    phone_number = phone_number.strip().replace(' ', '')
    if not phone_number.startswith('+'):
        phone_number = '+' + phone_number
    
    otp_store[phone_number] = {
        'otp': otp,
        'expiry': (datetime.now() + timedelta(minutes=OTP_EXPIRY_MINUTES)).isoformat(),
        'purpose': purpose,
        'created_at': datetime.now().isoformat(),
        'attempts': 0
    }
    
    save_otp_store(otp_store)
    return phone_number

def verify_otp(phone_number, otp):
    """Verify OTP for a phone number"""
    cleanup_expired_otps()
    
    # Normalize phone number
    phone_number = phone_number.strip().replace(' ', '')
    if not phone_number.startswith('+'):
        phone_number = '+' + phone_number
    
    otp_store = load_otp_store()
    
    if phone_number not in otp_store:
        return False, "No OTP found for this phone number"
    
    stored_data = otp_store[phone_number]
    
    # Check expiry
    expiry = datetime.fromisoformat(stored_data['expiry'])
    if expiry < datetime.now():
        del otp_store[phone_number]
        save_otp_store(otp_store)
        return False, "OTP has expired"
    
    # Check attempts (max 3)
    if stored_data['attempts'] >= 3:
        del otp_store[phone_number]
        save_otp_store(otp_store)
        return False, "Too many failed attempts. Please request a new OTP"
    
    # Verify OTP
    if stored_data['otp'] == otp:
        # Remove OTP after successful verification
        del otp_store[phone_number]
        save_otp_store(otp_store)
        return True, "OTP verified successfully"
    else:
        # Increment attempts
        stored_data['attempts'] += 1
        save_otp_store(otp_store)
        remaining = 3 - stored_data['attempts']
        return False, f"Invalid OTP. {remaining} attempts remaining"

# ============================================================================
# WHATSAPP INTEGRATION (Twilio)
# ============================================================================

def is_twilio_configured():
    """Check if Twilio credentials are configured"""
    return bool(TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN)

def send_whatsapp_otp(phone_number, otp, purpose='login'):
    """Send OTP via WhatsApp using Twilio"""
    
    # Normalize phone number
    phone_number = phone_number.strip().replace(' ', '')
    if not phone_number.startswith('+'):
        phone_number = '+' + phone_number
    
    # If Twilio is not configured, return test mode
    if not is_twilio_configured():
        print(f"\n{'='*70}")
        print("TEST MODE - Twilio not configured")
        print(f"{'='*70}")
        print(f"Phone: {phone_number}")
        print(f"OTP: {otp}")
        print(f"Purpose: {purpose}")
        print(f"{'='*70}\n")
        return True, f"TEST MODE: Your OTP is {otp}"
    
    try:
        # Initialize Twilio client
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        
        # Prepare message
        if purpose == 'signup':
            message_body = f"""🔐 *Policy Engine - Signup Verification*

Your verification code is: *{otp}*

This code will expire in {OTP_EXPIRY_MINUTES} minutes.
Do not share this code with anyone.

If you didn't request this, please ignore this message."""
        else:
            message_body = f"""🔐 *Policy Engine - Login Verification*

Your login code is: *{otp}*

This code will expire in {OTP_EXPIRY_MINUTES} minutes.
Do not share this code with anyone.

If you didn't request this, please secure your account immediately."""
        
        # Send WhatsApp message
        message = client.messages.create(
            from_=TWILIO_WHATSAPP_FROM,
            body=message_body,
            to=f'whatsapp:{phone_number}'
        )
        
        print(f"WhatsApp OTP sent successfully. SID: {message.sid}")
        return True, "OTP sent successfully via WhatsApp"
        
    except Exception as e:
        print(f"Error sending WhatsApp OTP: {e}")
        return False, f"Failed to send OTP: {str(e)}"

# ============================================================================
# OTP FLOW HELPERS
# ============================================================================

def send_signup_otp(phone_number):
    """Generate and send OTP for signup"""
    otp = generate_otp()
    normalized_phone = store_otp(phone_number, otp, purpose='signup')
    success, message = send_whatsapp_otp(normalized_phone, otp, purpose='signup')
    return success, message, normalized_phone

def send_login_otp(phone_number):
    """Generate and send OTP for login"""
    otp = generate_otp()
    normalized_phone = store_otp(phone_number, otp, purpose='login')
    success, message = send_whatsapp_otp(normalized_phone, otp, purpose='login')
    return success, message, normalized_phone

def resend_otp(phone_number, purpose='login'):
    """Resend OTP (generates new one)"""
    otp = generate_otp()
    normalized_phone = store_otp(phone_number, otp, purpose=purpose)
    success, message = send_whatsapp_otp(normalized_phone, otp, purpose=purpose)
    return success, message, normalized_phone

# ============================================================================
# TESTING / DEVELOPMENT HELPERS
# ============================================================================

def get_test_otp(phone_number):
    """Get current OTP for testing (only in development)"""
    if os.getenv('DEBUG', 'false').lower() == 'true':
        phone_number = phone_number.strip().replace(' ', '')
        if not phone_number.startswith('+'):
            phone_number = '+' + phone_number
        
        otp_store = load_otp_store()
        if phone_number in otp_store:
            return otp_store[phone_number]['otp']
    return None

# ============================================================================
# SMS FALLBACK (Optional)
# ============================================================================

def send_sms_otp(phone_number, otp, purpose='login'):
    """Send OTP via SMS as fallback"""
    
    if not is_twilio_configured():
        print(f"TEST MODE - SMS OTP for {phone_number}: {otp}")
        return True, f"TEST MODE: Your OTP is {otp}"
    
    try:
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        
        message_body = f"Your Policy Engine verification code is: {otp}. Valid for {OTP_EXPIRY_MINUTES} minutes."
        
        message = client.messages.create(
            from_=os.getenv('TWILIO_PHONE_FROM', ''),
            body=message_body,
            to=phone_number
        )
        
        return True, "OTP sent successfully via SMS"
        
    except Exception as e:
        print(f"Error sending SMS OTP: {e}")
        return False, f"Failed to send SMS: {str(e)}"
