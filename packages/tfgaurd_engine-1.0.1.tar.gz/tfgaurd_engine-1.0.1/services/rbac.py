# rbac.py - Simplified Role-Based Access Control

from functools import wraps
from flask import session, g, jsonify
from core.models import UserRole
import logging

logger = logging.getLogger(__name__)

# Role permissions
ROLE_PERMISSIONS = {
    UserRole.ADMIN: {
        'create_user', 'read_user', 'update_user', 'delete_user', 'assign_role',
        'create_api_key', 'read_api_key', 'revoke_api_key', 'read_all_api_keys',
        'check_policy', 'bulk_check', 'read_check_history', 'read_all_check_history',
        'read_rules', 'create_rule', 'update_rule', 'delete_rule',
        'read_audit_logs', 'export_audit_logs', 'read_analytics', 'export_reports',
        'read_metrics', 'read_health', 'manage_system'
    },
    UserRole.DEVELOPER: {
        'read_user', 'create_api_key', 'read_api_key', 'revoke_api_key',
        'check_policy', 'bulk_check', 'read_check_history',
        'read_rules', 'create_rule', 'read_analytics',
    },
    UserRole.AUDITOR: {
        'read_user', 'read_api_key', 'read_check_history', 'read_all_check_history',
        'read_rules', 'read_audit_logs', 'export_audit_logs',
        'read_analytics', 'read_metrics', 'read_health',
    }
}

def has_permission(user_role, permission):
    if isinstance(user_role, str):
        try:
            user_role = UserRole(user_role)
        except ValueError:
            return False
    return permission in ROLE_PERMISSIONS.get(user_role, set())

def get_user_role():
    if hasattr(g, 'user_role'):
        return g.user_role
    # Try to get role from username
    if hasattr(g, 'username') and g.username:
        from core.database import get_db_session
        from core.models import User
        with get_db_session() as session:
            user = session.query(User).filter_by(username=g.username).first()
            if user:
                return user.role
    return None

def require_permission(permission):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            user_role = get_user_role()
            if not user_role or not has_permission(user_role, permission):
                return jsonify({'error': 'Forbidden', 'message': f'Permission required: {permission}'}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def require_role(*roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            user_role = get_user_role()
            allowed_roles = [UserRole(r) if isinstance(r, str) else r for r in roles]
            if not user_role or user_role not in allowed_roles:
                return jsonify({'error': 'Forbidden', 'message': 'Insufficient role'}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def admin_only(f):
    return require_role(UserRole.ADMIN)(f)

def init_rbac(app):
    @app.before_request
    def load_user_role():
        if 'username' in session:
            try:
                from core.database import get_db_session
                from core.models import User
                with get_db_session() as db:
                    user = db.query(User).filter_by(username=session['username']).first()
                    if user:
                        g.user = user
                        g.user_role = user.role
                        g.username = user.username
            except Exception as e:
                logger.error(f"Failed to load user role: {str(e)}")
    
    logger.info("RBAC initialized successfully")
