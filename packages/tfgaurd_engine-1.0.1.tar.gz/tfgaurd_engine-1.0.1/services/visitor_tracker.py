"""
Visitor Tracking Service — DB-backed
Tracks unique visitors and stores every page-view in the visitor_logs table.
"""

import logging
from datetime import datetime

from user_agents import parse

from core.database import get_db_session
from core.models import VisitorLog

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Seen-visitor cache (in-memory per-process) — avoids a DB read per request
# ---------------------------------------------------------------------------
_seen_visitor_ids: set = set()


def _get_ip(request_obj) -> str:
    """Extract real IP, honouring X-Forwarded-For."""
    xff = request_obj.environ.get("HTTP_X_FORWARDED_FOR")
    if xff:
        return xff.split(",")[0].strip()
    return request_obj.environ.get("REMOTE_ADDR", "unknown")


def _parse_ua(ua_string: str) -> dict:
    """Parse user-agent string into structured fields."""
    if not ua_string:
        return {}
    try:
        ua = parse(ua_string)
        return {
            "browser": f"{ua.browser.family} {ua.browser.version_string}".strip(),
            "os": f"{ua.os.family} {ua.os.version_string}".strip(),
            "device": ua.device.family,
            "is_mobile": ua.is_mobile,
            "is_tablet": ua.is_tablet,
            "is_pc": ua.is_pc,
            "is_bot": ua.is_bot,
        }
    except Exception:
        return {"browser": "Unknown", "os": "Unknown", "device": "Unknown",
                "is_mobile": False, "is_tablet": False, "is_pc": True, "is_bot": False}


def track_visit(request_obj, session_id: str | None = None):
    """
    Record a single page-view into visitor_logs.
    Call this from the before_request hook or individual routes.

    Returns True if this was a new unique visitor (IP+UA combo).
    """
    ip = _get_ip(request_obj)
    ua_raw = request_obj.headers.get("User-Agent", "")
    page_url = request_obj.path or "/"
    referer = request_obj.referrer or request_obj.headers.get("Referer")

    # Ignore health checks and wordpress vulnerability scanners
    page_url_lower = page_url.lower()
    if page_url_lower.startswith("/health") or "wp-" in page_url_lower or "wordpress" in page_url_lower:
        return False

    # Quick in-memory uniqueness check (resets on restart — good enough)
    visitor_key = f"{ip}:{hash(ua_raw[:80])}"
    is_new = visitor_key not in _seen_visitor_ids
    if is_new:
        _seen_visitor_ids.add(visitor_key)

    ua = _parse_ua(ua_raw)

    try:
        with get_db_session() as db:
            entry = VisitorLog(
                session_id=session_id,
                ip_address=ip,
                page_url=page_url[:500],
                referer=referer[:500] if referer else None,
                user_agent_raw=ua_raw[:500],
                browser=ua.get("browser", "Unknown")[:100],
                os=ua.get("os", "Unknown")[:100],
                device=ua.get("device", "Unknown")[:100],
                is_mobile=ua.get("is_mobile", False),
                is_tablet=ua.get("is_tablet", False),
                is_pc=ua.get("is_pc", True),
                is_bot=ua.get("is_bot", False),
                is_new_visitor=is_new,
                timestamp=datetime.utcnow(),
            )
            db.add(entry)
            db.commit()
    except Exception as e:
        logger.error(f"visitor_tracker.track_visit error: {e}")

    return is_new


def get_stats() -> dict:
    """Return total visits and unique visitor count from DB."""
    try:
        with get_db_session() as db:
            total = db.query(VisitorLog).count()
            unique = db.query(VisitorLog.ip_address).distinct().count()
            mob = db.query(VisitorLog).filter(
                (VisitorLog.is_mobile == True) | (VisitorLog.is_tablet == True)
            ).count()
            bot = db.query(VisitorLog).filter(VisitorLog.is_bot == True).count()
            return {
                "total_visits": total,
                "unique_visitors": unique,
                "mobile_visits": mob,
                "bot_visits": bot,
            }
    except Exception as e:
        logger.error(f"visitor_tracker.get_stats error: {e}")
        return {"total_visits": 0, "unique_visitors": 0, "mobile_visits": 0, "bot_visits": 0}


def get_visitor_stats_for_home() -> dict:
    """Lightweight stats used in the home page footer."""
    return get_stats()


# ── Legacy VisitorTracker shim ───────────────────────────────────────────────

class VisitorTracker:
    """Backward-compatible shim — routes all calls to the DB functions above."""

    def track_visitor(self, ip_address, user_agent=None, page_url="/", referer=None):
        from unittest.mock import MagicMock
        mock_req = MagicMock()
        mock_req.environ = {"REMOTE_ADDR": ip_address}
        mock_req.headers = {"User-Agent": user_agent or ""}
        mock_req.path = page_url
        mock_req.referrer = referer
        return track_visit(mock_req)

    def get_stats(self):
        return get_stats()

    def get_unique_count(self):
        return get_stats()["unique_visitors"]

    def get_recent_visits(self, limit=100):
        return _query_recent(limit=limit, page=1, per_page=limit)["items"]

    def get_visits_summary(self):
        return _get_summary()


_tracker = None


def get_visitor_tracker():
    """Get singleton VisitorTracker (legacy compatibility)."""
    global _tracker
    if _tracker is None:
        _tracker = VisitorTracker()
    return _tracker


# ── Admin query helpers ──────────────────────────────────────────────────────

def _query_recent(limit=50, page=1, per_page=50, page_filter=None, bot_filter=None,
                  device_filter=None, search=None):
    """
    Paginated query of visitor_logs.
    Returns { items: [...], total: int, pages: int }.
    """
    try:
        with get_db_session() as db:
            q = db.query(VisitorLog)

            if page_filter:
                q = q.filter(VisitorLog.page_url.ilike(f"%{page_filter}%"))
            if bot_filter == "human":
                q = q.filter(VisitorLog.is_bot == False)
            elif bot_filter == "bot":
                q = q.filter(VisitorLog.is_bot == True)
            if device_filter == "mobile":
                q = q.filter(VisitorLog.is_mobile == True)
            elif device_filter == "tablet":
                q = q.filter(VisitorLog.is_tablet == True)
            elif device_filter == "desktop":
                q = q.filter(VisitorLog.is_pc == True)
            if search:
                q = q.filter(VisitorLog.ip_address.ilike(f"%{search}%"))

            total = q.count()
            rows = (
                q.order_by(VisitorLog.timestamp.desc())
                .offset((page - 1) * per_page)
                .limit(per_page)
                .all()
            )
            items = [r.to_dict() for r in rows]
            pages = max(1, (total + per_page - 1) // per_page)
            return {"items": items, "total": total, "pages": pages, "page": page}
    except Exception as e:
        logger.error(f"visitor_tracker._query_recent error: {e}")
        return {"items": [], "total": 0, "pages": 1, "page": 1}


def _get_summary() -> dict:
    """Aggregate summary stats for the admin panel."""
    from sqlalchemy import func
    try:
        with get_db_session() as db:
            # Top browsers
            browsers = (
                db.query(VisitorLog.browser, func.count(VisitorLog.id).label("cnt"))
                .filter(VisitorLog.browser.isnot(None))
                .group_by(VisitorLog.browser)
                .order_by(func.count(VisitorLog.id).desc())
                .limit(6)
                .all()
            )
            # Top OS
            oss = (
                db.query(VisitorLog.os, func.count(VisitorLog.id).label("cnt"))
                .filter(VisitorLog.os.isnot(None))
                .group_by(VisitorLog.os)
                .order_by(func.count(VisitorLog.id).desc())
                .limit(6)
                .all()
            )
            # Top pages
            pages = (
                db.query(VisitorLog.page_url, func.count(VisitorLog.id).label("cnt"))
                .group_by(VisitorLog.page_url)
                .order_by(func.count(VisitorLog.id).desc())
                .limit(10)
                .all()
            )
            # Daily visits — last 14 days (today inclusive)
            # Bug fix: previously had no date filter, so LIMIT 14 returned the
            # *oldest* 14 distinct days ever recorded, not the most recent ones.
            from sqlalchemy import cast, Date
            from datetime import date, timedelta
            cutoff = date.today() - timedelta(days=13)  # 14 days including today
            daily = (
                db.query(
                    cast(VisitorLog.timestamp, Date).label("day"),
                    func.count(VisitorLog.id).label("cnt"),
                )
                .filter(cast(VisitorLog.timestamp, Date) >= cutoff)
                .group_by("day")
                .order_by("day")   # ascending so chart reads left → right (oldest to newest)
                .all()
            )
            mobile   = db.query(VisitorLog).filter(VisitorLog.is_mobile == True).count()
            tablet   = db.query(VisitorLog).filter(VisitorLog.is_tablet == True).count()
            desktop  = db.query(VisitorLog).filter(VisitorLog.is_pc == True).count()
            bot      = db.query(VisitorLog).filter(VisitorLog.is_bot == True).count()
            new_vis  = db.query(VisitorLog).filter(VisitorLog.is_new_visitor == True).count()

            return {
                "browsers": {r.browser: r.cnt for r in browsers},
                "operating_systems": {r.os: r.cnt for r in oss},
                "top_pages": {r.page_url: r.cnt for r in pages},
                "daily_visits": [{"day": str(r.day), "count": r.cnt} for r in daily],
                "mobile_visits": mobile,
                "tablet_visits": tablet,
                "desktop_visits": desktop,
                "bot_visits": bot,
                "new_visitors": new_vis,
            }
    except Exception as e:
        logger.error(f"visitor_tracker._get_summary error: {e}")
        return {}


def get_heatmap_data(page_url=None, limit=2000) -> list:
    """Return heatmap click events for a given page (or all pages)."""
    from core.models import ClickHeatmap
    try:
        with get_db_session() as db:
            q = db.query(ClickHeatmap)
            if page_url:
                q = q.filter(ClickHeatmap.page_url == page_url)
            rows = q.order_by(ClickHeatmap.timestamp.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]
    except Exception as e:
        logger.error(f"visitor_tracker.get_heatmap_data error: {e}")
        return []
