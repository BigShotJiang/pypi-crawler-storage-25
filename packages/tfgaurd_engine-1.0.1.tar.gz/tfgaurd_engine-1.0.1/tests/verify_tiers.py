"""Verify free vs premium tier rules."""
import sys, os
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils import parser
from utils.policy_checker import check_resources, get_severity
from utils.rules import RULE_REGISTRY_FREE, RULE_REGISTRY

# ── Rule counts ───────────────────────────────────────────────────────────────
cloud_prefixes = ('google_', 'azurerm_', 'oci_')
free_aws_types = [k for k in RULE_REGISTRY_FREE if not any(k.startswith(p) for p in cloud_prefixes)]
free_rules     = sum(len(RULE_REGISTRY_FREE[k]) for k in free_aws_types)
prem_types     = len(RULE_REGISTRY)
prem_rules     = sum(len(v) for v in RULE_REGISTRY.values())

print("=" * 64)
print("  Rule Registry Summary")
print("=" * 64)
print(f"  FREE  : {free_rules:3d} rules  across {len(free_aws_types):2d} core AWS resource types")
print(f"  PREMIUM: {prem_rules:3d} rule-slots across {prem_types:2d} resource types")
print()

# ── Scan the bad TF in both modes ─────────────────────────────────────────────
resources = parser.parse_terraform_file('tests/sample_bad.tf')
print(f"  Resources in sample_bad.tf: {len(resources)}")
print()

free_v    = check_resources(resources, has_subscription=False)
premium_v = check_resources(resources, has_subscription=True)

def split(violations):
    real   = [v for v in violations if not v['violation'].startswith('[RULE ERROR]') and not v['violation'].startswith('[PREMIUM]')]
    nudges = [v for v in violations if v['violation'].startswith('[PREMIUM]')]
    errors = [v for v in violations if v['violation'].startswith('[RULE ERROR]')]
    return real, nudges, errors

free_real, free_nudges, free_errors = split(free_v)
prem_real, _, prem_errors = split(premium_v)

print("  FREE USER SCAN:")
print(f"    Security violations : {len(free_real)}")
print(f"    Premium nudges shown: {len(free_nudges)}")
print(f"    Rule errors         : {len(free_errors)}")
print()
print("  PREMIUM USER SCAN:")
print(f"    Security violations : {len(prem_real)}")
print(f"    Rule errors         : {len(prem_errors)}")
print()

# ── Sample outputs ─────────────────────────────────────────────────────────────
print("-" * 64)
print("  Sample FREE violations (first 10):")
for v in free_real[:10]:
    print(f"    [{v['resource_type']}.{v['resource_name']}]")
    print(f"     -> {v['violation']}")
print()

print("  Sample PREMIUM nudges shown to free users:")
for v in free_nudges[:8]:
    print(f"    [{v['resource_type']}.{v['resource_name']}]")
    print(f"     -> {v['violation']}")
print()

print("  Sample PREMIUM-ONLY violations (not visible to free users):")
free_resource_pairs = {(v['resource_type'], v['resource_name'], v['violation']) for v in free_real}
prem_only = [v for v in prem_real
             if (v['resource_type'], v['resource_name'], v['violation']) not in free_resource_pairs]
for v in prem_only[:10]:
    print(f"    [{v['resource_type']}.{v['resource_name']}]")
    print(f"     -> {v['violation']}")

print("=" * 64)
