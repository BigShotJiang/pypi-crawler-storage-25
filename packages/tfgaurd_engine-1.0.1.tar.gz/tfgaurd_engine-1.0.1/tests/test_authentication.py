#!/usr/bin/env python3
"""
Test script to verify authentication and API functionality
Run this after starting the server to ensure everything works
"""

import requests
import sys

def test_health_check(base_url):
    """Test health endpoint (no auth required)"""
    print("Testing health check...")
    try:
        response = requests.get(f"{base_url}/health")
        if response.status_code == 200:
            print("✅ Health check passed")
            return True
        else:
            print(f"❌ Health check failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_version_endpoint(base_url):
    """Test version endpoint (no auth required)"""
    print("Testing version endpoint...")
    try:
        response = requests.get(f"{base_url}/api/version")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ API Version: {data.get('api_version')}")
            return True
        else:
            print(f"❌ Version check failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_api_without_key(base_url):
    """Test that API requires authentication"""
    print("Testing API without key (should fail)...")
    try:
        response = requests.get(f"{base_url}/api/stats")
        if response.status_code == 401:
            print("✅ API correctly requires authentication")
            return True
        else:
            print(f"❌ API should require auth but returned: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_api_with_key(base_url, api_key):
    """Test API with valid key"""
    print("Testing API with key...")
    try:
        headers = {"X-API-Key": api_key}
        response = requests.get(f"{base_url}/api/stats", headers=headers)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ API authenticated successfully")
            print(f"   Total rules: {data.get('total_rules')}")
            return True
        elif response.status_code == 401:
            print("❌ API key invalid or revoked")
            return False
        else:
            print(f"❌ Unexpected response: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_terraform_check(base_url, api_key):
    """Test Terraform checking"""
    print("Testing Terraform policy check...")
    
    terraform_code = '''
resource "aws_s3_bucket" "test" {
  bucket = "my-test-bucket"
  acl    = "private"
}
'''
    
    try:
        headers = {
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        }
        
        payload = {
            "code": terraform_code,
            "filename": "test.tf"
        }
        
        response = requests.post(f"{base_url}/api/check", json=payload, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Terraform check successful")
            print(f"   Resources: {data.get('resource_count')}")
            print(f"   Violations: {data.get('violation_count')}")
            print(f"   Passed: {data.get('passed')}")
            return True
        else:
            print(f"❌ Check failed: {response.status_code}")
            print(f"   Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def main():
    """Run all tests"""
    print("="*70)
    print("Policy Engine Authentication & API Test")
    print("="*70)
    print()
    
    # Configuration
    base_url = "http://localhost:5000"
    
    print(f"Server: {base_url}")
    print()
    
    # Run tests that don't require auth
    all_passed = True
    
    if not test_health_check(base_url):
        all_passed = False
    print()
    
    if not test_version_endpoint(base_url):
        all_passed = False
    print()
    
    if not test_api_without_key(base_url):
        all_passed = False
    print()
    
    # Tests that require API key
    api_key = input("Enter your API key (or press Enter to skip authenticated tests): ").strip()
    
    if api_key:
        print()
        if not test_api_with_key(base_url, api_key):
            all_passed = False
        print()
        
        if not test_terraform_check(base_url, api_key):
            all_passed = False
        print()
    else:
        print("\n⚠️  Skipping authenticated tests (no API key provided)")
        print("\nTo test with authentication:")
        print("1. Login to http://localhost:5000")
        print("2. Go to Profile and generate an API key")
        print("3. Run this test again with the key")
        print()
    
    # Summary
    print("="*70)
    if all_passed:
        print("✅ All tests passed!")
    else:
        print("❌ Some tests failed")
    print("="*70)
    
    return 0 if all_passed else 1

if __name__ == '__main__':
    sys.exit(main())
