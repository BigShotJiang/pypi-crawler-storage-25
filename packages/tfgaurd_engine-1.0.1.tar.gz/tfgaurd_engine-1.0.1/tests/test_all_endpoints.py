#!/usr/bin/env python3
"""
Comprehensive endpoint testing script for Policy Engine
Tests all web pages and API endpoints for errors
"""

import requests
import json
import sys
from datetime import datetime

BASE_URL = "http://127.0.0.1:5000"

# Color codes for output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
RESET = '\033[0m'

def print_header(text):
    print(f"\n{BLUE}{'='*60}{RESET}")
    print(f"{BLUE}{text}{RESET}")
    print(f"{BLUE}{'='*60}{RESET}")

def print_success(text):
    print(f"{GREEN}[OK] {text}{RESET}")

def print_error(text):
    print(f"{RED}[FAIL] {text}{RESET}")

def print_warning(text):
    print(f"{YELLOW}[WARN] {text}{RESET}")

def test_public_endpoints():
    """Test endpoints that don't require authentication"""
    print_header("Testing Public Endpoints")
    
    endpoints = [
        ("/health", "GET", "Health Check"),
        ("/api/version", "GET", "API Version"),
        ("/login", "GET", "Login Page"),
        ("/signup", "GET", "Signup Page"),
    ]
    
    results = []
    for endpoint, method, description in endpoints:
        try:
            url = f"{BASE_URL}{endpoint}"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                print_success(f"{description} ({endpoint}): {response.status_code}")
                results.append((endpoint, True, response.status_code, None))
            else:
                print_error(f"{description} ({endpoint}): {response.status_code}")
                results.append((endpoint, False, response.status_code, None))
        except Exception as e:
            print_error(f"{description} ({endpoint}): {str(e)}")
            results.append((endpoint, False, None, str(e)))
    
    return results

def test_api_endpoints_without_auth():
    """Test API endpoints without authentication (should fail with 401)"""
    print_header("Testing API Endpoints Without Authentication")
    
    endpoints = [
        ("/api/policies", "GET", "Get Policies"),
        ("/api/rules", "GET", "Get Rules"),
        ("/api/stats", "GET", "Get Stats"),
        ("/api/history", "GET", "Get History"),
        ("/api/check", "POST", "Check Terraform"),
    ]
    
    results = []
    for endpoint, method, description in endpoints:
        try:
            url = f"{BASE_URL}{endpoint}"
            if method == "GET":
                response = requests.get(url, timeout=5)
            else:
                response = requests.post(url, json={}, timeout=5)
            
            # These should return 401 Unauthorized
            if response.status_code == 401:
                print_success(f"{description} ({endpoint}): Correctly returns 401 (Unauthorized)")
                results.append((endpoint, True, 401, None))
            else:
                print_warning(f"{description} ({endpoint}): Expected 401, got {response.status_code}")
                results.append((endpoint, False, response.status_code, "Expected 401"))
        except Exception as e:
            print_error(f"{description} ({endpoint}): {str(e)}")
            results.append((endpoint, False, None, str(e)))
    
    return results

def test_api_endpoints_with_auth():
    """Test API endpoints with valid authentication"""
    print_header("Testing API Endpoints With Authentication")
    
    # First, we need to get an API key from the api_keys.json file
    try:
        with open('api_keys.json', 'r', encoding='utf-8') as f:
            api_keys_data = json.load(f)
            if api_keys_data and len(api_keys_data) > 0:
                # Get the first API key
                first_key = list(api_keys_data.keys())[0]
                api_key = first_key
                print_success(f"Using API key: {api_key[:20]}...")
            else:
                print_error("No API keys found in api_keys.json")
                return []
    except Exception as e:
        print_error(f"Failed to load API key: {str(e)}")
        return []
    
    headers = {"X-API-Key": api_key}
    
    endpoints = [
        ("/api/policies", "GET", "Get Policies", None),
        ("/api/rules", "GET", "Get Rules", None),
        ("/api/stats", "GET", "Get Stats", None),
        ("/api/history", "GET", "Get History", None),
        ("/api/check", "POST", "Check Terraform", {
            "code": 'resource "aws_s3_bucket" "test" { bucket = "test-bucket" }',
            "filename": "test.tf"
        }),
    ]
    
    results = []
    for endpoint, method, description, data in endpoints:
        try:
            url = f"{BASE_URL}{endpoint}"
            if method == "GET":
                response = requests.get(url, headers=headers, timeout=5)
            else:
                response = requests.post(url, headers=headers, json=data, timeout=5)
            
            if response.status_code == 200:
                print_success(f"{description} ({endpoint}): {response.status_code}")
                # Print response preview
                try:
                    resp_json = response.json()
                    if isinstance(resp_json, dict):
                        keys = list(resp_json.keys())[:3]
                        print(f"  Response keys: {keys}")
                except:
                    pass
                results.append((endpoint, True, response.status_code, None))
            else:
                print_error(f"{description} ({endpoint}): {response.status_code}")
                print(f"  Response: {response.text[:200]}")
                results.append((endpoint, False, response.status_code, response.text[:200]))
        except Exception as e:
            print_error(f"{description} ({endpoint}): {str(e)}")
            results.append((endpoint, False, None, str(e)))
    
    return results

def test_protected_pages_without_auth():
    """Test protected pages without authentication (should redirect to login)"""
    print_header("Testing Protected Pages Without Authentication")
    
    endpoints = [
        ("/", "Dashboard"),
        ("/check", "Check Page"),
        ("/rules", "Rules Page"),
        ("/profile", "Profile Page"),
    ]
    
    results = []
    for endpoint, description in endpoints:
        try:
            url = f"{BASE_URL}{endpoint}"
            response = requests.get(url, allow_redirects=False, timeout=5)
            
            # Should redirect to login (302) or return 401
            if response.status_code in [302, 401]:
                print_success(f"{description} ({endpoint}): Correctly protected ({response.status_code})")
                if response.status_code == 302:
                    redirect_location = response.headers.get('Location', '')
                    if 'login' in redirect_location:
                        print(f"  Redirects to: {redirect_location}")
                results.append((endpoint, True, response.status_code, None))
            else:
                print_warning(f"{description} ({endpoint}): Expected 302/401, got {response.status_code}")
                results.append((endpoint, False, response.status_code, "Expected redirect"))
        except Exception as e:
            print_error(f"{description} ({endpoint}): {str(e)}")
            results.append((endpoint, False, None, str(e)))
    
    return results

def print_summary(all_results):
    """Print test summary"""
    print_header("Test Summary")
    
    total = len(all_results)
    passed = sum(1 for _, success, _, _ in all_results if success)
    failed = total - passed
    
    print(f"\nTotal Tests: {total}")
    print_success(f"Passed: {passed}")
    if failed > 0:
        print_error(f"Failed: {failed}")
    else:
        print_success(f"Failed: {failed}")
    
    if failed > 0:
        print("\nFailed Tests:")
        for endpoint, success, status, error in all_results:
            if not success:
                print_error(f"  {endpoint}: Status={status}, Error={error}")
    
    return failed == 0

def main():
    print(f"\n{BLUE}Policy Engine - Comprehensive Endpoint Testing{RESET}")
    print(f"{BLUE}Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{RESET}")
    
    all_results = []
    
    # Run all tests
    all_results.extend(test_public_endpoints())
    all_results.extend(test_protected_pages_without_auth())
    all_results.extend(test_api_endpoints_without_auth())
    all_results.extend(test_api_endpoints_with_auth())
    
    # Print summary
    success = print_summary(all_results)
    
    print(f"\n{BLUE}Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{RESET}\n")
    
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
