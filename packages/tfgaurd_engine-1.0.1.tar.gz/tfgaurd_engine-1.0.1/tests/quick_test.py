"""Quick smoke test - run directly with: python tests/quick_test.py"""
import sys, os, traceback
sys.stdout.reconfigure(encoding='utf-8')   # force UTF-8 output on Windows
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils import parser
from utils.policy_checker import check_resources, get_severity

CASES = {
    "bad_infra": """
resource "aws_s3_bucket" "bad" {
  bucket = "my-public-bucket"
  acl    = "public-read-write"
}
resource "aws_instance" "bad_ec2" {
  ami                         = "ami-abc123"
  instance_type               = "t2.micro"
  associate_public_ip_address = true
  key_name                    = "old-ssh-key"
}
resource "aws_security_group" "wide_open" {
  name        = "wide-open-sg"
  description = "Managed by Terraform"
  ingress {
    from_port   = 0
    to_port     = 65535
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
resource "aws_db_instance" "bad_rds" {
  engine                  = "mysql"
  engine_version          = "5.6.40"
  instance_class          = "db.t3.micro"
  username                = "admin"
  password                = "Secret123!"
  publicly_accessible     = true
  storage_encrypted       = false
  backup_retention_period = 0
  skip_final_snapshot     = true
  deletion_protection     = false
}
resource "aws_iam_policy" "admin" {
  name   = "AdminPolicy"
  policy = "{\"Version\":\"2012-10-17\",\"Statement\":[{\"Effect\":\"Allow\",\"Action\":\"*\",\"Resource\":\"*\"}]}"
}
resource "aws_lambda_function" "bad_fn" {
  function_name = "my-fn"
  role          = "arn:aws:iam::123:role/r"
  runtime       = "nodejs10.x"
  handler       = "index.handler"
  timeout       = 900
}
resource "aws_kms_key" "no_rot" {
  description             = ""
  enable_key_rotation     = false
  deletion_window_in_days = 7
}
resource "aws_cloudtrail" "bad_trail" {
  name                          = "my-trail"
  s3_bucket_name                = "trail-bucket"
  enable_log_file_validation    = false
  is_multi_region_trail         = false
  include_global_service_events = false
}
resource "aws_elasticsearch_domain" "bad_es" {
  domain_name           = "bad-es"
  elasticsearch_version = "7.10"
}
resource "aws_sqs_queue" "unencrypted" {
  name = "my-queue"
}
resource "aws_sns_topic" "unencrypted" {
  name = "my-topic"
}
resource "aws_dynamodb_table" "bad_table" {
  name           = "bad-table"
  billing_mode   = "PROVISIONED"
  read_capacity  = 0
  write_capacity = 0
  hash_key       = "id"
  attribute {
    name = "id"
    type = "S"
  }
}
resource "aws_ecr_repository" "mutable" {
  name                 = "my-repo"
  image_tag_mutability = "MUTABLE"
}
resource "aws_eks_cluster" "public_cluster" {
  name     = "my-cluster"
  role_arn = "arn:aws:iam::123:role/EKS"
  vpc_config {
    subnet_ids              = ["subnet-1"]
    endpoint_public_access  = true
    public_access_cidrs     = ["0.0.0.0/0"]
  }
}
resource "aws_cloudfront_distribution" "no_waf" {
  origin {
    domain_name = "example.com"
    origin_id   = "myOrigin"
  }
  enabled = true
  default_cache_behavior {
    viewer_protocol_policy = "allow-all"
    target_origin_id       = "myOrigin"
    forwarded_values {
      query_string = false
      cookies { forward = "none" }
    }
    allowed_methods = ["GET","HEAD"]
    cached_methods  = ["GET","HEAD"]
  }
  restrictions {
    geo_restriction {
      restriction_type = "none"
    }
  }
  viewer_certificate {
    cloudfront_default_certificate = true
  }
}
""",
    "good_infra": """
resource "aws_s3_bucket" "secure" {
  bucket = "my-secure-bucket"
  tags   = { Environment = "prod", Owner = "platform" }
}
resource "aws_s3_bucket_versioning" "v" {
  bucket = aws_s3_bucket.secure.id
  versioning_configuration { status = "Enabled" }
}
resource "aws_kms_key" "good" {
  description             = "Production KMS key for S3"
  enable_key_rotation     = true
  deletion_window_in_days = 30
  tags                    = { Environment = "prod" }
}
resource "aws_instance" "hardened" {
  ami                     = "ami-abc123"
  instance_type           = "t3.medium"
  monitoring              = true
  ebs_optimized           = true
  iam_instance_profile    = "EC2-SSM-Profile"
  disable_api_termination = true
  tags                    = { Name = "prod-app", Environment = "prod" }
  metadata_options {
    http_tokens = "required"
  }
  root_block_device {
    encrypted = true
    kms_key_id = "arn:aws:kms:us-east-1:123:key/abc"
  }
}
resource "aws_security_group" "strict" {
  name        = "strict-sg"
  description = "Only HTTPS from corporate network"
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/8"]
  }
  egress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = { Name = "strict", Environment = "prod" }
}
""",
}

SEV_ICON = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}

print("\n" + "="*70)
print("  TFGuard — Policy Engine Integration Test")
print("="*70)

grand = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}

for name, tf_code in CASES.items():
    print(f"\n{'─'*70}")
    print(f"📄  Case: {name}")
    try:
        resources = parser.parse_terraform_file(tf_code)
        violations = check_resources(resources, has_subscription=True)
        by_sev = {}
        for v in violations:
            sev = get_severity(v["violation"])
            by_sev.setdefault(sev, []).append(v)
            grand[sev] += 1

        print(f"   Resources parsed : {len(resources)}")
        print(f"   Total violations : {len(violations)}")
        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            items = by_sev.get(sev, [])
            if not items:
                continue
            print(f"\n   {SEV_ICON[sev]} {sev} ({len(items)})")
            for v in items:
                print(f"      [{v['resource_type']}.{v['resource_name']}]")
                print(f"       → {v['violation']}")
    except Exception:
        traceback.print_exc()

print(f"\n{'='*70}")
print("  GRAND TOTAL")
print(f"{'='*70}")
for sev, icon in SEV_ICON.items():
    print(f"  {icon} {sev:8s}: {grand[sev]}")
print()
