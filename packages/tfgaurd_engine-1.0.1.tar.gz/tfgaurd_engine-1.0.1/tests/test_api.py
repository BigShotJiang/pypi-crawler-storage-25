#!/usr/bin/env python3
"""Test the policy-engine API"""

import requests
import json

BASE_URL = "http://127.0.0.1:5000"

def test_get_policies():
    """Test GET /api/policies endpoint"""
    print("\n=== Testing GET /api/policies ===")
    response = requests.get(f"{BASE_URL}/api/policies")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    return response.status_code == 200

def test_check_terraform():
    """Test POST /api/check endpoint"""
    print("\n=== Testing POST /api/check ===")
    
    # Test with public S3 bucket (should have violations)
    terraform_code = '''
resource "aws_s3_bucket" "test_bucket" {
  bucket = "my-test-bucket"
  acl    = "public-read"
}
'''
    
    response = requests.post(
        f"{BASE_URL}/api/check",
        json={"code": terraform_code},
        headers={"Content-Type": "application/json"}
    )
    
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    return response.status_code == 200

def test_check_terraform_secure():
    """Test POST /api/check with secure bucket"""
    print("\n=== Testing POST /api/check with secure config ===")
    
    # Test with private S3 bucket (should pass)
    terraform_code = '''
resource "aws_s3_bucket" "secure_bucket" {
  bucket = "my-secure-bucket"
  acl    = "private"
  block_public_acls = true
}
'''
    
    response = requests.post(
        f"{BASE_URL}/api/check",
        json={"code": terraform_code},
        headers={"Content-Type": "application/json"}
    )
    
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    return response.status_code == 200

if __name__ == "__main__":
    print("Testing Policy Engine API...")
    print("=" * 50)
    
    try:
        test1 = test_get_policies()
        test2 = test_check_terraform()
        test3 = test_check_terraform_secure()
        
        print("\n" + "=" * 50)
        print(f"Test Results:")
        print(f"  GET /api/policies: {'✓ PASS' if test1 else '✗ FAIL'}")
        print(f"  POST /api/check (insecure): {'✓ PASS' if test2 else '✗ FAIL'}")
        print(f"  POST /api/check (secure): {'✓ PASS' if test3 else '✗ FAIL'}")
        
        if all([test1, test2, test3]):
            print("\n✓ All tests passed!")
        else:
            print("\n✗ Some tests failed")
            
    except requests.exceptions.ConnectionError:
        print("\n✗ ERROR: Could not connect to the API server.")
        print("Make sure the Flask app is running: python app.py")
    except Exception as e:
        print(f"\n✗ ERROR: {e}")
