"""
Real-world Terraform integration test.
Downloads well-known public TF configurations from GitHub and
runs the full policy rule registry against them.
"""

import sys
import os
import requests

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils import parser
from utils.policy_checker import check_resources, get_severity

# ---------------------------------------------------------------------------
# Raw TF files from public GitHub repos (intentionally misconfigured examples
# plus real-world examples that will show realistic findings)
# ---------------------------------------------------------------------------
SOURCES = [
    {
        "name": "Badly configured S3 + EC2 (terraform-aws-modules examples)",
        "url": "https://raw.githubusercontent.com/antonbabenko/terraform-aws-devops/master/terraform-aws-s3-bucket/examples/complete/main.tf",
    },
    {
        "name": "AWS VPC + Subnets (terraform-aws-vpc example)",
        "url": "https://raw.githubusercontent.com/terraform-aws-modules/terraform-aws-vpc/master/examples/simple/main.tf",
    },
    {
        "name": "AWS EKS cluster (terraform-aws-eks example)",
        "url": "https://raw.githubusercontent.com/terraform-aws-modules/terraform-aws-eks/master/examples/complete/main.tf",
    },
    {
        "name": "AWS RDS / Aurora example",
        "url": "https://raw.githubusercontent.com/terraform-aws-modules/terraform-aws-rds/master/examples/complete-postgres/main.tf",
    },
    {
        "name": "AWS Security Groups open example",
        "url": "https://raw.githubusercontent.com/terraform-aws-modules/terraform-aws-security-group/master/examples/complete/main.tf",
    },
    {
        "name": "AWS Lambda example",
        "url": "https://raw.githubusercontent.com/terraform-aws-modules/terraform-aws-lambda/master/examples/complete/main.tf",
    },
    {
        "name": "AWS CloudFront + WAF",
        "url": "https://raw.githubusercontent.com/terraform-aws-modules/terraform-aws-cloudfront/master/examples/complete/main.tf",
    },
    {
        "name": "AWS ALB / Load Balancer",
        "url": "https://raw.githubusercontent.com/terraform-aws-modules/terraform-aws-alb/master/examples/complete-alb/main.tf",
    },
]

# Fallback inline TF configs to guarantee coverage when URLs fail
FALLBACK_TF = {
    "Inline: Intentionally misconfigured AWS example": """
resource "aws_s3_bucket" "bad_example" {
  bucket = "my-totally-public-bucket"
  acl    = "public-read-write"
}

resource "aws_instance" "bad_ec2" {
  ami                         = "ami-12345678"
  instance_type               = "t2.micro"
  associate_public_ip_address = true
  monitoring                  = false
  key_name                    = "my-old-ssh-key"
}

resource "aws_security_group" "wide_open" {
  name        = "wide-open-sg"
  description = "Managed by Terraform"

  ingress {
    from_port   = 0
    to_port     = 65535
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_db_instance" "bad_rds" {
  engine               = "mysql"
  engine_version       = "5.6.40"
  instance_class       = "db.t3.micro"
  name                 = "mydb"
  username             = "admin"
  password             = "SuperSecretPassword123!"
  publicly_accessible  = true
  storage_encrypted    = false
  backup_retention_period = 0
  skip_final_snapshot  = true
}

resource "aws_iam_policy" "too_permissive" {
  name = "TooPermissive"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "*"
      Resource = "*"
    }]
  })
}

resource "aws_lambda_function" "bad_lambda" {
  function_name = "bad-function"
  role          = "arn:aws:iam::123456789:role/LambdaRole"
  handler       = "index.handler"
  runtime       = "nodejs10.x"
  timeout       = 900
}

resource "aws_kms_key" "no_rotation" {
  description             = ""
  enable_key_rotation     = false
  deletion_window_in_days = 7
}

resource "aws_cloudtrail" "no_encryption" {
  name                          = "my-trail"
  s3_bucket_name                = "my-trail-bucket"
  enable_log_file_validation    = false
  is_multi_region_trail         = false
  include_global_service_events = false
}

resource "aws_elasticsearch_domain" "bad_es" {
  domain_name           = "bad-es"
  elasticsearch_version = "7.10"
}

resource "aws_sqs_queue" "no_encryption" {
  name = "my-queue"
}

resource "aws_sns_topic" "no_encryption" {
  name = "my-topic"
}

resource "aws_dynamodb_table" "bad_table" {
  name         = "bad-table"
  billing_mode = "PROVISIONED"
  read_capacity  = 0
  write_capacity = 0
  hash_key     = "id"
  attribute {
    name = "id"
    type = "S"
  }
}

resource "aws_ecr_repository" "bad_ecr" {
  name = "my-images"
  image_tag_mutability = "MUTABLE"
}

resource "aws_eks_cluster" "bad_eks" {
  name = "bad-cluster"
  role_arn = "arn:aws:iam::123456789:role/EKSRole"
  vpc_config {
    subnet_ids = ["subnet-123"]
    endpoint_public_access = true
    public_access_cidrs    = ["0.0.0.0/0"]
  }
}
""",
    "Inline: Well-configured reference (fewer findings expected)": """
resource "aws_s3_bucket" "good_bucket" {
  bucket = "my-secure-bucket"
}

resource "aws_s3_bucket_versioning" "good" {
  bucket = aws_s3_bucket.good_bucket.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "good" {
  bucket = aws_s3_bucket.good_bucket.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = "arn:aws:kms:us-east-1:123456789:key/abc"
    }
    bucket_key_enabled = true
  }
}

resource "aws_instance" "good_ec2" {
  ami           = "ami-12345678"
  instance_type = "t3.medium"
  monitoring    = true
  ebs_optimized = true
  iam_instance_profile = "MyInstanceProfile"
  disable_api_termination = true

  metadata_options {
    http_tokens = "required"
  }

  root_block_device {
    encrypted = true
  }
}

resource "aws_security_group" "strict_sg" {
  name        = "strict-sg"
  description = "Only allow HTTPS inbound from corporate network"

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/8"]
  }

  egress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_kms_key" "good_key" {
  description         = "Production encryption key for S3 and RDS"
  enable_key_rotation = true
  deletion_window_in_days = 30
  tags = { Environment = "production" }
}
""",
}

# ANSI colors
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
GREEN  = "\033[92m"
BOLD   = "\033[1m"
RESET  = "\033[0m"
DIM    = "\033[2m"

SEV_COLOR = {"CRITICAL": RED, "HIGH": YELLOW, "MEDIUM": CYAN, "LOW": GREEN}

def fetch_tf(url: str) -> str | None:
    try:
        r = requests.get(url, timeout=10, headers={"User-Agent": "TFGuard-test/1.0"})
        if r.status_code == 200:
            return r.text
    except Exception as e:
        print(f"  {DIM}fetch error: {e}{RESET}")
    return None

def run_check(name: str, tf_code: str) -> dict:
    try:
        resources = parser.parse_terraform_file(tf_code)
    except Exception as e:
        return {"name": name, "error": str(e), "resources": 0, "violations": []}

    violations = check_resources(resources, has_subscription=True)
    by_sev = {"CRITICAL": [], "HIGH": [], "MEDIUM": [], "LOW": []}
    for v in violations:
        sev = get_severity(v["violation"])
        by_sev[sev].append(v)

    return {
        "name": name,
        "error": None,
        "resources": len(resources),
        "violations": violations,
        "by_sev": by_sev,
    }

def print_report(result: dict):
    name  = result["name"]
    print(f"\n{BOLD}{'─'*72}{RESET}")
    print(f"{BOLD}📁  {name}{RESET}")

    if result.get("error"):
        print(f"  {RED}⚠  Parse error: {result['error']}{RESET}")
        return

    total = len(result["violations"])
    rsrc  = result["resources"]
    by_sev = result.get("by_sev", {})

    c = len(by_sev.get("CRITICAL", []))
    h = len(by_sev.get("HIGH", []))
    m = len(by_sev.get("MEDIUM", []))
    l = len(by_sev.get("LOW", []))

    print(f"  Resources parsed : {BOLD}{rsrc}{RESET}")
    print(f"  Total violations : {BOLD}{total}{RESET}  "
          f"({RED}CRITICAL:{c}{RESET}  {YELLOW}HIGH:{h}{RESET}  "
          f"{CYAN}MEDIUM:{m}{RESET}  {GREEN}LOW:{l}{RESET})")

    for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
        items = by_sev.get(sev, [])
        if not items:
            continue
        color = SEV_COLOR[sev]
        print(f"\n  {color}{BOLD}[{sev}] — {len(items)} findings{RESET}")
        for v in items:
            rtype = v["resource_type"]
            rname = v["resource_name"]
            msg   = v["violation"]
            print(f"    {color}●{RESET} {BOLD}{rtype}.{rname}{RESET}")
            print(f"      {DIM}{msg}{RESET}")

def main():
    print(f"\n{BOLD}{'='*72}")
    print("  TFGuard — Real-world Terraform Policy Check")
    print(f"{'='*72}{RESET}\n")

    results = []

    # 1. Try fetching from internet
    for src in SOURCES:
        print(f"⬇  Fetching: {DIM}{src['url'][:70]}...{RESET}")
        tf_code = fetch_tf(src["url"])
        if tf_code:
            print(f"   {GREEN}✓ Downloaded ({len(tf_code):,} bytes){RESET}")
            result = run_check(src["name"], tf_code)
            results.append(result)
        else:
            print(f"   {YELLOW}⚠ Skipped (unreachable){RESET}")

    # 2. Always run fallback inline examples
    print(f"\n{DIM}── Running inline Terraform examples ──{RESET}")
    for name, tf_code in FALLBACK_TF.items():
        result = run_check(name, tf_code)
        results.append(result)

    # Print all reports
    for result in results:
        print_report(result)

    # Final summary
    grand_total   = sum(len(r.get("violations", [])) for r in results)
    grand_crit    = sum(len(r.get("by_sev", {}).get("CRITICAL", [])) for r in results)
    grand_high    = sum(len(r.get("by_sev", {}).get("HIGH", [])) for r in results)
    grand_medium  = sum(len(r.get("by_sev", {}).get("MEDIUM", [])) for r in results)
    grand_low     = sum(len(r.get("by_sev", {}).get("LOW", [])) for r in results)
    grand_errors  = sum(1 for r in results if r.get("error"))

    print(f"\n{BOLD}{'='*72}")
    print("  GRAND TOTAL SUMMARY")
    print(f"{'='*72}{RESET}")
    print(f"  Files tested     : {len(results)}")
    print(f"  Parse errors     : {RED}{grand_errors}{RESET}")
    print(f"  Total violations : {BOLD}{grand_total}{RESET}")
    print(f"  {RED}CRITICAL : {grand_crit}{RESET}")
    print(f"  {YELLOW}HIGH     : {grand_high}{RESET}")
    print(f"  {CYAN}MEDIUM   : {grand_medium}{RESET}")
    print(f"  {GREEN}LOW      : {grand_low}{RESET}")

if __name__ == "__main__":
    main()
