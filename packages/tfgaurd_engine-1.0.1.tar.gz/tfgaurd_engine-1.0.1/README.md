# TFGaurd 🛡️

**The Terraform Security Scanner that Respects Your Code.**

TFGaurd is a **Privacy-First, Local-First** security engine for Terraform. Unlike traditional SaaS scanners, TFGaurd ensures your sensitive Infrastructure-as-Code (HCL) **never leaves your machine or CI/CD runner**. 

By running the core engine locally and syncing only high-level metadata (violation counts) to your cloud dashboard, you get enterprise-grade security observability with **zero privacy trade-offs**.

---

## 🚀 Quick Start (1-Minute)

### 1. Install via Pip
TFGuard requires Python 3.8+ and installs as a standalone CLI.
```bash
pip install tfguard
```

### 2. Run an Anonymous Local Scan
Scan your current directory immediately. This uses our free-tier AWS security engine. No account or data-sync required.
```bash
tfguard scan .
```

### 3. Unlock 1,200+ Premium Rules (GCP, Azure, OCI)
Provide your API key to download the **Secure In-Memory Rule Bundle** (~700+ proprietary rules) and sync metadata to your [TFGuard Dashboard](https://tfgaurd.com).
```bash
export TFGUARD_API_KEY="your_key_here"
tfguard scan .
```

---

## 🔒 Our Privacy Guarantee

1. **Local-Only Parsing**: Your raw HCL code is parsed and analysed on your local machine. We never see your variable values, architecture, or credentials.
2. **Metadata-Only Ingestion**: Cloud sync is strictly limited to high-level results (e.g., "3 CRITICAL violations found"). 
3. **Secure In-Memory Rule Streaming**: Premium rules are delivered as an encrypted blob that is decrypted in RAM and executed in an isolated namespace. **Rule logic is never written to disk.**

---

## 🔄 CI/CD Integration

Integrate TFGuard into your automated pipelines in seconds.

### GitHub Actions Example
```yaml
name: Security Scan
on: [push]
jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: pip install tfguard
      - run: tfguard scan . --fail-on CRITICAL
        env:
          TFGUARD_API_KEY: ${{ secrets.TFGUARD_API_KEY }}
```

---

## ✨ Features

- **1,200+ Security Rules**: Comprehensive coverage for AWS, Azure, GCP, and OCI.
- **Portability**: A 50KB zero-dependency CLI that runs anywhere (Laptop, CI/CD, Air-gapped VPCs).
- **Sub-Second Performance**: Instant security feedback for small to medium environments.
- **Metadata Sync**: Track your security posture trends on [tfgaurd.com](https://tfgaurd.com) without exposing source code.

---

## 📜 License
TFGuard is licensed under the MIT License. See [LICENSE](LICENSE) for details.

---

**Built with ❤️ by the TFGuard Team.**
[View Project Website](https://tfgaurd.com) | [Read Documentation](https://tfgaurd.com/docs)
