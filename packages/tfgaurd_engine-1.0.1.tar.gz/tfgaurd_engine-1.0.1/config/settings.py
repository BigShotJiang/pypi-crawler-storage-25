"""
Centralized Configuration Management
All application settings in one place
"""

import os
from pathlib import Path

# Base directory
BASE_DIR = Path(__file__).parent.parent

# Environment
ENV = os.getenv('FLASK_ENV', 'development')
DEBUG = os.getenv('DEBUG', 'true').lower() == 'true'

# Server
HOST = os.getenv('HOST', '0.0.0.0')
PORT = int(os.getenv('PORT', 5000))

# Security
SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
WTF_CSRF_SECRET_KEY = os.getenv('WTF_CSRF_SECRET_KEY', SECRET_KEY)

# Database
DATABASE_DIR = BASE_DIR / 'data'
DATABASE_PATH = DATABASE_DIR / 'policy_engine.db'
DATABASE_URL = os.getenv('DATABASE_URL', f'sqlite:///{DATABASE_PATH}')

# Data Files
DATA_DIR = BASE_DIR / 'data'
API_KEYS_FILE = DATA_DIR / 'api_keys.json'
USERS_FILE = DATA_DIR / 'users.json'
OTP_STORE_FILE = DATA_DIR / 'otp_store.json'

# Logging
LOG_DIR = BASE_DIR / 'logs'
LOG_FILE = LOG_DIR / 'app.log'
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
LOG_MAX_SIZE = int(os.getenv('LOG_MAX_SIZE', 5 * 1024 * 1024))  # 5MB
LOG_BACKUP_COUNT = int(os.getenv('LOG_BACKUP_COUNT', 3))

# Session
SESSION_TYPE = 'filesystem'
SESSION_PERMANENT = False
PERMANENT_SESSION_LIFETIME = int(os.getenv('SESSION_LIFETIME', 3600))  # 1 hour

# Rate Limiting
RATE_LIMIT_ENABLED = os.getenv('RATE_LIMIT_ENABLED', 'true').lower() == 'true'
RATE_LIMIT_STORAGE_URL = os.getenv('RATE_LIMIT_STORAGE_URL', 'memory://')

# WhatsApp OTP
WHATSAPP_API_URL = os.getenv('WHATSAPP_API_URL', 'https://graph.facebook.com/v17.0')
WHATSAPP_PHONE_ID = os.getenv('WHATSAPP_PHONE_ID', '')
WHATSAPP_TOKEN = os.getenv('WHATSAPP_TOKEN', '')
OTP_EXPIRY_MINUTES = int(os.getenv('OTP_EXPIRY_MINUTES', 5))
OTP_LENGTH = int(os.getenv('OTP_LENGTH', 6))

# Google OAuth
GOOGLE_CLIENT_ID = os.getenv('GOOGLE_CLIENT_ID', '')
GOOGLE_CLIENT_SECRET = os.getenv('GOOGLE_CLIENT_SECRET', '')
GOOGLE_DISCOVERY_URL = "https://accounts.google.com/.well-known/openid-configuration"
GOOGLE_REDIRECT_URI = os.getenv('GOOGLE_REDIRECT_URI', '')  # e.g. https://tfgaurd.com/login/google/callback
OAUTHLIB_INSECURE_TRANSPORT = os.getenv('OAUTHLIB_INSECURE_TRANSPORT', '1' if DEBUG else '0')

# Razorpay
RAZORPAY_KEY_ID = os.getenv('RAZORPAY_KEY_ID', '')
RAZORPAY_KEY_SECRET = os.getenv('RAZORPAY_KEY_SECRET', '')

# Metrics
METRICS_ENABLED = os.getenv('METRICS_ENABLED', 'true').lower() == 'true'
METRICS_PORT = int(os.getenv('METRICS_PORT', 9090))

# Audit
AUDIT_ENABLED = os.getenv('AUDIT_ENABLED', 'true').lower() == 'true'
AUDIT_RETENTION_DAYS = int(os.getenv('AUDIT_RETENTION_DAYS', 90))

# RBAC
RBAC_ENABLED = os.getenv('RBAC_ENABLED', 'true').lower() == 'true'

# File Upload
UPLOAD_FOLDER = BASE_DIR / 'uploads'
MAX_CONTENT_LENGTH = int(os.getenv('MAX_CONTENT_LENGTH', 16 * 1024 * 1024))  # 16MB

# Templates and Static
TEMPLATE_DIR = BASE_DIR / 'templates'
STATIC_DIR = BASE_DIR / 'static'

# Testing
TESTING = os.getenv('TESTING', 'false').lower() == 'true'
TEST_DATABASE_URL = os.getenv('TEST_DATABASE_URL', 'sqlite:///:memory:')

# Ensure required directories exist
for directory in [DATABASE_DIR, LOG_DIR, UPLOAD_FOLDER]:
    directory.mkdir(parents=True, exist_ok=True)


class Config:
    """Base configuration"""

    # Flask
    SECRET_KEY = SECRET_KEY
    DEBUG = DEBUG
    TESTING = False

    # Database
    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Session
    SESSION_TYPE = SESSION_TYPE
    SESSION_PERMANENT = SESSION_PERMANENT
    PERMANENT_SESSION_LIFETIME = PERMANENT_SESSION_LIFETIME

    # Upload
    UPLOAD_FOLDER = str(UPLOAD_FOLDER)
    MAX_CONTENT_LENGTH = MAX_CONTENT_LENGTH

    # Logging
    LOG_LEVEL = LOG_LEVEL
    LOG_FILE = str(LOG_FILE)

    # Features
    RATE_LIMIT_ENABLED = RATE_LIMIT_ENABLED
    METRICS_ENABLED = METRICS_ENABLED
    AUDIT_ENABLED = AUDIT_ENABLED
    RBAC_ENABLED = RBAC_ENABLED


class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    TESTING = False
    TEMPLATES_AUTO_RELOAD = True   # re-read templates on every request in dev


class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    TESTING = False

    # Tell Flask that requests arrive over HTTPS (CDN terminates SSL)
    # This ensures url_for(_external=True) generates https:// URLs
    PREFERRED_URL_SCHEME = 'https'

    # Override with stronger settings
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'


class TestingConfig(Config):
    """Testing configuration"""
    DEBUG = True
    TESTING = True
    TEMPLATES_AUTO_RELOAD = True
    SQLALCHEMY_DATABASE_URI = TEST_DATABASE_URL
    WTF_CSRF_ENABLED = False
    RATE_LIMIT_ENABLED = False


# Configuration dictionary
config_by_name = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}


def get_config(env=None):
    """Get configuration based on environment"""
    if env is None:
        env = ENV
    return config_by_name.get(env, DevelopmentConfig)
