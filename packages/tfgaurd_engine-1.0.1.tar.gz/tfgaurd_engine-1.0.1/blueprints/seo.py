"""
SEO Blueprint - Handles sitemap.xml, robots.txt generation and search engine ping
"""

from flask import Blueprint, Response, render_template, url_for, request, jsonify
from datetime import datetime
import logging
import urllib.request
import urllib.parse

logger = logging.getLogger(__name__)

seo_bp = Blueprint('seo', __name__)

# Per-page publish / last-modified dates (ISO format)
# Update these whenever a page receives a meaningful content update.
_PAGE_DATES = {
    'dashboard.home':                      '2026-03-26',
    'dashboard.docs_page':                 '2026-03-21',
    'dashboard.api_reference_page':        '2026-03-11',
    'dashboard.support_page':              '2026-03-10',
    'dashboard.pricing_page':              '2026-03-21',
    'dashboard.blog_index':                '2026-03-26',
    'dashboard.blog_sentinel_vs_opa':      '2026-03-04',
    'dashboard.blog_cloud_security':       '2026-03-12',
    'dashboard.blog_tfguard_vs_checkov':   '2026-03-21',
    'dashboard.blog_tfguard_vs_tfsec':     '2026-03-21',
    'dashboard.blog_best_terraform_scanner': '2026-03-21',
    'dashboard.blog_hcl_security_delhi':   '2026-03-26',
    'auth.login_page':                     '2026-03-10',
    'auth.signup_page':                    '2026-03-10',
}


@seo_bp.route('/sitemap.xml')
def sitemap():
    """
    Generate dynamic XML sitemap for search engines.
    Each URL carries an accurate lastmod date and appropriate priority/changefreq.
    """
    try:
        pages = []

        # (endpoint, priority, changefreq)
        static_pages = [
            ('dashboard.home',                      1.0,  'daily'),
            ('dashboard.blog_index',                0.85, 'weekly'),
            ('dashboard.blog_hcl_security_delhi',   0.90, 'monthly'),   # Delhi-NCR — newest
            ('dashboard.blog_best_terraform_scanner', 0.90, 'monthly'), # SEO roundup
            ('dashboard.blog_tfguard_vs_checkov',   0.85, 'monthly'),   # Compare
            ('dashboard.blog_tfguard_vs_tfsec',     0.85, 'monthly'),   # Compare
            ('dashboard.blog_cloud_security',       0.85, 'monthly'),   # Blog post
            ('dashboard.blog_sentinel_vs_opa',      0.80, 'monthly'),   # Blog post
            ('dashboard.docs_page',                 0.80, 'weekly'),
            ('dashboard.api_reference_page',        0.75, 'weekly'),
            ('dashboard.pricing_page',              0.75, 'monthly'),
            ('dashboard.support_page',              0.65, 'monthly'),
            ('auth.login_page',                     0.40, 'monthly'),
            ('auth.signup_page',                    0.40, 'monthly'),
        ]

        today = datetime.now().strftime('%Y-%m-%d')

        for endpoint, priority, changefreq in static_pages:
            try:
                url = url_for(endpoint, _external=True, _scheme='https')
                pages.append({
                    'loc':        url,
                    'lastmod':    _PAGE_DATES.get(endpoint, today),
                    'priority':   priority,
                    'changefreq': changefreq,
                })
            except Exception as e:
                logger.warning(f"Could not generate URL for {endpoint}: {e}")
                continue

        sitemap_xml = render_template('frontend/sitemap.xml', pages=pages)
        response = Response(sitemap_xml, mimetype='application/xml')
        response.headers['Cache-Control'] = 'public, max-age=3600'   # 1-hour cache
        return response

    except Exception as e:
        logger.error(f"Error generating sitemap: {e}")
        return Response("Error generating sitemap", status=500)


@seo_bp.route('/admin/ping-sitemap', methods=['GET', 'POST'])
def ping_sitemap():
    """
    Notify Google (and Bing) that the sitemap has been updated.
    Access: GET /admin/ping-sitemap  (admin only — protect with login_required in production)
    Returns a JSON summary of ping results.
    """
    from core.auth import login_required  # noqa — keeps import local to avoid circular

    sitemap_url = url_for('seo.sitemap', _external=True, _scheme='https')
    encoded     = urllib.parse.quote(sitemap_url, safe='')

    engines = {
        'Google': f'https://www.google.com/ping?sitemap={encoded}',
        'Bing':   f'https://www.bing.com/ping?sitemap={encoded}',
    }

    results = {}
    for name, ping_url in engines.items():
        try:
            req = urllib.request.Request(
                ping_url,
                headers={'User-Agent': 'TFGaurd-SitemapPinger/1.0'},
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                results[name] = {'status': resp.status, 'ok': resp.status == 200}
        except Exception as exc:
            results[name] = {'status': None, 'ok': False, 'error': str(exc)}
            logger.error(f"Sitemap ping to {name} failed: {exc}")

    all_ok = all(r['ok'] for r in results.values())
    logger.info(f"Sitemap pinged: {results}")

    return jsonify({
        'sitemap_url': sitemap_url,
        'pinged_at':   datetime.utcnow().isoformat() + 'Z',
        'results':     results,
        'all_ok':      all_ok,
    }), 200 if all_ok else 207


@seo_bp.route('/robots.txt')
def robots():
    """
    Generate robots.txt file to guide search engine crawlers
    """
    try:
        # Detect base URL dynamically (handles HTTP + HTTPS + custom domains)
        base_url = request.url_root.rstrip('/')

        robots_txt = f"""# robots.txt for TFGuard
# Docs: https://developers.google.com/search/docs/crawling-indexing/robots/intro

# ── Allow all compliant crawlers ──────────────────────────────────────────────
User-agent: *

# Public pages — index these
Allow: /
Allow: /docs
Allow: /api-reference
Allow: /support
Allow: /login
Allow: /signup
Allow: /blog
Allow: /blog/
Allow: /static/

# ── Block private / admin areas ───────────────────────────────────────────────

# Admin dashboard
Disallow: /admin/
Disallow: /admin/visitors
Disallow: /admin/users

# Authenticated-only pages (no value for search engines)
Disallow: /dashboard
Disallow: /check
Disallow: /results/
Disallow: /history
Disallow: /rules
Disallow: /all-rules
Disallow: /resource-types
Disallow: /api-testing
Disallow: /profile

# Auth actions
Disallow: /logout
Disallow: /login/google
Disallow: /login/google/callback

# API endpoints
Disallow: /api/
Disallow: /api/internal/

# Uploads and logs
Disallow: /uploads/
Disallow: /logs/

# Tracking and metrics (no SEO value, save crawl budget)
Disallow: /api/track-click
Disallow: /metrics

# URL parameters that create duplicate content
Disallow: /*?page=
Disallow: /*?per_page=
Disallow: /*?search=

# ── Crawl rate (be respectful of server resources) ────────────────────────────
Crawl-delay: 1

# ── Sitemap location ──────────────────────────────────────────────────────────
Sitemap: {base_url}/sitemap.xml
"""

        response = Response(robots_txt, mimetype='text/plain')

        # Cache for 1 day
        response.headers['Cache-Control'] = 'public, max-age=86400'

        return response

    except Exception as e:
        logger.error(f"Error generating robots.txt: {e}")
        return Response("User-agent: *\nAllow: /\n", status=500, mimetype='text/plain')



@seo_bp.route('/humans.txt')
def humans():
    """
    Generate humans.txt file - credits for the team
    Optional but nice to have for transparency
    """
    humans_txt = """/* TEAM */
Developer: TFGuard Team
Site: https://tfgaurd.com
Location: Global

/* THANKS */
Terraform Community
Open Source Contributors

/* SITE */
Last update: {}
Standards: HTML5, CSS3, Flask
Components: Python, PostgreSQL, Docker
Software: VS Code, Git
""".format(datetime.now().strftime('%Y-%m-%d'))

    return Response(humans_txt, mimetype='text/plain')


# Optional: Add security.txt for responsible disclosure
@seo_bp.route('/.well-known/security.txt')
def security_txt():
    """
    Security.txt for responsible security disclosure
    https://securitytxt.org/
    """
    security_txt = """Contact: security@tfgaurd.com
Expires: {}
Preferred-Languages: en
Canonical: https://tfgaurd.com/.well-known/security.txt
""".format((datetime.now().year + 1))

    return Response(security_txt, mimetype='text/plain')
