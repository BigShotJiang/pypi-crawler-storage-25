"""
Authentication Blueprint
Handles user signup, login, and logout with email/password and Google OAuth
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
import os
import bcrypt
from datetime import datetime
from authlib.integrations.flask_client import OAuth
from core.auth import (
    login_required, generate_api_key, list_user_api_keys, revoke_api_key
)
from core.database import get_db_session
from core.models import User
from services.rate_limiter import rate_limit
from config.settings import GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_DISCOVERY_URL, GOOGLE_REDIRECT_URI
from utils.seo_helpers import get_preset_meta, generate_meta_tags
import logging

auth_bp = Blueprint('auth', __name__, url_prefix='')
logger = logging.getLogger(__name__)


@auth_bp.context_processor
def inject_admin_context():
    """Make admin_username / admin_unread_msgs available in auth templates (profile, etc.)"""
    from blueprints.dashboard import _get_unread_msg_count
    username = session.get('username', '')
    unread = 0
    if username:
        try:
            unread = _get_unread_msg_count()
        except Exception:
            unread = 0
    return {'admin_username': username, 'admin_unread_msgs': unread}


# Initialize OAuth
oauth = OAuth()
google = oauth.register(
    name='google',
    client_id=GOOGLE_CLIENT_ID,
    client_secret=GOOGLE_CLIENT_SECRET,
    server_metadata_url=GOOGLE_DISCOVERY_URL,
    client_kwargs={
        'scope': 'openid email profile'
    }
)


# ============================================================================
# SIGNUP ROUTES
# ============================================================================


def _redirect_to_modal(modal_name):
    from flask import request, redirect, url_for
    from urllib.parse import urlparse
    
    # redirect back with ?modal= query param
    ref = request.headers.get('Referer')
    if ref:
        parsed = urlparse(ref)
        # Check that it's a relative path or on our own host
        if not parsed.netloc or parsed.netloc == request.host:
            path = parsed.path
            # Prevent redirecting to paths that might loop
            if path and not path.startswith('/login') and not path.startswith('/signup') and not path.startswith('/logout'):
                # Also avoid redirecting back to protected routes if we are displaying a modal
                # (which usually means we are unauthenticated)
                protected_prefixes = ['/dashboard', '/check', '/history', '/rules', '/all-rules', '/resource-types', '/admin', '/profile', '/api-testing', '/results']
                if not any(path.startswith(p) for p in protected_prefixes):
                    return redirect(f"{path}?modal={modal_name}")
                    
    return redirect(url_for('dashboard.home', modal=modal_name))

@auth_bp.route('/signup', methods=['GET', 'POST'])
@rate_limit(limit=10, window_seconds=3600)  # 10 signups per hour per IP
def signup_page():
    """Signup page with email and password"""
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        # Validate inputs
        if not username or not email or not password:
            flash('All fields are required', 'error')
            return _redirect_to_modal('signup')

        # Validate password match
        if password != confirm_password:
            flash('Passwords do not match', 'error')
            return _redirect_to_modal('signup')

        # Validate password length
        if len(password) < 8:
            flash('Password must be at least 8 characters long', 'error')
            return _redirect_to_modal('signup')

        # Check if username already exists
        with get_db_session() as session_db:
            existing_user = session_db.query(User).filter_by(username=username).first()
            if existing_user:
                flash('Username already taken. Please choose another.', 'error')
                return _redirect_to_modal('signup')

            # Check if email already exists
            existing_email = session_db.query(User).filter_by(email=email).first()
            if existing_email:
                flash('Email already registered. Please login instead.', 'error')
                return redirect(url_for('auth.login_page'))

            # Create user
            try:
                password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

                new_user = User(
                    username=username,
                    email=email,
                    password_hash=password_hash,
                    auth_method='password',
                    is_active=True
                )
                session_db.add(new_user)
                session_db.commit()

                # Auto login after signup (new users are always 'user' role)
                session['username'] = username
                session['role'] = 'user'

                flash('Account created successfully! Welcome!', 'success')
                return redirect(url_for('dashboard.dashboard'))
            except Exception as e:
                session_db.rollback()
                logger.error(f"Signup error: {str(e)}")
                flash(f'Error creating account: {str(e)}', 'error')
                return _redirect_to_modal('signup')

    return _redirect_to_modal('signup')


# ============================================================================
# LOGIN ROUTES
# ============================================================================

@auth_bp.route('/login', methods=['GET', 'POST'])
@rate_limit(limit=30, window_seconds=3600)  # 30 logins per hour
def login_page():
    """Login page with email/username and password"""
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        if not username or not password:
            flash('Username and password are required', 'error')
            return _redirect_to_modal('login')

        # Try to authenticate
        with get_db_session() as session_db:
            # Check if username is email or username
            user = session_db.query(User).filter(
                (User.username == username) | (User.email == username)
            ).first()

            if user and user.password_hash:
                try:
                    if bcrypt.checkpw(password.encode('utf-8'), user.password_hash.encode('utf-8')):
                        session['username'] = user.username
                        session['role'] = user.role.value

                        # Update last login
                        user.last_login = datetime.utcnow()
                        user.login_count = (user.login_count or 0) + 1
                        session_db.commit()

                        flash('Logged in successfully!', 'success')
                        return redirect(url_for('dashboard.dashboard'))
                except Exception as e:
                    logger.error(f"Login error for user {username}: {str(e)}")
                    flash(f'Login error: {str(e)}', 'error')
                    return _redirect_to_modal('login')

        flash('Invalid username/email or password', 'error')

    return _redirect_to_modal('login')



@auth_bp.route('/logout')
def logout():
    """Logout"""
    session.pop('username', None)
    session.pop('role', None)
    session.clear() # Ensure everything is cleared (like Google token state)
    flash('Logged out successfully', 'success')
    return redirect(url_for('dashboard.home'))


# ============================================================================
# GOOGLE OAUTH ROUTES
# ============================================================================

@auth_bp.route('/login/google')
def google_login():
    """Initiate Google OAuth login"""
    if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
        flash('Google Sign-In is not configured. Please contact the administrator.', 'error')
        return redirect(url_for('auth.login_page'))

    # Use the explicitly configured redirect URI (most reliable).
    # Falls back to url_for with forced https scheme.
    # GOOGLE_REDIRECT_URI must match exactly what is registered in Google Cloud Console.
    if GOOGLE_REDIRECT_URI:
        redirect_uri = GOOGLE_REDIRECT_URI
    else:
        redirect_uri = url_for('auth.google_callback', _external=True, _scheme='https')

    return google.authorize_redirect(redirect_uri)


@auth_bp.route('/login/google/callback')
def google_callback():
    """Handle Google OAuth callback"""
    try:
        # Get the authorization token
        token = google.authorize_access_token()

        # Get user info from Google
        user_info = token.get('userinfo')
        if not user_info:
            resp = google.get('userinfo')
            user_info = resp.json()

        google_id = user_info.get('sub')
        email = user_info.get('email')
        name = user_info.get('name', '')
        picture = user_info.get('picture', '')

        if not google_id or not email:
            flash('Failed to get user information from Google', 'error')
            return redirect(url_for('auth.login_page'))

        # Check if user exists with this Google ID
        with get_db_session() as session_db:
            user = session_db.query(User).filter_by(google_id=google_id).first()

            if user:
                # User exists, log them in
                session['username'] = user.username
                session['role'] = user.role.value

                # Update last login
                user.last_login = datetime.utcnow()
                user.login_count = (user.login_count or 0) + 1

                # Update profile picture if changed
                if picture and user.profile_picture != picture:
                    user.profile_picture = picture

                session_db.commit()

                flash('Logged in successfully with Google!', 'success')
                return redirect(url_for('dashboard.dashboard'))

            else:
                # Check if user exists with this email
                user = session_db.query(User).filter_by(email=email).first()

                if user:
                    # Link Google account to existing user
                    user.google_id = google_id
                    user.profile_picture = picture
                    user.auth_method = 'google'
                    user.last_login = datetime.utcnow()
                    user.login_count = (user.login_count or 0) + 1
                    session_db.commit()

                    session['username'] = user.username
                    session['role'] = user.role.value if user.role else 'user'
                    flash('Google account linked successfully!', 'success')
                    return redirect(url_for('dashboard.dashboard'))

                else:
                    # Create new user with Google account
                    # Generate username from email or name
                    base_username = email.split('@')[0] if email else name.replace(' ', '_').lower()
                    username = base_username

                    # Ensure username is unique
                    counter = 1
                    while session_db.query(User).filter_by(username=username).first():
                        username = f"{base_username}{counter}"
                        counter += 1

                    new_user = User(
                        username=username,
                        email=email,
                        google_id=google_id,
                        profile_picture=picture,
                        auth_method='google',
                        is_active=True
                    )
                    session_db.add(new_user)
                    session_db.commit()

                    session['username'] = username
                    session['role'] = 'user'  # new Google users start as regular user
                    flash(f'Account created successfully with Google! Welcome {name}!', 'success')
                    return redirect(url_for('dashboard.dashboard'))

    except Exception as e:
        logger.error(f"Google OAuth error: {str(e)}")
        flash(f'Google Sign-In failed: {str(e)}', 'error')
        return redirect(url_for('auth.login_page'))


# ============================================================================
# PROFILE & API KEY MANAGEMENT
# ============================================================================

@auth_bp.route('/profile')
@login_required
def profile_page():
    """User profile and API key management"""
    username = session.get('username')
    api_keys = list_user_api_keys(username)
    return render_template('admin/profile.html', username=username, api_keys=api_keys)


@auth_bp.route('/api-key/generate', methods=['POST'])
@login_required
def generate_new_api_key():
    """Generate a new API key"""
    username = session.get('username')
    description = request.form.get('description', '')

    api_key = generate_api_key(username, description)
    flash(f'API Key generated: {api_key}', 'success')
    flash('⚠️ Copy this key now! You won\'t be able to see it again.', 'warning')

    return redirect(url_for('auth.profile_page'))


@auth_bp.route('/api-key/revoke', methods=['POST'])
@login_required
def revoke_key():
    """Revoke an API key"""
    username = session.get('username')
    api_key = request.form.get('api_key')

    success, message = revoke_api_key(api_key, username)
    flash(message, 'success' if success else 'error')

    return redirect(url_for('auth.profile_page'))
