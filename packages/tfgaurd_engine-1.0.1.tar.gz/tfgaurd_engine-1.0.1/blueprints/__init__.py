"""
Blueprints package for Policy Engine
Contains modular route blueprints for different functional areas
"""

from .auth import auth_bp
from .api import api_bp
from .dashboard import dashboard_bp
from .seo import seo_bp

__all__ = ['auth_bp', 'api_bp', 'dashboard_bp', 'seo_bp']
