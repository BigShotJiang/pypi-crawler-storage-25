"""
API Blueprint
Handles all REST API endpoints for programmatic access
Requires API key authentication
"""

import inspect
import time
from datetime import datetime

from flask import Blueprint, g, jsonify, make_response, request, session

from core.auth import require_api_key, require_auth, validate_api_key
from core.database import get_db_session
from core.models import CheckHistory, User
from services.audit import log_policy_check
from services.metrics import record_policy_check
from services.rate_limiter import rate_limit
from utils import rules
from utils.parser import parse_terraform_file
from utils.policy_checker import check_resources, get_severity

api_bp = Blueprint("api", __name__, url_prefix="/api")

# ============================================================================
# INFORMATION ENDPOINTS
# ============================================================================


@api_bp.route("/version")
def api_version():
    """API version information"""
    return jsonify(
        {
            "api_version": "v1",
            "app_version": "1.0.0",
            "features": {
                "authentication": True,
                "api_keys": True,
                "terraform_parsing": True,
                "policy_checking": True,
            },
        }
    )


@api_bp.route("/health")
def api_health():
    """API health check endpoint"""
    return jsonify(
        {
            "status": "healthy",
            "api_version": "v1",
            "timestamp": datetime.now().isoformat(),
        }
    )


# ============================================================================
# POLICY & RULES ENDPOINTS (Require API Key)
# ============================================================================


@api_bp.route("/policies", methods=["GET"])
@require_auth
def get_policies():
    """Return all policies"""
    policies = []
    for resource_type, rule_list in rules.RULE_REGISTRY.items():
        for rule_func in rule_list:
            policies.append(
                {
                    "resource_type": resource_type,
                    "name": rule_func.__name__,
                    "description": rule_func.__doc__ or "No description",
                }
            )

    return jsonify({"policies": policies, "count": len(policies)})


@api_bp.route("/rules", methods=["GET"])
@require_auth
def get_rules():
    """Get all rules organized by resource type"""
    rules_data = {}
    for resource_type, rule_list in rules.RULE_REGISTRY.items():
        rules_data[resource_type] = [
            {
                "name": rule_func.__name__,
                "description": rule_func.__doc__ or "No description",
                "source": inspect.getsource(rule_func),
            }
            for rule_func in rule_list
        ]

    return jsonify(rules_data)


# ============================================================================
# TERRAFORM CHECKING ENDPOINT (Public - No Auth Required)
# ============================================================================


@api_bp.route("/check", methods=["POST"])
@rate_limit(limit=100)  # 100 checks per hour for anonymous users
def check_terraform():
    """Check Terraform code - Public endpoint, no authentication required"""
    data = request.json
    code = data.get("code", "").replace('\r\n', '\n')
    filename = data.get("filename", "inline")

    start_time = datetime.now()

    try:
        resources = parse_terraform_file(code)
        
        # Determine user_id and subscription status before checking
        user_id = None
        has_subscription = False
        if hasattr(g, "username") and g.username:
            with get_db_session() as session_db:
                u = session_db.query(User).filter_by(username=g.username).first()
                if u:
                    user_id = u.id
                    has_subscription = u.has_active_subscription
        elif "user_id" in session:
            with get_db_session() as session_db:
                u = session_db.query(User).filter_by(id=session["user_id"]).first()
                if u:
                    user_id = u.id
                    has_subscription = u.has_active_subscription
        elif "username" in session:
            with get_db_session() as session_db:
                u = (
                    session_db.query(User)
                    .filter_by(username=session["username"])
                    .first()
                )
                if u:
                    user_id = u.id
                    has_subscription = u.has_active_subscription

        violations = check_resources(resources, has_subscription=has_subscription)

        # Categorize by severity
        by_severity = {"CRITICAL": [], "HIGH": [], "MEDIUM": [], "LOW": []}
        count_by_severity = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}

        for v in violations:
            severity = v.get("severity", "LOW")
            by_severity[severity].append(v)
            count_by_severity[severity] += 1

        # Calculate execution time
        execution_time_ms = int((datetime.now() - start_time).total_seconds() * 1000)

        passed = len(violations) == 0

        # Only save to database if user is authenticated
        check_id = None
        if user_id:
            with get_db_session() as session_db:
                history = CheckHistory(
                    user_id=user_id,
                    filename=filename,
                    resource_count=len(resources),
                    violation_count=len(violations),
                    passed=passed,
                    critical_count=count_by_severity["CRITICAL"],
                    high_count=count_by_severity["HIGH"],
                    medium_count=count_by_severity["MEDIUM"],
                    low_count=count_by_severity["LOW"],
                    violations=violations,
                    execution_time_ms=execution_time_ms,
                )
                session_db.add(history)
                session_db.commit()
                check_id = history.id

        # Log audit and metrics
        log_policy_check(filename, len(violations), execution_time_ms)
        record_policy_check(passed, execution_time_ms / 1000.0, count_by_severity)

        response_data = {
            "passed": passed,
            "violations": violations,
            "by_severity": by_severity,
            "resource_count": len(resources),
            "violation_count": len(violations),
            "exit_code": 0 if passed else 1,
        }

        # Only include check_id if saved to database
        if check_id:
            response_data["check_id"] = check_id

        return jsonify(response_data)
    except Exception as e:
        return jsonify({"error": str(e), "exit_code": 2}), 400


# ============================================================================
# FILE UPLOAD CHECK ENDPOINT (Public - No Auth Required)
# ============================================================================


@api_bp.route("/check-files", methods=["POST"])
def check_terraform_files():
    """
    Check uploaded Terraform files (.tf or .zip of .tf files).
    Requires API Key authentication.
    """
    import zipfile
    import io as _io

    uploaded_files = request.files.getlist("files")
    if not uploaded_files or all(f.filename == "" for f in uploaded_files):
        return jsonify({"error": "No files uploaded"}), 400

    # Collect (filename, content_string) pairs to analyse
    tf_sources = []

    for upload in uploaded_files:
        fname = upload.filename or "unknown"
        lower = fname.lower()
        if lower.endswith(".zip"):
            try:
                zdata = upload.read()
                with zipfile.ZipFile(_io.BytesIO(zdata)) as zf:
                    for member in zf.namelist():
                        if member.lower().endswith(".tf") and not member.startswith("__"):
                            with zf.open(member) as mf:
                                content = mf.read().decode("utf-8", errors="replace").replace('\r\n', '\n')
                                tf_sources.append((member, content))
            except zipfile.BadZipFile:
                return jsonify({"error": f"{fname} is not a valid ZIP file"}), 400
        elif lower.endswith(".tf"):
            content = upload.read().decode("utf-8", errors="replace").replace('\r\n', '\n')
            tf_sources.append((fname, content))
        else:
            return jsonify({"error": f"Unsupported file type: {fname}. Only .tf and .zip allowed"}), 400

    if not tf_sources:
        return jsonify({"error": "No .tf files found in the uploaded content"}), 400

    # ── 1. Authenticate API Key ──────────────────────────
    api_key_raw = request.headers.get('X-API-Key') or request.headers.get('Authorization', '').replace('Bearer ', '')
    
    if not api_key_raw:
        return jsonify({"error": "API Key is required"}), 401

    username = validate_api_key(api_key_raw)
    if not username:
         return jsonify({"error": "Invalid or revoked API key"}), 401

    g.username = username

    # ── 2. Determine Subscription Status ────────────────
    user_id = None
    has_subscription = False
    with get_db_session() as session_db:
        u = session_db.query(User).filter_by(username=username).first()
        if u:
            user_id = u.id
            has_subscription = u.has_active_subscription

    # ── 3. Apply Tier-Based Rate Limits ────────────────
    rate_limit_val = 10000 if has_subscription else 50
    rate_key = f"api_key:{api_key_raw[:16]}" 
    
    from services.rate_limiter import check_rate_limit
    allowed, remaining, reset_time = check_rate_limit(rate_key, limit=rate_limit_val, window_seconds=3600)
    
    if not allowed:
        return jsonify({
            "error": "Rate limit exceeded",
            "tier": "Premium" if has_subscription else "Standard",
            "limit": rate_limit_val,
            "reset_at": reset_time
        }), 429

    start_time = datetime.now()
    
    # Analyze each file individually (rest of function follows)
    return _process_policy_analysis(tf_sources, has_subscription, user_id, start_time, rate_limit_val, remaining, reset_time)


@api_bp.route("/check-files-public", methods=["POST"])
def check_terraform_files_public():
    """
    Public endpoint for home page 'Quick Check'
    No API key required, limited to 50 checks/hr, Standard Tier only.
    """
    import zipfile
    import io as _io

    uploaded_files = request.files.getlist("files")
    if not uploaded_files or all(f.filename == "" for f in uploaded_files):
        return jsonify({"error": "No files uploaded"}), 400

    tf_sources = []
    for upload in uploaded_files:
        fname = upload.filename or "unknown"
        lower = fname.lower()
        if lower.endswith(".zip"):
            try:
                zdata = upload.read()
                with zipfile.ZipFile(_io.BytesIO(zdata)) as zf:
                    for member in zf.namelist():
                        if member.lower().endswith(".tf") and not member.startswith("__"):
                            with zf.open(member) as mf:
                                content = mf.read().decode("utf-8", errors="replace").replace('\r\n', '\n')
                                tf_sources.append((member, content))
            except zipfile.BadZipFile:
                continue
        elif lower.endswith(".tf"):
            content = upload.read().decode("utf-8", errors="replace").replace('\r\n', '\n')
            tf_sources.append((fname, content))

    if not tf_sources:
        return jsonify({"error": "No .tf files found"}), 400

    # Apply same rate limit as /api/check for consistency
    from services.rate_limiter import check_rate_limit, get_rate_limit_key
    key = get_rate_limit_key()
    limit_val = 50
    allowed, remaining, reset_time = check_rate_limit(key, limit=limit_val)
    
    if not allowed:
        return jsonify({
            "error": "Rate limit exceeded",
            "message": f"Public limit reached ({limit_val}/hr). Please use an API key or upgrade.",
            "retry_after": reset_time - int(time.time())
        }), 429

    start_time = datetime.now()
    # Anonymous use = Standard tier
    return _process_policy_analysis(tf_sources, has_subscription=False, user_id=None, start_time=start_time, limit=limit_val, remaining=remaining, reset=reset_time)


def _process_policy_analysis(tf_sources, has_subscription, user_id, start_time, limit, remaining, reset):
    """Internal helper to process files and return results"""
    all_violations = []
    files_summary = []
    total_resources = 0
    count_by_severity = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}

    for filename, code in tf_sources:
        try:
            resources = parse_terraform_file(code)
            violations = check_resources(resources, has_subscription=has_subscription)

            file_by_severity = {"CRITICAL": [], "HIGH": [], "MEDIUM": [], "LOW": []}
            file_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
            for v in violations:
                sev = v.get("severity", "LOW")
                file_by_severity[sev].append(v)
                file_counts[sev] += 1

            total_resources += len(resources)
            all_violations.extend(violations)

            files_summary.append({
                "filename": filename,
                "resource_count": len(resources),
                "violation_count": len(violations),
                "passed": len(violations) == 0,
                "by_severity": file_by_severity,
                "severity_counts": file_counts,
                "violations": violations,
            })
        except Exception as e:
            files_summary.append({
                "filename": filename,
                "error": str(e),
                "resource_count": 0,
                "violation_count": 0,
                "passed": False,
                "violations": [],
                "by_severity": {"CRITICAL": [], "HIGH": [], "MEDIUM": [], "LOW": []},
                "severity_counts": {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0},
            })

    for v in all_violations:
        sev = v.get("severity", "LOW")
        count_by_severity[sev] += 1

    execution_time_ms = int((datetime.now() - start_time).total_seconds() * 1000)
    passed = len(all_violations) == 0

    check_id = None
    if user_id:
        try:
            combined_label = ", ".join(f["filename"] for f in files_summary)
            with get_db_session() as session_db:
                history = CheckHistory(
                    user_id=user_id,
                    filename=combined_label[:255],
                    resource_count=total_resources,
                    violation_count=len(all_violations),
                    passed=passed,
                    critical_count=count_by_severity["CRITICAL"],
                    high_count=count_by_severity["HIGH"],
                    medium_count=count_by_severity["MEDIUM"],
                    low_count=count_by_severity["LOW"],
                    violations=all_violations,
                    execution_time_ms=execution_time_ms,
                )
                session_db.add(history)
                session_db.commit()
                check_id = history.id
        except Exception:
            pass

    log_policy_check(f"check-files", len(all_violations), execution_time_ms)
    record_policy_check(passed, execution_time_ms / 1000.0, count_by_severity)

    response_data = {
        "passed": passed,
        "files_analysed": len(tf_sources),
        "total_resource_count": total_resources,
        "total_violation_count": len(all_violations),
        "severity_counts": count_by_severity,
        "files": files_summary,
        "execution_time_ms": execution_time_ms,
        "tier": "Premium" if has_subscription else "Standard",
        "rate_limit": {
            "limit": limit,
            "remaining": remaining,
            "reset": reset
        },
        "exit_code": 0 if passed else 1,
    }
    if check_id:
        response_data["check_id"] = check_id

    return jsonify(response_data)


# ============================================================================
# STATISTICS ENDPOINTS
# ============================================================================


@api_bp.route("/stats", methods=["GET"])
@require_auth
def get_stats():
    """Get statistics"""
    from sqlalchemy import func

    with get_db_session() as session:
        # Total stats
        total_checks = session.query(CheckHistory).count()
        total_violations = (
            session.query(func.sum(CheckHistory.violation_count)).scalar() or 0
        )

        # Severity counts
        severity_counts = {
            "CRITICAL": session.query(func.sum(CheckHistory.critical_count)).scalar()
            or 0,
            "HIGH": session.query(func.sum(CheckHistory.high_count)).scalar() or 0,
            "MEDIUM": session.query(func.sum(CheckHistory.medium_count)).scalar() or 0,
            "LOW": session.query(func.sum(CheckHistory.low_count)).scalar() or 0,
        }

    return jsonify(
        {
            "total_checks": total_checks,
            "total_violations": total_violations,
            "total_rules": sum(
                len(rule_list) for rule_list in rules.RULE_REGISTRY.values()
            ),
            "resource_types": len(rules.RULE_REGISTRY),
            "severity_counts": severity_counts,
        }
    )


@api_bp.route("/history", methods=["GET"])
@require_auth
def get_history():
    """Get check history"""
    limit = request.args.get("limit", 100, type=int)
    offset = request.args.get("offset", 0, type=int)

    with get_db_session() as session:
        history = (
            session.query(CheckHistory)
            .order_by(CheckHistory.created_at.desc())
            .limit(limit)
            .offset(offset)
            .all()
        )
        history_list = [h.to_dict() for h in history]

    return jsonify(
        {
            "history": history_list,
            "count": len(history_list),
            "limit": limit,
            "offset": offset,
        }
    )


# ============================================================================
# CUSTOM RULES MANAGEMENT
# ============================================================================


@api_bp.route("/custom-rules", methods=["GET"])
@require_auth
def get_custom_rules():
    """Get all custom rules"""
    all_rules = rules.get_all_custom_rules()
    return jsonify({"rules": all_rules, "count": len(all_rules)})


@api_bp.route("/custom-rules", methods=["POST"])
@require_auth
def create_custom_rule():
    """Create a new custom rule"""
    try:
        data = request.get_json()

        # Validate required fields
        required_fields = [
            "rule_name",
            "resource_type",
            "rule_category",
            "rule_condition",
            "condition_value",
            "severity_level",
        ]
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({"error": f"Missing required field: {field}"}), 400

        # Create the rule
        new_rule = rules.add_custom_rule(data)

        return jsonify({"message": "Rule created successfully", "rule": new_rule}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@api_bp.route("/custom-rules/<rule_name>", methods=["GET"])
@require_auth
def get_custom_rule(rule_name):
    """Get a specific custom rule"""
    rule = rules.get_custom_rule(rule_name)
    if not rule:
        return jsonify({"error": "Rule not found"}), 404
    return jsonify({"rule": rule})


@api_bp.route("/custom-rules/<rule_name>", methods=["PUT"])
@require_auth
def update_custom_rule(rule_name):
    """Update a custom rule"""
    try:
        data = request.get_json()

        # Validate required fields
        required_fields = [
            "rule_name",
            "resource_type",
            "rule_category",
            "rule_condition",
            "condition_value",
            "severity_level",
        ]
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({"error": f"Missing required field: {field}"}), 400

        # Update the rule
        updated_rule = rules.update_custom_rule(rule_name, data)
        if not updated_rule:
            return jsonify({"error": "Rule not found"}), 404

        return jsonify({"message": "Rule updated successfully", "rule": updated_rule})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@api_bp.route("/custom-rules/<rule_name>", methods=["DELETE"])
@require_auth
def delete_custom_rule(rule_name):
    """Delete a custom rule"""
    try:
        success = rules.delete_custom_rule(rule_name)
        if not success:
            return jsonify({"error": "Rule not found"}), 404

        return jsonify({"message": f'Rule "{rule_name}" deleted successfully'})
    except Exception as e:
        return jsonify({"error": str(e)}), 500



# ============================================================================
# PREMIUM RULE BUNDLE DOWNLOAD ENDPOINT
# Delivers an AES-GCM encrypted blob of all premium rule source files.
# The encryption key is HMAC(server_secret, api_key) — unique per user.
# The CLI decrypts and executes entirely in memory; rules are never on disk.
# ============================================================================


@api_bp.route("/rules/bundle", methods=["GET"])
def download_rules_bundle():
    """
    Download the encrypted premium rules bundle for the local CLI.

    Returns a binary blob: [12-byte nonce][AES-GCM ciphertext].
    The CLI decrypts this using the same API key used in the request header.
    The decrypted content is the combined Python source of all premium rule
    modules, which the CLI executes in an isolated in-memory namespace.

    Free users receive HTTP 403 with an upgrade URL.
    """
    # ── Authenticate ────────────────────────────────────────────────────────
    api_key_raw = (
        request.headers.get("X-API-Key")
        or request.headers.get("Authorization", "").replace("Bearer ", "")
    )
    if not api_key_raw:
        return jsonify({"error": "X-API-Key header required."}), 401

    username = validate_api_key(api_key_raw)
    if not username:
        return jsonify({"error": "Invalid or revoked API key."}), 401

    # ── Check subscription ───────────────────────────────────────────────────
    has_subscription = False
    with get_db_session() as session_db:
        u = session_db.query(User).filter_by(username=username).first()
        if u:
            has_subscription = u.has_active_subscription

    if not has_subscription:
        return jsonify({
            "error": "Premium subscription required to access the rule bundle.",
            "has_subscription": False,
            "upgrade_url": "/pricing",
        }), 403

    # ── Build & return the encrypted bundle ──────────────────────────────────
    try:
        from services.rule_bundler import build_encrypted_bundle
        blob = build_encrypted_bundle(api_key_raw)
    except RuntimeError as exc:
        # cryptography package missing on server
        return jsonify({"error": str(exc)}), 503
    except Exception as exc:
        return jsonify({"error": f"Bundle generation failed: {exc}"}), 500

    # Return as raw binary with a custom content-type so curl/requests
    # download it as bytes without any encoding surprises.
    resp = make_response(blob)
    resp.headers["Content-Type"] = "application/octet-stream"
    resp.headers["Content-Disposition"] = 'attachment; filename="rules.bundle"'
    resp.headers["X-Has-Subscription"] = "true"
    return resp


# ============================================================================
# LOCAL CLI INGEST ENDPOINT
# Receives metadata-only payloads from `tfguard_cli.py`.
# ⚠️  Source code NEVER touches this endpoint by design.
# ============================================================================


@api_bp.route("/ingest", methods=["POST"])
def ingest_local_scan():
    """
    Accept scan metadata from the TFGuard local CLI.

    The local CLI runs all Terraform parsing and rule evaluation on the
    developer's own machine.  Only the RESULTS (violation messages, severity
    counts, resource counts) are posted here — never the original source code.

    Authentication: X-API-Key header (same key as /api/check).
    Premium subscriptions get their `has_subscription` flag back so the CLI
    can enable the premium rule tier locally.
    """
    # ── 1. Validate API Key ──────────────────────────────────────────────────
    api_key_raw = (
        request.headers.get("X-API-Key")
        or request.headers.get("Authorization", "").replace("Bearer ", "")
    )
    if not api_key_raw:
        return jsonify({"error": "API key required. Set X-API-Key header."}), 401

    username = validate_api_key(api_key_raw)
    if not username:
        return jsonify({"error": "Invalid or revoked API key."}), 401

    # ── 2. Look up user & subscription ──────────────────────────────────────
    user_id = None
    has_subscription = False
    with get_db_session() as session_db:
        u = session_db.query(User).filter_by(username=username).first()
        if u:
            user_id = u.id
            has_subscription = u.has_active_subscription

    if not has_subscription:
        return jsonify({
            "error": "Premium subscription required to sync results to the dashboard.",
            "has_subscription": False,
            "upgrade_url": "/pricing",
        }), 403

    # ── 3. Parse JSON payload ────────────────────────────────────────────────
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "JSON body required."}), 400

    # Basic field extraction — all optional so the CLI version can evolve
    repo_name         = str(data.get("repo_name", "unknown"))[:255]
    total_files       = int(data.get("total_files", 0))
    total_resources   = int(data.get("total_resources", 0))
    total_violations  = int(data.get("total_violations", 0))
    severity_counts   = data.get("severity_counts", {})
    passed            = bool(data.get("passed", total_violations == 0))
    execution_time_ms = int(data.get("execution_time_ms", 0))
    scanned_at        = data.get("scanned_at", datetime.now().isoformat())
    files_meta        = data.get("files", [])
    cli_version       = str(data.get("cli_version", "unknown"))
    hostname          = str(data.get("hostname", ""))[:100]
    source_os         = str(data.get("os", ""))[:50]

    # Flatten all violations from all files into one list for storage
    all_violations = []
    for file_info in files_meta:
        for v in file_info.get("violations", []):
            all_violations.append({
                "filename":      file_info.get("filename", ""),
                "resource_type": v.get("resource_type", ""),
                "resource_name": v.get("resource_name", ""),
                "rule":          v.get("rule", ""),
                "violation":     v.get("violation", ""),
                "severity":      v.get("severity", "LOW"),
            })

    # Build a human-readable filename label
    if files_meta:
        filenames = [f.get("filename", "") for f in files_meta[:5]]
        label = ", ".join(filenames)
        if len(files_meta) > 5:
            label += f" (+{len(files_meta) - 5} more)"
        label = f"[CLI] {repo_name}: {label}"[:500]
    else:
        label = f"[CLI] {repo_name}"[:500]

    # ── 4. Persist to CheckHistory ──────────────────────────────────────────
    check_id = None
    try:
        with get_db_session() as session_db:
            history = CheckHistory(
                user_id=user_id,
                filename=label,
                resource_count=total_resources,
                violation_count=total_violations,
                passed=passed,
                critical_count=int(severity_counts.get("CRITICAL", 0)),
                high_count=int(severity_counts.get("HIGH", 0)),
                medium_count=int(severity_counts.get("MEDIUM", 0)),
                low_count=int(severity_counts.get("LOW", 0)),
                violations=all_violations,
                execution_time_ms=execution_time_ms,
            )
            session_db.add(history)
            session_db.commit()
            check_id = history.id
    except Exception as exc:
        # Non-fatal — return success but note the storage error
        return jsonify({
            "synced": False,
            "error": f"Failed to persist results: {exc}",
            "has_subscription": has_subscription,
        }), 500

    # ── 5. Log metrics ───────────────────────────────────────────────────────
    try:
        log_policy_check(label, total_violations, execution_time_ms)
        record_policy_check(passed, execution_time_ms / 1000.0, severity_counts)
    except Exception:
        pass  # metrics are non-fatal

    # ── 6. Return confirmation ───────────────────────────────────────────────
    dashboard_url = f"/results/{check_id}" if check_id else "/history"

    return jsonify({
        "synced":           True,
        "check_id":         check_id,
        "has_subscription": has_subscription,
        "dashboard_url":    dashboard_url,
        "message":          (
            f"✓ Scan results synced successfully. "
            f"{total_violations} violation(s) across {total_files} file(s). "
            f"View at {dashboard_url}"
        ),
    })


@api_bp.route("/custom-rules/code", methods=["POST"])
@require_auth
def create_code_rule():
    """Create a custom rule from Python code"""
    try:
        data = request.get_json()

        # Validate required fields
        required_fields = [
            "code_name",
            "code_resource_type",
            "code_severity",
            "code_python",
        ]
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({"error": f"Missing required field: {field}"}), 400

        # Validate Python code syntax
        try:
            compile(data["code_python"], "<string>", "exec")
        except SyntaxError as e:
            return jsonify({"error": f"Syntax error in code: {str(e)}"}), 400

        # Create the code-based rule
        new_rule = rules.add_code_rule(data)

        return (
            jsonify(
                {"message": "Rule created successfully from code", "rule": new_rule}
            ),
            201,
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 500
