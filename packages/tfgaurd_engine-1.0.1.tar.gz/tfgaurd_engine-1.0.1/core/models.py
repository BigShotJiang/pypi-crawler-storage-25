# models.py - SQLAlchemy database models for enterprise features

import enum
from datetime import datetime

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()

# ============================================================================
# ENUMS
# ============================================================================


class UserRole(enum.Enum):
    """User roles for RBAC"""

    ADMIN = "admin"
    DEVELOPER = "developer"
    AUDITOR = "auditor"


class AuditAction(enum.Enum):
    """Audit log action types"""

    LOGIN = "login"
    LOGOUT = "logout"
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    CHECK_POLICY = "check_policy"
    GENERATE_API_KEY = "generate_api_key"
    REVOKE_API_KEY = "revoke_api_key"


# ============================================================================
# MODELS
# ============================================================================


class User(Base):
    """User model with RBAC support"""

    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=True, index=True)
    phone = Column(String(20), unique=True, nullable=True, index=True)
    password_hash = Column(String(255), nullable=True)  # Nullable for OTP-only users

    # OAuth fields
    google_id = Column(String(255), unique=True, nullable=True, index=True)
    profile_picture = Column(String(500), nullable=True)

    # RBAC
    role = Column(
        Enum(UserRole), default=UserRole.DEVELOPER, nullable=False, index=True
    )

    # Metadata
    auth_method = Column(String(20), default="password")  # 'password', 'otp', or 'google'
    is_active = Column(Boolean, default=True, nullable=False, index=True)
    has_active_subscription = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)
    login_count = Column(Integer, default=0)

    # Relationships
    api_keys = relationship(
        "APIKey", back_populates="user", cascade="all, delete-orphan"
    )
    check_history = relationship(
        "CheckHistory", back_populates="user", cascade="all, delete-orphan"
    )
    audit_logs = relationship(
        "AuditLog", back_populates="user", cascade="all, delete-orphan"
    )
    custom_rules = relationship(
        "CustomRule", back_populates="created_by_user", cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<User(username='{self.username}', role='{self.role.value}', active={self.is_active})>"

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "phone": self.phone,
            "role": self.role.value,
            "auth_method": self.auth_method,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "last_login": self.last_login.isoformat() if self.last_login else None,
            "login_count": self.login_count,
            "profile_picture": self.profile_picture,
        }


class APIKey(Base):
    """API Key model with usage tracking"""

    __tablename__ = "api_keys"

    id = Column(Integer, primary_key=True)
    key_hash = Column(
        String(255), unique=True, nullable=False, index=True
    )  # Hashed API key
    key_prefix = Column(
        String(20), nullable=False
    )  # First few chars for identification (e.g., 'pk_abc...')

    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    description = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False, index=True)

    # Usage tracking
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    last_used = Column(DateTime, nullable=True)
    usage_count = Column(Integer, default=0)

    # Rate limiting
    rate_limit = Column(Integer, default=100)  # Requests per hour

    # Relationships
    user = relationship("User", back_populates="api_keys")

    # Indexes
    __table_args__ = (Index("idx_api_key_user_active", "user_id", "is_active"),)

    def __repr__(self):
        return f"<APIKey(prefix='{self.key_prefix}', user_id={self.user_id}, active={self.is_active})>"

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "key_preview": f"{self.key_prefix}...",
            "description": self.description,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "last_used": self.last_used.isoformat() if self.last_used else None,
            "usage_count": self.usage_count,
            "rate_limit": self.rate_limit,
        }


class CheckHistory(Base):
    """Policy check history with full metadata"""

    __tablename__ = "check_history"

    id = Column(Integer, primary_key=True)
    user_id = Column(
        Integer, ForeignKey("users.id"), nullable=True, index=True
    )  # Nullable for anonymous checks

    # Check details
    filename = Column(String(500), nullable=False)
    resource_count = Column(Integer, default=0)
    violation_count = Column(Integer, default=0)
    passed = Column(Boolean, default=False, index=True)

    # Severity breakdown
    critical_count = Column(Integer, default=0)
    high_count = Column(Integer, default=0)
    medium_count = Column(Integer, default=0)
    low_count = Column(Integer, default=0)

    # Full results (stored as JSON)
    violations = Column(JSON, nullable=True)

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    execution_time_ms = Column(Integer, nullable=True)  # Execution time in milliseconds

    # Relationships
    user = relationship("User", back_populates="check_history")

    # Indexes
    __table_args__ = (
        Index("idx_check_history_user_date", "user_id", "created_at"),
        Index("idx_check_history_passed", "passed", "created_at"),
    )

    def __repr__(self):
        return f"<CheckHistory(id={self.id}, filename='{self.filename}', violations={self.violation_count})>"

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "filename": self.filename,
            "resource_count": self.resource_count,
            "violation_count": self.violation_count,
            "passed": self.passed,
            "severity_breakdown": {
                "CRITICAL": self.critical_count,
                "HIGH": self.high_count,
                "MEDIUM": self.medium_count,
                "LOW": self.low_count,
            },
            "violations": self.violations,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "execution_time_ms": self.execution_time_ms,
        }


class AuditLog(Base):
    """Audit log for compliance and security"""

    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True)
    user_id = Column(
        Integer, ForeignKey("users.id"), nullable=True, index=True
    )  # Nullable for anonymous actions

    # Action details
    action = Column(Enum(AuditAction), nullable=False, index=True)
    resource_type = Column(
        String(100), nullable=True
    )  # e.g., 'user', 'api_key', 'policy'
    resource_id = Column(String(100), nullable=True)

    # Request details
    ip_address = Column(String(45), nullable=True)  # IPv6 support
    user_agent = Column(String(500), nullable=True)
    correlation_id = Column(
        String(100), nullable=True, index=True
    )  # For request tracing

    # Additional details (stored as JSON)
    details = Column(JSON, nullable=True)

    # Metadata
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    success = Column(Boolean, default=True, index=True)
    error_message = Column(Text, nullable=True)

    # Relationships
    user = relationship("User", back_populates="audit_logs")

    # Indexes
    __table_args__ = (
        Index("idx_audit_log_user_timestamp", "user_id", "timestamp"),
        Index("idx_audit_log_action_timestamp", "action", "timestamp"),
        Index("idx_audit_log_correlation", "correlation_id"),
    )

    def __repr__(self):
        return f"<AuditLog(id={self.id}, action='{self.action.value}', user_id={self.user_id})>"

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "action": self.action.value,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "ip_address": self.ip_address,
            "user_agent": self.user_agent,
            "correlation_id": self.correlation_id,
            "details": self.details,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "success": self.success,
            "error_message": self.error_message,
        }


class CustomRule(Base):
    """Custom policy rules created by users"""

    __tablename__ = "custom_rules"

    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False, index=True)
    description = Column(Text, nullable=True)

    # Rule details
    resource_type = Column(
        String(100), nullable=False, index=True
    )  # e.g., 'aws_s3_bucket'
    severity = Column(String(20), default="MEDIUM")  # CRITICAL, HIGH, MEDIUM, LOW
    rule_code = Column(Text, nullable=False)  # Python code for the rule

    # Metadata
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    is_active = Column(Boolean, default=True, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Usage tracking
    usage_count = Column(Integer, default=0)
    last_used = Column(DateTime, nullable=True)

    # Relationships
    created_by_user = relationship("User", back_populates="custom_rules")

    # Indexes
    __table_args__ = (
        Index("idx_custom_rule_resource_active", "resource_type", "is_active"),
    )

    def __repr__(self):
        return f"<CustomRule(name='{self.name}', resource_type='{self.resource_type}')>"

    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "resource_type": self.resource_type,
            "severity": self.severity,
            "rule_code": self.rule_code,
            "created_by": self.created_by,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "usage_count": self.usage_count,
            "last_used": self.last_used.isoformat() if self.last_used else None,
        }


# ============================================================================
# VISITOR ANALYTICS MODELS
# ============================================================================


class VisitorLog(Base):
    """Stores every page-view event for visitor analytics"""

    __tablename__ = "visitor_logs"

    id = Column(Integer, primary_key=True)
    session_id = Column(String(64), nullable=True, index=True)   # browser fingerprint
    ip_address = Column(String(45), nullable=False, index=True)  # IPv6 support
    page_url = Column(String(500), nullable=False, index=True)
    referer = Column(String(500), nullable=True)

    # Parsed user-agent fields
    user_agent_raw = Column(String(500), nullable=True)
    browser = Column(String(100), nullable=True, index=True)
    os = Column(String(100), nullable=True, index=True)
    device = Column(String(100), nullable=True)
    is_mobile = Column(Boolean, default=False)
    is_tablet = Column(Boolean, default=False)
    is_pc = Column(Boolean, default=False)
    is_bot = Column(Boolean, default=False, index=True)

    # Visit metadata
    is_new_visitor = Column(Boolean, default=False, index=True)
    duration_seconds = Column(Integer, nullable=True)   # Updated on next page hit
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)

    __table_args__ = (
        Index("idx_visitor_log_ts_ip", "timestamp", "ip_address"),
        Index("idx_visitor_log_page", "page_url", "timestamp"),
    )

    def to_dict(self):
        return {
            "id": self.id,
            "session_id": self.session_id,
            "ip_address": self.ip_address,
            "page_url": self.page_url,
            "referer": self.referer,
            "browser": self.browser,
            "os": self.os,
            "device": self.device,
            "is_mobile": self.is_mobile,
            "is_tablet": self.is_tablet,
            "is_pc": self.is_pc,
            "is_bot": self.is_bot,
            "is_new_visitor": self.is_new_visitor,
            "user_agent_raw": self.user_agent_raw,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }


class ClickHeatmap(Base):
    """Stores click / interaction events for heatmap visualisation"""

    __tablename__ = "click_heatmap"

    id = Column(Integer, primary_key=True)
    session_id = Column(String(64), nullable=True, index=True)
    ip_address = Column(String(45), nullable=True)
    page_url = Column(String(500), nullable=False, index=True)

    # Click coordinates (relative to viewport, 0-100 %)
    x_pct = Column(Integer, nullable=False)  # % of viewport width
    y_pct = Column(Integer, nullable=False)  # % of viewport height

    # Element info
    element_tag = Column(String(50), nullable=True)   # e.g. 'button', 'a'
    element_text = Column(String(200), nullable=True) # trimmed inner text
    element_id = Column(String(200), nullable=True)   # id attribute

    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)

    __table_args__ = (
        Index("idx_heatmap_page_ts", "page_url", "timestamp"),
    )

    def to_dict(self):
        return {
            "id": self.id,
            "session_id": self.session_id,
            "page_url": self.page_url,
            "x_pct": self.x_pct,
            "y_pct": self.y_pct,
            "element_tag": self.element_tag,
            "element_text": self.element_text,
            "element_id": self.element_id,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }


class ContactMessage(Base):
    """Stores support contact form submissions"""

    __tablename__ = "contact_messages"

    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    email = Column(String(255), nullable=False, index=True)
    category = Column(String(100), nullable=True)
    message = Column(Text, nullable=False)
    ip_address = Column(String(45), nullable=True)
    is_read = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "category": self.category,
            "message": self.message,
            "ip_address": self.ip_address,
            "is_read": self.is_read,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
