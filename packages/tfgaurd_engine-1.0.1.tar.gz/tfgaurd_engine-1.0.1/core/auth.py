import bcrypt
import secrets
import json
import os
import hashlib
from datetime import datetime
from functools import wraps
from flask import request, jsonify, session, g
from config.settings import USERS_FILE, API_KEYS_FILE, SECRET_KEY

# ============================================================================
# USER MANAGEMENT
# ============================================================================

def load_users():
    """Load users from file"""
    if not os.path.exists(USERS_FILE):
        return {}
    with open(USERS_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_users(users):
    """Save users to file"""
    # Ensure directory exists
    os.makedirs(os.path.dirname(USERS_FILE), exist_ok=True)
    with open(USERS_FILE, 'w', encoding='utf-8') as f:
        json.dump(users, f, indent=2)

def create_user(username, password='', email='', phone=''):
    """Create a new user (supports both password and phone-based auth)"""
    users = load_users()

    if username in users:
        return False, "Username already exists"

    # If phone is provided, check for duplicate
    if phone:
        normalized_phone = phone.strip().replace(' ', '')
        if not normalized_phone.startswith('+'):
            normalized_phone = '+' + normalized_phone

        for user, data in users.items():
            if data.get('phone') == normalized_phone:
                return False, "Phone number already registered"

    user_data = {
        'created_at': datetime.now().isoformat(),
        'is_active': True,
        'auth_method': 'otp' if phone else 'password'
    }

    # Hash password if provided (for backward compatibility)
    if password:
        password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        user_data['password_hash'] = password_hash

    # Add email and phone if provided
    if email:
        user_data['email'] = email
    if phone:
        normalized_phone = phone.strip().replace(' ', '')
        if not normalized_phone.startswith('+'):
            normalized_phone = '+' + normalized_phone
        user_data['phone'] = normalized_phone

    users[username] = user_data
    save_users(users)
    return True, "User created successfully"

def create_user_with_phone(phone_number, username=None):
    """Create a new user with phone number (OTP-based)"""
    # Normalize phone number
    phone_number = phone_number.strip().replace(' ', '')
    if not phone_number.startswith('+'):
        phone_number = '+' + phone_number

    # Use phone as username if not provided
    if not username:
        username = phone_number.replace('+', '').replace(' ', '')

    return create_user(username, phone=phone_number)

def get_user_by_phone(phone_number):
    """Get user by phone number"""
    # Normalize phone number
    phone_number = phone_number.strip().replace(' ', '')
    if not phone_number.startswith('+'):
        phone_number = '+' + phone_number

    users = load_users()
    for username, data in users.items():
        if data.get('phone') == phone_number:
            return username, data
    return None, None

def verify_user(username, password):
    """Verify user credentials (backward compatibility wrapper)"""
    return verify_user_password(username, password)

def initialize_default_user():
    """Create default admin user if no users exist"""
    # Secure admin credentials
    ADMIN_USERNAME = 'sysadmin_pe'
    ADMIN_PASSWORD = 'PolicyEngine@2026!Secure'
    ADMIN_EMAIL = 'sysadmin@policyengine.local'

    # Create in JSON (for backward compatibility)
    users = load_users()
    if not users:
        create_user(ADMIN_USERNAME, ADMIN_PASSWORD, ADMIN_EMAIL)
        print(f"Default user created in JSON - Username: {ADMIN_USERNAME}")

    # Create in database
    from core.database import get_db_session
    from core.models import User, UserRole
    import bcrypt

    with get_db_session() as session:
        # Check if admin user exists in DB
        existing_user = session.query(User).filter_by(username=ADMIN_USERNAME).first()
        if not existing_user:
            # Create admin user in database
            password_hash = bcrypt.hashpw(ADMIN_PASSWORD.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
            admin_user = User(
                username=ADMIN_USERNAME,
                email=ADMIN_EMAIL,
                password_hash=password_hash,
                is_active=True,
                role=UserRole.ADMIN,
                created_at=datetime.now()
            )
            session.add(admin_user)
            session.commit()
            print(f"Default admin user created in database - Username: {ADMIN_USERNAME}")
            print("✓ Strong password configured")

def verify_user_password(username, password):
    """Verify user credentials with password (backward compatibility)"""
    users = load_users()

    if username not in users:
        return False

    user = users[username]
    if not user.get('is_active', True):
        return False

    if 'password_hash' not in user:
        return False

    return bcrypt.checkpw(password.encode('utf-8'), user['password_hash'].encode('utf-8'))

def _hash_key(api_key):
    """Securely hash an API key for storage using SHA-256"""
    return hashlib.sha256(api_key.encode()).hexdigest()

def generate_api_key(username, description=''):
    """Generate a new API key for a user and store in database"""
    from core.database import get_db_session
    from core.models import User, APIKey
    
    with get_db_session() as session_db:
        user = session_db.query(User).filter_by(username=username).first()
        if not user:
            return None
            
        # Generate a secure random key
        api_key_raw = 'pk_' + secrets.token_urlsafe(32)
        key_hash = _hash_key(api_key_raw)
        
        # New keys started as legacy JSON often didn't have high length prefix
        key_prefix = api_key_raw[:12]
        
        new_key = APIKey(
            key_hash=key_hash,
            key_prefix=key_prefix,
            user_id=user.id,
            description=description,
            is_active=True,
            created_at=datetime.utcnow(),
            usage_count=0
        )
        session_db.add(new_key)
        session_db.commit()
        
        return api_key_raw

def validate_api_key(api_key_raw):
    """Validate an API key against database and return username if valid"""
    from core.database import get_db_session
    from core.models import User, APIKey
    
    key_hash = _hash_key(api_key_raw)
    
    with get_db_session() as session_db:
        # Query for active key
        key_record = session_db.query(APIKey).filter_by(key_hash=key_hash, is_active=True).first()
        
        if not key_record:
            return None
            
        # Update usage tracking
        key_record.last_used = datetime.utcnow()
        key_record.usage_count += 1
        
        username = key_record.user.username
        session_db.commit()
        
        return username

def list_user_api_keys(username):
    """List all API keys for a user from database"""
    from core.database import get_db_session
    from core.models import User, APIKey
    
    with get_db_session() as session_db:
        user = session_db.query(User).filter_by(username=username).first()
        if not user:
            return []
            
        keys = session_db.query(APIKey).filter_by(user_id=user.id).all()
        user_keys = []
        
        for k in keys:
            user_keys.append({
                'id': k.id,
                'key_preview': f"{k.key_prefix}...",
                'description': k.description,
                'created_at': k.created_at.isoformat() if k.created_at else None,
                'last_used': k.last_used.isoformat() if k.last_used else None,
                'usage_count': k.usage_count,
                'is_active': k.is_active
            })
            
        return user_keys

def revoke_api_key(api_key_id_or_raw, username):
    """Revoke an API key in database (can be ID or full key)"""
    from core.database import get_db_session
    from core.models import User, APIKey
    
    with get_db_session() as session_db:
        user = session_db.query(User).filter_by(username=username).first()
        if not user:
            return False, "User not found"
            
        # Try finding by ID first (from dashboard)
        try:
            key_id = int(api_key_id_or_raw)
            key_record = session_db.query(APIKey).filter_by(id=key_id, user_id=user.id).first()
        except (ValueError, TypeError):
            # Try finding by raw key hash (if provided directly)
            key_hash = _hash_key(api_key_id_or_raw)
            key_record = session_db.query(APIKey).filter_by(key_hash=key_hash, user_id=user.id).first()
            
        if not key_record:
            return False, "API key not found"
            
        key_record.is_active = False
        session_db.commit()
        return True, "API key revoked"

# ============================================================================
# DECORATORS
# ============================================================================

def require_api_key(f):
    """Decorator to require API key authentication for API endpoints"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Check for API key in header
        api_key = request.headers.get('X-API-Key') or request.headers.get('Authorization', '').replace('Bearer ', '')

        if not api_key:
            return jsonify({
                'error': 'Missing API key',
                'message': 'Please provide an API key in X-API-Key header or Authorization header'
            }), 401

        username = validate_api_key(api_key)
        if not username:
            return jsonify({
                'error': 'Invalid API key',
                'message': 'The provided API key is invalid or has been revoked'
            }), 401

        # Store username in Flask's g object for use in the request
        g.username = username

        return f(*args, **kwargs)

    return decorated_function

def require_auth(f):
    """Decorator to require either API key OR session authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        from flask import session, g

        # Check for session authentication first
        if 'username' in session:
            g.username = session['username']
            return f(*args, **kwargs)

        # Fall back to API key authentication
        api_key = request.headers.get('X-API-Key') or request.headers.get('Authorization', '').replace('Bearer ', '')

        if not api_key:
            return jsonify({
                'error': 'Authentication required',
                'message': 'Please provide an API key or login'
            }), 401

        username = validate_api_key(api_key)
        if not username:
            return jsonify({
                'error': 'Invalid API key',
                'message': 'The provided API key is invalid or has been revoked'
            }), 401

        g.username = username
        return f(*args, **kwargs)

    return decorated_function

def login_required(f):
    """Decorator to require login for web pages"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        from flask import redirect, url_for, session
        if 'username' not in session:
            return redirect(url_for('auth.login_page'))
        return f(*args, **kwargs)

    return decorated_function

def admin_required(f):
    """Decorator to require admin role for web pages"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        from flask import redirect, url_for, session, abort
        from core.database import get_db_session
        from core.models import User

        if 'username' not in session:
            return redirect(url_for('auth.login_page'))

        # Check if user has admin role
        username = session.get('username')
        with get_db_session() as session_db:
            user = session_db.query(User).filter_by(username=username).first()
            if not user or user.role.value != 'admin':
                abort(403)  # Forbidden

        return f(*args, **kwargs)

    return decorated_function

# ============================================================================
# INITIALIZATION
# ============================================================================
