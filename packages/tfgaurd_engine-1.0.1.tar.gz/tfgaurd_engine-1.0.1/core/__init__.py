"""
Core module for Policy Engine
Contains authentication, database, and models
"""

from .auth import (
    require_api_key, login_required, verify_user, verify_user_password, 
    create_user, generate_api_key, list_user_api_keys, revoke_api_key,
    initialize_default_user, create_user_with_phone, get_user_by_phone
)
from .database import init_db, get_db_session
from .models import User, APIKey, CheckHistory

__all__ = [
    'require_api_key', 'login_required', 'verify_user', 'verify_user_password',
    'create_user', 'generate_api_key', 'list_user_api_keys', 'revoke_api_key',
    'initialize_default_user', 'create_user_with_phone', 'get_user_by_phone',
    'init_db', 'get_db_session',
    'User', 'APIKey', 'CheckHistory'
]
