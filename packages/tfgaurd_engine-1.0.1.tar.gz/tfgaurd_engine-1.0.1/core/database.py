# database.py - Database configuration and session management

import os
from datetime import datetime
from contextlib import contextmanager
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, scoped_session
from sqlalchemy.pool import QueuePool
from core.models import Base
import logging

logger = logging.getLogger(__name__)

# ============================================================================
# DATABASE CONFIGURATION
# ============================================================================

class DatabaseConfig:
    """Database configuration from environment variables"""
    
    def __init__(self):
        # Database URL (supports PostgreSQL and SQLite)
        self.database_url = os.getenv(
            'DATABASE_URL',
            'sqlite:///policy_engine.db'  # Default to SQLite for development
        )
        
        # Connection pool settings
        self.pool_size = int(os.getenv('DATABASE_POOL_SIZE', '10'))
        self.max_overflow = int(os.getenv('DATABASE_MAX_OVERFLOW', '20'))
        self.pool_timeout = int(os.getenv('DATABASE_POOL_TIMEOUT', '30'))
        self.pool_recycle = int(os.getenv('DATABASE_POOL_RECYCLE', '3600'))
        
        # Echo SQL queries (for debugging)
        self.echo = os.getenv('DATABASE_ECHO', 'false').lower() == 'true'
        
    def get_engine_kwargs(self):
        """Get engine configuration kwargs"""
        kwargs = {
            'echo': self.echo,
            'pool_pre_ping': True,  # Verify connections before using
        }
        
        # Only add pool settings for non-SQLite databases
        if not self.database_url.startswith('sqlite'):
            kwargs.update({
                'poolclass': QueuePool,
                'pool_size': self.pool_size,
                'max_overflow': self.max_overflow,
                'pool_timeout': self.pool_timeout,
                'pool_recycle': self.pool_recycle,
            })
        else:
            # SQLite-specific settings
            kwargs['connect_args'] = {'check_same_thread': False}
        
        return kwargs


# ============================================================================
# DATABASE ENGINE AND SESSION
# ============================================================================

# Global database configuration
config = DatabaseConfig()

# Create engine
engine = create_engine(config.database_url, **config.get_engine_kwargs())

# Create session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Thread-safe session
ScopedSession = scoped_session(SessionLocal)


# ============================================================================
# DATABASE INITIALIZATION
# ============================================================================

def init_db():
    """Initialize database - create all tables"""
    try:
        logger.info("Initializing database...")
        Base.metadata.create_all(bind=engine)
        logger.info("Database initialized successfully")
        return True
    except Exception as e:
        logger.error(f"Failed to initialize database: {str(e)}")
        return False


def drop_db():
    """Drop all tables (use with caution!)"""
    try:
        logger.warning("Dropping all database tables...")
        Base.metadata.drop_all(bind=engine)
        logger.info("All tables dropped successfully")
        return True
    except Exception as e:
        logger.error(f"Failed to drop tables: {str(e)}")
        return False


def reset_db():
    """Reset database - drop and recreate all tables"""
    drop_db()
    return init_db()


# ============================================================================
# SESSION MANAGEMENT
# ============================================================================

@contextmanager
def get_db_session():
    """
    Context manager for database sessions
    
    Usage:
        with get_db_session() as session:
            user = session.query(User).filter_by(username='admin').first()
    """
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception as e:
        session.rollback()
        logger.error(f"Database session error: {str(e)}")
        raise
    finally:
        session.close()


def get_db():
    """
    Get database session for dependency injection (Flask)
    
    Usage in Flask:
        @app.route('/users')
        def get_users():
            db = get_db()
            users = db.query(User).all()
            return jsonify([u.to_dict() for u in users])
    """
    db = SessionLocal()
    try:
        return db
    finally:
        pass  # Session will be closed by caller


# ============================================================================
# DATABASE UTILITIES
# ============================================================================

def check_database_connection():
    """Check if database connection is working"""
    try:
        from sqlalchemy import text
        with get_db_session() as session:
            session.execute(text('SELECT 1'))
        return True, "Database connection successful"
    except Exception as e:
        return False, f"Database connection failed: {str(e)}"


def get_database_stats():
    """Get database statistics"""
    try:
        with get_db_session() as session:
            from core.models import User, APIKey, CheckHistory, AuditLog, CustomRule
            
            stats = {
                'users': session.query(User).count(),
                'active_users': session.query(User).filter_by(is_active=True).count(),
                'api_keys': session.query(APIKey).count(),
                'active_api_keys': session.query(APIKey).filter_by(is_active=True).count(),
                'checks': session.query(CheckHistory).count(),
                'audit_logs': session.query(AuditLog).count(),
                'custom_rules': session.query(CustomRule).count(),
            }
            
            return stats
    except Exception as e:
        logger.error(f"Failed to get database stats: {str(e)}")
        return {}


def cleanup_old_audit_logs(days=90):
    """
    Clean up audit logs older than specified days
    
    Args:
        days: Number of days to retain (default: 90)
    
    Returns:
        Number of deleted records
    """
    try:
        from datetime import datetime, timedelta
        from core.models import AuditLog
        
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        with get_db_session() as session:
            deleted = session.query(AuditLog).filter(
                AuditLog.timestamp < cutoff_date
            ).delete()
            
            logger.info(f"Deleted {deleted} audit log records older than {days} days")
            return deleted
    except Exception as e:
        logger.error(f"Failed to cleanup audit logs: {str(e)}")
        return 0


# ============================================================================
# EVENT LISTENERS
# ============================================================================

@event.listens_for(engine, "connect")
def set_sqlite_pragma(dbapi_conn, connection_record):
    """Enable foreign keys for SQLite"""
    if config.database_url.startswith('sqlite'):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()


@event.listens_for(engine, "checkin")
def receive_checkin(dbapi_conn, connection_record):
    """Log when connection is returned to pool"""
    logger.debug("Connection returned to pool")


# ============================================================================
# MIGRATION UTILITIES
# ============================================================================

def migrate_from_json():
    """
    Migrate data from JSON files to database
    This should be run once when transitioning from file-based to database storage
    """
    import json
    import bcrypt
    from core.models import User, APIKey, UserRole
    
    logger.info("Starting migration from JSON files to database...")
    
    try:
        with get_db_session() as session:
            # Migrate users
            if os.path.exists('users.json'):
                with open('users.json', 'r', encoding='utf-8') as f:
                    users_data = json.load(f)
                
                for username, data in users_data.items():
                    # Check if user already exists
                    existing = session.query(User).filter_by(username=username).first()
                    if existing:
                        logger.info(f"User {username} already exists, skipping")
                        continue
                    
                    # Determine role (default to developer for existing users)
                    role = UserRole.ADMIN if username == 'admin' else UserRole.DEVELOPER
                    
                    user = User(
                        username=username,
                        email=data.get('email'),
                        phone=data.get('phone'),
                        password_hash=data.get('password_hash'),
                        role=role,
                        auth_method=data.get('auth_method', 'password'),
                        is_active=data.get('is_active', True),
                        created_at=datetime.fromisoformat(data['created_at']) if 'created_at' in data else datetime.utcnow()
                    )
                    session.add(user)
                    logger.info(f"Migrated user: {username}")
                
                session.flush()  # Flush to get user IDs
            
            # Migrate API keys
            if os.path.exists('api_keys.json'):
                with open('api_keys.json', 'r', encoding='utf-8') as f:
                    api_keys_data = json.load(f)
                
                for key, data in api_keys_data.items():
                    # Find user
                    user = session.query(User).filter_by(username=data['username']).first()
                    if not user:
                        logger.warning(f"User {data['username']} not found for API key, skipping")
                        continue
                    
                    # Hash the API key
                    key_hash = bcrypt.hashpw(key.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
                    key_prefix = key[:10] if len(key) > 10 else key
                    
                    api_key = APIKey(
                        key_hash=key_hash,
                        key_prefix=key_prefix,
                        user_id=user.id,
                        description=data.get('description', ''),
                        is_active=data.get('is_active', True),
                        created_at=datetime.fromisoformat(data['created_at']) if 'created_at' in data else datetime.utcnow(),
                        last_used=datetime.fromisoformat(data['last_used']) if data.get('last_used') else None,
                        usage_count=data.get('usage_count', 0)
                    )
                    session.add(api_key)
                    logger.info(f"Migrated API key for user: {data['username']}")
            
            session.commit()
            logger.info("Migration completed successfully!")
            return True
            
    except Exception as e:
        logger.error(f"Migration failed: {str(e)}")
        return False


if __name__ == '__main__':
    # Initialize database when run directly
    logging.basicConfig(level=logging.INFO)
    logger.info("Initializing database...")
    
    if init_db():
        logger.info("Database initialized successfully!")
        
        # Print stats
        stats = get_database_stats()
        logger.info(f"Database stats: {stats}")
        
        # Check connection
        success, message = check_database_connection()
        logger.info(message)
    else:
        logger.error("Failed to initialize database")
