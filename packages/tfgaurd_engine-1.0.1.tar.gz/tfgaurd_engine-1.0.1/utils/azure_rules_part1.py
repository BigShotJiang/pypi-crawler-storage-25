
# ============================================================================
# AZURE SECURITY RULES - PART 1
# Storage, Virtual Machines, SQL, Key Vault, AKS, App Service, NSG, CosmosDB
# ============================================================================

def storage_no_https(r):
    if not r.get('enable_https_traffic_only', True): return 'Azure Storage Account does not enforce HTTPS'
def storage_no_min_tls_1_2(r):
    if r.get('min_tls_version', 'TLS1_0') != 'TLS1_2': return 'Azure Storage Account minimum TLS version is not 1.2'
def storage_public_access(r):
    if r.get('public_network_access_enabled', True): return 'Azure Storage Account allows public network access'
def storage_blob_public_access(r):
    if r.get('allow_nested_items_to_be_public', True): return 'Azure Storage Account allows nested items to be public'
def storage_no_infrastructure_encryption(r):
    if not r.get('infrastructure_encryption_enabled', False): return 'Azure Storage Account infrastructure encryption not enabled'
def storage_shared_key_access(r):
    if r.get('shared_access_key_enabled', True): return 'Azure Storage Account shared key access is enabled - use Entra ID'

AZURE_STORAGE_RULES = [storage_no_https, storage_no_min_tls_1_2, storage_public_access, storage_blob_public_access, storage_no_infrastructure_encryption, storage_shared_key_access]

def vm_password_auth(r):
    if not r.get('disable_password_authentication', True): return 'Azure Linux VM has password authentication enabled - use SSH keys'
def vm_no_encrypted_disk(r):
    osd = r.get('os_disk', {}); osd = (osd[0] if isinstance(osd, list) and osd else osd) or {}
    if not osd.get('disk_encryption_set_id'): return 'Azure VM OS disk is not encrypted with CMK'
def vm_public_ip(r):
    if r.get('public_ip_address_id'): return 'Azure VM has a public IP address directly attached'

AZURE_VM_RULES = [vm_password_auth, vm_no_encrypted_disk, vm_public_ip]

def sql_no_auditing(r):
    if not r.get('extended_auditing_policy'): return 'Azure SQL Server does not have extended auditing configured'
def sql_no_aad_admin(r):
    if not r.get('azuread_administrator'): return 'Azure SQL Server uses SQL admin instead of Entra ID admin'
def sql_public_access(r):
    if r.get('public_network_access_enabled', True): return 'Azure SQL Server allows public network access'
def sql_tls_version(r):
    if r.get('minimum_tls_version', '1.0') != '1.2': return 'Azure SQL minimum TLS version is not 1.2'

AZURE_SQL_RULES = [sql_no_auditing, sql_no_aad_admin, sql_public_access, sql_tls_version]

def kv_purge_protection(r):
    if not r.get('purge_protection_enabled', False): return 'Azure Key Vault purge protection disabled - data loss risk'
def kv_soft_delete(r):
    if not r.get('soft_delete_retention_days'): return 'Azure Key Vault soft delete is not configured'
def kv_public_access(r):
    n = r.get('network_acls', {}); n = (n[0] if isinstance(n, list) and n else n) or {}
    if n.get('default_action', 'Allow') == 'Allow': return 'Azure Key Vault network ACLs allow default public access'
def kv_rbac_auth(r):
    if not r.get('enable_rbac_authorization', False): return 'Azure Key Vault does not use RBAC for authorization'

AZURE_KV_RULES = [kv_purge_protection, kv_soft_delete, kv_public_access, kv_rbac_auth]

def aks_rbac(r):
    if not r.get('role_based_access_control_enabled', True): return 'Azure AKS cluster RBAC is disabled'
def aks_private_cluster(r):
    if not r.get('private_cluster_enabled', False): return 'Azure AKS cluster is not private'
def aks_local_account(r):
    if r.get('local_account_disabled', False) == False: return 'Azure AKS allows local accounts - disable and use Entra ID'
def aks_network_policy(r):
    np = r.get('network_profile', {}); np = (np[0] if isinstance(np, list) and np else np) or {}
    if not np.get('network_policy'): return 'Azure AKS does not have a network policy configured'
def aks_api_server_authorized_ip_ranges(r):
    api = r.get('api_server_access_profile', {}); api = (api[0] if isinstance(api, list) and api else api) or {}
    if not api.get('authorized_ip_ranges'): return 'Azure AKS API server is open to any IP (0.0.0.0/0)'

AZURE_AKS_RULES = [aks_rbac, aks_private_cluster, aks_local_account, aks_network_policy, aks_api_server_authorized_ip_ranges]

def app_service_https_only(r):
    if not r.get('https_only', False): return 'Azure App Service allows HTTP traffic'
def app_service_tls_version(r):
    sc = r.get('site_config', {}); sc = (sc[0] if isinstance(sc, list) and sc else sc) or {}
    if str(sc.get('min_tls_version', '1.0')) != '1.2': return 'Azure App Service minimum TLS is not 1.2'
def app_service_client_cert(r):
    if not r.get('client_cert_enabled', False): return 'Azure App Service does not require client certificates (mTLS)'
def app_service_auth(r):
    auth = r.get('auth_settings_v2', {}); auth = (auth[0] if isinstance(auth, list) and auth else auth) or {}
    if not auth.get('auth_enabled', False): return 'Azure App Service authentication/authorization is not enabled'

AZURE_APP_SERVICE_RULES = [app_service_https_only, app_service_tls_version, app_service_client_cert, app_service_auth]

def nsg_rdp_open(r):
    for sec in (r.get('security_rule') or []):
        if not isinstance(sec, dict): continue
        if sec.get('access') == 'Allow' and sec.get('direction') == 'Inbound' and str(sec.get('destination_port_range')) in ['3389', '*']:
            s = sec.get('source_address_prefix', '')
            if s in ['*', 'Internet', '0.0.0.0/0']: return 'Azure NSG allows open RDP (port 3389)'
def nsg_ssh_open(r):
    for sec in (r.get('security_rule') or []):
        if not isinstance(sec, dict): continue
        if sec.get('access') == 'Allow' and sec.get('direction') == 'Inbound' and str(sec.get('destination_port_range')) in ['22', '*']:
            s = sec.get('source_address_prefix', '')
            if s in ['*', 'Internet', '0.0.0.0/0']: return 'Azure NSG allows open SSH (port 22)'

AZURE_NSG_RULES = [nsg_rdp_open, nsg_ssh_open]

def cosmos_public_access(r):
    if r.get('public_network_access_enabled', True): return 'Azure CosmosDB allows public network access'
def cosmos_local_auth(r):
    if not r.get('local_authentication_disabled', False): return 'Azure CosmosDB local authentication is enabled'

AZURE_COSMOSDB_RULES = [cosmos_public_access, cosmos_local_auth]

AZURE_RULES_MAP = {
    'azurerm_storage_account': AZURE_STORAGE_RULES,
    'azurerm_linux_virtual_machine': AZURE_VM_RULES,
    'azurerm_windows_virtual_machine': AZURE_VM_RULES,
    'azurerm_mssql_server': AZURE_SQL_RULES,
    'azurerm_key_vault': AZURE_KV_RULES,
    'azurerm_kubernetes_cluster': AZURE_AKS_RULES,
    'azurerm_linux_web_app': AZURE_APP_SERVICE_RULES,
    'azurerm_windows_web_app': AZURE_APP_SERVICE_RULES,
    'azurerm_network_security_group': AZURE_NSG_RULES,
    'azurerm_cosmosdb_account': AZURE_COSMOSDB_RULES
}
