
# ============================================================================
# GCP SECURITY RULES - PART 4
# Cloud Redis, Cloud Spanner, App Engine, VPC Peering, Cloud Armor, IAM refined
# ============================================================================

# ── CLOUD REDIS ──────────────────────────────────────────────────────────────
def redis_no_auth(r):
    if not r.get('auth_enabled', False): return 'Cloud Redis auth (AUTH string) not enabled - cluster is open to any connected client'
def redis_no_transit_encryption(r):
    if r.get('transit_encryption_mode') != 'SERVER_AUTHENTICATION': return 'Cloud Redis transit encryption (TLS) not enabled - HIGH RISK'
def redis_basic_tier(r):
    if r.get('tier', 'BASIC') == 'BASIC': return 'Cloud Redis uses BASIC tier - no high availability or failover'
def redis_no_labels(r):
    if not r.get('labels'): return 'Cloud Redis instance has no labels'
def redis_no_cmek(r):
    if not r.get('customer_managed_key'): return 'Cloud Redis not encrypted with CMEK'
def redis_old_version(r):
    v = r.get('redis_version', 'REDIS_5_0')
    if '5_0' in v or '4_0' in v or '3_2' in v: return f'Cloud Redis version {v} is deprecated - upgrade to REDIS_6_X or newer'

GCP_REDIS_RULES = [redis_no_auth, redis_no_transit_encryption, redis_basic_tier, redis_no_labels, redis_no_cmek, redis_old_version]

# ── CLOUD SPANNER ────────────────────────────────────────────────────────────
def spanner_no_cmek(r):
    enc = r.get('encryption_config', {}); enc = (enc[0] if isinstance(enc, list) and enc else enc) or {}
    if not enc.get('kms_key_name'): return 'Cloud Spanner instance not encrypted with CMEK'
def spanner_no_labels(r):
    if not r.get('labels'): return 'Cloud Spanner instance has no labels'
def spanner_public_access(r):
    if 'roles/spanner.databaseReader' in str(r.get('role')) and ('allUsers' in str(r.get('members')) or 'allAuthenticatedUsers' in str(r.get('members'))):
        return 'Cloud Spanner database allows public read access - CRITICAL RISK'
def spanner_delete_protection_off(r):
    if r.get('enable_drop_protection', False) == False: return 'Cloud Spanner drop protection disabled - accidental database deletion risk'

GCP_SPANNER_RULES = [spanner_no_cmek, spanner_no_labels, spanner_public_access, spanner_delete_protection_off]

# ── MEMCACHE ─────────────────────────────────────────────────────────────────
def memcache_no_nodes(r):
    if int(r.get('node_count', 0) or 0) < 2: return 'Cloud Memcache has < 2 nodes - no high availability'
def memcache_no_labels(r):
    if not r.get('labels'): return 'Cloud Memcache intance has no labels'

GCP_MEMCACHE_RULES = [memcache_no_nodes, memcache_no_labels]

# ── APP ENGINE ───────────────────────────────────────────────────────────────
def gae_no_iap(r):
    iap = r.get('iap', {}); iap = (iap[0] if isinstance(iap, list) and iap else iap) or {}
    if not iap.get('enabled', False): return 'App Engine application does not have Identity-Aware Proxy (IAP) enabled'
def gae_env_secrets(r):
    for k in (r.get('env_variables') or {}).keys():
        if any(s in str(k).lower() for s in ('key', 'secret', 'pass', 'token')): return f'App Engine env var {k} may be a secret - use Secret Manager'
def gae_no_vpc_access(r):
    if not r.get('vpc_access_connector'): return 'App Engine standard service has no VPC connector - cannot reach internal IPs'
def gae_egress_all(r):
    vpc = r.get('vpc_access_connector', {}); vpc = (vpc[0] if isinstance(vpc, list) and vpc else vpc) or {}
    if vpc and vpc.get('egress_setting') != 'ALL_TRAFFIC': return 'App Engine egress setting is not ALL_TRAFFIC - some traffic may bypass VPC controls'
def gae_default_sa(r):
    sa = r.get('service_account', '')
    if 'appspot.gserviceaccount.com' in sa: return 'App Engine uses default appspot service account - HIGH RISK'

GCP_GAE_RULES = [gae_no_iap, gae_env_secrets, gae_no_vpc_access, gae_egress_all, gae_default_sa]

# ── CLOUD ARMOR (SECURITY POLICY) ─────────────────────────────────────────────
def armor_default_allow(r):
    for rule in (r.get('rule') or []):
        if not isinstance(rule, dict): continue
        if rule.get('action') == 'allow' and rule.get('priority') == 2147483647:
            match = rule.get('match', {}); match = (match[0] if isinstance(match, list) and match else match) or {}
            config = match.get('config', {}); config = (config[0] if isinstance(config, list) and config else config) or {}
            if '*' in config.get('src_ip_ranges', []): return 'Cloud Armor policy default rule is ALLOW - prefer default DENY'
def armor_no_sqli(r):
    has_sqli = False
    for rule in (r.get('rule') or []):
        if not isinstance(rule, dict): continue
        match = rule.get('match', {}); match = (match[0] if isinstance(match, list) and match else match) or {}
        expr = match.get('expr', {}); expr = (expr[0] if isinstance(expr, list) and expr else expr) or {}
        if 'sqli' in str(expr.get('expression', '')): has_sqli = True
    if not has_sqli: return 'Cloud Armor policy has no preconfigured SQLi (SQL injection) protection rule'
def armor_no_xss(r):
    has_xss = False
    for rule in (r.get('rule') or []):
        if not isinstance(rule, dict): continue
        match = rule.get('match', {}); match = (match[0] if isinstance(match, list) and match else match) or {}
        expr = match.get('expr', {}); expr = (expr[0] if isinstance(expr, list) and expr else expr) or {}
        if 'xss' in str(expr.get('expression', '')): has_xss = True
    if not has_xss: return 'Cloud Armor policy has no preconfigured XSS (Cross-site scripting) protection rule'
def armor_no_lfi(r):
    has_lfi = False
    for rule in (r.get('rule') or []):
        if not isinstance(rule, dict): continue
        match = rule.get('match', {}); match = (match[0] if isinstance(match, list) and match else match) or {}
        expr = match.get('expr', {}); expr = (expr[0] if isinstance(expr, list) and expr else expr) or {}
        if 'lfi' in str(expr.get('expression', '')): has_lfi = True
    if not has_lfi: return 'Cloud Armor policy has no preconfigured LFI (Local File Inclusion) protection rule'

GCP_ARMOR_RULES = [armor_default_allow, armor_no_sqli, armor_no_xss, armor_no_lfi]

# ── VPC PEERING ──────────────────────────────────────────────────────────────
def vpc_peering_export_custom_routes(r):
    if r.get('export_custom_routes', False): return 'VPC Peering exports custom routes - review route propagation carefully to prevent IP spoofing or loops'
def vpc_peering_export_subnet_routes(r):
    if r.get('export_subnet_routes_with_public_ip', False): return 'VPC Peering exports subnet routes with public IPs - increases attack surface'

GCP_PEERING_RULES = [vpc_peering_export_custom_routes, vpc_peering_export_subnet_routes]

# ── IAM OVERLY PERMISSIVE ROLES ──────────────────────────────────────────────
def iam_network_admin(r):
    if str(r.get('role')) == 'roles/compute.networkAdmin' and not r.get('condition'): return 'GCP IAM grants compute.networkAdmin broadly - use condition or networkUser'
def iam_security_admin(r):
    if str(r.get('role')) == 'roles/iam.securityAdmin' and not r.get('condition'): return 'GCP IAM grants iam.securityAdmin without condition - allows full IAM modification bypass'
def iam_org_policy_admin(r):
    if str(r.get('role')) == 'roles/orgpolicy.policyAdmin' and not r.get('condition'): return 'GCP IAM grants Org Policy Admin without condition - allows bypassing all org constraints'
def iam_kms_admin(r):
    if str(r.get('role')) == 'roles/cloudkms.admin' and not r.get('condition'): return 'GCP IAM grants KMS Admin without condition - allows disabling/destroying KMS keys'
def iam_service_account_user(r):
    if str(r.get('role')) == 'roles/iam.serviceAccountUser' and 'user:' in str(r.get('members', [])): return 'GCP IAM grants ServiceAccountUser to a human User instead of a compute entity'

GCP_IAM_REFINED_RULES = [iam_network_admin, iam_security_admin, iam_org_policy_admin, iam_kms_admin, iam_service_account_user]

# ── BIGTABLE ─────────────────────────────────────────────────────────────────
def bigtable_no_cmek(r):
    cluster = r.get('cluster', [])
    for c in cluster:
        if isinstance(c, dict) and not c.get('kms_key_name'): return 'Cloud Bigtable cluster not encrypted with CMEK'
def bigtable_single_node(r):
    cluster = r.get('cluster', [])
    for c in cluster:
        if isinstance(c, dict) and int(c.get('num_nodes', 0) or 0) < 3: return 'Cloud Bigtable cluster has < 3 nodes - not suitable for production HA'
def bigtable_no_deletion_protection(r):
    if not r.get('deletion_protection', False): return 'Cloud Bigtable instance deletion protection disabled - data loss risk'

GCP_BIGTABLE_RULES = [bigtable_no_cmek, bigtable_single_node, bigtable_no_deletion_protection]

# ── DATAFLOW ─────────────────────────────────────────────────────────────────
def dataflow_public_ips(r):
    if not r.get('ip_configuration') == 'WORKER_IP_PRIVATE': return 'Dataflow workers not explicitly set to private IPs only'
def dataflow_no_cmek(r):
    if not r.get('kms_key_name'): return 'Dataflow job not encrypted with CMEK'
def dataflow_default_sa(r):
    if not r.get('service_account_email'): return 'Dataflow job uses default compute service account - grant specialized service account'

GCP_DATAFLOW_RULES = [dataflow_public_ips, dataflow_no_cmek, dataflow_default_sa]

# ── CLOUD BUILD ─────────────────────────────────────────────────────────────
def build_no_logs_bucket(r):
    steps = r.get('step', [])
    if steps and not r.get('logs_bucket'): return 'Cloud Build job stores logs in default bucket (Google-owned) - specify custom bucket for retention'
def build_default_sa(r):
    if not r.get('service_account'): return 'Cloud Build job uses default Cloud Build service account - grant specialized minimal IAM service account'

GCP_CLOUDBUILD_RULES = [build_no_logs_bucket, build_default_sa]
