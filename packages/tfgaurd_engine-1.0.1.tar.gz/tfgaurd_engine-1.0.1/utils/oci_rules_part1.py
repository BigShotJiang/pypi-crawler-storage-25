
# ============================================================================
# OCI SECURITY RULES - PART 1
# Object Storage, Compute, Block Volume, VCN, Database, Identity
# ============================================================================

def os_public_access(r):
    if r.get('access_type', 'NoPublicAccess') != 'NoPublicAccess': return 'OCI Object Storage Bucket is public'
def os_versioning(r):
    if r.get('versioning', 'Disabled') != 'Enabled': return 'OCI Object Storage Bucket versioning is not enabled'
def os_kms_key(r):
    if not r.get('kms_key_id'): return 'OCI Object Storage Bucket not encrypted with customer managed key'

OCI_OS_RULES = [os_public_access, os_versioning, os_kms_key]

def compute_monitoring(r):
    aa = r.get('agent_config', {}); aa = (aa[0] if isinstance(aa, list) and aa else aa) or {}
    if not aa.get('is_monitoring_disabled', False) == False: return 'OCI Compute Instance monitoring disabled'
def compute_legacy_endpoint(r):
    io = r.get('instance_options', {}); io = (io[0] if isinstance(io, list) and io else io) or {}
    if io.get('are_legacy_imds_endpoints_disabled', False) == False: return 'OCI Compute Instance legacy IMDS endpoints enabled - SSRF risk'

OCI_COMPUTE_RULES = [compute_monitoring, compute_legacy_endpoint]

def bv_kms_key(r):
    if not r.get('kms_key_id'): return 'OCI Block Volume not encrypted with customer managed key'
def bv_backup_policy(r):
    if not r.get('backup_policy_id'): return 'OCI Block Volume has no backup policy'

OCI_BV_RULES = [bv_kms_key, bv_backup_policy]

def db_public_access(r):
    if r.get('is_public', True): return 'OCI Autonomous Database is publicly accessible'
def db_mtls_required(r):
    if not r.get('is_mtls_connection_required', False): return 'OCI Autonomous Database does not require mTLS'

OCI_DB_RULES = [db_public_access, db_mtls_required]

def vcn_no_ipv6(r):
    if r.get('is_ipv6enabled', False): return 'OCI VCN has IPv6 enabled - ensure rules are configured for v6'

def subnet_public(r):
    if not r.get('prohibit_public_ip_on_vnic', False): return 'OCI Subnet permits public IPs'

OCI_VCN_RULES = [vcn_no_ipv6]
OCI_SUBNET_RULES = [subnet_public]

def iam_password_policy(r):
    pl = r.get('password_policy', {}); pl = (pl[0] if isinstance(pl, list) and pl else pl) or {}
    if not pl: return 'OCI IAM Authentication Policy has no complex password rules'

OCI_IAM_RULES = [iam_password_policy]

OCI_RULES_MAP = {
    'oci_objectstorage_bucket': OCI_OS_RULES,
    'oci_core_instance': OCI_COMPUTE_RULES,
    'oci_core_volume': OCI_BV_RULES,
    'oci_core_vcn': OCI_VCN_RULES,
    'oci_core_subnet': OCI_SUBNET_RULES,
    'oci_database_autonomous_database': OCI_DB_RULES,
    'oci_identity_authentication_policy': OCI_IAM_RULES
}
