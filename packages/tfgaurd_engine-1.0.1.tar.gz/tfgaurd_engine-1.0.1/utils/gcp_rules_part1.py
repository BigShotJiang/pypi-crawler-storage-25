
# ============================================================================
# GCP SECURITY RULES - PART 1
# Cloud Storage, Compute Engine, Firewall, Disk, Snapshot, VPC, Subnet
# ============================================================================

# ── CLOUD STORAGE BUCKET ────────────────────────────────────────────────────
def gcs_no_uniform_access(r):
    ua = r.get('uniform_bucket_level_access', r.get('uniform_access', False))
    if not ua: return 'GCS bucket has no uniform bucket-level access - ACL bypasses IAM'
def gcs_public_all_users(r):
    for m in (r.get('member') or []):
        if m in ('allUsers', 'allAuthenticatedUsers'): return f'GCS bucket grants access to {m} - CRITICAL: public data exposure'
def gcs_no_versioning(r):
    v = r.get('versioning', {}); v = (v[0] if isinstance(v, list) and v else v) or {}
    if not v.get('enabled', False): return 'GCS bucket versioning not enabled - no object history'
def gcs_no_logging(r):
    l = r.get('logging', {}); l = (l[0] if isinstance(l, list) and l else l) or {}
    if not l: return 'GCS bucket access logging disabled - HIGH RISK'
def gcs_no_encryption(r):
    e = r.get('encryption', {}); e = (e[0] if isinstance(e, list) and e else e) or {}
    if not e.get('default_kms_key_name'): return 'GCS bucket not encrypted with CMEK - uses Google-managed keys'
def gcs_no_retention_policy(r):
    rp = r.get('retention_policy', {}); rp = (rp[0] if isinstance(rp, list) and rp else rp) or {}
    if not rp: return 'GCS bucket has no retention policy - data may be deleted prematurely'
def gcs_no_lifecycle(r):
    lc = r.get('lifecycle_rule', []) or []
    if not lc: return 'GCS bucket has no lifecycle rules - storage costs not managed'
def gcs_no_labels(r):
    if not r.get('labels'): return 'GCS bucket has no labels - cost governance issue'
def gcs_public_access_prevention_off(r):
    pa = r.get('public_access_prevention', '')
    if pa != 'enforced': return 'GCS public access prevention not enforced'
def gcs_no_cors(r):
    if r.get('website') and not r.get('cors'): return 'GCS website bucket has no CORS policy configured'
def gcs_default_acl_public(r):
    if r.get('default_acl', '') in ('publicRead', 'publicReadWrite'): return f'GCS default ACL is {r.get("default_acl")} - CRITICAL: public read'
def gcs_requester_pays_off(r):
    if not r.get('requester_pays', False): return 'GCS requester-pays not enabled - egress costs on bucket owner'
def gcs_old_storage_class(r):
    if r.get('storage_class') == 'NEARLINE' and not r.get('lifecycle_rule'):
        return 'GCS NEARLINE without lifecycle - consider STANDARD with lifecycle for flexibility'
def gcs_no_object_creation_notification(r):
    if not r.get('notification'): return 'GCS bucket has no Pub/Sub notification - no real-time object events'
def gcs_no_soft_delete(r):
    sd = r.get('soft_delete_policy', {}); sd = (sd[0] if isinstance(sd, list) and sd else sd) or {}
    if not sd.get('retention_duration_seconds'): return 'GCS soft delete policy not configured - accidental deletion risk'
def gcs_cross_project_access(r):
    iam = str(r.get('binding', '') or r.get('iam_policy', '') or '')
    if 'serviceAccount' in iam and '@' in iam and '.iam.gserviceaccount.com' in iam:
        return 'GCS bucket has service account cross-project IAM bindings - review access'
def gcs_no_object_versioning_limit(r):
    v = r.get('versioning', {}); v = (v[0] if isinstance(v, list) and v else v) or {}
    if v.get('enabled') and not r.get('lifecycle_rule'):
        return 'GCS versioning enabled but no lifecycle rule to expire old versions - runaway storage cost'
def gcs_autoclass_not_enabled(r):
    ac = r.get('autoclass', {}); ac = (ac[0] if isinstance(ac, list) and ac else ac) or {}
    if not ac.get('enabled', False): return 'GCS Autoclass not enabled - storage class not optimized automatically'
def gcs_no_custom_placement(r):
    if r.get('location', '').upper() in ('US', 'EU', 'ASIA'):
        return f'GCS bucket uses multi-region location {r.get("location")} - consider region for data residency'
def gcs_website_index_missing(r):
    w = r.get('website', {}); w = (w[0] if isinstance(w, list) and w else w) or {}
    if w and not w.get('main_page_suffix'): return 'GCS website bucket has no index page configured'

GCS_RULES = [
    gcs_no_uniform_access, gcs_public_all_users, gcs_no_versioning, gcs_no_logging,
    gcs_no_encryption, gcs_no_retention_policy, gcs_no_lifecycle, gcs_no_labels,
    gcs_public_access_prevention_off, gcs_no_cors, gcs_default_acl_public,
    gcs_requester_pays_off, gcs_old_storage_class, gcs_no_object_creation_notification,
    gcs_no_soft_delete, gcs_cross_project_access, gcs_no_object_versioning_limit,
    gcs_autoclass_not_enabled, gcs_no_custom_placement, gcs_website_index_missing,
]

# ── COMPUTE INSTANCE ─────────────────────────────────────────────────────────
def gce_public_ip(r):
    for ni in (r.get('network_interface') or []):
        if isinstance(ni, dict) and ni.get('access_config'): return 'GCE instance has public IP - HIGH RISK: limit exposure'
def gce_no_shielded_vm(r):
    sv = r.get('shielded_instance_config', {}); sv = (sv[0] if isinstance(sv, list) and sv else sv) or {}
    if not sv.get('enable_secure_boot', False): return 'GCE Shielded VM secure boot not enabled'
def gce_no_vtpm(r):
    sv = r.get('shielded_instance_config', {}); sv = (sv[0] if isinstance(sv, list) and sv else sv) or {}
    if not sv.get('enable_vtpm', False): return 'GCE Shielded VM vTPM not enabled'
def gce_no_integrity_monitoring(r):
    sv = r.get('shielded_instance_config', {}); sv = (sv[0] if isinstance(sv, list) and sv else sv) or {}
    if not sv.get('enable_integrity_monitoring', False): return 'GCE integrity monitoring not enabled'
def gce_default_sa(r):
    sa = r.get('service_account', {}); sa = (sa[0] if isinstance(sa, list) and sa else sa) or {}
    email = sa.get('email', '')
    if 'compute@developer.gserviceaccount.com' in str(email): return 'GCE uses default compute service account - HIGH RISK'
def gce_full_cloud_api_access(r):
    sa = r.get('service_account', {}); sa = (sa[0] if isinstance(sa, list) and sa else sa) or {}
    if 'cloud-platform' in str(sa.get('scopes', [])): return 'GCE has cloud-platform scope - grants all GCP API access'
def gce_no_deletion_protection(r):
    if not r.get('deletion_protection', False): return 'GCE deletion protection not enabled'
def gce_no_labels(r):
    if not r.get('labels'): return 'GCE instance has no labels - governance issue'
def gce_ssh_keys_in_metadata(r):
    meta = str(r.get('metadata', {}) or {})
    if 'ssh-keys' in meta or 'sshKeys' in meta: return 'GCE instance has SSH keys in metadata - use OS Login instead'
def gce_os_login_disabled(r):
    meta = r.get('metadata', {}) or {}
    if isinstance(meta, list): meta = meta[0] if meta else {}
    if str(meta.get('enable-oslogin', 'false')).lower() != 'true': return 'GCE OS Login not enabled - prefer over SSH key metadata'
def gce_serial_port_enabled(r):
    meta = r.get('metadata', {}) or {}
    if isinstance(meta, list): meta = meta[0] if meta else {}
    if str(meta.get('serial-port-enable', '0')) == '1': return 'GCE serial port access enabled - diagnostic risk'
def gce_boot_disk_no_encryption(r):
    bd = r.get('boot_disk', {}); bd = (bd[0] if isinstance(bd, list) and bd else bd) or {}
    if not bd.get('disk_encryption_key') and not bd.get('kms_key_self_link'): return 'GCE boot disk not encrypted with CMEK'
def gce_preemptible_production(r):
    sc = r.get('scheduling', {}); sc = (sc[0] if isinstance(sc, list) and sc else sc) or {}
    if sc.get('preemptible', False): return 'GCE instance is preemptible - not suitable for production workloads'
def gce_no_startup_script_validation(r):
    meta = r.get('metadata', {}) or {}
    if isinstance(meta, list): meta = meta[0] if meta else {}
    if meta.get('startup-script') and not meta.get('startup-script-checksum'):
        return 'GCE startup script has no integrity check'
def gce_no_tags(r):
    if not r.get('tags'): return 'GCE instance has no network tags - cannot target with firewall rules'
def gce_no_monitoring_agent(r):
    meta = r.get('metadata', {}) or {}
    if isinstance(meta, list): meta = meta[0] if meta else {}
    if not meta.get('google-monitoring-enabled'): return 'GCE monitoring agent not enabled via metadata'
def gce_no_logging_agent(r):
    meta = r.get('metadata', {}) or {}
    if isinstance(meta, list): meta = meta[0] if meta else {}
    if not meta.get('google-logging-enabled'): return 'GCE logging agent not enabled via metadata'
def gce_ip_forwarding_enabled(r):
    if r.get('can_ip_forward', False): return 'GCE IP forwarding enabled - only required for routers/VPNs'
def gce_no_snapshot_policy(r):
    if not r.get('resource_policy') and not r.get('attached_disk'): return 'GCE instance has no snapshot schedule - no backup protection'
def gce_old_machine_type(r):
    mt = r.get('machine_type', '')
    if mt.startswith('n1-') and 'standard' in mt: return f'GCE machine type {mt} is N1 - consider N2/N2D for better price-performance'
def gce_no_confidential_vm(r):
    cv = r.get('confidential_instance_config', {}); cv = (cv[0] if isinstance(cv, list) and cv else cv) or {}
    if not cv.get('enable_confidential_compute', False): return 'GCE Confidential Computing not enabled for sensitive workloads'
def gce_no_sole_tenancy_affinity(r):
    na = r.get('node_affinities', []) or []
    if not na and r.get('_requires_sole_tenancy'): return 'GCE sole tenancy affinity not configured'
def gce_windows_no_password_disabled(r):
    meta = r.get('metadata', {}) or {}
    if isinstance(meta, list): meta = meta[0] if meta else {}
    if str(meta.get('windows-startup-script-ps1', '')).lower().find('password') >= 0:
        return 'GCE Windows instance may have password in metadata startup script'
def gce_no_resource_manager_tags(r):
    if not r.get('resource_manager_tags'): return 'GCE instance has no resource manager tags for policy enforcement'
def gce_http_enabled(r):
    if r.get('allow_stopping_for_update', True) and r.get('tags') and 'http-server' in (r.get('tags') or []):
        return 'GCE instance has http-server tag - HTTP traffic allowed'

GCE_RULES = [
    gce_public_ip, gce_no_shielded_vm, gce_no_vtpm, gce_no_integrity_monitoring,
    gce_default_sa, gce_full_cloud_api_access, gce_no_deletion_protection, gce_no_labels,
    gce_ssh_keys_in_metadata, gce_os_login_disabled, gce_serial_port_enabled,
    gce_boot_disk_no_encryption, gce_preemptible_production, gce_no_startup_script_validation,
    gce_no_tags, gce_no_monitoring_agent, gce_no_logging_agent, gce_ip_forwarding_enabled,
    gce_no_snapshot_policy, gce_old_machine_type, gce_no_confidential_vm,
    gce_no_sole_tenancy_affinity, gce_windows_no_password_disabled,
    gce_no_resource_manager_tags, gce_http_enabled,
]

# ── COMPUTE FIREWALL ─────────────────────────────────────────────────────────
def fw_ssh_open(r):
    for a in (r.get('allow') or []):
        if not isinstance(a, dict): continue
        if '0.0.0.0/0' in (r.get('source_ranges') or []) and '22' in str(a.get('ports', [])):
            return 'GCP Firewall allows SSH (22) from 0.0.0.0/0 - CRITICAL RISK'
def fw_rdp_open(r):
    for a in (r.get('allow') or []):
        if not isinstance(a, dict): continue
        if '0.0.0.0/0' in (r.get('source_ranges') or []) and '3389' in str(a.get('ports', [])):
            return 'GCP Firewall allows RDP (3389) from 0.0.0.0/0 - CRITICAL RISK'
def fw_all_ingress_open(r):
    if '0.0.0.0/0' in (r.get('source_ranges') or []) and r.get('direction', 'INGRESS') == 'INGRESS':
        for a in (r.get('allow') or []):
            if isinstance(a, dict) and a.get('protocol') == 'all': return 'GCP Firewall allows ALL protocols from internet - CRITICAL RISK'
def fw_no_description(r):
    if not r.get('description'): return 'GCP Firewall rule has no description'
def fw_no_target_tags(r):
    if not r.get('target_tags') and not r.get('target_service_accounts'): return 'GCP Firewall applies to all instances - use target tags to scope'
def fw_icmp_open(r):
    if '0.0.0.0/0' in (r.get('source_ranges') or []):
        for a in (r.get('allow') or []):
            if isinstance(a, dict) and a.get('protocol') == 'icmp': return 'GCP Firewall allows ICMP from internet - network reconnaissance risk'
def fw_high_priority(r):
    if int(r.get('priority', 1000) or 1000) < 100: return f'GCP Firewall priority {r.get("priority")} is very high - may override security rules'
def fw_disabled(r):
    if r.get('disabled', False): return 'GCP Firewall rule is disabled - review if intentional'
def fw_egress_all_open(r):
    if r.get('direction') == 'EGRESS' and '0.0.0.0/0' in (r.get('destination_ranges') or []):
        for a in (r.get('allow') or []):
            if isinstance(a, dict) and a.get('protocol') == 'all': return 'GCP Firewall allows all egress - restrict outbound traffic'
def fw_mysql_open(r):
    if '0.0.0.0/0' in (r.get('source_ranges') or []):
        for a in (r.get('allow') or []):
            if isinstance(a, dict) and '3306' in str(a.get('ports', [])): return 'GCP Firewall allows MySQL (3306) from internet - CRITICAL RISK'
def fw_postgres_open(r):
    if '0.0.0.0/0' in (r.get('source_ranges') or []):
        for a in (r.get('allow') or []):
            if isinstance(a, dict) and '5432' in str(a.get('ports', [])): return 'GCP Firewall allows PostgreSQL (5432) from internet - CRITICAL RISK'
def fw_redis_open(r):
    if '0.0.0.0/0' in (r.get('source_ranges') or []):
        for a in (r.get('allow') or []):
            if isinstance(a, dict) and '6379' in str(a.get('ports', [])): return 'GCP Firewall allows Redis (6379) from internet - CRITICAL RISK'
def fw_mongodb_open(r):
    if '0.0.0.0/0' in (r.get('source_ranges') or []):
        for a in (r.get('allow') or []):
            if isinstance(a, dict) and '27017' in str(a.get('ports', [])): return 'GCP Firewall allows MongoDB (27017) from internet - CRITICAL RISK'
def fw_telnet_open(r):
    if '0.0.0.0/0' in (r.get('source_ranges') or []):
        for a in (r.get('allow') or []):
            if isinstance(a, dict) and '23' in str(a.get('ports', [])): return 'GCP Firewall allows Telnet (23) from internet - CRITICAL RISK'
def fw_ftp_open(r):
    if '0.0.0.0/0' in (r.get('source_ranges') or []):
        for a in (r.get('allow') or []):
            if isinstance(a, dict) and '21' in str(a.get('ports', [])): return 'GCP Firewall allows FTP (21) from internet - CRITICAL RISK'
def fw_elasticsearch_open(r):
    if '0.0.0.0/0' in (r.get('source_ranges') or []):
        for a in (r.get('allow') or []):
            if isinstance(a, dict) and ('9200' in str(a.get('ports', [])) or '9300' in str(a.get('ports', []))):
                return 'GCP Firewall allows Elasticsearch from internet - CRITICAL RISK'
def fw_kafka_open(r):
    if '0.0.0.0/0' in (r.get('source_ranges') or []):
        for a in (r.get('allow') or []):
            if isinstance(a, dict) and '9092' in str(a.get('ports', [])): return 'GCP Firewall allows Kafka (9092) from internet - CRITICAL RISK'
def fw_no_deny_rule(r):
    if not r.get('deny') and r.get('allow'): return 'GCP Firewall has only allow rules - consider explicit deny rule'
def fw_http_open(r):
    if '0.0.0.0/0' in (r.get('source_ranges') or []):
        for a in (r.get('allow') or []):
            if isinstance(a, dict) and '80' in str(a.get('ports', [])): return 'GCP Firewall allows HTTP (80) from internet - use HTTPS'

GCE_FIREWALL_RULES = [
    fw_ssh_open, fw_rdp_open, fw_all_ingress_open, fw_no_description, fw_no_target_tags,
    fw_icmp_open, fw_high_priority, fw_disabled, fw_egress_all_open, fw_mysql_open,
    fw_postgres_open, fw_redis_open, fw_mongodb_open, fw_telnet_open, fw_ftp_open,
    fw_elasticsearch_open, fw_kafka_open, fw_no_deny_rule, fw_http_open,
]

# ── COMPUTE DISK ─────────────────────────────────────────────────────────────
def disk_no_encryption(r):
    if not r.get('disk_encryption_key') and not r.get('kms_key_self_link'): return 'GCE disk not encrypted with CMEK - uses Google-managed key'
def disk_no_labels(r):
    if not r.get('labels'): return 'GCE disk has no labels'
def disk_no_snapshot_policy(r):
    if not r.get('resource_policies'): return 'GCE disk has no snapshot schedule policy'
def disk_pd_standard(r):
    if r.get('type', '') == 'pd-standard': return 'GCE disk uses pd-standard - consider pd-ssd for production I/O'
def disk_no_description(r):
    if not r.get('description'): return 'GCE disk has no description'
def disk_size_too_large(r):
    if int(r.get('size', 0) or 0) > 2000: return f'GCE disk size {r.get("size")}GB is very large - verify allocation'
def disk_multi_writer(r):
    if r.get('multi_writer', False): return 'GCE disk multi-writer enabled - only for clustered workloads'
def disk_no_physical_block_size(r):
    if not r.get('physical_block_size_bytes'): return 'GCE disk physical block size not set - may affect I/O alignment'
def disk_not_regional(r):
    if not r.get('replica_zones'): return 'GCE disk is not regional (no replica zones) - single-zone failure risk'

GCE_DISK_RULES = [
    disk_no_encryption, disk_no_labels, disk_no_snapshot_policy, disk_pd_standard,
    disk_no_description, disk_size_too_large, disk_multi_writer,
    disk_no_physical_block_size, disk_not_regional,
]

# ── COMPUTE SNAPSHOT ─────────────────────────────────────────────────────────
def snap_no_encryption(r):
    if not r.get('snapshot_encryption_key') and not r.get('kms_key_self_link'): return 'GCE snapshot not encrypted with CMEK'
def snap_no_labels(r):
    if not r.get('labels'): return 'GCE snapshot has no labels'
def snap_public_shared(r):
    if r.get('sharing'): return 'GCE snapshot is shared publicly - review access'
def snap_no_description(r):
    if not r.get('description'): return 'GCE snapshot has no description'
def snap_chain_name_missing(r):
    if not r.get('chain_name'): return 'GCE snapshot has no chain name - incremental snapshot chain unidentified'

GCE_SNAPSHOT_RULES = [snap_no_encryption, snap_no_labels, snap_public_shared, snap_no_description, snap_chain_name_missing]

# ── COMPUTE NETWORK (VPC) ────────────────────────────────────────────────────
def net_auto_create_subnets(r):
    if r.get('auto_create_subnetworks', True): return 'GCP VPC auto-creates subnetworks - use custom mode for explicit control'
def net_no_description(r):
    if not r.get('description'): return 'GCP VPC network has no description'
def net_legacy_network(r):
    if r.get('gateway_ipv4') and not r.get('subnetworks'): return 'GCP legacy network in use - migrate to VPC'
def net_no_shared_vpc(r):
    if not r.get('_is_shared_vpc_host'): return 'GCP VPC not configured as Shared VPC - consider for multi-project isolation'
def net_no_firewall_policy(r):
    if not r.get('firewall_policy'): return 'GCP VPC has no hierarchical firewall policy attached'
def net_bgp_routing_dynamic_disabled(r):
    if r.get('routing_mode', 'REGIONAL') == 'REGIONAL': return 'GCP VPC routing mode is REGIONAL - consider GLOBAL for multi-region routing'
def net_no_private_google_access(r):
    if not r.get('enable_private_google_access'): return 'GCP VPC private Google Access not enabled at network level'
def net_delete_default_vpc(r):
    if r.get('name') == 'default': return 'GCP is using default VPC - delete default VPC and create custom VPCs'

GCE_NETWORK_RULES = [
    net_auto_create_subnets, net_no_description, net_legacy_network, net_no_shared_vpc,
    net_no_firewall_policy, net_bgp_routing_dynamic_disabled, net_no_private_google_access, net_delete_default_vpc,
]

# ── COMPUTE SUBNETWORK ───────────────────────────────────────────────────────
def subnet_no_private_google_access(r):
    if not r.get('private_ip_google_access', False): return 'GCP subnet private Google access not enabled - VMs need public IPs for GCP APIs'
def subnet_no_flow_logs(r):
    fl = r.get('log_config', {}); fl = (fl[0] if isinstance(fl, list) and fl else fl) or {}
    if not fl: return 'GCP subnet flow logs not enabled - no network visibility'
def subnet_flow_log_sampling_low(r):
    fl = r.get('log_config', {}); fl = (fl[0] if isinstance(fl, list) and fl else fl) or {}
    if fl and float(fl.get('flow_sampling', 0.5) or 0.5) < 0.5: return 'GCP subnet flow log sampling rate < 50% - reduce blind spots'
def subnet_no_secondary_ranges(r):
    if not r.get('secondary_ip_range'): return 'GCP subnet has no secondary IP ranges - GKE pods/services need secondary ranges'
def subnet_ipv4_only(r):
    if not r.get('ipv6_access_type'): return 'GCP subnet has no IPv6 configured - dual-stack not supported'
def subnet_purpose_not_set(r):
    if not r.get('purpose'): return 'GCP subnet purpose not set - internal load balancer or proxy subnets need explicit purpose'
def subnet_no_description(r):
    if not r.get('description'): return 'GCP subnet has no description'
def subnet_no_stack_type(r):
    if not r.get('stack_type'): return 'GCP subnet stack type not explicitly set'

GCE_SUBNET_RULES = [
    subnet_no_private_google_access, subnet_no_flow_logs, subnet_flow_log_sampling_low,
    subnet_no_secondary_ranges, subnet_ipv4_only, subnet_purpose_not_set,
    subnet_no_description, subnet_no_stack_type,
]

# ── COMPUTE ROUTER / NAT ─────────────────────────────────────────────────────
def router_no_bgp(r):
    bgp = r.get('bgp', {}); bgp = (bgp[0] if isinstance(bgp, list) and bgp else bgp) or {}
    if not bgp.get('asn'): return 'GCP Cloud Router has no BGP ASN configured'
def router_no_description(r):
    if not r.get('description'): return 'GCP Cloud Router has no description'
def nat_no_log_config(r):
    lc = r.get('log_config', {}); lc = (lc[0] if isinstance(lc, list) and lc else lc) or {}
    if not lc.get('enable', False): return 'GCP Cloud NAT logging not enabled'
def nat_no_min_ports_per_vm(r):
    if not r.get('min_ports_per_vm'): return 'GCP Cloud NAT min ports per VM not configured - SNAT exhaustion risk'
def nat_all_subnets_all_ips(r):
    if r.get('nat_ip_allocate_option') == 'AUTO_ONLY' and r.get('source_subnetwork_ip_ranges_to_nat') == 'ALL_SUBNETWORKS_ALL_IP_RANGES':
        return 'GCP Cloud NAT uses AUTO IP allocation with all subnets - consider MANUAL IPs'

GCE_ROUTER_RULES = [router_no_bgp, router_no_description, nat_no_log_config, nat_no_min_ports_per_vm, nat_all_subnets_all_ips]

# ── COMPUTE SSL POLICY ────────────────────────────────────────────────────────
def ssl_policy_compatible(r):
    if r.get('profile', 'COMPATIBLE') == 'COMPATIBLE': return 'GCP SSL policy uses COMPATIBLE profile - supports TLS 1.0/1.1, upgrade to MODERN or RESTRICTED'
def ssl_policy_no_min_tls(r):
    tls = r.get('min_tls_version', 'TLS_1_0')
    if tls in ('TLS_1_0', 'TLS_1_1'): return f'GCP SSL policy allows {tls} - minimum should be TLS_1_2'
def ssl_policy_no_description(r):
    if not r.get('description'): return 'GCP SSL policy has no description'

GCE_SSL_POLICY_RULES = [ssl_policy_compatible, ssl_policy_no_min_tls, ssl_policy_no_description]

# ── COMPUTE INSTANCE TEMPLATE ────────────────────────────────────────────────
def tmpl_public_ip(r):
    for ni in (r.get('network_interface') or []):
        if isinstance(ni, dict) and ni.get('access_config'): return 'GCE instance template has public IP - HIGH RISK'
def tmpl_default_sa(r):
    sa = r.get('service_account', {}); sa = (sa[0] if isinstance(sa, list) and sa else sa) or {}
    if 'compute@developer.gserviceaccount.com' in str(sa.get('email', '')): return 'GCE template uses default compute service account - CRITICAL RISK'
def tmpl_no_shielded_vm(r):
    sv = r.get('shielded_instance_config', {}); sv = (sv[0] if isinstance(sv, list) and sv else sv) or {}
    if not sv.get('enable_secure_boot', False): return 'GCE template Shielded VM not configured'
def tmpl_no_labels(r):
    if not r.get('labels'): return 'GCE instance template has no labels'
def tmpl_os_login_disabled(r):
    meta = r.get('metadata', {}) or {}
    if isinstance(meta, list): meta = meta[0] if meta else {}
    if str(meta.get('enable-oslogin', 'false')).lower() != 'true': return 'GCE template OS Login not enabled'
def tmpl_no_description(r):
    if not r.get('description'): return 'GCE instance template has no description'

GCE_INSTANCE_TEMPLATE_RULES = [tmpl_public_ip, tmpl_default_sa, tmpl_no_shielded_vm, tmpl_no_labels, tmpl_os_login_disabled, tmpl_no_description]

# ── COMPUTE BACKEND SERVICE ──────────────────────────────────────────────────
def bs_no_cdn(r):
    if not r.get('enable_cdn', False): return 'GCP Backend service CDN not enabled - consider for global caching'
def bs_no_health_check(r):
    if not r.get('health_checks'): return 'GCP Backend service has no health checks - traffic may reach unhealthy backends'
def bs_no_timeout(r):
    if not r.get('timeout_sec'): return 'GCP Backend service timeout not configured'
def bs_no_custom_request_headers(r):
    if not r.get('custom_request_headers'): return 'GCP Backend service has no custom request headers'
def bs_no_security_policy(r):
    if not r.get('security_policy'): return 'GCP Backend service has no Cloud Armor security policy - DDoS/WAF protection missing'
def bs_no_logging(r):
    ll = r.get('log_config', {}); ll = (ll[0] if isinstance(ll, list) and ll else ll) or {}
    if not ll.get('enable', False): return 'GCP Backend service access logging not enabled'
def bs_connection_draining_too_short(r):
    cd = r.get('connection_draining', {}); cd = (cd[0] if isinstance(cd, list) and cd else cd) or {}
    if int(cd.get('draining_timeout_sec', 0) or 0) < 60: return 'GCP Backend service connection draining < 60s - in-flight requests may be dropped'

GCE_BACKEND_SERVICE_RULES = [bs_no_cdn, bs_no_health_check, bs_no_timeout, bs_no_custom_request_headers, bs_no_security_policy, bs_no_logging, bs_connection_draining_too_short]

# ── COMPUTE LOAD BALANCER ────────────────────────────────────────────────────
def lb_no_ssl_policy(r):
    if not r.get('ssl_policy'): return 'GCP HTTPS LB has no SSL policy - uses default (allows TLS 1.0)'
def lb_no_https_redirect(r):
    if not r.get('_has_http_to_https_redirect'): return 'GCP LB has no HTTP to HTTPS redirect configured'
def lb_http_target(r):
    if r.get('url_map') and not r.get('ssl_certificates'): return 'GCP LB has no SSL certificates - traffic is plain HTTP'

GCE_LB_RULES = [lb_no_ssl_policy, lb_no_https_redirect, lb_http_target]

# ── MANAGED INSTANCE GROUP ────────────────────────────────────────────────────
def mig_no_health_checks(r):
    if not r.get('auto_healing_policies'): return 'GCE MIG has no auto-healing policies - unhealthy instances stay alive'
def mig_no_autoscaling(r):
    if not r.get('autoscaling_policy'): return 'GCE MIG has no autoscaling policy - no dynamic capacity'
def mig_no_update_policy(r):
    up = r.get('update_policy', {}); up = (up[0] if isinstance(up, list) and up else up) or {}
    if not up: return 'GCE MIG has no update policy configured - updates unstaged'
def mig_minimum_replicas_zero(r):
    ap = r.get('autoscaling_policy', {}); ap = (ap[0] if isinstance(ap, list) and ap else ap) or {}
    if int(ap.get('min_replicas', 0) or 0) == 0: return 'GCE MIG can scale to 0 - service may become unavailable'
def mig_no_multi_zone(r):
    if not r.get('distribution_policy_zones') or len(r.get('distribution_policy_zones', [])) < 2:
        return 'GCE MIG spans fewer than 2 zones - single-zone failure risk'
def mig_no_stateful_disk(r):
    if r.get('_requires_stateful') and not r.get('stateful_disk'): return 'GCE MIG requires stateful disks but none configured'

GCE_MIG_RULES = [mig_no_health_checks, mig_no_autoscaling, mig_no_update_policy, mig_minimum_replicas_zero, mig_no_multi_zone, mig_no_stateful_disk]
