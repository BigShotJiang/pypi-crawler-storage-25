
# ============================================================================
# OCI SECURITY RULES - PART 2
# Load Balancer, File Storage, DNS, API Gateway, Compartments
# ============================================================================

def lb_no_https(r):
    for l in (r.get('listener') or []):
        if not isinstance(l, dict): continue
        if l.get('protocol', '').upper() == 'HTTP': return 'OCI Load Balancer listener allows HTTP - use HTTPS'

def lb_no_nsg(r):
    if not r.get('network_security_group_ids'): return 'OCI Load Balancer has no Network Security Groups attached'

OCI_LB_RULES = [lb_no_https, lb_no_nsg]

def fss_no_kms(r):
    if not r.get('kms_key_id'): return 'OCI File Storage File System not encrypted with customer managed key'

OCI_FSS_RULES = [fss_no_kms]

def dns_zone_no_tags(r):
    if not r.get('freeform_tags') and not r.get('defined_tags'): return 'OCI DNS Zone has no tags'

OCI_DNS_RULES = [dns_zone_no_tags]

def apigw_public(r):
    if r.get('endpoint_type', 'PUBLIC') == 'PUBLIC': return 'OCI API Gateway endpoint is PUBLIC'

def apigw_no_auth(r):
    auth = r.get('authentication_policy', {}); auth = (auth[0] if isinstance(auth, list) and auth else auth) or {}
    if not auth: return 'OCI API Gateway has no authentication policy configured'

OCI_APIGW_RULES = [apigw_public, apigw_no_auth]

OCI_RULES_MAP_PART2 = {
    'oci_load_balancer_load_balancer': OCI_LB_RULES,
    'oci_file_storage_file_system': OCI_FSS_RULES,
    'oci_dns_zone': OCI_DNS_RULES,
    'oci_apigateway_gateway': OCI_APIGW_RULES
}
