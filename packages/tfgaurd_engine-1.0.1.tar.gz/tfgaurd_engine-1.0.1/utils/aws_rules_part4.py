
# ============================================================================
# AWS EXTENDED SECURITY RULES - PART 4
# Kinesis, EMR, CodeBuild, Secrets Manager, VPC, API Gateway,
# MSK, RDS Aurora, SageMaker, Backup, CloudWatch, AutoScaling, WAF
# ============================================================================

# ── KINESIS STREAM RULES ────────────────────────────────────────────────────
def check_kinesis_no_encryption(r):
    ec = r.get('encryption_type', 'NONE')
    if ec == 'NONE': return 'Kinesis stream not encrypted - HIGH RISK'
def check_kinesis_no_kms(r):
    if r.get('encryption_type') == 'KMS' and not r.get('kms_key_id'): return 'Kinesis stream KMS encryption has no key specified'
def check_kinesis_no_tags(r):
    if not r.get('tags'): return 'Kinesis stream has no tags'
def check_kinesis_retention_low(r):
    ret = int(r.get('retention_period', 24) or 24)
    if ret < 24: return f'Kinesis retention period {ret}h is below 24h minimum'
def check_kinesis_shard_count_zero(r):
    if int(r.get('shard_count', 0) or 0) == 0 and r.get('stream_mode_details', {}).get('stream_mode') != 'ON_DEMAND':
        return 'Kinesis stream has 0 shards and is not ON_DEMAND - misconfigured'
def check_kinesis_no_enhanced_monitoring(r):
    if not r.get('shard_level_metrics'): return 'Kinesis has no shard-level metrics enabled'

KINESIS_RULES = [check_kinesis_no_encryption, check_kinesis_no_kms, check_kinesis_no_tags,
    check_kinesis_retention_low, check_kinesis_shard_count_zero, check_kinesis_no_enhanced_monitoring]

# ── EMR RULES ───────────────────────────────────────────────────────────────
def check_emr_no_encryption(r):
    sc = r.get('security_configuration'); 
    if not sc: return 'EMR cluster has no security configuration - encryption disabled'
def check_emr_public_subnet(r):
    for ig in (r.get('instance_group') or []):
        if isinstance(ig, dict) and not ig.get('ebs_config'): return 'EMR instance group has no EBS config'
def check_emr_no_logging(r):
    if not r.get('log_uri'): return 'EMR cluster has no S3 log URI configured'
def check_emr_no_tags(r):
    if not r.get('tags'): return 'EMR cluster has no tags'
def check_emr_master_not_spot(r):
    for ig in (r.get('instance_group') or []):
        if isinstance(ig, dict) and ig.get('instance_role') == 'MASTER' and ig.get('bid_price'):
            return 'EMR master node uses spot - interruption risk for cluster coordination'
def check_emr_no_kerberos(r):
    kc = r.get('kerberos_attributes', {}); kc = (kc[0] if isinstance(kc, list) else kc) or {}
    if not kc: return 'EMR cluster has no Kerberos authentication configured'
def check_emr_auto_terminate(r):
    if not r.get('keep_job_flow_alive_when_no_steps', True): return 'EMR cluster auto-terminates when no steps - transient cluster'
def check_emr_no_ebs_root_volume_encryption(r):
    if not r.get('ebs_root_volume_size'): return 'EMR cluster EBS root volume size not specified'

EMR_RULES = [check_emr_no_encryption, check_emr_public_subnet, check_emr_no_logging, check_emr_no_tags,
    check_emr_master_not_spot, check_emr_no_kerberos, check_emr_auto_terminate, check_emr_no_ebs_root_volume_encryption]

# ── CODEBUILD RULES ─────────────────────────────────────────────────────────
def check_cb_no_encryption(r):
    ae = r.get('artifacts', {}); ae = (ae[0] if isinstance(ae, list) else ae) or {}
    if ae.get('type') == 'S3' and not ae.get('encryption_disabled') is False: return 'CodeBuild S3 artifacts not explicitly encrypted'
def check_cb_no_vpc(r):
    vpc = r.get('vpc_config', {}); vpc = (vpc[0] if isinstance(vpc, list) else vpc) or {}
    if not vpc: return 'CodeBuild project not in VPC - network isolation missing'
def check_cb_privileged_mode(r):
    env = r.get('environment', {}); env = (env[0] if isinstance(env, list) else env) or {}
    if env.get('privileged_mode', False): return 'CodeBuild running in privileged mode - only needed for Docker builds'
def check_cb_no_logs(r):
    lc = r.get('logs_config', {}); lc = (lc[0] if isinstance(lc, list) else lc) or {}
    if not lc: return 'CodeBuild logs not configured'
def check_cb_no_tags(r):
    if not r.get('tags'): return 'CodeBuild project has no tags'
def check_cb_env_vars_secrets(r):
    env = r.get('environment', {}); env = (env[0] if isinstance(env, list) else env) or {}
    for ev in (env.get('environment_variable') or []):
        if isinstance(ev, dict) and ev.get('type', 'PLAINTEXT') == 'PLAINTEXT':
            k = str(ev.get('name', '')).lower()
            if any(s in k for s in ['password', 'secret', 'key', 'token']): return f'CodeBuild env var {ev.get("name")} is PLAINTEXT - use SECRETS_MANAGER or PARAMETER_STORE'
def check_cb_no_timeout(r):
    if not r.get('build_timeout'): return 'CodeBuild build timeout not configured - runaway builds possible'
def check_cb_no_badge(r):
    if not r.get('badge_enabled', False): return 'CodeBuild badge not enabled - no build status visibility'

CODEBUILD_RULES = [check_cb_no_encryption, check_cb_no_vpc, check_cb_privileged_mode, check_cb_no_logs,
    check_cb_no_tags, check_cb_env_vars_secrets, check_cb_no_timeout, check_cb_no_badge]

# ── SECRETS MANAGER RULES ────────────────────────────────────────────────────
def check_sm_no_rotation(r):
    if not r.get('rotation_enabled', False): return 'Secrets Manager secret has no automatic rotation - HIGH RISK'
def check_sm_rotation_long(r):
    rd = r.get('rotation_rules', {}); rd = (rd[0] if isinstance(rd, list) else rd) or {}
    days = int(rd.get('automatically_after_days', 0) or 0)
    if days > 90: return f'Secrets Manager secret rotates every {days} days - reduce to 30-90'
def check_sm_no_kms(r):
    if not r.get('kms_key_id'): return 'Secrets Manager secret not encrypted with customer KMS key'
def check_sm_no_tags(r):
    if not r.get('tags'): return 'Secrets Manager secret has no tags - governance issue'
def check_sm_no_description(r):
    if not r.get('description'): return 'Secrets Manager secret has no description'
def check_sm_public_policy(r):
    if '"Principal": "*"' in str(r.get('policy', '') or ''): return 'Secrets Manager secret policy allows public access - CRITICAL RISK'
def check_sm_no_recovery_window(r):
    if int(r.get('recovery_window_in_days', 7) or 7) < 7: return 'Secrets Manager recovery window < 7 days - accidental deletion risk'
def check_sm_secret_in_name(r):
    name = str(r.get('name', '') or '').lower()
    if any(s in name for s in ['prod', 'password', 'key']): return f'Secrets Manager secret name {name} reveals sensitive context'

SECRETS_MANAGER_RULES = [check_sm_no_rotation, check_sm_rotation_long, check_sm_no_kms, check_sm_no_tags,
    check_sm_no_description, check_sm_public_policy, check_sm_no_recovery_window, check_sm_secret_in_name]

# ── VPC RULES ────────────────────────────────────────────────────────────────
def check_vpc_default_sg_open(r):
    if r.get('is_default', False): return 'Default VPC should not be used for production workloads'
def check_vpc_no_flow_logs(r):
    if not r.get('enable_dns_hostnames') and not r.get('flow_log'): return 'VPC has no Flow Logs enabled - no network visibility'
def check_vpc_no_dns_resolution(r):
    if not r.get('enable_dns_support', True): return 'VPC DNS resolution disabled'
def check_vpc_large_cidr(r):
    cidr = r.get('cidr_block', '')
    if cidr.endswith('/8') or cidr.endswith('/16'): return f'VPC CIDR {cidr} is very large - use smaller CIDR for better IP management'
def check_vpc_no_tags(r):
    if not r.get('tags'): return 'VPC has no tags'
def check_vpc_ipv6_not_configured(r):
    if not r.get('assign_generated_ipv6_cidr_block', False): return 'VPC has no IPv6 CIDR - dual-stack not configured'
def check_vpc_no_secondary_cidr(r):
    if not r.get('secondary_cidr_blocks'): return 'VPC has no secondary CIDR - future expansion may require new VPC'

VPC_RULES = [check_vpc_default_sg_open, check_vpc_no_flow_logs, check_vpc_no_dns_resolution,
    check_vpc_large_cidr, check_vpc_no_tags, check_vpc_ipv6_not_configured, check_vpc_no_secondary_cidr]

# ── API GATEWAY STAGE RULES ──────────────────────────────────────────────────
def check_apigw_no_logging(r):
    ms = r.get('method_settings', [])
    has_logging = any((m or {}).get('logging_level', 'OFF') != 'OFF' for m in (ms if isinstance(ms, list) else [ms]))
    if not has_logging: return 'API Gateway stage has no CloudWatch logging'
def check_apigw_no_access_log(r):
    if not r.get('access_log_settings') and not r.get('access_log_destination_arn'): return 'API Gateway stage has no access log destination'
def check_apigw_no_waf(r):
    if not r.get('web_acl_arn'): return 'API Gateway stage has no WAF WebACL'
def check_apigw_tracing_disabled(r):
    if not r.get('xray_tracing_enabled', False): return 'API Gateway X-Ray tracing disabled'
def check_apigw_no_cache(r):
    if not r.get('cache_cluster_enabled', False): return 'API Gateway caching not enabled - increased backend load'
def check_apigw_http_not_https(r):
    if r.get('endpoint_type', '') == 'HTTP': return 'API Gateway uses HTTP endpoint type - ensure HTTPS'
def check_apigw_no_throttling(r):
    ms = r.get('method_settings', [])
    no_throttle = all((m or {}).get('throttling_rate_limit', 0) == 0 for m in (ms if isinstance(ms, list) else [ms] if ms else []))
    if no_throttle: return 'API Gateway stage has no throttling configured - DDoS risk'
def check_apigw_no_tags(r):
    if not r.get('tags'): return 'API Gateway stage has no tags'
def check_apigw_stage_variables_secrets(r):
    for k, v in (r.get('variables') or {}).items():
        if any(s in k.lower() for s in ['password', 'secret', 'key', 'token']): return f'API Gateway stage variable {k} may contain sensitive data'
def check_apigw_no_client_cert(r):
    if not r.get('client_certificate_id'): return 'API Gateway stage has no client certificate for backend auth'

APIGW_STAGE_RULES = [check_apigw_no_logging, check_apigw_no_access_log, check_apigw_no_waf,
    check_apigw_tracing_disabled, check_apigw_no_cache, check_apigw_http_not_https,
    check_apigw_no_throttling, check_apigw_no_tags, check_apigw_stage_variables_secrets, check_apigw_no_client_cert]

# ── CLOUDWATCH LOG GROUP RULES ────────────────────────────────────────────────
def check_cw_no_retention(r):
    if not r.get('retention_in_days'): return 'CloudWatch Log Group has no retention policy - costs accumulate'
def check_cw_no_kms(r):
    if not r.get('kms_key_id'): return 'CloudWatch Log Group not encrypted with KMS'
def check_cw_no_tags(r):
    if not r.get('tags'): return 'CloudWatch Log Group has no tags'
def check_cw_retention_too_short(r):
    ret = int(r.get('retention_in_days', 0) or 0)
    if 0 < ret < 90: return f'CloudWatch Log Group retention {ret} days may be insufficient for compliance'
def check_cw_no_metric_filter(r):
    if not r.get('metric_filter'): return 'CloudWatch Log Group has no metric filters for alerting'
def check_cw_no_subscription_filter(r):
    if not r.get('subscription_filter') and not r.get('subscription_filter_arn'): return 'CloudWatch Log Group has no subscription filter - no real-time log streaming'

CW_LOG_GROUP_RULES = [check_cw_no_retention, check_cw_no_kms, check_cw_no_tags,
    check_cw_retention_too_short, check_cw_no_metric_filter, check_cw_no_subscription_filter]

# ── AUTOSCALING GROUP RULES ──────────────────────────────────────────────────
def check_asg_no_multi_az(r):
    azs = r.get('availability_zones') or r.get('vpc_zone_identifier') or []
    if isinstance(azs, str): azs = azs.split(',')
    if len(azs) < 2: return 'AutoScaling group spans fewer than 2 AZs - single-AZ risk'
def check_asg_no_health_check(r):
    if r.get('health_check_type', 'EC2') == 'EC2': return 'AutoScaling group uses EC2 health checks - use ELB for application-level checks'
def check_asg_no_termination_policy(r):
    if not r.get('termination_policies'): return 'AutoScaling group has no termination policy'
def check_asg_no_scaling_policies(r):
    if not r.get('scaling_policy') and not r.get('target_tracking_config'): return 'AutoScaling group has no scaling policies - no dynamic scaling'
def check_asg_no_tags(r):
    if not r.get('tag'): return 'AutoScaling group has no tags'
def check_asg_min_size_zero(r):
    if int(r.get('min_size', 0) or 0) == 0: return 'AutoScaling group min_size is 0 - can scale to zero'
def check_asg_no_warm_pool(r):
    if not r.get('warm_pool'): return 'AutoScaling group has no warm pool - cold start latency on scale-out'
def check_asg_no_instance_refresh(r):
    if not r.get('instance_refresh'): return 'AutoScaling group has no instance refresh strategy configured'
def check_asg_no_loadbalancer(r):
    if not r.get('load_balancers') and not r.get('target_group_arns'): return 'AutoScaling group has no load balancer - all instances receive direct traffic'
def check_asg_launch_config_deprecated(r):
    if r.get('launch_configuration') and not r.get('launch_template'): return 'AutoScaling group uses launch configuration - migrate to launch template'

ASG_RULES = [check_asg_no_multi_az, check_asg_no_health_check, check_asg_no_termination_policy,
    check_asg_no_scaling_policies, check_asg_no_tags, check_asg_min_size_zero,
    check_asg_no_warm_pool, check_asg_no_instance_refresh, check_asg_no_loadbalancer, check_asg_launch_config_deprecated]

# ── WAFv2 RULES ──────────────────────────────────────────────────────────────
def check_waf_no_logging(r):
    if not r.get('logging_configuration') and not r.get('log_destination_configs'): return 'WAFv2 has no logging configured'
def check_waf_no_managed_rules(r):
    rl = r.get('rule', []) or []
    has_managed = any('ManagedRuleGroupStatement' in str(rule) for rule in rl)
    if not has_managed: return 'WAFv2 has no AWS Managed Rule Groups - common threats unblocked'
def check_waf_no_rate_limiting(r):
    rl = r.get('rule', []) or []
    has_rate = any('RateBasedStatement' in str(rule) for rule in rl)
    if not has_rate: return 'WAFv2 has no rate-based rules - DDoS/brute-force unprotected'
def check_waf_default_action_allow(r):
    da = r.get('default_action', {}); da = (da[0] if isinstance(da, list) else da) or {}
    if 'allow' in str(da).lower() and not r.get('_explicit_allow_intended'): return 'WAFv2 default action is ALLOW - verify all traffic should be allowed by default'
def check_waf_no_tags(r):
    if not r.get('tags'): return 'WAFv2 WebACL has no tags'
def check_waf_no_ip_set(r):
    rl = r.get('rule', []) or []
    has_ipset = any('IPSetReferenceStatement' in str(rule) for rule in rl)
    if not has_ipset: return 'WAFv2 has no IP set rules - geo/IP blocking not configured'
def check_waf_too_few_rules(r):
    rl = r.get('rule', []) or []
    if len(rl) < 3: return f'WAFv2 has only {len(rl)} rules - consider adding more protection'
def check_waf_no_sqli_protection(r):
    rl = str(r.get('rule', []))
    if 'SqliMatchStatement' not in rl and 'AWSManagedRulesSQLiRuleSet' not in rl: return 'WAFv2 has no SQLi protection rules'
def check_waf_no_xss_protection(r):
    rl = str(r.get('rule', []))
    if 'XssMatchStatement' not in rl and 'AWSManagedRulesCommonRuleSet' not in rl: return 'WAFv2 has no XSS protection rules'

WAFV2_RULES = [check_waf_no_logging, check_waf_no_managed_rules, check_waf_no_rate_limiting,
    check_waf_default_action_allow, check_waf_no_tags, check_waf_no_ip_set,
    check_waf_too_few_rules, check_waf_no_sqli_protection, check_waf_no_xss_protection]

# ── MSK RULES ────────────────────────────────────────────────────────────────
def check_msk_no_encryption(r):
    ec = r.get('encryption_info', {}); ec = (ec[0] if isinstance(ec, list) else ec) or {}
    bc = ec.get('encryption_in_transit', {}); bc = (bc[0] if isinstance(bc, list) else bc) or {}
    if bc.get('client_broker', 'PLAINTEXT') == 'PLAINTEXT': return 'MSK cluster client-broker encryption is PLAINTEXT - HIGH RISK'
def check_msk_no_kms(r):
    ec = r.get('encryption_info', {}); ec = (ec[0] if isinstance(ec, list) else ec) or {}
    if not ec.get('encryption_at_rest', {}).get('encryption_key'): return 'MSK cluster at-rest encryption uses default KMS key'
def check_msk_no_enhanced_monitoring(r):
    if r.get('enhanced_monitoring', 'DEFAULT') == 'DEFAULT': return 'MSK cluster using DEFAULT monitoring - enable enhanced'
def check_msk_no_logging(r):
    lc = r.get('logging_info', {}); lc = (lc[0] if isinstance(lc, list) else lc) or {}
    if not lc: return 'MSK cluster has no broker logging configured'
def check_msk_no_multi_az(r):
    bi = r.get('broker_node_group_info', {}); bi = (bi[0] if isinstance(bi, list) else bi) or {}
    azs = bi.get('client_subnets', []) or []
    if len(azs) < 2: return 'MSK cluster spans fewer than 2 AZs'
def check_msk_no_tags(r):
    if not r.get('tags'): return 'MSK cluster has no tags'

MSK_RULES = [check_msk_no_encryption, check_msk_no_kms, check_msk_no_enhanced_monitoring,
    check_msk_no_logging, check_msk_no_multi_az, check_msk_no_tags]

# ── EFS RULES ────────────────────────────────────────────────────────────────
def check_efs_no_encryption(r):
    if not r.get('encrypted', False): return 'EFS file system not encrypted - HIGH RISK'
def check_efs_no_kms(r):
    if r.get('encrypted') and not r.get('kms_key_id'): return 'EFS uses default KMS key - use customer-managed key'
def check_efs_no_lifecycle(r):
    if not r.get('lifecycle_policy'): return 'EFS has no lifecycle policy - storage costs not optimized'
def check_efs_no_backup(r):
    bp = r.get('backup_policy', {}); bp = (bp[0] if isinstance(bp, list) else bp) or {}
    if bp.get('status', 'DISABLED') == 'DISABLED': return 'EFS backup policy disabled'
def check_efs_performance_mode(r):
    if r.get('performance_mode', 'generalPurpose') == 'generalPurpose' and r.get('_is_high_io'):
        return 'EFS using generalPurpose mode for high-I/O workload - consider maxIO'
def check_efs_no_tags(r):
    if not r.get('tags'): return 'EFS file system has no tags'
def check_efs_provisioned_throughput_unset(r):
    if r.get('throughput_mode') == 'provisioned' and not r.get('provisioned_throughput_in_mibps'):
        return 'EFS in provisioned throughput mode but no throughput value set'
def check_efs_public_mount_target(r):
    if r.get('availability_zone_name') and not r.get('subnet_id'): return 'EFS mount target may be in public subnet'

EFS_RULES = [check_efs_no_encryption, check_efs_no_kms, check_efs_no_lifecycle, check_efs_no_backup,
    check_efs_performance_mode, check_efs_no_tags, check_efs_provisioned_throughput_unset, check_efs_public_mount_target]

# ── SAGEMAKER NOTEBOOK RULES ─────────────────────────────────────────────────
def check_sm_nb_no_kms(r):
    if not r.get('kms_key_id'): return 'SageMaker notebook instance has no KMS encryption'
def check_sm_nb_direct_internet_access(r):
    if r.get('direct_internet_access', 'Enabled') == 'Enabled': return 'SageMaker notebook has direct internet access - HIGH RISK'
def check_sm_nb_no_vpc(r):
    if not r.get('subnet_id'): return 'SageMaker notebook not in VPC'
def check_sm_nb_no_tags(r):
    if not r.get('tags'): return 'SageMaker notebook has no tags'
def check_sm_nb_root_access(r):
    if r.get('root_access', 'Enabled') == 'Enabled': return 'SageMaker notebook root access enabled - restrict user capabilities'
def check_sm_nb_no_lifecycle(r):
    if not r.get('lifecycle_config_name'): return 'SageMaker notebook has no lifecycle configuration'

SAGEMAKER_NOTEBOOK_RULES = [check_sm_nb_no_kms, check_sm_nb_direct_internet_access, check_sm_nb_no_vpc,
    check_sm_nb_no_tags, check_sm_nb_root_access, check_sm_nb_no_lifecycle]

# ── AWS BACKUP RULES ─────────────────────────────────────────────────────────
def check_backup_no_vault_encryption(r):
    if not r.get('kms_key_arn'): return 'Backup vault not encrypted with KMS'
def check_backup_no_retention(r):
    rule = r.get('rule', {}); rule = (rule[0] if isinstance(rule, list) else rule) or {}
    if not rule.get('delete_after'): return 'Backup plan rule has no retention period'
def check_backup_no_tags(r):
    if not r.get('tags'): return 'Backup plan has no tags'
def check_backup_no_vault_lock(r):
    if not r.get('locked'): return 'Backup vault has no vault lock configured - backups can be deleted'
def check_backup_no_cross_region(r):
    rule = r.get('rule', {}); rule = (rule[0] if isinstance(rule, list) else rule) or {}
    if not rule.get('copy_action'): return 'Backup plan has no cross-region copy action'

BACKUP_PLAN_RULES = [check_backup_no_vault_encryption, check_backup_no_retention,
    check_backup_no_tags, check_backup_no_vault_lock, check_backup_no_cross_region]

# ── ACM CERT RULES ───────────────────────────────────────────────────────────
def check_acm_no_renewal(r):
    ro = r.get('renewal_eligibility', '')
    if ro == 'INELIGIBLE': return 'ACM certificate is ineligible for renewal - review domain validation'
def check_acm_expiry_soon(r):
    na = r.get('not_after', '') or ''
    if na and '2026' in na: return 'ACM certificate expires in 2026 - ensure auto-renewal is working'
def check_acm_wildcard(r):
    for dom in (r.get('domain_validation_options') or []):
        if isinstance(dom, dict) and (dom.get('domain_name', '') or '').startswith('*.'): return 'ACM wildcard certificate in use - single certificate covers all subdomains'
def check_acm_no_tags(r):
    if not r.get('tags'): return 'ACM certificate has no tags'

ACM_RULES = [check_acm_no_renewal, check_acm_expiry_soon, check_acm_wildcard, check_acm_no_tags]

# ── GUARDDUTY RULES ────────────────────────────────────────────────────────────
def check_gd_not_enabled(r):
    if not r.get('enable', False): return 'GuardDuty detector is not enabled - CRITICAL RISK'
def check_gd_no_s3_protection(r):
    ds = r.get('datasources', {}); ds = (ds[0] if isinstance(ds, list) else ds) or {}
    s3 = ds.get('s3_logs', {}); s3 = (s3[0] if isinstance(s3, list) else s3) or {}
    if not s3.get('enable', False): return 'GuardDuty S3 protection not enabled'
def check_gd_no_eks_protection(r):
    ds = r.get('datasources', {}); ds = (ds[0] if isinstance(ds, list) else ds) or {}
    eks = ds.get('kubernetes', {}); eks = (eks[0] if isinstance(eks, list) else eks) or {}
    if not eks.get('audit_logs', {}).get('enable', False): return 'GuardDuty EKS audit log protection not enabled'
def check_gd_no_malware_protection(r):
    ds = r.get('datasources', {}); ds = (ds[0] if isinstance(ds, list) else ds) or {}
    mw = ds.get('malware_protection', {}); mw = (mw[0] if isinstance(mw, list) else mw) or {}
    if not mw.get('scan_ec2_instance_with_findings', {}).get('ebs_volumes', {}).get('enable', False):
        return 'GuardDuty EBS malware protection not enabled'
def check_gd_no_tags(r):
    if not r.get('tags'): return 'GuardDuty detector has no tags'

GUARDDUTY_RULES = [check_gd_not_enabled, check_gd_no_s3_protection, check_gd_no_eks_protection,
    check_gd_no_malware_protection, check_gd_no_tags]

# ── GLUE JOB RULES ──────────────────────────────────────────────────────────
def check_glue_no_encryption(r):
    ec = r.get('security_configuration', '')
    if not ec: return 'Glue job has no security configuration - no encryption'
def check_glue_no_tags(r):
    if not r.get('tags'): return 'Glue job has no tags'
def check_glue_no_cloudwatch_logs(r):
    dc = r.get('default_arguments', {}); dc = (dc[0] if isinstance(dc, list) else dc) or {}
    if '--enable-continuous-cloudwatch-log' not in str(dc): return 'Glue job continuous CloudWatch logging not enabled'
def check_glue_no_bookmark(r):
    dc = r.get('default_arguments', {}); dc = (dc[0] if isinstance(dc, list) else dc) or {}
    if 'job-bookmark-enable' not in str(dc): return 'Glue job bookmark not enabled - may reprocess data'
def check_glue_no_timeout(r):
    if not r.get('timeout'): return 'Glue job has no timeout configured - runaway jobs possible'

GLUE_JOB_RULES = [check_glue_no_encryption, check_glue_no_tags, check_glue_no_cloudwatch_logs,
    check_glue_no_bookmark, check_glue_no_timeout]

# ── SSM PARAMETER RULES ───────────────────────────────────────────────────────
def check_ssm_no_kms(r):
    if r.get('type', '') == 'SecureString' and not r.get('key_id'): return 'SSM SecureString parameter has no KMS key specified'
def check_ssm_plain_sensitive(r):
    name = str(r.get('name', '') or '').lower()
    if r.get('type') == 'String' and any(s in name for s in ['password', 'secret', 'token', 'key']):
        return f'SSM parameter {name} looks sensitive but is not SecureString'
def check_ssm_no_tags(r):
    if not r.get('tags'): return 'SSM parameter has no tags'
def check_ssm_no_description(r):
    if not r.get('description'): return 'SSM parameter has no description'
def check_ssm_value_too_long(r):
    if len(str(r.get('value', '') or '')) > 4096: return 'SSM parameter value exceeds 4096 bytes - use advanced tier with caution'

SSM_PARAMETER_RULES = [check_ssm_no_kms, check_ssm_plain_sensitive, check_ssm_no_tags,
    check_ssm_no_description, check_ssm_value_too_long]
