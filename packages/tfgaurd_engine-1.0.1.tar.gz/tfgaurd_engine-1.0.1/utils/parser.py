# parser.py - Read Terraform files

import hcl2
import json
import io

def parse_terraform_file(file_path_or_code):
    """Extract resources from .tf file or string code"""
    # Check if input is a file path or code string
    if '\n' in file_path_or_code or 'resource ' in file_path_or_code:
        # It's code, parse as string
        tf_dict = hcl2.loads(file_path_or_code)
    else:
        # It's a file path
        with open(file_path_or_code, 'r', encoding='utf-8') as f:
            tf_dict = hcl2.load(f)
    
    # Handle different return formats from hcl2
    resources_dict = tf_dict.get('resource', [])
    
    # If it's already a list, hcl2 returns it as list of dicts
    if isinstance(resources_dict, list):
        # Flatten the structure
        resources_list = []
        for resource_item in resources_dict:
            for resource_type, resource_configs in resource_item.items():
                for resource_name, resource_config in resource_configs.items():
                    resources_list.append({
                        resource_type: {
                            resource_name: resource_config
                        }
                    })
        return resources_list
    
    # If it's a dict, convert to list format
    resources_list = []
    for resource_type, resource_configs in resources_dict.items():
        for resource_name, resource_config in resource_configs.items():
            resources_list.append({
                resource_type: {
                    resource_name: resource_config
                }
            })
    
    return resources_list