
# ============================================================================
# GCP SECURITY RULES - PART 2
# Cloud SQL, IAM, Service Accounts, KMS, Cloud Run, Cloud Functions
# ============================================================================

# ── CLOUD SQL INSTANCE ───────────────────────────────────────────────────────
def sql_no_public_ip(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    ip = s.get('ip_configuration', {}); ip = (ip[0] if isinstance(ip, list) and ip else ip) or {}
    if ip.get('ipv4_enabled', True): return 'Cloud SQL has public IP enabled - HIGH RISK: disable ipv4_enabled'
def sql_authorized_networks_open(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    ip = s.get('ip_configuration', {}); ip = (ip[0] if isinstance(ip, list) and ip else ip) or {}
    for n in (ip.get('authorized_networks') or []):
        if isinstance(n, dict) and n.get('value') == '0.0.0.0/0': return 'Cloud SQL allows 0.0.0.0/0 in authorized networks - CRITICAL RISK'
def sql_no_ssl_tls(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    ip = s.get('ip_configuration', {}); ip = (ip[0] if isinstance(ip, list) and ip else ip) or {}
    if not ip.get('require_ssl', False): return 'Cloud SQL does not require SSL/TLS for all connections - HIGH RISK'
def sql_no_backups(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    b = s.get('backup_configuration', {}); b = (b[0] if isinstance(b, list) and b else b) or {}
    if not b.get('enabled', False): return 'Cloud SQL automated backups not enabled'
def sql_no_ha(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    if s.get('availability_type', 'ZONAL') == 'ZONAL': return 'Cloud SQL is ZONAL - no high availability/failover'
def sql_no_cmek(r):
    if not r.get('encryption_key_name'): return 'Cloud SQL not encrypted with CMEK - uses Google-managed key'
def sql_no_labels(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    if not s.get('user_labels'): return 'Cloud SQL has no user labels'
def sql_no_deletion_protection(r):
    if not r.get('deletion_protection', False): return 'Cloud SQL deletion protection disabled'
def sql_db_flags_local_infile(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    for f in (s.get('database_flags') or []):
        if isinstance(f, dict) and f.get('name') == 'local_infile' and f.get('value') == 'on':
            return 'Cloud SQL MySQL allows local_infile - data exfiltration risk'
def sql_db_flags_cross_db_ownership(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    for f in (s.get('database_flags') or []):
        if isinstance(f, dict) and f.get('name') == 'cross_db_ownership_chaining' and f.get('value') == 'on':
            return 'Cloud SQL SQL Server allows cross-database ownership chaining - privilege escalation risk'
def sql_db_flags_contained_db_authentication(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    for f in (s.get('database_flags') or []):
        if isinstance(f, dict) and f.get('name') == 'contained_database_authentication' and f.get('value') == 'on':
            return 'Cloud SQL SQL Server allows contained database authentication - bypasses DB engine auditing'
def sql_db_flags_log_min_messages(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    found = False
    for f in (s.get('database_flags') or []):
        if isinstance(f, dict) and f.get('name') == 'log_min_messages' and f.get('value') not in ('fatal', 'panic', 'log', 'error'):
            return f'Cloud SQL Postgres log_min_messages set to {f.get("value")} - may log sensitive data'
def sql_db_flags_log_statement(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    for f in (s.get('database_flags') or []):
        if isinstance(f, dict) and f.get('name') == 'log_statement' and f.get('value') == 'all':
            return 'Cloud SQL Postgres log_statement set to all - logs all queries including passwords'
def sql_no_point_in_time_recovery(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    b = s.get('backup_configuration', {}); b = (b[0] if isinstance(b, list) and b else b) or {}
    if not b.get('point_in_time_recovery_enabled', False): return 'Cloud SQL point-in-time recovery not enabled'
def sql_query_insights_disabled(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    qi = s.get('insights_config', {}); qi = (qi[0] if isinstance(qi, list) and qi else qi) or {}
    if not qi.get('query_insights_enabled', False): return 'Cloud SQL Query Insights disabled - query performance visibility lost'
def sql_root_password(r):
    if r.get('root_password'): return 'Cloud SQL sets root password in configuration - HIGH RISK: use secret manager'
def sql_iam_auth_disabled(r):
    s = r.get('settings', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    if not s.get('database_flags') or not any(f.get('name') == 'cloudsql.iam_authentication' and f.get('value') == 'on' for f in (s.get('database_flags') or []) if isinstance(f, dict)):
        return 'Cloud SQL IAM database authentication not enabled'

GCP_SQL_RULES = [
    sql_no_public_ip, sql_authorized_networks_open, sql_no_ssl_tls, sql_no_backups,
    sql_no_ha, sql_no_cmek, sql_no_labels, sql_no_deletion_protection,
    sql_db_flags_local_infile, sql_db_flags_cross_db_ownership, sql_db_flags_contained_db_authentication,
    sql_db_flags_log_min_messages, sql_db_flags_log_statement, sql_no_point_in_time_recovery,
    sql_query_insights_disabled, sql_root_password, sql_iam_auth_disabled,
]

# ── IAM & FOLDERS ────────────────────────────────────────────────────────────
def iam_basic_roles_project(r):
    role = r.get('role', '')
    if role in ('roles/owner', 'roles/editor', 'roles/viewer') and r.get('project'):
        return f'GCP IAM uses primitive project role {role} - HIGH RISK: use predefined curated roles'
def iam_service_account_admin(r):
    role = r.get('role', '')
    if role == 'roles/iam.serviceAccountAdmin' and not r.get('condition'):
        return 'GCP IAM assigns ServiceAccountAdmin without condition - allows full pivot to any service account'
def iam_user_impersonation(r):
    role = r.get('role', '')
    if role == 'roles/iam.serviceAccountTokenCreator' and 'user:' in str(r.get('members', [])):
        return 'GCP IAM assigns TokenCreator directly to a user - allows impersonating service accounts indefinitely'
def iam_all_users_grant(r):
    members = r.get('members', []) or []
    if 'allUsers' in members or 'allAuthenticatedUsers' in members:
        return 'GCP IAM grants access to allUsers/allAuthenticatedUsers - public exposure'
def iam_no_condition(r):
    if r.get('role', '').startswith('roles/resourcemanager.organizationAdmin') and not r.get('condition'):
        return 'GCP IAM grants orgAdmin without conditions (e.g. time-based or IP-based)'
def folder_no_tags(r):
    if not r.get('tags'): return 'GCP Folder has no tags'
def policy_boolean_constraint(r):
    c = str(r.get('constraint', ''))
    if 'storage.uniformBucketLevelAccess' in c and not r.get('boolean_policy', {}).get('enforced', False):
        return 'GCP Org Policy disables uniform bucket-level access constraint'

GCP_IAM_RULES = [
    iam_basic_roles_project, iam_service_account_admin, iam_user_impersonation,
    iam_all_users_grant, iam_no_condition, folder_no_tags, policy_boolean_constraint,
]

# ── SERVICE ACCOUNTS & KEYS ──────────────────────────────────────────────────
def sa_key_created(r):
    if r.get('private_key_type') and not r.get('_is_cicd'): return 'GCP Service Account user-managed key created - use workload identity federation'
def sa_no_description(r):
    if not r.get('description'): return 'GCP Service Account has no description'
def sa_display_name_default(r):
    if not r.get('display_name'): return 'GCP Service Account has no display name'
def sa_key_no_rotation(r):
    if r.get('valid_before_time'): return 'GCP Service Account key expires > 90 days - rotate keys'
def workload_identity_no_condition(r):
    if 'iam.workloadIdentityUser' in str(r.get('role')) and not r.get('condition'):
        return 'GCP Workload Identity binding has no condition - any OIDC subject from provider can assume'

GCP_SA_RULES = [sa_key_created, sa_no_description, sa_display_name_default, sa_key_no_rotation, workload_identity_no_condition]

# ── KMS KEYS & KEYRINGS ──────────────────────────────────────────────────────
def kms_no_rotation(r):
    if not r.get('rotation_period'): return 'GCP KMS CryptoKey has no defined rotation period'
def kms_rotation_too_long(r):
    p = r.get('rotation_period', '')
    if p and p.endswith('s') and int(p[:-1] or 0) > 31536000: return 'GCP KMS CryptoKey rotation period > 365 days'
def kms_public_access(r):
    for m in (r.get('members') or []):
        if m in ('allUsers', 'allAuthenticatedUsers'): return 'GCP KMS key allows public access - CRITICAL RISK'
def kms_no_labels(r):
    if not r.get('labels'): return 'GCP KMS CryptoKey has no labels'
def kms_algorithm_weak(r):
    vp = r.get('version_template', {}); vp = (vp[0] if isinstance(vp, list) and vp else vp) or {}
    if vp.get('algorithm') == 'GOOGLE_SYMMETRIC_ENCRYPTION_AES_128': return 'GCP KMS uses AES-128 - prefer AES-256'
def kms_purpose_not_strict(r):
    if r.get('purpose') == 'ENCRYPT_DECRYPT' and r.get('_sensitive_signing'): return 'GCP KMS key purpose allows encrypt/decrypt, not restricted to sign/verify'
def keyring_no_location(r):
    if r.get('location') == 'global': return 'GCP KMS KeyRing uses global location - restricts sovereign data guarantees'

GCP_KMS_RULES = [kms_no_rotation, kms_rotation_too_long, kms_public_access, kms_no_labels, kms_algorithm_weak, kms_purpose_not_strict, keyring_no_location]

# ── CLOUD RUN ────────────────────────────────────────────────────────────────
def run_no_ingress_control(r):
    meta = r.get('metadata', {}); meta = (meta[0] if isinstance(meta, list) and meta else meta) or {}
    ann = meta.get('annotations', {})
    if ann.get('run.googleapis.com/ingress') not in ('internal', 'internal-and-cloud-load-balancing'):
        return 'Cloud Run service allows public ingress - use internal/LB if not public API'
def run_all_users_invoker(r):
    if 'roles/run.invoker' in str(r.get('role')) and ('allUsers' in (r.get('members') or []) or 'allAuthenticatedUsers' in (r.get('members') or [])):
        return 'Cloud Run service is publicly invokable - verify intended API exposure'
def run_no_vpc_connector(r):
    t = r.get('template', {}); t = (t[0] if isinstance(t, list) and t else t) or {}
    meta = t.get('metadata', {}); meta = (meta[0] if isinstance(meta, list) and meta else meta) or {}
    ann = meta.get('annotations', {})
    if not ann.get('run.googleapis.com/vpc-access-connector'): return 'Cloud Run service has no Serverless VPC Access connector - cannot reach private resources'
def run_egress_all(r):
    t = r.get('template', {}); t = (t[0] if isinstance(t, list) and t else t) or {}
    meta = t.get('metadata', {}); meta = (meta[0] if isinstance(meta, list) and meta else meta) or {}
    ann = meta.get('annotations', {})
    if ann.get('run.googleapis.com/vpc-access-egress') != 'all-traffic': return 'Cloud Run does not route all egress via VPC - risk of public IP use'
def run_env_secrets(r):
    t = r.get('template', {}); t = (t[0] if isinstance(t, list) and t else t) or {}
    spec = t.get('spec', {}); spec = (spec[0] if isinstance(spec, list) and spec else spec) or {}
    c = spec.get('containers', {}); c = (c[0] if isinstance(c, list) and c else c) or {}
    for env in (c.get('env') or []):
        if not isinstance(env, dict): continue
        if env.get('value') and any(s in str(env.get('name', '')).lower() for s in ('key', 'secret', 'pass', 'token')):
            return f'Cloud Run env var {env.get("name")} contains plaintext value - use Secret Manager'
def run_default_sa(r):
    t = r.get('template', {}); t = (t[0] if isinstance(t, list) and t else t) or {}
    spec = t.get('spec', {}); spec = (spec[0] if isinstance(spec, list) and spec else spec) or {}
    sa = spec.get('service_account_name', '')
    if 'compute@developer.gserviceaccount.com' in sa: return 'Cloud Run uses default compute service account - HIGH RISK'
def run_container_privileged(r):
    t = r.get('template', {}); t = (t[0] if isinstance(t, list) and t else t) or {}
    spec = t.get('spec', {}); spec = (spec[0] if isinstance(spec, list) and spec else spec) or {}
    c = spec.get('containers', {}); c = (c[0] if isinstance(c, list) and c else c) or {}
    sc = c.get('security_context', {}); sc = (sc[0] if isinstance(sc, list) and sc else sc) or {}
    if sc.get('privileged', False): return 'Cloud Run container runs in privileged mode - HIGH RISK'

GCP_CLOUD_RUN_RULES = [run_no_ingress_control, run_all_users_invoker, run_no_vpc_connector, run_egress_all, run_env_secrets, run_default_sa, run_container_privileged]

# ── CLOUD FUNCTIONS ──────────────────────────────────────────────────────────
def func_no_vpc_connector(r):
    if not r.get('vpc_connector'): return 'Cloud Function has no VPC connector - cannot access private VPC resources'
def func_ingress_all(r):
    if r.get('ingress_settings', 'ALLOW_ALL') == 'ALLOW_ALL': return 'Cloud Function allows all ingress traffic - restrict to internal/LB'
def func_build_env_secrets(r):
    for k, v in (r.get('build_environment_variables') or {}).items():
        if any(s in str(k).lower() for s in ('key', 'secret', 'pass', 'token')): return f'Cloud Function build env {k} may be a secret'
def func_env_secrets(r):
    for k, v in (r.get('environment_variables') or {}).items():
        if any(s in str(k).lower() for s in ('key', 'secret', 'pass', 'token')): return f'Cloud Function env {k} may be a secret - use secret_environment_variables'
def func_default_sa(r):
    sa = r.get('service_account_email', '')
    if 'appspot.gserviceaccount.com' in sa: return 'Cloud Function uses default appspot service account - HIGH RISK: overly permissive'
def func_all_users_invoker(r):
    if 'roles/cloudfunctions.invoker' in str(r.get('role')) and ('allUsers' in (r.get('members') or []) or 'allAuthenticatedUsers' in (r.get('members') or [])):
        return 'Cloud Function is publicly invokable'
def func_no_labels(r):
    if not r.get('labels'): return 'Cloud Function has no labels'
def func_no_timeout_set(r):
    if not r.get('timeout'): return 'Cloud Function timeout not explicitly set - runaway costs possible'
def func_old_runtime(r):
    rt = r.get('runtime', '')
    if any(rt.startswith(s) for s in ('nodejs10', 'nodejs12', 'python37', 'go111', 'dotnet3')): return f'Cloud Function runtime {rt} is deprecated/unsupported'
def func_no_kms(r):
    if not r.get('kms_key_name'): return 'Cloud Function environment not encrypted with CMEK'

GCP_CLOUD_FUNCTIONS_RULES = [func_no_vpc_connector, func_ingress_all, func_build_env_secrets, func_env_secrets, func_default_sa, func_all_users_invoker, func_no_labels, func_no_timeout_set, func_old_runtime, func_no_kms]
