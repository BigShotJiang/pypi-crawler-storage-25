
# ============================================================================
# GCP SECURITY RULES - PART 6
# Data Fusion, Dataplex, Datastore, Endpoints, Eventarc, Filestore,
# Healthcare API, IAP, Identity Platform, IoT Core, Network Connectivity,
# Recaptcha, Security Command Center, Source Repositories, Spanner extras.
# ============================================================================

# ── CLOUD DATA FUSION ────────────────────────────────────────────────────────
def datafusion_private_instance(r):
    p = r.get('network_config', {}); p = (p[0] if isinstance(p, list) and p else p) or {}
    if p.get('connection_type', '') != 'VPC_PEERING': return 'Data Fusion instance is not private - uses public IP'
def datafusion_no_cmek(r):
    e = r.get('crypto_key_config', {}); e = (e[0] if isinstance(e, list) and e else e) or {}
    if not e.get('key_reference'): return 'Data Fusion instance not encrypted with CMEK'
def datafusion_no_labels(r):
    if not r.get('labels'): return 'Data Fusion instance has no labels'

GCP_DATAFUSION_RULES = [datafusion_private_instance, datafusion_no_cmek, datafusion_no_labels]

# ── DATAPLEX ─────────────────────────────────────────────────────────────────
def dataplex_lake_no_labels(r):
    if not r.get('labels'): return 'Dataplex Lake has no labels'
def dataplex_zone_discovery_disabled(r):
    d = r.get('discovery_spec', {}); d = (d[0] if isinstance(d, list) and d else d) or {}
    if not d.get('enabled', True): return 'Dataplex Zone discovery is disabled - metadata not automatically crawled'
def dataplex_env_no_fallback(r):
    es = r.get('session_spec', {}); es = (es[0] if isinstance(es, list) and es else es) or {}
    if not es.get('max_idle_duration'): return 'Dataplex Environment has no idle timeout configured'

GCP_DATAPLEX_RULES = [dataplex_lake_no_labels, dataplex_zone_discovery_disabled, dataplex_env_no_fallback]

# ── CLOUD DATASTORE / FIRESTORE ──────────────────────────────────────────────
def datastore_public_access(r):
    if 'roles/datastore.viewer' in str(r.get('role')) and ('allUsers' in str(r.get('members')) or 'allAuthenticatedUsers' in str(r.get('members'))):
        return 'Cloud Datastore allows public read access - CRITICAL RISK'
def firestore_cmek(r):
    if not r.get('cmek_config'): return 'Firestore Database not encrypted with CMEK'
def firestore_pitr_off(r):
    if not r.get('point_in_time_recovery_enablement') == 'POINT_IN_TIME_RECOVERY_ENABLED': return 'Firestore Point-in-time Recovery (PITR) disabled'
def firestore_delete_protection_off(r):
    if not r.get('delete_protection_state') == 'DELETE_PROTECTION_ENABLED': return 'Firestore Delete Protection disabled'

GCP_FIRESTORE_RULES = [datastore_public_access, firestore_cmek, firestore_pitr_off, firestore_delete_protection_off]

# ── CLOUD ENDPOINTS ──────────────────────────────────────────────────────────
def endpoints_no_api_key_required(r):
    o = r.get('openapi_config', '')
    if o and 'security:' not in str(o).lower(): return 'Cloud Endpoints API doesn\'t require authentication (API key or OAuth)'
def endpoints_grpc_no_ssl(r):
    g = r.get('grpc_config', '')
    if g and 'ssl' not in str(g).lower(): return 'Cloud Endpoints gRPC API may not enforce SSL'

GCP_ENDPOINTS_RULES = [endpoints_no_api_key_required, endpoints_grpc_no_ssl]

# ── EVENTARC ─────────────────────────────────────────────────────────────────
def eventarc_no_cmek(r):
    if not r.get('crypto_key_name'): return 'Eventarc trigger not encrypted with CMEK'
def eventarc_no_channel(r):
    if not r.get('channel'): return 'Eventarc trigger does not use a dedicated channel - shares default channel'
def eventarc_default_sa(r):
    sa = r.get('service_account', '')
    if 'compute@developer.gserviceaccount.com' in sa: return 'Eventarc uses default compute service account'

GCP_EVENTARC_RULES = [eventarc_no_cmek, eventarc_no_channel, eventarc_default_sa]

# ── FILESTORE ────────────────────────────────────────────────────────────────
def filestore_no_private_ip(r):
    n = r.get('networks', {}); n = (n[0] if isinstance(n, list) and n else n) or {}
    m = n.get('modes', [])
    if 'MODE_IPV4' not in m: return 'Filestore instance does not explicitly use private IPv4'
def filestore_no_cmek(r):
    if not r.get('kms_key_name'): return 'Filestore instance not encrypted with CMEK'
def filestore_no_backups(r):
    if r.get('tier', 'BASIC_HDD') in ('BASIC_HDD', 'BASIC_SSD'): return 'Filestore uses basic tier - automated backups unsupported'

GCP_FILESTORE_RULES = [filestore_no_private_ip, filestore_no_cmek, filestore_no_backups]

# ── IDENTITY AWARE PROXY (IAP) ───────────────────────────────────────────────
def iap_web_all_users(r):
    if 'roles/iap.httpsResourceAccessor' in str(r.get('role')) and ('allUsers' in str(r.get('members')) or 'allAuthenticatedUsers' in str(r.get('members'))):
        return 'IAP Web resource allows public access - defeats the purpose of IAP'
def iap_tunnel_all_users(r):
    if 'roles/iap.tunnelResourceAccessor' in str(r.get('role')) and ('allUsers' in str(r.get('members')) or 'allAuthenticatedUsers' in str(r.get('members'))):
        return 'IAP TCP Tunnel allows public access - CRITICAL RISK'

GCP_IAP_RULES = [iap_web_all_users, iap_tunnel_all_users]

# ── IDENTITY PLATFORM ────────────────────────────────────────────────────────
def identity_anonymous_auth(r):
    sc = r.get('sign_in', {}); sc = (sc[0] if isinstance(sc, list) and sc else sc) or {}
    aa = sc.get('anonymous', {}); aa = (aa[0] if isinstance(aa, list) and aa else aa) or {}
    if aa.get('enabled', False): return 'Identity Platform allows anonymous authentication - review if needed'
def identity_multi_factor_optional(r):
    m = r.get('mfa', {}); m = (m[0] if isinstance(m, list) and m else m) or {}
    if m.get('state', 'DISABLED') != 'MANDATORY': return 'Identity Platform MFA not set to MANDATORY'
def identity_no_authorized_domains(r):
    if not r.get('authorized_domains'): return 'Identity Platform has no authorized domains - vulnerable to unauthorized hosting'

GCP_IDENTITY_RULES = [identity_anonymous_auth, identity_multi_factor_optional, identity_no_authorized_domains]

# ── IOT CORE ─────────────────────────────────────────────────────────────────
def iot_registry_no_mqtt(r):
    if r.get('mqtt_config', {}).get('mqtt_config_state', 'MQTT_ENABLED') == 'MQTT_DISABLED': return 'IoT Registry MQTT disabled'
def iot_registry_no_http(r):
    if r.get('http_config', {}).get('http_config_state', 'HTTP_ENABLED') == 'HTTP_DISABLED': return 'IoT Registry HTTP disabled'

GCP_IOT_RULES = [iot_registry_no_mqtt, iot_registry_no_http]

# ── NETWORK CONNECTIVITY ─────────────────────────────────────────────────────
def ncc_hub_no_labels(r):
    if not r.get('labels'): return 'Network Connectivity Hub has no labels'
def ncc_spoke_no_labels(r):
    if not r.get('labels'): return 'Network Connectivity Spoke has no labels'

GCP_NCC_RULES = [ncc_hub_no_labels, ncc_spoke_no_labels]

# ── RECAPTCHA ENTERPRISE ─────────────────────────────────────────────────────
def recaptcha_key_no_domain_restriction(r):
    ws = r.get('web_settings', {}); ws = (ws[0] if isinstance(ws, list) and ws else ws) or {}
    if not ws.get('allowed_domains') and ws.get('integration_type', 'SCORE') != 'SCORE':
        return 'reCAPTCHA Enterprise key has no allowed domains configured'
def recaptcha_key_no_waf(r):
    wf = r.get('waf_settings', {}); wf = (wf[0] if isinstance(wf, list) and wf else wf) or {}
    if wf.get('waf_service', 'WAF_SERVICE_UNSPECIFIED') == 'WAF_SERVICE_UNSPECIFIED': return 'reCAPTCHA Enterprise key not integrated with Cloud Armor WAF'

GCP_RECAPTCHA_RULES = [recaptcha_key_no_domain_restriction, recaptcha_key_no_waf]

# ── SECURITY COMMAND CENTER ──────────────────────────────────────────────────
def scc_mute_rule_active(r):
    if not r.get('description'): return 'SCC mute rule has no description to explain bypass'
def scc_notification_no_filter(r):
    if not r.get('filter'): return 'SCC Notification config routes all findings - likely to cause alert fatigue'

GCP_SCC_RULES = [scc_mute_rule_active, scc_notification_no_filter]

# ── SOURCE REPOSITORIES ──────────────────────────────────────────────────────
def source_repo_public(r):
    if 'roles/source.reader' in str(r.get('role')) and ('allUsers' in str(r.get('members')) or 'allAuthenticatedUsers' in str(r.get('members'))):
        return 'Cloud Source Repository allows public read access - CRITICAL source code exposure'
def source_repo_no_pubsub(r):
    if not r.get('pubsub_configs'): return 'Cloud Source Repository has no Pub/Sub notifications configured for commits'

GCP_SOURCE_RULES = [source_repo_public, source_repo_no_pubsub]

# ── SPANNER EXTRA / REFINED ──────────────────────────────────────────────────
def spanner_backup_retention_short(r):
    dr = r.get('retention_period', '')
    if dr and 'd' in dr and int(dr.replace('d', '') or 0) < 7: return 'Cloud Spanner backup retention < 7 days'
def spanner_instance_single_node(r):
    if int(r.get('num_nodes', 1) or 1) < 1 and int(r.get('processing_units', 100) or 100) < 1000:
        return 'Cloud Spanner compute capacity is extremely low - production requires at least 1000 PU / 1 node'

GCP_SPANNER_EXTRA_RULES = [spanner_backup_retention_short, spanner_instance_single_node]

# ── BIGQUERY DATA TRANSFER ───────────────────────────────────────────────────
def bq_dt_no_email_notif(r):
    e = r.get('email_preferences', {}); e = (e[0] if isinstance(e, list) and e else e) or {}
    if not e.get('enable_failure_email', False): return 'BQ Data Transfer config does not send failure emails'
def bq_dt_pubsub_none(r):
    if not r.get('pubsub_topic'): return 'BQ Data Transfer has no Pub/Sub topic for programmatic failure alerts'

GCP_BQ_DT_RULES = [bq_dt_no_email_notif, bq_dt_pubsub_none]

# ── CLOUD RUN DOMAIN MAPPING ─────────────────────────────────────────────────
def run_domain_no_cert_override(r):
    s = r.get('spec', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    if s.get('certificate_mode', 'AUTOMATIC') == 'AUTOMATIC': return 'Cloud Run domain mapping uses automatic Google certs - verify CAA records allow letsencrypt'

GCP_RUN_DOMAIN_RULES = [run_domain_no_cert_override]

# ── CLOUD SCHEDULER ──────────────────────────────────────────────────────────
def scheduler_no_retry(r):
    rc = r.get('retry_config', {}); rc = (rc[0] if isinstance(rc, list) and rc else rc) or {}
    if int(rc.get('retry_count', 0) or 0) == 0: return 'Cloud Scheduler job has no retries configured'
def scheduler_http_no_auth(r):
    h = r.get('http_target', {}); h = (h[0] if isinstance(h, list) and h else h) or {}
    if h and not h.get('oidc_token') and not h.get('oauth_token'): return 'Cloud Scheduler HTTP target uses no authentication'

GCP_SCHEDULER_RULES = [scheduler_no_retry, scheduler_http_no_auth]

# ── CLOUD BUILD REFINED ──────────────────────────────────────────────────────
def build_trigger_no_approval(r):
    a = r.get('approval_config', {}); a = (a[0] if isinstance(a, list) and a else a) or {}
    if not a.get('approval_required', False): return 'Cloud Build trigger does not require manual approval - CI/CD pipeline runs automatically'

GCP_BUILD_EXTRA_RULES = [build_trigger_no_approval]
