# main.py - Simple policy checker
from utils import parser
from utils import rules

def evaluate_custom_rule(resource, custom_rule):
    """Evaluate a custom rule against a resource"""
    condition = custom_rule.get('condition')
    value = custom_rule.get('value', '')
    
    # Map condition types to evaluation logic
    if condition == 'must_have':
        # Check if a required property exists and is truthy
        return not resource.get(value, False)
    
    elif condition == 'must_not_have':
        # Check if a property should not exist or be falsy
        return bool(resource.get(value, False))
    
    elif condition == 'equals':
        # Check if property equals value
        return resource.get(value) != value
    
    elif condition == 'not_equals':
        # Check if property does not equal value
        return resource.get(value) == value
    
    elif condition == 'contains':
        # Check if property contains value
        resource_value = str(resource.get(value, ''))
        return value not in resource_value
    
    elif condition == 'not_contains':
        # Check if property does not contain value
        resource_value = str(resource.get(value, ''))
        return value in resource_value
    
    elif condition == 'greater_than':
        # Check if property is greater than value
        try:
            return float(resource.get(value, 0)) <= float(value)
        except (ValueError, TypeError):
            return True
    
    elif condition == 'less_than':
        # Check if property is less than value
        try:
            return float(resource.get(value, 0)) >= float(value)
        except (ValueError, TypeError):
            return True
    
    return False

def check_resource(resource, resource_type, registry=None):
    """Check a single resource against applicable rules from the given registry."""
    violations = []

    if registry is None:
        registry = rules.RULE_REGISTRY

    applicable_rules = registry.get(resource_type, [])

    for rule in applicable_rules:
        try:
            result = rule(resource)
            if result:
                severity = get_severity(result)
                violations.append({
                    'rule': rule.__doc__.strip() if rule.__doc__ else rule.__name__,
                    'violation': result,
                    'severity': severity
                })
        except Exception as exc:
            violations.append({
                'rule': rule.__name__,
                'violation': f'[RULE ERROR]: {exc}',
                'severity': 'HIGH'
            })

    # Always evaluate user-defined custom rules (regardless of tier)
    for custom_rule in rules.get_all_custom_rules():
        if custom_rule.get('resource_type') == resource_type:
            try:
                if custom_rule.get('type') == 'code':
                    local_vars = {'resource': resource}
                    exec(custom_rule.get('code', ''), {}, local_vars)
                    result = local_vars.get('check_resource', lambda x: None)(resource)
                    if result:
                        violations.append({
                            'rule': custom_rule.get('name'),
                            'violation': result,
                            'severity': custom_rule.get('severity', 'MEDIUM')
                        })
                else:
                    if evaluate_custom_rule(resource, custom_rule):
                        violations.append({
                            'rule': custom_rule.get('name'),
                            'violation': custom_rule.get('description', 'Custom rule violation'),
                            'severity': custom_rule.get('severity', 'MEDIUM')
                        })
            except Exception as e:
                violations.append({
                    'rule': custom_rule.get('name'),
                    'violation': f'Error executing rule: {str(e)}',
                    'severity': 'HIGH'
                })

    return violations


_PREMIUM_CLOUD_PREFIXES = ('google_', 'azurerm_', 'oci_')

_PREMIUM_NUDGE = (
    'Upgrade to Premium to unlock {count} additional security checks '
    'for {resource_type} — covering encryption, HA, compliance, and more.'
)


def check_resources(resources, has_subscription=False):
    """Check all resources against rules.

    Free tier  → RULE_REGISTRY_FREE (~44 rules, 8 core AWS services).
    Premium    → RULE_REGISTRY      (730+ rules, 73 resource types).
    GCP / Azure / OCI always require a subscription.
    """
    all_violations = []

    active_registry  = rules.RULE_REGISTRY if has_subscription else rules.RULE_REGISTRY_FREE
    full_registry    = rules.RULE_REGISTRY      # for premium nudge counts
    free_registry    = rules.RULE_REGISTRY_FREE

    for resource_item in resources:
        for resource_type, resource_configs in resource_item.items():

            is_cloud_premium = any(
                resource_type.startswith(p) for p in _PREMIUM_CLOUD_PREFIXES
            )
            in_full_registry = resource_type in full_registry
            in_free_registry = resource_type in free_registry

            for resource_name, resource_config in resource_configs.items():
                # ── 1. Non-AWS cloud providers (GCP / Azure / OCI) ──────────
                if is_cloud_premium and not has_subscription:
                    all_violations.append({
                        'resource_type': resource_type,
                        'resource_name': resource_name,
                        'rule': 'SUBSCRIPTION_REQUIRED',
                        'severity': 'CRITICAL',
                        'violation': (
                            'Monthly subscription required to use non-AWS '
                            '(GCP, Azure, Oracle) security rules - CRITICAL RISK'
                        ),
                    })
                    continue

                # ── 2. Extended AWS resource types (premium-only) ───────────
                if not has_subscription and not in_free_registry and in_full_registry:
                    extra_count = len(full_registry.get(resource_type, []))
                    all_violations.append({
                        'resource_type': resource_type,
                        'resource_name': resource_name,
                        'rule': 'PREMIUM_ONLY_RESOURCE',
                        'severity': 'MEDIUM',
                        'violation': (
                            f'[PREMIUM] Upgrade to unlock {extra_count} security checks '
                            f'for {resource_type} (CloudTrail, EKS, DynamoDB, WAF, '
                            f'Redshift, MSK and 65+ more resource types are Premium-only)'
                        ),
                    })
                    continue

                # ── 3. Core resource types: run free or full rules ──────────
                if not in_free_registry and not in_full_registry:
                    continue  # no rules for this type at all

                # For core types, free users run base rules; premium runs extended
                if not has_subscription and in_free_registry:
                    free_count = len(active_registry.get(resource_type, []))
                    extra_count = len(full_registry.get(resource_type, [])) - free_count
                    violations = check_resource(resource_config, resource_type, active_registry)
                    for v in violations:
                        all_violations.append({
                            'resource_type': resource_type,
                            'resource_name': resource_name,
                            'violation': v['violation'],
                            'rule': v['rule'],
                            'severity': v['severity']
                        })
                    # Append a single soft nudge about extra premium checks
                    if extra_count > 0:
                        all_violations.append({
                            'resource_type': resource_type,
                            'resource_name': resource_name,
                            'violation': (
                                f'[PREMIUM] {extra_count} additional checks available '
                                f'for {resource_type} — upgrade to unlock'
                            ),
                            'rule': 'PREMIUM_UPSELL',
                            'severity': 'LOW'
                        })
                else:
                    violations = check_resource(resource_config, resource_type, active_registry)
                    for v in violations:
                        all_violations.append({
                            'resource_type': resource_type,
                            'resource_name': resource_name,
                            'violation': v['violation'],
                            'rule': v['rule'],
                            'severity': v['severity']
                        })

    return all_violations

def get_severity(violation_text):
    """Determine severity level from violation text and patterns"""
    text = str(violation_text).upper()
    if 'CRITICAL' in text:
        return 'CRITICAL'
    elif 'HIGH' in text:
        return 'HIGH'
    elif 'MEDIUM' in text:
        return 'MEDIUM'
    
    # Contextual keywords
    medium_risks = ['COST RISK', 'DR PROTECTION', 'AVAILABILITY RISK', 'GOVERNANCE ISSUE', 'EXPOSURE RISK']
    if any(risk in text for risk in medium_risks):
        return 'MEDIUM'
        
    return 'LOW'

# Example usage
if __name__ == '__main__':
    # Parse the Terraform file
    resources = parser.parse_terraform_file('main.tf')
    
    # Check all resources
    violations = check_resources(resources)
    
    # Group by severity
    by_severity = {'CRITICAL': [], 'HIGH': [], 'MEDIUM': [], 'LOW': []}
    for v in violations:
        severity = get_severity(v['violation'])
        by_severity[severity].append(v)
    
    print(f"\n{'='*70}")
    print(f"SECURITY POLICY CHECK RESULTS")
    print(f"{'='*70}")
    print(f"Total violations found: {len(violations)}\n")
    
    for severity in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']:
        if by_severity[severity]:
            print(f"\n{severity} SEVERITY ({len(by_severity[severity])} issues):")
            print("-" * 70)
            for v in by_severity[severity]:
                print(f"  [{severity}] {v['resource_type']}.{v['resource_name']}")
                print(f"           {v['violation']}\n")