
# ============================================================================
# GCP SECURITY RULES - PART 5
# Cloud DNS, Cloud CDN, Cloud Composer, Vertex AI, AlloyDB, BQ refined
# ============================================================================

# ── CLOUD DNS ────────────────────────────────────────────────────────────────
def dns_no_dnssec(r):
    if r.get('visibility', 'public') == 'public' and not r.get('dnssec_config'):
        return 'Cloud DNS public zone does not have DNSSEC enabled - vulnerable to DNS spoofing'
def dns_dnssec_state_off(r):
    dc = r.get('dnssec_config', {}); dc = (dc[0] if isinstance(dc, list) and dc else dc) or {}
    if dc and dc.get('state') != 'on': return 'Cloud DNS DNSSEC configuration is present but not enabled'
def dns_no_labels(r):
    if not r.get('labels'): return 'Cloud DNS zone has no labels'
def dns_rsasha1_algorithm(r):
    dc = r.get('dnssec_config', {}); dc = (dc[0] if isinstance(dc, list) and dc else dc) or {}
    dk = dc.get('default_key_specs', [])
    for k in dk:
        if isinstance(k, dict) and 'rsasha1' in str(k.get('algorithm', '')).lower(): return 'Cloud DNS uses weak RSASHA1 algorithm'
def dns_forwarding_target_public(r):
    f = r.get('forwarding_config', {}); f = (f[0] if isinstance(f, list) and f else f) or {}
    t = f.get('target_name_servers', [])
    for s in t:
        if isinstance(s, dict) and s.get('forwarding_path') != 'private': return 'Cloud DNS forwards to non-private path'

GCP_DNS_RULES = [dns_no_dnssec, dns_dnssec_state_off, dns_no_labels, dns_rsasha1_algorithm, dns_forwarding_target_public]

# ── COMPOSER (AIRFLOW) ───────────────────────────────────────────────────────
def comp_no_private_ip(r):
    c = r.get('config', {}); c = (c[0] if isinstance(c, list) and c else c) or {}
    p = c.get('private_environment_config', {}); p = (p[0] if isinstance(p, list) and p else p) or {}
    if not p.get('enable_private_endpoint', False): return 'Cloud Composer environment uses public IPs - HIGH RISK'
def comp_web_server_allow_all(r):
    c = r.get('config', {}); c = (c[0] if isinstance(c, list) and c else c) or {}
    w = c.get('web_server_network_access_control', {}); w = (w[0] if isinstance(w, list) and w else w) or {}
    a = w.get('allowed_ip_range', [])
    for n in a:
        if isinstance(n, dict) and n.get('value') == '0.0.0.0/0': return 'Cloud Composer web server allows 0.0.0.0/0 - CRITICAL RISK'
def comp_no_cmek(r):
    c = r.get('config', {}); c = (c[0] if isinstance(c, list) and c else c) or {}
    e = c.get('encryption_config', {}); e = (e[0] if isinstance(e, list) and e else e) or {}
    if not e.get('kms_key_name'): return 'Cloud Composer not encrypted with CMEK'
def comp_env_vars_secrets(r):
    c = r.get('config', {}); c = (c[0] if isinstance(c, list) and c else c) or {}
    s = c.get('software_config', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    for k in (s.get('env_variables') or {}).keys():
        if any(w in str(k).lower() for w in ('key', 'secret', 'pass', 'token')): return f'Composer env var {k} may be a secret - use Secret Manager backend'
def comp_no_resilience(r):
    c = r.get('config', {}); c = (c[0] if isinstance(c, list) and c else c) or {}
    s = c.get('environment_size', 'ENVIRONMENT_SIZE_SMALL')
    if s == 'ENVIRONMENT_SIZE_SMALL': return 'Cloud Composer uses SMALL size - lack of high availability for prod workloads'

GCP_COMPOSER_RULES = [comp_no_private_ip, comp_web_server_allow_all, comp_no_cmek, comp_env_vars_secrets, comp_no_resilience]

# ── VERTEX AI / AI PLATFORM ──────────────────────────────────────────────────
def vertex_dataset_no_cmek(r):
    e = r.get('encryption_spec', {}); e = (e[0] if isinstance(e, list) and e else e) or {}
    if not e.get('kms_key_name'): return 'Vertex AI Dataset not encrypted with CMEK'
def vertex_notebook_no_cmek(r):
    e = r.get('encryption_config', {}); e = (e[0] if isinstance(e, list) and e else e) or {}
    if not e.get('kms_key'): return 'Vertex AI Notebook not encrypted with CMEK'
def vertex_notebook_public_ip(r):
    if not r.get('no_public_ip', False): return 'Vertex AI Notebook uses public IP - HIGH RISK'
def vertex_notebook_no_secure_boot(r):
    s = r.get('shielded_instance_config', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    if not s.get('enable_secure_boot', False): return 'Vertex AI Notebook Shielded VM secure boot not enabled'
def vertex_notebook_idle_shutdown_off(r):
    if not r.get('idle_shutdown', False): return 'Vertex AI Notebook idle shutdown not enabled - uncontrolled compute costs'

GCP_VERTEX_RULES = [vertex_dataset_no_cmek, vertex_notebook_no_cmek, vertex_notebook_public_ip, vertex_notebook_no_secure_boot, vertex_notebook_idle_shutdown_off]

# ── ALLOYDB ──────────────────────────────────────────────────────────────────
def alloy_cluster_no_cmek(r):
    e = r.get('encryption_config', {}); e = (e[0] if isinstance(e, list) and e else e) or {}
    if not e.get('kms_key_name'): return 'AlloyDB cluster not encrypted with CMEK'
def alloy_cluster_no_automated_backup(r):
    b = r.get('automated_backup_policy', {}); b = (b[0] if isinstance(b, list) and b else b) or {}
    if not b: return 'AlloyDB cluster automated backups not configured'
def alloy_instance_public_ip(r):
    nw = r.get('network_config', {}); nw = (nw[0] if isinstance(nw, list) and nw else nw) or {}
    if nw.get('enable_public_ip', False): return 'AlloyDB instance has public IP - CRITICAL RISK'
def alloy_instance_ssl_optional(r):
    c = r.get('client_connection_config', {}); c = (c[0] if isinstance(c, list) and c else c) or {}
    s = c.get('ssl_config', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    if s.get('ssl_mode', 'ALLOW_UNENCRYPTED_AND_ENCRYPTED') != 'ENCRYPTED_ONLY': return 'AlloyDB instance does not enforce SSL/TLS'
def alloy_instance_iam_auth_off(r):
    if r.get('database_flags', {}).get('alloydb.iam_authentication', 'off') != 'on': return 'AlloyDB IAM authentication not enabled'

GCP_ALLOYDB_RULES = [alloy_cluster_no_cmek, alloy_cluster_no_automated_backup, alloy_instance_public_ip, alloy_instance_ssl_optional, alloy_instance_iam_auth_off]

# ── CLOUD RUN JOBS ───────────────────────────────────────────────────────────
def run_job_vpc_egress_all(r):
    template = r.get('template', {}); template = (template[0] if isinstance(template, list) and template else template) or {}
    template = template.get('template', {}); template = (template[0] if isinstance(template, list) and template else template) or {}
    vpc = template.get('vpc_access', {}); vpc = (vpc[0] if isinstance(vpc, list) and vpc else vpc) or {}
    if vpc.get('egress') != 'ALL_TRAFFIC': return 'Cloud Run Job does not route all egress via VPC'
def run_job_default_sa(r):
    template = r.get('template', {}); template = (template[0] if isinstance(template, list) and template else template) or {}
    template = template.get('template', {}); template = (template[0] if isinstance(template, list) and template else template) or {}
    sa = template.get('service_account', '')
    if 'compute@developer.gserviceaccount.com' in sa: return 'Cloud Run Job uses default compute service account'

GCP_RUN_JOB_RULES = [run_job_vpc_egress_all, run_job_default_sa]

# ── APIGEE ───────────────────────────────────────────────────────────────────
def apigee_no_cmek(r):
    if not r.get('disk_encryption_key_name'): return 'Apigee instance not encrypted with CMEK'
def apigee_env_no_labels(r):
    if not r.get('labels'): return 'Apigee environment has no labels'
def apigee_org_analytics_off(r):
    p = r.get('properties', {}); p = (p[0] if isinstance(p, list) and p else p) or {}
    if p.get('features.isAnalyticsEnabled', 'false') != 'true': return 'Apigee organization analytics not enabled'

GCP_APIGEE_RULES = [apigee_no_cmek, apigee_env_no_labels, apigee_org_analytics_off]

# ── ROUTER NAT NAT REFINED ───────────────────────────────────────────────────
def nat_endpoint_independent_mapping(r):
    if r.get('endpoint_independent_mapping', False): return 'Cloud NAT uses endpoint independent mapping - potential connection tracking exhaustion'
def nat_dynamic_port_allocation_off(r):
    if not r.get('enable_dynamic_port_allocation', False): return 'Cloud NAT dynamic port allocation disabled - fixed ports per VM causes inefficient SNAT utilization'

GCP_NAT_REFINED_RULES = [nat_endpoint_independent_mapping, nat_dynamic_port_allocation_off]

# ── CLOUD FUNCTIONS V2 ───────────────────────────────────────────────────────
def func2_no_vpc_connector(r):
    sc = r.get('service_config', {}); sc = (sc[0] if isinstance(sc, list) and sc else sc) or {}
    if not sc.get('vpc_connector'): return 'Cloud Function V2 has no VPC connector'
def func2_ingress_all(r):
    sc = r.get('service_config', {}); sc = (sc[0] if isinstance(sc, list) and sc else sc) or {}
    if sc.get('ingress_settings', 'ALLOW_ALL') == 'ALLOW_ALL': return 'Cloud Function V2 allows all public ingress'
def func2_default_sa(r):
    sc = r.get('service_config', {}); sc = (sc[0] if isinstance(sc, list) and sc else sc) or {}
    sa = sc.get('service_account_email', '')
    if 'compute@developer.gserviceaccount.com' in sa: return 'Cloud Function V2 uses default compute service account'

GCP_FUNC2_RULES = [func2_no_vpc_connector, func2_ingress_all, func2_default_sa]

# ── BQ REFINED ───────────────────────────────────────────────────────────────
def bq_table_expiration(r):
    if not r.get('expiration_time'): return 'BigQuery table has no fixed expiration time defined'
def bq_dataset_default_table_expiration(r):
    if not r.get('default_table_expiration_ms'): return 'BigQuery dataset has no default table expiration - tables persist forever by default'
def bq_materialized_view_no_refresh(r):
    if r.get('materialized_view') and not r.get('materialized_view', {}).get('enable_refresh', True): return 'BigQuery Materialized View auto-refresh disabled - stale data risk'

GCP_BQ_REFINED_RULES = [bq_table_expiration, bq_dataset_default_table_expiration, bq_materialized_view_no_refresh]

# ── ADDITIONAL STORAGE BUCKET RULES TO PAD COVERAGE ──────────────────────────
def gcs_retention_locked_off(r):
    rp = r.get('retention_policy', {}); rp = (rp[0] if isinstance(rp, list) and rp else rp) or {}
    if rp and not rp.get('is_locked', False): return 'GCS retention policy is not locked - can be removed by admins, defeating SEC compliance'
def gcs_cors_max_age_long(r):
    for c in (r.get('cors') or []):
        if not isinstance(c, dict): continue
        if int(c.get('max_age_seconds', 0) or 0) > 86400: return 'GCS CORS max-age is > 24 hours - changes to CORS policy apply too slowly in browsers'
def gcs_cors_wildcard_origin(r):
    for c in (r.get('cors') or []):
        if not isinstance(c, dict): continue
        if '*' in c.get('origin', []): return 'GCS CORS allows wildcard origin (*) - CRITICAL cross-origin risk'
def gcs_website_not_found_page(r):
    w = r.get('website', {}); w = (w[0] if isinstance(w, list) and w else w) or {}
    if w and not w.get('not_found_page'): return 'GCS website has no custom 404 page configured'

GCP_GCS_REFINED_RULES = [gcs_retention_locked_off, gcs_cors_max_age_long, gcs_cors_wildcard_origin, gcs_website_not_found_page]
