
# ============================================================================
# AWS EXTENDED SECURITY RULES - PART 5
# RDS Aurora, DocDB, Neptune, MQ, Athena, Step Functions,
# Config, Route53, Flow Logs, Network ACL, more EC2/S3/IAM extras
# ============================================================================

# ── RDS AURORA RULES ─────────────────────────────────────────────────────────
def check_aurora_no_encryption(r):
    if not r.get('storage_encrypted', False): return 'Aurora cluster not encrypted - HIGH RISK'
def check_aurora_no_deletion_protection(r):
    if not r.get('deletion_protection', False): return 'Aurora cluster has no deletion protection'
def check_aurora_no_backtrack(r):
    if not r.get('backtrack_window'): return 'Aurora cluster has no backtrack configured - no point-in-time rewind'
def check_aurora_no_cloudwatch_logs(r):
    if not r.get('enabled_cloudwatch_logs_exports'): return 'Aurora cluster not exporting logs to CloudWatch'
def check_aurora_no_iam_auth(r):
    if not r.get('iam_database_authentication_enabled', False): return 'Aurora cluster has no IAM database authentication'
def check_aurora_no_performance_insights(r):
    if not r.get('performance_insights_enabled', False): return 'Aurora cluster Performance Insights disabled'
def check_aurora_no_enhanced_monitoring(r):
    if not int(r.get('monitoring_interval', 0) or 0) > 0: return 'Aurora cluster enhanced monitoring disabled'
def check_aurora_no_multi_az(r):
    if not r.get('replication_source_identifier') and int(r.get('availability_zones', ['a'])).__class__.__name__ != 'list': pass
    azs = r.get('availability_zones', [])
    if isinstance(azs, list) and len(azs) < 2: return 'Aurora cluster spans fewer than 2 AZs'
def check_aurora_skip_final_snapshot(r):
    if r.get('skip_final_snapshot', False): return 'Aurora cluster skip_final_snapshot=true - data loss risk'
def check_aurora_no_kms_key(r):
    if r.get('storage_encrypted') and not r.get('kms_key_id'): return 'Aurora uses default KMS key - use customer-managed key'
def check_aurora_no_tags(r):
    if not r.get('tags'): return 'Aurora cluster has no tags'
def check_aurora_engine_not_latest(r):
    engine = r.get('engine', '')
    version = r.get('engine_version', '')
    if 'mysql' in engine and version.startswith('5.6'): return f'Aurora MySQL {version} is end-of-life'
def check_aurora_no_serverless(r):
    sc = r.get('scaling_configuration', {}); sc = (sc[0] if isinstance(sc, list) else sc) or {}
    if r.get('engine_mode') == 'provisioned' and not r.get('_is_high_traffic'): return 'Aurora uses provisioned mode - consider Serverless v2 for variable loads'
def check_aurora_no_global_cluster(r):
    if not r.get('global_cluster_identifier'): return 'Aurora cluster not part of global cluster - no cross-region DR'
def check_aurora_no_snapshot_copy(r):
    if not r.get('copy_tags_to_snapshot', False): return 'Aurora cluster not copying tags to snapshots'

AURORA_CLUSTER_RULES = [check_aurora_no_encryption, check_aurora_no_deletion_protection, check_aurora_no_backtrack,
    check_aurora_no_cloudwatch_logs, check_aurora_no_iam_auth, check_aurora_no_performance_insights,
    check_aurora_no_enhanced_monitoring, check_aurora_no_multi_az, check_aurora_skip_final_snapshot,
    check_aurora_no_kms_key, check_aurora_no_tags, check_aurora_engine_not_latest,
    check_aurora_no_serverless, check_aurora_no_global_cluster, check_aurora_no_snapshot_copy]

# ── DOCDB RULES ─────────────────────────────────────────────────────────────
def check_docdb_no_encryption(r):
    if not r.get('storage_encrypted', False): return 'DocumentDB cluster not encrypted - HIGH RISK'
def check_docdb_no_kms(r):
    if r.get('storage_encrypted') and not r.get('kms_key_id'): return 'DocumentDB uses default KMS key - use customer-managed key'
def check_docdb_no_cloudwatch_logs(r):
    if not r.get('enabled_cloudwatch_logs_exports'): return 'DocumentDB not exporting logs to CloudWatch'
def check_docdb_no_deletion_protection(r):
    if not r.get('deletion_protection', False): return 'DocumentDB deletion protection disabled'
def check_docdb_no_backup_retention(r):
    if int(r.get('backup_retention_period', 1) or 1) < 7: return 'DocumentDB backup retention < 7 days'
def check_docdb_no_tls(r):
    if not r.get('tls_enabled', True): return 'DocumentDB TLS disabled - HIGH RISK'
def check_docdb_no_tags(r):
    if not r.get('tags'): return 'DocumentDB cluster has no tags'
def check_docdb_skip_final_snapshot(r):
    if r.get('skip_final_snapshot', False): return 'DocumentDB skip_final_snapshot=true - data loss risk'
def check_docdb_no_param_group(r):
    pg = r.get('db_cluster_parameter_group_name', '')
    if not pg or pg.startswith('default.'): return 'DocumentDB using default parameter group'
def check_docdb_no_multi_az(r):
    if not r.get('availability_zones') or len(r.get('availability_zones', [])) < 2: return 'DocumentDB cluster spans fewer than 2 AZs'

DOCDB_RULES = [check_docdb_no_encryption, check_docdb_no_kms, check_docdb_no_cloudwatch_logs,
    check_docdb_no_deletion_protection, check_docdb_no_backup_retention, check_docdb_no_tls,
    check_docdb_no_tags, check_docdb_skip_final_snapshot, check_docdb_no_param_group, check_docdb_no_multi_az]

# ── NEPTUNE RULES ────────────────────────────────────────────────────────────
def check_neptune_no_encryption(r):
    if not r.get('storage_encrypted', False): return 'Neptune cluster not encrypted - HIGH RISK'
def check_neptune_no_kms(r):
    if r.get('storage_encrypted') and not r.get('kms_key_id'): return 'Neptune uses default KMS key'
def check_neptune_no_cloudwatch_logs(r):
    if not r.get('enable_cloudwatch_logs_exports'): return 'Neptune not exporting logs to CloudWatch'
def check_neptune_no_deletion_protection(r):
    if not r.get('deletion_protection', False): return 'Neptune deletion protection not enabled'
def check_neptune_no_backup_retention(r):
    if int(r.get('backup_retention_period', 1) or 1) < 7: return 'Neptune backup retention < 7 days'
def check_neptune_no_iam_auth(r):
    if not r.get('iam_database_authentication_enabled', False): return 'Neptune IAM authentication not enabled'
def check_neptune_no_tags(r):
    if not r.get('tags'): return 'Neptune cluster has no tags'
def check_neptune_skip_final_snapshot(r):
    if r.get('skip_final_snapshot', False): return 'Neptune skip_final_snapshot=true - data loss risk'
def check_neptune_no_multi_az(r):
    azs = r.get('availability_zones', [])
    if isinstance(azs, list) and len(azs) < 2: return 'Neptune cluster spans fewer than 2 AZs'

NEPTUNE_RULES = [check_neptune_no_encryption, check_neptune_no_kms, check_neptune_no_cloudwatch_logs,
    check_neptune_no_deletion_protection, check_neptune_no_backup_retention, check_neptune_no_iam_auth,
    check_neptune_no_tags, check_neptune_skip_final_snapshot, check_neptune_no_multi_az]

# ── MQ BROKER RULES ─────────────────────────────────────────────────────────
def check_mq_no_encryption(r):
    ec = r.get('encryption_options', {}); ec = (ec[0] if isinstance(ec, list) else ec) or {}
    if not ec.get('kms_key_id') and not ec.get('use_aws_owned_key', True): return 'MQ broker encryption configuration missing'
def check_mq_public_access(r):
    if r.get('publicly_accessible', False): return 'MQ broker is publicly accessible - CRITICAL RISK'
def check_mq_no_audit_log(r):
    lc = r.get('logs', {}); lc = (lc[0] if isinstance(lc, list) else lc) or {}
    if not lc.get('audit', False): return 'MQ broker audit logging disabled'
def check_mq_no_general_log(r):
    lc = r.get('logs', {}); lc = (lc[0] if isinstance(lc, list) else lc) or {}
    if not lc.get('general', False): return 'MQ broker general logging disabled'
def check_mq_no_auto_minor_upgrade(r):
    if not r.get('auto_minor_version_upgrade', True): return 'MQ broker auto minor version upgrade disabled'
def check_mq_no_tags(r):
    if not r.get('tags'): return 'MQ broker has no tags'
def check_mq_single_instance(r):
    if r.get('deployment_mode', 'SINGLE_INSTANCE') == 'SINGLE_INSTANCE': return 'MQ broker is single instance - no HA'
def check_mq_no_maintenance_window(r):
    if not r.get('maintenance_window_start_time'): return 'MQ broker has no maintenance window configured'

MQ_RULES = [check_mq_no_encryption, check_mq_public_access, check_mq_no_audit_log, check_mq_no_general_log,
    check_mq_no_auto_minor_upgrade, check_mq_no_tags, check_mq_single_instance, check_mq_no_maintenance_window]

# ── ATHENA WORKGROUP RULES ───────────────────────────────────────────────────
def check_athena_no_encryption(r):
    c = r.get('configuration', {}); c = (c[0] if isinstance(c, list) else c) or {}
    rc = c.get('result_configuration', {}); rc = (rc[0] if isinstance(rc, list) else rc) or {}
    ec = rc.get('encryption_configuration', {}); ec = (ec[0] if isinstance(ec, list) else ec) or {}
    if not ec: return 'Athena workgroup query results not encrypted'
def check_athena_no_enforce_config(r):
    c = r.get('configuration', {}); c = (c[0] if isinstance(c, list) else c) or {}
    if not c.get('enforce_workgroup_configuration', True): return 'Athena workgroup configuration not enforced'
def check_athena_no_s3_output(r):
    c = r.get('configuration', {}); c = (c[0] if isinstance(c, list) else c) or {}
    rc = c.get('result_configuration', {}); rc = (rc[0] if isinstance(rc, list) else rc) or {}
    if not rc.get('output_location'): return 'Athena workgroup has no query results output location'
def check_athena_no_tags(r):
    if not r.get('tags'): return 'Athena workgroup has no tags'
def check_athena_no_data_scanned_limit(r):
    c = r.get('configuration', {}); c = (c[0] if isinstance(c, list) else c) or {}
    if not c.get('bytes_scanned_cutoff_per_query'): return 'Athena workgroup has no data scan limit per query - runaway costs'
def check_athena_publish_metrics(r):
    c = r.get('configuration', {}); c = (c[0] if isinstance(c, list) else c) or {}
    if not c.get('publish_cloudwatch_metrics_enabled', False): return 'Athena workgroup does not publish CloudWatch metrics'

ATHENA_WORKGROUP_RULES = [check_athena_no_encryption, check_athena_no_enforce_config, check_athena_no_s3_output,
    check_athena_no_tags, check_athena_no_data_scanned_limit, check_athena_publish_metrics]

# ── STEP FUNCTIONS RULES ─────────────────────────────────────────────────────
def check_sfn_no_encryption(r):
    ec = r.get('encryption_configuration', {}); ec = (ec[0] if isinstance(ec, list) else ec) or {}
    if not ec.get('type') or ec.get('type') == 'NONE': return 'Step Functions state machine has no encryption'
def check_sfn_no_logging(r):
    lc = r.get('logging_configuration', {}); lc = (lc[0] if isinstance(lc, list) else lc) or {}
    if not lc.get('log_destination') and not lc.get('level', 'OFF') != 'OFF': return 'Step Functions logging not configured'
def check_sfn_no_tracing(r):
    tc = r.get('tracing_configuration', {}); tc = (tc[0] if isinstance(tc, list) else tc) or {}
    if not tc.get('enabled', False): return 'Step Functions X-Ray tracing disabled'
def check_sfn_no_tags(r):
    if not r.get('tags'): return 'Step Functions state machine has no tags'
def check_sfn_express_no_logging(r):
    if r.get('type') == 'EXPRESS':
        lc = r.get('logging_configuration', {}); lc = (lc[0] if isinstance(lc, list) else lc) or {}
        if not lc: return 'Express Step Functions workflow has no logging - transient executions not captured'

SFN_RULES = [check_sfn_no_encryption, check_sfn_no_logging, check_sfn_no_tracing, check_sfn_no_tags, check_sfn_express_no_logging]

# ── AWS CONFIG RULES ────────────────────────────────────────────────────────
def check_config_not_enabled(r):
    if not r.get('recording_group') and not r.get('all_supported', False): return 'AWS Config recorder may not be recording all resources'
def check_config_no_s3_delivery(r):
    if not r.get('s3_bucket_name'): return 'AWS Config has no S3 delivery channel configured'
def check_config_no_sns(r):
    if not r.get('sns_topic_arn'): return 'AWS Config has no SNS notification configured'
def check_config_no_global_resources(r):
    rg = r.get('recording_group', {}); rg = (rg[0] if isinstance(rg, list) else rg) or {}
    if not rg.get('include_global_resource_types', False): return 'AWS Config not recording global resource types (IAM etc.)'
def check_config_no_tags(r):
    if not r.get('tags'): return 'AWS Config recorder has no tags'

CONFIG_RECORDER_RULES = [check_config_not_enabled, check_config_no_s3_delivery, check_config_no_sns,
    check_config_no_global_resources, check_config_no_tags]

# ── ROUTE53 RULES ────────────────────────────────────────────────────────────
def check_r53_no_query_logging(r):
    if not r.get('query_log_config_id'): return 'Route53 hosted zone has no query logging'
def check_r53_public_zone(r):
    if not r.get('private_zone', False) and not r.get('vpc'): return 'Route53 zone is public - ensure no sensitive internal records exposed'
def check_r53_no_health_checks(r):
    if not r.get('health_check'): return 'Route53 zone has no health checks configured'
def check_r53_no_dnssec(r):
    if not r.get('dnssec_config') and not r.get('key_signing_key'): return 'Route53 hosted zone has no DNSSEC configured'
def check_r53_no_tags(r):
    if not r.get('tags'): return 'Route53 hosted zone has no tags'
def check_r53_transfer_policy(r):
    if not r.get('transfer_lock'): return 'Route53 domain has no transfer lock - domain hijacking risk'

ROUTE53_RULES = [check_r53_no_query_logging, check_r53_public_zone, check_r53_no_health_checks,
    check_r53_no_dnssec, check_r53_no_tags, check_r53_transfer_policy]

# ── VPC FLOW LOGS RULES ─────────────────────────────────────────────────────
def check_fl_no_all_traffic(r):
    if r.get('traffic_type', 'ALL') != 'ALL': return 'VPC Flow Logs not capturing ALL traffic (only ACCEPT or REJECT)'
def check_fl_no_cloudwatch(r):
    if not r.get('log_group_name') and not r.get('log_destination'): return 'VPC Flow Logs have no CloudWatch or S3 destination'
def check_fl_no_tags(r):
    if not r.get('tags'): return 'VPC Flow Logs have no tags'
def check_fl_no_max_aggregation(r):
    if int(r.get('max_aggregation_interval', 600) or 600) > 60: return 'VPC Flow Logs aggregation interval > 60s - reduce for faster detection'
def check_fl_iam_no_permission(r):
    if not r.get('iam_role_arn'): return 'VPC Flow Logs have no IAM role - publishing may fail'

VPC_FLOW_LOG_RULES = [check_fl_no_all_traffic, check_fl_no_cloudwatch, check_fl_no_tags,
    check_fl_no_max_aggregation, check_fl_iam_no_permission]

# ── NETWORK ACL RULES ────────────────────────────────────────────────────────
def check_nacl_allow_all_ingress(r):
    for entry in (r.get('ingress') or []):
        if isinstance(entry, dict) and entry.get('cidr_block') == '0.0.0.0/0' and entry.get('action') == 'allow' and str(entry.get('from_port', '')) == '0':
            return 'Network ACL allows all inbound traffic from 0.0.0.0/0 - too permissive'
def check_nacl_allow_all_egress(r):
    for entry in (r.get('egress') or []):
        if isinstance(entry, dict) and entry.get('cidr_block') == '0.0.0.0/0' and entry.get('action') == 'allow' and str(entry.get('from_port', '')) == '0':
            return 'Network ACL allows all outbound traffic to 0.0.0.0/0 - restrict egress'
def check_nacl_no_tags(r):
    if not r.get('tags'): return 'Network ACL has no tags'
def check_nacl_ssh_open(r):
    for entry in (r.get('ingress') or []):
        if isinstance(entry, dict) and entry.get('cidr_block') == '0.0.0.0/0' and entry.get('action') == 'allow':
            fp = int(entry.get('from_port', 0) or 0); tp = int(entry.get('to_port', 0) or 0)
            if fp <= 22 <= tp: return 'Network ACL allows SSH (22) from internet - CRITICAL RISK'
def check_nacl_rdp_open(r):
    for entry in (r.get('ingress') or []):
        if isinstance(entry, dict) and entry.get('cidr_block') == '0.0.0.0/0' and entry.get('action') == 'allow':
            fp = int(entry.get('from_port', 0) or 0); tp = int(entry.get('to_port', 0) or 0)
            if fp <= 3389 <= tp: return 'Network ACL allows RDP (3389) from internet - CRITICAL RISK'

NACL_RULES = [check_nacl_allow_all_ingress, check_nacl_allow_all_egress, check_nacl_no_tags,
    check_nacl_ssh_open, check_nacl_rdp_open]

# ── SUBNET RULES ─────────────────────────────────────────────────────────────
def check_subnet_public_ip(r):
    if r.get('map_public_ip_on_launch', False): return 'Subnet auto-assigns public IPs - HIGH RISK for private subnets'
def check_subnet_no_tags(r):
    if not r.get('tags'): return 'Subnet has no tags - cannot identify purpose'
def check_subnet_no_flow_logs(r):
    if not r.get('flow_log_id') and not r.get('_vpc_has_flow_logs'):
        return 'Subnet VPC may have no flow logs - no network visibility'
def check_subnet_ipv6_cidr_public(r):
    if r.get('ipv6_cidr_block') and r.get('map_public_ip_on_launch', False): return 'Subnet has IPv6 CIDR with auto-assign public IP - public dual-stack'

SUBNET_RULES = [check_subnet_public_ip, check_subnet_no_tags, check_subnet_no_flow_logs, check_subnet_ipv6_cidr_public]

# ── S3 BUCKET POLICY RULES ───────────────────────────────────────────────────
def check_s3_policy_public_star(r):
    if '"Principal": "*"' in str(r.get('policy', '') or ''):
        return 'S3 bucket policy has * principal - CRITICAL: public access granted'
def check_s3_policy_allows_delete(r):
    policy = str(r.get('policy', '') or '')
    if 's3:DeleteObject' in policy and '"Principal": "*"' in policy:
        return 'S3 bucket policy allows public DeleteObject - CRITICAL RISK'
def check_s3_policy_no_deny_http(r):
    policy = str(r.get('policy', '') or '')
    if 'aws:SecureTransport' not in policy:
        return 'S3 bucket policy does not deny non-HTTPS requests'
def check_s3_policy_cross_account_access(r):
    policy = str(r.get('policy', '') or '')
    import re
    accounts = re.findall(r'arn:aws:iam::(\d+):', policy)
    if len(set(accounts)) > 1: return 'S3 bucket policy grants cross-account access - review principals'

S3_POLICY_RULES = [check_s3_policy_public_star, check_s3_policy_allows_delete,
    check_s3_policy_no_deny_http, check_s3_policy_cross_account_access]

# ── IAM ACCESS KEY RULES ─────────────────────────────────────────────────────
def check_ak_no_rotation(r):
    age = int(r.get('age_days', 0) or 0)
    if age > 90: return f'IAM access key is {age} days old - rotate every 90 days - HIGH RISK'
def check_ak_never_used(r):
    if not r.get('last_used_date') and not r.get('last_used'): return 'IAM access key has never been used - consider deactivating'
def check_ak_status_active(r):
    if r.get('status') == 'Active' and int(r.get('age_days', 0) or 0) > 180: return 'IAM access key active > 180 days - HIGH RISK'
def check_ak_root_key(r):
    if r.get('user_name') == 'root': return 'Root AWS account has active access key - CRITICAL RISK: deactivate immediately'

IAM_ACCESS_KEY_RULES = [check_ak_no_rotation, check_ak_never_used, check_ak_status_active, check_ak_root_key]

# ── ELASTIC IP RULES ─────────────────────────────────────────────────────────
def check_eip_not_associated(r):
    if not r.get('instance') and not r.get('network_interface_id'): return 'Elastic IP is not associated - paying for unused EIP'
def check_eip_no_tags(r):
    if not r.get('tags'): return 'Elastic IP has no tags'

EIP_RULES = [check_eip_not_associated, check_eip_no_tags]

# ── INTERNET GATEWAY RULES ───────────────────────────────────────────────────
def check_igw_no_tags(r):
    if not r.get('tags'): return 'Internet Gateway has no tags'
def check_igw_not_attached(r):
    if not r.get('vpc_id') and not r.get('attachment'): return 'Internet Gateway is not attached to a VPC'

IGW_RULES = [check_igw_no_tags, check_igw_not_attached]

# ── RDS SNAPSHOT RULES ──────────────────────────────────────────────────────
def check_rds_snapshot_public(r):
    if r.get('publicly_accessible', False): return 'RDS snapshot is public - CRITICAL RISK'
def check_rds_snapshot_no_encryption(r):
    if not r.get('encrypted', False): return 'RDS snapshot is not encrypted - HIGH RISK'
def check_rds_snapshot_no_tags(r):
    if not r.get('tags'): return 'RDS snapshot has no tags'

RDS_SNAPSHOT_RULES = [check_rds_snapshot_public, check_rds_snapshot_no_encryption, check_rds_snapshot_no_tags]

# ── ECS CLUSTER RULES ────────────────────────────────────────────────────────
def check_ecs_cluster_no_container_insights(r):
    settings = r.get('setting', [])
    for s in (settings if isinstance(settings, list) else [settings]):
        if isinstance(s, dict) and s.get('name') == 'containerInsights' and s.get('value') == 'disabled':
            return 'ECS cluster container insights disabled'
    if not settings: return 'ECS cluster has no settings configured - container insights likely disabled'
def check_ecs_cluster_no_tags(r):
    if not r.get('tags'): return 'ECS cluster has no tags'
def check_ecs_cluster_no_capacity_providers(r):
    if not r.get('capacity_providers'): return 'ECS cluster has no capacity providers configured'
def check_ecs_cluster_no_execute_command_kms(r):
    ec = r.get('configuration', {}); ec = (ec[0] if isinstance(ec, list) else ec) or {}
    exe = ec.get('execute_command_configuration', {}); exe = (exe[0] if isinstance(exe, list) else exe) or {}
    if exe and not exe.get('kms_key_id'): return 'ECS execute command not using KMS for session encryption'

ECS_CLUSTER_RULES = [check_ecs_cluster_no_container_insights, check_ecs_cluster_no_tags,
    check_ecs_cluster_no_capacity_providers, check_ecs_cluster_no_execute_command_kms]

# ── ELASTICACHE REPLICATION GROUP EXTRA ─────────────────────────────────────
def check_ecr_rg_no_auth(r):
    if r.get('transit_encryption_enabled') and not r.get('auth_token'): return 'ElastiCache replication group TLS without auth token - HIGH RISK'
def check_ecr_rg_no_automatic_failover(r):
    if not r.get('automatic_failover_enabled', False): return 'ElastiCache replication group automatic failover disabled'
def check_ecr_rg_no_at_rest_encryption(r):
    if not r.get('at_rest_encryption_enabled', False): return 'ElastiCache replication group at-rest encryption disabled'
def check_ecr_rg_single_shard(r):
    if int(r.get('num_cache_clusters', 1) or 1) < 2 and int(r.get('num_node_groups', 1) or 1) < 2:
        return 'ElastiCache replication group has fewer than 2 nodes - single point of failure'
def check_ecr_rg_no_kms(r):
    if r.get('at_rest_encryption_enabled') and not r.get('kms_key_id'): return 'ElastiCache replication group uses default KMS key'
def check_ecr_rg_no_tags(r):
    if not r.get('tags'): return 'ElastiCache replication group has no tags'
def check_ecr_rg_no_maintenance_window(r):
    if not r.get('maintenance_window'): return 'ElastiCache replication group has no maintenance window'
def check_ecr_rg_no_snapshot_window(r):
    if not r.get('snapshot_window'): return 'ElastiCache replication group has no snapshot window'
def check_ecr_rg_version_not_latest(r):
    from_ver = r.get('engine_version', '')
    if from_ver and from_ver.startswith('5.'): return f'ElastiCache Redis {from_ver} may be outdated - upgrade'
def check_ecr_rg_no_global_replication(r):
    if not r.get('global_replication_group_id'): return 'ElastiCache replication group not in global replication group'

ELASTICACHE_RG_EXTRA_RULES = [check_ecr_rg_no_auth, check_ecr_rg_no_automatic_failover, check_ecr_rg_no_at_rest_encryption,
    check_ecr_rg_single_shard, check_ecr_rg_no_kms, check_ecr_rg_no_tags, check_ecr_rg_no_maintenance_window,
    check_ecr_rg_no_snapshot_window, check_ecr_rg_version_not_latest, check_ecr_rg_no_global_replication]

# ── CLOUDWATCH METRIC ALARM RULES ────────────────────────────────────────────
def check_cwa_no_actions(r):
    if not r.get('alarm_actions'): return 'CloudWatch alarm has no actions configured - alerts never sent'
def check_cwa_no_ok_action(r):
    if not r.get('ok_actions'): return 'CloudWatch alarm has no OK action - recovery not notified'
def check_cwa_evaluation_periods_too_high(r):
    if int(r.get('evaluation_periods', 1) or 1) > 10: return 'CloudWatch alarm evaluation period count > 10 - alert may be slow'
def check_cwa_no_tags(r):
    if not r.get('tags'): return 'CloudWatch alarm has no tags'
def check_cwa_threshold_zero(r):
    if r.get('threshold', -1) == 0 and r.get('comparison_operator') not in ['GreaterThanThreshold', 'GreaterThanOrEqualToThreshold']:
        return 'CloudWatch alarm threshold is 0 - may never trigger'
def check_cwa_missing_dimensions(r):
    if not r.get('dimensions'): return 'CloudWatch alarm has no dimensions - monitoring all instances'
def check_cwa_insufficient_data_action(r):
    if not r.get('insufficient_data_actions'): return 'CloudWatch alarm has no insufficient_data action'

CW_METRIC_ALARM_RULES = [check_cwa_no_actions, check_cwa_no_ok_action, check_cwa_evaluation_periods_too_high,
    check_cwa_no_tags, check_cwa_threshold_zero, check_cwa_missing_dimensions, check_cwa_insufficient_data_action]

# ── SNS TOPIC POLICY EXTRA ──────────────────────────────────────────────────
def check_sns_http_endpoint(r):
    for sub in (r.get('subscription') or []):
        if isinstance(sub, dict) and sub.get('protocol') == 'http': return 'SNS subscription uses plain HTTP endpoint - use HTTPS'
def check_sns_email_raw(r):
    for sub in (r.get('subscription') or []):
        if isinstance(sub, dict) and sub.get('protocol') == 'email': return 'SNS subscription uses email protocol - consider SES for reliable delivery'
def check_sns_no_access_policy(r):
    if not r.get('policy'): return 'SNS topic has no resource policy configured'

SNS_EXTRA_RULES = [check_sns_http_endpoint, check_sns_email_raw, check_sns_no_access_policy]

# ── IAM GROUP RULES ──────────────────────────────────────────────────────────
def check_iam_group_admin_policy(r):
    if 'arn:aws:iam::aws:policy/AdministratorAccess' in (r.get('policies') or []): return 'IAM group has AdministratorAccess - CRITICAL RISK'
def check_iam_group_no_users(r):
    if not r.get('users'): return 'IAM group has no users - empty group'
def check_iam_group_no_policies(r):
    if not r.get('policies') and not r.get('policy_attachment'): return 'IAM group has no policies attached'
def check_iam_group_wildcard_policy(r):
    if '"Action": "*"' in str(r.get('policy', '') or ''): return 'IAM group policy uses wildcard actions - CRITICAL RISK'
def check_iam_group_no_tags(r):
    if not r.get('tags'): return 'IAM group has no tags'

IAM_GROUP_RULES = [check_iam_group_admin_policy, check_iam_group_no_users,
    check_iam_group_no_policies, check_iam_group_wildcard_policy, check_iam_group_no_tags]

# ── API GATEWAY REST API RULES ───────────────────────────────────────────────
def check_api_rest_no_client_cert(r):
    if not r.get('client_cert'): return 'API Gateway REST API has no client certificate'
def check_api_rest_no_endpoint_config(r):
    ec = r.get('endpoint_configuration', {}); ec = (ec[0] if isinstance(ec, list) else ec) or {}
    if ec.get('types', ['EDGE'])[0] == 'EDGE': return 'API Gateway uses EDGE endpoint - consider REGIONAL for lower latency'
def check_api_rest_no_tags(r):
    if not r.get('tags'): return 'API Gateway REST API has no tags'
def check_api_rest_no_description(r):
    if not r.get('description'): return 'API Gateway REST API has no description'
def check_api_rest_min_compression_not_set(r):
    if r.get('minimum_compression_size') is None: return 'API Gateway minimum compression not configured'

API_REST_RULES = [check_api_rest_no_client_cert, check_api_rest_no_endpoint_config,
    check_api_rest_no_tags, check_api_rest_no_description, check_api_rest_min_compression_not_set]

# ── EKS NODE GROUP RULES ────────────────────────────────────────────────────
def check_ekng_no_encryption(r):
    lc = r.get('launch_template', {}); lc = (lc[0] if isinstance(lc, list) else lc) or {}
    if not lc.get('_disk_encrypted'): return 'EKS node group disk may not be encrypted'
def check_ekng_public_access(r):
    if not r.get('remote_access') and not r.get('_no_public_access'): return 'EKS node group may have no remote access restriction'
def check_ekng_no_tags(r):
    if not r.get('tags'): return 'EKS node group has no tags'
def check_ekng_no_capacity_type(r):
    if r.get('capacity_type', 'ON_DEMAND') == 'SPOT': return 'EKS node group uses SPOT instances - interruption risk for production'
def check_ekng_small_min_size(r):
    if int(r.get('scaling_config', {}).get('min_size', 0) or 0) == 0: return 'EKS node group min_size is 0 - can scale to zero'
def check_ekng_no_ami_type(r):
    if not r.get('ami_type'): return 'EKS node group has no explicit AMI type configured'

EKS_NODE_GROUP_RULES = [check_ekng_no_encryption, check_ekng_public_access, check_ekng_no_tags,
    check_ekng_no_capacity_type, check_ekng_small_min_size, check_ekng_no_ami_type]
