
# ============================================================================
# GCP SECURITY RULES - PART 3
# GKE, Pub/Sub, BigQuery, Artifact Registry, Dataproc, DNS, Secret Manager
# ============================================================================

# ── GKE CLUSTER ──────────────────────────────────────────────────────────────
def gke_no_private_cluster(r):
    p = r.get('private_cluster_config', {}); p = (p[0] if isinstance(p, list) and p else p) or {}
    if not p.get('enable_private_nodes', False): return 'GKE nodes have public IPs - HIGH RISK'
def gke_public_endpoint(r):
    p = r.get('private_cluster_config', {}); p = (p[0] if isinstance(p, list) and p else p) or {}
    if not p.get('enable_private_endpoint', False): return 'GKE control plane endpoint is publicly accessible - restrict with master authorized networks'
def gke_no_master_auth_networks(r):
    m = r.get('master_authorized_networks_config', {}); m = (m[0] if isinstance(m, list) and m else m) or {}
    if not m: return 'GKE master authorized networks not configured - accessible from anywhere'
def gke_abac_enabled(r):
    if r.get('enable_legacy_abac', False): return 'GKE Legacy ABAC enabled - use RBAC instead'
def gke_basic_auth(r):
    m = r.get('master_auth', {}); m = (m[0] if isinstance(m, list) and m else m) or {}
    cc = m.get('client_certificate_config', {}); cc = (cc[0] if isinstance(cc, list) and cc else cc) or {}
    if r.get('master_auth') and not cc.get('issue_client_certificate', False):
        return 'GKE basic auth or client certificate auth enabled - HIGH RISK: use IAM'
def gke_no_network_policy(r):
    np = r.get('network_policy', {}); np = (np[0] if isinstance(np, list) and np else np) or {}
    if not np.get('enabled', False): return 'GKE Network Policy disabled - no pod-to-pod isolation'
def gke_no_shielded_nodes(r):
    sn = r.get('enable_shielded_nodes', False)
    if not sn: return 'GKE Shielded Nodes not enabled - vulnerability to rootkits'
def gke_no_workload_identity(r):
    wi = r.get('workload_identity_config', {}); wi = (wi[0] if isinstance(wi, list) and wi else wi) or {}
    if not wi.get('workload_pool'): return 'GKE Workload Identity disabled - pods use node service account'
def gke_no_database_encryption(r):
    de = r.get('database_encryption', {}); de = (de[0] if isinstance(de, list) and de else de) or {}
    if de.get('state') != 'ENCRYPTED': return 'GKE secrets not encrypted in etcd with CMEK'
def gke_node_metadata_unconcealed(r):
    nc = r.get('node_config', {}); nc = (nc[0] if isinstance(nc, list) and nc else nc) or {}
    wm = nc.get('workload_metadata_config', {}); wm = (wm[0] if isinstance(wm, list) and wm else wm) or {}
    if wm.get('mode') not in ('GKE_METADATA', 'GCE_METADATA'):
        return 'GKE node metadata concealed incorrectly - pods can access GCE metadata server'
def gke_no_auto_upgrade(r):
    nc = r.get('node_pool', [])
    for np in nc:
        if isinstance(np, dict):
            m = np.get('management', {}); m = (m[0] if isinstance(m, list) and m else m) or {}
            if not m.get('auto_upgrade', True): return 'GKE node auto-upgrade disabled'
def gke_no_auto_repair(r):
    nc = r.get('node_pool', [])
    for np in nc:
        if isinstance(np, dict):
            m = np.get('management', {}); m = (m[0] if isinstance(m, list) and m else m) or {}
            if not m.get('auto_repair', True): return 'GKE node auto-repair disabled'
def gke_default_sa(r):
    nc = r.get('node_config', {}); nc = (nc[0] if isinstance(nc, list) and nc else nc) or {}
    sa = nc.get('service_account', '')
    if sa == 'default' or not sa: return 'GKE node uses default compute service account - overly permissive'
def gke_no_intra_node_visibility(r):
    if not r.get('enable_intranode_visibility', False): return 'GKE intra-node visibility disabled - pod-to-pod traffic invisible to VPC flow logs'
def gke_no_release_channel(r):
    rc = r.get('release_channel', {}); rc = (rc[0] if isinstance(rc, list) and rc else rc) or {}
    if not rc.get('channel'): return 'GKE cluster not enrolled in a release channel - upgrades are manual'
def gke_security_posture_disabled(r):
    sp = r.get('security_posture_config', {}); sp = (sp[0] if isinstance(sp, list) and sp else sp) or {}
    if not sp.get('mode') or sp.get('mode') == 'DISABLED': return 'GKE Security Posture API disabled - vulnerabilities undetected'
def gke_no_logging_monitoring(r):
    ls = r.get('logging_service', 'logging.googleapis.com/kubernetes')
    ms = r.get('monitoring_service', 'monitoring.googleapis.com/kubernetes')
    if ls == 'none' or ms == 'none': return 'GKE Cloud Logging/Monitoring is disabled - observability lost'
def gke_confidential_nodes_disabled(r):
    cc = r.get('confidential_nodes', {}); cc = (cc[0] if isinstance(cc, list) and cc else cc) or {}
    if not cc.get('enabled', False): return 'GKE Confidential Nodes not enabled - data in use not encrypted'

GCP_GKE_RULES = [
    gke_no_private_cluster, gke_public_endpoint, gke_no_master_auth_networks,
    gke_abac_enabled, gke_basic_auth, gke_no_network_policy, gke_no_shielded_nodes,
    gke_no_workload_identity, gke_no_database_encryption, gke_node_metadata_unconcealed,
    gke_no_auto_upgrade, gke_no_auto_repair, gke_default_sa, gke_no_intra_node_visibility,
    gke_no_release_channel, gke_security_posture_disabled, gke_no_logging_monitoring,
    gke_confidential_nodes_disabled,
]

# ── PUB/SUB ──────────────────────────────────────────────────────────────────
def pubsub_no_kms(r):
    if not r.get('kms_key_name'): return 'Pub/Sub topic not encrypted with CMEK'
def pubsub_public_access(r):
    if 'roles/pubsub.publisher' in str(r.get('role')) or 'roles/pubsub.subscriber' in str(r.get('role')):
        if 'allUsers' in str(r.get('members')) or 'allAuthenticatedUsers' in str(r.get('members')):
            return 'Pub/Sub topic allows public publish/subscribe - CRITICAL RISK'
def pubsub_no_labels(r):
    if not r.get('labels'): return 'Pub/Sub topic has no labels'
def sub_no_dlq(r):
    if not r.get('dead_letter_policy'): return 'Pub/Sub subscription has no dead-letter policy - poison pill messages will block'
def sub_no_expiration(r):
    ep = r.get('expiration_policy', {}); ep = (ep[0] if isinstance(ep, list) and ep else ep) or {}
    if ep.get('ttl') == '' or r.get('expiration_policy') == []: return 'Pub/Sub subscription has no expiration - unread messages persist indefinitely'
def sub_no_retry_policy(r):
    if not r.get('retry_policy'): return 'Pub/Sub subscription has no explicit retry policy - uses immediate backoff'

GCP_PUBSUB_RULES = [pubsub_no_kms, pubsub_public_access, pubsub_no_labels, sub_no_dlq, sub_no_expiration, sub_no_retry_policy]

# ── BIGQUERY ─────────────────────────────────────────────────────────────────
def bq_public_dataset(r):
    for a in (r.get('access') or []):
        if not isinstance(a, dict): continue
        if a.get('special_group') == 'allAuthenticatedUsers' or a.get('user_by_email') == 'allUsers':
            return 'BigQuery dataset is public - CRITICAL: data exposure'
def bq_no_cmek(r):
    e = r.get('default_encryption_configuration', {}); e = (e[0] if isinstance(e, list) and e else e) or {}
    if not e.get('kms_key_name'): return 'BigQuery dataset not encrypted with CMEK by default'
def bq_table_no_cmek(r):
    e = r.get('encryption_configuration', {}); e = (e[0] if isinstance(e, list) and e else e) or {}
    if not e.get('kms_key_name'): return 'BigQuery table not encrypted with CMEK'
def bq_no_labels(r):
    if not r.get('labels'): return 'BigQuery dataset has no labels'
def bq_table_no_partitioning(r):
    if not r.get('time_partitioning') and not r.get('range_partitioning'): return 'BigQuery table has no partitioning - full scans will be very expensive'
def bq_table_no_clustering(r):
    if not r.get('cluster_by'): return 'BigQuery table has no clustering - query performance/cost not optimized'
def bq_table_require_partition_filter_off(r):
    tp = r.get('time_partitioning', {}); tp = (tp[0] if isinstance(tp, list) and tp else tp) or {}
    if r.get('time_partitioning') and not tp.get('require_partition_filter', False): return 'BigQuery table does not require partition filter - risk of accidental full scans'
def bq_external_data_config(r):
    if r.get('external_data_configuration'): return 'BigQuery table uses external data source - query costs unpredictable and IAM bypass possible'

GCP_BQ_RULES = [bq_public_dataset, bq_no_cmek, bq_table_no_cmek, bq_no_labels, bq_table_no_partitioning, bq_table_no_clustering, bq_table_require_partition_filter_off, bq_external_data_config]

# ── ARTIFACT REGISTRY / GCR ──────────────────────────────────────────────────
def ar_public_access(r):
    if 'roles/artifactregistry.reader' in str(r.get('role')) and ('allUsers' in str(r.get('members')) or 'allAuthenticatedUsers' in str(r.get('members'))):
        return 'Artifact Registry docker repo is publicly readable - image source code exposed'
def ar_no_cmek(r):
    if not r.get('kms_key_name'): return 'Artifact Registry not encrypted with CMEK'
def ar_no_labels(r):
    if not r.get('labels'): return 'Artifact Registry has no labels'

GCP_AR_RULES = [ar_public_access, ar_no_cmek, ar_no_labels]

# ── DATAPROC ─────────────────────────────────────────────────────────────────
def dataproc_no_internal_ip(r):
    cc = r.get('cluster_config', {}); cc = (cc[0] if isinstance(cc, list) and cc else cc) or {}
    gce = cc.get('gce_cluster_config', {}); gce = (gce[0] if isinstance(gce, list) and gce else gce) or {}
    if not gce.get('internal_ip_only', False): return 'Dataproc cluster nodes have public IPs - use internal networking mapped to Cloud NAT'
def dataproc_default_sa(r):
    cc = r.get('cluster_config', {}); cc = (cc[0] if isinstance(cc, list) and cc else cc) or {}
    gce = cc.get('gce_cluster_config', {}); gce = (gce[0] if isinstance(gce, list) and gce else gce) or {}
    if not gce.get('service_account'): return 'Dataproc cluster uses default compute service account - grant specialized service accounts instead'

GCP_DATAPROC_RULES = [dataproc_no_internal_ip, dataproc_default_sa]

# ── SECRET MANAGER ───────────────────────────────────────────────────────────
def secret_no_cmek(r):
    rep = r.get('replication', {}); rep = (rep[0] if isinstance(rep, list) and rep else rep) or {}
    auto = rep.get('user_managed', {}); auto = (auto[0] if isinstance(auto, list) and auto else auto) or {}
    rep_list = auto.get('replicas', []) or []
    for repl in rep_list:
        if isinstance(repl, dict) and not repl.get('customer_managed_encryption'): return 'Secret Manager secret replica not encrypted with CMEK'
def secret_public_access(r):
    if 'roles/secretmanager.secretAccessor' in str(r.get('role')) and ('allUsers' in str(r.get('members')) or 'allAuthenticatedUsers' in str(r.get('members'))):
        return 'Secret Manager secret is publicly accessible - CRITICAL RISK'
def secret_no_labels(r):
    if not r.get('labels'): return 'Secret Manager secret has no labels'

GCP_SECRET_RULES = [secret_no_cmek, secret_public_access, secret_no_labels]

# ── LOGGING ──────────────────────────────────────────────────────────────────
def logging_no_cmek_sink(r):
    d = r.get('destination', '')
    if 'storage.googleapis.com' in d and 'kmsKeyName' not in d: return 'Logging Sink to GCS is not CMEK encrypted'

GCP_LOGGING_RULES = [logging_no_cmek_sink]
