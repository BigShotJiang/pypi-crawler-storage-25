
# ============================================================================
# GCP SECURITY RULES - PART 7
# Cloud Load Balancing (Regional), VPC Service Controls, Cloud Build Extras,
# Cloud Deploy, Datastream, Assured Workloads, BeyondCorp, Essential Contacts,
# Recommender Hub.
# ============================================================================

# ── VPC SERVICE CONTROLS ─────────────────────────────────────────────────────
def vpc_sc_perimeter_no_resources(r):
    p = r.get('status', {}); p = (p[0] if isinstance(p, list) and p else p) or {}
    if not p.get('resources'): return 'VPC Service Controls perimeter has no resources protected'
def vpc_sc_perimeter_unrestricted_access(r):
    p = r.get('status', {}); p = (p[0] if isinstance(p, list) and p else p) or {}
    for rule in (p.get('ingress_policies') or []):
        if not isinstance(rule, dict): continue
        if rule.get('ingress_from', {}).get('sources', {}).get('access_level') == '*': return 'VPC SC perimeter allows wildcard ingress source'
def vpc_sc_perimeter_no_restricted_services(r):
    p = r.get('status', {}); p = (p[0] if isinstance(p, list) and p else p) or {}
    if not p.get('restricted_services'): return 'VPC SC perimeter has no restricted services defined'

GCP_VPC_SC_RULES = [vpc_sc_perimeter_no_resources, vpc_sc_perimeter_unrestricted_access, vpc_sc_perimeter_no_restricted_services]

# ── BEYONDCORP ENTERPRISE ────────────────────────────────────────────────────
def beyondcorp_app_connector_no_labels(r):
    if not r.get('labels'): return 'BeyondCorp App Connector has no labels'
def beyondcorp_app_gateway_no_labels(r):
    if not r.get('labels'): return 'BeyondCorp App Gateway has no labels'
def beyondcorp_app_connection_no_labels(r):
    if not r.get('labels'): return 'BeyondCorp App Connection has no labels'

GCP_BEYONDCORP_RULES = [beyondcorp_app_connector_no_labels, beyondcorp_app_gateway_no_labels, beyondcorp_app_connection_no_labels]

# ── CLOUD DEPLOY ─────────────────────────────────────────────────────────────
def deploy_pipeline_no_suspension(r):
    if not r.get('suspended', False): return 'Cloud Deploy pipeline is active - verify if intended for continuous deployment'
def deploy_target_no_require_approval(r):
    if not r.get('require_approval', False): return 'Cloud Deploy target does not require approval phase - auto-deployment to critical environments'
def deploy_target_no_labels(r):
    if not r.get('labels'): return 'Cloud Deploy target has no labels'
def deploy_target_no_annotations(r):
    if not r.get('annotations'): return 'Cloud Deploy target has no annotations tracking infrastructure links'

GCP_DEPLOY_RULES = [deploy_pipeline_no_suspension, deploy_target_no_require_approval, deploy_target_no_labels, deploy_target_no_annotations]

# ── ESSENTIAL CONTACTS ───────────────────────────────────────────────────────
def essential_contacts_no_security(r):
    cat = r.get('validation_category', [])
    if 'SECURITY' not in str(cat): return 'Essential Contact does not include SECURITY validation category'
def essential_contacts_no_legal(r):
    cat = r.get('validation_category', [])
    if 'LEGAL' not in str(cat): return 'Essential Contact does not include LEGAL validation category - compliance risk'

GCP_CONTACTS_RULES = [essential_contacts_no_security, essential_contacts_no_legal]

# ── DATASTREAM ───────────────────────────────────────────────────────────────
def datastream_stream_not_private(r):
    b = r.get('backfill_none', {}); b = (b[0] if isinstance(b, list) and b else b) or {}
    if not b: return 'Datastream stream has backfill configured - monitor resource load'
def datastream_connection_profile_no_labels(r):
    if not r.get('labels'): return 'Datastream connection profile has no labels'

GCP_DATASTREAM_RULES = [datastream_stream_not_private, datastream_connection_profile_no_labels]

# ── ASSURED WORKLOADS ────────────────────────────────────────────────────────
def assured_workloads_no_labels(r):
    if not r.get('labels'): return 'Assured Workload has no labels'
def assured_workloads_no_violation_acknowledgement(r):
    if r.get('violation_acknowledgement_instructions'): return 'Assured Workload has open violation acknowledgements'

GCP_ASSURED_WORKLOADS_RULES = [assured_workloads_no_labels, assured_workloads_no_violation_acknowledgement]

# ── CLOUD IDS (INTRUSION DETECTION SYSTEM) ───────────────────────────────────
def cloud_ids_endpoint_no_threat_exceptions(r):
    if r.get('threat_exceptions'): return 'Cloud IDS endpoint has threat exceptions configured - IDS bypass risk'

GCP_CLOUD_IDS_RULES = [cloud_ids_endpoint_no_threat_exceptions]

# ── CERTIFICATE AUTHORITY SERVICE ────────────────────────────────────────────
def ca_pool_tier_dev(r):
    if r.get('tier', 'DEVOPS') == 'DEVOPS': return 'CA Pool uses DEVOPS tier - Enterprise required for production CA'
def ca_pool_no_labels(r):
    if not r.get('labels'): return 'CA Pool has no labels'
def ca_certificate_no_revocation(r):
    if r.get('revocation_details'): return 'CA Certificate has revocation details present - already revoked'

GCP_CA_RULES = [ca_pool_tier_dev, ca_pool_no_labels, ca_certificate_no_revocation]

# ── CLOUD TASKS ──────────────────────────────────────────────────────────────
def tasks_queue_no_rate_limits(r):
    rr = r.get('rate_limits', {}); rr = (rr[0] if isinstance(rr, list) and rr else rr) or {}
    if not rr.get('max_concurrent_dispatches'): return 'Cloud Tasks queue has no max concurrent dispatches configured'
def tasks_queue_no_retry_config(r):
    rc = r.get('retry_config', {}); rc = (rc[0] if isinstance(rc, list) and rc else rc) or {}
    if not rc.get('max_attempts'): return 'Cloud Tasks queue has no max attempts configured'
def tasks_queue_no_app_engine_routing(r):
    ae = r.get('app_engine_routing_override', {}); ae = (ae[0] if isinstance(ae, list) and ae else ae) or {}
    if not ae: return 'Cloud Tasks queue has no explicit App Engine routing override'

GCP_TASKS_RULES = [tasks_queue_no_rate_limits, tasks_queue_no_retry_config, tasks_queue_no_app_engine_routing]

# ── LOOKER ───────────────────────────────────────────────────────────────────
def looker_instance_public_ip(r):
    if r.get('public_ip_enabled', True): return 'Looker instance has public IP enabled - HIGH RISK'
def looker_instance_no_cmek(r):
    e = r.get('encryption_config', {}); e = (e[0] if isinstance(e, list) and e else e) or {}
    if not e.get('kms_key_name'): return 'Looker instance not encrypted with CMEK'
def looker_instance_no_custom_domain(r):
    if not r.get('custom_domain'): return 'Looker instance has no custom domain configured - uses default URL'

GCP_LOOKER_RULES = [looker_instance_public_ip, looker_instance_no_cmek, looker_instance_no_custom_domain]

# ── BARE METAL SOLUTION ──────────────────────────────────────────────────────
def bms_instance_os_outdated(r):
    os = r.get('os_image', '')
    if 'centos' in str(os).lower() or 'redhat' in str(os).lower(): return f'Bare Metal instance OS image {os} may be outdated - verify lifecycle'
def bms_instance_no_labels(r):
    if not r.get('labels'): return 'Bare Metal instance has no labels'

GCP_BMS_RULES = [bms_instance_os_outdated, bms_instance_no_labels]

# ── EVENTARC REFINED ─────────────────────────────────────────────────────────
def eventarc_pubsub_no_topic(r):
    t = r.get('transport', {}); t = (t[0] if isinstance(t, list) and t else t) or {}
    ps = t.get('pubsub', {}); ps = (ps[0] if isinstance(ps, list) and ps else ps) or {}
    if t and not ps.get('topic'): return 'Eventarc uses Pub/Sub transport but no specific topic is provided'

GCP_EVENTARC_REFINED_RULES = [eventarc_pubsub_no_topic]

# ── CLOUD RUN REFINED (V1) ───────────────────────────────────────────────────
def run_v1_revision_no_timeout(r):
    t = r.get('template', {}); t = (t[0] if isinstance(t, list) and t else t) or {}
    s = t.get('spec', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    if not s.get('timeout_seconds'): return 'Cloud Run service revision has no explicit timeout configured'

GCP_RUN_REFINED_RULES = [run_v1_revision_no_timeout]

# ── COMPUTE REGION DISK ──────────────────────────────────────────────────────
def disk_region_no_encryption(r):
    e = r.get('disk_encryption_key', {}); e = (e[0] if isinstance(e, list) and e else e) or {}
    if not e.get('kms_key_name'): return 'GCE Regional Disk not encrypted with CMEK'

GCP_DISK_REFINED_RULES = [disk_region_no_encryption]

# ── GKE HUB (ANTHOS / FLEET) ─────────────────────────────────────────────────
def gke_hub_membership_no_labels(r):
    if not r.get('labels'): return 'GKE Hub Membership (Fleet) has no labels'
def gke_hub_feature_no_spec(r):
    if not r.get('spec'): return 'GKE Hub Feature has no specific configuration spec applied'

GCP_GKE_HUB_RULES = [gke_hub_membership_no_labels, gke_hub_feature_no_spec]
