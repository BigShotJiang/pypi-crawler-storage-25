
# ============================================================================
# AWS EXTENDED SECURITY RULES - PART 2
# IAM, EBS, ELB, Lambda, CloudTrail, KMS, DynamoDB, Redshift
# ============================================================================

# ── IAM ROLE RULES ────────────────────────────────────────────────────────────
def check_iam_role_wildcard_principal(r):
    """IAM role allows any principal"""
    trust = str(r.get('assume_role_policy', '') or '')
    if '"Principal": "*"' in trust or '"AWS": "*"' in trust:
        return 'IAM role allows any principal (*) - CRITICAL RISK'
def check_iam_role_no_condition(r):
    """IAM role trust has no conditions"""
    trust = str(r.get('assume_role_policy', '') or '')
    if trust and 'Condition' not in trust and '"AWS"' in trust:
        return 'IAM role trust policy has no conditions - add MFA or IP restriction'
def check_iam_role_admin_access(r):
    """IAM role has AdministratorAccess"""
    if 'arn:aws:iam::aws:policy/AdministratorAccess' in (r.get('managed_policy_arns') or []):
        return 'IAM role has AdministratorAccess - CRITICAL RISK: use least privilege'
def check_iam_role_no_permission_boundary(r):
    """IAM role has no permission boundary"""
    if not r.get('permissions_boundary'):
        return 'IAM role has no permission boundary - privilege escalation risk'
def check_iam_role_cross_account_no_externalid(r):
    """IAM cross-account role missing ExternalId"""
    trust = str(r.get('assume_role_policy', '') or '')
    if '"AWS"' in trust and 'sts.amazonaws.com' not in trust and 'ExternalId' not in trust:
        return 'Cross-account IAM role has no ExternalId - confused deputy risk'
def check_iam_role_max_session_too_long(r):
    """IAM role max session duration too long"""
    dur = int(r.get('max_session_duration', 3600) or 3600)
    if dur > 43200:
        return f'IAM role max session duration {dur}s exceeds 12h - reduce'
def check_iam_role_no_tags(r):
    """IAM role has no tags"""
    if not r.get('tags'):
        return 'IAM role has no tags - governance issue'
def check_iam_role_service_wildcard(r):
    """IAM role trust allows any service"""
    if '"Service": "*"' in str(r.get('assume_role_policy', '') or ''):
        return 'IAM role trust allows any AWS service - restrict'
def check_iam_role_passrole_wildcard(r):
    """IAM role allows PassRole with wildcard"""
    policy = str(r.get('assume_role_policy', '') or '')
    if 'iam:PassRole' in policy and '"Resource": "*"' in policy:
        return 'IAM role allows iam:PassRole with * resource - privilege escalation risk'
def check_iam_role_no_description(r):
    """IAM role has no description"""
    if not r.get('description'):
        return 'IAM role has no description - documentation issue'
def check_iam_role_wildcard_actions(r):
    """IAM role inline policy uses wildcard actions"""
    for p in (r.get('inline_policy') or []):
        if isinstance(p, dict) and '"Action": "*"' in str(p.get('policy', '')):
            return 'IAM role inline policy uses wildcard actions (*)'
def check_iam_role_unused_policy_versions(r):
    """IAM role has unused managed policy versions"""
    if len(r.get('managed_policy_arns', []) or []) > 10:
        return 'IAM role has more than 10 managed policies - review and consolidate'
def check_iam_role_ec2_no_metadata_restriction(r):
    """IAM role for EC2 without metadata restriction"""
    trust = str(r.get('assume_role_policy', '') or '')
    if 'ec2.amazonaws.com' in trust and 'aws:ec2:MetadataHttpTokens' not in trust:
        return 'IAM EC2 role trust has no IMDSv2 condition'
def check_iam_role_lambda_no_log_restriction(r):
    """IAM Lambda role allows unrestricted log access"""
    trust = str(r.get('assume_role_policy', '') or '')
    if 'lambda.amazonaws.com' in trust:
        if 'logs:*' in str(r.get('inline_policy', '') or ''):
            return 'IAM Lambda role allows unrestricted CloudWatch Logs access'
def check_iam_role_no_path(r):
    """IAM role has no path for organization"""
    path = r.get('path', '/')
    if path == '/':
        return 'IAM role uses root path - use structured paths for organization'

IAM_ROLE_RULES = [
    check_iam_role_wildcard_principal, check_iam_role_no_condition, check_iam_role_admin_access,
    check_iam_role_no_permission_boundary, check_iam_role_cross_account_no_externalid,
    check_iam_role_max_session_too_long, check_iam_role_no_tags, check_iam_role_service_wildcard,
    check_iam_role_passrole_wildcard, check_iam_role_no_description, check_iam_role_wildcard_actions,
    check_iam_role_unused_policy_versions, check_iam_role_ec2_no_metadata_restriction,
    check_iam_role_lambda_no_log_restriction, check_iam_role_no_path,
]

# ── IAM USER RULES ────────────────────────────────────────────────────────────
def check_iam_user_no_mfa(r):
    """IAM user has no MFA"""
    if not r.get('mfa_enabled') and not r.get('mfa_device'):
        return 'IAM user has no MFA enabled - HIGH RISK'
def check_iam_user_no_group(r):
    """IAM user not in any group"""
    if not r.get('groups'):
        return 'IAM user not in any group - manage permissions via groups'
def check_iam_user_direct_policy(r):
    """IAM user has directly attached policies"""
    if r.get('policy') or r.get('user_policy_attachments'):
        return 'IAM user has directly attached policies - attach to groups instead'
def check_iam_user_no_tags(r):
    """IAM user has no tags"""
    if not r.get('tags'):
        return 'IAM user has no tags - accountability issue'
def check_iam_user_console_no_mfa(r):
    """IAM user console access without MFA"""
    if r.get('console_password') and not r.get('mfa_enabled'):
        return 'IAM user has console access without MFA - HIGH RISK'
def check_iam_user_access_key_active(r):
    """IAM user has active access keys that are old"""
    for k in (r.get('access_keys') or []):
        if isinstance(k, dict) and k.get('status') == 'Active' and not k.get('last_used_date'):
            return 'IAM user has active access key that has never been used'
def check_iam_user_multiple_access_keys(r):
    """IAM user has multiple active access keys"""
    active = [k for k in (r.get('access_keys') or []) if isinstance(k, dict) and k.get('status') == 'Active']
    if len(active) > 1:
        return f'IAM user has {len(active)} active access keys - keep only 1'
def check_iam_user_no_boundary(r):
    """IAM user has no permission boundary"""
    if not r.get('permissions_boundary'):
        return 'IAM user has no permission boundary'
def check_iam_user_admin_policy(r):
    """IAM user has AdministratorAccess"""
    if 'arn:aws:iam::aws:policy/AdministratorAccess' in (r.get('managed_policy_arns') or []):
        return 'IAM user has AdministratorAccess policy - CRITICAL RISK'
def check_iam_user_no_path(r):
    """IAM user has no custom path"""
    if r.get('path', '/') == '/':
        return 'IAM user uses root path - use structured paths'
def check_iam_user_wildcard_action(r):
    """IAM user policy allows wildcard actions"""
    if '"Action": "*"' in str(r.get('policy', '') or ''):
        return 'IAM user policy uses wildcard actions - CRITICAL RISK'
def check_iam_user_inline_policy(r):
    """IAM user has inline policies"""
    if r.get('inline_policy'):
        return 'IAM user has inline policies - prefer managed policies'
def check_iam_user_unused(r):
    """IAM user has never logged in"""
    if not r.get('last_login') and not r.get('password_last_used'):
        return 'IAM user has never logged in - consider deactivating'
def check_iam_user_force_destroy(r):
    """IAM user allows force destroy"""
    if r.get('force_destroy', False):
        return 'IAM user force_destroy=true - accidental deletion risk'
def check_iam_user_no_login_profile(r):
    """IAM user has no login profile restriction"""
    lp = r.get('login_profile', {}); lp = (lp[0] if isinstance(lp, list) else lp) or {}
    if lp and not lp.get('password_reset_required', False):
        return 'IAM user login profile does not require password reset on first login'

IAM_USER_RULES = [
    check_iam_user_no_mfa, check_iam_user_no_group, check_iam_user_direct_policy,
    check_iam_user_no_tags, check_iam_user_console_no_mfa, check_iam_user_access_key_active,
    check_iam_user_multiple_access_keys, check_iam_user_no_boundary, check_iam_user_admin_policy,
    check_iam_user_no_path, check_iam_user_wildcard_action, check_iam_user_inline_policy,
    check_iam_user_unused, check_iam_user_force_destroy, check_iam_user_no_login_profile,
]

# ── IAM POLICY EXTRA RULES ───────────────────────────────────────────────────
def check_iam_policy_notaction(r):
    """IAM policy uses NotAction"""
    if '"NotAction"' in str(r.get('policy', '') or ''):
        return 'IAM policy uses NotAction - may grant unintended permissions'
def check_iam_policy_notresource(r):
    """IAM policy uses NotResource"""
    if '"NotResource"' in str(r.get('policy', '') or ''):
        return 'IAM policy uses NotResource - may grant unintended permissions'
def check_iam_policy_no_condition(r):
    """IAM policy allows actions without conditions"""
    policy = str(r.get('policy', '') or '')
    if '"Effect": "Allow"' in policy and '"Resource": "*"' in policy and 'Condition' not in policy:
        return 'IAM policy allows resource=* with no conditions'
def check_iam_policy_too_many_statements(r):
    """IAM policy has too many statements"""
    import json
    try:
        pol = json.loads(r.get('policy', '{}') or '{}')
        stmts = pol.get('Statement', [])
        if len(stmts) > 20:
            return f'IAM policy has {len(stmts)} statements - consider splitting'
    except: pass
def check_iam_policy_no_tags(r):
    """IAM policy has no tags"""
    if not r.get('tags'):
        return 'IAM managed policy has no tags'
def check_iam_policy_star_resource_sensitive(r):
    """IAM policy allows sensitive actions on * resource"""
    policy = str(r.get('policy', '') or '')
    sensitive = ['secretsmanager:', 'kms:Decrypt', 'iam:Create', 's3:DeleteObject']
    for s in sensitive:
        if s in policy and '"Resource": "*"' in policy:
            return f'IAM policy allows {s} on wildcard resource - HIGH RISK'
def check_iam_policy_allows_all_services(r):
    """IAM policy allows all AWS service actions"""
    if '"Action": "*"' in str(r.get('policy', '') or ''):
        return 'IAM policy allows all service actions (*) - CRITICAL RISK'
def check_iam_policy_inline_only(r):
    """IAM policy is inline (not managed)"""
    if r.get('name_prefix', '').startswith('inline-'):
        return 'IAM policy appears to be inline - prefer customer-managed policies'
def check_iam_policy_no_description(r):
    """IAM policy has no description"""
    if not r.get('description'):
        return 'IAM managed policy has no description'
def check_iam_policy_sts_wildcards(r):
    """IAM policy allows sts:* without restriction"""
    if 'sts:*' in str(r.get('policy', '') or ''):
        return 'IAM policy allows sts:* - restrict to specific STS actions'

IAM_POLICY_EXTRA_RULES = [
    check_iam_policy_notaction, check_iam_policy_notresource, check_iam_policy_no_condition,
    check_iam_policy_too_many_statements, check_iam_policy_no_tags,
    check_iam_policy_star_resource_sensitive, check_iam_policy_allows_all_services,
    check_iam_policy_inline_only, check_iam_policy_no_description, check_iam_policy_sts_wildcards,
]

# ── IAM PASSWORD POLICY RULES ────────────────────────────────────────────────
def check_pw_min_length(r):
    """Password policy min length too short"""
    if int(r.get('minimum_password_length', 0) or 0) < 14:
        return 'IAM password policy minimum length < 14 characters'
def check_pw_no_uppercase(r):
    """Password policy missing uppercase"""
    if not r.get('require_uppercase_characters', False):
        return 'IAM password policy does not require uppercase characters'
def check_pw_no_lowercase(r):
    """Password policy missing lowercase"""
    if not r.get('require_lowercase_characters', False):
        return 'IAM password policy does not require lowercase characters'
def check_pw_no_numbers(r):
    """Password policy missing numbers"""
    if not r.get('require_numbers', False):
        return 'IAM password policy does not require numbers'
def check_pw_no_symbols(r):
    """Password policy missing symbols"""
    if not r.get('require_symbols', False):
        return 'IAM password policy does not require symbols'
def check_pw_no_expiry(r):
    """Password policy missing expiration"""
    if not int(r.get('max_password_age', 0) or 0) > 0:
        return 'IAM password policy has no expiration period'
def check_pw_short_expiry(r):
    """Password policy expiry too long"""
    age = int(r.get('max_password_age', 0) or 0)
    if 0 < age > 90:
        return f'IAM password policy max age {age} days exceeds 90 - reduce'
def check_pw_no_reuse_prevention(r):
    """Password policy no reuse prevention"""
    if int(r.get('password_reuse_prevention', 0) or 0) < 24:
        return 'IAM password reuse prevention < 24 passwords'
def check_pw_allow_user_change(r):
    """Password policy allows users to change own password"""
    if not r.get('allow_users_to_change_password', True):
        return 'IAM password policy does not allow users to change their password'
def check_pw_hard_expiry(r):
    """Password policy missing hard expiry"""
    if not r.get('hard_expiry', False):
        return 'IAM password policy does not enforce hard expiry on console lockout'

IAM_PASSWORD_POLICY_RULES = [
    check_pw_min_length, check_pw_no_uppercase, check_pw_no_lowercase,
    check_pw_no_numbers, check_pw_no_symbols, check_pw_no_expiry,
    check_pw_short_expiry, check_pw_no_reuse_prevention, check_pw_allow_user_change, check_pw_hard_expiry,
]

# ── EBS EXTRA RULES ───────────────────────────────────────────────────────────
def check_ebs_no_tags(r):
    """EBS volume has no tags"""
    if not r.get('tags'):
        return 'EBS volume has no tags - governance issue'
def check_ebs_no_kms_key(r):
    """EBS encrypted but no custom KMS key"""
    if r.get('encrypted', False) and not r.get('kms_key_id'):
        return 'EBS volume uses default KMS key - use customer-managed key'
def check_ebs_gp2_not_gp3(r):
    """EBS using gp2 instead of gp3"""
    if r.get('type', '') == 'gp2':
        return 'EBS volume is gp2 - migrate to gp3 for 20% cost reduction'
def check_ebs_no_snapshot(r):
    """EBS volume has no snapshot policy"""
    if not r.get('snapshot_id') and not r.get('snapshot_policy'):
        return 'EBS volume has no associated snapshot policy'
def check_ebs_unencrypted(r):
    """EBS volume is not encrypted"""
    if not r.get('encrypted', False):
        return 'EBS volume not encrypted - HIGH RISK'
def check_ebs_size_too_large(r):
    """EBS volume is unexpectedly large"""
    size = int(r.get('size', 0) or 0)
    if size > 16384:
        return f'EBS volume size {size}GB is very large - review allocation'
def check_ebs_no_delete_on_termination(r):
    """EBS not set to delete on termination"""
    if r.get('type') and not r.get('_delete_on_termination', True):
        return 'EBS volume not set to delete on instance termination - orphan risk'
def check_ebs_io1_no_iops(r):
    """EBS io1/io2 missing IOPS configuration"""
    if r.get('type', '') in ['io1', 'io2'] and not r.get('iops'):
        return 'EBS io1/io2 volume has no explicit IOPS configured'
def check_ebs_multi_attach_not_validated(r):
    """EBS multi-attach enabled without cluster use case"""
    if r.get('multi_attach_enabled', False):
        return 'EBS multi-attach enabled - ensure cluster-aware file system in use'
def check_ebs_throughput_not_set_gp3(r):
    """EBS gp3 throughput not configured"""
    if r.get('type', '') == 'gp3' and not r.get('throughput'):
        return 'EBS gp3 volume has no explicit throughput configured'
def check_ebs_availability_zone_mismatch(r):
    """EBS AZ may not match EC2 instance"""
    if r.get('availability_zone') and not r.get('_az_validated'):
        return 'EBS volume AZ not validated against attached instance AZ'
def check_ebs_no_auto_snapshot(r):
    """EBS no automated snapshots"""
    if not r.get('snapshot_id') and not r.get('create_snapshot'):
        return 'EBS volume has no automated snapshot configured'

EBS_EXTRA_RULES = [
    check_ebs_no_tags, check_ebs_no_kms_key, check_ebs_gp2_not_gp3, check_ebs_no_snapshot,
    check_ebs_unencrypted, check_ebs_size_too_large, check_ebs_no_delete_on_termination,
    check_ebs_io1_no_iops, check_ebs_multi_attach_not_validated, check_ebs_throughput_not_set_gp3,
    check_ebs_availability_zone_mismatch, check_ebs_no_auto_snapshot,
]

# ── ELB EXTRA RULES ───────────────────────────────────────────────────────────
def check_elb_no_tags(r):
    """ELB has no tags"""
    if not r.get('tags'):
        return 'Load balancer has no tags'
def check_elb_no_waf(r):
    """ALB has no WAF attached"""
    if not r.get('web_acl_arn') and not r.get('waf_acl_id'):
        return 'Application Load Balancer has no WAF associated - HIGH RISK'
def check_elb_no_access_logs(r):
    """ELB access logs disabled"""
    logs = r.get('access_logs', {}); logs = (logs[0] if isinstance(logs, list) else logs) or {}
    if not logs or not logs.get('enabled', False):
        return 'Load balancer access logs not enabled'
def check_elb_http_listener(r):
    """ELB has HTTP listener"""
    for listener in (r.get('listener') or []):
        if listener and listener.get('protocol') == 'HTTP':
            return 'Load balancer has HTTP listener - use HTTPS'
def check_elb_ssl_policy_weak(r):
    """ELB using weak SSL policy"""
    for listener in (r.get('listener') or []):
        if listener and listener.get('ssl_policy', '') in ['ELBSecurityPolicy-2015-05', 'ELBSecurityPolicy-TLS-1-0-2015-04']:
            return f'Load balancer uses outdated SSL policy {listener.get("ssl_policy")}'
def check_elb_no_deletion_protection(r):
    """ELB deletion protection disabled"""
    if not r.get('enable_deletion_protection', False):
        return 'Load balancer has no deletion protection'
def check_elb_cross_zone_disabled(r):
    """ELB cross-zone load balancing disabled"""
    if not r.get('enable_cross_zone_load_balancing', True):
        return 'Load balancer cross-zone balancing disabled - uneven traffic distribution'
def check_elb_no_health_check(r):
    """ELB missing health check configuration"""
    if not r.get('health_check'):
        return 'Load balancer has no health check configured'
def check_elb_idle_timeout_too_short(r):
    """ELB idle timeout too short"""
    timeout = int(r.get('idle_timeout', 60) or 60)
    if timeout < 30:
        return f'Load balancer idle timeout {timeout}s may be too short for long-running requests'
def check_elb_desync_mitigation_missing(r):
    """ELB desync mitigation not set to strictest mode"""
    if r.get('desync_mitigation_mode', 'defensive') == 'monitor':
        return 'Load balancer desync mitigation in monitor mode - set to strictest'
def check_elb_http2_disabled(r):
    """ALB HTTP/2 support disabled"""
    if r.get('internal', False) is False and not r.get('enable_http2', True):
        return 'Application Load Balancer HTTP/2 disabled'
def check_elb_preserve_host_header(r):
    """ALB not preserving host header"""
    if not r.get('preserve_host_header', False):
        return 'ALB not configured to preserve host header - may affect routing'
def check_elb_no_subnet_mapping(r):
    """ELB missing explicit subnet mapping"""
    if not r.get('subnets') and not r.get('subnet_mapping'):
        return 'Load balancer has no subnet mapping defined'
def check_elb_s3_logs_retention(r):
    """ELB log bucket has insufficient retention"""
    if not r.get('access_logs_retention_days'):
        return 'Load balancer access log retention period not configured'
def check_elb_security_group_missing(r):
    """ALB has no security groups"""
    if not r.get('security_groups') and r.get('load_balancer_type', 'application') == 'application':
        return 'Application Load Balancer has no security groups'

ELB_EXTRA_RULES = [
    check_elb_no_tags, check_elb_no_waf, check_elb_no_access_logs, check_elb_http_listener,
    check_elb_ssl_policy_weak, check_elb_no_deletion_protection, check_elb_cross_zone_disabled,
    check_elb_no_health_check, check_elb_idle_timeout_too_short, check_elb_desync_mitigation_missing,
    check_elb_http2_disabled, check_elb_preserve_host_header, check_elb_no_subnet_mapping,
    check_elb_s3_logs_retention, check_elb_security_group_missing,
]

# ── LAMBDA EXTRA RULES ───────────────────────────────────────────────────────
def check_lambda_no_vpc(r):
    """Lambda not in VPC"""
    if not r.get('vpc_config'):
        return 'Lambda is not in a VPC - network isolation missing'
def check_lambda_no_tracing(r):
    """Lambda X-Ray tracing disabled"""
    tc = r.get('tracing_config', {}); tc = (tc[0] if isinstance(tc, list) else tc) or {}
    if tc.get('mode', '') != 'Active':
        return 'Lambda X-Ray tracing not Active'
def check_lambda_no_concurrency(r):
    """Lambda no reserved concurrency"""
    if r.get('reserved_concurrent_executions') is None:
        return 'Lambda no reserved concurrency - throttling risk'
def check_lambda_no_dlq(r):
    """Lambda no dead letter queue"""
    dlq = r.get('dead_letter_config'); dlq = (dlq[0] if isinstance(dlq, list) else dlq)
    if not dlq:
        return 'Lambda has no dead letter queue configured'
def check_lambda_timeout_too_long(r):
    """Lambda timeout too long"""
    if int(r.get('timeout', 3) or 3) >= 900:
        return 'Lambda timeout set to max (900s) - review design'
def check_lambda_timeout_too_short(r):
    """Lambda default timeout may be too short"""
    if int(r.get('timeout', 3) or 3) == 3:
        return 'Lambda uses default 3s timeout - verify sufficient for workload'
def check_lambda_no_env_encryption(r):
    """Lambda env vars not encrypted with KMS"""
    env = r.get('environment', {}); env = (env[0] if isinstance(env, list) else env) or {}
    if env.get('variables') and not r.get('kms_key_arn'):
        return 'Lambda env variables not encrypted with KMS key'
def check_lambda_no_tags(r):
    """Lambda has no tags"""
    if not r.get('tags'):
        return 'Lambda function has no tags'
def check_lambda_runtime_deprecated(r):
    """Lambda using deprecated runtime"""
    deprecated = ['nodejs10.x', 'nodejs8.10', 'python2.7', 'ruby2.5', 'java8.al2', 'dotnetcore2.1']
    if r.get('runtime', '') in deprecated:
        return f'Lambda uses deprecated runtime {r.get("runtime")} - upgrade'
def check_lambda_code_size(r):
    """Lambda code size concern"""
    if int(r.get('source_code_size', 0) or 0) > 50 * 1024 * 1024:
        return 'Lambda deployment package > 50MB - consider container image'
def check_lambda_no_role(r):
    """Lambda has no execution role"""
    if not r.get('role'):
        return 'Lambda has no execution role - CRITICAL'
def check_lambda_too_much_memory(r):
    """Lambda memory allocation too high"""
    if int(r.get('memory_size', 128) or 128) > 3008:
        return 'Lambda memory > 3008MB - review allocation'
def check_lambda_no_log_retention(r):
    """Lambda CloudWatch log group has no retention"""
    if not r.get('log_retention_in_days') and not r.get('cloudwatch_logs_retention'):
        return 'Lambda CloudWatch log group has no retention policy - costs accumulate'
def check_lambda_public_url(r):
    """Lambda function URL publicly accessible"""
    url = r.get('url_config', {}); url = (url[0] if isinstance(url, list) else url) or {}
    if url.get('authorization_type') == 'NONE':
        return 'Lambda function URL has no authorization - PUBLIC access - CRITICAL'
def check_lambda_no_code_signing(r):
    """Lambda code signing not configured"""
    if not r.get('code_signing_config_arn'):
        return 'Lambda code signing not configured - unverified code risk'
def check_lambda_layers_too_many(r):
    """Lambda has too many layers"""
    if len(r.get('layers', []) or []) > 5:
        return 'Lambda has more than 5 layers - manage dependencies'
def check_lambda_no_provisioned_concurrency(r):
    """Lambda no provisioned concurrency for latency-sensitive functions"""
    if not r.get('provisioned_concurrency_config'):
        return 'Lambda no provisioned concurrency - cold start risk for latency-sensitive workloads'
def check_lambda_ephemeral_storage_default(r):
    """Lambda ephemeral storage at default value"""
    eph = r.get('ephemeral_storage', {}); eph = (eph[0] if isinstance(eph, list) else eph) or {}
    if eph.get('size', 512) == 512 and r.get('_needs_large_tmp'):
        return 'Lambda ephemeral storage at default 512MB - increase if large /tmp required'
def check_lambda_no_event_invoke_config(r):
    """Lambda event invoke config missing retry settings"""
    if not r.get('event_invoke_config') and not r.get('maximum_retry_attempts'):
        return 'Lambda event invoke config not set - default retry behavior may cause duplicate processing'
def check_lambda_architecture_not_arm(r):
    """Lambda not using arm64 for cost savings"""
    if r.get('architectures', ['x86_64']) == ['x86_64']:
        return 'Lambda uses x86_64 - consider arm64 (Graviton) for 20% cost reduction'

LAMBDA_EXTRA_RULES = [
    check_lambda_no_vpc, check_lambda_no_tracing, check_lambda_no_concurrency, check_lambda_no_dlq,
    check_lambda_timeout_too_long, check_lambda_timeout_too_short, check_lambda_no_env_encryption,
    check_lambda_no_tags, check_lambda_runtime_deprecated, check_lambda_code_size,
    check_lambda_no_role, check_lambda_too_much_memory, check_lambda_no_log_retention,
    check_lambda_public_url, check_lambda_no_code_signing, check_lambda_layers_too_many,
    check_lambda_no_provisioned_concurrency, check_lambda_ephemeral_storage_default,
    check_lambda_no_event_invoke_config, check_lambda_architecture_not_arm,
]

# ── CLOUDTRAIL RULES ─────────────────────────────────────────────────────────
def check_ct_disabled(r):
    """CloudTrail not enabled"""
    if not r.get('enable_logging', True):
        return 'CloudTrail logging is disabled - CRITICAL RISK'
def check_ct_no_kms(r):
    """CloudTrail not encrypted with KMS"""
    if not r.get('kms_key_id'):
        return 'CloudTrail logs not encrypted with KMS'
def check_ct_no_log_validation(r):
    """CloudTrail log file validation disabled"""
    if not r.get('enable_log_file_validation', False):
        return 'CloudTrail log file validation disabled - tampering undetectable'
def check_ct_no_global_events(r):
    """CloudTrail not logging global service events"""
    if not r.get('include_global_service_events', True):
        return 'CloudTrail not logging global service events (e.g., IAM)'
def check_ct_not_multi_region(r):
    """CloudTrail not multi-region"""
    if not r.get('is_multi_region_trail', False):
        return 'CloudTrail not configured as multi-region trail'
def check_ct_no_s3_log_prefix(r):
    """CloudTrail missing S3 log prefix"""
    if not r.get('s3_key_prefix'):
        return 'CloudTrail has no S3 key prefix - logs mixed at bucket root'
def check_ct_sns_missing(r):
    """CloudTrail missing SNS notification"""
    if not r.get('sns_topic_name') and not r.get('sns_topic_arn'):
        return 'CloudTrail has no SNS notification - no real-time alerting'
def check_ct_management_events_off(r):
    """CloudTrail management events not captured"""
    for selector in (r.get('event_selector') or []):
        if selector and selector.get('include_management_events') is False:
            return 'CloudTrail event selector excludes management events'
def check_ct_data_events_missing(r):
    """CloudTrail data events not captured"""
    selectors = r.get('event_selector') or []
    has_data = any((s or {}).get('data_resource') for s in selectors)
    if not has_data:
        return 'CloudTrail has no data event selectors - S3/Lambda activity not tracked'
def check_ct_no_organizational(r):
    """CloudTrail not organization-wide"""
    if not r.get('is_organization_trail', False):
        return 'CloudTrail is not an organization trail - gaps in multi-account logging'
def check_ct_no_tags(r):
    """CloudTrail has no tags"""
    if not r.get('tags'):
        return 'CloudTrail has no tags'
def check_ct_s3_object_level_read(r):
    """CloudTrail missing S3 object-level read events"""
    selectors = r.get('event_selector') or []
    for s in selectors:
        for dr in ((s or {}).get('data_resource') or []):
            if (dr or {}).get('type') == 'AWS::S3::Object' and 'ReadOnly' not in str(dr):
                return 'CloudTrail does not capture S3 object-level read events'
def check_ct_insight_selectors(r):
    """CloudTrail Insights disabled"""
    if not r.get('insight_selector'):
        return 'CloudTrail Insights not configured - unusual API activity undetected'
def check_ct_bucket_access_logging(r):
    """CloudTrail S3 bucket missing access logging"""
    if not r.get('s3_bucket_access_logging'):
        return 'CloudTrail S3 bucket does not have access logging'
def check_ct_bucket_public(r):
    """CloudTrail S3 bucket is public"""
    if r.get('s3_bucket_public', False):
        return 'CloudTrail S3 destination bucket is PUBLIC - CRITICAL RISK'

CLOUDTRAIL_RULES = [
    check_ct_disabled, check_ct_no_kms, check_ct_no_log_validation, check_ct_no_global_events,
    check_ct_not_multi_region, check_ct_no_s3_log_prefix, check_ct_sns_missing,
    check_ct_management_events_off, check_ct_data_events_missing, check_ct_no_organizational,
    check_ct_no_tags, check_ct_s3_object_level_read, check_ct_insight_selectors,
    check_ct_bucket_access_logging, check_ct_bucket_public,
]

# ── KMS RULES ────────────────────────────────────────────────────────────────
def check_kms_key_rotation_disabled(r):
    """KMS key rotation disabled"""
    if not r.get('enable_key_rotation', False):
        return 'KMS key rotation not enabled - HIGH RISK'
def check_kms_key_pending_deletion(r):
    """KMS key pending deletion"""
    if r.get('key_state', '') == 'PendingDeletion':
        return 'KMS key is pending deletion - verify intentional'
def check_kms_no_tags(r):
    """KMS key has no tags"""
    if not r.get('tags'):
        return 'KMS key has no tags - governance issue'
def check_kms_no_description(r):
    """KMS key has no description"""
    if not r.get('description'):
        return 'KMS key has no description'
def check_kms_wildcard_policy(r):
    """KMS key policy allows all principals"""
    if '"Principal": {"AWS": "*"}' in str(r.get('policy', '') or ''):
        return 'KMS key policy allows all AWS principals - CRITICAL RISK'
def check_kms_deletion_window_short(r):
    """KMS key deletion window too short"""
    window = int(r.get('deletion_window_in_days', 30) or 30)
    if window < 7:
        return f'KMS key deletion window is {window} days - set to at least 7'
def check_kms_policy_cross_account(r):
    """KMS key policy allows cross-account access"""
    policy = str(r.get('policy', '') or '')
    if 'arn:aws:iam::' in policy and policy.count('arn:aws:iam::') > 1:
        return 'KMS key policy may grant cross-account access - review'
def check_kms_symmetric_not_used_for_sensitive(r):
    """KMS key using asymmetric for general encryption"""
    if r.get('key_spec', 'SYMMETRIC_DEFAULT') != 'SYMMETRIC_DEFAULT' and not r.get('_is_signing_key'):
        return 'KMS asymmetric key used - verify if symmetric would be more appropriate'
def check_kms_alias_missing(r):
    """KMS key has no alias"""
    if not r.get('alias_name') and not r.get('_has_alias'):
        return 'KMS key has no alias - hard to identify purpose'
def check_kms_multi_region_not_enabled(r):
    """KMS key not multi-region"""
    if not r.get('multi_region', False):
        return 'KMS key is not multi-region - cross-region decryption requires replica setup'
def check_kms_external_key_material(r):
    """KMS key using external material without validation"""
    if r.get('key_material_origin') == 'EXTERNAL' and not r.get('_material_validated'):
        return 'KMS key uses external key material - validate import and rotation process'
def check_kms_no_key_policy_conditions(r):
    """KMS key policy has no conditions"""
    policy = str(r.get('policy', '') or '')
    if 'Allow' in policy and '"Resource": "*"' in policy and 'Condition' not in policy:
        return 'KMS key policy allows actions without conditions'
def check_kms_bypass_policy_lockout_safety(r):
    """KMS key bypass policy lockout disabled"""
    if r.get('bypass_policy_lockout_safety_check', False):
        return 'KMS key bypass_policy_lockout_safety_check=true - dangerous'
def check_kms_no_grant_validation(r):
    """KMS key has grants that may be overly permissive"""
    if r.get('has_grants') and not r.get('_grants_reviewed'):
        return 'KMS key has grants - review grant permissions periodically'
def check_kms_symmetric_for_signing(r):
    """KMS symmetric key used for signing (wrong type)"""
    usage = r.get('key_usage', 'ENCRYPT_DECRYPT')
    spec = r.get('key_spec', 'SYMMETRIC_DEFAULT')
    if usage == 'SIGN_VERIFY' and spec == 'SYMMETRIC_DEFAULT':
        return 'KMS key key_usage=SIGN_VERIFY requires asymmetric key spec'

KMS_RULES = [
    check_kms_key_rotation_disabled, check_kms_key_pending_deletion, check_kms_no_tags,
    check_kms_no_description, check_kms_wildcard_policy, check_kms_deletion_window_short,
    check_kms_policy_cross_account, check_kms_symmetric_not_used_for_sensitive, check_kms_alias_missing,
    check_kms_multi_region_not_enabled, check_kms_external_key_material, check_kms_no_key_policy_conditions,
    check_kms_bypass_policy_lockout_safety, check_kms_no_grant_validation, check_kms_symmetric_for_signing,
]

# ── DynamoDB RULES ────────────────────────────────────────────────────────────
def check_dynamo_no_encryption(r):
    """DynamoDB table not encrypted with KMS"""
    sse = r.get('server_side_encryption', {}); sse = (sse[0] if isinstance(sse, list) else sse) or {}
    if not sse.get('enabled', False):
        return 'DynamoDB table server-side encryption not enabled'
def check_dynamo_no_kms(r):
    """DynamoDB using default AWS-owned key"""
    sse = r.get('server_side_encryption', {}); sse = (sse[0] if isinstance(sse, list) else sse) or {}
    if sse.get('enabled') and not sse.get('kms_key_arn'):
        return 'DynamoDB uses AWS-owned KMS key - use customer-managed key'
def check_dynamo_no_pitr(r):
    """DynamoDB PITR not enabled"""
    pitr = r.get('point_in_time_recovery', {}); pitr = (pitr[0] if isinstance(pitr, list) else pitr) or {}
    if not pitr.get('enabled', False):
        return 'DynamoDB Point-In-Time Recovery not enabled'
def check_dynamo_billing_mode(r):
    """DynamoDB billing mode not optimized"""
    if r.get('billing_mode', 'PROVISIONED') == 'PROVISIONED' and not r.get('_is_high_traffic'):
        return 'DynamoDB uses PROVISIONED billing - consider PAY_PER_REQUEST for variable workloads'
def check_dynamo_no_deletion_protection(r):
    """DynamoDB deletion protection disabled"""
    if not r.get('deletion_protection_enabled', False):
        return 'DynamoDB deletion protection not enabled'
def check_dynamo_no_tags(r):
    """DynamoDB has no tags"""
    if not r.get('tags'):
        return 'DynamoDB table has no tags'
def check_dynamo_no_stream(r):
    """DynamoDB streams not configured"""
    if not r.get('stream_enabled', False):
        return 'DynamoDB streams not enabled - change data capture unavailable'
def check_dynamo_public_access(r):
    """DynamoDB resource policy allows public access"""
    if '"Principal": "*"' in str(r.get('resource_policy', '') or ''):
        return 'DynamoDB table resource policy allows public access - CRITICAL RISK'
def check_dynamo_no_backup(r):
    """DynamoDB no backup configured"""
    if not r.get('point_in_time_recovery') and not r.get('backup_plan'):
        return 'DynamoDB table has no backup plan'
def check_dynamo_deprecated_hash_key_type(r):
    """DynamoDB attribute type check"""
    for attr in (r.get('attribute') or []):
        if isinstance(attr, dict) and attr.get('type') == 'N' and attr.get('name', '').lower() == 'id':
            return 'DynamoDB numeric primary key "id" - consider string UUID for better distribution'
def check_dynamo_no_ttl(r):
    """DynamoDB TTL not configured"""
    ttl = r.get('ttl', {}); ttl = (ttl[0] if isinstance(ttl, list) else ttl) or {}
    if not ttl.get('enabled', False):
        return 'DynamoDB TTL not configured - stale data may accumulate'
def check_dynamo_no_global_table(r):
    """DynamoDB not configured as a global table"""
    if not r.get('replica') and not r.get('global_table_version'):
        return 'DynamoDB is not a global table - no multi-region HA'
def check_dynamo_table_class_not_optimized(r):
    """DynamoDB table class not optimized"""
    if r.get('table_class', 'STANDARD') == 'STANDARD' and r.get('_is_infrequent_access'):
        return 'DynamoDB table class is STANDARD - consider STANDARD_INFREQUENT_ACCESS'
def check_dynamo_no_contributor_insights(r):
    """DynamoDB contributor insights disabled"""
    if not r.get('contributor_insights_enabled', False):
        return 'DynamoDB contributor insights disabled - no hot key detection'
def check_dynamo_throughput_not_sufficient(r):
    """DynamoDB provisioned throughput too low"""
    if r.get('billing_mode') == 'PROVISIONED':
        ru = int((r.get('read_capacity') or 0)); wu = int((r.get('write_capacity') or 0))
        if ru == 0 or wu == 0:
            return 'DynamoDB provisioned capacity set to 0 - table will throttle all requests'

DYNAMODB_RULES = [
    check_dynamo_no_encryption, check_dynamo_no_kms, check_dynamo_no_pitr, check_dynamo_billing_mode,
    check_dynamo_no_deletion_protection, check_dynamo_no_tags, check_dynamo_no_stream,
    check_dynamo_public_access, check_dynamo_no_backup, check_dynamo_deprecated_hash_key_type,
    check_dynamo_no_ttl, check_dynamo_no_global_table, check_dynamo_table_class_not_optimized,
    check_dynamo_no_contributor_insights, check_dynamo_throughput_not_sufficient,
]

# ── REDSHIFT RULES ────────────────────────────────────────────────────────────
def check_rs_not_encrypted(r):
    """Redshift cluster not encrypted"""
    if not r.get('encrypted', False):
        return 'Redshift cluster not encrypted - HIGH RISK'
def check_rs_public_access(r):
    """Redshift cluster publicly accessible"""
    if r.get('publicly_accessible', False):
        return 'Redshift cluster is publicly accessible - CRITICAL RISK'
def check_rs_no_vpc(r):
    """Redshift not in VPC"""
    if not r.get('cluster_subnet_group_name'):
        return 'Redshift cluster has no subnet group - may not be in VPC'
def check_rs_no_logging(r):
    """Redshift audit logging disabled"""
    ll = r.get('logging', {}); ll = (ll[0] if isinstance(ll, list) else ll) or {}
    if not ll.get('enable', False):
        return 'Redshift audit logging disabled'
def check_rs_no_kms(r):
    """Redshift not using customer KMS key"""
    if r.get('encrypted') and not r.get('kms_key_id'):
        return 'Redshift uses default KMS key - use customer-managed key'
def check_rs_no_skip_final_snapshot(r):
    """Redshift allows deletion without final snapshot"""
    if r.get('skip_final_snapshot', False):
        return 'Redshift allows deletion without final snapshot - data loss risk'
def check_rs_no_version_upgrade(r):
    """Redshift automated upgrades disabled"""
    if not r.get('allow_version_upgrade', True):
        return 'Redshift automated version upgrades disabled'
def check_rs_default_port(r):
    """Redshift uses default port"""
    if int(r.get('port', 5439) or 5439) == 5439:
        return 'Redshift uses default port 5439 - consider non-default'
def check_rs_no_enhanced_vpc(r):
    """Redshift enhanced VPC routing disabled"""
    if not r.get('enhanced_vpc_routing', False):
        return 'Redshift enhanced VPC routing disabled - traffic may go outside VPC'
def check_rs_single_az(r):
    """Redshift in single AZ"""
    if not r.get('availability_zone_relocation_enabled', False):
        return 'Redshift AZ relocation not enabled - AZ failure risk'
def check_rs_no_maintenance_window(r):
    """Redshift no maintenance window"""
    if not r.get('preferred_maintenance_window'):
        return 'Redshift has no preferred maintenance window'
def check_rs_default_master_username(r):
    """Redshift uses default master username"""
    if r.get('master_username', '') in ['admin', 'root', 'awsuser', 'redshift']:
        return 'Redshift uses common master username - use unique admin username'
def check_rs_no_automated_snapshot(r):
    """Redshift automated snapshot retention too low"""
    ret = int(r.get('automated_snapshot_retention_period', 1) or 1)
    if ret < 7:
        return f'Redshift automated snapshot retention is {ret} days - recommend >= 7'
def check_rs_no_tags(r):
    """Redshift has no tags"""
    if not r.get('tags'):
        return 'Redshift cluster has no tags'
def check_rs_no_param_group(r):
    """Redshift using default parameter group"""
    if not r.get('cluster_parameter_group_name') or r.get('cluster_parameter_group_name', '').startswith('default.'):
        return 'Redshift using default parameter group - harden SSL and audit settings'

REDSHIFT_RULES = [
    check_rs_not_encrypted, check_rs_public_access, check_rs_no_vpc, check_rs_no_logging,
    check_rs_no_kms, check_rs_no_skip_final_snapshot, check_rs_no_version_upgrade, check_rs_default_port,
    check_rs_no_enhanced_vpc, check_rs_single_az, check_rs_no_maintenance_window,
    check_rs_default_master_username, check_rs_no_automated_snapshot, check_rs_no_tags, check_rs_no_param_group,
]
