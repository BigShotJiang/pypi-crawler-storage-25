
# ============================================================================
# AWS EXTENDED SECURITY RULES - PART 1
# S3, EC2, RDS, Security Groups
# ============================================================================

def _ingress_open(r, port):
    for rule in (r.get('ingress') or []):
        if not rule: continue
        cidrs = rule.get('cidr_blocks', []) or []
        fp = int(rule.get('from_port', 0) or 0)
        tp = int(rule.get('to_port', 0) or 0)
        if ('0.0.0.0/0' in cidrs or '::/0' in (rule.get('ipv6_cidr_blocks') or [])) and fp <= port <= tp:
            return True
    return False

# ── S3 EXTRA RULES ──────────────────────────────────────────────────────────
def check_s3_lifecycle(r):
    """S3 bucket missing lifecycle rules"""
    if not r.get('lifecycle_rule') and not r.get('lifecycle_configuration'):
        return 'S3 bucket has no lifecycle rules - objects never expire, cost risk'
def check_s3_replication(r):
    """S3 bucket missing cross-region replication"""
    if not r.get('replication_configuration'):
        return 'S3 bucket has no cross-region replication - no DR protection'
def check_s3_object_lock(r):
    """S3 bucket missing WORM protection"""
    if not r.get('object_lock_configuration'):
        return 'S3 bucket has no Object Lock enabled - no WORM protection'
def check_s3_mfa_delete(r):
    """S3 bucket missing MFA delete"""
    v = r.get('versioning', {}); v = (v[0] if isinstance(v, list) else v) or {}
    if not v.get('mfa_delete', False):
        return 'S3 MFA Delete not enabled - HIGH RISK'
def check_s3_kms_not_used(r):
    """S3 bucket using AES256 instead of KMS"""
    try:
        sse = r.get('server_side_encryption_configuration') or []
        sse = (sse[0] if isinstance(sse, list) and sse else sse) or {}
        if not isinstance(sse, dict): return
        rule = sse.get('rule') or {}
        rule = (rule[0] if isinstance(rule, list) and rule else rule) or {}
        if not isinstance(rule, dict): return
        aae = rule.get('apply_server_side_encryption_by_default') or {}
        aae = (aae[0] if isinstance(aae, list) and aae else aae) or {}
        if isinstance(aae, dict) and aae.get('sse_algorithm') == 'AES256':
            return 'S3 bucket uses AES256, not KMS - prefer aws:kms for key rotation'
    except Exception:
        return
def check_s3_cors_wildcard(r):
    """S3 CORS allows all origins"""
    for rule in (r.get('cors_rule') or []):
        if rule and '*' in (rule.get('allowed_origins') or []):
            return 'S3 CORS allows all origins (*) - data exposure risk'
def check_s3_website_enabled(r):
    """S3 bucket has public website hosting"""
    if r.get('website') or r.get('website_endpoint'):
        return 'S3 static website hosting enabled - ensure intentional'
def check_s3_no_tags(r):
    """S3 bucket has no tags"""
    if not r.get('tags'):
        return 'S3 bucket has no tags - cost governance issue'
def check_s3_bucket_key_disabled(r):
    """S3 bucket key not enabled"""
    try:
        sse = r.get('server_side_encryption_configuration') or []
        sse = (sse[0] if isinstance(sse, list) and sse else sse) or {}
        if not isinstance(sse, dict) or not sse: return
        rule = sse.get('rule') or {}
        rule = (rule[0] if isinstance(rule, list) and rule else rule) or {}
        if isinstance(rule, dict) and not rule.get('bucket_key_enabled', False):
            return 'S3 bucket key not enabled - increases KMS API costs'
    except Exception:
        return
def check_s3_object_ownership(r):
    """S3 object ownership misconfigured"""
    if r.get('object_ownership', '') not in ['BucketOwnerEnforced', 'BucketOwnerPreferred']:
        return 'S3 object ownership not set to BucketOwnerEnforced'
def check_s3_notification_missing(r):
    """S3 missing event notifications"""
    if not r.get('notification') and not r.get('bucket_notification'):
        return 'S3 bucket has no event notifications configured'
def check_s3_policy_missing(r):
    """S3 bucket missing bucket policy"""
    if not r.get('policy'):
        return 'S3 bucket has no bucket policy - access depends on ACLs only'
def check_s3_versioning_suspended(r):
    """S3 versioning is suspended"""
    v = r.get('versioning', {}); v = (v[0] if isinstance(v, list) else v) or {}
    if v.get('status') == 'Suspended':
        return 'S3 bucket versioning is Suspended - object history not maintained'
def check_s3_transfer_acceleration(r):
    """S3 transfer acceleration unnecessarily enabled"""
    if r.get('acceleration_status') == 'Enabled':
        return 'S3 Transfer Acceleration enabled - verify need and cost'
def check_s3_intelligent_tiering(r):
    """S3 no intelligent tiering for cost optimization"""
    if not r.get('intelligent_tiering_configuration'):
        return 'S3 Intelligent-Tiering not configured - potential cost issue'
def check_s3_access_log_target(r):
    """S3 logging missing target bucket"""
    logging = r.get('logging', {}); logging = (logging[0] if isinstance(logging, list) else logging) or {}
    if logging and not logging.get('target_bucket'):
        return 'S3 access log has no target bucket'
def check_s3_no_inventory(r):
    """S3 bucket missing inventory configuration"""
    if not r.get('inventory_source_bucket_arn') and not r.get('bucket_inventory'):
        return 'S3 bucket inventory not configured - no object visibility'
def check_s3_public_access_enabled_acl(r):
    """S3 public ACL set explicitly"""
    if r.get('acl', '') in ['public-read', 'public-read-write']:
        return f'S3 bucket ACL is {r.get("acl")} - CRITICAL: data publicly exposed'
def check_s3_requester_pays(r):
    """S3 requester pays enabled"""
    if r.get('request_payer') == 'requester':
        return 'S3 requester-pays enabled - verify business intent'
def check_s3_no_replication_encryption(r):
    """S3 replication config missing encryption"""
    rep = r.get('replication_configuration', {}); rep = (rep[0] if isinstance(rep, list) else rep) or {}
    rules = rep.get('rule', []); rules = rules if isinstance(rules, list) else [rules]
    for rr in rules:
        ss = (rr or {}).get('source_selection_criteria', {}); ss = (ss[0] if isinstance(ss, list) else ss) or {}
        if not ss.get('sse_kms_encrypted_objects'):
            return 'S3 replication does not enforce SSE-KMS on replicated objects'
def check_s3_object_lock_mode(r):
    """S3 Object Lock missing COMPLIANCE mode"""
    olc = r.get('object_lock_configuration', {}); olc = (olc[0] if isinstance(olc, list) else olc) or {}
    rule = olc.get('rule', {}); rule = (rule[0] if isinstance(rule, list) else rule) or {}
    dd = rule.get('default_retention', {}); dd = (dd[0] if isinstance(dd, list) else dd) or {}
    if olc and dd.get('mode', '') == 'GOVERNANCE':
        return 'S3 Object Lock uses GOVERNANCE mode - prefer COMPLIANCE for stricter protection'
def check_s3_no_cross_region_replication(r):
    """S3 no cross-region replication for disaster recovery"""
    rep = r.get('replication_configuration', {}); rep = (rep[0] if isinstance(rep, list) else rep) or {}
    if not rep:
        return 'S3 bucket lacks cross-region replication - single-region data risk'
def check_s3_access_point_missing(r):
    """S3 access points not used"""
    if not r.get('access_point'):
        return 'S3 access points not configured - consider for fine-grained access control'
def check_s3_event_bridge_missing(r):
    """S3 EventBridge integration missing"""
    notification = r.get('notification', {}); notification = (notification[0] if isinstance(notification, list) else notification) or {}
    if notification and not notification.get('eventbridge'):
        return 'S3 bucket is not integrated with EventBridge for advanced event routing'
def check_s3_analytics_not_configured(r):
    """S3 analytics not configured"""
    if not r.get('analytics_configuration'):
        return 'S3 bucket analytics not configured - no access pattern visibility'
def check_s3_acl_authenticated_read(r):
    """S3 authenticated-read ACL allows all AWS users"""
    if r.get('acl') == 'authenticated-read':
        return 'S3 ACL is authenticated-read - any AWS user can access - HIGH RISK'
def check_s3_versioning_disabled(r):
    """S3 versioning disabled"""
    v = r.get('versioning', {}); v = (v[0] if isinstance(v, list) else v) or {}
    if not v.get('enabled', False) and v.get('status', '') not in ['Enabled']:
        return 'S3 bucket versioning is disabled - no version history'
def check_s3_no_delete_protection(r):
    """S3 no delete protection mechanism"""
    v = r.get('versioning', {}); v = (v[0] if isinstance(v, list) else v) or {}
    olc = r.get('object_lock_configuration')
    if not v.get('enabled') and not olc:
        return 'S3 bucket has no deletion protection (no versioning or object lock)'
def check_s3_logging_disabled(r):
    """S3 access logging disabled"""
    logging = r.get('logging', {}); logging = (logging[0] if isinstance(logging, list) else logging) or {}
    if not logging:
        return 'S3 access logging is disabled - HIGH RISK'

S3_EXTRA_RULES = [
    check_s3_lifecycle, check_s3_replication, check_s3_object_lock, check_s3_mfa_delete,
    check_s3_kms_not_used, check_s3_cors_wildcard, check_s3_website_enabled, check_s3_no_tags,
    check_s3_bucket_key_disabled, check_s3_object_ownership, check_s3_notification_missing,
    check_s3_policy_missing, check_s3_versioning_suspended, check_s3_transfer_acceleration,
    check_s3_intelligent_tiering, check_s3_access_log_target, check_s3_no_inventory,
    check_s3_public_access_enabled_acl, check_s3_requester_pays, check_s3_no_replication_encryption,
    check_s3_object_lock_mode, check_s3_no_cross_region_replication, check_s3_access_point_missing,
    check_s3_event_bridge_missing, check_s3_analytics_not_configured, check_s3_acl_authenticated_read,
    check_s3_versioning_disabled, check_s3_no_delete_protection, check_s3_logging_disabled,
]

# ── EC2 EXTRA RULES ──────────────────────────────────────────────────────────
def check_ec2_termination_protection(r):
    """EC2 termination protection disabled"""
    if not r.get('disable_api_termination', False):
        return 'EC2 termination protection not enabled'
def check_ec2_no_instance_profile(r):
    """EC2 missing IAM instance profile"""
    if not r.get('iam_instance_profile'):
        return 'EC2 has no IAM instance profile - no role-based access'
def check_ec2_ssh_key_in_use(r):
    """EC2 uses SSH key pair instead of SSM"""
    if r.get('key_name'):
        return 'EC2 uses SSH key pair - prefer SSM Session Manager'
def check_ec2_ebs_optimized_disabled(r):
    """EC2 EBS optimization disabled"""
    if not r.get('ebs_optimized', False):
        return 'EC2 is not EBS-optimized - reduced storage performance'
def check_ec2_no_tags(r):
    """EC2 has no tags"""
    if not r.get('tags'):
        return 'EC2 instance has no tags - cost and governance issue'
def check_ec2_source_dest_check_off(r):
    """EC2 source/dest check disabled"""
    if r.get('source_dest_check') is False:
        return 'EC2 source/dest check disabled - verify NAT role'
def check_ec2_too_many_sgs(r):
    """EC2 has too many security groups"""
    sgs = r.get('vpc_security_group_ids', []) or []
    if len(sgs) > 5:
        return f'EC2 has {len(sgs)} security groups - reduce complexity'
def check_ec2_t2_unlimited(r):
    """EC2 T2 unlimited credits unexpectedly enabled"""
    cs = r.get('credit_specification', {}); cs = (cs[0] if isinstance(cs, list) else cs) or {}
    if r.get('instance_type', '').startswith('t2.') and cs.get('cpu_credits') == 'unlimited':
        return 'EC2 T2 unlimited CPU credits enabled - unexpected cost'
def check_ec2_old_generation(r):
    """EC2 uses old instance generation"""
    old = ['t1.', 'm1.', 'm2.', 'm3.', 'c1.', 'c3.', 'r3.', 'i2.']
    itype = r.get('instance_type', '')
    if any(itype.startswith(g) for g in old):
        return f'EC2 instance type {itype} is previous gen - upgrade'
def check_ec2_no_vpc(r):
    """EC2 not in a VPC"""
    if not r.get('subnet_id') and not r.get('vpc_id'):
        return 'EC2 instance may not be in a VPC - HIGH RISK'
def check_ec2_stop_protection(r):
    """EC2 stop protection disabled"""
    if not r.get('disable_api_stop', False):
        return 'EC2 stop protection not enabled'
def check_ec2_no_launch_template(r):
    """EC2 not using launch template"""
    if not r.get('launch_template'):
        return 'EC2 does not use a launch template - harder to maintain consistently'
def check_ec2_large_user_data(r):
    """EC2 user data exceeds recommended size"""
    ud = r.get('user_data', '') or ''
    if len(ud) > 16384:
        return 'EC2 user_data exceeds 16KB - truncation may occur'
def check_ec2_insufficient_metadata_version(r):
    """EC2 IMDSv2 not required"""
    mo = r.get('metadata_options', {}); mo = (mo[0] if isinstance(mo, list) else mo) or {}
    if mo.get('http_tokens', 'optional') != 'required':
        return 'EC2 does not require IMDSv2 - metadata SSRF risk'
def check_ec2_no_monitoring(r):
    """EC2 detailed monitoring disabled"""
    if not r.get('monitoring', False):
        return 'EC2 detailed monitoring disabled'
def check_ec2_root_volume_unencrypted(r):
    """EC2 root volume not encrypted"""
    rbd = r.get('root_block_device', {}); rbd = (rbd[0] if isinstance(rbd, list) else rbd) or {}
    if not rbd.get('encrypted', False):
        return 'EC2 root volume not encrypted - HIGH RISK'
def check_ec2_ebs_delete_on_termination(r):
    """EC2 EBS volumes not set to delete on termination"""
    rbd = r.get('root_block_device', {}); rbd = (rbd[0] if isinstance(rbd, list) else rbd) or {}
    if rbd and not rbd.get('delete_on_termination', True):
        return 'EC2 root volume not set to delete on termination - orphan disk risk'
def check_ec2_public_ami(r):
    """EC2 using a public AMI without validation"""
    ami = r.get('ami', '')
    if ami and not r.get('ami_validated'):
        return 'EC2 AMI not explicitly validated - verify AMI ownership and content'
def check_ec2_no_placement_group(r):
    """EC2 not in a placement group"""
    if not r.get('placement_group'):
        return 'EC2 not in a placement group - potential higher latency'
def check_ec2_tenancy_default(r):
    """EC2 using shared tenancy"""
    if r.get('tenancy', 'default') == 'default':
        return 'EC2 uses shared tenancy - consider dedicated for compliance workloads'
def check_ec2_no_elastic_ip(r):
    """EC2 with public IP but no Elastic IP"""
    if r.get('associate_public_ip_address', False) and not r.get('elastic_ip'):
        return 'EC2 has dynamic public IP - use Elastic IP for stable addressing'
def check_ec2_user_data_has_secret(r):
    """EC2 user data may contain secrets"""
    ud = str(r.get('user_data', '') or '').lower()
    for pat in ['password', 'secret', 'api_key', 'token', 'credential']:
        if pat in ud:
            return f'EC2 user_data may contain sensitive data ({pat}) - HIGH RISK'
def check_ec2_no_ssm_agent(r):
    """EC2 not managed by SSM"""
    if not r.get('iam_instance_profile'):
        return 'EC2 likely not managed by SSM - no automated patching'
def check_ec2_auto_recovery_missing(r):
    """EC2 auto-recovery alarm not verified"""
    if not r.get('auto_recovery'):
        return 'EC2 auto-recovery not explicitly configured - risk of downtime'
def check_ec2_detailed_monitoring_off(r):
    """EC2 detailed CloudWatch monitoring off"""
    m = r.get('monitoring', {})
    if isinstance(m, dict) and not m.get('enabled', False):
        return 'EC2 detailed CloudWatch monitoring disabled'
def check_ec2_shutdown_behavior(r):
    """EC2 shutdown behavior should be stop not terminate"""
    if r.get('instance_initiated_shutdown_behavior') == 'terminate':
        return 'EC2 shutdown behavior is terminate - risk of accidental data loss'
def check_ec2_credits_not_standard(r):
    """EC2 T3/T4 burstable credits not set to standard"""
    cs = r.get('credit_specification', {}); cs = (cs[0] if isinstance(cs, list) else cs) or {}
    itype = r.get('instance_type', '')
    if (itype.startswith('t3.') or itype.startswith('t4.')) and cs.get('cpu_credits', 'standard') == 'unlimited':
        return 'EC2 T3/T4 unlimited CPU credits - unexpected charges possible'
def check_ec2_no_security_group(r):
    """EC2 has no security groups"""
    sgs = r.get('vpc_security_group_ids') or r.get('security_groups') or []
    if not sgs:
        return 'EC2 instance has no security groups - CRITICAL RISK'
def check_ec2_hibernation_enabled_no_encryption(r):
    """EC2 hibernation requires encrypted disk"""
    hib = r.get('hibernation_options', {}); hib = (hib[0] if isinstance(hib, list) else hib) or {}
    rbd = r.get('root_block_device', {}); rbd = (rbd[0] if isinstance(rbd, list) else rbd) or {}
    if hib.get('configured') and not rbd.get('encrypted'):
        return 'EC2 hibernation enabled but root volume not encrypted - conflict'

EC2_EXTRA_RULES = [
    check_ec2_termination_protection, check_ec2_no_instance_profile, check_ec2_ssh_key_in_use,
    check_ec2_ebs_optimized_disabled, check_ec2_no_tags, check_ec2_source_dest_check_off,
    check_ec2_too_many_sgs, check_ec2_t2_unlimited, check_ec2_old_generation, check_ec2_no_vpc,
    check_ec2_stop_protection, check_ec2_no_launch_template, check_ec2_large_user_data,
    check_ec2_insufficient_metadata_version, check_ec2_no_monitoring, check_ec2_root_volume_unencrypted,
    check_ec2_ebs_delete_on_termination, check_ec2_public_ami, check_ec2_no_placement_group,
    check_ec2_tenancy_default, check_ec2_no_elastic_ip, check_ec2_user_data_has_secret,
    check_ec2_no_ssm_agent, check_ec2_auto_recovery_missing, check_ec2_detailed_monitoring_off,
    check_ec2_shutdown_behavior, check_ec2_credits_not_standard, check_ec2_no_security_group,
    check_ec2_hibernation_enabled_no_encryption,
]

# ── RDS EXTRA RULES ──────────────────────────────────────────────────────────
def check_db_performance_insights(r):
    """RDS Performance Insights disabled"""
    if not r.get('performance_insights_enabled', False):
        return 'RDS Performance Insights disabled - no query-level visibility'
def check_db_enhanced_monitoring(r):
    """RDS enhanced monitoring disabled"""
    if not int(r.get('monitoring_interval', 0) or 0) > 0:
        return 'RDS enhanced monitoring disabled'
def check_db_cloudwatch_logs(r):
    """RDS not exporting logs to CloudWatch"""
    if not r.get('enabled_cloudwatch_logs_exports'):
        return 'RDS not exporting logs to CloudWatch'
def check_db_copy_tags_to_snapshot(r):
    """RDS not copying tags to snapshots"""
    if not r.get('copy_tags_to_snapshot', False):
        return 'RDS not copying tags to snapshots'
def check_db_storage_autoscaling(r):
    """RDS storage autoscaling disabled"""
    if not r.get('max_allocated_storage'):
        return 'RDS storage autoscaling disabled - risk of out-of-storage'
def check_db_default_port(r):
    """RDS using default port"""
    engine = r.get('engine', '')
    port = int(r.get('port', 0) or 0)
    defaults = {'mysql': 3306, 'postgres': 5432, 'mariadb': 3306}
    for eng, dp in defaults.items():
        if eng in engine and port == dp:
            return f'RDS using default port {dp} - consider non-default port'
def check_db_old_engine_version(r):
    """RDS engine version is end of life"""
    ev = r.get('engine_version', ''); e = r.get('engine', '')
    if 'mysql' in e and ev.startswith('5.6'):
        return f'RDS MySQL {ev} is end-of-life - upgrade required'
    if 'postgres' in e and ev.startswith('9.'):
        return f'RDS PostgreSQL {ev} is end-of-life - upgrade required'
def check_db_no_tags(r):
    """RDS has no tags"""
    if not r.get('tags'):
        return 'RDS instance has no tags - cost governance issue'
def check_db_no_maintenance_window(r):
    """RDS has no maintenance window"""
    if not r.get('maintenance_window'):
        return 'RDS has no maintenance window configured'
def check_db_credentials_in_tf(r):
    """RDS has plaintext password in config"""
    if r.get('password') and not r.get('manage_master_user_password'):
        return 'RDS password in Terraform config - use Secrets Manager - HIGH RISK'
def check_db_retention_low(r):
    """RDS backup retention too low"""
    ret = int(r.get('backup_retention_period', 0) or 0)
    if 0 < ret < 7:
        return f'RDS backup retention is {ret} days - recommend >= 7'
def check_db_no_subnet_group(r):
    """RDS has no DB subnet group"""
    if not r.get('db_subnet_group_name'):
        return 'RDS has no subnet group - may be in default VPC'
def check_db_no_parameter_group(r):
    """RDS using default parameter group"""
    if not r.get('parameter_group_name') or r.get('parameter_group_name', '').startswith('default.'):
        return 'RDS using default parameter group - harden parameters'
def check_db_no_option_group(r):
    """RDS using default option group"""
    if not r.get('option_group_name') or r.get('option_group_name', '').startswith('default.'):
        return 'RDS using default option group - explicitly configure options'
def check_db_publicly_accessible_strict(r):
    """RDS publicly accessible"""
    if r.get('publicly_accessible', False):
        return 'RDS is publicly accessible - CRITICAL: remove public access'
def check_db_no_read_replica(r):
    """RDS has no read replicas"""
    if not r.get('replicate_source_db') and int(r.get('replica_count', 0) or 0) == 0:
        return 'RDS has no read replicas - single point of read failure'
def check_db_license_model_cost(r):
    """RDS Oracle license cost check"""
    if 'oracle' in r.get('engine', '') and r.get('license_model') == 'license-included':
        return 'RDS Oracle uses license-included - verify cost vs BYOL'
def check_db_ca_cert_outdated(r):
    """RDS CA certificate outdated"""
    ca = r.get('ca_cert_identifier', '')
    outdated = ['rds-ca-2015', 'rds-ca-2019']
    if any(ca.startswith(o) for o in outdated):
        return f'RDS CA certificate {ca} is outdated - rotate to rds-ca-rsa2048-g1'
def check_db_no_kms_key(r):
    """RDS encrypted but no custom KMS key"""
    if r.get('storage_encrypted', False) and not r.get('kms_key_id'):
        return 'RDS uses default KMS key - use customer-managed KMS key'
def check_db_no_iam_auth(r):
    """RDS IAM authentication disabled"""
    if not r.get('iam_database_authentication_enabled', False):
        return 'RDS IAM DB authentication disabled'

RDS_EXTRA_RULES = [
    check_db_performance_insights, check_db_enhanced_monitoring, check_db_cloudwatch_logs,
    check_db_copy_tags_to_snapshot, check_db_storage_autoscaling, check_db_default_port,
    check_db_old_engine_version, check_db_no_tags, check_db_no_maintenance_window,
    check_db_credentials_in_tf, check_db_retention_low, check_db_no_subnet_group,
    check_db_no_parameter_group, check_db_no_option_group, check_db_publicly_accessible_strict,
    check_db_no_read_replica, check_db_license_model_cost, check_db_ca_cert_outdated,
    check_db_no_kms_key, check_db_no_iam_auth,
]

# ── SECURITY GROUP EXTRA RULES ────────────────────────────────────────────────
def check_sg_http_open(r):
    """SG allows HTTP from internet"""
    if _ingress_open(r, 80):
        return 'Security group allows HTTP (80) from internet - use HTTPS'
def check_sg_ftp_open(r):
    """SG allows FTP from internet"""
    if _ingress_open(r, 21):
        return 'Security group allows FTP (21) from internet - CRITICAL RISK'
def check_sg_smtp_open(r):
    """SG allows SMTP from internet"""
    if _ingress_open(r, 25):
        return 'Security group allows SMTP (25) from internet - spam relay risk'
def check_sg_telnet_open(r):
    """SG allows Telnet from internet"""
    if _ingress_open(r, 23):
        return 'Security group allows Telnet (23) from internet - CRITICAL RISK'
def check_sg_vnc_open(r):
    """SG allows VNC from internet"""
    if _ingress_open(r, 5900):
        return 'Security group allows VNC (5900) from internet - CRITICAL RISK'
def check_sg_elasticsearch_open(r):
    """SG allows Elasticsearch from internet"""
    if _ingress_open(r, 9200) or _ingress_open(r, 9300):
        return 'Security group allows Elasticsearch (9200/9300) from internet - CRITICAL RISK'
def check_sg_kibana_open(r):
    """SG allows Kibana from internet"""
    if _ingress_open(r, 5601):
        return 'Security group allows Kibana (5601) from internet - CRITICAL RISK'
def check_sg_redis_open(r):
    """SG allows Redis from internet"""
    if _ingress_open(r, 6379):
        return 'Security group allows Redis (6379) from internet - CRITICAL RISK'
def check_sg_memcached_open(r):
    """SG allows Memcached from internet"""
    if _ingress_open(r, 11211):
        return 'Security group allows Memcached (11211) from internet - CRITICAL RISK'
def check_sg_docker_open(r):
    """SG allows Docker API from internet"""
    if _ingress_open(r, 2375) or _ingress_open(r, 2376):
        return 'Security group allows Docker API (2375/2376) from internet - CRITICAL RISK'
def check_sg_kubernetes_open(r):
    """SG allows Kubernetes API from internet"""
    if _ingress_open(r, 6443):
        return 'Security group allows Kubernetes API (6443) from internet - CRITICAL RISK'
def check_sg_cassandra_open(r):
    """SG allows Cassandra from internet"""
    if _ingress_open(r, 9042):
        return 'Security group allows Cassandra (9042) from internet - CRITICAL RISK'
def check_sg_cifs_open(r):
    """SG allows SMB/CIFS from internet"""
    if _ingress_open(r, 445):
        return 'Security group allows SMB/CIFS (445) from internet - CRITICAL RISK'
def check_sg_netbios_open(r):
    """SG allows NetBIOS from internet"""
    if _ingress_open(r, 137) or _ingress_open(r, 138) or _ingress_open(r, 139):
        return 'Security group allows NetBIOS (137-139) from internet - CRITICAL RISK'
def check_sg_oracle_open(r):
    """SG allows Oracle DB from internet"""
    if _ingress_open(r, 1521):
        return 'Security group allows Oracle DB (1521) from internet - CRITICAL RISK'
def check_sg_mssql_open(r):
    """SG allows MSSQL from internet"""
    if _ingress_open(r, 1433):
        return 'Security group allows MSSQL (1433) from internet - CRITICAL RISK'
def check_sg_mongodb_open(r):
    """SG allows MongoDB from internet"""
    if _ingress_open(r, 27017):
        return 'Security group allows MongoDB (27017) from internet - CRITICAL RISK'
def check_sg_couchdb_open(r):
    """SG allows CouchDB from internet"""
    if _ingress_open(r, 5984):
        return 'Security group allows CouchDB (5984) from internet - CRITICAL RISK'
def check_sg_rpc_open(r):
    """SG allows RPC portmapper from internet"""
    if _ingress_open(r, 111):
        return 'Security group allows RPC (111) from internet - HIGH RISK'
def check_sg_hadoop_open(r):
    """SG allows Hadoop ports from internet"""
    for p in [8020, 8088, 9000, 50070]:
        if _ingress_open(r, p):
            return f'Security group allows Hadoop port {p} from internet - HIGH RISK'
def check_sg_icmp_unrestricted(r):
    """SG allows unrestricted ICMP"""
    for rule in (r.get('ingress') or []):
        if rule and '0.0.0.0/0' in (rule.get('cidr_blocks') or []) and rule.get('protocol') == 'icmp':
            return 'Security group allows unrestricted ICMP - network reconnaissance risk'
def check_sg_egress_unrestricted(r):
    """SG has unrestricted outbound"""
    for rule in (r.get('egress') or []):
        if rule and '0.0.0.0/0' in (rule.get('cidr_blocks') or []) and rule.get('protocol') == '-1':
            return 'Security group allows all outbound traffic - restrict egress'
def check_sg_no_description(r):
    """SG has no meaningful description"""
    desc = r.get('description', '')
    if not desc or desc in ['Managed by Terraform', 'default', '']:
        return 'Security group has no meaningful description'
def check_sg_no_tags(r):
    """SG has no tags"""
    if not r.get('tags'):
        return 'Security group has no tags - governance issue'
def check_sg_wide_port_range(r):
    """SG has overly wide port range"""
    for rule in (r.get('ingress') or []):
        if not rule: continue
        fp = int(rule.get('from_port', 0) or 0); tp = int(rule.get('to_port', 0) or 0)
        if (tp - fp) > 1000 and '0.0.0.0/0' in (rule.get('cidr_blocks') or []):
            return f'Security group has very wide port range ({fp}-{tp}) from internet'
def check_sg_smtp_465_open(r):
    """SG allows SMTPS from internet"""
    if _ingress_open(r, 465):
        return 'Security group allows SMTPS (465) from internet'
def check_sg_imap_open(r):
    """SG allows IMAP from internet"""
    if _ingress_open(r, 143) or _ingress_open(r, 993):
        return 'Security group allows IMAP (143/993) from internet'
def check_sg_pop3_open(r):
    """SG allows POP3 from internet"""
    if _ingress_open(r, 110) or _ingress_open(r, 995):
        return 'Security group allows POP3 (110/995) from internet'
def check_sg_nfs_open(r):
    """SG allows NFS from internet"""
    if _ingress_open(r, 2049):
        return 'Security group allows NFS (2049) from internet - CRITICAL RISK'
def check_sg_mysql_open(r):
    """SG allows MySQL from internet"""
    if _ingress_open(r, 3306):
        return 'Security group allows MySQL (3306) from internet - CRITICAL RISK'
def check_sg_postgres_open(r):
    """SG allows PostgreSQL from internet"""
    if _ingress_open(r, 5432):
        return 'Security group allows PostgreSQL (5432) from internet - CRITICAL RISK'
def check_sg_ldap_open(r):
    """SG allows LDAP from internet"""
    if _ingress_open(r, 389) or _ingress_open(r, 636):
        return 'Security group allows LDAP (389/636) from internet - CRITICAL RISK'
def check_sg_zookeeper_open(r):
    """SG allows Zookeeper from internet"""
    if _ingress_open(r, 2181):
        return 'Security group allows Zookeeper (2181) from internet - CRITICAL RISK'
def check_sg_all_ports_open(r):
    """SG allows all ports from internet"""
    for rule in (r.get('ingress') or []):
        if not rule: continue
        fp = int(rule.get('from_port', 1) or 1); tp = int(rule.get('to_port', 0) or 0)
        if '0.0.0.0/0' in (rule.get('cidr_blocks') or []) and fp == 0 and tp == 65535:
            return 'Security group allows ALL ports from internet - CRITICAL RISK'

SG_EXTRA_RULES = [
    check_sg_http_open, check_sg_ftp_open, check_sg_smtp_open, check_sg_telnet_open,
    check_sg_vnc_open, check_sg_elasticsearch_open, check_sg_kibana_open, check_sg_redis_open,
    check_sg_memcached_open, check_sg_docker_open, check_sg_kubernetes_open, check_sg_cassandra_open,
    check_sg_cifs_open, check_sg_netbios_open, check_sg_oracle_open, check_sg_mssql_open,
    check_sg_mongodb_open, check_sg_couchdb_open, check_sg_rpc_open, check_sg_hadoop_open,
    check_sg_icmp_unrestricted, check_sg_egress_unrestricted, check_sg_no_description,
    check_sg_no_tags, check_sg_wide_port_range, check_sg_smtp_465_open, check_sg_imap_open,
    check_sg_pop3_open, check_sg_nfs_open, check_sg_mysql_open, check_sg_postgres_open,
    check_sg_ldap_open, check_sg_zookeeper_open, check_sg_all_ports_open,
]
