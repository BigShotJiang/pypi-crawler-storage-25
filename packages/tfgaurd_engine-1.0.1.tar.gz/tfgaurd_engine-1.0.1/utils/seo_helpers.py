"""
SEO Helper Functions
Utilities for generating meta tags, Open Graph, Twitter Cards, etc.
"""

from flask import request, url_for
import os

from typing import Dict, Optional


def generate_meta_tags(
    title: str,
    description: str,
    keywords: Optional[str] = None,
    image: Optional[str] = None,
    url: Optional[str] = None,
    article: bool = False,
    author: Optional[str] = None,
    published_time: Optional[str] = None
) -> Dict[str, str]:
    """
    Generate complete meta tags for a page

    Args:
        title: Page title (50-60 characters recommended)
        description: Page description (150-160 characters recommended)
        keywords: Comma-separated keywords (optional, less important now)
        image: Full URL to social sharing image (1200x630px recommended)
        url: Canonical URL (defaults to current URL)
        article: Whether this is an article/blog post
        author: Article author name
        published_time: ISO 8601 timestamp for articles

    Returns:
        Dictionary of meta tag values for template rendering
    """
    # Get base URL
    site_url = request.url_root.rstrip('/')
    current_url = url or request.url

    # Default image if not provided
    default_image = f"{site_url}/static/img/og-default.png"
    og_image = image or default_image

    # Build meta tags dictionary
    meta = {
        # Basic Meta Tags
        'title': title,
        'description': description,
        'keywords': keywords or '',
        'canonical': current_url,
        'robots': 'index, follow',

        # Open Graph (Facebook, LinkedIn)
        'og_type': 'article' if article else 'website',
        'og_site_name': 'Policy Engine',
        'og_title': title,
        'og_description': description,
        'og_url': current_url,
        'og_image': og_image,
        'og_image_width': '1200',
        'og_image_height': '630',
        'og_locale': 'en_US',

        # Twitter Card
        'twitter_card': 'summary_large_image',
        'twitter_site': '@PolicyEngine',  # Update with actual Twitter handle
        'twitter_title': title,
        'twitter_description': description,
        'twitter_image': og_image,

        # Google Search Console, Analytics & Tag Manager
        'google_site_verification': os.getenv('GOOGLE_SITE_VERIFICATION', ''),
        'google_analytics_id': os.getenv('GOOGLE_ANALYTICS_ID', ''),
        'google_tag_manager_id': os.getenv('GOOGLE_TAG_MANAGER_ID', ''),
    }

    # Add article-specific tags
    if article and author:
        meta['article_author'] = author

    if article and published_time:
        meta['article_published_time'] = published_time

    return meta


def generate_breadcrumbs(items: list) -> list:
    """
    Generate breadcrumb navigation with Schema.org structured data

    Args:
        items: List of tuples (name, url)

    Example:
        items = [
            ('Home', '/'),
            ('Docs', '/docs'),
            ('Security Rules', '/docs/security-rules')
        ]

    Returns:
        List of breadcrumb items with structured data
    """
    breadcrumbs = []

    for position, (name, url) in enumerate(items, start=1):
        breadcrumbs.append({
            'name': name,
            'url': request.url_root.rstrip('/') + url if url.startswith('/') else url,
            'position': position
        })

    return breadcrumbs


def generate_faq_schema(faqs: list) -> dict:
    """
    Generate FAQ structured data for rich snippets

    Args:
        faqs: List of tuples (question, answer)

    Returns:
        Dictionary with FAQ schema markup
    """
    schema = {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        'mainEntity': []
    }

    for question, answer in faqs:
        schema['mainEntity'].append({
            '@type': 'Question',
            'name': question,
            'acceptedAnswer': {
                '@type': 'Answer',
                'text': answer
            }
        })

    return schema


def generate_article_schema(
    title: str,
    description: str,
    author: str,
    published_date: str,
    modified_date: Optional[str] = None,
    image: Optional[str] = None
) -> dict:
    """
    Generate Article structured data

    Args:
        title: Article title
        description: Article description
        author: Author name
        published_date: ISO 8601 date (e.g., '2026-02-18')
        modified_date: ISO 8601 date (optional)
        image: Full URL to article image

    Returns:
        Dictionary with Article schema markup
    """
    site_url = request.url_root.rstrip('/')

    schema = {
        '@context': 'https://schema.org',
        '@type': 'Article',
        'headline': title,
        'description': description,
        'author': {
            '@type': 'Person',
            'name': author
        },
        'datePublished': published_date,
        'dateModified': modified_date or published_date,
        'publisher': {
            '@type': 'Organization',
            'name': 'Policy Engine',
            'logo': {
                '@type': 'ImageObject',
                'url': f'{site_url}/static/img/logo.png'
            }
        }
    }

    if image:
        schema['image'] = image

    return schema


def generate_software_schema(
    name: str = 'Policy Engine',
    description: str = 'Automated Terraform policy validation and IaC security scanner',
    price: str = '0',
    rating: Optional[float] = None,
    rating_count: Optional[int] = None
) -> dict:
    """
    Generate SoftwareApplication structured data

    Returns:
        Dictionary with SoftwareApplication schema markup
    """
    site_url = request.url_root.rstrip('/')

    schema = {
        '@context': 'https://schema.org',
        '@type': 'SoftwareApplication',
        'name': name,
        'applicationCategory': 'DeveloperApplication',
        'operatingSystem': 'Web, Linux, Windows, macOS',
        'description': description,
        'url': site_url,
        'offers': {
            '@type': 'Offer',
            'price': price,
            'priceCurrency': 'USD'
        },
        'author': {
            '@type': 'Organization',
            'name': 'Policy Engine Team'
        }
    }

    if rating and rating_count:
        schema['aggregateRating'] = {
            '@type': 'AggregateRating',
            'ratingValue': str(rating),
            'ratingCount': str(rating_count)
        }

    return schema


# SEO metadata presets for common pages
SEO_PRESETS = {
    'homepage': {
        'title': 'Terraform Policy Checker | IaC Security Scanner | Policy Engine',
        'description': 'Automated Terraform security validation. Check IAM policies, S3 buckets, EC2 instances for compliance. Try free scanner now!',
        'keywords': 'terraform scanner, iac security, policy as code, compliance checker, terraform validation'
    },
    'check': {
        'title': 'Check Terraform Files | Policy Engine',
        'description': 'Upload and scan your Terraform files for security issues, compliance violations, and best practice deviations. Get instant results.',
        'keywords': 'terraform check, terraform scan, iac validation, terraform security'
    },
    'api': {
        'title': 'REST API Documentation | Policy Engine',
        'description': 'Integrate automated Terraform validation into CI/CD. RESTful API for policy checks, JSON responses, webhook support.',
        'keywords': 'terraform api, policy api, cicd integration, automated scanning'
    },
    'docs': {
        'title': 'Documentation | Terraform Security Rules | Policy Engine',
        'description': 'Complete guide to Terraform security policies: IAM, S3, EC2, RDS. Learn best practices for infrastructure as code compliance.',
        'keywords': 'terraform docs, iac security guide, policy rules, compliance documentation'
    },
    'login': {
        'title': 'Login | Policy Engine',
        'description': 'Sign in to Policy Engine to access your Terraform security scans, check history, and API keys.',
        'keywords': 'policy engine login, sign in'
    }
}


def get_preset_meta(preset_name: str, **overrides) -> Dict[str, str]:
    """
    Get preset meta tags with optional overrides

    Args:
        preset_name: Name of the preset (e.g., 'homepage', 'docs')
        **overrides: Any values to override in the preset

    Returns:
        Dictionary of meta tag values
    """
    preset = dict(SEO_PRESETS.get(preset_name, SEO_PRESETS['homepage']))  # shallow copy to avoid mutation
    preset.update(overrides)
    return generate_meta_tags(**preset)
