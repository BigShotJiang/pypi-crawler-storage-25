# ============================================================================
# EXTENDED RULES IMPORTS
# ============================================================================
from utils.aws_rules_part1 import (
    S3_EXTRA_RULES, EC2_EXTRA_RULES, RDS_EXTRA_RULES, SG_EXTRA_RULES,
)
from utils.aws_rules_part2 import (
    IAM_ROLE_RULES, IAM_USER_RULES, IAM_POLICY_EXTRA_RULES,
    IAM_PASSWORD_POLICY_RULES, EBS_EXTRA_RULES, ELB_EXTRA_RULES,
    LAMBDA_EXTRA_RULES, CLOUDTRAIL_RULES, KMS_RULES,
    DYNAMODB_RULES, REDSHIFT_RULES,
)
from utils.aws_rules_part3 import (
    ES_RULES, ECR_RULES, ECS_TASK_RULES, EKS_RULES, CLOUDFRONT_RULES,
    SNS_RULES, SQS_RULES, ELASTICACHE_RULES,
)
from utils.aws_rules_part4 import (
    KINESIS_RULES, EMR_RULES, CODEBUILD_RULES, SECRETS_MANAGER_RULES,
    VPC_RULES, APIGW_STAGE_RULES, CW_LOG_GROUP_RULES, ASG_RULES,
    WAFV2_RULES, MSK_RULES, EFS_RULES, SAGEMAKER_NOTEBOOK_RULES,
    BACKUP_PLAN_RULES, ACM_RULES, GUARDDUTY_RULES, GLUE_JOB_RULES,
    SSM_PARAMETER_RULES,
)
from utils.aws_rules_part5 import (
    AURORA_CLUSTER_RULES, DOCDB_RULES, NEPTUNE_RULES, MQ_RULES,
    ATHENA_WORKGROUP_RULES, SFN_RULES, CONFIG_RECORDER_RULES,
    ROUTE53_RULES, VPC_FLOW_LOG_RULES, NACL_RULES, SUBNET_RULES,
    S3_POLICY_RULES, IAM_ACCESS_KEY_RULES, EIP_RULES, IGW_RULES,
    RDS_SNAPSHOT_RULES, ECS_CLUSTER_RULES, ELASTICACHE_RG_EXTRA_RULES,
    CW_METRIC_ALARM_RULES, SNS_EXTRA_RULES, IAM_GROUP_RULES,
    API_REST_RULES, EKS_NODE_GROUP_RULES,
)

from utils.gcp_rules_part1 import (
    GCS_RULES, GCE_RULES, GCE_FIREWALL_RULES, GCE_DISK_RULES,
    GCE_SNAPSHOT_RULES, GCE_NETWORK_RULES, GCE_SUBNET_RULES,
    GCE_ROUTER_RULES, GCE_SSL_POLICY_RULES, GCE_INSTANCE_TEMPLATE_RULES,
    GCE_BACKEND_SERVICE_RULES, GCE_LB_RULES, GCE_MIG_RULES,
)

from utils.gcp_rules_part2 import (
    GCP_SQL_RULES, GCP_IAM_RULES, GCP_SA_RULES, GCP_KMS_RULES,
    GCP_CLOUD_RUN_RULES, GCP_CLOUD_FUNCTIONS_RULES,
)

from utils.gcp_rules_part3 import (
    GCP_GKE_RULES, GCP_PUBSUB_RULES, GCP_BQ_RULES, GCP_AR_RULES,
    GCP_DATAPROC_RULES, GCP_SECRET_RULES, GCP_LOGGING_RULES,
)

from utils.gcp_rules_part4 import (
    GCP_REDIS_RULES, GCP_SPANNER_RULES, GCP_MEMCACHE_RULES,
    GCP_GAE_RULES, GCP_ARMOR_RULES, GCP_PEERING_RULES,
    GCP_IAM_REFINED_RULES, GCP_BIGTABLE_RULES, GCP_DATAFLOW_RULES,
    GCP_CLOUDBUILD_RULES,
)

from utils.gcp_rules_part5 import (
    GCP_DNS_RULES, GCP_COMPOSER_RULES, GCP_VERTEX_RULES,
    GCP_ALLOYDB_RULES, GCP_RUN_JOB_RULES, GCP_APIGEE_RULES,
    GCP_NAT_REFINED_RULES, GCP_FUNC2_RULES, GCP_BQ_REFINED_RULES,
    GCP_GCS_REFINED_RULES,
)

from utils.gcp_rules_part6 import (
    GCP_DATAFUSION_RULES, GCP_DATAPLEX_RULES, GCP_FIRESTORE_RULES,
    GCP_ENDPOINTS_RULES, GCP_EVENTARC_RULES, GCP_FILESTORE_RULES,
    GCP_IAP_RULES, GCP_IDENTITY_RULES, GCP_IOT_RULES, GCP_NCC_RULES,
    GCP_RECAPTCHA_RULES, GCP_SCC_RULES, GCP_SOURCE_RULES,
    GCP_SPANNER_EXTRA_RULES, GCP_BQ_DT_RULES, GCP_RUN_DOMAIN_RULES,
    GCP_SCHEDULER_RULES, GCP_BUILD_EXTRA_RULES,
)

from utils.gcp_rules_part7 import (
    GCP_VPC_SC_RULES, GCP_BEYONDCORP_RULES, GCP_DEPLOY_RULES,
    GCP_CONTACTS_RULES, GCP_DATASTREAM_RULES, GCP_ASSURED_WORKLOADS_RULES,
    GCP_CLOUD_IDS_RULES, GCP_CA_RULES, GCP_TASKS_RULES, GCP_LOOKER_RULES,
    GCP_BMS_RULES, GCP_EVENTARC_REFINED_RULES, GCP_RUN_REFINED_RULES,
    GCP_DISK_REFINED_RULES, GCP_GKE_HUB_RULES,
)

# ============================================================================
# S3 BUCKET SECURITY RULES
# ============================================================================

def check_public_read_acl(resource):
    """Check if S3 bucket has public-read ACL"""
    if resource.get('acl') == 'public-read':
        return 'S3 bucket is public (acl: public-read) - HIGH RISK'
    return None

def check_public_read_write_acl(resource):
    """Check if S3 bucket has public-read-write ACL"""
    if resource.get('acl') == 'public-read-write':
        return 'S3 bucket has public read-write access - CRITICAL RISK'
    return None

def check_authenticated_read_acl(resource):
    """Check if S3 bucket allows authenticated users"""
    if resource.get('acl') == 'authenticated-read':
        return 'S3 bucket allows any authenticated AWS user to read'
    return None

def check_block_public_acls(resource):
    """Check if S3 bucket blocks public ACLs"""
    if not resource.get('block_public_acls', False):
        return 'S3 bucket does not block public ACLs'
    return None

def check_block_public_policy(resource):
    """Check if S3 bucket blocks public policies"""
    if not resource.get('block_public_policy', False):
        return 'S3 bucket does not block public policies'
    return None

def check_ignore_public_acls(resource):
    """Check if S3 bucket ignores public ACLs"""
    if not resource.get('ignore_public_acls', False):
        return 'S3 bucket does not ignore public ACLs'
    return None

def check_restrict_public_buckets(resource):
    """Check if S3 bucket restricts public bucket policies"""
    if not resource.get('restrict_public_buckets', False):
        return 'S3 bucket does not restrict public bucket policies'
    return None

def check_s3_encryption(resource):
    """Check if S3 bucket has default encryption enabled"""
    server_side_encryption = resource.get('server_side_encryption_configuration')
    # Handle list format
    if isinstance(server_side_encryption, list):
        server_side_encryption = server_side_encryption[0] if server_side_encryption else None
    if not server_side_encryption:
        return 'S3 bucket does not have default encryption enabled'
    return None

def check_s3_versioning(resource):
    """Check if S3 bucket has versioning enabled"""
    versioning = resource.get('versioning', {})
    # Handle list format
    if isinstance(versioning, list):
        versioning = versioning[0] if versioning else {}
    if not versioning or not versioning.get('enabled', False):
        return 'S3 bucket does not have versioning enabled'
    return None

def check_s3_logging(resource):
    """Check if S3 bucket has access logging enabled"""
    logging = resource.get('logging')
    # Handle list format
    if isinstance(logging, list):
        logging = logging[0] if logging else None
    if not logging:
        return 'S3 bucket does not have access logging enabled'
    return None

def check_s3_ssl_requests_only(resource):
    """Check if S3 bucket enforces SSL/TLS"""
    policy = resource.get('policy', '')
    if 'aws:SecureTransport' not in str(policy):
        return 'S3 bucket does not enforce SSL/TLS for requests'
    return None

# List of S3 rules to check
S3_RULES = [
    check_public_read_acl,
    check_public_read_write_acl,
    check_authenticated_read_acl,
    check_block_public_acls,
    check_block_public_policy,
    check_ignore_public_acls,
    check_restrict_public_buckets,
    check_s3_encryption,
    check_s3_versioning,
    check_s3_logging,
    check_s3_ssl_requests_only
]

# ============================================================================
# RDS DATABASE SECURITY RULES
# ============================================================================

def check_db_encryption(resource):
    """Check if database has encryption enabled"""
    if not resource.get('storage_encrypted', False):
        return 'RDS database is not encrypted at rest - HIGH RISK'
    return None

def check_db_public_access(resource):
    """Check if database is publicly accessible"""
    if resource.get('publicly_accessible', False):
        return 'RDS database is publicly accessible - CRITICAL RISK'
    return None

def check_db_multi_az(resource):
    """Check if database has multi-AZ enabled for HA"""
    if not resource.get('multi_az', False):
        return 'RDS database does not have multi-AZ enabled (availability risk)'
    return None

def check_db_backup_retention(resource):
    """Check if database has adequate backup retention"""
    retention = resource.get('backup_retention_period', 0)
    if retention < 7:
        return f'RDS database backup retention is {retention} days (recommended: >= 7)'
    return None

def check_db_deletion_protection(resource):
    """Check if database has deletion protection"""
    if not resource.get('deletion_protection', False):
        return 'RDS database does not have deletion protection enabled'
    return None

def check_db_auto_minor_version_upgrade(resource):
    """Check if database has auto minor version upgrades"""
    if not resource.get('auto_minor_version_upgrade', True):
        return 'RDS database does not have auto minor version upgrades enabled'
    return None

def check_db_iam_authentication(resource):
    """Check if database uses IAM authentication"""
    if not resource.get('iam_database_authentication_enabled', False):
        return 'RDS database does not use IAM authentication'
    return None

# List of database rules to check
DB_RULES = [
    check_db_encryption,
    check_db_public_access,
    check_db_multi_az,
    check_db_backup_retention,
    check_db_deletion_protection,
    check_db_auto_minor_version_upgrade,
    check_db_iam_authentication
]

# ============================================================================
# EC2 INSTANCE SECURITY RULES
# ============================================================================

def check_ec2_public_ip(resource):
    """Check if EC2 instance has public IP"""
    if resource.get('associate_public_ip_address', False):
        return 'EC2 instance has public IP address assigned'
    return None

def check_ec2_imdsv2(resource):
    """Check if EC2 instance requires IMDSv2"""
    metadata_options = resource.get('metadata_options', {})
    # Handle list format
    if isinstance(metadata_options, list):
        metadata_options = metadata_options[0] if metadata_options else {}
    if metadata_options.get('http_tokens') != 'required':
        return 'EC2 instance does not require IMDSv2 (metadata security risk)'
    return None

def check_ec2_monitoring(resource):
    """Check if EC2 instance has detailed monitoring"""
    if not resource.get('monitoring', False):
        return 'EC2 instance does not have detailed monitoring enabled'
    return None

def check_ec2_ebs_encryption(resource):
    """Check if EC2 root volume is encrypted"""
    root_block_device = resource.get('root_block_device', {})
    # Handle both dict and list formats
    if isinstance(root_block_device, list):
        root_block_device = root_block_device[0] if root_block_device else {}
    if not root_block_device.get('encrypted', False):
        return 'EC2 instance root volume is not encrypted'
    return None

def check_ec2_user_data_secrets(resource):
    """Check if EC2 user data contains potential secrets"""
    user_data = resource.get('user_data', '')
    sensitive_patterns = ['password', 'secret', 'api_key', 'apikey', 'token', 'credentials']
    for pattern in sensitive_patterns:
        if pattern.lower() in str(user_data).lower():
            return f'EC2 instance user_data may contain sensitive data ({pattern})'
    return None

EC2_RULES = [
    check_ec2_public_ip,
    check_ec2_imdsv2,
    check_ec2_monitoring,
    check_ec2_ebs_encryption,
    check_ec2_user_data_secrets
]

# ============================================================================
# SECURITY GROUP RULES
# ============================================================================

def check_sg_ssh_open_to_world(resource):
    """Check if SSH (port 22) is open to the internet"""
    ingress_rules = resource.get('ingress', [])
    if not isinstance(ingress_rules, list):
        ingress_rules = [ingress_rules]
    
    for rule in ingress_rules:
        if not rule:
            continue
        cidr_blocks = rule.get('cidr_blocks', [])
        from_port = rule.get('from_port', 0)
        to_port = rule.get('to_port', 0)
        
        if '0.0.0.0/0' in cidr_blocks and from_port <= 22 <= to_port:
            return 'Security group allows SSH (port 22) from internet - CRITICAL RISK'
    return None

def check_sg_rdp_open_to_world(resource):
    """Check if RDP (port 3389) is open to the internet"""
    ingress_rules = resource.get('ingress', [])
    if not isinstance(ingress_rules, list):
        ingress_rules = [ingress_rules]
    
    for rule in ingress_rules:
        if not rule:
            continue
        cidr_blocks = rule.get('cidr_blocks', [])
        from_port = rule.get('from_port', 0)
        to_port = rule.get('to_port', 0)
        
        if '0.0.0.0/0' in cidr_blocks and from_port <= 3389 <= to_port:
            return 'Security group allows RDP (port 3389) from internet - CRITICAL RISK'
    return None

def check_sg_all_traffic_open(resource):
    """Check if all traffic is open to the internet"""
    ingress_rules = resource.get('ingress', [])
    if not isinstance(ingress_rules, list):
        ingress_rules = [ingress_rules]
    
    for rule in ingress_rules:
        if not rule:
            continue
        cidr_blocks = rule.get('cidr_blocks', [])
        protocol = rule.get('protocol', '')
        
        if '0.0.0.0/0' in cidr_blocks and protocol == '-1':
            return 'Security group allows all traffic from internet - CRITICAL RISK'
    return None

def check_sg_database_ports_open(resource):
    """Check if database ports are open to the internet"""
    ingress_rules = resource.get('ingress', [])
    if not isinstance(ingress_rules, list):
        ingress_rules = [ingress_rules]
    
    db_ports = {3306: 'MySQL', 5432: 'PostgreSQL', 1433: 'MSSQL', 27017: 'MongoDB', 6379: 'Redis'}
    
    for rule in ingress_rules:
        if not rule:
            continue
        cidr_blocks = rule.get('cidr_blocks', [])
        from_port = rule.get('from_port', 0)
        to_port = rule.get('to_port', 0)
        
        if '0.0.0.0/0' in cidr_blocks:
            for port, db_name in db_ports.items():
                if from_port <= port <= to_port:
                    return f'Security group allows {db_name} (port {port}) from internet - CRITICAL RISK'
    return None

SECURITY_GROUP_RULES = [
    check_sg_ssh_open_to_world,
    check_sg_rdp_open_to_world,
    check_sg_all_traffic_open,
    check_sg_database_ports_open
]

# ============================================================================
# IAM POLICY RULES
# ============================================================================

def check_iam_policy_admin_access(resource):
    """Check if IAM policy grants admin access"""
    policy = resource.get('policy', '')
    if '"Effect": "Allow"' in str(policy) and '"Action": "*"' in str(policy) and '"Resource": "*"' in str(policy):
        return 'IAM policy grants full admin access (*:*:*) - CRITICAL RISK'
    return None

def check_iam_policy_wildcard_actions(resource):
    """Check if IAM policy uses wildcard actions"""
    policy = resource.get('policy', '')
    if '"Action": "*"' in str(policy):
        return 'IAM policy uses wildcard actions (*)'
    return None

def check_iam_user_policy_attachment(resource):
    """Check if IAM policy is attached directly to user"""
    # This would be checked in policy_checker when we see aws_iam_user_policy_attachment
    return None

IAM_RULES = [
    check_iam_policy_admin_access,
    check_iam_policy_wildcard_actions
]

# ============================================================================
# EBS VOLUME RULES
# ============================================================================

def check_ebs_encryption(resource):
    """Check if EBS volume is encrypted"""
    if not resource.get('encrypted', False):
        return 'EBS volume is not encrypted - HIGH RISK'
    return None

def check_ebs_kms_key(resource):
    """Check if EBS volume uses KMS key"""
    if resource.get('encrypted', False) and not resource.get('kms_key_id'):
        return 'EBS volume uses default encryption instead of KMS key'
    return None

EBS_RULES = [
    check_ebs_encryption,
    check_ebs_kms_key
]

# ============================================================================
# ELB/ALB RULES
# ============================================================================

def check_elb_access_logs(resource):
    """Check if load balancer has access logs enabled"""
    access_logs = resource.get('access_logs', {})
    # Handle list format
    if isinstance(access_logs, list):
        access_logs = access_logs[0] if access_logs else {}
    if not access_logs or not access_logs.get('enabled', False):
        return 'Load balancer does not have access logs enabled'
    return None

def check_elb_https_only(resource):
    """Check if load balancer listener uses HTTPS"""
    listeners = resource.get('listener', [])
    if not isinstance(listeners, list):
        listeners = [listeners]
    
    for listener in listeners:
        if listener and listener.get('protocol') == 'HTTP':
            return 'Load balancer has HTTP listener (should use HTTPS)'
    return None

def check_elb_deletion_protection(resource):
    """Check if load balancer has deletion protection"""
    if not resource.get('enable_deletion_protection', False):
        return 'Load balancer does not have deletion protection enabled'
    return None

ELB_RULES = [
    check_elb_access_logs,
    check_elb_https_only,
    check_elb_deletion_protection
]

# ============================================================================
# LAMBDA FUNCTION RULES
# ============================================================================

def check_lambda_vpc(resource):
    """Check if Lambda function is in VPC"""
    if not resource.get('vpc_config'):
        return 'Lambda function is not deployed in VPC'
    return None

def check_lambda_tracing(resource):
    """Check if Lambda function has X-Ray tracing enabled"""
    tracing_config = resource.get('tracing_config', {})
    # Handle list format
    if isinstance(tracing_config, list):
        tracing_config = tracing_config[0] if tracing_config else {}
    if tracing_config.get('mode') != 'Active':
        return 'Lambda function does not have X-Ray tracing enabled'
    return None

def check_lambda_reserved_concurrency(resource):
    """Check if Lambda function has reserved concurrency"""
    if not resource.get('reserved_concurrent_executions'):
        return 'Lambda function does not have reserved concurrency (throttling risk)'
    return None

def check_lambda_dead_letter_config(resource):
    """Check if Lambda function has dead letter queue"""
    dead_letter_config = resource.get('dead_letter_config')
    # Handle list format
    if isinstance(dead_letter_config, list):
        dead_letter_config = dead_letter_config[0] if dead_letter_config else None
    if not dead_letter_config:
        return 'Lambda function does not have dead letter queue configured'
    return None

LAMBDA_RULES = [
    check_lambda_vpc,
    check_lambda_tracing,
    check_lambda_reserved_concurrency,
    check_lambda_dead_letter_config
]

# ============================================================================
# GCP SECURITY RULES
# ============================================================================

def check_gcp_bucket_public(resource):
    """Check if GCP storage bucket enforces uniform bucket-level access"""
    ubla = resource.get('uniform_bucket_level_access', {})
    if isinstance(ubla, list):
        ubla = ubla[0] if ubla else {}
    if not ubla or not ubla.get('enabled', False):
        return 'GCP Storage Bucket does not enforce Uniform Bucket-Level Access - HIGH RISK'
    return None

def check_gcp_compute_public_ip(resource):
    """Check if GCP compute instance has a public IP"""
    network_interfaces = resource.get('network_interface', [])
    if not isinstance(network_interfaces, list):
        network_interfaces = [network_interfaces]
    for ni in network_interfaces:
        if ni and 'access_config' in ni:
            return 'GCP Compute Instance has a public IP configured - HIGH RISK'
    return None

GCP_RULES = [
    check_gcp_bucket_public,
    check_gcp_compute_public_ip
]

from utils.azure_rules_part1 import AZURE_RULES_MAP
from utils.azure_rules_part2 import AZURE_RULES_MAP_PART2
from utils.oci_rules_part1 import OCI_RULES_MAP
from utils.oci_rules_part2 import OCI_RULES_MAP_PART2

# ============================================================================
# RULE REGISTRY - Maps resource types to their rule sets
# ============================================================================

# ============================================================================
# FREE TIER RULE REGISTRY (~100 essential rules for core AWS services)
# Premium tier adds 630+ rules across 70+ resource types.
# ============================================================================

RULE_REGISTRY_FREE = {
    # Core S3 checks — 11 rules
    'aws_s3_bucket': S3_RULES,
    # Core RDS checks — 7 rules
    'aws_db_instance': DB_RULES,
    # Core EC2 checks — 5 rules
    'aws_instance': EC2_RULES,
    # Core Security Group checks — 4 rules
    'aws_security_group': SECURITY_GROUP_RULES,
    # Core IAM checks — 2 rules
    'aws_iam_policy': IAM_RULES,
    # Core EBS checks — 2 rules
    'aws_ebs_volume': EBS_RULES,
    # Core Load Balancer checks — 3 rules each
    'aws_lb':  ELB_RULES,
    'aws_alb': ELB_RULES,
    'aws_elb': ELB_RULES,
    # Core Lambda checks — 4 rules
    'aws_lambda_function': LAMBDA_RULES,
    # GCP / Azure / OCI — blocked by subscription check in policy_checker
}

RULE_REGISTRY = {
    # AWS S3
    'aws_s3_bucket': S3_RULES + S3_EXTRA_RULES,
    # AWS RDS
    'aws_db_instance': DB_RULES + RDS_EXTRA_RULES,
    # AWS EC2
    'aws_instance': EC2_RULES + EC2_EXTRA_RULES,
    # AWS Security Groups
    'aws_security_group': SECURITY_GROUP_RULES + SG_EXTRA_RULES,
    # AWS IAM
    'aws_iam_policy': IAM_RULES + IAM_POLICY_EXTRA_RULES,
    # AWS IAM Role
    'aws_iam_role': IAM_ROLE_RULES,
    # AWS IAM User
    'aws_iam_user': IAM_USER_RULES,
    # AWS IAM Password Policy
    'aws_iam_account_password_policy': IAM_PASSWORD_POLICY_RULES,
    # AWS EBS
    'aws_ebs_volume': EBS_RULES + EBS_EXTRA_RULES,
    # AWS ELB/ALB
    'aws_lb': ELB_RULES + ELB_EXTRA_RULES,
    'aws_alb': ELB_RULES + ELB_EXTRA_RULES,
    'aws_elb': ELB_RULES + ELB_EXTRA_RULES,
    # AWS Lambda
    'aws_lambda_function': LAMBDA_RULES + LAMBDA_EXTRA_RULES,
    # AWS CloudTrail
    'aws_cloudtrail': CLOUDTRAIL_RULES,
    # AWS KMS
    'aws_kms_key': KMS_RULES,
    # AWS DynamoDB
    'aws_dynamodb_table': DYNAMODB_RULES,
    # AWS Redshift
    'aws_redshift_cluster': REDSHIFT_RULES,
    # AWS Elasticsearch / OpenSearch
    'aws_elasticsearch_domain': ES_RULES,
    'aws_opensearch_domain': ES_RULES,
    # AWS ECR
    'aws_ecr_repository': ECR_RULES,
    # AWS ECS
    'aws_ecs_task_definition': ECS_TASK_RULES,
    # AWS EKS
    'aws_eks_cluster': EKS_RULES,
    # AWS CloudFront
    'aws_cloudfront_distribution': CLOUDFRONT_RULES,
    # AWS SNS
    'aws_sns_topic': SNS_RULES,
    # AWS SQS
    'aws_sqs_queue': SQS_RULES,
    # AWS ElastiCache
    'aws_elasticache_cluster': ELASTICACHE_RULES,
    'aws_elasticache_replication_group': ELASTICACHE_RULES + ELASTICACHE_RG_EXTRA_RULES,
    # AWS Kinesis
    'aws_kinesis_stream': KINESIS_RULES,
    # AWS EMR
    'aws_emr_cluster': EMR_RULES,
    # AWS CodeBuild
    'aws_codebuild_project': CODEBUILD_RULES,
    # AWS Secrets Manager
    'aws_secretsmanager_secret': SECRETS_MANAGER_RULES,
    # AWS VPC
    'aws_vpc': VPC_RULES,
    'aws_flow_log': VPC_FLOW_LOG_RULES,
    'aws_network_acl': NACL_RULES,
    'aws_subnet': SUBNET_RULES,
    'aws_eip': EIP_RULES,
    'aws_internet_gateway': IGW_RULES,
    # AWS API Gateway
    'aws_api_gateway_stage': APIGW_STAGE_RULES,
    'aws_apigatewayv2_stage': APIGW_STAGE_RULES,
    'aws_api_gateway_rest_api': API_REST_RULES,
    # AWS CloudWatch
    'aws_cloudwatch_log_group': CW_LOG_GROUP_RULES,
    'aws_cloudwatch_metric_alarm': CW_METRIC_ALARM_RULES,
    # AWS AutoScaling
    'aws_autoscaling_group': ASG_RULES,
    # AWS WAF
    'aws_wafv2_web_acl': WAFV2_RULES,
    # AWS MSK
    'aws_msk_cluster': MSK_RULES,
    # AWS EFS
    'aws_efs_file_system': EFS_RULES,
    # AWS SageMaker
    'aws_sagemaker_notebook_instance': SAGEMAKER_NOTEBOOK_RULES,
    # AWS Backup
    'aws_backup_plan': BACKUP_PLAN_RULES,
    # AWS ACM
    'aws_acm_certificate': ACM_RULES,
    # AWS GuardDuty
    'aws_guardduty_detector': GUARDDUTY_RULES,
    # AWS Glue
    'aws_glue_job': GLUE_JOB_RULES,
    # AWS SSM
    'aws_ssm_parameter': SSM_PARAMETER_RULES,
    # AWS Aurora
    'aws_rds_cluster': AURORA_CLUSTER_RULES,
    # AWS DocumentDB
    'aws_docdb_cluster': DOCDB_RULES,
    # AWS Neptune
    'aws_neptune_cluster': NEPTUNE_RULES,
    # AWS MQ
    'aws_mq_broker': MQ_RULES,
    # AWS Athena
    'aws_athena_workgroup': ATHENA_WORKGROUP_RULES,
    # AWS Step Functions
    'aws_sfn_state_machine': SFN_RULES,
    # AWS Config
    'aws_config_configuration_recorder': CONFIG_RECORDER_RULES,
    # AWS Route53
    'aws_route53_zone': ROUTE53_RULES,
    # AWS RDS Snapshots
    'aws_db_snapshot': RDS_SNAPSHOT_RULES,
    'aws_db_cluster_snapshot': RDS_SNAPSHOT_RULES,
    # AWS IAM Groups & Access Keys
    'aws_iam_group': IAM_GROUP_RULES,
    'aws_iam_access_key': IAM_ACCESS_KEY_RULES,
    # AWS EKS Node Groups
    'aws_eks_node_group': EKS_NODE_GROUP_RULES,
    # AWS ECS Cluster
    'aws_ecs_cluster': ECS_CLUSTER_RULES,
    # AWS S3 Bucket Policy
    'aws_s3_bucket_policy': S3_POLICY_RULES,
    # AWS SNS extras applied to policy too
    'aws_sns_topic_policy': SNS_EXTRA_RULES,

    # ========================================================================
    # GCP PREMIUM SECURITY RULES
    # ========================================================================
    'google_storage_bucket':           GCS_RULES + GCP_GCS_REFINED_RULES,
    'google_compute_instance':         GCE_RULES,
    'google_compute_firewall':         GCE_FIREWALL_RULES,
    'google_compute_disk':             GCE_DISK_RULES,
    'google_compute_snapshot':         GCE_SNAPSHOT_RULES,
    'google_compute_network':          GCE_NETWORK_RULES,
    'google_compute_subnetwork':       GCE_SUBNET_RULES,
    'google_compute_router':           GCE_ROUTER_RULES,
    'google_compute_router_nat':       GCP_NAT_REFINED_RULES,
    'google_compute_ssl_policy':       GCE_SSL_POLICY_RULES,
    'google_compute_instance_template': GCE_INSTANCE_TEMPLATE_RULES,
    'google_compute_backend_service':  GCE_BACKEND_SERVICE_RULES,
    'google_compute_target_https_proxy': GCE_LB_RULES,
    'google_compute_target_ssl_proxy': GCE_LB_RULES,
    'google_compute_region_target_https_proxy': GCE_LB_RULES,
    'google_compute_instance_group_manager': GCE_MIG_RULES,
    'google_compute_region_instance_group_manager': GCE_MIG_RULES,
    'google_sql_database_instance':    GCP_SQL_RULES,
    'google_project_iam_binding':      GCP_IAM_RULES + GCP_IAM_REFINED_RULES,
    'google_project_iam_member':       GCP_IAM_RULES + GCP_IAM_REFINED_RULES,
    'google_folder_iam_binding':       GCP_IAM_RULES,
    'google_folder':                   GCP_IAM_RULES,
    'google_org_policy_policy':        GCP_IAM_RULES,
    'google_service_account':          GCP_SA_RULES,
    'google_service_account_key':      GCP_SA_RULES,
    'google_service_account_iam_binding': GCP_SA_RULES,
    'google_kms_crypto_key':           GCP_KMS_RULES,
    'google_kms_key_ring':             GCP_KMS_RULES,
    'google_kms_crypto_key_iam_binding': GCP_KMS_RULES,
    'google_cloud_run_service':        GCP_CLOUD_RUN_RULES,
    'google_cloud_run_v2_job':         GCP_RUN_JOB_RULES,
    'google_cloudfunctions_function':  GCP_CLOUD_FUNCTIONS_RULES,
    'google_cloudfunctions2_function': GCP_FUNC2_RULES,
    'google_container_cluster':        GCP_GKE_RULES,
    'google_pubsub_topic':             GCP_PUBSUB_RULES,
    'google_pubsub_subscription':      GCP_PUBSUB_RULES,
    'google_bigquery_dataset':         GCP_BQ_RULES + GCP_BQ_REFINED_RULES,
    'google_bigquery_table':           GCP_BQ_RULES + GCP_BQ_REFINED_RULES,
    'google_artifact_registry_repository': GCP_AR_RULES,
    'google_dataproc_cluster':         GCP_DATAPROC_RULES,
    'google_secret_manager_secret':    GCP_SECRET_RULES,
    'google_logging_project_sink':     GCP_LOGGING_RULES,
    'google_redis_instance':           GCP_REDIS_RULES,
    'google_spanner_instance':         GCP_SPANNER_RULES,
    'google_spanner_database_iam_binding': GCP_SPANNER_RULES,
    'google_memcache_instance':        GCP_MEMCACHE_RULES,
    'google_app_engine_application':   GCP_GAE_RULES,
    'google_app_engine_standard_app_version': GCP_GAE_RULES,
    'google_compute_network_peering':  GCP_PEERING_RULES,
    'google_compute_security_policy':  GCP_ARMOR_RULES,
    'google_bigtable_instance':        GCP_BIGTABLE_RULES,
    'google_dataflow_job':             GCP_DATAFLOW_RULES,
    'google_cloudbuild_trigger':       GCP_CLOUDBUILD_RULES,
    'google_dns_managed_zone':         GCP_DNS_RULES,
    'google_composer_environment':     GCP_COMPOSER_RULES,
    'google_vertex_ai_dataset':        GCP_VERTEX_RULES,
    'google_notebooks_instance':       GCP_VERTEX_RULES,
    'google_alloydb_cluster':          GCP_ALLOYDB_RULES,
    'google_apigee_environment':       GCP_APIGEE_RULES,
    'google_data_fusion_instance':     GCP_DATAFUSION_RULES,
    'google_dataplex_lake':            GCP_DATAPLEX_RULES,
    'google_dataplex_zone':            GCP_DATAPLEX_RULES,
    'google_dataplex_environment':     GCP_DATAPLEX_RULES,
    'google_datastore_index_iam_binding': GCP_FIRESTORE_RULES,
    'google_firestore_database':       GCP_FIRESTORE_RULES,
    'google_endpoints_service':        GCP_ENDPOINTS_RULES,
    'google_eventarc_trigger':         GCP_EVENTARC_RULES,
    'google_filestore_instance':       GCP_FILESTORE_RULES,
    'google_iap_web_iam_binding':      GCP_IAP_RULES,
    'google_iap_tunnel_iam_binding':   GCP_IAP_RULES,
    'google_identity_platform_config': GCP_IDENTITY_RULES,
    'google_iot_registry':             GCP_IOT_RULES,
    'google_network_connectivity_hub': GCP_NCC_RULES,
    'google_network_connectivity_spoke': GCP_NCC_RULES,
    'google_recaptcha_enterprise_key': GCP_RECAPTCHA_RULES,
    'google_scc_mute_config':          GCP_SCC_RULES,
    'google_scc_notification_config':  GCP_SCC_RULES,
    'google_sourcerepo_repository':    GCP_SOURCE_RULES,
    'google_sourcerepo_repository_iam_binding': GCP_SOURCE_RULES,
    'google_spanner_instance':         GCP_SPANNER_RULES + GCP_SPANNER_EXTRA_RULES,
    'google_bigquery_data_transfer_config': GCP_BQ_DT_RULES,
    'google_cloud_run_domain_mapping': GCP_RUN_DOMAIN_RULES,
    'google_cloud_scheduler_job':      GCP_SCHEDULER_RULES,
    'google_cloudbuild_trigger':       GCP_CLOUDBUILD_RULES + GCP_BUILD_EXTRA_RULES,
    'google_vpc_access_connector':     GCP_VPC_SC_RULES,  # mapped contextually
    'google_access_context_manager_service_perimeter': GCP_VPC_SC_RULES,
    'google_beyondcorp_app_connector': GCP_BEYONDCORP_RULES,
    'google_beyondcorp_app_gateway':   GCP_BEYONDCORP_RULES,
    'google_beyondcorp_app_connection': GCP_BEYONDCORP_RULES,
    'google_clouddeploy_delivery_pipeline': GCP_DEPLOY_RULES,
    'google_clouddeploy_target':       GCP_DEPLOY_RULES,
    'google_essential_contacts_contact': GCP_CONTACTS_RULES,
    'google_datastream_stream':        GCP_DATASTREAM_RULES,
    'google_datastream_connection_profile': GCP_DATASTREAM_RULES,
    'google_assured_workloads_workload': GCP_ASSURED_WORKLOADS_RULES,
    'google_cloud_ids_endpoint':       GCP_CLOUD_IDS_RULES,
    'google_privateca_ca_pool':        GCP_CA_RULES,
    'google_privateca_certificate':    GCP_CA_RULES,
    'google_cloud_tasks_queue':        GCP_TASKS_RULES,
    'google_looker_instance':          GCP_LOOKER_RULES,
    'google_bare_metal_solution_instance': GCP_BMS_RULES,
    'google_eventarc_trigger':         GCP_EVENTARC_RULES + GCP_EVENTARC_REFINED_RULES,
    'google_cloud_run_service':        GCP_CLOUD_RUN_RULES + GCP_RUN_REFINED_RULES,
    'google_compute_region_disk':      GCP_DISK_REFINED_RULES,
    'google_gke_hub_membership':       GCP_GKE_HUB_RULES,
    'google_gke_hub_feature':          GCP_GKE_HUB_RULES,

    # ========================================================================
    # AZURE SECURITY RULES
    # ========================================================================
    **AZURE_RULES_MAP,
    **AZURE_RULES_MAP_PART2,
    # Oracle Cloud (OCI)
    **OCI_RULES_MAP,
    **OCI_RULES_MAP_PART2,
}

# ============================================================================
# ============================================================================
# CUSTOM RULES STORAGE - Database storage for user-created rules
# ============================================================================
import json
from flask import g, session as flask_session

def _get_current_user_id(session):
    from core.models import User
    user_id = None
    try:
        if hasattr(g, "username") and g.username:
            u = session.query(User).filter_by(username=g.username).first()
            if u: user_id = u.id
        elif "user_id" in flask_session:
            user_id = flask_session["user_id"]
        elif "username" in flask_session:
            u = session.query(User).filter_by(username=flask_session["username"]).first()
            if u: user_id = u.id
    except:
        pass
        
    if not user_id:
        u = session.query(User).first()
        user_id = u.id if u else 1
    return user_id

def get_all_custom_rules():
    from core.database import get_db_session
    from core.models import CustomRule
    
    with get_db_session() as session:
        rules = session.query(CustomRule).filter_by(is_active=True).all()
        result = []
        for r in rules:
            try:
                data = json.loads(r.rule_code)
            except:
                data = {}
            if data.get('type') == 'code':
                result.append({
                    'name': r.name,
                    'description': r.description,
                    'resource_type': r.resource_type,
                    'severity': r.severity,
                    'code': data.get('code', ''),
                    'type': 'code'
                })
            else:
                result.append({
                    'name': r.name,
                    'description': r.description,
                    'resource_type': r.resource_type,
                    'severity': r.severity,
                    'condition': data.get('condition', ''),
                    'value': data.get('value', ''),
                    'category': data.get('category', ''),
                    'type': 'form'
                })
        return result

# For backward compatibility where CUSTOM_RULES was accessed directly as a property,
# we can make it a property of the module or just fix the 2 places it is used.
# But python modules don't support properties easily without sys.modules hack.
# I will define CUSTOM_RULES as an empty list to avoid import errors, but it should not be used.
CUSTOM_RULES = []

def add_custom_rule(rule_data):
    """Add a new custom rule"""
    from core.database import get_db_session
    from core.models import CustomRule
    
    with get_db_session() as session:
        payload = {
            'type': 'form',
            'condition': rule_data.get('rule_condition'),
            'value': rule_data.get('condition_value'),
            'category': rule_data.get('rule_category')
        }
        custom_rule = CustomRule(
            name=rule_data.get('rule_name'),
            description=rule_data.get('description'),
            resource_type=rule_data.get('resource_type'),
            severity=rule_data.get('severity_level', 'MEDIUM'),
            rule_code=json.dumps(payload),
            created_by=_get_current_user_id(session),
            is_active=True
        )
        session.add(custom_rule)
        session.flush()
        
        return {
            'name': custom_rule.name,
            'description': custom_rule.description,
            'resource_type': custom_rule.resource_type,
            'category': payload['category'],
            'condition': payload['condition'],
            'value': payload['value'],
            'severity': custom_rule.severity
        }

def update_custom_rule(rule_name, rule_data):
    """Update an existing custom rule"""
    from core.database import get_db_session
    from core.models import CustomRule
    
    with get_db_session() as session:
        rule = session.query(CustomRule).filter_by(name=rule_name, is_active=True).first()
        if not rule:
            return None
            
        payload = {
            'type': 'form',
            'condition': rule_data.get('rule_condition'),
            'value': rule_data.get('condition_value'),
            'category': rule_data.get('rule_category')
        }
        
        rule.name = rule_data.get('rule_name')
        rule.description = rule_data.get('description')
        rule.resource_type = rule_data.get('resource_type')
        rule.severity = rule_data.get('severity_level', 'MEDIUM')
        rule.rule_code = json.dumps(payload)
        session.commit()
        
        return {
            'name': rule.name,
            'description': rule.description,
            'resource_type': rule.resource_type,
            'category': payload['category'],
            'condition': payload['condition'],
            'value': payload['value'],
            'severity': rule.severity
        }

def delete_custom_rule(rule_name):
    """Delete a custom rule"""
    from core.database import get_db_session
    from core.models import CustomRule
    
    with get_db_session() as session:
        rule = session.query(CustomRule).filter_by(name=rule_name, is_active=True).first()
        if not rule:
            return False
            
        rule.is_active = False
        session.commit()
        return True

def get_custom_rule(rule_name):
    """Get a specific custom rule"""
    rules = get_all_custom_rules()
    for rule in rules:
        if rule['name'] == rule_name:
            return rule
    return None

def add_code_rule(rule_data):
    """Add a custom rule from Python code"""
    from core.database import get_db_session
    from core.models import CustomRule
    
    try:
        # Compile and validate the code
        code = rule_data.get('code_python', '')
        compile(code, '<string>', 'exec')
        
        with get_db_session() as session:
            payload = {
                'type': 'code',
                'code': code
            }
            custom_rule = CustomRule(
                name=rule_data.get('code_name'),
                description=rule_data.get('code_description', ''),
                resource_type=rule_data.get('code_resource_type'),
                severity=rule_data.get('code_severity', 'MEDIUM'),
                rule_code=json.dumps(payload),
                created_by=_get_current_user_id(session),
                is_active=True
            )
            session.add(custom_rule)
            session.flush()
            
            return {
                'name': custom_rule.name,
                'description': custom_rule.description,
                'resource_type': custom_rule.resource_type,
                'category': 'code-based',
                'condition': 'custom',
                'value': '',
                'severity': custom_rule.severity,
                'code': code,
                'type': 'code'
            }
    except SyntaxError as e:
        raise Exception(f'Invalid Python code: {str(e)}')
    except Exception as e:
        raise Exception(f'Error creating code rule: {str(e)}')