
# ============================================================================
# AZURE SECURITY RULES - PART 2
# Cognitive Services, Event Hubs, Service Bus, Redis, PostgreSQL, MySQL
# API Management, App Gateway, Data Factory, Databricks
# ============================================================================

def cognitive_no_public_access(r):
    if r.get('public_network_access_enabled', True): return 'Azure Cognitive Services allows public network access'
def cognitive_local_auth(r):
    if not r.get('local_authentication_enabled', False) == False: return 'Azure Cognitive Services allows local authentication'
def eventhub_no_trusted_services(r):
    n = r.get('network_rules', {}); n = (n[0] if isinstance(n, list) and n else n) or {}
    if not n.get('trusted_service_access_enabled', False): return 'Azure Event Hub network rules don\'t allow trusted Azure services'
def eventhub_local_auth(r):
    if not r.get('local_authentication_enabled', False) == False: return 'Azure Event Hub allows local authentication'

AZURE_COGNITIVE_RULES = [cognitive_no_public_access, cognitive_local_auth]
AZURE_EVENTHUB_RULES = [eventhub_no_trusted_services, eventhub_local_auth]

def pg_no_ssl(r):
    if not r.get('ssl_enforcement_enabled', True): return 'Azure PostgreSQL SSL enforcement is disabled'
def pg_no_min_tls(r):
    if r.get('ssl_minimal_tls_version_enforced', 'TLS1_0') != 'TLS1_2': return 'Azure PostgreSQL minimum TLS is not 1.2'
def pg_public_access(r):
    if r.get('public_network_access_enabled', True): return 'Azure PostgreSQL allows public network access'

AZURE_PG_RULES = [pg_no_ssl, pg_no_min_tls, pg_public_access]

def mysql_no_ssl(r):
    if not r.get('ssl_enforcement_enabled', True): return 'Azure MySQL SSL enforcement is disabled'
def mysql_no_min_tls(r):
    if r.get('ssl_minimal_tls_version_enforced', 'TLS1_0') != 'TLS1_2': return 'Azure MySQL minimum TLS is not 1.2'
def mysql_public_access(r):
    if r.get('public_network_access_enabled', True): return 'Azure MySQL allows public network access'

AZURE_MYSQL_RULES = [mysql_no_ssl, mysql_no_min_tls, mysql_public_access]

def redis_no_ssl(r):
    if not r.get('enable_non_ssl_port', False) == False: return 'Azure Redis Cache enables non-SSL port'
def redis_no_min_tls(r):
    if r.get('minimum_tls_version', '1.0') != '1.2': return 'Azure Redis Cache minimum TLS is not 1.2'
def redis_public_access(r):
    if r.get('public_network_access_enabled', True): return 'Azure Redis Cache allows public network access'

AZURE_REDIS_RULES = [redis_no_ssl, redis_no_min_tls, redis_public_access]

def apim_no_min_tls(r):
    s = r.get('security', {}); s = (s[0] if isinstance(s, list) and s else s) or {}
    if s.get('enable_frontend_tlsv10', False) or s.get('enable_frontend_tlsv11', False): return 'Azure API Management enables TLS 1.0/1.1 on frontend'
    if s.get('enable_backend_tlsv10', False) or s.get('enable_backend_tlsv11', False): return 'Azure API Management enables TLS 1.0/1.1 on backend'

AZURE_APIM_RULES = [apim_no_min_tls]

def appgw_no_waf(r):
    w = r.get('waf_configuration', {}); w = (w[0] if isinstance(w, list) and w else w) or {}
    if not w.get('enabled', False): return 'Azure Application Gateway WAF is disabled'

AZURE_APPGW_RULES = [appgw_no_waf]

def df_public_access(r):
    if r.get('public_network_enabled', True): return 'Azure Data Factory allows public network access'

AZURE_DF_RULES = [df_public_access]

def databricks_no_public_ip(r):
    c = r.get('custom_parameters', {}); c = (c[0] if isinstance(c, list) and c else c) or {}
    if not c.get('no_public_ip', False): return 'Azure Databricks Workspace has public IPs'

AZURE_DATABRICKS_RULES = [databricks_no_public_ip]

AZURE_RULES_MAP_PART2 = {
    'azurerm_cognitive_account': AZURE_COGNITIVE_RULES,
    'azurerm_eventhub_namespace': AZURE_EVENTHUB_RULES,
    'azurerm_postgresql_server': AZURE_PG_RULES,
    'azurerm_mysql_server': AZURE_MYSQL_RULES,
    'azurerm_redis_cache': AZURE_REDIS_RULES,
    'azurerm_api_management': AZURE_APIM_RULES,
    'azurerm_application_gateway': AZURE_APPGW_RULES,
    'azurerm_data_factory': AZURE_DF_RULES,
    'azurerm_databricks_workspace': AZURE_DATABRICKS_RULES
}
