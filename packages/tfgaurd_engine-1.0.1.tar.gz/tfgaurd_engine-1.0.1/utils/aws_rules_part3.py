
# ============================================================================
# AWS EXTENDED SECURITY RULES - PART 3
# Elasticsearch, ECR, ECS, EKS, CloudFront, SNS, SQS, ElastiCache
# ============================================================================

# ── ELASTICSEARCH RULES ───────────────────────────────────────────────────────
def check_es_encryption_at_rest(r):
    ea = r.get('encrypt_at_rest', {}); ea = (ea[0] if isinstance(ea, list) else ea) or {}
    if not ea.get('enabled', False): return 'Elasticsearch encryption at rest not enabled - HIGH RISK'
def check_es_node_to_node_encryption(r):
    ne = r.get('node_to_node_encryption', {}); ne = (ne[0] if isinstance(ne, list) else ne) or {}
    if not ne.get('enabled', False): return 'Elasticsearch node-to-node encryption disabled'
def check_es_no_vpc(r):
    vpc = r.get('vpc_options', {}); vpc = (vpc[0] if isinstance(vpc, list) else vpc) or {}
    if not vpc: return 'Elasticsearch domain not deployed in VPC - HIGH RISK'
def check_es_public_access(r):
    ap = r.get('access_policies', '') or ''
    if '"Principal": {"AWS": "*"}' in ap or '"Principal": "*"' in ap: return 'Elasticsearch allows public access - CRITICAL RISK'
def check_es_no_https(r):
    dep = r.get('domain_endpoint_options', {}); dep = (dep[0] if isinstance(dep, list) else dep) or {}
    if not dep.get('enforce_https', False): return 'Elasticsearch does not enforce HTTPS'
def check_es_tls_policy_weak(r):
    dep = r.get('domain_endpoint_options', {}); dep = (dep[0] if isinstance(dep, list) else dep) or {}
    tls = dep.get('tls_security_policy', 'Policy-Min-TLS-1-0-2019-07')
    if '1-0' in tls: return f'Elasticsearch TLS policy {tls} allows TLS 1.0 - upgrade to TLS 1.2'
def check_es_no_logging(r):
    ll = r.get('log_publishing_options', [])
    if not ll: return 'Elasticsearch log publishing not configured'
def check_es_no_kms(r):
    ea = r.get('encrypt_at_rest', {}); ea = (ea[0] if isinstance(ea, list) else ea) or {}
    if ea.get('enabled') and not ea.get('kms_key_id'): return 'Elasticsearch uses default KMS key - use customer-managed key'
def check_es_no_automated_snapshot(r):
    ss = r.get('snapshot_options', {}); ss = (ss[0] if isinstance(ss, list) else ss) or {}
    if ss.get('automated_snapshot_start_hour', -1) < 0: return 'Elasticsearch automated snapshot not configured'
def check_es_no_dedicated_master(r):
    cc = r.get('cluster_config', {}); cc = (cc[0] if isinstance(cc, list) else cc) or {}
    if not cc.get('dedicated_master_enabled', False): return 'Elasticsearch has no dedicated master nodes - stability risk'
def check_es_no_zone_awareness(r):
    cc = r.get('cluster_config', {}); cc = (cc[0] if isinstance(cc, list) else cc) or {}
    za = cc.get('zone_awareness_config', {}); za = (za[0] if isinstance(za, list) else za) or {}
    if not cc.get('zone_awareness_enabled', False): return 'Elasticsearch zone awareness disabled - single-AZ risk'
def check_es_no_tags(r):
    if not r.get('tags'): return 'Elasticsearch domain has no tags'
def check_es_fine_grained_access_missing(r):
    ac = r.get('advanced_security_options', {}); ac = (ac[0] if isinstance(ac, list) else ac) or {}
    if not ac.get('enabled', False): return 'Elasticsearch fine-grained access control not enabled'
def check_es_no_custom_endpoint(r):
    dep = r.get('domain_endpoint_options', {}); dep = (dep[0] if isinstance(dep, list) else dep) or {}
    if not dep.get('custom_endpoint_enabled', False): return 'Elasticsearch does not use custom endpoint - harder to manage certs'
def check_es_single_az(r):
    cc = r.get('cluster_config', {}); cc = (cc[0] if isinstance(cc, list) else cc) or {}
    if int(cc.get('instance_count', 1) or 1) < 2: return 'Elasticsearch cluster has only 1 node - single point of failure'

ES_RULES = [check_es_encryption_at_rest, check_es_node_to_node_encryption, check_es_no_vpc, check_es_public_access,
    check_es_no_https, check_es_tls_policy_weak, check_es_no_logging, check_es_no_kms,
    check_es_no_automated_snapshot, check_es_no_dedicated_master, check_es_no_zone_awareness,
    check_es_no_tags, check_es_fine_grained_access_missing, check_es_no_custom_endpoint, check_es_single_az]

# ── ECR RULES ────────────────────────────────────────────────────────────────
def check_ecr_scan_on_push(r):
    sc = r.get('image_scanning_configuration', {}); sc = (sc[0] if isinstance(sc, list) else sc) or {}
    if not sc.get('scan_on_push', False): return 'ECR scan on push not enabled - vulnerabilities undetected'
def check_ecr_no_encryption(r):
    ec = r.get('encryption_configuration', {}); ec = (ec[0] if isinstance(ec, list) else ec) or {}
    if not ec or ec.get('encryption_type', 'AES256') == 'AES256': return 'ECR using AES256 - prefer KMS encryption'
def check_ecr_public_repo(r):
    if r.get('image_tag_mutability', '') == '' and not r.get('repository_policy'): return 'ECR repository has no policy - may be publicly accessible'
def check_ecr_no_lifecycle_policy(r):
    if not r.get('lifecycle_policy'): return 'ECR has no lifecycle policy - untagged images accumulate'
def check_ecr_mutable_tags(r):
    if r.get('image_tag_mutability', 'MUTABLE') == 'MUTABLE': return 'ECR image tags are mutable - use IMMUTABLE for production'
def check_ecr_no_tags(r):
    if not r.get('tags'): return 'ECR repository has no tags'
def check_ecr_cross_account_access(r):
    pol = str(r.get('repository_policy', '') or '')
    if '"Principal": {"AWS": "*"}' in pol: return 'ECR repository policy allows any AWS account - CRITICAL RISK'
def check_ecr_no_replication(r):
    if not r.get('replication_configuration'): return 'ECR has no replication configured - no DR protection'
def check_ecr_pull_through_cache(r):
    if not r.get('pull_through_cache_rule'): return 'ECR pull-through cache not configured - direct Docker Hub pulls'
def check_ecr_no_enhanced_scanning(r):
    sc = r.get('image_scanning_configuration', {}); sc = (sc[0] if isinstance(sc, list) else sc) or {}
    if sc.get('scan_type', 'BASIC') != 'ENHANCED': return 'ECR uses BASIC scanning - enable ENHANCED scanning with Inspector'

ECR_RULES = [check_ecr_scan_on_push, check_ecr_no_encryption, check_ecr_public_repo, check_ecr_no_lifecycle_policy,
    check_ecr_mutable_tags, check_ecr_no_tags, check_ecr_cross_account_access, check_ecr_no_replication,
    check_ecr_pull_through_cache, check_ecr_no_enhanced_scanning]

# ── ECS TASK DEFINITION RULES ────────────────────────────────────────────────
def check_ecs_no_readonly_root(r):
    for cd in (r.get('container_definitions') or []):
        if isinstance(cd, dict) and not cd.get('readonlyRootFilesystem', False): return 'ECS container does not use readonlyRootFilesystem'
def check_ecs_privileged_container(r):
    for cd in (r.get('container_definitions') or []):
        if isinstance(cd, dict) and cd.get('privileged', False): return 'ECS container runs in privileged mode - CRITICAL RISK'
def check_ecs_no_log_configuration(r):
    for cd in (r.get('container_definitions') or []):
        if isinstance(cd, dict) and not cd.get('logConfiguration'): return 'ECS container has no log configuration'
def check_ecs_no_resource_limits(r):
    for cd in (r.get('container_definitions') or []):
        if isinstance(cd, dict) and not cd.get('cpu') and not cd.get('memory'): return 'ECS container has no CPU/memory limits'
def check_ecs_uses_host_network(r):
    if r.get('network_mode') == 'host': return 'ECS task uses host network mode - container isolation risk'
def check_ecs_no_task_role(r):
    if not r.get('task_role_arn'): return 'ECS task has no task IAM role - using EC2 instance role'
def check_ecs_no_execution_role(r):
    if not r.get('execution_role_arn'): return 'ECS task has no execution role - cannot pull from ECR or log'
def check_ecs_fargate_no_platform_version(r):
    if r.get('requires_compatibilities') == ['FARGATE'] and not r.get('runtime_platform'): return 'ECS Fargate task has no explicit platform version'
def check_ecs_env_secrets_in_plaintext(r):
    for cd in (r.get('container_definitions') or []):
        for ev in (cd or {}).get('environment', []):
            k = str((ev or {}).get('name', '')).lower()
            if any(s in k for s in ['password', 'secret', 'key', 'token']): return f'ECS container env var {ev.get("name")} may contain plaintext secret'
def check_ecs_no_tags(r):
    if not r.get('tags'): return 'ECS task definition has no tags'
def check_ecs_capabilities_added(r):
    for cd in (r.get('container_definitions') or []):
        cap = (cd or {}).get('linuxParameters', {}).get('capabilities', {}).get('add', [])
        if cap: return f'ECS container adds Linux capabilities: {cap} - review necessity'
def check_ecs_user_root(r):
    for cd in (r.get('container_definitions') or []):
        if isinstance(cd, dict) and cd.get('user', '') in ['root', '0']: return 'ECS container runs as root user - privilege risk'

ECS_TASK_RULES = [check_ecs_no_readonly_root, check_ecs_privileged_container, check_ecs_no_log_configuration,
    check_ecs_no_resource_limits, check_ecs_uses_host_network, check_ecs_no_task_role,
    check_ecs_no_execution_role, check_ecs_fargate_no_platform_version, check_ecs_env_secrets_in_plaintext,
    check_ecs_no_tags, check_ecs_capabilities_added, check_ecs_user_root]

# ── EKS RULES ─────────────────────────────────────────────────────────────────
def check_eks_public_endpoint(r):
    access = r.get('kubernetes_network_config', {}); ep = r.get('endpoint_public_access', True)
    if ep: return 'EKS API server endpoint is publicly accessible - CRITICAL RISK'
def check_eks_no_private_endpoint(r):
    if not r.get('endpoint_private_access', False): return 'EKS private endpoint not enabled'
def check_eks_no_logging(r):
    cfg = r.get('enabled_cluster_log_types', []) or []
    required = {'api', 'audit', 'authenticator', 'controllerManager', 'scheduler'}
    missing = required - set(cfg)
    if missing: return f'EKS missing control plane log types: {missing}'
def check_eks_no_encryption(r):
    ec = r.get('encryption_config', []) or []
    if not ec: return 'EKS secrets not encrypted with KMS'
def check_eks_no_tags(r):
    if not r.get('tags'): return 'EKS cluster has no tags'
def check_eks_outdated_version(r):
    ver = str(r.get('version', '') or '')
    if ver and ver < '1.28': return f'EKS version {ver} may be outdated - upgrade to supported version'
def check_eks_default_sg_used(r):
    vpc = r.get('vpc_config', {})
    vpc = (vpc[0] if isinstance(vpc, list) and vpc else vpc) or {}
    if not vpc.get('security_group_ids'): return 'EKS cluster has no custom security groups'
def check_eks_no_addon_vpc_cni(r):
    addons = [a.get('addon_name', '') for a in (r.get('addons') or []) if isinstance(a, dict)]
    if 'vpc-cni' not in addons: return 'EKS vpc-cni addon not managed - network plugin not version-pinned'
def check_eks_public_access_cidrs(r):
    cidrs = r.get('public_access_cidrs', ['0.0.0.0/0']) or ['0.0.0.0/0']
    if '0.0.0.0/0' in cidrs: return 'EKS public endpoint accessible from any IP (0.0.0.0/0) - restrict CIDRs'
def check_eks_no_node_encryption(r):
    for ng in (r.get('node_group') or []):
        disk = (ng or {}).get('disk_encrypted', False)
        if not disk: return 'EKS node group disk not encrypted'
def check_eks_no_oidc(r):
    if not r.get('identity', {}) and not r.get('oidc_provider_arn'): return 'EKS OIDC provider not configured - pod IAM roles unavailable'
def check_eks_no_fargate_profile(r):
    if not r.get('fargate_profile') and not r.get('node_group'): return 'EKS has neither node groups nor Fargate profiles'

EKS_RULES = [check_eks_public_endpoint, check_eks_no_private_endpoint, check_eks_no_logging,
    check_eks_no_encryption, check_eks_no_tags, check_eks_outdated_version, check_eks_default_sg_used,
    check_eks_no_addon_vpc_cni, check_eks_public_access_cidrs, check_eks_no_node_encryption,
    check_eks_no_oidc, check_eks_no_fargate_profile]

# ── CLOUDFRONT RULES ─────────────────────────────────────────────────────────
def check_cf_no_waf(r):
    if not r.get('web_acl_id'): return 'CloudFront distribution has no WAF WebACL'
def check_cf_no_https(r):
    for b in (r.get('origin') or []):
        op = (b or {}).get('custom_origin_config', {}); op = (op[0] if isinstance(op, list) else op) or {}
        if op.get('origin_protocol_policy', '') == 'http-only': return 'CloudFront origin uses HTTP-only - enforce HTTPS'
def check_cf_viewer_protocol_allow_http(r):
    for cbc in (r.get('default_cache_behavior', []) or []):
        if isinstance(cbc, dict) and cbc.get('viewer_protocol_policy') == 'allow-all': return 'CloudFront allows HTTP viewer requests - enforce HTTPS'
    if isinstance(r.get('default_cache_behavior'), dict):
        if r['default_cache_behavior'].get('viewer_protocol_policy') == 'allow-all': return 'CloudFront allows HTTP viewer requests - enforce HTTPS'
def check_cf_no_logging(r):
    lc = r.get('logging_config', {}); lc = (lc[0] if isinstance(lc, list) else lc) or {}
    if not lc.get('bucket'): return 'CloudFront access logging not enabled'
def check_cf_no_geo_restriction(r):
    gr = r.get('restrictions', {}); gr = (gr[0] if isinstance(gr, list) else gr) or {}
    ret = gr.get('geo_restriction', {}); ret = (ret[0] if isinstance(ret, list) else ret) or {}
    if ret.get('restriction_type', 'none') == 'none': return 'CloudFront has no geo-restriction - consider limiting to needed regions'
def check_cf_tls_minimum_version(r):
    vc = r.get('viewer_certificate', {}); vc = (vc[0] if isinstance(vc, list) else vc) or {}
    proto = vc.get('minimum_protocol_version', 'TLSv1')
    if proto in ['TLSv1', 'TLSv1_2016', 'TLSv1.1_2016']: return f'CloudFront minimum TLS version {proto} is outdated - use TLSv1.2_2021'
def check_cf_uses_default_cert(r):
    vc = r.get('viewer_certificate', {}); vc = (vc[0] if isinstance(vc, list) else vc) or {}
    if vc.get('cloudfront_default_certificate', False): return 'CloudFront uses default certificate (*.cloudfront.net) - use custom domain with ACM cert'
def check_cf_origin_ssl_protocols(r):
    for b in (r.get('origin') or []):
        op = (b or {}).get('custom_origin_config', {}); op = (op[0] if isinstance(op, list) else op) or {}
        protos = op.get('origin_ssl_protocols', [])
        if 'SSLv3' in protos or 'TLSv1' in protos: return 'CloudFront origin accepts SSLv3/TLSv1 - remove weak protocols'
def check_cf_no_tags(r):
    if not r.get('tags'): return 'CloudFront distribution has no tags'
def check_cf_no_compress(r):
    dcb = r.get('default_cache_behavior', {}); dcb = (dcb[0] if isinstance(dcb, list) else dcb) or {}
    if not dcb.get('compress', False): return 'CloudFront compression disabled - increases bandwidth costs'
def check_cf_http_version_not_http2(r):
    if r.get('http_version', 'http1.1') not in ['http2', 'http2and3']: return 'CloudFront not using HTTP/2 - lower performance'
def check_cf_no_custom_error_pages(r):
    if not r.get('custom_error_response'): return 'CloudFront has no custom error pages configured'
def check_cf_price_class_all(r):
    if r.get('price_class', 'PriceClass_All') == 'PriceClass_All': return 'CloudFront uses all edge locations - consider restricting price class for cost'

CLOUDFRONT_RULES = [check_cf_no_waf, check_cf_no_https, check_cf_viewer_protocol_allow_http, check_cf_no_logging,
    check_cf_no_geo_restriction, check_cf_tls_minimum_version, check_cf_uses_default_cert,
    check_cf_origin_ssl_protocols, check_cf_no_tags, check_cf_no_compress,
    check_cf_http_version_not_http2, check_cf_no_custom_error_pages, check_cf_price_class_all]

# ── SNS RULES ────────────────────────────────────────────────────────────────
def check_sns_no_encryption(r):
    if not r.get('kms_master_key_id'): return 'SNS topic not encrypted with KMS'
def check_sns_public_policy(r):
    if '"Principal": "*"' in str(r.get('policy', '') or ''): return 'SNS topic policy allows public access - CRITICAL RISK'
def check_sns_no_tags(r):
    if not r.get('tags'): return 'SNS topic has no tags'
def check_sns_no_subscriptions(r):
    if not r.get('subscription'): return 'SNS topic has no subscriptions configured'
def check_sns_http_subscription(r):
    for sub in (r.get('subscription') or []):
        if isinstance(sub, dict) and sub.get('protocol') == 'http': return 'SNS subscription uses HTTP - use HTTPS'
def check_sns_no_dlq(r):
    for sub in (r.get('subscription') or []):
        if isinstance(sub, dict) and not sub.get('redrive_policy'): return 'SNS subscription has no dead-letter queue'
def check_sns_fifo_deduplication(r):
    if r.get('fifo_topic') and not r.get('content_based_deduplication'): return 'SNS FIFO topic has no content-based deduplication'
def check_sns_no_filter_policy(r):
    for sub in (r.get('subscription') or []):
        if isinstance(sub, dict) and not sub.get('filter_policy'): return 'SNS subscription has no filter policy - all messages delivered'

SNS_RULES = [check_sns_no_encryption, check_sns_public_policy, check_sns_no_tags,
    check_sns_no_subscriptions, check_sns_http_subscription, check_sns_no_dlq,
    check_sns_fifo_deduplication, check_sns_no_filter_policy]

# ── SQS RULES ────────────────────────────────────────────────────────────────
def check_sqs_no_encryption(r):
    if not r.get('kms_master_key_id') and r.get('sqs_managed_sse_enabled', True) is not True: return 'SQS queue not encrypted'
def check_sqs_public_policy(r):
    if '"Principal": "*"' in str(r.get('policy', '') or ''): return 'SQS queue policy allows public access - CRITICAL RISK'
def check_sqs_no_dlq(r):
    if not r.get('redrive_policy') and not r.get('dead_letter_queue_arn'): return 'SQS queue has no dead-letter queue'
def check_sqs_no_tags(r):
    if not r.get('tags'): return 'SQS queue has no tags'
def check_sqs_visibility_timeout_low(r):
    vt = int(r.get('visibility_timeout_seconds', 30) or 30)
    if vt < 30: return f'SQS visibility timeout {vt}s may be too low - messages may reprocess'
def check_sqs_long_retention(r):
    ret = int(r.get('message_retention_seconds', 345600) or 345600)
    if ret > 1209600: return 'SQS message retention at maximum - review data lifecycle'
def check_sqs_no_kms_key(r):
    if r.get('kms_master_key_id') and r.get('kms_master_key_id') == 'alias/aws/sqs': return 'SQS using AWS-managed KMS key - use customer-managed key'
def check_sqs_fifo_no_dedup(r):
    if r.get('fifo_queue') and not r.get('content_based_deduplication'): return 'SQS FIFO queue has no content-based deduplication'
def check_sqs_max_message_size(r):
    if int(r.get('max_message_size', 262144) or 262144) == 262144: return 'SQS max message size at default 256KB - configure explicitly'

SQS_RULES = [check_sqs_no_encryption, check_sqs_public_policy, check_sqs_no_dlq,
    check_sqs_no_tags, check_sqs_visibility_timeout_low, check_sqs_long_retention,
    check_sqs_no_kms_key, check_sqs_fifo_no_dedup, check_sqs_max_message_size]

# ── ELASTICACHE RULES ────────────────────────────────────────────────────────
def check_ec_no_encryption_in_transit(r):
    if not r.get('transit_encryption_enabled', False): return 'ElastiCache transit encryption not enabled - HIGH RISK'
def check_ec_no_encryption_at_rest(r):
    if not r.get('at_rest_encryption_enabled', False): return 'ElastiCache at-rest encryption not enabled - HIGH RISK'
def check_ec_no_auth_token(r):
    if r.get('transit_encryption_enabled') and not r.get('auth_token'): return 'ElastiCache Redis has no auth token with TLS - HIGH RISK'
def check_ec_public_subnet(r):
    if r.get('publicly_accessible', False): return 'ElastiCache cluster is public - CRITICAL RISK'
def check_ec_no_multi_az(r):
    if not r.get('multi_az_enabled', False) and not r.get('automatic_failover_enabled', False): return 'ElastiCache has no multi-AZ or automatic failover'
def check_ec_no_version_upgrade(r):
    if not r.get('auto_minor_version_upgrade', True): return 'ElastiCache auto minor version upgrade disabled'
def check_ec_no_tags(r):
    if not r.get('tags'): return 'ElastiCache cluster has no tags'
def check_ec_no_snapshot_retention(r):
    if int(r.get('snapshot_retention_limit', 0) or 0) == 0: return 'ElastiCache snapshot retention not configured'
def check_ec_no_maintenance_window(r):
    if not r.get('maintenance_window'): return 'ElastiCache has no maintenance window'
def check_ec_no_subnet_group(r):
    if not r.get('subnet_group_name'): return 'ElastiCache has no subnet group - may not be in VPC'
def check_ec_no_notification_topic(r):
    if not r.get('notification_topic_arn'): return 'ElastiCache has no SNS notification configured'
def check_ec_no_parameter_group(r):
    pg = r.get('parameter_group_name', '')
    if not pg or pg.startswith('default.'): return 'ElastiCache using default parameter group - explicitly configure'

ELASTICACHE_RULES = [check_ec_no_encryption_in_transit, check_ec_no_encryption_at_rest, check_ec_no_auth_token,
    check_ec_public_subnet, check_ec_no_multi_az, check_ec_no_version_upgrade, check_ec_no_tags,
    check_ec_no_snapshot_retention, check_ec_no_maintenance_window, check_ec_no_subnet_group,
    check_ec_no_notification_topic, check_ec_no_parameter_group]
