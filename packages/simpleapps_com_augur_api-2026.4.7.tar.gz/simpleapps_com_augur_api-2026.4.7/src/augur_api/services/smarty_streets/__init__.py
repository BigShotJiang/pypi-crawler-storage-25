"""Service client for smarty_streets."""

from augur_api.services.smarty_streets.generated.client import SmartyStreetsClient

__all__ = ["SmartyStreetsClient"]
