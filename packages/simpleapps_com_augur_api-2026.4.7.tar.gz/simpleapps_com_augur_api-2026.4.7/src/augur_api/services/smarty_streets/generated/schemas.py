"""
Generated Pydantic schemas for smarty-streets service.
Source: shared/specs/smarty-streets.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import EdgeCacheParams


class UsLookupGetParams(EdgeCacheParams):
    """Params for GET /us/lookup."""

    address1: str
    address2: str
    city: str
    postal_code: str
    state: str
