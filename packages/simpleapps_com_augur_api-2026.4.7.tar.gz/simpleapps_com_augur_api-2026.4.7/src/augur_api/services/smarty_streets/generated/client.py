"""
Generated client for smarty-streets service.
Source: shared/specs/smarty-streets.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.smarty_streets.generated.schemas import (
        UsLookupGetParams,
    )


class UsResource(BaseResource):
    """Resource for /us endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/us")

    def get_lookup(self, params: UsLookupGetParams | None = None) -> BaseResponse[Any]:
        """GET /us/lookup."""
        response = self._get("/lookup", params=params)
        return BaseResponse[Any].model_validate(response)


class SmartyStreetsClient(BaseServiceClient):
    """Client for the smarty-streets service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._us: UsResource | None = None

    @property
    def us(self) -> UsResource:
        """Access us endpoints."""
        if self._us is None:
            self._us = UsResource(self._http)
        return self._us
