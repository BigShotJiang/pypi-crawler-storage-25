"""
Generated Pydantic schemas for shipping service.
Source: shared/specs/shipping.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations
