"""Generated code for shipping service."""
