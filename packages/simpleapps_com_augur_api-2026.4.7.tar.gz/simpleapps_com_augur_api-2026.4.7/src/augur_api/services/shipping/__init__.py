"""Service client for shipping."""

from augur_api.services.shipping.generated.client import ShippingClient

__all__ = ["ShippingClient"]
