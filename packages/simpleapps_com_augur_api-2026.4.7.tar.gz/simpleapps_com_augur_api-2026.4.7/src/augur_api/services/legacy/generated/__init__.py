"""Generated code for legacy service."""
