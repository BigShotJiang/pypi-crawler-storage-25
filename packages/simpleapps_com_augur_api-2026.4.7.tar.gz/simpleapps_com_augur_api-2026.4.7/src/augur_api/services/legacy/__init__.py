"""Service client for legacy."""

from augur_api.services.legacy.generated.client import LegacyClient

__all__ = ["LegacyClient"]
