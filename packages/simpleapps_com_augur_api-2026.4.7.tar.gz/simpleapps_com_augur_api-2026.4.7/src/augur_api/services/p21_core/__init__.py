"""Service client for p21_core."""

from augur_api.services.p21_core.generated.client import P21CoreClient

__all__ = ["P21CoreClient"]
