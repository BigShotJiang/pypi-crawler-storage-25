"""
Generated client for p21-core service.
Source: shared/specs/p21-core.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.p21_core.generated.schemas import (
        AddressCorpAddressListParams,
        AddressEnableGetParams,
        AddressListParams,
        CashDrawerListParams,
        CodeP21ListParams,
        CompanyGetParams,
        CompanyListParams,
        LocationGetParams,
        LocationListParams,
        PaymentTypesListParams,
    )


class AddressResource(BaseResource):
    """Resource for /address endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/address")

    def list(self, params: AddressListParams | None = None) -> BaseResponse[Any]:
        """GET /address."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get_refresh(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /address/refresh."""
        response = self._get("/refresh", params=options)
        return BaseResponse[Any].model_validate(response)

    def get(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /address/{id}."""
        response = self._get(f"/{id}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_corp_address(
        self,
        id: int,
        params: AddressCorpAddressListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /address/{id}/corp-address."""
        response = self._get(f"/{id}/corp-address", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_default(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /address/{id}/default."""
        response = self._get(f"/{id}/default", params=options)
        return BaseResponse[Any].model_validate(response)

    def get_enable(
        self,
        id: int,
        params: AddressEnableGetParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /address/{id}/enable."""
        response = self._get(f"/{id}/enable", params=params)
        return BaseResponse[Any].model_validate(response)


class CashDrawerResource(BaseResource):
    """Resource for /cash-drawer endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/cash-drawer")

    def list(self, params: CashDrawerListParams | None = None) -> BaseResponse[Any]:
        """GET /cash-drawer."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        cash_drawer_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /cash-drawer/{cashDrawerUid}."""
        response = self._get(f"/{cash_drawer_uid}", params=options)
        return BaseResponse[Any].model_validate(response)


class CodeP21Resource(BaseResource):
    """Resource for /code-p21 endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/code-p21")

    def list(self, params: CodeP21ListParams | None = None) -> BaseResponse[Any]:
        """GET /code-p21."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)


class CompanyResource(BaseResource):
    """Resource for /company endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/company")

    def list(self, params: CompanyListParams | None = None) -> BaseResponse[Any]:
        """GET /company."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(self, company_uid: int, params: CompanyGetParams | None = None) -> BaseResponse[Any]:
        """GET /company/{companyUid}."""
        response = self._get(f"/{company_uid}", params=params)
        return BaseResponse[Any].model_validate(response)


class LocationResource(BaseResource):
    """Resource for /location endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/location")

    def list(self, params: LocationListParams | None = None) -> BaseResponse[Any]:
        """GET /location."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(self, location_id: float, params: LocationGetParams | None = None) -> BaseResponse[Any]:
        """GET /location/{locationId}."""
        response = self._get(f"/{location_id}", params=params)
        return BaseResponse[Any].model_validate(response)


class PaymentTypesResource(BaseResource):
    """Resource for /payment-types endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/payment-types")

    def list(self, params: PaymentTypesListParams | None = None) -> BaseResponse[Any]:
        """GET /payment-types."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)


class P21CoreClient(BaseServiceClient):
    """Client for the p21-core service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._address: AddressResource | None = None
        self._cash_drawer: CashDrawerResource | None = None
        self._code_p21: CodeP21Resource | None = None
        self._company: CompanyResource | None = None
        self._location: LocationResource | None = None
        self._payment_types: PaymentTypesResource | None = None

    @property
    def address(self) -> AddressResource:
        """Access address endpoints."""
        if self._address is None:
            self._address = AddressResource(self._http)
        return self._address

    @property
    def cash_drawer(self) -> CashDrawerResource:
        """Access cashDrawer endpoints."""
        if self._cash_drawer is None:
            self._cash_drawer = CashDrawerResource(self._http)
        return self._cash_drawer

    @property
    def code_p21(self) -> CodeP21Resource:
        """Access codeP21 endpoints."""
        if self._code_p21 is None:
            self._code_p21 = CodeP21Resource(self._http)
        return self._code_p21

    @property
    def company(self) -> CompanyResource:
        """Access company endpoints."""
        if self._company is None:
            self._company = CompanyResource(self._http)
        return self._company

    @property
    def location(self) -> LocationResource:
        """Access location endpoints."""
        if self._location is None:
            self._location = LocationResource(self._http)
        return self._location

    @property
    def payment_types(self) -> PaymentTypesResource:
        """Access paymentTypes endpoints."""
        if self._payment_types is None:
            self._payment_types = PaymentTypesResource(self._http)
        return self._payment_types
