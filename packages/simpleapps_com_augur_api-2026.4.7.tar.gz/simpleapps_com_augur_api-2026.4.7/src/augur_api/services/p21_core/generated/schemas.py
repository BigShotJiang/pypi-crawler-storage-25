"""
Generated Pydantic schemas for p21-core service.
Source: shared/specs/p21-core.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


class AddressListParams(EdgeCacheParams):
    """Params for GET /address."""

    carrier_flag: str | None = None
    default_cd: int | None = None
    enabled_cd: int | None = None
    limit: int | None = None
    offset: int | None = None
    status_cd: int | None = None


AddressRefreshGetParams = EdgeCacheParams


AddressGetParams = EdgeCacheParams


class AddressCorpAddressListParams(EdgeCacheParams):
    """Params for GET /address/{id}/corp-address."""

    limit: int | None = None
    offset: int | None = None
    q: str | None = None


AddressDefaultListParams = EdgeCacheParams


class AddressEnableGetParams(EdgeCacheParams):
    """Params for GET /address/{id}/enable."""

    enabled_cd: int | None = None


class CashDrawerListParams(EdgeCacheParams):
    """Params for GET /cash-drawer."""

    company_id: str | None = None
    drawer_open: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


CashDrawerGetParams = EdgeCacheParams


class CodeP21ListParams(EdgeCacheParams):
    """Params for GET /code-p21."""

    code_no_list: str | None = None
    limit: int | None = None
    offset: int | None = None
    q: str


class CompanyListParams(EdgeCacheParams):
    """Params for GET /company."""

    company_id: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None


class CompanyGetParams(EdgeCacheParams):
    """Params for GET /company/{companyUid}."""

    company_id: str | None = None


class LocationListParams(EdgeCacheParams):
    """Params for GET /location."""

    delete_flag: str | None = None
    include_address: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None


class LocationGetParams(EdgeCacheParams):
    """Params for GET /location/{locationId}."""

    include_address: str | None = None


class PaymentTypesListParams(EdgeCacheParams):
    """Params for GET /payment-types."""

    limit: int | None = None
    offset: int | None = None


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class CashDrawerData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    cash_drawer_id: str | None = None
    company_id: str | None = None
    cash_drawer_description: str | None = None
    current_sequence_no: float | None = None
    opening_balance: float | None = None
    withdrawals: float | None = None
    deposits: float | None = None
    current_balance: float | None = None
    drawer_open: str | None = None
    bank_no: float | None = None
    cash_on_hand_account_number: str | None = None
    delete_flag: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    last_maintained_by: str | None = None
    cash_card_load: float | None = None
    cash_drawer_uid: int | None = None
    loc_id_for_branch_conflict: float | None = None
    default_close_branch_id: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None


class CodeP21Data(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    code_uid: int | None = None
    code_no: int | None = None
    language_id: str | None = None
    code_description: str | None = None
    row_status_flag: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    last_maintained_by: str | None = None
    code_sub_description: str | None = None
    update_cd: int | None = None


class CompanyData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    company_uid: int | None = None
    company_id: str | None = None
    company_name: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    delete_flag: str | None = None
    update_cd: int | None = None
    last_maintained_by: str | None = None
    address_id: float | None = None
    default_sales_location_id: float | None = None
    freight_code_uid: int | None = None
    ups_account_no: str | None = None
    default_source_price_cd: int | None = None
    default_multiplier: float | None = None


class LocationData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    location_id: float | None = None
    company_id: str | None = None
    default_branch_id: str | None = None
    delete_flag: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    last_maintained_by: str | None = None
    location_name: str | None = None
    lot_bin_integration: str | None = None
    fedex_loc_acct_no: str | None = None
    fedex_meter_no: str | None = None
    ups_account_no: str | None = None
    ups_pickup_type_cd: int | None = None
    ups_customer_type_cd: int | None = None
    ups_olt_access_key: str | None = None
    ups_olt_password: str | None = None
    ups_olt_user_id: str | None = None
    distribution_center: str | None = None
    update_cd: int | None = None
