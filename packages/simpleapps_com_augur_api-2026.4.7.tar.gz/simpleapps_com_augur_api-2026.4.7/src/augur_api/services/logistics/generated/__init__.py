"""Generated code for logistics service."""
