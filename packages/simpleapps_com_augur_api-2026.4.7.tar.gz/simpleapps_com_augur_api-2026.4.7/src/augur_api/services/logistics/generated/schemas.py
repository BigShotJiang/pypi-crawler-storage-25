"""
Generated Pydantic schemas for logistics service.
Source: shared/specs/logistics.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import EdgeCacheParams


class ShipviaRatesListParams(EdgeCacheParams):
    """Params for GET /shipvia/rates."""

    carriers: str | None = None
    dimension_unit: str | None = None
    from_city: str | None = None
    from_country: str | None = None
    from_postal_code: str
    from_state: str | None = None
    location_id: int
    package_height: float | None = None
    package_length: float | None = None
    package_width: float | None = None
    residential: bool | None = None
    service_type: str | None = None
    to_city: str | None = None
    to_country: str | None = None
    to_postal_code: str
    to_state: str | None = None
    total_weight: float
    weight_unit: str


class ShipviaRatesLtlListParams(EdgeCacheParams):
    """Params for GET /shipvia/rates/ltl."""

    carriers: str | None = None
    commodity_class: str
    commodity_description: str
    delivery_instructions: str | None = None
    dimension_unit: str | None = None
    from_city: str | None = None
    from_country: str | None = None
    from_postal_code: str
    from_state: str | None = None
    is_haz_mat: bool | None = None
    location_id: int
    package_height: float | None = None
    package_length: float | None = None
    package_width: float | None = None
    packaging_type: str
    pickup_instructions: str | None = None
    quantity: int | None = None
    to_city: str | None = None
    to_country: str | None = None
    to_postal_code: str
    to_state: str | None = None
    total_weight: float
    weight_unit: str


class SpeedshipFreightListParams(EdgeCacheParams):
    """Params for GET /speedship/freight."""

    delivery_instructions: str | None = None
    dimension_unit: str
    from_address_line: str
    from_city: str
    from_company_name: str
    from_country_code: str
    from_first_name: str
    from_last_name: str
    from_phone: str
    from_postal_code: str
    from_state: str
    handling_charge: float | None = None
    handling_charge_unit: str | None = None
    international: bool | None = None
    package_height: float | None = None
    package_length: float
    package_width: float
    pickup_instructions: str | None = None
    product_type: str
    quantity: float
    response_format: str
    to_address_line: str
    to_city: str
    to_company_name: str
    to_country_code: str
    to_first_name: str
    to_last_name: str
    to_phone: str
    to_postal_code: str
    to_region: str
    total_weight: float
    weight_unit: str


class UpsRatesListParams(EdgeCacheParams):
    """Params for GET /ups/rates."""

    from_address1: str
    from_city: str
    from_country_code: str | None = None
    from_postal_code: str
    from_state_province_code: str
    to_address1: str
    to_city: str
    to_country_code: str | None = None
    to_postal_code: str
    to_state_province_code: str
    weight: int
