"""Service client for logistics."""

from augur_api.services.logistics.generated.client import LogisticsClient

__all__ = ["LogisticsClient"]
