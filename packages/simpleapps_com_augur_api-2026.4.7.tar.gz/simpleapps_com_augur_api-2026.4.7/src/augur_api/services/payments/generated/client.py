"""
Generated client for payments service.
Source: shared/specs/payments.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.payments.generated.schemas import (
        MonerisPreAuthCompleteListParams,
        MonerisPreAuthListParams,
        UnifiedAccountQueryListParams,
        UnifiedBillingUpdateListParams,
        UnifiedCardInfoListParams,
        UnifiedSurchargeListParams,
        UnifiedTransactionSetupListParams,
        UnifiedValidateListParams,
    )


class ElementResource(BaseResource):
    """Resource for /element endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/element")

    def create_payment(self, data: Any = None) -> BaseResponse[Any]:
        """POST /element/payment."""
        response = self._post("/payment", data=data)
        return BaseResponse[Any].model_validate(response)


class MonerisResource(BaseResource):
    """Resource for /moneris endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/moneris")

    def list_pre_auth(self, params: MonerisPreAuthListParams | None = None) -> BaseResponse[Any]:
        """GET /moneris/pre-auth."""
        response = self._get("/pre-auth", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_pre_auth_complete(
        self,
        params: MonerisPreAuthCompleteListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /moneris/pre-auth-complete."""
        response = self._get("/pre-auth-complete", params=params)
        return BaseResponse[Any].model_validate(response)


class PaytraceResource(BaseResource):
    """Resource for /paytrace endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/paytrace")

    def create_authorization(self, data: Any = None) -> BaseResponse[Any]:
        """POST /paytrace/authorization."""
        response = self._post("/authorization", data=data)
        return BaseResponse[Any].model_validate(response)

    def create_capture(self, data: Any = None) -> BaseResponse[Any]:
        """POST /paytrace/capture."""
        response = self._post("/capture", data=data)
        return BaseResponse[Any].model_validate(response)

    def create_refund(self, data: Any = None) -> BaseResponse[Any]:
        """POST /paytrace/refund."""
        response = self._post("/refund", data=data)
        return BaseResponse[Any].model_validate(response)

    def create_sale(self, data: Any = None) -> BaseResponse[Any]:
        """POST /paytrace/sale."""
        response = self._post("/sale", data=data)
        return BaseResponse[Any].model_validate(response)

    def create_void(self, data: Any = None) -> BaseResponse[Any]:
        """POST /paytrace/void."""
        response = self._post("/void", data=data)
        return BaseResponse[Any].model_validate(response)


class UnifiedResource(BaseResource):
    """Resource for /unified endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/unified")

    def list_account_query(
        self,
        params: UnifiedAccountQueryListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /unified/account-query."""
        response = self._get("/account-query", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_billing_update(
        self,
        params: UnifiedBillingUpdateListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /unified/billing-update."""
        response = self._get("/billing-update", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_card_info(self, params: UnifiedCardInfoListParams | None = None) -> BaseResponse[Any]:
        """GET /unified/card-info."""
        response = self._get("/card-info", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_surcharge(self, params: UnifiedSurchargeListParams | None = None) -> BaseResponse[Any]:
        """GET /unified/surcharge."""
        response = self._get("/surcharge", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_transaction_setup(
        self,
        params: UnifiedTransactionSetupListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /unified/transaction-setup."""
        response = self._get("/transaction-setup", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_validate(self, params: UnifiedValidateListParams | None = None) -> BaseResponse[Any]:
        """GET /unified/validate."""
        response = self._get("/validate", params=params)
        return BaseResponse[Any].model_validate(response)


class PaymentsClient(BaseServiceClient):
    """Client for the payments service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._element: ElementResource | None = None
        self._moneris: MonerisResource | None = None
        self._paytrace: PaytraceResource | None = None
        self._unified: UnifiedResource | None = None

    @property
    def element(self) -> ElementResource:
        """Access element endpoints."""
        if self._element is None:
            self._element = ElementResource(self._http)
        return self._element

    @property
    def moneris(self) -> MonerisResource:
        """Access moneris endpoints."""
        if self._moneris is None:
            self._moneris = MonerisResource(self._http)
        return self._moneris

    @property
    def paytrace(self) -> PaytraceResource:
        """Access paytrace endpoints."""
        if self._paytrace is None:
            self._paytrace = PaytraceResource(self._http)
        return self._paytrace

    @property
    def unified(self) -> UnifiedResource:
        """Access unified endpoints."""
        if self._unified is None:
            self._unified = UnifiedResource(self._http)
        return self._unified
