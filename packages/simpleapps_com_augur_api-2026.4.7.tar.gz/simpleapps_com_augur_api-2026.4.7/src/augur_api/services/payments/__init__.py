"""Service client for payments."""

from augur_api.services.payments.generated.client import PaymentsClient

__all__ = ["PaymentsClient"]
