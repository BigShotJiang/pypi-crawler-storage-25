"""Generated code for items service."""
