"""Service client for items."""

from augur_api.services.items.generated.client import ItemsClient

__all__ = ["ItemsClient"]
