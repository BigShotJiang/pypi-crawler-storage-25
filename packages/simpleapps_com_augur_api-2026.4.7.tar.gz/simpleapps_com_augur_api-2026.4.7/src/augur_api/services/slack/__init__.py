"""Service client for slack."""

from augur_api.services.slack.generated.client import SlackClient

__all__ = ["SlackClient"]
