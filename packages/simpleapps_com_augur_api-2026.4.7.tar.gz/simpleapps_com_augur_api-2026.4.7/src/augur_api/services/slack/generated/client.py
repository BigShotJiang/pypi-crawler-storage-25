"""
Generated client for slack service.
Source: shared/specs/slack.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient


class WebHookResource(BaseResource):
    """Resource for /web-hook endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/web-hook")

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /web-hook."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def get_refresh(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /web-hook/refresh."""
        response = self._get("/refresh", params=options)
        return BaseResponse[Any].model_validate(response)


class SlackClient(BaseServiceClient):
    """Client for the slack service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._web_hook: WebHookResource | None = None

    @property
    def web_hook(self) -> WebHookResource:
        """Access webHook endpoints."""
        if self._web_hook is None:
            self._web_hook = WebHookResource(self._http)
        return self._web_hook
