"""Generated code for slack service."""
