"""
Generated Pydantic schemas for slack service.
Source: shared/specs/slack.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import EdgeCacheParams

WebHookRefreshGetParams = EdgeCacheParams
