"""
Generated Pydantic schemas for agr-info service.
Source: shared/specs/agr-info.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams

ContextGetParams = EdgeCacheParams


class MicroservicesListParams(EdgeCacheParams):
    """Params for GET /microservices."""

    limit: int | None = None
    offset: int | None = None
    status_cd: int | None = None


MicroservicesGetParams = EdgeCacheParams


OllamaTagsListParams = EdgeCacheParams


RubricsListParams = EdgeCacheParams


RubricsGetParams = EdgeCacheParams


WorkflowsListParams = EdgeCacheParams


WorkflowsGetParams = EdgeCacheParams


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class MicroservicesData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    microservices_uid: int | None = None
    name: str | None = None
    id: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None


class RubricsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    rubrics_uid: int | None = None
    title: str | None = None
    id: str | None = None
    content: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None


class WorkflowsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    workflows_uid: int | None = None
    workflows_id: str | None = None
    title: str | None = None
    description: str | None = None
    services: str | None = None
    workflow: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
