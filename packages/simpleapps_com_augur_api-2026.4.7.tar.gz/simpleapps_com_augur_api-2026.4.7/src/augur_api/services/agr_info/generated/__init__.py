"""Generated code for agr-info service."""
