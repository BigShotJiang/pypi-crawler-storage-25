"""Service client for agr_info."""

from augur_api.services.agr_info.generated.client import AgrInfoClient

__all__ = ["AgrInfoClient"]
