"""Service client for brand_folder."""

from augur_api.services.brand_folder.generated.client import BrandFolderClient

__all__ = ["BrandFolderClient"]
