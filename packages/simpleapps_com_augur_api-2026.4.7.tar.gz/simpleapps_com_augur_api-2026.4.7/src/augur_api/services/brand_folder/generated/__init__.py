"""Generated code for brand-folder service."""
