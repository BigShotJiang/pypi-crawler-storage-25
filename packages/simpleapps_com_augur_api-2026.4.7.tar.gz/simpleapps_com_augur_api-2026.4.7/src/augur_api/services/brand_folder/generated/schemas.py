"""
Generated Pydantic schemas for brand-folder service.
Source: shared/specs/brand-folder.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations
