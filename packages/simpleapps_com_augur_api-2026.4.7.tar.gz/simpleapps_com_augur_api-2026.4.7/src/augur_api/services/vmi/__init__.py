"""Service client for vmi."""

from augur_api.services.vmi.generated.client import VmiClient

__all__ = ["VmiClient"]
