"""
Generated Pydantic schemas for vmi service.
Source: shared/specs/vmi.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


class DistributorsListParams(EdgeCacheParams):
    """Params for GET /distributors."""

    customer_id: int
    limit: int | None = None
    offset: int | None = None
    status_cd: int | None = None


DistributorsGetParams = EdgeCacheParams


class InvProfileHdrListParams(EdgeCacheParams):
    """Params for GET /inv-profile-hdr."""

    customer_id: int
    limit: int | None = None
    offset: int | None = None


InvProfileHdrGetParams = EdgeCacheParams


class InvProfileHdrInvProfileLineListParams(EdgeCacheParams):
    """Params for GET /inv-profile-hdr/{invProfileHdrUid}/inv-profile-line."""

    limit: int | None = None
    offset: int | None = None
    q: str | None = None
    status_cd: int | None = None


InvProfileHdrInvProfileLineGetParams = EdgeCacheParams


class ProductsListParams(EdgeCacheParams):
    """Params for GET /products."""

    customer_id: int
    distributors_uid: int
    limit: int | None = None
    offset: int | None = None
    prefix: str | None = None
    q: str | None = None
    status_cd: int | None = None


class ProductsFindListParams(EdgeCacheParams):
    """Params for GET /products/find."""

    customer_id: int
    prefix: str | None = None


ProductsGetParams = EdgeCacheParams


class RestockHdrListParams(EdgeCacheParams):
    """Params for GET /restock-hdr."""

    distributors_uid: int | None = None
    limit: int | None = None
    offset: int | None = None
    warehouse_uid: int | None = None


RestockHdrGetParams = EdgeCacheParams


class SectionsListParams(EdgeCacheParams):
    """Params for GET /sections."""

    customer_id: int
    limit: int | None = None
    offset: int | None = None
    status_cd: int | None = None


SectionsGetParams = EdgeCacheParams


class WarehouseListParams(EdgeCacheParams):
    """Params for GET /warehouse."""

    customer_id: int
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None
    users_id: int | None = None


WarehouseGetParams = EdgeCacheParams


class WarehouseAvailabilityListParams(EdgeCacheParams):
    """Params for GET /warehouse/{warehouseUid}/availability."""

    q: str


class WarehouseReplenishListParams(EdgeCacheParams):
    """Params for GET /warehouse/{warehouseUid}/replenish."""

    distributors_uid: int | None = None


class WarehouseUsersListParams(EdgeCacheParams):
    """Params for GET /warehouse/{warehouseUid}/users."""

    limit: int | None = None
    offset: int | None = None
    status_cd_list: str | None = None


class WarehouseUsersCreateParams(EdgeCacheParams):
    """Params for POST /warehouse/{warehouseUid}/users."""

    make_primary_user: str | None = None


WarehouseUsersGetParams = EdgeCacheParams


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class DistributorsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    distributors_uid: int | None = None
    customer_id: float | None = None
    distributors_id: str | None = None
    distributors_name: str | None = None
    distributors_desc: str | None = None
    distributors_email: str | None = None
    distributors_account: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None


class DistributorsProductsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    products_uid: int | None = None
    distributors_uid: int | None = None
    products_id: str | None = None
    products_desc: str | None = None
    default_selling_unit: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    upc_or_ean_id: str | None = None
    image_url: str | None = None
    part_number: str | None = None


class InvProfileHdrData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    inv_profile_hdr_uid: int | None = None
    inv_profile_hdr_id: str | None = None
    inv_profile_hdr_desc: str | None = None
    customer_id: float | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None


class InvProfileHdrInvProfileLineData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    inv_profile_line_uid: int | None = None
    inv_profile_hdr_uid: int | None = None
    inv_mast_uid: int | None = None
    inv_profile_line_type: str | None = None
    inv_profile_hdr_min_qty: float | None = None
    inv_profile_hdr_max_qty: float | None = None
    inv_profile_hdr_reorder_qty: float | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    sections_uid: int | None = None
    keywords: str | None = None


class RestockHdrData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    restock_hdr_uid: int | None = None
    warehouse_uid: int | None = None
    distributors_uid: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    json_data: str | None = None
    process_state: str | None = None
    po_no: str | None = None
    users_id: int | None = None
    customer_id: float | None = None
    contact_id: str | None = None
    delivery_instructions: str | None = None


class SectionsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    sections_uid: int | None = None
    customer_id: float | None = None
    sections_id: str | None = None
    sections_name: str | None = None
    sections_desc: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None


class WarehouseData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    warehouse_uid: int | None = None
    warehouse_id: str | None = None
    warehouse_name: str | None = None
    warehouse_desc: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    customer_id: float | None = None
    inv_profile_hdr_uid: int | None = None
