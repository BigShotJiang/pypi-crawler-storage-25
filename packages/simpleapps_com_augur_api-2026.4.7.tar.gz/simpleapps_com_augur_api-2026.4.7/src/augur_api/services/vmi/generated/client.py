"""
Generated client for vmi service.
Source: shared/specs/vmi.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.vmi.generated.schemas import (
        DistributorsListParams,
        InvProfileHdrInvProfileLineListParams,
        InvProfileHdrListParams,
        ProductsFindListParams,
        ProductsListParams,
        RestockHdrListParams,
        SectionsListParams,
        WarehouseAvailabilityListParams,
        WarehouseListParams,
        WarehouseReplenishListParams,
        WarehouseUsersListParams,
    )


class DistributorsResource(BaseResource):
    """Resource for /distributors endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/distributors")

    def list(self, params: DistributorsListParams | None = None) -> BaseResponse[Any]:
        """GET /distributors."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /distributors."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, distributors_uid: int) -> BaseResponse[Any]:
        """DELETE /distributors/{distributorsUid}."""
        response = self._delete(f"/{distributors_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        distributors_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /distributors/{distributorsUid}."""
        response = self._get(f"/{distributors_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, distributors_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /distributors/{distributorsUid}."""
        response = self._put(f"/{distributors_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def update_enable(self, distributors_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /distributors/{distributorsUid}/enable."""
        response = self._put(f"/{distributors_uid}/enable", data=data)
        return BaseResponse[Any].model_validate(response)

    def create_products(self, distributors_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /distributors/{distributorsUid}/products."""
        response = self._post(f"/{distributors_uid}/products", data=data)
        return BaseResponse[Any].model_validate(response)


class InvProfileHdrResource(BaseResource):
    """Resource for /inv-profile-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-profile-hdr")

    def list(self, params: InvProfileHdrListParams | None = None) -> BaseResponse[Any]:
        """GET /inv-profile-hdr."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /inv-profile-hdr."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def create_upload(self, customer_id: int, data: Any = None) -> BaseResponse[Any]:
        """POST /inv-profile-hdr/{customerId}/upload."""
        response = self._post(f"/{customer_id}/upload", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, inv_profile_hdr_uid: int) -> BaseResponse[Any]:
        """DELETE /inv-profile-hdr/{invProfileHdrUid}."""
        response = self._delete(f"/{inv_profile_hdr_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        inv_profile_hdr_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-profile-hdr/{invProfileHdrUid}."""
        response = self._get(f"/{inv_profile_hdr_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, inv_profile_hdr_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /inv-profile-hdr/{invProfileHdrUid}."""
        response = self._put(f"/{inv_profile_hdr_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_inv_profile_line(
        self,
        inv_profile_hdr_uid: int,
        params: InvProfileHdrInvProfileLineListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-profile-hdr/{invProfileHdrUid}/inv-profile-line."""
        response = self._get(f"/{inv_profile_hdr_uid}/inv-profile-line", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_inv_profile_line(
        self,
        inv_profile_hdr_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """POST /inv-profile-hdr/{invProfileHdrUid}/inv-profile-line."""
        response = self._post(f"/{inv_profile_hdr_uid}/inv-profile-line", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_inv_profile_line(
        self,
        inv_profile_hdr_uid: int,
        inv_profile_line_uid: int,
    ) -> BaseResponse[Any]:
        """DELETE /inv-profile-hdr/{invProfileHdrUid}/inv-profile-line/{invProfileLineUid}."""
        response = self._delete(f"/{inv_profile_hdr_uid}/inv-profile-line/{inv_profile_line_uid}")
        return BaseResponse[Any].model_validate(response)

    def get_inv_profile_line(
        self,
        inv_profile_hdr_uid: int,
        inv_profile_line_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-profile-hdr/{invProfileHdrUid}/inv-profile-line/{invProfileLineUid}."""
        response = self._get(
            f"/{inv_profile_hdr_uid}/inv-profile-line/{inv_profile_line_uid}",
            params=options,
        )
        return BaseResponse[Any].model_validate(response)

    def update_inv_profile_line(
        self,
        inv_profile_hdr_uid: int,
        inv_profile_line_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """PUT /inv-profile-hdr/{invProfileHdrUid}/inv-profile-line/{invProfileLineUid}."""
        response = self._put(
            f"/{inv_profile_hdr_uid}/inv-profile-line/{inv_profile_line_uid}",
            data=data,
        )
        return BaseResponse[Any].model_validate(response)


class ProductsResource(BaseResource):
    """Resource for /products endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/products")

    def list(self, params: ProductsListParams | None = None) -> BaseResponse[Any]:
        """GET /products."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def list_find(self, params: ProductsFindListParams | None = None) -> BaseResponse[Any]:
        """GET /products/find."""
        response = self._get("/find", params=params)
        return BaseResponse[Any].model_validate(response)

    def delete(self, products_uid: int) -> BaseResponse[Any]:
        """DELETE /products/{productsUid}."""
        response = self._delete(f"/{products_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, products_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /products/{productsUid}."""
        response = self._get(f"/{products_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, products_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /products/{productsUid}."""
        response = self._put(f"/{products_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def update_enable(self, products_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /products/{productsUid}/enable."""
        response = self._put(f"/{products_uid}/enable", data=data)
        return BaseResponse[Any].model_validate(response)


class RestockHdrResource(BaseResource):
    """Resource for /restock-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/restock-hdr")

    def list(self, params: RestockHdrListParams | None = None) -> BaseResponse[Any]:
        """GET /restock-hdr."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /restock-hdr."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, restock_hdr_uid: int) -> BaseResponse[Any]:
        """DELETE /restock-hdr/{restockHdrUid}."""
        response = self._delete(f"/{restock_hdr_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        restock_hdr_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /restock-hdr/{restockHdrUid}."""
        response = self._get(f"/{restock_hdr_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, restock_hdr_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /restock-hdr/{restockHdrUid}."""
        response = self._put(f"/{restock_hdr_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class SectionsResource(BaseResource):
    """Resource for /sections endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/sections")

    def list(self, params: SectionsListParams | None = None) -> BaseResponse[Any]:
        """GET /sections."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /sections."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, sections_uid: int) -> BaseResponse[Any]:
        """DELETE /sections/{sectionsUid}."""
        response = self._delete(f"/{sections_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, sections_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /sections/{sectionsUid}."""
        response = self._get(f"/{sections_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, sections_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /sections/{sectionsUid}."""
        response = self._put(f"/{sections_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def update_enable(self, sections_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /sections/{sectionsUid}/enable."""
        response = self._put(f"/{sections_uid}/enable", data=data)
        return BaseResponse[Any].model_validate(response)


class WarehouseResource(BaseResource):
    """Resource for /warehouse endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/warehouse")

    def list(self, params: WarehouseListParams | None = None) -> BaseResponse[Any]:
        """GET /warehouse."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /warehouse."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, warehouse_uid: int) -> BaseResponse[Any]:
        """DELETE /warehouse/{warehouseUid}."""
        response = self._delete(f"/{warehouse_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, warehouse_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /warehouse/{warehouseUid}."""
        response = self._get(f"/{warehouse_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, warehouse_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /warehouse/{warehouseUid}."""
        response = self._put(f"/{warehouse_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def create_adjust(self, warehouse_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /warehouse/{warehouseUid}/adjust."""
        response = self._post(f"/{warehouse_uid}/adjust", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_availability(
        self,
        warehouse_uid: int,
        params: WarehouseAvailabilityListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /warehouse/{warehouseUid}/availability."""
        response = self._get(f"/{warehouse_uid}/availability", params=params)
        return BaseResponse[Any].model_validate(response)

    def update_enable(self, warehouse_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /warehouse/{warehouseUid}/enable."""
        response = self._put(f"/{warehouse_uid}/enable", data=data)
        return BaseResponse[Any].model_validate(response)

    def create_receive(self, warehouse_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /warehouse/{warehouseUid}/receive."""
        response = self._post(f"/{warehouse_uid}/receive", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_replenish(
        self,
        warehouse_uid: int,
        params: WarehouseReplenishListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /warehouse/{warehouseUid}/replenish."""
        response = self._get(f"/{warehouse_uid}/replenish", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_replenish(self, warehouse_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /warehouse/{warehouseUid}/replenish."""
        response = self._post(f"/{warehouse_uid}/replenish", data=data)
        return BaseResponse[Any].model_validate(response)

    def create_transfer(self, warehouse_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /warehouse/{warehouseUid}/transfer."""
        response = self._post(f"/{warehouse_uid}/transfer", data=data)
        return BaseResponse[Any].model_validate(response)

    def create_usage(self, warehouse_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /warehouse/{warehouseUid}/usage."""
        response = self._post(f"/{warehouse_uid}/usage", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_users(
        self,
        warehouse_uid: int,
        params: WarehouseUsersListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /warehouse/{warehouseUid}/users."""
        response = self._get(f"/{warehouse_uid}/users", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_users(self, warehouse_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /warehouse/{warehouseUid}/users."""
        response = self._post(f"/{warehouse_uid}/users", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_users(self, warehouse_uid: int, users_id: int) -> BaseResponse[Any]:
        """DELETE /warehouse/{warehouseUid}/users/{usersId}."""
        response = self._delete(f"/{warehouse_uid}/users/{users_id}")
        return BaseResponse[Any].model_validate(response)

    def get_users(
        self,
        warehouse_uid: int,
        users_id: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /warehouse/{warehouseUid}/users/{usersId}."""
        response = self._get(f"/{warehouse_uid}/users/{users_id}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update_users(
        self,
        warehouse_uid: int,
        users_id: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """PUT /warehouse/{warehouseUid}/users/{usersId}."""
        response = self._put(f"/{warehouse_uid}/users/{users_id}", data=data)
        return BaseResponse[Any].model_validate(response)


class VmiClient(BaseServiceClient):
    """Client for the vmi service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._distributors: DistributorsResource | None = None
        self._inv_profile_hdr: InvProfileHdrResource | None = None
        self._products: ProductsResource | None = None
        self._restock_hdr: RestockHdrResource | None = None
        self._sections: SectionsResource | None = None
        self._warehouse: WarehouseResource | None = None

    @property
    def distributors(self) -> DistributorsResource:
        """Access distributors endpoints."""
        if self._distributors is None:
            self._distributors = DistributorsResource(self._http)
        return self._distributors

    @property
    def inv_profile_hdr(self) -> InvProfileHdrResource:
        """Access invProfileHdr endpoints."""
        if self._inv_profile_hdr is None:
            self._inv_profile_hdr = InvProfileHdrResource(self._http)
        return self._inv_profile_hdr

    @property
    def products(self) -> ProductsResource:
        """Access products endpoints."""
        if self._products is None:
            self._products = ProductsResource(self._http)
        return self._products

    @property
    def restock_hdr(self) -> RestockHdrResource:
        """Access restockHdr endpoints."""
        if self._restock_hdr is None:
            self._restock_hdr = RestockHdrResource(self._http)
        return self._restock_hdr

    @property
    def sections(self) -> SectionsResource:
        """Access sections endpoints."""
        if self._sections is None:
            self._sections = SectionsResource(self._http)
        return self._sections

    @property
    def warehouse(self) -> WarehouseResource:
        """Access warehouse endpoints."""
        if self._warehouse is None:
            self._warehouse = WarehouseResource(self._http)
        return self._warehouse
