"""Generated code for orders service."""
