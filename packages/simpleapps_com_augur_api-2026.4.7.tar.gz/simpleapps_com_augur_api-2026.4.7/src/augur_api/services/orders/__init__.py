"""Service client for orders."""

from augur_api.services.orders.generated.client import OrdersClient

__all__ = ["OrdersClient"]
