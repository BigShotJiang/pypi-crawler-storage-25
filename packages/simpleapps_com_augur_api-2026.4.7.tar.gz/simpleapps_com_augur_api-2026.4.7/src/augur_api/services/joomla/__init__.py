"""Service client for joomla."""

from augur_api.services.joomla.generated.client import JoomlaClient

__all__ = ["JoomlaClient"]
