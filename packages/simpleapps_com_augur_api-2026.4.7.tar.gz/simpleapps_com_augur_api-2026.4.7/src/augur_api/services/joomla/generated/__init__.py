"""Generated code for joomla service."""
