"""
Generated client for joomla service.
Source: shared/specs/joomla.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.joomla.generated.schemas import (
        CategoriesListParams,
        ContentDocListParams,
        ContentGetParams,
        ContentListParams,
        MenuDocListParams,
        MenuListParams,
        TagsListParams,
        UsergroupsListParams,
        UsersDocListParams,
        UsersGroupsListParams,
        UsersTrinityListParams,
    )


class CategoriesResource(BaseResource):
    """Resource for /categories endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/categories")

    def list(self, params: CategoriesListParams | None = None) -> BaseResponse[Any]:
        """GET /categories."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /categories/{id}."""
        response = self._get(f"/{id}", params=options)
        return BaseResponse[Any].model_validate(response)


class ContentResource(BaseResource):
    """Resource for /content endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/content")

    def list(self, params: ContentListParams | None = None) -> BaseResponse[Any]:
        """GET /content."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(self, id: int, params: ContentGetParams | None = None) -> BaseResponse[Any]:
        """GET /content/{id}."""
        response = self._get(f"/{id}", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_doc(self, id: int, params: ContentDocListParams | None = None) -> BaseResponse[Any]:
        """GET /content/{id}/doc."""
        response = self._get(f"/{id}/doc", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_doc(self, id: int, params: ContentDocListParams | None = None) -> BaseResponse[Any]:
        """Alias for list_doc — GET /content/{id}/doc."""
        return self.list_doc(id, params=params)


class MenuResource(BaseResource):
    """Resource for /menu endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/menu")

    def list(self, params: MenuListParams | None = None) -> BaseResponse[Any]:
        """GET /menu."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def list_doc(self, id: int, params: MenuDocListParams | None = None) -> BaseResponse[Any]:
        """GET /menu/{id}/doc."""
        response = self._get(f"/{id}/doc", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_doc(self, id: int, params: MenuDocListParams | None = None) -> BaseResponse[Any]:
        """Alias for list_doc — GET /menu/{id}/doc."""
        return self.list_doc(id, params=params)


class TagsResource(BaseResource):
    """Resource for /tags endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/tags")

    def list(self, params: TagsListParams | None = None) -> BaseResponse[Any]:
        """GET /tags."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)


class UsergroupsResource(BaseResource):
    """Resource for /usergroups endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/usergroups")

    def list(self, params: UsergroupsListParams | None = None) -> BaseResponse[Any]:
        """GET /usergroups."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)


class UsersResource(BaseResource):
    """Resource for /users endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/users")

    def list(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /users."""
        response = self._get(params=options)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /users."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def create_verify_password(self, data: Any = None) -> BaseResponse[Any]:
        """POST /users/verify-password."""
        response = self._post("/verify-password", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, id: int) -> BaseResponse[Any]:
        """DELETE /users/{id}."""
        response = self._delete(f"/{id}")
        return BaseResponse[Any].model_validate(response)

    def get(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /users/{id}."""
        response = self._get(f"/{id}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, id: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /users/{id}."""
        response = self._put(f"/{id}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_doc(self, id: int, params: UsersDocListParams | None = None) -> BaseResponse[Any]:
        """GET /users/{id}/doc."""
        response = self._get(f"/{id}/doc", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_doc(self, id: int, params: UsersDocListParams | None = None) -> BaseResponse[Any]:
        """Alias for list_doc — GET /users/{id}/doc."""
        return self.list_doc(id, params=params)

    def list_groups(
        self,
        id: int,
        params: UsersGroupsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /users/{id}/groups."""
        response = self._get(f"/{id}/groups", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_groups(self, id: int, data: Any = None) -> BaseResponse[Any]:
        """POST /users/{id}/groups."""
        response = self._post(f"/{id}/groups", data=data)
        return BaseResponse[Any].model_validate(response)

    def get_groups(
        self,
        id: int,
        group_id: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /users/{id}/groups/{groupId}."""
        response = self._get(f"/{id}/groups/{group_id}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_trinity(
        self,
        id: int,
        params: UsersTrinityListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /users/{id}/trinity."""
        response = self._get(f"/{id}/trinity", params=params)
        return BaseResponse[Any].model_validate(response)


class JoomlaClient(BaseServiceClient):
    """Client for the joomla service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._categories: CategoriesResource | None = None
        self._content: ContentResource | None = None
        self._menu: MenuResource | None = None
        self._tags: TagsResource | None = None
        self._usergroups: UsergroupsResource | None = None
        self._users: UsersResource | None = None

    @property
    def categories(self) -> CategoriesResource:
        """Access categories endpoints."""
        if self._categories is None:
            self._categories = CategoriesResource(self._http)
        return self._categories

    @property
    def content(self) -> ContentResource:
        """Access content endpoints."""
        if self._content is None:
            self._content = ContentResource(self._http)
        return self._content

    @property
    def menu(self) -> MenuResource:
        """Access menu endpoints."""
        if self._menu is None:
            self._menu = MenuResource(self._http)
        return self._menu

    @property
    def tags(self) -> TagsResource:
        """Access tags endpoints."""
        if self._tags is None:
            self._tags = TagsResource(self._http)
        return self._tags

    @property
    def usergroups(self) -> UsergroupsResource:
        """Access usergroups endpoints."""
        if self._usergroups is None:
            self._usergroups = UsergroupsResource(self._http)
        return self._usergroups

    @property
    def users(self) -> UsersResource:
        """Access users endpoints."""
        if self._users is None:
            self._users = UsersResource(self._http)
        return self._users
