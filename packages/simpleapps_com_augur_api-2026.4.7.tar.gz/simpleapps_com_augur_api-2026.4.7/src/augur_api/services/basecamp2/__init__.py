"""Service client for basecamp2."""

from augur_api.services.basecamp2.generated.client import Basecamp2Client

__all__ = ["Basecamp2Client"]
