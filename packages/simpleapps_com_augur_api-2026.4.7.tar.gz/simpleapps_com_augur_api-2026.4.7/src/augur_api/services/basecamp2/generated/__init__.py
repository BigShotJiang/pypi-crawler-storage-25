"""Generated code for basecamp2 service."""
