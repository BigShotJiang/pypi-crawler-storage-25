"""
Generated Pydantic schemas for basecamp2 service.
Source: shared/specs/basecamp2.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


class CommentsListParams(EdgeCacheParams):
    """Params for GET /comments."""

    creator_id: int | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    todos_id: int | None = None


CommentsGetParams = EdgeCacheParams


class EventsListParams(EdgeCacheParams):
    """Params for GET /events."""

    event_type_cd: int | None = None
    id: int | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    people_id: int | None = None


class MetricsListParams(EdgeCacheParams):
    """Params for GET /metrics."""

    assignee_id: int | None = None
    creator_id: int | None = None
    has_comments: int | None = None
    is_stale: int | None = None
    limit: int | None = None
    needs_response: int | None = None
    offset: int | None = None
    order_by: str | None = None
    projects_id: int | None = None
    todos_status_cd: int | None = None


class PeopleListParams(EdgeCacheParams):
    """Params for GET /people."""

    admin_flag: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    trashed_flag: str | None = None


PeopleGetParams = EdgeCacheParams


class PeopleMetricsListParams(EdgeCacheParams):
    """Params for GET /people/{id}/metrics."""

    has_comments: int | None = None
    is_stale: int | None = None
    limit: int | None = None
    needs_response: int | None = None
    offset: int | None = None
    order_by: str | None = None
    todos_status_cd: int | None = None


class PeopleTodosListParams(EdgeCacheParams):
    """Params for GET /people/{id}/todos."""

    completed_flag: str | None = None
    due_at: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    projects_id: int | None = None


class PeopleProjectsTodosListParams(EdgeCacheParams):
    """Params for GET /people/{personId}/projects/{projectId}/todos."""

    completed_flag: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


class ProjectsListParams(EdgeCacheParams):
    """Params for GET /projects."""

    archived_flag: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    trashed_flag: str | None = None


ProjectsGetParams = EdgeCacheParams


class ProjectsMetricsListParams(EdgeCacheParams):
    """Params for GET /projects/{id}/metrics."""

    has_comments: int | None = None
    is_stale: int | None = None
    limit: int | None = None
    needs_response: int | None = None
    offset: int | None = None
    order_by: str | None = None
    todos_status_cd: int | None = None


class ProjectsTodolistsListParams(EdgeCacheParams):
    """Params for GET /projects/{id}/todolists."""

    completed_flag: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


class ProjectsTodosListParams(EdgeCacheParams):
    """Params for GET /projects/{id}/todos."""

    assignee_id: int | None = None
    completed_flag: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


class ProjectsTodolistsTodosListParams(EdgeCacheParams):
    """Params for GET /projects/{projectId}/todolists/{todolistId}/todos."""

    assignee_id: int | None = None
    completed_flag: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


class TodolistsListParams(EdgeCacheParams):
    """Params for GET /todolists."""

    assignee_id: int | None = None
    completed_flag: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    projects_id: int | None = None


TodolistsGetParams = EdgeCacheParams


class TodosListParams(EdgeCacheParams):
    """Params for GET /todos."""

    assignee_id: int | None = None
    completed_flag: str | None = None
    due_at: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    projects_id: int | None = None
    todolist_id: int | None = None


class TodosSummaryListParams(EdgeCacheParams):
    """Params for GET /todos-summary."""

    akasha_cd: int | None = None
    limit: int | None = None
    offset: int | None = None
    process_cd: int | None = None


TodosSummaryGetParams = EdgeCacheParams


TodosGetParams = EdgeCacheParams


class TodosCommentsListParams(EdgeCacheParams):
    """Params for GET /todos/{id}/comments."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


class TodosEventsListParams(EdgeCacheParams):
    """Params for GET /todos/{id}/events."""

    event_type_cd: int | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    people_id: int | None = None


TodosEventsGetParams = EdgeCacheParams


TodosMetricsListParams = EdgeCacheParams


class TodosSessionsListParams(EdgeCacheParams):
    """Params for GET /todos/{id}/sessions."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    session_status_cd: int | None = None


TodosSessionsGetParams = EdgeCacheParams


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class CommentsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    id: int | None = None
    content: str | None = None
    updated_at: str | None = None
    created_at: str | None = None
    creator_id: int | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    todos_id: int | None = None
    vector: str | None = None
    vector_cd: int | None = None
    vector_flag: str | None = None
    date_last_vector: str | None = None
    location: str | None = None
    content_length: int | None = None
    token_count: int | None = None


class EventsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    id: int | None = None
    event_num: int | None = None
    event_type_cd: int | None = None
    people_id: int | None = None
    event_at: str | None = None
    comment_id: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    todos_sessions_uid: int | None = None


class MetricsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    id: int | None = None
    projects_id: int | None = None
    todolist_id: int | None = None
    assignee_id: int | None = None
    creator_id: int | None = None
    todos_content: str | None = None
    todos_status_cd: int | None = None
    is_stale: int | None = None
    has_comments: int | None = None
    needs_response: int | None = None
    created_at: str | None = None
    completed_at: str | None = None
    last_activity_at: str | None = None
    first_comment_at: str | None = None
    last_comment_at: str | None = None
    days_open: int | None = None
    days_since_last_event: int | None = None
    days_to_first_comment: int | None = None
    cycle_time_days: int | None = None
    comment_count: int | None = None
    active_days_count: int | None = None
    activity_span_days: int | None = None
    avg_days_between_activity: float | None = None
    last_commenter_id: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None


class PeopleData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    id: int | None = None
    identity_id: int | None = None
    name: str | None = None
    email_address: str | None = None
    admin_flag: str | None = None
    trashed_flag: str | None = None
    updated_at: str | None = None
    created_at: str | None = None
    url: str | None = None
    app_url: str | None = None
    avatar_url: str | None = None
    fullsize_avatar_url: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None


class ProjectsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    id: int | None = None
    name: str | None = None
    description: str | None = None
    updated_at: str | None = None
    created_at: str | None = None
    last_event_at: str | None = None
    url: str | None = None
    app_url: str | None = None
    template_flag: str | None = None
    archived_flag: str | None = None
    starred_flag: str | None = None
    trashed_flag: str | None = None
    draft_flag: str | None = None
    is_client_project_flag: str | None = None
    color: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None


class TodolistsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    id: int | None = None
    name: str | None = None
    description: str | None = None
    updated_at: str | None = None
    created_at: str | None = None
    url: str | None = None
    app_url: str | None = None
    completed_flag: str | None = None
    private_flag: str | None = None
    trashed_flag: str | None = None
    completed_count: int | None = None
    remaining_count: int | None = None
    creator_id: int | None = None
    bucket_id: int | None = None
    update_cd: int | None = None
    position: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    projects_id: int | None = None


class TodosData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    id: int | None = None
    todolist_id: int | None = None
    content: str | None = None
    due_at: str | None = None
    due_on: str | None = None
    updated_at: str | None = None
    created_at: str | None = None
    completed_at: str | None = None
    comments_count: int | None = None
    private_flag: str | None = None
    trashed_flag: str | None = None
    creator_id: int | None = None
    assignee_id: int | None = None
    completed_flag: str | None = None
    url: str | None = None
    app_url: str | None = None
    update_cd: int | None = None
    position: int | None = None
    projects_id: int | None = None
    detail_json: str | None = None
    pull_detail_cd: int | None = None
    process_cd: int | None = None
    agr_info_cd: int | None = None
    status_cd: int | None = None
    last_comment_at: str | None = None
    vector: str | None = None
    vector_cd: int | None = None
    vector_flag: str | None = None
    date_last_vector: str | None = None


class TodosSummaryData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    id: int | None = None
    summary: str | None = None
    summary_tokens: int | None = None
    context: str | None = None
    context_tokens: int | None = None
    model_name: str | None = None
    vector: str | None = None
    vector_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    update_cd: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    akasha_cd: int | None = None
    complexity_score: int | None = None
    complexity_reason: str | None = None
    estimated_minutes: int | None = None
    required_services: str | None = None
    worthiness_reason: str | None = None


class TodosSessionsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    todos_sessions_uid: int | None = None
    todos_id: int | None = None
    session_num: int | None = None
    session_status_cd: int | None = None
    subject: str | None = None
    problem: str | None = None
    investigation: str | None = None
    plan: str | None = None
    outcome: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
