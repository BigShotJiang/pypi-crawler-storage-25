"""Service client for ups."""

from augur_api.services.ups.generated.client import UpsClient

__all__ = ["UpsClient"]
