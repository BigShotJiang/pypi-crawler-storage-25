"""
Generated client for ups service.
Source: shared/specs/ups.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.ups.generated.schemas import (
        RatesShopListParams,
    )


class RatesShopResource(BaseResource):
    """Resource for /rates-shop endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/rates-shop")

    def list(self, params: RatesShopListParams | None = None) -> BaseResponse[Any]:
        """GET /rates-shop."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)


class UpsClient(BaseServiceClient):
    """Client for the ups service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._rates_shop: RatesShopResource | None = None

    @property
    def rates_shop(self) -> RatesShopResource:
        """Access ratesShop endpoints."""
        if self._rates_shop is None:
            self._rates_shop = RatesShopResource(self._http)
        return self._rates_shop
