"""Generated code for ups service."""
