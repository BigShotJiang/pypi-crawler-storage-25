"""
Generated Pydantic schemas for ups service.
Source: shared/specs/ups.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import EdgeCacheParams


class RatesShopListParams(EdgeCacheParams):
    """Params for GET /rates-shop."""

    cache_site_id: str | None = None
    from_address1: str | None = None
    from_address2: str | None = None
    from_address3: str | None = None
    from_city: str | None = None
    from_country_code: str | None = None
    from_postal_code: str | None = None
    from_state_province_code: str | None = None
    to_address1: str | None = None
    to_address2: str | None = None
    to_address3: str | None = None
    to_city: str | None = None
    to_country_code: str | None = None
    to_postal_code: str | None = None
    to_state_province_code: str | None = None
    weight: int | None = None
