"""Service client for p21_pim."""

from augur_api.services.p21_pim.generated.client import P21PimClient

__all__ = ["P21PimClient"]
