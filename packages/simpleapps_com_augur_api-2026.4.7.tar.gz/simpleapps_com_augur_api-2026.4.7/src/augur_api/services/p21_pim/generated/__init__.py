"""Generated code for p21-pim service."""
