"""
Generated Pydantic schemas for p21-pim service.
Source: shared/specs/p21-pim.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


class InvMastExtListParams(EdgeCacheParams):
    """Params for GET /inv-mast-ext."""

    inv_mast_uid: int | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


InvMastExtGetParams = EdgeCacheParams


class ItemsSuggestDisplayDescListParams(EdgeCacheParams):
    """Params for GET /items/{invMastUid}/suggest-display-desc."""

    limit: int | None = None
    model: str | None = None


class ItemsSuggestWebDescListParams(EdgeCacheParams):
    """Params for GET /items/{invMastUid}/suggest-web-desc."""

    limit: int | None = None
    model: str | None = None


class PodcastsListParams(EdgeCacheParams):
    """Params for GET /podcasts."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


PodcastsGetParams = EdgeCacheParams


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class PodcastsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    podcasts_uid: int | None = None
    title: str | None = None
    path: str | None = None
    transcript: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
