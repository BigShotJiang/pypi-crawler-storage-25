"""
Generated Pydantic schemas for p21-sism service.
Source: shared/specs/p21-sism.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from pydantic import Field

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


class ImportListParams(EdgeCacheParams):
    """Params for GET /import."""

    created_from: str | None = None
    created_on: str | None = None
    created_to: str | None = None
    exclude_state: str | None = None
    import_state: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    reference_no: str | None = None
    source_id: int | None = None
    source_name: str | None = None


class ImportDailySummaryListParams(EdgeCacheParams):
    """Params for GET /import/daily-summary."""

    days: int | None = None


class ImportRecentListParams(EdgeCacheParams):
    """Params for GET /import/recent."""

    created_from: str | None = None
    created_on: str | None = None
    created_to: str | None = None
    exclude_state: str | None = None
    hours: int | None = None
    import_state: str | None = None
    limit: int | None = None
    source_id: int | None = None
    source_name: str | None = None


class ImportStuckListParams(EdgeCacheParams):
    """Params for GET /import/stuck."""

    hours: int | None = None
    limit: int | None = None


ImportGetParams = EdgeCacheParams


ImportImpOeHdrListParams = EdgeCacheParams


ImportImpOeHdrSalesrepListParams = EdgeCacheParams


ImportImpOeHdrWebListParams = EdgeCacheParams


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class ImportDailySummaryData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    date: str | None = None
    total: int | None = None
    initial: int | None = None
    processing: int | None = None
    processing_coupon: int | None = None
    process_coupon: int | None = None
    validate_value: int | None = Field(None, alias="validate")
    validating: int | None = None
    validated: int | None = None
    processed: int | None = None
    hold: int | None = None
    delivering: int | None = None
    delivered: int | None = None
    importing: int | None = None
    imported: int | None = None
    redelivered: int | None = None
    invalid: int | None = None
    failed: int | None = None
    error: int | None = None
    cancelled: int | None = None
    stopped: int | None = None
    skipped: int | None = None


class ImportData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    import_uid: int | None = None
    scheduled_import_master_uid: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    source_name: str | None = None
    source_id: int | None = None
    import_state: str | None = None
    json_data: str | None = None
    import_status_cd: int | None = None
    import_results: str | None = None
    reference_no: str | None = None
