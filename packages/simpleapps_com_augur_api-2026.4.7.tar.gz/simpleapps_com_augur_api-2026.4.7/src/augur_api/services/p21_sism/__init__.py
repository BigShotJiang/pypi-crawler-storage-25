"""Service client for p21_sism."""

from augur_api.services.p21_sism.generated.client import P21SismClient

__all__ = ["P21SismClient"]
