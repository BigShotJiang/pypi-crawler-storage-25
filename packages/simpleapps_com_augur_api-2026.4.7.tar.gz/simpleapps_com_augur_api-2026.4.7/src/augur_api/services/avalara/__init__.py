"""Service client for avalara."""

from augur_api.services.avalara.generated.client import AvalaraClient

__all__ = ["AvalaraClient"]
