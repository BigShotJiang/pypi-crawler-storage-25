"""Service client for agr_site."""

from augur_api.services.agr_site.generated.client import AgrSiteClient

__all__ = ["AgrSiteClient"]
