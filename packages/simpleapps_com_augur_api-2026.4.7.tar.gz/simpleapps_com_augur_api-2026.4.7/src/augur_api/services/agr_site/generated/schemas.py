"""
Generated Pydantic schemas for agr-site service.
Source: shared/specs/agr-site.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams

ContextGetParams = EdgeCacheParams


class FyxerTranscriptListParams(EdgeCacheParams):
    """Params for GET /fyxer-transcript."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


FyxerTranscriptGetParams = EdgeCacheParams


class GeoCodesPostalCodesListParams(EdgeCacheParams):
    """Params for GET /geo-codes-postal-codes."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


GeoCodesPostalCodesGetParams = EdgeCacheParams


MetaFilesRobotsListParams = EdgeCacheParams


class OpenSearchEmbeddingListParams(EdgeCacheParams):
    """Params for GET /open-search/embedding."""

    q: str


class PostalCodesXShiptosListParams(EdgeCacheParams):
    """Params for GET /postal-codes-x-shiptos."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


PostalCodesXShiptosGetParams = EdgeCacheParams


class SettingsListParams(EdgeCacheParams):
    """Params for GET /settings."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    service_name: str
    status_cd: int | None = None


SettingsGetParams = EdgeCacheParams


class TrainingListParams(EdgeCacheParams):
    """Params for GET /training."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


TrainingGetParams = EdgeCacheParams


class TrainingConversationsListParams(EdgeCacheParams):
    """Params for GET /training/{trainingSetUid}/conversations."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


TrainingConversationsGetParams = EdgeCacheParams


class TrainingConversationsMessagesListParams(EdgeCacheParams):
    """Params for GET /training/{trainingSetUid}/conversations/{trainingConvUid}/messages."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


TrainingConversationsMessagesGetParams = EdgeCacheParams


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class FyxerTranscriptData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    fyxer_transcript_hdr_uid: int | None = None
    link: str | None = None
    summary: str | None = None
    transcript: str | None = None
    date_recorded: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    title: str | None = None


class GeoCodesPostalCodesData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    geo_codes_postal_codes_uid: int | None = None
    country_code: str | None = None
    postal_code: str | None = None
    place_name: str | None = None
    admin_name1: str | None = None
    admin_code1: str | None = None
    admin_name2: str | None = None
    admin_code2: str | None = None
    admin_name3: str | None = None
    admin_code3: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    accuracy: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None


class NotificationsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    notifications_uid: int | None = None
    service_name: str | None = None
    data_type_name: str | None = None
    type: str | None = None
    data_type_uid: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None


class PostalCodesXShiptosData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    postal_codes_x_shiptos_uid: int | None = None
    postal_code: str | None = None
    ship_to_id: float | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None


class SettingsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    settings_uid: int | None = None
    service_name: str | None = None
    name: str | None = None
    value: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None


class TrainingData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    training_set_uid: int | None = None
    name: str | None = None
    description: str | None = None
    format_type: str | None = None
    system_prompt: str | None = None
    developer_prompt: str | None = None
    model_target: str | None = None
    train_split_pct: int | None = None
    total_conversations: int | None = None
    total_tokens: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    update_cd: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None


class TrainingConversationsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    training_conv_uid: int | None = None
    training_set_uid: int | None = None
    source_type: str | None = None
    generator_model: str | None = None
    service_name: str | None = None
    data_type_name: str | None = None
    data_type_uid: int | None = None
    category: str | None = None
    quality_score: float | None = None
    split_type: str | None = None
    total_tokens: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    update_cd: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None


class TrainingConversationsMessagesData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    training_msg_uid: int | None = None
    training_conv_uid: int | None = None
    sequence_no: int | None = None
    role: str | None = None
    channel: str | None = None
    content: str | None = None
    analysis: str | None = None
    commentary: str | None = None
    final: str | None = None
    weight: int | None = None
    tokens: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    update_cd: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
