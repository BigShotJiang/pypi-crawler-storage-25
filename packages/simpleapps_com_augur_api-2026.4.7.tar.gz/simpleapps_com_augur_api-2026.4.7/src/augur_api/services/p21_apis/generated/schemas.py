"""
Generated Pydantic schemas for p21-apis service.
Source: shared/specs/p21-apis.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import EdgeCacheParams

EntityContactsRefreshGetParams = EdgeCacheParams


EntityCustomersRefreshGetParams = EdgeCacheParams


class TransCategoryGetParams(EdgeCacheParams):
    """Params for GET /trans-category/{categoryUid}."""

    category_id: str | None = None


class TransCategoryUpdateParams(EdgeCacheParams):
    """Params for PUT /trans-category/{categoryUid}."""

    category_id: str | None = None


class TransCategoryDeleteParams(EdgeCacheParams):
    """Params for DELETE /trans-category/{categoryUid}."""

    category_id: str | None = None


class TransCompanyGetParams(EdgeCacheParams):
    """Params for GET /trans-company/{companyUid}."""

    company_id: str | None = None


class TransCompanyUpdateParams(EdgeCacheParams):
    """Params for PUT /trans-company/{companyUid}."""

    company_id: str | None = None


class TransCompanyDeleteParams(EdgeCacheParams):
    """Params for DELETE /trans-company/{companyUid}."""

    company_id: str | None = None


TransPurchaseOrderReceiptGetParams = EdgeCacheParams


class TransUserGetParams(EdgeCacheParams):
    """Params for GET /trans-user/{usersUid}."""

    user_id: str | None = None


class TransUserUpdateParams(EdgeCacheParams):
    """Params for PUT /trans-user/{usersUid}."""

    user_id: str | None = None


class TransUserDeleteParams(EdgeCacheParams):
    """Params for DELETE /trans-user/{usersUid}."""

    user_id: str | None = None


TransWebDisplayTypeDefaultsListParams = EdgeCacheParams


TransWebDisplayTypeDefinitionListParams = EdgeCacheParams


class TransWebDisplayTypeGetParams(EdgeCacheParams):
    """Params for GET /trans-web-display-type/{webDisplayTypeUid}."""

    web_display_type_id: str | None = None


class TransWebDisplayTypeUpdateParams(EdgeCacheParams):
    """Params for PUT /trans-web-display-type/{webDisplayTypeUid}."""

    web_display_type_id: str | None = None


class TransWebDisplayTypeDeleteParams(EdgeCacheParams):
    """Params for DELETE /trans-web-display-type/{webDisplayTypeUid}."""

    web_display_type_id: str | None = None
