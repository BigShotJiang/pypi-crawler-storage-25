"""
Generated client for p21-apis service.
Source: shared/specs/p21-apis.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.p21_apis.generated.schemas import (
        TransCategoryGetParams,
        TransCompanyGetParams,
        TransUserGetParams,
        TransWebDisplayTypeGetParams,
    )


class EntityContactsResource(BaseResource):
    """Resource for /entity-contacts endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/entity-contacts")

    def get_refresh(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /entity-contacts/refresh."""
        response = self._get("/refresh", params=options)
        return BaseResponse[Any].model_validate(response)


class EntityCustomersResource(BaseResource):
    """Resource for /entity-customers endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/entity-customers")

    def get_refresh(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /entity-customers/refresh."""
        response = self._get("/refresh", params=options)
        return BaseResponse[Any].model_validate(response)


class TransCategoryResource(BaseResource):
    """Resource for /trans-category endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/trans-category")

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /trans-category."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, category_uid: int) -> BaseResponse[Any]:
        """DELETE /trans-category/{categoryUid}."""
        response = self._delete(f"/{category_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        category_uid: int,
        params: TransCategoryGetParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /trans-category/{categoryUid}."""
        response = self._get(f"/{category_uid}", params=params)
        return BaseResponse[Any].model_validate(response)

    def update(self, category_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /trans-category/{categoryUid}."""
        response = self._put(f"/{category_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class TransCompanyResource(BaseResource):
    """Resource for /trans-company endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/trans-company")

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /trans-company."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, company_uid: int) -> BaseResponse[Any]:
        """DELETE /trans-company/{companyUid}."""
        response = self._delete(f"/{company_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        company_uid: int,
        params: TransCompanyGetParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /trans-company/{companyUid}."""
        response = self._get(f"/{company_uid}", params=params)
        return BaseResponse[Any].model_validate(response)

    def update(self, company_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /trans-company/{companyUid}."""
        response = self._put(f"/{company_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class TransPurchaseOrderReceiptResource(BaseResource):
    """Resource for /trans-purchase-order-receipt endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/trans-purchase-order-receipt")

    def get(self, po_no: str, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /trans-purchase-order-receipt/{poNo}."""
        response = self._get(f"/{po_no}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, po_no: str, data: Any = None) -> BaseResponse[Any]:
        """PUT /trans-purchase-order-receipt/{poNo}."""
        response = self._put(f"/{po_no}", data=data)
        return BaseResponse[Any].model_validate(response)


class TransUserResource(BaseResource):
    """Resource for /trans-user endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/trans-user")

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /trans-user."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, users_uid: int) -> BaseResponse[Any]:
        """DELETE /trans-user/{usersUid}."""
        response = self._delete(f"/{users_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, users_uid: int, params: TransUserGetParams | None = None) -> BaseResponse[Any]:
        """GET /trans-user/{usersUid}."""
        response = self._get(f"/{users_uid}", params=params)
        return BaseResponse[Any].model_validate(response)

    def update(self, users_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /trans-user/{usersUid}."""
        response = self._put(f"/{users_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class TransWebDisplayTypeResource(BaseResource):
    """Resource for /trans-web-display-type endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/trans-web-display-type")

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /trans-web-display-type."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def list_defaults(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /trans-web-display-type/defaults."""
        response = self._get("/defaults", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_definition(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /trans-web-display-type/definition."""
        response = self._get("/definition", params=options)
        return BaseResponse[Any].model_validate(response)

    def delete(self, web_display_type_uid: int) -> BaseResponse[Any]:
        """DELETE /trans-web-display-type/{webDisplayTypeUid}."""
        response = self._delete(f"/{web_display_type_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        web_display_type_uid: int,
        params: TransWebDisplayTypeGetParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /trans-web-display-type/{webDisplayTypeUid}."""
        response = self._get(f"/{web_display_type_uid}", params=params)
        return BaseResponse[Any].model_validate(response)

    def update(self, web_display_type_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /trans-web-display-type/{webDisplayTypeUid}."""
        response = self._put(f"/{web_display_type_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class P21ApisClient(BaseServiceClient):
    """Client for the p21-apis service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._entity_contacts: EntityContactsResource | None = None
        self._entity_customers: EntityCustomersResource | None = None
        self._trans_category: TransCategoryResource | None = None
        self._trans_company: TransCompanyResource | None = None
        self._trans_purchase_order_receipt: TransPurchaseOrderReceiptResource | None = None
        self._trans_user: TransUserResource | None = None
        self._trans_web_display_type: TransWebDisplayTypeResource | None = None

    @property
    def entity_contacts(self) -> EntityContactsResource:
        """Access entityContacts endpoints."""
        if self._entity_contacts is None:
            self._entity_contacts = EntityContactsResource(self._http)
        return self._entity_contacts

    @property
    def entity_customers(self) -> EntityCustomersResource:
        """Access entityCustomers endpoints."""
        if self._entity_customers is None:
            self._entity_customers = EntityCustomersResource(self._http)
        return self._entity_customers

    @property
    def trans_category(self) -> TransCategoryResource:
        """Access transCategory endpoints."""
        if self._trans_category is None:
            self._trans_category = TransCategoryResource(self._http)
        return self._trans_category

    @property
    def trans_company(self) -> TransCompanyResource:
        """Access transCompany endpoints."""
        if self._trans_company is None:
            self._trans_company = TransCompanyResource(self._http)
        return self._trans_company

    @property
    def trans_purchase_order_receipt(self) -> TransPurchaseOrderReceiptResource:
        """Access transPurchaseOrderReceipt endpoints."""
        if self._trans_purchase_order_receipt is None:
            self._trans_purchase_order_receipt = TransPurchaseOrderReceiptResource(self._http)
        return self._trans_purchase_order_receipt

    @property
    def trans_user(self) -> TransUserResource:
        """Access transUser endpoints."""
        if self._trans_user is None:
            self._trans_user = TransUserResource(self._http)
        return self._trans_user

    @property
    def trans_web_display_type(self) -> TransWebDisplayTypeResource:
        """Access transWebDisplayType endpoints."""
        if self._trans_web_display_type is None:
            self._trans_web_display_type = TransWebDisplayTypeResource(self._http)
        return self._trans_web_display_type
