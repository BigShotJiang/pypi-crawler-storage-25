"""Service client for p21_apis."""

from augur_api.services.p21_apis.generated.client import P21ApisClient

__all__ = ["P21ApisClient"]
