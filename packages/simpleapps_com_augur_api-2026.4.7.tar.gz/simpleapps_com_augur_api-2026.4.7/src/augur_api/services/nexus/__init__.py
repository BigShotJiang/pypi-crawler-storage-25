"""Service client for nexus."""

from augur_api.services.nexus.generated.client import NexusClient

__all__ = ["NexusClient"]
