"""Generated code for nexus service."""
