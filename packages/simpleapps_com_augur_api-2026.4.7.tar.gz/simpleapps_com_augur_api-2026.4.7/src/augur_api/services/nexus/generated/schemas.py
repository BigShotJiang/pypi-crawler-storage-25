"""
Generated Pydantic schemas for nexus service.
Source: shared/specs/nexus.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams

BinTransferGetParams = EdgeCacheParams


class BinTransferListParams(EdgeCacheParams):
    """Params for GET /bin-transfer."""

    limit: int | None = None
    offset: int | None = None
    status_cd: int | None = None


class BinTransferCreateParams(EdgeCacheParams):
    """Params for POST /bin-transfer."""

    limit: int | None = None
    offset: int | None = None
    status_cd: int | None = None


BinTransferStatusListParams = EdgeCacheParams


PurchaseOrderReceiptGetParams = EdgeCacheParams


class PurchaseOrderReceiptListParams(EdgeCacheParams):
    """Params for GET /purchase-order-receipt."""

    limit: int | None = None
    offset: int | None = None
    reference_no: str | None = None
    status_cd: int | None = None


class PurchaseOrderReceiptCreateParams(EdgeCacheParams):
    """Params for POST /purchase-order-receipt."""

    limit: int | None = None
    offset: int | None = None
    reference_no: str | None = None
    status_cd: int | None = None


ReceivingGetParams = EdgeCacheParams


class ReceivingListParams(EdgeCacheParams):
    """Params for GET /receiving."""

    limit: int | None = None
    offset: int | None = None
    po_no: int | None = None
    status_cd: int | None = None


class ReceivingCreateParams(EdgeCacheParams):
    """Params for POST /receiving."""

    limit: int | None = None
    offset: int | None = None
    po_no: int | None = None
    status_cd: int | None = None


TransferGetParams = EdgeCacheParams


class TransferListParams(EdgeCacheParams):
    """Params for GET /transfer."""

    limit: int | None = None
    offset: int | None = None
    reference_no: str | None = None
    status_cd: int | None = None


class TransferCreateParams(EdgeCacheParams):
    """Params for POST /transfer."""

    limit: int | None = None
    offset: int | None = None
    reference_no: str | None = None
    status_cd: int | None = None


TransferReceiptGetParams = EdgeCacheParams


class TransferReceiptListParams(EdgeCacheParams):
    """Params for GET /transfer-receipt."""

    limit: int | None = None
    offset: int | None = None
    reference_no: str | None = None
    status_cd: int | None = None


class TransferReceiptCreateParams(EdgeCacheParams):
    """Params for POST /transfer-receipt."""

    limit: int | None = None
    offset: int | None = None
    reference_no: str | None = None
    status_cd: int | None = None


TransferShippingGetParams = EdgeCacheParams


class TransferShippingListParams(EdgeCacheParams):
    """Params for GET /transfer-shipping."""

    limit: int | None = None
    offset: int | None = None
    reference_no: str | None = None
    status_cd: int | None = None


class TransferShippingCreateParams(EdgeCacheParams):
    """Params for POST /transfer-shipping."""

    limit: int | None = None
    offset: int | None = None
    reference_no: str | None = None
    status_cd: int | None = None


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class BinTransferData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    bin_transfer_hdr_uid: int | None = None
    import_state: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    json_data: str | None = None
    properties: str | None = None
    request_id: str | None = None
    response: str | None = None
    users_id: int | None = None
    location_id: float | None = None


class BinTransferStatusData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    bin_transfer_hdr_uid: int | None = None
    import_state: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    json_data: str | None = None
    properties: str | None = None
    request_id: str | None = None
    response: str | None = None
    users_id: int | None = None
    location_id: float | None = None
    lines: str | None = None


class PurchaseOrderReceiptData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    purchase_order_receipt_uid: int | None = None
    import_state: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    reference_no: str | None = None
    json_data: str | None = None
    request_id: str | None = None
    process_message: str | None = None


class ReceivingData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    receiving_uid: int | None = None
    import_state: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    reference_no: str | None = None
    json_data: str | None = None
    properties: str | None = None
    po_no: float | None = None
    request_id: str | None = None
    process_message: str | None = None


class TransferData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    transfer_uid: int | None = None
    import_state: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    reference_no: str | None = None
    json_data: str | None = None
    request_id: str | None = None
    process_message: str | None = None


class TransferReceiptData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    transfer_receipt_uid: int | None = None
    import_state: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    reference_no: str | None = None
    json_data: str | None = None
    request_id: str | None = None
    process_message: str | None = None
