"""
Generated client for nexus service.
Source: shared/specs/nexus.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.nexus.generated.schemas import (
        BinTransferListParams,
        PurchaseOrderReceiptListParams,
        ReceivingListParams,
        TransferListParams,
        TransferReceiptListParams,
        TransferShippingListParams,
    )


class BinTransferResource(BaseResource):
    """Resource for /bin-transfer endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/bin-transfer")

    def list(self, params: BinTransferListParams | None = None) -> BaseResponse[Any]:
        """GET /bin-transfer."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /bin-transfer."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, bin_transfer_hdr_uid: int) -> BaseResponse[Any]:
        """DELETE /bin-transfer/{binTransferHdrUid}."""
        response = self._delete(f"/{bin_transfer_hdr_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        bin_transfer_hdr_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /bin-transfer/{binTransferHdrUid}."""
        response = self._get(f"/{bin_transfer_hdr_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, bin_transfer_hdr_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /bin-transfer/{binTransferHdrUid}."""
        response = self._put(f"/{bin_transfer_hdr_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_status(
        self,
        bin_transfer_hdr_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /bin-transfer/{binTransferHdrUid}/status."""
        response = self._get(f"/{bin_transfer_hdr_uid}/status", params=options)
        return BaseResponse[Any].model_validate(response)


class PurchaseOrderReceiptResource(BaseResource):
    """Resource for /purchase-order-receipt endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/purchase-order-receipt")

    def list(self, params: PurchaseOrderReceiptListParams | None = None) -> BaseResponse[Any]:
        """GET /purchase-order-receipt."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /purchase-order-receipt."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, purchase_order_receipt_uid: int) -> BaseResponse[Any]:
        """DELETE /purchase-order-receipt/{purchaseOrderReceiptUid}."""
        response = self._delete(f"/{purchase_order_receipt_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        purchase_order_receipt_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /purchase-order-receipt/{purchaseOrderReceiptUid}."""
        response = self._get(f"/{purchase_order_receipt_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, purchase_order_receipt_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /purchase-order-receipt/{purchaseOrderReceiptUid}."""
        response = self._put(f"/{purchase_order_receipt_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class ReceivingResource(BaseResource):
    """Resource for /receiving endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/receiving")

    def list(self, params: ReceivingListParams | None = None) -> BaseResponse[Any]:
        """GET /receiving."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /receiving."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, receiving_uid: int) -> BaseResponse[Any]:
        """DELETE /receiving/{receivingUid}."""
        response = self._delete(f"/{receiving_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, receiving_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /receiving/{receivingUid}."""
        response = self._get(f"/{receiving_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, receiving_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /receiving/{receivingUid}."""
        response = self._put(f"/{receiving_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class TransferResource(BaseResource):
    """Resource for /transfer endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/transfer")

    def list(self, params: TransferListParams | None = None) -> BaseResponse[Any]:
        """GET /transfer."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /transfer."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, transfer_uid: int) -> BaseResponse[Any]:
        """DELETE /transfer/{transferUid}."""
        response = self._delete(f"/{transfer_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, transfer_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /transfer/{transferUid}."""
        response = self._get(f"/{transfer_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, transfer_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /transfer/{transferUid}."""
        response = self._put(f"/{transfer_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class TransferReceiptResource(BaseResource):
    """Resource for /transfer-receipt endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/transfer-receipt")

    def list(self, params: TransferReceiptListParams | None = None) -> BaseResponse[Any]:
        """GET /transfer-receipt."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /transfer-receipt."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, transfer_receipt_uid: int) -> BaseResponse[Any]:
        """DELETE /transfer-receipt/{transferReceiptUid}."""
        response = self._delete(f"/{transfer_receipt_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        transfer_receipt_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /transfer-receipt/{transferReceiptUid}."""
        response = self._get(f"/{transfer_receipt_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, transfer_receipt_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /transfer-receipt/{transferReceiptUid}."""
        response = self._put(f"/{transfer_receipt_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class TransferShippingResource(BaseResource):
    """Resource for /transfer-shipping endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/transfer-shipping")

    def list(self, params: TransferShippingListParams | None = None) -> BaseResponse[Any]:
        """GET /transfer-shipping."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /transfer-shipping."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, transfer_receipt_uid: int) -> BaseResponse[Any]:
        """DELETE /transfer-shipping/{transferReceiptUid}."""
        response = self._delete(f"/{transfer_receipt_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        transfer_receipt_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /transfer-shipping/{transferReceiptUid}."""
        response = self._get(f"/{transfer_receipt_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, transfer_receipt_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /transfer-shipping/{transferReceiptUid}."""
        response = self._put(f"/{transfer_receipt_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class NexusClient(BaseServiceClient):
    """Client for the nexus service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._bin_transfer: BinTransferResource | None = None
        self._purchase_order_receipt: PurchaseOrderReceiptResource | None = None
        self._receiving: ReceivingResource | None = None
        self._transfer: TransferResource | None = None
        self._transfer_receipt: TransferReceiptResource | None = None
        self._transfer_shipping: TransferShippingResource | None = None

    @property
    def bin_transfer(self) -> BinTransferResource:
        """Access binTransfer endpoints."""
        if self._bin_transfer is None:
            self._bin_transfer = BinTransferResource(self._http)
        return self._bin_transfer

    @property
    def purchase_order_receipt(self) -> PurchaseOrderReceiptResource:
        """Access purchaseOrderReceipt endpoints."""
        if self._purchase_order_receipt is None:
            self._purchase_order_receipt = PurchaseOrderReceiptResource(self._http)
        return self._purchase_order_receipt

    @property
    def receiving(self) -> ReceivingResource:
        """Access receiving endpoints."""
        if self._receiving is None:
            self._receiving = ReceivingResource(self._http)
        return self._receiving

    @property
    def transfer(self) -> TransferResource:
        """Access transfer endpoints."""
        if self._transfer is None:
            self._transfer = TransferResource(self._http)
        return self._transfer

    @property
    def transfer_receipt(self) -> TransferReceiptResource:
        """Access transferReceipt endpoints."""
        if self._transfer_receipt is None:
            self._transfer_receipt = TransferReceiptResource(self._http)
        return self._transfer_receipt

    @property
    def transfer_shipping(self) -> TransferShippingResource:
        """Access transferShipping endpoints."""
        if self._transfer_shipping is None:
            self._transfer_shipping = TransferShippingResource(self._http)
        return self._transfer_shipping
