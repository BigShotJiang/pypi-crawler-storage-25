"""Service client for agr_work."""

from augur_api.services.agr_work.generated.client import AgrWorkClient

__all__ = ["AgrWorkClient"]
