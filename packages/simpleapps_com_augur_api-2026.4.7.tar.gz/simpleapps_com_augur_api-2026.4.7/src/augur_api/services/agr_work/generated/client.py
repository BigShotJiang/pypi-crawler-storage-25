"""
Generated client for agr-work service.
Source: shared/specs/agr-work.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from augur_api.services.base import BaseServiceClient

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient


class AgrWorkClient(BaseServiceClient):
    """Client for the agr-work service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
