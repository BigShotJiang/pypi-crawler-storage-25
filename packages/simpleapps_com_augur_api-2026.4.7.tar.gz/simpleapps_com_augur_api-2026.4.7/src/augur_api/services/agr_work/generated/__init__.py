"""Generated code for agr-work service."""
