"""
Generated Pydantic schemas for agr-work service.
Source: shared/specs/agr-work.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations
