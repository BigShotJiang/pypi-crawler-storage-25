"""
Generated Pydantic schemas for gregorovich service.
Source: shared/specs/gregorovich.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import EdgeCacheParams


class ChatGptAskGetParams(EdgeCacheParams):
    """Params for GET /chat-gpt/ask."""

    question: str


DocumentsListParams = EdgeCacheParams
