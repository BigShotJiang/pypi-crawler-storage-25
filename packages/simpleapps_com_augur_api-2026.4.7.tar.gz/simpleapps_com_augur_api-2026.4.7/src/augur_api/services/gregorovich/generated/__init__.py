"""Generated code for gregorovich service."""
