"""
Generated client for gregorovich service.
Source: shared/specs/gregorovich.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.gregorovich.generated.schemas import (
        ChatGptAskGetParams,
    )


class ChatGptResource(BaseResource):
    """Resource for /chat-gpt endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/chat-gpt")

    def get_ask(self, params: ChatGptAskGetParams | None = None) -> BaseResponse[Any]:
        """GET /chat-gpt/ask."""
        response = self._get("/ask", params=params)
        return BaseResponse[Any].model_validate(response)


class DocumentsResource(BaseResource):
    """Resource for /documents endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/documents")

    def list(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /documents."""
        response = self._get(params=options)
        return BaseResponse[Any].model_validate(response)


class OllamaResource(BaseResource):
    """Resource for /ollama endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/ollama")

    def create_generate(self, data: Any = None) -> BaseResponse[Any]:
        """POST /ollama/generate."""
        response = self._post("/generate", data=data)
        return BaseResponse[Any].model_validate(response)


class GregorovichClient(BaseServiceClient):
    """Client for the gregorovich service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._chat_gpt: ChatGptResource | None = None
        self._documents: DocumentsResource | None = None
        self._ollama: OllamaResource | None = None

    @property
    def chat_gpt(self) -> ChatGptResource:
        """Access chatGpt endpoints."""
        if self._chat_gpt is None:
            self._chat_gpt = ChatGptResource(self._http)
        return self._chat_gpt

    @property
    def documents(self) -> DocumentsResource:
        """Access documents endpoints."""
        if self._documents is None:
            self._documents = DocumentsResource(self._http)
        return self._documents

    @property
    def ollama(self) -> OllamaResource:
        """Access ollama endpoints."""
        if self._ollama is None:
            self._ollama = OllamaResource(self._http)
        return self._ollama
