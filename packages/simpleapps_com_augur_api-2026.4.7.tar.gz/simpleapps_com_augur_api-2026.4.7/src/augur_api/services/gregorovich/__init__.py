"""Service client for gregorovich."""

from augur_api.services.gregorovich.generated.client import GregorovichClient

__all__ = ["GregorovichClient"]
