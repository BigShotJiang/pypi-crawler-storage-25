"""Service client for customers."""

from augur_api.services.customers.generated.client import CustomersClient

__all__ = ["CustomersClient"]
