"""
Generated Pydantic schemas for customers service.
Source: shared/specs/customers.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import EdgeCacheParams

ContactsUdGetParams = EdgeCacheParams


ContactsRefreshGetParams = EdgeCacheParams


class ContactsCustomersListParams(EdgeCacheParams):
    """Params for GET /contacts/{id}/customers."""

    class5_id: str | None = None
    limit: int | None = None
    offset: int | None = None
    q: str | None = None


ContactsDocListParams = EdgeCacheParams


ContactsWebAllowanceListParams = EdgeCacheParams


class CustomerListParams(EdgeCacheParams):
    """Params for GET /customer."""

    class5_id: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None


class CustomerLookupGetParams(EdgeCacheParams):
    """Params for GET /customer/lookup."""

    limit: int | None = None
    offset: int | None = None
    q: str


class CustomerAddressListParams(EdgeCacheParams):
    """Params for GET /customer/{customerId}/address."""

    limit: int | None = None
    offset: int | None = None
    q: str


class CustomerContactsListParams(EdgeCacheParams):
    """Params for GET /customer/{customerId}/contacts."""

    limit: int | None = None
    offset: int | None = None
    q: str


CustomerDocListParams = EdgeCacheParams


class CustomerInvoicesListParams(EdgeCacheParams):
    """Params for GET /customer/{customerId}/invoices."""

    limit: int | None = None
    offset: int | None = None
    paid_in_full: str | None = None
    q: str
    ship_to_id: int | None = None


CustomerInvoicesGetParams = EdgeCacheParams


class CustomerOrdersListParams(EdgeCacheParams):
    """Params for GET /customer/{customerId}/orders."""

    cancel_flag: str | None = None
    contact_id: str | None = None
    delete_flag: str | None = None
    full_document: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None


CustomerOrdersGetParams = EdgeCacheParams


class CustomerPurchasedItemsListParams(EdgeCacheParams):
    """Params for GET /customer/{customerId}/purchased-items."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


class CustomerQuotesListParams(EdgeCacheParams):
    """Params for GET /customer/{customerId}/quotes."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


CustomerQuotesGetParams = EdgeCacheParams


class CustomerShipToListParams(EdgeCacheParams):
    """Params for GET /customer/{customerId}/ship-to."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


OeContactsCustomerRefreshGetParams = EdgeCacheParams


ShipToRefreshGetParams = EdgeCacheParams
