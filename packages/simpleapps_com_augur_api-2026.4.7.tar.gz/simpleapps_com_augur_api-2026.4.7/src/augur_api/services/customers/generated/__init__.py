"""Generated code for customers service."""
