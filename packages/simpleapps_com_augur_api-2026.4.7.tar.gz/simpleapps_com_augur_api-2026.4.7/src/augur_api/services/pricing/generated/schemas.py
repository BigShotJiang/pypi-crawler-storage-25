"""
Generated Pydantic schemas for pricing service.
Source: shared/specs/pricing.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


class JobPriceHdrListParams(EdgeCacheParams):
    """Params for GET /job-price-hdr."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None


JobPriceHdrGetParams = EdgeCacheParams


class JobPriceHdrLinesListParams(EdgeCacheParams):
    """Params for GET /job-price-hdr/{jobPriceHdrUid}/lines."""

    inv_mast_uid: int | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


JobPriceHdrLinesGetParams = EdgeCacheParams


class PriceEngineListParams(EdgeCacheParams):
    """Params for GET /price-engine."""

    cache_site_id: str | None = None
    cache_ttl: int | None = None
    cart_items: str | None = None
    company_id: str | None = None
    customer_id: int
    item_id: str
    quantity: int | None = None
    ship_to_id: int | None = None
    unit_of_measure: str | None = None


class WebPricingListParams(EdgeCacheParams):
    """Params for GET /web-pricing."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


WebPricingGetParams = EdgeCacheParams


class WebPricingCustomersListParams(EdgeCacheParams):
    """Params for GET /web-pricing/{webPricingUid}/customers."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


WebPricingCustomersGetParams = EdgeCacheParams


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class JobPriceHdrData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    job_price_hdr_uid: int | None = None
    job_no: str | None = None
    job_description: str | None = None
    company_id: str | None = None
    customer_id: float | None = None
    sales_loc_id: float | None = None
    contract_no: str | None = None
    contact_id: str | None = None
    start_date: str | None = None
    end_date: str | None = None
    ship_to_id: float | None = None
    approved: str | None = None
    cancelled: str | None = None
    taker: str | None = None
    po_no: str | None = None
    row_status_flag: int | None = None
    date_last_modified: str | None = None
    date_created: str | None = None
    last_maintained_by: str | None = None
    corp_address_id: float | None = None
    salesrep_id: str | None = None
    currency_line_uid: int | None = None
    currency_conversion: str | None = None
    consignment_flag: str | None = None
    contract_type_cd: int | None = None
    extended_desc: str | None = None
    no_of_periods: int | None = None
    cad_cha_contract_cd: int | None = None
    cad_cha_supplier_id: float | None = None
    cad_cha_quote_no: str | None = None
    cad_cha_location_id: float | None = None
    anniversary_date: str | None = None
    use_totes_flag: str | None = None
    hand_held_add_flag: str | None = None
    update_cd: int | None = None


class JobPriceHdrLinesData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    job_price_line_uid: int | None = None
    job_price_hdr_uid: int | None = None
    inv_mast_uid: int | None = None
    uom: str | None = None
    unit_size: float | None = None
    pricing_method: int | None = None
    source_price: int | None = None
    price: float | None = None
    qty_ordered: float | None = None
    qty_maximum: float | None = None
    other_cost_type_cd: int | None = None
    other_cost_value: float | None = None
    other_cost_source_cd: int | None = None
    other_cost_calc_method_cd: int | None = None
    other_cost_calc_value: float | None = None
    commission_cost_type_cd: int | None = None
    commission_cost_value: float | None = None
    commission_cost_source_cd: int | None = None
    commission_cost_calc_method_cd: int | None = None
    commission_cost_calc_value: float | None = None
    row_status_flag: int | None = None
    date_last_modified: str | None = None
    date_created: str | None = None
    last_maintained_by: str | None = None
    multiplier: float | None = None
    line_no: int | None = None
    source_location_id: float | None = None
    customer_part_no: str | None = None
    expiration_date: str | None = None
    vendor_auth_no: str | None = None
    po_cost: float | None = None
    currency_id: float | None = None
    discount_group_id: str | None = None
    cust_po_no: str | None = None
    item_category_uid: int | None = None
    sub_category_uid: int | None = None
    product_group_id: str | None = None
    terminal_id: float | None = None
    contract_line_cost_page_uid: int | None = None
    contract_line_price_page_uid: int | None = None
    budget_cd: str | None = None
    item_revision_uid: int | None = None
    line_start_date: str | None = None
    initial_commitment_amount: float | None = None
    commitment_amount: float | None = None
    total_commitment_amount: float | None = None
    pick_fee: float | None = None
    cad_purchase_cost: float | None = None
    starting_virtual_inventory_qty: float | None = None
    snapshot_cost: float | None = None
    minimum_mcc_code: str | None = None
    commission_class_id: str | None = None
    commission_override_percent: float | None = None
    update_cd: int | None = None


class PriceEngineData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    unit_price: float | None = None
    priced_from: str | None = None
    price_type: str | None = None
    job_price: float | None = None
    list_price: float | None = None
    customer: str | None = None
    item: str | None = None
    options: str | None = None
    messages: str | None = None
    job_no: str | None = None
    job_price_hdr_uid: int | None = None
    contract_no: str | None = None
    library_price_data: str | None = None
    default_company_price: str | None = None
    web_price: float | None = None


class TaxEngineData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    tax_estimate: float | None = None
    customer_id: float | None = None
    postal_code: str | None = None
    tax_rate: float | None = None
    items: str | None = None


class WebPricingData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    web_pricing_uid: int | None = None
    name: str | None = None
    description: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    status_cd: int | None = None
    update_cd: int | None = None
    process_cd: int | None = None
    sequence_no: int | None = None
    customer_mode: str | None = None
    min_qty: int | None = None
    max_qty: int | None = None
    discount_pct: float | None = None
    effective_date: str | None = None
    expiration_date: str | None = None


class WebPricingCustomersData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    web_pricing_x_customer_uid: int | None = None
    web_pricing_uid: int | None = None
    customer_id: float | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    status_cd: int | None = None
    update_cd: int | None = None
    process_cd: int | None = None
