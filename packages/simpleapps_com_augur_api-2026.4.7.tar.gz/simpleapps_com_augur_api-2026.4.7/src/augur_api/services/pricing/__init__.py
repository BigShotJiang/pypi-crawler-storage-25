"""Service client for pricing."""

from augur_api.services.pricing.generated.client import PricingClient

__all__ = ["PricingClient"]
