"""Service client for commerce."""

from augur_api.services.commerce.generated.client import CommerceClient

__all__ = ["CommerceClient"]
