"""
Generated client for commerce service.
Source: shared/specs/commerce.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.commerce.generated.schemas import (
        CartHdrAlsoBoughtListParams,
        CartHdrListListParams,
        CartHdrLookupGetParams,
        CheckoutDocListParams,
    )


class CartHdrResource(BaseResource):
    """Resource for /cart-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/cart-hdr")

    def list_list(self, params: CartHdrListListParams | None = None) -> BaseResponse[Any]:
        """GET /cart-hdr/list."""
        response = self._get("/list", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_lookup(self, params: CartHdrLookupGetParams | None = None) -> BaseResponse[Any]:
        """GET /cart-hdr/lookup."""
        response = self._get("/lookup", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_also_bought(
        self,
        cart_hdr_uid: int,
        params: CartHdrAlsoBoughtListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /cart-hdr/{cartHdrUid}/also-bought."""
        response = self._get(f"/{cart_hdr_uid}/also-bought", params=params)
        return BaseResponse[Any].model_validate(response)


class CartLineResource(BaseResource):
    """Resource for /cart-line endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/cart-line")

    def delete(self, cart_hdr_uid: int) -> BaseResponse[Any]:
        """DELETE /cart-line/{cartHdrUid}."""
        response = self._delete(f"/{cart_hdr_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, cart_hdr_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /cart-line/{cartHdrUid}."""
        response = self._get(f"/{cart_hdr_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def create_add(self, cart_hdr_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /cart-line/{cartHdrUid}/add."""
        response = self._post(f"/{cart_hdr_uid}/add", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_lines(self, cart_hdr_uid: int, line_no: int) -> BaseResponse[Any]:
        """DELETE /cart-line/{cartHdrUid}/lines/{lineNo}."""
        response = self._delete(f"/{cart_hdr_uid}/lines/{line_no}")
        return BaseResponse[Any].model_validate(response)

    def create_update(self, cart_hdr_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /cart-line/{cartHdrUid}/update."""
        response = self._post(f"/{cart_hdr_uid}/update", data=data)
        return BaseResponse[Any].model_validate(response)


class CheckoutResource(BaseResource):
    """Resource for /checkout endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/checkout")

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /checkout."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def get(self, checkout_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /checkout/{checkoutUid}."""
        response = self._get(f"/{checkout_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update_activate(self, checkout_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /checkout/{checkoutUid}/activate."""
        response = self._put(f"/{checkout_uid}/activate", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_doc(
        self,
        checkout_uid: int,
        params: CheckoutDocListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /checkout/{checkoutUid}/doc."""
        response = self._get(f"/{checkout_uid}/doc", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_doc(
        self,
        checkout_uid: int,
        params: CheckoutDocListParams | None = None,
    ) -> BaseResponse[Any]:
        """Alias for list_doc — GET /checkout/{checkoutUid}/doc."""
        return self.list_doc(checkout_uid, params=params)

    def create_prophet21_hdr(self, checkout_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /checkout/{checkoutUid}/prophet21-hdr."""
        response = self._post(f"/{checkout_uid}/prophet21-hdr", data=data)
        return BaseResponse[Any].model_validate(response)

    def create_prophet21_hdr_prophet21_line(
        self,
        checkout_uid: int,
        prophet21_hdr_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """POST /checkout/{checkoutUid}/prophet21-hdr/{prophet21HdrUid}/prophet21-line."""
        response = self._post(
            f"/{checkout_uid}/prophet21-hdr/{prophet21_hdr_uid}/prophet21-line",
            data=data,
        )
        return BaseResponse[Any].model_validate(response)

    def update_validate(self, checkout_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /checkout/{checkoutUid}/validate."""
        response = self._put(f"/{checkout_uid}/validate", data=data)
        return BaseResponse[Any].model_validate(response)


class CommerceClient(BaseServiceClient):
    """Client for the commerce service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._cart_hdr: CartHdrResource | None = None
        self._cart_line: CartLineResource | None = None
        self._checkout: CheckoutResource | None = None

    @property
    def cart_hdr(self) -> CartHdrResource:
        """Access cartHdr endpoints."""
        if self._cart_hdr is None:
            self._cart_hdr = CartHdrResource(self._http)
        return self._cart_hdr

    @property
    def cart_line(self) -> CartLineResource:
        """Access cartLine endpoints."""
        if self._cart_line is None:
            self._cart_line = CartLineResource(self._http)
        return self._cart_line

    @property
    def checkout(self) -> CheckoutResource:
        """Access checkout endpoints."""
        if self._checkout is None:
            self._checkout = CheckoutResource(self._http)
        return self._checkout
