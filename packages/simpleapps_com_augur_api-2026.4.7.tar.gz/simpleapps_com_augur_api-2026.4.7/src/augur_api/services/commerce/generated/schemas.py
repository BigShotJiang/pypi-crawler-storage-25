"""
Generated Pydantic schemas for commerce service.
Source: shared/specs/commerce.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import EdgeCacheParams


class CartHdrListListParams(EdgeCacheParams):
    """Params for GET /cart-hdr/list."""

    user_id: int


class CartHdrLookupGetParams(EdgeCacheParams):
    """Params for GET /cart-hdr/lookup."""

    cart_token: str | None = None
    contact_id: int
    customer_id: int
    user_cart_no: int | None = None
    user_id: int


class CartHdrAlsoBoughtListParams(EdgeCacheParams):
    """Params for GET /cart-hdr/{cartHdrUid}/also-bought."""

    limit: int | None = None
    offset: int | None = None


CartLineGetParams = EdgeCacheParams


CheckoutGetParams = EdgeCacheParams


class CheckoutDocListParams(EdgeCacheParams):
    """Params for GET /checkout/{checkoutUid}/doc."""

    cart_hdr_uid: int | None = None
