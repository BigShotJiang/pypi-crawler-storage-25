"""Generated code for commerce service."""
