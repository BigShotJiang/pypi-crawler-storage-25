"""Service client for open_search."""

from augur_api.services.open_search.generated.client import OpenSearchClient

__all__ = ["OpenSearchClient"]
