"""
Generated Pydantic schemas for open-search service.
Source: shared/specs/open-search.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


class ItemSearchListParams(EdgeCacheParams):
    """Params for GET /item-search."""

    class_id5_exclude_list: str | None = None
    class_id5_list: str | None = None
    discontinued_any: str | None = None
    fields: str | None = None
    filters: str | None = None
    from_: int | None = None
    item_category_uid_list: str | None = None
    job_numbers: str | None = None
    operator: str | None = None
    parent_category_uid: int | None = None
    q: str
    search_type: str
    size: int | None = None
    sort: str | None = None
    source_fields_list: str | None = None
    stock_status: str | None = None
    tags: str | None = None
    variant_filter: str | None = None


class ItemSearchAttributesListParams(EdgeCacheParams):
    """Params for GET /item-search/attributes."""

    cache_site_id: str | None = None
    cache_ttl: int | None = None
    filters: str | None = None
    q: str
    search_type: str


class ItemsListParams(EdgeCacheParams):
    """Params for GET /items."""

    item_id: str | None = None
    limit: int | None = None
    offset: int | None = None
    online: str | None = None
    status_cd: int | None = None


ItemsGetParams = EdgeCacheParams


ItemsRefreshGetParams = EdgeCacheParams


class SuggestionsListParams(EdgeCacheParams):
    """Params for GET /suggestions."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    process_cd: int | None = None
    query: str | None = None
    query_string_uid: int | None = None
    status_cd: int | None = None


class SuggestionsSuggestListParams(EdgeCacheParams):
    """Params for GET /suggestions/suggest."""

    limit: int | None = None
    offset: int | None = None
    q: str | None = None


SuggestionsGetParams = EdgeCacheParams


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class SuggestionsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    suggestions_uid: int | None = None
    query_string_uid: int | None = None
    suggestions_string: str | None = None
    suggestions_metaphone: str | None = None
    avg_total_results: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
