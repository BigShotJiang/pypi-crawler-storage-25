"""
Generated client for open-search service.
Source: shared/specs/open-search.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.open_search.generated.schemas import (
        ItemSearchAttributesListParams,
        ItemSearchListParams,
        ItemsListParams,
        SuggestionsListParams,
        SuggestionsSuggestListParams,
    )


class ItemSearchResource(BaseResource):
    """Resource for /item-search endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/item-search")

    def list(self, params: ItemSearchListParams | None = None) -> BaseResponse[Any]:
        """GET /item-search."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def list_attributes(
        self,
        params: ItemSearchAttributesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /item-search/attributes."""
        response = self._get("/attributes", params=params)
        return BaseResponse[Any].model_validate(response)


class ItemsResource(BaseResource):
    """Resource for /items endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/items")

    def list(self, params: ItemsListParams | None = None) -> BaseResponse[Any]:
        """GET /items."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def update_refresh(self, data: Any = None) -> BaseResponse[Any]:
        """PUT /items/refresh."""
        response = self._put("/refresh", data=data)
        return BaseResponse[Any].model_validate(response)

    def get(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /items/{invMastUid}."""
        response = self._get(f"/{inv_mast_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, inv_mast_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /items/{invMastUid}."""
        response = self._put(f"/{inv_mast_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def get_refresh(
        self,
        inv_mast_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /items/{invMastUid}/refresh."""
        response = self._get(f"/{inv_mast_uid}/refresh", params=options)
        return BaseResponse[Any].model_validate(response)


class SuggestionsResource(BaseResource):
    """Resource for /suggestions endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/suggestions")

    def list(self, params: SuggestionsListParams | None = None) -> BaseResponse[Any]:
        """GET /suggestions."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def list_suggest(self, params: SuggestionsSuggestListParams | None = None) -> BaseResponse[Any]:
        """GET /suggestions/suggest."""
        response = self._get("/suggest", params=params)
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        suggestions_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /suggestions/{suggestionsUid}."""
        response = self._get(f"/{suggestions_uid}", params=options)
        return BaseResponse[Any].model_validate(response)


class OpenSearchClient(BaseServiceClient):
    """Client for the open-search service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._item_search: ItemSearchResource | None = None
        self._items: ItemsResource | None = None
        self._suggestions: SuggestionsResource | None = None

    @property
    def item_search(self) -> ItemSearchResource:
        """Access itemSearch endpoints."""
        if self._item_search is None:
            self._item_search = ItemSearchResource(self._http)
        return self._item_search

    @property
    def items(self) -> ItemsResource:
        """Access items endpoints."""
        if self._items is None:
            self._items = ItemsResource(self._http)
        return self._items

    @property
    def suggestions(self) -> SuggestionsResource:
        """Access suggestions endpoints."""
        if self._suggestions is None:
            self._suggestions = SuggestionsResource(self._http)
        return self._suggestions
