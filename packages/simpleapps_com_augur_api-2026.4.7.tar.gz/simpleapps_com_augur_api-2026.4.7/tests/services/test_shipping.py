"""Tests for the Shipping service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

from augur_api.services.shipping import ShippingClient
from augur_api.services.shipping.generated.client import RatesResource

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.service_name = "shipping"
    return http


class TestShippingClient:
    """Tests for ShippingClient lazy property initialisation."""

    def test_rates(self) -> None:
        client = ShippingClient(mock_http())
        assert isinstance(client.rates, RatesResource)

    def test_lazy_caching(self) -> None:
        client = ShippingClient(mock_http())
        assert client.rates is client.rates


class TestRatesResource:
    """Tests for /rates endpoints."""

    def test_create(self) -> None:
        http = mock_http()
        r = RatesResource(http)
        result = r.create(data={"originZip": "90210", "destinationZip": "10001"})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/rates"
        assert result.status == 200
