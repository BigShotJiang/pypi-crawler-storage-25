"""Tests for the Smarty Streets service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

from augur_api.services.smarty_streets import SmartyStreetsClient
from augur_api.services.smarty_streets.generated.client import UsResource
from augur_api.services.smarty_streets.generated.schemas import UsLookupGetParams

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "smarty-streets"
    return http


class TestSmartyStreetsClient:
    """Tests for SmartyStreetsClient lazy property initialisation."""

    def test_us(self) -> None:
        client = SmartyStreetsClient(mock_http())
        assert isinstance(client.us, UsResource)

    def test_lazy_caching(self) -> None:
        """Accessing the same property twice returns the same instance."""
        client = SmartyStreetsClient(mock_http())
        first = client.us
        second = client.us
        assert first is second


class TestUsResource:
    """Tests for /us endpoints."""

    def test_get_lookup(self) -> None:
        http = mock_http()
        r = UsResource(http)
        result = r.get_lookup()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/us/lookup"
        assert result.status == 200

    def test_get_lookup_with_params(self) -> None:
        http = mock_http()
        r = UsResource(http)
        params = UsLookupGetParams(
            address1="123 Main St",
            address2="",
            city="Provo",
            state="UT",
            postal_code="84606",
        )
        result = r.get_lookup(params=params)
        http.get.assert_called_once()
        assert result.status == 200
