"""Tests for the UPS service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

from augur_api.services.ups import UpsClient
from augur_api.services.ups.generated.client import RatesShopResource

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.service_name = "ups"
    return http


class TestUpsClient:
    """Tests for UpsClient lazy property initialisation."""

    def test_rates_shop(self) -> None:
        client = UpsClient(mock_http())
        assert isinstance(client.rates_shop, RatesShopResource)

    def test_lazy_caching(self) -> None:
        client = UpsClient(mock_http())
        assert client.rates_shop is client.rates_shop


class TestRatesShopResource:
    """Tests for /rates-shop endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = RatesShopResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/rates-shop"
        assert result.status == 200
