"""Tests for the P21 Core service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.p21_core import P21CoreClient
from augur_api.services.p21_core.generated.client import (
    AddressResource,
    CashDrawerResource,
    CodeP21Resource,
    CompanyResource,
    LocationResource,
    PaymentTypesResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


@pytest.fixture
def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "p21-core"
    return http


class TestP21CoreClient:
    """Tests for P21CoreClient lazy property initialisation."""

    def test_address(self, mock_http: MagicMock) -> None:
        client = P21CoreClient(mock_http)
        assert isinstance(client.address, AddressResource)

    def test_cash_drawer(self, mock_http: MagicMock) -> None:
        client = P21CoreClient(mock_http)
        assert isinstance(client.cash_drawer, CashDrawerResource)

    def test_code_p21(self, mock_http: MagicMock) -> None:
        client = P21CoreClient(mock_http)
        assert isinstance(client.code_p21, CodeP21Resource)

    def test_company(self, mock_http: MagicMock) -> None:
        client = P21CoreClient(mock_http)
        assert isinstance(client.company, CompanyResource)

    def test_location(self, mock_http: MagicMock) -> None:
        client = P21CoreClient(mock_http)
        assert isinstance(client.location, LocationResource)

    def test_payment_types(self, mock_http: MagicMock) -> None:
        client = P21CoreClient(mock_http)
        assert isinstance(client.payment_types, PaymentTypesResource)

    def test_lazy_caching(self, mock_http: MagicMock) -> None:
        client = P21CoreClient(mock_http)
        assert client.address is client.address
        assert client.cash_drawer is client.cash_drawer
        assert client.code_p21 is client.code_p21
        assert client.company is client.company
        assert client.location is client.location
        assert client.payment_types is client.payment_types


class TestAddressResource:
    """Tests for /address endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = AddressResource(mock_http)
        result = r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/address"
        assert result.status == 200

    def test_get_refresh(self, mock_http: MagicMock) -> None:
        r = AddressResource(mock_http)
        r.get_refresh()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/address/refresh"

    def test_get(self, mock_http: MagicMock) -> None:
        r = AddressResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/address/1"

    def test_list_corp_address(self, mock_http: MagicMock) -> None:
        r = AddressResource(mock_http)
        r.list_corp_address(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/address/1/corp-address"

    def test_list_default(self, mock_http: MagicMock) -> None:
        r = AddressResource(mock_http)
        r.list_default(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/address/1/default"

    def test_get_enable(self, mock_http: MagicMock) -> None:
        r = AddressResource(mock_http)
        r.get_enable(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/address/1/enable"


class TestCashDrawerResource:
    """Tests for /cash_drawer endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = CashDrawerResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/cash-drawer"

    def test_get(self, mock_http: MagicMock) -> None:
        r = CashDrawerResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/cash-drawer/1"


class TestCodeP21Resource:
    """Tests for /code-p21 endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = CodeP21Resource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/code-p21"


class TestCompanyResource:
    """Tests for /company endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = CompanyResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/company"

    def test_get(self, mock_http: MagicMock) -> None:
        r = CompanyResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/company/1"


class TestLocationResource:
    """Tests for /location endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = LocationResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/location"

    def test_get(self, mock_http: MagicMock) -> None:
        r = LocationResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/location/1"


class TestPaymentTypesResource:
    """Tests for /payment-types endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = PaymentTypesResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/payment-types"


class TestResponseValidation:
    """Verify BaseResponse[Any] is returned correctly."""

    def test_list_returns_base_response(self, mock_http: MagicMock) -> None:
        r = AddressResource(mock_http)
        result = r.list()
        assert result.status == 200
        assert result.message == "Success"

    def test_get_returns_base_response(self, mock_http: MagicMock) -> None:
        r = CompanyResource(mock_http)
        result = r.get(1)
        assert result.data == {"id": 1}
