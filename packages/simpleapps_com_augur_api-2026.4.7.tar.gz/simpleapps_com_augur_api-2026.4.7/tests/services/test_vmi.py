"""Tests for the VMI service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.vmi import VmiClient
from augur_api.services.vmi.generated.client import (
    DistributorsResource,
    InvProfileHdrResource,
    ProductsResource,
    RestockHdrResource,
    SectionsResource,
    WarehouseResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


@pytest.fixture
def mock_http() -> MagicMock:
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "vmi"
    return http


class TestVmiClient:
    def test_distributors(self, mock_http: MagicMock) -> None:
        client = VmiClient(mock_http)
        assert isinstance(client.distributors, DistributorsResource)

    def test_inv_profile_hdr(self, mock_http: MagicMock) -> None:
        client = VmiClient(mock_http)
        assert isinstance(client.inv_profile_hdr, InvProfileHdrResource)

    def test_products(self, mock_http: MagicMock) -> None:
        client = VmiClient(mock_http)
        assert isinstance(client.products, ProductsResource)

    def test_restock_hdr(self, mock_http: MagicMock) -> None:
        client = VmiClient(mock_http)
        assert isinstance(client.restock_hdr, RestockHdrResource)

    def test_sections(self, mock_http: MagicMock) -> None:
        client = VmiClient(mock_http)
        assert isinstance(client.sections, SectionsResource)

    def test_warehouse(self, mock_http: MagicMock) -> None:
        client = VmiClient(mock_http)
        assert isinstance(client.warehouse, WarehouseResource)

    def test_lazy_caching(self, mock_http: MagicMock) -> None:
        client = VmiClient(mock_http)
        assert client.distributors is client.distributors
        assert client.inv_profile_hdr is client.inv_profile_hdr
        assert client.products is client.products
        assert client.restock_hdr is client.restock_hdr
        assert client.sections is client.sections
        assert client.warehouse is client.warehouse


class TestDistributorsResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = DistributorsResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/distributors"

    def test_create(self, mock_http: MagicMock) -> None:
        r = DistributorsResource(mock_http)
        r.create(data={"name": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/distributors"

    def test_get(self, mock_http: MagicMock) -> None:
        r = DistributorsResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/distributors/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = DistributorsResource(mock_http)
        r.update(1, data={"name": "updated"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/distributors/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = DistributorsResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/distributors/1"

    def test_update_enable(self, mock_http: MagicMock) -> None:
        r = DistributorsResource(mock_http)
        r.update_enable(1, data={"enabled": True})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/distributors/1/enable"

    def test_create_products(self, mock_http: MagicMock) -> None:
        r = DistributorsResource(mock_http)
        r.create_products(1, data={"productId": 123})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/distributors/1/products"


class TestInvProfileHdrResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = InvProfileHdrResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-profile-hdr"

    def test_create(self, mock_http: MagicMock) -> None:
        r = InvProfileHdrResource(mock_http)
        r.create(data={"name": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/inv-profile-hdr"

    def test_create_upload(self, mock_http: MagicMock) -> None:
        r = InvProfileHdrResource(mock_http)
        r.create_upload(123, data={"file": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/inv-profile-hdr/123/upload"

    def test_get(self, mock_http: MagicMock) -> None:
        r = InvProfileHdrResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-profile-hdr/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = InvProfileHdrResource(mock_http)
        r.update(1)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/inv-profile-hdr/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = InvProfileHdrResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/inv-profile-hdr/1"

    def test_list_inv_profile_line(self, mock_http: MagicMock) -> None:
        r = InvProfileHdrResource(mock_http)
        r.list_inv_profile_line(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-profile-hdr/1/inv-profile-line"

    def test_create_inv_profile_line(self, mock_http: MagicMock) -> None:
        r = InvProfileHdrResource(mock_http)
        r.create_inv_profile_line(1, data={"item": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/inv-profile-hdr/1/inv-profile-line"

    def test_get_inv_profile_line(self, mock_http: MagicMock) -> None:
        r = InvProfileHdrResource(mock_http)
        r.get_inv_profile_line(1, 2)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-profile-hdr/1/inv-profile-line/2"

    def test_update_inv_profile_line(self, mock_http: MagicMock) -> None:
        r = InvProfileHdrResource(mock_http)
        r.update_inv_profile_line(1, 2)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/inv-profile-hdr/1/inv-profile-line/2"

    def test_delete_inv_profile_line(self, mock_http: MagicMock) -> None:
        r = InvProfileHdrResource(mock_http)
        r.delete_inv_profile_line(1, 2)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/inv-profile-hdr/1/inv-profile-line/2"


class TestProductsResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = ProductsResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/products"

    def test_list_find(self, mock_http: MagicMock) -> None:
        r = ProductsResource(mock_http)
        r.list_find()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/products/find"

    def test_get(self, mock_http: MagicMock) -> None:
        r = ProductsResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/products/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = ProductsResource(mock_http)
        r.update(1)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/products/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = ProductsResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/products/1"

    def test_update_enable(self, mock_http: MagicMock) -> None:
        r = ProductsResource(mock_http)
        r.update_enable(1)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/products/1/enable"


class TestRestockHdrResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = RestockHdrResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/restock-hdr"

    def test_create(self, mock_http: MagicMock) -> None:
        r = RestockHdrResource(mock_http)
        r.create(data={"test": True})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/restock-hdr"

    def test_get(self, mock_http: MagicMock) -> None:
        r = RestockHdrResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/restock-hdr/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = RestockHdrResource(mock_http)
        r.update(1)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/restock-hdr/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = RestockHdrResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/restock-hdr/1"


class TestSectionsResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = SectionsResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/sections"

    def test_create(self, mock_http: MagicMock) -> None:
        r = SectionsResource(mock_http)
        r.create(data={"test": True})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/sections"

    def test_get(self, mock_http: MagicMock) -> None:
        r = SectionsResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/sections/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = SectionsResource(mock_http)
        r.update(1)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/sections/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = SectionsResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/sections/1"

    def test_update_enable(self, mock_http: MagicMock) -> None:
        r = SectionsResource(mock_http)
        r.update_enable(1)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/sections/1/enable"


class TestWarehouseResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/warehouse"

    def test_create(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.create(data={"test": True})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/warehouse"

    def test_get(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/warehouse/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.update(1)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/warehouse/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/warehouse/1"

    def test_create_adjust(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.create_adjust(1)
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/warehouse/1/adjust"

    def test_list_availability(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.list_availability(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/warehouse/1/availability"

    def test_update_enable(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.update_enable(1)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/warehouse/1/enable"

    def test_create_receive(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.create_receive(1)
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/warehouse/1/receive"

    def test_list_replenish(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.list_replenish(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/warehouse/1/replenish"

    def test_create_replenish(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.create_replenish(1)
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/warehouse/1/replenish"

    def test_create_transfer(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.create_transfer(1)
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/warehouse/1/transfer"

    def test_create_usage(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.create_usage(1)
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/warehouse/1/usage"

    def test_list_users(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.list_users(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/warehouse/1/users"

    def test_create_users(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.create_users(1)
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/warehouse/1/users"

    def test_get_users(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.get_users(1, 2)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/warehouse/1/users/2"

    def test_update_users(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.update_users(1, 2)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/warehouse/1/users/2"

    def test_delete_users(self, mock_http: MagicMock) -> None:
        r = WarehouseResource(mock_http)
        r.delete_users(1, 2)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/warehouse/1/users/2"


class TestResponseValidation:
    def test_returns_base_response(self, mock_http: MagicMock) -> None:
        r = DistributorsResource(mock_http)
        result = r.list()
        assert result.status == 200
        assert result.data == {"id": 1}
