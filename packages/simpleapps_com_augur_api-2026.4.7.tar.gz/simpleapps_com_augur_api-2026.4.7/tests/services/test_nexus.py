"""Tests for the Nexus service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

from augur_api.services.nexus import NexusClient
from augur_api.services.nexus.generated.client import (
    BinTransferResource,
    PurchaseOrderReceiptResource,
    ReceivingResource,
    TransferReceiptResource,
    TransferResource,
    TransferShippingResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "nexus"
    return http


class TestNexusClient:
    """Tests for NexusClient lazy property initialisation."""

    def test_bin_transfer(self) -> None:
        client = NexusClient(mock_http())
        assert isinstance(client.bin_transfer, BinTransferResource)

    def test_purchase_order_receipt(self) -> None:
        client = NexusClient(mock_http())
        assert isinstance(client.purchase_order_receipt, PurchaseOrderReceiptResource)

    def test_receiving(self) -> None:
        client = NexusClient(mock_http())
        assert isinstance(client.receiving, ReceivingResource)

    def test_transfer(self) -> None:
        client = NexusClient(mock_http())
        assert isinstance(client.transfer, TransferResource)

    def test_transfer_receipt(self) -> None:
        client = NexusClient(mock_http())
        assert isinstance(client.transfer_receipt, TransferReceiptResource)

    def test_transfer_shipping(self) -> None:
        client = NexusClient(mock_http())
        assert isinstance(client.transfer_shipping, TransferShippingResource)

    def test_lazy_caching(self) -> None:
        """Accessing the same property twice returns the same instance."""
        client = NexusClient(mock_http())
        assert client.bin_transfer is client.bin_transfer
        assert client.purchase_order_receipt is client.purchase_order_receipt
        assert client.receiving is client.receiving
        assert client.transfer is client.transfer
        assert client.transfer_receipt is client.transfer_receipt
        assert client.transfer_shipping is client.transfer_shipping


class TestBinTransferResource:
    """Tests for /bin-transfer endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = BinTransferResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/bin-transfer"
        assert result.status == 200

    def test_get(self) -> None:
        http = mock_http()
        r = BinTransferResource(http)
        result = r.get(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/bin-transfer/1"
        assert result.status == 200

    def test_create(self) -> None:
        http = mock_http()
        r = BinTransferResource(http)
        result = r.create(data={})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/bin-transfer"
        assert result.status == 200

    def test_update(self) -> None:
        http = mock_http()
        r = BinTransferResource(http)
        result = r.update(1, data={})
        http.put.assert_called_once()
        assert http.put.call_args[0][0] == "/bin-transfer/1"
        assert result.status == 200

    def test_delete(self) -> None:
        http = mock_http()
        r = BinTransferResource(http)
        result = r.delete(1)
        http.delete.assert_called_once()
        assert http.delete.call_args[0][0] == "/bin-transfer/1"
        assert result.status == 200

    def test_list_status(self) -> None:
        http = mock_http()
        r = BinTransferResource(http)
        result = r.list_status(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/bin-transfer/1/status"
        assert result.status == 200


class TestPurchaseOrderReceiptResource:
    """Tests for /purchase-order-receipt endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = PurchaseOrderReceiptResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/purchase-order-receipt"
        assert result.status == 200

    def test_get(self) -> None:
        http = mock_http()
        r = PurchaseOrderReceiptResource(http)
        result = r.get(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/purchase-order-receipt/1"
        assert result.status == 200

    def test_create(self) -> None:
        http = mock_http()
        r = PurchaseOrderReceiptResource(http)
        result = r.create(data={})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/purchase-order-receipt"
        assert result.status == 200

    def test_update(self) -> None:
        http = mock_http()
        r = PurchaseOrderReceiptResource(http)
        result = r.update(1, data={})
        http.put.assert_called_once()
        assert http.put.call_args[0][0] == "/purchase-order-receipt/1"
        assert result.status == 200

    def test_delete(self) -> None:
        http = mock_http()
        r = PurchaseOrderReceiptResource(http)
        result = r.delete(1)
        http.delete.assert_called_once()
        assert http.delete.call_args[0][0] == "/purchase-order-receipt/1"
        assert result.status == 200


class TestReceivingResource:
    """Tests for /receiving endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = ReceivingResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/receiving"
        assert result.status == 200

    def test_get(self) -> None:
        http = mock_http()
        r = ReceivingResource(http)
        result = r.get(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/receiving/1"
        assert result.status == 200

    def test_create(self) -> None:
        http = mock_http()
        r = ReceivingResource(http)
        result = r.create(data={})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/receiving"
        assert result.status == 200

    def test_update(self) -> None:
        http = mock_http()
        r = ReceivingResource(http)
        result = r.update(1, data={})
        http.put.assert_called_once()
        assert http.put.call_args[0][0] == "/receiving/1"
        assert result.status == 200

    def test_delete(self) -> None:
        http = mock_http()
        r = ReceivingResource(http)
        result = r.delete(1)
        http.delete.assert_called_once()
        assert http.delete.call_args[0][0] == "/receiving/1"
        assert result.status == 200


class TestTransferResource:
    """Tests for /transfer endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = TransferResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/transfer"
        assert result.status == 200

    def test_get(self) -> None:
        http = mock_http()
        r = TransferResource(http)
        result = r.get(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/transfer/1"
        assert result.status == 200

    def test_create(self) -> None:
        http = mock_http()
        r = TransferResource(http)
        result = r.create(data={})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/transfer"
        assert result.status == 200

    def test_update(self) -> None:
        http = mock_http()
        r = TransferResource(http)
        result = r.update(1, data={})
        http.put.assert_called_once()
        assert http.put.call_args[0][0] == "/transfer/1"
        assert result.status == 200

    def test_delete(self) -> None:
        http = mock_http()
        r = TransferResource(http)
        result = r.delete(1)
        http.delete.assert_called_once()
        assert http.delete.call_args[0][0] == "/transfer/1"
        assert result.status == 200


class TestTransferReceiptResource:
    """Tests for /transfer-receipt endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = TransferReceiptResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/transfer-receipt"
        assert result.status == 200

    def test_get(self) -> None:
        http = mock_http()
        r = TransferReceiptResource(http)
        result = r.get(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/transfer-receipt/1"
        assert result.status == 200

    def test_create(self) -> None:
        http = mock_http()
        r = TransferReceiptResource(http)
        result = r.create(data={})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/transfer-receipt"
        assert result.status == 200

    def test_update(self) -> None:
        http = mock_http()
        r = TransferReceiptResource(http)
        result = r.update(1, data={})
        http.put.assert_called_once()
        assert http.put.call_args[0][0] == "/transfer-receipt/1"
        assert result.status == 200

    def test_delete(self) -> None:
        http = mock_http()
        r = TransferReceiptResource(http)
        result = r.delete(1)
        http.delete.assert_called_once()
        assert http.delete.call_args[0][0] == "/transfer-receipt/1"
        assert result.status == 200


class TestTransferShippingResource:
    """Tests for /transfer-shipping endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = TransferShippingResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/transfer-shipping"
        assert result.status == 200

    def test_get(self) -> None:
        http = mock_http()
        r = TransferShippingResource(http)
        result = r.get(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/transfer-shipping/1"
        assert result.status == 200

    def test_create(self) -> None:
        http = mock_http()
        r = TransferShippingResource(http)
        result = r.create(data={})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/transfer-shipping"
        assert result.status == 200

    def test_update(self) -> None:
        http = mock_http()
        r = TransferShippingResource(http)
        result = r.update(1, data={})
        http.put.assert_called_once()
        assert http.put.call_args[0][0] == "/transfer-shipping/1"
        assert result.status == 200

    def test_delete(self) -> None:
        http = mock_http()
        r = TransferShippingResource(http)
        result = r.delete(1)
        http.delete.assert_called_once()
        assert http.delete.call_args[0][0] == "/transfer-shipping/1"
        assert result.status == 200
