"""Tests for the Items service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.items import ItemsClient
from augur_api.services.items.generated.client import (
    AttributeGroupsResource,
    AttributesResource,
    BrandsResource,
    CategoriesResource,
    ContractsResource,
    InternalResource,
    InvLocResource,
    InvMastLinksResource,
    InvMastResource,
    InvMastSubPartsResource,
    InvMastUdResource,
    ItemCategoryResource,
    ItemFavoritesResource,
    ItemUomResource,
    ItemWishlistResource,
    LocationsResource,
    P21Resource,
    VariantsResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


@pytest.fixture
def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "items"
    return http


# ============================================================================
# ItemsClient — lazy property access
# ============================================================================


class TestItemsClient:
    """Tests for ItemsClient lazy property initialisation."""

    def test_attribute_groups(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.attribute_groups, AttributeGroupsResource)

    def test_attributes(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.attributes, AttributesResource)

    def test_brands(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.brands, BrandsResource)

    def test_categories(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.categories, CategoriesResource)

    def test_contracts(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.contracts, ContractsResource)

    def test_internal(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.internal, InternalResource)

    def test_inv_loc(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.inv_loc, InvLocResource)

    def test_inv_mast(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.inv_mast, InvMastResource)

    def test_inv_mast_links(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.inv_mast_links, InvMastLinksResource)

    def test_inv_mast_sub_parts(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.inv_mast_sub_parts, InvMastSubPartsResource)

    def test_inv_mast_ud(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.inv_mast_ud, InvMastUdResource)

    def test_item_category(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.item_category, ItemCategoryResource)

    def test_item_favorites(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.item_favorites, ItemFavoritesResource)

    def test_item_uom(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.item_uom, ItemUomResource)

    def test_item_wishlist(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.item_wishlist, ItemWishlistResource)

    def test_locations(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.locations, LocationsResource)

    def test_p21(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.p21, P21Resource)

    def test_variants(self, mock_http: MagicMock) -> None:
        client = ItemsClient(mock_http)
        assert isinstance(client.variants, VariantsResource)

    def test_lazy_caching(self, mock_http: MagicMock) -> None:
        """Accessing the same property twice returns the same instance."""
        client = ItemsClient(mock_http)
        assert client.attribute_groups is client.attribute_groups
        assert client.attributes is client.attributes
        assert client.brands is client.brands
        assert client.categories is client.categories
        assert client.contracts is client.contracts
        assert client.internal is client.internal
        assert client.inv_loc is client.inv_loc
        assert client.inv_mast is client.inv_mast
        assert client.inv_mast_links is client.inv_mast_links
        assert client.inv_mast_sub_parts is client.inv_mast_sub_parts
        assert client.inv_mast_ud is client.inv_mast_ud
        assert client.item_category is client.item_category
        assert client.item_favorites is client.item_favorites
        assert client.item_uom is client.item_uom
        assert client.item_wishlist is client.item_wishlist
        assert client.locations is client.locations
        assert client.p21 is client.p21
        assert client.variants is client.variants


# ============================================================================
# AttributeGroupsResource
# ============================================================================


class TestAttributeGroupsResource:
    """Tests for /attribute-groups endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = AttributeGroupsResource(mock_http)
        result = r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/attribute-groups"
        assert result.status == 200

    def test_create(self, mock_http: MagicMock) -> None:
        r = AttributeGroupsResource(mock_http)
        r.create(data={"name": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/attribute-groups"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = AttributeGroupsResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/attribute-groups/1"

    def test_get(self, mock_http: MagicMock) -> None:
        r = AttributeGroupsResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/attribute-groups/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = AttributeGroupsResource(mock_http)
        r.update(1, data={"name": "updated"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/attribute-groups/1"

    def test_list_attributes(self, mock_http: MagicMock) -> None:
        r = AttributeGroupsResource(mock_http)
        r.list_attributes(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/attribute-groups/1/attributes"

    def test_create_attributes(self, mock_http: MagicMock) -> None:
        r = AttributeGroupsResource(mock_http)
        r.create_attributes(1, data={"test": True})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/attribute-groups/1/attributes"

    def test_delete_attributes(self, mock_http: MagicMock) -> None:
        r = AttributeGroupsResource(mock_http)
        r.delete_attributes(1, 2)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/attribute-groups/1/attributes/2"

    def test_get_attributes(self, mock_http: MagicMock) -> None:
        r = AttributeGroupsResource(mock_http)
        r.get_attributes(1, 2)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/attribute-groups/1/attributes/2"

    def test_update_attributes(self, mock_http: MagicMock) -> None:
        r = AttributeGroupsResource(mock_http)
        r.update_attributes(1, 2, data={"test": True})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/attribute-groups/1/attributes/2"


# ============================================================================
# AttributesResource
# ============================================================================


class TestAttributesResource:
    """Tests for /attributes endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = AttributesResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/attributes"

    def test_create(self, mock_http: MagicMock) -> None:
        r = AttributesResource(mock_http)
        r.create(data={"name": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/attributes"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = AttributesResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/attributes/1"

    def test_get(self, mock_http: MagicMock) -> None:
        r = AttributesResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/attributes/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = AttributesResource(mock_http)
        r.update(1, data={"name": "updated"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/attributes/1"

    def test_list_values(self, mock_http: MagicMock) -> None:
        r = AttributesResource(mock_http)
        r.list_values(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/attributes/1/values"

    def test_create_values(self, mock_http: MagicMock) -> None:
        r = AttributesResource(mock_http)
        r.create_values(1, data={"value": "x"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/attributes/1/values"

    def test_delete_values(self, mock_http: MagicMock) -> None:
        r = AttributesResource(mock_http)
        r.delete_values(1, 2)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/attributes/1/values/2"

    def test_get_values(self, mock_http: MagicMock) -> None:
        r = AttributesResource(mock_http)
        r.get_values(1, 2)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/attributes/1/values/2"

    def test_update_values(self, mock_http: MagicMock) -> None:
        r = AttributesResource(mock_http)
        r.update_values(1, 2, data={"value": "y"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/attributes/1/values/2"


# ============================================================================
# BrandsResource
# ============================================================================


class TestBrandsResource:
    """Tests for /brands endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = BrandsResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/brands"

    def test_create(self, mock_http: MagicMock) -> None:
        r = BrandsResource(mock_http)
        r.create(data={"name": "brand"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/brands"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = BrandsResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/brands/1"

    def test_get(self, mock_http: MagicMock) -> None:
        r = BrandsResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/brands/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = BrandsResource(mock_http)
        r.update(1, data={"name": "updated"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/brands/1"

    def test_list_attributes(self, mock_http: MagicMock) -> None:
        r = BrandsResource(mock_http)
        r.list_attributes(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/brands/1/attributes"

    def test_list_items(self, mock_http: MagicMock) -> None:
        r = BrandsResource(mock_http)
        r.list_items(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/brands/1/items"


# ============================================================================
# CategoriesResource
# ============================================================================


class TestCategoriesResource:
    """Tests for /categories endpoints."""

    def test_get_lookup(self, mock_http: MagicMock) -> None:
        r = CategoriesResource(mock_http)
        r.get_lookup()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/categories/lookup"

    def test_get(self, mock_http: MagicMock) -> None:
        r = CategoriesResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/categories/1"

    def test_list_attributes(self, mock_http: MagicMock) -> None:
        r = CategoriesResource(mock_http)
        r.list_attributes(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/categories/1/attributes"

    def test_list_images(self, mock_http: MagicMock) -> None:
        r = CategoriesResource(mock_http)
        r.list_images(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/categories/1/images"

    def test_list_items(self, mock_http: MagicMock) -> None:
        r = CategoriesResource(mock_http)
        r.list_items(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/categories/1/items"


# ============================================================================
# ContractsResource
# ============================================================================


class TestContractsResource:
    """Tests for /contracts endpoints."""

    def test_list_attributes(self, mock_http: MagicMock) -> None:
        r = ContractsResource(mock_http)
        r.list_attributes(100)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/contracts/100/attributes"

    def test_list_items(self, mock_http: MagicMock) -> None:
        r = ContractsResource(mock_http)
        r.list_items(100)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/contracts/100/items"


# ============================================================================
# InternalResource
# ============================================================================


class TestInternalResource:
    """Tests for /internal endpoints."""

    def test_create_pdf(self, mock_http: MagicMock) -> None:
        r = InternalResource(mock_http)
        r.create_pdf(data={"html": "<p>test</p>"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/internal/pdf"


# ============================================================================
# InvLocResource
# ============================================================================


class TestInvLocResource:
    """Tests for /inv-loc endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = InvLocResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-loc"


# ============================================================================
# InvMastResource
# ============================================================================


class TestInvMastResource:
    """Tests for /inv-mast endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast"

    def test_get_lookup(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.get_lookup()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/lookup"

    def test_get(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1"

    def test_list_alternate_code(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.list_alternate_code(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1/alternate-code"

    def test_list_attributes(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.list_attributes(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1/attributes"

    def test_create_attributes(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.create_attributes(1, data={"test": True})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/inv-mast/1/attributes"

    def test_list_attributes_values(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.list_attributes_values(attribute_uid=2, inv_mast_uid=1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1/attributes/2/values"

    def test_create_attributes_values(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.create_attributes_values(attribute_uid=2, inv_mast_uid=1, data={"v": 1})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/inv-mast/1/attributes/2/values"

    def test_delete_attributes_values(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.delete_attributes_values(attribute_uid=2, attribute_value_uid=3, inv_mast_uid=1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/inv-mast/1/attributes/2/values/3"

    def test_update_attributes_values(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.update_attributes_values(
            attribute_uid=2, attribute_value_uid=3, inv_mast_uid=1, data={"v": 2}
        )
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/inv-mast/1/attributes/2/values/3"

    def test_list_doc(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.list_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1/doc"

    def test_get_doc_alias(self, mock_http: MagicMock) -> None:
        """get_doc is an alias for list_doc."""
        r = InvMastResource(mock_http)
        r.get_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1/doc"

    def test_list_faq(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.list_faq(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1/faq"

    def test_create_faq(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.create_faq(1, data={"question": "test?"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/inv-mast/1/faq"

    def test_delete_faq(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.delete_faq(inv_mast_faq_uid=2, inv_mast_uid=1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/inv-mast/1/faq/2"

    def test_get_faq(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.get_faq(inv_mast_faq_uid=2, inv_mast_uid=1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1/faq/2"

    def test_update_faq(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.update_faq(inv_mast_faq_uid=2, inv_mast_uid=1, data={"answer": "yes"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/inv-mast/1/faq/2"

    def test_list_inv_accessory(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.list_inv_accessory(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1/inv-accessory"

    def test_list_inv_sub(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.list_inv_sub(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1/inv-sub"

    def test_list_locations_bins(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.list_locations_bins(inv_mast_uid=1, location_id=10)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1/locations/10/bins"

    def test_get_locations_bins(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.get_locations_bins(bin="A1", inv_mast_uid=1, location_id=10)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1/locations/10/bins/A1"

    def test_list_similar(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.list_similar(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1/similar"

    def test_get_stock(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.get_stock(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/1/stock"


# ============================================================================
# InvMastLinksResource
# ============================================================================


class TestInvMastLinksResource:
    """Tests for /inv-mast-links endpoints."""

    def test_get(self, mock_http: MagicMock) -> None:
        r = InvMastLinksResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast-links/1"


# ============================================================================
# InvMastSubPartsResource
# ============================================================================


class TestInvMastSubPartsResource:
    """Tests for /inv-mast-sub-parts endpoints."""

    def test_get(self, mock_http: MagicMock) -> None:
        r = InvMastSubPartsResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast-sub-parts/1"


# ============================================================================
# InvMastUdResource
# ============================================================================


class TestInvMastUdResource:
    """Tests for /inv-mast-ud endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = InvMastUdResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast-ud"


# ============================================================================
# ItemCategoryResource
# ============================================================================


class TestItemCategoryResource:
    """Tests for /item-category endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = ItemCategoryResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/item-category"

    def test_get_lookup(self, mock_http: MagicMock) -> None:
        r = ItemCategoryResource(mock_http)
        r.get_lookup()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/item-category/lookup"

    def test_get(self, mock_http: MagicMock) -> None:
        r = ItemCategoryResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/item-category/1"

    def test_list_doc(self, mock_http: MagicMock) -> None:
        r = ItemCategoryResource(mock_http)
        r.list_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/item-category/1/doc"

    def test_get_doc_alias(self, mock_http: MagicMock) -> None:
        """get_doc is an alias for list_doc."""
        r = ItemCategoryResource(mock_http)
        r.get_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/item-category/1/doc"


# ============================================================================
# ItemFavoritesResource
# ============================================================================


class TestItemFavoritesResource:
    """Tests for /item-favorites endpoints."""

    def test_list_items(self, mock_http: MagicMock) -> None:
        r = ItemFavoritesResource(mock_http)
        r.list_items(users_id=5)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/item-favorites/5/items"

    def test_create_items(self, mock_http: MagicMock) -> None:
        r = ItemFavoritesResource(mock_http)
        r.create_items(users_id=5, data={"inv_mast_uid": 1})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/item-favorites/5/items"

    def test_delete_items(self, mock_http: MagicMock) -> None:
        r = ItemFavoritesResource(mock_http)
        r.delete_items(inv_mast_uid=1, users_id=5)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/item-favorites/5/items/1"

    def test_get_items(self, mock_http: MagicMock) -> None:
        r = ItemFavoritesResource(mock_http)
        r.get_items(inv_mast_uid=1, users_id=5)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/item-favorites/5/items/1"

    def test_update_items(self, mock_http: MagicMock) -> None:
        r = ItemFavoritesResource(mock_http)
        r.update_items(inv_mast_uid=1, users_id=5, data={"sort": 1})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/item-favorites/5/items/1"


# ============================================================================
# ItemUomResource
# ============================================================================


class TestItemUomResource:
    """Tests for /item-uom endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = ItemUomResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/item-uom"

    def test_get(self, mock_http: MagicMock) -> None:
        r = ItemUomResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/item-uom/1"


# ============================================================================
# ItemWishlistResource
# ============================================================================


class TestItemWishlistResource:
    """Tests for /item-wishlist endpoints."""

    def test_get(self, mock_http: MagicMock) -> None:
        r = ItemWishlistResource(mock_http)
        r.get(users_id=5)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/item-wishlist/5"

    def test_create(self, mock_http: MagicMock) -> None:
        r = ItemWishlistResource(mock_http)
        r.create(users_id=5, data={"name": "My List"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/item-wishlist/5"

    def test_delete_hdr(self, mock_http: MagicMock) -> None:
        r = ItemWishlistResource(mock_http)
        r.delete_hdr(item_wishlist_hdr_uid=10, users_id=5)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/item-wishlist/5/hdr/10"

    def test_get_hdr(self, mock_http: MagicMock) -> None:
        r = ItemWishlistResource(mock_http)
        r.get_hdr(item_wishlist_hdr_uid=10, users_id=5)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/item-wishlist/5/hdr/10"

    def test_create_hdr(self, mock_http: MagicMock) -> None:
        r = ItemWishlistResource(mock_http)
        r.create_hdr(item_wishlist_hdr_uid=10, users_id=5, data={"item": 1})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/item-wishlist/5/hdr/10"

    def test_update_hdr(self, mock_http: MagicMock) -> None:
        r = ItemWishlistResource(mock_http)
        r.update_hdr(item_wishlist_hdr_uid=10, users_id=5, data={"name": "updated"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/item-wishlist/5/hdr/10"

    def test_delete_hdr_line(self, mock_http: MagicMock) -> None:
        r = ItemWishlistResource(mock_http)
        r.delete_hdr_line(item_wishlist_hdr_uid=10, item_wishlist_line_uid=20, users_id=5)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/item-wishlist/5/hdr/10/line/20"

    def test_get_hdr_positional_url_order(self, mock_http: MagicMock) -> None:
        """Positional args MUST follow URL path order (users_id, item_wishlist_hdr_uid).

        Regression: BC #516640882. Previously the generated signature put
        path params in alphabetical order, swapping the two values when
        callers passed them positionally in URL order.
        """
        r = ItemWishlistResource(mock_http)
        r.get_hdr(12345, 7)  # positional: users_id=12345, item_wishlist_hdr_uid=7
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/item-wishlist/12345/hdr/7"

    def test_delete_hdr_line_positional_url_order(self, mock_http: MagicMock) -> None:
        """Three-segment positional args follow URL path order."""
        r = ItemWishlistResource(mock_http)
        # positional: users_id=12345, item_wishlist_hdr_uid=7, item_wishlist_line_uid=3
        r.delete_hdr_line(12345, 7, 3)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/item-wishlist/12345/hdr/7/line/3"


# ============================================================================
# LocationsResource
# ============================================================================


class TestLocationsResource:
    """Tests for /locations endpoints."""

    def test_list_bins(self, mock_http: MagicMock) -> None:
        r = LocationsResource(mock_http)
        r.list_bins(location_id=10)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/locations/10/bins"

    def test_get_bins(self, mock_http: MagicMock) -> None:
        r = LocationsResource(mock_http)
        r.get_bins(bin="A1", location_id=10)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/locations/10/bins/A1"


# ============================================================================
# P21Resource
# ============================================================================


class TestP21Resource:
    """Tests for /p21 endpoints."""

    def test_list_inv_mast(self, mock_http: MagicMock) -> None:
        r = P21Resource(mock_http)
        r.list_inv_mast()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/p21/inv-mast"


# ============================================================================
# VariantsResource
# ============================================================================


class TestVariantsResource:
    """Tests for /variants endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/variants"

    def test_create(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.create(data={"name": "v1"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/variants"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/variants/1"

    def test_get(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/variants/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.update(1, data={"name": "v2"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/variants/1"

    def test_list_attributes(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.list_attributes(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/variants/1/attributes"

    def test_create_attributes(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.create_attributes(1, data={"attr": 1})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/variants/1/attributes"

    def test_delete_attributes(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.delete_attributes(attribute_uid=2, item_variant_hdr_uid=1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/variants/1/attributes/2"

    def test_get_attributes(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.get_attributes(attribute_uid=2, item_variant_hdr_uid=1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/variants/1/attributes/2"

    def test_update_attributes(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.update_attributes(attribute_uid=2, item_variant_hdr_uid=1, data={"v": 1})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/variants/1/attributes/2"

    def test_list_doc(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.list_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/variants/1/doc"

    def test_get_doc_alias(self, mock_http: MagicMock) -> None:
        """get_doc is an alias for list_doc."""
        r = VariantsResource(mock_http)
        r.get_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/variants/1/doc"

    def test_list_lines(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.list_lines(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/variants/1/lines"

    def test_create_lines(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.create_lines(1, data={"line": 1})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/variants/1/lines"

    def test_delete_lines(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.delete_lines(item_variant_hdr_uid=1, item_variant_line_uid=2)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/variants/1/lines/2"

    def test_get_lines(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.get_lines(item_variant_hdr_uid=1, item_variant_line_uid=2)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/variants/1/lines/2"

    def test_update_lines(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.update_lines(item_variant_hdr_uid=1, item_variant_line_uid=2, data={"qty": 5})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/variants/1/lines/2"

    def test_list_similar(self, mock_http: MagicMock) -> None:
        r = VariantsResource(mock_http)
        r.list_similar(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/variants/1/similar"


# ============================================================================
# Response validation
# ============================================================================


class TestResponseValidation:
    """Verify BaseResponse[Any] is returned correctly."""

    def test_list_returns_base_response(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        result = r.list()
        assert result.status == 200
        assert result.message == "Success"
        assert result.count == 1
        assert result.total == 1

    def test_get_returns_base_response(self, mock_http: MagicMock) -> None:
        r = AttributeGroupsResource(mock_http)
        result = r.get(1)
        assert result.data == {"id": 1}
