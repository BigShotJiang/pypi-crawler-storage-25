"""Tests for the P21 SISM service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.p21_sism import P21SismClient
from augur_api.services.p21_sism.generated.client import (
    ImportResource,
    ScheduledImportMasterResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


@pytest.fixture
def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "p21-sism"
    return http


class TestP21SismClient:
    """Tests for P21SismClient lazy property initialisation."""

    def test_import_(self, mock_http: MagicMock) -> None:
        client = P21SismClient(mock_http)
        assert isinstance(client.import_, ImportResource)

    def test_scheduled_import_master(self, mock_http: MagicMock) -> None:
        client = P21SismClient(mock_http)
        assert isinstance(client.scheduled_import_master, ScheduledImportMasterResource)

    def test_lazy_caching(self, mock_http: MagicMock) -> None:
        client = P21SismClient(mock_http)
        assert client.import_ is client.import_
        assert client.scheduled_import_master is client.scheduled_import_master


class TestImportResource:
    """Tests for /import endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = ImportResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/import"

    def test_list_daily_summary(self, mock_http: MagicMock) -> None:
        r = ImportResource(mock_http)
        r.list_daily_summary()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/import/daily-summary"

    def test_list_recent(self, mock_http: MagicMock) -> None:
        r = ImportResource(mock_http)
        r.list_recent()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/import/recent"

    def test_list_stuck(self, mock_http: MagicMock) -> None:
        r = ImportResource(mock_http)
        r.list_stuck()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/import/stuck"

    def test_get(self, mock_http: MagicMock) -> None:
        r = ImportResource(mock_http)
        r.get("123")
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/import/123"

    def test_update(self, mock_http: MagicMock) -> None:
        r = ImportResource(mock_http)
        r.update("123", data={"test": True})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/import/123"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = ImportResource(mock_http)
        r.delete("123")
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/import/123"

    def test_list_imp_oe_hdr(self, mock_http: MagicMock) -> None:
        r = ImportResource(mock_http)
        r.list_imp_oe_hdr("123")
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/import/123/imp-oe-hdr"

    def test_update_imp_oe_hdr(self, mock_http: MagicMock) -> None:
        r = ImportResource(mock_http)
        r.update_imp_oe_hdr("123", data={"test": True})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/import/123/imp-oe-hdr"

    def test_list_imp_oe_hdr_salesrep(self, mock_http: MagicMock) -> None:
        r = ImportResource(mock_http)
        r.list_imp_oe_hdr_salesrep("123")
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/import/123/imp-oe-hdr-salesrep"

    def test_update_imp_oe_hdr_salesrep(self, mock_http: MagicMock) -> None:
        r = ImportResource(mock_http)
        r.update_imp_oe_hdr_salesrep("123", data={"test": True})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/import/123/imp-oe-hdr-salesrep"

    def test_list_imp_oe_hdr_web(self, mock_http: MagicMock) -> None:
        r = ImportResource(mock_http)
        r.list_imp_oe_hdr_web("123")
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/import/123/imp-oe-hdr-web"


class TestScheduledImportMasterResource:
    """Tests for /scheduled-import-master endpoints."""

    def test_create_metadata_sftp(self, mock_http: MagicMock) -> None:
        r = ScheduledImportMasterResource(mock_http)
        r.create_metadata_sftp("abc", data={"test": True})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/scheduled-import-master/abc/metadata/sftp"


class TestResponseValidation:
    """Verify BaseResponse[Any] is returned correctly."""

    def test_list_returns_base_response(self, mock_http: MagicMock) -> None:
        r = ImportResource(mock_http)
        result = r.list()
        assert result.status == 200
        assert result.message == "Success"
