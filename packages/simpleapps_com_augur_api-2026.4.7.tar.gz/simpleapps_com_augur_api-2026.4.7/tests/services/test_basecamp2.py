"""Tests for the Basecamp2 service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.basecamp2 import Basecamp2Client
from augur_api.services.basecamp2.generated.client import (
    CommentsResource,
    EventsResource,
    MetricsResource,
    PeopleResource,
    ProjectsResource,
    TodolistsResource,
    TodosResource,
    TodosSummaryResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


@pytest.fixture
def mock_http() -> MagicMock:
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "basecamp2"
    return http


class TestBasecamp2Client:
    def test_comments(self, mock_http: MagicMock) -> None:
        client = Basecamp2Client(mock_http)
        assert isinstance(client.comments, CommentsResource)

    def test_todos(self, mock_http: MagicMock) -> None:
        client = Basecamp2Client(mock_http)
        assert isinstance(client.todos, TodosResource)

    def test_events(self, mock_http: MagicMock) -> None:
        client = Basecamp2Client(mock_http)
        assert isinstance(client.events, EventsResource)

    def test_metrics(self, mock_http: MagicMock) -> None:
        client = Basecamp2Client(mock_http)
        assert isinstance(client.metrics, MetricsResource)

    def test_people(self, mock_http: MagicMock) -> None:
        client = Basecamp2Client(mock_http)
        assert isinstance(client.people, PeopleResource)

    def test_projects(self, mock_http: MagicMock) -> None:
        client = Basecamp2Client(mock_http)
        assert isinstance(client.projects, ProjectsResource)

    def test_todolists(self, mock_http: MagicMock) -> None:
        client = Basecamp2Client(mock_http)
        assert isinstance(client.todolists, TodolistsResource)

    def test_todos_summary(self, mock_http: MagicMock) -> None:
        client = Basecamp2Client(mock_http)
        assert isinstance(client.todos_summary, TodosSummaryResource)

    def test_lazy_caching(self, mock_http: MagicMock) -> None:
        client = Basecamp2Client(mock_http)
        assert client.comments is client.comments
        assert client.events is client.events
        assert client.metrics is client.metrics
        assert client.people is client.people
        assert client.projects is client.projects
        assert client.todolists is client.todolists
        assert client.todos is client.todos
        assert client.todos_summary is client.todos_summary


class TestCommentsResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = CommentsResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/comments"

    def test_get(self, mock_http: MagicMock) -> None:
        r = CommentsResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/comments/1"


class TestEventsResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = EventsResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/events"


class TestMetricsResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = MetricsResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/metrics"


class TestPeopleResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = PeopleResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/people"

    def test_get(self, mock_http: MagicMock) -> None:
        r = PeopleResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/people/1"

    def test_list_metrics(self, mock_http: MagicMock) -> None:
        r = PeopleResource(mock_http)
        r.list_metrics(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/people/1/metrics"

    def test_list_todos(self, mock_http: MagicMock) -> None:
        r = PeopleResource(mock_http)
        r.list_todos(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/people/1/todos"

    def test_list_projects_todos(self, mock_http: MagicMock) -> None:
        r = PeopleResource(mock_http)
        r.list_projects_todos(1, 2)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/people/1/projects/2/todos"


class TestProjectsResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = ProjectsResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/projects"

    def test_get(self, mock_http: MagicMock) -> None:
        r = ProjectsResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/projects/1"

    def test_list_metrics(self, mock_http: MagicMock) -> None:
        r = ProjectsResource(mock_http)
        r.list_metrics(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/projects/1/metrics"

    def test_list_todolists(self, mock_http: MagicMock) -> None:
        r = ProjectsResource(mock_http)
        r.list_todolists(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/projects/1/todolists"

    def test_list_todos(self, mock_http: MagicMock) -> None:
        r = ProjectsResource(mock_http)
        r.list_todos(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/projects/1/todos"

    def test_list_todolists_todos(self, mock_http: MagicMock) -> None:
        r = ProjectsResource(mock_http)
        r.list_todolists_todos(1, 2)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/projects/1/todolists/2/todos"


class TestTodolistsResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = TodolistsResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/todolists"

    def test_get(self, mock_http: MagicMock) -> None:
        r = TodolistsResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/todolists/1"


class TestTodosResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = TodosResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/todos"

    def test_get(self, mock_http: MagicMock) -> None:
        r = TodosResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/todos/1"

    def test_list_comments(self, mock_http: MagicMock) -> None:
        r = TodosResource(mock_http)
        r.list_comments(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/todos/1/comments"

    def test_list_events(self, mock_http: MagicMock) -> None:
        r = TodosResource(mock_http)
        r.list_events(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/todos/1/events"

    def test_get_events(self, mock_http: MagicMock) -> None:
        r = TodosResource(mock_http)
        r.get_events(1, 2)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/todos/1/events/2"

    def test_list_metrics(self, mock_http: MagicMock) -> None:
        r = TodosResource(mock_http)
        r.list_metrics(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/todos/1/metrics"

    def test_list_sessions(self, mock_http: MagicMock) -> None:
        r = TodosResource(mock_http)
        r.list_sessions(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/todos/1/sessions"

    def test_create_sessions(self, mock_http: MagicMock) -> None:
        r = TodosResource(mock_http)
        r.create_sessions(1, data={"test": True})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/todos/1/sessions"

    def test_get_sessions(self, mock_http: MagicMock) -> None:
        r = TodosResource(mock_http)
        r.get_sessions(1, 2)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/todos/1/sessions/2"

    def test_update_sessions(self, mock_http: MagicMock) -> None:
        r = TodosResource(mock_http)
        r.update_sessions(1, 2, data={"test": True})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/todos/1/sessions/2"

    def test_delete_sessions(self, mock_http: MagicMock) -> None:
        r = TodosResource(mock_http)
        r.delete_sessions(1, 2)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/todos/1/sessions/2"


class TestTodosSummaryResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = TodosSummaryResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/todos-summary"

    def test_get(self, mock_http: MagicMock) -> None:
        r = TodosSummaryResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/todos-summary/1"


class TestResponseValidation:
    def test_returns_base_response(self, mock_http: MagicMock) -> None:
        r = CommentsResource(mock_http)
        result = r.list()
        assert result.status == 200
        assert result.data == {"id": 1}
