"""Tests for service clients."""
