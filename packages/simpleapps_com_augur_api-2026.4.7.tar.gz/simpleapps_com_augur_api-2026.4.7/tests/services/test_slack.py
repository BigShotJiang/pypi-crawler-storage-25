"""Tests for the Slack service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

from augur_api.services.slack import SlackClient
from augur_api.services.slack.generated.client import WebHookResource

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.service_name = "slack"
    return http


class TestSlackClient:
    """Tests for SlackClient lazy property initialisation."""

    def test_web_hook(self) -> None:
        client = SlackClient(mock_http())
        assert isinstance(client.web_hook, WebHookResource)

    def test_lazy_caching(self) -> None:
        client = SlackClient(mock_http())
        assert client.web_hook is client.web_hook


class TestWebHookResource:
    """Tests for /web-hook endpoints."""

    def test_create(self) -> None:
        http = mock_http()
        r = WebHookResource(http)
        result = r.create(data={"text": "Hello!"})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/web-hook"
        assert result.status == 200

    def test_get_refresh(self) -> None:
        http = mock_http()
        r = WebHookResource(http)
        result = r.get_refresh()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/web-hook/refresh"
        assert result.status == 200
