"""Access control for standard Odoo XML-RPC connections.

Permissions are entirely determined by the Odoo user account configured
via ODOO_USER / ODOO_PASSWORD (or ODOO_API_KEY).  This module provides a
lightweight wrapper whose interface is compatible with the rest of the
codebase while delegating all enforcement to Odoo itself.

Model discovery uses the standard ``ir.model`` endpoint so that the
list_models tool can return a meaningful catalogue without requiring any
custom Odoo module.
"""

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from .config import OdooConfig

logger = logging.getLogger(__name__)


class AccessControlError(Exception):
    """Exception for access control failures."""

    pass


@dataclass
class ModelPermissions:
    """Permissions for a specific model.

    In read-only mode only ``can_read`` is meaningful; the other flags are
    kept for interface compatibility but will always be False.
    """

    model: str
    enabled: bool
    can_read: bool = True
    can_write: bool = False
    can_create: bool = False
    can_unlink: bool = False

    def can_perform(self, operation: str) -> bool:
        """Check if a specific operation is allowed."""
        operation_map = {
            "read": self.can_read,
            "write": self.can_write,
            "create": self.can_create,
            "unlink": self.can_unlink,
            "delete": self.can_unlink,  # Alias
        }
        return operation_map.get(operation, False)


@dataclass
class CacheEntry:
    """Cache entry for permission data."""

    data: Any
    timestamp: datetime

    def is_expired(self, ttl_seconds: int) -> bool:
        """Check if cache entry is expired."""
        return datetime.now() - self.timestamp > timedelta(seconds=ttl_seconds)


class AccessController:
    """Delegates access control to Odoo's native permission system.

    All read operations are considered allowed at this layer; the actual
    Odoo XML-RPC call will raise an ``Access Denied`` fault if the
    configured user lacks the necessary model-level access rights.

    Model discovery (``get_enabled_models``) queries ``ir.model`` via
    XML-RPC so that the list_models tool works without any custom module.
    The XML-RPC object proxy is injected after authentication via
    ``set_object_proxy``.
    """

    # Cache TTL in seconds
    CACHE_TTL = 300  # 5 minutes

    def __init__(
        self,
        config: OdooConfig,
        database: Optional[str] = None,
        cache_ttl: int = CACHE_TTL,
    ):
        """Initialize access controller.

        Args:
            config: OdooConfig with connection details
            database: Resolved database name
            cache_ttl: Cache time-to-live in seconds
        """
        self.config = config
        self.database = database or config.database
        self.cache_ttl = cache_ttl
        self._cache: Dict[str, CacheEntry] = {}

        # XML-RPC object proxy — set via set_object_proxy() after auth
        self._object_proxy = None
        self._uid: Optional[int] = None
        self._password: Optional[str] = None

        base = config.url.rstrip("/")
        logger.info(f"Initialized AccessController for {base} (Odoo native permissions)")

    # ------------------------------------------------------------------
    # Proxy injection (called by OdooMCPServer after authentication)
    # ------------------------------------------------------------------

    def set_object_proxy(self, proxy, uid: int, password: str) -> None:
        """Inject the authenticated XML-RPC object proxy.

        Args:
            proxy: xmlrpc.client.ServerProxy for /xmlrpc/2/object
            uid: Authenticated user ID
            password: Password or API key used for authentication
        """
        self._object_proxy = proxy
        self._uid = uid
        self._password = password
        logger.debug("AccessController received object proxy")

    # ------------------------------------------------------------------
    # Cache helpers
    # ------------------------------------------------------------------

    def _get_from_cache(self, key: str) -> Optional[Any]:
        """Get value from cache if not expired."""
        if key in self._cache:
            entry = self._cache[key]
            if not entry.is_expired(self.cache_ttl):
                logger.debug(f"Cache hit for {key}")
                return entry.data
            else:
                logger.debug(f"Cache expired for {key}")
                del self._cache[key]
        return None

    def _set_cache(self, key: str, data: Any) -> None:
        """Set value in cache."""
        self._cache[key] = CacheEntry(data=data, timestamp=datetime.now())
        logger.debug(f"Cached {key}")

    def clear_cache(self) -> None:
        """Clear all cached data."""
        self._cache.clear()
        logger.info("Cleared access control cache")

    # ------------------------------------------------------------------
    # Model discovery via ir.model
    # ------------------------------------------------------------------

    def get_enabled_models(self) -> List[Dict[str, str]]:
        """Return all models the current user can access.

        Queries ``ir.model`` via XML-RPC.  If the proxy is not yet
        available (e.g. during early startup), returns an empty list.

        Returns:
            List of dicts with ``model`` and ``name`` keys.
        """
        cache_key = "enabled_models"
        cached = self._get_from_cache(cache_key)
        if cached is not None:
            return cached

        if self._object_proxy is None or self._uid is None:
            logger.debug("Object proxy not yet available; returning empty model list")
            return []

        try:
            db = self.database or ""
            records = self._object_proxy.execute_kw(
                db,
                self._uid,
                self._password,
                "ir.model",
                "search_read",
                [[]],
                {"fields": ["model", "name"], "order": "model asc"},
            )
            models = [{"model": r["model"], "name": r["name"]} for r in records]
            self._set_cache(cache_key, models)
            logger.info(f"Retrieved {len(models)} models from ir.model")
            return models
        except Exception as e:
            logger.warning(f"Could not retrieve model list from Odoo: {e}")
            return []

    def is_model_enabled(self, model: str) -> bool:
        """Check if a model is accessible.

        Always returns True — Odoo will enforce access rights on the
        actual XML-RPC call.  We keep the method for interface compat.

        Args:
            model: The Odoo model name (e.g., 'res.partner')

        Returns:
            True (access enforcement delegated to Odoo)
        """
        return True

    def get_model_permissions(self, model: str) -> ModelPermissions:
        """Return permissions for a model.

        Since this server is read-only and delegates enforcement to Odoo,
        we always report ``can_read=True`` and all write flags as False.

        Args:
            model: The Odoo model name

        Returns:
            ModelPermissions with read-only flags
        """
        return ModelPermissions(
            model=model,
            enabled=True,
            can_read=True,
            can_write=False,
            can_create=False,
            can_unlink=False,
        )

    def check_operation_allowed(self, model: str, operation: str) -> Tuple[bool, Optional[str]]:
        """Check if an operation is allowed on a model.

        Read operations are always allowed at this layer (Odoo enforces
        the real permission).  Write operations are always denied because
        this server is read-only.

        Args:
            model: The Odoo model name
            operation: The operation to check (read, write, create, unlink)

        Returns:
            Tuple of (allowed, error_message)
        """
        if operation in ("write", "create", "unlink", "delete"):
            return False, f"Operation '{operation}' is not supported (read-only server)"

        # For read — allow; Odoo will reject with Access Denied if needed
        return True, None

    def validate_model_access(self, model: str, operation: str) -> None:
        """Validate model access, raising exception if denied.

        Args:
            model: The Odoo model name
            operation: The operation to perform

        Raises:
            AccessControlError: If access is denied at this layer
        """
        allowed, error_msg = self.check_operation_allowed(model, operation)
        if not allowed:
            raise AccessControlError(error_msg or f"Access denied to {model}.{operation}")

    def filter_enabled_models(self, models: List[str]) -> List[str]:
        """Return models unchanged (all models pass the filter).

        Access enforcement is delegated to Odoo; this layer does not
        filter models out.

        Args:
            models: List of model names

        Returns:
            The same list unmodified
        """
        return list(models)

    def get_all_permissions(self) -> Dict[str, ModelPermissions]:
        """Return read-only permissions for all known models.

        Returns:
            Dict mapping model names to their (read-only) permissions
        """
        permissions: Dict[str, ModelPermissions] = {}
        for model_info in self.get_enabled_models():
            model = model_info["model"]
            permissions[model] = self.get_model_permissions(model)
        return permissions
