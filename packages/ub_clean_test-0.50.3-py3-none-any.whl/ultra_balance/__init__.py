__version__ = '0.50.3'         
__author__ = 'pengyeqin'

def hello():
    print("Hello from ub-clean-test!")