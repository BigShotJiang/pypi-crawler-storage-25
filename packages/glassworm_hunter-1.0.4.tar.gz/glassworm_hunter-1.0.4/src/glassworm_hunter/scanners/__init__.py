"""File system traversal strategies."""
