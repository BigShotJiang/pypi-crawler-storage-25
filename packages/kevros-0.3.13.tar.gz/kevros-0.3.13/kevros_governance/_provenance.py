"""
Build provenance record — auto-generated, do not edit.

This file is embedded by the CI/CD pipeline at build time.
It provides hash verification and optional cryptographic
signature verification for this package distribution.
"""

PROVENANCE = {
    'schema_version': '1.0',
    'artifact_hash': 'sha512:69679372c6b72c53d95ab95ca08f90e42c09611822cf575c824249deee1af752f3f00cfb32e58c1aa1475a40f75ea581e6c5d368c81224bdb2ad648eeda92407',
    'version': '0.3.13',
    'registry': 'pypi',
    'package_name': 'kevros',
    'build_timestamp': '2026-04-04T06:10:46Z',
    'build_host_hash': 'sha256:095d6207b8dcc408c792c76eee968106385e8fe048e6b2958dc37f5dc0cfeb87',
    'git_commit': '3455e9ac58e2b23119b0aa508e81ba5a11294708',
    'git_branch': 'sdk-v0.3.13',
    'signer': 'github-actions-oidc',
    'signature_algorithm': '',
    'signature': '',
    'public_key': '',
    'dependencies_hash': 'sha256:0ad6d8e8cf6dbdc929def97dca11d7705d599a1fd8c5a12f2c6bba8f86dc6cf8',
}


def get_provenance() -> dict:
    """Return a copy of the build provenance record."""
    return dict(PROVENANCE)
