import hmac
from hashlib import sha256

from solfoundry_bounty_sync.github import verify_github_signature


def test_verify_github_signature():
    body = b'{"ok":true}'
    secret = "secret"
    signature = "sha256=" + hmac.new(secret.encode(), body, sha256).hexdigest()
    assert verify_github_signature(secret, body, signature)
    assert not verify_github_signature(secret, body, "sha256=bad")
