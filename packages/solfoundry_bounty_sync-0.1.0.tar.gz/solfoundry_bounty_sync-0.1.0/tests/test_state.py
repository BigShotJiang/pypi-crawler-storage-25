from solfoundry_bounty_sync.state import SyncState


def test_state_dedupes(tmp_path):
    state = SyncState(f"sqlite:///{tmp_path / 'state.db'}")
    assert not state.seen_same("repo#1", "abc")
    state.mark("repo#1", "abc", "bounty-1")
    assert state.seen_same("repo#1", "abc")
    assert not state.seen_same("repo#1", "def")
