from datetime import datetime, timezone

from solfoundry_bounty_sync.mapper import detect_tier, issue_to_bounty
from solfoundry_bounty_sync.models import BountyTier, GitHubIssue


def issue(title="Bounty T2: scraper", labels=None):
    return GitHubIssue(
        id=1,
        number=840,
        repo="SolFoundry/solfoundry",
        title=title,
        body="body",
        state="open",
        labels=labels or [],
        author="alice",
        html_url="https://github.com/SolFoundry/solfoundry/issues/840",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )


def test_detect_tier_from_title():
    assert detect_tier(issue()) == BountyTier.T2


def test_detect_tier_from_label():
    assert detect_tier(issue("Build scraper", ["T3", "bounty"])) == BountyTier.T3


def test_issue_to_bounty_schema():
    bounty = issue_to_bounty(issue())
    assert bounty.source_id == "SolFoundry/solfoundry#840"
    assert bounty.tier == BountyTier.T2
    assert bounty.issue_number == 840
