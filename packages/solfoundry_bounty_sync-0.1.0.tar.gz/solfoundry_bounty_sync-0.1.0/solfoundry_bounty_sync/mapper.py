from __future__ import annotations

import re

from .models import BountyRecord, BountyTier, GitHubIssue

_TIER_RE = re.compile(r"\bT([123])\b", re.IGNORECASE)


def detect_tier(issue: GitHubIssue) -> BountyTier:
    haystack = " ".join([issue.title, *(issue.labels or [])])
    match = _TIER_RE.search(haystack)
    if not match:
        return BountyTier.UNKNOWN
    return BountyTier(f"T{match.group(1)}")


def issue_to_bounty(issue: GitHubIssue) -> BountyRecord:
    return BountyRecord(
        source_id=f"{issue.repo}#{issue.number}",
        source_url=issue.html_url,
        repo=issue.repo,
        issue_number=issue.number,
        title=issue.title.strip(),
        description=(issue.body or "").strip(),
        tier=detect_tier(issue),
        labels=issue.labels,
        author=issue.author,
        metadata={
            "github_issue_id": issue.id,
            "github_state": issue.state,
            "github_created_at": issue.created_at.isoformat(),
            "github_updated_at": issue.updated_at.isoformat(),
        },
    )
