from __future__ import annotations

import hmac
from hashlib import sha256
from typing import Any

import httpx

from .models import GitHubIssue

GITHUB_API = "https://api.github.com"


class GitHubClient:
    def __init__(self, token: str | None = None, base_url: str = GITHUB_API) -> None:
        headers = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        self.client = httpx.AsyncClient(base_url=base_url, headers=headers, timeout=30)

    async def close(self) -> None:
        await self.client.aclose()

    async def list_issues(self, repo: str, labels: list[str] | None = None, limit: int = 50) -> list[GitHubIssue]:
        params: dict[str, Any] = {"state": "open", "per_page": min(limit, 100), "sort": "updated"}
        if labels:
            params["labels"] = ",".join(labels)
        response = await self.client.get(f"/repos/{repo}/issues", params=params)
        response.raise_for_status()
        return [self._parse_issue(repo, item) for item in response.json() if "pull_request" not in item]

    def _parse_issue(self, repo: str, raw: dict[str, Any]) -> GitHubIssue:
        return GitHubIssue(
            id=raw["id"],
            number=raw["number"],
            repo=repo,
            title=raw["title"],
            body=raw.get("body") or "",
            state=raw["state"],
            labels=[label["name"] for label in raw.get("labels", [])],
            author=raw.get("user", {}).get("login", "unknown"),
            html_url=raw["html_url"],
            created_at=raw["created_at"],
            updated_at=raw["updated_at"],
        )


def verify_github_signature(secret: str, body: bytes, signature: str | None) -> bool:
    if not signature or not signature.startswith("sha256="):
        return False
    expected = "sha256=" + hmac.new(secret.encode(), body, sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


def parse_webhook_issue(repo_full_name: str, payload: dict[str, Any]) -> GitHubIssue | None:
    if "issue" not in payload or "pull_request" in payload["issue"]:
        return None
    return GitHubClient()._parse_issue(repo_full_name, payload["issue"])
