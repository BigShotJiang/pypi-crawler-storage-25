from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, HttpUrl


class BountyTier(str, Enum):
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    UNKNOWN = "UNKNOWN"


class GitHubIssue(BaseModel):
    id: int
    number: int
    repo: str
    title: str
    body: str | None = None
    state: str
    labels: list[str] = Field(default_factory=list)
    author: str
    html_url: HttpUrl
    created_at: datetime
    updated_at: datetime


class BountyRecord(BaseModel):
    source: str = "github"
    source_id: str
    source_url: HttpUrl
    repo: str
    issue_number: int
    title: str
    description: str = ""
    tier: BountyTier = BountyTier.UNKNOWN
    labels: list[str] = Field(default_factory=list)
    author: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class PublishResult(BaseModel):
    status: str
    bounty_id: str | None = None
    message: str = ""
