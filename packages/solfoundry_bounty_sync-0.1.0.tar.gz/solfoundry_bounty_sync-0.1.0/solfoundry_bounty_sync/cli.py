from __future__ import annotations

import argparse
import asyncio
import json

import uvicorn

from .app import app
from .config import load_settings
from .service import sync_once


def main() -> None:
    parser = argparse.ArgumentParser(description="Sync GitHub bounty issues into SolFoundry")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("sync", help="Run one polling sync")
    serve = sub.add_parser("serve", help="Run FastAPI webhook/API server")
    serve.add_argument("--host", default="0.0.0.0")
    serve.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()
    if args.cmd == "sync":
        print(json.dumps(asyncio.run(sync_once(load_settings())), indent=2))
    elif args.cmd == "serve":
        uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
