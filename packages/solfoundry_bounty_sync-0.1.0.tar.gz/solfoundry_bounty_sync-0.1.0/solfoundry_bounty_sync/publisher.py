from __future__ import annotations

import hashlib

import httpx

from .models import BountyRecord, PublishResult


def stable_payload_hash(record: BountyRecord) -> str:
    return hashlib.sha256(record.model_dump_json(sort_keys=True).encode()).hexdigest()


class SolFoundryPublisher:
    def __init__(self, api_url: str | None, token: str | None, dry_run: bool = True) -> None:
        self.api_url = str(api_url).rstrip("/") if api_url else None
        self.token = token
        self.dry_run = dry_run

    async def publish(self, record: BountyRecord) -> PublishResult:
        if self.dry_run or not self.api_url:
            return PublishResult(status="dry_run", bounty_id=record.source_id, message="validated only")
        headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
        async with httpx.AsyncClient(timeout=30, headers=headers) as client:
            response = await client.post(f"{self.api_url}/bounties", json=record.model_dump(mode="json"))
            response.raise_for_status()
            data = response.json()
            return PublishResult(status="published", bounty_id=str(data.get("id", record.source_id)))
