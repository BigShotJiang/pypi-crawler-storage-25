from __future__ import annotations

import sqlite3
from pathlib import Path
from urllib.parse import urlparse


class SyncState:
    def __init__(self, database_url: str) -> None:
        parsed = urlparse(database_url)
        if parsed.scheme and parsed.scheme != "sqlite":
            raise ValueError("Only sqlite:// database_url is supported by the built-in state backend")
        path = parsed.path if parsed.scheme else database_url
        self.path = Path(path if path != "/" else "./solfoundry_bounty_sync.db")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.path)

    def _init(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS sync_state (
                  source_id TEXT PRIMARY KEY,
                  payload_hash TEXT NOT NULL,
                  bounty_id TEXT,
                  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
                """
            )

    def seen_same(self, source_id: str, payload_hash: str) -> bool:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT payload_hash FROM sync_state WHERE source_id = ?", (source_id,)
            ).fetchone()
        return bool(row and row[0] == payload_hash)

    def mark(self, source_id: str, payload_hash: str, bounty_id: str | None = None) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO sync_state (source_id, payload_hash, bounty_id)
                VALUES (?, ?, ?)
                ON CONFLICT(source_id) DO UPDATE SET
                  payload_hash = excluded.payload_hash,
                  bounty_id = excluded.bounty_id,
                  updated_at = CURRENT_TIMESTAMP
                """,
                (source_id, payload_hash, bounty_id),
            )
