from __future__ import annotations

from .config import Settings
from .github import GitHubClient
from .mapper import issue_to_bounty
from .publisher import SolFoundryPublisher, stable_payload_hash
from .state import SyncState


async def sync_once(settings: Settings) -> dict[str, int]:
    token = settings.github_token.get_secret_value() if settings.github_token else None
    sf_token = settings.solfoundry_api_token.get_secret_value() if settings.solfoundry_api_token else None
    github = GitHubClient(token=token)
    state = SyncState(settings.database_url)
    publisher = SolFoundryPublisher(settings.solfoundry_api_url, sf_token, settings.dry_run)
    counters = {"scanned": 0, "skipped": 0, "published": 0}
    try:
        for repo in settings.github_repos:
            issues = await github.list_issues(repo, settings.github_labels_any, settings.poll_limit)
            for issue in issues:
                counters["scanned"] += 1
                record = issue_to_bounty(issue)
                digest = stable_payload_hash(record)
                if state.seen_same(record.source_id, digest):
                    counters["skipped"] += 1
                    continue
                result = await publisher.publish(record)
                state.mark(record.source_id, digest, result.bounty_id)
                counters["published"] += 1
        return counters
    finally:
        await github.close()
