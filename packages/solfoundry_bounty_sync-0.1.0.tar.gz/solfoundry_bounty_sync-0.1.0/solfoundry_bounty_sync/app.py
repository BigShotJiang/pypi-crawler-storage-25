from __future__ import annotations

from fastapi import FastAPI, Header, HTTPException, Request

from .config import load_settings
from .github import parse_webhook_issue, verify_github_signature
from .mapper import issue_to_bounty
from .publisher import SolFoundryPublisher, stable_payload_hash
from .service import sync_once
from .state import SyncState

app = FastAPI(title="SolFoundry Bounty Sync", version="0.1.0")


@app.get("/healthz")
def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/sync")
async def sync() -> dict[str, int]:
    return await sync_once(load_settings())


@app.post("/webhooks/github")
async def github_webhook(
    request: Request,
    x_github_event: str = Header(default=""),
    x_hub_signature_256: str | None = Header(default=None),
) -> dict[str, str]:
    settings = load_settings()
    body = await request.body()
    if settings.github_webhook_secret:
        secret = settings.github_webhook_secret.get_secret_value()
        if not verify_github_signature(secret, body, x_hub_signature_256):
            raise HTTPException(status_code=401, detail="invalid signature")
    if x_github_event != "issues":
        return {"status": "ignored"}
    payload = await request.json()
    repo = payload.get("repository", {}).get("full_name")
    issue = parse_webhook_issue(repo, payload) if repo else None
    if not issue:
        return {"status": "ignored"}
    record = issue_to_bounty(issue)
    digest = stable_payload_hash(record)
    state = SyncState(settings.database_url)
    if state.seen_same(record.source_id, digest):
        return {"status": "duplicate"}
    sf_token = settings.solfoundry_api_token.get_secret_value() if settings.solfoundry_api_token else None
    result = await SolFoundryPublisher(settings.solfoundry_api_url, sf_token, settings.dry_run).publish(record)
    state.mark(record.source_id, digest, result.bounty_id)
    return {"status": result.status, "bounty_id": result.bounty_id or ""}
