from __future__ import annotations

from pydantic import AnyHttpUrl, Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="SOLFOUNDRY_", extra="ignore")

    github_token: SecretStr | None = None
    github_repos: list[str] = Field(default_factory=lambda: ["SolFoundry/solfoundry"])
    github_labels_any: list[str] = Field(default_factory=lambda: ["bounty", "T1", "T2", "T3"])
    github_webhook_secret: SecretStr | None = None

    solfoundry_api_url: AnyHttpUrl | None = None
    solfoundry_api_token: SecretStr | None = None
    dry_run: bool = True

    poll_limit: int = 50
    database_url: str = "sqlite:///./solfoundry_bounty_sync.db"


def load_settings() -> Settings:
    return Settings()
