# solfoundry-bounty-sync

Production-ready GitHub issue scraper + publisher for the SolFoundry bounty ingestion workflow.

Built for SolFoundry issue #840: **Bounty T2: GitHub Issue Scraper for Foundry Bounties**.

## What it does

- polls configurable GitHub repositories for open bounty issues
- normalizes issues into a stable `BountyRecord` schema
- maps tiers from issue titles/labels (`T1`, `T2`, `T3`)
- publishes records to a SolFoundry API endpoint, or runs safely in dry-run mode
- supports GitHub `issues` webhooks with HMAC SHA-256 signature verification
- stores sync state in SQLite for dedupe/idempotency
- exposes `/healthz`, `/sync`, and `/webhooks/github`
- ships with CLI, tests, and typed Pydantic models

## Quick start

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e '.[dev]'
cp .env.example .env
solfoundry-bounty-sync sync
solfoundry-bounty-sync serve --port 8080
```

## Configuration

Environment variables use the `SOLFOUNDRY_` prefix.

```bash
SOLFOUNDRY_GITHUB_TOKEN=github_pat_or_classic_token
SOLFOUNDRY_GITHUB_REPOS='["SolFoundry/solfoundry"]'
SOLFOUNDRY_GITHUB_LABELS_ANY='["bounty","T1","T2","T3"]'
SOLFOUNDRY_GITHUB_WEBHOOK_SECRET=change-me
SOLFOUNDRY_SOLFOUNDRY_API_URL=https://api.solfoundry.example
SOLFOUNDRY_SOLFOUNDRY_API_TOKEN=token
SOLFOUNDRY_DRY_RUN=true
SOLFOUNDRY_DATABASE_URL=sqlite:///./solfoundry_bounty_sync.db
```

Dry-run is enabled by default so the package can be verified without touching production.

## Verification checklist

```bash
python -m pytest
python -m ruff check .
python -m build
```

## Integration notes

The publisher expects `POST {SOLFOUNDRY_SOLFOUNDRY_API_URL}/bounties` with the normalized `BountyRecord` JSON. If SolFoundry's internal API route differs, only `publisher.py` needs a small adapter change; ingestion, mapping, dedupe, and webhook verification remain unchanged.
