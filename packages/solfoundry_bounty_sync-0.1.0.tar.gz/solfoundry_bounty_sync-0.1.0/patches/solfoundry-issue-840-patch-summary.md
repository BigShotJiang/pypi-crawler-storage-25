# SolFoundry issue #840 — patch summary

Patch file: `solfoundry-issue-840-github-bounty-sync.patch`

Adds a standalone backend service under `services/github-bounty-sync/`:

- FastAPI service: `/healthz`, `/sync`, `/webhooks/github`
- GitHub issue polling with configurable repo/label filters
- GitHub webhook HMAC SHA-256 signature verification
- Normalized bounty schema + T1/T2/T3 tier mapping
- SQLite dedupe/idempotency sync state
- SolFoundry publisher adapter with safe dry-run default
- CLI entrypoint: `solfoundry-bounty-sync sync|serve`
- README, `.env.example`, MIT license, package metadata
- Tests for tier mapping, webhook verification, and state dedupe

Verification run:

```bash
cd services/github-bounty-sync
uv venv .venv --clear
. .venv/bin/activate
uv pip install -e '.[dev]' build
python -m pytest -q        # 5 passed
python -m ruff check .     # passed
python -m build            # wheel + sdist built
```

Patch apply check against `SolFoundry/solfoundry@main`: OK.
