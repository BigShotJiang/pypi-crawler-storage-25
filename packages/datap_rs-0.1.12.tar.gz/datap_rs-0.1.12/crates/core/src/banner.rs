//! Startup banner — printed once when a backend boots.
//!
//! Lives in `datapress-core` so both backend crates (and the Python
//! binding's embedded server) render the exact same splash.

/// DataPress version (matches the workspace `Cargo.toml`).
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

const ASCII_ART: &str = r#"
██████╗  █████╗ ████████╗ █████╗ ██████╗       ██████╗ ███████╗
██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██╔══██╗      ██╔══██╗██╔════╝
██║  ██║███████║   ██║   ███████║██████╔╝█████╗██████╔╝███████╗
██║  ██║██╔══██║   ██║   ██╔══██║██╔═══╝ ╚════╝██╔══██╗╚════██║
██████╔╝██║  ██║   ██║   ██║  ██║██║           ██║  ██║███████║
╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝           ╚═╝  ╚═╝╚══════╝
"#;

/// Write the banner + version straight to stdout. Bypasses `log` so it
/// always shows regardless of `RUST_LOG`.
pub fn print() {
    println!("{ASCII_ART}");
    println!("                          datap-rs v{VERSION}");
    println!();
}
