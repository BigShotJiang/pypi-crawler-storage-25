# Created on 10/12/2025
# Author: Frank Vega

import itertools

import networkx as nx

def find_independent_set(graph):
    """
    Compute an approximate maximum independent set with a 2-approximation ratio.

    Args:
        graph (nx.Graph): An undirected NetworkX graph.

    Returns:
        set: A maximal independent set of vertices.
    """
    def cover_bipartite(bipartite_graph):
        """Compute a minimum vertex cover set for a bipartite graph using matching.

        Args:
            bipartite_graph (nx.Graph): A bipartite NetworkX graph.

        Returns:
            set: A minimum vertex cover set for the bipartite graph.
        """
        # Verify bipartite property
        if not nx.bipartite.is_bipartite(bipartite_graph):
            raise ValueError("Graph must be bipartite for this algorithm")

        optimal_solution = set()
        for component in nx.connected_components(bipartite_graph):
            subgraph = bipartite_graph.subgraph(component)
            # Hopcroft-Karp finds a maximum matching in O(E * sqrt(V)) time
            matching = nx.bipartite.hopcroft_karp_matching(subgraph)
            # By König's theorem, min vertex cover == max matching in bipartite graphs;
            # the complement of this cover is therefore a maximum independent set
            vertex_cover = nx.bipartite.to_vertex_cover(subgraph, matching)
            optimal_solution.update(vertex_cover)
        return optimal_solution

    def is_independent_set(graph, independent_set):
        """
        Verify if a set of vertices is an independent set in the graph.

        Args:
            graph (nx.Graph): The input graph.
            independent_set (set): Vertices to check.

        Returns:
            bool: True if the set is independent, False otherwise.
        """
        for u, v in graph.edges():
            # An edge with both endpoints in the set violates independence
            if u in independent_set and v in independent_set:
                return False
        return True

    # Validate input graph type
    if not isinstance(graph, nx.Graph):
        raise ValueError("Input must be an undirected NetworkX Graph.")

    # Handle trivial cases: empty or edgeless graphs
    if graph.number_of_nodes() == 0 or graph.number_of_edges() == 0:
        return set(graph)

    # Work on a copy so the caller's graph is never mutated
    working_graph = graph.copy()

    # Self-loops are irrelevant to independence (a single vertex already covers them)
    working_graph.remove_edges_from(list(nx.selfloop_edges(working_graph)))

    # Isolated nodes are trivially independent of everything and can always be included
    isolates = set(nx.isolates(working_graph))
    working_graph.remove_nodes_from(isolates)

    # After stripping self-loops and isolates the graph may now be empty
    if working_graph.number_of_nodes() == 0:
        return isolates

    # For bipartite graphs König's theorem gives the exact maximum IS in polynomial
    # time: min vertex cover == max matching, and IS == complement of min VC
    if nx.bipartite.is_bipartite(working_graph):
        # The complement of a minimum vertex cover is a maximum independent set
        approximate_independent_set = set(working_graph.nodes()) - cover_bipartite(working_graph)
    else:
        approximate_vertex_cover = set()

        # Solve each connected component separately; the union of per-component
        # vertex covers is a valid cover for the whole graph
        for component in nx.connected_components(working_graph):
            component_subgraph = working_graph.subgraph(component)

            if nx.bipartite.is_bipartite(component_subgraph):
                # Bipartite components are handled exactly via König's theorem
                approximate_vertex_cover.update(cover_bipartite(component_subgraph))
            else:
                # For non-bipartite components we construct a bipartite gadget graph G
                # that encodes the vertex cover problem of the original component.
                # Once a minimum VC of G is found (exactly, via König's theorem), the
                # original vertices that "should" be in the cover are decoded from the
                # 3-tuple nodes that appear in that cover.
                G = nx.Graph()

                # ── Gadget construction ──────────────────────────────────────────
                # For each original edge (u, v) we introduce four 3-tuple "edge-side"
                # nodes: (u,v,0) and (u,v,1) represent u's two roles w.r.t. this
                # edge, and (v,u,0) and (v,u,1) represent v's two roles.  These are
                # connected to each other and to 2-tuple "vertex" nodes (u,0), (u,1),
                # (v,0), (v,1) in a way that forces the resulting bipartite cover to
                # include at least one endpoint for every original edge — faithfully
                # encoding the vertex cover constraint in a bipartite structure that
                # König's theorem can solve exactly.
                for u, v in component_subgraph.edges():
                    # Cross-connections between u's and v's edge-side nodes ensure
                    # that at least one of the two original vertices is "selected"
                    # by the bipartite cover for each direction of the edge
                    G.add_edge((u, v, 0), (v, u, 1))
                    G.add_edge((u, v, 0), (u, 1))    # ties u's edge-node to u's vertex-node side 1
                    G.add_edge((v, u, 1), (v, 0))    # ties v's edge-node to v's vertex-node side 0

                    G.add_edge((u, v, 1), (v, u, 0))
                    G.add_edge((u, v, 1), (u, 0))    # symmetric: u's edge-node to u's vertex-node side 0
                    G.add_edge((v, u, 0), (v, 1))    # symmetric: v's edge-node to v's vertex-node side 1

                # Pendant edges anchor every vertex-node pair (u,0)↔(u,2) and
                # (u,1)↔(u,3).  Because (u,2) and (u,3) appear in no other edge,
                # the König cover must include either (u,0) or (u,2) (and either
                # (u,1) or (u,3)) for each vertex u, which keeps the gadget's
                # bipartite structure intact and prevents spurious free choices.
                G.add_edges_from({((u, 0), (u, 2)) for u in component_subgraph.nodes()})
                G.add_edges_from({((v, 1), (v, 3)) for v in component_subgraph.nodes()})

                # Solve the bipartite gadget exactly; G is constructed to be
                # bipartite by design — the two sides are nodes whose last tuple
                # element is even (0 or 2) versus odd (1 or 3)
                cover = cover_bipartite(G)

                # Decode: 3-tuple nodes (orig_vertex, neighbour, side) that appear
                # in the bipartite cover identify which original vertices should be
                # in the vertex cover.  Extract the original vertex (element 0) from
                # every 3-tuple cover node; 2-tuple nodes are gadget artifacts and
                # are discarded (len check distinguishes the two kinds).
                solution = {u[0] for u in cover if len(u) == 3}
                approximate_vertex_cover.update(solution)

        # The complement of the accumulated vertex cover is a candidate IS;
        # every vertex not in the cover has all its edges covered by its neighbors,
        # so no two complement vertices can be adjacent
        complement_solution = set(working_graph.nodes()) - approximate_vertex_cover

        # Greedily extend to maximality: add any vertex whose entire neighborhood
        # is already outside the current IS candidate
        for v in working_graph.nodes():
            if v not in complement_solution:
                # v is safe to add only if it has no neighbor already in the set
                if not any(working_graph.has_edge(v, u) for u in complement_solution):
                    complement_solution.add(v)

        approximate_independent_set = complement_solution

    # Re-add isolated nodes — they are always safe to include in any IS
    approximate_independent_set.update(isolates)

    # Runtime correctness guard: raises immediately if a bug in the reduction
    # or extension logic produced an invalid set
    if not is_independent_set(graph, approximate_independent_set):
        raise RuntimeError(
            f"Polynomial-time algorithm failed: the set {approximate_independent_set} is not independent"
        )
    return approximate_independent_set

def find_independent_set_brute_force(graph):
    """
    Computes an exact independent set in exponential time.

    Args:
        graph: A NetworkX Graph.

    Returns:
        A set of vertex indices representing the exact Independent Set, or None if the graph is empty.
    """
    def is_independent_set(graph, independent_set):
        """
        Verifies if a given set of vertices is a valid Independent Set for the graph.

        Args:
            graph (nx.Graph): The input graph.
            independent_set (set): A set of vertices to check.

        Returns:
            bool: True if the set is a valid Independent Set, False otherwise.
        """
        for u in independent_set:
            for v in independent_set:
                if u != v and graph.has_edge(u, v):
                    return False
        return True
    
    if graph.number_of_nodes() == 0 or graph.number_of_edges() == 0:
        return None

    n_vertices = len(graph.nodes())

    n_max_vertices = 0
    best_solution = None

    for k in range(1, n_vertices + 1): # Iterate through all possible sizes of the cover
        for candidate in itertools.combinations(graph.nodes(), k):
            cover_candidate = set(candidate)
            if is_independent_set(graph, cover_candidate) and len(cover_candidate) > n_max_vertices:
                n_max_vertices = len(cover_candidate)
                best_solution = cover_candidate
                
    return best_solution



def find_independent_set_approximation(graph):
    """
    Computes an approximate Independent Set in polynomial time with an approximation ratio of at most 2 for undirected graphs.

    Args:
        graph: A NetworkX Graph.

    Returns:
        A set of vertex indices representing the approximate Independent Set, or None if the graph is empty.
    """

    if graph.number_of_nodes() == 0 or graph.number_of_edges() == 0:
        return None

    #networkx doesn't have a guaranteed independent set function, so we use approximation
    complement_graph = nx.complement(graph)
    independent_set = nx.approximation.max_clique(complement_graph)
    return independent_set