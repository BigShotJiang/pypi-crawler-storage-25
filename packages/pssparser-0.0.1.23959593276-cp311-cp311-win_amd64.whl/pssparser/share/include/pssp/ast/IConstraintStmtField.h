/****************************************************************************
 * IConstraintStmtField.h
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 ****************************************************************************/
#pragma once
#include <stdint.h>
#include <unordered_map>
#include <memory>
#include <set>
#include <string>
#include <vector>
#include "pssp/ast/impl/UP.h"
#include "pssp/ast/IVisitor.h"
#include "pssp/ast/IConstraintStmt.h"

namespace pssp {
namespace ast {

class IConstraintStmt;
using IConstraintStmtUP=UP<IConstraintStmt>;
typedef std::shared_ptr<IConstraintStmt> IConstraintStmtSP;
class IExprId;
using IExprIdUP=UP<IExprId>;
typedef std::shared_ptr<IExprId> IExprIdSP;
class IDataType;
using IDataTypeUP=UP<IDataType>;
typedef std::shared_ptr<IDataType> IDataTypeSP;
class IConstraintStmtField;
using IConstraintStmtFieldUP=UP<IConstraintStmtField>;
class IConstraintStmtField : public virtual IConstraintStmt {
public:
    
    virtual ~IConstraintStmtField() { }
    
    
    virtual IExprId *getName() const = 0;
    
    virtual void setName(IExprId *v, bool own=true) = 0;
    
    virtual IDataType *getType() const = 0;
    
    virtual void setType(IDataType *v, bool own=true) = 0;
};
    
    } // namespace pssp
    } // namespace ast
    
