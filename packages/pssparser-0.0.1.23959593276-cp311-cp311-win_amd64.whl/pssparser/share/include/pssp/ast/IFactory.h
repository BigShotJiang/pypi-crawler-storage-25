/****************************************************************************
 * IFactory.h
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 ****************************************************************************/
#pragma once

#include <memory>
#include "pssp/ast/AssignOp.h"
#include "pssp/ast/ExecKind.h"
#include "pssp/ast/ExprBinOp.h"
#include "pssp/ast/ExprUnaryOp.h"
#include "pssp/ast/ExtendTargetE.h"
#include "pssp/ast/FunctionParamDeclKind.h"
#include "pssp/ast/ParamDir.h"
#include "pssp/ast/PlatQual.h"
#include "pssp/ast/StringMethodId.h"
#include "pssp/ast/StructKind.h"
#include "pssp/ast/SymbolRefPathElemKind.h"
#include "pssp/ast/TypeCategory.h"
#include "pssp/ast/ITemplateParamDeclList.h"
#include "pssp/ast/IAssocData.h"
#include "pssp/ast/IExecTargetTemplateParam.h"
#include "pssp/ast/IExpr.h"
#include "pssp/ast/ITemplateParamValue.h"
#include "pssp/ast/IMonitorActivityMatchChoice.h"
#include "pssp/ast/ITemplateParamValueList.h"
#include "pssp/ast/IExprAggrMapElem.h"
#include "pssp/ast/IRefExpr.h"
#include "pssp/ast/IExprAggrStructElem.h"
#include "pssp/ast/IMonitorActivitySelectBranch.h"
#include "pssp/ast/IScopeChild.h"
#include "pssp/ast/IActivityMatchChoice.h"
#include "pssp/ast/ISymbolImportSpec.h"
#include "pssp/ast/ISymbolRefPath.h"
#include "pssp/ast/IActivitySelectBranch.h"
#include "pssp/ast/IActionFieldInitializer.h"
#include "pssp/ast/IActivityJoinSpec.h"
#include "pssp/ast/IMonitorActivityStmt.h"
#include "pssp/ast/INamedScopeChild.h"
#include "pssp/ast/IPackageImportStmt.h"
#include "pssp/ast/IActivitySchedulingConstraint.h"
#include "pssp/ast/IActivityStmt.h"
#include "pssp/ast/IProceduralStmtIfClause.h"
#include "pssp/ast/IAnnotation.h"
#include "pssp/ast/IAnnotationParam.h"
#include "pssp/ast/IConstraintStmt.h"
#include "pssp/ast/IPyImportFromStmt.h"
#include "pssp/ast/IPyImportStmt.h"
#include "pssp/ast/IRefExprScopeIndex.h"
#include "pssp/ast/IRefExprTypeScopeContext.h"
#include "pssp/ast/IRefExprTypeScopeGlobal.h"
#include "pssp/ast/IScope.h"
#include "pssp/ast/ICoverStmtInline.h"
#include "pssp/ast/ICoverStmtReference.h"
#include "pssp/ast/IDataType.h"
#include "pssp/ast/IScopeChildRef.h"
#include "pssp/ast/ISymbolChild.h"
#include "pssp/ast/ISymbolScopeRef.h"
#include "pssp/ast/ITemplateParamDecl.h"
#include "pssp/ast/IExecStmt.h"
#include "pssp/ast/IExecTargetTemplateBlock.h"
#include "pssp/ast/ITemplateParamExprValue.h"
#include "pssp/ast/IExportFunction.h"
#include "pssp/ast/ITemplateParamTypeValue.h"
#include "pssp/ast/ITypeIdentifier.h"
#include "pssp/ast/IExprAggrLiteral.h"
#include "pssp/ast/ITypeIdentifierElem.h"
#include "pssp/ast/ITypedefDeclaration.h"
#include "pssp/ast/IExprBin.h"
#include "pssp/ast/IExprBitSlice.h"
#include "pssp/ast/IExprBool.h"
#include "pssp/ast/IExprCast.h"
#include "pssp/ast/IExprCompileHas.h"
#include "pssp/ast/IExprCond.h"
#include "pssp/ast/IExprDomainOpenRangeList.h"
#include "pssp/ast/IExprDomainOpenRangeValue.h"
#include "pssp/ast/IExprHierarchicalId.h"
#include "pssp/ast/IExprId.h"
#include "pssp/ast/IExprIn.h"
#include "pssp/ast/IExprListLiteral.h"
#include "pssp/ast/IExprMemberPathElem.h"
#include "pssp/ast/IExprNull.h"
#include "pssp/ast/IExprNumber.h"
#include "pssp/ast/IExprOpenRangeList.h"
#include "pssp/ast/IExprOpenRangeValue.h"
#include "pssp/ast/IExprRefPath.h"
#include "pssp/ast/IExprRefPathElem.h"
#include "pssp/ast/IExprStaticRefPath.h"
#include "pssp/ast/IExprString.h"
#include "pssp/ast/IExprStructLiteral.h"
#include "pssp/ast/IExprStructLiteralItem.h"
#include "pssp/ast/IExprSubscript.h"
#include "pssp/ast/IExprSubstring.h"
#include "pssp/ast/IExprUnary.h"
#include "pssp/ast/IExtendEnum.h"
#include "pssp/ast/IFunctionDefinition.h"
#include "pssp/ast/IFunctionImport.h"
#include "pssp/ast/IFunctionParamDecl.h"
#include "pssp/ast/IGenericConstraintDeclValue.h"
#include "pssp/ast/IGenericConstraintParam.h"
#include "pssp/ast/IMethodParameterList.h"
#include "pssp/ast/IMonitorActivityActionTraversal.h"
#include "pssp/ast/IMonitorActivityConcat.h"
#include "pssp/ast/IActionHandleField.h"
#include "pssp/ast/IMonitorActivityEventually.h"
#include "pssp/ast/IMonitorActivityIfElse.h"
#include "pssp/ast/IMonitorActivityMatch.h"
#include "pssp/ast/IActivityBindStmt.h"
#include "pssp/ast/IActivityConstraint.h"
#include "pssp/ast/IMonitorActivityMonitorTraversal.h"
#include "pssp/ast/IMonitorActivityOverlap.h"
#include "pssp/ast/IMonitorActivityRepeatCount.h"
#include "pssp/ast/IMonitorActivityRepeatWhile.h"
#include "pssp/ast/IActivityJoinSpecBranch.h"
#include "pssp/ast/IActivityJoinSpecFirst.h"
#include "pssp/ast/IActivityJoinSpecNone.h"
#include "pssp/ast/IActivityJoinSpecSelect.h"
#include "pssp/ast/IMonitorActivitySelect.h"
#include "pssp/ast/IActivityLabeledStmt.h"
#include "pssp/ast/IMonitorConstraint.h"
#include "pssp/ast/INamedScope.h"
#include "pssp/ast/IPackageScope.h"
#include "pssp/ast/IProceduralStmtAssignment.h"
#include "pssp/ast/IProceduralStmtBody.h"
#include "pssp/ast/IProceduralStmtBreak.h"
#include "pssp/ast/IProceduralStmtContinue.h"
#include "pssp/ast/IProceduralStmtDataDeclaration.h"
#include "pssp/ast/IProceduralStmtExpr.h"
#include "pssp/ast/IProceduralStmtFunctionCall.h"
#include "pssp/ast/IProceduralStmtIfElse.h"
#include "pssp/ast/IProceduralStmtMatch.h"
#include "pssp/ast/IProceduralStmtMatchChoice.h"
#include "pssp/ast/IProceduralStmtRandomize.h"
#include "pssp/ast/IProceduralStmtReturn.h"
#include "pssp/ast/IConstraintScope.h"
#include "pssp/ast/IConstraintStmtDefault.h"
#include "pssp/ast/IConstraintStmtDefaultDisable.h"
#include "pssp/ast/IConstraintStmtExpr.h"
#include "pssp/ast/IConstraintStmtField.h"
#include "pssp/ast/IProceduralStmtYield.h"
#include "pssp/ast/IConstraintStmtIf.h"
#include "pssp/ast/IConstraintStmtUnique.h"
#include "pssp/ast/ISymbolChildrenScope.h"
#include "pssp/ast/IDataTypeBool.h"
#include "pssp/ast/IDataTypeChandle.h"
#include "pssp/ast/IDataTypeEnum.h"
#include "pssp/ast/IDataTypeInt.h"
#include "pssp/ast/IDataTypePyObj.h"
#include "pssp/ast/IDataTypeRef.h"
#include "pssp/ast/IDataTypeString.h"
#include "pssp/ast/IDataTypeUserDefined.h"
#include "pssp/ast/IEnumDecl.h"
#include "pssp/ast/IEnumItem.h"
#include "pssp/ast/ITemplateCategoryTypeParamDecl.h"
#include "pssp/ast/ITemplateGenericTypeParamDecl.h"
#include "pssp/ast/IExprAggrEmpty.h"
#include "pssp/ast/IExprAggrList.h"
#include "pssp/ast/ITemplateValueParamDecl.h"
#include "pssp/ast/IExprAggrMap.h"
#include "pssp/ast/IExprAggrStruct.h"
#include "pssp/ast/IExprRefPathContext.h"
#include "pssp/ast/IExprRefPathId.h"
#include "pssp/ast/IExprRefPathStatic.h"
#include "pssp/ast/IExprRefPathStaticRooted.h"
#include "pssp/ast/IExprSignedNumber.h"
#include "pssp/ast/IExprUnsignedNumber.h"
#include "pssp/ast/IExtendType.h"
#include "pssp/ast/IField.h"
#include "pssp/ast/IFieldClaim.h"
#include "pssp/ast/IFieldCompRef.h"
#include "pssp/ast/IFieldRef.h"
#include "pssp/ast/IFunctionImportProto.h"
#include "pssp/ast/IFunctionImportType.h"
#include "pssp/ast/IFunctionPrototype.h"
#include "pssp/ast/IGlobalScope.h"
#include "pssp/ast/IActivityActionHandleTraversal.h"
#include "pssp/ast/IActivityActionTypeTraversal.h"
#include "pssp/ast/IActivityAtomicBlock.h"
#include "pssp/ast/IActivityForeach.h"
#include "pssp/ast/IActivityIfElse.h"
#include "pssp/ast/IActivityMatch.h"
#include "pssp/ast/IActivityRepeatCount.h"
#include "pssp/ast/IActivityRepeatWhile.h"
#include "pssp/ast/IActivityReplicate.h"
#include "pssp/ast/IActivitySelect.h"
#include "pssp/ast/IActivitySuper.h"
#include "pssp/ast/IProceduralStmtRepeatWhile.h"
#include "pssp/ast/IConstraintBlock.h"
#include "pssp/ast/IProceduralStmtWhile.h"
#include "pssp/ast/IConstraintStmtForall.h"
#include "pssp/ast/IConstraintStmtForeach.h"
#include "pssp/ast/IConstraintStmtImplication.h"
#include "pssp/ast/ISymbolScope.h"
#include "pssp/ast/ITypeScope.h"
#include "pssp/ast/IExprRefPathStaticFunc.h"
#include "pssp/ast/IExprRefPathSuper.h"
#include "pssp/ast/IAction.h"
#include "pssp/ast/IMonitorActivityDecl.h"
#include "pssp/ast/IActivityDecl.h"
#include "pssp/ast/IMonitorActivitySchedule.h"
#include "pssp/ast/IMonitorActivitySequence.h"
#include "pssp/ast/IActivityLabeledScope.h"
#include "pssp/ast/IAnnotationDecl.h"
#include "pssp/ast/IComponent.h"
#include "pssp/ast/IProceduralStmtSymbolBodyScope.h"
#include "pssp/ast/IRootSymbolScope.h"
#include "pssp/ast/IConstraintSymbolScope.h"
#include "pssp/ast/IStruct.h"
#include "pssp/ast/ISymbolEnumScope.h"
#include "pssp/ast/ISymbolExtendScope.h"
#include "pssp/ast/ISymbolFunctionScope.h"
#include "pssp/ast/ISymbolTypeScope.h"
#include "pssp/ast/IExecScope.h"
#include "pssp/ast/IGenericConstraintDeclBool.h"
#include "pssp/ast/IMonitor.h"
#include "pssp/ast/IProceduralStmtRepeat.h"
#include "pssp/ast/IActivityParallel.h"
#include "pssp/ast/IActivitySchedule.h"
#include "pssp/ast/IProceduralStmtForeach.h"
#include "pssp/ast/IActivitySequence.h"
#include "pssp/ast/IExecBlock.h"
namespace pssp {
namespace ast {

class IFactory;
using IFactoryUP=std::unique_ptr<IFactory>;
class IFactory {
public:

    virtual ~IFactory() { }
    
    virtual ITemplateParamDeclList *mkTemplateParamDeclList() = 0;
    virtual IAssocData *mkAssocData() = 0;
    virtual IExecTargetTemplateParam *mkExecTargetTemplateParam(    IExpr* expr,
    int32_t start,
    int32_t end) = 0;
    virtual IExpr *mkExpr() = 0;
    virtual ITemplateParamValue *mkTemplateParamValue() = 0;
    virtual IMonitorActivityMatchChoice *mkMonitorActivityMatchChoice(    bool is_default,
    IExprOpenRangeList* cond,
    IScopeChild* body) = 0;
    virtual ITemplateParamValueList *mkTemplateParamValueList() = 0;
    virtual IExprAggrMapElem *mkExprAggrMapElem(    IExpr* lhs,
    IExpr* rhs) = 0;
    virtual IRefExpr *mkRefExpr() = 0;
    virtual IExprAggrStructElem *mkExprAggrStructElem(    IExprId* name,
    IExpr* value) = 0;
    virtual IMonitorActivitySelectBranch *mkMonitorActivitySelectBranch(    IExpr* guard,
    IScopeChild* body) = 0;
    virtual IScopeChild *mkScopeChild() = 0;
    virtual IActivityMatchChoice *mkActivityMatchChoice(    bool is_default,
    IExprOpenRangeList* cond,
    IScopeChild* body) = 0;
    virtual ISymbolImportSpec *mkSymbolImportSpec() = 0;
    virtual ISymbolRefPath *mkSymbolRefPath() = 0;
    virtual IActivitySelectBranch *mkActivitySelectBranch(    IExpr* guard,
    IExpr* weight,
    IScopeChild* body) = 0;
    virtual IActionFieldInitializer *mkActionFieldInitializer(    IExprHierarchicalId* path,
    IExpr* value) = 0;
    virtual IActivityJoinSpec *mkActivityJoinSpec() = 0;
    virtual IMonitorActivityStmt *mkMonitorActivityStmt() = 0;
    virtual INamedScopeChild *mkNamedScopeChild(    IExprId* name) = 0;
    virtual IPackageImportStmt *mkPackageImportStmt(    bool wildcard,
    IExprId* alias) = 0;
    virtual IActivitySchedulingConstraint *mkActivitySchedulingConstraint(    bool is_parallel) = 0;
    virtual IActivityStmt *mkActivityStmt() = 0;
    virtual IProceduralStmtIfClause *mkProceduralStmtIfClause(    IExpr* cond,
    IScopeChild* body) = 0;
    virtual IAnnotation *mkAnnotation(    ITypeIdentifier* type) = 0;
    virtual IAnnotationParam *mkAnnotationParam(    IExpr* value) = 0;
    virtual IConstraintStmt *mkConstraintStmt() = 0;
    virtual IPyImportFromStmt *mkPyImportFromStmt() = 0;
    virtual IPyImportStmt *mkPyImportStmt() = 0;
    virtual IRefExprScopeIndex *mkRefExprScopeIndex(    IRefExpr* base,
    int32_t offset) = 0;
    virtual IRefExprTypeScopeContext *mkRefExprTypeScopeContext(    IRefExpr* base,
    int32_t offset) = 0;
    virtual IRefExprTypeScopeGlobal *mkRefExprTypeScopeGlobal(    int32_t fileid) = 0;
    virtual IScope *mkScope() = 0;
    virtual ICoverStmtInline *mkCoverStmtInline(    IScopeChild* body) = 0;
    virtual ICoverStmtReference *mkCoverStmtReference(    IExprRefPath* target) = 0;
    virtual IDataType *mkDataType() = 0;
    virtual IScopeChildRef *mkScopeChildRef(    IScopeChild * target) = 0;
    virtual ISymbolChild *mkSymbolChild() = 0;
    virtual ISymbolScopeRef *mkSymbolScopeRef(    std::string name) = 0;
    virtual ITemplateParamDecl *mkTemplateParamDecl(    IExprId* name) = 0;
    virtual IExecStmt *mkExecStmt() = 0;
    virtual IExecTargetTemplateBlock *mkExecTargetTemplateBlock(    ExecKind kind,
    std::string data) = 0;
    virtual ITemplateParamExprValue *mkTemplateParamExprValue(    IExpr* value) = 0;
    virtual IExportFunction *mkExportFunction(    PlatQual plat,
    IExprId* name) = 0;
    virtual ITemplateParamTypeValue *mkTemplateParamTypeValue(    IDataType* value) = 0;
    virtual ITypeIdentifier *mkTypeIdentifier() = 0;
    virtual IExprAggrLiteral *mkExprAggrLiteral() = 0;
    virtual ITypeIdentifierElem *mkTypeIdentifierElem(    IExprId* id,
    ITemplateParamValueList* params) = 0;
    virtual ITypedefDeclaration *mkTypedefDeclaration(    IExprId* name,
    IDataType* type) = 0;
    virtual IExprBin *mkExprBin(    IExpr* lhs,
    ExprBinOp op,
    IExpr* rhs) = 0;
    virtual IExprBitSlice *mkExprBitSlice(    IExpr* lhs,
    IExpr* rhs) = 0;
    virtual IExprBool *mkExprBool(    bool value) = 0;
    virtual IExprCast *mkExprCast(    IDataType* casting_type,
    IExpr* expr) = 0;
    virtual IExprCompileHas *mkExprCompileHas(    IExprRefPathStatic* ref) = 0;
    virtual IExprCond *mkExprCond(    IExpr* cond_e,
    IExpr* true_e,
    IExpr* false_e) = 0;
    virtual IExprDomainOpenRangeList *mkExprDomainOpenRangeList() = 0;
    virtual IExprDomainOpenRangeValue *mkExprDomainOpenRangeValue(    bool single,
    IExpr* lhs,
    IExpr* rhs) = 0;
    virtual IExprHierarchicalId *mkExprHierarchicalId() = 0;
    virtual IExprId *mkExprId(    std::string id,
    bool is_escaped) = 0;
    virtual IExprIn *mkExprIn(    IExpr* lhs,
    IExprOpenRangeList* rhs) = 0;
    virtual IExprListLiteral *mkExprListLiteral() = 0;
    virtual IExprMemberPathElem *mkExprMemberPathElem(    IExprId* id,
    IMethodParameterList* params) = 0;
    virtual IExprNull *mkExprNull() = 0;
    virtual IExprNumber *mkExprNumber() = 0;
    virtual IExprOpenRangeList *mkExprOpenRangeList() = 0;
    virtual IExprOpenRangeValue *mkExprOpenRangeValue(    IExpr* lhs,
    IExpr* rhs) = 0;
    virtual IExprRefPath *mkExprRefPath() = 0;
    virtual IExprRefPathElem *mkExprRefPathElem() = 0;
    virtual IExprStaticRefPath *mkExprStaticRefPath(    bool is_global,
    IExprMemberPathElem* leaf) = 0;
    virtual IExprString *mkExprString(    std::string value,
    bool is_raw) = 0;
    virtual IExprStructLiteral *mkExprStructLiteral() = 0;
    virtual IExprStructLiteralItem *mkExprStructLiteralItem(    IExprId* id,
    IExpr* value) = 0;
    virtual IExprSubscript *mkExprSubscript(    IExpr* expr,
    IExpr* subscript) = 0;
    virtual IExprSubstring *mkExprSubstring(    IExpr* expr,
    IExpr* start,
    IExpr* end) = 0;
    virtual IExprUnary *mkExprUnary(    ExprUnaryOp op,
    IExpr* rhs) = 0;
    virtual IExtendEnum *mkExtendEnum(    ITypeIdentifier* target) = 0;
    virtual IFunctionDefinition *mkFunctionDefinition(    IFunctionPrototype* proto,
    IExecScope* body,
    PlatQual plat) = 0;
    virtual IFunctionImport *mkFunctionImport(    PlatQual plat,
    std::string lang) = 0;
    virtual IFunctionParamDecl *mkFunctionParamDecl(    FunctionParamDeclKind kind,
    IExprId* name,
    IDataType* type,
    ParamDir dir,
    IExpr* dflt) = 0;
    virtual IGenericConstraintDeclValue *mkGenericConstraintDeclValue() = 0;
    virtual IGenericConstraintParam *mkGenericConstraintParam(    IExprId* name,
    bool is_const,
    bool is_numeric,
    IDataType* type) = 0;
    virtual IMethodParameterList *mkMethodParameterList() = 0;
    virtual IMonitorActivityActionTraversal *mkMonitorActivityActionTraversal(    IExprRefPath* target,
    IConstraintStmt* with_c) = 0;
    virtual IMonitorActivityConcat *mkMonitorActivityConcat(    IMonitorActivityStmt* lhs,
    IMonitorActivityStmt* rhs) = 0;
    virtual IActionHandleField *mkActionHandleField(    IExprId* name,
    IDataType* type) = 0;
    virtual IMonitorActivityEventually *mkMonitorActivityEventually(    IExpr* condition,
    IMonitorActivityStmt* body) = 0;
    virtual IMonitorActivityIfElse *mkMonitorActivityIfElse(    IExpr* cond,
    IMonitorActivityStmt* true_s,
    IMonitorActivityStmt* false_s) = 0;
    virtual IMonitorActivityMatch *mkMonitorActivityMatch(    IExpr* cond) = 0;
    virtual IActivityBindStmt *mkActivityBindStmt(    IExprHierarchicalId* lhs) = 0;
    virtual IActivityConstraint *mkActivityConstraint(    IConstraintStmt* constraint) = 0;
    virtual IMonitorActivityMonitorTraversal *mkMonitorActivityMonitorTraversal(    IExprRefPath* target,
    IConstraintStmt* with_c) = 0;
    virtual IMonitorActivityOverlap *mkMonitorActivityOverlap(    IMonitorActivityStmt* lhs,
    IMonitorActivityStmt* rhs) = 0;
    virtual IMonitorActivityRepeatCount *mkMonitorActivityRepeatCount(    IExprId* loop_var,
    IExpr* count,
    IScopeChild* body) = 0;
    virtual IMonitorActivityRepeatWhile *mkMonitorActivityRepeatWhile(    IExpr* cond,
    IScopeChild* body) = 0;
    virtual IActivityJoinSpecBranch *mkActivityJoinSpecBranch() = 0;
    virtual IActivityJoinSpecFirst *mkActivityJoinSpecFirst(    IExpr* count) = 0;
    virtual IActivityJoinSpecNone *mkActivityJoinSpecNone() = 0;
    virtual IActivityJoinSpecSelect *mkActivityJoinSpecSelect(    IExpr* count) = 0;
    virtual IMonitorActivitySelect *mkMonitorActivitySelect() = 0;
    virtual IActivityLabeledStmt *mkActivityLabeledStmt() = 0;
    virtual IMonitorConstraint *mkMonitorConstraint(    IConstraintStmt* constraint) = 0;
    virtual INamedScope *mkNamedScope(    IExprId* name) = 0;
    virtual IPackageScope *mkPackageScope() = 0;
    virtual IProceduralStmtAssignment *mkProceduralStmtAssignment(    IExpr* lhs,
    AssignOp op,
    IExpr* rhs) = 0;
    virtual IProceduralStmtBody *mkProceduralStmtBody(    IScopeChild* body) = 0;
    virtual IProceduralStmtBreak *mkProceduralStmtBreak() = 0;
    virtual IProceduralStmtContinue *mkProceduralStmtContinue() = 0;
    virtual IProceduralStmtDataDeclaration *mkProceduralStmtDataDeclaration(    IExprId* name,
    IDataType* datatype,
    IExpr* init) = 0;
    virtual IProceduralStmtExpr *mkProceduralStmtExpr(    IExpr* expr) = 0;
    virtual IProceduralStmtFunctionCall *mkProceduralStmtFunctionCall(    IExprRefPathStaticRooted* prefix) = 0;
    virtual IProceduralStmtIfElse *mkProceduralStmtIfElse() = 0;
    virtual IProceduralStmtMatch *mkProceduralStmtMatch(    IExpr* expr) = 0;
    virtual IProceduralStmtMatchChoice *mkProceduralStmtMatchChoice(    bool is_default,
    IExprOpenRangeList* cond,
    IScopeChild* body) = 0;
    virtual IProceduralStmtRandomize *mkProceduralStmtRandomize(    IExpr* target) = 0;
    virtual IProceduralStmtReturn *mkProceduralStmtReturn(    IExpr* expr) = 0;
    virtual IConstraintScope *mkConstraintScope() = 0;
    virtual IConstraintStmtDefault *mkConstraintStmtDefault(    IExprHierarchicalId* hid,
    IExpr* expr) = 0;
    virtual IConstraintStmtDefaultDisable *mkConstraintStmtDefaultDisable(    IExprHierarchicalId* hid) = 0;
    virtual IConstraintStmtExpr *mkConstraintStmtExpr(    IExpr* expr) = 0;
    virtual IConstraintStmtField *mkConstraintStmtField(    IExprId* name,
    IDataType* type) = 0;
    virtual IProceduralStmtYield *mkProceduralStmtYield() = 0;
    virtual IConstraintStmtIf *mkConstraintStmtIf(    IExpr* cond,
    IConstraintScope* true_c,
    IConstraintScope* false_c) = 0;
    virtual IConstraintStmtUnique *mkConstraintStmtUnique() = 0;
    virtual ISymbolChildrenScope *mkSymbolChildrenScope(    std::string name) = 0;
    virtual IDataTypeBool *mkDataTypeBool() = 0;
    virtual IDataTypeChandle *mkDataTypeChandle() = 0;
    virtual IDataTypeEnum *mkDataTypeEnum(    IDataTypeUserDefined* tid,
    IExprOpenRangeList* in_rangelist) = 0;
    virtual IDataTypeInt *mkDataTypeInt(    bool is_signed,
    IExpr* width,
    IExprDomainOpenRangeList* in_range) = 0;
    virtual IDataTypePyObj *mkDataTypePyObj() = 0;
    virtual IDataTypeRef *mkDataTypeRef(    IDataTypeUserDefined* type) = 0;
    virtual IDataTypeString *mkDataTypeString(    bool has_range) = 0;
    virtual IDataTypeUserDefined *mkDataTypeUserDefined(    bool is_global,
    ITypeIdentifier* type_id) = 0;
    virtual IEnumDecl *mkEnumDecl(    IExprId* name) = 0;
    virtual IEnumItem *mkEnumItem(    IExprId* name,
    IExpr* value) = 0;
    virtual ITemplateCategoryTypeParamDecl *mkTemplateCategoryTypeParamDecl(    IExprId* name,
    TypeCategory category,
    ITypeIdentifier* restriction,
    IDataType* dflt) = 0;
    virtual ITemplateGenericTypeParamDecl *mkTemplateGenericTypeParamDecl(    IExprId* name,
    IDataType* dflt) = 0;
    virtual IExprAggrEmpty *mkExprAggrEmpty() = 0;
    virtual IExprAggrList *mkExprAggrList() = 0;
    virtual ITemplateValueParamDecl *mkTemplateValueParamDecl(    IExprId* name,
    IDataType* type,
    IExpr* dflt) = 0;
    virtual IExprAggrMap *mkExprAggrMap() = 0;
    virtual IExprAggrStruct *mkExprAggrStruct() = 0;
    virtual IExprRefPathContext *mkExprRefPathContext(    IExprHierarchicalId* hier_id) = 0;
    virtual IExprRefPathId *mkExprRefPathId(    IExprId* id) = 0;
    virtual IExprRefPathStatic *mkExprRefPathStatic(    bool is_global) = 0;
    virtual IExprRefPathStaticRooted *mkExprRefPathStaticRooted(    IExprRefPathStatic* root,
    IExprHierarchicalId* leaf) = 0;
    virtual IExprSignedNumber *mkExprSignedNumber(    std::string image,
    int32_t width,
    int64_t value) = 0;
    virtual IExprUnsignedNumber *mkExprUnsignedNumber(    std::string image,
    int32_t width,
    uint64_t value) = 0;
    virtual IExtendType *mkExtendType(    ExtendTargetE kind,
    ITypeIdentifier* target) = 0;
    virtual IField *mkField(    IExprId* name,
    IDataType* type,
    FieldAttr attr,
    IExpr* init) = 0;
    virtual IFieldClaim *mkFieldClaim(    IExprId* name,
    IDataTypeUserDefined* type,
    bool is_lock) = 0;
    virtual IFieldCompRef *mkFieldCompRef(    IExprId* name,
    IDataTypeUserDefined* type) = 0;
    virtual IFieldRef *mkFieldRef(    IExprId* name,
    IDataTypeUserDefined* type,
    bool is_input) = 0;
    virtual IFunctionImportProto *mkFunctionImportProto(    PlatQual plat,
    std::string lang,
    IFunctionPrototype* proto) = 0;
    virtual IFunctionImportType *mkFunctionImportType(    PlatQual plat,
    std::string lang,
    ITypeIdentifier* type) = 0;
    virtual IFunctionPrototype *mkFunctionPrototype(    IExprId* name,
    IDataType* rtype,
    bool is_target,
    bool is_solve) = 0;
    virtual IGlobalScope *mkGlobalScope(    int32_t fileid) = 0;
    virtual IActivityActionHandleTraversal *mkActivityActionHandleTraversal(    IExprRefPathContext* target,
    IConstraintStmt* with_c) = 0;
    virtual IActivityActionTypeTraversal *mkActivityActionTypeTraversal(    IDataTypeUserDefined* target,
    IConstraintStmt* with_c) = 0;
    virtual IActivityAtomicBlock *mkActivityAtomicBlock(    IScopeChild* body) = 0;
    virtual IActivityForeach *mkActivityForeach(    IExprId* it_id,
    IExprId* idx_id,
    IExprRefPathContext* target,
    IScopeChild* body) = 0;
    virtual IActivityIfElse *mkActivityIfElse(    IExpr* cond,
    IActivityStmt* true_s,
    IActivityStmt* false_s) = 0;
    virtual IActivityMatch *mkActivityMatch(    IExpr* cond) = 0;
    virtual IActivityRepeatCount *mkActivityRepeatCount(    IExprId* loop_var,
    IExpr* count,
    IScopeChild* body) = 0;
    virtual IActivityRepeatWhile *mkActivityRepeatWhile(    IExpr* cond,
    IScopeChild* body) = 0;
    virtual IActivityReplicate *mkActivityReplicate(    IExprId* idx_id,
    IExprId* it_label,
    IScopeChild* body) = 0;
    virtual IActivitySelect *mkActivitySelect() = 0;
    virtual IActivitySuper *mkActivitySuper() = 0;
    virtual IProceduralStmtRepeatWhile *mkProceduralStmtRepeatWhile(    IScopeChild* body,
    IExpr* expr) = 0;
    virtual IConstraintBlock *mkConstraintBlock(    std::string name,
    bool is_dynamic) = 0;
    virtual IProceduralStmtWhile *mkProceduralStmtWhile(    IScopeChild* body,
    IExpr* expr) = 0;
    virtual IConstraintStmtForall *mkConstraintStmtForall(    IExprId* iterator_id,
    IDataTypeUserDefined* type_id,
    IExprRefPath* ref_path) = 0;
    virtual IConstraintStmtForeach *mkConstraintStmtForeach(    IExpr* expr) = 0;
    virtual IConstraintStmtImplication *mkConstraintStmtImplication(    IExpr* cond) = 0;
    virtual ISymbolScope *mkSymbolScope(    std::string name) = 0;
    virtual ITypeScope *mkTypeScope(    IExprId* name,
    ITypeIdentifier* super_t) = 0;
    virtual IExprRefPathStaticFunc *mkExprRefPathStaticFunc(    bool is_global,
    IMethodParameterList* params) = 0;
    virtual IExprRefPathSuper *mkExprRefPathSuper(    IExprHierarchicalId* hier_id) = 0;
    virtual IAction *mkAction(    IExprId* name,
    ITypeIdentifier* super_t,
    bool is_abstract) = 0;
    virtual IMonitorActivityDecl *mkMonitorActivityDecl(    std::string name) = 0;
    virtual IActivityDecl *mkActivityDecl(    std::string name) = 0;
    virtual IMonitorActivitySchedule *mkMonitorActivitySchedule(    std::string name) = 0;
    virtual IMonitorActivitySequence *mkMonitorActivitySequence(    std::string name) = 0;
    virtual IActivityLabeledScope *mkActivityLabeledScope(    std::string name) = 0;
    virtual IAnnotationDecl *mkAnnotationDecl(    IExprId* name,
    ITypeIdentifier* super_t) = 0;
    virtual IComponent *mkComponent(    IExprId* name,
    ITypeIdentifier* super_t) = 0;
    virtual IProceduralStmtSymbolBodyScope *mkProceduralStmtSymbolBodyScope(    std::string name,
    IScopeChild* body) = 0;
    virtual IRootSymbolScope *mkRootSymbolScope(    std::string name) = 0;
    virtual IConstraintSymbolScope *mkConstraintSymbolScope(    std::string name) = 0;
    virtual IStruct *mkStruct(    IExprId* name,
    ITypeIdentifier* super_t,
    StructKind kind) = 0;
    virtual ISymbolEnumScope *mkSymbolEnumScope(    std::string name) = 0;
    virtual ISymbolExtendScope *mkSymbolExtendScope(    std::string name) = 0;
    virtual ISymbolFunctionScope *mkSymbolFunctionScope(    std::string name) = 0;
    virtual ISymbolTypeScope *mkSymbolTypeScope(    std::string name,
    ISymbolScope* plist) = 0;
    virtual IExecScope *mkExecScope(    std::string name) = 0;
    virtual IGenericConstraintDeclBool *mkGenericConstraintDeclBool(    std::string name,
    bool is_dynamic) = 0;
    virtual IMonitor *mkMonitor(    IExprId* name,
    ITypeIdentifier* super_t) = 0;
    virtual IProceduralStmtRepeat *mkProceduralStmtRepeat(    std::string name,
    IScopeChild* body,
    IExprId* it_id,
    IExpr* count) = 0;
    virtual IActivityParallel *mkActivityParallel(    std::string name,
    IActivityJoinSpec* join_spec) = 0;
    virtual IActivitySchedule *mkActivitySchedule(    std::string name,
    IActivityJoinSpec* join_spec) = 0;
    virtual IProceduralStmtForeach *mkProceduralStmtForeach(    std::string name,
    IScopeChild* body,
    IExprRefPath* path,
    IExprId* it_id,
    IExprId* idx_id) = 0;
    virtual IActivitySequence *mkActivitySequence(    std::string name) = 0;
    virtual IExecBlock *mkExecBlock(    std::string name,
    ExecKind kind) = 0;
};

} // namespace pssp
} // namespace ast

