/****************************************************************************
 * IEnumItem.h
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 ****************************************************************************/
#pragma once
#include <stdint.h>
#include <unordered_map>
#include <memory>
#include <set>
#include <string>
#include <vector>
#include "pssp/ast/impl/UP.h"
#include "pssp/ast/IVisitor.h"
#include "pssp/ast/INamedScopeChild.h"

namespace pssp {
namespace ast {

class INamedScopeChild;
using INamedScopeChildUP=UP<INamedScopeChild>;
typedef std::shared_ptr<INamedScopeChild> INamedScopeChildSP;
class IExpr;
using IExprUP=UP<IExpr>;
typedef std::shared_ptr<IExpr> IExprSP;
class ISymbolEnumScope;
using ISymbolEnumScopeUP=UP<ISymbolEnumScope>;
typedef std::shared_ptr<ISymbolEnumScope> ISymbolEnumScopeSP;
class IEnumItem;
using IEnumItemUP=UP<IEnumItem>;
class IEnumItem : public virtual INamedScopeChild {
public:
    
    virtual ~IEnumItem() { }
    
    
    virtual IExpr *getValue() const = 0;
    
    virtual void setValue(IExpr *v, bool own=true) = 0;
    
    virtual ISymbolEnumScope *getUpper() = 0;
    
    virtual void setUpper(ISymbolEnumScope *v) = 0;
};
    
    } // namespace pssp
    } // namespace ast
    
