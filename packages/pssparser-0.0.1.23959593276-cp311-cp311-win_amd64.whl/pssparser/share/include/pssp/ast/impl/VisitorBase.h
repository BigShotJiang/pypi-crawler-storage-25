/****************************************************************************
 * VisitorBase.h
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 ****************************************************************************/
#pragma once
#include "pssp/ast/IVisitor.h"

#include "pssp/ast/ITemplateParamDeclList.h"
#include "pssp/ast/IAssocData.h"
#include "pssp/ast/IExecTargetTemplateParam.h"
#include "pssp/ast/IExpr.h"
#include "pssp/ast/ITemplateParamValue.h"
#include "pssp/ast/IMonitorActivityMatchChoice.h"
#include "pssp/ast/ITemplateParamValueList.h"
#include "pssp/ast/IExprAggrMapElem.h"
#include "pssp/ast/IRefExpr.h"
#include "pssp/ast/IExprAggrStructElem.h"
#include "pssp/ast/IMonitorActivitySelectBranch.h"
#include "pssp/ast/IScopeChild.h"
#include "pssp/ast/IActivityMatchChoice.h"
#include "pssp/ast/ISymbolImportSpec.h"
#include "pssp/ast/ISymbolRefPath.h"
#include "pssp/ast/IActivitySelectBranch.h"
#include "pssp/ast/IActionFieldInitializer.h"
#include "pssp/ast/IActivityJoinSpec.h"
#include "pssp/ast/IMonitorActivityStmt.h"
#include "pssp/ast/INamedScopeChild.h"
#include "pssp/ast/IPackageImportStmt.h"
#include "pssp/ast/IActivitySchedulingConstraint.h"
#include "pssp/ast/IActivityStmt.h"
#include "pssp/ast/IProceduralStmtIfClause.h"
#include "pssp/ast/IAnnotation.h"
#include "pssp/ast/IAnnotationParam.h"
#include "pssp/ast/IConstraintStmt.h"
#include "pssp/ast/IPyImportFromStmt.h"
#include "pssp/ast/IPyImportStmt.h"
#include "pssp/ast/IRefExprScopeIndex.h"
#include "pssp/ast/IRefExprTypeScopeContext.h"
#include "pssp/ast/IRefExprTypeScopeGlobal.h"
#include "pssp/ast/IScope.h"
#include "pssp/ast/ICoverStmtInline.h"
#include "pssp/ast/ICoverStmtReference.h"
#include "pssp/ast/IDataType.h"
#include "pssp/ast/IScopeChildRef.h"
#include "pssp/ast/ISymbolChild.h"
#include "pssp/ast/ISymbolScopeRef.h"
#include "pssp/ast/ITemplateParamDecl.h"
#include "pssp/ast/IExecStmt.h"
#include "pssp/ast/IExecTargetTemplateBlock.h"
#include "pssp/ast/ITemplateParamExprValue.h"
#include "pssp/ast/IExportFunction.h"
#include "pssp/ast/ITemplateParamTypeValue.h"
#include "pssp/ast/ITypeIdentifier.h"
#include "pssp/ast/IExprAggrLiteral.h"
#include "pssp/ast/ITypeIdentifierElem.h"
#include "pssp/ast/ITypedefDeclaration.h"
#include "pssp/ast/IExprBin.h"
#include "pssp/ast/IExprBitSlice.h"
#include "pssp/ast/IExprBool.h"
#include "pssp/ast/IExprCast.h"
#include "pssp/ast/IExprCompileHas.h"
#include "pssp/ast/IExprCond.h"
#include "pssp/ast/IExprDomainOpenRangeList.h"
#include "pssp/ast/IExprDomainOpenRangeValue.h"
#include "pssp/ast/IExprHierarchicalId.h"
#include "pssp/ast/IExprId.h"
#include "pssp/ast/IExprIn.h"
#include "pssp/ast/IExprListLiteral.h"
#include "pssp/ast/IExprMemberPathElem.h"
#include "pssp/ast/IExprNull.h"
#include "pssp/ast/IExprNumber.h"
#include "pssp/ast/IExprOpenRangeList.h"
#include "pssp/ast/IExprOpenRangeValue.h"
#include "pssp/ast/IExprRefPath.h"
#include "pssp/ast/IExprRefPathElem.h"
#include "pssp/ast/IExprStaticRefPath.h"
#include "pssp/ast/IExprString.h"
#include "pssp/ast/IExprStructLiteral.h"
#include "pssp/ast/IExprStructLiteralItem.h"
#include "pssp/ast/IExprSubscript.h"
#include "pssp/ast/IExprSubstring.h"
#include "pssp/ast/IExprUnary.h"
#include "pssp/ast/IExtendEnum.h"
#include "pssp/ast/IFunctionDefinition.h"
#include "pssp/ast/IFunctionImport.h"
#include "pssp/ast/IFunctionParamDecl.h"
#include "pssp/ast/IGenericConstraintDeclValue.h"
#include "pssp/ast/IGenericConstraintParam.h"
#include "pssp/ast/IMethodParameterList.h"
#include "pssp/ast/IMonitorActivityActionTraversal.h"
#include "pssp/ast/IMonitorActivityConcat.h"
#include "pssp/ast/IActionHandleField.h"
#include "pssp/ast/IMonitorActivityEventually.h"
#include "pssp/ast/IMonitorActivityIfElse.h"
#include "pssp/ast/IMonitorActivityMatch.h"
#include "pssp/ast/IActivityBindStmt.h"
#include "pssp/ast/IActivityConstraint.h"
#include "pssp/ast/IMonitorActivityMonitorTraversal.h"
#include "pssp/ast/IMonitorActivityOverlap.h"
#include "pssp/ast/IMonitorActivityRepeatCount.h"
#include "pssp/ast/IMonitorActivityRepeatWhile.h"
#include "pssp/ast/IActivityJoinSpecBranch.h"
#include "pssp/ast/IActivityJoinSpecFirst.h"
#include "pssp/ast/IActivityJoinSpecNone.h"
#include "pssp/ast/IActivityJoinSpecSelect.h"
#include "pssp/ast/IMonitorActivitySelect.h"
#include "pssp/ast/IActivityLabeledStmt.h"
#include "pssp/ast/IMonitorConstraint.h"
#include "pssp/ast/INamedScope.h"
#include "pssp/ast/IPackageScope.h"
#include "pssp/ast/IProceduralStmtAssignment.h"
#include "pssp/ast/IProceduralStmtBody.h"
#include "pssp/ast/IProceduralStmtBreak.h"
#include "pssp/ast/IProceduralStmtContinue.h"
#include "pssp/ast/IProceduralStmtDataDeclaration.h"
#include "pssp/ast/IProceduralStmtExpr.h"
#include "pssp/ast/IProceduralStmtFunctionCall.h"
#include "pssp/ast/IProceduralStmtIfElse.h"
#include "pssp/ast/IProceduralStmtMatch.h"
#include "pssp/ast/IProceduralStmtMatchChoice.h"
#include "pssp/ast/IProceduralStmtRandomize.h"
#include "pssp/ast/IProceduralStmtReturn.h"
#include "pssp/ast/IConstraintScope.h"
#include "pssp/ast/IConstraintStmtDefault.h"
#include "pssp/ast/IConstraintStmtDefaultDisable.h"
#include "pssp/ast/IConstraintStmtExpr.h"
#include "pssp/ast/IConstraintStmtField.h"
#include "pssp/ast/IProceduralStmtYield.h"
#include "pssp/ast/IConstraintStmtIf.h"
#include "pssp/ast/IConstraintStmtUnique.h"
#include "pssp/ast/ISymbolChildrenScope.h"
#include "pssp/ast/IDataTypeBool.h"
#include "pssp/ast/IDataTypeChandle.h"
#include "pssp/ast/IDataTypeEnum.h"
#include "pssp/ast/IDataTypeInt.h"
#include "pssp/ast/IDataTypePyObj.h"
#include "pssp/ast/IDataTypeRef.h"
#include "pssp/ast/IDataTypeString.h"
#include "pssp/ast/IDataTypeUserDefined.h"
#include "pssp/ast/IEnumDecl.h"
#include "pssp/ast/IEnumItem.h"
#include "pssp/ast/ITemplateCategoryTypeParamDecl.h"
#include "pssp/ast/ITemplateGenericTypeParamDecl.h"
#include "pssp/ast/IExprAggrEmpty.h"
#include "pssp/ast/IExprAggrList.h"
#include "pssp/ast/ITemplateValueParamDecl.h"
#include "pssp/ast/IExprAggrMap.h"
#include "pssp/ast/IExprAggrStruct.h"
#include "pssp/ast/IExprRefPathContext.h"
#include "pssp/ast/IExprRefPathId.h"
#include "pssp/ast/IExprRefPathStatic.h"
#include "pssp/ast/IExprRefPathStaticRooted.h"
#include "pssp/ast/IExprSignedNumber.h"
#include "pssp/ast/IExprUnsignedNumber.h"
#include "pssp/ast/IExtendType.h"
#include "pssp/ast/IField.h"
#include "pssp/ast/IFieldClaim.h"
#include "pssp/ast/IFieldCompRef.h"
#include "pssp/ast/IFieldRef.h"
#include "pssp/ast/IFunctionImportProto.h"
#include "pssp/ast/IFunctionImportType.h"
#include "pssp/ast/IFunctionPrototype.h"
#include "pssp/ast/IGlobalScope.h"
#include "pssp/ast/IActivityActionHandleTraversal.h"
#include "pssp/ast/IActivityActionTypeTraversal.h"
#include "pssp/ast/IActivityAtomicBlock.h"
#include "pssp/ast/IActivityForeach.h"
#include "pssp/ast/IActivityIfElse.h"
#include "pssp/ast/IActivityMatch.h"
#include "pssp/ast/IActivityRepeatCount.h"
#include "pssp/ast/IActivityRepeatWhile.h"
#include "pssp/ast/IActivityReplicate.h"
#include "pssp/ast/IActivitySelect.h"
#include "pssp/ast/IActivitySuper.h"
#include "pssp/ast/IProceduralStmtRepeatWhile.h"
#include "pssp/ast/IConstraintBlock.h"
#include "pssp/ast/IProceduralStmtWhile.h"
#include "pssp/ast/IConstraintStmtForall.h"
#include "pssp/ast/IConstraintStmtForeach.h"
#include "pssp/ast/IConstraintStmtImplication.h"
#include "pssp/ast/ISymbolScope.h"
#include "pssp/ast/ITypeScope.h"
#include "pssp/ast/IExprRefPathStaticFunc.h"
#include "pssp/ast/IExprRefPathSuper.h"
#include "pssp/ast/IAction.h"
#include "pssp/ast/IMonitorActivityDecl.h"
#include "pssp/ast/IActivityDecl.h"
#include "pssp/ast/IMonitorActivitySchedule.h"
#include "pssp/ast/IMonitorActivitySequence.h"
#include "pssp/ast/IActivityLabeledScope.h"
#include "pssp/ast/IAnnotationDecl.h"
#include "pssp/ast/IComponent.h"
#include "pssp/ast/IProceduralStmtSymbolBodyScope.h"
#include "pssp/ast/IRootSymbolScope.h"
#include "pssp/ast/IConstraintSymbolScope.h"
#include "pssp/ast/IStruct.h"
#include "pssp/ast/ISymbolEnumScope.h"
#include "pssp/ast/ISymbolExtendScope.h"
#include "pssp/ast/ISymbolFunctionScope.h"
#include "pssp/ast/ISymbolTypeScope.h"
#include "pssp/ast/IExecScope.h"
#include "pssp/ast/IGenericConstraintDeclBool.h"
#include "pssp/ast/IMonitor.h"
#include "pssp/ast/IProceduralStmtRepeat.h"
#include "pssp/ast/IActivityParallel.h"
#include "pssp/ast/IActivitySchedule.h"
#include "pssp/ast/IProceduralStmtForeach.h"
#include "pssp/ast/IActivitySequence.h"
#include "pssp/ast/IExecBlock.h"

namespace pssp {
namespace ast {


class VisitorBase : public virtual IVisitor {
public:
    VisitorBase(IVisitor *this_p=0) : m_this(this_p?this_p:this) { }
    
    virtual ~VisitorBase() { }
    
    virtual void visitTemplateParamDeclList(ITemplateParamDeclList *i) override {
        for (std::vector<ITemplateParamDeclUP>::const_iterator
                it=i->getParams().begin();
                it!=i->getParams().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitAssocData(IAssocData *i) override {
    }
    
    virtual void visitExecTargetTemplateParam(IExecTargetTemplateParam *i) override {
        if (i->getExpr()) {
            i->getExpr()->accept(this);
        }
    }
    
    virtual void visitExpr(IExpr *i) override {
    }
    
    virtual void visitTemplateParamValue(ITemplateParamValue *i) override {
    }
    
    virtual void visitMonitorActivityMatchChoice(IMonitorActivityMatchChoice *i) override {
        if (i->getCond()) {
            i->getCond()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitTemplateParamValueList(ITemplateParamValueList *i) override {
        for (std::vector<ITemplateParamValueUP>::const_iterator
                it=i->getValues().begin();
                it!=i->getValues().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitExprAggrMapElem(IExprAggrMapElem *i) override {
        if (i->getLhs()) {
            i->getLhs()->accept(this);
        }
        if (i->getRhs()) {
            i->getRhs()->accept(this);
        }
    }
    
    virtual void visitRefExpr(IRefExpr *i) override {
    }
    
    virtual void visitExprAggrStructElem(IExprAggrStructElem *i) override {
        if (i->getName()) {
            i->getName()->accept(this);
        }
        if (i->getValue()) {
            i->getValue()->accept(this);
        }
    }
    
    virtual void visitMonitorActivitySelectBranch(IMonitorActivitySelectBranch *i) override {
        if (i->getGuard()) {
            i->getGuard()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitScopeChild(IScopeChild *i) override {
        if (i->getAssocData()) {
            i->getAssocData()->accept(this);
        }
        for (std::vector<IAnnotationUP>::const_iterator
                it=i->getAnnotations().begin();
                it!=i->getAnnotations().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitActivityMatchChoice(IActivityMatchChoice *i) override {
        if (i->getCond()) {
            i->getCond()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitSymbolImportSpec(ISymbolImportSpec *i) override {
        for (std::vector<IPackageImportStmt *>::const_iterator
                it=i->getImports().begin();
                it!=i->getImports().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitSymbolRefPath(ISymbolRefPath *i) override {
    }
    
    virtual void visitActivitySelectBranch(IActivitySelectBranch *i) override {
        if (i->getGuard()) {
            i->getGuard()->accept(this);
        }
        if (i->getWeight()) {
            i->getWeight()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitActionFieldInitializer(IActionFieldInitializer *i) override {
        visitScopeChild(i);
        if (i->getPath()) {
            i->getPath()->accept(this);
        }
        if (i->getValue()) {
            i->getValue()->accept(this);
        }
    }
    
    virtual void visitActivityJoinSpec(IActivityJoinSpec *i) override {
        visitScopeChild(i);
    }
    
    virtual void visitMonitorActivityStmt(IMonitorActivityStmt *i) override {
        visitScopeChild(i);
    }
    
    virtual void visitNamedScopeChild(INamedScopeChild *i) override {
        visitScopeChild(i);
        if (i->getName()) {
            i->getName()->accept(this);
        }
    }
    
    virtual void visitPackageImportStmt(IPackageImportStmt *i) override {
        visitScopeChild(i);
        if (i->getAlias()) {
            i->getAlias()->accept(this);
        }
        if (i->getPath()) {
            i->getPath()->accept(this);
        }
    }
    
    virtual void visitActivitySchedulingConstraint(IActivitySchedulingConstraint *i) override {
        visitScopeChild(i);
        for (std::vector<IExprHierarchicalIdUP>::const_iterator
                it=i->getTargets().begin();
                it!=i->getTargets().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitActivityStmt(IActivityStmt *i) override {
        visitScopeChild(i);
    }
    
    virtual void visitProceduralStmtIfClause(IProceduralStmtIfClause *i) override {
        visitScopeChild(i);
        if (i->getCond()) {
            i->getCond()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitAnnotation(IAnnotation *i) override {
        visitScopeChild(i);
        if (i->getType()) {
            i->getType()->accept(this);
        }
        for (std::vector<IAnnotationParamUP>::const_iterator
                it=i->getParameters().begin();
                it!=i->getParameters().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitAnnotationParam(IAnnotationParam *i) override {
        visitScopeChild(i);
        if (i->getName()) {
            i->getName()->accept(this);
        }
        if (i->getValue()) {
            i->getValue()->accept(this);
        }
    }
    
    virtual void visitConstraintStmt(IConstraintStmt *i) override {
        visitScopeChild(i);
    }
    
    virtual void visitPyImportFromStmt(IPyImportFromStmt *i) override {
        visitScopeChild(i);
        for (std::vector<IExprIdUP>::const_iterator
                it=i->getPath().begin();
                it!=i->getPath().end(); it++) {
            (*it)->accept(this);
        }
        for (std::vector<IExprIdUP>::const_iterator
                it=i->getTargets().begin();
                it!=i->getTargets().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitPyImportStmt(IPyImportStmt *i) override {
        visitScopeChild(i);
        for (std::vector<IExprIdUP>::const_iterator
                it=i->getPath().begin();
                it!=i->getPath().end(); it++) {
            (*it)->accept(this);
        }
        if (i->getAlias()) {
            i->getAlias()->accept(this);
        }
    }
    
    virtual void visitRefExprScopeIndex(IRefExprScopeIndex *i) override {
        visitRefExpr(i);
        if (i->getBase()) {
            i->getBase()->accept(this);
        }
    }
    
    virtual void visitRefExprTypeScopeContext(IRefExprTypeScopeContext *i) override {
        visitRefExpr(i);
        if (i->getBase()) {
            i->getBase()->accept(this);
        }
    }
    
    virtual void visitRefExprTypeScopeGlobal(IRefExprTypeScopeGlobal *i) override {
        visitRefExpr(i);
    }
    
    virtual void visitScope(IScope *i) override {
        visitScopeChild(i);
        for (std::vector<IScopeChildUP>::const_iterator
                it=i->getChildren().begin();
                it!=i->getChildren().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitCoverStmtInline(ICoverStmtInline *i) override {
        visitScopeChild(i);
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitCoverStmtReference(ICoverStmtReference *i) override {
        visitScopeChild(i);
        if (i->getTarget()) {
            i->getTarget()->accept(this);
        }
    }
    
    virtual void visitDataType(IDataType *i) override {
        visitScopeChild(i);
    }
    
    virtual void visitScopeChildRef(IScopeChildRef *i) override {
        visitScopeChild(i);
        if (i->getTarget()) {
            i->getTarget()->accept(this);
        }
    }
    
    virtual void visitSymbolChild(ISymbolChild *i) override {
        visitScopeChild(i);
    }
    
    virtual void visitSymbolScopeRef(ISymbolScopeRef *i) override {
        visitScopeChild(i);
    }
    
    virtual void visitTemplateParamDecl(ITemplateParamDecl *i) override {
        visitScopeChild(i);
        if (i->getName()) {
            i->getName()->accept(this);
        }
    }
    
    virtual void visitExecStmt(IExecStmt *i) override {
        visitScopeChild(i);
    }
    
    virtual void visitExecTargetTemplateBlock(IExecTargetTemplateBlock *i) override {
        visitScopeChild(i);
        for (std::vector<IExecTargetTemplateParamUP>::const_iterator
                it=i->getParameters().begin();
                it!=i->getParameters().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitTemplateParamExprValue(ITemplateParamExprValue *i) override {
        visitTemplateParamValue(i);
        if (i->getValue()) {
            i->getValue()->accept(this);
        }
    }
    
    virtual void visitExportFunction(IExportFunction *i) override {
        visitScopeChild(i);
        if (i->getName()) {
            i->getName()->accept(this);
        }
    }
    
    virtual void visitTemplateParamTypeValue(ITemplateParamTypeValue *i) override {
        visitTemplateParamValue(i);
        if (i->getValue()) {
            i->getValue()->accept(this);
        }
    }
    
    virtual void visitTypeIdentifier(ITypeIdentifier *i) override {
        visitExpr(i);
        for (std::vector<ITypeIdentifierElemUP>::const_iterator
                it=i->getElems().begin();
                it!=i->getElems().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitExprAggrLiteral(IExprAggrLiteral *i) override {
        visitExpr(i);
    }
    
    virtual void visitTypeIdentifierElem(ITypeIdentifierElem *i) override {
        visitExpr(i);
        if (i->getId()) {
            i->getId()->accept(this);
        }
        if (i->getParams()) {
            i->getParams()->accept(this);
        }
    }
    
    virtual void visitTypedefDeclaration(ITypedefDeclaration *i) override {
        visitScopeChild(i);
        if (i->getName()) {
            i->getName()->accept(this);
        }
        if (i->getType()) {
            i->getType()->accept(this);
        }
    }
    
    virtual void visitExprBin(IExprBin *i) override {
        visitExpr(i);
        if (i->getLhs()) {
            i->getLhs()->accept(this);
        }
        if (i->getRhs()) {
            i->getRhs()->accept(this);
        }
    }
    
    virtual void visitExprBitSlice(IExprBitSlice *i) override {
        visitExpr(i);
        if (i->getLhs()) {
            i->getLhs()->accept(this);
        }
        if (i->getRhs()) {
            i->getRhs()->accept(this);
        }
    }
    
    virtual void visitExprBool(IExprBool *i) override {
        visitExpr(i);
    }
    
    virtual void visitExprCast(IExprCast *i) override {
        visitExpr(i);
        if (i->getCasting_type()) {
            i->getCasting_type()->accept(this);
        }
        if (i->getExpr()) {
            i->getExpr()->accept(this);
        }
    }
    
    virtual void visitExprCompileHas(IExprCompileHas *i) override {
        visitExpr(i);
        if (i->getRef()) {
            i->getRef()->accept(this);
        }
    }
    
    virtual void visitExprCond(IExprCond *i) override {
        visitExpr(i);
        if (i->getCond_e()) {
            i->getCond_e()->accept(this);
        }
        if (i->getTrue_e()) {
            i->getTrue_e()->accept(this);
        }
        if (i->getFalse_e()) {
            i->getFalse_e()->accept(this);
        }
    }
    
    virtual void visitExprDomainOpenRangeList(IExprDomainOpenRangeList *i) override {
        visitExpr(i);
        for (std::vector<IExprDomainOpenRangeValueUP>::const_iterator
                it=i->getValues().begin();
                it!=i->getValues().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitExprDomainOpenRangeValue(IExprDomainOpenRangeValue *i) override {
        visitExpr(i);
        if (i->getLhs()) {
            i->getLhs()->accept(this);
        }
        if (i->getRhs()) {
            i->getRhs()->accept(this);
        }
    }
    
    virtual void visitExprHierarchicalId(IExprHierarchicalId *i) override {
        visitExpr(i);
        for (std::vector<IExprMemberPathElemUP>::const_iterator
                it=i->getElems().begin();
                it!=i->getElems().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitExprId(IExprId *i) override {
        visitExpr(i);
    }
    
    virtual void visitExprIn(IExprIn *i) override {
        visitExpr(i);
        if (i->getLhs()) {
            i->getLhs()->accept(this);
        }
        if (i->getRhs()) {
            i->getRhs()->accept(this);
        }
    }
    
    virtual void visitExprListLiteral(IExprListLiteral *i) override {
        visitExpr(i);
        for (std::vector<IExprUP>::const_iterator
                it=i->getValue().begin();
                it!=i->getValue().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitExprMemberPathElem(IExprMemberPathElem *i) override {
        visitExpr(i);
        if (i->getId()) {
            i->getId()->accept(this);
        }
        if (i->getParams()) {
            i->getParams()->accept(this);
        }
        for (std::vector<IExprUP>::const_iterator
                it=i->getSubscript().begin();
                it!=i->getSubscript().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitExprNull(IExprNull *i) override {
        visitExpr(i);
    }
    
    virtual void visitExprNumber(IExprNumber *i) override {
        visitExpr(i);
    }
    
    virtual void visitExprOpenRangeList(IExprOpenRangeList *i) override {
        visitExpr(i);
        for (std::vector<IExprOpenRangeValueUP>::const_iterator
                it=i->getValues().begin();
                it!=i->getValues().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitExprOpenRangeValue(IExprOpenRangeValue *i) override {
        visitExpr(i);
        if (i->getLhs()) {
            i->getLhs()->accept(this);
        }
        if (i->getRhs()) {
            i->getRhs()->accept(this);
        }
    }
    
    virtual void visitExprRefPath(IExprRefPath *i) override {
        visitExpr(i);
        if (i->getTarget()) {
            i->getTarget()->accept(this);
        }
    }
    
    virtual void visitExprRefPathElem(IExprRefPathElem *i) override {
        visitExpr(i);
    }
    
    virtual void visitExprStaticRefPath(IExprStaticRefPath *i) override {
        visitExpr(i);
        for (std::vector<ITypeIdentifierElemUP>::const_iterator
                it=i->getBase().begin();
                it!=i->getBase().end(); it++) {
            (*it)->accept(this);
        }
        if (i->getLeaf()) {
            i->getLeaf()->accept(this);
        }
    }
    
    virtual void visitExprString(IExprString *i) override {
        visitExpr(i);
    }
    
    virtual void visitExprStructLiteral(IExprStructLiteral *i) override {
        visitExpr(i);
        for (std::vector<IExprStructLiteralItemUP>::const_iterator
                it=i->getValues().begin();
                it!=i->getValues().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitExprStructLiteralItem(IExprStructLiteralItem *i) override {
        visitExpr(i);
        if (i->getId()) {
            i->getId()->accept(this);
        }
        if (i->getValue()) {
            i->getValue()->accept(this);
        }
    }
    
    virtual void visitExprSubscript(IExprSubscript *i) override {
        visitExpr(i);
        if (i->getExpr()) {
            i->getExpr()->accept(this);
        }
        if (i->getSubscript()) {
            i->getSubscript()->accept(this);
        }
    }
    
    virtual void visitExprSubstring(IExprSubstring *i) override {
        visitExpr(i);
        if (i->getExpr()) {
            i->getExpr()->accept(this);
        }
        if (i->getStart()) {
            i->getStart()->accept(this);
        }
        if (i->getEnd()) {
            i->getEnd()->accept(this);
        }
    }
    
    virtual void visitExprUnary(IExprUnary *i) override {
        visitExpr(i);
        if (i->getRhs()) {
            i->getRhs()->accept(this);
        }
    }
    
    virtual void visitExtendEnum(IExtendEnum *i) override {
        visitScopeChild(i);
        if (i->getTarget()) {
            i->getTarget()->accept(this);
        }
        for (std::vector<IEnumItemUP>::const_iterator
                it=i->getItems().begin();
                it!=i->getItems().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitFunctionDefinition(IFunctionDefinition *i) override {
        visitScopeChild(i);
        if (i->getProto()) {
            i->getProto()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitFunctionImport(IFunctionImport *i) override {
        visitScopeChild(i);
    }
    
    virtual void visitFunctionParamDecl(IFunctionParamDecl *i) override {
        visitScopeChild(i);
        if (i->getName()) {
            i->getName()->accept(this);
        }
        if (i->getType()) {
            i->getType()->accept(this);
        }
        if (i->getDflt()) {
            i->getDflt()->accept(this);
        }
    }
    
    virtual void visitGenericConstraintDeclValue(IGenericConstraintDeclValue *i) override {
        visitScopeChild(i);
        if (i->getReturn_type()) {
            i->getReturn_type()->accept(this);
        }
        if (i->getName()) {
            i->getName()->accept(this);
        }
        for (std::vector<IGenericConstraintParamUP>::const_iterator
                it=i->getParameters().begin();
                it!=i->getParameters().end(); it++) {
            (*it)->accept(this);
        }
        if (i->getExpr()) {
            i->getExpr()->accept(this);
        }
    }
    
    virtual void visitGenericConstraintParam(IGenericConstraintParam *i) override {
        visitScopeChild(i);
        if (i->getName()) {
            i->getName()->accept(this);
        }
        if (i->getType()) {
            i->getType()->accept(this);
        }
    }
    
    virtual void visitMethodParameterList(IMethodParameterList *i) override {
        visitExpr(i);
        for (std::vector<IExprUP>::const_iterator
                it=i->getParameters().begin();
                it!=i->getParameters().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitMonitorActivityActionTraversal(IMonitorActivityActionTraversal *i) override {
        visitMonitorActivityStmt(i);
        if (i->getTarget()) {
            i->getTarget()->accept(this);
        }
        if (i->getWith_c()) {
            i->getWith_c()->accept(this);
        }
    }
    
    virtual void visitMonitorActivityConcat(IMonitorActivityConcat *i) override {
        visitMonitorActivityStmt(i);
        if (i->getLhs()) {
            i->getLhs()->accept(this);
        }
        if (i->getRhs()) {
            i->getRhs()->accept(this);
        }
    }
    
    virtual void visitActionHandleField(IActionHandleField *i) override {
        visitNamedScopeChild(i);
        if (i->getType()) {
            i->getType()->accept(this);
        }
        for (std::vector<IActionFieldInitializerUP>::const_iterator
                it=i->getInitializers().begin();
                it!=i->getInitializers().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitMonitorActivityEventually(IMonitorActivityEventually *i) override {
        visitMonitorActivityStmt(i);
        if (i->getCondition()) {
            i->getCondition()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitMonitorActivityIfElse(IMonitorActivityIfElse *i) override {
        visitMonitorActivityStmt(i);
        if (i->getCond()) {
            i->getCond()->accept(this);
        }
        if (i->getTrue_s()) {
            i->getTrue_s()->accept(this);
        }
        if (i->getFalse_s()) {
            i->getFalse_s()->accept(this);
        }
    }
    
    virtual void visitMonitorActivityMatch(IMonitorActivityMatch *i) override {
        visitMonitorActivityStmt(i);
        if (i->getCond()) {
            i->getCond()->accept(this);
        }
        for (std::vector<IMonitorActivityMatchChoiceUP>::const_iterator
                it=i->getChoices().begin();
                it!=i->getChoices().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitActivityBindStmt(IActivityBindStmt *i) override {
        visitActivityStmt(i);
        if (i->getLhs()) {
            i->getLhs()->accept(this);
        }
        for (std::vector<IExprHierarchicalIdUP>::const_iterator
                it=i->getRhs().begin();
                it!=i->getRhs().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitActivityConstraint(IActivityConstraint *i) override {
        visitActivityStmt(i);
        if (i->getConstraint()) {
            i->getConstraint()->accept(this);
        }
    }
    
    virtual void visitMonitorActivityMonitorTraversal(IMonitorActivityMonitorTraversal *i) override {
        visitMonitorActivityStmt(i);
        if (i->getTarget()) {
            i->getTarget()->accept(this);
        }
        if (i->getWith_c()) {
            i->getWith_c()->accept(this);
        }
    }
    
    virtual void visitMonitorActivityOverlap(IMonitorActivityOverlap *i) override {
        visitMonitorActivityStmt(i);
        if (i->getLhs()) {
            i->getLhs()->accept(this);
        }
        if (i->getRhs()) {
            i->getRhs()->accept(this);
        }
    }
    
    virtual void visitMonitorActivityRepeatCount(IMonitorActivityRepeatCount *i) override {
        visitMonitorActivityStmt(i);
        if (i->getLoop_var()) {
            i->getLoop_var()->accept(this);
        }
        if (i->getCount()) {
            i->getCount()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitMonitorActivityRepeatWhile(IMonitorActivityRepeatWhile *i) override {
        visitMonitorActivityStmt(i);
        if (i->getCond()) {
            i->getCond()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitActivityJoinSpecBranch(IActivityJoinSpecBranch *i) override {
        visitActivityJoinSpec(i);
        for (std::vector<IExprRefPathContextUP>::const_iterator
                it=i->getBranches().begin();
                it!=i->getBranches().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitActivityJoinSpecFirst(IActivityJoinSpecFirst *i) override {
        visitActivityJoinSpec(i);
        if (i->getCount()) {
            i->getCount()->accept(this);
        }
    }
    
    virtual void visitActivityJoinSpecNone(IActivityJoinSpecNone *i) override {
        visitActivityJoinSpec(i);
    }
    
    virtual void visitActivityJoinSpecSelect(IActivityJoinSpecSelect *i) override {
        visitActivityJoinSpec(i);
        if (i->getCount()) {
            i->getCount()->accept(this);
        }
    }
    
    virtual void visitMonitorActivitySelect(IMonitorActivitySelect *i) override {
        visitMonitorActivityStmt(i);
        if (i->getLabel()) {
            i->getLabel()->accept(this);
        }
        for (std::vector<IMonitorActivitySelectBranchUP>::const_iterator
                it=i->getBranches().begin();
                it!=i->getBranches().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitActivityLabeledStmt(IActivityLabeledStmt *i) override {
        visitActivityStmt(i);
        if (i->getLabel()) {
            i->getLabel()->accept(this);
        }
    }
    
    virtual void visitMonitorConstraint(IMonitorConstraint *i) override {
        visitMonitorActivityStmt(i);
        if (i->getConstraint()) {
            i->getConstraint()->accept(this);
        }
    }
    
    virtual void visitNamedScope(INamedScope *i) override {
        visitScope(i);
        if (i->getName()) {
            i->getName()->accept(this);
        }
    }
    
    virtual void visitPackageScope(IPackageScope *i) override {
        visitScope(i);
        for (std::vector<IExprIdUP>::const_iterator
                it=i->getId().begin();
                it!=i->getId().end(); it++) {
            (*it)->accept(this);
        }
        if (i->getSibling()) {
            i->getSibling()->accept(this);
        }
    }
    
    virtual void visitProceduralStmtAssignment(IProceduralStmtAssignment *i) override {
        visitExecStmt(i);
        if (i->getLhs()) {
            i->getLhs()->accept(this);
        }
        if (i->getRhs()) {
            i->getRhs()->accept(this);
        }
    }
    
    virtual void visitProceduralStmtBody(IProceduralStmtBody *i) override {
        visitExecStmt(i);
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitProceduralStmtBreak(IProceduralStmtBreak *i) override {
        visitExecStmt(i);
    }
    
    virtual void visitProceduralStmtContinue(IProceduralStmtContinue *i) override {
        visitExecStmt(i);
    }
    
    virtual void visitProceduralStmtDataDeclaration(IProceduralStmtDataDeclaration *i) override {
        visitExecStmt(i);
        if (i->getName()) {
            i->getName()->accept(this);
        }
        if (i->getDatatype()) {
            i->getDatatype()->accept(this);
        }
        if (i->getInit()) {
            i->getInit()->accept(this);
        }
    }
    
    virtual void visitProceduralStmtExpr(IProceduralStmtExpr *i) override {
        visitExecStmt(i);
        if (i->getExpr()) {
            i->getExpr()->accept(this);
        }
    }
    
    virtual void visitProceduralStmtFunctionCall(IProceduralStmtFunctionCall *i) override {
        visitExecStmt(i);
        if (i->getPrefix()) {
            i->getPrefix()->accept(this);
        }
        for (std::vector<IExprUP>::const_iterator
                it=i->getParams().begin();
                it!=i->getParams().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitProceduralStmtIfElse(IProceduralStmtIfElse *i) override {
        visitExecStmt(i);
        for (std::vector<IProceduralStmtIfClauseUP>::const_iterator
                it=i->getIf_then().begin();
                it!=i->getIf_then().end(); it++) {
            (*it)->accept(this);
        }
        if (i->getElse_then()) {
            i->getElse_then()->accept(this);
        }
    }
    
    virtual void visitProceduralStmtMatch(IProceduralStmtMatch *i) override {
        visitExecStmt(i);
        if (i->getExpr()) {
            i->getExpr()->accept(this);
        }
        for (std::vector<IProceduralStmtMatchChoiceUP>::const_iterator
                it=i->getChoices().begin();
                it!=i->getChoices().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitProceduralStmtMatchChoice(IProceduralStmtMatchChoice *i) override {
        visitExecStmt(i);
        if (i->getCond()) {
            i->getCond()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitProceduralStmtRandomize(IProceduralStmtRandomize *i) override {
        visitExecStmt(i);
        if (i->getTarget()) {
            i->getTarget()->accept(this);
        }
        for (std::vector<IConstraintStmtUP>::const_iterator
                it=i->getConstraints().begin();
                it!=i->getConstraints().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitProceduralStmtReturn(IProceduralStmtReturn *i) override {
        visitExecStmt(i);
        if (i->getExpr()) {
            i->getExpr()->accept(this);
        }
    }
    
    virtual void visitConstraintScope(IConstraintScope *i) override {
        visitConstraintStmt(i);
        for (std::vector<IConstraintStmtUP>::const_iterator
                it=i->getConstraints().begin();
                it!=i->getConstraints().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitConstraintStmtDefault(IConstraintStmtDefault *i) override {
        visitConstraintStmt(i);
        if (i->getHid()) {
            i->getHid()->accept(this);
        }
        if (i->getExpr()) {
            i->getExpr()->accept(this);
        }
    }
    
    virtual void visitConstraintStmtDefaultDisable(IConstraintStmtDefaultDisable *i) override {
        visitConstraintStmt(i);
        if (i->getHid()) {
            i->getHid()->accept(this);
        }
    }
    
    virtual void visitConstraintStmtExpr(IConstraintStmtExpr *i) override {
        visitConstraintStmt(i);
        if (i->getExpr()) {
            i->getExpr()->accept(this);
        }
    }
    
    virtual void visitConstraintStmtField(IConstraintStmtField *i) override {
        visitConstraintStmt(i);
        if (i->getName()) {
            i->getName()->accept(this);
        }
        if (i->getType()) {
            i->getType()->accept(this);
        }
    }
    
    virtual void visitProceduralStmtYield(IProceduralStmtYield *i) override {
        visitExecStmt(i);
    }
    
    virtual void visitConstraintStmtIf(IConstraintStmtIf *i) override {
        visitConstraintStmt(i);
        if (i->getCond()) {
            i->getCond()->accept(this);
        }
        if (i->getTrue_c()) {
            i->getTrue_c()->accept(this);
        }
        if (i->getFalse_c()) {
            i->getFalse_c()->accept(this);
        }
    }
    
    virtual void visitConstraintStmtUnique(IConstraintStmtUnique *i) override {
        visitConstraintStmt(i);
        for (std::vector<IExprHierarchicalIdUP>::const_iterator
                it=i->getList().begin();
                it!=i->getList().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitSymbolChildrenScope(ISymbolChildrenScope *i) override {
        visitSymbolChild(i);
        for (std::vector<IScopeChildUP>::const_iterator
                it=i->getChildren().begin();
                it!=i->getChildren().end(); it++) {
            (*it)->accept(this);
        }
        if (i->getTarget()) {
            i->getTarget()->accept(this);
        }
    }
    
    virtual void visitDataTypeBool(IDataTypeBool *i) override {
        visitDataType(i);
    }
    
    virtual void visitDataTypeChandle(IDataTypeChandle *i) override {
        visitDataType(i);
    }
    
    virtual void visitDataTypeEnum(IDataTypeEnum *i) override {
        visitDataType(i);
        if (i->getTid()) {
            i->getTid()->accept(this);
        }
        if (i->getIn_rangelist()) {
            i->getIn_rangelist()->accept(this);
        }
    }
    
    virtual void visitDataTypeInt(IDataTypeInt *i) override {
        visitDataType(i);
        if (i->getWidth()) {
            i->getWidth()->accept(this);
        }
        if (i->getIn_range()) {
            i->getIn_range()->accept(this);
        }
    }
    
    virtual void visitDataTypePyObj(IDataTypePyObj *i) override {
        visitDataType(i);
    }
    
    virtual void visitDataTypeRef(IDataTypeRef *i) override {
        visitDataType(i);
        if (i->getType()) {
            i->getType()->accept(this);
        }
    }
    
    virtual void visitDataTypeString(IDataTypeString *i) override {
        visitDataType(i);
    }
    
    virtual void visitDataTypeUserDefined(IDataTypeUserDefined *i) override {
        visitDataType(i);
        if (i->getType_id()) {
            i->getType_id()->accept(this);
        }
    }
    
    virtual void visitEnumDecl(IEnumDecl *i) override {
        visitNamedScopeChild(i);
        for (std::vector<IEnumItemUP>::const_iterator
                it=i->getItems().begin();
                it!=i->getItems().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitEnumItem(IEnumItem *i) override {
        visitNamedScopeChild(i);
        if (i->getValue()) {
            i->getValue()->accept(this);
        }
    }
    
    virtual void visitTemplateCategoryTypeParamDecl(ITemplateCategoryTypeParamDecl *i) override {
        visitTemplateParamDecl(i);
        if (i->getRestriction()) {
            i->getRestriction()->accept(this);
        }
        if (i->getDflt()) {
            i->getDflt()->accept(this);
        }
    }
    
    virtual void visitTemplateGenericTypeParamDecl(ITemplateGenericTypeParamDecl *i) override {
        visitTemplateParamDecl(i);
        if (i->getDflt()) {
            i->getDflt()->accept(this);
        }
    }
    
    virtual void visitExprAggrEmpty(IExprAggrEmpty *i) override {
        visitExprAggrLiteral(i);
    }
    
    virtual void visitExprAggrList(IExprAggrList *i) override {
        visitExprAggrLiteral(i);
        for (std::vector<IExprUP>::const_iterator
                it=i->getElems().begin();
                it!=i->getElems().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitTemplateValueParamDecl(ITemplateValueParamDecl *i) override {
        visitTemplateParamDecl(i);
        if (i->getType()) {
            i->getType()->accept(this);
        }
        if (i->getDflt()) {
            i->getDflt()->accept(this);
        }
    }
    
    virtual void visitExprAggrMap(IExprAggrMap *i) override {
        visitExprAggrLiteral(i);
        for (std::vector<IExprAggrMapElemUP>::const_iterator
                it=i->getElems().begin();
                it!=i->getElems().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitExprAggrStruct(IExprAggrStruct *i) override {
        visitExprAggrLiteral(i);
        for (std::vector<IExprAggrStructElemUP>::const_iterator
                it=i->getElems().begin();
                it!=i->getElems().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitExprRefPathContext(IExprRefPathContext *i) override {
        visitExprRefPath(i);
        if (i->getHier_id()) {
            i->getHier_id()->accept(this);
        }
        if (i->getSlice()) {
            i->getSlice()->accept(this);
        }
    }
    
    virtual void visitExprRefPathId(IExprRefPathId *i) override {
        visitExprRefPath(i);
        if (i->getId()) {
            i->getId()->accept(this);
        }
        if (i->getSlice()) {
            i->getSlice()->accept(this);
        }
    }
    
    virtual void visitExprRefPathStatic(IExprRefPathStatic *i) override {
        visitExprRefPath(i);
        for (std::vector<ITypeIdentifierElemUP>::const_iterator
                it=i->getBase().begin();
                it!=i->getBase().end(); it++) {
            (*it)->accept(this);
        }
        if (i->getSlice()) {
            i->getSlice()->accept(this);
        }
    }
    
    virtual void visitExprRefPathStaticRooted(IExprRefPathStaticRooted *i) override {
        visitExprRefPath(i);
        if (i->getRoot()) {
            i->getRoot()->accept(this);
        }
        if (i->getLeaf()) {
            i->getLeaf()->accept(this);
        }
        if (i->getSlice()) {
            i->getSlice()->accept(this);
        }
    }
    
    virtual void visitExprSignedNumber(IExprSignedNumber *i) override {
        visitExprNumber(i);
    }
    
    virtual void visitExprUnsignedNumber(IExprUnsignedNumber *i) override {
        visitExprNumber(i);
    }
    
    virtual void visitExtendType(IExtendType *i) override {
        visitScope(i);
        if (i->getTarget()) {
            i->getTarget()->accept(this);
        }
        if (i->getImports()) {
            i->getImports()->accept(this);
        }
    }
    
    virtual void visitField(IField *i) override {
        visitNamedScopeChild(i);
        if (i->getType()) {
            i->getType()->accept(this);
        }
        if (i->getInit()) {
            i->getInit()->accept(this);
        }
    }
    
    virtual void visitFieldClaim(IFieldClaim *i) override {
        visitNamedScopeChild(i);
        if (i->getType()) {
            i->getType()->accept(this);
        }
    }
    
    virtual void visitFieldCompRef(IFieldCompRef *i) override {
        visitNamedScopeChild(i);
        if (i->getType()) {
            i->getType()->accept(this);
        }
    }
    
    virtual void visitFieldRef(IFieldRef *i) override {
        visitNamedScopeChild(i);
        if (i->getType()) {
            i->getType()->accept(this);
        }
    }
    
    virtual void visitFunctionImportProto(IFunctionImportProto *i) override {
        visitFunctionImport(i);
        if (i->getProto()) {
            i->getProto()->accept(this);
        }
    }
    
    virtual void visitFunctionImportType(IFunctionImportType *i) override {
        visitFunctionImport(i);
        if (i->getType()) {
            i->getType()->accept(this);
        }
    }
    
    virtual void visitFunctionPrototype(IFunctionPrototype *i) override {
        visitNamedScopeChild(i);
        if (i->getRtype()) {
            i->getRtype()->accept(this);
        }
        for (std::vector<IFunctionParamDeclUP>::const_iterator
                it=i->getParameters().begin();
                it!=i->getParameters().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitGlobalScope(IGlobalScope *i) override {
        visitScope(i);
    }
    
    virtual void visitActivityActionHandleTraversal(IActivityActionHandleTraversal *i) override {
        visitActivityLabeledStmt(i);
        if (i->getTarget()) {
            i->getTarget()->accept(this);
        }
        if (i->getWith_c()) {
            i->getWith_c()->accept(this);
        }
        for (std::vector<IActionFieldInitializerUP>::const_iterator
                it=i->getInitializers().begin();
                it!=i->getInitializers().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitActivityActionTypeTraversal(IActivityActionTypeTraversal *i) override {
        visitActivityLabeledStmt(i);
        if (i->getTarget()) {
            i->getTarget()->accept(this);
        }
        if (i->getWith_c()) {
            i->getWith_c()->accept(this);
        }
        for (std::vector<IActionFieldInitializerUP>::const_iterator
                it=i->getInitializers().begin();
                it!=i->getInitializers().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitActivityAtomicBlock(IActivityAtomicBlock *i) override {
        visitActivityLabeledStmt(i);
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitActivityForeach(IActivityForeach *i) override {
        visitActivityLabeledStmt(i);
        if (i->getIt_id()) {
            i->getIt_id()->accept(this);
        }
        if (i->getIdx_id()) {
            i->getIdx_id()->accept(this);
        }
        if (i->getTarget()) {
            i->getTarget()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitActivityIfElse(IActivityIfElse *i) override {
        visitActivityLabeledStmt(i);
        if (i->getCond()) {
            i->getCond()->accept(this);
        }
        if (i->getTrue_s()) {
            i->getTrue_s()->accept(this);
        }
        if (i->getFalse_s()) {
            i->getFalse_s()->accept(this);
        }
    }
    
    virtual void visitActivityMatch(IActivityMatch *i) override {
        visitActivityLabeledStmt(i);
        if (i->getCond()) {
            i->getCond()->accept(this);
        }
        for (std::vector<IActivityMatchChoiceUP>::const_iterator
                it=i->getChoices().begin();
                it!=i->getChoices().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitActivityRepeatCount(IActivityRepeatCount *i) override {
        visitActivityLabeledStmt(i);
        if (i->getLoop_var()) {
            i->getLoop_var()->accept(this);
        }
        if (i->getCount()) {
            i->getCount()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitActivityRepeatWhile(IActivityRepeatWhile *i) override {
        visitActivityLabeledStmt(i);
        if (i->getCond()) {
            i->getCond()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitActivityReplicate(IActivityReplicate *i) override {
        visitActivityLabeledStmt(i);
        if (i->getIdx_id()) {
            i->getIdx_id()->accept(this);
        }
        if (i->getIt_label()) {
            i->getIt_label()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitActivitySelect(IActivitySelect *i) override {
        visitActivityLabeledStmt(i);
        for (std::vector<IActivitySelectBranchUP>::const_iterator
                it=i->getBranches().begin();
                it!=i->getBranches().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitActivitySuper(IActivitySuper *i) override {
        visitActivityLabeledStmt(i);
    }
    
    virtual void visitProceduralStmtRepeatWhile(IProceduralStmtRepeatWhile *i) override {
        visitProceduralStmtBody(i);
        if (i->getExpr()) {
            i->getExpr()->accept(this);
        }
    }
    
    virtual void visitConstraintBlock(IConstraintBlock *i) override {
        visitConstraintScope(i);
    }
    
    virtual void visitProceduralStmtWhile(IProceduralStmtWhile *i) override {
        visitProceduralStmtBody(i);
        if (i->getExpr()) {
            i->getExpr()->accept(this);
        }
    }
    
    virtual void visitConstraintStmtForall(IConstraintStmtForall *i) override {
        visitConstraintScope(i);
        if (i->getIterator_id()) {
            i->getIterator_id()->accept(this);
        }
        if (i->getType_id()) {
            i->getType_id()->accept(this);
        }
        if (i->getRef_path()) {
            i->getRef_path()->accept(this);
        }
        if (i->getSymtab()) {
            i->getSymtab()->accept(this);
        }
    }
    
    virtual void visitConstraintStmtForeach(IConstraintStmtForeach *i) override {
        visitConstraintScope(i);
        if (i->getIt()) {
            i->getIt()->accept(this);
        }
        if (i->getIdx()) {
            i->getIdx()->accept(this);
        }
        if (i->getExpr()) {
            i->getExpr()->accept(this);
        }
    }
    
    virtual void visitConstraintStmtImplication(IConstraintStmtImplication *i) override {
        visitConstraintScope(i);
        if (i->getCond()) {
            i->getCond()->accept(this);
        }
    }
    
    virtual void visitSymbolScope(ISymbolScope *i) override {
        visitSymbolChildrenScope(i);
        if (i->getImports()) {
            i->getImports()->accept(this);
        }
    }
    
    virtual void visitTypeScope(ITypeScope *i) override {
        visitNamedScope(i);
        if (i->getSuper_t()) {
            i->getSuper_t()->accept(this);
        }
        if (i->getParams()) {
            i->getParams()->accept(this);
        }
    }
    
    virtual void visitExprRefPathStaticFunc(IExprRefPathStaticFunc *i) override {
        visitExprRefPathStatic(i);
        if (i->getParams()) {
            i->getParams()->accept(this);
        }
    }
    
    virtual void visitExprRefPathSuper(IExprRefPathSuper *i) override {
        visitExprRefPathContext(i);
    }
    
    virtual void visitAction(IAction *i) override {
        visitTypeScope(i);
    }
    
    virtual void visitMonitorActivityDecl(IMonitorActivityDecl *i) override {
        visitSymbolScope(i);
    }
    
    virtual void visitActivityDecl(IActivityDecl *i) override {
        visitSymbolScope(i);
    }
    
    virtual void visitMonitorActivitySchedule(IMonitorActivitySchedule *i) override {
        visitSymbolScope(i);
        if (i->getLabel()) {
            i->getLabel()->accept(this);
        }
    }
    
    virtual void visitMonitorActivitySequence(IMonitorActivitySequence *i) override {
        visitSymbolScope(i);
        if (i->getLabel()) {
            i->getLabel()->accept(this);
        }
    }
    
    virtual void visitActivityLabeledScope(IActivityLabeledScope *i) override {
        visitSymbolScope(i);
        if (i->getLabel()) {
            i->getLabel()->accept(this);
        }
    }
    
    virtual void visitAnnotationDecl(IAnnotationDecl *i) override {
        visitTypeScope(i);
    }
    
    virtual void visitComponent(IComponent *i) override {
        visitTypeScope(i);
    }
    
    virtual void visitProceduralStmtSymbolBodyScope(IProceduralStmtSymbolBodyScope *i) override {
        visitSymbolScope(i);
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitRootSymbolScope(IRootSymbolScope *i) override {
        visitSymbolScope(i);
        for (std::vector<IGlobalScopeUP>::const_iterator
                it=i->getUnits().begin();
                it!=i->getUnits().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitConstraintSymbolScope(IConstraintSymbolScope *i) override {
        visitSymbolScope(i);
        if (i->getConstraint()) {
            i->getConstraint()->accept(this);
        }
    }
    
    virtual void visitStruct(IStruct *i) override {
        visitTypeScope(i);
    }
    
    virtual void visitSymbolEnumScope(ISymbolEnumScope *i) override {
        visitSymbolScope(i);
    }
    
    virtual void visitSymbolExtendScope(ISymbolExtendScope *i) override {
        visitSymbolScope(i);
    }
    
    virtual void visitSymbolFunctionScope(ISymbolFunctionScope *i) override {
        visitSymbolScope(i);
        for (std::vector<IFunctionPrototype *>::const_iterator
                it=i->getPrototypes().begin();
                it!=i->getPrototypes().end(); it++) {
            (*it)->accept(this);
        }
        for (std::vector<IFunctionImportUP>::const_iterator
                it=i->getImport_specs().begin();
                it!=i->getImport_specs().end(); it++) {
            (*it)->accept(this);
        }
        if (i->getDefinition()) {
            i->getDefinition()->accept(this);
        }
        if (i->getPlist()) {
            i->getPlist()->accept(this);
        }
        if (i->getBody()) {
            i->getBody()->accept(this);
        }
    }
    
    virtual void visitSymbolTypeScope(ISymbolTypeScope *i) override {
        visitSymbolScope(i);
        if (i->getPlist()) {
            i->getPlist()->accept(this);
        }
        for (std::vector<ISymbolTypeScopeUP>::const_iterator
                it=i->getSpec_types().begin();
                it!=i->getSpec_types().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitExecScope(IExecScope *i) override {
        visitSymbolScope(i);
    }
    
    virtual void visitGenericConstraintDeclBool(IGenericConstraintDeclBool *i) override {
        visitConstraintBlock(i);
        for (std::vector<IGenericConstraintParamUP>::const_iterator
                it=i->getParameters().begin();
                it!=i->getParameters().end(); it++) {
            (*it)->accept(this);
        }
    }
    
    virtual void visitMonitor(IMonitor *i) override {
        visitTypeScope(i);
    }
    
    virtual void visitProceduralStmtRepeat(IProceduralStmtRepeat *i) override {
        visitProceduralStmtSymbolBodyScope(i);
        if (i->getIt_id()) {
            i->getIt_id()->accept(this);
        }
        if (i->getCount()) {
            i->getCount()->accept(this);
        }
    }
    
    virtual void visitActivityParallel(IActivityParallel *i) override {
        visitActivityLabeledScope(i);
        if (i->getJoin_spec()) {
            i->getJoin_spec()->accept(this);
        }
    }
    
    virtual void visitActivitySchedule(IActivitySchedule *i) override {
        visitActivityLabeledScope(i);
        if (i->getJoin_spec()) {
            i->getJoin_spec()->accept(this);
        }
    }
    
    virtual void visitProceduralStmtForeach(IProceduralStmtForeach *i) override {
        visitProceduralStmtSymbolBodyScope(i);
        if (i->getPath()) {
            i->getPath()->accept(this);
        }
        if (i->getIt_id()) {
            i->getIt_id()->accept(this);
        }
        if (i->getIdx_id()) {
            i->getIdx_id()->accept(this);
        }
    }
    
    virtual void visitActivitySequence(IActivitySequence *i) override {
        visitActivityLabeledScope(i);
    }
    
    virtual void visitExecBlock(IExecBlock *i) override {
        visitExecScope(i);
    }
    
    
    protected:
        IVisitor *m_this;
};


} // namespace pssp
} // namespace ast

