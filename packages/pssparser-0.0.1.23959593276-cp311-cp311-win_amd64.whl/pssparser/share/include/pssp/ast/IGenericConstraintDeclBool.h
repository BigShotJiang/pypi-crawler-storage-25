/****************************************************************************
 * IGenericConstraintDeclBool.h
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 ****************************************************************************/
#pragma once
#include <stdint.h>
#include <unordered_map>
#include <memory>
#include <set>
#include <string>
#include <vector>
#include "pssp/ast/impl/UP.h"
#include "pssp/ast/IVisitor.h"
#include "pssp/ast/IConstraintBlock.h"

namespace pssp {
namespace ast {

class IConstraintBlock;
using IConstraintBlockUP=UP<IConstraintBlock>;
typedef std::shared_ptr<IConstraintBlock> IConstraintBlockSP;
class IGenericConstraintParam;
using IGenericConstraintParamUP=UP<IGenericConstraintParam>;
typedef std::shared_ptr<IGenericConstraintParam> IGenericConstraintParamSP;
class IGenericConstraintDeclBool;
using IGenericConstraintDeclBoolUP=UP<IGenericConstraintDeclBool>;
class IGenericConstraintDeclBool : public virtual IConstraintBlock {
public:
    
    virtual ~IGenericConstraintDeclBool() { }
    
    
    virtual bool getIs_static() const = 0;
    
    virtual void setIs_static(bool v) = 0;
    
    virtual const std::vector<IGenericConstraintParamUP> &getParameters() const = 0;
    
    virtual std::vector<IGenericConstraintParamUP> &getParameters() = 0;
};
    
    } // namespace pssp
    } // namespace ast
    
