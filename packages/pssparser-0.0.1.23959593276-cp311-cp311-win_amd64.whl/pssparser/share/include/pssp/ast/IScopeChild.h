/****************************************************************************
 * IScopeChild.h
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 ****************************************************************************/
#pragma once
#include <stdint.h>
#include <unordered_map>
#include <memory>
#include <set>
#include <string>
#include <vector>
#include "pssp/ast/impl/UP.h"
#include "pssp/ast/IVisitor.h"
#include "pssp/ast/Location.h"
namespace pssp {
namespace ast {

class IScope;
using IScopeUP=UP<IScope>;
typedef std::shared_ptr<IScope> IScopeSP;
class IAssocData;
using IAssocDataUP=UP<IAssocData>;
typedef std::shared_ptr<IAssocData> IAssocDataSP;
class IAnnotation;
using IAnnotationUP=UP<IAnnotation>;
typedef std::shared_ptr<IAnnotation> IAnnotationSP;
class IScopeChild;
using IScopeChildUP=UP<IScopeChild>;
class IScopeChild {
public:
    
    virtual ~IScopeChild() { }
    
    
    virtual const std::string &getDocstring() const = 0;
    
    virtual void setDocstring(const std::string &v) = 0;
    
    virtual const Location &getLocation() const = 0;
    
    virtual void setLocation(const Location &v) = 0;
    
    virtual IScope *getParent() = 0;
    
    virtual void setParent(IScope *v) = 0;
    
    virtual int32_t getIndex() const = 0;
    
    virtual void setIndex(int32_t v) = 0;
    
    virtual IAssocData *getAssocData() const = 0;
    
    virtual void setAssocData(IAssocData *v, bool own=true) = 0;
    
    virtual const std::vector<IAnnotationUP> &getAnnotations() const = 0;
    
    virtual std::vector<IAnnotationUP> &getAnnotations() = 0;
    virtual void accept(IVisitor *v) = 0;
};
    
    } // namespace pssp
    } // namespace ast
    
