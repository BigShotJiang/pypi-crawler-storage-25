/****************************************************************************
 * IMonitorActivitySelect.h
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 ****************************************************************************/
#pragma once
#include <stdint.h>
#include <unordered_map>
#include <memory>
#include <set>
#include <string>
#include <vector>
#include "pssp/ast/impl/UP.h"
#include "pssp/ast/IVisitor.h"
#include "pssp/ast/IMonitorActivityStmt.h"

namespace pssp {
namespace ast {

class IMonitorActivityStmt;
using IMonitorActivityStmtUP=UP<IMonitorActivityStmt>;
typedef std::shared_ptr<IMonitorActivityStmt> IMonitorActivityStmtSP;
class IExprId;
using IExprIdUP=UP<IExprId>;
typedef std::shared_ptr<IExprId> IExprIdSP;
class IMonitorActivitySelectBranch;
using IMonitorActivitySelectBranchUP=UP<IMonitorActivitySelectBranch>;
typedef std::shared_ptr<IMonitorActivitySelectBranch> IMonitorActivitySelectBranchSP;
class IMonitorActivitySelect;
using IMonitorActivitySelectUP=UP<IMonitorActivitySelect>;
class IMonitorActivitySelect : public virtual IMonitorActivityStmt {
public:
    
    virtual ~IMonitorActivitySelect() { }
    
    
    virtual IExprId *getLabel() const = 0;
    
    virtual void setLabel(IExprId *v, bool own=true) = 0;
    
    virtual const std::vector<IMonitorActivitySelectBranchUP> &getBranches() const = 0;
    
    virtual std::vector<IMonitorActivitySelectBranchUP> &getBranches() = 0;
};
    
    } // namespace pssp
    } // namespace ast
    
