/****************************************************************************
 * IProceduralStmtForeach.h
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 ****************************************************************************/
#pragma once
#include <stdint.h>
#include <unordered_map>
#include <memory>
#include <set>
#include <string>
#include <vector>
#include "pssp/ast/impl/UP.h"
#include "pssp/ast/IVisitor.h"
#include "pssp/ast/IProceduralStmtSymbolBodyScope.h"

namespace pssp {
namespace ast {

class IProceduralStmtSymbolBodyScope;
using IProceduralStmtSymbolBodyScopeUP=UP<IProceduralStmtSymbolBodyScope>;
typedef std::shared_ptr<IProceduralStmtSymbolBodyScope> IProceduralStmtSymbolBodyScopeSP;
class IExprRefPath;
using IExprRefPathUP=UP<IExprRefPath>;
typedef std::shared_ptr<IExprRefPath> IExprRefPathSP;
class IExprId;
using IExprIdUP=UP<IExprId>;
typedef std::shared_ptr<IExprId> IExprIdSP;
class IProceduralStmtForeach;
using IProceduralStmtForeachUP=UP<IProceduralStmtForeach>;
class IProceduralStmtForeach : public virtual IProceduralStmtSymbolBodyScope {
public:
    
    virtual ~IProceduralStmtForeach() { }
    
    
    virtual IExprRefPath *getPath() const = 0;
    
    virtual void setPath(IExprRefPath *v, bool own=true) = 0;
    
    virtual IExprId *getIt_id() const = 0;
    
    virtual void setIt_id(IExprId *v, bool own=true) = 0;
    
    virtual IExprId *getIdx_id() const = 0;
    
    virtual void setIdx_id(IExprId *v, bool own=true) = 0;
};
    
    } // namespace pssp
    } // namespace ast
    
