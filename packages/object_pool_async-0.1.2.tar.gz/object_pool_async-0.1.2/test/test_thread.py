"""
By DeepSeek V3.2.

验证线程不安全
"""

import threading
from object_pool import Pool, Status 
from test_pool import DummyObject

pool = Pool(detect_status=lambda w: Status.AVAILABLE)

def worker():
    for _ in range(100):
        obj = DummyObject(1)
        pool.add(obj)          # 同步方法
        pool.remove(obj)

threads = [threading.Thread(target=worker) for _ in range(10)]
for t in threads:
    t.start()
for t in threads:
    t.join()
