"""
By DeepSeek V3.2.

测试 Pool
"""

import asyncio
import time
from datetime import timedelta

from object_pool import Pool, ObjectWrapper, Status


# 模拟一个简单的对象
class DummyObject:
    def __init__(self, _id: int):
        self.id = _id

    def __str__(self) -> str:
        return f"Dummy({self.id})"


# 状态检测函数：将对象标记为 AVAILABLE 或 INVALID
def detect_status(wrapper: ObjectWrapper[DummyObject]) -> Status:
    # 假设对象如果 id 为负数则无效
    if wrapper.object.id < 0:
        return Status.INVALID
    # 如果对象尚未标记，则设为 AVAILABLE
    if wrapper.status == Status.PENDING:
        return Status.AVAILABLE
    return wrapper.status


# 异步版本
async def detect_status_async(wrapper: ObjectWrapper[DummyObject]) -> Status:
    await asyncio.sleep(0.01)  # 模拟异步检测
    return detect_status(wrapper)


def _test() -> None:
    """同步测试 Pool 类（使用同步方法）"""
    print("=== 同步测试开始 ===")

    # 创建对象池
    pool = Pool(
        detect_status=detect_status,
        select_object=lambda seq, **kw: seq[0] if seq else None,  # 总是选第一个
        async_concurrency=2
    )

    # 创建对象
    obj1 = DummyObject(1)
    obj2 = DummyObject(2)
    obj3 = DummyObject(-3)  # 无效对象

    # 添加对象
    pool.add(obj1)
    pool.add(obj2)
    pool.add(obj3)
    print(f"池中对象数量: {len(pool)}")

    # 更新状态（检测 + 清理）
    pool.update_status()
    print(f"obj1 状态: {pool.get_status(obj1)}")  # 应为 AVAILABLE
    print(f"obj2 状态: {pool.get_status(obj2)}")  # 应为 AVAILABLE
    try:
        print(f"obj3 状态: {pool.get_status(obj3)}")  # 应为 INVALID，找不到
    except:
        print(f"obj3 已被清理")

    # 再次更新状态，无效对象应被移除
    pool.update_status()
    print(f"清理后池中对象数量: {len(pool)}")  # 应为 2

    # 借出对象
    pack1 = pool.borrow(timeout=1.0)  # 超时1秒
    if pack1:
        print(f"借出对象: {pack1.object}")
        # 模拟使用
        time.sleep(0.5)
        pack1.close()
        print("归还对象")

    # 借出超时测试
    pack2 = pool.borrow(timeout=0.1)
    if pack2:
        print(f"借出对象（短超时）: {pack2.object}")
        time.sleep(0.2)  # 等待超时
        # 此时应被自动回收
        pool.update_status()  # 触发回收
        # 检查状态是否为 PENDING
        status = pool.get_status(pack2.object)
        print(f"超时后对象状态: {status}")  # 应为 PENDING

    # 上下文管理器测试
    with pool.borrow(timeout=2.0) as obj:
        print(f"上下文管理器借出: {obj}")
        # 自动归还

    print("=== 同步测试完成 ===\n")


async def _test_async() -> None:
    """异步测试 Pool 类（使用异步方法）"""
    print("=== 异步测试开始 ===")

    # 创建对象池（使用异步检测函数）
    pool = Pool(
        detect_status=detect_status_async,
        select_object=lambda seq, **kw: seq[0] if seq else None,
        async_concurrency=2
    )

    obj1 = DummyObject(10)
    obj2 = DummyObject(20)

    # 添加对象（异步）
    await pool.add_async(obj1)
    await pool.add_async(obj2)
    print(f"池中对象数量: {len(pool)}")

    # 更新状态
    await pool.update_status_async()
    print(f"obj1 状态: {await pool.get_status_async(obj1)}")
    print(f"obj2 状态: {await pool.get_status_async(obj2)}")

    # 借出对象（异步）
    pack = await pool.borrow_async(timeout=timedelta(seconds=1))
    if pack:
        print(f"借出对象: {pack.object}")
        await asyncio.sleep(0.5)
        pack.close()
        print("归还对象")

    # 测试超时自动回收（异步）
    pack2 = await pool.borrow_async(timeout=0.2)
    if pack2:
        print(f"借出对象（短超时）: {pack2.object}")
        await asyncio.sleep(0.3)  # 超过超时时间
        await pool.update_status_async()
        status = await pool.get_status_async(pack2.object)
        print(f"超时后对象状态: {status}")

    # 测试异步上下文管理器
    async with await pool.borrow_async(timeout=2.0) as obj:
        print(f"异步上下文管理器借出: {obj}")
        # 自动归还

    # 清理所有对象
    await pool.clear_async()
    print(f"清空后池中对象数量: {len(pool)}")

    print("=== 异步测试完成 ===")


if __name__ == "__main__":
    # 运行同步测试
    _test()

    # 运行异步测试
    asyncio.run(_test_async())
