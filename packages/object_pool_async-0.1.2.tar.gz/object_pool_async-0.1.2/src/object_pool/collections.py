from typing import Any


class AttributeDict(dict):
    """
    A class that can read / set attribute value via both `.` and `[]`.
    """

    def __getattr__(self, key: str) -> Any:
        """
        Get an attribute value by `.`

        Args:
            key (str): The name of the attribute to get.

        Returns:
            Any: The value of the attribute.
        """
        return self[key]

    def __setattr__(self, key: str, value: Any) -> None:
        """
        Set an attribute value by `.`

        Args:
            key (str): The name of the attribute to set.
            value (Any): The value to set the attribute to.
        """
        self[key] = value

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({super().__repr__()})"
