"""
class: Pool
"""

from __future__ import annotations
import asyncio
from collections.abc import Callable, Coroutine
from datetime import datetime, timedelta
import functools
from numbers import Number
import random
from typing import Any, Dict, Generic, List, Optional, Sequence, TypeVar

from .collections import AttributeDict
from .exceptions import ObjectNotFoundError
from .status import Status
from .utils import AsyncRLock, to_async


# 池中对象
Object = TypeVar("Object")


# 包装器
class ObjectWrapper(AttributeDict, Generic[Object]):
    """
    对象包装器，用于储存对象的数据。
    """
    def __init__(self, object: Object, status: Status = Status.PENDING, **kwargs):
        super(AttributeDict, self).__init__(**kwargs)
        self.object: Object = object
        self.status: Status = status

    def __str__(self) -> str:
        return f"{type(self).__name__}<{self.object}: {self.status}>"


# 打包器
class ObjectPack(Generic[Object]):
    """
    对象包裹，当对象被借出时返回。
    """
    def __init__(self, object_wrapper: ObjectWrapper[Object]):
        self._object_wrapper = object_wrapper

    def __str__(self) -> str:
        return f"{type(self).__name__}<{self.object}>"


    @property
    def object(self):
        """
        返回对象。
        """
        return self._object_wrapper.object


    def close(self, **feedback) -> None:
        """
        归还借出的对象。
        """
        self._object_wrapper.status = Status.PENDING
        self._object_wrapper.update(feedback)


    def __enter__(self) -> Object:
        return self.object

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
        self._object_wrapper = None

    async def __aenter__(self) -> Object:
        return self.__enter__()

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        return self.__exit__(exc_type, exc_val, exc_tb)


def _split_chunk(objects: List[Any], chunk_size: Optional[int] = None) -> List[List[Any]]:
    """
    将对象列表按每组 chunk_size 个，分组。
    """
    if not chunk_size or chunk_size < 0:
        return [objects]

    return [
        objects[i : i + chunk_size]
        for i in range(0, len(objects), chunk_size)
    ]


def _choice(seq: Sequence[Any]) -> Optional[Any]:
    """
    默认的随机选择函数。
    """
    if not seq:
        return None
    return random.choice(seq)


def async_locked(method: Callable) -> Callable:
    """装饰器：为异步方法自动加上 RLock"""
    @functools.wraps(method)
    async def wrapper(self, *args, **kwargs):
        async with self._lock_async:
            return await method(self, *args, **kwargs)
    return wrapper


class Pool(Generic[Object]):
    """
    对象池。
    """
    # 对象的ID
    ID = int

    # 对象状态检测器
    StatusDetector = Callable[
        [ObjectWrapper[Object]],
        Status
    ]
    StatusDetectorAsync = Callable[
        [ObjectWrapper[Object]],
        Coroutine[None, None, Status]
    ]

    # 对象选择器
    ObjectSelector = Callable[
        [List[ObjectWrapper[Object]], ...],
        Optional[ObjectWrapper[Object]]
    ]
    ObjectSelectorAsync = Callable[
        [List[ObjectWrapper[Object]], ...],
        Coroutine[None, None, Optional[ObjectWrapper[Object]]]
    ]

    # 包装工厂函数
    Wrapper = Callable[
        [Object],
        ObjectWrapper[Object]
    ]
    WrapperAsync = Callable[
        [Object],
        Coroutine[None, None, ObjectWrapper[Object]]
    ]

    # 打包工厂函数
    Packer = Callable[
        [ObjectWrapper[Object]],
        ObjectPack[Object]
    ]
    PackerAsync = Callable[
        [ObjectWrapper[Object]],
        Coroutine[None, None, ObjectPack[Object]]
    ]

    def __init__(
        self,
        detect_status: StatusDetector | StatusDetectorAsync,
        select_object: ObjectSelector | ObjectSelectorAsync = _choice,
        *,
        wrapper: Wrapper | WrapperAsync = ObjectWrapper,
        packer: Packer | PackerAsync = ObjectPack,
        wrapping_data: Optional[Dict[str, Any]] = None,
        async_concurrency: Optional[int] = None
    ):
        """
        初始化一个 Pool 对象。

        Args:
            detect_status (StatusDetector | StatusDetectorAsync): 检测对象状态的函数，内部会把它变成异步函数。
            select_object (ObjectSelector | ObjectSelectorAsync): 从容器中选择一个对象。默认随机选择。
            wrapper (Callable[[Object], ObjectWrapper]): 包装对象的可调用对象。
            packer (Callable[[ObjectWrapper], ObjectPack]): 打包对象的可调用对象。
            wrapping_data (Dict[str, Any]): 添加对象时，默认的数据。
            async_concurrency (int): 最大异步并发数。若缺省，则全部并发。
        """
        self._object_wrappers       : Dict[self.ID, ObjectWrapper[Object]] = {}
        self._detect_status_async   : self.StatusDetectorAsync             = to_async(detect_status)
        self._select_object_async   : self.ObjectSelectorAsync             = to_async(select_object)
        self._wrapper_async         : self.WrapperAsync                    = to_async(wrapper)
        self._packer_async          : self.PackerAsync                     = to_async(packer)
        self._default_wrapping_data : Dict[str, Any]                       = wrapping_data or {}
        self._async_concurrency     : int                                  = async_concurrency
        self._due_datetime          : Dict[self.ID, datetime]              = {}
        self._lock_async = AsyncRLock()


    def __len__(self) -> int:
        return len(self._object_wrappers)


    def __contains__(self, obj: Object) -> bool:
        _id = id(obj)
        return _id in self._object_wrappers


    def _split_chunk(self, objects: List[Any]) -> List[List[Any]]:
        """
        将对象列表按每组 self._async_concurrency 个，分组。
        """
        return _split_chunk(objects, self._async_concurrency)


    async def _get_wrapper_async(self, obj: Object) -> ObjectWrapper[Object]:
        """
        返回 `obj` 的包装器对象。

        Raises:
            ObjectNotFoundError: 如果 obj 不在池中。
        """
        _id = id(obj)
        if _id not in self._object_wrappers:
            raise ObjectNotFoundError(str(obj))
        return self._object_wrappers[_id]


    @async_locked
    async def add_async(self, obj: Object, **kwargs) -> ObjectWrapper[Object]:
        """
        向池中添加/覆盖一个对象。
        """
        kwargs = self._default_wrapping_data | kwargs
        _id = id(obj)
        self._object_wrappers[_id] = await self._wrapper_async(obj, **kwargs)
        return await self._get_wrapper_async(obj)


    async def _delete_async(self, obj: Object) -> None:
        """
        从池中丢弃一个对象。

        Raises:
            ObjectNotFoundError: 如果 obj 不在池中。
        """
        _id = id(obj)
        if _id not in self._object_wrappers:
            raise ObjectNotFoundError(str(obj))
        self._object_wrappers.pop(_id)
        self._due_datetime.pop(_id, None)


    @async_locked
    async def discard_async(self, obj: Object) -> None:
        """
        从池中丢弃一个对象。

        如果池中没有该对象，不会报错。
        """
        if obj in self:
            await self._delete_async(obj)


    @async_locked
    async def remove_async(self, obj: Object) -> None:
        """
        从池中丢弃一个对象。

        Raises:
            ObjectNotFoundError: 如果 obj 不在池中。
        """
        await self._delete_async(obj)


    @async_locked
    async def clear_async(self) -> None:
        """
        清空对象池。
        """
        self._object_wrappers.clear()
        self._due_datetime.clear()


    async def _get_status_by_id_async(self, _id: ID) -> Status:
        """
        通过 id 查询对象状态。
        """
        if _id not in self._object_wrappers:
            raise ObjectNotFoundError(f"Can't find object with id {_id!r}")
        object_wrapper = self._object_wrappers[_id]
        return object_wrapper.status


    @async_locked
    async def get_status_async(self, obj: Object) -> Status:
        """
        查询对象的状态。
        """
        _id = id(obj)
        return await self._get_status_by_id_async(_id)


    async def _detect_async(self) -> None:
        """
        对池中对象进行检测，更新 status。
        """
        # 排除被借出的对象
        object_wrappers_to_be_detected = [
            object_wrapper
            for object_wrapper in self._object_wrappers.values()
            if object_wrapper.status != Status.BORROWED
        ]

        # 异步并发检测对象
        object_wrapper_chunks = self._split_chunk(object_wrappers_to_be_detected)
        for object_wrappers in object_wrapper_chunks:
            tasks = map(self._detect_status_async, object_wrappers)
            statuses = await asyncio.gather(*tasks, return_exceptions=True)
            for (object_wrapper, status) in zip(object_wrappers, statuses):
                if isinstance(status, Exception):
                    # 记录日志，并将状态设为 UNKNOWN
                    object_wrapper.status = Status.UNKNOWN
                else:
                    object_wrapper.status = status


    async def _clean_async(self) -> None:
        """
        删除池中不可用的对象。
        """
        # 挑出无效对象
        objects_to_be_removed = [
            object_wrapper.object
            for object_wrapper in await self._get_object_wrappers_by_status_async(Status.INVALID)
        ]

        # 异步并发删除对象
        object_chunks = self._split_chunk(objects_to_be_removed)
        for objects in object_chunks:
            tasks = map(self._delete_async, objects)
            await asyncio.gather(*tasks, return_exceptions=True)


    async def _withdraw_async(self) -> None:
        """
        强制收回被借出的过期对象。
        """
        # 找出过期的
        now = datetime.now()
        withdrawn_ids = []
        for (_id, due) in self._due_datetime.items():
            if due < now:
                withdrawn_ids.append(_id)

        # 回收
        for _id in withdrawn_ids:
            self._due_datetime.pop(_id)
            object_wrapper = self._object_wrappers.get(_id, None)
            if object_wrapper and object_wrapper.status == Status.BORROWED:
                object_wrapper.status = Status.PENDING


    @async_locked
    async def update_status_async(self) -> None:
        """
        更新对象的状态记录。
        """
        await self._withdraw_async()
        await self._detect_async()
        await self._clean_async()


    async def _get_object_wrappers_by_status_async(self, status: Status) -> List[ObjectWrapper[Object]]:
        """
        根据状态查找对象。
        """
        return [
            object_wrapper
            for object_wrapper in self._object_wrappers.values()
            if object_wrapper.status == status
        ]


    @async_locked
    async def borrow_async(
        self,
        timeout: Optional[Number | timedelta] = None,
        **kwargs
    ) -> Optional[ObjectPack[Object]]:
        """
        从池中借出一个对象。

        Args:
            timeout (Optional[Number | timedelta]): 借出对象的借出时间间隔，超过该时间后，对象将强制归还。
            - Number: 单位：秒。
            - timedelta: 经过该时间间隔被归还。
            - None: 不限超时。
        """
        # 获取对象
        await self.update_status_async()
        available_object_wrappers = await self._get_object_wrappers_by_status_async(Status.AVAILABLE)
        object_wrapper = await self._select_object_async(available_object_wrappers, **kwargs)
        if object_wrapper is None:
            # 没有可用对象
            return None

        # 计算到期时间
        if timeout is None:
            due_time = datetime.max
        else:
            if isinstance(timeout, Number):
                timeout = timedelta(seconds = timeout)
            due_time = datetime.now() + timeout

        # 记录借出
        object_wrapper.status = Status.BORROWED
        self._due_datetime[id(object_wrapper.object)] = due_time

        return await self._packer_async(object_wrapper)


    # ==== 异步方法转同步 ====

    def add(self, obj: Object, **kwargs) -> ObjectWrapper[Object]:
        """ Synchronous version of `.add_async`. """
        return asyncio.run(self.add_async(obj, **kwargs))

    def discard(self, obj: Object) -> None:
        """ Synchronous version of `.discard_async`. """
        asyncio.run(self.discard_async(obj))

    def remove(self, obj: Object) -> None:
        """ Synchronous version of `.remove_async`. """
        asyncio.run(self.remove_async(obj))

    def clear(self) -> None:
        """ Synchronous version of `.clear_async`. """
        asyncio.run(self.clear_async())

    def get_status(self, obj: Object) -> Status:
        """ Synchronous version of `.get_status_async`. """
        return asyncio.run(self.get_status_async(obj))

    def update_status(self) -> None:
        """ Synchronous version of `.update_status_async`. """
        asyncio.run(self.update_status_async())

    def borrow(self, timeout: Optional[Number | timedelta] = None, **kwargs) -> Optional[ObjectPack[Object]]:
        """ Synchronous version of `.borrow_async`. """
        return asyncio.run(self.borrow_async(timeout, **kwargs))
