"""
对象池。
"""

from .exceptions import PoolError, ObjectNotFoundError
from .status import Status
from .pool import (
	Pool,
	Object, ObjectWrapper, ObjectPack
)
