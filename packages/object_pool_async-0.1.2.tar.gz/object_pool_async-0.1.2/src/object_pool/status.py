"""
enum: Status
"""

try:
    from enum import StrEnum
except ImportError:
    # 兼容低版本
    from enum import Enum
    class StrEnum(str, Enum):
        pass


class Status(StrEnum):
    """
    池中对象的状态。

    Note:
        PENDING: 一般出现在：对象刚入池时、对象刚被归还时、对象借出超时后。
        DORMANT: 对象目前不可用，但是过一段时间可能可用。
        INVALID: 对象永久用不了。
        UNKNOWN: 一般不会出现。
    """

    # 被借出的
    BORROWED = "borrowed"

    # 待检测的
    PENDING = "pending"

    # 可用的
    AVAILABLE = "available"

    # 休眠的
    DORMANT = "dormant"

    # 不可用的
    INVALID = "invalid"

    # 未知的
    UNKNOWN = "unknown"
