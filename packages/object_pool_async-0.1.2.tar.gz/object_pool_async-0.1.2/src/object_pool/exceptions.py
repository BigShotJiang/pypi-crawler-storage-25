"""
异常
"""

class PoolError(Exception):
    """
    与对象池有关的错误。
    """


class ObjectNotFoundError(PoolError):
    """
    在池中没有找到对象。
    """
