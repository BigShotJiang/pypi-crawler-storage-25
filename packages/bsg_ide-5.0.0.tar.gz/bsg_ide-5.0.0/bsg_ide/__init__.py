"""
BSG-IDE - Beamer Slide Generator Integrated Development Environment
"""

__version__ = "5.0.0"
__author__ = "Ninan Sajeeth Philip"
__license__ = "MIT"

from .BSG_IDE import BeamerSlideEditor, main

__all__ = ['BeamerSlideEditor', 'main']
