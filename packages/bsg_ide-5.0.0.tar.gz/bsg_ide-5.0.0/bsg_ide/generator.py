#!/usr/bin/env python3
"""
Wrapper for BeamerSlideGenerator to handle lazy imports
"""

import sys
import os
from pathlib import Path

# Try to import the actual generator
try:
    # First try from installed package
    from BeamerSlideGenerator import *
except ImportError:
    # Try from local directory
    script_dir = Path(__file__).parent.parent
    sys.path.insert(0, str(script_dir))
    try:
        from BeamerSlideGenerator import *
    except ImportError:
        # Fallback: create stub functions that prompt for installation
        print("⚠ BeamerSlideGenerator not found. Installing...")

        # Try to download
        try:
            import requests
            url = "https://raw.githubusercontent.com/sajeethphilip/Beamer-Slide-Generator/main/BeamerSlideGenerator.py"
            response = requests.get(url)
            if response.status_code == 200:
                target_path = Path(__file__).parent / "BeamerSlideGenerator.py"
                with open(target_path, 'w') as f:
                    f.write(response.text)
                print("✓ BeamerSlideGenerator downloaded")
                from BeamerSlideGenerator import *
            else:
                raise ImportError("Could not download BeamerSlideGenerator")
        except Exception as e:
            raise ImportError(f"Could not load BeamerSlideGenerator: {e}")
