#!/usr/bin/env python3
"""
Entry point for BSG-IDE
"""

from .BSG_IDE import main

if __name__ == "__main__":
    main()
