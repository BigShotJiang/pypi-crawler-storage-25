#!/usr/bin/env python3
"""
BSG-IDE Main Editor Class with Lazy Dependency Loading
"""

import os
import sys
import threading
import traceback
from pathlib import Path

# Lazy loading wrappers for optional dependencies
class LazyLoader:
    """Lazy load modules on first use"""

    def __init__(self, module_name, feature_name):
        self.module_name = module_name
        self.feature_name = feature_name
        self._module = None

    def __getattr__(self, name):
        if self._module is None:
            self._load()
        return getattr(self._module, name)

    def _load(self):
        """Load the module on-demand"""
        from .__main__ import DependencyManager
        success, module = DependencyManager.ensure_import(self.module_name, self.feature_name)
        if success:
            self._module = module
        else:
            raise ImportError(f"Could not load {self.module_name}. {self.feature_name} unavailable.")


# Create lazy loaders for optional features
requests = LazyLoader('requests', 'media')
yt_dlp = LazyLoader('yt_dlp', 'media')
cv2 = LazyLoader('cv2', 'media')
spellchecker = LazyLoader('spellchecker', 'spellcheck')
fitz = LazyLoader('fitz', 'pdf')
screeninfo = LazyLoader('screeninfo', 'screen')
pyautogui = LazyLoader('pyautogui', 'screen')


# Import required modules
import customtkinter as ctk
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image


class BeamerSlideEditor(ctk.CTk):
    """Main editor class with lazy-loaded dependencies"""

    def __init__(self):
        super().__init__()

        # Basic initialization
        self.title("BeamerSlide Generator IDE")
        self.geometry("1200x800")

        # Create basic UI elements
        self._create_basic_ui()

        # Check and install dependencies in background
        self._check_dependencies_background()

    def _create_basic_ui(self):
        """Create basic UI elements that don't need optional dependencies"""
        # Create sidebar
        self.sidebar = ctk.CTkFrame(self)
        self.sidebar.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)

        # Create main editor
        self.editor_frame = ctk.CTkFrame(self)
        self.editor_frame.grid(row=0, column=1, sticky="nsew", padx=5, pady=5)

        # Configure grid weights
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # Add basic widgets
        self._add_basic_widgets()

    def _add_basic_widgets(self):
        """Add basic widgets that work without optional dependencies"""
        # Title entry
        ctk.CTkLabel(self.editor_frame, text="Title:").pack(anchor="w", padx=5)
        self.title_entry = ctk.CTkEntry(self.editor_frame, width=400)
        self.title_entry.pack(fill="x", padx=5, pady=2)

        # Media entry
        ctk.CTkLabel(self.editor_frame, text="Media:").pack(anchor="w", padx=5)
        self.media_entry = ctk.CTkEntry(self.editor_frame, width=400)
        self.media_entry.pack(fill="x", padx=5, pady=2)

        # Content editor
        ctk.CTkLabel(self.editor_frame, text="Content:").pack(anchor="w", padx=5)
        self.content_editor = ctk.CTkTextbox(self.editor_frame, height=200)
        self.content_editor.pack(fill="both", expand=True, padx=5, pady=2)

        # Notes editor
        ctk.CTkLabel(self.editor_frame, text="Notes:").pack(anchor="w", padx=5)
        self.notes_editor = ctk.CTkTextbox(self.editor_frame, height=100)
        self.notes_editor.pack(fill="x", padx=5, pady=2)

        # Slide list
        ctk.CTkLabel(self.sidebar, text="Slides").pack(pady=5)
        self.slide_list = ctk.CTkTextbox(self.sidebar, width=200, height=300)
        self.slide_list.pack(padx=5, pady=5)

        # Basic buttons
        button_frame = ctk.CTkFrame(self.sidebar)
        button_frame.pack(fill="x", padx=5, pady=5)

        ctk.CTkButton(button_frame, text="New Slide", command=self.new_slide).pack(fill="x", pady=2)
        ctk.CTkButton(button_frame, text="Delete Slide", command=self.delete_slide).pack(fill="x", pady=2)
        ctk.CTkButton(button_frame, text="Save", command=self.save_file).pack(fill="x", pady=2)

    def _check_dependencies_background(self):
        """Check for optional dependencies in background"""
        def check():
            from .__main__ import DependencyManager

            # Check each optional dependency
            for module_name, (package, feature, desc) in DependencyManager.PACKAGES.items():
                try:
                    __import__(module_name)
                    # Mark as installed in dependency manager
                    DependencyManager._installed.add(module_name)
                except ImportError:
                    # Don't install automatically, just note it's missing
                    pass

            # Update UI to show available features
            self.after(0, self._update_features_available)

        threading.Thread(target=check, daemon=True).start()

    def _update_features_available(self):
        """Update UI based on available features"""
        # Check if media features are available
        try:
            __import__('requests')
            media_available = True
        except ImportError:
            media_available = False

        # Add media buttons if available
        if media_available and not hasattr(self, '_media_buttons_added'):
            self._add_media_buttons()
            self._media_buttons_added = True

        # Check if spell checking is available
        try:
            __import__('spellchecker')
            spell_available = True
        except ImportError:
            spell_available = False

        if spell_available and not hasattr(self, '_spell_check_added'):
            self._add_spell_check()
            self._spell_check_added = True

        # Update status
        self.title(f"BeamerSlide Generator IDE - Features: Media={media_available}, SpellCheck={spell_available}")

    def _add_media_buttons(self):
        """Add media buttons when requests is available"""
        # Add to media frame (create if needed)
        media_frame = ctk.CTkFrame(self.editor_frame)
        media_frame.pack(fill="x", padx=5, pady=2)

        ctk.CTkButton(media_frame, text="Browse", command=self.browse_media).pack(side="left", padx=2)
        ctk.CTkButton(media_frame, text="YouTube", command=self.youtube_dialog).pack(side="left", padx=2)
        ctk.CTkButton(media_frame, text="Search Images", command=self.search_images).pack(side="left", padx=2)

    def _add_spell_check(self):
        """Add spell checking when pyspellchecker is available"""
        # Add status label
        status_frame = ctk.CTkFrame(self.editor_frame)
        status_frame.pack(fill="x", padx=5, pady=2)

        self.spell_status = ctk.CTkLabel(status_frame, text="✓ Spell checking available", text_color="green")
        self.spell_status.pack(side="left", padx=5)

        # Bind spell check events
        self.content_editor._textbox.bind('<KeyRelease>', self._delayed_spell_check)
        self.notes_editor._textbox.bind('<KeyRelease>', self._delayed_spell_check)

    def _delayed_spell_check(self, event=None):
        """Delayed spell check using lazy-loaded spellchecker"""
        try:
            # Import spellchecker lazily
            import spellchecker
            if not hasattr(self, '_spell_checker'):
                self._spell_checker = spellchecker.SpellChecker()

            # Perform spell check (simplified)
            text = event.widget.get("1.0", "end-1c")
            words = text.split()
            misspelled = self._spell_checker.unknown(words)

            # Update status
            if misspelled:
                self.spell_status.configure(text=f"⚠ {len(misspelled)} misspelled words", text_color="orange")
            else:
                self.spell_status.configure(text="✓ No misspelled words", text_color="green")
        except ImportError:
            pass

    # Basic methods (simplified versions)
    def new_slide(self):
        """Create new slide"""
        pass

    def delete_slide(self):
        """Delete current slide"""
        pass

    def save_file(self):
        """Save file"""
        messagebox.showinfo("Info", "Save functionality - full version available after installing dependencies")

    def browse_media(self):
        """Browse media files"""
        try:
            import requests
            # Use file browser
            filename = filedialog.askopenfilename(
                title="Select Media File",
                filetypes=[("Media files", "*.png *.jpg *.jpeg *.gif *.mp4 *.avi *.mov"), ("All files", "*.*")]
            )
            if filename:
                self.media_entry.delete(0, 'end')
                self.media_entry.insert(0, f"\\file {filename}")
        except ImportError:
            messagebox.showinfo("Info", "Media features require requests. Install with: pip install requests")

    def youtube_dialog(self):
        """Add YouTube video"""
        messagebox.showinfo("YouTube", "YouTube support requires yt-dlp. Install with: pip install yt-dlp")

    def search_images(self):
        """Search for images"""
        import webbrowser
        query = self.title_entry.get() or "presentation"
        webbrowser.open(f"https://www.google.com/search?q={query}&tbm=isch")

    def generate_pdf(self):
        """Generate PDF"""
        messagebox.showinfo("PDF Generation", "PDF generation requires full dependencies. Run: pip install 'bsg-ide[full]'")


# Main entry for direct execution
def main():
    app = BeamerSlideEditor()
    app.mainloop()


if __name__ == "__main__":
    main()
