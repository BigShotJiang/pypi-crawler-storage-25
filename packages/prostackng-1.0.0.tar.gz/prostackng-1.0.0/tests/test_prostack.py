"""
ProStack NG Python SDK — Test Suite
pytest + respx (httpx mock library)
"""

from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any, Dict

import httpx
import pytest
import respx

from prostackng import (
    AsyncProStack,
    AuthenticationError,
    InsufficientBalanceError,
    NetworkError,
    ProStack,
    ProStackError,
    RateLimitError,
    ServerError,
    ValidationError,
    verify_webhook,
    parse_webhook_payload,
)

BASE = "https://prostack-api.onrender.com"


def api(path: str) -> str:
    return f"{BASE}{path}"


def ok(data: Any) -> Dict[str, Any]:
    return {"success": True, "data": data}


# ── Helpers ───────────────────────────────────────────────────

def make_client(**kwargs: Any) -> ProStack:
    return ProStack(
        api_key=kwargs.get("api_key", "psk_test_sdk_key"),
        max_retries=kwargs.get("max_retries", 0),
        base_url=BASE,
    )


def make_async_client(**kwargs: Any) -> AsyncProStack:
    return AsyncProStack(
        api_key=kwargs.get("api_key", "psk_test_sdk_key"),
        max_retries=kwargs.get("max_retries", 0),
        base_url=BASE,
    )


# ── Constructor ───────────────────────────────────────────────

class TestConstructor:
    def test_raises_on_empty_api_key(self) -> None:
        with pytest.raises(ValueError, match="api_key is required"):
            ProStack(api_key="")

    def test_infers_test_environment(self) -> None:
        c = ProStack(api_key="psk_test_abc")
        assert c.environment == "test"

    def test_infers_live_environment(self) -> None:
        c = ProStack(api_key="psk_live_abc")
        assert c.environment == "live"

    def test_all_services_exposed(self) -> None:
        c = make_client()
        assert c.notifications is not None
        assert c.payments      is not None
        assert c.identity      is not None
        assert c.vtu           is not None
        assert c.reports       is not None
        assert c.webhooks      is not None

    def test_context_manager(self) -> None:
        with ProStack(api_key="psk_test_abc", base_url=BASE) as client:
            assert client.environment == "test"

    def test_async_raises_on_empty_key(self) -> None:
        with pytest.raises(ValueError):
            AsyncProStack(api_key="")


# ── Notifications — SMS ───────────────────────────────────────

class TestNotificationsSms:
    @respx.mock
    def test_send_sms_success(self) -> None:
        data = {"id": "n1", "status": "sent", "provider": "termii", "cost": 4.0, "created_at": "2026-04-01T00:00:00Z"}
        respx.post(api("/v1/notifications/sms")).mock(return_value=httpx.Response(200, json=ok(data)))

        result = make_client().notifications.send_sms(to="08012345678", message="Hello")
        assert result.id == "n1"
        assert result.status == "sent"
        assert result.cost == 4.0

    @respx.mock
    def test_send_sms_passes_api_key_header(self) -> None:
        data = {"id": "n2", "status": "sent", "provider": "termii", "cost": 4.0, "created_at": ""}
        route = respx.post(api("/v1/notifications/sms")).mock(return_value=httpx.Response(200, json=ok(data)))

        make_client(api_key="psk_test_my_key").notifications.send_sms(to="080", message="test")
        assert route.calls[0].request.headers["X-API-Key"] == "psk_test_my_key"

    @respx.mock
    def test_send_sms_sends_correct_body(self) -> None:
        data = {"id": "n3", "status": "sent", "provider": "sandbox", "cost": 0.0, "created_at": ""}
        route = respx.post(api("/v1/notifications/sms")).mock(return_value=httpx.Response(200, json=ok(data)))

        make_client().notifications.send_sms(to="+2348012345678", message="OTP: 4821", sender_id="MyApp")

        body = json.loads(route.calls[0].request.content)
        assert body["to"] == "+2348012345678"
        assert body["sender_id"] == "MyApp"

    @respx.mock
    def test_send_bulk_sms(self) -> None:
        data = {"job_id": "job_1", "total": 2, "status": "queued", "sent": 0, "failed": 0, "pending": 2, "created_at": ""}
        respx.post(api("/v1/notifications/bulk-sms")).mock(return_value=httpx.Response(200, json=ok(data)))

        job = make_client().notifications.send_bulk_sms(
            recipients=[{"to": "08012345678", "message": "Hi A"}, {"to": "08098765432", "message": "Hi B"}]
        )
        assert job.job_id == "job_1"
        assert job.total == 2
        assert job.status == "queued"


# ── Payments ──────────────────────────────────────────────────

class TestPayments:
    @respx.mock
    def test_initiate_payment(self) -> None:
        data = {
            "id": "pay_1", "reference": "PSK-REF-001", "amount": 5000.0,
            "currency": "NGN", "email": "u@e.com", "status": "pending",
            "provider": "paystack", "authorization_url": "https://checkout.paystack.com/abc",
            "created_at": "2026-04-01T00:00:00Z",
        }
        respx.post(api("/v1/payments/initiate")).mock(return_value=httpx.Response(200, json=ok(data)))

        result = make_client().payments.initiate(amount=5000, email="u@e.com")
        assert result.authorization_url == "https://checkout.paystack.com/abc"
        assert result.amount == 5000.0
        assert result.status == "pending"

    @respx.mock
    def test_verify_payment(self) -> None:
        data = {"id": "pay_1", "reference": "REF-001", "amount": 5000.0, "status": "success", "provider": "paystack", "verified_at": ""}
        respx.get(api("/v1/payments/verify/REF-001")).mock(return_value=httpx.Response(200, json=ok(data)))

        result = make_client().payments.verify("REF-001")
        assert result.status == "success"


# ── Identity ──────────────────────────────────────────────────

class TestIdentity:
    @respx.mock
    def test_verify_bvn(self) -> None:
        data = {
            "id": "idc_1", "check_type": "bvn", "status": "verified",
            "provider": "smile_identity", "first_name": "John", "last_name": "Doe",
            "cost": 100.0, "created_at": "2026-04-01T00:00:00Z",
        }
        respx.post(api("/v1/identity/verify-bvn")).mock(return_value=httpx.Response(200, json=ok(data)))

        result = make_client().identity.verify_bvn(bvn="12345678901", first_name="John")
        assert result.status == "verified"
        assert result.first_name == "John"
        assert result.cost == 100.0

    @respx.mock
    def test_verify_nin(self) -> None:
        data = {"id": "idc_2", "check_type": "nin", "status": "verified", "provider": "smile_identity", "cost": 150.0, "created_at": ""}
        respx.post(api("/v1/identity/verify-nin")).mock(return_value=httpx.Response(200, json=ok(data)))

        result = make_client().identity.verify_nin(nin="12345678901")
        assert result.check_type == "nin"

    @respx.mock
    def test_verify_phone(self) -> None:
        data = {"id": "idc_3", "check_type": "phone", "status": "verified", "provider": "smile_identity", "cost": 50.0, "created_at": ""}
        respx.post(api("/v1/identity/verify-phone")).mock(return_value=httpx.Response(200, json=ok(data)))

        result = make_client().identity.verify_phone(phone="08012345678", network="mtn")
        assert result.status == "verified"


# ── VTU ──────────────────────────────────────────────────────

class TestVtu:
    @respx.mock
    def test_buy_airtime(self) -> None:
        data = {"id": "vtu_1", "type": "airtime", "status": "success", "provider": "vtpass", "amount": 500.0, "cost": 7.5, "created_at": ""}
        respx.post(api("/v1/vtu/airtime")).mock(return_value=httpx.Response(200, json=ok(data)))

        result = make_client().vtu.buy_airtime(phone="08012345678", amount=500, network="mtn")
        assert result.status == "success"
        assert result.type == "airtime"

    @respx.mock
    def test_pay_electricity_returns_token(self) -> None:
        data = {"id": "vtu_2", "type": "electricity", "status": "success", "provider": "vtpass", "token": "1234-5678-9012", "amount": 5000.0, "cost": 0.0, "created_at": ""}
        respx.post(api("/v1/vtu/electricity")).mock(return_value=httpx.Response(200, json=ok(data)))

        result = make_client().vtu.pay_electricity(meter_number="123", disco="phed", meter_type="prepaid", amount=5000)
        assert result.token == "1234-5678-9012"


# ── Reports ───────────────────────────────────────────────────

class TestReports:
    @respx.mock
    def test_generate_report(self) -> None:
        data = {"id": "rep_1", "title": "Test", "status": "pending", "output_format": "pdf", "cost": 20.0, "created_at": ""}
        respx.post(api("/v1/reports/generate")).mock(return_value=httpx.Response(200, json=ok(data)))

        result = make_client().reports.generate(title="Test", data=[{"col": "val"}])
        assert result.status == "pending"
        assert result.cost == 20.0


# ── Webhooks ──────────────────────────────────────────────────

class TestWebhooks:
    @respx.mock
    def test_create_webhook(self) -> None:
        data = {"id": "wh_1", "url": "https://app.com/hook", "events": ["payment.success"], "is_active": True, "created_at": ""}
        respx.post(api("/v1/webhooks")).mock(return_value=httpx.Response(200, json=ok(data)))

        result = make_client().webhooks.create(url="https://app.com/hook", events=["payment.success"])
        assert result.id == "wh_1"
        assert "payment.success" in result.events

    @respx.mock
    def test_delete_webhook(self) -> None:
        route = respx.delete(api("/v1/webhooks/wh_1")).mock(return_value=httpx.Response(200, json=ok(None)))
        make_client().webhooks.delete("wh_1")
        assert route.called


# ── Error Handling ────────────────────────────────────────────

class TestErrors:
    @respx.mock
    def test_raises_authentication_error_on_401(self) -> None:
        respx.post(api("/v1/notifications/sms")).mock(
            return_value=httpx.Response(401, json={"message": "Invalid API key"})
        )
        with pytest.raises(AuthenticationError) as exc_info:
            make_client().notifications.send_sms(to="080", message="x")
        assert exc_info.value.status_code == 401

    @respx.mock
    def test_raises_authentication_error_on_403(self) -> None:
        respx.post(api("/v1/identity/verify-bvn")).mock(
            return_value=httpx.Response(403, json={"message": "Forbidden"})
        )
        with pytest.raises(AuthenticationError) as exc_info:
            make_client().identity.verify_bvn(bvn="12345678901")
        assert exc_info.value.status_code == 403

    @respx.mock
    def test_raises_validation_error_on_422(self) -> None:
        respx.post(api("/v1/notifications/sms")).mock(
            return_value=httpx.Response(422, json={"message": "Validation failed", "fields": {"to": "invalid"}})
        )
        with pytest.raises(ValidationError) as exc_info:
            make_client().notifications.send_sms(to="bad", message="x")
        assert exc_info.value.fields == {"to": "invalid"}

    @respx.mock
    def test_raises_insufficient_balance_on_402(self) -> None:
        respx.post(api("/v1/identity/verify-bvn")).mock(
            return_value=httpx.Response(402, json={"message": "Insufficient balance", "balance": 50.0, "required": 100.0})
        )
        with pytest.raises(InsufficientBalanceError) as exc_info:
            make_client().identity.verify_bvn(bvn="12345678901")
        assert exc_info.value.balance == 50.0
        assert exc_info.value.required == 100.0

    @respx.mock
    def test_raises_rate_limit_error_on_429(self) -> None:
        respx.post(api("/v1/notifications/sms")).mock(
            return_value=httpx.Response(
                429,
                json={"message": "Rate limit exceeded"},
                headers={"retry-after": "30"},
            )
        )
        with pytest.raises(RateLimitError) as exc_info:
            make_client().notifications.send_sms(to="080", message="x")
        assert exc_info.value.retry_after == 30

    @respx.mock
    def test_raises_server_error_on_500(self) -> None:
        respx.post(api("/v1/notifications/sms")).mock(
            return_value=httpx.Response(500, json={"message": "Internal server error"})
        )
        with pytest.raises(ServerError):
            make_client().notifications.send_sms(to="080", message="x")

    @respx.mock
    def test_no_retry_on_401(self) -> None:
        """Auth errors must NOT be retried."""
        route = respx.post(api("/v1/notifications/sms")).mock(
            return_value=httpx.Response(401, json={"message": "Unauthorized"})
        )
        client = ProStack(api_key="psk_test_bad", max_retries=3, base_url=BASE)
        with pytest.raises(AuthenticationError):
            client.notifications.send_sms(to="080", message="x")
        assert route.call_count == 1  # called exactly once — no retries


# ── Webhook Verification ──────────────────────────────────────

class TestWebhookVerification:
    def _sign(self, payload: str, secret: str) -> str:
        return hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()

    def test_valid_signature_returns_true(self) -> None:
        payload = '{"event":"payment.success","data":{},"timestamp":"2026-04-01T00:00:00Z"}'
        secret  = "my_webhook_secret"
        sig     = self._sign(payload, secret)
        assert verify_webhook(payload, sig, secret) is True

    def test_invalid_signature_returns_false(self) -> None:
        assert verify_webhook('{"event":"test"}', "deadbeef", "secret") is False

    def test_empty_signature_returns_false(self) -> None:
        assert verify_webhook('{"event":"test"}', "", "secret") is False

    def test_empty_secret_returns_false(self) -> None:
        assert verify_webhook('{"event":"test"}', "abc123", "") is False

    def test_bytes_payload(self) -> None:
        payload = b'{"event":"vtu.success"}'
        secret  = "byte_secret"
        sig     = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
        assert verify_webhook(payload, sig, secret) is True

    def test_signature_case_insensitive(self) -> None:
        payload = '{"event":"test"}'
        secret  = "case_secret"
        sig     = self._sign(payload, secret).upper()  # uppercase should still match
        assert verify_webhook(payload, sig, secret) is True

    def test_parse_webhook_payload(self) -> None:
        raw = json.dumps({"event": "payment.success", "data": {"id": "pay_1", "amount": 5000}, "timestamp": "2026-04-01"})
        parsed = parse_webhook_payload(raw)
        assert parsed["event"] == "payment.success"
        assert parsed["data"]["amount"] == 5000

    def test_parse_bytes_payload(self) -> None:
        raw = b'{"event":"identity.verified","data":{},"timestamp":""}'
        parsed = parse_webhook_payload(raw)
        assert parsed["event"] == "identity.verified"

    def test_prostack_static_method(self) -> None:
        payload = '{"event":"test"}'
        secret  = "static_secret"
        sig     = self._sign(payload, secret)
        assert ProStack.verify_webhook(payload, sig, secret) is True


# ── Async Client ──────────────────────────────────────────────

class TestAsyncClient:
    @pytest.mark.asyncio
    @respx.mock
    async def test_async_send_sms(self) -> None:
        data = {"id": "n_async", "status": "sent", "provider": "termii", "cost": 4.0, "created_at": ""}
        respx.post(api("/v1/notifications/sms")).mock(return_value=httpx.Response(200, json=ok(data)))

        async with make_async_client() as client:
            result = await client.notifications.send_sms(to="08012345678", message="Async test")
        assert result.status == "sent"

    @pytest.mark.asyncio
    @respx.mock
    async def test_async_verify_bvn(self) -> None:
        data = {"id": "idc_async", "check_type": "bvn", "status": "verified", "provider": "smile_identity", "cost": 100.0, "created_at": ""}
        respx.post(api("/v1/identity/verify-bvn")).mock(return_value=httpx.Response(200, json=ok(data)))

        async with make_async_client() as client:
            result = await client.identity.verify_bvn(bvn="12345678901")
        assert result.status == "verified"

    @pytest.mark.asyncio
    @respx.mock
    async def test_async_initiate_payment(self) -> None:
        data = {
            "id": "pay_async", "reference": "REF-ASYNC", "amount": 10000.0,
            "currency": "NGN", "email": "a@b.com", "status": "pending",
            "provider": "paystack", "authorization_url": "https://checkout.paystack.com/xyz",
            "created_at": "",
        }
        respx.post(api("/v1/payments/initiate")).mock(return_value=httpx.Response(200, json=ok(data)))

        async with make_async_client() as client:
            result = await client.payments.initiate(amount=10000, email="a@b.com")
        assert result.authorization_url == "https://checkout.paystack.com/xyz"

    @pytest.mark.asyncio
    @respx.mock
    async def test_async_raises_auth_error(self) -> None:
        respx.post(api("/v1/notifications/sms")).mock(
            return_value=httpx.Response(401, json={"message": "Invalid API key"})
        )
        async with make_async_client() as client:
            with pytest.raises(AuthenticationError):
                await client.notifications.send_sms(to="080", message="x")
