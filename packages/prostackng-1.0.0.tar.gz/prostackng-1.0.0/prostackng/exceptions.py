"""
ProStack NG Python SDK — Exception Classes
"""

from __future__ import annotations

from typing import Any, Dict, Optional


class ProStackError(Exception):
    """
    Base exception for all ProStack SDK errors.

    Attributes:
        message:     Human-readable error message from the API.
        status_code: HTTP status code (0 for network errors).
        response:    Raw API error response body.
    """

    def __init__(
        self,
        message: str,
        status_code: int = 0,
        response: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.message     = message
        self.status_code = status_code
        self.response    = response or {}

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(status_code={self.status_code}, message={self.message!r})"


class AuthenticationError(ProStackError):
    """
    Raised when the API key is missing, invalid, or lacks permission.
    HTTP 401 / 403.
    """


class ValidationError(ProStackError):
    """
    Raised when request input fails server-side validation.
    HTTP 400 / 422.

    Attributes:
        fields: Optional dict of field-level errors, e.g. {"bvn": "must be 11 digits"}.
    """

    def __init__(
        self,
        message: str,
        response: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message, 422, response)
        self.fields: Optional[Dict[str, str]] = (
            response.get("fields") if response else None  # type: ignore[assignment]
        )


class InsufficientBalanceError(ProStackError):
    """
    Raised when the developer's wallet balance is too low.
    HTTP 402.

    Attributes:
        balance:  Current wallet balance in NGN.
        required: Required balance for the operation in NGN.
    """

    def __init__(
        self,
        message: str,
        balance: float = 0.0,
        required: float = 0.0,
        response: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message, 402, response)
        self.balance  = balance
        self.required = required


class RateLimitError(ProStackError):
    """
    Raised when the rate limit is exceeded.
    HTTP 429.

    Attributes:
        retry_after: Seconds to wait before retrying.
    """

    def __init__(
        self,
        message: str,
        retry_after: int = 60,
        response: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message, 429, response)
        self.retry_after = retry_after


class NetworkError(ProStackError):
    """
    Raised when a network-level error occurs (timeout, connection refused, DNS failure).
    status_code is 0.
    """

    def __init__(self, message: str, cause: Optional[Exception] = None) -> None:
        super().__init__(message, 0)
        self.__cause__ = cause


class ServerError(ProStackError):
    """
    Raised when the ProStack API returns a 5xx error.
    """
