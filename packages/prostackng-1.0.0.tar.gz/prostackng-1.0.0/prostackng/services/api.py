"""ProStack NG — Payments, Identity, VTU, Reports, Webhooks Services"""

from __future__ import annotations

from typing import List

from .._http import AsyncHttpClient, SyncHttpClient
from ..models import (
    AirtimeRequest,
    CableTvRequest,
    CreateWebhookRequest,
    DataPlan,
    DataRequest,
    ElectricityRequest,
    GenerateReportRequest,
    GenerateReportResponse,
    IdentityCheck,
    IdentityVerificationResponse,
    InitiatePaymentRequest,
    InitiatePaymentResponse,
    PaymentTransaction,
    Report,
    VerifyBvnRequest,
    VerifyNinRequest,
    VerifyPaymentResponse,
    VerifyPhoneRequest,
    VtuTransaction,
    VtuTransactionResponse,
    Webhook,
)


# ── Payments ──────────────────────────────────────────────────

class PaymentsService:
    def __init__(self, http: SyncHttpClient) -> None:
        self._http = http

    def initiate(
        self,
        amount: float,
        email: str,
        reference: str | None = None,
        provider: str = "paystack",
        metadata: dict | None = None,
    ) -> InitiatePaymentResponse:
        """
        Initiate a payment. Returns an authorization_url to redirect your user to.

        Example::

            payment = client.payments.initiate(amount=5000, email="user@app.com")
            # Redirect user to payment.authorization_url
        """
        payload = InitiatePaymentRequest(
            amount=amount, email=email, reference=reference,
            provider=provider, metadata=metadata,  # type: ignore[arg-type]
        )
        resp = self._http.request("POST", "/v1/payments/initiate", payload.model_dump(exclude_none=True))
        return InitiatePaymentResponse.model_validate(resp["data"])

    def verify(self, reference: str) -> VerifyPaymentResponse:
        """
        Verify a payment by its reference.

        Example::

            result = client.payments.verify("PSK-REF-abc123")
            if result.status == "success":
                # fulfill order
        """
        resp = self._http.request("GET", f"/v1/payments/verify/{reference}")
        return VerifyPaymentResponse.model_validate(resp["data"])

    def list(self, limit: int = 100) -> List[PaymentTransaction]:
        resp = self._http.request("GET", f"/v1/payments?limit={limit}")
        return [PaymentTransaction.model_validate(t) for t in resp["data"]]


class AsyncPaymentsService:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def initiate(
        self,
        amount: float,
        email: str,
        reference: str | None = None,
        provider: str = "paystack",
        metadata: dict | None = None,
    ) -> InitiatePaymentResponse:
        payload = InitiatePaymentRequest(
            amount=amount, email=email, reference=reference,
            provider=provider, metadata=metadata,  # type: ignore[arg-type]
        )
        resp = await self._http.request("POST", "/v1/payments/initiate", payload.model_dump(exclude_none=True))
        return InitiatePaymentResponse.model_validate(resp["data"])

    async def verify(self, reference: str) -> VerifyPaymentResponse:
        resp = await self._http.request("GET", f"/v1/payments/verify/{reference}")
        return VerifyPaymentResponse.model_validate(resp["data"])

    async def list(self, limit: int = 100) -> List[PaymentTransaction]:
        resp = await self._http.request("GET", f"/v1/payments?limit={limit}")
        return [PaymentTransaction.model_validate(t) for t in resp["data"]]


# ── Identity ──────────────────────────────────────────────────

class IdentityService:
    def __init__(self, http: SyncHttpClient) -> None:
        self._http = http

    def verify_bvn(
        self,
        bvn: str,
        first_name: str | None = None,
        last_name: str | None = None,
        date_of_birth: str | None = None,
    ) -> IdentityVerificationResponse:
        """
        Verify a Bank Verification Number (BVN). Requires LIVE API key.
        Cost: ₦100 per successful verification.

        Example::

            result = client.identity.verify_bvn(
                bvn="12345678901",
                first_name="John",
                last_name="Doe",
            )
            if result.status == "verified":
                print(f"Verified: {result.first_name} {result.last_name}")
        """
        payload = VerifyBvnRequest(
            bvn=bvn, first_name=first_name,
            last_name=last_name, date_of_birth=date_of_birth,
        )
        resp = self._http.request("POST", "/v1/identity/verify-bvn", payload.model_dump(exclude_none=True))
        return IdentityVerificationResponse.model_validate(resp["data"])

    def verify_nin(
        self,
        nin: str,
        first_name: str | None = None,
        last_name: str | None = None,
    ) -> IdentityVerificationResponse:
        """Verify a National Identification Number (NIN). Cost: ₦150."""
        payload = VerifyNinRequest(nin=nin, first_name=first_name, last_name=last_name)
        resp = self._http.request("POST", "/v1/identity/verify-nin", payload.model_dump(exclude_none=True))
        return IdentityVerificationResponse.model_validate(resp["data"])

    def verify_phone(self, phone: str, network: str | None = None) -> IdentityVerificationResponse:
        """Verify a Nigerian phone number. Cost: ₦50."""
        payload = VerifyPhoneRequest(phone=phone, network=network)  # type: ignore[arg-type]
        resp = self._http.request("POST", "/v1/identity/verify-phone", payload.model_dump(exclude_none=True))
        return IdentityVerificationResponse.model_validate(resp["data"])

    def list(self, limit: int = 100) -> List[IdentityCheck]:
        resp = self._http.request("GET", f"/v1/identity?limit={limit}")
        return [IdentityCheck.model_validate(c) for c in resp["data"]]


class AsyncIdentityService:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def verify_bvn(
        self,
        bvn: str,
        first_name: str | None = None,
        last_name: str | None = None,
        date_of_birth: str | None = None,
    ) -> IdentityVerificationResponse:
        payload = VerifyBvnRequest(bvn=bvn, first_name=first_name, last_name=last_name, date_of_birth=date_of_birth)
        resp = await self._http.request("POST", "/v1/identity/verify-bvn", payload.model_dump(exclude_none=True))
        return IdentityVerificationResponse.model_validate(resp["data"])

    async def verify_nin(self, nin: str, first_name: str | None = None, last_name: str | None = None) -> IdentityVerificationResponse:
        payload = VerifyNinRequest(nin=nin, first_name=first_name, last_name=last_name)
        resp = await self._http.request("POST", "/v1/identity/verify-nin", payload.model_dump(exclude_none=True))
        return IdentityVerificationResponse.model_validate(resp["data"])

    async def verify_phone(self, phone: str, network: str | None = None) -> IdentityVerificationResponse:
        payload = VerifyPhoneRequest(phone=phone, network=network)  # type: ignore[arg-type]
        resp = await self._http.request("POST", "/v1/identity/verify-phone", payload.model_dump(exclude_none=True))
        return IdentityVerificationResponse.model_validate(resp["data"])

    async def list(self, limit: int = 100) -> List[IdentityCheck]:
        resp = await self._http.request("GET", f"/v1/identity?limit={limit}")
        return [IdentityCheck.model_validate(c) for c in resp["data"]]


# ── VTU ──────────────────────────────────────────────────────

class VtuService:
    def __init__(self, http: SyncHttpClient) -> None:
        self._http = http

    def buy_airtime(self, phone: str, amount: float, network: str) -> VtuTransactionResponse:
        """
        Top up airtime on any Nigerian network.

        Example::

            result = client.vtu.buy_airtime(phone="08012345678", amount=500, network="mtn")
        """
        payload = AirtimeRequest(phone=phone, amount=amount, network=network)  # type: ignore[arg-type]
        resp = self._http.request("POST", "/v1/vtu/airtime", payload.model_dump())
        return VtuTransactionResponse.model_validate(resp["data"])

    def buy_data(self, phone: str, plan_id: str, network: str) -> VtuTransactionResponse:
        """Purchase a mobile data bundle. Use list_data_plans() first for valid plan_id values."""
        payload = DataRequest(phone=phone, plan_id=plan_id, network=network)  # type: ignore[arg-type]
        resp = self._http.request("POST", "/v1/vtu/data", payload.model_dump())
        return VtuTransactionResponse.model_validate(resp["data"])

    def pay_electricity(
        self, meter_number: str, disco: str, meter_type: str, amount: float
    ) -> VtuTransactionResponse:
        """
        Pay electricity bill. Returns a token for prepaid meters.

        Example::

            result = client.vtu.pay_electricity(
                meter_number="12345678901", disco="phed",
                meter_type="prepaid", amount=5000,
            )
            print(result.token)  # meter token
        """
        payload = ElectricityRequest(
            meter_number=meter_number, disco=disco,  # type: ignore[arg-type]
            meter_type=meter_type, amount=amount,  # type: ignore[arg-type]
        )
        resp = self._http.request("POST", "/v1/vtu/electricity", payload.model_dump())
        return VtuTransactionResponse.model_validate(resp["data"])

    def pay_cable_tv(self, decoder_number: str, provider: str, package: str) -> VtuTransactionResponse:
        """Pay DStv, GOtv, or StarTimes subscription."""
        payload = CableTvRequest(decoder_number=decoder_number, provider=provider, package=package)  # type: ignore[arg-type]
        resp = self._http.request("POST", "/v1/vtu/cable-tv", payload.model_dump())
        return VtuTransactionResponse.model_validate(resp["data"])

    def list_data_plans(self, network: str) -> List[DataPlan]:
        """List available data plans for a network: 'mtn', 'airtel', 'glo', '9mobile'."""
        resp = self._http.request("GET", f"/v1/vtu/data-plans?network={network}")
        return [DataPlan.model_validate(p) for p in resp["data"]]

    def list(self, limit: int = 100) -> List[VtuTransaction]:
        resp = self._http.request("GET", f"/v1/vtu?limit={limit}")
        return [VtuTransaction.model_validate(t) for t in resp["data"]]


class AsyncVtuService:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def buy_airtime(self, phone: str, amount: float, network: str) -> VtuTransactionResponse:
        payload = AirtimeRequest(phone=phone, amount=amount, network=network)  # type: ignore[arg-type]
        resp = await self._http.request("POST", "/v1/vtu/airtime", payload.model_dump())
        return VtuTransactionResponse.model_validate(resp["data"])

    async def buy_data(self, phone: str, plan_id: str, network: str) -> VtuTransactionResponse:
        payload = DataRequest(phone=phone, plan_id=plan_id, network=network)  # type: ignore[arg-type]
        resp = await self._http.request("POST", "/v1/vtu/data", payload.model_dump())
        return VtuTransactionResponse.model_validate(resp["data"])

    async def pay_electricity(self, meter_number: str, disco: str, meter_type: str, amount: float) -> VtuTransactionResponse:
        payload = ElectricityRequest(meter_number=meter_number, disco=disco, meter_type=meter_type, amount=amount)  # type: ignore[arg-type]
        resp = await self._http.request("POST", "/v1/vtu/electricity", payload.model_dump())
        return VtuTransactionResponse.model_validate(resp["data"])

    async def pay_cable_tv(self, decoder_number: str, provider: str, package: str) -> VtuTransactionResponse:
        payload = CableTvRequest(decoder_number=decoder_number, provider=provider, package=package)  # type: ignore[arg-type]
        resp = await self._http.request("POST", "/v1/vtu/cable-tv", payload.model_dump())
        return VtuTransactionResponse.model_validate(resp["data"])

    async def list_data_plans(self, network: str) -> List[DataPlan]:
        resp = await self._http.request("GET", f"/v1/vtu/data-plans?network={network}")
        return [DataPlan.model_validate(p) for p in resp["data"]]

    async def list(self, limit: int = 100) -> List[VtuTransaction]:
        resp = await self._http.request("GET", f"/v1/vtu?limit={limit}")
        return [VtuTransaction.model_validate(t) for t in resp["data"]]


# ── Reports ───────────────────────────────────────────────────

class ReportsService:
    def __init__(self, http: SyncHttpClient) -> None:
        self._http = http

    def generate(
        self,
        title: str,
        data: list[dict],
        output_format: str = "pdf",
        description: str | None = None,
    ) -> GenerateReportResponse:
        """
        Generate a PDF or Excel report from structured data (async — poll get_by_id()).
        Cost: ₦20 per report.

        Example::

            report = client.reports.generate(
                title="April 2026 Sales",
                data=[{"date": "2026-04-01", "amount": 15000}],
            )
            # Poll until complete
            while report.status in ("pending", "processing"):
                import time; time.sleep(3)
                report = client.reports.get_by_id(report.id)
            print(report.output_url)
        """
        payload = GenerateReportRequest(
            title=title, description=description,
            output_format=output_format, data=data,  # type: ignore[arg-type]
        )
        body = {
            "title": payload.title,
            "description": payload.description,
            "output_format": payload.output_format,
            "input_format": payload.input_format,
            "input_data": payload.data,
        }
        resp = self._http.request("POST", "/v1/reports/generate", {k: v for k, v in body.items() if v is not None})
        return GenerateReportResponse.model_validate(resp["data"])

    def get_by_id(self, report_id: str) -> Report:
        resp = self._http.request("GET", f"/v1/reports/{report_id}")
        return Report.model_validate(resp["data"])

    def list(self, limit: int = 100) -> List[Report]:
        resp = self._http.request("GET", f"/v1/reports?limit={limit}")
        return [Report.model_validate(r) for r in resp["data"]]


class AsyncReportsService:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def generate(self, title: str, data: list[dict], output_format: str = "pdf", description: str | None = None) -> GenerateReportResponse:
        payload = GenerateReportRequest(title=title, description=description, output_format=output_format, data=data)  # type: ignore[arg-type]
        body = {"title": payload.title, "output_format": payload.output_format, "input_format": payload.input_format, "input_data": payload.data}
        if description:
            body["description"] = description  # type: ignore[assignment]
        resp = await self._http.request("POST", "/v1/reports/generate", body)  # type: ignore[arg-type]
        return GenerateReportResponse.model_validate(resp["data"])

    async def get_by_id(self, report_id: str) -> Report:
        resp = await self._http.request("GET", f"/v1/reports/{report_id}")
        return Report.model_validate(resp["data"])

    async def list(self, limit: int = 100) -> List[Report]:
        resp = await self._http.request("GET", f"/v1/reports?limit={limit}")
        return [Report.model_validate(r) for r in resp["data"]]


# ── Webhooks ──────────────────────────────────────────────────

class WebhooksService:
    def __init__(self, http: SyncHttpClient) -> None:
        self._http = http

    def create(self, url: str, events: list[str]) -> Webhook:
        """
        Register a webhook endpoint.

        Example::

            wh = client.webhooks.create(
                url="https://yourapp.com/webhooks/prostack",
                events=["payment.success", "identity.verified"],
            )
        """
        payload = CreateWebhookRequest(url=url, events=events)
        resp = self._http.request("POST", "/v1/webhooks", payload.model_dump())
        return Webhook.model_validate(resp["data"])

    def list(self) -> List[Webhook]:
        resp = self._http.request("GET", "/v1/webhooks")
        return [Webhook.model_validate(w) for w in resp["data"]]

    def delete(self, webhook_id: str) -> None:
        self._http.request("DELETE", f"/v1/webhooks/{webhook_id}")


class AsyncWebhooksService:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create(self, url: str, events: list[str]) -> Webhook:
        payload = CreateWebhookRequest(url=url, events=events)
        resp = await self._http.request("POST", "/v1/webhooks", payload.model_dump())
        return Webhook.model_validate(resp["data"])

    async def list(self) -> List[Webhook]:
        resp = await self._http.request("GET", "/v1/webhooks")
        return [Webhook.model_validate(w) for w in resp["data"]]

    async def delete(self, webhook_id: str) -> None:
        await self._http.request("DELETE", f"/v1/webhooks/{webhook_id}")
