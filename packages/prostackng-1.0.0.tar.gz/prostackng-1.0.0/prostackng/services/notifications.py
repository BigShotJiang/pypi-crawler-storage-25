"""ProStack NG — Notifications Service (SMS + Email)"""

from __future__ import annotations

from typing import List

from .._http import AsyncHttpClient, SyncHttpClient
from ..models import (
    BulkSmsJobResponse,
    NotificationLog,
    SendBulkSmsRequest,
    SendEmailRequest,
    SendEmailResponse,
    SendSmsRequest,
    SendSmsResponse,
)


class NotificationsService:
    """Send SMS and email notifications. Access via ``client.notifications``."""

    def __init__(self, http: SyncHttpClient) -> None:
        self._http = http

    def send_sms(self, to: str, message: str, sender_id: str | None = None) -> SendSmsResponse:
        """
        Send a single SMS to a Nigerian phone number.

        Args:
            to:        Phone number (08012345678 or +2348012345678).
            message:   Message body (max 160 chars per segment).
            sender_id: Optional sender ID shown to recipient.

        Example::

            result = client.notifications.send_sms(
                to="08012345678",
                message="Your OTP is 4821. Valid for 5 minutes.",
            )
            print(result.status)  # "sent"
        """
        payload = SendSmsRequest(to=to, message=message, sender_id=sender_id)
        resp = self._http.request("POST", "/v1/notifications/sms", payload.model_dump(exclude_none=True))
        return SendSmsResponse.model_validate(resp["data"])

    def send_email(
        self,
        to: str,
        subject: str,
        body: str,
        html: str | None = None,
        from_name: str | None = None,
    ) -> SendEmailResponse:
        """
        Send an email.

        Example::

            result = client.notifications.send_email(
                to="customer@example.com",
                subject="Your invoice",
                body="Please find your invoice attached.",
                html="<p>Please find your invoice attached.</p>",
            )
        """
        payload = SendEmailRequest(to=to, subject=subject, body=body, html=html, from_name=from_name)
        resp = self._http.request("POST", "/v1/notifications/email", payload.model_dump(exclude_none=True))
        return SendEmailResponse.model_validate(resp["data"])

    def send_bulk_sms(
        self,
        recipients: list[dict],
        callback_url: str | None = None,
    ) -> BulkSmsJobResponse:
        """
        Send bulk SMS to up to 10,000 recipients (async processing).
        Returns a job_id immediately — poll get_bulk_job_status() for progress.

        Example::

            job = client.notifications.send_bulk_sms(
                recipients=[
                    {"to": "08012345678", "message": "Hi John!"},
                    {"to": "08098765432", "message": "Hi Jane!"},
                ],
                callback_url="https://yourapp.com/webhooks/bulk",
            )
            print(job.job_id)
        """
        payload = SendBulkSmsRequest(recipients=recipients, callback_url=callback_url)
        resp = self._http.request("POST", "/v1/notifications/bulk-sms", payload.model_dump(exclude_none=True))
        return BulkSmsJobResponse.model_validate(resp["data"])

    def get_bulk_job_status(self, job_id: str) -> BulkSmsJobResponse:
        """Check the status of a bulk SMS job."""
        resp = self._http.request("GET", f"/v1/notifications/bulk/{job_id}")
        return BulkSmsJobResponse.model_validate(resp["data"])

    def list(self, limit: int = 100) -> List[NotificationLog]:
        """List recent notification logs (SMS + email combined)."""
        resp = self._http.request("GET", f"/v1/notifications?limit={limit}")
        return [NotificationLog.model_validate(item) for item in resp["data"]]


class AsyncNotificationsService:
    """Async version of NotificationsService. Access via ``async_client.notifications``."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def send_sms(self, to: str, message: str, sender_id: str | None = None) -> SendSmsResponse:
        payload = SendSmsRequest(to=to, message=message, sender_id=sender_id)
        resp = await self._http.request("POST", "/v1/notifications/sms", payload.model_dump(exclude_none=True))
        return SendSmsResponse.model_validate(resp["data"])

    async def send_email(
        self,
        to: str,
        subject: str,
        body: str,
        html: str | None = None,
        from_name: str | None = None,
    ) -> SendEmailResponse:
        payload = SendEmailRequest(to=to, subject=subject, body=body, html=html, from_name=from_name)
        resp = await self._http.request("POST", "/v1/notifications/email", payload.model_dump(exclude_none=True))
        return SendEmailResponse.model_validate(resp["data"])

    async def send_bulk_sms(
        self,
        recipients: list[dict],
        callback_url: str | None = None,
    ) -> BulkSmsJobResponse:
        payload = SendBulkSmsRequest(recipients=recipients, callback_url=callback_url)
        resp = await self._http.request("POST", "/v1/notifications/bulk-sms", payload.model_dump(exclude_none=True))
        return BulkSmsJobResponse.model_validate(resp["data"])

    async def get_bulk_job_status(self, job_id: str) -> BulkSmsJobResponse:
        resp = await self._http.request("GET", f"/v1/notifications/bulk/{job_id}")
        return BulkSmsJobResponse.model_validate(resp["data"])

    async def list(self, limit: int = 100) -> List[NotificationLog]:
        resp = await self._http.request("GET", f"/v1/notifications?limit={limit}")
        return [NotificationLog.model_validate(item) for item in resp["data"]]
