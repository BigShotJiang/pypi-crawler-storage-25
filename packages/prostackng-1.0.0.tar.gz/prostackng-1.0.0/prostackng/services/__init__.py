"""ProStack NG service modules."""
