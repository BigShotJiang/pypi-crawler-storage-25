"""
prostackng — Official Python SDK for ProStack NG
================================================

ProStack NG is Africa's unified API gateway: one key for payments,
SMS, email, BVN/NIN identity verification, utility bills, and reports.

Quickstart::

    from prostackng import ProStack

    client = ProStack(api_key="psk_live_...")

    # Send SMS
    sms = client.notifications.send_sms(
        to="08012345678",
        message="Your OTP is 4821. Valid for 5 minutes.",
    )

    # Verify BVN
    bvn = client.identity.verify_bvn(bvn="12345678901", first_name="John")
    if bvn.status == "verified":
        print(f"Name: {bvn.first_name} {bvn.last_name}")

    # Initiate a payment
    payment = client.payments.initiate(amount=5000, email="user@app.com")
    # → redirect user to payment.authorization_url

Async (FastAPI / aiohttp)::

    from prostackng import AsyncProStack

    client = AsyncProStack(api_key="psk_live_...")
    sms = await client.notifications.send_sms(to="080...", message="Hi!")

Error handling::

    from prostackng import ProStack, InsufficientBalanceError, RateLimitError

    try:
        result = client.identity.verify_bvn(bvn="12345678901")
    except InsufficientBalanceError as e:
        print(f"Top up needed. Have ₦{e.balance}, need ₦{e.required}")
    except RateLimitError as e:
        print(f"Rate limited. Retry in {e.retry_after}s")

Homepage: https://prostackng.com.ng
Docs:     https://prostackng.com.ng/docs
GitHub:   https://github.com/PereTheDataAnalyst/prostack-api
"""

from .client import AsyncProStack, ProStack
from .exceptions import (
    AuthenticationError,
    InsufficientBalanceError,
    NetworkError,
    ProStackError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .models import (
    AirtimeRequest,
    BulkSmsJobResponse,
    BulkSmsRecipient,
    CableTvRequest,
    CreateWebhookRequest,
    DataPlan,
    DataRequest,
    ElectricityRequest,
    GenerateReportRequest,
    GenerateReportResponse,
    IdentityCheck,
    IdentityVerificationResponse,
    InitiatePaymentRequest,
    InitiatePaymentResponse,
    NotificationLog,
    PaymentTransaction,
    Report,
    SendBulkSmsRequest,
    SendEmailRequest,
    SendEmailResponse,
    SendSmsRequest,
    SendSmsResponse,
    TopupRequest,
    TopupResponse,
    VerifyBvnRequest,
    VerifyNinRequest,
    VerifyPaymentResponse,
    VerifyPhoneRequest,
    VtuTransaction,
    VtuTransactionResponse,
    WalletBalance,
    Webhook,
    WebhookPayload,
)
from .webhook import parse_webhook_payload, verify_webhook

__version__ = "1.0.0"
__author__  = "ProStack NG Technologies Ltd"
__all__ = [
    # Clients
    "ProStack",
    "AsyncProStack",
    # Errors
    "ProStackError",
    "AuthenticationError",
    "ValidationError",
    "InsufficientBalanceError",
    "RateLimitError",
    "NetworkError",
    "ServerError",
    # Models — Notifications
    "SendSmsRequest",
    "SendSmsResponse",
    "SendEmailRequest",
    "SendEmailResponse",
    "BulkSmsRecipient",
    "SendBulkSmsRequest",
    "BulkSmsJobResponse",
    "NotificationLog",
    # Models — Payments
    "InitiatePaymentRequest",
    "InitiatePaymentResponse",
    "PaymentTransaction",
    "VerifyPaymentResponse",
    # Models — Identity
    "VerifyBvnRequest",
    "VerifyNinRequest",
    "VerifyPhoneRequest",
    "IdentityVerificationResponse",
    "IdentityCheck",
    # Models — VTU
    "AirtimeRequest",
    "DataRequest",
    "DataPlan",
    "ElectricityRequest",
    "CableTvRequest",
    "VtuTransactionResponse",
    "VtuTransaction",
    # Models — Reports
    "GenerateReportRequest",
    "GenerateReportResponse",
    "Report",
    # Models — Webhooks
    "CreateWebhookRequest",
    "Webhook",
    "WebhookPayload",
    # Models — Wallet
    "WalletBalance",
    "TopupRequest",
    "TopupResponse",
    # Webhook helpers
    "verify_webhook",
    "parse_webhook_payload",
    # Meta
    "__version__",
]
