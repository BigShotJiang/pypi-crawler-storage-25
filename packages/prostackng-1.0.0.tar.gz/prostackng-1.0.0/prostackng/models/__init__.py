"""
ProStack NG Python SDK — Pydantic v2 Models
"""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field


# ── Notifications ─────────────────────────────────────────────

class SendSmsRequest(BaseModel):
    to: str
    message: str
    sender_id: Optional[str] = None


class SendSmsResponse(BaseModel):
    id: str
    status: Literal["sent", "failed", "sandbox"]
    provider: str
    provider_message_id: Optional[str] = None
    cost: float
    created_at: str


class BulkSmsRecipient(BaseModel):
    to: str
    message: str


class SendBulkSmsRequest(BaseModel):
    recipients: List[BulkSmsRecipient]
    callback_url: Optional[str] = None


class BulkSmsJobResponse(BaseModel):
    job_id: str
    total: int
    status: Literal["queued", "processing", "completed", "partial"]
    sent: int
    failed: int
    pending: int
    created_at: str


class SendEmailRequest(BaseModel):
    to: str
    subject: str
    body: str
    html: Optional[str] = None
    from_name: Optional[str] = None


class SendEmailResponse(BaseModel):
    id: str
    status: Literal["sent", "failed", "sandbox"]
    provider: str
    provider_message_id: Optional[str] = None
    cost: float
    created_at: str


class NotificationLog(BaseModel):
    id: str
    type: Literal["sms", "email"]
    recipient: str
    message: str
    subject: Optional[str] = None
    status: Literal["sent", "failed", "sandbox"]
    provider: str
    cost: float
    created_at: str


# ── Payments ──────────────────────────────────────────────────

class InitiatePaymentRequest(BaseModel):
    amount: float = Field(..., gt=0)
    email: str
    reference: Optional[str] = None
    provider: Literal["paystack", "flutterwave"] = "paystack"
    metadata: Optional[Dict[str, Any]] = None


class InitiatePaymentResponse(BaseModel):
    id: str
    reference: str
    amount: float
    currency: str
    email: str
    status: Literal["pending", "success", "failed"]
    provider: str
    authorization_url: str
    created_at: str


class PaymentTransaction(BaseModel):
    id: str
    reference: str
    amount: float
    currency: str
    email: str
    status: Literal["pending", "success", "failed"]
    provider: str
    provider_ref: Optional[str] = None
    fee_charged: float
    metadata: Optional[Dict[str, Any]] = None
    created_at: str
    updated_at: str


class VerifyPaymentResponse(BaseModel):
    id: str
    reference: str
    amount: float
    status: Literal["pending", "success", "failed"]
    provider: str
    verified_at: str


# ── Identity ──────────────────────────────────────────────────

class VerifyBvnRequest(BaseModel):
    bvn: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    date_of_birth: Optional[str] = None


class VerifyNinRequest(BaseModel):
    nin: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None


class VerifyPhoneRequest(BaseModel):
    phone: str
    network: Optional[str] = None


class IdentityVerificationResponse(BaseModel):
    id: str
    check_type: Literal["bvn", "nin", "phone"]
    status: Literal["verified", "failed", "sandbox"]
    provider: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    middle_name: Optional[str] = None
    date_of_birth: Optional[str] = None
    phone_number: Optional[str] = None
    gender: Optional[str] = None
    cost: float
    created_at: str


class IdentityCheck(BaseModel):
    id: str
    check_type: Literal["bvn", "nin", "phone"]
    status: Literal["verified", "failed", "sandbox"]
    provider: str
    cost: float
    created_at: str


# ── VTU ──────────────────────────────────────────────────────

class AirtimeRequest(BaseModel):
    phone: str
    amount: float = Field(..., gt=0)
    network: str


class DataRequest(BaseModel):
    phone: str
    plan_id: str
    network: str


class ElectricityRequest(BaseModel):
    meter_number: str
    disco: str
    meter_type: str
    amount: float = Field(..., gt=0)


class CableTvRequest(BaseModel):
    decoder_number: str
    provider: str
    package: str


class VtuTransactionResponse(BaseModel):
    id: str
    type: Literal["airtime", "data", "electricity", "cable_tv"]
    status: Literal["pending", "success", "failed", "sandbox"]
    provider: str
    provider_ref: Optional[str] = None
    token: Optional[str] = None
    amount: float
    cost: float
    created_at: str


class DataPlan(BaseModel):
    id: str
    name: str
    amount: float
    validity: str


class VtuTransaction(VtuTransactionResponse):
    phone: Optional[str] = None
    network: Optional[str] = None
    meter_number: Optional[str] = None
    disco_code: Optional[str] = None


# ── Reports ───────────────────────────────────────────────────

class GenerateReportRequest(BaseModel):
    title: str
    description: Optional[str] = None
    output_format: Literal["pdf", "excel", "both"] = "pdf"
    input_format: Literal["json", "csv"] = "json"
    data: List[Dict[str, Any]]


class GenerateReportResponse(BaseModel):
    id: str
    title: str
    status: Literal["pending", "processing", "completed", "failed"]
    output_format: Literal["pdf", "excel", "both"]
    row_count: Optional[int] = None
    output_url: Optional[str] = None
    cost: float
    created_at: str


class Report(BaseModel):
    id: str
    title: str
    description: Optional[str] = None
    status: Literal["pending", "processing", "completed", "failed"]
    input_format: Literal["json", "csv"]
    output_format: Literal["pdf", "excel", "both"]
    row_count: Optional[int] = None
    page_count: Optional[int] = None
    output_url: Optional[str] = None
    cost: float
    created_at: str
    completed_at: Optional[str] = None


# ── Webhooks ──────────────────────────────────────────────────

class CreateWebhookRequest(BaseModel):
    url: str
    events: List[str]


class Webhook(BaseModel):
    id: str
    url: str
    events: List[str]
    is_active: bool
    created_at: str


class WebhookPayload(BaseModel):
    event: str
    data: Dict[str, Any]
    timestamp: str


# ── Wallet ────────────────────────────────────────────────────

class WalletBalance(BaseModel):
    balance: float
    currency: Literal["NGN"] = "NGN"


class TopupRequest(BaseModel):
    amount: float = Field(..., gt=0)
    email: str
    provider: Literal["paystack", "flutterwave"] = "paystack"


class TopupResponse(BaseModel):
    reference: str
    amount: float
    authorization_url: str
