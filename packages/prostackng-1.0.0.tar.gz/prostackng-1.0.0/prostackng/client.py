"""
ProStack NG Python SDK — Main Client
prostackng · https://prostackng.com.ng
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from ._http import DEFAULT_BASE_URL, AsyncHttpClient, SyncHttpClient
from .exceptions import (
    AuthenticationError,
    InsufficientBalanceError,
    NetworkError,
    ProStackError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .services.notifications import (
    AsyncNotificationsService,
    NotificationsService,
)
from .services.api import (
    AsyncIdentityService,
    AsyncPaymentsService,
    AsyncReportsService,
    AsyncVtuService,
    AsyncWebhooksService,
    IdentityService,
    PaymentsService,
    ReportsService,
    VtuService,
    WebhooksService,
)
from .webhook import parse_webhook_payload, verify_webhook

__all__ = [
    "ProStack",
    "AsyncProStack",
    # Errors
    "ProStackError",
    "AuthenticationError",
    "ValidationError",
    "InsufficientBalanceError",
    "RateLimitError",
    "NetworkError",
    "ServerError",
    # Webhook helpers
    "verify_webhook",
    "parse_webhook_payload",
]


class ProStack:
    """
    ProStack NG synchronous Python client.

    Use this in standard Python scripts, Django, Flask, and any
    synchronous context.

    Args:
        api_key:     Your ProStack API key (``psk_test_...`` or ``psk_live_...``).
        timeout:     Request timeout in seconds (default: 30).
        max_retries: Max retry attempts on 429/5xx errors (default: 3).
        base_url:    Override the API base URL (for testing).

    Example::

        from prostackng import ProStack

        client = ProStack(api_key="psk_live_...")

        # Send SMS
        sms = client.notifications.send_sms(
            to="08012345678",
            message="Your OTP is 4821. Valid for 5 minutes.",
        )

        # Verify BVN
        bvn = client.identity.verify_bvn(bvn="12345678901", first_name="John")

        # Initiate payment
        payment = client.payments.initiate(amount=5000, email="user@app.com")
        # Redirect user to payment.authorization_url

    Context manager (auto-closes HTTP connection pool)::

        with ProStack(api_key="psk_live_...") as client:
            result = client.vtu.buy_airtime(phone="08012345678", amount=500, network="mtn")
    """

    def __init__(
        self,
        api_key: str,
        timeout: float = 30.0,
        max_retries: int = 3,
        base_url: str = DEFAULT_BASE_URL,
    ) -> None:
        if not api_key or not isinstance(api_key, str):
            raise ValueError(
                "[prostackng] api_key is required. "
                "Get yours at https://prostack-api-dashboard.vercel.app"
            )

        self._http = SyncHttpClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )

        #: Send SMS and email notifications
        self.notifications = NotificationsService(self._http)
        #: Initiate and verify payments
        self.payments      = PaymentsService(self._http)
        #: Verify BVN, NIN, and phone numbers
        self.identity      = IdentityService(self._http)
        #: Buy airtime, data, electricity, cable TV
        self.vtu           = VtuService(self._http)
        #: Generate PDF and Excel reports
        self.reports       = ReportsService(self._http)
        #: Manage webhook endpoints
        self.webhooks      = WebhooksService(self._http)

        #: Detected environment from API key prefix
        self.environment: str = (
            "test" if api_key.startswith("psk_test_") else "live"
        )

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> "ProStack":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    @staticmethod
    def verify_webhook(payload: bytes | str, signature: str, secret: str) -> bool:
        """
        Verify a ProStack webhook signature (HMAC-SHA256).

        Always verify before processing webhook events.

        Example::

            is_valid = ProStack.verify_webhook(
                payload=request.get_data(),
                signature=request.headers["X-ProStack-Signature"],
                secret=os.environ["PROSTACK_WEBHOOK_SECRET"],
            )
        """
        return verify_webhook(payload, signature, secret)

    @staticmethod
    def parse_webhook_payload(raw_body: bytes | str) -> dict:
        """Parse a raw webhook body. Always call verify_webhook() first."""
        return parse_webhook_payload(raw_body)


class AsyncProStack:
    """
    ProStack NG async Python client.

    Use this with FastAPI, Starlette, aiohttp, and any async context.

    Args:
        api_key:     Your ProStack API key (``psk_test_...`` or ``psk_live_...``).
        timeout:     Request timeout in seconds (default: 30).
        max_retries: Max retry attempts on 429/5xx errors (default: 3).
        base_url:    Override the API base URL (for testing).

    Example::

        from prostackng import AsyncProStack

        client = AsyncProStack(api_key="psk_live_...")

        # Send SMS
        sms = await client.notifications.send_sms(
            to="08012345678",
            message="Your OTP is 4821.",
        )

        # Verify BVN
        bvn = await client.identity.verify_bvn(bvn="12345678901")

    Async context manager::

        async with AsyncProStack(api_key="psk_live_...") as client:
            payment = await client.payments.initiate(
                amount=5000, email="user@app.com"
            )

    FastAPI example::

        from fastapi import FastAPI
        from prostackng import AsyncProStack

        app = FastAPI()
        client = AsyncProStack(api_key=settings.PROSTACK_API_KEY)

        @app.post("/send-otp")
        async def send_otp(phone: str):
            result = await client.notifications.send_sms(
                to=phone,
                message="Your OTP is 4821",
            )
            return {"status": result.status}
    """

    def __init__(
        self,
        api_key: str,
        timeout: float = 30.0,
        max_retries: int = 3,
        base_url: str = DEFAULT_BASE_URL,
    ) -> None:
        if not api_key or not isinstance(api_key, str):
            raise ValueError(
                "[prostackng] api_key is required. "
                "Get yours at https://prostack-api-dashboard.vercel.app"
            )

        self._http = AsyncHttpClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )

        #: Send SMS and email notifications (async)
        self.notifications = AsyncNotificationsService(self._http)
        #: Initiate and verify payments (async)
        self.payments      = AsyncPaymentsService(self._http)
        #: Verify BVN, NIN, and phone numbers (async)
        self.identity      = AsyncIdentityService(self._http)
        #: Buy airtime, data, electricity, cable TV (async)
        self.vtu           = AsyncVtuService(self._http)
        #: Generate PDF and Excel reports (async)
        self.reports       = AsyncReportsService(self._http)
        #: Manage webhook endpoints (async)
        self.webhooks      = AsyncWebhooksService(self._http)

        self.environment: str = (
            "test" if api_key.startswith("psk_test_") else "live"
        )

    async def aclose(self) -> None:
        """Close the underlying async HTTP connection pool."""
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncProStack":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.aclose()

    @staticmethod
    def verify_webhook(payload: bytes | str, signature: str, secret: str) -> bool:
        """Verify a ProStack webhook signature. Always call before processing events."""
        return verify_webhook(payload, signature, secret)

    @staticmethod
    def parse_webhook_payload(raw_body: bytes | str) -> dict:
        """Parse a raw webhook body. Always call verify_webhook() first."""
        return parse_webhook_payload(raw_body)
