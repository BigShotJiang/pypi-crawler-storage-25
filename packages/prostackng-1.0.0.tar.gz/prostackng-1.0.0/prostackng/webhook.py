"""
ProStack NG Python SDK — Webhook Signature Verification
"""

from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any, Dict


def verify_webhook(payload: bytes | str, signature: str, secret: str) -> bool:
    """
    Verify a ProStack webhook signature using HMAC-SHA256.

    Always call this before processing any webhook event to prevent
    replay attacks and request forgery.

    Args:
        payload:   Raw request body (bytes or str). Do NOT parse JSON first.
        signature: Value of the ``X-ProStack-Signature`` header.
        secret:    Your webhook secret from the ProStack dashboard.

    Returns:
        ``True`` if the signature is valid, ``False`` otherwise.

    Example (Flask)::

        @app.route("/webhooks/prostack", methods=["POST"])
        def prostack_webhook():
            is_valid = verify_webhook(
                payload=request.get_data(),
                signature=request.headers.get("X-ProStack-Signature", ""),
                secret=os.environ["PROSTACK_WEBHOOK_SECRET"],
            )
            if not is_valid:
                return "Invalid signature", 400

            event = parse_webhook_payload(request.get_data())
            if event["event"] == "payment.success":
                pass  # fulfill order
            return "OK", 200

    Example (FastAPI)::

        @app.post("/webhooks/prostack")
        async def prostack_webhook(request: Request):
            body = await request.body()
            is_valid = verify_webhook(
                payload=body,
                signature=request.headers.get("x-prostack-signature", ""),
                secret=settings.PROSTACK_WEBHOOK_SECRET,
            )
            if not is_valid:
                raise HTTPException(status_code=400, detail="Invalid signature")
            event = parse_webhook_payload(body)
            return {"status": "ok"}
    """
    if not signature or not secret:
        return False

    if isinstance(payload, str):
        payload = payload.encode("utf-8")

    expected = hmac.new(
        secret.encode("utf-8"),
        payload,
        hashlib.sha256,
    ).hexdigest()

    # Timing-safe comparison
    return hmac.compare_digest(expected, signature.lower())


def parse_webhook_payload(raw_body: bytes | str) -> Dict[str, Any]:
    """
    Parse a raw webhook body into a dictionary.

    Always call :func:`verify_webhook` first.

    Args:
        raw_body: Raw request body (bytes or str).

    Returns:
        Parsed event dict with ``event``, ``data``, and ``timestamp`` keys.

    Example::

        event = parse_webhook_payload(request.body)
        print(event["event"])   # "payment.success"
        print(event["data"])    # {"id": "pay_123", "amount": 5000, ...}
    """
    if isinstance(raw_body, bytes):
        raw_body = raw_body.decode("utf-8")
    return json.loads(raw_body)  # type: ignore[no-any-return]
