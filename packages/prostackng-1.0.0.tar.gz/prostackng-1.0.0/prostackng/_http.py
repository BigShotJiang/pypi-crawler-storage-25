"""
ProStack NG Python SDK — HTTP Client
Sync (httpx.Client) + Async (httpx.AsyncClient), automatic retry with backoff.
"""

from __future__ import annotations

import random
import time
from typing import Any, Dict, Optional, Type, TypeVar

import httpx

from .exceptions import (
    AuthenticationError,
    InsufficientBalanceError,
    NetworkError,
    ProStackError,
    RateLimitError,
    ServerError,
    ValidationError,
)

DEFAULT_BASE_URL   = "https://prostack-api.onrender.com"
DEFAULT_TIMEOUT    = 30.0
DEFAULT_MAX_RETRIES = 3
RETRYABLE_STATUSES = {429, 500, 502, 503, 504}

T = TypeVar("T")


def _backoff_seconds(attempt: int, retry_after: Optional[int] = None) -> float:
    if retry_after:
        return float(retry_after)
    base   = 0.5 * (2 ** attempt)
    jitter = base * (random.random() * 0.2 - 0.1)
    return min(base + jitter, 30.0)


def _build_error(response: httpx.Response) -> ProStackError:
    try:
        body: Dict[str, Any] = response.json()
    except Exception:
        body = {}

    msg = body.get("message") or response.reason_phrase or "Unknown error"

    if response.status_code in (401, 403):
        return AuthenticationError(msg, response.status_code, body)
    if response.status_code == 400:
        return ValidationError(msg, body)
    if response.status_code == 402:
        return InsufficientBalanceError(
            msg,
            balance=float(body.get("balance", 0)),
            required=float(body.get("required", 0)),
            response=body,
        )
    if response.status_code == 422:
        return ValidationError(msg, body)
    if response.status_code == 429:
        retry_after = int(response.headers.get("retry-after", 60))
        return RateLimitError(msg, retry_after, body)
    if response.status_code >= 500:
        return ServerError(msg, response.status_code, body)
    return ProStackError(msg, response.status_code, body)


def _default_headers(api_key: str) -> Dict[str, str]:
    return {
        "X-API-Key":    api_key,
        "Content-Type": "application/json",
        "Accept":       "application/json",
        "User-Agent":   "prostackng-python/1.0.0",
    }


# ── Synchronous Client ────────────────────────────────────────

class SyncHttpClient:
    def __init__(self, api_key: str, base_url: str, timeout: float, max_retries: int) -> None:
        self._api_key     = api_key
        self._base_url    = base_url.rstrip("/")
        self._max_retries = max_retries
        self._client      = httpx.Client(
            base_url=self._base_url,
            headers=_default_headers(api_key),
            timeout=timeout,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "SyncHttpClient":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def request(
        self,
        method: str,
        path: str,
        body: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        last_error: Optional[ProStackError] = None

        for attempt in range(self._max_retries + 1):
            if attempt > 0:
                wait = _backoff_seconds(
                    attempt - 1,
                    last_error.retry_after if isinstance(last_error, RateLimitError) else None,
                )
                time.sleep(wait)

            try:
                resp = self._client.request(method, path, json=body)
            except httpx.TimeoutException as e:
                raise NetworkError(f"Request timed out: {e}", e) from e
            except httpx.NetworkError as e:
                raise NetworkError(f"Network error: {e}", e) from e

            if not resp.is_success:
                err = _build_error(resp)
                if resp.status_code not in RETRYABLE_STATUSES:
                    raise err
                last_error = err
                if attempt == self._max_retries:
                    raise err
                continue

            try:
                return resp.json()  # type: ignore[no-any-return]
            except Exception:
                return {}

        raise last_error or ProStackError("Request failed", 0)


# ── Asynchronous Client ───────────────────────────────────────

import asyncio  # noqa: E402


class AsyncHttpClient:
    def __init__(self, api_key: str, base_url: str, timeout: float, max_retries: int) -> None:
        self._api_key     = api_key
        self._base_url    = base_url.rstrip("/")
        self._max_retries = max_retries
        self._client      = httpx.AsyncClient(
            base_url=self._base_url,
            headers=_default_headers(api_key),
            timeout=timeout,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncHttpClient":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.aclose()

    async def request(
        self,
        method: str,
        path: str,
        body: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        last_error: Optional[ProStackError] = None

        for attempt in range(self._max_retries + 1):
            if attempt > 0:
                wait = _backoff_seconds(
                    attempt - 1,
                    last_error.retry_after if isinstance(last_error, RateLimitError) else None,
                )
                await asyncio.sleep(wait)

            try:
                resp = await self._client.request(method, path, json=body)
            except httpx.TimeoutException as e:
                raise NetworkError(f"Request timed out: {e}", e) from e
            except httpx.NetworkError as e:
                raise NetworkError(f"Network error: {e}", e) from e

            if not resp.is_success:
                err = _build_error(resp)
                if resp.status_code not in RETRYABLE_STATUSES:
                    raise err
                last_error = err
                if attempt == self._max_retries:
                    raise err
                continue

            try:
                return resp.json()  # type: ignore[no-any-return]
            except Exception:
                return {}

        raise last_error or ProStackError("Request failed", 0)
