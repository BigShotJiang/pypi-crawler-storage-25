"""Bundled skills for hyperresearch."""
