"""Core vault operations."""
