"""Knowledge graph operations."""
