"""End-to-end integration tests for DeepSeek models via the OpenAI adapter.

Tests structured output fallback behavior: DeepSeek does not support the
``json_schema`` response format, so the adapter automatically downgrades
to ``json_object`` mode.  Post-response schema validation is handled by
the executor layer.
"""

import json
import logging

import jsonschema
import pytest

from dotpromptz.typing import (
    Message,
    PromptOutputConfig,
    RenderedPrompt,
    Role,
    TextPart,
)

pytestmark = pytest.mark.integration

logger = logging.getLogger(__name__)

MODEL = 'deepseek-reasoner'


# ---------------------------------------------------------------------------
# Test 1 - basic chat completion (no structured output)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_deepseek_simple_chat(deepseek_adapter) -> None:
    """Send a simple user message to DeepSeek and verify a non-empty response."""
    rendered = RenderedPrompt(
        config={'model': MODEL, 'max_tokens': 100},
        messages=[
            Message(role=Role.USER, content=[TextPart(text='What is 2 + 3? Reply with just the number.')]),
        ],
    )

    response = await deepseek_adapter.generate(rendered)

    assert response.text is not None
    assert len(response.text.strip()) > 0
    assert '5' in response.text
    assert response.usage is not None
    assert response.usage.total_tokens > 0
    logger.info('[deepseek] simple chat response: %r', response.text)
    logger.info('[deepseek] simple chat tokens: %s', response.usage.total_tokens)


# ---------------------------------------------------------------------------
# Test 2 - JSON output without schema (json_object mode)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_deepseek_json_output_no_schema(deepseek_adapter) -> None:
    """Test JSON output format without schema (uses response_format: json_object)."""
    rendered = RenderedPrompt(
        config={'model': MODEL, 'max_tokens': 200},
        messages=[
            Message(
                role=Role.SYSTEM,
                content=[TextPart(text='You are a helpful assistant. Always respond in valid JSON.')],
            ),
            Message(
                role=Role.USER,
                content=[
                    TextPart(text='List the 3 primary colors as a JSON object with key "colors" containing an array.')
                ],
            ),
        ],
        output=PromptOutputConfig(format='json', file_name='output'),
    )

    response = await deepseek_adapter.generate(rendered)

    assert response.text is not None
    data = json.loads(response.text)
    assert 'colors' in data
    logger.info('[deepseek] json_object mode SUCCESS: %s', data)


# ---------------------------------------------------------------------------
# Test 3 - JSON output WITH schema (auto-downgraded to json_object)
# ---------------------------------------------------------------------------

_PERSON_SCHEMA = {
    'type': 'object',
    'properties': {
        'name': {'type': 'string'},
        'age': {'type': 'integer'},
        'favorite_color': {'type': 'string', 'enum': ['red', 'green', 'blue']},
    },
    'required': ['name', 'age', 'favorite_color'],
    'additionalProperties': False,
}


@pytest.mark.asyncio
async def test_deepseek_json_output_with_schema_fallback(deepseek_adapter) -> None:
    """Test that DeepSeek with schema auto-downgrades to json_object mode.

    Previously this would fail with a 400 error because DeepSeek does not
    support ``json_schema`` response format.  After the fallback, the adapter
    should use ``json_object`` mode and ``create()`` instead of ``parse()``.
    """
    rendered = RenderedPrompt(
        config={'model': MODEL, 'max_tokens': 200},
        messages=[
            Message(
                role=Role.SYSTEM,
                content=[TextPart(text='You are a data extraction assistant. Return ONLY valid JSON.')],
            ),
            Message(
                role=Role.USER,
                content=[TextPart(text='Extract person info: Alice is 30 years old and her favorite color is blue.')],
            ),
        ],
        output=PromptOutputConfig(format='json', schema_value=_PERSON_SCHEMA, file_name='output'),
    )

    # Verify the request was downgraded to json_object
    request_dict = deepseek_adapter.convert(rendered)
    response_format = request_dict.get('response_format', {})
    assert response_format.get('type') == 'json_object', f'Expected json_object fallback but got: {response_format}'
    assert 'json_schema' not in response_format
    logger.info('[deepseek] request downgraded to json_object: %s', response_format)

    # Call the real API — should succeed now
    response = await deepseek_adapter.generate(rendered)

    assert response.text is not None
    data = json.loads(response.text)
    logger.info('[deepseek] fallback response: %s', data)

    # Validate against the schema (same validation executor would do)
    jsonschema.validate(instance=data, schema=_PERSON_SCHEMA)

    assert data['name'] == 'Alice'
    assert data['age'] == 30
    assert data['favorite_color'] == 'blue'
    logger.info('[deepseek] json_schema fallback SUCCESS — response matches schema')


# ---------------------------------------------------------------------------
# Test 4 - reasoning_effort parameter
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_deepseek_reasoning_effort_param(deepseek_adapter) -> None:
    """Test whether DeepSeek handles the ``reasoning_effort`` parameter.

    DeepSeek silently ignores this parameter (does not error).
    """
    rendered = RenderedPrompt(
        config={'model': MODEL, 'thinking': 'low', 'max_tokens': 100},
        messages=[
            Message(role=Role.USER, content=[TextPart(text='What is 7 * 8? Reply with just the number.')]),
        ],
    )

    request_dict = deepseek_adapter.convert(rendered)
    reasoning_effort = request_dict.get('reasoning_effort')
    logger.info('[deepseek] reasoning_effort in request: %r', reasoning_effort)

    response = await deepseek_adapter.generate(rendered)

    assert response.text is not None
    assert '56' in response.text
    logger.info('[deepseek] reasoning_effort response: %r (param silently accepted)', response.text)


# ===========================================================================
# DeepSeek V4 Pro tests
# ===========================================================================

V4_PRO_MODEL = 'deepseek-v4-pro'


@pytest.mark.asyncio
async def test_deepseek_v4_pro_simple_chat(deepseek_v4_pro_adapter) -> None:
    """Basic chat with deepseek-v4-pro."""
    rendered = RenderedPrompt(
        config={'model': V4_PRO_MODEL, 'max_tokens': 100},
        messages=[
            Message(role=Role.USER, content=[TextPart(text='What is 2 + 3? Reply with just the number.')]),
        ],
    )

    response = await deepseek_v4_pro_adapter.generate(rendered)

    assert response.text is not None
    assert '5' in response.text
    assert response.usage is not None
    assert response.usage.total_tokens > 0
    logger.info('[deepseek-v4-pro] simple chat: %r  tokens=%s', response.text, response.usage.total_tokens)


@pytest.mark.asyncio
async def test_deepseek_v4_pro_json_no_schema(deepseek_v4_pro_adapter) -> None:
    """JSON object mode (no schema) with deepseek-v4-pro."""
    rendered = RenderedPrompt(
        config={'model': V4_PRO_MODEL, 'max_tokens': 200},
        messages=[
            Message(
                role=Role.SYSTEM,
                content=[TextPart(text='You are a helpful assistant. Always respond in valid JSON.')],
            ),
            Message(
                role=Role.USER,
                content=[
                    TextPart(text='List the 3 primary colors as a JSON object with key "colors" containing an array.')
                ],
            ),
        ],
        output=PromptOutputConfig(format='json', file_name='output'),
    )

    response = await deepseek_v4_pro_adapter.generate(rendered)

    assert response.text is not None
    data = json.loads(response.text)
    assert 'colors' in data
    logger.info('[deepseek-v4-pro] json_object: %s', data)


@pytest.mark.asyncio
async def test_deepseek_v4_pro_json_schema_fallback(deepseek_v4_pro_adapter) -> None:
    """JSON schema auto-downgrade to json_object with deepseek-v4-pro.

    Without native ``json_schema`` enforcement the model may not strictly
    conform to the schema (e.g. ``favoriteColor`` instead of
    ``favorite_color``).  The test verifies:
    1. The request is correctly downgraded to ``json_object`` mode.
    2. The API call succeeds (no 400 error).
    3. The response is valid JSON.
    """
    rendered = RenderedPrompt(
        config={'model': V4_PRO_MODEL, 'max_tokens': 200},
        messages=[
            Message(
                role=Role.SYSTEM,
                content=[TextPart(text='You are a data extraction assistant. Return ONLY valid JSON.')],
            ),
            Message(
                role=Role.USER,
                content=[TextPart(text='Extract person info: Alice is 30 years old and her favorite color is blue.')],
            ),
        ],
        output=PromptOutputConfig(format='json', schema_value=_PERSON_SCHEMA, file_name='output'),
    )

    # Verify downgrade
    request_dict = deepseek_v4_pro_adapter.convert(rendered)
    response_format = request_dict.get('response_format', {})
    assert response_format.get('type') == 'json_object'
    assert 'json_schema' not in response_format

    response = await deepseek_v4_pro_adapter.generate(rendered)

    assert response.text is not None
    data = json.loads(response.text)
    logger.info('[deepseek-v4-pro] schema fallback response: %s', data)

    # Without json_schema enforcement the model may deviate from the schema.
    # Validate and log whether the response conforms.
    try:
        jsonschema.validate(instance=data, schema=_PERSON_SCHEMA)
        logger.info('[deepseek-v4-pro] response conforms to schema')
    except jsonschema.ValidationError as exc:
        logger.warning(
            '[deepseek-v4-pro] response does NOT conform to schema (expected in json_object mode): %s',
            exc.message,
        )

    # Core assertions: the call succeeded and returned valid JSON with person data
    assert 'name' in data or 'Name' in data
    assert data.get('name', data.get('Name')) == 'Alice'
    logger.info('[deepseek-v4-pro] schema fallback completed successfully')
