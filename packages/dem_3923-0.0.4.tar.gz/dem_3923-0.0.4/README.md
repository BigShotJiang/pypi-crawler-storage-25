# dem_3923

This package stores folders `1`, `2`, and `3` from the project.

After installing it, export the folders with:

```powershell
dem-3923-export .\my_project
```
