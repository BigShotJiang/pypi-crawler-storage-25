from __future__ import annotations

import argparse
import shutil
from importlib import resources
from pathlib import Path

__all__ = ["export_folders", "get_data_path"]


def get_data_path() -> Path:
    return Path(resources.files(__name__) / "data")


def export_folders(destination: str | Path, overwrite: bool = False) -> Path:
    destination_path = Path(destination)
    destination_path.mkdir(parents=True, exist_ok=True)

    data_path = get_data_path()
    for folder_name in ("1", "2", "3"):
        source = data_path / folder_name
        target = destination_path / folder_name
        if target.exists():
            if not overwrite:
                raise FileExistsError(f"{target} already exists")
            shutil.rmtree(target)
        shutil.copytree(
            source,
            target,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"),
        )

    return destination_path


def export_folders_cli() -> None:
    parser = argparse.ArgumentParser(description="Export folders 1, 2, and 3 from dem_3923.")
    parser.add_argument("destination", help="Directory where folders will be copied.")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    print(export_folders(args.destination, overwrite=args.overwrite))
