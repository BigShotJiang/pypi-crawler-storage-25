SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS shoe_store
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE shoe_store;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS roles;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS manufacturers;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS units;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(30) NOT NULL UNIQUE,
    title VARCHAR(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_id INT NOT NULL,
    login VARCHAR(60) NOT NULL UNIQUE,
    password_hash CHAR(64) NOT NULL,
    full_name VARCHAR(160) NOT NULL,
    phone VARCHAR(30) NULL,
    email VARCHAR(120) NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_users_roles FOREIGN KEY (role_id)
        REFERENCES roles(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE manufacturers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL UNIQUE,
    phone VARCHAR(30) NULL,
    email VARCHAR(120) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE units (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE,
    short_name VARCHAR(20) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image_path VARCHAR(255) NULL,
    name VARCHAR(180) NOT NULL,
    category_id INT NOT NULL,
    description TEXT NULL,
    manufacturer_id INT NOT NULL,
    supplier_id INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    unit_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 0,
    discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_products_price CHECK (price >= 0),
    CONSTRAINT chk_products_quantity CHECK (quantity >= 0),
    CONSTRAINT chk_products_discount CHECK (discount_percent >= 0 AND discount_percent <= 100),
    CONSTRAINT fk_products_categories FOREIGN KEY (category_id)
        REFERENCES categories(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,
    CONSTRAINT fk_products_manufacturers FOREIGN KEY (manufacturer_id)
        REFERENCES manufacturers(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,
    CONSTRAINT fk_products_suppliers FOREIGN KEY (supplier_id)
        REFERENCES suppliers(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,
    CONSTRAINT fk_products_units FOREIGN KEY (unit_id)
        REFERENCES units(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    customer_name VARCHAR(160) NOT NULL,
    customer_phone VARCHAR(30) NULL,
    status ENUM('новый','в работе','завершён','отменён') NOT NULL DEFAULT 'новый',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_orders_users FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    CONSTRAINT chk_order_items_quantity CHECK (quantity > 0),
    CONSTRAINT chk_order_items_price CHECK (price >= 0),
    CONSTRAINT chk_order_items_discount CHECK (discount_percent >= 0 AND discount_percent <= 100),
    CONSTRAINT fk_order_items_orders FOREIGN KEY (order_id)
        REFERENCES orders(id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT fk_order_items_products FOREIGN KEY (product_id)
        REFERENCES products(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_products_name ON products(name);
CREATE INDEX idx_products_supplier ON products(supplier_id);
CREATE INDEX idx_products_price ON products(price);
CREATE INDEX idx_products_quantity ON products(quantity);
CREATE INDEX idx_orders_status ON orders(status);

INSERT INTO roles (id, code, title) VALUES
(1, 'client', 'Авторизованный клиент'),
(2, 'manager', 'Менеджер'),
(3, 'admin', 'Администратор')
ON DUPLICATE KEY UPDATE title = VALUES(title);

INSERT INTO users (id, role_id, login, password_hash, full_name, phone, email, active) VALUES
(1, 3, 'admin', SHA2('admin', 256), 'Администратор системы', '+7 900 000-00-01', 'admin@example.local', 1),
(2, 2, 'manager', SHA2('manager', 256), 'Менеджер магазина', '+7 900 000-00-02', 'manager@example.local', 1),
(3, 1, 'client', SHA2('client', 256), 'Авторизованный клиент', '+7 900 000-00-03', 'client@example.local', 1)
ON DUPLICATE KEY UPDATE
role_id = VALUES(role_id), password_hash = VALUES(password_hash), full_name = VALUES(full_name), active = VALUES(active);

INSERT INTO categories (id, name) VALUES
(1, 'Кроссовки'),
(2, 'Ботинки'),
(3, 'Туфли'),
(4, 'Сандалии'),
(5, 'Сапоги')
ON DUPLICATE KEY UPDATE name = VALUES(name);

INSERT INTO manufacturers (id, name) VALUES
(1, 'Северная обувная фабрика'),
(2, 'Городская линия'),
(3, 'Комфорт плюс'),
(4, 'Лёгкий шаг')
ON DUPLICATE KEY UPDATE name = VALUES(name);

INSERT INTO suppliers (id, name, phone, email) VALUES
(1, 'Поставщик Север', '+7 900 100-00-01', 'sever@example.local'),
(2, 'Поставщик Юг', '+7 900 100-00-02', 'ug@example.local'),
(3, 'Оптовый склад Обувь', '+7 900 100-00-03', 'sklad@example.local')
ON DUPLICATE KEY UPDATE phone = VALUES(phone), email = VALUES(email);

INSERT INTO units (id, name, short_name) VALUES
(1, 'Пара', 'пара'),
(2, 'Штука', 'шт.')
ON DUPLICATE KEY UPDATE short_name = VALUES(short_name);

INSERT INTO products
(id, image_path, name, category_id, description, manufacturer_id, supplier_id, price, unit_id, quantity, discount_percent)
VALUES
(1, 'resources/picture.png', 'Кроссовки прогулочные А-100', 1, 'Лёгкая повседневная обувь для города.', 2, 1, 3990.00, 1, 18, 10.00),
(2, 'resources/picture.png', 'Ботинки зимние Б-220', 2, 'Утеплённые ботинки с нескользящей подошвой.', 1, 3, 6890.00, 1, 7, 20.00),
(3, 'resources/picture.png', 'Туфли классические Т-50', 3, 'Классическая модель для офиса.', 3, 2, 4590.00, 1, 0, 5.00),
(4, 'resources/picture.png', 'Сандалии летние С-10', 4, 'Открытая летняя обувь.', 4, 1, 2390.00, 1, 25, 0.00),
(5, 'resources/picture.png', 'Сапоги демисезонные Д-300', 5, 'Демисезонная модель из искусственной кожи.', 1, 3, 5890.00, 1, 5, 18.00)
ON DUPLICATE KEY UPDATE
image_path = VALUES(image_path),
name = VALUES(name),
category_id = VALUES(category_id),
description = VALUES(description),
manufacturer_id = VALUES(manufacturer_id),
supplier_id = VALUES(supplier_id),
price = VALUES(price),
unit_id = VALUES(unit_id),
quantity = VALUES(quantity),
discount_percent = VALUES(discount_percent);

INSERT INTO orders (id, user_id, customer_name, customer_phone, status) VALUES
(1, 3, 'Авторизованный клиент', '+7 900 000-00-03', 'новый')
ON DUPLICATE KEY UPDATE status = VALUES(status), customer_name = VALUES(customer_name), customer_phone = VALUES(customer_phone);

INSERT INTO order_items (id, order_id, product_id, quantity, price, discount_percent) VALUES
(1, 1, 2, 1, 6890.00, 20.00)
ON DUPLICATE KEY UPDATE quantity = VALUES(quantity), price = VALUES(price), discount_percent = VALUES(discount_percent);
