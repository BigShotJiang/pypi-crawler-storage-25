import argparse
from pathlib import Path

import pandas as pd
import pymysql

DB_CONFIG = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "root",
    "password": "",
    "database": "shoe_store",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor,
}

DEFAULT_IMAGE = "resources/picture.png"

COLUMN_ALIASES = {
    "image_path": ["image_path", "фото", "путь к фото", "изображение"],
    "name": ["name", "наименование", "товар", "наименование товара"],
    "category": ["category", "категория", "категория товара"],
    "description": ["description", "описание", "описание товара"],
    "manufacturer": ["manufacturer", "производитель"],
    "supplier": ["supplier", "поставщик"],
    "price": ["price", "цена", "стоимость"],
    "unit": ["unit", "единица", "единица измерения"],
    "quantity": ["quantity", "количество", "количество на складе", "остаток"],
    "discount_percent": ["discount_percent", "discount", "скидка", "действующая скидка"],
    "phone": ["phone", "телефон"],
    "email": ["email", "почта", "электронная почта"],
}


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    mapping = {}
    normalized = {str(col).strip().lower(): col for col in df.columns}
    for target, aliases in COLUMN_ALIASES.items():
        for alias in aliases:
            key = alias.strip().lower()
            if key in normalized:
                mapping[normalized[key]] = target
                break
    return df.rename(columns=mapping)


def value_or_none(value):
    if pd.isna(value):
        return None
    text = str(value).strip()
    return text if text else None


def decimal_value(value, default=0):
    if pd.isna(value) or str(value).strip() == "":
        return default
    return float(str(value).replace(",", "."))


def int_value(value, default=0):
    if pd.isna(value) or str(value).strip() == "":
        return default
    return int(float(str(value).replace(",", ".")))


def get_connection():
    return pymysql.connect(**DB_CONFIG)


def get_or_create(cursor, table, name, extra=None):
    name = (name or "").strip()
    if not name:
        raise ValueError(f"Пустое значение справочника {table}")
    cursor.execute(f"SELECT id FROM {table} WHERE name=%s", (name,))
    row = cursor.fetchone()
    if row:
        return row["id"]
    if table == "suppliers":
        cursor.execute(
            "INSERT INTO suppliers (name, phone, email) VALUES (%s,%s,%s)",
            (name, (extra or {}).get("phone"), (extra or {}).get("email")),
        )
    elif table == "units":
        cursor.execute("INSERT INTO units (name, short_name) VALUES (%s,%s)", (name, name[:20]))
    else:
        cursor.execute(f"INSERT INTO {table} (name) VALUES (%s)", (name,))
    return cursor.lastrowid


def import_lookup_sheet(cursor, df, table):
    df = normalize_columns(df)
    if "name" not in df.columns:
        raise ValueError(f"В листе для {table} нет столбца name или Наименование")
    count = 0
    for _, row in df.iterrows():
        name = value_or_none(row.get("name"))
        if not name:
            continue
        if table == "suppliers":
            phone = value_or_none(row.get("phone"))
            email = value_or_none(row.get("email"))
            cursor.execute(
                """
                INSERT INTO suppliers (name, phone, email)
                VALUES (%s,%s,%s)
                ON DUPLICATE KEY UPDATE phone=VALUES(phone), email=VALUES(email)
                """,
                (name, phone, email),
            )
        elif table == "units":
            cursor.execute(
                """
                INSERT INTO units (name, short_name)
                VALUES (%s,%s)
                ON DUPLICATE KEY UPDATE short_name=VALUES(short_name)
                """,
                (name, name[:20]),
            )
        else:
            cursor.execute(f"INSERT IGNORE INTO {table} (name) VALUES (%s)", (name,))
        count += 1
    return count


def import_products_sheet(cursor, df):
    df = normalize_columns(df)
    required = ["name", "category", "manufacturer", "supplier", "price"]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError("В листе товаров нет обязательных столбцов: " + ", ".join(missing))
    count = 0
    for _, row in df.iterrows():
        name = value_or_none(row.get("name"))
        if not name:
            continue
        category_id = get_or_create(cursor, "categories", value_or_none(row.get("category")))
        manufacturer_id = get_or_create(cursor, "manufacturers", value_or_none(row.get("manufacturer")))
        supplier_id = get_or_create(cursor, "suppliers", value_or_none(row.get("supplier")))
        unit_name = value_or_none(row.get("unit")) or "Пара"
        unit_id = get_or_create(cursor, "units", unit_name)
        cursor.execute(
            """
            INSERT INTO products
            (image_path, name, category_id, description, manufacturer_id, supplier_id, price, unit_id, quantity, discount_percent)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """,
            (
                value_or_none(row.get("image_path")) or DEFAULT_IMAGE,
                name,
                category_id,
                value_or_none(row.get("description")),
                manufacturer_id,
                supplier_id,
                decimal_value(row.get("price")),
                unit_id,
                int_value(row.get("quantity")),
                decimal_value(row.get("discount_percent")),
            ),
        )
        count += 1
    return count


def read_source(path: Path):
    suffix = path.suffix.lower()
    if suffix in (".xlsx", ".xls", ".xlsm", ".ods"):
        return pd.read_excel(path, sheet_name=None)
    if suffix == ".csv":
        return {"Товары": pd.read_csv(path, sep=None, engine="python")}
    raise ValueError("Поддерживаются файлы .xlsx, .xls, .xlsm, .ods и .csv")


def main():
    parser = argparse.ArgumentParser(description="Импорт данных ООО «Обувь» из Excel или CSV в MySQL.")
    parser.add_argument("file", help="Путь к файлу импорта")
    args = parser.parse_args()
    path = Path(args.file)
    if not path.exists():
        raise FileNotFoundError(f"Файл не найден: {path}")

    sheets = read_source(path)
    conn = get_connection()
    totals = {}
    try:
        with conn.cursor() as cursor:
            for sheet_name, df in sheets.items():
                key = sheet_name.strip().lower()
                if key in ("categories", "категории"):
                    totals[sheet_name] = import_lookup_sheet(cursor, df, "categories")
                elif key in ("manufacturers", "производители"):
                    totals[sheet_name] = import_lookup_sheet(cursor, df, "manufacturers")
                elif key in ("suppliers", "поставщики"):
                    totals[sheet_name] = import_lookup_sheet(cursor, df, "suppliers")
                elif key in ("units", "единицы", "единицы измерения"):
                    totals[sheet_name] = import_lookup_sheet(cursor, df, "units")
                elif key in ("products", "товары", "import"):
                    totals[sheet_name] = import_products_sheet(cursor, df)
            conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    if not totals:
        print("Подходящие листы не найдены. Используйте лист Товары или import.")
    else:
        for sheet_name, count in totals.items():
            print(f"{sheet_name}: импортировано строк {count}")


if __name__ == "__main__":
    main()
