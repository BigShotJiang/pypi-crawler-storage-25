import hashlib
import os
import shutil
import sys
from decimal import Decimal
from pathlib import Path

import pymysql
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QColor, QFont, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QAbstractItemView,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QToolBar,
    QVBoxLayout,
    QWidget,
)

APP_DIR = Path(__file__).resolve().parent
PLACEHOLDER_IMAGE = APP_DIR / "resources" / "picture.png"
PRODUCT_IMAGES_DIR = APP_DIR / "resources" / "products"
PRODUCT_IMAGES_DIR.mkdir(parents=True, exist_ok=True)

DB_CONFIG = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "root",
    "password": "",
    "database": "shoe_store",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor,
}

ROLE_TITLES = {
    "guest": "Гость",
    "client": "Авторизованный клиент",
    "manager": "Менеджер",
    "admin": "Администратор",
}


def get_connection():
    return pymysql.connect(**DB_CONFIG)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def run_fetch_all(sql: str, params=None):
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(sql, params or ())
            return cursor.fetchall()
    finally:
        conn.close()


def run_fetch_one(sql: str, params=None):
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(sql, params or ())
            return cursor.fetchone()
    finally:
        conn.close()


def show_error(parent, text: str):
    QMessageBox.critical(parent, "Ошибка", text)


def show_info(parent, text: str):
    QMessageBox.information(parent, "Информация", text)


def show_warning(parent, text: str):
    QMessageBox.warning(parent, "Предупреждение", text)


def money(value) -> str:
    return f"{Decimal(str(value)):.2f}"


def product_final_price(price, discount_percent) -> Decimal:
    price_dec = Decimal(str(price))
    discount_dec = Decimal(str(discount_percent))
    return (price_dec * (Decimal("100") - discount_dec) / Decimal("100")).quantize(Decimal("0.01"))


def resolve_image_path(image_path: str | None) -> Path:
    if not image_path:
        return PLACEHOLDER_IMAGE
    path = Path(image_path)
    if path.is_absolute():
        return path
    return APP_DIR / path


def relative_app_path(path: Path) -> str:
    return str(path.resolve().relative_to(APP_DIR)).replace("\\", "/")


def save_product_image(source_path: str, product_id: int) -> str:
    pixmap = QPixmap(source_path)
    if pixmap.isNull():
        raise ValueError("Не удалось открыть выбранное изображение.")
    result_path = PRODUCT_IMAGES_DIR / f"product_{product_id}.png"
    scaled = pixmap.scaled(300, 200, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation)
    if not scaled.save(str(result_path), "PNG"):
        raise ValueError("Не удалось сохранить изображение товара.")
    return relative_app_path(result_path)


def delete_product_image_if_local(image_path: str | None):
    if not image_path or image_path == "resources/picture.png":
        return
    path = resolve_image_path(image_path)
    try:
        if path.exists() and path.resolve().is_relative_to(PRODUCT_IMAGES_DIR.resolve()):
            path.unlink()
    except OSError:
        pass


def load_lookup(table_name: str, label_field: str = "name"):
    return run_fetch_all(f"SELECT id, {label_field} AS title FROM {table_name} ORDER BY {label_field}")


def fill_combo(combo: QComboBox, rows, include_empty=False, empty_text=""):
    combo.clear()
    if include_empty:
        combo.addItem(empty_text, None)
    for row in rows:
        combo.addItem(str(row["title"]), row["id"])


def set_combo_value(combo: QComboBox, value):
    index = combo.findData(value)
    if index >= 0:
        combo.setCurrentIndex(index)


class LoginWindow(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Вход")
        self.setMinimumWidth(360)
        self.main_window = None

        layout = QVBoxLayout(self)
        title = QLabel("ООО «Обувь»")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size: 20px; font-weight: 600;")
        layout.addWidget(title)

        form = QFormLayout()
        self.login_edit = QLineEdit()
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        form.addRow("Логин", self.login_edit)
        form.addRow("Пароль", self.password_edit)
        layout.addLayout(form)

        buttons = QHBoxLayout()
        self.login_button = QPushButton("Войти")
        self.guest_button = QPushButton("Войти как гость")
        buttons.addWidget(self.login_button)
        buttons.addWidget(self.guest_button)
        layout.addLayout(buttons)

        hint = QLabel("Тестовые учётные записи: admin/admin, manager/manager, client/client")
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #555;")
        layout.addWidget(hint)

        self.login_button.clicked.connect(self.try_login)
        self.guest_button.clicked.connect(self.login_as_guest)
        self.password_edit.returnPressed.connect(self.try_login)

    def try_login(self):
        login = self.login_edit.text().strip()
        password = self.password_edit.text()
        if not login or not password:
            show_warning(self, "Введите логин и пароль.")
            return
        try:
            user = run_fetch_one(
                """
                SELECT u.id, u.login, u.full_name, r.code AS role_code, r.title AS role_title
                FROM users u
                JOIN roles r ON r.id = u.role_id
                WHERE u.login = %s AND u.password_hash = %s AND u.active = 1
                """,
                (login, sha256_text(password)),
            )
        except Exception as exc:
            show_error(self, f"Не удалось подключиться к базе данных. Проверьте настройки DB_CONFIG и импорт SQL-файла.\n\n{exc}")
            return
        if not user:
            show_warning(self, "Неверный логин или пароль.")
            return
        self.open_main_window(user)

    def login_as_guest(self):
        self.open_main_window({"id": None, "login": "guest", "full_name": "Гость", "role_code": "guest", "role_title": "Гость"})

    def open_main_window(self, user):
        self.main_window = MainWindow(user, self)
        self.main_window.show()
        self.hide()


class MainWindow(QMainWindow):
    def __init__(self, user, login_window: LoginWindow):
        super().__init__()
        self.user = user
        self.login_window = login_window
        self.setWindowTitle("ООО «Обувь»")
        self.resize(1200, 720)

        toolbar = QToolBar()
        self.addToolBar(toolbar)
        role_text = ROLE_TITLES.get(user["role_code"], user.get("role_title", ""))
        toolbar.addWidget(QLabel(f"Пользователь: {user['full_name']} | Роль: {role_text}"))
        toolbar.addSeparator()
        logout_action = QAction("Выйти", self)
        logout_action.triggered.connect(self.logout)
        toolbar.addAction(logout_action)

        tabs = QTabWidget()
        tabs.addTab(ProductsPage(user), "Товары")
        if user["role_code"] in ("manager", "admin"):
            tabs.addTab(OrdersPage(user), "Заказы")
        self.setCentralWidget(tabs)

    def logout(self):
        self.close()
        self.login_window.login_edit.clear()
        self.login_window.password_edit.clear()
        self.login_window.show()

    def closeEvent(self, event):
        if not self.login_window.isVisible():
            self.login_window.close()
        super().closeEvent(event)


class ProductsPage(QWidget):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.products = []
        self.edit_dialog = None

        layout = QVBoxLayout(self)
        role = user["role_code"]

        self.filter_panel = QWidget()
        filter_layout = QHBoxLayout(self.filter_panel)
        filter_layout.setContentsMargins(0, 0, 0, 0)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Поиск по товарам, описанию, категории, производителю, поставщику")
        self.supplier_combo = QComboBox()
        self.sort_combo = QComboBox()
        self.sort_combo.addItems([
            "Без сортировки",
            "Цена по возрастанию",
            "Цена по убыванию",
            "Количество по возрастанию",
            "Количество по убыванию",
        ])
        filter_layout.addWidget(QLabel("Поиск"))
        filter_layout.addWidget(self.search_edit, 2)
        filter_layout.addWidget(QLabel("Поставщик"))
        filter_layout.addWidget(self.supplier_combo, 1)
        filter_layout.addWidget(QLabel("Сортировка"))
        filter_layout.addWidget(self.sort_combo, 1)
        layout.addWidget(self.filter_panel)
        self.filter_panel.setVisible(role in ("manager", "admin"))

        button_panel = QWidget()
        button_layout = QHBoxLayout(button_panel)
        button_layout.setContentsMargins(0, 0, 0, 0)
        self.add_button = QPushButton("Добавить")
        self.edit_button = QPushButton("Редактировать")
        self.delete_button = QPushButton("Удалить")
        button_layout.addWidget(self.add_button)
        button_layout.addWidget(self.edit_button)
        button_layout.addWidget(self.delete_button)
        button_layout.addStretch()
        layout.addWidget(button_panel)
        button_panel.setVisible(role == "admin")

        self.table = QTableWidget(0, 9)
        self.table.setHorizontalHeaderLabels([
            "Фото",
            "Категория | Наименование",
            "Описание",
            "Производитель",
            "Поставщик",
            "Цена",
            "Ед.",
            "Склад",
            "Скидка",
        ])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        layout.addWidget(self.table)

        self.search_edit.textChanged.connect(self.load_products)
        self.supplier_combo.currentIndexChanged.connect(self.load_products)
        self.sort_combo.currentIndexChanged.connect(self.load_products)
        self.add_button.clicked.connect(self.open_add_product)
        self.edit_button.clicked.connect(self.open_edit_product)
        self.delete_button.clicked.connect(self.delete_selected_product)
        self.table.doubleClicked.connect(self.open_edit_product)

        self.load_suppliers()
        self.load_products()

    def load_suppliers(self):
        if self.user["role_code"] not in ("manager", "admin"):
            return
        selected = self.supplier_combo.currentData()
        self.supplier_combo.blockSignals(True)
        try:
            fill_combo(self.supplier_combo, load_lookup("suppliers"), include_empty=True, empty_text="Все поставщики")
            set_combo_value(self.supplier_combo, selected)
        except Exception as exc:
            show_error(self, f"Не удалось загрузить список поставщиков.\n\n{exc}")
        finally:
            self.supplier_combo.blockSignals(False)

    def product_query(self):
        sql = """
            SELECT
                p.id, p.image_path, p.name, p.description, p.price, p.quantity, p.discount_percent,
                p.category_id, c.name AS category,
                p.manufacturer_id, m.name AS manufacturer,
                p.supplier_id, s.name AS supplier,
                p.unit_id, u.short_name AS unit
            FROM products p
            JOIN categories c ON c.id = p.category_id
            JOIN manufacturers m ON m.id = p.manufacturer_id
            JOIN suppliers s ON s.id = p.supplier_id
            JOIN units u ON u.id = p.unit_id
        """
        params = []
        where = []
        if self.user["role_code"] in ("manager", "admin"):
            search = self.search_edit.text().strip()
            if search:
                where.append("(p.name LIKE %s OR p.description LIKE %s OR c.name LIKE %s OR m.name LIKE %s OR s.name LIKE %s)")
                params.extend([f"%{search}%"] * 5)
            supplier_id = self.supplier_combo.currentData()
            if supplier_id:
                where.append("p.supplier_id = %s")
                params.append(supplier_id)
        if where:
            sql += " WHERE " + " AND ".join(where)
        sort_text = self.sort_combo.currentText() if self.user["role_code"] in ("manager", "admin") else ""
        order_by = {
            "Цена по возрастанию": "p.price ASC, p.name ASC",
            "Цена по убыванию": "p.price DESC, p.name ASC",
            "Количество по возрастанию": "p.quantity ASC, p.name ASC",
            "Количество по убыванию": "p.quantity DESC, p.name ASC",
        }.get(sort_text, "p.name ASC")
        sql += f" ORDER BY {order_by}"
        return sql, params

    def load_products(self):
        try:
            sql, params = self.product_query()
            self.products = run_fetch_all(sql, params)
        except Exception as exc:
            show_error(self, f"Не удалось загрузить товары.\n\n{exc}")
            return
        self.table.setRowCount(0)
        for row_index, product in enumerate(self.products):
            self.table.insertRow(row_index)
            self.table.setRowHeight(row_index, 78)
            self.fill_product_row(row_index, product)

    def row_background(self, product):
        if int(product["quantity"]) == 0:
            return QColor("#ADD8E6")
        if Decimal(str(product["discount_percent"])) > Decimal("15"):
            return QColor("#2E8B57")
        return QColor("#FFFFFF")

    def set_table_item(self, row, column, text, background):
        item = QTableWidgetItem(str(text))
        item.setBackground(background)
        if background.name().lower() == "#2e8b57":
            item.setForeground(QColor("#ffffff"))
        item.setData(Qt.ItemDataRole.UserRole, self.products[row]["id"])
        self.table.setItem(row, column, item)
        return item

    def fill_product_row(self, row, product):
        background = self.row_background(product)
        image_label = QLabel()
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        image_label.setStyleSheet(f"background-color: {background.name()};")
        pixmap = QPixmap(str(resolve_image_path(product.get("image_path"))))
        if pixmap.isNull():
            pixmap = QPixmap(str(PLACEHOLDER_IMAGE))
        image_label.setPixmap(pixmap.scaled(72, 52, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        self.table.setCellWidget(row, 0, image_label)
        self.set_table_item(row, 1, f"{product['category']} | {product['name']}", background)
        self.set_table_item(row, 2, product.get("description") or "", background)
        self.set_table_item(row, 3, product["manufacturer"], background)
        self.set_table_item(row, 4, product["supplier"], background)

        price_label = QLabel()
        price_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        price_label.setStyleSheet(f"background-color: {background.name()};")
        price = Decimal(str(product["price"]))
        discount = Decimal(str(product["discount_percent"]))
        if discount > 0:
            final_price = product_final_price(price, discount)
            price_label.setText(
                f"<span style='color:#cc0000; text-decoration: line-through;'>{money(price)}</span><br>"
                f"<span style='color:#000000;'>{money(final_price)}</span>"
            )
        else:
            price_label.setText(money(price))
        self.table.setCellWidget(row, 5, price_label)

        self.set_table_item(row, 6, product["unit"], background)
        quantity_item = self.set_table_item(row, 7, product["quantity"], background)
        quantity_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        discount_item = self.set_table_item(row, 8, f"{money(discount)}%", background)
        discount_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)

    def selected_product(self):
        selected = self.table.selectionModel().selectedRows()
        if not selected:
            show_warning(self, "Выберите товар.")
            return None
        return self.products[selected[0].row()]

    def open_add_product(self):
        if self.user["role_code"] != "admin":
            return
        self.open_product_dialog(None)

    def open_edit_product(self):
        if self.user["role_code"] != "admin":
            return
        product = self.selected_product()
        if not product:
            return
        try:
            full_product = run_fetch_one("SELECT * FROM products WHERE id = %s", (product["id"],))
        except Exception as exc:
            show_error(self, f"Не удалось открыть товар.\n\n{exc}")
            return
        self.open_product_dialog(full_product)

    def open_product_dialog(self, product):
        if self.edit_dialog is not None and self.edit_dialog.isVisible():
            self.edit_dialog.raise_()
            self.edit_dialog.activateWindow()
            show_warning(self, "Уже открыто окно добавления или редактирования товара.")
            return
        self.edit_dialog = ProductDialog(product, self)
        self.edit_dialog.finished.connect(lambda _: setattr(self, "edit_dialog", None))
        self.edit_dialog.saved.connect(self.after_product_saved)
        self.edit_dialog.show()

    def after_product_saved(self):
        self.load_suppliers()
        self.load_products()

    def delete_selected_product(self):
        if self.user["role_code"] != "admin":
            return
        product = self.selected_product()
        if not product:
            return
        try:
            usage = run_fetch_one("SELECT COUNT(*) AS cnt FROM order_items WHERE product_id = %s", (product["id"],))["cnt"]
        except Exception as exc:
            show_error(self, f"Не удалось проверить товар перед удалением.\n\n{exc}")
            return
        if usage > 0:
            show_warning(self, "Товар присутствует в заказе. Удаление запрещено.")
            return
        answer = QMessageBox.question(
            self,
            "Подтверждение удаления",
            "Удаление товара необратимо. Удалить выбранный товар?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        conn = get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT image_path FROM products WHERE id = %s", (product["id"],))
                image_row = cursor.fetchone()
                cursor.execute("DELETE FROM products WHERE id = %s", (product["id"],))
            conn.commit()
            if image_row:
                delete_product_image_if_local(image_row.get("image_path"))
            self.load_products()
            show_info(self, "Товар удалён.")
        except Exception as exc:
            conn.rollback()
            show_error(self, f"Не удалось удалить товар.\n\n{exc}")
        finally:
            conn.close()


class ProductDialog(QDialog):
    from PySide6.QtCore import Signal
    saved = Signal()

    def __init__(self, product, parent=None):
        super().__init__(parent)
        self.product = product
        self.selected_image_source = None
        self.setWindowTitle("Редактирование товара" if product else "Добавление товара")
        self.setMinimumWidth(620)

        layout = QVBoxLayout(self)
        form = QFormLayout()

        if product:
            self.id_label = QLabel(str(product["id"]))
            form.addRow("ID", self.id_label)

        self.image_preview = QLabel()
        self.image_preview.setFixedSize(300, 200)
        self.image_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_preview.setStyleSheet("border: 1px solid #999;")
        self.choose_image_button = QPushButton("Выбрать изображение")
        image_box = QHBoxLayout()
        image_box.addWidget(self.image_preview)
        image_box.addWidget(self.choose_image_button)
        image_box.addStretch()
        form.addRow("Фото", image_box)

        self.name_edit = QLineEdit()
        self.category_combo = QComboBox()
        self.description_edit = QTextEdit()
        self.description_edit.setFixedHeight(80)
        self.manufacturer_combo = QComboBox()
        self.supplier_combo = QComboBox()
        self.price_spin = QDoubleSpinBox()
        self.price_spin.setMaximum(99999999.99)
        self.price_spin.setDecimals(2)
        self.price_spin.setSingleStep(100.0)
        self.unit_combo = QComboBox()
        self.quantity_spin = QSpinBox()
        self.quantity_spin.setMaximum(1000000)
        self.discount_spin = QDoubleSpinBox()
        self.discount_spin.setRange(0.0, 100.0)
        self.discount_spin.setDecimals(2)

        form.addRow("Наименование", self.name_edit)
        form.addRow("Категория", self.category_combo)
        form.addRow("Описание", self.description_edit)
        form.addRow("Производитель", self.manufacturer_combo)
        form.addRow("Поставщик", self.supplier_combo)
        form.addRow("Цена", self.price_spin)
        form.addRow("Единица измерения", self.unit_combo)
        form.addRow("Количество на складе", self.quantity_spin)
        form.addRow("Действующая скидка, %", self.discount_spin)
        layout.addLayout(form)

        self.button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        self.button_box.button(QDialogButtonBox.StandardButton.Save).setText("Сохранить")
        self.button_box.button(QDialogButtonBox.StandardButton.Cancel).setText("Отмена")
        layout.addWidget(self.button_box)

        self.choose_image_button.clicked.connect(self.choose_image)
        self.button_box.accepted.connect(self.save)
        self.button_box.rejected.connect(self.reject)

        self.load_combos()
        self.load_product_values()

    def load_combos(self):
        try:
            fill_combo(self.category_combo, load_lookup("categories"))
            fill_combo(self.manufacturer_combo, load_lookup("manufacturers"))
            fill_combo(self.supplier_combo, load_lookup("suppliers"))
            rows = run_fetch_all("SELECT id, CONCAT(name, ' (', short_name, ')') AS title FROM units ORDER BY name")
            fill_combo(self.unit_combo, rows)
        except Exception as exc:
            show_error(self, f"Не удалось загрузить справочники.\n\n{exc}")

    def load_product_values(self):
        product = self.product
        image_path = product.get("image_path") if product else "resources/picture.png"
        self.set_preview(resolve_image_path(image_path))
        if not product:
            return
        self.name_edit.setText(product.get("name") or "")
        self.description_edit.setPlainText(product.get("description") or "")
        set_combo_value(self.category_combo, product.get("category_id"))
        set_combo_value(self.manufacturer_combo, product.get("manufacturer_id"))
        set_combo_value(self.supplier_combo, product.get("supplier_id"))
        set_combo_value(self.unit_combo, product.get("unit_id"))
        self.price_spin.setValue(float(product.get("price") or 0))
        self.quantity_spin.setValue(int(product.get("quantity") or 0))
        self.discount_spin.setValue(float(product.get("discount_percent") or 0))

    def set_preview(self, path: Path):
        pixmap = QPixmap(str(path))
        if pixmap.isNull():
            pixmap = QPixmap(str(PLACEHOLDER_IMAGE))
        self.image_preview.setPixmap(pixmap.scaled(300, 200, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def choose_image(self):
        path, _ = QFileDialog.getOpenFileName(self, "Выберите изображение", "", "Изображения (*.png *.jpg *.jpeg *.bmp)")
        if not path:
            return
        self.selected_image_source = path
        self.set_preview(Path(path))

    def collect_data(self):
        name = self.name_edit.text().strip()
        if not name:
            raise ValueError("Введите наименование товара.")
        if self.category_combo.currentData() is None:
            raise ValueError("Выберите категорию товара.")
        if self.manufacturer_combo.currentData() is None:
            raise ValueError("Выберите производителя.")
        if self.supplier_combo.currentData() is None:
            raise ValueError("Выберите поставщика.")
        if self.unit_combo.currentData() is None:
            raise ValueError("Выберите единицу измерения.")
        return {
            "name": name,
            "category_id": self.category_combo.currentData(),
            "description": self.description_edit.toPlainText().strip(),
            "manufacturer_id": self.manufacturer_combo.currentData(),
            "supplier_id": self.supplier_combo.currentData(),
            "price": self.price_spin.value(),
            "unit_id": self.unit_combo.currentData(),
            "quantity": self.quantity_spin.value(),
            "discount_percent": self.discount_spin.value(),
        }

    def save(self):
        try:
            data = self.collect_data()
        except ValueError as exc:
            show_warning(self, str(exc))
            return

        conn = get_connection()
        old_image_path = self.product.get("image_path") if self.product else None
        new_image_path = old_image_path or "resources/picture.png"
        try:
            with conn.cursor() as cursor:
                if self.product:
                    product_id = self.product["id"]
                    if self.selected_image_source:
                        new_image_path = save_product_image(self.selected_image_source, product_id)
                    cursor.execute(
                        """
                        UPDATE products
                        SET image_path=%s, name=%s, category_id=%s, description=%s, manufacturer_id=%s,
                            supplier_id=%s, price=%s, unit_id=%s, quantity=%s, discount_percent=%s
                        WHERE id=%s
                        """,
                        (
                            new_image_path,
                            data["name"],
                            data["category_id"],
                            data["description"],
                            data["manufacturer_id"],
                            data["supplier_id"],
                            data["price"],
                            data["unit_id"],
                            data["quantity"],
                            data["discount_percent"],
                            product_id,
                        ),
                    )
                else:
                    cursor.execute(
                        """
                        INSERT INTO products
                        (image_path, name, category_id, description, manufacturer_id, supplier_id, price, unit_id, quantity, discount_percent)
                        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                        """,
                        (
                            "resources/picture.png",
                            data["name"],
                            data["category_id"],
                            data["description"],
                            data["manufacturer_id"],
                            data["supplier_id"],
                            data["price"],
                            data["unit_id"],
                            data["quantity"],
                            data["discount_percent"],
                        ),
                    )
                    product_id = cursor.lastrowid
                    if self.selected_image_source:
                        new_image_path = save_product_image(self.selected_image_source, product_id)
                        cursor.execute("UPDATE products SET image_path=%s WHERE id=%s", (new_image_path, product_id))
            conn.commit()
            if old_image_path and self.selected_image_source and old_image_path != new_image_path:
                delete_product_image_if_local(old_image_path)
            self.saved.emit()
            show_info(self, "Данные товара сохранены.")
            self.accept()
        except Exception as exc:
            conn.rollback()
            show_error(self, f"Не удалось сохранить товар.\n\n{exc}")
        finally:
            conn.close()


class OrdersPage(QWidget):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.orders = []
        self.dialog = None

        layout = QVBoxLayout(self)
        button_panel = QWidget()
        button_layout = QHBoxLayout(button_panel)
        button_layout.setContentsMargins(0, 0, 0, 0)
        self.add_button = QPushButton("Добавить")
        self.edit_button = QPushButton("Редактировать")
        self.delete_button = QPushButton("Удалить")
        button_layout.addWidget(self.add_button)
        button_layout.addWidget(self.edit_button)
        button_layout.addWidget(self.delete_button)
        button_layout.addStretch()
        layout.addWidget(button_panel)
        button_panel.setVisible(user["role_code"] == "admin")

        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(["ID", "Клиент", "Телефон", "Статус", "Дата", "Позиций", "Сумма"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(6, QHeaderView.ResizeMode.ResizeToContents)
        layout.addWidget(self.table)

        self.add_button.clicked.connect(self.open_add_order)
        self.edit_button.clicked.connect(self.open_edit_order)
        self.delete_button.clicked.connect(self.delete_order)
        self.table.doubleClicked.connect(self.open_order_by_role)
        self.load_orders()

    def load_orders(self):
        try:
            self.orders = run_fetch_all(
                """
                SELECT o.id, o.customer_name, o.customer_phone, o.status, o.created_at,
                       COUNT(oi.id) AS items_count,
                       COALESCE(SUM(oi.quantity * oi.price * (100 - oi.discount_percent) / 100), 0) AS total
                FROM orders o
                LEFT JOIN order_items oi ON oi.order_id = o.id
                GROUP BY o.id, o.customer_name, o.customer_phone, o.status, o.created_at
                ORDER BY o.created_at DESC, o.id DESC
                """
            )
        except Exception as exc:
            show_error(self, f"Не удалось загрузить заказы.\n\n{exc}")
            return
        self.table.setRowCount(0)
        for row, order in enumerate(self.orders):
            self.table.insertRow(row)
            values = [
                order["id"],
                order["customer_name"],
                order.get("customer_phone") or "",
                order["status"],
                str(order["created_at"]),
                order["items_count"],
                money(order["total"]),
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.ItemDataRole.UserRole, order["id"])
                if column in (0, 5, 6):
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.table.setItem(row, column, item)

    def selected_order(self):
        selected = self.table.selectionModel().selectedRows()
        if not selected:
            show_warning(self, "Выберите заказ.")
            return None
        return self.orders[selected[0].row()]

    def open_order_by_role(self):
        if self.user["role_code"] == "admin":
            self.open_edit_order()
        else:
            order = self.selected_order()
            if order:
                self.open_order_dialog(order["id"], read_only=True)

    def open_add_order(self):
        if self.user["role_code"] == "admin":
            self.open_order_dialog(None, read_only=False)

    def open_edit_order(self):
        if self.user["role_code"] != "admin":
            return
        order = self.selected_order()
        if order:
            self.open_order_dialog(order["id"], read_only=False)

    def open_order_dialog(self, order_id, read_only):
        if self.dialog is not None and self.dialog.isVisible():
            self.dialog.raise_()
            self.dialog.activateWindow()
            show_warning(self, "Уже открыто окно заказа.")
            return
        self.dialog = OrderDialog(order_id, read_only, self)
        self.dialog.finished.connect(lambda _: setattr(self, "dialog", None))
        self.dialog.saved.connect(self.load_orders)
        self.dialog.show()

    def delete_order(self):
        if self.user["role_code"] != "admin":
            return
        order = self.selected_order()
        if not order:
            return
        answer = QMessageBox.question(
            self,
            "Подтверждение удаления",
            "Удаление заказа необратимо. Удалить выбранный заказ?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        conn = get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("DELETE FROM orders WHERE id=%s", (order["id"],))
            conn.commit()
            self.load_orders()
            show_info(self, "Заказ удалён.")
        except Exception as exc:
            conn.rollback()
            show_error(self, f"Не удалось удалить заказ.\n\n{exc}")
        finally:
            conn.close()


class OrderDialog(QDialog):
    from PySide6.QtCore import Signal
    saved = Signal()

    def __init__(self, order_id=None, read_only=False, parent=None):
        super().__init__(parent)
        self.order_id = order_id
        self.read_only = read_only
        self.items = []
        self.setWindowTitle("Просмотр заказа" if read_only else ("Редактирование заказа" if order_id else "Добавление заказа"))
        self.resize(760, 520)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        if order_id:
            form.addRow("ID", QLabel(str(order_id)))
        self.customer_name_edit = QLineEdit()
        self.customer_phone_edit = QLineEdit()
        self.status_combo = QComboBox()
        self.status_combo.addItems(["новый", "в работе", "завершён", "отменён"])
        form.addRow("Клиент", self.customer_name_edit)
        form.addRow("Телефон", self.customer_phone_edit)
        form.addRow("Статус", self.status_combo)
        layout.addLayout(form)

        item_buttons = QHBoxLayout()
        self.add_item_button = QPushButton("Добавить позицию")
        self.remove_item_button = QPushButton("Удалить позицию")
        item_buttons.addWidget(self.add_item_button)
        item_buttons.addWidget(self.remove_item_button)
        item_buttons.addStretch()
        layout.addLayout(item_buttons)

        self.items_table = QTableWidget(0, 6)
        self.items_table.setHorizontalHeaderLabels(["ID товара", "Товар", "Количество", "Цена", "Скидка", "Сумма"])
        self.items_table.verticalHeader().setVisible(False)
        self.items_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.items_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.items_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.items_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.items_table)

        self.total_label = QLabel("Итого: 0.00")
        self.total_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.total_label.setStyleSheet("font-weight: 600;")
        layout.addWidget(self.total_label)

        if read_only:
            self.button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
            self.button_box.button(QDialogButtonBox.StandardButton.Close).setText("Закрыть")
            self.button_box.rejected.connect(self.reject)
        else:
            self.button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
            self.button_box.button(QDialogButtonBox.StandardButton.Save).setText("Сохранить")
            self.button_box.button(QDialogButtonBox.StandardButton.Cancel).setText("Отмена")
            self.button_box.accepted.connect(self.save)
            self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

        self.add_item_button.clicked.connect(self.add_item)
        self.remove_item_button.clicked.connect(self.remove_selected_item)
        if order_id:
            self.load_order(order_id)
        self.apply_read_only()
        self.refresh_items_table()

    def apply_read_only(self):
        widgets = [self.customer_name_edit, self.customer_phone_edit, self.status_combo, self.add_item_button, self.remove_item_button]
        for widget in widgets:
            widget.setEnabled(not self.read_only)

    def load_order(self, order_id):
        try:
            order = run_fetch_one("SELECT * FROM orders WHERE id=%s", (order_id,))
            rows = run_fetch_all(
                """
                SELECT oi.product_id, p.name AS product_name, oi.quantity, oi.price, oi.discount_percent
                FROM order_items oi
                JOIN products p ON p.id = oi.product_id
                WHERE oi.order_id = %s
                ORDER BY oi.id
                """,
                (order_id,),
            )
        except Exception as exc:
            show_error(self, f"Не удалось загрузить заказ.\n\n{exc}")
            return
        if not order:
            show_warning(self, "Заказ не найден.")
            return
        self.customer_name_edit.setText(order.get("customer_name") or "")
        self.customer_phone_edit.setText(order.get("customer_phone") or "")
        index = self.status_combo.findText(order.get("status") or "новый")
        if index >= 0:
            self.status_combo.setCurrentIndex(index)
        self.items = [
            {
                "product_id": row["product_id"],
                "product_name": row["product_name"],
                "quantity": int(row["quantity"]),
                "price": Decimal(str(row["price"])),
                "discount_percent": Decimal(str(row["discount_percent"])),
            }
            for row in rows
        ]

    def add_item(self):
        dialog = OrderItemDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        item = dialog.selected_item()
        for existing in self.items:
            if existing["product_id"] == item["product_id"]:
                existing["quantity"] += item["quantity"]
                self.refresh_items_table()
                return
        self.items.append(item)
        self.refresh_items_table()

    def remove_selected_item(self):
        selected = self.items_table.selectionModel().selectedRows()
        if not selected:
            show_warning(self, "Выберите позицию заказа.")
            return
        del self.items[selected[0].row()]
        self.refresh_items_table()

    def refresh_items_table(self):
        self.items_table.setRowCount(0)
        total = Decimal("0.00")
        for row_index, item in enumerate(self.items):
            self.items_table.insertRow(row_index)
            line_sum = (Decimal(item["quantity"]) * item["price"] * (Decimal("100") - item["discount_percent"]) / Decimal("100")).quantize(Decimal("0.01"))
            total += line_sum
            values = [
                item["product_id"],
                item["product_name"],
                item["quantity"],
                money(item["price"]),
                f"{money(item['discount_percent'])}%",
                money(line_sum),
            ]
            for column, value in enumerate(values):
                table_item = QTableWidgetItem(str(value))
                if column != 1:
                    table_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.items_table.setItem(row_index, column, table_item)
        self.total_label.setText(f"Итого: {money(total)}")

    def save(self):
        customer_name = self.customer_name_edit.text().strip()
        if not customer_name:
            show_warning(self, "Введите имя клиента.")
            return
        if not self.items:
            show_warning(self, "Добавьте хотя бы одну позицию заказа.")
            return
        conn = get_connection()
        try:
            with conn.cursor() as cursor:
                if self.order_id:
                    cursor.execute(
                        "UPDATE orders SET customer_name=%s, customer_phone=%s, status=%s WHERE id=%s",
                        (customer_name, self.customer_phone_edit.text().strip(), self.status_combo.currentText(), self.order_id),
                    )
                    cursor.execute("DELETE FROM order_items WHERE order_id=%s", (self.order_id,))
                    order_id = self.order_id
                else:
                    cursor.execute(
                        "INSERT INTO orders (customer_name, customer_phone, status) VALUES (%s,%s,%s)",
                        (customer_name, self.customer_phone_edit.text().strip(), self.status_combo.currentText()),
                    )
                    order_id = cursor.lastrowid
                for item in self.items:
                    cursor.execute(
                        """
                        INSERT INTO order_items (order_id, product_id, quantity, price, discount_percent)
                        VALUES (%s,%s,%s,%s,%s)
                        """,
                        (order_id, item["product_id"], item["quantity"], item["price"], item["discount_percent"]),
                    )
            conn.commit()
            self.saved.emit()
            show_info(self, "Заказ сохранён.")
            self.accept()
        except Exception as exc:
            conn.rollback()
            show_error(self, f"Не удалось сохранить заказ.\n\n{exc}")
        finally:
            conn.close()


class OrderItemDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Позиция заказа")
        self.setMinimumWidth(480)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.product_combo = QComboBox()
        self.quantity_spin = QSpinBox()
        self.quantity_spin.setRange(1, 1000000)
        form.addRow("Товар", self.product_combo)
        form.addRow("Количество", self.quantity_spin)
        layout.addLayout(form)
        self.button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.button_box.button(QDialogButtonBox.StandardButton.Ok).setText("Добавить")
        self.button_box.button(QDialogButtonBox.StandardButton.Cancel).setText("Отмена")
        layout.addWidget(self.button_box)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        self.load_products()

    def load_products(self):
        try:
            products = run_fetch_all(
                """
                SELECT id, name, price, discount_percent, quantity
                FROM products
                ORDER BY name
                """
            )
        except Exception as exc:
            show_error(self, f"Не удалось загрузить товары.\n\n{exc}")
            return
        self.product_combo.clear()
        for product in products:
            label = f"{product['name']} | цена {money(product['price'])} | склад {product['quantity']}"
            self.product_combo.addItem(label, product)

    def selected_item(self):
        product = self.product_combo.currentData()
        return {
            "product_id": product["id"],
            "product_name": product["name"],
            "quantity": self.quantity_spin.value(),
            "price": Decimal(str(product["price"])),
            "discount_percent": Decimal(str(product["discount_percent"])),
        }


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = LoginWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
