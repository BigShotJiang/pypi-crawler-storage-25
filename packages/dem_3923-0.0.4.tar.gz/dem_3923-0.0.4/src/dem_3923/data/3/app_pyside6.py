import os
import sys
from decimal import Decimal

import pymysql
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QApplication,
    QAbstractItemView,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

DB_HOST = os.getenv("DEM_DB_HOST", "localhost")
DB_USER = os.getenv("DEM_DB_USER", "root")
DB_PASSWORD = os.getenv("DEM_DB_PASSWORD", "")
DB_NAME = os.getenv("DEM_DB_NAME", "dem_DB")
DB_PORT = int(os.getenv("DEM_DB_PORT", "3306"))

PRODUCT_FIELDS = [
    "article",
    "product_name",
    "unit",
    "price",
    "supplier",
    "manufacturer",
    "category",
    "current_discount",
    "stock_quantity",
    "description",
    "image",
]

PRODUCT_HEADERS = [
    "Артикул",
    "Название",
    "Ед. изм.",
    "Цена",
    "Цена со скидкой",
    "Поставщик",
    "Производитель",
    "Категория",
    "Скидка, %",
    "Остаток",
    "Описание",
    "Фото",
]


class Database:
    def __init__(self):
        self.connection = None
        self.last_error = ""
        self.connect()

    def connect(self):
        try:
            self.connection = pymysql.connect(
                host=DB_HOST,
                user=DB_USER,
                password=DB_PASSWORD,
                database=DB_NAME,
                port=DB_PORT,
                charset="utf8mb4",
                cursorclass=pymysql.cursors.DictCursor,
                autocommit=False,
            )
            self.last_error = ""
        except Exception as error:
            self.connection = None
            self.last_error = str(error)

    def is_connected(self):
        if self.connection is None:
            return False
        try:
            self.connection.ping(reconnect=True)
            return True
        except Exception as error:
            self.last_error = str(error)
            return False

    def close(self):
        if self.connection:
            self.connection.close()
            self.connection = None

    def get_user(self, login, password):
        if not self.is_connected():
            return None
        sql = """
            SELECT id_user, role, full_name, login, password
            FROM `user`
            WHERE login = %s AND password = %s
            LIMIT 1
        """
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(sql, (login, password))
                return cursor.fetchone()
        except Exception as error:
            self.last_error = str(error)
            return None

    def get_products(self, search_text="", supplier=None, sort_type=None):
        if not self.is_connected():
            return []

        where_parts = []
        params = []

        if search_text:
            where_parts.append("(article LIKE %s OR product_name LIKE %s OR category LIKE %s)")
            pattern = f"%{search_text}%"
            params.extend([pattern, pattern, pattern])

        if supplier:
            where_parts.append("supplier = %s")
            params.append(supplier)

        order_map = {
            "name_asc": "product_name ASC",
            "price_asc": "price ASC, product_name ASC",
            "price_desc": "price DESC, product_name ASC",
            "quantity_asc": "stock_quantity ASC, product_name ASC",
            "quantity_desc": "stock_quantity DESC, product_name ASC",
        }
        order_by = order_map.get(sort_type or "name_asc", "product_name ASC")
        where_sql = "WHERE " + " AND ".join(where_parts) if where_parts else ""

        sql = f"""
            SELECT article, product_name, unit, price, supplier, manufacturer,
                   category, current_discount, stock_quantity, description, image
            FROM tovar
            {where_sql}
            ORDER BY {order_by}
        """
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(sql, params)
                return cursor.fetchall()
        except Exception as error:
            self.last_error = str(error)
            return []

    def get_suppliers(self):
        if not self.is_connected():
            return []
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("""
                    SELECT DISTINCT supplier
                    FROM tovar
                    WHERE supplier IS NOT NULL AND supplier <> ''
                    ORDER BY supplier
                """)
                return [row["supplier"] for row in cursor.fetchall()]
        except Exception as error:
            self.last_error = str(error)
            return []

    def get_product_by_article(self, article):
        if not self.is_connected():
            return None
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("SELECT * FROM tovar WHERE article = %s", (article,))
                return cursor.fetchone()
        except Exception as error:
            self.last_error = str(error)
            return None

    def add_product(self, product_data):
        if not self.is_connected():
            return False, "Нет подключения к базе данных."
        if self.get_product_by_article(product_data["article"]):
            return False, "Товар с таким артикулом уже существует."

        sql = """
            INSERT INTO tovar
            (article, product_name, unit, price, supplier, manufacturer, category,
             current_discount, stock_quantity, description, image)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        params = tuple(product_data.get(field) for field in PRODUCT_FIELDS)
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(sql, params)
            self.connection.commit()
            return True, "Товар добавлен."
        except Exception as error:
            self.connection.rollback()
            return False, f"Ошибка добавления: {error}"

    def update_product(self, article, product_data):
        if not self.is_connected():
            return False, "Нет подключения к базе данных."

        sql = """
            UPDATE tovar
            SET product_name = %s,
                unit = %s,
                price = %s,
                supplier = %s,
                manufacturer = %s,
                category = %s,
                current_discount = %s,
                stock_quantity = %s,
                description = %s,
                image = %s
            WHERE article = %s
        """
        params = (
            product_data.get("product_name"),
            product_data.get("unit"),
            product_data.get("price"),
            product_data.get("supplier"),
            product_data.get("manufacturer"),
            product_data.get("category"),
            product_data.get("current_discount"),
            product_data.get("stock_quantity"),
            product_data.get("description"),
            product_data.get("image"),
            article,
        )
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(sql, params)
            self.connection.commit()
            return True, "Товар обновлён."
        except Exception as error:
            self.connection.rollback()
            return False, f"Ошибка обновления: {error}"

    def delete_product(self, article):
        if not self.is_connected():
            return False, "Нет подключения к базе данных."

        try:
            with self.connection.cursor() as cursor:
                cursor.execute("SELECT COUNT(*) AS cnt FROM order_items WHERE article = %s", (article,))
                result = cursor.fetchone()
                if result and int(result["cnt"]) > 0:
                    return False, "Товар присутствует в заказах. Удаление запрещено."
                cursor.execute("DELETE FROM tovar WHERE article = %s", (article,))
            self.connection.commit()
            return True, "Товар удалён."
        except Exception as error:
            self.connection.rollback()
            return False, f"Ошибка удаления: {error}"

    def get_orders(self):
        if not self.is_connected():
            return []
        sql = """
            SELECT z.order_number, z.order_date, z.delivery_date, z.pickup_code,
                   z.order_status, pp.address, u.full_name,
                   oi.article, t.product_name, oi.quantity
            FROM zakaz z
            LEFT JOIN pickup_points pp ON pp.id_points = z.id_points
            LEFT JOIN `user` u ON u.id_user = z.id_user
            LEFT JOIN order_items oi ON oi.order_number = z.order_number
            LEFT JOIN tovar t ON t.article = oi.article
            ORDER BY z.order_date DESC, z.order_number DESC
        """
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(sql)
                return cursor.fetchall()
        except Exception as error:
            self.last_error = str(error)
            return []


class LoginWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.db = Database()
        self.product_window = None
        self.setWindowTitle('Авторизация - ООО "Обувь"')
        self.setMinimumSize(800, 600)
        self.setup_ui()

    def setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)

        wrapper = QVBoxLayout(central)
        wrapper.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title = QLabel('ООО "Обувь"')
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setFont(QFont("Times New Roman", 18, QFont.Weight.Bold))

        form_box = QGroupBox("Вход в систему")
        form_box.setFixedWidth(360)
        form_layout = QFormLayout(form_box)

        self.login_edit = QLineEdit()
        self.login_edit.setPlaceholderText("Введите логин")
        self.password_edit = QLineEdit()
        self.password_edit.setPlaceholderText("Введите пароль")
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)

        form_layout.addRow("Логин:", self.login_edit)
        form_layout.addRow("Пароль:", self.password_edit)

        button_layout = QHBoxLayout()
        self.login_button = QPushButton("Войти")
        self.guest_button = QPushButton("Войти как гость")
        button_layout.addWidget(self.login_button)
        button_layout.addWidget(self.guest_button)
        form_layout.addRow(button_layout)

        self.exit_button = QPushButton("Выход")
        form_layout.addRow(self.exit_button)

        wrapper.addWidget(title)
        wrapper.addWidget(form_box)

        self.login_button.clicked.connect(self.on_login)
        self.guest_button.clicked.connect(self.on_guest)
        self.exit_button.clicked.connect(self.close)
        self.password_edit.returnPressed.connect(self.on_login)

    def on_login(self):
        login = self.login_edit.text().strip()
        password = self.password_edit.text().strip()
        if not login or not password:
            QMessageBox.warning(self, "Ошибка", "Введите логин и пароль.")
            return

        user = self.db.get_user(login, password)
        if not user:
            if not self.db.is_connected():
                QMessageBox.critical(self, "Ошибка подключения", self.db.last_error)
            else:
                QMessageBox.critical(self, "Ошибка", "Неверный логин или пароль.")
            return

        self.open_product_window(user)

    def on_guest(self):
        user = {"id_user": 0, "role": "Гость", "full_name": "Гость"}
        self.open_product_window(user)

    def open_product_window(self, user):
        self.hide()
        self.product_window = ProductWindow(user=user, database=self.db, login_window=self)
        self.product_window.show()


class ProductDialog(QDialog):
    def __init__(self, product_data=None, parent=None):
        super().__init__(parent)
        self.product_data = product_data or {}
        self.setWindowTitle("Добавление товара" if product_data is None else "Редактирование товара")
        self.setMinimumWidth(520)
        self.setup_ui()
        if product_data:
            self.load_product_data()
            self.article_edit.setReadOnly(True)

    def setup_ui(self):
        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.article_edit = QLineEdit()
        self.name_edit = QLineEdit()
        self.category_edit = QLineEdit()
        self.manufacturer_edit = QLineEdit()
        self.supplier_edit = QLineEdit()
        self.price_spin = QDoubleSpinBox()
        self.price_spin.setRange(0, 100_000_000)
        self.price_spin.setDecimals(2)
        self.discount_spin = QDoubleSpinBox()
        self.discount_spin.setRange(0, 100)
        self.discount_spin.setDecimals(2)
        self.quantity_spin = QSpinBox()
        self.quantity_spin.setRange(0, 10_000_000)
        self.unit_edit = QLineEdit("шт.")
        self.description_edit = QTextEdit()
        self.description_edit.setFixedHeight(90)
        self.image_edit = QLineEdit()

        form.addRow("Артикул:", self.article_edit)
        form.addRow("Название:", self.name_edit)
        form.addRow("Категория:", self.category_edit)
        form.addRow("Производитель:", self.manufacturer_edit)
        form.addRow("Поставщик:", self.supplier_edit)
        form.addRow("Цена:", self.price_spin)
        form.addRow("Скидка, %:", self.discount_spin)
        form.addRow("Количество:", self.quantity_spin)
        form.addRow("Единица измерения:", self.unit_edit)
        form.addRow("Описание:", self.description_edit)
        form.addRow("Фото, файл:", self.image_edit)

        self.button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)

        layout.addLayout(form)
        layout.addWidget(self.button_box)

    def load_product_data(self):
        data = self.product_data
        self.article_edit.setText(str(data.get("article", "")))
        self.name_edit.setText(str(data.get("product_name", "")))
        self.category_edit.setText(str(data.get("category", "")))
        self.manufacturer_edit.setText(str(data.get("manufacturer", "")))
        self.supplier_edit.setText(str(data.get("supplier", "")))
        self.price_spin.setValue(float(data.get("price") or 0))
        self.discount_spin.setValue(float(data.get("current_discount") or 0))
        self.quantity_spin.setValue(int(data.get("stock_quantity") or 0))
        self.unit_edit.setText(str(data.get("unit", "шт.") or "шт."))
        self.description_edit.setPlainText(str(data.get("description", "") or ""))
        self.image_edit.setText(str(data.get("image", "") or ""))

    def get_product_data(self):
        return {
            "article": self.article_edit.text().strip(),
            "product_name": self.name_edit.text().strip(),
            "unit": self.unit_edit.text().strip() or "шт.",
            "price": self.price_spin.value(),
            "supplier": self.supplier_edit.text().strip(),
            "manufacturer": self.manufacturer_edit.text().strip(),
            "category": self.category_edit.text().strip(),
            "current_discount": self.discount_spin.value(),
            "stock_quantity": self.quantity_spin.value(),
            "description": self.description_edit.toPlainText().strip(),
            "image": self.image_edit.text().strip(),
        }

    def accept(self):
        data = self.get_product_data()
        if not data["article"]:
            QMessageBox.warning(self, "Ошибка", "Артикул обязателен.")
            return
        if not data["product_name"]:
            QMessageBox.warning(self, "Ошибка", "Название товара обязательно.")
            return
        super().accept()


class OrdersDialog(QDialog):
    def __init__(self, database, parent=None):
        super().__init__(parent)
        self.database = database
        self.setWindowTitle("Заказы")
        self.resize(1050, 520)
        self.setup_ui()
        self.load_orders()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        self.table = QTableWidget()
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        layout.addWidget(self.table)

        close_button = QPushButton("Закрыть")
        close_button.clicked.connect(self.close)
        layout.addWidget(close_button, alignment=Qt.AlignmentFlag.AlignRight)

    def load_orders(self):
        headers = [
            "Номер",
            "Дата заказа",
            "Дата доставки",
            "Код",
            "Статус",
            "Пункт выдачи",
            "Клиент",
            "Артикул",
            "Товар",
            "Кол-во",
        ]
        rows = self.database.get_orders()
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(len(rows))
        for row_idx, row in enumerate(rows):
            values = [
                row.get("order_number"),
                row.get("order_date"),
                row.get("delivery_date"),
                row.get("pickup_code"),
                row.get("order_status"),
                row.get("address"),
                row.get("full_name"),
                row.get("article"),
                row.get("product_name"),
                row.get("quantity"),
            ]
            for col_idx, value in enumerate(values):
                self.table.setItem(row_idx, col_idx, QTableWidgetItem("" if value is None else str(value)))


class ProductWindow(QMainWindow):
    def __init__(self, user, database, login_window=None):
        super().__init__()
        self.user = user
        self.database = database
        self.login_window = login_window
        self.role = user.get("role", "Гость")
        self.is_admin = self.role == "Администратор"
        self.can_filter = self.role in ["Менеджер", "Администратор"]

        self.setWindowTitle(f'ООО "Обувь" - {self.role}')
        self.resize(1200, 720)
        self.setup_ui()
        self.setup_permissions()
        self.load_suppliers()
        self.load_products()

    def setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        top = QHBoxLayout()
        title = QLabel('ООО "Обувь"')
        title.setFont(QFont("Times New Roman", 16, QFont.Weight.Bold))
        self.user_label = QLabel(self.user.get("full_name", "Гость"))
        self.user_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.logout_button = QPushButton("Выход")
        top.addWidget(title)
        top.addStretch()
        top.addWidget(self.user_label)
        top.addWidget(self.logout_button)

        controls = QGridLayout()
        self.orders_button = QPushButton("Заказы")
        self.add_button = QPushButton("Добавить товар")
        self.search_label = QLabel("Поиск:")
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Название, артикул или категория")
        self.sort_label = QLabel("Сортировка:")
        self.sort_combo = QComboBox()
        self.sort_combo.addItem("Без сортировки", "name_asc")
        self.sort_combo.addItem("Цена по возрастанию", "price_asc")
        self.sort_combo.addItem("Цена по убыванию", "price_desc")
        self.sort_combo.addItem("Количество по возрастанию", "quantity_asc")
        self.sort_combo.addItem("Количество по убыванию", "quantity_desc")
        self.filter_label = QLabel("Поставщик:")
        self.supplier_combo = QComboBox()
        self.reset_button = QPushButton("Сбросить")

        controls.addWidget(self.orders_button, 0, 0)
        controls.addWidget(self.add_button, 0, 1)
        controls.addWidget(self.search_label, 1, 0)
        controls.addWidget(self.search_edit, 1, 1)
        controls.addWidget(self.sort_label, 1, 2)
        controls.addWidget(self.sort_combo, 1, 3)
        controls.addWidget(self.filter_label, 1, 4)
        controls.addWidget(self.supplier_combo, 1, 5)
        controls.addWidget(self.reset_button, 1, 6)
        controls.setColumnStretch(1, 2)
        controls.setColumnStretch(5, 2)

        self.table = QTableWidget()
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)

        self.status_label = QLabel("")

        root.addLayout(top)
        root.addLayout(controls)
        root.addWidget(self.table)
        root.addWidget(self.status_label)

        self.logout_button.clicked.connect(self.on_logout)
        self.orders_button.clicked.connect(self.on_orders)
        self.add_button.clicked.connect(self.on_add)
        self.search_edit.textChanged.connect(self.load_products)
        self.sort_combo.currentIndexChanged.connect(self.load_products)
        self.supplier_combo.currentIndexChanged.connect(self.load_products)
        self.reset_button.clicked.connect(self.reset_filters)

    def setup_permissions(self):
        self.orders_button.setVisible(self.role in ["Менеджер", "Администратор"])
        self.add_button.setVisible(self.is_admin)
        for widget in [
            self.search_label,
            self.search_edit,
            self.sort_label,
            self.sort_combo,
            self.filter_label,
            self.supplier_combo,
            self.reset_button,
        ]:
            widget.setVisible(self.can_filter)

    def load_suppliers(self):
        self.supplier_combo.blockSignals(True)
        self.supplier_combo.clear()
        self.supplier_combo.addItem("Все поставщики", None)
        for supplier in self.database.get_suppliers():
            self.supplier_combo.addItem(supplier, supplier)
        self.supplier_combo.blockSignals(False)

    def current_filter(self):
        if not self.can_filter:
            return "", None, "name_asc"
        return (
            self.search_edit.text().strip(),
            self.supplier_combo.currentData(),
            self.sort_combo.currentData(),
        )

    def load_products(self):
        search_text, supplier, sort_type = self.current_filter()
        products = self.database.get_products(search_text=search_text, supplier=supplier, sort_type=sort_type)
        self.render_products(products)
        if not self.database.is_connected():
            self.status_label.setText(f"Нет подключения к базе данных: {self.database.last_error}")
        else:
            self.status_label.setText(f"Загружено товаров: {len(products)}")

    def render_products(self, products):
        headers = PRODUCT_HEADERS.copy()
        if self.is_admin:
            headers.append("Действия")

        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(len(products))

        for row_idx, product in enumerate(products):
            values = self.product_row_values(product)
            row_color = self.row_color(product)
            for col_idx, value in enumerate(values):
                item = QTableWidgetItem("" if value is None else str(value))
                item.setFlags(item.flags() ^ Qt.ItemFlag.ItemIsEditable)
                if row_color:
                    item.setBackground(row_color)
                self.table.setItem(row_idx, col_idx, item)

            if self.is_admin:
                actions_widget = QWidget()
                actions_layout = QHBoxLayout(actions_widget)
                actions_layout.setContentsMargins(2, 2, 2, 2)
                edit_button = QPushButton("Редактировать")
                delete_button = QPushButton("Удалить")
                edit_button.clicked.connect(lambda _, p=product: self.on_edit(p))
                delete_button.clicked.connect(lambda _, p=product: self.on_delete(p))
                actions_layout.addWidget(edit_button)
                actions_layout.addWidget(delete_button)
                self.table.setCellWidget(row_idx, len(headers) - 1, actions_widget)

        self.table.resizeColumnsToContents()

    def product_row_values(self, product):
        price = Decimal(str(product.get("price") or 0))
        discount = Decimal(str(product.get("current_discount") or 0))
        discounted_price = price * (Decimal("1") - discount / Decimal("100"))
        return [
            product.get("article"),
            product.get("product_name"),
            product.get("unit"),
            f"{price:.2f}",
            f"{discounted_price:.2f}",
            product.get("supplier"),
            product.get("manufacturer"),
            product.get("category"),
            f"{discount:.2f}",
            product.get("stock_quantity"),
            product.get("description"),
            product.get("image"),
        ]

    @staticmethod
    def row_color(product):
        discount = float(product.get("current_discount") or 0)
        quantity = int(product.get("stock_quantity") or 0)
        if discount > 15:
            return QColor("#2E8B57")
        if quantity <= 0:
            return QColor("#ADD8E6")
        return None

    def reset_filters(self):
        self.search_edit.clear()
        self.sort_combo.setCurrentIndex(0)
        self.supplier_combo.setCurrentIndex(0)
        self.load_products()

    def on_add(self):
        dialog = ProductDialog(parent=self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        success, message = self.database.add_product(dialog.get_product_data())
        self.show_result(success, message)
        if success:
            self.load_suppliers()
            self.load_products()

    def on_edit(self, product):
        fresh_product = self.database.get_product_by_article(product["article"]) or product
        dialog = ProductDialog(product_data=fresh_product, parent=self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        success, message = self.database.update_product(fresh_product["article"], dialog.get_product_data())
        self.show_result(success, message)
        if success:
            self.load_suppliers()
            self.load_products()

    def on_delete(self, product):
        answer = QMessageBox.question(
            self,
            "Удаление",
            f"Удалить товар '{product.get('product_name')}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        success, message = self.database.delete_product(product["article"])
        self.show_result(success, message)
        if success:
            self.load_suppliers()
            self.load_products()

    def on_orders(self):
        dialog = OrdersDialog(self.database, self)
        dialog.exec()

    def on_logout(self):
        self.close()
        if self.login_window:
            self.login_window.show()

    def show_result(self, success, message):
        if success:
            QMessageBox.information(self, "Готово", message)
        else:
            QMessageBox.warning(self, "Ошибка", message)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = LoginWindow()
    window.show()
    sys.exit(app.exec())
