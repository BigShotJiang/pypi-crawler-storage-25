@echo off
python app_pyside6.py
pause
