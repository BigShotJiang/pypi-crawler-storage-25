login: phpmyadmin
password: phpmyadmin

База данных: dem_DB
Кодировка по заданию: utf16_general_ci

user
id_user int primary key auto_increment
role varchar(80)
full_name varchar(255)
login varchar(255)
password varchar(255)

pickup_points
id_points int primary key auto_increment
address varchar(500)

tovar
article varchar(64) primary key
product_name varchar(255)
unit varchar(40)
price decimal(10,2)
supplier varchar(255)
manufacturer varchar(255)
category varchar(255)
current_discount decimal(5,2)
stock_quantity int
description text
image varchar(255)

zakaz
order_number varchar(64) primary key
order_date date
delivery_date date
pickup_code varchar(50)
order_status varchar(80)
id_points int foreign key -> pickup_points.id_points
id_user int foreign key -> user.id_user

order_items
id_items int primary key auto_increment
order_number varchar(64) foreign key -> zakaz.order_number
article varchar(64) foreign key -> tovar.article
quantity int
