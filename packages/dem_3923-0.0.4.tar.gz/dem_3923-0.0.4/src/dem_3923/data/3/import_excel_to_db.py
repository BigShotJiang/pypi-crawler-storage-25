import argparse
import csv
import os
from datetime import datetime
from decimal import Decimal

import openpyxl
import pymysql

DB_HOST = os.getenv("DEM_DB_HOST", "localhost")
DB_USER = os.getenv("DEM_DB_USER", "root")
DB_PASSWORD = os.getenv("DEM_DB_PASSWORD", "")
DB_NAME = os.getenv("DEM_DB_NAME", "dem_DB")
DB_PORT = int(os.getenv("DEM_DB_PORT", "3306"))


USER_MAP = {
    "role": "role",
    "роль": "role",
    "full_name": "full_name",
    "фио": "full_name",
    "фио_пользователя": "full_name",
    "фио пользователя": "full_name",
    "login": "login",
    "логин": "login",
    "password": "password",
    "пароль": "password",
}

POINTS_MAP = {
    "address": "address",
    "адрес": "address",
    "адрес_пункта_выдачи": "address",
    "адрес пункта выдачи": "address",
}

PRODUCT_MAP = {
    "article": "article",
    "артикул": "article",
    "product_name": "product_name",
    "наименование": "product_name",
    "название": "product_name",
    "название товара": "product_name",
    "unit": "unit",
    "единица измерения": "unit",
    "единица_измерения": "unit",
    "price": "price",
    "цена": "price",
    "supplier": "supplier",
    "поставщик": "supplier",
    "manufacturer": "manufacturer",
    "производитель": "manufacturer",
    "category": "category",
    "категория": "category",
    "current_discount": "current_discount",
    "действующая скидка": "current_discount",
    "действующая_скидка": "current_discount",
    "скидка": "current_discount",
    "stock_quantity": "stock_quantity",
    "количество на складе": "stock_quantity",
    "количество_на_складе": "stock_quantity",
    "количество": "stock_quantity",
    "description": "description",
    "описание": "description",
    "image": "image",
    "изображение": "image",
    "фото": "image",
}

ORDER_MAP = {
    "order_number": "order_number",
    "номер_заказа": "order_number",
    "номер заказа": "order_number",
    "order_date": "order_date",
    "дата_заказа": "order_date",
    "дата заказа": "order_date",
    "delivery_date": "delivery_date",
    "дата_доставки": "delivery_date",
    "дата доставки": "delivery_date",
    "pickup_code": "pickup_code",
    "код_для_получения": "pickup_code",
    "код для получения": "pickup_code",
    "order_status": "order_status",
    "статус_заказа": "order_status",
    "статус заказа": "order_status",
    "address": "address",
    "адрес_пункта_выдачи": "address",
    "адрес пункта выдачи": "address",
    "full_name": "full_name",
    "фио_авторизированного_клиента": "full_name",
    "фио авторизированного клиента": "full_name",
    "article": "article",
    "артикул_заказа": "article",
    "артикул заказа": "article",
    "quantity": "quantity",
    "количество": "quantity",
}

PRODUCT_FIELDS = [
    "article",
    "product_name",
    "unit",
    "price",
    "supplier",
    "manufacturer",
    "category",
    "current_discount",
    "stock_quantity",
    "description",
    "image",
]


def connect():
    return pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        port=DB_PORT,
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=False,
    )


def normalize_header(value):
    if value is None:
        return ""
    return str(value).strip().lower().replace("\n", " ")


def read_rows(path):
    extension = os.path.splitext(path)[1].lower()
    if extension in [".xlsx", ".xlsm"]:
        workbook = openpyxl.load_workbook(path, data_only=True)
        sheet = workbook.active
        rows = list(sheet.iter_rows(values_only=True))
        if not rows:
            return []
        headers = [normalize_header(value) for value in rows[0]]
        result = []
        for row in rows[1:]:
            if not row or all(value is None or str(value).strip() == "" for value in row):
                continue
            result.append({headers[index]: row[index] if index < len(row) else None for index in range(len(headers))})
        return result

    if extension == ".csv":
        with open(path, "r", encoding="utf-8-sig", newline="") as file:
            reader = csv.DictReader(file)
            return [{normalize_header(key): value for key, value in row.items()} for row in reader]

    raise ValueError(f"Неизвестный формат файла: {path}")


def mapped_rows(path, mapping):
    rows = read_rows(path)
    result = []
    for row in rows:
        item = {}
        for source_key, value in row.items():
            target_key = mapping.get(normalize_header(source_key))
            if target_key:
                item[target_key] = clean(value)
        if any(value not in [None, ""] for value in item.values()):
            result.append(item)
    return result


def clean(value):
    if value is None:
        return None
    if isinstance(value, str):
        value = value.strip()
        return value if value != "" else None
    return value


def to_decimal(value, default="0"):
    if value in [None, ""]:
        return Decimal(default)
    return Decimal(str(value).replace(",", "."))


def to_int(value, default=0):
    if value in [None, ""]:
        return default
    return int(float(str(value).replace(",", ".")))


def to_date(value):
    if value in [None, ""]:
        return None
    if isinstance(value, datetime):
        return value.date().isoformat()
    text = str(value).strip()
    for fmt in ["%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y", "%Y.%m.%d"]:
        try:
            return datetime.strptime(text, fmt).date().isoformat()
        except ValueError:
            pass
    return text


def import_users(connection, path):
    rows = mapped_rows(path, USER_MAP)
    sql = """
        INSERT INTO `user` (role, full_name, login, password)
        VALUES (%s, %s, %s, %s)
    """
    with connection.cursor() as cursor:
        for row in rows:
            cursor.execute(sql, (
                row.get("role") or "Авторизированный клиент",
                row.get("full_name") or "Без имени",
                row.get("login"),
                row.get("password"),
            ))
    connection.commit()
    return len(rows)


def import_points(connection, path):
    rows = mapped_rows(path, POINTS_MAP)
    sql = "INSERT INTO pickup_points (address) VALUES (%s)"
    with connection.cursor() as cursor:
        for row in rows:
            address = row.get("address")
            if address:
                cursor.execute(sql, (address,))
    connection.commit()
    return len(rows)


def import_products(connection, path):
    rows = mapped_rows(path, PRODUCT_MAP)
    sql = """
        INSERT INTO tovar
        (article, product_name, unit, price, supplier, manufacturer, category,
         current_discount, stock_quantity, description, image)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE
            product_name = VALUES(product_name),
            unit = VALUES(unit),
            price = VALUES(price),
            supplier = VALUES(supplier),
            manufacturer = VALUES(manufacturer),
            category = VALUES(category),
            current_discount = VALUES(current_discount),
            stock_quantity = VALUES(stock_quantity),
            description = VALUES(description),
            image = VALUES(image)
    """
    count = 0
    with connection.cursor() as cursor:
        for row in rows:
            if not row.get("article") or not row.get("product_name"):
                continue
            data = {
                "article": str(row.get("article")),
                "product_name": row.get("product_name"),
                "unit": row.get("unit") or "шт.",
                "price": to_decimal(row.get("price")),
                "supplier": row.get("supplier") or "",
                "manufacturer": row.get("manufacturer") or "",
                "category": row.get("category") or "",
                "current_discount": to_decimal(row.get("current_discount")),
                "stock_quantity": to_int(row.get("stock_quantity")),
                "description": row.get("description") or "",
                "image": row.get("image") or "",
            }
            cursor.execute(sql, tuple(data[field] for field in PRODUCT_FIELDS))
            count += 1
    connection.commit()
    return count


def find_or_create_point(connection, address):
    if not address:
        return None
    with connection.cursor() as cursor:
        cursor.execute("SELECT id_points FROM pickup_points WHERE address = %s LIMIT 1", (address,))
        row = cursor.fetchone()
        if row:
            return row["id_points"]
        cursor.execute("INSERT INTO pickup_points (address) VALUES (%s)", (address,))
        return cursor.lastrowid


def find_or_create_user(connection, full_name):
    if not full_name:
        return None
    with connection.cursor() as cursor:
        cursor.execute("SELECT id_user FROM `user` WHERE full_name = %s LIMIT 1", (full_name,))
        row = cursor.fetchone()
        if row:
            return row["id_user"]
        cursor.execute(
            "INSERT INTO `user` (role, full_name, login, password) VALUES (%s, %s, %s, %s)",
            ("Авторизированный клиент", full_name, None, None),
        )
        return cursor.lastrowid


def import_orders(connection, path):
    rows = mapped_rows(path, ORDER_MAP)
    if not rows:
        return 0, 0

    order_sql = """
        INSERT INTO zakaz
        (order_number, order_date, delivery_date, pickup_code, order_status, id_points, id_user)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE
            order_date = VALUES(order_date),
            delivery_date = VALUES(delivery_date),
            pickup_code = VALUES(pickup_code),
            order_status = VALUES(order_status),
            id_points = VALUES(id_points),
            id_user = VALUES(id_user)
    """
    item_sql = """
        INSERT INTO order_items (order_number, article, quantity)
        VALUES (%s, %s, %s)
    """

    imported_orders = set()
    imported_items = 0
    with connection.cursor() as cursor:
        for row in rows:
            order_number = row.get("order_number")
            if not order_number:
                continue
            order_number = str(order_number)
            if order_number not in imported_orders:
                point_id = find_or_create_point(connection, row.get("address"))
                user_id = find_or_create_user(connection, row.get("full_name"))
                cursor.execute(order_sql, (
                    order_number,
                    to_date(row.get("order_date")) or datetime.today().date().isoformat(),
                    to_date(row.get("delivery_date")),
                    row.get("pickup_code"),
                    row.get("order_status") or "Новый",
                    point_id,
                    user_id,
                ))
                imported_orders.add(order_number)

            article = row.get("article")
            quantity = to_int(row.get("quantity"), 1)
            if article:
                cursor.execute(item_sql, (order_number, str(article), quantity))
                imported_items += 1
    connection.commit()
    return len(imported_orders), imported_items


def main():
    parser = argparse.ArgumentParser(description="Импорт ресурсов демонстрационного экзамена в dem_DB.")
    parser.add_argument("--users", help="Файл user_import.xlsx или user_import.csv")
    parser.add_argument("--points", help="Файл Пункты выдачи_import.xlsx или .csv")
    parser.add_argument("--products", help="Файл Tovar.xlsx или Tovar.csv")
    parser.add_argument("--orders", help="Файл Заказ_import.xlsx, order_main.csv или подготовленный файл заказов")
    args = parser.parse_args()

    connection = connect()
    try:
        if args.users:
            print(f"Пользователи: {import_users(connection, args.users)}")
        if args.points:
            print(f"Пункты выдачи: {import_points(connection, args.points)}")
        if args.products:
            print(f"Товары: {import_products(connection, args.products)}")
        if args.orders:
            orders_count, items_count = import_orders(connection, args.orders)
            print(f"Заказы: {orders_count}; позиции заказов: {items_count}")
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


if __name__ == "__main__":
    main()
