-- dem_DB.sql
-- Скрипт создания базы данных для phpMyAdmin / MySQL / MariaDB.
-- Имя базы и кодировка взяты из инструкции: dem_DB, utf16_general_ci.

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `dem_DB`
  DEFAULT CHARACTER SET utf16
  COLLATE utf16_general_ci;

USE `dem_DB`;

DROP TABLE IF EXISTS `order_items`;
DROP TABLE IF EXISTS `zakaz`;
DROP TABLE IF EXISTS `tovar`;
DROP TABLE IF EXISTS `pickup_points`;
DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` INT NOT NULL AUTO_INCREMENT,
  `role` VARCHAR(80) NOT NULL,
  `full_name` VARCHAR(255) NOT NULL,
  `login` VARCHAR(255) DEFAULT NULL,
  `password` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  INDEX `idx_user_login` (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

CREATE TABLE `pickup_points` (
  `id_points` INT NOT NULL AUTO_INCREMENT,
  `address` VARCHAR(500) NOT NULL,
  PRIMARY KEY (`id_points`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

CREATE TABLE `tovar` (
  `article` VARCHAR(64) NOT NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `unit` VARCHAR(40) NOT NULL DEFAULT 'шт.',
  `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `supplier` VARCHAR(255) DEFAULT '',
  `manufacturer` VARCHAR(255) DEFAULT '',
  `category` VARCHAR(255) DEFAULT '',
  `current_discount` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  `stock_quantity` INT NOT NULL DEFAULT 0,
  `description` TEXT,
  `image` VARCHAR(255) DEFAULT '',
  PRIMARY KEY (`article`),
  INDEX `idx_tovar_name` (`product_name`),
  INDEX `idx_tovar_supplier` (`supplier`),
  INDEX `idx_tovar_price` (`price`),
  INDEX `idx_tovar_quantity` (`stock_quantity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

CREATE TABLE `zakaz` (
  `order_number` VARCHAR(64) NOT NULL,
  `order_date` DATE NOT NULL,
  `delivery_date` DATE DEFAULT NULL,
  `pickup_code` VARCHAR(50) DEFAULT NULL,
  `order_status` VARCHAR(80) NOT NULL DEFAULT 'Новый',
  `id_points` INT DEFAULT NULL,
  `id_user` INT DEFAULT NULL,
  PRIMARY KEY (`order_number`),
  INDEX `idx_zakaz_points` (`id_points`),
  INDEX `idx_zakaz_user` (`id_user`),
  CONSTRAINT `fk_zakaz_points`
    FOREIGN KEY (`id_points`) REFERENCES `pickup_points` (`id_points`)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT `fk_zakaz_user`
    FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

CREATE TABLE `order_items` (
  `id_items` INT NOT NULL AUTO_INCREMENT,
  `order_number` VARCHAR(64) NOT NULL,
  `article` VARCHAR(64) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_items`),
  INDEX `idx_items_order` (`order_number`),
  INDEX `idx_items_article` (`article`),
  CONSTRAINT `fk_items_order`
    FOREIGN KEY (`order_number`) REFERENCES `zakaz` (`order_number`)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_items_article`
    FOREIGN KEY (`article`) REFERENCES `tovar` (`article`)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- Контрольные пользователи из задания для проверки входа.
INSERT INTO `user` (`role`, `full_name`, `login`, `password`) VALUES
('Администратор', 'Администратор', '94d5ous@gmail.com', 'uzWC67'),
('Менеджер', 'Менеджер', '1diph5e@tutanota.com', '8ntwUp'),
('Авторизированный клиент', 'Авторизированный клиент', '5d4zbu@tutanota.com', 'rwVDh9');

-- Минимальные тестовые данные. Их можно удалить после импорта реальных ресурсов.
INSERT INTO `pickup_points` (`address`) VALUES
('г. Москва, ул. Примерная, д. 1'),
('г. Казань, пр. Учебный, д. 5');

INSERT INTO `tovar`
(`article`, `product_name`, `unit`, `price`, `supplier`, `manufacturer`, `category`, `current_discount`, `stock_quantity`, `description`, `image`) VALUES
('SAMPLE-001', 'Кроссовки учебные', 'шт.', 3490.00, 'Поставщик А', 'ООО ОбувьПром', 'Кроссовки', 10.00, 12, 'Тестовый товар для проверки просмотра.', ''),
('SAMPLE-002', 'Ботинки демисезонные', 'шт.', 5190.00, 'Поставщик Б', 'Фабрика Север', 'Ботинки', 20.00, 7, 'Товар со скидкой больше 15 процентов.', ''),
('SAMPLE-003', 'Туфли классические', 'шт.', 4590.00, 'Поставщик А', 'Фабрика Стиль', 'Туфли', 0.00, 0, 'Товар с нулевым остатком.', '');
