from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "dem_DB",
    "charset": "utf8mb4",
    "autocommit": False,
}

DEFAULT_ENTITY_TYPE = "shoe_store"
DEFAULT_LAYOUT_PATH = BASE_DIR / "configs" / "field_order_shoes.json"
IMAGE_DIR = BASE_DIR / "images"
PLACEHOLDER_IMAGE = IMAGE_DIR / "picture.png"
