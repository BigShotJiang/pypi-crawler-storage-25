from __future__ import annotations

import datetime as _dt
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pymysql
import pymysql.cursors

from settings import DB_CONFIG


VALUE_COLUMNS = {
    "string": "value_string",
    "image": "value_string",
    "text": "value_text",
    "integer": "value_int",
    "decimal": "value_decimal",
    "date": "value_date",
    "boolean": "value_bool",
}


class Database:
    def __init__(self) -> None:
        self.connection = None
        self.connect()

    def connect(self) -> None:
        try:
            self.connection = pymysql.connect(
                **DB_CONFIG,
                cursorclass=pymysql.cursors.DictCursor,
            )
            print("✅ Подключено к БД")
        except Exception as exc:
            self.connection = None
            print(f"Ошибка подключения к БД: {exc}")

    def is_connected(self) -> bool:
        return self.connection is not None

    def close(self) -> None:
        if self.connection:
            self.connection.close()
            self.connection = None

    def _ensure(self) -> None:
        if not self.is_connected():
            raise RuntimeError("Нет подключения к базе данных")

    def fetchall(self, sql: str, params: Iterable[Any] = ()) -> List[Dict[str, Any]]:
        self._ensure()
        with self.connection.cursor() as cursor:
            cursor.execute(sql, tuple(params))
            return list(cursor.fetchall())

    def fetchone(self, sql: str, params: Iterable[Any] = ()) -> Optional[Dict[str, Any]]:
        self._ensure()
        with self.connection.cursor() as cursor:
            cursor.execute(sql, tuple(params))
            return cursor.fetchone()

    def execute(self, sql: str, params: Iterable[Any] = ()) -> int:
        self._ensure()
        with self.connection.cursor() as cursor:
            result = cursor.execute(sql, tuple(params))
        self.connection.commit()
        return result

    def get_user(self, login: str, password: str) -> Optional[Dict[str, Any]]:
        return self.fetchone(
            """
            SELECT id_user, role, full_name, login
            FROM `user`
            WHERE login=%s AND password=%s
            """,
            (login, password),
        )

    def get_entity_types(self) -> List[Dict[str, Any]]:
        return self.fetchall(
            """
            SELECT id_entity_type, code, title, search_field_code, filter_field_code,
                   price_field_code, stock_field_code, image_field_code
            FROM catalog_entity_type
            WHERE is_active=1
            ORDER BY title
            """
        )

    def get_entity_type(self, code: str) -> Optional[Dict[str, Any]]:
        return self.fetchone(
            """
            SELECT id_entity_type, code, title, search_field_code, filter_field_code,
                   price_field_code, stock_field_code, image_field_code
            FROM catalog_entity_type
            WHERE code=%s AND is_active=1
            """,
            (code,),
        )

    def get_fields(self, entity_type_code: str) -> List[Dict[str, Any]]:
        entity = self.get_entity_type(entity_type_code)
        if not entity:
            return []
        fields = self.fetchall(
            """
            SELECT id_field, field_code, title, data_type, is_required, is_unique,
                   max_length, min_number, max_number, default_value, display_in_form,
                   display_in_card, sort_allowed, filter_allowed, search_allowed,
                   is_system, is_computed, compute_expression, sort_weight
            FROM catalog_field
            WHERE entity_type_id=%s
            ORDER BY sort_weight, id_field
            """,
            (entity["id_entity_type"],),
        )
        return fields

    def _field_map(self, entity_type_code: str) -> Dict[str, Dict[str, Any]]:
        return {f["field_code"]: f for f in self.get_fields(entity_type_code)}

    def _read_typed_value(self, data_type: str, row: Dict[str, Any]) -> Any:
        column = VALUE_COLUMNS[data_type]
        return row.get(column)

    def _build_items_from_rows(
        self,
        entity_type_code: str,
        rows: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        items: Dict[int, Dict[str, Any]] = {}
        for row in rows:
            item_id = row["id_item"]
            if item_id not in items:
                items[item_id] = {
                    "id_item": item_id,
                    "article": row["article"],
                    "entity_type_code": entity_type_code,
                }
            if row.get("field_code"):
                items[item_id][row["field_code"]] = self._read_typed_value(row["data_type"], row)
        field_map = self._field_map(entity_type_code)
        for item in items.values():
            self._apply_defaults_and_computed(item, field_map)
        return list(items.values())

    def _apply_defaults_and_computed(
        self,
        item: Dict[str, Any],
        field_map: Dict[str, Dict[str, Any]],
    ) -> None:
        for code, field in field_map.items():
            if code == "article":
                continue
            if code not in item and field.get("default_value") is not None:
                item[code] = field["default_value"]
        if "price_after_discount" in field_map:
            price = self._decimal(item.get("price") or 0)
            discount = self._decimal(item.get("current_discount") or 0)
            item["price_after_discount"] = price * (Decimal("1") - discount / Decimal("100"))

    def get_items(
        self,
        entity_type_code: str,
        search_text: str = "",
        filter_field: Optional[str] = None,
        filter_value: Optional[str] = None,
        sort_code: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        entity = self.get_entity_type(entity_type_code)
        if not entity:
            return []

        rows = self.fetchall(
            """
            SELECT ci.id_item, ci.article, cf.field_code, cf.data_type,
                   civ.value_string, civ.value_text, civ.value_int, civ.value_decimal,
                   civ.value_date, civ.value_bool, civ.value_json
            FROM catalog_item ci
            LEFT JOIN catalog_item_value civ ON civ.item_id = ci.id_item
            LEFT JOIN catalog_field cf ON cf.id_field = civ.field_id
            WHERE ci.entity_type_id=%s
            ORDER BY ci.article
            """,
            (entity["id_entity_type"],),
        )
        items = self._build_items_from_rows(entity_type_code, rows)
        fields = self.get_fields(entity_type_code)
        searchable_codes = [f["field_code"] for f in fields if f.get("search_allowed")]

        if filter_field and filter_value:
            items = [
                item for item in items
                if str(item.get(filter_field, "")).casefold() == str(filter_value).casefold()
            ]

        text = (search_text or "").strip().casefold()
        if text:
            items = [
                item for item in items
                if any(text in str(item.get(code, "")).casefold() for code in searchable_codes)
            ]

        sort_field, reverse = self._decode_sort_code(sort_code, entity)
        if sort_field:
            items.sort(key=lambda item: self._sort_value(item.get(sort_field)), reverse=reverse)
        else:
            title_field = entity.get("search_field_code") or "article"
            items.sort(key=lambda item: str(item.get(title_field, item.get("article", ""))).casefold())

        return items

    def _decode_sort_code(
        self,
        sort_code: Optional[str],
        entity: Dict[str, Any],
    ) -> Tuple[Optional[str], bool]:
        if not sort_code:
            return None, False
        if sort_code.endswith("_asc"):
            return sort_code[:-4], False
        if sort_code.endswith("_desc"):
            return sort_code[:-5], True
        aliases = {
            "price_asc": (entity.get("price_field_code"), False),
            "price_desc": (entity.get("price_field_code"), True),
            "quantity_asc": (entity.get("stock_field_code"), False),
            "quantity_desc": (entity.get("stock_field_code"), True),
        }
        return aliases.get(sort_code, (None, False))

    def _sort_value(self, value: Any) -> Tuple[int, Any]:
        if value is None:
            return (1, "")
        if isinstance(value, (int, float, Decimal, _dt.date)):
            return (0, value)
        return (0, str(value).casefold())

    def get_filter_values(self, entity_type_code: str, field_code: str) -> List[str]:
        entity = self.get_entity_type(entity_type_code)
        field = self.fetchone(
            """
            SELECT id_field, data_type
            FROM catalog_field
            WHERE entity_type_id=%s AND field_code=%s
            """,
            (entity["id_entity_type"], field_code),
        ) if entity else None
        if not entity or not field:
            return []
        column = VALUE_COLUMNS[field["data_type"]]
        rows = self.fetchall(
            f"""
            SELECT DISTINCT civ.{column} AS value
            FROM catalog_item ci
            JOIN catalog_item_value civ ON civ.item_id = ci.id_item
            WHERE ci.entity_type_id=%s AND civ.field_id=%s AND civ.{column} IS NOT NULL
            ORDER BY civ.{column}
            """,
            (entity["id_entity_type"], field["id_field"]),
        )
        return [str(r["value"]) for r in rows if str(r["value"]).strip()]

    def get_sort_options(self, entity_type_code: str) -> List[Dict[str, str]]:
        result = []
        for field in self.get_fields(entity_type_code):
            if not field.get("sort_allowed"):
                continue
            code = field["field_code"]
            title = field["title"]
            result.append({"code": f"{code}_asc", "title": f"{title}: возрастание"})
            result.append({"code": f"{code}_desc", "title": f"{title}: убывание"})
        return result

    def _decimal(self, value: Any) -> Decimal:
        try:
            return Decimal(str(value).replace(",", "."))
        except (InvalidOperation, ValueError):
            return Decimal("0")

    def _convert_for_field(self, field: Dict[str, Any], raw_value: Any) -> Any:
        if raw_value is None:
            return None
        if isinstance(raw_value, str) and raw_value.strip() == "":
            return None
        data_type = field["data_type"]
        if data_type in ("string", "image", "text"):
            value = str(raw_value).strip()
            max_length = field.get("max_length")
            if max_length and len(value) > int(max_length):
                raise ValueError(f"Поле {field['title']} длиннее {max_length} символов")
            return value
        if data_type == "integer":
            value = int(float(str(raw_value).replace(",", ".")))
            self._check_number_limits(field, Decimal(value))
            return value
        if data_type == "decimal":
            value = self._decimal(raw_value)
            self._check_number_limits(field, value)
            return value
        if data_type == "boolean":
            if isinstance(raw_value, bool):
                return int(raw_value)
            return 1 if str(raw_value).strip().casefold() in {"1", "true", "да", "yes"} else 0
        if data_type == "date":
            if isinstance(raw_value, _dt.date):
                return raw_value
            return _dt.datetime.strptime(str(raw_value).strip(), "%Y-%m-%d").date()
        return raw_value

    def _check_number_limits(self, field: Dict[str, Any], value: Decimal) -> None:
        min_number = field.get("min_number")
        max_number = field.get("max_number")
        if min_number is not None and value < Decimal(str(min_number)):
            raise ValueError(f"Поле {field['title']} меньше {min_number}")
        if max_number is not None and value > Decimal(str(max_number)):
            raise ValueError(f"Поле {field['title']} больше {max_number}")

    def _validate_required(self, fields: List[Dict[str, Any]], data: Dict[str, Any]) -> None:
        for field in fields:
            if field.get("is_required") and not field.get("is_computed"):
                value = data.get(field["field_code"])
                if value is None or str(value).strip() == "":
                    raise ValueError(f"Заполните поле: {field['title']}")

    def _get_item_by_article(self, entity_type_id: int, article: str) -> Optional[Dict[str, Any]]:
        return self.fetchone(
            """
            SELECT id_item, article
            FROM catalog_item
            WHERE entity_type_id=%s AND article=%s
            """,
            (entity_type_id, article),
        )

    def save_item(
        self,
        entity_type_code: str,
        data: Dict[str, Any],
        original_article: Optional[str] = None,
    ) -> Tuple[bool, str]:
        try:
            self._ensure()
            entity = self.get_entity_type(entity_type_code)
            if not entity:
                return False, "Тип объекта не найден"
            fields = self.get_fields(entity_type_code)
            field_map = {field["field_code"]: field for field in fields}
            self._validate_required(fields, data)

            article = str(data.get("article", "")).strip()
            if not article:
                return False, "Артикул или код обязателен"

            existing = self._get_item_by_article(entity["id_entity_type"], original_article or article)
            duplicate = self._get_item_by_article(entity["id_entity_type"], article)
            if original_article is None and duplicate:
                return False, "Запись с таким артикулом или кодом уже существует"
            if original_article and duplicate and duplicate["article"] != original_article:
                return False, "Новый артикул или код уже занят"

            with self.connection.cursor() as cursor:
                if existing:
                    cursor.execute(
                        """
                        UPDATE catalog_item
                        SET article=%s
                        WHERE id_item=%s
                        """,
                        (article, existing["id_item"]),
                    )
                    item_id = existing["id_item"]
                else:
                    cursor.execute(
                        """
                        INSERT INTO catalog_item (entity_type_id, article)
                        VALUES (%s, %s)
                        """,
                        (entity["id_entity_type"], article),
                    )
                    item_id = cursor.lastrowid

                for code, field in field_map.items():
                    if code == "article" or field.get("is_computed"):
                        continue
                    value = self._convert_for_field(field, data.get(code))
                    self._upsert_value(cursor, item_id, field, value)

            self.connection.commit()
            return True, "Запись сохранена"
        except Exception as exc:
            if self.connection:
                self.connection.rollback()
            return False, str(exc)

    def _upsert_value(self, cursor, item_id: int, field: Dict[str, Any], value: Any) -> None:
        column = VALUE_COLUMNS[field["data_type"]]
        all_columns = ["value_string", "value_text", "value_int", "value_decimal", "value_date", "value_bool", "value_json"]
        values = {name: None for name in all_columns}
        values[column] = value
        cursor.execute(
            """
            INSERT INTO catalog_item_value
            (item_id, field_id, value_string, value_text, value_int, value_decimal, value_date, value_bool, value_json)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
              value_string=VALUES(value_string),
              value_text=VALUES(value_text),
              value_int=VALUES(value_int),
              value_decimal=VALUES(value_decimal),
              value_date=VALUES(value_date),
              value_bool=VALUES(value_bool),
              value_json=VALUES(value_json)
            """,
            (
                item_id,
                field["id_field"],
                values["value_string"],
                values["value_text"],
                values["value_int"],
                values["value_decimal"],
                values["value_date"],
                values["value_bool"],
                values["value_json"],
            ),
        )

    def delete_item(self, entity_type_code: str, article: str) -> Tuple[bool, str]:
        try:
            entity = self.get_entity_type(entity_type_code)
            if not entity:
                return False, "Тип объекта не найден"
            linked = self.fetchone(
                """
                SELECT COUNT(*) AS cnt
                FROM order_items
                WHERE entity_type_id=%s AND article=%s
                """,
                (entity["id_entity_type"], article),
            )
            if linked and linked["cnt"] > 0:
                return False, "Запись используется в заказах. Удаление заблокировано"
            self.execute(
                """
                DELETE FROM catalog_item
                WHERE entity_type_id=%s AND article=%s
                """,
                (entity["id_entity_type"], article),
            )
            return True, "Запись удалена"
        except Exception as exc:
            return False, str(exc)

    def get_table_columns(self, table_name: str) -> List[Dict[str, Any]]:
        return self.fetchall(
            """
            SELECT COLUMN_NAME AS column_name, DATA_TYPE AS data_type,
                   IS_NULLABLE AS is_nullable, CHARACTER_MAXIMUM_LENGTH AS max_length,
                   NUMERIC_PRECISION AS numeric_precision, NUMERIC_SCALE AS numeric_scale
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s
            ORDER BY ORDINAL_POSITION
            """,
            (table_name,),
        )
