from __future__ import annotations

import json
import sys
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, List, Optional

from PyQt5.QtCore import QDate, Qt
from PyQt5.QtGui import QFont, QPixmap
from PyQt5.QtWidgets import (
    QApplication,
    QComboBox,
    QDateEdit,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from database import Database
from settings import DEFAULT_ENTITY_TYPE, DEFAULT_LAYOUT_PATH, IMAGE_DIR, PLACEHOLDER_IMAGE


def money(value: Any) -> str:
    try:
        return f"{Decimal(str(value)):.2f} ₽"
    except Exception:
        return "0.00 ₽"


def load_layout_config(path: Path, entity_type_code: str, fields: List[Dict[str, Any]]) -> Dict[str, Any]:
    if path.exists():
        with path.open("r", encoding="utf-8") as file:
            config = json.load(file)
        if config.get("entity_type_code") == entity_type_code:
            return config
    return {
        "entity_type_code": entity_type_code,
        "card": [
            {"field_code": field["field_code"], "visible": bool(field["display_in_card"])}
            for field in fields
            if field.get("display_in_card")
        ],
        "dialog": [
            {"field_code": field["field_code"], "visible": bool(field["display_in_form"])}
            for field in fields
            if field.get("display_in_form") and not field.get("is_computed")
        ],
    }


class LoginForm(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.db = Database()
        self.product_window = None
        self.setWindowTitle("Авторизация")
        self.setMinimumSize(800, 600)
        self._setup_ui()

    def _setup_ui(self) -> None:
        root = QWidget()
        root.setStyleSheet("background-color: white;")
        self.setCentralWidget(root)

        box = QVBoxLayout(root)
        box.setAlignment(Qt.AlignCenter)

        title = QLabel("Универсальное приложение")
        title.setAlignment(Qt.AlignCenter)
        title.setFont(QFont("Times New Roman", 18, QFont.Bold))
        box.addWidget(title)

        form = QGridLayout()
        form.setSpacing(10)
        box.addLayout(form)

        form.addWidget(QLabel("Логин:"), 0, 0)
        self.loginEdit = QLineEdit()
        self.loginEdit.setPlaceholderText("Введите логин")
        form.addWidget(self.loginEdit, 0, 1)

        form.addWidget(QLabel("Пароль:"), 1, 0)
        self.passwordEdit = QLineEdit()
        self.passwordEdit.setEchoMode(QLineEdit.Password)
        self.passwordEdit.setPlaceholderText("Введите пароль")
        form.addWidget(self.passwordEdit, 1, 1)

        buttons = QHBoxLayout()
        self.loginButton = QPushButton("Войти")
        self.guestButton = QPushButton("Войти как гость")
        self.exitButton = QPushButton("Выход")
        buttons.addWidget(self.loginButton)
        buttons.addWidget(self.guestButton)
        buttons.addWidget(self.exitButton)
        box.addLayout(buttons)

        self.loginButton.clicked.connect(self.on_login)
        self.guestButton.clicked.connect(self.on_guest)
        self.exitButton.clicked.connect(self.close)

    def on_login(self) -> None:
        login = self.loginEdit.text().strip()
        password = self.passwordEdit.text().strip()
        if not login or not password:
            QMessageBox.warning(self, "Предупреждение", "Введите логин и пароль")
            return
        user = self.db.get_user(login, password)
        if user:
            self.open_product_form(user)
        else:
            QMessageBox.critical(self, "Ошибка", "Неверный логин или пароль")

    def on_guest(self) -> None:
        self.open_product_form({
            "id_user": 0,
            "role": "Гость",
            "full_name": "Гость",
            "login": "",
        })

    def open_product_form(self, user: Dict[str, Any]) -> None:
        self.hide()
        self.product_window = ProductWindow(user, login_window=self)
        self.product_window.show()


class DynamicItemDialog(QDialog):
    def __init__(
        self,
        fields: List[Dict[str, Any]],
        item_data: Optional[Dict[str, Any]] = None,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.fields = [f for f in fields if f.get("display_in_form") and not f.get("is_computed")]
        self.item_data = item_data or {}
        self.widgets: Dict[str, Any] = {}
        self.setWindowTitle("Добавление записи" if item_data is None else "Редактирование записи")
        self.setMinimumWidth(520)
        self._setup_ui()
        if item_data:
            self._load_values()

    def _setup_ui(self) -> None:
        root = QVBoxLayout(self)
        form = QGridLayout()
        form.setSpacing(8)
        root.addLayout(form)

        for row, field in enumerate(self.fields):
            label_text = field["title"] + (":" if not field.get("is_required") else ": *")
            form.addWidget(QLabel(label_text), row, 0)
            widget = self._make_widget(field)
            self.widgets[field["field_code"]] = widget
            form.addWidget(widget, row, 1)

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        root.addWidget(button_box)

    def _make_widget(self, field: Dict[str, Any]):
        data_type = field["data_type"]
        if data_type == "integer":
            widget = QSpinBox()
            widget.setRange(int(field.get("min_number") or 0), int(field.get("max_number") or 999999999))
            return widget
        if data_type == "decimal":
            widget = QDoubleSpinBox()
            widget.setDecimals(2)
            widget.setRange(float(field.get("min_number") or 0), float(field.get("max_number") or 999999999))
            return widget
        if data_type == "date":
            widget = QDateEdit()
            widget.setCalendarPopup(True)
            widget.setDisplayFormat("yyyy-MM-dd")
            widget.setDate(QDate.currentDate())
            return widget
        if data_type == "boolean":
            widget = QComboBox()
            widget.addItem("Нет", 0)
            widget.addItem("Да", 1)
            return widget
        if data_type == "text":
            return QTextEdit()
        return QLineEdit()

    def _load_values(self) -> None:
        for field in self.fields:
            code = field["field_code"]
            widget = self.widgets[code]
            value = self.item_data.get(code)
            if value is None:
                value = field.get("default_value")
            if value is None:
                continue
            if isinstance(widget, QSpinBox):
                widget.setValue(int(value))
            elif isinstance(widget, QDoubleSpinBox):
                widget.setValue(float(value))
            elif isinstance(widget, QDateEdit):
                widget.setDate(QDate.fromString(str(value), "yyyy-MM-dd"))
            elif isinstance(widget, QComboBox):
                index = widget.findData(int(value))
                widget.setCurrentIndex(max(index, 0))
            elif isinstance(widget, QTextEdit):
                widget.setPlainText(str(value))
            else:
                widget.setText(str(value))

        article_widget = self.widgets.get("article")
        if article_widget and hasattr(article_widget, "setReadOnly"):
            article_widget.setReadOnly(True)

    def get_data(self) -> Dict[str, Any]:
        data = {}
        for field in self.fields:
            code = field["field_code"]
            widget = self.widgets[code]
            if isinstance(widget, QSpinBox):
                data[code] = widget.value()
            elif isinstance(widget, QDoubleSpinBox):
                data[code] = widget.value()
            elif isinstance(widget, QDateEdit):
                data[code] = widget.date().toString("yyyy-MM-dd")
            elif isinstance(widget, QComboBox):
                data[code] = widget.currentData()
            elif isinstance(widget, QTextEdit):
                data[code] = widget.toPlainText().strip()
            else:
                data[code] = widget.text().strip()
        return data


class ProductCard(QFrame):
    def __init__(
        self,
        item: Dict[str, Any],
        fields: Dict[str, Dict[str, Any]],
        layout_config: Dict[str, Any],
        is_admin: bool,
        parent_form: "ProductWindow",
    ) -> None:
        super().__init__()
        self.item = item
        self.fields = fields
        self.layout_config = layout_config
        self.is_admin = is_admin
        self.parent_form = parent_form
        self._setup_ui()

    def _setup_ui(self) -> None:
        self.setFrameShape(QFrame.Box)
        self.setLineWidth(1)
        self.setMinimumHeight(160)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)

        main = QHBoxLayout(self)
        image_code = self.parent_form.entity.get("image_field_code") or "image"
        image_value = self.item.get(image_code)
        image_label = QLabel()
        image_label.setFixedSize(110, 110)
        image_label.setAlignment(Qt.AlignCenter)
        image_path = IMAGE_DIR / str(image_value) if image_value else PLACEHOLDER_IMAGE
        if not image_path.exists():
            image_path = PLACEHOLDER_IMAGE
        pixmap = QPixmap(str(image_path))
        if not pixmap.isNull():
            image_label.setPixmap(pixmap.scaled(100, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        main.addWidget(image_label)

        info = QVBoxLayout()
        title_code = self.parent_form.entity.get("search_field_code") or "article"
        title_label = QLabel(str(self.item.get(title_code, self.item.get("article", ""))))
        title_label.setFont(QFont("Times New Roman", 12, QFont.Bold))
        info.addWidget(title_label)

        for entry in self.layout_config.get("card", []):
            if not entry.get("visible", True):
                continue
            code = entry["field_code"]
            if code == image_code or code == title_code:
                continue
            field = self.fields.get(code)
            if not field:
                continue
            value = self.item.get(code)
            if value is None or str(value).strip() == "":
                continue
            text = self._format_value(field, value)
            label = QLabel(text)
            label.setWordWrap(True)
            if code == "price" and self.item.get("current_discount"):
                label.setStyleSheet("text-decoration: line-through; color: #b00020;")
            if code == "price_after_discount":
                label.setFont(QFont("Times New Roman", 11, QFont.Bold))
            info.addWidget(label)

        main.addLayout(info, stretch=1)

        if self.is_admin:
            buttons = QVBoxLayout()
            edit_button = QPushButton("Редактировать")
            delete_button = QPushButton("Удалить")
            edit_button.clicked.connect(self.edit_item)
            delete_button.clicked.connect(self.delete_item)
            buttons.addWidget(edit_button)
            buttons.addWidget(delete_button)
            buttons.addStretch()
            main.addLayout(buttons)

        discount = self.item.get("current_discount") or 0
        stock = self.item.get("stock_quantity")
        try:
            if Decimal(str(discount)) > 15:
                self.setStyleSheet("background-color: #d8f2df;")
            elif stock is not None and int(stock) <= 0:
                self.setStyleSheet("background-color: #d9ecff;")
        except Exception:
            pass

    def _format_value(self, field: Dict[str, Any], value: Any) -> str:
        if field["data_type"] == "decimal":
            return f"{field['title']}: {money(value)}"
        if field["data_type"] == "integer":
            return f"{field['title']}: {value}"
        if field["data_type"] == "boolean":
            return f"{field['title']}: {'Да' if value else 'Нет'}"
        text = str(value)
        if len(text) > 180:
            text = text[:177] + "..."
        return f"{field['title']}: {text}"

    def edit_item(self) -> None:
        self.parent_form.edit_item(self.item)

    def delete_item(self) -> None:
        self.parent_form.delete_item(self.item)


class ProductWindow(QMainWindow):
    def __init__(self, user: Dict[str, Any], login_window: Optional[LoginForm] = None) -> None:
        super().__init__()
        self.user = user
        self.role = user["role"]
        self.login_window = login_window
        self.db = Database()
        self.entity_type_code = DEFAULT_ENTITY_TYPE
        self.entity: Dict[str, Any] = {}
        self.fields: List[Dict[str, Any]] = []
        self.field_map: Dict[str, Dict[str, Any]] = {}
        self.layout_config: Dict[str, Any] = {}
        self.setMinimumSize(960, 640)
        self._setup_ui()
        self.load_entity(self.entity_type_code)

    def _setup_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        main = QVBoxLayout(root)

        header = QHBoxLayout()
        self.entity_combo = QComboBox()
        self.user_label = QLabel(self.user["full_name"])
        self.user_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.logout_button = QPushButton("Выход")
        header.addWidget(QLabel("Тема:"))
        header.addWidget(self.entity_combo, stretch=1)
        header.addWidget(self.user_label, stretch=2)
        header.addWidget(self.logout_button)
        main.addLayout(header)

        controls = QHBoxLayout()
        self.orders_button = QPushButton("Заказы")
        self.add_button = QPushButton("Добавить")
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Поиск...")
        self.filter_combo = QComboBox()
        self.sort_combo = QComboBox()
        controls.addWidget(self.orders_button)
        controls.addWidget(self.add_button)
        controls.addWidget(QLabel("Поиск:"))
        controls.addWidget(self.search_edit, stretch=1)
        controls.addWidget(QLabel("Фильтр:"))
        controls.addWidget(self.filter_combo)
        controls.addWidget(QLabel("Сортировка:"))
        controls.addWidget(self.sort_combo)
        main.addLayout(controls)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.products_container = QWidget()
        self.products_layout = QVBoxLayout(self.products_container)
        self.products_layout.setAlignment(Qt.AlignTop)
        self.scroll_area.setWidget(self.products_container)
        main.addWidget(self.scroll_area)

        self.statusBar().showMessage("Готово")

        self.orders_button.setVisible(self.role in ["Менеджер", "Администратор"])
        self.add_button.setVisible(self.role == "Администратор")
        manager_or_admin = self.role in ["Менеджер", "Администратор"]
        self.search_edit.setVisible(manager_or_admin)
        self.filter_combo.setVisible(manager_or_admin)
        self.sort_combo.setVisible(manager_or_admin)

        self.logout_button.clicked.connect(self.on_logout)
        self.add_button.clicked.connect(self.add_item)
        self.search_edit.textChanged.connect(self.apply_filters)
        self.filter_combo.currentIndexChanged.connect(self.apply_filters)
        self.sort_combo.currentIndexChanged.connect(self.apply_filters)
        self.entity_combo.currentIndexChanged.connect(self.on_entity_changed)

        self._load_entity_combo()

    def _load_entity_combo(self) -> None:
        self.entity_combo.blockSignals(True)
        self.entity_combo.clear()
        for entity in self.db.get_entity_types():
            self.entity_combo.addItem(entity["title"], entity["code"])
        index = self.entity_combo.findData(DEFAULT_ENTITY_TYPE)
        self.entity_combo.setCurrentIndex(max(index, 0))
        self.entity_combo.blockSignals(False)

    def on_entity_changed(self) -> None:
        code = self.entity_combo.currentData()
        if code:
            self.load_entity(code)

    def load_entity(self, entity_type_code: str) -> None:
        entity = self.db.get_entity_type(entity_type_code)
        if not entity:
            QMessageBox.critical(self, "Ошибка", "Тип объекта не найден в БД")
            return
        self.entity_type_code = entity_type_code
        self.entity = entity
        self.fields = self.db.get_fields(entity_type_code)
        self.field_map = {f["field_code"]: f for f in self.fields}
        self.layout_config = load_layout_config(DEFAULT_LAYOUT_PATH, entity_type_code, self.fields)
        self.setWindowTitle(f"{entity['title']} — {self.role}")
        self._load_filter_combo()
        self._load_sort_combo()
        self.apply_filters()

    def _load_filter_combo(self) -> None:
        self.filter_combo.blockSignals(True)
        self.filter_combo.clear()
        self.filter_combo.addItem("Все", None)
        filter_field = self.entity.get("filter_field_code")
        if filter_field:
            for value in self.db.get_filter_values(self.entity_type_code, filter_field):
                self.filter_combo.addItem(value, value)
        self.filter_combo.blockSignals(False)

    def _load_sort_combo(self) -> None:
        self.sort_combo.blockSignals(True)
        self.sort_combo.clear()
        self.sort_combo.addItem("Без сортировки", None)
        for option in self.db.get_sort_options(self.entity_type_code):
            self.sort_combo.addItem(option["title"], option["code"])
        self.sort_combo.blockSignals(False)

    def apply_filters(self) -> None:
        if not self.entity:
            return
        filter_value = self.filter_combo.currentData()
        filter_field = self.entity.get("filter_field_code") if filter_value else None
        items = self.db.get_items(
            self.entity_type_code,
            search_text=self.search_edit.text(),
            filter_field=filter_field,
            filter_value=filter_value,
            sort_code=self.sort_combo.currentData(),
        )
        self._render_items(items)
        self.statusBar().showMessage(f"Загружено записей: {len(items)}")

    def _render_items(self, items: List[Dict[str, Any]]) -> None:
        while self.products_layout.count():
            child = self.products_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        is_admin = self.role == "Администратор"
        for item in items:
            card = ProductCard(item, self.field_map, self.layout_config, is_admin, self)
            self.products_layout.addWidget(card)
        self.products_layout.addStretch()

    def add_item(self) -> None:
        dialog = DynamicItemDialog(self.fields, parent=self)
        if dialog.exec_() == QDialog.Accepted:
            success, message = self.db.save_item(self.entity_type_code, dialog.get_data())
            if success:
                QMessageBox.information(self, "Успех", message)
                self._load_filter_combo()
                self.apply_filters()
            else:
                QMessageBox.warning(self, "Ошибка", message)

    def edit_item(self, item: Dict[str, Any]) -> None:
        dialog = DynamicItemDialog(self.fields, item_data=item, parent=self)
        if dialog.exec_() == QDialog.Accepted:
            success, message = self.db.save_item(
                self.entity_type_code,
                dialog.get_data(),
                original_article=item["article"],
            )
            if success:
                QMessageBox.information(self, "Успех", message)
                self._load_filter_combo()
                self.apply_filters()
            else:
                QMessageBox.warning(self, "Ошибка", message)

    def delete_item(self, item: Dict[str, Any]) -> None:
        answer = QMessageBox.question(
            self,
            "Подтверждение",
            f"Удалить запись {item.get('article')}?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer == QMessageBox.Yes:
            success, message = self.db.delete_item(self.entity_type_code, item["article"])
            if success:
                QMessageBox.information(self, "Успех", message)
                self.apply_filters()
            else:
                QMessageBox.warning(self, "Ошибка", message)

    def on_logout(self) -> None:
        self.close()
        if self.login_window:
            self.login_window.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = LoginForm()
    window.show()
    sys.exit(app.exec_())
