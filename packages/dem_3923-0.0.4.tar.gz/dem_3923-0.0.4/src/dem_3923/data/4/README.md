# Универсальное приложение для демоэкзамена

Проект сделан как универсальный каталог. Тема задаётся в БД через `catalog_entity_type`, набор полей через `catalog_field`, значения записей через `catalog_item` и `catalog_item_value`. За счёт этого можно использовать магазин обуви, зоомагазин, услуги ремонта принтеров и другие похожие предметные области.

## Установка

```bash
pip install -r requirements.txt
```

## Создание БД

1. Откройте phpMyAdmin.
2. Создайте или импортируйте SQL из файла `create_database.sql`.
3. В `settings.py` проверьте логин, пароль и имя БД.

Тестовые пользователи после выполнения SQL:

- `admin@example.com` / `admin`
- `manager@example.com` / `manager`
- `client@example.com` / `client`

## Запуск приложения

```bash
python main.py
```

Роли:

- Гость и клиент видят карточки.
- Менеджер и администратор используют поиск, фильтрацию и сортировку.
- Администратор добавляет, редактирует и удаляет записи.

## Настройка порядка полей

```bash
python field_layout_helper.py
```

Скрипт загружает поля и типы из БД, даёт переставить поля в карточке, открыть существующий JSON и сохранить исправленный JSON. Готовый пример находится в `configs/field_order_shoes.json`.

## Импорт из Excel

Импорт товаров или услуг в универсальный каталог:

```bash
python import_excel_to_db.py --file Tovar.xlsx --table catalog --entity-type shoe_store
```

Импорт с явной картой столбцов:

```bash
python import_excel_to_db.py --file Tovar.xlsx --table catalog --entity-type shoe_store --mapping configs/import_mapping_example.json
```

Импорт обычных таблиц:

```bash
python import_excel_to_db.py --file user_import.xlsx --table user
python import_excel_to_db.py --file pickup_points.xlsx --table pickup_points
python import_excel_to_db.py --file order_main.xlsx --table zakaz
python import_excel_to_db.py --file order_items.xlsx --table order_items
```

## Как добавить новую тему

1. Добавьте строку в `catalog_entity_type`.
2. Добавьте поля темы в `catalog_field`.
3. Запустите `field_layout_helper.py`.
4. Сохраните JSON порядка полей.
5. В `settings.py` смените `DEFAULT_ENTITY_TYPE` и `DEFAULT_LAYOUT_PATH`.

## Важное ограничение

`create_database.sql` содержит совместимое представление `tovar` для темы магазина обуви. Основное приложение работает через универсальные таблицы `catalog_*`.
