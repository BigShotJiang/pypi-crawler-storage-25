from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict

import pandas as pd

from database import Database


DEFAULT_FIELD_MAP = {
    "article": ["article", "Артикул", "Код", "Код услуги"],
    "product_name": ["product_name", "Название", "Наименование", "Товар"],
    "service_name": ["service_name", "Название", "Наименование", "Услуга"],
    "unit": ["unit", "Единица измерения", "Ед. изм.", "Единица"],
    "price": ["price", "Цена", "Цена (руб)", "Стоимость"],
    "supplier": ["supplier", "Поставщик"],
    "manufacturer": ["manufacturer", "Производитель"],
    "category": ["category", "Категория"],
    "current_discount": ["current_discount", "Скидка", "Скидка (%)", "Действующая скидка"],
    "stock_quantity": ["stock_quantity", "Количество", "Количество на складе", "Остаток"],
    "description": ["description", "Описание"],
    "image": ["image", "Фото", "Изображение", "Картинка", "image"],
}

TABLE_COLUMNS = {
    "user": ["role", "full_name", "login", "password"],
    "pickup_points": ["address"],
    "zakaz": ["order_number", "order_date", "delivery_date", "pickup_code", "order_status", "id_points", "id_user"],
    "order_items": ["order_number", "entity_type_id", "article", "quantity"],
}


def normalize_column(name: Any) -> str:
    return str(name).strip().replace("\n", " ").replace("\r", " ")


def load_mapping(path: str | None) -> Dict[str, Any]:
    if not path:
        return {}
    with Path(path).open("r", encoding="utf-8") as file:
        return json.load(file)


def guess_columns(df: pd.DataFrame, field_map: Dict[str, list[str]]) -> Dict[str, str]:
    normalized = {normalize_column(col).casefold(): col for col in df.columns}
    result = {}
    for field_code, candidates in field_map.items():
        for candidate in candidates:
            column = normalized.get(candidate.casefold())
            if column is not None:
                result[field_code] = column
                break
    return result


def clean_value(value: Any) -> Any:
    if pd.isna(value):
        return None
    if isinstance(value, str):
        value = value.strip()
        return value if value else None
    return value


def import_catalog_items(
    db: Database,
    path: Path,
    entity_type: str,
    sheet_name: str | int | None,
    mapping: Dict[str, Any],
) -> None:
    df = pd.read_excel(path, sheet_name=sheet_name if sheet_name is not None else 0, dtype=object)
    df = df.dropna(how="all")
    field_map = mapping.get("field_map") or DEFAULT_FIELD_MAP
    columns = mapping.get("columns") or guess_columns(df, field_map)

    if "article" not in columns:
        raise RuntimeError("В Excel не найден столбец артикула или кода")

    added = 0
    updated = 0
    for _, row in df.iterrows():
        data = {}
        for field_code, column in columns.items():
            if column in row:
                data[field_code] = clean_value(row[column])
        if not data.get("article"):
            continue
        entity = db.get_entity_type(entity_type)
        exists = db._get_item_by_article(entity["id_entity_type"], str(data["article"]).strip()) if entity else None
        success, message = db.save_item(entity_type, data, original_article=data["article"] if exists else None)
        if success and exists:
            updated += 1
        elif success:
            added += 1
        else:
            print(f"Пропущена строка с article={data.get('article')}: {message}")
    print(f"Готово. Добавлено: {added}. Обновлено: {updated}.")


def import_simple_table(db: Database, path: Path, table: str, sheet_name: str | int | None, mapping: Dict[str, Any]) -> None:
    if table not in TABLE_COLUMNS:
        raise RuntimeError(f"Нет встроенного импорта для таблицы {table}")

    df = pd.read_excel(path, sheet_name=sheet_name if sheet_name is not None else 0, dtype=object)
    df = df.dropna(how="all")
    columns = mapping.get("columns") or {column: column for column in TABLE_COLUMNS[table]}

    db._ensure()
    inserted = 0
    with db.connection.cursor() as cursor:
        for _, row in df.iterrows():
            values = {}
            for db_col, excel_col in columns.items():
                if excel_col in row:
                    values[db_col] = clean_value(row[excel_col])
            if not values:
                continue
            cols = list(values.keys())
            placeholders = ", ".join(["%s"] * len(cols))
            col_sql = ", ".join([f"`{col}`" for col in cols])
            update_sql = ", ".join([f"`{col}`=VALUES(`{col}`)" for col in cols])
            cursor.execute(
                f"""
                INSERT INTO `{table}` ({col_sql})
                VALUES ({placeholders})
                ON DUPLICATE KEY UPDATE {update_sql}
                """,
                tuple(values[col] for col in cols),
            )
            inserted += 1
    db.connection.commit()
    print(f"Готово. Обработано строк: {inserted}.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Импорт данных из Excel в БД демоэкзамена")
    parser.add_argument("--file", required=True, help="Путь к xlsx/xls файлу")
    parser.add_argument("--entity-type", default="shoe_store", help="Код темы для универсального каталога")
    parser.add_argument("--table", default="catalog", help="catalog, user, pickup_points, zakaz, order_items")
    parser.add_argument("--sheet", default=None, help="Название листа или номер листа")
    parser.add_argument("--mapping", default=None, help="JSON с соответствием столбцов Excel и полей БД")
    args = parser.parse_args()

    sheet = args.sheet
    if sheet is not None and str(sheet).isdigit():
        sheet = int(sheet)

    db = Database()
    mapping = load_mapping(args.mapping)
    path = Path(args.file)

    if args.table == "catalog" or args.table == "tovar":
        import_catalog_items(db, path, args.entity_type, sheet, mapping)
    else:
        import_simple_table(db, path, args.table, sheet, mapping)


if __name__ == "__main__":
    main()
