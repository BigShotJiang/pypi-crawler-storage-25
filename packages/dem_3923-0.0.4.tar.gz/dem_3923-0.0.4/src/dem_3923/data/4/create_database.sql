DROP DATABASE IF EXISTS dem_DB;
CREATE DATABASE dem_DB
  DEFAULT CHARACTER SET utf16
  DEFAULT COLLATE utf16_general_ci;

USE dem_DB;

CREATE TABLE `user` (
  id_user INT UNSIGNED NOT NULL AUTO_INCREMENT,
  role ENUM('Гость','Авторизированный клиент','Менеджер','Администратор') NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  login VARCHAR(100) NOT NULL,
  password VARCHAR(100) NOT NULL,
  PRIMARY KEY (id_user),
  UNIQUE KEY uq_user_login (login)
) ENGINE=InnoDB;

CREATE TABLE pickup_points (
  id_points INT UNSIGNED NOT NULL AUTO_INCREMENT,
  address VARCHAR(255) NOT NULL,
  PRIMARY KEY (id_points),
  UNIQUE KEY uq_pickup_points_address (address)
) ENGINE=InnoDB;

CREATE TABLE catalog_entity_type (
  id_entity_type INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(64) NOT NULL,
  title VARCHAR(150) NOT NULL,
  search_field_code VARCHAR(64) NULL,
  filter_field_code VARCHAR(64) NULL,
  price_field_code VARCHAR(64) NULL,
  stock_field_code VARCHAR(64) NULL,
  image_field_code VARCHAR(64) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id_entity_type),
  UNIQUE KEY uq_entity_type_code (code)
) ENGINE=InnoDB;

CREATE TABLE catalog_field (
  id_field INT UNSIGNED NOT NULL AUTO_INCREMENT,
  entity_type_id INT UNSIGNED NOT NULL,
  field_code VARCHAR(64) NOT NULL,
  title VARCHAR(120) NOT NULL,
  data_type ENUM('string','text','integer','decimal','date','image','boolean') NOT NULL,
  is_required TINYINT(1) NOT NULL DEFAULT 0,
  is_unique TINYINT(1) NOT NULL DEFAULT 0,
  max_length SMALLINT UNSIGNED NULL,
  min_number DECIMAL(12,2) NULL,
  max_number DECIMAL(12,2) NULL,
  default_value VARCHAR(255) NULL,
  display_in_form TINYINT(1) NOT NULL DEFAULT 1,
  display_in_card TINYINT(1) NOT NULL DEFAULT 1,
  sort_allowed TINYINT(1) NOT NULL DEFAULT 0,
  filter_allowed TINYINT(1) NOT NULL DEFAULT 0,
  search_allowed TINYINT(1) NOT NULL DEFAULT 0,
  is_system TINYINT(1) NOT NULL DEFAULT 0,
  is_computed TINYINT(1) NOT NULL DEFAULT 0,
  compute_expression VARCHAR(255) NULL,
  sort_weight SMALLINT NOT NULL DEFAULT 100,
  PRIMARY KEY (id_field),
  UNIQUE KEY uq_catalog_field_code (entity_type_id, field_code),
  CONSTRAINT fk_catalog_field_entity
    FOREIGN KEY (entity_type_id) REFERENCES catalog_entity_type(id_entity_type)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CHECK (max_length IS NULL OR max_length > 0),
  CHECK (min_number IS NULL OR max_number IS NULL OR min_number <= max_number)
) ENGINE=InnoDB;

CREATE TABLE catalog_item (
  id_item BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  entity_type_id INT UNSIGNED NOT NULL,
  article VARCHAR(80) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id_item),
  UNIQUE KEY uq_catalog_item_article (entity_type_id, article),
  CONSTRAINT fk_catalog_item_entity
    FOREIGN KEY (entity_type_id) REFERENCES catalog_entity_type(id_entity_type)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE catalog_item_value (
  id_value BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  item_id BIGINT UNSIGNED NOT NULL,
  field_id INT UNSIGNED NOT NULL,
  value_string VARCHAR(255) NULL,
  value_text TEXT NULL,
  value_int INT NULL,
  value_decimal DECIMAL(12,2) NULL,
  value_date DATE NULL,
  value_bool TINYINT(1) NULL,
  value_json JSON NULL,
  PRIMARY KEY (id_value),
  UNIQUE KEY uq_catalog_item_value (item_id, field_id),
  INDEX idx_value_string (value_string),
  INDEX idx_value_int (value_int),
  INDEX idx_value_decimal (value_decimal),
  CONSTRAINT fk_catalog_item_value_item
    FOREIGN KEY (item_id) REFERENCES catalog_item(id_item)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_catalog_item_value_field
    FOREIGN KEY (field_id) REFERENCES catalog_field(id_field)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE zakaz (
  order_number INT UNSIGNED NOT NULL,
  order_date DATE NOT NULL,
  delivery_date DATE NOT NULL,
  pickup_code VARCHAR(20) NOT NULL,
  order_status VARCHAR(50) NOT NULL DEFAULT 'Новый',
  id_points INT UNSIGNED NOT NULL,
  id_user INT UNSIGNED NULL,
  PRIMARY KEY (order_number),
  INDEX idx_zakaz_user (id_user),
  INDEX idx_zakaz_point (id_points),
  CONSTRAINT fk_zakaz_point
    FOREIGN KEY (id_points) REFERENCES pickup_points(id_points)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_zakaz_user
    FOREIGN KEY (id_user) REFERENCES `user`(id_user)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CHECK (delivery_date >= order_date)
) ENGINE=InnoDB;

CREATE TABLE order_items (
  id_items INT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_number INT UNSIGNED NOT NULL,
  entity_type_id INT UNSIGNED NOT NULL,
  article VARCHAR(80) NOT NULL,
  quantity INT UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (id_items),
  INDEX idx_order_items_order (order_number),
  INDEX idx_order_items_catalog (entity_type_id, article),
  CONSTRAINT fk_order_items_order
    FOREIGN KEY (order_number) REFERENCES zakaz(order_number)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_order_items_item
    FOREIGN KEY (entity_type_id, article) REFERENCES catalog_item(entity_type_id, article)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CHECK (quantity > 0)
) ENGINE=InnoDB;

INSERT INTO `user` (role, full_name, login, password) VALUES
('Администратор', 'Администратор системы', 'admin@example.com', 'admin'),
('Менеджер', 'Менеджер системы', 'manager@example.com', 'manager'),
('Авторизированный клиент', 'Клиент системы', 'client@example.com', 'client');

INSERT INTO pickup_points (address) VALUES
('г. Москва, ул. Центральная, 1'),
('г. Москва, ул. Северная, 15');

INSERT INTO catalog_entity_type
(code, title, search_field_code, filter_field_code, price_field_code, stock_field_code, image_field_code)
VALUES
('shoe_store', 'Магазин обуви', 'product_name', 'supplier', 'price', 'stock_quantity', 'image'),
('pet_store', 'Зоомагазин', 'product_name', 'supplier', 'price', 'stock_quantity', 'image'),
('printer_service', 'Ремонт и заправка принтеров', 'service_name', 'supplier', 'price', 'stock_quantity', 'image');

SET @shoe := (SELECT id_entity_type FROM catalog_entity_type WHERE code='shoe_store');
SET @pet := (SELECT id_entity_type FROM catalog_entity_type WHERE code='pet_store');
SET @printer := (SELECT id_entity_type FROM catalog_entity_type WHERE code='printer_service');

INSERT INTO catalog_field
(entity_type_id, field_code, title, data_type, is_required, is_unique, max_length, min_number, max_number,
 display_in_form, display_in_card, sort_allowed, filter_allowed, search_allowed, is_system, is_computed,
 compute_expression, sort_weight)
VALUES
(@shoe,'image','Изображение','image',0,0,255,NULL,NULL,1,1,0,0,0,0,0,NULL,10),
(@shoe,'article','Артикул','string',1,1,80,NULL,NULL,1,1,0,0,1,1,0,NULL,20),
(@shoe,'product_name','Название','string',1,0,150,NULL,NULL,1,1,0,0,1,0,0,NULL,30),
(@shoe,'price','Цена до скидки','decimal',1,0,NULL,0,999999.99,1,1,1,0,0,0,0,NULL,40),
(@shoe,'current_discount','Скидка, %','decimal',0,0,NULL,0,100,1,1,1,0,0,0,0,NULL,50),
(@shoe,'price_after_discount','Цена после скидки','decimal',0,0,NULL,0,999999.99,0,1,1,0,0,0,1,'price * (1 - current_discount / 100)',60),
(@shoe,'stock_quantity','Количество на складе','integer',1,0,NULL,0,999999,1,1,1,0,0,0,0,NULL,70),
(@shoe,'supplier','Поставщик','string',0,0,150,NULL,NULL,1,1,0,1,1,0,0,NULL,80),
(@shoe,'manufacturer','Производитель','string',0,0,150,NULL,NULL,1,1,0,0,1,0,0,NULL,90),
(@shoe,'category','Категория','string',0,0,120,NULL,NULL,1,1,0,1,1,0,0,NULL,100),
(@shoe,'unit','Единица измерения','string',0,0,30,NULL,NULL,1,1,0,0,0,0,0,NULL,110),
(@shoe,'description','Описание','text',0,0,NULL,NULL,NULL,1,1,0,0,1,0,0,NULL,120);

INSERT INTO catalog_field
(entity_type_id, field_code, title, data_type, is_required, is_unique, max_length, min_number, max_number,
 display_in_form, display_in_card, sort_allowed, filter_allowed, search_allowed, is_system, is_computed,
 compute_expression, sort_weight)
SELECT @pet, field_code, title, data_type, is_required, is_unique, max_length, min_number, max_number,
       display_in_form, display_in_card, sort_allowed, filter_allowed, search_allowed, is_system, is_computed,
       compute_expression, sort_weight
FROM catalog_field WHERE entity_type_id=@shoe;

INSERT INTO catalog_field
(entity_type_id, field_code, title, data_type, is_required, is_unique, max_length, min_number, max_number,
 display_in_form, display_in_card, sort_allowed, filter_allowed, search_allowed, is_system, is_computed,
 compute_expression, sort_weight)
VALUES
(@printer,'image','Изображение','image',0,0,255,NULL,NULL,1,1,0,0,0,0,0,NULL,10),
(@printer,'article','Код услуги','string',1,1,80,NULL,NULL,1,1,0,0,1,1,0,NULL,20),
(@printer,'service_name','Название услуги','string',1,0,150,NULL,NULL,1,1,0,0,1,0,0,NULL,30),
(@printer,'price','Цена','decimal',1,0,NULL,0,999999.99,1,1,1,0,0,0,0,NULL,40),
(@printer,'current_discount','Скидка, %','decimal',0,0,NULL,0,100,1,1,1,0,0,0,0,NULL,50),
(@printer,'price_after_discount','Цена со скидкой','decimal',0,0,NULL,0,999999.99,0,1,1,0,0,0,1,'price * (1 - current_discount / 100)',60),
(@printer,'stock_quantity','Остаток расходников','integer',0,0,NULL,0,999999,1,1,1,0,0,0,0,NULL,70),
(@printer,'supplier','Поставщик расходников','string',0,0,150,NULL,NULL,1,1,0,1,1,0,0,NULL,80),
(@printer,'category','Категория','string',0,0,120,NULL,NULL,1,1,0,1,1,0,0,NULL,90),
(@printer,'printer_type','Тип принтера','string',0,0,120,NULL,NULL,1,1,0,1,1,0,0,NULL,100),
(@printer,'unit','Единица','string',0,0,30,NULL,NULL,1,1,0,0,0,0,0,NULL,110),
(@printer,'description','Описание','text',0,0,NULL,NULL,NULL,1,1,0,0,1,0,0,NULL,120);

INSERT INTO catalog_item (entity_type_id, article) VALUES
(@shoe, 'SH-001'),
(@shoe, 'SH-002'),
(@shoe, 'SH-003');

INSERT INTO catalog_item_value (item_id, field_id, value_string, value_text, value_int, value_decimal)
SELECT ci.id_item, cf.id_field,
       CASE cf.field_code
         WHEN 'product_name' THEN 'Кроссовки демо'
         WHEN 'unit' THEN 'шт.'
         WHEN 'supplier' THEN 'Поставщик 1'
         WHEN 'manufacturer' THEN 'Производитель 1'
         WHEN 'category' THEN 'Кроссовки'
         WHEN 'image' THEN 'picture.png'
       END,
       CASE cf.field_code WHEN 'description' THEN 'Демонстрационная карточка товара' END,
       CASE cf.field_code WHEN 'stock_quantity' THEN 12 END,
       CASE cf.field_code WHEN 'price' THEN 3500.00 WHEN 'current_discount' THEN 10.00 END
FROM catalog_item ci
JOIN catalog_field cf ON cf.entity_type_id = ci.entity_type_id
WHERE ci.article='SH-001' AND cf.field_code IN
('product_name','unit','supplier','manufacturer','category','image','description','stock_quantity','price','current_discount');

INSERT INTO catalog_item_value (item_id, field_id, value_string, value_text, value_int, value_decimal)
SELECT ci.id_item, cf.id_field,
       CASE cf.field_code
         WHEN 'product_name' THEN 'Ботинки демо'
         WHEN 'unit' THEN 'шт.'
         WHEN 'supplier' THEN 'Поставщик 2'
         WHEN 'manufacturer' THEN 'Производитель 2'
         WHEN 'category' THEN 'Ботинки'
         WHEN 'image' THEN 'picture.png'
       END,
       CASE cf.field_code WHEN 'description' THEN 'Второй тестовый товар' END,
       CASE cf.field_code WHEN 'stock_quantity' THEN 4 END,
       CASE cf.field_code WHEN 'price' THEN 5200.00 WHEN 'current_discount' THEN 0.00 END
FROM catalog_item ci
JOIN catalog_field cf ON cf.entity_type_id = ci.entity_type_id
WHERE ci.article='SH-002' AND cf.field_code IN
('product_name','unit','supplier','manufacturer','category','image','description','stock_quantity','price','current_discount');

INSERT INTO catalog_item_value (item_id, field_id, value_string, value_text, value_int, value_decimal)
SELECT ci.id_item, cf.id_field,
       CASE cf.field_code
         WHEN 'product_name' THEN 'Сандалии демо'
         WHEN 'unit' THEN 'шт.'
         WHEN 'supplier' THEN 'Поставщик 1'
         WHEN 'manufacturer' THEN 'Производитель 3'
         WHEN 'category' THEN 'Сандалии'
         WHEN 'image' THEN 'picture.png'
       END,
       CASE cf.field_code WHEN 'description' THEN 'Третий тестовый товар' END,
       CASE cf.field_code WHEN 'stock_quantity' THEN 0 END,
       CASE cf.field_code WHEN 'price' THEN 2400.00 WHEN 'current_discount' THEN 20.00 END
FROM catalog_item ci
JOIN catalog_field cf ON cf.entity_type_id = ci.entity_type_id
WHERE ci.article='SH-003' AND cf.field_code IN
('product_name','unit','supplier','manufacturer','category','image','description','stock_quantity','price','current_discount');

CREATE OR REPLACE VIEW tovar AS
SELECT
  ci.article AS article,
  MAX(CASE WHEN cf.field_code='product_name' THEN civ.value_string END) AS product_name,
  MAX(CASE WHEN cf.field_code='unit' THEN civ.value_string END) AS unit,
  MAX(CASE WHEN cf.field_code='price' THEN civ.value_decimal END) AS price,
  MAX(CASE WHEN cf.field_code='supplier' THEN civ.value_string END) AS supplier,
  MAX(CASE WHEN cf.field_code='manufacturer' THEN civ.value_string END) AS manufacturer,
  MAX(CASE WHEN cf.field_code='category' THEN civ.value_string END) AS category,
  MAX(CASE WHEN cf.field_code='current_discount' THEN civ.value_decimal END) AS current_discount,
  MAX(CASE WHEN cf.field_code='stock_quantity' THEN civ.value_int END) AS stock_quantity,
  MAX(CASE WHEN cf.field_code='description' THEN civ.value_text END) AS description,
  MAX(CASE WHEN cf.field_code='image' THEN civ.value_string END) AS image
FROM catalog_item ci
JOIN catalog_entity_type cet ON cet.id_entity_type = ci.entity_type_id
LEFT JOIN catalog_item_value civ ON civ.item_id = ci.id_item
LEFT JOIN catalog_field cf ON cf.id_field = civ.field_id
WHERE cet.code = 'shoe_store'
GROUP BY ci.article;
