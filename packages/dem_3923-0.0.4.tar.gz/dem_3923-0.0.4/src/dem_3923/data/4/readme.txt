login: phpmyadmin
password: phpmyadmin

database: dem_DB
charset: utf16_general_ci

user
id_user INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY
role ENUM('Гость','Авторизированный клиент','Менеджер','Администратор') NOT NULL
full_name VARCHAR(150) NOT NULL
login VARCHAR(100) NOT NULL UNIQUE
password VARCHAR(100) NOT NULL

pickup_points
id_points INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY
address VARCHAR(255) NOT NULL UNIQUE

catalog_entity_type
id_entity_type INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY
code VARCHAR(64) NOT NULL UNIQUE
title VARCHAR(150) NOT NULL
search_field_code VARCHAR(64) NULL
filter_field_code VARCHAR(64) NULL
price_field_code VARCHAR(64) NULL
stock_field_code VARCHAR(64) NULL
image_field_code VARCHAR(64) NULL
is_active TINYINT(1) NOT NULL DEFAULT 1

catalog_field
id_field INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY
entity_type_id INT UNSIGNED NOT NULL
field_code VARCHAR(64) NOT NULL
title VARCHAR(120) NOT NULL
data_type ENUM('string','text','integer','decimal','date','image','boolean') NOT NULL
is_required TINYINT(1) NOT NULL DEFAULT 0
is_unique TINYINT(1) NOT NULL DEFAULT 0
max_length SMALLINT UNSIGNED NULL
min_number DECIMAL(12,2) NULL
max_number DECIMAL(12,2) NULL
default_value VARCHAR(255) NULL
display_in_form TINYINT(1) NOT NULL DEFAULT 1
display_in_card TINYINT(1) NOT NULL DEFAULT 1
sort_allowed TINYINT(1) NOT NULL DEFAULT 0
filter_allowed TINYINT(1) NOT NULL DEFAULT 0
search_allowed TINYINT(1) NOT NULL DEFAULT 0
is_system TINYINT(1) NOT NULL DEFAULT 0
is_computed TINYINT(1) NOT NULL DEFAULT 0
compute_expression VARCHAR(255) NULL
sort_weight SMALLINT NOT NULL DEFAULT 100

catalog_item
id_item BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY
entity_type_id INT UNSIGNED NOT NULL
article VARCHAR(80) NOT NULL
created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP

catalog_item_value
id_value BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY
item_id BIGINT UNSIGNED NOT NULL
field_id INT UNSIGNED NOT NULL
value_string VARCHAR(255) NULL
value_text TEXT NULL
value_int INT NULL
value_decimal DECIMAL(12,2) NULL
value_date DATE NULL
value_bool TINYINT(1) NULL
value_json JSON NULL

tovar
Представление для совместимости с темой магазин обуви:
article
product_name
unit
price
supplier
manufacturer
category
current_discount
stock_quantity
description
image

zakaz
order_number INT UNSIGNED NOT NULL PRIMARY KEY
order_date DATE NOT NULL
delivery_date DATE NOT NULL
pickup_code VARCHAR(20) NOT NULL
order_status VARCHAR(50) NOT NULL DEFAULT 'Новый'
id_points INT UNSIGNED NOT NULL
id_user INT UNSIGNED NULL

order_items
id_items INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY
order_number INT UNSIGNED NOT NULL
entity_type_id INT UNSIGNED NOT NULL
article VARCHAR(80) NOT NULL
quantity INT UNSIGNED NOT NULL DEFAULT 1
