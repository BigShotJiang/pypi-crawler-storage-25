from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QApplication,
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from database import Database
from settings import BASE_DIR


class FieldLayoutHelper(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.db = Database()
        self.fields: List[Dict[str, Any]] = []
        self.current_path: Path | None = None
        self.setWindowTitle("Настройка порядка полей")
        self.setMinimumSize(760, 560)
        self._setup_ui()
        self._load_entities()

    def _setup_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        main = QVBoxLayout(root)

        top = QHBoxLayout()
        self.entity_combo = QComboBox()
        self.load_fields_button = QPushButton("Загрузить поля из БД")
        self.open_button = QPushButton("Открыть JSON")
        self.save_button = QPushButton("Сохранить JSON")
        top.addWidget(QLabel("Тема:"))
        top.addWidget(self.entity_combo, stretch=1)
        top.addWidget(self.load_fields_button)
        top.addWidget(self.open_button)
        top.addWidget(self.save_button)
        main.addLayout(top)

        self.list_widget = QListWidget()
        self.list_widget.setDragDropMode(QListWidget.InternalMove)
        self.list_widget.setSelectionMode(QListWidget.SingleSelection)
        main.addWidget(self.list_widget, stretch=1)

        bottom = QHBoxLayout()
        self.up_button = QPushButton("Вверх")
        self.down_button = QPushButton("Вниз")
        bottom.addWidget(self.up_button)
        bottom.addWidget(self.down_button)
        bottom.addStretch()
        main.addLayout(bottom)

        hint = QLabel(
            "Галочка означает показ поля в карточке. "
            "Порядок строк в списке будет сохранён в JSON."
        )
        hint.setWordWrap(True)
        main.addWidget(hint)

        self.load_fields_button.clicked.connect(self.load_fields_from_db)
        self.open_button.clicked.connect(self.open_json)
        self.save_button.clicked.connect(self.save_json)
        self.up_button.clicked.connect(lambda: self.move_current(-1))
        self.down_button.clicked.connect(lambda: self.move_current(1))
        self.entity_combo.currentIndexChanged.connect(self.load_fields_from_db)

    def _load_entities(self) -> None:
        self.entity_combo.blockSignals(True)
        self.entity_combo.clear()
        for entity in self.db.get_entity_types():
            self.entity_combo.addItem(entity["title"], entity["code"])
        self.entity_combo.blockSignals(False)
        self.load_fields_from_db()

    def load_fields_from_db(self) -> None:
        code = self.entity_combo.currentData()
        if not code:
            return
        self.fields = self.db.get_fields(code)
        self._fill_list(self.fields)

    def _fill_list(self, fields: List[Dict[str, Any]], visible_map: Dict[str, bool] | None = None) -> None:
        self.list_widget.clear()
        visible_map = visible_map or {}
        for field in fields:
            item = QListWidgetItem(
                f"{field['field_code']} — {field['title']} — {field['data_type']}"
                + (" — вычисляемое" if field.get("is_computed") else "")
            )
            item.setData(Qt.UserRole, field)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsDragEnabled | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            checked = visible_map.get(field["field_code"], bool(field.get("display_in_card")))
            item.setCheckState(Qt.Checked if checked else Qt.Unchecked)
            self.list_widget.addItem(item)

    def open_json(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Открыть JSON",
            str(BASE_DIR / "configs"),
            "JSON (*.json)",
        )
        if not path:
            return
        self.current_path = Path(path)
        with self.current_path.open("r", encoding="utf-8") as file:
            config = json.load(file)

        code = config.get("entity_type_code") or self.entity_combo.currentData()
        index = self.entity_combo.findData(code)
        if index >= 0:
            self.entity_combo.setCurrentIndex(index)

        db_fields = {field["field_code"]: field for field in self.db.get_fields(code)}
        ordered_fields = []
        visible_map = {}
        for entry in config.get("card", []):
            field = db_fields.get(entry.get("field_code"))
            if field:
                ordered_fields.append(field)
                visible_map[field["field_code"]] = bool(entry.get("visible", True))

        used = {field["field_code"] for field in ordered_fields}
        for field in db_fields.values():
            if field["field_code"] not in used:
                ordered_fields.append(field)

        self.fields = ordered_fields
        self._fill_list(ordered_fields, visible_map)
        QMessageBox.information(self, "Готово", "JSON открыт")

    def save_json(self) -> None:
        code = self.entity_combo.currentData()
        fields = self._ordered_fields()
        entity = self.db.get_entity_type(code) or {}
        config = {
            "entity_type_code": code,
            "card": [
                {
                    "field_code": field["field_code"],
                    "title": field["title"],
                    "data_type": field["data_type"],
                    "visible": self._item_for_field(field)["checkState"] == Qt.Checked,
                }
                for field in fields
            ],
            "dialog": [
                {
                    "field_code": field["field_code"],
                    "title": field["title"],
                    "data_type": field["data_type"],
                    "visible": bool(field.get("display_in_form")),
                }
                for field in fields
                if not field.get("is_computed")
            ],
            "filter_field": entity.get("filter_field_code"),
            "search_fields": [field["field_code"] for field in fields if field.get("search_allowed")],
            "sort_options": [
                {"code": f"{field['field_code']}_asc", "title": f"{field['title']}: возрастание"}
                for field in fields if field.get("sort_allowed")
            ] + [
                {"code": f"{field['field_code']}_desc", "title": f"{field['title']}: убывание"}
                for field in fields if field.get("sort_allowed")
            ],
        }

        suggested = self.current_path or (BASE_DIR / "configs" / f"field_order_{code}.json")
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Сохранить JSON",
            str(suggested),
            "JSON (*.json)",
        )
        if not path:
            return
        self.current_path = Path(path)
        with self.current_path.open("w", encoding="utf-8") as file:
            json.dump(config, file, ensure_ascii=False, indent=2)
        QMessageBox.information(self, "Готово", f"Сохранено: {self.current_path}")

    def _ordered_fields(self) -> List[Dict[str, Any]]:
        result = []
        for i in range(self.list_widget.count()):
            result.append(self.list_widget.item(i).data(Qt.UserRole))
        return result

    def _item_for_field(self, field: Dict[str, Any]) -> Dict[str, Any]:
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item.data(Qt.UserRole)["field_code"] == field["field_code"]:
                return {"item": item, "checkState": item.checkState()}
        return {"item": None, "checkState": Qt.Unchecked}

    def move_current(self, direction: int) -> None:
        row = self.list_widget.currentRow()
        if row < 0:
            return
        new_row = row + direction
        if new_row < 0 or new_row >= self.list_widget.count():
            return
        item = self.list_widget.takeItem(row)
        self.list_widget.insertItem(new_row, item)
        self.list_widget.setCurrentRow(new_row)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = FieldLayoutHelper()
    window.show()
    sys.exit(app.exec_())
