DROP DATABASE IF EXISTS dem_DB;
CREATE DATABASE dem_DB CHARACTER SET utf16 COLLATE utf16_general_ci;
USE dem_DB;

CREATE TABLE `user` (
  id_user INT UNSIGNED NOT NULL AUTO_INCREMENT,
  role VARCHAR(40) NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  login VARCHAR(120) NOT NULL,
  password VARCHAR(120) NOT NULL,
  PRIMARY KEY (id_user),
  UNIQUE KEY uq_user_login (login),
  CHECK (role IN ('Гость','Авторизированный клиент','Менеджер','Администратор'))
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

CREATE TABLE pickup_points (
  id_points INT UNSIGNED NOT NULL AUTO_INCREMENT,
  address VARCHAR(255) NOT NULL,
  PRIMARY KEY (id_points),
  UNIQUE KEY uq_pickup_address (address)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

CREATE TABLE tovar (
  article VARCHAR(50) NOT NULL,
  product_name VARCHAR(255) NOT NULL,
  unit VARCHAR(20) NOT NULL DEFAULT 'шт.',
  price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  supplier VARCHAR(150) NULL,
  manufacturer VARCHAR(150) NULL,
  category VARCHAR(120) NULL,
  current_discount DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  stock_quantity INT NOT NULL DEFAULT 0,
  description TEXT NULL,
  image VARCHAR(255) NULL,
  PRIMARY KEY (article),
  INDEX ix_tovar_name (product_name),
  INDEX ix_tovar_supplier (supplier),
  CHECK (price >= 0),
  CHECK (current_discount BETWEEN 0 AND 100),
  CHECK (stock_quantity >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

CREATE TABLE zakaz (
  order_number INT UNSIGNED NOT NULL,
  order_date DATE NOT NULL,
  delivery_date DATE NULL,
  pickup_code VARCHAR(20) NOT NULL,
  order_status VARCHAR(50) NOT NULL DEFAULT 'Новый',
  id_points INT UNSIGNED NULL,
  id_user INT UNSIGNED NULL,
  PRIMARY KEY (order_number),
  INDEX ix_zakaz_user (id_user),
  INDEX ix_zakaz_point (id_points),
  CONSTRAINT fk_zakaz_user FOREIGN KEY (id_user) REFERENCES `user`(id_user)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT fk_zakaz_point FOREIGN KEY (id_points) REFERENCES pickup_points(id_points)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

CREATE TABLE order_items (
  id_items INT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_number INT UNSIGNED NOT NULL,
  article VARCHAR(50) NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  PRIMARY KEY (id_items),
  INDEX ix_items_order (order_number),
  INDEX ix_items_article (article),
  CONSTRAINT fk_items_order FOREIGN KEY (order_number) REFERENCES zakaz(order_number)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_items_article FOREIGN KEY (article) REFERENCES tovar(article)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CHECK (quantity > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

CREATE TABLE app_entities (
  entity_key VARCHAR(60) NOT NULL,
  table_name VARCHAR(64) NOT NULL,
  pk_field VARCHAR(64) NOT NULL,
  title_field VARCHAR(64) NOT NULL,
  image_field VARCHAR(64) NULL,
  price_field VARCHAR(64) NULL,
  discount_field VARCHAR(64) NULL,
  stock_field VARCHAR(64) NULL,
  filter_field VARCHAR(64) NULL,
  search_fields TEXT NULL,
  sortable_fields TEXT NULL,
  PRIMARY KEY (entity_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

INSERT INTO app_entities VALUES
('tovar','tovar','article','product_name','image','price','current_discount','stock_quantity','supplier',
 'product_name,category,manufacturer,supplier','product_name,price,stock_quantity');

INSERT INTO `user` (role, full_name, login, password) VALUES
('Администратор','Администратор','94d5ous@gmail.com','uzWC67'),
('Менеджер','Менеджер','1diph5e@tutanota.com','8ntwUp'),
('Авторизированный клиент','Клиент','5d4zbu@tutanota.com','rwVDh9');
