import json, sys
from pathlib import Path
from PyQt5.QtWidgets import *
from database import Database

class Editor(QMainWindow):
    def __init__(self):
        super().__init__(); self.db=Database(); self.path="field_config.json"; self.cfg={}
        self.setWindowTitle("Порядок полей"); self.resize(760,520)
        w=QWidget(); self.setCentralWidget(w); g=QGridLayout(w)
        self.tables=QComboBox(); self.tables.addItems(self.db.tables()); g.addWidget(QLabel("Таблица"),0,0); g.addWidget(self.tables,0,1)
        self.entity=QLineEdit("tovar"); self.title=QLineEdit("Приложение"); g.addWidget(QLabel("Ключ"),1,0); g.addWidget(self.entity,1,1); g.addWidget(QLabel("Заголовок"),2,0); g.addWidget(self.title,2,1)
        self.pk=QComboBox(); self.name=QComboBox(); self.image=QComboBox(); self.price=QComboBox(); self.discount=QComboBox(); self.stock=QComboBox(); self.filter=QComboBox()
        for i,(t,c) in enumerate((("PK",self.pk),("Название",self.name),("Фото",self.image),("Цена",self.price),("Скидка",self.discount),("Остаток",self.stock),("Фильтр",self.filter)),3):
            g.addWidget(QLabel(t),i,0); g.addWidget(c,i,1)
        self.list=QListWidget(); self.list.setDragDropMode(QAbstractItemView.InternalMove); g.addWidget(self.list,0,2,10,1)
        for txt,fn in (("Открыть json",self.open),("Сохранить json",self.save),("Поля из БД",self.load_fields)):
            b=QPushButton(txt); b.clicked.connect(fn); g.addWidget(b)
        self.tables.currentIndexChanged.connect(self.load_fields); self.load_fields()

    def load_fields(self):
        t=self.tables.currentText(); fs=self.db.fields(t); names=[f["COLUMN_NAME"] for f in fs]
        for c in (self.pk,self.name,self.image,self.price,self.discount,self.stock,self.filter):
            c.clear(); c.addItem(""); c.addItems(names)
        self.list.clear()
        for f in fs:
            self.list.addItem(f'{f["COLUMN_NAME"]} | {f["DATA_TYPE"]} | null={f["IS_NULLABLE"]} | key={f["COLUMN_KEY"]}')

    def open(self):
        p,_=QFileDialog.getOpenFileName(self,"Открыть",self.path,"JSON (*.json)")
        if not p: return
        self.path=p; self.cfg=json.loads(Path(p).read_text(encoding="utf-8"))
        self.tables.setCurrentText(self.cfg.get("table","")); self.entity.setText(self.cfg.get("entity_key","tovar")); self.title.setText(self.cfg.get("title",""))
        for c,k in ((self.pk,"pk_field"),(self.name,"title_field"),(self.image,"image_field"),(self.price,"price_field"),(self.discount,"discount_field"),(self.stock,"stock_field"),(self.filter,"filter_field")):
            c.setCurrentText(self.cfg.get(k,""))
        self.list.clear()
        allf={x["COLUMN_NAME"]:x for x in self.db.fields(self.tables.currentText())}
        keys=[f["key"] for f in self.cfg.get("fields",[])] or list(allf)
        for k in keys:
            f=allf.get(k,{})
            self.list.addItem(f'{k} | {f.get("DATA_TYPE","computed")} | null={f.get("IS_NULLABLE","")} | key={f.get("COLUMN_KEY","")}')

    def save(self):
        fields=[]
        for i in range(self.list.count()):
            k=self.list.item(i).text().split("|")[0].strip()
            fields.append({"key":k,"label":k,"type":"image" if k==self.image.currentText() else "text"})
        cfg={
            "title":self.title.text(), "table":self.tables.currentText(), "pk_field":self.pk.currentText(),
            "title_field":self.name.currentText(), "image_field":self.image.currentText(),
            "price_field":self.price.currentText(), "discount_field":self.discount.currentText(),
            "stock_field":self.stock.currentText(), "filter_field":self.filter.currentText(),
            "search_fields":[x for x in [self.name.currentText(), self.filter.currentText()] if x],
            "sortable_fields":[x for x in [self.name.currentText(), self.price.currentText(), self.stock.currentText()] if x],
            "fields":fields}
        p,_=QFileDialog.getSaveFileName(self,"Сохранить",self.path,"JSON (*.json)")
        if p: Path(p).write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding="utf-8")

if __name__=="__main__":
    app=QApplication(sys.argv); w=Editor(); w.show(); sys.exit(app.exec_())
