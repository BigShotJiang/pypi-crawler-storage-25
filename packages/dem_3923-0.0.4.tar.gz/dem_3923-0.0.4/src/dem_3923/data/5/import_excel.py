import argparse
from openpyxl import load_workbook
from database import Database

def norm(x): return str(x or "").strip()

p=argparse.ArgumentParser()
p.add_argument("xlsx"); p.add_argument("table")
p.add_argument("--sheet"); p.add_argument("--truncate", action="store_true")
args=p.parse_args()

db=Database(); wb=load_workbook(args.xlsx, data_only=True); ws=wb[args.sheet] if args.sheet else wb.active
cols={f["COLUMN_NAME"]:f for f in db.fields(args.table)}
pk=db.pk(args.table)
headers=[norm(c.value) for c in next(ws.iter_rows(min_row=1,max_row=1))]
known=[h for h in headers if h in cols and "auto_increment" not in (cols[h]["EXTRA"] or "")]
if args.truncate: db.exec(f"DELETE FROM `{args.table}`")
n=0
for row in ws.iter_rows(min_row=2, values_only=True):
    data={h:v for h,v in zip(headers,row) if h in known and v is not None}
    if not data: continue
    db.save_row(args.table, data, pk, None); n+=1
print(f"Импортировано: {n}")
