1. Скопируй db_config.json.sample в db_config.json и пропиши пароль MySQL.
2. Создай БД: mysql -u root -p < schema.sql
3. Установи библиотеки: pip install -r requirements.txt
4. Запуск приложения: python main.py
5. Импорт Excel: python import_excel.py Tovar.xlsx tovar
6. Настройка порядка полей: python field_order_editor.py
