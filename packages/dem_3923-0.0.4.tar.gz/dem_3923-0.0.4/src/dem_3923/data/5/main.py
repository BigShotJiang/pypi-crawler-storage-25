import json, os, sys
from pathlib import Path
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QFont
from PyQt5.QtWidgets import *
from database import Database

CFG_PATH = "field_config.json"

def load_cfg(): return json.loads(Path(CFG_PATH).read_text(encoding="utf-8"))

class Login(QMainWindow):
    def __init__(self):
        super().__init__(); self.db = Database(); self.setWindowTitle("Авторизация"); self.resize(420,260)
        w=QWidget(); self.setCentralWidget(w); l=QVBoxLayout(w); l.setAlignment(Qt.AlignCenter)
        self.login=QLineEdit(); self.login.setPlaceholderText("Логин")
        self.pwd=QLineEdit(); self.pwd.setEchoMode(QLineEdit.Password); self.pwd.setPlaceholderText("Пароль")
        b=QPushButton("Войти"); g=QPushButton("Войти как гость")
        for x in (QLabel("Авторизация"), self.login, self.pwd, b, g): l.addWidget(x)
        b.clicked.connect(self.enter); g.clicked.connect(self.guest)

    def enter(self):
        u = self.db.get_user(self.login.text(), self.pwd.text())
        if not u: QMessageBox.warning(self, "Ошибка", "Неверный логин или пароль"); return
        self.open(u)

    def guest(self): self.open({"id_user":0,"role":"Гость","full_name":"Гость"})

    def open(self, u):
        self.hide(); self.win = App(u, self); self.win.show()

class Card(QFrame):
    def __init__(self, row, cfg, is_admin, db, parent):
        super().__init__(); self.row=row; self.cfg=cfg; self.db=db; self.parent=parent
        self.setFrameShape(QFrame.Box); h=QHBoxLayout(self); info=QVBoxLayout(); h.addLayout(info)
        for f in cfg["fields"]:
            k=f["key"]; v=self.value(k); label=f.get("label",k)
            if f.get("type")=="image" or k==cfg.get("image_field"):
                p = str(row.get(k) or "picture.png"); p = p if os.path.exists(p) else os.path.join("images",p)
                img=QLabel(); img.setFixedSize(100,100); img.setPixmap(QPixmap(p).scaled(95,95,Qt.KeepAspectRatio)); h.insertWidget(0,img); continue
            if v in (None,""): continue
            q=QLabel(f"{label}: {v}"); 
            if k==cfg.get("title_field"): q.setFont(QFont("Times New Roman",12,QFont.Bold))
            info.addWidget(q)
        info.addStretch()
        if is_admin:
            box=QVBoxLayout(); h.addLayout(box)
            for text, fn in (("Изменить", self.edit), ("Удалить", self.delete)):
                b=QPushButton(text); b.clicked.connect(fn); box.addWidget(b)

    def value(self, k):
        if k == "_discount_price":
            p=float(self.row.get(self.cfg.get("price_field")) or 0); d=float(self.row.get(self.cfg.get("discount_field")) or 0)
            return round(p*(1-d/100),2)
        return self.row.get(k)

    def edit(self): self.parent.edit_row(self.row)
    def delete(self): self.parent.delete_row(self.row)

class RowDialog(QDialog):
    def __init__(self, fields, row=None, parent=None):
        super().__init__(parent); self.setWindowTitle("Данные"); self.ed={}
        form=QFormLayout(self)
        for f in fields:
            if "auto_increment" in (f["EXTRA"] or ""): continue
            k=f["COLUMN_NAME"]; e=QLineEdit(str((row or {}).get(k) or ""))
            if row and f["COLUMN_KEY"]=="PRI": e.setReadOnly(True)
            self.ed[k]=e; form.addRow(k, e)
        box=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel)
        box.accepted.connect(self.accept); box.rejected.connect(self.reject); form.addRow(box)
    def data(self): return {k:e.text().strip() for k,e in self.ed.items()}

class App(QMainWindow):
    def __init__(self, user, login):
        super().__init__(); self.user=user; self.login=login; self.db=Database(); self.cfg=load_cfg()
        self.table=self.cfg["table"]; self.pk=self.cfg.get("pk_field") or self.db.pk(self.table)
        self.setWindowTitle(self.cfg.get("title","Приложение")); self.resize(980,700)
        w=QWidget(); self.setCentralWidget(w); v=QVBoxLayout(w); top=QHBoxLayout(); v.addLayout(top)
        top.addWidget(QLabel(user["full_name"])); top.addStretch()
        self.search=QLineEdit(); self.search.setPlaceholderText("Поиск"); top.addWidget(self.search)
        self.filt=QComboBox(); top.addWidget(self.filt)
        self.sort=QComboBox(); top.addWidget(self.sort)
        self.add=QPushButton("Добавить"); top.addWidget(self.add)
        out=QPushButton("Выход"); top.addWidget(out)
        self.area=QScrollArea(); self.area.setWidgetResizable(True); self.cont=QWidget(); self.lst=QVBoxLayout(self.cont); self.area.setWidget(self.cont); v.addWidget(self.area)
        self.admin=user["role"]=="Администратор"; power=user["role"] in ("Менеджер","Администратор")
        for x in (self.search,self.filt,self.sort): x.setVisible(power)
        self.add.setVisible(self.admin)
        out.clicked.connect(self.exit); self.add.clicked.connect(lambda:self.edit_row(None))
        self.search.textChanged.connect(self.load); self.filt.currentIndexChanged.connect(self.load); self.sort.currentIndexChanged.connect(self.load)
        self.fill_controls(); self.load()

    def fill_controls(self):
        self.filt.clear(); self.filt.addItem("Все", None)
        for x in self.db.distinct(self.table, self.cfg.get("filter_field","")): self.filt.addItem(str(x), x)
        self.sort.clear(); self.sort.addItem("Без сортировки", None)
        for f in self.cfg.get("sortable_fields",[]): self.sort.addItem(f+" ↑", f+":ASC"); self.sort.addItem(f+" ↓", f+":DESC")

    def load(self):
        while self.lst.count():
            it=self.lst.takeAt(0)
            if it.widget(): it.widget().deleteLater()
        rows=self.db.select(self.table,self.cfg,self.search.text().strip(),self.filt.currentData(),self.sort.currentData())
        for r in rows: self.lst.addWidget(Card(r,self.cfg,self.admin,self.db,self))
        self.lst.addStretch()

    def edit_row(self, row):
        d=RowDialog(self.db.fields(self.table), row, self)
        if d.exec_()==QDialog.Accepted:
            self.db.save_row(self.table, d.data(), self.pk, None if row is None else row[self.pk])
            self.fill_controls(); self.load()

    def delete_row(self, row):
        if QMessageBox.question(self,"Удаление","Удалить запись?")==QMessageBox.Yes:
            try: self.db.delete_row(self.table,self.pk,row[self.pk]); self.load()
            except Exception as e: QMessageBox.warning(self,"Ошибка",str(e))

    def exit(self):
        self.close(); self.login.show()

if __name__ == "__main__":
    app=QApplication(sys.argv); w=Login(); w.show(); sys.exit(app.exec_())
