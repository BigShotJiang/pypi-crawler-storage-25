import json, pymysql
from pathlib import Path

def cfg(path="db_config.json"):
    p = Path(path)
    if not p.exists(): p = Path("db_config.json.sample")
    return json.loads(p.read_text(encoding="utf-8"))

def qi(name):
    return "`" + str(name).replace("`", "``") + "`"

class Database:
    def __init__(self, path="db_config.json"):
        c = cfg(path)
        self.connection = pymysql.connect(
            host=c["host"], user=c["user"], password=c["password"],
            database=c["database"], charset=c.get("charset","utf8mb4"),
            cursorclass=pymysql.cursors.DictCursor, autocommit=False)

    def is_connected(self): return self.connection.open

    def rows(self, sql, args=()):
        with self.connection.cursor() as cur:
            cur.execute(sql, args)
            return cur.fetchall()

    def one(self, sql, args=()):
        r = self.rows(sql, args)
        return r[0] if r else None

    def exec(self, sql, args=()):
        with self.connection.cursor() as cur:
            cur.execute(sql, args)
        self.connection.commit()

    def get_user(self, login, password):
        return self.one("SELECT * FROM `user` WHERE login=%s AND password=%s", (login, password))

    def tables(self):
        return [r["TABLE_NAME"] for r in self.rows(
            "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() ORDER BY TABLE_NAME")]

    def fields(self, table):
        return self.rows("""
            SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT,
                   CHARACTER_MAXIMUM_LENGTH, COLUMN_KEY, EXTRA, ORDINAL_POSITION
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s
            ORDER BY ORDINAL_POSITION""", (table,))

    def pk(self, table):
        for f in self.fields(table):
            if f["COLUMN_KEY"] == "PRI": return f["COLUMN_NAME"]
        return self.fields(table)[0]["COLUMN_NAME"]

    def _cols(self, table): return {f["COLUMN_NAME"]: f for f in self.fields(table)}

    def select(self, table, cfg, search="", filt=None, sort=None):
        cols = self._cols(table); where=[]; args=[]
        ss = [s for s in cfg.get("search_fields", []) if s in cols]
        if search and ss:
            where.append("(" + " OR ".join(qi(s)+" LIKE %s" for s in ss) + ")")
            args += [f"%{search}%"] * len(ss)
        ff = cfg.get("filter_field")
        if filt and ff in cols:
            where.append(qi(ff)+"=%s"); args.append(filt)
        order = qi(cfg.get("title_field", self.pk(table)))
        if sort:
            name, direction = sort.split(":")
            if name in cols and direction in ("ASC","DESC"): order = qi(name)+" "+direction
        sql = "SELECT * FROM " + qi(table)
        if where: sql += " WHERE " + " AND ".join(where)
        return self.rows(sql + " ORDER BY " + order, args)

    def distinct(self, table, field):
        if field not in self._cols(table): return []
        return [r[field] for r in self.rows(
            f"SELECT DISTINCT {qi(field)} FROM {qi(table)} WHERE {qi(field)} IS NOT NULL AND {qi(field)}<>'' ORDER BY {qi(field)}")]

    def save_row(self, table, data, pk=None, old_pk=None):
        cols = self._cols(table)
        data = {k: (None if v == "" and cols[k]["IS_NULLABLE"] == "YES" else v)
                for k, v in data.items() if k in cols and "auto_increment" not in (cols[k]["EXTRA"] or "")}
        pk = pk or self.pk(table)
        if old_pk is None:
            names = list(data)
            sql = f"INSERT INTO {qi(table)} ({','.join(qi(n) for n in names)}) VALUES ({','.join(['%s']*len(names))})"
            self.exec(sql, [data[n] for n in names]); return
        names = [n for n in data if n != pk]
        sql = f"UPDATE {qi(table)} SET " + ",".join(qi(n)+"=%s" for n in names) + f" WHERE {qi(pk)}=%s"
        self.exec(sql, [data[n] for n in names] + [old_pk])

    def delete_row(self, table, pk, value):
        self.exec(f"DELETE FROM {qi(table)} WHERE {qi(pk)}=%s", (value,))
