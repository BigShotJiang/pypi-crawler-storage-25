CREATE DATABASE IF NOT EXISTS shoe_exam
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE shoe_exam;

CREATE TABLE roles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(30) NOT NULL UNIQUE
);

INSERT INTO roles (id, name) VALUES
(1, 'client'),
(2, 'manager'),
(3, 'admin');

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    login VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role_id INT NOT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

INSERT INTO users (login, password, full_name, role_id) VALUES
('client', '123', 'Иван Клиент', 1),
('manager', '123', 'Мария Менеджер', 2),
('admin', '123', 'Анна Администратор', 3);

CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE manufacturers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE suppliers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL
);

INSERT INTO categories (name) VALUES
('Кроссовки'),
('Ботинки'),
('Туфли');

INSERT INTO manufacturers (name) VALUES
('Nike'),
('Adidas'),
('Ecco');

INSERT INTO suppliers (name) VALUES
('ВсеПоставка'),
('ОбувьСклад'),
('ИмпортШуз');

CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    image_path VARCHAR(255),
    name VARCHAR(150) NOT NULL,
    category_id INT NOT NULL,
    description TEXT,
    manufacturer_id INT NOT NULL,
    supplier_id INT NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    unit VARCHAR(30) NOT NULL DEFAULT 'пара',
    stock INT NOT NULL DEFAULT 0,
    discount DECIMAL(5,2) NOT NULL DEFAULT 0,
    FOREIGN KEY (category_id) REFERENCES categories(id),
    FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id)
);

INSERT INTO products
(image_path, name, category_id, description, manufacturer_id, supplier_id, price, unit, stock, discount)
VALUES
(NULL, 'Кроссовки Air Run', 1, 'Лёгкие кроссовки для повседневной носки', 1, 1, 5990.00, 'пара', 10, 10),
(NULL, 'Ботинки Winter Pro', 2, 'Зимние ботинки с утеплителем', 3, 2, 8490.00, 'пара', 0, 5),
(NULL, 'Кроссовки Street Max', 1, 'Спортивная модель со скидкой', 2, 3, 7290.00, 'пара', 4, 20);

CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);