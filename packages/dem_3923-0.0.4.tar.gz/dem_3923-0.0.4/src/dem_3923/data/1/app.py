# app.py
# Минимальное приложение для демо-экзамена: авторизация, список товаров,
# поиск/фильтр/сортировка, добавление, редактирование, удаление.

import html
import os
import shutil
import sys
from pathlib import Path
from uuid import uuid4

import pymysql
from pymysql.cursors import DictCursor
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

# Настройки подключения к MySQL.
# Если в phpMyAdmin другой пользователь или пароль, меняй здесь.
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "shoes_exam",
    "charset": "utf8mb4",
    "cursorclass": DictCursor,
    "autocommit": False,
}

APP_DIR = Path(__file__).resolve().parent
RESOURCE_DIR = APP_DIR / "resources"
PRODUCT_IMAGE_DIR = RESOURCE_DIR / "products"
PLACEHOLDER_IMAGE = RESOURCE_DIR / "picture.png"
PRODUCT_IMAGE_DIR.mkdir(parents=True, exist_ok=True)


def get_connection():
    """Открывает соединение с базой данных."""
    return pymysql.connect(**DB_CONFIG)


def fetch_all(query, params=None):
    """Выполняет SELECT и возвращает список строк как словари."""
    with get_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(query, params or ())
            return cursor.fetchall()


def fetch_one(query, params=None):
    """Выполняет SELECT и возвращает одну строку или None."""
    with get_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(query, params or ())
            return cursor.fetchone()


def execute_query(query, params=None):
    """Выполняет INSERT/UPDATE/DELETE и сохраняет изменения."""
    with get_connection() as connection:
        try:
            with connection.cursor() as cursor:
                cursor.execute(query, params or ())
            connection.commit()
        except Exception:
            connection.rollback()
            raise


def money(value):
    """Красиво выводит цену: 4500.00 -> 4 500.00."""
    return f"{float(value):,.2f}".replace(",", " ")


def product_final_price(product):
    """Считает цену с учётом скидки."""
    price = float(product["price"])
    discount = int(product["discount"] or 0)
    return price * (100 - discount) / 100


class ProductCard(QWidget):
    """Виджет одной карточки товара в списке."""

    def __init__(self, product):
        super().__init__()
        self.product = product

        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(12)

        image_label = QLabel()
        image_label.setFixedSize(120, 90)
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        image_label.setText("Фото")

        image_path = product.get("image_path")
        if image_path:
            image_file = APP_DIR / image_path
        else:
            image_file = PLACEHOLDER_IMAGE

        if image_file.exists():
            pixmap = QPixmap(str(image_file))
            pixmap = pixmap.scaled(
                120,
                90,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            image_label.setPixmap(pixmap)

        main_layout.addWidget(image_label)

        category = html.escape(product["category_name"])
        name = html.escape(product["name"])
        description = html.escape(product.get("description") or "")
        manufacturer = html.escape(product["manufacturer_name"])
        supplier = html.escape(product["supplier_name"])
        unit = html.escape(product["unit_name"])

        old_price = money(product["price"])
        new_price = money(product_final_price(product))

        if int(product["discount"] or 0) > 0:
            price_html = (
                f"<span style='color:red; text-decoration: line-through;'>{old_price}</span> "
                f"<span style='color:black;'>{new_price}</span>"
            )
        else:
            price_html = f"<span style='color:black;'>{old_price}</span>"

        info = QLabel(
            f"<b>{category} | {name}</b><br>"
            f"{description}<br>"
            f"Производитель: {manufacturer}<br>"
            f"Поставщик: {supplier}<br>"
            f"Цена: {price_html}<br>"
            f"Единица измерения: {unit}<br>"
            f"Количество на складе: {product['quantity']}"
        )
        info.setWordWrap(True)
        main_layout.addWidget(info, stretch=1)

        discount_label = QLabel(f"Действующая\nскидка\n{product['discount']}%")
        discount_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        discount_label.setFixedWidth(110)
        main_layout.addWidget(discount_label)

        # По заданию: скидка больше 15% — зелёный фон, нет на складе — голубой фон.
        if int(product["quantity"]) <= 0:
            self.setStyleSheet("background-color: #ADD8E6;")
        elif int(product["discount"] or 0) > 15:
            self.setStyleSheet("background-color: #2E8B57;")
        else:
            self.setStyleSheet("background-color: white;")


class LoginWindow(QMainWindow):
    """Первое окно приложения: вход или просмотр как гость."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("ООО Обувь — авторизация")
        self.resize(420, 220)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        title = QLabel("ООО «Обувь»")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size: 20px; font-weight: bold;")
        layout.addWidget(title)

        self.login_input = QLineEdit()
        self.login_input.setPlaceholderText("Логин")
        layout.addWidget(self.login_input)

        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Пароль")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(self.password_input)

        login_button = QPushButton("Войти")
        guest_button = QPushButton("Просмотр товаров как гость")
        layout.addWidget(login_button)
        layout.addWidget(guest_button)

        login_button.clicked.connect(self.try_login)
        guest_button.clicked.connect(self.open_as_guest)

    def try_login(self):
        """Проверяет логин и пароль в таблице users."""
        login = self.login_input.text().strip()
        password = self.password_input.text().strip()

        user = fetch_one(
            """
            SELECT users.id, users.full_name, roles.name AS role_name
            FROM users
            JOIN roles ON roles.id = users.role_id
            WHERE users.login = %s AND users.password = %s
            """,
            (login, password),
        )

        if user is None:
            QMessageBox.warning(self, "Ошибка входа", "Неверный логин или пароль.")
            return

        self.main_window = MainWindow(user["role_name"], user["full_name"])
        self.main_window.show()
        self.close()

    def open_as_guest(self):
        """Открывает список товаров без авторизации."""
        self.main_window = MainWindow("guest", "Гость")
        self.main_window.show()
        self.close()


class MainWindow(QMainWindow):
    """Главное окно со списком товаров."""

    def __init__(self, role_name, full_name):
        super().__init__()
        self.role_name = role_name
        self.full_name = full_name
        self.setWindowTitle("ООО Обувь — список товаров")
        self.resize(980, 650)

        self.can_search = role_name in ("manager", "admin")
        self.can_edit = role_name == "admin"

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        top_layout = QHBoxLayout()
        layout.addLayout(top_layout)

        title = QLabel("Список товаров")
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        top_layout.addWidget(title)
        top_layout.addStretch()

        user_label = QLabel(f"{self.full_name} ({self.role_name})")
        top_layout.addWidget(user_label)

        exit_button = QPushButton("Выйти")
        exit_button.clicked.connect(self.logout)
        top_layout.addWidget(exit_button)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Поиск по товарам")
        self.supplier_combo = QComboBox()
        self.sort_combo = QComboBox()
        self.sort_combo.addItem("Количество: без сортировки", "none")
        self.sort_combo.addItem("Количество: по возрастанию", "asc")
        self.sort_combo.addItem("Количество: по убыванию", "desc")

        controls = QHBoxLayout()
        layout.addLayout(controls)
        controls.addWidget(self.search_input)
        controls.addWidget(self.supplier_combo)
        controls.addWidget(self.sort_combo)

        self.add_button = QPushButton("Добавить товар")
        self.edit_button = QPushButton("Редактировать")
        self.delete_button = QPushButton("Удалить")
        controls.addWidget(self.add_button)
        controls.addWidget(self.edit_button)
        controls.addWidget(self.delete_button)

        self.search_input.setVisible(self.can_search)
        self.supplier_combo.setVisible(self.can_search)
        self.sort_combo.setVisible(self.can_search)
        self.add_button.setVisible(self.can_edit)
        self.edit_button.setVisible(self.can_edit)
        self.delete_button.setVisible(self.can_edit)

        self.product_list = QListWidget()
        layout.addWidget(self.product_list)

        self.search_input.textChanged.connect(self.refresh_products)
        self.supplier_combo.currentIndexChanged.connect(self.refresh_products)
        self.sort_combo.currentIndexChanged.connect(self.refresh_products)
        self.add_button.clicked.connect(self.add_product)
        self.edit_button.clicked.connect(self.edit_product)
        self.delete_button.clicked.connect(self.delete_product)
        self.product_list.itemDoubleClicked.connect(lambda item: self.edit_product())

        self.load_suppliers()
        self.refresh_products()

    def logout(self):
        """Возвращает пользователя на окно авторизации."""
        self.login_window = LoginWindow()
        self.login_window.show()
        self.close()

    def load_suppliers(self):
        """Загружает поставщиков в выпадающий список."""
        self.supplier_combo.blockSignals(True)
        self.supplier_combo.clear()
        self.supplier_combo.addItem("Все поставщики", 0)
        for row in fetch_all("SELECT id, name FROM suppliers ORDER BY name"):
            self.supplier_combo.addItem(row["name"], row["id"])
        self.supplier_combo.blockSignals(False)

    def refresh_products(self):
        """Перечитывает товары из БД с учётом поиска, фильтра и сортировки."""
        search_text = self.search_input.text().strip() if self.can_search else ""
        search_pattern = f"%{search_text}%"
        supplier_id = self.supplier_combo.currentData() if self.can_search else 0
        supplier_id = supplier_id or 0

        order_by = "p.id"
        if self.can_search:
            sort_mode = self.sort_combo.currentData()
            if sort_mode == "asc":
                order_by = "p.quantity ASC"
            elif sort_mode == "desc":
                order_by = "p.quantity DESC"

        products = fetch_all(
            f"""
            SELECT
                p.id,
                p.name,
                p.description,
                p.price,
                p.quantity,
                p.discount,
                p.image_path,
                c.name AS category_name,
                m.name AS manufacturer_name,
                s.name AS supplier_name,
                u.name AS unit_name
            FROM products p
            JOIN categories c ON c.id = p.category_id
            JOIN manufacturers m ON m.id = p.manufacturer_id
            JOIN suppliers s ON s.id = p.supplier_id
            JOIN units u ON u.id = p.unit_id
            WHERE
                (%s = '' OR CONCAT_WS(' ', p.name, p.description, c.name, m.name, s.name, u.name) LIKE %s)
                AND (%s = 0 OR p.supplier_id = %s)
            ORDER BY {order_by}
            """,
            (search_text, search_pattern, supplier_id, supplier_id),
        )

        self.product_list.clear()
        for product in products:
            item = QListWidgetItem()
            item.setData(Qt.ItemDataRole.UserRole, product["id"])
            card = ProductCard(product)
            item.setSizeHint(card.sizeHint())
            self.product_list.addItem(item)
            self.product_list.setItemWidget(item, card)

    def selected_product_id(self):
        """Возвращает id выбранного товара или None."""
        item = self.product_list.currentItem()
        if item is None:
            return None
        return item.data(Qt.ItemDataRole.UserRole)

    def add_product(self):
        """Открывает форму добавления товара."""
        dialog = ProductEditor(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.load_suppliers()
            self.refresh_products()

    def edit_product(self):
        """Открывает форму редактирования выбранного товара."""
        if not self.can_edit:
            return

        product_id = self.selected_product_id()
        if product_id is None:
            QMessageBox.information(self, "Редактирование", "Выберите товар в списке.")
            return

        dialog = ProductEditor(self, product_id)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.load_suppliers()
            self.refresh_products()

    def delete_product(self):
        """Удаляет выбранный товар, если он не присутствует в заказе."""
        product_id = self.selected_product_id()
        if product_id is None:
            QMessageBox.information(self, "Удаление", "Выберите товар в списке.")
            return

        usage = fetch_one(
            "SELECT COUNT(*) AS count_items FROM order_items WHERE product_id = %s",
            (product_id,),
        )
        if usage["count_items"] > 0:
            QMessageBox.warning(
                self,
                "Удаление запрещено",
                "Этот товар присутствует в заказе, поэтому удалить его нельзя.",
            )
            return

        answer = QMessageBox.question(
            self,
            "Подтверждение удаления",
            "Удалить выбранный товар? Операцию нельзя отменить.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return

        product = fetch_one("SELECT image_path FROM products WHERE id = %s", (product_id,))
        execute_query("DELETE FROM products WHERE id = %s", (product_id,))

        if product and product.get("image_path"):
            image_file = APP_DIR / product["image_path"]
            if image_file.exists():
                image_file.unlink()

        self.refresh_products()


class ProductEditor(QDialog):
    """Форма добавления или редактирования товара."""

    def __init__(self, parent=None, product_id=None):
        super().__init__(parent)
        self.product_id = product_id
        self.new_image_source = None
        self.current_image_path = None
        self.setModal(True)
        self.setWindowTitle("Редактирование товара" if product_id else "Добавление товара")
        self.resize(520, 620)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        layout.addLayout(form)

        self.id_input = QLineEdit()
        self.id_input.setReadOnly(True)
        form.addRow("ID", self.id_input)
        self.id_input.setVisible(product_id is not None)

        self.image_label = QLabel("Изображение не выбрано")
        self.image_label.setFixedSize(300, 200)
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setStyleSheet("border: 1px solid gray;")
        form.addRow("Фото", self.image_label)

        choose_image_button = QPushButton("Выбрать изображение")
        choose_image_button.clicked.connect(self.choose_image)
        form.addRow("", choose_image_button)

        self.name_input = QLineEdit()
        form.addRow("Наименование", self.name_input)

        self.category_combo = QComboBox()
        form.addRow("Категория", self.category_combo)

        self.description_input = QTextEdit()
        self.description_input.setFixedHeight(80)
        form.addRow("Описание", self.description_input)

        self.manufacturer_combo = QComboBox()
        form.addRow("Производитель", self.manufacturer_combo)

        self.supplier_combo = QComboBox()
        form.addRow("Поставщик", self.supplier_combo)

        self.price_input = QDoubleSpinBox()
        self.price_input.setRange(0, 1_000_000)
        self.price_input.setDecimals(2)
        self.price_input.setSuffix(" руб.")
        form.addRow("Цена", self.price_input)

        self.unit_combo = QComboBox()
        form.addRow("Единица", self.unit_combo)

        self.quantity_input = QSpinBox()
        self.quantity_input.setRange(0, 1_000_000)
        form.addRow("Количество", self.quantity_input)

        self.discount_input = QSpinBox()
        self.discount_input.setRange(0, 100)
        self.discount_input.setSuffix(" %")
        form.addRow("Скидка", self.discount_input)

        buttons_layout = QHBoxLayout()
        layout.addLayout(buttons_layout)
        save_button = QPushButton("Сохранить")
        cancel_button = QPushButton("Отмена")
        buttons_layout.addWidget(save_button)
        buttons_layout.addWidget(cancel_button)

        save_button.clicked.connect(self.save_product)
        cancel_button.clicked.connect(self.reject)

        self.load_combo(self.category_combo, "categories")
        self.load_combo(self.manufacturer_combo, "manufacturers")
        self.load_combo(self.supplier_combo, "suppliers")
        self.load_combo(self.unit_combo, "units")

        if self.product_id:
            self.load_product()

    def load_combo(self, combo, table_name):
        """Загружает справочник в выпадающий список."""
        combo.clear()
        rows = fetch_all(f"SELECT id, name FROM {table_name} ORDER BY name")
        for row in rows:
            combo.addItem(row["name"], row["id"])

    def set_combo_value(self, combo, value):
        """Выбирает элемент combo по id, который хранится в UserData."""
        index = combo.findData(value)
        if index >= 0:
            combo.setCurrentIndex(index)

    def load_product(self):
        """Загружает текущие значения товара в поля формы."""
        product = fetch_one("SELECT * FROM products WHERE id = %s", (self.product_id,))
        if product is None:
            QMessageBox.warning(self, "Ошибка", "Товар не найден.")
            self.reject()
            return

        self.id_input.setText(str(product["id"]))
        self.name_input.setText(product["name"])
        self.description_input.setPlainText(product.get("description") or "")
        self.price_input.setValue(float(product["price"]))
        self.quantity_input.setValue(int(product["quantity"]))
        self.discount_input.setValue(int(product["discount"]))
        self.current_image_path = product.get("image_path")

        self.set_combo_value(self.category_combo, product["category_id"])
        self.set_combo_value(self.manufacturer_combo, product["manufacturer_id"])
        self.set_combo_value(self.supplier_combo, product["supplier_id"])
        self.set_combo_value(self.unit_combo, product["unit_id"])
        self.show_image(APP_DIR / self.current_image_path if self.current_image_path else PLACEHOLDER_IMAGE)

    def choose_image(self):
        """Открывает выбор файла изображения."""
        file_name, _ = QFileDialog.getOpenFileName(
            self,
            "Выберите изображение товара",
            "",
            "Изображения (*.png *.jpg *.jpeg *.bmp)",
        )
        if not file_name:
            return

        self.new_image_source = Path(file_name)
        self.show_image(self.new_image_source)

    def show_image(self, path):
        """Показывает изображение в форме."""
        if not path or not Path(path).exists():
            self.image_label.setText("Изображение не найдено")
            self.image_label.setPixmap(QPixmap())
            return

        pixmap = QPixmap(str(path))
        pixmap = pixmap.scaled(
            300,
            200,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        self.image_label.setPixmap(pixmap)

    def save_image_if_needed(self):
        """Копирует новое изображение в папку приложения и ограничивает размер 300x200."""
        if self.new_image_source is None:
            return self.current_image_path

        extension = self.new_image_source.suffix.lower() or ".png"
        new_name = f"{uuid4().hex}{extension}"
        target_path = PRODUCT_IMAGE_DIR / new_name

        pixmap = QPixmap(str(self.new_image_source))
        if pixmap.isNull():
            shutil.copy2(self.new_image_source, target_path)
        else:
            pixmap = pixmap.scaled(
                300,
                200,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            pixmap.save(str(target_path))

        if self.current_image_path:
            old_path = APP_DIR / self.current_image_path
            if old_path.exists():
                old_path.unlink()

        return os.path.relpath(target_path, APP_DIR).replace("\\", "/")

    def save_product(self):
        """Проверяет поля и сохраняет товар в БД."""
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Ошибка ввода", "Введите наименование товара.")
            return

        image_path = self.save_image_if_needed()
        params = (
            name,
            self.category_combo.currentData(),
            self.description_input.toPlainText().strip(),
            self.manufacturer_combo.currentData(),
            self.supplier_combo.currentData(),
            self.price_input.value(),
            self.unit_combo.currentData(),
            self.quantity_input.value(),
            self.discount_input.value(),
            image_path,
        )

        try:
            if self.product_id:
                execute_query(
                    """
                    UPDATE products
                    SET name = %s,
                        category_id = %s,
                        description = %s,
                        manufacturer_id = %s,
                        supplier_id = %s,
                        price = %s,
                        unit_id = %s,
                        quantity = %s,
                        discount = %s,
                        image_path = %s
                    WHERE id = %s
                    """,
                    params + (self.product_id,),
                )
            else:
                execute_query(
                    """
                    INSERT INTO products
                    (name, category_id, description, manufacturer_id, supplier_id,
                     price, unit_id, quantity, discount, image_path)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    params,
                )
        except Exception as error:
            QMessageBox.critical(self, "Ошибка сохранения", f"Не удалось сохранить товар:\n{error}")
            return

        self.accept()


def main():
    app = QApplication(sys.argv)
    window = LoginWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
