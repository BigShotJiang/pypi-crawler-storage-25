# Contributing to Zenith

First off, thank you for considering contributing to Zenith! It's people like you that make the open-source community such a great place to learn, inspire, and create.

## How Can You Contribute?

### Reporting Bugs
* Ensure the bug was not already reported by searching on GitHub under Issues.
* If you're unable to find an open issue addressing the problem, open a new one. Be sure to include a title and clear description, as much relevant information as possible, and a code sample or an executable test case demonstrating the expected behavior that is not occurring.

### Suggesting Enhancements
* Open a new issue with a clear title and description.
* Explain why this enhancement would be useful to most users.

### Pull Requests
1. Fork the repo and create your branch from `main`.
2. If you've added code that should be tested, add tests.
3. Ensure the test suite passes.
4. Make sure your code respects the existing formatting.
5. Issue that pull request!
