# BruhWhat

**BruhWhat** IS programming language made for fun and inspired by game baba IS you

## Features
- py and terminal - these are commands that lets you use terminal and python commands
- exec - lets you execute code inside code inside code inside code
- IS - everything IS variable, no =, only IS
- ADD / SUB - math but without + and - because we only use words (not always)
- func - functions exist but who needs them when you have exec

## Why BruhWhat?

Because you can write:
```bruhwhat
exec exec exec exec exec print exec print exec lol exec IS py run_lines(["terminal echo lol"],{},{})
```
And it works. Nobody knows how. Not even the creator.

## How to run code?

```python
import bruhwhat
bruhwhat.run("code.bw")
```

## Quick example of bw code
```bw
# Making variables
ur_age exec IS input yoo what's ur age bro?:
this_year num IS 2026
# Calculating
ur_birthday math IS this_year - ur_age
print txt Here's ur birthday bro:
print ur_birthday
```
