from setuptools import setup, find_packages

setup(
    name="bruhwhat",
    version="1.0.0",
    author="Sviter",
    description="A funny programming language named BruhWhat",
    url="https://github.com/ISviterI/bruhwhat",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    project_urls={
        "Homepage": "https://github.com/ISviterI/bruhwhat",
        "Discord": "https://discord.gg/MXv3KTFmPE",
        "Wiki": "https://github.com/ISviterI/bruhwhat/wiki",
    },
    packages=find_packages(),
    license="MIT",
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    keywords="bruhwhat,language,programming",
)