import os

def run(filename):
    code = open(filename).read()
    lines = code.split('\n')
    run_lines(lines,{},{})
def error(exception):
    print("ERROR:",exception)
def run_lines(lines:list, svars, sfuncs):
    variables = svars
    functions = sfuncs
    creatingfunc = False
    newfuncname = ""
    result = None
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        space = line.split()
        if not creatingfunc:
            if " IS " in line:
                split = line.split(" IS ")
                split2 = split[0].split()
                if split2[1] == "num":
                    variables[split2[0]] = int(split[1])
                elif split2[1] == "txt":
                    variables[split2[0]] = split[1]
                elif split2[1] == "exec":
                    exec_lines = split[1].split(";")
                    variables[split2[0]] = run_lines(exec_lines,variables,functions)
                elif split2[1] == "math":
                    cool_space = split[1].split()
                    try:
                        if variables[cool_space[0]] and variables[cool_space[2]]:
                            if cool_space[1] == "+":
                                variables[split2[0]] = str(variables[cool_space[0]]) + str(variables[cool_space[2]]) or int(variables[cool_space[0]]) + int(variables[cool_space[2]])
                            elif cool_space[1] == "-":
                                variables[split2[0]] = int(variables[cool_space[0]]) - int(variables[cool_space[2]])
                            elif cool_space[1] == "*":
                                variables[split2[0]] = int(variables[cool_space[0]]) * int(variables[cool_space[2]])
                            elif cool_space[1] == "/":
                                variables[split2[0]] = int(variables[cool_space[0]]) / int(variables[cool_space[2]])

                    except Exception as e:
                        error(e)


            elif space[0] == "print":
                try:
                    print(float(space[1]))
                except:
                    try:
                        print(variables[space[1]])
                    except:
                        if space[1] == "txt":
                            txt = ""
                            num = 0
                            for t in space:
                                num += 1
                                if num > 2:
                                    txt += t
                                    if num < len(space):
                                        txt += " "
                            print(txt)
                        elif space[1] == "exec":
                            txt = ""
                            num = 0
                            for t in space:
                                num += 1
                                if num > 2:
                                    txt += t
                                    if num < len(space):
                                        txt += " "
                            print(run_lines([txt],variables,functions))
                        else:
                            error(f"No variable, number, txt found in {space[1]}")

            elif space[0] == "terminal":
                txt = ""
                num = 0
                for t in space:
                    num += 1
                    if num >= 2:
                        txt += t + " "
                os.system(txt)
            elif space[0] == "func":
                newfuncname = space[1]
                functions[newfuncname] = ""
                creatingfunc = True
            elif " ADD " in line:
                split = line.split(" ADD ")
                var_name = split[0].strip()
                value = split[1].strip()

                if value in variables:
                    variables[var_name] += variables[value]
                else:
                    try:
                        variables[var_name] += int(value)
                    except:
                        error(f"Cannot add {value} to {var_name}")
            elif " SUB " in line:
                split = line.split(" SUB ")
                var_name = split[0].strip()
                value = split[1].strip()

                if value in variables:
                    variables[var_name] -= variables[value]
                else:
                    try:
                        variables[var_name] -= int(value)
                    except:
                        error(f"Cannot subtract {value} from {var_name}")
            elif space[0] == "input":
                try:
                    txt = ""
                    num = 0
                    for t in space:
                        num += 1
                        if num > 1:
                            txt += t
                            if num < len(space):
                                txt += " "
                    result = input(txt)
                    return result
                except:
                    error("No prompt provided")
            elif space[0] == "py":
                code = " ".join(space[1:])
                exec(code)
            elif space[0] == "exec":
                txt = ""
                num = 0
                for t in space:
                    num += 1
                    if num >= 2:
                        txt += t + " "
                run_lines([txt],variables,functions)
        if creatingfunc and line != "end":
            functions[newfuncname] += line + ":"
        if creatingfunc and line == "end":
            creatingfunc = False
        line_without_is = f"{line[:len(line)-1]}"
        line_has_is = False
        for i in line:
            if i == ":":
                line_has_is = True
        if functions.get(line_without_is) and line_has_is:
                if True:
                    func_lines = []
                    num = 0
                    for i in functions[line_without_is].split(":"):
                        num += 1
                        if num > 1:
                            func_lines.append(i)
                    run_lines(func_lines, variables, functions)
    return result