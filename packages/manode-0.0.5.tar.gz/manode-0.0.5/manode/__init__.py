# Copyright 2026 Alex Summers
# See LICENSE file for more information

import sys

if sys.version_info[0] == 2:
    raise ImportError('Ninia requires Python 3.7. This is Python 2.')

__all__ = ['VCC', 'Ground', 'USResistor', 'Capacitor', 'LED', 'Diode', 'IC',
           'connect', 'build_circuit_path', 'ATtiny84a', 'ATtiny85']
__version__ = '0.0.5'

from .elements.one_terminal import VCC, Ground
from .elements.two_terminal import USResistor, Capacitor, LED, Diode
from .elements.multi_terminal import IC
from .elements.integrated import ATtiny84a, ATtiny85

from .utils import connect, build_circuit_path
