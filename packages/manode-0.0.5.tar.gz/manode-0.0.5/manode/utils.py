from manim import *
import itertools as it
from .base import OneTerminal, TwoTerminal, MultiTerminal


def connect(source, target, source_pin=None, target_pin=None):
    """Draw a wire between the two closest terminals of source and target."""

    if isinstance(source, OneTerminal):
        source_combs = [source.terminal()]
    elif isinstance(source, TwoTerminal):
        source_combs = [source.output(), source.input()]
    elif isinstance(source, MultiTerminal):
        source_combs = [source.lead(source_pin)]
    else:
        raise TypeError(f'Source of inaccessible type, {source.__class__.__bases__}')

    if isinstance(target, OneTerminal):
        target_combs = [target.terminal()]
    elif isinstance(target, TwoTerminal):
        target_combs = [target.output(), target.input()]
    elif isinstance(target, MultiTerminal):
        target_combs = [target.lead(target_pin)]
    else:
        raise TypeError(f'Source of inaccessible type, {target.__class__.__bases__}')

    combos = it.product(source_combs, target_combs)
    start, end = min(combos, key=lambda pair: np.linalg.norm(pair[0] - pair[1]))
    return Line(start, end)


def build_circuit_path(parts):
    """Merge parts into a single VMobject, auto-orienting each piece."""
    circuit = VMobject()
    for i, part in enumerate(parts):
        print(part)
        pts = part.get_all_points()
        if i > 0:
            prev_end = circuit.get_all_points()[-1]
            if np.linalg.norm(pts[-1] - prev_end) < np.linalg.norm(pts[0] - prev_end):
                pts = pts[::-1]
        circuit.append_points(pts)
    return circuit


def _make_small_arrow(self, start, end, color, stroke_width):
    """A tiny arrow from start to end."""
    line = Line(start, end, color=color, stroke_width=stroke_width)
    direction = normalize(end - start)
    perp = np.array([-direction[1], direction[0], 0])
    tip_len = np.linalg.norm(end - start) * 0.3
    tip1 = Line(end, end - tip_len * direction + tip_len * 0.4 * perp,
                color=color, stroke_width=stroke_width)
    tip2 = Line(end, end - tip_len * direction - tip_len * 0.4 * perp,
                color=color, stroke_width=stroke_width)
    return VGroup(line, tip1, tip2)


