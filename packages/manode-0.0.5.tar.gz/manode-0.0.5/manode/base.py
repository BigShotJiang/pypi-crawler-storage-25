from manim import *


class CircuitComponent(VGroup):
    def __init__(self, width=1.2, color=WHITE,
                 stroke_width=DEFAULT_STROKE_WIDTH, reverse=False, **kwargs):
        super().__init__(**kwargs)


class TwoTerminal(CircuitComponent):
    def __init__(self, width=1.2, color=WHITE,
                 stroke_width=DEFAULT_STROKE_WIDTH, reverse=False, **kwargs):
        super().__init__(**kwargs)

    def input(self):
        raise NotImplementedError

    def output(self):
        raise NotImplementedError

    def align_input_h(self, point):
        self.shift(UP * (point[1] - self.input()[1]))
        return self

    def align_input_v(self, point):
        self.shift(RIGHT * (point[0] - self.input()[0]))
        return self

    def align_output_h(self, point):
        self.shift(UP * (point[1] - self.output()[1]))
        return self

    def align_output_v(self, point):
        self.shift(RIGHT * (point[0] - self.output()[0]))
        return self

    def terminal_near(self, point):
        start = self.input()
        end = self.output()
        if np.linalg.norm(point - start) < np.linalg.norm(point - end):
            return start
        return end

    def terminal_far(self, point):
        start = self.input()
        end = self.output()
        if np.linalg.norm(point - start) >= np.linalg.norm(point - end):
            return start
        return end

    def rotate_about_input(self, angle):
        self.rotate(angle, about_point=self.input())
        return self

    def rotate_about_output(self, angle):
        self.rotate(angle, about_point=self.output())
        return self


class OneTerminal(CircuitComponent):
    def __init__(self, width=1.2, color=WHITE,
                 stroke_width=DEFAULT_STROKE_WIDTH, reverse=False, **kwargs):
        super().__init__(**kwargs)

    def terminal(self):
        raise NotImplementedError

    def align_terminal_h(self, point):
        self.shift(UP * (point[1] - self.terminal()[1]))
        return self

    def align_terminal_v(self, point):
        self.shift(RIGHT * (point[0] - self.terminal()[0]))
        return self

    def rotate_about_terminal(self, angle):
        self.rotate(angle, about_point=self.terminal())
        return self


class MultiTerminal(CircuitComponent):
    def __init__(self, width=1.2, color=WHITE,
                 stroke_width=DEFAULT_STROKE_WIDTH, reverse=False, **kwargs):
        super().__init__(**kwargs)

        self.pin_dict = {}

    def lead(self, pin):
        raise NotImplementedError

