from manim import *
from .multi_terminal import IC


class ATtiny85(IC):
    def __init__(self, width=1.2, color=WHITE,
                 label=None, stroke_width=DEFAULT_STROKE_WIDTH, **kwargs):

        left_pins = [(1, 'RESET'), (2, '3'), (3, '4'), (4, 'GND')]
        right_pins = [(5, '0'), (6, '1'), (7, '2'), (8, '5V')]

        super().__init__(
            width=width,
            color=color,
            label='ATtiny85',
            stroke_width=stroke_width,
            left_pins=left_pins,
            right_pins=right_pins,
            **kwargs
        )


class ATtiny84a(IC):
    def __init__(self, width=1.2, color=WHITE, label=None,
                 stroke_width=DEFAULT_STROKE_WIDTH, lead_extra=0, **kwargs):

        left_pins = [(1, 'VCC'), (2, 'D0'), (3, 'D1'), (4, 'RESET'), (5, 'D2'),
                     (6, 'A7,D3'), (7, 'A6,D4,MOSI')]
        right_pins = [(8, 'A5,D5,MISO'), (9, 'A4,D6,SCK'), (10, 'A3,D7'), (11, 'A2,D8'), (12, 'A1,D9'),
                      (13, 'A0,D10,GND'), (14, 'GND')]

        super().__init__(
            width=width,
            color=color,
            label='ATtiny85',
            stroke_width=stroke_width,
            left_pins=left_pins,
            right_pins=right_pins,
            lead_extra=lead_extra,
            **kwargs
        )

