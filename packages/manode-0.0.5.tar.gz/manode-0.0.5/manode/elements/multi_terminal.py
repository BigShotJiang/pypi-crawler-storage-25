from manim import *
from ..base import MultiTerminal


class IC(MultiTerminal):
    def __init__(self, width=1.2, color=WHITE, left_pins=None, right_pins=None,
                 label=None, stroke_width=DEFAULT_STROKE_WIDTH, reverse=False, lead_extra=0, **kwargs):
        super().__init__(color=color, stroke_width=stroke_width, **kwargs)

        self.labels = VGroup()
        self.top_label = None

        components = max(len(left_pins), len(right_pins))
        height = (components + 1) * width / 2

        bottom_right = DOWN * height / 2 + RIGHT * width / 2
        bottom_left = DOWN * height / 2 + LEFT * width / 2
        top_right = UP * height / 2 + RIGHT * width / 2
        top_left = UP * height / 2 + LEFT * width / 2
        rectangle = Polygon(bottom_left, top_left, top_right, bottom_right,
                            color=color, stroke_width=stroke_width)

        self.add(rectangle)
        if label is not None:
            chip_label = Text(label, font_size=20 * (width / 0.8)).next_to(rectangle, UP * height / 2)
            self.top_label = chip_label

        k = 0

        for i in range(len(left_pins) + len(right_pins)):
            self.labels.add(VGroup())

        left_pin_sep = height / (len(left_pins) + 1)
        for i, pin in enumerate(left_pins):
            pin_lead = Line(top_left + DOWN * left_pin_sep * (i + 1),
                            top_left + DOWN * left_pin_sep * (i + 1) + LEFT * (width + lead_extra),
                            color=color, stroke_width=stroke_width)

            pin_label = Text(f'{pin[0]}', font_size=15 * (width / 0.8)).next_to(pin_lead, RIGHT / 2)
            pin_lead_label = Text(f'{pin[1]}', font_size=15 * (width / 0.8)).next_to(pin_lead, UP * width / 4)

            self.add(pin_lead)
            self.labels[pin[0] - 1].add(pin_label)
            self.labels[pin[0] - 1].add(pin_lead_label)
            self.pin_dict.update({pin[0]: pin_lead})

        right_pin_sep = height / (len(right_pins) + 1)
        for i, pin in enumerate(right_pins):
            pin_lead = Line(bottom_right + UP * right_pin_sep * (i + 1),
                            bottom_right + UP * right_pin_sep * (i + 1) + RIGHT * (width + lead_extra),
                            color=color, stroke_width=stroke_width)
            pin_label = Text(f'{pin[0]}', font_size=15 * (width / 0.8)).next_to(pin_lead, LEFT / 2)
            pin_lead_label = Text(f'{pin[1]}', font_size=15 * (width / 0.8)).next_to(pin_lead, UP * width / 4)

            self.add(pin_lead)
            self.labels[pin[0] - 1].add(pin_label)
            self.labels[pin[0] - 1].add(pin_lead_label)
            self.pin_dict.update({pin[0]: pin_lead})

    def lead(self, pin):
        return self.pin_dict[pin].get_end()


