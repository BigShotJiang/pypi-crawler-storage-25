from manim import *
from ..base import TwoTerminal
from ..utils import _make_small_arrow


class USResistor(TwoTerminal):
    def __init__(self, width=1.2, aspect_ratio=8, color=WHITE,
                 stroke_width=DEFAULT_STROKE_WIDTH, reverse=False, **kwargs):
        super().__init__(color=color, stroke_width=stroke_width, **kwargs)
        self.reverse = reverse

        amplitude = width / aspect_ratio

        points = []

        for i in range(10):
            x = -width / 2 + i * (width / 8)
            if (i == 0) or (i == 1) or (i == 8) or (i == 9):
                y = 0
                if (i == 1):
                    x += width / 16
                elif (i == 8):
                    x -= width / 16
            else:
                y = amplitude * (1 if i % 2 == 0 else -1)
            points.append([x, y, 0])

        self.trace = VMobject(color=color,
                              stroke_width=stroke_width
                              ).set_points_as_corners(
            [np.array(p) for p in points]
        )

        if self.reverse:
            self.trace.reverse_points()
        self.add(self.trace)

    def input(self):
        return self.trace.get_start()

    def output(self):
        return self.trace.get_end()


class Capacitor(TwoTerminal):

    def __init__(self, width=1.2, aspect_ratio1=8, aspect_ratio2=2.4, color=WHITE,
                 stroke_width=DEFAULT_STROKE_WIDTH, **kwargs):
        super().__init__(color=color, stroke_width=stroke_width, **kwargs)

        gap = width / aspect_ratio1
        height = width / aspect_ratio2
        lead = (width - gap) / 2

        left_lead = Line(LEFT * width / 2, LEFT * gap / 2, color=color, stroke_width=stroke_width)

        left_plate = Line(
            LEFT * gap / 2 + UP * height / 2,
            LEFT * gap / 2 + DOWN * height / 2,
            color=color, stroke_width=stroke_width
        )

        right_plate = Line(
            RIGHT * gap / 2 + UP * height / 2,
            RIGHT * gap / 2 + DOWN * height / 2,
            color=color, stroke_width=stroke_width
        )

        right_lead = Line(RIGHT * gap / 2, RIGHT * width / 2, color=color, stroke_width=stroke_width)

        self.add(left_lead, left_plate, right_plate, right_lead)

    def input(self):
        return self[0].get_start()

    def output(self):
        return self[3].get_end()


class LED(TwoTerminal):
    def __init__(self, width=1.2, aspect_ratio=3, color=WHITE,
                 stroke_width=DEFAULT_STROKE_WIDTH, **kwargs):
        super().__init__(color=color, stroke_width=stroke_width, **kwargs)

        lead_len = width / 3
        height = width / aspect_ratio

        left_lead = Line(
            LEFT * width / 2,
            LEFT * (width / 2 - lead_len),
            color=color, stroke_width=stroke_width
        )

        tip = RIGHT * (width / 2 - lead_len)
        base_top = LEFT * (width / 2 - lead_len) + UP * height / 2
        base_bot = LEFT * (width / 2 - lead_len) + DOWN * height / 2
        triangle = Polygon(
            base_top, base_bot, tip,
            color=color, stroke_width=stroke_width
        )

        bar = Line(
            tip + UP * height / 2,
            tip + DOWN * height / 2,
            color=color, stroke_width=stroke_width
        )

        right_lead = Line(
            tip,
            RIGHT * width / 2,
            color=color, stroke_width=stroke_width
        )

        arrow_len = height / 3
        arrow_start_1 = UP * height / 2 + LEFT * (width / 2 - lead_len) * 0.3
        arrow_start_2 = arrow_start_1 + RIGHT * arrow_len

        arrow1 = _make_small_arrow(self, arrow_start_1, arrow_start_1 + UP * arrow_len + RIGHT * arrow_len * 0.5,
                                   color=color, stroke_width=stroke_width)
        arrow2 = _make_small_arrow(self, arrow_start_2, arrow_start_2 + UP * arrow_len + RIGHT * arrow_len * 0.5,
                                   color=color, stroke_width=stroke_width)

        self.add(left_lead, triangle, bar, right_lead, arrow1, arrow2)

    def input(self):
        return self[0].get_start()

    def output(self):
        return self[3].get_end()


class Diode(TwoTerminal):
    def __init__(self, width=1.2, aspect_ratio=3, color=WHITE,
                 stroke_width=DEFAULT_STROKE_WIDTH, **kwargs):
        super().__init__(color=color, stroke_width=stroke_width, **kwargs)

        lead_len = width / 3
        height = width / aspect_ratio

        left_lead = Line(
            LEFT * width / 2,
            LEFT * (width / 2 - lead_len),
            color=color, stroke_width=stroke_width
        )

        tip = RIGHT * (width / 2 - lead_len)
        base_top = LEFT * (width / 2 - lead_len) + UP * height / 2
        base_bot = LEFT * (width / 2 - lead_len) + DOWN * height / 2
        triangle = Polygon(
            base_top, base_bot, tip,
            color=color, stroke_width=stroke_width
        )

        bar = Line(
            tip + UP * height / 2,
            tip + DOWN * height / 2,
            color=color, stroke_width=stroke_width
        )

        right_lead = Line(
            tip,
            RIGHT * width / 2,
            color=color, stroke_width=stroke_width
        )

        self.add(left_lead, triangle, bar, right_lead)

    def input(self):
        return self[0].get_start()

    def output(self):
        return self[3].get_end()


