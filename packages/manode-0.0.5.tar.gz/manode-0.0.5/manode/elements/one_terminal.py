from manim import *
from ..base import OneTerminal

class Ground(OneTerminal):

    def __init__(self, width=1.2, aspect_ratio=3, color=WHITE,
                 stroke_width=DEFAULT_STROKE_WIDTH, **kwargs):
        super().__init__(**kwargs)

        height = width / aspect_ratio

        lead = Line(UP * height / 2, ORIGIN, color=color, stroke_width=stroke_width)
        gnd0 = Line(width * LEFT / 4, width * RIGHT / 4, color=color, stroke_width=stroke_width)
        gnd1 = Line(DOWN * height / 6 + LEFT * width * 3 / 16, DOWN * height / 6 + RIGHT * width * 3 / 16, color=color,
                    stroke_width=stroke_width)
        gnd2 = Line(DOWN * height / 3 + LEFT * width * 2 / 16, DOWN * height / 3 + RIGHT * width * 2 / 16, color=color,
                    stroke_width=stroke_width)
        gnd3 = Line(DOWN * height / 2 + LEFT * width * 1 / 16, DOWN * height / 2 + RIGHT * width * 1 / 16, color=color,
                    stroke_width=stroke_width)

        self.add(lead, gnd0, gnd1, gnd2, gnd3)

    def terminal(self):
        return self[0].get_start()


class VCC(OneTerminal):

    def __init__(self, width=1.2, aspect_ratio=3, color=WHITE,
                 stroke_width=DEFAULT_STROKE_WIDTH, **kwargs):
        super().__init__(**kwargs)

        height = width / aspect_ratio

        lead_len = width / 3
        tri_width = width / 2 - lead_len

        lead = Line(DOWN * height / 2, ORIGIN, color=color, stroke_width=stroke_width)

        tip = UP * (height / 2)
        base_left = LEFT * (width / 6)
        base_right = RIGHT * (width / 6)

        triangle = Polygon(
            base_left, base_right, tip,
            color=color, stroke_width=stroke_width
        )

        self.add(lead, triangle)

    def terminal(self):
        return self[0].get_start()