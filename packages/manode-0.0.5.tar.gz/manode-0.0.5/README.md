This is an extension to the manim community edition package for circuit design. 

Still in development.