import setuptools

with open('README.md', 'r', encoding='utf-8') as fh:
    long_description = fh.read()

setuptools.setup(
    name='manode',
    version='0.0.5',
    author='Alex Summers',
    author_email='ajs0201@auburn.edu',
    description='Extension to manim community package for circuit design.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/ajsummers/manode',
    project_urls={
        'Issues': 'https://github.com/ajsummers/manode/issues'
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    packages=setuptools.find_packages(),
    include_package_data=True,
    python_requires='>=3.7',
)