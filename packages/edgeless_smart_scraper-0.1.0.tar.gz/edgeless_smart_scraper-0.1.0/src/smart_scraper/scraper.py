"""
Main scraper module.

Provides the unified ``scrape_url()`` entry point that ties together backend
selection, instantiation, and execution.

Usage::

    from smart_scraper import scrape_url

    # Automatic backend selection
    result = scrape_url("https://example.com")

    # Force a specific backend
    result = scrape_url("https://example.com", backend="firecrawl")

    # Force Firecrawl (shorthand kept for discoverability)
    result = scrape_url("https://spa-site.com", force_firecrawl=True)
"""

from __future__ import annotations

from typing import Optional, Union

from ._types import ScrapeResult
from .backends.basic import BasicBackend
from .backends.firecrawl import FirecrawlBackend
from .backends.tavily import TavilyBackend
from .selector import Backend, BackendSelector

# Re-export so callers can do `from smart_scraper import ScrapeResult, Backend`
__all__ = ["scrape_url", "ScrapeResult", "Backend"]

# Module-level singletons (lazily created, not shared state in a harmful way —
# they hold no mutable scraping state, only SDK client handles).
_basic: Optional[BasicBackend] = None
_firecrawl: Optional[FirecrawlBackend] = None
_tavily: Optional[TavilyBackend] = None


def _get_basic() -> BasicBackend:
    global _basic
    if _basic is None:
        _basic = BasicBackend()
    return _basic


def _get_firecrawl() -> FirecrawlBackend:
    global _firecrawl
    if _firecrawl is None:
        _firecrawl = FirecrawlBackend()
    return _firecrawl


def _get_tavily() -> TavilyBackend:
    global _tavily
    if _tavily is None:
        _tavily = TavilyBackend()
    return _tavily


def scrape_url(
    url: str,
    *,
    backend: Union[str, Backend, None] = None,
    force_firecrawl: bool = False,
    force_tavily: bool = False,
    only_main_content: bool = True,
    timeout: int = 30,
    firecrawl_api_key: Optional[str] = None,
    tavily_api_key: Optional[str] = None,
) -> ScrapeResult:
    """
    Scrape *url* and return a normalised :class:`~smart_scraper.ScrapeResult`.

    Backend selection priority (highest to lowest):
        1. ``backend`` parameter (explicit override)
        2. ``force_firecrawl`` / ``force_tavily`` flags (convenience shortcuts)
        3. Automatic selection via :class:`~smart_scraper.selector.BackendSelector`

    Args:
        url:
            Fully-qualified URL to scrape (must include scheme, e.g. ``https://``).
        backend:
            Force a specific backend.  Accepts ``"basic"``, ``"firecrawl"``,
            ``"tavily"``, ``"auto"`` (default automatic), or a :class:`Backend`
            enum value.
        force_firecrawl:
            Shorthand for ``backend="firecrawl"``.  Ignored when ``backend`` is set.
        force_tavily:
            Shorthand for ``backend="tavily"``.  Ignored when ``backend`` is set.
        only_main_content:
            Ask the Firecrawl backend to strip navigation, headers, and footers.
            Has no effect on other backends.
        timeout:
            Per-request timeout in seconds.
        firecrawl_api_key:
            Firecrawl API key for this call only.  If omitted, the backend reads
            ``FIRECRAWL_API_KEY`` from the environment.
        tavily_api_key:
            Tavily API key for this call only.  If omitted, the backend reads
            ``TAVILY_API_KEY`` from the environment.

    Returns:
        :class:`~smart_scraper.ScrapeResult` — always returned, never raises.
        Check ``result.success`` and ``result.error`` for failure details.

    Examples::

        from smart_scraper import scrape_url

        # Zero-config: works with no API keys
        result = scrape_url("https://example.com")
        print(result.content)

        # JS-heavy site with Firecrawl
        result = scrape_url("https://notion.so/page", force_firecrawl=True)

        # Research query via Tavily
        result = scrape_url("https://wsj.com/article", force_tavily=True)
    """
    # --- Resolve which backend to use -----------------------------------
    hint = _resolve_hint(backend, force_firecrawl, force_tavily)

    # Build per-call backends with optional key overrides
    fc_backend = FirecrawlBackend(api_key=firecrawl_api_key) if firecrawl_api_key else _get_firecrawl()
    tv_backend = TavilyBackend(api_key=tavily_api_key) if tavily_api_key else _get_tavily()

    selector = BackendSelector(
        firecrawl_available=fc_backend.is_available,
        tavily_available=tv_backend.is_available,
    )
    chosen = selector.select(url, hint)

    # --- Dispatch -------------------------------------------------------
    if chosen == Backend.FIRECRAWL:
        result = fc_backend.fetch(
            url,
            only_main_content=only_main_content,
            timeout=timeout,
        )
        # On Firecrawl failure, transparently fall back to basic
        if not result.success:
            basic_result = _get_basic().fetch(url, timeout=timeout)
            if basic_result.success:
                return basic_result
        return result

    if chosen == Backend.TAVILY:
        result = tv_backend.fetch(url)
        if not result.success:
            basic_result = _get_basic().fetch(url, timeout=timeout)
            if basic_result.success:
                return basic_result
        return result

    # Default: basic
    return _get_basic().fetch(url, timeout=timeout)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _resolve_hint(
    backend: Union[str, Backend, None],
    force_firecrawl: bool,
    force_tavily: bool,
) -> Optional[Backend]:
    """Normalise caller intent into an optional Backend hint."""
    if backend is not None:
        if isinstance(backend, Backend):
            return backend if backend != Backend.AUTO else None
        try:
            parsed = Backend(backend.lower())
            return parsed if parsed != Backend.AUTO else None
        except ValueError:
            valid = ", ".join(b.value for b in Backend)
            raise ValueError(
                f"Unknown backend {backend!r}. Valid options: {valid}"
            ) from None

    if force_firecrawl:
        return Backend.FIRECRAWL
    if force_tavily:
        return Backend.TAVILY
    return None
