"""
Intelligent backend selector.

Analyses a URL's characteristics to choose the most appropriate scraping
backend before making any network request.  The selection logic is
deliberately rule-based (no ML, no external calls) so it is fast, free,
and 100% testable offline.

Decision flow:
    1. URL pattern matching — raw file hosts always use basic.
    2. Known JS-heavy domain matching — routes to Firecrawl.
    3. Availability check — fall back to the next-best available backend.
    4. Default — basic scraper (always available).

Override any decision by passing ``backend=`` explicitly to ``scrape_url()``.
"""

from __future__ import annotations

import re
from enum import Enum
from typing import TYPE_CHECKING, Optional
from urllib.parse import urlparse

if TYPE_CHECKING:
    pass


class Backend(str, Enum):
    """Named backends that can be explicitly requested."""

    BASIC = "basic"
    FIRECRAWL = "firecrawl"
    TAVILY = "tavily"
    AUTO = "auto"


# ---------------------------------------------------------------------------
# Domain / pattern lists
# ---------------------------------------------------------------------------

# Patterns where the content is guaranteed to be plain text or clean HTML —
# no JavaScript execution needed.
_SIMPLE_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"raw\.githubusercontent\.com"),
    re.compile(r"gist\.githubusercontent\.com"),
    re.compile(r"github\.com/.+/raw/"),
    re.compile(r"pastebin\.com/raw/"),
    re.compile(r"arxiv\.org/abs/"),
    re.compile(r"arxiv\.org/pdf/"),
    re.compile(r"hacker-?news\.firebaseio\.com"),
]

# Domains known to require JavaScript for meaningful content.
# Firecrawl is preferred here.
_JS_HEAVY_DOMAINS: frozenset[str] = frozenset(
    [
        "twitter.com",
        "x.com",
        "linkedin.com",
        "facebook.com",
        "instagram.com",
        "tiktok.com",
        "medium.com",
        "substack.com",
        "notion.so",
        "figma.com",
        "vercel.app",
        "netlify.app",
        "nextjs.org",
        "react.dev",
        "angular.io",
    ]
)

# TLDs / domains where content is commonly paywalled or requires
# authentication — Tavily's cached access often bypasses this.
_PAYWALL_DOMAINS: frozenset[str] = frozenset(
    [
        "wsj.com",
        "ft.com",
        "nytimes.com",
        "bloomberg.com",
        "businessinsider.com",
        "economist.com",
        "thetimes.co.uk",
        "telegraph.co.uk",
        "wired.com",
        "theatlantic.com",
    ]
)


# ---------------------------------------------------------------------------
# BackendSelector
# ---------------------------------------------------------------------------


class BackendSelector:
    """
    Stateless helper that maps a URL to the best available backend.

    Example::

        selector = BackendSelector(firecrawl_available=True, tavily_available=False)
        backend = selector.select("https://medium.com/@author/article-slug")
        assert backend == Backend.FIRECRAWL
    """

    def __init__(
        self,
        firecrawl_available: bool = False,
        tavily_available: bool = False,
    ) -> None:
        """
        Args:
            firecrawl_available: Set to ``True`` when the Firecrawl SDK is
                installed AND ``FIRECRAWL_API_KEY`` is set.
            tavily_available: Set to ``True`` when the Tavily SDK is
                installed AND ``TAVILY_API_KEY`` is set.
        """
        self.firecrawl_available = firecrawl_available
        self.tavily_available = tavily_available

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def select(self, url: str, hint: Optional[Backend] = None) -> Backend:
        """
        Select the best backend for *url*.

        Args:
            url: Fully-qualified URL to evaluate.
            hint: Caller-supplied override.  ``Backend.AUTO`` and ``None``
                  both trigger automatic selection.

        Returns:
            The chosen :class:`Backend`.
        """
        if hint is not None and hint != Backend.AUTO:
            return hint

        # Step 1: plain-text / raw-file patterns → always basic
        if self._is_simple(url):
            return Backend.BASIC

        # Step 2: paywall domains → prefer Tavily
        if self._is_paywalled(url):
            if self.tavily_available:
                return Backend.TAVILY
            # Tavily unavailable — fall through to JS check

        # Step 3: JS-heavy domains → prefer Firecrawl, then Tavily (still better
        # than basic for bot-protected sites), then basic.
        if self._is_js_heavy(url):
            if self.firecrawl_available:
                return Backend.FIRECRAWL
            if self.tavily_available:
                return Backend.TAVILY
            return Backend.BASIC

        # Step 4: unknown domain — try Firecrawl (best quality) if available,
        # then Tavily, then basic.
        if self.firecrawl_available:
            return Backend.FIRECRAWL
        if self.tavily_available:
            return Backend.TAVILY

        return Backend.BASIC

    def explain(self, url: str, hint: Optional[Backend] = None) -> str:
        """
        Return a human-readable explanation of why a backend was chosen.

        Useful for debugging and logging.

        Args:
            url: URL to evaluate.
            hint: Optional caller-supplied override.

        Returns:
            Explanation string.
        """
        chosen = self.select(url, hint)

        if hint is not None and hint != Backend.AUTO:
            return f"Backend '{chosen.value}' selected by caller override."

        if self._is_simple(url):
            return (
                f"Backend '{chosen.value}' selected: URL matches a known static-content "
                f"pattern (raw file / plain HTML)."
            )

        if self._is_paywalled(url):
            if self.tavily_available:
                return (
                    f"Backend '{chosen.value}' selected: domain is known to be "
                    f"paywalled; Tavily's cached access is preferred."
                )
            return (
                f"Backend '{chosen.value}' selected: domain is paywalled but Tavily "
                f"is not available."
            )

        if self._is_js_heavy(url):
            if self.firecrawl_available:
                return (
                    f"Backend '{chosen.value}' selected: domain requires JavaScript "
                    f"rendering; Firecrawl is preferred."
                )
            if self.tavily_available:
                return (
                    f"Backend '{chosen.value}' selected: domain requires JavaScript "
                    f"rendering; Firecrawl unavailable — using Tavily as next-best option."
                )
            return (
                f"Backend '{chosen.value}' selected: domain requires JavaScript "
                f"but neither Firecrawl nor Tavily is available."
            )

        availability = []
        if self.firecrawl_available:
            availability.append("Firecrawl")
        if self.tavily_available:
            availability.append("Tavily")
        if not availability:
            availability.append("basic only")

        return (
            f"Backend '{chosen.value}' selected: domain not in any known list; "
            f"best available backend chosen (available: {', '.join(availability)})."
        )

    # ------------------------------------------------------------------
    # Internal matchers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_simple(url: str) -> bool:
        return any(p.search(url) for p in _SIMPLE_PATTERNS)

    @staticmethod
    def _strip_www(netloc: str) -> str:
        """Remove a leading 'www.' prefix (exact prefix, not character strip)."""
        return netloc[4:] if netloc.startswith("www.") else netloc

    @classmethod
    def _is_js_heavy(cls, url: str) -> bool:
        netloc = cls._strip_www(urlparse(url).netloc.lower())
        return any(domain == netloc or netloc.endswith(f".{domain}")
                   for domain in _JS_HEAVY_DOMAINS)

    @classmethod
    def _is_paywalled(cls, url: str) -> bool:
        netloc = cls._strip_www(urlparse(url).netloc.lower())
        return any(domain == netloc or netloc.endswith(f".{domain}")
                   for domain in _PAYWALL_DOMAINS)


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------

_default_selector: Optional[BackendSelector] = None


def _get_default_selector(
    firecrawl_available: bool,
    tavily_available: bool,
) -> BackendSelector:
    """Return a singleton selector, recreated if availability changes."""
    global _default_selector
    if (
        _default_selector is None
        or _default_selector.firecrawl_available != firecrawl_available
        or _default_selector.tavily_available != tavily_available
    ):
        _default_selector = BackendSelector(
            firecrawl_available=firecrawl_available,
            tavily_available=tavily_available,
        )
    return _default_selector


def select_backend(
    url: str,
    firecrawl_available: bool = False,
    tavily_available: bool = False,
    hint: Optional[Backend] = None,
) -> Backend:
    """
    Module-level convenience wrapper around :class:`BackendSelector`.

    Args:
        url: URL to evaluate.
        firecrawl_available: Whether Firecrawl SDK + key are present.
        tavily_available: Whether Tavily SDK + key are present.
        hint: Optional caller-supplied backend override.

    Returns:
        Chosen :class:`Backend`.
    """
    return _get_default_selector(firecrawl_available, tavily_available).select(
        url, hint
    )
