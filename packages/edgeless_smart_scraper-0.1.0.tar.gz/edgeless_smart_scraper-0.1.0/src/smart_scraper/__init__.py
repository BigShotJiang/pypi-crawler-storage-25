"""
smart-scraper: Intelligent web scraping with automatic backend selection.

Core API:
    from smart_scraper import scrape_url
    result = scrape_url("https://example.com")
    print(result.content)

Available backends:
    - basic    : requests + BeautifulSoup (zero extra deps, always available)
    - firecrawl: Firecrawl SDK (optional, handles JS-heavy sites)
    - tavily   : Tavily search API (optional, handles paywalled/research pages)

Install extras:
    pip install smart-scraper[firecrawl]
    pip install smart-scraper[tavily]
    pip install smart-scraper[all]
"""

from .scraper import scrape_url, ScrapeResult, Backend
from .selector import BackendSelector, select_backend

__all__ = [
    "scrape_url",
    "ScrapeResult",
    "Backend",
    "BackendSelector",
    "select_backend",
]

__version__ = "0.1.0"
