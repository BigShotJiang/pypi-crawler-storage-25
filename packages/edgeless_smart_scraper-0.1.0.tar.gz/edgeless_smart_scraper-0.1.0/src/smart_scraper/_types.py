"""
Shared type definitions used across all modules.

Kept in a single module to avoid circular imports.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class ScrapeResult:
    """
    Normalised result returned by every backend.

    Attributes:
        url:      The URL that was scraped.
        content:  Extracted text content (Markdown where possible).
        title:    Page title, if detected.
        metadata: Backend-specific metadata dict (keys vary by backend).
        source:   Backend name that produced this result
                  (``"basic"``, ``"firecrawl"``, or ``"tavily"``).
        success:  ``True`` when the fetch completed without errors.
        error:    Human-readable error description when ``success`` is ``False``.
    """

    url: str
    content: str
    title: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = field(default=None)
    source: str = "basic"
    success: bool = True
    error: Optional[str] = None

    def __bool__(self) -> bool:
        return self.success
