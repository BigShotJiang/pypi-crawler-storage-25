"""
Backend implementations for smart-scraper.

Each backend exposes a single function with this signature:

    def fetch(url: str, **kwargs) -> ScrapeResult: ...

Backends degrade gracefully when optional dependencies are not installed.
"""

from .basic import BasicBackend
from .firecrawl import FirecrawlBackend
from .tavily import TavilyBackend

__all__ = ["BasicBackend", "FirecrawlBackend", "TavilyBackend"]
