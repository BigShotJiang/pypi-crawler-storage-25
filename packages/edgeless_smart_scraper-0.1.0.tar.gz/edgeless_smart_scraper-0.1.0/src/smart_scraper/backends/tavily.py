"""
Tavily backend: search-powered content extraction.

Tavily is best suited for research queries, paywalled or login-walled
content, and situations where you want both web search AND page content
in one API call. It returns AI-curated snippets alongside raw page text.

Requires: tavily-python  (install via `pip install smart-scraper[tavily]`)
API key:  TAVILY_API_KEY environment variable (or pass api_key= directly)
Free tier: 1,000 API credits/month (as of 2024). See https://tavily.com for plans.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .._types import ScrapeResult

# Optional import — degrades gracefully when the package is not installed.
try:
    from tavily import TavilyClient as _TavilySDKClient

    _TAVILY_INSTALLED = True
except ImportError:
    _TAVILY_INSTALLED = False
    _TavilySDKClient = None  # type: ignore[assignment,misc]


@dataclass
class SearchResult:
    """A single result returned by a Tavily search."""

    title: str
    url: str
    content: str  # Snippet / AI-curated excerpt
    score: float
    raw_content: Optional[str] = None  # Full page text (requires include_raw_content)


@dataclass
class TavilySearchResponse:
    """Aggregated response from a Tavily search call."""

    query: str
    results: List[SearchResult] = field(default_factory=list)
    answer: Optional[str] = None  # AI-generated direct answer
    success: bool = True
    error: Optional[str] = None


class TavilyBackend:
    """
    Backend that delegates to the Tavily search + extraction API.

    Best for: research queries, discovering relevant pages for a topic,
    paywalled content (Tavily's crawler often has cached access),
    and situations where an AI-generated answer is useful.

    Falls back to an error ScrapeResult (not an exception) when the SDK
    is not installed or the API key is missing.
    """

    name = "tavily"

    def __init__(self, api_key: Optional[str] = None) -> None:
        """
        Args:
            api_key: Tavily API key. Falls back to TAVILY_API_KEY env var.
        """
        self.api_key = api_key or os.environ.get("TAVILY_API_KEY")
        self._client = None

    @property
    def client(self):  # type: ignore[return]
        """Lazy-initialised Tavily SDK client."""
        if self._client is None and self.is_available:
            self._client = _TavilySDKClient(api_key=self.api_key)  # type: ignore[call-arg]
        return self._client

    @property
    def is_available(self) -> bool:
        """True only when the SDK is installed and an API key is set."""
        return bool(_TAVILY_INSTALLED and self.api_key)

    # ------------------------------------------------------------------
    # Scrape-compatible interface (URL → ScrapeResult)
    # ------------------------------------------------------------------

    def fetch(self, url: str) -> ScrapeResult:
        """
        Extract content from a specific URL using Tavily's extract endpoint.

        This is the entry point used by BackendSelector / scrape_url().

        Args:
            url: Fully-qualified URL to extract.

        Returns:
            ScrapeResult with the page's raw content.
        """
        if not self.is_available:
            msg = (
                "Tavily backend not available. "
                "Install with: pip install smart-scraper[tavily] "
                "and set TAVILY_API_KEY."
            )
            return ScrapeResult(url=url, content="", source=self.name,
                                success=False, error=msg)

        try:
            data = self.extract([url])
            content = data.get(url, "")
            return ScrapeResult(
                url=url,
                content=content,
                source=self.name,
                success=bool(content),
                error=None if content else "No content returned by Tavily",
            )
        except Exception as exc:  # noqa: BLE001
            return ScrapeResult(
                url=url,
                content="",
                source=self.name,
                success=False,
                error=str(exc),
            )

    # ------------------------------------------------------------------
    # Search interface
    # ------------------------------------------------------------------

    def search(
        self,
        query: str,
        max_results: int = 5,
        search_depth: str = "basic",
        include_raw_content: bool = False,
        include_answer: bool = False,
        topic: str = "general",
        include_domains: Optional[List[str]] = None,
        exclude_domains: Optional[List[str]] = None,
    ) -> TavilySearchResponse:
        """
        Search the web using the Tavily search API.

        Args:
            query: Search query string.
            max_results: Number of results to return (1–10).
            search_depth: ``"basic"`` (fast) or ``"advanced"`` (thorough).
            include_raw_content: Include full page content in results.
            include_answer: Include an AI-generated direct answer.
            topic: Result category — ``"general"``, ``"news"``, or ``"finance"``.
            include_domains: Restrict results to these domains.
            exclude_domains: Exclude results from these domains.

        Returns:
            TavilySearchResponse containing matched SearchResult objects.
        """
        if not self.is_available:
            return TavilySearchResponse(
                query=query,
                success=False,
                error=(
                    "Tavily backend not available. "
                    "Install with: pip install smart-scraper[tavily] "
                    "and set TAVILY_API_KEY."
                ),
            )

        try:
            params: Dict = {
                "query": query,
                "max_results": min(max_results, 10),
                "search_depth": search_depth,
                "include_raw_content": include_raw_content,
                "include_answer": include_answer,
                "topic": topic,
            }
            if include_domains:
                params["include_domains"] = include_domains
            if exclude_domains:
                params["exclude_domains"] = exclude_domains

            response = self.client.search(**params)

            results = [
                SearchResult(
                    title=item.get("title", ""),
                    url=item.get("url", ""),
                    content=item.get("content", ""),
                    score=float(item.get("score", 0.0)),
                    raw_content=item.get("raw_content") if include_raw_content else None,
                )
                for item in response.get("results", [])
            ]

            return TavilySearchResponse(
                query=query,
                results=results,
                answer=response.get("answer") if include_answer else None,
                success=True,
            )

        except Exception as exc:  # noqa: BLE001
            return TavilySearchResponse(
                query=query,
                success=False,
                error=str(exc),
            )

    # ------------------------------------------------------------------
    # Extract interface
    # ------------------------------------------------------------------

    def extract(self, urls: List[str]) -> Dict[str, str]:
        """
        Extract raw content from a list of specific URLs.

        Args:
            urls: URLs to extract content from.

        Returns:
            Mapping of ``{url: content_string}``.

        Raises:
            RuntimeError: If Tavily is unavailable or the API call fails.
        """
        if not self.is_available:
            raise RuntimeError(
                "Tavily backend not available. "
                "Install with: pip install smart-scraper[tavily] "
                "and set TAVILY_API_KEY."
            )

        try:
            response = self.client.extract(urls=urls)
            return {
                item.get("url", ""): item.get("raw_content", "")
                for item in response.get("results", [])
                if item.get("url")
            }
        except Exception as exc:  # noqa: BLE001
            raise RuntimeError(f"Tavily extraction failed: {exc}") from exc

    def get_search_context(
        self,
        query: str,
        max_results: int = 5,
        search_depth: str = "basic",
    ) -> str:
        """
        Return a single string of concatenated search results.

        Useful as a context window for LLM prompts.

        Args:
            query: Search query.
            max_results: Number of search results to include.
            search_depth: ``"basic"`` or ``"advanced"``.

        Returns:
            Concatenated content string, empty on error.
        """
        if not self.is_available:
            return ""
        try:
            return self.client.get_search_context(
                query=query,
                max_results=max_results,
                search_depth=search_depth,
            )
        except Exception:  # noqa: BLE001
            return ""

    def qna_search(self, query: str, search_depth: str = "advanced") -> str:
        """
        Get a direct AI-generated answer to a question.

        Args:
            query: Question to answer.
            search_depth: ``"basic"`` or ``"advanced"``.

        Returns:
            AI-generated answer string, empty on error.
        """
        if not self.is_available:
            return ""
        try:
            return self.client.qna_search(query=query, search_depth=search_depth)
        except Exception:  # noqa: BLE001
            return ""
