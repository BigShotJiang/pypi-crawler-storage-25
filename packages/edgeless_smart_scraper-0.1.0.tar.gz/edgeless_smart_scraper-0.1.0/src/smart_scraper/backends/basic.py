"""
Basic backend: requests + BeautifulSoup.

This backend is always available (zero optional dependencies beyond the core
install) and handles static HTML pages reliably. It does NOT execute
JavaScript, so single-page apps and heavily dynamic sites will return
partial content.

Requires: requests, beautifulsoup4  (both are core dependencies)
"""

from __future__ import annotations

import re
from typing import Optional
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

from .._types import ScrapeResult

# Default headers that mimic a real browser well enough for most CDNs.
_DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (compatible; SmartScraper/0.1; "
        "+https://github.com/edgeless-ai/smart-scraper)"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
}


class BasicBackend:
    """
    Lightweight scraper using requests + BeautifulSoup.

    Best for: static HTML, documentation sites, GitHub raw files,
    news articles, blogs without heavy JS rendering.

    Not suitable for: SPAs, login-walled content, sites that require
    JavaScript execution to render meaningful content.
    """

    name = "basic"

    def __init__(self, timeout: int = 30) -> None:
        """
        Args:
            timeout: HTTP request timeout in seconds.
        """
        self.timeout = timeout
        self._session: Optional[requests.Session] = None

    @property
    def session(self) -> requests.Session:
        """Lazy-initialised requests Session (connection pooling)."""
        if self._session is None:
            self._session = requests.Session()
            self._session.headers.update(_DEFAULT_HEADERS)
        return self._session

    @property
    def is_available(self) -> bool:
        """Basic backend is always available."""
        return True

    def fetch(self, url: str, timeout: Optional[int] = None) -> ScrapeResult:
        """
        Fetch a URL and return its text content.

        Args:
            url: Fully-qualified URL to fetch.
            timeout: Override the instance-level timeout for this request.

        Returns:
            ScrapeResult populated from the HTTP response.
        """
        _timeout = timeout if timeout is not None else self.timeout
        try:
            response = self.session.get(url, timeout=_timeout, allow_redirects=True)
            response.raise_for_status()
            content_type = response.headers.get("Content-Type", "")
            if "html" not in content_type and "text" not in content_type:
                return ScrapeResult(
                    url=url,
                    content="",
                    source=self.name,
                    success=False,
                    error=f"Unexpected content type: {content_type}",
                )
            return self._parse(url, response.text)
        except requests.RequestException as exc:
            return ScrapeResult(
                url=url,
                content="",
                source=self.name,
                success=False,
                error=str(exc),
            )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _parse(self, url: str, html: str) -> ScrapeResult:
        """Convert raw HTML into a clean ScrapeResult."""
        soup = BeautifulSoup(html, "html.parser")

        # Extract <title>
        title_tag = soup.find("title")
        title = title_tag.get_text(strip=True) if title_tag else None

        # Remove clutter: scripts, styles, nav, header, footer, ads
        for tag in soup(["script", "style", "noscript", "nav", "header",
                          "footer", "aside", "form", "iframe"]):
            tag.decompose()

        # Prefer <main> or <article> when present (signals main content)
        main = soup.find("main") or soup.find("article")
        target = main if main else soup.find("body") or soup

        content = self._to_markdown(target)

        metadata = {
            "title": title,
            "url": url,
            "domain": urlparse(url).netloc,
        }

        return ScrapeResult(
            url=url,
            content=content,
            title=title,
            metadata=metadata,
            source=self.name,
            success=True,
        )

    def _to_markdown(self, element: BeautifulSoup) -> str:
        """
        Convert a BeautifulSoup element tree to lightweight Markdown.

        Handles headings, paragraphs, lists, links, code blocks, and
        normalises whitespace.
        """
        lines: list[str] = []

        def _walk(node: BeautifulSoup) -> None:  # type: ignore[type-arg]
            name = getattr(node, "name", None)

            if name is None:
                # NavigableString
                text = str(node)
                stripped = re.sub(r"\s+", " ", text).strip()
                if stripped:
                    lines.append(stripped)
                return

            if name in ("h1", "h2", "h3", "h4", "h5", "h6"):
                level = int(name[1])
                text = node.get_text(" ", strip=True)
                if text:
                    lines.append(f"\n{'#' * level} {text}\n")
                return

            if name == "p":
                # Recurse into children so inline elements (e.g. <code>, <a>)
                # are rendered with their own Markdown markers.
                before = len(lines)
                lines.append("\n")
                for child in node.children:
                    _walk(child)  # type: ignore[arg-type]
                lines.append("\n")
                # If recursion added nothing meaningful, remove the blank lines.
                if len(lines) == before + 2:
                    lines.pop()
                    lines.pop()
                return

            if name in ("ul", "ol"):
                for i, li in enumerate(node.find_all("li", recursive=False), 1):
                    prefix = f"{i}." if name == "ol" else "-"
                    text = li.get_text(" ", strip=True)
                    if text:
                        lines.append(f"{prefix} {text}")
                lines.append("")
                return

            if name == "a":
                text = node.get_text(" ", strip=True)
                href = node.get("href", "")
                if text and href:
                    lines.append(f"[{text}]({href})")
                elif text:
                    lines.append(text)
                return

            if name == "code":
                text = node.get_text()
                if "\n" in text:
                    lines.append(f"\n```\n{text.strip()}\n```\n")
                else:
                    lines.append(f"`{text.strip()}`")
                return

            if name == "pre":
                text = node.get_text()
                lines.append(f"\n```\n{text.strip()}\n```\n")
                return

            if name == "blockquote":
                for child_line in node.get_text("\n", strip=True).splitlines():
                    lines.append(f"> {child_line}")
                lines.append("")
                return

            if name == "br":
                lines.append("")
                return

            if name == "hr":
                lines.append("\n---\n")
                return

            # Default: recurse into children
            for child in node.children:
                _walk(child)  # type: ignore[arg-type]

        _walk(element)

        # Collapse excessive blank lines
        text = "\n".join(lines)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()
