"""
Firecrawl backend: cloud-based JS rendering + structured extraction.

Firecrawl handles JavaScript-heavy sites, anti-bot measures, and returns
clean Markdown output. It is the best choice for SPAs, social platforms,
and sites that require a real browser to render content.

Requires: firecrawl-py  (install via `pip install smart-scraper[firecrawl]`)
API key:  FIRECRAWL_API_KEY environment variable (or pass api_key= directly)
Free tier: 500 scrapes total (as of 2024). See https://firecrawl.dev for plans.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from .._types import ScrapeResult

# Optional import — degrades gracefully when the package is not installed.
try:
    from firecrawl import FirecrawlApp as _FirecrawlApp

    _FIRECRAWL_INSTALLED = True
except ImportError:
    _FIRECRAWL_INSTALLED = False
    _FirecrawlApp = None  # type: ignore[assignment,misc]


class FirecrawlBackend:
    """
    Backend that delegates to the Firecrawl cloud API.

    Best for: JS-rendered pages, SPAs (React/Vue/Next.js), social media,
    subscription newsletters, sites protected by bot-detection middleware.

    Falls back to an error ScrapeResult (not an exception) when the SDK
    is not installed or the API key is missing.
    """

    name = "firecrawl"

    def __init__(self, api_key: Optional[str] = None, timeout: int = 30) -> None:
        """
        Args:
            api_key: Firecrawl API key. Falls back to FIRECRAWL_API_KEY env var.
            timeout: Per-request timeout in seconds (converted to ms internally).
        """
        self.api_key = api_key or os.environ.get("FIRECRAWL_API_KEY")
        self.timeout = timeout
        self._app: Optional[Any] = None

    @property
    def app(self) -> Optional[Any]:
        """Lazy-initialised FirecrawlApp instance."""
        if self._app is None and self.is_available:
            self._app = _FirecrawlApp(api_key=self.api_key)
        return self._app

    @property
    def is_available(self) -> bool:
        """True only when both the SDK is installed and an API key is set."""
        return bool(_FIRECRAWL_INSTALLED and self.api_key)

    def fetch(
        self,
        url: str,
        only_main_content: bool = True,
        formats: Optional[List[str]] = None,
        timeout: Optional[int] = None,
    ) -> ScrapeResult:
        """
        Scrape a URL via the Firecrawl API.

        Args:
            url: Fully-qualified URL to scrape.
            only_main_content: Strip navigation, footers, and sidebars.
            formats: Firecrawl output formats. Defaults to ["markdown"].
            timeout: Override instance timeout for this request (seconds).

        Returns:
            ScrapeResult with Markdown content and page metadata.
        """
        if not self.is_available:
            msg = (
                "Firecrawl backend not available. "
                "Install with: pip install smart-scraper[firecrawl] "
                "and set FIRECRAWL_API_KEY."
            )
            return ScrapeResult(url=url, content="", source=self.name,
                                success=False, error=msg)

        _formats = formats or ["markdown"]
        _timeout_ms = (timeout if timeout is not None else self.timeout) * 1000

        try:
            raw = self.app.scrape(  # type: ignore[union-attr]
                url,
                formats=_formats,
                only_main_content=only_main_content,
                timeout=_timeout_ms,
            )
            return self._parse_result(url, raw)
        except Exception as exc:  # noqa: BLE001
            return ScrapeResult(
                url=url,
                content="",
                source=self.name,
                success=False,
                error=str(exc),
            )

    def crawl(
        self,
        url: str,
        max_pages: int = 50,
        max_depth: int = 2,
        only_main_content: bool = True,
    ) -> List[ScrapeResult]:
        """
        Crawl a full site starting from *url*.

        Args:
            url: Entry-point URL.
            max_pages: Maximum number of pages to crawl.
            max_depth: Maximum link depth to follow from the entry URL.
            only_main_content: Strip boilerplate from each page.

        Returns:
            List of ScrapeResult, one per crawled page.
        """
        if not self.is_available:
            msg = (
                "Firecrawl backend not available. "
                "Install with: pip install smart-scraper[firecrawl] "
                "and set FIRECRAWL_API_KEY."
            )
            return [ScrapeResult(url=url, content="", source=self.name,
                                 success=False, error=msg)]

        try:
            raw = self.app.crawl(  # type: ignore[union-attr]
                url,
                limit=max_pages,
                max_depth=max_depth,
                scrape_options={
                    "formats": ["markdown"],
                    "only_main_content": only_main_content,
                },
                poll_interval=5,
            )

            pages = raw if isinstance(raw, list) else getattr(raw, "data", [])
            return [self._parse_page(url, page) for page in pages]

        except Exception as exc:  # noqa: BLE001
            return [ScrapeResult(url=url, content="", source=self.name,
                                 success=False, error=str(exc))]

    def extract_structured(
        self,
        url: str,
        schema: Dict[str, Any],
        prompt: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        LLM-powered structured extraction from a URL.

        Args:
            url: URL to extract from.
            schema: JSON Schema defining the expected output structure.
            prompt: Optional instruction to guide the extraction model.

        Returns:
            Extracted data matching the schema.

        Raises:
            RuntimeError: If Firecrawl is unavailable or the extraction fails.
        """
        if not self.is_available:
            raise RuntimeError(
                "Firecrawl backend not available. "
                "Install with: pip install smart-scraper[firecrawl] "
                "and set FIRECRAWL_API_KEY."
            )

        try:
            result = self.app.extract(  # type: ignore[union-attr]
                urls=[url],
                schema=schema,
                prompt=prompt,
            )
            if hasattr(result, "data"):
                return result.data[0] if result.data else {}
            if isinstance(result, dict):
                return result.get("data", [{}])[0]
            return {}
        except Exception as exc:  # noqa: BLE001
            raise RuntimeError(f"Firecrawl extraction failed: {exc}") from exc

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _parse_result(self, url: str, raw: Any) -> ScrapeResult:
        """Convert a raw Firecrawl scrape response into a ScrapeResult."""
        content = getattr(raw, "markdown", "") or getattr(raw, "html", "") or ""
        meta_obj = getattr(raw, "metadata", None)

        title = None
        metadata: Optional[Dict[str, Any]] = None
        if meta_obj is not None:
            title = getattr(meta_obj, "title", None)
            metadata = {
                "title": title,
                "url": getattr(meta_obj, "url", url),
                "language": getattr(meta_obj, "language", None),
                "status_code": getattr(meta_obj, "status_code", None),
            }

        return ScrapeResult(
            url=url,
            content=content,
            title=title,
            metadata=metadata,
            source=self.name,
            success=True,
        )

    def _parse_page(self, fallback_url: str, page: Any) -> ScrapeResult:
        """Convert one page from a crawl result."""
        meta_obj = getattr(page, "metadata", None)
        page_url = fallback_url
        title = None
        if meta_obj is not None:
            page_url = getattr(meta_obj, "url", fallback_url)
            title = getattr(meta_obj, "title", None)
        content = getattr(page, "markdown", "") or ""
        return ScrapeResult(
            url=page_url,
            content=content,
            title=title,
            metadata={"title": title, "url": page_url},
            source=self.name,
            success=True,
        )
