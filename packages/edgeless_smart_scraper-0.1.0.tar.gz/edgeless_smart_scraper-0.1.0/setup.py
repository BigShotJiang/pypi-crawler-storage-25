"""
Minimal setup.py for compatibility with older pip versions.

All metadata is in pyproject.toml.  This file only exists so that
`pip install -e .` works on environments that pre-date PEP 660 support.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
