"""
Tests for the basic scraper backend.

Live network tests are gated behind the ``--live`` pytest flag and are skipped
by default in CI environments.  All other tests use mocking or local fixtures.
"""

from __future__ import annotations

import textwrap
from unittest.mock import MagicMock, patch

import pytest
import requests

from smart_scraper._types import ScrapeResult
from smart_scraper.backends.basic import BasicBackend


# ---------------------------------------------------------------------------
# Fixtures and helpers
# ---------------------------------------------------------------------------

SIMPLE_HTML = textwrap.dedent(
    """
    <!DOCTYPE html>
    <html>
    <head><title>Test Page</title></head>
    <body>
      <nav>Nav link</nav>
      <main>
        <h1>Main Heading</h1>
        <p>First paragraph.</p>
        <p>Second paragraph.</p>
        <ul>
          <li>Item one</li>
          <li>Item two</li>
        </ul>
        <a href="https://example.com">Example link</a>
      </main>
      <footer>Footer content</footer>
    </body>
    </html>
    """
).strip()

MINIMAL_HTML = "<html><body><p>Hello world</p></body></html>"

SCRIPT_HEAVY_HTML = textwrap.dedent(
    """
    <html><head><title>App</title></head><body>
    <script>var x = 1; document.write('injected');</script>
    <style>.hidden { display: none; }</style>
    <main><p>Real content here.</p></main>
    </body></html>
    """
).strip()


def _make_response(html: str, status_code: int = 200) -> MagicMock:
    """Return a mock requests.Response for a given HTML body."""
    mock_resp = MagicMock(spec=requests.Response)
    mock_resp.status_code = status_code
    mock_resp.text = html
    mock_resp.headers = {"Content-Type": "text/html; charset=utf-8"}
    mock_resp.raise_for_status = MagicMock()
    return mock_resp


# ---------------------------------------------------------------------------
# BasicBackend — is_available
# ---------------------------------------------------------------------------

class TestIsAvailable:
    def test_always_true(self) -> None:
        assert BasicBackend().is_available is True


# ---------------------------------------------------------------------------
# BasicBackend — title extraction
# ---------------------------------------------------------------------------

class TestTitleExtraction:
    def test_extracts_title(self) -> None:
        backend = BasicBackend()
        result = backend._parse("https://example.com", SIMPLE_HTML)
        assert result.title == "Test Page"

    def test_no_title_returns_none(self) -> None:
        backend = BasicBackend()
        result = backend._parse("https://example.com", MINIMAL_HTML)
        assert result.title is None

    def test_title_in_metadata(self) -> None:
        backend = BasicBackend()
        result = backend._parse("https://example.com", SIMPLE_HTML)
        assert result.metadata is not None
        assert result.metadata["title"] == "Test Page"


# ---------------------------------------------------------------------------
# BasicBackend — content cleaning
# ---------------------------------------------------------------------------

class TestContentCleaning:
    def test_scripts_stripped(self) -> None:
        backend = BasicBackend()
        result = backend._parse("https://example.com", SCRIPT_HEAVY_HTML)
        assert "var x = 1" not in result.content
        assert "document.write" not in result.content

    def test_styles_stripped(self) -> None:
        backend = BasicBackend()
        result = backend._parse("https://example.com", SCRIPT_HEAVY_HTML)
        assert ".hidden" not in result.content

    def test_nav_stripped(self) -> None:
        backend = BasicBackend()
        result = backend._parse("https://example.com", SIMPLE_HTML)
        assert "Nav link" not in result.content

    def test_footer_stripped(self) -> None:
        backend = BasicBackend()
        result = backend._parse("https://example.com", SIMPLE_HTML)
        assert "Footer content" not in result.content

    def test_main_content_preserved(self) -> None:
        backend = BasicBackend()
        result = backend._parse("https://example.com", SIMPLE_HTML)
        assert "Main Heading" in result.content
        assert "First paragraph" in result.content
        assert "Second paragraph" in result.content

    def test_real_content_preserved_script_heavy(self) -> None:
        backend = BasicBackend()
        result = backend._parse("https://example.com", SCRIPT_HEAVY_HTML)
        assert "Real content here" in result.content


# ---------------------------------------------------------------------------
# BasicBackend — markdown conversion
# ---------------------------------------------------------------------------

class TestMarkdownConversion:
    def test_headings(self) -> None:
        html = "<html><body><h1>Hello</h1><h2>Sub</h2></body></html>"
        backend = BasicBackend()
        result = backend._parse("https://example.com", html)
        assert "# Hello" in result.content
        assert "## Sub" in result.content

    def test_unordered_list(self) -> None:
        html = "<html><body><ul><li>A</li><li>B</li></ul></body></html>"
        backend = BasicBackend()
        result = backend._parse("https://example.com", html)
        assert "- A" in result.content
        assert "- B" in result.content

    def test_ordered_list(self) -> None:
        html = "<html><body><ol><li>First</li><li>Second</li></ol></body></html>"
        backend = BasicBackend()
        result = backend._parse("https://example.com", html)
        assert "1." in result.content
        assert "2." in result.content

    def test_inline_code(self) -> None:
        html = "<html><body><p>Use <code>print()</code></p></body></html>"
        backend = BasicBackend()
        result = backend._parse("https://example.com", html)
        assert "`print()`" in result.content

    def test_code_block(self) -> None:
        html = "<html><body><pre>def f():\n    pass</pre></body></html>"
        backend = BasicBackend()
        result = backend._parse("https://example.com", html)
        assert "```" in result.content

    def test_hyperlink(self) -> None:
        html = '<html><body><a href="https://example.com">Click here</a></body></html>'
        backend = BasicBackend()
        result = backend._parse("https://example.com", html)
        assert "[Click here](https://example.com)" in result.content

    def test_no_excessive_blank_lines(self) -> None:
        html = "<html><body><p>A</p><p>B</p><p>C</p></body></html>"
        backend = BasicBackend()
        result = backend._parse("https://example.com", html)
        assert "\n\n\n" not in result.content


# ---------------------------------------------------------------------------
# BasicBackend — metadata
# ---------------------------------------------------------------------------

class TestMetadata:
    def test_metadata_contains_url(self) -> None:
        backend = BasicBackend()
        result = backend._parse("https://example.com/page", MINIMAL_HTML)
        assert result.metadata is not None
        assert result.metadata["url"] == "https://example.com/page"

    def test_metadata_contains_domain(self) -> None:
        backend = BasicBackend()
        result = backend._parse("https://example.com/page", MINIMAL_HTML)
        assert result.metadata is not None
        assert result.metadata["domain"] == "example.com"

    def test_source_is_basic(self) -> None:
        backend = BasicBackend()
        result = backend._parse("https://example.com", MINIMAL_HTML)
        assert result.source == "basic"


# ---------------------------------------------------------------------------
# BasicBackend — fetch() via mocked requests
# ---------------------------------------------------------------------------

class TestFetch:
    def test_success_returns_scrape_result(self) -> None:
        backend = BasicBackend()
        with patch.object(backend.session, "get", return_value=_make_response(SIMPLE_HTML)):
            result = backend.fetch("https://example.com")
        assert result.success is True
        assert result.source == "basic"
        assert "Main Heading" in result.content

    def test_http_error_returns_failure(self) -> None:
        backend = BasicBackend()
        mock_resp = _make_response("", status_code=404)
        mock_resp.raise_for_status.side_effect = requests.HTTPError("404 Not Found")
        with patch.object(backend.session, "get", return_value=mock_resp):
            result = backend.fetch("https://example.com/missing")
        assert result.success is False
        assert result.error is not None

    def test_connection_error_returns_failure(self) -> None:
        backend = BasicBackend()
        with patch.object(
            backend.session, "get",
            side_effect=requests.ConnectionError("Name or service not known")
        ):
            result = backend.fetch("https://does-not-exist.example")
        assert result.success is False
        assert result.content == ""

    def test_non_html_content_type_returns_failure(self) -> None:
        backend = BasicBackend()
        mock_resp = _make_response(b"binary".decode(), status_code=200)  # type: ignore
        mock_resp.headers = {"Content-Type": "application/octet-stream"}
        with patch.object(backend.session, "get", return_value=mock_resp):
            result = backend.fetch("https://example.com/file.bin")
        assert result.success is False

    def test_timeout_override(self) -> None:
        """Ensure timeout parameter is passed to the requests call."""
        backend = BasicBackend(timeout=10)
        with patch.object(backend.session, "get", return_value=_make_response(MINIMAL_HTML)) as mock_get:
            backend.fetch("https://example.com", timeout=5)
        mock_get.assert_called_once()
        _, kwargs = mock_get.call_args
        assert kwargs["timeout"] == 5

    def test_default_timeout_used(self) -> None:
        backend = BasicBackend(timeout=42)
        with patch.object(backend.session, "get", return_value=_make_response(MINIMAL_HTML)) as mock_get:
            backend.fetch("https://example.com")
        _, kwargs = mock_get.call_args
        assert kwargs["timeout"] == 42


# ---------------------------------------------------------------------------
# ScrapeResult — __bool__
# ---------------------------------------------------------------------------

class TestScrapeResultBool:
    def test_successful_result_is_truthy(self) -> None:
        result = ScrapeResult(url="https://example.com", content="hello", success=True)
        assert bool(result) is True

    def test_failed_result_is_falsy(self) -> None:
        result = ScrapeResult(url="https://example.com", content="", success=False)
        assert bool(result) is False


# ---------------------------------------------------------------------------
# Live network tests (opt-in)
# ---------------------------------------------------------------------------

def pytest_addoption(parser):  # type: ignore[no-untyped-def]
    parser.addoption("--live", action="store_true", default=False,
                     help="Run live network tests (requires internet access).")


def pytest_collection_modifyitems(config, items):  # type: ignore[no-untyped-def]
    if not config.getoption("--live"):
        skip_live = pytest.mark.skip(reason="Pass --live to run network tests.")
        for item in items:
            if "live" in item.keywords:
                item.add_marker(skip_live)


@pytest.mark.live
def test_live_fetch_example_com() -> None:
    """Fetch example.com — requires internet access."""
    backend = BasicBackend()
    result = backend.fetch("https://example.com")
    assert result.success is True
    assert result.title is not None
    assert len(result.content) > 50


@pytest.mark.live
def test_live_fetch_arxiv() -> None:
    """Fetch an arxiv abstract — requires internet access."""
    backend = BasicBackend()
    result = backend.fetch("https://arxiv.org/abs/1706.03762")
    assert result.success is True
    assert len(result.content) > 100
