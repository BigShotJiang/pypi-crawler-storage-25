"""
Unit tests for the backend selector.

All tests run offline — no network calls, no API keys required.
"""

import pytest

from smart_scraper.selector import Backend, BackendSelector, select_backend


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def no_backends() -> BackendSelector:
    """Selector with no optional backends available."""
    return BackendSelector(firecrawl_available=False, tavily_available=False)


@pytest.fixture()
def firecrawl_only() -> BackendSelector:
    return BackendSelector(firecrawl_available=True, tavily_available=False)


@pytest.fixture()
def tavily_only() -> BackendSelector:
    return BackendSelector(firecrawl_available=False, tavily_available=True)


@pytest.fixture()
def all_backends() -> BackendSelector:
    return BackendSelector(firecrawl_available=True, tavily_available=True)


# ---------------------------------------------------------------------------
# Simple / static URL patterns → always basic
# ---------------------------------------------------------------------------

class TestSimplePatterns:
    SIMPLE_URLS = [
        "https://raw.githubusercontent.com/user/repo/main/file.md",
        "https://gist.githubusercontent.com/user/abc123/raw/snippet.py",
        "https://github.com/user/repo/raw/main/README.md",
        "https://pastebin.com/raw/abc123",
        "https://arxiv.org/abs/2301.00001",
        "https://arxiv.org/pdf/2301.00001",
    ]

    @pytest.mark.parametrize("url", SIMPLE_URLS)
    def test_simple_urls_always_basic(self, url: str, all_backends: BackendSelector) -> None:
        """Simple URLs return basic even when better backends are available."""
        assert all_backends.select(url) == Backend.BASIC

    @pytest.mark.parametrize("url", SIMPLE_URLS)
    def test_simple_urls_basic_no_backends(self, url: str, no_backends: BackendSelector) -> None:
        assert no_backends.select(url) == Backend.BASIC


# ---------------------------------------------------------------------------
# JS-heavy domain routing
# ---------------------------------------------------------------------------

class TestJSHeavyDomains:
    JS_URLS = [
        "https://twitter.com/user/status/123",
        "https://x.com/user/status/123",
        "https://www.linkedin.com/in/someuser",
        "https://medium.com/@author/article-slug",
        "https://substack.com/newsletter/issue",
        "https://notion.so/page/some-page-id",
        "https://figma.com/file/abc/design",
    ]

    @pytest.mark.parametrize("url", JS_URLS)
    def test_js_heavy_uses_firecrawl_when_available(
        self, url: str, firecrawl_only: BackendSelector
    ) -> None:
        assert firecrawl_only.select(url) == Backend.FIRECRAWL

    @pytest.mark.parametrize("url", JS_URLS)
    def test_js_heavy_falls_back_when_firecrawl_unavailable(
        self, url: str, no_backends: BackendSelector
    ) -> None:
        assert no_backends.select(url) == Backend.BASIC

    @pytest.mark.parametrize("url", JS_URLS)
    def test_js_heavy_uses_tavily_when_firecrawl_unavailable(
        self, url: str, tavily_only: BackendSelector
    ) -> None:
        # When Firecrawl is absent, Tavily is the next-best option for JS-heavy
        # sites (better than basic, which cannot execute JavaScript at all).
        assert tavily_only.select(url) == Backend.TAVILY


# ---------------------------------------------------------------------------
# Paywall domain routing
# ---------------------------------------------------------------------------

class TestPaywallDomains:
    PAYWALL_URLS = [
        "https://wsj.com/articles/some-story",
        "https://www.wsj.com/articles/some-story",
        "https://ft.com/content/some-id",
        "https://nytimes.com/2024/01/01/tech/article.html",
        "https://bloomberg.com/news/articles/abc",
        "https://economist.com/finance/2024/01/01/article",
    ]

    @pytest.mark.parametrize("url", PAYWALL_URLS)
    def test_paywall_uses_tavily_when_available(
        self, url: str, tavily_only: BackendSelector
    ) -> None:
        assert tavily_only.select(url) == Backend.TAVILY

    @pytest.mark.parametrize("url", PAYWALL_URLS)
    def test_paywall_falls_back_to_basic_when_no_backends(
        self, url: str, no_backends: BackendSelector
    ) -> None:
        # Without Tavily, basic is the only option.
        assert no_backends.select(url) == Backend.BASIC

    @pytest.mark.parametrize("url", PAYWALL_URLS)
    def test_paywall_prefers_tavily_over_firecrawl(
        self, url: str, all_backends: BackendSelector
    ) -> None:
        # Tavily has cached access; it should win over Firecrawl for paywalled domains.
        assert all_backends.select(url) == Backend.TAVILY


# ---------------------------------------------------------------------------
# Unknown domain routing
# ---------------------------------------------------------------------------

class TestUnknownDomains:
    UNKNOWN_URLS = [
        "https://example.com/page",
        "https://docs.python.org/3/library/json.html",
        "https://myblog.io/post/hello-world",
        "https://some-company.com/careers",
    ]

    @pytest.mark.parametrize("url", UNKNOWN_URLS)
    def test_unknown_prefers_firecrawl(
        self, url: str, firecrawl_only: BackendSelector
    ) -> None:
        assert firecrawl_only.select(url) == Backend.FIRECRAWL

    @pytest.mark.parametrize("url", UNKNOWN_URLS)
    def test_unknown_falls_back_to_tavily_without_firecrawl(
        self, url: str, tavily_only: BackendSelector
    ) -> None:
        assert tavily_only.select(url) == Backend.TAVILY

    @pytest.mark.parametrize("url", UNKNOWN_URLS)
    def test_unknown_basic_when_nothing_available(
        self, url: str, no_backends: BackendSelector
    ) -> None:
        assert no_backends.select(url) == Backend.BASIC

    @pytest.mark.parametrize("url", UNKNOWN_URLS)
    def test_unknown_prefers_firecrawl_over_tavily_when_both_available(
        self, url: str, all_backends: BackendSelector
    ) -> None:
        assert all_backends.select(url) == Backend.FIRECRAWL


# ---------------------------------------------------------------------------
# Explicit override (hint)
# ---------------------------------------------------------------------------

class TestHintOverride:
    def test_hint_basic_overrides_js_heavy(self, all_backends: BackendSelector) -> None:
        result = all_backends.select("https://medium.com/article", hint=Backend.BASIC)
        assert result == Backend.BASIC

    def test_hint_firecrawl_overrides_simple(self, all_backends: BackendSelector) -> None:
        result = all_backends.select(
            "https://raw.githubusercontent.com/user/repo/main/file.md",
            hint=Backend.FIRECRAWL,
        )
        assert result == Backend.FIRECRAWL

    def test_hint_tavily_overrides_everything(self, all_backends: BackendSelector) -> None:
        result = all_backends.select("https://example.com", hint=Backend.TAVILY)
        assert result == Backend.TAVILY

    def test_hint_auto_triggers_automatic_selection(
        self, firecrawl_only: BackendSelector
    ) -> None:
        result = firecrawl_only.select("https://example.com", hint=Backend.AUTO)
        # AUTO means automatic: unknown domain + firecrawl available → firecrawl
        assert result == Backend.FIRECRAWL

    def test_hint_none_triggers_automatic_selection(
        self, no_backends: BackendSelector
    ) -> None:
        result = no_backends.select("https://example.com", hint=None)
        assert result == Backend.BASIC


# ---------------------------------------------------------------------------
# Module-level select_backend() convenience function
# ---------------------------------------------------------------------------

class TestSelectBackendFunction:
    def test_returns_basic_with_no_backends(self) -> None:
        assert select_backend("https://example.com") == Backend.BASIC

    def test_returns_firecrawl_when_available(self) -> None:
        result = select_backend(
            "https://medium.com/article",
            firecrawl_available=True,
            tavily_available=False,
        )
        assert result == Backend.FIRECRAWL

    def test_hint_respected(self) -> None:
        result = select_backend(
            "https://medium.com/article",
            firecrawl_available=True,
            hint=Backend.BASIC,
        )
        assert result == Backend.BASIC


# ---------------------------------------------------------------------------
# explain() method
# ---------------------------------------------------------------------------

class TestExplain:
    def test_explain_returns_string(self, all_backends: BackendSelector) -> None:
        explanation = all_backends.explain("https://example.com")
        assert isinstance(explanation, str)
        assert len(explanation) > 0

    def test_explain_mentions_backend_name(self, no_backends: BackendSelector) -> None:
        explanation = no_backends.explain("https://example.com")
        assert "basic" in explanation.lower()

    def test_explain_caller_override(self, all_backends: BackendSelector) -> None:
        explanation = all_backends.explain("https://example.com", hint=Backend.BASIC)
        assert "override" in explanation.lower()

    def test_explain_js_heavy(self, firecrawl_only: BackendSelector) -> None:
        explanation = firecrawl_only.explain("https://medium.com/article")
        assert "javascript" in explanation.lower() or "js" in explanation.lower()

    def test_explain_paywall(self, tavily_only: BackendSelector) -> None:
        explanation = tavily_only.explain("https://wsj.com/articles/x")
        assert "paywall" in explanation.lower()


# ---------------------------------------------------------------------------
# Backend enum
# ---------------------------------------------------------------------------

class TestBackendEnum:
    def test_all_values_accessible(self) -> None:
        assert Backend.BASIC.value == "basic"
        assert Backend.FIRECRAWL.value == "firecrawl"
        assert Backend.TAVILY.value == "tavily"
        assert Backend.AUTO.value == "auto"

    def test_string_comparison(self) -> None:
        assert Backend.BASIC == "basic"
        assert Backend.FIRECRAWL == "firecrawl"
