project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "output_paths.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))

config <- default_project_config(project_root = project_root)
manifest <- inventory_input_artifacts(config)
write_inventory_outputs(manifest, config)

message("Inventoried ", nrow(manifest), " artifacts.")
message("Manifest written to ", output_file(config, "input_artifact_manifest"))
