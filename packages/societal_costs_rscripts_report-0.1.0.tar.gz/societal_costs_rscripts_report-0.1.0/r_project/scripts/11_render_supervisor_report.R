project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "output_paths.R"))
source(file.path(project_root, "R", "supervisor_figures.R"))

args <- parse_cli_args()
config <- default_project_config(project_root = project_root, args = args)
rebuild_figures <- parse_bool_flag(args$rebuild_figures %||% TRUE, default = TRUE)

report_path <- render_supervisor_report(config, rebuild_figures = rebuild_figures)

message("Progress report written to ", report_path)
