project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "output_paths.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "direct_cost_artifacts.R"))

config <- default_project_config(project_root = project_root)
artifacts <- build_direct_cost_artifacts(config)
output_paths <- if (isTRUE(artifacts$reused_existing)) {
  direct_cost_artifact_paths(config)
} else {
  write_direct_cost_artifacts(artifacts, config)
}

message("LMDB direct-cost rows: ", nrow(artifacts$lmdb_cost))
message("LPR direct-cost rows: ", nrow(artifacts$lpr_cost))
message("Primary-sector direct-cost rows: ", nrow(artifacts$primary_cost))
message("Hospital-drugs direct-cost rows: ", nrow(artifacts$hospital_drugs_cost))
message("Combined direct-cost rows: ", nrow(artifacts$combined_cost))
message("Combined direct-cost parquet written to ", output_paths$combined_cost_path)
message("Source inventory written to ", output_paths$source_inventory_path)
message("Component-year availability written to ", output_paths$component_year_availability_path)
message("Legacy LPR validation written to ", output_paths$lpr_legacy_validation_path)
message("Build notes written to ", output_paths$issues_note_path)
