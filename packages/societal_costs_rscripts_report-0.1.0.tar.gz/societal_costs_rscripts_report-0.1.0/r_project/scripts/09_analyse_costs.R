project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "output_paths.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "followup_cost_panel.R"))
source(file.path(project_root, "R", "cost_analysis.R"))

args   <- parse_cli_args()
config <- default_project_config(project_root = project_root, args = args)

n_bootstrap        <- as.integer(args$n_bootstrap        %||% 1000L)
n_cores            <- as.integer(args$n_cores            %||% 1L)
max_followup_years <- as.integer(args$max_followup_years %||% 10L)
skip_subgroups     <- isTRUE(as.logical(args$skip_subgroups    %||% FALSE))
skip_discounts     <- isTRUE(as.logical(args$skip_discounts    %||% FALSE))
skip_survivors     <- isTRUE(as.logical(args$skip_survivors    %||% FALSE))
skip_proxies       <- isTRUE(as.logical(args$skip_proxies      %||% FALSE))

panel_path            <- resolve_existing_output_file(config, "followup_cost_panel")
compact_panel_path    <- resolve_existing_output_file(config, "followup_cost_panel_compact")
segments_path         <- resolve_existing_output_file(config, "followup_segments")
discounted_panel_path <- resolve_existing_output_file(config, "followup_cost_panel_discounted")
discounted_compact_panel_path <- resolve_existing_output_file(config, "followup_cost_panel_discounted_compact")
survivor_panel_path   <- resolve_existing_output_file(config, "followup_cost_panel_survivors")
matched_cohort_path   <- resolve_existing_output_file(config, "matched_cohort")

use_compact_panel <- file.exists(compact_panel_path) && file.exists(segments_path)
if (!use_compact_panel && !file.exists(panel_path)) {
  stop(sprintf(
    "Follow-up cost panel not found at %s or %s. Run scripts/08_build_followup_cost_panel.R first.",
    compact_panel_path,
    panel_path
  ))
}
if (!file.exists(matched_cohort_path)) {
  stop(sprintf(
    "Matched cohort not found at %s. Run scripts/03_run_matching.R first.",
    matched_cohort_path
  ))
}

panel_df <- if (use_compact_panel) {
  message("Using compact follow-up cost panel for analysis.")
  arrow::read_parquet(compact_panel_path)
} else {
  arrow::read_parquet(panel_path)
}
segment_df <- if (use_compact_panel) arrow::read_parquet(segments_path) else NULL
matched_df <- arrow::read_parquet(matched_cohort_path)

discounted_df <- if (!skip_discounts && use_compact_panel && file.exists(discounted_compact_panel_path)) {
  arrow::read_parquet(discounted_compact_panel_path)
} else if (!skip_discounts && file.exists(discounted_panel_path)) {
  arrow::read_parquet(discounted_panel_path)
} else {
  if (!skip_discounts) message("Warning: discounted panel not found, skipping discount scenarios.")
  data.frame()
}

message(sprintf(
  "Panel: %d rows | %d persons | components: %s",
  nrow(panel_df),
  length(unique(panel_df$person_id)),
  paste(sort(unique(panel_df$component)), collapse = ", ")
))
message(sprintf(
  "Bootstrap replicates: %d | cores: %d | max follow-up years: %d",
  n_bootstrap, n_cores, max_followup_years
))

# Primary analysis (undiscounted, full population, cumulative + annual)
message("=== Primary analysis ===")
results_primary <- run_cost_analysis(
  panel_df           = panel_df,
  matched_df         = matched_df,
  max_followup_years = max_followup_years,
  n_bootstrap        = n_bootstrap,
  n_cores            = n_cores,
  segment_df         = segment_df
)

# Discount scenarios (3% and 5%, cumulative only)
results_discount <- if (!skip_discounts && nrow(discounted_df)) {
  message("=== Discount scenarios ===")
  run_discount_scenarios(
    discounted_panel_df = discounted_df,
    matched_df          = matched_df,
    discount_rates      = c(0.03, 0.05),
    max_followup_years  = max_followup_years,
    n_bootstrap         = n_bootstrap,
    n_cores             = n_cores,
    segment_df          = segment_df
  )
} else {
  data.frame()
}

# Subgroup analyses (cumulative only: diagnosis_group, sex, SES, age band)
results_subgroup <- if (!skip_subgroups) {
  message("=== Subgroup analyses ===")
  run_subgroup_analyses(
    panel_df           = panel_df,
    matched_df         = matched_df,
    max_followup_years = max_followup_years,
    n_bootstrap        = n_bootstrap,
    n_cores            = n_cores,
    segment_df         = segment_df
  )
} else {
  data.frame()
}

results_df <- dplyr::bind_rows(results_primary, results_discount, results_subgroup)

output_paths <- write_cost_analysis_outputs(results_df, config)
print_analysis_diagnostic_summary(results_df, output_paths$model_diagnostics)

n_primary  <- sum(is.na(results_df$discount_rate) & is.na(results_df$subgroup_col))
n_discount <- sum(!is.na(results_df$discount_rate))
n_subgroup <- sum(is.na(results_df$discount_rate) & !is.na(results_df$subgroup_col))

message(sprintf(
  "Done: %d rows total (%d primary, %d discount scenarios, %d subgroup) written to %s",
  nrow(results_df), n_primary, n_discount, n_subgroup,
  output_paths$all_results
))

# Survivor-only secondary analysis
if (!skip_survivors) {
  message("=== Survivor-only secondary analysis ===")
  survivor_df <- if (file.exists(survivor_panel_path)) {
    arrow::read_parquet(survivor_panel_path)
  } else if (isTRUE(use_compact_panel)) {
    message("Survivor panel not found; compact primary panel cannot be used as a full survivor panel.")
    data.frame()
  } else {
    message("Survivor panel not found; building from primary panel on the fly.")
    filter_survivor_only_panel(panel_df, matched_df)
  }

  if (nrow(survivor_df)) {
    message(sprintf(
      "Survivor panel: %d rows | %d persons (vs %d primary)",
      nrow(survivor_df), length(unique(survivor_df$person_id)),
      length(unique(panel_df$person_id))
    ))
    results_survivors <- run_cost_analysis(
      panel_df           = survivor_df,
      matched_df         = matched_df,
      max_followup_years = max_followup_years,
      n_bootstrap        = n_bootstrap,
      n_cores            = n_cores
    )
    survivor_out <- output_file(config, "cost_analysis_results_survivors")
    survivor_diagnostics_out <- output_file(config, "model_diagnostics_survivors")
    ensure_output_parent(survivor_out)
    write_csv_file(results_survivors, survivor_out)
    write_analysis_diagnostics_output(results_survivors, survivor_diagnostics_out)
    print_analysis_diagnostic_summary(results_survivors, survivor_diagnostics_out)
    message(sprintf("Survivor analysis written to %s (%d rows)", survivor_out, nrow(results_survivors)))
  } else {
    message("Survivor panel is empty — analysis skipped.")
  }
}

# Non-monetary utilization proxies (supplementary diagnostics)
if (!skip_proxies) {
  message("=== Utilization proxy analysis ===")
  proxy_summary <- run_utilization_proxy_analysis(panel_df, config)
  if (nrow(proxy_summary)) {
    proxy_out <- output_file(config, "utilization_proxy_summary")
    ensure_output_parent(proxy_out)
    write_csv_file(proxy_summary, proxy_out)
    message(sprintf(
      "Proxy analysis written to %s (%d rows, proxies: %s)",
      proxy_out, nrow(proxy_summary),
      paste(sort(unique(proxy_summary$proxy)), collapse = ", ")
    ))
  }
}
