project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "output_paths.R"))
source(file.path(project_root, "R", "logging.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "cohort_inputs.R"))
source(file.path(project_root, "R", "register_metrics.R"))
source(file.path(project_root, "R", "raw_parent_covariates.R"))
source(file.path(project_root, "R", "baseline_dataset.R"))
source(file.path(project_root, "R", "matching.R"))
source(file.path(project_root, "R", "table1_matched.R"))
source(file.path(project_root, "R", "direct_cost_artifacts.R"))
source(file.path(project_root, "R", "cost_panel.R"))
source(file.path(project_root, "R", "price_harmonization.R"))
source(file.path(project_root, "R", "followup_cost_panel.R"))
source(file.path(project_root, "R", "cost_analysis.R"))
source(file.path(project_root, "R", "supervisor_figures.R"))

detected_repo_root <- detect_repo_root(project_root)

# Edit this block before running.
#
# Recommended production refresh after education/cohabitation/ethnicity rule changes:
# - Leave the production paths as NULL on the remote Windows server. The config will use:
#   intermediate_root: E:/workdata/708245/CDEF/Personer/tkra0028/societal_costs/sc_output
#   raw_register_root: E:/workdata/708245/data/202603
#   raw_popc_dir: E:/workdata/708245/data/popc
#   raw_indberetningmedpris_path:
#     E:/workdata/708245/CDEF/Projekter/SAS_konvertering/binary_test/indberetningmedpris/indberetningmedpris.parquet
# - Keep `reuse_prepared_baseline_artifacts = TRUE`.
# - Keep `force_rebuild_prepared_baseline_artifacts = FALSE`, even for the first run after adding
#   the new UDDF cache schema. Setting it TRUE forces all prepared baseline caches, including
#   pre-index register scans, to rebuild and is only for changed raw inputs or bad caches.
# - Set `force_rebuild_parent_covariates = TRUE` to refresh derived parent covariates while
#   reusing the small parent POPC lookup caches. If the old parent UDDF cache lacks raw HFAUDD/
#   HF_KILDE columns, it will be rebuilt once automatically.
# - Run `refresh_matched_cohort`, not `matching`, unless the actual matching criteria changed.
#
# In local repo development, leaving paths as NULL will auto-resolve from `repo_root`.
# For other servers, set:
# - `intermediate_root` to the sc_output directory containing cohort/core/registers
# - `raw_register_root` to the flat cost-register parquet delivery directory
# - `raw_popc_dir` if AKM/IND/UDDF live outside `raw_register_root`
pipeline_settings <- list(
  repo_root = detected_repo_root,
  use_production_paths = NULL,
  intermediate_root = NULL,
  raw_register_root = NULL,
  test_out_root = NULL,
  cohort_dir = NULL,
  core_dir = NULL,
  registers_dir = NULL,
  raw_data_dir = NULL,
  raw_popc_dir = NULL,
  raw_lmdb_dir = NULL,
  raw_primary_dir = NULL,
  raw_drg_dir = NULL,
  raw_indberetningmedpris_path = NULL,
  output_dir = file.path(project_root, "output"),
  output_layout = "structured",
  reference_price_year = 2023L,
  use_hospital_drugs = FALSE,
  run_parental_education_diagnostics = FALSE,
  reuse_prepared_baseline_artifacts = TRUE,
  force_rebuild_prepared_baseline_artifacts = FALSE,
  force_rebuild_parent_covariates = TRUE,
  reuse_direct_cost_artifacts = TRUE,
  force_rebuild_direct_cost_artifacts = FALSE,
  skip_lpr_legacy_validation = TRUE,
  direct_cost_scope = "matched_analysis",
  direct_cost_n_cores = 4L,
  hospital_drugs_usage_path = NULL,
  n_bootstrap = 100L,
  n_cores = 4L,
  max_followup_years = 10L,
  skip_subgroups = TRUE,
  skip_discounts = TRUE,
  skip_survivors = TRUE,
  write_full_followup_panel = FALSE,
  skip_proxies = TRUE,
  skip_followup_sensitivities = TRUE,
  skip_followup_90d_sensitivity = TRUE,
  skip_followup_all_entry_years = TRUE
)

# Choose which stages to run.
# Available:
# inventory, prepare_baseline_cache, baseline, parental_education_diagnostics, matching_inputs,
# matching, refresh_matched_cohort, table1, direct_cost, cost_panel, harmonize, followup,
# supervisor_figures, supervisor_report, analyse
# `parental_education_diagnostics` is intentionally excluded by default because
# it can be very expensive on the full production cohort. Add it here and set
# `run_parental_education_diagnostics = TRUE` when you need the diagnostic table.
stages_to_run <- c(
  "inventory",
  "baseline",
  #"refresh_matched_cohort",
  "matching_inputs",
  "matching",
  "table1",
  "direct_cost",
  "cost_panel",
  "harmonize",
  "followup",
  "supervisor_figures",
  "supervisor_report",
  "analyse"
)

make_interactive_config <- function(project_root, settings) {
  default_project_config(project_root = project_root, args = settings)
}

run_stage <- function(label, fn, config = NULL) {
  if (is.null(config)) {
    current_config <- getOption("societal_costs_current_config", NULL)
    if (is.list(current_config) && length(current_config)) {
      config <- current_config[[1]]
    }
  }
  started <- Sys.time()
  message(sprintf("\n=== %s ===", label))
  if (!is.null(config)) {
    log_event(config, level = "INFO", stage = label, message = "Stage started.")
  }
  status <- "ok"
  result <- tryCatch(
    {
      if (!is.null(config)) {
        with_warning_logging(config, label, fn())
      } else {
        fn()
      }
    },
    error = function(e) {
      status <<- "error"
      if (!is.null(config)) {
        log_event(config, level = "ERROR", stage = label, message = conditionMessage(e))
      }
      stop(e)
    }
  )
  elapsed <- difftime(Sys.time(), started, units = "secs")
  message(sprintf("Completed %s in %.1f seconds", label, as.numeric(elapsed)))
  if (!is.null(config)) {
    log_event(config, level = "INFO", stage = label, message = sprintf("Stage completed in %.1f seconds.", as.numeric(elapsed)))
    summaries <- getOption("societal_costs_stage_summaries", list())
    summaries[[length(summaries) + 1L]] <- data.frame(
      stage = label,
      status = status,
      elapsed_seconds = as.numeric(elapsed),
      completed_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
      stringsAsFactors = FALSE
    )
    options(societal_costs_stage_summaries = summaries)
  }
  result
}

read_if_exists <- function(path) {
  if (!file.exists(path)) {
    return(NULL)
  }
  arrow::read_parquet(path)
}

read_output_if_exists <- function(config, artifact) {
  read_if_exists(resolve_existing_output_file(config, artifact))
}

run_societal_costs_pipeline_interactive <- function(settings = pipeline_settings, stages = stages_to_run) {
  config <- make_interactive_config(project_root, settings)
  ensure_output_dir(config)
  initialize_run_logging(config)
  options(societal_costs_stage_summaries = list())
  options(societal_costs_current_config = list(config))

  message("Using paths:")
  message(sprintf("  repo_root: %s", config$repo_root))
  message(sprintf("  use_production_paths: %s", config$use_production_paths))
  message(sprintf("  intermediate_root: %s", config$intermediate_root))
  message(sprintf("  raw_register_root: %s", config$raw_register_root))
  message(sprintf("  cohort_dir: %s", config$cohort_dir))
  message(sprintf("  core_dir: %s", config$core_dir))
  message(sprintf("  registers_dir: %s", config$registers_dir))
  message(sprintf("  raw_popc_dir: %s", config$raw_popc_dir))
  message(sprintf("  raw_lmdb_dir: %s", config$raw_lmdb_dir))
  message(sprintf("  raw_primary_dir: %s", config$raw_primary_dir))
  message(sprintf("  raw_drg_dir: %s", config$raw_drg_dir))
  message(sprintf("  raw_indberetningmedpris_path: %s", config$raw_indberetningmedpris_path))
  message(sprintf("  output_dir: %s", config$output_dir))
  message(sprintf("  output_layout: %s", config$output_layout))
  message(sprintf("  run_parental_education_diagnostics: %s", config$run_parental_education_diagnostics))
  message(sprintf("  reuse_prepared_baseline_artifacts: %s", config$reuse_prepared_baseline_artifacts))
  message(sprintf("  force_rebuild_prepared_baseline_artifacts: %s", config$force_rebuild_prepared_baseline_artifacts))
  message(sprintf("  force_rebuild_parent_covariates: %s", config$force_rebuild_parent_covariates))
  message(sprintf("  reuse_direct_cost_artifacts: %s", config$reuse_direct_cost_artifacts))
  message(sprintf("  force_rebuild_direct_cost_artifacts: %s", config$force_rebuild_direct_cost_artifacts))
  message(sprintf("  skip_lpr_legacy_validation: %s", config$skip_lpr_legacy_validation))
  message(sprintf("  direct_cost_scope: %s", config$direct_cost_scope))
  message(sprintf("  direct_cost_n_cores: %s", config$direct_cost_n_cores))
  message(sprintf("  skip_discounts: %s", config$skip_discounts))
  message(sprintf("  skip_survivors: %s", config$skip_survivors))
  message(sprintf("  write_full_followup_panel: %s", config$write_full_followup_panel))
  message(sprintf("  skip_followup_sensitivities: %s", config$skip_followup_sensitivities))
  message(sprintf("  skip_followup_90d_sensitivity: %s", config$skip_followup_90d_sensitivity))
  message(sprintf("  skip_followup_all_entry_years: %s", config$skip_followup_all_entry_years))
  message(sprintf("  pipeline_log: %s", output_file(config, "pipeline_log")))
  message(sprintf("  warnings_log: %s", output_file(config, "warnings_log")))

  valid_stages <- c(
    "inventory",
    "prepare_baseline_cache",
    "baseline",
    "parental_education_diagnostics",
    "matching_inputs",
    "matching",
    "refresh_matched_cohort",
    "table1",
    "direct_cost",
    "cost_panel",
    "harmonize",
    "followup",
    "supervisor_figures",
    "supervisor_report",
    "analyse"
  )
  unknown_stages <- setdiff(stages, valid_stages)
  if (length(unknown_stages)) {
    stop(sprintf("Unknown stages: %s", paste(unknown_stages, collapse = ", ")))
  }

  results <- list(config = config)

  if ("inventory" %in% stages) {
    results$inventory <- run_stage("inventory", function() {
      manifest <- inventory_input_artifacts(config)
      write_inventory_outputs(manifest, config)
      manifest
    })
  }

  if ("prepare_baseline_cache" %in% stages) {
    results$prepare_baseline_cache <- run_stage("prepare_baseline_cache", function() {
      prepare_baseline_cache(config)
    })
  }

  if ("baseline" %in% stages) {
    results$baseline <- run_stage("baseline", function() {
      baseline_df <- build_baseline_dataset(config)
      write_baseline_dataset(config, baseline_df)
      baseline_df
    })
  }

  if ("parental_education_diagnostics" %in% stages) {
    results$parental_education_diagnostics <- run_stage("parental_education_diagnostics", function() {
      if (!isTRUE(config$run_parental_education_diagnostics)) {
        message("Skipping parental_education_diagnostics because run_parental_education_diagnostics is FALSE.")
        message("Set it to TRUE in pipeline_settings, or run scripts/01b_parental_education_diagnostics.R directly, when this diagnostic is needed.")
        return(NULL)
      }
      baseline_df <- results$baseline %||% read_output_if_exists(config, "baseline_dataset")
      if (is.null(baseline_df)) {
        stop("Baseline dataset not found. Run the baseline stage first.")
      }
      diagnostics <- build_parental_education_diagnostics(baseline_df, config)
      write_parental_education_diagnostics(diagnostics, config)
      diagnostics
    })
  }

  if ("matching_inputs" %in% stages) {
    results$matching_inputs <- run_stage("matching_inputs", function() {
      baseline_df <- results$baseline %||% read_output_if_exists(config, "baseline_dataset")
      if (is.null(baseline_df)) {
        stop("Baseline dataset not found. Run the baseline stage first.")
      }
      write_matching_inputs(config, baseline_df)
    })
  }

  if ("matching" %in% stages) {
    results$matching <- run_stage("matching", function() {
      baseline_df <- results$baseline %||% read_output_if_exists(config, "baseline_dataset")
      if (is.null(baseline_df)) {
        stop("Baseline dataset not found. Run the baseline stage first.")
      }
      write_matching_outputs(
        baseline_df,
        config,
        match_ratios = default_match_ratios(),
        seed = 42L
      )
    })
  }

  if ("refresh_matched_cohort" %in% stages) {
    results$refresh_matched_cohort <- run_stage("refresh_matched_cohort", function() {
      baseline_df <- results$baseline %||% read_output_if_exists(config, "baseline_dataset")
      if (is.null(baseline_df)) {
        stop("Baseline dataset not found. Run the baseline stage first.")
      }
      write_refreshed_matched_cohort_output(baseline_df, config)
    })
  }

  if ("table1" %in% stages) {
    results$table1 <- run_stage("table1", function() {
      matched_df <- read_output_if_exists(config, "matched_cohort")
      if (is.null(matched_df)) {
        stop("Matched cohort not found. Run the matching stage first.")
      }
      write_matched_table1_outputs(matched_df, config = config)
    })
  }

  if ("direct_cost" %in% stages) {
    results$direct_cost <- run_stage("direct_cost", function() {
      artifacts <- build_direct_cost_artifacts(config)
      if (!isTRUE(artifacts$reused_existing)) {
        write_direct_cost_artifacts(artifacts, config)
      }
      artifacts
    })
  }

  if ("cost_panel" %in% stages) {
    results$cost_panel <- run_stage("cost_panel", function() {
      matched_df <- read_output_if_exists(config, "matched_cohort")
      if (is.null(matched_df)) {
        stop("Matched cohort not found. Run the matching stage first.")
      }
      direct_cost_df <- results$direct_cost$combined_cost
      component_year_availability_df <- results$direct_cost$component_year_availability
      cost_panel_artifacts <- build_cost_panel_artifacts(
        matched_df,
        config = config,
        direct_cost_df = direct_cost_df,
        component_year_availability = component_year_availability_df,
        followup_years = 5L
      )
      write_cost_panel_outputs(
        cost_panel_artifacts$cost_panel,
        config,
        cost_panel_artifacts$panel_summary,
        cost_panel_artifacts$data_availability_summary
      )
    })
  }

  if ("harmonize" %in% stages) {
    results$harmonize <- run_stage("harmonize", function() {
      direct_cost_df <- (results$direct_cost$combined_cost) %||%
        read_output_if_exists(config, "direct_cost_person_year")
      if (is.null(direct_cost_df)) {
        stop("Direct-cost parquet not found. Run the direct_cost stage first.")
      }
      harmonized_cost_df    <- harmonize_direct_cost_person_year(direct_cost_df, config)
      harmonized_summary_df <- build_harmonized_cost_summary(harmonized_cost_df)
      write_harmonized_cost_outputs(harmonized_cost_df, harmonized_summary_df, config)
      harmonized_cost_df
    })
  }

  if ("followup" %in% stages) {
    results$followup <- run_stage("followup", function() {
      matched_df_full <- timed_followup_step("read matched cohort for follow-up", {
        read_output_if_exists(config, "matched_cohort")
      })
      if (is.null(matched_df_full)) {
        stop("Matched cohort not found. Run the matching stage first.")
      }
      harmonized_cost_path <- resolve_existing_output_file(config, "direct_cost_person_year_harmonized")
      harmonized_cost_df <- results$harmonize
      if (is.null(harmonized_cost_df) && !file.exists(harmonized_cost_path)) {
        stop("Harmonized cost parquet not found. Run the harmonize stage first.")
      }

      max_fy <- settings$max_followup_years %||% 10L
      followup_options <- followup_build_options(config)
      write_full_followup_panel <- isTRUE(followup_options$include_full_panel) ||
        isTRUE(followup_options$include_survivors)

      # Compute index_year once to avoid repeated as.Date + format calls
      index_year_vec <- as.integer(format(as.Date(matched_df_full$index_date), "%Y"))
      matched_df_primary <- matched_df_full[
        !is.na(matched_df_full$index_date) &
          index_year_vec >= 2001L &
          index_year_vec <= 2014L,
        , drop = FALSE
      ]
      if (is.null(harmonized_cost_df)) {
        harmonized_cost_primary_df <- timed_followup_step("load harmonized costs for primary follow-up", {
          load_relevant_harmonized_costs(harmonized_cost_path, matched_df_primary, max_fy)
        })
        harmonized_cost_all_df <- if (isTRUE(followup_options$include_all_entry_years)) {
          timed_followup_step("load harmonized costs for all entry years", {
            load_relevant_harmonized_costs(harmonized_cost_path, matched_df_full, max_fy)
          })
        } else {
          data.frame()
        }
      } else {
        harmonized_cost_primary_df <- timed_followup_step("filter harmonized costs for primary follow-up", {
          filter_relevant_harmonized_costs(harmonized_cost_df, matched_df_primary, max_fy)
        })
        harmonized_cost_all_df <- if (isTRUE(followup_options$include_all_entry_years)) {
          timed_followup_step("filter harmonized costs for all entry years", {
            filter_relevant_harmonized_costs(harmonized_cost_df, matched_df_full, max_fy)
          })
        } else {
          data.frame()
        }
      }

      # Build primary segments once; reuse for both the standard and 90-day-exclusion variants.
      primary_segments <- timed_followup_step("build primary follow-up segments", {
        build_followup_segments_vectorized(matched_df_primary, max_fy)
      })

      followup_outputs <- build_followup_cost_panel_from_segments(
        primary_segments, harmonized_cost_primary_df,
        max_followup_years   = max_fy,
        exclude_first_n_days = 0L,
        include_sparse       = FALSE,
        include_discounted   = followup_options$include_discounted,
        include_full         = write_full_followup_panel,
        include_compact      = TRUE
      )
      annual_summary_df <- timed_followup_step("summarize annual follow-up costs", {
        build_followup_annual_summary(
          followup_outputs$compact_followup_cost_panel,
          segment_df = followup_outputs$followup_segments
        )
      })
      cumulative_summary_df <- timed_followup_step("summarize cumulative follow-up costs", {
        build_followup_cumulative_summary(
          followup_outputs$compact_followup_cost_panel,
          max_followup_years = max_fy,
          segment_df = followup_outputs$followup_segments
        )
      })
      discounted_cumulative_summary_df <- if (isTRUE(followup_options$include_discounted)) {
        timed_followup_step("summarize discounted cumulative follow-up costs", {
          build_followup_discounted_cumulative_summary(
            followup_outputs$discounted_compact_followup_cost_panel,
            max_followup_years = max_fy,
            segment_df = followup_outputs$followup_segments
          )
        })
      } else {
        data.frame()
      }
      annual_difference_df <- timed_followup_step("compute annual follow-up differences", {
        build_followup_difference_summary(
          annual_summary_df,
          value_column  = "annual_cost_ppy_reference_dkk",
          group_columns = c("component", "followup_year")
        )
      })
      cumulative_difference_df <- timed_followup_step("compute cumulative follow-up differences", {
        build_followup_difference_summary(
          cumulative_summary_df,
          value_column  = "mean_cumulative_cost_reference_dkk",
          group_columns = c("component")
        )
      })
      discounted_cumulative_difference_df <- if (isTRUE(followup_options$include_discounted)) {
        timed_followup_step("compute discounted cumulative follow-up differences", {
          build_followup_difference_summary(
            discounted_cumulative_summary_df,
            value_column  = "mean_cumulative_discounted_cost_reference_dkk",
            group_columns = c("component", "discount_rate")
          )
        })
      } else {
        data.frame()
      }

      write_followup_cost_outputs(
        followup_segments_df             = followup_outputs$followup_segments,
        compact_followup_cost_panel_df   = followup_outputs$compact_followup_cost_panel,
        followup_cost_panel_df            = followup_outputs$followup_cost_panel,
        discounted_compact_followup_cost_panel_df = followup_outputs$discounted_compact_followup_cost_panel,
        discounted_followup_cost_panel_df = followup_outputs$discounted_followup_cost_panel,
        annual_summary_df                 = annual_summary_df,
        cumulative_summary_df             = cumulative_summary_df,
        discounted_cumulative_summary_df  = discounted_cumulative_summary_df,
        annual_difference_df              = annual_difference_df,
        cumulative_difference_df          = cumulative_difference_df,
        discounted_cumulative_difference_df = discounted_cumulative_difference_df,
        config = config,
        write_full_panel = write_full_followup_panel
      )

      if (isTRUE(followup_options$include_survivors)) {
        survivor_panel <- timed_followup_step("build survivor-only follow-up panel", {
          filter_survivor_only_panel(
            followup_outputs$followup_cost_panel,
            matched_df_primary
          )
        })
        timed_followup_step("write survivor-only follow-up panel", {
          arrow::write_parquet(
            survivor_panel,
            output_file(config, "followup_cost_panel_survivors")
          )
        })
      } else {
        message("Skipping survivor-only follow-up panel.")
      }

      if (isTRUE(followup_options$include_90d_sensitivity)) {
        # Reuse pre-built primary segments; only the allocation differs for the 90d variant.
        followup_outputs_90d <- build_followup_cost_panel_from_segments(
          primary_segments, harmonized_cost_primary_df,
          max_followup_years   = max_fy,
          exclude_first_n_days = 90L,
          include_sparse       = FALSE,
          include_discounted   = followup_options$include_discounted,
          include_full         = write_full_followup_panel,
          include_compact      = TRUE
        )
        timed_followup_step("write 90-day sensitivity follow-up outputs", {
          arrow::write_parquet(
            followup_outputs_90d$compact_followup_cost_panel,
            output_file(config, "followup_cost_panel_compact_excl90d")
          )
          arrow::write_parquet(
            followup_outputs_90d$discounted_compact_followup_cost_panel,
            output_file(config, "followup_cost_panel_discounted_compact_excl90d")
          )
          if (isTRUE(write_full_followup_panel)) {
            arrow::write_parquet(
              followup_outputs_90d$followup_cost_panel,
              output_file(config, "followup_cost_panel_excl90d")
            )
            arrow::write_parquet(
              followup_outputs_90d$discounted_followup_cost_panel,
              output_file(config, "followup_cost_panel_discounted_excl90d")
            )
          }
          write_csv_file(
            build_followup_annual_summary(
              followup_outputs_90d$compact_followup_cost_panel,
              segment_df = followup_outputs_90d$followup_segments
            ),
            output_file(config, "followup_annual_cost_summary_excl90d")
          )
        })
      } else {
        message("Skipping 90-day follow-up sensitivity panel.")
      }

      if (isTRUE(followup_options$include_all_entry_years)) {
        # All-entry-years variant uses matched_df_full — different persons, built separately.
        followup_outputs_annual <- build_followup_cost_panel(
          matched_df_full, harmonized_cost_all_df,
          max_followup_years   = max_fy,
          exclude_first_n_days = 0L,
          include_sparse       = FALSE,
          include_discounted   = FALSE,
          include_full         = write_full_followup_panel,
          include_compact      = TRUE
        )
        if (isTRUE(write_full_followup_panel)) {
          timed_followup_step("write all-entry-years follow-up panel", {
            arrow::write_parquet(
              followup_outputs_annual$followup_cost_panel,
              output_file(config, "followup_cost_panel_all_entry_years")
            )
          })
        } else {
          message("Skipping full all-entry-years follow-up panel.")
        }
      } else {
        message("Skipping all-entry-years follow-up panel.")
      }

      followup_outputs
    })
  }

  if ("supervisor_figures" %in% stages) {
    results$supervisor_figures <- run_stage("supervisor_figures", function() {
      build_supervisor_figures(config)
    })
  }

  if ("supervisor_report" %in% stages) {
    results$supervisor_report <- run_stage("supervisor_report", function() {
      render_supervisor_report(config, rebuild_figures = !("supervisor_figures" %in% stages))
    })
  }

  if ("analyse" %in% stages) {
    results$analyse <- run_stage("analyse", function() {
      compact_panel_df <- read_output_if_exists(config, "followup_cost_panel_compact")
      segment_df <- read_output_if_exists(config, "followup_segments")
      use_compact_panel <- !is.null(compact_panel_df) && !is.null(segment_df)
      panel_df <- if (isTRUE(use_compact_panel)) {
        message("Using compact follow-up cost panel for analysis.")
        compact_panel_df
      } else {
        segment_df <- NULL
        read_output_if_exists(config, "followup_cost_panel")
      }
      matched_df <- read_output_if_exists(config, "matched_cohort")
      discounted_df <- if (isTRUE(config$skip_discounts)) {
        data.frame()
      } else if (isTRUE(use_compact_panel)) {
        read_output_if_exists(config, "followup_cost_panel_discounted_compact")
      } else {
        read_output_if_exists(config, "followup_cost_panel_discounted")
      }
      if (is.null(panel_df)) {
        stop("Follow-up cost panel not found. Run the followup stage first.")
      }
      if (is.null(matched_df)) {
        stop("Matched cohort not found. Run the matching stage first.")
      }

      message("=== Primary analysis ===")
      results_primary <- run_cost_analysis(
        panel_df = panel_df,
        matched_df = matched_df,
        max_followup_years = settings$max_followup_years %||% 10L,
        n_bootstrap = settings$n_bootstrap %||% 1000L,
        n_cores = settings$n_cores %||% 1L,
        segment_df = segment_df
      )

      results_discount <- if (!isTRUE(config$skip_discounts) && !is.null(discounted_df) && nrow(discounted_df)) {
        message("=== Discount scenarios ===")
        run_discount_scenarios(
          discounted_panel_df = discounted_df,
          matched_df = matched_df,
          discount_rates = c(0.03, 0.05),
          max_followup_years = settings$max_followup_years %||% 10L,
          n_bootstrap = settings$n_bootstrap %||% 1000L,
          n_cores = settings$n_cores %||% 1L,
          segment_df = segment_df
        )
      } else {
        data.frame()
      }

      results_subgroup <- if (!isTRUE(settings$skip_subgroups)) {
        message("=== Subgroup analyses ===")
        run_subgroup_analyses(
          panel_df = panel_df,
          matched_df = matched_df,
          max_followup_years = settings$max_followup_years %||% 10L,
          n_bootstrap = settings$n_bootstrap %||% 1000L,
          n_cores = settings$n_cores %||% 1L,
          segment_df = segment_df
        )
      } else {
        data.frame()
      }

      results_df <- dplyr::bind_rows(results_primary, results_discount, results_subgroup)
      output_paths <- write_cost_analysis_outputs(results_df, config)
      print_analysis_diagnostic_summary(results_df, output_paths$model_diagnostics)

      if (!isTRUE(settings$skip_survivors)) {
        message("=== Survivor-only secondary analysis ===")
        survivor_df <- read_output_if_exists(config, "followup_cost_panel_survivors")
        if (!is.null(survivor_df) && nrow(survivor_df)) {
          message(sprintf(
            "Survivor panel: %d rows | %d persons (vs %d primary)",
            nrow(survivor_df), length(unique(survivor_df$person_id)),
            length(unique(panel_df$person_id))
          ))
          results_survivors <- run_cost_analysis(
            panel_df = survivor_df,
            matched_df = matched_df,
            max_followup_years = settings$max_followup_years %||% 10L,
            n_bootstrap = settings$n_bootstrap %||% 1000L,
            n_cores = settings$n_cores %||% 1L
          )
          survivor_out <- output_file(config, "cost_analysis_results_survivors")
          survivor_diagnostics_out <- output_file(config, "model_diagnostics_survivors")
          ensure_output_parent(survivor_out)
          write_csv_file(
            results_survivors,
            survivor_out
          )
          write_analysis_diagnostics_output(results_survivors, survivor_diagnostics_out)
          print_analysis_diagnostic_summary(results_survivors, survivor_diagnostics_out)
          message(sprintf("Survivor analysis written to %s (%d rows)", survivor_out, nrow(results_survivors)))
        } else {
          message("Survivor panel is empty or missing; analysis skipped.")
        }
      }

      if (!isTRUE(settings$skip_proxies)) {
        message("=== Utilization proxy analysis ===")
        proxy_summary <- run_utilization_proxy_analysis(panel_df, config)
        if (nrow(proxy_summary)) {
          proxy_out <- output_file(config, "utilization_proxy_summary")
          ensure_output_parent(proxy_out)
          write_csv_file(proxy_summary, proxy_out)
          message(sprintf("Proxy analysis written to %s (%d rows)", proxy_out, nrow(proxy_summary)))
        }
      }

      results_df
    })
  }

  summaries <- getOption("societal_costs_stage_summaries", list())
  if (length(summaries)) {
    write_run_summary(config, dplyr::bind_rows(summaries))
    message(sprintf("Run summary written to %s", output_file(config, "run_summary")))
  }

  invisible(results)
}

pipeline_results <- run_societal_costs_pipeline_interactive()
