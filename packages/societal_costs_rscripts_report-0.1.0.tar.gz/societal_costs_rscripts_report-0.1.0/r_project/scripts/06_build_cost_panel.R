project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "output_paths.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "cost_panel.R"))

config <- default_project_config(project_root = project_root)
matched_cohort_path <- resolve_existing_output_file(config, "matched_cohort")
direct_cost_path <- resolve_existing_output_file(config, "direct_cost_person_year")
component_year_availability_path <- resolve_existing_output_file(config, "direct_cost_component_year_availability")

if (!file.exists(matched_cohort_path)) {
  stop(sprintf("Matched cohort not found at %s. Run scripts/03_run_matching.R first.", matched_cohort_path))
}
if (!file.exists(direct_cost_path)) {
  stop(sprintf("Direct-cost person-year parquet not found at %s. Run scripts/05_build_direct_cost_artifacts.R first.", direct_cost_path))
}

matched_df <- arrow::read_parquet(matched_cohort_path)

cost_panel_artifacts <- build_cost_panel_artifacts(
  matched_df,
  config = config,
  followup_years = 5L
)
cost_panel_df <- cost_panel_artifacts$cost_panel
output_paths <- write_cost_panel_outputs(
  cost_panel_df,
  config,
  cost_panel_artifacts$panel_summary,
  cost_panel_artifacts$data_availability_summary
)

message("Matched cost-panel rows: ", nrow(cost_panel_df))
message("Matched cost-panel parquet written to ", output_paths$cost_panel_path)
message("Matched cost-panel data availability summary written to ", output_paths$cost_panel_data_availability_summary_path)
