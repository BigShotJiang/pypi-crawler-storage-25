project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "output_paths.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "cohort_inputs.R"))
source(file.path(project_root, "R", "register_metrics.R"))
source(file.path(project_root, "R", "raw_parent_covariates.R"))
source(file.path(project_root, "R", "baseline_dataset.R"))

config <- default_project_config(project_root = project_root)
baseline_df <- build_baseline_dataset(config)
output_path <- write_baseline_dataset(config, baseline_df)

message("Baseline dataset rows: ", nrow(baseline_df))
message("Baseline dataset written to ", output_path)
