project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "output_paths.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "price_harmonization.R"))
source(file.path(project_root, "R", "followup_cost_panel.R"))

args <- parse_cli_args()
config <- default_project_config(project_root = project_root, args = args)
followup_options <- followup_build_options(config)
write_full_followup_panel <- isTRUE(followup_options$include_full_panel) ||
  isTRUE(followup_options$include_survivors)
matched_cohort_path <- resolve_existing_output_file(config, "matched_cohort")
harmonized_cost_path <- resolve_existing_output_file(config, "direct_cost_person_year_harmonized")

if (!file.exists(matched_cohort_path)) {
  stop(sprintf("Matched cohort not found at %s. Run scripts/03_run_matching.R first.", matched_cohort_path))
}
if (!file.exists(harmonized_cost_path)) {
  stop(sprintf("Harmonized direct-cost parquet not found at %s. Run scripts/07_build_harmonized_cost_artifacts.R first.", harmonized_cost_path))
}

matched_df_full <- timed_followup_step("read matched cohort for follow-up", {
  arrow::read_parquet(matched_cohort_path)
})

# For the primary 10-year cumulative endpoint the protocol restricts cohort
# entry to 2001-2014 so that complete 10-year follow-up is observable by 2024.
# For annual endpoints, all cohort entry years (through 2023) are used.
index_year_vec <- as.integer(format(as.Date(matched_df_full$index_date), "%Y"))
matched_df_primary <- matched_df_full[
  !is.na(matched_df_full$index_date) &
    index_year_vec >= 2001L &
    index_year_vec <= 2014L,
  ,
  drop = FALSE
]
harmonized_cost_primary_df <- timed_followup_step("load harmonized costs for primary follow-up", {
  load_relevant_harmonized_costs(harmonized_cost_path, matched_df_primary, max_followup_years = 10L)
})
harmonized_cost_all_df <- if (isTRUE(followup_options$include_all_entry_years)) {
  timed_followup_step("load harmonized costs for all entry years", {
    load_relevant_harmonized_costs(harmonized_cost_path, matched_df_full, max_followup_years = 10L)
  })
} else {
  data.frame()
}

message(sprintf(
  "Cohort: %d total, %d in 2001-2014 primary window",
  nrow(matched_df_full),
  nrow(matched_df_primary)
))

# Build primary segments once; primary and 90-day sensitivity panels differ only
# in allocation, not in their follow-up segment boundaries.
primary_segments <- timed_followup_step("build primary follow-up segments", {
  build_followup_segments_vectorized(matched_df_primary, max_followup_years = 10L)
})

# Primary panel: all post-index costs from day 0
followup_outputs <- build_followup_cost_panel_from_segments(
  primary_segments,
  harmonized_cost_primary_df,
  max_followup_years = 10L,
  exclude_first_n_days = 0L,
  include_sparse = FALSE,
  include_discounted = followup_options$include_discounted,
  include_full = write_full_followup_panel,
  include_compact = TRUE
)
annual_summary_df <- timed_followup_step("summarize annual follow-up costs", {
  build_followup_annual_summary(
    followup_outputs$compact_followup_cost_panel,
    segment_df = followup_outputs$followup_segments
  )
})
cumulative_summary_df <- timed_followup_step("summarize cumulative follow-up costs", {
  build_followup_cumulative_summary(
    followup_outputs$compact_followup_cost_panel,
    segment_df = followup_outputs$followup_segments
  )
})
discounted_cumulative_summary_df <- if (isTRUE(followup_options$include_discounted)) {
  timed_followup_step("summarize discounted cumulative follow-up costs", {
    build_followup_discounted_cumulative_summary(
      followup_outputs$discounted_compact_followup_cost_panel,
      segment_df = followup_outputs$followup_segments
    )
  })
} else {
  data.frame()
}
annual_difference_df <- timed_followup_step("compute annual follow-up differences", {
  build_followup_difference_summary(
    annual_summary_df,
    value_column = "annual_cost_ppy_reference_dkk",
    group_columns = c("component", "followup_year")
  )
})
cumulative_difference_df <- timed_followup_step("compute cumulative follow-up differences", {
  build_followup_difference_summary(
    cumulative_summary_df,
    value_column = "mean_cumulative_cost_reference_dkk",
    group_columns = c("component")
  )
})
discounted_cumulative_difference_df <- if (isTRUE(followup_options$include_discounted)) {
  timed_followup_step("compute discounted cumulative follow-up differences", {
    build_followup_difference_summary(
      discounted_cumulative_summary_df,
      value_column = "mean_cumulative_discounted_cost_reference_dkk",
      group_columns = c("component", "discount_rate")
    )
  })
} else {
  data.frame()
}
output_paths <- write_followup_cost_outputs(
  followup_segments_df = followup_outputs$followup_segments,
  compact_followup_cost_panel_df = followup_outputs$compact_followup_cost_panel,
  followup_cost_panel_df = followup_outputs$followup_cost_panel,
  discounted_compact_followup_cost_panel_df = followup_outputs$discounted_compact_followup_cost_panel,
  discounted_followup_cost_panel_df = followup_outputs$discounted_followup_cost_panel,
  annual_summary_df = annual_summary_df,
  cumulative_summary_df = cumulative_summary_df,
  discounted_cumulative_summary_df = discounted_cumulative_summary_df,
  annual_difference_df = annual_difference_df,
  cumulative_difference_df = cumulative_difference_df,
  discounted_cumulative_difference_df = discounted_cumulative_difference_df,
  config = config,
  write_full_panel = write_full_followup_panel
)
message("Compact follow-up cost-panel rows (primary): ", nrow(followup_outputs$compact_followup_cost_panel))
message("Compact follow-up cost-panel parquet written to ", output_paths$compact_followup_cost_panel_path)

# Survivor-only secondary panel: exclude person-years truncated by death
if (isTRUE(followup_options$include_survivors)) {
  survivor_panel <- timed_followup_step("build survivor-only follow-up panel", {
    filter_survivor_only_panel(
      followup_outputs$followup_cost_panel,
      matched_df_primary
    )
  })
  survivor_panel_path <- output_file(config, "followup_cost_panel_survivors")
  ensure_output_parent(survivor_panel_path)
  timed_followup_step("write survivor-only follow-up panel", {
    arrow::write_parquet(survivor_panel, survivor_panel_path)
  })
  message("Survivor-only panel rows: ", nrow(survivor_panel), " (", survivor_panel_path, ")")
} else {
  message("Skipping survivor-only follow-up panel.")
}

# Sensitivity panel: exclude first 90 days (diagnostic-workup costs)
if (isTRUE(followup_options$include_90d_sensitivity)) {
  followup_outputs_90d <- build_followup_cost_panel_from_segments(
    primary_segments,
    harmonized_cost_primary_df,
    max_followup_years = 10L,
    exclude_first_n_days = 90L,
    include_sparse = FALSE,
    include_discounted = followup_options$include_discounted,
    include_full = write_full_followup_panel,
    include_compact = TRUE
  )

  sensitivity_paths <- list(
    compact_panel_path = output_file(config, "followup_cost_panel_compact_excl90d"),
    discounted_compact_path = output_file(config, "followup_cost_panel_discounted_compact_excl90d"),
    panel_path = output_file(config, "followup_cost_panel_excl90d"),
    discounted_path = output_file(config, "followup_cost_panel_discounted_excl90d"),
    summary_path = output_file(config, "followup_annual_cost_summary_excl90d")
  )
  invisible(lapply(sensitivity_paths, ensure_output_parent))
  timed_followup_step("write 90-day sensitivity follow-up outputs", {
    arrow::write_parquet(followup_outputs_90d$compact_followup_cost_panel, sensitivity_paths$compact_panel_path)
    arrow::write_parquet(
      followup_outputs_90d$discounted_compact_followup_cost_panel,
      sensitivity_paths$discounted_compact_path
    )
    if (isTRUE(write_full_followup_panel)) {
      arrow::write_parquet(followup_outputs_90d$followup_cost_panel, sensitivity_paths$panel_path)
      arrow::write_parquet(followup_outputs_90d$discounted_followup_cost_panel, sensitivity_paths$discounted_path)
    }
    write_csv_file(
      build_followup_annual_summary(
        followup_outputs_90d$compact_followup_cost_panel,
        segment_df = followup_outputs_90d$followup_segments
      ),
      sensitivity_paths$summary_path
    )
  })
  message("Compact follow-up cost-panel rows (90-day exclusion sensitivity): ", nrow(followup_outputs_90d$compact_followup_cost_panel))
  message("Sensitivity panel written to ", sensitivity_paths$compact_panel_path)
} else {
  message("Skipping 90-day follow-up sensitivity panel.")
}

if (isTRUE(followup_options$include_all_entry_years)) {
  # Annual panel: full cohort (all entry years) for annual cost trajectories
  followup_outputs_annual <- build_followup_cost_panel(
    matched_df_full,
    harmonized_cost_all_df,
    max_followup_years = 10L,
    exclude_first_n_days = 0L,
    include_sparse = FALSE,
    include_discounted = FALSE,
    include_full = write_full_followup_panel,
    include_compact = TRUE
  )
  if (isTRUE(write_full_followup_panel)) {
    timed_followup_step("write all-entry-years follow-up panel", {
      arrow::write_parquet(
        followup_outputs_annual$followup_cost_panel,
        output_file(config, "followup_cost_panel_all_entry_years")
      )
    })
  } else {
    message("Skipping full all-entry-years follow-up panel.")
  }
  message("Compact follow-up cost-panel rows (all entry years, annual): ", nrow(followup_outputs_annual$compact_followup_cost_panel))
} else {
  message("Skipping all-entry-years follow-up panel.")
}
