suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
  library(splines)
  library(fastglm)
})

# ── Helpers ───────────────────────────────────────────────────────────────────

derive_age_band <- function(age_months) {
  cut(
    age_months / 12,
    breaks = c(0, 5, 10, 15, 18, Inf),
    labels = c("0-4yr", "5-9yr", "10-14yr", "15-17yr", "18+yr"),
    right = FALSE, include.lowest = TRUE
  )
}

as_optional_followup_year <- function(value) {
  if (is.null(value) || !length(value)) {
    return(NA_integer_)
  }
  as.integer(value[[1]])
}

count_true <- function(x) {
  sum(isTRUE(x) | (!is.na(x) & x), na.rm = TRUE)
}

model_preflight_diagnostics <- function(
  df,
  cost_col,
  component_name,
  followup_year_target = NULL,
  model_type = "two_part",
  min_observations = 20L,
  min_positive_total = 20L,
  min_positive_per_arm = 10L
) {
  n_exposed <- sum(df$exposed %in% TRUE, na.rm = TRUE)
  n_unexposed <- sum(df$exposed %in% FALSE, na.rm = TRUE)
  positive <- !is.na(df[[cost_col]]) & df[[cost_col]] > 0
  positive_exposed <- sum(positive & df$exposed %in% TRUE, na.rm = TRUE)
  positive_unexposed <- sum(positive & df$exposed %in% FALSE, na.rm = TRUE)
  positive_total <- positive_exposed + positive_unexposed
  zero_share <- if (nrow(df)) mean(df[[cost_col]] == 0, na.rm = TRUE) else NA_real_
  observed_max_cost <- if (nrow(df) && !all(is.na(df[[cost_col]]))) {
    max(df[[cost_col]], na.rm = TRUE)
  } else {
    NA_real_
  }

  status <- "ok"
  note <- "Model preflight checks passed."
  if (nrow(df) < min_observations) {
    status <- "insufficient_observations"
    note <- sprintf("Fewer than %d observations after filtering; model was not fit.", min_observations)
  } else if (model_type %in% c("gamma", "two_part") && positive_total < min_positive_total) {
    status <- "insufficient_positive_costs"
    note <- sprintf(
      "Fewer than %d positive-cost observations after filtering; model was not fit.",
      min_positive_total
    )
  } else if (model_type == "two_part" &&
             (positive_exposed < min_positive_per_arm || positive_unexposed < min_positive_per_arm)) {
    status <- "insufficient_positive_costs"
    note <- sprintf(
      "Too few positive-cost observations in at least one exposure arm: exposed=%d, unexposed=%d.",
      positive_exposed,
      positive_unexposed
    )
  }

  data.frame(
    component = component_name,
    followup_year = as_optional_followup_year(followup_year_target),
    model_type = model_type,
    n_observations = nrow(df),
    n_exposed = n_exposed,
    n_unexposed = n_unexposed,
    positive_exposed = positive_exposed,
    positive_unexposed = positive_unexposed,
    zero_share = zero_share,
    observed_max_cost = observed_max_cost,
    n_parameters = NA_integer_,
    model_status = status,
    failure_message = NA_character_,
    actionable_note = note,
    stringsAsFactors = FALSE
  )
}

classify_prediction_stability <- function(
  mean_exposed,
  mean_unexposed,
  mean_difference,
  observed_max_cost,
  prediction_scale_multiplier = 100
) {
  values <- c(mean_exposed, mean_unexposed, mean_difference)
  if (!all(is.finite(values))) {
    return(list(
      model_status = "unstable_fit",
      actionable_note = "Model produced non-finite standardized predictions; inspect sparsity and model specification."
    ))
  }

  if (is.finite(observed_max_cost) && observed_max_cost > 0) {
    prediction_limit <- observed_max_cost * prediction_scale_multiplier
    if (any(abs(c(mean_exposed, mean_unexposed)) > prediction_limit)) {
      return(list(
        model_status = "unstable_fit",
        actionable_note = sprintf(
          "Standardized predictions are far outside observed cost scale; max observed cost is %.1f.",
          observed_max_cost
        )
      ))
    }
  }

  list(model_status = "ok", actionable_note = "Model fit and standardized predictions passed diagnostics.")
}

model_result_converged <- function(fit_result, model_type) {
  if (model_type == "gamma") {
    return(is.null(fit_result$converged) || isTRUE(fit_result$converged))
  }
  bin_ok <- is.null(fit_result$model_bin$converged) || isTRUE(fit_result$model_bin$converged)
  pos_ok <- is.null(fit_result$model_pos$converged) || isTRUE(fit_result$model_pos$converged)
  bin_ok && pos_ok
}

formula_parameter_count <- function(formula, df) {
  count <- tryCatch(
    ncol(stats::model.matrix(formula, data = df)),
    error = function(e) NA_integer_
  )
  as.integer(count)
}

analysis_status_counts <- function(results_df) {
  if (!"model_status" %in% names(results_df) || !nrow(results_df)) {
    return(data.frame(model_status = character(0), n = integer(0), stringsAsFactors = FALSE))
  }
  counts <- as.data.frame(table(results_df$model_status), stringsAsFactors = FALSE)
  names(counts) <- c("model_status", "n")
  counts <- counts[counts$n > 0L, , drop = FALSE]
  counts$model_status <- as.character(counts$model_status)
  counts$n <- as.integer(counts$n)
  counts[order(counts$model_status), , drop = FALSE]
}

analysis_diagnostics_frame <- function(results_df) {
  diagnostic_cols <- intersect(
    c(
      "component", "followup_year", "model_type", "discount_rate", "subgroup_col", "subgroup_val",
      "n_observations", "n_exposed", "n_unexposed", "positive_exposed", "positive_unexposed",
      "zero_share", "observed_max_cost", "n_parameters", "model_status", "failure_message",
      "actionable_note", "n_bootstrap_valid", "note"
    ),
    names(results_df)
  )
  results_df[, diagnostic_cols, drop = FALSE]
}

write_analysis_diagnostics_output <- function(results_df, path) {
  diagnostics_df <- analysis_diagnostics_frame(results_df)
  if (exists("write_csv_file", mode = "function")) {
    write_csv_file(diagnostics_df, path)
  } else {
    dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
    utils::write.csv(diagnostics_df, path, row.names = FALSE)
  }
  invisible(path)
}

print_analysis_diagnostic_summary <- function(results_df, diagnostics_path = NULL) {
  counts <- analysis_status_counts(results_df)
  if (!nrow(counts)) {
    message("Analysis model diagnostics: no model status rows recorded.")
    return(invisible(counts))
  }

  message("Analysis model diagnostics:")
  for (i in seq_len(nrow(counts))) {
    message(sprintf("  %s: %d", counts$model_status[[i]], counts$n[[i]]))
  }
  if (!is.null(diagnostics_path) && nzchar(diagnostics_path)) {
    message(sprintf("  details: %s", diagnostics_path))
  }
  invisible(counts)
}

analysis_result_row <- function(
  component_name,
  followup_year_target,
  model_type,
  discount_rate,
  subgroup_col,
  subgroup_val,
  diagnostics,
  mean_exposed = NA_real_,
  mean_unexposed = NA_real_,
  mean_difference = NA_real_,
  ci_lower = NA_real_,
  ci_upper = NA_real_,
  n_bootstrap_valid = 0L,
  note = NA_character_
) {
  data.frame(
    component         = component_name,
    followup_year     = as_optional_followup_year(followup_year_target),
    model_type        = model_type,
    discount_rate     = discount_rate,
    subgroup_col      = if (is.null(subgroup_col)) NA_character_ else subgroup_col,
    subgroup_val      = if (is.null(subgroup_val)) NA_character_ else as.character(subgroup_val),
    n_observations    = diagnostics$n_observations,
    mean_exposed      = mean_exposed,
    mean_unexposed    = mean_unexposed,
    mean_difference   = mean_difference,
    ci_lower          = ci_lower,
    ci_upper          = ci_upper,
    n_bootstrap_valid = n_bootstrap_valid,
    note              = note,
    n_exposed         = diagnostics$n_exposed,
    n_unexposed       = diagnostics$n_unexposed,
    positive_exposed  = diagnostics$positive_exposed,
    positive_unexposed = diagnostics$positive_unexposed,
    zero_share        = diagnostics$zero_share,
    observed_max_cost = diagnostics$observed_max_cost,
    n_parameters      = diagnostics$n_parameters,
    model_status      = diagnostics$model_status,
    failure_message   = diagnostics$failure_message,
    actionable_note   = diagnostics$actionable_note,
    stringsAsFactors  = FALSE
  )
}

format_analysis_number <- function(value) {
  if (is.null(value) || !length(value) || !is.finite(as.numeric(value[[1]]))) {
    return("NA")
  }
  formatC(as.numeric(value[[1]]), format = "f", digits = 1, big.mark = ",")
}

format_analysis_count <- function(value) {
  if (is.null(value) || !length(value) || is.na(value[[1]])) {
    return("NA")
  }
  trimws(format(as.integer(value[[1]]), big.mark = ",", scientific = FALSE))
}

analysis_slice_label <- function(component_name, label, subgroup_col = NULL, subgroup_val = NULL) {
  subgroup_label <- if (!is.null(subgroup_col)) {
    sprintf(" [%s=%s]", subgroup_col, subgroup_val)
  } else {
    ""
  }
  sprintf("%s / %s%s", component_name, label, subgroup_label)
}

format_bootstrap_start_message <- function(slice_label, mean_difference, n_bootstrap) {
  sprintf(
    "  %s: estimated mean diff = %s; bootstrap reps = %s",
    slice_label,
    format_analysis_number(mean_difference),
    format_analysis_count(n_bootstrap)
  )
}

format_bootstrap_result_message <- function(
  slice_label,
  mean_difference,
  ci_lower,
  ci_upper,
  n_valid_replicates,
  n_bootstrap
) {
  sprintf(
    "  %s: estimated mean diff = %s; 95%% CI = [%s, %s]; valid bootstrap reps = %s/%s",
    slice_label,
    format_analysis_number(mean_difference),
    format_analysis_number(ci_lower),
    format_analysis_number(ci_upper),
    format_analysis_count(n_valid_replicates),
    format_analysis_count(n_bootstrap)
  )
}

# ── Covariate preparation ─────────────────────────────────────────────────────

COVARIATE_COLS <- c(
  "person_id",
  "sex", "birth_date", "region",
  "parent_education_group", "parent_socio_group", "cohabitation_group",
  "gest_age_cat", "birth_weight_cat", "parity_cat", "multiple_birth",
  "maternal_age_birth_group", "apgar_cat",
  "truncated_lookback_flag",
  "preindex_util_total_rate", "preindex_hosp_days_rate",
  "censor_reason"
)

join_analysis_covariates <- function(panel_df, matched_df) {
  available <- intersect(COVARIATE_COLS, names(matched_df))
  panel_df |>
    left_join(matched_df[, available, drop = FALSE], by = "person_id") |>
    mutate(
      age_at_index_months = as.numeric(
        as.Date(index_date) - as.Date(birth_date)
      ) / 30.4375,
      index_year_f = factor(index_year),
      match_weight = dplyr::coalesce(match_weight, 1)
    )
}

# ── Formula construction ──────────────────────────────────────────────────────

build_cost_formula <- function(df, cost_col) {
  terms <- character(0)

  if ("age_at_index_months" %in% names(df) &&
      sum(is.finite(df$age_at_index_months), na.rm = TRUE) > 10L &&
      length(unique(df$age_at_index_months[is.finite(df$age_at_index_months)])) >= 5L) {
    terms <- c(terms, "ns(age_at_index_months, df = 3)")
  }
  if ("index_year_f" %in% names(df)) {
    terms <- c(terms, "index_year_f")
  }

  categorical_vars <- c(
    "sex", "region",
    "parent_education_group", "parent_socio_group", "cohabitation_group",
    "gest_age_cat", "birth_weight_cat", "parity_cat", "multiple_birth",
    "maternal_age_birth_group", "apgar_cat",
    "truncated_lookback_flag"
  )
  for (v in categorical_vars) {
    if (v %in% names(df) &&
        sum(!is.na(df[[v]])) > 0L &&
        length(unique(stats::na.omit(as.character(df[[v]])))) > 1L) {
      terms <- c(terms, v)
    }
  }

  rhs <- paste(c("exposed", terms), collapse = " + ")
  as.formula(paste(cost_col, "~", rhs))
}

# ── Gamma GLM (one-part) ──────────────────────────────────────────────────────

fit_gamma_glm <- function(df, formula, cost_col, cost_floor = 1, verbose = TRUE) {
  df$cost_adj__ <- pmax(df[[cost_col]], cost_floor)
  f <- update(formula, cost_adj__ ~ .)
  tryCatch(
    glm(f, data = df, family = Gamma(link = "log"), weights = match_weight),
    error = function(e) {
      if (isTRUE(verbose)) {
        message("  Gamma GLM failed: ", conditionMessage(e))
      }
      NULL
    }
  )
}

# ── Two-part model (hurdle) ───────────────────────────────────────────────────

fit_two_part_model <- function(df, formula, cost_col, cost_floor = 1, verbose = TRUE) {
  df$any_cost__ <- df[[cost_col]] > 0
  df$cost_adj__ <- ifelse(df$any_cost__, pmax(df[[cost_col]], cost_floor), NA_real_)

  f_bin <- update(formula, any_cost__ ~ .)

  model_bin <- tryCatch(
    glm(f_bin, data = df, family = binomial(link = "logit"), weights = match_weight),
    error = function(e) {
      if (isTRUE(verbose)) {
        message("  Two-part binary model failed: ", conditionMessage(e))
      }
      NULL
    }
  )

  df_pos <- df[!is.na(df$cost_adj__), , drop = FALSE]
  model_pos <- if (nrow(df_pos) >= 20L) {
    f_pos <- build_cost_formula(df_pos, "cost_adj__")
    tryCatch(
      glm(f_pos, data = df_pos, family = Gamma(link = "log"), weights = match_weight),
      error = function(e) {
        if (isTRUE(verbose)) {
          message("  Two-part positive-cost model failed: ", conditionMessage(e))
        }
        NULL
      }
    )
  } else {
    NULL
  }

  list(model_bin = model_bin, model_pos = model_pos)
}

# ── Marginal standardization ──────────────────────────────────────────────────

align_newdata_to_model <- function(model, newdata) {
  if (is.null(model$xlevels) || !length(model$xlevels)) {
    return(newdata)
  }
  for (nm in names(model$xlevels)) {
    if (nm %in% names(newdata)) {
      newdata[[nm]] <- factor(as.character(newdata[[nm]]), levels = model$xlevels[[nm]])
    }
  }
  newdata
}

marginal_standardize <- function(model, df) {
  if (is.null(model)) {
    return(list(mean_exposed = NA_real_, mean_unexposed = NA_real_, mean_difference = NA_real_))
  }
  df_exp   <- align_newdata_to_model(model, df); df_exp$exposed   <- TRUE
  df_unexp <- align_newdata_to_model(model, df); df_unexp$exposed <- FALSE
  p_exp   <- predict(model, newdata = df_exp,   type = "response")
  p_unexp <- predict(model, newdata = df_unexp, type = "response")
  list(
    mean_exposed    = mean(p_exp,             na.rm = TRUE),
    mean_unexposed  = mean(p_unexp,           na.rm = TRUE),
    mean_difference = mean(p_exp - p_unexp,   na.rm = TRUE)
  )
}

marginal_standardize_two_part <- function(models, df) {
  if (is.null(models$model_bin) || is.null(models$model_pos)) {
    return(list(mean_exposed = NA_real_, mean_unexposed = NA_real_, mean_difference = NA_real_))
  }
  df_exp   <- df; df_exp$exposed   <- TRUE
  df_unexp <- df; df_unexp$exposed <- FALSE
  prob_exp   <- predict(models$model_bin, newdata = align_newdata_to_model(models$model_bin, df_exp),   type = "response")
  prob_unexp <- predict(models$model_bin, newdata = align_newdata_to_model(models$model_bin, df_unexp), type = "response")
  mu_exp     <- predict(models$model_pos, newdata = align_newdata_to_model(models$model_pos, df_exp),   type = "response")
  mu_unexp   <- predict(models$model_pos, newdata = align_newdata_to_model(models$model_pos, df_unexp), type = "response")
  pred_exp   <- prob_exp   * mu_exp
  pred_unexp <- prob_unexp * mu_unexp
  list(
    mean_exposed    = mean(pred_exp,              na.rm = TRUE),
    mean_unexposed  = mean(pred_unexp,            na.rm = TRUE),
    mean_difference = mean(pred_exp - pred_unexp, na.rm = TRUE)
  )
}

# ── Family-clustered bootstrap ────────────────────────────────────────────────

run_one_replicate_fast <- function(
  seed, model_type, cluster_ids, cluster_lookup,
  X_mat, y_vec, w_vec, X_exp, X_unexp, cost_floor = 1
) {
  set.seed(seed)
  sampled_clusters <- sample(cluster_ids, length(cluster_ids), replace = TRUE)
  idx <- unlist(cluster_lookup[sampled_clusters], use.names = FALSE)

  if (!length(idx)) return(NA_real_)

  # Prediction helper that gracefully handles rank deficiency (NA coefficients)
  # by dropping redundant columns from X, matching predict.glm behavior.
  safe_predict_fast <- function(X_mat, coefs) {
    valid <- !is.na(coefs)
    if (!any(valid)) return(rep(NA_real_, nrow(X_mat)))
    as.vector(X_mat[, valid, drop = FALSE] %*% coefs[valid])
  }

  tryCatch({
    if (model_type == "gamma") {
      y_adj <- pmax(y_vec[idx], cost_floor)
      # fastglm() handles rank deficiency by setting redundant coefs to NA
      fit <- fastglm::fastglm(
        x = X_mat[idx, , drop = FALSE],
        y = y_adj,
        weights = w_vec[idx],
        family = stats::Gamma(link = "log")
      )
      coefs  <- fit$coefficients
      p_exp   <- exp(safe_predict_fast(X_exp[idx, , drop = FALSE], coefs))
      p_unexp <- exp(safe_predict_fast(X_unexp[idx, , drop = FALSE], coefs))
      mean(p_exp - p_unexp, na.rm = TRUE)
    } else {
      y_bin   <- as.numeric(y_vec[idx] > 0)
      fit_bin <- fastglm::fastglm(
        x = X_mat[idx, , drop = FALSE],
        y = y_bin,
        weights = w_vec[idx],
        family = stats::binomial(link = "logit")
      )
      coef_bin <- fit_bin$coefficients

      pos_mask <- y_bin > 0
      pos_idx  <- idx[pos_mask]

      if (length(pos_idx) >= 20L) {
        y_adj <- pmax(y_vec[pos_idx], cost_floor)
        fit_pos <- fastglm::fastglm(
          x = X_mat[pos_idx, , drop = FALSE],
          y = y_adj,
          weights = w_vec[pos_idx],
          family = stats::Gamma(link = "log")
        )
        coef_pos <- fit_pos$coefficients

        prob_exp   <- stats::plogis(safe_predict_fast(X_exp[idx, , drop = FALSE],   coef_bin))
        prob_unexp <- stats::plogis(safe_predict_fast(X_unexp[idx, , drop = FALSE], coef_bin))
        mu_exp     <- exp(safe_predict_fast(X_exp[idx, , drop = FALSE],   coef_pos))
        mu_unexp   <- exp(safe_predict_fast(X_unexp[idx, , drop = FALSE], coef_pos))

        pred_exp   <- prob_exp   * mu_exp
        pred_unexp <- prob_unexp * mu_unexp
        mean(pred_exp - pred_unexp, na.rm = TRUE)
      } else {
        NA_real_
      }
    }
  }, error = function(e) NA_real_)
}

resolve_bootstrap_parallel_backend <- function(n_cores, os_type = .Platform$OS.type, backend = "auto") {
  if (is.null(backend) || !length(backend) || is.na(backend[[1]]) || !nzchar(as.character(backend[[1]]))) {
    backend <- "auto"
  }
  backend <- tolower(as.character(backend[[1]]))
  valid_backends <- c("auto", "sequential", "fork", "psock")
  if (!backend %in% valid_backends) {
    stop(sprintf(
      "Unknown bootstrap parallel backend '%s'. Use one of: %s.",
      backend,
      paste(valid_backends, collapse = ", ")
    ), call. = FALSE)
  }

  if (is.na(n_cores) || as.integer(n_cores) <= 1L) {
    return("sequential")
  }
  if (!identical(backend, "auto")) {
    return(backend)
  }

  if (identical(tolower(as.character(os_type)), "windows")) {
    "psock"
  } else {
    "fork"
  }
}

run_bootstrap_replicates <- function(
  seeds, model_type, cluster_ids, cluster_lookup,
  X_mat, y_vec, w_vec, X_exp_mat, X_unexp_mat,
  n_cores = 1L, parallel_backend = "auto"
) {
  backend <- resolve_bootstrap_parallel_backend(n_cores, backend = parallel_backend)
  n_cores <- as.integer(n_cores)

  if (identical(backend, "sequential") || !requireNamespace("parallel", quietly = TRUE)) {
    return(vapply(
      X = seeds,
      FUN = run_one_replicate_fast,
      FUN.VALUE = numeric(1),
      model_type = model_type,
      cluster_ids = cluster_ids,
      cluster_lookup = cluster_lookup,
      X_mat = X_mat, y_vec = y_vec, w_vec = w_vec,
      X_exp = X_exp_mat, X_unexp = X_unexp_mat
    ))
  }

  if (identical(backend, "fork")) {
    return(unlist(parallel::mclapply(
      X = seeds,
      FUN = run_one_replicate_fast,
      model_type = model_type,
      cluster_ids = cluster_ids,
      cluster_lookup = cluster_lookup,
      X_mat = X_mat, y_vec = y_vec, w_vec = w_vec,
      X_exp = X_exp_mat, X_unexp = X_unexp_mat,
      mc.cores = n_cores
    ), use.names = FALSE))
  }

  worker_env <- new.env(parent = emptyenv())
  worker_env$run_one_replicate_fast <- run_one_replicate_fast
  worker_env$model_type <- model_type
  worker_env$cluster_ids <- cluster_ids
  worker_env$cluster_lookup <- cluster_lookup
  worker_env$X_mat <- X_mat
  worker_env$y_vec <- y_vec
  worker_env$w_vec <- w_vec
  worker_env$X_exp_mat <- X_exp_mat
  worker_env$X_unexp_mat <- X_unexp_mat

  cluster <- parallel::makeCluster(n_cores)
  on.exit(parallel::stopCluster(cluster), add = TRUE)
  parallel::clusterExport(
    cluster,
    varlist = ls(worker_env, all.names = TRUE),
    envir = worker_env
  )

  unlist(parallel::parLapply(cluster, seeds, function(seed) {
    run_one_replicate_fast(
      seed = seed,
      model_type = model_type,
      cluster_ids = cluster_ids,
      cluster_lookup = cluster_lookup,
      X_mat = X_mat,
      y_vec = y_vec,
      w_vec = w_vec,
      X_exp = X_exp_mat,
      X_unexp = X_unexp_mat
    )
  }), use.names = FALSE)
}

prepare_analysis_model_df <- function(df, cost_col) {
  if (!nrow(df)) {
    return(df)
  }

  if ("match_weight" %in% names(df)) {
    df$match_weight[!is.finite(df$match_weight) | is.na(df$match_weight) | df$match_weight <= 0] <- 1
  } else {
    df$match_weight <- 1
  }

  numeric_cols <- intersect(
    c(cost_col, "observed_person_years", "age_at_index_months"),
    names(df)
  )
  for (col in numeric_cols) {
    df[[col]][!is.finite(df[[col]])] <- NA_real_
  }

  categorical_cols <- intersect(
    c(
      "sex", "region",
      "parent_education_group", "parent_socio_group", "cohabitation_group",
      "gest_age_cat", "birth_weight_cat", "parity_cat", "multiple_birth",
      "maternal_age_birth_group", "apgar_cat", "truncated_lookback_flag",
      "index_year_f"
    ),
    names(df)
  )
  for (col in categorical_cols) {
    df[[col]] <- droplevels(factor(as.character(df[[col]])))
  }

  df <- df[!is.na(df$exposed) & !is.na(df[[cost_col]]), , drop = FALSE]
  df
}

bootstrap_cost_difference <- function(
  df, formula, model_type, cost_col,
  n_replicates = 1000L, n_cores = 1L, parallel_backend = "auto"
) {
  # Pre-clean NAs across all variables in the formula to ensure matrices align perfectly.
  # This mimics the behavior of glm() but moves it outside the performance-critical loop.
  vars_needed <- all.vars(formula)
  valid_rows <- stats::complete.cases(df[, intersect(vars_needed, names(df)), drop = FALSE])
  df_clean <- df[valid_rows, , drop = FALSE]

  if (!nrow(df_clean)) {
    return(list(ci_lower = NA_real_, ci_upper = NA_real_, n_valid_replicates = 0L))
  }

  df_clean$.cluster_id__ <- ifelse(
    is.na(df_clean$family_id), paste0("__singleton_", df_clean$person_id), df_clean$family_id
  )
  cluster_ids    <- unique(df_clean$.cluster_id__)
  cluster_lookup <- split(seq_len(nrow(df_clean)), df_clean$.cluster_id__)

  # Precompute design matrices once.
  X_mat <- stats::model.matrix(formula, data = df_clean)
  y_vec <- df_clean[[cost_col]]
  w_vec <- df_clean$match_weight

  # Precompute counterfactual design matrices for marginal standardization.
  df_exp <- df_clean;   df_exp$exposed <- TRUE
  df_unexp <- df_clean; df_unexp$exposed <- FALSE
  X_exp_mat   <- stats::model.matrix(formula, data = df_exp)
  X_unexp_mat <- stats::model.matrix(formula, data = df_unexp)

  diffs <- run_bootstrap_replicates(
    seeds = seq_len(n_replicates),
    model_type = model_type,
    cluster_ids = cluster_ids,
    cluster_lookup = cluster_lookup,
    X_mat = X_mat,
    y_vec = y_vec,
    w_vec = w_vec,
    X_exp_mat = X_exp_mat,
    X_unexp_mat = X_unexp_mat,
    n_cores = n_cores,
    parallel_backend = parallel_backend
  )

  diffs <- diffs[!is.na(diffs)]
  list(
    ci_lower           = if (length(diffs)) stats::quantile(diffs, 0.025) else NA_real_,
    ci_upper           = if (length(diffs)) stats::quantile(diffs, 0.975) else NA_real_,
    n_valid_replicates = length(diffs)
  )
}

# ── Single component × follow-up-year analysis ────────────────────────────────

# component_df: optional pre-joined, pre-filtered slice for this component.
# When supplied (by run_cost_analysis), the function skips the join + component filter.
analyse_component <- function(
  panel_df, matched_df, component_name,
  followup_year_target = NULL,
  model_type = c("gamma", "two_part"),
  n_bootstrap = 1000L, n_cores = 1L,
  base_cost_col = "cost_reference_dkk_allocated",
  subgroup_col = NULL, subgroup_val = NULL,
  discount_rate = NA_real_,
  component_df = NULL
) {
  model_type <- match.arg(model_type)

  if (!is.null(component_df)) {
    df <- component_df
  } else {
    df <- panel_df[panel_df$component == component_name, , drop = FALSE]
    df <- join_analysis_covariates(df, matched_df)
  }

  if (!is.null(followup_year_target)) {
    df <- df[df$followup_year == followup_year_target, , drop = FALSE]
    label <- sprintf("year %d", followup_year_target)
  } else {
    label <- "cumulative"
  }

  # Apply subgroup filter after join (sex/SES come from matched_df, age_band is derived)
  if (!is.null(subgroup_col) && !is.null(subgroup_val)) {
    if (subgroup_col == "age_band") {
      df$age_band <- as.character(derive_age_band(df$age_at_index_months))
      df <- df[!is.na(df$age_band) & df$age_band == subgroup_val, , drop = FALSE]
    } else {
      df <- df[
        !is.na(df[[subgroup_col]]) &
          as.character(df[[subgroup_col]]) == as.character(subgroup_val),
        , drop = FALSE
      ]
    }
  }

  # Standardize cost column to cost__ to simplify downstream code
  df$cost__ <- df[[base_cost_col]]

  if (!is.null(followup_year_target)) {
    cost_col <- "cost_rate__"
    df$cost_rate__ <- df$cost__ / pmax(df$observed_person_years, 1 / 365.25)
  } else {
    df <- df |>
      group_by(
        person_id, family_id, matched_set_id, match_weight,
        exposed, diagnosis_group, severity, index_date, index_year
      ) |>
      summarise(
        cost__ = sum(cost__, na.rm = TRUE),
        observed_person_years = sum(observed_person_years, na.rm = TRUE),
        .groups = "drop"
      ) |>
      as.data.frame(stringsAsFactors = FALSE)
    cost_col <- "cost__"
  }

  df <- df[!is.na(df$exposed) & df$observed_person_years > 0, , drop = FALSE]
  df <- prepare_analysis_model_df(df, cost_col)

  diagnostics <- model_preflight_diagnostics(
    df,
    cost_col = cost_col,
    component_name = component_name,
    followup_year_target = followup_year_target,
    model_type = model_type
  )

  if (!identical(diagnostics$model_status, "ok")) {
    note <- switch(
      diagnostics$model_status,
      insufficient_observations = "Insufficient observations",
      insufficient_positive_costs = sprintf("Insufficient positive costs for %s model", model_type),
      diagnostics$model_status
    )
    return(analysis_result_row(
      component_name, followup_year_target, model_type, discount_rate,
      subgroup_col, subgroup_val, diagnostics, note = note
    ))
  }

  formula <- build_cost_formula(df, cost_col)
  diagnostics$n_parameters <- formula_parameter_count(formula, df)

  fit_result <- if (model_type == "gamma") {
    suppressWarnings(fit_gamma_glm(df, formula, cost_col = cost_col, verbose = FALSE))
  } else {
    suppressWarnings(fit_two_part_model(df, formula, cost_col = cost_col, verbose = FALSE))
  }

  if ((model_type == "gamma" && is.null(fit_result)) ||
      (model_type == "two_part" && (is.null(fit_result$model_bin) || is.null(fit_result$model_pos)))) {
    diagnostics$model_status <- "fit_failed"
    diagnostics$failure_message <- sprintf("%s fit failed", if (model_type == "gamma") "Gamma GLM" else "Two-part model")
    diagnostics$actionable_note <- "Model fitting failed; inspect positive-cost counts, one-level factors, and separation diagnostics."
    return(analysis_result_row(
      component_name, followup_year_target, model_type, discount_rate,
      subgroup_col, subgroup_val, diagnostics, note = diagnostics$failure_message
    ))
  }

  if (!model_result_converged(fit_result, model_type)) {
    diagnostics$model_status <- "unstable_fit"
    diagnostics$failure_message <- "GLM algorithm did not converge."
    diagnostics$actionable_note <- "Model fit did not converge; prefer cumulative estimates or simplify the model for this slice."
    return(analysis_result_row(
      component_name, followup_year_target, model_type, discount_rate,
      subgroup_col, subgroup_val, diagnostics, note = "Unstable model fit"
    ))
  }

  ms <- if (model_type == "gamma") {
    marginal_standardize(fit_result, df)
  } else {
    marginal_standardize_two_part(fit_result, df)
  }

  stability <- classify_prediction_stability(
    ms$mean_exposed,
    ms$mean_unexposed,
    ms$mean_difference,
    diagnostics$observed_max_cost
  )
  diagnostics$model_status <- stability$model_status
  diagnostics$actionable_note <- stability$actionable_note
  if (!identical(stability$model_status, "ok")) {
    diagnostics$failure_message <- stability$actionable_note
    return(analysis_result_row(
      component_name, followup_year_target, model_type, discount_rate,
      subgroup_col, subgroup_val, diagnostics, note = "Unstable model fit"
    ))
  }

  slice_label <- analysis_slice_label(component_name, label, subgroup_col, subgroup_val)
  message(format_bootstrap_start_message(slice_label, ms$mean_difference, n_bootstrap))

  boot <- suppressWarnings(bootstrap_cost_difference(
    df, formula, model_type, cost_col,
    n_replicates = n_bootstrap, n_cores = n_cores
  ))
  message(format_bootstrap_result_message(
    slice_label = slice_label,
    mean_difference = ms$mean_difference,
    ci_lower = boot$ci_lower,
    ci_upper = boot$ci_upper,
    n_valid_replicates = boot$n_valid_replicates,
    n_bootstrap = n_bootstrap
  ))

  analysis_result_row(
    component_name, followup_year_target, model_type, discount_rate,
    subgroup_col, subgroup_val, diagnostics,
    mean_exposed = ms$mean_exposed,
    mean_unexposed = ms$mean_unexposed,
    mean_difference = ms$mean_difference,
    ci_lower = boot$ci_lower,
    ci_upper = boot$ci_upper,
    n_bootstrap_valid = boot$n_valid_replicates
  )
}

# ── Component model-type selection ────────────────────────────────────────────

select_model_type <- function(
  panel_df,
  component_name,
  zero_threshold = 0.20,
  segment_df = NULL,
  base_cost_col = "cost_reference_dkk_allocated"
) {
  if (!is.null(segment_df) && nrow(segment_df)) {
    rows <- panel_df[panel_df$component == component_name, , drop = FALSE]
    if (!nrow(segment_df)) return("gamma")
    positive_rows <- if (base_cost_col %in% names(rows)) {
      sum(rows[[base_cost_col]] > 0, na.rm = TRUE)
    } else {
      0L
    }
    zero_share <- 1 - (positive_rows / nrow(segment_df))
    return(if (zero_share > zero_threshold) "two_part" else "gamma")
  }

  rows <- panel_df[panel_df$component == component_name, , drop = FALSE]
  if (!nrow(rows)) return("gamma")
  zero_share <- mean(rows[[base_cost_col]] == 0, na.rm = TRUE)
  if (zero_share > zero_threshold) "two_part" else "gamma"
}

# ── Full analysis pipeline ────────────────────────────────────────────────────

run_cost_analysis <- function(
  panel_df, matched_df,
  max_followup_years = 10L,
  n_bootstrap        = 1000L,
  n_cores            = 1L,
  base_cost_col      = "cost_reference_dkk_allocated",
  discount_rate      = NA_real_,
  subgroup_col       = NULL,
  subgroup_val       = NULL,
  cumulative_only    = FALSE,
  segment_df         = NULL
) {
  compact_input <- !is.null(segment_df) && nrow(segment_df)
  if (isTRUE(compact_input) && !exists("complete_compact_followup_component_slice", mode = "function")) {
    stop(
      "Compact follow-up analysis requires followup_cost_panel.R to be sourced first.",
      call. = FALSE
    )
  }

  analysis_components <- c("total", "lmdb", "lpr_sghforlob", "lpr_kontakt", "primary_sector")
  components <- if (isTRUE(compact_input)) {
    analysis_components
  } else {
    intersect(analysis_components, unique(panel_df$component))
  }

  if (!isTRUE(compact_input)) {
    # Join covariates once and pre-split by component to avoid repeated joins + linear scans.
    panel_aug      <- join_analysis_covariates(panel_df, matched_df)
    panel_by_comp  <- split(panel_aug, panel_aug$component)
  } else {
    panel_by_comp <- list()
  }

  results <- list()

  for (comp in components) {
    model_type <- select_model_type(
      panel_df,
      comp,
      segment_df = if (isTRUE(compact_input)) segment_df else NULL,
      base_cost_col = base_cost_col
    )
    message(sprintf("Component: %s  |  model: %s", comp, model_type))

    comp_df <- if (isTRUE(compact_input)) {
      join_analysis_covariates(
        complete_compact_followup_component_slice(
          panel_df,
          segment_df,
          comp,
          base_cost_col = base_cost_col
        ),
        matched_df
      )
    } else {
      panel_by_comp[[comp]]
    }

    results[[length(results) + 1L]] <- analyse_component(
      panel_df = panel_df, matched_df = matched_df, component_name = comp,
      followup_year_target = NULL,
      model_type = model_type,
      n_bootstrap = n_bootstrap, n_cores = n_cores,
      base_cost_col = base_cost_col,
      subgroup_col = subgroup_col, subgroup_val = subgroup_val,
      discount_rate = discount_rate,
      component_df = comp_df
    )

    if (!cumulative_only) {
      for (fy in seq_len(max_followup_years)) {
        results[[length(results) + 1L]] <- analyse_component(
          panel_df = panel_df, matched_df = matched_df, component_name = comp,
          followup_year_target = fy,
          model_type = model_type,
          n_bootstrap = n_bootstrap, n_cores = n_cores,
          base_cost_col = base_cost_col,
          subgroup_col = subgroup_col, subgroup_val = subgroup_val,
          discount_rate = discount_rate,
          component_df = comp_df
        )
      }
    }
  }

  bind_rows(results) |>
    mutate(followup_year = as.integer(followup_year)) |>
    arrange(component, followup_year) |>
    as.data.frame(stringsAsFactors = FALSE)
}

# ── Discount scenario analyses ────────────────────────────────────────────────

run_discount_scenarios <- function(
  discounted_panel_df, matched_df,
  discount_rates     = c(0.03, 0.05),
  max_followup_years = 10L,
  n_bootstrap        = 1000L,
  n_cores            = 1L,
  segment_df         = NULL
) {
  bind_rows(lapply(discount_rates, function(rate) {
    rate_df <- discounted_panel_df[
      !is.na(discounted_panel_df$discount_rate) &
        abs(discounted_panel_df$discount_rate - rate) < 1e-9,
      , drop = FALSE
    ]
    if (!nrow(rate_df)) {
      message(sprintf("  No rows for discount_rate = %.2f, skipping.", rate))
      return(data.frame())
    }
    message(sprintf("Discount scenario: %.0f%%", rate * 100))
    run_cost_analysis(
      panel_df        = rate_df,
      matched_df      = matched_df,
      max_followup_years = max_followup_years,
      n_bootstrap     = n_bootstrap,
      n_cores         = n_cores,
      base_cost_col   = "discounted_cost_reference_dkk",
      discount_rate   = rate,
      cumulative_only = TRUE,
      segment_df      = segment_df
    )
  }))
}

# ── Subgroup analyses ─────────────────────────────────────────────────────────

run_subgroup_analyses <- function(
  panel_df, matched_df,
  max_followup_years = 10L,
  n_bootstrap        = 1000L,
  n_cores            = 1L,
  segment_df         = NULL
) {
  subgroup_specs <- list(
    list(col = "diagnosis_group",    vals = sort(unique(na.omit(panel_df$diagnosis_group)))),
    list(col = "sex",                vals = sort(unique(na.omit(matched_df$sex)))),
    list(col = "parent_socio_group", vals = sort(unique(na.omit(matched_df$parent_socio_group)))),
    list(col = "age_band",           vals = c("0-4yr", "5-9yr", "10-14yr", "15-17yr", "18+yr"))
  )

  # Remove specs where matched column does not exist in matched_df
  subgroup_specs <- Filter(function(s) {
    s$col == "diagnosis_group" ||
    s$col == "age_band" ||
    s$col %in% names(matched_df)
  }, subgroup_specs)

  results <- list()
  for (spec in subgroup_specs) {
    for (val in spec$vals) {
      message(sprintf("Subgroup: %s = %s", spec$col, val))
      res <- run_cost_analysis(
        panel_df        = panel_df,
        matched_df      = matched_df,
        max_followup_years = max_followup_years,
        n_bootstrap     = n_bootstrap,
        n_cores         = n_cores,
        subgroup_col    = spec$col,
        subgroup_val    = val,
        cumulative_only = TRUE,
        segment_df      = segment_df
      )
      results[[length(results) + 1L]] <- res
    }
  }

  bind_rows(results)
}

# ── Utilization proxy analysis (non-monetary supplementary) ───────────────────

run_utilization_proxy_analysis <- function(panel_df, config) {
  proxy_paths <- list(
    lpr_contact_count = file.path(config$registers_dir, "lpr",            "lpr_proxy_usage.parquet"),
    ssr_contact_count = file.path(config$registers_dir, "primary_sector", "primary_sector_usage.parquet"),
    rx_fill_count     = file.path(config$registers_dir, "prescriptions",  "lmdb_usage.parquet")
  )

  available <- Filter(file.exists, proxy_paths)
  if (!length(available)) {
    message("No utilization proxy files found — skipping proxy analysis.")
    return(data.frame())
  }

  # Use the total component; one row per person × follow-up year
  panel_total <- panel_df[panel_df$component == "total", , drop = FALSE]
  if (!nrow(panel_total)) return(data.frame())

  # Map each follow-up year to its approximate calendar year
  panel_total$proxy_cal_year <- panel_total$index_year + panel_total$followup_year - 1L

  results <- list()
  for (count_col in names(available)) {
    proxy_df <- tryCatch(
      arrow::read_parquet(available[[count_col]]),
      error = function(e) {
        message(sprintf("  Failed to load %s: %s", available[[count_col]], conditionMessage(e)))
        NULL
      }
    )
    if (is.null(proxy_df)) next

    year_col <- if ("year" %in% names(proxy_df)) "year" else
                if ("calendar_year" %in% names(proxy_df)) "calendar_year" else NULL
    raw_count_col <- setdiff(names(proxy_df), c("person_id", year_col))[1]

    if (is.null(year_col) || is.na(raw_count_col)) {
      message(sprintf("  Cannot identify year/count columns in %s — skipping.", basename(available[[count_col]])))
      next
    }

    proxy_df$year__  <- proxy_df[[year_col]]
    proxy_df$count__ <- as.numeric(proxy_df[[raw_count_col]])

    joined <- merge(
      panel_total[, c("person_id", "exposed", "followup_year", "proxy_cal_year"), drop = FALSE],
      proxy_df[, c("person_id", "year__", "count__"), drop = FALSE],
      by.x = c("person_id", "proxy_cal_year"),
      by.y = c("person_id", "year__"),
      all.x = TRUE
    )
    joined$count__[is.na(joined$count__)] <- 0

    summary_df <- joined |>
      group_by(exposed, followup_year) |>
      summarise(
        proxy          = count_col,
        n_persons      = n_distinct(person_id),
        mean_count     = mean(count__, na.rm = TRUE),
        median_count   = median(count__, na.rm = TRUE),
        zero_fraction  = mean(count__ == 0, na.rm = TRUE),
        .groups = "drop"
      ) |>
      as.data.frame(stringsAsFactors = FALSE)

    results[[count_col]] <- summary_df
  }

  if (!length(results)) return(data.frame())
  bind_rows(results) |>
    arrange(proxy, followup_year, exposed) |>
    as.data.frame(stringsAsFactors = FALSE)
}

# ── Output ────────────────────────────────────────────────────────────────────

write_cost_analysis_outputs <- function(results_df, config) {
  ensure_output_dir(config)

  is_primary  <- is.na(results_df$discount_rate) & is.na(results_df$subgroup_col)
  is_discount <- !is.na(results_df$discount_rate)
  is_subgroup <- is.na(results_df$discount_rate) & !is.na(results_df$subgroup_col)

  primary_df      <- results_df[is_primary,  , drop = FALSE]
  discount_df     <- results_df[is_discount, , drop = FALSE]
  subgroup_df     <- results_df[is_subgroup, , drop = FALSE]

  cumulative_df   <- primary_df[is.na(primary_df$followup_year),  , drop = FALSE]
  annual_df       <- primary_df[!is.na(primary_df$followup_year), , drop = FALSE]

  paths <- list(
    all_results       = output_file(config, "cost_analysis_results"),
    cumulative        = output_file(config, "cost_analysis_cumulative"),
    annual            = output_file(config, "cost_analysis_annual"),
    discount_results  = output_file(config, "cost_analysis_discount_scenarios"),
    subgroup_results  = output_file(config, "cost_analysis_subgroups"),
    model_diagnostics = output_file(config, "model_diagnostics")
  )
  lapply(paths, ensure_output_parent)

  write_csv_file(results_df,    paths$all_results)
  write_csv_file(cumulative_df, paths$cumulative)
  write_csv_file(annual_df,     paths$annual)
  write_csv_file(discount_df,   paths$discount_results)
  write_csv_file(subgroup_df,   paths$subgroup_results)
  write_analysis_diagnostics_output(results_df, paths$model_diagnostics)

  paths
}
