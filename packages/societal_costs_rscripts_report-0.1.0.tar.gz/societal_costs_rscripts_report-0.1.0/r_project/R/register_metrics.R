suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

if (!exists("output_file", mode = "function") && file.exists(file.path("R", "output_paths.R"))) {
  source(file.path("R", "output_paths.R"))
}

safe_numeric <- function(x) {
  value <- suppressWarnings(as.numeric(x))
  ifelse(is.na(value), 0, value)
}

timed_register_step <- function(label, expr) {
  start <- Sys.time()
  message(sprintf("    * %s...", label))
  result <- force(expr)
  elapsed <- as.numeric(difftime(Sys.time(), start, units = "secs"))
  message(sprintf("    * %s completed in %.1f seconds", label, elapsed))
  result
}

prepared_baseline_cache_enabled <- function(config) {
  reuse <- config$reuse_prepared_baseline_artifacts
  if (is.null(reuse) || length(reuse) != 1L || is.na(reuse)) {
    reuse <- TRUE
  }
  force_rebuild <- config$force_rebuild_prepared_baseline_artifacts
  if (is.null(force_rebuild) || length(force_rebuild) != 1L || is.na(force_rebuild)) {
    force_rebuild <- FALSE
  }
  isTRUE(reuse) && !isTRUE(force_rebuild)
}

prepared_baseline_cache_write_enabled <- function(config) {
  reuse <- config$reuse_prepared_baseline_artifacts
  if (is.null(reuse) || length(reuse) != 1L || is.na(reuse)) {
    reuse <- TRUE
  }
  isTRUE(reuse)
}

filter_register_dataset <- function(ds, filter_ids = NULL, min_year = NULL, max_year = NULL) {
  available_columns <- names(ds$schema)
  if ("year" %in% available_columns) {
    year_expr <- rlang::sym("year")
    if (!is.null(min_year) && !is.na(min_year)) {
      ds <- ds |> filter(!!year_expr >= min_year)
    }
    if (!is.null(max_year) && !is.na(max_year)) {
      ds <- ds |> filter(!!year_expr <= max_year)
    }
  }
  if (!is.null(filter_ids)) {
    ds <- ds |> filter(as.character(person_id) %in% filter_ids)
  }
  ds
}

load_register_usage_tables <- function(config, person_ids = NULL, min_year = NULL, max_year = NULL) {
  registers_root <- config$registers_dir
  lpr_proxy_path <- file.path(registers_root, "lpr", "lpr_proxy_usage.parquet")
  lmdb_usage_path <- file.path(registers_root, "prescriptions", "lmdb_usage.parquet")
  lmdb_atc_path <- file.path(registers_root, "prescriptions", "lmdb_atc_level3.parquet")
  primary_sector_path <- file.path(registers_root, "primary_sector", "primary_sector_usage.parquet")

  required_paths <- c(lpr_proxy_path, lmdb_usage_path, lmdb_atc_path, primary_sector_path)
  missing_required <- required_paths[!file.exists(required_paths)]
  if (length(missing_required)) {
    stop(sprintf("Missing required register usage artifacts: %s", paste(missing_required, collapse = ", ")))
  }

  hospital_drugs_path <- normalizePath(config$hospital_drugs_usage_path, winslash = "/", mustWork = FALSE)
  hospital_drugs_enabled <- isTRUE(config$use_hospital_drugs)
  hospital_drugs_available <- hospital_drugs_enabled && file.exists(hospital_drugs_path)

  filter_ids <- if (length(person_ids)) as.character(person_ids) else NULL

  read_register <- function(path, label) {
    ds <- arrow::open_dataset(path, format = "parquet")
    ds <- filter_register_dataset(ds, filter_ids = filter_ids, min_year = min_year, max_year = max_year)
    timed_register_step(label, {
      ds |> collect() |> as.data.frame(stringsAsFactors = FALSE)
    })
  }

  list(
    lpr_proxy = read_register(lpr_proxy_path, "load LPR usage"),
    lmdb_usage = read_register(lmdb_usage_path, "load LMDB usage"),
    lmdb_atc = read_register(lmdb_atc_path, "load LMDB ATC"),
    primary_sector = read_register(primary_sector_path, "load primary-sector usage"),
    hospital_drugs = if (hospital_drugs_available) read_register(hospital_drugs_path, "load hospital-drug usage") else NULL,
    hospital_drugs_enabled = hospital_drugs_enabled,
    hospital_drugs_available = hospital_drugs_available,
    hospital_drugs_path = hospital_drugs_path
  )
}

build_preindex_component_years <- function(registers) {
  lpr_df <- registers$lpr_proxy |>
    transmute(
      person_id,
      year = as.integer(year),
      proxy_total = as.numeric(proxy_index),
      raw_total = as.numeric(contacts) + as.numeric(episodes),
      hosp_days_total = as.numeric(bed_days),
      proxy_seen = TRUE,
      raw_seen = TRUE,
      hosp_days_seen = TRUE
    )

  lmdb_atc_distinct <- registers$lmdb_atc |>
    distinct(person_id, year, atc_code) |>
    count(person_id, year, name = "atc_distinct")

  lmdb_df <- registers$lmdb_usage |>
    left_join(lmdb_atc_distinct, by = c("person_id", "year")) |>
    mutate(
      atc_distinct = dplyr::coalesce(as.numeric(atc_distinct), 0),
      proxy_total = as.numeric(dispenses) + 0.25 * atc_distinct,
      raw_total = as.numeric(dispenses),
      hosp_days_total = 0,
      proxy_seen = TRUE,
      raw_seen = TRUE,
      hosp_days_seen = FALSE
    ) |>
    transmute(
      person_id,
      year = as.integer(year),
      proxy_total,
      raw_total,
      hosp_days_total,
      proxy_seen,
      raw_seen,
      hosp_days_seen
    )

  primary_df <- registers$primary_sector |>
    mutate(
      contacts = pmax(safe_numeric(contacts), 0),
      services = pmax(safe_numeric(services), 0),
      proxy_total = contacts + 0.5 * services,
      raw_total = contacts + services,
      hosp_days_total = 0,
      proxy_seen = TRUE,
      raw_seen = TRUE,
      hosp_days_seen = FALSE
    ) |>
    transmute(
      person_id,
      year = as.integer(year),
      proxy_total,
      raw_total,
      hosp_days_total,
      proxy_seen,
      raw_seen,
      hosp_days_seen
    )

  component_df <- bind_rows(lpr_df, lmdb_df, primary_df)

  if (!is.null(registers$hospital_drugs)) {
    hospital_df <- registers$hospital_drugs
    dispenses_col <- intersect(c("dispenses", "packages", "volume"), names(hospital_df))
    if (!length(dispenses_col)) {
      stop(
        sprintf(
          "Hospital-drugs parquet at %s is missing a usable count column.",
          registers$hospital_drugs_path
        )
      )
    }

    hospital_component_df <- hospital_df |>
      transmute(
        person_id,
        year = as.integer(year),
        proxy_total = 0,
        raw_total = as.numeric(.data[[dispenses_col[[1]]]]),
        hosp_days_total = 0,
        proxy_seen = FALSE,
        raw_seen = TRUE,
        hosp_days_seen = FALSE
      )

    component_df <- bind_rows(component_df, hospital_component_df)
  }

  component_df |>
    group_by(person_id, year) |>
    summarise(
      proxy_total = sum(proxy_total, na.rm = TRUE),
      raw_total = sum(raw_total, na.rm = TRUE),
      hosp_days_total = sum(hosp_days_total, na.rm = TRUE),
      proxy_seen = any(proxy_seen),
      raw_seen = any(raw_seen),
      hosp_days_seen = any(hosp_days_seen),
      .groups = "drop"
  )
}

preindex_observation_windows <- function(baseline_df, config) {
  index_dates_v  <- as.Date(baseline_df$index_date)
  fixed_start    <- index_dates_v - config$baseline_years_target * 365L
  fixed_end      <- index_dates_v - config$preindex_lag_days
  baseline_start <- as.Date(baseline_df$baseline_start)
  baseline_end   <- as.Date(baseline_df$baseline_end)
  birth_date     <- as.Date(baseline_df$birth_date)

  obs_start_raw <- pmax(fixed_start, baseline_start, na.rm = TRUE)
  birth_adj     <- !is.na(birth_date) & birth_date > obs_start_raw
  obs_start     <- as.Date(
    ifelse(birth_adj, as.numeric(birth_date), as.numeric(obs_start_raw)),
    origin = "1970-01-01"
  )
  obs_end <- pmin(fixed_end, baseline_end, na.rm = TRUE)

  valid_windows <- !is.na(obs_start) & !is.na(obs_end) & obs_end >= obs_start
  min_year <- if (any(valid_windows)) {
    min(as.integer(format(obs_start[valid_windows], "%Y")), na.rm = TRUE)
  } else {
    NA_integer_
  }
  max_year <- if (any(valid_windows)) {
    max(as.integer(format(obs_end[valid_windows], "%Y")), na.rm = TRUE)
  } else {
    NA_integer_
  }

  list(
    windows_df = data.frame(
      person_id = baseline_df$person_id,
      obs_start = obs_start,
      obs_end   = obs_end,
      stringsAsFactors = FALSE
    ),
    min_year = min_year,
    max_year = max_year
  )
}

preindex_person_ids_cache_covers <- function(config, person_ids) {
  path <- output_file(config, "preindex_person_ids_cache")
  if (!file.exists(path)) {
    return(FALSE)
  }
  cached <- tryCatch(arrow::read_parquet(path), error = function(e) NULL)
  if (is.null(cached) || !("person_id" %in% names(cached))) {
    return(FALSE)
  }
  !length(setdiff(person_ids, cached$person_id))
}

preindex_metadata_covers <- function(config, min_year, max_year) {
  metadata_path <- output_file(config, "preindex_component_years_metadata")
  if (!file.exists(metadata_path)) {
    return(FALSE)
  }
  metadata <- tryCatch(utils::read.csv(metadata_path, stringsAsFactors = FALSE), error = function(e) NULL)
  required <- c(
    "min_year",
    "max_year",
    "hospital_drugs_available",
    "registers_dir",
    "use_hospital_drugs",
    "hospital_drugs_path"
  )
  if (is.null(metadata) || !nrow(metadata) || !all(required %in% names(metadata))) {
    return(FALSE)
  }
  if (!identical(as.character(metadata$registers_dir[[1]]), as.character(config$registers_dir))) {
    return(FALSE)
  }
  cached_use_hospital_drugs <- isTRUE(metadata$use_hospital_drugs[[1]]) ||
    identical(tolower(as.character(metadata$use_hospital_drugs[[1]])), "true")
  if (!identical(cached_use_hospital_drugs, isTRUE(config$use_hospital_drugs))) {
    return(FALSE)
  }
  if (!identical(as.character(metadata$hospital_drugs_path[[1]]), as.character(config$hospital_drugs_usage_path))) {
    return(FALSE)
  }
  cached_min <- suppressWarnings(as.integer(metadata$min_year[[1]]))
  cached_max <- suppressWarnings(as.integer(metadata$max_year[[1]]))
  if (is.na(min_year) || is.na(max_year)) {
    return(TRUE)
  }
  !is.na(cached_min) && !is.na(cached_max) && cached_min <= min_year && cached_max >= max_year
}

preindex_component_years_cache_valid <- function(config, person_ids, min_year, max_year) {
  if (!prepared_baseline_cache_enabled(config)) {
    return(FALSE)
  }
  all(file.exists(c(
    output_file(config, "preindex_component_years_cache"),
    output_file(config, "preindex_person_ids_cache"),
    output_file(config, "preindex_component_years_metadata")
  ))) &&
    preindex_person_ids_cache_covers(config, person_ids) &&
    preindex_metadata_covers(config, min_year, max_year)
}

read_preindex_component_years_cache <- function(config, person_ids, min_year, max_year) {
  component_years <- arrow::read_parquet(output_file(config, "preindex_component_years_cache")) |>
    as.data.frame(stringsAsFactors = FALSE)
  if (nrow(component_years)) {
    component_years <- component_years |>
      filter(person_id %in% person_ids) |>
      as.data.frame(stringsAsFactors = FALSE)
    if (!is.na(min_year) && !is.na(max_year) && "year" %in% names(component_years)) {
      component_years <- component_years |>
        filter(is.na(year) | (year >= min_year & year <= max_year)) |>
        as.data.frame(stringsAsFactors = FALSE)
    }
  }
  metadata <- utils::read.csv(output_file(config, "preindex_component_years_metadata"), stringsAsFactors = FALSE)
  list(
    component_years = component_years,
    hospital_drugs_available = isTRUE(metadata$hospital_drugs_available[[1]]) ||
      identical(tolower(as.character(metadata$hospital_drugs_available[[1]])), "true")
  )
}

write_preindex_component_years_cache <- function(config, component_years, person_ids, min_year, max_year, hospital_drugs_available) {
  write_parquet_output(component_years, config, "preindex_component_years_cache")
  write_parquet_output(
    data.frame(person_id = person_ids, stringsAsFactors = FALSE),
    config,
    "preindex_person_ids_cache"
  )
  write_csv_output(
    data.frame(
      min_year = min_year,
      max_year = max_year,
      person_count = length(person_ids),
      hospital_drugs_available = isTRUE(hospital_drugs_available),
      registers_dir = config$registers_dir,
      use_hospital_drugs = isTRUE(config$use_hospital_drugs),
      hospital_drugs_path = config$hospital_drugs_usage_path,
      created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
      stringsAsFactors = FALSE
    ),
    config,
    "preindex_component_years_metadata"
  )
  invisible(TRUE)
}

aggregate_preindex_component_years <- function(component_years, windows_df) {
  empty <- data.frame(
    person_id = character(),
    proxy_total_w = numeric(),
    raw_total_w = numeric(),
    hosp_days_total_w = numeric(),
    proxy_seen_any = logical(),
    raw_seen_any = logical(),
    hosp_days_seen_any = logical(),
    stringsAsFactors = FALSE
  )
  if (!nrow(component_years) || !nrow(windows_df)) {
    return(empty)
  }

  component_years$person_id <- as.character(component_years$person_id)
  windows_df$person_id <- as.character(windows_df$person_id)
  window_idx <- match(component_years$person_id, windows_df$person_id)
  keep <- !is.na(window_idx)
  if (!any(keep)) {
    return(empty)
  }

  cy <- component_years[keep, , drop = FALSE]
  wi <- window_idx[keep]
  obs_start_num <- as.numeric(as.Date(windows_df$obs_start[wi]))
  obs_end_num <- as.numeric(as.Date(windows_df$obs_end[wi]))
  valid_window <- !is.na(obs_start_num) & !is.na(obs_end_num) & obs_end_num >= obs_start_num
  if (!any(valid_window)) {
    return(empty)
  }

  cy <- cy[valid_window, , drop = FALSE]
  obs_start_num <- obs_start_num[valid_window]
  obs_end_num <- obs_end_num[valid_window]
  years <- as.integer(cy$year)
  valid_year <- !is.na(years)
  if (!any(valid_year)) {
    return(empty)
  }

  cy <- cy[valid_year, , drop = FALSE]
  obs_start_num <- obs_start_num[valid_year]
  obs_end_num <- obs_end_num[valid_year]
  years <- years[valid_year]

  unique_years <- sort(unique(years))
  year_keys <- as.character(unique_years)
  year_start_map <- stats::setNames(as.numeric(as.Date(sprintf("%d-01-01", unique_years))), year_keys)
  year_end_map <- stats::setNames(as.numeric(as.Date(sprintf("%d-12-31", unique_years))), year_keys)
  year_key <- as.character(years)
  yr_start_num <- unname(year_start_map[year_key])
  yr_end_num <- unname(year_end_map[year_key])
  yr_days <- yr_end_num - yr_start_num + 1

  ol_start <- pmax(obs_start_num, yr_start_num)
  ol_end <- pmin(obs_end_num, yr_end_num)
  fraction <- ifelse(ol_end >= ol_start, (ol_end - ol_start + 1) / yr_days, 0)
  keep_fraction <- !is.na(fraction) & fraction > 0
  if (!any(keep_fraction)) {
    return(empty)
  }

  cy <- cy[keep_fraction, , drop = FALSE]
  fraction <- fraction[keep_fraction]
  proxy_seen <- cy$proxy_seen %in% TRUE
  raw_seen <- cy$raw_seen %in% TRUE
  hosp_days_seen <- cy$hosp_days_seen %in% TRUE
  proxy_contrib <- ifelse(proxy_seen, safe_numeric(cy$proxy_total) * fraction, 0)
  raw_contrib <- ifelse(raw_seen, safe_numeric(cy$raw_total) * fraction, 0)
  hosp_days_contrib <- ifelse(hosp_days_seen, safe_numeric(cy$hosp_days_total) * fraction, 0)
  group <- cy$person_id

  proxy_sum <- rowsum(proxy_contrib, group, reorder = FALSE)
  raw_sum <- rowsum(raw_contrib, group, reorder = FALSE)
  hosp_days_sum <- rowsum(hosp_days_contrib, group, reorder = FALSE)
  proxy_seen_sum <- rowsum(as.integer(proxy_seen), group, reorder = FALSE)
  raw_seen_sum <- rowsum(as.integer(raw_seen), group, reorder = FALSE)
  hosp_days_seen_sum <- rowsum(as.integer(hosp_days_seen), group, reorder = FALSE)

  data.frame(
    person_id = rownames(proxy_sum),
    proxy_total_w = as.numeric(proxy_sum[, 1]),
    raw_total_w = as.numeric(raw_sum[rownames(proxy_sum), 1]),
    hosp_days_total_w = as.numeric(hosp_days_sum[rownames(proxy_sum), 1]),
    proxy_seen_any = as.integer(proxy_seen_sum[rownames(proxy_sum), 1]) > 0L,
    raw_seen_any = as.integer(raw_seen_sum[rownames(proxy_sum), 1]) > 0L,
    hosp_days_seen_any = as.integer(hosp_days_seen_sum[rownames(proxy_sum), 1]) > 0L,
    stringsAsFactors = FALSE
  )
}

compute_preindex_metrics <- function(baseline_df, config) {
  person_ids <- unique(as.character(baseline_df$person_id))
  person_ids <- person_ids[!is.na(person_ids) & nzchar(person_ids)]
  windows <- preindex_observation_windows(baseline_df, config)
  windows_df <- windows$windows_df

  cached_component_years <- NULL
  hospital_drugs_available <- FALSE
  if (preindex_component_years_cache_valid(config, person_ids, windows$min_year, windows$max_year)) {
    cached_component_years <- timed_register_step("read cached pre-index component-year table", {
      read_preindex_component_years_cache(config, person_ids, windows$min_year, windows$max_year)
    })
    component_years <- cached_component_years$component_years
    hospital_drugs_available <- cached_component_years$hospital_drugs_available
  } else {
    registers <- timed_register_step(
      sprintf("load register usage tables for years %s-%s", windows$min_year, windows$max_year),
      load_register_usage_tables(
        config,
        person_ids = person_ids,
        min_year = windows$min_year,
        max_year = windows$max_year
      )
    )
    component_years <- timed_register_step("build pre-index component-year table", build_preindex_component_years(registers))
    hospital_drugs_available <- registers$hospital_drugs_available
    if (prepared_baseline_cache_write_enabled(config)) {
      timed_register_step("write pre-index component-year cache", {
        write_preindex_component_years_cache(
          config,
          component_years,
          person_ids,
          windows$min_year,
          windows$max_year,
          hospital_drugs_available
        )
      })
    }
  }

  # Join component-years with person windows, compute year-overlap fractions
  aggregated <- timed_register_step("aggregate pre-index utilization windows", {
    aggregate_preindex_component_years(component_years, windows_df)
  })

  result_idx <- match(as.character(baseline_df$person_id), aggregated$person_id)
  proxy_seen_any <- aggregated$proxy_seen_any[result_idx]
  raw_seen_any <- aggregated$raw_seen_any[result_idx]
  hosp_days_seen_any <- aggregated$hosp_days_seen_any[result_idx]
  proxy_total_w <- aggregated$proxy_total_w[result_idx]
  raw_total_w <- aggregated$raw_total_w[result_idx]
  hosp_days_total_w <- aggregated$hosp_days_total_w[result_idx]
  preindex_util_total_numerator <- ifelse(
    !is.na(proxy_seen_any) & proxy_seen_any,
    proxy_total_w,
    ifelse(!is.na(raw_seen_any) & raw_seen_any, raw_total_w, NA_real_)
  )
  preindex_hosp_days_numerator <- ifelse(
    !is.na(hosp_days_seen_any) & hosp_days_seen_any,
    hosp_days_total_w,
    NA_real_
  )

  data.frame(
    preindex_util_total_numerator        = preindex_util_total_numerator,
    preindex_hosp_days_numerator         = preindex_hosp_days_numerator,
    preindex_util_missing_hospital_drugs = !hospital_drugs_available,
    stringsAsFactors = FALSE
  )
}
