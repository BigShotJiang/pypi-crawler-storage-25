suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
  library(jsonlite)
})

if (!exists("output_file", mode = "function") && file.exists(file.path("R", "output_paths.R"))) {
  source(file.path("R", "output_paths.R"))
}

parse_year_from_path <- function(path, prefix) {
  stem <- sub("\\.parquet$", "", basename(path))
  nested_dir <- basename(dirname(path))

  if (identical(nested_dir, prefix)) {
    digits <- gsub("[^0-9]", "", stem)
    if (nchar(digits) >= 4L) {
      return(suppressWarnings(as.integer(substr(digits, 1, 4))))
    }
    return(NA_integer_)
  }

  suffix <- sub(sprintf("^%s", prefix), "", stem)
  suppressWarnings(as.integer(substr(suffix, 1, 4)))
}

parse_snapshot_date_from_path <- function(path, prefix) {
  stem <- sub("\\.parquet$", "", basename(path))
  nested_dir <- basename(dirname(path))
  digits <- if (identical(nested_dir, prefix)) {
    gsub("[^0-9]", "", stem)
  } else {
    gsub("[^0-9]", "", sub(sprintf("^%s", prefix), "", stem))
  }
  if (nchar(digits) >= 6L) {
    year <- suppressWarnings(as.integer(substr(digits, 1L, 4L)))
    month <- suppressWarnings(as.integer(substr(digits, 5L, 6L)))
  } else if (nchar(digits) >= 4L) {
    year <- suppressWarnings(as.integer(substr(digits, 1L, 4L)))
    month <- 12L
  } else {
    return(as.Date(NA))
  }
  if (is.na(year) || is.na(month) || month < 1L || month > 12L) {
    return(as.Date(NA))
  }
  as.Date(sprintf("%04d-%02d-01", year, month))
}

select_latest_popc_snapshot_files <- function(paths, prefix) {
  if (!length(paths)) {
    return(paths)
  }

  snapshot_dates <- as.Date(vapply(
    paths,
    function(path) as.character(parse_snapshot_date_from_path(path, prefix)),
    character(1)
  ))
  if (all(is.na(snapshot_dates))) {
    return(paths)
  }

  latest <- max(snapshot_dates, na.rm = TRUE)
  paths[!is.na(snapshot_dates) & snapshot_dates == latest]
}

find_popc_files <- function(raw_popc_dir, prefix) {
  patterns <- c(
    file.path(raw_popc_dir, sprintf("%s*.parquet", prefix)),
    file.path(raw_popc_dir, prefix, "*.parquet")
  )
  unique(unlist(lapply(patterns, Sys.glob), use.names = FALSE))
}

parent_id_filter_table <- function(person_ids) {
  ids <- unique(as.character(person_ids))
  ids <- ids[!is.na(ids) & nzchar(ids)]
  data.frame(person_id = ids, stringsAsFactors = FALSE)
}

prepared_baseline_cache_enabled <- function(config) {
  reuse <- config$reuse_prepared_baseline_artifacts
  if (is.null(reuse) || length(reuse) != 1L || is.na(reuse)) {
    reuse <- TRUE
  }
  force_rebuild <- config$force_rebuild_prepared_baseline_artifacts
  if (is.null(force_rebuild) || length(force_rebuild) != 1L || is.na(force_rebuild)) {
    force_rebuild <- FALSE
  }
  isTRUE(reuse) && !isTRUE(force_rebuild)
}

prepared_baseline_cache_write_enabled <- function(config) {
  reuse <- config$reuse_prepared_baseline_artifacts
  if (is.null(reuse) || length(reuse) != 1L || is.na(reuse)) {
    reuse <- TRUE
  }
  isTRUE(reuse)
}

arrow_column_type_string <- function(dataset, column_name) {
  field <- tryCatch(dataset$schema$GetFieldByName(column_name), error = function(e) NULL)
  if (is.null(field)) {
    return("")
  }
  tryCatch(field$type$ToString(), error = function(e) "")
}

native_id_filter_values <- function(dataset, id_col, person_ids) {
  ids <- unique(as.character(person_ids))
  ids <- ids[!is.na(ids) & nzchar(ids)]
  if (!length(ids)) {
    return(ids)
  }

  id_type <- tolower(arrow_column_type_string(dataset, id_col))
  if (!grepl("int|uint", id_type)) {
    return(ids)
  }

  if (grepl("64", id_type) && requireNamespace("bit64", quietly = TRUE)) {
    values <- suppressWarnings(bit64::as.integer64(ids))
    return(values[!is.na(values)])
  }

  values <- suppressWarnings(as.numeric(ids))
  values[!is.na(values)]
}

filter_dataset_to_ids_native <- function(dataset, id_col, person_ids) {
  filter_values <- native_id_filter_values(dataset, id_col, person_ids)
  id_expr <- rlang::sym(id_col)
  dataset |> filter(!!id_expr %in% filter_values)
}

timed_parent_step <- function(label, expr) {
  start <- Sys.time()
  message(sprintf("    * %s...", label))
  result <- force(expr)
  elapsed <- as.numeric(difftime(Sys.time(), start, units = "secs"))
  message(sprintf("    * %s completed in %.1f seconds", label, elapsed))
  result
}

scan_popc_people <- function(path, requested_columns, person_ids) {
  id_table <- parent_id_filter_table(person_ids)
  if (!nrow(id_table)) {
    return(NULL)
  }

  dataset <- arrow::open_dataset(path, format = "parquet")
  available_columns <- names(dataset$schema)
  selected_columns <- intersect(unique(c("PNR", requested_columns)), available_columns)
  if (!("PNR" %in% selected_columns)) {
    stop(sprintf("%s does not contain PNR.", basename(path)))
  }

  pnr_expr <- rlang::sym("PNR")
  native_scan <- tryCatch(
    {
      dataset |>
        select(dplyr::all_of(selected_columns)) |>
        filter_dataset_to_ids_native("PNR", id_table$person_id) |>
        mutate(person_id = as.character(!!pnr_expr))
    },
    error = function(e) NULL
  )

  if (!is.null(native_scan)) {
    return(native_scan)
  }

  dataset |>
    select(dplyr::all_of(selected_columns)) |>
    mutate(person_id = as.character(!!pnr_expr)) |>
    inner_join(arrow::arrow_table(id_table), by = "person_id")
}

read_popc_people_columns <- function(path, requested_columns, person_ids) {
  id_table <- parent_id_filter_table(person_ids)
  if (!nrow(id_table)) {
    return(NULL)
  }

  dataset <- arrow::open_dataset(path, format = "parquet")
  available_columns <- names(dataset$schema)
  selected_columns <- intersect(unique(c("PNR", requested_columns)), available_columns)
  if (!("PNR" %in% selected_columns)) {
    stop(sprintf("%s does not contain PNR.", basename(path)))
  }

  df <- arrow::read_parquet(path, col_select = dplyr::all_of(selected_columns)) |>
    as.data.frame(stringsAsFactors = FALSE)
  df$person_id <- as.character(df$PNR)
  df[df$person_id %in% id_table$person_id, , drop = FALSE]
}

normalize_hfaudd_code <- function(code) {
  normalize_hfaudd_code_vec(code)[[1]]
}

normalize_hfaudd_code_vec <- function(code) {
  if (is.null(code)) {
    return(NA_character_)
  }
  safe_code <- suppressWarnings(iconv(as.character(code), from = "", to = "ASCII//TRANSLIT", sub = ""))
  digits <- gsub("[^0-9]", "", trimws(safe_code))
  digits[is.na(safe_code) | !nzchar(digits)] <- NA_character_
  digits
}

normalize_ascii_text <- function(value) {
  normalize_ascii_text_vec(value)[[1]]
}

normalize_ascii_text_vec <- function(value) {
  if (is.null(value)) {
    return(NA_character_)
  }
  safe_value <- suppressWarnings(iconv(as.character(value), from = "", to = "ASCII//TRANSLIT", sub = ""))
  result <- trimws(safe_value)
  result[is.na(safe_value)] <- NA_character_
  result
}

parse_uddf_validity_date <- function(value, default = as.Date(NA)) {
  parse_uddf_validity_date_vec(value, default = default)[[1]]
}

parse_uddf_validity_date_vec <- function(value, default = as.Date(NA)) {
  if (is.null(value)) {
    return(as.Date(character()))
  }
  if (inherits(value, "Date")) {
    return(value)
  }

  text_value <- trimws(as.character(value))
  result <- rep(as.Date(default), length(text_value))
  missing <- is.na(text_value) | !nzchar(text_value)

  parsed <- suppressWarnings(as.Date(text_value))
  parsed_ok <- !missing & !is.na(parsed)
  result[parsed_ok] <- parsed[parsed_ok]

  unresolved <- !missing & is.na(parsed)
  if (any(unresolved)) {
    unresolved_idx <- which(unresolved)
    digits <- gsub("[^0-9]", "", text_value[unresolved])
    has_yyyymmdd <- nchar(digits) >= 8L
    if (any(has_yyyymmdd)) {
      parsed_digits <- suppressWarnings(as.Date(
        substr(digits[has_yyyymmdd], 1L, 8L),
        format = "%Y%m%d"
      ))
      parsed_digits_ok <- !is.na(parsed_digits)
      result[unresolved_idx[has_yyyymmdd][parsed_digits_ok]] <- parsed_digits[parsed_digits_ok]
    }
  }

  result
}

hfaudd_isced_map <- local({
  cache <- NULL

  function(json_path) {
    if (!is.null(cache)) {
      return(cache)
    }
    if (!file.exists(json_path)) {
      cache <<- setNames(character(), character())
      return(cache)
    }

    parsed <- jsonlite::read_json(json_path, simplifyVector = TRUE)
    mapping <- unlist(parsed, use.names = TRUE)
    names(mapping) <- vapply(names(mapping), normalize_hfaudd_code, character(1))
    mapping <- mapping[!is.na(names(mapping)) & nzchar(names(mapping))]
    cache <<- mapping
    cache
  }
})

hfaudd_main_group_map <- local({
  cache <- list()

  function(asset_path) {
    if (is.null(asset_path) || length(asset_path) != 1L || is.na(asset_path) || !nzchar(asset_path) ||
        !file.exists(asset_path)) {
      return(setNames(character(), character()))
    }

    normalized_path <- normalizePath(asset_path, winslash = "/", mustWork = FALSE)
    if (!is.null(cache[[normalized_path]])) {
      return(cache[[normalized_path]])
    }

    lines <- readLines(normalized_path, warn = FALSE, encoding = "UTF-8")
    matches <- regexec("^\\s*([0-9]+)\\s*=\\s*'([0-9]+)'\\s*$", lines)
    parsed <- regmatches(lines, matches)
    parsed <- parsed[lengths(parsed) == 3L]
    if (!length(parsed)) {
      mapping <- setNames(character(), character())
      cache[[normalized_path]] <<- mapping
      return(mapping)
    }

    codes <- vapply(parsed, function(x) normalize_hfaudd_code(x[[2]]), character(1))
    groups <- vapply(parsed, function(x) normalize_hfaudd_code(x[[3]]), character(1))
    valid <- !is.na(codes) & nzchar(codes) & !is.na(groups) & nzchar(groups)
    mapping <- stats::setNames(groups[valid], codes[valid])
    cache[[normalized_path]] <<- mapping
    mapping
  }
})

resolve_isced_code <- function(code, hfaudd_json_path) {
  resolve_isced_code_vec(code, hfaudd_json_path)[[1]]
}

resolve_isced_code_vec <- function(code, hfaudd_json_path) {
  normalized <- normalize_hfaudd_code_vec(code)
  mapping <- hfaudd_isced_map(hfaudd_json_path)
  result <- rep(NA_character_, length(normalized))
  if (!length(mapping) || !length(normalized)) {
    return(result)
  }

  candidates <- list(
    normalized,
    ifelse(!is.na(normalized) & nchar(normalized) >= 4L, substr(normalized, 1L, 3L), NA_character_),
    ifelse(!is.na(normalized) & nchar(normalized) >= 3L, substr(normalized, 1L, 2L), NA_character_)
  )

  for (candidate in candidates) {
    unresolved <- is.na(result) & !is.na(candidate) & nzchar(candidate)
    if (!any(unresolved)) {
      next
    }
    matched <- unname(mapping[candidate[unresolved]])
    result[unresolved] <- ifelse(is.na(matched), result[unresolved], as.character(matched))
  }

  result
}

resolve_hfaudd_main_group_vec <- function(code, education_asset_path = NULL) {
  normalized <- normalize_hfaudd_code_vec(code)
  mapping <- hfaudd_main_group_map(education_asset_path)
  result <- rep(NA_character_, length(normalized))
  if (!length(mapping) || !length(normalized)) {
    return(result)
  }

  candidates <- list(
    normalized,
    ifelse(!is.na(normalized) & nchar(normalized) >= 4L, substr(normalized, 1L, 3L), NA_character_),
    ifelse(!is.na(normalized) & nchar(normalized) >= 3L, substr(normalized, 1L, 2L), NA_character_)
  )

  for (candidate in candidates) {
    unresolved <- is.na(result) & !is.na(candidate) & nzchar(candidate)
    if (!any(unresolved)) {
      next
    }
    matched <- unname(mapping[candidate[unresolved]])
    result[unresolved] <- ifelse(is.na(matched), result[unresolved], as.character(matched))
  }

  result
}

isced_rank <- function(isced_code) {
  value <- suppressWarnings(as.integer(isced_code))
  if (is.na(value)) {
    return(-1L)
  }
  value
}

classify_education_level_label <- function(hfaudd, hf_kilde, hfaudd_json_path, education_asset_path = NULL) {
  classify_education_level_label_vec(hfaudd, hf_kilde, hfaudd_json_path, education_asset_path)[[1]]
}

classify_education_level_label_vec <- function(hfaudd, hf_kilde, hfaudd_json_path, education_asset_path = NULL) {
  no_education_sources <- c("9", "10", "18")
  no_education_codes <- c("90", "9000", "9999")
  middle_school_codes <- c("1021", "1022", "1023", "1121", "1122", "1123", "1423", "1522", "1523", "1721", "1722", "1723")
  aggregate_short_codes <- c("10", "15")
  aggregate_medium_codes <- c("20", "30", "35")
  aggregate_long_codes <- c("40", "50", "60", "70", "80")

  code <- normalize_hfaudd_code_vec(hfaudd)
  source_code <- normalize_ascii_text_vec(hf_kilde %||% rep("", length(code)))
  result <- rep("no_completed_or_missing", length(code))

  explicit_no_education <- !is.na(source_code) & nzchar(source_code) & source_code %in% no_education_sources
  code_missing <- is.na(code) | code %in% no_education_codes
  eligible <- !explicit_no_education & !code_missing

  result[eligible & code %in% c(middle_school_codes, aggregate_medium_codes)] <- "medium"
  result[eligible & code %in% aggregate_short_codes] <- "short"
  result[eligible & code %in% aggregate_long_codes] <- "long"

  unresolved <- eligible & result == "no_completed_or_missing"
  if (any(unresolved)) {
    main_group <- resolve_hfaudd_main_group_vec(code[unresolved], education_asset_path)
    unresolved_idx <- which(unresolved)
    result[unresolved_idx[!is.na(main_group) & main_group %in% aggregate_short_codes]] <- "short"
    result[unresolved_idx[!is.na(main_group) & main_group %in% aggregate_medium_codes]] <- "medium"
    result[unresolved_idx[!is.na(main_group) & main_group %in% aggregate_long_codes]] <- "long"
  }

  unresolved <- eligible & result == "no_completed_or_missing"
  if (any(unresolved)) {
    isced_code <- resolve_isced_code_vec(code[unresolved], hfaudd_json_path)
    unresolved_idx <- which(unresolved)
    result[unresolved_idx[!is.na(isced_code) & isced_code %in% c("5", "6", "7", "8")]] <- "long"
    result[unresolved_idx[!is.na(isced_code) & isced_code == "4"]] <- "medium"
    result[unresolved_idx[!is.na(isced_code) & isced_code %in% c("0", "1", "2", "3")]] <- "short"
  }

  result
}

education_rank <- function(label) {
  match(label, c("no_completed_or_missing", "short", "medium", "long")) - 1L
}

combine_parent_education_label <- function(mother, father) {
  combine_parent_education_label_vec(mother, father)[[1]]
}

combine_parent_education_label_vec <- function(mother, father) {
  values <- c(mother, father)
  mother_rank <- education_rank(mother)
  father_rank <- education_rank(father)
  mother_rank[is.na(mother_rank)] <- -1L
  father_rank[is.na(father_rank)] <- -1L
  result <- ifelse(mother_rank >= father_rank, mother, father)
  result[is.na(result)] <- "no_completed_or_missing"
  result
}

map_akm_socio_status_to_group_vec <- function(codes) {
  value  <- suppressWarnings(as.integer(trimws(as.character(codes))))
  result <- rep("missing_other", length(codes))
  result[!is.na(value) & ((value >= 110L & value <= 114L) | value == 120L |
    (value >= 131L & value <= 135L) | value == 139L | value == 310L)] <- "working_studying"
  result[!is.na(value) & (value == 210L | value == 410L)]             <- "temporarily_out"
  result[!is.na(value) & (value == 330L | value == 220L | value == 321L)] <- "outside_workforce"
  result[!is.na(value) & (value == 322L | value == 323L)]             <- "retired"
  result
}

combine_parent_socio_label <- function(mother, father) {
  combine_parent_socio_label_vec(mother, father)[[1]]
}

combine_parent_socio_label_vec <- function(mother, father) {
  result <- rep("missing_other", length(mother))
  result[mother %in% "retired" | father %in% "retired"] <- "retired"
  result[mother %in% "outside_workforce" | father %in% "outside_workforce"] <- "outside_workforce"
  result[mother %in% "temporarily_out" | father %in% "temporarily_out"] <- "temporarily_out"
  result[mother %in% "working_studying" | father %in% "working_studying"] <- "working_studying"
  result
}

load_akm_lookup <- function(config, person_ids, min_year, max_year) {
  if (is.na(min_year) || is.na(max_year)) {
    return(data.frame(person_id = character(), year = integer(), socio_group = character()))
  }

  paths <- find_popc_files(config$raw_popc_dir, "akm")
  if (!length(paths)) {
    return(data.frame(person_id = character(), year = integer(), socio_group = character()))
  }

  years <- vapply(paths, parse_year_from_path, integer(1), prefix = "akm")
  keep <- !is.na(years) & years >= min_year & years <= max_year
  paths <- paths[keep]
  years <- years[keep]
  if (!length(paths)) {
    return(data.frame(person_id = character(), year = integer(), socio_group = character()))
  }

  rows <- vector("list", length(paths))
  for (i in seq_along(paths)) {
    scan <- scan_popc_people(paths[[i]], c("SOCIO13", "SOCIO02", "SOCIO"), person_ids)
    if (is.null(scan)) {
      rows[[i]] <- data.frame(person_id = character(), year = integer(), socio_group = character())
      next
    }

    df <- scan |>
      collect() |>
      as.data.frame(stringsAsFactors = FALSE)
    if (!nrow(df)) {
      rows[[i]] <- data.frame(person_id = character(), year = integer(), socio_group = character())
      next
    }

    for (col in c("SOCIO13", "SOCIO02", "SOCIO")) {
      if (!(col %in% names(df))) {
        df[[col]] <- NA
      }
    }

    df <- df |>
      transmute(
        person_id,
        socio_code = dplyr::coalesce(SOCIO13, SOCIO02, SOCIO)
      ) |>
      mutate(
        year = years[[i]],
        socio_group = map_akm_socio_status_to_group_vec(socio_code)
      ) |>
      select(person_id, year, socio_group)
    rows[[i]] <- df
  }

  bind_rows(rows)
}

load_bef_origin_lookup <- function(config, person_ids, min_year, max_year) {
  empty <- data.frame(
    person_id = character(),
    year = integer(),
    snapshot_date = as.Date(character()),
    origin_country = character(),
    stringsAsFactors = FALSE
  )
  if (is.na(min_year) || is.na(max_year)) {
    return(empty)
  }

  paths <- find_popc_files(config$raw_popc_dir, "bef")
  if (!length(paths)) {
    warning(
      "No BEF files found under raw_popc_dir; ethnicity grouping will use child OPR_LAND/IE_TYPE without parent-origin refinement.",
      call. = FALSE
    )
    return(empty)
  }

  years <- vapply(paths, parse_year_from_path, integer(1), prefix = "bef")
  snapshot_dates <- as.Date(vapply(paths, parse_snapshot_date_from_path, as.Date(NA), prefix = "bef"))
  keep <- !is.na(years) & years >= min_year & years <= max_year
  paths <- paths[keep]
  years <- years[keep]
  snapshot_dates <- snapshot_dates[keep]
  if (!length(paths)) {
    return(empty)
  }

  rows <- vector("list", length(paths))
  for (i in seq_along(paths)) {
    scan <- scan_popc_people(paths[[i]], c("OPR_LAND"), person_ids)
    if (is.null(scan)) {
      rows[[i]] <- empty
      next
    }

    df <- scan |>
      collect() |>
      as.data.frame(stringsAsFactors = FALSE)
    if (!("OPR_LAND" %in% names(df))) {
      stop(sprintf("%s is missing required BEF column: OPR_LAND", basename(paths[[i]])))
    }
    if (!nrow(df)) {
      rows[[i]] <- empty
      next
    }

    rows[[i]] <- df |>
      transmute(
        person_id,
        year = years[[i]],
        snapshot_date = snapshot_dates[[i]],
        origin_country = as.character(OPR_LAND)
      ) |>
      distinct(person_id, year, snapshot_date, origin_country)
  }

  bind_rows(rows) |>
    distinct(person_id, year, snapshot_date, origin_country)
}

load_uddf_lookup <- function(config, person_ids, min_year, max_year) {
  empty <- data.frame(
    person_id = character(),
    hfaudd = character(),
    hf_kilde = character(),
    valid_from = as.Date(character()),
    valid_to = as.Date(character()),
    education_group = character(),
    isced_code = character(),
    stringsAsFactors = FALSE
  )
  paths <- find_popc_files(config$raw_popc_dir, "uddf")
  if (!length(paths)) {
    return(empty)
  }
  paths <- select_latest_popc_snapshot_files(paths, "uddf")

  # UDDF files are commonly delivered as extract snapshots, e.g. uddf/202409.parquet,
  # where the file date is not the education event year. Validity dates inside the
  # file determine eligibility by index date, so keep only the latest snapshot.
  rows <- vector("list", length(paths))
  for (i in seq_along(paths)) {
    df <- tryCatch(
      read_popc_people_columns(paths[[i]], c("HFAUDD", "HF_KILDE", "HF_VFRA", "HF_VTIL"), person_ids),
      error = function(e) {
        scan <- scan_popc_people(paths[[i]], c("HFAUDD", "HF_KILDE", "HF_VFRA", "HF_VTIL"), person_ids)
        if (is.null(scan)) {
          return(NULL)
        }
        scan |>
          collect() |>
          as.data.frame(stringsAsFactors = FALSE)
      }
    )
    if (is.null(df)) {
      rows[[i]] <- empty
      next
    }
    missing_columns <- setdiff(c("HFAUDD", "HF_KILDE", "HF_VFRA", "HF_VTIL"), names(df))
    if (length(missing_columns)) {
      stop(sprintf(
        "%s is missing required UDDF columns: %s",
        basename(paths[[i]]),
        paste(missing_columns, collapse = ", ")
      ))
    }

    df <- df |>
      transmute(
        person_id,
        hfaudd = as.character(HFAUDD),
        hf_kilde = as.character(HF_KILDE),
        hf_vfra = HF_VFRA,
        hf_vtil = HF_VTIL
      )

    if (!nrow(df)) {
      rows[[i]] <- empty
      next
    }

    education_group <- classify_education_level_label_vec(
      df$hfaudd,
      df$hf_kilde,
      hfaudd_json_path = config$hfaudd_json_path,
      education_asset_path = config$education_asset_path
    )
    isced_code <- resolve_isced_code_vec(
      df$hfaudd,
      hfaudd_json_path = config$hfaudd_json_path
    )

    df <- df |>
      transmute(
        person_id,
        hfaudd,
        hf_kilde,
        valid_from = parse_uddf_validity_date_vec(hf_vfra),
        valid_to = parse_uddf_validity_date_vec(hf_vtil),
        education_group = education_group,
        isced_code = isced_code
      ) |>
      distinct(person_id, hfaudd, hf_kilde, valid_from, valid_to, education_group, isced_code)
    rows[[i]] <- df
  }

  bind_rows(rows) |>
    distinct(person_id, hfaudd, hf_kilde, valid_from, valid_to, education_group, isced_code)
}

latest_group_for_parent <- function(parent_id, baseline_year, lookup_df, value_col) {
  if (is.na(parent_id) || !nzchar(parent_id)) {
    return(NA_character_)
  }
  rows <- lookup_df[lookup_df$person_id == parent_id & lookup_df$year <= baseline_year, , drop = FALSE]
  if (!nrow(rows)) {
    return(NA_character_)
  }
  rows[[value_col]][[which.max(rows$year)]]
}

highest_attained_group_for_parent <- function(parent_id, index_date, lookup_df, value_col = "education_group") {
  if (is.na(parent_id) || !nzchar(parent_id)) {
    return(NA_character_)
  }
  index_date <- as.Date(index_date)
  if (is.na(index_date)) {
    return(NA_character_)
  }
  rows <- lookup_df[
    lookup_df$person_id == parent_id &
      !is.na(lookup_df$valid_from) &
      lookup_df$valid_from <= index_date &
      (is.na(lookup_df$valid_to) | lookup_df$valid_to >= index_date),
    ,
    drop = FALSE
  ]
  if (!nrow(rows)) {
    rows <- lookup_df[
      lookup_df$person_id == parent_id &
        !is.na(lookup_df$valid_from) &
        lookup_df$valid_from <= index_date,
      ,
      drop = FALSE
    ]
  }
  if (!nrow(rows)) {
    return(NA_character_)
  }
  if (!("isced_code" %in% names(rows))) {
    rows <- rows[order(rows$valid_from), , drop = FALSE]
    return(rows[[value_col]][[nrow(rows)]])
  }

  score <- vapply(rows$isced_code, isced_rank, integer(1))
  valid_from_ord <- as.numeric(rows$valid_from)
  valid_from_ord[is.na(valid_from_ord)] <- -Inf
  order_idx <- order(score, valid_from_ord, na.last = TRUE)
  rows[[value_col]][[order_idx[[length(order_idx)]]]]
}

# Pre-indexed variants: accept already-subsetted rows for a single parent (or NULL).
latest_group_for_parent_rows <- function(rows, baseline_year, value_col) {
  if (is.null(rows) || !nrow(rows)) return(NA_character_)
  rows <- rows[rows$year <= baseline_year, , drop = FALSE]
  if (!nrow(rows)) return(NA_character_)
  rows[[value_col]][[which.max(rows$year)]]
}

highest_attained_group_for_parent_rows <- function(rows, index_date, value_col = "education_group") {
  if (is.null(rows) || !nrow(rows)) return(NA_character_)
  index_date <- as.Date(index_date)
  if (is.na(index_date)) return(NA_character_)
  active <- rows[
    !is.na(rows$valid_from) &
      rows$valid_from <= index_date &
      (is.na(rows$valid_to) | rows$valid_to >= index_date),
    ,
    drop = FALSE
  ]
  if (!nrow(active)) {
    active <- rows[!is.na(rows$valid_from) & rows$valid_from <= index_date, , drop = FALSE]
  }
  if (!nrow(active)) return(NA_character_)
  if (!("isced_code" %in% names(active))) {
    return(active[[value_col]][[which.max(as.numeric(active$valid_from))]])
  }
  score          <- vapply(active$isced_code, isced_rank, integer(1))
  valid_from_ord <- as.numeric(active$valid_from)
  valid_from_ord[is.na(valid_from_ord)] <- -Inf
  order_idx      <- order(score, valid_from_ord, na.last = TRUE)
  active[[value_col]][[order_idx[[length(order_idx)]]]]
}

build_parent_role_rows <- function(baseline_df, index_dates, baseline_years) {
  base_rows <- data.frame(
    row_id = seq_len(nrow(baseline_df)),
    index_date = as.Date(index_dates),
    baseline_year = baseline_years,
    mother_id = as.character(baseline_df$mother_id),
    father_id = as.character(baseline_df$father_id),
    stringsAsFactors = FALSE
  )

  bind_rows(
    data.frame(
      row_id = base_rows$row_id,
      role = "mother",
      parent_id = base_rows$mother_id,
      index_date = base_rows$index_date,
      baseline_year = base_rows$baseline_year,
      stringsAsFactors = FALSE
    ),
    data.frame(
      row_id = base_rows$row_id,
      role = "father",
      parent_id = base_rows$father_id,
      index_date = base_rows$index_date,
      baseline_year = base_rows$baseline_year,
      stringsAsFactors = FALSE
    )
  ) |>
    filter(!is.na(parent_id), nzchar(parent_id))
}

select_latest_parent_socio <- function(parent_role_rows, akm_lookup) {
  if (!nrow(parent_role_rows) || !nrow(akm_lookup)) {
    return(data.frame(
      row_id = integer(),
      role = character(),
      socio_group = character(),
      stringsAsFactors = FALSE
    ))
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt_roles <- data.table::as.data.table(parent_role_rows)
    dt_roles[, parent_id := as.character(parent_id)]
    dt_roles[, baseline_year := as.integer(baseline_year)]
    dt_keys <- unique(dt_roles[
      !is.na(parent_id) & nzchar(parent_id) & !is.na(baseline_year),
      list(parent_id, baseline_year)
    ])
    dt_lookup <- data.table::as.data.table(akm_lookup)
    dt_lookup[, person_id := as.character(person_id)]
    dt_lookup[, year := as.integer(year)]
    data.table::setkey(dt_lookup, person_id, year)
    selected <- dt_lookup[
      dt_keys,
      on = c("person_id" = "parent_id", "year" = "baseline_year"),
      roll = Inf,
      mult = "last"
    ][!is.na(socio_group), list(parent_id = person_id, baseline_year = year, socio_group)]
    if (!nrow(selected)) {
      return(data.frame(row_id = integer(), role = character(), socio_group = character(), stringsAsFactors = FALSE))
    }
    result <- selected[
      dt_roles,
      on = c("parent_id", "baseline_year")
    ][!is.na(socio_group), list(row_id, role, socio_group)]
    return(as.data.frame(result, stringsAsFactors = FALSE))
  }

  keys <- parent_role_rows |>
    transmute(parent_id = as.character(parent_id), baseline_year = as.integer(baseline_year)) |>
    filter(!is.na(parent_id), nzchar(parent_id), !is.na(baseline_year)) |>
    distinct()

  selected_keys <- keys |>
    inner_join(akm_lookup, by = c("parent_id" = "person_id"), relationship = "many-to-many") |>
    filter(!is.na(year), year <= baseline_year) |>
    group_by(parent_id, baseline_year) |>
    slice_max(year, n = 1, with_ties = FALSE) |>
    ungroup() |>
    transmute(parent_id, baseline_year, socio_group) |>
    as.data.frame(stringsAsFactors = FALSE)

  if (!nrow(selected_keys)) {
    return(data.frame(row_id = integer(), role = character(), socio_group = character(), stringsAsFactors = FALSE))
  }

  parent_role_rows |>
    mutate(parent_id = as.character(parent_id), baseline_year = as.integer(baseline_year)) |>
    left_join(selected_keys, by = c("parent_id", "baseline_year")) |>
    filter(!is.na(socio_group)) |>
    transmute(row_id, role, socio_group) |>
    as.data.frame(stringsAsFactors = FALSE)
}

select_latest_parent_origin <- function(parent_role_rows, bef_origin_lookup) {
  if (!nrow(parent_role_rows) || !nrow(bef_origin_lookup)) {
    return(data.frame(
      row_id = integer(),
      role = character(),
      origin_country = character(),
      stringsAsFactors = FALSE
    ))
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt_roles <- data.table::as.data.table(parent_role_rows)
    dt_roles[, parent_id := as.character(parent_id)]
    dt_roles[, baseline_year := as.integer(baseline_year)]
    dt_roles[, index_date := as.Date(index_date)]
    dt_keys <- unique(dt_roles[
      !is.na(parent_id) & nzchar(parent_id) & !is.na(baseline_year),
      list(parent_id, baseline_year, index_date)
    ])
    dt_lookup <- data.table::as.data.table(bef_origin_lookup)
    dt_lookup[, person_id := as.character(person_id)]
    dt_lookup[, year := as.integer(year)]
    if (!("snapshot_date" %in% names(dt_lookup))) {
      dt_lookup[, snapshot_date := as.Date(NA)]
    }
    dt_lookup[, snapshot_date := as.Date(snapshot_date)]
    dt_lookup[, lookup_year := year]
    joined <- dt_lookup[
      dt_keys,
      on = c("person_id==parent_id", "year<=baseline_year"),
      allow.cartesian = TRUE,
      nomatch = 0
    ]
    if (!nrow(joined)) {
      return(data.frame(row_id = integer(), role = character(), origin_country = character(), stringsAsFactors = FALSE))
    }
    joined <- joined[is.na(snapshot_date) | is.na(index_date) | snapshot_date <= index_date]
    if (!nrow(joined)) {
      return(data.frame(row_id = integer(), role = character(), origin_country = character(), stringsAsFactors = FALSE))
    }
    data.table::setorder(joined, person_id, year, index_date, lookup_year, snapshot_date)
    selected <- joined[
      ,
      .SD[.N],
      by = c("person_id", "year", "index_date")
    ][, list(parent_id = person_id, baseline_year = year, index_date, origin_country)]
    result <- selected[
      dt_roles,
      on = c("parent_id", "baseline_year", "index_date")
    ][!is.na(origin_country), list(row_id, role, origin_country)]
    return(as.data.frame(result, stringsAsFactors = FALSE))
  }

  lookup <- bef_origin_lookup
  if (!("snapshot_date" %in% names(lookup))) {
    lookup$snapshot_date <- as.Date(NA)
  }
  lookup$snapshot_date <- as.Date(lookup$snapshot_date)

  keys <- parent_role_rows |>
    transmute(
      parent_id = as.character(parent_id),
      baseline_year = as.integer(baseline_year),
      index_date = as.Date(index_date)
    ) |>
    filter(!is.na(parent_id), nzchar(parent_id), !is.na(baseline_year)) |>
    distinct()

  selected_keys <- keys |>
    inner_join(lookup, by = c("parent_id" = "person_id"), relationship = "many-to-many") |>
    filter(!is.na(year), year <= baseline_year) |>
    filter(is.na(snapshot_date) | is.na(index_date) | snapshot_date <= index_date) |>
    group_by(parent_id, baseline_year, index_date) |>
    arrange(year, snapshot_date, .by_group = TRUE) |>
    slice_tail(n = 1L) |>
    ungroup() |>
    transmute(parent_id, baseline_year, index_date, origin_country) |>
    as.data.frame(stringsAsFactors = FALSE)

  if (!nrow(selected_keys)) {
    return(data.frame(row_id = integer(), role = character(), origin_country = character(), stringsAsFactors = FALSE))
  }

  parent_role_rows |>
    mutate(
      parent_id = as.character(parent_id),
      baseline_year = as.integer(baseline_year),
      index_date = as.Date(index_date)
    ) |>
    left_join(selected_keys, by = c("parent_id", "baseline_year", "index_date")) |>
    filter(!is.na(origin_country)) |>
    transmute(row_id, role, origin_country) |>
    as.data.frame(stringsAsFactors = FALSE)
}

select_highest_parent_education <- function(parent_role_rows, uddf_lookup) {
  if (!nrow(parent_role_rows) || !nrow(uddf_lookup)) {
    return(data.frame(
      row_id = integer(),
      role = character(),
      education_group = character(),
      stringsAsFactors = FALSE
    ))
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt_roles <- data.table::as.data.table(parent_role_rows)
    dt_roles[, parent_id := as.character(parent_id)]
    dt_roles[, index_date := as.Date(index_date)]
    dt_keys <- unique(dt_roles[
      !is.na(parent_id) & nzchar(parent_id) & !is.na(index_date),
      list(parent_id, index_date)
    ])
    dt_lookup <- data.table::as.data.table(uddf_lookup)
    dt_lookup[, person_id := as.character(person_id)]
    dt_lookup[, valid_from := as.Date(valid_from)]
    dt_lookup[, valid_to := as.Date(valid_to)]
    dt_lookup[, valid_from_orig := valid_from]
    joined <- dt_lookup[
      dt_keys,
      on = c("person_id==parent_id", "valid_from<=index_date"),
      allow.cartesian = TRUE,
      nomatch = 0
    ]
    if (!nrow(joined)) {
      return(data.frame(row_id = integer(), role = character(), education_group = character(), stringsAsFactors = FALSE))
    }
    joined[, index_date := valid_from]
    joined[, active_now := is.na(valid_to) | valid_to >= index_date]
    joined[, valid_from_num := as.numeric(valid_from_orig)]
    joined[is.na(valid_from_num), valid_from_num := -Inf]
    joined[, isced_score := vapply(isced_code, isced_rank, integer(1))]
    joined[, has_active_now := any(active_now), by = c("person_id", "index_date")]
    joined <- joined[active_now | !has_active_now]
    if (!nrow(joined)) {
      return(data.frame(row_id = integer(), role = character(), education_group = character(), stringsAsFactors = FALSE))
    }
    data.table::setorder(joined, person_id, index_date, isced_score, valid_from_num)
    selected <- joined[
      ,
      .SD[.N],
      by = c("person_id", "index_date")
    ][, list(parent_id = person_id, index_date, education_group)]
    result <- selected[
      dt_roles,
      on = c("parent_id", "index_date")
    ][!is.na(education_group), list(row_id, role, education_group)]
    return(as.data.frame(result, stringsAsFactors = FALSE))
  }

  keys <- parent_role_rows |>
    transmute(parent_id = as.character(parent_id), index_date = as.Date(index_date)) |>
    filter(!is.na(parent_id), nzchar(parent_id), !is.na(index_date)) |>
    distinct()

  joined <- keys |>
    inner_join(uddf_lookup, by = c("parent_id" = "person_id"), relationship = "many-to-many") |>
    mutate(
      valid_from_num = as.numeric(valid_from),
      active_now = !is.na(valid_from) & valid_from <= index_date & (is.na(valid_to) | valid_to >= index_date),
      historical_ok = !is.na(valid_from) & valid_from <= index_date
    ) |>
    filter(active_now | historical_ok)

  if (!nrow(joined)) {
    return(data.frame(row_id = integer(), role = character(), education_group = character(), stringsAsFactors = FALSE))
  }

  selected_keys <- joined |>
    group_by(parent_id, index_date) |>
    mutate(
      has_active_now = any(active_now),
      use_row = if_else(has_active_now, active_now, historical_ok),
      isced_score = vapply(isced_code, isced_rank, integer(1))
    ) |>
    filter(use_row) |>
    arrange(isced_score, valid_from_num, .by_group = TRUE) |>
    slice_tail(n = 1L) |>
    ungroup() |>
    transmute(parent_id, index_date, education_group) |>
    as.data.frame(stringsAsFactors = FALSE)

  parent_role_rows |>
    mutate(parent_id = as.character(parent_id), index_date = as.Date(index_date)) |>
    left_join(selected_keys, by = c("parent_id", "index_date")) |>
    filter(!is.na(education_group)) |>
    transmute(row_id, role, education_group) |>
    as.data.frame(stringsAsFactors = FALSE)
}

select_parent_uddf_presence <- function(parent_role_rows, uddf_lookup) {
  if (!nrow(parent_role_rows) || !nrow(uddf_lookup)) {
    return(data.frame(
      row_id = integer(),
      role = character(),
      has_uddf_by_index = logical(),
      stringsAsFactors = FALSE
    ))
  }

  parent_role_rows |>
    inner_join(uddf_lookup, by = c("parent_id" = "person_id"), relationship = "many-to-many") |>
    group_by(row_id, role) |>
    summarise(
      has_uddf_by_index = any(!is.na(valid_from) & valid_from <= index_date),
      .groups = "drop"
    ) |>
    as.data.frame(stringsAsFactors = FALSE)
}

parent_context_from_baseline <- function(baseline_df) {
  parent_ids <- unique(c(baseline_df$mother_id, baseline_df$father_id))
  parent_ids <- parent_ids[!is.na(parent_ids) & nzchar(parent_ids)]
  index_dates <- as.Date(baseline_df$index_date)

  baseline_end <- if ("baseline_end" %in% names(baseline_df)) {
    as.Date(baseline_df$baseline_end)
  } else {
    rep(as.Date(NA), nrow(baseline_df))
  }
  baseline_reference <- baseline_end
  missing_reference <- is.na(baseline_reference)
  baseline_reference[missing_reference] <- index_dates[missing_reference] - 1L
  baseline_years <- as.integer(format(baseline_reference, "%Y"))
  index_years <- as.integer(format(index_dates, "%Y"))
  valid_baseline_years <- baseline_years[!is.na(baseline_years)]
  valid_index_years <- index_years[!is.na(index_years)]

  list(
    parent_ids = parent_ids,
    index_dates = index_dates,
    index_years = index_years,
    baseline_years = baseline_years,
    min_akm_year = if (length(valid_baseline_years)) min(valid_baseline_years) else NA_integer_,
    max_akm_year = if (length(valid_baseline_years)) max(valid_baseline_years) else NA_integer_,
    min_origin_year = if (length(valid_index_years)) min(valid_index_years) else NA_integer_,
    max_origin_year = if (length(valid_index_years)) max(valid_index_years) else NA_integer_
  )
}

reclassify_uddf_lookup <- function(uddf_lookup, config) {
  uddf_lookup <- as.data.frame(uddf_lookup, stringsAsFactors = FALSE)
  if (!nrow(uddf_lookup) || !all(c("hfaudd", "hf_kilde") %in% names(uddf_lookup))) {
    return(uddf_lookup)
  }

  uddf_lookup$hfaudd <- as.character(uddf_lookup$hfaudd)
  uddf_lookup$hf_kilde <- as.character(uddf_lookup$hf_kilde)
  uddf_lookup$education_group <- classify_education_level_label_vec(
    uddf_lookup$hfaudd,
    uddf_lookup$hf_kilde,
    hfaudd_json_path = config$hfaudd_json_path,
    education_asset_path = config$education_asset_path
  )
  uddf_lookup$isced_code <- resolve_isced_code_vec(
    uddf_lookup$hfaudd,
    hfaudd_json_path = config$hfaudd_json_path
  )
  uddf_lookup
}

parent_cache_required_paths <- function(config, include_akm = TRUE, include_uddf = TRUE) {
  paths <- c(output_file(config, "parent_lookup_ids_cache"))
  if (isTRUE(include_akm)) {
    paths <- c(paths, output_file(config, "parent_akm_lookup_cache"), output_file(config, "parent_lookup_metadata"))
  }
  if (isTRUE(include_uddf)) {
    paths <- c(paths, output_file(config, "parent_uddf_lookup_cache"))
  }
  paths
}

parent_ids_cache_covers <- function(config, parent_ids) {
  path <- output_file(config, "parent_lookup_ids_cache")
  if (!file.exists(path)) {
    return(FALSE)
  }
  cached <- tryCatch(arrow::read_parquet(path), error = function(e) NULL)
  if (is.null(cached) || !("parent_id" %in% names(cached))) {
    return(FALSE)
  }
  !length(setdiff(parent_ids, cached$parent_id))
}

parent_uddf_lookup_cache_has_raw_columns <- function(config) {
  path <- output_file(config, "parent_uddf_lookup_cache")
  if (!file.exists(path)) {
    return(FALSE)
  }
  dataset <- tryCatch(arrow::open_dataset(path, format = "parquet"), error = function(e) NULL)
  if (is.null(dataset)) {
    return(FALSE)
  }
  all(c("hfaudd", "hf_kilde") %in% names(dataset$schema))
}

parent_lookup_metadata_covers <- function(config, min_akm_year, max_akm_year) {
  metadata_path <- output_file(config, "parent_lookup_metadata")
  if (!file.exists(metadata_path)) {
    return(FALSE)
  }
  metadata <- tryCatch(utils::read.csv(metadata_path, stringsAsFactors = FALSE), error = function(e) NULL)
  required <- c("min_akm_year", "max_akm_year", "raw_popc_dir")
  if (is.null(metadata) || !nrow(metadata) || !all(required %in% names(metadata))) {
    return(FALSE)
  }
  if (!identical(as.character(metadata$raw_popc_dir[[1]]), as.character(config$raw_popc_dir))) {
    return(FALSE)
  }

  uddf_lookup_schema <- if ("uddf_lookup_schema" %in% names(metadata)) {
    as.character(metadata$uddf_lookup_schema[[1]])
  } else {
    "derived_uddf_v1"
  }
  if (!identical(uddf_lookup_schema, "raw_uddf_v2")) {
    required_derived_fields <- c("hfaudd_json_path", "education_asset_path")
    if (!all(required_derived_fields %in% names(metadata))) {
      return(FALSE)
    }
    if (!identical(as.character(metadata$hfaudd_json_path[[1]]), as.character(config$hfaudd_json_path))) {
      return(FALSE)
    }
    if (!identical(as.character(metadata$education_asset_path[[1]]), as.character(config$education_asset_path))) {
      return(FALSE)
    }
  }
  cached_min <- suppressWarnings(as.integer(metadata$min_akm_year[[1]]))
  cached_max <- suppressWarnings(as.integer(metadata$max_akm_year[[1]]))
  if (is.na(min_akm_year) || is.na(max_akm_year)) {
    return(TRUE)
  }
  !is.na(cached_min) && !is.na(cached_max) && cached_min <= min_akm_year && cached_max >= max_akm_year
}

parent_lookup_cache_valid <- function(config, parent_ids, min_akm_year, max_akm_year) {
  if (!prepared_baseline_cache_enabled(config)) {
    return(FALSE)
  }
  paths <- parent_cache_required_paths(config, include_akm = TRUE, include_uddf = TRUE)
  if (!all(file.exists(paths))) {
    return(FALSE)
  }
  if (isTRUE(config$force_rebuild_parent_covariates) &&
      !parent_uddf_lookup_cache_has_raw_columns(config)) {
    return(FALSE)
  }
  parent_ids_cache_covers(config, parent_ids) &&
    parent_lookup_metadata_covers(config, min_akm_year, max_akm_year)
}

parent_uddf_cache_valid <- function(config, parent_ids) {
  if (!prepared_baseline_cache_enabled(config)) {
    return(FALSE)
  }
  paths <- parent_cache_required_paths(config, include_akm = FALSE, include_uddf = TRUE)
  all(file.exists(paths)) &&
    (!isTRUE(config$force_rebuild_parent_covariates) || parent_uddf_lookup_cache_has_raw_columns(config)) &&
    parent_ids_cache_covers(config, parent_ids)
}

filter_cached_parent_lookup <- function(df, parent_ids, min_akm_year = NULL, max_akm_year = NULL) {
  if (!nrow(df)) {
    return(df)
  }
  df <- df[df$person_id %in% parent_ids, , drop = FALSE]
  if (!is.null(min_akm_year) && !is.null(max_akm_year) &&
      !is.na(min_akm_year) && !is.na(max_akm_year) && "year" %in% names(df)) {
    df <- df[is.na(df$year) | (df$year >= min_akm_year & df$year <= max_akm_year), , drop = FALSE]
  }
  as.data.frame(df, stringsAsFactors = FALSE)
}

read_parent_lookup_cache <- function(config, parent_ids, min_akm_year, max_akm_year) {
  list(
    akm_lookup = filter_cached_parent_lookup(
      arrow::read_parquet(output_file(config, "parent_akm_lookup_cache")),
      parent_ids,
      min_akm_year,
      max_akm_year
    ),
    uddf_lookup = reclassify_uddf_lookup(
      filter_cached_parent_lookup(
        arrow::read_parquet(output_file(config, "parent_uddf_lookup_cache")),
        parent_ids
      ),
      config
    )
  )
}

write_parent_lookup_cache <- function(config, parent_ids, akm_lookup, uddf_lookup, min_akm_year, max_akm_year) {
  write_parquet_output(
    data.frame(parent_id = parent_ids, stringsAsFactors = FALSE),
    config,
    "parent_lookup_ids_cache"
  )
  write_parquet_output(akm_lookup, config, "parent_akm_lookup_cache")
  write_parquet_output(uddf_lookup, config, "parent_uddf_lookup_cache")
  write_csv_output(
    data.frame(
      min_akm_year = min_akm_year,
      max_akm_year = max_akm_year,
      parent_count = length(parent_ids),
      raw_popc_dir = config$raw_popc_dir,
      hfaudd_json_path = config$hfaudd_json_path,
      education_asset_path = config$education_asset_path,
      uddf_lookup_schema = if (all(c("hfaudd", "hf_kilde") %in% names(uddf_lookup))) {
        "raw_uddf_v2"
      } else {
        "derived_uddf_v1"
      },
      created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
      stringsAsFactors = FALSE
    ),
    config,
    "parent_lookup_metadata"
  )
  invisible(TRUE)
}

load_or_build_parent_lookups <- function(config, parent_ids, min_akm_year, max_akm_year) {
  if (parent_lookup_cache_valid(config, parent_ids, min_akm_year, max_akm_year)) {
    return(timed_parent_step("read cached parent POPC lookups", {
      read_parent_lookup_cache(config, parent_ids, min_akm_year, max_akm_year)
    }))
  }

  akm_lookup <- timed_parent_step(
    sprintf("load AKM lookup for %d parent IDs", length(parent_ids)),
    load_akm_lookup(config, parent_ids, min_akm_year, max_akm_year)
  )
  uddf_lookup <- timed_parent_step(
    sprintf("load UDDF lookup for %d parent IDs", length(parent_ids)),
    load_uddf_lookup(config, parent_ids, min_akm_year, max_akm_year)
  )
  if (prepared_baseline_cache_write_enabled(config)) {
    timed_parent_step("write parent POPC lookup cache", {
      write_parent_lookup_cache(config, parent_ids, akm_lookup, uddf_lookup, min_akm_year, max_akm_year)
    })
  }

  list(akm_lookup = akm_lookup, uddf_lookup = uddf_lookup)
}

load_or_build_uddf_lookup <- function(config, parent_ids, min_year, max_year) {
  if (parent_uddf_cache_valid(config, parent_ids)) {
    return(timed_parent_step("read cached parent UDDF lookup", {
      reclassify_uddf_lookup(
        filter_cached_parent_lookup(
          arrow::read_parquet(output_file(config, "parent_uddf_lookup_cache")),
          parent_ids
        ),
        config
      )
    }))
  }

  uddf_lookup <- timed_parent_step(
    sprintf("load UDDF lookup for %d parent IDs", length(parent_ids)),
    load_uddf_lookup(config, parent_ids, min_year, max_year)
  )
  if (prepared_baseline_cache_write_enabled(config)) {
    timed_parent_step("write parent UDDF lookup cache", {
      write_parquet_output(
        data.frame(parent_id = parent_ids, stringsAsFactors = FALSE),
        config,
        "parent_lookup_ids_cache"
      )
      write_parquet_output(uddf_lookup, config, "parent_uddf_lookup_cache")
    })
  }
  uddf_lookup
}

parent_bef_origin_metadata_covers <- function(config, min_year, max_year) {
  metadata_path <- output_file(config, "parent_bef_origin_lookup_metadata")
  if (!file.exists(metadata_path)) {
    return(FALSE)
  }
  metadata <- tryCatch(utils::read.csv(metadata_path, stringsAsFactors = FALSE), error = function(e) NULL)
  required <- c("min_year", "max_year", "raw_popc_dir")
  if (is.null(metadata) || !nrow(metadata) || !all(required %in% names(metadata))) {
    return(FALSE)
  }
  if (!identical(as.character(metadata$raw_popc_dir[[1]]), as.character(config$raw_popc_dir))) {
    return(FALSE)
  }
  cached_min <- suppressWarnings(as.integer(metadata$min_year[[1]]))
  cached_max <- suppressWarnings(as.integer(metadata$max_year[[1]]))
  if (is.na(min_year) || is.na(max_year)) {
    return(TRUE)
  }
  !is.na(cached_min) && !is.na(cached_max) && cached_min <= min_year && cached_max >= max_year
}

parent_bef_origin_cache_valid <- function(config, parent_ids, min_year, max_year) {
  if (!prepared_baseline_cache_enabled(config)) {
    return(FALSE)
  }
  all(file.exists(c(
    output_file(config, "parent_bef_origin_lookup_cache"),
    output_file(config, "parent_bef_origin_lookup_metadata"),
    output_file(config, "parent_lookup_ids_cache")
  ))) &&
    parent_ids_cache_covers(config, parent_ids) &&
    parent_bef_origin_metadata_covers(config, min_year, max_year)
}

read_parent_bef_origin_cache <- function(config, parent_ids, min_year, max_year) {
  cached <- arrow::read_parquet(output_file(config, "parent_bef_origin_lookup_cache")) |>
    as.data.frame(stringsAsFactors = FALSE)
  if (!nrow(cached)) {
    return(cached)
  }
  cached <- cached[cached$person_id %in% parent_ids, , drop = FALSE]
  if (!is.na(min_year) && !is.na(max_year) && "year" %in% names(cached)) {
    cached <- cached[is.na(cached$year) | (cached$year >= min_year & cached$year <= max_year), , drop = FALSE]
  }
  as.data.frame(cached, stringsAsFactors = FALSE)
}

write_parent_bef_origin_cache <- function(config, parent_ids, bef_origin_lookup, min_year, max_year) {
  write_parquet_output(
    data.frame(parent_id = parent_ids, stringsAsFactors = FALSE),
    config,
    "parent_lookup_ids_cache"
  )
  write_parquet_output(bef_origin_lookup, config, "parent_bef_origin_lookup_cache")
  write_csv_output(
    data.frame(
      min_year = min_year,
      max_year = max_year,
      parent_count = length(parent_ids),
      raw_popc_dir = config$raw_popc_dir,
      created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
      stringsAsFactors = FALSE
    ),
    config,
    "parent_bef_origin_lookup_metadata"
  )
  invisible(TRUE)
}

load_or_build_bef_origin_lookup <- function(config, parent_ids, min_year, max_year) {
  if (parent_bef_origin_cache_valid(config, parent_ids, min_year, max_year)) {
    return(timed_parent_step("read cached parent BEF origin lookup", {
      read_parent_bef_origin_cache(config, parent_ids, min_year, max_year)
    }))
  }

  bef_origin_lookup <- timed_parent_step(
    sprintf("load BEF origin lookup for %d parent IDs", length(parent_ids)),
    load_bef_origin_lookup(config, parent_ids, min_year, max_year)
  )
  if (prepared_baseline_cache_write_enabled(config)) {
    timed_parent_step("write parent BEF origin lookup cache", {
      write_parent_bef_origin_cache(config, parent_ids, bef_origin_lookup, min_year, max_year)
    })
  }
  bef_origin_lookup
}

parent_covariate_cache_key <- function(baseline_df) {
  data.frame(
    person_id = as.character(baseline_df$person_id),
    index_date = as.Date(baseline_df$index_date),
    mother_id = as.character(baseline_df$mother_id),
    father_id = as.character(baseline_df$father_id),
    stringsAsFactors = FALSE
  )
}

read_parent_covariates_cache <- function(baseline_df, config) {
  path <- output_file(config, "parent_covariates_cache")
  if (isTRUE(config$force_rebuild_parent_covariates) ||
      !prepared_baseline_cache_enabled(config) || !file.exists(path)) {
    return(NULL)
  }
  cached <- tryCatch(arrow::read_parquet(path), error = function(e) NULL)
  required <- c(
    "person_id",
    "index_date",
    "mother_id",
    "father_id",
    "parent_education_group",
    "parent_socio_group",
    "mother_origin_country",
    "father_origin_country"
  )
  if (is.null(cached) || !all(required %in% names(cached))) {
    return(NULL)
  }

  key <- parent_covariate_cache_key(baseline_df)
  key$row_order <- seq_len(nrow(key))
  matched <- key |>
    left_join(cached[, required, drop = FALSE], by = c("person_id", "index_date", "mother_id", "father_id")) |>
    arrange(row_order) |>
    as.data.frame(stringsAsFactors = FALSE)
  if (nrow(matched) != nrow(key) || anyNA(matched$parent_education_group) || anyNA(matched$parent_socio_group)) {
    return(NULL)
  }

  data.frame(
    parent_education_group = matched$parent_education_group,
    parent_socio_group = matched$parent_socio_group,
    mother_origin_country = matched$mother_origin_country,
    father_origin_country = matched$father_origin_country,
    stringsAsFactors = FALSE
  )
}

write_parent_covariates_cache <- function(baseline_df, config, covariates) {
  cached <- cbind(parent_covariate_cache_key(baseline_df), covariates)
  write_parquet_output(cached, config, "parent_covariates_cache")
  invisible(cached)
}

compute_parental_covariates <- function(baseline_df, config) {
  context <- parent_context_from_baseline(baseline_df)
  parent_ids <- context$parent_ids
  if (!length(parent_ids) || !nrow(baseline_df)) {
    return(data.frame(
      parent_education_group = rep("no_completed_or_missing", nrow(baseline_df)),
      parent_socio_group = rep("missing_other", nrow(baseline_df)),
      mother_origin_country = rep(NA_character_, nrow(baseline_df)),
      father_origin_country = rep(NA_character_, nrow(baseline_df)),
      stringsAsFactors = FALSE
    ))
  }

  cached_covariates <- read_parent_covariates_cache(baseline_df, config)
  if (!is.null(cached_covariates)) {
    message(sprintf("    * using cached parent covariates for %d baseline rows", nrow(baseline_df)))
    return(cached_covariates)
  }

  lookups <- load_or_build_parent_lookups(config, parent_ids, context$min_akm_year, context$max_akm_year)
  akm_lookup <- lookups$akm_lookup
  uddf_lookup <- lookups$uddf_lookup
  bef_origin_lookup <- load_or_build_bef_origin_lookup(
    config,
    parent_ids,
    context$min_origin_year,
    context$max_origin_year
  )
  parent_role_rows <- timed_parent_step(
    "build parent-role rows",
    build_parent_role_rows(baseline_df, context$index_dates, context$baseline_years)
  )
  parent_origin_role_rows <- timed_parent_step(
    "build parent-origin role rows",
    build_parent_role_rows(baseline_df, context$index_dates, context$index_years)
  )

  socio_selected <- timed_parent_step("select latest parent socioeconomic group", {
    select_latest_parent_socio(parent_role_rows, akm_lookup) |>
      tidyr::pivot_wider(
        id_cols = row_id,
        names_from = role,
        values_from = socio_group,
        names_glue = "{role}_socio"
      ) |>
      as.data.frame(stringsAsFactors = FALSE)
  })

  edu_selected <- timed_parent_step("select highest parent education group", {
    select_highest_parent_education(parent_role_rows, uddf_lookup) |>
      tidyr::pivot_wider(
        id_cols = row_id,
        names_from = role,
        values_from = education_group,
        names_glue = "{role}_education"
      ) |>
      as.data.frame(stringsAsFactors = FALSE)
  })

  origin_selected <- timed_parent_step("select latest parent origin country", {
    select_latest_parent_origin(parent_origin_role_rows, bef_origin_lookup) |>
      tidyr::pivot_wider(
        id_cols = row_id,
        names_from = role,
        values_from = origin_country,
        names_glue = "{role}_origin_country"
      ) |>
      as.data.frame(stringsAsFactors = FALSE)
  })

  combined <- data.frame(
    row_id = seq_len(nrow(baseline_df)),
    stringsAsFactors = FALSE
  ) |>
    left_join(socio_selected, by = "row_id") |>
    left_join(edu_selected, by = "row_id") |>
    left_join(origin_selected, by = "row_id") |>
    as.data.frame(stringsAsFactors = FALSE)

  for (col in c(
    "mother_socio",
    "father_socio",
    "mother_education",
    "father_education",
    "mother_origin_country",
    "father_origin_country"
  )) {
    if (!(col %in% names(combined))) {
      combined[[col]] <- NA_character_
    }
  }

  parent_education_group <- combine_parent_education_label_vec(
    combined$mother_education,
    combined$father_education
  )
  parent_socio_group <- combine_parent_socio_label_vec(
    combined$mother_socio,
    combined$father_socio
  )

  covariates <- data.frame(
    parent_education_group = parent_education_group,
    parent_socio_group     = parent_socio_group,
    mother_origin_country  = combined$mother_origin_country,
    father_origin_country  = combined$father_origin_country,
    stringsAsFactors = FALSE
  )
  if (prepared_baseline_cache_write_enabled(config)) {
    timed_parent_step("write parent covariate cache", {
      write_parent_covariates_cache(baseline_df, config, covariates)
    })
  }
  covariates
}

build_parental_education_diagnostics <- function(baseline_df, config) {
  context <- parent_context_from_baseline(baseline_df)
  parent_ids <- context$parent_ids
  index_dates <- context$index_dates
  index_years <- context$index_years

  if (!length(parent_ids) || !length(index_years)) {
    empty_row <- data.frame(
      person_id = character(),
      index_year = integer(),
      mother_id = character(),
      father_id = character(),
      mother_has_id = logical(),
      father_has_id = logical(),
      any_parent_id = logical(),
      mother_has_uddf_by_index = logical(),
      father_has_uddf_by_index = logical(),
      any_parent_uddf_by_index = logical(),
      mother_education_group = character(),
      father_education_group = character(),
      combined_parent_education_group = character(),
      stringsAsFactors = FALSE
    )
    return(list(
      row_level = empty_row,
      summary = data.frame(),
      lookup_summary = data.frame()
    ))
  }

  min_year <- min(index_years, na.rm = TRUE)
  max_year <- max(index_years, na.rm = TRUE)
  uddf_lookup <- load_or_build_uddf_lookup(config, parent_ids, min_year, max_year)
  baseline_core <- data.frame(
    row_id = seq_len(nrow(baseline_df)),
    person_id = baseline_df$person_id,
    index_year = index_years,
    mother_id = na_if(trimws(as.character(baseline_df$mother_id)), ""),
    father_id = na_if(trimws(as.character(baseline_df$father_id)), ""),
    stringsAsFactors = FALSE
  )
  parent_role_rows <- timed_parent_step(
    "build diagnostic parent-role rows",
    build_parent_role_rows(baseline_df, index_dates, index_years)
  )

  education_selected <- timed_parent_step("select diagnostic parent education groups", {
    select_highest_parent_education(parent_role_rows, uddf_lookup) |>
      tidyr::pivot_wider(
        id_cols = row_id,
        names_from = role,
        values_from = education_group,
        names_glue = "{role}_education_group"
      ) |>
      as.data.frame(stringsAsFactors = FALSE)
  })

  presence_selected <- timed_parent_step("select diagnostic UDDF presence flags", {
    select_parent_uddf_presence(parent_role_rows, uddf_lookup) |>
      tidyr::pivot_wider(
        id_cols = row_id,
        names_from = role,
        values_from = has_uddf_by_index,
        names_glue = "{role}_has_uddf_by_index",
        values_fill = FALSE
      ) |>
      as.data.frame(stringsAsFactors = FALSE)
  })

  row_level_df <- baseline_core |>
    left_join(education_selected, by = "row_id") |>
    left_join(presence_selected, by = "row_id") |>
    as.data.frame(stringsAsFactors = FALSE)

  for (col in c("mother_education_group", "father_education_group")) {
    if (!(col %in% names(row_level_df))) {
      row_level_df[[col]] <- NA_character_
    }
  }
  for (col in c("mother_has_uddf_by_index", "father_has_uddf_by_index")) {
    if (!(col %in% names(row_level_df))) {
      row_level_df[[col]] <- FALSE
    }
    row_level_df[[col]][is.na(row_level_df[[col]])] <- FALSE
  }

  row_level_df <- row_level_df |>
    mutate(
      mother_has_id = !is.na(mother_id) & nzchar(mother_id),
      father_has_id = !is.na(father_id) & nzchar(father_id),
      any_parent_id = mother_has_id | father_has_id,
      any_parent_uddf_by_index = mother_has_uddf_by_index | father_has_uddf_by_index,
      combined_parent_education_group = combine_parent_education_label_vec(
        mother_education_group,
        father_education_group
      )
    ) |>
    transmute(
      person_id,
      index_year,
      mother_id,
      father_id,
      mother_has_id,
      father_has_id,
      any_parent_id,
      mother_has_uddf_by_index,
      father_has_uddf_by_index,
      any_parent_uddf_by_index,
      mother_education_group,
      father_education_group,
      combined_parent_education_group
    ) |>
    as.data.frame(stringsAsFactors = FALSE)
  summary_df <- row_level_df |>
    mutate(
      linkage_state = case_when(
        !any_parent_id ~ "no_parent_ids",
        any_parent_id & !any_parent_uddf_by_index ~ "parent_ids_but_no_uddf_by_index",
        TRUE ~ "has_uddf_by_index"
      )
    ) |>
    group_by(linkage_state, combined_parent_education_group) |>
    summarise(rows = n(), .groups = "drop") |>
    arrange(linkage_state, desc(rows)) |>
    as.data.frame(stringsAsFactors = FALSE)

  lookup_summary_df <- uddf_lookup |>
    group_by(education_group) |>
    summarise(rows = n(), unique_parents = n_distinct(person_id), .groups = "drop") |>
    arrange(desc(rows)) |>
    as.data.frame(stringsAsFactors = FALSE)

  list(
    row_level = row_level_df,
    summary = summary_df,
    lookup_summary = lookup_summary_df
  )
}

write_parental_education_diagnostics <- function(diagnostics, config) {
  ensure_output_dir(config)

  paths <- list(
    row_level_path = output_file(config, "parental_education_diagnostics"),
    summary_path = output_file(config, "parental_education_diagnostics_summary"),
    lookup_summary_path = output_file(config, "parental_education_lookup_summary")
  )
  lapply(paths, ensure_output_parent)

  arrow::write_parquet(diagnostics$row_level, paths$row_level_path)
  write_csv_file(diagnostics$summary, paths$summary_path)
  write_csv_file(diagnostics$lookup_summary, paths$lookup_summary_path)

  paths
}
