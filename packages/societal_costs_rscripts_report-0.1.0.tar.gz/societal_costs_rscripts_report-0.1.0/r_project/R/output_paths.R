if (!exists("%||%", mode = "function")) {
  `%||%` <- function(lhs, rhs) {
    if (is.null(lhs) || (length(lhs) == 1L && (is.na(lhs) || identical(lhs, "")))) {
      rhs
    } else {
      lhs
    }
  }
}

OUTPUT_ARTIFACTS <- list(
  input_artifact_manifest = "inventory/input_artifact_manifest.parquet",
  input_artifact_manifest_csv = "inventory/input_artifact_manifest.csv",

  baseline_dataset = "baseline/baseline_dataset.parquet",
  baseline_dataset_notes = "baseline/baseline_dataset_notes.txt",
  parental_education_diagnostics = "baseline/parental_education_diagnostics.parquet",
  parental_education_diagnostics_summary = "baseline/parental_education_diagnostics_summary.csv",
  parental_education_lookup_summary = "baseline/parental_education_lookup_summary.csv",
  matching_inputs = "baseline/matching_inputs.parquet",

  baseline_core_cache = "cache/baseline_core.parquet",
  parent_lookup_ids_cache = "cache/parent_lookup_ids.parquet",
  parent_akm_lookup_cache = "cache/parent_akm_lookup.parquet",
  parent_uddf_lookup_cache = "cache/parent_uddf_lookup.parquet",
  parent_bef_origin_lookup_cache = "cache/parent_bef_origin_lookup.parquet",
  parent_bef_origin_lookup_metadata = "cache/parent_bef_origin_lookup_metadata.csv",
  parent_lookup_metadata = "cache/parent_lookup_metadata.csv",
  parent_covariates_cache = "cache/parent_covariates.parquet",
  preindex_component_years_cache = "cache/preindex_component_years.parquet",
  preindex_person_ids_cache = "cache/preindex_person_ids.parquet",
  preindex_component_years_metadata = "cache/preindex_component_years_metadata.csv",

  matched_pairs = "matching/matched_pairs.parquet",
  matched_cohort = "matching/matched_cohort.parquet",
  matched_cohort_refresh_notes = "matching/matched_cohort_refresh_notes.txt",
  matching_diagnostics = "matching/diagnostics.csv",
  matching_summary = "matching/summary.csv",
  matching_exclusion_summary = "matching/exclusion_summary.csv",

  table1_matched_html = "tables/table1_matched.html",
  table1_matched_csv = "tables/table1_matched.csv",
  table1_baseline_window_html = "tables/table1_baseline_window.html",
  table1_baseline_window_csv = "tables/table1_baseline_window.csv",

  lmdb_direct_cost = "costs/direct/lmdb_direct_cost.parquet",
  lpr_direct_cost = "costs/direct/lpr_direct_cost.parquet",
  primary_sector_direct_cost = "costs/direct/primary_sector_direct_cost.parquet",
  hospital_drugs_direct_cost = "costs/direct/hospital_drugs_direct_cost.parquet",
  direct_cost_person_year = "costs/direct/direct_cost_person_year.parquet",
  direct_cost_coverage_summary = "costs/direct/coverage_summary.csv",
  direct_cost_source_inventory = "costs/direct/source_inventory.csv",
  direct_cost_component_year_availability = "costs/direct/component_year_availability.parquet",
  direct_cost_component_year_summary = "costs/direct/component_year_summary.csv",
  lpr_legacy_validation_summary = "costs/direct/lpr_legacy_validation_summary.csv",
  primary_transition_summary = "costs/direct/primary_transition_summary.csv",
  direct_cost_build_notes = "costs/direct/build_notes.txt",

  matched_cost_panel = "costs/panels/matched_cost_panel.parquet",
  matched_cost_panel_summary = "costs/panels/matched_cost_panel_summary.csv",
  matched_cost_panel_data_availability_summary = "costs/panels/data_availability_summary.csv",

  direct_cost_person_year_harmonized = "costs/harmonized/direct_cost_person_year_harmonized.parquet",
  direct_cost_person_year_harmonized_summary = "costs/harmonized/direct_cost_person_year_harmonized_summary.csv",

  followup_cost_panel = "costs/followup/followup_cost_panel.parquet",
  followup_segments = "costs/followup/followup_segments.parquet",
  followup_cost_panel_compact = "costs/followup/followup_cost_panel_compact.parquet",
  followup_cost_panel_discounted = "costs/followup/followup_cost_panel_discounted.parquet",
  followup_cost_panel_discounted_compact = "costs/followup/followup_cost_panel_discounted_compact.parquet",
  followup_cost_panel_survivors = "costs/followup/followup_cost_panel_survivors.parquet",
  followup_cost_panel_excl90d = "costs/followup/sensitivity/followup_cost_panel_excl90d.parquet",
  followup_cost_panel_compact_excl90d = "costs/followup/sensitivity/followup_cost_panel_compact_excl90d.parquet",
  followup_cost_panel_discounted_excl90d = "costs/followup/sensitivity/followup_cost_panel_discounted_excl90d.parquet",
  followup_cost_panel_discounted_compact_excl90d = "costs/followup/sensitivity/followup_cost_panel_discounted_compact_excl90d.parquet",
  followup_cost_panel_all_entry_years = "costs/followup/sensitivity/followup_cost_panel_all_entry_years.parquet",
  followup_annual_cost_summary = "costs/followup/summaries/annual_cost_summary.csv",
  followup_cumulative_cost_summary = "costs/followup/summaries/cumulative_cost_summary.csv",
  followup_discounted_cumulative_cost_summary = "costs/followup/summaries/discounted_cumulative_cost_summary.csv",
  followup_annual_cost_difference_summary = "costs/followup/summaries/annual_cost_difference_summary.csv",
  followup_cumulative_cost_difference_summary = "costs/followup/summaries/cumulative_cost_difference_summary.csv",
  followup_discounted_cumulative_cost_difference_summary = "costs/followup/summaries/discounted_cumulative_cost_difference_summary.csv",
  followup_annual_cost_summary_excl90d = "costs/followup/sensitivity/followup_annual_cost_summary_excl90d.csv",

  cost_analysis_results = "analysis/primary/cost_analysis_results.csv",
  cost_analysis_cumulative = "analysis/primary/cumulative.csv",
  cost_analysis_annual = "analysis/primary/annual.csv",
  cost_analysis_discount_scenarios = "analysis/discount_scenarios/results.csv",
  cost_analysis_subgroups = "analysis/subgroups/results.csv",
  cost_analysis_results_survivors = "analysis/survivors/results.csv",
  utilization_proxy_summary = "analysis/utilization_proxies/summary.csv",
  model_diagnostics = "analysis/model_diagnostics.csv",
  model_diagnostics_survivors = "analysis/survivors/model_diagnostics.csv",

  supervisor_cohort_flow_plot = "analysis/supervisor/cohort_flow.png",
  supervisor_index_year_distribution_plot = "analysis/supervisor/index_year_distribution.png",
  supervisor_component_coverage_plot = "analysis/supervisor/component_coverage.png",
  supervisor_preindex_cost_ecdf_plot = "analysis/supervisor/preindex_cost_ecdf.png",
  supervisor_stable_core_annual_followup_costs_plot = "analysis/supervisor/stable_core_annual_followup_costs.png",
  supervisor_stable_core_cumulative_cost_difference_plot = "analysis/supervisor/stable_core_cumulative_cost_difference.png",
  supervisor_annual_followup_costs_plot = "analysis/supervisor/annual_followup_costs.png",
  supervisor_cumulative_cost_difference_plot = "analysis/supervisor/cumulative_cost_difference.png",
  supervisor_cohort_flow_csv = "analysis/supervisor/cohort_flow.csv",
  supervisor_index_year_distribution_csv = "analysis/supervisor/index_year_distribution.csv",
  supervisor_component_coverage_csv = "analysis/supervisor/component_coverage.csv",
  supervisor_analysis_options_csv = "analysis/supervisor/analysis_options.csv",
  supervisor_preindex_cost_summary_csv = "analysis/supervisor/preindex_cost_summary.csv",
  supervisor_stable_core_annual_followup_costs_csv = "analysis/supervisor/stable_core_annual_followup_costs.csv",
  supervisor_stable_core_cumulative_cost_difference_csv = "analysis/supervisor/stable_core_cumulative_cost_difference.csv",
  supervisor_annual_followup_costs_csv = "analysis/supervisor/annual_followup_costs.csv",
  supervisor_cumulative_cost_difference_csv = "analysis/supervisor/cumulative_cost_difference.csv",
  supervisor_figure_manifest_csv = "analysis/supervisor/figure_manifest.csv",
  supervisor_report_html = "analysis/supervisor/supervisor_report.html",
  supervisor_report_rmd = "analysis/supervisor/supervisor_report.Rmd",

  pipeline_log = "logs/pipeline.log",
  warnings_log = "logs/warnings.csv",
  run_summary = "logs/run_summary.csv"
)

output_layout <- function(config) {
  layout <- config$output_layout %||% "structured"
  layout <- tolower(as.character(layout[[1]]))
  if (!layout %in% c("structured", "flat")) {
    stop(sprintf("Unknown output_layout '%s'. Use 'structured' or 'flat'.", layout), call. = FALSE)
  }
  layout
}

output_artifact_subpath <- function(artifact) {
  if (!artifact %in% names(OUTPUT_ARTIFACTS)) {
    stop(sprintf("Unknown output artifact '%s'.", artifact), call. = FALSE)
  }
  OUTPUT_ARTIFACTS[[artifact]]
}

output_file <- function(config, artifact) {
  subpath <- output_artifact_subpath(artifact)
  if (identical(output_layout(config), "flat")) {
    subpath <- basename(subpath)
  }
  normalizePath(file.path(config$output_dir, subpath), winslash = "/", mustWork = FALSE)
}

legacy_flat_output_file <- function(config, artifact) {
  normalizePath(
    file.path(config$output_dir, basename(output_artifact_subpath(artifact))),
    winslash = "/",
    mustWork = FALSE
  )
}

resolve_existing_output_file <- function(config, artifact) {
  preferred <- output_file(config, artifact)
  if (file.exists(preferred)) {
    return(normalizePath(preferred, winslash = "/", mustWork = FALSE))
  }
  legacy <- legacy_flat_output_file(config, artifact)
  if (file.exists(legacy)) {
    return(normalizePath(legacy, winslash = "/", mustWork = FALSE))
  }
  preferred
}

ensure_output_parent <- function(path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  invisible(path)
}

ensure_output_tree <- function(config) {
  dir.create(config$output_dir, recursive = TRUE, showWarnings = FALSE)
  if (identical(output_layout(config), "structured")) {
    dirs <- unique(dirname(unlist(OUTPUT_ARTIFACTS, use.names = FALSE)))
    for (dir in dirs) {
      dir.create(file.path(config$output_dir, dir), recursive = TRUE, showWarnings = FALSE)
    }
  }
  invisible(config)
}

csv_column_digits <- function(column_name) {
  if (grepl("discount_rate", column_name, ignore.case = TRUE)) {
    return(4L)
  }
  if (grepl(
    paste(
      c(
        "^year$", "_year$", "^followup_year$", "^index_year$",
        "^rows$", "^people$", "^person_year_rows$",
        "^n_", "_n$", "count", "valid_replicates", "observations",
        "^positive_exposed$", "^positive_unexposed$", "^n_exposed$", "^n_unexposed$",
        "parameters$"
      ),
      collapse = "|"
    ),
    column_name,
    ignore.case = TRUE
  )) {
    return(0L)
  }
  if (grepl("share|fraction|proportion|percent|ratio|rate", column_name, ignore.case = TRUE)) {
    return(4L)
  }
  if (grepl(
    "cost|dkk|mean|median|diff|difference|ci_|lower|upper|sum|max|min|ppy|person_years",
    column_name,
    ignore.case = TRUE
  )) {
    return(2L)
  }
  4L
}

format_csv_output <- function(data, digits_by_column = NULL) {
  formatted <- as.data.frame(data, stringsAsFactors = FALSE)
  for (column_name in names(formatted)) {
    if (!is.numeric(formatted[[column_name]])) {
      next
    }
    digits <- digits_by_column[[column_name]] %||% csv_column_digits(column_name)
    formatted[[column_name]] <- round(formatted[[column_name]], digits = digits)
  }
  formatted
}

write_csv_file <- function(data, path, row.names = FALSE, digits_by_column = NULL) {
  ensure_output_parent(path)
  utils::write.csv(
    format_csv_output(data, digits_by_column = digits_by_column),
    path,
    row.names = row.names,
    na = "NA"
  )
  invisible(path)
}

write_csv_output <- function(data, config, artifact, row.names = FALSE) {
  path <- output_file(config, artifact)
  write_csv_file(data, path, row.names = row.names)
}

write_parquet_output <- function(data, config, artifact) {
  path <- output_file(config, artifact)
  ensure_output_parent(path)
  arrow::write_parquet(data, path)
  invisible(path)
}
