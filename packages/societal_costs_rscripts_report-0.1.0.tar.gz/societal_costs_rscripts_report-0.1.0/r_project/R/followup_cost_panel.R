suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

timed_followup_step <- function(label, expr) {
  start <- Sys.time()
  message(sprintf("  - %s...", label))
  value <- force(expr)
  elapsed <- as.numeric(difftime(Sys.time(), start, units = "secs"))
  message(sprintf("  - %s completed in %.1f seconds", label, elapsed))
  value
}

followup_base_components <- function() {
  c("lmdb", "hospital_drugs", "lpr_sghforlob", "lpr_kontakt", "primary_sector")
}

followup_harmonized_group_columns <- function(df = NULL) {
  columns <- c(
    "person_id", "year", "component", "source_system", "source_era", "coverage_status",
    "cpi_index", "reference_price_year", "cpi_adjustment_factor"
  )
  if (is.null(df)) {
    return(columns)
  }
  intersect(columns, names(df))
}

aggregate_harmonized_cost_rows <- function(harmonized_cost_df) {
  if (!nrow(harmonized_cost_df)) {
    return(harmonized_cost_df)
  }

  group_columns <- followup_harmonized_group_columns(harmonized_cost_df)
  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(harmonized_cost_df)
    dt[, person_id := as.character(person_id)]
    dt[, year := as.integer(year)]
    for (col_name in intersect(c("nominal_cost", "cost_reference_dkk"), names(dt))) {
      dt[, (col_name) := as.numeric(get(col_name))]
    }
    result <- dt[, .(
      nominal_cost = sum(nominal_cost, na.rm = TRUE),
      cost_reference_dkk = sum(cost_reference_dkk, na.rm = TRUE)
    ), by = group_columns]
    data.table::setorderv(result, intersect(c("person_id", "year", "component"), names(result)))
    return(as.data.frame(result))
  }

  harmonized_cost_df |>
    group_by(across(all_of(group_columns))) |>
    summarise(
      nominal_cost = sum(nominal_cost, na.rm = TRUE),
      cost_reference_dkk = sum(cost_reference_dkk, na.rm = TRUE),
      .groups = "drop"
    ) |>
    as.data.frame(stringsAsFactors = FALSE)
}

filter_harmonized_costs_to_person_years <- function(harmonized_cost_df, person_year_keys) {
  if (!nrow(harmonized_cost_df) || !nrow(person_year_keys)) {
    return(harmonized_cost_df[0, , drop = FALSE])
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(harmonized_cost_df)
    keys <- data.table::as.data.table(unique(person_year_keys))
    dt[, person_id := as.character(person_id)]
    dt[, year := as.integer(year)]
    keys[, person_id := as.character(person_id)]
    keys[, year := as.integer(year)]
    data.table::setkey(dt, person_id, year)
    data.table::setkey(keys, person_id, year)
    return(as.data.frame(dt[keys, nomatch = 0L]))
  }

  harmonized_cost_df |>
    inner_join(unique(person_year_keys), by = c("person_id", "year")) |>
    as.data.frame(stringsAsFactors = FALSE)
}

# Build all follow-up segments in one vectorized pass over matched_df.
# Returns the same schema as the old per-person lapply approach.
build_followup_segments_vectorized <- function(matched_df, max_followup_years = 10L) {
  valid <- !is.na(matched_df$index_date)
  if (!any(valid)) return(data.frame())
  df <- matched_df[valid, , drop = FALSE]
  n  <- nrow(df)

  # Study end per person: end of follow-up year max, clamped to censor_date
  study_end_unc <- add_years_vec(df$index_date, max_followup_years) - 1L
  study_end     <- study_end_unc
  has_censor    <- !is.na(df$censor_date)
  if (any(has_censor)) {
    study_end[has_censor] <- pmin(
      as.Date(df$censor_date[has_censor]),
      study_end_unc[has_censor]
    )
  }

  # Expand to person × followup_year grid (rectangular: all persons get max_followup_years slots)
  idx <- rep(seq_len(n),            each  = max_followup_years)
  fy  <- rep(seq_len(max_followup_years), times = n)

  index_date_r <- df$index_date[idx]
  study_end_r  <- study_end[idx]

  index_year <- as.integer(format(df$index_date, "%Y"))
  index_month <- format(df$index_date, "%m")
  index_day <- format(df$index_date, "%d")
  make_shifted_dates <- function(year_offset) {
    shifted_year <- index_year[idx] + year_offset
    result <- as.Date(paste(shifted_year, index_month[idx], index_day[idx], sep = "-"))
    bad <- !is.na(index_date_r) & is.na(result)
    if (any(bad)) {
      result[bad] <- as.Date(paste(shifted_year[bad], index_month[idx][bad], "28", sep = "-"))
    }
    result
  }

  seg_start    <- make_shifted_dates(fy - 1L)
  seg_end_full <- make_shifted_dates(fy) - 1L
  seg_end      <- pmin(seg_end_full, study_end_r)

  valid_rows <- seg_end >= seg_start
  if (!any(valid_rows)) return(data.frame())

  i   <- idx[valid_rows]
  fyv <- fy[valid_rows]
  ss  <- seg_start[valid_rows]
  se  <- seg_end[valid_rows]
  sef <- seg_end_full[valid_rows]

  obs_days  <- as.numeric(se - ss) + 1
  full_days <- as.numeric(sef - ss) + 1

  data.frame(
    person_id             = df$person_id[i],
    family_id             = if ("family_id"      %in% names(df)) df$family_id[i]      else NA_character_,
    matched_set_id        = if ("matched_set_id" %in% names(df)) df$matched_set_id[i] else NA_character_,
    match_weight          = if ("match_weight"   %in% names(df)) df$match_weight[i]   else NA_real_,
    exposed               = as.logical(df$exposed[i]),
    diagnosis_group       = df$diagnosis_group[i],
    severity              = df$severity[i],
    index_date            = df$index_date[i],
    index_year            = index_year[i],
    followup_year         = fyv,
    segment_start         = ss,
    segment_end           = se,
    observed_days         = obs_days,
    observed_person_years = obs_days / 365.25,
    observed_fraction     = ifelse(full_days > 0, obs_days / full_days, 0),
    stringsAsFactors      = FALSE
  )
}

ensure_followup_segment_id <- function(segment_rows) {
  if (!nrow(segment_rows) || ".segment_id" %in% names(segment_rows)) {
    return(segment_rows)
  }
  segment_rows$.segment_id <- seq_len(nrow(segment_rows))
  segment_rows
}

drop_followup_internal_columns <- function(df) {
  if (!nrow(df)) {
    return(df)
  }
  df[, setdiff(names(df), ".segment_id"), drop = FALSE]
}

with_public_followup_segment_id <- function(df) {
  if (!nrow(df)) {
    return(df)
  }
  if (".segment_id" %in% names(df) && !"followup_segment_id" %in% names(df)) {
    names(df)[names(df) == ".segment_id"] <- "followup_segment_id"
  }
  df
}

with_internal_followup_segment_id <- function(df) {
  if (!nrow(df)) {
    return(df)
  }
  if ("followup_segment_id" %in% names(df) && !".segment_id" %in% names(df)) {
    names(df)[names(df) == "followup_segment_id"] <- ".segment_id"
  }
  df
}

build_followup_segment_panel <- function(segment_rows) {
  if (!nrow(segment_rows)) {
    return(data.frame())
  }
  with_public_followup_segment_id(ensure_followup_segment_id(segment_rows))
}

is_true_pipeline_setting <- function(settings, name) {
  value <- settings[[name]] %||% FALSE
  if (exists("parse_bool_flag", mode = "function")) {
    parse_bool_flag(value, default = FALSE)
  } else {
    isTRUE(value) || tolower(as.character(value)) %in% c("1", "true", "t", "yes", "y", "on")
  }
}

followup_build_options <- function(settings = list()) {
  skip_sensitivities <- is_true_pipeline_setting(settings, "skip_followup_sensitivities")
  list(
    include_discounted = !is_true_pipeline_setting(settings, "skip_discounts"),
    include_survivors = !is_true_pipeline_setting(settings, "skip_survivors"),
    include_full_panel = is_true_pipeline_setting(settings, "write_full_followup_panel"),
    include_90d_sensitivity = !(skip_sensitivities || is_true_pipeline_setting(settings, "skip_followup_90d_sensitivity")),
    include_all_entry_years = !(skip_sensitivities || is_true_pipeline_setting(settings, "skip_followup_all_entry_years"))
  )
}

coverage_status_priority <- function(status) {
  priority <- c(missing = 0L, restricted = 1L, supplementary = 2L, partial = 3L, full = 4L)
  result <- unname(priority[as.character(status)])
  result[is.na(result)] <- 0L
  result
}

coverage_status_from_priority <- function(priority) {
  levels <- c("missing", "restricted", "supplementary", "partial", "full")
  levels[pmax(0L, pmin(4L, as.integer(priority))) + 1L]
}

expand_followup_segments_to_calendar_years <- function(segment_df, exclude_first_n_days = 0L) {
  if (!nrow(segment_df)) {
    return(data.frame())
  }

  segment_start <- as.Date(segment_df$segment_start)
  segment_end   <- as.Date(segment_df$segment_end)
  valid <- !is.na(segment_start) & !is.na(segment_end) & segment_end >= segment_start
  if (!any(valid)) {
    return(data.frame())
  }

  segment_df    <- segment_df[valid, , drop = FALSE]
  segment_start <- segment_start[valid]
  segment_end   <- segment_end[valid]
  start_year    <- as.integer(format(segment_start, "%Y"))
  end_year      <- as.integer(format(segment_end, "%Y"))
  year_counts   <- end_year - start_year + 1L

  segment_index <- rep(seq_len(nrow(segment_df)), times = year_counts)
  calendar_year <- rep(start_year, times = year_counts) + sequence(year_counts) - 1L
  expanded <- segment_df[segment_index, , drop = FALSE]
  expanded$calendar_year  <- as.integer(calendar_year)

  unique_calendar_years <- sort(unique(expanded$calendar_year))
  calendar_year_match <- match(expanded$calendar_year, unique_calendar_years)
  calendar_start_lookup <- as.Date(sprintf("%04d-01-01", unique_calendar_years))
  calendar_end_lookup <- as.Date(sprintf("%04d-12-31", unique_calendar_years))
  expanded$calendar_start <- calendar_start_lookup[calendar_year_match]
  expanded$calendar_end   <- calendar_end_lookup[calendar_year_match]

  overlap_start <- pmax(as.Date(expanded$segment_start), expanded$calendar_start)
  overlap_end   <- pmin(as.Date(expanded$segment_end),   expanded$calendar_end)

  if (exclude_first_n_days > 0L) {
    exclusion_end <- as.Date(expanded$index_date) + as.difftime(as.integer(exclude_first_n_days) - 1L, units = "days")
    overlap_start <- pmax(overlap_start, exclusion_end + 1L)
  }

  expanded$allocation_overlap_days <- as.numeric(overlap_end - overlap_start) + 1
  expanded$allocation_overlap_days[is.na(expanded$allocation_overlap_days) | expanded$allocation_overlap_days < 0] <- 0
  expanded <- expanded[expanded$allocation_overlap_days > 0, , drop = FALSE]
  if (!nrow(expanded)) {
    return(data.frame())
  }

  calendar_days <- as.numeric(expanded$calendar_end - expanded$calendar_start) + 1
  expanded$allocation_fraction <- expanded$allocation_overlap_days / calendar_days
  if (requireNamespace("data.table", quietly = TRUE)) {
    return(as.data.frame(data.table::as.data.table(expanded)))
  }

  expanded
}

build_followup_person_year_keys <- function(matched_df, max_followup_years = 10L) {
  if (!nrow(matched_df)) {
    return(data.frame(person_id = character(), year = integer(), stringsAsFactors = FALSE))
  }

  index_date <- as.Date(matched_df$index_date)
  valid <- !is.na(index_date) & !is.na(matched_df$person_id) & nzchar(as.character(matched_df$person_id))
  if (!any(valid)) {
    return(data.frame(person_id = character(), year = integer(), stringsAsFactors = FALSE))
  }

  matched_df <- matched_df[valid, , drop = FALSE]
  index_date <- index_date[valid]
  study_end <- add_years_vec(index_date, max_followup_years) - 1L

  if ("censor_date" %in% names(matched_df)) {
    censor_date <- as.Date(matched_df$censor_date)
    has_censor <- !is.na(censor_date)
    if (any(has_censor)) {
      study_end[has_censor] <- pmin(censor_date[has_censor], study_end[has_censor])
    }
  }

  start_year <- as.integer(format(index_date, "%Y"))
  end_year   <- as.integer(format(study_end, "%Y"))
  valid_span <- !is.na(start_year) & !is.na(end_year) & end_year >= start_year
  if (!any(valid_span)) {
    return(data.frame(person_id = character(), year = integer(), stringsAsFactors = FALSE))
  }

  person_id  <- as.character(matched_df$person_id[valid_span])
  start_year <- start_year[valid_span]
  end_year   <- end_year[valid_span]
  year_counts <- end_year - start_year + 1L

  keys <- data.frame(
    person_id = rep(person_id, times = year_counts),
    year = as.integer(rep(start_year, times = year_counts) + sequence(year_counts) - 1L),
    stringsAsFactors = FALSE
  )
  unique(keys)
}

load_relevant_harmonized_costs <- function(harmonized_cost_path, matched_df, max_followup_years = 10L) {
  if (!file.exists(harmonized_cost_path) || !nrow(matched_df)) {
    return(data.frame())
  }

  person_year_keys <- build_followup_person_year_keys(matched_df, max_followup_years)
  if (!nrow(person_year_keys)) {
    return(data.frame())
  }

  min_year <- min(person_year_keys$year, na.rm = TRUE)
  max_year <- max(person_year_keys$year, na.rm = TRUE)

  ds <- arrow::open_dataset(harmonized_cost_path, format = "parquet")
  selected_columns <- intersect(
    c(
      "person_id", "year", "component", "source_system", "source_era", "coverage_status",
      "nominal_cost", "cost_reference_dkk", "cpi_index", "reference_price_year",
      "cpi_adjustment_factor"
    ),
    names(ds$schema)
  )

  cost_scan <- ds |>
    select(dplyr::all_of(selected_columns)) |>
    filter(year >= min_year, year <= max_year)
  if (exists("filter_dataset_to_person_ids", mode = "function")) {
    cost_scan <- filter_dataset_to_person_ids(
      cost_scan,
      unique(person_year_keys$person_id),
      id_col = "person_id"
    )
  }

  collected <- cost_scan |>
    collect() |>
    as.data.frame(stringsAsFactors = FALSE)

  collected <- filter_harmonized_costs_to_person_years(collected, person_year_keys)
  aggregate_harmonized_cost_rows(collected)
}

filter_relevant_harmonized_costs <- function(harmonized_cost_df, matched_df, max_followup_years = 10L) {
  if (!nrow(harmonized_cost_df) || !nrow(matched_df)) {
    return(data.frame())
  }

  person_year_keys <- build_followup_person_year_keys(matched_df, max_followup_years)
  if (!nrow(person_year_keys)) {
    return(data.frame())
  }

  min_year <- min(person_year_keys$year, na.rm = TRUE)
  max_year <- max(person_year_keys$year, na.rm = TRUE)
  selected_columns <- intersect(
    c(
      "person_id", "year", "component", "source_system", "source_era", "coverage_status",
      "nominal_cost", "cost_reference_dkk", "cpi_index", "reference_price_year",
      "cpi_adjustment_factor"
    ),
    names(harmonized_cost_df)
  )

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(harmonized_cost_df)
    dt[, year := as.integer(year)]
    filtered <- as.data.frame(dt[year >= min_year & year <= max_year, ..selected_columns])
  } else {
    filtered <- harmonized_cost_df |>
      select(dplyr::all_of(selected_columns)) |>
      filter(year >= min_year, year <= max_year) |>
      as.data.frame(stringsAsFactors = FALSE)
  }

  filtered <- filter_harmonized_costs_to_person_years(filtered, person_year_keys)
  aggregate_harmonized_cost_rows(filtered)
}

allocate_person_year_cost_to_followup <- function(segment_df, cost_df, max_followup_years = 10L, exclude_first_n_days = 0L) {
  if (!nrow(segment_df) || !nrow(cost_df)) {
    return(data.frame())
  }

  segment_years <- expand_followup_segments_to_calendar_years(segment_df, exclude_first_n_days)
  if (!nrow(segment_years)) {
    return(data.frame())
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    segment_dt <- data.table::as.data.table(segment_years)
    cost_dt <- data.table::as.data.table(cost_df)
    segment_dt[, person_id := as.character(person_id)]
    segment_dt[, calendar_year := as.integer(calendar_year)]
    cost_dt[, person_id := as.character(person_id)]
    cost_dt[, year := as.integer(year)]
    segment_join <- data.table::copy(segment_dt)
    data.table::setnames(segment_join, "calendar_year", "year")
    merged <- merge(
      segment_join,
      cost_dt,
      by = c("person_id", "year"),
      allow.cartesian = TRUE,
      sort = FALSE
    )

    if (!nrow(merged)) {
      return(data.frame())
    }

    merged[, calendar_year := year]
    merged[, nominal_cost_allocated := nominal_cost * allocation_fraction]
    merged[, cost_reference_dkk_allocated := cost_reference_dkk * allocation_fraction]
    merged[, service_year_cpi_index := cpi_index]

    output_columns <- c(
      if (".segment_id" %in% names(merged)) ".segment_id",
      "person_id", "exposed", "diagnosis_group", "severity", "index_date", "index_year",
      "followup_year", "segment_start", "segment_end", "observed_days", "observed_person_years",
      "observed_fraction", "calendar_year", "component", "source_system", "source_era",
      "coverage_status", "service_year_cpi_index", "reference_price_year",
      "cpi_adjustment_factor", "allocation_overlap_days", "allocation_fraction",
      "nominal_cost_allocated", "cost_reference_dkk_allocated"
    )
    return(as.data.frame(merged[, ..output_columns]))
  }

  merged <- dplyr::inner_join(
    segment_years, cost_df,
    by = c("person_id", "calendar_year" = "year"),
    relationship = "many-to-many"
  )

  if (!nrow(merged)) {
    return(data.frame())
  }

  merged$nominal_cost_allocated            <- merged$nominal_cost * merged$allocation_fraction
  merged$cost_reference_dkk_allocated      <- merged$cost_reference_dkk * merged$allocation_fraction
  merged$service_year_cpi_index            <- merged$cpi_index

  output_columns <- c(
    if (".segment_id" %in% names(merged)) ".segment_id",
    "person_id", "exposed", "diagnosis_group", "severity", "index_date", "index_year",
    "followup_year", "segment_start", "segment_end", "observed_days", "observed_person_years",
    "observed_fraction", "calendar_year", "component", "source_system", "source_era",
    "coverage_status", "service_year_cpi_index", "reference_price_year",
    "cpi_adjustment_factor", "allocation_overlap_days", "allocation_fraction",
    "nominal_cost_allocated", "cost_reference_dkk_allocated"
  )

  merged[, output_columns, drop = FALSE]
}

complete_followup_component_grid <- function(segment_rows, allocated_cost_rows) {
  base_components <- followup_base_components()
  if (!nrow(segment_rows)) {
    return(data.frame())
  }
  segment_rows <- ensure_followup_segment_id(segment_rows)

  if (requireNamespace("data.table", quietly = TRUE)) {
    segment_dt <- data.table::as.data.table(segment_rows)
    n_segments <- nrow(segment_dt)
    segment_grid <- segment_dt[rep(seq_len(n_segments), each = length(base_components))]
    segment_grid[, component := rep(base_components, times = n_segments)]

    if (!nrow(allocated_cost_rows)) {
      segment_grid[, nominal_cost_allocated := 0]
      segment_grid[, cost_reference_dkk_allocated := 0]
      segment_grid[, allocation_fraction_sum := 0]
      segment_grid[, source_system := component]
      segment_grid[, source_era := component]
      segment_grid[, coverage_status := "missing"]
      if (".segment_id" %in% names(segment_grid)) {
        segment_grid[, .segment_id := NULL]
      }
      return(segment_grid)
    }

    aggregated_allocations <- summarise_followup_component_allocations(allocated_cost_rows)
    allocation_columns <- c(
      ".segment_id", "component",
      "nominal_cost_allocated", "cost_reference_dkk_allocated", "allocation_fraction_sum",
      "source_system", "source_era", "coverage_status"
    )
    allocation_dt <- data.table::as.data.table(aggregated_allocations)
    allocation_dt <- allocation_dt[, ..allocation_columns]

    segment_grid[, nominal_cost_allocated := 0]
    segment_grid[, cost_reference_dkk_allocated := 0]
    segment_grid[, allocation_fraction_sum := 0]
    segment_grid[, source_system := component]
    segment_grid[, source_era := component]
    segment_grid[, coverage_status := "missing"]

    segment_grid[allocation_dt, on = .(.segment_id, component), `:=`(
      nominal_cost_allocated = i.nominal_cost_allocated,
      cost_reference_dkk_allocated = i.cost_reference_dkk_allocated,
      allocation_fraction_sum = i.allocation_fraction_sum,
      source_system = i.source_system,
      source_era = i.source_era,
      coverage_status = i.coverage_status
    )]

    allocation_dt[, coverage_priority := coverage_status_priority(coverage_status)]
    total_values <- allocation_dt[, .(
      nominal_cost_allocated = sum(nominal_cost_allocated, na.rm = TRUE),
      cost_reference_dkk_allocated = sum(cost_reference_dkk_allocated, na.rm = TRUE),
      allocation_fraction_sum = sum(allocation_fraction_sum, na.rm = TRUE),
      coverage_priority = max(coverage_priority, na.rm = TRUE)
    ), by = .(.segment_id)]

    total_rows <- data.table::copy(segment_dt)
    total_idx <- match(total_rows$.segment_id, total_values$.segment_id)
    total_rows[, component := "total"]
    total_rows[, nominal_cost_allocated := total_values$nominal_cost_allocated[total_idx]]
    total_rows[, cost_reference_dkk_allocated := total_values$cost_reference_dkk_allocated[total_idx]]
    total_rows[, allocation_fraction_sum := total_values$allocation_fraction_sum[total_idx]]
    total_rows[is.na(nominal_cost_allocated), nominal_cost_allocated := 0]
    total_rows[is.na(cost_reference_dkk_allocated), cost_reference_dkk_allocated := 0]
    total_rows[is.na(allocation_fraction_sum), allocation_fraction_sum := 0]
    total_rows[, source_system := "combined"]
    total_rows[, source_era := "combined"]
    total_rows[, coverage_status := coverage_status_from_priority(data.table::fifelse(
      is.na(total_values$coverage_priority[total_idx]),
      0L,
      total_values$coverage_priority[total_idx]
    ))]

    result <- data.table::rbindlist(list(segment_grid, total_rows), use.names = TRUE, fill = TRUE)
    if (".segment_id" %in% names(result)) {
      result[, .segment_id := NULL]
    }
    return(result)
  }

  segment_grid <- merge(
    segment_rows,
    data.frame(component = base_components, stringsAsFactors = FALSE),
    by = NULL
  )

  if (!nrow(allocated_cost_rows)) {
    segment_grid$nominal_cost_allocated         <- 0
    segment_grid$cost_reference_dkk_allocated   <- 0
    segment_grid$allocation_fraction_sum        <- 0
    segment_grid$source_system                  <- segment_grid$component
    segment_grid$source_era                     <- segment_grid$component
    segment_grid$coverage_status                <- "missing"
    return(segment_grid)
  }

  aggregated_allocations <- summarise_followup_component_allocations(allocated_cost_rows)

  if (".segment_id" %in% names(aggregated_allocations)) {
    allocation_columns <- c(
      ".segment_id", "component",
      "nominal_cost_allocated", "cost_reference_dkk_allocated", "allocation_fraction_sum",
      "source_system", "source_era", "coverage_status"
    )
    merged <- segment_grid |>
      left_join(
        aggregated_allocations[, allocation_columns, drop = FALSE],
        by = c(".segment_id", "component")
      )
  } else {
    merged <- segment_grid |>
      left_join(
        aggregated_allocations,
        by = c(
          "person_id", "exposed", "diagnosis_group", "severity", "index_date", "index_year",
          "followup_year", "segment_start", "segment_end", "observed_days", "observed_person_years",
          "observed_fraction", "component"
        )
      )
  }

  merged <- merged |>
    mutate(
      nominal_cost_allocated       = dplyr::coalesce(nominal_cost_allocated, 0),
      cost_reference_dkk_allocated = dplyr::coalesce(cost_reference_dkk_allocated, 0),
      allocation_fraction_sum      = dplyr::coalesce(allocation_fraction_sum, 0),
      source_system    = dplyr::coalesce(source_system, component),
      source_era       = dplyr::coalesce(source_era,    component),
      coverage_status  = dplyr::coalesce(coverage_status, "missing")
    )

  # Compute totals from the already-aggregated component rows (cheaper than re-aggregating allocated_cost_rows)
  if (".segment_id" %in% names(merged)) {
    ids <- segment_rows$.segment_id
    nominal_sum <- rowsum(merged$nominal_cost_allocated, merged$.segment_id, reorder = FALSE)
    reference_sum <- rowsum(merged$cost_reference_dkk_allocated, merged$.segment_id, reorder = FALSE)
    fraction_sum <- rowsum(merged$allocation_fraction_sum, merged$.segment_id, reorder = FALSE)
    row_idx <- match(ids, rownames(nominal_sum))
    coverage_priority <- tapply(
      coverage_status_priority(merged$coverage_status),
      merged$.segment_id,
      max
    )
    coverage_idx <- match(ids, names(coverage_priority))

    total_rows <- segment_rows
    total_rows$component <- "total"
    total_rows$nominal_cost_allocated <- as.numeric(nominal_sum[row_idx, 1])
    total_rows$cost_reference_dkk_allocated <- as.numeric(reference_sum[row_idx, 1])
    total_rows$allocation_fraction_sum <- as.numeric(fraction_sum[row_idx, 1])
    total_rows$source_system <- "combined"
    total_rows$source_era <- "combined"
    total_rows$coverage_status <- coverage_status_from_priority(coverage_priority[coverage_idx])
  } else {
    total_rows <- merged |>
      group_by(
        person_id, exposed, diagnosis_group, severity, index_date, index_year, followup_year,
        segment_start, segment_end, observed_days, observed_person_years, observed_fraction
      ) |>
      summarise(
        nominal_cost_allocated       = sum(nominal_cost_allocated, na.rm = TRUE),
        cost_reference_dkk_allocated = sum(cost_reference_dkk_allocated, na.rm = TRUE),
        allocation_fraction_sum      = sum(allocation_fraction_sum, na.rm = TRUE),
        source_system   = "combined",
        source_era      = "combined",
        coverage_status = case_when(
          any(coverage_status == "full")          ~ "full",
          any(coverage_status == "partial")       ~ "partial",
          any(coverage_status == "supplementary") ~ "supplementary",
          any(coverage_status == "restricted")    ~ "restricted",
          TRUE                                    ~ "missing"
        ),
        component = "total",
        .groups = "drop"
      )
  }

  bind_rows(merged, total_rows) |>
    arrange(person_id, followup_year, component) |>
    drop_followup_internal_columns() |>
    as.data.frame(stringsAsFactors = FALSE)
}

followup_component_group_columns <- function(df = NULL) {
  base_columns <- c(
    "person_id", "exposed", "diagnosis_group", "severity", "index_date", "index_year",
    "followup_year", "segment_start", "segment_end", "observed_days",
    "observed_person_years", "observed_fraction", "component"
  )
  if (!is.null(df) && ".segment_id" %in% names(df)) {
    return(c(".segment_id", base_columns))
  }
  base_columns
}

followup_segment_group_columns <- function(df = NULL) {
  setdiff(followup_component_group_columns(df), "component")
}

summarise_followup_component_allocations <- function(allocated_cost_rows) {
  if (!nrow(allocated_cost_rows)) {
    return(data.frame())
  }

  if (requireNamespace("data.table", quietly = TRUE) && ".segment_id" %in% names(allocated_cost_rows)) {
    dt <- data.table::as.data.table(allocated_cost_rows)
    dt[, coverage_priority := coverage_status_priority(coverage_status)]
    group_cols <- c(".segment_id", "component")
    result <- dt[, .(
      person_id = person_id[[1]],
      exposed = exposed[[1]],
      diagnosis_group = diagnosis_group[[1]],
      severity = severity[[1]],
      index_date = index_date[[1]],
      index_year = index_year[[1]],
      followup_year = followup_year[[1]],
      segment_start = segment_start[[1]],
      segment_end = segment_end[[1]],
      observed_days = observed_days[[1]],
      observed_person_years = observed_person_years[[1]],
      observed_fraction = observed_fraction[[1]],
      nominal_cost_allocated = sum(nominal_cost_allocated, na.rm = TRUE),
      cost_reference_dkk_allocated = sum(cost_reference_dkk_allocated, na.rm = TRUE),
      allocation_fraction_sum = sum(allocation_fraction, na.rm = TRUE),
      source_system = paste(sort(unique(source_system)), collapse = ";"),
      source_era = paste(sort(unique(source_era)), collapse = ";"),
      coverage_status = coverage_status_from_priority(max(coverage_priority, na.rm = TRUE))
    ), by = group_cols]
    return(result)
  }

  allocated_cost_rows |>
    group_by(across(all_of(followup_component_group_columns(allocated_cost_rows)))) |>
    summarise(
      nominal_cost_allocated        = sum(nominal_cost_allocated, na.rm = TRUE),
      cost_reference_dkk_allocated  = sum(cost_reference_dkk_allocated, na.rm = TRUE),
      allocation_fraction_sum       = sum(allocation_fraction, na.rm = TRUE),
      source_system = paste(sort(unique(source_system)), collapse = ";"),
      source_era    = paste(sort(unique(source_era)),    collapse = ";"),
      coverage_status = case_when(
        any(coverage_status == "full")          ~ "full",
        any(coverage_status == "partial")       ~ "partial",
        any(coverage_status == "supplementary") ~ "supplementary",
        any(coverage_status == "restricted")    ~ "restricted",
        TRUE                                    ~ "missing"
      ),
      .groups = "drop"
    ) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_sparse_followup_component_panel <- function(allocated_cost_rows, include_zero_cost_components = FALSE) {
  sparse_rows <- summarise_followup_component_allocations(allocated_cost_rows)
  if (!nrow(sparse_rows)) {
    return(sparse_rows)
  }

  if (!isTRUE(include_zero_cost_components)) {
    sparse_rows <- sparse_rows |>
      filter(nominal_cost_allocated != 0 | cost_reference_dkk_allocated != 0)
  }

  if (!nrow(sparse_rows)) {
    return(sparse_rows)
  }

  if (requireNamespace("data.table", quietly = TRUE) && ".segment_id" %in% names(sparse_rows)) {
    dt <- data.table::as.data.table(sparse_rows)
    dt[, coverage_priority := coverage_status_priority(coverage_status)]
    total_rows <- dt[, .(
      person_id = person_id[[1]],
      exposed = exposed[[1]],
      diagnosis_group = diagnosis_group[[1]],
      severity = severity[[1]],
      index_date = index_date[[1]],
      index_year = index_year[[1]],
      followup_year = followup_year[[1]],
      segment_start = segment_start[[1]],
      segment_end = segment_end[[1]],
      observed_days = observed_days[[1]],
      observed_person_years = observed_person_years[[1]],
      observed_fraction = observed_fraction[[1]],
      nominal_cost_allocated = sum(nominal_cost_allocated, na.rm = TRUE),
      cost_reference_dkk_allocated = sum(cost_reference_dkk_allocated, na.rm = TRUE),
      allocation_fraction_sum = sum(allocation_fraction_sum, na.rm = TRUE),
      source_system = "combined",
      source_era = "combined",
      coverage_status = coverage_status_from_priority(max(coverage_priority, na.rm = TRUE)),
      component = "total"
    ), by = .(.segment_id)]
    dt[, coverage_priority := NULL]
    result <- data.table::rbindlist(list(dt, total_rows), use.names = TRUE, fill = TRUE)
    return(drop_followup_internal_columns(as.data.frame(result)))
  }

  total_rows <- sparse_rows |>
    group_by(across(all_of(followup_segment_group_columns(sparse_rows)))) |>
    summarise(
      nominal_cost_allocated       = sum(nominal_cost_allocated, na.rm = TRUE),
      cost_reference_dkk_allocated = sum(cost_reference_dkk_allocated, na.rm = TRUE),
      allocation_fraction_sum      = sum(allocation_fraction_sum, na.rm = TRUE),
      source_system   = "combined",
      source_era      = "combined",
      coverage_status = case_when(
        any(coverage_status == "full")          ~ "full",
        any(coverage_status == "partial")       ~ "partial",
        any(coverage_status == "supplementary") ~ "supplementary",
        any(coverage_status == "restricted")    ~ "restricted",
        TRUE                                    ~ "missing"
      ),
      component = "total",
      .groups = "drop"
    )

  bind_rows(sparse_rows, total_rows) |>
    arrange(person_id, followup_year, component) |>
    drop_followup_internal_columns() |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_compact_followup_component_panel <- function(segment_rows, allocated_cost_rows) {
  if (!nrow(segment_rows)) {
    return(data.frame())
  }
  segment_rows <- ensure_followup_segment_id(segment_rows)

  if (requireNamespace("data.table", quietly = TRUE)) {
    segment_dt <- data.table::copy(data.table::as.data.table(segment_rows))
    aggregated <- if (nrow(allocated_cost_rows)) {
      alloc_dt <- data.table::copy(data.table::as.data.table(allocated_cost_rows))
      alloc_dt[, coverage_priority := coverage_status_priority(coverage_status)]
      alloc_dt[, .(
        nominal_cost_allocated = sum(nominal_cost_allocated, na.rm = TRUE),
        cost_reference_dkk_allocated = sum(cost_reference_dkk_allocated, na.rm = TRUE),
        allocation_fraction_sum = sum(allocation_fraction, na.rm = TRUE),
        source_system = if (data.table::uniqueN(source_system) == 1L) source_system[[1L]] else "combined",
        source_era = if (data.table::uniqueN(source_era) == 1L) source_era[[1L]] else "combined",
        coverage_priority = max(coverage_priority, na.rm = TRUE)
      ), by = .(.segment_id, component)]
    } else {
      data.table::data.table()
    }

    component_rows <- if (nrow(aggregated)) {
      component_values <- aggregated[
        component != "total" &
          (nominal_cost_allocated != 0 | cost_reference_dkk_allocated != 0)
      ]
      if (nrow(component_values)) {
        rows <- segment_dt[component_values, on = .(.segment_id)]
        rows[, coverage_status := coverage_status_from_priority(coverage_priority)]
        rows[, coverage_priority := NULL]
        rows
      } else {
        data.table::data.table()
      }
    } else {
      data.table::data.table()
    }

    total_values <- if (nrow(aggregated)) {
      aggregated[, .(
        nominal_cost_allocated = sum(nominal_cost_allocated, na.rm = TRUE),
        cost_reference_dkk_allocated = sum(cost_reference_dkk_allocated, na.rm = TRUE),
        allocation_fraction_sum = sum(allocation_fraction_sum, na.rm = TRUE),
        coverage_priority = max(coverage_priority, na.rm = TRUE)
      ), by = .(.segment_id)]
    } else {
      data.table::data.table(
        .segment_id = integer(),
        nominal_cost_allocated = numeric(),
        cost_reference_dkk_allocated = numeric(),
        allocation_fraction_sum = numeric(),
        coverage_priority = integer()
      )
    }

    total_rows <- data.table::copy(segment_dt)
    total_idx <- match(total_rows$.segment_id, total_values$.segment_id)
    total_rows[, component := "total"]
    total_rows[, nominal_cost_allocated := total_values$nominal_cost_allocated[total_idx]]
    total_rows[, cost_reference_dkk_allocated := total_values$cost_reference_dkk_allocated[total_idx]]
    total_rows[, allocation_fraction_sum := total_values$allocation_fraction_sum[total_idx]]
    total_rows[is.na(nominal_cost_allocated), nominal_cost_allocated := 0]
    total_rows[is.na(cost_reference_dkk_allocated), cost_reference_dkk_allocated := 0]
    total_rows[is.na(allocation_fraction_sum), allocation_fraction_sum := 0]
    total_rows[, source_system := "combined"]
    total_rows[, source_era := "combined"]
    total_rows[, coverage_status := coverage_status_from_priority(data.table::fifelse(
      is.na(total_values$coverage_priority[total_idx]),
      0L,
      total_values$coverage_priority[total_idx]
    ))]

    result <- data.table::rbindlist(list(component_rows, total_rows), use.names = TRUE, fill = TRUE)
    result <- data.table::as.data.table(with_public_followup_segment_id(as.data.frame(result)))
    return(add_followup_annual_cost_rates(result))
  }

  component_rows <- summarise_followup_component_allocations(allocated_cost_rows)
  if (nrow(component_rows)) {
    component_rows <- component_rows |>
      filter(component != "total" & (nominal_cost_allocated != 0 | cost_reference_dkk_allocated != 0))
  }

  full_panel <- complete_followup_component_grid(segment_rows, allocated_cost_rows)
  total_rows <- full_panel[full_panel$component == "total", , drop = FALSE]
  bind_rows(component_rows, total_rows) |>
    with_public_followup_segment_id() |>
    add_followup_annual_cost_rates()
}

add_followup_annual_cost_rates <- function(followup_cost_panel_df) {
  if (!nrow(followup_cost_panel_df)) {
    return(followup_cost_panel_df)
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(followup_cost_panel_df)
    dt[, annual_cost_ppy_nominal := data.table::fifelse(
      observed_person_years > 0,
      nominal_cost_allocated / observed_person_years,
      NA_real_
    )]
    dt[, annual_cost_ppy_reference_dkk := data.table::fifelse(
      observed_person_years > 0,
      cost_reference_dkk_allocated / observed_person_years,
      NA_real_
    )]
    data.table::setDF(dt)
    return(dt)
  }

  followup_cost_panel_df |>
    mutate(
      annual_cost_ppy_nominal       = ifelse(observed_person_years > 0, nominal_cost_allocated / observed_person_years, NA_real_),
      annual_cost_ppy_reference_dkk = ifelse(observed_person_years > 0, cost_reference_dkk_allocated / observed_person_years, NA_real_)
    ) |>
    as.data.frame(stringsAsFactors = FALSE)
}

complete_compact_followup_component_slice <- function(
  compact_panel_df,
  segment_df,
  component_name,
  base_cost_col = "cost_reference_dkk_allocated"
) {
  if (!nrow(segment_df)) {
    return(data.frame())
  }
  if (!"followup_segment_id" %in% names(segment_df)) {
    segment_df <- with_public_followup_segment_id(ensure_followup_segment_id(segment_df))
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    base_dt <- data.table::as.data.table(segment_df)
    rows_dt <- if (nrow(compact_panel_df)) {
      data.table::as.data.table(compact_panel_df[compact_panel_df$component == component_name, , drop = FALSE])
    } else {
      data.table::data.table()
    }
    if (".segment_id" %in% names(base_dt)) {
      base_dt[, .segment_id := NULL]
    }
    if (".segment_id" %in% names(rows_dt)) {
      data.table::setnames(rows_dt, ".segment_id", "followup_segment_id")
    }

    result <- data.table::copy(base_dt)
    result[, component := component_name]
    result[, nominal_cost_allocated := 0]
    result[, cost_reference_dkk_allocated := 0]
    result[, allocation_fraction_sum := 0]
    result[, source_system := component_name]
    result[, source_era := component_name]
    result[, coverage_status := "missing"]
    if (base_cost_col != "cost_reference_dkk_allocated") {
      result[, (base_cost_col) := 0]
    }

    if ("discount_rate" %in% names(compact_panel_df)) {
      discount_values <- unique(stats::na.omit(compact_panel_df$discount_rate))
      result[, discount_rate := if (length(discount_values) == 1L) discount_values[[1]] else NA_real_]
    }

    if (nrow(rows_dt)) {
      value_columns <- unique(intersect(
        c(
          "followup_segment_id", "nominal_cost_allocated", "cost_reference_dkk_allocated",
          "allocation_fraction_sum", "source_system", "source_era", "coverage_status",
          "discount_rate", base_cost_col
        ),
        names(rows_dt)
      ))
      values_dt <- rows_dt[, ..value_columns]
      update_columns <- setdiff(value_columns, "followup_segment_id")
      result[values_dt, on = .(followup_segment_id), (update_columns) := mget(paste0("i.", update_columns))]
    }

    if ("followup_segment_id" %in% names(result)) {
      result[, followup_segment_id := NULL]
    }
    return(add_followup_annual_cost_rates(result))
  }

  base <- segment_df
  rows <- compact_panel_df[compact_panel_df$component == component_name, , drop = FALSE]
  result <- merge(
    base,
    rows[, setdiff(names(rows), intersect(names(rows), setdiff(names(base), "followup_segment_id"))), drop = FALSE],
    by = "followup_segment_id",
    all.x = TRUE
  )
  result$component <- component_name
  for (col in c("nominal_cost_allocated", "cost_reference_dkk_allocated", "allocation_fraction_sum", base_cost_col)) {
    if (!col %in% names(result)) {
      result[[col]] <- 0
    }
    result[[col]][is.na(result[[col]])] <- 0
  }
  result$source_system <- dplyr::coalesce(result$source_system, component_name)
  result$source_era <- dplyr::coalesce(result$source_era, component_name)
  result$coverage_status <- dplyr::coalesce(result$coverage_status, "missing")
  result$followup_segment_id <- NULL
  add_followup_annual_cost_rates(result)
}

apply_discount_scenarios <- function(followup_cost_panel_df, discount_rates = default_discount_rates()) {
  if (!nrow(followup_cost_panel_df)) {
    return(data.frame())
  }

  # Precompute vectors shared across all rates
  svc_year   <- followup_cost_panel_df$index_year + followup_cost_panel_df$followup_year - 1L
  idx_year   <- followup_cost_panel_df$index_year
  base_costs <- followup_cost_panel_df$cost_reference_dkk_allocated

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(followup_cost_panel_df)
    result <- data.table::rbindlist(lapply(discount_rates, function(discount_rate) {
      rate <- discount_rate
      discounted <- data.table::copy(dt)
      discounted[, discount_rate := rate]
      discounted[, discounted_cost_reference_dkk := discount_cost_reference_dkk(
        base_costs,
        service_year = svc_year,
        index_year = idx_year,
        discount_rate = rate
      )]
      discounted
    }), use.names = TRUE, fill = TRUE)
    return(as.data.frame(result))
  }

  bind_rows(lapply(discount_rates, function(discount_rate) {
    followup_cost_panel_df$discount_rate                  <- discount_rate
    followup_cost_panel_df$discounted_cost_reference_dkk  <- discount_cost_reference_dkk(
      base_costs, service_year = svc_year, index_year = idx_year, discount_rate = discount_rate
    )
    followup_cost_panel_df
  })) |>
    as.data.frame(stringsAsFactors = FALSE)
}

empty_discounted_followup_panel <- function(followup_cost_panel_df) {
  if (ncol(followup_cost_panel_df)) {
    empty_panel <- followup_cost_panel_df[0, , drop = FALSE]
  } else {
    empty_panel <- data.frame()
  }
  empty_panel$discount_rate <- numeric()
  empty_panel$discounted_cost_reference_dkk <- numeric()
  empty_panel
}

# Core allocation + grid logic, accepting pre-built segments.
# Used by build_followup_cost_panel and by the runner when reusing segments.
build_followup_cost_panel_from_segments <- function(
  segment_rows, harmonized_cost_df,
  max_followup_years = 10L, exclude_first_n_days = 0L,
  include_sparse = TRUE,
  include_discounted = TRUE,
  include_full = TRUE,
  include_compact = TRUE
) {
  if (!nrow(segment_rows)) {
    return(list(
      followup_segments = data.frame(),
      compact_followup_cost_panel = data.frame(),
      followup_cost_panel = data.frame(),
      sparse_followup_cost_panel = data.frame(),
      discounted_compact_followup_cost_panel = data.frame(),
      discounted_followup_cost_panel = data.frame()
    ))
  }
  segment_rows <- ensure_followup_segment_id(segment_rows)
  followup_segments <- build_followup_segment_panel(segment_rows)

  # Narrow harmonized_cost_df to the calendar years the segments actually span
  if (nrow(harmonized_cost_df)) {
    min_year <- min(as.integer(format(segment_rows$segment_start, "%Y")))
    max_year <- max(as.integer(format(segment_rows$segment_end,   "%Y")))
    if (requireNamespace("data.table", quietly = TRUE)) {
      harmonized_cost_dt <- data.table::as.data.table(harmonized_cost_df)
      harmonized_cost_dt[, year := as.integer(year)]
      harmonized_cost_df <- as.data.frame(harmonized_cost_dt[year >= min_year & year <= max_year])
    } else {
      harmonized_cost_df <- harmonized_cost_df[
        harmonized_cost_df$year >= min_year & harmonized_cost_df$year <= max_year,
        , drop = FALSE
      ]
    }
  }

  allocated_cost_rows <- timed_followup_step("allocate person-year costs to follow-up", {
    allocate_person_year_cost_to_followup(
      segment_df = segment_rows,
      cost_df    = harmonized_cost_df,
      max_followup_years     = max_followup_years,
      exclude_first_n_days   = exclude_first_n_days
    )
  })

  sparse_followup_cost_panel <- if (isTRUE(include_sparse)) {
    timed_followup_step("build sparse follow-up component panel", {
      build_sparse_followup_component_panel(allocated_cost_rows) |>
        add_followup_annual_cost_rates()
    })
  } else {
    data.frame()
  }

  compact_followup_cost_panel <- if (isTRUE(include_compact)) {
    timed_followup_step("build compact follow-up component panel", {
      build_compact_followup_component_panel(segment_rows, allocated_cost_rows)
    })
  } else {
    data.frame()
  }

  followup_cost_panel <- if (isTRUE(include_full)) {
    timed_followup_step("complete follow-up component grid", {
      complete_followup_component_grid(segment_rows, allocated_cost_rows) |>
        add_followup_annual_cost_rates()
    })
  } else {
    data.frame()
  }

  discounted_compact_followup_cost_panel <- if (isTRUE(include_discounted) && nrow(compact_followup_cost_panel)) {
    timed_followup_step("apply compact follow-up discount scenarios", {
      apply_discount_scenarios(compact_followup_cost_panel)
    })
  } else if (ncol(compact_followup_cost_panel)) {
    empty_discounted_followup_panel(compact_followup_cost_panel)
  } else {
    data.frame()
  }

  discounted_followup_cost_panel <- if (isTRUE(include_discounted) && nrow(followup_cost_panel)) {
    timed_followup_step("apply follow-up discount scenarios", {
      apply_discount_scenarios(followup_cost_panel)
    })
  } else if (ncol(followup_cost_panel)) {
    empty_discounted_followup_panel(followup_cost_panel)
  } else {
    data.frame()
  }

  list(
    followup_segments              = followup_segments,
    compact_followup_cost_panel    = compact_followup_cost_panel,
    followup_cost_panel            = followup_cost_panel,
    sparse_followup_cost_panel     = sparse_followup_cost_panel,
    discounted_compact_followup_cost_panel = discounted_compact_followup_cost_panel,
    discounted_followup_cost_panel = discounted_followup_cost_panel
  )
}

build_followup_cost_panel <- function(
  matched_df, harmonized_cost_df,
  max_followup_years = 10L,
  exclude_first_n_days = 0L,
  include_sparse = TRUE,
  include_discounted = TRUE,
  include_full = TRUE,
  include_compact = TRUE
) {
  segment_rows <- timed_followup_step("build follow-up segments", {
    build_followup_segments_vectorized(matched_df, max_followup_years)
  })
  build_followup_cost_panel_from_segments(
    segment_rows, harmonized_cost_df,
    max_followup_years   = max_followup_years,
    exclude_first_n_days = exclude_first_n_days,
    include_sparse      = include_sparse,
    include_discounted  = include_discounted,
    include_full        = include_full,
    include_compact     = include_compact
  )
}

followup_summary_components <- function(followup_cost_panel_df, segment_df = NULL) {
  if (!is.null(segment_df) && nrow(segment_df)) {
    return(c("total", followup_base_components()))
  }
  sort(unique(as.character(followup_cost_panel_df$component)))
}

build_followup_annual_summary <- function(followup_cost_panel_df, segment_df = NULL) {
  if (!is.null(segment_df) && nrow(segment_df)) {
    return(dplyr::bind_rows(lapply(
      followup_summary_components(followup_cost_panel_df, segment_df),
      function(component_name) {
        build_followup_annual_summary(
          complete_compact_followup_component_slice(
            followup_cost_panel_df,
            segment_df,
            component_name
          )
        )
      }
    )) |>
      as.data.frame(stringsAsFactors = FALSE))
  }

  if (!nrow(followup_cost_panel_df)) {
    return(data.frame())
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(followup_cost_panel_df)
    result <- dt[, .(
      rows = .N,
      people = data.table::uniqueN(person_id),
      observed_person_years_sum = sum(observed_person_years, na.rm = TRUE),
      nominal_cost_sum = sum(nominal_cost_allocated, na.rm = TRUE),
      cost_reference_dkk_sum = sum(cost_reference_dkk_allocated, na.rm = TRUE)
    ), by = .(component, followup_year, exposed)]
    result[, annual_cost_ppy_reference_dkk := data.table::fifelse(
      observed_person_years_sum > 0,
      cost_reference_dkk_sum / observed_person_years_sum,
      NA_real_
    )]
    data.table::setorderv(result, c("component", "followup_year", "exposed"))
    return(as.data.frame(result))
  }

  followup_cost_panel_df |>
    group_by(component, followup_year, exposed) |>
    summarise(
      rows                             = n(),
      people                           = n_distinct(person_id),
      observed_person_years_sum        = sum(observed_person_years, na.rm = TRUE),
      nominal_cost_sum                 = sum(nominal_cost_allocated, na.rm = TRUE),
      cost_reference_dkk_sum           = sum(cost_reference_dkk_allocated, na.rm = TRUE),
      annual_cost_ppy_reference_dkk    = ifelse(
        observed_person_years_sum > 0,
        cost_reference_dkk_sum / observed_person_years_sum,
        NA_real_
      ),
      .groups = "drop"
    ) |>
    arrange(component, followup_year, exposed) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_followup_cumulative_summary <- function(followup_cost_panel_df, max_followup_years = 10L, segment_df = NULL) {
  if (!is.null(segment_df) && nrow(segment_df)) {
    return(dplyr::bind_rows(lapply(
      followup_summary_components(followup_cost_panel_df, segment_df),
      function(component_name) {
        build_followup_cumulative_summary(
          complete_compact_followup_component_slice(
            followup_cost_panel_df,
            segment_df,
            component_name
          ),
          max_followup_years = max_followup_years
        )
      }
    )) |>
      as.data.frame(stringsAsFactors = FALSE))
  }

  if (!nrow(followup_cost_panel_df)) {
    return(data.frame())
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(followup_cost_panel_df)
    dt <- dt[followup_year <= max_followup_years]
    person_costs <- dt[, .(
      cumulative_nominal_cost = sum(nominal_cost_allocated, na.rm = TRUE),
      cumulative_cost_reference_dkk = sum(cost_reference_dkk_allocated, na.rm = TRUE)
    ), by = .(component, exposed, person_id)]
    result <- person_costs[, .(
      people = .N,
      mean_cumulative_nominal_cost = mean(cumulative_nominal_cost, na.rm = TRUE),
      mean_cumulative_cost_reference_dkk = mean(cumulative_cost_reference_dkk, na.rm = TRUE)
    ), by = .(component, exposed)]
    data.table::setorderv(result, c("component", "exposed"))
    return(as.data.frame(result))
  }

  followup_cost_panel_df |>
    filter(followup_year <= max_followup_years) |>
    group_by(component, exposed, person_id) |>
    summarise(
      cumulative_nominal_cost          = sum(nominal_cost_allocated, na.rm = TRUE),
      cumulative_cost_reference_dkk    = sum(cost_reference_dkk_allocated, na.rm = TRUE),
      .groups = "drop"
    ) |>
    group_by(component, exposed) |>
    summarise(
      people                                = n(),
      mean_cumulative_nominal_cost          = mean(cumulative_nominal_cost, na.rm = TRUE),
      mean_cumulative_cost_reference_dkk    = mean(cumulative_cost_reference_dkk, na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(component, exposed) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_followup_discounted_cumulative_summary <- function(
  discounted_followup_cost_panel_df,
  max_followup_years = 10L,
  segment_df = NULL
) {
  if (!is.null(segment_df) && nrow(segment_df)) {
    discount_rates <- sort(unique(stats::na.omit(discounted_followup_cost_panel_df$discount_rate)))
    return(dplyr::bind_rows(lapply(discount_rates, function(rate) {
      rate_df <- discounted_followup_cost_panel_df[
        !is.na(discounted_followup_cost_panel_df$discount_rate) &
          abs(discounted_followup_cost_panel_df$discount_rate - rate) < 1e-9,
        ,
        drop = FALSE
      ]
      dplyr::bind_rows(lapply(
        followup_summary_components(rate_df, segment_df),
        function(component_name) {
          completed <- complete_compact_followup_component_slice(
            rate_df,
            segment_df,
            component_name,
            base_cost_col = "discounted_cost_reference_dkk"
          )
          completed$discount_rate <- rate
          build_followup_discounted_cumulative_summary(
            completed,
            max_followup_years = max_followup_years
          )
        }
      ))
    })) |>
      as.data.frame(stringsAsFactors = FALSE))
  }

  if (!nrow(discounted_followup_cost_panel_df)) {
    return(data.frame())
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(discounted_followup_cost_panel_df)
    dt <- dt[followup_year <= max_followup_years]
    person_costs <- dt[, .(
      cumulative_discounted_cost_reference_dkk = sum(discounted_cost_reference_dkk, na.rm = TRUE)
    ), by = .(component, discount_rate, exposed, person_id)]
    result <- person_costs[, .(
      people = .N,
      mean_cumulative_discounted_cost_reference_dkk = mean(cumulative_discounted_cost_reference_dkk, na.rm = TRUE)
    ), by = .(component, discount_rate, exposed)]
    data.table::setorderv(result, c("component", "discount_rate", "exposed"))
    return(as.data.frame(result))
  }

  discounted_followup_cost_panel_df |>
    filter(followup_year <= max_followup_years) |>
    group_by(component, discount_rate, exposed, person_id) |>
    summarise(
      cumulative_discounted_cost_reference_dkk = sum(discounted_cost_reference_dkk, na.rm = TRUE),
      .groups = "drop"
    ) |>
    group_by(component, discount_rate, exposed) |>
    summarise(
      people                                        = n(),
      mean_cumulative_discounted_cost_reference_dkk = mean(cumulative_discounted_cost_reference_dkk, na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(component, discount_rate, exposed) |>
    as.data.frame(stringsAsFactors = FALSE)
}

filter_survivor_only_panel <- function(panel_df, matched_df, baseline_df = NULL) {
  if (!nrow(panel_df)) return(panel_df)

  if ("censor_reason" %in% names(matched_df)) {
    censor_lookup <- unique(matched_df[, c("person_id", "censor_reason"), drop = FALSE])
  } else if (!is.null(baseline_df) && "censor_reason" %in% names(baseline_df)) {
    censor_lookup <- unique(baseline_df[, c("person_id", "censor_reason"), drop = FALSE])
    message("Note: censor_reason joined from baseline_df (not present in matched_df).")
  } else {
    message("Warning: censor_reason unavailable — survivor-only filter not applied.")
    return(panel_df)
  }

  censor_lookup <- censor_lookup[!duplicated(censor_lookup$person_id), , drop = FALSE]
  if (requireNamespace("data.table", quietly = TRUE)) {
    panel_dt <- data.table::as.data.table(panel_df)
    lookup_dt <- data.table::as.data.table(censor_lookup)
    panel_dt[, person_id := as.character(person_id)]
    lookup_dt[, person_id := as.character(person_id)]
    panel_aug <- lookup_dt[panel_dt, on = .(person_id)]
    is_death_censored <- !is.na(panel_aug$censor_reason) &
      panel_aug$censor_reason == "death" &
      panel_aug$observed_fraction < 1.0
    return(as.data.frame(panel_aug[!is_death_censored]))
  }

  panel_aug <- merge(panel_df, censor_lookup, by = "person_id", all.x = TRUE)

  is_death_censored <- !is.na(panel_aug$censor_reason) &
    panel_aug$censor_reason == "death" &
    panel_aug$observed_fraction < 1.0

  panel_aug[!is_death_censored, , drop = FALSE]
}

build_followup_difference_summary <- function(summary_df, value_column, group_columns) {
  if (!nrow(summary_df)) {
    return(data.frame())
  }

  assert_required_columns(summary_df, c(group_columns, value_column, "exposed"),
    "summary_df for difference computation")

  exposed_rows   <- summary_df[summary_df$exposed, , drop = FALSE]
  unexposed_rows <- summary_df[!summary_df$exposed, , drop = FALSE]

  if (!nrow(exposed_rows) || !nrow(unexposed_rows)) {
    return(data.frame())
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    exposed_dt <- data.table::as.data.table(exposed_rows)
    unexposed_dt <- data.table::as.data.table(unexposed_rows)
    merged <- merge(
      exposed_dt,
      unexposed_dt,
      by = group_columns,
      suffixes = c("_exposed", "_unexposed"),
      sort = FALSE
    )
    merged$difference_exposed_minus_unexposed <- merged[[paste0(value_column, "_exposed")]] -
      merged[[paste0(value_column, "_unexposed")]]
    return(as.data.frame(merged))
  }

  merged <- dplyr::inner_join(
    exposed_rows, unexposed_rows,
    by = group_columns,
    suffix = c("_exposed", "_unexposed")
  )
  merged$difference_exposed_minus_unexposed <- merged[[paste0(value_column, "_exposed")]] -
    merged[[paste0(value_column, "_unexposed")]]
  merged
}

write_followup_cost_outputs <- function(
  followup_segments_df,
  compact_followup_cost_panel_df,
  followup_cost_panel_df,
  discounted_compact_followup_cost_panel_df,
  discounted_followup_cost_panel_df,
  annual_summary_df,
  cumulative_summary_df,
  discounted_cumulative_summary_df,
  annual_difference_df,
  cumulative_difference_df,
  discounted_cumulative_difference_df,
  config,
  write_full_panel = TRUE
) {
  ensure_output_dir(config)

  paths <- list(
    followup_segments_path                   = output_file(config, "followup_segments"),
    compact_followup_cost_panel_path         = output_file(config, "followup_cost_panel_compact"),
    followup_cost_panel_path                 = output_file(config, "followup_cost_panel"),
    discounted_compact_followup_cost_panel_path = output_file(config, "followup_cost_panel_discounted_compact"),
    discounted_followup_cost_panel_path      = output_file(config, "followup_cost_panel_discounted"),
    annual_summary_path                      = output_file(config, "followup_annual_cost_summary"),
    cumulative_summary_path                  = output_file(config, "followup_cumulative_cost_summary"),
    discounted_cumulative_summary_path       = output_file(config, "followup_discounted_cumulative_cost_summary"),
    annual_difference_path                   = output_file(config, "followup_annual_cost_difference_summary"),
    cumulative_difference_path               = output_file(config, "followup_cumulative_cost_difference_summary"),
    discounted_cumulative_difference_path    = output_file(config, "followup_discounted_cumulative_cost_difference_summary")
  )
  lapply(paths, ensure_output_parent)

  timed_followup_step("write follow-up segments parquet", {
    arrow::write_parquet(followup_segments_df, paths$followup_segments_path)
  })
  timed_followup_step("write compact follow-up cost panel parquet", {
    arrow::write_parquet(compact_followup_cost_panel_df, paths$compact_followup_cost_panel_path)
  })

  if (!ncol(discounted_followup_cost_panel_df)) {
    discounted_followup_cost_panel_df <- empty_discounted_followup_panel(followup_cost_panel_df)
  }
  if (!ncol(discounted_compact_followup_cost_panel_df)) {
    discounted_compact_followup_cost_panel_df <- empty_discounted_followup_panel(compact_followup_cost_panel_df)
  }

  timed_followup_step("write discounted compact follow-up panel parquet", {
    arrow::write_parquet(
      discounted_compact_followup_cost_panel_df,
      paths$discounted_compact_followup_cost_panel_path
    )
  })
  if (isTRUE(write_full_panel)) {
    timed_followup_step("write full follow-up cost panel parquet", {
      arrow::write_parquet(followup_cost_panel_df, paths$followup_cost_panel_path)
    })
    timed_followup_step("write discounted full follow-up panel parquet", {
      arrow::write_parquet(discounted_followup_cost_panel_df, paths$discounted_followup_cost_panel_path)
    })
  } else {
    message("Skipping full follow-up cost panel parquet.")
  }
  timed_followup_step("write follow-up summary CSVs", {
    write_csv_file(annual_summary_df,                   paths$annual_summary_path)
    write_csv_file(cumulative_summary_df,               paths$cumulative_summary_path)
    write_csv_file(discounted_cumulative_summary_df,    paths$discounted_cumulative_summary_path)
    write_csv_file(annual_difference_df,                paths$annual_difference_path)
    write_csv_file(cumulative_difference_df,            paths$cumulative_difference_path)
    write_csv_file(discounted_cumulative_difference_df, paths$discounted_cumulative_difference_path)
  })

  paths
}
