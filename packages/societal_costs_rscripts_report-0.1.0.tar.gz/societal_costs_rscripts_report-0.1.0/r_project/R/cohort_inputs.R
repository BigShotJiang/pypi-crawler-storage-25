suppressPackageStartupMessages({
  library(dplyr)
})

required_baseline_sources <- function(config) {
  manifest <- expected_artifact_manifest(config)
  manifest$artifact_path[match(
    c("cohort_base", "cohort_censoring", "scd_results", "mfr_child_birth_fact", "relations_index"),
    manifest$artifact_name
  )]
}

load_baseline_source_datasets <- function(config) {
  paths <- expected_artifact_manifest(config)
  path_lookup <- stats::setNames(paths$artifact_path, paths$artifact_name)

  list(
    cohort_base = open_parquet_dataset(path_lookup[["cohort_base"]]) |>
      rename(index_date = reference_date) |>
      select(
        person_id,
        index_date,
        sex,
        birth_date,
        municipality,
        region,
        family_id,
        mother_id,
        father_id,
        civil_status,
        family_type,
        origin_country,
        ie_type
      ),
    cohort_censoring = open_parquet_dataset(path_lookup[["cohort_censoring"]]) |>
      rename(is_resident_eligible = eligible_resident),
    scd_results = open_parquet_dataset(path_lookup[["scd_results"]]) |>
      transmute(
        person_id,
        scd_is_case = is_scd,
        scd_first_date = first_scd_date,
        scd_first_chapter = first_scd_chapter
      ),
    mfr_child_birth_fact = open_parquet_dataset(path_lookup[["mfr_child_birth_fact"]]) |>
      select(
        person_id,
        mother_id,
        father_id,
        gestational_age_days,
        birth_weight_grams,
        parity,
        births_count,
        multiple_birth_flag,
        maternal_age,
        apgar_score_5min
      ),
    relations_index = open_parquet_dataset(path_lookup[["relations_index"]]) |>
      select(
        person_id,
        mother_id,
        father_id,
        sibling_group_id,
        sibling_count,
        relation_rows
      )
  )
}
