log_timestamp <- function() {
  format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
}

initialize_run_logging <- function(config) {
  ensure_output_tree(config)
  log_path <- output_file(config, "pipeline_log")
  warnings_path <- output_file(config, "warnings_log")
  ensure_output_parent(log_path)
  ensure_output_parent(warnings_path)
  writeLines(sprintf("[%s] INFO pipeline: run logging initialized", log_timestamp()), log_path)
  write_csv_file(
    data.frame(
      timestamp = character(0),
      stage = character(0),
      message = character(0),
      stringsAsFactors = FALSE
    ),
    warnings_path
  )
  invisible(config)
}

log_event <- function(config, level = "INFO", stage = "pipeline", message, actionable = NA_character_) {
  log_path <- output_file(config, "pipeline_log")
  ensure_output_parent(log_path)
  suffix <- if (!is.na(actionable) && nzchar(actionable)) {
    paste0(" | action: ", actionable)
  } else {
    ""
  }
  cat(
    sprintf("[%s] %s %s: %s%s\n", log_timestamp(), toupper(level), stage, message, suffix),
    file = log_path,
    append = TRUE
  )
  invisible(log_path)
}

append_warning_record <- function(config, stage, message) {
  warnings_path <- output_file(config, "warnings_log")
  ensure_output_parent(warnings_path)
  row <- data.frame(
    timestamp = log_timestamp(),
    stage = stage,
    message = message,
    stringsAsFactors = FALSE
  )

  if (!file.exists(warnings_path)) {
    write_csv_file(row, warnings_path)
  } else {
    existing <- utils::read.csv(warnings_path, stringsAsFactors = FALSE)
    write_csv_file(rbind(existing, row), warnings_path)
  }
  invisible(warnings_path)
}

with_warning_logging <- function(config, stage, expr) {
  warnings <- character(0)
  result <- withCallingHandlers(
    expr,
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )

  if (length(warnings)) {
    for (warning_message in warnings) {
      append_warning_record(config, stage, warning_message)
    }
    log_event(
      config,
      level = "WARN",
      stage = stage,
      message = sprintf("Captured %d warning(s); see %s", length(warnings), output_file(config, "warnings_log"))
    )
  }

  result
}

write_run_summary <- function(config, stage_results) {
  path <- output_file(config, "run_summary")
  write_csv_file(stage_results, path)
  invisible(path)
}
