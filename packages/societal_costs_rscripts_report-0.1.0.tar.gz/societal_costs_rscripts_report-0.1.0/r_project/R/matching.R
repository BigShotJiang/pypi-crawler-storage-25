suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

default_match_ratios <- function() {
  c(4L, 3L, 2L, 1L)
}

default_birth_date_caliper_days <- function() {
  31L
}

default_preindex_lag_days <- function() {
  91L
}

timed_matching_step <- function(label, expr) {
  start <- Sys.time()
  message(sprintf("  - %s...", label))
  value <- force(expr)
  elapsed <- as.numeric(difftime(Sys.time(), start, units = "secs"))
  message(sprintf("  - %s completed in %.1f seconds", label, elapsed))
  value
}

resolve_target_ratio <- function(match_ratios) {
  ratios <- as.integer(match_ratios)
  ratios <- ratios[!is.na(ratios) & ratios > 0L]
  if (!length(ratios)) {
    return(1L)
  }
  max(ratios)
}

as_safe_date_distance <- function(left, right) {
  if (is.na(left) || is.na(right)) {
    return(.Machine$integer.max)
  }
  abs(as.integer(left - right))
}

matched_baseline_window <- function(index_date, baseline_years_target, preindex_lag_days = default_preindex_lag_days()) {
  baseline_start <- subtract_year_days(index_date, baseline_years_target)
  baseline_end <- index_date - 1
  preindex_end <- index_date - preindex_lag_days

  list(
    baseline_start = baseline_start,
    baseline_end = baseline_end,
    preindex_end = preindex_end
  )
}

observed_person_years <- function(birth_date, baseline_start, preindex_end) {
  if (is.na(preindex_end) || is.na(baseline_start)) {
    return(NA_real_)
  }

  observed_start <- baseline_start
  if (!is.na(birth_date) && birth_date > observed_start) {
    observed_start <- birth_date
  }

  if (preindex_end < observed_start) {
    return(0)
  }

  as.numeric(preindex_end - observed_start + 1) / 365.25
}

sex_region_key <- function(sex_value, region_value) {
  paste0(ifelse(is.na(sex_value), "NA", as.character(sex_value)), "::", ifelse(is.na(region_value), "", region_value))
}

evaluate_control_for_case <- function(control_row, case_row, birth_date_caliper_days) {
  if (!isTRUE(control_row$unexposed)) {
    return("not_unexposed")
  }
  if (!isTRUE(control_row$is_resident_eligible)) {
    return("not_resident_eligible")
  }
  if (!is.na(control_row$censor_date) && control_row$censor_date < case_row$index_date) {
    return("censored_before_index")
  }
  if (!is.na(control_row$birth_date) && !is.na(case_row$index_date) && control_row$birth_date > case_row$index_date) {
    return("birth_after_index")
  }
  if (!is.na(birth_date_caliper_days) &&
      !is.na(control_row$birth_date) &&
      !is.na(case_row$birth_date) &&
      as_safe_date_distance(control_row$birth_date, case_row$birth_date) > birth_date_caliper_days) {
    return("birth_date_caliper")
  }
  "eligible"
}

evaluate_control_pool_for_case <- function(control_pool, case_row, birth_date_caliper_days) {
  if (!nrow(control_pool)) {
    return(character())
  }

  reasons <- rep("eligible", nrow(control_pool))

  reasons[!control_pool$unexposed] <- "not_unexposed"
  reasons[reasons == "eligible" & !control_pool$is_resident_eligible] <- "not_resident_eligible"
  reasons[reasons == "eligible" & !is.na(control_pool$censor_date) & control_pool$censor_date < case_row$index_date[[1]]] <- "censored_before_index"
  reasons[reasons == "eligible" & !is.na(control_pool$birth_date) & !is.na(case_row$index_date[[1]]) & control_pool$birth_date > case_row$index_date[[1]]] <- "birth_after_index"

  case_birth_date_int <- case_row$birth_date_int[[1]] %||% as.integer(case_row$birth_date[[1]])
  if (!is.na(birth_date_caliper_days) && !is.na(case_birth_date_int)) {
    birth_distance <- abs(control_pool$birth_date_int - case_birth_date_int)
    birth_distance[is.na(birth_distance)] <- .Machine$integer.max
    reasons[reasons == "eligible" & birth_distance > birth_date_caliper_days] <- "birth_date_caliper"
  }

  reasons
}

rank_controls_for_case <- function(control_pool, case_row) {
  if (!nrow(control_pool)) {
    return(control_pool)
  }

  case_birth_date_int <- case_row$birth_date_int[[1]] %||% as.integer(case_row$birth_date[[1]])
  control_pool$birth_date_distance_days <- abs(control_pool$birth_date_int - case_birth_date_int)
  control_pool$birth_date_distance_days[is.na(control_pool$birth_date_distance_days)] <- .Machine$integer.max

  control_pool$util_distance <- abs(dplyr::coalesce(control_pool$preindex_util_total_rate, 0) - dplyr::coalesce(case_row$preindex_util_total_rate, 0))
  control_pool$hosp_distance <- abs(dplyr::coalesce(control_pool$preindex_hosp_days_rate, 0) - dplyr::coalesce(case_row$preindex_hosp_days_rate, 0))

  control_pool[order(
    control_pool$birth_date_distance_days,
    control_pool$util_distance,
    control_pool$hosp_distance,
    control_pool$person_id
  ), , drop = FALSE]
}

select_controls_from_pool <- function(control_pool, case_row, n_needed) {
  if (n_needed <= 0L || !nrow(control_pool)) {
    return(control_pool[0, , drop = FALSE])
  }
  ranked_pool <- rank_controls_for_case(control_pool, case_row)
  ranked_pool[seq_len(min(n_needed, nrow(ranked_pool))), , drop = FALSE]
}

matching_reason_levels <- function() {
  c(
    "eligible",
    "not_unexposed",
    "not_resident_eligible",
    "censored_before_index",
    "birth_after_index",
    "birth_date_caliper"
  )
}

build_control_match_vectors <- function(controls) {
  util_rate <- controls$preindex_util_total_rate
  util_rate[is.na(util_rate)] <- 0
  hosp_rate <- controls$preindex_hosp_days_rate
  hosp_rate[is.na(hosp_rate)] <- 0

  list(
    person_id = controls$person_id,
    unexposed = controls$unexposed,
    is_resident_eligible = controls$is_resident_eligible,
    censor_date = controls$censor_date,
    birth_date = controls$birth_date,
    birth_date_int = controls$birth_date_int,
    municipality = controls$municipality,
    util_rate = util_rate,
    hosp_rate = hosp_rate
  )
}

evaluate_control_indices_for_case <- function(control_indices, case_row, control_vectors, birth_date_caliper_days) {
  if (!length(control_indices)) {
    return(integer())
  }

  reason_codes <- rep.int(1L, length(control_indices))

  unexposed <- control_vectors$unexposed[control_indices]
  resident <- control_vectors$is_resident_eligible[control_indices]
  censor_date <- control_vectors$censor_date[control_indices]
  birth_date <- control_vectors$birth_date[control_indices]
  birth_date_int <- control_vectors$birth_date_int[control_indices]
  case_index_date <- case_row$index_date[[1]]

  reason_codes[is.na(unexposed) | !unexposed] <- 2L
  reason_codes[reason_codes == 1L & (is.na(resident) | !resident)] <- 3L
  reason_codes[reason_codes == 1L & !is.na(censor_date) & censor_date < case_index_date] <- 4L
  reason_codes[reason_codes == 1L & !is.na(birth_date) & !is.na(case_index_date) & birth_date > case_index_date] <- 5L

  case_birth_date_int <- case_row$birth_date_int[[1]] %||% as.integer(case_row$birth_date[[1]])
  if (!is.na(birth_date_caliper_days) && !is.na(case_birth_date_int)) {
    birth_distance <- abs(birth_date_int - case_birth_date_int)
    birth_distance[is.na(birth_distance)] <- .Machine$integer.max
    reason_codes[reason_codes == 1L & birth_distance > birth_date_caliper_days] <- 6L
  }

  reason_codes
}

select_control_indices_from_pool <- function(control_indices, case_row, control_vectors, n_needed) {
  if (n_needed <= 0L || !length(control_indices)) {
    return(integer())
  }

  case_birth_date_int <- case_row$birth_date_int[[1]] %||% as.integer(case_row$birth_date[[1]])
  birth_distance <- abs(control_vectors$birth_date_int[control_indices] - case_birth_date_int)
  birth_distance[is.na(birth_distance)] <- .Machine$integer.max

  case_util_rate <- case_row$preindex_util_total_rate[[1]]
  if (is.na(case_util_rate)) {
    case_util_rate <- 0
  }
  case_hosp_rate <- case_row$preindex_hosp_days_rate[[1]]
  if (is.na(case_hosp_rate)) {
    case_hosp_rate <- 0
  }

  ranked_positions <- order(
    birth_distance,
    abs(control_vectors$util_rate[control_indices] - case_util_rate),
    abs(control_vectors$hosp_rate[control_indices] - case_hosp_rate),
    control_vectors$person_id[control_indices]
  )
  control_indices[ranked_positions[seq_len(min(n_needed, length(ranked_positions)))]]
}

annotate_selected_controls_for_case <- function(selected_controls, case_row) {
  if (!nrow(selected_controls)) {
    return(selected_controls)
  }

  case_birth_date_int <- case_row$birth_date_int[[1]] %||% as.integer(case_row$birth_date[[1]])
  selected_controls$birth_date_distance_days <- abs(selected_controls$birth_date_int - case_birth_date_int)
  selected_controls$birth_date_distance_days[is.na(selected_controls$birth_date_distance_days)] <- .Machine$integer.max

  selected_controls$util_distance <- abs(
    dplyr::coalesce(selected_controls$preindex_util_total_rate, 0) -
      dplyr::coalesce(case_row$preindex_util_total_rate, 0)
  )
  selected_controls$hosp_distance <- abs(
    dplyr::coalesce(selected_controls$preindex_hosp_days_rate, 0) -
      dplyr::coalesce(case_row$preindex_hosp_days_rate, 0)
  )

  selected_controls
}

drop_control_internal_columns <- function(df) {
  df[, setdiff(names(df), ".control_index"), drop = FALSE]
}

bind_matching_rows <- function(rows) {
  if (requireNamespace("data.table", quietly = TRUE)) {
    return(as.data.frame(data.table::rbindlist(rows, use.names = TRUE, fill = TRUE)))
  }

  bind_rows(rows)
}

order_distinct_matched_cohort <- function(matched_cohort_df) {
  if (!nrow(matched_cohort_df)) {
    return(matched_cohort_df)
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(matched_cohort_df)
    data.table::setorderv(dt, c("index_date", "exposed", "person_id"), order = c(1L, -1L, 1L), na.last = TRUE)
    dt <- unique(dt, by = c("person_id", "index_date", "exposed"))
    return(as.data.frame(dt))
  }

  matched_cohort_order <- order(
    matched_cohort_df$index_date,
    -as.integer(matched_cohort_df$exposed),
    as.character(matched_cohort_df$person_id),
    na.last = TRUE
  )
  matched_cohort_df <- matched_cohort_df[matched_cohort_order, , drop = FALSE]
  dedupe_key <- paste(
    as.character(matched_cohort_df$person_id),
    as.character(as.Date(matched_cohort_df$index_date)),
    as.character(matched_cohort_df$exposed),
    sep = "\r"
  )
  matched_cohort_df <- matched_cohort_df[!duplicated(dedupe_key), , drop = FALSE]
  row.names(matched_cohort_df) <- NULL
  matched_cohort_df
}

materialize_control_episodes <- function(control_rows, case_row) {
  if (!nrow(control_rows)) {
    return(drop_control_internal_columns(control_rows))
  }

  adjusted <- control_rows
  case_index_date <- as.Date(case_row$index_date[[1]])
  baseline_years_target <- adjusted$baseline_years_target
  fallback_target <- case_row$baseline_years_target[[1]] %||% 5L
  baseline_years_target[is.na(baseline_years_target)] <- fallback_target
  baseline_years_target <- as.integer(baseline_years_target)

  baseline_start <- case_index_date - 365L * baseline_years_target
  baseline_end <- case_index_date - 1L
  preindex_end <- case_index_date - default_preindex_lag_days()

  birth_date <- as.Date(adjusted$birth_date)
  observed_start <- baseline_start
  birth_later <- !is.na(birth_date) & birth_date > observed_start
  observed_start[birth_later] <- birth_date[birth_later]

  observed_years <- rep(NA_real_, nrow(adjusted))
  degenerate <- !is.na(preindex_end) & !is.na(observed_start) & preindex_end < observed_start
  observed_years[degenerate] <- 0
  good <- !is.na(preindex_end) & !is.na(observed_start) & !degenerate
  observed_years[good] <- as.numeric(preindex_end - observed_start[good] + 1L) / 365.25

  adjusted$index_date <- case_index_date
  adjusted$baseline_start <- baseline_start
  adjusted$baseline_end <- baseline_end
  adjusted$baseline_observed_person_years <- observed_years
  adjusted$baseline_years_target <- baseline_years_target
  adjusted$baseline_years_observed <- floor(observed_years)
  adjusted$baseline_years_effective_required <- baseline_years_target
  adjusted$baseline_truncated_by_source_window <- ifelse(
    is.na(birth_date),
    TRUE,
    birth_date > baseline_start
  )
  adjusted$truncated_lookback_flag <- adjusted$baseline_truncated_by_source_window
  adjusted$exposure_date <- as.Date(NA)
  adjusted$exposed <- FALSE
  adjusted$unexposed <- TRUE
  adjusted$diagnosis_group <- "Unexposed"
  adjusted$severity <- "Unexposed"
  adjusted$scd_is_case <- FALSE
  adjusted$scd_first_date <- as.Date(NA)
  adjusted$scd_first_chapter <- NA_character_
  drop_control_internal_columns(adjusted)
}

materialize_control_episode <- function(control_row, case_row) {
  materialize_control_episodes(control_row, case_row)
}

materialize_control_episodes_for_pairs <- function(control_rows, case_index_dates, case_baseline_years_target) {
  if (!nrow(control_rows)) {
    return(drop_control_internal_columns(control_rows))
  }

  adjusted <- control_rows
  case_index_dates <- as.Date(case_index_dates)
  baseline_years_target <- adjusted$baseline_years_target
  fallback_target <- case_baseline_years_target %||% rep(5L, nrow(adjusted))
  fallback_target <- as.integer(fallback_target)
  fallback_target[is.na(fallback_target)] <- 5L
  baseline_years_target[is.na(baseline_years_target)] <- fallback_target[is.na(baseline_years_target)]
  baseline_years_target <- as.integer(baseline_years_target)

  baseline_start <- case_index_dates - 365L * baseline_years_target
  baseline_end <- case_index_dates - 1L
  preindex_end <- case_index_dates - default_preindex_lag_days()

  birth_date <- as.Date(adjusted$birth_date)
  observed_start <- baseline_start
  birth_later <- !is.na(birth_date) & birth_date > observed_start
  observed_start[birth_later] <- birth_date[birth_later]

  observed_years <- rep(NA_real_, nrow(adjusted))
  degenerate <- !is.na(preindex_end) & !is.na(observed_start) & preindex_end < observed_start
  observed_years[degenerate] <- 0
  good <- !is.na(preindex_end) & !is.na(observed_start) & !degenerate
  observed_years[good] <- as.numeric(preindex_end[good] - observed_start[good] + 1L) / 365.25

  adjusted$index_date <- case_index_dates
  adjusted$baseline_start <- baseline_start
  adjusted$baseline_end <- baseline_end
  adjusted$baseline_observed_person_years <- observed_years
  adjusted$baseline_years_target <- baseline_years_target
  adjusted$baseline_years_observed <- floor(observed_years)
  adjusted$baseline_years_effective_required <- baseline_years_target
  adjusted$baseline_truncated_by_source_window <- ifelse(
    is.na(birth_date),
    TRUE,
    birth_date > baseline_start
  )
  adjusted$truncated_lookback_flag <- adjusted$baseline_truncated_by_source_window
  adjusted$exposure_date <- as.Date(NA)
  adjusted$exposed <- FALSE
  adjusted$unexposed <- TRUE
  adjusted$diagnosis_group <- "Unexposed"
  adjusted$severity <- "Unexposed"
  adjusted$scd_is_case <- FALSE
  adjusted$scd_first_date <- as.Date(NA)
  adjusted$scd_first_chapter <- NA_character_
  drop_control_internal_columns(adjusted)
}

build_matched_pairs <- function(case_row, selected_controls, tier_label) {
  if (!nrow(selected_controls)) {
    return(data.frame())
  }

  tier <- if (length(tier_label) == nrow(selected_controls)) {
    tier_label
  } else {
    rep(tier_label, nrow(selected_controls))
  }

  data.frame(
    case_id = rep(case_row$person_id, nrow(selected_controls)),
    control_id = selected_controls$person_id,
    tier = tier,
    case_index_date = rep(case_row$index_date, nrow(selected_controls)),
    matched_index_date = rep(case_row$index_date, nrow(selected_controls)),
    case_birth_date = rep(case_row$birth_date, nrow(selected_controls)),
    control_birth_date = selected_controls$birth_date,
    birth_date_distance_days = {
      distance <- abs(as.integer(selected_controls$birth_date) - as.integer(case_row$birth_date[[1]]))
      distance[is.na(distance)] <- .Machine$integer.max
      distance
    },
    municipality = rep(case_row$municipality, nrow(selected_controls)),
    region = rep(case_row$region, nrow(selected_controls)),
    stringsAsFactors = FALSE
  )
}

annotate_matched_cohort_sets <- function(matched_cohort_df, matched_pairs_df) {
  if (!nrow(matched_pairs_df)) {
    matched_cohort_df$matched_set_id <- NA_character_
    matched_cohort_df$n_controls <- 0L
    matched_cohort_df$match_weight <- NA_real_
    return(matched_cohort_df)
  }

  pair_case_key <- as.character(matched_pairs_df$case_id)
  pair_control_key <- as.character(matched_pairs_df$control_id)
  unique_case_keys <- unique(pair_case_key)
  n_controls_by_case <- tabulate(match(pair_case_key, unique_case_keys), nbins = length(unique_case_keys))

  first_control_rows <- !duplicated(pair_control_key)
  cohort_person_key <- as.character(matched_cohort_df$person_id)
  control_match <- match(cohort_person_key, pair_control_key[first_control_rows])
  matched_set_id <- pair_case_key[first_control_rows][control_match]

  exposed_rows <- !is.na(matched_cohort_df$exposed) & matched_cohort_df$exposed
  matched_set_id[exposed_rows] <- cohort_person_key[exposed_rows]
  set_size_match <- match(matched_set_id, unique_case_keys)
  n_controls <- rep(0L, nrow(matched_cohort_df))
  known_set_size <- !is.na(set_size_match)
  n_controls[known_set_size] <- n_controls_by_case[set_size_match[known_set_size]]

  matched_cohort_df$matched_set_id <- matched_set_id
  matched_cohort_df$n_controls <- n_controls
  matched_cohort_df$match_weight <- ifelse(exposed_rows, 1, ifelse(n_controls > 0L, 1 / n_controls, NA_real_))
  matched_cohort_df
}

rebuild_matched_cohort_from_pairs <- function(baseline_df, matched_pairs_df) {
  assert_required_columns(
    baseline_df,
    c("person_id", "exposed", "unexposed", "birth_date", "index_date",
      "baseline_years_target"),
    "baseline_df for matched cohort refresh"
  )
  assert_required_columns(
    matched_pairs_df,
    c("case_id", "control_id", "case_index_date"),
    "matched_pairs_df for matched cohort refresh"
  )

  if (!nrow(matched_pairs_df)) {
    return(annotate_matched_cohort_sets(baseline_df[0, , drop = FALSE], matched_pairs_df))
  }

  working_df <- as.data.frame(baseline_df, stringsAsFactors = FALSE)
  matched_pairs_df <- as.data.frame(matched_pairs_df, stringsAsFactors = FALSE)
  matched_pairs_df$case_index_date <- as.Date(matched_pairs_df$case_index_date)

  baseline_person_key <- as.character(working_df$person_id)
  if (anyNA(baseline_person_key)) {
    stop("Cannot refresh matched cohort: baseline_df has missing person_id values.")
  }
  if (anyDuplicated(baseline_person_key)) {
    duplicated_ids <- unique(baseline_person_key[duplicated(baseline_person_key)])
    stop(sprintf(
      "Cannot refresh matched cohort: baseline_df has duplicated person_id values: %s",
      paste(utils::head(duplicated_ids, 10), collapse = ", ")
    ))
  }

  pair_case_key <- as.character(matched_pairs_df$case_id)
  pair_control_key <- as.character(matched_pairs_df$control_id)
  case_date_key <- paste(pair_case_key, as.character(matched_pairs_df$case_index_date), sep = "\r")
  unique_case_date_rows <- !duplicated(case_date_key)
  case_keys_by_date <- pair_case_key[unique_case_date_rows]
  cases_with_multiple_dates <- unique(case_keys_by_date[duplicated(case_keys_by_date)])
  if (length(cases_with_multiple_dates)) {
    stop(sprintf(
      "Cannot refresh matched cohort: case_id values map to multiple case_index_date values: %s",
      paste(utils::head(cases_with_multiple_dates, 10), collapse = ", ")
    ))
  }

  pair_case_row_index <- match(pair_case_key, baseline_person_key)
  if (anyNA(pair_case_row_index)) {
    missing_cases <- unique(pair_case_key[is.na(pair_case_row_index)])
    stop(sprintf(
      "Cannot refresh matched cohort: case_id values are missing from baseline_df: %s",
      paste(utils::head(missing_cases, 10), collapse = ", ")
    ))
  }

  unique_case_rows <- !duplicated(pair_case_key)
  case_row_index <- pair_case_row_index[unique_case_rows]
  control_row_index <- match(pair_control_key, baseline_person_key)
  if (anyNA(control_row_index)) {
    missing_controls <- unique(pair_control_key[is.na(control_row_index)])
    stop(sprintf(
      "Cannot refresh matched cohort: control_id values are missing from baseline_df: %s",
      paste(utils::head(missing_controls, 10), collapse = ", ")
    ))
  }

  cases <- working_df[case_row_index, , drop = FALSE]
  cases$index_date <- matched_pairs_df$case_index_date[unique_case_rows]

  matched_control_df <- materialize_control_episodes_for_pairs(
    working_df[control_row_index, , drop = FALSE],
    matched_pairs_df$case_index_date,
    working_df$baseline_years_target[pair_case_row_index]
  )
  matched_cohort_df <- bind_matching_rows(list(cases, matched_control_df))
  matched_cohort_df <- order_distinct_matched_cohort(matched_cohort_df)

  annotate_matched_cohort_sets(matched_cohort_df, matched_pairs_df)
}

run_risk_set_matching <- function(
  baseline_df,
  match_ratios = default_match_ratios(),
  seed = 42L,
  birth_date_caliper_days = default_birth_date_caliper_days()
) {
  assert_required_columns(
    baseline_df,
    c("person_id", "exposed", "unexposed", "scd_is_case", "sex", "region",
      "birth_date", "index_date", "censor_date", "is_resident_eligible",
      "preindex_util_total_rate", "preindex_hosp_days_rate"),
    "baseline_df for matching"
  )
  set.seed(as.integer(seed))

  target_ratio <- resolve_target_ratio(match_ratios)
  working_df <- as.data.frame(baseline_df, stringsAsFactors = FALSE)
  working_df$municipality[is.na(working_df$municipality)] <- ""
  working_df$region[is.na(working_df$region)] <- ""
  working_df$birth_date_int <- as.integer(working_df$birth_date)

  cases <- working_df |>
    filter(exposed, scd_is_case) |>
    arrange(index_date, person_id)

  controls <- working_df |>
    filter(unexposed) |>
    arrange(person_id)
  controls$.control_index <- seq_len(nrow(controls))
  control_groups <- split(controls$.control_index, sex_region_key(controls$sex, controls$region))
  control_vectors <- build_control_match_vectors(controls)

  used_controls <- rep(FALSE, nrow(controls))
  unused_control_count <- length(used_controls)
  matched_pairs_list <- vector("list", nrow(cases))
  matched_case_rows <- vector("list", nrow(cases))
  diagnostics_rows <- vector("list", nrow(cases))
  control_episode_rows <- vector("list", nrow(cases))
  exclusion_summary_rows <- vector("list", nrow(cases))
  reason_levels <- matching_reason_levels()

  for (i in seq_len(nrow(cases))) {
    case_row <- cases[i, , drop = FALSE]
    case_id <- case_row$person_id[[1]]
    group_key <- sex_region_key(case_row$sex[[1]], case_row$region[[1]])
    control_indices <- control_groups[[group_key]]
    if (is.null(control_indices)) {
      control_indices <- integer()
    }

    total_unused_controls <- unused_control_count
    if (length(control_indices)) {
      available_indices <- control_indices[!used_controls[control_indices]]
    } else {
      available_indices <- integer()
    }

    if (length(available_indices)) {
      eligibility_reason <- evaluate_control_indices_for_case(
        available_indices,
        case_row,
        control_vectors,
        birth_date_caliper_days = birth_date_caliper_days
      )
      eligible_control_indices <- available_indices[eligibility_reason == 1L]
    } else {
      eligibility_reason <- integer()
      eligible_control_indices <- integer()
    }

    municipality_pool_indices <- eligible_control_indices[
      control_vectors$municipality[eligible_control_indices] == case_row$municipality[[1]]
    ]
    municipality_control_indices <- select_control_indices_from_pool(
      municipality_pool_indices,
      case_row,
      control_vectors,
      target_ratio
    )

    remaining_needed <- target_ratio - length(municipality_control_indices)
    selected_control_indices <- municipality_control_indices

    region_pool_indices <- eligible_control_indices[!(eligible_control_indices %in% selected_control_indices)]
    region_control_indices <- select_control_indices_from_pool(
      region_pool_indices,
      case_row,
      control_vectors,
      remaining_needed
    )

    selected_control_indices <- c(municipality_control_indices, region_control_indices)
    municipality_controls <- controls[municipality_control_indices, , drop = FALSE]
    region_controls <- controls[region_control_indices, , drop = FALSE]
    selected_controls <- controls[selected_control_indices, , drop = FALSE]
    selected_controls <- annotate_selected_controls_for_case(selected_controls, case_row)
    if (length(selected_control_indices)) {
      used_controls[selected_control_indices] <- TRUE
      unused_control_count <- unused_control_count - length(selected_control_indices)
    }

    selected_tiers <- c(
      rep("municipality", nrow(municipality_controls)),
      rep("region_fallback", nrow(region_controls))
    )
    matched_pairs <- build_matched_pairs(case_row, selected_controls, selected_tiers)
    matched_pairs_list[[i]] <- matched_pairs

    if (nrow(selected_controls)) {
      matched_case_rows[[i]] <- case_row
      control_episode_rows[[i]] <- materialize_control_episodes(selected_controls, case_row)
    } else {
      matched_case_rows[[i]] <- case_row[0, , drop = FALSE]
      control_episode_rows[[i]] <- drop_control_internal_columns(selected_controls[0, , drop = FALSE])
    }

    diagnostics_rows[[i]] <- data.frame(
      case_id = case_id,
      case_index_date = case_row$index_date[[1]],
      unused_controls = total_unused_controls,
      same_sex_region_candidates = length(available_indices),
      eligible_candidates = length(eligible_control_indices),
      municipality_candidates = length(municipality_pool_indices),
      region_fallback_candidates = length(region_pool_indices),
      municipality_matches = nrow(municipality_controls),
      region_fallback_matches = nrow(region_controls),
      achieved_controls = nrow(selected_controls),
      target_controls = target_ratio,
      fully_matched = nrow(selected_controls) >= target_ratio,
      stringsAsFactors = FALSE
    )

    exclusion_counts <- tabulate(eligibility_reason, nbins = length(reason_levels))
    exclusion_summary_rows[[i]] <- data.frame(
      case_id = case_id,
      reason = reason_levels,
      count = exclusion_counts,
      stringsAsFactors = FALSE
    )
  }

  matched_pairs_df <- bind_rows(matched_pairs_list)
  matched_case_df <- bind_rows(matched_case_rows)
  matched_control_df <- bind_rows(control_episode_rows)
  matched_cohort_df <- bind_rows(matched_case_df, matched_control_df) |>
    arrange(index_date, desc(exposed), person_id) |>
    distinct(person_id, index_date, exposed, .keep_all = TRUE)
  matched_cohort_df <- annotate_matched_cohort_sets(matched_cohort_df, matched_pairs_df)

  diagnostics_df <- bind_rows(diagnostics_rows)
  exclusion_summary_df <- bind_rows(exclusion_summary_rows) |>
    group_by(reason) |>
    summarise(count = sum(count), .groups = "drop")
  summary_df <- data.frame(
    metric = c(
      "eligible_cases",
      "matched_cases",
      "unmatched_cases",
      "matched_pairs",
      "municipality_pairs",
      "region_fallback_pairs",
      "target_ratio",
      "birth_date_caliper_days"
    ),
    value = c(
      nrow(cases),
      sum(diagnostics_df$achieved_controls > 0),
      sum(diagnostics_df$achieved_controls == 0),
      nrow(matched_pairs_df),
      sum(matched_pairs_df$tier == "municipality"),
      sum(matched_pairs_df$tier == "region_fallback"),
      target_ratio,
      birth_date_caliper_days
    ),
    stringsAsFactors = FALSE
  )

  list(
    matched_pairs = matched_pairs_df,
    matched_cohort = matched_cohort_df,
    diagnostics = diagnostics_df,
    summary = summary_df,
    matching_exclusion_summary = exclusion_summary_df
  )
}

write_refreshed_matched_cohort_output <- function(baseline_df, config, matched_pairs = NULL) {
  ensure_output_dir(config)
  matched_pairs_path <- output_file(config, "matched_pairs")
  if (is.null(matched_pairs)) {
    if (!file.exists(matched_pairs_path)) {
      stop(sprintf("Matched pairs not found at %s. Run matching once before refresh_matched_cohort.", matched_pairs_path))
    }
    matched_pairs <- timed_matching_step("read matched pairs", {
      arrow::read_parquet(matched_pairs_path)
    })
  }

  refreshed <- timed_matching_step(
    sprintf("rebuild matched cohort from %d matched pairs", nrow(matched_pairs)),
    rebuild_matched_cohort_from_pairs(baseline_df, matched_pairs)
  )
  matched_cohort_path <- output_file(config, "matched_cohort")
  refresh_notes_path <- output_file(config, "matched_cohort_refresh_notes")
  ensure_output_parent(matched_cohort_path)
  ensure_output_parent(refresh_notes_path)
  timed_matching_step("write refreshed matched cohort", {
    arrow::write_parquet(refreshed, matched_cohort_path)
  })
  writeLines(
    c(
      sprintf("refreshed_at=%s", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
      sprintf("matched_pairs_path=%s", matched_pairs_path),
      sprintf("matched_pairs_rows=%s", nrow(matched_pairs)),
      sprintf("matched_cohort_rows=%s", nrow(refreshed)),
      "note=Matched pair assignments were reused; matched_cohort covariates were rematerialized from the current baseline_dataset."
    ),
    refresh_notes_path
  )

  list(
    matched_cohort_path = matched_cohort_path,
    refresh_notes_path = refresh_notes_path
  )
}

write_matching_outputs <- function(
  baseline_df,
  config,
  match_ratios = default_match_ratios(),
  seed = 42L,
  birth_date_caliper_days = default_birth_date_caliper_days()
) {
  ensure_output_dir(config)
  result <- run_risk_set_matching(
    baseline_df,
    match_ratios = match_ratios,
    seed = seed,
    birth_date_caliper_days = birth_date_caliper_days
  )

  matched_pairs_path <- output_file(config, "matched_pairs")
  matched_cohort_path <- output_file(config, "matched_cohort")
  diagnostics_path <- output_file(config, "matching_diagnostics")
  summary_path <- output_file(config, "matching_summary")
  exclusion_summary_path <- output_file(config, "matching_exclusion_summary")
  lapply(
    c(matched_pairs_path, matched_cohort_path, diagnostics_path, summary_path, exclusion_summary_path),
    ensure_output_parent
  )

  arrow::write_parquet(result$matched_pairs, matched_pairs_path)
  arrow::write_parquet(result$matched_cohort, matched_cohort_path)
  write_csv_file(result$diagnostics, diagnostics_path)
  write_csv_file(result$summary, summary_path)
  write_csv_file(result$matching_exclusion_summary, exclusion_summary_path)

  list(
    matched_pairs_path = matched_pairs_path,
    matched_cohort_path = matched_cohort_path,
    diagnostics_path = diagnostics_path,
    summary_path = summary_path,
    exclusion_summary_path = exclusion_summary_path
  )
}
