assert_required_columns <- function(data, required_columns, object_name) {
  missing_columns <- setdiff(required_columns, names(data))
  if (length(missing_columns)) {
    stop(
      sprintf(
        "%s is missing required columns: %s",
        object_name,
        paste(missing_columns, collapse = ", ")
      )
    )
  }

  invisible(data)
}

assert_unique_key <- function(data, key, object_name) {
  duplicated_keys <- duplicated(data[[key]])
  if (any(duplicated_keys)) {
    dup_values <- unique(data[[key]][duplicated_keys])
    stop(
      sprintf(
        "%s has duplicated `%s` values: %s",
        object_name,
        key,
        paste(utils::head(dup_values, 10), collapse = ", ")
      )
    )
  }

  invisible(data)
}

# Asserts the right-hand side of an upcoming join is unique on `key` columns.
# Call this before a left_join to detect fan-out before it corrupts downstream counts.
assert_unique_join_key <- function(data, key, object_name) {
  missing_key_cols <- setdiff(key, names(data))
  if (length(missing_key_cols)) {
    stop(sprintf(
      "%s is missing join-key column(s): %s",
      object_name, paste(missing_key_cols, collapse = ", ")
    ))
  }
  if (nrow(data) > 0L && anyDuplicated(data[, key, drop = FALSE]) > 0) {
    n_dup <- sum(duplicated(data[, key, drop = FALSE]))
    stop(sprintf(
      "%s has %d duplicate row(s) on key (%s) — join would fan out unexpectedly.",
      object_name, n_dup, paste(key, collapse = ", ")
    ))
  }
  invisible(data)
}

# Warns when a column has a suspiciously high NA rate after a join,
# which typically indicates a type mismatch or missing key in the right-hand side.
warn_high_na_rate <- function(data, col, threshold = 0.5, object_name) {
  if (!(col %in% names(data)) || !nrow(data)) return(invisible(data))
  na_rate <- mean(is.na(data[[col]]))
  if (na_rate > threshold) {
    warning(sprintf(
      "%s: column '%s' is %.0f%% NA after join — verify join-key types and upstream data.",
      object_name, col, na_rate * 100
    ), call. = FALSE)
  }
  invisible(data)
}

write_validation_note <- function(lines, config, file_name = "validation_notes.txt") {
  ensure_output_dir(config)
  path <- file.path(config$output_dir, file_name)
  writeLines(lines, path)
  invisible(path)
}
