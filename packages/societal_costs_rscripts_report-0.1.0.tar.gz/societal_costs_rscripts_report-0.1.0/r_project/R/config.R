detect_project_root <- function() {
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    return(dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE))))
  }
  if (requireNamespace("rstudioapi", quietly = TRUE) &&
      rstudioapi::isAvailable() &&
      nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    return(dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/"))))
  }
  normalizePath(getwd(), winslash = "/")
}

detect_repo_root <- function(project_root, explicit = NULL) {
  if (!is.null(explicit) && length(explicit) == 1L && !is.na(explicit) && nzchar(explicit)) {
    return(normalizePath(explicit, winslash = "/", mustWork = FALSE))
  }

  current <- normalizePath(project_root, winslash = "/", mustWork = FALSE)
  visited <- character(0)

  repeat {
    if (current %in% visited) {
      break
    }
    visited <- c(visited, current)

    has_direct_data_dirs <- dir.exists(file.path(current, "test_out")) ||
      dir.exists(file.path(current, "test_data"))
    has_tmp_data_dirs <- dir.exists(file.path(current, "tmp", "test_out")) ||
      dir.exists(file.path(current, "tmp", "test_data"))
    has_data_dirs <- has_direct_data_dirs || has_tmp_data_dirs

    is_rust_workspace <- dir.exists(file.path(current, "crates")) && has_data_dirs
    has_top_level_r_project <- dir.exists(file.path(current, "r_project", "R")) &&
      dir.exists(file.path(current, "r_project", "scripts"))
    has_legacy_nested_r_project <- dir.exists(
      file.path(current, "src", "societal_costs_r_bundle", "r_project", "R")
    ) &&
      dir.exists(file.path(current, "src", "societal_costs_r_bundle", "r_project", "scripts"))
    is_bundle_repo <- file.exists(file.path(current, "pyproject.toml")) &&
      (has_top_level_r_project || has_legacy_nested_r_project)
    is_runtime_project <- dir.exists(file.path(current, "R")) &&
      dir.exists(file.path(current, "scripts")) &&
      has_data_dirs

    if (is_rust_workspace || is_bundle_repo || is_runtime_project) {
      return(current)
    }

    parent <- dirname(current)
    if (identical(parent, current)) {
      break
    }
    current <- parent
  }

  if (dir.exists(file.path(project_root, "R")) &&
      dir.exists(file.path(project_root, "scripts"))) {
    return(normalizePath(project_root, winslash = "/", mustWork = FALSE))
  }

  dirname(normalizePath(project_root, winslash = "/", mustWork = FALSE))
}

get_script_path <- function() {
  file_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
  if (!length(file_arg)) {
    stop("This script must be run with Rscript.")
  }

  normalizePath(sub("^--file=", "", file_arg[[1]]), winslash = "/", mustWork = TRUE)
}

parse_cli_args <- function(args = commandArgs(trailingOnly = TRUE)) {
  parsed <- list()

  for (arg in args) {
    if (!startsWith(arg, "--")) {
      next
    }

    parts <- strsplit(sub("^--", "", arg), "=", fixed = TRUE)[[1]]
    key <- gsub("-", "_", parts[[1]], fixed = TRUE)
    value <- if (length(parts) > 1L) {
      paste(parts[-1L], collapse = "=")
    } else {
      TRUE
    }
    parsed[[key]] <- value
  }

  parsed
}

parse_bool_flag <- function(value, default = FALSE) {
  if (is.null(value) || is.na(value) || identical(value, "")) {
    return(default)
  }
  if (is.logical(value)) {
    return(isTRUE(value))
  }

  normalized <- tolower(as.character(value))
  normalized %in% c("1", "true", "t", "yes", "y", "on")
}

parse_int_option <- function(value, default) {
  if (is.null(value) || length(value) == 0L ||
      (length(value) == 1L && (is.na(value) || identical(value, "")))) {
    return(as.integer(default))
  }

  parsed <- suppressWarnings(as.integer(value[[1]]))
  if (is.na(parsed)) {
    as.integer(default)
  } else {
    parsed
  }
}

`%||%` <- function(lhs, rhs) {
  if (is.null(lhs) || (length(lhs) == 1L && (is.na(lhs) || identical(lhs, "")))) {
    rhs
  } else {
    lhs
  }
}

production_path_defaults <- function() {
  list(
    intermediate_root = "E:/workdata/708245/CDEF/Personer/tkra0028/societal_costs/sc_output",
    raw_register_root = "E:/workdata/708245/data/202603",
    raw_popc_dir = "E:/workdata/708245/data/popc",
    raw_indberetningmedpris_path = paste0(
      "E:/workdata/708245/CDEF/Projekter/SAS_konvertering/binary_test/",
      "indberetningmedpris/indberetningmedpris.parquet"
    )
  )
}

is_windows_runtime <- function() {
  identical(.Platform$OS.type, "windows") ||
    grepl("^[A-Za-z]:/", normalizePath(getwd(), winslash = "/", mustWork = FALSE))
}

normalize_config_path <- function(path) {
  normalizePath(path, winslash = "/", mustWork = FALSE)
}

resolve_raw_family_dir <- function(explicit, raw_register_root, subdir) {
  if (!is.null(explicit) && length(explicit) == 1L && !is.na(explicit) && nzchar(explicit)) {
    return(normalize_config_path(explicit))
  }

  nested_dir <- file.path(raw_register_root, subdir)
  if (dir.exists(nested_dir)) {
    normalize_config_path(nested_dir)
  } else {
    raw_register_root
  }
}

resolve_raw_indberetningmedpris_path <- function(explicit, raw_register_root, use_production_paths) {
  if (!is.null(explicit) && length(explicit) == 1L && !is.na(explicit) && nzchar(explicit)) {
    return(normalize_config_path(explicit))
  }

  env_path <- Sys.getenv("SOCIETAL_COSTS_INDBERETNINGMEDPRIS_PATH", unset = "")
  if (nzchar(env_path)) {
    return(normalize_config_path(env_path))
  }

  defaults <- production_path_defaults()
  if (isTRUE(use_production_paths)) {
    return(normalize_config_path(defaults$raw_indberetningmedpris_path))
  }

  flat_path <- file.path(raw_register_root, "indberetningmedpris.parquet")
  if (file.exists(flat_path)) {
    normalize_config_path(flat_path)
  } else {
    normalize_config_path(file.path(raw_register_root, "hospital_drugs", "indberetningmedpris.parquet"))
  }
}

default_project_config <- function(project_root = getwd(), args = parse_cli_args()) {
  project_root <- normalize_config_path(project_root)
  repo_root <- detect_repo_root(
    project_root,
    args$repo_root %||% Sys.getenv("SOCIETAL_COSTS_REPO_ROOT", unset = "")
  )

  use_production_paths <- parse_bool_flag(
    args$use_production_paths %||% Sys.getenv("SOCIETAL_COSTS_USE_PRODUCTION_PATHS", unset = ""),
    default = is_windows_runtime()
  )

  defaults <- production_path_defaults()
  intermediate_root <- normalize_config_path(
    args$intermediate_root %||%
      args$test_out_root %||%
      Sys.getenv("SOCIETAL_COSTS_INTERMEDIATE_ROOT", unset = "") %||%
      if (isTRUE(use_production_paths)) defaults$intermediate_root else file.path(repo_root, "test_out")
  )
  raw_register_root <- normalize_config_path(
    args$raw_register_root %||%
      args$raw_data_dir %||%
      Sys.getenv("SOCIETAL_COSTS_RAW_REGISTER_ROOT", unset = "") %||%
      if (isTRUE(use_production_paths)) defaults$raw_register_root else file.path(repo_root, "test_data")
  )

  list(
    project_root = project_root,
    repo_root = repo_root,
    use_production_paths = use_production_paths,
    intermediate_root = intermediate_root,
    test_out_root = intermediate_root,
    raw_register_root = raw_register_root,
    cohort_dir = normalizePath(
      args$cohort_dir %||% file.path(intermediate_root, "cohort"),
      winslash = "/",
      mustWork = FALSE
    ),
    core_dir = normalizePath(
      args$core_dir %||% file.path(intermediate_root, "core"),
      winslash = "/",
      mustWork = FALSE
    ),
    registers_dir = normalizePath(
      args$registers_dir %||% file.path(intermediate_root, "registers"),
      winslash = "/",
      mustWork = FALSE
    ),
    raw_data_dir = raw_register_root,
    raw_popc_dir = resolve_raw_family_dir(
      args$raw_popc_dir %||%
        Sys.getenv("SOCIETAL_COSTS_RAW_POPC_DIR", unset = "") %||%
        if (isTRUE(use_production_paths)) defaults$raw_popc_dir else NULL,
      raw_register_root,
      "popc"
    ),
    raw_lmdb_dir = resolve_raw_family_dir(args$raw_lmdb_dir, raw_register_root, "lmdb"),
    raw_primary_dir = resolve_raw_family_dir(args$raw_primary_dir, raw_register_root, "primary_sector"),
    raw_drg_dir = resolve_raw_family_dir(args$raw_drg_dir, raw_register_root, "drg"),
    raw_indberetningmedpris_path = resolve_raw_indberetningmedpris_path(
      args$raw_indberetningmedpris_path,
      raw_register_root,
      use_production_paths
    ),
    output_dir = normalizePath(
      args$output_dir %||% file.path(project_root, "output"),
      winslash = "/",
      mustWork = FALSE
    ),
    output_layout = tolower(as.character(
      args$output_layout %||% Sys.getenv("SOCIETAL_COSTS_OUTPUT_LAYOUT", unset = "") %||% "structured"
    )),
    baseline_years_target = 5L,
    preindex_lag_days = 91L,
    reference_price_year = as.integer(args$reference_price_year %||% 2023L),
    use_hospital_drugs = parse_bool_flag(args$use_hospital_drugs, default = FALSE),
    run_parental_education_diagnostics = parse_bool_flag(
      args$run_parental_education_diagnostics %||%
        Sys.getenv("SOCIETAL_COSTS_RUN_PARENTAL_EDUCATION_DIAGNOSTICS", unset = ""),
      default = FALSE
    ),
    reuse_prepared_baseline_artifacts = parse_bool_flag(
      args$reuse_prepared_baseline_artifacts %||%
        Sys.getenv("SOCIETAL_COSTS_REUSE_PREPARED_BASELINE_ARTIFACTS", unset = ""),
      default = TRUE
    ),
    force_rebuild_prepared_baseline_artifacts = parse_bool_flag(
      args$force_rebuild_prepared_baseline_artifacts %||%
        Sys.getenv("SOCIETAL_COSTS_FORCE_REBUILD_PREPARED_BASELINE_ARTIFACTS", unset = ""),
      default = FALSE
    ),
    force_rebuild_parent_covariates = parse_bool_flag(
      args$force_rebuild_parent_covariates %||%
        Sys.getenv("SOCIETAL_COSTS_FORCE_REBUILD_PARENT_COVARIATES", unset = ""),
      default = FALSE
    ),
    reuse_direct_cost_artifacts = parse_bool_flag(
      args$reuse_direct_cost_artifacts %||%
        Sys.getenv("SOCIETAL_COSTS_REUSE_DIRECT_COST_ARTIFACTS", unset = ""),
      default = TRUE
    ),
    force_rebuild_direct_cost_artifacts = parse_bool_flag(
      args$force_rebuild_direct_cost_artifacts %||%
        Sys.getenv("SOCIETAL_COSTS_FORCE_REBUILD_DIRECT_COST_ARTIFACTS", unset = ""),
      default = FALSE
    ),
    skip_lpr_legacy_validation = parse_bool_flag(
      args$skip_lpr_legacy_validation %||%
        Sys.getenv("SOCIETAL_COSTS_SKIP_LPR_LEGACY_VALIDATION", unset = ""),
      default = TRUE
    ),
    direct_cost_scope = tolower(as.character(
      args$direct_cost_scope %||%
        Sys.getenv("SOCIETAL_COSTS_DIRECT_COST_SCOPE", unset = "") %||%
        "matched_analysis"
    )),
    direct_cost_n_cores = max(
      1L,
      parse_int_option(
        args$direct_cost_n_cores %||%
          Sys.getenv("SOCIETAL_COSTS_DIRECT_COST_N_CORES", unset = ""),
        default = 1L
      )
    ),
    skip_discounts = parse_bool_flag(
      args$skip_discounts %||%
        Sys.getenv("SOCIETAL_COSTS_SKIP_DISCOUNTS", unset = ""),
      default = FALSE
    ),
    skip_survivors = parse_bool_flag(
      args$skip_survivors %||%
        Sys.getenv("SOCIETAL_COSTS_SKIP_SURVIVORS", unset = ""),
      default = FALSE
    ),
    write_full_followup_panel = parse_bool_flag(
      args$write_full_followup_panel %||%
        Sys.getenv("SOCIETAL_COSTS_WRITE_FULL_FOLLOWUP_PANEL", unset = ""),
      default = FALSE
    ),
    skip_followup_sensitivities = parse_bool_flag(
      args$skip_followup_sensitivities %||%
        Sys.getenv("SOCIETAL_COSTS_SKIP_FOLLOWUP_SENSITIVITIES", unset = ""),
      default = FALSE
    ),
    skip_followup_90d_sensitivity = parse_bool_flag(
      args$skip_followup_90d_sensitivity %||%
        Sys.getenv("SOCIETAL_COSTS_SKIP_FOLLOWUP_90D_SENSITIVITY", unset = ""),
      default = FALSE
    ),
    skip_followup_all_entry_years = parse_bool_flag(
      args$skip_followup_all_entry_years %||%
        Sys.getenv("SOCIETAL_COSTS_SKIP_FOLLOWUP_ALL_ENTRY_YEARS", unset = ""),
      default = FALSE
    ),
    hospital_drugs_usage_path = args$hospital_drugs_usage_path %||%
      file.path(intermediate_root, "registers", "hospital_drugs", "hospital_drugs_usage.parquet"),
    education_asset_path = normalizePath(file.path(project_root, "AUDD_HOVED_E_L1L5_K.txt"), winslash = "/", mustWork = FALSE),
    hfaudd_json_path = normalizePath(
      file.path(project_root, "HFAUDD.json"),
      winslash = "/",
      mustWork = FALSE
    )
  )
}
