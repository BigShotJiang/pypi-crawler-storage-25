suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

load_study_population_ids <- function(config) {
  baseline_path <- resolve_existing_output_file(config, "baseline_dataset")
  if (!file.exists(baseline_path)) {
    stop(sprintf(
      "Baseline dataset not found at %s. Run scripts/01_build_baseline_dataset.R before building direct-cost artifacts.",
      baseline_path
    ))
  }

  baseline_df <- arrow::read_parquet(baseline_path, col_select = "person_id")
  ids <- unique(as.character(baseline_df$person_id))
  ids <- ids[!is.na(ids) & nzchar(ids)]
  if (!length(ids)) {
    stop(sprintf("No study population IDs found in %s.", baseline_path))
  }
  ids
}

list_raw_parquet_files <- function(directory, pattern) {
  if (!dir.exists(directory)) {
    return(character(0))
  }

  list.files(
    directory,
    pattern = pattern,
    full.names = TRUE,
    recursive = FALSE
  ) |>
    sort()
}

extract_year_from_filename <- function(path, prefix) {
  file_name <- basename(path)
  year_text <- sub(sprintf("^%s([0-9]{4}).*$", prefix), "\\1", file_name)
  suppressWarnings(as.integer(year_text))
}

is_partial_year_file <- function(path, prefix) {
  grepl(sprintf("^%s[0-9]{6}.*\\.parquet$", prefix), basename(path))
}

filter_raw_files_by_year <- function(paths, prefix, predicate) {
  if (!length(paths)) {
    return(paths)
  }
  years <- vapply(paths, extract_year_from_filename, integer(1), prefix = prefix)
  paths[!is.na(years) & predicate(years)]
}

direct_cost_add_years <- function(dates, n) {
  if (exists("add_years_vec", mode = "function")) {
    return(add_years_vec(dates, n))
  }

  yr <- as.integer(format(dates, "%Y")) + as.integer(n)
  mo <- format(dates, "%m")
  dy <- format(dates, "%d")
  result <- as.Date(paste(yr, mo, dy, sep = "-"))
  bad <- !is.na(dates) & is.na(result)
  if (any(bad)) {
    result[bad] <- as.Date(paste(yr[bad], mo[bad], "28", sep = "-"))
  }
  result
}

direct_cost_date <- function(value) {
  if (inherits(value, "Date")) {
    return(value)
  }
  if (inherits(value, "POSIXt")) {
    return(as.Date(value))
  }
  suppressWarnings(as.Date(value))
}

direct_cost_year_range_label <- function(scan_scope) {
  if (is.null(scan_scope) ||
      (is.null(scan_scope$year_min) && is.null(scan_scope$year_max))) {
    return("all available years")
  }
  sprintf(
    "%s-%s",
    scan_scope$year_min %||% "min",
    scan_scope$year_max %||% "max"
  )
}

direct_cost_years_in_scope <- function(years, scan_scope) {
  keep <- rep(TRUE, length(years))
  if (is.null(scan_scope)) {
    return(keep)
  }
  if (!is.null(scan_scope$year_min) && !is.na(scan_scope$year_min)) {
    keep <- keep & (is.na(years) | years >= scan_scope$year_min)
  }
  if (!is.null(scan_scope$year_max) && !is.na(scan_scope$year_max)) {
    keep <- keep & (is.na(years) | years <= scan_scope$year_max)
  }
  keep
}

append_direct_cost_note <- function(note, suffix) {
  ifelse(nzchar(note), paste(note, suffix, sep = "; "), suffix)
}

apply_direct_cost_inventory_scope <- function(year, selected_for_build, note, scan_scope) {
  in_scope <- direct_cost_years_in_scope(year, scan_scope)
  note <- ifelse(
    !in_scope,
    append_direct_cost_note(
      note,
      sprintf("Excluded outside direct-cost scan window (%s)", direct_cost_year_range_label(scan_scope))
    ),
    note
  )
  list(
    selected_for_build = selected_for_build & in_scope,
    note = note
  )
}

filter_raw_files_for_scan_scope <- function(paths, prefix, scan_scope, predicate = function(year) TRUE) {
  if (!length(paths)) {
    return(paths)
  }
  years <- vapply(paths, extract_year_from_filename, integer(1), prefix = prefix)
  keep <- !is.na(years) & predicate(years) & direct_cost_years_in_scope(years, scan_scope)
  paths[keep]
}

filter_rows_to_scan_scope <- function(df, scan_scope, year_col = "year") {
  if (!nrow(df) || is.null(scan_scope) || !(year_col %in% names(df))) {
    return(df)
  }

  years <- suppressWarnings(as.integer(df[[year_col]]))
  keep <- direct_cost_years_in_scope(years, scan_scope)
  df[keep, , drop = FALSE]
}

direct_cost_parallel_cores <- function(config) {
  n_cores <- suppressWarnings(as.integer(config$direct_cost_n_cores %||% 1L))
  if (is.na(n_cores) || n_cores < 1L) {
    1L
  } else {
    n_cores
  }
}

direct_cost_scan_scope_mode <- function(config) {
  mode <- tolower(as.character(config$direct_cost_scope %||% "matched_analysis"))
  if (!mode %in% c("matched_analysis", "baseline")) {
    stop(
      sprintf("Unknown direct_cost_scope '%s'. Use 'matched_analysis' or 'baseline'.", mode),
      call. = FALSE
    )
  }
  mode
}

direct_cost_matched_year_range <- function(matched_df, max_followup_years) {
  if (!nrow(matched_df) || !("index_date" %in% names(matched_df))) {
    return(list(year_min = NULL, year_max = NULL))
  }

  index_date <- direct_cost_date(matched_df$index_date)
  start_dates <- index_date
  if ("baseline_start" %in% names(matched_df)) {
    start_dates <- c(start_dates, direct_cost_date(matched_df$baseline_start))
  }

  study_end <- direct_cost_add_years(index_date, max_followup_years) - 1L
  if ("censor_date" %in% names(matched_df)) {
    censor_date <- direct_cost_date(matched_df$censor_date)
    has_censor <- !is.na(censor_date) & !is.na(study_end)
    study_end[has_censor] <- pmin(study_end[has_censor], censor_date[has_censor])
  }

  start_years <- as.integer(format(start_dates, "%Y"))
  end_years <- as.integer(format(study_end, "%Y"))
  year_min <- suppressWarnings(min(start_years, na.rm = TRUE))
  year_max <- suppressWarnings(max(end_years, na.rm = TRUE))
  list(
    year_min = if (is.infinite(year_min)) NULL else as.integer(year_min),
    year_max = if (is.infinite(year_max)) NULL else as.integer(year_max)
  )
}

derive_direct_cost_scan_scope <- function(config) {
  mode <- direct_cost_scan_scope_mode(config)
  if (identical(mode, "matched_analysis")) {
    matched_path <- resolve_existing_output_file(config, "matched_cohort")
    if (file.exists(matched_path)) {
      matched_df <- arrow::read_parquet(matched_path)
      if ("person_id" %in% names(matched_df)) {
        cohort_ids <- unique(as.character(matched_df$person_id))
        cohort_ids <- cohort_ids[!is.na(cohort_ids) & nzchar(cohort_ids)]
        if (length(cohort_ids)) {
          max_followup_years <- max(
            5L,
            suppressWarnings(as.integer(config$max_followup_years %||% 10L)),
            na.rm = TRUE
          )
          year_range <- direct_cost_matched_year_range(matched_df, max_followup_years)
          return(list(
            mode = "matched_analysis",
            source = "matched_cohort",
            cohort_ids = cohort_ids,
            year_min = year_range$year_min,
            year_max = year_range$year_max,
            fallback_reason = NA_character_
          ))
        }
      }
    }
  }

  list(
    mode = "baseline",
    source = "baseline_dataset",
    cohort_ids = load_study_population_ids(config),
    year_min = NULL,
    year_max = NULL,
    fallback_reason = if (identical(mode, "matched_analysis")) {
      "matched_cohort was missing or empty"
    } else {
      NA_character_
    }
  )
}

message_direct_cost_scan_scope <- function(scan_scope) {
  message(sprintf(
    "  - direct-cost scan scope: %s IDs from %s; years %s",
    length(scan_scope$cohort_ids),
    scan_scope$source,
    direct_cost_year_range_label(scan_scope)
  ))
  if (!is.na(scan_scope$fallback_reason %||% NA_character_)) {
    message(sprintf("  - direct-cost scan scope fallback: %s", scan_scope$fallback_reason))
  }
}

normalize_upper_names <- function(df) {
  names(df) <- toupper(names(df))
  df
}

resolve_case_insensitive_column_map <- function(available_columns, requested_columns) {
  requested_columns <- unique(requested_columns)
  available_upper <- toupper(available_columns)
  result <- character(0)

  for (requested in requested_columns) {
    exact_idx <- match(requested, available_columns)
    if (!is.na(exact_idx)) {
      result[[requested]] <- available_columns[[exact_idx]]
      next
    }

    case_idx <- match(toupper(requested), available_upper)
    if (!is.na(case_idx)) {
      result[[requested]] <- available_columns[[case_idx]]
    }
  }

  result
}

rename_case_insensitive_columns <- function(df, column_map) {
  if (!length(column_map)) {
    return(df)
  }
  rename_exprs <- stats::setNames(
    rlang::syms(unname(column_map)),
    names(column_map)
  )
  df |> rename(!!!rename_exprs)
}

first_matching_column <- function(df, patterns, object_name) {
  matched <- names(df)[vapply(
    names(df),
    function(name) any(grepl(patterns, name, ignore.case = TRUE)),
    logical(1)
  )]
  if (!length(matched)) {
    stop(
      sprintf(
        "%s is missing any column matching patterns: %s",
        object_name,
        paste(patterns, collapse = ", ")
      )
    )
  }
  matched[[1]]
}

first_present_column <- function(df, candidates, object_name) {
  matched <- intersect(candidates, names(df))
  if (!length(matched)) {
    stop(
      sprintf(
        "%s is missing all candidate columns: %s",
        object_name,
        paste(candidates, collapse = ", ")
      )
    )
  }
  matched[[1]]
}

safe_cost_numeric <- function(x) {
  value <- suppressWarnings(as.numeric(x))
  value[is.na(value)] <- 0
  value
}

standardize_person_id <- function(x) {
  as.character(x)
}

cohort_id_filter_table <- function(cohort_ids) {
  ids <- unique(as.character(cohort_ids))
  ids <- ids[!is.na(ids) & nzchar(ids)]
  data.frame(person_id = ids, stringsAsFactors = FALSE)
}

arrow_column_type_string <- function(dataset, column_name) {
  field <- tryCatch(dataset$schema$GetFieldByName(column_name), error = function(e) NULL)
  if (is.null(field)) {
    return("")
  }
  tryCatch(field$type$ToString(), error = function(e) "")
}

native_id_filter_values <- function(dataset, id_col, person_ids) {
  ids <- unique(as.character(person_ids))
  ids <- ids[!is.na(ids) & nzchar(ids)]
  if (!length(ids)) {
    return(ids)
  }

  id_type <- tolower(arrow_column_type_string(dataset, id_col))
  if (!grepl("int|uint", id_type)) {
    return(ids)
  }

  if (grepl("64", id_type) && requireNamespace("bit64", quietly = TRUE)) {
    values <- suppressWarnings(bit64::as.integer64(ids))
    return(values[!is.na(values)])
  }

  values <- suppressWarnings(as.numeric(ids))
  values[!is.na(values)]
}

filter_dataset_to_ids_native <- function(dataset, id_col, person_ids) {
  filter_values <- native_id_filter_values(dataset, id_col, person_ids)
  id_expr <- rlang::sym(id_col)
  dataset |> filter(!!id_expr %in% filter_values)
}

scan_cohort_parquet <- function(dataset, path_label, requested_columns, cohort_ids, person_col = "PNR") {
  cohort_table <- cohort_id_filter_table(cohort_ids)
  if (!nrow(cohort_table)) {
    return(NULL)
  }

  available_columns <- names(dataset$schema)
  column_map <- resolve_case_insensitive_column_map(
    available_columns,
    unique(c(person_col, requested_columns))
  )
  if (!(person_col %in% names(column_map))) {
    stop(sprintf("%s does not contain %s.", basename(path_label), person_col))
  }

  selected_columns <- unname(column_map)
  person_col_actual <- unname(column_map[[person_col]])
  pnr_expr <- rlang::sym(person_col)
  native_scan <- tryCatch(
    {
      dataset |>
        select(dplyr::all_of(selected_columns)) |>
        filter_dataset_to_ids_native(person_col_actual, cohort_table$person_id) |>
        rename_case_insensitive_columns(column_map) |>
        mutate(person_id = as.character(!!pnr_expr))
    },
    error = function(e) NULL
  )
  if (!is.null(native_scan)) {
    return(native_scan)
  }

  dataset |>
    select(dplyr::all_of(selected_columns)) |>
    rename_case_insensitive_columns(column_map) |>
    mutate(person_id = as.character(!!pnr_expr)) |>
    inner_join(arrow::arrow_table(cohort_table), by = "person_id")
}

read_filtered_parquet_df <- function(path, requested_columns, cohort_ids, person_col = "PNR") {
  if (!length(cohort_ids)) {
    return(data.frame())
  }

  dataset <- arrow::open_dataset(path, format = "parquet")
  cohort_scan <- scan_cohort_parquet(dataset, path, requested_columns, cohort_ids, person_col = person_col)
  if (is.null(cohort_scan)) {
    return(data.frame())
  }

  selected_columns <- names(resolve_case_insensitive_column_map(
    names(dataset$schema),
    unique(c(person_col, requested_columns))
  ))
  cohort_scan |>
    select(dplyr::all_of(selected_columns)) |>
    collect() |>
    as.data.frame(stringsAsFactors = FALSE)
}

arrow_sum_expression <- function(cost_terms) {
  cost_terms <- cost_terms[!is.na(names(cost_terms)) & nzchar(names(cost_terms))]
  if (!length(cost_terms)) {
    stop("At least one named cost term is required.")
  }

  term_exprs <- sprintf(
    "dplyr::coalesce(`%s`, 0) * %.17g",
    names(cost_terms),
    unname(as.numeric(cost_terms))
  )
  rlang::parse_expr(paste(term_exprs, collapse = " + "))
}

read_grouped_fixed_year_cost_with_arrow <- function(
  dataset, path_label, requested_columns, cohort_ids, source_year, cost_terms
) {
  if (!length(cohort_ids)) {
    return(data.frame())
  }

  column_map <- resolve_case_insensitive_column_map(
    names(dataset$schema),
    unique(c("PNR", requested_columns))
  )
  selected_columns <- names(column_map)
  if (!("PNR" %in% selected_columns)) {
    stop(sprintf("%s does not contain PNR.", basename(path_label)))
  }
  missing_terms <- setdiff(names(cost_terms), selected_columns)
  if (length(missing_terms)) {
    stop(sprintf(
      "%s is missing cost columns: %s",
      basename(path_label),
      paste(missing_terms, collapse = ", ")
    ))
  }

  cost_expr <- arrow_sum_expression(cost_terms)
  cohort_scan <- scan_cohort_parquet(dataset, path_label, requested_columns, cohort_ids)
  if (is.null(cohort_scan)) {
    return(data.frame())
  }

  cohort_scan |>
    mutate(
      year = !!source_year,
      cost_total = !!cost_expr
    ) |>
    group_by(person_id, year) |>
    summarise(cost_total = sum(cost_total, na.rm = TRUE), .groups = "drop") |>
    collect() |>
    filter(!is.na(person_id), nzchar(person_id), !is.na(year)) |>
    as.data.frame(stringsAsFactors = FALSE)
}

read_grouped_year_column_cost_with_arrow <- function(
  dataset, path_label, requested_columns, cohort_ids, year_column, cost_terms, scan_scope = NULL
) {
  if (!length(cohort_ids)) {
    return(data.frame())
  }

  column_map <- resolve_case_insensitive_column_map(
    names(dataset$schema),
    unique(c("PNR", year_column, requested_columns))
  )
  selected_columns <- names(column_map)
  if (!("PNR" %in% selected_columns)) {
    stop(sprintf("%s does not contain PNR.", basename(path_label)))
  }
  if (!(year_column %in% selected_columns)) {
    stop(sprintf("%s does not contain %s.", basename(path_label), year_column))
  }
  missing_terms <- setdiff(names(cost_terms), selected_columns)
  if (length(missing_terms)) {
    stop(sprintf(
      "%s is missing cost columns: %s",
      basename(path_label),
      paste(missing_terms, collapse = ", ")
    ))
  }

  cost_expr <- arrow_sum_expression(cost_terms)
  year_expr <- rlang::sym(year_column)
  cohort_scan <- scan_cohort_parquet(
    dataset,
    path_label,
    unique(c(year_column, requested_columns)),
    cohort_ids
  )
  if (is.null(cohort_scan)) {
    return(data.frame())
  }

  grouped_scan <- cohort_scan |>
    mutate(
      year = as.integer(!!year_expr),
      cost_total = !!cost_expr
    )
  if (!is.null(scan_scope$year_min %||% NULL)) {
    grouped_scan <- grouped_scan |> filter(year >= !!(scan_scope$year_min))
  }
  if (!is.null(scan_scope$year_max %||% NULL)) {
    grouped_scan <- grouped_scan |> filter(year <= !!(scan_scope$year_max))
  }

  grouped_scan |>
    group_by(person_id, year) |>
    summarise(cost_total = sum(cost_total, na.rm = TRUE), .groups = "drop") |>
    collect() |>
    filter(!is.na(person_id), nzchar(person_id), !is.na(year)) |>
    as.data.frame(stringsAsFactors = FALSE)
}

derive_year_value <- function(df, object_name, exact_year_candidates = character(), exact_date_candidates = character()) {
  year_col <- intersect(exact_year_candidates, names(df))
  if (length(year_col)) {
    year_vec <- df[[year_col[[1]]]]
    if (inherits(year_vec, "Date") || inherits(year_vec, "POSIXt")) {
      return(as.integer(format(as.Date(year_vec), "%Y")))
    }
    year_value <- suppressWarnings(as.integer(substr(as.character(year_vec), 1L, 4L)))
    return(year_value)
  }

  date_col <- intersect(exact_date_candidates, names(df))
  if (length(date_col)) {
    date_vec <- df[[date_col[[1]]]]
    if (inherits(date_vec, "Date") || inherits(date_vec, "POSIXt")) {
      return(as.integer(format(as.Date(date_vec), "%Y")))
    }
    date_int <- suppressWarnings(as.integer(date_vec))
    non_na <- date_int[!is.na(date_int)]
    if (length(non_na) > 0L && all(non_na >= 10000L & non_na <= 32000L)) {
      # SAS date: days since 1960-01-01
      return(as.integer(format(as.Date(date_int, origin = "1960-01-01"), "%Y")))
    }
    return(suppressWarnings(as.integer(substr(gsub("[^0-9]", "", as.character(date_vec)), 1L, 4L))))
  }

  pattern_col <- names(df)[grepl("AAR|YEAR|DATO|DATE", names(df), ignore.case = TRUE)][1]
  if (!is.na(pattern_col) && nzchar(pattern_col)) {
    pattern_vec <- df[[pattern_col]]
    if (inherits(pattern_vec, "Date") || inherits(pattern_vec, "POSIXt")) {
      return(as.integer(format(as.Date(pattern_vec), "%Y")))
    }
    return(suppressWarnings(as.integer(substr(gsub("[^0-9]", "", as.character(pattern_vec)), 1L, 4L))))
  }

  stop(sprintf("%s is missing a usable year/date column.", object_name))
}

approx_equal_cost <- function(lhs, rhs, tolerance = 1e-6) {
  abs(lhs - rhs) <= tolerance
}

direct_cost_collect_one <- function(path, reader, args) {
  result <- tryCatch(
    do.call(reader, c(list(path), args)),
    error = function(err) err
  )
  if (inherits(result, "error")) {
    list(row = NULL, issue = sprintf("%s: %s", basename(path), conditionMessage(result)))
  } else {
    list(row = result, issue = NA_character_)
  }
}

direct_cost_parallel_function_exports <- function(envir) {
  names <- ls(envir = envir, all.names = TRUE)
  names[vapply(
    names,
    function(name) is.function(get(name, envir = envir, inherits = FALSE)),
    logical(1)
  )]
}

collect_cost_rows <- function(paths, reader, ..., n_cores = 1L) {
  issues <- character(0)

  if (!length(paths)) {
    return(list(rows = data.frame(), issues = issues))
  }

  args <- list(...)
  n_cores <- suppressWarnings(as.integer(n_cores))
  if (is.na(n_cores) || n_cores < 1L) {
    n_cores <- 1L
  }
  n_cores <- min(n_cores, length(paths))

  if (n_cores > 1L && requireNamespace("parallel", quietly = TRUE)) {
    cluster <- parallel::makeCluster(n_cores)
    on.exit(parallel::stopCluster(cluster), add = TRUE)
    parallel::clusterEvalQ(cluster, {
      suppressPackageStartupMessages({
        library(arrow)
        library(dplyr)
      })
      NULL
    })
    function_env <- environment(collect_cost_rows)
    parallel::clusterExport(
      cluster,
      direct_cost_parallel_function_exports(function_env),
      envir = function_env
    )
    .direct_cost_reader <- reader
    .direct_cost_args <- args
    parallel::clusterExport(
      cluster,
      c(".direct_cost_reader", ".direct_cost_args"),
      envir = environment()
    )
    results <- parallel::parLapply(cluster, paths, function(path) {
      direct_cost_collect_one(path, .direct_cost_reader, .direct_cost_args)
    })
  } else {
    results <- lapply(paths, direct_cost_collect_one, reader = reader, args = args)
  }

  rows <- lapply(results, `[[`, "row")
  issues <- stats::na.omit(vapply(results, `[[`, character(1), "issue"))

  list(
    rows = bind_rows(rows),
    issues = as.character(issues)
  )
}

derive_lmdb_cost_column <- function(df, object_name) {
  if ("EKSP" %in% names(df)) {
    return(list(
      cost_value = safe_cost_numeric(df$EKSP),
      price_source = "eksp_sum",
      derivation_note = NA_character_
    ))
  }

  if ("AUP" %in% names(df)) {
    return(list(
      cost_value = safe_cost_numeric(df$AUP),
      price_source = "aup_sum",
      derivation_note = NA_character_
    ))
  }

  if (all(c("PTP", "TSKA", "TSK1", "TSK2", "TSK3") %in% names(df))) {
    return(list(
      cost_value = safe_cost_numeric(df$PTP) +
        safe_cost_numeric(df$TSKA) +
        safe_cost_numeric(df$TSK1) +
        safe_cost_numeric(df$TSK2) +
        safe_cost_numeric(df$TSK3),
      price_source = "ptp_plus_subsidy_sum",
      derivation_note = NA_character_
    ))
  }

  if ("TILPRIS" %in% names(df)) {
    return(list(
      cost_value = safe_cost_numeric(df$TILPRIS),
      price_source = "tilpris_sum_proxy",
      derivation_note = sprintf(
        "%s used TILPRIS fallback because EKSP, AUP and full subsidy decomposition were unavailable.",
        object_name
      )
    ))
  }

  stop(
    sprintf(
      "%s does not contain EKSP, AUP, a full patient-payment plus subsidy decomposition, or TILPRIS.",
      object_name
    )
  )
}

read_lmdb_direct_cost <- function(path, config, cohort_ids) {
  source_year <- extract_year_from_filename(path, "lmdb")
  if (!is.na(source_year)) {
    object_name <- sprintf("LMDB file %s", basename(path))
    dataset <- arrow::open_dataset(path, format = "parquet")
    available_columns <- toupper(names(dataset$schema))
    price_source <- if ("EKSP" %in% available_columns) {
      "eksp_sum"
    } else if ("AUP" %in% available_columns) {
      "aup_sum"
    } else if (all(c("PTP", "TSKA", "TSK1", "TSK2", "TSK3") %in% available_columns)) {
      "ptp_plus_subsidy_sum"
    } else if ("TILPRIS" %in% available_columns) {
      "tilpris_sum_proxy"
    } else {
      NULL
    }
    derivation_note <- if (identical(price_source, "tilpris_sum_proxy")) {
      sprintf(
        "%s used TILPRIS fallback because EKSP, AUP and full subsidy decomposition were unavailable.",
        object_name
      )
    } else {
      NA_character_
    }
    cost_terms <- switch(
      price_source,
      eksp_sum = c(EKSP = 1),
      aup_sum = c(AUP = 1),
      ptp_plus_subsidy_sum = c(PTP = 1, TSKA = 1, TSK1 = 1, TSK2 = 1, TSK3 = 1),
      tilpris_sum_proxy = c(TILPRIS = 1)
    )
    grouped <- read_grouped_fixed_year_cost_with_arrow(
      dataset = dataset,
      path_label = path,
      requested_columns = names(cost_terms),
      cohort_ids = cohort_ids,
      source_year = source_year,
      cost_terms = cost_terms
    )
    if (nrow(grouped)) {
      grouped$source_year <- source_year
      grouped$source_file <- basename(path)
      grouped$price_source <- price_source
      grouped$derivation_note <- derivation_note
      grouped$coverage_status <- if (is_partial_year_file(path, "lmdb")) "partial" else "full"
      return(grouped)
    }
    return(grouped)
  }

  raw_df <- read_filtered_parquet_df(path, c("PNR", "EKSD", "EKSP", "AUP", "PTP", "TSKA", "TSK1", "TSK2", "TSK3", "TILPRIS"), cohort_ids) |>
    normalize_upper_names()

  object_name <- sprintf("LMDB file %s", basename(path))
  person_col <- first_present_column(raw_df, c("PNR"), object_name)
  date_col <- first_present_column(raw_df, c("EKSD"), object_name)
  cost_meta <- derive_lmdb_cost_column(raw_df, object_name)

  date_value <- as.character(raw_df[[date_col]])
  year_value <- suppressWarnings(as.integer(substr(gsub("[^0-9]", "", date_value), 1L, 4L)))
  source_year <- extract_year_from_filename(path, "lmdb")
  if (!is.na(source_year)) {
    missing_year <- is.na(year_value)
    year_value[missing_year] <- source_year
  }

  data.frame(
    person_id = standardize_person_id(raw_df[[person_col]]),
    year = year_value,
    cost_total = cost_meta$cost_value,
    source_year = source_year,
    source_file = basename(path),
    price_source = cost_meta$price_source,
    derivation_note = cost_meta$derivation_note,
    coverage_status = if (is_partial_year_file(path, "lmdb")) "partial" else "full",
    stringsAsFactors = FALSE
  ) |>
    dplyr::filter(!is.na(person_id), nzchar(person_id), !is.na(year))
}

build_lmdb_direct_cost_artifact <- function(config, cohort_ids = NULL, scan_scope = NULL) {
  lmdb_files <- filter_raw_files_for_scan_scope(
    list_raw_parquet_files(config$raw_lmdb_dir, "^lmdb[0-9]{4}.*\\.parquet$"),
    "lmdb",
    scan_scope
  )
  if (!length(lmdb_files)) {
    return(list(data = data.frame(), issues = character(0)))
  }

  cohort_ids <- cohort_ids %||% load_study_population_ids(config)
  collected <- collect_cost_rows(
    lmdb_files,
    read_lmdb_direct_cost,
    config = config,
    cohort_ids = cohort_ids,
    n_cores = direct_cost_parallel_cores(config)
  )
  collected$rows <- filter_rows_to_scan_scope(collected$rows, scan_scope)
  if (!nrow(collected$rows)) {
    return(list(data = data.frame(), issues = collected$issues))
  }
  data <- collected$rows |>
    group_by(person_id, year, price_source, coverage_status) |>
    summarise(
      cost_total = sum(cost_total, na.rm = TRUE),
      source_year = min(source_year, na.rm = TRUE),
      source_file = paste(sort(unique(source_file)), collapse = ";"),
      derivation_note = {
        notes <- sort(unique(stats::na.omit(derivation_note)))
        if (length(notes)) paste(notes, collapse = ";") else NA_character_
      },
      .groups = "drop"
    ) |>
    arrange(person_id, year) |>
    as.data.frame(stringsAsFactors = FALSE)

  list(data = data, issues = collected$issues)
}

read_primary_direct_cost <- function(path, source_system, cohort_ids) {
  source_year <- extract_year_from_filename(path, source_system)
  if (!is.na(source_year)) {
    amount_candidates <- c("BRUHON", "HONUGE")
    dataset <- arrow::open_dataset(path, format = "parquet")
    available_columns <- toupper(names(dataset$schema))
    amount_col <- first_present_column(
      setNames(as.list(rep(NA, length(available_columns))), available_columns),
      amount_candidates,
      sprintf("%s file %s", toupper(source_system), basename(path))
    )
    grouped <- read_grouped_fixed_year_cost_with_arrow(
      dataset = dataset,
      path_label = path,
      requested_columns = amount_col,
      cohort_ids = cohort_ids,
      source_year = source_year,
      cost_terms = stats::setNames(if (identical(source_system, "sysi")) 0.01 else 1, amount_col)
    )
    if (nrow(grouped)) {
      grouped$source_system <- source_system
      grouped$source_file <- basename(path)
      grouped$price_source <- sprintf("%s_%s_sum", source_system, tolower(amount_col))
      grouped$coverage_status <- "full"
      return(grouped)
    }
    return(grouped)
  }

  raw_df <- read_filtered_parquet_df(path, c("PNR", "AFRPER", "BRUHON", "HONUGE"), cohort_ids) |>
    normalize_upper_names()

  object_name <- sprintf("%s file %s", toupper(source_system), basename(path))
  person_col <- first_present_column(raw_df, c("PNR"), object_name)
  period_col <- first_present_column(raw_df, c("AFRPER"), object_name)
  amount_col <- first_present_column(raw_df, c("BRUHON", "HONUGE"), object_name)

  year_value <- suppressWarnings(as.integer(substr(as.character(raw_df[[period_col]]), 1L, 4L)))
  cost_value <- safe_cost_numeric(raw_df[[amount_col]])
  if (identical(source_system, "sysi")) {
    cost_value <- cost_value / 100
  }

  data.frame(
    person_id = standardize_person_id(raw_df[[person_col]]),
    year = year_value,
    cost_total = cost_value,
    source_system = source_system,
    source_file = basename(path),
    price_source = sprintf("%s_%s_sum", source_system, tolower(amount_col)),
    coverage_status = "full",
    stringsAsFactors = FALSE
  ) |>
    dplyr::filter(!is.na(person_id), nzchar(person_id), !is.na(year))
}

build_primary_direct_cost_artifact <- function(config, cohort_ids = NULL, scan_scope = NULL) {
  sysi_files <- filter_raw_files_for_scan_scope(
    list_raw_parquet_files(config$raw_primary_dir, "^sysi[0-9]{4}.*\\.parquet$"),
    "sysi",
    scan_scope,
    function(year) year <= 2004L
  )
  sssy_files <- filter_raw_files_for_scan_scope(
    list_raw_parquet_files(config$raw_primary_dir, "^sssy[0-9]{4}.*\\.parquet$"),
    "sssy",
    scan_scope,
    function(year) year >= 2005L
  )
  cohort_ids <- cohort_ids %||% load_study_population_ids(config)

  n_cores <- direct_cost_parallel_cores(config)
  sysi_collected <- collect_cost_rows(
    sysi_files,
    read_primary_direct_cost,
    source_system = "sysi",
    cohort_ids = cohort_ids,
    n_cores = n_cores
  )
  sssy_collected <- collect_cost_rows(
    sssy_files,
    read_primary_direct_cost,
    source_system = "sssy",
    cohort_ids = cohort_ids,
    n_cores = n_cores
  )
  primary_rows <- bind_rows(sysi_collected$rows, sssy_collected$rows)
  primary_rows <- filter_rows_to_scan_scope(primary_rows, scan_scope)

  if (!nrow(primary_rows)) {
    return(list(data = primary_rows, issues = c(sysi_collected$issues, sssy_collected$issues)))
  }

  data <- primary_rows |>
    filter((source_system == "sysi" & year <= 2004L) | (source_system == "sssy" & year >= 2005L)) |>
    group_by(person_id, year, source_system, price_source, coverage_status) |>
    summarise(
      cost_total = sum(cost_total, na.rm = TRUE),
      source_file = paste(sort(unique(source_file)), collapse = ";"),
      .groups = "drop"
    ) |>
    arrange(person_id, year, source_system) |>
    as.data.frame(stringsAsFactors = FALSE)

  list(data = data, issues = c(sysi_collected$issues, sssy_collected$issues))
}

build_direct_cost_source_inventory <- function(config, scan_scope = NULL) {
  lmdb_files <- list_raw_parquet_files(config$raw_lmdb_dir, "^lmdb[0-9]{4}.*\\.parquet$")
  sysi_files <- list_raw_parquet_files(config$raw_primary_dir, "^sysi[0-9]{4}.*\\.parquet$")
  sssy_files <- list_raw_parquet_files(config$raw_primary_dir, "^sssy[0-9]{4}.*\\.parquet$")
  amb_files <- list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_amb[0-9]{4}.*\\.parquet$")
  hel_files <- list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_hel[0-9]{4}.*\\.parquet$")
  kontakt_files <- list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_kontakt2018.*\\.parquet$")
  sghforlob_files <- list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_sghforlob2018.*\\.parquet$")
  indberetning_file <- if (file.exists(config$raw_indberetningmedpris_path)) config$raw_indberetningmedpris_path else character(0)

  bind_rows(
    if (length(lmdb_files)) {
      year_value <- vapply(lmdb_files, extract_year_from_filename, integer(1), prefix = "lmdb")
      coverage_value <- ifelse(vapply(lmdb_files, is_partial_year_file, logical(1), prefix = "lmdb"), "partial", "full")
      note_value <- ifelse(coverage_value == "partial", "Partial-year LMDB delivery", "Included")
      selection <- apply_direct_cost_inventory_scope(
        year_value,
        rep(TRUE, length(lmdb_files)),
        note_value,
        scan_scope
      )
      data.frame(
        component = "lmdb",
        source_system = "lmdb",
        source_table = "lmdb",
        year = year_value,
        source_file = basename(lmdb_files),
        source_path = lmdb_files,
        coverage_status = coverage_value,
        selected_for_build = selection$selected_for_build,
        note = selection$note,
        stringsAsFactors = FALSE
      )
    },
    if (length(sysi_files)) {
      year_value <- vapply(sysi_files, extract_year_from_filename, integer(1), prefix = "sysi")
      selected_value <- year_value <= 2004L
      note_value <- ifelse(selected_value, "Included", "Excluded because SYSI overlaps with SSSY from 2005 onward")
      selection <- apply_direct_cost_inventory_scope(year_value, selected_value, note_value, scan_scope)
      data.frame(
        component = "primary_sector",
        source_system = "sysi",
        source_table = "sysi",
        year = year_value,
        source_file = basename(sysi_files),
        source_path = sysi_files,
        coverage_status = "full",
        selected_for_build = selection$selected_for_build,
        note = selection$note,
        stringsAsFactors = FALSE
      )
    },
    if (length(sssy_files)) {
      year_value <- vapply(sssy_files, extract_year_from_filename, integer(1), prefix = "sssy")
      selected_value <- year_value >= 2005L
      note_value <- ifelse(selected_value, "Included", "Excluded because SSSY is canonical from 2005 onward")
      selection <- apply_direct_cost_inventory_scope(year_value, selected_value, note_value, scan_scope)
      data.frame(
        component = "primary_sector",
        source_system = "sssy",
        source_table = "sssy",
        year = year_value,
        source_file = basename(sssy_files),
        source_path = sssy_files,
        coverage_status = "full",
        selected_for_build = selection$selected_for_build,
        note = selection$note,
        stringsAsFactors = FALSE
      )
    },
    if (length(amb_files)) {
      year_value <- vapply(amb_files, extract_year_from_filename, integer(1), prefix = "drgsoma_amb")
      selection <- apply_direct_cost_inventory_scope(
        year_value,
        rep(TRUE, length(amb_files)),
        rep("Included", length(amb_files)),
        scan_scope
      )
      data.frame(
        component = "lpr_kontakt",
        source_system = "lpr",
        source_table = "drgsoma_amb",
        year = year_value,
        source_file = basename(amb_files),
        source_path = amb_files,
        coverage_status = "full",
        selected_for_build = selection$selected_for_build,
        note = selection$note,
        stringsAsFactors = FALSE
      )
    },
    if (length(hel_files)) {
      year_value <- vapply(hel_files, extract_year_from_filename, integer(1), prefix = "drgsoma_hel")
      selection <- apply_direct_cost_inventory_scope(
        year_value,
        rep(TRUE, length(hel_files)),
        rep("Included", length(hel_files)),
        scan_scope
      )
      data.frame(
        component = "lpr_sghforlob",
        source_system = "lpr",
        source_table = "drgsoma_hel",
        year = year_value,
        source_file = basename(hel_files),
        source_path = hel_files,
        coverage_status = "full",
        selected_for_build = selection$selected_for_build,
        note = selection$note,
        stringsAsFactors = FALSE
      )
    },
    if (length(kontakt_files)) {
      year_value <- rep(2018L, length(kontakt_files))
      note_value <- rep(
        if (length(sghforlob_files)) {
          "Included only for kontakt rows without linked DRGSGHFORLOB_ID"
        } else {
          "Used as 2018 fallback because drgsoma_sghforlob2018 is absent"
        },
        length(kontakt_files)
      )
      selection <- apply_direct_cost_inventory_scope(
        year_value,
        rep(TRUE, length(kontakt_files)),
        note_value,
        scan_scope
      )
      data.frame(
        component = "lpr_kontakt",
        source_system = "lpr",
        source_table = "drgsoma_kontakt2018",
        year = year_value,
        source_file = basename(kontakt_files),
        source_path = kontakt_files,
        coverage_status = if (length(sghforlob_files)) "supplementary" else "partial",
        selected_for_build = selection$selected_for_build,
        note = selection$note,
        stringsAsFactors = FALSE
      )
    },
    if (length(sghforlob_files)) {
      year_value <- rep(2018L, length(sghforlob_files))
      selection <- apply_direct_cost_inventory_scope(
        year_value,
        rep(TRUE, length(sghforlob_files)),
        rep("Included as canonical 2018 LPR pathway source", length(sghforlob_files)),
        scan_scope
      )
      data.frame(
        component = "lpr_sghforlob",
        source_system = "lpr",
        source_table = "drgsoma_sghforlob2018",
        year = year_value,
        source_file = basename(sghforlob_files),
        source_path = sghforlob_files,
        coverage_status = "full",
        selected_for_build = selection$selected_for_build,
        note = selection$note,
        stringsAsFactors = FALSE
      )
    },
    if (length(indberetning_file)) {
      data.frame(
        component = "hospital_drugs",
        source_system = "hospital_drugs",
        source_table = "indberetningmedpris",
        year = NA_integer_,
        source_file = basename(indberetning_file),
        source_path = indberetning_file,
        coverage_status = "restricted",
        selected_for_build = TRUE,
        note = "Multi-year hospital-drug cost file with restricted coverage",
        stringsAsFactors = FALSE
      )
    }
  ) |>
    arrange(component, year, source_table, source_file) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_component_year_availability <- function(source_inventory) {
  if (!nrow(source_inventory)) {
    return(data.frame())
  }

  source_inventory |>
    filter(!is.na(year)) |>
    filter(selected_for_build) |>
    group_by(component, year) |>
    summarise(
      coverage_status = case_when(
        any(coverage_status == "full") ~ "full",
        any(coverage_status == "partial") ~ "partial",
        any(coverage_status == "supplementary") ~ "supplementary",
        any(coverage_status == "restricted") ~ "restricted",
        TRUE ~ "unknown"
      ),
      source_tables = paste(sort(unique(source_table)), collapse = ";"),
      source_files = paste(sort(unique(source_file)), collapse = ";"),
      .groups = "drop"
    ) |>
    mutate(data_available = TRUE) |>
    arrange(component, year) |>
    as.data.frame(stringsAsFactors = FALSE)
}

canonical_legacy_drg_cost <- function(df) {
  total_col <- intersect(c("V_TOTPRIS"), names(df))
  base_col <- intersect(c("V_PRIS"), names(df))
  long_col <- intersect(c("V_LANGPRIS"), names(df))

  total_cost <- if (length(total_col)) safe_cost_numeric(df[[total_col[[1]]]]) else rep(NA_real_, nrow(df))
  base_cost <- if (length(base_col)) safe_cost_numeric(df[[base_col[[1]]]]) else rep(NA_real_, nrow(df))
  long_cost <- if (length(long_col)) safe_cost_numeric(df[[long_col[[1]]]]) else rep(0, nrow(df))
  decomposition_cost <- base_cost + long_cost

  # V_TOTPRIS, V_PRIS, V_LANGPRIS are stored in 1,000 DKK units in pre-2018 DRG files
  # (eSundhed: "Prisen angives i 1.000 kr"). Multiply by 1000 to convert to whole DKK.
  1000 * ifelse(!is.na(total_cost) & total_cost > 0, total_cost, decomposition_cost)
}

arrow_legacy_drg_cost_expression <- function(available_columns) {
  has_total <- "V_TOTPRIS" %in% available_columns
  has_base  <- "V_PRIS" %in% available_columns
  has_long  <- "V_LANGPRIS" %in% available_columns

  base_expr <- if (has_base) "dplyr::coalesce(V_PRIS, 0)" else "NA_real_"
  long_expr <- if (has_long) "dplyr::coalesce(V_LANGPRIS, 0)" else "0"
  decomposition_expr <- sprintf("(%s + %s)", base_expr, long_expr)

  cost_expr <- if (has_total) {
    sprintf(
      "dplyr::if_else(dplyr::coalesce(V_TOTPRIS, 0) > 0, dplyr::coalesce(V_TOTPRIS, 0), %s)",
      decomposition_expr
    )
  } else {
    decomposition_expr
  }

  rlang::parse_expr(sprintf("1000 * (%s)", cost_expr))
}

read_grouped_legacy_drg_cost_with_arrow <- function(dataset, path_label, table_type, cohort_ids) {
  if (!length(cohort_ids)) {
    return(data.frame())
  }

  column_map <- resolve_case_insensitive_column_map(
    names(dataset$schema),
    c("PNR", "V_AAR", "V_PRIS", "V_LANGPRIS", "V_TOTPRIS")
  )
  available_columns <- names(column_map)
  if (!("PNR" %in% available_columns)) {
    stop(sprintf("%s does not contain PNR.", basename(path_label)))
  }
  if (!("V_AAR" %in% available_columns)) {
    stop(sprintf("%s does not contain V_AAR.", basename(path_label)))
  }
  if (!("V_TOTPRIS" %in% available_columns) && !("V_PRIS" %in% available_columns)) {
    return(data.frame(
      person_id = character(),
      year = integer(),
      ambulatory_cost = numeric(),
      inpatient_cost = numeric(),
      cost_total = numeric(),
      source_era = character(),
      source_file = character(),
      price_source = character(),
      coverage_status = character(),
      stringsAsFactors = FALSE
    ))
  }

  cost_expr <- arrow_legacy_drg_cost_expression(available_columns)
  year_expr <- rlang::sym("V_AAR")
  cohort_scan <- scan_cohort_parquet(
    dataset,
    path_label,
    c("V_AAR", "V_PRIS", "V_LANGPRIS", "V_TOTPRIS"),
    cohort_ids
  )
  if (is.null(cohort_scan)) {
    return(data.frame())
  }

  grouped <- cohort_scan |>
    mutate(
      year = as.integer(!!year_expr),
      cost_total = !!cost_expr
    ) |>
    filter(!is.na(person_id), !is.na(year), !is.na(cost_total)) |>
    group_by(person_id, year) |>
    summarise(cost_total = sum(cost_total, na.rm = TRUE), .groups = "drop") |>
    collect() |>
    filter(!is.na(person_id), nzchar(person_id), !is.na(year), !is.na(cost_total)) |>
    as.data.frame(stringsAsFactors = FALSE)

  if (!nrow(grouped)) {
    return(grouped)
  }

  grouped$ambulatory_cost <- if (identical(table_type, "amb")) grouped$cost_total else 0
  grouped$inpatient_cost <- if (identical(table_type, "hel")) grouped$cost_total else 0
  grouped$source_era <- "legacy_amb_hel"
  grouped$source_file <- basename(path_label)
  grouped$price_source <- "v_totpris_preferred"
  grouped$coverage_status <- "full"

  grouped[, c(
    "person_id", "year", "ambulatory_cost", "inpatient_cost", "cost_total",
    "source_era", "source_file", "price_source", "coverage_status"
  ), drop = FALSE]
}

read_legacy_drg_cost <- function(path, table_type, cohort_ids) {
  dataset <- arrow::open_dataset(path, format = "parquet")
  available_columns <- toupper(names(dataset$schema))
  if (all(c("PNR", "V_AAR") %in% available_columns)) {
    return(read_grouped_legacy_drg_cost_with_arrow(
      dataset = dataset,
      path_label = path,
      table_type = table_type,
      cohort_ids = cohort_ids
    ))
  }

  raw_df <- read_filtered_parquet_df(path, c("PNR", "V_AAR", "V_PRIS", "V_LANGPRIS", "V_TOTPRIS"), cohort_ids) |>
    normalize_upper_names()

  object_name <- sprintf("legacy DRG file %s", basename(path))
  person_col <- first_present_column(raw_df, c("PNR"), object_name)
  year_col <- first_present_column(raw_df, c("V_AAR"), object_name)
  cost_value <- canonical_legacy_drg_cost(raw_df)

  data.frame(
    person_id = standardize_person_id(raw_df[[person_col]]),
    year = suppressWarnings(as.integer(raw_df[[year_col]])),
    ambulatory_cost = if (identical(table_type, "amb")) cost_value else 0,
    inpatient_cost = if (identical(table_type, "hel")) cost_value else 0,
    cost_total = cost_value,
    source_era = "legacy_amb_hel",
    source_file = basename(path),
    price_source = "v_totpris_preferred",
    coverage_status = "full",
    stringsAsFactors = FALSE
  ) |>
    dplyr::filter(!is.na(person_id), nzchar(person_id), !is.na(year), !is.na(cost_total))
}

read_drg2018_sghforlob <- function(path, cohort_ids, scan_scope = NULL) {
  dataset <- arrow::open_dataset(path, format = "parquet")
  available_columns <- toupper(names(dataset$schema))
  if (all(c("PNR", "AKTIVITETSAAR", "TOTALPRIS_DRGSGHF") %in% available_columns)) {
    grouped <- read_grouped_year_column_cost_with_arrow(
      dataset = dataset,
      path_label = path,
      requested_columns = c("AKTIVITETSAAR", "TOTALPRIS_DRGSGHF"),
      cohort_ids = cohort_ids,
      year_column = "AKTIVITETSAAR",
      cost_terms = c(TOTALPRIS_DRGSGHF = 1),
      scan_scope = scan_scope
    )
    if (!nrow(grouped)) {
      return(grouped)
    }
    grouped$ambulatory_cost <- 0
    grouped$inpatient_cost <- grouped$cost_total
    grouped$source_era <- "drg2018_sghforlob"
    grouped$source_file <- basename(path)
    grouped$price_source <- "totalpris_drgsghf_sum"
    grouped$coverage_status <- "full"
    return(grouped[, c(
      "person_id", "year", "ambulatory_cost", "inpatient_cost", "cost_total",
      "source_era", "source_file", "price_source", "coverage_status"
    ), drop = FALSE])
  }

  raw_df <- read_filtered_parquet_df(path, c("PNR", "AKTIVITETSAAR", "TOTALPRIS_DRGSGHF"), cohort_ids) |>
    normalize_upper_names()

  person_col <- first_present_column(raw_df, c("PNR"), basename(path))
  year_col <- first_present_column(raw_df, c("AKTIVITETSAAR"), basename(path))
  cost_col <- first_present_column(raw_df, c("TOTALPRIS_DRGSGHF"), basename(path))

  rows <- data.frame(
    person_id = standardize_person_id(raw_df[[person_col]]),
    year = suppressWarnings(as.integer(raw_df[[year_col]])),
    ambulatory_cost = 0,
    inpatient_cost = safe_cost_numeric(raw_df[[cost_col]]),
    cost_total = safe_cost_numeric(raw_df[[cost_col]]),
    source_era = "drg2018_sghforlob",
    source_file = basename(path),
    price_source = "totalpris_drgsghf_sum",
    coverage_status = "full",
    stringsAsFactors = FALSE
  ) |>
    dplyr::filter(!is.na(person_id), nzchar(person_id), !is.na(year))
  filter_rows_to_scan_scope(rows, scan_scope)
}

read_grouped_drg2018_kontakt_with_arrow <- function(dataset, path_label, cohort_ids, scan_scope = NULL) {
  if (!length(cohort_ids)) {
    return(data.frame())
  }

  column_map <- resolve_case_insensitive_column_map(
    names(dataset$schema),
    c("PNR", "AKTIVITETSAAR", "TOTALPRIS_DRG", "DRGSGHFORLOB_ID")
  )
  available_columns <- names(column_map)
  required_columns <- c("PNR", "AKTIVITETSAAR", "TOTALPRIS_DRG")
  missing_columns <- setdiff(required_columns, available_columns)
  if (length(missing_columns)) {
    stop(sprintf(
      "%s is missing required kontakt columns: %s",
      basename(path_label),
      paste(missing_columns, collapse = ", ")
    ))
  }

  has_linked_forlob <- "DRGSGHFORLOB_ID" %in% available_columns
  requested_columns <- c("AKTIVITETSAAR", "TOTALPRIS_DRG")
  if (has_linked_forlob) {
    requested_columns <- c(requested_columns, "DRGSGHFORLOB_ID")
  }

  year_expr <- rlang::sym("AKTIVITETSAAR")
  linked_expr <- rlang::sym("DRGSGHFORLOB_ID")
  cohort_scan <- scan_cohort_parquet(
    dataset,
    path_label,
    requested_columns,
    cohort_ids
  )
  if (is.null(cohort_scan)) {
    return(data.frame())
  }

  if (has_linked_forlob) {
    cohort_scan <- cohort_scan |>
      mutate(.linked_forlob = as.character(!!linked_expr)) |>
      filter(is.na(.linked_forlob) | .linked_forlob == "")
  }

  grouped_scan <- cohort_scan |>
    mutate(
      year = as.integer(!!year_expr),
      cost_total = dplyr::coalesce(TOTALPRIS_DRG, 0)
    )
  if (!is.null(scan_scope$year_min %||% NULL)) {
    grouped_scan <- grouped_scan |> filter(year >= !!(scan_scope$year_min))
  }
  if (!is.null(scan_scope$year_max %||% NULL)) {
    grouped_scan <- grouped_scan |> filter(year <= !!(scan_scope$year_max))
  }

  grouped <- grouped_scan |>
    group_by(person_id, year) |>
    summarise(cost_total = sum(cost_total, na.rm = TRUE), .groups = "drop") |>
    collect() |>
    filter(!is.na(person_id), nzchar(person_id), !is.na(year)) |>
    as.data.frame(stringsAsFactors = FALSE)

  if (!nrow(grouped)) {
    return(grouped)
  }

  grouped$ambulatory_cost <- grouped$cost_total
  grouped$inpatient_cost <- 0
  grouped$source_era <- "drg2018_kontakt_fallback"
  grouped$source_file <- basename(path_label)
  grouped$price_source <- "totalpris_drg_sum"
  grouped$coverage_status <- if (has_linked_forlob) "supplementary" else "partial"

  grouped[, c(
    "person_id", "year", "ambulatory_cost", "inpatient_cost", "cost_total",
    "source_era", "source_file", "price_source", "coverage_status"
  ), drop = FALSE]
}

read_drg2018_kontakt <- function(path, cohort_ids, scan_scope = NULL) {
  dataset <- arrow::open_dataset(path, format = "parquet")
  available_columns <- toupper(names(dataset$schema))
  if (all(c("PNR", "AKTIVITETSAAR", "TOTALPRIS_DRG") %in% available_columns)) {
    return(read_grouped_drg2018_kontakt_with_arrow(
      dataset = dataset,
      path_label = path,
      cohort_ids = cohort_ids,
      scan_scope = scan_scope
    ))
  }

  raw_df <- read_filtered_parquet_df(path, c("PNR", "AKTIVITETSAAR", "DRGSGHFORLOB_ID", "TOTALPRIS_DRG"), cohort_ids) |>
    normalize_upper_names()

  person_col <- first_present_column(raw_df, c("PNR"), basename(path))
  year_col <- first_present_column(raw_df, c("AKTIVITETSAAR"), basename(path))
  cost_col <- first_present_column(raw_df, c("TOTALPRIS_DRG"), basename(path))
  linked_forlob_col <- intersect(c("DRGSGHFORLOB_ID"), names(raw_df))
  include_row <- rep(TRUE, nrow(raw_df))
  if (length(linked_forlob_col)) {
    linked_value <- trimws(as.character(raw_df[[linked_forlob_col[[1]]]]))
    include_row <- is.na(linked_value) | linked_value == ""
  }

  rows <- data.frame(
    person_id = standardize_person_id(raw_df[[person_col]]),
    year = suppressWarnings(as.integer(raw_df[[year_col]])),
    ambulatory_cost = safe_cost_numeric(raw_df[[cost_col]]),
    inpatient_cost = 0,
    cost_total = safe_cost_numeric(raw_df[[cost_col]]),
    source_era = "drg2018_kontakt_fallback",
    source_file = basename(path),
    price_source = "totalpris_drg_sum",
    coverage_status = if (length(linked_forlob_col)) "supplementary" else "partial",
    stringsAsFactors = FALSE
  ) |>
    dplyr::filter(include_row) |>
    dplyr::filter(!is.na(person_id), nzchar(person_id), !is.na(year))
  filter_rows_to_scan_scope(rows, scan_scope)
}

build_lpr_direct_cost_artifact <- function(config, cohort_ids = NULL, scan_scope = NULL) {
  amb_files <- filter_raw_files_for_scan_scope(
    list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_amb[0-9]{4}.*\\.parquet$"),
    "drgsoma_amb",
    scan_scope
  )
  hel_files <- filter_raw_files_for_scan_scope(
    list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_hel[0-9]{4}.*\\.parquet$"),
    "drgsoma_hel",
    scan_scope
  )
  include_2018 <- direct_cost_years_in_scope(2018L, scan_scope)
  kontakt_files <- if (isTRUE(include_2018)) {
    list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_kontakt2018.*\\.parquet$")
  } else {
    character(0)
  }
  sghforlob_files <- if (isTRUE(include_2018)) {
    list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_sghforlob2018.*\\.parquet$")
  } else {
    character(0)
  }
  cohort_ids <- cohort_ids %||% load_study_population_ids(config)

  n_cores <- direct_cost_parallel_cores(config)
  amb_collected <- collect_cost_rows(
    amb_files,
    read_legacy_drg_cost,
    table_type = "amb",
    cohort_ids = cohort_ids,
    n_cores = n_cores
  )
  hel_collected <- collect_cost_rows(
    hel_files,
    read_legacy_drg_cost,
    table_type = "hel",
    cohort_ids = cohort_ids,
    n_cores = n_cores
  )
  sgh_collected <- collect_cost_rows(
    sghforlob_files,
    read_drg2018_sghforlob,
    cohort_ids = cohort_ids,
    scan_scope = scan_scope,
    n_cores = n_cores
  )
  kontakt_collected <- if (length(kontakt_files)) {
    collect_cost_rows(
      kontakt_files,
      read_drg2018_kontakt,
      cohort_ids = cohort_ids,
      scan_scope = scan_scope,
      n_cores = n_cores
    )
  } else {
    list(rows = data.frame(), issues = character(0))
  }

  lpr_rows <- bind_rows(
    amb_collected$rows,
    hel_collected$rows,
    sgh_collected$rows,
    kontakt_collected$rows
  )
  lpr_rows <- filter_rows_to_scan_scope(lpr_rows, scan_scope)

  if (!nrow(lpr_rows)) {
    return(list(
      data = lpr_rows,
      issues = c(amb_collected$issues, hel_collected$issues, sgh_collected$issues, kontakt_collected$issues)
    ))
  }

  data <- lpr_rows |>
    group_by(person_id, year, source_era, price_source, coverage_status) |>
    summarise(
      ambulatory_cost = sum(ambulatory_cost, na.rm = TRUE),
      inpatient_cost = sum(inpatient_cost, na.rm = TRUE),
      cost_total = sum(cost_total, na.rm = TRUE),
      source_file = paste(sort(unique(source_file)), collapse = ";"),
      .groups = "drop"
    ) |>
    arrange(person_id, year, source_era) |>
    as.data.frame(stringsAsFactors = FALSE)

  list(
    data = data,
    issues = c(amb_collected$issues, hel_collected$issues, sgh_collected$issues, kontakt_collected$issues)
  )
}

read_hospital_drugs_direct_cost <- function(path, cohort_ids, scan_scope = NULL) {
  dataset <- arrow::open_dataset(path, format = "parquet")
  schema_cols <- names(dataset$schema)
  available_columns <- toupper(schema_cols)

  # Detect person ID column: INDBERETNINGMEDPRIS uses V_CPR, older formats use PNR
  person_col_upper <- intersect(c("PNR", "V_CPR"), available_columns)
  if (!length(person_col_upper)) {
    stop(sprintf("hospital-drugs file %s is missing a person ID column (PNR or V_CPR).", basename(path)))
  }
  person_col <- schema_cols[match(person_col_upper[[1]], available_columns)]

  simple_year_col <- intersect(c("AAR", "YEAR", "AKTIVITETSAAR", "V_AAR"), available_columns)
  simple_amount_col <- intersect(
    c("AMGROS_ADM_PRIS", "PRIS", "TOTALPRIS", "BELOEB", "BELOB", "AFREGNINGSPRIS", "COST"),
    available_columns
  )
  if (length(simple_year_col) && length(simple_amount_col)) {
    year_col <- simple_year_col[[1]]
    amount_col <- simple_amount_col[[1]]
    grouped <- read_grouped_year_column_cost_with_arrow(
      dataset = dataset,
      path_label = path,
      requested_columns = c(year_col, amount_col),
      cohort_ids = cohort_ids,
      year_column = year_col,
      cost_terms = stats::setNames(1, amount_col),
      scan_scope = scan_scope
    )
    if (!nrow(grouped)) {
      return(grouped)
    }
    grouped$source_file <- basename(path)
    grouped$price_source <- sprintf("hospital_drugs_%s_sum", tolower(amount_col))
    grouped$coverage_status <- "restricted"
    return(grouped[, c(
      "person_id", "year", "cost_total", "source_file", "price_source", "coverage_status"
    ), drop = FALSE])
  }

  raw_df <- read_filtered_parquet_df(
    path,
    c("AAR", "YEAR", "AKTIVITETSAAR", "V_AAR", "AFRPER", "DATO", "DATE", "EKSD",
      "D_ADM", "D_KONTAKT_START", "D_ORD_START",
      "AMGROS_ADM_PRIS", "PRIS", "TOTALPRIS", "BELOEB", "BELOB", "AFREGNINGSPRIS", "COST"),
    cohort_ids,
    person_col = person_col
  ) |>
    normalize_upper_names()

  object_name <- sprintf("hospital-drugs file %s", basename(path))
  person_col_df <- first_present_column(raw_df, c("PNR", "V_CPR"), object_name)
  year_value <- derive_year_value(
    raw_df,
    object_name,
    exact_year_candidates = c("AAR", "YEAR", "AKTIVITETSAAR", "V_AAR", "AFRPER"),
    exact_date_candidates = c("D_ADM", "D_KONTAKT_START", "D_ORD_START", "DATO", "DATE", "EKSD")
  )
  amount_col <- intersect(
    c("AMGROS_ADM_PRIS", "PRIS", "TOTALPRIS", "BELOEB", "BELOB", "AFREGNINGSPRIS", "COST"),
    names(raw_df)
  )
  if (!length(amount_col)) {
    amount_col <- first_matching_column(raw_df, c("AMGROS_ADM_PRIS", "PRIS", "BELOE?B", "COST"), object_name)
  } else {
    amount_col <- amount_col[[1]]
  }

  rows <- data.frame(
    person_id = standardize_person_id(raw_df[[person_col_df]]),
    year = year_value,
    cost_total = safe_cost_numeric(raw_df[[amount_col]]),
    source_file = basename(path),
    price_source = sprintf("hospital_drugs_%s_sum", tolower(amount_col)),
    coverage_status = "restricted",
    stringsAsFactors = FALSE
  ) |>
    dplyr::filter(!is.na(person_id), nzchar(person_id), !is.na(year))
  filter_rows_to_scan_scope(rows, scan_scope)
}

build_hospital_drugs_direct_cost_artifact <- function(config, cohort_ids = NULL, scan_scope = NULL) {
  path <- config$raw_indberetningmedpris_path
  if (!file.exists(path)) {
    return(list(data = data.frame(), issues = character(0)))
  }

  cohort_ids <- cohort_ids %||% load_study_population_ids(config)
  collected <- collect_cost_rows(
    path,
    read_hospital_drugs_direct_cost,
    cohort_ids = cohort_ids,
    scan_scope = scan_scope,
    n_cores = 1L
  )
  collected$rows <- filter_rows_to_scan_scope(collected$rows, scan_scope)
  if (!nrow(collected$rows)) {
    return(list(data = data.frame(), issues = collected$issues))
  }

  data <- collected$rows |>
    group_by(person_id, year, price_source, coverage_status) |>
    summarise(
      cost_total = sum(cost_total, na.rm = TRUE),
      source_file = paste(sort(unique(source_file)), collapse = ";"),
      .groups = "drop"
    ) |>
    arrange(person_id, year) |>
    as.data.frame(stringsAsFactors = FALSE)

  list(data = data, issues = collected$issues)
}

build_lpr_legacy_validation_summary <- function(config, cohort_ids = NULL, scan_scope = NULL) {
  legacy_files <- c(
    filter_raw_files_for_scan_scope(
      list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_amb[0-9]{4}.*\\.parquet$"),
      "drgsoma_amb",
      scan_scope
    ),
    filter_raw_files_for_scan_scope(
      list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_hel[0-9]{4}.*\\.parquet$"),
      "drgsoma_hel",
      scan_scope
    )
  )

  if (!length(legacy_files)) {
    return(data.frame())
  }
  cohort_ids <- cohort_ids %||% load_study_population_ids(config)

  bind_rows(lapply(legacy_files, function(path) {
    raw_df <- read_filtered_parquet_df(path, c("PNR", "V_AAR", "V_PRIS", "V_LANGPRIS", "V_TOTPRIS"), cohort_ids) |>
      normalize_upper_names()

    year_value <- if ("V_AAR" %in% names(raw_df) && nrow(raw_df)) {
      suppressWarnings(as.integer(raw_df$V_AAR[[1]]))
    } else {
      suppressWarnings(as.integer(sub(".*([0-9]{4}).*", "\\1", basename(path))))
    }
    base_cost <- if ("V_PRIS" %in% names(raw_df)) safe_cost_numeric(raw_df$V_PRIS) else rep(NA_real_, nrow(raw_df))
    long_cost <- if ("V_LANGPRIS" %in% names(raw_df)) safe_cost_numeric(raw_df$V_LANGPRIS) else rep(NA_real_, nrow(raw_df))
    total_cost <- if ("V_TOTPRIS" %in% names(raw_df)) safe_cost_numeric(raw_df$V_TOTPRIS) else rep(NA_real_, nrow(raw_df))
    decomposition_cost <- base_cost + long_cost
    has_total <- !is.na(total_cost) & total_cost > 0
    comparable <- has_total & !is.na(decomposition_cost)
    matches <- comparable & approx_equal_cost(total_cost, decomposition_cost)

    data.frame(
      source_file = basename(path),
      source_table = if (grepl("^drgsoma_amb", basename(path))) "drgsoma_amb" else "drgsoma_hel",
      year = year_value,
      rows = nrow(raw_df),
      rows_with_totpris = sum(has_total, na.rm = TRUE),
      rows_comparable = sum(comparable, na.rm = TRUE),
      rows_matching_decomposition = sum(matches, na.rm = TRUE),
      share_matching_decomposition = if (sum(comparable, na.rm = TRUE) > 0) {
        sum(matches, na.rm = TRUE) / sum(comparable, na.rm = TRUE)
      } else {
        NA_real_
      },
      rows_missing_totpris = sum(!has_total, na.rm = TRUE),
      stringsAsFactors = FALSE
    )
  })) |>
    arrange(year, source_table, source_file) |>
    as.data.frame(stringsAsFactors = FALSE)
}

empty_lpr_legacy_validation_summary <- function() {
  data.frame(
    source_file = character(),
    source_table = character(),
    year = integer(),
    rows = integer(),
    rows_with_totpris = integer(),
    rows_comparable = integer(),
    rows_matching_decomposition = integer(),
    share_matching_decomposition = numeric(),
    rows_missing_totpris = integer(),
    stringsAsFactors = FALSE
  )
}

build_direct_cost_person_year <- function(lmdb_cost, lpr_cost, primary_cost, hospital_drugs_cost) {
  bind_rows(
    if (nrow(lmdb_cost)) {
      lmdb_cost |>
        transmute(
          person_id,
          year,
          component = "lmdb",
          cost = cost_total,
          source_system = "lmdb",
          source_era = "lmdb",
          price_source,
          coverage_status
        )
    },
    if (nrow(lpr_cost)) {
      bind_rows(
        lpr_cost |>
          transmute(
            person_id,
            year,
            component = "lpr_sghforlob",
            cost = inpatient_cost,
            source_system = "lpr",
            source_era,
            price_source,
            coverage_status
          ),
        lpr_cost |>
          transmute(
            person_id,
            year,
            component = "lpr_kontakt",
            cost = ambulatory_cost,
            source_system = "lpr",
            source_era,
            price_source,
            coverage_status
          )
      )
    },
    if (nrow(primary_cost)) {
      primary_cost |>
        transmute(
          person_id,
          year,
          component = "primary_sector",
          cost = cost_total,
          source_system = source_system,
          source_era = source_system,
          price_source,
          coverage_status
        )
    },
    if (nrow(hospital_drugs_cost)) {
      hospital_drugs_cost |>
        transmute(
          person_id,
          year,
          component = "hospital_drugs",
          cost = cost_total,
          source_system = "hospital_drugs",
          source_era = "hospital_drugs",
          price_source,
          coverage_status
        )
    }
  ) |>
    arrange(component, person_id, year) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_direct_cost_coverage_summary <- function(lmdb_cost, lpr_cost, primary_cost, hospital_drugs_cost) {
  bind_rows(
    if (nrow(lmdb_cost)) lmdb_cost |> transmute(component = "lmdb", year, coverage_status),
    if (nrow(lpr_cost)) bind_rows(
      lpr_cost |> transmute(component = "lpr_sghforlob", year, coverage_status),
      lpr_cost |> transmute(component = "lpr_kontakt", year, coverage_status)
    ),
    if (nrow(primary_cost)) primary_cost |> transmute(component = "primary_sector", year, coverage_status),
    if (nrow(hospital_drugs_cost)) hospital_drugs_cost |> transmute(component = "hospital_drugs", year, coverage_status)
  ) |>
    group_by(component, year, coverage_status) |>
    summarise(person_year_rows = n(), .groups = "drop") |>
    arrange(component, year, coverage_status) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_direct_cost_component_year_summary <- function(combined_cost, component_year_availability) {
  if (!nrow(component_year_availability)) {
    return(data.frame())
  }

  aggregated_cost <- if (nrow(combined_cost)) {
    combined_cost |>
      group_by(component, year) |>
      summarise(
        person_year_rows = n(),
        unique_people = n_distinct(person_id),
        total_cost = sum(cost, na.rm = TRUE),
        .groups = "drop"
      )
  } else {
    data.frame(
      component = character(),
      year = integer(),
      person_year_rows = integer(),
      unique_people = integer(),
      total_cost = numeric(),
      stringsAsFactors = FALSE
    )
  }

  component_year_availability |>
    left_join(aggregated_cost, by = c("component", "year")) |>
    mutate(
      person_year_rows = dplyr::coalesce(person_year_rows, 0L),
      unique_people = dplyr::coalesce(unique_people, 0L),
      total_cost = dplyr::coalesce(total_cost, 0)
    ) |>
    arrange(component, year) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_primary_transition_summary <- function(source_inventory) {
  primary_inventory <- source_inventory[source_inventory$component == "primary_sector", , drop = FALSE]
  if (!nrow(primary_inventory)) {
    return(data.frame())
  }

  primary_inventory |>
    group_by(source_system, year, selected_for_build) |>
    summarise(
      files = n(),
      coverage_status = paste(sort(unique(coverage_status)), collapse = ";"),
      notes = paste(sort(unique(note)), collapse = ";"),
      .groups = "drop"
    ) |>
    arrange(year, source_system, desc(selected_for_build)) |>
    as.data.frame(stringsAsFactors = FALSE)
}

direct_cost_artifact_paths <- function(config) {
  list(
    lmdb_cost_path = output_file(config, "lmdb_direct_cost"),
    lpr_cost_path = output_file(config, "lpr_direct_cost"),
    primary_cost_path = output_file(config, "primary_sector_direct_cost"),
    hospital_drugs_cost_path = output_file(config, "hospital_drugs_direct_cost"),
    combined_cost_path = output_file(config, "direct_cost_person_year"),
    coverage_summary_path = output_file(config, "direct_cost_coverage_summary"),
    source_inventory_path = output_file(config, "direct_cost_source_inventory"),
    component_year_availability_path = output_file(config, "direct_cost_component_year_availability"),
    component_year_summary_path = output_file(config, "direct_cost_component_year_summary"),
    lpr_legacy_validation_path = output_file(config, "lpr_legacy_validation_summary"),
    primary_transition_summary_path = output_file(config, "primary_transition_summary"),
    issues_note_path = output_file(config, "direct_cost_build_notes")
  )
}

direct_cost_artifacts_available <- function(config) {
  paths <- direct_cost_artifact_paths(config)
  required_paths <- unlist(paths, use.names = FALSE)
  all(file.exists(required_paths))
}

read_direct_cost_csv <- function(path) {
  if (!file.exists(path)) {
    return(data.frame())
  }
  utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
}

read_direct_cost_artifacts <- function(config) {
  paths <- direct_cost_artifact_paths(config)
  if (!direct_cost_artifacts_available(config)) {
    missing_paths <- unlist(paths, use.names = FALSE)[!file.exists(unlist(paths, use.names = FALSE))]
    stop(sprintf(
      "Cannot reuse direct-cost artifacts because these outputs are missing: %s",
      paste(missing_paths, collapse = ", ")
    ), call. = FALSE)
  }

  list(
    source_inventory = read_direct_cost_csv(paths$source_inventory_path),
    lmdb_cost = arrow::read_parquet(paths$lmdb_cost_path),
    lpr_cost = arrow::read_parquet(paths$lpr_cost_path),
    primary_cost = arrow::read_parquet(paths$primary_cost_path),
    hospital_drugs_cost = arrow::read_parquet(paths$hospital_drugs_cost_path),
    combined_cost = arrow::read_parquet(paths$combined_cost_path),
    coverage_summary = read_direct_cost_csv(paths$coverage_summary_path),
    component_year_availability = arrow::read_parquet(paths$component_year_availability_path),
    component_year_summary = read_direct_cost_csv(paths$component_year_summary_path),
    lpr_legacy_validation = read_direct_cost_csv(paths$lpr_legacy_validation_path),
    primary_transition_summary = read_direct_cost_csv(paths$primary_transition_summary_path),
    issues = character(0),
    reused_existing = TRUE
  )
}

build_direct_cost_artifacts <- function(config) {
  ensure_output_dir(config)

  if (isTRUE(config$reuse_direct_cost_artifacts) &&
      !isTRUE(config$force_rebuild_direct_cost_artifacts) &&
      direct_cost_artifacts_available(config)) {
    message("  - using cached direct-cost artifacts")
    return(read_direct_cost_artifacts(config))
  }

  scan_scope <- derive_direct_cost_scan_scope(config)
  message_direct_cost_scan_scope(scan_scope)
  cohort_ids <- scan_scope$cohort_ids

  source_inventory      <- build_direct_cost_source_inventory(config, scan_scope = scan_scope)
  lmdb_result           <- build_lmdb_direct_cost_artifact(config, cohort_ids = cohort_ids, scan_scope = scan_scope)
  lpr_result            <- build_lpr_direct_cost_artifact(config, cohort_ids = cohort_ids, scan_scope = scan_scope)
  primary_result        <- build_primary_direct_cost_artifact(config, cohort_ids = cohort_ids, scan_scope = scan_scope)
  hospital_drugs_result <- build_hospital_drugs_direct_cost_artifact(
    config,
    cohort_ids = cohort_ids,
    scan_scope = scan_scope
  )
  lmdb_cost <- lmdb_result$data
  lpr_cost <- lpr_result$data
  primary_cost <- primary_result$data
  hospital_drugs_cost <- hospital_drugs_result$data
  combined_cost <- build_direct_cost_person_year(lmdb_cost, lpr_cost, primary_cost, hospital_drugs_cost)
  coverage_summary <- build_direct_cost_coverage_summary(lmdb_cost, lpr_cost, primary_cost, hospital_drugs_cost)
  component_year_availability <- build_component_year_availability(source_inventory)
  if (nrow(hospital_drugs_cost)) {
    hospital_drugs_availability <- hospital_drugs_cost |>
      group_by(year) |>
      summarise(
        component = "hospital_drugs",
        coverage_status = "restricted",
        source_tables = "indberetningmedpris",
        source_files = paste(sort(unique(source_file)), collapse = ";"),
        data_available = TRUE,
        .groups = "drop"
      ) |>
      select(component, year, coverage_status, source_tables, source_files, data_available) |>
      as.data.frame(stringsAsFactors = FALSE)
    component_year_availability <- bind_rows(component_year_availability, hospital_drugs_availability) |>
      arrange(component, year) |>
      as.data.frame(stringsAsFactors = FALSE)
  }
  component_year_summary <- build_direct_cost_component_year_summary(combined_cost, component_year_availability)
  lpr_legacy_validation <- if (isTRUE(config$skip_lpr_legacy_validation)) {
    empty_lpr_legacy_validation_summary()
  } else {
    build_lpr_legacy_validation_summary(config, cohort_ids = cohort_ids, scan_scope = scan_scope)
  }
  primary_transition_summary <- build_primary_transition_summary(source_inventory)

  list(
    source_inventory = source_inventory,
    lmdb_cost = lmdb_cost,
    lpr_cost = lpr_cost,
    primary_cost = primary_cost,
    hospital_drugs_cost = hospital_drugs_cost,
    combined_cost = combined_cost,
    coverage_summary = coverage_summary,
    component_year_availability = component_year_availability,
    component_year_summary = component_year_summary,
    lpr_legacy_validation = lpr_legacy_validation,
    primary_transition_summary = primary_transition_summary,
    issues = c(lmdb_result$issues, lpr_result$issues, primary_result$issues, hospital_drugs_result$issues),
    reused_existing = FALSE
  )
}

write_direct_cost_artifacts <- function(artifacts, config) {
  ensure_output_dir(config)

  output_paths <- direct_cost_artifact_paths(config)
  lapply(output_paths, ensure_output_parent)

  arrow::write_parquet(artifacts$lmdb_cost, output_paths$lmdb_cost_path)
  arrow::write_parquet(artifacts$lpr_cost, output_paths$lpr_cost_path)
  arrow::write_parquet(artifacts$primary_cost, output_paths$primary_cost_path)
  arrow::write_parquet(artifacts$hospital_drugs_cost, output_paths$hospital_drugs_cost_path)
  arrow::write_parquet(artifacts$combined_cost, output_paths$combined_cost_path)
  write_csv_file(artifacts$coverage_summary, output_paths$coverage_summary_path)
  write_csv_file(artifacts$source_inventory, output_paths$source_inventory_path)
  arrow::write_parquet(artifacts$component_year_availability, output_paths$component_year_availability_path)
  write_csv_file(artifacts$component_year_summary, output_paths$component_year_summary_path)
  write_csv_file(artifacts$lpr_legacy_validation, output_paths$lpr_legacy_validation_path)
  write_csv_file(artifacts$primary_transition_summary, output_paths$primary_transition_summary_path)
  writeLines(
    if (length(artifacts$issues)) artifacts$issues else "No build issues recorded.",
    output_paths$issues_note_path
  )

  output_paths
}
