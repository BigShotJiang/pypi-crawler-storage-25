# Vectorized year-addition that clamps Feb-29 to Feb-28 in non-leap years.
add_years_vec <- function(dates, n) {
  yr     <- as.integer(format(dates, "%Y")) + as.integer(n)
  mo     <- format(dates, "%m")
  dy     <- format(dates, "%d")
  result <- as.Date(paste(yr, mo, dy, sep = "-"))
  bad    <- !is.na(dates) & is.na(result)
  if (any(bad)) result[bad] <- as.Date(paste(yr[bad], mo[bad], "28", sep = "-"))
  result
}

# Approximate year-subtraction using 365-day years (avoids lubridate dependency).
subtract_year_days <- function(date_value, years) {
  date_value - as.difftime(365L * years, units = "days")
}
