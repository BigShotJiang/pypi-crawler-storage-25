suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

if (!exists("output_file", mode = "function") && file.exists(file.path("R", "output_paths.R"))) {
  source(file.path("R", "output_paths.R"))
}

supervisor_exposure_label <- function(exposed) {
  ifelse(as.logical(exposed), "Exposed", "Unexposed")
}

supervisor_metric_value <- function(summary_df, metric_name) {
  if (is.null(summary_df) || !nrow(summary_df) ||
      !all(c("metric", "value") %in% names(summary_df))) {
    return(NA_integer_)
  }

  matched <- summary_df$value[as.character(summary_df$metric) == metric_name]
  if (!length(matched)) {
    return(NA_integer_)
  }
  suppressWarnings(as.integer(matched[[1]]))
}

supervisor_required_columns <- function(df, columns, object_name) {
  missing <- setdiff(columns, names(df))
  if (length(missing)) {
    stop(sprintf(
      "%s is missing required columns: %s",
      object_name,
      paste(missing, collapse = ", ")
    ), call. = FALSE)
  }
  invisible(df)
}

supervisor_base_components <- function() {
  c("lmdb", "primary_sector", "lpr_sghforlob", "lpr_kontakt", "hospital_drugs")
}

supervisor_stable_core_components <- function() {
  c("lmdb", "primary_sector")
}

supervisor_lpr_drg_components <- function() {
  c("lpr_sghforlob", "lpr_kontakt")
}

supervisor_component_labels <- function() {
  c(
    lmdb = "LMDB",
    primary_sector = "Primary sector",
    lpr_sghforlob = "LPR/DRG SGHFORLOB",
    lpr_kontakt = "LPR/DRG Kontakt",
    hospital_drugs = "Hospital drugs",
    total = "Delivered-register total"
  )
}

supervisor_component_label <- function(component) {
  labels <- supervisor_component_labels()
  component <- as.character(component)
  result <- unname(labels[component])
  result[is.na(result)] <- component[is.na(result)]
  result
}

supervisor_component_set_label <- function(components) {
  paste(supervisor_component_label(components), collapse = " + ")
}

supervisor_coverage_priority <- function(status) {
  priority <- c(missing = 0L, restricted = 1L, supplementary = 2L, partial = 3L, full = 4L)
  result <- unname(priority[as.character(status)])
  result[is.na(result)] <- 0L
  result
}

supervisor_coverage_from_priority <- function(priority) {
  levels <- c("missing", "restricted", "supplementary", "partial", "full")
  levels[pmax(0L, pmin(4L, as.integer(priority))) + 1L]
}

supervisor_coverage_label <- function(status) {
  labels <- c(
    missing = "Missing",
    restricted = "Restricted",
    supplementary = "Supplementary",
    partial = "Partial",
    full = "Full"
  )
  status <- as.character(status)
  result <- unname(labels[status])
  result[is.na(result)] <- status[is.na(result)]
  result
}

supervisor_index_years <- function(matched_df) {
  if (is.null(matched_df) || !nrow(matched_df)) {
    return(integer())
  }
  if ("index_year" %in% names(matched_df)) {
    years <- suppressWarnings(as.integer(matched_df$index_year))
  } else if ("index_date" %in% names(matched_df)) {
    years <- suppressWarnings(as.integer(format(as.Date(matched_df$index_date), "%Y")))
  } else {
    return(integer())
  }
  years[!is.na(years)]
}

supervisor_followup_calendar_years <- function(matched_df, max_followup_years = 10L) {
  index_years <- supervisor_index_years(matched_df)
  if (!length(index_years)) {
    return(integer())
  }
  max_followup_years <- max(1L, suppressWarnings(as.integer(max_followup_years[[1]] %||% 10L)))
  seq(min(index_years), max(index_years) + max_followup_years - 1L)
}

supervisor_complete_window_flags <- function(matched_df, component_coverage, components, max_followup_years = 10L) {
  index_years <- supervisor_index_years(matched_df)
  if (!length(index_years)) {
    return(logical())
  }
  if (!nrow(component_coverage)) {
    return(rep(FALSE, length(index_years)))
  }

  max_followup_years <- max(1L, suppressWarnings(as.integer(max_followup_years[[1]] %||% 10L)))
  available <- component_coverage |>
    filter(component %in% components, as.logical(data_available))
  available_keys <- paste(available$component, available$year, sep = "::")

  vapply(index_years, function(index_year) {
    needed <- expand.grid(
      component = components,
      year = seq(index_year, index_year + max_followup_years - 1L),
      stringsAsFactors = FALSE
    )
    all(paste(needed$component, needed$year, sep = "::") %in% available_keys)
  }, logical(1))
}

supervisor_index_year_range_label <- function(index_years) {
  index_years <- sort(unique(index_years[!is.na(index_years)]))
  if (!length(index_years)) {
    return("None in matched cohort")
  }
  if (length(index_years) == 1L) {
    return(as.character(index_years[[1]]))
  }
  sprintf("%s-%s", min(index_years), max(index_years))
}

supervisor_max_numeric <- function(x) {
  x <- suppressWarnings(as.numeric(x))
  if (!length(x) || all(is.na(x))) {
    return(NA_real_)
  }
  max(x, na.rm = TRUE)
}

prepare_supervisor_cohort_flow <- function(baseline_df, matched_df, matching_summary = NULL) {
  supervisor_required_columns(matched_df, c("person_id", "exposed"), "matched cohort")

  matched_exposed <- sum(as.logical(matched_df$exposed), na.rm = TRUE)
  matched_controls <- sum(!as.logical(matched_df$exposed), na.rm = TRUE)
  eligible_cases <- supervisor_metric_value(matching_summary, "eligible_cases")
  matched_cases <- supervisor_metric_value(matching_summary, "matched_cases")
  if (is.na(matched_cases)) {
    matched_cases <- matched_exposed
  }

  steps <- data.frame(
    step = c(
      "baseline_cohort",
      "eligible_exposed_cases",
      "matched_exposed_cases",
      "matched_unexposed_controls",
      "matched_analysis_rows"
    ),
    label = c(
      "Baseline cohort",
      "Eligible exposed cases",
      "Matched exposed cases",
      "Matched unexposed controls",
      "Matched analysis rows"
    ),
    count = c(
      if (!is.null(baseline_df) && nrow(baseline_df)) nrow(baseline_df) else NA_integer_,
      eligible_cases,
      matched_cases,
      matched_controls,
      nrow(matched_df)
    ),
    stringsAsFactors = FALSE
  )

  steps <- steps[!is.na(steps$count), , drop = FALSE]
  steps$order <- seq_len(nrow(steps))
  steps
}

prepare_supervisor_index_year_distribution <- function(matched_df) {
  supervisor_required_columns(matched_df, c("index_date", "exposed"), "matched cohort")

  matched_df |>
    mutate(
      index_year = as.integer(format(as.Date(index_date), "%Y")),
      exposure_group = supervisor_exposure_label(exposed)
    ) |>
    filter(!is.na(index_year), !is.na(exposure_group)) |>
    count(exposure_group, index_year, name = "n") |>
    group_by(exposure_group) |>
    mutate(proportion = n / sum(n)) |>
    ungroup() |>
    arrange(index_year, exposure_group) |>
    as.data.frame(stringsAsFactors = FALSE)
}

prepare_supervisor_component_coverage <- function(
  component_year_availability,
  matched_df = NULL,
  max_followup_years = 10L
) {
  components <- unique(c(
    supervisor_base_components(),
    as.character(component_year_availability$component %||% character())
  ))

  if (is.null(component_year_availability) || !nrow(component_year_availability)) {
    availability <- data.frame(
      component = character(),
      year = integer(),
      coverage_status = character(),
      source_tables = character(),
      source_files = character(),
      data_available = logical(),
      stringsAsFactors = FALSE
    )
  } else {
    supervisor_required_columns(
      component_year_availability,
      c("component", "year", "coverage_status"),
      "component-year availability"
    )
    availability <- component_year_availability
    if (!"data_available" %in% names(availability)) {
      availability$data_available <- TRUE
    }
    if (!"source_tables" %in% names(availability)) {
      availability$source_tables <- ""
    }
    if (!"source_files" %in% names(availability)) {
      availability$source_files <- ""
    }
    availability <- availability |>
      mutate(
        component = as.character(component),
        year = suppressWarnings(as.integer(year)),
        data_available = as.logical(data_available),
        coverage_status = ifelse(data_available, as.character(coverage_status), "missing"),
        coverage_priority = supervisor_coverage_priority(coverage_status)
      ) |>
      filter(!is.na(component), !is.na(year)) |>
      group_by(component, year) |>
      summarise(
        coverage_status = supervisor_coverage_from_priority(max(coverage_priority, na.rm = TRUE)),
        source_tables = paste(sort(unique(source_tables)), collapse = ";"),
        source_files = paste(sort(unique(source_files)), collapse = ";"),
        data_available = any(data_available, na.rm = TRUE),
        .groups = "drop"
      ) |>
      as.data.frame(stringsAsFactors = FALSE)
  }

  years <- sort(unique(c(
    availability$year,
    supervisor_followup_calendar_years(matched_df, max_followup_years)
  )))
  if (!length(years)) {
    return(data.frame())
  }

  component_order <- unique(c(supervisor_base_components(), sort(setdiff(components, supervisor_base_components()))))
  grid <- expand.grid(
    component = component_order,
    year = years,
    stringsAsFactors = FALSE
  )

  merged <- grid |>
    left_join(availability, by = c("component", "year")) |>
    mutate(
      coverage_status = dplyr::coalesce(coverage_status, "missing"),
      data_available = dplyr::coalesce(data_available, FALSE),
      source_tables = dplyr::coalesce(source_tables, ""),
      source_files = dplyr::coalesce(source_files, ""),
      component_label = supervisor_component_label(component),
      coverage_label = supervisor_coverage_label(coverage_status),
      component_order = match(component, component_order)
    ) |>
    arrange(component_order, year) |>
    select(
      component, component_label, year, coverage_status, coverage_label,
      data_available, source_tables, source_files
    ) |>
    as.data.frame(stringsAsFactors = FALSE)

  merged
}

prepare_supervisor_analysis_options <- function(
  matched_df,
  component_coverage,
  max_followup_years = 10L
) {
  supervisor_required_columns(matched_df, c("person_id"), "matched cohort")
  index_years <- supervisor_index_years(matched_df)
  n_matched <- nrow(matched_df)

  option_components <- list(
    stable_core = supervisor_stable_core_components(),
    restricted_lpr_drg = supervisor_lpr_drg_components(),
    observed_delivered_total = supervisor_base_components()
  )
  option_titles <- c(
    stable_core = "Full cohort, stable-core costs",
    restricted_lpr_drg = "Restricted complete LPR/DRG window",
    observed_delivered_total = "Currently observed delivered-register total"
  )
  option_interpretation <- c(
    stable_core = "Best candidate for preserving early diagnosis years if LMDB and primary-sector coverage spans the follow-up window.",
    restricted_lpr_drg = "Shows what is gained in LPR/DRG completeness and what is lost in calendar-year and cohort coverage.",
    observed_delivered_total = "Progress output using all delivered rows; missing component years are not zero-cost years."
  )
  option_use <- c(
    stable_core = "Primary discussion candidate",
    restricted_lpr_drg = "Completeness sensitivity",
    observed_delivered_total = "Pipeline progress check"
  )

  rows <- lapply(names(option_components), function(option_id) {
    components <- option_components[[option_id]]
    complete_flags <- supervisor_complete_window_flags(
      matched_df,
      component_coverage,
      components = components,
      max_followup_years = max_followup_years
    )
    complete_years <- if (length(complete_flags)) index_years[complete_flags] else integer()
    matched_rows_with_complete_window <- sum(complete_flags, na.rm = TRUE)
    matched_rows_in_scope <- if (option_id == "restricted_lpr_drg") {
      matched_rows_with_complete_window
    } else {
      n_matched
    }

    data.frame(
      option_id = option_id,
      analysis_lens = unname(option_titles[[option_id]]),
      component_scope = supervisor_component_set_label(components),
      matched_rows_in_scope = matched_rows_in_scope,
      matched_rows_with_complete_window = matched_rows_with_complete_window,
      complete_window_share = if (n_matched > 0) matched_rows_with_complete_window / n_matched else NA_real_,
      complete_index_year_range = supervisor_index_year_range_label(complete_years),
      cost_interpretation = unname(option_interpretation[[option_id]]),
      recommended_use = unname(option_use[[option_id]]),
      stringsAsFactors = FALSE
    )
  })

  dplyr::bind_rows(rows) |>
    as.data.frame(stringsAsFactors = FALSE)
}

supervisor_cost_column <- function(df, preferred = c("total_direct_cost_weighted", "total_direct_cost")) {
  matched <- intersect(preferred, names(df))
  if (!length(matched)) {
    stop(sprintf(
      "matched cost panel is missing all candidate cost columns: %s",
      paste(preferred, collapse = ", ")
    ), call. = FALSE)
  }
  matched[[1]]
}

prepare_supervisor_preindex_cost_ecdf_data <- function(matched_cost_panel) {
  supervisor_required_columns(matched_cost_panel, c("person_id", "exposed", "segment"), "matched cost panel")
  cost_col <- supervisor_cost_column(matched_cost_panel)

  cost_expr <- rlang::sym(cost_col)
  person_costs <- matched_cost_panel |>
    filter(segment == "pre_index") |>
    mutate(
      exposure_group = supervisor_exposure_label(exposed),
      cost_value = suppressWarnings(as.numeric(!!cost_expr))
    ) |>
    group_by(person_id, exposure_group) |>
    summarise(preindex_cost = sum(cost_value, na.rm = TRUE), .groups = "drop") |>
    mutate(
      preindex_cost = pmax(preindex_cost, 0),
      log1p_preindex_cost = log1p(preindex_cost),
      zero_cost = preindex_cost <= 0
    ) |>
    arrange(exposure_group, preindex_cost, person_id) |>
    as.data.frame(stringsAsFactors = FALSE)

  summary <- person_costs |>
    group_by(exposure_group) |>
    summarise(
      people = n(),
      zero_cost_share = mean(zero_cost, na.rm = TRUE),
      mean_preindex_cost = mean(preindex_cost, na.rm = TRUE),
      median_preindex_cost = stats::median(preindex_cost, na.rm = TRUE),
      p75_preindex_cost = stats::quantile(preindex_cost, 0.75, na.rm = TRUE, names = FALSE),
      p90_preindex_cost = stats::quantile(preindex_cost, 0.90, na.rm = TRUE, names = FALSE),
      p95_preindex_cost = stats::quantile(preindex_cost, 0.95, na.rm = TRUE, names = FALSE),
      .groups = "drop"
    ) |>
    as.data.frame(stringsAsFactors = FALSE)

  list(person_costs = person_costs, summary = summary)
}

prepare_supervisor_annual_followup_costs <- function(annual_summary) {
  supervisor_required_columns(
    annual_summary,
    c("component", "followup_year", "exposed", "people", "annual_cost_ppy_reference_dkk"),
    "annual follow-up summary"
  )

  annual_summary |>
    filter(component == "total") |>
    mutate(
      followup_year = as.integer(followup_year),
      annual_cost_ppy_reference_dkk = as.numeric(annual_cost_ppy_reference_dkk),
      exposure_group = supervisor_exposure_label(exposed)
    ) |>
    arrange(followup_year, exposure_group) |>
    as.data.frame(stringsAsFactors = FALSE)
}

prepare_supervisor_component_set_annual_costs <- function(
  annual_summary,
  components,
  cost_scope
) {
  supervisor_required_columns(
    annual_summary,
    c("component", "followup_year", "exposed", "observed_person_years_sum", "cost_reference_dkk_sum"),
    "annual follow-up summary"
  )

  if (!"rows" %in% names(annual_summary)) {
    annual_summary$rows <- 0
  }
  if (!"people" %in% names(annual_summary)) {
    annual_summary$people <- NA_real_
  }

  annual_summary |>
    filter(component %in% components) |>
    mutate(
      followup_year = as.integer(followup_year),
      cost_reference_dkk_sum = as.numeric(cost_reference_dkk_sum),
      observed_person_years_sum = as.numeric(observed_person_years_sum)
    ) |>
    group_by(followup_year, exposed) |>
    summarise(
      component_set = cost_scope,
      components = supervisor_component_set_label(components),
      component_count = n_distinct(component),
      rows = sum(rows, na.rm = TRUE),
      people = supervisor_max_numeric(people),
      observed_person_years_sum = supervisor_max_numeric(observed_person_years_sum),
      cost_reference_dkk_sum = sum(cost_reference_dkk_sum, na.rm = TRUE),
      .groups = "drop"
    ) |>
    mutate(
      annual_cost_ppy_reference_dkk = ifelse(
        observed_person_years_sum > 0,
        cost_reference_dkk_sum / observed_person_years_sum,
        NA_real_
      ),
      exposure_group = supervisor_exposure_label(exposed)
    ) |>
    arrange(followup_year, exposure_group) |>
    as.data.frame(stringsAsFactors = FALSE)
}

prepare_supervisor_cumulative_difference_curve_from_annual <- function(annual_difference) {
  supervisor_required_columns(
    annual_difference,
    c("component", "followup_year", "difference_exposed_minus_unexposed"),
    "annual follow-up difference summary"
  )

  annual_difference |>
    filter(component == "total") |>
    mutate(
      followup_year = as.integer(followup_year),
      difference_exposed_minus_unexposed = as.numeric(difference_exposed_minus_unexposed)
    ) |>
    arrange(followup_year) |>
    mutate(cumulative_difference_reference_dkk = cumsum(difference_exposed_minus_unexposed)) |>
    as.data.frame(stringsAsFactors = FALSE)
}

prepare_supervisor_cumulative_difference_curve_from_panel <- function(followup_panel) {
  supervisor_required_columns(
    followup_panel,
    c("person_id", "exposed", "component", "followup_year"),
    "follow-up cost panel"
  )
  cost_col <- intersect(c("cost_reference_dkk_allocated", "annual_cost_ppy_reference_dkk"), names(followup_panel))
  if (!length(cost_col)) {
    stop(
      "follow-up cost panel is missing cost_reference_dkk_allocated or annual_cost_ppy_reference_dkk.",
      call. = FALSE
    )
  }
  cost_col <- cost_col[[1]]
  cost_expr <- rlang::sym(cost_col)
  panel <- followup_panel
  if (any(panel$component == "total", na.rm = TRUE)) {
    panel <- panel[panel$component == "total", , drop = FALSE]
  }

  person_year <- panel |>
    mutate(
      exposure_group = supervisor_exposure_label(exposed),
      followup_year = as.integer(followup_year),
      cost_value = suppressWarnings(as.numeric(!!cost_expr))
    ) |>
    filter(!is.na(followup_year), !is.na(exposure_group)) |>
    group_by(person_id, exposure_group, followup_year) |>
    summarise(followup_cost_reference_dkk = sum(cost_value, na.rm = TRUE), .groups = "drop") |>
    arrange(person_id, followup_year) |>
    group_by(person_id, exposure_group) |>
    mutate(cumulative_cost_reference_dkk = cumsum(followup_cost_reference_dkk)) |>
    ungroup()

  by_group <- person_year |>
    group_by(followup_year, exposure_group) |>
    summarise(
      people = n_distinct(person_id),
      mean_cumulative_cost_reference_dkk = mean(cumulative_cost_reference_dkk, na.rm = TRUE),
      .groups = "drop"
    ) |>
    as.data.frame(stringsAsFactors = FALSE)

  exposed <- by_group[by_group$exposure_group == "Exposed", c("followup_year", "people", "mean_cumulative_cost_reference_dkk")]
  unexposed <- by_group[by_group$exposure_group == "Unexposed", c("followup_year", "people", "mean_cumulative_cost_reference_dkk")]
  names(exposed) <- c("followup_year", "people_exposed", "mean_cumulative_cost_reference_dkk_exposed")
  names(unexposed) <- c("followup_year", "people_unexposed", "mean_cumulative_cost_reference_dkk_unexposed")

  merged <- merge(exposed, unexposed, by = "followup_year", all = FALSE)
  merged$difference_exposed_minus_unexposed <-
    merged$mean_cumulative_cost_reference_dkk_exposed -
    merged$mean_cumulative_cost_reference_dkk_unexposed
  merged$cumulative_difference_reference_dkk <- merged$difference_exposed_minus_unexposed
  merged[order(merged$followup_year), , drop = FALSE]
}

prepare_supervisor_component_set_cumulative_difference <- function(
  followup_panel,
  followup_segments,
  components,
  cost_scope
) {
  supervisor_required_columns(
    followup_panel,
    c("person_id", "exposed", "component", "followup_year"),
    "follow-up cost panel"
  )
  cost_col <- intersect(c("cost_reference_dkk_allocated", "annual_cost_ppy_reference_dkk"), names(followup_panel))
  if (!length(cost_col)) {
    stop(
      "follow-up cost panel is missing cost_reference_dkk_allocated or annual_cost_ppy_reference_dkk.",
      call. = FALSE
    )
  }
  cost_col <- cost_col[[1]]
  cost_expr <- rlang::sym(cost_col)

  costs <- followup_panel |>
    filter(component %in% components) |>
    mutate(
      followup_year = as.integer(followup_year),
      cost_value = suppressWarnings(as.numeric(!!cost_expr))
    )

  if (!is.null(followup_segments) && nrow(followup_segments)) {
    supervisor_required_columns(
      followup_segments,
      c("person_id", "exposed", "followup_year"),
      "follow-up segments"
    )
    segment_keys <- c("person_id", "exposed", "followup_year")
    if ("followup_segment_id" %in% names(followup_segments) && "followup_segment_id" %in% names(costs)) {
      segment_keys <- "followup_segment_id"
    }

    base_columns <- unique(c("followup_segment_id", "person_id", "exposed", "followup_year"))
    base <- followup_segments[, intersect(base_columns, names(followup_segments)), drop = FALSE] |>
      mutate(followup_year = as.integer(followup_year)) |>
      distinct()

    grouped_costs <- costs |>
      group_by(across(all_of(segment_keys))) |>
      summarise(followup_cost_reference_dkk = sum(cost_value, na.rm = TRUE), .groups = "drop")

    person_year <- base |>
      left_join(grouped_costs, by = segment_keys) |>
      mutate(followup_cost_reference_dkk = dplyr::coalesce(followup_cost_reference_dkk, 0))
  } else {
    person_year <- costs |>
      group_by(person_id, exposed, followup_year) |>
      summarise(followup_cost_reference_dkk = sum(cost_value, na.rm = TRUE), .groups = "drop")
  }

  person_year <- person_year |>
    mutate(
      exposure_group = supervisor_exposure_label(exposed),
      followup_year = as.integer(followup_year)
    ) |>
    filter(!is.na(followup_year), !is.na(exposure_group)) |>
    group_by(person_id, exposure_group, followup_year) |>
    summarise(followup_cost_reference_dkk = sum(followup_cost_reference_dkk, na.rm = TRUE), .groups = "drop") |>
    arrange(person_id, followup_year) |>
    group_by(person_id, exposure_group) |>
    mutate(cumulative_cost_reference_dkk = cumsum(followup_cost_reference_dkk)) |>
    ungroup()

  by_group <- person_year |>
    group_by(followup_year, exposure_group) |>
    summarise(
      people = n_distinct(person_id),
      mean_cumulative_cost_reference_dkk = mean(cumulative_cost_reference_dkk, na.rm = TRUE),
      .groups = "drop"
    ) |>
    as.data.frame(stringsAsFactors = FALSE)

  exposed <- by_group[by_group$exposure_group == "Exposed", c("followup_year", "people", "mean_cumulative_cost_reference_dkk")]
  unexposed <- by_group[by_group$exposure_group == "Unexposed", c("followup_year", "people", "mean_cumulative_cost_reference_dkk")]
  names(exposed) <- c("followup_year", "people_exposed", "mean_cumulative_cost_reference_dkk_exposed")
  names(unexposed) <- c("followup_year", "people_unexposed", "mean_cumulative_cost_reference_dkk_unexposed")

  merged <- merge(exposed, unexposed, by = "followup_year", all = FALSE)
  merged$difference_exposed_minus_unexposed <-
    merged$mean_cumulative_cost_reference_dkk_exposed -
    merged$mean_cumulative_cost_reference_dkk_unexposed
  merged$cumulative_difference_reference_dkk <- merged$difference_exposed_minus_unexposed
  merged$component_set <- cost_scope
  merged$components <- supervisor_component_set_label(components)
  merged[order(merged$followup_year), , drop = FALSE]
}

prepare_supervisor_cumulative_difference_curve <- function(data) {
  if (all(c("person_id", "exposed", "followup_year", "component") %in% names(data))) {
    return(prepare_supervisor_cumulative_difference_curve_from_panel(data))
  }
  prepare_supervisor_cumulative_difference_curve_from_annual(data)
}

supervisor_figure_paths <- function(config) {
  list(
    cohort_flow_plot = output_file(config, "supervisor_cohort_flow_plot"),
    index_year_distribution_plot = output_file(config, "supervisor_index_year_distribution_plot"),
    component_coverage_plot = output_file(config, "supervisor_component_coverage_plot"),
    preindex_cost_ecdf_plot = output_file(config, "supervisor_preindex_cost_ecdf_plot"),
    stable_core_annual_followup_costs_plot = output_file(config, "supervisor_stable_core_annual_followup_costs_plot"),
    stable_core_cumulative_cost_difference_plot = output_file(config, "supervisor_stable_core_cumulative_cost_difference_plot"),
    annual_followup_costs_plot = output_file(config, "supervisor_annual_followup_costs_plot"),
    cumulative_cost_difference_plot = output_file(config, "supervisor_cumulative_cost_difference_plot"),
    cohort_flow_csv = output_file(config, "supervisor_cohort_flow_csv"),
    index_year_distribution_csv = output_file(config, "supervisor_index_year_distribution_csv"),
    component_coverage_csv = output_file(config, "supervisor_component_coverage_csv"),
    analysis_options_csv = output_file(config, "supervisor_analysis_options_csv"),
    preindex_cost_summary_csv = output_file(config, "supervisor_preindex_cost_summary_csv"),
    stable_core_annual_followup_costs_csv = output_file(config, "supervisor_stable_core_annual_followup_costs_csv"),
    stable_core_cumulative_cost_difference_csv = output_file(config, "supervisor_stable_core_cumulative_cost_difference_csv"),
    annual_followup_costs_csv = output_file(config, "supervisor_annual_followup_costs_csv"),
    cumulative_cost_difference_csv = output_file(config, "supervisor_cumulative_cost_difference_csv"),
    figure_manifest_csv = output_file(config, "supervisor_figure_manifest_csv"),
    report_html = output_file(config, "supervisor_report_html"),
    report_rmd = output_file(config, "supervisor_report_rmd")
  )
}

require_supervisor_plot_packages <- function() {
  required <- c("ggplot2", "scales")
  missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) {
    stop(sprintf(
      "Supervisor figures require R package(s): %s. Install them with install.packages(c(%s)).",
      paste(missing, collapse = ", "),
      paste(sprintf("\"%s\"", missing), collapse = ", ")
    ), call. = FALSE)
  }
  invisible(TRUE)
}

supervisor_palette <- function() {
  c(Exposed = "#B23A48", Unexposed = "#2F6C9E")
}

plot_supervisor_cohort_flow <- function(flow_df) {
  require_supervisor_plot_packages()
  flow_df$label <- factor(flow_df$label, levels = rev(flow_df$label))

  ggplot2::ggplot(flow_df, ggplot2::aes(x = count, y = label)) +
    ggplot2::geom_col(width = 0.66, fill = "#3A6EA5") +
    ggplot2::geom_text(
      ggplot2::aes(label = scales::comma(count)),
      hjust = -0.08,
      size = 3.8
    ) +
    ggplot2::scale_x_continuous(labels = scales::comma, expand = ggplot2::expansion(mult = c(0, 0.18))) +
    ggplot2::labs(
      title = "Cohort flow",
      x = "People / rows",
      y = NULL
    ) +
    ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(panel.grid.major.y = ggplot2::element_blank())
}

plot_supervisor_index_year_distribution <- function(index_year_df) {
  require_supervisor_plot_packages()

  ggplot2::ggplot(
    index_year_df,
    ggplot2::aes(x = index_year, y = proportion, fill = exposure_group)
  ) +
    ggplot2::geom_col(position = ggplot2::position_dodge(width = 0.78), width = 0.72) +
    ggplot2::scale_fill_manual(values = supervisor_palette()) +
    ggplot2::scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
    ggplot2::scale_x_continuous(breaks = sort(unique(index_year_df$index_year))) +
    ggplot2::labs(
      title = "Index-year distribution",
      x = "Index year",
      y = "Within-group share",
      fill = NULL
    ) +
    ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(
      legend.position = "top",
      axis.text.x = ggplot2::element_text(angle = 45, hjust = 1)
    )
}

plot_supervisor_component_coverage <- function(coverage_df) {
  require_supervisor_plot_packages()
  if (!nrow(coverage_df)) {
    stop("No component coverage rows available for plotting.", call. = FALSE)
  }

  coverage_df$coverage_status <- factor(
    as.character(coverage_df$coverage_status),
    levels = c("missing", "restricted", "supplementary", "partial", "full")
  )
  component_levels <- rev(unique(coverage_df$component_label[order(match(coverage_df$component, supervisor_base_components()))]))
  coverage_df$component_label <- factor(coverage_df$component_label, levels = component_levels)
  year_range <- range(coverage_df$year, na.rm = TRUE)
  year_step <- max(1L, ceiling(diff(year_range) / 12))
  year_breaks <- seq(year_range[[1]], year_range[[2]], by = year_step)

  ggplot2::ggplot(
    coverage_df,
    ggplot2::aes(x = year, y = component_label, fill = coverage_status)
  ) +
    ggplot2::geom_tile(colour = "white", linewidth = 0.25) +
    ggplot2::scale_fill_manual(
      values = c(
        missing = "#E6E6E6",
        restricted = "#D9A441",
        supplementary = "#8C6BB1",
        partial = "#5D8AA8",
        full = "#4C8C5A"
      ),
      labels = supervisor_coverage_label,
      drop = FALSE
    ) +
    ggplot2::scale_x_continuous(breaks = year_breaks) +
    ggplot2::labs(
      title = "Cost-register coverage by calendar year",
      subtitle = "Missing register years are unavailable, not zero-cost years",
      x = "Calendar year",
      y = NULL,
      fill = "Coverage"
    ) +
    ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(
      legend.position = "top",
      panel.grid = ggplot2::element_blank(),
      axis.text.x = ggplot2::element_text(angle = 45, hjust = 1)
    )
}

plot_supervisor_preindex_cost_ecdf <- function(person_costs) {
  require_supervisor_plot_packages()

  ggplot2::ggplot(
    person_costs,
    ggplot2::aes(x = log1p_preindex_cost, colour = exposure_group)
  ) +
    ggplot2::stat_ecdf(linewidth = 0.9) +
    ggplot2::scale_colour_manual(values = supervisor_palette()) +
    ggplot2::scale_x_continuous(
      breaks = log1p(c(0, 100, 1000, 10000, 100000, 1000000)),
      labels = scales::comma(c(0, 100, 1000, 10000, 100000, 1000000))
    ) +
    ggplot2::scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
    ggplot2::labs(
      title = "Pre-index cost distribution",
      subtitle = "Empirical CDF of person-level pre-index total direct costs",
      x = "Pre-index total direct cost, DKK (log scale)",
      y = "Cumulative share",
      colour = NULL
    ) +
    ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(legend.position = "top")
}

plot_supervisor_annual_followup_costs <- function(
  annual_df,
  title = "Observed delivered-register annual costs",
  subtitle = "All currently delivered components; incomplete where component years are missing"
) {
  require_supervisor_plot_packages()

  ggplot2::ggplot(
    annual_df,
    ggplot2::aes(x = followup_year, y = annual_cost_ppy_reference_dkk, colour = exposure_group)
  ) +
    ggplot2::geom_line(linewidth = 0.9) +
    ggplot2::geom_point(size = 2.2) +
    ggplot2::scale_colour_manual(values = supervisor_palette()) +
    ggplot2::scale_x_continuous(breaks = sort(unique(annual_df$followup_year))) +
    ggplot2::scale_y_continuous(labels = scales::comma) +
    ggplot2::labs(
      title = title,
      subtitle = subtitle,
      x = "Follow-up year",
      y = "Mean annual cost per observed person-year, DKK",
      colour = NULL
    ) +
    ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(legend.position = "top")
}

plot_supervisor_cumulative_difference <- function(
  cumulative_df,
  title = "Observed delivered-register cumulative cost difference",
  subtitle = "Exposed minus unexposed, person-level cumulative mean costs"
) {
  require_supervisor_plot_packages()

  ggplot2::ggplot(
    cumulative_df,
    ggplot2::aes(x = followup_year, y = cumulative_difference_reference_dkk)
  ) +
    ggplot2::geom_hline(yintercept = 0, colour = "grey55", linewidth = 0.4) +
    ggplot2::geom_line(linewidth = 0.9, colour = "#4C6A4F") +
    ggplot2::geom_point(size = 2.2, colour = "#4C6A4F") +
    ggplot2::scale_x_continuous(breaks = sort(unique(cumulative_df$followup_year))) +
    ggplot2::scale_y_continuous(labels = scales::comma) +
    ggplot2::labs(
      title = title,
      subtitle = subtitle,
      x = "Follow-up year",
      y = "Cumulative difference, DKK"
    ) +
    ggplot2::theme_minimal(base_size = 12)
}

save_supervisor_plot <- function(plot, path, width = 8, height = 5, dpi = 150) {
  ensure_output_parent(path)
  ggplot2::ggsave(
    filename = path,
    plot = plot,
    width = width,
    height = height,
    dpi = dpi,
    bg = "white"
  )
  invisible(path)
}

read_supervisor_csv_if_exists <- function(config, artifact) {
  path <- resolve_existing_output_file(config, artifact)
  if (!file.exists(path)) {
    return(data.frame())
  }
  utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
}

read_supervisor_parquet <- function(config, artifact) {
  path <- resolve_existing_output_file(config, artifact)
  if (!file.exists(path)) {
    stop(sprintf("Required artifact '%s' not found at %s.", artifact, path), call. = FALSE)
  }
  arrow::read_parquet(path)
}

read_supervisor_parquet_if_exists <- function(config, artifact) {
  path <- resolve_existing_output_file(config, artifact)
  if (!file.exists(path)) {
    return(data.frame())
  }
  arrow::read_parquet(path)
}

build_supervisor_figures <- function(config) {
  require_supervisor_plot_packages()
  paths <- supervisor_figure_paths(config)

  matched_df <- read_supervisor_parquet(config, "matched_cohort")
  baseline_path <- resolve_existing_output_file(config, "baseline_dataset")
  baseline_df <- if (file.exists(baseline_path)) arrow::read_parquet(baseline_path) else NULL
  matching_summary <- read_supervisor_csv_if_exists(config, "matching_summary")
  matched_cost_panel <- read_supervisor_parquet(config, "matched_cost_panel")
  followup_panel <- read_supervisor_parquet_if_exists(config, "followup_cost_panel_compact")
  if (!nrow(followup_panel)) {
    followup_panel <- read_supervisor_parquet(config, "followup_cost_panel")
  }
  followup_segments <- read_supervisor_parquet_if_exists(config, "followup_segments")
  component_year_availability <- read_supervisor_parquet_if_exists(config, "direct_cost_component_year_availability")
  annual_summary <- read_supervisor_csv_if_exists(config, "followup_annual_cost_summary")
  max_followup_years <- suppressWarnings(as.integer(config$max_followup_years %||% NA_integer_))
  if (is.na(max_followup_years)) {
    candidate_followup_years <- suppressWarnings(as.integer(c(followup_panel$followup_year, annual_summary$followup_year)))
    candidate_followup_years <- candidate_followup_years[!is.na(candidate_followup_years)]
    max_followup_years <- if (length(candidate_followup_years)) max(candidate_followup_years) else 10L
  }

  flow <- prepare_supervisor_cohort_flow(baseline_df, matched_df, matching_summary)
  index_year <- prepare_supervisor_index_year_distribution(matched_df)
  component_coverage <- prepare_supervisor_component_coverage(
    component_year_availability,
    matched_df,
    max_followup_years = max_followup_years
  )
  analysis_options <- prepare_supervisor_analysis_options(
    matched_df,
    component_coverage,
    max_followup_years = max_followup_years
  )
  preindex <- prepare_supervisor_preindex_cost_ecdf_data(matched_cost_panel)
  stable_core_annual <- prepare_supervisor_component_set_annual_costs(
    annual_summary,
    components = supervisor_stable_core_components(),
    cost_scope = "Stable core"
  )
  stable_core_cumulative <- prepare_supervisor_component_set_cumulative_difference(
    followup_panel,
    followup_segments,
    components = supervisor_stable_core_components(),
    cost_scope = "Stable core"
  )
  annual <- prepare_supervisor_annual_followup_costs(annual_summary)
  cumulative <- prepare_supervisor_cumulative_difference_curve(followup_panel)

  write_csv_file(flow, paths$cohort_flow_csv)
  write_csv_file(index_year, paths$index_year_distribution_csv)
  write_csv_file(component_coverage, paths$component_coverage_csv)
  write_csv_file(analysis_options, paths$analysis_options_csv)
  write_csv_file(preindex$summary, paths$preindex_cost_summary_csv)
  write_csv_file(stable_core_annual, paths$stable_core_annual_followup_costs_csv)
  write_csv_file(stable_core_cumulative, paths$stable_core_cumulative_cost_difference_csv)
  write_csv_file(annual, paths$annual_followup_costs_csv)
  write_csv_file(cumulative, paths$cumulative_cost_difference_csv)

  save_supervisor_plot(plot_supervisor_cohort_flow(flow), paths$cohort_flow_plot, width = 7.5, height = 4.8)
  save_supervisor_plot(plot_supervisor_index_year_distribution(index_year), paths$index_year_distribution_plot, width = 8, height = 4.8)
  save_supervisor_plot(plot_supervisor_component_coverage(component_coverage), paths$component_coverage_plot, width = 9, height = 4.8)
  save_supervisor_plot(plot_supervisor_preindex_cost_ecdf(preindex$person_costs), paths$preindex_cost_ecdf_plot, width = 8, height = 4.8)
  save_supervisor_plot(
    plot_supervisor_annual_followup_costs(
      stable_core_annual,
      title = "Stable-core annual costs",
      subtitle = "LMDB + primary sector; intended to preserve the broadest calendar coverage"
    ),
    paths$stable_core_annual_followup_costs_plot,
    width = 8,
    height = 4.8
  )
  save_supervisor_plot(
    plot_supervisor_cumulative_difference(
      stable_core_cumulative,
      title = "Stable-core cumulative cost difference",
      subtitle = "LMDB + primary sector; exposed minus unexposed person-level cumulative means"
    ),
    paths$stable_core_cumulative_cost_difference_plot,
    width = 8,
    height = 4.8
  )
  save_supervisor_plot(plot_supervisor_annual_followup_costs(annual), paths$annual_followup_costs_plot, width = 8, height = 4.8)
  save_supervisor_plot(plot_supervisor_cumulative_difference(cumulative), paths$cumulative_cost_difference_plot, width = 8, height = 4.8)

  manifest <- data.frame(
    figure = c(
      "cohort_flow",
      "index_year_distribution",
      "component_coverage",
      "preindex_cost_ecdf",
      "stable_core_annual_followup_costs",
      "stable_core_cumulative_cost_difference",
      "annual_followup_costs",
      "cumulative_cost_difference"
    ),
    path = c(
      paths$cohort_flow_plot,
      paths$index_year_distribution_plot,
      paths$component_coverage_plot,
      paths$preindex_cost_ecdf_plot,
      paths$stable_core_annual_followup_costs_plot,
      paths$stable_core_cumulative_cost_difference_plot,
      paths$annual_followup_costs_plot,
      paths$cumulative_cost_difference_plot
    ),
    data_path = c(
      paths$cohort_flow_csv,
      paths$index_year_distribution_csv,
      paths$component_coverage_csv,
      paths$preindex_cost_summary_csv,
      paths$stable_core_annual_followup_costs_csv,
      paths$stable_core_cumulative_cost_difference_csv,
      paths$annual_followup_costs_csv,
      paths$cumulative_cost_difference_csv
    ),
    stringsAsFactors = FALSE
  )
  write_csv_file(manifest, paths$figure_manifest_csv)

  list(
    paths = paths,
    manifest = manifest,
    cohort_flow = flow,
    index_year_distribution = index_year,
    component_coverage = component_coverage,
    analysis_options = analysis_options,
    preindex_cost_summary = preindex$summary,
    stable_core_annual_followup_costs = stable_core_annual,
    stable_core_cumulative_cost_difference = stable_core_cumulative,
    annual_followup_costs = annual,
    cumulative_cost_difference = cumulative
  )
}

supervisor_report_template_path <- function(config) {
  candidates <- c(
    file.path(config$project_root %||% getwd(), "reports", "supervisor_report.Rmd"),
    file.path(getwd(), "reports", "supervisor_report.Rmd")
  )
  matched <- candidates[file.exists(candidates)]
  if (!length(matched)) {
    stop(sprintf(
      "Progress report template not found. Looked in: %s",
      paste(candidates, collapse = ", ")
    ), call. = FALSE)
  }
  normalizePath(matched[[1]], winslash = "/", mustWork = TRUE)
}

require_supervisor_report_packages <- function() {
  required <- c("rmarkdown", "knitr")
  missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) {
    stop(sprintf(
      "Progress report rendering requires R package(s): %s. Install them with install.packages(c(%s)).",
      paste(missing, collapse = ", "),
      paste(sprintf("\"%s\"", missing), collapse = ", ")
    ), call. = FALSE)
  }
  invisible(TRUE)
}

render_supervisor_report <- function(config, rebuild_figures = TRUE) {
  require_supervisor_report_packages()
  paths <- supervisor_figure_paths(config)
  if (isTRUE(rebuild_figures)) {
    build_supervisor_figures(config)
  }

  template_path <- supervisor_report_template_path(config)
  ensure_output_parent(paths$report_rmd)
  file.copy(template_path, paths$report_rmd, overwrite = TRUE)

  output_dir <- dirname(paths$report_html)
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  rendered <- rmarkdown::render(
    input = paths$report_rmd,
    output_file = basename(paths$report_html),
    output_dir = output_dir,
    params = list(
      project_root = config$project_root,
      output_dir = config$output_dir,
      supervisor_dir = output_dir,
      generated_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
    ),
    envir = new.env(parent = globalenv()),
    quiet = TRUE
  )
  normalizePath(rendered, winslash = "/", mustWork = TRUE)
}
