suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

timed_cost_panel_step <- function(label, expr) {
  start <- Sys.time()
  message(sprintf("  - %s...", label))
  value <- force(expr)
  elapsed <- as.numeric(difftime(Sys.time(), start, units = "secs"))
  message(sprintf("  - %s completed in %.1f seconds", label, elapsed))
  value
}

cost_panel_component_levels <- function() {
  c("lmdb", "hospital_drugs", "lpr_sghforlob", "lpr_kontakt", "primary_sector")
}

empty_component_year_availability <- function() {
  data.frame(
    component = character(),
    year = integer(),
    coverage_status = character(),
    source_tables = character(),
    source_files = character(),
    data_available = logical(),
    stringsAsFactors = FALSE
  )
}

filter_direct_cost_to_segments <- function(direct_cost_df, segment_rows) {
  if (!nrow(direct_cost_df) || !nrow(segment_rows)) {
    return(direct_cost_df[0, , drop = FALSE])
  }

  segment_years <- as.integer(segment_rows$calendar_year)
  min_year <- min(segment_years, na.rm = TRUE)
  max_year <- max(segment_years, na.rm = TRUE)
  panel_person_ids <- unique(as.character(segment_rows$person_id))
  panel_person_ids <- panel_person_ids[!is.na(panel_person_ids) & nzchar(panel_person_ids)]

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(direct_cost_df)
    dt[, person_id := as.character(person_id)]
    dt[, year := as.integer(year)]
    dt <- dt[year >= min_year & year <= max_year]
    if (!nrow(dt)) {
      return(as.data.frame(dt))
    }
    id_dt <- data.table::data.table(person_id = panel_person_ids)
    data.table::setkey(dt, person_id)
    data.table::setkey(id_dt, person_id)
    return(as.data.frame(dt[id_dt, nomatch = 0L]))
  }

  direct_cost_df[
    as.character(direct_cost_df$person_id) %in% panel_person_ids &
      as.integer(direct_cost_df$year) >= min_year &
      as.integer(direct_cost_df$year) <= max_year,
    ,
    drop = FALSE
  ]
}

read_direct_cost_person_year_for_segments <- function(config, segment_rows) {
  direct_cost_path <- resolve_existing_output_file(config, "direct_cost_person_year")
  if (!file.exists(direct_cost_path)) {
    stop(sprintf("Direct-cost person-year parquet not found at %s. Run direct_cost first.", direct_cost_path))
  }
  if (!nrow(segment_rows)) {
    return(arrow::read_parquet(direct_cost_path)[0, , drop = FALSE])
  }

  segment_years <- as.integer(segment_rows$calendar_year)
  min_year <- min(segment_years, na.rm = TRUE)
  max_year <- max(segment_years, na.rm = TRUE)
  panel_person_ids <- unique(as.character(segment_rows$person_id))
  panel_person_ids <- panel_person_ids[!is.na(panel_person_ids) & nzchar(panel_person_ids)]

  direct_cost_ds <- arrow::open_dataset(direct_cost_path)
  filtered_ds <- direct_cost_ds |>
    filter(year >= min_year, year <= max_year)

  if (exists("filter_dataset_to_person_ids", mode = "function")) {
    return(filter_dataset_to_person_ids(filtered_ds, panel_person_ids, id_col = "person_id") |>
      collect() |>
      as.data.frame(stringsAsFactors = FALSE))
  }

  filtered_ds |>
    collect() |>
    filter(as.character(person_id) %in% panel_person_ids) |>
    as.data.frame(stringsAsFactors = FALSE)
}

read_component_year_availability_for_cost_panel <- function(config) {
  availability_path <- resolve_existing_output_file(config, "direct_cost_component_year_availability")
  if (!file.exists(availability_path)) {
    return(empty_component_year_availability())
  }
  arrow::read_parquet(availability_path)
}

build_cost_panel_segments_vectorized <- function(matched_df, followup_years = 5L) {
  valid <- !is.na(matched_df$index_date) & !is.na(matched_df$baseline_start)
  if (!any(valid)) return(data.frame())
  df <- matched_df[valid, , drop = FALSE]
  n  <- nrow(df)

  index_date     <- as.Date(df$index_date)
  baseline_start <- as.Date(df$baseline_start)
  censor_date    <- df$censor_date

  study_end_unc <- add_years_vec(index_date, followup_years) - 1L
  study_end     <- study_end_unc
  has_censor    <- !is.na(censor_date)
  if (any(has_censor)) {
    study_end[has_censor] <- pmin(as.Date(censor_date[has_censor]), study_end_unc[has_censor])
  }

  index_year <- as.integer(format(index_date, "%Y"))
  start_year <- as.integer(format(baseline_start, "%Y"))
  end_year   <- as.integer(format(study_end, "%Y"))
  valid_span <- !is.na(start_year) & !is.na(end_year) & end_year >= start_year
  if (!any(valid_span)) {
    return(data.frame())
  }

  df <- df[valid_span, , drop = FALSE]
  index_date <- index_date[valid_span]
  baseline_start <- baseline_start[valid_span]
  study_end <- study_end[valid_span]
  index_year <- index_year[valid_span]
  start_year <- start_year[valid_span]
  end_year <- end_year[valid_span]
  n <- nrow(df)

  year_counts <- end_year - start_year + 1L
  row_index <- rep(seq_len(n), times = year_counts)
  calendar_year <- rep(start_year, times = year_counts) + sequence(year_counts) - 1L

  unique_calendar_years <- sort(unique(calendar_year))
  calendar_year_match <- match(calendar_year, unique_calendar_years)
  year_start_lookup <- as.Date(sprintf("%04d-01-01", unique_calendar_years))
  year_end_lookup <- as.Date(sprintf("%04d-12-31", unique_calendar_years))
  yr_start <- year_start_lookup[calendar_year_match]
  yr_end   <- year_end_lookup[calendar_year_match]
  yr_days  <- as.numeric(yr_end - yr_start) + 1

  ps     <- pmax(yr_start, baseline_start[row_index])
  pe     <- pmin(yr_end,   index_date[row_index] - 1L)
  pre_ok <- pe >= ps

  qs      <- pmax(yr_start, index_date[row_index])
  qe      <- pmin(yr_end,   study_end[row_index])
  post_ok <- qe >= qs

  build_segment_rows <- function(ok, segment_label, segment_start, segment_end) {
    if (!any(ok)) {
      return(data.frame())
    }
    source_index <- row_index[ok]
    data.frame(
      person_id         = df$person_id[source_index],
      exposed           = as.logical(df$exposed[source_index]),
      diagnosis_group   = df$diagnosis_group[source_index],
      severity          = df$severity[source_index],
      index_date        = index_date[source_index],
      calendar_year     = calendar_year[ok],
      segment           = segment_label,
      relative_year     = as.integer(calendar_year[ok] - index_year[source_index]),
      segment_start     = segment_start[ok],
      segment_end       = segment_end[ok],
      observed_fraction = as.numeric(segment_end[ok] - segment_start[ok] + 1) / yr_days[ok],
      stringsAsFactors  = FALSE
    )
  }

  segment_parts <- list(
    build_segment_rows(pre_ok, "pre_index", ps, pe),
    build_segment_rows(post_ok, "post_index", qs, qe)
  )
  if (requireNamespace("data.table", quietly = TRUE)) {
    segments <- data.table::rbindlist(segment_parts, use.names = TRUE, fill = TRUE)
    data.table::setorderv(segments, c("person_id", "calendar_year", "segment"))
    return(as.data.frame(segments))
  }

  bind_rows(segment_parts) |>
    arrange(person_id, calendar_year, segment) |>
    as.data.frame(stringsAsFactors = FALSE)
}

reshape_direct_cost_wide <- function(direct_cost_df) {
  component_levels <- cost_panel_component_levels()
  if (!nrow(direct_cost_df)) {
    return(data.frame(
      person_id = character(),
      calendar_year = integer(),
      lmdb_cost = numeric(),
      hospital_drugs_cost = numeric(),
      lpr_sghforlob_cost = numeric(),
      lpr_kontakt_cost = numeric(),
      primary_sector_cost = numeric(),
      total_direct_cost = numeric(),
      stringsAsFactors = FALSE
    ))
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(direct_cost_df)
    dt[, person_id := as.character(person_id)]
    dt[, year := as.integer(year)]
    dt[, component := as.character(component)]
    dt[, cost := as.numeric(cost)]
    cost_by_component <- dt[, .(cost = sum(cost, na.rm = TRUE)), by = .(person_id, year, component)]
    merged <- data.table::dcast(
      cost_by_component,
      person_id + year ~ component,
      value.var = "cost",
      fill = 0
    )

    for (component_name in component_levels) {
      if (!(component_name %in% names(merged))) {
        merged[, (component_name) := 0]
      }
      data.table::setnames(merged, component_name, paste0(component_name, "_cost"))
    }

    cost_cols <- paste0(component_levels, "_cost")
    for (col_name in cost_cols) {
      merged[is.na(get(col_name)), (col_name) := 0]
    }
    merged[, total_direct_cost := lmdb_cost + hospital_drugs_cost + lpr_sghforlob_cost +
      lpr_kontakt_cost + primary_sector_cost]
    data.table::setnames(merged, "year", "calendar_year")
    data.table::setorderv(merged, c("person_id", "calendar_year"))
    data.table::setcolorder(merged, c("person_id", "calendar_year", cost_cols, "total_direct_cost"))
    return(as.data.frame(merged))
  }

  cost_by_component <- direct_cost_df |>
    group_by(person_id, year, component) |>
    summarise(cost = sum(cost, na.rm = TRUE), .groups = "drop")

  merged <- cost_by_component |>
    tidyr::pivot_wider(
      id_cols = c(person_id, year),
      names_from = component,
      values_from = cost,
      names_glue = "{component}_cost",
      values_fill = list(cost = 0)
    )

  for (component_name in component_levels) {
    col_name <- paste0(component_name, "_cost")
    if (!(col_name %in% names(merged))) {
      merged[[col_name]] <- numeric(nrow(merged))
    }
    merged[[col_name]][is.na(merged[[col_name]])] <- 0
  }

  merged$total_direct_cost <- merged$lmdb_cost + merged$hospital_drugs_cost + merged$lpr_sghforlob_cost +
    merged$lpr_kontakt_cost + merged$primary_sector_cost
  merged$calendar_year <- merged$year
  merged$year <- NULL
  merged |>
    arrange(person_id, calendar_year) |>
    as.data.frame(stringsAsFactors = FALSE)
}

reshape_component_year_availability_wide <- function(component_year_availability) {
  component_levels <- cost_panel_component_levels()
  if (is.null(component_year_availability) || !nrow(component_year_availability)) {
    return(data.frame(
      calendar_year = integer(),
      lmdb_data_available = logical(),
      hospital_drugs_data_available = logical(),
      lpr_sghforlob_data_available = logical(),
      lpr_kontakt_data_available = logical(),
      primary_sector_data_available = logical(),
      lmdb_coverage_status = character(),
      hospital_drugs_coverage_status = character(),
      lpr_sghforlob_coverage_status = character(),
      lpr_kontakt_coverage_status = character(),
      primary_sector_coverage_status = character(),
      stringsAsFactors = FALSE
    ))
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(component_year_availability)
    dt[, component := as.character(component)]
    dt[, year := as.integer(year)]
    dt[, data_available := as.logical(data_available)]
    dt[, coverage_status := as.character(coverage_status)]
    availability <- dt[, .(
      data_available = any(data_available, na.rm = TRUE),
      coverage_status = {
        status <- coverage_status
        if (any(status == "full", na.rm = TRUE)) {
          "full"
        } else if (any(status == "partial", na.rm = TRUE)) {
          "partial"
        } else if (any(status == "supplementary", na.rm = TRUE)) {
          "supplementary"
        } else if (any(status == "restricted", na.rm = TRUE)) {
          "restricted"
        } else {
          "missing"
        }
      }
    ), by = .(component, year)]

    available_wide <- data.table::dcast(
      availability,
      year ~ component,
      value.var = "data_available",
      fill = FALSE
    )
    coverage_wide <- data.table::dcast(
      availability,
      year ~ component,
      value.var = "coverage_status",
      fill = "missing"
    )
    for (component_name in component_levels) {
      if (!(component_name %in% names(available_wide))) {
        available_wide[, (component_name) := FALSE]
      }
      data.table::setnames(available_wide, component_name, paste0(component_name, "_data_available"))
      if (!(component_name %in% names(coverage_wide))) {
        coverage_wide[, (component_name) := "missing"]
      }
      data.table::setnames(coverage_wide, component_name, paste0(component_name, "_coverage_status"))
    }

    merged <- merge(available_wide, coverage_wide, by = "year", all = TRUE, sort = FALSE)
    available_cols <- paste0(component_levels, "_data_available")
    coverage_cols <- paste0(component_levels, "_coverage_status")
    for (col_name in available_cols) {
      merged[is.na(get(col_name)), (col_name) := FALSE]
    }
    for (col_name in coverage_cols) {
      merged[is.na(get(col_name)), (col_name) := "missing"]
    }
    data.table::setnames(merged, "year", "calendar_year")
    data.table::setorderv(merged, "calendar_year")
    data.table::setcolorder(merged, c("calendar_year", available_cols, coverage_cols))
    return(as.data.frame(merged))
  }

  availability <- component_year_availability |>
    select(component, year, data_available, coverage_status) |>
    group_by(component, year) |>
    summarise(
      data_available = any(data_available, na.rm = TRUE),
      coverage_status = case_when(
        any(coverage_status == "full") ~ "full",
        any(coverage_status == "partial") ~ "partial",
        any(coverage_status == "supplementary") ~ "supplementary",
        any(coverage_status == "restricted") ~ "restricted",
        TRUE ~ "missing"
      ),
      .groups = "drop"
    )

  merged <- availability |>
    tidyr::pivot_wider(
      id_cols = year,
      names_from = component,
      values_from = c(data_available, coverage_status),
      names_glue = "{component}_{.value}",
      values_fill = list(data_available = FALSE, coverage_status = "missing")
    )

  for (component_name in component_levels) {
    available_col <- paste0(component_name, "_data_available")
    coverage_col <- paste0(component_name, "_coverage_status")
    if (!(available_col %in% names(merged))) {
      merged[[available_col]] <- FALSE
    }
    if (!(coverage_col %in% names(merged))) {
      merged[[coverage_col]] <- "missing"
    }
    merged[[available_col]][is.na(merged[[available_col]])] <- FALSE
    merged[[coverage_col]][is.na(merged[[coverage_col]])] <- "missing"
  }

  merged$calendar_year <- merged$year
  merged$year <- NULL
  merged |>
    arrange(calendar_year) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_cost_panel_from_segments <- function(segment_rows, direct_cost_df, component_year_availability = NULL) {
  if (!nrow(segment_rows)) {
    return(segment_rows)
  }

  direct_cost_df <- filter_direct_cost_to_segments(direct_cost_df, segment_rows)
  direct_cost_wide <- timed_cost_panel_step("reshape direct-cost rows wide", {
    reshape_direct_cost_wide(direct_cost_df)
  })
  if (is.null(component_year_availability)) {
    component_year_availability <- empty_component_year_availability()
  }
  availability_wide <- timed_cost_panel_step("reshape component-year availability", {
    reshape_component_year_availability_wide(component_year_availability)
  })

  component_levels <- cost_panel_component_levels()
  cost_cols <- c(paste0(component_levels, "_cost"), "total_direct_cost")
  available_cols <- paste0(component_levels, "_data_available")
  coverage_cols <- paste0(component_levels, "_coverage_status")
  weighted_cols <- paste0(cost_cols, "_weighted")

  if (requireNamespace("data.table", quietly = TRUE)) {
    panel_dt <- data.table::as.data.table(segment_rows)
    direct_dt <- data.table::as.data.table(direct_cost_wide)
    availability_dt <- data.table::as.data.table(availability_wide)

    if (nrow(direct_dt)) {
      direct_dt[, person_id := as.character(person_id)]
      direct_dt[, calendar_year := as.integer(calendar_year)]
      panel_dt <- direct_dt[panel_dt, on = .(person_id, calendar_year)]
    }
    if (nrow(availability_dt)) {
      availability_dt[, calendar_year := as.integer(calendar_year)]
      panel_dt <- availability_dt[panel_dt, on = .(calendar_year)]
    }

    for (col_name in cost_cols) {
      if (!(col_name %in% names(panel_dt))) {
        panel_dt[, (col_name) := 0]
      }
      panel_dt[is.na(get(col_name)), (col_name) := 0]
    }
    for (col_name in available_cols) {
      if (!(col_name %in% names(panel_dt))) {
        panel_dt[, (col_name) := FALSE]
      }
      panel_dt[is.na(get(col_name)), (col_name) := FALSE]
    }
    for (col_name in coverage_cols) {
      if (!(col_name %in% names(panel_dt))) {
        panel_dt[, (col_name) := "missing"]
      }
      panel_dt[is.na(get(col_name)), (col_name) := "missing"]
    }

    panel_dt[, lmdb_cost_weighted := lmdb_cost * observed_fraction]
    panel_dt[, hospital_drugs_cost_weighted := hospital_drugs_cost * observed_fraction]
    panel_dt[, lpr_sghforlob_cost_weighted := lpr_sghforlob_cost * observed_fraction]
    panel_dt[, lpr_kontakt_cost_weighted := lpr_kontakt_cost * observed_fraction]
    panel_dt[, primary_sector_cost_weighted := primary_sector_cost * observed_fraction]
    panel_dt[, total_direct_cost_weighted := total_direct_cost * observed_fraction]
    data.table::setorderv(panel_dt, c("person_id", "calendar_year", "segment"))
    data.table::setcolorder(panel_dt, c(
      names(segment_rows),
      cost_cols,
      available_cols,
      coverage_cols,
      weighted_cols
    ))
    return(as.data.frame(panel_dt))
  }

  panel <- segment_rows |>
    left_join(direct_cost_wide, by = c("person_id", "calendar_year")) |>
    left_join(availability_wide, by = "calendar_year") |>
    mutate(
      lmdb_cost = dplyr::coalesce(lmdb_cost, 0),
      hospital_drugs_cost = dplyr::coalesce(hospital_drugs_cost, 0),
      lpr_sghforlob_cost = dplyr::coalesce(lpr_sghforlob_cost, 0),
      lpr_kontakt_cost = dplyr::coalesce(lpr_kontakt_cost, 0),
      primary_sector_cost = dplyr::coalesce(primary_sector_cost, 0),
      total_direct_cost = dplyr::coalesce(total_direct_cost, 0),
      lmdb_data_available = dplyr::coalesce(lmdb_data_available, FALSE),
      hospital_drugs_data_available = dplyr::coalesce(hospital_drugs_data_available, FALSE),
      lpr_sghforlob_data_available = dplyr::coalesce(lpr_sghforlob_data_available, FALSE),
      lpr_kontakt_data_available = dplyr::coalesce(lpr_kontakt_data_available, FALSE),
      primary_sector_data_available = dplyr::coalesce(primary_sector_data_available, FALSE),
      lmdb_coverage_status = dplyr::coalesce(lmdb_coverage_status, "missing"),
      hospital_drugs_coverage_status = dplyr::coalesce(hospital_drugs_coverage_status, "missing"),
      lpr_sghforlob_coverage_status = dplyr::coalesce(lpr_sghforlob_coverage_status, "missing"),
      lpr_kontakt_coverage_status = dplyr::coalesce(lpr_kontakt_coverage_status, "missing"),
      primary_sector_coverage_status = dplyr::coalesce(primary_sector_coverage_status, "missing"),
      lmdb_cost_weighted = lmdb_cost * observed_fraction,
      hospital_drugs_cost_weighted = hospital_drugs_cost * observed_fraction,
      lpr_sghforlob_cost_weighted = lpr_sghforlob_cost * observed_fraction,
      lpr_kontakt_cost_weighted = lpr_kontakt_cost * observed_fraction,
      primary_sector_cost_weighted = primary_sector_cost * observed_fraction,
      total_direct_cost_weighted = total_direct_cost * observed_fraction
    ) |>
    arrange(person_id, calendar_year, segment)

  as.data.frame(panel, stringsAsFactors = FALSE)
}

build_cost_panel <- function(matched_df, direct_cost_df, component_year_availability = NULL, followup_years = 5L) {
  segment_rows <- timed_cost_panel_step("build cost-panel time segments", {
    build_cost_panel_segments_vectorized(matched_df, followup_years = followup_years)
  })
  timed_cost_panel_step("build matched cost panel", {
    build_cost_panel_from_segments(
      segment_rows,
      direct_cost_df,
      component_year_availability = component_year_availability
    )
  })
}

build_cost_panel_summary <- function(cost_panel_df) {
  if (!nrow(cost_panel_df)) {
    return(data.frame())
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(cost_panel_df)
    summary_dt <- dt[, .(
      rows = .N,
      people = data.table::uniqueN(person_id),
      observed_fraction_mean = mean(observed_fraction, na.rm = TRUE),
      total_direct_cost_weighted_sum = sum(total_direct_cost_weighted, na.rm = TRUE)
    ), by = .(segment, relative_year, exposed)]
    data.table::setorderv(summary_dt, c("segment", "relative_year", "exposed"))
    return(as.data.frame(summary_dt))
  }

  cost_panel_df |>
    group_by(segment, relative_year, exposed) |>
    summarise(
      rows = n(),
      people = n_distinct(person_id),
      observed_fraction_mean = mean(observed_fraction, na.rm = TRUE),
      total_direct_cost_weighted_sum = sum(total_direct_cost_weighted, na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(segment, relative_year, exposed) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_cost_panel_data_availability_summary <- function(cost_panel_df) {
  if (!nrow(cost_panel_df)) {
    return(data.frame())
  }

  if (requireNamespace("data.table", quietly = TRUE)) {
    dt <- data.table::as.data.table(cost_panel_df)
    summary_dt <- dt[, .(
      rows = .N,
      people = data.table::uniqueN(person_id),
      lmdb_year_available_share = mean(lmdb_data_available, na.rm = TRUE),
      hospital_drugs_year_available_share = mean(hospital_drugs_data_available, na.rm = TRUE),
      lpr_sghforlob_year_available_share = mean(lpr_sghforlob_data_available, na.rm = TRUE),
      lpr_kontakt_year_available_share = mean(lpr_kontakt_data_available, na.rm = TRUE),
      primary_sector_year_available_share = mean(primary_sector_data_available, na.rm = TRUE)
    ), by = .(segment, relative_year, exposed)]
    data.table::setorderv(summary_dt, c("segment", "relative_year", "exposed"))
    return(as.data.frame(summary_dt))
  }

  cost_panel_df |>
    group_by(segment, relative_year, exposed) |>
    summarise(
      rows = n(),
      people = n_distinct(person_id),
      lmdb_year_available_share = mean(lmdb_data_available, na.rm = TRUE),
      hospital_drugs_year_available_share = mean(hospital_drugs_data_available, na.rm = TRUE),
      lpr_sghforlob_year_available_share = mean(lpr_sghforlob_data_available, na.rm = TRUE),
      lpr_kontakt_year_available_share = mean(lpr_kontakt_data_available, na.rm = TRUE),
      primary_sector_year_available_share = mean(primary_sector_data_available, na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(segment, relative_year, exposed) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_cost_panel_artifacts <- function(
  matched_df,
  config = NULL,
  direct_cost_df = NULL,
  component_year_availability = NULL,
  followup_years = 5L
) {
  segment_rows <- timed_cost_panel_step("build cost-panel time segments", {
    build_cost_panel_segments_vectorized(matched_df, followup_years = followup_years)
  })

  if (is.null(direct_cost_df)) {
    if (is.null(config)) {
      stop("direct_cost_df must be supplied when config is NULL.", call. = FALSE)
    }
    direct_cost_df <- timed_cost_panel_step("read direct-cost rows for matched panel", {
      read_direct_cost_person_year_for_segments(config, segment_rows)
    })
  } else {
    direct_cost_df <- timed_cost_panel_step("filter direct-cost rows to matched panel", {
      filter_direct_cost_to_segments(direct_cost_df, segment_rows)
    })
  }

  if (is.null(component_year_availability)) {
    component_year_availability <- if (is.null(config)) {
      empty_component_year_availability()
    } else {
      timed_cost_panel_step("read component-year availability", {
        read_component_year_availability_for_cost_panel(config)
      })
    }
  }

  cost_panel_df <- timed_cost_panel_step("build matched cost panel", {
    build_cost_panel_from_segments(
      segment_rows,
      direct_cost_df,
      component_year_availability = component_year_availability
    )
  })
  panel_summary <- timed_cost_panel_step("summarize matched cost panel", {
    build_cost_panel_summary(cost_panel_df)
  })
  data_availability_summary <- timed_cost_panel_step("summarize cost-panel availability", {
    build_cost_panel_data_availability_summary(cost_panel_df)
  })

  list(
    cost_panel = cost_panel_df,
    panel_summary = panel_summary,
    data_availability_summary = data_availability_summary
  )
}

write_cost_panel_outputs <- function(cost_panel_df, config, panel_summary = NULL, data_availability_summary = NULL) {
  ensure_output_dir(config)

  if (is.null(panel_summary)) {
    panel_summary <- timed_cost_panel_step("summarize matched cost panel", {
      build_cost_panel_summary(cost_panel_df)
    })
  }
  if (is.null(data_availability_summary)) {
    data_availability_summary <- timed_cost_panel_step("summarize cost-panel availability", {
      build_cost_panel_data_availability_summary(cost_panel_df)
    })
  }

  paths <- list(
    cost_panel_path = output_file(config, "matched_cost_panel"),
    cost_panel_summary_path = output_file(config, "matched_cost_panel_summary"),
    cost_panel_data_availability_summary_path = output_file(config, "matched_cost_panel_data_availability_summary")
  )
  lapply(paths, ensure_output_parent)

  timed_cost_panel_step("write matched cost panel parquet", {
    arrow::write_parquet(cost_panel_df, paths$cost_panel_path)
  })
  timed_cost_panel_step("write matched cost panel summary", {
    write_csv_file(panel_summary, paths$cost_panel_summary_path)
  })
  timed_cost_panel_step("write cost-panel availability summary", {
    write_csv_file(data_availability_summary, paths$cost_panel_data_availability_summary_path)
  })

  paths
}
