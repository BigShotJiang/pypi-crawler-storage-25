# societal_costs_r

This is the `societal_costs_r` analysis project. The Python wheel embeds a minimal runtime copy of
this directory so it can be unpacked on the remote Windows host.

## Included Files

- `R/`
- `reports/`
- `scripts/`
- `HFAUDD.json`
- `README.md`

Generated files in `output/` and local contract tests are development artifacts. They are not
included in the Python wheel or copied by the `unpack` command.

## Expected Usage

1. Unpack the project with:

   ```bash
   unpack /target/path
   ```

2. Set the working directory to the unpacked project.
3. Configure input and output paths in `scripts/99_run_all_interactive.R` or by setting
   environment variables.
4. Run `scripts/99_run_all_interactive.R`, or run the stage scripts individually.

Install the usual pipeline R packages plus `ggplot2`, `scales`, `rmarkdown`, and `knitr` if you want
to render the supervisor-update figures and report.

## Path Configuration

The pipeline can be configured with high-level input roots:

- `intermediate_root`: directory containing `cohort/`, `core/`, and `registers/`.
- `raw_register_root`: flat parquet delivery directory containing files such as
  `lmdb*.parquet`, `sssy*.parquet`, `sysi*.parquet`, and `drgsoma_*.parquet`.
- `raw_popc_dir`: POPC root containing `akm/`, `ind/`, and `uddf/` when those files
  are stored separately from the flat cost-register delivery.

On the production Windows server, these paths default to the standard project locations,
including the fixed `indberetningmedpris.parquet` path and the separate POPC root.
Other environments can set `intermediate_root`, `raw_register_root`, and optionally
`raw_popc_dir` in `scripts/99_run_all_interactive.R`.

The standard production defaults are:

- `intermediate_root`: `E:/workdata/708245/CDEF/Personer/tkra0028/societal_costs/sc_output`
- `raw_register_root`: `E:/workdata/708245/data/202603`
- `raw_popc_dir`: `E:/workdata/708245/data/popc`
- `raw_indberetningmedpris_path`: `E:/workdata/708245/CDEF/Projekter/SAS_konvertering/binary_test/indberetningmedpris/indberetningmedpris.parquet`

POPC is not treated as a flat monetary-register directory. AKM and IND are read from yearly files
such as `popc/akm/2024.parquet` and `popc/ind/2024.parquet`; UDDF is read from
`popc/uddf/202409.parquet`.

## Output Layout

Outputs are structured by default under `output/`:

- `inventory/`: input artifact manifests.
- `baseline/`: baseline cohort, notes, parental-education diagnostics, and matching inputs.
- `matching/`: matched cohort, pairs, and matching diagnostics.
- `tables/`: Table 1 HTML/CSV outputs.
- `costs/direct/`, `costs/harmonized/`, `costs/panels/`, `costs/followup/`: cost build artifacts.
- `analysis/`: primary, discount, subgroup, survivor, proxy, and model-diagnostic outputs.
- `analysis/supervisor/`: quick progress figures for supervisor updates.
- `cache/`: reusable baseline-preparation artifacts for parent POPC lookups and pre-index
  utilization component-years.
- `logs/`: pipeline log, warning log, and run summary.

Set `output_layout = "flat"` or `SOCIETAL_COSTS_OUTPUT_LAYOUT=flat` if you need the old flat output
directory while comparing old runs. Readers first look for the structured path and then fall back to
the legacy flat filename.

The follow-up stage writes `costs/followup/followup_segments.parquet` plus compact cost panels by
default. The compact panel keeps one total row per person-year segment and only non-zero component
rows; the analysis stage expands one component at a time when fitting models. Set
`write_full_followup_panel = TRUE` or `SOCIETAL_COSTS_WRITE_FULL_FOLLOWUP_PANEL=true` only when you
need the old full person x follow-up-year x component parquet files. Survivor-only follow-up analysis
also requires the full panel, so keep `skip_survivors = TRUE` for the fastest compact path.

## Logs And Diagnostics

The interactive runner prints the active paths and writes:

- `output/logs/pipeline.log`: stage start, completion, and error events.
- `output/logs/warnings.csv`: captured warnings with stage names.
- `output/logs/run_summary.csv`: elapsed time and status per stage.
- `output/analysis/model_diagnostics.csv`: model status, sample sizes, positive-cost counts,
  failure messages, and actionable notes for the cost-analysis models.
- `output/analysis/survivors/model_diagnostics.csv`: the same diagnostics for the survivor-only
  secondary analysis.

Cost-analysis model warnings are summarized into statuses such as `ok`, `fit_failed`,
`insufficient_positive_costs`, and `unstable_fit` so production runs are easier to scan.
CSV outputs use semantic rounding to keep reports readable: counts and years are whole numbers,
monetary estimates are generally rounded to two decimals, and rates/shares are rounded to four.

The supervisor-update figure script writes a compact progress pack under
`output/analysis/supervisor/`: cohort flow, index-year distribution, cost-register coverage,
analysis-option summaries, pre-index cost ECDF, stable-core annual/cumulative costs, and observed
delivered-register annual/cumulative costs. Run `scripts/10_build_supervisor_figures.R` after the
follow-up summaries exist, or add `supervisor_figures` to `stages_to_run` after `followup` in
`scripts/99_run_all_interactive.R`. To render the expandable HTML progress report, run
`scripts/11_render_supervisor_report.R` or add `supervisor_report` after `supervisor_figures`; the
report includes the figures plus the matched Table 1.

The supervisor report is coverage-aware. Stable-core costs are LMDB plus primary-sector costs.
Observed delivered-register totals use all currently delivered component rows, but missing
component-years are unavailable data and should not be interpreted as zero-cost years.

## Performance Notes

The interactive runner skips `parental_education_diagnostics` by default. That stage is diagnostic
only and can be expensive on the full production cohort because it scans and joins raw UDDF parent
records. To run it, add `parental_education_diagnostics` to `stages_to_run` and set
`run_parental_education_diagnostics = TRUE`.

The baseline stage prints nested timings for source loading, parental POPC covariates, and
pre-index utilization metrics. On the production host, use those lines to identify whether runtime
is dominated by raw POPC scans, register usage scans, or in-memory joins.

The expensive baseline-preparation steps now write reusable files under `output/cache/`. Re-running
baseline with the same cohort will reuse parent POPC lookups, derived parent covariates, and
pre-index component-year tables instead of rescanning raw POPC/register parquet files. The baseline
core table is cached too, so repeated descriptive-covariate refreshes can skip source loading and
cohort snapshot selection. Add `prepare_baseline_cache` to `stages_to_run` if you want to
materialize those caches as a separate step before running the full baseline. Set
`force_rebuild_prepared_baseline_artifacts = TRUE` or
`SOCIETAL_COSTS_FORCE_REBUILD_PREPARED_BASELINE_ARTIFACTS=true` when raw inputs have changed and
the caches should be rebuilt.

If the `data.table` package is installed, baseline uses faster keyed/rolling joins for cohort
snapshot selection and parent AKM/UDDF/BEF lookups. The code still runs without `data.table`, but
production runs should install it because these joins are among the main scale-sensitive steps.

The direct-cost stage skips the legacy LPR price-decomposition validation by default because it is a
diagnostic-only second scan of the legacy DRG files. Set `skip_lpr_legacy_validation = FALSE` or
`SOCIETAL_COSTS_SKIP_LPR_LEGACY_VALIDATION=false` only when you need that validation table. Primary
sector files are also filtered to the canonical source years before reading: SYSI through 2004 and
SSSY from 2005 onward.

For production analysis runs, keep `direct_cost_scope = "matched_analysis"` after matching has been
run. In that mode the direct-cost stage reads `matched_cohort.parquet`, scans only matched person
IDs, and skips raw yearly parquet files outside the matched baseline/follow-up calendar window.
Set `direct_cost_scope = "baseline"` only if you deliberately need direct-cost artifacts for the
full baseline cohort. Use `direct_cost_n_cores` to parallelize per-file extraction on Windows PSOCK
workers; start with 4 on the remote host and reduce it if shared storage becomes saturated.

For education-rule changes, prefer `force_rebuild_parent_covariates = TRUE` while leaving
`force_rebuild_prepared_baseline_artifacts = FALSE`. The parent UDDF lookup cache stores the
parent-specific raw `HFAUDD`/`HF_KILDE` extract, so the baseline can reclassify parent education
from `output/cache/` without rescanning the full production UDDF parquet. The first run after this
cache-schema change may need one raw UDDF scan; subsequent reclassifications should reuse the
cached extract. Keep `force_rebuild_prepared_baseline_artifacts = FALSE` for that first run too:
if the existing parent UDDF cache lacks raw `HFAUDD`/`HF_KILDE`, it is rebuilt once automatically
without forcing the unrelated prepared baseline caches. If multiple UDDF snapshots are present,
only the latest snapshot file is scanned.

The recommended remote-production options for the current descriptive-covariate refresh are:

```r
pipeline_settings$use_production_paths <- NULL
pipeline_settings$intermediate_root <- NULL
pipeline_settings$raw_register_root <- NULL
pipeline_settings$raw_popc_dir <- NULL
pipeline_settings$raw_indberetningmedpris_path <- NULL
pipeline_settings$reuse_prepared_baseline_artifacts <- TRUE
pipeline_settings$force_rebuild_prepared_baseline_artifacts <- FALSE
pipeline_settings$force_rebuild_parent_covariates <- TRUE
pipeline_settings$run_parental_education_diagnostics <- FALSE
```

Run `baseline`, `refresh_matched_cohort`, and the downstream output stages. Do not run `matching`
again unless the matching variables or matching algorithm changed. Use
`force_rebuild_prepared_baseline_artifacts = TRUE` only for a deliberate full raw-input cache
rebuild.

When only descriptive baseline covariates have changed and the matching criteria are unchanged,
reuse the existing `matching/matched_pairs.parquet` instead of rerunning risk-set matching. Run
`baseline`, then `refresh_matched_cohort`, then downstream stages such as `table1`, `cost_panel`,
`followup`, and `analyse`. The refresh stage rematerializes `matched_cohort.parquet` from the
current baseline while keeping the existing matched pair assignments.
