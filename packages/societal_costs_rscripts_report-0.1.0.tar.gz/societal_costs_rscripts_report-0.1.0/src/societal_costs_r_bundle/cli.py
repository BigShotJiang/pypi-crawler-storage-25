import argparse
import shutil
from contextlib import contextmanager
from importlib.resources import as_file, files
from pathlib import Path
from typing import Iterator

EXCLUDED_BUNDLE_DIRS = {"output", "tests", "docs", "__pycache__"}
EXCLUDED_BUNDLE_FILES = {".DS_Store", ".RData", ".Rhistory"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="unpack",
        description="Copy the bundled societal_costs_r project into the target path.",
    )
    parser.add_argument("target", help="Exact destination path for the unpacked project")
    return parser.parse_args()


def ignore_bundle_artifacts(_directory: str, names: list[str]) -> set[str]:
    return {
        name
        for name in names
        if name in EXCLUDED_BUNDLE_DIRS or name in EXCLUDED_BUNDLE_FILES
    }


def is_runtime_project(path) -> bool:
    return path.joinpath("R").is_dir() and path.joinpath("scripts").is_dir()


@contextmanager
def bundle_source_path() -> Iterator[Path]:
    bundled_source = files("societal_costs_r_bundle").joinpath("r_project")
    if bundled_source.is_dir() and is_runtime_project(bundled_source):
        with as_file(bundled_source) as source_path:
            yield source_path
        return

    checkout_source = Path(__file__).resolve().parents[2] / "r_project"
    if checkout_source.is_dir() and is_runtime_project(checkout_source):
        yield checkout_source
        return

    raise SystemExit("Bundled r_project source was not found.")


def copy_bundle(target: Path) -> Path:
    resolved_target = target.expanduser().resolve()

    if resolved_target.exists():
        raise SystemExit(f"Target already exists: {resolved_target}")

    resolved_target.parent.mkdir(parents=True, exist_ok=True)
    with bundle_source_path() as source_path:
        shutil.copytree(source_path, resolved_target, ignore=ignore_bundle_artifacts)
    return resolved_target


def main() -> None:
    args = parse_args()
    target = copy_bundle(Path(args.target))
    print(f"Copied bundled project to {target}")


if __name__ == "__main__":
    main()
