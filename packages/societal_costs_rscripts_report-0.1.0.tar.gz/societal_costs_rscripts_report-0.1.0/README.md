# Societal Costs R Bundle

This repository develops the `societal_costs_r` R project and ships it through a small Python
wheel wrapper. The Python package exists only because the remote Windows host accepts packages from
its PyPI mirror but does not allow pasting or normal file transfer.

The source of truth for the R code is the top-level `r_project/` directory. During wheel builds,
that project is embedded as `societal_costs_r_bundle/r_project/` so the installed `unpack` command
can copy it onto the remote host.

## Repository Layout

- `r_project/R/`: R helper functions used by the pipeline.
- `r_project/scripts/`: stage scripts and the interactive runner.
- `r_project/tests/`: local R contract tests, not included in the wheel.
- `src/societal_costs_r_bundle/`: Python unpack wrapper.
- `tests/`: Python tests for the wrapper.

## Included Files

- `R/`
- `scripts/`
- `HFAUDD.json`
- `AUDD_HOVED_E_L1L5_K.txt`
- `README.md`

## Usage

```bash
unpack /target/path
```

The command copies the bundled project files into the exact path you provide and fails if that path already exists.
Generated outputs, local R tests, and docs are intentionally not copied into the unpacked runtime project.

Inside the unpacked R project, `scripts/99_run_all_interactive.R` is the main entry point for
interactive production runs. On Windows it defaults to the standard production roots for
`intermediate_root`, the flat cost-register delivery, POPC, and `indberetningmedpris.parquet`.
Outputs are written in a structured `output/` tree by default, with logs under `output/logs/` and
model diagnostics under `output/analysis/model_diagnostics.csv`.

## Release Checks

Run the local checks before building:

```bash
just release-check
```

Or run the steps individually:

```bash
just r-test
just py-test
uv build
```

Inspect the wheel before publishing:

```bash
unzip -l dist/*.whl
```

The wheel should include `r_project/R/`, `r_project/scripts/`, `r_project/HFAUDD.json`,
`r_project/AUDD_HOVED_E_L1L5_K.txt`, and `r_project/README.md`; it should not include
`r_project/output/`.
