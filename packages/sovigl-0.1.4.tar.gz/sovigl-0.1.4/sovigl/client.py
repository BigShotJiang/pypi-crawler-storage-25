import requests
import uuid


def map_status(status):
    if status == "allowed":
        return "approved"
    if status == "pending_approval":
        return "pending"
    return status


class Decision:
    def __init__(self, data):
        self.status = map_status(data["status"])
        self.reason = data.get("reason")
        self.cdt = data.get("cdt")
        self.decision_id = data.get("decision_id")
        self.approval_id = data.get("approval_id")
        self.fraud = data.get("fraud")
        self.risk_assessment = data.get("risk_assessment")
        self.explanation_registry = data.get("explanation_registry")
        self.policy_version = data.get("policy_version")
        self.summary = data.get("summary")

    @property
    def approved(self):
        return self.status == "approved"

    @property
    def pending(self):
        return self.status == "pending"

    @property
    def blocked(self):
        return self.status == "blocked"


def evaluate(
    action: str,
    context: dict,
    org_id: str = "demo_fintech",
    api_key: str = "demo_key_123",
):
    payload = {
        "org_id": org_id,
        "type": action.split(".")[0],
        "amount": context["amount"],
        "role": context.get("role", "employee"),
        "user_id": context.get("user_id", "sdk_user"),
        "agent_id": context.get("agent_id", "sdk_client"),
        "agent_type": context.get("agent_type", "ai"),
        "decision_id": str(uuid.uuid4()),
    }
    if context["amount"] > 10000:
        payload["description"] = "SDK test transaction"

    headers = {"api-key": api_key, "Content-Type": "application/json"}

    response = requests.post(
        "https://web-production-e334b.up.railway.app/check",
        headers=headers,
        json=payload,
    )
    data = response.json()
    return Decision(data)
