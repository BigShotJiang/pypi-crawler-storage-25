# sovigl

Sovigl evaluates approval decisions for actions like payments and returns one of three states: `approved`, `pending`, or `blocked`.

## Install

```bash
pip install sovigl
```

## Access

Demo: works instantly, no key needed. pip install sovigl and call evaluate().

Production: email sovigl100@gmail.com to get org_id and api_key.

## Python Usage

```python
import sovigl

for amount in [500, 5000, 100000]:
    decision = sovigl.evaluate(
        action="payment.create",
        context={"amount": amount}
    )

    print(f"amount={amount} status={decision.status} reason={decision.reason}")

    if decision.approved:
        print("Execute payment")
    elif decision.pending:
        print("Human approval required")
    elif decision.blocked:
        print("Do not execute payment")
```

## Full Response Object (Python)

`evaluate()` returns a `Decision` object with these fields/properties:

- `status`: final mapped status (`approved`, `pending`, `blocked`)
- `reason`: backend reason string when present
- `cdt`: backend metadata object when present
- `approved`: boolean helper (`status == "approved"`)
- `pending`: boolean helper (`status == "pending"`)
- `blocked`: boolean helper (`status == "blocked"`)

Example:

```python
decision = sovigl.evaluate(
    action="payment.create",
    context={"amount": 5000}
)

print(decision.status)
print(decision.reason)
print(decision.cdt)
print(decision.__dict__)
```

## Pending Workflow

When `decision.status == "pending"`, treat it as a hard stop for automatic execution and route to manual approval.

```python
decision = sovigl.evaluate(
    action="payment.create",
    context={"amount": 5000}
)

if decision.pending:
    approval_id = getattr(decision, "approval_id", None)
    print("Human approval required", approval_id, decision.reason)
```

## Context Fields

| Field | Type | Description |
| --- | --- | --- |
| `amount` | number | Transaction amount evaluated against policy |
| `user_id` | string | Who is performing the action |
| `role` | string | Caller role - employee, manager, or admin |
| `agent_id` | string | AI agent identifier if action is automated |

## Action Types

Sovigl accepts any action string in <type>.<verb> format.
- payment.create
- expense.submit
- transfer.initiate
- loan.approve

## Node.js Usage

```javascript
const sovigl = require("./node/index.js");

(async () => {
  for (const amount of [500, 5000, 100000]) {
    const decision = await sovigl.evaluate({
      action: "payment.create",
      context: { amount }
    });

    console.log({ amount, status: decision.status, reason: decision.reason });
  }
})();
```

Backend: https://github.com/riteshkumar10000/sovigl-sdk | PyPI: https://pypi.org/project/sovigl/
