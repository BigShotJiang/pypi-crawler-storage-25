#
# Copyright 2026 Tabs Data Inc.
#

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
