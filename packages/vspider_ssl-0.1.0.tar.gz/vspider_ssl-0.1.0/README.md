# vspider-api

AES-based SSL bypass and cookie challenge solver.

## Install
pip install vspider-api

## Usage
from vspider_api import check
result = check("https://example.com")
