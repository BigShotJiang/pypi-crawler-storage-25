# CrateDB Fivetran Destination Changelog

## Unreleased

## v0.1.2 - 2026-05-08

- Added `Capabilities` RPC endpoint, returning `BatchFileFormat.CSV`

## v0.1.1 - 2026-04-27

- Fixed schema migration helper's `_validate_history_table` by using `DATE_FORMAT`
  instead of `TO_CHAR`. Because live mode was paused, this doesn't have an effect
  on usability today.

## v0.1.0 - 2026-04-24

- Model: Removed workaround for `_`-prefixed column names.
  The package now requires CrateDB 6.2 or higher.
- Testing: Updated to `sdk-tester:2.26.0127.001` (Jan 28, 2026)
- Testing: Updated to `sdk-tester:2.26.0420.001` (Apr 21, 2026)
- Model: Added refinements from recent commits to Fivetran
  Partner SDK up until commit 3037ce4 (Apr 21, 2026).
- Testing: Skipped live mode integration test, the feature has
  been put [on hold][live mode pause] by Fivetran.
- Added documentation from Fivetran blueprints
- Dependencies: Updated to grpcio==1.80.*

[live mode pause]: https://github.com/crate/cratedb-fivetran-destination/issues/148

## v0.0.4 - 2026-01-23

### Features
- Implemented `AlterTableRecreateStatements` for recreating a table
  with a new schema, used for processing primary key column changes
- Added support for `AlterTable::drop_columns` operation
- Compatibility: Field `_fivetran_deleted` became optional
- Added support for schema migrations
- Added support for history and live mode
- Added support for Fivetran's `TIME_NAIVE` data type
- Made temp table creation resilient to failed runs of `AlterTable`

### Infrastructure
- Dependencies: Updated requirements across the board
- Testing: Updated to `sdk-tester:2.26.0113.001`
- Runtime: Updated Fivetran SDK to commit `76b1422`
- Build: Trimmed `requirements.txt`, dependencies are defined in `pyproject.toml`
- Build: Added `main.py` application entrypoint and `build.sh` files

## v0.0.3 - 2025-05-23
- Dependencies: Updated to `sqlalchemy-cratedb==0.42.0.dev2`
- Build: Added target to generate `requirements.txt`, and added the generated file
- CI: Stopped building OCI images and standalone artifacts

## v0.0.2 - 2025-05-01
- CLI: Added `--host` option to define on which host to listen on.
  Default: [::]
- Packaging: Improved bootstrapping by supporting directory-based invocation
  per `python src/cratedb_fivetran_destination` and PyInstaller builds per
  `poe build-app`
- Release: Started providing standalone executables on the [releases] page.

## v0.0.1 - 2025-03-31
- Added implementation for `DescribeTable` gRPC method
- Added implementation for `AlterTable` gRPC method
- Type mapping: Mapped `Fivetran.SHORT` to `SQLAlchemy.SmallInteger`
- Type mapping: Mapped `SQLAlchemy.DateTime` to `Fivetran.UTC_DATETIME`
- UI: Removed unneeded form fields. Added unit test.
- CLI: Provided command-line interface for `--port` and `--max-workers` options
- OCI: Provided container image `ghcr.io/crate/cratedb-fivetran-destination`
- Packaging: Removed SDK from repository, build at build-time instead

## v0.0.0 - 2025-02-17
- Added project skeleton
- Added generated SDK gRPC API stubs
- Added example destination blueprint
- Added software integration tests
- DML: Added SQLAlchemy backend implementation for upsert, update, delete
- Connect: Added `url` form field, accepting an SQLAlchemy database connection URL
- Connect: Implemented adapter's `Test` method
- Transform: Fivetran uses special values for designating `NULL` and
  CDC-unmodified values.
- Types: Added support for all Fivetran data types

[releases]: https://github.com/crate/cratedb-fivetran-destination/releases
