"""Single source of truth for the package version."""
from __future__ import annotations

__version__ = "0.1.0a1"

__all__ = ["__version__"]
