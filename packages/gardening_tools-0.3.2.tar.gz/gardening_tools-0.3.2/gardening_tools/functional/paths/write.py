import os
import nibabel as nib
import numpy as np
import pickle
import json
from PIL import Image
from gardening_tools.functional.nibabel_utils import reorient_nib_image
from gardening_tools.functional.paths.scan import subfiles


def save_json(obj, p):
    with open(p, "w") as f:
        json.dump(obj, f, indent=2)


def save_pickle(obj, file: str, mode: str = "wb") -> None:
    with open(file, mode) as f:
        pickle.dump(obj, f)


def save_nifti_from_numpy(pred, outpath, properties, compression=9):
    # slight hacky, but it is what it is
    nib.openers.Opener.default_compresslevel = compression
    pred = nib.Nifti1Image(
        pred,
        properties["nifti_metadata"]["affine"],
        header=None,
        dtype=np.uint8,
    )
    if properties["nifti_metadata"]["reoriented"]:
        pred = reorient_nib_image(
            pred,
            properties["nifti_metadata"]["final_direction"],
            properties["nifti_metadata"]["original_orientation"],
        )
    nib.save(
        pred,
        outpath + ".nii.gz",
    )
    del pred


def save_png_from_numpy(pred, outpath):
    pred = Image.fromarray(pred.astype(np.uint8))
    pred.save(outpath + ".png")
    del pred


def save_txt_from_numpy(pred, outpath):
    np.savetxt(outpath + ".txt", np.atleast_1d(pred), fmt="%i", delimiter=",")
    del pred


def save_prediction_from_logits(
    logits, outpath, properties, save_format: str = "nii.gz", compression=9
):
    """
    Expects input of shape (b,c,x,y,z) or (b,c,x,y)
    """
    if logits.shape[1] > 1:
        logits = np.argmax(logits, 1)
    pred = np.squeeze(logits)
    if "png" in save_format:
        save_png_from_numpy(pred, outpath)
    elif "txt" in save_format:
        save_txt_from_numpy(pred, outpath)
    elif "nii.gz" in save_format:
        save_nifti_from_numpy(pred, outpath, properties, compression=compression)
    else:
        raise ValueError(
            f"Unsupported save format: {save_format}. Supported formats are png, txt, nii.gz."
        )


def save_multilabel_prediction_from_logits(logits, outpath, properties, compression=9):
    nib.openers.Opener.default_compresslevel = compression
    # here we use a sigmoid instead of the softmax/argmax functions to keep the multiple channels
    # of predicted classes. This means predictions from this are stored as (c, h, w, d) rather than (h, w, d)
    pred = 1.0 / (1.0 + np.exp(-logits))
    pred = (pred > 0.5).astype(np.uint8)
    pred = np.squeeze(pred)
    preds = []
    for i in range(pred.shape[0]):
        pred_for_label = nib.Nifti1Image(
            pred[i],
            properties["nifti_metadata"]["affine"],
            header=nib.Nifti1Header(properties["nifti_metadata"]["header"]),
            dtype=np.uint8,
        )
        if properties["nifti_metadata"]["reoriented"]:
            pred_for_label = reorient_nib_image(
                pred_for_label,
                properties["nifti_metadata"]["final_direction"],
                properties["nifti_metadata"]["original_orientation"],
            )
        preds.append(pred_for_label)
    pred = nib.concat_images(preds)
    nib.save(
        pred,
        outpath + ".nii.gz",
    )
    del pred


def merge_softmax_from_folders(folders: list, outpath, method="sum"):
    os.makedirs(outpath, exists_ok=True)
    cases = subfiles(folders[0], suffix=".npz", join=False)
    for folder in folders:
        assert cases == subfiles(folder, suffix=".npz", join=False), (
            f"Found unexpected cases. "
            f"The following two folders do not contain the same cases: \n"
            f"{folders[0]} \n"
            f"{folder}"
        )

    for case in cases:
        files_for_case = [
            np.load(os.path.join(folder, case), allow_pickle=True) for folder in folders
        ]
        properties_for_case = files_for_case[0]["properties"]
        files_for_case = [file["data"].astype(np.float32) for file in files_for_case]

        if method == "sum":
            files_for_case = np.sum(files_for_case, axis=0)

        files_for_case = np.argmax(files_for_case, 0)
        save_nifti_from_numpy(
            files_for_case,
            os.path.join(outpath, case[:-4]),
            properties=properties_for_case.item(),
        )

    del files_for_case, properties_for_case
