from setuptools import setup

def readme():
    with open('README.rst', encoding='utf-8') as f:
        return f.read()

setup(name='liujianlib',
      version='1.0.0',
      packages=['liujianlib'],
      py_modules=['t1'],
      description='liujianlib',
      long_description=readme(),
      license='MIT',
      author='liujian520', author_email='1009626711@qq.com')