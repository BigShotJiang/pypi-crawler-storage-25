"""FastAPI 1-line server demo.

Run::

    uv run uvicorn examples.server_demo:app --port 3402
    curl -i localhost:3402/api/translate
"""

from fastapi import Depends, FastAPI, Response

from clawpay_x402.server import x402_dependency

app = FastAPI()

pay = x402_dependency(
    accepts=[
        {
            "scheme": "clawpay-cny",
            "network": "clawpay-mainnet",
            "maxAmountRequired": "150",
            "asset": "CNY",
            "payTo": "agent:31981",
            "extra": {
                "facilitator": "https://erc8004.cn/api/x402/facilitator",
                "humanPrice": "¥1.50",
            },
        },
    ],
    metadata={"agent": {"name": "demo-agent"}},
    verify=lambda payload: True,  # mock; replace with real WeChat/Alipay check
)


@app.get("/api/translate")
async def translate(ctx: dict = Depends(pay)) -> Response:
    body = {
        "output": "Hello, world",
        "paidWith": ctx["payload"]["scheme"],
    }
    import json

    return Response(
        content=json.dumps(body),
        media_type="application/json",
        headers={"X-PAYMENT-RESPONSE": ctx["receipt_header"]},
    )
