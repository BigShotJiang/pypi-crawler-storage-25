"""3-line client demo. Run with:  uv run python examples/client_demo.py"""

import asyncio

from clawpay_x402 import x402_pay


async def main() -> None:
    r = await x402_pay("https://erc8004.cn/api/x402/demo", from_="clawpay:demo-cli")
    print("status :", r.status, " paid:", r.paid, " scheme:", (r.payment_requirements or {}).get("scheme"))
    print("body   :", r.body)
    print("receipt:", r.receipt)


if __name__ == "__main__":
    asyncio.run(main())
