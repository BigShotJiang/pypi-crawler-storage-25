"""ClawPay × x402 client SDK.

The 3-line surface::

    from clawpay_x402 import x402_pay
    r = await x402_pay("https://erc8004.cn/api/x402/demo", from_="clawpay:me")
    print(r.body, r.receipt)
"""

from __future__ import annotations

import base64
import json
import time
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Iterable

import httpx

from .types import (
    CLAWPAY_SCHEMES,
    X402_VERSION,
    PaymentPayload,
    PaymentRequirements,
    Receipt,
    Server402Body,
)

DEFAULT_PREFER: tuple[str, ...] = (
    "clawpay-cny",
    "clawpay-dcep",
    "clawpay-cross",
    "exact",
)


# ──────────────────────────────────────────────────────────────────────────


@dataclass(slots=True)
class X402Result:
    """What `x402_pay` returns."""

    status: int
    body: Any
    paid: bool
    payment_requirements: PaymentRequirements | None
    receipt: Receipt | None
    response: httpx.Response

    @property
    def ok(self) -> bool:
        return 200 <= self.status < 300


# ──────────────────────────────────────────────────────────────────────────


def select_scheme(
    body: Server402Body | dict[str, Any] | None,
    prefer: Iterable[str] = DEFAULT_PREFER,
) -> PaymentRequirements | None:
    """Pick the best PaymentRequirements entry from a 402 body."""
    if not isinstance(body, dict):
        return None
    accepts = body.get("accepts") or []
    if not isinstance(accepts, list):
        return None
    for wanted in prefer:
        for entry in accepts:
            if isinstance(entry, dict) and entry.get("scheme") == wanted:
                return entry  # type: ignore[return-value]
    return None


def encode_payment(payload: dict[str, Any]) -> str:
    """base64-encode a PaymentPayload object as the X-PAYMENT header value."""
    return base64.b64encode(json.dumps(payload, separators=(",", ":")).encode("utf-8")).decode("ascii")


def decode_receipt(header_value: str | None) -> Receipt | None:
    """Decode an X-PAYMENT-RESPONSE receipt header. Returns None on failure."""
    if not header_value:
        return None
    try:
        return json.loads(base64.b64decode(header_value, validate=True).decode("utf-8"))  # type: ignore[no-any-return]
    except Exception:
        return None


def build_payload(
    req: PaymentRequirements,
    from_: str,
    *,
    transaction_id: str | None = None,
    rail: str | None = None,
    signature: str | None = None,
    signed_at: str | None = None,
) -> PaymentPayload:
    """Construct a PaymentPayload for a clawpay-* scheme.

    Throws on `exact` (use a real on-chain SDK for that).
    """
    scheme = req.get("scheme", "")
    if scheme not in CLAWPAY_SCHEMES:
        raise ValueError(
            f"build_payload only supports clawpay-* schemes (got {scheme!r}). "
            "Use Coinbase's x402 SDK for the 'exact' scheme."
        )
    if not from_:
        raise ValueError("build_payload requires from_")

    txn = transaction_id or _mock_txn_id(rail or scheme)
    inner: dict[str, Any] = {
        "from": from_,
        "to": req.get("payTo", ""),
        "amount": req.get("maxAmountRequired", "0"),
        "transactionId": txn,
        "signedAt": signed_at or _now_iso(),
    }
    if rail:
        inner["rail"] = rail
    if signature:
        inner["signature"] = signature
    return {
        "x402Version": X402_VERSION,
        "scheme": scheme,
        "network": req.get("network", ""),
        "payload": inner,
    }


# ──────────────────────────────────────────────────────────────────────────


async def x402_pay(
    url: str,
    *,
    from_: str,
    prefer: Iterable[str] = DEFAULT_PREFER,
    on_build_payload: Callable[[PaymentRequirements], Awaitable[dict[str, Any]] | dict[str, Any]] | None = None,
    client: httpx.AsyncClient | None = None,
    timeout: float = 30.0,
    method: str = "GET",
    request_kwargs: dict[str, Any] | None = None,
) -> X402Result:
    """Fetch an x402-protected resource. Auto-handles 402 → retry with X-PAYMENT.

    Parameters
    ----------
    url : the resource URL
    from_ : payer identifier ("clawpay:<uid>" / "agent:<id>" / "0x...")
    prefer : scheme preference order (default: clawpay-* first, exact last)
    on_build_payload : async callable that, given a PaymentRequirements, returns
        extra fields to merge into PaymentPayload.payload — typically a real
        `transactionId` from your WeChat / Alipay / DCEP processor
    client : optional reusable httpx.AsyncClient
    timeout : per-request timeout
    method : HTTP method (default GET)
    request_kwargs : extra kwargs forwarded to httpx.request
    """
    own_client = client is None
    cli = client or httpx.AsyncClient(timeout=timeout)
    extra_kw = request_kwargs or {}
    try:
        r1 = await cli.request(method, url, **extra_kw)
        if r1.status_code != 402:
            return X402Result(
                status=r1.status_code,
                body=_safe_json(r1),
                paid=False,
                payment_requirements=None,
                receipt=None,
                response=r1,
            )

        body402 = _safe_json(r1)
        req = select_scheme(body402, prefer)
        if req is None:
            offered = []
            if isinstance(body402, dict):
                offered = [a.get("scheme") for a in body402.get("accepts", []) if isinstance(a, dict)]
            raise RuntimeError(
                f"server returned 402 but no scheme matched preferences {list(prefer)}. "
                f"Server offered: {offered}"
            )
        if req.get("scheme") == "exact":
            raise RuntimeError(
                "selected scheme is 'exact' (on-chain USDC). This SDK does not handle "
                "on-chain signing — use Coinbase's x402 SDK or filter exact out via prefer."
            )

        extras: dict[str, Any] = {}
        if on_build_payload is not None:
            res = on_build_payload(req)
            if hasattr(res, "__await__"):
                res = await res  # type: ignore[assignment]
            extras = res or {}

        payload = build_payload(
            req,
            from_=from_,
            transaction_id=extras.get("transactionId") or extras.get("transaction_id"),
            rail=extras.get("rail"),
            signature=extras.get("signature"),
            signed_at=extras.get("signedAt") or extras.get("signed_at"),
        )
        hdr = encode_payment(payload)

        headers = dict(extra_kw.get("headers") or {})
        headers["X-PAYMENT"] = hdr
        kw2 = {**extra_kw, "headers": headers}
        r2 = await cli.request(method, url, **kw2)
        return X402Result(
            status=r2.status_code,
            body=_safe_json(r2),
            paid=200 <= r2.status_code < 300,
            payment_requirements=req,
            receipt=decode_receipt(r2.headers.get("x-payment-response")),
            response=r2,
        )
    finally:
        if own_client:
            await cli.aclose()


# ──────────────────────────────────────────────────────────────────────────


def _now_iso() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _mock_txn_id(prefix: str) -> str:
    return f"{prefix[:8]}-mock-{int(time.time() * 1000)}"


def _safe_json(r: httpx.Response) -> Any:
    try:
        return r.json()
    except Exception:
        return r.text
