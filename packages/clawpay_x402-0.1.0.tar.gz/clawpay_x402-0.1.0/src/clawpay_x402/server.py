"""ClawPay × x402 server SDK — framework-agnostic + optional FastAPI dependency.

Building blocks (no framework needed)::

    from clawpay_x402 import build_402_body, decode_payment, verify_shape, encode_receipt

FastAPI 1-line surface (requires `pip install clawpay-x402[fastapi]`)::

    from fastapi import FastAPI, Depends
    from clawpay_x402.server import x402_dependency

    app = FastAPI()
    pay = x402_dependency(
        accepts=[
            {"scheme": "clawpay-cny", "network": "clawpay-mainnet",
             "maxAmountRequired": "150", "asset": "CNY", "payTo": "agent:31981"},
        ],
        verify=lambda payload: True,  # mock; replace with real
    )

    @app.get("/api/translate")
    async def translate(ctx = Depends(pay)):
        return {"output": "Hello, world", "paidWith": ctx["payload"]["scheme"]}
"""

from __future__ import annotations

import base64
import json
import time
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Iterable

from .types import PaymentPayload, PaymentRequirements, Receipt, Server402Body, X402_VERSION


def build_402_body(
    accepts: Iterable[PaymentRequirements],
    *,
    error: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> Server402Body:
    return {
        "x402Version": X402_VERSION,
        "accepts": list(accepts),
        "error": error,
        "metadata": metadata or {},
    }


def decode_payment(header_value: str | None) -> dict[str, Any] | None:
    """Decode an X-PAYMENT base64 header. Returns None on garbage."""
    if not header_value or not isinstance(header_value, str):
        return None
    try:
        decoded = base64.b64decode(header_value, validate=True)
        obj = json.loads(decoded.decode("utf-8"))
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None


def encode_receipt(receipt: Receipt | dict[str, Any]) -> str:
    return base64.b64encode(json.dumps(dict(receipt), separators=(",", ":")).encode("utf-8")).decode("ascii")


def verify_shape(
    payload: dict[str, Any] | None,
    accepts: Iterable[PaymentRequirements],
    *,
    freshness_seconds: int = 5 * 60,
) -> dict[str, Any]:
    """Stateless shape + freshness validation.

    Returns ``{"ok": True, "paymentRequirements": <matched>}`` or
    ``{"ok": False, "reason": "<msg>"}``.
    """
    if not isinstance(payload, dict):
        return {"ok": False, "reason": "payload not an object"}
    if payload.get("x402Version") != X402_VERSION:
        return {"ok": False, "reason": f"x402Version {payload.get('x402Version')} != {X402_VERSION}"}
    accepts_list = list(accepts)
    matched = next(
        (
            a
            for a in accepts_list
            if a.get("scheme") == payload.get("scheme") and a.get("network") == payload.get("network")
        ),
        None,
    )
    if matched is None:
        return {
            "ok": False,
            "reason": f"scheme {payload.get('scheme')!r} on network {payload.get('network')!r} not in server's accepts[]",
        }
    inner = payload.get("payload")
    if not isinstance(inner, dict):
        return {"ok": False, "reason": "missing 'payload' object"}
    txn = inner.get("transactionId")
    if not txn or not isinstance(txn, str):
        return {"ok": False, "reason": "missing 'payload.transactionId'"}
    amount = inner.get("amount")
    if not isinstance(amount, str) or not amount.isdigit():
        return {"ok": False, "reason": "'payload.amount' must be integer string in scheme unit"}
    if int(amount) < int(matched.get("maxAmountRequired", "0")):
        return {
            "ok": False,
            "reason": f"payload.amount ({amount}) < maxAmountRequired ({matched.get('maxAmountRequired')})",
        }
    signed_at = inner.get("signedAt")
    if signed_at:
        try:
            ts = datetime.fromisoformat(signed_at.replace("Z", "+00:00")).timestamp()
        except Exception:
            return {"ok": False, "reason": "payload.signedAt not parseable as ISO 8601"}
        skew = abs(time.time() - ts)
        if skew > freshness_seconds:
            return {"ok": False, "reason": f"payload.signedAt outside {freshness_seconds // 60}-minute window"}
    return {"ok": True, "paymentRequirements": matched}


def base_receipt(payload: PaymentPayload, payment_requirements: PaymentRequirements) -> Receipt:
    inner = payload.get("payload", {})
    return {
        "scheme": payload.get("scheme", ""),
        "network": payload.get("network", ""),
        "settled": True,
        "payer": inner.get("from", ""),
        "payTo": payment_requirements.get("payTo", ""),
        "amountCharged": inner.get("amount", ""),
        "settledAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


# ──────────────────────────────────────────────────────────────────────────
# Optional FastAPI dependency
# ──────────────────────────────────────────────────────────────────────────


def x402_dependency(
    accepts: Iterable[PaymentRequirements],
    *,
    verify: Callable[[dict[str, Any]], bool | dict[str, Any] | Awaitable[bool | dict[str, Any]]] | None = None,
    build_receipt: Callable[[dict[str, Any], PaymentRequirements], dict[str, Any] | Awaitable[dict[str, Any]]] | None = None,
    metadata: dict[str, Any] | None = None,
) -> Callable[..., Awaitable[dict[str, Any]]]:
    """Build a FastAPI dependency that enforces x402 payment.

    Use as ``Depends(x402_dependency(...))``. The handler receives
    ``{"payload": <PaymentPayload>, "paymentRequirements": <matched entry>}``.
    """
    try:
        from fastapi import HTTPException, Request
    except ImportError as e:
        raise ImportError(
            "clawpay-x402[fastapi] extra not installed. `pip install 'clawpay-x402[fastapi]'`"
        ) from e

    accepts_list = list(accepts)

    async def _dep(request):  # annotation patched below so FastAPI sees the real Request type

        hdr = request.headers.get("x-payment")
        if not hdr:
            raise HTTPException(
                status_code=402,
                detail=build_402_body(accepts_list, metadata=metadata),
                headers={"X-Powered-By": "ClawPay/0.1 (x402-compatible)"},
            )
        payload = decode_payment(hdr)
        if payload is None:
            raise HTTPException(
                status_code=402,
                detail=build_402_body(accepts_list, error="X-PAYMENT not valid base64 JSON", metadata=metadata),
            )
        shape = verify_shape(payload, accepts_list)
        if not shape["ok"]:
            raise HTTPException(
                status_code=402,
                detail=build_402_body(accepts_list, error=shape["reason"], metadata=metadata),
            )
        if verify is not None:
            v = verify(payload)
            if hasattr(v, "__await__"):
                v = await v  # type: ignore[assignment]
            ok = v if isinstance(v, bool) else bool(v.get("ok") if isinstance(v, dict) else False)
            reason = v.get("reason") if isinstance(v, dict) else None
            if not ok:
                raise HTTPException(
                    status_code=402,
                    detail=build_402_body(accepts_list, error=reason or "verify hook returned false", metadata=metadata),
                )
        # build receipt and stash on request so the route can set response headers
        receipt = base_receipt(payload, shape["paymentRequirements"])
        if build_receipt is not None:
            extra = build_receipt(payload, shape["paymentRequirements"])
            if hasattr(extra, "__await__"):
                extra = await extra  # type: ignore[assignment]
            receipt = {**receipt, **(extra or {})}
        receipt_hdr = encode_receipt(receipt)
        request.state.x402_receipt_header = receipt_hdr  # route can read this
        return {
            "payload": payload,
            "paymentRequirements": shape["paymentRequirements"],
            "receipt": receipt,
            "receipt_header": receipt_hdr,
        }

    # FastAPI inspects this annotation to know to inject the live Request.
    # We must set it concretely (not via `from __future__ import annotations`).
    _dep.__annotations__ = {"request": Request, "return": dict}
    return _dep
