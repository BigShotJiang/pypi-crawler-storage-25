"""ClawPay × x402 SDK.

Spec: https://erc8004.cn/specs/clawpay-x402/
"""

from .types import (
    CLAWPAY_SCHEMES,
    SUPPORTED_SCHEMES,
    X402_VERSION,
    PaymentPayload,
    PaymentRequirements,
    Receipt,
)
from .client import (
    build_payload,
    decode_receipt,
    encode_payment,
    select_scheme,
    x402_pay,
)
from .server import (
    build_402_body,
    decode_payment,
    encode_receipt,
    verify_shape,
)

__all__ = [
    "CLAWPAY_SCHEMES",
    "SUPPORTED_SCHEMES",
    "X402_VERSION",
    "PaymentPayload",
    "PaymentRequirements",
    "Receipt",
    "build_payload",
    "decode_receipt",
    "encode_payment",
    "select_scheme",
    "x402_pay",
    "build_402_body",
    "decode_payment",
    "encode_receipt",
    "verify_shape",
]
__version__ = "0.1.0"
