"""Type definitions — kept as plain TypedDict so we don't force a pydantic dep."""

from __future__ import annotations

from typing import Any, Literal, TypedDict

X402_VERSION: int = 1

Scheme = Literal[
    "clawpay-cny", "clawpay-dcep", "clawpay-cross", "exact"
]

# Schemes this SDK can construct PaymentPayloads for without external chain infra.
CLAWPAY_SCHEMES: tuple[str, ...] = ("clawpay-cny", "clawpay-dcep", "clawpay-cross")

SUPPORTED_SCHEMES: tuple[str, ...] = (*CLAWPAY_SCHEMES, "exact")


class PaymentRequirements(TypedDict, total=False):
    scheme: str
    network: str
    maxAmountRequired: str  # integer string in scheme unit (CNY: cents)
    asset: str
    assetDecimals: int
    payTo: str
    resource: str
    description: str
    mimeType: str
    extra: dict[str, Any]


class PaymentPayloadInner(TypedDict, total=False):
    from_: str  # alias; real key is "from" — handled in client.py
    to: str
    amount: str
    transactionId: str
    rail: str
    signedAt: str
    signature: str


class PaymentPayload(TypedDict, total=False):
    x402Version: int
    scheme: str
    network: str
    payload: dict[str, Any]


class Server402Body(TypedDict, total=False):
    x402Version: int
    accepts: list[PaymentRequirements]
    error: str | None
    metadata: dict[str, Any]


class Receipt(TypedDict, total=False):
    scheme: str
    network: str
    settled: bool
    demoMode: bool
    txRef: str
    settledAt: str
    payer: str
    payTo: str
    amountCharged: str
    facilitator: str
