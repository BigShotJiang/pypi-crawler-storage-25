"""Live test against the real erc8004.cn demo. Skipped unless LIVE=1."""

import os

import pytest

from clawpay_x402 import x402_pay

LIVE = os.environ.get("LIVE") == "1"
URL = os.environ.get("LIVE_URL", "https://erc8004.cn/api/x402/demo")


@pytest.mark.skipif(not LIVE, reason="set LIVE=1 to run")
async def test_live_round_trip():
    r = await x402_pay(URL, from_="clawpay:py-sdk-live")
    assert r.status == 200, f"expected 200 got {r.status}: {r.body!r}"
    assert r.paid is True
    assert r.payment_requirements["scheme"] == "clawpay-cny"
    assert r.body["ok"] is True
    assert r.body["paidWith"] == "clawpay-cny"
    assert r.body["agent"]["agentId"] == 31981
    assert r.receipt is not None
    assert r.receipt["settled"] is True
    assert r.receipt.get("demoMode") is True


@pytest.mark.skipif(not LIVE, reason="set LIVE=1 to run")
async def test_live_prefer_dcep():
    r = await x402_pay(URL, from_="clawpay:py-sdk-live", prefer=("clawpay-dcep", "clawpay-cny"))
    assert r.status == 200
    assert r.payment_requirements["scheme"] == "clawpay-dcep"
    assert r.body["paidWith"] == "clawpay-dcep"
