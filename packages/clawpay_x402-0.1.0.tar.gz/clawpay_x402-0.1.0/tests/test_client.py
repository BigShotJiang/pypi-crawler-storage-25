from __future__ import annotations

import base64
import json

import httpx
import pytest
import respx

from clawpay_x402 import (
    build_payload,
    decode_receipt,
    encode_payment,
    select_scheme,
    x402_pay,
)

REQ_CNY = {
    "scheme": "clawpay-cny", "network": "clawpay-mainnet",
    "maxAmountRequired": "150", "asset": "CNY", "payTo": "agent:31981",
}
REQ_DCEP = {**REQ_CNY, "scheme": "clawpay-dcep", "network": "ecny-mainnet", "asset": "e-CNY"}
REQ_USDC = {
    "scheme": "exact", "network": "base",
    "maxAmountRequired": "210000", "asset": "0x...", "payTo": "0xb95...",
}


def test_select_scheme_picks_first_preference():
    body = {"x402Version": 1, "accepts": [REQ_USDC, REQ_CNY]}
    assert select_scheme(body)["scheme"] == "clawpay-cny"
    assert select_scheme(body, prefer=("exact",))["scheme"] == "exact"
    assert select_scheme(body, prefer=("clawpay-dcep",)) is None


def test_select_scheme_handles_garbage():
    assert select_scheme(None) is None
    assert select_scheme({}) is None
    assert select_scheme({"x402Version": 1, "accepts": []}) is None


def test_build_payload_clawpay_cny():
    p = build_payload(REQ_CNY, from_="clawpay:test")
    assert p["x402Version"] == 1
    assert p["scheme"] == "clawpay-cny"
    assert p["network"] == "clawpay-mainnet"
    assert p["payload"]["from"] == "clawpay:test"
    assert p["payload"]["to"] == "agent:31981"
    assert p["payload"]["amount"] == "150"
    assert "transactionId" in p["payload"]
    assert "mock" in p["payload"]["transactionId"]
    assert p["payload"]["signedAt"].endswith("Z")


def test_build_payload_user_supplied_txn_id():
    p = build_payload(REQ_CNY, from_="clawpay:x", transaction_id="wx-001", rail="wechat")
    assert p["payload"]["transactionId"] == "wx-001"
    assert p["payload"]["rail"] == "wechat"


def test_build_payload_rejects_exact():
    with pytest.raises(ValueError, match="only supports clawpay-"):
        build_payload(REQ_USDC, from_="0xabc")


def test_build_payload_rejects_empty_from():
    with pytest.raises(ValueError, match="requires from_"):
        build_payload(REQ_CNY, from_="")


def test_encode_payment_decode_receipt_roundtrip():
    obj = {"hello": "世界", "n": 42}
    hdr = encode_payment(obj)
    assert json.loads(base64.b64decode(hdr).decode()) == obj
    assert decode_receipt(hdr) == obj
    assert decode_receipt("") is None
    assert decode_receipt("not-b64*") is None


@respx.mock
async def test_x402_pay_200_path():
    respx.get("http://x.test/").mock(return_value=httpx.Response(200, json={"ok": True, "data": 1}))
    r = await x402_pay("http://x.test/", from_="clawpay:t")
    assert r.status == 200
    assert r.paid is False
    assert r.body == {"ok": True, "data": 1}
    assert r.payment_requirements is None


@respx.mock
async def test_x402_pay_402_then_200_with_receipt():
    seen_headers: list[dict] = []

    def cb(request: httpx.Request) -> httpx.Response:
        seen_headers.append(dict(request.headers))
        if "x-payment" not in request.headers:
            return httpx.Response(402, json={"x402Version": 1, "accepts": [REQ_DCEP, REQ_CNY]})
        receipt_b64 = encode_payment({"scheme": "clawpay-cny", "settled": True})
        return httpx.Response(200, json={"ok": True, "output": "Hello, world"}, headers={"X-PAYMENT-RESPONSE": receipt_b64})

    respx.get("http://x.test/").mock(side_effect=cb)
    r = await x402_pay("http://x.test/", from_="clawpay:test")
    assert len(seen_headers) == 2
    assert "x-payment" not in seen_headers[0]
    assert "x-payment" in seen_headers[1]
    assert r.status == 200
    assert r.paid is True
    assert r.payment_requirements["scheme"] == "clawpay-cny"
    assert r.receipt["scheme"] == "clawpay-cny"


@respx.mock
async def test_x402_pay_402_only_exact_raises():
    respx.get("http://x.test/").mock(return_value=httpx.Response(402, json={"x402Version": 1, "accepts": [REQ_USDC]}))
    with pytest.raises(RuntimeError, match="no scheme matched preferences"):
        await x402_pay("http://x.test/", from_="clawpay:t", prefer=("clawpay-cny", "clawpay-dcep"))


@respx.mock
async def test_x402_pay_on_build_payload_hook_injects_real_txn():
    captured = {}

    def cb(request: httpx.Request) -> httpx.Response:
        if "x-payment" not in request.headers:
            return httpx.Response(402, json={"x402Version": 1, "accepts": [REQ_CNY]})
        decoded = json.loads(base64.b64decode(request.headers["x-payment"]).decode())
        captured.update(decoded["payload"])
        return httpx.Response(200, json={"ok": True})

    respx.get("http://x.test/").mock(side_effect=cb)

    async def hook(req):
        return {"transactionId": "wx-real-999", "rail": "wechat"}

    r = await x402_pay("http://x.test/", from_="clawpay:hook", on_build_payload=hook)
    assert r.paid is True
    assert captured["transactionId"] == "wx-real-999"
    assert captured["rail"] == "wechat"


@respx.mock
async def test_x402_pay_sync_on_build_payload():
    """Hook can be sync (returns dict directly)."""
    def cb(request: httpx.Request) -> httpx.Response:
        if "x-payment" not in request.headers:
            return httpx.Response(402, json={"x402Version": 1, "accepts": [REQ_CNY]})
        return httpx.Response(200, json={"ok": True})

    respx.get("http://x.test/").mock(side_effect=cb)
    r = await x402_pay("http://x.test/", from_="clawpay:t", on_build_payload=lambda req: {"transactionId": "sync-1"})
    assert r.paid is True
