from __future__ import annotations

import time
from datetime import datetime, timezone

import pytest

from clawpay_x402 import (
    build_402_body,
    decode_payment,
    encode_payment,
    encode_receipt,
    verify_shape,
)

ACCEPTS = [
    {"scheme": "clawpay-cny", "network": "clawpay-mainnet",
     "maxAmountRequired": "150", "asset": "CNY", "payTo": "agent:31981"},
    {"scheme": "clawpay-dcep", "network": "ecny-mainnet",
     "maxAmountRequired": "150", "asset": "e-CNY", "payTo": "ecny:1234567890"},
]


def good_payload(**override) -> dict:
    inner_override = override.pop("payload", {})
    base = {
        "x402Version": 1,
        "scheme": "clawpay-cny",
        "network": "clawpay-mainnet",
        "payload": {
            "from": "clawpay:test",
            "to": "agent:31981",
            "amount": "150",
            "transactionId": "wx-ok-1",
            "rail": "wechat",
            "signedAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        },
    }
    base.update(override)
    base["payload"] = {**base["payload"], **inner_override}
    return base


def test_build_402_body():
    b = build_402_body(ACCEPTS)
    assert b["x402Version"] == 1
    assert len(b["accepts"]) == 2
    assert b["error"] is None


def test_decode_payment_round_trip():
    obj = {"x402Version": 1, "scheme": "clawpay-cny"}
    assert decode_payment(encode_payment(obj)) == obj
    assert decode_payment("") is None
    assert decode_payment("bad@@@") is None
    assert decode_payment(None) is None  # type: ignore[arg-type]


def test_verify_shape_happy():
    r = verify_shape(good_payload(), ACCEPTS)
    assert r["ok"] is True
    assert r["paymentRequirements"]["scheme"] == "clawpay-cny"


def test_verify_shape_wrong_version():
    r = verify_shape(good_payload(x402Version=2), ACCEPTS)
    assert r["ok"] is False
    assert "x402Version 2" in r["reason"]


def test_verify_shape_unknown_scheme():
    r = verify_shape(good_payload(scheme="fake"), ACCEPTS)
    assert r["ok"] is False
    assert "scheme 'fake'" in r["reason"]


def test_verify_shape_under_amount():
    r = verify_shape(good_payload(payload={"amount": "100"}), ACCEPTS)
    assert r["ok"] is False
    assert "< maxAmountRequired" in r["reason"]


def test_verify_shape_missing_txn():
    p = good_payload()
    del p["payload"]["transactionId"]
    assert verify_shape(p, ACCEPTS)["ok"] is False


def test_verify_shape_stale_signed_at():
    stale = datetime.fromtimestamp(time.time() - 600, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    r = verify_shape(good_payload(payload={"signedAt": stale}), ACCEPTS)
    assert r["ok"] is False
    assert "signedAt outside" in r["reason"]


def test_verify_shape_bad_amount_format():
    r = verify_shape(good_payload(payload={"amount": "150.50"}), ACCEPTS)
    assert r["ok"] is False
    assert "must be integer string" in r["reason"]


def test_encode_receipt_idempotent():
    r1 = encode_receipt({"scheme": "clawpay-cny", "settled": True})
    r2 = encode_receipt({"scheme": "clawpay-cny", "settled": True})
    assert r1 == r2  # canonical separators


# ─── FastAPI dependency tests ───
fastapi = pytest.importorskip("fastapi")
from fastapi import Depends, FastAPI, Response  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from clawpay_x402.server import x402_dependency  # noqa: E402


def make_app(verify=None, build_receipt=None):
    app = FastAPI()
    pay = x402_dependency(ACCEPTS, verify=verify, build_receipt=build_receipt,
                          metadata={"agent": {"name": "test-agent"}})

    @app.get("/api/translate")
    async def t(ctx: dict = Depends(pay)):
        return Response(
            content='{"output":"Hello, world","paidWith":"' + ctx["payload"]["scheme"] + '"}',
            media_type="application/json",
            headers={"X-PAYMENT-RESPONSE": ctx["receipt_header"]},
        )
    return app


def test_fastapi_no_header_returns_402():
    c = TestClient(make_app())
    r = c.get("/api/translate")
    assert r.status_code == 402
    detail = r.json()["detail"]
    assert detail["x402Version"] == 1
    assert len(detail["accepts"]) == 2
    assert detail["metadata"]["agent"]["name"] == "test-agent"


def test_fastapi_bad_header_returns_402_with_error():
    c = TestClient(make_app())
    r = c.get("/api/translate", headers={"X-PAYMENT": "garbage@@@"})
    assert r.status_code == 402
    assert "not valid base64" in r.json()["detail"]["error"]


def test_fastapi_happy_path():
    c = TestClient(make_app())
    r = c.get("/api/translate", headers={"X-PAYMENT": encode_payment(good_payload())})
    assert r.status_code == 200
    assert r.json() == {"output": "Hello, world", "paidWith": "clawpay-cny"}
    assert "X-PAYMENT-RESPONSE" in r.headers


def test_fastapi_verify_returns_false_dict():
    def deny(_):
        return {"ok": False, "reason": "wechat receipt not found"}
    c = TestClient(make_app(verify=deny))
    r = c.get("/api/translate", headers={"X-PAYMENT": encode_payment(good_payload())})
    assert r.status_code == 402
    assert "wechat receipt not found" in r.json()["detail"]["error"]


def test_fastapi_build_receipt_hook_merges_into_header():
    import base64, json
    def br(_payload, _req):
        return {"txRef": "ours-001", "facilitator": "https://x"}
    c = TestClient(make_app(build_receipt=br))
    r = c.get("/api/translate", headers={"X-PAYMENT": encode_payment(good_payload())})
    assert r.status_code == 200
    receipt = json.loads(base64.b64decode(r.headers["X-PAYMENT-RESPONSE"]).decode())
    assert receipt["txRef"] == "ours-001"
    assert receipt["facilitator"] == "https://x"
    assert receipt["scheme"] == "clawpay-cny"
