"""Matplotlib rendering pipeline for surface-cut meshes.

Provides :class:`RenderItem` for pairing meshes with scalar fields,
:class:`Bounds3D` for view-volume management, and the
:func:`plot_surfaces` entry point.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, Literal, Optional, Sequence, Tuple, Union

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.colors import Normalize
from matplotlib.colors import to_rgba
from mpl_toolkits.mplot3d.art3d import Line3DCollection, Poly3DCollection


Mode = Literal["cmap", "cont", "cmap+cont"]


@dataclass(frozen=True)
class RenderItem:
    """Rendering specification for a mesh surface.

    style:
      - 'field': color by sampled field values (colormap)
      - 'solid': constant face color (e.g., gray cut faces)
    """

    surface: object
    style: Literal["field", "solid"] = "field"
    solid_color: Union[str, Tuple[float, float, float], Tuple[float, float, float, float]] = "0.6"
    alpha: Optional[float] = None
    draw_contours: bool = True
    edge_color: Optional[str] = None
    edge_lw: float = 0.4


@dataclass(frozen=True)
class Bounds3D:
    """Axis-aligned 3-D bounding box."""

    x: Tuple[float, float]
    y: Tuple[float, float]
    z: Tuple[float, float]

    def expanded(self, frac: float = 0.05) -> "Bounds3D":
        """Return a new Bounds expanded by the given fraction.

        Parameters
        ----------
        frac : float, optional
            Fraction by which to expand each interval.
        Returns
        -------
        "Bounds3D"
            Expanded bounding box.
        """

        def ex(a, b):
            """Expand a 1-D interval by the given fraction.

            Parameters
            ----------
            a : object
                Lower bound of the interval.
            b : object
                Upper bound of the interval.
            Returns
            -------
            object
                Expanded interval endpoints.
            """
            w = b - a
            return (a - frac * w, b + frac * w)

        return Bounds3D(ex(*self.x), ex(*self.y), ex(*self.z))


def _as_list(surfaces) -> list[RenderItem]:
    """Normalize inputs into a list[RenderItem]."""
    if isinstance(surfaces, (list, tuple)):
        items = list(surfaces)
    else:
        items = [surfaces]

    out: list[RenderItem] = []
    for it in items:
        if isinstance(it, RenderItem):
            out.append(it)
        else:
            out.append(RenderItem(surface=it))
    return out


def _make_norm(vmin=None, vmax=None, *, robust_data: Optional[np.ndarray] = None) -> Normalize:
    """Create a colormap normalization object.

    Parameters
    ----------
    vmin : object, optional
        Minimum of the display range.
    vmax : object, optional
        Maximum of the display range.
    robust_data : Optional[np.ndarray], optional
        Reference data used for robust (outlier-resistant) range estimation.
    Returns
    -------
    Normalize
        Matplotlib color normalization object.
    """
    if vmin is None or vmax is None:
        if robust_data is None:
            vmin0, vmax0 = -1.0, 1.0
        else:
            d = np.asarray(robust_data, dtype=float)
            d = d[np.isfinite(d)]
            if d.size == 0:
                vmin0, vmax0 = -1.0, 1.0
            else:
                vmin0, vmax0 = np.percentile(d, [1, 99])
        vmin = vmin0 if vmin is None else vmin
        vmax = vmax0 if vmax is None else vmax
    return Normalize(vmin=vmin, vmax=vmax)


def _surface_mesh(surface) -> Tuple[np.ndarray, np.ndarray]:
    """Extract ``(V, F)`` arrays from a :class:`MeshSurface3D`.

    Accepts anything with a callable ``mesh()`` method that returns either a
    ``(V, F)`` pair directly or another mesh-like object whose own ``mesh()``
    yields the pair (e.g. a :class:`Boundary` from
    :mod:`emout.emout.boundaries`, whose ``mesh()`` returns a
    ``MeshSurface3D``). One level of unwrapping is enough because
    :class:`CompositeMeshSurface` already returns ``(V, F)`` directly.
    """
    mesh_fn = getattr(surface, "mesh", None)
    if not callable(mesh_fn):
        raise TypeError(f"Expected a MeshSurface3D-like object with a .mesh() method, got {type(surface).__name__}")
    result = mesh_fn()
    # Unwrap one level so Boundary objects (mesh() → MeshSurface3D) work too.
    inner = getattr(result, "mesh", None)
    if callable(inner):
        result = inner()
    V, F = result
    V = np.asarray(V, dtype=np.float64)
    F = np.asarray(F, dtype=np.int64)
    return V, F


def _bounds_from_mesh_surfaces(surfaces) -> Optional[Bounds3D]:
    """Infer plot bounds from explicit mesh surfaces."""
    mins: list[np.ndarray] = []
    maxs: list[np.ndarray] = []
    for item in _as_list(surfaces):
        try:
            V, _ = _surface_mesh(item.surface)
        except TypeError:
            return None
        if V.size == 0:
            continue
        mins.append(np.nanmin(V, axis=0))
        maxs.append(np.nanmax(V, axis=0))

    if not mins:
        return None

    xyz_min = np.min(np.vstack(mins), axis=0)
    xyz_max = np.max(np.vstack(maxs), axis=0)
    return Bounds3D(
        (float(xyz_min[0]), float(xyz_max[0])),
        (float(xyz_min[1]), float(xyz_max[1])),
        (float(xyz_min[2]), float(xyz_max[2])),
    ).expanded(0.05)


def _face_normals_from_mesh(V: np.ndarray, F: np.ndarray) -> np.ndarray:
    """Compute normalized face normals from triangle geometry."""
    tris = V[F]
    fn = np.cross(tris[:, 1] - tris[:, 0], tris[:, 2] - tris[:, 0])
    nrm = np.linalg.norm(fn, axis=1)
    good = nrm > 0.0
    fn[good] /= nrm[good][:, None]
    return fn


def _clip_faces_to_bounds(V: np.ndarray, F: np.ndarray, bounds: Bounds3D) -> np.ndarray:
    """Return the subset of ``F`` whose centroids fall inside ``bounds``.

    This is a fast centroid-based clip rather than a true polygon-versus-AABB
    intersection: triangles straddling the bounding box are kept or dropped
    wholesale based on which side their centroid lies on. The result has
    slightly jagged edges right at the bounds but is visually acceptable for
    overlay plots and avoids any new vertex generation. Vertices are not
    compacted — unused entries simply stop being referenced.
    """
    if F.size == 0:
        return F
    tris = V[F]  # (nF, 3, 3)
    centroids = tris.mean(axis=1)  # (nF, 3)
    cx, cy, cz = centroids[:, 0], centroids[:, 1], centroids[:, 2]
    keep = (
        (cx >= bounds.x[0])
        & (cx <= bounds.x[1])
        & (cy >= bounds.y[0])
        & (cy <= bounds.y[1])
        & (cz >= bounds.z[0])
        & (cz <= bounds.z[1])
    )
    return F[keep]


def _face_values_from_vertex_values(F: np.ndarray, vval: np.ndarray) -> np.ndarray:
    """Compute a representative value for each face from vertex values.

    Parameters
    ----------
    F : np.ndarray
        Triangle face index array.
    vval : np.ndarray
        Per-vertex scalar values (same vertex order as `V`).
    Returns
    -------
    np.ndarray
        Mean scalar value for each triangle face.
    """
    return np.nanmean(vval[F], axis=1)


def _poly_collection(
    V: np.ndarray,
    F: np.ndarray,
    face_values: np.ndarray,
    *,
    cmap,
    norm: Normalize,
    alpha: float = 1.0,
) -> Poly3DCollection:
    """Create a polygon collection colored by face values.

    Parameters
    ----------
    V : np.ndarray
        Vertex coordinate array.
    F : np.ndarray
        Triangle face index array.
    face_values : np.ndarray
        Per-face scalar values, aligned with rows of `F`.
    cmap : object
        Colormap.
    norm : Normalize
        Color normalization.
    alpha : float, optional
        Opacity.
    Returns
    -------
    Poly3DCollection
        Colormap-applied triangle polygon collection.
    """
    tris = V[F]
    fc = cmap(norm(face_values))
    fc[:, 3] = np.where(np.isfinite(face_values), alpha, 0.0)
    poly = Poly3DCollection(tris, facecolors=fc, edgecolors="none")
    poly.set_alpha(None)
    return poly


def _solid_poly_collection(
    V: np.ndarray,
    F: np.ndarray,
    *,
    color,
    alpha: float = 1.0,
    edge_color: Optional[str] = None,
    edge_lw: float = 0.4,
) -> Poly3DCollection:
    """Create a solid-color polygon collection.

    Parameters
    ----------
    V : np.ndarray
        Vertex coordinate array.
    F : np.ndarray
        Triangle face index array.
    color : object
        Face color. Accepts any Matplotlib color specification (name, RGB(A), hex, etc.).
    alpha : float, optional
        Opacity.
    edge_color : Optional[str], optional
        Edge color. If `None`, edges are not drawn.
    edge_lw : float, optional
        Edge line width.
    Returns
    -------
    Poly3DCollection
        Triangle polygon collection for rendering.
    """
    tris = V[F]
    rgba = list(to_rgba(color))
    rgba[3] = float(alpha)
    poly = Poly3DCollection(
        tris,
        facecolors=[tuple(rgba)],
        edgecolors=("none" if edge_color is None else edge_color),
        linewidths=edge_lw,
    )
    return poly


def _view_dir_from_axes(ax) -> np.ndarray:
    """Approximate view direction (from data toward the camera) in data coordinates.

    Uses mplot3d's azim/elev convention. This is only used for back-face culling
    of contour segments; it is evaluated at draw time (static view).
    """

    az = np.deg2rad(getattr(ax, "azim", -60.0) or -60.0)
    el = np.deg2rad(getattr(ax, "elev", 30.0) or 30.0)
    return np.array([np.cos(el) * np.cos(az), np.cos(el) * np.sin(az), np.sin(el)], dtype=np.float64)


def _is_mesh_open(V: np.ndarray, F: np.ndarray) -> bool:
    """Return True if the mesh has a real (non-degenerate) boundary edge.

    A closed triangle mesh has every non-degenerate edge shared by exactly
    two triangles. Any edge with a count of 1 is a boundary edge — the
    mesh is open at that point. Used by the contour back-face culling
    logic to decide whether the mesh has a "back side" worth culling:
    closed meshes do (and culling correctly hides occluded contour
    curves), open meshes don't (so culling would only drop legitimately
    visible contours).

    Degenerate edges — both endpoints at the same 3D position — are
    excluded. This is critical for lat-lng sphere meshes built by
    :class:`SphereMeshSurface`: the pole rows collapse all vertices in a
    row to the same 3D point, and the connecting "edges" between those
    distinct-but-coincident pole vertex indices would otherwise look
    like a giant boundary loop and falsely classify the sphere as open.

    Cost is ``O(nF)`` plus one ``np.unique``.
    """
    if F.size == 0:
        return False
    edges = np.concatenate(
        [F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]],
        axis=0,
    )
    edges_sorted = np.sort(edges, axis=1)

    # Drop degenerate edges (both endpoints map to the same 3D point).
    # Use a small absolute tolerance because trig identities like
    # cos(-π/2) are not exactly zero in fp64 — a sphere's pole row
    # vertices differ by ~1e-17 epsilon noise but represent the same
    # physical point. The threshold (1e-9) is far above fp64 noise but
    # well below any physically meaningful distance in the units this
    # library is used with.
    p0 = V[edges_sorted[:, 0]]
    p1 = V[edges_sorted[:, 1]]
    nondegenerate = np.any(np.abs(p0 - p1) > 1e-9, axis=1)
    edges_sorted = edges_sorted[nondegenerate]
    if edges_sorted.size == 0:
        return False

    # Pack each edge into a single int64 key for fast unique counting.
    a = edges_sorted[:, 0].astype(np.int64, copy=False)
    b = edges_sorted[:, 1].astype(np.int64, copy=False)
    keys = (a << np.int64(32)) | b
    _, counts = np.unique(keys, return_counts=True)
    return bool(np.any(counts == 1))


def _label_position_for_level(segs_array: np.ndarray) -> Optional[np.ndarray]:
    """Pick a representative ``(x, y, z)`` for placing a contour label.

    Strategy: take the midpoint of every segment, find their centroid,
    and return the midpoint closest to that centroid. For a single
    connected contour curve this lands on the curve roughly halfway
    along; for disconnected curves it picks one of them. Returns
    ``None`` for an empty input.
    """
    if segs_array is None or segs_array.size == 0:
        return None
    midpoints = segs_array.mean(axis=1)  # (n, 3)
    centroid = midpoints.mean(axis=0)
    distances = np.linalg.norm(midpoints - centroid, axis=1)
    idx = int(np.argmin(distances))
    return midpoints[idx]


def _contour_segments_on_mesh(
    V: np.ndarray,
    F: np.ndarray,
    vval: np.ndarray,
    levels: Sequence[float],
    *,
    face_normals: Optional[np.ndarray] = None,
    offset: float = 0.0,
) -> "dict[float, np.ndarray]":
    """Generate contour line segments for scalar values on a triangular mesh.

    Returns a mapping ``{level: segs}`` where ``segs`` has shape
    ``(n_segments, 2, 3)`` (each row is the two endpoints of one segment in
    world coordinates). Empty levels map to a ``(0, 2, 3)`` array so the
    caller can stack uniformly without per-level branching.

    Implementation note: this used to be a per-face Python loop that became
    the dominant cost at high resolution (100k+ faces × N levels). The
    current version is fully vectorised — for each level we build a
    ``(nF, 3)`` boolean mask of which edges crossed, gather the two
    crossing points via :func:`numpy.argsort` + advanced indexing, and
    return them as one stacked array.
    """
    out: "dict[float, np.ndarray]" = {}

    if F.size == 0 or len(levels) == 0:
        empty = np.empty((0, 2, 3), dtype=np.float64)
        return {float(L): empty for L in levels}

    p = V[F]  # (nF, 3, 3)
    s = vval[F]  # (nF, 3)

    valid_face = np.all(np.isfinite(s), axis=1)
    p = p[valid_face]
    s = s[valid_face]

    if p.shape[0] == 0:
        empty = np.empty((0, 2, 3), dtype=np.float64)
        return {float(L): empty for L in levels}

    # Optional tiny offset (only safe on flat meshes — see plot_surfaces
    # docstring for the curved-surface caveat).
    fn = None
    if face_normals is not None and offset != 0.0:
        fn = np.asarray(face_normals, dtype=np.float64)
        if fn.shape[0] == F.shape[0]:
            fn = fn[valid_face]
        else:
            fn = None

    # Edge endpoints: edge ei of each face goes from vertex ei to vertex
    # (ei + 1) mod 3. Roll along the vertex axis to get the "next" vertex.
    pa_all = p  # (nF, 3, 3)  start positions
    pb_all = np.roll(p, -1, axis=1)  # (nF, 3, 3)  end positions
    sa_all = s  # (nF, 3)     start values
    sb_all = np.roll(s, -1, axis=1)  # (nF, 3)     end values

    den_all = sb_all - sa_all  # (nF, 3)
    safe_den = np.where(den_all != 0.0, den_all, 1.0)

    nF = p.shape[0]
    rows = np.arange(nF)

    for L in levels:
        L_f = float(L)
        # Boolean mask: which edges of which faces cross this level.
        cross = (den_all != 0.0) & ((sa_all - L_f) * (sb_all - L_f) < 0.0)
        n_cross = cross.sum(axis=1)
        face_mask = n_cross == 2  # exactly two crossings → one segment
        if not face_mask.any():
            out[L_f] = np.empty((0, 2, 3), dtype=np.float64)
            continue

        # Linear interpolation parameter per edge (only meaningful where cross
        # is True; the others are masked away below).
        with np.errstate(invalid="ignore"):
            t_all = (L_f - sa_all) / safe_den  # (nF, 3)
        # Intersection points per edge in world coords.
        ip_all = pa_all + t_all[..., None] * (pb_all - pa_all)  # (nF, 3, 3)

        # Restrict to faces with exactly two crossings.
        valid_cross = cross[face_mask]  # (nv, 3)
        valid_ip = ip_all[face_mask]  # (nv, 3, 3)
        nv = valid_cross.shape[0]
        valid_rows = rows[:nv]

        # Stable argsort places True last (False=0 < True=1) so the final
        # two columns of the sorted index hold the indices of the two
        # crossing edges, in stable order.
        order = np.argsort(valid_cross.astype(np.int8), axis=1, kind="stable")
        edge_a = order[:, -2]
        edge_b = order[:, -1]

        seg_a = valid_ip[valid_rows, edge_a]  # (nv, 3)
        seg_b = valid_ip[valid_rows, edge_b]  # (nv, 3)
        segs_array = np.stack([seg_a, seg_b], axis=1).astype(np.float64)  # (nv, 2, 3)

        if fn is not None:
            valid_normals = fn[face_mask]
            segs_array = segs_array + float(offset) * valid_normals[:, None, :]

        out[L_f] = segs_array

    return out


def plot_surfaces(
    ax,
    *,
    field=None,
    surfaces,
    bounds: Optional[Bounds3D] = None,
    mode: Mode = "cmap+cont",
    cmap_name: str = "jet",
    vmin: Optional[float] = None,
    vmax: Optional[float] = None,
    alpha: float = 1.0,
    contour_levels: Union[int, Sequence[float]] = 10,
    contour_color: str = "k",
    contour_lw: float = 0.8,
    contour_on_top: bool = True,
    contour_offset: float = 0.0,
    contour_side: str = "auto",
    clabel: bool = False,
    clabel_fmt: Union[str, "Callable[[float], str]"] = "{:g}",
    clabel_kwargs: Optional["dict"] = None,
    clip_to_bounds: bool = True,
):
    """Render explicit triangle mesh surfaces with optional colormap + contours.

    When ``clip_to_bounds`` is ``True`` (the default) every mesh is filtered
    against the resolved ``bounds`` (either the user-supplied box or the
    field/mesh-derived one) by dropping triangles whose centroid lies
    outside. Pass ``clip_to_bounds=False`` to disable the clip and render
    every mesh in full — useful when you intentionally want surfaces
    extending beyond the plot extent.

    Side effect: this function sets ``ax.computed_zorder = False`` so it
    can pin the merged polygon collection behind the contour line
    collections via explicit ``set_zorder``. mplot3d's automatic
    inter-collection depth sort relies on a single per-collection z value
    that goes through the camera projection, which is camera-dependent and
    causes contours to vanish behind the polygon they were extracted from
    at certain viewpoints. Disabling computed_zorder makes the contour
    layering camera-independent. Per-triangle depth sort *within* the
    merged polygon collection still runs (it lives in
    ``Poly3DCollection.do_3d_projection``) so interleaving meshes still
    render in the right order.

    ``contour_offset`` defaults to ``0.0`` because shifting contour
    segments along the source triangle's face normal **breaks line
    continuity on curved surfaces**: adjacent triangles share an edge
    but have different face normals, so the shared edge crossing gets
    pushed in two different directions and the contour fractures into
    per-triangle dashes. The polygon-vs-contour layering is already
    handled by the explicit ``set_zorder`` mechanism above, so an
    offset is not needed for visibility. Pass a small positive
    ``contour_offset`` only when working with strictly flat surfaces
    where every triangle shares the same normal.

    Contour labels: when ``clabel=True`` one text label per level is
    placed at a representative midpoint along that level's segments
    (closest segment midpoint to the level's overall centroid).
    Format the value with ``clabel_fmt`` — either a Python format
    string like ``"{:.1f}"`` (default ``"{:g}"``) or a callable
    ``level -> str``. Style the text via ``clabel_kwargs`` (forwarded
    to :meth:`matplotlib.axes.Axes.text`); useful keys include
    ``fontsize``, ``color``, ``ha``/``va``, ``bbox``. Defaults are
    ``color=contour_color``, ``fontsize=8``, centered alignment.

    ``contour_side`` controls back-face culling for contour
    extraction:

    * ``"auto"`` (default) — detect whether the mesh is closed
      (every edge shared by two triangles) or open (any boundary
      edges). Closed meshes get the front-facing cull so back-side
      contours don't bleed through. Open meshes (e.g. a half cylinder
      built with ``theta_range``, a flat ``RectangleMeshSurface``,
      or a ``CompositeMeshSurface`` of mostly-open boundaries) keep
      every triangle because they have no back side to hide.
    * ``"front"`` / ``"back"`` — explicit normal-based cull.
    * ``"both"`` — keep every triangle, no culling.
    """

    items = _as_list(surfaces)

    g = None if field is None else field.grid
    if bounds is None:
        if g is not None:
            x_edges, y_edges, z_edges = g.extent_edges()
            bounds = Bounds3D(x_edges, y_edges, z_edges).expanded(0.05)
        else:
            bounds = _bounds_from_mesh_surfaces(items)
            if bounds is None:
                raise ValueError("bounds is required when field is None and the surfaces do not expose vertex extents")

    cmap = plt.get_cmap(cmap_name)
    norm = _make_norm(vmin, vmax, robust_data=None if field is None else field.data)

    if isinstance(contour_levels, int):
        levels = np.linspace(norm.vmin, norm.vmax, contour_levels)
    else:
        levels = np.asarray(list(contour_levels), dtype=float)

    # NOTE on rendering order:
    #   matplotlib's mplot3d uses a painter's algorithm. There are two
    #   levels of sorting:
    #
    #     (a) Across collections: each Poly3DCollection gets a single
    #         "depth" value (set_sort_zpos override, or by default the
    #         average camera-space z of its vertices). All collections
    #         are drawn back-to-front by that single value when
    #         ax.computed_zorder is True (the default).
    #
    #     (b) Within a single Poly3DCollection: every triangle is sorted
    #         independently by its own camera-space average z. This is
    #         the only level of sort that gives *correct* depth ordering
    #         when surfaces interpenetrate or interleave in 3D.
    #
    #   We merge every face from every input mesh into ONE
    #   Poly3DCollection (with per-face colors / edges / linewidths) so
    #   the per-triangle sort kicks in and the user gets the visually
    #   correct order from any viewpoint.
    #
    #   For the contour Line3DCollections vs. the merged polygon, we
    #   cannot rely on (a) because mpl's auto sort goes through the
    #   camera projection: at some camera angles the contours sort as
    #   "background" relative to the merged polygon's average z and
    #   vanish behind it. Instead we disable computed_zorder and pin
    #   the layering with explicit set_zorder values. The internal
    #   per-triangle sort inside the merged Poly3DCollection still runs
    #   (it lives inside do_3d_projection, which is called either way).
    ax.computed_zorder = False

    poly_V_chunks: list[np.ndarray] = []
    poly_F_chunks: list[np.ndarray] = []
    poly_fc_chunks: list[np.ndarray] = []
    poly_ec_chunks: list[np.ndarray] = []
    poly_lw_chunks: list[np.ndarray] = []
    v_offset = 0

    # Per-level accumulator for contour labels: {level: list of (nv, 2, 3)
    # arrays from each surface}. Used after the loop to pick a representative
    # midpoint per level for clabel text.
    clabel_segs_per_level: Dict[float, list] = {}

    for srf in items:
        surface = srf.surface
        V, F = _surface_mesh(surface)
        if V.size == 0 or F.size == 0:
            continue

        if clip_to_bounds:
            F = _clip_faces_to_bounds(V, F, bounds)
            if F.size == 0:
                continue

        item_alpha = alpha if srf.alpha is None else float(srf.alpha)

        # Decide whether faces from this surface get drawn at all, and
        # compute the per-face color array (one rgba per triangle).
        draw_faces = False
        facecolors: Optional[np.ndarray] = None
        vval: Optional[np.ndarray] = None  # field samples for contour extraction

        if srf.style == "solid":
            draw_faces = True
            rgba = np.asarray(to_rgba(srf.solid_color), dtype=np.float64).copy()
            rgba[3] = item_alpha
            facecolors = np.tile(rgba, (F.shape[0], 1))
        elif srf.style == "field":
            if field is None:
                raise ValueError("field is required when style='field' or contours are requested")
            vval = field.sample(V[:, 0], V[:, 1], V[:, 2])
            if mode in ("cmap", "cmap+cont"):
                draw_faces = True
                face_val = _face_values_from_vertex_values(F, vval)
                facecolors = np.asarray(cmap(norm(face_val)), dtype=np.float64).copy()
                facecolors[:, 3] = np.where(np.isfinite(face_val), item_alpha, 0.0)
        else:
            raise ValueError(f"Unknown surface style {srf.style!r}")

        if draw_faces and facecolors is not None:
            nF = F.shape[0]
            if srf.edge_color is None:
                edgecolors = np.zeros((nF, 4), dtype=np.float64)
            else:
                edge_rgba = np.asarray(to_rgba(srf.edge_color), dtype=np.float64).copy()
                edgecolors = np.tile(edge_rgba, (nF, 1))
            linewidths = np.full(nF, float(srf.edge_lw), dtype=np.float64)

            poly_V_chunks.append(V)
            poly_F_chunks.append(F + v_offset)
            poly_fc_chunks.append(facecolors)
            poly_ec_chunks.append(edgecolors)
            poly_lw_chunks.append(linewidths)
            v_offset += V.shape[0]

        # Contour lines remain per-item — they live in a separate
        # Line3DCollection that gets pushed forward via sort_zpos.
        if srf.style == "field" and srf.draw_contours and mode in ("cont", "cmap+cont"):
            if vval is None:
                # Should be unreachable (vval is set in the field branch above),
                # but be defensive in case mode/style invariants change.
                vval = field.sample(V[:, 0], V[:, 1], V[:, 2])
            fn = _face_normals_from_mesh(V, F)

            # Back-face culling for contours.
            #
            # contour_side options:
            #   "auto"   — detect open vs closed mesh:
            #              * closed mesh (every edge shared by 2 triangles)
            #                → cull back-facing triangles like "front"
            #              * open mesh (any boundary edge)
            #                → keep everything; the mesh has no back side
            #                  so any "front-facing" subset based on a
            #                  single per-triangle normal is guaranteed
            #                  to drop legitimately visible contours
            #                  (e.g. a half-cylinder via theta_range
            #                  whose outward normals all point AWAY from
            #                  the camera).
            #   "front"  — keep triangles whose normal faces the camera
            #   "back"   — keep triangles whose normal faces away
            #   "both"   — keep everything
            if contour_side not in ("both", "front", "back", "auto"):
                raise ValueError('contour_side must be "auto", "both", "front", or "back"')
            F_contour = F
            effective_side = contour_side
            if effective_side == "auto":
                effective_side = "both" if _is_mesh_open(V, F_contour) else "front"
            if effective_side != "both" and len(F_contour) > 0:
                vdir = _view_dir_from_axes(ax)
                d = fn[:, 0] * vdir[0] + fn[:, 1] * vdir[1] + fn[:, 2] * vdir[2]
                keep = d > 0.0 if effective_side == "front" else d < 0.0
                # If orientation is flipped, keep may become almost empty; auto-flip in that case.
                if keep.mean() < 0.05:
                    keep = ~keep
                F_contour = F_contour[keep]
                fn = fn[keep]

            segs_per_level = _contour_segments_on_mesh(
                V,
                F_contour,
                vval,
                levels,
                face_normals=fn,
                offset=contour_offset,
            )
            # Stack every level's segments into a single (n_total, 2, 3)
            # array for one Line3DCollection. The mpl LineCollection
            # constructor accepts an iterable of (2, 3) arrays so we feed
            # it via list(segs_array) which iterates the first axis.
            flat_segs = []
            for L_val, level_segs in segs_per_level.items():
                if level_segs.size == 0:
                    continue
                flat_segs.extend(list(level_segs))
                # Accumulate the segments for clabel positioning later.
                clabel_segs_per_level.setdefault(L_val, []).append(level_segs)
            if flat_segs:
                lc = Line3DCollection(
                    flat_segs,
                    colors=contour_color,
                    linewidths=contour_lw,
                    # Round caps/joins matter a lot for thick contour
                    # lines on curved surfaces. mpl's defaults (butt /
                    # miter) leave a small triangular gap at every
                    # segment boundary, and the gaps look like the
                    # contour curve has been chopped into discrete
                    # tick marks. Round caps fill in those gaps so
                    # thick contours render as one continuous curve.
                    capstyle="round",
                    joinstyle="round",
                )
                # With ax.computed_zorder=False, set_zorder is honoured at
                # draw time. Contours sit above the merged polygon (which
                # gets zorder=1 below) when contour_on_top is True.
                lc.set_zorder(2 if contour_on_top else 1)
                ax.add_collection3d(lc)

    # ---- merged polygon collection ----
    if poly_V_chunks:
        V_all = np.vstack(poly_V_chunks).astype(np.float64)
        F_all = np.vstack(poly_F_chunks).astype(np.int64)
        fc_all = np.vstack(poly_fc_chunks)
        ec_all = np.vstack(poly_ec_chunks)
        lw_all = np.concatenate(poly_lw_chunks)

        tris = V_all[F_all]
        # If every requested edge is fully transparent, switch to "none" so
        # mpl skips the edge-drawing path entirely (slight speed win and a
        # cleaner output).
        if not np.any(ec_all[:, 3] > 0.0):
            edgecolors_arg = "none"
        else:
            edgecolors_arg = ec_all
        # Linewidth optimisation: a per-face linewidth array forces mpl to
        # walk every face inside set_linewidth → _bcast_lwls in Python and
        # is by far the slowest part of Poly3DCollection construction at
        # high resolution. Detect the common case where every surface used
        # the same edge_lw and pass a scalar instead — mpl then takes the
        # fast cached-LineCollection path. (At high resolution this brought
        # plot_surfaces from ~560 ms to ~120 ms in our profile.)
        if lw_all.size == 0 or np.all(lw_all == lw_all[0]):
            linewidths_arg = float(lw_all[0]) if lw_all.size else 0.0
        else:
            linewidths_arg = lw_all
        merged_poly = Poly3DCollection(
            tris,
            facecolors=fc_all,
            edgecolors=edgecolors_arg,
            linewidths=linewidths_arg,
            # Disable antialiasing on the polygon faces. mpl's default
            # AA produces semi-transparent fringes around every triangle
            # which the user sees as the whole face being "a bit
            # transparent" even when the per-face alpha is 1.0. Crisp
            # edges are also a better fit for the painter's-algorithm
            # depth sort, since AA depends on draw order.
            antialiaseds=False,
        )
        # set_alpha(None) tells mpl NOT to multiply every face by a
        # global alpha — we want the per-face rgba in fc_all to be the
        # final value, including the explicit 1.0 cases.
        merged_poly.set_alpha(None)
        # Pin polygons below contour lines via explicit zorder
        # (computed_zorder is disabled at the top of this function).
        merged_poly.set_zorder(1)
        ax.add_collection3d(merged_poly)

    # ---- contour labels ----
    if clabel and clabel_segs_per_level:
        defaults = {
            "color": contour_color,
            "fontsize": 8,
            "ha": "center",
            "va": "center",
        }
        if clabel_kwargs:
            defaults.update(clabel_kwargs)
        # zorder >= contour line collections so labels sit on top.
        defaults.setdefault("zorder", 3)

        for L_val, segs_lists in clabel_segs_per_level.items():
            stacked = np.concatenate(segs_lists, axis=0)
            pos = _label_position_for_level(stacked)
            if pos is None:
                continue
            if callable(clabel_fmt):
                label_text = clabel_fmt(L_val)
            else:
                label_text = clabel_fmt.format(L_val)
            ax.text(float(pos[0]), float(pos[1]), float(pos[2]), label_text, **defaults)

    ax.set_xlim(*bounds.x)
    ax.set_ylim(*bounds.y)
    ax.set_zlim(*bounds.z)

    return cmap, norm


def add_colorbar(fig, ax, *, cmap, norm, label=r"$\phi$ (V)", cax=None, fraction=0.03, pad=0.08):
    """Add a colorbar corresponding to the rendered plot.

    Parameters
    ----------
    fig : object
        Target Figure.
    ax : object
        Target Axes.
    cmap : object
        Colormap.
    norm : object
        Color normalization.
    label : str, optional
        Label string for the colorbar.
    fraction : float, optional
        Width ratio of the colorbar (`Figure.colorbar`'s `fraction`).
    pad : float, optional
        Spacing between the plot and the colorbar (`Figure.colorbar`'s `pad`).
    Returns
    -------
    object
        The added colorbar object.
    """
    m = cm.ScalarMappable(norm=norm, cmap=cmap)
    m.set_array([])
    cbar = fig.colorbar(m, ax=ax, fraction=fraction, pad=pad, cax=cax)
    cbar.set_label(label)
    return cbar
