"""
Code Formatter for generated Python code.

This module provides utilities for:
- Formatting Python code with black
- Sorting imports with isort
- Linting with flake8 (optional)
- Code quality checks
"""

from __future__ import annotations

import subprocess
import tempfile
import logging
from pathlib import Path
from typing import Optional, Union, List, Dict, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class FormattingResult:
    """Result of code formatting operation."""
    success: bool
    original_content: str
    formatted_content: str
    changes_made: bool
    errors: List[str]
    warnings: List[str]


class CodeFormatter:
    """
    Formatter for Python code using black and isort.
    
    Features:
    - Black code formatting
    - isort import sorting
    - Error handling and reporting
    - Customizable formatting options
    """
    
    def __init__(
        self,
        use_black: bool = True,
        use_isort: bool = True,
        black_line_length: int = 88,
        black_string_normalization: bool = True,
        isort_profile: str = "black",
        isort_multi_line: int = 3,
        isort_include_trailing_comma: bool = True,
        isort_force_grid_wrap: int = 0,
        isort_use_parentheses: bool = True,
        isort_ensure_newline_before_comments: bool = True
    ):
        """
        Initialize CodeFormatter.
        
        Args:
            use_black: Whether to use black for formatting
            use_isort: Whether to use isort for import sorting
            black_line_length: Black line length setting
            black_string_normalization: Black string normalization setting
            isort_profile: isort profile to use
            isort_multi_line: isort multi-line import style
            isort_include_trailing_comma: isort trailing comma setting
            isort_force_grid_wrap: isort force grid wrap setting
            isort_use_parentheses: isort parentheses setting
            isort_ensure_newline_before_comments: isort newline before comments setting
        """
        self.use_black = use_black
        self.use_isort = use_isort
        self.black_line_length = black_line_length
        self.black_string_normalization = black_string_normalization
        self.isort_profile = isort_profile
        self.isort_multi_line = isort_multi_line
        self.isort_include_trailing_comma = isort_include_trailing_comma
        self.isort_force_grid_wrap = isort_force_grid_wrap
        self.isort_use_parentheses = isort_use_parentheses
        self.isort_ensure_newline_before_comments = isort_ensure_newline_before_comments
    
    def _check_tool_availability(self, tool_name: str) -> bool:
        """
        Check if a formatting tool is available.
        
        Args:
            tool_name: Name of the tool (black, isort)
            
        Returns:
            True if tool is available
        """
        try:
            result = subprocess.run(
                [tool_name, "--version"],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            return False
    
    def _run_black(
        self,
        content: str,
        file_path: Optional[Union[str, Path]] = None
    ) -> FormattingResult:
        """
        Format content with black.
        
        Args:
            content: Python code content
            file_path: Optional file path for context
            
        Returns:
            Formatting result
        """
        if not self.use_black:
            return FormattingResult(
                success=True,
                original_content=content,
                formatted_content=content,
                changes_made=False,
                errors=[],
                warnings=[]
            )
        
        if not self._check_tool_availability("black"):
            return FormattingResult(
                success=False,
                original_content=content,
                formatted_content=content,
                changes_made=False,
                errors=["black is not available"],
                warnings=[]
            )
        
        try:
            # Create temporary file with content
            with tempfile.NamedTemporaryFile(
                mode='w',
                suffix='.py',
                delete=False,
                encoding='utf-8'
            ) as temp_file:
                temp_file.write(content)
                temp_file_path = temp_file.name
            
            # Run black
            cmd = [
                "black",
                "--line-length", str(self.black_line_length),
                "--quiet"
            ]
            
            if not self.black_string_normalization:
                cmd.append("--skip-string-normalization")
            
            cmd.append(temp_file_path)
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            # Read formatted content
            formatted_content = Path(temp_file_path).read_text(encoding='utf-8')
            
            # Clean up temporary file
            Path(temp_file_path).unlink()
            
            if result.returncode == 0:
                changes_made = formatted_content != content
                return FormattingResult(
                    success=True,
                    original_content=content,
                    formatted_content=formatted_content,
                    changes_made=changes_made,
                    errors=[],
                    warnings=[]
                )
            else:
                return FormattingResult(
                    success=False,
                    original_content=content,
                    formatted_content=content,
                    changes_made=False,
                    errors=[result.stderr] if result.stderr else ["black formatting failed"],
                    warnings=[]
                )
                
        except subprocess.TimeoutExpired:
            return FormattingResult(
                success=False,
                original_content=content,
                formatted_content=content,
                changes_made=False,
                errors=["black formatting timed out"],
                warnings=[]
            )
        except Exception as e:
            return FormattingResult(
                success=False,
                original_content=content,
                formatted_content=content,
                changes_made=False,
                errors=[f"black formatting error: {str(e)}"],
                warnings=[]
            )
    
    def _run_isort(
        self,
        content: str,
        file_path: Optional[Union[str, Path]] = None
    ) -> FormattingResult:
        """
        Sort imports with isort.
        
        Args:
            content: Python code content
            file_path: Optional file path for context
            
        Returns:
            Formatting result
        """
        if not self.use_isort:
            return FormattingResult(
                success=True,
                original_content=content,
                formatted_content=content,
                changes_made=False,
                errors=[],
                warnings=[]
            )
        
        if not self._check_tool_availability("isort"):
            return FormattingResult(
                success=False,
                original_content=content,
                formatted_content=content,
                changes_made=False,
                errors=["isort is not available"],
                warnings=[]
            )
        
        try:
            # Create temporary file with content
            with tempfile.NamedTemporaryFile(
                mode='w',
                suffix='.py',
                delete=False,
                encoding='utf-8'
            ) as temp_file:
                temp_file.write(content)
                temp_file_path = temp_file.name
            
            # Run isort
            cmd = [
                "isort",
                "--profile", self.isort_profile,
                "--multi-line", str(self.isort_multi_line),
                "--quiet"
            ]
            
            if self.isort_include_trailing_comma:
                cmd.append("--trailing-comma")
            
            if self.isort_force_grid_wrap > 0:
                cmd.extend(["--force-grid-wrap", str(self.isort_force_grid_wrap)])
            
            if self.isort_use_parentheses:
                cmd.append("--use-parentheses")
            
            if self.isort_ensure_newline_before_comments:
                cmd.append("--ensure-newline-before-comments")
            
            cmd.append(temp_file_path)
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            # Read formatted content
            formatted_content = Path(temp_file_path).read_text(encoding='utf-8')
            
            # Clean up temporary file
            Path(temp_file_path).unlink()
            
            if result.returncode == 0:
                changes_made = formatted_content != content
                return FormattingResult(
                    success=True,
                    original_content=content,
                    formatted_content=formatted_content,
                    changes_made=changes_made,
                    errors=[],
                    warnings=[]
                )
            else:
                return FormattingResult(
                    success=False,
                    original_content=content,
                    formatted_content=content,
                    changes_made=False,
                    errors=[result.stderr] if result.stderr else ["isort import sorting failed"],
                    warnings=[]
                )
                
        except subprocess.TimeoutExpired:
            return FormattingResult(
                success=False,
                original_content=content,
                formatted_content=content,
                changes_made=False,
                errors=["isort import sorting timed out"],
                warnings=[]
            )
        except Exception as e:
            return FormattingResult(
                success=False,
                original_content=content,
                formatted_content=content,
                changes_made=False,
                errors=[f"isort import sorting error: {str(e)}"],
                warnings=[]
            )
    
    def format_content(
        self,
        content: str,
        file_path: Optional[Union[str, Path]] = None,
        apply_isort_first: bool = True
    ) -> FormattingResult:
        """
        Format Python code content.
        
        Args:
            content: Python code content
            file_path: Optional file path for context
            apply_isort_first: Whether to apply isort before black
            
        Returns:
            Formatting result
        """
        original_content = content
        current_content = content
        all_errors = []
        all_warnings = []
        changes_made = False
        
        try:
            # Apply isort first if requested
            if apply_isort_first and self.use_isort:
                isort_result = self._run_isort(current_content, file_path)
                if isort_result.success:
                    current_content = isort_result.formatted_content
                    if isort_result.changes_made:
                        changes_made = True
                    logger.debug("Applied isort formatting")
                else:
                    all_errors.extend(isort_result.errors)
                    logger.warning(f"isort formatting failed: {isort_result.errors}")
            
            # Apply black formatting
            if self.use_black:
                black_result = self._run_black(current_content, file_path)
                if black_result.success:
                    current_content = black_result.formatted_content
                    if black_result.changes_made:
                        changes_made = True
                    logger.debug("Applied black formatting")
                else:
                    all_errors.extend(black_result.errors)
                    logger.warning(f"black formatting failed: {black_result.errors}")
            
            # Apply isort after black if not done before
            if not apply_isort_first and self.use_isort:
                isort_result = self._run_isort(current_content, file_path)
                if isort_result.success:
                    current_content = isort_result.formatted_content
                    if isort_result.changes_made:
                        changes_made = True
                    logger.debug("Applied isort formatting after black")
                else:
                    all_errors.extend(isort_result.errors)
                    logger.warning(f"isort formatting failed: {isort_result.errors}")
            
            success = len(all_errors) == 0
            
            if success and changes_made:
                logger.info(f"Successfully formatted code with {len([r for r in [isort_result if 'isort_result' in locals() else None, black_result if 'black_result' in locals() else None] if r and r.changes_made])} changes")
            elif success:
                logger.debug("Code formatting completed with no changes needed")
            
            return FormattingResult(
                success=success,
                original_content=original_content,
                formatted_content=current_content,
                changes_made=changes_made,
                errors=all_errors,
                warnings=all_warnings
            )
            
        except Exception as e:
            logger.error(f"Unexpected error during formatting: {e}")
            return FormattingResult(
                success=False,
                original_content=original_content,
                formatted_content=original_content,
                changes_made=False,
                errors=[f"Unexpected formatting error: {str(e)}"],
                warnings=[]
            )
    
    def format_file(
        self,
        file_path: Union[str, Path],
        in_place: bool = True
    ) -> FormattingResult:
        """
        Format Python file.
        
        Args:
            file_path: Path to Python file
            in_place: Whether to modify file in place
            
        Returns:
            Formatting result
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            return FormattingResult(
                success=False,
                original_content="",
                formatted_content="",
                changes_made=False,
                errors=[f"File not found: {file_path}"],
                warnings=[]
            )
        
        try:
            # Read file content
            content = file_path.read_text(encoding='utf-8')
            
            # Format content
            result = self.format_content(content, file_path)
            
            # Write formatted content back if in_place and successful
            if in_place and result.success and result.changes_made:
                file_path.write_text(result.formatted_content, encoding='utf-8')
                logger.info(f"Formatted file: {file_path}")
            
            return result
            
        except Exception as e:
            logger.error(f"Error formatting file {file_path}: {e}")
            return FormattingResult(
                success=False,
                original_content="",
                formatted_content="",
                changes_made=False,
                errors=[f"File formatting error: {str(e)}"],
                warnings=[]
            )
    
    def get_formatting_config(self) -> Dict[str, Any]:
        """
        Get current formatting configuration.
        
        Returns:
            Dictionary with formatting configuration
        """
        return {
            "use_black": self.use_black,
            "use_isort": self.use_isort,
            "black_line_length": self.black_line_length,
            "black_string_normalization": self.black_string_normalization,
            "isort_profile": self.isort_profile,
            "isort_multi_line": self.isort_multi_line,
            "isort_include_trailing_comma": self.isort_include_trailing_comma,
            "isort_force_grid_wrap": self.isort_force_grid_wrap,
            "isort_use_parentheses": self.isort_use_parentheses,
            "isort_ensure_newline_before_comments": self.isort_ensure_newline_before_comments
        }


