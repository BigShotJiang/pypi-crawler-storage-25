from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import UNSET, Response, Unset


def _get_kwargs(
    requirement_number: int,
    *,
    format_: Union[Unset, str] = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["format"] = format_

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/house-requirement/{requirement_number}".format(
            requirement_number=requirement_number,
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Any]:
    if response.status_code == 200:
        return None
    if response.status_code == 400:
        return None
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    requirement_number: int,
    *,
    client: AuthenticatedClient,
    format_: Union[Unset, str] = UNSET,
) -> Response[Any]:
    r"""Returns detailed information for a specified House requirement.

     GET /house-requirement/:requirementNumber

    **Example Request**

    https://api.congress.gov/v3/house-requirement/8070?api_key=[INSERT_KEY]

    **Example Response**

        {
            \"houseRequirement\": {
                \"activeRecord\": true,
                \"frequency\": \"[No deadline specified].\",
                \"legalAuthority\": \"5 U.S.C. 801(a)(1)(A); Public Law 104\u2013121, section 251; (110
    Stat. 868)\",
                \"matchingCommunications\": {
                    \"count\": 85085,
                    \"url\": \"https://api.congress.gov/v3/house-requirement/8070/matching-
    communications?format=json\"
                },
                \"nature\": \"Congressional review of agency rulemaking.\",
                \"number\": 8070,
                \"parentAgency\": \"Multiple Executive Agencies and Departments\",
                \"submittingAgency\": Multiple Executive Agencies and Departments\",
                \"submittingOfficial\": null,
                \"updateDate\": \"2021-08-13\"
            }

    Args:
        requirement_number (int):
        format_ (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        requirement_number=requirement_number,
        format_=format_,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


async def asyncio_detailed(
    requirement_number: int,
    *,
    client: AuthenticatedClient,
    format_: Union[Unset, str] = UNSET,
) -> Response[Any]:
    r"""Returns detailed information for a specified House requirement.

     GET /house-requirement/:requirementNumber

    **Example Request**

    https://api.congress.gov/v3/house-requirement/8070?api_key=[INSERT_KEY]

    **Example Response**

        {
            \"houseRequirement\": {
                \"activeRecord\": true,
                \"frequency\": \"[No deadline specified].\",
                \"legalAuthority\": \"5 U.S.C. 801(a)(1)(A); Public Law 104\u2013121, section 251; (110
    Stat. 868)\",
                \"matchingCommunications\": {
                    \"count\": 85085,
                    \"url\": \"https://api.congress.gov/v3/house-requirement/8070/matching-
    communications?format=json\"
                },
                \"nature\": \"Congressional review of agency rulemaking.\",
                \"number\": 8070,
                \"parentAgency\": \"Multiple Executive Agencies and Departments\",
                \"submittingAgency\": Multiple Executive Agencies and Departments\",
                \"submittingOfficial\": null,
                \"updateDate\": \"2021-08-13\"
            }

    Args:
        requirement_number (int):
        format_ (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        requirement_number=requirement_number,
        format_=format_,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)
