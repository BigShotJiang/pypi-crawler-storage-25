from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.amendment_actions_item import AmendmentActionsItem
from ...models.get_amendment_congress_amendment_type_amendment_number_actions_format import (
    GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    congress: int,
    amendment_type: str,
    amendment_number: str,
    *,
    format_: Union[
        Unset, GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat
    ] = GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_format_: Union[Unset, str] = UNSET
    if not isinstance(format_, Unset):
        json_format_ = format_.value

    params["format"] = json_format_

    params["offset"] = offset

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/amendment/{congress}/{amendment_type}/{amendment_number}/actions".format(
            congress=congress,
            amendment_type=amendment_type,
            amendment_number=amendment_number,
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Any, list["AmendmentActionsItem"]]]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for componentsschemas_amendment_actions_item_data in _response_200:
            componentsschemas_amendment_actions_item = AmendmentActionsItem.from_dict(
                componentsschemas_amendment_actions_item_data
            )

            response_200.append(componentsschemas_amendment_actions_item)

        return response_200
    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Any, list["AmendmentActionsItem"]]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    congress: int,
    amendment_type: str,
    amendment_number: str,
    *,
    client: Union[AuthenticatedClient, Client],
    format_: Union[
        Unset, GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat
    ] = GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
) -> Response[Union[Any, list["AmendmentActionsItem"]]]:
    """Returns the list of actions on a specified amendment.

     Returns the list of actions on a specified amendment.

    Args:
        congress (int):
        amendment_type (str):
        amendment_number (str):
        format_ (Union[Unset, GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat]):
            Default: GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat.XML.
        offset (Union[Unset, int]):
        limit (Union[Unset, int]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, list['AmendmentActionsItem']]]
    """

    kwargs = _get_kwargs(
        congress=congress,
        amendment_type=amendment_type,
        amendment_number=amendment_number,
        format_=format_,
        offset=offset,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    congress: int,
    amendment_type: str,
    amendment_number: str,
    *,
    client: Union[AuthenticatedClient, Client],
    format_: Union[
        Unset, GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat
    ] = GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
) -> Optional[Union[Any, list["AmendmentActionsItem"]]]:
    """Returns the list of actions on a specified amendment.

     Returns the list of actions on a specified amendment.

    Args:
        congress (int):
        amendment_type (str):
        amendment_number (str):
        format_ (Union[Unset, GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat]):
            Default: GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat.XML.
        offset (Union[Unset, int]):
        limit (Union[Unset, int]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, list['AmendmentActionsItem']]
    """

    return sync_detailed(
        congress=congress,
        amendment_type=amendment_type,
        amendment_number=amendment_number,
        client=client,
        format_=format_,
        offset=offset,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    congress: int,
    amendment_type: str,
    amendment_number: str,
    *,
    client: Union[AuthenticatedClient, Client],
    format_: Union[
        Unset, GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat
    ] = GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
) -> Response[Union[Any, list["AmendmentActionsItem"]]]:
    """Returns the list of actions on a specified amendment.

     Returns the list of actions on a specified amendment.

    Args:
        congress (int):
        amendment_type (str):
        amendment_number (str):
        format_ (Union[Unset, GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat]):
            Default: GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat.XML.
        offset (Union[Unset, int]):
        limit (Union[Unset, int]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, list['AmendmentActionsItem']]]
    """

    kwargs = _get_kwargs(
        congress=congress,
        amendment_type=amendment_type,
        amendment_number=amendment_number,
        format_=format_,
        offset=offset,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    congress: int,
    amendment_type: str,
    amendment_number: str,
    *,
    client: Union[AuthenticatedClient, Client],
    format_: Union[
        Unset, GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat
    ] = GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
) -> Optional[Union[Any, list["AmendmentActionsItem"]]]:
    """Returns the list of actions on a specified amendment.

     Returns the list of actions on a specified amendment.

    Args:
        congress (int):
        amendment_type (str):
        amendment_number (str):
        format_ (Union[Unset, GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat]):
            Default: GetAmendmentCongressAmendmentTypeAmendmentNumberActionsFormat.XML.
        offset (Union[Unset, int]):
        limit (Union[Unset, int]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, list['AmendmentActionsItem']]
    """

    return (
        await asyncio_detailed(
            congress=congress,
            amendment_type=amendment_type,
            amendment_number=amendment_number,
            client=client,
            format_=format_,
            offset=offset,
            limit=limit,
        )
    ).parsed
