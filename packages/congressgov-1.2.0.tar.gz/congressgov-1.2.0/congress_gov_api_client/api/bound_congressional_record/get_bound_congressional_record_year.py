from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.bound_congressional_record import BoundCongressionalRecord
from ...models.get_bound_congressional_record_year_format import GetBoundCongressionalRecordYearFormat
from ...types import UNSET, Response, Unset


def _get_kwargs(
    year: int,
    *,
    format_: Union[Unset, GetBoundCongressionalRecordYearFormat] = GetBoundCongressionalRecordYearFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_format_: Union[Unset, str] = UNSET
    if not isinstance(format_, Unset):
        json_format_ = format_.value

    params["format"] = json_format_

    params["offset"] = offset

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/bound-congressional-record/{year}".format(
            year=year,
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Any, BoundCongressionalRecord]]:
    if response.status_code == 200:
        response_200 = BoundCongressionalRecord.from_dict(response.json())

        return response_200
    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Any, BoundCongressionalRecord]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    year: int,
    *,
    client: Union[AuthenticatedClient, Client],
    format_: Union[Unset, GetBoundCongressionalRecordYearFormat] = GetBoundCongressionalRecordYearFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
) -> Response[Union[Any, BoundCongressionalRecord]]:
    """Returns a list of bound congressional records issues sorted by most recent.

     Returns a list of bound congressional record issues sorted by most recent.

    Args:
        year (int):
        format_ (Union[Unset, GetBoundCongressionalRecordYearFormat]):  Default:
            GetBoundCongressionalRecordYearFormat.XML.
        offset (Union[Unset, int]):
        limit (Union[Unset, int]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, BoundCongressionalRecord]]
    """

    kwargs = _get_kwargs(
        year=year,
        format_=format_,
        offset=offset,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    year: int,
    *,
    client: Union[AuthenticatedClient, Client],
    format_: Union[Unset, GetBoundCongressionalRecordYearFormat] = GetBoundCongressionalRecordYearFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
) -> Optional[Union[Any, BoundCongressionalRecord]]:
    """Returns a list of bound congressional records issues sorted by most recent.

     Returns a list of bound congressional record issues sorted by most recent.

    Args:
        year (int):
        format_ (Union[Unset, GetBoundCongressionalRecordYearFormat]):  Default:
            GetBoundCongressionalRecordYearFormat.XML.
        offset (Union[Unset, int]):
        limit (Union[Unset, int]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, BoundCongressionalRecord]
    """

    return sync_detailed(
        year=year,
        client=client,
        format_=format_,
        offset=offset,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    year: int,
    *,
    client: Union[AuthenticatedClient, Client],
    format_: Union[Unset, GetBoundCongressionalRecordYearFormat] = GetBoundCongressionalRecordYearFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
) -> Response[Union[Any, BoundCongressionalRecord]]:
    """Returns a list of bound congressional records issues sorted by most recent.

     Returns a list of bound congressional record issues sorted by most recent.

    Args:
        year (int):
        format_ (Union[Unset, GetBoundCongressionalRecordYearFormat]):  Default:
            GetBoundCongressionalRecordYearFormat.XML.
        offset (Union[Unset, int]):
        limit (Union[Unset, int]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, BoundCongressionalRecord]]
    """

    kwargs = _get_kwargs(
        year=year,
        format_=format_,
        offset=offset,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    year: int,
    *,
    client: Union[AuthenticatedClient, Client],
    format_: Union[Unset, GetBoundCongressionalRecordYearFormat] = GetBoundCongressionalRecordYearFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
) -> Optional[Union[Any, BoundCongressionalRecord]]:
    """Returns a list of bound congressional records issues sorted by most recent.

     Returns a list of bound congressional record issues sorted by most recent.

    Args:
        year (int):
        format_ (Union[Unset, GetBoundCongressionalRecordYearFormat]):  Default:
            GetBoundCongressionalRecordYearFormat.XML.
        offset (Union[Unset, int]):
        limit (Union[Unset, int]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, BoundCongressionalRecord]
    """

    return (
        await asyncio_detailed(
            year=year,
            client=client,
            format_=format_,
            offset=offset,
            limit=limit,
        )
    ).parsed
