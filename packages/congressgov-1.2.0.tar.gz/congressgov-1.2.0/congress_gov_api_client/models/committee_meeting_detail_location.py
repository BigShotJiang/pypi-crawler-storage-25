from collections.abc import Mapping
from typing import Any, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CommitteeMeetingDetailLocation")


@_attrs_define
class CommitteeMeetingDetailLocation:
    """
    Attributes:
        building (Union[Unset, str]):  Example: Longworth House Office Building.
        room (Union[Unset, str]):  Example: 1234.
    """

    building: Union[Unset, str] = UNSET
    room: Union[Unset, str] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        building = self.building

        room = self.room

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if building is not UNSET:
            field_dict["building"] = building
        if room is not UNSET:
            field_dict["room"] = room

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        building = d.pop("building", UNSET)

        room = d.pop("room", UNSET)

        committee_meeting_detail_location = cls(
            building=building,
            room=room,
        )

        committee_meeting_detail_location.additional_properties = d
        return committee_meeting_detail_location

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
