"""Tests for the linter module."""
import pytest
from pathlib import Path

from agentlint.linter import lint

TESTS_DIR = Path(__file__).parent


def get_issue_codes(content: str) -> set[str]:
    return {i.rule for i in lint(content)}


class TestTooLong:
    def test_detects_long_file(self):
        content = "\n".join(["line"] * 85)
        assert "TOO_LONG" in get_issue_codes(content)

    def test_accepts_short_file(self):
        content = "\n".join(["line"] * 40)
        assert "TOO_LONG" not in get_issue_codes(content)

    def test_boundary_exactly_80(self):
        content = "\n".join(["line"] * 80)
        assert "TOO_LONG" not in get_issue_codes(content)

    def test_boundary_81_lines(self):
        content = "\n".join(["line"] * 81)
        assert "TOO_LONG" in get_issue_codes(content)


class TestTokenWaste:
    def test_detects_senior_engineer(self):
        content = "Act as a senior engineer and help me."
        assert "TOKEN_WASTE" in get_issue_codes(content)

    def test_detects_be_concise(self):
        content = "Be concise and helpful in your responses."
        assert "TOKEN_WASTE" in get_issue_codes(content)

    def test_detects_world_class(self):
        content = "You are a world-class developer."
        assert "TOKEN_WASTE" in get_issue_codes(content)

    def test_no_false_positive(self):
        content = "Use TypeScript for all new files.\nnpm test before committing."
        assert "TOKEN_WASTE" not in get_issue_codes(content)


class TestDuplicateRule:
    def test_detects_near_duplicates(self):
        content = (
            "Always write unit tests for every new function you add.\n"
            "Always write unit tests for every new function you create.\n"
        )
        assert "DUPLICATE_RULE" in get_issue_codes(content)

    def test_ignores_short_lines(self):
        content = "yes\nyes\nyes\n"
        assert "DUPLICATE_RULE" not in get_issue_codes(content)

    def test_no_false_positive_different_lines(self):
        content = "Use TypeScript for all files.\nRun tests before committing changes.\n"
        assert "DUPLICATE_RULE" not in get_issue_codes(content)


class TestContradiction:
    def test_detects_tabs_vs_spaces(self):
        content = "Use tabs for indentation.\nUse spaces for indentation.\n"
        assert "CONTRADICTION" in get_issue_codes(content)

    def test_detects_comments_contradiction(self):
        content = "Always add comments to functions.\nNo comments in code.\n"
        assert "CONTRADICTION" in get_issue_codes(content)

    def test_no_false_positive_unrelated(self):
        content = "Use TypeScript.\nRun tests often.\n"
        assert "CONTRADICTION" not in get_issue_codes(content)


class TestMissingCommands:
    def test_detects_missing(self):
        content = "Write good code and be helpful.\n"
        assert "MISSING_COMMANDS" in get_issue_codes(content)

    def test_detects_npm_test(self):
        content = "Run `npm test` before committing.\n"
        assert "MISSING_COMMANDS" not in get_issue_codes(content)

    def test_detects_pytest(self):
        content = "Run pytest to verify your changes.\n"
        assert "MISSING_COMMANDS" not in get_issue_codes(content)

    def test_detects_backtick_command(self):
        content = "Use `npm run build` to compile.\n"
        assert "MISSING_COMMANDS" not in get_issue_codes(content)


class TestMissingStack:
    def test_detects_missing(self):
        content = "Write good code.\n"
        assert "MISSING_STACK" in get_issue_codes(content)

    def test_detects_python(self):
        content = "This is a Python project using FastAPI.\n"
        assert "MISSING_STACK" not in get_issue_codes(content)

    def test_detects_typescript(self):
        content = "Language: TypeScript (Node 20)\n"
        assert "MISSING_STACK" not in get_issue_codes(content)


class TestAtMentionAbuse:
    def test_detects_many_mentions(self):
        content = (
            "Use @src/config.ts for settings.\n"
            "See @src/types.ts for types.\n"
            "Refer to @docs/guide.md for docs.\n"
        )
        assert "AT_MENTION_ABUSE" in get_issue_codes(content)

    def test_ok_with_few_mentions(self):
        content = "See @CLAUDE.md for instructions.\nUse TypeScript.\n"
        assert "AT_MENTION_ABUSE" not in get_issue_codes(content)


class TestNoVerifyStep:
    def test_detects_missing(self):
        content = "Write TypeScript code.\n"
        assert "NO_VERIFY_STEP" in get_issue_codes(content)

    def test_detects_run_test(self):
        content = "After changes, run tests to confirm they pass.\n"
        assert "NO_VERIFY_STEP" not in get_issue_codes(content)

    def test_detects_verify_keyword(self):
        content = "Verify your changes work before responding.\n"
        assert "NO_VERIFY_STEP" not in get_issue_codes(content)


class TestVagueInstruction:
    def test_detects_ensure(self):
        content = "Ensure code is readable and maintainable.\n"
        assert "VAGUE_INSTRUCTION" in get_issue_codes(content)

    def test_detects_make_sure(self):
        content = "Make sure to follow best practices.\n"
        assert "VAGUE_INSTRUCTION" in get_issue_codes(content)

    def test_detects_try_to(self):
        content = "Try to keep things simple.\n"
        assert "VAGUE_INSTRUCTION" in get_issue_codes(content)

    def test_no_false_positive_specific(self):
        content = "All functions must have TypeScript return types.\n"
        assert "VAGUE_INSTRUCTION" not in get_issue_codes(content)


class TestBloatDetected:
    def test_detects_many_numbered_items(self):
        lines = [f"{i}. Do thing number {i}" for i in range(1, 12)]
        content = "\n".join(lines)
        assert "BLOAT_DETECTED" in get_issue_codes(content)

    def test_ok_with_few_items(self):
        content = "1. Run tests\n2. Check build\n3. Commit\n"
        assert "BLOAT_DETECTED" not in get_issue_codes(content)


class TestMissingNever:
    def test_detects_missing(self):
        content = "Write TypeScript code. Run tests.\n"
        assert "MISSING_NEVER" in get_issue_codes(content)

    def test_detects_never_keyword(self):
        content = "Never delete files without confirmation.\n"
        assert "MISSING_NEVER" not in get_issue_codes(content)

    def test_detects_do_not(self):
        content = "Do not commit without running tests.\n"
        assert "MISSING_NEVER" not in get_issue_codes(content)


class TestSampleFiles:
    def test_bad_sample_triggers_many_rules(self):
        content = (TESTS_DIR / "sample_bad.md").read_text()
        issues = lint(content)
        codes = {i.rule for i in issues}
        # Should trigger at least 8 rules
        assert len(codes) >= 8, f"Only triggered: {codes}"

    def test_good_sample_has_few_issues(self):
        content = (TESTS_DIR / "sample_good.md").read_text()
        issues = lint(content)
        errors = [i for i in issues if i.severity.value == "error"]
        assert len(errors) == 0, f"Errors in good sample: {[i.rule for i in errors]}"
