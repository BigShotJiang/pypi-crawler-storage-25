"""Tests for the scorer module."""
import pytest
from pathlib import Path

from agentlint.scorer import score

TESTS_DIR = Path(__file__).parent


class TestScoreRange:
    def test_score_in_valid_range(self):
        content = "Write code.\n"
        breakdown = score(content)
        assert 0 <= breakdown.total <= 100

    def test_each_category_in_range(self):
        content = "Write code.\n"
        breakdown = score(content)
        assert 0 <= breakdown.length_density <= 25
        assert 0 <= breakdown.specificity <= 25
        assert 0 <= breakdown.structure <= 25
        assert 0 <= breakdown.completeness <= 25

    def test_total_equals_sum(self):
        content = "Write TypeScript. Run pytest.\n"
        breakdown = score(content)
        assert breakdown.total == (
            breakdown.length_density
            + breakdown.specificity
            + breakdown.structure
            + breakdown.completeness
        )


class TestGrades:
    def test_grade_a(self):
        breakdown = score.__wrapped__(90) if hasattr(score, '__wrapped__') else None
        # Test grade mapping directly
        from agentlint.scorer import ScoreBreakdown
        from agentlint.rules import LintIssue
        b = ScoreBreakdown(25, 25, 25, 15, 90, [])
        assert b.grade == "A"

    def test_grade_f(self):
        from agentlint.scorer import ScoreBreakdown
        b = ScoreBreakdown(5, 5, 5, 5, 20, [])
        assert b.grade == "F"

    def test_grade_labels(self):
        from agentlint.scorer import ScoreBreakdown
        assert ScoreBreakdown(25, 25, 25, 15, 90, []).grade_label == "Excellent"
        assert ScoreBreakdown(5, 5, 5, 5, 20, []).grade_label == "Critical Issues"


class TestCompleteness:
    def test_empty_file_low_completeness(self):
        content = "Some generic advice.\n"
        breakdown = score(content)
        assert breakdown.completeness < 10

    def test_complete_file_high_completeness(self):
        content = (
            "## Stack\nPython (FastAPI)\n\n"
            "## Commands\n`pytest` to run tests. `ruff` to lint.\n\n"
            "## Verify\nRun pytest and confirm all tests pass before responding done.\n\n"
            "## Never\nNever delete files without confirmation.\n"
        )
        breakdown = score(content)
        assert breakdown.completeness >= 20


class TestSampleFiles:
    def test_good_sample_scores_higher_than_bad(self):
        good = (TESTS_DIR / "sample_good.md").read_text()
        bad = (TESTS_DIR / "sample_bad.md").read_text()
        good_score = score(good).total
        bad_score = score(bad).total
        assert good_score > bad_score, (
            f"Good sample ({good_score}) should score higher than bad ({bad_score})"
        )

    def test_good_sample_score_above_60(self):
        content = (TESTS_DIR / "sample_good.md").read_text()
        breakdown = score(content)
        assert breakdown.total >= 60, f"Good sample scored only {breakdown.total}"

    def test_bad_sample_score_below_50(self):
        content = (TESTS_DIR / "sample_bad.md").read_text()
        breakdown = score(content)
        assert breakdown.total < 50, f"Bad sample scored too high: {breakdown.total}"
