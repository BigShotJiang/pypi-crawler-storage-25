# Project Instructions

## Stack

- Language: TypeScript (Node 20)
- Framework: Next.js 14 (App Router)
- Database: PostgreSQL via Prisma ORM
- Testing: Vitest + Playwright for E2E
- Styling: Tailwind CSS

## Commands

```bash
npm test           # run unit tests (Vitest)
npm run build      # TypeScript compile + Next.js build
npm run lint       # ESLint + Prettier check
npm run typecheck  # tsc --noEmit
```

## Code Rules

- All functions must have TypeScript return types
- Use `async/await`, never raw `.then()` chains
- No `any` types — use `unknown` and narrow
- Components go in `src/components/`, hooks in `src/hooks/`
- Database queries only in `src/server/` — never in components

## Never

- Never delete migration files
- Never commit with `console.log` statements left in
- Never bypass TypeScript errors with `@ts-ignore` without a comment explaining why
- Never expose environment variables to the client without the `NEXT_PUBLIC_` prefix

## Verification

After every change, run `npm test` and `npm run typecheck` and confirm both pass
before marking the task complete. If tests fail, fix them — do not skip.
