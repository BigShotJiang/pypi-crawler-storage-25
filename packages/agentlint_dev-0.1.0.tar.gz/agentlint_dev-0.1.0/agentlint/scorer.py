"""Scoring logic for agentlint. Returns a 0-100 score with category breakdown."""
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List

from .linter import COMMAND_PATTERNS, NEVER_PATTERNS, STACK_KEYWORDS, VERIFY_KEYWORDS, lint
from .rules import LintIssue, Severity


@dataclass
class ScoreBreakdown:
    length_density: int        # 25 pts
    specificity: int           # 25 pts
    structure: int             # 25 pts
    completeness: int          # 25 pts
    total: int
    issues: List[LintIssue]

    @property
    def grade(self) -> str:
        if self.total >= 90:
            return "A"
        elif self.total >= 80:
            return "B"
        elif self.total >= 70:
            return "C"
        elif self.total >= 60:
            return "D"
        else:
            return "F"

    @property
    def grade_label(self) -> str:
        grades = {
            "A": "Excellent",
            "B": "Good",
            "C": "Needs Work",
            "D": "Poor",
            "F": "Critical Issues",
        }
        return grades[self.grade]


def score(content: str, filepath: str = "CLAUDE.md") -> ScoreBreakdown:
    issues = lint(content, filepath)
    lines = content.splitlines()
    lower = content.lower()
    line_count = len(lines)

    issue_codes = {i.rule for i in issues}

    # ── Length & Density (25 pts) ─────────────────────────────────────────
    # Perfect score for 20-50 lines. Penalize over 80, reward under 80.
    if line_count <= 30:
        length_score = 25
    elif line_count <= 50:
        length_score = 22
    elif line_count <= 80:
        length_score = 18
    elif line_count <= 120:
        length_score = 12
    else:
        length_score = max(0, 25 - (line_count - 80) // 5)

    # Penalize token waste
    token_waste_count = sum(1 for i in issues if i.rule == "TOKEN_WASTE")
    length_score = max(0, length_score - token_waste_count * 3)

    # Penalize duplicates
    duplicate_count = sum(1 for i in issues if i.rule == "DUPLICATE_RULE")
    length_score = max(0, length_score - duplicate_count * 4)

    # Penalize instruction limit
    if "INSTRUCTION_LIMIT" in issue_codes:
        length_score = max(0, length_score - 8)

    length_score = min(25, length_score)

    # ── Specificity (25 pts) ──────────────────────────────────────────────
    specificity_score = 25

    # Penalize vague instructions
    vague_count = sum(1 for i in issues if i.rule == "VAGUE_INSTRUCTION")
    specificity_score -= vague_count * 4

    # Penalize contradictions
    contradiction_count = sum(1 for i in issues if i.rule == "CONTRADICTION")
    specificity_score -= contradiction_count * 6

    # Reward concrete commands
    command_count = sum(
        1 for pat in COMMAND_PATTERNS
        if re.search(pat, content, re.IGNORECASE)
    )
    specificity_score += min(5, command_count)

    # Penalize missing never rules
    if "MISSING_NEVER" in issue_codes:
        specificity_score -= 5

    specificity_score = max(0, min(25, specificity_score))

    # ── Structure (25 pts) ────────────────────────────────────────────────
    structure_score = 0

    # Has headers
    headers = [l for l in lines if re.match(r"^#{1,3}\s", l)]
    if len(headers) >= 2:
        structure_score += 10
    elif len(headers) == 1:
        structure_score += 5

    # Has bullet lists
    bullets = [l for l in lines if re.match(r"^\s*[-*•]\s", l)]
    if len(bullets) >= 3:
        structure_score += 8
    elif len(bullets) >= 1:
        structure_score += 4

    # Has code blocks
    code_blocks = content.count("```")
    if code_blocks >= 2:
        structure_score += 7
    elif code_blocks >= 1:
        structure_score += 3

    # Penalize bloat
    if "BLOAT_DETECTED" in issue_codes:
        structure_score -= 5

    # Penalize excessive @mentions
    if "AT_MENTION_ABUSE" in issue_codes:
        structure_score -= 3

    structure_score = max(0, min(25, structure_score))

    # ── Completeness (25 pts) ─────────────────────────────────────────────
    completeness_score = 0

    # Has stack info
    if any(re.search(r"\b" + re.escape(kw) + r"\b", lower) for kw in STACK_KEYWORDS):
        completeness_score += 7

    # Has commands
    has_commands = any(re.search(pat, content, re.IGNORECASE) for pat in COMMAND_PATTERNS)
    if has_commands:
        completeness_score += 7

    # Has verify step
    has_verify = any(kw in lower for kw in VERIFY_KEYWORDS)
    if has_verify:
        completeness_score += 6

    # Has never rules
    has_never = any(re.search(pat, content, re.IGNORECASE) for pat in NEVER_PATTERNS)
    if has_never:
        completeness_score += 5

    completeness_score = max(0, min(25, completeness_score))

    total = length_score + specificity_score + structure_score + completeness_score

    return ScoreBreakdown(
        length_density=length_score,
        specificity=specificity_score,
        structure=structure_score,
        completeness=completeness_score,
        total=total,
        issues=issues,
    )


def score_file(path: Path) -> ScoreBreakdown:
    content = path.read_text(encoding="utf-8")
    return score(content, str(path))
