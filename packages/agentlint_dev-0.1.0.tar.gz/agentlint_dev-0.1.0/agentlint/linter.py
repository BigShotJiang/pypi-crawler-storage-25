"""Core lint rules for agentlint."""
import re
from difflib import SequenceMatcher
from pathlib import Path
from typing import List

from .rules import RULES, LintIssue, RuleDefinition, Severity


# Phrases that waste tokens by instructing personality/style
TOKEN_WASTE_PATTERNS = [
    r"act as (a |an )?(senior|expert|experienced|professional|world.?class)",
    r"you are (a |an )?(senior|expert|experienced|professional|world.?class)",
    r"be (concise|helpful|friendly|professional|thorough|careful|creative|brilliant)",
    r"always be (polite|respectful|kind|helpful)",
    r"write (clean|good|high.?quality|beautiful|elegant|readable) code",
    r"think (step.?by.?step|carefully|deeply|like a developer)",
    r"you('re| are) an? (AI|assistant|coding assistant|pair programmer)",
    r"be (a |an )?(expert|genius|ninja|rockstar|guru)",
]

# Vague instruction patterns
VAGUE_PATTERNS = [
    r"^(always |never )?(ensure|make sure|try to|attempt to|strive to)\b",
    r"^(be |stay |remain )?(consistent|clear|simple|clean|readable)\b",
    r"^follow (best practices?|good practices?|industry standards?)\b",
    r"^write (good|clean|quality|proper|correct) (code|tests|docs)\b",
    r"^(keep|maintain) (things|code|everything) (simple|clean|organized)\b",
    r"^(use|follow) (proper|correct|appropriate) (naming|conventions|patterns)\b",
]

# Verification keywords
VERIFY_KEYWORDS = [
    "verify", "run test", "run the test", "check that", "confirm",
    "make sure it works", "validate", "npm test", "pytest", "cargo test",
    "before responding", "before saying done", "before marking complete",
]

# Stack/language indicators
STACK_KEYWORDS = [
    "python", "javascript", "typescript", "rust", "go", "golang",
    "java", "kotlin", "swift", "ruby", "php", "c#", "dotnet", ".net",
    "react", "vue", "angular", "next.js", "nextjs", "nuxt", "svelte",
    "django", "flask", "fastapi", "express", "fastify", "rails",
    "node", "deno", "bun", "postgres", "mysql", "sqlite", "mongodb",
    "docker", "kubernetes", "aws", "gcp", "azure",
]

# Command indicators
COMMAND_PATTERNS = [
    r"`[^`]*(test|build|lint|run|check|format)[^`]*`",
    r"npm (run |exec )?(test|build|lint|start|dev)",
    r"yarn (test|build|lint|start|dev)",
    r"pnpm (test|build|lint|start|dev)",
    r"pytest|python -m pytest",
    r"cargo (test|build|check|clippy)",
    r"go (test|build|vet|lint)",
    r"make (test|build|lint|check)",
    r"\.\/gradlew|mvn (test|package|compile)",
    r"ruff|flake8|mypy|black|isort",
    r"eslint|prettier|tsc --",
]

# Never/prohibition indicators
NEVER_PATTERNS = [
    r"\bnever\b",
    r"\bdo not\b",
    r"\bdon't\b",
    r"\bprohibit",
    r"\bforbid",
    r"\bavoid\b",
    r"\bdo NOT\b",
]

# Bloat indicators (long step-by-step procedures)
BLOAT_SECTION_PATTERNS = [
    r"step \d+",
    r"^\d+\.\s",  # numbered list items
    r"first,.*then,.*finally",
    r"(procedure|workflow|process|guide|tutorial):",
]


def _similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def lint(content: str, filepath: str = "CLAUDE.md") -> List[LintIssue]:
    issues: List[LintIssue] = []
    lines = content.splitlines()
    lower = content.lower()

    # TOO_LONG
    if len(lines) > 80:
        rule = RULES["TOO_LONG"]
        issues.append(LintIssue(
            rule="TOO_LONG",
            severity=rule.severity,
            title=rule.title,
            message=f"File has {len(lines)} lines (limit: 80). Claude deprioritizes instructions in long files.",
            fix=rule.fix,
            line=80,
        ))

    # TOKEN_WASTE
    for i, line in enumerate(lines, 1):
        for pattern in TOKEN_WASTE_PATTERNS:
            if re.search(pattern, line, re.IGNORECASE):
                rule = RULES["TOKEN_WASTE"]
                issues.append(LintIssue(
                    rule="TOKEN_WASTE",
                    severity=rule.severity,
                    title=rule.title,
                    message=f"Line {i}: \"{line.strip()}\" — personality/style instruction wastes tokens.",
                    fix=rule.fix,
                    line=i,
                ))
                break

    # DUPLICATE_RULE — find near-duplicate non-empty lines
    seen: list[tuple[int, str]] = []
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if len(stripped) < 20:
            continue
        for j, prev in seen:
            if _similarity(stripped, prev) > 0.82:
                rule = RULES["DUPLICATE_RULE"]
                issues.append(LintIssue(
                    rule="DUPLICATE_RULE",
                    severity=rule.severity,
                    title=rule.title,
                    message=f"Line {i} is nearly identical to line {j}.",
                    fix=rule.fix,
                    lines=[j, i],
                ))
                break
        else:
            seen.append((i, stripped))

    # CONTRADICTION — detect common opposing pairs
    contradiction_pairs = [
        (r"\buse tabs\b", r"\buse spaces\b"),
        (r"\buse spaces\b", r"\buse tabs\b"),
        (r"\bno comments?\b", r"\badd comments?\b"),
        (r"\badd comments?\b", r"\bno comments?\b"),
        (r"\bwrite tests?\b", r"\bno tests?\b"),
        (r"\bno tests?\b", r"\bwrite tests?\b"),
        (r"\buse (async|await)\b", r"\bavoid (async|await)\b"),
        (r"\bavoid (async|await)\b", r"\buse (async|await)\b"),
        (r"\bshort functions?\b", r"\blong functions?\b"),
        (r"\blong functions?\b", r"\bshort functions?\b"),
        (r"\bnever use (any|inline)\b", r"\balways use (any|inline)\b"),
        (r"\balways use (any|inline)\b", r"\bnever use (any|inline)\b"),
        (r"\bprefer (classes?|OOP)\b", r"\bprefer (functions?|functional)\b"),
        (r"\bprefer (functions?|functional)\b", r"\bprefer (classes?|OOP)\b"),
    ]
    found_contradictions: set[str] = set()
    for pat_a, pat_b in contradiction_pairs:
        matches_a = [(i + 1, l) for i, l in enumerate(lines) if re.search(pat_a, l, re.IGNORECASE)]
        matches_b = [(i + 1, l) for i, l in enumerate(lines) if re.search(pat_b, l, re.IGNORECASE)]
        if matches_a and matches_b:
            key = tuple(sorted([pat_a, pat_b]))
            if key not in found_contradictions:
                found_contradictions.add(key)
                rule = RULES["CONTRADICTION"]
                line_nums_a = [x[0] for x in matches_a]
                line_nums_b = [x[0] for x in matches_b]
                same_line = set(line_nums_a) & set(line_nums_b)
                if same_line:
                    loc = f"line {next(iter(same_line))} (within the same line)"
                elif line_nums_a == line_nums_b:
                    loc = f"line(s) {line_nums_a}"
                else:
                    loc = f"line(s) {line_nums_a} vs line(s) {line_nums_b}"
                snippet_a = matches_a[0][1].strip()
                snippet_b = matches_b[0][1].strip() if matches_b[0][1] != matches_a[0][1] else None
                detail = f"\"{snippet_a}\""
                if snippet_b:
                    detail += f" conflicts with \"{snippet_b}\""
                issues.append(LintIssue(
                    rule="CONTRADICTION",
                    severity=rule.severity,
                    title=rule.title,
                    message=f"Contradiction on {loc}: {detail}",
                    fix=rule.fix,
                    lines=line_nums_a + line_nums_b,
                ))

    # MISSING_COMMANDS
    has_commands = any(
        re.search(pat, content, re.IGNORECASE) for pat in COMMAND_PATTERNS
    )
    if not has_commands:
        rule = RULES["MISSING_COMMANDS"]
        issues.append(LintIssue(
            rule="MISSING_COMMANDS",
            severity=rule.severity,
            title=rule.title,
            message="No shell commands (test/build/lint) found. The agent won't know how to verify its work.",
            fix=rule.fix,
        ))

    # MISSING_STACK
    has_stack = any(
        re.search(r"\b" + re.escape(kw) + r"\b", lower) for kw in STACK_KEYWORDS
    )
    if not has_stack:
        rule = RULES["MISSING_STACK"]
        issues.append(LintIssue(
            rule="MISSING_STACK",
            severity=rule.severity,
            title=rule.title,
            message="No technology stack mentioned. The agent may make incorrect toolchain assumptions.",
            fix=rule.fix,
        ))

    # AT_MENTION_ABUSE — count @file references
    at_mentions = re.findall(r"@\w[\w/\.\-]+", content)
    if len(at_mentions) >= 3:
        rule = RULES["AT_MENTION_ABUSE"]
        issues.append(LintIssue(
            rule="AT_MENTION_ABUSE",
            severity=rule.severity,
            title=rule.title,
            message=f"{len(at_mentions)} @file references found: {', '.join(at_mentions[:5])}. These embed entire files every session.",
            fix=rule.fix,
        ))

    # NO_VERIFY_STEP
    has_verify = any(kw in lower for kw in VERIFY_KEYWORDS)
    if not has_verify:
        rule = RULES["NO_VERIFY_STEP"]
        issues.append(LintIssue(
            rule="NO_VERIFY_STEP",
            severity=rule.severity,
            title=rule.title,
            message="No verification instructions found. The agent won't know to run tests before declaring success.",
            fix=rule.fix,
        ))

    # VAGUE_INSTRUCTION
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        for pattern in VAGUE_PATTERNS:
            if re.search(pattern, stripped, re.IGNORECASE):
                rule = RULES["VAGUE_INSTRUCTION"]
                issues.append(LintIssue(
                    rule="VAGUE_INSTRUCTION",
                    severity=rule.severity,
                    title=rule.title,
                    message=f"Line {i}: \"{stripped}\" — too vague to be reliably actionable.",
                    fix=rule.fix,
                    line=i,
                ))
                break

    # BLOAT_DETECTED — look for long numbered/stepped procedure blocks
    numbered_lines = sum(1 for l in lines if re.match(r"^\s*\d+\.\s", l))
    step_lines = sum(1 for l in lines if re.search(r"\bstep \d+\b", l, re.IGNORECASE))
    if numbered_lines >= 8 or step_lines >= 4:
        rule = RULES["BLOAT_DETECTED"]
        issues.append(LintIssue(
            rule="BLOAT_DETECTED",
            severity=rule.severity,
            title=rule.title,
            message=f"Found {numbered_lines} numbered list items and {step_lines} 'step N' references. Lengthy procedures should be extracted to skill files.",
            fix=rule.fix,
        ))

    # MISSING_NEVER
    has_never = any(re.search(pat, content, re.IGNORECASE) for pat in NEVER_PATTERNS)
    if not has_never:
        rule = RULES["MISSING_NEVER"]
        issues.append(LintIssue(
            rule="MISSING_NEVER",
            severity=rule.severity,
            title=rule.title,
            message="No prohibition rules ('never', 'do not', 'avoid') found. Negative constraints are highly effective.",
            fix=rule.fix,
        ))

    # INSTRUCTION_LIMIT — rough estimate: bullet points + numbered items + short lines
    instruction_count = sum(
        1 for l in lines
        if re.match(r"^\s*[-*•]\s", l) or re.match(r"^\s*\d+\.\s", l)
    )
    # Also count non-empty, non-header lines as potential instructions
    prose_instructions = sum(
        1 for l in lines
        if l.strip() and not l.strip().startswith("#") and not re.match(r"^\s*[-*•\d]", l)
    )
    total_estimated = instruction_count + (prose_instructions // 3)
    if total_estimated > 150:
        rule = RULES["INSTRUCTION_LIMIT"]
        issues.append(LintIssue(
            rule="INSTRUCTION_LIMIT",
            severity=rule.severity,
            title=rule.title,
            message=f"Estimated ~{total_estimated} instructions (limit: 150). Models lose track of instructions in very long configs.",
            fix=rule.fix,
        ))

    return issues


def lint_file(path: Path) -> List[LintIssue]:
    content = path.read_text(encoding="utf-8")
    return lint(content, str(path))
