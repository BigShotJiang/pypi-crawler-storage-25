"""Rule definitions, codes, severities, and messages for agentlint."""
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional


class Severity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class RuleDefinition:
    code: str
    severity: Severity
    title: str
    description: str
    fix: str


@dataclass
class LintIssue:
    rule: str
    severity: Severity
    title: str
    message: str
    fix: str
    line: Optional[int] = None
    lines: Optional[List[int]] = None


RULES: dict[str, RuleDefinition] = {
    "TOO_LONG": RuleDefinition(
        code="TOO_LONG",
        severity=Severity.ERROR,
        title="File too long",
        description="File exceeds 80 lines. Frontier models start deprioritizing instructions in long files.",
        fix="Trim to under 80 lines. Move detailed how-to guides into separate skill files or commands.",
    ),
    "TOKEN_WASTE": RuleDefinition(
        code="TOKEN_WASTE",
        severity=Severity.WARNING,
        title="Token-wasting instruction",
        description="Personality or style instructions waste tokens and have little effect on model behavior.",
        fix="Remove lines like 'act as a senior engineer' or 'be concise'. Use linters/formatters for style.",
    ),
    "DUPLICATE_RULE": RuleDefinition(
        code="DUPLICATE_RULE",
        severity=Severity.WARNING,
        title="Duplicate instruction",
        description="The same instruction (or near-duplicate) appears more than once.",
        fix="Keep only one copy of each instruction. Repetition wastes tokens and doesn't reinforce behavior.",
    ),
    "CONTRADICTION": RuleDefinition(
        code="CONTRADICTION",
        severity=Severity.ERROR,
        title="Contradicting instructions",
        description="Two instructions directly contradict each other, causing unpredictable model behavior.",
        fix="Remove or reconcile the conflicting instructions. Decide on one clear rule.",
    ),
    "MISSING_COMMANDS": RuleDefinition(
        code="MISSING_COMMANDS",
        severity=Severity.ERROR,
        title="No commands defined",
        description="No shell commands (test, build, lint) are defined. The agent won't know how to verify its work.",
        fix="Add a Commands section with at minimum: test, build, and lint commands for your stack.",
    ),
    "MISSING_STACK": RuleDefinition(
        code="MISSING_STACK",
        severity=Severity.ERROR,
        title="No tech stack defined",
        description="The technology stack is not mentioned. The agent may make incorrect toolchain assumptions.",
        fix="Add a section listing your language, framework, and key libraries.",
    ),
    "AT_MENTION_ABUSE": RuleDefinition(
        code="AT_MENTION_ABUSE",
        severity=Severity.WARNING,
        title="Excessive @file references",
        description="@file references embed entire files into every session, bloating context unnecessarily.",
        fix="Only @mention files the agent needs every session. Move rarely-needed context to comments or docs.",
    ),
    "NO_VERIFY_STEP": RuleDefinition(
        code="NO_VERIFY_STEP",
        severity=Severity.ERROR,
        title="No verification instructions",
        description="No instructions tell the agent how to verify its changes actually work.",
        fix="Add a Verify section: 'After changes, run tests and confirm they pass before responding done.'",
    ),
    "VAGUE_INSTRUCTION": RuleDefinition(
        code="VAGUE_INSTRUCTION",
        severity=Severity.WARNING,
        title="Vague instruction",
        description="Instruction is too vague to be reliably actionable by a model.",
        fix="Replace with concrete, specific rules. E.g. instead of 'write good code', say 'functions must have type annotations'.",
    ),
    "BLOAT_DETECTED": RuleDefinition(
        code="BLOAT_DETECTED",
        severity=Severity.WARNING,
        title="Content bloat detected",
        description="File contains content that belongs in a reusable skill/command, not in the base config.",
        fix="Extract repeated multi-step procedures into /commands or skill files. Reference them instead.",
    ),
    "MISSING_NEVER": RuleDefinition(
        code="MISSING_NEVER",
        severity=Severity.WARNING,
        title="No 'never do X' rules",
        description="No explicit prohibitions defined. Agents benefit greatly from clear negative constraints.",
        fix="Add a 'Never' section listing things the agent must never do (e.g. 'never delete files without confirmation').",
    ),
    "INSTRUCTION_LIMIT": RuleDefinition(
        code="INSTRUCTION_LIMIT",
        severity=Severity.WARNING,
        title="Too many instructions",
        description="Estimated instruction count exceeds ~150. Models struggle to reliably follow all of them.",
        fix="Consolidate related rules, remove redundant ones, and trim to the most impactful 50-100 instructions.",
    ),
}
