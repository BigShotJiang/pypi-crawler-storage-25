"""agentlint — lint, score, and optimize AI agent configuration files."""

__version__ = "0.1.0"
__author__ = "agentlint"
