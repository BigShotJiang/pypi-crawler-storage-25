"""CLI entry point for agentlint."""
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console

from .linter import lint_file
from .optimizer import optimize as _optimize_content, optimize_file
from .output import (
    console,
    print_diff,
    print_header,
    print_issues,
    print_scan_results,
    print_score,
    print_summary,
)
from .scorer import score, score_file

# Config file names to look for during scan
CONFIG_PATTERNS = [
    "CLAUDE.md",
    "AGENTS.md",
    ".cursorrules",
    ".cursor/rules/*.md",
    ".github/copilot-instructions.md",
    "CODEBASE_CONTEXT.md",
    "CONTEXT.md",
    "AI_INSTRUCTIONS.md",
]


def _find_config_files(directory: Path) -> list[Path]:
    found = []
    for pattern in CONFIG_PATTERNS:
        if "*" in pattern:
            found.extend(directory.rglob(pattern.lstrip("./")))
        else:
            candidate = directory / pattern
            if candidate.exists():
                found.append(candidate)
    # Also rglob for CLAUDE.md and AGENTS.md in subdirs
    for name in ("CLAUDE.md", "AGENTS.md"):
        for p in directory.rglob(name):
            if p not in found:
                found.append(p)
    return sorted(set(found))


def _resolve_path(filepath: str) -> Path:
    path = Path(filepath)
    if not path.exists():
        console.print(f"[bold red]Error:[/bold red] File not found: {filepath}")
        sys.exit(1)
    if not path.is_file():
        console.print(f"[bold red]Error:[/bold red] Not a file: {filepath}")
        sys.exit(1)
    return path


@click.group()
@click.version_option(package_name="agentlint")
def cli() -> None:
    """agentlint — lint, score, and optimize your AI agent config files."""


@cli.command()
@click.argument("filepath", default="CLAUDE.md")
@click.option("--no-fix", is_flag=True, help="Hide fix suggestions.")
def lint(filepath: str, no_fix: bool) -> None:
    """Lint a config file and report issues."""
    path = _resolve_path(filepath)
    print_header(str(path))
    issues = lint_file(path)
    print_issues(issues, show_fixes=not no_fix)
    print_summary(issues, str(path))
    sys.exit(1 if any(i.severity.value == "error" for i in issues) else 0)


@cli.command()
@click.argument("filepath", default="CLAUDE.md")
def score(filepath: str) -> None:
    """Score a config file from 0-100 with a breakdown."""
    path = _resolve_path(filepath)
    breakdown = score_file(path)
    print_score(breakdown, str(path))

    if breakdown.issues:
        console.print("[dim]Top issues:[/dim]")
        print_issues(breakdown.issues[:5], show_fixes=True)


@cli.command()
@click.argument("filepath", default="CLAUDE.md")
@click.option("--output", "-o", default=None, help="Output file path (default: <name>.optimized.md).")
@click.option("--stdout", is_flag=True, help="Print result to stdout instead of saving.")
@click.option("--ai", is_flag=True, help="Use Claude API for smarter suggestions (requires ANTHROPIC_API_KEY).")
def optimize(filepath: str, output: Optional[str], stdout: bool, ai: bool) -> None:
    """Generate an optimized version of the config file."""
    path = _resolve_path(filepath)

    if ai:
        _optimize_with_ai(path)
        return

    print_header(str(path))

    if stdout:
        content = path.read_text(encoding="utf-8")
        result = _optimize_content(content, str(path))
        console.print(result)
        return

    out_path = Path(output) if output else None
    saved = optimize_file(path, out_path)
    console.print(f"[bold green]✅ Optimized file saved to:[/bold green] [cyan]{saved}[/cyan]")

    # Show quick score comparison
    original_content = path.read_text(encoding="utf-8")
    optimized_content = saved.read_text(encoding="utf-8")
    from .scorer import score as _score
    before = _score(original_content, str(path))
    after = _score(optimized_content, str(saved))
    delta = after.total - before.total
    sign = "+" if delta >= 0 else ""
    console.print(
        f"  Score: [yellow]{before.total}[/yellow] → [green]{after.total}[/green]  "
        f"([{'green' if delta >= 0 else 'red'}]{sign}{delta}[/{'green' if delta >= 0 else 'red'}] pts)"
    )


@cli.command()
@click.argument("filepath", default="CLAUDE.md")
def diff(filepath: str) -> None:
    """Show a diff of what optimize would change."""
    path = _resolve_path(filepath)
    print_header(str(path))
    content = path.read_text(encoding="utf-8")
    from .optimizer import optimize as _optimize
    optimized = _optimize(content, str(path))
    print_diff(content, optimized)


@cli.command()
@click.argument("directory", default=".")
def scan(directory: str) -> None:
    """Scan a directory for all agent config files and report issues."""
    dir_path = Path(directory)
    if not dir_path.is_dir():
        console.print(f"[bold red]Error:[/bold red] Not a directory: {directory}")
        sys.exit(1)

    console.print(f"\n[bold cyan]Scanning[/bold cyan] [dim]{dir_path.resolve()}[/dim]...\n")
    files = _find_config_files(dir_path)

    if not files:
        console.print("[yellow]No agent config files found.[/yellow]")
        console.print("[dim]Looking for: CLAUDE.md, AGENTS.md, .cursorrules, and more.[/dim]")
        return

    results = []
    for f in files:
        issues = lint_file(f)
        results.append((f, issues))

    print_scan_results(results)

    total_errors = sum(
        sum(1 for i in issues if i.severity.value == "error")
        for _, issues in results
    )
    sys.exit(1 if total_errors > 0 else 0)


def _optimize_with_ai(path: Path) -> None:
    """Use Claude API for AI-powered optimization."""
    import os
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        console.print("[bold red]Error:[/bold red] ANTHROPIC_API_KEY environment variable not set.")
        sys.exit(1)

    try:
        import anthropic
    except ImportError:
        console.print("[bold red]Error:[/bold red] anthropic package not installed. Run: pip install anthropic")
        sys.exit(1)

    content = path.read_text(encoding="utf-8")
    issues = lint_file(path)
    issue_summary = "\n".join(f"- {i.rule}: {i.message}" for i in issues)

    console.print(f"[bold cyan]Optimizing {path} with Claude AI...[/bold cyan]")

    client = anthropic.Anthropic(api_key=api_key)
    prompt = f"""You are an expert at optimizing AI agent configuration files (CLAUDE.md, AGENTS.md).

Here is the current file content:
<file>
{content}
</file>

Lint issues found:
{issue_summary}

Please rewrite this file to fix all lint issues while preserving the intent.
Output ONLY the improved file content, no explanation."""

    message = client.messages.create(
        model="claude-opus-4-6",
        max_tokens=4096,
        messages=[{"role": "user", "content": prompt}],
    )

    optimized = message.content[0].text
    out_path = path.parent / f"{path.stem}.optimized{path.suffix}"
    out_path.write_text(optimized, encoding="utf-8")
    console.print(f"[bold green]✅ AI-optimized file saved to:[/bold green] [cyan]{out_path}[/cyan]")
