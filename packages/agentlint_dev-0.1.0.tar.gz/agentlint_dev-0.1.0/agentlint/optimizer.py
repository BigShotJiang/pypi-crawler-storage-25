"""Optimization suggestions and improved file generation."""
import re
from pathlib import Path
from typing import List, Optional

from .linter import COMMAND_PATTERNS, NEVER_PATTERNS, STACK_KEYWORDS, VERIFY_KEYWORDS, lint
from .rules import LintIssue


# Sections to inject when missing
COMMANDS_TEMPLATE = """
## Commands

```bash
# Add your project commands here — examples:
npm test          # run tests
npm run build     # build the project
npm run lint      # lint source files
```
"""

VERIFY_TEMPLATE = """
## Verification

After making changes, always run the test suite and confirm it passes before
responding that the task is complete. Do not mark work as done if tests fail.
"""

NEVER_TEMPLATE = """
## Never

- Never delete files or directories without explicit user confirmation
- Never commit changes without running tests first
- Never modify files outside the scope of the current task
- Never expose secrets, tokens, or credentials in code or logs
"""

STACK_TEMPLATE = """
## Stack

<!-- TODO: describe your technology stack here, e.g.:
- Language: TypeScript (Node 20)
- Framework: Next.js 14
- Database: PostgreSQL via Prisma
- Testing: Vitest + Playwright
-->
"""


def _remove_token_waste(lines: List[str]) -> List[str]:
    from .linter import TOKEN_WASTE_PATTERNS
    cleaned = []
    for line in lines:
        waste = any(re.search(pat, line, re.IGNORECASE) for pat in TOKEN_WASTE_PATTERNS)
        if not waste:
            cleaned.append(line)
    return cleaned


def _deduplicate(lines: List[str]) -> List[str]:
    from difflib import SequenceMatcher
    seen: List[str] = []
    result: List[str] = []
    for line in lines:
        stripped = line.strip()
        if len(stripped) < 20:
            result.append(line)
            continue
        is_dup = any(
            SequenceMatcher(None, stripped.lower(), s.lower()).ratio() > 0.82
            for s in seen
        )
        if not is_dup:
            result.append(line)
            seen.append(stripped)
    return result


def _remove_vague(lines: List[str]) -> List[str]:
    from .linter import VAGUE_PATTERNS
    cleaned = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#"):
            cleaned.append(line)
            continue
        vague = any(re.search(pat, stripped, re.IGNORECASE) for pat in VAGUE_PATTERNS)
        if vague:
            cleaned.append(f"<!-- REMOVED (vague): {line.rstrip()} -->")
        else:
            cleaned.append(line)
    return cleaned


def optimize(content: str, filepath: str = "CLAUDE.md") -> str:
    """Return an optimized version of the config content."""
    issues = lint(content, filepath)
    issue_codes = {i.rule for i in issues}

    lines = content.splitlines(keepends=True)
    text_lines = [l.rstrip("\n") for l in lines]
    lower = content.lower()

    # Apply fixes in order (least destructive first)

    # 1. Remove token waste lines
    if any(i.rule == "TOKEN_WASTE" for i in issues):
        text_lines = _remove_token_waste(text_lines)

    # 2. Remove vague instructions
    if any(i.rule == "VAGUE_INSTRUCTION" for i in issues):
        text_lines = _remove_vague(text_lines)

    # 3. Deduplicate
    if any(i.rule == "DUPLICATE_RULE" for i in issues):
        text_lines = _deduplicate(text_lines)

    # 4. Trim to 80 lines if still too long (after cleanup)
    if len(text_lines) > 80 and "TOO_LONG" in issue_codes:
        text_lines = text_lines[:80]
        text_lines.append("")
        text_lines.append("<!-- NOTE: File truncated at 80 lines by agentlint. Move remaining content to skill files. -->")

    result = "\n".join(text_lines)

    # 5. Inject missing sections at the end
    additions = []

    if "MISSING_STACK" in issue_codes:
        additions.append(STACK_TEMPLATE)

    if "MISSING_COMMANDS" in issue_codes:
        additions.append(COMMANDS_TEMPLATE)

    if "NO_VERIFY_STEP" in issue_codes:
        additions.append(VERIFY_TEMPLATE)

    if "MISSING_NEVER" in issue_codes:
        additions.append(NEVER_TEMPLATE)

    if additions:
        result = result.rstrip() + "\n\n---\n<!-- Added by agentlint optimize -->\n"
        result += "\n".join(additions)

    return result


def optimize_file(path: Path, output_path: Optional[Path] = None) -> Path:
    content = path.read_text(encoding="utf-8")
    optimized = optimize(content, str(path))

    if output_path is None:
        stem = path.stem
        suffix = path.suffix
        output_path = path.parent / f"{stem}.optimized{suffix}"

    output_path.write_text(optimized, encoding="utf-8")
    return output_path
