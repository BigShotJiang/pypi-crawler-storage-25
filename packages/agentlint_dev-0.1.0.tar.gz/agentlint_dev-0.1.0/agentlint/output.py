"""Rich terminal output helpers for agentlint."""
from pathlib import Path
from typing import List

from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, TextColumn
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from .rules import LintIssue, Severity
from .scorer import ScoreBreakdown

console = Console()

SEVERITY_STYLE = {
    Severity.ERROR: ("red", "❌"),
    Severity.WARNING: ("yellow", "⚠️ "),
    Severity.INFO: ("blue", "ℹ️ "),
}


def print_header(filepath: str) -> None:
    console.print()
    console.rule(f"[bold cyan]agentlint[/bold cyan] · [dim]{filepath}[/dim]")
    console.print()


def print_issues(issues: List[LintIssue], show_fixes: bool = True) -> None:
    if not issues:
        console.print("[bold green]✅ No issues found![/bold green]")
        return

    errors = [i for i in issues if i.severity == Severity.ERROR]
    warnings = [i for i in issues if i.severity == Severity.WARNING]
    infos = [i for i in issues if i.severity == Severity.INFO]

    for group, label in [(errors, "Errors"), (warnings, "Warnings"), (infos, "Info")]:
        if not group:
            continue
        console.print(f"[bold]{label}[/bold]")
        for issue in group:
            style, emoji = SEVERITY_STYLE[issue.severity]
            console.print(
                f"  {emoji} [bold {style}]{issue.rule}[/bold {style}]  "
                f"[white]{issue.title}[/white]"
            )
            console.print(f"     [dim]{issue.message}[/dim]")
            if show_fixes:
                console.print(f"     [green]Fix:[/green] [dim]{issue.fix}[/dim]")
            console.print()


def print_summary(issues: List[LintIssue], filepath: str) -> None:
    errors = sum(1 for i in issues if i.severity == Severity.ERROR)
    warnings = sum(1 for i in issues if i.severity == Severity.WARNING)

    if not issues:
        console.print(Panel(
            "[bold green]✅  Perfect! No issues detected.[/bold green]",
            border_style="green",
        ))
    else:
        parts = []
        if errors:
            parts.append(f"[bold red]{errors} error{'s' if errors != 1 else ''}[/bold red]")
        if warnings:
            parts.append(f"[bold yellow]{warnings} warning{'s' if warnings != 1 else ''}[/bold yellow]")
        console.print(Panel(
            "  ".join(parts) + f"  in [cyan]{filepath}[/cyan]",
            border_style="red" if errors else "yellow",
        ))


def print_score(breakdown: ScoreBreakdown, filepath: str) -> None:
    console.print()

    # Grade badge
    grade_colors = {"A": "green", "B": "cyan", "C": "yellow", "D": "red", "F": "bold red"}
    color = grade_colors.get(breakdown.grade, "white")
    grade_text = Text(f" {breakdown.grade} ", style=f"bold {color} on default")

    console.print(Panel(
        f"[bold]Score: [bold {color}]{breakdown.total}/100[/bold {color}]  "
        f"Grade: [{color}]{breakdown.grade}[/{color}] — [{color}]{breakdown.grade_label}[/{color}][/bold]",
        title=f"[bold cyan]{filepath}[/bold cyan]",
        border_style=color,
    ))

    # Score bar
    console.print()
    _print_score_bar("Length & Density", breakdown.length_density, 25)
    _print_score_bar("Specificity      ", breakdown.specificity, 25)
    _print_score_bar("Structure        ", breakdown.structure, 25)
    _print_score_bar("Completeness     ", breakdown.completeness, 25)
    console.print()


def _print_score_bar(label: str, value: int, max_val: int) -> None:
    pct = value / max_val
    filled = int(pct * 20)
    empty = 20 - filled

    if pct >= 0.8:
        color = "green"
    elif pct >= 0.5:
        color = "yellow"
    else:
        color = "red"

    bar = f"[{color}]{'█' * filled}[/{color}][dim]{'░' * empty}[/dim]"
    console.print(f"  {label}  {bar}  [{color}]{value:2d}/{max_val}[/{color}]")


def print_diff(original: str, optimized: str) -> None:
    import difflib

    original_lines = original.splitlines(keepends=True)
    optimized_lines = optimized.splitlines(keepends=True)

    diff = list(difflib.unified_diff(
        original_lines,
        optimized_lines,
        fromfile="original",
        tofile="optimized",
        lineterm="",
    ))

    if not diff:
        console.print("[green]No changes would be made.[/green]")
        return

    console.print()
    for line in diff:
        if line.startswith("---") or line.startswith("+++"):
            console.print(f"[bold]{line}[/bold]")
        elif line.startswith("@@"):
            console.print(f"[cyan]{line}[/cyan]")
        elif line.startswith("+"):
            console.print(f"[green]{line}[/green]")
        elif line.startswith("-"):
            console.print(f"[red]{line}[/red]")
        else:
            console.print(f"[dim]{line}[/dim]")


def print_scan_results(results: list[tuple[Path, List[LintIssue]]]) -> None:
    if not results:
        console.print("[yellow]No config files found.[/yellow]")
        return

    table = Table(title="Scan Results", border_style="cyan", show_lines=False)
    table.add_column("File", style="cyan", no_wrap=True)
    table.add_column("Errors", style="red", justify="right")
    table.add_column("Warnings", style="yellow", justify="right")
    table.add_column("Status", justify="center")

    for path, issues in sorted(results, key=lambda x: -len(x[1])):
        errors = sum(1 for i in issues if i.severity == Severity.ERROR)
        warnings = sum(1 for i in issues if i.severity == Severity.WARNING)
        if errors:
            status = "[red]❌ Needs fix[/red]"
        elif warnings:
            status = "[yellow]⚠️  Warnings[/yellow]"
        else:
            status = "[green]✅ Clean[/green]"
        table.add_row(str(path), str(errors) if errors else "-", str(warnings) if warnings else "-", status)

    console.print(table)
