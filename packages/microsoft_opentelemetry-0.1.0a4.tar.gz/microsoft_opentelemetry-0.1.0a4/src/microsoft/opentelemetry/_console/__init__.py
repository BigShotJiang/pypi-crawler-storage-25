# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# -------------------------------------------------------------------------

from microsoft.opentelemetry._console.handler import (
    create_console_components,
    ConsoleHandlers,
)

__all__ = [
    "create_console_components",
    "ConsoleHandlers",
]
