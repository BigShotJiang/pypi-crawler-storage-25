"""Additional tests for training service to push coverage to 85%+.

Targets:
- _make_cancel_aware_cb: CancelledError path (lines 39-42)
- _run_job_core: cancelled and failed branches with broadcaster (lines 88-103)
- _run_job_core: log file written to disk after job (lines 108-110)
- start_fit_async: thread is spawned and workspace state updated
- start_tune_async: thread is spawned and workspace state updated
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pandas as pd
import pytest

from lizystudio.backends.types import DataRef, FitSummary, TuningSummary
from lizystudio.services.jobs import JobStore
from lizystudio.services.training import (
    CancelledError,
    _make_cancel_aware_cb,
    _run_job_core,
    run_fit,
    run_tune,
    start_fit_async,
    start_tune_async,
)
from lizystudio.services.workspace import WorkspaceState
from lizystudio.ws.progress import ProgressBroadcaster

pytestmark = pytest.mark.unit

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def job_store(tmp_path: Path) -> JobStore:
    return JobStore(tmp_path / "jobs")


@pytest.fixture()
def sample_data_ref() -> DataRef:
    return DataRef(
        source_type="path",
        path="/data/train.csv",
        filename="train.csv",
        fingerprint="abc123",
        shape=(100, 10),
    )


@pytest.fixture()
def sample_df() -> pd.DataFrame:
    return pd.DataFrame({"x": [1, 2, 3], "y": [0, 1, 0]})


@pytest.fixture()
def mock_backend() -> MagicMock:
    backend = MagicMock()
    backend.create_model.return_value = MagicMock()
    backend.info.name = "lizyml"
    backend.fit.return_value = FitSummary(
        metrics={"auc": 0.9}, fold_count=5, params=[{"n_estimators": 100}]
    )
    backend.tune.return_value = TuningSummary(
        best_params={"lr": 0.01},
        best_score=0.95,
        trials=[{"number": 1, "score": 0.95, "params": {"lr": 0.01}}],
        metric_name="auc",
        direction="maximize",
    )
    backend.export_model.return_value = "/tmp/model"
    backend.validate_config.return_value = []
    return backend


@pytest.fixture()
def mock_broadcaster() -> MagicMock:
    return MagicMock(spec=ProgressBroadcaster)


# ---------------------------------------------------------------------------
# _make_cancel_aware_cb — CancelledError path
# ---------------------------------------------------------------------------


def test_cancel_aware_cb_raises_cancelled_error_when_cancel_requested(
    job_store: JobStore,
    sample_data_ref: DataRef,
) -> None:
    """Callback must raise CancelledError when cancellation is requested."""
    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )
    job_store.request_cancel(job.job_id)

    cb = _make_cancel_aware_cb(job.job_id, job_store, broadcaster=None)

    with pytest.raises(CancelledError):
        cb(current=1, total=10, message="step")


def test_cancel_aware_cb_forwards_progress_when_no_cancel(
    job_store: JobStore,
    sample_data_ref: DataRef,
    mock_broadcaster: MagicMock,
) -> None:
    """Callback must call broadcaster.send_progress when no cancellation."""
    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )

    cb = _make_cancel_aware_cb(job.job_id, job_store, broadcaster=mock_broadcaster)
    cb(current=3, total=10, message="training")

    mock_broadcaster.send_progress.assert_called_once_with(
        job.job_id,
        current=3,
        total=10,
        message="training",
        fold_results=None,
        trial_results=None,
    )


def test_cancel_aware_cb_no_broadcaster_no_error(
    job_store: JobStore,
    sample_data_ref: DataRef,
) -> None:
    """Callback must not raise when broadcaster is None and no cancel."""
    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )

    cb = _make_cancel_aware_cb(job.job_id, job_store, broadcaster=None)
    # Should not raise
    cb(current=1, total=5, message="ok")


# ---------------------------------------------------------------------------
# _run_job_core — cancelled path (execute_fn raises CancelledError)
# ---------------------------------------------------------------------------


def test_run_job_core_cancelled_sets_status(
    job_store: JobStore,
    sample_data_ref: DataRef,
) -> None:
    """When execute_fn raises CancelledError the job status becomes 'cancelled'."""
    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )

    def execute_fn(cb: Any) -> Any:
        raise CancelledError

    finished = _run_job_core(
        job=job,
        job_store=job_store,
        broadcaster=None,
        execute_fn=execute_fn,
    )

    assert finished.status == "cancelled"
    assert finished.completed_at is not None

    # Persisted state must reflect cancellation
    persisted = job_store.get(job.job_id)
    assert persisted is not None
    assert persisted.status == "cancelled"


def test_run_job_core_cancelled_notifies_broadcaster(
    job_store: JobStore,
    sample_data_ref: DataRef,
    mock_broadcaster: MagicMock,
) -> None:
    """Broadcaster receives send_error with JOB_CANCELLED code on cancellation."""
    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )

    def execute_fn(cb: Any) -> Any:
        raise CancelledError

    _run_job_core(
        job=job,
        job_store=job_store,
        broadcaster=mock_broadcaster,
        execute_fn=execute_fn,
    )

    mock_broadcaster.send_error.assert_called_once()
    call_kwargs = mock_broadcaster.send_error.call_args
    assert call_kwargs.kwargs.get("code") == "JOB_CANCELLED" or (
        len(call_kwargs.args) >= 3 and call_kwargs.args[2] == "JOB_CANCELLED"
    )


def test_run_job_core_failed_notifies_broadcaster(
    job_store: JobStore,
    sample_data_ref: DataRef,
    mock_broadcaster: MagicMock,
) -> None:
    """Broadcaster receives send_error with sanitized message on generic failure."""
    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )

    def execute_fn(cb: Any) -> Any:
        raise RuntimeError("something went wrong")

    finished = _run_job_core(
        job=job,
        job_store=job_store,
        broadcaster=mock_broadcaster,
        execute_fn=execute_fn,
    )

    assert finished.status == "failed"
    mock_broadcaster.send_error.assert_called_once()
    # Sanitized message must contain the exception type but NOT the full traceback
    error_message = mock_broadcaster.send_error.call_args.args[1]
    assert "RuntimeError" in error_message
    assert "something went wrong" in error_message


def test_run_job_core_success_notifies_broadcaster(
    job_store: JobStore,
    sample_data_ref: DataRef,
    mock_broadcaster: MagicMock,
) -> None:
    """Broadcaster receives send_completed on successful job."""
    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )
    fit_result = FitSummary(metrics={"auc": 0.8}, fold_count=3, params=[])

    def execute_fn(cb: Any) -> Any:
        return fit_result, None, "/model"

    _run_job_core(
        job=job,
        job_store=job_store,
        broadcaster=mock_broadcaster,
        execute_fn=execute_fn,
    )

    mock_broadcaster.send_completed.assert_called_once_with(job.job_id)


# ---------------------------------------------------------------------------
# Log file written after job
# ---------------------------------------------------------------------------


def test_run_job_core_writes_log_file_on_success(
    job_store: JobStore,
    sample_data_ref: DataRef,
) -> None:
    """execution.log must be created inside {jobs_dir}/{job_id}/ after the job."""
    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )
    fit_result = FitSummary(metrics={}, fold_count=1, params=[])

    def execute_fn(cb: Any) -> Any:
        return fit_result, None, "/model"

    _run_job_core(
        job=job,
        job_store=job_store,
        broadcaster=None,
        execute_fn=execute_fn,
    )

    log_path = job_store.jobs_dir / job.job_id / "execution.log"
    assert log_path.exists(), "execution.log must exist after job completion"


def test_run_job_core_writes_log_file_on_failure(
    job_store: JobStore,
    sample_data_ref: DataRef,
) -> None:
    """execution.log must be created even when the job fails."""
    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )

    def execute_fn(cb: Any) -> Any:
        raise ValueError("boom")

    _run_job_core(
        job=job,
        job_store=job_store,
        broadcaster=None,
        execute_fn=execute_fn,
    )

    log_path = job_store.jobs_dir / job.job_id / "execution.log"
    assert log_path.exists(), "execution.log must exist even after job failure"


def test_run_job_core_writes_log_file_on_cancel(
    job_store: JobStore,
    sample_data_ref: DataRef,
) -> None:
    """execution.log must be created even when the job is cancelled."""
    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )

    def execute_fn(cb: Any) -> Any:
        raise CancelledError

    _run_job_core(
        job=job,
        job_store=job_store,
        broadcaster=None,
        execute_fn=execute_fn,
    )

    log_path = job_store.jobs_dir / job.job_id / "execution.log"
    assert log_path.exists(), "execution.log must exist even after cancellation"


# ---------------------------------------------------------------------------
# start_fit_async — thread spawned and workspace state updated
# ---------------------------------------------------------------------------


def _make_workspace(backend: MagicMock) -> WorkspaceState:
    ws = WorkspaceState(backend=backend)
    return ws


def test_start_fit_async_returns_job_id(
    job_store: JobStore,
    sample_data_ref: DataRef,
    sample_df: pd.DataFrame,
    mock_backend: MagicMock,
    mock_broadcaster: MagicMock,
) -> None:
    """start_fit_async must return the job_id string immediately."""
    job = job_store.create(
        backend_name="lizyml",
        config={"task": "binary"},
        data_ref=sample_data_ref,
        job_type="fit",
    )
    ws = _make_workspace(mock_backend)

    returned_id = start_fit_async(
        ws=ws,
        job_store=job_store,
        broadcaster=mock_broadcaster,
        config={"task": "binary"},
        dataframe=sample_df,
        job=job,
    )

    assert returned_id == job.job_id


def test_start_fit_async_updates_workspace_on_completion(
    job_store: JobStore,
    sample_data_ref: DataRef,
    sample_df: pd.DataFrame,
    mock_backend: MagicMock,
    mock_broadcaster: MagicMock,
) -> None:
    """After the background thread finishes, workspace_fit_result must be set."""
    job = job_store.create(
        backend_name="lizyml",
        config={"task": "binary"},
        data_ref=sample_data_ref,
        job_type="fit",
    )
    ws = _make_workspace(mock_backend)

    start_fit_async(
        ws=ws,
        job_store=job_store,
        broadcaster=mock_broadcaster,
        config={"task": "binary"},
        dataframe=sample_df,
        job=job,
    )

    # Wait for the background thread to complete (up to 5 seconds)
    deadline = time.monotonic() + 5.0
    while ws.workspace_fit_result is None and time.monotonic() < deadline:
        time.sleep(0.05)

    assert ws.workspace_fit_result is not None
    assert ws.workspace_fit_result.metrics["auc"] == 0.9
    assert ws.workspace_tune_result is None
    assert ws.current_job_id == job.job_id


def test_start_fit_async_job_completed_in_store(
    job_store: JobStore,
    sample_data_ref: DataRef,
    sample_df: pd.DataFrame,
    mock_backend: MagicMock,
    mock_broadcaster: MagicMock,
) -> None:
    """start_fit_async sets job status to completed."""
    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )
    ws = _make_workspace(mock_backend)

    start_fit_async(
        ws=ws,
        job_store=job_store,
        broadcaster=mock_broadcaster,
        config={},
        dataframe=sample_df,
        job=job,
    )

    deadline = time.monotonic() + 5.0
    stored_status = "pending"
    while stored_status != "completed" and time.monotonic() < deadline:
        time.sleep(0.05)
        j = job_store.get(job.job_id)
        if j is not None:
            stored_status = j.status

    assert stored_status == "completed"


# ---------------------------------------------------------------------------
# start_tune_async — thread spawned and workspace state updated
# ---------------------------------------------------------------------------


def test_start_tune_async_returns_job_id(
    job_store: JobStore,
    sample_data_ref: DataRef,
    sample_df: pd.DataFrame,
    mock_backend: MagicMock,
    mock_broadcaster: MagicMock,
) -> None:
    """start_tune_async must return the job_id string immediately."""
    job = job_store.create(
        backend_name="lizyml",
        config={"task": "binary"},
        data_ref=sample_data_ref,
        job_type="tune",
    )
    ws = _make_workspace(mock_backend)

    returned_id = start_tune_async(
        ws=ws,
        job_store=job_store,
        broadcaster=mock_broadcaster,
        config={"task": "binary"},
        dataframe=sample_df,
        job=job,
    )

    assert returned_id == job.job_id


def test_start_tune_async_updates_workspace_on_completion(
    job_store: JobStore,
    sample_data_ref: DataRef,
    sample_df: pd.DataFrame,
    mock_backend: MagicMock,
    mock_broadcaster: MagicMock,
) -> None:
    """After the background thread finishes, workspace_tune_result must be set."""
    job = job_store.create(
        backend_name="lizyml",
        config={"task": "binary"},
        data_ref=sample_data_ref,
        job_type="tune",
    )
    ws = _make_workspace(mock_backend)

    start_tune_async(
        ws=ws,
        job_store=job_store,
        broadcaster=mock_broadcaster,
        config={"task": "binary"},
        dataframe=sample_df,
        job=job,
    )

    deadline = time.monotonic() + 5.0
    while ws.workspace_tune_result is None and time.monotonic() < deadline:
        time.sleep(0.05)

    assert ws.workspace_tune_result is not None
    assert ws.workspace_tune_result.best_score == 0.95
    assert ws.workspace_fit_result is not None
    assert ws.current_job_id == job.job_id


def test_start_tune_async_job_completed_in_store(
    job_store: JobStore,
    sample_data_ref: DataRef,
    sample_df: pd.DataFrame,
    mock_backend: MagicMock,
    mock_broadcaster: MagicMock,
) -> None:
    """start_tune_async sets job status to completed."""
    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="tune",
    )
    ws = _make_workspace(mock_backend)

    start_tune_async(
        ws=ws,
        job_store=job_store,
        broadcaster=mock_broadcaster,
        config={},
        dataframe=sample_df,
        job=job,
    )

    deadline = time.monotonic() + 5.0
    stored_status = "pending"
    while stored_status != "completed" and time.monotonic() < deadline:
        time.sleep(0.05)
        j = job_store.get(job.job_id)
        if j is not None:
            stored_status = j.status

    assert stored_status == "completed"


# ---------------------------------------------------------------------------
# run_fit / run_tune cancel via callback (integration of cancel mechanism)
# ---------------------------------------------------------------------------


def test_run_fit_cancelled_via_cancel_flag(
    job_store: JobStore,
    sample_data_ref: DataRef,
    sample_df: pd.DataFrame,
    mock_backend: MagicMock,
) -> None:
    """If cancellation is requested before fit is called, job ends as cancelled."""

    def fit_side_effect(model: Any, *, params: Any, on_progress: Any) -> FitSummary:
        # Invoke the callback — it should raise CancelledError
        on_progress(current=0, total=10, message="starting")
        return FitSummary(metrics={}, fold_count=1, params=[])  # never reached

    mock_backend.fit.side_effect = fit_side_effect

    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )
    job_store.request_cancel(job.job_id)

    result = run_fit(
        job=job,
        job_store=job_store,
        backend=mock_backend,
        config={},
        dataframe=sample_df,
    )

    assert result.status == "cancelled"


def test_run_tune_cancelled_via_cancel_flag(
    job_store: JobStore,
    sample_data_ref: DataRef,
    sample_df: pd.DataFrame,
    mock_backend: MagicMock,
) -> None:
    """If cancellation is requested before tune is called, job ends as cancelled."""

    def tune_side_effect(model: Any, *, on_progress: Any) -> TuningSummary:
        on_progress(current=0, total=50, message="tuning")
        return MagicMock()  # never reached

    mock_backend.tune.side_effect = tune_side_effect

    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="tune",
    )
    job_store.request_cancel(job.job_id)

    result = run_tune(
        job=job,
        job_store=job_store,
        backend=mock_backend,
        config={},
        dataframe=sample_df,
    )

    assert result.status == "cancelled"


# ---------------------------------------------------------------------------
# Active job tracking (concurrency control)
# ---------------------------------------------------------------------------


def test_claim_active_prevents_second_job(
    job_store: JobStore,
    sample_data_ref: DataRef,
) -> None:
    """Second job should fail when another job already holds the active slot."""
    job1 = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )
    job2 = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )

    assert job_store.claim_active(job1.job_id) is True
    assert job_store.has_active_job() is True
    assert job_store.active_job_id == job1.job_id

    assert job_store.claim_active(job2.job_id) is False

    job_store.release_active(job1.job_id)
    assert job_store.has_active_job() is False
    assert job_store.claim_active(job2.job_id) is True
    job_store.release_active(job2.job_id)


def test_run_job_core_fails_when_active_slot_taken(
    job_store: JobStore,
    sample_data_ref: DataRef,
) -> None:
    """_run_job_core should fail the job if claim_active returns False."""
    from lizystudio.services.training import _run_job_core

    job_store.claim_active("blocker-job")

    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )

    def never_called(cb: Any) -> tuple[FitSummary, None, str]:
        raise AssertionError("Should not be called")

    result = _run_job_core(
        job=job,
        job_store=job_store,
        broadcaster=None,
        execute_fn=never_called,
    )

    assert result.status == "failed"
    assert "already running" in (result.error or "")
    assert job_store.active_job_id == "blocker-job"
    job_store.release_active("blocker-job")


def test_run_job_core_job_conflict_notifies_broadcaster(
    job_store: JobStore,
    sample_data_ref: DataRef,
    mock_broadcaster: MagicMock,
) -> None:
    """_run_job_core: send_error with JOB_CONFLICT when slot taken."""
    job_store.claim_active("blocker-job")

    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )

    def never_called(cb: Any) -> tuple[FitSummary, None, str]:
        raise AssertionError("Should not be called")

    result = _run_job_core(
        job=job,
        job_store=job_store,
        broadcaster=mock_broadcaster,
        execute_fn=never_called,
    )

    assert result.status == "failed"
    mock_broadcaster.send_error.assert_called_once()
    call_args = mock_broadcaster.send_error.call_args
    assert call_args.kwargs.get("code") == "JOB_CONFLICT"
    job_store.release_active("blocker-job")


# ---------------------------------------------------------------------------
# _run_subprocess_job — no data_ref path
# ---------------------------------------------------------------------------


def test_run_subprocess_job_no_data_ref_sets_failed_status(
    job_store: JobStore,
    sample_data_ref: DataRef,
    mock_backend: MagicMock,
    mock_broadcaster: MagicMock,
) -> None:
    """_run_subprocess_job must set job status=failed when ws.data_ref is None."""
    from lizystudio.services.training import _run_subprocess_job
    from lizystudio.services.workspace import WorkspaceState

    ws = WorkspaceState(backend=mock_backend)
    assert ws.data_ref is None  # no data loaded

    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )

    _run_subprocess_job(ws, job, job_store, mock_broadcaster)

    assert job.status == "failed"
    assert "No data loaded" in (job.error or "")
    assert ws.current_job_id == job.job_id
    mock_broadcaster.send_error.assert_called_once_with(job.job_id, job.error)


# ---------------------------------------------------------------------------
# start_fit_async / start_tune_async — subprocess path
# ---------------------------------------------------------------------------


def test_start_fit_async_subprocess_path(
    job_store: JobStore,
    sample_data_ref: DataRef,
    sample_df: pd.DataFrame,
    mock_backend: MagicMock,
    mock_broadcaster: MagicMock,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """start_fit_async calls _run_subprocess_job in subprocess mode."""
    import lizystudio.services.training as training_mod
    from lizystudio.services.workspace import WorkspaceState

    ws = WorkspaceState(backend=mock_backend)
    ws.data_ref = sample_data_ref  # provide data ref so subprocess path succeeds

    called = {}

    def fake_subprocess_job(
        ws2: Any,
        job2: Any,
        job_store2: Any,
        broadcaster2: Any,
    ) -> None:
        called["invoked"] = True
        with ws2._lock:
            ws2.current_job_id = job2.job_id

    import lizystudio.services.openmp_detect as openmp_detect_mod

    monkeypatch.setattr(openmp_detect_mod, "should_use_subprocess", lambda: True)
    monkeypatch.setattr(training_mod, "_run_subprocess_job", fake_subprocess_job)

    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )

    start_fit_async(
        ws=ws,
        job_store=job_store,
        broadcaster=mock_broadcaster,
        config={},
        dataframe=sample_df,
        job=job,
    )

    if ws._job_thread:
        ws._job_thread.join(timeout=5)

    assert called.get("invoked") is True


def test_start_tune_async_subprocess_path(
    job_store: JobStore,
    sample_data_ref: DataRef,
    sample_df: pd.DataFrame,
    mock_backend: MagicMock,
    mock_broadcaster: MagicMock,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """start_tune_async calls _run_subprocess_job in subprocess mode."""
    import lizystudio.services.training as training_mod
    from lizystudio.services.workspace import WorkspaceState

    ws = WorkspaceState(backend=mock_backend)
    ws.data_ref = sample_data_ref

    called = {}

    def fake_subprocess_job(
        ws2: Any,
        job2: Any,
        job_store2: Any,
        broadcaster2: Any,
    ) -> None:
        called["invoked"] = True
        with ws2._lock:
            ws2.current_job_id = job2.job_id

    import lizystudio.services.openmp_detect as openmp_detect_mod

    monkeypatch.setattr(openmp_detect_mod, "should_use_subprocess", lambda: True)
    monkeypatch.setattr(training_mod, "_run_subprocess_job", fake_subprocess_job)

    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="tune",
    )

    start_tune_async(
        ws=ws,
        job_store=job_store,
        broadcaster=mock_broadcaster,
        config={},
        dataframe=sample_df,
        job=job,
    )

    if ws._job_thread:
        ws._job_thread.join(timeout=5)

    assert called.get("invoked") is True


# ---------------------------------------------------------------------------
# _run_subprocess_job — success path (lines 234-245)
# ---------------------------------------------------------------------------


def test_run_subprocess_job_success_updates_workspace(
    job_store: JobStore,
    sample_data_ref: DataRef,
    mock_backend: MagicMock,
    mock_broadcaster: MagicMock,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """_run_subprocess_job success updates workspace state."""
    from lizystudio.services.training import _run_subprocess_job
    from lizystudio.services.workspace import WorkspaceState

    ws = WorkspaceState(backend=mock_backend)
    ws.data_ref = sample_data_ref  # data_ref with path set

    job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )

    fit_result = FitSummary(metrics={"auc": 0.88}, fold_count=3, params=[])
    finished_job = job_store.create(
        backend_name="lizyml",
        config={},
        data_ref=sample_data_ref,
        job_type="fit",
    )
    finished_job.fit_result = fit_result
    finished_job.tune_result = None
    finished_job.status = "completed"

    import lizystudio.services.subprocess_runner as subprocess_runner_mod

    monkeypatch.setattr(
        subprocess_runner_mod,
        "run_job_in_subprocess",
        lambda **_kwargs: finished_job,
    )

    _run_subprocess_job(ws, job, job_store, mock_broadcaster)

    assert ws.workspace_fit_result is fit_result
    assert ws.workspace_tune_result is None
    assert ws.current_job_id == finished_job.job_id


# --- _prepare_tune_config tests ---


class TestPrepareTuneConfig:
    """Unit tests for _prepare_tune_config."""

    def test_merges_tuning_evaluation_to_top_level(self) -> None:
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {
            "task": "binary",
            "evaluation": {"metrics": ["rmse"]},
            "tuning": {
                "optuna": {"params": {"n_trials": 50}, "space": {}},
                "evaluation": {"metrics": ["auc", "f1"]},
            },
        }
        result = _prepare_tune_config(config)
        assert result["evaluation"] == {"metrics": ["auc", "f1"]}

    def test_merges_tuning_model_params(self) -> None:
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {
            "task": "binary",
            "model": {"params": {"n_estimators": 1000}},
            "tuning": {
                "optuna": {"params": {}, "space": {}},
                "model_params": {"learning_rate": 0.01},
            },
        }
        result = _prepare_tune_config(config)
        assert result["model"]["params"]["n_estimators"] == 1000
        assert result["model"]["params"]["learning_rate"] == 0.01

    def test_strips_internal_keys_from_model_params(self) -> None:
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {
            "task": "binary",
            "tuning": {
                "optuna": {"params": {}, "space": {}},
                "model_params": {"lr": 0.01, "_precision_at_k_k": 10},
            },
        }
        result = _prepare_tune_config(config)
        assert "_precision_at_k_k" not in result.get("model", {}).get("params", {})

    def test_merges_tuning_training(self) -> None:
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {
            "task": "binary",
            "training": {"seed": 42},
            "tuning": {
                "optuna": {"params": {}, "space": {}},
                "training": {"validation_ratio": 0.2},
            },
        }
        result = _prepare_tune_config(config)
        assert result["training"]["seed"] == 42
        assert result["training"]["validation_ratio"] == 0.2

    def test_injects_default_metric_when_evaluation_empty(self) -> None:
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {
            "task": "binary",
            "tuning": {"optuna": {"params": {"n_trials": 50}, "space": {}}},
        }
        result = _prepare_tune_config(config)
        assert result["evaluation"]["metrics"] == ["auc"]

    def test_injects_default_metric_regression(self) -> None:
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {
            "task": "regression",
            "tuning": {"optuna": {"params": {}, "space": {}}},
        }
        result = _prepare_tune_config(config)
        assert result["evaluation"]["metrics"] == ["rmse"]

    def test_resolves_direction_maximize_for_auc(self) -> None:
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {
            "task": "binary",
            "tuning": {
                "optuna": {"params": {"n_trials": 50}, "space": {}},
                "evaluation": {"metrics": ["auc"]},
            },
        }
        result = _prepare_tune_config(config)
        assert result["tuning"]["optuna"]["params"]["direction"] == "maximize"

    def test_resolves_direction_minimize_for_rmse(self) -> None:
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {
            "task": "regression",
            "tuning": {
                "optuna": {"params": {}, "space": {}},
                "evaluation": {"metrics": ["rmse"]},
            },
        }
        result = _prepare_tune_config(config)
        assert result["tuning"]["optuna"]["params"]["direction"] == "minimize"

    def test_preserves_explicit_direction(self) -> None:
        """User-set direction must NOT be overwritten."""
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {
            "task": "regression",
            "tuning": {
                "optuna": {
                    "params": {"n_trials": 50, "direction": "maximize"},
                    "space": {},
                },
                "evaluation": {"metrics": ["rmse"]},
            },
        }
        result = _prepare_tune_config(config)
        # rmse is normally minimize, but user explicitly set maximize
        assert result["tuning"]["optuna"]["params"]["direction"] == "maximize"

    def test_cleans_tuning_section(self) -> None:
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {
            "task": "binary",
            "tuning": {
                "optuna": {"params": {}, "space": {}},
                "evaluation": {"metrics": ["auc"]},
                "model_params": {"lr": 0.01},
                "training": {"seed": 1},
            },
        }
        result = _prepare_tune_config(config)
        # Only optuna should remain in tuning
        assert set(result["tuning"].keys()) == {"optuna"}

    def test_no_tuning_section(self) -> None:
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {"task": "binary"}
        result = _prepare_tune_config(config)
        # Should not crash; evaluation should get default metric
        assert result["evaluation"]["metrics"] == ["auc"]

    def test_unknown_task_uses_empty_default_metric(self) -> None:
        """Unknown task type must not inject a default metric."""
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {
            "task": "unknown_task",
            "tuning": {"optuna": {"params": {}, "space": {}}},
        }
        result = _prepare_tune_config(config)
        # No preferred metric → evaluation section should NOT be added
        assert "evaluation" not in result or result.get("evaluation") == {}

    def test_dict_form_metric_resolves_direction(self) -> None:
        """Direction resolved from first metric when it is a dict (not str)."""
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {
            "task": "binary",
            "tuning": {
                "optuna": {"params": {"n_trials": 10}, "space": {}},
                "evaluation": {"metrics": [{"auc": {}}]},
            },
        }
        result = _prepare_tune_config(config)
        # {"auc": {}} → first key is "auc" → maximize
        assert result["tuning"]["optuna"]["params"]["direction"] == "maximize"

    def test_multiclass_task_uses_auc_metric(self) -> None:
        from lizystudio.services.training import _prepare_tune_config

        config: dict[str, Any] = {
            "task": "multiclass",
            "tuning": {"optuna": {"params": {}, "space": {}}},
        }
        result = _prepare_tune_config(config)
        assert result["evaluation"]["metrics"] == ["auc"]


# ---------------------------------------------------------------------------
# _save_tuning_plot
# ---------------------------------------------------------------------------


class TestSaveTuningPlot:
    """Unit tests for _save_tuning_plot."""

    def test_saves_plot_json_to_disk(self, tmp_path: Path) -> None:
        """Successful call writes plotly_json to tuning_plot.json."""
        from unittest.mock import MagicMock

        from lizystudio.backends.types import PlotData
        from lizystudio.services.training import _save_tuning_plot

        backend = MagicMock()
        model = MagicMock()
        backend.plot.return_value = PlotData(plotly_json='{"data":[]}')

        job_dir = tmp_path / "job_abc"
        job_dir.mkdir()
        _save_tuning_plot(backend, model, job_dir)

        plot_path = job_dir / "tuning_plot.json"
        assert plot_path.exists()
        assert plot_path.read_text(encoding="utf-8") == '{"data":[]}'
        backend.plot.assert_called_once_with(model, "tuning")

    def test_logs_warning_on_backend_error(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """When backend.plot raises, a warning is logged and no exception propagates."""
        import logging
        from unittest.mock import MagicMock

        from lizystudio.services.training import _save_tuning_plot

        backend = MagicMock()
        model = MagicMock()
        backend.plot.side_effect = RuntimeError("No study data")

        job_dir = tmp_path / "job_err"
        job_dir.mkdir()

        # Must NOT raise — _save_tuning_plot catches all exceptions (BLE001)
        with caplog.at_level(logging.WARNING, logger="lizystudio.services.training"):
            _save_tuning_plot(backend, model, job_dir)

        # Warning should have been emitted
        assert any("Failed to save tuning plot" in r.message for r in caplog.records)
        # File must not have been written
        assert not (job_dir / "tuning_plot.json").exists()

    def test_suppresses_backend_exception(self, tmp_path: Path) -> None:
        """_save_tuning_plot must suppress exceptions (BLE001 catch-all)."""
        from unittest.mock import MagicMock

        from lizystudio.services.training import _save_tuning_plot

        backend = MagicMock()
        model = MagicMock()
        backend.plot.side_effect = ValueError("oops")

        job_dir = tmp_path / "job_suppress"
        job_dir.mkdir()

        # No exception should propagate
        _save_tuning_plot(backend, model, job_dir)

        # File should not have been written
        assert not (job_dir / "tuning_plot.json").exists()


# ---------------------------------------------------------------------------
# _prepare_autofit_config
# ---------------------------------------------------------------------------


class TestPrepareAutofitConfig:
    """Unit tests for _prepare_autofit_config."""

    def test_merges_best_params_into_model_params(self) -> None:
        from lizystudio.services.training import _prepare_autofit_config

        config: dict[str, Any] = {
            "task": "binary",
            "model": {"name": "lgbm", "params": {"n_estimators": 1000}},
        }
        best_params = {"learning_rate": 0.05, "num_leaves": 64}
        result = _prepare_autofit_config(config, best_params)

        assert result["model"]["params"]["n_estimators"] == 1000
        assert result["model"]["params"]["learning_rate"] == 0.05
        assert result["model"]["params"]["num_leaves"] == 64

    def test_strips_tuning_section(self) -> None:
        from lizystudio.services.training import _prepare_autofit_config

        config: dict[str, Any] = {
            "task": "binary",
            "model": {"params": {}},
            "tuning": {"optuna": {"params": {"n_trials": 50}}},
        }
        result = _prepare_autofit_config(config, {})
        assert "tuning" not in result

    def test_does_not_mutate_original_config(self) -> None:
        from lizystudio.services.training import _prepare_autofit_config

        config: dict[str, Any] = {
            "task": "binary",
            "model": {"params": {"n_estimators": 100}},
        }
        original_params = dict(config["model"]["params"])  # type: ignore[index]
        _prepare_autofit_config(config, {"learning_rate": 0.01})

        assert config["model"]["params"] == original_params  # type: ignore[index]

    def test_empty_best_params(self) -> None:
        from lizystudio.services.training import _prepare_autofit_config

        config: dict[str, Any] = {
            "task": "binary",
            "model": {"params": {"n_estimators": 500}},
        }
        result = _prepare_autofit_config(config, {})
        assert result["model"]["params"] == {"n_estimators": 500}

    def test_no_model_section_in_config(self) -> None:
        """_prepare_autofit_config handles config with no model key."""
        from lizystudio.services.training import _prepare_autofit_config

        config: dict[str, Any] = {"task": "binary"}
        result = _prepare_autofit_config(config, {"lr": 0.1})
        assert result["model"]["params"] == {"lr": 0.1}

    def test_best_params_override_existing(self) -> None:
        """best_params must overwrite existing model.params values."""
        from lizystudio.services.training import _prepare_autofit_config

        config: dict[str, Any] = {
            "task": "binary",
            "model": {"params": {"learning_rate": 0.1, "n_estimators": 100}},
        }
        result = _prepare_autofit_config(config, {"learning_rate": 0.001})
        assert result["model"]["params"]["learning_rate"] == 0.001
        assert result["model"]["params"]["n_estimators"] == 100
