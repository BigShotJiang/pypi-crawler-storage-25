import type { ParameterHint } from "@/api/types";
import { ChipGroup } from "./ChipGroup";
import { CompactStepper } from "./CompactStepper";
import { CompactToggle } from "./CompactToggle";
import { FormRow } from "./FormRow";
import { SegmentGroup } from "./SegmentGroup";

interface DynParamProps {
  hint: ParameterHint;
  value: unknown;
  onChange: (value: unknown) => void;
  /** Options list for objective / model_metric kinds (task-filtered). */
  options?: string[];
  /** Whether the field is visible (conditional_visibility). */
  visible?: boolean;
  /** precision_at_k k-value (for model_metric kind). */
  precisionAtKValue?: number;
  /** Callback for precision_at_k k-value change. */
  onPrecisionAtKChange?: (k: number) => void;
}

/**
 * Renders a single parameter based on its ParameterHint.kind.
 *
 * Maps:
 *   objective    -> SegmentGroup  (single-select)
 *   model_metric -> ChipGroup     (multi-select among task metrics)
 *   integer      -> CompactStepper
 *   number       -> CompactStepper
 *   boolean      -> CompactToggle
 */
export function DynParam({
  hint,
  value,
  onChange,
  options,
  visible = true,
  precisionAtKValue,
  onPrecisionAtKChange,
}: DynParamProps) {
  if (!visible) return null;

  switch (hint.kind) {
    case "objective": {
      const opts = options ?? [];
      if (opts.length === 0) return null;
      return (
        <FormRow label={hint.label} description={hint.description}>
          <SegmentGroup
            options={opts}
            value={typeof value === "string" ? value : ""}
            onChange={(v) => onChange(v)}
          />
        </FormRow>
      );
    }

    case "model_metric": {
      const opts = options ?? [];
      if (opts.length === 0) return null;
      const selected = Array.isArray(value)
        ? (value as string[])
        : typeof value === "string"
          ? [value]
          : [];
      const showK = selected.includes("precision_at_k") && onPrecisionAtKChange;
      return (
        <>
          <FormRow label={hint.label} description={hint.description}>
            <ChipGroup
              options={opts}
              selected={selected}
              onChange={(v) => onChange(v)}
              minSelected={1}
            />
          </FormRow>
          {showK && (
            <FormRow label="precision_at_k: k">
              <CompactStepper
                value={precisionAtKValue ?? 10}
                onChange={(v) => {
                  if (v !== undefined) onPrecisionAtKChange(v);
                }}
                min={1}
                max={100}
                step={1}
              />
            </FormRow>
          )}
        </>
      );
    }

    case "integer":
    case "number": {
      const rawValue =
        value !== undefined && value !== null ? Number(value) : undefined;
      const defaultNum =
        hint.default !== undefined && hint.default !== null
          ? Number(hint.default)
          : undefined;
      const numValue = rawValue ?? defaultNum;
      const step = hint.step ?? (hint.kind === "integer" ? 1 : 0.01);
      return (
        <FormRow label={hint.label} description={hint.description}>
          <CompactStepper
            value={numValue}
            onChange={(v) => onChange(v)}
            step={step}
          />
        </FormRow>
      );
    }

    case "boolean": {
      const boolValue = value === true;
      return (
        <FormRow label={hint.label} description={hint.description}>
          <CompactToggle checked={boolValue} onChange={(v) => onChange(v)} />
        </FormRow>
      );
    }

    default:
      return null;
  }
}
