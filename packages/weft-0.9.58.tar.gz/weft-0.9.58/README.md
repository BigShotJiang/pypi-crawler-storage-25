# Weft

*The durable task substrate for agent systems. Persistent managers, multiprocess isolation, comprehensive observability.*

```bash
$ weft run echo "hello world"
hello world

$ weft run --spec NAME|PATH
# resolves a stored spec or builtin helper and waits by default

$ weft run --spec review-agent.json
# runs an agent TaskSpec through the normal manager/task path

$ weft status
# shows current task, manager, and broker status
```

## What Weft Is (And Is Not)

Weft is for durable, observable, isolated process execution with easy
inter-process messaging. It uses processes as a natural concurrency primitive
for commands, functions, pipelines, and agents. The unifying idea is simple:
everything is a Task. If work matters, Weft should be able to submit it
durably, run it in a chosen runtime, observe it, control it, and compose it
with other work.

Agent support is part of that core model, not a separate product layered on
top. A dangerous agent running in a restricted container is still just a task
with a different target and runner.

Weft is explicitly a substrate for higher-level systems. It may know enough
about important runtimes to make common execution paths work and to fail
clearly, but policy and domain-specific knowledge belong above Weft. Weft may 
grow richer pipeline shapes, but the boundary stays durable, observable, 
isolated process execution and task-shaped composition.

## Installation

```bash
# Default SQLite-backed install
uv add weft

# Install Postgres backend support too
uv add 'weft[pg]'

# Install Docker runner support (currently supported on Linux and macOS)
uv add 'weft[docker]'

# Install macOS sandbox runner support
uv add 'weft[macos-sandbox]'

# Install Django integration support
uv add 'weft[django]'

# Install Django integration plus Channels/WebSocket realtime support
uv add 'weft[django-channels]'

# Install all first-party optional backends and runners
uv add 'weft[all]'
```

Installing `weft[pg]` adds the `simplebroker-pg` backend plugin. Backend
selection still happens at runtime through project config or environment
variables; the extra only makes the Postgres backend available.

Runner extras work the same way: `weft[docker]` adds the Docker runner plugin
plus the Docker SDK dependency, `weft[macos-sandbox]` adds the macOS sandbox
runner plugin, and `weft[django]` adds the first-party Django integration
package. `weft[django-channels]` adds that Django integration plus the optional
Channels/WebSocket realtime transport. The first-party Docker runner is
currently supported on Linux and macOS only. `weft[all]` installs the current
first-party optional backends, runner plugins, and framework integrations
together; it does not pull nested framework transport extras such as Channels.
Runner selection still happens per TaskSpec through `spec.runner`. The current
Docker runner owns normal command tasks and the Docker-backed one-shot
`provider_cli` agent lane for providers with explicit image recipes. The
current shipped image-recipe set is `claude_code`, `codex`, `gemini`,
`opencode`, and `qwen`.

## Quick Start

```bash
# Initialize the current directory (like `git init`)
$ weft init
# initializes the current directory as a Weft project

# Run a simple command
$ weft run echo "hello world"
hello world

# Run with resource limits
$ weft run --memory 100 --cpu 50 python script.py

# Run and wait for completion
$ weft run --wait --timeout 30 ./long-task.sh

# Run a task spec JSON file
$ weft run --spec .weft/tasks/data-cleanup.json

# Run a builtin helper TaskSpec
$ weft run --spec probe-agents

# Run a pipeline spec (from .weft/pipelines/)
$ weft run --pipeline etl-job

# Pipe stdin into an inline command, task spec file, or pipeline
$ printf "hello\n" | weft run -- python summarize.py
$ printf "hello\n" | weft run --spec summarize.json
$ printf "hello\n" | weft run --pipeline etl-job
# Use --input for explicit pipeline input; do not mix it with piped stdin.

# Run a Python function
$ weft run --function mymodule:process_data --arg input.csv --kw mode=fast

# Run an agent TaskSpec
$ weft run --spec review-agent.json

# Check system status
$ weft status
# shows task, manager, and broker status for the current context

# Get task result as structured JSON
$ weft result 1234567890 --json
# emits the completed result payload as JSON
```

For a guided walkthrough, see [Your First Weft Task](docs/tutorials/first-task.md).

## Embedding Weft in Python

`weft.client` is the public Python surface over the same shared command layer
the CLI uses. The basic pattern is `submit(...) -> Task`, then inspect or wait
through the task handle. The package ships as typed Python (`py.typed`) and
re-exports the public exception surface for library integrations.

```python
from weft.client import WeftClient

client = WeftClient(path=".")

task = client.submit_command(["echo", "hello"])
result = task.result(timeout=30.0)

assert result.status == "completed"
assert "hello" in (result.stdout or str(result.value))
```

Stored specs and pipelines use the same reference grammar as
`weft run --spec NAME|PATH` and `weft run --pipeline NAME|PATH`:

```python
task = client.submit_spec("probe-agents")
pipeline = client.submit_pipeline("etl-job", payload={"batch": 7})
```

Use `prepare*` when an integration needs to validate and snapshot work before a
later commit point. Preparation does not enqueue work; `submit()` does:

```python
prepared = client.prepare_spec("report-job", payload={"report_id": 123})
# later, after the host app commits its own durable state
task = prepared.submit()
```

Use namespaces when you want the broader control surface:

```python
snapshot = client.task(task.tid).snapshot()
events = list(client.task(task.tid).follow())
queues = client.queues.list(include_stats=True)
managers = client.managers.list()
specs = client.specs.list()
system = client.system.status()
```

## Builtin Task Helpers

Weft ships a small set of packaged builtin TaskSpecs as explicit helpers. The
packaged assets are read-only; individual helpers may still perform explicit,
documented project mutations. For example, `probe-agents` can fill missing
provider executable defaults in `.weft/agents.json` while preserving existing
explicit settings. Builtins are not a second command system and they do not
change bare command execution.

Builtins are bundled examples of using Weft as a task runner. A builtin is an
example task or pipeline that is useful enough that Weft ships it directly. In
current Weft, the shipped builtins are task helpers.

They also offer an explicit happy path for common setup or
runtime-preparation tasks.
They may help discover available runtimes or warm a slow runner path, but they
are never required for correctness and are never run implicitly.

A builtin should teach the Weft shape rather than replace it. If a helper
starts to feel like a setup wizard or a second control plane, it belongs in a
higher layer or an extension.

`weft run --spec NAME|PATH` resolves in this order:

1. existing file path
2. existing spec-bundle directory path containing `taskspec.json`
3. local stored task spec in `.weft/tasks/<name>.json`
4. local stored task bundle in `.weft/tasks/<name>/taskspec.json`
5. builtin task helper bundled with Weft, either as
   `weft/builtins/tasks/<name>.json` or
   `weft/builtins/tasks/<name>/taskspec.json`

Local `.weft/tasks` specs shadow builtin helpers of the same name. Builtins are
available only through explicit spec surfaces such as `weft run --spec` and
`weft spec show`. Bare `weft run foo` still means "run command `foo`".

When a spec declares submission-time options through `spec.parameterization`
or `spec.run_input`, those are still ordinary explicit long options owned by
that spec, not new global Weft flags. They use `--name value` or
`--name=value`, and declared `path` values are resolved to absolute host paths
before the adapter sees them.

When a task spec comes from a bundle directory, ordinary Python callable refs
such as `module:function` stay unchanged, but Weft resolves `module` against
that bundle root first before falling back to normal Python imports. That
bundle-local rule applies to `function_target`, runner environment profiles,
delegated agent resolver/tool-profile refs, and Python agent tool refs.
Inside bundle-local helper code, sibling Python modules should use
package-relative imports. Weft does not turn the bundle root into a
process-global `sys.path` entry.

Projects can use `.weft/tasks/` and `.weft/pipelines/` the same way. The same
explicit spec surfaces let a project build up its own reusable task and
pipeline library over time, with builtins acting as bundled examples alongside
that project-local library.

`weft spec list` shows the effective project-visible spec namespace. If you
want the shipped builtin inventory instead, use `weft system builtins`.

One builtin helper currently shipped is `probe-agents`, which probes the known
delegated provider CLIs and can fill missing executable defaults while
preserving existing explicit project settings. It is a convenience helper, not
a required setup step.

Another builtin helper currently shipped is `prepare-agent-images`, which
warms the local Docker image cache for supported Docker-backed delegated agent
runtimes. It is an explicit optional cache warmer, not hidden setup. The
current shipped image-recipe set is `claude_code`, `codex`, `gemini`,
`opencode`, and `qwen`. The name stays plural because one run may warm
multiple provider images. Ordinary Docker-backed agent runs use the same
deterministic image tags and reuse those warmed images when they already
exist; they only build on cache miss.

Weft also ships `dockerized-agent`, a parameterized builtin TaskSpec
for the Docker-backed one-shot delegated-agent lane. It uses
`spec.parameterization` to let `weft run --spec` accept an explicit
`--provider` and optional `--model`, materializes a concrete provider-specific
TaskSpec locally before queueing, then uses `spec.run_input` to accept a
required `--prompt` plus either piped stdin text or an explicit `--document`
path. It mounts a caller-supplied host document read-only into the container
at a helper-owned target path and asks the agent to explain that document in
one sentence. The current default provider is `codex`. To point it at this
repo's architecture overview, run either:

```bash
cat docs/specifications/00-Overview_and_Architecture.md | weft run --spec dockerized-agent --provider codex --prompt "Explain this document in one sentence."
```

or:

```bash
weft run --spec dockerized-agent --provider gemini --prompt "Explain this document in one sentence." --document docs/specifications/00-Overview_and_Architecture.md
```

This is the one public builtin for that lane. Provider choice stays an
explicit argument on the same TaskSpec instead of being split across multiple
near-duplicate fixed-provider builtins. The main caveats are:

- piped stdin is the tightest path when you want the shipped examples to obey
  a strict output-shape prompt such as "one sentence"; `--document` still
  proves late-bound Docker file mounts, but some providers may narrate their
  file-read step before the final answer
- the builtin currently defaults `opencode` to
  `spec.agent.model="openai/gpt-5"` when `--provider opencode` is selected
  without an explicit `--model`
- the builtin defaults to `authority_class="general"` so it stays
  representative; if you want a narrower read-only provider mode, copy it and
  set `authority_class="bounded"` explicitly where the provider supports it
- when `claude_code` is selected, Weft first
  preserves explicit portable auth such as `CLAUDE_CODE_OAUTH_TOKEN`,
  `ANTHROPIC_AUTH_TOKEN`, `ANTHROPIC_API_KEY`, or a Linux
  `~/.claude/.credentials.json`
- that explicit Claude example path also sets `IS_SANDBOX=1` so Claude treats
  the Docker container as a sandboxed runtime instead of rejecting workspace-
  write mode under root
- on macOS, if those Claude auth paths are absent, that explicit Claude example
  startup path attempts a runtime-only Keychain lookup and injects
  `CLAUDE_CODE_OAUTH_TOKEN` for that run only; it does not persist a Linux
  credential file, and it aborts startup if lookup fails

## Docker-Backed One-Shot `provider_cli`

The current Docker-backed agent lane is intentionally narrow. It is for
one-shot delegated `provider_cli` tasks only:

- `spec.type="agent"`
- `spec.agent.runtime="provider_cli"`
- `spec.agent.conversation_scope="per_message"`
- `spec.persistent=false`
- `spec.runner.name="docker"`
- selected provider has both a shipped Docker image recipe and an internal
  container runtime descriptor (`claude_code`, `codex`, `gemini`, `opencode`,
  and `qwen` today)

Use this when you want the agent CLI and its runtime inside a restricted
container, while still passing per-run mounts, environment variables, working
directory, and network policy through the normal task path. The current
Docker-backed `provider_cli` lane may also apply internal provider runtime
descriptors for provider-specific runtime mounts and other explicit defaults.
Current shipped defaults include:

- `codex`: optional writable `~/.codex`
- `gemini`: optional `GEMINI_API_KEY` forwarding plus a small generated
  runtime home seeded from a subset of `~/.gemini`
- `opencode`: allowlisted provider env forwarding
- `qwen`: optional writable `~/.qwen`
- `claude_code`: optional writable `~/.claude` and `~/.claude.json` plus
  portable auth env forwarding

If you want env-based auth in a Docker agent task, set it explicitly in
`spec.env` or through a runner environment profile. On macOS specifically,
Docker-backed `claude_code` needs portable auth because a host `claude.ai`
login lives in macOS Keychain and is not portable into the Linux container by
mount alone.

For agent tasks only, the Docker runner also supports
`spec.runner.options.work_item_mounts`, which resolves absolute host paths from
the raw work item at execution time and bind-mounts them into fixed container
targets. This is intentionally Docker-specific; it is not a generic core Weft
input-mount abstraction.

```jsonc
{
  "name": "docker-codex-review",
  "version": "1.0",
  "spec": {
    "type": "agent",
    "persistent": false,
    "agent": {
      "runtime": "provider_cli",
      "authority_class": "general",
      "conversation_scope": "per_message",
      "runtime_config": {
        "provider": "codex"
      }
    },
    "working_dir": "/Users/me/project",
    "runner": {
      "name": "docker",
      "environment_profile_ref": "dockerized_agent:dockerized_agent_environment_profile",
      "options": {}
    }
  }
}
```

`prepare-agent-images` is optional. It can warm the local image cache ahead of
time, but ordinary `weft run` still takes the normal path and builds on cache
miss when needed.

For the current builtin catalog and contract, see
[Builtin TaskSpecs](docs/specifications/10B-Builtin_TaskSpecs.md).

## Core Concepts

### Project Context

Weft uses a project-local metadata directory for isolation. By default that
directory is `.weft/`, similar to git repositories:

```text
myproject/
  .weft/
    broker.db        # SQLite default broker file
    tasks/           # Saved task specs
    pipelines/       # Saved pipeline specs
    autostart/       # Autostart manifests (lifecycle + defaults)
    outputs/         # Large output spillover
    logs/            # Centralized logging
    ...
```

You can override the metadata-directory name with `WEFT_DIRECTORY_NAME`
(for example `.engram`). Run `weft` commands from anywhere in the project tree;
discovery uses the configured metadata-directory name.

`weft init` follows the same targeting model as tools like `git init`: it
defaults to the current directory, or you can pass a positional directory to
initialize another root explicitly. It does not take `--context`; `--context`
is for commands that operate inside an already existing Weft project.

For non-file-backed backends such as Postgres, the configured metadata
directory still holds Weft metadata, logs, outputs, and autostart manifests,
but the broker target is resolved through SimpleBroker project configuration
rather than assuming an on-disk broker db under the default `.weft/` layout.
Weft scopes that broker project configuration under the metadata directory by
default: `.weft/broker.toml`.

### Selecting A Backend

SQLite remains the default. To use Postgres, install `weft[pg]` and then
declare the backend through SimpleBroker project config or Weft environment
variables.

Project-local `.weft/broker.toml`:

```toml
version = 1
backend = "postgres"
target = "postgresql://user:pass@host:5432/dbname"

[backend_options]
schema = "weft"
```

Environment-based selection:

```bash
export WEFT_BACKEND=postgres
export WEFT_BACKEND_TARGET='postgresql://user:pass@host:5432/dbname'
export WEFT_BACKEND_SCHEMA='weft'
```

Sparse launch environments such as cron or systemd can point Weft at a
dotenv-style file with `WEFT_ENV_FILE`. Weft loads that file before importing
the full CLI, so values in it participate in normal broker and context
resolution:

```bash
WEFT_ENV_FILE=/etc/weft/project.env weft status
WEFT_ENV_FILE=/etc/weft/project.env weft manager serve --context /srv/project
```

The file format is intentionally narrow: blank lines, full-line comments,
optional `export`, and `KEY=VALUE` assignments with unquoted, single-quoted, or
double-quoted values. It is not a shell script; Weft does not run command
substitution, variable interpolation, includes, or multiline parsing. Real
process environment values win over values from the file. `weft run --env` and
TaskSpec `spec.env` are task-process overlays, not Weft process bootstrap.

When Weft auto-discovers a project from a child directory, an existing local
broker target still wins over ambient env backend selection. That means
`.weft/broker.toml` is authoritative, and legacy sqlite project discovery
beats `WEFT_BACKEND=...` during upward discovery. Env-based backend selection
is the fallback when no project-local broker target has already claimed the
directory. A root `.broker.toml` belongs to standalone SimpleBroker and does
not redirect Weft by default.

If Postgres is selected without the plugin installed, Weft will fail with an
install hint for `uv add 'weft[pg]'`.

#### Quick Comparison

| | SQLite (default) | Postgres |
|---|---|---|
| Setup | Zero config | Requires running Postgres |
| Concurrency | Single-writer (fine for most workloads) | Full MVCC |
| Persistence | File on disk | Database server |
| Best for | Local dev, single-machine agents, CI | Multi-host, high-concurrency production |

SQLite is the right default for most users. Switch to Postgres when you need
multi-host task submission or high write concurrency.

#### Postgres Connection Budget

Weft uses SimpleBroker's multi-queue activity waiter API, so a long-lived
watcher shares one backend wait/listen path across the queues it watches
inside that process. It does not open one Postgres `LISTEN` connection per
watched queue. The important operational limit is therefore the number of
concurrent Weft processes, plus short-lived command and startup spikes.

For production Postgres deployments, give Weft its own connection budget rather
than relying on the application's normal database pool. A practical starting
point is a Postgres `max_connections` budget in the 200-300 range when Weft can
run many managers, consumers, CLI commands, or agents concurrently, then tune
from observed peak usage. If you put a pooler such as PgBouncer in front of
Postgres, make sure its mode preserves the notification behavior required by
`LISTEN`/`NOTIFY`; transaction-pooling modes that do not preserve listener
state are not a substitute for listener headroom.

### Task IDs (TIDs)

Every task receives a unique 64-bit SimpleBroker timestamp (hybrid microseconds + logical counter), typically 19 digits:

- **Full TID**: `1837025672140161024` (Unique task ID)
- **Short TID**: `0161024` (last 10 digits for convenience)
- Used for correlation across queues and process titles
- Monotonic within a context, format-compatible with time.time_ns()
- The spawn-request message ID becomes the task TID for the full lifecycle

### Queue Structure

Each task gets its own queues:

```
T{tid}.inbox      # Work messages to process
T{tid}.reserved   # Messages being processed (reservation pattern)
T{tid}.outbox     # Results and output
T{tid}.ctrl_in    # Control commands (STOP, STATUS, PING)
T{tid}.ctrl_out   # Status responses

weft.log.tasks           # Global state log (all tasks)
weft.spawn.requests      # Task spawn requests to manager
weft.state.managers       # Manager liveness tracking (runtime state)
weft.state.tid_mappings  # Short->full TID mappings (runtime state)
weft.state.streaming     # Active streaming sessions (runtime state)
```

Queues under `weft.state.*` are runtime-only and excluded from dumps by default.

### Reservation Pattern

Weft implements inbox -> reserved -> outbox flow for reliable message processing:

1. **Reserve**: Move message from inbox to reserved
2. **Process**: Execute work while message is in reserved
3. **Complete**: Write output to outbox, delete from reserved (or apply policy)

If a task crashes mid-work, the message remains in reserved for manual recovery or explicit requeue.

**Idempotency guidance**
- Single-message tasks may use `tid` as an idempotency key.
- Multi-message tasks should use the inbox/reserved message ID (timestamp).
- Recommended composite key: `tid:message_id`.

Configurable policies (`keep`, `requeue`, `clear`) control reserved queue behavior on errors.

### Managers

Persistent manager processes that:
- Monitor `weft.spawn.requests` for new tasks
- Launch child task processes
- Track process lifecycle
- Auto-terminate after idle timeout (default 600 seconds)
- Launch autostart tasks on boot

### Autostart Tasks

Manifest files in `.weft/autostart/*.json` are launched when the manager
starts. Autostart targets must reference stored task specs or pipelines; they
do not embed inline TaskSpecs.

```json
{
  "name": "queue-monitor",
  "target": { "type": "task", "name": "queue-monitor" },
  "policy": { "mode": "ensure" }
}
```

Control autostart behavior with:

- `weft init --no-autostart`
- `weft run --no-autostart`
- `WEFT_AUTOSTART_TASKS=false`

### Process Titles

Tasks update their process title for observability:

```bash
$ ps aux | grep weft
weft-proj-0161024:mytask:running
weft-proj-0161025:manager:completed
```

Format: `weft-{context_short}-{short_tid}:{name}:{status}[:details]`

## Going Deeper

| Topic | Where to look |
|-------|--------------|
| CLI surface and flags | [CLI Interface spec](docs/specifications/10-CLI_Interface.md) |
| Builtin task helpers | [Builtin TaskSpecs](docs/specifications/10B-Builtin_TaskSpecs.md) |
| Agent tasks and runner-specific Docker lane | [Agent Runtime spec](docs/specifications/13-Agent_Runtime.md) |
| Pipeline composition | [Pipeline spec](docs/specifications/12-Pipeline_Composition_and_UX.md) |
| TaskSpec schema reference | [TaskSpec spec](docs/specifications/02-TaskSpec.md) |
| Queue patterns and state | [Message Flow spec](docs/specifications/05-Message_Flow_and_State.md) |
| System invariants | [Invariants spec](docs/specifications/07-System_Invariants.md) |

## Command Reference

### Project Management

```bash
# Initialize new project
weft init [DIRECTORY] [--autostart/--no-autostart]

# Show system status
weft status [--all] [--status STATUS] [--json] [--watch] [--interval SECONDS] [--context PATH]

# Task detail view
weft task status TID [--process] [--watch] [--json] [--context PATH]
weft task tid [TID] [--pid PID] [--reverse FULL_TID] [--context PATH]

# List tasks
weft task list [--status STATUS] [--all] [--stats] [--json] [--context PATH]

# Manager lifecycle
weft manager start [--replace] [--context PATH]
weft manager serve [--replace] [--context PATH]
weft manager stop [TID] [--force] [--timeout SECONDS] [--context PATH]
weft manager list [--all] [--json] [--context PATH]
weft manager status TID [--json] [--context PATH]

# System maintenance
weft system builtins [--json]  # shipped builtin inventory
weft system tidy            # backend-native broker compaction
weft system dump -o FILE
weft system load -i FILE    # preflight import; exits 3 on alias conflicts

# Generate and store a reusable spec
weft spec generate --type task > my-task.json
weft spec create my-task --file my-task.json

# Validate a TaskSpec and optionally preflight runner/runtime availability
weft spec validate --type task FILE [--load-runner] [--preflight]
```

Stored specs are ordinary JSON files. If you want `weft run --spec ...` to
accept extra spec-owned CLI options, declare `spec.parameterization` or
`spec.run_input` in that TaskSpec. `--arg` and `--kw` are only for
`weft run --function`. For simple manual TaskSpec inputs, use a built-in
adapter such as `weft.builtins.run_input:arguments_payload` to copy declared
options into a flat JSON work payload, or
`weft.builtins.run_input:keyword_arguments_payload` to build a function
`{"kwargs": ...}` envelope. The `nonempty_*` variants reject blank string
values before queueing; they do not validate UUIDs, dates, or other
domain-specific formats.

Flat payload example:

```json
"run_input": {
  "adapter_ref": "weft.builtins.run_input:nonempty_arguments_payload",
  "arguments": {
    "case_id": {
      "type": "string",
      "required": true,
      "help": "Case ID to process"
    }
  }
}
```

Kwargs-envelope example:

```json
"run_input": {
  "adapter_ref": "weft.builtins.run_input:nonempty_keyword_arguments_payload",
  "arguments": {
    "case_id": {
      "type": "string",
      "required": true
    }
  }
}
```

Use `weft spec validate --preflight` when you want an ahead-of-time
availability check on the current machine. `weft run` does not do hidden
runtime preflight first; it submits the task, then the real execution path
either starts or fails with the concrete runner or agent error.
For Docker-backed one-shot `provider_cli` agent specs, preflight validates the
Docker lane and static descriptor requirements. It does not require the host
provider executable to exist, because the real provider CLI runs inside the
container.

### Task Execution

```bash
# Run command
weft run COMMAND [args...] [--context PATH]
weft run --spec NAME|PATH
weft run --pipeline NAME|PATH
weft run --function module:func [--arg VALUE] [--kw KEY=VALUE]

# Pipe raw stdin as the initial task input
printf "hello\n" | weft run -- python worker.py
printf "hello\n" | weft run --spec summarize.json
printf "hello\n" | weft run --pipeline etl-job
# --input is for explicit pipeline input and cannot be mixed with piped stdin.

# Execution options
--wait / --no-wait   # Wait for completion
--timeout N         # Timeout in seconds
--memory N          # Memory limit in MB
--cpu N            # CPU limit (percentage)
--env KEY=VALUE      # Environment variable
--name TEXT          # Explicit task name
--interactive / --non-interactive  # Line-oriented task IO
--stream-output / --no-stream-output  # Stream stdout/stderr to queues
--continuous / --once  # Continuously process spec queue messages
--autostart/--no-autostart  # Enable/disable autostart manifests
--arg VALUE          # Positional arg for --function (repeatable)
--kw KEY=VALUE       # Keyword arg for --function (repeatable)
--input TEXT         # Explicit pipeline input

# Get results
weft result TID [--timeout N] [--stream] [--json] [--error] [--context PATH]
weft result --all [--peek]
```

### Queue Operations

```bash
# Direct queue access
weft queue read QUEUE [--json] [--all]
weft queue write QUEUE [MESSAGE]
weft queue write --endpoint NAME [MESSAGE]
weft queue peek QUEUE [--json] [--all]
weft queue move SOURCE DEST [--all]
weft queue list [--json] [--stats] [--endpoints] [-p PATTERN]
weft queue resolve ENDPOINT_NAME [--json]
weft queue watch QUEUE [--json] [--peek]
weft queue delete QUEUE

# Broadcast and aliases
weft queue broadcast [MESSAGE] [--pattern GLOB]
printf "payload" | weft queue write QUEUE
printf "STOP" | weft queue broadcast --pattern 'T*.ctrl_in'
weft queue alias add ALIAS TARGET
weft queue alias remove ALIAS
weft queue alias list [--target QUEUE]
```

## Exit Codes

```bash
0   - Success
1   - General error
2   - Not found (task, queue, spec)
3   - Import conflict, such as `weft system load` alias conflicts
124 - Timeout
```

## Common Patterns

### Background Processing

```bash
# Launch task without waiting
$ weft run --no-wait ./background-job.sh

# Check status later
$ weft status
# Shows running tasks in the current context

# Get result when ready
$ weft result <tid>
```

### Pipeline Processing

```bash
# Run a stored pipeline and wait for its final output
$ weft run --pipeline etl-job --input '{"batch": 7}'

# Submit a pipeline and collect the result later
$ weft run --pipeline etl-job --no-wait
$ weft task status <pipeline-tid>
$ weft result <pipeline-tid>
```

### Persistent Watchers

```bash
# Save task spec
$ cat > .weft/tasks/file-watcher.json <<EOF
{
  "name": "file-watcher",
  "spec": {
    "type": "function",
    "function_target": "watchers.watch_directory",
    "timeout": null
  }
}
EOF

# Create autostart manifest
$ cat > .weft/autostart/file-watcher.json <<EOF
{
  "name": "file-watcher",
  "target": { "type": "task", "name": "file-watcher" },
  "policy": { "mode": "ensure" }
}
EOF

# Starts automatically with manager
$ weft run echo "start"

# Verify running
$ ps aux | grep weft
weft-proj-1234567:file-watcher:running
```

### Resource-Constrained Execution

```bash
# Limit memory and CPU
$ weft run --memory 100 --cpu 25 ./memory-intensive.py

# With timeout
$ weft run --timeout 60 --memory 500 ./task.sh
```

## Testing

Weft classifies backend coverage explicitly:

- `shared`: backend-agnostic tests intended to pass on both SQLite and Postgres
- `sqlite_only`: tests that intentionally validate SQLite or file-backed behavior

For local development, do not assume `pytest`, `mypy`, or `ruff` are installed
globally. This repo expects you to install the development extras once with
`uv sync --all-extras` and then run checks through the repo-managed toolchain.

The default local suite remains SQLite-first. To run the audited shared suite
against Postgres, use [`bin/pytest-pg`](./bin/pytest-pg), which provisions a
temporary Docker Postgres instance and installs `simplebroker-pg[dev]` into the
test environment alongside the published `simplebroker` dependency declared by
Weft.

## Development

For local verification, load the repo environment first. This repo's
[`.envrc`](./.envrc) sets `UV_PROJECT_ENVIRONMENT=.venv`, prepends the repo's
`bin/`, activates `.venv`, and, when present, wires a sibling
`../simplebroker` checkout into `PYTHONPATH`.

If you use `direnv`, run:

```bash
direnv allow
```

If you do not use `direnv`, source the file in your shell before running local
commands:

```bash
. ./.envrc
```

Then use the repo-managed toolchain. For deterministic local verification,
prefer the in-repo virtualenv binaries directly. That avoids the common failure
mode where an agent or developer assumes `pytest`, `mypy`, or `ruff` should
already exist on the global `PATH`, and it avoids ambiguity about which `uv`
wrapper or shell environment is active.

```bash
# Load repo environment first if direnv is not already doing it
. ./.envrc

# Install development dependencies
uv sync --all-extras

# Fast/default suite
./.venv/bin/python -m pytest

# Include slow tests when needed
./.venv/bin/python -m pytest -m ""

# Target the smallest relevant scope first
./.venv/bin/python -m pytest tests/tasks/ -q
./.venv/bin/python -m pytest tests/cli/ -q
./.venv/bin/python -m pytest tests/commands/test_run.py -q

# Shared Postgres-compatible suite
./.venv/bin/python bin/pytest-pg --all

# Static checks
./.venv/bin/ruff check weft tests
./.venv/bin/ruff format weft tests
./.venv/bin/mypy weft extensions/weft_docker extensions/weft_macos_sandbox

# Build
uv build
```

## Release

Weft uses a tag-driven release flow in GitHub Actions:

- [`.github/workflows/release-gate.yml`](./.github/workflows/release-gate.yml)
  runs on pushed `v*` tags, executes the full SQLite suite plus the
  PG-compatible suite via [`bin/pytest-pg`](./bin/pytest-pg), runs the
  Docker extension test suite on Ubuntu and the macOS sandbox extension test
  suite on macOS, and only invokes the publish workflow if every job passes.
  If the tag is moved while a gate is running, the older run is canceled and
  the gate refuses to publish from the stale tag state.
- [`.github/workflows/release-gate-docker.yml`](./.github/workflows/release-gate-docker.yml)
  runs on pushed `weft_docker/v*` tags, executes the Docker extension package
  tests on Ubuntu, and publishes the `weft-docker` package to PyPI if the tag
  still points at the tested commit.
- [`.github/workflows/release-gate-django.yml`](./.github/workflows/release-gate-django.yml)
  runs on pushed `weft_django/v*` tags, executes the Django integration package
  tests on Ubuntu, and publishes the `weft-django` package to PyPI if the tag
  still points at the tested commit.
- [`.github/workflows/release-gate-macos-sandbox.yml`](./.github/workflows/release-gate-macos-sandbox.yml)
  runs on pushed `weft_macos_sandbox/v*` tags, executes the macOS sandbox
  extension package tests on macOS, and publishes the `weft-macos-sandbox`
  package to PyPI if the tag still points at the tested commit.
- [`.github/workflows/release.yml`](./.github/workflows/release.yml) is a
  reusable workflow that can only be called from a release gate; it handles
  package build, PyPI publishing, signing, and, for the root `weft` package,
  GitHub Release creation from the tested commit SHA rather than re-resolving
  the mutable tag.

```bash
# Reuse the current version if it has never reached GitHub Release / PyPI;
# otherwise pass --version with a new X.Y.Z version
uv run python bin/release.py

# Explicitly release a new version
uv run python bin/release.py --version 0.1.1

# If an unpublished remote tag exists on the wrong commit, recreate it explicitly
uv run python bin/release.py --retag

# Preview the release steps without changing files or running commands
uv run python bin/release.py --dry-run
```

The release helper only requires a new version after that version has produced
either a GitHub Release or a PyPI publication. If the current repo version is
still unpublished, the helper can reuse it without rewriting version files.
It will still refuse to silently move an existing remote tag to a different
commit; use `--retag` if you want the helper to delete and recreate an
unpublished remote tag.

The helper also inspects the current versions in the first-party extension
packages:

- `extensions/weft_docker/pyproject.toml`
- `integrations/weft_django/pyproject.toml`
- `extensions/weft_macos_sandbox/pyproject.toml`

If any package version is still unpublished on PyPI, the helper pushes the
matching namespaced tag from the tested commit:

- `weft_docker/vX.Y.Z`
- `weft_django/vX.Y.Z`
- `weft_macos_sandbox/vX.Y.Z`

Those namespaced tags can also be pushed manually when you want to release just
one first-party package.

When the helper does need to bump the version, it updates both canonical
version sources:

- `pyproject.toml`
- `weft/_constants.py`

Before it tags and pushes, the helper runs:

1. The SQLite release precheck with xdist
2. The PG-compatible release precheck with `uv run bin/pytest-pg --all`
3. The Django integration tests
4. The Docker extension tests when Docker is available locally
5. The macOS sandbox extension tests when running on macOS

After the helper pushes `v0.1.1`, the release gate workflow will:

1. Run the full SQLite suite
2. Run the PG-compatible suite with `uv run bin/pytest-pg --all`
3. Run the Django integration tests on Ubuntu
4. Run the Docker extension tests on Ubuntu
5. Run the macOS sandbox extension tests on macOS
6. Confirm the tag still points at the tested commit
7. Invoke the package release workflow only if all suites pass
8. Build distributions with `uv build`
9. Publish to PyPI with `uv publish --trusted-publishing always dist/*`
10. Sign artifacts, create the GitHub Release, and upload the release files once PyPI succeeds

If the helper also pushes a namespaced package tag such as `weft_docker/vX.Y.Z`,
`weft_django/vX.Y.Z`, or `weft_macos_sandbox/vX.Y.Z`, the package-specific
release gates will:

1. Run the matching package test suite
2. Verify the namespaced tag still points at the tested commit
3. Build the package from its subdirectory
4. Publish the distribution to PyPI

Prerequisite:

- Configure the PyPI Trusted Publisher for `weft`, `weft-docker`,
  `weft-django`, and `weft-macos-sandbox`, each with the corresponding
  GitHub Actions workflow.

## Supervised Manager

Use `weft manager serve` when you want a persistent manager owned by `systemd`,
`launchd`, `supervisord`, or a similar service manager:

```bash
weft manager serve --context /path/to/project
```

`weft manager serve` runs the canonical manager in the foreground and keeps it alive
until it is explicitly stopped. It forces `idle_timeout=0.0` for that
invocation, so the manager does not self-exit for inactivity.

`weft manager start` is different. It starts a detached manager and exits, which
means the service manager would only supervise the short-lived CLI wrapper, not
the actual manager process.

Use `--replace` for operator-driven manager handoff:

```bash
weft manager serve --replace --context /path/to/project
weft manager start --replace --context /path/to/project
```

Replacement sends STOP to each selected active manager's `ctrl_in`, records
that owner as `superseded` in `weft.state.services`, reselects until no active
manager remains, then starts or serves the replacement. It does not wait for
stopped confirmation in v1, so there can be a short overlap while the old
manager consumes STOP and drains.

Operational notes:

- Put restart policy in the service manager, not in Weft.
- For password-bearing env files, prefer `WEFT_ENV_FILE=... weft manager serve`
  over `weft manager start`. Detached manager startup currently passes
  resolved config and broker target data through child process arguments, so it
  should not be treated as a secret-safe launcher.
- When `weft manager serve` runs inside Docker or another PID namespace while
  sharing a broker with future containers, Weft avoids registering
  container-local PIDs such as `1` as host-scoped process identities when it can
  detect the container. For production supervisors, prefer providing
  `WEFT_MANAGER_RUNTIME_HANDLE_JSON` with an explicit `external-supervisor`
  runtime handle. Runtime extensions such as `weft_docker` may register
  process-local liveness probes that can mark an external-supervisor handle
  stale sooner; missing or inconclusive probes fall back to normal heartbeat
  expiry.
- `weft manager stop` sends a graceful STOP to the active manager for the
  current context. `weft manager stop <tid>` targets an exact manager. An
  auto-restarting service manager may start the manager again unless the
  service itself is stopped.
- `weft.state.services` treats `superseded` as non-live service-owner evidence;
  manager convergence selects the lowest non-superseded live canonical manager.
- This minimal supervised mode does not add a separate Weft-side drain timeout
  or second-signal escalation. Configure the service manager's stop timeout to
  match the grace period you want for draining child tasks.

## Configuration

Environment variables:

- `WEFT_ENV_FILE` - Bootstrap dotenv-style file loaded before full CLI import
- `WEFT_MANAGER_LIFETIME_TIMEOUT` - Manager idle timeout (default: 600s)
- `WEFT_MANAGER_REUSE_ENABLED` - Keep manager running (default: true)
- `WEFT_AUTOSTART_TASKS` - Enable autostart (default: true)

## License

MIT
