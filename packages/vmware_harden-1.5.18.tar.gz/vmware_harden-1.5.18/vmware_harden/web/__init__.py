"""vmware-harden web dashboard."""
