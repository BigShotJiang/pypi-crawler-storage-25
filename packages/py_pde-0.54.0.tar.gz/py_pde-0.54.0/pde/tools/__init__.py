"""Package containing several tools required in py-pde.

.. autosummary::
   :nosignatures:

   cache
   config
   cuboid
   docstrings
   expressions
   ffmpeg
   math
   misc
   mpi
   output
   parse_duration
   plotting
   spectral
   typing

.. codeauthor:: David Zwicker <david.zwicker@ds.mpg.de>
"""
