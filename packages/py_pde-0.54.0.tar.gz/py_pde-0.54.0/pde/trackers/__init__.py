"""Classes for tracking simulation results in controlled interrupts.

Trackers are classes that periodically receive the state of the simulation to analyze,
store, or output it. The trackers defined in this module are:

.. autosummary::
   :nosignatures:

   ~trackers.CallbackTracker
   ~trackers.ProgressTracker
   ~trackers.PrintTracker
   ~trackers.PlotTracker
   ~trackers.LivePlotTracker
   ~trackers.DataTracker
   ~trackers.SteadyStateTracker
   ~trackers.RuntimeTracker
   ~trackers.ConsistencyTracker
   ~trackers.MaterialConservationTracker
   ~interactive.InteractivePlotTracker

Some trackers can be referenced by name for convenience when using them in simulations.
The list of supported names is returned by :func:`~pde.registered_trackers`.

Multiple trackers can be collected in a :class:`~base.TrackerCollection`, which provides
methods for handling them efficiently. Moreover, custom trackers can be implemented by
deriving from :class:`~.trackers.base.TrackerBase`. Note that trackers generally receive
a view into the current state, implying that they can adjust the state by modifying it
in-place. Moreover, trackers can abort the simulation by raising the special exception
:class:`StopIteration`.


For each tracker, the time at which the simulation is interrupted can be decided using
one of the following classes:

.. autosummary::
   :nosignatures:

   ~interrupts.FixedInterrupts
   ~interrupts.ConstantInterrupts
   ~interrupts.LogarithmicInterrupts
   ~interrupts.GeometricInterrupts
   ~interrupts.RealtimeInterrupts

In particular, interrupts can be specified conveniently using
:func:`~interrupts.parse_interrupt`.

Inheritance structure of the tracker classes:

.. inheritance-diagram::
      trackers.CallbackTracker
      trackers.ProgressTracker
      trackers.PrintTracker
      trackers.PlotTracker
      trackers.LivePlotTracker
      trackers.DataTracker
      trackers.SteadyStateTracker
      trackers.RuntimeTracker
      trackers.ConsistencyTracker
      interactive.InteractivePlotTracker
      pde.storage.base.StorageTracker
   :parts: 1

.. codeauthor:: David Zwicker <david.zwicker@ds.mpg.de>
"""

from .base import *  # noqa: F403
from .interactive import InteractivePlotTracker  # noqa: F401
from .interrupts import *  # noqa: F403
from .trackers import *  # noqa: F403
