use ndarray::Array1;
use rayon::prelude::*;
use serde::{Deserialize, Serialize};
use serde_json::Value as JsonValue;
use std::cmp::Ordering;
use std::collections::HashMap;
use std::path::Path;
use std::sync::Arc;

use super::backend::StorageBackend;
use super::bm25::Bm25Index;
use super::compaction::Compactor;
use super::graph::GraphManager;
use super::id_pool::IdPool;
use super::ivf::IvfIndex;
use super::live_codes::LiveCodesFile;
use super::metadata::{MetadataStore, VectorMetadata};
use super::rrf::{DEFAULT_RRF_K, DEFAULT_RRF_OVERSAMPLE, rrf_fuse};
use super::segment::{SegmentManager, SegmentRecord};
use super::wal::{Wal, WalEntry};
use crate::quantizer::CodeIndex;
use crate::quantizer::prod::ProdQuantizer;
pub(crate) mod filter;
use filter::{
    extract_in_condition, extract_indexable_eq, extract_nin_condition, extract_or_single_field_eq,
    extract_range_condition, get_nested_field, metadata_matches_filter, score_vectors_with_metric,
};

const QUANTIZER_STATE_FILE: &str = "quantizer.bin";
const INDEX_IDS_FILE: &str = "graph_ids.json";
const DELTA_IDS_FILE: &str = "delta_ids.json";
const ID_POOL_FILE: &str = "live_ids.bin";
const MANIFEST_SAVE_INTERVAL_OPS: usize = 64;
const ID_POOL_DENSE_MAGIC: &[u8; 8] = b"TQID2D1\0";
/// Sparse format: stores bytes/offsets/lens/alive only — hashes recomputed on load.
/// Saves 8 bytes × slot_count vs the raw bincode layout.
const ID_POOL_SPARSE_MAGIC: &[u8; 8] = b"TQID2S1\0";
/// Sparse+zstd format: same sparse payload, zstd-compressed on disk when beneficial.
const ID_POOL_SPARSE_ZSTD_MAGIC: &[u8; 8] = b"TQID2Z1\0";
/// Automatic maintenance: when segment count grows beyond this threshold,
/// a compaction checkpoint is triggered on WAL flush.
const AUTO_CHECKPOINT_SEGMENTS_THRESHOLD: usize = 64;

const LIVE_GAMMA_BYTES: usize = 4;
const LIVE_NORM_BYTES: usize = 4;
const LIVE_DELETED_BYTES: usize = 1;

/// Below this candidate count the brute-force inner loop runs sequentially (avoids
/// Rayon thread park/unpark overhead on small N). Above it, par_chunks is used.
/// Also used in search_batch to decide whether to parallelise across queries.
const SEQ_THRESHOLD: usize = 20_000;

/// Auto-planner: engage ANN automatically when N >= this threshold and an index exists.
const AUTO_ANN_THRESHOLD: usize = 10_000;
/// Auto-planner: fall back to brute-force when delta_slots > this fraction of N (num/den).
const AUTO_ANN_MAX_DELTA_NUM: usize = 1;
const AUTO_ANN_MAX_DELTA_DEN: usize = 5; // 20%

/// Default rerank-candidate oversampling factor as a function of vector dimension.
///
/// Per-candidate dequantize+score cost scales with `d`, and the level-0 HNSW search
/// loop visits roughly proportional to its `search_list_size`. At high `d`, a factor
/// of 20 makes ANN slower than brute-force (e.g. at d=1536 the level-0 search bloats
/// to ~200 visits × ~µs each before any rerank). Stepping the factor down at high `d`
/// keeps latency bounded with negligible recall loss because the full-LUT navigation
/// score is already accurate; the candidate buffer only insulates against beam misses.
///
/// `is_ann=true` returns ANN defaults; `false` returns brute-force defaults (which
/// don't have the level-0 traversal blow-up but still benefit from a dimension cap
/// on the rerank pool).
pub(crate) fn default_rerank_factor(d: usize, is_ann: bool) -> usize {
    if is_ann {
        if d <= 384 {
            20
        } else if d <= 1024 {
            8
        } else {
            4
        }
    } else if d <= 384 {
        10
    } else if d <= 1024 {
        6
    } else {
        4
    }
}

/// C1 (Fix B): dim-aware default for HNSW `ef_construction`.
/// Larger values produce higher-quality neighbour lists at build time, lifting
/// the search-time recall ceiling. Build is one-shot (not on the query hot path)
/// so we can afford a more thorough construction at low `d` where quantization
/// noise is most damaging to graph topology. At high `d` per-node build cost
/// is already significant; keep the historical default of 200.
///
/// Used only when the caller passes `ef_construction=None`. Explicit overrides
/// are respected.
pub fn default_ann_ef_construction(d: usize) -> usize {
    if d <= 384 {
        400
    } else if d <= 1024 {
        300
    } else {
        200
    }
}

/// Controls the precision used to store raw vectors in `live_vectors.bin` for reranking.
///
/// All options except `Disabled` enable exact second-pass rescoring: after the quantized pass
/// selects `rerank_factor × top_k` candidates, the stored vectors are used for precise scoring.
///
/// | Variant  | Bytes/vector | 100k×d=768 | Notes |
/// |----------|-------------|------------|-------|
/// | `Int8`   | d + 4       | 77 MB      | Default. Per-vector scaled INT8. Same recall as F16. |
/// | `Int4`   | ⌈d/2⌉ + 4   | 39 MB      | 2× smaller than Int8; slight recall cost at low d. |
/// | `F16`    | d × 2       | 154 MB     | Available for maximum precision. |
/// | `F32`    | d × 4       | 307 MB     | Legacy/backward-compat. |
/// | `Disabled` | 0         | 0 MB       | Dequantization only; zero recall gain for IP metric. |
///
/// Old databases without this field in manifest.json → serde default = `Disabled`.
#[derive(Serialize, Deserialize, Clone, Copy, Debug, PartialEq, Eq, Default)]
#[serde(rename_all = "lowercase")]
pub enum RerankPrecision {
    /// No live_vectors.bin; reranking uses dequantization. Zero disk overhead but also zero
    /// recall improvement for the IP metric (dequantized ≡ LUT score).
    #[default]
    Disabled,
    /// INT8 per-vector-scaled storage. Stride = d + 4 bytes (d × i8 + f32 scale).
    /// Default when `rerank=True`. Near-identical recall to F16 at half the disk.
    Int8,
    /// INT4 nibble-packed per-vector-scaled storage of the **raw** vector.
    /// Stride = ⌈d/2⌉ + 4 bytes. **Deprecated** — strictly dominated by
    /// `ResidualInt4` (same disk, much higher recall). Numpy validation on
    /// dbpedia-1536 b=4 showed Int4 raw rerank R@1 = 0.925 vs ResidualInt4
    /// R@1 = 0.995 at the same byte cost. Kept for backward compatibility
    /// with existing databases; new dbs should use `ResidualInt4`.
    Int4,
    /// **P12 (v0.8.3) — recommended low-disk rerank.** INT4-quantized
    /// **residual** = `vec − dequant(MSE codes) × doc_norm`, INT4-quantised
    /// with per-vector scale. Stride = ⌈d/2⌉ + 4 bytes (same as `Int4`).
    /// Because the residual has a much smaller dynamic range than the raw
    /// vector, 4 bits buy substantially more precision per dim — recall
    /// matches `Int8` at half the disk on b=4 production cells.
    ///
    /// Score is additive at query time:
    ///   * IP:     `final = cand_score + <q, residual_decoded>`
    ///   * Cosine: `final = cand_score + q_norm_inv × <q, residual_decoded>`
    /// (`doc_norm` is absorbed into the residual at encode time, so the
    /// rerank score does NOT multiply by it again at query time. See
    /// `live_rerank_score_residual_int4`.) No redundant code re-dequantization
    /// at query time.
    ResidualInt4,
    /// Raw f16 vectors. Stride = d × 2 bytes. Maximum precision for non-normalized vectors.
    F16,
    /// Raw f32 vectors. Stride = d × 4 bytes. Legacy/backward-compat option.
    F32,
}

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum DistanceMetric {
    Ip,
    Cosine,
    L2,
}

impl Default for DistanceMetric {
    fn default() -> Self {
        Self::Ip
    }
}

impl std::fmt::Display for DistanceMetric {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Ip => write!(f, "ip"),
            Self::Cosine => write!(f, "cosine"),
            Self::L2 => write!(f, "l2"),
        }
    }
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Manifest {
    pub version: u32,
    pub d: usize,
    pub b: usize,
    pub seed: u64,
    pub vector_count: u64,
    pub storage_uri: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub quantizer: Option<ProdQuantizer>,
    #[serde(default)]
    pub metric: DistanceMetric,
    #[serde(default)]
    pub index_state: Option<IndexState>,
    #[serde(default)]
    pub fast_mode: bool,
    #[serde(default = "default_rerank_enabled")]
    pub rerank_enabled: bool,
    /// Controls raw-vector rerank storage. Absent in old manifests → serde default = `Disabled`.
    /// `F16`/`F32` create `live_vectors.bin` on new DBs for exact fast reranking.
    #[serde(default)]
    pub rerank_precision: RerankPrecision,
    /// When true the engine L2-normalises every inserted vector and every query
    /// vector internally so that IP scoring equals cosine similarity.  Callers
    /// that already emit unit vectors (e.g. Axon RAG) can set this to avoid
    /// repeating the normalisation themselves.
    #[serde(default)]
    pub normalize: bool,
    /// Which quantizer variant is in use: `"dense"` (default, Haar-uniform QR) or `"srht"` (structured fast path).
    /// `"exact"` is accepted as a backward-compatible alias for `"dense"`.
    /// Persisted so reopened DBs load the correct `quantizer.bin`.
    #[serde(default)]
    pub quantizer_type: String,
}

fn default_rerank_enabled() -> bool {
    true
}

#[inline]
fn has_meaningful_metadata(meta: &VectorMetadata) -> bool {
    !meta.properties.is_empty() || meta.document.is_some()
}

/// Returns true when `resolve_filter_via_index()` fully resolves `filter` with no
/// additional per-candidate evaluation needed.  Pure-$eq, $in, $nin, single-field $or,
/// and single-field range conditions are all exact — callers can skip the post-scan.
fn filter_is_exact_index(filter: &HashMap<String, JsonValue>) -> bool {
    // Pure equality conditions (existing behaviour).
    if let Some(eqs) = extract_indexable_eq(filter) {
        return eqs.len() == filter.len();
    }
    // Single-field $in / $nin / single-field $or / single-field range.
    extract_in_condition(filter).is_some()
        || extract_nin_condition(filter).is_some()
        || extract_or_single_field_eq(filter).is_some()
        || extract_range_condition(filter).is_some()
}

fn intersect_sorted_slots(a: &[u32], b: &[u32]) -> Vec<u32> {
    let mut out = Vec::new();
    let mut i = 0usize;
    let mut j = 0usize;
    while i < a.len() && j < b.len() {
        match a[i].cmp(&b[j]) {
            std::cmp::Ordering::Equal => {
                out.push(a[i]);
                i += 1;
                j += 1;
            }
            std::cmp::Ordering::Less => i += 1,
            std::cmp::Ordering::Greater => j += 1,
        }
    }
    out
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct IndexState {
    pub max_degree: usize,
    #[serde(default = "default_ef_construction")]
    pub ef_construction: usize,
    pub search_list_size: usize,
    pub alpha: f64,
    pub indexed_nodes: usize,
}

fn default_ef_construction() -> usize {
    200
}

impl Manifest {
    fn save<P: AsRef<std::path::Path>>(
        &self,
        path: P,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let json = serde_json::to_string_pretty(self)?;
        std::fs::write(path, json)?;
        Ok(())
    }

    pub fn load<P: AsRef<std::path::Path>>(
        path: P,
    ) -> Result<Self, Box<dyn std::error::Error + Send + Sync>> {
        let json = std::fs::read_to_string(path)?;
        Ok(serde_json::from_str(&json)?)
    }
}

#[derive(Debug, Clone)]
pub struct BatchWriteFailure {
    pub index: usize,
    pub id: String,
    pub error: String,
}

#[derive(Debug)]
pub struct BatchWriteReport {
    pub ok: Vec<String>,
    pub failed: Vec<BatchWriteFailure>,
    pub applied: usize,
}

#[derive(Debug, Clone)]
pub struct BatchWriteItem {
    pub id: String,
    pub vector: Vec<f32>,
    pub metadata: HashMap<String, JsonValue>,
    pub document: Option<String>,
}

#[derive(Debug, Clone)]
pub struct GetResult {
    pub id: String,
    pub metadata: HashMap<String, JsonValue>,
    pub document: Option<String>,
}

#[derive(Debug, Clone)]
pub struct SearchResult {
    pub id: String,
    pub score: f64,
    pub metadata: HashMap<String, JsonValue>,
    pub document: Option<String>,
}

#[derive(Debug, Clone)]
pub struct DbStats {
    pub vector_count: u64,
    pub segment_count: usize,
    pub buffered_vectors: usize,
    pub d: usize,
    pub b: usize,
    pub metric: String,
    pub total_disk_bytes: u64,
    pub has_index: bool,
    pub index_nodes: usize,
    pub live_codes_bytes: usize,
    pub live_slot_count: usize,
    pub live_id_count: usize,
    pub live_vectors_count: usize,
    pub live_vectors_bytes_estimate: usize,
    pub metadata_entries: usize,
    pub metadata_bytes_estimate: usize,
    pub ann_slot_count: usize,
    pub graph_nodes: usize,
    /// Number of vectors in the delta overlay (inserted after last `create_index()`).
    /// When this grows large, consider calling `create_index()` again to merge.
    pub delta_size: usize,
}

pub struct TurboQuantEngine {
    pub d: usize,
    pub b: usize,
    pub quantizer: ProdQuantizer,
    pub manifest: Manifest,
    pub metric: DistanceMetric,
    pub rerank_enabled: bool,

    backend: Arc<StorageBackend>,
    wal: Wal,
    wal_buffer: Vec<WalEntry>,
    wal_flush_threshold: usize,
    segments: SegmentManager,
    metadata: MetadataStore,
    /// BM25 sparse-retrieval sidecar. Populated only when documents are inserted;
    /// flushes alongside `metadata` and is rebuilt from `metadata`'s docs on cold
    /// open if `bm25.idx` is missing or invalid.
    bm25: Bm25Index,
    graph: GraphManager,
    local_dir: String,

    index_ids: Vec<u32>,
    /// Slots inserted after the last `create_index()` call — the "delta" overlay.
    /// ANN search queries both the HNSW graph and these slots (brute-force).
    /// Cleared on every `create_index()` and persisted to `delta_ids.json`.
    delta_slots: Vec<u32>,
    live_codes: LiveCodesFile,
    live_vraw: Option<LiveCodesFile>,
    id_pool: IdPool,
    index_ids_dirty: bool,
    delta_slots_dirty: bool,
    pending_manifest_updates: usize,
    /// True when at least one delete has been issued since the last compaction.
    /// When false, `live_compact_slab` is skipped on WAL flush — a pure insert
    /// workload never needs to compact (no dead slots to remove).
    has_pending_deletes: bool,
    /// When true, input vectors and query vectors are L2-normalised internally
    /// before quantisation / scoring so that IP ≡ cosine similarity.
    pub normalize: bool,
    /// Optional IVF coarse index — loaded at open if `ivf.bin` exists.
    ivf: Option<IvfIndex>,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum BatchWriteMode {
    Insert,
    Upsert,
    Update,
}

impl TurboQuantEngine {
    pub fn open(
        uri: &str,
        local_dir: &str,
        d: usize,
        b: usize,
        seed: u64,
    ) -> Result<Self, Box<dyn std::error::Error + Send + Sync>> {
        Self::open_with_metric(uri, local_dir, d, b, seed, DistanceMetric::Ip)
    }

    /// Open (or create) with O(d log d) SRHT fast-path quantizer.
    /// Equivalent to `open` but uses SRHT for both MSE rotation and QJL projection.
    pub fn open_fast(
        uri: &str,
        local_dir: &str,
        d: usize,
        b: usize,
        seed: u64,
    ) -> Result<Self, Box<dyn std::error::Error + Send + Sync>> {
        Self::open_with_metric_and_rerank(
            uri,
            local_dir,
            d,
            b,
            seed,
            DistanceMetric::Ip,
            true,
            true,
        )
    }

    pub fn open_with_metric(
        uri: &str,
        local_dir: &str,
        d: usize,
        b: usize,
        seed: u64,
        metric: DistanceMetric,
    ) -> Result<Self, Box<dyn std::error::Error + Send + Sync>> {
        Self::open_with_metric_and_rerank(uri, local_dir, d, b, seed, metric, true, false)
    }

    pub fn open_with_metric_and_rerank(
        uri: &str,
        local_dir: &str,
        d: usize,
        b: usize,
        seed: u64,
        metric: DistanceMetric,
        rerank: bool,
        fast_mode: bool,
    ) -> Result<Self, Box<dyn std::error::Error + Send + Sync>> {
        let precision = if rerank {
            RerankPrecision::F32
        } else {
            RerankPrecision::Disabled
        };
        Self::open_with_options(
            uri, local_dir, d, b, seed, metric, rerank, fast_mode, precision, None, false, None,
        )
    }

    pub fn open_with_options(
        uri: &str,
        local_dir: &str,
        d: usize,
        b: usize,
        seed: u64,
        metric: DistanceMetric,
        rerank: bool,
        fast_mode: bool,
        rerank_precision: RerankPrecision,
        wal_flush_threshold: Option<usize>,
        normalize: bool,
        quantizer_type: Option<String>,
    ) -> Result<Self, Box<dyn std::error::Error + Send + Sync>> {
        std::fs::create_dir_all(local_dir)?;
        let manifest_path = format!("{}/manifest.json", local_dir);
        let wal_path = format!("{}/wal.log", local_dir);
        let metadata_path = format!("{}/metadata.bin", local_dir);

        let backend = Arc::new(StorageBackend::from_uri(uri)?);

        let (manifest, quantizer) = if Path::new(&manifest_path).exists() {
            let m = Manifest::load(&manifest_path)?;
            if m.d != d {
                return Err(format!(
                    "dimension mismatch: manifest has d={}, requested d={}",
                    m.d, d
                )
                .into());
            }
            if m.b != b {
                return Err(
                    format!("bits mismatch: manifest has b={}, requested b={}", m.b, b).into(),
                );
            }
            if m.metric != metric {
                return Err(format!(
                    "metric mismatch: manifest has {:?}, requested {:?}",
                    m.metric, metric
                )
                .into());
            }
            let q = load_quantizer_state(local_dir, &backend)?;
            (m, q)
        } else if let Ok(data) = backend.read("manifest.json") {
            let m: Manifest = serde_json::from_slice(&data)?;
            if m.d != d {
                return Err(format!(
                    "dimension mismatch: manifest has d={}, requested d={}",
                    m.d, d
                )
                .into());
            }
            if m.b != b {
                return Err(
                    format!("bits mismatch: manifest has b={}, requested b={}", m.b, b).into(),
                );
            }
            if m.metric != metric {
                return Err(format!(
                    "metric mismatch: manifest has {:?}, requested {:?}",
                    m.metric, metric
                )
                .into());
            }
            let q = load_quantizer_state(local_dir, &backend)?;
            (m, q)
        } else {
            let qt = quantizer_type.as_deref().unwrap_or("dense");
            let is_dense = qt == "dense" || qt == "exact"; // "exact" is a legacy alias
            let q = if is_dense && fast_mode {
                ProdQuantizer::new_dense_fast(d, b, seed)
            } else if is_dense {
                ProdQuantizer::new_dense(d, b, seed)
            } else if fast_mode {
                ProdQuantizer::new_srht(d, b, seed)
            } else {
                ProdQuantizer::new(d, b, seed)
            };
            let m = Manifest {
                version: 2,
                d,
                b,
                seed,
                vector_count: 0,
                storage_uri: uri.to_string(),
                quantizer: None,
                metric: metric.clone(),
                index_state: None,
                rerank_enabled: rerank,
                fast_mode,
                rerank_precision,
                normalize,
                quantizer_type: qt.to_string(),
            };
            save_quantizer_state(local_dir, &backend, &q)?;
            m.save(&manifest_path)?;
            backend.write("manifest.json", &serde_json::to_vec_pretty(&m)?)?;
            // Create an empty live_vectors.bin so that insert_batch can write raw vectors
            // immediately. Only when the user explicitly opts into exact reranking.
            if !matches!(rerank_precision, RerankPrecision::Disabled) {
                let vraw_path = Path::new(local_dir).join("live_vectors.bin");
                if !vraw_path.exists() {
                    std::fs::File::create(&vraw_path)?;
                }
            }
            (m, q)
        };

        let mut wal = Wal::open(&wal_path)?;
        wal.set_quantizer(std::sync::Arc::new(quantizer.clone()));
        // Recover from any interrupted compaction before loading segments.
        Compactor::new(backend.clone()).recover_if_needed()?;
        let segments = SegmentManager::open(backend.clone())?;
        let metadata = MetadataStore::open(&metadata_path)?;
        let bm25_path = Path::new(local_dir).join("bm25.idx");
        let mut bm25 = Bm25Index::open(bm25_path)?;
        // Cold-start fallback: if the sidecar was missing/corrupt but the metadata
        // store already has documents (e.g. an upgrade from a pre-BM25 release),
        // rebuild from those docs. After `Database.open()` returns, BM25 is always
        // queryable without a manual rebuild step.
        if bm25.is_empty() && metadata.iter_docs().next().is_some() {
            for (slot, doc) in metadata.iter_docs() {
                bm25.put(slot, doc);
            }
        }
        let graph = GraphManager::open(backend.clone(), local_dir)?;

        // Use quantizer.n (not manifest.d.next_power_of_two()) so that exact mode (n=d)
        // and SRHT mode (n=next_power_of_two(d)) both get the correct stride.
        // fast_mode never writes or reads QJL bytes — omit from stride to save disk/RAM.
        let qjl_len = if quantizer.fast_mode {
            0
        } else {
            quantizer.n.div_ceil(8)
        };
        let mse_len = (quantizer.n * quantizer.mse_bits_per_idx()).div_ceil(8);
        let stride = mse_len + qjl_len + LIVE_GAMMA_BYTES + LIVE_NORM_BYTES + LIVE_DELETED_BYTES;
        let live_codes = LiveCodesFile::open(Path::new(local_dir).join("live_codes.bin"), stride)?;
        // A1: hint OS to prefetch live_codes.bin into page cache. Reduces cold-cache
        // penalty on the first few queries after open. Unix-only (no-op on Windows).
        live_codes.advise_willneed();
        let live_vraw_path = Path::new(local_dir).join("live_vectors.bin");
        let live_vraw = if manifest.rerank_enabled
            && live_vraw_path.exists()
            && !matches!(manifest.rerank_precision, RerankPrecision::Disabled)
        {
            let vstride = match manifest.rerank_precision {
                RerankPrecision::F32 => manifest.d * 4,
                RerankPrecision::F16 => manifest.d * 2,
                RerankPrecision::Int8 => manifest.d + 4,
                RerankPrecision::Int4 => (manifest.d + 1) / 2 + 4,
                RerankPrecision::ResidualInt4 => (manifest.d + 1) / 2 + 4,
                RerankPrecision::Disabled => manifest.d * 4, // unreachable, but must be valid
            };
            let vraw = LiveCodesFile::open(live_vraw_path, vstride)?;
            // Random-access pattern (ANN rerank reads scattered slots); hint to OS.
            vraw.advise_random();
            Some(vraw)
        } else {
            None
        };

        let normalize_flag = normalize || manifest.normalize;
        let delta_slots = load_delta_slots(local_dir, &backend).unwrap_or_default();
        let mut engine = Self {
            d: manifest.d,
            b: manifest.b,
            quantizer,
            manifest: manifest.clone(),
            metric,
            backend,
            wal,
            wal_buffer: Vec::new(),
            wal_flush_threshold: wal_flush_threshold.unwrap_or(5_000),
            segments,
            metadata,
            bm25,
            graph,
            local_dir: local_dir.to_string(),
            index_ids: load_index_ids(local_dir).unwrap_or_default(),
            delta_slots,
            live_codes,
            live_vraw,
            id_pool: IdPool::new(),
            index_ids_dirty: false,
            delta_slots_dirty: false,
            pending_manifest_updates: 0,
            has_pending_deletes: false,
            rerank_enabled: manifest.rerank_enabled,
            normalize: normalize_flag,
            ivf: None,
        };

        let id_pool_loaded = if let Ok(ip) = load_id_pool(local_dir, &engine.backend) {
            engine.id_pool = ip;
            // live_codes.open() sets len = capacity (file size / stride) because the file
            // is pre-allocated in GROW_SLOTS increments.  Correct len to the actual number
            // of populated slots so that the next alloc_slot() returns the right index.
            let slot_count = engine.id_pool.slot_count();
            engine.live_codes.set_len(slot_count);
            if let Some(vraw) = engine.live_vraw.as_mut() {
                vraw.set_len(slot_count);
            }
            // Carry forward any pre-existing tombstones so that the next
            // flush_wal_to_segment() will call live_compact_slab() even if no
            // new deletes are issued during this session.
            engine.has_pending_deletes =
                engine.id_pool.active_count() < engine.id_pool.slot_count();
            true
        } else {
            false
        };

        let pending = Wal::replay(&wal_path, Some(&engine.quantizer))?;
        if !pending.is_empty() {
            engine.apply_wal_entries_to_live_state(&pending, !id_pool_loaded)?;
            if pending.iter().any(|entry| entry.is_deleted) {
                engine.has_pending_deletes = true;
            }
            engine.wal_buffer.extend(pending);
            engine.flush_wal_to_segment()?;
        } else if !id_pool_loaded && engine.live_codes.len() > 0 {
            return Err(
                "live_ids.bin missing and WAL is empty; database state appears corrupt".into(),
            );
        }
        // Load IVF index if present. Defense-in-depth for v0.8.2 fix #1:
        // even though `live_compact_slab` removes `ivf.bin` on compaction,
        // a Windows file-lock or permission error could leave a stale file
        // on disk. Validate the loaded IVF's cluster_map length against the
        // current id_pool slot count; if they disagree, the IVF references
        // the pre-compaction slot space and we must drop it (and clean up
        // the file so the next reopen is fast).
        let ivf_path = Path::new(local_dir).join("ivf.bin");
        if ivf_path.exists() {
            if let Some(ivf) = IvfIndex::load(&ivf_path).ok() {
                let expected = engine.id_pool.slot_count();
                if !ivf.cluster_map.is_empty() && ivf.cluster_map.len() != expected {
                    eprintln!(
                        "WARNING: ivf.bin references {} slots but id_pool has {}; \
                         dropping stale IVF index from a previous compaction.",
                        ivf.cluster_map.len(),
                        expected
                    );
                    let _ = std::fs::remove_file(&ivf_path);
                    let _ = engine.backend.delete("ivf.bin");
                } else {
                    engine.ivf = Some(ivf);
                }
            }
        }
        Ok(engine)
    }

    pub fn insert(
        &mut self,
        id: String,
        vector: &Array1<f64>,
        metadata: HashMap<String, JsonValue>,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        self.insert_with_document(id, vector, metadata, None)
    }

    pub fn insert_with_document(
        &mut self,
        id: String,
        vector: &Array1<f64>,
        metadata: HashMap<String, JsonValue>,
        document: Option<String>,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        if self.id_pool.contains(&id) {
            return Err(format!("ID '{}' already exists", id).into());
        }
        self.write_vector_entry(id, vector, metadata, document, false)
    }

    pub fn upsert_with_document(
        &mut self,
        id: String,
        vector: &Array1<f64>,
        metadata: HashMap<String, JsonValue>,
        document: Option<String>,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        self.write_vector_entry(id, vector, metadata, document, false)
    }

    pub fn update_with_document(
        &mut self,
        id: String,
        vector: &Array1<f64>,
        metadata: HashMap<String, JsonValue>,
        document: Option<String>,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        if !self.id_pool.contains(&id) {
            return Err(format!("ID '{}' does not exist", id).into());
        }
        self.write_vector_entry(id, vector, metadata, document, false)
    }

    pub fn insert_many(
        &mut self,
        items: Vec<BatchWriteItem>,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        self.insert_many_with_mode(items, BatchWriteMode::Insert)
    }
    pub fn upsert_many(
        &mut self,
        items: Vec<BatchWriteItem>,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        self.insert_many_with_mode(items, BatchWriteMode::Upsert)
    }
    pub fn update_many(
        &mut self,
        items: Vec<BatchWriteItem>,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        self.insert_many_with_mode(items, BatchWriteMode::Update)
    }

    pub fn delete(&mut self, id: String) -> Result<bool, Box<dyn std::error::Error + Send + Sync>> {
        if !self.id_pool.contains(&id) {
            return Ok(false);
        }
        let entry = WalEntry {
            id: id.clone(),
            quantized_indices: Vec::new(),
            qjl_bits: Vec::new(),
            gamma: 0.0,
            norm: 0.0,
            metadata_json: "{}".to_string(),
            is_deleted: true,
        };
        self.wal.append(&entry, false)?;
        self.wal_buffer.push(entry);
        self.has_pending_deletes = true;
        self.live_delete_slot(&id);
        self.invalidate_index_state()?;
        self.maybe_persist_state(false)?;
        if self.wal_buffer.len() >= self.wal_flush_threshold {
            self.flush_wal_to_segment()?;
        }
        Ok(true)
    }

    pub fn get(
        &self,
        id: &str,
    ) -> Result<Option<GetResult>, Box<dyn std::error::Error + Send + Sync>> {
        let Some(slot) = self.id_pool.get_slot(id) else {
            return Ok(None);
        };
        let meta = self.metadata.get(slot)?.unwrap_or_default();
        Ok(Some(GetResult {
            id: id.to_string(),
            metadata: meta.properties,
            document: meta.document,
        }))
    }

    pub fn get_many(
        &self,
        ids: &[String],
    ) -> Result<Vec<Option<GetResult>>, Box<dyn std::error::Error + Send + Sync>> {
        let mut out = Vec::with_capacity(ids.len());
        let mut slots = Vec::new();
        // Map slot → list of output positions (handles duplicate IDs).
        let mut slot_to_indices: HashMap<u32, Vec<usize>> = HashMap::new();

        for (i, id) in ids.iter().enumerate() {
            if let Some(slot) = self.id_pool.get_slot(id) {
                slot_to_indices.entry(slot).or_default().push(i);
                slots.push(slot);
            }
            out.push(None);
        }
        slots.sort_unstable(); // needed for dedup to catch non-adjacent duplicates
        slots.dedup(); // unique slots for metadata fetch

        if !slots.is_empty() {
            let meta_map = self.metadata.get_many(&slots)?;
            for (slot, indices) in slot_to_indices {
                let meta = meta_map.get(&slot).cloned().unwrap_or_default();
                for idx in indices {
                    out[idx] = Some(GetResult {
                        id: ids[idx].clone(),
                        metadata: meta.properties.clone(),
                        document: meta.document.clone(),
                    });
                }
            }
        }
        Ok(out)
    }

    pub fn list_all(&self) -> Vec<String> {
        self.id_pool
            .iter_active()
            .into_iter()
            .map(|(id, _)| id)
            .collect()
    }

    /// Return IDs with optional metadata filter and pagination.
    pub fn list_with_filter_page(
        &self,
        filter: Option<&HashMap<String, JsonValue>>,
        limit: Option<usize>,
        offset: usize,
    ) -> Result<Vec<String>, Box<dyn std::error::Error + Send + Sync>> {
        let active = self.id_pool.iter_active();
        let cap = limit.unwrap_or(usize::MAX);
        if let Some(f) = filter {
            let slots: Vec<u32> = active.iter().map(|(_, s)| *s).collect();
            let meta_map = self.metadata.get_many_properties(&slots)?;
            let empty_props: HashMap<String, JsonValue> = HashMap::new();
            let ids: Vec<String> = active
                .iter()
                .filter(|(_, slot)| {
                    let props = meta_map.get(slot).copied().unwrap_or(&empty_props);
                    metadata_matches_filter(props, f)
                })
                .map(|(id, _)| id.clone())
                .skip(offset)
                .take(cap)
                .collect();
            Ok(ids)
        } else {
            let ids: Vec<String> = active
                .into_iter()
                .map(|(id, _)| id)
                .skip(offset)
                .take(cap)
                .collect();
            Ok(ids)
        }
    }

    /// Return a `{value: count}` map of all unique values of `field` across active vectors.
    ///
    /// Supports dotted paths (e.g. `"meta.source"`) using the same nested-field resolution
    /// as the filter system.  Non-string values are stringified via their JSON representation.
    /// O(n) scan — identical cost to a filtered `count()`.
    pub fn list_metadata_values(
        &self,
        field: &str,
    ) -> Result<HashMap<String, usize>, Box<dyn std::error::Error + Send + Sync>> {
        let slots = self.id_pool.iter_active_slots();
        let meta_map = self.metadata.get_many_properties(&slots)?;
        let mut counts: HashMap<String, usize> = HashMap::new();
        for slot in &slots {
            if let Some(props) = meta_map.get(slot) {
                if let Some(val) = get_nested_field(props, field) {
                    let key = match val {
                        JsonValue::String(s) => s.clone(),
                        other => other.to_string(),
                    };
                    *counts.entry(key).or_insert(0) += 1;
                }
            }
        }
        Ok(counts)
    }

    /// Update metadata and/or document for an existing vector without re-quantising.
    ///
    /// The quantised codes and any stored raw vector are untouched — only the
    /// metadata store is written. Errors if the ID does not exist.
    pub fn update_metadata_only(
        &mut self,
        id: &str,
        metadata: HashMap<String, JsonValue>,
        document: Option<String>,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let Some(slot) = self.id_pool.get_slot(id) else {
            return Err(format!("ID '{}' does not exist", id).into());
        };
        let existing = self.metadata.get(slot)?.unwrap_or_default();
        let new_meta = VectorMetadata {
            // Explicit non-empty map replaces; empty map preserves existing.
            properties: if metadata.is_empty() {
                existing.properties
            } else {
                metadata
            },
            // Explicit Some replaces; None preserves existing document.
            document: document.or(existing.document),
        };
        if has_meaningful_metadata(&new_meta) {
            self.metadata.put(slot, &new_meta)?;
        } else {
            self.metadata.delete(slot)?;
        }
        match new_meta.document.as_deref() {
            Some(doc) if !doc.is_empty() => self.bm25.put(slot, doc),
            _ => self.bm25.delete(slot),
        }
        Ok(())
    }

    /// Score documents for `query_text` using BM25 over the sparse index.
    ///
    /// Results are returned as `(id, score)` pairs sorted by descending score, with
    /// at most `top_k` entries. Empty queries, an empty index, or `top_k == 0` all
    /// return an empty vector. `filter`, when supplied, must be a sorted-unique slot
    /// list (typically produced by the metadata pre-filter pipeline) — only those
    /// slots are scored.
    pub fn search_bm25(
        &self,
        query_text: &str,
        top_k: usize,
        filter: Option<&[u32]>,
    ) -> Result<Vec<(String, f32)>, Box<dyn std::error::Error + Send + Sync>> {
        let scored = self.bm25.search(query_text, top_k, filter);
        let mut out = Vec::with_capacity(scored.len());
        for (slot, score) in scored {
            // A slot may be tombstoned between bm25.put and search if the user issued
            // a delete and the tombstone hasn't propagated to bm25 yet (it always does
            // synchronously today, but defend against future drift). Skip dead slots.
            if let Some(id) = self.id_pool.get_str(slot) {
                out.push((id.to_string(), score));
            }
        }
        Ok(out)
    }

    /// Number of documents currently indexed by BM25. Useful for tests, stats output,
    /// and the auto-planner deciding whether sparse search is even possible.
    pub fn bm25_doc_count(&self) -> u32 {
        self.bm25.n_docs()
    }

    /// Hybrid search: dense vector retrieval + BM25 sparse retrieval, fused via RRF.
    ///
    /// Each retriever is asked for `oversample × top_k` candidates so RRF has room
    /// to find consensus picks that don't lead either list. `text_weight ∈ [0, 1]`
    /// controls the BM25 contribution: `0.0` collapses to pure dense, `1.0` to pure
    /// BM25 (with the dense list still consulted for metadata enrichment).
    ///
    /// Pass `None` for `text_weight` / `rrf_k` / `oversample` to use the defaults
    /// (`0.5` weight, `60.0` k, `4×` oversample) that match the documented hybrid
    /// behaviour.
    #[allow(clippy::too_many_arguments)]
    pub fn search_hybrid(
        &self,
        query_vec: &Array1<f64>,
        query_text: &str,
        top_k: usize,
        filter: Option<&HashMap<String, JsonValue>>,
        ann_search_list_size: Option<usize>,
        use_ann: bool,
        rerank_factor: Option<usize>,
        text_weight: Option<f32>,
        rrf_k: Option<f32>,
        oversample: Option<usize>,
        include_id: bool,
        include_metadata: bool,
        include_document: bool,
    ) -> Result<Vec<SearchResult>, Box<dyn std::error::Error + Send + Sync>> {
        if top_k == 0 {
            return Ok(Vec::new());
        }
        let text_weight = text_weight.unwrap_or(0.5).clamp(0.0, 1.0);
        let rrf_k = rrf_k.unwrap_or(DEFAULT_RRF_K).max(1.0);
        let oversample = oversample.unwrap_or(DEFAULT_RRF_OVERSAMPLE).max(1);
        let oversampled_k = top_k.saturating_mul(oversample);

        // BM25 doesn't share the dense path's filter machinery, so we don't push the
        // filter into the BM25 leg directly — it's evaluated as a post-filter on
        // BM25-only fused slots below. The dense path always applies the filter, so
        // any slot that came from the dense leg is already filter-correct.
        let bm25_filter: Option<&[u32]> = None;

        // Run dense and BM25 concurrently. Both are read-only on `&self` so this
        // is safe with `rayon::join`. BM25 is CPU-light next to the dense path,
        // but parallelism still hides the BM25 latency for large top_k.
        let (dense_r, bm25_r) = rayon::join(
            || {
                self.search_with_filter_and_ann_include(
                    query_vec,
                    oversampled_k,
                    filter,
                    ann_search_list_size,
                    use_ann,
                    rerank_factor,
                    true,
                    true,
                    true,
                )
            },
            || self.search_bm25(query_text, oversampled_k, bm25_filter),
        );
        let dense_r = dense_r?;
        let bm25_r = bm25_r?;

        let dense_slots: Vec<u32> = dense_r
            .iter()
            .filter_map(|r| self.id_pool.get_slot(&r.id))
            .collect();
        let bm25_slots: Vec<u32> = bm25_r
            .iter()
            .filter_map(|(id, _)| self.id_pool.get_slot(id))
            .collect();

        let fused = rrf_fuse(
            &[&dense_slots, &bm25_slots],
            &[1.0 - text_weight, text_weight],
            rrf_k,
            top_k,
        );

        // Cache the dense-side full SearchResults so we don't re-fetch metadata
        // for slots both retrievers found. Keyed by slot, since RRF speaks slots.
        let mut cache: HashMap<u32, SearchResult> = HashMap::with_capacity(dense_r.len());
        for r in dense_r.into_iter() {
            if let Some(slot) = self.id_pool.get_slot(&r.id) {
                cache.insert(slot, r);
            }
        }

        // Slots that BM25 surfaced but the dense path didn't — fetch their metadata
        // in one batch instead of one-by-one inside the loop below.
        let bm25_only: Vec<u32> = fused
            .iter()
            .map(|(s, _)| *s)
            .filter(|s| !cache.contains_key(s))
            .collect();
        let extra_meta: HashMap<u32, VectorMetadata> = if bm25_only.is_empty() {
            HashMap::new()
        } else {
            self.metadata.get_many(&bm25_only)?
        };

        let mut out = Vec::with_capacity(fused.len());
        for (slot, fused_score) in fused {
            let id = match self.id_pool.get_str(slot) {
                Some(s) => s.to_string(),
                None => continue, // tombstoned between fan-out and fuse — drop
            };
            let (metadata, document, from_dense) = if let Some(r) = cache.remove(&slot) {
                (r.metadata, r.document, true)
            } else if let Some(m) = extra_meta.get(&slot) {
                (m.properties.clone(), m.document.clone(), false)
            } else {
                (HashMap::new(), None, false)
            };
            // Filter correctness: dense-side slots are pre-filtered by
            // `search_with_filter_and_ann_include`. BM25-side slots bypass that
            // pipeline, so when the caller supplied a `filter` we re-check the
            // predicate here for any slot that didn't come through the dense leg.
            if let Some(f) = filter {
                if !from_dense && !metadata_matches_filter(&metadata, f) {
                    continue;
                }
            }
            out.push(SearchResult {
                id: if include_id { id } else { String::new() },
                score: fused_score as f64,
                metadata: if include_metadata {
                    metadata
                } else {
                    HashMap::new()
                },
                document: if include_document { document } else { None },
            });
        }
        Ok(out)
    }

    /// Query-planner decision: should this query use the HNSW index?
    ///
    /// Returns `true` when all of:
    /// - An index has been built and is non-empty.
    /// - The active collection is large enough (≥ `AUTO_ANN_THRESHOLD`).
    /// - The delta overlay (post-index inserts) is small enough (≤ 20% of N).
    ///
    /// Use this when `_use_ann` is `None` (caller did not explicitly request a path).
    pub fn auto_use_ann(&self) -> bool {
        let n = self.id_pool.active_count();
        if !self.graph.has_index() || self.index_ids.is_empty() || n < AUTO_ANN_THRESHOLD {
            return false;
        }
        // delta_size / n <= NUM/DEN  ↔  delta_size * DEN <= n * NUM
        self.delta_slots.len() * AUTO_ANN_MAX_DELTA_DEN <= n * AUTO_ANN_MAX_DELTA_NUM
    }

    /// Blocked batch scorer: scan all N codes once, score against all Q queries in parallel.
    ///
    /// Reduces memory traffic from Q×N×stride to N×stride bytes. Activated when
    /// Q ≥ 8, N ≥ 500k, brute-force path, Ip/Cosine metric, rerank disabled.
    fn score_batch_brute(
        &self,
        queries: &[Array1<f64>],
        top_k: usize,
        filter: Option<&HashMap<String, JsonValue>>,
        include_id: bool,
        include_metadata: bool,
        include_document: bool,
    ) -> Result<Vec<Vec<SearchResult>>, Box<dyn std::error::Error + Send + Sync>> {
        let nq = queries.len();
        let internal_k = top_k; // no rerank — caller already checked rerank_enabled=false

        // Apply the same query normalisation as the single-query path.
        let normalized_storage: Vec<Array1<f64>>;
        let effective_queries: &[Array1<f64>] = if self.normalize {
            normalized_storage = queries
                .iter()
                .map(|q| {
                    let qn = q.iter().map(|x| x * x).sum::<f64>().sqrt();
                    if qn > 1e-10 { q / qn } else { q.to_owned() }
                })
                .collect();
            &normalized_storage
        } else {
            queries
        };

        // Resolve candidate slots (shared across all Q queries).
        let active_slots = self.id_pool.iter_active_slots();
        if active_slots.is_empty() {
            return Ok(vec![Vec::new(); nq]);
        }
        let candidate_slots: Vec<u32> = if let Some(f) = filter {
            if let Some(indexed) = self.resolve_filter_via_index(f, &active_slots) {
                let all_eq = filter_is_exact_index(f);
                if all_eq {
                    indexed
                } else {
                    let meta_map = self.metadata.get_many_properties(&indexed)?;
                    let empty: HashMap<String, JsonValue> = HashMap::new();
                    indexed
                        .into_iter()
                        .filter(|s| {
                            metadata_matches_filter(meta_map.get(s).copied().unwrap_or(&empty), f)
                        })
                        .collect()
                }
            } else {
                let meta_map = self.metadata.get_many_properties(&active_slots)?;
                let empty: HashMap<String, JsonValue> = HashMap::new();
                active_slots
                    .into_iter()
                    .filter(|s| {
                        metadata_matches_filter(meta_map.get(s).copied().unwrap_or(&empty), f)
                    })
                    .collect()
            }
        } else {
            active_slots
        };
        if candidate_slots.is_empty() {
            return Ok(vec![Vec::new(); nq]);
        }

        let codes_bytes = self.live_codes.as_bytes();
        let stride = self.live_stride();
        let mse_len = self.live_mse_len();
        let qjl_len = self.live_qjl_len();
        let quantizer = &self.quantizer;

        // Per-query q_norm_inv for cosine.
        let q_norms_inv: Vec<f64> = effective_queries
            .iter()
            .map(|q| {
                let n = q.iter().map(|x| x * x).sum::<f64>().sqrt();
                if n > 0.0 { 1.0 / n } else { 0.0 }
            })
            .collect();

        // Pre-build Q LUTs — O(Q × n) work done once outside the scoring loop.
        let preps: Vec<_> = effective_queries
            .iter()
            .map(|q| quantizer.prepare_ip_query(q))
            .collect();

        // Per-query bounded heap: Vec<(slot, score)>, capped at internal_k.
        let use_small_topk = internal_k <= 32;
        let mut per_query: Vec<Vec<(u32, f64)>> = (0..nq)
            .map(|_| Vec::with_capacity(internal_k.min(256)))
            .collect();
        // P8 (v0.8.3): score_ip_encoded_packed now dispatches a const-generic
        // SIMD kernel for every b ∈ [1, 8], so the previous A2-era b=4 gate is
        // gone. Every brute-force candidate goes through the fused-unpack path.
        // (The pre-P8 code allocated a per-call `idx_buf: Vec<u16>` for the
        // b!=4 fallback — that fallback is gone and the buffer along with it.)
        for &slot in &candidate_slots {
            let rec = &codes_bytes[slot as usize * stride..(slot as usize + 1) * stride];
            let gamma = f32::from_le_bytes(
                rec[mse_len + qjl_len..mse_len + qjl_len + 4]
                    .try_into()
                    .expect("gamma field is 4 bytes"),
            );
            let doc_norm = f32::from_le_bytes(
                rec[mse_len + qjl_len + 4..mse_len + qjl_len + 8]
                    .try_into()
                    .expect("doc_norm field is 4 bytes"),
            );
            let qjl_bits = &rec[mse_len..mse_len + qjl_len];
            let packed_mse = &rec[..mse_len];

            for q_idx in 0..nq {
                let ip = quantizer.score_ip_encoded_packed(
                    &preps[q_idx],
                    packed_mse,
                    qjl_bits,
                    gamma as f64,
                );
                // Cosine: vectors stored unit-normalised; ip = <q, d̂>; divide by ‖q‖.
                // IP: multiply by doc_norm to recover the original inner product magnitude.
                let score = if matches!(self.metric, DistanceMetric::Cosine) {
                    ip * q_norms_inv[q_idx]
                } else {
                    ip * doc_norm as f64
                };
                let heap = &mut per_query[q_idx];
                if use_small_topk {
                    if heap.len() < internal_k {
                        heap.push((slot, score));
                    } else {
                        let (mut min_i, mut min_s) = (0, heap[0].1);
                        for (i, &(_, s)) in heap.iter().enumerate().skip(1) {
                            if s < min_s {
                                min_s = s;
                                min_i = i;
                            }
                        }
                        if score > min_s {
                            heap[min_i] = (slot, score);
                        }
                    }
                } else {
                    heap.push((slot, score));
                    // Periodic trim: avoid O(N) memory per query.
                    if heap.len() > internal_k * 4 {
                        heap.select_nth_unstable_by(internal_k, |a, b| {
                            b.1.partial_cmp(&a.1).unwrap_or(Ordering::Equal)
                        });
                        heap.truncate(internal_k);
                    }
                }
            }
        }

        // Finalize: trim, sort, convert to SearchResult.
        let mut results = Vec::with_capacity(nq);
        for mut candidates in per_query {
            if !use_small_topk && candidates.len() > internal_k {
                candidates.select_nth_unstable_by(internal_k, |a, b| {
                    b.1.partial_cmp(&a.1).unwrap_or(Ordering::Equal)
                });
                candidates.truncate(internal_k);
            }
            candidates.sort_unstable_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(Ordering::Equal));
            candidates.truncate(top_k);

            let slots: Vec<u32> = candidates.iter().map(|(s, _)| *s).collect();
            let meta_map = if (include_metadata || include_document) && self.metadata.len() > 0 {
                Some(self.metadata.get_many(&slots)?)
            } else {
                None
            };

            let mut row = Vec::with_capacity(candidates.len());
            for (cand_slot, score) in candidates {
                let id = if include_id {
                    self.id_pool
                        .get_str(cand_slot)
                        .unwrap_or_default()
                        .to_string()
                } else {
                    String::new()
                };
                let mut metadata = HashMap::new();
                let mut document = None;
                if let Some(meta) = meta_map.as_ref().and_then(|m| m.get(&cand_slot)).cloned() {
                    if include_metadata {
                        metadata = meta.properties;
                    }
                    if include_document {
                        document = meta.document;
                    }
                }
                row.push(SearchResult {
                    id,
                    score,
                    metadata,
                    document,
                });
            }
            results.push(row);
        }
        Ok(results)
    }

    /// Run the same search for multiple query vectors in one call.
    ///
    /// `use_ann_opt`:
    /// - `None`       → query planner auto-selects (ANN when index exists + N ≥ threshold).
    /// - `Some(true)` → force ANN (requires `create_index()` first).
    /// - `Some(false)`→ force brute-force.
    pub fn search_batch(
        &self,
        queries: &[ndarray::Array1<f64>],
        top_k: usize,
        filter: Option<&HashMap<String, JsonValue>>,
        ann_search_list_size: Option<usize>,
        use_ann_opt: Option<bool>,
        rerank_factor: Option<usize>,
    ) -> Result<Vec<Vec<SearchResult>>, Box<dyn std::error::Error + Send + Sync>> {
        self.search_batch_with_include(
            queries,
            top_k,
            filter,
            ann_search_list_size,
            use_ann_opt,
            rerank_factor,
            true,
            true,
            true,
        )
    }

    pub fn search_batch_with_include(
        &self,
        queries: &[ndarray::Array1<f64>],
        top_k: usize,
        filter: Option<&HashMap<String, JsonValue>>,
        ann_search_list_size: Option<usize>,
        use_ann_opt: Option<bool>,
        rerank_factor: Option<usize>,
        include_id: bool,
        include_metadata: bool,
        include_document: bool,
    ) -> Result<Vec<Vec<SearchResult>>, Box<dyn std::error::Error + Send + Sync>> {
        let use_ann = use_ann_opt.unwrap_or_else(|| self.auto_use_ann());
        // Blocked batch scorer: one pass through codes scores all Q queries simultaneously.
        // Reduces memory traffic Q×N×stride → N×stride at the cost of sequential access.
        // Break-even on memory-bandwidth-limited workloads (codes >> L3 cache, typically N > 500k).
        // On multi-core machines with small N, the Rayon par_iter path beats this.
        const BATCH_BRUTE_MIN_Q: usize = 8;
        const BATCH_BRUTE_MIN_N: usize = 500_000;
        if !use_ann
            && queries.len() >= BATCH_BRUTE_MIN_Q
            && self.id_pool.active_count() >= BATCH_BRUTE_MIN_N
            && !self.rerank_enabled
            && matches!(self.metric, DistanceMetric::Ip | DistanceMetric::Cosine)
        {
            return self.score_batch_brute(
                queries,
                top_k,
                filter,
                include_id,
                include_metadata,
                include_document,
            );
        }
        // For small query batches, Rayon scheduling overhead can dominate
        // end-to-end latency. Use a sequential path to reduce p50/p99 for
        // tiny batches (common in interactive RAG calls).
        const PAR_BATCH_MIN_QUERIES: usize = 4;
        if queries.len() < PAR_BATCH_MIN_QUERIES {
            let mut out = Vec::with_capacity(queries.len());
            for q in queries {
                out.push(self.search_with_filter_and_ann_include(
                    q,
                    top_k,
                    filter,
                    ann_search_list_size,
                    use_ann,
                    rerank_factor,
                    include_id,
                    include_metadata,
                    include_document,
                )?);
            }
            Ok(out)
        } else {
            queries
                .par_iter()
                .map(|q| {
                    self.search_with_filter_and_ann_include(
                        q,
                        top_k,
                        filter,
                        ann_search_list_size,
                        use_ann,
                        rerank_factor,
                        include_id,
                        include_metadata,
                        include_document,
                    )
                })
                .collect()
        }
    }

    ///
    /// When `filter` is `None` this is equivalent to `stats().vector_count` but
    /// faster (no disk I/O). When a filter is supplied it performs an O(n) scan
    /// identical to the brute-force search pre-filter path.
    pub fn count_with_filter(
        &self,
        filter: Option<&HashMap<String, JsonValue>>,
    ) -> Result<usize, Box<dyn std::error::Error + Send + Sync>> {
        let Some(f) = filter else {
            return Ok(self.id_pool.active_count());
        };
        let slots = self.id_pool.iter_active_slots();
        let meta_map = self.metadata.get_many_properties(&slots)?;
        let empty_props: HashMap<String, JsonValue> = HashMap::new();
        let count = slots
            .iter()
            .filter(|slot| {
                let props = meta_map.get(slot).copied().unwrap_or(&empty_props);
                metadata_matches_filter(props, f)
            })
            .count();
        Ok(count)
    }

    /// Delete multiple vectors in a single call.
    ///
    /// Returns the number of IDs that were found and deleted. IDs not present
    /// in the database are silently skipped. A single WAL flush is performed
    /// after all deletions, making this significantly cheaper than calling
    /// `delete()` in a loop when removing many vectors at once.
    pub fn delete_batch(
        &mut self,
        ids: Vec<String>,
    ) -> Result<usize, Box<dyn std::error::Error + Send + Sync>> {
        let mut deleted = 0usize;
        for id in ids {
            if !self.id_pool.contains(&id) {
                continue;
            }
            let entry = WalEntry {
                id: id.clone(),
                quantized_indices: Vec::new(),
                qjl_bits: Vec::new(),
                gamma: 0.0,
                norm: 0.0,
                metadata_json: "{}".to_string(),
                is_deleted: true,
            };
            self.wal.append(&entry, false)?;
            self.wal_buffer.push(entry);
            self.live_delete_slot(&id);
            deleted += 1;
        }
        if deleted > 0 {
            self.has_pending_deletes = true;
            self.invalidate_index_state()?;
            self.maybe_persist_state(false)?;
            if self.wal_buffer.len() >= self.wal_flush_threshold {
                self.flush_wal_to_segment()?;
            }
        }
        Ok(deleted)
    }

    /// Delete all vectors whose metadata matches `filter`.
    ///
    /// Atomically collects matching IDs (under the same write lock held by the
    /// caller) and then delegates to [`delete_batch`].  Returns the count of
    /// deleted vectors.
    pub fn delete_where(
        &mut self,
        filter: &HashMap<String, JsonValue>,
    ) -> Result<usize, Box<dyn std::error::Error + Send + Sync>> {
        let active = self.id_pool.iter_active();
        let slots: Vec<u32> = active.iter().map(|(_, s)| *s).collect();
        let meta_map = self.metadata.get_many_properties(&slots)?;
        let ids_to_delete: Vec<String> = active
            .into_iter()
            .filter(|(_, slot)| {
                meta_map
                    .get(slot)
                    .is_some_and(|props| metadata_matches_filter(props, filter))
            })
            .map(|(id, _)| id)
            .collect();
        self.delete_batch(ids_to_delete)
    }

    pub fn create_index_with_params(
        &mut self,
        max_degree: usize,
        ef_construction: usize,
        search_list_size: usize,
        alpha: f64,
        n_refinements: usize,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        self.flush_wal_to_segment()?;
        let mut id_slot_pairs = self.live_iter_id_slots();
        if id_slot_pairs.is_empty() {
            return Ok(());
        }
        id_slot_pairs.sort_by(|a, b| a.0.cmp(&b.0));
        let indexed_slots: Vec<u32> = id_slot_pairs.iter().map(|(_, slot)| *slot).collect();
        let live_codes = &self.live_codes;
        let d = self.d;
        let qjl_len = self.live_qjl_len();
        let mse_len = self.live_mse_len();
        let metric = self.metric.clone();
        let quantizer = self.quantizer.clone();
        let slots_ref = indexed_slots.clone();
        let has_vraw = self.live_vraw.is_some();
        // Share live_vraw reference safely with the closure.
        let vraw_ref = self.live_vraw.as_ref();
        let vraw_precision = self.manifest.rerank_precision;

        let qn = quantizer.n;

        // Pre-cache all encoded vectors for IP/Cosine metrics into flat contiguous arrays.
        // Avoids O(n × candidates × refinements) heap allocations and random slab reads
        // that live_codes_at_slot_raw() would otherwise incur per scoring call.
        // In fast_mode, gamma=0 for every vector so the QJL loop is skipped by the scorer;
        // we skip pre-caching qjl_buf entirely to reduce memory footprint and bandwidth.
        let is_fast_mode = self.manifest.fast_mode;
        // The stride used to index all_qjl_flat: 0 when fast_mode (empty buffer).
        let cached_qjl_len = if is_fast_mode { 0 } else { qjl_len };
        let (all_mse, all_qjl_flat, all_gamma, all_norm) =
            if matches!(self.metric, DistanceMetric::Ip | DistanceMetric::Cosine) {
                let n_indexed = indexed_slots.len();
                let mut mse_buf = vec![0u16; n_indexed * qn];
                let effective_qjl_len = if is_fast_mode { 0 } else { qjl_len };
                let mut qjl_buf = vec![0u8; n_indexed * effective_qjl_len];
                let mut gamma_buf = vec![0.0f32; n_indexed];
                let mut norm_buf = vec![0.0f32; n_indexed];
                for (i, &slot) in indexed_slots.iter().enumerate() {
                    let rec = live_codes.get_slot(slot as usize);
                    quantizer
                        .unpack_mse_indices(&rec[..mse_len], &mut mse_buf[i * qn..(i + 1) * qn]);
                    if !is_fast_mode && qjl_len > 0 {
                        qjl_buf[i * qjl_len..(i + 1) * qjl_len]
                            .copy_from_slice(&rec[mse_len..mse_len + qjl_len]);
                    }
                    gamma_buf[i] = f32::from_le_bytes(
                        rec[mse_len + qjl_len..mse_len + qjl_len + 4]
                            .try_into()
                            .expect("live_codes gamma field is always 4 bytes"),
                    );
                    norm_buf[i] = f32::from_le_bytes(
                        rec[mse_len + qjl_len + 4..mse_len + qjl_len + 8]
                            .try_into()
                            .expect("live_codes norm field is always 4 bytes"),
                    );
                }
                (mse_buf, qjl_buf, gamma_buf, norm_buf)
            } else {
                (Vec::new(), Vec::new(), Vec::new(), Vec::new())
            };

        // For L2/other metrics without raw vectors: pre-compute all dequantized vectors in
        // parallel before the build loop so each `to` node is dequantized at most once instead
        // of once per candidate evaluation (O(n × ef_construction) without this).
        let precomputed_l2: Vec<Array1<f64>> =
            if !matches!(self.metric, DistanceMetric::Ip | DistanceMetric::Cosine) && !has_vraw {
                let codes_bytes = live_codes.as_bytes();
                let stride = self.live_stride();
                let q = &self.quantizer;
                indexed_slots
                    .par_iter()
                    .map(|&slot| {
                        let rec =
                            &codes_bytes[slot as usize * stride..(slot as usize + 1) * stride];
                        let mut idx = vec![0u16; q.n];
                        q.unpack_mse_indices(&rec[..mse_len], &mut idx);
                        let gamma = f32::from_le_bytes(
                            rec[mse_len + qjl_len..mse_len + qjl_len + 4]
                                .try_into()
                                .expect("live_codes gamma field is always 4 bytes"),
                        );
                        let doc_norm = f32::from_le_bytes(
                            rec[mse_len + qjl_len + 4..mse_len + qjl_len + 8]
                                .try_into()
                                .expect("live_codes norm field is always 4 bytes"),
                        );
                        let mut v =
                            q.dequantize(&idx, &rec[mse_len..mse_len + qjl_len], gamma as f64);
                        // Dequantize returns unit vector; scale back to original norm for L2.
                        v.mapv_inplace(|x| x * doc_norm as f64);
                        v
                    })
                    .collect()
            } else {
                Vec::new()
            };

        let build_scorer = move |from: u32, candidates: &[u32]| -> Vec<(u32, f64)> {
            let from_idx = from as usize;
            let from_slot = slots_ref[from_idx] as usize;

            if matches!(metric, DistanceMetric::Ip) {
                // For IP: prepare from-query via O(n) centroid lookup (no SRHT) when raw
                // vectors are unavailable. When vraw is present, use exact rotation.
                // In both cases, `to` candidates use pre-cached encoded data.
                if has_vraw {
                    let rec = vraw_ref
                        .expect("invariant: has_vraw=true implies live_vraw is Some")
                        .get_slot(from_slot);
                    let mut out = Array1::<f64>::zeros(d);
                    match vraw_precision {
                        RerankPrecision::Int8 => {
                            let scale = f32::from_le_bytes(rec[..4].try_into().unwrap()) as f64;
                            for i in 0..d {
                                out[i] = (rec[4 + i] as i8) as f64 * scale / 127.0;
                            }
                        }
                        RerankPrecision::Int4 => {
                            let scale = f32::from_le_bytes(rec[..4].try_into().unwrap()) as f64;
                            for i in 0..d {
                                let byte = rec[4 + i / 2];
                                let nibble = if i % 2 == 0 {
                                    byte & 0x0F
                                } else {
                                    (byte >> 4) & 0x0F
                                };
                                let signed = if nibble > 7 {
                                    nibble as i8 - 16
                                } else {
                                    nibble as i8
                                };
                                out[i] = signed as f64 * scale / 7.0;
                            }
                        }
                        RerankPrecision::ResidualInt4 => {
                            // Residual + dequant(codes_at_from_idx) = full reconstruction.
                            let scale = f32::from_le_bytes(rec[..4].try_into().unwrap()) as f64;
                            let from_codes = &all_mse[from_idx * qn..(from_idx + 1) * qn];
                            let recon = quantizer.mse_quantizer.dequantize(from_codes);
                            for i in 0..d {
                                let byte = rec[4 + i / 2];
                                let nibble = if i % 2 == 0 {
                                    byte & 0x0F
                                } else {
                                    (byte >> 4) & 0x0F
                                };
                                let signed = if nibble > 7 {
                                    nibble as i8 - 16
                                } else {
                                    nibble as i8
                                };
                                let residual = signed as f64 * scale / 7.0;
                                out[i] = recon[i] + residual;
                            }
                        }
                        RerankPrecision::F16 => {
                            for i in 0..d {
                                let bytes: [u8; 2] = rec[i * 2..(i + 1) * 2].try_into().unwrap();
                                out[i] = half::f16::from_le_bytes(bytes).to_f64();
                            }
                        }
                        _ => {
                            for i in 0..d {
                                let bytes: [u8; 4] = rec[i * 4..(i + 1) * 4].try_into().unwrap();
                                out[i] = f32::from_le_bytes(bytes) as f64;
                            }
                        }
                    }
                    let prep = quantizer.prepare_ip_query_lite(&out);
                    candidates
                        .iter()
                        .map(|&to| {
                            let to_idx = to as usize;
                            let to_i = &all_mse[to_idx * qn..(to_idx + 1) * qn];
                            let to_q = if cached_qjl_len > 0 {
                                &all_qjl_flat
                                    [to_idx * cached_qjl_len..(to_idx + 1) * cached_qjl_len]
                            } else {
                                &[]
                            };
                            let to_g = all_gamma[to_idx];
                            let to_n = all_norm[to_idx];
                            (
                                to,
                                quantizer.score_ip_encoded_lite(&prep, to_i, to_q, to_g as f64)
                                    * to_n as f64,
                            )
                        })
                        .collect()
                } else {
                    // No raw vectors: use MSE centroid-lookup score blended with Hamming
                    // similarity between from-QJL bits and to-QJL bits.
                    //
                    // Background: prepare_ip_query_from_codes sets sq=0 (the QJL
                    // projection of the from-vector is unknown without raw data), making
                    // score_ip_encoded_lite skip the QJL term. This MSE-only topology
                    // mismatches the full-LUT scoring used at search time → poor recall.
                    //
                    // Fix: hamming_score(from_q, to_q) ∈ [0,1] approximates cos(from,to)
                    // in QJL-sign space. Subtracting 0.5 centres it so it contributes
                    // positively for near neighbours and negatively for far ones.
                    let from_i = &all_mse[from_idx * qn..(from_idx + 1) * qn];
                    let from_q = if cached_qjl_len > 0 {
                        &all_qjl_flat[from_idx * cached_qjl_len..(from_idx + 1) * cached_qjl_len]
                    } else {
                        &[]
                    };
                    let mse_prep = quantizer.prepare_ip_query_from_codes(from_i);
                    candidates
                        .iter()
                        .map(|&to| {
                            let to_idx = to as usize;
                            let to_i = &all_mse[to_idx * qn..(to_idx + 1) * qn];
                            let to_q = if cached_qjl_len > 0 {
                                &all_qjl_flat
                                    [to_idx * cached_qjl_len..(to_idx + 1) * cached_qjl_len]
                            } else {
                                &[]
                            };
                            let to_n = all_norm[to_idx];
                            let mse_score =
                                quantizer.score_ip_encoded_lite(&mse_prep, to_i, &[], 0.0);
                            let hamming_bonus = if !from_q.is_empty() && !to_q.is_empty() {
                                quantizer.hamming_proximity(from_q, to_q) - 0.5
                            } else {
                                0.0
                            };
                            (to, (mse_score + hamming_bonus) * to_n as f64)
                        })
                        .collect()
                }
            } else if matches!(metric, DistanceMetric::Cosine) {
                if has_vraw {
                    let rec = vraw_ref
                        .expect("invariant: has_vraw=true implies live_vraw is Some")
                        .get_slot(from_slot);
                    let mut out = Array1::<f64>::zeros(d);
                    match vraw_precision {
                        RerankPrecision::Int8 => {
                            let scale = f32::from_le_bytes(rec[..4].try_into().unwrap()) as f64;
                            for i in 0..d {
                                out[i] = (rec[4 + i] as i8) as f64 * scale / 127.0;
                            }
                        }
                        RerankPrecision::Int4 => {
                            let scale = f32::from_le_bytes(rec[..4].try_into().unwrap()) as f64;
                            for i in 0..d {
                                let byte = rec[4 + i / 2];
                                let nibble = if i % 2 == 0 {
                                    byte & 0x0F
                                } else {
                                    (byte >> 4) & 0x0F
                                };
                                let signed = if nibble > 7 {
                                    nibble as i8 - 16
                                } else {
                                    nibble as i8
                                };
                                out[i] = signed as f64 * scale / 7.0;
                            }
                        }
                        RerankPrecision::ResidualInt4 => {
                            // Residual + dequant(codes_at_from_idx) = full reconstruction.
                            let scale = f32::from_le_bytes(rec[..4].try_into().unwrap()) as f64;
                            let from_codes = &all_mse[from_idx * qn..(from_idx + 1) * qn];
                            let recon = quantizer.mse_quantizer.dequantize(from_codes);
                            for i in 0..d {
                                let byte = rec[4 + i / 2];
                                let nibble = if i % 2 == 0 {
                                    byte & 0x0F
                                } else {
                                    (byte >> 4) & 0x0F
                                };
                                let signed = if nibble > 7 {
                                    nibble as i8 - 16
                                } else {
                                    nibble as i8
                                };
                                let residual = signed as f64 * scale / 7.0;
                                out[i] = recon[i] + residual;
                            }
                        }
                        RerankPrecision::F16 => {
                            for i in 0..d {
                                let bytes: [u8; 2] = rec[i * 2..(i + 1) * 2].try_into().unwrap();
                                out[i] = half::f16::from_le_bytes(bytes).to_f64();
                            }
                        }
                        _ => {
                            for i in 0..d {
                                let bytes: [u8; 4] = rec[i * 4..(i + 1) * 4].try_into().unwrap();
                                out[i] = f32::from_le_bytes(bytes) as f64;
                            }
                        }
                    }
                    let from_norm = out.iter().map(|x| x * x).sum::<f64>().sqrt();
                    let prep = quantizer.prepare_ip_query_lite(&out);
                    candidates
                        .iter()
                        .map(|&to| {
                            let to_idx = to as usize;
                            let to_i = &all_mse[to_idx * qn..(to_idx + 1) * qn];
                            let to_q = if cached_qjl_len > 0 {
                                &all_qjl_flat
                                    [to_idx * cached_qjl_len..(to_idx + 1) * cached_qjl_len]
                            } else {
                                &[]
                            };
                            let to_g = all_gamma[to_idx];
                            // prep built from raw from_vec; ip ≈ <from_raw, unit_to>
                            let ip =
                                quantizer.score_ip_encoded_lite(&prep, to_i, to_q, to_g as f64);
                            let score = if from_norm > 0.0 { ip / from_norm } else { 0.0 };
                            (to, score)
                        })
                        .collect()
                } else {
                    // No raw vectors: same Hamming-blend fix as for IP above.
                    // Vectors are stored unit-normalised, so cosine ≈ inner product.
                    let from_i = &all_mse[from_idx * qn..(from_idx + 1) * qn];
                    let from_q = if cached_qjl_len > 0 {
                        &all_qjl_flat[from_idx * cached_qjl_len..(from_idx + 1) * cached_qjl_len]
                    } else {
                        &[]
                    };
                    let mse_prep = quantizer.prepare_ip_query_from_codes(from_i);
                    candidates
                        .iter()
                        .map(|&to| {
                            let to_idx = to as usize;
                            let to_i = &all_mse[to_idx * qn..(to_idx + 1) * qn];
                            let to_q = if cached_qjl_len > 0 {
                                &all_qjl_flat
                                    [to_idx * cached_qjl_len..(to_idx + 1) * cached_qjl_len]
                            } else {
                                &[]
                            };
                            let mse_score =
                                quantizer.score_ip_encoded_lite(&mse_prep, to_i, &[], 0.0);
                            let hamming_bonus = if !from_q.is_empty() && !to_q.is_empty() {
                                quantizer.hamming_proximity(from_q, to_q) - 0.5
                            } else {
                                0.0
                            };
                            (to, mse_score + hamming_bonus)
                        })
                        .collect()
                }
            } else if !precomputed_l2.is_empty() {
                // L2 without raw vecs: use pre-computed dequantized vectors (no per-call
                // SRHT — each vector was dequantized exactly once in parallel above).
                let from_vec = &precomputed_l2[from_idx];
                candidates
                    .iter()
                    .map(|&to| {
                        let to_vec = &precomputed_l2[to as usize];
                        (to, score_vectors_with_metric(&metric, from_vec, to_vec))
                    })
                    .collect()
            } else {
                // L2 with raw vecs: read from vraw directly.
                // Invariant: precomputed_l2 is empty only when has_vraw=true (L2 + rerank=true).
                let vraw =
                    vraw_ref.expect("invariant: L2 raw-vec path only reached when rerank=true");
                let rec = vraw.get_slot(from_slot);
                let mut from_vec = Array1::<f64>::zeros(d);
                for i in 0..d {
                    let bytes: [u8; 4] = rec[i * 4..(i + 1) * 4]
                        .try_into()
                        .expect("vraw f32 record has 4 bytes per element");
                    from_vec[i] = f32::from_le_bytes(bytes) as f64;
                }
                candidates
                    .iter()
                    .map(|&to| {
                        let to_slot = slots_ref[to as usize] as usize;
                        let rec = vraw.get_slot(to_slot);
                        let mut to_vec = Array1::<f64>::zeros(d);
                        for i in 0..d {
                            let bytes: [u8; 4] = rec[i * 4..(i + 1) * 4]
                                .try_into()
                                .expect("vraw f32 record has 4 bytes per element");
                            to_vec[i] = f32::from_le_bytes(bytes) as f64;
                        }
                        (to, score_vectors_with_metric(&metric, &from_vec, &to_vec))
                    })
                    .collect()
            }
        };

        self.graph.build(
            indexed_slots.len(),
            max_degree,
            ef_construction,
            n_refinements,
            alpha,
            build_scorer,
        )?;
        self.index_ids = indexed_slots;
        self.index_ids_dirty = true;
        // Delta slots are now part of the rebuilt graph — clear the overlay.
        self.delta_slots.clear();
        self.delta_slots_dirty = true;
        self.manifest.index_state = Some(IndexState {
            max_degree,
            ef_construction,
            search_list_size,
            alpha,
            indexed_nodes: self.index_ids.len(),
        });
        self.maybe_persist_state(true)?;
        Ok(())
    }

    pub fn search(
        &self,
        query: &Array1<f64>,
        top_k: usize,
    ) -> Result<Vec<SearchResult>, Box<dyn std::error::Error + Send + Sync>> {
        self.search_with_filter_and_ann_include(
            query, top_k, None, None, true, None, true, true, true,
        )
    }

    pub fn search_with_filter(
        &self,
        query: &Array1<f64>,
        top_k: usize,
        filter: Option<&HashMap<String, JsonValue>>,
    ) -> Result<Vec<SearchResult>, Box<dyn std::error::Error + Send + Sync>> {
        self.search_with_filter_and_ann_include(
            query, top_k, filter, None, true, None, true, true, true,
        )
    }

    pub fn search_with_filter_and_ann(
        &self,
        query: &Array1<f64>,
        top_k: usize,
        filter: Option<&HashMap<String, JsonValue>>,
        ann_search_list_size: Option<usize>,
        use_ann: bool,
        rerank_factor: Option<usize>,
    ) -> Result<Vec<SearchResult>, Box<dyn std::error::Error + Send + Sync>> {
        self.search_with_filter_and_ann_include(
            query,
            top_k,
            filter,
            ann_search_list_size,
            use_ann,
            rerank_factor,
            true,
            true,
            true,
        )
    }

    pub fn search_with_filter_and_ann_include(
        &self,
        query: &Array1<f64>,
        top_k: usize,
        filter: Option<&HashMap<String, JsonValue>>,
        ann_search_list_size: Option<usize>,
        use_ann: bool,
        rerank_factor: Option<usize>,
        include_id: bool,
        include_metadata: bool,
        include_document: bool,
    ) -> Result<Vec<SearchResult>, Box<dyn std::error::Error + Send + Sync>> {
        if self.id_pool.active_count() == 0 || top_k == 0 {
            return Ok(Vec::new());
        }

        // When normalize=true, L2-normalise the query so IP ≡ cosine similarity.
        let normalized_query;
        let query = if self.normalize {
            let qn = query.iter().map(|x| x * x).sum::<f64>().sqrt();
            normalized_query = if qn > 1e-10 {
                query / qn
            } else {
                query.to_owned()
            };
            &normalized_query
        } else {
            query
        };

        let has_index = self.graph.has_index();
        let not_empty = !self.index_ids.is_empty();
        let state_match = self
            .manifest
            .index_state
            .as_ref()
            .is_some_and(|s| s.indexed_nodes == self.index_ids.len());

        if use_ann && has_index && not_empty && state_match {
            let sls = ann_search_list_size.unwrap_or_else(|| {
                self.manifest
                    .index_state
                    .as_ref()
                    .map(|s| s.search_list_size)
                    .unwrap_or(64)
            });

            // Pre-filter support: resolve matching slots.
            // Fast path uses eq_index for O(1) candidate lookup on pure-$eq filters.
            // Query planner: if the filtered candidate set is small (< N/20 = 5%),
            // route to brute-force — HNSW graph traversal adds more overhead than it saves.
            let active_n = self.id_pool.active_count();
            const PLANNER_SELECTIVE_THRESHOLD: usize = 20; // route to brute-force if < N/20
            let filter_slots: Option<Vec<u32>> = if let Some(f) = filter {
                let active_slots = self.id_pool.iter_active_slots();

                let matches = if let Some(indexed) = self.resolve_filter_via_index(f, &active_slots)
                {
                    if filter_is_exact_index(f) {
                        indexed
                    } else {
                        let meta_map = self.metadata.get_many_properties(&indexed)?;
                        let empty_props: HashMap<String, JsonValue> = HashMap::new();
                        indexed
                            .into_iter()
                            .filter(|s| {
                                let props = meta_map.get(s).copied().unwrap_or(&empty_props);
                                metadata_matches_filter(props, f)
                            })
                            .collect()
                    }
                } else {
                    // O(n) fallback
                    let slots = active_slots;
                    let meta_map = self.metadata.get_many_properties(&slots)?;
                    let empty_props: HashMap<String, JsonValue> = HashMap::new();
                    let v: Vec<u32> = slots
                        .into_iter()
                        .filter(|s| {
                            let props = meta_map.get(s).copied().unwrap_or(&empty_props);
                            metadata_matches_filter(props, f)
                        })
                        .collect();
                    v
                };

                if matches.is_empty() {
                    return Ok(Vec::new());
                }

                // Query planner: if very selective, brute-force beats HNSW.
                if matches.len() < active_n / PLANNER_SELECTIVE_THRESHOLD {
                    return self.exhaustive_search_simd(
                        query,
                        top_k,
                        None,
                        Some(matches),
                        rerank_factor,
                        include_id,
                        include_metadata,
                        include_document,
                    );
                }
                Some(matches)
            } else {
                None
            };

            // Expand candidate pool for ANN: always fetch at least sls candidates so the
            // beam search has a sufficient buffer to recover from approximate navigation.
            // Without reranking, internal_k=top_k leaves no buffer → recall collapses.
            // Use `saturating_mul` so a pathological top_k can't wrap; the cap below
            // (active count + index_ids.len()) keeps the candidate buffer bounded
            // even when the user passes a huge top_k.
            let internal_k = if self.rerank_enabled {
                let factor =
                    rerank_factor.unwrap_or_else(|| default_rerank_factor(self.quantizer.d, true));
                let raw = top_k.saturating_mul(factor).max(top_k.saturating_add(1));
                let cap = self.index_ids.len().max(1);
                raw.min(cap)
            } else {
                // Fetch sls candidates, re-score by full LUT, return top_k.
                sls.max(top_k).min(self.index_ids.len().max(1))
            };

            // Shared references captured by search closures.
            let mse_len = self.live_mse_len();
            let qjl_len = self.live_qjl_len();
            let qn = self.quantizer.n;
            let live_codes_r = &self.live_codes;
            let quantizer_r = &self.quantizer;

            // Single full-LUT query prep: used for both HNSW navigation and final scoring.
            // The full scorer is more accurate than the lite scorer for navigation, and
            // eliminates the need for a separate re-score step after beam search.
            let prep = self.quantizer.prepare_ip_query(query);
            let query_norm = if matches!(self.metric, DistanceMetric::Cosine) {
                query.iter().map(|x| x * x).sum::<f64>().sqrt()
            } else {
                1.0
            };

            let slot_set: Option<std::collections::HashSet<u32>> =
                filter_slots.map(|s| s.into_iter().collect());
            let index_ids = &self.index_ids;
            let is_l2 = matches!(self.metric, DistanceMetric::L2);
            let is_cosine = matches!(self.metric, DistanceMetric::Cosine);
            let metric_r = &self.metric;

            // Reusable index buffer for MSE code unpacking — captured by the FnMut scorer
            // closure so it is allocated once and reused across all HNSW node visits.
            let mut idx_buf_ann = vec![0u16; qn];

            // C2: prefetch upcoming neighbour's live_codes record while the current
            // one is being scored. Hint to OS, no semantic change. No-op on non-x86_64.
            // Capture `index_ids` by reference (already borrowed at line 2160) — the
            // closure lives only for the duration of the search call so a borrow is
            // sufficient and avoids a per-query Vec<u32> clone of the (potentially
            // huge) index_ids buffer.
            let pf_index_ids: &[u32] = index_ids.as_slice();
            let pf_live_codes = &self.live_codes;
            let pf_stride = self.live_stride();
            let prefetch_fn = move |node: u32| {
                let slot = pf_index_ids[node as usize] as usize;
                let off = slot.saturating_mul(pf_stride);
                let bytes = pf_live_codes.as_bytes();
                if off < bytes.len() {
                    #[cfg(target_arch = "x86_64")]
                    unsafe {
                        std::arch::x86_64::_mm_prefetch(
                            bytes.as_ptr().add(off) as *const i8,
                            std::arch::x86_64::_MM_HINT_T0,
                        );
                    }
                    let _ = off;
                }
            };

            // HNSW beam search: collect internal_k candidates with accurate full-LUT scores.
            // internal_k = sls (≥ top_k) provides a candidate buffer to recover from any
            // graph navigation approximation errors before truncating to the final top_k.
            let ann_nodes = self.graph.search_with_prefetch(
                0,
                internal_k,
                sls.max(internal_k),
                |node| {
                    let slot = index_ids[node as usize];
                    let rec = live_codes_r.get_slot(slot as usize);
                    let qjl = &rec[mse_len..mse_len + qjl_len];
                    let gamma = f32::from_le_bytes(
                        rec[mse_len + qjl_len..mse_len + qjl_len + 4]
                            .try_into()
                            .expect("live_codes gamma field is always 4 bytes"),
                    );
                    let doc_norm = f32::from_le_bytes(
                        rec[mse_len + qjl_len + 4..mse_len + qjl_len + 8]
                            .try_into()
                            .expect("live_codes norm field is always 4 bytes"),
                    );
                    quantizer_r.unpack_mse_indices(&rec[..mse_len], &mut idx_buf_ann);

                    if is_l2 {
                        let mut v = quantizer_r.dequantize(&idx_buf_ann, qjl, gamma as f64);
                        v.mapv_inplace(|x| x * doc_norm as f64);
                        score_vectors_with_metric(metric_r, query, &v)
                    } else if is_cosine {
                        let ip =
                            quantizer_r.score_ip_encoded(&prep, &idx_buf_ann, qjl, gamma as f64);
                        if query_norm > 0.0 {
                            ip / query_norm
                        } else {
                            0.0
                        }
                    } else {
                        quantizer_r.score_ip_encoded(&prep, &idx_buf_ann, qjl, gamma as f64)
                            * doc_norm as f64
                    }
                },
                slot_set.map(|ss| move |node_idx: u32| ss.contains(&index_ids[node_idx as usize])),
                Some(prefetch_fn),
            )?;

            // Navigation scores from the full LUT are already accurate; no re-score pass
            // needed. ann_nodes is already sorted descending by graph.search(); truncate
            // here handles the rerank=True path which uses internal_k = top_k * 20.
            let mut ann: Vec<(u32, f64)> = ann_nodes;
            ann.truncate(top_k);

            let slots: Vec<u32> = ann
                .iter()
                .map(|(n, _)| self.index_ids[*n as usize])
                .collect();
            let needs_payload = include_metadata || include_document;
            let meta_map = if needs_payload && self.metadata.len() > 0 {
                Some(self.metadata.get_many(&slots)?)
            } else {
                None
            };
            let mut out = Vec::with_capacity(ann.len());

            // Batch-dequantize all candidates in parallel when reranking without raw vecs.
            let deq_vecs: Vec<Array1<f64>> = if self.rerank_enabled && self.live_vraw.is_none() {
                let (encoded, norms): (Vec<_>, Vec<f32>) = slots
                    .iter()
                    .map(|&slot| {
                        let (idx, qjl, gamma, norm) = self.live_codes_at_slot(slot as usize);
                        ((idx, qjl.to_vec(), gamma as f64), norm)
                    })
                    .unzip();
                let mut vecs = self.quantizer.dequantize_batch(&encoded);
                // Dequantize returns unit vectors; scale back to original norm for correct
                // metric computation (IP, L2). Cosine is scale-invariant so this is safe.
                for (v, norm) in vecs.iter_mut().zip(norms.iter()) {
                    v.mapv_inplace(|x| x * *norm as f64);
                }
                vecs
            } else {
                Vec::new()
            };

            for (i, (node, approx_score)) in ann.into_iter().enumerate() {
                let slot = self.index_ids[node as usize];
                let id = if include_id {
                    self.id_pool.get_str(slot).unwrap_or_default().to_string()
                } else {
                    String::new()
                };

                let score = if self.rerank_enabled {
                    if self.live_vraw.is_some() {
                        // P12: ResidualInt4 uses the additive shortcut to avoid
                        // O(d^2) code re-dequantization per candidate.
                        if matches!(self.manifest.rerank_precision, RerankPrecision::ResidualInt4)
                            && !matches!(self.metric, DistanceMetric::L2)
                        {
                            let q_norm_inv = if matches!(self.metric, DistanceMetric::Cosine) {
                                let qn = query.iter().map(|x| x * x).sum::<f64>().sqrt();
                                if qn > 1e-10 { 1.0 / qn } else { 0.0 }
                            } else { 0.0 };
                            self.live_rerank_score_residual_int4(slot as usize, query, approx_score, q_norm_inv)
                        } else {
                            let raw_vec = self.live_raw_vector_at_slot(slot as usize);
                            score_vectors_with_metric(&self.metric, query, &raw_vec)
                        }
                    } else {
                        score_vectors_with_metric(&self.metric, query, &deq_vecs[i])
                    }
                } else {
                    approx_score
                };

                let mut metadata = HashMap::new();
                let mut document = None;
                if let Some(meta) = meta_map.as_ref().and_then(|m| m.get(&slot)).cloned() {
                    if include_metadata {
                        metadata = meta.properties;
                    }
                    if include_document {
                        document = meta.document;
                    }
                }

                out.push(SearchResult {
                    id,
                    score,
                    metadata,
                    document,
                });
            }
            out.sort_by(|a, b| {
                b.score
                    .partial_cmp(&a.score)
                    .unwrap_or(std::cmp::Ordering::Equal)
            });
            if out.len() > top_k {
                out.truncate(top_k);
            }

            // Delta overlay: brute-force score vectors inserted after create_index()
            // that are not in the HNSW graph.  delta_slots is maintained incrementally
            // on every insert, avoiding the O(n) set-difference scan on each search.
            // is_slot_alive filters deleted slots without allocating strings or a HashSet.
            let delta: Vec<u32> = self
                .delta_slots
                .iter()
                .copied()
                .filter(|s| self.id_pool.is_slot_alive(*s))
                .collect();
            if !delta.is_empty() {
                let mut delta_results = self.exhaustive_search_simd(
                    query,
                    top_k,
                    filter,
                    Some(delta),
                    rerank_factor,
                    include_id,
                    include_metadata,
                    include_document,
                )?;
                out.append(&mut delta_results);
                out.sort_by(|a, b| {
                    b.score
                        .partial_cmp(&a.score)
                        .unwrap_or(std::cmp::Ordering::Equal)
                });
                out.truncate(top_k);
            }

            return Ok(out);
        }

        // Exhaustive search path (SIMD Optimized)
        self.exhaustive_search_simd(
            query,
            top_k,
            filter,
            None,
            rerank_factor,
            include_id,
            include_metadata,
            include_document,
        )
    }

    /// Try to resolve filter candidates using the eq_index or range_index.
    ///
    /// Returns `Some(slots)` when the filter can be resolved by index:
    /// - Pure `$eq` conditions → eq_index intersection (O(1) per field).
    /// - Single-field pure range (`$gt`/`$gte`/`$lt`/`$lte`) on a numeric field → range_index
    ///   BTreeMap range query (O(log n + result_count)).
    ///
    /// Returns `None` when the filter is not indexable (falls back to O(n) scan).
    fn resolve_filter_via_index(
        &self,
        filter: &HashMap<String, JsonValue>,
        active_slots: &[u32],
    ) -> Option<Vec<u32>> {
        // Fast path 1: pure equality conditions → eq_index.
        if let Some(conditions) = extract_indexable_eq(filter) {
            let mut result: Option<Vec<u32>> = None;
            for (field, val) in conditions {
                let indexed = self.metadata.get_eq_candidates(field, val)?;
                let set: Vec<u32> = if let Some(prev) = &result {
                    // Intersect with previous result (both are sorted).
                    let mut intersected = Vec::new();
                    let mut i = 0;
                    let mut j = 0;
                    while i < prev.len() && j < indexed.len() {
                        match prev[i].cmp(&indexed[j]) {
                            std::cmp::Ordering::Equal => {
                                intersected.push(prev[i]);
                                i += 1;
                                j += 1;
                            }
                            std::cmp::Ordering::Less => i += 1,
                            std::cmp::Ordering::Greater => j += 1,
                        }
                    }
                    intersected
                } else {
                    indexed.to_vec()
                };
                result = Some(set);
            }
            return result.map(|slots| intersect_sorted_slots(&slots, active_slots));
        }

        // Fast path 2: single-field numeric range → range_index.
        if let Some((field, lo, hi)) = extract_range_condition(filter) {
            let slots = self.metadata.get_range_candidates(field, lo, hi)?;
            return Some(intersect_sorted_slots(&slots, active_slots));
        }

        // Fast path 3: $in — union of eq_index lookups for each value in the list.
        if let Some((field, values)) = extract_in_condition(filter) {
            if let Some(candidates) = self.metadata.get_in_candidates(field, values) {
                return Some(intersect_sorted_slots(&candidates, active_slots));
            }
            // Field not indexed → fall through to O(N) scan.
        }

        // Fast path 4: $nin — complement of excluded-value slots against active slots.
        if let Some((field, excluded)) = extract_nin_condition(filter) {
            let excluded_slots = self
                .metadata
                .get_in_candidates(field, excluded)
                .unwrap_or_default();
            let result: Vec<u32> = active_slots
                .iter()
                .copied()
                .filter(|s| excluded_slots.binary_search(s).is_err())
                .collect();
            return Some(result);
        }

        // Fast path 5: single-field $or with pure equality sub-conditions → $in union.
        if let Some((field, values)) = extract_or_single_field_eq(filter) {
            if let Some(candidates) = self.metadata.get_in_candidates_refs(field, &values) {
                return Some(intersect_sorted_slots(&candidates, active_slots));
            }
            // Field not indexed → fall through to O(N) scan.
        }

        None
    }

    /// Score a set of candidate slots against `query` and return the top-`top_k` results.
    ///
    /// `forced_slots`: when `Some`, these slots are scored directly (after optional filter).
    /// When `None`, all active slots from `id_pool` are used (the normal brute-force path).
    fn exhaustive_search_simd(
        &self,
        query: &Array1<f64>,
        top_k: usize,
        filter: Option<&HashMap<String, JsonValue>>,
        forced_slots: Option<Vec<u32>>,
        rerank_factor: Option<usize>,
        include_id: bool,
        include_metadata: bool,
        include_document: bool,
    ) -> Result<Vec<SearchResult>, Box<dyn std::error::Error + Send + Sync>> {
        // saturating_mul guards against overflow when top_k or factor is huge;
        // the cap to active_count keeps the rerank candidate pool bounded.
        let internal_k = if self.rerank_enabled {
            let factor =
                rerank_factor.unwrap_or_else(|| default_rerank_factor(self.quantizer.d, false));
            let raw = top_k.saturating_mul(factor).max(top_k.saturating_add(1));
            let cap = self.id_pool.active_count().max(1);
            raw.min(cap)
        } else {
            top_k
        };
        let q_norm = query.iter().map(|x| x * x).sum::<f64>().sqrt();
        let q_norm_inv = if q_norm > 0.0 { 1.0 / q_norm } else { 0.0 };

        // Build candidate slot list: either from the forced set or all active slots.
        // Pre-filter slots upfront to keep the hot scoring loop filter-free.
        let candidate_slots: Vec<u32> = match forced_slots {
            Some(slots) => {
                if let Some(f) = filter {
                    let meta_map = self.metadata.get_many_properties(&slots)?;
                    let empty_props: HashMap<String, JsonValue> = HashMap::new();
                    slots
                        .into_iter()
                        .filter(|s| {
                            let props = meta_map.get(s).copied().unwrap_or(&empty_props);
                            metadata_matches_filter(props, f)
                        })
                        .collect()
                } else {
                    slots
                }
            }
            None => {
                let active_slots = self.id_pool.iter_active_slots();
                if active_slots.is_empty() {
                    return Ok(Vec::new());
                }
                if let Some(f) = filter {
                    // Fast path: try eq_index for O(1) candidate resolution.
                    if let Some(indexed_slots) = self.resolve_filter_via_index(f, &active_slots) {
                        // Skip post-scan when the indexed result is exact.
                        // Applies to: pure-$eq, $in, $nin, single-field $or, single-field range.
                        if filter_is_exact_index(f) {
                            indexed_slots
                        } else {
                            let meta_map = self.metadata.get_many_properties(&indexed_slots)?;
                            let empty_props: HashMap<String, JsonValue> = HashMap::new();
                            indexed_slots
                                .into_iter()
                                .filter(|s| {
                                    let props = meta_map.get(s).copied().unwrap_or(&empty_props);
                                    metadata_matches_filter(props, f)
                                })
                                .collect()
                        }
                    } else {
                        // Fallback: O(n) scan.
                        let all_slots = active_slots;
                        let meta_map = self.metadata.get_many_properties(&all_slots)?;
                        let empty_props: HashMap<String, JsonValue> = HashMap::new();
                        let cands: Vec<u32> = all_slots
                            .into_iter()
                            .filter(|s| {
                                let props = meta_map.get(s).copied().unwrap_or(&empty_props);
                                metadata_matches_filter(props, f)
                            })
                            .collect();
                        cands
                    }
                } else {
                    active_slots
                }
            }
        };

        if candidate_slots.is_empty() {
            return Ok(Vec::new());
        }

        // Borrow mmap bytes once — &[u8] is Sync so safe to share across Rayon threads.
        let codes_bytes = self.live_codes.as_bytes();
        let stride = self.live_stride();
        let mse_len = self.live_mse_len();
        let qjl_len = self.live_qjl_len();
        let quantizer = &self.quantizer;
        let metric = &self.metric;

        // Sign-bit Hamming prefilter (fast_mode + IP/Cosine + b ∈ {1, 2, 4, 8}).
        //
        // In fast_mode there's no QJL stored, but the MSB of each B-bit MSE code
        // is the sign of the corresponding rotated dimension (Lloyd-Max codebook
        // is symmetric around 0 for every B). We derive a 1-bit-per-dim sketch
        // from the existing MSE bytes for free and use Hamming disagreement as
        // a cheap proxy for IP to shrink the candidate set before full LUT scoring.
        //
        // **P8 (v0.8.3):** generalised from b=4-only to every cleanly-packed B.
        // Other bit-rates (3, 5, 6, 7) span misaligned byte boundaries — those
        // bypass the prefilter and run full LUT scoring on every candidate.
        //
        // Only enabled for sufficiently large candidate pools, where the prefilter's
        // amortised cost is dwarfed by the savings on the full scoring pass.
        const HAMMING_PREFILTER_MIN_CANDIDATES: usize = 5_000;
        const HAMMING_PREFILTER_MIN_DIM: usize = 512;
        const HAMMING_PREFILTER_RETAIN_RATIO: usize = 16; // P4: tightened from 8 -> 16
        let prefilter_b = quantizer.b;
        let prefilter_supports_b = matches!(prefilter_b, 1 | 2 | 4 | 8);
        let use_sign_prefilter = qjl_len == 0
            && prefilter_supports_b
            && quantizer.d >= HAMMING_PREFILTER_MIN_DIM
            && matches!(metric, DistanceMetric::Ip | DistanceMetric::Cosine)
            && candidate_slots.len() >= HAMMING_PREFILTER_MIN_CANDIDATES;
        let candidate_slots: Vec<u32> = if use_sign_prefilter {
            let target = (candidate_slots.len() / HAMMING_PREFILTER_RETAIN_RATIO)
                .max(internal_k.saturating_mul(10))
                .min(candidate_slots.len());
            let q_signs = quantizer.prepare_query_sign_bits(query);
            let q_signs_ref: &[u8] = &q_signs;
            // Dispatch the const-generic Hamming kernel based on B.
            let score_one = |mse_slice: &[u8]| -> u32 {
                match prefilter_b {
                    1 => {
                        crate::quantizer::prod::hamming_disagree_signs::<1>(q_signs_ref, mse_slice)
                    }
                    2 => {
                        crate::quantizer::prod::hamming_disagree_signs::<2>(q_signs_ref, mse_slice)
                    }
                    4 => {
                        crate::quantizer::prod::hamming_disagree_signs::<4>(q_signs_ref, mse_slice)
                    }
                    8 => {
                        crate::quantizer::prod::hamming_disagree_signs::<8>(q_signs_ref, mse_slice)
                    }
                    _ => unreachable!("prefilter_supports_b checked above"),
                }
            };
            let mut scored: Vec<(u32, u32)> = candidate_slots
                .par_iter()
                .map(|&slot| {
                    let rec = &codes_bytes[slot as usize * stride..(slot as usize + 1) * stride];
                    let dis = score_one(&rec[..mse_len]);
                    (slot, dis)
                })
                .collect();
            if scored.len() > target {
                scored.select_nth_unstable_by_key(target, |x| x.1);
                scored.truncate(target);
            }
            scored.into_iter().map(|(s, _)| s).collect()
        } else {
            candidate_slots
        };

        // Scoring: sequential for small N (avoids Rayon thread park/unpark on Windows
        // where scheduler granularity dominates the actual sub-millisecond work);
        // parallel chunk-based for large N where the work outweighs the thread overhead.
        //
        // SEQ_THRESHOLD is adapted by dimension: high-D work per slot is larger so the
        // break-even point is lower. Target ~5M scoring ops as the parallel kick-in.
        let seq_threshold = (5_000_000 / quantizer.d).clamp(1_000, SEQ_THRESHOLD);
        // Parallel chunk size is also adapted by D to keep per-chunk work roughly stable.
        // Low-D queries use larger chunks (less scheduler overhead), high-D uses smaller
        // chunks (better load-balancing and cache behavior).
        let par_chunk_max = if !self.rerank_enabled && quantizer.d >= 512 {
            2048
        } else {
            4096
        };
        let par_chunk = (2_000_000 / quantizer.d.max(1)).clamp(128, par_chunk_max);
        let n_candidates = candidate_slots.len();
        // Small-k fast path: avoid per-chunk full buffers + select_nth when
        // the requested candidate budget is tiny (common top_k=10 workload).
        let use_small_topk = internal_k <= 32;
        let push_small_topk = |out: &mut Vec<(u32, f64)>, slot: u32, score: f64, k: usize| {
            if out.len() < k {
                out.push((slot, score));
                return;
            }
            let mut min_i = 0usize;
            let mut min_s = out[0].1;
            for (i, (_, s)) in out.iter().enumerate().skip(1) {
                if *s < min_s {
                    min_s = *s;
                    min_i = i;
                }
            }
            if score > min_s {
                out[min_i] = (slot, score);
            }
        };
        let merge_topk = |mut a: Vec<(u32, f64)>, mut b: Vec<(u32, f64)>| -> Vec<(u32, f64)> {
            if a.is_empty() {
                if b.len() > internal_k {
                    b.select_nth_unstable_by(internal_k, |x, y| {
                        y.1.partial_cmp(&x.1).unwrap_or(Ordering::Equal)
                    });
                    b.truncate(internal_k);
                }
                return b;
            }
            if b.is_empty() {
                if a.len() > internal_k {
                    a.select_nth_unstable_by(internal_k, |x, y| {
                        y.1.partial_cmp(&x.1).unwrap_or(Ordering::Equal)
                    });
                    a.truncate(internal_k);
                }
                return a;
            }
            a.append(&mut b);
            if a.len() > internal_k {
                a.select_nth_unstable_by(internal_k, |x, y| {
                    y.1.partial_cmp(&x.1).unwrap_or(Ordering::Equal)
                });
                a.truncate(internal_k);
            }
            a
        };
        let scored: Vec<(u32, f64)> = if n_candidates <= seq_threshold {
            // Sequential path: single idx buffer reused across all slots.
            let mut out = Vec::with_capacity(if use_small_topk {
                internal_k
            } else {
                n_candidates
            });
            // P8 (v0.8.3): IP/Cosine paths route through `score_ip_encoded_packed`
            // (const-generic SIMD for every b ∈ [1, 8], no need for an unpacked
            // idx_buf). The L2 fallback below still needs the unpacked indices.
            let mut idx = vec![0u16; quantizer.n];
            match metric {
                DistanceMetric::Ip => {
                    let prep = quantizer.prepare_ip_query(query);
                    for &slot in &candidate_slots {
                        let rec =
                            &codes_bytes[slot as usize * stride..(slot as usize + 1) * stride];
                        let gamma = f32::from_le_bytes(
                            rec[mse_len + qjl_len..mse_len + qjl_len + 4]
                                .try_into()
                                .expect("live_codes gamma field is always 4 bytes"),
                        );
                        let doc_norm = f32::from_le_bytes(
                            rec[mse_len + qjl_len + 4..mse_len + qjl_len + 8]
                                .try_into()
                                .expect("live_codes norm field is always 4 bytes"),
                        );
                        let raw_ip = quantizer.score_ip_encoded_packed(
                            &prep,
                            &rec[..mse_len],
                            &rec[mse_len..mse_len + qjl_len],
                            gamma as f64,
                        );
                        let score = raw_ip * doc_norm as f64;
                        if use_small_topk {
                            push_small_topk(&mut out, slot, score, internal_k);
                        } else {
                            out.push((slot, score));
                        }
                    }
                }
                DistanceMetric::Cosine => {
                    let prep = quantizer.prepare_ip_query(query);
                    for &slot in &candidate_slots {
                        let rec =
                            &codes_bytes[slot as usize * stride..(slot as usize + 1) * stride];
                        let gamma = f32::from_le_bytes(
                            rec[mse_len + qjl_len..mse_len + qjl_len + 4]
                                .try_into()
                                .expect("live_codes gamma field is always 4 bytes"),
                        );
                        let ip = quantizer.score_ip_encoded_packed(
                            &prep,
                            &rec[..mse_len],
                            &rec[mse_len..mse_len + qjl_len],
                            gamma as f64,
                        );
                        let score = ip * q_norm_inv;
                        if use_small_topk {
                            push_small_topk(&mut out, slot, score, internal_k);
                        } else {
                            out.push((slot, score));
                        }
                    }
                }
                _ => {
                    for &slot in &candidate_slots {
                        let rec =
                            &codes_bytes[slot as usize * stride..(slot as usize + 1) * stride];
                        quantizer.unpack_mse_indices(&rec[..mse_len], &mut idx);
                        let gamma = f32::from_le_bytes(
                            rec[mse_len + qjl_len..mse_len + qjl_len + 4]
                                .try_into()
                                .expect("live_codes gamma field is always 4 bytes"),
                        );
                        let doc_norm = f32::from_le_bytes(
                            rec[mse_len + qjl_len + 4..mse_len + qjl_len + 8]
                                .try_into()
                                .expect("live_codes norm field is always 4 bytes"),
                        );
                        let mut v = quantizer.dequantize(
                            &idx,
                            &rec[mse_len..mse_len + qjl_len],
                            gamma as f64,
                        );
                        v.mapv_inplace(|x| x * doc_norm as f64);
                        let score = score_vectors_with_metric(metric, query, &v);
                        if use_small_topk {
                            push_small_topk(&mut out, slot, score, internal_k);
                        } else {
                            out.push((slot, score));
                        }
                    }
                }
            }
            out
        } else {
            // Parallel path: P8 — score_ip_encoded_packed dispatches the const-generic
            // SIMD kernel for any b ∈ [1, 8], so we no longer maintain a per-chunk
            // CodeIndex scratch buffer.
            match metric {
                DistanceMetric::Ip => {
                    let prep = quantizer.prepare_ip_query(query);
                    candidate_slots
                        .par_chunks(par_chunk)
                        .map(|chunk| {
                            let mut out = Vec::with_capacity(if use_small_topk {
                                internal_k
                            } else {
                                chunk.len()
                            });
                            for &slot in chunk {
                                let rec = &codes_bytes
                                    [slot as usize * stride..(slot as usize + 1) * stride];
                                let gamma = f32::from_le_bytes(
                                    rec[mse_len + qjl_len..mse_len + qjl_len + 4]
                                        .try_into()
                                        .expect("live_codes gamma field is always 4 bytes"),
                                );
                                let doc_norm = f32::from_le_bytes(
                                    rec[mse_len + qjl_len + 4..mse_len + qjl_len + 8]
                                        .try_into()
                                        .expect("live_codes norm field is always 4 bytes"),
                                );
                                // Vectors stored unit-normalized; scale back to recover <q, doc>.
                                let raw_ip = quantizer.score_ip_encoded_packed(
                                    &prep,
                                    &rec[..mse_len],
                                    &rec[mse_len..mse_len + qjl_len],
                                    gamma as f64,
                                );
                                let score = raw_ip * doc_norm as f64;
                                if use_small_topk {
                                    push_small_topk(&mut out, slot, score, internal_k);
                                } else {
                                    out.push((slot, score));
                                }
                            }
                            if !use_small_topk && out.len() > internal_k {
                                out.select_nth_unstable_by(internal_k, |a, b| {
                                    b.1.partial_cmp(&a.1).unwrap_or(Ordering::Equal)
                                });
                                out.truncate(internal_k);
                            }
                            out
                        })
                        .reduce(Vec::new, merge_topk)
                }
                DistanceMetric::Cosine => {
                    let prep = quantizer.prepare_ip_query(query);
                    candidate_slots
                        .par_chunks(par_chunk)
                        .map(|chunk| {
                            let mut out = Vec::with_capacity(if use_small_topk {
                                internal_k
                            } else {
                                chunk.len()
                            });
                            for &slot in chunk {
                                let rec = &codes_bytes
                                    [slot as usize * stride..(slot as usize + 1) * stride];
                                let gamma = f32::from_le_bytes(
                                    rec[mse_len + qjl_len..mse_len + qjl_len + 4]
                                        .try_into()
                                        .expect("live_codes gamma field is always 4 bytes"),
                                );
                                // Vectors stored unit-normalized; ip estimates <query, unit_doc>.
                                // cosine(query, doc) = <query, unit_doc> / ||query||
                                let ip = quantizer.score_ip_encoded_packed(
                                    &prep,
                                    &rec[..mse_len],
                                    &rec[mse_len..mse_len + qjl_len],
                                    gamma as f64,
                                );
                                let score = ip * q_norm_inv;
                                if use_small_topk {
                                    push_small_topk(&mut out, slot, score, internal_k);
                                } else {
                                    out.push((slot, score));
                                }
                            }
                            if !use_small_topk && out.len() > internal_k {
                                out.select_nth_unstable_by(internal_k, |a, b| {
                                    b.1.partial_cmp(&a.1).unwrap_or(Ordering::Equal)
                                });
                                out.truncate(internal_k);
                            }
                            out
                        })
                        .reduce(Vec::new, merge_topk)
                }
                _ => {
                    // L2 and any future metrics: dequantize then compute distance
                    candidate_slots
                        .par_chunks(par_chunk)
                        .map(|chunk| {
                            let mut idx = vec![0u16; quantizer.n];
                            let mut out = Vec::with_capacity(if use_small_topk {
                                internal_k
                            } else {
                                chunk.len()
                            });
                            for &slot in chunk {
                                let rec = &codes_bytes
                                    [slot as usize * stride..(slot as usize + 1) * stride];
                                quantizer.unpack_mse_indices(&rec[..mse_len], &mut idx);
                                let gamma = f32::from_le_bytes(
                                    rec[mse_len + qjl_len..mse_len + qjl_len + 4]
                                        .try_into()
                                        .expect("live_codes gamma field is always 4 bytes"),
                                );
                                let doc_norm = f32::from_le_bytes(
                                    rec[mse_len + qjl_len + 4..mse_len + qjl_len + 8]
                                        .try_into()
                                        .expect("live_codes norm field is always 4 bytes"),
                                );
                                // Dequantize returns unit vector; scale back to original norm.
                                let mut v = quantizer.dequantize(
                                    &idx,
                                    &rec[mse_len..mse_len + qjl_len],
                                    gamma as f64,
                                );
                                v.mapv_inplace(|x| x * doc_norm as f64);
                                let score = score_vectors_with_metric(metric, query, &v);
                                if use_small_topk {
                                    push_small_topk(&mut out, slot, score, internal_k);
                                } else {
                                    out.push((slot, score));
                                }
                            }
                            if !use_small_topk && out.len() > internal_k {
                                out.select_nth_unstable_by(internal_k, |a, b| {
                                    b.1.partial_cmp(&a.1).unwrap_or(Ordering::Equal)
                                });
                                out.truncate(internal_k);
                            }
                            out
                        })
                        .reduce(Vec::new, merge_topk)
                }
            }
        };

        // Keep only the top internal_k scores with partial selection instead of
        // heap push/pop on every candidate (faster for large candidate sets).
        let mut candidates = scored;
        if internal_k < candidates.len() {
            candidates.select_nth_unstable_by(internal_k, |a, b| {
                b.1.partial_cmp(&a.1).unwrap_or(Ordering::Equal)
            });
            candidates.truncate(internal_k);
        }
        let slots: Vec<u32> = candidates.iter().map(|(slot, _)| *slot).collect();
        let needs_payload = include_metadata || include_document;
        let meta_map = if needs_payload && self.metadata.len() > 0 {
            Some(self.metadata.get_many(&slots)?)
        } else {
            None
        };
        let mut out = Vec::with_capacity(candidates.len());

        // Batch-dequantize all rerank candidates in parallel when raw vecs unavailable.
        let deq_vecs: Vec<Array1<f64>> = if self.rerank_enabled && self.live_vraw.is_none() {
            let (encoded, norms): (Vec<_>, Vec<f32>) = slots
                .iter()
                .map(|&slot| {
                    let (idx, qjl, gamma, norm) = self.live_codes_at_slot(slot as usize);
                    ((idx, qjl.to_vec(), gamma as f64), norm)
                })
                .unzip();
            let mut vecs = self.quantizer.dequantize_batch(&encoded);
            for (v, norm) in vecs.iter_mut().zip(norms.iter()) {
                v.mapv_inplace(|x| x * *norm as f64);
            }
            vecs
        } else {
            Vec::new()
        };

        for (i, (cand_slot, cand_score)) in candidates.into_iter().enumerate() {
            let id = if include_id {
                self.id_pool
                    .get_str(cand_slot)
                    .unwrap_or_default()
                    .to_string()
            } else {
                String::new()
            };

            let score = if self.rerank_enabled {
                if self.live_vraw.is_some() {
                    if matches!(self.manifest.rerank_precision, RerankPrecision::ResidualInt4)
                        && !matches!(self.metric, DistanceMetric::L2)
                    {
                        let q_norm_inv = if matches!(self.metric, DistanceMetric::Cosine) {
                            let qn = query.iter().map(|x| x * x).sum::<f64>().sqrt();
                            if qn > 1e-10 { 1.0 / qn } else { 0.0 }
                        } else { 0.0 };
                        self.live_rerank_score_residual_int4(cand_slot as usize, query, cand_score, q_norm_inv)
                    } else {
                        let raw_vec = self.live_raw_vector_at_slot(cand_slot as usize);
                        score_vectors_with_metric(&self.metric, query, &raw_vec)
                    }
                } else {
                    score_vectors_with_metric(&self.metric, query, &deq_vecs[i])
                }
            } else {
                cand_score
            };

            let mut metadata = HashMap::new();
            let mut document = None;
            if let Some(meta) = meta_map.as_ref().and_then(|m| m.get(&cand_slot)).cloned() {
                if include_metadata {
                    metadata = meta.properties;
                }
                if include_document {
                    document = meta.document;
                }
            }

            out.push(SearchResult {
                id,
                score,
                metadata,
                document,
            });
        }
        out.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(Ordering::Equal));
        if out.len() > top_k {
            out.truncate(top_k);
        }
        Ok(out)
    }

    pub fn flush_wal_to_segment(&mut self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        if self.wal_buffer.is_empty() {
            return Ok(());
        }
        let records: Vec<SegmentRecord> = self
            .wal_buffer
            .drain(..)
            .map(|e| SegmentRecord {
                id: e.id,
                is_deleted: e.is_deleted,
            })
            .collect();
        // WAL entries have already been applied to live state when they were
        // created (normal writes) or during reopen recovery (pending WAL replay).
        // Do not re-apply delete tombstones here by ID or a delete followed by a
        // same-ID reinsert in the same WAL batch will incorrectly delete the
        // newest live slot before compaction persists the final state.
        // Persist segments first so any rebuilds (if needed) read a complete view.
        self.segments.flush_batch(records)?;
        // Only compact the live slab when there are pending deletes — compaction
        // copies all live data to a fresh file and rebuilds the id_pool, which is
        // unnecessary (and very expensive) for pure insert workloads.
        if self.has_pending_deletes {
            self.live_compact_slab()?;
            self.has_pending_deletes = false;
        }
        self.live_codes.flush()?;
        if let Some(vraw) = &mut self.live_vraw {
            vraw.flush()?;
        }
        self.wal.truncate()?;
        self.metadata.flush()?;
        self.bm25.flush()?;
        self.persist_id_pool()?;

        self.live_codes.release_handles();
        if let Some(vraw) = &mut self.live_vraw {
            vraw.release_handles();
        }
        let live_codes_path = Path::new(&self.local_dir).join("live_codes.bin");
        let live_vraw_path = Path::new(&self.local_dir).join("live_vectors.bin");

        let live_codes_data = std::fs::read(&live_codes_path)?;
        self.backend.write("live_codes.bin", &live_codes_data)?;

        // Only sync live_vectors.bin if it actually exists (new DBs use dequant reranking).
        let had_vraw = self.live_vraw.is_some();
        if had_vraw {
            let live_vraw_data = std::fs::read(&live_vraw_path)?;
            self.backend.write("live_vectors.bin", &live_vraw_data)?;
        }

        self.live_codes = LiveCodesFile::open(live_codes_path, self.live_stride())?;
        // The file was pre-allocated to GROW_SLOTS multiples; correct len to match
        // the id_pool's slot count so the next alloc_slot() resumes at the right offset.
        let slot_count = self.id_pool.slot_count();
        self.live_codes.set_len(slot_count);
        if had_vraw {
            let mut vraw = LiveCodesFile::open(live_vraw_path, self.live_vraw_stride())?;
            vraw.set_len(slot_count);
            self.live_vraw = Some(vraw);
        }
        self.invalidate_index_state()?;
        self.manifest.vector_count = self.live_active_count() as u64;
        // Keep segment count bounded in long ingest sessions.
        if self.segments.segments.len() >= AUTO_CHECKPOINT_SEGMENTS_THRESHOLD {
            self.compact_segments_now()?;
        }
        self.maybe_persist_state(false)?;
        Ok(())
    }

    /// Flush live state for a clean close without writing a new immutable segment.
    ///
    /// `close()` drops all segment files immediately after flushing, so calling
    /// `flush_wal_to_segment()` would write a segment only to delete it on the next
    /// line.  This path drains the WAL buffer, compacts the live slab if needed, and
    /// syncs live_codes.bin / live_vectors.bin to the backend — identical to the
    /// segment-flush path except no `segments.flush_batch()` is invoked.
    fn flush_for_close(&mut self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        // WAL records are already applied to live state on write; just discard.
        self.wal_buffer.clear();
        if self.has_pending_deletes {
            self.live_compact_slab()?;
            self.has_pending_deletes = false;
        }
        self.live_codes
            .flush()
            .map_err(|e| format!("flush_for_close: live_codes.flush failed: {e}"))?;
        if let Some(vraw) = &mut self.live_vraw {
            vraw.flush()
                .map_err(|e| format!("flush_for_close: live_vraw.flush failed: {e}"))?;
        }
        self.wal
            .truncate()
            .map_err(|e| format!("flush_for_close: wal.truncate failed: {e}"))?;
        self.metadata
            .flush()
            .map_err(|e| format!("flush_for_close: metadata.flush failed: {e}"))?;
        self.bm25
            .flush()
            .map_err(|e| format!("flush_for_close: bm25.flush failed: {e}"))?;

        // Sync live_codes.bin to the backend (required for cloud / remote backends).
        // IMPORTANT: upload live codes *before* persisting the ID pool so that a crash
        // between the two leaves a recoverable state (stale ID pool → WAL replay rebuilds
        // it) rather than an ID pool that references codes that never reached the backend.
        self.live_codes.release_handles();
        let had_vraw = self.live_vraw.is_some();
        if had_vraw {
            if let Some(vraw) = &mut self.live_vraw {
                vraw.release_handles();
            }
        }
        let live_codes_path = Path::new(&self.local_dir).join("live_codes.bin");
        let live_vraw_path = Path::new(&self.local_dir).join("live_vectors.bin");
        // For local backends the mmap flush already wrote the data in-place;
        // re-writing via backend.write() would truncate the file, which on
        // Windows triggers ERROR_USER_MAPPED_FILE (1224) when the kernel has
        // not yet fully released the previous section object.  Only upload for
        // remote/cloud backends where local_dir is a cache separate from storage.
        if !self.backend.is_local_filesystem() {
            let live_codes_data = std::fs::read(&live_codes_path)?;
            self.backend.write("live_codes.bin", &live_codes_data)?;
            if had_vraw {
                let live_vraw_data = std::fs::read(&live_vraw_path)?;
                self.backend.write("live_vectors.bin", &live_vraw_data)?;
            }
        }
        // Persist ID pool last: for remote backends this uploads live_ids.bin after
        // live_codes.bin is safely stored, ensuring the ID pool never gets ahead of
        // the codes it references on the remote side.
        self.persist_id_pool()
            .map_err(|e| format!("flush_for_close: persist_id_pool failed: {e}"))?;
        // Reopen handles so truncate_to() in close() can operate on an open file.
        self.live_codes = LiveCodesFile::open(live_codes_path, self.live_stride())?;
        let slot_count = self.id_pool.slot_count();
        self.live_codes.set_len(slot_count);
        if had_vraw {
            let mut vraw = LiveCodesFile::open(live_vraw_path, self.live_vraw_stride())?;
            vraw.set_len(slot_count);
            self.live_vraw = Some(vraw);
        }
        Ok(())
    }

    pub fn close(&mut self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        self.flush_for_close()
            .map_err(|e| format!("close: flush_for_close failed: {e}"))?;
        // Trim pre-allocated capacity to the exact slot count so the on-disk and
        // memory-mapped sizes are minimal after the database is closed.
        let slot_count = self.id_pool.slot_count();
        self.live_codes
            .truncate_to(slot_count)
            .map_err(|e| format!("close: live_codes.truncate_to({slot_count}) failed: {e}"))?;
        if let Some(vraw) = &mut self.live_vraw {
            vraw.truncate_to(slot_count)
                .map_err(|e| format!("close: live_vraw.truncate_to({slot_count}) failed: {e}"))?;
        }
        self.metadata
            .flush()
            .map_err(|e| format!("close: metadata.flush failed: {e}"))?;
        self.bm25
            .flush()
            .map_err(|e| format!("close: bm25.flush failed: {e}"))?;
        self.persist_id_pool()
            .map_err(|e| format!("close: persist_id_pool failed: {e}"))?;
        self.maybe_persist_state(true)
            .map_err(|e| format!("close: maybe_persist_state(true) failed: {e}"))?;
        // Segments are crash-recovery fallbacks: live_codes.bin + live_ids.bin are now
        // the authoritative state and are fully flushed.  Delete segment files so a clean
        // close does not leave duplicate data on disk.  On next open an empty segment list
        // is fine — WAL replay and live_codes restore state without them.
        self.segments
            .drop_all()
            .map_err(|e| format!("close: segments.drop_all failed: {e}"))?;
        Ok(())
    }

    pub fn vector_count(&self) -> u64 {
        self.id_pool.active_count() as u64
    }

    /// Open a collection scoped under `{local_root}/{tenant}/{database}/{collection}`.
    /// Thin wrapper around `open_with_options` used by the HTTP server.
    pub fn open_collection_scoped(
        uri: &str,
        local_root: &str,
        tenant: &str,
        database: &str,
        collection: &str,
        d: usize,
        b: usize,
        seed: u64,
        metric: DistanceMetric,
    ) -> Result<Self, Box<dyn std::error::Error + Send + Sync>> {
        let path = format!("{local_root}/{tenant}/{database}/{collection}");
        // Build a scoped URI so the storage backend writes to the collection directory,
        // not the top-level storage root (which would pollute root with manifest.json).
        let scoped_uri = format!("{uri}/{tenant}/{database}/{collection}");
        Self::open_with_options(
            &scoped_uri,
            &path,
            d,
            b,
            seed,
            metric,
            true,
            false,
            RerankPrecision::Disabled,
            None,
            false,
            None,
        )
    }

    /// Copy all files in `src_dir` to `dst_dir` atomically (write to `.tmp` suffix then
    /// rename the entire directory).  Used for point-in-time snapshots by the HTTP server.
    pub fn snapshot_local_dir(
        src_dir: &str,
        dst_dir: &str,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let tmp_dir = format!("{dst_dir}.tmp");
        if std::path::Path::new(&tmp_dir).exists() {
            std::fs::remove_dir_all(&tmp_dir)?;
        }
        std::fs::create_dir_all(&tmp_dir)?;
        for entry in std::fs::read_dir(src_dir)? {
            let entry = entry?;
            if entry.file_type()?.is_file() {
                let file_name = entry.file_name();
                std::fs::copy(
                    entry.path(),
                    format!("{tmp_dir}/{}", file_name.to_string_lossy()),
                )?;
            }
        }
        // Atomic rename: replace dst_dir with the fully-written tmp copy.
        if std::path::Path::new(dst_dir).exists() {
            std::fs::remove_dir_all(dst_dir)?;
        }
        std::fs::rename(&tmp_dir, dst_dir)?;
        Ok(())
    }

    /// Check whether a scoped collection exists (i.e., its `manifest.json` is present).
    /// Returns `Some(())` if it exists, `None` otherwise.  Used by the HTTP server to
    /// prevent duplicate collection creation.
    pub fn get_collection_scoped_with_uri(
        _uri: &str,
        local_root: &str,
        tenant: &str,
        database: &str,
        collection: &str,
    ) -> Result<Option<()>, Box<dyn std::error::Error + Send + Sync>> {
        let manifest = std::path::Path::new(local_root)
            .join(tenant)
            .join(database)
            .join(collection)
            .join("manifest.json");
        Ok(if manifest.exists() { Some(()) } else { None })
    }

    /// Create the on-disk directory for a new scoped collection.
    /// The actual engine is opened (and manifest written) by a subsequent `open_collection_scoped`.
    pub fn create_collection_scoped_with_uri(
        _uri: &str,
        local_root: &str,
        tenant: &str,
        database: &str,
        collection: &str,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let path = std::path::Path::new(local_root)
            .join(tenant)
            .join(database)
            .join(collection);
        std::fs::create_dir_all(&path)?;
        Ok(())
    }

    /// Delete the on-disk directory of a scoped collection.
    /// Returns `true` if the directory existed and was removed, `false` if not found.
    pub fn delete_collection_scoped_with_uri(
        _uri: &str,
        local_root: &str,
        tenant: &str,
        database: &str,
        collection: &str,
    ) -> Result<bool, Box<dyn std::error::Error + Send + Sync>> {
        let path = std::path::Path::new(local_root)
            .join(tenant)
            .join(database)
            .join(collection);
        if path.exists() {
            std::fs::remove_dir_all(&path)?;
            Ok(true)
        } else {
            Ok(false)
        }
    }

    /// Result returned by `insert_many_report` / `upsert_many_report`.
    // (Defined as a plain struct so the server can destructure it.)

    /// Batch-insert with per-item failure reporting.  Unlike `insert_many_with_mode`,
    /// this never returns an early `Err`; individual item failures are collected and
    /// returned alongside the successes.
    pub fn insert_many_report(&mut self, items: Vec<BatchWriteItem>) -> BatchWriteReport {
        let mut failed = Vec::new();
        let mut ok = Vec::new();
        for (index, item) in items.into_iter().enumerate() {
            let id = item.id.clone();
            let vec_f64: ndarray::Array1<f64> = item.vector.iter().map(|&x| x as f64).collect();
            match self.insert_many_with_mode(
                vec![BatchWriteItem {
                    id: id.clone(),
                    ..item
                }],
                BatchWriteMode::Insert,
            ) {
                Ok(_) => ok.push(id),
                Err(e) => failed.push(BatchWriteFailure {
                    index,
                    id,
                    error: e.to_string(),
                }),
            }
            let _ = vec_f64; // suppress unused warning
        }
        let applied = ok.len();
        BatchWriteReport {
            ok,
            failed,
            applied,
        }
    }

    /// Same as `insert_many_report` but uses upsert semantics.
    pub fn upsert_many_report(&mut self, items: Vec<BatchWriteItem>) -> BatchWriteReport {
        let mut failed = Vec::new();
        let mut ok = Vec::new();
        for (index, item) in items.into_iter().enumerate() {
            let id = item.id.clone();
            match self.insert_many_with_mode(
                vec![BatchWriteItem {
                    id: id.clone(),
                    ..item
                }],
                BatchWriteMode::Upsert,
            ) {
                Ok(_) => ok.push(id),
                Err(e) => failed.push(BatchWriteFailure {
                    index,
                    id,
                    error: e.to_string(),
                }),
            }
        }
        let applied = ok.len();
        BatchWriteReport {
            ok,
            failed,
            applied,
        }
    }

    /// Batch-delete by string IDs.  Wraps `delete_batch`.
    pub fn delete_many(
        &mut self,
        ids: &[String],
    ) -> Result<usize, Box<dyn std::error::Error + Send + Sync>> {
        self.delete_batch(ids.to_vec())
    }

    /// Trigger segment compaction if the compaction threshold is met.
    /// Flushes the WAL first so all buffered data is on disk before merging.
    pub fn compact(&mut self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        self.flush_wal_to_segment()?;
        self.compact_segments_now()?;
        Ok(())
    }

    /// Force a maintenance checkpoint: flush WAL, persist side stores, and run
    /// segment compaction when the threshold is met.
    pub fn checkpoint(&mut self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        self.compact()
    }

    fn compact_segments_now(&mut self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let compactor = Compactor::new(self.backend.clone());
        let seg_count = self.segments.segments.len();
        if !compactor.should_compact(seg_count) {
            return Ok(());
        }

        let old_segment_names: Vec<String> = self
            .segments
            .segments
            .iter()
            .map(|s| s.name.clone())
            .collect();
        if old_segment_names.is_empty() {
            return Ok(());
        }

        let mut live_records: Vec<SegmentRecord> = self
            .live_iter_id_slots()
            .into_iter()
            .map(|(id, _)| SegmentRecord {
                id,
                is_deleted: false,
            })
            .collect();
        live_records.sort_by(|a, b| a.id.cmp(&b.id));

        let new_segment_name = self.segments.next_segment_name();
        compactor.begin_compaction(&old_segment_names, &new_segment_name)?;
        let new_seg =
            compactor.compact_live_records(&old_segment_names, &new_segment_name, &live_records)?;
        self.segments.remove_segments(&old_segment_names);
        self.segments.add_segment(new_seg);
        compactor.finish_compaction()?;
        Ok(())
    }

    /// Build IVF coarse routing index and persist it to disk.
    ///
    /// `n_clusters`: number of clusters (coarse centroids). Recommended: 256 for N ≥ 100k.
    /// Use `nprobe` parameter in `search()` to activate IVF routing at query time.
    pub fn create_coarse_index(
        &mut self,
        n_clusters: usize,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        // A4 (v0.8.2 audit): n_clusters=0 produces a degenerate empty IVF
        // index that probe() can't use; reject early with a clear message.
        if n_clusters == 0 {
            return Err("create_coarse_index requires n_clusters >= 1".into());
        }
        let active_slots = self.id_pool.iter_active_slots();
        if active_slots.is_empty() {
            return Ok(());
        }
        let codes_bytes = self.live_codes.as_bytes();
        let stride = self.live_stride();
        let mse_len = self.live_mse_len();
        let n = self.quantizer.n;
        let bits = self.quantizer.mse_bits_per_idx();
        let mse_centroids = &self.quantizer.mse_quantizer.centroids;
        let seed = self.quantizer.mse_quantizer.b as u64 * 1234567891;

        let ivf = IvfIndex::build(
            codes_bytes,
            &active_slots,
            stride,
            mse_len,
            n,
            bits,
            mse_centroids,
            n_clusters,
            20, // max_iter
            seed,
        );
        let ivf_path = Path::new(&self.local_dir).join("ivf.bin");
        ivf.save(&ivf_path)?;
        // Mirror to the backend so cloud backends (S3/GCS) persist the index.
        self.backend.write("ivf.bin", &std::fs::read(&ivf_path)?)?;
        self.ivf = Some(ivf);
        Ok(())
    }

    /// Search using IVF coarse routing: score only nprobe clusters instead of all N vectors.
    ///
    /// Requires `create_coarse_index()` to have been called first. Falls back to
    /// brute-force when no IVF index is loaded.
    pub fn search_with_ivf(
        &self,
        query: &Array1<f64>,
        top_k: usize,
        filter: Option<&HashMap<String, JsonValue>>,
        nprobe: usize,
        rerank_factor: Option<usize>,
        include_id: bool,
        include_metadata: bool,
        include_document: bool,
    ) -> Result<Vec<SearchResult>, Box<dyn std::error::Error + Send + Sync>> {
        // IVF centroid scoring uses IP in the MSE-rotated space; non-IP/Cosine metrics
        // would need distance-consistent centroid assignment — fall back to brute-force.
        if !matches!(self.metric, DistanceMetric::Ip | DistanceMetric::Cosine) {
            return self.search_with_filter_and_ann_include(
                query,
                top_k,
                filter,
                None,
                false,
                rerank_factor,
                include_id,
                include_metadata,
                include_document,
            );
        }
        let Some(ivf) = &self.ivf else {
            // No IVF index — fall back to brute-force.
            return self.search_with_filter_and_ann_include(
                query,
                top_k,
                filter,
                None,
                false,
                rerank_factor,
                include_id,
                include_metadata,
                include_document,
            );
        };
        if self.id_pool.active_count() == 0 || top_k == 0 {
            return Ok(Vec::new());
        }

        // Apply the same query normalisation that the main search path does.
        let normalized_query;
        let effective_query = if self.normalize {
            let qn = query.iter().map(|x| x * x).sum::<f64>().sqrt();
            normalized_query = if qn > 1e-10 {
                query / qn
            } else {
                query.to_owned()
            };
            &normalized_query
        } else {
            query
        };

        // Rotate query into MSE-rotated space to score against IVF centroids.
        let query_f32: Vec<f32> = effective_query.iter().map(|&v| v as f32).collect();
        let mut y_query = vec![0.0f32; self.quantizer.n];
        self.quantizer
            .mse_quantizer
            .apply_rotation(&query_f32, &mut y_query);

        // Probe IVF: get candidate slots from top-nprobe clusters.
        let mut candidates = ivf.probe(&y_query, nprobe);

        // Intersect with filter candidates using sorted-list merge (both sides are sorted).
        if let Some(f) = filter {
            let active_slots = self.id_pool.iter_active_slots();
            if let Some(mut filter_slots) = self.resolve_filter_via_index(f, &active_slots) {
                filter_slots.sort_unstable();
                let mut merged = Vec::with_capacity(candidates.len().min(filter_slots.len()));
                let (mut ci, mut fi) = (0, 0);
                while ci < candidates.len() && fi < filter_slots.len() {
                    match candidates[ci].cmp(&filter_slots[fi]) {
                        std::cmp::Ordering::Equal => {
                            merged.push(candidates[ci]);
                            ci += 1;
                            fi += 1;
                        }
                        std::cmp::Ordering::Less => ci += 1,
                        std::cmp::Ordering::Greater => fi += 1,
                    }
                }
                candidates = merged;
            }
        }

        if candidates.is_empty() {
            return Ok(Vec::new());
        }

        // Score the shortlist using the existing quantized scorer.
        self.exhaustive_search_simd(
            effective_query,
            top_k,
            filter,
            Some(candidates),
            rerank_factor,
            include_id,
            include_metadata,
            include_document,
        )
    }

    /// Build the HNSW index with server-friendly defaults.
    /// `max_degree` and `ef_construction` mirror the HTTP API defaults.
    pub fn create_index(
        &mut self,
        max_degree: usize,
        ef_construction: usize,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        self.create_index_with_params(max_degree, ef_construction, 128, 1.2, 5)
    }

    /// Incrementally extend an existing HNSW index with vectors inserted since the last
    /// `create_index()` call (the delta overlay). If no graph exists, performs a full build.
    ///
    /// Delta vectors are merged into the graph using an MSE+Hamming scorer and `delta_slots`
    /// is cleared. Significantly faster than full rebuild for small deltas (< ~10% of corpus).
    pub fn create_index_incremental(
        &mut self,
        max_degree: usize,
        ef_construction: usize,
        search_list_size: usize,
        alpha: f64,
        n_refinements: usize,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        if self.delta_slots.is_empty() && self.graph.has_index() {
            return Ok(());
        }
        if !self.graph.has_index() {
            return self.create_index_with_params(
                max_degree,
                ef_construction,
                search_list_size,
                alpha,
                n_refinements,
            );
        }

        self.flush_wal_to_segment()?;

        let mut id_slot_pairs = self.live_iter_id_slots();
        if id_slot_pairs.is_empty() {
            return Ok(());
        }
        id_slot_pairs.sort_by(|a, b| a.0.cmp(&b.0));
        let indexed_slots: Vec<u32> = id_slot_pairs.iter().map(|(_, slot)| *slot).collect();
        let new_total = indexed_slots.len();

        // Pre-cache MSE codes and QJL bits for all nodes (existing + delta).
        // Uses the same MSE+Hamming scoring as the no-raw-vecs path in create_index_with_params.
        let live_codes = &self.live_codes;
        let qjl_len = self.live_qjl_len();
        let mse_len = self.live_mse_len();
        let quantizer = self.quantizer.clone();
        let qn = quantizer.n;
        let is_fast_mode = self.manifest.fast_mode;
        let cached_qjl_len = if is_fast_mode { 0 } else { qjl_len };

        let n_idx = new_total;
        let mut all_mse = vec![0u16; n_idx * qn];
        let mut all_qjl = vec![0u8; n_idx * cached_qjl_len.max(1)];
        let mut all_norm = vec![0.0f32; n_idx];

        for (i, &slot) in indexed_slots.iter().enumerate() {
            let rec = live_codes.get_slot(slot as usize);
            quantizer.unpack_mse_indices(&rec[..mse_len], &mut all_mse[i * qn..(i + 1) * qn]);
            if cached_qjl_len > 0 {
                all_qjl[i * cached_qjl_len..(i + 1) * cached_qjl_len]
                    .copy_from_slice(&rec[mse_len..mse_len + qjl_len]);
            }
            all_norm[i] = f32::from_le_bytes(
                rec[mse_len + qjl_len + 4..mse_len + qjl_len + 8]
                    .try_into()
                    .expect("live_codes norm field is always 4 bytes"),
            );
        }

        let build_scorer = move |from: u32, candidates: &[u32]| -> Vec<(u32, f64)> {
            let fi = from as usize;
            let from_i = &all_mse[fi * qn..(fi + 1) * qn];
            let from_q = if cached_qjl_len > 0 {
                &all_qjl[fi * cached_qjl_len..(fi + 1) * cached_qjl_len]
            } else {
                &[]
            };
            let mse_prep = quantizer.prepare_ip_query_from_codes(from_i);
            candidates
                .iter()
                .map(|&to| {
                    let ti = to as usize;
                    let to_i = &all_mse[ti * qn..(ti + 1) * qn];
                    let to_q = if cached_qjl_len > 0 {
                        &all_qjl[ti * cached_qjl_len..(ti + 1) * cached_qjl_len]
                    } else {
                        &[]
                    };
                    let to_n = all_norm[ti];
                    let mse_score = quantizer.score_ip_encoded_lite(&mse_prep, to_i, &[], 0.0);
                    let hamming_bonus = if !from_q.is_empty() && !to_q.is_empty() {
                        quantizer.hamming_proximity(from_q, to_q) - 0.5
                    } else {
                        0.0
                    };
                    (to, (mse_score + hamming_bonus) * to_n as f64)
                })
                .collect()
        };

        self.graph.build_incremental(
            new_total,
            max_degree,
            ef_construction,
            n_refinements,
            alpha,
            build_scorer,
        )?;

        self.index_ids = indexed_slots;
        self.index_ids_dirty = true;
        self.delta_slots.clear();
        self.delta_slots_dirty = true;

        self.manifest.index_state = Some(IndexState {
            max_degree,
            ef_construction,
            search_list_size,
            alpha,
            indexed_nodes: self.index_ids.len(),
        });
        self.maybe_persist_state(true)?;
        Ok(())
    }

    /// List collection names (subdirectories containing a `manifest.json`) under
    /// `{local_root}/{tenant}/{database}/`.  Used by the HTTP server.
    pub fn list_collections_scoped(
        local_root: &str,
        tenant: &str,
        database: &str,
    ) -> Result<Vec<String>, Box<dyn std::error::Error + Send + Sync>> {
        let dir = format!("{local_root}/{tenant}/{database}");
        let dir_path = std::path::Path::new(&dir);
        if !dir_path.exists() {
            return Ok(Vec::new());
        }
        let mut collections = Vec::new();
        for entry in std::fs::read_dir(dir_path)? {
            let entry = entry?;
            if entry.file_type()?.is_dir() && entry.path().join("manifest.json").exists() {
                if let Some(name) = entry.file_name().to_str() {
                    collections.push(name.to_string());
                }
            }
        }
        collections.sort();
        Ok(collections)
    }

    pub fn stats(&self) -> DbStats {
        DbStats {
            vector_count: self.vector_count(),
            segment_count: self.segments.segments.len(),
            buffered_vectors: self.wal_buffer.len(),
            d: self.d,
            b: self.b,
            metric: self.metric.to_string(),
            total_disk_bytes: self.total_disk_bytes(),
            has_index: self.can_use_ann_index(),
            index_nodes: self.index_ids.len(),
            live_codes_bytes: self.live_codes.byte_len(),
            live_slot_count: self.live_codes.len(),
            live_id_count: self.id_pool.active_count(),
            live_vectors_count: self.live_active_count(),
            live_vectors_bytes_estimate: self.live_vraw.as_ref().map_or(0, |v| v.byte_len()),
            metadata_entries: self.metadata.len(),
            metadata_bytes_estimate: self.metadata.approx_bytes(),
            ann_slot_count: self.index_ids.len(),
            graph_nodes: self.graph.node_count(),
            delta_size: self.delta_slots.len(),
        }
    }

    fn live_mse_len(&self) -> usize {
        (self.quantizer.n * self.quantizer.mse_bits_per_idx()).div_ceil(8)
    }
    fn live_qjl_len(&self) -> usize {
        if self.quantizer.fast_mode {
            0
        } else {
            self.quantizer.n.div_ceil(8)
        }
    }
    fn live_stride(&self) -> usize {
        self.live_mse_len()
            + self.live_qjl_len()
            + LIVE_GAMMA_BYTES
            + LIVE_NORM_BYTES
            + LIVE_DELETED_BYTES
    }
    /// Bytes per slot in live_vectors.bin (raw rerank buffer).
    fn live_vraw_stride(&self) -> usize {
        match self.manifest.rerank_precision {
            RerankPrecision::F32 => self.d * 4,
            RerankPrecision::F16 => self.d * 2,
            RerankPrecision::Int8 => self.d + 4,
            RerankPrecision::Int4 => (self.d + 1) / 2 + 4,
            RerankPrecision::ResidualInt4 => (self.d + 1) / 2 + 4,
            RerankPrecision::Disabled => self.d * 4, // unreachable; file not created
        }
    }
    fn live_active_count(&self) -> usize {
        self.id_pool.active_count()
    }

    fn live_codes_at_slot(&self, slot: usize) -> (Vec<CodeIndex>, &[u8], f32, f32) {
        let rec = self.live_codes.get_slot(slot);
        let mse_len = self.live_mse_len();
        let qjl_len = self.live_qjl_len();
        let mut indices = vec![0 as CodeIndex; self.quantizer.n];
        self.quantizer
            .unpack_mse_indices(&rec[0..mse_len], &mut indices);
        let qjl = &rec[mse_len..mse_len + qjl_len];
        let gamma = f32::from_le_bytes(
            rec[mse_len + qjl_len..mse_len + qjl_len + 4]
                .try_into()
                .expect("live_codes gamma field is always 4 bytes"),
        );
        let norm = f32::from_le_bytes(
            rec[mse_len + qjl_len + 4..mse_len + qjl_len + 8]
                .try_into()
                .expect("live_codes norm field is always 4 bytes"),
        );
        (indices, qjl, gamma, norm)
    }

    fn live_raw_vector_at_slot(&self, slot: usize) -> Array1<f64> {
        let Some(vraw) = &self.live_vraw else {
            return Array1::zeros(self.d);
        };
        let rec = vraw.get_slot(slot);
        let mut out = Array1::zeros(self.d);
        match self.manifest.rerank_precision {
            RerankPrecision::Int8 => {
                let scale = f32::from_le_bytes(rec[..4].try_into().unwrap()) as f64;
                for i in 0..self.d {
                    out[i] = (rec[4 + i] as i8) as f64 * scale / 127.0;
                }
            }
            RerankPrecision::Int4 => {
                let scale = f32::from_le_bytes(rec[..4].try_into().unwrap()) as f64;
                for i in 0..self.d {
                    let byte = rec[4 + i / 2];
                    let nibble = if i % 2 == 0 {
                        byte & 0x0F
                    } else {
                        (byte >> 4) & 0x0F
                    };
                    let signed = if nibble > 7 {
                        nibble as i8 - 16
                    } else {
                        nibble as i8
                    };
                    out[i] = signed as f64 * scale / 7.0;
                }
            }
            RerankPrecision::ResidualInt4 => {
                // Residual stored INT4-quantized + per-vector scale. The residual
                // was computed at encode time as `vector - dequant_unit(codes) * doc_norm`,
                // so it already absorbs the per-vector scale. To recover the full
                // vector here we add `dequant_unit(codes) * doc_norm + residual_decoded`.
                //
                // NOTE: this code path is only used by callers that need the full
                // f64 vector (L2 metric, debug, etc.). Hot rerank paths use the
                // additive `live_rerank_score_residual_int4` helper to skip the
                // O(d²) code re-dequant.
                let scale = f32::from_le_bytes(rec[..4].try_into().unwrap()) as f64;
                let mut residual_decoded = vec![0.0f64; self.d];
                for i in 0..self.d {
                    let byte = rec[4 + i / 2];
                    let nibble = if i % 2 == 0 {
                        byte & 0x0F
                    } else {
                        (byte >> 4) & 0x0F
                    };
                    let signed = if nibble > 7 {
                        nibble as i8 - 16
                    } else {
                        nibble as i8
                    };
                    residual_decoded[i] = signed as f64 * scale / 7.0;
                }
                // Read MSE codes + doc_norm for this slot, dequant codes, scale by doc_norm.
                let stride = self.live_stride();
                let mse_len = self.live_mse_len();
                let qjl_len = self.live_qjl_len();
                let codes_bytes = self.live_codes.as_bytes();
                let rec_codes = &codes_bytes[slot * stride..slot * stride + mse_len];
                let mut idx = vec![0 as CodeIndex; self.quantizer.n];
                self.quantizer.unpack_mse_indices(rec_codes, &mut idx);
                let recon = self.quantizer.mse_quantizer.dequantize(&idx);
                let doc_norm = f32::from_le_bytes(
                    codes_bytes[slot * stride + mse_len + qjl_len + 4
                              ..slot * stride + mse_len + qjl_len + 8]
                        .try_into()
                        .expect("doc_norm field is 4 bytes"),
                ) as f64;
                for i in 0..self.d {
                    out[i] = recon[i] * doc_norm + residual_decoded[i];
                }
            }
            RerankPrecision::F16 => {
                for i in 0..self.d {
                    let bytes: [u8; 2] = rec[i * 2..(i + 1) * 2]
                        .try_into()
                        .expect("vraw f16 record has 2 bytes per element");
                    out[i] = half::f16::from_le_bytes(bytes).to_f64();
                }
            }
            RerankPrecision::F32 | RerankPrecision::Disabled => {
                for i in 0..self.d {
                    let bytes: [u8; 4] = rec[i * 4..(i + 1) * 4]
                        .try_into()
                        .expect("vraw f32 record has 4 bytes per element");
                    out[i] = f32::from_le_bytes(bytes) as f64;
                }
            }
        }
        out
    }

    /// Encode the per-vector rerank record at the given slot.
    ///
    /// `vector` is the unit-vector (or raw if normalize=False).
    /// `idx` is the MSE code indices for this vector — used by the
    /// `ResidualInt4` mode to compute `residual = vec - dequant(idx)`.
    /// Other precision modes ignore `idx`.
    ///
    /// Convenience wrapper around `live_save_raw_vector_with_residual` that
    /// computes the residual serially when needed (used by per-item callers
    /// like WAL replay). The hot batch-insert path should pass a
    /// pre-computed residual via `live_save_raw_vector_with_residual`
    /// directly to amortise the dequant cost across cores.
    fn live_save_raw_vector(&mut self, slot: u32, vector: &[f32], idx: &[CodeIndex]) {
        // ResidualInt4: compute residual serially (per-item path).
        // For batch inserts, callers should pre-compute residuals in parallel via
        // `compute_residuals_batch_parallel` and pass through to
        // `live_save_raw_vector_with_residual` to avoid the O(d²) dequant
        // serially-per-vector.
        let residual_storage: Option<Vec<f32>> = match self.manifest.rerank_precision {
            RerankPrecision::ResidualInt4 => {
                let recon_unit = self.quantizer.mse_quantizer.dequantize(idx);
                let doc_norm: f32 = vector.iter().map(|v| v * v).sum::<f32>().sqrt().max(1e-9);
                let mut residual = vec![0f32; self.d];
                for i in 0..self.d {
                    residual[i] = vector[i] - recon_unit[i] as f32 * doc_norm;
                }
                Some(residual)
            }
            _ => None,
        };
        self.live_save_raw_vector_with_residual(slot, vector, residual_storage.as_deref());
    }

    /// Lower-level encode that takes a pre-computed `precomputed_residual` for
    /// `RerankPrecision::ResidualInt4`. Pass `None` for the other precision
    /// modes — the parameter is ignored. This is the entry point used by the
    /// batch insert path after `compute_residuals_batch_parallel`.
    fn live_save_raw_vector_with_residual(
        &mut self,
        slot: u32,
        vector: &[f32],
        precomputed_residual: Option<&[f32]>,
    ) {
        let Some(vraw) = &mut self.live_vraw else { return; };
        let rec = vraw.get_slot_mut(slot as usize);
        match self.manifest.rerank_precision {
            RerankPrecision::Int8 => {
                let scale = vector
                    .iter()
                    .map(|v| v.abs())
                    .fold(0.0_f32, f32::max)
                    .max(1e-9);
                rec[..4].copy_from_slice(&scale.to_le_bytes());
                for (i, &v) in vector.iter().enumerate() {
                    let q = (v / scale * 127.0).round().clamp(-127.0, 127.0) as i8;
                    rec[4 + i] = q as u8;
                }
            }
            RerankPrecision::Int4 => {
                let scale = vector
                    .iter()
                    .map(|v| v.abs())
                    .fold(0.0_f32, f32::max)
                    .max(1e-9);
                rec[..4].copy_from_slice(&scale.to_le_bytes());
                let n = vector.len();
                for i in (0..n).step_by(2) {
                    let q0 = (vector[i] / scale * 7.0).round().clamp(-8.0, 7.0) as i8;
                    let q1 = if i + 1 < n {
                        (vector[i + 1] / scale * 7.0).round().clamp(-8.0, 7.0) as i8
                    } else {
                        0_i8
                    };
                    // lower nibble = dim i (even), upper nibble = dim i+1 (odd)
                    rec[4 + i / 2] = (q0 as u8 & 0x0F) | ((q1 as u8 & 0x0F) << 4);
                }
            }
            RerankPrecision::ResidualInt4 => {
                // Caller must supply precomputed_residual for this mode.
                let residual = precomputed_residual
                    .expect("ResidualInt4 requires precomputed_residual");
                let scale = residual
                    .iter()
                    .map(|v| v.abs())
                    .fold(0.0_f32, f32::max)
                    .max(1e-9);
                rec[..4].copy_from_slice(&scale.to_le_bytes());
                let n = residual.len();
                for i in (0..n).step_by(2) {
                    let q0 = (residual[i] / scale * 7.0).round().clamp(-8.0, 7.0) as i8;
                    let q1 = if i + 1 < n {
                        (residual[i + 1] / scale * 7.0).round().clamp(-8.0, 7.0) as i8
                    } else {
                        0_i8
                    };
                    rec[4 + i / 2] = (q0 as u8 & 0x0F) | ((q1 as u8 & 0x0F) << 4);
                }
            }
            RerankPrecision::F16 => {
                for (i, &val) in vector.iter().enumerate() {
                    let h = half::f16::from_f32(val);
                    rec[i * 2..(i + 1) * 2].copy_from_slice(&h.to_le_bytes());
                }
            }
            RerankPrecision::F32 | RerankPrecision::Disabled => {
                for (i, &val) in vector.iter().enumerate() {
                    rec[i * 4..(i + 1) * 4].copy_from_slice(&val.to_le_bytes());
                }
            }
        }
    }

    /// **P12 (v0.8.3)** — additive scoring helper for `RerankPrecision::ResidualInt4`.
    ///
    /// Reads the INT4 residual at `slot`, dequantizes it to `f32`, and returns
    /// `<query, residual_decoded>`. The caller computes
    /// `final_score = code_score_from_brute_pass + doc_norm * this_residual_score`
    /// (or just `+ this_residual_score` for cosine where doc_norm == 1).
    ///
    /// Avoids redundant code re-dequantization at query time — the brute pass
    /// has already produced `<q, dequant(codes)> * doc_norm`; we just need the
    /// residual contribution.
    /// **P12e (v0.8.3)** — pre-pass that computes the per-vector residual
    /// `vec − dequant(idx)·doc_norm` for a whole batch at once.
    ///
    /// Used by the batch insert path when `RerankPrecision::ResidualInt4` is
    /// enabled. The serial first-cut took ~24 min for 100k × d=3072 (single-
    /// threaded O(d²) dequant per slot, memory-bandwidth-bound).
    ///
    /// Dense mode: uses **a single SGEMM** (`Q^T · y_tilde`) to do all N
    /// inverse rotations in one pass, then a parallel per-column residual
    /// subtraction. The d×d rotation matrix is streamed once — D×B vs D²×B
    /// memory traffic compared to per-vector dequant.
    ///
    /// SRHT mode: per-vector inverse-SRHT is already O(d log d) and matrix-
    /// free, so a Rayon par_iter is sufficient.
    fn compute_residuals_batch_parallel(
        &self,
        unit_vecs: &[&[f32]],
        all_indices: &[Vec<CodeIndex>],
    ) -> Vec<Vec<f32>> {
        use rayon::prelude::*;
        debug_assert_eq!(unit_vecs.len(), all_indices.len());
        let d = self.d;
        let q = &self.quantizer;
        let mse = &q.mse_quantizer;
        let b = unit_vecs.len();

        if let Some(rotation_matrix) = mse.rotation_matrix.as_ref() {
            // Dense mode — GEMM-batched dequant.
            let n = mse.n; // == d for dense
            let centroids = &mse.centroids;

            // Build y_tilde: n × b col-major (each column = centroids[idx[row]]).
            let mut y_tilde = vec![0.0f32; n * b];
            for (col, idx) in all_indices.iter().enumerate() {
                let off = col * n;
                for row in 0..n {
                    y_tilde[off + row] = centroids[idx[row] as usize];
                }
            }

            // recon = Q^T · y_tilde, d × b col-major. Q is row-major (d × d);
            // passing strides (1, d) reads it as col-major = Q^T.
            let mut recon = vec![0.0f32; d * b];
            unsafe {
                matrixmultiply::sgemm(
                    d,
                    d,
                    b,
                    1.0,
                    rotation_matrix.as_ptr(),
                    1, // Q^T: rsa=1
                    d as isize, // Q^T: csa=d
                    y_tilde.as_ptr(),
                    1, // col-major y_tilde
                    n as isize,
                    0.0,
                    recon.as_mut_ptr(),
                    1, // col-major recon
                    d as isize,
                );
            }

            // Per-column residual subtraction in parallel. Recon col `col` lives
            // at recon[col*d .. (col+1)*d].
            (0..b)
                .into_par_iter()
                .map(|col| {
                    let vec = unit_vecs[col];
                    let doc_norm: f32 = vec.iter().map(|v| v * v).sum::<f32>().sqrt().max(1e-9);
                    let off = col * d;
                    let mut residual = vec![0f32; d];
                    for i in 0..d {
                        residual[i] = vec[i] - recon[off + i] * doc_norm;
                    }
                    residual
                })
                .collect()
        } else {
            // SRHT mode — per-vector inverse SRHT is already cheap.
            unit_vecs
                .par_iter()
                .zip(all_indices.par_iter())
                .map(|(vec, idx)| {
                    let recon_unit = q.mse_quantizer.dequantize(idx);
                    let doc_norm: f32 = vec.iter().map(|v| v * v).sum::<f32>().sqrt().max(1e-9);
                    let mut residual = vec![0f32; d];
                    for i in 0..d {
                        residual[i] = vec[i] - recon_unit[i] as f32 * doc_norm;
                    }
                    residual
                })
                .collect()
        }
    }

    /// **P12 additive rerank score for `RerankPrecision::ResidualInt4`.**
    ///
    /// `cand_score` is the score the brute-force pass already produced for this
    /// candidate using the MSE codes alone. We add the residual contribution
    /// without re-dequantizing the codes:
    ///   * IP:     `final = cand_score + <q, residual_decoded>`
    ///     (the encode side already absorbed `doc_norm` into the residual).
    ///   * Cosine: `final = cand_score + q_norm_inv × <q, residual_decoded>`
    ///   * L2:     no clean additive form — fall back to full reconstruction.
    ///
    /// At d=1536 this is ~10× faster than `live_raw_vector_at_slot` →
    /// `score_vectors_with_metric` for ResidualInt4 (which re-dequants the
    /// codes per candidate, an O(d²) operation in dense mode).
    fn live_rerank_score_residual_int4(
        &self,
        slot: usize,
        query: &Array1<f64>,
        cand_score: f64,
        q_norm_inv: f64,
    ) -> f64 {
        match self.metric {
            DistanceMetric::Ip => {
                let residual_score = self.live_residual_score_at_slot(slot, query);
                cand_score + residual_score
            }
            DistanceMetric::Cosine => {
                let residual_score = self.live_residual_score_at_slot(slot, query);
                cand_score + q_norm_inv * residual_score
            }
            DistanceMetric::L2 => {
                let raw_vec = self.live_raw_vector_at_slot(slot);
                score_vectors_with_metric(&self.metric, query, &raw_vec)
            }
        }
    }

    fn live_residual_score_at_slot(&self, slot: usize, query: &Array1<f64>) -> f64 {
        let Some(vraw) = &self.live_vraw else { return 0.0; };
        let rec = vraw.get_slot(slot);
        let scale = f32::from_le_bytes(rec[..4].try_into().unwrap()) as f64;
        let inv_scale_over_7 = scale / 7.0;
        let mut score = 0.0_f64;
        for i in 0..self.d {
            let byte = rec[4 + i / 2];
            let nibble = if i % 2 == 0 { byte & 0x0F } else { (byte >> 4) & 0x0F };
            let signed = if nibble > 7 { nibble as i8 - 16 } else { nibble as i8 };
            let v = signed as f64 * inv_scale_over_7;
            score += query[i] * v;
        }
        score
    }

    fn approx_raw_vector_from_entry(&self, entry: &WalEntry) -> Vec<f32> {
        let mut vec = self.quantizer.dequantize(
            &entry.quantized_indices,
            &entry.qjl_bits,
            entry.gamma as f64,
        );
        vec.mapv_inplace(|x| x * entry.norm as f64);
        vec.iter().map(|&x| x as f32).collect()
    }

    fn apply_wal_entries_to_live_state(
        &mut self,
        entries: &[WalEntry],
        rebuild_from_wal_only: bool,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        if rebuild_from_wal_only {
            self.live_codes.clear()?;
            if let Some(vraw) = &mut self.live_vraw {
                vraw.clear()?;
            }
            self.id_pool = IdPool::new();
            self.metadata.clear();
            self.bm25.clear();
        }

        for entry in entries {
            if entry.is_deleted {
                self.live_delete_slot(&entry.id);
                continue;
            }

            let slot = self.live_alloc_or_update(
                &entry.id,
                &entry.quantized_indices,
                &entry.qjl_bits,
                entry.gamma,
                entry.norm,
            )?;
            if self.live_vraw.is_some() {
                let approx_raw = self.approx_raw_vector_from_entry(entry);
                self.live_save_raw_vector(slot, &approx_raw, &entry.quantized_indices);
            }
            let meta: VectorMetadata = serde_json::from_str(&entry.metadata_json)?;
            if has_meaningful_metadata(&meta) {
                self.metadata.put(slot, &meta)?;
            } else {
                self.metadata.delete(slot)?;
            }
            match meta.document.as_deref() {
                Some(doc) if !doc.is_empty() => self.bm25.put(slot, doc),
                _ => self.bm25.delete(slot),
            }
        }

        Ok(())
    }

    fn live_alloc_slot(
        &mut self,
        id: &str,
        indices: &[CodeIndex],
        qjl: &[u8],
        gamma: f32,
        norm: f32,
    ) -> Result<u32, Box<dyn std::error::Error + Send + Sync>> {
        let slot = self.id_pool.insert(id)?;
        let new_slot = self.live_codes.alloc_slot()?;
        if let Some(vraw) = &mut self.live_vraw {
            let _ = vraw.alloc_slot()?;
        } // Keep aligned
        let mse_len = self.live_mse_len();
        let qjl_len = self.live_qjl_len();
        let packed_mse = self.quantizer.pack_mse_indices(indices);
        let rec = self.live_codes.get_slot_mut(new_slot);
        rec[0..mse_len].copy_from_slice(&packed_mse);
        if qjl_len > 0 {
            rec[mse_len..mse_len + qjl_len].copy_from_slice(qjl);
        }
        rec[mse_len + qjl_len..mse_len + qjl_len + 4].copy_from_slice(&gamma.to_le_bytes());
        rec[mse_len + qjl_len + 4..mse_len + qjl_len + 8].copy_from_slice(&norm.to_le_bytes());
        rec[mse_len + qjl_len + 8] = 0u8;
        Ok(slot)
    }

    fn live_alloc_or_update(
        &mut self,
        id: &str,
        indices: &[CodeIndex],
        qjl: &[u8],
        gamma: f32,
        norm: f32,
    ) -> Result<u32, Box<dyn std::error::Error + Send + Sync>> {
        if let Some(slot) = self.id_pool.get_slot(id) {
            let mse_len = self.live_mse_len();
            let qjl_len = self.live_qjl_len();
            let packed_mse = self.quantizer.pack_mse_indices(indices);
            let rec = self.live_codes.get_slot_mut(slot as usize);
            rec[0..mse_len].copy_from_slice(&packed_mse);
            if qjl_len > 0 {
                rec[mse_len..mse_len + qjl_len].copy_from_slice(qjl);
            }
            rec[mse_len + qjl_len..mse_len + qjl_len + 4].copy_from_slice(&gamma.to_le_bytes());
            rec[mse_len + qjl_len + 4..mse_len + qjl_len + 8].copy_from_slice(&norm.to_le_bytes());
            rec[mse_len + qjl_len + 8] = 0u8;
            Ok(slot)
        } else {
            self.live_alloc_slot(id, indices, qjl, gamma, norm)
        }
    }

    fn live_delete_slot(&mut self, id: &str) {
        if let Some(slot) = self.id_pool.delete_by_id(id) {
            let stride = self.live_stride();
            let rec = self.live_codes.get_slot_mut(slot as usize);
            rec[stride - 1] = 1u8;
            // Drop the slot from BM25 immediately so deleted IDs disappear from
            // sparse search results without waiting for compaction. (Dense search
            // already filters via the deleted-flag byte set above.)
            self.bm25.delete(slot);
        }
    }

    fn live_iter_id_slots(&self) -> Vec<(String, u32)> {
        self.id_pool.iter_active()
    }

    fn live_compact_slab(&mut self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let stride = self.live_stride();
        let vstride = self.live_vraw_stride();
        let temp_path = Path::new(&self.local_dir).join("live_codes.bin.tmp");
        let vtemp_path = Path::new(&self.local_dir).join("live_vectors.bin.tmp");

        // Only compact live_vectors.bin if it actually exists (new DBs use dequant reranking).
        let had_vraw = self.live_vraw.is_some();
        let mut new_codes = LiveCodesFile::open(temp_path.clone(), stride)?;
        let mut new_vraw = if had_vraw {
            Some(LiveCodesFile::open(vtemp_path.clone(), vstride)?)
        } else {
            None
        };

        new_codes.clear()?;
        if let Some(nv) = &mut new_vraw {
            nv.clear()?;
        }

        let mut new_pool = IdPool::new();
        let mut new_metadata = HashMap::new();

        for (id, old_slot) in self.live_iter_id_slots() {
            let old_rec = self.live_codes.get_slot(old_slot as usize);
            let next_alloc = new_codes.alloc_slot()?;
            new_codes.get_slot_mut(next_alloc).copy_from_slice(old_rec);

            if let (Some(nv), Some(ov)) = (&mut new_vraw, &mut self.live_vraw) {
                let old_vrec = ov.get_slot(old_slot as usize);
                let _ = nv.alloc_slot()?;
                nv.get_slot_mut(next_alloc).copy_from_slice(old_vrec);
            }

            let new_slot = new_pool.insert(&id)?;
            debug_assert_eq!(new_slot as usize, next_alloc);
            if let Some(meta) = self.metadata.get(old_slot)? {
                new_metadata.insert(new_slot, meta);
            }
        }

        new_codes.truncate_to(new_pool.active_count())?;
        if let Some(nv) = &mut new_vraw {
            nv.truncate_to(new_pool.active_count())?;
        }

        new_codes.flush()?;
        drop(new_codes);
        if let Some(nv) = new_vraw {
            nv.flush()?;
            drop(nv);
        }

        let final_path = Path::new(&self.local_dir).join("live_codes.bin");
        let vfinal_path = Path::new(&self.local_dir).join("live_vectors.bin");

        self.live_codes.release_handles();
        if let Some(vraw) = &mut self.live_vraw {
            vraw.release_handles();
        }

        std::fs::rename(temp_path, &final_path)?;
        if had_vraw {
            std::fs::rename(vtemp_path, &vfinal_path)?;
        }

        self.live_codes = LiveCodesFile::open(final_path, stride)?;
        if had_vraw {
            self.live_vraw = Some(LiveCodesFile::open(vfinal_path, vstride)?);
        }

        self.id_pool = new_pool;
        self.metadata.replace_all(new_metadata);
        // Compaction renumbers slots, so the BM25 index — keyed by slot — is now
        // stale. The doc text survives in the new metadata; rebuild from there.
        self.bm25.clear();
        for (slot, doc) in self.metadata.iter_docs() {
            self.bm25.put(slot, doc);
        }

        // v0.8.2 audit fix #1: invalidate the IVF coarse index. Its
        // `cluster_index` and `cluster_map` reference the OLD slot numbers
        // from before compaction; using them after this point would silently
        // return wrong vectors. Drop both the in-memory state and the on-disk
        // file so a reopen doesn't reload stale data. The user can rebuild
        // with `create_coarse_index()`; until then `search_with_ivf` falls
        // back to brute-force.
        //
        // We log warnings on removal failure (e.g. permission denied, file
        // locked on Windows) rather than failing compaction outright — the
        // engine state is already consistent in memory at this point, and a
        // belt-and-suspenders consistency check at `open()` (see the IVF
        // load path) catches a stale `ivf.bin` if removal here ever fails
        // silently.
        if self.ivf.is_some() {
            self.ivf = None;
            let ivf_path = Path::new(&self.local_dir).join("ivf.bin");
            if let Err(e) = std::fs::remove_file(&ivf_path) {
                if e.kind() != std::io::ErrorKind::NotFound {
                    eprintln!(
                        "WARNING: failed to remove stale ivf.bin during compaction \
                         ({}); reopen will detect the staleness and drop it.",
                        e
                    );
                }
            }
            if let Err(e) = self.backend.delete("ivf.bin") {
                let msg = e.to_string();
                if !msg.contains("not found") && !msg.contains("NotFound") {
                    eprintln!(
                        "WARNING: failed to remove stale ivf.bin from backend during \
                         compaction ({}); reopen will detect the staleness and drop it.",
                        msg
                    );
                }
            }
        }

        // v0.8.2 audit fix #2: `delta_slots` holds slot numbers from the
        // pre-compaction id_pool. After renumbering they're meaningless and
        // would steer auto_use_ann() toward wrong fallback decisions and
        // corrupt the delta-overlay scoring path. Clear them; subsequent
        // inserts will repopulate against the new id_pool.
        if !self.delta_slots.is_empty() {
            self.delta_slots.clear();
            self.delta_slots_dirty = true;
        }

        Ok(())
    }

    fn persist_id_pool(&self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        save_id_pool(&self.local_dir, &self.backend, &self.id_pool)
    }

    fn invalidate_index_state(&mut self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        self.index_ids.clear();
        self.manifest.index_state = None;
        self.index_ids_dirty = true;
        Ok(())
    }

    fn maybe_persist_state(
        &mut self,
        force: bool,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        if !force
            && !self.index_ids_dirty
            && !self.delta_slots_dirty
            && self.pending_manifest_updates < MANIFEST_SAVE_INTERVAL_OPS
        {
            return Ok(());
        }
        if self.index_ids_dirty {
            save_index_ids(&self.local_dir, &self.index_ids)?;
            self.backend
                .write(INDEX_IDS_FILE, &serialize_index_ids(&self.index_ids)?)?;
            self.index_ids_dirty = false;
        }
        if self.delta_slots_dirty {
            let delta_bytes = serialize_index_ids(&self.delta_slots)?;
            // Write to local_dir directly so load_delta_slots (which checks
            // local_dir first) always sees fresh data, even when the backend
            // is S3 whose local cache root may differ from local_dir.
            std::fs::write(
                Path::new(&self.local_dir).join(DELTA_IDS_FILE),
                &delta_bytes,
            )?;
            self.backend.write(DELTA_IDS_FILE, &delta_bytes)?;
            self.delta_slots_dirty = false;
        }
        self.save_manifest()?;
        self.pending_manifest_updates = 0;
        Ok(())
    }

    fn can_use_ann_index(&self) -> bool {
        self.graph.has_index()
            && !self.index_ids.is_empty()
            && self
                .manifest
                .index_state
                .as_ref()
                .is_some_and(|s| s.indexed_nodes == self.index_ids.len())
    }

    fn save_manifest(&self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let mut m = self.manifest.clone();
        m.quantizer = None;
        let manifest_path = format!("{}/manifest.json", self.local_dir);
        m.save(&manifest_path)?;
        self.backend
            .write("manifest.json", &serde_json::to_vec_pretty(&m)?)?;
        Ok(())
    }

    fn total_disk_bytes(&self) -> u64 {
        let mut total = self.segments.total_disk_size();
        let mut files = vec![
            "manifest.json",
            "metadata.bin",
            "wal.log",
            QUANTIZER_STATE_FILE,
            "graph.bin",
            INDEX_IDS_FILE,
            "live_codes.bin",
        ];
        if self.rerank_enabled {
            files.push("live_vectors.bin");
        }
        for name in files {
            if let Ok(size) = self.backend.size(name) {
                total += size;
            }
        }
        total
    }

    fn write_vector_entry(
        &mut self,
        id: String,
        vector: &Array1<f64>,
        metadata: HashMap<String, JsonValue>,
        document: Option<String>,
        is_deleted: bool,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let vec_f32: Vec<f32> = vector.iter().map(|&v| v as f32).collect();
        let norm = vec_f32.iter().map(|x| x * x).sum::<f32>().sqrt();
        if self.normalize && norm <= 1e-10 {
            return Err("Cannot normalize a zero vector: L2 norm is zero".into());
        }
        let vec_unit: Vec<f32> = if norm > 1e-10 {
            vec_f32.iter().map(|&x| x / norm).collect()
        } else {
            vec_f32.clone()
        };
        // When normalize=true, treat the vector as unit-length so IP ≡ cosine.
        // The stored norm drives IP score scaling; setting it to 1.0 removes that scaling.
        let stored_norm = if self.normalize { 1.0f32 } else { norm };
        let raw_for_rerank = if self.normalize { &vec_unit } else { &vec_f32 };
        let (indices, qjl, gamma) = self.quantizer.quantize(&vec_unit);
        let meta = VectorMetadata {
            properties: metadata,
            document,
        };
        let entry = WalEntry {
            id: id.clone(),
            quantized_indices: indices,
            qjl_bits: qjl,
            gamma: gamma as f32,
            norm: stored_norm,
            metadata_json: serde_json::to_string(&meta)?,
            is_deleted,
        };
        self.wal.append(&entry, false)?;
        self.wal_buffer.push(entry.clone());
        if !is_deleted {
            let slot = self.live_alloc_or_update(
                &id,
                &entry.quantized_indices,
                &entry.qjl_bits,
                entry.gamma,
                stored_norm,
            )?;
            // Track new slot in delta overlay (same as batch path).
            // index_ids and delta_slots are both kept sorted; use binary_search
            // for O(log n) membership test instead of O(n) Vec::contains.
            if !self.index_ids.is_empty() && self.index_ids.binary_search(&slot).is_err() {
                if let Err(pos) = self.delta_slots.binary_search(&slot) {
                    self.delta_slots.insert(pos, slot);
                    self.delta_slots_dirty = true;
                }
            }
            self.live_save_raw_vector(slot, raw_for_rerank, &entry.quantized_indices);
            if has_meaningful_metadata(&meta) {
                self.metadata.put(slot, &meta)?;
            } else {
                self.metadata.delete(slot)?;
            }
            // BM25 mirrors the document field independently of `has_meaningful_metadata`:
            // a non-empty doc must always be indexed, and a slot whose doc was just
            // dropped must lose its sparse posting even if other metadata changed.
            match meta.document.as_deref() {
                Some(doc) if !doc.is_empty() => self.bm25.put(slot, doc),
                _ => self.bm25.delete(slot),
            }
        }
        // Inserts do NOT invalidate the HNSW index — new slots go to delta_slots.
        self.manifest.vector_count = self.live_active_count() as u64;
        self.maybe_persist_state(false)?;
        if self.wal_buffer.len() >= self.wal_flush_threshold {
            self.flush_wal_to_segment()?;
        }
        Ok(())
    }

    pub fn insert_many_with_mode(
        &mut self,
        items: Vec<BatchWriteItem>,
        mode: BatchWriteMode,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        // Build indexed_set once for the whole batch — index_ids never changes
        // during ingest. Using a HashSet for O(1) per-item lookup.
        let indexed_set: std::collections::HashSet<u32> = if self.index_ids.is_empty() {
            std::collections::HashSet::new()
        } else {
            self.index_ids.iter().copied().collect()
        };
        for chunk in items.chunks(5000) {
            let mut wal_entries = Vec::with_capacity(chunk.len());
            let mut metadata_entries: Vec<(u32, VectorMetadata)> = Vec::with_capacity(chunk.len());
            let mut metadata_deletes: Vec<u32> = Vec::new();
            let mut touched_slots: Vec<u32> = Vec::with_capacity(chunk.len());
            // Normalize each vector to unit sphere before quantization so the
            // Lloyd-Max codebook (fitted to Beta-distribution unit-sphere coords) is valid.
            // Compute (unit_vec, norm) once to avoid a second O(d) pass per vector.
            // Use Rayon for large chunks; sequential for small ones to avoid
            // thread park/unpark overhead (same threshold as quantize_batch).
            const NORM_PAR_THRESHOLD: usize = 512;
            let unit_vecs_and_norms: Vec<(Vec<f32>, f32)> = if chunk.len() > NORM_PAR_THRESHOLD {
                chunk
                    .par_iter()
                    .map(|item| {
                        let n = item.vector.iter().map(|x| x * x).sum::<f32>().sqrt();
                        if n > 1e-10 {
                            (item.vector.iter().map(|&x| x / n).collect(), n)
                        } else {
                            (item.vector.clone(), n)
                        }
                    })
                    .collect()
            } else {
                chunk
                    .iter()
                    .map(|item| {
                        let n = item.vector.iter().map(|x| x * x).sum::<f32>().sqrt();
                        if n > 1e-10 {
                            (item.vector.iter().map(|&x| x / n).collect(), n)
                        } else {
                            (item.vector.clone(), n)
                        }
                    })
                    .collect()
            };
            let vec_refs: Vec<&[f32]> = unit_vecs_and_norms
                .iter()
                .map(|(v, _)| v.as_slice())
                .collect();
            let quantized = self.quantizer.quantize_batch(&vec_refs);

            // P12e: pre-compute residuals in parallel for ResidualInt4 to avoid
            // serial O(d²) dequant in the per-vector save loop below. The bytes
            // needed by `live_save_raw_vector_with_residual` are computed here
            // for the ENTIRE batch under Rayon par_iter, then consumed sequentially.
            //
            // For non-rerank-stored modes (Disabled) and other precisions this
            // pre-pass is a no-op (vector kept None).
            let precomputed_residuals: Option<Vec<Vec<f32>>> = match self.manifest.rerank_precision {
                RerankPrecision::ResidualInt4 if self.live_vraw.is_some() => {
                    // For ResidualInt4 the residual is computed against the
                    // vector that's actually stored: vec_unit when normalize=True,
                    // otherwise vec_f32 (raw).
                    let store_refs: Vec<&[f32]> = unit_vecs_and_norms
                        .iter()
                        .enumerate()
                        .map(|(i, (uv, _))| if self.normalize {
                            uv.as_slice()
                        } else {
                            chunk[i].vector.as_slice()
                        })
                        .collect();
                    let all_idx: Vec<Vec<CodeIndex>> = quantized
                        .iter()
                        .map(|(idx, _, _)| idx.clone())
                        .collect();
                    Some(self.compute_residuals_batch_parallel(&store_refs, &all_idx))
                }
                _ => None,
            };

            for (_i, (item, ((unit_vec, norm), (indices, qjl, gamma)))) in chunk
                .iter()
                .zip(unit_vecs_and_norms.iter().zip(quantized))
                .enumerate()
            {
                match mode {
                    BatchWriteMode::Insert if self.id_pool.contains(&item.id) => {
                        return Err(format!("ID '{}' already exists", item.id).into());
                    }
                    BatchWriteMode::Update if !self.id_pool.contains(&item.id) => {
                        return Err(format!("ID '{}' does not exist", item.id).into());
                    }
                    _ => {}
                }
                // When normalize=true, store norm=1.0 so IP ≡ cosine (no scaling).
                let stored_norm = if self.normalize { 1.0f32 } else { *norm };
                let raw_for_rerank: &[f32] = if self.normalize {
                    unit_vec
                } else {
                    &item.vector
                };
                let meta = VectorMetadata {
                    properties: item.metadata.clone(),
                    document: item.document.clone(),
                };
                let entry = WalEntry {
                    id: item.id.clone(),
                    quantized_indices: indices,
                    qjl_bits: qjl,
                    gamma: gamma as f32,
                    norm: stored_norm,
                    metadata_json: serde_json::to_string(&meta)?,
                    is_deleted: false,
                };
                let slot = self.live_alloc_or_update(
                    &item.id,
                    &entry.quantized_indices,
                    &entry.qjl_bits,
                    entry.gamma,
                    stored_norm,
                )?;
                let precomputed = precomputed_residuals
                    .as_ref()
                    .map(|all| all[_i].as_slice());
                self.live_save_raw_vector_with_residual(slot, raw_for_rerank, precomputed);
                touched_slots.push(slot);
                if has_meaningful_metadata(&meta) {
                    metadata_entries.push((slot, meta));
                } else {
                    metadata_deletes.push(slot);
                }
                wal_entries.push(entry);
            }
            self.wal.append_batch(&wal_entries, false)?;
            self.metadata.put_many(&metadata_entries)?;
            self.metadata.delete_many(&metadata_deletes)?;
            // Drive BM25 from the same per-slot decisions: any slot whose document
            // is non-empty gets indexed; any slot in `metadata_deletes` (no-meta
            // path) drops out of the sparse index too, since it carries no doc.
            for (slot, meta) in &metadata_entries {
                match meta.document.as_deref() {
                    Some(doc) if !doc.is_empty() => self.bm25.put(*slot, doc),
                    _ => self.bm25.delete(*slot),
                }
            }
            if !metadata_deletes.is_empty() {
                self.bm25.delete_many(&metadata_deletes);
            }
            // Track newly allocated slots in the delta overlay so ANN search finds
            // them without a rebuild. indexed_set is built once before the chunk
            // loop. delta_slots is kept sorted; binary_search gives O(log n).
            if !indexed_set.is_empty() {
                for slot in &touched_slots {
                    if !indexed_set.contains(slot) {
                        if let Err(pos) = self.delta_slots.binary_search(slot) {
                            self.delta_slots.insert(pos, *slot);
                            self.delta_slots_dirty = true;
                        }
                    }
                }
            }
            self.wal_buffer.extend(wal_entries);
        }
        // Inserts do NOT invalidate the HNSW index.  New slots are tracked in
        // delta_slots (above); ANN search unions HNSW results with a brute-force
        // pass over the delta.  The index is only invalidated on deletes or
        // on explicit rebuild via create_index().
        self.manifest.vector_count = self.live_active_count() as u64;
        self.maybe_persist_state(false)?;
        if self.wal_buffer.len() >= self.wal_flush_threshold {
            self.flush_wal_to_segment()?;
        }
        Ok(())
    }
}

fn save_quantizer_state(
    local_dir: &str,
    backend: &Arc<StorageBackend>,
    quantizer: &ProdQuantizer,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let bytes = bincode::serialize(quantizer)?;
    std::fs::write(format!("{}/{}", local_dir, QUANTIZER_STATE_FILE), &bytes)?;
    backend.write(QUANTIZER_STATE_FILE, &bytes)?;
    Ok(())
}

fn load_quantizer_state(
    local_dir: &str,
    backend: &Arc<StorageBackend>,
) -> Result<ProdQuantizer, Box<dyn std::error::Error + Send + Sync>> {
    let local = format!("{}/{}", local_dir, QUANTIZER_STATE_FILE);
    if Path::new(&local).exists() {
        return Ok(bincode::deserialize(&std::fs::read(&local)?)?);
    }
    if let Ok(bytes) = backend.read(QUANTIZER_STATE_FILE) {
        std::fs::write(&local, &bytes)?;
        return Ok(bincode::deserialize(&bytes)?);
    }
    Err("Quantizer state not found".into())
}

fn save_id_pool(
    local_dir: &str,
    backend: &Arc<StorageBackend>,
    pool: &IdPool,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let bytes = if let Some(alive_bits) = pool.dense_alive_bits_if_compatible() {
        // Dense format: all IDs are "id-{slot}" — store only a bitset.
        let dense = DenseIdDashDisk {
            slot_count: pool.slot_count() as u32,
            alive_bits,
        };
        let mut out = ID_POOL_DENSE_MAGIC.to_vec();
        out.extend_from_slice(&bincode::serialize(&dense)?);
        out
    } else {
        // Sparse format: omit the hashes field (recomputed on load from bytes/offsets/lens).
        // Saves 8 bytes × slot_count vs the raw bincode layout.
        let sparse = SparseIdDisk {
            bytes: pool.raw_bytes().to_vec(),
            offsets: pool.raw_offsets().to_vec(),
            lens: pool.raw_lens().to_vec(),
            alive: pool.raw_alive().to_vec(),
        };
        let sparse_bytes = bincode::serialize(&sparse)?;
        // Optional compressed sparse encoding for large ID pools.
        // Keep legacy sparse format when compression is not worthwhile.
        if sparse_bytes.len() >= 4 * 1024 {
            let compressed = zstd::stream::encode_all(sparse_bytes.as_slice(), 1)?;
            if compressed.len() + 256 < sparse_bytes.len() {
                let mut out = ID_POOL_SPARSE_ZSTD_MAGIC.to_vec();
                out.extend_from_slice(&compressed);
                out
            } else {
                let mut out = ID_POOL_SPARSE_MAGIC.to_vec();
                out.extend_from_slice(&sparse_bytes);
                out
            }
        } else {
            let mut out = ID_POOL_SPARSE_MAGIC.to_vec();
            out.extend_from_slice(&sparse_bytes);
            out
        }
    };
    let local = format!("{}/{}", local_dir, ID_POOL_FILE);
    std::fs::write(&local, &bytes)?;
    backend.write(ID_POOL_FILE, &bytes)?;
    Ok(())
}

fn load_id_pool(
    local_dir: &str,
    backend: &Arc<StorageBackend>,
) -> Result<IdPool, Box<dyn std::error::Error + Send + Sync>> {
    let local = format!("{}/{}", local_dir, ID_POOL_FILE);
    if Path::new(&local).exists() {
        let bytes = std::fs::read(&local)?;
        let mut pool: IdPool = deserialize_id_pool_bytes(&bytes)?;
        pool.rebuild_lookup();
        return Ok(pool);
    }
    if let Ok(bytes) = backend.read(ID_POOL_FILE) {
        std::fs::write(&local, &bytes)?;
        let mut pool: IdPool = deserialize_id_pool_bytes(&bytes)?;
        pool.rebuild_lookup();
        return Ok(pool);
    }
    Err("live_ids.bin not found".into())
}

#[derive(Serialize, Deserialize, Clone, Debug)]
struct DenseIdDashDisk {
    slot_count: u32,
    alive_bits: Vec<u8>,
}

/// Compact on-disk layout that omits the redundant `hashes` field.
/// Hashes are recomputed from `bytes`/`offsets`/`lens` at load time.
#[derive(Serialize, Deserialize, Clone, Debug)]
struct SparseIdDisk {
    bytes: Vec<u8>,
    offsets: Vec<u32>,
    lens: Vec<u16>,
    alive: Vec<bool>,
}

fn deserialize_id_pool_bytes(
    bytes: &[u8],
) -> Result<IdPool, Box<dyn std::error::Error + Send + Sync>> {
    if bytes.starts_with(ID_POOL_DENSE_MAGIC) {
        let dense: DenseIdDashDisk = bincode::deserialize(&bytes[ID_POOL_DENSE_MAGIC.len()..])?;
        return Ok(IdPool::from_dense_id_dash(
            dense.slot_count as usize,
            &dense.alive_bits,
        ));
    }
    if bytes.starts_with(ID_POOL_SPARSE_MAGIC) {
        let sparse: SparseIdDisk = bincode::deserialize(&bytes[ID_POOL_SPARSE_MAGIC.len()..])?;
        return IdPool::from_sparse(sparse.bytes, sparse.offsets, sparse.lens, sparse.alive);
    }
    if bytes.starts_with(ID_POOL_SPARSE_ZSTD_MAGIC) {
        let raw = zstd::stream::decode_all(&bytes[ID_POOL_SPARSE_ZSTD_MAGIC.len()..])?;
        let sparse: SparseIdDisk = bincode::deserialize(&raw)?;
        return IdPool::from_sparse(sparse.bytes, sparse.offsets, sparse.lens, sparse.alive);
    }
    // Legacy: raw bincode with hashes included.
    Ok(bincode::deserialize(bytes)?)
}

fn save_index_ids(
    local_dir: &str,
    ids: &[u32],
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    std::fs::write(
        format!("{}/{}", local_dir, INDEX_IDS_FILE),
        serialize_index_ids(ids)?,
    )?;
    Ok(())
}

fn serialize_index_ids(ids: &[u32]) -> Result<Vec<u8>, Box<dyn std::error::Error + Send + Sync>> {
    Ok(serde_json::to_vec_pretty(ids)?)
}

fn load_index_ids(local_dir: &str) -> Result<Vec<u32>, Box<dyn std::error::Error + Send + Sync>> {
    let local = format!("{}/{}", local_dir, INDEX_IDS_FILE);
    if Path::new(&local).exists() {
        return Ok(serde_json::from_slice(&std::fs::read(&local)?)?);
    }
    Ok(Vec::new())
}

fn load_delta_slots(
    local_dir: &str,
    backend: &Arc<StorageBackend>,
) -> Result<Vec<u32>, Box<dyn std::error::Error + Send + Sync>> {
    let local = format!("{}/{}", local_dir, DELTA_IDS_FILE);
    if Path::new(&local).exists() {
        return Ok(serde_json::from_slice(&std::fs::read(&local)?)?);
    }
    // Fall back to backend (e.g. S3 restore on a fresh machine).
    if let Ok(bytes) = backend.read(DELTA_IDS_FILE) {
        std::fs::write(&local, &bytes)?;
        return Ok(serde_json::from_slice(&bytes)?);
    }
    Ok(Vec::new())
}

#[cfg(test)]
mod tests;
