"""Find heuristic rules that fire on benign prompts (false positives).

Goal: precision tuning. Each false positive listed here either means the rule
is too broad and should be tightened, or the prompt is mislabeled in the
benchmark (sometimes happens with crowd-sourced data).

Usage:
    python -m eval.audit_heuristics --dataset rogue
"""

from __future__ import annotations

import argparse
import sys
from collections import Counter, defaultdict
from collections.abc import Iterable

from eval.data import load_rogue_benchmark, load_xtram1_test
from promptward.stages.heuristics import HeuristicMatch, HeuristicsStage

DATASETS = {
    "rogue": load_rogue_benchmark,
    "xtram1": load_xtram1_test,
}


def main() -> int:
    args = _parse_args()
    eval_set = DATASETS[args.dataset]()
    stage = HeuristicsStage()

    fp_per_rule: dict[str, list[tuple[str, HeuristicMatch]]] = defaultdict(list)
    fn_per_rule_class: Counter[str] = Counter()
    n_benign_flagged = 0
    n_attack_caught = 0

    for text, label in zip(eval_set.texts, eval_set.labels, strict=False):
        result = stage.run(text)
        if not result.matches:
            if label == 1:
                fn_per_rule_class["<no_match>"] += 1
            continue

        if label == 0:
            n_benign_flagged += 1
            for match in result.matches:
                fp_per_rule[match.rule_id].append((text, match))
        else:
            n_attack_caught += 1

    n_benign = eval_set.n_benign
    n_attack = eval_set.n_attack

    print(f"Dataset: {eval_set.name} (attack={n_attack}, benign={n_benign})")
    print(
        f"Heuristic-only:  TP={n_attack_caught}/{n_attack} "
        f"({n_attack_caught / max(n_attack, 1):.1%})  "
        f"FP={n_benign_flagged}/{n_benign} "
        f"({n_benign_flagged / max(n_benign, 1):.1%})"
    )
    print()

    if not fp_per_rule:
        print("No false positives.")
        return 0

    print(f"{'rule':<32} {'FP':>5} {'examples':>5}")
    print("-" * 50)
    for rule_id, matches in sorted(fp_per_rule.items(), key=lambda kv: -len(kv[1])):
        print(f"{rule_id:<32} {len(matches):>5} (showing up to {min(args.examples, len(matches))})")

    print()
    for rule_id, matches in sorted(fp_per_rule.items(), key=lambda kv: -len(kv[1])):
        print(f"\n=== rule: {rule_id} ({len(matches)} false positives) ===")
        for text, match in _sample(matches, args.examples):
            preview = (text[:140] + "...") if len(text) > 140 else text
            print(f"  matched={match.matched_text!r}")
            print(f"  prompt={preview!r}")

    return 0


def _sample(items: list, n: int) -> Iterable:
    return items[:n]


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", choices=list(DATASETS), default="rogue")
    p.add_argument("--examples", type=int, default=5, help="Examples per rule to show.")
    return p.parse_args()


if __name__ == "__main__":
    sys.exit(main())
