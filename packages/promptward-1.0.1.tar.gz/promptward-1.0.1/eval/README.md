# Evaluation

Harness for scoring `promptward.Guard` (and competing models) against a
suite of held-out benchmarks.

## Held-out benchmarks (5)

| Benchmark | Source | n | Notes |
|---|---|---|---|
| rogue | `rogue-security/prompt-injections-benchmark` | 5,000 | Long, narrative-wrapped attacks |
| xtram1_test | `xTRam1/safe-guard-prompt-injection` test split | 2,060 | Standard injection, held out from training |
| slabs_test | `S-Labs/prompt-injection-dataset` test split | 2,101 | Security-lab curated, held out from training |
| deepset_test | `deepset/prompt-injections` test split | 116 | Short, polite override attacks |
| jailbreakbench | `JailbreakBench/JBB-Behaviors` | 200 | Harmful-behavior elicitation |

The training builder dedupes against all five before fitting any model.

## Headline metrics

| Metric | Why it matters |
|---|---|
| AUC | Threshold-independent ranking quality |
| F1 @ 0.5 | Practical default-threshold quality |
| FPR @ TPR=0.99 | False-positive rate at high recall — the deployment-critical number |
| p50 / p95 latency | Adoption gate; we ship sub-10 ms p50 |

## Running

```bash
# Default: promptward heuristics-only against all 5 benchmarks
python -m eval.benchmark_suite

# Local model (e.g. a freshly-exported ONNX checkpoint)
python -m eval.benchmark_suite --runner local:/path/to/model

# Compare against public baselines on a specific benchmark
python -m eval.benchmark_suite \
    --runner local:/path/to/model \
    --runner protectai/deberta-v3-base-prompt-injection-v2 \
    --benchmark rogue --benchmark jailbreakbench
```

## Other tools

- `eval/audit_heuristics.py` — finds heuristic false positives against a
  benign dataset; used to tighten the regex layer.
- `eval/dataset_audit.py` — produces a markdown report comparing training
  corpus distribution against the rogue benchmark (length, signature
  patterns, etc.). Useful for diagnosing distribution gaps.

## Single-benchmark mode

For quick smoke checks against one benchmark:

```bash
python -m eval.benchmark --runner promptward-fast --dataset rogue
```
