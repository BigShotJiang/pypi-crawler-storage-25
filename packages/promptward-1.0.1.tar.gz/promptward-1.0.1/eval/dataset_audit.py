"""Comprehensive dataset audit — produces evidence to inform training decisions.

Five questions:
  1. Distribution mismatch: are rogue prompts systematically different from
     our training data in length, structure, vocabulary?
  2. Per-source quality: which sources contribute unique information vs.
     duplicates of other sources?
  3. Label honesty: are sources labeled correctly? Sample audits.
  4. Truncation impact: how often does rogue's actual injection live past
     our MAX_LEN=256 token window?
  5. Pattern audit: what kinds of prompts dominate each source?

Output: a markdown report at eval/data_audit_report.md.

Usage:
    python -m eval.dataset_audit
    python -m eval.dataset_audit --limit 5000  # per source, for speed
"""

from __future__ import annotations

import argparse
import logging
import re
import sys
from collections import Counter
from pathlib import Path
from statistics import mean, median, stdev

import numpy as np

from eval.data import load_rogue_benchmark
from training.builder import DEFAULT_CAPS
from training.data.loaders import LABELED_LOADERS, LoadedDataset, load_dolly_benign

logger = logging.getLogger(__name__)

# Same patterns as the heuristics — we use them here as "signature" probes
# to cluster prompts by structure, not to flag.
_SIGNATURES = {
    "ignore_previous": re.compile(
        r"\b(ignore|disregard|forget)\b[^.\n]{0,40}\b(previous|prior|above|all)\b[^.\n]{0,40}\binstructions?\b",
        re.IGNORECASE,
    ),
    "dan_persona": re.compile(r"\b(DAN|STAN|jailbroken|do\s+anything\s+now)\b", re.IGNORECASE),
    "role_assignment": re.compile(
        r"\b(you\s+are|act\s+as|pretend\s+to\s+be|imagine\s+you\s+are)\b", re.IGNORECASE
    ),
    "academic_framing": re.compile(
        r"\b(research|study|academic|university|professor|scholar|paper|thesis|essay)\b",
        re.IGNORECASE,
    ),
    "professional_framing": re.compile(
        r"\b(SEO|professional|developer|engineer|consultant|expert|specialist|analyst)\b",
        re.IGNORECASE,
    ),
    "narrative_framing": re.compile(
        r"\b(imagine|once\s+upon|fictional|hypothetical|story|character|alternate\s+universe|parallel)\b",
        re.IGNORECASE,
    ),
    "document_wrapper": re.compile(
        r"\b(summarize|extract|translate|article|excerpt|document|passage|content)\b.{0,40}:?\s*\n",
        re.IGNORECASE,
    ),
    "system_prompt_leak": re.compile(
        r"\b(reveal|print|repeat|show|display)\b[^.\n]{0,40}\b(system\s+prompt|instructions|prompt|original)\b",
        re.IGNORECASE,
    ),
    "encoding_attack": re.compile(r"(base64|rot13|hex|\\x[0-9a-f]{2}|%[0-9A-Fa-f]{2})"),
    "json_structure": re.compile(r"^\s*[\{\[]"),
    "begins_with_ignore": re.compile(r"^\s*(please\s+)?(ignore|disregard|forget)", re.IGNORECASE),
}


def length_stats(texts: list[str]) -> dict:
    if not texts:
        return {"n": 0}
    lens = [len(t) for t in texts]
    return {
        "n": len(texts),
        "min": min(lens),
        "max": max(lens),
        "mean": int(mean(lens)),
        "median": int(median(lens)),
        "p95": int(np.percentile(lens, 95)),
        "p99": int(np.percentile(lens, 99)),
        "std": int(stdev(lens)) if len(lens) > 1 else 0,
    }


def signature_breakdown(texts: list[str]) -> dict[str, int]:
    counts: Counter = Counter()
    for text in texts:
        for name, pattern in _SIGNATURES.items():
            if pattern.search(text):
                counts[name] += 1
    return dict(counts)


def signature_percentages(texts: list[str]) -> dict[str, float]:
    n = max(len(texts), 1)
    raw = signature_breakdown(texts)
    return {k: 100.0 * v / n for k, v in raw.items()}


def token_count_estimate(texts: list[str], tokenizer=None) -> list[int]:
    """Estimate token count. Uses tokenizer if available, else 4 chars/token."""
    if tokenizer is not None:
        return [len(tokenizer(t, truncation=False)["input_ids"]) for t in texts]
    return [max(1, len(t) // 4) for t in texts]


def main() -> int:
    args = _parse_args()
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    report_lines = ["# Dataset Audit Report\n"]
    report_lines.append(
        f"Generated against current training corpus (caps: {len(DEFAULT_CAPS)} sources).\n"
    )

    # 1) Load rogue benchmark first
    rogue = load_rogue_benchmark()
    rogue_attack = [t for t, lbl in zip(rogue.texts, rogue.labels, strict=False) if lbl == 1]
    rogue_benign = [t for t, lbl in zip(rogue.texts, rogue.labels, strict=False) if lbl == 0]

    report_lines.append("## 1. Rogue Benchmark Profile (held-out eval)\n")
    report_lines.append(
        f"- Total: {len(rogue.texts):,} (attack={len(rogue_attack):,}, benign={len(rogue_benign):,})\n"
    )
    report_lines.append("### Attack length stats (chars):")
    report_lines.append(_format_stats(length_stats(rogue_attack)))
    report_lines.append("\n### Benign length stats (chars):")
    report_lines.append(_format_stats(length_stats(rogue_benign)))

    report_lines.append("\n### Attack signature distribution:")
    report_lines.append(_format_signatures(signature_percentages(rogue_attack)))
    report_lines.append("\n### Benign signature distribution:")
    report_lines.append(_format_signatures(signature_percentages(rogue_benign)))

    # 2) Load our training sources
    report_lines.append("\n## 2. Per-Source Profile\n")
    pre_caps = {name: cap * args.pre_cap_mult for name, cap in DEFAULT_CAPS.items()}

    sources: dict[str, LoadedDataset] = {}
    for name, fn in LABELED_LOADERS.items():
        try:
            ds = fn(limit=pre_caps.get(name, args.limit))
            sources[name] = ds
            logger.info("loaded %s: n=%d", name, len(ds.texts))
        except Exception as exc:
            logger.warning("skipped %s: %s", name, exc)

    sources["dolly"] = load_dolly_benign(limit=15000)

    for name, ds in sources.items():
        attacks = [t for t, lbl in zip(ds.texts, ds.labels, strict=False) if lbl == 1]
        benigns = [t for t, lbl in zip(ds.texts, ds.labels, strict=False) if lbl == 0]
        report_lines.append(f"\n### `{name}` ({len(ds.texts):,} samples)\n")
        report_lines.append(f"- Attack: {len(attacks):,} | Benign: {len(benigns):,}")
        if attacks:
            stats = length_stats(attacks)
            report_lines.append(f"- Attack length (chars): {_inline_stats(stats)}")
        if benigns:
            stats = length_stats(benigns)
            report_lines.append(f"- Benign length (chars): {_inline_stats(stats)}")

        if attacks:
            sigs = signature_percentages(attacks)
            top = sorted(sigs.items(), key=lambda x: -x[1])[:5]
            report_lines.append(
                "- Attack signatures (top 5): " + ", ".join(f"{k}={v:.0f}%" for k, v in top)
            )

        # Sample
        sample = attacks[0] if attacks else (benigns[0] if benigns else "")
        sample_short = sample.replace("\n", " | ")[:200]
        if sample_short:
            label = "attack" if attacks else "benign"
            report_lines.append(f"- Sample ({label}): `{sample_short}`")

    # 3) Distribution comparison: rogue vs combined training
    report_lines.append("\n## 3. Distribution Mismatch (rogue vs training)\n")
    all_train_attacks: list[str] = []
    all_train_benigns: list[str] = []
    for ds in sources.values():
        for t, lbl in zip(ds.texts, ds.labels, strict=False):
            (all_train_attacks if lbl == 1 else all_train_benigns).append(t)

    report_lines.append(
        f"\n### Length distribution comparison (chars)\n"
        f"```\n"
        f"                    rogue_attack   rogue_benign   train_attack   train_benign\n"
        f"{_compare_row('median', rogue_attack, rogue_benign, all_train_attacks, all_train_benigns, 'median')}\n"
        f"{_compare_row('mean  ', rogue_attack, rogue_benign, all_train_attacks, all_train_benigns, 'mean')}\n"
        f"{_compare_row('p95   ', rogue_attack, rogue_benign, all_train_attacks, all_train_benigns, 'p95')}\n"
        f"{_compare_row('p99   ', rogue_attack, rogue_benign, all_train_attacks, all_train_benigns, 'p99')}\n"
        f"```\n"
    )

    report_lines.append("\n### Signature comparison (rogue attack vs train attack)\n")
    rogue_attack_sigs = signature_percentages(rogue_attack)
    train_attack_sigs = signature_percentages(all_train_attacks)
    report_lines.append("```")
    report_lines.append(f"{'signature':<22} {'rogue %':>10} {'train %':>10} {'gap':>8}")
    report_lines.append("-" * 52)
    all_sigs = sorted(set(rogue_attack_sigs) | set(train_attack_sigs))
    for sig in all_sigs:
        r = rogue_attack_sigs.get(sig, 0.0)
        t = train_attack_sigs.get(sig, 0.0)
        gap = r - t
        marker = " <-- gap" if abs(gap) > 10 else ""
        report_lines.append(f"{sig:<22} {r:>9.1f}% {t:>9.1f}% {gap:>+7.1f}%{marker}")
    report_lines.append("```")

    # 4) Truncation impact
    report_lines.append("\n## 4. Truncation Impact (MAX_LEN=256 tokens)\n")
    try:
        from transformers import AutoTokenizer

        tok = AutoTokenizer.from_pretrained("microsoft/deberta-v3-small")
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token

        rogue_attack_tokens = token_count_estimate(rogue_attack, tok)
        rogue_benign_tokens = token_count_estimate(rogue_benign, tok)

        report_lines.append(
            f"- Rogue attacks: median={int(median(rogue_attack_tokens))}, "
            f"p95={int(np.percentile(rogue_attack_tokens, 95))} tokens"
        )
        report_lines.append(
            f"- Rogue benigns: median={int(median(rogue_benign_tokens))}, "
            f"p95={int(np.percentile(rogue_benign_tokens, 95))} tokens"
        )
        for threshold in (256, 512, 1024):
            attack_trunc = sum(1 for x in rogue_attack_tokens if x > threshold)
            benign_trunc = sum(1 for x in rogue_benign_tokens if x > threshold)
            report_lines.append(
                f"- Truncated at MAX_LEN={threshold}: "
                f"attacks={attack_trunc}/{len(rogue_attack_tokens)} ({100 * attack_trunc / max(len(rogue_attack_tokens), 1):.1f}%) "
                f"benigns={benign_trunc}/{len(rogue_benign_tokens)} ({100 * benign_trunc / max(len(rogue_benign_tokens), 1):.1f}%)"
            )
    except Exception as exc:
        report_lines.append(f"- Tokenizer unavailable; skipped: {exc}")

    # 5) Label-honesty audit
    report_lines.append("\n## 5. Label Honesty Audit (3 random samples per source)\n")
    rng = np.random.default_rng(42)
    for name, ds in sources.items():
        if not ds.texts:
            continue
        report_lines.append(f"\n### `{name}`")
        attack_idx = [i for i, lbl in enumerate(ds.labels) if lbl == 1]
        benign_idx = [i for i, lbl in enumerate(ds.labels) if lbl == 0]
        for label, indices in (("attack", attack_idx), ("benign", benign_idx)):
            if not indices:
                continue
            sample_ids = rng.choice(indices, size=min(3, len(indices)), replace=False)
            for sid in sample_ids:
                text = ds.texts[int(sid)].replace("\n", " | ")[:180]
                report_lines.append(f"- _{label}_: `{text}`")

    # Save
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(report_lines) + "\n")
    logger.info("wrote %s", out_path)
    print("\n=== KEY FINDINGS ===")
    print(
        _summary_findings(
            rogue_attack,
            rogue_benign,
            all_train_attacks,
            all_train_benigns,
            rogue_attack_sigs,
            train_attack_sigs,
        )
    )

    return 0


def _format_stats(stats: dict) -> str:
    if stats.get("n", 0) == 0:
        return "- (empty)"
    return (
        f"- n={stats['n']:,} | min={stats['min']} | median={stats['median']} "
        f"| mean={stats['mean']} | p95={stats['p95']} | p99={stats['p99']} | max={stats['max']}"
    )


def _inline_stats(stats: dict) -> str:
    if stats.get("n", 0) == 0:
        return "(empty)"
    return f"median={stats['median']}, p95={stats['p95']}, max={stats['max']}"


def _format_signatures(sigs: dict[str, float]) -> str:
    if not sigs:
        return "- (none detected)"
    lines = []
    for k, v in sorted(sigs.items(), key=lambda x: -x[1]):
        lines.append(f"- {k}: {v:.1f}%")
    return "\n".join(lines)


def _compare_row(name, ra, rb, ta, tb, stat):
    def s(texts):
        if not texts:
            return "—"
        st = length_stats(texts)
        return f"{st[stat]:>10,}"

    return f"{name:<20}{s(ra):>15}{s(rb):>15}{s(ta):>15}{s(tb):>15}"


def _summary_findings(
    rogue_attack, rogue_benign, train_attack, train_benign, rogue_attack_sigs, train_attack_sigs
) -> str:
    findings = []
    ra_med = median([len(t) for t in rogue_attack])
    ta_med = median([len(t) for t in train_attack])
    if ra_med > 1.5 * ta_med:
        findings.append(
            f"- ⚠ Rogue attacks are {ra_med / ta_med:.1f}x longer than our train attacks (median {ra_med:.0f} vs {ta_med:.0f} chars)"
        )
    elif ta_med > 1.5 * ra_med:
        findings.append(
            f"- ⚠ Our train attacks are {ta_med / ra_med:.1f}x longer than rogue's (median {ta_med:.0f} vs {ra_med:.0f} chars)"
        )

    for sig in rogue_attack_sigs:
        gap = rogue_attack_sigs.get(sig, 0) - train_attack_sigs.get(sig, 0)
        if gap > 15:
            findings.append(
                f"- ⚠ '{sig}' under-represented in train: rogue {rogue_attack_sigs[sig]:.0f}% vs train {train_attack_sigs.get(sig, 0):.0f}%"
            )
        elif gap < -15:
            findings.append(
                f"- ⚠ '{sig}' over-represented in train: rogue {rogue_attack_sigs.get(sig, 0):.0f}% vs train {train_attack_sigs[sig]:.0f}%"
            )

    if not findings:
        findings.append("- No obvious distribution gaps in length or signatures.")
    return "\n".join(findings)


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--output", default="eval/data_audit_report.md")
    p.add_argument("--limit", type=int, default=None, help="Per-source row cap")
    p.add_argument("--pre-cap-mult", type=int, default=1, help="Cap multiplier vs DEFAULT_CAPS")
    return p.parse_args()


if __name__ == "__main__":
    sys.exit(main())
