# Data

How Promptward's training corpus is built — sources, caps, licenses, and the
rules that keep evaluation honest.

This document is authoritative. If a source is added or removed in code, this
file gets updated in the same commit.

## Philosophy

1. **Real adversarial signal beats synthetic at any scale.** A thousand
   real human-crafted attacks teach the model more than a million
   templated ones.
2. **Held-out benchmarks stay held out.** Five benchmarks (see below) are
   never used for training. `training.builder.build_corpus` dedupes against
   them automatically.
3. **Diverse benigns matter as much as diverse attacks.** Without realistic
   benign prompts (creative writing, instructions, dialogue), the model
   learns shortcut features and over-flags legitimate roleplay.

## Corpus composition

Numbers are pre-cap from each source; post-dedupe contributions vary.

### Attack-positive sources

| Source | Pool size | Cap | Type | License |
|---|---|---|---|---|
| **hlyn_judge** | 400k | 80k | Curated mix from 12 upstream sources; the strongest single attack signal | Public |
| **tensor_trust** | 12k unique successful + 1.3k curated | 30k | Real human CTF attacks (Berkeley) | Berkeley research; commercial use cleared |
| **neuralchemy_threat** | 32k | 25k | Intent-typed attacks (6 types) | CC BY-NC 4.0 |
| **neuralchemy_core** | 6k | 6k | Categorized + hard-negative benigns | CC BY-NC 4.0 |
| **guychuk** | 464k | 25k | Professional-framing rich | Public on HF |
| **necent** | 1.18M | 15k | Multi-source aggregator | MIT aggregation; sources retain own |
| **bogdanminko** | 857k | 8k | Jailbreak / injection / benign | Public on HF |
| **S-Labs** | 15k | 12k | Security-lab curated | Public on HF |
| **xTRam1** | 10k | 10k | Clean labels | Public on HF |
| **imoxto_v2** | 535k | 12k | HackaPrompt cleaned | CC BY 4.0 |
| **hackaprompt** | 227k | 8k | HackaPrompt 2023 competition | CC BY 4.0 |
| **mosscap** | 279k attack-only | 6k | Lakera extraction game | Public on HF |
| **deepset** | 662 | 1k | Original DeBERTa training set | MIT |
| **jailbreak_classification** | 1.3k | 1.5k | DAN-style jailbreaks | Apache-2.0 |

### Benign-only sources

| Source | Pool size | Cap | Type | License |
|---|---|---|---|---|
| **hh_rlhf** | 161k | 30k | Real user dialogues, helpful subset | MIT |
| **alpaca** | 52k | 15k | Instruction-following | CC BY-NC 4.0 |
| **dolly** | 15k | 15k | Q&A and instruction tuning | CC BY-SA 3.0 |

### Synthesized sources

| Source | Generation | Cap | Notes |
|---|---|---|---|
| **indirect_injection** | `training/data/synthesize.py` + Wikipedia | 30k | Attacks embedded inside Wikipedia paragraphs at random positions |
| **llm_attacks** | `training/data/llm_augment.py` | 60k | LLM-generated across 12 OWASP LLM01 / MITRE ATLAS categories. Cached locally; not redistributed. |

## Held-out eval benchmarks

Never train on these. `training.builder.build_corpus` dedupes against the
external sets automatically; the training-source test splits are excluded
via `HOLDOUT_TEST_SPLIT=True` in `training/data/loaders.py`.

### External (never seen anywhere in training)

| Benchmark | n | Purpose |
|---|---|---|
| `rogue-security/prompt-injections-benchmark` | 5,000 | Long, narrative-wrapped attacks |
| `JailbreakBench/JBB-Behaviors` | 200 | Harmful-behavior elicitation |

### Training-source test splits (excluded from training)

| Benchmark | n |
|---|---|
| `xTRam1/safe-guard-prompt-injection` test split | 2,060 |
| `S-Labs/prompt-injection-dataset` test split | 2,101 |
| `deepset/prompt-injections` test split | 116 |

### Running the suite

```bash
python -m eval.benchmark_suite                                      # heuristics-only
python -m eval.benchmark_suite --runner local:/path/to/model
python -m eval.benchmark_suite --runner local:/path/to/model \
    --runner protectai/deberta-v3-base-prompt-injection-v2
```

## License audit

The SDK code is **AGPL-3.0-or-later** from v1.0.1 onward (v1.0.0 was
Apache-2.0; that release is grandfathered). A commercial license is
available for users who can't comply with AGPL — see the README for
contact. The trained model weights distributed via Hugging Face Hub
are built from a mixed-license corpus, summarized below.

### Permissive (commercial use clear)

- `Anthropic/hh-rlhf` — MIT
- `deepset/prompt-injections` — MIT
- `imoxto/prompt_injection_*` — CC BY 4.0 (HackaPrompt)
- `jackhhao/jailbreak-classification` — Apache-2.0
- `databricks/databricks-dolly-15k` — CC BY-SA 3.0
- `HumanCompatibleAI/tensor-trust-data` — Berkeley research, commercial use cleared

### Non-commercial source data (model weights downstream are typically fine)

- `tatsu-lab/alpaca` — CC BY-NC 4.0
- `neuralchemy/Prompt-injection-dataset` — CC BY-NC 4.0
- `neuralchemy/prompt-injection-Threat-Matrix` — CC BY-NC 4.0

**Implication**: CC BY-NC restricts redistribution of the *dataset*; the
standard reading is that trained model weights produced from such data are
not themselves derivative works under the share-alike clause. We ship
weights only, never the corpus. This is the same approach used by most
HuggingFace model releases.

### Unspecified license (public on HF)

- `guychuk/benign-malicious-prompt-classification`
- `bogdanminko/Catch_the_prompt_injection_or_jailbreak_or_benign`
- `S-Labs/prompt-injection-dataset`
- `xTRam1/safe-guard-prompt-injection`
- `Lakera/mosscap_prompt_injection`
- `hlyn-labs/prompt-injection-judge-deberta-dataset`

Public on HuggingFace without an explicit license. Standard interpretation
is research and training use is acceptable; redistribution of the raw data
is not.

### How we handle the complexity

1. **We ship model weights, not the training corpus.** The corpus is
   reconstructable by anyone who runs the training pipeline.
2. **Each dataset loads from its canonical source** at training time. The
   user running training accepts each dataset's terms by doing so.
3. **Full attributions** live in [ATTRIBUTIONS.md](ATTRIBUTIONS.md).
4. **The SDK and heuristics layer are dataset-independent** — they work
   with any model, including ones trained on different data.

## Expected corpus stats

After load, synthesis, dedupe vs held-out benchmarks, and stratified split:

- Train: ~250k samples
- Val: ~12k samples
- Attack / benign: target close to 50/50
- 18 sources contributing
- Held-out benchmark dedupe: aggressive

## Adding a new source

1. Write a loader in `training/data/loaders.py` returning `LoadedDataset`.
2. Add to `LABELED_LOADERS`. Position by purpose (benigns first, real
   attacks middle, synthetic last) — affects which source claims a
   sample when there's a dedupe collision.
3. Add a cap to `DEFAULT_CAPS` in `training/builder.py`.
4. Update this file: source, size, type, license.
5. Update [ATTRIBUTIONS.md](ATTRIBUTIONS.md) with citation.
6. Verify it loads:
   ```bash
   python -c "from training.data.loaders import load_X; print(len(load_X(limit=200).texts))"
   ```

## Running training

End-to-end pipeline lives in `notebooks/train.ipynb` (Colab L4 / High-RAM).

For local corpus inspection without training:

```python
from training.data.loaders import load_all
from training.builder import build_corpus, DEFAULT_CAPS

loaded = load_all(skip_failed=True, pre_caps={k: v*3 for k, v in DEFAULT_CAPS.items()})
corpus = build_corpus(loaded, caps_per_source=DEFAULT_CAPS)
print(corpus.stats)
```
