# Attributions

Promptward's binary classifier is trained on a curated mix of publicly
available prompt-injection and jailbreak datasets. We're grateful to the
maintainers of each — without these resources this project wouldn't exist.

This file is the authoritative attribution list for the trained model
weights distributed via Hugging Face Hub. The SDK code (this repository,
from v1.0.1 onward) is AGPL-3.0-or-later; v1.0.0 was released under
Apache-2.0 and remains so for that release.

## Training data sources

| Source | Citation / Maintainer | License |
|---|---|---|
| `hlyn-labs/prompt-injection-judge-deberta-dataset` | hlyn-labs | Public |
| `HumanCompatibleAI/tensor-trust-data` | Toyer, Watkins, et al. (2023). *Tensor Trust: Interpretable Prompt Injection Attacks from an Online Game.* ICLR 2024. | Berkeley research; commercial use cleared |
| `neuralchemy/Prompt-injection-dataset` | neuralchemy | CC BY-NC 4.0 (model weights only) |
| `neuralchemy/prompt-injection-Threat-Matrix` | neuralchemy | CC BY-NC 4.0 (model weights only) |
| `guychuk/benign-malicious-prompt-classification` | guychuk | Public on HF |
| `Necent/llm-jailbreak-prompt-injection-dataset` | Necent (aggregator) | MIT for aggregation; source licenses retained |
| `Anthropic/hh-rlhf` | Bai, Jones, et al. (2022). *Training a Helpful and Harmless Assistant with Reinforcement Learning from Human Feedback.* | MIT |
| `tatsu-lab/alpaca` | Taori, Gulrajani, et al. (2023). *Alpaca: A Strong, Replicable Instruction-Following Model.* | CC BY-NC 4.0 (model weights only) |
| `databricks/databricks-dolly-15k` | Databricks | CC BY-SA 3.0 |
| `xTRam1/safe-guard-prompt-injection` | xTRam1 | Public on HF |
| `S-Labs/prompt-injection-dataset` | S-Labs | Public on HF |
| `bogdanminko/Catch_the_prompt_injection_or_jailbreak_or_benign` | bogdanminko | Public on HF |
| `imoxto/prompt_injection_cleaned_dataset-v2` | imoxto (HackaPrompt mirror) | CC BY 4.0 (HackaPrompt) |
| `imoxto/prompt_injection_hackaprompt_gpt35` | imoxto (HackaPrompt mirror) | CC BY 4.0 (HackaPrompt) |
| `Lakera/mosscap_prompt_injection` | Lakera | Public on HF |
| `deepset/prompt-injections` | deepset | MIT |
| `jackhhao/jailbreak-classification` | jackhhao | Apache-2.0 |

## Synthesized data

| Source | Generation | Notes |
|---|---|---|
| `indirect_injection` | Wikipedia paragraphs (`wikimedia/wikipedia`, CC BY-SA 4.0) + attacks from sources above embedded at random positions | Programmatic synthesis |
| `llm_attacks` | LLM-generated across 12 OWASP LLM01 / MITRE ATLAS categories | Generated locally per user; not redistributed |

## Held-out evaluation benchmarks

These are used for evaluation only. The training pipeline dedupes against
each before fitting any model.

- `rogue-security/prompt-injections-benchmark`
- `JailbreakBench/JBB-Behaviors` (Chao, Robey, et al., 2024)
- Test splits of `xTRam1/safe-guard-prompt-injection`, `S-Labs/prompt-injection-dataset`, `deepset/prompt-injections` (excluded from training via the `HOLDOUT_TEST_SPLIT` flag)

## How we handle license complexity

1. We ship trained model weights, **never the training corpus**. CC BY-NC
   restrictions apply to redistribution of the underlying datasets, not to
   the model weights produced from them (standard interpretation; not legal
   advice).
2. SDK code in this repository contains no third-party data.
3. Each dataset is loaded directly from its canonical source at training
   time. The user running training is responsible for accepting each
   dataset's terms.
4. If you maintain one of the listed sources and would like the
   attribution updated, please open an issue.

## Citations to include if you reuse trained weights

If you fine-tune or build on top of the Promptward weights, please also
cite the upstream sources whose data shaped the model:

- Toyer et al., *Tensor Trust* (2023) — adversarial prompt corpus
- Bai et al., *Anthropic HH-RLHF* (2022) — benign dialogue corpus
- Taori et al., *Alpaca* (2023) — instruction-following corpus
- Schulhoff et al., *HackaPrompt* (2023) — competition prompts
