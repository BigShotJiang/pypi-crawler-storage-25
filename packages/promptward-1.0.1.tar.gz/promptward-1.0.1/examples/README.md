# Examples

End-to-end usage samples that import `promptward` the same way a user would,
no local install or `[dev]` extras required.

| File | What it shows |
|---|---|
| `demo.py` | Five common patterns: basic protect(), chatbot guard, RAG / indirect-injection detection, batch processing, throughput benchmark — plus an honest look at v1.0 limitations. |

## Running

```bash
pip install promptward
python examples/demo.py
```

The first run downloads the model from the HF Hub (~30 s, cached for
subsequent runs).

## Reference output

A typical run on a consumer CPU produces ~5.5 ms p50 inference latency,
~176 prompts/sec sustained throughput, and the chatbot/RAG scenarios
block the obvious attacks while letting benign prompts through.
