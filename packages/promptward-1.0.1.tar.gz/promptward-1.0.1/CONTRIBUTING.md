# Contributing to Promptward

Thanks for considering a contribution. Promptward aims to be the strongest
local prompt-injection guard, so we hold a high bar for accuracy and a low
one for friction.

## Setup

```bash
git clone https://github.com/promptward/promptward.git
cd promptward
python3.12 -m venv .venv
.venv/bin/pip install -e ".[dev,eval]"
.venv/bin/pytest
```

## Running things locally

```bash
# Tests
pytest

# Lint
ruff check .
ruff format .

# Heuristic audit on rogue benchmark
python -m eval.audit_heuristics --dataset rogue

# Full multi-benchmark suite
python -m eval.benchmark_suite --runner promptward-fast

# Compare against a specific baseline
python -m eval.benchmark_suite \
    --runner promptward-fast \
    --runner protectai/deberta-v3-base-prompt-injection-v2
```

## What we accept

- **Heuristic rules** with a precision estimate based on a real eval run on
  the rogue benchmark. Rules without precision data won't be merged.
- **Eval improvements**: new held-out benchmarks, better metrics, latency
  profiling, multilingual coverage.
- **Training improvements**: dataset additions, loss-function variants,
  augmentation strategies. Show numbers.
- **Infra**: type fixes, docstrings, packaging, tests.

## What we don't accept

- Adding heuristic rules without measuring precision impact. We optimize
  for low FPR; broad rules are anti-features.
- Training on the held-out benchmark — even indirectly via near-duplicates.
  `training/builder.py` dedupes against it; don't bypass that.
- Vibes-based PRs. Show me numbers.

## Filing issues

For false positives or missed attacks, please include the exact prompt and
the version (`promptward.__version__`). Sensitive prompts can be redacted as
long as the structure is preserved.
