## What

<!-- One or two sentences. -->

## Why

<!-- Reason / motivation. Skip if obvious. -->

## Numbers

<!-- For changes that touch heuristics, models, or eval:
     - Before / after: AUC, F1, FPR@TPR=0.99 on the rogue benchmark.
     - p50 latency if relevant.
     For other changes (refactor, docs, packaging): write "n/a". -->

## Checklist

- [ ] `pytest` passes locally
- [ ] `ruff check .` is clean
- [ ] If touching heuristics: `python -m eval.audit_heuristics --dataset rogue` was run
- [ ] If touching detection: benchmark numbers are in the description above
- [ ] Updated CHANGELOG.md if user-visible
