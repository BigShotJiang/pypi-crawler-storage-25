"""Training losses used across stages.

- RDropLoss: KL regularization between two forward passes with dropout, from
  "R-Drop: Regularized Dropout for Neural Networks" (Liang et al., 2021).
  Forces the model to be consistent under dropout perturbation. Cheap, no
  extra params, reliably improves calibration.

- SupConLoss: supervised contrastive loss (Khosla et al., 2020) on CLS
  embeddings. Pulls together same-class samples, pushes apart cross-class.
  Improves separation in the feature space.

- DistillationLoss: KL divergence between student and (averaged) teacher
  softmax outputs, with temperature smoothing.
"""

from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import Tensor, nn


class RDropLoss(nn.Module):
    def __init__(self, alpha: float = 1.0) -> None:
        super().__init__()
        self.alpha = alpha

    def forward(self, logits1: Tensor, logits2: Tensor, labels: Tensor) -> Tensor:
        ce = 0.5 * (F.cross_entropy(logits1, labels) + F.cross_entropy(logits2, labels))
        p = F.log_softmax(logits1, dim=-1)
        q = F.log_softmax(logits2, dim=-1)
        kl_pq = F.kl_div(p, q, reduction="batchmean", log_target=True)
        kl_qp = F.kl_div(q, p, reduction="batchmean", log_target=True)
        return ce + self.alpha * 0.5 * (kl_pq + kl_qp)


class SupConLoss(nn.Module):
    """Supervised contrastive loss on L2-normalized embeddings."""

    def __init__(self, temperature: float = 0.07) -> None:
        super().__init__()
        self.temperature = temperature

    def forward(self, embeddings: Tensor, labels: Tensor) -> Tensor:
        device = embeddings.device
        embeddings = F.normalize(embeddings, dim=-1)
        sim = embeddings @ embeddings.T / self.temperature

        # Mask self-contrast. We use a large negative number rather than
        # -inf because (-inf * 0) produces NaN later when we mask-multiply.
        n = embeddings.shape[0]
        self_mask = torch.eye(n, dtype=torch.bool, device=device)
        neg_inf_proxy = torch.finfo(sim.dtype).min / 2  # ~-1.7e38, safe under ops
        sim = sim.masked_fill(self_mask, neg_inf_proxy)

        labels = labels.view(-1, 1)
        positive_mask = (labels == labels.T) & ~self_mask

        log_prob = sim - torch.logsumexp(sim, dim=1, keepdim=True)
        # Sum only over positive anchors to avoid `mask=0 * log_prob=-large = nan`.
        masked_log_prob = torch.where(positive_mask, log_prob, torch.zeros_like(log_prob))

        positives_per_row = positive_mask.sum(dim=1)
        valid = positives_per_row > 0
        if not valid.any():
            return torch.tensor(0.0, device=device, requires_grad=True)
        mean_log_prob_pos = masked_log_prob.sum(dim=1)[valid] / positives_per_row[valid].clamp(
            min=1
        )
        return -mean_log_prob_pos.mean()


class DistillationLoss(nn.Module):
    """KL between student log-softmax and teacher softmax, with temperature."""

    def __init__(self, temperature: float = 4.0, ce_weight: float = 0.7) -> None:
        super().__init__()
        self.temperature = temperature
        self.ce_weight = ce_weight

    def forward(
        self,
        student_logits: Tensor,
        teacher_logits: Tensor,
        labels: Tensor | None = None,
    ) -> Tensor:
        T = self.temperature
        s = F.log_softmax(student_logits / T, dim=-1)
        t = F.softmax(teacher_logits / T, dim=-1)
        kl = F.kl_div(s, t, reduction="batchmean") * (T * T)
        if labels is None or self.ce_weight == 0:
            return kl
        ce = F.cross_entropy(student_logits, labels)
        return self.ce_weight * ce + (1.0 - self.ce_weight) * kl
