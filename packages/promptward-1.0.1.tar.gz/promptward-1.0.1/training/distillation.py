"""Stage 2 distillation: collator, trainer, balanced corpus builder.

Three things to get right or distillation actively hurts:

  * Tokenizer mismatch destroys signal. Teachers must score with the
    student's tokenizer + truncation, otherwise teacher saw different
    content than the student does at training time.
  * Class skew in the unlabeled corpus makes the student over-flag.
    Build a 50/50 corpus by teacher prediction, not raw class distribution.
  * T=4 amplifies KL by 16x (T^2). At ce_weight=0.7 the KL term dominates
    cross-entropy and overrides Stage 1's careful boundary. Default is
    T=2, ce_weight=0.85.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

import torch
import torch.nn.functional as F
from torch import Tensor

from training.losses import DistillationLoss

logger = logging.getLogger(__name__)


@dataclass
class TeacherSpec:
    model_id: str
    attack_label_id: int = 1
    local_files_only: bool = False


def score_with_student_tokenizer(
    spec: TeacherSpec,
    texts: list[str],
    student_tokenizer,
    max_length: int = 256,
    batch_size: int = 16,
    device: str = "cuda",
) -> Tensor:
    """Run a teacher on `texts` but with the student's tokenizer.

    The teacher's logits will reflect the same tokenization the student
    sees at training time — without this, distillation actively hurts.
    """
    from transformers import AutoModelForSequenceClassification

    model = (
        AutoModelForSequenceClassification.from_pretrained(
            spec.model_id,
            local_files_only=spec.local_files_only,
        )
        .to(device)
        .eval()
    )
    if model.config.pad_token_id is None and student_tokenizer.pad_token_id is not None:
        model.config.pad_token_id = student_tokenizer.pad_token_id

    all_logits: list[Tensor] = []
    with torch.no_grad():
        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            enc = student_tokenizer(
                batch,
                truncation=True,
                max_length=max_length,
                padding=True,
                return_tensors="pt",
            ).to(device)
            logits = model(**enc).logits.cpu()
            # Re-order columns so attack is always at index 1, regardless of
            # what the teacher's label2id says.
            if spec.attack_label_id == 0:
                logits = logits[:, [1, 0]]
            all_logits.append(logits)

    del model
    torch.cuda.empty_cache()
    return torch.cat(all_logits, dim=0)


def build_balanced_unlabeled_corpus(
    pool: list[str],
    teacher_logits: Tensor,
    target_size: int,
    seed: int = 42,
) -> tuple[list[str], Tensor]:
    """Sample a 50/50 attack/benign corpus by teacher's predicted class.

    `pool` and `teacher_logits` are aligned. We split by argmax,
    shuffle each side, and take half of `target_size` from each.

    Returns (texts, logits) of length up to `target_size`.
    """
    import random

    preds = teacher_logits.argmax(dim=-1).tolist()
    attack_idx = [i for i, p in enumerate(preds) if p == 1]
    benign_idx = [i for i, p in enumerate(preds) if p == 0]

    rng = random.Random(seed)
    rng.shuffle(attack_idx)
    rng.shuffle(benign_idx)

    half = target_size // 2
    take_attack = attack_idx[:half]
    take_benign = benign_idx[:half]
    keep = sorted(take_attack + take_benign)

    texts = [pool[i] for i in keep]
    logits = teacher_logits[keep]

    logger.info(
        "balanced corpus: %d total (attack=%d, benign=%d) from pool of %d",
        len(texts),
        len(take_attack),
        len(take_benign),
        len(pool),
    )
    return texts, logits


class DistillCollator:
    """Standard padding + preserves teacher_logits.

    HuggingFace's DataCollatorWithPadding only knows tokenizer fields and
    silently drops `teacher_logits`. We pull it aside, run the base
    collator, then stack it back on.
    """

    def __init__(self, tokenizer):
        from transformers import DataCollatorWithPadding

        self.base = DataCollatorWithPadding(tokenizer=tokenizer)

    def __call__(self, features):
        teacher = [f.pop("teacher_logits", None) for f in features]
        batch = self.base(features)
        if any(t is not None for t in teacher):
            batch["teacher_logits"] = torch.stack([t for t in teacher if t is not None])
        return batch


def make_distill_trainer(
    *,
    student,
    train_dataset,
    eval_dataset,
    tokenizer,
    output_dir: str,
    epochs: int = 2,
    lr: float = 2e-5,
    train_batch_size: int = 32,
    eval_batch_size: int = 64,
    temperature: float = 2.0,
    ce_weight: float = 0.85,
    seed: int = 42,
    compute_metrics=None,
):
    """Construct a Trainer that distills from teacher_logits in each batch.

    Validation falls back to plain CE because val_ds has no teacher_logits.
    """
    from transformers import Trainer, TrainingArguments

    loss_fn = DistillationLoss(temperature=temperature, ce_weight=ce_weight)

    class DistillTrainer(Trainer):
        def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
            teacher_logits = inputs.pop("teacher_logits", None)
            labels = inputs.pop("labels")
            out = model(**inputs)
            if teacher_logits is None:
                # Eval pass — no teachers there; just plain CE.
                loss = F.cross_entropy(out.logits, labels)
            else:
                teacher_logits = teacher_logits.to(model.device)
                loss = loss_fn(out.logits, teacher_logits, labels=labels)
            if return_outputs:
                return loss, out
            return loss

    args = TrainingArguments(
        output_dir=output_dir,
        learning_rate=lr,
        per_device_train_batch_size=train_batch_size,
        per_device_eval_batch_size=eval_batch_size,
        num_train_epochs=epochs,
        weight_decay=0.01,
        warmup_ratio=0.05,
        eval_strategy="epoch",
        save_strategy="epoch",
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="f1",
        greater_is_better=True,
        logging_steps=100,
        fp16=True,
        report_to="none",
        seed=seed,
        remove_unused_columns=False,  # keep teacher_logits in the batch
    )

    return DistillTrainer(
        model=student,
        args=args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        data_collator=DistillCollator(tokenizer),
        compute_metrics=compute_metrics,
    )
