"""Dataset loaders — one function per HF dataset.

Each loader returns a `LoadedDataset` with text/label/source aligned. Loaders
accept an optional `limit` so we can cap rows at load time and avoid
materializing full datasets in RAM (some are 1M+ rows). Capping happens
*before* dedupe in `builder.build_corpus`, so always pass a generous
multiplier of the final cap (`load_all(pre_caps=...)` handles this).
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from dataclasses import dataclass

from training.data.normalize import find_label, find_text, normalize_binary_label

logger = logging.getLogger(__name__)


@dataclass
class LoadedDataset:
    name: str
    texts: list[str]
    labels: list[int]

    @property
    def n_attack(self) -> int:
        return sum(1 for label in self.labels if label == 1)

    @property
    def n_benign(self) -> int:
        return sum(1 for label in self.labels if label == 0)


def _iter_dataset(
    repo_id: str,
    limit: int | None = None,
    exclude_splits: tuple[str, ...] = (),
) -> Iterator[dict]:
    """Yield rows from all splits of a HF dataset, optionally capped.

    `exclude_splits` skips the named splits entirely — used to hold the
    `test` split out of training so it can serve as a clean eval set.
    """
    from datasets import load_dataset

    try:
        ds = load_dataset(repo_id, streaming=True)
        yielded = 0
        for split_name in ds:
            if split_name in exclude_splits:
                continue
            for row in ds[split_name]:
                yield row
                yielded += 1
                if limit and yielded >= limit:
                    return
        return
    except Exception as exc:
        logger.info("streaming failed for %s (%s); falling back to eager load", repo_id, exc)

    ds = load_dataset(repo_id)
    yielded = 0
    for split_name in ds:
        if split_name in exclude_splits:
            continue
        split = ds[split_name]
        for row in split:
            yield row
            yielded += 1
            if limit and yielded >= limit:
                return


def _harvest(rows: Iterator[dict], source: str) -> LoadedDataset:
    texts: list[str] = []
    labels: list[int] = []
    skipped = 0
    for row in rows:
        text = find_text(row)
        if not text:
            skipped += 1
            continue
        try:
            label = normalize_binary_label(find_label(row))
        except (ValueError, TypeError):
            skipped += 1
            continue
        texts.append(text)
        labels.append(label)
    if skipped:
        logger.info("%s: skipped %d rows with missing/unparseable fields", source, skipped)
    return LoadedDataset(name=source, texts=texts, labels=labels)


# Sources whose `test` split we hold out for cross-benchmark evaluation.
# When called via `load_all`, we exclude the test split from training so it
# remains a clean held-out eval set in `eval.data`. Don't flip this off —
# the held-out splits are the contract we make with anyone evaluating us.
HOLDOUT_TEST_SPLIT: bool = True


def _holdout() -> tuple[str, ...]:
    return ("test", "validation") if HOLDOUT_TEST_SPLIT else ()


def load_xtram1(limit: int | None = None) -> LoadedDataset:
    return _harvest(
        _iter_dataset("xTRam1/safe-guard-prompt-injection", limit, exclude_splits=_holdout()),
        source="xTRam1",
    )


def load_deepset(limit: int | None = None) -> LoadedDataset:
    return _harvest(
        _iter_dataset("deepset/prompt-injections", limit, exclude_splits=_holdout()),
        source="deepset",
    )


def load_slabs(limit: int | None = None) -> LoadedDataset:
    return _harvest(
        _iter_dataset("S-Labs/prompt-injection-dataset", limit, exclude_splits=_holdout()),
        source="S-Labs",
    )


def load_hlyn_judge(limit: int | None = None) -> LoadedDataset:
    """hlyn-labs/prompt-injection-judge-deberta-dataset — 400k samples.

    The actual training data behind hlyn's DeBERTa-70m model (which scores
    0.98 AUC on rogue). Public, not gated. Balanced (51% benign / 49% attack).

    Simple binary classification with `text` and `label` fields. By far the
    largest single labeled source available to us; adding this typically
    closes most of the rogue distribution gap our other sources couldn't.

    NOTE: the builder dedupes against the held-out rogue benchmark
    automatically, so any direct overlap is excluded from training.
    """
    return _harvest(
        _iter_dataset("hlyn-labs/prompt-injection-judge-deberta-dataset", limit),
        source="hlyn_judge",
    )


def load_imoxto_v2(limit: int | None = None) -> LoadedDataset:
    return _harvest(
        _iter_dataset("imoxto/prompt_injection_cleaned_dataset-v2", limit), source="imoxto_v2"
    )


def load_imoxto_v1(limit: int | None = None) -> LoadedDataset:
    """HackaPrompt competition data. Every row is an attack attempt; we use
    the `user_input` field (the injection itself) and label all as attack.
    """
    texts: list[str] = []
    labels: list[int] = []
    for row in _iter_dataset("imoxto/prompt_injection_cleaned_dataset", limit):
        text = row.get("user_input")
        if not text or not isinstance(text, str) or not text.strip():
            continue
        texts.append(text)
        labels.append(1)
    return LoadedDataset(name="imoxto_v1", texts=texts, labels=labels)


def load_hackaprompt(limit: int | None = None) -> LoadedDataset:
    return _harvest(
        _iter_dataset("imoxto/prompt_injection_hackaprompt_gpt35", limit), source="hackaprompt"
    )


def load_mosscap(limit: int | None = None) -> LoadedDataset:
    """Lakera Mosscap prompt-injection dataset.

    All rows are attack attempts (extraction prompts), so we label everything
    as attack=1.
    """
    texts: list[str] = []
    labels: list[int] = []
    for row in _iter_dataset("Lakera/mosscap_prompt_injection", limit):
        text = find_text(row) or row.get("prompt")
        if not text:
            continue
        texts.append(text)
        labels.append(1)
    return LoadedDataset(name="mosscap", texts=texts, labels=labels)


def load_necent_jailbreak(limit: int | None = None) -> LoadedDataset:
    """Necent aggregator with orthogonal multi-label schema. We project the
    `prompt_adversarial` flag down to binary attack/benign.

    Gated; requires manual approval. Will warn-and-skip until then.
    """
    texts: list[str] = []
    labels: list[int] = []
    for row in _iter_dataset("Necent/llm-jailbreak-prompt-injection-dataset", limit):
        text = row.get("prompt")
        if not text or not isinstance(text, str) or not text.strip():
            continue
        adv = row.get("prompt_adversarial")
        if adv is None:
            continue
        texts.append(text)
        labels.append(int(adv))
    return LoadedDataset(name="necent", texts=texts, labels=labels)


def load_jailbreak_classification(limit: int | None = None) -> LoadedDataset:
    """jackhhao/jailbreak-classification — public, hand-curated DAN-style
    jailbreaks vs benign roleplay. Small (~1.3k) but covers a class
    underrepresented in the larger synthetic sources.
    """
    texts: list[str] = []
    labels: list[int] = []
    for row in _iter_dataset("jackhhao/jailbreak-classification", limit):
        text = row.get("prompt")
        if not text or not isinstance(text, str) or not text.strip():
            continue
        type_value = (row.get("type") or "").strip().lower()
        if type_value in {"benign", "safe"}:
            label = 0
        elif type_value:
            label = 1
        else:
            continue
        texts.append(text)
        labels.append(label)
    return LoadedDataset(name="jailbreak_classification", texts=texts, labels=labels)


def load_geekyrakshit(limit: int | None = None) -> LoadedDataset:
    return _harvest(
        _iter_dataset("geekyrakshit/prompt-injection-dataset", limit), source="geekyrakshit"
    )


def load_bogdanminko(limit: int | None = None) -> LoadedDataset:
    """3-class dataset with columns `prompt` and `type`. `type` values:
    'benign', 'jailbreak', 'prompt_injection'. Collapsed to binary by
    treating both attack types as positive.
    """
    texts: list[str] = []
    labels: list[int] = []
    for row in _iter_dataset(
        "bogdanminko/Catch_the_prompt_injection_or_jailbreak_or_benign", limit
    ):
        text = row.get("prompt")
        if not text or not isinstance(text, str) or not text.strip():
            continue
        type_value = (row.get("type") or "").strip().lower()
        if type_value in {"benign", "safe"}:
            label = 0
        elif type_value:
            label = 1
        else:
            continue
        texts.append(text)
        labels.append(label)
    return LoadedDataset(name="bogdanminko", texts=texts, labels=labels)


def load_hh_rlhf_benign(limit: int | None = 30000) -> LoadedDataset:
    """Anthropic/hh-rlhf 'helpful-base' subset. Extracts the human turn from
    each `chosen` dialogue.

    These are real-world user prompts including extensive creative writing,
    roleplay, and "what if" framing — important for reducing false positives
    on benign fictional content.
    """
    import re

    from datasets import load_dataset

    ds = load_dataset("Anthropic/hh-rlhf", data_dir="helpful-base")
    rows = []
    for split_name in ds:
        rows.extend(list(ds[split_name]))

    texts: list[str] = []
    labels: list[int] = []
    # Pull the FIRST human turn out of each dialogue. Multi-turn dialogues
    # collapse to one user prompt; that's what we'd actually classify in
    # production.
    pattern = re.compile(r"\n\nHuman:\s*(.*?)(?=\n\nAssistant:|\Z)", re.DOTALL)
    for row in rows:
        chosen = row.get("chosen", "")
        if not chosen:
            continue
        match = pattern.search(chosen)
        if not match:
            continue
        text = match.group(1).strip()
        if not text or len(text) < 10:
            continue
        texts.append(text)
        labels.append(0)
        if limit and len(texts) >= limit:
            break
    return LoadedDataset(name="hh_rlhf", texts=texts, labels=labels)


def load_alpaca_benign(limit: int | None = 20000) -> LoadedDataset:
    """tatsu-lab/alpaca — 52k instruction-following examples. Pure benign
    instructions covering Q&A, summarization, classification, brainstorming.
    """
    texts: list[str] = []
    labels: list[int] = []
    for row in _iter_dataset("tatsu-lab/alpaca", limit):
        instruction = (row.get("instruction") or "").strip()
        if not instruction:
            continue
        input_text = (row.get("input") or "").strip()
        text = instruction + (("\n\n" + input_text) if input_text else "")
        texts.append(text)
        labels.append(0)
    return LoadedDataset(name="alpaca", texts=texts, labels=labels)


def load_neuralchemy_core(limit: int | None = None) -> LoadedDataset:
    """neuralchemy/Prompt-injection-dataset (core config).

    6.3k samples with attack categories including direct_injection,
    crescendo, indirect_injection, jailbreak, token_smuggling. Has
    explicit "hard_negative" benigns. Covers wrapped-attack patterns that
    simpler injection datasets miss.
    """
    from datasets import load_dataset

    ds = load_dataset("neuralchemy/Prompt-injection-dataset", "core")
    rows = []
    for split_name in ds:
        rows.extend(list(ds[split_name]))

    texts: list[str] = []
    labels: list[int] = []
    for row in rows:
        text = row.get("text")
        if not text or not isinstance(text, str) or not text.strip():
            continue
        try:
            label = int(row.get("label"))
        except (TypeError, ValueError):
            continue
        texts.append(text)
        labels.append(label)
        if limit and len(texts) >= limit:
            break
    return LoadedDataset(name="neuralchemy_core", texts=texts, labels=labels)


def load_neuralchemy_threat(limit: int | None = None) -> LoadedDataset:
    """neuralchemy/prompt-injection-Threat-Matrix (multiclass config).

    32k rows with intent labels (direct_injection, system_extraction,
    role_hijack, obfuscation, tool_abuse, indirect_injection, benign).
    We collapse to binary via the dataset's `binary_label` field.

    Has severity scores 1-10 — useful for future hard-negative mining.
    """
    from datasets import load_dataset

    ds = load_dataset("neuralchemy/prompt-injection-Threat-Matrix", "multiclass")
    rows = []
    for split_name in ds:
        rows.extend(list(ds[split_name]))

    texts: list[str] = []
    labels: list[int] = []
    for row in rows:
        text = row.get("text")
        if not text or not isinstance(text, str) or not text.strip():
            continue
        binary = row.get("binary_label")
        if binary is None:
            continue
        texts.append(text)
        labels.append(int(binary))
        if limit and len(texts) >= limit:
            break
    return LoadedDataset(name="neuralchemy_threat", texts=texts, labels=labels)


def load_guychuk(limit: int | None = None) -> LoadedDataset:
    """guychuk/benign-malicious-prompt-classification (464k rows).

    Massive binary set focused on injection-technique detection (not
    content harm). Schema: prompt + label.
    """
    texts: list[str] = []
    labels: list[int] = []
    for row in _iter_dataset("guychuk/benign-malicious-prompt-classification", limit):
        text = row.get("prompt")
        if not text or not isinstance(text, str) or not text.strip():
            continue
        try:
            label = int(row.get("label"))
        except (TypeError, ValueError):
            continue
        texts.append(text)
        labels.append(label)
    return LoadedDataset(name="guychuk", texts=texts, labels=labels)


_TT_GITHUB_BASE = "https://raw.githubusercontent.com/HumanCompatibleAI/tensor-trust-data/main"
_TT_HIJACK_URL = (
    f"{_TT_GITHUB_BASE}/benchmarks/hijacking-robustness/v1/hijacking_robustness_dataset.jsonl"
)
_TT_EXTRACT_URL = (
    f"{_TT_GITHUB_BASE}/benchmarks/extraction-robustness/v1/extraction_robustness_dataset.jsonl"
)
_TT_RAW_URL = f"{_TT_GITHUB_BASE}/raw-data/v2/raw_dump_attacks.jsonl.bz2"


def _tensor_trust_cache_dir() -> str:
    """Resolve a cache directory for Tensor Trust raw downloads.

    Honours $PROMPTWARD_CACHE if set; falls back to ~/.cache/promptward.
    Created on first call.
    """
    import os
    import pathlib

    base = os.environ.get("PROMPTWARD_CACHE")
    if not base:
        base = str(pathlib.Path.home() / ".cache" / "promptward")
    out = pathlib.Path(base) / "tensor-trust"
    out.mkdir(parents=True, exist_ok=True)
    return str(out)


def _download_if_missing(url: str, cache_dir: str, filename: str) -> str:
    """Download URL to cache_dir/filename if not already present. Returns path."""
    import os
    import urllib.request

    target = os.path.join(cache_dir, filename)
    if os.path.exists(target) and os.path.getsize(target) > 0:
        return target
    logger.info("downloading %s -> %s", url, target)
    urllib.request.urlretrieve(url, target)
    return target


def load_tensor_trust(
    limit: int | None = None,
    subset: str = "curated_plus_successful",
    cache_dir: str | None = None,
) -> LoadedDataset:
    """Tensor Trust attack corpus (Berkeley / HCAI).

    Real human-crafted prompt-injection attacks from an online CTF where
    players tried to extract passwords from defender chatbots. Two flavors:

    - Curated benchmarks (~1.3k high-quality samples across hijacking and
      extraction categories).
    - Raw dump (~563k attempts; we filter to ~234k unique non-self attacks,
      of which ~32k were successful — the LLM granted access).

    Subsets:
      "curated"             : ~1.3k from hijacking + extraction benchmarks
      "successful_only"     : ~32k unique successful non-self attacks
      "all_unique"          : ~234k unique non-self attacks (incl. failed)
      "curated_plus_successful" : default, ~33k highest-quality combined

    All entries label as attack=1 (Tensor Trust is an attack-only corpus).

    LICENSE NOTE: Tensor Trust is released by Berkeley (Toyer et al. 2023)
    without an explicit commercial-use license. Use is fine for research
    and pre-commercial training. Email the authors for commercial permission
    before shipping a paid product. Don't redistribute the raw data.

    Citation:
      @misc{toyer2023tensor,
        title={Tensor Trust: Interpretable Prompt Injection Attacks
               from an Online Game},
        author={Toyer, Sam et al.},
        year={2023},
      }
    """
    import bz2
    import json

    cache = cache_dir or _tensor_trust_cache_dir()
    texts: list[str] = []

    if subset in ("curated", "curated_plus_successful"):
        for url, name in [
            (_TT_HIJACK_URL, "hijacking_robustness.jsonl"),
            (_TT_EXTRACT_URL, "extraction_robustness.jsonl"),
        ]:
            path = _download_if_missing(url, cache, name)
            with open(path) as f:
                for line in f:
                    row = json.loads(line)
                    attack = row.get("attack")
                    if isinstance(attack, str) and attack.strip():
                        texts.append(attack)

    if subset in ("successful_only", "all_unique", "curated_plus_successful"):
        path = _download_if_missing(_TT_RAW_URL, cache, "raw_attacks.jsonl.bz2")
        # "curated_plus_successful" and "successful_only" both restrict to
        # attacks that actually granted access. "all_unique" keeps failed
        # attempts too.
        require_success = subset != "all_unique"
        seen: set[str] = set(texts)  # don't duplicate the curated benchmark texts
        with bz2.open(path, "rt", encoding="utf-8") as f:
            for line in f:
                row = json.loads(line)
                if row.get("is_self_attack"):
                    continue
                if require_success and not row.get("output_is_access_granted"):
                    continue
                attack = row.get("attacker_input")
                if not isinstance(attack, str):
                    continue
                attack = attack.strip()
                if not attack or attack in seen:
                    continue
                seen.add(attack)
                texts.append(attack)
                if limit and len(texts) >= limit:
                    break

    # Cap-after-collection only if a tighter limit is required than the
    # natural subset bounds. (For curated_plus_successful, the limit kicks
    # in mid-raw-iteration above.)
    if limit and len(texts) > limit:
        texts = texts[:limit]

    return LoadedDataset(
        name="tensor_trust",
        texts=texts,
        labels=[1] * len(texts),
    )


def load_dolly_benign(limit: int | None = 15000) -> LoadedDataset:
    """databricks/databricks-dolly-15k — entirely benign instruction tuning.

    Used to bolster the safe class with realistic non-attack prompts and as
    fodder for distillation in Stage 2.
    """
    texts: list[str] = []
    labels: list[int] = []
    for row in _iter_dataset("databricks/databricks-dolly-15k", limit):
        instruction = row.get("instruction", "") or ""
        context = row.get("context", "") or ""
        text = (instruction + ("\n\n" + context if context else "")).strip()
        if not text:
            continue
        texts.append(text)
        labels.append(0)
    return LoadedDataset(name="dolly", texts=texts, labels=labels)


def _lazy_load_llm_attacks(limit: int | None = None) -> LoadedDataset:
    """Lazy proxy to training.data.llm_augment.load_llm_attacks.

    Defers the import so the optional `openai` dependency is only required
    when you actually run generation. Returns empty if no cache.
    """
    from training.data.llm_augment import load_llm_attacks

    return load_llm_attacks(limit=limit)


# Loader registry. Order matters for downstream balancing / capping logic
# (sources earlier in the dict eat dedupe slots first).
#
# Convention: benign creative-writing first (so they survive dedupe against
# attack sources that share phrasing), then real attacks, then synthesized
# attacks last.
LABELED_LOADERS = {
    # Benign creative writing / instructions — populate `seen` first so
    # benign roleplay/fiction patterns aren't deduped away by attack sources
    # that share phrasing.
    "hh_rlhf": load_hh_rlhf_benign,
    "alpaca": load_alpaca_benign,
    # Categorized injection sources with wrapped-attack patterns
    # (crescendo, indirect_injection, role_hijack, etc.).
    "neuralchemy_core": load_neuralchemy_core,
    "neuralchemy_threat": load_neuralchemy_threat,
    "guychuk": load_guychuk,
    # Tensor Trust — real human-crafted attacks from a Berkeley CTF.
    # Largest single source of quality adversarial signal.
    "tensor_trust": load_tensor_trust,
    # LLM-augmented attacks. Loader returns empty until
    # `python -m training.data.llm_augment generate` has been run.
    "llm_attacks": _lazy_load_llm_attacks,
    # hlyn-labs DeBERTa training set — 400k binary samples, the broadest
    # single labeled source available.
    "hlyn_judge": load_hlyn_judge,
    # Curated attack sources
    "xTRam1": load_xtram1,
    "deepset": load_deepset,
    "S-Labs": load_slabs,
    "necent": load_necent_jailbreak,
    "jailbreak_classification": load_jailbreak_classification,
    "bogdanminko": load_bogdanminko,
    # Synthesized / specific-game attacks (lowest priority, deduped first)
    "imoxto_v2": load_imoxto_v2,
    "hackaprompt": load_hackaprompt,  # canonical HackaPrompt-2023 mirror
    "mosscap": load_mosscap,
}


def load_all(
    skip_failed: bool = True,
    only: list[str] | None = None,
    pre_caps: dict[str, int] | None = None,
) -> dict[str, LoadedDataset]:
    """Load every registered dataset. Returns dict source -> LoadedDataset.

    `pre_caps` caps each source at load time (before dedupe). Pass a multiple
    of the final per-source cap (typically 3x) so the dedupe step has room
    to drop near-duplicates without starving any source.
    """
    pre_caps = pre_caps or {}
    out: dict[str, LoadedDataset] = {}
    for source, fn in LABELED_LOADERS.items():
        if only and source not in only:
            continue
        try:
            out[source] = fn(limit=pre_caps.get(source))
            logger.info(
                "loaded %s: n=%d (attack=%d benign=%d)",
                source,
                len(out[source].texts),
                out[source].n_attack,
                out[source].n_benign,
            )
        except Exception as exc:
            if skip_failed:
                logger.warning("could not load %s: %s", source, exc)
            else:
                raise
    return out
