"""Quality review for LLM-generated attack samples.

Reads the cache directory written by `llm_augment.py`, runs cheap-but-useful
quality checks, and prints both aggregate stats and random samples for human
inspection.

The point: before you spend $20-100 generating 30k attacks, run this on a
small batch (e.g. 100 samples/category) to make sure the model isn't
refusing, going off-task, or producing slop. Detect issues cheaply.

Usage:
    # Review everything in the default cache
    python -m training.data.review_llm

    # One category, show more samples per category
    python -m training.data.review_llm --category refusal_bypass --samples 8

    # Inspect a specific cache dir (e.g. when reviewing a model variant)
    python -m training.data.review_llm --cache-dir .local-data/llm_attacks_sonnet/
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys
from pathlib import Path
from statistics import mean, median, stdev

from eval.dataset_audit import signature_percentages
from training.data.llm_augment import _DEFAULT_CACHE_DIR, _categories_by_name

logger = logging.getLogger(__name__)


# Detect outputs where the LLM refused or went off-task instead of
# producing an attack. We catch these BEFORE training so they don't poison
# the model.
_REFUSAL_PATTERNS = (
    re.compile(r"^\s*i\s*(can'?t|cannot|won'?t|am unable|do not feel)", re.IGNORECASE),
    re.compile(r"^\s*i'?m\s*(sorry|not able|unable)", re.IGNORECASE),
    re.compile(r"^\s*sorry,?\s*(i|but)", re.IGNORECASE),
    re.compile(r"^\s*(i must|i need to|i should|let me) decline", re.IGNORECASE),
    re.compile(r"^\s*as an ai (assistant|language model)", re.IGNORECASE),
    re.compile(r"^\s*here (are|is) (the|some|\d+) (samples|examples|attacks)", re.IGNORECASE),
    re.compile(r"^\s*sample \d+\b", re.IGNORECASE),  # model leaked formatting
)


def _is_refusal_or_meta(text: str) -> str | None:
    """Return a brief flag if `text` looks like a refusal/meta-leak, else None."""
    stripped = text.strip()
    if not stripped:
        return "empty"
    for pattern in _REFUSAL_PATTERNS:
        if pattern.search(stripped[:200]):
            return f"refusal/meta: {pattern.pattern[:40]}"
    return None


def _shingle_hash(text: str, k: int = 5) -> set[int]:
    """Cheap shingle set for near-duplicate detection. Words 0..k-1, 1..k, etc."""
    words = text.split()
    if len(words) < k:
        return {hash(text)}
    return {hash(" ".join(words[i : i + k])) for i in range(len(words) - k + 1)}


def _jaccard(a: set[int], b: set[int]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _length_stats(texts: list[str]) -> dict:
    if not texts:
        return {"n": 0}
    lens = [len(t) for t in texts]
    return {
        "n": len(texts),
        "min": min(lens),
        "max": max(lens),
        "mean": int(mean(lens)),
        "median": int(median(lens)),
        "std": int(stdev(lens)) if len(lens) > 1 else 0,
    }


def _detect_near_dup_clusters(texts: list[str], threshold: float = 0.7) -> int:
    """Greedy near-duplicate count.

    Returns the number of items that have at least one near-duplicate
    elsewhere in the list. O(n^2) — keep n small (<2000).
    """
    if len(texts) > 2000:
        # Sub-sample to keep it cheap
        import random

        rng = random.Random(42)
        sample = rng.sample(texts, 2000)
    else:
        sample = texts
    shingles = [_shingle_hash(t) for t in sample]
    dup_count = 0
    flagged = [False] * len(sample)
    for i in range(len(sample)):
        if flagged[i]:
            continue
        for j in range(i + 1, len(sample)):
            if flagged[j]:
                continue
            if _jaccard(shingles[i], shingles[j]) >= threshold:
                if not flagged[i]:
                    dup_count += 1
                    flagged[i] = True
                dup_count += 1
                flagged[j] = True
    return dup_count


def _review_category(
    name: str,
    texts: list[str],
    samples_to_show: int,
    max_sample_chars: int,
    rng_seed: int = 42,
) -> dict:
    """Print human-readable review for one category, return summary stats."""
    if not texts:
        print(f"\n### {name}")
        print("  (no samples in cache)")
        return {"name": name, "n": 0}

    # 1. Refusal / meta-leak rate. Store the text directly so we don't
    # need to dereference indices after shuffling below.
    flagged: list[tuple[str, str]] = []
    for t in texts:
        flag = _is_refusal_or_meta(t)
        if flag is not None:
            flagged.append((t, flag))

    # 2. Length stats
    ls = _length_stats(texts)

    # 3. Exact dedup
    unique = len(set(texts))

    # 4. Near-dup (cheap, sub-sampled)
    near_dups = _detect_near_dup_clusters(texts)

    # 5. Signature distribution — does it match the category's intended shape?
    sigs = signature_percentages(texts)
    sigs_sorted = sorted(sigs.items(), key=lambda kv: -kv[1])[:5]

    # 6. Random samples
    import random

    random.Random(rng_seed).shuffle(texts := list(texts))
    samples = texts[:samples_to_show]

    # Print
    print(f"\n### `{name}` — n={ls['n']}")
    print(f"  length: min={ls['min']}, median={ls['median']}, mean={ls['mean']}, max={ls['max']}")
    print(f"  unique: {unique}/{ls['n']} ({100 * unique / ls['n']:.1f}%)")
    print(f"  near-dup flagged (jaccard>=0.7): {near_dups}")
    print(f"  refusal/meta leaks: {len(flagged)}/{ls['n']} ({100 * len(flagged) / ls['n']:.1f}%)")
    if flagged[:3]:
        print("  examples of leaks:")
        for leak_text, flag in flagged[:3]:
            short = leak_text.replace("\n", " | ")[:120]
            print(f"    [{flag}] {short!r}")
    print(f"  top 5 signatures: {', '.join(f'{k}={v:.0f}%' for k, v in sigs_sorted)}")

    print(f"  --- {samples_to_show} random samples ---")
    for i, s in enumerate(samples):
        preview = s if len(s) <= max_sample_chars else s[: max_sample_chars - 3] + "..."
        preview = preview.replace("\n", "\n      ")
        print(f"  [{i + 1}] [{len(s)} chars]")
        print(f"      {preview}")

    return {
        "name": name,
        "n": ls["n"],
        "unique_pct": 100 * unique / ls["n"],
        "near_dups": near_dups,
        "refusal_pct": 100 * len(flagged) / ls["n"],
        "median_chars": ls["median"],
        "top_signature": sigs_sorted[0][0] if sigs_sorted else None,
    }


def _load_cache(cache_dir: Path) -> dict[str, list[str]]:
    """Return dict of category_name -> list of texts from .jsonl cache."""
    out: dict[str, list[str]] = {}
    if not cache_dir.exists():
        return out
    for f in sorted(cache_dir.glob("*.jsonl")):
        texts: list[str] = []
        with f.open() as fh:
            for line in fh:
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                text = row.get("text")
                if isinstance(text, str) and text.strip():
                    texts.append(text.strip())
        out[f.stem] = texts
    return out


def main() -> int:
    p = argparse.ArgumentParser(prog="review_llm")
    p.add_argument("--cache-dir", default=_DEFAULT_CACHE_DIR)
    p.add_argument(
        "--category",
        default=None,
        help="Review only one category. Default: all categories in cache.",
    )
    p.add_argument(
        "--samples",
        type=int,
        default=5,
        help="Random samples to show per category.",
    )
    p.add_argument(
        "--max-chars",
        type=int,
        default=600,
        help="Truncate each sample to this many chars for display.",
    )
    args = p.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    cache_dir = Path(args.cache_dir)
    by_category = _load_cache(cache_dir)
    if not by_category:
        print(f"No cache found at {cache_dir}. Generate first:")
        print("  python -m training.data.llm_augment generate --total 1000")
        return 1

    known_categories = set(_categories_by_name())
    if args.category:
        if args.category not in by_category:
            print(f"Category '{args.category}' not in cache. Available:")
            for k in sorted(by_category):
                print(f"  {k}")
            return 1
        targets = {args.category: by_category[args.category]}
    else:
        targets = dict(by_category)

    print(f"## LLM Attack Cache Review — {cache_dir}\n")
    print(f"Cached categories: {len(by_category)}")
    print(f"Total samples: {sum(len(v) for v in by_category.values())}")
    unknown = set(by_category) - known_categories
    if unknown:
        print(f"⚠ Unknown categories (not in taxonomy): {sorted(unknown)}")

    summaries = []
    for name, texts in targets.items():
        summaries.append(
            _review_category(
                name,
                texts,
                samples_to_show=args.samples,
                max_sample_chars=args.max_chars,
            )
        )

    # ===== Aggregate quality scorecard =====
    print("\n## Aggregate Scorecard\n")
    print(
        f"{'category':<24} {'n':>6} {'unique%':>8} {'near_dups':>10} {'refusal%':>9} "
        f"{'med chars':>10}"
    )
    print("-" * 70)
    for s in summaries:
        if s["n"] == 0:
            continue
        print(
            f"{s['name']:<24} {s['n']:>6} {s.get('unique_pct', 0):>8.1f} "
            f"{s.get('near_dups', 0):>10} {s.get('refusal_pct', 0):>9.1f} "
            f"{s.get('median_chars', 0):>10}"
        )

    # ===== Verdict =====
    issues: list[str] = []
    for s in summaries:
        if s["n"] == 0:
            continue
        if s.get("refusal_pct", 0) > 5:
            issues.append(
                f"{s['name']}: {s['refusal_pct']:.0f}% refusals — model is refusing the prompt or leaking meta"
            )
        if s.get("unique_pct", 100) < 90:
            issues.append(
                f"{s['name']}: {s['unique_pct']:.0f}% unique — significant exact duplicates"
            )
        if s.get("near_dups", 0) > s["n"] * 0.2:
            issues.append(
                f"{s['name']}: {s['near_dups']}/{s['n']} near-duplicates — templates may be too tight"
            )
        if s.get("median_chars", 0) < 50:
            issues.append(
                f"{s['name']}: median {s['median_chars']} chars — outputs may be truncated"
            )

    print("\n## Verdict\n")
    if not issues:
        print("✓ No quality flags. Safe to scale up generation.")
    else:
        print("⚠ Issues detected:")
        for issue in issues:
            print(f"  - {issue}")
        print(
            "\nReview the samples above to decide if these are real problems "
            "(adjust the generation prompt) or acceptable noise (proceed)."
        )

    return 0


if __name__ == "__main__":
    sys.exit(main())
