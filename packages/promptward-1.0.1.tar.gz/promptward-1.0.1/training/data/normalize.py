"""Shared text and label normalization for dataset loaders.

Lifted from `DeBERTa_prompt_injection_finetuning.ipynb` and consolidated so
loaders stay single-purpose.
"""

from __future__ import annotations

from typing import Any

TEXT_KEYS = ("text", "prompt", "input", "instruction", "content", "question")

ATTACK_VALUES = frozenset(
    {
        "1",
        "true",
        "yes",
        "attack",
        "attacked",
        "injection",
        "prompt_injection",
        "jailbreak",
        "malicious",
        "unsafe",
        "harmful",
    }
)

SAFE_VALUES = frozenset(
    {
        "0",
        "false",
        "no",
        "safe",
        "benign",
        "normal",
        "clean",
    }
)

LABEL_KEYS = ("label", "labels", "is_prompt_injection", "injection", "is_injection")


def find_text(row: dict[str, Any]) -> str | None:
    for key in TEXT_KEYS:
        value = row.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return None


def find_label(row: dict[str, Any]) -> Any:
    for key in LABEL_KEYS:
        if key in row and row[key] is not None:
            return row[key]
    return None


def normalize_binary_label(raw: Any) -> int:
    if isinstance(raw, bool):
        return 1 if raw else 0
    if isinstance(raw, (int, float)):
        return int(raw)
    if isinstance(raw, str):
        value = raw.strip().lower()
        if value in ATTACK_VALUES:
            return 1
        if value in SAFE_VALUES:
            return 0
    raise ValueError(f"Cannot normalize label: {raw!r}")
