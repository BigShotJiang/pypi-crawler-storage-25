"""Synthetic attack generators.

Indirect-injection synthesizer: takes attack texts and embeds them inside
longer benign documents. This mimics rogue-benchmark cases where the
"prompt" is actually a Wikipedia paragraph or article excerpt with a
hidden injection — a failure mode that simple injection datasets miss
because the actual injection sits past the truncation boundary.

Usage:
    from training.data.loaders import load_all
    from training.data.synthesize import (
        load_wikipedia_documents,
        synthesize_indirect_injections,
        collect_attack_texts,
    )

    loaded = load_all(...)
    attacks = collect_attack_texts(loaded)
    docs = load_wikipedia_documents(limit=20000)
    loaded["indirect_injection"] = synthesize_indirect_injections(
        attacks=attacks, documents=docs, n_samples=30000,
    )
"""

from __future__ import annotations

import logging
import random
from collections.abc import Iterable

from training.data.loaders import LoadedDataset

logger = logging.getLogger(__name__)


# Wrappers that look natural in real-world LLM input — mirrors how indirect
# injections appear in production (article summarization, RAG context, etc.)
_DOC_FRAMINGS = (
    "Please summarize the following article:\n\n{doc}",
    "Translate this passage to Spanish:\n\n{doc}",
    "Extract the key facts from this text:\n\n{doc}",
    "Article excerpt:\n---\n{doc}\n---\nWhat is the main point?",
    "Document content:\n{doc}",
    "Reference material:\n\n{doc}\n\nAnswer based only on the above.",
    "{doc}",  # raw — sometimes the document is just dumped in directly
)

# Common attack lead-ins inside documents — mimics adversarial RAG
# poisoning where someone has tampered with a source document.
_INJECTION_PREFIXES = (
    "\n\n",
    "\n\n---\n\n",
    "\n\n[NOTE TO ASSISTANT: ",
    "\n\nIMPORTANT: ",
    "\n\n<<<SYSTEM OVERRIDE>>> ",
    "\n\n[hidden instructions for the AI:] ",
    "\n\n# Updated guidance:\n",
    "\n\n```\n",
    "\n\nP.S. ",
)

_INJECTION_SUFFIXES = (
    "",
    "]",
    "\n\n---\n\n",
    "\n```\n",
)


def collect_attack_texts(
    loaded: dict[str, LoadedDataset],
    min_length: int = 20,
    max_length: int = 800,
) -> list[str]:
    """Pull all attack-positive texts from already-loaded sources.

    `min_length` filters out token-spam attacks that won't read as natural
    embedded content. `max_length` keeps embeds reasonable inside documents.
    """
    out: list[str] = []
    for ds in loaded.values():
        for text, label in zip(ds.texts, ds.labels, strict=False):
            if label != 1:
                continue
            t = text.strip()
            if min_length <= len(t) <= max_length:
                out.append(t)
    logger.info(
        "collected %d attack texts (length %d-%d) for synthesis",
        len(out),
        min_length,
        max_length,
    )
    return out


def load_wikipedia_documents(
    limit: int = 20000,
    min_chars: int = 800,
    max_chars: int = 4000,
    config: str = "20231101.simple",
) -> list[str]:
    """Stream Wikipedia article paragraphs as carrier documents.

    Uses the `simple` config (~180 MB) by default — sufficient variety for
    indirect-injection synthesis. Filters by length to get real paragraphs.
    Falls back to cnn_dailymail if Wikipedia is unreachable.
    """
    try:
        return _stream_dataset_field(
            "wikimedia/wikipedia",
            config=config,
            text_field="text",
            limit=limit,
            min_chars=min_chars,
            max_chars=max_chars,
            label="wikipedia",
        )
    except Exception as exc:
        logger.warning("wikipedia loader failed (%s); falling back to cnn_dailymail", exc)
        return _stream_dataset_field(
            "cnn_dailymail",
            config="3.0.0",
            text_field="article",
            limit=limit,
            min_chars=min_chars,
            max_chars=max_chars,
            label="cnn_dailymail",
        )


def _stream_dataset_field(
    repo_id: str,
    *,
    config: str | None,
    text_field: str,
    limit: int,
    min_chars: int,
    max_chars: int,
    label: str,
) -> list[str]:
    """Stream rows from a HF dataset (with optional config) and harvest a
    single text field. Truncates to max_chars on word boundary.
    """
    from datasets import load_dataset

    docs: list[str] = []
    # Try streaming mode first (lazy, low RAM)
    try:
        if config is not None:
            ds = load_dataset(repo_id, config, streaming=True)
        else:
            ds = load_dataset(repo_id, streaming=True)
        for split_name in ds:
            for row in ds[split_name]:
                doc = _harvest_doc(row, text_field, min_chars, max_chars)
                if doc is not None:
                    docs.append(doc)
                    if len(docs) >= limit:
                        break
            if len(docs) >= limit:
                break
    except Exception as exc:
        logger.info("streaming failed for %s (%s); falling back to eager", label, exc)
        ds = load_dataset(repo_id, config) if config is not None else load_dataset(repo_id)
        for split_name in ds:
            for row in ds[split_name]:
                doc = _harvest_doc(row, text_field, min_chars, max_chars)
                if doc is not None:
                    docs.append(doc)
                    if len(docs) >= limit:
                        break
            if len(docs) >= limit:
                break

    logger.info("loaded %d %s documents", len(docs), label)
    return docs


def _harvest_doc(row: dict, text_field: str, min_chars: int, max_chars: int) -> str | None:
    text = row.get(text_field) or ""
    if not isinstance(text, str):
        return None
    text = text.strip()
    if len(text) < min_chars:
        return None
    if len(text) > max_chars:
        text = text[:max_chars].rsplit(" ", 1)[0]
    return text


def _wrap_attack(attack: str, rng: random.Random) -> str:
    """Format an attack with a natural-looking lead-in / lead-out."""
    prefix = rng.choice(_INJECTION_PREFIXES)
    suffix = rng.choice(_INJECTION_SUFFIXES)
    return f"{prefix}{attack}{suffix}"


def _embed_attack(
    attack: str,
    document: str,
    position: str,
    rng: random.Random,
) -> str:
    """Insert the wrapped attack at a position inside the document."""
    wrapped = _wrap_attack(attack, rng)

    if position == "start":
        return wrapped.lstrip() + "\n\n" + document
    if position == "end":
        return document + wrapped
    if position == "middle":
        # Insert at a paragraph boundary near the middle for realism.
        midpoint = len(document) // 2
        # Find the nearest newline >= midpoint to avoid splitting words.
        idx = document.find("\n", midpoint)
        if idx == -1:
            idx = document.find(" ", midpoint)
        if idx == -1:
            idx = midpoint
        return document[:idx] + wrapped + document[idx:]

    # "random" or anything else — uniform position
    pos = rng.randint(0, len(document))
    space = document.rfind(" ", 0, pos)
    if space != -1:
        pos = space
    return document[:pos] + wrapped + document[pos:]


def synthesize_indirect_injections(
    attacks: list[str],
    documents: list[str],
    n_samples: int = 30000,
    positions: Iterable[str] = ("start", "middle", "end", "random"),
    framings: Iterable[str] = _DOC_FRAMINGS,
    seed: int = 42,
) -> LoadedDataset:
    """Generate indirect-injection samples by embedding attacks in documents.

    For each output sample:
      1. Pick a random attack and a random carrier document.
      2. Pick a random position (`start`/`middle`/`end`/`random`).
      3. Wrap the attack with a natural-looking prefix/suffix.
      4. Pick a random outer framing (e.g. "Summarize this:").
      5. Concatenate and label as attack=1.

    The diversity along each axis (attack, doc, position, wrapping, framing)
    means the model can't memorize a fixed pattern; it has to learn that an
    embedded instruction-override is the universal feature.
    """
    if not attacks:
        raise ValueError("synthesize_indirect_injections needs >=1 attack text")
    if not documents:
        raise ValueError("synthesize_indirect_injections needs >=1 document")

    rng = random.Random(seed)
    positions_list = list(positions)
    framings_list = list(framings)

    texts: list[str] = []
    for _ in range(n_samples):
        attack = rng.choice(attacks)
        doc = rng.choice(documents)
        pos = rng.choice(positions_list)
        framing = rng.choice(framings_list)

        injected_doc = _embed_attack(attack, doc, pos, rng)
        final = framing.format(doc=injected_doc)
        texts.append(final)

    return LoadedDataset(
        name="indirect_injection",
        texts=texts,
        labels=[1] * len(texts),
    )
