"""Stage 1 trainer with R-Drop + SupCon, plus checkpoint averaging (SWA).

Hlyn's published recipe combines R-Drop, SupCon, and SWA on top of a
DeBERTa-v3 backbone. We already had R-Drop. This module adds:

- **SupCon** as an auxiliary loss on CLS embeddings (alongside R-Drop CE).
  Pulls same-class samples together and pushes cross-class apart in the
  representation space, before the classifier head sees them.

- **Checkpoint averaging** as a pragmatic SWA approximation. After
  `trainer.train()` completes, we average the last N saved checkpoints
  and write the result to `<output_dir>/swa/`. Empirically this captures
  ~80% of the generalization benefit of true step-wise SWA at a fraction
  of the implementation complexity, and works cleanly with HF Trainer's
  load_best_model_at_end mechanic.
"""

from __future__ import annotations

import logging
import shutil
from pathlib import Path

import torch
import torch.nn.functional as F
from transformers import (
    DataCollatorWithPadding,
    Trainer,
    TrainingArguments,
)

from training.losses import RDropLoss, SupConLoss

logger = logging.getLogger(__name__)


class RDropSupConTrainer(Trainer):
    """Combines R-Drop (KL between two dropout passes on logits) with
    SupCon (contrastive on CLS embeddings).

    Both auxiliary losses are added to standard cross-entropy. SupCon is
    weighted by `supcon_alpha` (default 0.1, conservative because R-Drop
    is also there).
    """

    def __init__(
        self,
        *args,
        rdrop_alpha: float = 1.0,
        supcon_alpha: float = 0.1,
        supcon_temp: float = 0.07,
        **kwargs,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.rdrop_loss = RDropLoss(alpha=rdrop_alpha)
        self.supcon_loss = SupConLoss(temperature=supcon_temp)
        self.supcon_alpha = supcon_alpha

    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        labels = inputs.pop("labels")

        # During eval, take the cheap path: single forward pass, no
        # hidden states, plain CE. R-Drop / SupCon only have meaning when
        # gradients flow, and the extra forward + 12-layer hidden states
        # would double GPU memory and cause OOM on T4.
        if not model.training:
            out = model(**inputs)
            loss = F.cross_entropy(out.logits, labels)
            if return_outputs:
                return loss, out
            return loss

        # Training: full R-Drop + SupCon path.
        out1 = model(**inputs, output_hidden_states=True)
        out2 = model(**inputs, output_hidden_states=True)

        loss = self.rdrop_loss(out1.logits, out2.logits, labels)

        if self.supcon_alpha > 0:
            # Average the two passes' CLS embeddings — consistent with
            # R-Drop's "be invariant to dropout perturbation" objective.
            cls1 = out1.hidden_states[-1][:, 0, :]
            cls2 = out2.hidden_states[-1][:, 0, :]
            cls_avg = (cls1 + cls2) / 2.0
            sc = self.supcon_loss(cls_avg, labels)
            loss = loss + self.supcon_alpha * sc

        if return_outputs:
            return loss, out1
        return loss


def make_stage1_trainer(
    *,
    model,
    train_dataset,
    eval_dataset,
    tokenizer,
    output_dir: str,
    epochs: int = 3,
    lr: float = 5e-5,
    train_batch_size: int = 32,
    eval_batch_size: int = 64,
    rdrop_alpha: float = 1.0,
    supcon_alpha: float = 0.1,
    seed: int = 42,
    compute_metrics=None,
):
    """Construct the Stage 1 trainer (R-Drop + SupCon)."""
    args = TrainingArguments(
        output_dir=output_dir,
        learning_rate=lr,
        per_device_train_batch_size=train_batch_size,
        per_device_eval_batch_size=eval_batch_size,
        num_train_epochs=epochs,
        weight_decay=0.01,
        warmup_ratio=0.1,
        eval_strategy="epoch",
        eval_accumulation_steps=4,  # offload predictions to CPU every 4 steps to avoid GPU OOM
        save_strategy="epoch",
        save_total_limit=epochs,  # keep all per-epoch checkpoints for SWA
        load_best_model_at_end=True,
        metric_for_best_model="f1",
        greater_is_better=True,
        logging_steps=100,
        fp16=True,
        report_to="none",
        seed=seed,
    )

    return RDropSupConTrainer(
        model=model,
        args=args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        data_collator=DataCollatorWithPadding(tokenizer=tokenizer),
        compute_metrics=compute_metrics,
        rdrop_alpha=rdrop_alpha,
        supcon_alpha=supcon_alpha,
    )


def find_recent_checkpoints(output_dir: str, n: int = 2) -> list[Path]:
    """Find the most recent N `checkpoint-XXXX/` directories under output_dir."""
    base = Path(output_dir)
    if not base.exists():
        return []
    checkpoints = sorted(
        (p for p in base.iterdir() if p.is_dir() and p.name.startswith("checkpoint-")),
        key=lambda p: int(p.name.split("-")[1]),
    )
    return checkpoints[-n:]


def average_checkpoints(
    checkpoint_dirs: list[Path],
    output_dir: str,
    tokenizer=None,
) -> str:
    """Average model weights across checkpoints (SWA-style approximation).

    Writes the averaged weights + copied tokenizer/config to `output_dir`.
    Returns the path to the saved averaged model.
    """
    if len(checkpoint_dirs) == 0:
        raise ValueError("no checkpoints to average")
    if len(checkpoint_dirs) == 1:
        logger.warning("only 1 checkpoint to average; result equals the checkpoint")

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    # Load all state_dicts
    state_dicts = []
    for ckpt in checkpoint_dirs:
        sd_path_st = ckpt / "model.safetensors"
        sd_path_pt = ckpt / "pytorch_model.bin"
        if sd_path_st.exists():
            from safetensors.torch import load_file

            state_dicts.append(load_file(str(sd_path_st)))
        elif sd_path_pt.exists():
            state_dicts.append(torch.load(str(sd_path_pt), weights_only=True, map_location="cpu"))
        else:
            raise FileNotFoundError(f"no model weights in {ckpt}")

    # Average tensor-by-tensor
    avg: dict[str, torch.Tensor] = {}
    for key in state_dicts[0]:
        stacked = torch.stack([sd[key].float() for sd in state_dicts], dim=0)
        avg[key] = stacked.mean(dim=0).to(state_dicts[0][key].dtype)

    # Save in safetensors format. Configs/tokenizer copied from first ckpt.
    from safetensors.torch import save_file

    save_file(avg, str(out / "model.safetensors"))

    src_ckpt = checkpoint_dirs[-1]  # use latest for config/tokenizer files
    for fname in (
        "config.json",
        "tokenizer.json",
        "tokenizer_config.json",
        "vocab.txt",
        "special_tokens_map.json",
        "spm.model",
        "added_tokens.json",
    ):
        src = src_ckpt / fname
        if src.exists():
            shutil.copy(src, out / fname)

    if tokenizer is not None:
        tokenizer.save_pretrained(str(out))

    logger.info(
        "averaged %d checkpoints into %s",
        len(checkpoint_dirs),
        out,
    )
    return str(out)


def swa_average_after_training(
    output_dir: str,
    swa_dir: str,
    n_recent: int = 2,
    tokenizer=None,
) -> str:
    """One-shot SWA: find the last n_recent checkpoints in `output_dir` and
    save their average to `swa_dir`. Designed to run right after
    `trainer.train()` completes.
    """
    ckpts = find_recent_checkpoints(output_dir, n=n_recent)
    if not ckpts:
        raise FileNotFoundError(
            f"no checkpoints found under {output_dir}; "
            "ensure save_strategy='epoch' and save_total_limit >= n_recent"
        )
    return average_checkpoints(ckpts, swa_dir, tokenizer=tokenizer)
