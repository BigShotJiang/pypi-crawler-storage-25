# Training

Source-of-truth code for training Promptward's binary classifier. The
end-to-end pipeline runs in `notebooks/train.ipynb`; the modules in this
directory are imported by that notebook.

## Files

| File | Role |
|---|---|
| `data/normalize.py` | Text + label normalization helpers |
| `data/loaders.py` | One function per HF dataset, registered in `LABELED_LOADERS` |
| `data/synthesize.py` | Indirect-injection synthesizer (Wikipedia + attack embedding) |
| `data/llm_augment.py` | LLM-augmented attack generation (12 OWASP categories) |
| `data/review_llm.py` | Quality-review CLI for generated batches |
| `builder.py` | Combine sources, dedupe vs benchmarks, source-balance, stratified split |
| `losses.py` | R-Drop, SupCon, Distillation loss implementations |
| `trainer.py` | Stage 1 trainer (R-Drop + SupCon) + SWA checkpoint averaging |
| `distillation.py` | Stage 2 distillation (experimental, off by default) |

## Pipeline stages

1. **Stage 1 — Fine-tune with R-Drop + SupCon**
   Two forward passes with dropout; KL between them on top of cross-entropy.
   Supervised contrastive loss on CLS embeddings as an auxiliary objective.
   3 epochs default.
2. **Stage 2 — Distillation from teachers** (off by default)
   Score a balanced unlabeled corpus with a teacher model, KL-distill the
   soft labels into the student. Useful when a strong teacher is available.
3. **Stage 3 — Adversarial polish**
   In-place attack augmentation: zero-width insertions, character swaps,
   document / persona wrappers. 1 low-LR epoch.
4. **SWA** — average the last two epoch checkpoints. Downstream stages
   load the SWA model.
5. **Calibration** — fit a temperature scalar on validation logits.
6. **Eval** — run the full 5-benchmark suite, write a leaderboard.
7. **Export** — ONNX + INT8 quantization, ready for the SDK.

## Hard rules

- Held-out eval benchmarks (rogue, JailbreakBench, the held-out test splits
  of xTRam1 / S-Labs / deepset) **never** appear in training.
  `builder.build_corpus` dedupes against them automatically; don't bypass.
- Best-model checkpoint selected on **F1**, not loss.
- Save `temperature.json` alongside the model so the SDK can apply
  calibration at inference time.
- Validate ONNX/INT8 accuracy delta < 1 pp before publishing.

## Generating LLM-augmented data

```bash
# Set provider env vars (Azure OpenAI used below; OPENAI_API_KEY also works)
export AZURE_OPENAI_ENDPOINT=...
export AZURE_OPENAI_API_KEY=...

# Generate (one-time, cached to .local-data/llm_attacks/)
python -m training.data.llm_augment generate \
    --total 30000 --workers 10 --model <deployment_name>

# Review quality before scaling up
python -m training.data.review_llm
```

See [DATA.md](../DATA.md) for the full source list and license audit, and
[ATTRIBUTIONS.md](../ATTRIBUTIONS.md) for upstream credits.
