"""Combine loaded datasets into a clean train/val set.

Pipeline:
  1. Load all sources (training.data.loaders.load_all)
  2. Normalize text for dedupe key (lowercase + collapse whitespace)
  3. Drop exact duplicates within and across sources
  4. Drop overlap with the held-out rogue-security benchmark
  5. Cap per-source samples (per label) for balance
  6. Stratified train/val split

The held-out rogue benchmark stays out of training entirely — that's the
contract we make with anyone evaluating us. Don't relax it.
"""

from __future__ import annotations

import logging
import random
import re
from collections import Counter, defaultdict
from dataclasses import dataclass

from training.data.loaders import LoadedDataset

logger = logging.getLogger(__name__)


_WS_RE = re.compile(r"\s+")


def _norm(text: str) -> str:
    return _WS_RE.sub(" ", text.strip().lower())


@dataclass
class TrainingCorpus:
    train_texts: list[str]
    train_labels: list[int]
    train_sources: list[str]
    val_texts: list[str]
    val_labels: list[int]
    val_sources: list[str]

    @property
    def stats(self) -> dict:
        def _summary(texts, labels, sources):
            return {
                "n": len(texts),
                "labels": dict(Counter(labels)),
                "sources": dict(Counter(sources)),
            }

        return {
            "train": _summary(self.train_texts, self.train_labels, self.train_sources),
            "val": _summary(self.val_texts, self.val_labels, self.val_sources),
        }


def build_corpus(
    loaded: dict[str, LoadedDataset],
    benchmark_texts: list[str] | None = None,
    caps_per_source: dict[str, int] | None = None,
    val_fraction: float = 0.05,
    seed: int = 42,
) -> TrainingCorpus:
    benchmark_keys = {_norm(t) for t in (benchmark_texts or [])}

    seen: set[str] = set()
    pool: list[tuple[str, int, str]] = []  # (text, label, source)

    for source, ds in loaded.items():
        before = len(ds.texts)
        kept = 0
        bench_overlap = 0
        for text, label in zip(ds.texts, ds.labels, strict=False):
            key = _norm(text)
            if not key:
                continue
            if key in benchmark_keys:
                bench_overlap += 1
                continue
            if key in seen:
                continue
            seen.add(key)
            pool.append((text, label, source))
            kept += 1
        logger.info(
            "%s: kept %d / %d (bench_overlap=%d duplicate=%d)",
            source,
            kept,
            before,
            bench_overlap,
            before - kept - bench_overlap,
        )

    capped = _apply_caps(pool, caps_per_source) if caps_per_source else pool

    rng = random.Random(seed)
    by_strata: dict[tuple[str, int], list[tuple[str, int, str]]] = defaultdict(list)
    for text, label, source in capped:
        by_strata[(source, label)].append((text, label, source))

    train: list[tuple[str, int, str]] = []
    val: list[tuple[str, int, str]] = []
    for items in by_strata.values():
        rng.shuffle(items)
        n_val = max(1, int(len(items) * val_fraction)) if items else 0
        val.extend(items[:n_val])
        train.extend(items[n_val:])

    rng.shuffle(train)
    rng.shuffle(val)

    return TrainingCorpus(
        train_texts=[t for t, _, _ in train],
        train_labels=[lbl for _, lbl, _ in train],
        train_sources=[s for _, _, s in train],
        val_texts=[t for t, _, _ in val],
        val_labels=[lbl for _, lbl, _ in val],
        val_sources=[s for _, _, s in val],
    )


def _apply_caps(
    pool: list[tuple[str, int, str]],
    caps: dict[str, int],
) -> list[tuple[str, int, str]]:
    by_source_label: dict[tuple[str, int], list] = defaultdict(list)
    for text, label, source in pool:
        by_source_label[(source, label)].append((text, label, source))

    out: list[tuple[str, int, str]] = []
    for (source, label), items in by_source_label.items():
        cap_total = caps.get(source)
        if cap_total is None:
            out.extend(items)
            continue
        cap_per_label = cap_total // 2
        if len(items) <= cap_per_label:
            out.extend(items)
        else:
            random.Random((source, label).__hash__()).shuffle(items)
            out.extend(items[:cap_per_label])
        logger.info(
            "%s label=%d: capped to %d (had %d)",
            source,
            label,
            min(len(items), cap_per_label),
            len(items),
        )
    return out


# Per-source caps. Tuned empirically to balance signal vs class skew.
#
# Caps interact with `_apply_caps` which splits each cap 50/50 between
# attack and benign labels. Sources that are 100% one label (e.g.
# tensor_trust is attack-only) effectively use only half the cap unless
# the cap is doubled — see the note in `_apply_caps`.
DEFAULT_CAPS = {
    # --- Largest sources, broad attack/benign coverage ---
    "hlyn_judge": 80000,  # 400k pool; strongest single attack signal
    "guychuk": 25000,  # 464k pool, professional-framing rich
    "neuralchemy_threat": 25000,  # 32k, intent-typed (6 categories)
    "neuralchemy_core": 6000,  # 6k, hard-negative benigns included
    # --- Real human-crafted attacks ---
    "tensor_trust": 30000,  # Berkeley CTF, real adversaries
    # --- Synthesized ---
    "indirect_injection": 30000,  # Wikipedia + embedded attacks
    "llm_attacks": 30000,  # LLM-generated, OWASP taxonomy
    # --- Curated HF attack sources ---
    "xTRam1": 10000,
    "S-Labs": 12000,
    "necent": 15000,
    "bogdanminko": 8000,
    "jailbreak_classification": 1500,
    "deepset": 1000,
    # --- HackaPrompt-derived ---
    "imoxto_v2": 12000,
    "hackaprompt": 8000,
    # --- Lakera extraction game ---
    "mosscap": 6000,
    # --- Benign creative writing / instructions ---
    "hh_rlhf": 30000,
    "alpaca": 15000,
    "dolly": 15000,
}
