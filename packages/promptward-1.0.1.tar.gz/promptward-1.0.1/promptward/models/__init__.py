from promptward.models.loader import ModelArtifact, OnnxModelLoader

__all__ = ["ModelArtifact", "OnnxModelLoader"]
