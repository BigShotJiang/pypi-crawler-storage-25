from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from promptward.models.loader import OnnxModelLoader

# Returned when model weights are not yet available. Sits exactly between
# safe_below and attack_above so it routes to whichever next stage is enabled
# without falsely classifying anything.
NEUTRAL_RISK = 0.5


@dataclass
class BinaryPrediction:
    risk: float
    available: bool


class BinaryStage:
    def __init__(self, model_id: str, cache_dir: str | None = None) -> None:
        self.model_id = model_id
        self._loader = OnnxModelLoader(model_id, cache_dir=cache_dir)

    def is_available(self) -> bool:
        return self._loader.is_available()

    def predict(self, text: str) -> BinaryPrediction:
        if not self.is_available():
            return BinaryPrediction(risk=NEUTRAL_RISK, available=False)

        artifact = self._loader.artifact
        encoding = artifact.tokenizer.encode(text)

        input_ids = np.array([encoding.ids], dtype=np.int64)
        attention_mask = np.array([encoding.attention_mask], dtype=np.int64)

        feed: dict[str, np.ndarray] = {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
        }
        if "token_type_ids" in {i.name for i in artifact.session.get_inputs()}:
            feed["token_type_ids"] = np.zeros_like(input_ids)

        outputs = artifact.session.run(None, feed)
        logits = outputs[0][0]
        probs = _softmax(logits)
        # Convention: index 1 is the attack class.
        attack_prob = float(probs[1]) if probs.shape[0] > 1 else float(probs[0])

        return BinaryPrediction(risk=attack_prob, available=True)


def _softmax(logits: np.ndarray) -> np.ndarray:
    shifted = logits - logits.max()
    exp = np.exp(shifted)
    return exp / exp.sum()
