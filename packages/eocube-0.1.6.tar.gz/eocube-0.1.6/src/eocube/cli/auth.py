# Copyright 2025 West University of Timisoara
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import base64
import json
import logging
import os
import sys
import threading
import time
import webbrowser
from datetime import datetime

import click
import keyring
import requests
from authlib.integrations.requests_client import OAuth2Session
from authlib.integrations.base_client.errors import OAuthError

from eocube.cli import console

from eocube.common import ROCS_DISCOVERY_URL
from eocube.common.auth import (
    discover_client_token,
    _is_token_valid,
    get_storage_credentials_using_access_token,
)
from eocube.common.exceptions import EOCubeAuthenticationException
from eocube.common.i18n import t

log = logging.getLogger("rich")

EOCUBE_CLI_CLIENT_ID = "eocube-cli"
EOCUBE_CLI_REDIRECT_URI = "http://localhost:5123/callback"

login_done = threading.Event()

authorize_url = None
token_url = None


def get_token():
    access_token = keyring.get_password("eocube-cli", "access-token")
    refresh_token = keyring.get_password("eocube-cli", "offline-refresh-token")

    if access_token and _is_token_valid(access_token):
        log.info(t("auth.found_valid_token"))
        return access_token
    else:
        log.warning(t("auth.no_token_found"))

    if not refresh_token:
        raise click.ClickException(t("auth.no_refresh_token"))

    metadata = requests.get(ROCS_DISCOVERY_URL).json()
    token_url = metadata["token_endpoint"]

    log.warning(t("auth.refreshing_token"))

    session = OAuth2Session(
        client_id=EOCUBE_CLI_CLIENT_ID, client_secret=None  # public client
    )

    try:
        token = session.refresh_token(token_url, refresh_token=refresh_token)
    except OAuthError as e:
        # Stale refresh token / revoked offline session — drop it so the next
        # invocation does not loop on the same error.
        if e.error in ("invalid_grant", "invalid_token"):
            for entry in ("offline-refresh-token", "access-token"):
                try:
                    keyring.delete_password("eocube-cli", entry)
                except keyring.errors.PasswordDeleteError:
                    pass
        raise click.ClickException(
            t("auth.session_expired", desc=e.description or e.error)
        )

    new_access_token = token["access_token"]
    new_refresh_token = token.get("refresh_token", refresh_token)

    keyring.set_password("eocube-cli", "access-token", new_access_token)
    keyring.set_password("eocube-cli", "offline-refresh-token", new_refresh_token)

    log.info(t("auth.saved_new_tokens"))

    return new_access_token


@click.group("auth", help=t("cli.auth_help"))
def auth_cli():
    """Authentication related functionality"""


@auth_cli.command("info", help=t("cli.info_help"))
def info_authentication():
    """Show information about the authenticated user"""

    token = get_token()
    try:
        payload_part = token.split(".")[1]
        padded = payload_part + "=" * (-len(payload_part) % 4)
        decoded = json.loads(base64.urlsafe_b64decode(padded.encode()))

        console.print(t("auth.info_title") + "\n")

        for key in [
            "sub",
            "preferred_username",
            "email",
            "name",
            "given_name",
            "family_name",
            "roles",
            "scope",
            "policy",
        ]:
            if key in decoded:
                console.print(f"{key:>20}: {decoded[key]}")
        if "exp" in decoded:
            exp_time = datetime.fromtimestamp(decoded["exp"])
            console.print(
                f"{'exp':>20}: {decoded['exp']} ("
                + t("auth.expires_on", when=exp_time)
                + ")"
            )

        if "realm_access" in decoded and "roles" in decoded["realm_access"]:
            roles = decoded["realm_access"]["roles"]
            console.print(f"{'roles':>20}: {', '.join(roles)}")
    except Exception as e:
        console.print(t("auth.cannot_decode_payload"), e)
        sys.exit(1)


def login_with_device_flow():
    metadata = requests.get(ROCS_DISCOVERY_URL).json()
    device_auth_url = metadata["device_authorization_endpoint"]
    token_url = metadata["token_endpoint"]
    device_resp = requests.post(
        device_auth_url,
        data={
            "client_id": EOCUBE_CLI_CLIENT_ID,
            "scope": "openid offline_access profile roles eocube-object-storage",
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    ).json()

    # session = OAuth2Session(EOCUBE_CLI_CLIENT_ID)

    print("\n" + t("auth.auth_required_banner"))
    print(t("auth.open_browser"))
    print(device_resp["verification_uri_complete"])
    print(t("auth.enter_code"), device_resp["user_code"])

    while True:
        time.sleep(device_resp.get("interval", 5))
        token_resp = requests.post(
            token_url,
            data={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "device_code": device_resp["device_code"],
                "client_id": EOCUBE_CLI_CLIENT_ID,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        if token_resp.status_code == 200:
            oauth_token = token_resp.json()
            print(t("auth.auth_success"))
            keyring.set_password(
                "eocube-cli", "offline-refresh-token", oauth_token["refresh_token"]
            )
            keyring.set_password(
                "eocube-cli", "access-token", oauth_token["access_token"]
            )
            break
        else:
            err = token_resp.json().get("error")
            if err in ["authorization_pending", "slow_down"]:
                print(t("auth.waiting_authorization", err=err))
                continue
            else:
                raise EOCubeAuthenticationException(
                    t("auth.device_flow_failed", err=err)
                )


@auth_cli.command("login", help=t("cli.login_help"))
@click.option(
    "--device-flow", is_flag=True, help=t("cli.use_device_flow"), default=False
)
def login(device_flow=False):
    if "EOCUBE_CLIENT_ID" in os.environ:  # Using env driven login
        return login_with_client_credentials()
    elif device_flow:
        return login_with_device_flow()
    else:
        return login_using_browser()


def login_with_client_credentials():
    auth_client = discover_client_token()
    oauth_token = auth_client.token
    if "refresh_token" in oauth_token:  # This should never be true
        keyring.set_password(
            "eocube-cli", "offline-refresh-token", oauth_token["refresh_token"]
        )
    keyring.set_password("eocube-cli", "access-token", oauth_token["access_token"])
    console.print(t("auth.saved_tokens"))


def login_using_browser():
    from flask import Flask, request

    """Login to EOCube.ro"""

    logging.getLogger("werkzeug").setLevel(logging.ERROR)

    app = Flask(__name__)
    server_thread = None

    def start_oauth_flow():
        global authorize_url
        global token_url
        oauth = OAuth2Session(
            EOCUBE_CLI_CLIENT_ID, redirect_uri=EOCUBE_CLI_REDIRECT_URI
        )
        metadata = requests.get(ROCS_DISCOVERY_URL).json()
        authorize_url = metadata["authorization_endpoint"]
        token_url = metadata["token_endpoint"]
        uri, state = oauth.create_authorization_url(
            authorize_url, scope="openid offline_access eocube-object-storage"
        )
        webbrowser.open(uri)
        return oauth

    def run_flask():
        app.run(port=5123, use_reloader=False)

    def shutdown_server():
        func = request.environ.get("werkzeug.server.shutdown")
        if func:
            func()

    @app.route("/callback")
    def callback():
        global oauth_token
        global token_url

        code = request.args.get("code")
        if not code:
            return t("auth.callback_no_code")

        token = app.oauth_session.fetch_token(token_url, code=code)

        oauth_token = token  # salvează tokenul pt codul principal
        login_done.set()
        shutdown_server()  # oprește Flask

        return t("auth.callback_success_html")

    console.print(t("auth.starting_login"))
    # global server_thread
    server_thread = threading.Thread(target=run_flask)
    server_thread.start()
    time.sleep(1)
    app.oauth_session = start_oauth_flow()
    login_done.wait()

    keyring.set_password(
        "eocube-cli", "offline-refresh-token", oauth_token["refresh_token"]
    )
    keyring.set_password("eocube-cli", "access-token", oauth_token["access_token"])
    console.print(t("auth.saved_tokens"))
    os._exit(0)


@auth_cli.command(
    "get-storage-credentials-with-token", help=t("cli.get_storage_credentials_help")
)
@click.option(
    "--endpoint",
    prompt=False,
    help=t("cli.storage_endpoint_help"),
    default="https://storage.svc.uvt-01.eocube.ro/",
)
@click.option("--token", prompt=True, help=t("cli.oidc_token_help"))
@click.option(
    "--duration-seconds",
    prompt=False,
    help=t("cli.duration_seconds_help"),
    default=3600,
)
def get_storage_credentials_with_token(endpoint, token, duration_seconds=3600):
    creds = get_storage_credentials_using_access_token(
        endpoint, token, duration_seconds=duration_seconds
    )
    console.print(t("storage.access_key", value=creds.access_key))
    console.print(t("storage.secret_key", value=creds.secret_key))
    console.print(t("storage.session_token", value=creds.session_token))
    console.print(t("storage.expiration", value=creds.expiration))


@auth_cli.command("logout", help=t("cli.logout_help"))
def logout():
    """Logout from EOCloud.Ro"""

    refresh_token = keyring.get_password("eocube-cli", "offline-refresh-token")
    access_token = keyring.get_password("eocube-cli", "access-token")

    metadata = requests.get(ROCS_DISCOVERY_URL).json()
    revocation_endpoint = metadata.get("revocation_endpoint")
    if not revocation_endpoint:
        raise click.UsageError(t("auth.no_revocation_endpoint"))
    client_id = EOCUBE_CLI_CLIENT_ID
    client_secret = None  # dacă e public client

    def revoke(token, token_type_hint):
        data = {
            "client_id": client_id,
            "token": token,
            "token_type_hint": token_type_hint,
        }
        if client_secret:
            data["client_secret"] = client_secret

        resp = requests.post(revocation_endpoint, data=data)
        if resp.status_code == 200:
            log.info(t("auth.token_revoked", token_type=token_type_hint))
        else:
            log.error(
                t(
                    "auth.revoke_error",
                    token_type=token_type_hint,
                    status=resp.status_code,
                    text=resp.text,
                )
            )
            raise click.Abort(t("auth.revoke_failed"))

    if refresh_token:
        revoke(refresh_token, "refresh_token")
        keyring.delete_password("eocube-cli", "offline-refresh-token")
        log.info(t("auth.refresh_token_deleted"))

    if access_token:
        revoke(access_token, "access_token")
        keyring.delete_password("eocube-cli", "access-token")
        log.info(t("auth.access_token_deleted"))

    if not access_token and not refresh_token:
        log.info(t("auth.no_tokens_in_keyring"))

    log.info(t("auth.logout_complete"))


@auth_cli.command("get-storage-credentials", help=t("cli.get_storage_credentials_help"))
@click.option(
    "--endpoint",
    help=t("cli.storage_endpoint_help"),
    default="https://storage.svc.uvt-01.eocube.ro/",
)
@click.option("--as-json", is_flag=True, help=t("cli.return_json_help"))
@click.option("--duration", type=int, help=t("cli.duration_seconds_help"), default=3600)
def get_storage_credentials(endpoint, as_json=False, duration=3600):
    """Return S3 Credentials"""
    access_token = get_token()
    creds = get_storage_credentials_using_access_token(
        endpoint=endpoint, token=access_token, duration_seconds=duration
    )
    if as_json:
        print(
            json.dumps(
                {
                    "access_key": creds.access_key,
                    "secret_key": creds.secret_key,
                    "session_token": creds.session_token,
                    "expiration": creds.expiration.isoformat(),
                }
            )
        )
    else:
        console.print(t("storage.access_key", value=creds.access_key))
        console.print(t("storage.secret_key", value=creds.secret_key))
        console.print(t("storage.session_token", value=creds.session_token))
        console.print(t("storage.expiration", value=creds.expiration))


@auth_cli.command("get-access-token", help=t("cli.get_access_token_help"))
def get_access_token_cli():
    """Return access token"""
    print(get_token())
