# Copyright 2025 West University of Timisoara
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import io

import click
from rich.table import Table

from eocube.cli import console
from eocube.common.i18n import t
from eocube.services.geospatialorg.uat import (
    UAT,
    get_county_by_name,
    get_county_by_mnemonic,
    get_administrative_unit_by_name,
    get_administrative_unit_by_code,
)

__ascii_art_availble = False


def _ascii_art_availble():
    try:
        import matplotlib.pyplot as plt
        import ascii_magic

        __ascii_art_availble = True
    except ImportError:
        __ascii_art_availble = False
    return __ascii_art_availble


def print_table(table):
    console.print(table)


def print_gdf(gdf):
    import matplotlib.pyplot as plt
    import ascii_magic

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.axis("off")
    gdf.plot(ax=ax)
    buf = io.BytesIO()
    plt.savefig(buf, format="png", bbox_inches="tight")
    plt.close(fig)
    buf.seek(0)
    ascii_art = ascii_magic.from_image(buf)
    ascii_art.to_terminal()


def uat_gdf_to_table(gdf, title):
    result_table = Table(title=f"Geo-Spatial.org -- {title}")
    result_table.add_column("Name", justify="left")
    result_table.add_column("natLevName", justify="left")
    result_table.add_column("countyCode", justify="left")
    result_table.add_column("county", justify="left")
    result_table.add_column("countyMn", justify="left")
    result_table.add_column("regionId", justify="left")
    result_table.add_column("regionCode", justify="left")
    result_table.add_column("region", justify="left")
    result_table.add_column("pop2011", justify="left")
    result_table.add_column("pop2012", justify="left")
    result_table.add_column("pop2013", justify="left")
    result_table.add_column("pop2014", justify="left")
    result_table.add_column("pop2015", justify="left")
    result_table.add_column("pop2020", justify="left")
    result_table.add_column("Area", justify="left")
    result_table.add_column("Centroid", justify="left")
    for _, row in gdf.head(10).iterrows():
        result_table.add_row(
            row["name"],
            row["natLevName"],
            f"{row['countyCode']}",
            row["county"],
            row["countyMn"],
            f"{row['regionId']}",
            f"{row['regionCode']}",
            row["region"],
            f"{int(row['pop2011']):,}",
            f"{int(row['pop2012']):,}",
            f"{int(row['pop2013']):,}",
            f"{int(row['pop2014']):,}",
            f"{int(row['pop2015']):,}",
            f"{int(row['pop2020']):,}",
            f"{row['geometry'].area:.2f}",
            str(row["geometry"].centroid),
        )
    return result_table


def county_gdf_to_table(gdf, title):
    result_table = Table(title=f"Geo-Spatial.org -- {title}")
    result_table.add_column("Name", justify="left")
    result_table.add_column("Mnemonic", justify="left")
    result_table.add_column("Region", justify="left")
    result_table.add_column("Pop. 1948", justify="left")
    result_table.add_column("Pop. 1956", justify="left")
    result_table.add_column("Pop. 1966", justify="left")
    result_table.add_column("Pop. 1977", justify="left")
    result_table.add_column("Pop. 1992", justify="left")
    result_table.add_column("Pop. 2002", justify="left")
    result_table.add_column("Pop. 2011", justify="left")
    result_table.add_column("Area", justify="left")
    result_table.add_column("Centroid", justify="left")
    for _, row in gdf.head(10).iterrows():
        result_table.add_row(
            row["name"],
            row["mnemonic"],
            row["region"],
            f"{int(row['pop1948']):,}",
            f"{int(row['pop1956']):,}",
            f"{int(row['pop1966']):,}",
            f"{int(row['pop1977']):,}",
            f"{int(row['pop1992']):,}",
            f"{int(row['pop2002']):,}",
            f"{int(row['pop2011']):,}",
            f"{row['geometry'].area:.2f}",
            str(row["geometry"].centroid),
        )
    return result_table


@click.group()
def geospatialorg():
    pass


@click.command("get-county-by-name")
@click.option("--name", prompt="Name of County", help="County Name")
@click.option("--epsg", default=3844, help="EPSG of the results")
@click.option(
    "--ascii-art",
    is_flag=True,
    default=False,
    help="Prin ascii art of the map, if available.",
)
@click.option(
    "--output", default=None, help="Destination of the output saved as GeoJSON"
)
def get_county_by_name_cli(name: str, output, epsg: int = 3844, ascii_art=False):
    """Retrieves the county by name"""
    result = get_county_by_name(name, epsg=epsg)
    if result is None:
        click.echo(t("geospatialorg.county_not_found"))
        return
    if output is not None:
        result.to_file(output, driver="GeoJSON")
    else:
        if ascii_art and _ascii_art_availble():
            print_gdf(result)
        else:
            print_table(county_gdf_to_table(result, f"Counties by Name ({name})"))

    return result


@click.command("get-county-by-mnemonic")
@click.option("--name", prompt="County Mnemonic", help="County Mnemonic. Eg. TM")
@click.option("--epsg", default=3844, help="EPSG of the results")
@click.option(
    "--ascii-art",
    is_flag=True,
    default=False,
    help="Prin ascii art of the map, if available.",
)
@click.option(
    "--output", default=None, help="Destination of the output saved as GeoJSON"
)
def get_county_by_mnemonic_cli(
    name: str, output: str, epsg: int = 3844, ascii_art=False
):
    """Retrieves the county by mnemonic"""
    result = get_county_by_mnemonic(name, epsg=epsg)
    if result is None:
        click.echo(t("geospatialorg.county_not_found"))
        return
    if output is not None:
        result.to_file(output, driver="GeoJSON")
    else:
        if ascii_art and _ascii_art_availble():
            print_gdf(result)
        else:
            print_table(county_gdf_to_table(result, f"Counties by Mnemonic ({name})"))
    return result


@click.command("get-administrative-unit-by-name")
@click.option(
    "--name", prompt="Name of administrative unit", help="Administrative unit name"
)
@click.option("--epsg", default=3844, help="EPSG of the results")
@click.option(
    "--ascii-art",
    is_flag=True,
    default=False,
    help="Prin ascii art of the map, if available.",
)
@click.option(
    "--output", default=None, help="Destination of the output saved as GeoJSON"
)
def get_administrative_unit_by_name_cli(
    name: str, output=str, matchcase=False, epsg: int = 4326, ascii_art=False
):
    """Retrieves the administrative unit by name"""
    result = get_administrative_unit_by_name(name, epsg=epsg, matchcase=matchcase)
    if result is None:
        click.echo(t("geospatialorg.administrative_unit_not_found"))
        return
    if output is not None:
        result.to_file(output, driver="GeoJSON")
    else:
        if ascii_art and _ascii_art_availble():
            print_gdf(result)
        else:
            print_table(uat_gdf_to_table(result, f"Counties by Name ({name})"))
    return result


@click.command("get-administrative-unit-by-code")
@click.option(
    "--code",
    prompt="Administrative unit code",
    help="SIRUTA Code of the administrative unit",
)
@click.option("--epsg", default=3844, help="EPSG of the results")
@click.option(
    "--ascii-art",
    is_flag=True,
    default=False,
    help="Prin ascii art of the map, if available.",
)
@click.option(
    "--output", default=None, help="Destination of the output saved as GeoJSON"
)
def get_administrative_unit_by_code_cli(
    code: int, output, epsg: int = 4326, ascii_art=False
):
    """Uses the SIRUTA Code to retrieve the administrative unit"""
    result = get_administrative_unit_by_code(siruta_code=code, epsg=epsg)
    if result is None:
        click.echo(t("geospatialorg.administrative_unit_not_found"))
        return
    if output is not None:
        result.to_file(output, driver="GeoJSON")
    else:
        if ascii_art and _ascii_art_availble():
            print_gdf(result)
        else:
            print_table(uat_gdf_to_table(result, f"Counties by SIRUTA ({code})"))
    return result


def register(cli):
    try:
        from eocube.services.geospatialorg.uat import UAT

        cli.add_command(geospatialorg)
        geospatialorg.add_command(get_county_by_name_cli)
        geospatialorg.add_command(get_county_by_mnemonic_cli)
        geospatialorg.add_command(get_administrative_unit_by_name_cli)
        geospatialorg.add_command(get_administrative_unit_by_code_cli)
    except ImportError:
        pass
