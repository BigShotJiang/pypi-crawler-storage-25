# Re-export for backward compatibility
from eocube.common import ROCS_DEFAULT_STORAGE_ENDPOINT
