# Copyright 2025 West University of Timisoara
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
"""Version + build provenance helpers.

Resolution order:

1. ``eocube._build_info.GIT_HASH`` / ``GIT_DIRTY`` — populated at wheel-build
   time by ``scripts/stamp-build-info.sh``. Authoritative for installed wheels.
2. Live ``git rev-parse`` against the working tree containing this module —
   used for editable installs where ``_build_info`` was never stamped.
3. ``(None, None)`` — unknown.

The package version itself comes from :func:`importlib.metadata.version`,
which reads the value Poetry stamps into the wheel's ``METADATA`` from
``pyproject.toml``.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path

from eocube import _build_info

log = logging.getLogger(__name__)


def get_version() -> str:
    """Return the installed package version, or ``"unknown"``."""
    try:
        from importlib.metadata import PackageNotFoundError, version

        return version("eocube")
    except Exception:
        return "unknown"


def _live_git_info(repo_root: Path) -> tuple[str | None, bool | None]:
    """Query git directly. Returns ``(None, None)`` on any failure."""
    if not (repo_root / ".git").exists():
        return None, None
    try:
        sha = (
            subprocess.check_output(
                ["git", "rev-parse", "HEAD"],
                cwd=repo_root,
                stderr=subprocess.DEVNULL,
            )
            .decode()
            .strip()
        )
    except Exception:
        return None, None
    try:
        rc = subprocess.call(
            ["git", "diff-index", "--quiet", "HEAD", "--"],
            cwd=repo_root,
            stderr=subprocess.DEVNULL,
        )
        dirty = rc != 0
    except Exception:
        dirty = None
    return sha, dirty


def get_git_info() -> tuple[str | None, bool | None]:
    """Return ``(commit_hash, dirty_flag)`` for the build that produced this code.

    Either entry may be ``None`` if unavailable.
    """
    if _build_info.GIT_HASH:
        return _build_info.GIT_HASH, _build_info.GIT_DIRTY

    # Editable / checkout install fallback. ``__file__`` is .../src/eocube/version.py
    repo_root = Path(__file__).resolve().parent.parent.parent
    return _live_git_info(repo_root)


def format_version_string() -> str:
    """Single-line human-readable version string used by ``eocube --version``."""
    v = get_version()
    sha, dirty = get_git_info()
    if not sha:
        return f"eocube {v}"
    short = sha[:12]
    if dirty is True:
        return f"eocube {v}, commit {short} (dirty)"
    if dirty is False:
        return f"eocube {v}, commit {short} (clean)"
    return f"eocube {v}, commit {short}"


__version__ = get_version()

__all__ = [
    "__version__",
    "get_version",
    "get_git_info",
    "format_version_string",
]
