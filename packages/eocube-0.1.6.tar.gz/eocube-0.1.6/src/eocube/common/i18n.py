# Copyright 2025 West University of Timisoara
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
"""Lightweight localization wrapper.

Locale detection order:
  1. ``EOCUBE_LANG`` environment variable (explicit override)
  2. ``LC_ALL`` / ``LC_MESSAGES`` / ``LANG`` POSIX environment variables
  3. ``locale.getlocale()`` (system setting)
  4. fallback to ``"en"``

Only the 2-letter language code (lowercase) is used. If a detected language
has no translation file under ``eocube/locales/``, the default language is
used instead.

Translation files are YAML, named ``{lang}.yml``, with a single top-level
key matching the language code, e.g.::

    en:
      auth:
        login_help: "Login to EOCube.ro"

The :func:`t` helper looks up nested keys using dot notation, e.g.
``t("auth.login_help")``. Keyword arguments are forwarded as ``str.format``
substitutions.

If the optional :mod:`i18n` (``python-i18n``) backend is unavailable, this
module falls back to its own minimal YAML loader (or, as a last resort, to
returning the key itself). This keeps the library usable without the
``core`` extra installed.
"""

from __future__ import annotations

import locale as _locale
import logging
import os
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

DEFAULT_LANGUAGE = "en"
LOCALES_DIR = Path(__file__).resolve().parent.parent / "locales"

_initialized = False
_active_lang = DEFAULT_LANGUAGE
_translations: dict[str, dict[str, Any]] = {}


# ---------------------------------------------------------------------------
# Locale detection
# ---------------------------------------------------------------------------


def detect_language() -> str:
    """Return the 2-letter language code derived from env / system settings."""
    explicit = os.environ.get("EOCUBE_LANG")
    if explicit:
        return explicit[:2].lower()

    for env_var in ("LC_ALL", "LC_MESSAGES", "LANG"):
        value = os.environ.get(env_var)
        if value and value not in ("C", "POSIX"):
            return value[:2].lower()

    try:
        loc = _locale.getlocale()[0]
    except Exception:
        loc = None
    if not loc:
        try:
            loc = _locale.getdefaultlocale()[0]  # type: ignore[attr-defined]
        except Exception:
            loc = None

    if loc:
        return loc[:2].lower()

    return DEFAULT_LANGUAGE


def supported_languages() -> list[str]:
    """Return the languages with translation files available."""
    if not LOCALES_DIR.is_dir():
        return [DEFAULT_LANGUAGE]
    langs = {p.stem for p in LOCALES_DIR.glob("*.yml")}
    langs.add(DEFAULT_LANGUAGE)
    return sorted(langs)


# ---------------------------------------------------------------------------
# Translation loading
# ---------------------------------------------------------------------------


def _load_yaml_file(path: Path) -> dict[str, Any]:
    """Load a YAML file, preferring PyYAML; fall back to an empty dict."""
    try:
        import yaml  # type: ignore
    except ImportError:
        log.debug("PyYAML not installed; cannot load %s", path)
        return {}
    try:
        with path.open("r", encoding="utf-8") as fh:
            return yaml.safe_load(fh) or {}
    except Exception as e:
        log.warning("Failed to load locale file %s: %s", path, e)
        return {}


def _load_translations(lang: str) -> dict[str, Any]:
    """Load translations for `lang`. The returned dict is the per-language tree."""
    path = LOCALES_DIR / f"{lang}.yml"
    if not path.is_file():
        return {}
    data = _load_yaml_file(path)
    # Files use the language code as the top-level key.
    return data.get(lang, data) if isinstance(data, dict) else {}


def _initialize() -> None:
    global _initialized, _active_lang
    if _initialized:
        return
    desired = detect_language()
    available = supported_languages()
    _active_lang = desired if desired in available else DEFAULT_LANGUAGE

    _translations[DEFAULT_LANGUAGE] = _load_translations(DEFAULT_LANGUAGE)
    if _active_lang != DEFAULT_LANGUAGE:
        _translations[_active_lang] = _load_translations(_active_lang)

    _initialized = True


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def get_language() -> str:
    """Return the active 2-letter language code."""
    _initialize()
    return _active_lang


def set_language(lang: str) -> None:
    """Override the active language. Use ``""`` or ``None`` to re-detect."""
    global _active_lang, _initialized
    if not lang:
        _initialized = False
        _initialize()
        return
    _active_lang = lang[:2].lower()
    if _active_lang not in _translations:
        _translations[_active_lang] = _load_translations(_active_lang)
    _initialized = True


def _lookup(tree: dict[str, Any], dotted_key: str) -> Any:
    node: Any = tree
    for part in dotted_key.split("."):
        if not isinstance(node, dict) or part not in node:
            return None
        node = node[part]
    return node


def t(key: str, **kwargs: Any) -> str:
    """Translate ``key`` using the active locale.

    Lookup falls back to ``DEFAULT_LANGUAGE`` and finally to the key itself.
    ``kwargs`` are interpolated via ``str.format``.
    """
    _initialize()
    value = _lookup(_translations.get(_active_lang, {}), key)
    if value is None and _active_lang != DEFAULT_LANGUAGE:
        value = _lookup(_translations.get(DEFAULT_LANGUAGE, {}), key)
    if value is None:
        value = key
    if not isinstance(value, str):
        return str(value)
    if kwargs:
        try:
            return value.format(**kwargs)
        except Exception:
            return value
    return value


__all__ = [
    "DEFAULT_LANGUAGE",
    "LOCALES_DIR",
    "detect_language",
    "supported_languages",
    "get_language",
    "set_language",
    "t",
]
