"""Smoke tests for postcraftin core functionality."""

from postcraftin.config import OLLAMA_HOST, DEFAULT_MODEL
from postcraftin.generator import build_prompt


def test_config_defaults():
    """OLLAMA_HOST and DEFAULT_MODEL must be set to non-empty strings."""
    assert OLLAMA_HOST, "OLLAMA_HOST should not be empty"
    assert DEFAULT_MODEL, "DEFAULT_MODEL should not be empty"
    assert OLLAMA_HOST.startswith("http"), "OLLAMA_HOST should be an HTTP URL"


def test_build_prompt_contains_profile_fields():
    """build_prompt() output must contain the topic and key profile fields."""
    topic = "AI in data pipelines"
    profile = {
        "role": "Data Engineer",
        "audience": "Fachleute auf LinkedIn",
        "tonality": "professional",
        "keywords": ["AI", "data"],
    }
    result = build_prompt(topic, profile)
    assert topic in result
    assert profile["role"] in result
    assert profile["tonality"] in result
