# postcraft
🤖 AI-powered LinkedIn post generator using local LLMs via Ollama. Personalized ghostwriter with onboarding profile, Few-Shot prompting, and CLI interface.
