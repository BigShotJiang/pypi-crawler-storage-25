import json
from pathlib import Path

PROFILES_DIR = Path.home() / ".postcraftin" / "profiles"


def _ensure_dir() -> None:
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)


def save_profile(name: str, data: dict) -> None:
    _ensure_dir()
    path = PROFILES_DIR / f"{name}.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def load_profile(name: str) -> dict:
    path = PROFILES_DIR / f"{name}.json"
    if not path.exists():
        raise FileNotFoundError(f"Profile '{name}' not found at {path}")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def list_profiles() -> list[str]:
    _ensure_dir()
    return [p.stem for p in PROFILES_DIR.glob("*.json")]


def get_default_profile_name() -> str | None:
    profiles = list_profiles()
    return profiles[0] if profiles else None
