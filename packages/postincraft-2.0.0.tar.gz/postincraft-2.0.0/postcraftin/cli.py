import click
from rich.console import Console
from rich.table import Table

from postcraftin.config import DEFAULT_MODEL
from postcraftin.generator import generate_post
from postcraftin.onboarding import run_onboarding
from postcraftin.profile import list_profiles, load_profile, get_default_profile_name

console = Console()


@click.group()
def cli():
    """Postcraftin — AI-powered LinkedIn post generator."""
    pass


@cli.command()
@click.option("--name", default="default", show_default=True, help="Profile name to create.")
def onboard(name: str):
    """Run the interactive onboarding wizard to create a profile."""
    run_onboarding(name)


@cli.command()
@click.option("-t", "--topic", required=True, help="Topic for the LinkedIn post.")
@click.option("--length", "-l", "post_length", default="mittel",
              type=click.Choice(["kurz", "mittel", "lang"], case_sensitive=False),
              help="Post length: kurz (150-500 Zeichen), mittel (1.200-1.500 Zeichen), lang (1.900-2.500 Zeichen).")
@click.option("--profile", default=None, help="Profile name to use (default: first available).")
@click.option("--model", default=DEFAULT_MODEL, show_default=True, help="Ollama model to use.")
def generate(topic: str, post_length: str, profile: str | None, model: str):
    """Generate a LinkedIn post for a given topic."""
    profile_name = profile or get_default_profile_name()
    if not profile_name:
        console.print("[red]No profile found. Run 'postcraftin onboard' first.[/red]")
        raise SystemExit(1)
    try:
        profile_data = load_profile(profile_name)
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)

    console.print(f"[cyan]Generating post about:[/cyan] {topic}")
    console.print(f"[dim]Profile: {profile_name} | Model: {model} | Length: {post_length}[/dim]\n")
    generate_post(topic, profile_data, post_length=post_length, model=model)


@cli.command(name="list-profiles")
def list_profiles_cmd():
    """List all available profiles."""
    profiles = list_profiles()
    if not profiles:
        console.print("[yellow]No profiles found. Run 'postcraftin onboard' to create one.[/yellow]")
        return
    table = Table(title="postcraftin Profiles")
    table.add_column("Name", style="cyan")
    for p in profiles:
        table.add_row(p)
    console.print(table)


if __name__ == "__main__":
    cli()
