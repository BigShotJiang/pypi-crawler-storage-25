import json
import requests
from postcraftin.config import OLLAMA_HOST, DEFAULT_MODEL

POST_LENGTHS = {
    "kurz": {
        "zeichen": "150-500",
        "woerter": "25-85",
        "beschreibung": "Kurzer Post für schnelle Insights und Umfragen"
    },
    "mittel": {
        "zeichen": "1.200-1.500",
        "woerter": "200-260",
        "beschreibung": "Optimaler Bereich für höchstes Engagement"
    },
    "lang": {
        "zeichen": "1.900-2.500",
        "woerter": "320-425",
        "beschreibung": "Tiefergehende Analysen und Case Studies"
    }
}


def _build_few_shot_block(profile: dict) -> str:
    examples = profile.get("example_posts", [])
    if not examples:
        return ""
    block = "\n\nHier sind Beispiele meines Schreibstils:\n"
    for i, ex in enumerate(examples, 1):
        block += f"\n--- Beispiel {i} ---\n{ex}\n"
    return block


SYSTEM_PROMPT = (
    "Du bist ein professioneller LinkedIn-Content-Schreiber.\n"
    "- Antworte ausschließlich auf Deutsch.\n"
    "- Verwende KEINE Emojis, Emoticons oder Unicode-Symbole (wie ✨, 🚀, 💡, etc.).\n"
    "- Verwende keine englischen Begriffe oder Sätze.\n"
    "- Achte auf korrekte Rechtschreibung und Grammatik.\n"
    "- Schreibe in einem professionellen, seriösen Ton."
)


def build_prompt(topic: str, profile: dict, post_length: str = "mittel") -> str:
    role = profile.get("role", "Experte")
    audience = profile.get("audience", "Fachleute auf LinkedIn")
    tonality = profile.get("tonality", "inspirierend")
    keywords = ", ".join(profile.get("keywords", []))
    few_shot = _build_few_shot_block(profile)
    length_info = POST_LENGTHS.get(post_length.lower(), POST_LENGTHS["mittel"])

    prompt = (
        f"{SYSTEM_PROMPT}\n\n"
        f"Ich bin {role} und schreibe für {audience}.\n"
        f"Mein Tonfall ist: {tonality}.\n"
        f"Relevante Keywords: {keywords}.\n"
        f"{few_shot}\n\n"
        f"Schreibe jetzt einen professionellen LinkedIn-Post über das folgende Thema:\n"
        f"{topic}\n\n"
        f"Der Post soll ca. {length_info['zeichen']} Zeichen ({length_info['woerter']} Wörter) umfassen.\n"
        f"Er soll einen starken Hook in den ersten 210 Zeichen haben, klare Absätze und mit einem "
        f"Call-to-Action enden."
    )
    return prompt


def generate_post(topic: str, profile: dict, post_length: str = "mittel", model: str = DEFAULT_MODEL) -> None:
    user_prompt = build_prompt(topic, profile, post_length)
    payload = {
        "model": model,
        "system": SYSTEM_PROMPT,
        "prompt": user_prompt,
        "stream": True,
    }
    url = f"{OLLAMA_HOST}/api/generate"
    with requests.post(url, json=payload, stream=True, timeout=120) as resp:
        resp.raise_for_status()
        for line in resp.iter_lines():
            if line:
                chunk = json.loads(line)
                print(chunk.get("response", ""), end="", flush=True)
    print()
