import click
from postcraftin.profile import save_profile


def run_onboarding(profile_name: str) -> None:
    click.echo(click.style("\n🚀 Willkommen bei postcraftin Onboarding!", fg="cyan", bold=True))
    click.echo("Beantworte 5 kurze Fragen, um dein Profil zu erstellen.\n")

    # Schritt 1: Branche / Rolle
    click.echo(click.style("Schritt 1/5: Branche & Rolle", fg="yellow", bold=True))
    role = click.prompt("In welcher Branche/Rolle bist du tätig?", default="Software Engineer")

    # Schritt 2: Zielgruppe
    click.echo(click.style("\nSchritt 2/5: Zielgruppe", fg="yellow", bold=True))
    audience = click.prompt("Wen möchtest du mit deinen Posts erreichen?", default="Tech-Professionals auf LinkedIn")

    # Schritt 3: Tonality
    click.echo(click.style("\nSchritt 3/5: Tonality", fg="yellow", bold=True))
    tonality_choice = click.prompt(
        "Welchen Tonfall bevorzugst du?",
        type=click.Choice(["inspirierend", "sachlich", "provokativ"], case_sensitive=False),
        default="inspirierend",
    )

    # Schritt 4: Themen-Keywords
    click.echo(click.style("\nSchritt 4/5: Themen-Keywords", fg="yellow", bold=True))
    keywords_raw = click.prompt(
        "Nenne deine wichtigsten Themen-Keywords (kommagetrennt)",
        default="KI, Daten, Architektur",
    )
    keywords = [k.strip() for k in keywords_raw.split(",") if k.strip()]

    # Schritt 5: Beispiel-Posts
    click.echo(click.style("\nSchritt 5/5: Beispiel-Posts zur Stil-Kalibrierung", fg="yellow", bold=True))
    click.echo("Füge 2 Beispiel-Posts ein, die deinen Stil widerspiegeln.")
    click.echo("(Beende jeden Post mit einer Leerzeile + ENTER + 'END')")

    example_posts = []
    for i in range(1, 3):
        click.echo(click.style(f"\nBeispiel-Post {i}:", fg="green"))
        lines = []
        while True:
            line = input()
            if line.strip().upper() == "END":
                break
            lines.append(line)
        example_posts.append("\n".join(lines).strip())

    profile_data = {
        "role": role,
        "audience": audience,
        "tonality": tonality_choice,
        "keywords": keywords,
        "example_posts": example_posts,
    }

    save_profile(profile_name, profile_data)
    click.echo(click.style(f"\n✅ Profil '{profile_name}' wurde gespeichert!", fg="green", bold=True))
