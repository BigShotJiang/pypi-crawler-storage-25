"""Tests for ``advisor.cost`` — token & dollar estimates."""

from __future__ import annotations

from pathlib import Path

import advisor.cost as cost
from advisor.cost import CostEstimate, estimate_cost, format_estimate, load_pricing
from advisor.focus import FocusTask


def _task(path: str, priority: int = 3) -> FocusTask:
    return FocusTask(file_path=path, priority=priority, prompt="")


class TestEstimateCost:
    def test_estimate_returns_range(self, tmp_path: Path) -> None:
        p = tmp_path / "a.py"
        p.write_text("x" * 4000)
        e = estimate_cost(
            [_task(str(p))],
            None,
            advisor_model="opus",
            runner_model="sonnet",
            max_fixes_per_runner=5,
        )
        assert isinstance(e, CostEstimate)
        assert e.cost_usd_min <= e.cost_usd_max
        assert e.input_tokens_min <= e.input_tokens_max
        assert e.output_tokens_min <= e.output_tokens_max

    def test_missing_file_tokens_zero(self, tmp_path: Path) -> None:
        e = estimate_cost(
            [_task(str(tmp_path / "missing.py"))],
            None,
            advisor_model="opus",
            runner_model="sonnet",
            max_fixes_per_runner=5,
        )
        assert e.cost_usd_min >= 0.0

    def test_negative_max_fixes_per_runner_rejected(self, tmp_path: Path) -> None:
        """The CLI / config layer floors at ``>=1`` before reaching the
        estimator, but a direct API caller could otherwise pass a
        negative cap that silently clamped to 0 via the existing
        ``max(0, ...)`` at the fix-rounds line. Reject explicitly so
        the misconfiguration is visible."""
        import pytest as _pytest

        with _pytest.raises(ValueError, match="must be >= 0"):
            estimate_cost(
                [_task(str(tmp_path / "f.py"))],
                None,
                advisor_model="opus",
                runner_model="sonnet",
                max_fixes_per_runner=-3,
            )

    def test_zero_max_fixes_accepted(self, tmp_path: Path) -> None:
        """``0`` legitimately means "no fix wave"; not negative."""
        (tmp_path / "f.py").write_text("x" * 200)
        e = estimate_cost(
            [_task(str(tmp_path / "f.py"))],
            None,
            advisor_model="opus",
            runner_model="sonnet",
            max_fixes_per_runner=0,
        )
        # MIN and MAX both reflect "no fixes" — equal cost is the
        # expected behavior, NOT a bug.
        assert e.cost_usd_min == e.cost_usd_max

    def test_opus_costs_more_than_sonnet(self, tmp_path: Path) -> None:
        (tmp_path / "f.py").write_text("x" * 2000)
        cheap = estimate_cost(
            [_task(str(tmp_path / "f.py"))],
            None,
            advisor_model="sonnet",
            runner_model="haiku",
            max_fixes_per_runner=5,
        )
        pricey = estimate_cost(
            [_task(str(tmp_path / "f.py"))],
            None,
            advisor_model="opus",
            runner_model="opus",
            max_fixes_per_runner=5,
        )
        assert pricey.cost_usd_max > cheap.cost_usd_max

    def test_format_estimate_contains_dollars(self, tmp_path: Path) -> None:
        (tmp_path / "f.py").write_text("x" * 500)
        e = estimate_cost(
            [_task(str(tmp_path / "f.py"))],
            None,
            advisor_model="opus",
            runner_model="sonnet",
            max_fixes_per_runner=5,
        )
        s = format_estimate(e)
        assert "$" in s
        assert "Cost estimate" in s

    def test_to_dict_roundtrip(self, tmp_path: Path) -> None:
        (tmp_path / "f.py").write_text("x" * 500)
        e = estimate_cost(
            [_task(str(tmp_path / "f.py"))],
            None,
            advisor_model="opus",
            runner_model="sonnet",
            max_fixes_per_runner=5,
        )
        d = e.to_dict()
        assert d["file_count"] == 1
        assert d["advisor_model"] == "opus"

    def test_max_runners_limits_unbatched_estimate(self, tmp_path: Path) -> None:
        tasks = []
        for i in range(8):
            p = tmp_path / f"f{i}.py"
            p.write_text("x" * 100)
            tasks.append(_task(str(p)))

        e = estimate_cost(
            tasks,
            None,
            advisor_model="opus",
            runner_model="sonnet",
            max_fixes_per_runner=5,
            max_runners=2,
        )

        assert e.runner_count == 2

    def test_batches_still_determine_runner_count(self, tmp_path: Path) -> None:
        from advisor.focus import FocusBatch

        tasks = [_task(str(tmp_path / f"f{i}.py")) for i in range(3)]
        batches = [
            FocusBatch(batch_id=1, tasks=(tasks[0],), complexity="low"),
            FocusBatch(batch_id=2, tasks=(tasks[1], tasks[2]), complexity="low"),
        ]

        e = estimate_cost(
            tasks,
            batches,
            advisor_model="opus",
            runner_model="sonnet",
            max_fixes_per_runner=5,
            max_runners=9,
        )

        assert e.runner_count == 2

    def test_duplicate_tasks_only_stat_once_per_estimate(self, tmp_path: Path, monkeypatch) -> None:
        p = tmp_path / "dup.py"
        p.write_text("x" * 100)
        calls = 0
        real_stat = cost.os.stat

        def counting_stat(path):
            nonlocal calls
            calls += 1
            return real_stat(path)

        monkeypatch.setattr(cost.os, "stat", counting_stat)

        estimate_cost(
            [_task(str(p)), _task(str(p))],
            None,
            advisor_model="opus",
            runner_model="sonnet",
            max_fixes_per_runner=5,
        )

        assert calls == 1

    def test_stat_cache_invalidates_when_file_changes(self, tmp_path: Path) -> None:
        p = tmp_path / "changing.py"
        p.write_text("x" * 35)
        first = cost._tokens_for_file(str(p))
        p.write_text("x" * 3500)

        assert cost._tokens_for_file(str(p)) > first


class TestLoadPricing:
    """``load_pricing`` parses both object and array shapes."""

    def test_object_shape(self, tmp_path: Path) -> None:
        import json

        p = tmp_path / "pricing.json"
        p.write_text(
            json.dumps(
                {
                    "opus": {"input": 2000, "output": 8000},
                    "sonnet": {"input": 400, "output": 2000},
                    "haiku": {"input": 120, "output": 600},
                }
            )
        )
        pricing = load_pricing(p)
        assert pricing == {
            "opus": (2000, 8000),
            "sonnet": (400, 2000),
            "haiku": (120, 600),
        }

    def test_array_shape(self, tmp_path: Path) -> None:
        import json

        p = tmp_path / "pricing.json"
        p.write_text(
            json.dumps(
                {
                    "opus": [1500, 7500],
                    "sonnet": [300, 1500],
                    "haiku": [100, 500],
                }
            )
        )
        pricing = load_pricing(p)
        assert pricing["opus"] == (1500, 7500)

    def test_missing_family_raises(self, tmp_path: Path) -> None:
        import json

        import pytest

        p = tmp_path / "pricing.json"
        p.write_text(json.dumps({"opus": [1, 1], "sonnet": [1, 1]}))
        with pytest.raises(ValueError, match="haiku"):
            load_pricing(p)

    def test_bad_json_raises(self, tmp_path: Path) -> None:
        import pytest

        p = tmp_path / "pricing.json"
        p.write_text("not json at all")
        with pytest.raises(ValueError, match="not valid JSON"):
            load_pricing(p)

    def test_negative_cents_raises(self, tmp_path: Path) -> None:
        import json

        import pytest

        p = tmp_path / "pricing.json"
        p.write_text(
            json.dumps(
                {
                    "opus": [-1, 1],
                    "sonnet": [1, 1],
                    "haiku": [1, 1],
                }
            )
        )
        with pytest.raises(ValueError, match="non-negative"):
            load_pricing(p)

    def test_pricing_threads_into_estimate(self, tmp_path: Path) -> None:
        import json

        (tmp_path / "f.py").write_text("x" * 2000)
        pricing = {
            "opus": (1, 1),
            "sonnet": (1, 1),
            "haiku": (1, 1),
        }
        cheap = estimate_cost(
            [_task(str(tmp_path / "f.py"))],
            None,
            advisor_model="opus",
            runner_model="opus",
            max_fixes_per_runner=5,
            pricing=pricing,
        )
        # Also check the file-loading round trip produces the same estimate.
        file_path = tmp_path / "pricing.json"
        file_path.write_text(
            json.dumps(
                {
                    "opus": list(pricing["opus"]),
                    "sonnet": list(pricing["sonnet"]),
                    "haiku": list(pricing["haiku"]),
                }
            )
        )
        loaded = load_pricing(file_path)
        same = estimate_cost(
            [_task(str(tmp_path / "f.py"))],
            None,
            advisor_model="opus",
            runner_model="opus",
            max_fixes_per_runner=5,
            pricing=loaded,
        )
        assert cheap.cost_usd_max == same.cost_usd_max


class TestPricingFreshness:
    """B2 — surface snapshot date + warn on stale defaults."""

    def test_pricing_as_of_exported(self) -> None:
        """``PRICING_AS_OF`` is part of the public surface so embedders can
        display the snapshot date in their own UI without reaching into
        ``advisor.cost``."""
        import advisor

        assert advisor.PRICING_AS_OF == cost.PRICING_AS_OF
        assert "PRICING_AS_OF" in advisor.__all__

    def test_format_estimate_surfaces_pricing_as_of(self, tmp_path: Path) -> None:
        (tmp_path / "f.py").write_text("x" * 500)
        e = estimate_cost(
            [_task(str(tmp_path / "f.py"))],
            None,
            advisor_model="opus",
            runner_model="sonnet",
            max_fixes_per_runner=5,
        )
        rendered = format_estimate(e)
        assert cost.PRICING_AS_OF.isoformat() in rendered
        assert "anthropic.com/pricing" in rendered

    def test_stale_pricing_warning_emitted(self, tmp_path: Path, monkeypatch) -> None:
        """Default pricing older than the stale threshold triggers a one-shot
        ``UserWarning``. Resets the module-level dedup flag so the test
        doesn't depend on test-order side effects from earlier estimates."""
        import datetime as _dt

        import pytest as _pytest

        (tmp_path / "f.py").write_text("x" * 200)
        monkeypatch.setattr(cost, "PRICING_AS_OF", _dt.date(2000, 1, 1))
        monkeypatch.setattr(cost, "_stale_pricing_warned", False)

        with _pytest.warns(UserWarning, match="default pricing table is stale"):
            estimate_cost(
                [_task(str(tmp_path / "f.py"))],
                None,
                advisor_model="opus",
                runner_model="sonnet",
                max_fixes_per_runner=1,
            )

    def test_stale_pricing_warning_silenced_when_pricing_override(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """A caller-supplied ``pricing=`` is an explicit opt-out from the
        default table — staleness of the default is irrelevant and the
        advisory must not fire."""
        import datetime as _dt
        import warnings as _warnings

        (tmp_path / "f.py").write_text("x" * 200)
        monkeypatch.setattr(cost, "PRICING_AS_OF", _dt.date(2000, 1, 1))
        monkeypatch.setattr(cost, "_stale_pricing_warned", False)

        with _warnings.catch_warnings(record=True) as caught:
            _warnings.simplefilter("always")
            estimate_cost(
                [_task(str(tmp_path / "f.py"))],
                None,
                advisor_model="opus",
                runner_model="sonnet",
                max_fixes_per_runner=1,
                pricing={"opus": (1, 1), "sonnet": (1, 1), "haiku": (1, 1)},
            )
        stale = [w for w in caught if "stale" in str(w.message)]
        assert not stale, (
            f"unexpected stale-pricing warning when pricing= override supplied: {stale}"
        )


class TestPricingValueShapeValidation:
    """B3 — ``estimate_cost`` validates ``pricing=`` value shapes
    symmetrically with ``load_pricing``, so direct-API callers get a
    clear ValueError at the boundary instead of a cryptic unpack error
    deep inside the pricing lookup."""

    def _good_other_two(self) -> dict[str, tuple[int, int]]:
        return {"sonnet": (1, 1), "haiku": (1, 1)}

    def test_short_tuple_rejected(self, tmp_path: Path) -> None:
        import pytest as _pytest

        (tmp_path / "f.py").write_text("x")
        bad = {"opus": (1500,), **self._good_other_two()}
        with _pytest.raises(ValueError, match="must be a 2-tuple"):
            estimate_cost(
                [_task(str(tmp_path / "f.py"))],
                None,
                advisor_model="opus",
                runner_model="sonnet",
                max_fixes_per_runner=1,
                pricing=bad,  # type: ignore[arg-type]
            )

    def test_string_value_rejected(self, tmp_path: Path) -> None:
        import pytest as _pytest

        (tmp_path / "f.py").write_text("x")
        bad = {"opus": "1500/7500", **self._good_other_two()}
        with _pytest.raises(ValueError, match="must be a 2-tuple"):
            estimate_cost(
                [_task(str(tmp_path / "f.py"))],
                None,
                advisor_model="opus",
                runner_model="sonnet",
                max_fixes_per_runner=1,
                pricing=bad,  # type: ignore[arg-type]
            )

    def test_three_tuple_rejected(self, tmp_path: Path) -> None:
        import pytest as _pytest

        (tmp_path / "f.py").write_text("x")
        bad = {"opus": (1500, 7500, 0), **self._good_other_two()}
        with _pytest.raises(ValueError, match="must be a 2-tuple"):
            estimate_cost(
                [_task(str(tmp_path / "f.py"))],
                None,
                advisor_model="opus",
                runner_model="sonnet",
                max_fixes_per_runner=1,
                pricing=bad,  # type: ignore[arg-type]
            )

    def test_non_integer_cents_rejected(self, tmp_path: Path) -> None:
        import pytest as _pytest

        (tmp_path / "f.py").write_text("x")
        bad = {"opus": (1500.5, 7500), **self._good_other_two()}
        with _pytest.raises(ValueError, match="must be an integer"):
            estimate_cost(
                [_task(str(tmp_path / "f.py"))],
                None,
                advisor_model="opus",
                runner_model="sonnet",
                max_fixes_per_runner=1,
                pricing=bad,  # type: ignore[arg-type]
            )

    def test_negative_cents_rejected(self, tmp_path: Path) -> None:
        import pytest as _pytest

        (tmp_path / "f.py").write_text("x")
        bad = {"opus": (-1, 7500), **self._good_other_two()}
        with _pytest.raises(ValueError, match="non-negative"):
            estimate_cost(
                [_task(str(tmp_path / "f.py"))],
                None,
                advisor_model="opus",
                runner_model="sonnet",
                max_fixes_per_runner=1,
                pricing=bad,
            )
