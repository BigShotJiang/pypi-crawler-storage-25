"""Advisor tool pattern — native Claude Code implementation.

This project uses Claude Code's Agent tool to replicate the Anthropic API
advisor pattern. See CLAUDE.md for the workflow protocol.

Public surface (grouped by intent — see ``__all__`` below for the full list):

  Core building blocks
    rank        — Priority-rank files by likelihood of containing issues
    focus       — Batched file review for parallel analysis
    verify      — Verification pass to filter noise from findings
    orchestrate — Team config, prompt builders, dispatch message specs

  Findings lifecycle
    history       — Persist confirmed findings across runs
    baseline      — Snapshot-and-compare for accepted-noise workflows
    suppressions  — Per-rule, per-file gate with expiry
    checkpoint    — Resume an interrupted dispatch plan

  Output sinks
    sarif       — SARIF 2.1.0 emitter for Code Scanning
    pr_comment  — GitHub-flavored PR body formatter
    cost        — Token / dollar estimator

  Operator tools (advisor-implementation territory — most users won't touch)
    runner_budget — Char-budget + scope-anchor primitives for live runners
    audit         — Post-hoc transcript analyser
    presets       — Curated rule-pack bundles
    git_scope     — ``--since`` / ``--staged`` / ``--base`` resolver
    install       — One-shot CLAUDE.md + skill wiring
    doctor        — Setup diagnostics
    skill_asset   — Bundled SKILL.md content

Modules prefixed with ``_`` (``_fs``, ``_style``, ``_version``) are
internal helpers and are not exported.
"""

from ._style import strip_ansi
from ._version import resolve_version as _resolve_version

__version__ = _resolve_version()

from .audit import (
    AuditReport,
    audit_to_dict,
    audit_transcript,
    format_audit_report,
)
from .baseline import (
    BaselineDiff,
    BaselineEntry,
    diff_against_baseline,
    filter_against_baseline,
    findings_to_entries,
    read_baseline,
    write_baseline,
)
from .checkpoint import (
    CHECKPOINT_SCHEMA_VERSION,
    Checkpoint,
    checkpoint_path,
    list_checkpoints,
    load_checkpoint,
    save_checkpoint,
)
from .cost import PRICING_AS_OF, CostEstimate, estimate_cost, format_estimate, load_pricing
from .doctor import DoctorReport, run_doctor
from .focus import (
    FocusBatch,
    FocusTask,
    create_focus_batches,
    create_focus_tasks,
    format_batch_plan,
    format_dispatch_plan,
)
from .git_scope import GitScopeError, resolve_git_scope
from .history import (
    HISTORY_SCHEMA_VERSION,
    HistoryEntry,
    append_entries,
    entry_now,
    file_repeat_counts,
    file_repeat_scores,
    format_history_block,
    history_path,
    load_recent,
    load_recent_findings,
    new_run_id,
)
from .install import (
    ComponentStatus,
    InstallAction,
    InstallResult,
    Status,
    apply_nudge,
    ensure_nudge,
    get_installed_skill_version,
    install,
    install_skill,
    install_update_skill,
    parse_badge,
    remove_nudge,
    render_block,
    should_auto_nudge,
    status,
    uninstall,
    uninstall_skill,
    uninstall_update_skill,
)
from .orchestrate import (
    KNOWN_MODEL_SHORTCUTS,
    TeamConfig,
    build_advisor_agent,
    build_advisor_prompt,
    build_fix_assignment_message,
    build_runner_agents,
    build_runner_batch_message,
    build_runner_dispatch_messages,
    build_runner_handoff_message,
    build_runner_pool_agents,
    build_runner_pool_prompt,
    build_runner_prompt,
    build_verify_dispatch_prompt,
    build_verify_message,
    check_batch_fix_budget,
    default_team_config,
    is_known_model,
    render_pipeline,
)
from .pr_comment import format_pr_comment
from .presets import PRESETS, RulePack, get_preset, list_presets
from .rank import (
    CONTENT_SCAN_LIMIT,
    LANGUAGE_EXTRA_KEYWORDS,
    PRIORITY_KEYWORDS,
    RankedFile,
    language_for_path,
    load_advisorignore,
    rank_files,
    rank_to_prompt,
)
from .runner_budget import (
    DEFAULT_CHAR_CEILING,
    DEFAULT_FILE_READ_CEILING,
    ROTATE_FRACTION,
    SCOPE_STAGES,
    SOFT_WARN_FRACTION,
    RunnerBudget,
    ScopeAnchor,
    budget_status,
    format_budget_nudge,
    new_budget,
    normalize_batch_files,
    out_of_batch,
    parse_scope_anchor,
    stage_regressed,
    update_budget,
)
from .sarif import (
    SARIF_SCHEMA_URI,
    SARIF_VERSION,
    findings_to_sarif,
    synthesize_rule_id,
)
from .skill_asset import SKILL_MD, SKILL_MD_UPDATE
from .suppressions import Suppression, apply_suppressions, load_suppressions
from .verify import (
    Finding,
    build_verify_prompt,
    format_findings_block,
    parse_findings_from_text,
    parse_findings_with_drift,
)

__all__ = [
    # version
    "__version__",
    # rank
    "CONTENT_SCAN_LIMIT",
    "LANGUAGE_EXTRA_KEYWORDS",
    "PRIORITY_KEYWORDS",
    "RankedFile",
    "language_for_path",
    "load_advisorignore",
    "rank_files",
    "rank_to_prompt",
    # focus
    "FocusBatch",
    "FocusTask",
    "create_focus_batches",
    "create_focus_tasks",
    "format_batch_plan",
    "format_dispatch_plan",
    # verify
    "Finding",
    "build_verify_prompt",
    "format_findings_block",
    "parse_findings_from_text",
    "parse_findings_with_drift",
    # orchestrate
    "KNOWN_MODEL_SHORTCUTS",
    "TeamConfig",
    "default_team_config",
    "is_known_model",
    "build_advisor_agent",
    "build_advisor_prompt",
    "build_fix_assignment_message",
    "build_runner_agents",
    "build_runner_batch_message",
    "build_runner_dispatch_messages",
    "build_runner_handoff_message",
    "build_runner_pool_agents",
    "build_runner_pool_prompt",
    "build_runner_prompt",
    "build_verify_dispatch_prompt",
    "build_verify_message",
    "check_batch_fix_budget",
    "render_pipeline",
    # install
    "ComponentStatus",
    "InstallAction",
    "InstallResult",
    "Status",
    "apply_nudge",
    "ensure_nudge",
    "get_installed_skill_version",
    "install",
    "install_skill",
    "install_update_skill",
    "parse_badge",
    "remove_nudge",
    "render_block",
    "should_auto_nudge",
    "status",
    "uninstall",
    "uninstall_skill",
    "uninstall_update_skill",
    # git scope
    "GitScopeError",
    "resolve_git_scope",
    # cost
    "CostEstimate",
    "PRICING_AS_OF",
    "estimate_cost",
    "format_estimate",
    "load_pricing",
    # doctor
    "DoctorReport",
    "run_doctor",
    # history
    "HISTORY_SCHEMA_VERSION",
    "HistoryEntry",
    "append_entries",
    "entry_now",
    "file_repeat_counts",
    "file_repeat_scores",
    "format_history_block",
    "history_path",
    "load_recent",
    "load_recent_findings",
    "new_run_id",
    # checkpoint
    "CHECKPOINT_SCHEMA_VERSION",
    "Checkpoint",
    "checkpoint_path",
    "list_checkpoints",
    "load_checkpoint",
    "save_checkpoint",
    # audit
    "AuditReport",
    "audit_to_dict",
    "audit_transcript",
    "format_audit_report",
    # presets
    "PRESETS",
    "RulePack",
    "get_preset",
    "list_presets",
    # sarif
    "SARIF_SCHEMA_URI",
    "SARIF_VERSION",
    "findings_to_sarif",
    "synthesize_rule_id",
    # baseline
    "BaselineDiff",
    "BaselineEntry",
    "diff_against_baseline",
    "filter_against_baseline",
    "findings_to_entries",
    "read_baseline",
    "write_baseline",
    # suppressions
    "Suppression",
    "apply_suppressions",
    "load_suppressions",
    # pr comment
    "format_pr_comment",
    # runner budget / scope anchor
    "DEFAULT_CHAR_CEILING",
    "DEFAULT_FILE_READ_CEILING",
    "ROTATE_FRACTION",
    "SCOPE_STAGES",
    "SOFT_WARN_FRACTION",
    "RunnerBudget",
    "ScopeAnchor",
    "budget_status",
    "format_budget_nudge",
    "new_budget",
    "normalize_batch_files",
    "out_of_batch",
    "parse_scope_anchor",
    "stage_regressed",
    "update_budget",
    # skill asset
    "SKILL_MD",
    "SKILL_MD_UPDATE",
    # style helpers (terminal output sanitization)
    "strip_ansi",
]
