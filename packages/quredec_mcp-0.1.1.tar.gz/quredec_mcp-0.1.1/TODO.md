# QuReDec_MCP — TODO

Carried-forward items, ordered by what unblocks the public launch.

## Phase 0 backend status

Phase 0 deployed to `quredec.com` on 2026-04-28. Canary gate
(`MCP_API_ALLOWLIST`) lifted on 2026-04-30 — the public REST API is now
generally available on every paid QuReDec account.

## Pre-launch checklist

- [x] **Run `scripts/integration_test.py` against `quredec.com`** — DONE
      2026-04-30. Submitted a real brief, polled to `completed`,
      verified all schema fields (3 facts, 29 citations, confidence 0.7,
      152 s end-to-end). View: `https://quredec.com/shared/brief/20589d5c-fc55-46a0-a838-c23456c33400/3a1eb7fe4b0c7d53`.
- [ ] Push this branch to the `Advanced-Binary-Operations/QuReDec_MCP`
      GitHub repo (currently private with the initial-commit scaffold
      from 2026-04-27).
- [ ] Flip the GitHub repo visibility to public.
- [ ] Publish the `quredec-mcp` package to PyPI so
      `registryType: pypi` / `identifier: quredec-mcp` resolves.
      Currently `pip install quredec-mcp` would 404. Local
      `python -m build` produces clean sdist + wheel; `twine check`
      passes both.
- [ ] Submit `server.json` to the Anthropic MCP Registry via PR
      against `modelcontextprotocol/registry`. Schema is already
      validated against `https://static.modelcontextprotocol.io/schemas/2025-12-11/server.schema.json`.

## Post-launch deferred

- [ ] If live API ever exposes user-friendly mode names, re-add `mode` to
      the `decision_brief` MCP tool surface. Currently dropped because the
      live API takes opaque `A|B|C` pipeline labels with no product-friendly
      mapping.
- [ ] Consider a `wait_for_completion=False` tool variant that uses
      MCP progress notifications (`Context.report_progress`) instead of a
      single blocking call, for clients that prefer streaming.
- [ ] Prometheus / OTEL metrics on the client (request count, p50/p95
      latency, 429-back-off depth) — useful once we have any volume.

## Coordination notes (no work here)

- The launch post drafts at `PRIOS_V5/docs/business_ideas/2026-04-26_mcp_launch_posts.md`
  reportedly contain "share URL goes into your team channel" wording. That
  file is owned by the business-ideas thread; flag here per the hard-gate
  scope rule. **Do not edit it from this thread.** The QuReDec product is
  an individual-user surface (claims-review §10) so any team/Slack/shared-
  workspace language must be removed before publication, but the removal
  belongs to the thread that owns the draft.

- `QuReDec_MCP/` itself was scrubbed of forbidden wording in this thread:
  `grep -ri "slack\|team\|workspace\|shared\|channel\|colleagues\|multi-user\|teammate"`
  returns only the `/shared/brief/...` URL path (live API route name, not
  workspace wording). Keep clean on subsequent commits.
