"""QuReDec MCP server — decision-brief tools for MCP clients.

Run with `quredec-mcp` (after `pip install -e .`) or `python -m quredec_mcp.server`.

Auth: set `QUREDEC_API_KEY` (generate one at https://quredec.com/account).
Dev:  set `QUREDEC_MOCK=1` to run against an in-process mock — no network,
      no key required. The mock mirrors the live brief schema field-for-field.
"""

from __future__ import annotations

from typing import Any

from mcp.server.fastmcp import FastMCP

from .client import (
    DEFAULT_POLL_TIMEOUT_S,
    TERMINAL_STATUSES,
    BriefStatus,
    BriefSubmission,
    QuReDecClient,
    QuReDecError,
)

mcp = FastMCP("quredec")


def _client() -> QuReDecClient:
    return QuReDecClient()


def _serialize_status(status: BriefStatus) -> dict[str, Any]:
    return {
        "brief_run_id": status.brief_run_id,
        "status": status.status,
        "progress": status.progress,
        "brief": status.brief,
        "public_share_url": status.public_share_url,
        "created_at": status.created_at,
    }


def _serialize_submission(submission: BriefSubmission) -> dict[str, Any]:
    return {
        "brief_run_id": submission.brief_run_id,
        "status_url": submission.status_url,
        "public_share_url": submission.public_share_url,
        "credits_remaining": submission.credits_remaining,
    }


@mcp.tool()
def decision_brief(
    question: str,
    links: list[str] | None = None,
    template_key: str | None = None,
    wait_for_completion: bool = True,
    timeout_seconds: float = DEFAULT_POLL_TIMEOUT_S,
) -> dict[str, Any]:
    """Generate a structured, evidence-backed decision brief for a question.

    Use this when the user asks for a recommendation, comparison, vendor pick,
    architecture decision, hire/no-hire call, build-vs-buy analysis, or any
    "what should I do about X" question that benefits from cited evidence.

    The completed brief contains:
      - executive_summary    — short prose framing the decision
      - recommendation       — single-line direction
      - confidence           — float 0..1
      - key_facts[]          — {text, citation_ids[]}
      - implications[]       — {text, citation_ids[]}
      - actions[]            — {text, effort, impact}
      - risks[]              — {text, severity, citation_ids[]}
      - citations[]          — {citation_id, title, url, source_type}

    Args:
        question: The decision question. Be specific (e.g. "Should we migrate
            our $50K/yr Stripe billing to LemonSqueezy given EU VAT changes
            in 2026?"). Minimum 10 characters.
        links: Optional URLs to seed the evidence pool (docs, RFCs, vendor
            pages, transcripts). Up to 10 entries.
        template_key: Optional domain template, e.g. "pharma_process_change".
            Defaults to the generic decision template.
        wait_for_completion: If True (default), block and poll until the brief
            is complete or `timeout_seconds` elapses, then return the full brief.
            If False, return immediately with a brief_run_id to poll separately.
        timeout_seconds: Max seconds to wait when wait_for_completion=True.
            Defaults to 600s (10 min). Briefs typically take 2-5 minutes.
            On timeout the brief is still being generated server-side; poll
            get_brief_status with the brief_run_id to retrieve it.

    Returns:
        When complete:  {brief_run_id, status: "completed" | "partial",
                         progress: 100, brief: {...}, public_share_url,
                         created_at}.
        When in flight: {brief_run_id, status: "queued" | "running",
                         progress, status_url, public_share_url}.
        On error:       {error: "<actionable message>"}.

    Errors a caller may see:
      - "Your QuReDec API key is missing or invalid..." — set QUREDEC_API_KEY.
      - "Your QuReDec credits are used up..." — top up at quredec.com/account.
      - "Question must be at least 10 characters." — rephrase.
    """
    try:
        client = _client()
        if wait_for_completion:
            submission, status = client.submit_and_wait(
                question=question,
                links=links,
                template_key=template_key,
                timeout_s=timeout_seconds,
            )
            payload = _serialize_status(status)
            payload["status_url"] = submission.status_url
            payload["credits_remaining"] = submission.credits_remaining
            if status.status not in TERMINAL_STATUSES:
                payload["next_step"] = (
                    f"Brief is still {status.status} after {timeout_seconds:.0f}s. "
                    f"Call get_brief_status(brief_run_id='{submission.brief_run_id}') "
                    "to retry — briefs can take up to 5 minutes."
                )
            return payload
        submission = client.submit_brief(
            question=question, links=links, template_key=template_key,
        )
        return {
            **_serialize_submission(submission),
            "status": "queued",
            "next_step": (
                f"Call get_brief_status(brief_run_id='{submission.brief_run_id}') "
                "to poll. Briefs typically complete in 2-5 minutes."
            ),
        }
    except QuReDecError as exc:
        return {"error": str(exc)}


@mcp.tool()
def get_brief_status(brief_run_id: str) -> dict[str, Any]:
    """Check status of a previously submitted decision brief by its ID.

    Use this to poll an in-flight brief, retrieve the full brief once complete,
    or re-fetch a previously generated brief by ID.

    Args:
        brief_run_id: The brief_run_id returned from decision_brief().

    Returns:
        {brief_run_id, status, progress, brief?, public_share_url?, created_at}.
        status is one of: queued | running | partial | completed | failed.
        `partial` means some evidence layers timed out but a usable brief was
        still synthesized; the `brief` payload is populated as for `completed`.
    """
    try:
        client = _client()
        return _serialize_status(client.get_brief(brief_run_id))
    except QuReDecError as exc:
        return {"error": str(exc)}


@mcp.tool()
def list_recent_briefs(limit: int = 20) -> dict[str, Any]:
    """List the caller's most recent decision briefs.

    Use this to find a prior brief by id, share an old brief again, or check
    what decisions have been logged for this account.

    Args:
        limit: Max briefs to return (default 20, valid range 1-100).

    Returns:
        {items: [{brief_run_id, status, progress, status_url,
                  public_share_url, created_at}, ...], count}.
    """
    try:
        client = _client()
        capped = max(1, min(limit, 100))
        items = client.list_briefs(limit=capped)
        return {"items": items, "count": len(items)}
    except QuReDecError as exc:
        return {"error": str(exc)}


def main() -> None:
    """Entry point for the `quredec-mcp` console script."""
    mcp.run()


if __name__ == "__main__":
    main()
