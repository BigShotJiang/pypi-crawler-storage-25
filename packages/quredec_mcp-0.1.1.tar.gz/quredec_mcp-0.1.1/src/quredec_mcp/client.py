"""HTTP client for the QuReDec public API.

Talks to the per-user Bearer-token surface at `https://quredec.com/api/v1/brief*`
(QuReDec roadmap §12.6 / Phase 0). Set `QUREDEC_MOCK=1` for offline development —
this short-circuits all HTTP and returns a fixture that matches the live
schema exactly, so server-side tools can be unit-tested without network.

Live API contract (mirrored at `PRIOS_V5/docs/API.md` in the QuReDec repo):

    POST /api/v1/brief
        body: {question, links?, mode?, template_key?}
        200 -> {brief_run_id, status: "queued", status_url, public_share_url, credits_remaining}
        400/401/402/404/429/503 with {error, message}

    GET  /api/v1/brief/{run_id}
        200 -> {brief_run_id, status, progress, status_url, public_share_url, created_at, brief?}
        Statuses: queued | running | partial | completed | failed.
        `brief` is populated when status is `completed` or `partial`.

    GET  /api/v1/brief?limit=N
        200 -> {items: [...], count: N}
"""

from __future__ import annotations

import logging
import os
import random
import time
from dataclasses import dataclass
from typing import Any

import httpx

DEFAULT_BASE_URL = "https://quredec.com"

# Per the live contract: briefs typically take 2–5 minutes. Poll at 15s with
# exponential back-off on 429; cap timeout at 10 minutes.
DEFAULT_POLL_INTERVAL_S = 15.0
DEFAULT_POLL_TIMEOUT_S = 600.0
MAX_POLL_INTERVAL_S = 60.0

# Statuses that signal the pipeline has stopped progressing. `partial` is a
# real terminal state on QuReDec — it means some evidence layers timed out
# but a brief was still synthesized; the response carries a `brief` payload.
TERMINAL_STATUSES = frozenset({"completed", "partial", "failed"})

# Standardized error messages — surface these unchanged so the MCP server
# can pass them straight to the LLM client. Phrasing matches §12.6 contract.
ERR_UNAUTHORIZED = (
    "Your QuReDec API key is missing or invalid. "
    "Generate one at https://quredec.com/account."
)
ERR_NO_CREDITS = (
    "Your QuReDec credits are used up. "
    "Add credits at https://quredec.com/account."
)

log = logging.getLogger(__name__)


class QuReDecError(Exception):
    """Raised for any non-2xx response from the QuReDec API."""


@dataclass
class BriefSubmission:
    brief_run_id: str
    status_url: str
    public_share_url: str | None
    credits_remaining: int | None


@dataclass
class BriefStatus:
    brief_run_id: str
    status: str  # queued | running | partial | completed | failed
    progress: int  # 0-100, integer percent (per live API)
    brief: dict[str, Any] | None  # populated when status in {completed, partial}
    public_share_url: str | None
    created_at: str | None


# ---------------------------------------------------------------------------
# Mock fixture — mirrors the live brief schema field-for-field. Update both
# in lockstep when the live contract evolves.
# ---------------------------------------------------------------------------

_MOCK_RUN_ID = "mock-run-001"

_MOCK_BRIEF_OBJECT: dict[str, Any] = {
    "executive_summary": (
        "Stripe remains the lower-risk choice for a $50K/yr subscription business "
        "with EU customers. LemonSqueezy's Merchant-of-Record model removes VAT "
        "burden but adds 5% + $0.50/tx, eroding margin at this volume."
    ),
    "recommendation": "Stay on Stripe; add Stripe Tax for EU VAT.",
    "confidence": 0.78,
    "key_facts": [
        {
            "text": "Stripe Tax handles EU VAT/GST natively at 0.5% per transaction.",
            "citation_ids": ["1"],
        },
        {
            "text": "LemonSqueezy is Merchant-of-Record; pricing is 5% + $0.50/tx.",
            "citation_ids": ["2"],
        },
    ],
    "implications": [
        {
            "text": "At $50K ARR, LemonSqueezy fees would exceed Stripe Tax + Stripe by ~$2,200/yr.",
            "citation_ids": ["1", "2"],
        }
    ],
    "actions": [
        {
            "text": "Enable Stripe Tax in dashboard; backfill historical VAT for last 12 months.",
            "effort": "low",
            "impact": "high",
        }
    ],
    "risks": [
        {
            "text": "Stripe Tax only handles indirect tax, not income tax. Operator still files corporate returns.",
            "severity": "low",
            "citation_ids": ["1"],
        }
    ],
    "citations": [
        {
            "citation_id": "1",
            "title": "Stripe Tax — automatic EU VAT collection",
            "url": "https://stripe.com/tax",
            "source_type": "web_article",
        },
        {
            "citation_id": "2",
            "title": "LemonSqueezy pricing",
            "url": "https://lemonsqueezy.com/pricing",
            "source_type": "web_article",
        },
    ],
}


def _mock_submission(base_url: str) -> BriefSubmission:
    return BriefSubmission(
        brief_run_id=_MOCK_RUN_ID,
        status_url=f"{base_url}/api/v1/brief/{_MOCK_RUN_ID}",
        public_share_url=f"{base_url}/shared/brief/{_MOCK_RUN_ID}/mocktoken00000000",
        credits_remaining=29,
    )


def _mock_status(base_url: str, brief_run_id: str) -> BriefStatus:
    return BriefStatus(
        brief_run_id=brief_run_id,
        status="completed",
        progress=100,
        brief=dict(_MOCK_BRIEF_OBJECT),
        public_share_url=f"{base_url}/shared/brief/{brief_run_id}/mocktoken00000000",
        created_at="2026-04-27T16:00:00+00:00",
    )


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class QuReDecClient:
    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self.api_key = api_key or os.environ.get("QUREDEC_API_KEY", "")
        self.base_url = (base_url or os.environ.get("QUREDEC_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self.mock = os.environ.get("QUREDEC_MOCK") == "1"
        self.timeout = timeout

        if not self.mock and not self.api_key:
            raise QuReDecError(
                "QUREDEC_API_KEY is required. Get one at https://quredec.com/account. "
                "For local dev set QUREDEC_MOCK=1."
            )

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "quredec-mcp/0.1.0",
        }

    # -- low-level error mapping ---------------------------------------------

    def _raise_for_status(self, response: httpx.Response) -> None:
        """Translate non-2xx responses into QuReDecError with stable messages."""
        if response.status_code < 400:
            return
        # 429 is handled by the back-off path — surface the raw text so callers
        # that opt out of submit_and_wait can react.
        if response.status_code == 401:
            raise QuReDecError(ERR_UNAUTHORIZED)
        if response.status_code == 402:
            raise QuReDecError(ERR_NO_CREDITS)
        if response.status_code == 404:
            raise QuReDecError("Brief not found.")
        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After", "60")
            raise QuReDecError(f"Rate limit hit. Retry after {retry_after}s.")
        # 400 / 503 / others — try to surface the server's `message` field if present.
        try:
            body = response.json()
            msg = str(body.get("message") or body.get("error") or "").strip()
        except Exception:
            msg = response.text[:200]
        raise QuReDecError(f"QuReDec API error {response.status_code}: {msg or 'unknown error'}")

    # -- submit ---------------------------------------------------------------

    def submit_brief(
        self,
        question: str,
        links: list[str] | None = None,
        mode: str | None = None,
        template_key: str | None = None,
    ) -> BriefSubmission:
        if self.mock:
            return _mock_submission(self.base_url)

        payload: dict[str, Any] = {"question": question}
        if links:
            payload["links"] = links
        if mode:
            # Live API expects "A" | "B" | "C" (IngestMode). Pass through as-is;
            # invalid values are server-coerced to "B".
            payload["mode"] = mode
        if template_key:
            payload["template_key"] = template_key

        with httpx.Client(timeout=self.timeout) as http:
            r = http.post(f"{self.base_url}/api/v1/brief", json=payload, headers=self._headers())
        self._raise_for_status(r)
        data = r.json()

        return BriefSubmission(
            brief_run_id=str(data["brief_run_id"]),
            status_url=str(data.get("status_url") or f"{self.base_url}/api/v1/brief/{data['brief_run_id']}"),
            public_share_url=data.get("public_share_url"),
            credits_remaining=(int(data["credits_remaining"]) if "credits_remaining" in data else None),
        )

    # -- status ---------------------------------------------------------------

    def get_brief(self, brief_run_id: str) -> BriefStatus:
        if self.mock:
            return _mock_status(self.base_url, brief_run_id)

        with httpx.Client(timeout=self.timeout) as http:
            r = http.get(f"{self.base_url}/api/v1/brief/{brief_run_id}", headers=self._headers())
        self._raise_for_status(r)
        data = r.json()

        return BriefStatus(
            brief_run_id=str(data["brief_run_id"]),
            status=str(data.get("status") or "unknown"),
            progress=int(data.get("progress") or 0),
            brief=data.get("brief"),
            public_share_url=data.get("public_share_url"),
            created_at=data.get("created_at"),
        )

    # -- list -----------------------------------------------------------------

    def list_briefs(self, limit: int = 20) -> list[dict[str, Any]]:
        """Return the caller's recent briefs. Live response shape:

            {"items": [{brief_run_id, status, progress, status_url,
                        public_share_url, created_at}, ...],
             "count": N}
        """
        if self.mock:
            return [
                {
                    "brief_run_id": _MOCK_RUN_ID,
                    "status": "completed",
                    "progress": 100,
                    "status_url": f"{self.base_url}/api/v1/brief/{_MOCK_RUN_ID}",
                    "public_share_url": f"{self.base_url}/shared/brief/{_MOCK_RUN_ID}/mocktoken00000000",
                    "created_at": "2026-04-27T16:00:00+00:00",
                }
            ]
        capped = max(1, min(int(limit), 100))
        with httpx.Client(timeout=self.timeout) as http:
            r = http.get(
                f"{self.base_url}/api/v1/brief",
                params={"limit": capped},
                headers=self._headers(),
            )
        self._raise_for_status(r)
        # The live API returns {"items": [...]}. Tolerate the older
        # {"briefs": [...]} shape transitionally so a stale server can't
        # break the client mid-deploy.
        body = r.json() if isinstance(r.json(), dict) else {}
        items = body.get("items")
        if items is None:
            items = body.get("briefs", [])
        return list(items or [])

    # -- submit + wait --------------------------------------------------------

    def submit_and_wait(
        self,
        question: str,
        links: list[str] | None = None,
        mode: str | None = None,
        template_key: str | None = None,
        poll_interval_s: float = DEFAULT_POLL_INTERVAL_S,
        timeout_s: float = DEFAULT_POLL_TIMEOUT_S,
    ) -> tuple[BriefSubmission, BriefStatus]:
        """Submit and poll until the brief reaches a terminal status or `timeout_s`.

        On 429 (rate limit) we back off exponentially up to MAX_POLL_INTERVAL_S
        with jitter, then resume. The MCP server should swallow these and only
        bubble the underlying QuReDecError if back-off itself times out.
        """
        submission = self.submit_brief(
            question, links=links, mode=mode, template_key=template_key,
        )
        deadline = time.monotonic() + max(timeout_s, 0)
        current_interval = max(0.5, float(poll_interval_s))

        # Initial fetch — if it's already terminal, return immediately.
        status = self._safe_get(submission.brief_run_id)
        while status.status not in TERMINAL_STATUSES:
            now = time.monotonic()
            if now >= deadline:
                break
            sleep_for = min(current_interval, max(0.5, deadline - now))
            # Small jitter to prevent thundering-herd polling.
            sleep_for += random.uniform(0, min(1.0, sleep_for * 0.1))
            time.sleep(sleep_for)
            status = self._safe_get(submission.brief_run_id, current_interval=current_interval)
            # If _safe_get hit a 429 it bumped current_interval via the closure
            # below — re-read the suggested next interval from a private attr.
            current_interval = min(MAX_POLL_INTERVAL_S, max(current_interval, getattr(self, "_last_backoff_s", current_interval)))
        return submission, status

    def _safe_get(self, brief_run_id: str, *, current_interval: float | None = None) -> BriefStatus:
        """Wrap get_brief() so 429s become an exponential back-off signal,
        not a hard error. Other QuReDecErrors propagate."""
        try:
            self._last_backoff_s = current_interval or DEFAULT_POLL_INTERVAL_S
            return self.get_brief(brief_run_id)
        except QuReDecError as exc:
            msg = str(exc)
            if msg.startswith("Rate limit hit"):
                next_interval = min(MAX_POLL_INTERVAL_S, (current_interval or DEFAULT_POLL_INTERVAL_S) * 2.0)
                self._last_backoff_s = next_interval
                log.info("rate-limited polling brief %s; backing off to %.1fs", brief_run_id, next_interval)
                # Return a synthetic running status so the loop keeps polling.
                return BriefStatus(
                    brief_run_id=brief_run_id,
                    status="running",
                    progress=0,
                    brief=None,
                    public_share_url=None,
                    created_at=None,
                )
            raise
