"""QuReDec MCP server — structured decision briefs from inside Claude Code / Desktop / Cursor."""

__version__ = "0.1.0"
