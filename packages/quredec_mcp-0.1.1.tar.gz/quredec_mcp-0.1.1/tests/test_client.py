"""Smoke tests against the in-process mock. Run with `QUREDEC_MOCK=1 pytest`.

The mock intentionally mirrors the live `/api/v1/brief*` schema field-for-field
so that any drift here also fails against production.
"""

from __future__ import annotations

import os

import pytest

os.environ.setdefault("QUREDEC_MOCK", "1")

from quredec_mcp.client import (  # noqa: E402
    DEFAULT_POLL_INTERVAL_S,
    DEFAULT_POLL_TIMEOUT_S,
    TERMINAL_STATUSES,
    QuReDecClient,
    QuReDecError,
)


def test_terminal_statuses_match_live_contract() -> None:
    """`partial` is a real terminal status on QuReDec — must NOT be missing."""
    assert "completed" in TERMINAL_STATUSES
    assert "partial" in TERMINAL_STATUSES
    assert "failed" in TERMINAL_STATUSES
    assert "complete" not in TERMINAL_STATUSES  # legacy spelling — guard against regression


def test_default_polling_matches_live_cadence() -> None:
    """Briefs typically take 2–5 minutes — defaults must reflect that."""
    assert DEFAULT_POLL_INTERVAL_S >= 10.0
    assert DEFAULT_POLL_TIMEOUT_S >= 300.0


def test_mock_submit_returns_run_id() -> None:
    c = QuReDecClient()
    sub = c.submit_brief(question="Should we adopt X?")
    assert sub.brief_run_id == "mock-run-001"
    # Mock URL must shape like the live one: /shared/brief/{id}/{token}.
    assert sub.public_share_url is not None
    assert "/shared/brief/mock-run-001/" in sub.public_share_url
    # Live API returns `credits_remaining` — mock should too.
    assert sub.credits_remaining is not None


def test_mock_get_brief_completed_with_full_schema() -> None:
    c = QuReDecClient()
    status = c.get_brief("mock-run-001")
    assert status.status == "completed"
    assert status.progress == 100
    assert isinstance(status.progress, int)
    assert status.brief is not None

    brief = status.brief
    # Every top-level key in the live brief contract MUST be present.
    for key in (
        "executive_summary",
        "recommendation",
        "confidence",
        "key_facts",
        "implications",
        "actions",
        "risks",
        "citations",
    ):
        assert key in brief, f"missing brief field: {key}"

    # key_facts items must carry citation_ids (not bare `citation`).
    assert all("text" in f and "citation_ids" in f for f in brief["key_facts"])

    # actions items must carry effort + impact.
    assert all("effort" in a and "impact" in a for a in brief["actions"])

    # risks items must carry severity + citation_ids (not bare strings).
    assert all(isinstance(r, dict) and "severity" in r for r in brief["risks"])

    # citations items must use citation_id (not `id`) and source_type.
    assert all("citation_id" in c and "source_type" in c for c in brief["citations"])


def test_mock_list_briefs_uses_live_response_shape() -> None:
    c = QuReDecClient()
    briefs = c.list_briefs(limit=5)
    assert isinstance(briefs, list)
    assert len(briefs) >= 1
    first = briefs[0]
    assert first["brief_run_id"] == "mock-run-001"
    # Live list endpoint returns status/progress/created_at, not just id+question.
    for key in ("status", "progress", "status_url", "public_share_url", "created_at"):
        assert key in first


def test_submit_and_wait_returns_terminal_status() -> None:
    c = QuReDecClient()
    submission, status = c.submit_and_wait(question="Should we adopt X?", timeout_s=5.0)
    assert submission.brief_run_id == "mock-run-001"
    assert status.status in TERMINAL_STATUSES
    assert status.brief is not None


def test_missing_api_key_without_mock_raises() -> None:
    saved_mock = os.environ.pop("QUREDEC_MOCK", None)
    saved_key = os.environ.pop("QUREDEC_API_KEY", None)
    try:
        with pytest.raises(QuReDecError, match="QUREDEC_API_KEY is required"):
            QuReDecClient()
    finally:
        if saved_mock is not None:
            os.environ["QUREDEC_MOCK"] = saved_mock
        if saved_key is not None:
            os.environ["QUREDEC_API_KEY"] = saved_key
