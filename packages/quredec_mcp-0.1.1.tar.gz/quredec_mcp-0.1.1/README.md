# QuReDec MCP Server

<!-- mcp-name: io.github.Advanced-Binary-Operations/quredec -->

Run a structured QuReDec decision brief from inside Claude Code, Claude Desktop, Cursor, or any MCP-compatible client.

> **Status:** alpha (2026-04-30). Wired to the live QuReDec public API
> (`/api/v1/brief*`, per-user Bearer-token auth). Set `QUREDEC_MOCK=1` for
> offline development.

## What this does

| Tool | Description |
|---|---|
| `decision_brief` | Submit a question; receive a structured, evidence-backed decision brief with citations |
| `get_brief_status` | Poll an in-progress brief by ID |
| `list_recent_briefs` | List the caller's recent briefs |

The completed brief contains: `executive_summary`, `recommendation`,
`confidence` (0–1), `key_facts[].citation_ids`, `implications[]`, `actions[]`
(with `effort` + `impact`), `risks[]` (with `severity` + `citation_ids`),
and `citations[]` (with `citation_id`, `title`, `url`, `source_type`).

## Install

```bash
pip install quredec-mcp
```

Or from source:

```bash
git clone https://github.com/Advanced-Binary-Operations/QuReDec_MCP
cd QuReDec_MCP
pip install -e .
```

## Configure

Generate a QuReDec API key at https://quredec.com/account → API keys.
Each key is shown to you exactly once at creation; copy it into a password
manager immediately.

Add to your MCP client config (Claude Desktop example):

```json
{
  "mcpServers": {
    "quredec": {
      "command": "quredec-mcp",
      "env": {
        "QUREDEC_API_KEY": "qrd_live_xxxxxxxxxxxx"
      }
    }
  }
}
```

Optional env vars:
- `QUREDEC_BASE_URL` — defaults to `https://quredec.com`.
- `QUREDEC_MOCK=1` — run against an in-process mock for development.

## Usage example

In Claude Code or Claude Desktop:

> Use the `decision_brief` tool to evaluate "Should I migrate from Stripe to LemonSqueezy?"

The brief comes back with: recommendation, confidence score, key facts with
inline citation ids, risks, recommended actions, and a public share URL.
Briefs typically take 2–5 minutes; the tool blocks and polls by default
(timeout 600 s) and falls back to a synthetic running status with a poll
hint if the timeout fires.

## Pricing

The MCP server is free. Briefs consume credits from your QuReDec account:
- **Starter** $4.99 — 3 briefs (one-time)
- **Pro** $49/mo — 30 briefs/mo

See https://quredec.com/pricing.

## Development

Unit tests run against the in-process mock (no network, no key required):

```bash
pip install -e ".[dev]"
QUREDEC_MOCK=1 pytest
```

Run the server locally against the mock:

```bash
QUREDEC_MOCK=1 quredec-mcp
```

### Live integration test

`scripts/integration_test.py` exercises the full path against `quredec.com`:
submit → poll → assert brief schema → list. It consumes 1 credit from the
account whose key you pass in, so run it sparingly.

```bash
QUREDEC_API_KEY=qrd_live_xxxxxxxxxxxx \
  python scripts/integration_test.py
```

Optional env vars:
- `QUREDEC_BASE_URL` — defaults to `https://quredec.com`.
- `QUREDEC_QUESTION` — override the default seed question.
- `QUREDEC_TIMEOUT` — poll timeout in seconds (default 600).

Exit code 0 on full pass, 1 on the first failed assertion.

## License

MIT — see `LICENSE`.

## Maintainer

Advanced Binary Operations LLC · support@advancedbinaryoperations.com
