"""End-to-end integration test against the live QuReDec API.

What this proves:
- Bearer auth works against quredec.com.
- POST /api/v1/brief returns a valid run id.
- GET /api/v1/brief/{id} eventually reaches a terminal status.
- The completed brief carries every field the live contract promises
  (executive_summary, recommendation, confidence, key_facts with
  citation_ids, implications, actions, risks, citations).
- GET /api/v1/brief lists the run we just submitted.

Usage:
    QUREDEC_API_KEY=qrd_live_xxxxxxxxxxxx python scripts/integration_test.py

Optional env vars:
    QUREDEC_BASE_URL  — defaults to https://quredec.com
    QUREDEC_QUESTION  — override the default seed question
    QUREDEC_TIMEOUT   — poll timeout in seconds (default 600)

Exit code:
    0 — every assertion passed.
    1 — any failure. The first failed assertion is printed; subsequent
        checks do not run. This is intentional — fail loud, fail fast.

This script consumes 1 credit from the account whose key you pass in.
Run it sparingly. It is the only client-side proof that the MCP product
is actually wired to the live engine.
"""

from __future__ import annotations

import os
import sys
import time
from typing import Any

# Force live mode regardless of any leaked env from the dev shell.
os.environ.pop("QUREDEC_MOCK", None)

# Force UTF-8 stdout so progress output works on Windows cp1252 consoles
# (the default arrow / em-dash glyphs would otherwise crash with
# UnicodeEncodeError mid-run, which is exactly what we don't want during
# a 5-minute live brief).
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from quredec_mcp.client import (  # noqa: E402  (env tweak must precede import)
    TERMINAL_STATUSES,
    QuReDecClient,
    QuReDecError,
)


DEFAULT_QUESTION = (
    "Should we adopt parametric release for our terminal sterilization line, "
    "given current ISO 14937 guidance and 21 CFR Part 11 expectations?"
)


def _need(key: str, value: object, where: str) -> None:
    if value in (None, "", []):
        raise AssertionError(f"missing required field `{key}` in {where}: got {value!r}")


def _print(msg: str) -> None:
    print(msg, flush=True)


def assert_brief_schema(brief: dict[str, Any]) -> None:
    """Field-for-field check against the live `brief` contract."""
    if not isinstance(brief, dict):
        raise AssertionError(f"brief is not a dict: {type(brief).__name__}")

    for key in ("executive_summary", "recommendation"):
        _need(key, brief.get(key), "brief")

    confidence = brief.get("confidence")
    if not isinstance(confidence, (int, float)):
        raise AssertionError(f"brief.confidence must be numeric, got {type(confidence).__name__}")
    if not 0.0 <= float(confidence) <= 1.0:
        raise AssertionError(f"brief.confidence out of [0,1]: {confidence}")

    for list_key in ("key_facts", "implications", "actions", "risks", "citations"):
        items = brief.get(list_key)
        if not isinstance(items, list):
            raise AssertionError(f"brief.{list_key} is not a list: got {type(items).__name__}")

    # Field-level shape checks for non-empty lists.
    for fact in brief.get("key_facts") or []:
        _need("key_facts[].text", fact.get("text"), "brief.key_facts")
        if not isinstance(fact.get("citation_ids", []), list):
            raise AssertionError("brief.key_facts[].citation_ids must be a list")

    for action in brief.get("actions") or []:
        _need("actions[].text", action.get("text"), "brief.actions")

    for risk in brief.get("risks") or []:
        _need("risks[].text", risk.get("text"), "brief.risks")

    for cite in brief.get("citations") or []:
        _need("citations[].citation_id", cite.get("citation_id"), "brief.citations")
        # url may be empty for some source types; title should not be.
        _need("citations[].title", cite.get("title"), "brief.citations")


def main() -> int:
    if not os.environ.get("QUREDEC_API_KEY"):
        _print("FAIL: QUREDEC_API_KEY env var is required.")
        _print("Generate a key at https://quredec.com/account.")
        return 1

    base_url = os.environ.get("QUREDEC_BASE_URL", "https://quredec.com").rstrip("/")
    question = os.environ.get("QUREDEC_QUESTION", DEFAULT_QUESTION).strip()
    timeout_s = float(os.environ.get("QUREDEC_TIMEOUT", "600"))

    if len(question) < 10:
        _print(f"FAIL: question is too short ({len(question)} chars). Min 10.")
        return 1

    _print(f"Live integration test → {base_url}")
    _print(f"Question: {question}")
    _print(f"Poll timeout: {timeout_s:.0f}s")
    _print("")

    client = QuReDecClient()

    # 1. Submit
    t0 = time.monotonic()
    try:
        submission = client.submit_brief(question=question)
    except QuReDecError as exc:
        _print(f"FAIL submit: {exc}")
        return 1
    _print(f"submitted in {time.monotonic() - t0:.1f}s")
    _print(f"  brief_run_id     = {submission.brief_run_id}")
    _print(f"  status_url       = {submission.status_url}")
    _print(f"  public_share_url = {submission.public_share_url}")
    _print(f"  credits_remaining= {submission.credits_remaining}")
    _print("")
    if not submission.brief_run_id:
        _print("FAIL: submission did not return a brief_run_id.")
        return 1
    if not submission.public_share_url:
        _print("FAIL: submission did not return a public_share_url.")
        return 1

    # 2. Poll
    _print("polling…")
    deadline = time.monotonic() + timeout_s
    poll_count = 0
    last_status = None
    while True:
        try:
            status = client.get_brief(submission.brief_run_id)
        except QuReDecError as exc:
            _print(f"FAIL poll: {exc}")
            return 1
        poll_count += 1
        if status.status != last_status:
            elapsed = time.monotonic() - t0
            _print(f"  [{elapsed:6.1f}s] status={status.status} progress={status.progress}%")
            last_status = status.status
        if status.status in TERMINAL_STATUSES:
            break
        if time.monotonic() >= deadline:
            _print(f"FAIL: timed out after {timeout_s:.0f}s in status={status.status}")
            return 1
        time.sleep(15.0)
    _print(f"reached terminal status={status.status} after {poll_count} polls")
    _print("")

    # 3. Schema check
    if status.status == "failed":
        _print("FAIL: brief reached terminal status=failed.")
        return 1
    if status.brief is None:
        _print(f"FAIL: status={status.status} but brief payload is None.")
        return 1
    try:
        assert_brief_schema(status.brief)
    except AssertionError as exc:
        _print(f"FAIL schema: {exc}")
        return 1
    _print(f"schema OK — {len(status.brief.get('key_facts') or [])} facts, "
           f"{len(status.brief.get('citations') or [])} citations, "
           f"confidence={status.brief.get('confidence')}")
    _print("")

    # 4. List
    try:
        items = client.list_briefs(limit=5)
    except QuReDecError as exc:
        _print(f"FAIL list: {exc}")
        return 1
    found = any(item.get("brief_run_id") == submission.brief_run_id for item in items)
    if not found:
        _print(f"FAIL: just-submitted run {submission.brief_run_id} "
               f"not present in /api/v1/brief?limit=5 ({len(items)} items returned)")
        return 1
    _print(f"list OK — found run id in {len(items)}-item recent list")
    _print("")

    elapsed = time.monotonic() - t0
    _print(f"PASS — full e2e in {elapsed:.0f}s ({poll_count} polls).")
    _print(f"View: {status.public_share_url}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
