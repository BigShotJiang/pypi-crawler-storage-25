"""Application Management.
"""
