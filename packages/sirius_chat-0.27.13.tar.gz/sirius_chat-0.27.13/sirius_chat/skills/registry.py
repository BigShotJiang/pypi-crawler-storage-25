"""Skill registry — discovers, loads, and manages skill definitions.

Skills are Python files residing in {work_path}/skills/ that expose:
- SKILL_META: dict with name, description, parameters, version (optional)
- run(**kwargs) -> Any: the callable entry point
"""

from __future__ import annotations

import importlib.util
import logging
import sys
from pathlib import Path
from typing import Any

from sirius_chat.skills.models import SkillDefinition, SkillInvocationContext, SkillParameter
from sirius_chat.skills.dependency_resolver import resolve_skill_dependencies

logger = logging.getLogger(__name__)

_SKILLS_README = """# skills 目录说明

此目录用于存放 Sirius Chat 在当前 work_path 下可自动发现的外部 SKILL 文件。

- 每个 SKILL 使用单独的 Python 文件。
- 文件需导出 SKILL_META 字典和 run() 函数。
- 文件名建议使用英文、数字、下划线，避免以下划线开头。
- 当会话启用 SKILL 系统时，框架会自动扫描此目录。

最小示例：

```python
SKILL_META = {
    "name": "hello_skill",
    "description": "返回简单问候语",
    "parameters": {
        "name": {
            "type": "str",
            "description": "要问候的名字",
            "required": True,
        }
    },
}


def run(name: str, **kwargs):
    return {"message": f"你好，{name}"}
```
"""


class SkillRegistry:
    """Discovers and manages skill definitions from a directory."""

    def __init__(self) -> None:
        self._skills: dict[str, SkillDefinition] = {}

    @property
    def skill_names(self) -> list[str]:
        return list(self._skills.keys())

    def get(self, name: str) -> SkillDefinition | None:
        return self._skills.get(name)

    def all_skills(self) -> list[SkillDefinition]:
        return list(self._skills.values())

    def register(self, skill: SkillDefinition) -> None:
        """Manually register a skill definition."""
        self._skills[skill.name] = skill

    def replace_all(self, skills: list[SkillDefinition]) -> None:
        """Replace the whole registry atomically."""
        self._skills = {skill.name: skill for skill in skills}

    @staticmethod
    def ensure_skills_directory(skills_dir: Path) -> None:
        """Ensure the skills directory and its README bootstrap file exist."""
        skills_dir.mkdir(parents=True, exist_ok=True)
        readme_path = skills_dir / "README.md"
        if not readme_path.exists():
            readme_path.write_text(_SKILLS_README, encoding="utf-8")

    @staticmethod
    def builtin_skills_dir() -> Path:
        """Return the package directory containing built-in skills."""
        return Path(__file__).resolve().parent / "builtin"

    def _load_builtin_skills(self, *, auto_install_deps: bool) -> int:
        """Load package-provided built-in skills into the registry."""
        loaded = 0
        builtin_dir = self.builtin_skills_dir()
        if not builtin_dir.exists():
            return loaded
        for py_file in sorted(builtin_dir.glob("*.py")):
            if py_file.name.startswith("_"):
                continue
            try:
                self._install_skill_dependencies(py_file, auto_install_deps=auto_install_deps)
                skill = self._load_skill_file(py_file)
                if skill is not None:
                    self._skills[skill.name] = skill
                    loaded += 1
            except Exception as exc:
                logger.warning("加载内置SKILL失败 (%s): %s", py_file.name, exc)
        return loaded

    def load_from_directory(
        self,
        skills_dir: Path,
        *,
        auto_install_deps: bool = True,
        include_builtin: bool = False,
    ) -> int:
        """Load all *.py skill files from a directory.

        Args:
            skills_dir: Directory containing SKILL Python files.
            auto_install_deps: If True, automatically install missing
                third-party dependencies declared in SKILL_META or
                detected from import statements (uses ``uv`` / ``pip``).
            include_builtin: If True, pre-load package-provided built-in skills
                before scanning the workspace directory. Workspace skills with the
                same name override built-ins.

        Returns the number of skills successfully loaded.
        """
        self.ensure_skills_directory(skills_dir)

        baseline = len(self._skills)
        if include_builtin:
            self._load_builtin_skills(auto_install_deps=auto_install_deps)

        for py_file in sorted(skills_dir.glob("*.py")):
            if py_file.name.startswith("_"):
                continue
            try:
                self._install_skill_dependencies(py_file, auto_install_deps=auto_install_deps)

                skill = self._load_skill_file(py_file)
                if skill is not None:
                    self._skills[skill.name] = skill
                    logger.info("已加载SKILL: %s (v%s) from %s", skill.name, skill.version, py_file.name)
            except Exception as exc:
                logger.warning("加载SKILL文件失败 (%s): %s", py_file.name, exc)
        return max(0, len(self._skills) - baseline)

    def reload_from_directory(
        self,
        skills_dir: Path,
        *,
        auto_install_deps: bool = True,
        include_builtin: bool = False,
    ) -> int:
        """Reload all skill files from a directory, replacing removed entries too."""
        self.ensure_skills_directory(skills_dir)

        loaded_skills: list[SkillDefinition] = []
        if include_builtin:
            builtin_dir = self.builtin_skills_dir()
            if builtin_dir.exists():
                for py_file in sorted(builtin_dir.glob("*.py")):
                    if py_file.name.startswith("_"):
                        continue
                    try:
                        self._install_skill_dependencies(py_file, auto_install_deps=auto_install_deps)
                        skill = self._load_skill_file(py_file)
                        if skill is not None:
                            loaded_skills.append(skill)
                            logger.info("已重载内置SKILL: %s (v%s) from %s", skill.name, skill.version, py_file.name)
                    except Exception as exc:
                        logger.warning("重载内置SKILL失败 (%s): %s", py_file.name, exc)

        for py_file in sorted(skills_dir.glob("*.py")):
            if py_file.name.startswith("_"):
                continue
            try:
                self._install_skill_dependencies(py_file, auto_install_deps=auto_install_deps)

                skill = self._load_skill_file(py_file)
                if skill is not None:
                    loaded_skills.append(skill)
                    logger.info("已重载SKILL: %s (v%s) from %s", skill.name, skill.version, py_file.name)
            except Exception as exc:
                logger.warning("重载SKILL文件失败 (%s): %s", py_file.name, exc)

        self.replace_all(loaded_skills)
        return len(self._skills)

    @staticmethod
    def _load_skill_file(file_path: Path) -> SkillDefinition | None:
        """Load a single skill from a Python file."""
        module_name = f"_sirius_skill_{file_path.stem}"

        spec = importlib.util.spec_from_file_location(module_name, file_path)
        if spec is None or spec.loader is None:
            logger.warning("无法创建模块规格: %s", file_path)
            return None

        module = importlib.util.module_from_spec(spec)
        # Temporarily add to sys.modules so relative imports work if needed
        sys.modules[module_name] = module
        try:
            spec.loader.exec_module(module)
        except Exception as exc:
            sys.modules.pop(module_name, None)
            raise RuntimeError(f"执行SKILL模块失败 ({file_path.name}): {exc}") from exc

        meta: dict[str, Any] | None = getattr(module, "SKILL_META", None)
        if not isinstance(meta, dict):
            sys.modules.pop(module_name, None)
            logger.warning("SKILL文件缺少 SKILL_META 字典: %s", file_path.name)
            return None

        run_func = getattr(module, "run", None)
        if not callable(run_func):
            sys.modules.pop(module_name, None)
            logger.warning("SKILL文件缺少 run() 函数: %s", file_path.name)
            return None

        name = str(meta.get("name", file_path.stem)).strip()
        description = str(meta.get("description", "")).strip()
        version = str(meta.get("version", "1.0.0")).strip()
        developer_only = bool(meta.get("developer_only", False))
        if not name:
            name = file_path.stem
        if not description:
            logger.warning("SKILL '%s' 缺少描述", name)

        # Parse parameters
        raw_params = meta.get("parameters", {})
        parameters: list[SkillParameter] = []
        if isinstance(raw_params, dict):
            for param_name, param_def in raw_params.items():
                if isinstance(param_def, dict):
                    parameters.append(
                        SkillParameter(
                            name=param_name,
                            type=str(param_def.get("type", "str")),
                            description=str(param_def.get("description", "")),
                            required=bool(param_def.get("required", False)),
                            default=param_def.get("default"),
                        )
                    )
        elif isinstance(raw_params, list):
            for item in raw_params:
                if isinstance(item, dict):
                    parameters.append(
                        SkillParameter(
                            name=str(item.get("name", "")),
                            type=str(item.get("type", "str")),
                            description=str(item.get("description", "")),
                            required=bool(item.get("required", False)),
                            default=item.get("default"),
                        )
                    )

        return SkillDefinition(
            name=name,
            description=description,
            parameters=parameters,
            version=version,
            developer_only=developer_only,
            source_path=file_path,
            _run_func=run_func,
        )

    def build_tool_descriptions(
        self,
        *,
        invocation_context: SkillInvocationContext | None = None,
    ) -> str:
        """Build a formatted text block describing all available skills.

        This is injected into the system prompt so the AI knows what tools
        are available and how to call them.
        """
        if not self._skills:
            return ""

        lines: list[str] = []
        for skill in self._skills.values():
            if (
                skill.developer_only
                and invocation_context is not None
                and not invocation_context.caller_is_developer
            ):
                continue

            security_note = "（仅 developer 可调用）" if skill.developer_only else ""
            lines.append(f"- {skill.name}: {skill.description}{security_note}")
            if skill.parameters:
                param_parts: list[str] = []
                for p in skill.parameters:
                    required_tag = "必填" if p.required else "可选"
                    default_tag = f", 默认={p.default}" if not p.required and p.default is not None else ""
                    param_parts.append(
                        f"    - {p.name} ({p.type}, {required_tag}{default_tag}): {p.description}"
                    )
                lines.extend(param_parts)
        return "\n".join(lines)

    @staticmethod
    def _install_skill_dependencies(py_file: Path, *, auto_install_deps: bool) -> None:
        if not auto_install_deps:
            resolve_skill_dependencies(py_file, auto_install=False)
            return

        installed = resolve_skill_dependencies(py_file, auto_install=True)
        if installed:
            logger.info("SKILL '%s': 已自动安装依赖: %s", py_file.stem, ", ".join(installed))
