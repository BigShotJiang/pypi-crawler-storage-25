# Contributing

- Full guide: [docs/CONTRIBUTING.md](docs/CONTRIBUTING.md)
