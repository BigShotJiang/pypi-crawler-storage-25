# openinference-instrumentation-codex Repo Guide

- Read [README.md](README.md) first.
- Use [docs/DIAGRAM.md](docs/DIAGRAM.md) for trace boundaries.
- Use [docs/CONTRIBUTING.md](docs/CONTRIBUTING.md) for validation.
- Use [docs/SECURITY.md](docs/SECURITY.md) for content-capture or exporter-risk changes.

- Use this routing table first.
- Open deeper docs only for the selected surface.

## Contents

- [Routing](#routing)
- [Boundary](#boundary)
- [Workflow](#workflow)
- [Required Checks](#required-checks)

## Routing

| User intent or change | Work in | Notes |
| --- | --- | --- |
| Event adapters, trace builder, attribute mapping | `src/openinference/instrumentation/codex/` | Package-owned behavior |
| `codex-otel-proxy` CLI | `src/openinference/instrumentation/codex/proxy.py` | CLI JSONL transport |
| Local JSONL forwarder | `src/openinference/instrumentation/codex/jsonl_forwarder.py`, `_session_jsonl.py`, `_turn_exporter.py` | Persisted session mode |
| Fallback SDK or CLI instrumentation | `src/openinference/instrumentation/codex/_instrumentor.py`, `_cli_instrumentor.py`, `_wrappers.py`, `_processor.py` | Keep fallback-only paths marked |
| Tests and fixtures | `tests/` | Unit, integration, e2e fixtures |
| Examples or helper scripts | `examples/`, `scripts/` | Keep docs aligned |
| Public docs | `README.md`, `docs/` | Update for public surface changes |
| CodexOps image pin or deployment wiring | Parent root `containers/codex-job/`, `charts/` | Outside this repo |

## Boundary

- Own the runner and instrumentation package
- Treat `codexops` as an external caller of the published runner
- Treat sink behavior as external to this repo

## Workflow

- Use `uv` for dependency and test workflows
- Update docs when public surfaces or integration contracts change
- Keep fallback paths clearly marked as fallback-only
- Keep package version, exported spans, CLI docs, and any parent CodexOps image pins or docs aligned when runner behavior changes
- Keep secrets and environment-specific values out of prompts and committed files
- Use Conventional Commit messages for every commit, whether authored by an agent or a human, so release-please can decide version bumps

## Required Checks

- `make lint`
- `make test`
- `make compose-e2e`
- `make flight-check` for full local validation
