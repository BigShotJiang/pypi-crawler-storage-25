from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Start codex-jsonl-forwarder in the background.")
    parser.add_argument("--codex-home", required=True)
    parser.add_argument("--state-path", required=True)
    parser.add_argument("--log-path", required=True)
    parser.add_argument("--pid-path", required=True)
    parser.add_argument("--project", required=True)
    parser.add_argument("--otlp-endpoint", required=True)
    parser.add_argument("--poll-interval", default="1")
    parser.add_argument("--backfill-active-grace", default="300")
    parser.add_argument("--turn-idle-timeout", default="30")
    parser.add_argument("--fresh", action="store_true")
    args = parser.parse_args()

    pid_path = Path(args.pid_path)
    if _running_pid(pid_path):
        print(f"codex-jsonl-forwarder already running with pid {pid_path.read_text().strip()}")
        return 0

    state_path = Path(args.state_path)
    log_path = Path(args.log_path)
    pid_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    if args.fresh:
        state_path.unlink(missing_ok=True)

    env = os.environ.copy()
    env.update(
        {
            "OTEL_TRACES_EXPORTER": "otlp",
            "OTEL_EXPORTER_OTLP_TRACES_ENDPOINT": args.otlp_endpoint,
            "OTEL_EXPORTER_OTLP_TRACES_PROTOCOL": "http/protobuf",
            "OTEL_RESOURCE_ATTRIBUTES": f"openinference.project.name={args.project}",
            "OTEL_SERVICE_NAME": "codex-jsonl-forwarder",
        }
    )
    command = [
        sys.executable,
        "-m",
        "openinference.instrumentation.codex.jsonl_forwarder",
        "--codex-home",
        args.codex_home,
        "--state-path",
        str(state_path),
        "--poll-interval",
        args.poll_interval,
        "--backfill-active-grace",
        args.backfill_active_grace,
        "--turn-idle-timeout",
        args.turn_idle_timeout,
    ]
    with log_path.open("ab") as output:
        process = subprocess.Popen(  # noqa: S603
            command,
            stdin=subprocess.DEVNULL,
            stdout=output,
            stderr=output,
            env=env,
            start_new_session=True,
        )
    pid_path.write_text(f"{process.pid}\n", encoding="utf-8")
    print(f"Started codex-jsonl-forwarder with pid {process.pid}")
    print(f"Forwarder log: {log_path}")
    return 0


def _running_pid(pid_path: Path) -> bool:
    try:
        pid = int(pid_path.read_text(encoding="utf-8").strip())
    except (FileNotFoundError, OSError, ValueError):
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


if __name__ == "__main__":
    raise SystemExit(main())
