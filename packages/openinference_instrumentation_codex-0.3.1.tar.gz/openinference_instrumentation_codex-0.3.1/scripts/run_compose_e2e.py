from __future__ import annotations

import subprocess
import sys
from pathlib import Path

DIST_DIR = Path("/tmp/dist")
PROJECT_WHEEL = "openinference_instrumentation_codex-*.whl"


def _run(command: list[str]) -> None:
    subprocess.check_call(command)


def _build_project_wheel() -> Path:
    DIST_DIR.mkdir(parents=True, exist_ok=True)
    for wheel in DIST_DIR.glob(PROJECT_WHEEL):
        wheel.unlink()

    _run([sys.executable, "-m", "pip", "wheel", ".", "-w", str(DIST_DIR)])

    wheels = sorted(DIST_DIR.glob(PROJECT_WHEEL))
    if len(wheels) != 1:
        names = ", ".join(str(wheel) for wheel in wheels) or "none"
        raise RuntimeError(f"expected exactly one built project wheel, found: {names}")
    return wheels[0]


def main() -> int:
    wheel = _build_project_wheel()
    _run([sys.executable, "-m", "pip", "install", f"{wheel}[otlp,test]"])
    _run([sys.executable, "tests/e2e/run_wheel_e2e.py"])
    _run([sys.executable, "scripts/run_live_codex_smoke.py"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
