from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class CodexUsage:
    input_tokens: int = 0
    cached_input_tokens: int = 0
    output_tokens: int = 0
    reasoning_output_tokens: int = 0
    total_tokens: int = 0

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any] | None) -> CodexUsage:
        raw = raw or {}
        input_tokens = _int_value(
            raw,
            "input_tokens",
            "inputTokens",
            "prompt_tokens",
            "promptTokens",
        )
        output_tokens = _int_value(
            raw,
            "output_tokens",
            "outputTokens",
            "completion_tokens",
            "completionTokens",
        )
        total_tokens = _int_value(raw, "total_tokens", "totalTokens")
        return cls(
            input_tokens=input_tokens,
            cached_input_tokens=_int_value(
                raw,
                "cached_input_tokens",
                "cachedInputTokens",
                "cached_tokens",
                "cachedTokens",
            )
            or _nested_int_value(
                raw,
                ("prompt_tokens_details", "cached_tokens"),
                ("promptTokensDetails", "cachedTokens"),
                ("input_tokens_details", "cached_tokens"),
                ("inputTokensDetails", "cachedTokens"),
            ),
            output_tokens=output_tokens,
            reasoning_output_tokens=_int_value(
                raw,
                "reasoning_output_tokens",
                "reasoningOutputTokens",
            )
            or _nested_int_value(
                raw,
                ("completion_tokens_details", "reasoning_tokens"),
                ("completionTokensDetails", "reasoningTokens"),
                ("output_tokens_details", "reasoning_tokens"),
                ("outputTokensDetails", "reasoningTokens"),
            ),
            total_tokens=total_tokens or input_tokens + output_tokens,
        )

    def add(self, other: CodexUsage) -> CodexUsage:
        return CodexUsage(
            input_tokens=self.input_tokens + other.input_tokens,
            cached_input_tokens=self.cached_input_tokens + other.cached_input_tokens,
            output_tokens=self.output_tokens + other.output_tokens,
            reasoning_output_tokens=self.reasoning_output_tokens + other.reasoning_output_tokens,
            total_tokens=self.total_tokens + other.total_tokens,
        )

    def as_attributes(self) -> dict[str, int]:
        attrs: dict[str, int] = {}
        if self.input_tokens:
            attrs["prompt_tokens"] = self.input_tokens
        if self.cached_input_tokens:
            attrs["cached_input_tokens"] = self.cached_input_tokens
        if self.output_tokens:
            attrs["completion_tokens"] = self.output_tokens
        if self.total_tokens:
            attrs["total_tokens"] = self.total_tokens
        if self.reasoning_output_tokens:
            attrs["codex.reasoning_output_tokens"] = self.reasoning_output_tokens
        return attrs

    def as_session_attributes(self) -> dict[str, int]:
        attrs: dict[str, int] = {}
        if self.input_tokens:
            attrs["codex.usage.prompt_tokens"] = self.input_tokens
        if self.cached_input_tokens:
            attrs["codex.usage.cached_input_tokens"] = self.cached_input_tokens
        if self.output_tokens:
            attrs["codex.usage.completion_tokens"] = self.output_tokens
        if self.total_tokens:
            attrs["codex.usage.total_tokens"] = self.total_tokens
        if self.reasoning_output_tokens:
            attrs["codex.reasoning_output_tokens"] = self.reasoning_output_tokens
        return attrs


@dataclass(frozen=True)
class CodexItem:
    item_id: str
    item_type: str
    status: str | None = None
    thread_id: str | None = None
    turn_id: str | None = None
    parent_item_id: str | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ThreadStarted:
    thread_id: str
    observed_at_ns: int | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class TurnStarted:
    turn_id: str
    thread_id: str | None = None
    observed_at_ns: int | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class TurnCompleted:
    turn_id: str
    thread_id: str | None = None
    status: str = "completed"
    usage: CodexUsage = field(default_factory=CodexUsage)
    error_message: str | None = None
    observed_at_ns: int | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ItemStarted:
    item: CodexItem
    observed_at_ns: int | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ItemCompleted:
    item: CodexItem
    observed_at_ns: int | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ItemUpdated:
    item: CodexItem
    observed_at_ns: int | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ItemDelta:
    item_id: str
    delta_kind: str
    delta: Any
    thread_id: str | None = None
    turn_id: str | None = None
    observed_at_ns: int | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class UsageUpdated:
    usage: CodexUsage
    thread_id: str | None = None
    turn_id: str | None = None
    cumulative: bool = True
    observed_at_ns: int | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class RuntimeErrorEvent:
    message: str
    thread_id: str | None = None
    turn_id: str | None = None
    item_id: str | None = None
    observed_at_ns: int | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class UnknownEvent:
    event_type: str
    observed_at_ns: int | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)


CodexEvent = (
    ThreadStarted
    | TurnStarted
    | TurnCompleted
    | ItemStarted
    | ItemUpdated
    | ItemCompleted
    | ItemDelta
    | UsageUpdated
    | RuntimeErrorEvent
    | UnknownEvent
)


def _int_value(raw: Mapping[str, Any], *keys: str) -> int:
    for key in keys:
        value = raw.get(key)
        if value is None:
            continue
        try:
            return int(value)
        except (TypeError, ValueError):
            continue
    return 0


def _nested_int_value(raw: Mapping[str, Any], *paths: tuple[str, str]) -> int:
    for outer_key, inner_key in paths:
        outer = raw.get(outer_key)
        if not isinstance(outer, Mapping):
            continue
        value = _int_value(outer, inner_key)
        if value:
            return value
    return 0
