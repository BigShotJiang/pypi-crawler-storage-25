from __future__ import annotations

import os
from collections.abc import Iterable
from dataclasses import dataclass, field, replace

DEFAULT_METHODS_TO_WRAP: tuple[tuple[str, str], ...] = (
    ("codex", "Client.run"),
    ("codex", "Client.create_task"),
    ("codex", "Client.responses.create"),
)


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


@dataclass(frozen=True)
class CodexConfig:
    enabled: bool = True
    capture_inputs: bool = False
    capture_outputs: bool = False
    capture_tool_outputs: bool = False
    redact_inputs: bool = True
    max_attribute_length: int = 4096
    preserve_original_attributes: bool = True
    debug: bool = False
    methods_to_wrap: tuple[tuple[str, str], ...] = field(
        default_factory=lambda: DEFAULT_METHODS_TO_WRAP
    )

    @classmethod
    def from_env(cls) -> CodexConfig:
        return cls(
            enabled=_env_bool("OPENINFERENCE_CODEX_ENABLED", True),
            capture_inputs=_env_bool("OPENINFERENCE_CODEX_CAPTURE_INPUTS", False),
            capture_outputs=_env_bool("OPENINFERENCE_CODEX_CAPTURE_OUTPUTS", False),
            capture_tool_outputs=_env_bool("OPENINFERENCE_CODEX_CAPTURE_TOOL_OUTPUTS", False),
            redact_inputs=_env_bool("OPENINFERENCE_CODEX_REDACT_INPUTS", True),
            max_attribute_length=_env_int("OPENINFERENCE_CODEX_MAX_ATTRIBUTE_LENGTH", 4096),
            preserve_original_attributes=_env_bool(
                "OPENINFERENCE_CODEX_PRESERVE_ORIGINAL_ATTRIBUTES", True
            ),
            debug=_env_bool("OPENINFERENCE_CODEX_DEBUG", False),
        )

    def with_methods(self, methods: Iterable[tuple[str, str]]) -> CodexConfig:
        return replace(self, methods_to_wrap=tuple(methods))
