from __future__ import annotations

import json
import os
from collections.abc import Mapping
from typing import Any

from opentelemetry import trace
from opentelemetry.context import Context
from opentelemetry.trace import Span, SpanKind, Status, StatusCode

from ._attributes import map_codex_attributes
from ._config import CodexConfig
from ._events import CodexUsage
from ._model_mapping import model_name_attributes
from ._session_jsonl import PersistedRecord, PersistedTurn
from ._version import __version__


class CodexTurnExporter:
    def __init__(
        self,
        *,
        tracer_provider: Any = None,
        config: CodexConfig | None = None,
        default_model: str | None = None,
        default_provider: str | None = None,
    ) -> None:
        self._config = config or CodexConfig.from_env()
        self._default_model = default_model
        self._default_provider = default_provider
        self._tracer = trace.get_tracer(
            "openinference.instrumentation.codex.session_jsonl",
            __version__,
            tracer_provider,
        )

    def export(
        self,
        turn: PersistedTurn,
        *,
        parent_context: Context | None = None,
        parent_node_id: str | None = None,
    ) -> Span:
        root = self._tracer.start_span(
            "codex.turn",
            context=parent_context,
            kind=SpanKind.INTERNAL,
            start_time=turn.started_at_ns,
        )
        root_context = trace.set_span_in_context(root)
        usage = _latest_usage(turn.records)
        root_attrs = {
            "span_kind": "LLM",
            "session.id": turn.session_id,
            "codex.thread.id": turn.session_id,
            "codex.turn.id": turn.turn_id,
            "codex.turn.status": turn.status,
            "codex.emission.transport": "session-jsonl",
            "codex.observer.name": "codex-jsonl-forwarder",
            "graph.node.id": f"turn:{turn.turn_id}",
            "graph.node.name": "codex.turn",
            **_turn_metadata_attributes(
                turn,
                default_model=self._default_model,
                default_provider=self._default_provider,
            ),
            **usage.as_attributes(),
        }
        if parent_node_id is not None:
            root_attrs["graph.node.parent_id"] = parent_node_id
        root_attrs.update(_root_content_attributes(turn.records))
        self._apply_attributes(root, "codex.turn", root_attrs)

        calls: dict[str, tuple[Span, Context, str]] = {}
        for record in turn.records:
            self._export_record(record, root_context=root_context, calls=calls)
        for span, _context, _span_name in calls.values():
            if getattr(span, "end_time", None) is None:
                span.end(end_time=turn.ended_at_ns)

        if turn.status == "completed":
            root.set_status(Status(StatusCode.OK))
        elif turn.status == "interrupted":
            root.set_status(Status(StatusCode.ERROR, "turn interrupted"))
        root.end(end_time=turn.ended_at_ns)
        return root

    def _export_record(
        self,
        record: PersistedRecord,
        *,
        root_context: Context,
        calls: dict[str, tuple[Span, Context, str]],
    ) -> None:
        payload_type = record.payload_type
        if payload_type == "message":
            role = str(record.payload.get("role") or "")
            text = _message_text(record.payload)
            if role not in {"user", "assistant"} or not text:
                return
            name = f"codex.message.{role}"
            attrs = {
                "span_kind": "CHAIN",
                "input": text if role == "user" else None,
                "output": text if role == "assistant" else None,
                "codex.turn.id": record.turn_id,
            }
            self._emit_child(
                name,
                context=root_context,
                start_time=record.observed_at_ns,
                end_time=record.observed_at_ns,
                attrs=attrs,
            )
            return

        if payload_type == "reasoning":
            summary = _joined(record.payload.get("summary"))
            encrypted = record.payload.get("encrypted_content")
            attrs = {
                "span_kind": "CHAIN",
                "output": summary,
                "codex.turn.id": record.turn_id,
                "codex.reasoning.summary_count": _summary_count(record.payload.get("summary")),
                "codex.reasoning.encrypted_present": encrypted is not None,
                "codex.reasoning.encrypted_length": len(str(encrypted)) if encrypted else 0,
            }
            self._emit_child(
                "codex.reasoning",
                context=root_context,
                start_time=record.observed_at_ns,
                end_time=record.observed_at_ns,
                attrs=attrs,
            )
            return

        if payload_type == "function_call":
            call_id = _call_id(record)
            tool_name = str(record.payload.get("name") or "function_call")
            span_name = _function_call_span_name(tool_name)
            attrs = {
                "span_kind": "TOOL",
                "tool_name": tool_name,
                "tool_id": call_id,
                "tool_arguments": _maybe_json(record.payload.get("arguments")),
                "codex.turn.id": record.turn_id,
            }
            span = self._tracer.start_span(
                span_name,
                context=root_context,
                kind=SpanKind.INTERNAL,
                start_time=record.observed_at_ns,
            )
            self._apply_attributes(span, span_name, attrs)
            calls[call_id] = (span, trace.set_span_in_context(span), span_name)
            return

        if payload_type == "function_call_output":
            call_id = _call_id(record)
            parent = calls.get(call_id)
            context = parent[1] if parent else root_context
            parent_name = parent[2] if parent else "codex.tool.function_call"
            output = record.payload.get("output")
            span_name = _function_result_span_name(parent_name)
            attrs = {
                "span_kind": "TOOL",
                "tool_id": call_id,
                "tool_result": output,
                "codex.turn.id": record.turn_id,
            }
            self._emit_child(
                span_name,
                context=context,
                start_time=record.observed_at_ns,
                end_time=record.observed_at_ns,
                attrs=attrs,
            )
            if parent:
                parent[0].end(end_time=record.observed_at_ns)
            return

        if payload_type == "mcp_tool_call":
            call_id = _call_id(record)
            server = _first_str(record.payload, "server", "server_label")
            tool = _first_str(record.payload, "tool", "name")
            tool_name = ".".join(part for part in (server, tool) if part) or "mcp"
            attrs = {
                "span_kind": "TOOL",
                "tool_name": tool_name,
                "tool_id": call_id,
                "tool_arguments": record.payload.get("arguments"),
                "codex.mcp.server": server,
                "codex.turn.id": record.turn_id,
            }
            span = self._tracer.start_span(
                "codex.tool.mcp",
                context=root_context,
                kind=SpanKind.INTERNAL,
                start_time=record.observed_at_ns,
            )
            self._apply_attributes(span, "codex.tool.mcp", attrs)
            calls[call_id] = (span, trace.set_span_in_context(span), "codex.tool.mcp")
            return

        if payload_type == "mcp_tool_call_output":
            call_id = _call_id(record)
            parent = calls.get(call_id)
            context = parent[1] if parent else root_context
            attrs = {
                "span_kind": "TOOL",
                "tool_id": call_id,
                "tool_result": record.payload.get("output"),
                "codex.turn.id": record.turn_id,
            }
            self._emit_child(
                "codex.tool.mcp.result",
                context=context,
                start_time=record.observed_at_ns,
                end_time=record.observed_at_ns,
                attrs=attrs,
            )
            if parent:
                parent[0].end(end_time=record.observed_at_ns)
            return

        if payload_type == "mcp_tool_call_end":
            call_id = _call_id(record)
            invocation = _mapping(record.payload.get("invocation"))
            parent = calls.get(call_id)
            if parent is None:
                server = _first_str(invocation, "server", "server_label")
                tool = _first_str(invocation, "tool", "name")
                tool_name = ".".join(part for part in (server, tool) if part) or "mcp"
                span = self._tracer.start_span(
                    "codex.tool.mcp",
                    context=root_context,
                    kind=SpanKind.INTERNAL,
                    start_time=record.observed_at_ns,
                )
                self._apply_attributes(
                    span,
                    "codex.tool.mcp",
                    {
                        "span_kind": "TOOL",
                        "tool_name": tool_name,
                        "tool_id": call_id,
                        "tool_arguments": invocation.get("arguments"),
                        "codex.mcp.server": server,
                        "codex.turn.id": record.turn_id,
                    },
                )
                parent = (span, trace.set_span_in_context(span), "codex.tool.mcp")
                calls[call_id] = parent
            self._emit_child(
                "codex.tool.mcp.result",
                context=parent[1],
                start_time=record.observed_at_ns,
                end_time=record.observed_at_ns,
                attrs={
                    "span_kind": "TOOL",
                    "tool_id": call_id,
                    "tool_result": _mcp_result_output(record.payload.get("result")),
                    "codex.turn.id": record.turn_id,
                },
            )
            parent[0].end(end_time=record.observed_at_ns)
            return

        if payload_type == "tool_search_call":
            call_id = _call_id(record)
            span = self._tracer.start_span(
                "codex.tool.search",
                context=root_context,
                kind=SpanKind.INTERNAL,
                start_time=record.observed_at_ns,
            )
            self._apply_attributes(
                span,
                "codex.tool.search",
                {
                    "span_kind": "TOOL",
                    "tool_name": "tool_search",
                    "tool_id": call_id,
                    "tool_arguments": record.payload.get("arguments"),
                    "codex.turn.id": record.turn_id,
                },
            )
            calls[call_id] = (span, trace.set_span_in_context(span), "codex.tool.search")
            return

        if payload_type == "tool_search_output":
            call_id = _call_id(record)
            parent = calls.get(call_id)
            context = parent[1] if parent else root_context
            self._emit_child(
                "codex.tool.search.result",
                context=context,
                start_time=record.observed_at_ns,
                end_time=record.observed_at_ns,
                attrs={
                    "span_kind": "TOOL",
                    "tool_id": call_id,
                    "tool_result": record.payload.get("tools"),
                    "codex.turn.id": record.turn_id,
                },
            )
            if parent:
                parent[0].end(end_time=record.observed_at_ns)
            return

        if payload_type == "web_search_call":
            action = _mapping(record.payload.get("action"))
            self._emit_child(
                "codex.tool.web_search",
                context=root_context,
                start_time=record.observed_at_ns,
                end_time=record.observed_at_ns,
                attrs={
                    "span_kind": "TOOL",
                    "tool_name": "web_search",
                    "tool_arguments": action,
                    "input": action.get("query"),
                    "codex.turn.id": record.turn_id,
                },
            )
            return

        if payload_type == "token_count":
            usage = CodexUsage.from_mapping(_token_usage(record.payload))
            self._emit_child(
                "codex.event.token_count",
                context=root_context,
                start_time=record.observed_at_ns,
                end_time=record.observed_at_ns,
                attrs={
                    "span_kind": "CHAIN",
                    "codex.turn.id": record.turn_id,
                    **usage.as_attributes(),
                },
            )

    def _emit_child(
        self,
        name: str,
        *,
        context: Context,
        start_time: int,
        end_time: int,
        attrs: Mapping[str, Any],
    ) -> None:
        span = self._tracer.start_span(
            name,
            context=context,
            kind=SpanKind.INTERNAL,
            start_time=start_time,
        )
        self._apply_attributes(span, name, attrs)
        span.set_status(Status(StatusCode.OK))
        span.end(end_time=end_time)

    def _apply_attributes(self, span: Span, span_name: str, attrs: Mapping[str, Any]) -> None:
        clean = {key: value for key, value in attrs.items() if value is not None}
        for key, value in map_codex_attributes(span_name, dict(clean), self._config).items():
            span.set_attribute(key, value)


def _root_content_attributes(records: tuple[PersistedRecord, ...]) -> dict[str, Any]:
    attrs: dict[str, Any] = {}
    for record in records:
        if record.payload_type != "message":
            continue
        text = _message_text(record.payload)
        role = str(record.payload.get("role") or "")
        if role == "user" and text:
            attrs["input"] = text
            attrs["llm_input_messages"] = [{"role": "user", "content": text}]
        elif role == "assistant" and text:
            attrs["output"] = text
            attrs["llm_output_messages"] = [{"role": "assistant", "content": text}]
    return attrs


def _latest_usage(records: tuple[PersistedRecord, ...]) -> CodexUsage:
    usage = CodexUsage()
    for record in records:
        if record.payload_type == "token_count":
            usage = CodexUsage.from_mapping(_token_usage(record.payload))
    return usage


def _token_usage(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    info = _mapping(payload.get("info"))
    return (
        _mapping(info.get("last_token_usage"))
        or _mapping(info.get("lastTokenUsage"))
        or _mapping(info.get("total_token_usage"))
        or _mapping(info.get("totalTokenUsage"))
        or _mapping(payload.get("usage"))
    )


def _turn_metadata_attributes(
    turn: PersistedTurn,
    *,
    default_model: str | None = None,
    default_provider: str | None = None,
) -> dict[str, Any]:
    raw_model = _turn_model(turn, default_model=default_model)
    return {
        **model_name_attributes(raw_model),
        "provider": _turn_provider(turn, default_provider=default_provider),
    }


def _turn_model(turn: PersistedTurn, *, default_model: str | None = None) -> str | None:
    return (
        _first_str(turn.turn_context, "model", "model_name", "modelName")
        or _collaboration_mode_model(turn.turn_context)
        or _env_str("OPENINFERENCE_CODEX_MODEL", "CODEX_MODEL")
        or default_model
    )


def _turn_provider(turn: PersistedTurn, *, default_provider: str | None = None) -> str | None:
    return (
        _first_str(turn.session_meta, "model_provider", "modelProvider", "provider")
        or _env_str("OPENINFERENCE_CODEX_PROVIDER")
        or default_provider
    )


def _collaboration_mode_model(raw: Mapping[str, Any]) -> str | None:
    collaboration_mode = _mapping(raw.get("collaboration_mode"))
    settings = _mapping(collaboration_mode.get("settings"))
    return _optional_str(settings.get("model"))


def _env_str(*keys: str) -> str | None:
    for key in keys:
        value = os.getenv(key)
        if value:
            return value
    return None


def _call_id(record: PersistedRecord) -> str:
    return str(record.payload.get("call_id") or record.payload.get("id") or record.observed_at_ns)


def _function_call_span_name(tool_name: str) -> str:
    if tool_name == "exec_command":
        return "codex.shell.command"
    if tool_name == "apply_patch":
        return "codex.file_change"
    return "codex.tool.function_call"


def _function_result_span_name(parent_name: str) -> str:
    if parent_name == "codex.shell.command":
        return "codex.shell.command.result"
    if parent_name == "codex.file_change":
        return "codex.file_change.result"
    return "codex.tool.function_result"


def _message_text(payload: Mapping[str, Any]) -> str:
    content = payload.get("content")
    if isinstance(content, str):
        return content.strip()
    if not isinstance(content, list):
        return ""
    parts: list[str] = []
    for item in content:
        if isinstance(item, str):
            parts.append(item)
        elif isinstance(item, Mapping):
            text = item.get("text")
            if isinstance(text, str):
                parts.append(text)
    return "\n".join(part for part in parts if part).strip()


def _joined(value: Any) -> str | None:
    if isinstance(value, str):
        return value.strip() or None
    if isinstance(value, list):
        text = "\n".join(str(item) for item in value if item).strip()
        return text or None
    return None


def _summary_count(value: Any) -> int:
    return len(value) if isinstance(value, list) else 0


def _maybe_json(value: Any) -> Any:
    if not isinstance(value, str):
        return value
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return value


def _first_str(raw: Mapping[str, Any], *keys: str) -> str:
    for key in keys:
        value = raw.get(key)
        if value is not None:
            return str(value)
    return ""


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _optional_str(value: Any) -> str | None:
    if value is None or value == "":
        return None
    return str(value)


def _mcp_result_output(value: Any) -> Any:
    result = _mapping(value)
    ok = _mapping(result.get("Ok"))
    if ok:
        return ok.get("structuredContent") or ok.get("content") or ok
    err = _mapping(result.get("Err"))
    if err:
        return err
    return value
