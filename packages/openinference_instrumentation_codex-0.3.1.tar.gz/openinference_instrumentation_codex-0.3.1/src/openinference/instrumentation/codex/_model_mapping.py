from __future__ import annotations

import re


def phoenix_cost_model_name(model: str | None) -> str | None:
    raw = _optional_model(model)
    if raw is None:
        return None
    normalized = _normalize_model_name(raw)

    if normalized == "codex-auto-review":
        return "gpt-5-codex"
    if normalized.startswith("gpt-5.4-cyber"):
        return "gpt-5.4"
    if normalized.startswith("gpt-5.3-codex-spark"):
        return "gpt-5.3-codex"
    if normalized in {"gpt-5.4-oai", "gpt-5.4-ultrafast"}:
        return "gpt-5.4"
    if normalized.startswith("gpt-5.4-oai-") or normalized.startswith("gpt-5.4-ultrafast-"):
        return "gpt-5.4"
    if normalized.startswith("gpt-5.5-pro"):
        return "gpt-5.5-pro"
    if normalized.startswith("gpt-5.5"):
        return "gpt-5.5"
    if normalized.startswith("gpt-5.4-pro"):
        return "gpt-5.4-pro"
    if normalized.startswith("gpt-5.4-mini"):
        return "gpt-5.4-mini"
    if normalized.startswith("gpt-5.4-nano"):
        return "gpt-5.4-nano"
    if normalized.startswith("gpt-5.4"):
        return "gpt-5.4"
    if normalized.startswith("gpt-5.3-codex"):
        return "gpt-5.3-codex"
    if normalized.startswith("gpt-5.3-chat"):
        return "gpt-5.3-chat-latest"
    if normalized.startswith("gpt-5.2-pro"):
        return "gpt-5.2-pro"
    if normalized.startswith("gpt-5.2-chat"):
        return "gpt-5.2-chat-latest"
    if normalized.startswith("gpt-5.2"):
        return "gpt-5.2"
    if normalized.startswith("gpt-5.1-codex-max"):
        return "gpt-5.1-codex-max"
    if normalized.startswith("gpt-5.1-codex-mini"):
        return "gpt-5.1-codex-mini"
    if normalized.startswith("gpt-5.1-codex"):
        return "gpt-5.1-codex"
    if normalized.startswith("gpt-5.1-chat"):
        return "gpt-5.1-chat-latest"
    if normalized.startswith("gpt-5.1"):
        return "gpt-5.1"
    if normalized.startswith("gpt-5-pro"):
        return "gpt-5-pro"
    if normalized.startswith("gpt-5-mini"):
        return "gpt-5-mini"
    if normalized.startswith("gpt-5-nano"):
        return "gpt-5-nano"
    if normalized.startswith("gpt-5-codex"):
        return "gpt-5-codex"
    if normalized.startswith("gpt-5-chat"):
        return "gpt-5-chat-latest"
    if normalized.startswith("gpt-5"):
        return "gpt-5"
    return raw


def model_name_attributes(model: str | None) -> dict[str, str]:
    raw = _optional_model(model)
    if raw is None:
        return {}
    cost_model = phoenix_cost_model_name(raw)
    attrs = {
        "model": cost_model or raw,
        "codex.model.original": raw,
    }
    if cost_model:
        attrs["codex.model.cost_model"] = cost_model
    return attrs


def _normalize_model_name(model: str) -> str:
    lowered = re.sub(r"\s+", "-", model.strip().lower())
    lowered = lowered.replace("_", "-")
    return lowered.removeprefix("openai/")


def _optional_model(model: str | None) -> str | None:
    if model is None:
        return None
    stripped = model.strip()
    return stripped or None
