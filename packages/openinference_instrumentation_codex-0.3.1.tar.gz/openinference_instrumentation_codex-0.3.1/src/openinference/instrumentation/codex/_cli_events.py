from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from dataclasses import replace
from typing import Any

from ._events import (
    CodexEvent,
    CodexItem,
    CodexUsage,
    ItemCompleted,
    ItemStarted,
    ItemUpdated,
    RuntimeErrorEvent,
    ThreadStarted,
    TurnCompleted,
    TurnStarted,
    UnknownEvent,
)
from ._trace_builder import CodexTraceBuilder


class CodexCliJsonlAdapter:
    def __init__(self, builder: CodexTraceBuilder) -> None:
        self._builder = builder
        self._turn_counter = 0
        self._active_turn_id: str | None = None

    def observe_line(self, line: str, *, observed_at_ns: int | None = None) -> bool:
        event = parse_cli_jsonl_line(line, observed_at_ns=observed_at_ns)
        if event is None:
            return False
        event = self._stabilize_turn_ids(event)
        self._builder.ingest(event)
        return True

    def observe_lines(self, lines: Iterable[str]) -> None:
        for line in lines:
            self.observe_line(line)

    def _stabilize_turn_ids(self, event: CodexEvent) -> CodexEvent:
        if isinstance(event, TurnStarted):
            turn_id = event.turn_id
            if turn_id == "turn":
                self._turn_counter += 1
                turn_id = f"turn-{self._turn_counter}"
                event = replace(event, turn_id=turn_id)
            self._active_turn_id = turn_id
            return event
        if isinstance(event, TurnCompleted):
            turn_id = self._active_turn_id if event.turn_id == "turn" else event.turn_id
            event = replace(event, turn_id=turn_id)
            self._active_turn_id = None
            return event
        if (
            isinstance(event, (ItemStarted, ItemUpdated, ItemCompleted))
            and event.item.turn_id is None
        ):
            return replace(event, item=replace(event.item, turn_id=self._active_turn_id))
        return event


def parse_cli_jsonl_line(line: str, *, observed_at_ns: int | None = None) -> CodexEvent | None:
    line = line.strip()
    if not line or not line.startswith("{"):
        return None
    try:
        raw = json.loads(line)
    except json.JSONDecodeError:
        return None
    if not isinstance(raw, Mapping):
        return None
    return normalize_cli_event(raw, observed_at_ns=observed_at_ns)


def normalize_cli_event(
    raw: Mapping[str, Any],
    *,
    observed_at_ns: int | None = None,
) -> CodexEvent:
    event_type = str(raw.get("type") or "")
    if event_type == "thread.started":
        return ThreadStarted(
            thread_id=str(raw.get("thread_id") or raw.get("threadId") or ""),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    if event_type == "turn.started":
        return TurnStarted(
            turn_id=str(raw.get("turn_id") or raw.get("turnId") or raw.get("id") or "turn"),
            thread_id=_optional_str(raw.get("thread_id") or raw.get("threadId")),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    if event_type in {"turn.completed", "turn.failed"}:
        status = "failed" if event_type == "turn.failed" else str(raw.get("status") or "completed")
        error = raw.get("error")
        return TurnCompleted(
            turn_id=str(raw.get("turn_id") or raw.get("turnId") or raw.get("id") or "turn"),
            thread_id=_optional_str(raw.get("thread_id") or raw.get("threadId")),
            status=status,
            usage=CodexUsage.from_mapping(_mapping(raw.get("usage"))),
            error_message=_error_message(error),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    if event_type in {"item.started", "item.updated", "item.completed"}:
        item = _normalize_cli_item(_mapping(raw.get("item")), raw)
        event_cls = {
            "item.started": ItemStarted,
            "item.updated": ItemUpdated,
            "item.completed": ItemCompleted,
        }[event_type]
        return event_cls(item=item, observed_at_ns=observed_at_ns, raw=raw)
    if event_type == "error":
        return RuntimeErrorEvent(
            message=_error_message(raw.get("error")) or str(raw.get("message") or "codex error"),
            thread_id=_optional_str(raw.get("thread_id") or raw.get("threadId")),
            turn_id=_optional_str(raw.get("turn_id") or raw.get("turnId")),
            item_id=_optional_str(raw.get("item_id") or raw.get("itemId")),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    return UnknownEvent(event_type=event_type or "unknown", observed_at_ns=observed_at_ns, raw=raw)


def _normalize_cli_item(item: Mapping[str, Any], raw: Mapping[str, Any]) -> CodexItem:
    return CodexItem(
        item_id=str(item.get("id") or ""),
        item_type=_normalize_item_type(str(item.get("type") or "")),
        status=_optional_str(item.get("status")),
        thread_id=_optional_str(raw.get("thread_id") or raw.get("threadId")),
        turn_id=_optional_str(raw.get("turn_id") or raw.get("turnId")),
        parent_item_id=_optional_str(item.get("parent_item_id") or item.get("parentItemId")),
        raw=item,
    )


def _normalize_item_type(item_type: str) -> str:
    return item_type.strip().replace("-", "_")


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _optional_str(value: Any) -> str | None:
    if value is None or value == "":
        return None
    return str(value)


def _error_message(value: Any) -> str | None:
    if isinstance(value, Mapping):
        if value.get("message"):
            return str(value["message"])
    if value is None or value == "":
        return None
    return str(value)
