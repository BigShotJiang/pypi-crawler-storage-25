from __future__ import annotations

import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from typing import Any

from opentelemetry import trace
from opentelemetry.context import Context
from opentelemetry.trace import Span, SpanKind, Status, StatusCode

from ._attributes import map_codex_attributes
from ._config import CodexConfig
from ._events import (
    CodexEvent,
    CodexItem,
    CodexUsage,
    ItemCompleted,
    ItemDelta,
    ItemStarted,
    ItemUpdated,
    RuntimeErrorEvent,
    ThreadStarted,
    TurnCompleted,
    TurnStarted,
    UnknownEvent,
    UsageUpdated,
)
from ._model_mapping import model_name_attributes
from ._utils import safe_json_dumps
from ._version import __version__

_TOOL_ITEM_TYPES = {
    "command_execution",
    "file_change",
    "mcp_tool_call",
    "dynamic_tool_call",
    "web_search",
    "image_view",
    "image_generation",
    "hook",
}
_AGENT_ITEM_TYPES = {"collab_tool_call"}


@dataclass
class _OpenSpan:
    span: Span
    context: Context
    node_id: str
    raw: dict[str, Any] = field(default_factory=dict)
    delta_output: list[str] = field(default_factory=list)


class CodexTraceBuilder:
    def __init__(
        self,
        *,
        tracer_provider: Any = None,
        config: CodexConfig | None = None,
        root_attributes: Mapping[str, Any] | None = None,
        root_context: Context | None = None,
        clock_ns: Callable[[], int] = time.time_ns,
    ) -> None:
        self._config = config or CodexConfig.from_env()
        self._clock_ns = clock_ns
        self._tracer = trace.get_tracer(
            "openinference.instrumentation.codex.events",
            __version__,
            tracer_provider,
        )
        self._root_seed_attributes = dict(root_attributes or {})
        self._root_context = root_context
        self._turns: dict[str, _OpenSpan] = {}
        self._items: dict[str, _OpenSpan] = {}
        self._active_turn_id: str | None = None
        self._thread_id: str | None = None
        self._turn_usage: dict[str, CodexUsage] = {}
        self._last_root_span: Span | None = None
        self._ended = False

    @property
    def root_span(self) -> Span:
        if self._active_turn_id and self._active_turn_id in self._turns:
            return self._turns[self._active_turn_id].span
        if self._last_root_span is not None:
            return self._last_root_span
        raise RuntimeError("no codex.turn root span has been started")

    def ingest(self, event: CodexEvent) -> None:
        if self._ended:
            return
        if isinstance(event, ThreadStarted):
            self._on_thread_started(event)
        elif isinstance(event, TurnStarted):
            self._on_turn_started(event)
        elif isinstance(event, TurnCompleted):
            self._on_turn_completed(event)
        elif isinstance(event, ItemStarted):
            self._on_item_started(event)
        elif isinstance(event, ItemUpdated):
            self._on_item_updated(event)
        elif isinstance(event, ItemCompleted):
            self._on_item_completed(event)
        elif isinstance(event, ItemDelta):
            self._on_item_delta(event)
        elif isinstance(event, UsageUpdated):
            self._on_usage_updated(event)
        elif isinstance(event, RuntimeErrorEvent):
            self._on_runtime_error(event)
        elif isinstance(event, UnknownEvent):
            self._record_unknown_event(event)

    def finish(self, *, status: StatusCode = StatusCode.OK, message: str = "") -> None:
        if self._ended:
            return
        for item_id in list(self._items):
            self._finish_item(item_id, status=StatusCode.UNSET)
        for turn_id in list(self._turns):
            self._finish_turn(turn_id, status=status, message=message)
        self._ended = True

    def _on_thread_started(self, event: ThreadStarted) -> None:
        if not self._thread_id:
            self._thread_id = event.thread_id

    def _on_turn_started(self, event: TurnStarted) -> None:
        if event.turn_id in self._turns:
            return
        span = self._tracer.start_span(
            "codex.turn",
            context=self._root_context,
            kind=SpanKind.INTERNAL,
            start_time=event.observed_at_ns or self._clock_ns(),
        )
        node_id = f"turn:{event.turn_id}"
        attrs = {
            "span_kind": "LLM",
            "session.id": event.thread_id or self._thread_id,
            "codex.turn.id": event.turn_id,
            "codex.thread.id": event.thread_id or self._thread_id,
            "graph.node.id": node_id,
            "graph.node.name": "codex.turn",
            **_turn_seed_attributes(self._root_seed_attributes),
        }
        self._apply_attributes(span, "codex.turn", attrs)
        self._turns[event.turn_id] = _OpenSpan(
            span=span,
            context=trace.set_span_in_context(span),
            node_id=node_id,
        )
        self._active_turn_id = event.turn_id
        self._turn_usage[event.turn_id] = CodexUsage()
        self._last_root_span = span

    def _on_turn_completed(self, event: TurnCompleted) -> None:
        turn = self._turns.get(event.turn_id)
        if turn is None:
            self._on_turn_started(
                TurnStarted(
                    turn_id=event.turn_id,
                    thread_id=event.thread_id,
                    observed_at_ns=event.observed_at_ns,
                    raw=event.raw,
                )
            )
            turn = self._turns.get(event.turn_id)
        if turn is None:
            return
        self._turn_usage[event.turn_id] = event.usage
        self._apply_attributes(turn.span, "codex.turn", event.usage.as_attributes())
        failed = event.status.lower() == "failed"
        self._finish_turn(
            event.turn_id,
            status=StatusCode.ERROR if failed else StatusCode.OK,
            message=event.error_message or "",
            end_time=event.observed_at_ns,
        )

    def _on_item_started(self, event: ItemStarted) -> None:
        item = event.item
        if item.item_id in self._items:
            return
        parent_ctx, parent_node_id = self._select_parent(item)
        span_name = _item_span_name(item.item_type)
        span = self._tracer.start_span(
            span_name,
            context=parent_ctx,
            kind=SpanKind.INTERNAL,
            start_time=event.observed_at_ns or self._clock_ns(),
        )
        node_id = f"item:{item.item_id}"
        raw = dict(item.raw)
        attrs = {
            **_item_base_attributes(item, span_name, node_id, parent_node_id),
            **_item_content_attributes(item.item_type, raw),
        }
        self._apply_attributes(span, span_name, attrs)
        self._items[item.item_id] = _OpenSpan(
            span=span,
            context=trace.set_span_in_context(span),
            node_id=node_id,
            raw=raw,
        )

    def _on_item_completed(self, event: ItemCompleted) -> None:
        item = event.item
        if item.item_id not in self._items:
            self._on_item_started(
                ItemStarted(
                    item=item,
                    observed_at_ns=event.observed_at_ns,
                    raw=event.raw,
                )
            )
        open_item = self._items.get(item.item_id)
        if open_item is None:
            return
        raw = dict(open_item.raw)
        raw.update(dict(item.raw))
        if open_item.delta_output:
            raw.setdefault("output", "".join(open_item.delta_output))
            raw.setdefault("aggregated_output", "".join(open_item.delta_output))
            raw.setdefault("result", "".join(open_item.delta_output))
        span_name = _item_span_name(item.item_type)
        self._apply_attributes(
            open_item.span,
            span_name,
            {
                **_item_base_attributes(
                    item,
                    span_name,
                    open_item.node_id,
                    _parent_node_id_from_span(open_item.span),
                ),
                **_item_content_attributes(item.item_type, raw),
            },
        )
        if item.item_type == "agent_message":
            if text := str(
                _first_value(raw, "text", "output", "aggregated_output") or ""
            ).strip():
                self._record_output_message(item.turn_id, text)
        elif item.item_type == "user_message":
            if text := _user_message_text(raw):
                self._record_input_message(item.turn_id, text)
        failed, message = _item_failed(item.item_type, raw, item.status)
        self._finish_item(
            item.item_id,
            status=StatusCode.ERROR if failed else StatusCode.OK,
            message=message,
            end_time=event.observed_at_ns,
        )

    def _on_item_updated(self, event: ItemUpdated) -> None:
        item = event.item
        if item.item_id not in self._items:
            self._on_item_started(
                ItemStarted(
                    item=item,
                    observed_at_ns=event.observed_at_ns,
                    raw=event.raw,
                )
            )
        open_item = self._items.get(item.item_id)
        if open_item is None:
            return
        open_item.raw.update(dict(item.raw))
        span_name = _item_span_name(item.item_type)
        self._apply_attributes(
            open_item.span,
            span_name,
            {
                **_item_base_attributes(
                    item,
                    span_name,
                    open_item.node_id,
                    _parent_node_id_from_span(open_item.span),
                ),
                **_item_content_attributes(item.item_type, open_item.raw),
            },
        )

    def _on_item_delta(self, event: ItemDelta) -> None:
        open_item = self._items.get(event.item_id)
        if open_item is None:
            return
        if event.delta_kind in {
            "command_output",
            "file_change_output",
            "agent_message",
            "plan",
            "reasoning",
        }:
            open_item.delta_output.append(str(event.delta))
        elif event.delta_kind == "mcp_progress":
            open_item.span.add_event(
                "codex.mcp.progress",
                {"codex.mcp.progress": safe_json_dumps(event.delta)},
                timestamp=event.observed_at_ns or self._clock_ns(),
            )
        elif event.delta_kind in {"file_change_patch", "reasoning_summary_part"}:
            open_item.span.add_event(
                f"codex.{event.delta_kind}",
                {"codex.delta.payload": safe_json_dumps(event.delta)},
                timestamp=event.observed_at_ns or self._clock_ns(),
            )

    def _on_usage_updated(self, event: UsageUpdated) -> None:
        turn_id = event.turn_id or self._active_turn_id
        if not turn_id or turn_id not in self._turns:
            return
        current = self._turn_usage.get(turn_id, CodexUsage())
        usage = event.usage if event.cumulative else current.add(event.usage)
        self._turn_usage[turn_id] = usage
        self._apply_attributes(self._turns[turn_id].span, "codex.turn", usage.as_attributes())

    def _on_runtime_error(self, event: RuntimeErrorEvent) -> None:
        attrs = {"codex.error.message": event.message}
        turn = self._turns.get(event.turn_id or self._active_turn_id or "")
        if turn is not None:
            turn.span.add_event(
                "codex.error",
                attrs,
                timestamp=event.observed_at_ns or self._clock_ns(),
            )
            turn.span.set_status(Status(StatusCode.ERROR, event.message))
        if event.item_id and event.item_id in self._items:
            self._items[event.item_id].span.set_status(Status(StatusCode.ERROR, event.message))

    def _select_parent(self, item: CodexItem) -> tuple[Context, str]:
        if item.parent_item_id and item.parent_item_id in self._items:
            parent = self._items[item.parent_item_id]
            return parent.context, parent.node_id
        if item.turn_id and item.turn_id in self._turns:
            parent = self._turns[item.turn_id]
            return parent.context, parent.node_id
        if self._active_turn_id and self._active_turn_id in self._turns:
            parent = self._turns[self._active_turn_id]
            return parent.context, parent.node_id
        turn_id = item.turn_id or self._active_turn_id or "turn"
        self._on_turn_started(TurnStarted(turn_id=turn_id, thread_id=item.thread_id))
        parent = self._turns[turn_id]
        return parent.context, parent.node_id

    def _finish_item(
        self,
        item_id: str,
        *,
        status: StatusCode,
        message: str = "",
        end_time: int | None = None,
    ) -> None:
        item = self._items.pop(item_id, None)
        if item is None:
            return
        if status is StatusCode.ERROR:
            item.span.set_status(Status(status, message))
        elif _span_status_code(item.span) is StatusCode.UNSET:
            item.span.set_status(Status(StatusCode.OK))
        item.span.end(end_time=end_time or self._clock_ns())

    def _finish_turn(
        self,
        turn_id: str,
        *,
        status: StatusCode,
        message: str = "",
        end_time: int | None = None,
    ) -> None:
        turn = self._turns.pop(turn_id, None)
        if turn is None:
            return
        if status is StatusCode.ERROR:
            turn.span.set_status(Status(status, message))
        elif _span_status_code(turn.span) is StatusCode.UNSET:
            turn.span.set_status(Status(StatusCode.OK))
        turn.span.end(end_time=end_time or self._clock_ns())
        if self._active_turn_id == turn_id:
            self._active_turn_id = None

    def _apply_attributes(self, span: Span, span_name: str, attrs: Mapping[str, Any]) -> None:
        clean_attrs = {key: value for key, value in attrs.items() if value is not None}
        if span_name == "codex.turn" and "span_kind" not in clean_attrs:
            clean_attrs["span_kind"] = "LLM"
        for key, value in map_codex_attributes(span_name, dict(clean_attrs), self._config).items():
            span.set_attribute(key, value)

    def annotate_root(self, attrs: Mapping[str, Any]) -> None:
        self._root_seed_attributes.update(dict(attrs))
        for turn in self._turns.values():
            self._apply_attributes(turn.span, "codex.turn", attrs)

    def _record_input_message(self, turn_id: str | None, text: str) -> None:
        messages = [{"role": "user", "content": text}]
        attrs = {"input": text, "llm_input_messages": messages}
        turn = self._turns.get(turn_id or self._active_turn_id or "")
        if turn is not None:
            self._apply_attributes(turn.span, "codex.turn", attrs)

    def _record_output_message(self, turn_id: str | None, text: str) -> None:
        messages = [{"role": "assistant", "content": text}]
        attrs = {"output": text, "llm_output_messages": messages}
        turn = self._turns.get(turn_id or self._active_turn_id or "")
        if turn is not None:
            self._apply_attributes(turn.span, "codex.turn", attrs)

    def _record_unknown_event(self, event: UnknownEvent) -> None:
        turn = self._turns.get(self._active_turn_id or "")
        if turn is None:
            return
        attrs = {"codex.event.type": event.event_type}
        if event.raw:
            attrs["codex.event.payload"] = safe_json_dumps(event.raw)
        turn.span.add_event(
            "codex.event",
            attrs,
            timestamp=event.observed_at_ns or self._clock_ns(),
        )


def _item_base_attributes(
    item: CodexItem,
    span_name: str,
    node_id: str,
    parent_node_id: str | None,
) -> dict[str, Any]:
    return {
        "span_kind": _item_span_kind(item.item_type),
        "codex.item.id": item.item_id,
        "codex.item.type": item.item_type,
        "codex.item.status": item.status,
        "codex.thread.id": item.thread_id,
        "codex.turn.id": item.turn_id,
        "graph.node.id": node_id,
        "graph.node.name": span_name,
        "graph.node.parent_id": parent_node_id,
        "tool_id": item.item_id if item.item_type in _TOOL_ITEM_TYPES else None,
    }


def _item_content_attributes(item_type: str, raw: Mapping[str, Any]) -> dict[str, Any]:
    if item_type == "command_execution":
        output = raw.get("aggregated_output") or raw.get("output")
        return {
            "tool_name": "command_execution",
            "tool_arguments": _first_mapping(raw, "tool_arguments")
            or {"command": raw.get("command"), "cwd": raw.get("cwd")},
            "input": raw.get("command"),
            "output": output,
            "tool_result": output,
            "codex.command.exit_code": _first_value(raw, "exit_code", "exitCode"),
        }
    if item_type == "file_change":
        return {
            "tool_name": "file_change",
            "tool_arguments": raw.get("changes"),
            "tool_result": raw.get("result") or raw.get("output"),
            "output": raw.get("result") or raw.get("output"),
        }
    if item_type == "mcp_tool_call":
        server = _first_value(raw, "server")
        tool = _first_value(raw, "tool", "tool_name", "toolName")
        tool_name = ".".join(part for part in (server, tool) if part) or "mcp"
        return {
            "tool_name": tool_name,
            "tool_arguments": _first_value(raw, "arguments", "tool_arguments"),
            "tool_result": _first_value(raw, "result", "tool_result"),
            "output": _first_value(raw, "result", "tool_result"),
            "codex.mcp.server": server,
        }
    if item_type == "dynamic_tool_call":
        return {
            "tool_name": _dynamic_tool_name(raw),
            "tool_arguments": _first_value(raw, "arguments", "tool_arguments"),
            "tool_result": _first_value(raw, "result", "content_items", "contentItems"),
            "output": _first_value(raw, "result", "content_items", "contentItems"),
            "codex.dynamic_tool.namespace": _first_value(raw, "namespace"),
        }
    if item_type == "collab_tool_call":
        return {
            "agent_name": _first_value(raw, "tool", "tool_name", "toolName") or "subagent",
            "input": _first_value(raw, "prompt"),
            "codex.collab.sender_thread_id": _first_value(
                raw,
                "sender_thread_id",
                "senderThreadId",
            ),
            "codex.collab.receiver_thread_id": _first_value(
                raw,
                "receiver_thread_id",
                "receiverThreadId",
            ),
            "codex.collab.receiver_thread_ids": _first_value(
                raw,
                "receiver_thread_ids",
                "receiverThreadIds",
            ),
            "codex.collab.new_thread_id": _first_value(raw, "new_thread_id", "newThreadId"),
            "codex.collab.agents_states": _first_value(raw, "agents_states", "agentsStates"),
            "codex.collab.agent_status": _first_value(raw, "agent_status", "agentStatus"),
        }
    if item_type == "web_search":
        return {
            "tool_name": "web_search",
            "tool_arguments": {
                "query": raw.get("query"),
                "action": raw.get("action"),
            },
            "input": raw.get("query"),
            "tool_result": _first_value(raw, "result", "results", "sources"),
            "output": _first_value(raw, "result", "results", "sources"),
        }
    if item_type == "image_view":
        return {
            "tool_name": "image_view",
            "tool_arguments": {"path": raw.get("path")},
            "input": raw.get("path"),
        }
    if item_type == "image_generation":
        return {
            "tool_name": "image_generation",
            "tool_arguments": {"prompt": raw.get("revisedPrompt")},
            "tool_result": _first_value(raw, "result", "savedPath", "saved_path"),
            "output": _first_value(raw, "result", "savedPath", "saved_path"),
        }
    if item_type in {"agent_message", "plan", "plan_update"}:
        return {
            "output": _first_value(raw, "text", "output", "aggregated_output")
            or _joined(_first_value(raw, "content"))
        }
    if item_type == "reasoning":
        return {
            "output": _first_value(raw, "output", "aggregated_output")
            or _joined(_first_value(raw, "summary", "content"))
        }
    if item_type == "user_message":
        return {"input": _user_message_text(raw)}
    if item_type == "hook":
        entries = raw.get("entries")
        return {
            "tool_name": f"hook.{_first_value(raw, 'eventName', 'event_name') or 'run'}",
            "tool_arguments": {
                "event_name": _first_value(raw, "eventName", "event_name"),
                "handler_type": _first_value(raw, "handlerType", "handler_type"),
                "execution_mode": _first_value(raw, "executionMode", "execution_mode"),
                "scope": _first_value(raw, "scope"),
                "source": _first_value(raw, "source"),
            },
            "tool_result": entries,
            "output": entries,
            "codex.hook.event_name": _first_value(raw, "eventName", "event_name"),
            "codex.hook.handler_type": _first_value(raw, "handlerType", "handler_type"),
            "codex.hook.execution_mode": _first_value(
                raw,
                "executionMode",
                "execution_mode",
            ),
            "codex.hook.scope": _first_value(raw, "scope"),
            "codex.hook.source_path": _first_value(raw, "sourcePath", "source_path"),
            "codex.hook.status_message": _first_value(
                raw,
                "statusMessage",
                "status_message",
            ),
            "codex.hook.duration_ms": _first_value(raw, "durationMs", "duration_ms"),
        }
    return {}


def _item_span_kind(item_type: str) -> str:
    if item_type in _AGENT_ITEM_TYPES:
        return "AGENT"
    if item_type in _TOOL_ITEM_TYPES:
        return "TOOL"
    return "CHAIN"


def _item_span_name(item_type: str) -> str:
    return {
        "command_execution": "codex.tool.command_execution",
        "file_change": "codex.file_change",
        "mcp_tool_call": "codex.tool.mcp",
        "dynamic_tool_call": "codex.tool.dynamic",
        "collab_tool_call": "codex.agent.subagent",
        "web_search": "codex.tool.web_search",
        "image_view": "codex.tool.image_view",
        "hook": "codex.hook",
        "context_compaction": "codex.context_compaction",
    }.get(item_type, f"codex.item.{item_type or 'unknown'}")


def _item_failed(
    item_type: str,
    raw: Mapping[str, Any],
    status: str | None,
) -> tuple[bool, str]:
    exit_code = _first_value(raw, "exit_code", "exitCode")
    if item_type == "command_execution" and exit_code not in (None, 0, "0"):
        return True, f"command exited with status {exit_code}"
    if str(status or "").lower() in {"failed", "error", "blocked"}:
        return True, str(_first_value(raw, "error") or "item failed")
    if _first_value(raw, "error"):
        return True, str(_first_value(raw, "error"))
    if _first_value(raw, "success") is False:
        return True, "tool reported success=false"
    return False, ""


def _parent_node_id_from_span(span: Span) -> str | None:
    value = getattr(span, "attributes", {}).get("graph.node.parent_id")
    return str(value) if value is not None else None


def _span_status_code(span: Span) -> StatusCode:
    status = getattr(span, "status", None)
    return getattr(status, "status_code", StatusCode.UNSET)


def _first_value(raw: Mapping[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in raw and raw[key] is not None:
            return raw[key]
    return None


def _first_mapping(raw: Mapping[str, Any], *keys: str) -> Mapping[str, Any] | None:
    value = _first_value(raw, *keys)
    if isinstance(value, Mapping):
        return value
    return None


def _joined(value: Any) -> str | None:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        parts: list[str] = []
        for part in value:
            if isinstance(part, str):
                parts.append(part)
            elif isinstance(part, Mapping):
                text = _first_value(part, "text", "content")
                if isinstance(text, str):
                    parts.append(text)
        text = "\n".join(part for part in parts if part).strip()
        return text or None
    return None


def _user_message_text(raw: Mapping[str, Any]) -> str:
    content = raw.get("content")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        chunks: list[str] = []
        for item in content:
            if isinstance(item, str):
                chunks.append(item)
            elif isinstance(item, Mapping):
                text = _first_value(item, "text", "content")
                if isinstance(text, str):
                    chunks.append(text)
        return "\n".join(chunk for chunk in chunks if chunk).strip()
    return ""


def _dynamic_tool_name(raw: Mapping[str, Any]) -> str:
    namespace = _first_value(raw, "namespace")
    tool = _first_value(raw, "tool", "tool_name", "toolName")
    if namespace and tool:
        return f"{namespace}.{tool}"
    return str(tool or "dynamic")


def _turn_seed_attributes(root_seed_attributes: Mapping[str, Any]) -> dict[str, Any]:
    attrs = dict(root_seed_attributes)
    if model_attrs := model_name_attributes(_first_model_value(attrs)):
        attrs.update(model_attrs)
    return attrs


def _first_model_value(attrs: Mapping[str, Any]) -> str | None:
    for key in ("model", "model_name", "codex.model", "codex.model_name"):
        value = attrs.get(key)
        if value is None:
            continue
        stripped = str(value).strip()
        if stripped:
            return stripped
    return None
