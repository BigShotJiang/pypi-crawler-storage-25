from __future__ import annotations

import argparse
import os
import signal
import sys
import threading
from collections.abc import Mapping, Sequence
from dataclasses import replace
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from ._config import CodexConfig
from ._session_jsonl import SessionFileFollower, default_state_path
from ._turn_exporter import CodexTurnExporter
from .proxy import (
    _HTTP_PROTOCOLS,
    _TRACE_EXPORTER_NONE,
    _TRACE_EXPORTER_OTLP,
    _resource_attributes,
    _trace_endpoint,
    _trace_protocol,
)


class CodexJsonlForwarder:
    def __init__(
        self,
        *,
        codex_home: Path,
        state_path: Path,
        poll_interval_s: float = 1.0,
        turn_idle_timeout_s: float = 30.0,
        backfill_active_grace_s: float = 300.0,
        tracer_provider: Any = None,
        config: CodexConfig | None = None,
    ) -> None:
        self._poll_interval_s = poll_interval_s
        self._provider = tracer_provider
        self._follower = SessionFileFollower(
            codex_home=codex_home,
            state_path=state_path,
            turn_idle_timeout_s=turn_idle_timeout_s,
            backfill_active_grace_s=backfill_active_grace_s,
        )
        default_model, default_provider = _codex_config_defaults(codex_home)
        self._exporter = CodexTurnExporter(
            tracer_provider=tracer_provider,
            config=config or _default_forwarder_config(),
            default_model=default_model,
            default_provider=default_provider,
        )
        self._stop_event = threading.Event()

    def run_once(self) -> int:
        sessions = self._follower.poll()
        return self._export_sessions(sessions)

    def backfill(self) -> int:
        sessions = self._follower.backfill()
        return self._export_sessions(sessions)

    def flush(self) -> int:
        sessions = self._follower.flush()
        return self._export_sessions(sessions)

    def _export_sessions(self, sessions: Sequence[Any]) -> int:
        exported = 0
        for session in sessions:
            for turn in session.turns:
                self._exporter.export(turn)
                exported += 1
                if self._provider is not None:
                    self._provider.force_flush()
        return exported

    def run_forever(self) -> None:
        self.backfill()
        while not self._stop_event.is_set():
            self.run_once()
            self._stop_event.wait(self._poll_interval_s)

    def stop(self) -> None:
        self._stop_event.set()


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="codex-jsonl-forwarder",
        description=(
            "Watch persisted Codex session JSONL and export one OpenInference trace per turn."
        ),
    )
    parser.add_argument("--codex-home", default="~/.codex", help="Codex home directory.")
    parser.add_argument(
        "--state-path",
        default=None,
        help="Path for persisted offsets and emitted-turn state.",
    )
    parser.add_argument(
        "--poll-interval",
        type=float,
        default=1.0,
        help="Polling interval in seconds.",
    )
    parser.add_argument(
        "--turn-idle-timeout",
        type=float,
        default=30.0,
        help="Seconds before an incomplete flushed turn is labeled stale_partial.",
    )
    parser.add_argument(
        "--backfill-active-grace",
        type=float,
        default=300.0,
        help=(
            "Startup backfill keeps unterminated session files modified within this many seconds "
            "buffered as active."
        ),
    )
    parser.add_argument(
        "--health-port",
        type=int,
        default=None,
        help="Optional localhost port for a basic /healthz endpoint.",
    )
    args = parser.parse_args(argv)

    provider = None
    forwarder: CodexJsonlForwarder | None = None
    health_server: ThreadingHTTPServer | None = None
    try:
        provider = _configure_forwarder_tracer_provider()
        forwarder = CodexJsonlForwarder(
            codex_home=Path(args.codex_home).expanduser(),
            state_path=Path(args.state_path).expanduser()
            if args.state_path
            else default_state_path(os.environ),
            poll_interval_s=args.poll_interval,
            turn_idle_timeout_s=args.turn_idle_timeout,
            backfill_active_grace_s=args.backfill_active_grace,
            tracer_provider=provider,
        )
        if args.health_port is not None:
            health_server = _start_health_server(args.health_port)
        _install_signal_handlers(forwarder)
        forwarder.run_forever()
        return 0
    except KeyboardInterrupt:
        return 0
    except Exception as exc:
        print(f"codex-jsonl-forwarder: {exc}", file=sys.stderr)
        return 1
    finally:
        if health_server is not None:
            health_server.shutdown()
        if forwarder is not None:
            forwarder.flush()
        if provider is not None:
            provider.force_flush()
            provider.shutdown()


def _install_signal_handlers(forwarder: CodexJsonlForwarder) -> None:
    def _stop(_signum: int, _frame: object) -> None:
        forwarder.stop()

    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, _stop)


def _default_forwarder_config() -> CodexConfig:
    config = CodexConfig.from_env()
    overrides: dict[str, bool] = {}
    if "OPENINFERENCE_CODEX_CAPTURE_INPUTS" not in os.environ:
        overrides["capture_inputs"] = True
    if "OPENINFERENCE_CODEX_CAPTURE_OUTPUTS" not in os.environ:
        overrides["capture_outputs"] = True
    if "OPENINFERENCE_CODEX_CAPTURE_TOOL_OUTPUTS" not in os.environ:
        overrides["capture_tool_outputs"] = True
    if not overrides:
        return config
    return replace(config, **overrides)


def _configure_forwarder_tracer_provider() -> Any:
    exporter_name = os.getenv("OTEL_TRACES_EXPORTER", _TRACE_EXPORTER_NONE).strip().lower()
    if exporter_name == _TRACE_EXPORTER_NONE:
        return None
    if exporter_name not in {"", _TRACE_EXPORTER_OTLP}:
        raise RuntimeError(
            f"unsupported OTEL_TRACES_EXPORTER for codex-jsonl-forwarder: {exporter_name}"
        )

    protocol = _trace_protocol(os.environ)
    if protocol not in _HTTP_PROTOCOLS:
        raise RuntimeError(
            "codex-jsonl-forwarder currently supports OTLP traces over http/protobuf only"
        )

    from opentelemetry import trace
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor

    provider = TracerProvider(resource=Resource.create(_resource_attributes(os.environ)))
    provider.add_span_processor(
        SimpleSpanProcessor(OTLPSpanExporter(endpoint=_trace_endpoint(os.environ)))
    )
    trace.set_tracer_provider(provider)
    return provider


def _codex_config_defaults(codex_home: Path) -> tuple[str | None, str | None]:
    config = _load_codex_config(codex_home / "config.toml")
    profile_name = _optional_str(config.get("profile"))
    profile_config = _profile_config(config, profile_name)

    model = _first_config_str(profile_config, "model", "model_name", "modelName") or (
        _first_config_str(config, "model", "model_name", "modelName")
    )
    provider = _first_config_str(
        profile_config,
        "model_provider",
        "modelProvider",
        "provider",
    ) or _first_config_str(config, "model_provider", "modelProvider", "provider")
    return model, provider


def _load_codex_config(path: Path) -> Mapping[str, Any]:
    if not path.exists():
        return {}
    parser = _toml_parser()
    if parser is None:
        return {}
    try:
        with path.open("rb") as file:
            loaded = parser.load(file)
    except Exception:
        return {}
    return loaded if isinstance(loaded, Mapping) else {}


def _toml_parser() -> Any | None:
    try:
        import tomllib

        return tomllib
    except ModuleNotFoundError:
        try:
            import tomli

            return tomli
        except ModuleNotFoundError:
            return None


def _profile_config(config: Mapping[str, Any], profile_name: str | None) -> Mapping[str, Any]:
    if not profile_name:
        return {}
    profiles = config.get("profiles")
    if not isinstance(profiles, Mapping):
        return {}
    profile = profiles.get(profile_name)
    return profile if isinstance(profile, Mapping) else {}


def _first_config_str(config: Mapping[str, Any], *keys: str) -> str | None:
    for key in keys:
        value = _optional_str(config.get(key))
        if value is not None:
            return value
    return None


def _optional_str(value: object) -> str | None:
    if value in (None, ""):
        return None
    return str(value)


def _start_health_server(port: int) -> ThreadingHTTPServer:
    class _HealthHandler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            if self.path != "/healthz":
                self.send_response(404)
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"ok\n")

        def log_message(self, _format: str, *_args: object) -> None:
            return

    server = ThreadingHTTPServer(("127.0.0.1", port), _HealthHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


if __name__ == "__main__":
    raise SystemExit(main())
