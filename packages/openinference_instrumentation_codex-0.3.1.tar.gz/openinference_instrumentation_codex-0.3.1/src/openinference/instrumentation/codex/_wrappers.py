from __future__ import annotations

import inspect
from collections.abc import Callable
from functools import wraps
from typing import Any

from opentelemetry import trace
from opentelemetry.trace import SpanKind, Status, StatusCode

from ._attributes import map_codex_attributes
from ._config import CodexConfig
from ._version import __version__

WRAPPED_MARKER = "__openinference_codex_wrapped__"


def _build_operation_attributes(
    qualified_name: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    result: Any = None,
) -> dict[str, Any]:
    attrs: dict[str, Any] = {"codex.operation.name": qualified_name}
    if kwargs:
        attrs["invocation_parameters"] = kwargs
    if args:
        attrs["input"] = args[0] if len(args) == 1 else list(args)
    if isinstance(result, dict):
        attrs.update(result)
    elif result is not None:
        attrs["output"] = result
    return attrs


def _set_mapped_attributes(
    span: Any,
    span_name: str,
    attrs: dict[str, Any],
    config: CodexConfig,
) -> None:
    for key, value in map_codex_attributes(span_name, attrs, config).items():
        span.set_attribute(key, value)


def _set_span_error(span: Any, exc: Exception) -> None:
    span.record_exception(exc)
    span.set_status(Status(StatusCode.ERROR, str(exc)))


def build_wrapper(
    qualified_name: str,
    wrapped: Callable[..., Any],
    config: CodexConfig,
    tracer_provider: Any = None,
) -> Callable[..., Any]:
    if getattr(wrapped, WRAPPED_MARKER, False):
        return wrapped

    tracer = trace.get_tracer("openinference.instrumentation.codex", __version__, tracer_provider)

    if inspect.iscoroutinefunction(wrapped):

        @wraps(wrapped)
        async def _async_wrapped(*args: Any, **kwargs: Any) -> Any:
            with tracer.start_as_current_span(qualified_name, kind=SpanKind.CLIENT) as op_span:
                op_attrs = {
                    "span_kind": "CHAIN",
                    **_build_operation_attributes(qualified_name, args, kwargs),
                }
                _set_mapped_attributes(op_span, qualified_name, op_attrs, config)
                try:
                    result = await wrapped(*args, **kwargs)
                except Exception as exc:
                    _set_span_error(op_span, exc)
                    raise
                op_attrs = {
                    "span_kind": "CHAIN",
                    **_build_operation_attributes(qualified_name, args, kwargs, result),
                }
                _set_mapped_attributes(op_span, qualified_name, op_attrs, config)
                return result

        setattr(_async_wrapped, WRAPPED_MARKER, True)
        return _async_wrapped

    @wraps(wrapped)
    def _wrapped(*args: Any, **kwargs: Any) -> Any:
        with tracer.start_as_current_span(qualified_name, kind=SpanKind.CLIENT) as op_span:
            op_attrs = {
                "span_kind": "CHAIN",
                **_build_operation_attributes(qualified_name, args, kwargs),
            }
            _set_mapped_attributes(op_span, qualified_name, op_attrs, config)
            try:
                result = wrapped(*args, **kwargs)
            except Exception as exc:
                _set_span_error(op_span, exc)
                raise
            op_attrs = {
                "span_kind": "CHAIN",
                **_build_operation_attributes(qualified_name, args, kwargs, result),
            }
            _set_mapped_attributes(op_span, qualified_name, op_attrs, config)
            return result

    setattr(_wrapped, WRAPPED_MARKER, True)
    return _wrapped
