from __future__ import annotations

import json
import os
import time
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

from ._events import CodexUsage


@dataclass(frozen=True)
class PersistedRecord:
    source_type: str
    payload_type: str
    timestamp: str | None
    payload: Mapping[str, Any]
    turn_id: str
    observed_at_ns: int


@dataclass(frozen=True)
class PersistedTurn:
    session_id: str
    turn_id: str
    status: str
    records: tuple[PersistedRecord, ...]
    started_at_ns: int
    ended_at_ns: int
    source_path: Path
    session_meta: Mapping[str, Any] = field(default_factory=dict)
    turn_context: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class PersistedSession:
    session_id: str
    status: str
    turns: tuple[PersistedTurn, ...]
    started_at_ns: int
    ended_at_ns: int
    source_path: Path
    session_meta: Mapping[str, Any] = field(default_factory=dict)
    usage: CodexUsage = field(default_factory=CodexUsage)


@dataclass
class _BufferedTurn:
    session_id: str
    turn_id: str
    source_path: Path
    started_at_ns: int
    last_observed_at_ns: int
    records: list[PersistedRecord] = field(default_factory=list)
    turn_context: Mapping[str, Any] = field(default_factory=dict)


@dataclass
class _SourceState:
    session_id: str | None = None
    session_meta: Mapping[str, Any] = field(default_factory=dict)
    session_started_at_ns: int | None = None
    session_last_observed_at_ns: int | None = None
    active_turn_id: str | None = None
    active_turn_context: Mapping[str, Any] = field(default_factory=dict)


class PersistedSessionReader:
    def __init__(self, *, turn_idle_timeout_s: float = 30.0) -> None:
        self._turn_idle_timeout_ns = int(turn_idle_timeout_s * 1_000_000_000)
        self._source_state: dict[Path, _SourceState] = {}
        self._turns: dict[tuple[Path, str], _BufferedTurn] = {}
        self._completed_turns: dict[Path, list[PersistedTurn]] = {}

    def observe(
        self,
        raw: Mapping[str, Any],
        *,
        source_path: Path,
        observed_at_ns: int | None = None,
    ) -> list[PersistedSession]:
        if not isinstance(raw, Mapping):
            return []
        source_type = str(raw.get("type") or "")
        payload = _mapping(raw.get("payload"))
        payload_type = str(payload.get("type") or "")
        observed_at_ns = observed_at_ns or _timestamp_to_ns(raw.get("timestamp")) or time.time_ns()
        state = self._source_state.setdefault(source_path, _SourceState())
        if state.session_started_at_ns is None:
            state.session_started_at_ns = observed_at_ns
        state.session_last_observed_at_ns = observed_at_ns

        if source_type == "session_meta":
            state.session_id = _optional_str(payload.get("id")) or state.session_id
            state.session_meta = dict(payload)
            return []

        if source_type == "turn_context":
            turn_id = _optional_str(payload.get("turn_id") or payload.get("turnId"))
            if turn_id:
                state.active_turn_id = turn_id
                state.active_turn_context = dict(payload)
            return []

        session_status = _session_terminal_status(source_type, payload_type)
        if session_status is not None:
            self._finish_active_turns(
                source_path,
                session_status=session_status,
                ended_at_ns=observed_at_ns,
            )
            session = self._finish_session(source_path, session_status, observed_at_ns)
            return [session] if session is not None else []

        turn_id = _optional_str(payload.get("turn_id") or payload.get("turnId"))
        if payload_type == "task_started" and turn_id:
            state.active_turn_id = turn_id
        turn_id = turn_id or state.active_turn_id
        if not turn_id:
            return []

        buffered = self._turns.get((source_path, turn_id))
        if buffered is None:
            buffered = _BufferedTurn(
                session_id=state.session_id or source_path.stem,
                turn_id=turn_id,
                source_path=source_path,
                started_at_ns=observed_at_ns,
                last_observed_at_ns=observed_at_ns,
                turn_context=dict(state.active_turn_context),
            )
            self._turns[(source_path, turn_id)] = buffered
        buffered.last_observed_at_ns = observed_at_ns
        buffered.records.append(
            PersistedRecord(
                source_type=source_type,
                payload_type=payload_type or source_type,
                timestamp=_optional_str(raw.get("timestamp")),
                payload=dict(payload),
                turn_id=turn_id,
                observed_at_ns=observed_at_ns,
            )
        )

        terminal_status = _terminal_status(payload_type)
        if terminal_status is None:
            return []
        turn = self._finish(source_path, turn_id, terminal_status, observed_at_ns)
        return [_session_for_turn(turn, status="active")]

    def flush(
        self,
        *,
        now_ns: int | None = None,
        exclude_paths: set[Path] | None = None,
    ) -> list[PersistedSession]:
        now_ns = now_ns or time.time_ns()
        exclude_paths = exclude_paths or set()
        sessions: list[PersistedSession] = []
        paths = {
            *self._source_state.keys(),
            *(source_path for source_path, _turn_id in self._turns),
            *self._completed_turns.keys(),
        }
        for source_path in sorted(paths):
            if source_path in exclude_paths:
                continue
            self._finish_active_turns(
                source_path,
                session_status="shutdown",
                ended_at_ns=now_ns,
            )
            session = self._finish_session(source_path, "shutdown", now_ns)
            if session is not None:
                sessions.append(session)
        return sessions

    def _finish_active_turns(
        self,
        source_path: Path,
        *,
        session_status: str,
        ended_at_ns: int,
    ) -> None:
        for path, turn_id in list(self._turns):
            if path != source_path:
                continue
            buffered = self._turns[(path, turn_id)]
            status = _partial_turn_status(
                buffered,
                session_status=session_status,
                ended_at_ns=ended_at_ns,
                turn_idle_timeout_ns=self._turn_idle_timeout_ns,
            )
            turn = self._finish(path, turn_id, status, ended_at_ns)
            self._completed_turns.setdefault(path, []).append(turn)

    def _finish(
        self,
        source_path: Path,
        turn_id: str,
        status: str,
        ended_at_ns: int,
    ) -> PersistedTurn:
        buffered = self._turns.pop((source_path, turn_id))
        state = self._source_state[source_path]
        if state.active_turn_id == turn_id:
            state.active_turn_id = None
            state.active_turn_context = {}
        return PersistedTurn(
            session_id=buffered.session_id,
            turn_id=turn_id,
            status=status,
            records=tuple(buffered.records),
            started_at_ns=buffered.started_at_ns,
            ended_at_ns=ended_at_ns,
            source_path=source_path,
            session_meta=dict(state.session_meta),
            turn_context=dict(buffered.turn_context),
        )

    def _finish_session(
        self,
        source_path: Path,
        status: str,
        ended_at_ns: int,
    ) -> PersistedSession | None:
        turns = tuple(self._completed_turns.pop(source_path, []))
        if not turns:
            return None
        state = self._source_state.setdefault(source_path, _SourceState())
        session_id = state.session_id or turns[0].session_id or source_path.stem
        started_at_ns = min(
            [turn.started_at_ns for turn in turns]
            + ([state.session_started_at_ns] if state.session_started_at_ns is not None else [])
        )
        state.active_turn_id = None
        state.active_turn_context = {}
        return PersistedSession(
            session_id=session_id,
            status=status,
            turns=turns,
            started_at_ns=started_at_ns,
            ended_at_ns=ended_at_ns,
            source_path=source_path,
            session_meta=dict(state.session_meta),
            usage=_aggregate_usage(turns),
        )


@dataclass
class ForwarderState:
    offsets: dict[str, int] = field(default_factory=dict)
    emitted_turns: set[str] = field(default_factory=set)
    emitted_sessions: set[str] = field(default_factory=set)

    @classmethod
    def load(cls, path: Path) -> ForwarderState:
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return cls()
        except (OSError, json.JSONDecodeError):
            return cls()
        offsets = {
            str(key): int(value)
            for key, value in _mapping(raw.get("offsets")).items()
            if _is_int_like(value)
        }
        emitted_turns = {str(item) for item in raw.get("emitted_turns", []) if item}
        emitted_sessions = {str(item) for item in raw.get("emitted_sessions", []) if item}
        return cls(
            offsets=offsets,
            emitted_turns=emitted_turns,
            emitted_sessions=emitted_sessions,
        )

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(
                {
                    "offsets": self.offsets,
                    "emitted_turns": sorted(self.emitted_turns),
                    "emitted_sessions": sorted(self.emitted_sessions),
                },
                sort_keys=True,
            ),
            encoding="utf-8",
        )


class SessionFileFollower:
    def __init__(
        self,
        *,
        codex_home: Path,
        state_path: Path,
        turn_idle_timeout_s: float = 30.0,
        backfill_active_grace_s: float = 300.0,
    ) -> None:
        self._codex_home = codex_home.expanduser()
        self._state_path = state_path.expanduser()
        self._state = ForwarderState.load(self._state_path)
        self._reader = PersistedSessionReader(turn_idle_timeout_s=turn_idle_timeout_s)
        self._backfill_active_grace_ns = int(backfill_active_grace_s * 1_000_000_000)

    def poll(self, *, now_ns: int | None = None) -> list[PersistedSession]:
        del now_ns
        completed: list[PersistedSession] = []
        for path in self._discover_files():
            completed.extend(self._read_new_records(path))
        deduped = list(self._dedupe_sessions(completed))
        self._state.save(self._state_path)
        return deduped

    def backfill(self, *, now_ns: int | None = None) -> list[PersistedSession]:
        now_ns = now_ns or time.time_ns()
        completed: list[PersistedSession] = []
        paths = list(self._discover_files())
        exclude_paths = _unterminated_backfill_exclude_paths(
            paths,
            now_ns=now_ns,
            active_grace_ns=self._backfill_active_grace_ns,
        )
        for path in paths:
            completed.extend(self._read_new_records(path))
        completed.extend(self._reader.flush(now_ns=now_ns, exclude_paths=exclude_paths))
        deduped = list(self._dedupe_sessions(completed))
        self._state.save(self._state_path)
        return deduped

    def flush(self, *, now_ns: int | None = None) -> list[PersistedSession]:
        completed: list[PersistedSession] = []
        for path in self._discover_files():
            completed.extend(self._read_new_records(path))
        completed.extend(self._reader.flush(now_ns=now_ns))
        deduped = list(self._dedupe_sessions(completed))
        self._state.save(self._state_path)
        return deduped

    def _discover_files(self) -> Iterable[Path]:
        session_root = self._codex_home / "sessions"
        if not session_root.exists():
            return []
        return sorted(session_root.rglob("*.jsonl"))

    def _read_new_records(self, path: Path) -> list[PersistedSession]:
        key = str(path)
        offset = self._state.offsets.get(key, 0)
        completed: list[PersistedSession] = []
        try:
            with path.open("rb") as handle:
                handle.seek(offset)
                chunk = handle.read()
        except OSError:
            return completed
        if not chunk:
            return completed

        cursor = offset
        for raw_line in chunk.splitlines(keepends=True):
            if not raw_line.endswith(b"\n"):
                break
            cursor += len(raw_line)
            try:
                decoded = json.loads(raw_line.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
            if isinstance(decoded, Mapping):
                completed.extend(self._reader.observe(decoded, source_path=path))
        self._state.offsets[key] = cursor
        return completed

    def _dedupe_sessions(self, sessions: Iterable[PersistedSession]) -> Iterable[PersistedSession]:
        for session in sessions:
            new_turns = []
            for turn in session.turns:
                key = _turn_state_key(turn)
                if key in self._state.emitted_turns:
                    continue
                self._state.emitted_turns.add(key)
                new_turns.append(turn)
            if new_turns:
                yield replace(session, turns=tuple(new_turns))


def _turn_state_key(turn: PersistedTurn) -> str:
    return f"{turn.session_id}:{turn.turn_id}:{turn.source_path}"


def _session_for_turn(turn: PersistedTurn, *, status: str) -> PersistedSession:
    return PersistedSession(
        session_id=turn.session_id,
        status=status,
        turns=(turn,),
        started_at_ns=turn.started_at_ns,
        ended_at_ns=turn.ended_at_ns,
        source_path=turn.source_path,
        session_meta=dict(turn.session_meta),
        usage=_latest_turn_usage(turn),
    )


def _unterminated_backfill_exclude_paths(
    paths: list[Path],
    *,
    now_ns: int,
    active_grace_ns: int,
) -> set[Path]:
    candidates = [path for path in paths if not _file_has_session_terminal(path)]
    excluded = {
        path for path in candidates if now_ns - _mtime_ns(path) <= active_grace_ns
    }
    if candidates:
        excluded.add(max(candidates, key=lambda path: _mtime_ns(path)))
    return excluded


def _file_has_session_terminal(path: Path) -> bool:
    try:
        with path.open("rb") as handle:
            for raw_line in handle:
                try:
                    decoded = json.loads(raw_line.decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    continue
                if not isinstance(decoded, Mapping):
                    continue
                source_type = str(decoded.get("type") or "")
                payload = _mapping(decoded.get("payload"))
                payload_type = str(payload.get("type") or "")
                if _session_terminal_status(source_type, payload_type) is not None:
                    return True
    except OSError:
        return False
    return False


def _mtime_ns(path: Path) -> int:
    try:
        return path.stat().st_mtime_ns
    except OSError:
        return 0


def default_state_path(env: Mapping[str, str] | None = None) -> Path:
    env = env or os.environ
    state_home = env.get("XDG_STATE_HOME", "").strip()
    if state_home:
        return (
            Path(state_home).expanduser()
            / "openinference"
            / "codex-jsonl-forwarder"
            / "state.json"
        )
    return (
        Path.home()
        / ".local"
        / "state"
        / "openinference"
        / "codex-jsonl-forwarder"
        / "state.json"
    )


def _terminal_status(payload_type: str) -> str | None:
    if payload_type == "task_complete":
        return "completed"
    lowered = payload_type.lower()
    if any(token in lowered for token in ("interrupt", "cancel")):
        return "interrupted"
    if lowered in {"task_failed", "task_error", "turn_failed", "turn_error", "error"}:
        return "interrupted"
    return None


def _session_terminal_status(source_type: str, payload_type: str) -> str | None:
    completed = {
        "conversation_complete",
        "conversation_completed",
        "conversation_end",
        "conversation_ended",
        "session_close",
        "session_closed",
        "session_complete",
        "session_completed",
        "session_end",
        "session_ended",
        "session_terminate",
        "session_terminated",
    }
    interrupted = {
        "conversation_aborted",
        "conversation_canceled",
        "conversation_cancelled",
        "conversation_error",
        "conversation_failed",
        "conversation_interrupted",
        "session_aborted",
        "session_canceled",
        "session_cancelled",
        "session_error",
        "session_failed",
        "session_interrupted",
    }
    markers = {source_type.lower(), payload_type.lower()}
    if markers & interrupted:
        return "interrupted"
    if markers & completed:
        return "completed"
    return None


def _partial_turn_status(
    buffered: _BufferedTurn,
    *,
    session_status: str,
    ended_at_ns: int,
    turn_idle_timeout_ns: int,
) -> str:
    if session_status == "interrupted":
        return "interrupted"
    if ended_at_ns - buffered.last_observed_at_ns > turn_idle_timeout_ns:
        return "stale_partial"
    return "active_partial"


def _aggregate_usage(turns: tuple[PersistedTurn, ...]) -> CodexUsage:
    usage = CodexUsage()
    for turn in turns:
        usage = usage.add(_latest_turn_usage(turn))
    return usage


def _latest_turn_usage(turn: PersistedTurn) -> CodexUsage:
    usage = CodexUsage()
    for record in turn.records:
        if record.payload_type == "token_count":
            usage = CodexUsage.from_mapping(_token_usage(record.payload))
    return usage


def _token_usage(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    info = _mapping(payload.get("info"))
    return (
        _mapping(info.get("last_token_usage"))
        or _mapping(info.get("lastTokenUsage"))
        or _mapping(info.get("total_token_usage"))
        or _mapping(info.get("totalTokenUsage"))
        or _mapping(payload.get("usage"))
    )


def _timestamp_to_ns(value: Any) -> int | None:
    if not isinstance(value, str) or not value:
        return None
    from datetime import datetime

    try:
        normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
        return int(datetime.fromisoformat(normalized).timestamp() * 1_000_000_000)
    except ValueError:
        return None


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _optional_str(value: Any) -> str | None:
    if value is None or value == "":
        return None
    return str(value)


def _is_int_like(value: Any) -> bool:
    try:
        int(value)
    except (TypeError, ValueError):
        return False
    return True
