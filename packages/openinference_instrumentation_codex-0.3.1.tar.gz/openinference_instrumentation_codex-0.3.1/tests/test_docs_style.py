from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC_PATHS = [
    ROOT / "AGENTS.md",
    ROOT / "CHANGELOG.md",
    ROOT / "CONTRIBUTING.md",
    ROOT / "README.md",
    *(ROOT / "docs").glob("*.md"),
]


def test_markdown_docs_avoid_floater_paragraphs():
    violations: list[str] = []
    for path in sorted(DOC_PATHS):
        in_code = False
        prose_block: list[tuple[int, str]] = []
        for line_no, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            line = raw_line.strip()
            if line.startswith("```"):
                _record_block(path, prose_block, violations)
                prose_block = []
                in_code = not in_code
                continue
            if in_code or _is_structured_markdown(line):
                _record_block(path, prose_block, violations)
                prose_block = []
                continue
            prose_block.append((line_no, line))
        _record_block(path, prose_block, violations)

    assert not violations, "Markdown docs should use bullets, tables, or diagrams:\n" + "\n".join(
        violations
    )


def _is_structured_markdown(line: str) -> bool:
    if not line:
        return True
    return line.startswith(("#", "-", "* ", "|", ">", "::"))


def _record_block(path: Path, block: list[tuple[int, str]], violations: list[str]) -> None:
    if not block:
        return
    for line_no, _line in block:
        violations.append(f"{path.relative_to(ROOT)}:{line_no} unstructured prose line")
