from __future__ import annotations

from openinference.instrumentation.codex._model_mapping import phoenix_cost_model_name


def test_phoenix_cost_model_name_maps_codex_internal_aliases():
    assert phoenix_cost_model_name("codex-auto-review") == "gpt-5-codex"
    assert phoenix_cost_model_name("gpt-5.4-cyber") == "gpt-5.4"
    assert phoenix_cost_model_name("gpt-5.3-codex-spark-preview") == "gpt-5.3-codex"
    assert phoenix_cost_model_name("GPT-5.5") == "gpt-5.5"
