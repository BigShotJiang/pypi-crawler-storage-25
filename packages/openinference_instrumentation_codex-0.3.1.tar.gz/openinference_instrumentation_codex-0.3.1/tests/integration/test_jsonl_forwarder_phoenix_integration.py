from __future__ import annotations

import io
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

import pytest
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from openinference.instrumentation.codex import CodexConfig
from openinference.instrumentation.codex.jsonl_forwarder import CodexJsonlForwarder
from openinference.instrumentation.codex.proxy import observe_stream

FIXTURES = Path(__file__).resolve().parents[1] / "fixtures"
PROJECT_NAME_PREFIX = "codex-jsonl-forwarder-smoke"
PROXY_PROJECT_NAME_PREFIX = "codex-cli-jsonl-proxy-smoke"


@pytest.mark.integration
def test_jsonl_forwarder_exports_turn_trace_to_phoenix(tmp_path):
    collector_endpoint = os.getenv("PHOENIX_COLLECTOR_ENDPOINT")
    phoenix_base_url = os.getenv("PHOENIX_BASE_URL")
    if not collector_endpoint or not phoenix_base_url:
        pytest.skip("set PHOENIX_COLLECTOR_ENDPOINT and PHOENIX_BASE_URL to run")

    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

    project_name = f"{PROJECT_NAME_PREFIX}-{uuid.uuid4().hex}"
    provider = TracerProvider(
        resource=Resource.create({"openinference.project.name": project_name})
    )
    provider.add_span_processor(
        BatchSpanProcessor(OTLPSpanExporter(endpoint=collector_endpoint))
    )

    codex_home = tmp_path / "codex-home"
    session_dir = codex_home / "sessions" / "2026" / "05" / "05"
    session_dir.mkdir(parents=True)
    (session_dir / "rollout.jsonl").write_text(
        (FIXTURES / "session_jsonl" / "interactive_turn.jsonl").read_text(),
        encoding="utf-8",
    )

    forwarder = CodexJsonlForwarder(
        codex_home=codex_home,
        state_path=tmp_path / "state.json",
        tracer_provider=provider,
        config=CodexConfig(
            capture_inputs=True,
            capture_outputs=True,
            capture_tool_outputs=True,
        ),
    )
    assert forwarder.run_once() == 1
    assert forwarder.flush() == 0
    provider.force_flush()

    spans = _wait_for_spans(phoenix_base_url, project_name)
    root = next(span for span in spans if span["name"] == "codex.turn")
    shell_result = next(span for span in spans if span["name"] == "codex.shell.command.result")
    root_attrs = _attrs(root)
    shell_attrs = _attrs(shell_result)
    assert [span["name"] for span in spans].count("codex.session") == 0
    assert root_attrs["openinference.span.kind"] == "LLM"
    assert root_attrs["codex.turn.id"] == "turn-local-1"
    assert root_attrs["llm.model_name"] == "gpt-5"
    assert root_attrs["codex.model.cost_model"] == "gpt-5"
    assert root_attrs["llm.provider"] == "openai"
    assert root_attrs["llm.token_count.prompt"] == 10
    assert root_attrs["llm.token_count.prompt_details.cache_read"] == 3
    assert root_attrs["llm.token_count.completion"] == 4
    assert root_attrs["llm.token_count.total"] == 14
    assert not root.get("parent_span_id")
    assert shell_attrs["output.value"] == "README.md\n"

    costed_root = _wait_for_costed_turn(phoenix_base_url, project_name)
    assert costed_root["spanKind"] == "llm"
    assert json.loads(costed_root["attributes"])["llm"]["model_name"] == "gpt-5"
    _assert_cost_summary(costed_root["costSummary"], expected_tokens=14)


@pytest.mark.integration
def test_cli_jsonl_proxy_exports_costed_turn_trace_to_phoenix(tmp_path, monkeypatch):
    collector_endpoint = os.getenv("PHOENIX_COLLECTOR_ENDPOINT")
    phoenix_base_url = os.getenv("PHOENIX_BASE_URL")
    if not collector_endpoint or not phoenix_base_url:
        pytest.skip("set PHOENIX_COLLECTOR_ENDPOINT and PHOENIX_BASE_URL to run")

    project_name = f"{PROXY_PROJECT_NAME_PREFIX}-{uuid.uuid4().hex}"
    prompt_file = tmp_path / "prompt.md"
    prompt_file.write_text("Inspect the cluster", encoding="utf-8")

    monkeypatch.setenv("OTEL_TRACES_EXPORTER", "otlp")
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_TRACES_PROTOCOL", "http/protobuf")
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", collector_endpoint)
    monkeypatch.setenv("OTEL_RESOURCE_ATTRIBUTES", f"openinference.project.name={project_name}")
    monkeypatch.setenv("OPENINFERENCE_CODEX_CAPTURE_INPUTS", "true")
    monkeypatch.setenv("OPENINFERENCE_CODEX_CAPTURE_OUTPUTS", "true")
    monkeypatch.setenv("OPENINFERENCE_CODEX_PROVIDER", "openai")
    monkeypatch.setenv("CODEX_MODEL", "gpt-5.3-codex-spark-preview")

    events = io.StringIO((FIXTURES / "cli" / "simple_success.jsonl").read_text())
    assert (
        observe_stream(
            events,
            transport="cli-jsonl",
            forward_to=None,
            prompt_file=str(prompt_file),
        )
        == 0
    )

    costed_root = _wait_for_costed_turn(phoenix_base_url, project_name)
    attrs = json.loads(costed_root["attributes"])
    assert costed_root["name"] == "codex.turn"
    assert costed_root["spanKind"] == "llm"
    assert attrs["llm"]["model_name"] == "gpt-5.3-codex"
    assert attrs["codex"]["model"]["original"] == "gpt-5.3-codex-spark-preview"
    assert attrs["codex"]["model"]["cost_model"] == "gpt-5.3-codex"
    _assert_cost_summary(costed_root["costSummary"], expected_tokens=14)


def _wait_for_spans(phoenix_base_url: str, project_name: str) -> list[dict]:
    base_url = phoenix_base_url.rstrip("/")
    deadline = time.time() + 30
    while time.time() < deadline:
        project_identifier = _project_identifier(base_url, project_name) or project_name
        try:
            spans = _fetch_spans(base_url, project_identifier)
            if any(span.get("name") == "codex.turn" for span in spans):
                return spans
        except (TimeoutError, urllib.error.HTTPError, urllib.error.URLError):
            pass
        time.sleep(0.25)
    return []


def _wait_for_costed_turn(phoenix_base_url: str, project_name: str) -> dict:
    base_url = phoenix_base_url.rstrip("/")
    deadline = time.time() + 30
    while time.time() < deadline:
        try:
            turn = _fetch_costed_turn(base_url, project_name)
            if turn and _cost(turn.get("costSummary")) > 0:
                return turn
        except (TimeoutError, urllib.error.HTTPError, urllib.error.URLError, AssertionError):
            pass
        time.sleep(0.25)
    raise AssertionError(f"Phoenix did not report a costed codex.turn for {project_name}")


def _project_identifier(base_url: str, project_name: str) -> str | None:
    url = f"{base_url}/v1/projects"
    try:
        with urllib.request.urlopen(url, timeout=2) as response:  # noqa: S310
            payload = json.loads(response.read().decode("utf-8"))
    except (TimeoutError, urllib.error.HTTPError, urllib.error.URLError):
        return None
    for project in payload.get("data", []):
        if project.get("name") == project_name:
            return project.get("id") or project.get("name")
    return None


def _fetch_spans(base_url: str, project_identifier: str) -> list[dict]:
    encoded_project = urllib.parse.quote(project_identifier, safe="")
    url = f"{base_url}/v1/projects/{encoded_project}/spans/otlpv1?limit=1000"
    with urllib.request.urlopen(url, timeout=2) as response:  # noqa: S310
        payload = json.loads(response.read().decode("utf-8"))
    return payload.get("data", [])


def _fetch_costed_turn(base_url: str, project_name: str) -> dict | None:
    payload = _graphql(
        base_url,
        """
        query CostedTurn($name: String!) {
          getProjectByName(name: $name) {
            spans(first: 20, rootSpansOnly: true, sort: {col: startTime, dir: desc}) {
              edges {
                node {
                  name
                  spanKind
                  tokenCountTotal
                  attributes
                  costSummary {
                    total { tokens cost }
                    prompt { tokens cost }
                    completion { tokens cost }
                  }
                }
              }
            }
          }
        }
        """,
        {"name": project_name},
    )
    project = payload.get("data", {}).get("getProjectByName")
    if not project:
        return None
    for edge in project["spans"]["edges"]:
        node = edge["node"]
        if node["name"] == "codex.turn":
            return node
    return None


def _graphql(base_url: str, query: str, variables: dict) -> dict:
    request = urllib.request.Request(
        f"{base_url}/graphql",
        data=json.dumps({"query": query, "variables": variables}).encode("utf-8"),
        headers={"content-type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=2) as response:  # noqa: S310
        payload = json.loads(response.read().decode("utf-8"))
    if payload.get("errors"):
        raise AssertionError(payload["errors"])
    return payload


def _assert_cost_summary(cost_summary: dict, *, expected_tokens: int) -> None:
    assert cost_summary["total"]["tokens"] == expected_tokens
    assert cost_summary["prompt"]["tokens"] > 0
    assert cost_summary["completion"]["tokens"] > 0
    assert cost_summary["total"]["cost"] > 0
    assert cost_summary["prompt"]["cost"] > 0
    assert cost_summary["completion"]["cost"] > 0


def _cost(cost_summary: dict | None) -> float:
    if not cost_summary:
        return 0
    return float(cost_summary.get("total", {}).get("cost") or 0)


def _attrs(span: dict) -> dict[str, str | int | float | bool]:
    return {item["key"]: _attr_value(item["value"]) for item in span.get("attributes", [])}


def _attr_value(value: dict) -> str | int | float | bool:
    for key in (
        "stringValue",
        "intValue",
        "doubleValue",
        "boolValue",
        "string_value",
        "int_value",
        "double_value",
        "bool_value",
    ):
        if value.get(key) is not None:
            return value[key]
    raise AssertionError(f"attribute value is empty: {value}")
