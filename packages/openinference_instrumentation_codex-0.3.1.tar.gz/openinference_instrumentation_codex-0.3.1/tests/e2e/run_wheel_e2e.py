from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from opentelemetry.proto.collector.trace.v1.trace_service_pb2 import ExportTraceServiceRequest
from opentelemetry.proto.common.v1.common_pb2 import AnyValue

ROOT = Path(__file__).resolve().parents[2]
MOCK_BIN = ROOT / "tests" / "mocks" / "bin"


class _TraceSink:
    def __init__(self) -> None:
        self.requests: list[ExportTraceServiceRequest] = []
        self.lock = threading.Lock()

    def append(self, payload: bytes) -> None:
        request = ExportTraceServiceRequest()
        request.ParseFromString(payload)
        with self.lock:
            self.requests.append(request)

class _Handler(BaseHTTPRequestHandler):
    sink: _TraceSink

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("content-length", "0"))
        self.sink.append(self.rfile.read(length))
        self.send_response(200)
        self.end_headers()

    def log_message(self, *_args: Any) -> None:
        return


def main() -> int:
    sink = _TraceSink()
    handler = type("TraceHandler", (_Handler,), {"sink": sink})
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        env = {
            **os.environ,
            "PATH": f"{MOCK_BIN}:{os.environ['PATH']}",
            "OTEL_TRACES_EXPORTER": "otlp",
            "OTEL_EXPORTER_OTLP_TRACES_PROTOCOL": "http/protobuf",
            "OTEL_EXPORTER_OTLP_TRACES_ENDPOINT": (
                f"http://127.0.0.1:{server.server_port}/v1/traces"
            ),
            "OTEL_RESOURCE_ATTRIBUTES": "openinference.project.name=wheel-e2e",
            "OPENINFERENCE_CODEX_CAPTURE_INPUTS": "true",
            "OPENINFERENCE_CODEX_CAPTURE_OUTPUTS": "true",
            "OPENINFERENCE_CODEX_CAPTURE_TOOL_OUTPUTS": "true",
        }
        with tempfile.TemporaryDirectory() as tmp:
            prompt_file = Path(tmp) / "prompt.md"
            report_file = Path(tmp) / "final-report.md"
            prompt_file.write_text("fixture prompt", encoding="utf-8")
            prompt = prompt_file.open("r", encoding="utf-8")
            codex = subprocess.Popen(
                [
                    "codex",
                    "exec",
                    "--json",
                    "--output-last-message",
                    str(report_file),
                    "--skip-git-repo-check",
                    "-",
                ],
                stdin=prompt,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
                text=True,
            )
            assert codex.stdout is not None
            proxy = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "openinference.instrumentation.codex.proxy",
                    "--transport",
                    "cli-jsonl",
                    "--no-forward",
                    "--prompt-file",
                    str(prompt_file),
                ],
                stdin=codex.stdout,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
                text=True,
            )
            codex.stdout.close()
            prompt.close()
            _, codex_stderr = codex.communicate()
            _, proxy_stderr = proxy.communicate()
            if codex.returncode != 0:
                print(codex_stderr, file=sys.stderr)
                return int(codex.returncode or 1)
            if proxy.returncode != 0:
                print(proxy_stderr, file=sys.stderr)
                return int(proxy.returncode or 1)

        deadline = time.time() + 5
        spans = []
        while time.time() < deadline:
            spans = list(_decoded_spans(sink))
            if spans:
                break
            time.sleep(0.05)
        _assert_trace_tree(spans)
        print("[ok] wheel e2e emitted the expected OTLP tree")
        return 0
    finally:
        server.shutdown()
        thread.join(timeout=5)


def _decoded_spans(sink: _TraceSink) -> list[dict[str, Any]]:
    decoded: list[dict[str, Any]] = []
    with sink.lock:
        requests = list(sink.requests)
    for request in requests:
        for resource_spans in request.resource_spans:
            resource_attrs = {
                attr.key: _value(attr.value) for attr in resource_spans.resource.attributes
            }
            for scope_spans in resource_spans.scope_spans:
                for span in scope_spans.spans:
                    decoded.append(
                        {
                            "name": span.name,
                            "span_id": span.span_id.hex(),
                            "parent_span_id": span.parent_span_id.hex(),
                            "status": span.status.code,
                            "attrs": {attr.key: _value(attr.value) for attr in span.attributes},
                            "resource_attrs": resource_attrs,
                        }
                    )
    return decoded


def _value(value: AnyValue) -> Any:
    kind = value.WhichOneof("value")
    if kind == "string_value":
        return value.string_value
    if kind == "bool_value":
        return value.bool_value
    if kind == "int_value":
        return value.int_value
    if kind == "double_value":
        return value.double_value
    if kind == "array_value":
        return [_value(item) for item in value.array_value.values]
    return None


def _assert_trace_tree(spans: list[dict[str, Any]]) -> None:
    names = [span["name"] for span in spans]
    assert names.count("codex.turn") == 1, names
    for required in {
        "codex.tool.command_execution",
        "codex.file_change",
        "codex.tool.mcp",
        "codex.tool.web_search",
    }:
        assert required in names, names

    by_name = {span["name"]: span for span in spans}
    root = by_name["codex.turn"]
    command = by_name["codex.tool.command_execution"]
    assert command["parent_span_id"] == root["span_id"]
    assert root["attrs"]["llm.token_count.prompt"] == 10
    assert root["attrs"]["llm.token_count.prompt_details.cache_read"] == 3
    assert root["attrs"]["llm.token_count.completion"] == 4
    assert root["attrs"]["llm.token_count.total"] == 14
    assert root["attrs"]["codex.emission.transport"] == "cli-jsonl"
    assert command["attrs"]["tool.name"] == "command_execution"
    assert "[REDACTED]" in command["attrs"]["input.value"]
    assert root["resource_attrs"]["openinference.project.name"] == "wheel-e2e"
    assert all(name != "codex.cli.run" for name in names)


if __name__ == "__main__":
    raise SystemExit(main())
