from __future__ import annotations

import json
import os
from pathlib import Path

from openinference.instrumentation.codex._session_jsonl import (
    PersistedSessionReader,
    SessionFileFollower,
)

FIXTURES = Path(__file__).resolve().parent / "fixtures"


def _records(name: str) -> list[dict]:
    path = FIXTURES / "session_jsonl" / name
    return [json.loads(line) for line in path.read_text().splitlines()]


def _minimal_turn(turn_id: str, *, prompt_tokens: int = 1, output_tokens: int = 1) -> list[dict]:
    return [
        {
            "timestamp": "2026-05-05T20:00:00.100Z",
            "type": "event_msg",
            "payload": {"type": "task_started", "turn_id": turn_id},
        },
        {
            "timestamp": "2026-05-05T20:00:00.200Z",
            "type": "event_msg",
            "payload": {
                "type": "token_count",
                "info": {
                    "last_token_usage": {
                        "input_tokens": prompt_tokens,
                        "output_tokens": output_tokens,
                    }
                },
            },
        },
        {
            "timestamp": "2026-05-05T20:00:00.300Z",
            "type": "event_msg",
            "payload": {"type": "task_complete", "turn_id": turn_id},
        },
    ]


def _session_complete() -> dict:
    return {
        "timestamp": "2026-05-05T20:00:01.000Z",
        "type": "event_msg",
        "payload": {"type": "session_complete"},
    }


def test_real_rollout_envelopes_emit_completed_turn_immediately():
    reader = PersistedSessionReader()

    sessions = []
    for record in _records("interactive_turn.jsonl"):
        sessions.extend(reader.observe(record, source_path=Path("session.jsonl")))

    assert len(sessions) == 1
    session = sessions[0]
    assert session.session_id == "session-local-1"
    assert session.status == "active"
    assert session.usage.input_tokens == 10
    assert session.usage.cached_input_tokens == 3
    assert session.usage.output_tokens == 4
    assert session.usage.total_tokens == 14

    turn = session.turns[0]
    assert turn.session_id == "session-local-1"
    assert turn.turn_id == "turn-local-1"
    assert turn.status == "completed"
    assert [record.payload_type for record in turn.records] == [
        "task_started",
        "user_message",
        "message",
        "function_call",
        "function_call_output",
        "function_call",
        "function_call_output",
        "mcp_tool_call",
        "mcp_tool_call_end",
        "tool_search_call",
        "tool_search_output",
        "web_search_call",
        "reasoning",
        "token_count",
        "message",
        "task_complete",
    ]
    assert all(record.turn_id == "turn-local-1" for record in turn.records)
    assert reader.flush() == []


def test_explicit_session_terminal_emits_ordered_session_with_aggregate_usage():
    reader = PersistedSessionReader()
    source = Path("session.jsonl")
    records = [
        {
            "timestamp": "2026-05-05T20:00:00.000Z",
            "type": "session_meta",
            "payload": {"id": "session-local-2"},
        },
        *_minimal_turn("turn-1", prompt_tokens=2, output_tokens=3),
        *_minimal_turn("turn-2", prompt_tokens=5, output_tokens=7),
        _session_complete(),
    ]

    sessions = []
    for record in records:
        sessions.extend(reader.observe(record, source_path=source))

    assert len(sessions) == 2
    assert [session.session_id for session in sessions] == [
        "session-local-2",
        "session-local-2",
    ]
    assert [session.status for session in sessions] == ["active", "active"]
    assert [turn.turn_id for session in sessions for turn in session.turns] == [
        "turn-1",
        "turn-2",
    ]
    aggregate = sessions[0].usage.add(sessions[1].usage)
    assert aggregate.input_tokens == 7
    assert aggregate.output_tokens == 10
    assert aggregate.total_tokens == 17


def test_flush_labels_incomplete_turns_by_idle_timeout():
    reader = PersistedSessionReader(turn_idle_timeout_s=5)
    source = Path("session.jsonl")
    reader.observe(
        {
            "timestamp": "2026-05-05T20:00:00.000Z",
            "type": "session_meta",
            "payload": {"id": "session-local-2"},
        },
        source_path=source,
    )
    reader.observe(
        {
            "timestamp": "2026-05-05T20:00:00.100Z",
            "type": "event_msg",
            "payload": {"type": "task_started", "turn_id": "turn-interrupted"},
        },
        source_path=source,
    )
    interrupted = reader.observe(
        {
            "timestamp": "2026-05-05T20:00:00.200Z",
            "type": "event_msg",
            "payload": {"type": "task_interrupted", "turn_id": "turn-interrupted"},
        },
        source_path=source,
    )
    assert [turn.turn_id for turn in interrupted[0].turns] == ["turn-interrupted"]
    assert [turn.status for turn in interrupted[0].turns] == ["interrupted"]

    reader.observe(
        {
            "timestamp": "2026-05-05T20:00:01.000Z",
            "type": "event_msg",
            "payload": {"type": "task_started", "turn_id": "turn-stale"},
        },
        source_path=source,
        observed_at_ns=1_000_000_000,
    )
    stale = reader.flush(now_ns=7_000_000_001)
    assert [turn.turn_id for turn in stale[0].turns] == ["turn-stale"]
    assert [turn.status for turn in stale[0].turns] == ["stale_partial"]


def test_session_file_follower_waits_for_flush_and_dedupes_after_restart(tmp_path):
    codex_home = tmp_path / "codex-home"
    session_dir = codex_home / "sessions" / "2026" / "05" / "05"
    session_dir.mkdir(parents=True)
    session_path = session_dir / "rollout.jsonl"
    session_path.write_text(
        (FIXTURES / "session_jsonl" / "interactive_turn.jsonl").read_text(),
        encoding="utf-8",
    )
    state_path = tmp_path / "state.json"

    follower = SessionFileFollower(codex_home=codex_home, state_path=state_path)
    first = follower.poll()
    assert [session.session_id for session in first] == ["session-local-1"]
    assert [turn.turn_id for turn in first[0].turns] == ["turn-local-1"]

    restarted = SessionFileFollower(codex_home=codex_home, state_path=state_path)
    assert restarted.poll() == []
    assert restarted.flush() == []


def test_session_file_follower_backfills_archived_files_but_keeps_latest_unterminated(tmp_path):
    codex_home = tmp_path / "codex-home"
    session_dir = codex_home / "sessions" / "2026" / "05" / "05"
    session_dir.mkdir(parents=True)
    archived_path = session_dir / "archived.jsonl"
    active_path = session_dir / "active.jsonl"
    archived_path.write_text(
        '{"timestamp":"2026-05-05T20:00:00.000Z","type":"session_meta",'
        '"payload":{"id":"session-archived"}}\n'
        + "\n".join(json.dumps(record) for record in _minimal_turn("turn-archived"))
        + "\n",
        encoding="utf-8",
    )
    active_path.write_text(
        '{"timestamp":"2026-05-05T20:00:01.000Z","type":"session_meta",'
        '"payload":{"id":"session-active"}}\n'
        + "\n".join(json.dumps(record) for record in _minimal_turn("turn-active"))
        + "\n",
        encoding="utf-8",
    )
    os.utime(archived_path, ns=(1_000_000_000, 1_000_000_000))
    os.utime(active_path, ns=(2_000_000_000, 2_000_000_000))

    follower = SessionFileFollower(codex_home=codex_home, state_path=tmp_path / "state.json")

    backfilled = follower.backfill()
    assert [session.session_id for session in backfilled] == [
        "session-active",
        "session-archived",
    ]
    assert [turn.turn_id for session in backfilled for turn in session.turns] == [
        "turn-active",
        "turn-archived",
    ]

    flushed = follower.flush()
    assert flushed == []


def test_session_file_follower_backfill_keeps_recent_unterminated_files_buffered(tmp_path):
    codex_home = tmp_path / "codex-home"
    session_dir = codex_home / "sessions" / "2026" / "05" / "05"
    session_dir.mkdir(parents=True)
    old_path = session_dir / "old.jsonl"
    active_one = session_dir / "active-one.jsonl"
    active_two = session_dir / "active-two.jsonl"
    old_path.write_text(
        '{"timestamp":"2026-05-05T20:00:00.000Z","type":"session_meta",'
        '"payload":{"id":"session-old"}}\n'
        + "\n".join(json.dumps(record) for record in _minimal_turn("turn-old"))
        + "\n",
        encoding="utf-8",
    )
    active_one.write_text(
        '{"timestamp":"2026-05-05T20:00:01.000Z","type":"session_meta",'
        '"payload":{"id":"session-active-one"}}\n'
        + "\n".join(json.dumps(record) for record in _minimal_turn("turn-active-one"))
        + "\n",
        encoding="utf-8",
    )
    active_two.write_text(
        '{"timestamp":"2026-05-05T20:00:02.000Z","type":"session_meta",'
        '"payload":{"id":"session-active-two"}}\n'
        + "\n".join(json.dumps(record) for record in _minimal_turn("turn-active-two"))
        + "\n",
        encoding="utf-8",
    )
    os.utime(old_path, ns=(1_000_000_000, 1_000_000_000))
    os.utime(active_one, ns=(9_000_000_000, 9_000_000_000))
    os.utime(active_two, ns=(10_000_000_000, 10_000_000_000))
    follower = SessionFileFollower(
        codex_home=codex_home,
        state_path=tmp_path / "state.json",
        backfill_active_grace_s=5,
    )

    backfilled = follower.backfill(now_ns=10_000_000_000)
    assert [session.session_id for session in backfilled] == [
        "session-active-one",
        "session-active-two",
        "session-old",
    ]

    flushed = follower.flush(now_ns=11_000_000_000)
    assert flushed == []


def test_session_file_follower_emits_explicitly_terminated_session_during_poll(tmp_path):
    codex_home = tmp_path / "codex-home"
    session_dir = codex_home / "sessions" / "2026" / "05" / "05"
    session_dir.mkdir(parents=True)
    session_path = session_dir / "rollout.jsonl"
    session_path.write_text(
        (FIXTURES / "session_jsonl" / "interactive_turn.jsonl").read_text()
        + json.dumps(_session_complete())
        + "\n",
        encoding="utf-8",
    )

    follower = SessionFileFollower(codex_home=codex_home, state_path=tmp_path / "state.json")
    sessions = follower.poll()

    assert [session.session_id for session in sessions] == ["session-local-1"]
    assert sessions[0].status == "active"
