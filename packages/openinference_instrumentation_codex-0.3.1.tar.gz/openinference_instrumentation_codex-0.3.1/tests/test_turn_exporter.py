from __future__ import annotations

import json
from pathlib import Path

from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from openinference.instrumentation.codex import CodexConfig
from openinference.instrumentation.codex._session_jsonl import (
    PersistedRecord,
    PersistedSessionReader,
    PersistedTurn,
)
from openinference.instrumentation.codex._turn_exporter import CodexTurnExporter

FIXTURES = Path(__file__).resolve().parent / "fixtures"


def _provider_and_exporter():
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    return provider, exporter


def _turn():
    reader = PersistedSessionReader()
    sessions = []
    for line in (FIXTURES / "session_jsonl" / "interactive_turn.jsonl").read_text().splitlines():
        sessions.extend(reader.observe(json.loads(line), source_path=Path("session.jsonl")))
    return sessions[0].turns[0]


def test_turn_exporter_emits_one_turn_root_with_inspectable_children():
    provider, exporter = _provider_and_exporter()
    CodexTurnExporter(
        tracer_provider=provider,
        config=CodexConfig(
            capture_inputs=True,
            capture_outputs=True,
            capture_tool_outputs=True,
        ),
    ).export(_turn())

    spans = exporter.get_finished_spans()
    root = next(span for span in spans if span.name == "codex.turn")
    assert root.parent is None
    assert root.attributes["openinference.span.kind"] == "LLM"
    assert root.attributes["session.id"] == "session-local-1"
    assert root.attributes["codex.turn.id"] == "turn-local-1"
    assert root.attributes["codex.turn.status"] == "completed"
    assert root.attributes["llm.model_name"] == "gpt-5"
    assert root.attributes["codex.model.original"] == "gpt-5"
    assert root.attributes["codex.model.cost_model"] == "gpt-5"
    assert root.attributes["llm.provider"] == "openai"
    assert root.attributes["input.value"] == "Inspect the repo"
    assert root.attributes["output.value"] == "Done"
    assert root.attributes["llm.token_count.prompt"] == 10
    assert root.attributes["llm.token_count.prompt_details.cache_read"] == 3
    assert root.attributes["llm.token_count.completion"] == 4
    assert root.attributes["llm.token_count.total"] == 14

    by_name = {}
    for span in spans:
        by_name.setdefault(span.name, []).append(span)
    assert by_name["codex.message.user"][0].parent.span_id == root.context.span_id
    assert by_name["codex.message.assistant"][0].parent.span_id == root.context.span_id
    assert by_name["codex.reasoning"][0].parent.span_id == root.context.span_id
    assert by_name["codex.event.token_count"][0].parent.span_id == root.context.span_id
    assert by_name["codex.shell.command.result"][0].parent.span_id == by_name[
        "codex.shell.command"
    ][0].context.span_id
    assert by_name["codex.file_change.result"][0].parent.span_id == by_name[
        "codex.file_change"
    ][0].context.span_id
    assert by_name["codex.tool.mcp.result"][0].parent.span_id == by_name[
        "codex.tool.mcp"
    ][0].context.span_id
    assert by_name["codex.tool.search.result"][0].parent.span_id == by_name[
        "codex.tool.search"
    ][0].context.span_id
    assert by_name["codex.tool.web_search"][0].parent.span_id == root.context.span_id
    assert by_name["codex.shell.command.result"][0].attributes["output.value"] == "README.md\n"
    assert "Success. Updated" in by_name["codex.file_change.result"][0].attributes[
        "output.value"
    ]
    assert by_name["codex.tool.mcp.result"][0].attributes["output.value"] == (
        '{"ok": true, "text": "hello"}'
    )
    assert by_name["codex.tool.search.result"][0].attributes["output.value"] == (
        '[{"name": "github", "type": "namespace"}]'
    )
    assert by_name["codex.reasoning"][0].attributes["output.value"] == "Reviewing files"
    assert by_name["codex.reasoning"][0].attributes[
        "codex.reasoning.encrypted_present"
    ] is True
    assert by_name["codex.reasoning"][0].attributes[
        "codex.reasoning.encrypted_length"
    ] == len("opaque-reasoning")


def test_turn_exporter_respects_content_capture_flags():
    provider, exporter = _provider_and_exporter()
    CodexTurnExporter(tracer_provider=provider, config=CodexConfig()).export(_turn())

    spans = exporter.get_finished_spans()
    root = next(span for span in spans if span.name == "codex.turn")
    shell_result = next(span for span in spans if span.name == "codex.shell.command.result")
    assert "input.value" not in root.attributes
    assert "output.value" not in root.attributes
    assert "output.value" not in shell_result.attributes


def test_turn_exporter_finishes_open_tool_spans_for_partial_turns():
    provider, exporter = _provider_and_exporter()
    turn = PersistedTurn(
        session_id="session-local-2",
        turn_id="turn-partial",
        status="stale_partial",
        records=(
            PersistedRecord(
                source_type="response_item",
                payload_type="function_call",
                timestamp="2026-05-05T20:00:00.000Z",
                payload={"type": "function_call", "call_id": "call-open", "name": "exec_command"},
                turn_id="turn-partial",
                observed_at_ns=1_000_000_000,
            ),
        ),
        started_at_ns=1_000_000_000,
        ended_at_ns=2_000_000_000,
        source_path=Path("session.jsonl"),
    )

    CodexTurnExporter(tracer_provider=provider, config=CodexConfig()).export(turn)

    shell = next(
        span for span in exporter.get_finished_spans() if span.name == "codex.shell.command"
    )
    assert shell.end_time == 2_000_000_000


def test_turn_exporter_maps_openai_style_usage_for_phoenix_costs():
    provider, exporter = _provider_and_exporter()
    turn = PersistedTurn(
        session_id="session-local-cost",
        turn_id="turn-cost",
        status="completed",
        records=(
            PersistedRecord(
                source_type="event_msg",
                payload_type="token_count",
                timestamp=None,
                payload={
                    "type": "token_count",
                    "usage": {
                        "prompt_tokens": 100,
                        "completion_tokens": 25,
                        "total_tokens": 125,
                        "prompt_tokens_details": {"cached_tokens": 80},
                        "completion_tokens_details": {"reasoning_tokens": 5},
                    },
                },
                turn_id="turn-cost",
                observed_at_ns=1_000_000_000,
            ),
        ),
        started_at_ns=1_000_000_000,
        ended_at_ns=2_000_000_000,
        source_path=Path("session.jsonl"),
        session_meta={"model_provider": "openai"},
        turn_context={"model": "gpt-5.3-codex-spark-preview"},
    )

    CodexTurnExporter(tracer_provider=provider, config=CodexConfig()).export(turn)

    root = next(span for span in exporter.get_finished_spans() if span.name == "codex.turn")
    assert root.attributes["openinference.span.kind"] == "LLM"
    assert root.attributes["llm.model_name"] == "gpt-5.3-codex"
    assert root.attributes["codex.model.cost_model"] == "gpt-5.3-codex"
    assert root.attributes["llm.provider"] == "openai"
    assert root.attributes["llm.token_count.prompt"] == 100
    assert root.attributes["llm.token_count.prompt_details.cache_read"] == 80
    assert root.attributes["llm.token_count.completion"] == 25
    assert root.attributes["llm.token_count.total"] == 125
    assert root.attributes["codex.reasoning_output_tokens"] == 5
