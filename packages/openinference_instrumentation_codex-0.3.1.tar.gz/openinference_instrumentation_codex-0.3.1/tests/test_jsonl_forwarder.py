from __future__ import annotations

import json
import os
from pathlib import Path

from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from openinference.instrumentation.codex import CodexConfig
from openinference.instrumentation.codex.jsonl_forwarder import (
    CodexJsonlForwarder,
    _configure_forwarder_tracer_provider,
)

FIXTURES = Path(__file__).resolve().parent / "fixtures"


def _provider_and_exporter():
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    return provider, exporter


class _CountingProvider:
    def __init__(self, provider):
        self._provider = provider
        self.force_flush_count = 0

    def get_tracer(self, *args, **kwargs):
        return self._provider.get_tracer(*args, **kwargs)

    def force_flush(self, *args, **kwargs):
        self.force_flush_count += 1
        return self._provider.force_flush(*args, **kwargs)


def test_forwarder_run_once_waits_and_flushes_turn_roots(tmp_path, monkeypatch):
    monkeypatch.delenv("OPENINFERENCE_CODEX_CAPTURE_INPUTS", raising=False)
    monkeypatch.delenv("OPENINFERENCE_CODEX_CAPTURE_OUTPUTS", raising=False)
    monkeypatch.delenv("OPENINFERENCE_CODEX_CAPTURE_TOOL_OUTPUTS", raising=False)
    codex_home = tmp_path / "codex-home"
    session_dir = codex_home / "sessions" / "2026" / "05" / "05"
    session_dir.mkdir(parents=True)
    session_path = session_dir / "rollout.jsonl"
    session_path.write_text(
        (FIXTURES / "session_jsonl" / "interactive_turn.jsonl").read_text(),
        encoding="utf-8",
    )
    provider, exporter = _provider_and_exporter()

    forwarder = CodexJsonlForwarder(
        codex_home=codex_home,
        state_path=tmp_path / "state.json",
        tracer_provider=provider,
    )

    assert forwarder.run_once() == 1
    names = [span.name for span in exporter.get_finished_spans()]
    assert "codex.session" not in names
    assert names.count("codex.turn") == 1
    by_name = {}
    for span in exporter.get_finished_spans():
        by_name.setdefault(span.name, []).append(span)
    turn = by_name["codex.turn"][0]
    assert turn.parent is None
    assert turn.attributes["openinference.span.kind"] == "LLM"
    assert turn.attributes["llm.model_name"] == "gpt-5"
    assert turn.attributes["codex.model.cost_model"] == "gpt-5"
    assert turn.attributes["llm.provider"] == "openai"
    assert turn.attributes["llm.token_count.prompt"] == 10
    assert turn.attributes["llm.token_count.prompt_details.cache_read"] == 3
    assert turn.attributes["llm.token_count.completion"] == 4
    assert turn.attributes["llm.token_count.total"] == 14
    assert turn.attributes["input.value"] == "Inspect the repo"
    assert turn.attributes["output.value"] == "Done"
    assert by_name["codex.shell.command.result"][0].attributes["output.value"] == "README.md\n"


def test_forwarder_flushes_provider_after_each_exported_turn(tmp_path):
    codex_home = tmp_path / "codex-home"
    session_dir = codex_home / "sessions" / "2026" / "05" / "05"
    session_dir.mkdir(parents=True)
    (session_dir / "rollout.jsonl").write_text(
        '{"timestamp":"2026-05-05T20:00:00.000Z","type":"session_meta",'
        '"payload":{"id":"session-running"}}\n'
        '{"timestamp":"2026-05-05T20:00:00.100Z","type":"event_msg",'
        '"payload":{"type":"task_started","turn_id":"turn-1"}}\n'
        '{"timestamp":"2026-05-05T20:00:00.200Z","type":"event_msg",'
        '"payload":{"type":"task_complete","turn_id":"turn-1"}}\n'
        '{"timestamp":"2026-05-05T20:00:01.100Z","type":"event_msg",'
        '"payload":{"type":"task_started","turn_id":"turn-2"}}\n'
        '{"timestamp":"2026-05-05T20:00:01.200Z","type":"event_msg",'
        '"payload":{"type":"task_complete","turn_id":"turn-2"}}\n'
        '{"timestamp":"2026-05-05T20:00:02.000Z","type":"event_msg",'
        '"payload":{"type":"session_complete"}}\n',
        encoding="utf-8",
    )
    provider, exporter = _provider_and_exporter()
    counting_provider = _CountingProvider(provider)

    forwarder = CodexJsonlForwarder(
        codex_home=codex_home,
        state_path=tmp_path / "state.json",
        tracer_provider=counting_provider,
    )

    assert forwarder.run_once() == 2
    assert [span.name for span in exporter.get_finished_spans()].count("codex.turn") == 2
    assert counting_provider.force_flush_count == 2


def test_forwarder_tracer_provider_uses_immediate_export(monkeypatch):
    monkeypatch.setenv("OTEL_TRACES_EXPORTER", "otlp")
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", "http://collector/v1/traces")
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_TRACES_PROTOCOL", "http/protobuf")

    provider = _configure_forwarder_tracer_provider()

    active = provider._active_span_processor
    processors = active._span_processors
    assert len(processors) == 1
    assert processors[0].__class__.__name__ == "SimpleSpanProcessor"


def test_forwarder_run_once_exports_explicitly_terminated_turn_roots(tmp_path):
    codex_home = tmp_path / "codex-home"
    session_dir = codex_home / "sessions" / "2026" / "05" / "05"
    session_dir.mkdir(parents=True)
    (session_dir / "rollout.jsonl").write_text(
        (FIXTURES / "session_jsonl" / "interactive_turn.jsonl").read_text()
        + '{"timestamp":"2026-05-05T20:00:02.000Z","type":"event_msg",'
        + '"payload":{"type":"session_complete"}}\n',
        encoding="utf-8",
    )
    provider, exporter = _provider_and_exporter()

    forwarder = CodexJsonlForwarder(
        codex_home=codex_home,
        state_path=tmp_path / "state.json",
        tracer_provider=provider,
        config=CodexConfig(capture_inputs=True, capture_outputs=True),
    )

    assert forwarder.run_once() == 1
    names = [span.name for span in exporter.get_finished_spans()]
    assert "codex.session" not in names
    assert names.count("codex.turn") == 1
    turn = next(span for span in exporter.get_finished_spans() if span.name == "codex.turn")
    assert turn.parent is None
    assert turn.attributes["openinference.span.kind"] == "LLM"


def test_forwarder_repeated_run_once_buffers_session_until_terminal(tmp_path):
    codex_home = tmp_path / "codex-home"
    session_dir = codex_home / "sessions" / "2026" / "05" / "05"
    session_dir.mkdir(parents=True)
    session_path = session_dir / "rollout.jsonl"
    session_path.write_text(
        '{"timestamp":"2026-05-05T20:00:00.000Z","type":"session_meta",'
        '"payload":{"id":"session-running"}}\n'
        '{"timestamp":"2026-05-05T20:00:00.100Z","type":"event_msg",'
        '"payload":{"type":"task_started","turn_id":"turn-1"}}\n'
        '{"timestamp":"2026-05-05T20:00:00.200Z","type":"event_msg",'
        '"payload":{"type":"task_complete","turn_id":"turn-1"}}\n',
        encoding="utf-8",
    )
    provider, exporter = _provider_and_exporter()
    forwarder = CodexJsonlForwarder(
        codex_home=codex_home,
        state_path=tmp_path / "state.json",
        tracer_provider=provider,
    )

    assert forwarder.run_once() == 1
    assert [span.name for span in exporter.get_finished_spans()].count("codex.turn") == 1

    with session_path.open("a", encoding="utf-8") as file:
        file.write(
            '{"timestamp":"2026-05-05T20:00:01.100Z","type":"event_msg",'
            '"payload":{"type":"task_started","turn_id":"turn-2"}}\n'
            '{"timestamp":"2026-05-05T20:00:01.200Z","type":"event_msg",'
            '"payload":{"type":"task_complete","turn_id":"turn-2"}}\n'
        )
    assert forwarder.run_once() == 1
    assert [span.name for span in exporter.get_finished_spans()].count("codex.turn") == 2

    with session_path.open("a", encoding="utf-8") as file:
        file.write(json.dumps({"type": "event_msg", "payload": {"type": "session_complete"}}))
        file.write("\n")
    assert forwarder.run_once() == 0
    assert [span.name for span in exporter.get_finished_spans()].count("codex.session") == 0
    assert [span.name for span in exporter.get_finished_spans()].count("codex.turn") == 2


def test_forwarder_backfill_exports_archived_and_buffers_latest_active(tmp_path):
    codex_home = tmp_path / "codex-home"
    session_dir = codex_home / "sessions" / "2026" / "05" / "05"
    session_dir.mkdir(parents=True)
    archived_path = session_dir / "archived.jsonl"
    active_path = session_dir / "active.jsonl"
    archived_path.write_text(
        '{"timestamp":"2026-05-05T20:00:00.000Z","type":"session_meta",'
        '"payload":{"id":"session-archived"}}\n'
        '{"timestamp":"2026-05-05T20:00:00.100Z","type":"event_msg",'
        '"payload":{"type":"task_started","turn_id":"turn-archived"}}\n'
        '{"timestamp":"2026-05-05T20:00:00.200Z","type":"event_msg",'
        '"payload":{"type":"task_complete","turn_id":"turn-archived"}}\n',
        encoding="utf-8",
    )
    active_path.write_text(
        '{"timestamp":"2026-05-05T20:00:01.000Z","type":"session_meta",'
        '"payload":{"id":"session-active"}}\n'
        '{"timestamp":"2026-05-05T20:00:01.100Z","type":"event_msg",'
        '"payload":{"type":"task_started","turn_id":"turn-active"}}\n'
        '{"timestamp":"2026-05-05T20:00:01.200Z","type":"event_msg",'
        '"payload":{"type":"task_complete","turn_id":"turn-active"}}\n',
        encoding="utf-8",
    )
    os.utime(archived_path, ns=(1_000_000_000, 1_000_000_000))
    os.utime(active_path, ns=(2_000_000_000, 2_000_000_000))
    provider, exporter = _provider_and_exporter()
    forwarder = CodexJsonlForwarder(
        codex_home=codex_home,
        state_path=tmp_path / "state.json",
        tracer_provider=provider,
    )

    assert forwarder.backfill() == 2
    turns = [span for span in exporter.get_finished_spans() if span.name == "codex.turn"]
    assert [span.attributes["codex.turn.id"] for span in turns] == [
        "turn-active",
        "turn-archived",
    ]
    assert turns[0].parent is None

    assert forwarder.flush() == 0
    assert [span.name for span in exporter.get_finished_spans()].count("codex.session") == 0
    turns = [span for span in exporter.get_finished_spans() if span.name == "codex.turn"]
    assert [span.attributes["codex.turn.id"] for span in turns] == [
        "turn-active",
        "turn-archived",
    ]


def test_forwarder_default_capture_can_be_disabled_with_env(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENINFERENCE_CODEX_CAPTURE_INPUTS", "false")
    monkeypatch.setenv("OPENINFERENCE_CODEX_CAPTURE_OUTPUTS", "false")
    monkeypatch.setenv("OPENINFERENCE_CODEX_CAPTURE_TOOL_OUTPUTS", "false")
    codex_home = tmp_path / "codex-home"
    session_dir = codex_home / "sessions" / "2026" / "05" / "05"
    session_dir.mkdir(parents=True)
    session_path = session_dir / "rollout.jsonl"
    session_path.write_text(
        (FIXTURES / "session_jsonl" / "interactive_turn.jsonl").read_text(),
        encoding="utf-8",
    )
    provider, exporter = _provider_and_exporter()

    forwarder = CodexJsonlForwarder(
        codex_home=codex_home,
        state_path=tmp_path / "state.json",
        tracer_provider=provider,
    )

    assert forwarder.flush() == 1
    turn = next(span for span in exporter.get_finished_spans() if span.name == "codex.turn")
    shell_result = next(
        span for span in exporter.get_finished_spans() if span.name == "codex.shell.command.result"
    )
    assert "input.value" not in turn.attributes
    assert "output.value" not in turn.attributes
    assert "output.value" not in shell_result.attributes


def test_forwarder_uses_codex_config_model_defaults(tmp_path, monkeypatch):
    monkeypatch.delenv("OPENINFERENCE_CODEX_MODEL", raising=False)
    monkeypatch.delenv("CODEX_MODEL", raising=False)
    monkeypatch.delenv("OPENINFERENCE_CODEX_PROVIDER", raising=False)
    codex_home = tmp_path / "codex-home"
    session_dir = codex_home / "sessions" / "2026" / "05" / "05"
    session_dir.mkdir(parents=True)
    fixture = (FIXTURES / "session_jsonl" / "interactive_turn.jsonl").read_text()
    fixture = fixture.replace(',"model_provider":"openai"', "")
    fixture = fixture.replace(',"model":"gpt-5"', "")
    (session_dir / "rollout.jsonl").write_text(fixture, encoding="utf-8")
    (codex_home / "config.toml").write_text(
        'profile = "work"\n\n'
        "[profiles.work]\n"
        'model = "gpt-5.3-codex-spark-preview"\n'
        'model_provider = "openai"\n',
        encoding="utf-8",
    )
    provider, exporter = _provider_and_exporter()

    forwarder = CodexJsonlForwarder(
        codex_home=codex_home,
        state_path=tmp_path / "state.json",
        tracer_provider=provider,
    )

    assert forwarder.flush() == 1
    turn = next(span for span in exporter.get_finished_spans() if span.name == "codex.turn")
    assert [span.name for span in exporter.get_finished_spans()].count("codex.session") == 0
    assert turn.attributes["llm.model_name"] == "gpt-5.3-codex"
    assert turn.attributes["codex.model.original"] == "gpt-5.3-codex-spark-preview"
    assert turn.attributes["codex.model.cost_model"] == "gpt-5.3-codex"
    assert turn.attributes["llm.provider"] == "openai"


def test_forwarder_dedupes_by_turn_after_restart(tmp_path):
    codex_home = tmp_path / "codex-home"
    session_dir = codex_home / "sessions" / "2026" / "05" / "05"
    session_dir.mkdir(parents=True)
    session_path = session_dir / "rollout.jsonl"
    session_path.write_text(
        (FIXTURES / "session_jsonl" / "interactive_turn.jsonl").read_text(),
        encoding="utf-8",
    )
    provider, exporter = _provider_and_exporter()
    state_path = tmp_path / "state.json"

    first = CodexJsonlForwarder(
        codex_home=codex_home,
        state_path=state_path,
        tracer_provider=provider,
    )
    assert first.flush() == 1

    restarted = CodexJsonlForwarder(
        codex_home=codex_home,
        state_path=state_path,
        tracer_provider=provider,
    )
    assert restarted.flush() == 0
    assert [span.name for span in exporter.get_finished_spans()].count("codex.turn") == 1
    state = json.loads(state_path.read_text(encoding="utf-8"))
    assert state["emitted_turns"] == [f"session-local-1:turn-local-1:{session_path}"]


def test_forwarder_run_once_returns_zero_when_no_sessions_exist(tmp_path):
    forwarder = CodexJsonlForwarder(
        codex_home=tmp_path / "missing",
        state_path=tmp_path / "state.json",
    )

    assert forwarder.run_once() == 0
    assert forwarder.flush() == 0
