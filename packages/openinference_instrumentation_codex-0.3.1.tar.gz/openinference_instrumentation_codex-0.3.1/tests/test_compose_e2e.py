from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_compose_e2e_installs_currently_built_wheel():
    compose = (ROOT / "docker-compose.phoenix.yml").read_text(encoding="utf-8")
    runner = (ROOT / "scripts" / "run_compose_e2e.py").read_text(encoding="utf-8")

    assert 'command: ["python", "scripts/run_compose_e2e.py"]' in compose
    assert '"${COMPOSE_PHOENIX_PORT:-6007}:6006"' in compose
    assert "openinference-instrumentation-codex[otlp,test]==" not in compose
    assert '"pip", "wheel", ".", "-w", str(DIST_DIR)' in runner
    assert "openinference_instrumentation_codex-*.whl" in runner
    assert 'f"{wheel}[otlp,test]"' in runner
    assert "tests/e2e/run_wheel_e2e.py" in runner
    assert "scripts/run_live_codex_smoke.py" in runner
