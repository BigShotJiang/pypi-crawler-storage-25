from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOWS = ROOT / ".github" / "workflows"


def _read_workflows() -> str:
    return "\n".join(
        path.read_text(encoding="utf-8")
        for path in sorted(WORKFLOWS.glob("*.yaml"))
    )


def test_makefile_exposes_local_phoenix_jsonl_targets():
    makefile = (ROOT / "Makefile").read_text(encoding="utf-8")

    assert "phoenix-jsonl-start:" in makefile
    assert "phoenix-jsonl-stop:" in makefile
    assert "phoenix-jsonl-status:" in makefile
    assert "jsonl-forwarder-start:" in makefile
    assert "scripts/spawn_jsonl_forwarder.py" in makefile
    assert "--backfill-active-grace" in makefile
    assert "RUN_DIR ?= .run" in makefile
    assert "codex-jsonl-forwarder-state.json" in makefile
    assert "/private/tmp" not in makefile
    assert "nohup" not in makefile


def test_makefile_exposes_standard_validation_targets():
    makefile = (ROOT / "Makefile").read_text(encoding="utf-8")

    for target in (
        "setup:",
        "lint:",
        "test:",
        "test-unit:",
        "test-integration:",
        "test-jsonl-forwarder-phoenix:",
        "test-e2e:",
        "compose-e2e:",
        "build:",
        "flight-check:",
    ):
        assert target in makefile
    assert "DOCKER_COMPOSE ?=" in makefile
    assert "uv sync --extra test" in makefile
    assert "uv run ruff check ." in makefile
    assert "uv run pytest" in makefile
    assert "uv build" in makefile
    assert "docker-compose.phoenix.yml" in makefile
    assert "flight-check: setup lint test build compose-e2e" in makefile


def test_github_workflows_use_make_targets_for_local_developer_commands():
    workflows = _read_workflows()

    assert "run: make setup" in workflows
    assert "run: make lint" in workflows
    assert "run: make test" in workflows
    assert "run: make test-jsonl-forwarder-phoenix" in workflows
    assert "run: make compose-e2e" in workflows
    assert "run: make build" in workflows
    assert "run: uv sync" not in workflows
    assert "run: uv run" not in workflows
    assert "run: uv build" not in workflows
    assert "run: docker compose" not in workflows
    assert "run: docker-compose" not in workflows


def test_readme_documents_local_phoenix_jsonl_target():
    readme = (ROOT / "README.md").read_text(encoding="utf-8")

    assert "make phoenix-jsonl-start" in readme
    assert ".run/codex-jsonl-forwarder-state.json" in readme
    assert "codex-local-jsonl-forwarder" in readme
