from __future__ import annotations

from pathlib import Path

from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace.status import StatusCode

from openinference.instrumentation.codex import CodexCliJsonlAdapter, CodexConfig, CodexTraceBuilder

FIXTURES = Path(__file__).resolve().parent / "fixtures"


def _provider_and_exporter():
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    return provider, exporter


def _span_map(spans):
    return {span.name: span for span in spans}


def _feed_cli_fixture(name: str, config: CodexConfig | None = None):
    provider, exporter = _provider_and_exporter()
    builder = CodexTraceBuilder(tracer_provider=provider, config=config)
    adapter = CodexCliJsonlAdapter(builder)
    for index, line in enumerate((FIXTURES / "cli" / name).read_text().splitlines(), start=1):
        adapter.observe_line(line, observed_at_ns=index * 1_000_000)
    builder.finish()
    return exporter.get_finished_spans()


def test_cli_fixture_builds_one_turn_root_with_real_tool_children():
    spans = _feed_cli_fixture(
        "simple_success.jsonl",
        CodexConfig(capture_inputs=True, capture_outputs=True),
    )
    names = [span.name for span in spans]
    assert names.count("codex.turn") == 1
    assert "codex.tool.command_execution" in names
    assert "codex.file_change" in names
    assert "codex.tool.mcp" in names
    assert "codex.tool.web_search" in names

    span_by_name = _span_map(spans)
    root = span_by_name["codex.turn"]
    command = span_by_name["codex.tool.command_execution"]
    assert root.parent is None
    assert command.parent.span_id == root.context.span_id
    assert command.end_time - command.start_time == 1_000_000
    assert root.attributes["session.id"] == "thread-cli-1"
    assert root.attributes["llm.token_count.prompt"] == 10
    assert root.attributes["llm.token_count.prompt_details.cache_read"] == 3
    assert root.attributes["llm.token_count.completion"] == 4
    assert root.attributes["llm.token_count.total"] == 14
    assert command.attributes["tool.name"] == "command_execution"
    assert root.attributes["output.value"] == "done"
    assert root.attributes["openinference.span.kind"] == "LLM"
    assert root.attributes["llm.output_messages.0.message.role"] == "assistant"
    assert root.attributes["llm.output_messages.0.message.content"] == "done"


def test_cli_failure_marks_tool_and_turn_root():
    spans = _feed_cli_fixture("tool_failure.jsonl")
    span_by_name = _span_map(spans)
    assert span_by_name["codex.tool.command_execution"].status.status_code is StatusCode.ERROR
    assert span_by_name["codex.turn"].status.status_code is StatusCode.ERROR


def test_cli_redaction_is_preserved():
    spans = _feed_cli_fixture(
        "redaction.jsonl",
        CodexConfig(capture_inputs=True, capture_outputs=True, redact_inputs=True),
    )
    command = _span_map(spans)["codex.tool.command_execution"]
    assert "[REDACTED]" in command.attributes["input.value"]
    assert "[REDACTED]" in command.attributes["tool.parameters"]


def test_cli_adapter_stabilizes_implicit_turn_ids():
    spans = _feed_cli_fixture("implicit_turn_ids.jsonl")
    span_by_name = _span_map(spans)
    assert span_by_name["codex.turn"].attributes["codex.turn.id"] == "turn-1"
    assert span_by_name["codex.tool.command_execution"].parent.span_id == span_by_name[
        "codex.turn"
    ].context.span_id


def test_cli_stream_emits_one_root_trace_per_turn():
    provider, exporter = _provider_and_exporter()
    builder = CodexTraceBuilder(tracer_provider=provider)
    adapter = CodexCliJsonlAdapter(builder)
    adapter.observe_line('{"type":"thread.started","thread_id":"thread-1"}')
    adapter.observe_line('{"type":"turn.started","turn_id":"turn-1","thread_id":"thread-1"}')
    adapter.observe_line('{"type":"turn.completed","turn_id":"turn-1","thread_id":"thread-1"}')
    adapter.observe_line('{"type":"turn.started","turn_id":"turn-2","thread_id":"thread-1"}')
    adapter.observe_line('{"type":"turn.completed","turn_id":"turn-2","thread_id":"thread-1"}')
    builder.finish()

    roots = [span for span in exporter.get_finished_spans() if span.name == "codex.turn"]
    assert len(roots) == 2
    assert [root.attributes["codex.turn.id"] for root in roots] == ["turn-1", "turn-2"]
    assert all(root.parent is None for root in roots)
    assert {root.attributes["session.id"] for root in roots} == {"thread-1"}


def test_cli_item_updated_refreshes_open_span_without_finishing_it():
    spans = _feed_cli_fixture("item_updated.jsonl", CodexConfig(capture_tool_outputs=True))
    span_by_name = _span_map(spans)
    command = span_by_name["codex.tool.command_execution"]
    assert command.attributes["output.value"] == "hello"
    assert command.attributes["codex.command.exit_code"] == 0
    assert span_by_name["codex.turn"].attributes["codex.reasoning_output_tokens"] == 3


def test_root_seed_attributes_flow_into_turn_llm_cost_fields():
    provider, exporter = _provider_and_exporter()
    builder = CodexTraceBuilder(
        tracer_provider=provider,
        config=CodexConfig(capture_inputs=True),
        root_attributes={
            "input": "Inspect the cluster",
            "model": "gpt-5.3-codex-spark-preview",
            "provider": "openai",
            "llm_input_messages": [{"role": "user", "content": "Inspect the cluster"}],
        },
    )
    adapter = CodexCliJsonlAdapter(builder)
    adapter.observe_line('{"type":"thread.started","thread_id":"thread-1"}')
    adapter.observe_line('{"type":"turn.started","turn_id":"turn-1","thread_id":"thread-1"}')
    builder.finish()

    span_by_name = _span_map(exporter.get_finished_spans())
    turn = span_by_name["codex.turn"]
    assert turn.attributes["input.value"] == "Inspect the cluster"
    assert turn.attributes["llm.model_name"] == "gpt-5.3-codex"
    assert turn.attributes["codex.model.original"] == "gpt-5.3-codex-spark-preview"
    assert turn.attributes["codex.model.cost_model"] == "gpt-5.3-codex"
    assert turn.attributes["llm.provider"] == "openai"
    assert turn.attributes["llm.input_messages.0.message.role"] == "user"


def test_codexops_job_identity_is_preserved_on_root_span():
    provider, exporter = _provider_and_exporter()
    builder = CodexTraceBuilder(
        tracer_provider=provider,
        root_attributes={
            "codexops.investigation.name": "investigation-otel",
            "codexops.job.name": "investigation-otel-job",
            "codexops.result.source.name": "result-otel",
            "k8s.pod.name": "investigation-otel-job-abcde",
        },
    )
    adapter = CodexCliJsonlAdapter(builder)
    adapter.observe_line('{"type":"thread.started","thread_id":"thread-1"}')
    adapter.observe_line('{"type":"turn.started","turn_id":"turn-1","thread_id":"thread-1"}')
    builder.finish()

    root = _span_map(exporter.get_finished_spans())["codex.turn"]
    assert root.attributes["codexops.investigation.name"] == "investigation-otel"
    assert root.attributes["codexops.job.name"] == "investigation-otel-job"
    assert root.attributes["codexops.result.source.name"] == "result-otel"
    assert root.attributes["k8s.pod.name"] == "investigation-otel-job-abcde"
