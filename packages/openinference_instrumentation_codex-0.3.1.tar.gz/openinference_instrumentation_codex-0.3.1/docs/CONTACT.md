# Maintainer Contact

## Scope

- Use this private maintainer contact only for:
- [Security vulnerability reports](SECURITY.md#reporting-a-vulnerability)
- [Code of Conduct reports](CODE_OF_CONDUCT.md#reporting)

## Preferred Channel

- Email `justin.law [@] theaicompany.org`

## Fallback

- GitHub [@openai-codex-demo](https://github.com/openai-codex-demo)
