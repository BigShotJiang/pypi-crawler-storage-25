# openinference-instrumentation-codex Diagrams

## Contents

- [System](#system)
- [Boundary Notes](#boundary-notes)

## System

```mermaid
flowchart LR
    cli["codex exec --json"] --> cli_adapter["CLI JSONL adapter"]
    cli_adapter --> builder["CodexTraceBuilder"]
    builder --> cli_turn_tree["one codex.turn trace per turn"]
    cli_turn_tree --> otlp["OTLP exporter"]

    local["--codex-home (default ~/.codex)\nsessions/**/*.jsonl only"] --> follower["session JSONL follower"]
    follower --> turn_exporter["CodexTurnExporter"]
    turn_exporter --> turn_tree["one codex.turn trace per persisted turn"]
    turn_tree --> otlp
```

## Boundary Notes

| Surface | Owned by this repo | External black box |
| --- | --- | --- |
| Event normalization | CLI JSONL and persisted-session adapters | Codex event production |
| Trace model | CLI mode emits one `codex.turn` root per observed turn; local JSONL mode emits one `codex.turn` root per persisted turn; both roots use OpenInference span kind `LLM` so Phoenix can calculate token cost | caller-specific parent context |
| Export | proxy and forwarder wiring to the active OTel SDK exporter | sink behavior in an external collector or tracing backend |
| Caller integration | `codex-otel-proxy` and `codex-jsonl-forwarder` CLIs | orchestration in external callers |
| Session file discovery | `codex-jsonl-forwarder` reads only `<codex-home>/sessions/**/*.jsonl`; default `<codex-home>` is `~/.codex` and can be changed with `--codex-home` | Codex persistence format and whether a session terminal record is written |

### Startup Backfill

- Exports archived terminated sessions
- Exports archived unterminated sessions not considered live
- Buffers recently modified unterminated sessions
- Buffers the newest unterminated session
- Polling export emits completed turns as soon as their turn terminal record is observed
- `--backfill-active-grace` controls the recent-file window
- Shutdown flush exports remaining buffered sessions
- Exported roots are `codex.turn` spans with OpenInference span kind `LLM`
- Phoenix cost inputs: `llm.model_name`, token counts, and cache-read token counts

### W3C Parent Context

- `codex-otel-proxy` attaches roots to W3C trace context when available.
- W3C inputs: `TRACEPARENT`, `TRACESTATE`
- External callers may package a different release.
- Verify external package pins before copying this trace contract into deployed system docs.
