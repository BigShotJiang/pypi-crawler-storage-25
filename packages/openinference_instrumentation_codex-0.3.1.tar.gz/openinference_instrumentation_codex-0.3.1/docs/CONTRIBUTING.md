# Contributing

- Start with [README.md](../README.md).
- Then read [AGENTS.md](../AGENTS.md).

## Contents

- [Pull Requests](#pull-requests)
- [Commit Messages](#commit-messages)
- [Validation](#validation)

## Pull Requests

- Keep scope narrow
- Reflect public surface and contract changes in docs
- Keep the split between this repo and external callers/sinks explicit
- Use Conventional Commit messages for all local commits and Conventional Commit PR titles
- Squash merge so the PR title becomes the release commit
- Keep secrets and environment-specific values out of the repo

## Commit Messages

- Use Conventional Commits.
- Valid forms: `type(scope): summary` or `type: summary`
- Examples: `feat: support local JSONL forwarding`, `fix(cli): preserve command output`
- Release-bearing user-facing changes: use `feat:` or `fix:`
- Non-releasable changes: use types such as `docs:`
- Avoid free-form subjects; release-please cannot parse them reliably.

## Validation

| Change | Minimum check |
| --- | --- |
| Source change | `make lint` |
| Behavior change | `make test` |
| Local JSONL Phoenix check | `make phoenix-jsonl-start` then `make phoenix-jsonl-status` |
| Live smoke path | `make compose-e2e` |
| Full local validation | `make flight-check` |

- Local JSONL Phoenix targets are repo-owned developer helpers.
- Phoenix URL: `localhost:6006`
- Runtime files: `.run/`
- Default project: `codex-local-jsonl-forwarder`
- Override via Make variables.

- GitHub CI uses the same Make targets as local development.
- Add new developer checks behind Makefile targets first.
- Workflow YAML should call Make targets.
- Workflow YAML should not spell out raw `uv`, `pytest`, `ruff`, or Compose commands.

### Compose Smoke

- Builds the current wheel
- Installs it with `[otlp,test]`
- Runs `tests/e2e/run_wheel_e2e.py`
- Runs `scripts/run_live_codex_smoke.py` against Phoenix
- Maps Phoenix to host port `6007` by default via `COMPOSE_PHOENIX_PORT`
- Avoids collision with the local JSONL Phoenix viewer on `6006`
- Keep CLI flags synchronized with README and diagrams.
- Keep env vars synchronized with README and diagrams.
- Keep trace root names synchronized with README and diagrams.
- Keep CodexOps integration notes synchronized with README and diagrams.
