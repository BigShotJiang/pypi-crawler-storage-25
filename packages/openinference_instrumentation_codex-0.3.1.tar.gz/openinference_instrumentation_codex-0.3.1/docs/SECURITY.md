# Security Policy

## Contents

- [Release Status](#release-status)
- [Supported Versions](#supported-versions)
- [Reporting a Vulnerability](#reporting-a-vulnerability)
- [Security Scope](#security-scope)

## Release Status

- Status: pre-`1.0.0`
- Version tags may exist.
- Stable support window: not defined yet
- Supported-version policy: not published yet

## Supported Versions

- Supported-version matrix: not published yet

## Reporting a Vulnerability

- Do not report security issues in public GitHub issues.
- Do not report security issues in public pull requests.
- Do not report security issues in public discussions.

- Private reporting path: [CONTACT.md](CONTACT.md)

### Include

- Affected commit, branch, or tag
- Impact and attacker prerequisites
- Reproduction steps or proof of concept
- Suggested mitigation or workaround

- Reports are reviewed privately.
- Impact is assessed privately.
- Disclosure is coordinated around a fix when possible.

## Security Scope

- Evaluate the current repository state.

### Focus Areas

- Event normalization and span-shaping behavior
- Public proxy stream handling
- OTLP exporter wiring and content-capture configuration
- Public docs linked from the [README Project Docs section](../README.md#project-docs)

- Base instrumentation content capture: opt-in
- `codex-jsonl-forwarder` default: rich local Phoenix export when capture env vars are unset
- Captured outputs: not redacted by the input redactor
- Captured tool results: not redacted by the input redactor
- OTLP sinks are sensitive when output capture is enabled.
- OTLP sinks are sensitive when tool-output capture is enabled.
- For untrusted sinks, set relevant `OPENINFERENCE_CODEX_CAPTURE_*` env vars to `false`.
