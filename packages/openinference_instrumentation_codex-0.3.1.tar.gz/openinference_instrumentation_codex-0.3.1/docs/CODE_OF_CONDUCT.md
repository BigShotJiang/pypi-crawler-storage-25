# Code of Conduct

## Contents

- [Standard](#standard)
- [Unacceptable Behavior](#unacceptable-behavior)
- [Enforcement](#enforcement)
- [Reporting](#reporting)

## Standard

### Project Standard

- Respectful
- Technically rigorous
- Direct
- Professional

### Participant Expectations

- Be respectful, direct, and professional
- Critique ideas, code, and decisions without attacking people
- Assume good intent and ask for clarification when something is unclear
- Keep discussions constructive, relevant, and welcoming
- Respect different backgrounds, identities, and experience levels

## Unacceptable Behavior

### Scope

- Project spaces
- Related private communication

- Harassment, threats, or personal attacks
- Discriminatory language or conduct
- Sexualized language or imagery
- Doxxing or sharing private information without permission
- Repeated bad-faith disruption, trolling, or intimidation
- Publishing private security reports without coordination

## Enforcement

- Maintainers may edit, hide, lock, or remove violating content.
- Repeated violations may lead to restrictions.
- Severe violations may lead to restrictions.
- Restrictions may be temporary or permanent.

## Reporting

- Private reporting path: [docs/CONTACT.md](CONTACT.md)

### Include

- GitHub accounts of the reported people
- Why the behavior violates the code of conduct
- Links or screenshots when relevant
