# Changelog

## [0.3.1](https://github.com/openai-codex-demo/openinference-instrumentation-codex/compare/v0.3.0...v0.3.1) (2026-05-13)


### Bug Fixes

* price codex turn traces in phoenix ([c72421e](https://github.com/openai-codex-demo/openinference-instrumentation-codex/commit/c72421e6d1c7ecdd2e74fe9d1e84d1d15d072914))

## [0.3.0](https://github.com/openai-codex-demo/openinference-instrumentation-codex/compare/v0.2.1...v0.3.0) (2026-05-13)


### Features

* add local jsonl forwarder ([2512aab](https://github.com/openai-codex-demo/openinference-instrumentation-codex/commit/2512aabbb704c3f6784289756bd1d7c54e3f76fc))
* jsonl forwarder phoenix ci ([#17](https://github.com/openai-codex-demo/openinference-instrumentation-codex/issues/17)) ([89f276e](https://github.com/openai-codex-demo/openinference-instrumentation-codex/commit/89f276eaaee9e9a5cf2e1555cfe648ae77214795))
* use turn roots for codex traces ([4e93e34](https://github.com/openai-codex-demo/openinference-instrumentation-codex/commit/4e93e344a075d30c32d4fca953a9d5f618888961))


### Bug Fixes

* align phoenix forwarder smoke expectations ([0b488cc](https://github.com/openai-codex-demo/openinference-instrumentation-codex/commit/0b488cc62d5a70aec989dd51da0e37c47ec5da25))
* drop Python 3.9 for urllib3 2.7 ([957ac34](https://github.com/openai-codex-demo/openinference-instrumentation-codex/commit/957ac34e7d8745a3cbac197b203116ed1963aaf1)), closes [#19](https://github.com/openai-codex-demo/openinference-instrumentation-codex/issues/19)
* export local jsonl turns to phoenix ([db8542a](https://github.com/openai-codex-demo/openinference-instrumentation-codex/commit/db8542a3edc25543195af1945805c167f08acd78))

## [0.2.1](https://github.com/openai-codex-demo/openinference-instrumentation-codex/compare/v0.2.0...v0.2.1) (2026-04-30)


### Bug Fixes

* align Codex event adapters ([24dc81c](https://github.com/openai-codex-demo/openinference-instrumentation-codex/commit/24dc81ce43d67dc0b6abab0b719936ddc9746737))

## [0.2.0](https://github.com/openai-codex-demo/openinference-instrumentation-codex/compare/v0.1.0...v0.2.0) (2026-04-29)


### Features

* add codex otel proxy ([481848f](https://github.com/openai-codex-demo/openinference-instrumentation-codex/commit/481848f2829a7d4bceaf7e99c6982a4fa8726aa0))
* add rich persisted-session runner transport ([57813c8](https://github.com/openai-codex-demo/openinference-instrumentation-codex/commit/57813c855c072c326ec538998510839ecde25f6a))


### Bug Fixes

* publish with tagged pypi action ([a795017](https://github.com/openai-codex-demo/openinference-instrumentation-codex/commit/a7950177322c19ad0b67318e91a5216b455ece73))
* restore dedicated publish workflow ([0581bca](https://github.com/openai-codex-demo/openinference-instrumentation-codex/commit/0581bcac221c75400fcbccef5a859e087f137c9f))

## 0.1.0 (2026-04-27)


### Features

* add event-native codex tracing ([4e1f616](https://github.com/openai-codex-demo/openinference-instrumentation-codex/commit/4e1f6163b00cbf5a66a72548ee35f613db896b74))

## Historical Notes

- Added an event-native Codex trace builder with normalized CLI JSONL and persisted-session adapters.
- Added fixture-backed coverage for turn/item lifecycle, failures, redaction, richer item types, and usage aggregation.
- Reworked SDK and CLI monkey patches into fallback-only spans instead of synthetic session/tool trees.
- Added the public `codex-otel-proxy` observer and installable `otlp` runtime extra.
- Added wheel-install e2e coverage that validates the exported OTLP session tree from a clean install.
- Updated docs and examples for current `codex exec` usage and Phoenix project routing.
