#!/usr/bin/env python3
"""
Benchmark SPECTER2 vs Gemini-2 search quality on two seed papers.
Finds top-20 related papers for each using both indexes, then compares.
"""

import time
from arxiv_search_kit.client import ArxivClient

SPECTER2_INDEX = "/root/.cache/arxiv_search_kit/arxiv_index"
GEMINI_INDEX   = "/workspace/gemini_index"
GEMINI_API_KEY = "AIzaSyAeMvL2bDp5BGAsFBgqp5uGHijo-dtLmaY"
TOP_N          = 20

SEED_PAPERS = [
    "2603.10165",  # OpenClaw-RL: Train Any Agent Simply by Talking
    "2602.15849",  # IntelliAsk: Learning to Ask High-Quality Research Questions via RLVR
]

print("Loading SPECTER2 client...")
t0 = time.time()
s2_client = ArxivClient(index_dir=SPECTER2_INDEX, embedding="specter2", rerank=False, eager_load=True)
print(f"  Ready in {time.time()-t0:.1f}s | {s2_client.num_papers:,} papers\n")

print("Loading Gemini-2 client...")
t0 = time.time()
g2_client = ArxivClient(index_dir=GEMINI_INDEX, embedding="gemini", gemini_api_key=GEMINI_API_KEY, rerank=False, eager_load=True)
print(f"  Ready in {time.time()-t0:.1f}s | {g2_client.num_papers:,} papers\n")

SEP = "=" * 80

for paper_id in SEED_PAPERS:
    paper = s2_client.get_paper(paper_id)
    print(f"\n{SEP}")
    print(f"SEED PAPER: [{paper_id}]")
    print(f"Title    : {paper.title}")
    print(f"Abstract : {paper.abstract[:200]}...")
    print(SEP)

    # --- SPECTER2 ---
    t0 = time.time()
    s2_result = s2_client.find_related(paper_id, max_results=TOP_N, rerank=False)
    s2_ms = time.time() - t0

    # --- Gemini-2 ---
    t0 = time.time()
    g2_result = g2_client.find_related(paper_id, max_results=TOP_N, rerank=False)
    g2_ms = time.time() - t0

    s2_ids = [p.arxiv_id for p in s2_result.papers]
    g2_ids = [p.arxiv_id for p in g2_result.papers]
    overlap = set(s2_ids) & set(g2_ids)

    print(f"\n{'─'*38} SPECTER2 ({s2_ms*1000:.0f}ms) {'─'*38}")
    for i, p in enumerate(s2_result.papers, 1):
        marker = "✓" if p.arxiv_id in overlap else " "
        print(f"  {marker} {i:2d}. [{p.arxiv_id}] {p.title[:72]}")

    print(f"\n{'─'*37} Gemini-2 ({g2_ms*1000:.0f}ms) {'─'*38}")
    for i, p in enumerate(g2_result.papers, 1):
        marker = "✓" if p.arxiv_id in overlap else " "
        print(f"  {marker} {i:2d}. [{p.arxiv_id}] {p.title[:72]}")

    print(f"\n  Overlap: {len(overlap)}/{TOP_N} papers in common")
    print(f"  Papers only in SPECTER2 : {len(set(s2_ids) - set(g2_ids))}")
    print(f"  Papers only in Gemini-2 : {len(set(g2_ids) - set(s2_ids))}")

print(f"\n{SEP}")
print("Done.")
