#!/usr/bin/env python3
"""
Embed ArXiv papers using the standard Gemini embedding API.
Exploits 20K RPM / 20M TPM limits with high concurrency.

Checkpointing: uses a numpy memmap file so saves are O(new rows) not O(total).
Resume-safe: tracks done IDs in standard_ids.json, skips on restart.

Usage:
    python embed_standard_api.py --api-key AIza...

    python embed_standard_api.py \
        --api-key AIza... \
        --input /workspace/gemini_pipeline/jobs/all_papers.jsonl \
        --out-dir /workspace/gemini_pipeline/jobs/embeddings \
        [--concurrency 300] \
        [--batch-size 100]
"""

import argparse
import asyncio
import json
import logging
import sys
import time
from pathlib import Path

import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

MODEL = "gemini-embedding-2-preview"
EMBED_DIM = 3072
TOTAL_PAPERS = 928_523  # pre-allocate memmap for full dataset

# Rate limits: 20K RPM = 333 RPS, 20M TPM
# batch_size=100 * ~200 tokens = ~20K tokens/req → 333 req/s * 100 = 33K papers/s theoretical
DEFAULT_CONCURRENCY = 300
DEFAULT_BATCH_SIZE = 100
CHECKPOINT_EVERY = 2000  # flush memmap & ids every N completed papers


async def embed_batch(client, ids: list[str], texts: list[str], semaphore: asyncio.Semaphore) -> tuple[list[str], list[list[float]]]:
    """Embed a batch. Returns (ids, vectors). Retries on 429 with exponential backoff."""
    import google.genai.errors as genai_errors

    for attempt in range(20):
        async with semaphore:
            try:
                result = await asyncio.to_thread(
                    client.models.embed_content,
                    model=MODEL,
                    contents=texts,
                )
                return ids, [list(e.values) for e in result.embeddings]
            except genai_errors.ClientError as e:
                if "429" in str(e) or "RESOURCE_EXHAUSTED" in str(e):
                    wait = min(2 ** attempt, 120)
                    logger.warning(f"429 — backing off {wait}s (attempt {attempt+1})")
                    await asyncio.sleep(wait)
                else:
                    logger.error(f"ClientError (non-retryable): {e}")
                    return [], []
            except Exception as e:
                wait = min(2 ** attempt, 60)
                logger.warning(f"Error: {e} — retrying in {wait}s")
                await asyncio.sleep(wait)

    logger.error(f"Batch failed permanently, skipping {len(ids)} papers")
    return [], []


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--api-key", required=True)
    parser.add_argument("--input", default="/workspace/gemini_pipeline/jobs/all_papers.jsonl")
    parser.add_argument("--out-dir", default="/workspace/gemini_pipeline/jobs/embeddings")
    parser.add_argument("--concurrency", type=int, default=DEFAULT_CONCURRENCY)
    parser.add_argument("--batch-size", type=int, default=DEFAULT_BATCH_SIZE)
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Files:
    #   standard_ids.json       — ordered list of arxiv_ids (checkpoint)
    #   standard_embeddings.dat — numpy memmap (N x 3072 float32), grows incrementally
    #   standard_embeddings.npy — final output (written at the end)
    ids_path = out_dir / "standard_ids.json"
    mmap_path = out_dir / "standard_embeddings.dat"
    npy_path = out_dir / "standard_embeddings.npy"

    from google import genai
    client = genai.Client(api_key=args.api_key)

    # Load already-done IDs
    done_ids: list[str] = []
    done_id_set: set[str] = set()
    if ids_path.exists():
        done_ids = json.loads(ids_path.read_text())
        done_id_set = set(done_ids)
        logger.info(f"Resuming: {len(done_ids):,} already embedded")

    # Read papers to embed, skip done
    logger.info(f"Reading {args.input}...")
    papers = []  # (arxiv_id, text)
    with open(args.input) as f:
        for line in f:
            rec = json.loads(line)
            arxiv_id = rec["key"]
            if arxiv_id in done_id_set:
                continue
            text = rec["request"]["content"]["parts"][0]["text"]
            papers.append((arxiv_id, text))

    total_papers = len(done_ids) + len(papers)
    logger.info(f"To embed: {len(papers):,} / {total_papers:,} total")
    if not papers:
        logger.info("Nothing to do.")
        return

    # Open memmap — pre-allocate for full dataset, use done_ids count as write cursor
    n_done = len(done_ids)
    mmap = np.memmap(str(mmap_path), dtype=np.float32, mode="r+" if mmap_path.exists() else "w+",
                     shape=(TOTAL_PAPERS, EMBED_DIM))
    write_cursor = n_done  # next row to write

    semaphore = asyncio.Semaphore(args.concurrency)
    batch_size = args.batch_size
    batches = [papers[i:i+batch_size] for i in range(0, len(papers), batch_size)]
    logger.info(f"Batches: {len(batches):,}  concurrency={args.concurrency}  batch_size={batch_size}")

    completed = 0
    failed = 0
    start = time.time()
    last_log = start
    last_checkpoint = 0

    result_lock = asyncio.Lock()
    pending_ids: list[str] = []
    pending_vecs: list[list[float]] = []

    async def run_batch(batch):
        nonlocal completed, failed
        ids = [p[0] for p in batch]
        texts = [p[1] for p in batch]
        ret_ids, vectors = await embed_batch(client, ids, texts, semaphore)
        async with result_lock:
            if ret_ids:
                pending_ids.extend(ret_ids)
                pending_vecs.extend(vectors)
                completed += len(ret_ids)
            else:
                failed += len(batch)

    def flush_checkpoint():
        nonlocal write_cursor, last_checkpoint
        if not pending_ids:
            return
        n = len(pending_ids)
        arr = np.array(pending_vecs, dtype=np.float32)
        mmap[write_cursor:write_cursor+n] = arr
        mmap.flush()
        write_cursor += n
        done_ids.extend(pending_ids)
        ids_path.write_text(json.dumps(done_ids))
        pending_ids.clear()
        pending_vecs.clear()
        last_checkpoint = completed
        logger.info(f"Checkpoint: {write_cursor:,} embeddings saved")

    tasks = [asyncio.create_task(run_batch(b)) for b in batches]

    while tasks:
        done_tasks, tasks = await asyncio.wait(tasks, timeout=10)

        now = time.time()
        if now - last_log >= 10:
            elapsed = now - start
            rate = completed / elapsed if elapsed > 0 else 0
            eta = (len(papers) - completed) / rate if rate > 0 else 0
            logger.info(
                f"{n_done+completed:,}/{total_papers:,} | "
                f"{rate:.0f} papers/s | ETA {eta/60:.1f}m | failed={failed}"
            )
            last_log = now

        if completed - last_checkpoint >= CHECKPOINT_EVERY:
            async with result_lock:
                flush_checkpoint()

    # Final flush
    async with result_lock:
        flush_checkpoint()

    # Write final .npy from memmap (only the written rows)
    logger.info(f"Writing final npy ({write_cursor:,} rows)...")
    final = np.array(mmap[:write_cursor], dtype=np.float32)
    np.save(str(npy_path), final)

    elapsed = time.time() - start
    logger.info(f"Done! {write_cursor:,} embeddings in {elapsed:.0f}s ({write_cursor/elapsed:.0f} papers/s)")
    logger.info(f"  shape: {final.shape}")
    logger.info(f"  npy:   {npy_path}")
    logger.info(f"  ids:   {ids_path}")
    if failed:
        logger.warning(f"  Failed papers: {failed}")


if __name__ == "__main__":
    asyncio.run(main())
