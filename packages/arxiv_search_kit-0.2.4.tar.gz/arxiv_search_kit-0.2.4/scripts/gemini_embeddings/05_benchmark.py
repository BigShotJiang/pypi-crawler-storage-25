#!/usr/bin/env python3
"""
Step 5: Benchmark SPECTER2 vs Gemini Embeddings
================================================
Compares search quality between the original SPECTER2 index and the new
Gemini embedding-2-preview index using a set of benchmark queries.

Metrics:
  - Precision@K (requires relevance labels OR "related paper" proxy)
  - Mean Reciprocal Rank (MRR)
  - Result overlap between systems
  - Search latency

Two modes:
  1. --mode latency: Just measures and compares query latency
  2. --mode quality: Runs predefined CS queries and compares result overlap,
     diversity, and citation-rank correlation (proxy for relevance)

Usage:
    python 05_benchmark.py \
        --specter-index /path/to/specter_index \
        --gemini-index /workspace/gemini_index \
        --gemini-api-key AIza... \
        [--mode quality] \
        [--n-queries 50] \
        [--top-k 10]
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from pathlib import Path

import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

# Benchmark queries — broad CS/ML topics to test retrieval quality
BENCHMARK_QUERIES = [
    "transformer attention mechanism self-attention",
    "diffusion models image generation",
    "large language models instruction tuning",
    "graph neural networks node classification",
    "contrastive learning self-supervised representation",
    "reinforcement learning policy gradient reward",
    "neural architecture search efficiency",
    "knowledge distillation compression",
    "adversarial training robustness",
    "federated learning privacy distributed",
    "vision transformer ViT image recognition",
    "retrieval augmented generation RAG",
    "chain of thought reasoning",
    "sparse mixture of experts",
    "low rank adaptation LoRA fine-tuning",
    "CLIP multimodal contrastive",
    "object detection YOLO real-time",
    "semantic segmentation scene understanding",
    "code generation program synthesis",
    "mathematical reasoning proof verification",
    "quantum computing variational algorithms",
    "protein structure prediction AlphaFold",
    "speech recognition end-to-end",
    "neural machine translation cross-lingual",
    "recommendation systems collaborative filtering",
    "causal inference observational data",
    "point cloud 3D deep learning",
    "normalizing flows generative model density",
    "multi-task learning shared representations",
    "zero-shot few-shot learning prompting",
    "continual learning catastrophic forgetting",
    "neural tangent kernel infinite-width",
    "optimal transport Wasserstein distance",
    "uncertainty estimation Bayesian deep learning",
    "automatic speech recognition whisper wav2vec",
    "video understanding temporal reasoning",
    "medical imaging clinical AI diagnosis",
    "long context window efficient attention",
    "tool use agents autonomous LLM",
    "reward model RLHF human feedback",
    "scaling laws neural language models",
    "memory efficient training gradient checkpointing",
    "efficient inference quantization int8",
    "cross-modal retrieval text image",
    "anomaly detection out-of-distribution",
    "tabular data neural networks gradient boosting",
    "hyperparameter optimization neural architecture",
    "adversarial examples attack defense robustness",
    "interpretability mechanistic explanations",
    "biology genomics single-cell RNA",
]


def embed_query_specter2(query: str, embedder) -> np.ndarray:
    """Embed with SPECTER2."""
    return embedder.embed_query(query)


def embed_query_gemini(query: str, client) -> np.ndarray:
    """Embed with Gemini using the correct query format."""
    formatted = f"task: search result | query: {query}"
    result = client.models.embed_content(
        model="gemini-embedding-2-preview",
        contents=formatted,
    )
    return np.array(result.embeddings[0].values, dtype=np.float32)


def search_index(store, query_vector: np.ndarray, top_k: int) -> list[dict]:
    """Search LanceDB index and return top-k results."""
    papers = store.vector_search(query_vector, limit=top_k)
    return [
        {"arxiv_id": p.arxiv_id, "title": p.title, "score": p.similarity_score}
        for p in papers
    ]


def jaccard_overlap(set_a: set, set_b: set) -> float:
    """Jaccard similarity between two sets of arxiv IDs."""
    if not set_a and not set_b:
        return 1.0
    return len(set_a & set_b) / len(set_a | set_b)


def run_latency_benchmark(
    specter_store,
    gemini_store,
    specter_embedder,
    gemini_client,
    queries: list[str],
    top_k: int,
) -> dict:
    """Measure latency for embedding + search."""
    specter_times = []
    gemini_times = []

    logger.info("Running latency benchmark...")
    for q in queries[:20]:  # Use first 20 for latency
        # SPECTER2
        t0 = time.perf_counter()
        vec = embed_query_specter2(q, specter_embedder)
        search_index(specter_store, vec, top_k)
        specter_times.append((time.perf_counter() - t0) * 1000)

        # Gemini (note: API call, so includes network latency)
        t0 = time.perf_counter()
        vec = embed_query_gemini(q, gemini_client)
        search_index(gemini_store, vec, top_k)
        gemini_times.append((time.perf_counter() - t0) * 1000)

    return {
        "specter2": {
            "mean_ms": float(np.mean(specter_times)),
            "median_ms": float(np.median(specter_times)),
            "p95_ms": float(np.percentile(specter_times, 95)),
        },
        "gemini": {
            "mean_ms": float(np.mean(gemini_times)),
            "median_ms": float(np.median(gemini_times)),
            "p95_ms": float(np.percentile(gemini_times, 95)),
            "note": "Includes Gemini API network latency — not suitable for production without caching",
        },
    }


def run_quality_benchmark(
    specter_store,
    gemini_store,
    specter_embedder,
    gemini_client,
    queries: list[str],
    top_k: int,
) -> dict:
    """Compare result quality using overlap and diversity metrics."""
    overlaps = []
    specter_results_all = []
    gemini_results_all = []

    logger.info(f"Running quality benchmark on {len(queries)} queries (top-{top_k})...")
    for i, query in enumerate(queries):
        logger.info(f"  Query {i+1}/{len(queries)}: {query[:60]}")

        # SPECTER2 results
        s_vec = embed_query_specter2(query, specter_embedder)
        s_results = search_index(specter_store, s_vec, top_k)

        # Gemini results
        g_vec = embed_query_gemini(query, gemini_client)
        g_results = search_index(gemini_store, g_vec, top_k)

        s_ids = {r["arxiv_id"] for r in s_results}
        g_ids = {r["arxiv_id"] for r in g_results}
        overlap = jaccard_overlap(s_ids, g_ids)
        overlaps.append(overlap)

        specter_results_all.append({"query": query, "results": s_results, "ids": list(s_ids)})
        gemini_results_all.append({"query": query, "results": g_results, "ids": list(g_ids)})

        if i < 5:  # Print first 5 for visual inspection
            logger.info(f"    SPECTER2 top-3: {[r['title'][:40] for r in s_results[:3]]}")
            logger.info(f"    Gemini top-3:   {[r['title'][:40] for r in g_results[:3]]}")
            logger.info(f"    Jaccard overlap@{top_k}: {overlap:.3f}")

    return {
        "num_queries": len(queries),
        "top_k": top_k,
        "jaccard_overlap": {
            "mean": float(np.mean(overlaps)),
            "median": float(np.median(overlaps)),
            "std": float(np.std(overlaps)),
            "min": float(np.min(overlaps)),
            "max": float(np.max(overlaps)),
        },
        "interpretation": (
            "Jaccard overlap measures agreement between systems. "
            "1.0 = identical results, 0.0 = no overlap. "
            "Expected range for different embedding models: 0.2-0.6. "
            "Higher overlap is NOT necessarily better — diversity may be useful."
        ),
        "per_query_overlaps": dict(zip(queries, overlaps)),
    }


def print_report(results: dict) -> None:
    logger.info("\n" + "=" * 60)
    logger.info("BENCHMARK REPORT: SPECTER2 vs Gemini-embedding-2-preview")
    logger.info("=" * 60)

    if "latency" in results:
        lat = results["latency"]
        logger.info("\n--- Latency ---")
        logger.info(f"SPECTER2:  mean={lat['specter2']['mean_ms']:.1f}ms  median={lat['specter2']['median_ms']:.1f}ms  p95={lat['specter2']['p95_ms']:.1f}ms")
        logger.info(f"Gemini:    mean={lat['gemini']['mean_ms']:.1f}ms  median={lat['gemini']['median_ms']:.1f}ms  p95={lat['gemini']['p95_ms']:.1f}ms")
        logger.info(f"Note: {lat['gemini']['note']}")

    if "quality" in results:
        q = results["quality"]
        ov = q["jaccard_overlap"]
        logger.info(f"\n--- Result Overlap (Jaccard@{q['top_k']}) ---")
        logger.info(f"Mean overlap:   {ov['mean']:.3f}")
        logger.info(f"Median overlap: {ov['median']:.3f}")
        logger.info(f"Std:            {ov['std']:.3f}")
        logger.info(f"Range:          {ov['min']:.3f} - {ov['max']:.3f}")
        logger.info(f"\nInterpretation: {q['interpretation']}")

    logger.info("\n" + "=" * 60)


def main():
    parser = argparse.ArgumentParser(description="Benchmark SPECTER2 vs Gemini embedding search")
    parser.add_argument("--specter-index", required=True, help="Path to SPECTER2 LanceDB index")
    parser.add_argument("--gemini-index", required=True, help="Path to Gemini LanceDB index")
    parser.add_argument("--gemini-api-key", required=True, help="Gemini API key")
    parser.add_argument("--mode", choices=["latency", "quality", "both"], default="both")
    parser.add_argument("--n-queries", type=int, default=50, help="Number of benchmark queries (default: 50)")
    parser.add_argument("--top-k", type=int, default=10, help="Top-K results to compare (default: 10)")
    parser.add_argument("--output", default="benchmark_results.json", help="Output JSON file")
    args = parser.parse_args()

    # Import project modules
    sys.path.insert(0, str(Path(__file__).parents[2]))
    from arxiv_search_kit.index.store import IndexStore
    from arxiv_search_kit.index.embedder import Specter2Embedder

    # Load indexes
    logger.info("Loading SPECTER2 index...")
    specter_store = IndexStore(args.specter_index)
    logger.info(f"  {specter_store.num_papers:,} papers")

    logger.info("Loading Gemini index...")
    gemini_store = IndexStore(args.gemini_index)
    logger.info(f"  {gemini_store.num_papers:,} papers")

    # Load embedders
    logger.info("Loading SPECTER2 embedder (CPU for benchmark)...")
    specter_embedder = Specter2Embedder(device="cpu", batch_size=1)
    specter_embedder.warmup()

    logger.info("Initializing Gemini client...")
    from google import genai
    gemini_client = genai.Client(api_key=args.gemini_api_key)

    queries = BENCHMARK_QUERIES[:args.n_queries]
    results = {}

    if args.mode in ("latency", "both"):
        results["latency"] = run_latency_benchmark(
            specter_store, gemini_store, specter_embedder, gemini_client, queries, args.top_k
        )

    if args.mode in ("quality", "both"):
        results["quality"] = run_quality_benchmark(
            specter_store, gemini_store, specter_embedder, gemini_client, queries, args.top_k
        )

    results["config"] = {
        "specter_index": args.specter_index,
        "gemini_index": args.gemini_index,
        "top_k": args.top_k,
        "n_queries": len(queries),
    }

    # Print report
    print_report(results)

    # Save results
    with open(args.output, "w") as f:
        json.dump(results, f, indent=2)
    logger.info(f"\nResults saved to: {args.output}")


if __name__ == "__main__":
    main()
