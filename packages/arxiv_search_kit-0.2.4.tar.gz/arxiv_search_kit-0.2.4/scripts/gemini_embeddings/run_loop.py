#!/usr/bin/env python3
"""
Full pipeline loop: submit one 40K-paper chunk, wait for completion,
collect results, then submit the next. Repeats until all 24 chunks done.

Respects the 10M enqueued-token limit by processing one chunk at a time.
"""
import json, time, warnings
from pathlib import Path

import numpy as np
from google import genai
from google.genai import types

API_KEY = "AIzaSyBUUxFmTk4oQa02Qm2dLQgPctqWfjnowTw"
JOBS_DIR = Path("/workspace/gemini_pipeline/jobs")
PARTS_DIR = JOBS_DIR / "parts40k"
EMBEDDINGS_DIR = JOBS_DIR / "embeddings"
PROGRESS_FILE = JOBS_DIR / "progress.json"
MODEL = "gemini-embedding-2-preview"
POLL_INTERVAL = 60  # seconds between status checks

EMBEDDINGS_DIR.mkdir(exist_ok=True)
client = genai.Client(api_key=API_KEY)


def load_progress():
    if PROGRESS_FILE.exists():
        return json.load(open(PROGRESS_FILE))
    return {}


def save_progress(progress):
    json.dump(progress, open(PROGRESS_FILE, "w"), indent=2)


def submit_chunk(part_name, part_path):
    """Upload file and submit batch job. Returns job_name."""
    print(f"  Uploading {part_name} ({part_path.stat().st_size//1024//1024}MB)...", flush=True)
    uploaded = client.files.upload(
        file=str(part_path),
        config=types.UploadFileConfig(display_name=part_name, mime_type="application/jsonl")
    )
    print(f"  Uploaded: {uploaded.name}", flush=True)

    for attempt in range(10):
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                job = client.batches.create_embeddings(
                    model=MODEL,
                    src=types.EmbeddingsBatchJobSource(file_name=uploaded.name),
                    config={"display_name": f"arxiv-embed-{part_name}"}
                )
            print(f"  Job: {job.name}  State: {job.state}", flush=True)
            return job.name, uploaded.name
        except Exception as e:
            if "429" in str(e):
                print(f"  429 quota hit (attempt {attempt+1}/10), waiting 60s...", flush=True)
                time.sleep(60)
            else:
                raise
    raise RuntimeError(f"Failed to submit {part_name} after 10 attempts")


def wait_for_job(job_name):
    """Poll until job succeeds. Returns job object."""
    done_states = {"JOB_STATE_SUCCEEDED", "JOB_STATE_FAILED", "JOB_STATE_CANCELLED", "JOB_STATE_EXPIRED"}
    while True:
        job = client.batches.get(name=job_name)
        state = job.state.name if hasattr(job.state, "name") else str(job.state)
        print(f"  [{time.strftime('%H:%M:%S')}] {state}", flush=True)
        if state in done_states:
            return job, state
        time.sleep(POLL_INTERVAL)


def collect_results(job, part_name):
    """Download and save embeddings. Returns (ids, npy_path)."""
    print(f"  Downloading results...", flush=True)
    content = client.files.download(file=job.dest.file_name)
    lines = content.decode().strip().split("\n")

    ids, embeddings, errors = [], [], 0
    for line in lines:
        rec = json.loads(line)
        key = rec.get("key", "")
        emb = rec.get("response", {}).get("embedding", {}).get("values", [])
        if emb:
            ids.append(key)
            embeddings.append(emb)
        else:
            errors += 1

    arr = np.array(embeddings, dtype=np.float32)
    npy_path = EMBEDDINGS_DIR / f"{part_name}_embeddings.npy"
    ids_path = EMBEDDINGS_DIR / f"{part_name}_ids.json"
    np.save(str(npy_path), arr)
    json.dump(ids, open(ids_path, "w"))
    print(f"  Saved: {arr.shape}, errors={errors}", flush=True)
    return ids_path, npy_path, len(ids)


def main():
    progress = load_progress()
    parts = sorted(PARTS_DIR.glob("part_*"))
    print(f"Total parts: {len(parts)}")

    # Show existing progress
    done = [p for p in parts if progress.get(p.name, {}).get("status") == "collected"]
    print(f"Already collected: {len(done)}/{len(parts)}")

    for part_path in parts:
        part_name = part_path.name
        status = progress.get(part_name, {}).get("status")

        if status == "collected":
            print(f"\n[{part_name}] Already collected, skipping.")
            continue

        print(f"\n{'='*50}")
        print(f"[{part_name}] Starting...", flush=True)

        # Submit if not already submitted
        if status != "submitted":
            job_name, uploaded_file = submit_chunk(part_name, part_path)
            progress[part_name] = {
                "status": "submitted",
                "job": job_name,
                "uploaded_file": uploaded_file,
            }
            save_progress(progress)
        else:
            job_name = progress[part_name]["job"]
            print(f"  Already submitted: {job_name}", flush=True)

        # Wait for completion
        print(f"  Waiting for job to complete...", flush=True)
        job, state = wait_for_job(job_name)

        if state != "JOB_STATE_SUCCEEDED":
            print(f"  FAILED: {state}")
            progress[part_name]["status"] = "failed"
            save_progress(progress)
            continue

        # Collect results
        ids_path, npy_path, count = collect_results(job, part_name)
        progress[part_name] = {
            "status": "collected",
            "job": job_name,
            "npy": str(npy_path),
            "ids": str(ids_path),
            "num_papers": count,
        }
        save_progress(progress)
        print(f"  [{part_name}] DONE: {count} papers collected.", flush=True)

    # Final summary
    progress = load_progress()
    collected = [p for p in parts if progress.get(p.name, {}).get("status") == "collected"]
    total = sum(progress.get(p.name, {}).get("num_papers", 0) for p in parts)
    print(f"\n{'='*50}")
    print(f"COMPLETE: {len(collected)}/{len(parts)} chunks, {total:,} papers total")


if __name__ == "__main__":
    main()
