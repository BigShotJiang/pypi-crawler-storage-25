#!/usr/bin/env python3
"""
Step 2: Monitor Batch Jobs and Collect Results
===============================================
Polls all submitted batch embedding jobs from the manifest, waits for
completion, downloads result files, and extracts embeddings into a
compact numpy binary format (.npy files, one per chunk).

The output is:
  output_dir/
    embeddings/
      chunk_0000_embeddings.npy   # shape (N, 3072), float32
      chunk_0000_ids.json         # list of arxiv_ids in same order
      ...
    job_manifest.jsonl            # updated with completion status

Usage:
    python 02_monitor_and_collect.py \
        --gemini-api-key AIza... \
        --output-dir /workspace/gemini_jobs \
        [--poll-interval 60] \
        [--resume]
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from pathlib import Path

import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

COMPLETED_STATES = {"JOB_STATE_SUCCEEDED", "JOB_STATE_FAILED", "JOB_STATE_CANCELLED", "JOB_STATE_EXPIRED"}


def load_manifest(manifest_path: Path) -> list[dict]:
    entries = []
    with open(manifest_path) as f:
        for line in f:
            line = line.strip()
            if line:
                entries.append(json.loads(line))
    return entries


def save_manifest(manifest_path: Path, entries: list[dict]) -> None:
    with open(manifest_path, "w") as f:
        for entry in entries:
            f.write(json.dumps(entry) + "\n")


def download_and_parse_result_file(client, file_name: str) -> list[dict]:
    """Download result JSONL file and parse embedding responses.

    Returns list of {"key": arxiv_id, "embedding": [float, ...]} dicts.
    """
    logger.info(f"  Downloading result file: {file_name}")
    content_bytes = client.files.download(file=file_name)
    content = content_bytes.decode("utf-8")

    results = []
    errors = 0
    for line in content.strip().split("\n"):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
            key = record.get("key", "")
            # Confirmed output structure (from live test):
            # {"key": "...", "response": {"embedding": {"values": [...]}, "usageMetadata": {...}}}
            response = record.get("response", {})
            if response and "embedding" in response:
                embedding = response["embedding"].get("values", [])
                if embedding:
                    results.append({"key": key, "embedding": embedding})
                else:
                    errors += 1
                    logger.warning(f"  Empty values in embedding for key={key}")
            elif "error" in record:
                errors += 1
                logger.warning(f"  Error for key={key}: {record['error']}")
            else:
                errors += 1
                logger.warning(f"  Unexpected response structure for key={key}, keys={list(response.keys())}")
        except Exception as e:
            errors += 1
            logger.warning(f"  Failed to parse line: {e}")

    logger.info(f"  Parsed {len(results):,} embeddings, {errors} errors")
    return results


def process_inline_embed_responses(batch_job) -> list[dict]:
    """Parse inline embedding responses from a batch job (for smaller jobs)."""
    results = []
    errors = 0

    if not (batch_job.dest and hasattr(batch_job.dest, "inlined_embed_content_responses")):
        return results

    for resp in batch_job.dest.inlined_embed_content_responses:
        key = getattr(resp, "key", "")
        if resp.response and hasattr(resp.response, "embeddings"):
            embs = resp.response.embeddings
            if embs and hasattr(embs[0], "values"):
                results.append({"key": key, "embedding": list(embs[0].values)})
            else:
                errors += 1
        elif resp.error:
            errors += 1
            logger.warning(f"  Error for key={key}: {resp.error}")

    logger.info(f"  Parsed {len(results):,} inline embeddings, {errors} errors")
    return results


def save_chunk_embeddings(results: list[dict], chunk_idx: int, embeddings_dir: Path) -> tuple[Path, Path]:
    """Save embeddings as numpy array and IDs as JSON.

    Returns (npy_path, ids_path).
    """
    if not results:
        raise ValueError("No results to save")

    ids = [r["key"] for r in results]
    dim = len(results[0]["embedding"])
    embeddings_arr = np.array([r["embedding"] for r in results], dtype=np.float32)

    npy_path = embeddings_dir / f"chunk_{chunk_idx:04d}_embeddings.npy"
    ids_path = embeddings_dir / f"chunk_{chunk_idx:04d}_ids.json"

    np.save(str(npy_path), embeddings_arr)
    with open(ids_path, "w") as f:
        json.dump(ids, f)

    logger.info(f"  Saved embeddings: {npy_path.name} shape={embeddings_arr.shape}, dim={dim}")
    return npy_path, ids_path


def main():
    parser = argparse.ArgumentParser(description="Monitor Gemini batch jobs and collect embeddings")
    parser.add_argument("--gemini-api-key", required=True, help="Gemini API key")
    parser.add_argument("--output-dir", required=True, help="Same output-dir as step 1")
    parser.add_argument("--poll-interval", type=int, default=60, help="Seconds between status polls (default: 60)")
    parser.add_argument("--resume", action="store_true", help="Skip already-collected chunks")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    embeddings_dir = output_dir / "embeddings"
    embeddings_dir.mkdir(exist_ok=True)
    manifest_path = output_dir / "job_manifest.jsonl"

    if not manifest_path.exists():
        logger.error(f"Manifest not found: {manifest_path}. Run step 1 first.")
        sys.exit(1)

    # Init Gemini client
    from google import genai
    client = genai.Client(api_key=args.gemini_api_key)

    entries = load_manifest(manifest_path)
    logger.info(f"Loaded {len(entries)} job entries from manifest")

    # Filter to pending jobs
    pending = [e for e in entries if e.get("status") == "submitted" and e.get("batch_job_name")]
    already_done = [e for e in entries if e.get("status") == "collected"]
    failed_submit = [e for e in entries if e.get("status") == "failed"]

    logger.info(f"  Pending: {len(pending)}, Already collected: {len(already_done)}, Submit-failed: {len(failed_submit)}")

    if not pending:
        logger.info("No pending jobs. All done!")
        return

    # Poll until all complete
    while True:
        still_running = []
        newly_done = []

        for entry in pending:
            job_name = entry["batch_job_name"]
            try:
                job = client.batches.get(name=job_name)
                state = job.state.name if hasattr(job.state, "name") else str(job.state)
                logger.debug(f"  {job_name}: {state}")

                if state in COMPLETED_STATES:
                    entry["final_state"] = state
                    newly_done.append((entry, job))
                else:
                    still_running.append(entry)
            except Exception as e:
                logger.warning(f"  Failed to poll {job_name}: {e}")
                still_running.append(entry)

        logger.info(f"Status: {len(newly_done)} completed this round, {len(still_running)} still running")

        # Process completed jobs
        for entry, job in newly_done:
            chunk_idx = entry["chunk_idx"]
            state = entry["final_state"]
            logger.info(f"Processing chunk {chunk_idx} (state={state})")

            if state != "JOB_STATE_SUCCEEDED":
                logger.error(f"  Chunk {chunk_idx} FAILED: {state}")
                entry["status"] = "failed_job"
                continue

            try:
                # Try file-based output first, then inline
                results = []
                if job.dest and hasattr(job.dest, "file_name") and job.dest.file_name:
                    results = download_and_parse_result_file(client, job.dest.file_name)
                elif job.dest and hasattr(job.dest, "inlined_embed_content_responses"):
                    results = process_inline_embed_responses(job)
                else:
                    logger.error(f"  Chunk {chunk_idx}: no output found in job dest")
                    entry["status"] = "failed_no_output"
                    continue

                if not results:
                    logger.error(f"  Chunk {chunk_idx}: 0 embeddings parsed")
                    entry["status"] = "failed_empty"
                    continue

                npy_path, ids_path = save_chunk_embeddings(results, chunk_idx, embeddings_dir)
                entry["status"] = "collected"
                entry["npy_path"] = str(npy_path)
                entry["ids_path"] = str(ids_path)
                entry["num_collected"] = len(results)
                entry["embedding_dim"] = len(results[0]["embedding"])
                logger.info(f"  Chunk {chunk_idx}: collected {len(results):,} embeddings (dim={entry['embedding_dim']})")

            except Exception as e:
                logger.error(f"  Chunk {chunk_idx}: collection failed: {e}", exc_info=True)
                entry["status"] = "failed_collection"
                entry["error"] = str(e)

        # Update manifest
        save_manifest(manifest_path, entries)

        if not still_running:
            break

        pending = still_running
        logger.info(f"Waiting {args.poll_interval}s before next poll...")
        time.sleep(args.poll_interval)

    # Summary
    entries = load_manifest(manifest_path)
    collected = [e for e in entries if e.get("status") == "collected"]
    failed = [e for e in entries if "fail" in e.get("status", "")]
    total_embeddings = sum(e.get("num_collected", 0) for e in collected)

    logger.info("\n=== COLLECTION SUMMARY ===")
    logger.info(f"Collected: {len(collected)} chunks, {total_embeddings:,} embeddings")
    logger.info(f"Failed:    {len(failed)} chunks")
    if failed:
        for e in failed:
            logger.warning(f"  Chunk {e['chunk_idx']}: {e.get('status')} - {e.get('error', '')}")

    logger.info(f"\nEmbeddings saved to: {embeddings_dir}")
    logger.info("Next step: run 03_build_gemini_index.py to build the LanceDB index")


if __name__ == "__main__":
    main()
