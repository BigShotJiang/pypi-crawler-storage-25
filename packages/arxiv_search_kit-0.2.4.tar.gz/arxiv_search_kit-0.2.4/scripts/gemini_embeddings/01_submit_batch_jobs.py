#!/usr/bin/env python3
"""
Step 1: Submit Gemini Batch Embedding Jobs
==========================================
Reads ArXiv metadata from HuggingFace (anonymousatom/arxiv-metadata),
formats papers for Gemini embedding-2-preview using the correct document
task prefix, splits into chunks (<= 20MB JSONL each), uploads via File API,
and submits batch embedding jobs.

Usage:
    python 01_submit_batch_jobs.py \
        --gemini-api-key AIza... \
        --hf-token hf_... \
        --output-dir /workspace/gemini_jobs \
        [--chunk-size 50000] \
        [--max-papers 0]   # 0 = all papers
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

# Gemini model to use for embeddings
GEMINI_EMBEDDING_MODEL = "gemini-embedding-2-preview"

# Document format for asymmetric search retrieval (gemini-embedding-2-preview)
# Per docs: "title: {title} | text: {content}"
def format_document(title: str, abstract: str) -> str:
    title = (title or "").strip()
    abstract = (abstract or "").strip()
    if not title:
        title = "none"
    # Truncate abstract to keep requests reasonable (~2000 chars)
    if len(abstract) > 2000:
        abstract = abstract[:2000]
    return f"title: {title} | text: {abstract}"


def load_metadata_from_hf(hf_token: str, max_papers: int = 0) -> list[dict]:
    """Stream metadata from HuggingFace dataset anonymousatom/arxiv-metadata."""
    from datasets import load_dataset

    logger.info("Loading metadata from HuggingFace: anonymousatom/arxiv-metadata")
    ds = load_dataset(
        "anonymousatom/arxiv-metadata",
        split="train",
        token=hf_token,
        streaming=False,
    )
    logger.info(f"Dataset loaded: {len(ds):,} papers")

    papers = []
    for i, row in enumerate(ds):
        if max_papers and i >= max_papers:
            break
        papers.append({
            "arxiv_id": row.get("arxiv_id") or row.get("id", ""),
            "title": row.get("title", ""),
            "abstract": row.get("abstract", ""),
            "authors": row.get("authors", "[]"),
            "categories": row.get("categories", "[]"),
            "primary_category": row.get("primary_category", ""),
            "published": str(row.get("published", "")),
            "updated": str(row.get("updated", "")),
            "doi": row.get("doi", ""),
            "journal_ref": row.get("journal_ref", ""),
            "comment": row.get("comment", ""),
        })
        if (i + 1) % 100_000 == 0:
            logger.info(f"  Loaded {i+1:,} papers...")

    logger.info(f"Total papers to embed: {len(papers):,}")
    return papers


def build_jsonl_chunk(papers: list[dict], chunk_idx: int, output_dir: Path) -> Path:
    """Build a JSONL file for a chunk of papers.

    Each line: {"key": "arxiv_id", "request": {"content": {"parts": [{"text": "..."}]}}}
    This is the format for embeddings batch jobs.
    """
    chunk_path = output_dir / f"chunk_{chunk_idx:04d}.jsonl"
    with open(chunk_path, "w", encoding="utf-8") as f:
        for paper in papers:
            arxiv_id = paper["arxiv_id"]
            text = format_document(paper["title"], paper["abstract"])
            record = {
                "key": arxiv_id,
                "request": {
                    "content": {
                        "parts": [{"text": text}]
                    }
                }
            }
            f.write(json.dumps(record) + "\n")

    size_mb = chunk_path.stat().st_size / (1024 * 1024)
    logger.info(f"  Wrote {len(papers):,} papers to {chunk_path.name} ({size_mb:.1f} MB)")
    return chunk_path


def submit_batch_job(client, chunk_path: Path, job_name: str, uploaded_file_name: str | None = None) -> str:
    """Upload JSONL file (if not already uploaded) and submit batch embedding job.

    uploaded_file_name: if provided, skips re-upload and reuses this file.
    Returns batch job name.
    """
    from google.genai import types

    if uploaded_file_name:
        logger.info(f"  Reusing already-uploaded file: {uploaded_file_name}")
    else:
        logger.info(f"  Uploading {chunk_path.name} to Gemini File API...")
        uploaded_file = client.files.upload(
            file=str(chunk_path),
            config=types.UploadFileConfig(
                display_name=chunk_path.name,
                mime_type="application/jsonl",
            ),
        )
        uploaded_file_name = uploaded_file.name
        logger.info(f"  Uploaded: {uploaded_file_name}")

    logger.info(f"  Submitting batch embedding job: {job_name}")
    for attempt in range(10):
        try:
            batch_job = client.batches.create_embeddings(
                model=GEMINI_EMBEDDING_MODEL,
                src={"file_name": uploaded_file_name},
                config={"display_name": job_name},
            )
            logger.info(f"  Batch job created: {batch_job.name}")
            return batch_job.name, uploaded_file_name
        except Exception as e:
            if "429" in str(e) or "RESOURCE_EXHAUSTED" in str(e):
                wait = 30
                logger.warning(f"  429 quota hit, waiting {wait}s (attempt {attempt+1}/10)...")
                time.sleep(wait)
            else:
                raise
    raise RuntimeError(f"Failed to submit {job_name} after 10 attempts")


def main():
    parser = argparse.ArgumentParser(description="Submit Gemini batch embedding jobs for ArXiv metadata")
    parser.add_argument("--gemini-api-key", required=True, help="Gemini API key")
    parser.add_argument("--hf-token", required=True, help="HuggingFace token")
    parser.add_argument("--output-dir", required=True, help="Directory to store JSONL chunks and job manifest")
    parser.add_argument("--chunk-size", type=int, default=50_000, help="Papers per batch job chunk (default: 50000)")
    parser.add_argument("--max-papers", type=int, default=0, help="Max papers to process (0 = all)")
    parser.add_argument("--skip-existing", action="store_true", help="Skip chunks already submitted (check manifest)")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    chunks_dir = output_dir / "chunks"
    chunks_dir.mkdir(exist_ok=True)

    # Init Gemini client
    os.environ["GEMINI_API_KEY"] = args.gemini_api_key
    from google import genai
    client = genai.Client(api_key=args.gemini_api_key)

    # Load/resume manifest — skip chunks that are already successfully submitted or collected
    manifest_path = output_dir / "job_manifest.jsonl"
    skip_chunks = set()   # chunk_idxs to skip entirely
    retry_chunks = {}     # chunk_idx -> existing entry (for failed chunks that have uploaded files)
    if args.skip_existing and manifest_path.exists():
        with open(manifest_path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                entry = json.loads(line)
                idx = entry["chunk_idx"]
                status = entry.get("status", "")
                if status in ("submitted", "collected"):
                    skip_chunks.add(idx)
                elif status == "failed" and entry.get("uploaded_file_name"):
                    # File was uploaded successfully, only the job submission failed — reuse the file
                    retry_chunks[idx] = entry
        logger.info(f"Resuming: {len(skip_chunks)} already submitted, {len(retry_chunks)} to retry with existing uploads")

    # Load metadata
    papers = load_metadata_from_hf(args.hf_token, args.max_papers)

    # Save paper index for later reconstruction
    paper_index_path = output_dir / "paper_index.jsonl"
    if not paper_index_path.exists():
        logger.info("Saving paper index (arxiv_id order)...")
        with open(paper_index_path, "w") as f:
            for p in papers:
                f.write(json.dumps(p) + "\n")
        logger.info(f"Paper index saved: {paper_index_path}")

    # Split into chunks and submit
    chunk_size = args.chunk_size
    num_chunks = (len(papers) + chunk_size - 1) // chunk_size
    logger.info(f"Splitting {len(papers):,} papers into {num_chunks} chunks of {chunk_size:,}")

    with open(manifest_path, "a") as manifest_f:
        for chunk_idx in range(num_chunks):
            if chunk_idx in skip_chunks:
                logger.info(f"Chunk {chunk_idx}/{num_chunks-1} already submitted, skipping")
                continue

            start = chunk_idx * chunk_size
            end = min(start + chunk_size, len(papers))
            chunk_papers = papers[start:end]

            logger.info(f"Processing chunk {chunk_idx+1}/{num_chunks} (papers {start:,}-{end:,})")

            # Build JSONL only if not already on disk
            chunk_path = chunks_dir / f"chunk_{chunk_idx:04d}.jsonl"
            if not chunk_path.exists():
                chunk_path = build_jsonl_chunk(chunk_papers, chunk_idx, chunks_dir)
            else:
                logger.info(f"  JSONL already exists: {chunk_path.name}, skipping rebuild")

            # Reuse uploaded file if this chunk previously failed after a successful upload
            existing_upload = retry_chunks.get(chunk_idx, {}).get("uploaded_file_name")

            # Submit batch job
            job_display_name = f"arxiv-gemini-embed-chunk-{chunk_idx:04d}"
            try:
                batch_job_name, uploaded_file_name = submit_batch_job(
                    client, chunk_path, job_display_name, uploaded_file_name=existing_upload
                )

                entry = {
                    "chunk_idx": chunk_idx,
                    "start_paper": start,
                    "end_paper": end,
                    "num_papers": len(chunk_papers),
                    "chunk_file": str(chunk_path),
                    "uploaded_file_name": uploaded_file_name,
                    "batch_job_name": batch_job_name,
                    "submitted_at": time.time(),
                    "status": "submitted",
                }
                manifest_f.write(json.dumps(entry) + "\n")
                manifest_f.flush()

                logger.info(f"  Chunk {chunk_idx} submitted: {batch_job_name}")

                # Small delay between submissions
                time.sleep(5)

            except Exception as e:
                logger.error(f"Failed to submit chunk {chunk_idx}: {e}")
                entry = {
                    "chunk_idx": chunk_idx,
                    "start_paper": start,
                    "end_paper": end,
                    "num_papers": len(chunk_papers),
                    "chunk_file": str(chunk_path),
                    "uploaded_file_name": existing_upload,  # preserve if we had one
                    "batch_job_name": None,
                    "submitted_at": time.time(),
                    "status": "failed",
                    "error": str(e),
                }
                manifest_f.write(json.dumps(entry) + "\n")
                manifest_f.flush()

    logger.info(f"\nDone! Job manifest saved to: {manifest_path}")
    logger.info("Next step: run 02_monitor_and_collect.py to poll jobs and download results")


if __name__ == "__main__":
    main()
