#!/usr/bin/env python3
"""
Build LanceDB index from standard API embeddings and upload to HuggingFace.

Usage:
    python build_and_upload.py --hf-token hf_... [--skip-build] [--skip-upload]
"""

import argparse
import json
import logging
import sys
import time
from pathlib import Path

import lancedb
import numpy as np
import pyarrow as pa

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

EMBEDDINGS_DIR = Path("/workspace/gemini_pipeline/jobs/embeddings")
PAPER_INDEX    = Path("/workspace/gemini_pipeline/jobs/paper_index.jsonl")
INDEX_DIR      = Path("/workspace/gemini_index")
TABLE_NAME     = "arxiv_papers"
EMBED_DIM      = 3072
HF_REPO        = "Vidushee/arxiv-gemini-index"


def build_index():
    logger.info("=== Building LanceDB index ===")

    # Load paper metadata
    logger.info(f"Loading paper metadata from {PAPER_INDEX}...")
    papers_meta = {}
    with open(PAPER_INDEX) as f:
        for line in f:
            p = json.loads(line)
            papers_meta[p["arxiv_id"]] = p
    logger.info(f"Loaded {len(papers_meta):,} papers")

    # Load embeddings + ids
    npy_path = EMBEDDINGS_DIR / "standard_embeddings.npy"
    ids_path = EMBEDDINGS_DIR / "standard_ids.json"
    logger.info(f"Loading embeddings from {npy_path}...")
    embeddings = np.load(str(npy_path))  # (N, 3072)
    ids = json.loads(ids_path.read_text())
    logger.info(f"Embeddings shape: {embeddings.shape}, IDs: {len(ids):,}")
    assert len(ids) == len(embeddings), "ID/embedding count mismatch"

    # Schema
    schema = pa.schema([
        pa.field("vector", pa.list_(pa.float32(), EMBED_DIM)),
        pa.field("arxiv_id", pa.string()),
        pa.field("title", pa.string()),
        pa.field("abstract", pa.string()),
        pa.field("authors", pa.string()),
        pa.field("categories", pa.string()),
        pa.field("primary_category", pa.string()),
        pa.field("published", pa.string()),
        pa.field("updated", pa.string()),
        pa.field("doi", pa.string()),
        pa.field("journal_ref", pa.string()),
        pa.field("comment", pa.string()),
    ])

    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    db = lancedb.connect(str(INDEX_DIR))

    # Stream into LanceDB in batches
    BATCH = 5000
    table = None
    total = 0
    missing = 0
    t0 = time.time()

    def flush(records):
        nonlocal table, total
        if not records:
            return
        if table is None:
            table = db.create_table(TABLE_NAME, records, schema=schema, mode="overwrite")
        else:
            table.add(records)
        total += len(records)
        if total % 50_000 == 0:
            elapsed = time.time() - t0
            logger.info(f"  Indexed {total:,} papers ({total/elapsed:.0f}/s)")

    batch = []
    for arxiv_id, emb in zip(ids, embeddings):
        meta = papers_meta.get(arxiv_id)
        if meta is None:
            missing += 1
            continue
        batch.append({
            "vector": emb.tolist(),
            "arxiv_id": arxiv_id,
            "title": meta.get("title", ""),
            "abstract": meta.get("abstract", ""),
            "authors": meta.get("authors", "[]"),
            "categories": meta.get("categories", "[]"),
            "primary_category": meta.get("primary_category", ""),
            "published": str(meta.get("published", "")),
            "updated": str(meta.get("updated", "")),
            "doi": meta.get("doi", ""),
            "journal_ref": meta.get("journal_ref", ""),
            "comment": meta.get("comment", ""),
        })
        if len(batch) >= BATCH:
            flush(batch)
            batch = []
    flush(batch)

    if missing:
        logger.warning(f"  {missing:,} IDs had no metadata (skipped)")
    logger.info(f"Indexed {total:,} papers total in {time.time()-t0:.0f}s")

    # IVF-PQ vector index
    logger.info("Building IVF-PQ vector index (256 partitions, 128 sub-vectors)...")
    table.create_index(metric="cosine", num_partitions=256, num_sub_vectors=128)
    logger.info("Vector index built")

    # BM25 FTS indexes
    for field in ["title", "abstract"]:
        logger.info(f"Building FTS index on '{field}'...")
        try:
            table.create_fts_index([field], replace=True)
        except Exception as e:
            logger.warning(f"FTS on '{field}' failed: {e}")

    # Save metadata
    meta_out = {
        "embedding_model": "gemini-embedding-2-preview",
        "embedding_dim": EMBED_DIM,
        "num_papers": total,
        "table_name": TABLE_NAME,
    }
    (INDEX_DIR / "index_metadata.json").write_text(json.dumps(meta_out, indent=2))
    logger.info(f"Index ready at {INDEX_DIR}")


def upload_to_hf(hf_token: str):
    logger.info(f"=== Uploading to HuggingFace: {HF_REPO} ===")
    from huggingface_hub import HfApi

    api = HfApi(token=hf_token)

    # Create repo if needed
    api.create_repo(repo_id=HF_REPO, repo_type="dataset", exist_ok=True, private=False)
    logger.info(f"Repo ready: {HF_REPO}")

    # Upload entire index directory
    logger.info(f"Uploading {INDEX_DIR} ...")
    api.upload_folder(
        folder_path=str(INDEX_DIR),
        repo_id=HF_REPO,
        repo_type="dataset",
        commit_message="Add Gemini-2 embedding index (928k CS papers, dim=3072)",
    )
    logger.info(f"Upload complete: https://huggingface.co/datasets/{HF_REPO}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--hf-token", required=True)
    parser.add_argument("--skip-build", action="store_true", help="Skip index build, go straight to upload")
    parser.add_argument("--skip-upload", action="store_true", help="Only build, don't upload")
    args = parser.parse_args()

    if not args.skip_build:
        build_index()

    if not args.skip_upload:
        upload_to_hf(args.hf_token)


if __name__ == "__main__":
    main()
