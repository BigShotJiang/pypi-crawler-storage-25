#!/usr/bin/env python3
"""
Upload 5 JSONL parts and submit 5 batch embedding jobs simultaneously.
"""
import json, time, warnings
from pathlib import Path
from google import genai
from google.genai import types

API_KEY = "AIzaSyBUUxFmTk4oQa02Qm2dLQgPctqWfjnowTw"
JOBS_DIR = Path("/workspace/gemini_pipeline/jobs")
MODEL = "gemini-embedding-2-preview"

client = genai.Client(api_key=API_KEY)

parts = sorted(JOBS_DIR.glob("part_*"))
print(f"Found {len(parts)} parts: {[p.name for p in parts]}")

results = []
for part in parts:
    print(f"\nUploading {part.name} ({part.stat().st_size/1024/1024:.0f} MB)...", flush=True)
    uploaded = client.files.upload(
        file=str(part),
        config=types.UploadFileConfig(display_name=part.name, mime_type="application/jsonl")
    )
    print(f"  Uploaded: {uploaded.name}", flush=True)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        job = client.batches.create_embeddings(
            model=MODEL,
            src=types.EmbeddingsBatchJobSource(file_name=uploaded.name),
            config={"display_name": f"arxiv-embed-{part.name}"}
        )
    print(f"  Job: {job.name}  State: {job.state}", flush=True)
    results.append({"part": part.name, "uploaded_file": uploaded.name, "job_name": job.name})
    time.sleep(3)

with open(JOBS_DIR / "five_jobs.json", "w") as f:
    json.dump(results, f, indent=2)

print(f"\nAll 5 jobs submitted. Saved to five_jobs.json")
for r in results:
    print(f"  {r['part']} -> {r['job_name']}")
