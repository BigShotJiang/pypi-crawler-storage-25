#!/usr/bin/env python3
"""
Step 4: Upload Gemini Index to HuggingFace
==========================================
Uploads the built LanceDB index (with Gemini embeddings) to HuggingFace
under the Vidushee account.

Target repo: Vidushee/arxiv-gemini-search-index (dataset)

Usage:
    python 04_upload_to_hf.py \
        --index-dir /workspace/gemini_index \
        --hf-token hf_... \
        [--repo-id Vidushee/arxiv-gemini-search-index] \
        [--private]
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

DEFAULT_REPO_ID = "Vidushee/arxiv-gemini-search-index"
INDEX_DIR_NAME = "arxiv_gemini_index"


def upload_index(
    index_dir: Path,
    repo_id: str,
    hf_token: str,
    private: bool = False,
) -> str:
    from huggingface_hub import HfApi

    api = HfApi(token=hf_token)

    logger.info(f"Creating/verifying HF dataset repo: {repo_id}")
    api.create_repo(
        repo_id=repo_id,
        repo_type="dataset",
        exist_ok=True,
        private=private,
    )

    logger.info(f"Uploading index from {index_dir} to {repo_id}/{INDEX_DIR_NAME}")
    logger.info("This may take a while for large indexes (~4-8 GB)...")

    api.upload_folder(
        folder_path=str(index_dir),
        path_in_repo=INDEX_DIR_NAME,
        repo_id=repo_id,
        repo_type="dataset",
        commit_message="Add Gemini embedding-2-preview arxiv index",
    )

    url = f"https://huggingface.co/datasets/{repo_id}"
    logger.info(f"Index uploaded to: {url}")
    return url


def create_dataset_card(index_dir: Path, repo_id: str, hf_token: str) -> None:
    """Create a README/dataset card describing the index."""
    import json
    from huggingface_hub import HfApi

    meta_path = index_dir / "index_metadata.json"
    meta = {}
    if meta_path.exists():
        with open(meta_path) as f:
            meta = json.load(f)

    card_content = f"""---
license: mit
tags:
- arxiv
- embeddings
- semantic-search
- gemini
- lancedb
---

# ArXiv Gemini Embedding Index

Pre-built LanceDB vector index for semantic search over ArXiv papers,
using **{meta.get('embedding_model', 'gemini-embedding-2-preview')}** embeddings.

## Stats

- **Papers**: {meta.get('num_papers', 'N/A'):,}
- **Embedding model**: `{meta.get('embedding_model', 'gemini-embedding-2-preview')}`
- **Embedding dimension**: {meta.get('embedding_dim', 3072)}
- **Vector index**: IVF-PQ (partitions={meta.get('num_partitions', 256)}, sub_vectors={meta.get('num_sub_vectors', 128)})
- **Text search**: BM25 FTS on title + abstract

## Usage

```python
from arxiv_search_kit import ArxivClient
from huggingface_hub import snapshot_download

# Download the index
index_path = snapshot_download(
    repo_id="{repo_id}",
    repo_type="dataset",
    local_dir="./arxiv_gemini_cache",
    allow_patterns=["{INDEX_DIR_NAME}/**"],
)

# Use with ArxivClient (with Gemini embedder)
client = ArxivClient(index_dir=f"{{index_path}}/{INDEX_DIR_NAME}")
results = client.search("transformer attention mechanism")
```

## Embedding format

Documents were embedded using the asymmetric retrieval format:

```
title: {{paper_title}} | text: {{abstract}}
```

Queries should use:

```
task: search result | query: {{your_query}}
```
"""

    api = HfApi(token=hf_token)
    api.upload_file(
        path_or_fileobj=card_content.encode("utf-8"),
        path_in_repo="README.md",
        repo_id=repo_id,
        repo_type="dataset",
        commit_message="Add dataset card",
    )
    logger.info("Dataset card uploaded")


def main():
    parser = argparse.ArgumentParser(description="Upload Gemini index to HuggingFace")
    parser.add_argument("--index-dir", required=True, help="Path to the built LanceDB index (step 3 output)")
    parser.add_argument("--hf-token", required=True, help="HuggingFace write token")
    parser.add_argument("--repo-id", default=DEFAULT_REPO_ID, help=f"HF repo ID (default: {DEFAULT_REPO_ID})")
    parser.add_argument("--private", action="store_true", help="Make repo private")
    args = parser.parse_args()

    index_dir = Path(args.index_dir)
    if not index_dir.exists():
        logger.error(f"Index directory not found: {index_dir}")
        sys.exit(1)

    url = upload_index(index_dir, args.repo_id, args.hf_token, args.private)
    create_dataset_card(index_dir, args.repo_id, args.hf_token)

    logger.info(f"\nDone! Index available at: {url}")
    logger.info("Next step: run 05_benchmark.py to compare SPECTER2 vs Gemini embeddings")


if __name__ == "__main__":
    main()
