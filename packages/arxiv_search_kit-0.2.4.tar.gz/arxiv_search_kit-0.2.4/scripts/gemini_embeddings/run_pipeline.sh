#!/bin/bash
# ============================================================
# Full Gemini Embedding Pipeline for ArXiv
# ============================================================
# Run this on the remote vst.ai machine.
# Prereq: Set env vars GEMINI_API_KEY and HF_TOKEN
#
# Usage:
#   export GEMINI_API_KEY="AIza..."
#   export HF_TOKEN="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"
#   bash run_pipeline.sh
# ============================================================

set -euo pipefail

# ---- Config ----
WORKSPACE="/workspace/gemini_pipeline"
JOBS_DIR="$WORKSPACE/jobs"
INDEX_DIR="$WORKSPACE/gemini_index"
SPECTER_INDEX="${SPECTER_INDEX:-$HOME/.cache/arxiv_search_kit/arxiv_index}"  # override if needed
CHUNK_SIZE=50000    # papers per batch job (50k is safe for <20MB JSONL)
NUM_PARTITIONS=256
NUM_SUB_VECTORS=128
HF_REPO="Vidushee/arxiv-gemini-search-index"
TOP_K=10

if [ -z "${GEMINI_API_KEY:-}" ]; then
    echo "ERROR: GEMINI_API_KEY not set"
    exit 1
fi

if [ -z "${HF_TOKEN:-}" ]; then
    echo "ERROR: HF_TOKEN not set"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "Script dir: $SCRIPT_DIR"

# ---- Install deps ----
echo ""
echo "=== Installing dependencies ==="
pip install -q google-genai datasets huggingface_hub lancedb numpy pyarrow

# ---- Step 1: Submit batch jobs ----
echo ""
echo "=== STEP 1: Submit Gemini batch embedding jobs ==="
python "$SCRIPT_DIR/01_submit_batch_jobs.py" \
    --gemini-api-key "$GEMINI_API_KEY" \
    --hf-token "$HF_TOKEN" \
    --output-dir "$JOBS_DIR" \
    --chunk-size "$CHUNK_SIZE" \
    --skip-existing

echo "Step 1 complete. Jobs submitted."

# ---- Step 2: Monitor and collect results ----
echo ""
echo "=== STEP 2: Monitor batch jobs and collect embeddings ==="
echo "This will poll every 60s until all jobs complete (up to 24h)..."
python "$SCRIPT_DIR/02_monitor_and_collect.py" \
    --gemini-api-key "$GEMINI_API_KEY" \
    --output-dir "$JOBS_DIR" \
    --poll-interval 60

echo "Step 2 complete. Embeddings collected."

# ---- Step 3: Build LanceDB index ----
echo ""
echo "=== STEP 3: Build LanceDB index ==="
python "$SCRIPT_DIR/03_build_gemini_index.py" \
    --jobs-dir "$JOBS_DIR" \
    --output-dir "$INDEX_DIR" \
    --num-partitions "$NUM_PARTITIONS" \
    --num-sub-vectors "$NUM_SUB_VECTORS"

echo "Step 3 complete. Index built at $INDEX_DIR"

# ---- Step 4: Upload to HuggingFace ----
echo ""
echo "=== STEP 4: Upload index to HuggingFace ==="
python "$SCRIPT_DIR/04_upload_to_hf.py" \
    --index-dir "$INDEX_DIR" \
    --hf-token "$HF_TOKEN" \
    --repo-id "$HF_REPO"

echo "Step 4 complete. Index uploaded to HuggingFace: https://huggingface.co/datasets/$HF_REPO"

# ---- Step 5: Benchmark (optional, requires SPECTER2 index) ----
if [ -d "$SPECTER_INDEX" ]; then
    echo ""
    echo "=== STEP 5: Benchmark SPECTER2 vs Gemini ==="
    # Install specter2 deps for benchmark
    pip install -q torch adapters transformers
    pip install -e "$SCRIPT_DIR/../.." 2>/dev/null || true

    python "$SCRIPT_DIR/05_benchmark.py" \
        --specter-index "$SPECTER_INDEX" \
        --gemini-index "$INDEX_DIR" \
        --gemini-api-key "$GEMINI_API_KEY" \
        --mode both \
        --n-queries 50 \
        --top-k "$TOP_K" \
        --output "$WORKSPACE/benchmark_results.json"

    echo "Benchmark complete. Results at $WORKSPACE/benchmark_results.json"
else
    echo ""
    echo "=== STEP 5: Skipping benchmark (SPECTER2 index not found at $SPECTER_INDEX) ==="
    echo "To run benchmark, set SPECTER_INDEX=/path/to/specter_index and re-run step 5 manually."
fi

echo ""
echo "======================================================"
echo "PIPELINE COMPLETE!"
echo "  Gemini index:  $INDEX_DIR"
echo "  HuggingFace:   https://huggingface.co/datasets/$HF_REPO"
echo "======================================================"
