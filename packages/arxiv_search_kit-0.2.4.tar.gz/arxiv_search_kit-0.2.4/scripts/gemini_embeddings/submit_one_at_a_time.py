#!/usr/bin/env python3
"""
Submit remaining batch embedding jobs one at a time, waiting for queue to drain.
Submits a new job only when the number of active (PENDING/RUNNING) embedding
batch jobs is below MAX_CONCURRENT.
"""

import json
import time
import warnings
from pathlib import Path

from google import genai
from google.genai import types

API_KEY = "AIzaSyBUUxFmTk4oQa02Qm2dLQgPctqWfjnowTw"
JOBS_DIR = Path("/workspace/gemini_pipeline/jobs")
CHUNKS_DIR = JOBS_DIR / "chunks"
MANIFEST_PATH = JOBS_DIR / "job_manifest.jsonl"
MODEL = "gemini-embedding-2-preview"
MAX_CONCURRENT = 3   # submit next job only when <3 of OUR embedding jobs are active
POLL_WAIT = 30       # seconds to wait between queue checks

client = genai.Client(api_key=API_KEY)


def load_manifest():
    entries = {}
    if MANIFEST_PATH.exists():
        with open(MANIFEST_PATH) as f:
            for line in f:
                line = line.strip()
                if line:
                    e = json.loads(line)
                    idx = e["chunk_idx"]
                    # Keep best status: submitted > failed
                    if idx not in entries or e["status"] == "submitted":
                        entries[idx] = e
    return entries


def save_entry(entry):
    with open(MANIFEST_PATH, "a") as f:
        f.write(json.dumps(entry) + "\n")


def count_active_our_jobs():
    """Count our arxiv embedding jobs that are still PENDING or RUNNING."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        jobs = list(client.batches.list())
    active = 0
    for j in jobs:
        state = j.state.name if hasattr(j.state, "name") else str(j.state)
        name = getattr(j, "display_name", "") or ""
        model = getattr(j, "model", "") or ""
        is_ours = "arxiv-gemini-embed" in name and "embedding" in model
        if is_ours and state in ("JOB_STATE_PENDING", "JOB_STATE_RUNNING"):
            active += 1
    return active


def submit_chunk(chunk_idx):
    chunk_path = CHUNKS_DIR / f"chunk_{chunk_idx:04d}.jsonl"
    if not chunk_path.exists():
        print(f"  ERROR: {chunk_path} not found!")
        return None

    print(f"  Uploading {chunk_path.name}...")
    uploaded = client.files.upload(
        file=str(chunk_path),
        config=types.UploadFileConfig(
            display_name=chunk_path.name, mime_type="application/jsonl"
        ),
    )
    print(f"  Uploaded: {uploaded.name}")

    job_name = f"arxiv-gemini-embed-chunk-{chunk_idx:04d}"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        job = client.batches.create_embeddings(
            model=MODEL,
            src={"file_name": uploaded.name},
            config={"display_name": job_name},
        )
    print(f"  Job created: {job.name}")
    return job.name, uploaded.name


# Determine how many papers per chunk from manifest or default
CHUNK_BOUNDARIES = {
    0: (0, 50000), 1: (50000, 100000), 2: (100000, 150000),
    3: (150000, 200000), 4: (200000, 250000), 5: (250000, 300000),
    6: (300000, 350000), 7: (350000, 400000), 8: (400000, 450000),
    9: (450000, 500000), 10: (500000, 550000), 11: (550000, 600000),
    12: (600000, 650000), 13: (650000, 700000), 14: (700000, 750000),
    15: (750000, 800000), 16: (800000, 850000), 17: (850000, 900000),
    18: (900000, 928523),
}

manifest = load_manifest()
submitted = {idx for idx, e in manifest.items() if e["status"] == "submitted"}
print(f"Already submitted: {sorted(submitted)}")

pending_chunks = [i for i in range(19) if i not in submitted]
print(f"Need to submit: {sorted(pending_chunks)}")

for chunk_idx in sorted(pending_chunks):
    # Wait until queue has room
    while True:
        active = count_active_our_jobs()
        print(f"[chunk {chunk_idx:02d}] Active embedding jobs: {active}/{MAX_CONCURRENT}")
        if active < MAX_CONCURRENT:
            break
        print(f"  Queue full, waiting {POLL_WAIT}s...")
        time.sleep(POLL_WAIT)

    print(f"Submitting chunk {chunk_idx}...")
    try:
        batch_job_name, uploaded_file_name = submit_chunk(chunk_idx)
        start, end = CHUNK_BOUNDARIES[chunk_idx]
        entry = {
            "chunk_idx": chunk_idx,
            "start_paper": start,
            "end_paper": end,
            "num_papers": end - start,
            "chunk_file": str(CHUNKS_DIR / f"chunk_{chunk_idx:04d}.jsonl"),
            "uploaded_file_name": uploaded_file_name,
            "batch_job_name": batch_job_name,
            "submitted_at": time.time(),
            "status": "submitted",
        }
        save_entry(entry)
        print(f"  Chunk {chunk_idx} saved to manifest")
        time.sleep(5)  # brief pause after each submission
    except Exception as e:
        print(f"  FAILED chunk {chunk_idx}: {e}")
        start, end = CHUNK_BOUNDARIES[chunk_idx]
        save_entry({
            "chunk_idx": chunk_idx, "start_paper": start, "end_paper": end,
            "num_papers": end - start,
            "chunk_file": str(CHUNKS_DIR / f"chunk_{chunk_idx:04d}.jsonl"),
            "batch_job_name": None, "submitted_at": time.time(),
            "status": "failed", "error": str(e),
        })

print("\nAll chunks submitted. Run 02_monitor_and_collect.py next.")
