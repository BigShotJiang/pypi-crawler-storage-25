#!/usr/bin/env python3
"""
Step 3: Build LanceDB Index from Gemini Embeddings
====================================================
Reads the collected .npy embedding files and the original paper metadata,
then builds a LanceDB index identical in structure to the SPECTER2 index
but with Gemini embeddings (dim=3072 for gemini-embedding-2-preview).

The index is stored at output_dir/gemini_index/ and can be used directly
with ArxivClient by passing index_dir=<path>.

Usage:
    python 03_build_gemini_index.py \
        --jobs-dir /workspace/gemini_jobs \
        --output-dir /workspace/gemini_index \
        [--num-partitions 256] \
        [--num-sub-vectors 128]
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import lancedb
import numpy as np
import pyarrow as pa

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

TABLE_NAME = "arxiv_papers"


def load_paper_metadata(jobs_dir: Path) -> dict[str, dict]:
    """Load paper metadata from the paper_index.jsonl saved in step 1."""
    paper_index_path = jobs_dir / "paper_index.jsonl"
    if not paper_index_path.exists():
        raise FileNotFoundError(f"paper_index.jsonl not found at {paper_index_path}")

    logger.info(f"Loading paper metadata from {paper_index_path}")
    papers = {}
    with open(paper_index_path) as f:
        for line in f:
            line = line.strip()
            if line:
                p = json.loads(line)
                arxiv_id = p["arxiv_id"]
                papers[arxiv_id] = p

    logger.info(f"Loaded metadata for {len(papers):,} papers")
    return papers


def load_collected_chunks(jobs_dir: Path) -> list[dict]:
    """Load manifest and return only successfully collected chunks."""
    manifest_path = jobs_dir / "job_manifest.jsonl"
    if not manifest_path.exists():
        raise FileNotFoundError(f"job_manifest.jsonl not found at {manifest_path}")

    chunks = []
    with open(manifest_path) as f:
        for line in f:
            line = line.strip()
            if line:
                entry = json.loads(line)
                if entry.get("status") == "collected":
                    chunks.append(entry)

    chunks.sort(key=lambda x: x["chunk_idx"])
    logger.info(f"Found {len(chunks)} collected chunks")
    return chunks


def iter_embeddings_and_papers(
    chunks: list[dict],
    papers_meta: dict[str, dict],
    batch_size: int = 5000,
):
    """Yield (batch_records) tuples by streaming through chunk files."""
    total_yielded = 0
    total_missing = 0
    batch_records = []

    for chunk in chunks:
        npy_path = Path(chunk["npy_path"])
        ids_path = Path(chunk["ids_path"])

        logger.info(f"  Loading chunk {chunk['chunk_idx']} from {npy_path.name}")
        embeddings = np.load(str(npy_path))  # shape (N, dim)
        with open(ids_path) as f:
            ids = json.load(f)

        assert len(ids) == len(embeddings), f"Mismatch: {len(ids)} ids vs {len(embeddings)} embeddings"

        for arxiv_id, embedding in zip(ids, embeddings):
            meta = papers_meta.get(arxiv_id)
            if meta is None:
                total_missing += 1
                continue

            record = {
                "vector": embedding.tolist(),
                "arxiv_id": arxiv_id,
                "title": meta.get("title", ""),
                "abstract": meta.get("abstract", ""),
                "authors": meta.get("authors", "[]"),
                "categories": meta.get("categories", "[]"),
                "primary_category": meta.get("primary_category", ""),
                "published": meta.get("published", ""),
                "updated": meta.get("updated", ""),
                "doi": meta.get("doi", ""),
                "journal_ref": meta.get("journal_ref", ""),
                "comment": meta.get("comment", ""),
            }
            batch_records.append(record)

            if len(batch_records) >= batch_size:
                total_yielded += len(batch_records)
                yield batch_records
                batch_records = []

    if batch_records:
        total_yielded += len(batch_records)
        yield batch_records

    if total_missing:
        logger.warning(f"  {total_missing:,} arxiv IDs had no metadata (skipped)")
    logger.info(f"  Total yielded: {total_yielded:,} records")


def detect_embedding_dim(chunks: list[dict]) -> int:
    """Detect embedding dimension from the first chunk."""
    if not chunks:
        raise ValueError("No chunks available")
    dim = chunks[0].get("embedding_dim")
    if dim:
        return int(dim)
    # Fall back: load first npy
    npy = np.load(chunks[0]["npy_path"])
    return npy.shape[1]


def build_lancedb_index(
    jobs_dir: Path,
    output_dir: Path,
    num_partitions: int = 256,
    num_sub_vectors: int = 128,
    batch_size: int = 5000,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load inputs
    papers_meta = load_paper_metadata(jobs_dir)
    chunks = load_collected_chunks(jobs_dir)

    if not chunks:
        raise RuntimeError("No collected chunks found. Run steps 1 and 2 first.")

    # Detect embedding dimension
    embed_dim = detect_embedding_dim(chunks)
    logger.info(f"Embedding dimension: {embed_dim}")

    # Define LanceDB schema — same as SPECTER2 index but with different vector dim
    schema = pa.schema([
        pa.field("vector", pa.list_(pa.float32(), embed_dim)),
        pa.field("arxiv_id", pa.string()),
        pa.field("title", pa.string()),
        pa.field("abstract", pa.string()),
        pa.field("authors", pa.string()),       # JSON string
        pa.field("categories", pa.string()),    # JSON string
        pa.field("primary_category", pa.string()),
        pa.field("published", pa.string()),
        pa.field("updated", pa.string()),
        pa.field("doi", pa.string()),
        pa.field("journal_ref", pa.string()),
        pa.field("comment", pa.string()),
    ])

    # Connect to LanceDB
    db = lancedb.connect(str(output_dir))

    # Stream records into LanceDB
    logger.info(f"Building LanceDB table '{TABLE_NAME}' at {output_dir}")
    table = None
    total_papers = 0

    for batch_records in iter_embeddings_and_papers(chunks, papers_meta, batch_size=batch_size):
        if table is None:
            table = db.create_table(TABLE_NAME, batch_records, schema=schema, mode="overwrite")
        else:
            table.add(batch_records)

        total_papers += len(batch_records)
        if total_papers % 50_000 == 0:
            logger.info(f"  Indexed {total_papers:,} papers")

    if table is None or total_papers == 0:
        raise RuntimeError("No papers were indexed. Check that embeddings and metadata match.")

    logger.info(f"Indexed {total_papers:,} papers total")

    # Build IVF-PQ vector index
    logger.info(f"Building IVF-PQ vector index (partitions={num_partitions}, sub_vectors={num_sub_vectors})")
    try:
        table.create_index(
            metric="cosine",
            num_partitions=num_partitions,
            num_sub_vectors=num_sub_vectors,
        )
        logger.info("Vector index built")
    except Exception as e:
        logger.error(f"Vector index build failed: {e}")
        raise

    # Build BM25 FTS indexes
    for field in ["title", "abstract"]:
        logger.info(f"Building FTS (BM25) index on '{field}'")
        try:
            table.create_fts_index([field], replace=True)
        except Exception as e:
            logger.warning(f"FTS index on '{field}' failed (non-fatal): {e}")

    # Save metadata about this index
    index_meta = {
        "embedding_model": "gemini-embedding-2-preview",
        "embedding_dim": embed_dim,
        "num_papers": total_papers,
        "num_chunks": len(chunks),
        "num_partitions": num_partitions,
        "num_sub_vectors": num_sub_vectors,
        "table_name": TABLE_NAME,
    }
    with open(output_dir / "index_metadata.json", "w") as f:
        json.dump(index_meta, f, indent=2)

    logger.info(f"\nIndex build complete!")
    logger.info(f"  Papers: {total_papers:,}")
    logger.info(f"  Embedding dim: {embed_dim}")
    logger.info(f"  Location: {output_dir}")
    logger.info("Next step: run 04_upload_to_hf.py to push the index to HuggingFace")


def main():
    parser = argparse.ArgumentParser(description="Build LanceDB index from Gemini embeddings")
    parser.add_argument("--jobs-dir", required=True, help="Output dir from steps 1 & 2 (contains embeddings/ and paper_index.jsonl)")
    parser.add_argument("--output-dir", required=True, help="Where to store the LanceDB index")
    parser.add_argument("--num-partitions", type=int, default=256, help="IVF-PQ partitions (default: 256)")
    parser.add_argument("--num-sub-vectors", type=int, default=128, help="PQ sub-vectors (default: 128)")
    parser.add_argument("--batch-size", type=int, default=5000, help="Records per LanceDB write batch (default: 5000)")
    args = parser.parse_args()

    build_lancedb_index(
        jobs_dir=Path(args.jobs_dir),
        output_dir=Path(args.output_dir),
        num_partitions=args.num_partitions,
        num_sub_vectors=args.num_sub_vectors,
        batch_size=args.batch_size,
    )


if __name__ == "__main__":
    main()
