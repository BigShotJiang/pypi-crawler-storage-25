# db-optimiser-agent

An AI-powered database performance agent. Connect it to a PostgreSQL or MySQL database and it analyses schemas, slow queries, and index health — then delivers ranked, actionable recommendations with copy-paste SQL to fix them.

## Quick start

```bash
# 1. Clone and enter the project
git clone <your-repo>
cd db-optimiser-agent

# 2. Create a virtual environment
python3.11 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Install the package in editable mode
pip install -e ".[dev]"

# 4. Set up your environment
cp .env.example .env
# Edit .env with your Anthropic API key and database credentials

# 5. Run your first analysis
db-optimiser analyse
```

## Project structure

```
db-optimiser-agent/
├── src/db_optimiser_agent/
│   ├── prompts/          # System prompt (the agent's brain)
│   ├── adapters/         # PostgreSQL + MySQL connection adapters  [Phase 1 Step 3]
│   ├── tools/            # Schema analyser, slow query finder, etc [Phase 2]
│   ├── config.py         # Environment-based configuration
│   └── cli.py            # Typer CLI entry point                   [Phase 1 Step 2]
├── tests/
├── scripts/              # Docker, seed scripts
├── .env.example
└── pyproject.toml
```

## Environment variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `ANTHROPIC_API_KEY` | Yes | — | Your Anthropic API key |
| `DB_TYPE` | No | `postgresql` | `postgresql` or `mysql` |
| `DB_HOST` | No | `localhost` | Database host |
| `DB_PORT` | No | `5432` | Database port |
| `DB_NAME` | Yes | — | Database name |
| `DB_USER` | Yes | — | Database user |
| `DB_PASSWORD` | Yes | — | Database password |
| `DB_SCHEMA` | No | `public` | PostgreSQL schema |

## Development

```bash
# Run tests
pytest

# Lint
ruff check src/

# Type check
mypy src/
```
