"""
Tests for the DatabaseOptimizerAgent and its response parsers.

These tests mock the Anthropic client so they run without an API key
and without a real database connection.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from db_optimiser_agent.agent import (
    DatabaseOptimizerAgent,
    _build_analysis_message,
    _parse_analysis_report,
    _parse_diagnostic_findings,
    _parse_remediations,
)
from db_optimiser_agent.config import AgentConfig, DatabaseType, ModelProvider
from db_optimiser_agent.models import (
    DatabaseContext,
    DiagnosticFinding,
    FindingCategory,
    RemediationScope,
    RiskLevel,
    Severity,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def config() -> AgentConfig:
    return AgentConfig(
        provider=ModelProvider.ANTHROPIC,
        anthropic_api_key="sk-ant-test-key",
        model="claude-sonnet-4-6",
        db_type=DatabaseType.POSTGRES,
        db_host="localhost",
        db_port=5432,
        db_name="testdb",
        db_user="testuser",
        db_password="testpass",
    )


@pytest.fixture()
def sample_context() -> DatabaseContext:
    return DatabaseContext(
        db_type="postgresql",
        db_name="testdb",
        schema_name="public",
        tables=[
            {"name": "users", "row_count": 50_000, "size": "12 MB"},
            {"name": "orders", "row_count": 2_000_000, "size": "850 MB"},
        ],
        slow_queries=[
            {
                "query": "SELECT * FROM orders WHERE user_id = $1",
                "mean_ms": 3200,
                "calls": 45000,
                "total_ms": 144_000_000,
            }
        ],
        missing_fk_indexes=[
            {"table": "orders", "column": "user_id", "references": "users(id)"}
        ],
    )


# Call 1 (analysis) sample markdown — no SQL in findings
SAMPLE_MARKDOWN = """
## Summary
Two critical issues found: a missing index on `orders.user_id` causing sequential scans over 2M rows,
and an unused composite index wasting write overhead.

## Findings

- **ID**: FIND-001
- **Severity**: CRITICAL
- **Category**: MISSING_INDEX
- **Table / Query affected**: `orders`
- **Root cause**: No index on `orders.user_id` forces a sequential scan over 2M rows on every lookup.
- **Impact**: Mean query time 3200ms. Estimated improvement: 50-100x after indexing.
- **Risk**: SAFE

- **ID**: FIND-002
- **Severity**: MEDIUM
- **Category**: UNUSED_INDEX
- **Table / Query affected**: `users`
- **Root cause**: Index `idx_users_legacy_email` has 0 scans in the past 30 days.
- **Impact**: Adds ~5ms overhead to every INSERT/UPDATE on users table.
- **Risk**: REVIEW_FIRST

## Quick Wins
- FIND-001 — add missing index on orders.user_id

## Deferred Actions
- FIND-002 — verify index is truly unused before dropping
"""

# Call 2 (remediation) sample markdown
SAMPLE_REMEDIATION_MARKDOWN = """
## FIND-001
### Fix
```sql
CREATE INDEX CONCURRENTLY idx_orders_user_id ON public.orders(user_id);
```
### Rollback
```sql
DROP INDEX CONCURRENTLY IF EXISTS public.idx_orders_user_id;
```

## FIND-002
### Fix
```sql
DROP INDEX CONCURRENTLY IF EXISTS public.idx_users_legacy_email;
```
### Rollback
```sql
CREATE INDEX CONCURRENTLY idx_users_legacy_email ON public.users(email);
```
"""


# ---------------------------------------------------------------------------
# Context builder tests
# ---------------------------------------------------------------------------

class TestBuildAnalysisMessage:
    def test_includes_db_metadata(self, sample_context: DatabaseContext) -> None:
        msg = _build_analysis_message(sample_context)
        assert "testdb" in msg
        assert "postgresql" in msg
        assert "public" in msg

    def test_includes_table_info(self, sample_context: DatabaseContext) -> None:
        msg = _build_analysis_message(sample_context)
        assert "orders" in msg
        assert "2000000" in msg or "2_000_000" in msg

    def test_includes_slow_queries(self, sample_context: DatabaseContext) -> None:
        msg = _build_analysis_message(sample_context)
        assert "SELECT * FROM orders" in msg
        assert "3200" in msg

    def test_includes_missing_fk(self, sample_context: DatabaseContext) -> None:
        msg = _build_analysis_message(sample_context)
        assert "user_id" in msg

    def test_empty_context_does_not_crash(self) -> None:
        ctx = DatabaseContext(db_type="postgresql", db_name="empty")
        msg = _build_analysis_message(ctx)
        assert "empty" in msg


# ---------------------------------------------------------------------------
# Call 1 parser tests
# ---------------------------------------------------------------------------

class TestParseDiagnosticFindings:
    def test_extracts_two_findings(self) -> None:
        findings = _parse_diagnostic_findings(SAMPLE_MARKDOWN)
        assert len(findings) == 2

    def test_first_finding_severity(self) -> None:
        findings = _parse_diagnostic_findings(SAMPLE_MARKDOWN)
        assert findings[0].severity == Severity.CRITICAL

    def test_first_finding_category(self) -> None:
        findings = _parse_diagnostic_findings(SAMPLE_MARKDOWN)
        assert findings[0].category == FindingCategory.MISSING_INDEX

    def test_first_finding_risk_safe(self) -> None:
        findings = _parse_diagnostic_findings(SAMPLE_MARKDOWN)
        assert findings[0].risk == RiskLevel.SAFE

    def test_second_finding_risk_review(self) -> None:
        findings = _parse_diagnostic_findings(SAMPLE_MARKDOWN)
        assert findings[1].risk == RiskLevel.REVIEW_FIRST

    def test_findings_are_diagnostic_type(self) -> None:
        findings = _parse_diagnostic_findings(SAMPLE_MARKDOWN)
        assert all(isinstance(f, DiagnosticFinding) for f in findings)

    def test_empty_markdown_returns_empty_list(self) -> None:
        assert _parse_diagnostic_findings("") == []


class TestParseAnalysisReport:
    def test_summary_extracted(self, sample_context: DatabaseContext) -> None:
        report = _parse_analysis_report(SAMPLE_MARKDOWN, "ABCD1234", sample_context)
        assert "critical issues" in report.summary.lower()

    def test_quick_wins_parsed(self, sample_context: DatabaseContext) -> None:
        report = _parse_analysis_report(SAMPLE_MARKDOWN, "ABCD1234", sample_context)
        assert "FIND-001" in report.quick_wins

    def test_deferred_parsed(self, sample_context: DatabaseContext) -> None:
        report = _parse_analysis_report(SAMPLE_MARKDOWN, "ABCD1234", sample_context)
        assert "FIND-002" in report.deferred

    def test_run_id_set(self, sample_context: DatabaseContext) -> None:
        report = _parse_analysis_report(SAMPLE_MARKDOWN, "TEST0001", sample_context)
        assert report.run_id == "TEST0001"

    def test_critical_count_property(self, sample_context: DatabaseContext) -> None:
        report = _parse_analysis_report(SAMPLE_MARKDOWN, "X", sample_context)
        assert report.critical_count == 1

    def test_high_count_property(self, sample_context: DatabaseContext) -> None:
        report = _parse_analysis_report(SAMPLE_MARKDOWN, "X", sample_context)
        assert report.high_count == 0

    def test_remediations_empty_after_call1(self, sample_context: DatabaseContext) -> None:
        report = _parse_analysis_report(SAMPLE_MARKDOWN, "X", sample_context)
        assert report.remediations == []


# ---------------------------------------------------------------------------
# Call 2 parser tests
# ---------------------------------------------------------------------------

class TestParseRemediations:
    @pytest.fixture()
    def diagnostics(self) -> list[DiagnosticFinding]:
        return [
            DiagnosticFinding(
                id="FIND-001",
                severity=Severity.CRITICAL,
                category=FindingCategory.MISSING_INDEX,
                affected="orders",
                root_cause="No index on orders.user_id.",
                impact="2M row seq scan.",
                risk=RiskLevel.SAFE,
            ),
            DiagnosticFinding(
                id="FIND-002",
                severity=Severity.MEDIUM,
                category=FindingCategory.UNUSED_INDEX,
                affected="users",
                root_cause="Index has 0 scans.",
                impact="Write overhead.",
                risk=RiskLevel.REVIEW_FIRST,
            ),
        ]

    def test_extracts_two_remediations(self, diagnostics) -> None:
        remediations = _parse_remediations(SAMPLE_REMEDIATION_MARKDOWN, diagnostics)
        assert len(remediations) == 2

    def test_fix_sql_extracted(self, diagnostics) -> None:
        remediations = _parse_remediations(SAMPLE_REMEDIATION_MARKDOWN, diagnostics)
        assert "CREATE INDEX CONCURRENTLY" in remediations[0].fix_sql

    def test_rollback_sql_extracted(self, diagnostics) -> None:
        remediations = _parse_remediations(SAMPLE_REMEDIATION_MARKDOWN, diagnostics)
        assert "DROP INDEX CONCURRENTLY" in remediations[0].rollback_sql

    def test_second_finding_fix_sql(self, diagnostics) -> None:
        remediations = _parse_remediations(SAMPLE_REMEDIATION_MARKDOWN, diagnostics)
        assert "DROP INDEX CONCURRENTLY" in remediations[1].fix_sql

    def test_diagnostic_fields_preserved(self, diagnostics) -> None:
        remediations = _parse_remediations(SAMPLE_REMEDIATION_MARKDOWN, diagnostics)
        assert remediations[0].severity == Severity.CRITICAL
        assert remediations[0].category == FindingCategory.MISSING_INDEX

    def test_unknown_id_skipped(self, diagnostics) -> None:
        markdown = "## FIND-999\n### Fix\n```sql\nSELECT 1;\n```\n### Rollback\n```sql\nSELECT 1;\n```"
        remediations = _parse_remediations(markdown, diagnostics)
        assert remediations == []


# ---------------------------------------------------------------------------
# Remediation scope selection tests
# ---------------------------------------------------------------------------

class TestRemediationScope:
    @pytest.fixture()
    def report(self, sample_context: DatabaseContext):
        return _parse_analysis_report(SAMPLE_MARKDOWN, "X", sample_context)

    def test_top_n_returns_n_findings(self, report) -> None:
        selected = report.select_for_remediation(scope=RemediationScope.TOP_N, n=1)
        assert len(selected) == 1

    def test_top_n_returns_highest_severity_first(self, report) -> None:
        selected = report.select_for_remediation(scope=RemediationScope.TOP_N, n=1)
        assert selected[0].severity == Severity.CRITICAL

    def test_full_returns_all(self, report) -> None:
        selected = report.select_for_remediation(scope=RemediationScope.FULL)
        assert len(selected) == len(report.findings)

    def test_ids_returns_only_requested(self, report) -> None:
        selected = report.select_for_remediation(
            scope=RemediationScope.IDS, ids=["FIND-002"]
        )
        assert len(selected) == 1
        assert selected[0].id == "FIND-002"

    def test_ids_unknown_id_returns_empty(self, report) -> None:
        selected = report.select_for_remediation(
            scope=RemediationScope.IDS, ids=["FIND-999"]
        )
        assert selected == []


# ---------------------------------------------------------------------------
# Agent integration tests (mocked Anthropic client)
# ---------------------------------------------------------------------------

class TestDatabaseOptimizerAgent:
    def _make_mock_message(self, text: str) -> MagicMock:
        mock_content = MagicMock()
        mock_content.text = text
        mock_message = MagicMock()
        mock_message.content = [mock_content]
        mock_message.stop_reason = "end_turn"
        return mock_message

    def test_analyse_returns_report(
        self, config: AgentConfig, sample_context: DatabaseContext
    ) -> None:
        with patch("db_optimiser_agent.agent.anthropic.Anthropic") as mock_cls:
            mock_client = MagicMock()
            mock_cls.return_value = mock_client
            mock_client.messages.create.return_value = self._make_mock_message(
                SAMPLE_MARKDOWN
            )

            agent = DatabaseOptimizerAgent(config)
            report = agent.analyse(sample_context)

        assert report.db_name == "testdb"
        assert len(report.findings) == 2

    def test_analyse_calls_correct_model(
        self, config: AgentConfig, sample_context: DatabaseContext
    ) -> None:
        with patch("db_optimiser_agent.agent.anthropic.Anthropic") as mock_cls:
            mock_client = MagicMock()
            mock_cls.return_value = mock_client
            mock_client.messages.create.return_value = self._make_mock_message(
                SAMPLE_MARKDOWN
            )

            agent = DatabaseOptimizerAgent(config)
            agent.analyse(sample_context)

            call_kwargs = mock_client.messages.create.call_args.kwargs
            assert call_kwargs["model"] == "claude-sonnet-4-6"

    def test_analyse_sends_analysis_prompt(
        self, config: AgentConfig, sample_context: DatabaseContext
    ) -> None:
        with patch("db_optimiser_agent.agent.anthropic.Anthropic") as mock_cls:
            mock_client = MagicMock()
            mock_cls.return_value = mock_client
            mock_client.messages.create.return_value = self._make_mock_message(
                SAMPLE_MARKDOWN
            )

            agent = DatabaseOptimizerAgent(config)
            agent.analyse(sample_context)

            call_kwargs = mock_client.messages.create.call_args.kwargs
            assert "Database Optimizer Agent" in call_kwargs["system"]

    def test_remediate_populates_remediations(
        self, config: AgentConfig, sample_context: DatabaseContext
    ) -> None:
        with patch("db_optimiser_agent.agent.anthropic.Anthropic") as mock_cls:
            mock_client = MagicMock()
            mock_cls.return_value = mock_client
            mock_client.messages.create.side_effect = [
                self._make_mock_message(SAMPLE_MARKDOWN),
                self._make_mock_message(SAMPLE_REMEDIATION_MARKDOWN),
            ]

            agent = DatabaseOptimizerAgent(config)
            report = agent.analyse(sample_context)
            report = agent.remediate(
                report, sample_context, scope=RemediationScope.FULL
            )

        assert len(report.remediations) == 2
        assert mock_client.messages.create.call_count == 2

    def test_remediate_top_n_limits_call2_input(
        self, config: AgentConfig, sample_context: DatabaseContext
    ) -> None:
        top1_remediation = "## FIND-001\n### Fix\n```sql\nCREATE INDEX CONCURRENTLY idx ON public.orders(user_id);\n```\n### Rollback\n```sql\nDROP INDEX CONCURRENTLY IF EXISTS public.idx;\n```"
        with patch("db_optimiser_agent.agent.anthropic.Anthropic") as mock_cls:
            mock_client = MagicMock()
            mock_cls.return_value = mock_client
            mock_client.messages.create.side_effect = [
                self._make_mock_message(SAMPLE_MARKDOWN),
                self._make_mock_message(top1_remediation),
            ]

            agent = DatabaseOptimizerAgent(config)
            report = agent.analyse(sample_context)
            report = agent.remediate(
                report, sample_context, scope=RemediationScope.TOP_N, n=1
            )

        # Call 2 user message should only reference FIND-001
        call2_user_msg = mock_client.messages.create.call_args_list[1].kwargs["messages"][0]["content"]
        assert "FIND-001" in call2_user_msg
        assert "FIND-002" not in call2_user_msg

    def test_ask_returns_string(
        self, config: AgentConfig
    ) -> None:
        with patch("db_optimiser_agent.agent.anthropic.Anthropic") as mock_cls:
            mock_client = MagicMock()
            mock_cls.return_value = mock_client
            mock_client.messages.create.return_value = self._make_mock_message(
                "Use CREATE INDEX CONCURRENTLY for zero-downtime indexing."
            )

            agent = DatabaseOptimizerAgent(config)
            answer = agent.ask("How do I add an index without downtime?")

        assert isinstance(answer, str)
        assert len(answer) > 0


# ---------------------------------------------------------------------------
# Gemini format compatibility tests
# ---------------------------------------------------------------------------

GEMINI_MARKDOWN = """
## Summary
The pagila database has critical performance issues from missing FK indexes
and unused index bloat.

## Findings

 \u2022 ID: FIND-001
 \u2022 Severity: CRITICAL
 \u2022 Category: MISSING_INDEX
 \u2022 Table / Query affected: rental, payment partitions
 \u2022 Root cause: Foreign key columns are not indexed, forcing sequential scans.
 \u2022 Impact: Full table scans on DELETE/UPDATE on parent tables.
 \u2022 Risk: SAFE

 \u2022 ID: FIND-002
 \u2022 Severity: MEDIUM
 \u2022 Category: UNUSED_INDEX
 \u2022 Table / Query affected: Multiple tables
 \u2022 Root cause: Indexes have zero scans since last stats reset.
 \u2022 Impact: Wasted disk space and write overhead.
 \u2022 Risk: REVIEW_FIRST

## Quick Wins
 \u2022 FIND-001

## Deferred Actions
 \u2022 FIND-002
"""


class TestGeminiFormatCompatibility:
    """Parser must handle Gemini bullet style (•) and non-bold field names."""

    def test_extracts_correct_count(self):
        findings = _parse_diagnostic_findings(GEMINI_MARKDOWN)
        assert len(findings) == 2

    def test_critical_severity_parsed(self):
        findings = _parse_diagnostic_findings(GEMINI_MARKDOWN)
        assert findings[0].severity == Severity.CRITICAL

    def test_medium_severity_parsed(self):
        findings = _parse_diagnostic_findings(GEMINI_MARKDOWN)
        assert findings[1].severity == Severity.MEDIUM

    def test_missing_index_category(self):
        findings = _parse_diagnostic_findings(GEMINI_MARKDOWN)
        assert findings[0].category == FindingCategory.MISSING_INDEX

    def test_unused_index_category(self):
        findings = _parse_diagnostic_findings(GEMINI_MARKDOWN)
        assert findings[1].category == FindingCategory.UNUSED_INDEX

    def test_affected_table_extracted(self):
        findings = _parse_diagnostic_findings(GEMINI_MARKDOWN)
        assert "rental" in findings[0].affected

    def test_safe_risk_parsed(self):
        findings = _parse_diagnostic_findings(GEMINI_MARKDOWN)
        assert findings[0].risk == RiskLevel.SAFE

    def test_review_first_risk_parsed(self):
        findings = _parse_diagnostic_findings(GEMINI_MARKDOWN)
        assert findings[1].risk == RiskLevel.REVIEW_FIRST

    def test_report_quick_wins(self):
        ctx = DatabaseContext(db_type="postgresql", db_name="pagila")
        report = _parse_analysis_report(GEMINI_MARKDOWN, "TEST001", ctx)
        assert "FIND-001" in report.quick_wins

    def test_report_deferred(self):
        ctx = DatabaseContext(db_type="postgresql", db_name="pagila")
        report = _parse_analysis_report(GEMINI_MARKDOWN, "TEST001", ctx)
        assert "FIND-002" in report.deferred

    def test_claude_format_still_works(self):
        """Ensure Claude format didn't break when fixing Gemini support."""
        findings = _parse_diagnostic_findings(SAMPLE_MARKDOWN)
        assert len(findings) == 2
        assert findings[0].severity == Severity.CRITICAL
