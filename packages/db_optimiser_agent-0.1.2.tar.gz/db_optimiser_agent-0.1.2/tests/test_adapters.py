"""
Tests for the PostgreSQL and MySQL adapters.

All database connections are mocked — no live database required.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch, call
import pytest

from db_optimiser_agent.adapters.base import BaseAdapter
from db_optimiser_agent.adapters.postgres import PostgreSQLAdapter
from db_optimiser_agent.adapters.mysql import MySQLAdapter
from db_optimiser_agent.adapters.factory import get_adapter
from db_optimiser_agent.config import AgentConfig, DatabaseType
from db_optimiser_agent.models import DatabaseContext


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

def _pg_config(**overrides) -> AgentConfig:
    defaults = dict(
        anthropic_api_key="sk-ant-test",
        db_type=DatabaseType.POSTGRES,
        db_host="localhost",
        db_port=5432,
        db_name="pagila",
        db_user="postgres",
        db_password="secret",
        db_schema="public",
        slow_query_threshold_ms=100.0,
    )
    defaults.update(overrides)
    return AgentConfig(**defaults)


def _my_config(**overrides) -> AgentConfig:
    defaults = dict(
        anthropic_api_key="sk-ant-test",
        db_type=DatabaseType.MYSQL,
        db_host="localhost",
        db_port=3306,
        db_name="mydb",
        db_user="root",
        db_password="secret",
        db_schema="mydb",
        slow_query_threshold_ms=100.0,
    )
    defaults.update(overrides)
    return AgentConfig(**defaults)


def _make_pg_adapter(config: AgentConfig | None = None) -> PostgreSQLAdapter:
    cfg = config or _pg_config()
    return PostgreSQLAdapter(
        host=cfg.db_host,
        port=cfg.db_port,
        dbname=cfg.db_name,
        user=cfg.db_user,
        password=cfg.db_password,
        schema=cfg.db_schema,
        slow_query_threshold_ms=cfg.slow_query_threshold_ms,
    )


def _make_my_adapter(config: AgentConfig | None = None) -> MySQLAdapter:
    cfg = config or _my_config()
    return MySQLAdapter(
        host=cfg.db_host,
        port=cfg.db_port,
        dbname=cfg.db_name,
        user=cfg.db_user,
        password=cfg.db_password,
        schema=cfg.db_schema,
        slow_query_threshold_ms=cfg.slow_query_threshold_ms,
    )


# ---------------------------------------------------------------------------
# Factory tests
# ---------------------------------------------------------------------------

class TestGetAdapter:
    def test_returns_postgres_adapter(self):
        adapter = get_adapter(_pg_config())
        assert isinstance(adapter, PostgreSQLAdapter)

    def test_returns_mysql_adapter(self):
        adapter = get_adapter(_my_config())
        assert isinstance(adapter, MySQLAdapter)

    def test_raises_on_unknown_type(self):
        config = _pg_config()
        object.__setattr__(config, "db_type", "oracle")
        with pytest.raises((ValueError, Exception)):
            get_adapter(config)


# ---------------------------------------------------------------------------
# Base adapter — collect() orchestration
# ---------------------------------------------------------------------------

class TestBaseAdapterCollect:
    """
    Tests the collect() orchestrator in BaseAdapter using PostgreSQLAdapter
    as a concrete implementation with all DB calls mocked.
    """

    def _patched_adapter(self) -> PostgreSQLAdapter:
        adapter = _make_pg_adapter()
        adapter._collect_tables = MagicMock(return_value=[
            {"name": "rental", "row_count": "16,044", "size": "5 MB",
             "size_bytes": 5_000_000, "seq_scans": 120, "idx_scans": 30, "index_hit_pct": 20.0}
        ])
        adapter._collect_indexes = MagicMock(return_value=[
            {"name": "idx_rental_customer_id", "table": "rental",
             "columns": "customer_id", "is_unique": False, "is_primary": False,
             "scans": 0, "size": "512 kB", "definition": "CREATE INDEX ..."}
        ])
        adapter._collect_slow_queries = MagicMock(return_value=[
            {"query": "SELECT * FROM rental WHERE customer_id = $1",
             "calls": 5000, "mean_ms": 3200.0, "total_ms": 16_000_000.0,
             "rows": 1, "stddev_ms": 200.0, "cache_hit_pct": 12.0, "source": "pg_stat_statements"}
        ])
        adapter._collect_missing_fk_indexes = MagicMock(return_value=[
            {"table": "rental", "column": "customer_id",
             "references": "customer(customer_id)", "constraint": "rental_customer_id_fkey"}
        ])
        adapter._collect_unused_indexes = MagicMock(return_value=[
            {"name": "idx_rental_id_duplicate", "table": "rental",
             "scans": 0, "size": "256 kB", "size_bytes": 262_144, "definition": "CREATE INDEX ..."}
        ])
        return adapter

    def test_returns_database_context(self):
        adapter = self._patched_adapter()
        ctx = adapter.collect()
        assert isinstance(ctx, DatabaseContext)

    def test_db_type_and_name(self):
        adapter = self._patched_adapter()
        ctx = adapter.collect()
        assert ctx.db_type == "postgresql"
        assert ctx.db_name == "pagila"

    def test_tables_populated(self):
        adapter = self._patched_adapter()
        ctx = adapter.collect()
        assert len(ctx.tables) == 1
        assert ctx.tables[0]["name"] == "rental"

    def test_slow_queries_populated(self):
        adapter = self._patched_adapter()
        ctx = adapter.collect()
        assert len(ctx.slow_queries) == 1
        assert ctx.slow_queries[0]["mean_ms"] == 3200.0

    def test_missing_fk_indexes_populated(self):
        adapter = self._patched_adapter()
        ctx = adapter.collect()
        assert len(ctx.missing_fk_indexes) == 1
        assert ctx.missing_fk_indexes[0]["column"] == "customer_id"

    def test_unused_indexes_populated(self):
        adapter = self._patched_adapter()
        ctx = adapter.collect()
        assert len(ctx.unused_indexes) == 1
        assert ctx.unused_indexes[0]["name"] == "idx_rental_id_duplicate"

    def test_extra_context_passed_through(self):
        adapter = self._patched_adapter()
        ctx = adapter.collect(extra_context="read-heavy OLAP workload")
        assert ctx.extra_context == "read-heavy OLAP workload"

    def test_collector_failure_returns_empty_not_crash(self):
        """If one collector fails, the others still run."""
        adapter = self._patched_adapter()
        adapter._collect_slow_queries = MagicMock(side_effect=Exception("pg_stat_statements missing"))
        ctx = adapter.collect()
        # slow_queries is empty but everything else still populated
        assert ctx.slow_queries == []
        assert len(ctx.tables) == 1

    def test_all_collectors_called(self):
        adapter = self._patched_adapter()
        adapter.collect()
        adapter._collect_tables.assert_called_once()
        adapter._collect_indexes.assert_called_once()
        adapter._collect_slow_queries.assert_called_once()
        adapter._collect_missing_fk_indexes.assert_called_once()
        adapter._collect_unused_indexes.assert_called_once()


# ---------------------------------------------------------------------------
# PostgreSQL adapter — connection and query behaviour
# ---------------------------------------------------------------------------

class TestPostgreSQLAdapter:
    def test_db_type(self):
        assert PostgreSQLAdapter.db_type == "postgresql"

    def test_connect_calls_psycopg2(self):
        adapter = _make_pg_adapter()
        mock_conn = MagicMock()
        with patch("db_optimiser_agent.adapters.postgres.psycopg2.connect",
                   return_value=mock_conn) as mock_connect:
            adapter.connect()
            mock_connect.assert_called_once()
            call_kwargs = mock_connect.call_args.kwargs
            assert call_kwargs["host"] == "localhost"
            assert call_kwargs["dbname"] == "pagila"
            assert call_kwargs["port"] == 5432

    def test_connect_sets_readonly(self):
        adapter = _make_pg_adapter()
        mock_conn = MagicMock()
        with patch("db_optimiser_agent.adapters.postgres.psycopg2.connect",
                   return_value=mock_conn):
            adapter.connect()
            mock_conn.set_session.assert_called_once_with(readonly=True, autocommit=True)

    def test_close_closes_connection(self):
        adapter = _make_pg_adapter()
        mock_conn = MagicMock()
        mock_conn.closed = False
        adapter._conn = mock_conn
        adapter.close()
        mock_conn.close.assert_called_once()

    def test_close_does_nothing_if_no_connection(self):
        adapter = _make_pg_adapter()
        adapter._conn = None
        adapter.close()  # should not raise

    def test_context_manager_connects_and_closes(self):
        adapter = _make_pg_adapter()
        mock_conn = MagicMock()
        mock_conn.closed = False
        with patch("db_optimiser_agent.adapters.postgres.psycopg2.connect",
                   return_value=mock_conn):
            with adapter:
                assert adapter._conn is mock_conn
            mock_conn.close.assert_called_once()

    def test_tables_row_count_formatted(self):
        adapter = _make_pg_adapter()
        adapter._query = MagicMock(return_value=[{
            "name": "payment",
            "row_count": 14596,
            "size": "3 MB",
            "size_bytes": 3_000_000,
            "seq_scan": 50,
            "idx_scan": 200,
            "index_hit_pct": 80.0,
        }])
        result = adapter._collect_tables()
        assert result[0]["row_count"] == "14,596"
        assert result[0]["index_hit_pct"] == 80.0

    def test_uses_pgss_when_available(self):
        adapter = _make_pg_adapter()
        adapter._has_pg_stat_statements = MagicMock(return_value=True)
        adapter._query = MagicMock(return_value=[])
        adapter._collect_slow_queries()
        # First call is the slow queries query (has_pgss already mocked)
        called_sql = adapter._query.call_args[0][0]
        assert "pg_stat_statements" in called_sql

    def test_falls_back_when_pgss_missing(self):
        adapter = _make_pg_adapter()
        adapter._has_pg_stat_statements = MagicMock(return_value=False)
        adapter._query = MagicMock(return_value=[])
        adapter._collect_slow_queries()
        called_sql = adapter._query.call_args[0][0]
        assert "seq_scan" in called_sql

    def test_slow_queries_capped_at_2000_chars(self):
        long_query = "SELECT " + "x, " * 1000 + "1 FROM t"
        adapter = _make_pg_adapter()
        adapter._has_pg_stat_statements = MagicMock(return_value=True)
        adapter._query = MagicMock(return_value=[{
            "query": long_query,
            "calls": 10,
            "mean_ms": 500,
            "total_ms": 5000,
            "rows": 1,
            "stddev_ms": 10,
            "cache_hit_pct": 90,
        }])
        result = adapter._collect_slow_queries()
        assert len(result[0]["query"]) <= 2000


# ---------------------------------------------------------------------------
# MySQL adapter — connection and query behaviour
# ---------------------------------------------------------------------------

class TestMySQLAdapter:
    def test_db_type(self):
        assert MySQLAdapter.db_type == "mysql"

    def test_connect_calls_connector(self):
        adapter = _make_my_adapter()
        mock_conn = MagicMock()
        with patch("db_optimiser_agent.adapters.mysql.mysql.connector.connect",
                   return_value=mock_conn) as mock_connect:
            adapter.connect()
            mock_connect.assert_called_once()
            call_kwargs = mock_connect.call_args.kwargs
            assert call_kwargs["host"] == "localhost"
            assert call_kwargs["database"] == "mydb"
            assert call_kwargs["port"] == 3306

    def test_close_disconnects(self):
        adapter = _make_my_adapter()
        mock_conn = MagicMock()
        mock_conn.is_connected.return_value = True
        adapter._conn = mock_conn
        adapter.close()
        mock_conn.close.assert_called_once()

    def test_close_skips_if_already_disconnected(self):
        adapter = _make_my_adapter()
        mock_conn = MagicMock()
        mock_conn.is_connected.return_value = False
        adapter._conn = mock_conn
        adapter.close()
        mock_conn.close.assert_not_called()

    def test_tables_formatted(self):
        adapter = _make_my_adapter()
        adapter._query = MagicMock(return_value=[{
            "name": "orders",
            "row_count": 250000,
            "size": "120.5 MB",
            "size_bytes": 126_353_408,
            "data_bytes": 100_000_000,
            "index_bytes": 26_353_408,
        }])
        result = adapter._collect_tables()
        assert result[0]["row_count"] == "250,000"
        assert result[0]["name"] == "orders"

    def test_slow_queries_returns_empty_on_error(self):
        adapter = _make_my_adapter()
        adapter._query = MagicMock(side_effect=Exception("performance_schema disabled"))
        result = adapter._collect_slow_queries()
        assert result == []

    def test_missing_fk_indexes(self):
        adapter = _make_my_adapter()
        adapter._query = MagicMock(return_value=[{
            "table": "orders",
            "column": "customer_id",
            "references": "customers(id)",
            "constraint_name": "fk_orders_customer",
        }])
        result = adapter._collect_missing_fk_indexes()
        assert len(result) == 1
        assert result[0]["table"] == "orders"
        assert result[0]["constraint"] == "fk_orders_customer"
