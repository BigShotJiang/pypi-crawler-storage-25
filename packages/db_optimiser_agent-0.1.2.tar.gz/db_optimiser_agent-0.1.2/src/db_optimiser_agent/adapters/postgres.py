"""
PostgreSQL database adapter.

Collects schema metadata, index usage, and slow queries using:
  - information_schema  — tables, columns, foreign keys
  - pg_stat_user_tables — live row counts and table sizes
  - pg_stat_user_indexes — index usage counters
  - pg_indexes           — index definitions
  - pg_stat_statements  — slow query log (requires the extension)
  - pg_constraint        — FK definitions for missing-index detection
"""

from __future__ import annotations

import json
import logging
from typing import Any

import psycopg2
import psycopg2.extras

from db_optimiser_agent.adapters.base import BaseAdapter

logger = logging.getLogger(__name__)

# pg_stat_statements may not be installed — we detect this at runtime
_PGSS_CHECK = """
SELECT COUNT(*) FROM pg_extension WHERE extname = 'pg_stat_statements';
"""

_TABLES_SQL = """
SELECT
    t.relname                                       AS name,
    t.n_live_tup                                    AS row_count,
    pg_size_pretty(pg_total_relation_size(c.oid))   AS size,
    pg_total_relation_size(c.oid)                   AS size_bytes,
    t.seq_scan,
    t.idx_scan,
    ROUND(
        CASE WHEN (t.seq_scan + t.idx_scan) > 0
             THEN t.idx_scan::numeric / (t.seq_scan + t.idx_scan) * 100
             ELSE 0
        END, 1
    )                                               AS index_hit_pct
FROM pg_stat_user_tables t
JOIN pg_class c ON c.relname = t.relname
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = %(schema)s
ORDER BY size_bytes DESC;
"""

_INDEXES_SQL = """
SELECT
    i.relname                                   AS name,
    t.relname                                   AS table,
    ix.indisunique                              AS is_unique,
    ix.indisprimary                             AS is_primary,
    pg_get_indexdef(ix.indexrelid)              AS definition,
    COALESCE(s.idx_scan, 0)                     AS scans,
    pg_size_pretty(pg_relation_size(i.oid))     AS size,
    pg_relation_size(i.oid)                     AS size_bytes,
    -- Human-readable column list
    (
        SELECT string_agg(a.attname, ', ' ORDER BY k.n)
        FROM unnest(ix.indkey) WITH ORDINALITY k(attnum, n)
        JOIN pg_attribute a
          ON a.attrelid = t.oid AND a.attnum = k.attnum
        WHERE k.attnum > 0
    )                                           AS columns
FROM pg_index ix
JOIN pg_class i ON i.oid = ix.indexrelid
JOIN pg_class t ON t.oid = ix.indrelid
JOIN pg_namespace n ON n.oid = t.relnamespace
LEFT JOIN pg_stat_user_indexes s
       ON s.indexrelid = ix.indexrelid
WHERE n.nspname = %(schema)s
  AND t.relkind = 'r'
ORDER BY t.relname, scans ASC;
"""

_SLOW_QUERIES_SQL = """
SELECT
    query,
    calls,
    ROUND((total_exec_time / calls)::numeric, 2)    AS mean_ms,
    ROUND(total_exec_time::numeric, 2)              AS total_ms,
    ROUND(mean_exec_time::numeric, 2)               AS mean_exec_ms,
    rows,
    ROUND(stddev_exec_time::numeric, 2)             AS stddev_ms,
    shared_blks_hit,
    shared_blks_read,
    CASE WHEN (shared_blks_hit + shared_blks_read) > 0
         THEN ROUND(
             shared_blks_hit::numeric /
             (shared_blks_hit + shared_blks_read) * 100, 1)
         ELSE NULL
    END                                             AS cache_hit_pct
FROM pg_stat_statements
WHERE calls > 5
  AND (total_exec_time / calls) > %(threshold_ms)s
  AND query NOT LIKE '%%pg_stat%%'
  AND query NOT LIKE '%%EXPLAIN%%'
ORDER BY total_exec_time DESC
LIMIT 20;
"""

_SLOW_QUERIES_FALLBACK_SQL = """
-- pg_stat_statements not available: fall back to finding tables
-- with high sequential scan counts as a proxy for slow queries
SELECT
    'SELECT * FROM ' || relname || ' -- (seq scan proxy, no pg_stat_statements)'
                                        AS query,
    seq_scan                            AS calls,
    0                                   AS mean_ms,
    0                                   AS total_ms,
    0                                   AS mean_exec_ms,
    n_live_tup                          AS rows,
    0                                   AS stddev_ms,
    0                                   AS shared_blks_hit,
    0                                   AS shared_blks_read,
    NULL                                AS cache_hit_pct
FROM pg_stat_user_tables
WHERE seq_scan > 50
ORDER BY seq_scan DESC
LIMIT 10;
"""

_MISSING_FK_INDEXES_SQL = """
-- Foreign key columns that have no index on the referencing side
SELECT
    kcu.table_name                              AS "table",
    kcu.column_name                             AS "column",
    ccu.table_name || '(' || ccu.column_name || ')'
                                                AS references,
    tc.constraint_name
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
  ON kcu.constraint_name = tc.constraint_name
 AND kcu.table_schema    = tc.table_schema
JOIN information_schema.referential_constraints rc
  ON rc.constraint_name  = tc.constraint_name
 AND rc.constraint_schema = tc.table_schema
JOIN information_schema.constraint_column_usage ccu
  ON ccu.constraint_name = rc.unique_constraint_name
 AND ccu.table_schema    = rc.unique_constraint_schema
WHERE tc.constraint_type = 'FOREIGN KEY'
  AND tc.table_schema    = %(schema)s
  -- No index exists that starts with this column on the referencing table
  AND NOT EXISTS (
      SELECT 1
      FROM pg_index px
      JOIN pg_class pc ON pc.oid = px.indrelid
      JOIN pg_attribute pa
        ON pa.attrelid = pc.oid
       AND pa.attnum   = px.indkey[0]   -- first column of index
      JOIN pg_namespace pn ON pn.oid = pc.relnamespace
      WHERE pn.nspname  = %(schema)s
        AND pc.relname  = kcu.table_name
        AND pa.attname  = kcu.column_name
  )
ORDER BY kcu.table_name, kcu.column_name;
"""

_UNUSED_INDEXES_SQL = """
SELECT
    i.relname                                       AS name,
    t.relname                                       AS "table",
    COALESCE(s.idx_scan, 0)                         AS scans,
    pg_size_pretty(pg_relation_size(i.oid))         AS size,
    pg_relation_size(i.oid)                         AS size_bytes,
    ix.indisunique                                  AS is_unique,
    pg_get_indexdef(ix.indexrelid)                  AS definition
FROM pg_index ix
JOIN pg_class i ON i.oid = ix.indexrelid
JOIN pg_class t ON t.oid = ix.indrelid
JOIN pg_namespace n ON n.oid = t.relnamespace
LEFT JOIN pg_stat_user_indexes s ON s.indexrelid = ix.indexrelid
WHERE n.nspname       = %(schema)s
  AND t.relkind       = 'r'
  AND ix.indisprimary = false
  AND ix.indisunique  = false
  AND COALESCE(s.idx_scan, 0) < 10          -- fewer than 10 uses ever recorded
  AND pg_relation_size(i.oid) > 8192        -- larger than one page (not trivial)
ORDER BY size_bytes DESC;
"""

_VIEWS_SQL = """
SELECT
    v.table_name                AS name,
    v.view_definition           AS definition,
    obj_description(
        (%(schema)s || '.' || quote_ident(v.table_name))::regclass, 'pg_class'
    )                           AS comment
FROM information_schema.views v
WHERE v.table_schema = %(schema)s
ORDER BY v.table_name;
"""

_FUNCTIONS_SQL = """
SELECT
    p.proname                               AS name,
    pg_get_function_arguments(p.oid)        AS arguments,
    pg_get_functiondef(p.oid)               AS definition,
    l.lanname                               AS language,
    obj_description(p.oid, 'pg_proc')       AS comment
FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
JOIN pg_language l ON l.oid = p.prolang
WHERE n.nspname = %(schema)s
  AND p.prokind = 'f'                       -- functions only (not procedures/aggregates)
ORDER BY p.proname;
"""

_COLUMN_STATS_SQL = """
SELECT
    c.table_name,
    c.column_name,
    c.data_type,
    c.character_maximum_length,
    c.is_nullable,
    c.column_default,
    -- Flag oversized varchars (>100 chars on non-text columns)
    CASE WHEN c.data_type = 'character varying'
              AND c.character_maximum_length > 100
         THEN true ELSE false END           AS oversized_varchar,
    -- Flag missing defaults on timestamp columns
    CASE WHEN c.data_type IN ('timestamp without time zone',
                              'timestamp with time zone')
              AND c.column_default IS NULL
         THEN true ELSE false END           AS timestamp_no_default,
    -- Detect columns that look like enums stored as varchar
    CASE WHEN c.data_type = 'character varying'
              AND c.character_maximum_length <= 50
              AND c.column_name IN (
                  'status','state','type','priority','role',
                  'category','mode','level','kind'
              )
         THEN true ELSE false END           AS likely_enum_as_varchar
FROM information_schema.columns c
WHERE c.table_schema = %(schema)s
  AND c.table_name NOT IN (
      SELECT table_name FROM information_schema.views
      WHERE table_schema = %(schema)s
  )
ORDER BY c.table_name, c.ordinal_position;
"""

_SERVER_CONFIG_SQL = """
SELECT
    name,
    setting,
    unit,
    short_desc,
    source          -- 'default', 'configuration file', 'session', etc.
FROM pg_settings
WHERE name IN (
    'work_mem',
    'shared_buffers',
    'effective_cache_size',
    'maintenance_work_mem',
    'max_parallel_workers_per_gather',
    'max_parallel_workers',
    'enable_indexscan',
    'enable_bitmapscan',
    'enable_seqscan',
    'enable_hashjoin',
    'enable_nestloop',
    'random_page_cost',
    'seq_page_cost',
    'default_statistics_target',
    'checkpoint_completion_target',
    'wal_buffers',
    'autovacuum',
    'autovacuum_vacuum_scale_factor',
    'autovacuum_analyze_scale_factor'
)
ORDER BY name;
"""


# How many of the top slow queries to run EXPLAIN on.
# EXPLAIN without ANALYZE is read-only and completes in < 2 ms per query.
_EXPLAIN_LIMIT = 5

# Statements that cannot be EXPLAINed (DDL, utility, PL/pgSQL internals)
_EXPLAINABLE_PREFIXES = ("SELECT", "INSERT", "UPDATE", "DELETE", "WITH")


def _walk_pg_plan(node: dict[str, Any], acc: dict[str, Any]) -> None:
    """
    Recursively collect key signals from a PostgreSQL JSON plan node.

    Populates ``acc`` with:
      seq_scan_tables   — list of "table (~N rows)" strings for full-table scans
      index_names_used  — list of "index_name on table" strings for index accesses
      nested_loop_count — number of Nested Loop join nodes (N+1 indicator)
    """
    node_type = node.get("Node Type", "")
    plan_rows = int(node.get("Plan Rows", 0))

    if node_type == "Seq Scan":
        table = node.get("Relation Name", "?")
        acc["seq_scan_tables"].append(f"{table} (~{plan_rows:,} rows)")

    if "Index" in node_type:  # Index Scan, Index Only Scan, Bitmap Index Scan
        idx   = node.get("Index Name", "")
        table = node.get("Relation Name", "?")
        if idx:
            acc["index_names_used"].append(f"{idx} on {table}")

    if node_type == "Nested Loop":
        acc["nested_loop_count"] += 1

    for child in node.get("Plans", []):
        _walk_pg_plan(child, acc)


class PostgreSQLAdapter(BaseAdapter):
    """Adapter for PostgreSQL databases."""

    db_type = "postgresql"

    def connect(self) -> None:
        logger.debug("Connecting to PostgreSQL %s:%s/%s", self.host, self.port, self.dbname)
        self._conn = psycopg2.connect(
            host=self.host,
            port=self.port,
            dbname=self.dbname,
            user=self.user,
            password=self.password,
            connect_timeout=10,
            options="-c statement_timeout=30000",  # 30s safety timeout
        )
        self._conn.set_session(readonly=True, autocommit=True)
        logger.info("PostgreSQL connection established")

    def close(self) -> None:
        if self._conn and not self._conn.closed:
            self._conn.close()
            logger.debug("PostgreSQL connection closed")

    def _query(self, sql: str, params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Execute a read-only query and return rows as dicts."""
        with self._conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(sql, params or {})
            return [dict(row) for row in cur.fetchall()]

    def _has_pg_stat_statements(self) -> bool:
        rows = self._query(_PGSS_CHECK)
        return rows[0]["count"] > 0 if rows else False

    def _explain_query(self, sql: str) -> dict[str, Any] | None:
        """
        Run ``EXPLAIN (FORMAT JSON, COSTS true, ANALYZE false)`` on *sql* and
        return a compact plan-summary dict.

        Returns ``None`` when EXPLAIN cannot be run (DDL, utility statements,
        or any planner error).  Failures are logged at DEBUG level only —
        they are expected for parameterised queries whose placeholder syntax
        the planner rejects.
        """
        stripped = sql.strip()
        if not any(stripped.upper().startswith(kw) for kw in _EXPLAINABLE_PREFIXES):
            return None

        # pg_stat_statements can store multiple statements separated by ';'
        # Take only the first to avoid a syntax error.
        first_stmt = stripped.split(";")[0].strip()
        if not first_stmt:
            return None

        try:
            with self._conn.cursor() as cur:
                # psycopg2 treats bare % in the SQL string as Python format
                # placeholders. Queries from pg_stat_statements often contain
                # %s or %(name)s (ORM-generated) — doubling them prevents
                # psycopg2 from attempting substitution on an unparameterised call.
                escaped = first_stmt.replace("%", "%%")
                cur.execute(
                    f"EXPLAIN (FORMAT JSON, COSTS true, ANALYZE false, VERBOSE false) {escaped}"
                )
                row = cur.fetchone()
            if not row:
                return None

            plan_data = row[0]
            if isinstance(plan_data, str):
                plan_data = json.loads(plan_data)
            if not isinstance(plan_data, list) or not plan_data:
                return None

            top = plan_data[0].get("Plan", {})
            acc: dict[str, Any] = {
                "seq_scan_tables": [],
                "index_names_used": [],
                "nested_loop_count": 0,
            }
            _walk_pg_plan(top, acc)

            return {
                "top_node":          top.get("Node Type", "Unknown"),
                "total_cost":        round(float(top.get("Total Cost", 0)), 2),
                "plan_rows":         int(top.get("Plan Rows", 0)),
                "seq_scan_tables":   acc["seq_scan_tables"],
                "index_names_used":  acc["index_names_used"],
                "nested_loop_count": acc["nested_loop_count"],
                "source":            "explain",
            }

        except Exception as exc:
            logger.debug("EXPLAIN skipped (%.80s…): %s", first_stmt, exc)
            return None

    # ------------------------------------------------------------------
    # Collection methods
    # ------------------------------------------------------------------

    def _collect_tables(self) -> list[dict[str, Any]]:
        rows = self._query(_TABLES_SQL, {"schema": self.schema})
        result = []
        for r in rows:
            result.append({
                "name": r["name"],
                "row_count": f"{int(r['row_count']):,}",
                "size": r["size"],
                "size_bytes": int(r["size_bytes"]),
                "seq_scans": int(r["seq_scan"]),
                "idx_scans": int(r["idx_scan"]),
                "index_hit_pct": float(r["index_hit_pct"] or 0),
            })
        return result

    def _collect_indexes(self) -> list[dict[str, Any]]:
        rows = self._query(_INDEXES_SQL, {"schema": self.schema})
        result = []
        for r in rows:
            result.append({
                "name": r["name"],
                "table": r["table"],
                "columns": r["columns"] or "(expression)",
                "is_unique": bool(r["is_unique"]),
                "is_primary": bool(r["is_primary"]),
                "scans": int(r["scans"]),
                "size": r["size"],
                "definition": r["definition"],
            })
        return result

    def _collect_slow_queries(self) -> list[dict[str, Any]]:
        has_pgss = self._has_pg_stat_statements()
        if has_pgss:
            logger.debug("pg_stat_statements available — using real slow query data")
            rows = self._query(
                _SLOW_QUERIES_SQL,
                {"threshold_ms": self.slow_query_threshold_ms},
            )
        else:
            logger.warning(
                "pg_stat_statements not installed — using sequential scan proxy. "
                "Install with: CREATE EXTENSION pg_stat_statements;"
            )
            rows = self._query(_SLOW_QUERIES_FALLBACK_SQL)

        result = []
        for r in rows:
            result.append({
                "query": (r["query"] or "").strip()[:2000],  # cap length
                "calls": int(r["calls"] or 0),
                "mean_ms": float(r["mean_ms"] or 0),
                "total_ms": float(r["total_ms"] or 0),
                "rows": int(r["rows"] or 0),
                "stddev_ms": float(r["stddev_ms"] or 0),
                "cache_hit_pct": (
                    float(r["cache_hit_pct"]) if r.get("cache_hit_pct") is not None else None
                ),
                "source": "pg_stat_statements" if has_pgss else "seq_scan_proxy",
                "explain_plan": None,  # populated below for top _EXPLAIN_LIMIT queries
            })

        # EXPLAIN the top N queries (already sorted by total_ms DESC).
        # EXPLAIN without ANALYZE is read-only and completes in < 2 ms each.
        for entry in result[:_EXPLAIN_LIMIT]:
            plan = self._explain_query(entry["query"])
            if plan:
                entry["explain_plan"] = plan
                logger.debug(
                    "EXPLAIN: %.60s… → %s (cost=%.0f seq_scans=%s)",
                    entry["query"], plan["top_node"], plan["total_cost"],
                    plan["seq_scan_tables"],
                )

        return result

    def _collect_missing_fk_indexes(self) -> list[dict[str, Any]]:
        rows = self._query(_MISSING_FK_INDEXES_SQL, {"schema": self.schema})
        return [
            {
                "table": r["table"],
                "column": r["column"],
                "references": r["references"],
                "constraint": r["constraint_name"],
            }
            for r in rows
        ]

    def _collect_unused_indexes(self) -> list[dict[str, Any]]:
        rows = self._query(_UNUSED_INDEXES_SQL, {"schema": self.schema})
        return [
            {
                "name": r["name"],
                "table": r["table"],
                "scans": int(r["scans"]),
                "size": r["size"],
                "size_bytes": int(r["size_bytes"]),
                "definition": r["definition"],
            }
            for r in rows
        ]

    def _collect_views(self) -> list[dict[str, Any]]:
        rows = self._query(_VIEWS_SQL, {"schema": self.schema})
        return [
            {
                "name": r["name"],
                "definition": (r["definition"] or "").strip(),
                "comment": r["comment"] or "",
            }
            for r in rows
        ]

    def _collect_functions(self) -> list[dict[str, Any]]:
        rows = self._query(_FUNCTIONS_SQL, {"schema": self.schema})
        return [
            {
                "name": r["name"],
                "arguments": r["arguments"] or "",
                "language": r["language"] or "",
                "definition": (r["definition"] or "").strip(),
                "comment": r["comment"] or "",
            }
            for r in rows
        ]

    def _collect_column_stats(self) -> list[dict[str, Any]]:
        rows = self._query(_COLUMN_STATS_SQL, {"schema": self.schema})
        return [
            {
                "table": r["table_name"],
                "column": r["column_name"],
                "data_type": r["data_type"],
                "max_length": r["character_maximum_length"],
                "nullable": r["is_nullable"] == "YES",
                "default": r["column_default"],
                "oversized_varchar": bool(r["oversized_varchar"]),
                "timestamp_no_default": bool(r["timestamp_no_default"]),
                "likely_enum_as_varchar": bool(r["likely_enum_as_varchar"]),
            }
            for r in rows
        ]

    def _collect_server_config(self) -> list[dict[str, Any]]:
        rows = self._query(_SERVER_CONFIG_SQL)
        return [
            {
                "name": r["name"],
                "setting": r["setting"],
                "unit": r["unit"] or "",
                "description": r["short_desc"] or "",
                "source": r["source"],
            }
            for r in rows
        ]
