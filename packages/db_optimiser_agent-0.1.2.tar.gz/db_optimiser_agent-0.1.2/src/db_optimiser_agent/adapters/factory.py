"""
Adapter factory.

Returns the correct BaseAdapter subclass based on the configured DB type.
"""

from __future__ import annotations

from db_optimiser_agent.adapters.base import BaseAdapter
from db_optimiser_agent.adapters.mysql import MySQLAdapter
from db_optimiser_agent.adapters.postgres import PostgreSQLAdapter
from db_optimiser_agent.config import AgentConfig, DatabaseType


def get_adapter(config: AgentConfig) -> BaseAdapter:
    """
    Instantiate and return the correct adapter for the configured database.

    Usage:
        with get_adapter(config) as adapter:
            context = adapter.collect()
    """
    kwargs = dict(
        host=config.db_host,
        port=config.db_port,
        dbname=config.db_name,
        user=config.db_user,
        password=config.db_password,
        schema=config.db_schema,
        slow_query_threshold_ms=config.slow_query_threshold_ms,
    )

    if config.db_type == DatabaseType.POSTGRES:
        return PostgreSQLAdapter(**kwargs)

    if config.db_type == DatabaseType.MYSQL:
        return MySQLAdapter(**kwargs)

    raise ValueError(f"Unsupported db_type: {config.db_type!r}")
