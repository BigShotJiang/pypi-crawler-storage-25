"""
MySQL / MariaDB database adapter.

Collects schema metadata, index usage, and slow queries using:
  - information_schema.TABLES          — table sizes and row estimates
  - information_schema.STATISTICS      — index column definitions
  - information_schema.KEY_COLUMN_USAGE / REFERENTIAL_CONSTRAINTS — FKs
  - performance_schema.table_io_waits_summary_by_index_usage — index usage
  - performance_schema.events_statements_summary_by_digest   — slow queries
"""

from __future__ import annotations

import json
import logging
from typing import Any

import mysql.connector
import mysql.connector.cursor

from db_optimiser_agent.adapters.base import BaseAdapter

logger = logging.getLogger(__name__)

_TABLES_SQL = """
SELECT
    TABLE_NAME                                  AS name,
    COALESCE(TABLE_ROWS, 0)                     AS row_count,
    CONCAT(
        ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 1), ' MB'
    )                                           AS size,
    (DATA_LENGTH + INDEX_LENGTH)                AS size_bytes,
    DATA_LENGTH                                 AS data_bytes,
    INDEX_LENGTH                                AS index_bytes
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = %(schema)s
  AND TABLE_TYPE   = 'BASE TABLE'
ORDER BY size_bytes DESC;
"""

_INDEXES_SQL = """
SELECT
    s.INDEX_NAME                                AS name,
    s.TABLE_NAME                                AS `table`,
    GROUP_CONCAT(s.COLUMN_NAME ORDER BY s.SEQ_IN_INDEX)
                                                AS columns,
    s.NON_UNIQUE = 0                            AS is_unique,
    s.INDEX_NAME = 'PRIMARY'                    AS is_primary,
    COALESCE(u.count_read, 0)                   AS scans,
    NULL                                        AS size
FROM information_schema.STATISTICS s
LEFT JOIN performance_schema.table_io_waits_summary_by_index_usage u
       ON u.OBJECT_SCHEMA = s.TABLE_SCHEMA
      AND u.OBJECT_NAME   = s.TABLE_NAME
      AND u.INDEX_NAME     = s.INDEX_NAME
WHERE s.TABLE_SCHEMA = %(schema)s
GROUP BY s.INDEX_NAME, s.TABLE_NAME, s.NON_UNIQUE, u.count_read
ORDER BY s.TABLE_NAME, scans ASC;
"""

_SLOW_QUERIES_SQL = """
SELECT
    DIGEST_TEXT                                 AS query,
    COUNT_STAR                                  AS calls,
    ROUND(AVG_TIMER_WAIT / 1000000, 2)          AS mean_ms,
    ROUND(SUM_TIMER_WAIT / 1000000, 2)          AS total_ms,
    SUM_ROWS_EXAMINED                           AS rows_examined,
    SUM_ROWS_SENT                               AS rows_sent,
    ROUND(SUM_NO_INDEX_USED * 100.0 / COUNT_STAR, 1)
                                                AS pct_no_index
FROM performance_schema.events_statements_summary_by_digest
WHERE SCHEMA_NAME     = %(schema)s
  AND COUNT_STAR      > 5
  AND AVG_TIMER_WAIT / 1000000 > %(threshold_ms)s
  AND DIGEST_TEXT IS NOT NULL
ORDER BY SUM_TIMER_WAIT DESC
LIMIT 20;
"""

_MISSING_FK_INDEXES_SQL = """
SELECT
    kcu.TABLE_NAME                              AS `table`,
    kcu.COLUMN_NAME                             AS `column`,
    CONCAT(kcu.REFERENCED_TABLE_NAME, '(',
           kcu.REFERENCED_COLUMN_NAME, ')')     AS `references`,
    kcu.CONSTRAINT_NAME                         AS constraint_name
FROM information_schema.KEY_COLUMN_USAGE kcu
JOIN information_schema.REFERENTIAL_CONSTRAINTS rc
  ON rc.CONSTRAINT_NAME   = kcu.CONSTRAINT_NAME
 AND rc.CONSTRAINT_SCHEMA = kcu.CONSTRAINT_SCHEMA
WHERE kcu.TABLE_SCHEMA              = %(schema)s
  AND kcu.REFERENCED_TABLE_NAME IS NOT NULL
  -- No index that starts with this FK column
  AND NOT EXISTS (
      SELECT 1
      FROM information_schema.STATISTICS s
      WHERE s.TABLE_SCHEMA = kcu.TABLE_SCHEMA
        AND s.TABLE_NAME   = kcu.TABLE_NAME
        AND s.COLUMN_NAME  = kcu.COLUMN_NAME
        AND s.SEQ_IN_INDEX = 1
  )
ORDER BY kcu.TABLE_NAME, kcu.COLUMN_NAME;
"""

_UNUSED_INDEXES_SQL = """
SELECT
    s.INDEX_NAME                                AS name,
    s.TABLE_NAME                                AS `table`,
    COALESCE(u.count_read, 0)                   AS scans,
    NULL                                        AS size,
    NULL                                        AS size_bytes
FROM information_schema.STATISTICS s
LEFT JOIN performance_schema.table_io_waits_summary_by_index_usage u
       ON u.OBJECT_SCHEMA = s.TABLE_SCHEMA
      AND u.OBJECT_NAME   = s.TABLE_NAME
      AND u.INDEX_NAME     = s.INDEX_NAME
WHERE s.TABLE_SCHEMA     = %(schema)s
  AND s.INDEX_NAME      != 'PRIMARY'
  AND s.SEQ_IN_INDEX     = 1           -- one row per index (leading column)
  AND COALESCE(u.count_read, 0) < 10
GROUP BY s.INDEX_NAME, s.TABLE_NAME, u.count_read
ORDER BY scans ASC;
"""


# How many of the top slow queries to EXPLAIN.
_EXPLAIN_LIMIT = 5

_EXPLAINABLE_PREFIXES = ("SELECT", "INSERT", "UPDATE", "DELETE", "WITH")


def _walk_mysql_plan(node: dict[str, Any], acc: dict[str, Any]) -> None:
    """
    Recursively walk a MySQL EXPLAIN FORMAT=JSON plan object.

    Populates ``acc`` with:
      seq_scan_tables   — tables accessed with access_type = "ALL" (full scan)
      index_names_used  — index key names where an index is used
      nested_loop_count — number of nested_loop constructs (N+1 indicator)
    """
    # Table-level access info
    if "table" in node:
        t = node["table"]
        name   = t.get("table_name", "?")
        access = t.get("access_type", "")
        rows   = int(t.get("rows_examined_per_scan") or t.get("rows_produced_per_join") or 0)

        if access == "ALL":
            acc["seq_scan_tables"].append(f"{name} (~{rows:,} rows)")
        else:
            key = t.get("key") or t.get("ref")
            if key:
                acc["index_names_used"].append(f"{key} on {name}")

    # Nested loop joins
    if "nested_loop" in node:
        acc["nested_loop_count"] += 1
        for item in node["nested_loop"]:
            _walk_mysql_plan(item, acc)

    # Recurse into known wrapper keys
    for key in ("query_block", "ordering_operation", "grouping_operation",
                "duplicates_removal", "union_result"):
        if key in node:
            _walk_mysql_plan(node[key], acc)


class MySQLAdapter(BaseAdapter):
    """Adapter for MySQL / MariaDB databases."""

    db_type = "mysql"

    def connect(self) -> None:
        logger.debug("Connecting to MySQL %s:%s/%s", self.host, self.port, self.dbname)
        self._conn = mysql.connector.connect(
            host=self.host,
            port=self.port,
            database=self.dbname,
            user=self.user,
            password=self.password,
            connection_timeout=10,
            # enforce read-only at the session level
            init_command="SET SESSION TRANSACTION READ ONLY",
        )
        # Apply a 30 s per-statement execution limit (MySQL 5.7.4+).
        # Silently skipped on MariaDB and older MySQL — not a hard requirement,
        # but prevents a runaway EXPLAIN or slow-query scan from hanging forever.
        try:
            cur = self._conn.cursor()
            cur.execute("SET SESSION MAX_EXECUTION_TIME = 30000")
            cur.close()
            logger.debug("MySQL MAX_EXECUTION_TIME set to 30000 ms")
        except Exception as exc:
            logger.debug("MAX_EXECUTION_TIME not supported on this server, skipping: %s", exc)
        logger.info("MySQL connection established")

    def close(self) -> None:
        if self._conn and self._conn.is_connected():
            self._conn.close()
            logger.debug("MySQL connection closed")

    def _explain_query(self, sql: str) -> dict[str, Any] | None:
        """
        Attempt ``EXPLAIN FORMAT=JSON`` on *sql* and return a compact plan summary.

        MySQL DIGEST_TEXT uses ``?`` placeholders which cannot be EXPLAINed
        directly.  When the attempt fails (as it usually will for parameterised
        queries) this method returns ``None`` so the caller can fall back to a
        heuristic built from ``pct_no_index`` and row-ratio metrics.
        """
        stripped = sql.strip()
        if not any(stripped.upper().startswith(kw) for kw in _EXPLAINABLE_PREFIXES):
            return None

        # Take only the first statement
        first_stmt = stripped.split(";")[0].strip()
        if not first_stmt:
            return None

        try:
            cursor = self._conn.cursor(dictionary=True)
            try:
                cursor.execute(f"EXPLAIN FORMAT=JSON {first_stmt}")
                row = cursor.fetchone()
            finally:
                cursor.close()

            if not row:
                return None

            raw = row.get("EXPLAIN") or row.get("explain") or ""
            plan = json.loads(raw) if isinstance(raw, str) else raw
            if not isinstance(plan, dict):
                return None

            acc: dict[str, Any] = {
                "seq_scan_tables": [],
                "index_names_used": [],
                "nested_loop_count": 0,
            }
            _walk_mysql_plan(plan, acc)

            query_cost = (
                plan.get("query_block", {})
                    .get("cost_info", {})
                    .get("query_cost")
            )

            return {
                "top_node":          "full scan" if acc["seq_scan_tables"] else "index access",
                "total_cost":        float(query_cost) if query_cost else None,
                "plan_rows":         None,
                "seq_scan_tables":   acc["seq_scan_tables"],
                "index_names_used":  acc["index_names_used"],
                "nested_loop_count": acc["nested_loop_count"],
                "source":            "explain",
            }

        except Exception as exc:
            logger.debug("MySQL EXPLAIN skipped (%.80s…): %s", first_stmt, exc)
            return None

    def _query(self, sql: str, params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Execute a read-only query and return rows as dicts."""
        cursor = self._conn.cursor(dictionary=True)
        try:
            # mysql-connector uses %(name)s placeholders natively
            cursor.execute(sql, params or {})
            return cursor.fetchall() or []
        finally:
            cursor.close()

    # ------------------------------------------------------------------
    # Collection methods
    # ------------------------------------------------------------------

    def _collect_tables(self) -> list[dict[str, Any]]:
        rows = self._query(_TABLES_SQL, {"schema": self.dbname})
        result = []
        for r in rows:
            result.append({
                "name": r["name"],
                "row_count": f"{int(r['row_count'] or 0):,}",
                "size": r["size"],
                "size_bytes": int(r["size_bytes"] or 0),
                "data_bytes": int(r["data_bytes"] or 0),
                "index_bytes": int(r["index_bytes"] or 0),
            })
        return result

    def _collect_indexes(self) -> list[dict[str, Any]]:
        rows = self._query(_INDEXES_SQL, {"schema": self.dbname})
        result = []
        for r in rows:
            result.append({
                "name": r["name"],
                "table": r["table"],
                "columns": r["columns"] or "",
                "is_unique": bool(r["is_unique"]),
                "is_primary": bool(r["is_primary"]),
                "scans": int(r["scans"] or 0),
                "size": r["size"],
                "definition": None,  # MySQL doesn't expose CREATE INDEX text easily
            })
        return result

    def _collect_slow_queries(self) -> list[dict[str, Any]]:
        try:
            rows = self._query(
                _SLOW_QUERIES_SQL,
                {
                    "schema": self.dbname,
                    "threshold_ms": self.slow_query_threshold_ms,
                },
            )
        except Exception as exc:
            logger.warning(
                "performance_schema slow query collection failed: %s. "
                "Ensure performance_schema is enabled.",
                exc,
            )
            return []

        result = [
            {
                "query": (r.get("query") or "").strip()[:2000],
                "calls": int(r.get("calls") or 0),
                "mean_ms": float(r.get("mean_ms") or 0),
                "total_ms": float(r.get("total_ms") or 0),
                "rows_examined": int(r.get("rows_examined") or 0),
                "rows_sent": int(r.get("rows_sent") or 0),
                "pct_no_index": float(r.get("pct_no_index") or 0),
                "source": "performance_schema",
                "explain_plan": None,  # populated below
            }
            for r in rows
        ]

        # Try EXPLAIN on the top N queries (sorted by SUM_TIMER_WAIT DESC).
        # DIGEST_TEXT uses '?' placeholders so EXPLAIN will usually fail —
        # in that case we build a heuristic plan from row-ratio metrics.
        for entry in result[:_EXPLAIN_LIMIT]:
            plan = self._explain_query(entry["query"])

            if plan is None:
                # Heuristic: derive access pattern from performance_schema counters
                rows_examined = entry["rows_examined"]
                rows_sent     = max(entry["rows_sent"], 1)
                ratio         = round(rows_examined / rows_sent, 1)
                pct_no_index  = entry["pct_no_index"]

                plan = {
                    "top_node":          "full table scan" if pct_no_index > 50 else "index access",
                    "total_cost":        None,
                    "plan_rows":         rows_examined,
                    "seq_scan_tables":   [],
                    "index_names_used":  [],
                    "nested_loop_count": 0,
                    "rows_per_sent":     ratio,
                    "pct_no_index":      pct_no_index,
                    "source":            "heuristic",
                }

            entry["explain_plan"] = plan
            logger.debug(
                "Plan (%s): %.60s… → %s (no_idx=%.0f%% ratio=%s)",
                plan["source"], entry["query"], plan["top_node"],
                plan.get("pct_no_index", 0), plan.get("rows_per_sent", "n/a"),
            )

        return result

    def _collect_missing_fk_indexes(self) -> list[dict[str, Any]]:
        rows = self._query(_MISSING_FK_INDEXES_SQL, {"schema": self.dbname})
        return [
            {
                "table": r["table"],
                "column": r["column"],
                "references": r["references"],
                "constraint": r["constraint_name"],
            }
            for r in rows
        ]

    def _collect_unused_indexes(self) -> list[dict[str, Any]]:
        rows = self._query(_UNUSED_INDEXES_SQL, {"schema": self.dbname})
        return [
            {
                "name": r["name"],
                "table": r["table"],
                "scans": int(r["scans"] or 0),
                "size": r["size"],
                "size_bytes": r["size_bytes"],
            }
            for r in rows
        ]
