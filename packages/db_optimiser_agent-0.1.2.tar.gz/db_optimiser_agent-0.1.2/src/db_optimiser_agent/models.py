"""
Typed models for agent findings and analysis reports.

These are the data structures that flow between the database adapters,
the Claude API wrapper, and the output formatters.

Two-phase design:
  Call 1 (analyse)   → AnalysisReport with findings: list[DiagnosticFinding]
  Call 2 (remediate) → AnalysisReport with remediations: list[RemediatedFinding]
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


# Severity ordering for TOP_N sorting (lower index = higher priority)
_SEVERITY_ORDER = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]


class FindingCategory(str, Enum):
    MISSING_INDEX = "MISSING_INDEX"
    SLOW_QUERY = "SLOW_QUERY"
    N_PLUS_ONE = "N_PLUS_ONE"
    SCHEMA = "SCHEMA"
    CONFIG = "CONFIG"
    UNUSED_INDEX = "UNUSED_INDEX"


class RiskLevel(str, Enum):
    SAFE = "SAFE"
    REQUIRES_MAINTENANCE_WINDOW = "REQUIRES_MAINTENANCE_WINDOW"
    REVIEW_FIRST = "REVIEW_FIRST"


class RemediationScope(str, Enum):
    """Controls how many findings are sent to the remediation call."""
    TOP_N = "top_n"   # top N by severity (default n=5)
    FULL  = "full"    # all findings
    IDS   = "ids"     # explicit list of finding IDs


class DiagnosticFinding(BaseModel):
    """
    A finding produced by Call 1 (analysis only).
    Contains diagnosis — no SQL yet.
    """
    id: str = Field(description="e.g. FIND-001")
    severity: Severity
    category: FindingCategory
    affected: str = Field(description="Table name, query pattern, or config key")
    root_cause: str
    impact: str
    risk: RiskLevel = Field(default=RiskLevel.SAFE)


class RemediatedFinding(BaseModel):
    """
    A finding enriched by Call 2 (remediation).
    Combines the original diagnosis with generated SQL.

    fix_sql is populated when the fix is executable SQL.
    fix_notes is populated instead when the fix requires a code/logic change
    (e.g. rewriting a view) that cannot be expressed as a single SQL statement.
    Exactly one of fix_sql or fix_notes will be non-empty.
    """
    id: str
    severity: Severity
    category: FindingCategory
    affected: str
    root_cause: str
    impact: str
    risk: RiskLevel
    fix_sql: str = Field(default="", description="Copy-paste SQL ready to run in production")
    fix_notes: str = Field(default="", description="Human-readable guidance when no SQL fix applies")
    rollback_sql: str = Field(default="", description="How to undo the fix")

    @classmethod
    def from_diagnostic(
        cls,
        diagnostic: DiagnosticFinding,
        fix_sql: str = "",
        fix_notes: str = "",
        rollback_sql: str = "",
    ) -> "RemediatedFinding":
        return cls(
            id=diagnostic.id,
            severity=diagnostic.severity,
            category=diagnostic.category,
            affected=diagnostic.affected,
            root_cause=diagnostic.root_cause,
            impact=diagnostic.impact,
            risk=diagnostic.risk,
            fix_sql=fix_sql,
            fix_notes=fix_notes,
            rollback_sql=rollback_sql,
        )


class AnalysisReport(BaseModel):
    """Full report returned by the agent."""

    run_id: str
    db_type: str
    db_name: str
    analysed_at: datetime = Field(default_factory=datetime.utcnow)
    summary: str

    # Populated after Call 1
    findings: list[DiagnosticFinding] = Field(default_factory=list)
    quick_wins: list[str] = Field(
        default_factory=list,
        description="IDs of the top 3 safe-to-apply findings",
    )
    deferred: list[str] = Field(
        default_factory=list,
        description="IDs of findings needing a maintenance window",
    )
    raw_markdown: str = Field(default="", description="Raw markdown from Call 1")

    # Populated after Call 2 (may remain empty if remediation not requested)
    remediations: list[RemediatedFinding] = Field(
        default_factory=list,
        description="SQL fixes, populated by the remediate() call",
    )
    remediation_markdown: str = Field(
        default="", description="Raw markdown from Call 2"
    )

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.CRITICAL)

    @property
    def high_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.HIGH)

    def is_remediated(self, finding_id: str) -> bool:
        return any(r.id == finding_id for r in self.remediations)

    def select_for_remediation(
        self,
        scope: RemediationScope = RemediationScope.TOP_N,
        n: int = 5,
        ids: list[str] | None = None,
    ) -> list[DiagnosticFinding]:
        """Return the subset of findings to send to Call 2."""
        if scope == RemediationScope.IDS:
            target = set(ids or [])
            return [f for f in self.findings if f.id in target]
        if scope == RemediationScope.FULL:
            return list(self.findings)
        # TOP_N: sort primarily by severity (CRITICAL first), then by risk
        # (SAFE before REVIEW_FIRST) as a tiebreaker within the same severity.
        # This ensures a CRITICAL/REVIEW_FIRST finding ranks above a HIGH/SAFE
        # one — severity is the primary business signal.
        _RISK_ORDER = [RiskLevel.SAFE, RiskLevel.REQUIRES_MAINTENANCE_WINDOW, RiskLevel.REVIEW_FIRST]
        sorted_findings = sorted(
            self.findings,
            key=lambda f: (
                _SEVERITY_ORDER.index(f.severity),
                _RISK_ORDER.index(f.risk),
            ),
        )
        return sorted_findings[:n]


class ChangedFinding(BaseModel):
    """A finding whose severity or risk level shifted between two runs."""
    baseline: DiagnosticFinding
    current: DiagnosticFinding


class ReportDiff(BaseModel):
    """Structural diff between a baseline and the current AnalysisReport."""
    baseline_run_id: str
    baseline_analysed_at: datetime
    current_run_id: str
    new: list[DiagnosticFinding] = Field(default_factory=list)
    resolved: list[DiagnosticFinding] = Field(default_factory=list)
    changed: list[ChangedFinding] = Field(default_factory=list)
    unchanged: list[DiagnosticFinding] = Field(default_factory=list)

    @property
    def has_changes(self) -> bool:
        return bool(self.new or self.resolved or self.changed)


def diff_reports(baseline: "AnalysisReport", current: "AnalysisReport") -> ReportDiff:
    """
    Compare two AnalysisReport objects.

    Findings are matched by (category, normalised affected string) rather than
    ID, because IDs are assigned sequentially per-run and are not stable across
    runs.  Two findings with the same category and the same affected target are
    considered the same finding.
    """
    def _key(f: DiagnosticFinding) -> tuple[str, str]:
        return (f.category.value, f.affected.lower().strip())

    baseline_map = {_key(f): f for f in baseline.findings}
    current_map  = {_key(f): f for f in current.findings}

    new: list[DiagnosticFinding] = []
    resolved: list[DiagnosticFinding] = []
    changed: list[ChangedFinding] = []
    unchanged: list[DiagnosticFinding] = []

    for key, cur_f in current_map.items():
        if key not in baseline_map:
            new.append(cur_f)
        else:
            base_f = baseline_map[key]
            if base_f.severity != cur_f.severity or base_f.risk != cur_f.risk:
                changed.append(ChangedFinding(baseline=base_f, current=cur_f))
            else:
                unchanged.append(cur_f)

    for key, base_f in baseline_map.items():
        if key not in current_map:
            resolved.append(base_f)

    return ReportDiff(
        baseline_run_id=baseline.run_id,
        baseline_analysed_at=baseline.analysed_at,
        current_run_id=current.run_id,
        new=new,
        resolved=resolved,
        changed=changed,
        unchanged=unchanged,
    )


class DatabaseContext(BaseModel):
    """
    Snapshot of database metadata passed to Claude as context.
    Populated by the DB adapters.
    """

    db_type: str
    db_name: str
    schema_name: str = "public"
    tables: list[dict[str, Any]] = Field(default_factory=list)
    indexes: list[dict[str, Any]] = Field(default_factory=list)
    slow_queries: list[dict[str, Any]] = Field(default_factory=list)
    missing_fk_indexes: list[dict[str, Any]] = Field(default_factory=list)
    unused_indexes: list[dict[str, Any]] = Field(default_factory=list)
    views: list[dict[str, Any]] = Field(default_factory=list)
    functions: list[dict[str, Any]] = Field(default_factory=list)
    column_stats: list[dict[str, Any]] = Field(default_factory=list)
    server_config: list[dict[str, Any]] = Field(default_factory=list)
    extra_context: str = Field(
        default="",
        description="Free-text additional context from the user",
    )
