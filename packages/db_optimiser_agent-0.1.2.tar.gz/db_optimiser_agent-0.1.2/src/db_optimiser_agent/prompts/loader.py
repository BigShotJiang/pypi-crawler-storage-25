"""Load system prompts from the markdown files next to this module."""

from __future__ import annotations

from pathlib import Path

_DIR = Path(__file__).parent


def load_system_prompt() -> str:
    """Return the analysis prompt (Call 1) as a string."""
    return (_DIR / "analysis_prompt.md").read_text(encoding="utf-8")


def load_remediation_prompt() -> str:
    """Return the remediation prompt (Call 2) as a string."""
    return (_DIR / "remediation_prompt.md").read_text(encoding="utf-8")
