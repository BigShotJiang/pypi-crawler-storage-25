# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.75.4](https://github.com/CoReason-AI/coreason-runtime/compare/v0.75.3...v0.75.4) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.75.4 ([09111ea](https://github.com/CoReason-AI/coreason-runtime/commit/09111ea7333f24815c2e6456849e80e907f1951a))

## [0.75.3](https://github.com/CoReason-AI/coreason-runtime/compare/v0.75.2...v0.75.3) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.75.3 ([45b0f90](https://github.com/CoReason-AI/coreason-runtime/commit/45b0f90ce6458115545f3a3417813dab46d533b4))

## [0.75.2](https://github.com/CoReason-AI/coreason-runtime/compare/v0.75.1...v0.75.2) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.75.2 ([7a62367](https://github.com/CoReason-AI/coreason-runtime/commit/7a62367b39cc7ed7f0d7ca4555d7361d836b8233))

## [0.75.1](https://github.com/CoReason-AI/coreason-runtime/compare/v0.75.0...v0.75.1) (2026-05-22)


### Bug Fixes

* **ci:** resolve ruff/bandit security and argument errors ([a6f0fae](https://github.com/CoReason-AI/coreason-runtime/commit/a6f0fae47473232410cc67a1b7d62f744066cad9))

## [0.75.0](https://github.com/CoReason-AI/coreason-runtime/compare/v0.74.7...v0.75.0) (2026-05-22)


### Features

* **api:** add CORSMiddleware to allow direct frontend connections ([9f2e410](https://github.com/CoReason-AI/coreason-runtime/commit/9f2e41066c533b68916c0524d8cec63299019655))

## [0.74.7](https://github.com/CoReason-AI/coreason-runtime/compare/v0.74.6...v0.74.7) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.74.7 ([6ffd011](https://github.com/CoReason-AI/coreason-runtime/commit/6ffd01128a56e35ff13901357fb74124fdd76dd6))

## [0.74.6](https://github.com/CoReason-AI/coreason-runtime/compare/v0.74.5...v0.74.6) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.74.6 ([fecbd01](https://github.com/CoReason-AI/coreason-runtime/commit/fecbd0199437a603a732bdc3b342aed2ab468626))

## [0.74.5](https://github.com/CoReason-AI/coreason-runtime/compare/v0.74.4...v0.74.5) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.74.5 ([69df7e4](https://github.com/CoReason-AI/coreason-runtime/commit/69df7e4226c30ff9402053e7e7342efb6b68f93f))

## [0.74.4](https://github.com/CoReason-AI/coreason-runtime/compare/v0.74.3...v0.74.4) (2026-05-22)


### Documentation

* sync RELEASE.md with updated infrastructure release policy ([1afa38b](https://github.com/CoReason-AI/coreason-runtime/commit/1afa38b1e8602baab62ed52a990089342adda21c))

## [0.74.3](https://github.com/CoReason-AI/coreason-runtime/compare/v0.74.2...v0.74.3) (2026-05-22)


### Bug Fixes

* **ci:** prevent release-please fromJSON parser error when release PR is empty ([0321e87](https://github.com/CoReason-AI/coreason-runtime/commit/0321e8779023fe6bd97e1dcd6401c7b4e0d24c45))

## [0.74.2](https://github.com/CoReason-AI/coreason-runtime/compare/v0.74.1...v0.74.2) (2026-05-22)


### Bug Fixes

* **api:** instantiate EgressEvent and SemanticSpaceResponse using field names to resolve mypy errors ([bfdb667](https://github.com/CoReason-AI/coreason-runtime/commit/bfdb667c5a7ccde25a851dc08138cfd3d9c97055))

## [0.74.1](https://github.com/CoReason-AI/coreason-runtime/compare/v0.74.0...v0.74.1) (2026-05-22)


### Bug Fixes

* resolve ruff unused arguments and imports in API routers and tests ([092cfe3](https://github.com/CoReason-AI/coreason-runtime/commit/092cfe3fd2b2c723ad63a53fc06f748a5cf14bbe))

## [0.74.0](https://github.com/CoReason-AI/coreason-runtime/compare/v0.73.3...v0.74.0) (2026-05-22)


### Features

* Sensory Command Center backend handshakes ([#373](https://github.com/CoReason-AI/coreason-runtime/issues/373), [#374](https://github.com/CoReason-AI/coreason-runtime/issues/374), [#375](https://github.com/CoReason-AI/coreason-runtime/issues/375), [#376](https://github.com/CoReason-AI/coreason-runtime/issues/376)) ([15cfefd](https://github.com/CoReason-AI/coreason-runtime/commit/15cfefdf2102a0cffb3cb2ea369fdc9ee7ae7b5f))

## [0.73.3](https://github.com/CoReason-AI/coreason-runtime/compare/v0.73.2...v0.73.3) (2026-05-22)


### Bug Fixes

* resolve ruff import ordering and bandit hardcoded password warning in tests ([c591ee0](https://github.com/CoReason-AI/coreason-runtime/commit/c591ee033f5d83be858eb37fbeebd0b61b8fe093))

## [0.73.2](https://github.com/CoReason-AI/coreason-runtime/compare/v0.73.1...v0.73.2) (2026-05-22)


### Bug Fixes

* resolve backend Yjs syntax error, dynamic openai config, and neo4j retry resilience (resolves [#24](https://github.com/CoReason-AI/coreason-runtime/issues/24), [#25](https://github.com/CoReason-AI/coreason-runtime/issues/25), [#26](https://github.com/CoReason-AI/coreason-runtime/issues/26)) ([610489a](https://github.com/CoReason-AI/coreason-runtime/commit/610489a6cfad03ca4a964299bfe1a55e474a6948))

## [0.73.1](https://github.com/CoReason-AI/coreason-runtime/compare/v0.73.0...v0.73.1) (2026-05-22)


### Bug Fixes

* **ci:** handle policy-blocked release-please merge gracefully ([224146a](https://github.com/CoReason-AI/coreason-runtime/commit/224146a1d1ad539285c41e55bf22dfe91e3fabaf))

## [0.73.0](https://github.com/CoReason-AI/coreason-runtime/compare/v0.72.9...v0.73.0) (2026-05-22)


### Features

* **api:** add provision and capabilities integration endpoints ref [#27](https://github.com/CoReason-AI/coreason-runtime/issues/27) [#38](https://github.com/CoReason-AI/coreason-runtime/issues/38) ([236a4de](https://github.com/CoReason-AI/coreason-runtime/commit/236a4de3faebd21f2a292a63db450c728d71d2ad))

## [0.72.9](https://github.com/CoReason-AI/coreason-runtime/compare/v0.72.8...v0.72.9) (2026-05-22)


### Bug Fixes

* **ci:** remove unused mypy ignore comment in test_extism_runner ([8b7a23b](https://github.com/CoReason-AI/coreason-runtime/commit/8b7a23ba4b44e5d8e03638944814dce6d81a3a85))

## [0.72.8](https://github.com/CoReason-AI/coreason-runtime/compare/v0.72.7...v0.72.8) (2026-05-22)


### Bug Fixes

* **ci:** format imports and files, and register profile router ([c5f8812](https://github.com/CoReason-AI/coreason-runtime/commit/c5f881218593fa1b65058d3b2b085aa3bab4f98f))

## [0.72.7](https://github.com/CoReason-AI/coreason-runtime/compare/v0.72.6...v0.72.7) (2026-05-22)


### Performance Improvements

* **discovery:** search result TTL cache for DiscoveryIndexer (Sprint D) ([ab4ed76](https://github.com/CoReason-AI/coreason-runtime/commit/ab4ed76adb6dfdb2c52a82e59baea49e352232ed))

## [0.72.6](https://github.com/CoReason-AI/coreason-runtime/compare/v0.72.5...v0.72.6) (2026-05-22)


### Bug Fixes

* **ci:** fix Ruff B017 assertion error and apply auto-formatting ([21dafe5](https://github.com/CoReason-AI/coreason-runtime/commit/21dafe57fb6d9055b42014a407b95145e04b07d4))

## [0.72.5](https://github.com/CoReason-AI/coreason-runtime/compare/v0.72.4...v0.72.5) (2026-05-22)


### Bug Fixes

* **yjs:** correct Python 2-style except syntax to tuple form ([#363](https://github.com/CoReason-AI/coreason-runtime/issues/363)) ([5a5a276](https://github.com/CoReason-AI/coreason-runtime/commit/5a5a2763a8ae95779eead47f61e6b9ad19105782))

## [0.72.4](https://github.com/CoReason-AI/coreason-runtime/compare/v0.72.3...v0.72.4) (2026-05-22)


### Bug Fixes

* **ci:** add flwr and delta_sharing to deptry ignores ([5722c66](https://github.com/CoReason-AI/coreason-runtime/commit/5722c669bba74a77b3ed0812d6de7da12388cdfe))

## [0.72.3](https://github.com/CoReason-AI/coreason-runtime/compare/v0.72.2...v0.72.3) (2026-05-22)


### Bug Fixes

* **ci:** resolve mypy typechecking and formatting issues ([453afca](https://github.com/CoReason-AI/coreason-runtime/commit/453afcaa34c02cc3dea192eaa0655bd9aa931330))

## [0.72.2](https://github.com/CoReason-AI/coreason-runtime/compare/v0.72.1...v0.72.2) (2026-05-22)


### Bug Fixes

* **ci:** resolve ruff lint and bandit security scan errors ([19f6ab0](https://github.com/CoReason-AI/coreason-runtime/commit/19f6ab0f88d41c4ada81a7b6003aa8f5f1cfb06c))
* **release:** upgrade release-please workflow to use robust pr merge fallback and correct token list ([fcfabd1](https://github.com/CoReason-AI/coreason-runtime/commit/fcfabd14cabc81dd8d029f51164ba7dec92e5832))

## [0.72.1](https://github.com/CoReason-AI/coreason-runtime/compare/v0.72.0...v0.72.1) (2026-05-22)


### Bug Fixes

* Sprint 5 bug fixes and security hardening ([#352](https://github.com/CoReason-AI/coreason-runtime/issues/352), [#353](https://github.com/CoReason-AI/coreason-runtime/issues/353), [#355](https://github.com/CoReason-AI/coreason-runtime/issues/355), [#356](https://github.com/CoReason-AI/coreason-runtime/issues/356), [#357](https://github.com/CoReason-AI/coreason-runtime/issues/357)) ([ec3b44f](https://github.com/CoReason-AI/coreason-runtime/commit/ec3b44f18893dfe21c5980d34fe433f148c15912))

## [0.72.0](https://github.com/CoReason-AI/coreason-runtime/compare/v0.71.0...v0.72.0) (2026-05-22)


### Features

* **execution:** Sprint 4 advanced capabilities ([#289](https://github.com/CoReason-AI/coreason-runtime/issues/289), [#306](https://github.com/CoReason-AI/coreason-runtime/issues/306), [#324](https://github.com/CoReason-AI/coreason-runtime/issues/324), [#325](https://github.com/CoReason-AI/coreason-runtime/issues/325), [#327](https://github.com/CoReason-AI/coreason-runtime/issues/327), [#328](https://github.com/CoReason-AI/coreason-runtime/issues/328), [#329](https://github.com/CoReason-AI/coreason-runtime/issues/329), [#330](https://github.com/CoReason-AI/coreason-runtime/issues/330), [#335](https://github.com/CoReason-AI/coreason-runtime/issues/335), [#336](https://github.com/CoReason-AI/coreason-runtime/issues/336), [#337](https://github.com/CoReason-AI/coreason-runtime/issues/337), [#348](https://github.com/CoReason-AI/coreason-runtime/issues/348), [#349](https://github.com/CoReason-AI/coreason-runtime/issues/349)) ([a129e09](https://github.com/CoReason-AI/coreason-runtime/commit/a129e090a3a6e10cfb640b5ff89a614adc8abbe9))

## [0.71.0](https://github.com/CoReason-AI/coreason-runtime/compare/v0.70.0...v0.71.0) (2026-05-22)


### Features

* **telemetry:** SSE broker, WASM hardening, speculative decoding, and Polars flusher ([#305](https://github.com/CoReason-AI/coreason-runtime/issues/305), [#309](https://github.com/CoReason-AI/coreason-runtime/issues/309), [#322](https://github.com/CoReason-AI/coreason-runtime/issues/322), [#326](https://github.com/CoReason-AI/coreason-runtime/issues/326), [#331](https://github.com/CoReason-AI/coreason-runtime/issues/331), [#332](https://github.com/CoReason-AI/coreason-runtime/issues/332), [#333](https://github.com/CoReason-AI/coreason-runtime/issues/333), [#334](https://github.com/CoReason-AI/coreason-runtime/issues/334), [#340](https://github.com/CoReason-AI/coreason-runtime/issues/340), [#346](https://github.com/CoReason-AI/coreason-runtime/issues/346), [#347](https://github.com/CoReason-AI/coreason-runtime/issues/347), [#350](https://github.com/CoReason-AI/coreason-runtime/issues/350)) ([6e2d97b](https://github.com/CoReason-AI/coreason-runtime/commit/6e2d97beb5b28087ddffc42cc1ee7737f9692dce))

## [0.70.0](https://github.com/CoReason-AI/coreason-runtime/compare/v0.69.1...v0.70.0) (2026-05-22)


### Features

* **security:** Merkle DAG WORM audit ledger and deterministic routing ([#323](https://github.com/CoReason-AI/coreason-runtime/issues/323), [#351](https://github.com/CoReason-AI/coreason-runtime/issues/351)) ([9818e8f](https://github.com/CoReason-AI/coreason-runtime/commit/9818e8ff495282c897420d9b19f4ca12b1eab9c5))


### Bug Fixes

* **orchestration:** deterministic set iteration in DynamicRoutingExecutionWorkflow ([#351](https://github.com/CoReason-AI/coreason-runtime/issues/351)) ([4b41154](https://github.com/CoReason-AI/coreason-runtime/commit/4b41154cd3e2e58b94965ece48c1c4d602079cfd))
* sorted(target_nodes) forces lexicographic ordering. ([4b41154](https://github.com/CoReason-AI/coreason-runtime/commit/4b41154cd3e2e58b94965ece48c1c4d602079cfd))

## [0.69.1](https://github.com/CoReason-AI/coreason-runtime/compare/v0.69.0...v0.69.1) (2026-05-22)


### Bug Fixes

* **license:** add ezkl to deptry ignores and fix trailing whitespace ([f4c7a5c](https://github.com/CoReason-AI/coreason-runtime/commit/f4c7a5c705c6d67092a03cd65b8e1cabab310e02))
* **license:** add mypy ignore overrides for ezkl module ([203b61e](https://github.com/CoReason-AI/coreason-runtime/commit/203b61ee186e5d43d034c8798d17d5fe3d55fe06))
* **license:** implement zk-SNARK verification and production licensing guards ([#307](https://github.com/CoReason-AI/coreason-runtime/issues/307), [#308](https://github.com/CoReason-AI/coreason-runtime/issues/308)) ([6283450](https://github.com/CoReason-AI/coreason-runtime/commit/628345031616c2d4f52b599750e6eccc280cc381))

## [0.69.0](https://github.com/CoReason-AI/coreason-runtime/compare/v0.68.0...v0.69.0) (2026-05-22)


### Features

* realize workflow history endpoint and refine type constraints ([975b4f7](https://github.com/CoReason-AI/coreason-runtime/commit/975b4f7309b46bf04831e9ac6de32b1bd036e7bc))
* **runtime:** implement local runtime simulator and ontological vocabulary solver ([d15137b](https://github.com/CoReason-AI/coreason-runtime/commit/d15137b5d808f7673ea7d12471f2a172fc06dcfb))

## [0.68.0](https://github.com/CoReason-AI/coreason-runtime/compare/v0.67.2...v0.68.0) (2026-05-21)


### Features

* **api:** integrate capabilities, telemetry stream, and websocket collab servers ([c463133](https://github.com/CoReason-AI/coreason-runtime/commit/c46313384c9c914a7759dc0ee48c059f505952eb))
* implement BaseTopologyWorkflow with state reconciliation and governance enforcement alongside comprehensive unit and integration tests ([f401b22](https://github.com/CoReason-AI/coreason-runtime/commit/f401b229d6b53799f86642384ba0b2f8341f9783))


### Bug Fixes

* **ci:** resolve ruff import sorting and gitleaks secret detection ([8f69fa7](https://github.com/CoReason-AI/coreason-runtime/commit/8f69fa70440c083d163c74d5a72b32402a228dd1))
* **ci:** resolve ruff lint, bandit security warnings, and release version mismatch ([7e8798e](https://github.com/CoReason-AI/coreason-runtime/commit/7e8798ec94fe08a7a05fa72afe70e50920543f75))
* **lint:** resolve ruff collections.abc and type arguments warnings in capabilities.py ([94c786c](https://github.com/CoReason-AI/coreason-runtime/commit/94c786caaaaed74845b638905722848bab50018f))
* **types:** resolve mypy type check errors for api routers and test mocks ([7b76248](https://github.com/CoReason-AI/coreason-runtime/commit/7b7624846f2df6dd8214aecbedab7d004be64008))

## [0.67.2](https://github.com/CoReason-AI/coreason-runtime/compare/v0.67.1...v0.67.2) (2026-05-21)


### Bug Fixes

* **runtime:** resolve null mutation gradient parsing, SPIFFE workload identity injection, and Temporal sandbox import violations ([b5bcd2c](https://github.com/CoReason-AI/coreason-runtime/commit/b5bcd2caf4370bec63f0a319a165d1552ae12273))

## [0.67.1](https://github.com/CoReason-AI/coreason-runtime/compare/v0.67.0...v0.67.1) (2026-05-21)


### Bug Fixes

* **runtime:** resolve sandbox violations, telemetry envelope bugs, and non-deterministic rehydration crashes ([25ad028](https://github.com/CoReason-AI/coreason-runtime/commit/25ad02880c2f9e542a49062b7fb0522dcc68c2e8))

## [0.67.0](https://github.com/CoReason-AI/coreason-runtime/compare/v0.66.0...v0.67.0) (2026-05-21)


### Features

* **release:** transition python packages to fully dynamic runtime versioning ([5df00e8](https://github.com/CoReason-AI/coreason-runtime/commit/5df00e8f42925c1a298d402390e186c4e90257ab))


### Bug Fixes

* **release:** support dynamic versioning validation in release workflow ([66ea82e](https://github.com/CoReason-AI/coreason-runtime/commit/66ea82e797c87249e081ccca7a0fe98fa5ae92a6))
* **runtime:** add noqa for bandit lint on test dummy path ([a3b1868](https://github.com/CoReason-AI/coreason-runtime/commit/a3b18689806b23cb21383b966fd2b31c996beea7))
* **runtime:** fallback to dummy path in capability forge workflow under tests ([86e1584](https://github.com/CoReason-AI/coreason-runtime/commit/86e1584547b61a93f24d900e15fdc6455f01556d))


### Documentation

* **release:** document OCI artifacts, cloud marketplaces, and GitOps integration ([3445557](https://github.com/CoReason-AI/coreason-runtime/commit/344555755c1d621a8751b31165811911d950220d))
* **release:** document Swarm-in-a-Box packaging and deprecations ([864b0e6](https://github.com/CoReason-AI/coreason-runtime/commit/864b0e61e52bfab1fc333d142c00455d2bd0978a))
* **release:** update coordinated release guide ([f7b6240](https://github.com/CoReason-AI/coreason-runtime/commit/f7b624024922766d553c6825315e21f46d815322))

## [Unreleased]

### Added

- Enterprise-grade SECURITY.md vulnerability disclosure policy
- PyPI keywords for package discoverability
- Gitleaks managed action with organization license key
- Advanced security workflow (ClamAV malware scan + copyleft license firewall)

*Copyright (c) 2026 CoReason, Inc. Licensed under the Prosperity Public License 3.0.*
