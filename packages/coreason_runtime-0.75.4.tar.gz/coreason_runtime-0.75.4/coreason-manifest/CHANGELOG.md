# Changelog

## [0.94.12](https://github.com/CoReason-AI/coreason-manifest/compare/v0.94.11...v0.94.12) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.94.12 ([f65246c](https://github.com/CoReason-AI/coreason-manifest/commit/f65246c094b4b6382d7f72732689dc575053721f))

## [0.94.11](https://github.com/CoReason-AI/coreason-manifest/compare/v0.94.10...v0.94.11) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.94.11 ([9d23460](https://github.com/CoReason-AI/coreason-manifest/commit/9d2346007221303e3526c80bfae46391d15cac29))

## [0.94.10](https://github.com/CoReason-AI/coreason-manifest/compare/v0.94.9...v0.94.10) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.94.10 ([76dd2b3](https://github.com/CoReason-AI/coreason-manifest/commit/76dd2b389c7db0c59056dea73708dd8ff81d191e))

## [0.94.9](https://github.com/CoReason-AI/coreason-manifest/compare/v0.94.8...v0.94.9) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.94.9 ([0b0bc69](https://github.com/CoReason-AI/coreason-manifest/commit/0b0bc69daf763e4075fd24bfdd04f098211513b0))

## [0.94.8](https://github.com/CoReason-AI/coreason-manifest/compare/v0.94.7...v0.94.8) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.94.8 ([b58b5c9](https://github.com/CoReason-AI/coreason-manifest/commit/b58b5c9a47ab910b93fb14c7d690dc1300d71b79))

## [0.94.7](https://github.com/CoReason-AI/coreason-manifest/compare/v0.94.6...v0.94.7) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.94.7 ([7d3ba05](https://github.com/CoReason-AI/coreason-manifest/commit/7d3ba059be534f295491b4a4e67a860b61981efe))

## [0.94.6](https://github.com/CoReason-AI/coreason-manifest/compare/v0.94.5...v0.94.6) (2026-05-22)


### Documentation

* sync RELEASE.md with updated infrastructure release policy ([43cd4e3](https://github.com/CoReason-AI/coreason-manifest/commit/43cd4e3acf1e04415b4d6a75ec170b843bce0cab))

## [0.94.5](https://github.com/CoReason-AI/coreason-manifest/compare/v0.94.4...v0.94.5) (2026-05-22)


### Bug Fixes

* **ci:** handle policy-blocked release-please merge gracefully ([c442a29](https://github.com/CoReason-AI/coreason-manifest/commit/c442a29722293ecdbc419f8ecfe2ebd054110e83))

## [0.94.4](https://github.com/CoReason-AI/coreason-manifest/compare/v0.94.3...v0.94.4) (2026-05-22)


### Bug Fixes

* **ci:** remove GHCR_PAT fallback from release-please token ([fcfa201](https://github.com/CoReason-AI/coreason-manifest/commit/fcfa2011788a0e4d0c9d0d59c54cd3cb08e78038))

## [0.94.3](https://github.com/CoReason-AI/coreason-manifest/compare/v0.94.2...v0.94.3) (2026-05-22)


### Bug Fixes

* **release:** prevent fromJSON parser error when release PR is empty ([7d05ed0](https://github.com/CoReason-AI/coreason-manifest/commit/7d05ed0bfd0d54e1d8ffa12d0e1df36c35b1a8f6))

## [0.94.2](https://github.com/CoReason-AI/coreason-manifest/compare/v0.94.1...v0.94.2) (2026-05-22)


### Bug Fixes

* **release:** test final auto-merge workflow v2 ([4ce25ce](https://github.com/CoReason-AI/coreason-manifest/commit/4ce25cefdfe29c6ee580fbd0afe15b3215f1b961))
* **release:** test fromJSON merge logic ([8e5d746](https://github.com/CoReason-AI/coreason-manifest/commit/8e5d7464916dddcdf339744c55bce306dbae5078))
* **release:** test robust auto-merge pipeline ([a94f45b](https://github.com/CoReason-AI/coreason-manifest/commit/a94f45bd9a4ebd6e53d9e114551dc80a1cf19fff))

## [0.94.1](https://github.com/CoReason-AI/coreason-manifest/compare/v0.94.0...v0.94.1) (2026-05-22)


### Bug Fixes

* **release:** test release-please auto-merge pipeline ([0f08d12](https://github.com/CoReason-AI/coreason-manifest/commit/0f08d12a2c0afcdc2d80646d3e046e699cee6fc6))

## [0.54.1](https://github.com/CoReason-AI/coreason-manifest/releases) (2026-05-13)


### Features

* **ontology:** remove deprecated proprietary chaos components ([#1721](https://github.com/CoReason-AI/coreason-manifest/issues/1721)) ([1f54db6](https://github.com/CoReason-AI/coreason-manifest/commit/1f54db6b2e024440678e3ac9f03ec6a69e7e3b3c))


### Bug Fixes

* **ci:** sync release-please manifest version to v0.54.0 ([c5dd1b9](https://github.com/CoReason-AI/coreason-manifest/commit/c5dd1b9e0f15294f09a7286270b448643da176fb))
* **ci:** sync release-please manifest version to v0.54.0 ([5fa206f](https://github.com/CoReason-AI/coreason-manifest/commit/5fa206f3578b9e0519dccc27be8b50134b185cf6))
* remove orphaned SteadyStateHypothesisState (chaos deprecation) ([b42dbec](https://github.com/CoReason-AI/coreason-manifest/commit/b42dbec45c03afe7576a2516d48f43d96ed8db2e))
* remove unused mypy type-ignore on mcp_adapters (Python 3.14 compat) ([5e33849](https://github.com/CoReason-AI/coreason-manifest/commit/5e33849fb33e9db3051d4cd142176b99a9d4fab2))


### Refactoring

* remove deprecated SpanKindProfile ([ed75ab7](https://github.com/CoReason-AI/coreason-manifest/commit/ed75ab7a7e22f4d54b980c316aa0c90fea4e6c82))

## 0.54.0 (2026-05-13)


### Features

* add algebra module for manifest data transformations and ontology schema generation ([4eef003](https://github.com/CoReason-AI/coreason-manifest/commit/4eef003b59c756c5fb3e1326c044fda67d0c84a9))
* add algebra utilities for manifest projection and ontology schema generation ([6e137c3](https://github.com/CoReason-AI/coreason-manifest/commit/6e137c3887cbd36550c13aceabe170a9368614b4))
* add automated multi-language release workflow for PyPI, npm, cr… ([bbd33cd](https://github.com/CoReason-AI/coreason-manifest/commit/bbd33cdeafe87513bfc257d1b01dcd936ec206e6))
* add automated multi-language release workflow for PyPI, npm, crates.io, and GitHub Pages ([614e44b](https://github.com/CoReason-AI/coreason-manifest/commit/614e44bb1b9b720251d90fd9ed43bf7fac639036))
* add CI workflow for multi-language release, packaging, and documentation deployment ([ac9cb92](https://github.com/CoReason-AI/coreason-manifest/commit/ac9cb92763d3495f9b0cf5d0300983ae9291b1a3))
* add CI workflow to automate multi-language releases and documentation deployment ([67e1703](https://github.com/CoReason-AI/coreason-manifest/commit/67e1703f5bfa58f4deae0389bd41c1ec93ccd34b))
* add CI workflow to automate release, documentation, and multi-language package publishing ([9e46d66](https://github.com/CoReason-AI/coreason-manifest/commit/9e46d6623b06227ad4426ede04e05b9d70b8f1a1))
* add CI workflow to automate release, documentation, and multi-language package publishing ([099f221](https://github.com/CoReason-AI/coreason-manifest/commit/099f221ecb21be5e6d63ce3342b1601b0ab0a136))
* add CI workflow with linting, security audits, cross-platform testing, and build determinism checks ([f5b713d](https://github.com/CoReason-AI/coreason-manifest/commit/f5b713dd0d03f29331362b9932bf23013334069b))
* add CI workflow with linting, security gates, multi-platform testing, and build determinism checks ([bd20138](https://github.com/CoReason-AI/coreason-manifest/commit/bd20138d92f391b44da598e497fbb2369657599e))
* add CI/CD workflow for multi-language package publishing and documentation deployment ([56047de](https://github.com/CoReason-AI/coreason-manifest/commit/56047de089d8a00090b291dc364c738bd417b9ac))
* add CI/CD workflow to automate releases for PyPI, npm, crates.io, and GitHub Pages ([ab07e3c](https://github.com/CoReason-AI/coreason-manifest/commit/ab07e3c722ba5b08b584b7723a437f6c3aa4d9ef))
* Add computational thermodynamics bounds and circuit breakers ([#1525](https://github.com/CoReason-AI/coreason-manifest/issues/1525)) ([30b8ff8](https://github.com/CoReason-AI/coreason-manifest/commit/30b8ff8233b2907732f520416ac4d059d517b76f))
* Add core specifications, utility functions, and a comprehensive suite of tests and validation scripts. ([4d271dd](https://github.com/CoReason-AI/coreason-manifest/commit/4d271dd710b5d107fa6f0778974e384962e1180c))
* add coreason_topological_exemption property to schema definitions for environment_imports, answer_sets, containment_edges, and variable_bindings ([be72eb8](https://github.com/CoReason-AI/coreason-manifest/commit/be72eb8d7a03f1cb230ecb75133c3c6fe88c0a67))
* add deterministic TypeScript serialization and automated NPM publishing workflow ([1d22321](https://github.com/CoReason-AI/coreason-manifest/commit/1d2232189a65d1e87913b9844a92a6bfd703ee0b))
* add GitHub Actions workflow for automated secret, malware, and license compliance scanning ([0e0ec27](https://github.com/CoReason-AI/coreason-manifest/commit/0e0ec2782485a6d0de42d1d5c0926547d55b4bf0))
* add GitHub Actions workflow for multi-language release and publishing ([0a45ec9](https://github.com/CoReason-AI/coreason-manifest/commit/0a45ec95000a6244081cedd7f3e887f6fba23b27))
* add GitHub Actions workflow for multi-language release and publishing ([2d026b4](https://github.com/CoReason-AI/coreason-manifest/commit/2d026b428c7f525ede8dd2fd458cd7f6d5beabef))
* add GitHub Actions workflow for secret scanning, malware detection, and license compliance ([a350b86](https://github.com/CoReason-AI/coreason-manifest/commit/a350b861f6935e803a4df7e435f6848f851d3539))
* add multi-target release workflow for PyPI, npm, crates.io, and GitHub Pages ([e395bea](https://github.com/CoReason-AI/coreason-manifest/commit/e395bea77b1af7745702ef72ee24b4dd4d3e0082))
* add multi-target release workflow for PyPI, npm, crates.io, and GitHub Pages ([78c84a2](https://github.com/CoReason-AI/coreason-manifest/commit/78c84a2a0cae3df42b8a0a0c15f1dc80eac425a5))
* add multi-target release workflow for PyPI, npm, crates.io, and GitHub Pages ([cde08a2](https://github.com/CoReason-AI/coreason-manifest/commit/cde08a22e20decee560ddf4af700e814ba8f5268))
* add OpenSSF Scorecard workflow for automated security analysis ([85e361a](https://github.com/CoReason-AI/coreason-manifest/commit/85e361a794146d675f327ed02ef6379b6ccedd67))
* add release-please workflow for automated versioning and changelogs ([98a6d6f](https://github.com/CoReason-AI/coreason-manifest/commit/98a6d6f2cccd8cb4f6b6b8f6b4dd17c9c60ceb2b))
* add rustworkx dependency and generate TypeScript ontology bindings ([fa95435](https://github.com/CoReason-AI/coreason-manifest/commit/fa954359ad5f53232071da400e1fb2f41481031c))
* add semantic_diff.py script to disable semantic diff checks. ([2aeb0da](https://github.com/CoReason-AI/coreason-manifest/commit/2aeb0da813c871027ce0c9426cb5dd08c4ac4523))
* add Zero-Trust Security & Hardware Limits doctrine to AGENTS.md ([3c0fa95](https://github.com/CoReason-AI/coreason-manifest/commit/3c0fa9539fe1d98e09a69bb04b23fce59fe424c5))
* apply array primitive bounding in ontology.py ([#1247](https://github.com/CoReason-AI/coreason-manifest/issues/1247)) ([006c682](https://github.com/CoReason-AI/coreason-manifest/commit/006c682012314732c1155ef298e064b683e1ffa8))
* AST-Native CI/CD Enforcement for Instantiation Bounds (Epic 1) ([#1243](https://github.com/CoReason-AI/coreason-manifest/issues/1243)) ([49b5158](https://github.com/CoReason-AI/coreason-manifest/commit/49b5158badff0eb1ced0bc27c39324a32f0a841f))
* autonomous recovery substrate with structured fault receipts ([#1341](https://github.com/CoReason-AI/coreason-manifest/issues/1341)) ([8e13b84](https://github.com/CoReason-AI/coreason-manifest/commit/8e13b842a7c5eb46c0e19ec7d10b5fa070ab2d3d))
* **bindings:** Establish Absolute Type Isomorphism via Cross-Language Generation and CI/CD Drift Guillotine ([15431d8](https://github.com/CoReason-AI/coreason-manifest/commit/15431d825ee5dffe48b07d0e40ef7c8115032165))
* **bindings:** Establish Absolute Type Isomorphism via Cross-Language Generation and CI/CD Drift Guillotine ([#1583](https://github.com/CoReason-AI/coreason-manifest/issues/1583)) ([89556f0](https://github.com/CoReason-AI/coreason-manifest/commit/89556f048e9ef2d67397b384d675a091e00c33c0))
* Contextual Semantic Resolution via Latent Manifold Alignment ([#1502](https://github.com/CoReason-AI/coreason-manifest/issues/1502)) ([a89cac6](https://github.com/CoReason-AI/coreason-manifest/commit/a89cac6fa78c3839eaa26d7fc5e817674b9b4bf5))
* Epic 1 - Domain-Agnostic Substrate ([#1497](https://github.com/CoReason-AI/coreason-manifest/issues/1497)) ([2501ed8](https://github.com/CoReason-AI/coreason-manifest/commit/2501ed89132f19d66336de2eb3bf6d6e917df810))
* Epic 1 - The Hollow Data Plane Refactor ([#1544](https://github.com/CoReason-AI/coreason-manifest/issues/1544)) ([7c13a5c](https://github.com/CoReason-AI/coreason-manifest/commit/7c13a5c71c04d360447a23cc3854af5320e16db4))
* Epic 1 - The Hollow Data Plane Refactor ([#1544](https://github.com/CoReason-AI/coreason-manifest/issues/1544)) ([fc72f78](https://github.com/CoReason-AI/coreason-manifest/commit/fc72f78b7459baed806283a571b8c6e08b0c3f06))
* Epic 1 - The Hollow Data Plane Refactor ([#1544](https://github.com/CoReason-AI/coreason-manifest/issues/1544)) ([d81efe5](https://github.com/CoReason-AI/coreason-manifest/commit/d81efe507ff16cfe3a476b2d975c077858e38f01))
* Epic 2 - The Multimodal Ingestion Engine (Docling-Graph) ([4200f0a](https://github.com/CoReason-AI/coreason-manifest/commit/4200f0a5746fd879b1bcd60dcc8716152df2b5a9))
* Epic 2 - The Multimodal Ingestion Engine (Docling-Graph) ([d2a0d54](https://github.com/CoReason-AI/coreason-manifest/commit/d2a0d541939538b7045af32a7c0c7d9b9d309298))
* Epic 2 - The Multimodal Ingestion Engine (Docling-Graph) ([4344885](https://github.com/CoReason-AI/coreason-manifest/commit/43448855cbb8390899b33349512ada98e1e039bb))
* Epic 2 - Unstructured Discourse Transmutation ([#1498](https://github.com/CoReason-AI/coreason-manifest/issues/1498)) ([f1fbe7b](https://github.com/CoReason-AI/coreason-manifest/commit/f1fbe7bec2d52caf681d68613af7fcfaa9f17450))
* expand P2P mesh discovery and cryptographic provenance manifests ([3db5181](https://github.com/CoReason-AI/coreason-manifest/commit/3db5181bbaa9061ac5c9c8e5555a3d7663faa018))
* export ontology specifications in package init module ([e58e066](https://github.com/CoReason-AI/coreason-manifest/commit/e58e0662a944a1681b6ecdbc4fa0fb85fdf46f63))
* implement algebraic utility module for manifest projection, ontology schema generation, and semantic manifold alignment ([51ffdd3](https://github.com/CoReason-AI/coreason-manifest/commit/51ffdd37c482599c32c30233302bbea48b3903f4))
* implement CI, security audit, and nightly fuzzing GitHub Actions workflows ([f7d58c5](https://github.com/CoReason-AI/coreason-manifest/commit/f7d58c52dc4cb74afd16681375e44f303bcd2718))
* implement comprehensive fuzzing test suite and architecture evaluation scripts for coreason-manifest specifications ([d33c7ba](https://github.com/CoReason-AI/coreason-manifest/commit/d33c7ba7a054496add50a63f88cdf9e5adad49ec))
* Implement Curriculum Synthesis ontology models and contract tests ([#1228](https://github.com/CoReason-AI/coreason-manifest/issues/1228)) ([6bb7d12](https://github.com/CoReason-AI/coreason-manifest/commit/6bb7d12f2ff191c05db603ea89f7d11b61836ec7))
* Implement Epic 3 Epistemic Rejection Framework ([#1522](https://github.com/CoReason-AI/coreason-manifest/issues/1522)) ([0e8eca6](https://github.com/CoReason-AI/coreason-manifest/commit/0e8eca60b7792f179c00e1c7012572956c695d4c))
* implement Epistemic Distillation schemas (Phase 1) ([#1225](https://github.com/CoReason-AI/coreason-manifest/issues/1225)) ([3a75349](https://github.com/CoReason-AI/coreason-manifest/commit/3a75349ee701ac7aea92da31cfd2a9531c600a80))
* implement epistemic ontology specs, SSRF-safe URL validation, and payload volume constraints with hypothesis testing support. ([914ac6a](https://github.com/CoReason-AI/coreason-manifest/commit/914ac6aca95adcab2fbb0e997669d3d24a4bc7a1))
* implement exogenous governance via OntologyDiscoveryIntent and SemanticMappingHeuristicProposal ([#1506](https://github.com/CoReason-AI/coreason-manifest/issues/1506)) ([d57cbc0](https://github.com/CoReason-AI/coreason-manifest/commit/d57cbc0cded87d5f59f80d1454a2b83f732fe7e4))
* implement manifest-driven convergence with hardware and security topologies ([#1424](https://github.com/CoReason-AI/coreason-manifest/issues/1424)) ([05e0db1](https://github.com/CoReason-AI/coreason-manifest/commit/05e0db1c3f6577102ca3b0abccb0be272da4a27f))
* implement MCP tool definition and secure payload validation utilities ([faa80a9](https://github.com/CoReason-AI/coreason-manifest/commit/faa80a90c4dd0040ff5cbb53c030d8fbc433e790))
* implement Meta-Engineering CLI and AST scaffolding ([#1411](https://github.com/CoReason-AI/coreason-manifest/issues/1411)) ([03974df](https://github.com/CoReason-AI/coreason-manifest/commit/03974df630203525f0a3865a8d3d16a88ea41e3a))
* implement multi-language release pipeline for PyPI, npm, and crates.io with automated binding generation ([ff12fcd](https://github.com/CoReason-AI/coreason-manifest/commit/ff12fcd5aa886d7ec4936b0d4a8f41a4c9502293))
* implement Neurosymbolic Caging Protocol across AGENTS.md and agent configuration rules ([72d7d34](https://github.com/CoReason-AI/coreason-manifest/commit/72d7d34c32167c1f02b48ed6d0a0636a14bca5dc))
* implement ontological classification and payload security valid… ([#1678](https://github.com/CoReason-AI/coreason-manifest/issues/1678)) ([2d217c1](https://github.com/CoReason-AI/coreason-manifest/commit/2d217c1e737fa8971cac9c75fa2eaec2a3d7944e))
* implement ontology specification with payload validation, canonicalization, and SSRF security controls ([e80e8df](https://github.com/CoReason-AI/coreason-manifest/commit/e80e8df5795230b43506367670ca18de8e043fb8))
* implement ontology specification with payload validation, topological DAG utilities, and epistemic security policies ([559d384](https://github.com/CoReason-AI/coreason-manifest/commit/559d3840b0a12f4c165f44dec5c33e729e23ef1c))
* implement ontology specifications and MCP adapter utilities for secure agent communication and payload validation. ([f855841](https://github.com/CoReason-AI/coreason-manifest/commit/f8558416c30c34fd33c10dedea9639f8cdb8ce4f))
* implement payload validation, SSRF protection, and compute profiling utilities in ontology specification ([0573f00](https://github.com/CoReason-AI/coreason-manifest/commit/0573f00f255d387e6644d52815ab3a5570384b82))
* implement Phase 2 rendering physics & telemetry pipeline ([#1357](https://github.com/CoReason-AI/coreason-manifest/issues/1357)) ([43cc754](https://github.com/CoReason-AI/coreason-manifest/commit/43cc7543bf8945a08e21d6f929754cedd56b9257))
* Implement Proposer-Verifier Macro Topology (Epic 3) ([#1445](https://github.com/CoReason-AI/coreason-manifest/issues/1445)) ([7f159d7](https://github.com/CoReason-AI/coreason-manifest/commit/7f159d79eb6e4581a59aa001b30155d7d5894b71))
* implement semantic zooming and observability LOD policy ([#1359](https://github.com/CoReason-AI/coreason-manifest/issues/1359)) ([d27d86b](https://github.com/CoReason-AI/coreason-manifest/commit/d27d86b0b21c7561625c8edd5602689c40fe1cfa))
* implement structural contracts for GRPO post-training ([#1229](https://github.com/CoReason-AI/coreason-manifest/issues/1229)) ([09397e4](https://github.com/CoReason-AI/coreason-manifest/commit/09397e4af25c8cd0f9427538c9b6e2844e4e2df1))
* implement topological reachability evaluation script ([#1532](https://github.com/CoReason-AI/coreason-manifest/issues/1532)) ([3f078fd](https://github.com/CoReason-AI/coreason-manifest/commit/3f078fd3184653cacf0cf7ffb9589732915c7932))
* initialize ontology module and export core manifest structures ([#1677](https://github.com/CoReason-AI/coreason-manifest/issues/1677)) ([9a60aa6](https://github.com/CoReason-AI/coreason-manifest/commit/9a60aa62910b717f04ff669907008bfe8cd03a7d))
* initialize project structure and add ontology type validation s… ([#1634](https://github.com/CoReason-AI/coreason-manifest/issues/1634)) ([4e14f4f](https://github.com/CoReason-AI/coreason-manifest/commit/4e14f4f8f58b32ad334ccfc1e4c16113a4c329d9))
* initialize TypeScript bindings project with package configuration and dependencies ([07806f1](https://github.com/CoReason-AI/coreason-manifest/commit/07806f185aee98519a44bcd952423ca3aea7316c))
* initialize TypeScript bindings, add MCP documentation, and implement contract testing suite ([8417359](https://github.com/CoReason-AI/coreason-manifest/commit/841735994f0d71e18c4bc583ab453230ebe7ab58))
* Intent Elicitation Airlock Macro-Topology ([#1387](https://github.com/CoReason-AI/coreason-manifest/issues/1387)) ([#1388](https://github.com/CoReason-AI/coreason-manifest/issues/1388)) ([53a5ee4](https://github.com/CoReason-AI/coreason-manifest/commit/53a5ee405e5ac52ee3e45198329f30edabd7abc9))
* introduce comprehensive documentation suite and enforce epistemic quarantine via mandatory legal directives across project files. ([a296689](https://github.com/CoReason-AI/coreason-manifest/commit/a296689447d9d4cb8bad70440fc81b3596836541))
* introduce core ontology definitions and data validation logic. ([1a054d0](https://github.com/CoReason-AI/coreason-manifest/commit/1a054d096ad5397123ee9f6a71bbac4134c342c5))
* Introduce new ontology specification with comprehensive contrac… ([b6ed02d](https://github.com/CoReason-AI/coreason-manifest/commit/b6ed02d2eac6f45c0a4674d1a8f9b09039859228))
* Introduce new ontology specification with comprehensive contract and fuzzing tests, along with supporting algebraic utilities and evaluation scripts. ([8588ee8](https://github.com/CoReason-AI/coreason-manifest/commit/8588ee8e9133401354815687bcd0f3e1e8924483))
* **manifest:** establish tripartite neurosymbolic schema boundaries and enforce topological serialization exemptions ([502a0e7](https://github.com/CoReason-AI/coreason-manifest/commit/502a0e7af10566199cc7ff76c29e49e5dd6abc31))
* Microscopic Epistemics & Dempster-Shafer Belief Vectors ([#1505](https://github.com/CoReason-AI/coreason-manifest/issues/1505)) ([268b9bf](https://github.com/CoReason-AI/coreason-manifest/commit/268b9bfb89c5c8ee2187c2313f8d3d0fac3c09be))
* **ontology:** Epic 2 - The Markov Transition Topology ([#1374](https://github.com/CoReason-AI/coreason-manifest/issues/1374)) ([c5251a6](https://github.com/CoReason-AI/coreason-manifest/commit/c5251a6b63c5f620d48cc25f75d113cbe240bca0))
* **ontology:** expand polymorphic state and intent unions with missing kinematic and exogenous triggers ([3de435f](https://github.com/CoReason-AI/coreason-manifest/commit/3de435f7c2b1e3f33a449cfbc84c15ff2345bacf))
* **ontology:** finalize Epic 3 Semantic Subtyping and Mapping Algebra ([69d59b0](https://github.com/CoReason-AI/coreason-manifest/commit/69d59b0da46097fb41945386ec7ab234bbf139d8))
* **ontology:** finalize Epic 3 Semantic Subtyping and Mapping Algebra ([69d59b0](https://github.com/CoReason-AI/coreason-manifest/commit/69d59b0da46097fb41945386ec7ab234bbf139d8))
* **ontology:** Implement Declarative Design-by-Contract via AST Quarantining ([9d3df0c](https://github.com/CoReason-AI/coreason-manifest/commit/9d3df0cc293b6974dfb1cd791c5d43ab0c0c64f2))
* **ontology:** implement Epic 1 Execution Envelope and State Determinism ([25b990e](https://github.com/CoReason-AI/coreason-manifest/commit/25b990e5a2358c36d5942ddf72e20789d821e882))
* **ontology:** implement Epic 4 Epistemic Ledger and Byzantine Consensus ([88837fc](https://github.com/CoReason-AI/coreason-manifest/commit/88837fc332b373c17ecc2f923c55be63ca0379ee))
* **ontology:** Implement Epic 5 - The Agentic Forge ([#1379](https://github.com/CoReason-AI/coreason-manifest/issues/1379)) ([d5dd587](https://github.com/CoReason-AI/coreason-manifest/commit/d5dd5872a194134a553673b268b39ad8c374132c))
* **ontology:** implement Epic 6 Oracle Interfaces and Reasoning Engineering ([2df7172](https://github.com/CoReason-AI/coreason-manifest/commit/2df717241974608ab39419400409096ced5fdfd2))
* **ontology:** implement Epic 6 Oracle Interfaces and Reasoning Engineering ([2df7172](https://github.com/CoReason-AI/coreason-manifest/commit/2df717241974608ab39419400409096ced5fdfd2))
* **ontology:** implement Epic 6 Oracle Interfaces and Reasoning Engineering ([6d975e9](https://github.com/CoReason-AI/coreason-manifest/commit/6d975e9590394d5a1b18d7158e82c1a72f1b0e00))
* **ontology:** implement Epic 6 Oracle Interfaces and Reasoning Engineering ([6d975e9](https://github.com/CoReason-AI/coreason-manifest/commit/6d975e9590394d5a1b18d7158e82c1a72f1b0e00))
* **ontology:** implement Epic 6 Oracle Interfaces and Reasoning Engineering ([1e8119a](https://github.com/CoReason-AI/coreason-manifest/commit/1e8119ad309171013b4aa06af59bbffb806d70d7))
* **ontology:** Implement Ontological Firewall Projection via Homotopic Proxy States ([ad3a422](https://github.com/CoReason-AI/coreason-manifest/commit/ad3a422900faee118271526cb1b5031b7af8ecab))
* **ontology:** Implement Ontological Firewall Projection via Homotopic Proxy States ([2fc8b1d](https://github.com/CoReason-AI/coreason-manifest/commit/2fc8b1d04748b614714bf6981534c60331786d37))
* **ontology:** Implement Runtime Substrate Hydration via Coalgebraic Thunking and Functorial Semantics ([e6994df](https://github.com/CoReason-AI/coreason-manifest/commit/e6994dfe5c9bd9f9bc4ba0c1f8a3519f84a6f0ff))
* **ontology:** Implement Runtime Substrate Hydration via Coalgebraic Thunking and Functorial Semantics ([5ce1d66](https://github.com/CoReason-AI/coreason-manifest/commit/5ce1d666c9692e4882dc307cc4e0f0c9fa3d8f75))
* **ontology:** Implement Runtime Substrate Hydration via Coalgebraic Thunking and Functorial Semantics ([151f733](https://github.com/CoReason-AI/coreason-manifest/commit/151f733f6f32eadd40b7b3cadb0253f4e7701cef))
* **ontology:** Implement Zero-Trust Topological Wiring via Operadic Mounting and Sheaf-Theoretic Grounding ([4a78314](https://github.com/CoReason-AI/coreason-manifest/commit/4a7831468b1b25ea3044c4576317164d461d86ac))
* **ontology:** Implement Zero-Trust Topological Wiring via Operadic Mounting and Sheaf-Theoretic Grounding ([#1558](https://github.com/CoReason-AI/coreason-manifest/issues/1558)) ([ea50b62](https://github.com/CoReason-AI/coreason-manifest/commit/ea50b629c588a534b673cdf9d34a6f44285bb746))
* **ontology:** remove deprecated proprietary chaos components ([#1721](https://github.com/CoReason-AI/coreason-manifest/issues/1721)) ([1f54db6](https://github.com/CoReason-AI/coreason-manifest/commit/1f54db6b2e024440678e3ac9f03ec6a69e7e3b3c))
* **ontology:** Support Non-Monotonic Logic, Continuous State Space, and Speculative Execution ([#1304](https://github.com/CoReason-AI/coreason-manifest/issues/1304)) ([fd0bde0](https://github.com/CoReason-AI/coreason-manifest/commit/fd0bde0e59397b783c5ec841fe0a87544cdcbb72))
* **ontology:** Upgrade constrained decoding for LMQL and Guidance ([#1301](https://github.com/CoReason-AI/coreason-manifest/issues/1301)) ([71baa8a](https://github.com/CoReason-AI/coreason-manifest/commit/71baa8a26e2407394b27cde4628be8826fbfc1b8))
* Phase 4 - Collaborative Infinite Canvas ([#1360](https://github.com/CoReason-AI/coreason-manifest/issues/1360)) ([4711ade](https://github.com/CoReason-AI/coreason-manifest/commit/4711ade40693120b4a4be0f513ceaf5012d0e7c3))
* Semantic to Symbolic Manifold Projection ([#1521](https://github.com/CoReason-AI/coreason-manifest/issues/1521)) ([7472dd8](https://github.com/CoReason-AI/coreason-manifest/commit/7472dd8a7f1d8578895720d4782309e65367b26d))
* SOTA 2026+ Crucible Refactor (EPIC 4.5) ([#1527](https://github.com/CoReason-AI/coreason-manifest/issues/1527)) ([b37a9b9](https://github.com/CoReason-AI/coreason-manifest/commit/b37a9b9925bd4a0737967bb4ff89f3579f1104be))
* Stochastic Ideation Topologies ([#1520](https://github.com/CoReason-AI/coreason-manifest/issues/1520)) ([2bc6754](https://github.com/CoReason-AI/coreason-manifest/commit/2bc67547e1e4450b1648c4bf6802acbb08ce8c70))
* Structural Macroscopics Implementation ([#1504](https://github.com/CoReason-AI/coreason-manifest/issues/1504)) ([df4d4d9](https://github.com/CoReason-AI/coreason-manifest/commit/df4d4d92f85969403729027bcc13d5e4190e27f5))


### Bug Fixes

* **ci:** regenerate Rust bindings for Drift Guillotine compliance ([#1679](https://github.com/CoReason-AI/coreason-manifest/issues/1679)) ([bc9eebd](https://github.com/CoReason-AI/coreason-manifest/commit/bc9eebdfd4d8e6044746518ca250daeafccf0654))
* eliminate IEEE 754 economic fractures and categorical type-algebra paradoxes across 5 classes ([2bf7ba9](https://github.com/CoReason-AI/coreason-manifest/commit/2bf7ba90bcde02ff4f87b4b45a62aeabd6822654))
* excise paradoxical le=1000000000 from strings, dicts, Literals, and nested model pointers across 5 classes ([73258a5](https://github.com/CoReason-AI/coreason-manifest/commit/73258a549310ad5b38e7f491adcfd74056a1d68f))
* format zensical.toml structure to support plugins and theme feat… ([294f165](https://github.com/CoReason-AI/coreason-manifest/commit/294f16527ea3bdc878f514fa6dc7227b7dcfb03b))
* format zensical.toml structure to support plugins and theme features ([#1224](https://github.com/CoReason-AI/coreason-manifest/issues/1224)) ([35e81a3](https://github.com/CoReason-AI/coreason-manifest/commit/35e81a3c068a38958cb8f74ff05d82de046ad908))
* **lint:** resolve SIM102 nested-if in scratch script ([f9b6965](https://github.com/CoReason-AI/coreason-manifest/commit/f9b69659976a3e24416f8cb41d9ba18d2b259b9e))
* **ontology:** excise prefix dilution and correct thermodynamic/geometric bounds ([6782034](https://github.com/CoReason-AI/coreason-manifest/commit/6782034c0d58abf15c1d619970abbedfc5b9c50f))
* **ontology:** resolve mypy non-overlapping equality check ([76dad05](https://github.com/CoReason-AI/coreason-manifest/commit/76dad05110291b2bcfccda1606b805c3bcf9806c))
* **ontology:** seal Exogenous Boundary with _validate_payload_bounds on 5 remaining unbounded schemas ([9db0c24](https://github.com/CoReason-AI/coreason-manifest/commit/9db0c2406a164308c57d0a800d18d9277c4a1949))
* Patch AST Immutability Lock and Inject Matrix Fuzzing Tripwires ([#1245](https://github.com/CoReason-AI/coreason-manifest/issues/1245)) ([21043ce](https://github.com/CoReason-AI/coreason-manifest/commit/21043cefbed4bf874df9bb5dcbfa822aa6da14e0))
* regenerate Rust bindings with cargo-typify 0.6.2 for CI alignment ([7ffc3bb](https://github.com/CoReason-AI/coreason-manifest/commit/7ffc3bb10e5adb5d52b3df52837617ea1c11f8b3))
* Remediate topological paradoxes and metadata in Zero-Cost Macros ([#1530](https://github.com/CoReason-AI/coreason-manifest/issues/1530)) ([75106c4](https://github.com/CoReason-AI/coreason-manifest/commit/75106c4c8ec16a3e70bc5ac0c36447a748466e5b))
* remove orphaned SteadyStateHypothesisState (chaos deprecation) ([b42dbec](https://github.com/CoReason-AI/coreason-manifest/commit/b42dbec45c03afe7576a2516d48f43d96ed8db2e))
* remove rustworkx from dev dependencies for python 3.14t compatibility ([8ae9725](https://github.com/CoReason-AI/coreason-manifest/commit/8ae9725d499f49bc8992be193c5c88a008810a68))
* remove unused mypy type-ignore on mcp_adapters (Python 3.14 compat) ([5e33849](https://github.com/CoReason-AI/coreason-manifest/commit/5e33849fb33e9db3051d4cd142176b99a9d4fab2))
* resolve topological reachability and missing schemas ([#1536](https://github.com/CoReason-AI/coreason-manifest/issues/1536)) ([e381b40](https://github.com/CoReason-AI/coreason-manifest/commit/e381b40facc4a9003fb7e466fe5332d3a4306bb3))
* seal Hollow Data Plane — enforce O(N) volumetric guillotine on 7 final RPC ingress ports ([3c8459d](https://github.com/CoReason-AI/coreason-manifest/commit/3c8459dfdf79af72fc2b0141b6667e79e83886da))
* **security:** resolve TruffleHog base/head identical mismatch in security.yml ([c6833db](https://github.com/CoReason-AI/coreason-manifest/commit/c6833db1c84215e9ee2b1c037c3cdd90f0d51582))
* supply NODE_AUTH_TOKEN for npm publish and set publishConfig.access ([cf89e72](https://github.com/CoReason-AI/coreason-manifest/commit/cf89e72aefb9016b9aef1e5498373c498db184b0))
* wire EpistemicRigidityPolicy into ontology graph and enforce canonical sorting ([147c514](https://github.com/CoReason-AI/coreason-manifest/commit/147c51406ac6b179de51c65a5e079bae9febb43d))


### Refactoring

* CoReason ontology alignment, ID to CID migration, and algebraic refactors ([#1463](https://github.com/CoReason-AI/coreason-manifest/issues/1463)) ([413be1a](https://github.com/CoReason-AI/coreason-manifest/commit/413be1abafafaf93e5a5d5c33bdff6ef2b711cb4))
* execute lexical architecture and suffix compliance corrections ([#1494](https://github.com/CoReason-AI/coreason-manifest/issues/1494)) ([e3f684e](https://github.com/CoReason-AI/coreason-manifest/commit/e3f684e8fb5efe5da51694ecd6a227ea0c05f98a))
* Neurosymbolic Greenfield Refactor & Dead Code Elimination ([#1227](https://github.com/CoReason-AI/coreason-manifest/issues/1227)) ([bdc8dea](https://github.com/CoReason-AI/coreason-manifest/commit/bdc8deadf25a5f786090cbe5c131e3d8b319b9a8))
* neutralize JSON bomb volume paradox, collapse SSRF to C-backed ipaddress, expand kinetic hooks to 4-part Semantic Gravity Wells ([c2ff50f](https://github.com/CoReason-AI/coreason-manifest/commit/c2ff50f50656848405ba4b66cc51b74036884a46))
* **ontology:** algorithmic complexity unbinding - replace Literal Big-O with algebraic regex ([49325a5](https://github.com/CoReason-AI/coreason-manifest/commit/49325a5925aec9725bcf9af6bd5265a0a9f2507a))
* **ontology:** cybernetic governance decoupling - remove hardcoded PPL_3_0_COMPLIANCE binding ([a6d2c74](https://github.com/CoReason-AI/coreason-manifest/commit/a6d2c749e174594c1076843b04741ff009f5ec89))
* **ontology:** Epic 10 - The Optical Physics Purge ([38285e0](https://github.com/CoReason-AI/coreason-manifest/commit/38285e04cc8f8eaafe610af405a5b73d116af6c6))
* **ontology:** Epic 9 - Algorithmic Iteration Unbinding to UAB ([cd5882d](https://github.com/CoReason-AI/coreason-manifest/commit/cd5882d7e1111d27039664b3f6de590d5dc1516a))
* **ontology:** migrate to TransformerLens hook points ([4e207d7](https://github.com/CoReason-AI/coreason-manifest/commit/4e207d708ba2ab71ec4f838a8e990196481b9f0e))
* **ontology:** protocol & security purge - strip SSRF, CRLF, XSS from data plane ([f9b6965](https://github.com/CoReason-AI/coreason-manifest/commit/f9b69659976a3e24416f8cb41d9ba18d2b259b9e))
* **ontology:** silicon purge - replace ephemeral hardware enums with URN pattern ([1a0099b](https://github.com/CoReason-AI/coreason-manifest/commit/1a0099b9b242d94fa13ea089e5e4fa4f80497050))
* **ontology:** silicon purge phase II - eradicate remaining Literal enums ([7fe2a64](https://github.com/CoReason-AI/coreason-manifest/commit/7fe2a64c237cb92b95b0db19c65beddca8048124))
* **ontology:** topological isomorphism - collapse fragmented logic classes into unified categorical abstractions ([c8d5cd2](https://github.com/CoReason-AI/coreason-manifest/commit/c8d5cd2fc79131b6ef8aa460fde368f8893a3ce5))
* **ontology:** universal ontological grounding - inject formal URN schema anchors ([5584444](https://github.com/CoReason-AI/coreason-manifest/commit/5584444c7900a3588887b7358c81367f7b97b28e))
* purge legacy tracing artifacts and stabilize ontology ([2f55544](https://github.com/CoReason-AI/coreason-manifest/commit/2f555442abc267e77e8c667c4f5753262d6eb0f2))
* remove deprecated SpanKindProfile ([ed75ab7](https://github.com/CoReason-AI/coreason-manifest/commit/ed75ab7a7e22f4d54b980c316aa0c90fea4e6c82))
* remove unused files and associated references ([6f837fe](https://github.com/CoReason-AI/coreason-manifest/commit/6f837fe80a01faf3c9874bc351630a46edf02420))
* rename ID fields to CID across ontology schema and regenerate language bindings ([0661f1e](https://github.com/CoReason-AI/coreason-manifest/commit/0661f1e3c14162a9d1996b012c7b9585b0e27b2b))
* reorder OntologicalCrosswalkIntent within the oneOf schema definition ([b735d4e](https://github.com/CoReason-AI/coreason-manifest/commit/b735d4e5365258f5cbec69bb8b53dcc6867dfeda))
* reorder OntologicalCrosswalkIntent within the oneOf schema definition ([b735d4e](https://github.com/CoReason-AI/coreason-manifest/commit/b735d4e5365258f5cbec69bb8b53dcc6867dfeda))
* Reordered properties in `ActionSpaceManifest`, `RepresentationEngineeringContract`, `ActiveInferenceContract`, and `ForcedAdjudicationIntent` for improved schema readability. ([b242775](https://github.com/CoReason-AI/coreason-manifest/commit/b242775438dca47ef3fecb2ef72e713ba01c4c92))
* The God Context Refactor (Epic 3) ([#1246](https://github.com/CoReason-AI/coreason-manifest/issues/1246)) ([09e785e](https://github.com/CoReason-AI/coreason-manifest/commit/09e785e1d64c1f2452b1774ecade3acfbf7a75fe))


### Performance

* **ontology:** eliminate redundant _sort_collections recursive dictionary sort ([#1323](https://github.com/CoReason-AI/coreason-manifest/issues/1323)) ([1abc59f](https://github.com/CoReason-AI/coreason-manifest/commit/1abc59f861fad5f5fa739de8deebb357667ce571))
* replace canonicaljson with msgspec for deterministic serialization ([#1666](https://github.com/CoReason-AI/coreason-manifest/issues/1666)) ([5c17c04](https://github.com/CoReason-AI/coreason-manifest/commit/5c17c044388d64c13d61b377639659f7e4db686f))


### Documentation

* Add Epistemic Boundary Mandate guidelines for anti-hallucination and anti-bombing, detailing strict primitive bounding with `Literal` and `StringConstraints`. ([1f441ac](https://github.com/CoReason-AI/coreason-manifest/commit/1f441ac2c99137e06ced974a90deffebcc6b2008))
* add strict instantiation boundary and anti-lazy validation mandate guidelines ([b6680d9](https://github.com/CoReason-AI/coreason-manifest/commit/b6680d998ec639e5c524ef3fc95e0c70e006ae9b))
* **agents:** enforce zensical for documentation builds ([#1222](https://github.com/CoReason-AI/coreason-manifest/issues/1222)) ([9ba5b18](https://github.com/CoReason-AI/coreason-manifest/commit/9ba5b18334507d27e3b3b6a324fc4260b1dff897))
* **agents:** enforce zensical for documentation builds ([#1222](https://github.com/CoReason-AI/coreason-manifest/issues/1222)) ([ac96197](https://github.com/CoReason-AI/coreason-manifest/commit/ac96197cbe8ea6df9bcf902d1c3be3c3d20f6ffb))
* audit and remove placeholder and developer thought comments ([#1](https://github.com/CoReason-AI/coreason-manifest/issues/1)… ([81d3f4a](https://github.com/CoReason-AI/coreason-manifest/commit/81d3f4a873ef9b158f247ace03f7ecb23851da94))
* audit and remove placeholder and developer thought comments ([#1682](https://github.com/CoReason-AI/coreason-manifest/issues/1682)) ([780e7b7](https://github.com/CoReason-AI/coreason-manifest/commit/780e7b7c962aaf4aedc9f6eef8885e5ae16580a3))
* clarify neurosymbolic architecture definitions and implement strict ontological firewall protocols in AGENTS.md ([302b555](https://github.com/CoReason-AI/coreason-manifest/commit/302b555f0057742944b7be79e49df8da0b04306e))
* **manifest:** align swarm epistemology with neurosymbolic triad and enforce zero-trust documentation boundaries ([f8dfd29](https://github.com/CoReason-AI/coreason-manifest/commit/f8dfd294e144f9c580683be8e13953b18e054a55))
* **manifest:** align swarm epistemology with neurosymbolic triad and enforce zero-trust documentation boundaries ([#1588](https://github.com/CoReason-AI/coreason-manifest/issues/1588)) ([cc1e7c7](https://github.com/CoReason-AI/coreason-manifest/commit/cc1e7c7c1c00650de0ffd7e1baf16f1246251fc1))
* **manifest:** align swarm epistemology with neurosymbolic triad and… ([fb57798](https://github.com/CoReason-AI/coreason-manifest/commit/fb57798f320777589684518880c2dec185e9d14a))
* resolve epic 3 semantic gravity wells in ontology.py ([#1490](https://github.com/CoReason-AI/coreason-manifest/issues/1490)) ([422089c](https://github.com/CoReason-AI/coreason-manifest/commit/422089c9b850b814718a3e06092dc6f08f5b1187))
* update AGENTS.md with substrate hydration, type isomorphism, and cryptographic determinism enforcement requirements ([0012065](https://github.com/CoReason-AI/coreason-manifest/commit/0012065d1fb31d8f3ce03c589b143e84016af60b))
* update Codecov link, Conventional Commits reference, and Sigstore URLs ([de49f91](https://github.com/CoReason-AI/coreason-manifest/commit/de49f912b867737f02c13ce971192fecd8ee9baa))


### CI/CD

* add CI and release workflows with comprehensive security, testing, and provenance checks ([e3fcc70](https://github.com/CoReason-AI/coreason-manifest/commit/e3fcc7022a7e9c200eda094ea7ee861af2bf9b10))
* exempt free-threaded 3.14t from coverage fail-under threshold ([1822a1b](https://github.com/CoReason-AI/coreason-manifest/commit/1822a1b984d49e97d00d2109d94554833b06b07d))
* extend 3.14t coverage exemption to test-extended matrix job ([6519a4a](https://github.com/CoReason-AI/coreason-manifest/commit/6519a4af293ebbf9f2786de4020b40c770184c68))
* update GitHub Actions to support Node.js 24 and resolve deprecation warnings ([#1302](https://github.com/CoReason-AI/coreason-manifest/issues/1302)) ([5ae4816](https://github.com/CoReason-AI/coreason-manifest/commit/5ae481652d38693e35183b2eff56c68c7033f653))
* verify topological integrity in publish workflow ([#1538](https://github.com/CoReason-AI/coreason-manifest/issues/1538)) ([216438c](https://github.com/CoReason-AI/coreason-manifest/commit/216438ccc12a9000a4444d6459af699826972812))


### Tests

* add comprehensive contract validation tests for the ontology specification. ([1e71585](https://github.com/CoReason-AI/coreason-manifest/commit/1e71585fba229463ed67e55e3e6650f2f4dbacdf))
* Add comprehensive coverage for algebra utility functions including manifest projection, state differentials, and semantic alignment. ([2326370](https://github.com/CoReason-AI/coreason-manifest/commit/23263701aca569ea618f8340086bf379d335adf9))
* add comprehensive property-based and contract-based test suites for algebraic operations and mathematical bounds validation ([8ede9d6](https://github.com/CoReason-AI/coreason-manifest/commit/8ede9d6666be41058d7542e0f5a71e64f83f9b2d))
* add comprehensive property-based and contract-based test suites for algebraic operations and mathematical bounds validation. ([dceec04](https://github.com/CoReason-AI/coreason-manifest/commit/dceec040294963e53084eb895864e134a0691cf9))
* add comprehensive property-based and unit tests for core algebra utilities ([42a3a9b](https://github.com/CoReason-AI/coreason-manifest/commit/42a3a9bfc5194e0a423e66ce445c73bbc30d37ff))
* Add comprehensive test suite for `algebra` utility functions, covering manifest projection, semantic alignment, state differentials, and schema validation. ([59d8048](https://github.com/CoReason-AI/coreason-manifest/commit/59d8048bffe33278a1ecd940c5a85f59cd3ce246))
* Add comprehensive unit and property-based tests for manifest algebra utility functions. ([7f14151](https://github.com/CoReason-AI/coreason-manifest/commit/7f141510a8db1e5807cbb1071af452848d0c4c57))
* add comprehensive unit tests for algebra utilities and ontology manifest components. ([c444bef](https://github.com/CoReason-AI/coreason-manifest/commit/c444befea702054ed36f995f04ee98dee5f432a0))
* add fuzzing for instantiation bounds ([#1244](https://github.com/CoReason-AI/coreason-manifest/issues/1244)) ([00b2d8f](https://github.com/CoReason-AI/coreason-manifest/commit/00b2d8fa7aa05bf251d5c3e16b1e381335e46fd8))
* add hypothesis property tests for base state validation, canonicalization, and hashing logic ([4b5d9c2](https://github.com/CoReason-AI/coreason-manifest/commit/4b5d9c2eff880096d85e5a142ccf018ad0bc9c24))
* add Hypothesis-based property tests and manual validation debug suites for ontological models ([08f568f](https://github.com/CoReason-AI/coreason-manifest/commit/08f568fdf4267a9441e472d73e739ea10aca15b3))
* add Hypothesis-based property tests and manual validation debug… ([efd51b7](https://github.com/CoReason-AI/coreason-manifest/commit/efd51b7f0aba4e3936b6dc2dc6f068b43edd79d5))
* add introspective canonical sort determinism and temporal CRDT contract tests ([697bf6e](https://github.com/CoReason-AI/coreason-manifest/commit/697bf6e2c5271ae6f0f85ba9b8fbdebc571341e2))
* add property-based validation tests for ontology hypothesis bounds and mathematical constraints ([02611cb](https://github.com/CoReason-AI/coreason-manifest/commit/02611cb87c2bbc4dea47d95b257b82bc13c6eea6))
* add unit tests for manifest macros and adversarial simulation profile fuzzing ([f5b6c52](https://github.com/CoReason-AI/coreason-manifest/commit/f5b6c52139d593e761acbd2319d928020f6d7220))
* add validation contract tests for MultimodalTokenAnchorState temporal and token spans ([69059f8](https://github.com/CoReason-AI/coreason-manifest/commit/69059f8d47e8fe666f6624086d1e1889e7541e45))
* fix class names and remove legacy utility tests ([86b07e9](https://github.com/CoReason-AI/coreason-manifest/commit/86b07e98bcc396bade76732d540f84fa71ac1da7))
* **ontology:** remove deprecated ExecutionNodeReceipt from manual validators ([9b2ffcd](https://github.com/CoReason-AI/coreason-manifest/commit/9b2ffcd3d8d7e171217c0066617fbce3ff2a9d4c))
* **topology:** expand reachability evaluation root set with orchestrator exemptions ([1c35181](https://github.com/CoReason-AI/coreason-manifest/commit/1c351816783a989033ffc00da3eb82c48cbecb4d))
