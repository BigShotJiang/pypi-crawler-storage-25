# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import os
from typing import Any, cast

import httpx
from coreason_manifest import (
    MCPPromptReferenceState,
    MCPResourceManifest,
)

from coreason_runtime.utils.exceptions import ManifestConformanceError
from coreason_runtime.utils.logger import logger


class MasterGatewayClient:
    """Master Gateway API client acting as the unified Master MCP.

    This client communicates with the coreason-master-gateway, which handles
    all perimeter security, mTLS certificates, and epistemic filtering.
    """

    def __init__(
        self,
        gateway_url: str | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        # Explicitly handling None case from os.getenv to satisfy Mypy union-attr requirements
        base_url = gateway_url or os.getenv("COREASON_MASTER_GATEWAY_URL") or "http://coreason-master-gateway:8000"
        self.gateway_url = base_url.rstrip("/")
        self.transport = transport
        self._client: httpx.AsyncClient | None = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            ca_bundle = os.getenv("COREASON_CA_BUNDLE")
            verify_param: bool | str = ca_bundle or True

            client_kwargs: dict[str, Any] = {
                "verify": verify_param,
                "limits": httpx.Limits(max_keepalive_connections=20, max_connections=100),
                "timeout": httpx.Timeout(30.0, read=None),
            }
            if self.transport:
                client_kwargs["transport"] = self.transport

            self._client = httpx.AsyncClient(**client_kwargs)
        return self._client

    async def close(self) -> None:
        """Close the underlying HTTP client pool."""
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()

    async def __aenter__(self) -> "MasterGatewayClient":
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.close()

    async def _post_payload(self, server_cid: str, endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Dispatch message exclusively to Master Gateway API over secured connection."""
        import asyncio

        url = f"{self.gateway_url}/mcp/{server_cid}/{endpoint}"

        max_attempts = 1 if os.getenv("COREASON_TESTING") == "1" else 10
        backoff = 0.5
        attempt = 0

        client = self._get_client()

        while True:
            attempt += 1
            try:
                response = await client.post(url, json=payload)
                response.raise_for_status()
                result: dict[str, Any] = response.json()
                return result
            except (httpx.ConnectError, httpx.ConnectTimeout, httpx.ReadTimeout) as e:
                if attempt >= max_attempts:
                    logger.error(f"Failed to communicate with Master Gateway after {max_attempts} attempts: {e}")
                    raise Exception(f"Gateway communication failure: {e}") from e
                logger.warning(f"Gateway connection/timeout error on attempt {attempt}: {e}. Retrying in {backoff}s...")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2.0, 10.0)
            except httpx.HTTPStatusError as e:
                if e.response.status_code in (401, 403, 406, 422):
                    logger.warning(
                        f"Guardrail violation captured natively: {e.response.text}",
                        extra={
                            "internal_telemetry": False,
                            "event_type": "GuardrailViolationEvent",
                            "endpoint": endpoint,
                            "status_code": e.response.status_code,
                        },
                    )
                    from coreason_runtime.utils.tracing import get_tracer

                    tracer = get_tracer("coreason-runtime.gateway_bridge")
                    with tracer.start_as_current_span("guardrail_violation") as span:
                        span.set_attribute("coreason.violation", True)
                        span.set_attribute("coreason.status_code", e.response.status_code)
                        span.set_attribute("coreason.endpoint", endpoint)
                        span.set_attribute("coreason.response_text", e.response.text)

                logger.error(f"Gateway returned HTTP error: {e.response.status_code} - {e.response.text}")
                if e.response.status_code == 500:
                    raise Exception(f"Gateway internal server error: {e}") from e
                raise ManifestConformanceError(f"Gateway HTTP error: {e}") from e
            except Exception as e:
                logger.error(f"Failed to communicate with Master Gateway: {e}")
                raise Exception(f"Gateway communication failure: {e}") from e

    async def hydrate_prompt(self, prompt_state: MCPPromptReferenceState) -> dict[str, Any]:
        """Fetch a remote prompt from Master Gateway."""
        payload = {
            "name": prompt_state.prompt_name,
            "arguments": prompt_state.arguments,
        }
        return await self._post_payload(prompt_state.server_cid, "prompts/get", payload)

    async def read_resource(self, resource_manifest: MCPResourceManifest) -> dict[str, Any]:
        """Read remote resources from Master Gateway."""
        results = []
        for uri in resource_manifest.uris:
            payload = {"uri": str(uri)}
            resp = await self._post_payload(resource_manifest.server_cid, "resources/read", payload)
            results.append(resp)
        return {"resources": results}

    async def call_tool(self, server_cid: str, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """Execute a remote capability via Master Gateway."""
        payload = {
            "name": name,
            "arguments": arguments,
        }
        return await self._post_payload(server_cid, "tools/call", payload)

    async def request(self, server_cid: str, method: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """Generic request to a specific server CID via Master Gateway."""
        return await self._post_payload(server_cid, method, arguments)

    async def list_tools(self, server_cid: str) -> list[dict[str, Any]]:
        """List tools for a specific server CID via Master Gateway."""
        resp = await self._post_payload(server_cid, "tools/list", {})
        tools = resp.get("tools", [])
        return cast("list[dict[str, Any]]", tools)

    async def discover_servers(self) -> list[str]:
        """Discover available MCP servers via the federated_discovery tool."""
        # The gateway itself is usually 'coreason-master-gateway' or similar
        # We call the federated_discovery tool on it.
        try:
            resp = await self.call_tool("coreason-master-gateway", "federated_discovery", {"domain_filter": []})
            # Gateway might return the result wrapped in 'content'
            content = resp.get("content", resp)
            if isinstance(content, str):
                import json

                data = json.loads(content)
            else:
                data = content

            capabilities = data.get("capabilities", [])
            return [cap["urn"] for cap in capabilities if "urn" in cap]
        except Exception as e:
            logger.warning(f"Failed to discover servers via Master Gateway: {e}")
            return []

    def get_client(self, server_cid: str) -> "_MCPClientShim":
        """Shim to return a client-like object for a specific server."""
        return _MCPClientShim(self, server_cid)


class _MCPClientShim:
    """Internal shim to provide a request() method for a specific server."""

    def __init__(self, bridge: MasterGatewayClient, server_cid: str):
        self.bridge = bridge
        self.server_cid = server_cid

    async def request(self, method: str, arguments: dict[str, Any] | None = None) -> dict[str, Any]:
        return await self.bridge.request(self.server_cid, method, arguments or {})
