# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>
"""
coreason-runtime: The Tier-1 Kinetic Execution Engine.

This package provides the deterministic execution substrate for CoReason agentic topologies.
It implements durable orchestration via Temporal, zero-trust tool sandboxing via WebAssembly,
and high-velocity telemetry ingestion using Polars and LanceDB.

Part of the CoReason Tripartite Cybernetic Manifold.
"""

import importlib.metadata

try:
    __version__ = importlib.metadata.version("coreason_runtime")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.75.4"

__author__ = "Gowtham A Rao"
__email__ = "gowtham.rao@coreason.ai"
