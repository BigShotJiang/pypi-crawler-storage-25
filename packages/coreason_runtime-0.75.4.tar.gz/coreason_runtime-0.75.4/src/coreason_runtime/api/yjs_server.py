# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import logging
import os

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, status
from fastapi.middleware.cors import CORSMiddleware

logger = logging.getLogger("yjs_server")

ws_app = FastAPI(title="Yjs CRDT Collaborative Synchronization Server")

# Parse allowed origins from environment variable
ALLOWED_ORIGINS_ENV = os.getenv("ALLOWED_ORIGINS", "*")
ALLOWED_ORIGINS = [origin.strip() for origin in ALLOWED_ORIGINS_ENV.split(",") if origin.strip()]

# Enable CORS middleware
ws_app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Map from room name -> set of active WebSockets
rooms: dict[str, set[WebSocket]] = {}


@ws_app.websocket("/{room_name}")
async def websocket_endpoint(websocket: WebSocket, room_name: str) -> None:
    origin = websocket.headers.get("origin")

    # CSWSH protection: Validate the WebSocket origin header
    if "*" not in ALLOWED_ORIGINS and (not origin or origin not in ALLOWED_ORIGINS):
        logger.warning(
            f"Rejected WebSocket connection to room '{room_name}' "
            f"from unauthorized origin: {origin}. "
            f"Allowed origins: {ALLOWED_ORIGINS_ENV}"
        )
        # Close with 1008 (Policy Violation) code before accepting
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return

    await websocket.accept()
    if room_name not in rooms:
        rooms[room_name] = set()
    rooms[room_name].add(websocket)
    logger.info(f"Client connected to Yjs room: {room_name}. Total clients: {len(rooms[room_name])}")
    try:
        while True:
            # Handle binary and text frames
            message = await websocket.receive()
            msg_type = message.get("type", "")

            # Break cleanly on disconnect instead of re-entering receive()
            if msg_type == "websocket.disconnect":
                break

            if "bytes" in message:
                data = message["bytes"]
                # Broadcast bytes to all other clients in the same room
                disconnected: set[WebSocket] = set()
                for client in list(rooms[room_name]):
                    if client != websocket:
                        try:
                            await client.send_bytes(data)
                        except WebSocketDisconnect, RuntimeError:
                            disconnected.add(client)
                rooms[room_name] -= disconnected
            elif "text" in message:
                data = message["text"]
                # Broadcast text to all other clients in the same room
                disconnected = set()
                for client in list(rooms[room_name]):
                    if client != websocket:
                        try:
                            await client.send_text(data)
                        except WebSocketDisconnect, RuntimeError:
                            disconnected.add(client)
                rooms[room_name] -= disconnected
    except WebSocketDisconnect:
        logger.info(f"Client disconnected from Yjs room: {room_name}")
    except Exception as e:
        logger.error(f"WebSocket error in Yjs room '{room_name}': {e}")
    finally:
        if room_name in rooms:
            rooms[room_name].discard(websocket)
            if not rooms[room_name]:
                del rooms[room_name]
