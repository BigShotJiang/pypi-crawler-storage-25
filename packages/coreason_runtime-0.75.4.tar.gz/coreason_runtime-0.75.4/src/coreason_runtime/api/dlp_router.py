# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""DLP Egress Alarm Router — Glass Box Air-Gap & DLP Particle Shields (#373).

Provides:
- GET /api/v1/telemetry/egress-blocks — query historical blocked egress events
- EgressClassifier — pattern scanner for sensitive data in outbound payloads
"""

from __future__ import annotations

import hashlib
import re
import time
from collections import deque
from typing import Any

from fastapi import APIRouter, Query
from pydantic import BaseModel, Field

from coreason_runtime.utils.logger import logger

dlp_router = APIRouter(prefix="/api/v1/telemetry", tags=["DLP Egress Telemetry"])


# ────────────────────────────────────────────────────────────────────
# Pydantic Models
# ────────────────────────────────────────────────────────────────────


class EgressEvent(BaseModel):
    egress_id: str = Field(..., alias="egressId")
    originating_agent_urn: str = Field(..., alias="originatingAgentUrn")
    destination_label: str = Field(..., alias="destinationLabel")
    payload_size_bytes: int = Field(..., alias="payloadSizeBytes")
    classification_outcome: str = Field(..., alias="classificationOutcome")
    blocked_data_pattern: str | None = Field(None, alias="blockedDataPattern")
    timestamp: str

    class Config:
        populate_by_name = True


class EgressBlocksResponse(BaseModel):
    blocks: list[EgressEvent]
    total_blocked_count: int = Field(..., alias="totalBlockedCount")

    class Config:
        populate_by_name = True


# ────────────────────────────────────────────────────────────────────
# Egress Classifier
# ────────────────────────────────────────────────────────────────────

# Sensitive data patterns (compiled once at module level)
_SENSITIVE_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"-----BEGIN\s+.*PRIVATE\s+KEY-----"), "Private Key Material"),
    (re.compile(r"-----BEGIN\s+CERTIFICATE-----"), "SPIFFE-SVID Certificate"),
    (re.compile(r"AKIA[0-9A-Z]{16}"), "AWS Access Key ID"),
    (re.compile(r"spiffe://[^\s]+/sa/[^\s]+"), "SPIFFE Service Account Identity"),
    (re.compile(r"eyJ[a-zA-Z0-9_-]{20,}\.eyJ[a-zA-Z0-9_-]{20,}"), "JWT Token"),
]


class EgressClassifier:
    """Pattern scanner for sensitive data in outbound payloads.

    Fail-closed: any classifier error defaults to BLOCKED.
    """

    _MAX_HISTORY = 1000

    def __init__(self) -> None:
        self._blocked_events: deque[EgressEvent] = deque(maxlen=self._MAX_HISTORY)
        self._total_blocked: int = 0

    def classify_egress(
        self,
        payload: bytes,
        agent_urn: str,
        destination: str,
    ) -> EgressEvent:
        """Classify an outbound payload for sensitive data leaks.

        Returns an EgressEvent with classificationOutcome NOMINAL or BLOCKED.
        Fail-closed: classifier errors result in BLOCKED.
        """
        egress_id = f"egress_{hashlib.sha256(payload[:64] + agent_urn.encode()).hexdigest()[:12]}"
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        try:
            payload_str = payload.decode("utf-8", errors="replace")

            for pattern, label in _SENSITIVE_PATTERNS:
                if pattern.search(payload_str):
                    event = EgressEvent(
                        egress_id=egress_id,
                        originating_agent_urn=agent_urn,
                        destination_label=destination,
                        payload_size_bytes=len(payload),
                        classification_outcome="BLOCKED",
                        blocked_data_pattern=label,
                        timestamp=ts,
                    )
                    self._blocked_events.append(event)
                    self._total_blocked += 1
                    logger.warning(f"DLP BLOCKED egress from {agent_urn} to {destination}: {label}")
                    return event

            return EgressEvent(
                egress_id=egress_id,
                originating_agent_urn=agent_urn,
                destination_label=destination,
                payload_size_bytes=len(payload),
                classification_outcome="NOMINAL",
                blocked_data_pattern=None,
                timestamp=ts,
            )
        except Exception as e:
            # Fail-closed: any error defaults to BLOCKED
            logger.error(f"DLP classifier error (fail-closed BLOCKED): {e}")
            event = EgressEvent(
                egress_id=egress_id,
                originating_agent_urn=agent_urn,
                destination_label=destination,
                payload_size_bytes=len(payload),
                classification_outcome="BLOCKED",
                blocked_data_pattern="Classifier Error (fail-closed)",
                timestamp=ts,
            )
            self._blocked_events.append(event)
            self._total_blocked += 1
            return event

    def get_blocked_events(
        self,
        agent_urn: str | None = None,
        limit: int = 50,
    ) -> tuple[list[EgressEvent], int]:
        """Return historical blocked events, optionally filtered by agent URN."""
        events = list(self._blocked_events)
        if agent_urn:
            events = [e for e in events if e.originating_agent_urn == agent_urn]
        return events[-limit:], self._total_blocked


# Module-level singleton
_classifier = EgressClassifier()


def get_classifier() -> EgressClassifier:
    """Return the module-level classifier singleton."""
    return _classifier


# ────────────────────────────────────────────────────────────────────
# Endpoint
# ────────────────────────────────────────────────────────────────────


@dlp_router.get("/egress-blocks", response_model=EgressBlocksResponse)
async def query_egress_blocks(
    agent_urn: str | None = Query(None, alias="agentUrn"),
    limit: int = Query(50, ge=1, le=500),
) -> Any:
    """Query historical blocked egress events."""
    blocks, total = _classifier.get_blocked_events(agent_urn=agent_urn, limit=limit)
    return EgressBlocksResponse(blocks=blocks, total_blocked_count=total)
