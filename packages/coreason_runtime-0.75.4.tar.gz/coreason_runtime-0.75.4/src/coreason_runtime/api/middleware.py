# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import httpx
from coreason_manifest.spec.ontology import IdentityContextProxy
from joserfc import jwt
from joserfc.jwk import KeySet
from joserfc.jwt import JWTClaimsRegistry
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Receive, Scope, Send

from coreason_runtime.utils.logger import logger

OPA_URL = "http://localhost:8181/v1/data/coreason/authz/allow"


class EnterpriseIdentityMiddleware:
    """
    ASGI Middleware for the Epistemic Firewall.
    Validates OIDC JWTs and enforces Zero-Trust via Open Policy Agent (OPA).

    This fulfills Phase 2 of the Enterprise-Grade BYOO implementation plan by physically
    decoupling the identity provider from the application logic and delegating
    authorization to an external OPA sidecar.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._jwks: Any = None
        self._client: httpx.AsyncClient | None = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient()
        return self._client

    async def get_jwks(self) -> Any:
        if self._jwks is None:
            client = self._get_client()
            jwks_response = await client.get("http://localhost:8000/.well-known/jwks.json")
            self._jwks = KeySet.import_key_set(jwks_response.json())
        return self._jwks

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] not in ["http", "websocket"]:
            await self.app(scope, receive, send)
            return

        request = Request(scope, receive=receive)

        protected_routes = ["/api/v1/oracle/resume", "/api/v1/temporal/retract"]
        if not any(request.url.path.startswith(route) for route in protected_routes):
            await self.app(scope, receive, send)
            return

        auth_header = request.headers.get("Authorization")

        if not auth_header or not auth_header.startswith("Bearer "):
            response = JSONResponse(
                {"error": "ManifestViolationReceipt", "details": "Missing or invalid Authorization header"},
                status_code=401,
            )
            await response(scope, receive, send)
            return

        # 1. JWT Validation (Decoupled Identity)
        # Validates the JWT signature against the IdP's JWKS endpoint.
        try:
            token = auth_header.split(" ")[1]
            jwks = await self.get_jwks()

            token_obj = jwt.decode(token, jwks)
            JWTClaimsRegistry().validate(token_obj.claims)
            claims = token_obj.claims

            execution_taint = claims.get("execution_taint", "spiffe://coreason.ai/ns/default/sa/admin")

            # Construct the mathematically bound IdentityContextProxy
            identity = IdentityContextProxy(jwt_payload=dict(claims), execution_taint=execution_taint)
            scope["coreason_identity"] = identity
        except Exception as e:
            logger.error(f"JWT Validation Failed: {e}")
            response = JSONResponse(
                {"error": "ManifestViolationReceipt", "details": "JWT Validation Failed"}, status_code=401
            )
            await response(scope, receive, send)
            return

        # 2. Open Policy Agent (OPA) Authorization
        # Performs a fast HTTP call to the local OPA sidecar.
        try:
            client = self._get_client()
            opa_response = await client.post(
                OPA_URL,
                json={
                    "input": {
                        "jwt": claims,
                        "method": request.method,
                        "path": request.url.path,
                        "taint": execution_taint,
                    }
                },
                timeout=2.0,
            )
            opa_result = opa_response.json()
            if not opa_result.get("result", False):
                raise ValueError("OPA Denied Access")
        except Exception as e:
            logger.warning(f"Authorization Failed via OPA: {e}")
            response = JSONResponse(
                {"error": "ManifestViolationReceipt", "details": "Access Denied by Open Policy Agent (OPA)"},
                status_code=403,
            )
            await response(scope, receive, send)
            return

        # 3. Passed Epistemic Firewall, continue execution
        await self.app(scope, receive, send)
