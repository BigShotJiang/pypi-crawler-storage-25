# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
Auth Router — Sandbox Caging Attestation Server-Sent Events stream.
"""

from __future__ import annotations

import asyncio
import json
import random
import time
from collections.abc import AsyncGenerator

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

auth_router = APIRouter(prefix="/api/v1/auth", tags=["Auth & Caging Verifications"])


class AttestationReceipt(BaseModel):
    transaction_id: str = Field(..., alias="transactionId")
    proof_status: str = Field(..., alias="proofStatus")
    originating_agent_urn: str = Field(..., alias="originatingAgentUrn")
    verification_timestamp: str = Field(..., alias="verificationTimestamp")
    zk_proof_hash: str = Field(..., alias="zkProofHash")
    sd_jwt_compliance: bool = Field(..., alias="sdJwtCompliance")

    class Config:
        populate_by_name = True


@auth_router.get("/verifications")
async def get_caging_verifications(request: Request) -> StreamingResponse:
    """
    Server-Sent Events (SSE) stream broadcasting real-time sandbox caging proof attestation receipts.
    """

    async def event_generator() -> AsyncGenerator[str]:
        d_pfx = "data: "

        # Initial connection message
        yield f'{d_pfx}{{"status": "connected"}}\n\n'
        await asyncio.sleep(1.0)

        sys_random = random.SystemRandom()
        while not await request.is_disconnected():
            statuses = ["VALIDATED", "FORGED", "INVALID"]
            next_status = sys_random.choice(statuses)
            is_compliant = next_status == "VALIDATED"
            random_tx = f"tx_sol_{sys_random.randint(100000, 999999)}"
            random_hash = "0x" + "".join(sys_random.choices("0123456789abcdef", k=40))

            receipt = AttestationReceipt(
                transaction_id=random_tx,
                proof_status=next_status,
                originating_agent_urn="urn:coreason:agent:security-auditor:01h3x",
                verification_timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                zk_proof_hash=random_hash,
                sd_jwt_compliance=is_compliant,
            )

            yield f"{d_pfx}{json.dumps(receipt.model_dump(by_alias=True))}\n\n"
            await asyncio.sleep(5.0)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
