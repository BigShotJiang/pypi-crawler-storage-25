# Copyright (c) 2026 CoReason, Inc.
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Header
from pydantic import BaseModel, Field

from coreason_runtime.utils.logger import logger

profile_router = APIRouter(prefix="/api/v1/auth/profile", tags=["Profile Configuration"])


class LayoutConfiguration(BaseModel):
    operational_subtype: str = Field("GENERALIST", alias="operationalSubtype")
    density: str = Field("standard")
    widgets: list[str] = Field(default_factory=list)
    custom_transitions_enabled: bool = Field(True, alias="customTransitionsEnabled")

    class Config:
        populate_by_name = True


# In-memory preference synchronization storage (keyed by tenant_id:user_id)
_configurations_store: dict[str, LayoutConfiguration] = {}

# Default fallback layout config (GENERALIST — fail-closed per NFR)
DEFAULT_CONFIG = LayoutConfiguration(
    operationalSubtype="GENERALIST",
    density="standard",
    widgets=["c-canvas", "c-profile", "c-assistant", "c-speculative", "c-alignment", "c-constellation"],
    customTransitionsEnabled=True,
)

# Allowed operational subtypes for validation
_VALID_SUBTYPES = {"GENERALIST", "SECURITY_AUDITOR", "EXECUTIVE", "ENGINEER"}


def _extract_tenant_user(authorization: str | None) -> tuple[str, str]:
    """Extract tenant_id and user_id from a Bearer JWT.

    Returns fallback identifiers if the header is missing or malformed.
    This is fail-closed: missing auth returns the default GENERALIST layout.
    """
    if not authorization or not authorization.startswith("Bearer "):
        return ("__anonymous__", "__anonymous__")

    token = authorization[len("Bearer ") :]
    # Decode JWT claims without full crypto verification (middleware handles that)
    # We just need the tenant/user IDs for storage keying.
    import base64
    import json

    try:
        # JWT has 3 parts: header.payload.signature
        parts = token.split(".")
        if len(parts) < 2:
            return ("__anonymous__", "__anonymous__")

        # Decode payload (add padding if needed)
        payload_b64 = parts[1]
        padding = 4 - len(payload_b64) % 4
        if padding != 4:
            payload_b64 += "=" * padding

        claims = json.loads(base64.urlsafe_b64decode(payload_b64))
        tenant_id = claims.get("tenant_id", claims.get("tid", "__anonymous__"))
        user_id = claims.get("sub", "__anonymous__")
        return (str(tenant_id), str(user_id))
    except Exception:
        logger.debug("Failed to decode JWT claims for profile keying")
        return ("__anonymous__", "__anonymous__")


@profile_router.get("/layout", response_model=LayoutConfiguration)
async def retrieve_layout_configuration(
    authorization: str | None = Header(None),
) -> LayoutConfiguration:
    """Retrieve layout preferences. Returns default GENERALIST if not yet persisted or auth missing."""
    tenant_id, user_id = _extract_tenant_user(authorization)
    store_key = f"{tenant_id}:{user_id}"
    return _configurations_store.get(store_key, DEFAULT_CONFIG)


@profile_router.post("/layout")
async def modify_layout_configuration(
    configuration_input: LayoutConfiguration,
    authorization: str | None = Header(None),
) -> dict[str, Any]:
    """Persist the modified layout configuration, keyed by tenant and user."""
    tenant_id, user_id = _extract_tenant_user(authorization)

    # Validate operational subtype
    if configuration_input.operational_subtype not in _VALID_SUBTYPES:
        logger.warning(
            f"Invalid operationalSubtype '{configuration_input.operational_subtype}', falling back to GENERALIST"
        )
        configuration_input = configuration_input.model_copy(update={"operational_subtype": "GENERALIST"})

    store_key = f"{tenant_id}:{user_id}"
    _configurations_store[store_key] = configuration_input
    return {"status": "success", "synchronized": True}
