# Copyright (c) 2026 CoReason, Inc.

"""Tests for Semantic Vector Space Router (#375)."""

from __future__ import annotations

from coreason_runtime.api.semantic_space_router import (
    _build_default_space,
    _hash_coordinate,
)


class TestHashCoordinate:
    """Tests for deterministic coordinate generation."""

    def test_coordinate_in_range(self) -> None:
        """Coordinates must be in [-1.0, 1.0]."""
        for axis in range(3):
            coord = _hash_coordinate("test_concept", axis)
            assert -1.0 <= coord <= 1.0

    def test_deterministic(self) -> None:
        """Same inputs produce same outputs."""
        c1 = _hash_coordinate("concept_a", 0)
        c2 = _hash_coordinate("concept_a", 0)
        assert c1 == c2

    def test_different_axes_differ(self) -> None:
        """Different axis indices produce different coordinates."""
        x = _hash_coordinate("concept_a", 0)
        y = _hash_coordinate("concept_a", 1)
        z = _hash_coordinate("concept_a", 2)
        # Very unlikely all three are equal
        assert not (x == y == z)


class TestBuildDefaultSpace:
    """Tests for the default belief constellation."""

    def test_returns_nodes_and_edges(self) -> None:
        space = _build_default_space()
        assert len(space.nodes) >= 5
        assert len(space.edges) >= 4

    def test_node_coordinates_normalized(self) -> None:
        space = _build_default_space()
        for node in space.nodes:
            assert -1.0 <= node.x <= 1.0
            assert -1.0 <= node.y <= 1.0
            assert -1.0 <= node.z <= 1.0

    def test_node_weights_valid(self) -> None:
        space = _build_default_space()
        for node in space.nodes:
            assert 0.0 <= node.weight <= 1.0

    def test_edge_strengths_valid(self) -> None:
        space = _build_default_space()
        for edge in space.edges:
            assert 0.0 <= edge.strength <= 1.0

    def test_custom_space_id(self) -> None:
        space = _build_default_space("custom_space_42")
        assert space.space_id == "custom_space_42"

    def test_edge_sources_are_valid_nodes(self) -> None:
        space = _build_default_space()
        node_ids = {n.id for n in space.nodes}
        for edge in space.edges:
            assert edge.source in node_ids
            assert edge.target in node_ids
