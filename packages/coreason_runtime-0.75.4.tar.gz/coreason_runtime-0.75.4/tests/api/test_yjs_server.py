# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Unit tests for the Yjs CRDT WebSocket collaboration server."""

import pytest
from fastapi.testclient import TestClient

from coreason_runtime.api.yjs_server import rooms, ws_app


def test_yjs_websocket_collaboration() -> None:
    """Verify Yjs collaborative websocket room creation and event broadcasting."""
    client = TestClient(ws_app)
    rooms.clear()

    # Establish connection 1
    with client.websocket_connect("/room-1") as ws1:
        assert "room-1" in rooms
        assert len(rooms["room-1"]) == 1

        # Establish connection 2
        with client.websocket_connect("/room-1") as ws2:
            assert len(rooms["room-1"]) == 2

            # Test text broadcast from ws1 to ws2
            ws1.send_text("hello-crdt")
            msg = ws2.receive_text()
            assert msg == "hello-crdt"

            # Test bytes broadcast from ws2 to ws1
            ws2.send_bytes(b"\x01\x02\x03")
            msg_bytes = ws1.receive_bytes()
            assert msg_bytes == b"\x01\x02\x03"

        # After ws2 exits, only ws1 remains
        assert len(rooms["room-1"]) == 1

    # After ws1 exits, the room is deleted
    assert "room-1" not in rooms


def test_yjs_websocket_origin_filtering(monkeypatch: pytest.MonkeyPatch) -> None:
    """Verify that websocket connection requests are filtered based on the Origin header."""
    from starlette.websockets import WebSocketDisconnect

    from coreason_runtime.api import yjs_server

    # Restrict allowed origins to a specific domain
    monkeypatch.setattr(yjs_server, "ALLOWED_ORIGINS", ["https://trusted.coreason.ai"])
    client = TestClient(ws_app)
    rooms.clear()

    # 1. Connecting with a valid Origin header should succeed
    with client.websocket_connect("/room-test", headers={"origin": "https://trusted.coreason.ai"}):
        assert "room-test" in rooms
        assert len(rooms["room-test"]) == 1

    # 2. Connecting with an invalid Origin header should be rejected
    with pytest.raises(WebSocketDisconnect) as exc_info:
        with client.websocket_connect("/room-test", headers={"origin": "https://malicious.evil.com"}):
            pass
    assert exc_info.value.code == 1008

    # 3. Connecting with no Origin header should also be rejected
    with pytest.raises(WebSocketDisconnect) as exc_info:
        with client.websocket_connect("/room-test"):
            pass
    assert exc_info.value.code == 1008
