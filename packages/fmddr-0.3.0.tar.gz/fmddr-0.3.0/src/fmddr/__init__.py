"""fmddr — query a FileMaker DDR."""
__version__ = "0.3.0"
