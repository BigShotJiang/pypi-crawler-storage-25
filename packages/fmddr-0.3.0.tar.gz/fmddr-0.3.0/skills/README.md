# fmddr — Claude Code skills

Two agent skills for working with [`fmddr`](https://github.com/proofsh/fmddr)
from Claude Code:

| Skill         | Triggers on                                                               | Purpose                                                       |
| ------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------- |
| `fmddr`       | FileMaker / DDR / fmp12 / Profile.xml / "where is X used" / refactor talk | Recognize when to reach for `fmddr` and use it correctly      |
| `fmddr-issue` | "report a bug", "file an issue", "feature request" — for fmddr            | Open a high-quality issue at proofsh/fmddr (with severity)    |

The `fmddr` skill is the one that solves the "agent doesn't realize this
tool exists" problem. Its description is packed with FileMaker trigger
phrases so Claude loads it as soon as the conversation enters that
domain.

## Install

### Personal (one user, all projects)

```sh
mkdir -p ~/.claude/skills
cp -R skills/fmddr ~/.claude/skills/
cp -R skills/fmddr-issue ~/.claude/skills/
```

### Project-scoped (this repo / a sibling repo)

```sh
mkdir -p .claude/skills
cp -R skills/fmddr .claude/skills/
cp -R skills/fmddr-issue .claude/skills/
```

Project skills override personal skills with the same name.

### One-liner from anywhere

```sh
# personal install, straight from the repo
git clone --depth 1 https://github.com/proofsh/fmddr.git /tmp/fmddr-skills \
  && mkdir -p ~/.claude/skills \
  && cp -R /tmp/fmddr-skills/skills/fmddr ~/.claude/skills/ \
  && cp -R /tmp/fmddr-skills/skills/fmddr-issue ~/.claude/skills/ \
  && rm -rf /tmp/fmddr-skills
```

## Verify

In a Claude Code session, type `/` and look for the skills, or ask
"is the fmddr skill loaded?" — Claude will list available skills.

You can also confirm by triggering it: in a directory containing a
FileMaker DDR XML, ask "what tools could analyze this?" — the `fmddr`
skill should activate.

## Layout

```
skills/
├── fmddr/
│   └── SKILL.md
└── fmddr-issue/
    ├── SKILL.md
    └── templates/
        ├── bug-report.md
        └── feature-request.md
```

## Updating

```sh
cd /path/to/fmddr && git pull
cp -R skills/fmddr ~/.claude/skills/
cp -R skills/fmddr-issue ~/.claude/skills/
```
