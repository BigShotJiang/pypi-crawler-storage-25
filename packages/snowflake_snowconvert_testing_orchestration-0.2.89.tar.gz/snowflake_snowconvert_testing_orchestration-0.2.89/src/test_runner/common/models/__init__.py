"""Data models for the test runner pipeline.

All models are re-exported here so that existing imports like
``from test_runner.common.models import BaselineData`` continue to work.
"""

from .validation_steps import ValidationSteps
from .step_types import (
    VALIDATE_SKIP,
    CursorStep,
    ParamStep,
    QueryStep,
    Step,
    StepBase,
    StepBasedValidation,
    TableStep,
    ValidateCursor,
    ValidateEntry,
    ValidateQuery,
    ValidateResult,
    ValidateSkip,
    ValidateTable,
)
from .test_file import TestFile
from .capture_result import TestCaseResult
from .baseline_data import BaselineData
from .stats import TestCaseStats, ValidationStats
from .types import (
    MAX_DETAIL_LENGTH,
    MAX_ERROR_LENGTH,
    MAX_SUMMARY_LENGTH,
    ColumnTypeMap,
    RowDict,
    truncate,
)
from .comparison import ComparisonResult, ValidationCaseResult, ValidationDifference

CaptureResult = TestCaseResult
CaptureStats = TestCaseStats
ValidateStats = ValidationStats

__all__ = [
    "MAX_DETAIL_LENGTH",
    "MAX_ERROR_LENGTH",
    "MAX_SUMMARY_LENGTH",
    "truncate",
    "ColumnTypeMap",
    "ComparisonResult",
    "CursorStep",
    "ParamStep",
    "QueryStep",
    "RowDict",
    "Step",
    "StepBase",
    "StepBasedValidation",
    "TableStep",
    "VALIDATE_SKIP",
    "ValidateCursor",
    "ValidateEntry",
    "ValidateQuery",
    "ValidateResult",
    "ValidateSkip",
    "ValidateTable",
    "ValidationCaseResult",
    "ValidationDifference",
    "ValidationSteps",
    "TestFile",
    "TestCaseResult",
    "CaptureResult",
    "BaselineData",
    "TestCaseStats",
    "CaptureStats",
    "ValidationStats",
    "ValidateStats",
]
