"""SQL validation steps for a single dialect."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class ValidationSteps:
    """SQL validation steps for a specific dialect (source or target)."""

    run: str
    """SQL template with {0}, {1} positional placeholders."""

    pre_execute: Optional[str] = None
    """Optional SQL to run before the main command (e.g. DECLARE statements)."""

    output_parameters: Optional[list[str]] = None
    """Optional output parameter names to retrieve after execution."""

    output_tables: Optional[list[str]] = None
    """Temp-table or table names to SELECT from after execution."""

    output_cursors: Optional[list[str]] = None
    """REFCURSOR names to FETCH from after execution (Redshift source only).

    On the Snowflake target side, cursors are declared as ``output.tables``
    instead — Snowflake reads both via ``SELECT * FROM IDENTIFIER()``.
    """
