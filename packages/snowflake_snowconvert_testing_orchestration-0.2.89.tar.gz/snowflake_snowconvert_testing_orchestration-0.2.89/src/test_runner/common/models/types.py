"""Reusable type aliases and small helpers for the test-runner pipeline."""

from __future__ import annotations

from typing import Any

ColumnTypeMap = dict[str, str]
"""Maps column name to its SQL type name (e.g. ``{"ID": "NUMBER", "NAME": "VARCHAR"}``)."""

RowDict = dict[str, Any]
"""A single result row represented as a column-name-to-value mapping."""

MAX_ERROR_LENGTH = 500
MAX_DETAIL_LENGTH = 300
MAX_SUMMARY_LENGTH = 200


def truncate(text: str, max_length: int = MAX_DETAIL_LENGTH) -> str:
    """Shorten *text* to at most *max_length* characters."""
    if len(text) <= max_length:
        return text
    return text[:max_length]
