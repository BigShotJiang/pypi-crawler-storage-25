"""Shared regex patterns for extracting parameter names from SQL templates."""

from __future__ import annotations

import re

# @name = {N}
PARAM_ASSIGNMENT_RE = re.compile(
    r"@(\w+)\s*=\s*\{(\d+)\}",
    re.IGNORECASE,
)

# DECLARE @name TYPE = {N}  /  LET name TYPE := {N}
DECLARE_PARAM_RE = re.compile(
    r"(?:DECLARE\s+@(\w+)|LET\s+(\w+))\s+\S+\s*(?::=|=)\s*\{(\d+)\}",
    re.IGNORECASE,
)

# {N} positional placeholder
POSITIONAL_PLACEHOLDER_RE = re.compile(r"\{(\d+)\}")
