"""Replay validation framework for DML procedures with side effects."""
