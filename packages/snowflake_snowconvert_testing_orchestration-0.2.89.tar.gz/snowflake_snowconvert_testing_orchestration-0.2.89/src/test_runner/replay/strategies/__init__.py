"""Delta capture strategy implementations.

Each strategy is a concrete subclass of :class:`DeltaCaptureStrategy`
that takes before/after row snapshots and produces a delta dict.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..models import DeltaStrategy, RowDict, TableConfig


class DeltaCaptureStrategy(ABC):
    """ABC for delta-capture strategies.

    Subclasses implement :meth:`compute_delta` which receives the
    before/after snapshots and returns a plain delta dict ready for
    JSON serialization in the baseline.
    """

    @property
    @abstractmethod
    def name(self) -> DeltaStrategy:
        """The strategy enum value."""

    @abstractmethod
    def compute_delta(
        self,
        before: list[RowDict],
        after: list[RowDict],
        table_cfg: TableConfig,
    ) -> dict[str, Any]:
        """Compute the delta between *before* and *after* snapshots.

        Returns a plain dict in the canonical delta format
        (``table``, ``strategy_used``, ``inserts``, ``deletes``, ``updates``).
        """
