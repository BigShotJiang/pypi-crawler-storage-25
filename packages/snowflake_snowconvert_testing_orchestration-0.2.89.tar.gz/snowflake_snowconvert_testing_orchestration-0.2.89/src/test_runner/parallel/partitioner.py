"""Partition test cases into read-only and DML buckets."""

from __future__ import annotations

from typing import Any

from test_runner.common.models import TestFile

# A "flattened case" is (TestFile, case_index, test_case_values).
CaseItem = tuple[TestFile, int, list[Any]]


def partition_cases(
    test_files: list[TestFile],
) -> tuple[list[CaseItem], list[CaseItem]]:
    """Split every test case into (read_only, dml) lists.

    A test file is considered DML when ``modifies_data is True``.
    All other files (including ``modifies_data is None``, which means
    the CUR classifier could not determine the answer) are treated as
    read-only for the purpose of safe parallelization.

    Returns:
        A tuple of ``(read_only_cases, dml_cases)`` where each element
        is a list of ``(TestFile, case_idx, test_case)`` tuples.
    """
    read_only: list[CaseItem] = []
    dml: list[CaseItem] = []

    for test_file in test_files:
        bucket = dml if test_file.modifies_data is True else read_only
        for case_idx, test_case in enumerate(test_file.test_cases):
            bucket.append((test_file, case_idx, test_case))

    return read_only, dml
