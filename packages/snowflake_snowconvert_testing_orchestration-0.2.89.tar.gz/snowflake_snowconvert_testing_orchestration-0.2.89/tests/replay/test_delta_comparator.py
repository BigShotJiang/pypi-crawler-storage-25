"""Tests for replay.delta_comparator — ignore_columns filtering."""

from __future__ import annotations

from test_runner.replay.delta_comparator import (
    _strip_columns,
    compare_table_deltas,
)


class TestStripColumns:
    def test_strips_matching_columns(self):
        rows = [{"A": 1, "B": 2, "C": 3}]
        result = _strip_columns(rows, {"B"})
        assert result == [{"A": 1, "C": 3}]

    def test_case_insensitive(self):
        rows = [{"ValidFrom": "2024-01-01", "Name": "x"}]
        result = _strip_columns(rows, {"VALIDFROM"})
        assert result == [{"Name": "x"}]

    def test_empty_ignore_returns_original(self):
        rows = [{"A": 1}]
        assert _strip_columns(rows, set()) is rows

    def test_empty_rows_returns_original(self):
        assert _strip_columns([], {"A"}) == []

    def test_multiple_rows(self):
        rows = [
            {"A": 1, "B": 2, "C": 3},
            {"A": 4, "B": 5, "C": 6},
        ]
        result = _strip_columns(rows, {"B", "C"})
        assert result == [{"A": 1}, {"A": 4}]


class TestCompareTableDeltasIgnoreColumns:
    """Verify that ignore_columns strips columns before comparison."""

    def test_match_when_only_ignored_columns_differ(self):
        baseline = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2024-01-01", "VALIDTO": "9999-12-31"}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2026-03-11", "VALIDTO": "2099-01-01"}],
            "deletes": [],
            "updates": [],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            ignore_columns=["VALIDFROM", "VALIDTO"],
        )
        assert result["match"] is True

    def test_mismatch_on_non_ignored_column(self):
        baseline = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2024-01-01"}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"COLOR": "Red", "VALIDFROM": "2026-03-11"}],
            "deletes": [],
            "updates": [],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            ignore_columns=["VALIDFROM"],
        )
        assert result["match"] is False

    def test_no_ignore_columns_compares_everything(self):
        baseline = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2024-01-01"}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2026-03-11"}],
            "deletes": [],
            "updates": [],
        }

        result = compare_table_deltas(baseline, actual, "S.T")
        assert result["match"] is False

    def test_ignore_columns_applied_to_deletes(self):
        baseline = {
            "inserts": [],
            "deletes": [{"NAME": "X", "VALIDFROM": "old"}],
            "updates": [],
        }
        actual = {
            "inserts": [],
            "deletes": [{"NAME": "X", "VALIDFROM": "new"}],
            "updates": [],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            ignore_columns=["VALIDFROM"],
        )
        assert result["match"] is True

    def test_ignore_columns_applied_to_updates(self):
        baseline = {
            "inserts": [],
            "deletes": [],
            "updates": [{"after": {"NAME": "X", "VALIDFROM": "old"}}],
        }
        actual = {
            "inserts": [],
            "deletes": [],
            "updates": [{"after": {"NAME": "X", "VALIDFROM": "new"}}],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            ignore_columns=["VALIDFROM"],
        )
        assert result["match"] is True
