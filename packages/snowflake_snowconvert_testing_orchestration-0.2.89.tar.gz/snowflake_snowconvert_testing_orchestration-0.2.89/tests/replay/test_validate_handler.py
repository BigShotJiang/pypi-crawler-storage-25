"""Tests for replay.validate_handler — column metadata merging."""

from __future__ import annotations

from test_runner.replay.models import TableConfig
from test_runner.replay.validate_handler import _merge_column_metadata


class TestMergeColumnMetadata:
    """Verify that auto-detected metadata merges into ignore_columns."""

    def test_merges_platform_managed_columns(self):
        configs = [TableConfig(schema_name="WAREHOUSE", table_name="COLORS")]

        _merge_column_metadata(configs, {
            "WAREHOUSE.COLORS": {
                "platform_managed_columns": ["VALIDFROM", "VALIDTO"],
                "identity_columns": ["COLORID"],
            },
        })

        assert "VALIDFROM" in configs[0].ignore_columns
        assert "VALIDTO" in configs[0].ignore_columns

    def test_does_not_merge_identity_columns(self):
        """Identity columns are tracked but not auto-ignored."""
        configs = [TableConfig(schema_name="WAREHOUSE", table_name="COLORS")]

        _merge_column_metadata(configs, {
            "WAREHOUSE.COLORS": {
                "platform_managed_columns": [],
                "identity_columns": ["COLORID"],
            },
        })

        assert "COLORID" not in configs[0].ignore_columns

    def test_unions_with_existing_ignore_columns(self):
        configs = [
            TableConfig(
                schema_name="WAREHOUSE", table_name="COLORS",
                ignore_columns=["VALIDFROM"],
            ),
        ]

        _merge_column_metadata(configs, {
            "WAREHOUSE.COLORS": {
                "platform_managed_columns": ["VALIDFROM", "VALIDTO"],
                "identity_columns": [],
            },
        })

        assert configs[0].ignore_columns.count("VALIDFROM") == 1
        assert "VALIDTO" in configs[0].ignore_columns

    def test_no_metadata_is_noop(self):
        configs = [TableConfig(schema_name="S", table_name="T")]
        _merge_column_metadata(configs, None)
        assert configs[0].ignore_columns == []

    def test_unrecognized_table_skipped(self):
        configs = [TableConfig(schema_name="S", table_name="T")]

        _merge_column_metadata(configs, {
            "OTHER.TABLE": {
                "platform_managed_columns": ["X"],
                "identity_columns": [],
            },
        })

        assert configs[0].ignore_columns == []

    def test_multiple_tables(self):
        configs = [
            TableConfig(schema_name="WAREHOUSE", table_name="COLORS"),
            TableConfig(schema_name="APPLICATION", table_name="PEOPLE"),
        ]

        _merge_column_metadata(configs, {
            "WAREHOUSE.COLORS": {
                "platform_managed_columns": ["VALIDFROM", "VALIDTO"],
                "identity_columns": [],
            },
            "APPLICATION.PEOPLE": {
                "platform_managed_columns": ["VALIDFROM", "VALIDTO"],
                "identity_columns": [],
            },
        })

        for tc in configs:
            assert "VALIDFROM" in tc.ignore_columns
            assert "VALIDTO" in tc.ignore_columns
