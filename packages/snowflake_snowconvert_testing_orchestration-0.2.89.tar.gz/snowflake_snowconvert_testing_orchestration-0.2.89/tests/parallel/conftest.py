"""Shared test fixtures for the parallel module."""

from __future__ import annotations

from test_runner.common.models import TestFile, ValidationSteps
from test_runner.parallel.partitioner import CaseItem


def make_test_file(
    name: str,
    *,
    modifies_data: bool | None = None,
    cases: int = 1,
    affected_tables: list[str] | None = None,
    read_tables: list[str] | None = None,
) -> TestFile:
    return TestFile(
        file_path=f"/fake/{name}.yml",
        source=ValidationSteps(run=f"CALL {name}({{0}})"),
        test_cases=[[i] for i in range(cases)],
        code_unit_name=name,
        modifies_data=modifies_data,
        affected_tables=affected_tables,
        read_tables=read_tables,
    )


def make_case_item(tf: TestFile, idx: int = 0) -> CaseItem:
    return (tf, idx, tf.test_cases[idx])
