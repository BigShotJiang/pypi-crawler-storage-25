"""Tests for test_runner.parallel.partitioner."""

from __future__ import annotations

from test_runner.parallel.partitioner import partition_cases

from .conftest import make_test_file as _make_tf


class TestPartitionCases:
    def test_all_read_only_when_modifies_data_none(self):
        tf = _make_tf("sp_read", modifies_data=None, cases=3)
        ro, dml = partition_cases([tf])
        assert len(ro) == 3
        assert len(dml) == 0

    def test_all_read_only_when_modifies_data_false(self):
        tf = _make_tf("sp_read", modifies_data=False, cases=2)
        ro, dml = partition_cases([tf])
        assert len(ro) == 2
        assert len(dml) == 0

    def test_dml_when_modifies_data_true(self):
        tf = _make_tf("sp_write", modifies_data=True, cases=2)
        ro, dml = partition_cases([tf])
        assert len(ro) == 0
        assert len(dml) == 2

    def test_mixed_files(self):
        ro_file = _make_tf("sp_read", modifies_data=False, cases=2)
        dml_file = _make_tf("sp_write", modifies_data=True, cases=1)
        unknown_file = _make_tf("sp_unknown", modifies_data=None, cases=1)

        ro, dml = partition_cases([ro_file, dml_file, unknown_file])
        assert len(ro) == 3  # 2 from ro_file + 1 from unknown_file
        assert len(dml) == 1

    def test_empty_input(self):
        ro, dml = partition_cases([])
        assert ro == []
        assert dml == []

    def test_case_items_preserve_structure(self):
        tf = _make_tf("sp_a", modifies_data=False, cases=2)
        ro, _ = partition_cases([tf])
        for test_file, case_idx, test_case in ro:
            assert test_file is tf
            assert isinstance(case_idx, int)
            assert isinstance(test_case, list)
