import { describe, expect, it } from "vitest";
import {
  CancelJobResponseSchema,
  CaptureRestartFrameSchema,
  CaptureRestartReasonSchema,
  FailoverHistoryEntrySchema,
  FailoverHistoryResponseSchema,
  ForgetMindResponseSchema,
  OnboardingCompleteResponseSchema,
  PruneRetentionResponseSchema,
  StartTrainingRequestSchema,
  StartTrainingResponseSchema,
  TrainingJobDetailResponseSchema,
  TrainingJobsResponseSchema,
  TrainingJobStatusSchema,
  TrainingJobStreamMessageSchema,
  TrainingJobSummarySchema,
  VoiceBypassTierStatusResponseSchema,
  VoiceRestartHistoryResponseSchema,
  WakeWordPerMindStatusResponseSchema,
  WakeWordPerMindStatusSchema,
  WakeWordToggleRequestSchema,
  WakeWordToggleResponseSchema,
  WizardDevicesResponseSchema,
  WizardDiagnosticResponseSchema,
  WizardTestResultResponseSchema,
} from "./schemas";

// Voice Windows Paranoid Mission (v0.24.0) — pin the wire contract
// for the new CaptureRestartFrame surface so a backend rename is loud
// in CI rather than silent at runtime.

describe("CaptureRestartReasonSchema", () => {
  it("accepts every documented variant", () => {
    expect(CaptureRestartReasonSchema.parse("device_changed")).toBe(
      "device_changed",
    );
    expect(CaptureRestartReasonSchema.parse("apo_degraded")).toBe(
      "apo_degraded",
    );
    expect(CaptureRestartReasonSchema.parse("overflow")).toBe("overflow");
    expect(CaptureRestartReasonSchema.parse("manual")).toBe("manual");
  });

  it("rejects unknown variants", () => {
    expect(() => CaptureRestartReasonSchema.parse("teleport")).toThrow();
  });

  // Mission C1 §20.K — verdict-driven reasons emitted by the
  // coordinator dispatch path (vad_frontend_dead / format_mismatch /
  // driver_silent — v0.44.0). The frontend zod parser MUST accept
  // these or the response fails safeParse at the boundary.
  it("accepts Mission C1 verdict-driven reasons", () => {
    expect(CaptureRestartReasonSchema.parse("vad_frontend_dead")).toBe(
      "vad_frontend_dead",
    );
    expect(CaptureRestartReasonSchema.parse("format_mismatch")).toBe(
      "format_mismatch",
    );
    expect(CaptureRestartReasonSchema.parse("driver_silent")).toBe(
      "driver_silent",
    );
  });

  // Mission H3 §T3.3 — extended QuarantineReason taxonomy values.
  // ``capture_dead`` (substrate fully silent, distinct from
  // ``driver_silent`` and ``kernel_invalidated``) and ``unclassified``
  // (taxonomy fallback). The schema rejects these pre-Phase-1.C; the
  // post-Phase-1.C dashboard accepts both.
  it("accepts Mission H3 quarantine reason extensions", () => {
    expect(CaptureRestartReasonSchema.parse("capture_dead")).toBe(
      "capture_dead",
    );
    expect(CaptureRestartReasonSchema.parse("unclassified")).toBe(
      "unclassified",
    );
  });
});

// T3.12 — every CaptureRestartFrame field is now required at the
// zod boundary because the Python dataclass always serialises
// them (defaults to empty-string / 0). Tests use this helper to
// build a fully-defaulted frame; tests that exercise specific
// fields override only what they need.
const restartFrameDefaults = () => ({
  frame_type: "CaptureRestart" as const,
  timestamp_monotonic: 1,
  utterance_id: "",
  restart_reason: "" as const,
  old_host_api: "",
  new_host_api: "",
  old_device_id: "",
  new_device_id: "",
  old_signal_processing_mode: "",
  new_signal_processing_mode: "",
  recovery_latency_ms: 0,
  bypass_tier: 0,
});

describe("CaptureRestartFrameSchema", () => {
  it("parses a minimal default-valued frame (T3.12 contract)", () => {
    const frame = CaptureRestartFrameSchema.parse(restartFrameDefaults());
    expect(frame.frame_type).toBe("CaptureRestart");
    expect(frame.timestamp_monotonic).toBe(1);
    // All fields populated with defaults.
    expect(frame.utterance_id).toBe("");
    expect(frame.bypass_tier).toBe(0);
  });

  it("parses a full device_changed payload", () => {
    const frame = CaptureRestartFrameSchema.parse({
      ...restartFrameDefaults(),
      timestamp_monotonic: 100,
      utterance_id: "utt-1",
      restart_reason: "device_changed",
      old_host_api: "Windows WASAPI",
      new_host_api: "Windows WASAPI",
      old_device_id: "{old-guid}",
      new_device_id: "{new-guid}",
      old_signal_processing_mode: "Default",
      new_signal_processing_mode: "Default",
      recovery_latency_ms: 312,
      bypass_tier: 0,
    });
    expect(frame.restart_reason).toBe("device_changed");
    expect(frame.recovery_latency_ms).toBe(312);
    expect(frame.bypass_tier).toBe(0);
  });

  it("parses an apo_degraded payload with bypass_tier=2", () => {
    const frame = CaptureRestartFrameSchema.parse({
      ...restartFrameDefaults(),
      timestamp_monotonic: 200,
      restart_reason: "apo_degraded",
      old_host_api: "MME",
      new_host_api: "Windows WASAPI",
      old_signal_processing_mode: "Default",
      new_signal_processing_mode: "RAW",
      bypass_tier: 2,
    });
    expect(frame.bypass_tier).toBe(2);
    expect(frame.new_signal_processing_mode).toBe("RAW");
  });

  it("rejects bypass_tier outside [0, 3]", () => {
    expect(() =>
      CaptureRestartFrameSchema.parse({
        ...restartFrameDefaults(),
        bypass_tier: 4,
      }),
    ).toThrow();
    expect(() =>
      CaptureRestartFrameSchema.parse({
        ...restartFrameDefaults(),
        bypass_tier: -1,
      }),
    ).toThrow();
  });

  it("rejects negative recovery_latency_ms", () => {
    expect(() =>
      CaptureRestartFrameSchema.parse({
        ...restartFrameDefaults(),
        recovery_latency_ms: -5,
      }),
    ).toThrow();
  });

  it("rejects non-CaptureRestart frame_type", () => {
    expect(() =>
      CaptureRestartFrameSchema.parse({
        ...restartFrameDefaults(),
        frame_type: "TranscriptionFrame",
      }),
    ).toThrow();
  });

  it("rejects payloads missing required fields (T3.12 boundary)", () => {
    // Pre-T3.12 these fields were .optional() so a minimal payload
    // would pass. Post-T3.12 the schema rejects — backend regression
    // (e.g. a future refactor that drops dataclass fields) is caught
    // at the wire boundary.
    expect(() =>
      CaptureRestartFrameSchema.parse({
        frame_type: "CaptureRestart",
        timestamp_monotonic: 1,
        // missing utterance_id, restart_reason, all the new fields
      }),
    ).toThrow();
  });

  it("tolerates an unknown restart_reason string (forward-compat)", () => {
    // Backend may emit a future variant before frontend ships its
    // zod bump; the schema accepts any string fallback.
    const frame = CaptureRestartFrameSchema.parse({
      ...restartFrameDefaults(),
      restart_reason: "teleport",
    });
    expect(frame.restart_reason).toBe("teleport");
  });
});

describe("VoiceRestartHistoryResponseSchema", () => {
  it("parses the empty-state payload (T33 wired contract)", () => {
    const payload = VoiceRestartHistoryResponseSchema.parse({
      frames: [],
      limit: 50,
      total: 0,
    });
    expect(payload.frames).toEqual([]);
    expect(payload.total).toBe(0);
  });

  it("parses a populated payload with limit + total", () => {
    const payload = VoiceRestartHistoryResponseSchema.parse({
      frames: [
        {
          ...restartFrameDefaults(),
          restart_reason: "device_changed",
        },
      ],
      limit: 50,
      total: 1,
    });
    expect(payload.frames).toHaveLength(1);
    expect(payload.limit).toBe(50);
    expect(payload.total).toBe(1);
  });

  it("rejects payloads missing limit or total (T3.12 boundary)", () => {
    // Pre-T3.12 these were .optional(). Post-T3.12 the endpoint
    // always populates them so the schema rejects malformed
    // responses.
    expect(() =>
      VoiceRestartHistoryResponseSchema.parse({ frames: [] }),
    ).toThrow();
  });
});

// v0.26.0 wire-up: every counter field is now required at the zod
// boundary because the endpoint reads a deterministic ``BypassTierSnapshot``
// mirror that always populates them. Tests use this helper to build a
// fully-defaulted payload.
const bypassTierStatusDefaults = () => ({
  tier1_raw_attempted: 0,
  tier1_raw_succeeded: 0,
  tier2_host_api_rotate_attempted: 0,
  tier2_host_api_rotate_succeeded: 0,
  tier3_wasapi_exclusive_attempted: 0,
  tier3_wasapi_exclusive_succeeded: 0,
});

describe("VoiceBypassTierStatusResponseSchema", () => {
  it("parses the v0.26.0 zero-state payload (all counters present)", () => {
    const payload = VoiceBypassTierStatusResponseSchema.parse({
      ...bypassTierStatusDefaults(),
      current_bypass_tier: null,
    });
    expect(payload.tier1_raw_attempted).toBe(0);
    expect(payload.current_bypass_tier).toBeNull();
  });

  it("parses a populated tier-status payload", () => {
    const payload = VoiceBypassTierStatusResponseSchema.parse({
      ...bypassTierStatusDefaults(),
      current_bypass_tier: 1,
      tier1_raw_attempted: 5,
      tier1_raw_succeeded: 4,
      tier3_wasapi_exclusive_attempted: 1,
      tier3_wasapi_exclusive_succeeded: 1,
    });
    expect(payload.current_bypass_tier).toBe(1);
    expect(payload.tier1_raw_succeeded).toBe(4);
  });

  it("accepts current_bypass_tier=null (no bypass currently engaged)", () => {
    const payload = VoiceBypassTierStatusResponseSchema.parse({
      ...bypassTierStatusDefaults(),
      current_bypass_tier: null,
    });
    expect(payload.current_bypass_tier).toBeNull();
  });

  it("rejects current_bypass_tier outside [0, 3]", () => {
    expect(() =>
      VoiceBypassTierStatusResponseSchema.parse({
        ...bypassTierStatusDefaults(),
        current_bypass_tier: 7,
      }),
    ).toThrow();
  });

  it("rejects payloads missing required counters (v0.26.0 wire-up boundary)", () => {
    // Pre-v0.26.0 these were .optional() so a minimal {} payload would
    // pass. Post-wire-up the schema rejects — backend regression
    // (e.g. dropped field) is caught at the zod boundary in CI.
    expect(() => VoiceBypassTierStatusResponseSchema.parse({})).toThrow();
    expect(() =>
      VoiceBypassTierStatusResponseSchema.parse({
        tier1_raw_attempted: 0,
        // missing tier1_raw_succeeded + tier2/3 counters
      }),
    ).toThrow();
  });
});

// ── Phase 8 / T8.21 — mind forget + retention dashboard endpoints ─

describe("ForgetMindResponseSchema", () => {
  const valid = {
    mind_id: "aria",
    concepts_purged: 0,
    relations_purged: 0,
    episodes_purged: 0,
    concept_embeddings_purged: 0,
    episode_embeddings_purged: 0,
    conversation_imports_purged: 0,
    consolidation_log_purged: 0,
    conversations_purged: 0,
    conversation_turns_purged: 0,
    daily_stats_purged: 0,
    consent_ledger_purged: 0,
    total_brain_rows_purged: 0,
    total_conversations_rows_purged: 0,
    total_system_rows_purged: 0,
    total_rows_purged: 0,
    dry_run: true,
  };

  it("parses the dry-run zero-state payload", () => {
    expect(ForgetMindResponseSchema.parse(valid).dry_run).toBe(true);
  });

  it("parses a populated wipe payload", () => {
    const populated = {
      ...valid,
      dry_run: false,
      concepts_purged: 3,
      episodes_purged: 4,
      total_brain_rows_purged: 7,
      total_rows_purged: 7,
    };
    const parsed = ForgetMindResponseSchema.parse(populated);
    expect(parsed.concepts_purged).toBe(3);
    expect(parsed.total_rows_purged).toBe(7);
  });

  it("rejects negative counts", () => {
    expect(() =>
      ForgetMindResponseSchema.parse({ ...valid, concepts_purged: -1 }),
    ).toThrow();
  });

  it("rejects non-integer counts", () => {
    expect(() =>
      ForgetMindResponseSchema.parse({ ...valid, episodes_purged: 3.5 }),
    ).toThrow();
  });

  it("rejects payloads missing required fields", () => {
    expect(() => ForgetMindResponseSchema.parse({})).toThrow();
    const { mind_id: _omit, ...withoutMindId } = valid;
    expect(() => ForgetMindResponseSchema.parse(withoutMindId)).toThrow();
  });
});

describe("PruneRetentionResponseSchema", () => {
  const valid = {
    mind_id: "aria",
    cutoff_utc: "2026-04-01T00:00:00+00:00",
    episodes_purged: 0,
    conversations_purged: 0,
    conversation_turns_purged: 0,
    daily_stats_purged: 0,
    consolidation_log_purged: 0,
    consent_ledger_purged: 0,
    effective_horizons: {
      episodes: 30,
      conversations: 30,
      consolidation_log: 90,
      daily_stats: 365,
      consent_ledger: 0,
    },
    total_brain_rows_purged: 0,
    total_conversations_rows_purged: 0,
    total_system_rows_purged: 0,
    total_rows_purged: 0,
    dry_run: true,
  };

  it("parses a dry-run preview with default horizons", () => {
    const parsed = PruneRetentionResponseSchema.parse(valid);
    expect(parsed.effective_horizons.episodes).toBe(30);
    expect(parsed.effective_horizons.consent_ledger).toBe(0);
  });

  it("parses a real-run with mind override horizons", () => {
    const realRun = {
      ...valid,
      dry_run: false,
      effective_horizons: { ...valid.effective_horizons, episodes: 90 },
      episodes_purged: 5,
      total_brain_rows_purged: 5,
      total_rows_purged: 5,
    };
    const parsed = PruneRetentionResponseSchema.parse(realRun);
    expect(parsed.effective_horizons.episodes).toBe(90);
    expect(parsed.episodes_purged).toBe(5);
  });

  it("rejects negative horizon values", () => {
    expect(() =>
      PruneRetentionResponseSchema.parse({
        ...valid,
        effective_horizons: { episodes: -1 },
      }),
    ).toThrow();
  });

  it("rejects payloads missing cutoff_utc", () => {
    const { cutoff_utc: _omit, ...withoutCutoff } = valid;
    expect(() => PruneRetentionResponseSchema.parse(withoutCutoff)).toThrow();
  });
});

// ── MISSION-pre-wake-word-ui-hardening §T4 — wake-word toggle ──

describe("WakeWordToggleRequestSchema", () => {
  it("parses an enable request", () => {
    expect(WakeWordToggleRequestSchema.parse({ enabled: true }).enabled).toBe(
      true,
    );
  });

  it("parses a disable request", () => {
    expect(WakeWordToggleRequestSchema.parse({ enabled: false }).enabled).toBe(
      false,
    );
  });

  it("rejects payloads missing the enabled field", () => {
    expect(() => WakeWordToggleRequestSchema.parse({})).toThrow();
  });

  it("rejects non-boolean enabled values", () => {
    expect(() =>
      WakeWordToggleRequestSchema.parse({ enabled: "true" }),
    ).toThrow();
    expect(() => WakeWordToggleRequestSchema.parse({ enabled: 1 })).toThrow();
  });
});

describe("WakeWordToggleResponseSchema", () => {
  const happyPath = {
    mind_id: "aria",
    enabled: true,
    persisted: true,
    applied_immediately: true,
    hot_apply_detail: null,
  };

  it("parses the happy-path payload (applied_immediately=true, detail=null)", () => {
    const parsed = WakeWordToggleResponseSchema.parse(happyPath);
    expect(parsed.applied_immediately).toBe(true);
    expect(parsed.hot_apply_detail).toBeNull();
  });

  it("parses the cold-start payload (applied_immediately=false with detail)", () => {
    const coldStart = {
      ...happyPath,
      applied_immediately: false,
      hot_apply_detail:
        "voice subsystem not running — change persisted; will apply on next boot",
    };
    const parsed = WakeWordToggleResponseSchema.parse(coldStart);
    expect(parsed.applied_immediately).toBe(false);
    expect(parsed.hot_apply_detail).toContain("next boot");
  });

  it("parses the disable payload", () => {
    const disable = {
      mind_id: "lucia",
      enabled: false,
      persisted: true,
      applied_immediately: true,
      hot_apply_detail: null,
    };
    expect(WakeWordToggleResponseSchema.parse(disable).enabled).toBe(false);
  });

  it("rejects payloads missing required fields", () => {
    expect(() => WakeWordToggleResponseSchema.parse({})).toThrow();
    const { mind_id: _omit, ...withoutMindId } = happyPath;
    expect(() => WakeWordToggleResponseSchema.parse(withoutMindId)).toThrow();
  });

  it("rejects non-string hot_apply_detail (must be string | null)", () => {
    expect(() =>
      WakeWordToggleResponseSchema.parse({
        ...happyPath,
        hot_apply_detail: 42,
      }),
    ).toThrow();
  });
});

// ── MISSION-wake-word-ui §T2 — per-mind wake-word status ──

describe("WakeWordPerMindStatusSchema", () => {
  const healthyExact = {
    mind_id: "aria",
    wake_word: "Aria",
    voice_language: "en",
    wake_word_enabled: true,
    runtime_registered: true,
    model_path: "/data/wake_word_models/pretrained/aria.onnx",
    resolution_strategy: "exact",
    matched_name: "aria",
    phoneme_distance: 0,
    last_error: null,
  };

  it("parses a healthy EXACT-match entry", () => {
    const parsed = WakeWordPerMindStatusSchema.parse(healthyExact);
    expect(parsed.runtime_registered).toBe(true);
    expect(parsed.resolution_strategy).toBe("exact");
    expect(parsed.last_error).toBeNull();
    // T1 of v0.29.1: EXACT populates matched_name + phoneme_distance=0.
    expect(parsed.matched_name).toBe("aria");
    expect(parsed.phoneme_distance).toBe(0);
  });

  it("parses a PHONETIC-match entry with non-zero distance", () => {
    const parsed = WakeWordPerMindStatusSchema.parse({
      ...healthyExact,
      wake_word: "Lúcia",
      voice_language: "pt-BR",
      resolution_strategy: "phonetic",
      model_path: "/data/wake_word_models/pretrained/lucia.onnx",
      matched_name: "lucia",
      phoneme_distance: 0,
    });
    expect(parsed.resolution_strategy).toBe("phonetic");
    expect(parsed.matched_name).toBe("lucia");
    expect(parsed.phoneme_distance).toBe(0);
  });

  it("parses a NONE-strategy entry with last_error remediation", () => {
    const parsed = WakeWordPerMindStatusSchema.parse({
      ...healthyExact,
      runtime_registered: false,
      model_path: null,
      resolution_strategy: "none",
      matched_name: null,
      phoneme_distance: null,
      last_error:
        "No ONNX model resolved for wake word 'Aria' ... train via `sovyx voice train-wake-word`",
    });
    expect(parsed.runtime_registered).toBe(false);
    expect(parsed.resolution_strategy).toBe("none");
    expect(parsed.last_error).toContain("train-wake-word");
    // T1 of v0.29.1: NONE has both new fields = null (no match to surface).
    expect(parsed.matched_name).toBeNull();
    expect(parsed.phoneme_distance).toBeNull();
  });

  it("parses a disabled-mind entry (resolution skipped)", () => {
    const parsed = WakeWordPerMindStatusSchema.parse({
      mind_id: "joao",
      wake_word: "Joao",
      voice_language: "en",
      wake_word_enabled: false,
      runtime_registered: false,
      model_path: null,
      resolution_strategy: null,
      matched_name: null,
      phoneme_distance: null,
      last_error: null,
    });
    expect(parsed.wake_word_enabled).toBe(false);
    expect(parsed.resolution_strategy).toBeNull();
    expect(parsed.matched_name).toBeNull();
    expect(parsed.phoneme_distance).toBeNull();
  });

  it("rejects invalid resolution_strategy values", () => {
    expect(() =>
      WakeWordPerMindStatusSchema.parse({
        ...healthyExact,
        resolution_strategy: "fuzzy",
      }),
    ).toThrow();
  });

  it("rejects negative phoneme_distance (resolver -1 sentinel must be converted at backend)", () => {
    expect(() =>
      WakeWordPerMindStatusSchema.parse({
        ...healthyExact,
        phoneme_distance: -1,
      }),
    ).toThrow();
  });

  it("rejects non-integer phoneme_distance", () => {
    expect(() =>
      WakeWordPerMindStatusSchema.parse({
        ...healthyExact,
        phoneme_distance: 0.5,
      }),
    ).toThrow();
  });

  it("rejects payloads missing required fields", () => {
    expect(() => WakeWordPerMindStatusSchema.parse({})).toThrow();
    const { mind_id: _omit, ...withoutMindId } = healthyExact;
    expect(() => WakeWordPerMindStatusSchema.parse(withoutMindId)).toThrow();
  });
});

describe("WakeWordPerMindStatusResponseSchema", () => {
  it("parses an empty-minds payload (cold-start / no minds on disk)", () => {
    const parsed = WakeWordPerMindStatusResponseSchema.parse({ minds: [] });
    expect(parsed.minds).toEqual([]);
  });

  it("parses a mixed list (healthy + broken + disabled)", () => {
    const mixedPayload = {
      minds: [
        {
          mind_id: "aria",
          wake_word: "Aria",
          voice_language: "en",
          wake_word_enabled: true,
          runtime_registered: true,
          model_path: "/data/wake_word_models/pretrained/aria.onnx",
          resolution_strategy: "exact",
          matched_name: "aria",
          phoneme_distance: 0,
          last_error: null,
        },
        {
          mind_id: "lucia",
          wake_word: "Lucia",
          voice_language: "pt-BR",
          wake_word_enabled: true,
          runtime_registered: false,
          model_path: null,
          resolution_strategy: "none",
          matched_name: null,
          phoneme_distance: null,
          last_error: "No ONNX model resolved ...",
        },
        {
          mind_id: "joao",
          wake_word: "Joao",
          voice_language: "en",
          wake_word_enabled: false,
          runtime_registered: false,
          model_path: null,
          resolution_strategy: null,
          matched_name: null,
          phoneme_distance: null,
          last_error: null,
        },
      ],
    };
    const parsed = WakeWordPerMindStatusResponseSchema.parse(mixedPayload);
    expect(parsed.minds.length).toBe(3);
    expect(parsed.minds[0].resolution_strategy).toBe("exact");
    expect(parsed.minds[1].resolution_strategy).toBe("none");
    expect(parsed.minds[2].resolution_strategy).toBeNull();
  });

  it("rejects payloads where minds is not an array", () => {
    expect(() =>
      WakeWordPerMindStatusResponseSchema.parse({ minds: "not-an-array" }),
    ).toThrow();
  });
});

// ── Phase 7 / T7.21-T7.24 — voice wizard endpoints ─

describe("WizardDevicesResponseSchema", () => {
  it("parses an empty-list payload (no audio hardware)", () => {
    const parsed = WizardDevicesResponseSchema.parse({
      devices: [],
      total_count: 0,
      default_device_id: null,
    });
    expect(parsed.devices).toEqual([]);
    expect(parsed.default_device_id).toBeNull();
  });

  it("parses a populated devices payload", () => {
    const parsed = WizardDevicesResponseSchema.parse({
      devices: [
        {
          device_id: "0",
          name: "Built-in Microphone",
          friendly_name: "Built-in Microphone",
          max_input_channels: 2,
          default_sample_rate: 48000,
          is_default: true,
          diagnosis_hint: "ready",
        },
      ],
      total_count: 1,
      default_device_id: "0",
    });
    expect(parsed.devices.length).toBe(1);
    expect(parsed.devices[0].diagnosis_hint).toBe("ready");
  });

  it("rejects negative channel counts", () => {
    expect(() =>
      WizardDevicesResponseSchema.parse({
        devices: [
          {
            device_id: "0",
            name: "x",
            friendly_name: "x",
            max_input_channels: -1,
            default_sample_rate: 48000,
            is_default: false,
            diagnosis_hint: "ready",
          },
        ],
        total_count: 1,
        default_device_id: null,
      }),
    ).toThrow();
  });
});

describe("WizardTestResultResponseSchema", () => {
  const valid = {
    session_id: "abc123",
    success: true,
    duration_actual_s: 3.0,
    sample_rate_hz: 16000,
    level_rms_dbfs: -20.0,
    level_peak_dbfs: -6.0,
    snr_db: 25.0,
    clipping_detected: false,
    silent_capture: false,
    diagnosis: "ok",
    diagnosis_hint: "Microphone looks good.",
    recorded_at_utc: "2026-05-02T12:00:00+00:00",
    error: null,
  };

  it("parses a successful capture payload", () => {
    expect(WizardTestResultResponseSchema.parse(valid).diagnosis).toBe("ok");
  });

  it("parses a silent-capture payload (null levels)", () => {
    const silent = {
      ...valid,
      success: true,
      silent_capture: true,
      level_rms_dbfs: null,
      level_peak_dbfs: null,
      snr_db: null,
      diagnosis: "no_audio",
      diagnosis_hint: "No usable signal captured.",
    };
    const parsed = WizardTestResultResponseSchema.parse(silent);
    expect(parsed.silent_capture).toBe(true);
    expect(parsed.level_peak_dbfs).toBeNull();
  });

  it("parses a recorder-error payload (success=false)", () => {
    const errorPayload = {
      ...valid,
      success: false,
      level_rms_dbfs: null,
      level_peak_dbfs: null,
      snr_db: null,
      diagnosis: "device_error",
      diagnosis_hint: "Permission denied. Open System Settings...",
      error: "Permission denied",
    };
    const parsed = WizardTestResultResponseSchema.parse(errorPayload);
    expect(parsed.success).toBe(false);
    expect(parsed.error).toBe("Permission denied");
  });

  it("rejects negative duration", () => {
    expect(() =>
      WizardTestResultResponseSchema.parse({
        ...valid,
        duration_actual_s: -1.0,
      }),
    ).toThrow();
  });
});

describe("WizardDiagnosticResponseSchema", () => {
  it("parses a ready=true payload (no APOs)", () => {
    const parsed = WizardDiagnosticResponseSchema.parse({
      ready: true,
      voice_clarity_active: false,
      active_device_name: null,
      platform: "linux",
      recommendations: [],
    });
    expect(parsed.ready).toBe(true);
    expect(parsed.recommendations).toEqual([]);
  });

  it("parses a not-ready payload with Voice Clarity active", () => {
    const parsed = WizardDiagnosticResponseSchema.parse({
      ready: false,
      voice_clarity_active: true,
      active_device_name: "Razer BlackShark V2 Pro",
      platform: "win32",
      recommendations: ["Windows Voice Clarity APO is active..."],
    });
    expect(parsed.voice_clarity_active).toBe(true);
    expect(parsed.recommendations.length).toBe(1);
  });

  it("rejects payloads missing platform", () => {
    expect(() =>
      WizardDiagnosticResponseSchema.parse({
        ready: true,
        voice_clarity_active: false,
        active_device_name: null,
        recommendations: [],
      }),
    ).toThrow();
  });
});

// ── Phase 8 / T8.13 — wake-word training endpoints ─

describe("TrainingJobStatusSchema", () => {
  it("accepts every documented status", () => {
    for (const status of [
      "pending",
      "synthesizing",
      "training",
      "complete",
      "failed",
      "cancelled",
    ]) {
      expect(TrainingJobStatusSchema.parse(status)).toBe(status);
    }
  });

  it("rejects unknown status string", () => {
    expect(() => TrainingJobStatusSchema.parse("running")).toThrow();
  });
});

describe("TrainingJobSummarySchema", () => {
  const valid = {
    job_id: "lucia",
    wake_word: "Lúcia",
    mind_id: "lucia",
    language: "pt-BR",
    status: "synthesizing" as const,
    progress: 0.45,
    samples_generated: 9,
    target_samples: 20,
    started_at: "2026-05-02T12:00:00+00:00",
    updated_at: "2026-05-02T12:01:00+00:00",
    completed_at: "",
    output_path: "",
    error_summary: "",
    cancelled_signalled: false,
  };

  it("parses an in-flight summary", () => {
    expect(TrainingJobSummarySchema.parse(valid).status).toBe("synthesizing");
  });

  it("rejects progress outside [0, 1]", () => {
    expect(() =>
      TrainingJobSummarySchema.parse({ ...valid, progress: 1.5 }),
    ).toThrow();
    expect(() =>
      TrainingJobSummarySchema.parse({ ...valid, progress: -0.1 }),
    ).toThrow();
  });

  it("rejects negative samples_generated", () => {
    expect(() =>
      TrainingJobSummarySchema.parse({ ...valid, samples_generated: -1 }),
    ).toThrow();
  });
});

describe("TrainingJobsResponseSchema", () => {
  it("parses the empty-state payload", () => {
    expect(TrainingJobsResponseSchema.parse({ jobs: [], total_count: 0 })).toEqual({
      jobs: [],
      total_count: 0,
    });
  });
});

describe("TrainingJobDetailResponseSchema", () => {
  const summary = {
    job_id: "lucia",
    wake_word: "Lúcia",
    mind_id: "lucia",
    language: "pt-BR",
    status: "complete" as const,
    progress: 1.0,
    samples_generated: 20,
    target_samples: 20,
    started_at: "2026-05-02T12:00:00+00:00",
    updated_at: "2026-05-02T12:30:00+00:00",
    completed_at: "2026-05-02T12:30:00+00:00",
    output_path: "/tmp/lucia.onnx",
    error_summary: "",
    cancelled_signalled: false,
  };

  it("parses a complete-state detail with history", () => {
    const parsed = TrainingJobDetailResponseSchema.parse({
      summary,
      history: [
        { status: "pending", progress: 0, samples_generated: 0 },
        { status: "complete", progress: 1.0, samples_generated: 20 },
      ],
      history_truncated: false,
    });
    expect(parsed.summary.status).toBe("complete");
    expect(parsed.history.length).toBe(2);
  });

  it("rejects payloads missing summary", () => {
    expect(() =>
      TrainingJobDetailResponseSchema.parse({
        history: [],
        history_truncated: false,
      }),
    ).toThrow();
  });
});

describe("CancelJobResponseSchema", () => {
  it("parses a successful cancel", () => {
    expect(
      CancelJobResponseSchema.parse({
        job_id: "lucia",
        cancel_signal_written: true,
        already_terminal: false,
      }).already_terminal,
    ).toBe(false);
  });

  it("rejects payloads missing booleans", () => {
    expect(() =>
      CancelJobResponseSchema.parse({ job_id: "lucia" }),
    ).toThrow();
  });
});

// ── Mission v0.30.0 §T1.3 — Train Wake Word UI runtime schemas ──

describe("StartTrainingRequestSchema", () => {
  const valid = {
    wake_word: "Aria",
    mind_id: "aria",
    language: "en",
    target_samples: 200,
    voices: [],
    variants: [],
    negatives_dir: "/data/negatives",
  };

  it("parses a valid request", () => {
    expect(StartTrainingRequestSchema.parse(valid).wake_word).toBe("Aria");
  });

  it("accepts optional fields omitted (use backend defaults)", () => {
    const minimal = {
      wake_word: "Lúcia",
      mind_id: "lucia",
      negatives_dir: "/data/negatives",
    };
    const parsed = StartTrainingRequestSchema.parse(minimal);
    expect(parsed.wake_word).toBe("Lúcia");
  });

  it("rejects target_samples below 100", () => {
    expect(() =>
      StartTrainingRequestSchema.parse({ ...valid, target_samples: 50 }),
    ).toThrow();
  });

  it("rejects target_samples above 10000", () => {
    expect(() =>
      StartTrainingRequestSchema.parse({ ...valid, target_samples: 100_000 }),
    ).toThrow();
  });

  it("rejects empty wake_word", () => {
    expect(() =>
      StartTrainingRequestSchema.parse({ ...valid, wake_word: "" }),
    ).toThrow();
  });

  it("rejects payloads missing required fields", () => {
    expect(() => StartTrainingRequestSchema.parse({})).toThrow();
    const { negatives_dir: _omit, ...withoutNeg } = valid;
    expect(() => StartTrainingRequestSchema.parse(withoutNeg)).toThrow();
  });
});

describe("StartTrainingResponseSchema", () => {
  it("parses a 202 Accepted response", () => {
    const parsed = StartTrainingResponseSchema.parse({
      job_id: "lucia",
      stream_url: "/api/voice/training/jobs/lucia/stream",
    });
    expect(parsed.job_id).toBe("lucia");
    expect(parsed.stream_url).toContain("/stream");
  });

  it("rejects payloads missing fields", () => {
    expect(() => StartTrainingResponseSchema.parse({})).toThrow();
    expect(() =>
      StartTrainingResponseSchema.parse({ job_id: "lucia" }),
    ).toThrow();
  });
});

describe("TrainingJobStreamMessageSchema", () => {
  it("parses a snapshot message", () => {
    const parsed = TrainingJobStreamMessageSchema.parse({
      type: "snapshot",
      state: { status: "synthesizing", progress: 0.5, samples_generated: 100 },
    });
    expect(parsed.type).toBe("snapshot");
    if (parsed.type === "snapshot") {
      expect(parsed.state["status"]).toBe("synthesizing");
    }
  });

  it("parses a terminal message", () => {
    const parsed = TrainingJobStreamMessageSchema.parse({
      type: "terminal",
      state: { status: "complete", progress: 1.0 },
    });
    expect(parsed.type).toBe("terminal");
  });

  it("parses an error message", () => {
    const parsed = TrainingJobStreamMessageSchema.parse({
      type: "error",
      message: "job not found: ghost",
    });
    expect(parsed.type).toBe("error");
    if (parsed.type === "error") {
      expect(parsed.message).toContain("not found");
    }
  });

  it("rejects unknown type values", () => {
    expect(() =>
      TrainingJobStreamMessageSchema.parse({
        type: "unknown",
        state: {},
      }),
    ).toThrow();
  });

  it("rejects snapshot without state field", () => {
    expect(() =>
      TrainingJobStreamMessageSchema.parse({ type: "snapshot" }),
    ).toThrow();
  });
});

// v0.31.6 T3.2 (M3.c) — pin the POST /api/onboarding/complete contract
// so the daemon's defensive ``voice_configured: false`` signal cannot
// silently regress to discarded.

describe("OnboardingCompleteResponseSchema", () => {
  it("accepts the v0.31.4 shape with voice_configured: true", () => {
    const result = OnboardingCompleteResponseSchema.parse({
      ok: true,
      voice_configured: true,
    });
    expect(result.ok).toBe(true);
    expect(result.voice_configured).toBe(true);
  });

  it("accepts the v0.31.4 shape with voice_configured: false", () => {
    const result = OnboardingCompleteResponseSchema.parse({
      ok: true,
      voice_configured: false,
    });
    expect(result.voice_configured).toBe(false);
  });

  it("accepts pre-v0.31.4 shape without voice_configured", () => {
    const result = OnboardingCompleteResponseSchema.parse({ ok: true });
    expect(result.ok).toBe(true);
    expect(result.voice_configured).toBeUndefined();
  });

  it("forwards extra fields via passthrough()", () => {
    const result = OnboardingCompleteResponseSchema.parse({
      ok: true,
      voice_configured: true,
      future_field: "hello",
    });
    expect(result.ok).toBe(true);
    // passthrough() retains unknown keys for forward-compat
    expect((result as { future_field?: string }).future_field).toBe("hello");
  });

  it("rejects when ok is missing", () => {
    expect(() =>
      OnboardingCompleteResponseSchema.parse({ voice_configured: false }),
    ).toThrow();
  });

  it("rejects when voice_configured has wrong type", () => {
    expect(() =>
      OnboardingCompleteResponseSchema.parse({
        ok: true,
        voice_configured: "false",
      }),
    ).toThrow();
  });
});

// ── F2-H02 — VoiceStatusResponseSchema + VoiceModelsResponseSchema ──
//
// These two schemas mirror the backend ``VoiceStatusResponse`` and
// ``VoiceModelsResponse`` Pydantic models in
// ``src/sovyx/dashboard/routes/voice.py``. ``pages/voice.tsx`` now wires
// them into ``api.get`` via ``{ schema }`` so backend response-shape
// drift surfaces as a structured ``api.schema_mismatch`` warning instead
// of silently degrading the UI.

import {
  VoiceModelsResponseSchema,
  VoiceStatusResponseSchema,
} from "./schemas";

const SAMPLE_VOICE_STATUS = {
  pipeline: { running: true, state: "idle", latency_ms: 42 },
  capture: {
    running: true,
    input_device: "Built-in Microphone",
    host_api: "WASAPI",
    sample_rate: 16000,
    frames_delivered: 1024,
    last_rms_db: -32.5,
  },
  stt: { engine: "MoonshineSTT", model: "moonshine-tiny", state: "ready" },
  tts: { engine: "PiperTTS", model: "en_US-lessac-medium", initialized: true },
  wake_word: { enabled: true, phrase: "hey sovyx" },
  vad: { enabled: true },
  wyoming: { connected: false, endpoint: null },
  hardware: { tier: "PI5", ram_mb: 4096 },
  preflight_warnings: [],
};

const SAMPLE_VOICE_MODELS = {
  detected_tier: "PI5",
  active: {
    stt_primary: "moonshine-tiny",
    stt_streaming: "moonshine-tiny",
    tts_primary: "piper-lessac",
    tts_quality: "piper-lessac",
    wake: "openwakeword",
    vad: "silero-v5",
  },
  available_tiers: {
    PI5: {
      stt_primary: "moonshine-tiny",
      stt_streaming: "moonshine-tiny",
      tts_primary: "piper-lessac",
      tts_quality: "piper-lessac",
      wake: "openwakeword",
      vad: "silero-v5",
    },
  },
};

describe("VoiceStatusResponseSchema (F2-H02)", () => {
  it("parses the canonical /api/voice/status payload", () => {
    const parsed = VoiceStatusResponseSchema.parse(SAMPLE_VOICE_STATUS);
    expect(parsed.pipeline.running).toBe(true);
    expect(parsed.capture?.last_rms_db).toBe(-32.5);
    expect(parsed.hardware?.tier).toBe("PI5");
  });

  it("safeParse succeeds when an optional sub-block is dropped (vad)", () => {
    // Backend dropping a sub-block (e.g. after a refactor) must not
    // corrupt the UI — safeParse semantics: optional fields silently
    // pass when missing, page continues to render.
    const { vad: _vad, ...withoutVad } = SAMPLE_VOICE_STATUS;
    const result = VoiceStatusResponseSchema.safeParse(withoutVad);
    expect(result.success).toBe(true);
  });

  it("safeParse succeeds when capture sub-fields are unknown (passthrough)", () => {
    // Backend's VoiceStatusCapture is `extra: allow` — new SLI
    // fields must round-trip without rejection.
    const drifted = {
      ...SAMPLE_VOICE_STATUS,
      capture: {
        ...SAMPLE_VOICE_STATUS.capture,
        future_sli_field: "ok",
      },
    };
    const result = VoiceStatusResponseSchema.safeParse(drifted);
    expect(result.success).toBe(true);
  });

  it("safeParse fails when pipeline.running has wrong type", () => {
    const broken = {
      ...SAMPLE_VOICE_STATUS,
      pipeline: { running: "true", state: "idle" },
    };
    const result = VoiceStatusResponseSchema.safeParse(broken);
    expect(result.success).toBe(false);
  });

  it("safeParse fails when pipeline block is missing entirely", () => {
    const { pipeline: _pipeline, ...broken } = SAMPLE_VOICE_STATUS;
    const result = VoiceStatusResponseSchema.safeParse(broken);
    expect(result.success).toBe(false);
  });

  // ── Mission C2 §T1.4 — int variant of capture.input_device ──
  //
  // The backend pydantic boundary pre-v0.44.2 was narrowed to
  // ``str | None``; the PortAudio device-index int (the steady-state
  // shape after capture opens — operator's Razer at idx=7 per the
  // v0.43.1 forensic audit) round-tripped through zod fine but 500'd
  // at the pydantic boundary. Post-mission both layers accept the
  // union. These tests pin the zod contract so a future narrowing
  // of ``VoiceStatusCaptureSchema.input_device`` surfaces here.
  //
  // Mission: docs-internal/missions/MISSION-c2-voice-status-response-contract-2026-05-16.md §T1.4

  it("safeParse accepts capture.input_device as integer (C2 prod shape)", () => {
    const intShape = {
      ...SAMPLE_VOICE_STATUS,
      capture: {
        ...SAMPLE_VOICE_STATUS.capture,
        input_device: 7, // ← PortAudio int handle from forensic L1444
      },
    };
    const result = VoiceStatusResponseSchema.safeParse(intShape);
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.capture?.input_device).toBe(7);
    }
  });

  it("safeParse accepts capture.input_device as null (no capture device)", () => {
    const nullShape = {
      ...SAMPLE_VOICE_STATUS,
      capture: { ...SAMPLE_VOICE_STATUS.capture, input_device: null },
    };
    const result = VoiceStatusResponseSchema.safeParse(nullShape);
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.capture?.input_device).toBeNull();
    }
  });

  it("safeParse rejects capture.input_device as boolean (outside union)", () => {
    // Guards against the union accidentally widening to ``any``
    // during a future refactor — zod must reject shapes that are
    // NEITHER int nor str nor null.
    const boolShape = {
      ...SAMPLE_VOICE_STATUS,
      capture: { ...SAMPLE_VOICE_STATUS.capture, input_device: true },
    };
    const result = VoiceStatusResponseSchema.safeParse(boolShape);
    expect(result.success).toBe(false);
  });
});

describe("VoiceModelsResponseSchema (F2-H02)", () => {
  it("parses the canonical /api/voice/models payload", () => {
    const parsed = VoiceModelsResponseSchema.parse(SAMPLE_VOICE_MODELS);
    expect(parsed.detected_tier).toBe("PI5");
    expect(parsed.active?.stt_primary).toBe("moonshine-tiny");
  });

  it("safeParse succeeds when active is null (no auto-selection yet)", () => {
    const result = VoiceModelsResponseSchema.safeParse({
      ...SAMPLE_VOICE_MODELS,
      active: null,
    });
    expect(result.success).toBe(true);
  });

  it("safeParse fails when an active selection field has wrong type", () => {
    const broken = {
      ...SAMPLE_VOICE_MODELS,
      active: {
        ...SAMPLE_VOICE_MODELS.active,
        stt_primary: 42,
      },
    };
    const result = VoiceModelsResponseSchema.safeParse(broken);
    expect(result.success).toBe(false);
  });

  it("safeParse succeeds with empty available_tiers map", () => {
    const result = VoiceModelsResponseSchema.safeParse({
      ...SAMPLE_VOICE_MODELS,
      available_tiers: {},
    });
    expect(result.success).toBe(true);
  });
});

// Mission C3 §T2.9 — failover-history zod twin tests.

describe("FailoverHistoryResponseSchema (Mission C3 §T2.9)", () => {
  it("safeParse accepts empty history", () => {
    const result = FailoverHistoryResponseSchema.safeParse({
      entries: [],
      ring_capacity: 32,
    });
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.entries).toEqual([]);
      expect(result.data.ring_capacity).toBe(32);
    }
  });

  it("safeParse accepts a 3-candidate exhausted ladder", () => {
    const candidates = [
      {
        index: 0,
        target_endpoint: "hd-audio-generic",
        target_friendly_name: "HD-Audio Generic",
        verdict: "failed" as const,
        error_class: "unopenable_this_boot",
        error_detail: "AlsaOpen failed",
        elapsed_ms: 1050,
        skipped_reason: null,
      },
      {
        index: 1,
        target_endpoint: "pipewire-virtual",
        target_friendly_name: "pipewire",
        verdict: "skipped" as const,
        error_class: "unopenable_this_boot",
        error_detail: "",
        elapsed_ms: null,
        skipped_reason: "probe_cache_unopenable",
      },
      {
        index: 2,
        target_endpoint: "os-default",
        target_friendly_name: "OS Default",
        verdict: "failed" as const,
        error_class: "transient_retryable_same_device",
        error_detail: "",
        elapsed_ms: 320,
        skipped_reason: null,
      },
    ];
    const entry = {
      ladder_id: "abc123def456",
      started_monotonic: 1000.0,
      completed_monotonic: 1001.5,
      verdict: "exhausted" as const,
      candidates_tried: 3,
      succeeded_index: null,
      candidates,
      from_endpoint: "razer-blackshark-v2-pro",
      elapsed_ms: 1500,
      derived_reason: "vad_frontend_dead",
      mind_id: "jonny",
    };
    const result = FailoverHistoryResponseSchema.safeParse({
      entries: [entry],
      ring_capacity: 32,
    });
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.entries[0]?.verdict).toBe("exhausted");
      expect(result.data.entries[0]?.candidates.length).toBe(3);
    }
  });

  it("safeParse accepts succeeded ladder with succeeded_index", () => {
    const entry = {
      ladder_id: "good00000001",
      started_monotonic: 100.0,
      completed_monotonic: 100.3,
      verdict: "succeeded" as const,
      candidates_tried: 2,
      succeeded_index: 1,
      candidates: [
        {
          index: 0,
          target_endpoint: "dev_a",
          verdict: "failed" as const,
          error_class: "unopenable_this_boot",
          elapsed_ms: 100,
        },
        {
          index: 1,
          target_endpoint: "dev_b",
          verdict: "succeeded" as const,
          elapsed_ms: 50,
        },
      ],
      ring_capacity: 32,
    };
    const result = FailoverHistoryEntrySchema.safeParse(entry);
    expect(result.success).toBe(true);
  });

  it("safeParse rejects invalid verdict literal", () => {
    const broken = {
      entries: [
        {
          ladder_id: "abc",
          started_monotonic: 1,
          verdict: "completely_made_up_verdict",
          candidates: [],
        },
      ],
      ring_capacity: 32,
    };
    const result = FailoverHistoryResponseSchema.safeParse(broken);
    expect(result.success).toBe(false);
  });

  it("safeParse accepts extra forward-additive fields (passthrough)", () => {
    const result = FailoverHistoryResponseSchema.safeParse({
      entries: [],
      ring_capacity: 16,
      future_field_for_c4: "banner_dismissed",
    });
    expect(result.success).toBe(true);
  });
});
