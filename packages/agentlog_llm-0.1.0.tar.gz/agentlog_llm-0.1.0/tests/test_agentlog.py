"""
Tests for agentlog-llm — no LLM API needed.
"""
import pytest
import time
from agentlog import AgentTracer, AgentTrace, LLMCall, ToolCall
from agentlog.costs import calc_cost


# ── Cost Tests ────────────────────────────────────────────────────────────────

class TestCosts:

    def test_known_model_cost(self):
        cost = calc_cost("gpt-4o", tokens_in=1000, tokens_out=500)
        assert abs(cost - 0.0075) < 0.0001

    def test_unknown_model_uses_default(self):
        cost = calc_cost("unknown-model", tokens_in=1000, tokens_out=1000)
        assert cost > 0

    def test_zero_tokens(self):
        assert calc_cost("gpt-4o", 0, 0) == 0.0

    def test_gemini_cost(self):
        cost = calc_cost("gemini-2.5-flash", tokens_in=1000, tokens_out=1000)
        assert cost > 0


# ── AgentTracer Tests ─────────────────────────────────────────────────────────

class TestAgentTracer:

    def test_basic_trace(self):
        tracer = AgentTracer("test-agent", task="Test task")
        trace = tracer.finish(success=True)
        assert trace.agent_name == "test-agent"
        assert trace.task == "Test task"
        assert trace.success is True
        assert trace.ended_at is not None

    def test_llm_call_logged(self):
        tracer = AgentTracer("test-agent")
        with tracer.llm_call("openai", "gpt-4o", prompt="Hello") as call:
            call.response = "Hi there!"
            call.tokens_in = 5
            call.tokens_out = 3

        trace = tracer.finish()
        assert trace.total_llm_calls == 1
        assert trace.llm_calls[0].response == "Hi there!"
        assert trace.llm_calls[0].tokens_in == 5
        assert trace.llm_calls[0].tokens_out == 3

    def test_llm_call_auto_cost(self):
        tracer = AgentTracer("test-agent")
        with tracer.llm_call("openai", "gpt-4o") as call:
            call.tokens_in = 1000
            call.tokens_out = 500

        trace = tracer.finish()
        assert trace.total_cost_usd > 0

    def test_tool_call_logged(self):
        tracer = AgentTracer("test-agent")
        with tracer.tool_call("search", inputs={"query": "AI news"}) as tool:
            tool.output = ["result1", "result2"]

        trace = tracer.finish()
        assert trace.total_tool_calls == 1
        assert trace.tool_calls[0].tool_name == "search"
        assert trace.tool_calls[0].output == ["result1", "result2"]

    def test_multiple_steps(self):
        tracer = AgentTracer("test-agent")
        with tracer.llm_call("openai", "gpt-4o") as call:
            call.tokens_in = 100
            call.tokens_out = 50

        with tracer.tool_call("calculator", inputs={"expr": "2+2"}) as tool:
            tool.output = 4

        with tracer.llm_call("openai", "gpt-4o") as call:
            call.tokens_in = 200
            call.tokens_out = 100

        trace = tracer.finish()
        assert len(trace.steps) == 3
        assert trace.total_llm_calls == 2
        assert trace.total_tool_calls == 1

    def test_total_tokens(self):
        tracer = AgentTracer("test-agent")
        with tracer.llm_call("openai", "gpt-4o") as call:
            call.tokens_in = 100
            call.tokens_out = 50

        with tracer.llm_call("openai", "gpt-4o") as call:
            call.tokens_in = 200
            call.tokens_out = 100

        trace = tracer.finish()
        assert trace.total_tokens == 450  # 100+50+200+100

    def test_log_custom_step(self):
        tracer = AgentTracer("test-agent")
        tracer.log("Decided to use tool A", step_type="decision")
        trace = tracer.finish()
        assert len(trace.steps) == 1
        assert trace.steps[0].step_type == "decision"
        assert "tool A" in trace.steps[0].description

    def test_latency_tracked(self):
        tracer = AgentTracer("test-agent")
        with tracer.llm_call("openai", "gpt-4o") as call:
            time.sleep(0.01)
            call.tokens_in = 10
            call.tokens_out = 5

        trace = tracer.finish()
        assert trace.llm_calls[0].latency_ms >= 10

    def test_error_in_llm_call(self):
        tracer = AgentTracer("test-agent")
        with pytest.raises(ValueError):
            with tracer.llm_call("openai", "gpt-4o") as call:
                raise ValueError("API error")

        trace = tracer.finish(success=False, error="API error")
        assert trace.llm_calls[0].error == "API error"
        assert trace.success is False

    def test_finish_with_error(self):
        tracer = AgentTracer("test-agent")
        trace = tracer.finish(success=False, error="Something failed")
        assert trace.success is False
        assert trace.error == "Something failed"

    def test_summary_structure(self):
        tracer = AgentTracer("test-agent", task="My task")
        with tracer.llm_call("openai", "gpt-4o") as call:
            call.tokens_in = 100
            call.tokens_out = 50
        with tracer.tool_call("search") as tool:
            tool.output = "result"

        trace = tracer.finish(success=True)
        summary = trace.summary()

        assert summary["agent"] == "test-agent"
        assert summary["task"] == "My task"
        assert summary["llm_calls"] == 1
        assert summary["tool_calls"] == 1
        assert summary["success"] is True
        assert "total_cost_usd" in summary
        assert "total_tokens" in summary

    def test_to_dict(self):
        tracer = AgentTracer("test-agent")
        tracer.finish()
        d = tracer.to_dict()
        assert isinstance(d, dict)
        assert "agent_name" in d
        assert "steps" in d

    def test_to_json(self):
        import json
        tracer = AgentTracer("test-agent")
        tracer.finish()
        j = tracer.to_json()
        parsed = json.loads(j)
        assert parsed["agent_name"] == "test-agent"

    def test_trace_tool_decorator(self):
        tracer = AgentTracer("test-agent")

        @tracer.trace_tool("multiply")
        def multiply(a: int, b: int) -> int:
            return a * b

        result = multiply(3, 4)
        assert result == 12

        trace = tracer.finish()
        assert trace.total_tool_calls == 1
        assert trace.tool_calls[0].tool_name == "multiply"
        assert trace.tool_calls[0].output == 12

    def test_metadata_attached(self):
        tracer = AgentTracer("test-agent", metadata={"env": "test"})
        trace = tracer.finish(metadata={"version": "1.0"})
        assert trace.metadata["env"] == "test"
        assert trace.metadata["version"] == "1.0"
