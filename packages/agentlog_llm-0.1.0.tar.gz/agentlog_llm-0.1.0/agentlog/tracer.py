"""
AgentTracer — the main interface for logging agent execution.

Usage:
    tracer = AgentTracer("my-agent", task="Summarize documents")

    with tracer.llm_call("openai", "gpt-4o", prompt="...") as call:
        response = openai_client.chat(...)
        call.response = response.text
        call.tokens_in = response.usage.prompt_tokens
        call.tokens_out = response.usage.completion_tokens

    with tracer.tool_call("search", inputs={"query": "..."}) as tool:
        result = search(query)
        tool.output = result

    trace = tracer.finish(success=True)
    print(trace.summary())
"""
import time
import functools
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Callable, Optional

from .models import AgentTrace, AgentStep, LLMCall, ToolCall
from .costs import calc_cost


class AgentTracer:
    """
    Trace an AI agent's execution — LLM calls, tool calls, decisions.

    All data stays in memory. Export to dict/JSON when done.
    """

    def __init__(self, agent_name: str, task: str = "", metadata: dict | None = None):
        self.trace = AgentTrace(
            agent_name=agent_name,
            task=task,
            metadata=metadata or {},
        )

    # ── LLM Call Context Manager ──────────────────────────────────────────────

    @contextmanager
    def llm_call(
        self,
        provider: str,
        model: str,
        prompt: str = "",
        description: str = "",
        auto_cost: bool = True,
        metadata: dict | None = None,
    ):
        """
        Context manager for logging an LLM call.

        Usage:
            with tracer.llm_call("openai", "gpt-4o", prompt=my_prompt) as call:
                response = client.chat(...)
                call.response = response.text
                call.tokens_in = response.usage.prompt_tokens
                call.tokens_out = response.usage.completion_tokens
        """
        call = LLMCall(
            provider=provider,
            model=model,
            prompt=prompt,
            metadata=metadata or {},
        )
        start = time.time()
        error = None

        try:
            yield call
        except Exception as e:
            error = str(e)
            call.error = error
            raise
        finally:
            call.latency_ms = round((time.time() - start) * 1000, 2)
            if auto_cost and not call.cost_usd:
                call.cost_usd = calc_cost(model, call.tokens_in, call.tokens_out)

            step = AgentStep(
                step_type="llm_call",
                description=description or f"LLM call: {provider}/{model}",
                llm_call=call,
            )
            self.trace.steps.append(step)

    # ── Tool Call Context Manager ─────────────────────────────────────────────

    @contextmanager
    def tool_call(
        self,
        tool_name: str,
        inputs: dict | None = None,
        description: str = "",
        metadata: dict | None = None,
    ):
        """
        Context manager for logging a tool/function call.

        Usage:
            with tracer.tool_call("web_search", inputs={"query": "..."}) as tool:
                result = search(query)
                tool.output = result
        """
        call = ToolCall(
            tool_name=tool_name,
            inputs=inputs or {},
            metadata=metadata or {},
        )
        start = time.time()

        try:
            yield call
        except Exception as e:
            call.error = str(e)
            raise
        finally:
            call.latency_ms = round((time.time() - start) * 1000, 2)
            step = AgentStep(
                step_type="tool_call",
                description=description or f"Tool call: {tool_name}",
                tool_call=call,
            )
            self.trace.steps.append(step)

    # ── Manual Step Logging ───────────────────────────────────────────────────

    def log(self, description: str, step_type: str = "custom", metadata: dict | None = None):
        """Log a custom step (decision, observation, etc.)"""
        step = AgentStep(
            step_type=step_type,
            description=description,
            metadata=metadata or {},
        )
        self.trace.steps.append(step)

    # ── Decorators ────────────────────────────────────────────────────────────

    def trace_tool(self, tool_name: str | None = None):
        """
        Decorator to automatically trace a tool function.

        Usage:
            @tracer.trace_tool("calculator")
            def calculate(expression: str) -> float:
                return eval(expression)
        """
        def decorator(fn: Callable) -> Callable:
            name = tool_name or fn.__name__

            @functools.wraps(fn)
            def wrapper(*args, **kwargs):
                inputs = {
                    **{f"arg_{i}": a for i, a in enumerate(args)},
                    **kwargs,
                }
                with self.tool_call(name, inputs=inputs) as call:
                    result = fn(*args, **kwargs)
                    call.output = result
                return result
            return wrapper
        return decorator

    # ── Finish ────────────────────────────────────────────────────────────────

    def finish(
        self,
        success: bool = True,
        error: str | None = None,
        metadata: dict | None = None,
    ) -> AgentTrace:
        """
        Finalize the trace and return it.

        Args:
            success: Whether the agent completed successfully
            error:   Error message if failed
            metadata: Any extra data to attach

        Returns:
            The complete AgentTrace
        """
        self.trace.ended_at = datetime.now(timezone.utc).isoformat()
        self.trace.success = success
        self.trace.error = error
        if metadata:
            self.trace.metadata.update(metadata)
        return self.trace

    # ── Export ────────────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        """Export the current trace as a dictionary."""
        import dataclasses
        return dataclasses.asdict(self.trace)

    def to_json(self, indent: int = 2) -> str:
        """Export the current trace as JSON string."""
        import json
        import dataclasses
        return json.dumps(dataclasses.asdict(self.trace), indent=indent)

    def save(self, path: str) -> None:
        """Save the trace to a JSON file."""
        with open(path, "w") as f:
            f.write(self.to_json())
