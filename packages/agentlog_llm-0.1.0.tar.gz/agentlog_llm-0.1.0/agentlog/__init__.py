"""
agentlog-llm — Trace AI agent execution: LLM calls, tool calls, costs, latency.

Quick start:
    from agentlog import AgentTracer

    tracer = AgentTracer("my-agent", task="Summarize documents")

    with tracer.llm_call("openai", "gpt-4o", prompt="Summarize this...") as call:
        response = openai_client.chat(...)
        call.response = response.text
        call.tokens_in = response.usage.prompt_tokens
        call.tokens_out = response.usage.completion_tokens

    with tracer.tool_call("search", inputs={"query": "AI news"}) as tool:
        result = search("AI news")
        tool.output = result

    tracer.log("Decided to summarize top 3 results")

    trace = tracer.finish(success=True)
    print(trace.summary())
    print(f"Total cost: ${trace.total_cost_usd}")
    print(f"Total tokens: {trace.total_tokens}")
"""

from .tracer import AgentTracer
from .models import AgentTrace, AgentStep, LLMCall, ToolCall
from .costs import calc_cost

__version__ = "0.1.0"
__all__ = [
    "AgentTracer",
    "AgentTrace",
    "AgentStep",
    "LLMCall",
    "ToolCall",
    "calc_cost",
]
