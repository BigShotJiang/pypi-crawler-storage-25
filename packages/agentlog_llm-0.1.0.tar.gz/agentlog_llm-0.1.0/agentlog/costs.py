COST_PER_1K: dict[str, dict[str, float]] = {
    "gpt-4o":              {"in": 0.0025,   "out": 0.010},
    "gpt-4o-mini":         {"in": 0.00015,  "out": 0.0006},
    "gpt-4-turbo":         {"in": 0.010,    "out": 0.030},
    "gpt-3.5-turbo":       {"in": 0.0005,   "out": 0.0015},
    "claude-opus-4":       {"in": 0.015,    "out": 0.075},
    "claude-sonnet-4":     {"in": 0.003,    "out": 0.015},
    "claude-haiku-4":      {"in": 0.00025,  "out": 0.00125},
    "claude-3-5-sonnet":   {"in": 0.003,    "out": 0.015},
    "gemini-2.5-pro":      {"in": 0.00125,  "out": 0.005},
    "gemini-2.5-flash":    {"in": 0.00015,  "out": 0.0006},
    "gemini-1.5-pro":      {"in": 0.00125,  "out": 0.005},
    "gemini-1.5-flash":    {"in": 0.000075, "out": 0.0003},
    "default":             {"in": 0.001,    "out": 0.002},
}


def calc_cost(model: str, tokens_in: int, tokens_out: int) -> float:
    key = next((k for k in COST_PER_1K if model.lower().startswith(k)), "default")
    rates = COST_PER_1K[key]
    return round((tokens_in / 1000) * rates["in"] + (tokens_out / 1000) * rates["out"], 8)
