from dataclasses import dataclass, field
from typing import Any, Optional
from datetime import datetime, timezone
import uuid


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()

def _uid() -> str:
    return str(uuid.uuid4())[:8]


@dataclass
class LLMCall:
    """A single LLM API call made by the agent."""
    call_id: str = field(default_factory=_uid)
    provider: str = ""
    model: str = ""
    prompt: str = ""
    response: str = ""
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0
    latency_ms: float = 0.0
    timestamp: str = field(default_factory=_now)
    error: Optional[str] = None
    metadata: dict = field(default_factory=dict)


@dataclass
class ToolCall:
    """A tool/function call made by the agent."""
    call_id: str = field(default_factory=_uid)
    tool_name: str = ""
    inputs: dict = field(default_factory=dict)
    output: Any = None
    latency_ms: float = 0.0
    timestamp: str = field(default_factory=_now)
    error: Optional[str] = None
    metadata: dict = field(default_factory=dict)


@dataclass
class AgentStep:
    """One step in the agent's execution trace."""
    step_id: str = field(default_factory=_uid)
    step_type: str = ""        # "llm_call" | "tool_call" | "decision" | "custom"
    description: str = ""
    llm_call: Optional[LLMCall] = None
    tool_call: Optional[ToolCall] = None
    timestamp: str = field(default_factory=_now)
    metadata: dict = field(default_factory=dict)


@dataclass
class AgentTrace:
    """Complete trace of an agent's execution."""
    trace_id: str = field(default_factory=_uid)
    agent_name: str = ""
    task: str = ""
    steps: list[AgentStep] = field(default_factory=list)
    started_at: str = field(default_factory=_now)
    ended_at: Optional[str] = None
    success: Optional[bool] = None
    error: Optional[str] = None
    metadata: dict = field(default_factory=dict)

    # ── Computed properties ───────────────────────────────────────────────────

    @property
    def total_llm_calls(self) -> int:
        return sum(1 for s in self.steps if s.llm_call)

    @property
    def total_tool_calls(self) -> int:
        return sum(1 for s in self.steps if s.tool_call)

    @property
    def total_tokens(self) -> int:
        return sum(
            (s.llm_call.tokens_in + s.llm_call.tokens_out)
            for s in self.steps if s.llm_call
        )

    @property
    def total_cost_usd(self) -> float:
        return round(sum(s.llm_call.cost_usd for s in self.steps if s.llm_call), 8)

    @property
    def total_latency_ms(self) -> float:
        llm = sum(s.llm_call.latency_ms for s in self.steps if s.llm_call)
        tool = sum(s.tool_call.latency_ms for s in self.steps if s.tool_call)
        return round(llm + tool, 2)

    @property
    def llm_calls(self) -> list[LLMCall]:
        return [s.llm_call for s in self.steps if s.llm_call]

    @property
    def tool_calls(self) -> list[ToolCall]:
        return [s.tool_call for s in self.steps if s.tool_call]

    def summary(self) -> dict:
        return {
            "trace_id": self.trace_id,
            "agent": self.agent_name,
            "task": self.task,
            "steps": len(self.steps),
            "llm_calls": self.total_llm_calls,
            "tool_calls": self.total_tool_calls,
            "total_tokens": self.total_tokens,
            "total_cost_usd": self.total_cost_usd,
            "total_latency_ms": self.total_latency_ms,
            "success": self.success,
        }
