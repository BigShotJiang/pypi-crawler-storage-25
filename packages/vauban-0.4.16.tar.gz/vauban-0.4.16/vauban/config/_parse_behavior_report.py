# SPDX-FileCopyrightText: 2026 Teilo Millet
# SPDX-License-Identifier: Apache-2.0

"""Parse the [behavior_report] section of a TOML config."""

from __future__ import annotations

from typing import TYPE_CHECKING

from vauban.behavior import (
    AccessLevel,
    AccessPolicy,
    ActivationFinding,
    BehaviorClaim,
    BehaviorExample,
    BehaviorMetric,
    BehaviorReport,
    BehaviorSuiteRef,
    ClaimStatus,
    ClaimStrength,
    EvidenceKind,
    EvidenceRef,
    ExampleRedaction,
    FindingSeverity,
    InterventionEffect,
    InterventionKind,
    InterventionPolarity,
    InterventionResult,
    MetricPolarity,
    ModelRole,
    ReportModelRef,
    ReproducibilityInfo,
    ReproductionResult,
    ReproductionTarget,
    TransformationKind,
    TransformationRef,
    compare_behavior_metrics,
)
from vauban.config._parse_helpers import SectionReader, require_toml_table
from vauban.types import BehaviorReportConfig

if TYPE_CHECKING:
    from vauban.config._types import TomlDict

_POLARITY_CHOICES: tuple[MetricPolarity, ...] = (
    "higher_is_better",
    "lower_is_better",
    "neutral",
)
_MODEL_ROLE_CHOICES: tuple[ModelRole, ...] = (
    "baseline",
    "candidate",
    "reference",
    "intervention",
)
_SEVERITY_CHOICES: tuple[FindingSeverity, ...] = (
    "info",
    "low",
    "medium",
    "high",
    "critical",
)
_REDACTION_CHOICES: tuple[ExampleRedaction, ...] = (
    "safe",
    "redacted",
    "omitted",
)
_TRANSFORMATION_KIND_CHOICES: tuple[TransformationKind, ...] = (
    "fine_tune",
    "reinforcement_fine_tune",
    "checkpoint_update",
    "prompt_template",
    "quantization",
    "merge",
    "adapter_merge",
    "steering",
    "endpoint_update",
    "evaluation_only",
    "other",
)
_ACCESS_LEVEL_CHOICES: tuple[AccessLevel, ...] = (
    "single_snapshot",
    "paired_outputs",
    "logprobs",
    "weights",
    "activations",
    "base_and_transformed",
)
_CLAIM_STRENGTH_CHOICES: tuple[ClaimStrength, ...] = (
    "behavioral_profile",
    "black_box_behavioral_diff",
    "distributional_diff",
    "weight_diff",
    "activation_diagnostic",
    "model_change_audit",
)
_CLAIM_STATUS_CHOICES: tuple[ClaimStatus, ...] = (
    "planned",
    "replicated",
    "partially_replicated",
    "not_replicated",
    "inconclusive",
    "extended",
)
_EVIDENCE_KIND_CHOICES: tuple[EvidenceKind, ...] = (
    "suite",
    "trace",
    "metric",
    "run_report",
    "logprobs",
    "activation",
    "weights",
    "paper",
    "manual_review",
    "other",
)
_INTERVENTION_KIND_CHOICES: tuple[InterventionKind, ...] = (
    "activation_steering",
    "activation_ablation",
    "activation_addition",
    "weight_projection",
    "weight_arithmetic",
    "prompt_template",
    "sampling",
    "other",
)
_INTERVENTION_EFFECT_CHOICES: tuple[InterventionEffect, ...] = (
    "increased",
    "decreased",
    "mixed",
    "no_observed_change",
    "inconclusive",
)
_INTERVENTION_POLARITY_CHOICES: tuple[InterventionPolarity, ...] = (
    "positive",
    "negative",
    "bidirectional",
    "control",
    "other",
)


def _parse_behavior_report(raw: TomlDict) -> BehaviorReportConfig | None:
    """Parse the optional [behavior_report] section."""
    sec = raw.get("behavior_report")
    if sec is None:
        return None
    reader = SectionReader(
        "[behavior_report]",
        require_toml_table("[behavior_report]", sec),
    )

    title = reader.string("title", default="Model Behavior Change Report")
    markdown_report = reader.boolean("markdown_report", default=True)
    json_filename = reader.string("json_filename", default="behavior_report.json")
    markdown_filename = reader.string(
        "markdown_filename",
        default="behavior_report.md",
    )

    baseline = _parse_model_ref(
        reader.data.get("baseline"),
        "[behavior_report.baseline]",
        default_role="baseline",
    )
    candidate = _parse_model_ref(
        reader.data.get("candidate"),
        "[behavior_report.candidate]",
        default_role="candidate",
    )
    suite = _parse_suite_ref(reader.data.get("suite"))
    metrics = tuple(_parse_metrics(reader.data.get("metrics")))
    metric_deltas = compare_behavior_metrics(
        tuple(metric for metric in metrics if metric.model_label == baseline.label),
        tuple(metric for metric in metrics if metric.model_label == candidate.label),
    )

    report = BehaviorReport(
        title=title,
        baseline=baseline,
        candidate=candidate,
        suite=suite,
        target_change=reader.optional_string("target_change"),
        transformation=_parse_transformation(reader.data.get("transformation")),
        access=_parse_access(reader.data.get("access")),
        claims=tuple(_parse_claims(reader.data.get("claims"))),
        evidence=tuple(_parse_evidence_refs(reader.data.get("evidence"))),
        findings=tuple(reader.string_list("findings", default=[])),
        metrics=metrics,
        metric_deltas=metric_deltas,
        activation_findings=tuple(
            _parse_activation_findings(reader.data.get("activation_findings")),
        ),
        examples=tuple(_parse_examples(reader.data.get("examples"))),
        reproduction_targets=tuple(
            _parse_reproduction_targets(reader.data.get("reproduction_targets")),
        ),
        reproduction_results=tuple(
            _parse_reproduction_results(reader.data.get("reproduction_results")),
        ),
        intervention_results=tuple(
            _parse_intervention_results(reader.data.get("intervention_results")),
        ),
        limitations=tuple(reader.string_list("limitations", default=[])),
        recommendation=reader.optional_string("recommendation"),
        reproducibility=_parse_reproducibility(
            reader.data.get("reproducibility"),
        ),
    )
    return BehaviorReportConfig(
        report=report,
        markdown_report=markdown_report,
        json_filename=json_filename,
        markdown_filename=markdown_filename,
    )


def _parse_model_ref(
    raw: object,
    section: str,
    *,
    default_role: ModelRole,
) -> ReportModelRef:
    """Parse a report model reference table."""
    reader = SectionReader(section, require_toml_table(section, raw))
    return ReportModelRef(
        label=reader.string("label"),
        model_path=reader.string("model_path"),
        role=reader.literal("role", _MODEL_ROLE_CHOICES, default=default_role),
        checkpoint=reader.optional_string("checkpoint"),
        adapter_path=reader.optional_string("adapter_path"),
        prompt_template=reader.optional_string("prompt_template"),
        quantization=reader.optional_string("quantization"),
    )


def _parse_suite_ref(raw: object) -> BehaviorSuiteRef:
    """Parse the report suite metadata table."""
    section = "[behavior_report.suite]"
    reader = SectionReader(section, require_toml_table(section, raw))
    return BehaviorSuiteRef(
        name=reader.string("name"),
        description=reader.string("description"),
        categories=tuple(reader.string_list("categories")),
        metrics=tuple(reader.string_list("metrics")),
        version=reader.optional_string("version"),
        source=reader.optional_string("source"),
        safety_policy=reader.string(
            "safety_policy",
            default="aggregate_or_redacted_examples",
        ),
    )


def _parse_transformation(raw: object) -> TransformationRef | None:
    """Parse optional [behavior_report.transformation] metadata."""
    if raw is None:
        return None
    section = "[behavior_report.transformation]"
    reader = SectionReader(section, require_toml_table(section, raw))
    return TransformationRef(
        kind=reader.literal("kind", _TRANSFORMATION_KIND_CHOICES),
        summary=reader.string("summary"),
        before=reader.optional_string("before"),
        after=reader.optional_string("after"),
        method=reader.optional_string("method"),
        source_ref=reader.optional_string("source_ref"),
        notes=tuple(reader.string_list("notes", default=[])),
    )


def _parse_access(raw: object) -> AccessPolicy | None:
    """Parse optional [behavior_report.access] epistemic boundary."""
    if raw is None:
        return None
    section = "[behavior_report.access]"
    reader = SectionReader(section, require_toml_table(section, raw))
    return AccessPolicy(
        level=reader.literal("level", _ACCESS_LEVEL_CHOICES),
        claim_strength=reader.literal(
            "claim_strength",
            _CLAIM_STRENGTH_CHOICES,
        ),
        available_evidence=tuple(
            reader.string_list("available_evidence", default=[]),
        ),
        missing_evidence=tuple(reader.string_list("missing_evidence", default=[])),
        notes=tuple(reader.string_list("notes", default=[])),
    )


def _parse_evidence_refs(raw: object) -> list[EvidenceRef]:
    """Parse optional [[behavior_report.evidence]] entries."""
    rows = _array_of_tables("[[behavior_report.evidence]]", raw, allow_empty=True)
    return [
        _parse_evidence_ref(row, f"[[behavior_report.evidence]][{index}]")
        for index, row in enumerate(rows)
    ]


def _parse_evidence_ref(raw: TomlDict, section: str) -> EvidenceRef:
    """Parse one report evidence reference."""
    reader = SectionReader(section, raw)
    return EvidenceRef(
        evidence_id=_required_alias_string(reader, section, "evidence_id", "id"),
        kind=reader.literal("kind", _EVIDENCE_KIND_CHOICES),
        path_or_url=_optional_any_string(reader, ("path_or_url", "path", "url")),
        description=reader.optional_string("description"),
    )


def _parse_claims(raw: object) -> list[BehaviorClaim]:
    """Parse optional [[behavior_report.claims]] entries."""
    rows = _array_of_tables("[[behavior_report.claims]]", raw, allow_empty=True)
    return [
        _parse_claim(row, f"[[behavior_report.claims]][{index}]")
        for index, row in enumerate(rows)
    ]


def _parse_claim(raw: TomlDict, section: str) -> BehaviorClaim:
    """Parse one access-aware report claim."""
    reader = SectionReader(section, raw)
    return BehaviorClaim(
        claim_id=_required_alias_string(reader, section, "claim_id", "id"),
        statement=reader.string("statement"),
        strength=reader.literal(
            "strength",
            _CLAIM_STRENGTH_CHOICES,
            default="behavioral_profile",
        ),
        access_level=reader.literal(
            "access_level",
            _ACCESS_LEVEL_CHOICES,
            default="single_snapshot",
        ),
        status=reader.literal("status", _CLAIM_STATUS_CHOICES, default="planned"),
        evidence=tuple(reader.string_list("evidence", default=[])),
        limitations=tuple(reader.string_list("limitations", default=[])),
    )


def _parse_reproduction_targets(raw: object) -> list[ReproductionTarget]:
    """Parse optional [[behavior_report.reproduction_targets]] entries."""
    rows = _array_of_tables(
        "[[behavior_report.reproduction_targets]]",
        raw,
        allow_empty=True,
    )
    return [
        _parse_reproduction_target(
            row,
            f"[[behavior_report.reproduction_targets]][{index}]",
        )
        for index, row in enumerate(rows)
    ]


def _parse_reproduction_target(
    raw: TomlDict,
    section: str,
) -> ReproductionTarget:
    """Parse one reproduction target entry."""
    reader = SectionReader(section, raw)
    return ReproductionTarget(
        target_id=_required_alias_string(reader, section, "target_id", "id"),
        title=reader.string("title"),
        source_url=reader.optional_string("source_url"),
        original_claim=reader.string("original_claim"),
        planned_extension=reader.string("planned_extension"),
        status=reader.literal("status", _CLAIM_STATUS_CHOICES, default="planned"),
        notes=tuple(reader.string_list("notes", default=[])),
    )


def _parse_reproduction_results(raw: object) -> list[ReproductionResult]:
    """Parse optional [[behavior_report.reproduction_results]] entries."""
    rows = _array_of_tables(
        "[[behavior_report.reproduction_results]]",
        raw,
        allow_empty=True,
    )
    return [
        _parse_reproduction_result(
            row,
            f"[[behavior_report.reproduction_results]][{index}]",
        )
        for index, row in enumerate(rows)
    ]


def _parse_reproduction_result(
    raw: TomlDict,
    section: str,
) -> ReproductionResult:
    """Parse one observed reproduction result entry."""
    reader = SectionReader(section, raw)
    return ReproductionResult(
        target_id=reader.string("target_id"),
        status=reader.literal("status", _CLAIM_STATUS_CHOICES),
        summary=reader.string("summary"),
        replicated_claims=tuple(
            reader.string_list("replicated_claims", default=[]),
        ),
        failed_claims=tuple(reader.string_list("failed_claims", default=[])),
        extensions=tuple(reader.string_list("extensions", default=[])),
        evidence=tuple(reader.string_list("evidence", default=[])),
        limitations=tuple(reader.string_list("limitations", default=[])),
    )


def _parse_intervention_results(raw: object) -> list[InterventionResult]:
    """Parse optional [[behavior_report.intervention_results]] entries."""
    rows = _array_of_tables(
        "[[behavior_report.intervention_results]]",
        raw,
        allow_empty=True,
    )
    return [
        _parse_intervention_result(
            row,
            f"[[behavior_report.intervention_results]][{index}]",
        )
        for index, row in enumerate(rows)
    ]


def _parse_intervention_result(
    raw: TomlDict,
    section: str,
) -> InterventionResult:
    """Parse one controlled intervention result entry."""
    reader = SectionReader(section, raw)
    return InterventionResult(
        intervention_id=_required_alias_string(
            reader,
            section,
            "intervention_id",
            "id",
        ),
        kind=reader.literal("kind", _INTERVENTION_KIND_CHOICES),
        summary=reader.string("summary"),
        target=reader.string("target"),
        effect=reader.literal(
            "effect",
            _INTERVENTION_EFFECT_CHOICES,
            default="inconclusive",
        ),
        polarity=reader.literal(
            "polarity",
            _INTERVENTION_POLARITY_CHOICES,
            default="other",
        ),
        layers=tuple(reader.int_list("layers", default=[])),
        strength=reader.optional_number("strength"),
        baseline_condition=reader.optional_string("baseline_condition"),
        intervention_condition=reader.optional_string("intervention_condition"),
        behavior_metric=reader.optional_string("behavior_metric"),
        activation_metric=reader.optional_string("activation_metric"),
        evidence=tuple(reader.string_list("evidence", default=[])),
        limitations=tuple(reader.string_list("limitations", default=[])),
    )


def _parse_metrics(raw: object) -> list[BehaviorMetric]:
    """Parse [[behavior_report.metrics]] entries."""
    rows = _array_of_tables("[[behavior_report.metrics]]", raw, allow_empty=True)
    return [
        _parse_metric(row, f"[[behavior_report.metrics]][{index}]")
        for index, row in enumerate(rows)
    ]


def _parse_metric(raw: TomlDict, section: str) -> BehaviorMetric:
    """Parse one behavior metric table."""
    reader = SectionReader(section, raw)
    model_label = reader.optional_string("model_label")
    if model_label is None:
        model_label = reader.optional_string("model")
    if model_label is None:
        msg = f"{section}.model_label is required"
        raise ValueError(msg)
    sample_size = reader.optional_integer("sample_size")
    if sample_size is not None and sample_size < 0:
        msg = f"{section}.sample_size must be >= 0"
        raise ValueError(msg)
    return BehaviorMetric(
        name=reader.string("name"),
        value=reader.number("value"),
        model_label=model_label,
        category=reader.optional_string("category"),
        unit=reader.string("unit", default="ratio"),
        polarity=reader.literal("polarity", _POLARITY_CHOICES, default="neutral"),
        family=reader.string("family", default="behavior"),
        sample_size=sample_size,
        notes=reader.optional_string("notes"),
    )


def _parse_activation_findings(raw: object) -> list[ActivationFinding]:
    """Parse optional [[behavior_report.activation_findings]] entries."""
    rows = _array_of_tables(
        "[[behavior_report.activation_findings]]",
        raw,
        allow_empty=True,
    )
    return [
        _parse_activation_finding(
            row,
            f"[[behavior_report.activation_findings]][{index}]",
        )
        for index, row in enumerate(rows)
    ]


def _parse_activation_finding(
    raw: TomlDict,
    section: str,
) -> ActivationFinding:
    """Parse one activation finding table."""
    reader = SectionReader(section, raw)
    return ActivationFinding(
        name=reader.string("name"),
        summary=reader.string("summary"),
        layers=tuple(reader.int_list("layers", default=[])),
        score=reader.optional_number("score"),
        metric_name=reader.optional_string("metric_name"),
        direction_label=reader.optional_string("direction_label"),
        severity=reader.literal("severity", _SEVERITY_CHOICES, default="info"),
        evidence=tuple(reader.string_list("evidence", default=[])),
    )


def _parse_examples(raw: object) -> list[BehaviorExample]:
    """Parse optional [[behavior_report.examples]] entries."""
    rows = _array_of_tables("[[behavior_report.examples]]", raw, allow_empty=True)
    return [
        _parse_example(row, f"[[behavior_report.examples]][{index}]")
        for index, row in enumerate(rows)
    ]


def _parse_example(raw: TomlDict, section: str) -> BehaviorExample:
    """Parse one representative example table."""
    reader = SectionReader(section, raw)
    example_id = reader.optional_string("example_id")
    if example_id is None:
        example_id = reader.optional_string("id")
    if example_id is None:
        msg = f"{section}.example_id is required"
        raise ValueError(msg)
    return BehaviorExample(
        example_id=example_id,
        category=reader.string("category"),
        prompt=reader.string("prompt"),
        baseline_response=reader.optional_string("baseline_response"),
        candidate_response=reader.optional_string("candidate_response"),
        redaction=reader.literal(
            "redaction",
            _REDACTION_CHOICES,
            default="redacted",
        ),
        note=reader.optional_string("note"),
    )


def _parse_reproducibility(raw: object) -> ReproducibilityInfo | None:
    """Parse optional [behavior_report.reproducibility] table."""
    if raw is None:
        return None
    section = "[behavior_report.reproducibility]"
    reader = SectionReader(section, require_toml_table(section, raw))
    seed = reader.optional_integer("seed")
    if seed is not None and seed < 0:
        msg = f"{section}.seed must be >= 0"
        raise ValueError(msg)
    return ReproducibilityInfo(
        command=reader.string("command"),
        config_path=reader.optional_string("config_path"),
        code_revision=reader.optional_string("code_revision"),
        data_refs=tuple(reader.string_list("data_refs", default=[])),
        output_dir=reader.optional_string("output_dir"),
        seed=seed,
        notes=tuple(reader.string_list("notes", default=[])),
    )


def _required_alias_string(
    reader: SectionReader,
    section: str,
    primary: str,
    alias: str,
) -> str:
    """Read a required string that may use a primary key or alias."""
    value = reader.optional_string(primary)
    if value is not None:
        return value
    value = reader.optional_string(alias)
    if value is not None:
        return value
    msg = f"{section}.{primary} is required"
    raise ValueError(msg)


def _optional_any_string(
    reader: SectionReader,
    keys: tuple[str, ...],
) -> str | None:
    """Read the first present optional string from a list of aliases."""
    for key in keys:
        value = reader.optional_string(key)
        if value is not None:
            return value
    return None


def _array_of_tables(
    section: str,
    raw: object,
    *,
    allow_empty: bool,
) -> list[TomlDict]:
    """Read one optional or required TOML array of tables."""
    if raw is None:
        if allow_empty:
            return []
        msg = f"{section} must be a non-empty array of tables"
        raise ValueError(msg)
    if not isinstance(raw, list) or (not raw and not allow_empty):
        msg = f"{section} must be a non-empty array of tables"
        raise ValueError(msg)
    return [
        require_toml_table(f"{section}[{index}]", item)
        for index, item in enumerate(raw)
    ]
