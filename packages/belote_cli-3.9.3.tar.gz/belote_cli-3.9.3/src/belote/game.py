from __future__ import annotations

import random
from dataclasses import dataclass, field, replace
from enum import Enum
from functools import lru_cache
from typing import Final, Literal

from .deck import Card, Contract, Rank, Suit, make_deck, trick_rank
from .deck import deal as deal_cards_
from .deck import shuffle as shuffle_deck_

# Sentinel for the Sans Atout contract at the bidding API boundary.
# `Suit.TOUT_ATOUT` already exists for Tout Atout. Sans Atout has no card-suit
# equivalent (no card has this "suit"), so the bid value is the string literal
# `"sans_atout"`. Post-bid this is encoded as `state.trump=None` plus
# `state.contract="sans_atout"` — `state.contract` is the authoritative carrier
# of contract identity from PLAYING onward.
SANS_ATOUT_BID: Literal["sans_atout"] = "sans_atout"
BidValue = Suit | Literal["sans_atout"] | None

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class Phase(Enum):
    DEAL = "DEAL"
    BIDDING = "BIDDING"
    PLAYING = "PLAYING"
    SCORING = "SCORING"
    GAME_OVER = "GAME_OVER"


class IllegalMoveError(Exception):
    """Raised when a player attempts an illegal play."""

    pass


class Seat(Enum):
    SOUTH = 0
    EAST = 1
    NORTH = 2
    WEST = 3

    def next_seat(self) -> Seat:
        return Seat((self.value + 1) % 4)

    def prev_seat(self) -> Seat:
        return Seat((self.value - 1) % 4)

    @property
    def name(self) -> str:
        match self:
            case Seat.SOUTH:
                return "South"
            case Seat.EAST:
                return "East"
            case Seat.NORTH:
                return "North"
            case Seat.WEST:
                return "West"

    @property
    def label(self) -> str:
        if self == Seat.SOUTH:
            return "You"
        return self.name


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def team_of(seat: Seat) -> int:
    """0 = NS, 1 = EW."""
    return 0 if seat in (Seat.SOUTH, Seat.NORTH) else 1


def partner(seat: Seat) -> Seat:
    if seat == Seat.SOUTH:
        return Seat.NORTH
    if seat == Seat.NORTH:
        return Seat.SOUTH
    if seat == Seat.EAST:
        return Seat.WEST
    return Seat.EAST


# ---------------------------------------------------------------------------
# Declaration types
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Sequence:
    length: int
    top_rank: int  # numeric rank value (higher = better)
    suit: Suit
    is_trump: bool
    cards: tuple[Card, ...]


@dataclass(frozen=True, slots=True)
class Carre:
    rank: int  # numeric rank value
    cards: tuple[Card, ...]


@dataclass(frozen=True, slots=True)
class BeloteDecl:
    cards: tuple[Card, ...]  # K+Q of trump


@dataclass(frozen=True, slots=True)
class Declaration:
    seat: Seat
    kind: Literal["belote", "rebelote", "sequence", "carre"]
    detail: Sequence | Carre | BeloteDecl | None = None


# ---------------------------------------------------------------------------
# GameState
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class TrickCard:
    seat: Seat
    card: Card


@dataclass(frozen=True, slots=True)
class RoundScore:
    taker_team: int
    ns_card_pts: int
    ew_card_pts: int
    ns_decl_pts: int
    ew_decl_pts: int
    ns_belote_pts: int
    ew_belote_pts: int
    ns_rebelote: bool
    ew_rebelote: bool
    ns_total: int
    ew_total: int
    is_failed: bool
    is_capot: bool
    is_litige: bool = False
    litige_points: int = 0
    contract: str | None = None
    trump: Suit | None = None
    taker_seat: Seat | None = None
    tricks_ns: int = 0
    tricks_ew: int = 0
    last_trick_winner: Seat | None = None
    decl_summary_ns: tuple[str, ...] = ()
    decl_summary_ew: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class BossModifiers:
    """Boss-modifier flags injected by drive_round when a boss blind is active."""
    no_belote: bool = False
    dynamic_trump: bool = False
    no_consecutive_team_wins: bool = False
    seven_eight_trump: bool = False
    invert_scoring: bool = False
    kings_zero: bool = False
    auto_coinche: bool = False
    queen_spades_penalty: bool = False
    hide_hud: bool = False
    ban_clubs: bool = False
    no_dix_de_der: bool = False
    tens_zero: bool = False
    hide_partner_hand: bool = False
    agent_double_active: bool = False
    agent_double_late_only: bool = False
    partner_forced_pass: bool = False
    lock_trust_zero: bool = False
    separate_scoring: bool = False
    # 3.0.0: three new boss flags (Le Sauvage, L'Iconoclaste, Le Mime).
    aces_zero: bool = False
    jacks_zero: bool = False
    declarations_zero: bool = False


@dataclass(frozen=True, slots=True)
class GameState:
    hands: tuple[tuple[Card, ...], ...]
    initial_hands: tuple[tuple[Card, ...], ...] = field(default_factory=lambda: ((), (), (), ()))
    trump: Suit | None = None
    contract: str | None = None
    dealer: Seat = Seat.SOUTH
    leader: Seat = Seat.SOUTH
    turn: Seat = Seat.SOUTH
    phase: Phase = Phase.DEAL
    bids: tuple[BidValue, ...] = field(default_factory=tuple)
    taker: Seat | None = None
    current_trick: tuple[TrickCard, ...] = field(default_factory=tuple)
    completed_tricks: tuple[tuple[TrickCard, ...], ...] = field(default_factory=tuple)
    last_trick_winner: Seat | None = None
    declarations: tuple[Declaration, ...] = field(default_factory=tuple)
    team_scores: tuple[int, int] = (0, 0)
    current_round_points: tuple[int, int] = (0, 0)
    score_history: tuple[RoundScore, ...] = field(default_factory=tuple)
    target: int = 1000
    up_card: Card | None = None
    remaining_cards: tuple[Card, ...] = field(default_factory=tuple)
    bidder_index: int = 0
    bidding_round: int = 1
    announced: str | None = None
    # Mutable dict held inside a `frozen=True` GameState. Contract: always
    # rebuild via `dataclasses.replace(state, belote_holders=new_dict)` —
    # never mutate in place. The `frozen` guarantee covers the field
    # reference, not the dict contents.
    belote_holders: dict[Suit, Seat] = field(default_factory=dict)
    belote_tracker: tuple[bool, bool] = (False, False)
    # Set when belote_tracker[0] first flips True — captures *which seat*
    # announced belote at the moment of announcement. Needed because the
    # L'Anarchie boss rotates state.trump mid-round, which would otherwise
    # make the scoring-side `belote_holders.get(state.trump)` lookup return
    # the wrong seat (or None) for a belote that was announced on the
    # original trump.
    belote_announcer: Seat | None = None
    # Captured at the same moment as `belote_announcer` — the trump suit at
    # the time belote was first announced. Under L'Anarchie (`dynamic_trump`)
    # `state.trump` rotates every 2 tricks, so the K/Q played second may not
    # match the *current* trump when scoring fires; we match against the
    # captured original trump instead. None outside a belote window.
    belote_trump: Suit | None = None
    first_trick_done: bool = False
    litige_points: int = 0

    boss_modifiers: BossModifiers = field(default_factory=BossModifiers)

    # Same mutable-dict-inside-frozen contract as `belote_holders`. BelAtro
    # jokers and the round driver write per-round flags here. Values must be
    # scalars (bool/int/str) — see tests/belatro/test_phase1_plumbing.py
    # `test_joker_state_only_contains_scalar_values`.
    _joker_state: dict[str, object] = field(default_factory=dict)
    _chips: int = 0
    _mult: float = 1.0
    _bonus_money: int = 0
    _rng: random.Random = field(default_factory=random.Random, compare=False, repr=False)

    def hand_of(self, seat: Seat) -> tuple[Card, ...]:
        return self.hands[seat.value]

    @property
    def current_bidder(self) -> Seat:
        return get_bidder(self.dealer, self.bidder_index)


# ---------------------------------------------------------------------------
# Pure transitions
# ---------------------------------------------------------------------------


def reset_round_fields(state: GameState, **kwargs: object) -> GameState:
    """Return a new state with round-specific fields reset to defaults."""
    reset_values: dict[str, object] = {
        "trump": None,
        "taker": None,
        "current_trick": (),
        "completed_tricks": (),
        "last_trick_winner": None,
        "bids": (),
        "bidder_index": 0,
        "current_round_points": (0, 0),
        "declarations": (),
        "announced": None,
        "belote_tracker": (False, False),
        "belote_announcer": None,
        "belote_trump": None,
        "first_trick_done": False,
        "boss_modifiers": BossModifiers(),
    }
    reset_values.update(kwargs)
    return replace(state, **reset_values)  # type: ignore[arg-type]


def new_game(target: int = 1000) -> GameState:
    return GameState(
        hands=((), (), (), ()),
        target=target,
    )


def start_round(state: GameState, rng: random.Random) -> GameState:
    """Deal cards and start bidding phase."""
    deck = shuffle_deck(rng)
    initial_hands, up_card, remaining = deal_cards(deck)
    dealer = state.dealer
    first_bidder = dealer.next_seat()  # bidding starts left of dealer

    return reset_round_fields(
        state,
        hands=initial_hands,
        initial_hands=initial_hands,
        leader=first_bidder,
        turn=first_bidder,
        phase=Phase.BIDDING,
        up_card=up_card,
        remaining_cards=remaining,
        bidding_round=1,
        belote_holders={},
        _rng=rng,
    )


def shuffle_deck(rng: random.Random) -> tuple[Card, ...]:
    return shuffle_deck_(make_deck(), rng)


def deal_cards(
    deck: tuple[Card, ...],
) -> tuple[tuple[tuple[Card, ...], ...], Card, tuple[Card, ...]]:
    return deal_cards_(deck)


def get_bidder(dealer: Seat, index: int) -> Seat:
    """Get the seat of the bidder at the given index."""
    start = dealer.next_seat()
    return Seat((start.value + index) % 4)


def bidding_turn(state: GameState) -> Seat:
    """Return the seat whose turn it is to bid."""
    return get_bidder(state.dealer, state.bidder_index)


def process_bid(state: GameState, bid: BidValue) -> GameState:
    """Process a bid and return the new state."""
    return place_bid(state, bid)


def _distribute_remaining_cards(state: GameState, taker: Seat) -> list[list[Card]]:
    """Helper to distribute remaining 11 cards after bidding is finished.
    Taker gets up-card + 2 more. Others get 3 more.
    """
    new_hands = [list(h) for h in state.hands]
    pool = list(state.remaining_cards)
    pool_idx = 0

    # Ordering: from dealer.next_seat() around the table (same as bidding order)
    for i in range(4):
        s = get_bidder(state.dealer, i)
        if s == taker:
            new_hands[s.value].append(state.up_card)  # type: ignore[arg-type]
            # Taker only needs 2 more
            new_hands[s.value].extend(pool[pool_idx : pool_idx + 2])
            pool_idx += 2
        else:
            # Others need 3 more
            new_hands[s.value].extend(pool[pool_idx : pool_idx + 3])
            pool_idx += 3

    if pool_idx != len(pool):
        raise ValueError(
            f"Deal corruption: {pool_idx} cards distributed from {len(pool)} available"
        )

    return new_hands


def place_bid(state: GameState, bid: BidValue) -> GameState:
    """Process a bid from the current bidder.

    `bid` is one of:
    - `None` → pass
    - `Suit.SPADES`/`HEARTS`/`DIAMONDS`/`CLUBS` → normal contract
    - `Suit.TOUT_ATOUT` → Tout Atout (round 2 only)
    - `"sans_atout"` → Sans Atout (round 2 only)

    TA and SA in round 1 raise `IllegalMoveError` — round 1 is "take the
    up-card suit at the standard contract" only.
    """
    is_special = bid == Suit.TOUT_ATOUT or bid == SANS_ATOUT_BID
    if is_special and state.bidding_round == 1:
        raise IllegalMoveError(
            "Tout Atout / Sans Atout can only be bid in round 2"
        )

    new_bids = state.bids + (bid,)

    if bid is not None:
        # Someone chose trump
        taker = get_bidder(state.dealer, state.bidder_index)

        # Distribute remaining 11 cards
        new_hands = _distribute_remaining_cards(state, taker)

        if not all(len(h) == 8 for h in new_hands):
            raise ValueError(f"Deal corruption: Hands lengths {[len(h) for h in new_hands]}")

        # Map bid → (trump, contract). State.contract is the authoritative
        # contract identity; state.trump is the trump *suit* (None for SA, the
        # special TOUT_ATOUT marker for TA, a normal suit otherwise).
        if bid == SANS_ATOUT_BID:
            new_trump: Suit | None = None
            new_contract: str = Contract.SANS_ATOUT
        elif bid == Suit.TOUT_ATOUT:
            new_trump = Suit.TOUT_ATOUT
            new_contract = Contract.TOUT_ATOUT
        else:
            assert isinstance(bid, Suit)
            new_trump = bid
            new_contract = Contract.NORMAL

        # Pre-calculate belote holders. Belote = K+Q of trump. There is no
        # unique K+Q-of-trump under TA (every suit acts as trump) or SA (no
        # trump at all), so belote is disabled for both contracts. 3.6.0
        # (audit L1): single-pass per hand — previously rebuilt a set of all
        # (rank,suit) pairs then re-iterated 4 suits, 5× more work than
        # tracking which suits saw a King and which saw a Queen.
        belote_holders: dict[Suit, Seat] = {}
        if new_contract == Contract.NORMAL:
            for s_idx in range(4):
                seat = Seat(s_idx)
                king_suits: set[Suit] = set()
                queen_suits: set[Suit] = set()
                for c in new_hands[s_idx]:
                    if c.rank == Rank.KING:
                        king_suits.add(c.suit)
                    elif c.rank == Rank.QUEEN:
                        queen_suits.add(c.suit)
                for suit in king_suits & queen_suits:
                    belote_holders[suit] = seat

        # Pre-calculate declarations
        from .scoring import get_declarations

        # initial_hands stores the 8-card hands at start of play (not the 5-card deal),
        # used by score_round for declaration detection after cards are played out.
        temp_state = replace(
            state,
            hands=tuple(tuple(h) for h in new_hands),
            initial_hands=tuple(tuple(h) for h in new_hands),
            bids=new_bids,
            trump=new_trump,
            contract=new_contract,
            taker=taker,
            phase=Phase.PLAYING,
        )
        decls = get_declarations(temp_state)

        return replace(
            temp_state,
            leader=state.dealer.next_seat(),  # Standard: left of dealer leads
            turn=state.dealer.next_seat(),
            up_card=None,
            remaining_cards=(),
            belote_holders=belote_holders,
            declarations=decls,
        )
    # Pass
    next_index = state.bidder_index + 1
    if next_index >= 4:
        if state.bidding_round == 1:
            # Move to round 2
            return replace(
                state,
                bids=(),
                bidder_index=0,
                bidding_round=2,
                turn=state.dealer.next_seat(),
            )
        # All passed round 2 -> redeal
        return replace(
            state,
            bids=(),
            dealer=state.dealer.next_seat(),
            phase=Phase.DEAL,
            bidder_index=0,
            bidding_round=1,
        )
    next_bidder = get_bidder(state.dealer, next_index)
    return replace(
        state,
        bids=new_bids,
        turn=next_bidder,
        bidder_index=next_index,
    )


# ---------------------------------------------------------------------------
# Trick play / caching
# ---------------------------------------------------------------------------

_CARD_TO_ID: Final = {c: i for i, c in enumerate(make_deck())}
_ID_TO_CARD: Final = {v: k for k, v in _CARD_TO_ID.items()}


def clear_legal_cards_cache() -> None:
    """Clear the legal cards cache."""
    _calculate_legal_cards_impl.cache_clear()
    _trick_winner_seat_impl.cache_clear()


@lru_cache(maxsize=2048)
def _calculate_legal_cards_impl(
    hand_ids: tuple[int, ...],
    trump: Suit | None,
    current_trick_ids: tuple[tuple[int, int], ...],
    seat_val: int,
    seven_eight_trump: bool = False,
    is_sans_atout: bool = False,
) -> tuple[int, ...]:
    """Calculate legal cards using card IDs (memoized).

    Cache-key analysis (3.5.0 P2 investigation): the key uses small-int IDs
    rather than Card objects, which is already the minimal hashable surface.
    Benchmarks (`scripts/benchmark.py::benchmark_legal_cards{_cached,}`) show
    cold ~9μs / warm ~6μs — the 33% gap is dominated by KEY BUILD in
    `legal_cards()` (above), not by lru_cache lookup. Slimming further would
    require caching `hand_ids` on the hand tuple itself, which isn't
    achievable without changing the hand representation.

    `is_sans_atout` discriminates the Sans Atout contract from "no trump set
    yet" (both have trump=None). Under SA, the player must follow the lead
    suit if able; if void, free discard (no trumping concept).
    """
    # Map IDs back to Cards for logic
    hand = tuple(_ID_TO_CARD[i] for i in hand_ids)
    seat = Seat(seat_val)

    if not current_trick_ids:
        return hand_ids

    if is_sans_atout:
        lead_suit = _ID_TO_CARD[current_trick_ids[0][1]].suit
        my_suit = tuple(c for c in hand if c.suit == lead_suit)
        res = my_suit if my_suit else hand
        return tuple(_CARD_TO_ID[c] for c in res)

    if trump is None:
        return hand_ids

    # Reconstruct TrickCard-like objects for the internal logic if needed,
    # but we can just use the IDs.
    lead_card_id = current_trick_ids[0][1]
    lead_card = _ID_TO_CARD[lead_card_id]
    lead_suit = lead_card.suit

    # Who is currently winning the trick?
    played_cards = [
        TrickCard(Seat(s), _ID_TO_CARD[c]) for s, c in current_trick_ids if s != seat_val
    ]

    current_winner = _current_trick_winner(
        played_cards, trump, lead_suit, seven_eight_trump, is_sans_atout
    )
    partner_winning = current_winner is not None and partner(seat) == current_winner

    my_suit_cards = [c for c in hand if c.suit == lead_suit]

    res_cards: tuple[Card, ...] = ()

    # Tout Atout: every suit acts as trump within its own led-suit group. Must
    # follow the lead suit if able and must rise within it; if void, discard
    # freely (off-suit cards never beat the lead suit, so there's no "trump
    # over" to force). Partner-winning gives no extra flexibility — the rise
    # rule applies regardless of who's winning, since rising is the only way
    # to beat opponents within the lead suit.
    if trump == Suit.TOUT_ATOUT:
        if my_suit_cards:
            highest_in_trick = max(
                (
                    trick_rank(tc.card, trump, seven_eight_trump)
                    for tc in played_cards
                    if tc.card.suit == lead_suit
                ),
                default=-1,
            )
            risers = tuple(
                c
                for c in my_suit_cards
                if trick_rank(c, trump, seven_eight_trump) > highest_in_trick
            )
            res_cards = risers or tuple(my_suit_cards)
        else:
            res_cards = hand
        return tuple(_CARD_TO_ID[c] for c in res_cards)

    is_trump_lead = (lead_suit == trump) or (
        seven_eight_trump and lead_card.rank in (Rank.SEVEN, Rank.EIGHT)
    )

    if is_trump_lead:
        # Trump led: must follow if possible, must overtrump if possible
        if my_suit_cards:
            highest_in_trick = max(
                (trick_rank(tc.card, trump, seven_eight_trump) for tc in played_cards), default=-1
            )
            must_overtrump = any(
                trick_rank(c, trump, seven_eight_trump) > highest_in_trick for c in my_suit_cards
            )
            if must_overtrump:
                res_cards = tuple(
                    c
                    for c in my_suit_cards
                    if trick_rank(c, trump, seven_eight_trump) > highest_in_trick
                )
            else:
                res_cards = tuple(my_suit_cards)
        else:
            # Void in trump (led suit) - can only play non-trump
            res_cards = tuple(
                c
                for c in hand
                if c.suit != trump
                and not (seven_eight_trump and c.rank in (Rank.SEVEN, Rank.EIGHT))
            )
    else:
        # Non-trump led
        if my_suit_cards:
            # Must follow suit
            res_cards = tuple(my_suit_cards)
        else:
            # Void in led suit
            if partner_winning:
                # Partner is winning - can discard
                res_cards = hand
            else:
                # Must trump if possible
                my_trumps = [
                    c
                    for c in hand
                    if c.suit == trump or (seven_eight_trump and c.rank in (Rank.SEVEN, Rank.EIGHT))
                ]
                if my_trumps:
                    # Must trump; also must overtrump if possible
                    highest_trump_in_trick = max(
                        (
                            trick_rank(tc.card, trump, seven_eight_trump)
                            for tc in played_cards
                            if tc.card.suit == trump
                            or (seven_eight_trump and tc.card.rank in (Rank.SEVEN, Rank.EIGHT))
                        ),
                        default=-1,
                    )
                    can_overtrump = any(
                        trick_rank(c, trump, seven_eight_trump) > highest_trump_in_trick
                        for c in my_trumps
                    )
                    if can_overtrump:
                        res_cards = tuple(
                            c
                            for c in my_trumps
                            if trick_rank(c, trump, seven_eight_trump) > highest_trump_in_trick
                        )
                    else:
                        res_cards = tuple(my_trumps)
                else:
                    # Can't follow, can't trump - discard
                    res_cards = hand

    return tuple(_CARD_TO_ID[c] for c in res_cards)


def legal_cards(state: GameState, seat: Seat) -> tuple[Card, ...]:
    """Return the set of legal cards for the given seat to play (memoized)."""
    if state.phase != Phase.PLAYING:
        return state.hand_of(seat)

    hand = state.hand_of(seat)
    hand_ids = tuple(_CARD_TO_ID[c] for c in hand)
    trick_ids = tuple((tc.seat.value, _CARD_TO_ID[tc.card]) for tc in state.current_trick)
    se_trump = state.boss_modifiers.seven_eight_trump
    is_sa = state.contract == Contract.SANS_ATOUT

    res_ids = _calculate_legal_cards_impl(
        hand_ids, state.trump, trick_ids, seat.value, se_trump, is_sa
    )
    res_cards = tuple(_ID_TO_CARD[i] for i in res_ids)

    # Le Républicain deck: 7s/8s are wild and always legal in addition to the
    # normal options. Union (preserve order, don't double up).
    if state._joker_state.get("republicain_wild") and state.current_trick:
        existing = set(res_cards)
        wild_extras = tuple(
            c for c in hand if c.rank in (Rank.SEVEN, Rank.EIGHT) and c not in existing
        )
        if wild_extras:
            res_cards = res_cards + wild_extras

    return res_cards


def _current_trick_winner(
    played: list[TrickCard],
    trump: Suit | None,
    lead_suit: Suit,
    seven_eight_trump: bool = False,
    is_sans_atout: bool = False,
) -> Seat | None:
    """Determine who is currently winning the trick based on cards played so far."""
    if not played:
        return None
    best = played[0]
    for tc in played[1:]:
        if _card_beats(tc.card, best.card, trump, lead_suit, seven_eight_trump, is_sans_atout):
            best = tc
    return best.seat


def _card_beats(
    card: Card,
    current_best: Card,
    trump: Suit | None,
    lead_suit: Suit,
    seven_eight_trump: bool = False,
    is_sans_atout: bool = False,
) -> bool:
    """Does card beat current_best?

    Sans Atout: only lead-suit cards can win; among lead-suit cards, the
    higher non-trump rank wins. Off-suit cards never beat the lead-suit hand.
    """
    if is_sans_atout:
        if card.suit == current_best.suit:
            # Both same suit. Use SANS_ATOUT_TRUMP placeholder is wrong; we want
            # the non-trump scale. Pass an unrelated suit so trick_rank treats
            # both as non-trump.
            return _NONTRUMP_RANK[card.rank] > _NONTRUMP_RANK[current_best.rank]
        # Different suits under SA: only the lead-suit card can win.
        return card.suit == lead_suit and current_best.suit != lead_suit

    if card.suit == current_best.suit:
        assert trump is not None  # legal_cards guarantees this for non-SA
        return trick_rank(card, trump, seven_eight_trump) > trick_rank(
            current_best, trump, seven_eight_trump
        )

    # Lead card is usually the first card in the trick.
    # We need to know if the LEAD was a trump (declared or 7/8 in Deluge).
    is_trump_card = (card.suit == trump) or (
        seven_eight_trump and card.rank in (Rank.SEVEN, Rank.EIGHT)
    )
    is_best_trump = (current_best.suit == trump) or (
        seven_eight_trump and current_best.rank in (Rank.SEVEN, Rank.EIGHT)
    )

    if is_trump_card and not is_best_trump:
        return True
    if not is_trump_card and is_best_trump:
        return False

    # Neither are trump (or both are trump but different suits - only possible with 7/8 deluge)
    if is_trump_card and is_best_trump:
        assert trump is not None
        # Both act as trumps, compare their trick_ranks
        return trick_rank(card, trump, seven_eight_trump) > trick_rank(
            current_best, trump, seven_eight_trump
        )

    return card.suit == lead_suit


# Inline copy of deck._NONTRUMP_ORDER so _card_beats can rank lead-suit cards
# under Sans Atout without importing private symbols. Match deck.py:111-121.
_NONTRUMP_RANK: dict[Rank, int] = {
    Rank.SEVEN: 0,
    Rank.EIGHT: 1,
    Rank.NINE: 2,
    Rank.JACK: 3,
    Rank.QUEEN: 4,
    Rank.KING: 5,
    Rank.TEN: 6,
    Rank.ACE: 7,
}


def compute_trick_winners(
    state: GameState,
    trump: Suit | None,
    is_sans_atout: bool,
    tricks: tuple[tuple[TrickCard, ...], ...] | list[tuple[TrickCard, ...]] | None = None,
) -> list[Seat | None]:
    """Resolve the winner of each completed trick, honoring La Rupture.

    La Rupture (`no_consecutive_team_wins`) flips the win to the opposing
    team when a trick's raw winner would be on the same team as the previous
    trick's resolved winner. Without this helper, `play_card` applied Rupture
    to live HUD but the final scoring path re-derived winners from raw
    `trick_winner_seat` — silently restoring the original winner and double-
    crediting the round.

    When `tricks` is None (the default), resolves `state.completed_tricks`.
    Callers building an in-flight trick list (live HUD CAPOT detection on the
    8th trick) may pass an explicit sequence so the same Rupture rule applies
    to the projected final state.
    """
    se_trump = state.boss_modifiers.seven_eight_trump
    rupture = state.boss_modifiers.no_consecutive_team_wins
    source = state.completed_tricks if tricks is None else tricks
    winners: list[Seat | None] = []
    prev_winner: Seat | None = None
    for trick in source:
        w = trick_winner_seat(trick, trump, se_trump, is_sans_atout)
        if (
            rupture
            and prev_winner is not None
            and w is not None
            and team_of(w) == team_of(prev_winner)
        ):
            other_team_cards = [
                tc for tc in trick if team_of(tc.seat) != team_of(prev_winner)
            ]
            if other_team_cards and (trump is not None or is_sans_atout):
                best_other = _current_trick_winner(
                    other_team_cards,
                    trump,
                    trick[0].card.suit,
                    se_trump,
                    is_sans_atout,
                )
                if best_other is not None:
                    w = best_other
        winners.append(w)
        prev_winner = w
    return winners


def trick_winner_seat(
    trick: tuple[TrickCard, ...],
    trump: Suit | None,
    seven_eight_trump: bool = False,
    is_sans_atout: bool = False,
) -> Seat | None:
    """Determine the winner of a completed trick.

    Returns None when the contract isn't established (e.g., during DEAL/BIDDING).
    Sans Atout has trump=None but produces a real winner when is_sans_atout=True.
    """
    if not trick:
        return None
    if trump is None and not is_sans_atout:
        return None

    # Use a primitive-only key for memoization
    trick_ids = tuple((tc.seat.value, _CARD_TO_ID[tc.card]) for tc in trick)
    return _trick_winner_seat_impl(trick_ids, trump, seven_eight_trump, is_sans_atout)


@lru_cache(maxsize=1024)
def _trick_winner_seat_impl(
    trick_ids: tuple[tuple[int, int], ...],
    trump: Suit | None,
    seven_eight_trump: bool = False,
    is_sans_atout: bool = False,
) -> Seat:
    """Internal memoized winner detection using primitives."""
    played = [TrickCard(Seat(s), _ID_TO_CARD[c]) for s, c in trick_ids]
    lead_suit = played[0].card.suit

    res = _current_trick_winner(played, trump, lead_suit, seven_eight_trump, is_sans_atout)
    assert res is not None  # Should not be None if trick_ids is not empty
    return res


@dataclass(frozen=True, slots=True)
class _PlayContext:
    """3.7.1 (D1): bundle of pre-computed values used across play_card helpers.

    Built once at the top of `play_card`; threaded into the per-section
    helpers so they don't each re-derive the same fields off GameState.
    Internal — no public consumers.
    """
    state: GameState
    trump: Suit | None
    is_sa: bool
    se_trump: bool


def _record_belote_announcement(
    ctx: _PlayContext, card: Card
) -> tuple[list[bool], Seat | None, Suit | None, str | None]:
    """Update belote_tracker / belote_announcer / belote_trump if the played
    card triggers a belote or rebelote announcement.

    Returns (belote_tracker, belote_announcer, belote_trump, announced_message).

    L'Anarchie note (3.9.3): `belote_trump` locks in the trump suit *at the
    moment of the first announcement*. The rebelote half then matches the K/Q
    play against that captured suit, not against the rotated `ctx.trump`.
    Without this, playing K-trump in trick 2 and Q-old-trump in trick 3 (after
    L'Anarchie rotates trump at tricks_count % 2 == 0) would silently drop
    the rebelote.
    """
    state = ctx.state
    belote_tracker = list(state.belote_tracker)
    belote_announcer = state.belote_announcer
    belote_trump = state.belote_trump
    announced: str | None = None

    # Once first-belote has fired we lock onto `belote_trump`; otherwise track
    # the current trump (which is also what belote_holders is keyed by at
    # round start, before any rotation).
    effective_trump = belote_trump if belote_tracker[0] else ctx.trump

    if (
        effective_trump
        and state.belote_holders.get(effective_trump) == state.turn
        and not state.boss_modifiers.no_belote
    ):
        is_k_q = (
            card.rank in (Rank.KING, Rank.QUEEN)
            and card.suit == effective_trump
        )
        if is_k_q:
            if not belote_tracker[0]:
                belote_tracker[0] = True
                # Capture the announcing seat *and* the trump at that moment.
                # The seat survives L'Anarchie rotation via belote_announcer;
                # the trump survives via belote_trump (3.9.3).
                belote_announcer = state.turn
                belote_trump = effective_trump
                announced = "Belote!"
            elif not belote_tracker[1]:
                belote_tracker[1] = True
                announced = "Rebelote!"
    return belote_tracker, belote_announcer, belote_trump, announced


def _resolve_trick_winner(
    ctx: _PlayContext, new_trick: tuple[TrickCard, ...]
) -> Seat:
    """Determine the trick winner, applying the La Rupture override.

    La Rupture (`no_consecutive_team_wins`): if the natural winner is on the
    same team as the previous trick's winner, swing the trick to the best
    card of the other team. Raises AssertionError if `trick_winner_seat`
    returns None (invariant violation — 4 cards + trump is set under PLAYING).
    """
    state = ctx.state
    winner = trick_winner_seat(new_trick, ctx.trump, ctx.se_trump, ctx.is_sa)

    if state.boss_modifiers.no_consecutive_team_wins and state.completed_tricks:
        # Use the cached resolved winner (state.last_trick_winner), not the
        # raw trick_winner_seat result from completed_tricks[-1]. play_card
        # stores the *resolved* winner, so reading from state keeps the
        # Rupture chain consistent with compute_trick_winners (used in final
        # scoring). Pre-3.8.1 the two paths drifted on trick 3+ whenever
        # Rupture flipped trick N-1.
        last_winner = state.last_trick_winner
        if last_winner and winner and team_of(winner) == team_of(last_winner):
            other_team_cards = [
                tc for tc in new_trick if team_of(tc.seat) != team_of(last_winner)
            ]
            if other_team_cards and (ctx.trump or ctx.is_sa):
                best_other = _current_trick_winner(
                    other_team_cards, ctx.trump, new_trick[0].card.suit, ctx.se_trump, ctx.is_sa
                )
                if best_other:
                    winner = best_other

    if winner is None:
        # Unreachable: trick has 4 cards and trump is set (PLAYING phase
        # guarantees both). Surface this as a hard error instead of papering
        # over what would be state corruption.
        raise AssertionError(
            "trick_winner_seat returned None for a complete 4-card trick — "
            "GameState invariant violated."
        )
    return winner


def _compute_live_round_points(
    ctx: _PlayContext,
    new_trick: tuple[TrickCard, ...],
    winner: Seat,
    tricks_count: int,
) -> tuple[int, int]:
    """Live HUD running total: trick points + dix-de-der on trick 8.

    Delegates per-trick points to `scoring.trick_card_points` (canonical
    helper that already applies every boss zero-rank flag, `ban_clubs`,
    and the seven_eight_trump scale) so the HUD cannot drift from the
    eventual round score under multi-boss combos.
    """
    state = ctx.state
    if state.contract is not None:
        # Local import to break the scoring → game cycle.
        from .scoring import trick_card_points
        trick_pts: int = trick_card_points(state, new_trick)
    else:
        trick_pts = 0

    ns_pts, ew_pts = state.current_round_points
    if team_of(winner) == 0:
        ns_pts += trick_pts
    else:
        ew_pts += trick_pts

    # Last trick bonus (suppressed by Le Zéro Final boss).
    if tricks_count == 8 and not state.boss_modifiers.no_dix_de_der:
        if team_of(winner) == 0:
            ns_pts += 10
        else:
            ew_pts += 10
    return ns_pts, ew_pts


def _rotate_dynamic_trump(ctx: _PlayContext, tricks_count: int) -> Suit | None:
    """L'Anarchie boss: rotate trump every 2 tricks (suppressed under SA)."""
    state = ctx.state
    if (
        state.boss_modifiers.dynamic_trump
        and state.contract != Contract.SANS_ATOUT
        and tricks_count % 2 == 0
        and tricks_count < 8
    ):
        possible = [s for s in Suit if s != ctx.trump and s.is_card_suit]
        return state._rng.choice(possible)
    return ctx.trump


def play_card(state: GameState, card: Card) -> GameState:
    """Play a card. Returns new state, possibly advancing trick/round/phase.

    3.7.1 (D1): orchestrator over `_record_belote_announcement`,
    `_resolve_trick_winner`, `_compute_live_round_points`, and
    `_rotate_dynamic_trump`. Behaviour unchanged from 3.6.0.
    """
    legal = legal_cards(state, state.turn)
    if card not in legal:
        raise IllegalMoveError(f"Card {card} is not a legal move for {state.turn.name}")

    # Remove card from the playing seat's hand.
    t = state.turn.value
    old_hand = state.hands[t]
    idx = old_hand.index(card)
    new_hand = old_hand[:idx] + old_hand[idx + 1 :]
    new_hands = state.hands[:t] + (new_hand,) + state.hands[t + 1 :]

    new_trick = state.current_trick + (TrickCard(state.turn, card),)

    ctx = _PlayContext(
        state=state,
        trump=state.trump,
        is_sa=state.contract == Contract.SANS_ATOUT,
        se_trump=state.boss_modifiers.seven_eight_trump,
    )

    # Belote/Rebelote announcement; resets the announced popup each play so it
    # fires exactly once per Belote-or-Rebelote event.
    belote_tracker, belote_announcer, belote_trump, announced = (
        _record_belote_announcement(ctx, card)
    )

    # Mid-trick: just advance the turn.
    if len(new_trick) != 4:
        next_turn = state.turn.next_seat()
        return replace(
            state,
            hands=tuple(new_hands),
            current_trick=new_trick,
            turn=next_turn,
            announced=announced,
            belote_tracker=(belote_tracker[0], belote_tracker[1]),
            belote_announcer=belote_announcer,
            belote_trump=belote_trump,
        )

    # Trick complete: resolve winner (honouring La Rupture override).
    winner = _resolve_trick_winner(ctx, new_trick)

    new_completed = state.completed_tricks + (new_trick,)
    tricks_count = len(new_completed)

    new_round_points = _compute_live_round_points(ctx, new_trick, winner, tricks_count)
    current_trump = _rotate_dynamic_trump(ctx, tricks_count)

    # Round complete after 8 tricks → SCORING phase.
    if tricks_count >= 8:
        return replace(
            state,
            hands=tuple(new_hands),
            current_trick=(),
            completed_tricks=new_completed,
            last_trick_winner=winner,
            leader=winner,
            turn=winner,
            phase=Phase.SCORING,
            announced=announced,
            belote_tracker=(belote_tracker[0], belote_tracker[1]),
            belote_announcer=belote_announcer,
            belote_trump=belote_trump,
            first_trick_done=True,
            current_round_points=new_round_points,
            trump=current_trump,
        )

    # Next trick led by the winner.
    first_trick_done = state.first_trick_done or tricks_count >= 1
    return replace(
        state,
        hands=tuple(new_hands),
        current_trick=(),
        completed_tricks=new_completed,
        last_trick_winner=winner,
        leader=winner,
        turn=winner,
        phase=Phase.PLAYING,
        announced=announced,
        belote_tracker=(belote_tracker[0], belote_tracker[1]),
        belote_announcer=belote_announcer,
        belote_trump=belote_trump,
        first_trick_done=first_trick_done,
        current_round_points=new_round_points,
        trump=current_trump,
    )


def set_announced(state: GameState, msg: str) -> GameState:
    return replace(state, announced=msg)


def clear_announced(state: GameState) -> GameState:
    return replace(state, announced=None)


_SUITS_ORDER: Final = [Suit.SPADES, Suit.HEARTS, Suit.DIAMONDS, Suit.CLUBS]
_TRUMP_RANK_IDX: Final = {
    r: i
    for i, r in enumerate(
        [
            Rank.JACK,
            Rank.NINE,
            Rank.ACE,
            Rank.TEN,
            Rank.KING,
            Rank.QUEEN,
            Rank.EIGHT,
            Rank.SEVEN,
        ]
    )
}
_NORMAL_RANK_IDX: Final = {
    r: i
    for i, r in enumerate(
        [
            Rank.ACE,
            Rank.TEN,
            Rank.KING,
            Rank.QUEEN,
            Rank.JACK,
            Rank.NINE,
            Rank.EIGHT,
            Rank.SEVEN,
        ]
    )
}


def _build_suit_idx(trump: Suit | None) -> dict[Suit, int]:
    suits_order = list(_SUITS_ORDER)
    if trump and trump in suits_order:
        suits_order.remove(trump)
        suits_order.insert(0, trump)
    return {s: i for i, s in enumerate(suits_order)}


# Pre-compute suit→position maps for every possible trump value (None + the
# four card suits + TOUT_ATOUT). sort_hand is called frequently during
# rendering and this keeps the hot path branch-free.
_SUIT_IDX_CACHE: Final[dict[Suit | None, dict[Suit, int]]] = {
    trump: _build_suit_idx(trump) for trump in (None, Suit.TOUT_ATOUT, *_SUITS_ORDER)
}


@lru_cache(maxsize=512)
def sort_hand(hand: tuple[Card, ...], trump: Suit | None) -> tuple[Card, ...]:
    """Sort hand by suit and rank (trump first, then others, honors together).

    3.6.0 (audit P4): cached because the UI render loop hits the same
    `(hand, trump)` pair on every redraw. Benchmark showed ~34% wall-clock
    win on a 400-input pattern. The cache key is bounded: at most 8! / dup
    permutations × 6 trumps, and `lru_cache` is bounded at 512.
    """
    suit_idx = _SUIT_IDX_CACHE.get(trump) or _build_suit_idx(trump)
    # Under Tout Atout every card is trump, so the trump-rank ladder applies
    # to *every* suit. `c.suit == trump` would always be False here because
    # Card.suit is one of SPADES/HEARTS/DIAMONDS/CLUBS — TOUT_ATOUT is a
    # contract-level marker, never a card suit.
    all_trump = trump is Suit.TOUT_ATOUT

    def sort_key(c: Card) -> tuple[int, int]:
        is_trump = all_trump or c.suit == trump
        return (
            suit_idx[c.suit],
            _TRUMP_RANK_IDX[c.rank] if is_trump else _NORMAL_RANK_IDX[c.rank],
        )

    return tuple(sorted(hand, key=sort_key))


def sort_south_hand(state: GameState) -> GameState:
    """Sort South's hand and update state."""
    new_hands = list(state.hands)
    new_hands[Seat.SOUTH.value] = sort_hand(state.hands[Seat.SOUTH.value], state.trump)

    new_initial = list(state.initial_hands)
    if new_initial[Seat.SOUTH.value]:
        new_initial[Seat.SOUTH.value] = sort_hand(
            state.initial_hands[Seat.SOUTH.value], state.trump
        )

    return replace(state, hands=tuple(new_hands), initial_hands=tuple(new_initial))

