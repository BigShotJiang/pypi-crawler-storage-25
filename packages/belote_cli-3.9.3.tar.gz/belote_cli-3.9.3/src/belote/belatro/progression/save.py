from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class Profile:
    """Persistent player profile storing unlocks and statistics."""

    unlocked_ids: list[str] = field(
        default_factory=lambda: ["le_classique", "le_courageux", "l_econome"]
    )
    discovered_items: list[str] = field(default_factory=list)
    stats: dict[str, Any] = field(
        default_factory=lambda: dict.fromkeys(
            ("runs_won", "total_capots", "sans_atout_wins", "tout_atout_wins"), 0
        )
    )

    def is_unlocked(self, item_id: str) -> bool:
        return item_id in self.unlocked_ids

    def unlock(self, item_id: str) -> bool:
        """Returns True if the item was newly unlocked."""
        if item_id not in self.unlocked_ids:
            self.unlocked_ids.append(item_id)
            return True
        return False

    def discover(self, item_id: str) -> bool:
        """Add an item to the collection if not already present."""
        if item_id not in self.discovered_items:
            self.discovered_items.append(item_id)
            return True
        return False


class SaveManager:
    """Handles OS-specific persistence of player profiles."""

    def __init__(self, app_name: str = "belote") -> None:
        self._save_path = self._get_save_path(app_name) / "profile.json"

    def _get_save_path(self, app_name: str) -> Path:
        """Resolve XDG-compliant data path."""
        if os.name == "nt":
            base = Path(os.environ.get("APPDATA", "."))
        else:
            xdg = os.environ.get("XDG_DATA_HOME", "")
            base = Path(xdg) if xdg else Path.home() / ".local" / "share"
        path = base / app_name
        path.mkdir(parents=True, exist_ok=True)
        return path

    def delete_profile(self) -> None:
        """Permanently remove the profile file from disk."""
        if self._save_path.exists():
            self._save_path.unlink()

    SCHEMA_VERSION: int = 1

    def save_profile(self, profile: Profile) -> None:
        import dataclasses
        import tempfile

        payload = {"schema_version": self.SCHEMA_VERSION, **dataclasses.asdict(profile)}
        # Atomic write: dump to a sibling tmp file, fsync, then os.replace
        # which is atomic on POSIX/NTFS. A crash mid-write leaves the original
        # profile.json intact instead of truncating it to invalid JSON.
        directory = self._save_path.parent
        directory.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(
            mode="w", dir=str(directory), prefix=".profile-", suffix=".json.tmp", delete=False
        ) as tf:
            tmp_path = Path(tf.name)
            json.dump(payload, tf, indent=4)
            tf.flush()
            os.fsync(tf.fileno())
        tmp_path.replace(self._save_path)

    def load_profile(self) -> Profile:
        try:
            with self._save_path.open() as f:
                data = json.load(f)
            data = self._migrate(data)
            _default_stats = dict.fromkeys(
                ("runs_won", "total_capots", "sans_atout_wins", "tout_atout_wins"), 0
            )
            # When a saved profile is missing `unlocked_ids` (older saves,
            # manual edits, partial writes), fall back to the Profile
            # dataclass default rather than an empty list — otherwise the
            # player loses their starter unlocks on reload.
            unlocked_ids = (
                list(data["unlocked_ids"])
                if "unlocked_ids" in data
                else Profile().unlocked_ids
            )
            return Profile(
                unlocked_ids=unlocked_ids,
                discovered_items=data.get("discovered_items", []),
                stats={**_default_stats, **data.get("stats", {})},
            )
        except (FileNotFoundError, json.JSONDecodeError):
            return Profile()

    def _migrate(self, data: dict[str, Any]) -> dict[str, Any]:
        """Upgrade older save dicts to the current schema.

        Profiles written before SCHEMA_VERSION existed have no `schema_version`
        key but are otherwise structurally compatible. New keys with sensible
        defaults can be added here as the schema evolves.
        """
        version = int(data.get("schema_version", 0))
        # No structural migrations yet — just normalise the version field.
        if version < self.SCHEMA_VERSION:
            data["schema_version"] = self.SCHEMA_VERSION
        return data
