from __future__ import annotations

from typing import Any

from belote.deck import Rank, Suit, card_points
from belote.game import Seat, team_of

from ...engine.event_bus import BeloteAnnouncedEvent, RoundEndEvent, TrickWonEvent
from ..base import Joker, JokerResult


class LIdeologue(Joker):
    id = "l_ideologue"
    name = "L'Idéologue"
    description = "Only activates on Sans Atout. Jacks score as 20 points each."
    cost = 8
    is_unlockable = True

    def on_trick_won(self, event: TrickWonEvent, state: dict[str, Any]) -> JokerResult | None:
        # Sans Atout has event.trump as None
        if team_of(event.winner) == 0 and event.trump is None:
            jacks = sum(1 for c in event.cards if c.rank == Rank.JACK)
            if jacks > 0:
                # In Sans Atout, Jack is worth 2. We want it to be 20.
                return JokerResult(add_chips=jacks * 18)
        return None


class LeFanatique(Joker):
    id = "le_fanatique"
    name = "Le Fanatique"
    description = "Only activates on Tout Atout. Every trick you win beyond the 4th adds ×1.5 Mult."
    cost = 8
    is_unlockable = True

    def on_round_start(self, state: dict[str, Any]) -> JokerResult | None:
        state[f"{self.id}_wins"] = 0
        return None

    def on_trick_won(self, event: TrickWonEvent, state: dict[str, Any]) -> JokerResult | None:
        # Only activates on Tout Atout (contract set in joker_state via BidMadeEvent)
        if state.get("contract") != "tout_atout":
            return None

        if team_of(event.winner) == 0:
            wins = state.get(f"{self.id}_wins", 0) + 1
            state[f"{self.id}_wins"] = wins
            if wins > 4:
                return JokerResult(times_mult=1.5)
        return None


class LeDiplomate(Joker):
    id = "le_diplomate"
    name = "Le Diplomate"
    description = (
        "Win a trick containing both a King AND Queen of the same suit → that trick scores ×2."
    )
    cost = 7

    def on_trick_won(self, event: TrickWonEvent, state: dict[str, Any]) -> JokerResult | None:
        if team_of(event.winner) == 0:
            suits: dict[Suit, set[Rank]] = {}
            for c in event.cards:
                if c.rank in (Rank.KING, Rank.QUEEN):
                    suits.setdefault(c.suit, set()).add(c.rank)

            for ranks in suits.values():
                if len(ranks) == 2:  # Both King and Queen present
                    return JokerResult(times_mult=2.0)
        return None


class LePatriote(Joker):
    id = "le_patriote"
    name = "Le Patriote"
    description = "All Trump cards score +50% extra points when they win a trick."
    cost = 6

    def on_trick_won(self, event: TrickWonEvent, state: dict[str, Any]) -> JokerResult | None:
        if team_of(event.winner) == 0 and event.trump:
            trump_pts = sum(
                card_points(c, event.trump) for c in event.cards if c.suit == event.trump
            )
            if trump_pts > 0:
                return JokerResult(add_chips=trump_pts // 2)
        return None


class LeRebelle(Joker):
    id = "le_rebelle"
    name = "Le Rebelle"
    description = "The Belote/Rebelote declaration gives ×3 Mult instead of a flat 20 points."
    cost = 8

    def on_belote(
        self, event: BeloteAnnouncedEvent, state: dict[str, Any]
    ) -> JokerResult | None:
        # Belote/Rebelote points (20) are only awarded if both cards are played.
        # Gate on the second event (rebelote) so we only subtract points that
        # the player actually earned.
        if event.seat == Seat.SOUTH and event.is_rebelote:
            return JokerResult(add_chips=-20, times_mult=3.0)
        return None


class LePuriste(Joker):
    id = "le_puriste"
    name = "Le Puriste"
    description = "If you win a round playing Sans Atout, double your cash payout."
    cost = 7

    def on_round_end(self, event: RoundEndEvent, state: dict[str, Any]) -> JokerResult | None:
        # Sans Atout means trump is None. Flag triggers double payout in _play_blind.
        if (
            event.trump is None
            and not event.breakdown.is_failed
            and event.taker_seat in (Seat.SOUTH, Seat.NORTH)
        ):
            state["puriste_triggered"] = True
        return None


class LIllusionniste(Joker):
    id = "lillusionniste"
    name = "L'Illusionniste"
    description = (
        "Jacks of non-trump suits take on the value of Trump Jacks (20 points) for the round."
    )
    cost = 9

    def on_trick_won(self, event: TrickWonEvent, state: dict[str, Any]) -> JokerResult | None:
        if team_of(event.winner) == 0 and event.trump:
            extra_pts = sum(
                18 for c in event.cards if c.rank == Rank.JACK and c.suit != event.trump
            )
            if extra_pts > 0:
                return JokerResult(add_chips=extra_pts)
        return None
