from __future__ import annotations

import random
from abc import ABC, abstractmethod
from dataclasses import replace
from typing import TYPE_CHECKING

from belote.ai import AIPlayer, Difficulty
from belote.deck import Card, Suit
from belote.game import (
    SANS_ATOUT_BID,
    BidValue,
    GameState,
    Phase,
    Seat,
    clear_legal_cards_cache,
    new_game,
    play_card,
    process_bid,
    start_round,
)
from belote.scoring import get_declaration_points, is_capot, score_round

from .event_bus import (
    BeloteAnnouncedEvent,
    BidMadeEvent,
    DeclarationScoredEvent,
    EventBus,
    RoundEndEvent,
    TrickWonEvent,
)

if TYPE_CHECKING:
    from ..core.scoring import ScoreAccumulator
    from ..ghost_run import GhostRecorder
    from ..partner.partner_state import PartnerState
    from ..run.boss import BossModifier


def _ew_should_coinche(state: GameState, rng: random.Random) -> bool:
    """Defender-side AI for the EW seats when NS is taker.

    Light, deterministic heuristic gated by the round's seeded RNG so
    behaviour is reproducible under a fixed seed (matters for ghost runs
    and replays). Baseline 20% rate; bumps to 35% if either defender holds
    2+ honour cards (Jack/Ace) — a strong defending hand suggests the NS
    contract is over-bid. Added in 3.6.0 to close audit H1 (Libra planet
    was unreachable in natural play because no path ever set
    coinche_level > 0 when NS was taker).
    """
    from belote.deck import Rank

    honors = {Rank.JACK, Rank.ACE}
    rate = 0.20
    for seat in (Seat.EAST, Seat.WEST):
        hand = state.hand_of(seat)
        if sum(1 for c in hand if c.rank in honors) >= 2:
            rate = 0.35
            break
    return rng.random() < rate


class RoundUICallbacks(ABC):
    """Interface for UI interaction during a round."""

    @abstractmethod
    def prompt_bid(self, state: GameState) -> Suit | None: ...

    @abstractmethod
    def prompt_card(self, state: GameState) -> tuple[Card, GameState]: ...

    @abstractmethod
    def on_card_played(self, state: GameState, seat: Seat, card: Card) -> None: ...

    @abstractmethod
    def on_trick_end(self, state: GameState, winner: Seat, points: int) -> None: ...

    @abstractmethod
    def on_round_end(self, breakdown: object) -> None: ...

    def prompt_coinche(self, state: GameState, taker: Seat) -> bool:
        """Ask the player whether to coinche the AI's bid.

        Default no-op returns False. Override in concrete UI (e.g. BelAtro main).
        """
        return False

    def prompt_surcoinche(self, state: GameState, coincheur: Seat) -> bool:
        """Ask the player whether to surcoinche (NS-taker path, 3.7.1 D3).

        Fired when the player is the taker (NS) and the EW AI lands a
        coinche — the player may surcoinche back to push `coinche_level` to
        2. Default no-op returns False; if the player declines, the existing
        AI surcoinche heuristic (30% under `surcoinche_unlocked`) still runs.
        Override in concrete UI (e.g. BelAtro main).
        """
        return False


def drive_round(
    bus: EventBus,
    partner: PartnerState,
    ui_callbacks: RoundUICallbacks,
    acc: ScoreAccumulator | None = None,
    boss: BossModifier | None = None,
    target_score: int = 0,
    seed: int | None = None,
    card_enhancements: dict[str, object] | None = None,
    recorder: GhostRecorder | None = None,
) -> GameState:
    """
    Core engine loop for a single round in BelAtro.
    Orchestrates the sequence of events (Dealing -> Bidding -> Playing -> Scoring).
    """
    rng = random.Random(seed)
    # Initialize the base game state
    state = new_game(target=1000)  # Target doesn't matter for single round
    state = start_round(state, rng)

    # Merge per-run deck/voucher flags so scoring/legal_cards can read them.
    if card_enhancements:
        new_jstate = {**state._joker_state, **card_enhancements}
        state = replace(state, _joker_state=new_jstate)

    # Le Traître joker (corrupted, partner_throws_trick): pick one random trick
    # for partner sabotage and reuse the existing agent_double AI path. Skip if
    # a boss already activates agent_double — its 3-trick set takes precedence.
    if state._joker_state.get("traitre_active") and not state.boss_modifiers.agent_double_active:
        sabotage = frozenset({rng.randint(1, 8)})
        new_bm = replace(state.boss_modifiers, agent_double_active=True)
        new_jstate2 = {**state._joker_state, "agent_double_tricks": sabotage}
        state = replace(state, boss_modifiers=new_bm, _joker_state=new_jstate2)

    # L'Agent Double joker (corrupted): like Le Traître but two sabotage tricks.
    # Same precedence rule — boss agent_double takes priority.
    if (
        state._joker_state.get("agent_double_joker_active")
        and not state.boss_modifiers.agent_double_active
    ):
        sabotage2 = frozenset(rng.sample(range(1, 9), 2))
        new_bm2 = replace(state.boss_modifiers, agent_double_active=True)
        new_jstate3 = {**state._joker_state, "agent_double_tricks": sabotage2}
        state = replace(state, boss_modifiers=new_bm2, _joker_state=new_jstate3)

    # B1: Apply boss modifier flags onto the frozen GameState so play_card sees them.
    # Must run BEFORE acc.trigger_round_start so the accumulator's snapshot of
    # boss-derived flags (e.g. joker_state["no_dix_de_der"]) reflects the live
    # boss state instead of the BossModifiers defaults.
    if boss is not None:
        from ..engine.modifier_patch import PatchedGameState

        _proxy = PatchedGameState(state)
        boss.apply(_proxy)
        _patches = dict(object.__getattribute__(_proxy, "_patches"))
        state = replace(state, **_patches)

        # Ensure boss modifiers don't use stale cached logic/values
        clear_legal_cards_cache()

    if acc is not None:
        state = acc.trigger_round_start(state)

    # Populate sabotage_tricks for any path that flagged agent_double_active.
    # Sources: L'Agent Double boss (3 random tricks), BetrayalArc (tricks 4-8 via
    # agent_double_late_only flag), traitre joker (already populated above).
    # Reading the flag — not boss.id — keeps this site reusable.
    if state.boss_modifiers.agent_double_active and not state._joker_state.get(
        "agent_double_tricks"
    ):
        if state.boss_modifiers.agent_double_late_only:
            sabotage_tricks = frozenset(range(4, 9))
        else:
            sabotage_tricks = frozenset(rng.sample(range(1, 9), 3))
        new_jstate = {**state._joker_state, "agent_double_tricks": sabotage_tricks}
        state = replace(state, _joker_state=new_jstate)

    # B4: Use partner trust-based difficulty for the North (partner) AI seat
    _north_diff_str = partner.difficulty_for(Seat.NORTH)
    _north_diff = {
        "easy": Difficulty.EASY,
        "medium": Difficulty.MEDIUM,
        "hard": Difficulty.HARD,
    }.get(_north_diff_str, Difficulty.MEDIUM)
    # Thread the round's seeded RNG into every AI seat so easy-AI plays and
    # personality jitter stay reproducible under a fixed seed. Ghost-run and
    # replay tooling rely on this — without it, AIPlayer's old unseeded
    # default RNG randomised behavior per process even at a fixed seed.
    ai_players = {
        Seat.EAST: AIPlayer(Seat.EAST, Difficulty.MEDIUM, rng=rng),
        Seat.NORTH: AIPlayer(Seat.NORTH, _north_diff, rng=rng),
        Seat.WEST: AIPlayer(Seat.WEST, Difficulty.MEDIUM, rng=rng),
    }

    if acc is not None:
        acc.partner_jokers_double = partner.trust.partner_jokers_double
        acc.partner_tier = partner.trust.tier

    def _emit(event: object, s: GameState) -> GameState:
        if acc is not None:
            return acc.update_state(s, event)
        return s

    # Phase: BIDDING
    while state.phase == Phase.BIDDING:
        bidder = state.turn
        bid: BidValue = None

        if bidder == Seat.SOUTH:
            bid = ui_callbacks.prompt_bid(state)
        elif (
            bidder == Seat.NORTH
            and partner is not None
            and not partner.trust.ai_degraded
        ):
            # Use personality for the partner if trust is maintained
            if state.boss_modifiers.partner_forced_pass:
                bid = None
            elif partner.personality.should_bid(state):
                p_bid = partner.personality.bid_value(state)
                # Trust-gate Tout Atout / Sans Atout: partner only bids these
                # special contracts once the trust track unlocks them. Below
                # the threshold, fall through to "pass" rather than bid a
                # normal suit — the personality already chose to go big.
                is_special = p_bid == Suit.TOUT_ATOUT or p_bid == SANS_ATOUT_BID
                if is_special and not partner.trust.duo_contracts_available:
                    p_bid = None
                # Ensure the bid is legal for the current round (round 1 = up
                # card suit only). TA/SA are also rejected in round 1 by
                # place_bid, but we filter early to keep the bid legal here.
                forbidden = state.up_card.suit if state.up_card else None
                if p_bid != forbidden and not (
                    is_special and state.bidding_round == 1
                ):
                    bid = p_bid
        else:
            # Standard AI for EAST/WEST
            bid = ai_players[bidder].decide_bid(state)

        state = process_bid(state, bid)
        # `bid` was a BidValue; the BidMadeEvent's `trump` field is the actual
        # trump suit (Suit | None) from state, which place_bid set correctly.
        state = _emit(
            BidMadeEvent(
                seat=bidder,
                trump=state.trump,
                contract=state.contract or "normal",
            ),
            state
        )
        if recorder is not None:
            recorder.note_bid(
                seat=bidder.name.lower(),
                trump=state.trump.name.lower() if state.trump is not None else None,
                contract=state.contract or "normal",
            )

    # ── Coinche / surcoinche flow ────────────────────────────────────────
    # Either defending team may coinche the taker's bid. The branches below
    # mirror each other: EW-taker → NS defenders may coinche (player or
    # partner-AI fallback); NS-taker → EW AI defenders may coinche (3.6.0
    # audit H1 — without this branch the Libra planet was unreachable in
    # natural play because coinche_level stayed 0 whenever NS was taker).
    coinche_level = 0
    if state.taker is not None and state.phase == Phase.PLAYING:
        surcoinche_unlocked = bool(state._joker_state.get("surcoinche_unlocked"))

        if state.taker in (Seat.EAST, Seat.WEST):
            # EW taker → NS defends. Player gets first refusal; partner AI
            # picks up if the player declined and trust isn't degraded.
            if ui_callbacks.prompt_coinche(state, state.taker) or (
                not partner.trust.ai_degraded
                and partner.personality.should_coinche(state, rng)
            ):
                coinche_level = 1
                if surcoinche_unlocked and rng.random() < 0.3:
                    coinche_level = 2
        else:
            # NS taker → EW AI defends. Light heuristic gated by the seeded
            # RNG (so behaviour is reproducible under a fixed seed). When
            # the coinche lands and surcoinche is unlocked, the player gets
            # first refusal to surcoinche back (3.7.1 D3); the AI surcoinche
            # heuristic (30 %) still fires if the player declines.
            if _ew_should_coinche(state, rng):
                coinche_level = 1
                if surcoinche_unlocked:
                    # Pick a concrete EW seat for the prompt label. Either
                    # works — both EW seats defend together. Branches are
                    # split (player-accept vs AI-fallback) because they are
                    # conceptually distinct decisions even though both raise
                    # the level — keep them separate for readability.
                    coincheur_seat = Seat.EAST
                    if ui_callbacks.prompt_surcoinche(state, coincheur_seat) or rng.random() < 0.3:
                        coinche_level = 2

        # L'Avocat boss forces at least coinche=1 regardless of taker team.
        if state.boss_modifiers.auto_coinche:
            coinche_level = max(coinche_level, 1)

        # Refresh joker_state with the resolved coinche level via a re-emit.
        # `re_emit=True` updates derived state (HUD, joker_state["contract"])
        # without re-firing on_bid jokers — those already fired in the loop.
        if coinche_level > 0:
            state = _emit(
                BidMadeEvent(
                    seat=state.taker,
                    trump=state.trump,
                    contract=state.contract or "normal",
                    coinche_level=coinche_level,
                    re_emit=True,
                ),
                state,
            )

    # Le Coincheur deck: every round starts pre-coinched (deck mod plumbed via
    # card_enhancements → state._joker_state).
    if (
        state.phase == Phase.PLAYING
        and state._joker_state.get("start_coinched")
        and coinche_level == 0
    ):
        coinche_level = 1
        state = _emit(
            BidMadeEvent(
                seat=state.taker if state.taker is not None else Seat.SOUTH,
                trump=state.trump,
                contract=state.contract or "normal",
                coinche_level=coinche_level,
                re_emit=True,
            ),
            state,
        )

    # If round ended early (everyone passed), emit RoundEndEvent
    if state.phase == Phase.DEAL and len(state.bids) == 0:
        # Everyone passed; state moved back to DEAL by process_bid
        # We need a breakdown to emit.
        breakdown = score_round(state)
        state = _emit(
            RoundEndEvent(
                breakdown=breakdown,
                taker_seat=None,
                trump=None,
                capot=False,
                hand_remainder=tuple(state.hand_of(Seat.SOUTH)),
                contract=state.contract or "normal",
                coinche_level=coinche_level,
            ),
            state
        )

    # Phase: PLAYING
    while state.phase == Phase.PLAYING:
        player = state.turn
        card: Card | None = None

        if player == Seat.SOUTH:
            card, state = ui_callbacks.prompt_card(state)
        else:
            # AI Play
            card = ai_players[player].decide_card(state)

        # Before playing, track points to emit TrickWonEvent with diff
        old_pts_total = sum(state.current_round_points)
        old_belote_tracker = state.belote_tracker

        state = play_card(state, card)
        ui_callbacks.on_card_played(state, player, card)
        if recorder is not None:
            # If the 4th card just closed the trick, completed_tricks already
            # includes it; otherwise we're mid-trick and the in-progress trick
            # number is one past the completed count.
            trick_no = (
                len(state.completed_tricks)
                if not state.current_trick
                else len(state.completed_tricks) + 1
            )
            recorder.note_play(trick=trick_no, seat=player.name.lower(), card=str(card))

        # If this play flipped the belote tracker, emit the announce event.
        # belote_tracker = (belote_played, rebelote_played); compare old vs new.
        if state.belote_tracker != old_belote_tracker:
            became_belote = state.belote_tracker[0] and not old_belote_tracker[0]
            became_rebelote = state.belote_tracker[1] and not old_belote_tracker[1]
            if became_belote or became_rebelote:
                state = _emit(
                    BeloteAnnouncedEvent(seat=player, is_rebelote=became_rebelote),
                    state,
                )

        if is_last_in_trick(state):
            last_trick = state.completed_tricks[-1]

            # Use the resolved winner cached by play_card (Rupture-aware).
            # 3.8.1: pre-fix this re-derived via trick_winner_seat, which
            # returns the RAW winner; under La Rupture the event.winner
            # would disagree with the team scoring authority.
            winner = state.last_trick_winner
            assert winner is not None, (
                "last_trick_winner unset after a complete trick — "
                "GameState invariant violated."
            )
            # Use state diff to get points; perfectly handles all boss-aware points and Dix de Der
            points = sum(state.current_round_points) - old_pts_total

            # Emit declarations first if it's the first trick
            if len(state.completed_tricks) == 1:
                for decl in state.declarations:
                    pts = 0
                    if decl.detail and decl.kind in ("sequence", "carre"):
                        pts = get_declaration_points([decl.detail])
                    state = _emit(
                        DeclarationScoredEvent(
                            seat=decl.seat,
                            declaration_type=decl.kind,
                            points=pts,
                        ),
                        state
                    )

            is_last = len(state.completed_tricks) == 8
            cards = tuple(tc.card for tc in last_trick)
            leader_seat = last_trick[0].seat
            state = _emit(
                TrickWonEvent(
                    winner=winner,
                    cards=cards,
                    trick_number=len(state.completed_tricks),
                    is_last=is_last,
                    card_points=points,
                    trump=state.trump,
                    leader_seat=leader_seat,
                ),
                state
            )
            # Le Fantôme partner personality: "Every trick they win gives you
            # +$1." Personalities don't subscribe to the event bus the way
            # jokers do, so payout is wired through state._bonus_money here.
            if (
                partner is not None
                and getattr(partner.personality, "id", None) == "le_fantome"
                and winner == Seat.NORTH
            ):
                state = replace(state, _bonus_money=state._bonus_money + 1)
            ui_callbacks.on_trick_end(state, winner, points)

    # Round End / Scoring
    if state.phase == Phase.SCORING:
        breakdown = score_round(state)
        hand_remainder = tuple(state.hand_of(Seat.SOUTH))
        state = _emit(
            RoundEndEvent(
                breakdown=breakdown,
                taker_seat=state.taker,
                trump=state.trump,
                capot=is_capot(state) is not None,
                hand_remainder=hand_remainder,
                contract=state.contract or "normal",
                coinche_level=coinche_level,
            ),
            state
        )
        if recorder is not None:
            recorder.note_round_end({
                "taker_team": breakdown.taker_team,
                "taker_total": breakdown.taker_total,
                "defender_total": breakdown.defender_total,
                "is_capot": breakdown.is_capot,
                "is_failed": breakdown.is_failed,
            })
        ui_callbacks.on_round_end(breakdown)

    return state


def is_last_in_trick(state: GameState) -> bool:
    """Helper to check if a trick just ended."""
    return len(state.current_trick) == 0 and len(state.completed_tricks) > 0
