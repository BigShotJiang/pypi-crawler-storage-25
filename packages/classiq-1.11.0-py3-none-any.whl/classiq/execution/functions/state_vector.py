from typing import TYPE_CHECKING, Any, overload

from classiq._internals.client import client

if TYPE_CHECKING:
    from pandas import DataFrame

from classiq.interface.backend.backend_preferences import (
    BackendPreferencesTypes,
    ClassiqBackendPreferences,
    GCPBackendPreferences,
)
from classiq.interface.backend.quantum_backend_providers import (
    ClassiqNvidiaBackendNames,
    ClassiqSimulatorBackendNames,
    GoogleNvidiaBackendNames,
)
from classiq.interface.executor.execution_preferences import ExecutionPreferences
from classiq.interface.executor.quantum_program_params import ExecutionParams
from classiq.interface.generator.model.preferences import create_random_seed
from classiq.interface.generator.model.preferences.preferences import (
    TranspilationOption,
)
from classiq.interface.generator.quantum_program import QuantumProgram
from classiq.interface.hardware import Provider

from classiq.execution import ExecutionSession
from classiq.execution.functions.util._logging import _logger, submitting_job_log_label
from classiq.execution.functions.util.parse_provider_backend import (
    _PROVIDER_TO_CANONICAL_NAME,
    _parse_provider_backend,
)

_DEFAULT_STATE_VECTOR_BACKEND_NAME = "simulator"


@overload
def calculate_state_vector(
    qprog: QuantumProgram,
    backend: str | None = ...,
    *,
    parameters: list[ExecutionParams],
    filters: dict[str, Any] | None = ...,
    random_seed: int | None = ...,
    transpilation_option: TranspilationOption = ...,
    amplitude_threshold: float = ...,
) -> list["DataFrame"]: ...


@overload
def calculate_state_vector(
    qprog: QuantumProgram,
    backend: str | None = ...,
    *,
    parameters: ExecutionParams | None = ...,
    filters: dict[str, Any] | None = ...,
    random_seed: int | None = ...,
    transpilation_option: TranspilationOption = ...,
    amplitude_threshold: float = ...,
) -> "DataFrame": ...


def calculate_state_vector(
    qprog: QuantumProgram,
    backend: str | None = None,
    *,
    parameters: ExecutionParams | list[ExecutionParams] | None = None,
    filters: dict[str, Any] | None = None,
    random_seed: int | None = None,
    transpilation_option: TranspilationOption = TranspilationOption.DECOMPOSE,
    amplitude_threshold: float = 0.0,
) -> "DataFrame | list[DataFrame]":
    """
    Calculate the state vector of a quantum program.

    This function is only available for Classiq simulators
    (e.g. ``"classiq/simulator"``).

    Args:
        qprog: The quantum program to be executed.
        backend: The simulator on which to simulate the quantum program.
            Specified as ``"provider/backend_name"``. Use the
            ``get_backend_details`` function to see supported backends.
            Only Classiq simulators are supported.
        parameters: A dictionary of parameter values, or a list of dictionaries
            for batch execution. Each key should be the name of a parameter in
            the quantum program (parameters of the main function), and the value
            should be the value to set for that parameter.
        filters: Only states where the variables match these values will be
            included in the state vector.
        random_seed: The random seed for reproducibility.
        transpilation_option: Advanced configuration for hardware-specific
            transpilation.
        amplitude_threshold: If provided, only states whose amplitude magnitude
            is strictly greater than this value will be included in the result.
            Defaults to 0 (filters exactly zero-amplitude states).

    Returns:
        A dataframe containing the state vector, or a list of dataframes when
        ``parameters`` is a list.
    """
    if backend is None:
        backend = _DEFAULT_STATE_VECTOR_BACKEND_NAME

    provider, raw_backend_name = _parse_provider_backend(backend)
    backend_name_lower = raw_backend_name.lower()
    backend_preferences: BackendPreferencesTypes

    if provider == Provider.CLASSIQ:
        if backend_name_lower == "simulator":
            backend_name = str(ClassiqSimulatorBackendNames.SIMULATOR_STATEVECTOR)
        elif backend_name_lower == "nvidia_simulator":
            backend_name = str(ClassiqNvidiaBackendNames.SIMULATOR_STATEVECTOR)
        else:
            raise ValueError(
                f"Unsupported backend '{backend}'. "
                "Only Classiq simulators (e.g. classiq/simulator) are supported."
            )
        backend_preferences = ClassiqBackendPreferences(backend_name=backend_name)
    elif provider == Provider.GOOGLE:
        if backend_name_lower == "cuquantum":
            backend_name = str(GoogleNvidiaBackendNames.CUQUANTUM_STATEVECTOR)
        else:
            raise ValueError(
                f"Unsupported backend '{backend}'. "
                "Under the Google provider, only 'google/cuquantum' is supported."
            )
        backend_preferences = GCPBackendPreferences(backend_name=backend_name)
    else:
        raise ValueError(
            f"Provider '{_PROVIDER_TO_CANONICAL_NAME.get(provider, provider)}' does not support "
            "state vector calculation. This operation is only available on Classiq simulators "
            "(e.g. classiq/simulator)."
        )

    ep = ExecutionPreferences(
        backend_preferences=backend_preferences,
        random_seed=create_random_seed() if random_seed is None else random_seed,
        transpile_to_hardware=transpilation_option,
        amplitude_threshold=amplitude_threshold,
    )
    _logger.info(
        f"Submitting job to {submitting_job_log_label(backend, backend_preferences)}"
    )
    with ExecutionSession(qprog, execution_preferences=ep) as session:
        if filters is not None:
            for output_name, value in filters.items():
                session.set_measured_state_filter(
                    output_name, lambda state, val=value: state == val
                )
        job = session.submit_sample(parameters)
        _logger.info(f"Job: {client()._config.host}jobs/{job.id}")
        if isinstance(parameters, list):
            results = job.get_batch_sample_result()
            return [result.dataframe for result in results]
        else:
            result = job.get_sample_result()
            return result.dataframe
