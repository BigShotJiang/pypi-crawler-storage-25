from typing import Any, overload

from classiq.interface.backend.backend_preferences import (
    BackendPreferencesTypes,
    ClassiqBackendPreferences,
)
from classiq.interface.backend.provider_config.provider_config import ProviderConfig
from classiq.interface.backend.quantum_backend_providers import (
    ClassiqSimulatorBackendNames,
)
from classiq.interface.executor.execution_preferences import ExecutionPreferences
from classiq.interface.executor.quantum_program_params import ExecutionParams
from classiq.interface.generator.model.preferences import create_random_seed
from classiq.interface.generator.model.preferences.preferences import (
    TranspilationOption,
)
from classiq.interface.generator.quantum_program import QuantumProgram
from classiq.interface.hardware import Provider

from classiq._internals.client import client
from classiq.execution.execution_session import ExecutionSession
from classiq.execution.functions.util._logging import _logger, submitting_job_log_label
from classiq.execution.functions.util.backend_preferences import (
    _get_backend_preferences_from_specifier,
)
from classiq.execution.functions.util.parse_provider_backend import (
    _parse_provider_backend,
)
from classiq.qmod.builtins.structs import SparsePauliOp

_DEFAULT_BACKEND_NAME = "simulator"


def _get_backend_preferences(
    backend: str,
    estimate: bool,
    config: dict[str, Any] | ProviderConfig | None,
    *,
    run_via_classiq: bool = False,
) -> BackendPreferencesTypes:
    provider, backend_name = _parse_provider_backend(backend)
    backend_preferences: BackendPreferencesTypes
    if not estimate:
        if not (
            provider == Provider.CLASSIQ and backend_name.lower().strip() == "simulator"
        ):
            raise ValueError(
                "Calculating exact expectation value is supported only for the 'classiq/simulator' backend"
            )
        backend_preferences = ClassiqBackendPreferences(
            # This backend name is for exact simulation
            backend_name=ClassiqSimulatorBackendNames.SIMULATOR_STATEVECTOR
        )
    else:
        backend_preferences = _get_backend_preferences_from_specifier(
            backend, config or {}, run_via_classiq=run_via_classiq
        )
    return backend_preferences


@overload
def observe(
    qprog: QuantumProgram,
    observable: SparsePauliOp,
    backend: str | None = ...,
    *,
    estimate: bool = ...,
    parameters: list[ExecutionParams],
    config: dict[str, Any] | ProviderConfig | None = ...,
    num_shots: int | None = ...,
    random_seed: int | None = ...,
    transpilation_option: TranspilationOption = ...,
    run_via_classiq: bool = ...,
) -> list[float]: ...


@overload
def observe(
    qprog: QuantumProgram,
    observable: SparsePauliOp,
    backend: str | None = ...,
    *,
    estimate: bool = ...,
    parameters: ExecutionParams | None = ...,
    config: dict[str, Any] | ProviderConfig | None = ...,
    num_shots: int | None = ...,
    random_seed: int | None = ...,
    transpilation_option: TranspilationOption = ...,
    run_via_classiq: bool = ...,
) -> float: ...


def observe(
    qprog: QuantumProgram,
    observable: SparsePauliOp,
    backend: str | None = None,
    *,
    estimate: bool = True,
    parameters: ExecutionParams | list[ExecutionParams] | None = None,
    config: dict[str, Any] | ProviderConfig | None = None,
    num_shots: int | None = None,
    random_seed: int | None = None,
    transpilation_option: TranspilationOption = TranspilationOption.DECOMPOSE,
    run_via_classiq: bool = False,
) -> float | list[float]:
    """
    Get the expectation value of the observable O with respect to the state
    |psi>, which is prepared by the provided quantum program.

    Args:
        qprog: The quantum program that generates the state |psi> to be
            observed.
        observable: The observable O, a Hermitian operator defined as a
            ``SparsePauliOp`` (sum of Pauli terms).
        backend: The hardware or simulator on which to run the quantum program.
            Use ``"simulator"`` for Classiq's default simulator, or specify a
            backend as ``"provider/backend_name"``. Use the
            ``get_backend_details`` function to see supported devices.
        estimate: Whether to estimate the expectation value by repeatedly
            measuring the circuit ``num_shots`` times, or calculate the exact
            expectation value using a simulated statevector. Note that the
            available options depend on the specified backend. Defaults to
            ``True``.
        parameters: A dictionary of parameter values, or a list of dictionaries
            for batch execution. Each key should be the name of a parameter in
            the quantum program (parameters of the main function), and the value
            should be the value to set for that parameter.
        config: Provider-specific configuration, such as API keys. For full
            details, see the SDK reference under Providers.
        num_shots: The number of measurement shots. Only relevant when
            ``estimate=True``.
        random_seed: The random seed for reproducibility.
        transpilation_option: Advanced configuration for hardware-specific
            transpilation.
        run_via_classiq: Run via Classiq's credentials while using your
            allocated budget. Defaults to ``False``.

    Returns:
        The expectation value as a float, or a list of floats when
        ``parameters`` is a list.

    See Also:
        More information about defining observables as
        `Hamiltonians <https://docs.classiq.io/latest/qmod-reference/language-reference/classical-types/#hamiltonians>`_.
    """
    if not isinstance(observable, SparsePauliOp):
        raise TypeError(
            f"'observable' must be a SparsePauliOp (Hamiltonian), got {type(observable).__name__}. "
            "See classical types under Qmod reference in Classiq documentation for how to define Hamiltonians."
        )
    if backend is None:
        backend = _DEFAULT_BACKEND_NAME
    backend_preferences = _get_backend_preferences(
        backend, estimate, config, run_via_classiq=run_via_classiq
    )
    ep = ExecutionPreferences(
        backend_preferences=backend_preferences,
        num_shots=num_shots,
        random_seed=create_random_seed() if random_seed is None else random_seed,
        transpile_to_hardware=transpilation_option,
    )

    _logger.info(
        f"Submitting job to {submitting_job_log_label(backend, backend_preferences)}"
    )
    with ExecutionSession(qprog, execution_preferences=ep) as session:
        job = session.submit_estimate(hamiltonian=observable, parameters=parameters)
        _logger.info(f"Job: {client()._config.host}jobs/{job.id}")
        if isinstance(parameters, list):
            results = job.get_batch_estimate_result()
            return [float(r.value.real) for r in results]
        else:
            result = job.get_estimate_result()
            return float(result.value.real)
