from typing import Any

from classiq.interface.backend.provider_config.provider_config import ProviderConfig
from classiq.interface.executor.execution_preferences import ExecutionPreferences
from classiq.interface.executor.quantum_program_params import ExecutionParams
from classiq.interface.generator.model.preferences import create_random_seed
from classiq.interface.generator.model.preferences.preferences import (
    TranspilationOption,
)
from classiq.interface.generator.quantum_program import QuantumProgram

from classiq._internals.client import client
from classiq.execution.execution_session import ExecutionSession
from classiq.execution.functions.util._logging import _logger, submitting_job_log_label
from classiq.execution.functions.util.backend_preferences import (
    _get_backend_preferences_from_specifier,
)
from classiq.qmod.builtins.structs import SparsePauliOp
from classiq.qmod.qmod_variable import QmodExpressionCreator

_DEFAULT_BACKEND_NAME = "simulator"


def variational_minimize(
    qprog: QuantumProgram,
    cost_function: SparsePauliOp | QmodExpressionCreator,
    initial_params: ExecutionParams,
    max_iteration: int,
    backend: str | None = None,
    *,
    quantile: float = 1.0,
    tolerance: float | None = None,
    config: dict[str, Any] | ProviderConfig | None = None,
    random_seed: int | None = None,
    transpilation_option: TranspilationOption = TranspilationOption.DECOMPOSE,
    run_via_classiq: bool = False,
) -> list[tuple[float, ExecutionParams]]:
    """
    Minimize the given cost function over the parameter values of the provided
    quantum program.

    Args:
        qprog: The parametric quantum program that generates the state (ansatz).
            Only quantum programs with exactly one execution parameter are
            supported.
        cost_function: The cost function to minimize.
            It can be one of the following:

            - A quantum cost function defined by a Hamiltonian.
            - A classical cost function represented as a callable that returns
              a Qmod expression. The callable should accept ``QVar``s as
              arguments and use names matching the Model outputs.
        initial_params: The initial parameter values for the minimization.
            This parameter must be of type ``CReal`` or ``CArray``. The
            dictionary must contain a single key-value pair, where:

            - The key is the name of the parameter.
            - The value is either a float or a list of floats.
        max_iteration: The maximum number of iterations for the minimization.
        backend: The hardware or simulator on which to run the quantum programs.
            Use ``"simulator"`` for Classiq's default simulator, or specify a
            backend as ``"provider/backend_name"``. Use the
            ``get_backend_details`` function to see supported devices.
        quantile: The quantile to use for cost estimation.
        tolerance: The tolerance for the minimization.
        config: Provider-specific configuration, such as API keys. For full
            details, see the SDK reference under Providers.
        random_seed: The random seed for reproducibility.
        transpilation_option: Advanced configuration for hardware-specific
            transpilation.
        run_via_classiq: Run via Classiq's credentials while using your
            allocated budget. Defaults to ``False``.

    Returns:
        A list of tuples, each containing the estimated cost and the
        corresponding parameters for that iteration. ``cost`` is a float,
        and ``parameters`` is a dictionary matching the execution parameter
        format.

    See Also:
        The `Execution Tutorial <https://docs.classiq.io/latest/getting-started/classiq_tutorial/execution_tutorial_part2/>`_
        has examples on using this method in variational quantum algorithms.

        More information about
        `Hamiltonians <https://docs.classiq.io/latest/qmod-reference/language-reference/classical-types/#hamiltonians>`_.
    """
    if backend is None:
        backend = _DEFAULT_BACKEND_NAME
    if not isinstance(cost_function, SparsePauliOp) and not callable(cost_function):
        raise TypeError(
            f"'cost_function' must be a SparsePauliOp (Hamiltonian) or a callable, "
            f"got {type(cost_function).__name__}. "
            "See the Execution Tutorial in Classiq documentation for examples."
        )
    if not isinstance(initial_params, dict):
        raise TypeError(
            f"'initial_params' must be a dictionary mapping parameter names to values, "
            f"got {type(initial_params).__name__}."
        )
    if config is None:
        config = {}
    backend_preferences = _get_backend_preferences_from_specifier(
        backend, config, run_via_classiq=run_via_classiq
    )

    ep = ExecutionPreferences(
        backend_preferences=backend_preferences,
        random_seed=create_random_seed() if random_seed is None else random_seed,
        transpile_to_hardware=transpilation_option,
    )

    _logger.info(
        f"Submitting job to {submitting_job_log_label(backend, backend_preferences)}"
    )
    with ExecutionSession(qprog, execution_preferences=ep) as session:
        job = session.submit_minimize(
            cost_function, initial_params, max_iteration, quantile, tolerance
        )
        _logger.info(f"Job: {client()._config.host}jobs/{job.id}")
        result = job.get_minimization_result()
        return session._minimize_result_to_result(
            result=result, initial_params=initial_params
        )
