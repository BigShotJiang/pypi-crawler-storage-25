from typing import TYPE_CHECKING, Any, overload

from classiq._internals.client import client
from classiq.execution.functions.util.backend_preferences import (
    _get_backend_preferences_from_specifier,
)

if TYPE_CHECKING:
    from pandas import DataFrame

from classiq.interface.backend.provider_config.provider_config import ProviderConfig
from classiq.interface.executor.execution_preferences import ExecutionPreferences
from classiq.interface.executor.quantum_program_params import ExecutionParams
from classiq.interface.generator.model.preferences import create_random_seed
from classiq.interface.generator.model.preferences.preferences import (
    TranspilationOption,
)
from classiq.interface.generator.quantum_program import QuantumProgram

from classiq.execution import ExecutionSession
from classiq.execution.functions.util._logging import _logger, submitting_job_log_label

_DEFAULT_BACKEND_NAME = "simulator"


def _openqasm_sample_parameters_allowed(
    parameters: ExecutionParams | list[ExecutionParams] | None,
) -> bool:
    if parameters is None:
        return True
    if isinstance(parameters, list):
        return all(not p for p in parameters)
    return not parameters


@overload
def sample(
    qprog: QuantumProgram,
    backend: str | None = ...,
    *,
    parameters: list[ExecutionParams],
    config: dict[str, Any] | ProviderConfig | None = ...,
    num_shots: int | None = ...,
    random_seed: int | None = ...,
    transpilation_option: TranspilationOption = ...,
    run_via_classiq: bool = ...,
) -> list["DataFrame"]: ...


@overload
def sample(
    qprog: QuantumProgram,
    backend: str | None = ...,
    *,
    parameters: ExecutionParams | None = ...,
    config: dict[str, Any] | ProviderConfig | None = ...,
    num_shots: int | None = ...,
    random_seed: int | None = ...,
    transpilation_option: TranspilationOption = ...,
    run_via_classiq: bool = ...,
) -> "DataFrame": ...


@overload
def sample(
    qprog: str,
    backend: str | None = ...,
    *,
    parameters: list[ExecutionParams],
    config: dict[str, Any] | ProviderConfig | None = ...,
    num_shots: int | None = ...,
    random_seed: int | None = ...,
    transpilation_option: TranspilationOption = ...,
    run_via_classiq: bool = ...,
) -> list["DataFrame"]: ...


@overload
def sample(
    qprog: str,
    backend: str | None = ...,
    *,
    parameters: ExecutionParams | None = ...,
    config: dict[str, Any] | ProviderConfig | None = ...,
    num_shots: int | None = ...,
    random_seed: int | None = ...,
    transpilation_option: TranspilationOption = ...,
    run_via_classiq: bool = ...,
) -> "DataFrame": ...


def sample(
    qprog: QuantumProgram | str,
    backend: str | None = None,
    *,
    parameters: ExecutionParams | list[ExecutionParams] | None = None,
    config: dict[str, Any] | ProviderConfig | None = None,
    num_shots: int | None = None,
    random_seed: int | None = None,
    transpilation_option: TranspilationOption = TranspilationOption.DECOMPOSE,
    run_via_classiq: bool = False,
) -> "DataFrame | list[DataFrame]":
    """
    Sample a quantum program or OpenQASM circuit.

    Args:
        qprog: A synthesized ``QuantumProgram``, or OpenQASM **2.0** / **3.0** source
            as a single string (for example output of ``qiskit.qasm2.dumps`` or
            ``qiskit.qasm3.dumps``).
        backend: The hardware or simulator on which to run the quantum program.
            Use ``"simulator"`` for Classiq's default simulator, or specify a backend
            as ``"provider/device_id"``. Use the ``get_backend_details`` function
            to see supported devices.
        parameters: A dictionary of parameter values, or a list of dictionaries for
            batch execution. Each key should be the name of a parameter in the quantum
            program (parameters of the ``main`` function), and the value should be the
            value to set for that parameter. **Not supported** when ``qprog`` is an
            OpenQASM string (use a ``QuantumProgram`` or bind values in QASM before
            calling ``sample``).
        config: Provider-specific configuration, such as API keys. For full details,
            see the SDK reference under Providers.
        num_shots: The number of times to sample.
        random_seed: The random seed used for transpilation and simulation.
        transpilation_option: Advanced configuration for hardware-specific
            transpilation.
        run_via_classiq: Run via Classiq's credentials while using your allocated
            budget. Defaults to ``False``.

    Returns:
        A dataframe containing the histogram, or a list of dataframes when
        ``parameters`` is a list.
    """
    if isinstance(qprog, str) and not _openqasm_sample_parameters_allowed(parameters):
        raise ValueError(
            "The parameters argument is not supported when the first argument is "
            "OpenQASM source text; use a QuantumProgram for parameterized execution."
        )
    if num_shots is not None and num_shots < 1:
        raise ValueError(f"Argument num_shots must be greater than 0, got {num_shots}")
    if config is None:
        config = {}
    if backend is None:
        backend = _DEFAULT_BACKEND_NAME
    backend_preferences = _get_backend_preferences_from_specifier(
        backend, config, run_via_classiq=run_via_classiq
    )
    ep = ExecutionPreferences(
        backend_preferences=backend_preferences,
        num_shots=num_shots,
        random_seed=create_random_seed() if random_seed is None else random_seed,
        transpile_to_hardware=transpilation_option,
    )
    _logger.info(
        f"Submitting job to {submitting_job_log_label(backend, backend_preferences)}"
    )
    with ExecutionSession(qprog, execution_preferences=ep) as session:
        job = session.submit_sample(parameters)
        _logger.info(f"Job: {client()._config.host}jobs/{job.id}")
        if isinstance(parameters, list):
            results = job.get_batch_sample_result()
            return [result.dataframe for result in results]
        else:
            result = job.get_sample_result()
            return result.dataframe
