import logging
from typing import Any

_logger = logging.getLogger(__name__)


def submitting_job_log_label(backend: str, backend_preferences: Any) -> str:
    if getattr(backend_preferences, "emulate", False):
        return f"{backend} (emulation)"
    return backend


def _setup_logging() -> None:
    if _logger.handlers:
        return

    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    _logger.addHandler(handler)
    _logger.setLevel(logging.INFO)

    _logger.propagate = False


_setup_logging()
