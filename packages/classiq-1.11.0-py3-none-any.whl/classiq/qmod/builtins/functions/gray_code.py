from classiq.qmod.builtins.enums import Pauli
from classiq.qmod.builtins.functions import Const
from classiq.qmod.qfunc import qfunc, qperm
from classiq.qmod.qmod_parameter import CArray, CReal
from classiq.qmod.qmod_variable import QBit, QNum


@qfunc(external=True)
def select_rotation(
    basis: Pauli, angles: CArray[CReal], selector: Const[QNum], target: QBit
) -> None:
    """
    [Qmod core-library function]

    Applies a set of controlled single-qubit rotations to a target qubit, using
    a specified rotation axis and a list of rotation angles.

    Args:
        basis: The Pauli operator defining the rotation axis.
        angles: The list of rotation angles in radians. The list must have length 2**selector.size.
        selector: The qubits that act as the selection register.
        target: The qubit on which the selected rotation is applied.
    """
    pass


@qperm(external=True)
def select_z_rotation(
    angles: CArray[CReal], selector: Const[QNum], target: Const[QBit]
) -> None:
    """
    [Qmod core-library function]

    Applies a set of controlled single-qubit Z rotations to a target qubit, using
    a list of rotation angles.

    Args:
        angles: The list of rotation angles in radians. The list must have length 2**selector.size.
        selector: The qubits that act as the selection register.
        target: The qubit on which the selected rotation is applied.
    """
    pass
