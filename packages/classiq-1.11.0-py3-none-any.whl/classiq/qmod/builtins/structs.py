from dataclasses import dataclass, fields, is_dataclass
from functools import cmp_to_key, total_ordering
from typing import Any, Union

from classiq.interface.exceptions import ClassiqValueError
from classiq.interface.generator.types.struct_declaration import StructDeclaration
from classiq.interface.helpers.datastructures import LenList

from classiq.qmod.builtins.enums import Pauli
from classiq.qmod.cparam import CArray, CInt, CReal
from classiq.qmod.python_classical_type import PythonClassicalType

_PAULI_MULTIPLICATIONS = {
    (Pauli.I, Pauli.I): (1, Pauli.I),
    (Pauli.I, Pauli.X): (1, Pauli.X),
    (Pauli.X, Pauli.I): (1, Pauli.X),
    (Pauli.I, Pauli.Y): (1, Pauli.Y),
    (Pauli.Y, Pauli.I): (1, Pauli.Y),
    (Pauli.I, Pauli.Z): (1, Pauli.Z),
    (Pauli.Z, Pauli.I): (1, Pauli.Z),
    (Pauli.X, Pauli.X): (1, Pauli.I),
    (Pauli.Y, Pauli.Y): (1, Pauli.I),
    (Pauli.Z, Pauli.Z): (1, Pauli.I),
    (Pauli.X, Pauli.Y): (1j, Pauli.Z),
    (Pauli.Y, Pauli.X): (-1j, Pauli.Z),
    (Pauli.X, Pauli.Z): (-1j, Pauli.Y),
    (Pauli.Z, Pauli.X): (1j, Pauli.Y),
    (Pauli.Y, Pauli.Z): (1j, Pauli.X),
    (Pauli.Z, Pauli.Y): (-1j, Pauli.X),
}


@dataclass
class PauliTerm:
    """
    A term in a Hamiltonian, represented as a product of single-qubit Pauli matrices.

    Attributes:
        pauli (CArray[Pauli]): The list of the chosen Pauli operators in the term, corresponds to a product of them.
        coefficient (CReal): The coefficient of the term (floating number).
    """

    pauli: CArray[Pauli]
    coefficient: CReal


@total_ordering
@dataclass
class IndexedPauli:
    """
    A single-qubit Pauli matrix on a specific qubit given by its index.

    Attributes:
        pauli (Pauli): The Pauli operator.
        index (CInt): The index of the qubit being operated on.
    """

    pauli: Pauli
    index: CInt

    def __lt__(self, other: Any) -> bool:
        if not isinstance(other, IndexedPauli):
            raise ClassiqValueError(
                "comparison operation not supported between IndexedPauli and non-IndexedPauli objects"
            )
        if not isinstance(
            self.index, int  # type: ignore[unreachable]
        ) or not isinstance(  # type: ignore[unreachable]
            other.index, int  # type: ignore[unreachable]
        ):
            raise ClassiqValueError("comparison operation not supported between CInts")
        if self.index != other.index:  # type: ignore[unreachable]
            return self.index < other.index
        return self.pauli < other.pauli

    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, IndexedPauli):
            raise ClassiqValueError(
                "comparison operation not supported between IndexedPauli and non-IndexedPauli objects"
            )
        return (
            self.index == other.index  # type: ignore[return-value]
            and self.pauli == other.pauli
        )


@dataclass
class SparsePauliTerm:
    """
    A term in the Hamiltonian, represented as a sparse product of single-qubit Pauli
    matrices.

       Attributes:
           paulis (CArray[IndexedPauli]): The list of chosen sparse Pauli operators in the term corresponds to a product of them. (See IndexedPauli)
           coefficient (CReal): The coefficient of the term (floating number).
    """

    paulis: CArray[IndexedPauli]
    coefficient: CReal

    def __mul__(self, obj: Any) -> "SparsePauliTerm":
        if isinstance(obj, (int, float, complex)):
            return SparsePauliTerm(
                paulis=self.paulis,
                coefficient=self.coefficient * obj,  # type: ignore[arg-type]
            )
        if not isinstance(obj, SparsePauliTerm):
            raise ClassiqValueError(
                f"Cannot multiply SparsePauliTerm by object of type {type(obj).__name__}"
            )
        ind = 0  # Assuming that self.paulis and obj.paulis are sorted by index
        ind_other = 0
        terms = []
        coef = self.coefficient * obj.coefficient
        while ind < len(self.paulis) and ind_other < len(  # type: ignore[arg-type]
            obj.paulis  # type: ignore[arg-type]
        ):
            if self.paulis[ind].index == obj.paulis[ind_other].index:
                prod_coef, pauli = _PAULI_MULTIPLICATIONS[
                    (self.paulis[ind].pauli, obj.paulis[ind_other].pauli)
                ]
                terms.append(IndexedPauli(pauli=pauli, index=self.paulis[ind].index))
                coef *= prod_coef
                ind += 1
                ind_other += 1
            elif self.paulis[ind].index < obj.paulis[ind_other].index:
                if self.paulis[ind].pauli != Pauli.I:
                    terms.append(
                        IndexedPauli(
                            pauli=self.paulis[ind].pauli, index=self.paulis[ind].index
                        )
                    )
                ind += 1
            else:
                if obj.paulis[ind_other].pauli != Pauli.I:
                    terms.append(
                        IndexedPauli(
                            pauli=obj.paulis[ind_other].pauli,
                            index=obj.paulis[ind_other].index,
                        )
                    )
                ind_other += 1

        terms += self.paulis[ind:]
        terms += obj.paulis[ind_other:]
        return SparsePauliTerm(
            paulis=LenList(terms), coefficient=coef  # type: ignore[arg-type]
        )

    def __rmul__(self, obj: Any) -> "SparsePauliTerm":
        return self.__mul__(obj)

    def __str__(self) -> str:
        if self.coefficient == 0:
            return "0"
        paulis_to_print = [
            pauli
            for pauli in self.paulis  # type: ignore[attr-defined]
            if pauli.pauli != Pauli.I
        ]
        if len(paulis_to_print) == 0:
            return f"{self.coefficient}"
        return (f"{self.coefficient}*" if self.coefficient != 1 else "") + "*".join(
            f"Pauli.{indexed_pauli.pauli.name}({indexed_pauli.index})"
            for indexed_pauli in paulis_to_print
        )

    def __post_init__(self) -> None:
        if not isinstance(self.paulis, list):  # type: ignore[unreachable]
            return

        if len(self.paulis) > 0:  # type: ignore[unreachable]
            self.paulis.sort()

    @staticmethod
    def cmp_paulis(a: "SparsePauliTerm", b: "SparsePauliTerm") -> int:
        if not isinstance(
            a.paulis, list  # type: ignore[unreachable]
        ) or not isinstance(  # type: ignore[unreachable]
            b.paulis, list  # type: ignore[unreachable]
        ):
            raise ClassiqValueError(
                "comparison operation not supported between CArrays"
            )
        ind_a = 0  # type: ignore[unreachable]
        ind_b = 0
        ind_a = a._ignore_identity(ind_a)
        ind_b = b._ignore_identity(ind_b)
        while ind_a < len(a.paulis) and ind_b < len(b.paulis):
            if a.paulis[ind_a].index != b.paulis[ind_b].index:
                return a.paulis[ind_a].index - b.paulis[ind_b].index
            if a.paulis[ind_a].pauli != b.paulis[ind_b].pauli:
                return a.paulis[ind_a].pauli - b.paulis[ind_b].pauli
            ind_a = a._ignore_identity(ind_a + 1)
            ind_b = b._ignore_identity(ind_b + 1)

        if ind_a < len(a.paulis):
            return 1
        if ind_b < len(b.paulis):
            return -1
        return 0

    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, SparsePauliTerm):
            raise ClassiqValueError(
                "comparison operation not supported between SparsePauliTerm and non-SparsePauliTerm objects"
            )
        return (
            SparsePauliTerm.cmp_paulis(self, other) == 0  # type: ignore[return-value]
            and self.coefficient == other.coefficient
        )

    def _ignore_identity(self, index: int) -> int:
        while (
            index < len(self.paulis)  # type: ignore[arg-type]
            and self.paulis[index].pauli == Pauli.I
        ):
            index += 1
        return index


@dataclass
class SparsePauliOp:
    """
    Represents a collection of sparse Pauli operators.

    Attributes:
        terms (CArray[SparsePauliTerm]): The list of chosen sparse Pauli terms, corresponds to a product of them. (See: SparsePauliTerm)
        num_qubits (CInt): The number of qubits in the Hamiltonian.
    """

    terms: list[SparsePauliTerm]
    num_qubits: int

    def _gather_similar_elements(self) -> None:
        self.terms.sort(key=cmp_to_key(SparsePauliTerm.cmp_paulis))
        i = 0
        while i < len(self.terms) - 1:
            if self.terms[i].coefficient == 0:
                del self.terms[i]
            elif SparsePauliTerm.cmp_paulis(self.terms[i], self.terms[i + 1]) == 0:
                self.terms[i].coefficient += self.terms[i + 1].coefficient  # type: ignore[assignment]
                del self.terms[i + 1]  # remove merged element
            else:
                i += 1

        if len(self.terms) > 1 and self.terms[-1].coefficient == 0:
            del self.terms[-1]

    def __mul__(self, obj: Any) -> "SparsePauliOp":
        if isinstance(obj, (int, float, complex)):
            if obj == 0:
                return SparsePauliOp(
                    terms=LenList(
                        [
                            SparsePauliTerm(
                                paulis=[IndexedPauli(pauli=Pauli.I, index=0)],  # type: ignore[arg-type]
                                coefficient=0,  # type: ignore[arg-type]
                            )
                        ]
                    ),
                    num_qubits=1,
                )
            return SparsePauliOp(
                terms=LenList([term * obj for term in self.terms]),
                num_qubits=self.num_qubits,
            )
        if not isinstance(obj, SparsePauliOp):
            raise ClassiqValueError(
                f"Cannot multiply SparsePauliOp by object of type {type(obj).__name__}"
            )
        res = SparsePauliOp(
            terms=LenList(
                [term1 * term2 for term1 in self.terms for term2 in obj.terms]
            ),
            num_qubits=max(self.num_qubits, obj.num_qubits),
        )
        res._gather_similar_elements()
        return res

    def __rmul__(self, obj: Union[float, "SparsePauliOp"]) -> "SparsePauliOp":
        return self.__mul__(obj)

    def __add__(self, other: Any) -> "SparsePauliOp":
        if isinstance(other, (int, float, complex)):
            return self + SparsePauliOp(
                terms=[
                    SparsePauliTerm(
                        paulis=[  # type: ignore[arg-type]
                            IndexedPauli(
                                pauli=Pauli.I, index=0  # type: ignore[arg-type]
                            ),
                        ],
                        coefficient=other,  # type: ignore[arg-type]
                    )
                ],
                num_qubits=1,
            )
        if not isinstance(other, SparsePauliOp):
            raise ClassiqValueError(
                f"Cannot add an object of type {type(other).__name__} to SparsePauliOp"
            )
        obj = SparsePauliOp(
            terms=LenList(self.terms + other.terms),
            num_qubits=max(self.num_qubits, other.num_qubits),
        )
        obj._gather_similar_elements()
        return obj

    def __sub__(self, other: Any) -> "SparsePauliOp":
        if not isinstance(other, SparsePauliOp):
            raise ClassiqValueError(
                f"Cannot substruct an object of type {type(other).__name__} to SparsePauliOp"
            )
        return self + -1.0 * other

    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, SparsePauliOp):
            raise ClassiqValueError(
                f"comparison operation not supported between SparsePauliOp and objects of type {type(other).__name__}"
            )
        self._gather_similar_elements()
        other._gather_similar_elements()
        return (
            all(
                (
                    self.terms[i] == other.terms[i]
                    or (
                        self.terms[i].coefficient == 0
                        and other.terms[i].coefficient == 0
                    )
                )
                for i in range(len(self.terms))
            )
            and self.num_qubits == other.num_qubits
        )

    def __str__(self) -> str:
        return " + ".join(f"{term}" for term in self.terms)

    def __truediv__(self, other: Any) -> "SparsePauliOp":
        if not isinstance(other, (int, float, complex)):
            raise ClassiqValueError(
                f"Cannot divide SparsePauliOp by object of type {type(other).__name__}"
            )
        if other == 0:
            raise ClassiqValueError("Cannot divide by zero")
        return self * (1 / other)


@dataclass
class CombinatorialOptimizationSolution:
    probability: CReal
    cost: CReal
    solution: CArray[CInt]
    count: CInt


@dataclass
class GaussianModel:
    num_qubits: CInt
    normal_max_value: CReal
    default_probabilities: CArray[CReal]
    rhos: CArray[CReal]
    loss: CArray[CInt]
    min_loss: CInt


@dataclass
class LogNormalModel:
    num_qubits: CInt
    mu: CReal
    sigma: CReal


BUILTIN_STRUCT_DECLARATIONS = {
    struct_decl.__name__: StructDeclaration(  # type: ignore[union-attr]
        name=struct_decl.__name__,  # type: ignore[union-attr]
        variables={
            field.name: PythonClassicalType().convert(field.type, nested=True)  # type: ignore[arg-type]
            for field in fields(struct_decl)
        },
    )
    for struct_decl in vars().values()
    if is_dataclass(struct_decl)
}


__all__ = [
    "CombinatorialOptimizationSolution",
    "GaussianModel",
    "IndexedPauli",
    "LogNormalModel",
    "PauliTerm",
    "SparsePauliOp",
    "SparsePauliTerm",
]
