from typing import TYPE_CHECKING, Any

from classiq.interface.exceptions import ClassiqError
from classiq.interface.helpers.text_utils import readable_list

from classiq.cudaq.cudaq_constants import NON_USER_GENERATED_GATES, QASM_CONSTANTS
from classiq.cudaq.cudaq_utils import CONVERSION_ERROR_PREFIX, QubitOrQreg

if TYPE_CHECKING:
    import cudaq
    import openqasm3


def eval_expr(
    params: dict[str, "cudaq.QuakeValue"], expr: "openqasm3.ast.Expression"
) -> Any:
    import openqasm3

    if isinstance(expr, openqasm3.ast.Identifier):
        if expr.name in QASM_CONSTANTS:
            return QASM_CONSTANTS[expr.name]
        if expr.name not in params:
            raise ClassiqError(
                CONVERSION_ERROR_PREFIX + f"name {expr.name!r} is not defined"
            )
        return params[expr.name]
    if isinstance(expr, openqasm3.ast.UnaryExpression):
        target = eval_expr(params, expr.expression)
        if expr.op == openqasm3.ast.UnaryOperator["~"]:
            return ~target
        if expr.op == openqasm3.ast.UnaryOperator["-"]:
            return -target
        raise ClassiqError(
            CONVERSION_ERROR_PREFIX + f"operation {str(expr.op)!r} is not supported"
        )
    if isinstance(expr, openqasm3.ast.BinaryExpression):
        left = eval_expr(params, expr.lhs)
        right = eval_expr(params, expr.rhs)
        if expr.op == openqasm3.ast.BinaryOperator["+"]:
            return left + right
        if expr.op == openqasm3.ast.BinaryOperator["-"]:
            return left - right
        if expr.op == openqasm3.ast.BinaryOperator["*"]:
            return left * right
        if expr.op == openqasm3.ast.BinaryOperator["/"]:
            return left / right
        raise ClassiqError(
            CONVERSION_ERROR_PREFIX + f"operation {str(expr.op)!r} is not supported"
        )
    if isinstance(expr, (openqasm3.ast.IntegerLiteral, openqasm3.ast.FloatLiteral)):
        return float(expr.value)
    raise ClassiqError(
        CONVERSION_ERROR_PREFIX
        + f"expression type {type(expr).__name__!r} is not supported"
    )


def eval_var(
    qubits: dict[str, QubitOrQreg],
    expr: "openqasm3.ast.IndexedIdentifier | openqasm3.ast.Identifier",
) -> QubitOrQreg:
    import openqasm3

    if isinstance(expr, openqasm3.ast.Identifier):
        if expr.name not in qubits:
            raise ClassiqError(
                CONVERSION_ERROR_PREFIX + f"name {expr.name!r} is not defined"
            )
        return qubits[expr.name]
    if isinstance(expr, openqasm3.ast.IndexedIdentifier):
        if expr.name.name not in qubits:
            raise ClassiqError(
                CONVERSION_ERROR_PREFIX + f"name {expr.name.name!r} is not defined"
            )
        if (
            len(expr.indices) != 1
            or not isinstance(accessor := expr.indices[0], list)
            or len(accessor) != 1
            or not isinstance(index := accessor[0], openqasm3.ast.IntegerLiteral)
        ):
            raise ClassiqError(
                CONVERSION_ERROR_PREFIX
                + "only simple subscript expressions are supported (for example, q[0])"
            )
        return qubits[expr.name.name][index.value]
    raise ClassiqError(
        CONVERSION_ERROR_PREFIX
        + f"expression type {type(expr).__name__!r} is not supported"
    )


def _get_expr_vars(
    params: dict[str, "cudaq.QuakeValue"], expr: "openqasm3.ast.Expression"
) -> set[str]:
    import openqasm3

    if isinstance(expr, openqasm3.ast.Identifier):
        if expr.name in QASM_CONSTANTS:
            return set()
        if expr.name not in params:
            raise ClassiqError(
                CONVERSION_ERROR_PREFIX + f"name {expr.name!r} is not defined"
            )
        return {expr.name}
    if isinstance(expr, openqasm3.ast.UnaryExpression):
        return _get_expr_vars(params, expr.expression)
    if isinstance(expr, openqasm3.ast.BinaryExpression):
        return _get_expr_vars(params, expr.lhs) | _get_expr_vars(params, expr.rhs)
    if isinstance(
        expr,
        (
            openqasm3.ast.IntegerLiteral,
            openqasm3.ast.FloatLiteral,
        ),
    ):
        return set()
    raise ClassiqError(
        CONVERSION_ERROR_PREFIX
        + f"expression type {type(expr).__name__!r} is not supported"
    )


def _eval_single_var(
    params: dict[str, "cudaq.QuakeValue"], expr: "openqasm3.ast.Expression"
) -> "cudaq.QuakeValue":
    expr_vars = _get_expr_vars(params, expr)
    if len(expr_vars) != 1:
        if len(expr_vars) == 0:
            suffix = "got none"
        else:
            suffix = f"got {readable_list(list(expr_vars), quote=True)}"
        raise ClassiqError(
            CONVERSION_ERROR_PREFIX
            + f"gate argument must contain exactly one angle variable, {suffix}"
        )
    return params[list(expr_vars)[0]]


def get_angle_args(
    gate_name: str,
    statement: "openqasm3.ast.QuantumGate",
    params: dict[str, "cudaq.QuakeValue"],
) -> list:
    if gate_name in NON_USER_GENERATED_GATES:  # (see CLS-6139)
        try:
            angle_args = [
                eval_expr({}, angle_expr) for angle_expr in statement.arguments
            ]
        except ClassiqError:
            raise ClassiqError(f"Unsupported {gate_name} call") from None
    else:
        angle_args = [
            _eval_single_var(params, angle_expr) for angle_expr in statement.arguments
        ]
    return angle_args
