from collections.abc import Mapping
from typing import TYPE_CHECKING, Literal

from classiq.interface.enum_utils import StrEnum
from classiq.interface.generator.arith.arithmetic import (
    ARITHMETIC_EXPRESSION_RESULT_NAME,
)
from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.model.quantum_expressions.quantum_expression import (
    QuantumAssignmentOperation,
)


class ArithmeticOperationKind(StrEnum):
    InplaceAdd = "inplace_add"
    Assignment = "assignment"
    InplaceXor = "inplace_xor"


class ArithmeticOperation(QuantumAssignmentOperation):
    if TYPE_CHECKING:
        kind: Literal["ArithmeticOperation"] = "ArithmeticOperation"
    else:
        kind: Literal["ArithmeticOperation"]

    operation_kind: ArithmeticOperationKind
    classical_assignment: bool = False

    @property
    def is_inplace(self) -> bool:
        return self.operation_kind in (
            ArithmeticOperationKind.InplaceXor,
            ArithmeticOperationKind.InplaceAdd,
        )

    @property
    def wiring_inouts(
        self,
    ) -> Mapping[str, Expr]:
        inouts = dict(super().wiring_inouts)
        if self.is_inplace and not self.classical_assignment:
            inouts[self.result_name()] = self.result_var
        return inouts

    @property
    def wiring_outputs(self) -> Mapping[str, Expr]:
        if self.is_inplace or self.classical_assignment:
            return {}
        return super().wiring_outputs

    @classmethod
    def result_name(cls) -> str:
        return ARITHMETIC_EXPRESSION_RESULT_NAME
