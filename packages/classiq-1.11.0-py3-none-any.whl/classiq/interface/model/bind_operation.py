from collections.abc import Mapping
from typing import TYPE_CHECKING, Literal

import pydantic

from classiq.interface.exceptions import ClassiqExpansionError
from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.generator.expressions.nodes.name import Name
from classiq.interface.generator.expressions.utilities.compatibility import (
    convert_pydantic_handle_to_expr,
)
from classiq.interface.model.handle_binding import HandleBinding
from classiq.interface.model.quantum_statement import QuantumOperation

BIND_INPUT_NAME = "bind_input"
BIND_OUTPUT_NAME = "bind_output"
BIND_PATH_EXPR_MESSAGE = (
    "Cannot use variable part (subscript, slice, or field access) in the source or "
    "destination of a 'bind' statement"
)


class BindOperation(QuantumOperation):
    if TYPE_CHECKING:
        kind: Literal["BindOperation"] = "BindOperation"
    else:
        kind: Literal["BindOperation"]

    in_handles: list[Name]
    out_handles: list[Name]

    @pydantic.field_validator("in_handles", mode="before")
    @classmethod
    def _in_handles_compatibility(
        cls, in_handles: list[HandleBinding | Expr | dict]
    ) -> list[Expr]:
        names = [convert_pydantic_handle_to_expr(in_handle) for in_handle in in_handles]
        if any(
            isinstance(handle, Expr) and not isinstance(handle, Name)
            for handle in names
        ):
            raise ClassiqExpansionError(BIND_PATH_EXPR_MESSAGE)
        return names

    @pydantic.field_validator("out_handles", mode="before")
    @classmethod
    def _out_handles_compatibility(
        cls, out_handles: list[HandleBinding | Expr | dict]
    ) -> list[Expr]:
        names = [convert_pydantic_handle_to_expr(handle) for handle in out_handles]
        if any(
            isinstance(handle, Expr) and not isinstance(handle, Name)
            for handle in names
        ):
            raise ClassiqExpansionError(BIND_PATH_EXPR_MESSAGE)
        return names

    @property
    def wiring_inputs(self) -> Mapping[str, Expr]:
        return {
            f"{BIND_INPUT_NAME}_{i}": handle for i, handle in enumerate(self.in_handles)
        }

    @property
    def wiring_outputs(self) -> Mapping[str, Expr]:
        return {
            f"{BIND_OUTPUT_NAME}_{i}": handle
            for i, handle in enumerate(self.out_handles)
        }

    def inverse(self) -> "BindOperation":
        return BindOperation(in_handles=self.out_handles, out_handles=self.in_handles)
