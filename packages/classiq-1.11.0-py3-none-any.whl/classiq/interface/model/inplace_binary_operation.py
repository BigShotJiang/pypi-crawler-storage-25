from collections.abc import Mapping
from typing import TYPE_CHECKING, Literal

import pydantic

from classiq.interface.enum_utils import StrEnum
from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.generator.expressions.utilities.compatibility import (
    convert_pydantic_handle_to_expr,
)
from classiq.interface.generator.expressions.utilities.path_expression import (
    get_path_expression_name,
)
from classiq.interface.generator.expressions.utilities.pydantic import ConcreteExpr
from classiq.interface.model.handle_binding import HandleBinding
from classiq.interface.model.quantum_statement import QuantumOperation


class BinaryOperation(StrEnum):
    Addition = "inplace_add"
    Xor = "inplace_xor"


class InplaceBinaryOperation(QuantumOperation):
    if TYPE_CHECKING:
        kind: Literal["InplaceBinaryOperation"] = "InplaceBinaryOperation"
    else:
        kind: Literal["InplaceBinaryOperation"]

    target: ConcreteExpr
    value: ConcreteExpr | Expression
    operation: BinaryOperation

    @pydantic.field_validator("target", mode="before")
    @classmethod
    def _target_compatibility(cls, target: HandleBinding | Expr | dict) -> Expr | dict:
        return convert_pydantic_handle_to_expr(target)

    @pydantic.field_validator("value", mode="before")
    @classmethod
    def _value_compatibility(
        cls, value: HandleBinding | Expr | Expression | dict
    ) -> Expr | Expression | dict:
        if isinstance(value, Expression) or (
            isinstance(value, dict) and "expr" in value
        ):
            return value
        return convert_pydantic_handle_to_expr(value)

    @property
    def wiring_inouts(self) -> Mapping[str, Expr]:
        inouts: dict[str, Expr] = {}
        for var in (self.target, self.value):
            if isinstance(var, Expression):
                continue
            inouts[get_path_expression_name(var)] = var
        return inouts

    @property
    def expressions(self) -> list[Expression]:
        return [self.value] if isinstance(self.value, Expression) else []
