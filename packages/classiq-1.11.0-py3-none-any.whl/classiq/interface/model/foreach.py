import ast
from typing import TYPE_CHECKING, Literal

import pydantic

from classiq.interface.ast_node import ASTNodeType, reset_lists
from classiq.interface.exceptions import ClassiqInternalError
from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.model.quantum_statement import QuantumOperation

if TYPE_CHECKING:
    from classiq.interface.model.statement_block import StatementBlock


class Foreach(QuantumOperation):
    if TYPE_CHECKING:
        kind: Literal["Foreach"] = "Foreach"
    else:
        kind: Literal["Foreach"]

    iter_vars: list[str]
    values: Expression
    body: "StatementBlock"

    _is_generative: bool = pydantic.PrivateAttr(default=False)

    @property
    def is_generative(self) -> bool:
        return self._is_generative

    @is_generative.setter
    def is_generative(self, value: bool) -> None:
        self._is_generative = value

    def _as_back_ref(self: ASTNodeType) -> ASTNodeType:
        return reset_lists(self, ["body"])

    @property
    def expressions(self) -> list[Expression]:
        return [self.values]

    @property
    def blocks(self) -> dict[str, "StatementBlock"]:
        return {"body": self.body}


def separate_foreach_values(
    values: Expression, iter_vars: list[str]
) -> list[dict[str, Expression]]:
    """Split a foreach's `values` into per-iteration `{iter_var: value_expr}`
    bindings by AST-level separation, without evaluating the expressions.

    This lets callers handle cases where an inner foreach's `values` reference
    outer iter-vars (e.g. inner `[i, j]`): we don't need a concrete list,
    just the AST elements, which we then feed to the downstream substitution.
    """
    tree = ast.parse(values.expr, mode="eval").body
    if not isinstance(tree, (ast.List, ast.Tuple)):
        raise ClassiqInternalError(
            f"Cannot separate non-literal foreach values: {values.expr!r}"
        )
    bindings: list[dict[str, Expression]] = []
    for elem in tree.elts:
        if len(iter_vars) == 1:
            element_exprs = [Expression(expr=ast.unparse(elem))]
        else:
            if not isinstance(elem, (ast.List, ast.Tuple)) or len(elem.elts) != len(
                iter_vars
            ):
                raise ClassiqInternalError(
                    f"Foreach with {len(iter_vars)} iter-vars expects each "
                    f"value to be a literal list of that length; got "
                    f"{ast.unparse(elem)!r}"
                )
            element_exprs = [Expression(expr=ast.unparse(e)) for e in elem.elts]
        bindings.append(dict(zip(iter_vars, element_exprs, strict=True)))
    return bindings
