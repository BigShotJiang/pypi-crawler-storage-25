from typing import Any, Union

import pydantic
from pydantic import ConfigDict, Field

from classiq.interface.ast_node import ASTNode
from classiq.interface.generator.expressions.expression import Expression


class HandleBinding(ASTNode):
    name: str = Field(default=None)  # type: ignore[assignment]
    model_config = ConfigDict(frozen=True, extra="forbid")


class NestedHandleBinding(HandleBinding):
    base_handle: "ConcreteHandleBinding"

    @pydantic.model_validator(mode="before")
    @classmethod
    def _set_name(cls, values: Any) -> dict[str, Any]:
        if isinstance(values, dict):
            orig = values
            while "base_handle" in dict(values):
                values = dict(values)["base_handle"]
            orig["name"] = dict(values).get("name")
            return orig
        if isinstance(values, NestedHandleBinding):
            values.name = values.base_handle.name  # type: ignore[misc]
            return values.model_dump()
        return values


class SubscriptHandleBinding(NestedHandleBinding):
    index: Expression
    model_config = ConfigDict(frozen=True, extra="forbid")


class SlicedHandleBinding(NestedHandleBinding):
    start: Expression
    end: Expression
    model_config = ConfigDict(frozen=True, extra="forbid")


class FieldHandleBinding(NestedHandleBinding):
    field: str
    model_config = ConfigDict(frozen=True, extra="forbid")


ConcreteHandleBinding = Union[
    HandleBinding,
    SubscriptHandleBinding,
    SlicedHandleBinding,
    FieldHandleBinding,
]
SubscriptHandleBinding.model_rebuild()
SlicedHandleBinding.model_rebuild()
FieldHandleBinding.model_rebuild()


class HandlesList(ASTNode):
    handles: list["GeneralHandle"]


GeneralHandle = Union[ConcreteHandleBinding, HandlesList]

HandlesList.model_rebuild()
