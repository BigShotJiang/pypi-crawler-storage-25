from typing import TYPE_CHECKING

import pydantic

from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.model.quantum_function_declaration import (
    NamedParamsQuantumFunctionDeclaration,
)

if TYPE_CHECKING:
    from classiq.interface.model.statement_block import StatementBlock


class NativeFunctionDefinition(NamedParamsQuantumFunctionDeclaration):
    """
    Facilitates the creation of a user-defined composite function

    This class sets extra to forbid so that it can be used in a Union and not "steal"
    objects from other classes.
    """

    body: "StatementBlock" = pydantic.Field(
        default_factory=list, description="List of function calls to perform."
    )

    # Maps output port name -> {input port name -> depth}.
    # Populated by the depth estimation visitor.
    _depth_between_ports: dict[str, dict[str, Expression]] = pydantic.PrivateAttr(
        default_factory=dict
    )

    # The maximum depth across all source-destination pairs.
    # Populated by the depth estimation visitor.
    _max_depth: Expression | None = pydantic.PrivateAttr(default=None)

    # Maps gate name -> count expression.
    # Populated by the gate count estimation visitor.
    _gate_count: dict[str, Expression] = pydantic.PrivateAttr(default_factory=dict)

    @property
    def depth_between_ports(self) -> dict[str, dict[str, Expression]]:
        return self._depth_between_ports

    def set_depth_between_ports(
        self, depth_between_ports_dict: dict[str, dict[str, Expression]]
    ) -> None:
        self._depth_between_ports = depth_between_ports_dict

    @property
    def max_depth(self) -> Expression | None:
        return self._max_depth

    @max_depth.setter
    def max_depth(self, value: Expression) -> None:
        self._max_depth = value

    @property
    def gate_count(self) -> dict[str, Expression]:
        return self._gate_count

    def set_gate_count(self, gate_count: dict[str, Expression]) -> None:
        self._gate_count = gate_count
