from typing import TYPE_CHECKING, Literal

import pydantic

from classiq.interface.ast_node import ASTNodeType, reset_lists
from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.model.quantum_statement import QuantumOperation

if TYPE_CHECKING:
    from classiq.interface.model.statement_block import StatementBlock


class Repeat(QuantumOperation):
    if TYPE_CHECKING:
        kind: Literal["Repeat"] = "Repeat"
    else:
        kind: Literal["Repeat"]

    iter_var: str
    count: Expression
    body: "StatementBlock"

    _is_generative: bool = pydantic.PrivateAttr(default=False)

    @property
    def is_generative(self) -> bool:
        return self._is_generative

    @is_generative.setter
    def is_generative(self, value: bool) -> None:
        self._is_generative = value

    def _as_back_ref(self: ASTNodeType) -> ASTNodeType:
        return reset_lists(self, ["body"])

    @property
    def expressions(self) -> list[Expression]:
        return [self.count]

    @property
    def blocks(self) -> dict[str, "StatementBlock"]:
        return {"body": self.body}
