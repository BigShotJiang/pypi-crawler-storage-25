from typing import TYPE_CHECKING, Any, Literal

import pydantic

from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.generator.expressions.utilities.compatibility import (
    convert_pydantic_handle_to_expr,
)
from classiq.interface.generator.expressions.utilities.pydantic import ConcreteExpr
from classiq.interface.model.quantum_statement import QuantumOperation


class SetBoundsStatement(QuantumOperation):
    if TYPE_CHECKING:
        kind: Literal["SetBoundsStatement"] = "SetBoundsStatement"
    else:
        kind: Literal["SetBoundsStatement"]

    target: ConcreteExpr
    lower_bound: Expression | None
    upper_bound: Expression | None

    @pydantic.field_validator("target", mode="before")
    @classmethod
    def _target_compatibility(cls, target: Any) -> Any:
        return convert_pydantic_handle_to_expr(target)

    @property
    def expressions(self) -> list[Expression]:
        exprs = []
        if self.lower_bound is not None:
            exprs.append(self.lower_bound)
        if self.upper_bound is not None:
            exprs.append(self.upper_bound)
        return exprs
