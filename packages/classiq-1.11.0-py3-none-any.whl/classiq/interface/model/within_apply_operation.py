from typing import TYPE_CHECKING, Literal

from classiq.interface.ast_node import ASTNodeType, reset_lists
from classiq.interface.model.quantum_statement import QuantumOperation

if TYPE_CHECKING:
    from classiq.interface.model.statement_block import StatementBlock


class WithinApply(QuantumOperation):
    if TYPE_CHECKING:
        kind: Literal["WithinApply"] = "WithinApply"
    else:
        kind: Literal["WithinApply"]

    compute: "StatementBlock"
    action: "StatementBlock"

    def _as_back_ref(self: ASTNodeType) -> ASTNodeType:
        return reset_lists(self, ["compute", "action"])

    @property
    def blocks(self) -> dict[str, "StatementBlock"]:
        return {"compute": self.compute, "action": self.action}


class Compute(QuantumOperation):
    if TYPE_CHECKING:
        kind: Literal["Compute"] = "Compute"
    else:
        kind: Literal["Compute"]


class Action(QuantumOperation):
    if TYPE_CHECKING:
        kind: Literal["Action"] = "Action"
    else:
        kind: Literal["Action"]


class Uncompute(QuantumOperation):
    if TYPE_CHECKING:
        kind: Literal["Uncompute"] = "Uncompute"
    else:
        kind: Literal["Uncompute"]
