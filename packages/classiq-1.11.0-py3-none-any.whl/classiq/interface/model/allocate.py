from collections.abc import Mapping
from typing import TYPE_CHECKING, Literal

import pydantic

from classiq.interface.exceptions import ClassiqValueError
from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.generator.expressions.nodes.name import Name
from classiq.interface.generator.expressions.utilities.compatibility import (
    convert_pydantic_handle_to_expr,
)
from classiq.interface.generator.expressions.utilities.path_expression import (
    to_python_str,
)
from classiq.interface.model.handle_binding import HandleBinding
from classiq.interface.model.quantum_statement import QuantumOperation


class Allocate(QuantumOperation):
    if TYPE_CHECKING:
        kind: Literal["Allocate"] = "Allocate"
    else:
        kind: Literal["Allocate"]
    size: Expression | None = None
    is_signed: Expression | None = None
    fraction_digits: Expression | None = None
    target: Name

    @pydantic.field_validator("target", mode="before")
    @classmethod
    def _target_compatibility(cls, target: HandleBinding | Expr | dict) -> Expr | dict:
        target = convert_pydantic_handle_to_expr(target)
        if isinstance(target, Expr) and not isinstance(target, Name):
            raise ClassiqValueError(
                f"Cannot allocate partial quantum variable {to_python_str(target)!r}"
            )
        return target

    @property
    def wiring_outputs(self) -> Mapping[str, Expr]:
        return {"out": self.target}

    @property
    def expressions(self) -> list[Expression]:
        exprs = []
        if self.size is not None:
            exprs.append(self.size)
        if self.is_signed is not None:
            exprs.append(self.is_signed)
        if self.fraction_digits is not None:
            exprs.append(self.fraction_digits)
        return exprs
