"""
User-defined noise for Classiq-hosted simulators.

These types describe how noise is applied during noisy circuit simulation on Classiq
infrastructure.

**Depolarizing noise on gates** mixes the state with the maximally mixed state on the
support of the gate: with probability :math:`(4^n-1)/4^n \\cdot \\lambda` a uniform
Pauli error is applied (excluding identity), and otherwise the channel leaves the state
unchanged, where :math:`n` is the number of qubits the gate acts on and
:math:`\\lambda` is the ``probability`` parameter (valid range is :math:`0 \\leq \\lambda
\\leq 4^n/(4^n-1)`; common choices stay well below 1).

**Pauli noise** is a probabilistic mixture: each term is a Pauli product (written as a
string of ``I``, ``X``, ``Y``, ``Z`` per qubit, e.g. ``X`` on one qubit, ``IX`` or
``XY`` on two) with an associated probability. All term probabilities must sum to 1.

**Thermal relaxation** models energy decay and dephasing over a gate duration: use
coherent time constants ``t1`` (amplitude damping) and ``t2`` (dephasing) in any
consistent unit, the same unit for ``time`` as the gate duration, and optional
``excited_state_population`` for the equilibrium :math:`|1\\rangle` population. For
physical consistency, require :math:`T_2 \\leq 2 T_1`. This channel is defined for a
single computational qubit; attach it only to single-qubit gates in this specification.

**Readout noise** uses a 2-by-2 **assignment matrix**: row index is the true pre-measurement
computational state (0 or 1), column index is the classical outcome (0 or 1); entry
:math:`(i,j)` is the probability of recording outcome :math:`j` when the qubit was in
state :math:`|i\\rangle`. Each row must be non-negative and sum to 1. The symmetric
one-parameter readout model swaps 0 and 1 with probability ``p`` on each qubit for both
rows.

**Basis gates** list optional primitive gate names used when the simulator decomposes
circuits before attaching noise. If omitted, the backend uses its default primitive
set (commonly single-qubit rotations and one entangling gate type).

**Using custom noise in the SDK**

1. Build a ``ClassiqSimulatorNoiseSpecification`` with the fields you need (all are
   optional; an empty specification means an ideal simulation).

2. Pass it as ``simulator_noise_spec`` on ``ClassiqBackendPreferences``. The fields
   ``noise_model`` (a named preset from ``CLASSIQ_NOISE_MODELS``) and
   ``simulator_noise_spec`` are mutually exclusive: set at most one of them.

3. For high-level execution, put those preferences inside ``ExecutionPreferences``
   (import ``ExecutionPreferences`` from ``classiq.interface.executor.execution_preferences``)::

       ExecutionPreferences(
           backend_preferences=ClassiqBackendPreferences(
               backend_name=ClassiqSimulatorBackendNames.SIMULATOR,
               simulator_noise_spec=ClassiqSimulatorNoiseSpecification(
                   readout_bit_flip_probability=0.02,
               ),
           ),
           num_shots=1000,
       )
"""

from __future__ import annotations

from typing import Literal

import pydantic
from pydantic import Field, model_validator

from classiq.interface.helpers.custom_pydantic_types import PydanticProbabilityFloat


def _is_stochastic_readout_matrix(m: list[list[float]]) -> bool:
    if len(m) != 2 or any(len(row) != 2 for row in m):
        return False
    for row in m:
        s = sum(row)
        if s <= 0 or abs(s - 1.0) > 1e-6:
            return False
        if any(x < 0 or x > 1 for x in row):
            return False
    return True


class DepolarizingNoiseOnGate(pydantic.BaseModel):
    """
    Depolarizing noise applied uniformly to every occurrence of a named gate: the same
    error statistics on all qubit positions where that gate appears.
    """

    gate: str = Field(
        ...,
        description=(
            "Name of the noisy instruction in the gate set used for simulation "
            "(e.g. single-qubit 'x', 'h', 'id'; two-qubit 'cx', 'cz')."
        ),
        min_length=1,
    )
    probability: PydanticProbabilityFloat = Field(
        ...,
        description=(
            "Depolarizing strength in [0, 1] for typical settings; "
            "the channel is the identity at probability 0 and strongest at the upper limit "
            "allowed for that gate width."
        ),
    )
    num_qubits: Literal[1, 2] = Field(
        ...,
        description="Number of qubits the named gate acts on (1 or 2).",
    )


class LocalDepolarizingNoiseOnGate(DepolarizingNoiseOnGate):
    """
    Depolarizing noise on a named gate only when it acts on a specific ordered tuple of
    qubit indices (other placements of the same gate name are unaffected).
    """

    qubits: list[int] = Field(
        ...,
        description="Simulator qubit indices; length must equal num_qubits.",
        min_length=1,
    )

    @model_validator(mode="after")
    def _qubit_count_matches(self) -> LocalDepolarizingNoiseOnGate:
        if len(self.qubits) != self.num_qubits:
            raise ValueError(
                f"len(qubits) must equal num_qubits ({self.num_qubits}), "
                f"got {len(self.qubits)}"
            )
        if any(q < 0 for q in self.qubits):
            raise ValueError("qubit indices must be non-negative")
        return self


class PauliNoiseTerm(pydantic.BaseModel):
    """One Pauli operator and its probability within a mixed Pauli noise channel."""

    pauli: str = Field(
        ...,
        description=(
            "Tensor product of Pauli labels I, X, Y, Z -- one character per qubit, "
            "left to right in the same order as the gate's qubits. Examples: 'X' "
            "or 'Z' for one qubit; 'IX', 'ZZ', 'XY' for two."
        ),
        min_length=1,
    )
    probability: float = Field(..., ge=0.0, le=1.0)


class PauliNoiseOnGate(pydantic.BaseModel):
    """
    A mixed Pauli channel applied uniformly to every occurrence of a named gate (same
    statistics on all positions). Include an identity Pauli term when you want a fraction
    of executions to stay error-free.
    """

    gate: str = Field(..., min_length=1)
    num_qubits: Literal[1, 2] = Field(...)
    pauli_terms: list[PauliNoiseTerm] = Field(
        ...,
        min_length=1,
        description="Non-empty list; all term probabilities must sum to 1.",
    )

    @model_validator(mode="after")
    def _probs_sum(self) -> PauliNoiseOnGate:
        s = sum(t.probability for t in self.pauli_terms)
        if abs(s - 1.0) > 1e-5:
            raise ValueError(f"Pauli term probabilities must sum to 1, got {s}")
        return self


class ThermalRelaxationNoiseOnGate(pydantic.BaseModel):
    """
    Single-qubit amplitude-and-phase relaxation over the gate duration ``time``.
    Use only with single-qubit ``gate`` names; the channel acts on one tensor factor.
    """

    gate: str = Field(..., min_length=1)
    t1: float = Field(
        ...,
        gt=0,
        description="Energy relaxation time constant (T1); use the same unit as ``time``.",
    )
    t2: float = Field(
        ...,
        gt=0,
        description=(
            "Dephasing time constant (T2); must satisfy T2 <= 2 T1 for a physical "
            "Lindblad-type model."
        ),
    )
    time: float = Field(
        ...,
        ge=0,
        description="Duration the qubit experiences the channel (same unit as T1, T2).",
    )
    excited_state_population: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description="Equilibrium population of the excited |1> state (0 to 1).",
    )

    @model_validator(mode="after")
    def _t2_bound(self) -> ThermalRelaxationNoiseOnGate:
        if self.t2 > 2 * self.t1 + 1e-12:
            raise ValueError("T2 must be at most 2 T1 for this relaxation model")
        return self


class LocalReadoutNoise(pydantic.BaseModel):
    """
    Readout confusion for one simulator qubit using a full 2-by-2 assignment matrix
    (see module docstring).
    """

    qubit: int = Field(
        ...,
        ge=0,
        description="Index of the measured qubit in the simulator labeling.",
    )
    assignment_probabilities: list[list[float]] = Field(
        ...,
        description=(
            "2-by-2 row-stochastic matrix: rows |0>, |1>; columns classical outcomes 0, 1."
        ),
    )

    @model_validator(mode="after")
    def _matrix(self) -> LocalReadoutNoise:
        if not _is_stochastic_readout_matrix(self.assignment_probabilities):
            raise ValueError(
                "assignment_probabilities must be a 2-by-2 row-stochastic matrix "
                "with non-negative entries"
            )
        return self


class ClassiqSimulatorNoiseSpecification(pydantic.BaseModel):
    """
    Complete custom noise description for Classiq noisy simulators. Combine any subset
    of the fields; an empty specification means an ideal (noise-free) simulation.

    Global readout settings (symmetric bit-flip probability or a shared 2-by-2 assignment
    matrix for every qubit) cannot both be set. Per-qubit readout in
    ``local_readout_errors`` uses the same matrix convention as in ``LocalReadoutNoise``.
    """

    basis_gates: list[str] | None = Field(
        default=None,
        description=(
            "Primitive gate names the simulator should treat as native when resolving "
            "noise on transpiled circuits. If None, the execution backend uses its "
            "default primitive list (often id, rz, sx, cx or an equivalent set)."
        ),
    )
    readout_bit_flip_probability: PydanticProbabilityFloat | None = Field(
        default=None,
        description=(
            "Symmetric classical bit-flip probability on measurement for all qubits: "
            "P(wrong outcome|state) = p for both |0> and |1>. Mutually exclusive with "
            "readout_assignment_probabilities."
        ),
    )
    readout_assignment_probabilities: list[list[float]] | None = Field(
        default=None,
        description=(
            "Single 2-by-2 readout assignment matrix applied to every qubit's measurement "
            "(same convention as LocalReadoutNoise). Mutually exclusive with "
            "readout_bit_flip_probability."
        ),
    )
    local_readout_errors: list[LocalReadoutNoise] = Field(
        default_factory=list,
        description="Per-qubit readout matrices; indices refer to simulator qubits.",
    )

    gate_depolarizing_errors: list[DepolarizingNoiseOnGate] = Field(
        default_factory=list,
        description="Depolarizing noise on all positions of each listed gate name.",
    )
    local_depolarizing_errors: list[LocalDepolarizingNoiseOnGate] = Field(
        default_factory=list,
        description="Depolarizing noise only when the gate appears on the given qubits.",
    )
    gate_pauli_errors: list[PauliNoiseOnGate] = Field(
        default_factory=list,
        description="Mixed Pauli noise on all positions of each listed gate name.",
    )
    gate_thermal_relaxation_errors: list[ThermalRelaxationNoiseOnGate] = Field(
        default_factory=list,
        description="Thermal relaxation after each listed single-qubit gate.",
    )

    @model_validator(mode="after")
    def _exclusive_symmetric_readout(self) -> ClassiqSimulatorNoiseSpecification:
        if (
            self.readout_bit_flip_probability is not None
            and self.readout_assignment_probabilities is not None
        ):
            raise ValueError(
                "Specify at most one of readout_bit_flip_probability and "
                "readout_assignment_probabilities"
            )
        if (
            self.readout_assignment_probabilities is not None
            and not _is_stochastic_readout_matrix(self.readout_assignment_probabilities)
        ):
            raise ValueError(
                "readout_assignment_probabilities must be a 2-by-2 row-stochastic matrix"
            )
        return self
