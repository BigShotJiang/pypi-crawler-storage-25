from collections.abc import Iterable
from typing import Any

import pydantic
from pydantic import BaseModel

from classiq.interface.backend.quantum_backend_providers import ProviderVendor
from classiq.interface.hardware import Provider


class BackendPreferences(BaseModel):
    """
    Preferences for the execution of the quantum program.

    Attributes:
        backend_service_provider (str): Provider company or cloud for the requested backend.
        backend_name (str): Name of the requested backend or target.
    """

    backend_service_provider: ProviderVendor = pydantic.Field(
        ..., description="Provider company or cloud for the requested backend."
    )
    backend_name: str = pydantic.Field(
        ..., description="Name of the requested backend or target."
    )

    @property
    def hw_provider(self) -> Provider:
        return Provider(self.backend_service_provider)

    @classmethod
    def batch_preferences(
        cls, *, backend_names: Iterable[str], **kwargs: Any
    ) -> list["BackendPreferences"]:
        return [cls(backend_name=name, **kwargs) for name in backend_names]

    def is_nvidia_backend(self) -> bool:
        return False
