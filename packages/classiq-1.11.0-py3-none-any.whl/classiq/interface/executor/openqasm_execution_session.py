from pydantic import BaseModel, Field

from classiq.interface.executor.execution_preferences import ExecutionPreferences
from classiq.interface.helpers.custom_encoders import CUSTOM_ENCODERS


class OpenQasmExecutionSessionRequest(BaseModel, json_encoders=CUSTOM_ENCODERS):
    """Body for creating an execution session from OpenQASM text (same job flow as qprog)."""

    qasm: str
    execution_preferences: ExecutionPreferences = Field(
        default_factory=ExecutionPreferences
    )
