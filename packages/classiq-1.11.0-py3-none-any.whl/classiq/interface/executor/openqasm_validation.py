"""Validate OpenQASM source strings before execution (no Qiskit dependency)."""

from __future__ import annotations

import re

from classiq.interface.exceptions import ClassiqValueError

# Mirrors qiskit_extension.qiskit_qasm_adapter header detection for QASM 3.
_BLOCK_COMMENT = r"\/\*(\*(?!\/)|[^*])*\*\/"
_LINE_COMMENT = r"\/\/.*\n"
_QASM3_DECL = r"OPENQASM\s+3(?:\.0)?\s*;"
_LEGAL_QASM3_HEADER = re.compile(
    rf"^({_BLOCK_COMMENT}|{_LINE_COMMENT}|\s)*{_QASM3_DECL}"
)
_QASM2_HEADER = re.compile(
    rf"^({_BLOCK_COMMENT}|{_LINE_COMMENT}|\s)*OPENQASM\s+2(?:\.0)?\s*;",
)


def validate_openqasm_source_text(qasm: str) -> None:
    """
    Ensure ``qasm`` looks like OpenQASM 2 or 3 (valid program header after optional
    leading whitespace and ``//`` or ``/* */`` comments).

    Raises:
        ClassiqValueError: If the string is empty or does not start with a valid
            OpenQASM header.
    """
    if qasm is None or not qasm.strip():
        raise ClassiqValueError("OpenQASM source is empty.")
    if _LEGAL_QASM3_HEADER.match(qasm):
        return
    if _QASM2_HEADER.match(qasm):
        return
    raise ClassiqValueError(
        "Invalid OpenQASM: the source must begin with an OPENQASM 2.0 or OPENQASM 3.0 "
        "program header (optional leading whitespace and // or /* */ comments). "
        "Plain text and other formats are not accepted."
    )
