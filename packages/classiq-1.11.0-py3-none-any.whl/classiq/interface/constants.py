DEFAULT_DECIMAL_PRECISION = 4
HIDDEN_VAR_PREFIX = "__"  # Beware using prefix inside methods of a class. Python mangling may change the prefix.
DROP_POOL_PREFIX = HIDDEN_VAR_PREFIX + "drop_pool"
