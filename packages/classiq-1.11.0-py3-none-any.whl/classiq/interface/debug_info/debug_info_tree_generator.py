from dataclasses import dataclass
from typing import Optional
from uuid import UUID

from classiq.interface.debug_info.debug_info import FunctionDebugInfo
from classiq.interface.exceptions import ClassiqInternalError
from classiq.interface.model.block import Block
from classiq.interface.model.model import Model
from classiq.interface.model.quantum_expressions.quantum_expression import (
    QuantumExpressionOperation,
)
from classiq.interface.model.statement_block import (
    ConcreteQuantumStatement,
    StatementBlock,
)


@dataclass
class StatementMetadata:
    uuid: UUID
    child_statements: list["StatementMetadata"]
    backref_statement: Optional["StatementMetadata"]
    debug_info_node_backref_statement: ConcreteQuantumStatement | None
    in_compiled_qmod: bool
    statement: ConcreteQuantumStatement
    debug_info_node_statement: ConcreteQuantumStatement | None


def update_statements_in_statements_block(
    statements: StatementBlock,
    keys: list[tuple[int, StatementMetadata]],
    all_statements: dict[str, StatementMetadata],
    indent: int = 0,
) -> None:
    for statement in statements:
        if str(statement.uuid) not in all_statements:
            all_statements[str(statement.uuid)] = StatementMetadata(
                uuid=statement.uuid,
                child_statements=[],
                backref_statement=None,
                debug_info_node_backref_statement=None,
                in_compiled_qmod=True,
                statement=statement,
                debug_info_node_statement=None,
            )
        else:
            if statement.kind != all_statements[str(statement.uuid)].statement.kind:
                raise ClassiqInternalError(
                    f"Statement {statement.uuid} already in all_statements"
                )
        keys.append((indent, all_statements[str(statement.uuid)]))
        for block in statement.blocks.values():
            update_statements_in_statements_block(
                block, keys, all_statements, indent + 1
            )


def update_statements_in_model(
    compiled_qmod: Model,
    function_to_function_tree: dict[str, list[tuple[int, StatementMetadata]]],
    all_statements: dict[str, StatementMetadata],
) -> None:
    for function in compiled_qmod.functions:
        function_to_function_tree[function.name] = []
        update_statements_in_statements_block(
            function.body, function_to_function_tree[function.name], all_statements
        )


def create_empty_statement_metadata_from_debug_info(
    debug_info: dict[str, FunctionDebugInfo],
    statement_uuid: UUID,
    all_statements_metadata: dict[str, StatementMetadata],
) -> StatementMetadata:
    node_statement = debug_info[str(statement_uuid)].node
    if node_statement is None:
        raise ClassiqInternalError(
            f"Node statement is None for statement {statement_uuid}"
        )
    if str(statement_uuid) not in all_statements_metadata:
        all_statements_metadata[str(statement_uuid)] = StatementMetadata(
            uuid=statement_uuid,
            child_statements=[],
            backref_statement=None,
            debug_info_node_backref_statement=None,
            in_compiled_qmod=False,
            statement=node_statement,
            debug_info_node_statement=None,
        )
    return all_statements_metadata[str(statement_uuid)]


def add_backrefs_statements_and_connections(
    debug_info: dict[str, FunctionDebugInfo],
    all_statements_metadata: dict[str, StatementMetadata],
) -> None:
    statements_to_backref: list[ConcreteQuantumStatement] = [
        statement_metadata.statement
        for statement_metadata in all_statements_metadata.values()
    ]
    while len(statements_to_backref) > 0:
        statement = statements_to_backref.pop(0)

        if statement.back_ref is not None:
            backref_statement_uuid = statement.back_ref
            if str(backref_statement_uuid) not in all_statements_metadata:
                create_empty_statement_metadata_from_debug_info(
                    debug_info, backref_statement_uuid, all_statements_metadata
                )
            all_statements_metadata[
                str(backref_statement_uuid)
            ].child_statements.append(all_statements_metadata[str(statement.uuid)])
            all_statements_metadata[str(statement.uuid)].backref_statement = (
                all_statements_metadata[str(backref_statement_uuid)]
            )

            if (
                all_statements_metadata[str(backref_statement_uuid)].statement.uuid
                != backref_statement_uuid
            ):
                raise ClassiqInternalError(
                    f"Backref statement {backref_statement_uuid} is not the same as the statement {statement.uuid}"
                )

            statements_to_backref.append(
                all_statements_metadata[str(backref_statement_uuid)].statement
            )
        """
        if str(statement.uuid) in debug_info and \
            debug_info[str(statement.uuid)].node is not None and \
            debug_info[str(statement.uuid)].node.back_ref is not None:
            debug_info_node_backref_statement_uuid = debug_info[str(statement.uuid)].node.back_ref
            if str(debug_info_node_backref_statement_uuid) not in all_statements_metadata and \
                str(debug_info_node_backref_statement_uuid) in debug_info:
                create_empty_statement_metadata_from_debug_info(debug_info, debug_info_node_backref_statement_uuid, all_statements_metadata)
            all_statements_metadata[str(debug_info_node_backref_statement_uuid)].child_statements.append(all_statements_metadata[str(statement.uuid)])
            all_statements_metadata[str(statement.uuid)].debug_info_node_backref_statement = all_statements_metadata[str(debug_info_node_backref_statement_uuid)]
            statements_to_backref.append(all_statements_metadata[str(debug_info_node_backref_statement_uuid)].statement)
        """


def add_debug_info_to_statements(
    debug_info: dict[str, FunctionDebugInfo],
    all_statements: dict[str, StatementMetadata],
) -> None:
    for statement_uuid, statement_metadata in all_statements.items():
        if str(statement_uuid) in debug_info:
            statement_metadata.debug_info_node_statement = debug_info[
                str(statement_uuid)
            ].node


def get_debug_info_trees(
    compiled_qmod: Model,
) -> tuple[
    dict[str, list[tuple[int, StatementMetadata]]], dict[str, StatementMetadata]
]:
    debug_info = compiled_qmod.debug_info.data
    all_statements: dict[str, StatementMetadata] = {}
    function_to_function_tree: dict[str, list[tuple[int, StatementMetadata]]] = {}

    function_to_function_tree["unknown"] = []

    # Get all statements from the model itself into the dictionary
    update_statements_in_model(compiled_qmod, function_to_function_tree, all_statements)

    # use backref to get the history of the statements.
    add_backrefs_statements_and_connections(debug_info, all_statements)

    # add debug info to the statements
    add_debug_info_to_statements(debug_info, all_statements)

    return function_to_function_tree, all_statements


def get_statement_string(statement: ConcreteQuantumStatement) -> str:
    ret = f"({str(statement.uuid)[:6]}...) -- {statement.kind}"
    if isinstance(statement, QuantumExpressionOperation):
        ret += f" - expression: {statement.expression.expr}"
    if isinstance(statement, Block):
        ret += f" - label: {statement.label}"

    return ret


def get_statement_metadata_string(statement_metadata: StatementMetadata) -> str:
    ret = get_statement_string(statement_metadata.statement)

    if statement_metadata.debug_info_node_statement is not None:
        ret += f" (debug_info_node_statement_type: {statement_metadata.debug_info_node_statement.kind}"

        if isinstance(
            statement_metadata.debug_info_node_statement, QuantumExpressionOperation
        ):
            ret += f" - debug info node expression: {statement_metadata.debug_info_node_statement.expression.expr}"
        if isinstance(statement_metadata.debug_info_node_statement, Block):
            ret += f" - debug info node label: {statement_metadata.debug_info_node_statement.label}"

        ret += ")"
    return ret


def print_debug_info_tree(
    statement_metadata_inst: StatementMetadata, indent: int, extra_indent_str: str
) -> str:
    lines = []
    prefix = "  " * indent
    prefix += extra_indent_str
    lines.append(f"{prefix}- {get_statement_metadata_string(statement_metadata_inst)}")

    if (
        statement_metadata_inst.backref_statement is not None
        and statement_metadata_inst.debug_info_node_backref_statement is not None
        and statement_metadata_inst.backref_statement.uuid
        == statement_metadata_inst.debug_info_node_backref_statement.uuid
    ):
        lines.append(
            print_debug_info_tree(
                statement_metadata_inst.backref_statement,
                indent,
                len(extra_indent_str) * " " + "#> ",
            )
        )
    else:
        if statement_metadata_inst.backref_statement is not None:
            lines.append(
                print_debug_info_tree(
                    statement_metadata_inst.backref_statement,
                    indent,
                    len(extra_indent_str) * " " + "> ",
                )
            )
        if statement_metadata_inst.debug_info_node_backref_statement is not None:
            lines.append(
                " " * (indent + len(extra_indent_str) + 1)
                + "# "
                + get_statement_string(
                    statement_metadata_inst.debug_info_node_backref_statement
                )
            )
    return "\n".join(lines)


def print_debug_info_trees(
    function_to_function_tree: dict[str, list[tuple[int, StatementMetadata]]],
) -> str:
    lines = []
    for function_name, function_tree in function_to_function_tree.items():
        lines.append(f"<<{function_name}>>")
        for indent, statement_metadata in function_tree:
            lines.append(print_debug_info_tree(statement_metadata, indent, ""))
    return "\n".join(str(line) for line in lines)


def generate_and_print_debug_info_trees(
    compiled_qmod: Model,
) -> str:
    debug_info_trees, _ = get_debug_info_trees(compiled_qmod)
    return print_debug_info_trees(debug_info_trees)
