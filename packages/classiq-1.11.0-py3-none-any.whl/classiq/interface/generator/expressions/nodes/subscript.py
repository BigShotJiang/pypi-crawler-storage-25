from typing import TYPE_CHECKING, Any, Literal

import pydantic

from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.helpers.pydantic_model_helpers import values_with_discriminator

if TYPE_CHECKING:
    from classiq.interface.generator.expressions.utilities.pydantic import ConcreteExpr


class Subscript(Expr):
    if TYPE_CHECKING:
        kind: Literal["Subscript"] = "Subscript"
    else:
        kind: Literal["Subscript"]
    value: "ConcreteExpr"
    index: Expression

    @pydantic.model_validator(mode="before")
    @classmethod
    def _set_kind(cls, values: Any) -> dict[str, Any]:
        return values_with_discriminator(values, "kind", "Subscript")
