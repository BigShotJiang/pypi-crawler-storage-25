import abc

from classiq.interface.ast_node import HashableASTNode


class Expr(HashableASTNode, abc.ABC):
    pass
