from collections.abc import Mapping
from typing import TYPE_CHECKING, Union

from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.generator.expressions.utilities.path_expression import (
    to_python_str,
)

if TYPE_CHECKING:
    from classiq.interface.generator.expressions.expression_types import ExpressionValue


class ClassicalProxy:
    def __init__(self, handle: Expr) -> None:
        self._handle = handle

    @property
    def handle(self) -> Expr:
        return self._handle

    def __str__(self) -> str:
        return to_python_str(self.handle)

    @property
    def fields(self) -> Mapping[str, Union["ExpressionValue", "ClassicalProxy"]]:
        raise NotImplementedError

    @property
    def type_name(self) -> str:
        raise NotImplementedError
