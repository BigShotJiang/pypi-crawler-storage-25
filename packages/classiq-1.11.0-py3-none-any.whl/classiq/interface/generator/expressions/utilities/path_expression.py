from __future__ import annotations

from collections.abc import Iterable
from itertools import chain

from classiq.interface.exceptions import (
    ClassiqInternalError,
    ClassiqInternalExpansionError,
)
from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.generator.expressions.nodes.array import Array
from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.generator.expressions.nodes.member_access import MemberAccess
from classiq.interface.generator.expressions.nodes.name import Name
from classiq.interface.generator.expressions.nodes.slice import Slice
from classiq.interface.generator.expressions.nodes.subscript import Subscript

HANDLE_ID_SEPARATOR = "___"


def _get_expr_id(expr: Expression) -> str:
    if expr.expr.isidentifier() or expr.expr.isnumeric():
        return expr.expr
    return str(abs(hash(expr.expr)))


def flatten_expr(expr: Expr) -> list[Expr]:
    source = get_path_expression_source(expr)
    if isinstance(source, Array):
        return list(chain.from_iterable(map(flatten_expr, source.elements)))
    return [expr]


def exprs_to_dict(exprs: Iterable[Expr]) -> dict[str, Expr]:
    return {get_path_expression_name(expr): expr for expr in exprs}


def get_path_expression_source(expr: Expr) -> Name | Array:
    if isinstance(expr, (Name, Array)):
        return expr
    if isinstance(expr, (Subscript, Slice, MemberAccess)):
        return get_path_expression_source(expr.value)
    raise ClassiqInternalError(f"{type(expr).__name__!r} is not a path expression")


def get_concatenation_sources(expr: Array) -> list[Expr]:
    return list(
        chain.from_iterable(
            (
                get_concatenation_sources(element)
                if isinstance(element, Array)
                else [element]
            )
            for element in expr.elements
        )
    )


def get_path_expression_name(expr: Expr) -> str:
    name = get_path_expression_source(expr)
    if not isinstance(name, Name):
        raise ClassiqInternalError(f"Name expected, got {type(name).__name__!r} source")
    return name.name


def is_collapsed(expr: Expr) -> bool:
    if isinstance(expr, Name):
        return True
    if isinstance(expr, Array):
        return all(map(is_collapsed, expr.elements))
    if isinstance(expr, MemberAccess):
        return is_collapsed(expr.value)
    if isinstance(expr, (Subscript, Slice)):
        return not isinstance(expr.value, Slice) and is_collapsed(expr.value)
    raise ClassiqInternalError(f"{type(expr).__name__!r} is not a path expression")


def to_python_str(expr: Expr) -> str:
    if isinstance(expr, Name):
        return expr.name
    if isinstance(expr, Array):
        return f"[{', '.join(map(to_python_str, expr.elements))}]"
    if isinstance(expr, MemberAccess):
        return f"{to_python_str(expr.value)}.{expr.member}"
    if isinstance(expr, Subscript):
        return f"{to_python_str(expr.value)}[{expr.index.expr}]"
    if isinstance(expr, Slice):
        return f"{to_python_str(expr.value)}[{expr.start.expr}:{expr.stop.expr}]"
    raise ClassiqInternalError(f"{type(expr).__name__!r} is not a path expression")


def get_identifier(expr: Expr) -> str:
    if isinstance(expr, Name):
        return expr.name
    if isinstance(expr, MemberAccess):
        return f"{get_identifier(expr.value)}{HANDLE_ID_SEPARATOR}{expr.member}"
    if isinstance(expr, Subscript):
        return f"{get_identifier(expr.value)}{HANDLE_ID_SEPARATOR}{_get_expr_id(expr.index)}"
    if isinstance(expr, Slice):
        return f"{get_identifier(expr.value)}{HANDLE_ID_SEPARATOR}{_get_expr_id(expr.start)}_{_get_expr_id(expr.stop)}"
    raise ClassiqInternalError(f"Unexpected Expr type {type(expr).__name__!r}")


def get_expressions(expr: Expr) -> list[Expression]:
    if isinstance(expr, Name):
        return []
    if isinstance(expr, Subscript):
        return get_expressions(expr.value) + [expr.index]
    if isinstance(expr, Slice):
        return get_expressions(expr.value) + [expr.start, expr.stop]
    if isinstance(expr, MemberAccess):
        return get_expressions(expr.value)
    if isinstance(expr, Array):
        return list(
            chain.from_iterable(get_expressions(element) for element in expr.elements)
        )
    raise ClassiqInternalError(f"Cannot get Expressions of {type(expr).__name__!r}")


def _get_collapsed_index(expr: Expr, index: Expression) -> Expression:
    if not isinstance(expr, (Subscript, Slice)):
        raise ClassiqInternalError(f"Unexpected Expr type {type(expr).__name__!r}")
    if not isinstance(expr.value, Slice):
        raise ClassiqInternalError(
            f"Unexpected nested Expr type {type(expr.value).__name__!r}"
        )
    if (
        index.is_evaluated()
        and index.is_constant()
        and expr.value.start.is_evaluated()
        and expr.value.start.is_constant()
    ):
        return Expression(
            expr=str(expr.value.start.to_int_value() + index.to_int_value())
        )
    return Expression(expr=f"({expr.value.start})+({index})")


def collapse(expr: Expr) -> Expr:
    if isinstance(expr, Name):
        return expr
    if isinstance(expr, Array):
        return Array(elements=[collapse(element) for element in expr.elements])
    if not isinstance(expr, (MemberAccess, Subscript, Slice)):
        raise ClassiqInternalError(f"Unexpected Expr type {type(expr).__name__!r}")
    if isinstance(expr.value, Slice):
        if isinstance(expr, Slice):
            return collapse(
                Slice(
                    value=expr.value.value,
                    start=_get_collapsed_index(expr, expr.start),
                    stop=_get_collapsed_index(expr, expr.stop),
                )
            )
        elif isinstance(expr, Subscript):
            return collapse(
                Subscript(
                    value=expr.value.value,
                    index=_get_collapsed_index(expr, expr.index),
                )
            )
    collapsed_value = collapse(expr.value)
    if collapsed_value is expr.value:
        return expr
    return expr.model_copy(update=dict(value=collapsed_value))


def set_prefix(expr: Expr, prefix: Expr) -> Expr:
    if isinstance(expr, (Subscript, Slice, MemberAccess)):
        return expr.model_copy(update=dict(value=set_prefix(expr.value, prefix)))
    return prefix


def replace_prefix(expr: Expr, prefix: Expr, replacement: Expr) -> Expr:
    if expr == prefix:
        return replacement
    if isinstance(expr, Name):
        return expr
    if (
        isinstance(expr, Subscript)
        and isinstance(prefix, Slice)
        and expr.value == prefix.value
        and expr.index.is_evaluated()
        and expr.index.is_constant()
        and is_constant(prefix)
        and prefix.start.to_int_value()
        <= expr.index.to_int_value()
        < prefix.stop.to_int_value()
    ):
        return Subscript(
            value=replacement,
            index=Expression(
                expr=str(expr.index.to_int_value() - prefix.start.to_int_value())
            ),
        )
    if (
        isinstance(expr, Slice)
        and isinstance(prefix, Slice)
        and expr.value == prefix.value
        and is_constant(expr)
        and is_constant(prefix)
    ):
        prefix_start = prefix.start.to_int_value()
        prefix_end = prefix.stop.to_int_value()
        self_start = expr.start.to_int_value()
        self_end = expr.stop.to_int_value()
        if (
            prefix_start <= self_start < prefix_end
            and prefix_start < self_end <= prefix_end
        ):
            return Slice(
                value=replacement,
                start=Expression(expr=str(self_start - prefix_start)),
                stop=Expression(expr=str(self_end - prefix_start)),
            )
    if not isinstance(expr, (MemberAccess, Subscript, Slice)):
        raise ClassiqInternalError(f"Unexpected Expr type {type(expr).__name__!r}")
    new_value = replace_prefix(expr.value, prefix, replacement)
    if new_value is not expr.value:
        return expr.model_copy(update=dict(value=new_value))
    return expr


def rename(expr: Expr, name: str) -> Expr:
    if isinstance(expr, Name):
        return expr.model_copy(update=dict(name=name))
    if isinstance(expr, (MemberAccess, Subscript, Slice)):
        return expr.model_copy(update=dict(value=rename(expr.value, name)))
    raise ClassiqInternalError(f"Unexpected Expr type {type(expr).__name__!r}")


def prefixes(expr: Expr) -> list[Expr]:
    if isinstance(expr, (Name, Array)):
        return [expr]
    if isinstance(expr, (MemberAccess, Subscript, Slice)):
        return prefixes(expr.value) + [expr]
    raise ClassiqInternalError(f"Unexpected Expr type {type(expr).__name__!r}")


def is_constant(expr: Expr) -> bool:
    if isinstance(expr, Name):
        return True
    if isinstance(expr, Subscript):
        return (
            is_constant(expr.value)
            and expr.index.is_evaluated()
            and expr.index.is_constant()
        )
    if isinstance(expr, Slice):
        return (
            is_constant(expr.value)
            and expr.start.is_evaluated()
            and expr.start.is_constant()
            and expr.stop.is_evaluated()
            and expr.stop.is_constant()
        )
    if isinstance(expr, MemberAccess):
        return is_constant(expr.value)
    raise ClassiqInternalError(f"Unexpected Expr type {type(expr).__name__!r}")


def _subscript_tail_overlaps(expr1: Subscript, expr2: Expr) -> bool:
    if isinstance(expr2, Subscript):
        return expr1.index == expr2.index
    if (
        isinstance(expr2, Slice)
        and expr1.index.is_evaluated()
        and expr1.index.is_constant()
        and is_constant(expr2)
    ):
        return (
            expr2.start.to_int_value()
            <= expr1.index.to_int_value()
            < expr2.stop.to_int_value()
        )
    return False


def _slice_tail_overlaps(expr1: Slice, expr2: Expr) -> bool:
    if not is_constant(expr1):
        return False
    start = expr1.start.to_int_value()
    stop = expr1.stop.to_int_value()
    if (
        isinstance(expr2, Subscript)
        and expr2.index.is_evaluated()
        and expr2.index.is_constant()
    ):
        return start <= expr2.index.to_int_value() < stop
    if isinstance(expr2, Slice) and is_constant(expr2):
        other_start = expr2.start.to_int_value()
        other_end = expr2.stop.to_int_value()
        return start <= other_start < stop or other_start <= start < other_end
    return False


def _tail_overlaps(expr1: Expr, expr2: Expr) -> bool:
    if isinstance(expr1, Name):
        expr1_name = get_path_expression_name(expr1)
        expr2_name = get_path_expression_name(expr2)
        return expr1_name == expr2_name
    if isinstance(expr1, Subscript):
        return _subscript_tail_overlaps(expr1, expr2)
    if isinstance(expr1, Slice):
        return _slice_tail_overlaps(expr1, expr2)
    if isinstance(expr1, MemberAccess):
        return isinstance(expr2, MemberAccess) and expr1.member == expr2.member
    raise ClassiqInternalError(f"Unexpected Expr type {type(expr1).__name__!r}")


def overlaps(expr1: Expr, expr2: Expr) -> bool:
    if not is_collapsed(expr1) or not is_collapsed(expr2):
        raise ClassiqInternalExpansionError(
            "Expr must be collapsed before calling this function"
        )
    self_prefixes = prefixes(expr1)
    other_prefixes = prefixes(expr2)
    return all(
        _tail_overlaps(self_prefix, other_prefix)
        for self_prefix, other_prefix in zip(self_prefixes, other_prefixes)
    )
