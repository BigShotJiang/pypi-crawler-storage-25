from typing import TYPE_CHECKING, Annotated, Union

import pydantic

from classiq.interface.generator.expressions.nodes.array import Array
from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.generator.expressions.nodes.member_access import MemberAccess
from classiq.interface.generator.expressions.nodes.name import Name
from classiq.interface.generator.expressions.nodes.slice import Slice
from classiq.interface.generator.expressions.nodes.subscript import Subscript

if TYPE_CHECKING:
    ConcreteExpr = Expr
else:
    ConcreteExpr = Annotated[
        Union[Name, Subscript, Slice, MemberAccess, Array],
        pydantic.Field(..., discriminator="kind"),
    ]

Subscript.model_rebuild()
Slice.model_rebuild()
MemberAccess.model_rebuild()
Array.model_rebuild()
