from __future__ import annotations

from typing import Any

import pydantic

from classiq.interface.exceptions import ClassiqInternalError
from classiq.interface.generator.expressions.nodes.array import Array
from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.generator.expressions.nodes.member_access import MemberAccess
from classiq.interface.generator.expressions.nodes.name import Name
from classiq.interface.generator.expressions.nodes.slice import Slice
from classiq.interface.generator.expressions.nodes.subscript import Subscript
from classiq.interface.generator.expressions.utilities.pydantic import ConcreteExpr
from classiq.interface.model.handle_binding import (
    ConcreteHandleBinding,
    FieldHandleBinding,
    GeneralHandle,
    HandleBinding,
    HandlesList,
    SlicedHandleBinding,
    SubscriptHandleBinding,
)


def convert_handle_to_expr(handle: GeneralHandle | Expr) -> Expr:
    if isinstance(handle, Expr):
        return handle
    if isinstance(handle, SubscriptHandleBinding):
        return Subscript(
            value=convert_handle_to_expr(handle.base_handle), index=handle.index
        )
    if isinstance(handle, SlicedHandleBinding):
        return Slice(
            value=convert_handle_to_expr(handle.base_handle),
            start=handle.start,
            stop=handle.end,
        )
    if isinstance(handle, FieldHandleBinding):
        return MemberAccess(
            value=convert_handle_to_expr(handle.base_handle), member=handle.field
        )
    if isinstance(handle, HandleBinding):
        return Name(name=handle.name)
    if isinstance(handle, HandlesList):
        return Array(
            elements=[convert_handle_to_expr(element) for element in handle.handles]
        )
    raise ClassiqInternalError(f"Cannot convert {type(handle).__name__!r} to Expr")


def convert_pydantic_handle_to_expr(data: Any) -> Expr:
    if isinstance(data, dict):
        if "kind" in data:
            data = pydantic.TypeAdapter(ConcreteExpr).validate_python(data)
        else:
            data = pydantic.TypeAdapter(ConcreteHandleBinding).validate_python(data)
    if isinstance(data, Expr):
        return data
    return convert_handle_to_expr(data)


def convert_pydantic_general_handle_or_any_to_expr(data: Any) -> Any:
    if isinstance(data, dict):
        if "kind" in data:
            data = pydantic.TypeAdapter(ConcreteExpr).validate_python(data)
        elif "handles" in data:
            data = pydantic.TypeAdapter(HandlesList).validate_python(data)
        elif "base_handle" in data or (
            set(data) - {"source_ref", "back_ref"} == {"name"}
        ):
            data = pydantic.TypeAdapter(ConcreteHandleBinding).validate_python(data)
        else:
            return data
    if isinstance(data, Expr):
        return data
    if isinstance(data, (HandleBinding, HandlesList)):
        return convert_handle_to_expr(data)
    return data
