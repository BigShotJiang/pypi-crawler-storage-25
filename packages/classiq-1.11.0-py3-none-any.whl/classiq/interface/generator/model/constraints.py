from typing import Union

import pydantic
from pydantic import BaseModel

from classiq.interface.enum_utils import StrEnum
from classiq.interface.exceptions import ClassiqValueError
from classiq.interface.generator.transpiler_basis_gates import TranspilerBasisGates

UNCONSTRAINED = -1


class OptimizationParameter(StrEnum):
    WIDTH = "width"
    DEPTH = "depth"
    NO_OPTIMIZATION = "no_opt"


OptimizationParameterType = Union[OptimizationParameter, TranspilerBasisGates]


def optimization_parameter_type_from_string(param: str) -> OptimizationParameterType:
    for enum_ in (OptimizationParameter, TranspilerBasisGates):
        try:
            return enum_(param)
        except ValueError:
            pass
    raise ClassiqValueError(f"Invalid OptimizationParameterType {param}")


class Constraints(BaseModel):
    """
    Constraints for the quantum circuit synthesis engine.

    This class is used to specify constraints such as maximum width, depth,
    gate count, and optimization parameters for the synthesis engine,
    guiding the generation of quantum circuits that satisfy these constraints.

    Attributes:
        max_width (int):
            Maximum number of qubits allowed in the generated quantum circuit.
            Defaults to `None`.
        optimization_parameter (OptimizationParameterType):
            Determines if and how the synthesis engine should optimize
            the solution. Defaults to `NO_OPTIMIZATION`. See `OptimizationParameterType`
    """

    max_width: pydantic.PositiveInt | None = pydantic.Field(
        default=None,
        description="Maximum number of qubits in generated quantum circuit",
    )

    optimization_parameter: OptimizationParameterType = pydantic.Field(
        default=OptimizationParameter.NO_OPTIMIZATION,
        description="If set, the synthesis engine optimizes the solution"
        " according to that chosen parameter",
    )
