"""
The file include various feature maps for QML applications.
"""

from enum import IntEnum
from itertools import combinations

import numpy as np

from classiq.interface.exceptions import ClassiqValueError

from classiq.open_library.functions.utility_functions import hadamard_transform
from classiq.qmod.builtins.enums import Pauli
from classiq.qmod.builtins.functions.exponentiation import multi_suzuki_trotter
from classiq.qmod.builtins.operations import power
from classiq.qmod.builtins.structs import IndexedPauli, SparsePauliOp, SparsePauliTerm
from classiq.qmod.cparam import CInt, CReal
from classiq.qmod.qfunc import qfunc
from classiq.qmod.qmod_parameter import CArray
from classiq.qmod.qmod_variable import QArray

THRESHOLD = 1e-13


class ConnectivityType(IntEnum):
    """Type of qubit connectivity for feature map construction."""

    LINEAR = 0
    CIRCULAR = 1
    FULL = 2


# Pauli feature map
def generate_connectivity_map(
    list_size: int, sublist_size: int, connectivity_type: ConnectivityType
) -> list[list[int]]:
    """
    Generate connectivity for a given list size and sublist size.

    Args:
        list_size (int): Number of list elements.
        sublist_size (int): The size of the subsets to generate.
        connectivity_type (ConnectivityType): LINEAR, CIRCULAR, or FULL.

    Returns:
        list: all unique subsets of the given size.
    """
    if list_size <= 0:
        raise ClassiqValueError("list_size must be positive")
    if sublist_size <= 0 or sublist_size > list_size:
        raise ClassiqValueError("sublist_size must be in the range 1..list_size")

    if connectivity_type == ConnectivityType.LINEAR:
        return [
            list(range(i, i + sublist_size))
            for i in range(list_size - sublist_size + 1)
        ]

    elif connectivity_type == ConnectivityType.CIRCULAR:
        return [
            [(i + j) % list_size for j in range(sublist_size)] for i in range(list_size)
        ]

    else:  # ConnectivityType.FULL
        return [list(comb) for comb in combinations(range(list_size), sublist_size)]


def generate_hamiltonian(
    data: CArray[CReal],
    paulis_list: list[list[Pauli]],
    affines: list[list[float]],
    connectivity: ConnectivityType,
) -> tuple[list[SparsePauliOp], list[CReal]]:
    hs = []
    coeffs = []
    for paulis, affine in zip(paulis_list, affines):
        indices = generate_connectivity_map(data.len, len(paulis), connectivity)
        for k in range(len(indices)):
            indexed_paulis = [
                IndexedPauli(pauli=paulis[j], index=indices[k][j])  # type: ignore[arg-type]
                for j in range(len(indices[0]))
            ]
            hs.append(
                SparsePauliOp(
                    terms=[SparsePauliTerm(paulis=indexed_paulis, coefficient=1)],  # type: ignore[arg-type]
                    num_qubits=data.len,
                )
            )
            coe = np.prod(
                [
                    affine[0] * (data[indices[k][j]] - affine[1])
                    for j in range(len(indices[0]))
                ]
            )
            coeffs.append(coe)

    return hs, coeffs


@qfunc
def pauli_feature_map(
    data: CArray[CReal],
    paulis_list: list[list[Pauli]],
    affines: list[list[float]],
    connectivity: ConnectivityType,
    reps: CInt,
    qba: QArray,
) -> None:
    hs, coeffs = generate_hamiltonian(data, paulis_list, affines, connectivity)
    power(
        reps,
        lambda: (
            hadamard_transform(qba),
            multi_suzuki_trotter(
                hamiltonians=hs,
                evolution_coefficients=coeffs,
                order=1,
                repetitions=1,
                qbv=qba,
            ),
        ),
    )


# Amplitude encoding feature map
# TODO: add amplitude encoding feature map

# Efficient SU2
# TODO: add efficient SU2 feature map

# ZZ feature map
# TODO: add ZZ feature map
