import numpy as np
from sklearn.svm import SVC  # type: ignore[import-untyped]

from classiq.interface.exceptions import ClassiqValueError
from classiq.interface.executor.execution_preferences import ExecutionPreferences
from classiq.interface.executor.result import ExecutionDetails
from classiq.interface.generator.quantum_program import QuantumProgram

from classiq import synthesize
from classiq.execution import ExecutionSession
from classiq.qmod import QCallable
from classiq.qmod.builtins.operations import allocate, invert
from classiq.qmod.cparam import CReal
from classiq.qmod.qfunc import qfunc
from classiq.qmod.qmod_parameter import CArray
from classiq.qmod.qmod_variable import Output, QNum


class QuantumKernelEvaluator:
    """
    Constructs the kernel matrix for the QSVM algorithm.
    """

    def __init__(
        self,
        feature_map: QCallable[CArray, QNum],
        num_qubits: int,
        execution_preferences: ExecutionPreferences | None = None,
    ) -> None:
        self.feature_map = feature_map
        self.num_qubits: int = num_qubits
        self.execution_preferences: ExecutionPreferences | None = execution_preferences
        self.qprog: QuantumProgram | None = None
        self.data_dimension: int = 0

    def _get_execution_params(
        self,
        data1: np.ndarray,
        data2: np.ndarray,
        symmetric: bool = False,
    ) -> tuple[list[dict], tuple[int, int]]:
        """
        Generate execution parameters.

        Notes:
        - symmetric mode corresponds to the training phase where the function
          generates a list of dictionaries of the form {data1: np.array, data2: np.array},
          where both data1 and data2 are data points are from the training set. The list contains
          all unique unordered pairs of training data points, including the diagonal pairs (x, x),
          with each distinct pair appearing exactly once.
        - otherwise, the function generates a list of dictionaries where dictionary key data1,
          is taken from the training set and dictionary key data2 is taken from the  set.

        Args:
            data1 (np.ndarray): First dataset (used for both training and validation).
            data2 (np.ndarray | None): Second dataset (only required for validation).
            symmetric (bool, optional): If True, symmetric mode is applied.

        Returns:
            list[dict]: A list of dictionaries containing the execution parameters.
        """
        n = data1.shape[0]
        if symmetric:
            self.data_dimension = data1.shape[1]
            shape = (n, n)
            data1 = data1.tolist()
            # Training mode (symmetric pairs of data1)
            return (
                [
                    {"data1": data1[k], "data2": data1[j]}
                    for k in range(n)
                    for j in range(k, n)  # Avoid symmetric pairs
                ],
                shape,
            )
        else:
            if self.data_dimension == 0 and data2.shape[1] == data1.shape[1]:
                self.data_dimension = data1.shape[1]
            elif self.data_dimension == 0:
                raise ClassiqValueError(
                    f"data1 and data2 should have the same number of features, got {data1.shape[1]} and {data2.shape[1]} respectively."
                )
            elif self.data_dimension != 0 and (
                data2.shape[1] != self.data_dimension
                or data1.shape[1] != self.data_dimension
            ):
                raise ClassiqValueError(
                    f"data1 and data2 should have the same number of features, expected {self.data_dimension}."
                )
            m = data2.shape[0]
            shape = (n, m)
            data1 = data1.tolist()
            data2 = data2.tolist()
            # Prediction mode
            return (
                [
                    {"data1": data1[k], "data2": data2[j]}
                    for k in range(len(data1))
                    for j in range(len(data2))
                ],
                shape,
            )

    def _build_qprog(self, data_dim: int) -> QuantumProgram:
        # build the quantum program implementing the feature map and its inverse
        num_qubits: int = self.num_qubits
        feature_map = self.feature_map

        @qfunc
        def main(
            data1: CArray[CReal, data_dim],  # type: ignore[valid-type]
            data2: CArray[CReal, data_dim],  # type: ignore[valid-type]
            qba: Output[QNum[num_qubits]],  # type: ignore[valid-type]
        ) -> None:
            allocate(qba)
            feature_map(data1, qba)
            invert(lambda: feature_map(data2, qba))

        return synthesize(main)

    def _construct_kernel_matrix(
        self,
        shape: tuple[int, int],
        res_batch: list[ExecutionDetails],
        symmetric: bool = False,
    ) -> np.ndarray:
        """
        Construct a kernel matrix from `res_batch`, depending on whether it's for training or predicting.

        Args:
            shape (tuple[int,int]): Tuple of (number of rows, number of columns) for the matrix.
            res_batch (list): Precomputed batch results.
            symmetric (bool):  If True, assumes training (symmetric matrix).

        Returns:
            np.array: the kernel matrix
        """
        rows, cols = shape
        kernel_matrix = np.zeros((rows, cols), dtype=float)

        # test the dimensions of res_batch
        if not res_batch:
            raise ClassiqValueError(
                "empty results batch; cannot construct kernel matrix."
            )
        expected = rows * cols if not symmetric else rows * (rows + 1) // 2
        if len(res_batch) != expected:
            raise ClassiqValueError(
                f"Expected {expected} results, got {len(res_batch)}."
            )

        num_shots = res_batch[
            0
        ].num_shots  # number of shots is the same across the batch
        if num_shots is None:
            raise ClassiqValueError(
                "results have no num_shots; cannot normalize counts to kernel matrix."
            )
        counts0 = res_batch[0].counts
        if not counts0:
            raise ClassiqValueError(
                "empty counts in results; cannot infer output bitstrings length."
            )

        num_output_qubits = len(next(iter(counts0)))

        idx = 0
        if symmetric:  # and rows == cols (training)
            # Symmetric matrix (training)
            for k in range(rows):
                for j in range(k, cols):
                    value = (
                        res_batch[idx].counts.get("0" * num_output_qubits, 0)
                        / num_shots
                    )
                    kernel_matrix[k, j] = value
                    kernel_matrix[j, k] = value  # Use symmetry
                    idx += 1
        else:
            # Non-symmetric matrix (predict or test)
            for k in range(rows):
                for j in range(cols):
                    kernel_matrix[k, j] = (
                        res_batch[idx].counts.get("0" * num_output_qubits, 0)
                        / num_shots
                    )
                    idx += 1

        return kernel_matrix

    def kernel(
        self,
        data1: np.ndarray,
        data2: np.ndarray | None = None,
    ) -> np.ndarray:
        symmetric = data2 is None
        data2 = data1 if data2 is None else data2

        execution_params, shape = self._get_execution_params(data1, data2, symmetric)
        self.qprog = self._build_qprog(self.data_dimension)

        with ExecutionSession(
            quantum_program=self.qprog, execution_preferences=self.execution_preferences
        ) as es:
            res_batch = es.sample(execution_params)  # execute batch
        # generate kernel matrix for train
        return self._construct_kernel_matrix(
            shape=shape,
            res_batch=res_batch,
            symmetric=symmetric,
        )


class QSVM:
    """
    Quantum support vector machine (QSVM) model.
    Classifies classical data into two categories.
    The model is first trained, and fitted. After pre-training,
    the model predicts the labels of new data points.
    """

    def __init__(
        self,
        feature_map: QCallable[CArray, QNum],
        num_qubits: int,
        execution_preferences: ExecutionPreferences | None = None,
    ) -> None:
        """
        Args:
            feature_map (QCallable): Feature map to be used for the kernel
            num_qubits (int): Number of qubits used to encode each data point
            execution_preferences (ExecutionPreferences | None): Execution preferences for the kernel
        """
        self.feature_map = feature_map
        self.num_qubits = num_qubits
        self.execution_preferences = execution_preferences
        self.kernel_eval = QuantumKernelEvaluator(
            feature_map=self.feature_map,
            num_qubits=self.num_qubits,
            execution_preferences=self.execution_preferences,
        )
        self.model = SVC(kernel="precomputed")  # the svm model
        self.train_data: np.ndarray | None = None

    def train(
        self,
        train_data: np.ndarray,
        train_labels: np.ndarray,
    ) -> None:
        """
        Trains an SVM model using a custom precomputed kernel from the training data.

        Args:
            train_data (np.ndarray): Contains the data points (np.ndarray)
            train_labels (np.ndarray): Contains the labels (0,1).

        """
        # organize the data and labels for execution and test
        self.train_data = np.asarray(train_data)
        train_labels = np.asarray(train_labels)
        self._test_input_data(self.train_data, train_labels)

        # build training kernel and fit the model
        kernel = self.kernel_eval.kernel(
            self.train_data
        )  # the training kernel is used to fit the model
        self.model.fit(
            kernel, train_labels
        )  # optimization to find the hyperplane best classifying the data

    def predict(
        self,
        data: np.ndarray,
    ) -> np.ndarray:
        """
        Predicts labels for new data using a precomputed kernel with a trained SVM model. Evaluates kernel
        matrix elements which are associated with the support vectors (those associated with non-vanishing
        coefficients in the prediction equation).

        Args:
            data (list[np.ndarray]): List of new data points to predict.

        Returns:
            np.ndarray: Predicted labels (0,1).
        """
        if not hasattr(self.model, "support_"):
            raise RuntimeError("train the QSVM model first (SVC not fitted).")

        # pre-processing and test
        data = np.asarray(data, dtype=float)
        self._test_data_dim(data)

        # extracting the non-zero coefficients, associated indices and interception point
        alpha_y = self.model.dual_coef_[0]
        sv_idx = self.model.support_
        b = self.model.intercept_[0]
        train_data_truncated = np.asarray(self.train_data)[
            sv_idx, :
        ]  # minimal required training data

        # build a minimal size kernel
        kernel = self.kernel_eval.kernel(
            data, train_data_truncated
        )  # prediction kernel

        # prediction
        scores = kernel @ alpha_y + b
        return np.where(scores >= 0, self.model.classes_[1], self.model.classes_[0])

    def test(
        self,
        data: np.ndarray,
        data_labels: np.ndarray,
    ) -> tuple[float, np.ndarray]:
        """
        Predicts the labels of the test dataset and evaluates the resulting test score using the ground-truth labels.

        Args:
            data (list[np.ndarray]): List of test data points to predict.
            data_labels (np.ndarray): Contains the test data labels.

        Returns:
            tuple: containing test score (float) and test labels (np.ndarray[int]).
        """
        if not hasattr(self.model, "support_"):
            raise RuntimeError("train the QSVM model first (SVC not fitted).")
        self._test_input_data(data, data_labels)
        self._test_data_dim(data)
        predicted_labels = self.predict(data)
        return np.mean(predicted_labels == data_labels), predicted_labels

    def get_svm_model(
        self,
    ) -> SVC:
        """
        Returns the classical SVM model.
        """
        return self.model

    def get_qprog(self, data_dim: int = 0) -> QuantumProgram | None:
        """
        Returns the quantum program.
        """
        if self.kernel_eval.qprog is None:
            if data_dim != 0:
                return self.kernel_eval._build_qprog(data_dim)
            else:
                raise ClassiqValueError(
                    "QuantumProgram has not yet been created, data dimension (data_dim) should be provided to build the quantum program."
                )
        return self.kernel_eval.qprog

    def _test_input_data(
        self,
        data: np.ndarray,
        data_labels: np.ndarray,
    ) -> None:
        if not isinstance(data, np.ndarray):
            raise ClassiqValueError("data should be a numpy array.")
        if not isinstance(data_labels, np.ndarray):
            raise ClassiqValueError("data labels should be a numpy array of integers.")
        if len(data) != len(data_labels):
            raise ClassiqValueError("data and labels should be the same length.")
        if len(data_labels.shape) != 1:
            raise ClassiqValueError("data labels should be a 1D array.")

        # test if the labels are binary
        if not bool(np.isin(data_labels, (0, 1)).all()):
            raise ClassiqValueError("labels should be binary")

    def _test_data_dim(self, data: np.ndarray) -> None:
        if data.ndim != 2 or data.shape[0] == 0:
            raise ClassiqValueError(
                "data must be a non-empty 2D array (n_samples, n_features)."
            )
        d = data.shape[1]
        if d != self.kernel_eval.data_dimension:
            raise ClassiqValueError(
                f"data points have dimension {d}, expected {self.kernel_eval.data_dimension}."
            )
