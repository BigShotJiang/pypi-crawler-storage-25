import importlib.util
from collections.abc import Callable

import numpy as np
from numpy.polynomial import Chebyshev, Polynomial
from numpy.polynomial.chebyshev import cheb2poly, poly2cheb

from classiq.interface.enum_utils import StrEnum
from classiq.interface.exceptions import ClassiqValueError


def _require_qsp() -> None:
    missing = [m for m in ("cvxpy", "nlft_qsp") if importlib.util.find_spec(m) is None]
    if missing:
        raise RuntimeError(
            "This feature needs the 'qsp' extra."
            "Install with: pip install classiq[qsp]"
            f"(missing: {', '.join(missing)})"
        )


def _nlft_get_qsvt_phases(poly_coeffs: np.ndarray) -> np.ndarray:
    """
    Use the nlft-qsp package to get the QSVT phase angles.
    The input polynomial is assumed to be in Chebyshev basis.
    Returns phases for processing operators exp(i*phi*Z) in the QSVT/reflection
    convention (Corollary 8 of arXiv:1806.01838).
    """
    from nlft_qsp import chebqsp_solve

    cheb_pf = chebqsp_solve(list(poly_coeffs))
    d = cheb_pf.degree()

    phi = np.zeros(d + 1)
    phi[0] = cheb_pf.phi[0] + (2 * d - 1) * np.pi / 4
    for k in range(1, d):
        phi[k] = cheb_pf.phi[k] - np.pi / 2
    phi[d] = cheb_pf.phi[d] - np.pi / 4

    ## multiply by 2 as RZ(theta) = exp(-i*theta/2)
    phi = -2 * np.array(phi)[::-1]

    return phi


def qsvt_phases(poly_coeffs: np.ndarray, cheb_basis: bool = True) -> np.ndarray:
    r"""
    Get QSVT phases that will generate the given Chebyshev polynomial.
    The phases are ready to be used in `qsvt` and `qsvt_lcu` functions in the classiq library. The convention
    is the reflection signal operator, and the measurement basis is the hadamard basis (see https://arxiv.org/abs/2105.02859
    APPENDIX A.).
    The current implementation is using the nlft-qsp package.

    Notes:
        1. The polynomial should have a definite parity, and bounded in magnitude by 1 in the interval [-1, 1].
        2. The phase finding works in the Chebyshev basis. If the a monomial basis polynomial is provided,
           it will be converted to the chebyshev basis (and introduce an additional overhead).
        3. The user is advised to get the polynomial using the `qsp_approximate` function.
        4. If the function fails, try to scale down the polynomial by a factor, it should ease the angle finding.

    Args:
        poly_coeffs: Array of polynomial coefficients (Chebyshev\Monomial, depending on cheb_basis).
        cheb_basis: Whether the poly coefficients are given in Chebyshev (True) or Monomial(False). Defaults to Chebyshev.
    Returns:
        phases: array of the qsvt phases corresponding to the given polynomial.
    """
    _require_qsp()

    assert poly_coeffs is not None
    assert len(poly_coeffs) > 1, "polynomial should have degree >= 1"

    # verify parity
    is_even = np.sum(np.abs(poly_coeffs[0::2])) > 1e-8
    is_odd = np.sum(np.abs(poly_coeffs[1::2])) > 1e-8
    assert is_even or is_odd, "Polynomial should have a definite parity"

    poly_coeffs = np.array(np.trim_zeros(poly_coeffs, "b"))

    if not cheb_basis:
        poly_coeffs = poly2cheb(poly_coeffs)

    # heuristic bound verification
    grid = np.linspace(-1, 1, 1000)
    max_abs = np.max(np.abs(Chebyshev(poly_coeffs)(grid)))
    assert max_abs <= 1, "polynomial should be bounded in magnitude by 1"

    return _nlft_get_qsvt_phases(poly_coeffs)


def _plot_qsp_approx(
    poly_cheb: np.ndarray,
    f_target: Callable[[float], complex],
    interval: tuple[float, float] = (-1, 1),
) -> None:
    from matplotlib import pyplot as plt

    grid_full = np.linspace(-1, 1, 3000)
    grid_interval = np.linspace(interval[0], interval[1], 3000)

    y_target = np.vectorize(f_target, otypes=[float])(grid_interval)
    y_approx = np.polynomial.Chebyshev(poly_cheb)(grid_full)

    # Plot
    plt.figure(figsize=(10, 5))
    plt.plot(grid_interval, y_target, label="Target function", linewidth=4)
    plt.plot(
        grid_full,
        y_approx,
        "--",
        label="Polynomial approximation",
        linewidth=2,
        c="r",
    )
    plt.title("Polynomial Approximation vs Target Function")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    # Draw vertical lines
    plt.axvline(interval[0], color="gray", linestyle=":", linewidth=3)
    plt.axvline(interval[1], color="gray", linestyle=":", linewidth=3)

    plt.legend()
    plt.grid(True)
    plt.show()


def qsp_approximate(
    f_target: Callable[[float], complex],
    degree: int,
    parity: int | None = None,
    interval: tuple[float, float] = (-1, 1),
    bound: float = 0.99,
    num_grid_points: int | None = None,
    plot: bool = False,
) -> tuple[np.ndarray, float]:
    """
    Approximate the target function on the given (sub-)interval of [-1,1], using QSP-compatible chebyshev polynomials.
    The approximating polynomial is enforced to |P(x)| <= bound on all of [-1,1].

    Note: scaling f_target by a factor < 1 might help the convergence and also a later qsp phase factor finiding.

    Args:
        f_target: Real function to approximate within the given interval. Should be bounded by [-1, 1] in the given interval.
        degree: Approximating polynomial degree.
        parity: None - full polynomial, 0 - restrict to even polynomial, 1 - odd polynomial.
        interval: sub interval of [-1, 1] to approximate the function within.
        bound: global polynomial bound on [-1,1] (defaults to 0.99).
        num_grid_points: sets the number of grid points used for the polynomial approximation (defaults to `max(2 * degree, 1000)`).
        plot: A flag for plotting the resulting approximation vs the target function.

    Returns:
        coeffs: Array of Chebyshev coefficients. In case of definite parity, still a full coefficients array is returned.
        max_error: (Approximated) maximum error between the target function and the approximating polynomial within the interval.
    """
    _require_qsp()
    import cvxpy as cp  # type: ignore[import-not-found, import-untyped, unused-ignore]

    if num_grid_points is None:
        num_grid_points = max(2 * degree, 1000)
    # Discretize [-1, 1] using the grid points (interpolants)
    xj_full = np.cos(
        np.pi * np.arange(num_grid_points) / (num_grid_points - 1)
    )  # Chebyshev nodes on [-1, 1]

    # Select grid points for the objective in [w_min, w_max]
    xj_obj = xj_full[(xj_full >= interval[0]) & (xj_full <= interval[1])]

    yj_obj = np.vectorize(f_target, otypes=[float])(xj_obj)

    # heuristic verification
    bound = min(1, bound)
    assert (
        np.max(np.abs(yj_obj)) <= bound
    ), f"f_target function values should be bounded in magnitude by bound={bound} within the interval:{interval}"

    # Define the Chebyshev polynomials
    con_mat = np.polynomial.chebyshev.chebvander(xj_full, degree)
    obj_mat = np.polynomial.chebyshev.chebvander(xj_obj, degree)

    # Choose which Chebyshev indices to use
    if parity is None:
        cols = np.arange(degree + 1)  # full
    elif parity == 0:
        cols = np.arange(0, degree + 1, 2)  # even T_0, T_2, ...
    elif parity == 1:
        cols = np.arange(1, degree + 1, 2)  # odd  T_1, T_3, ...
    else:
        raise ValueError("parity must be None, 0 (even), or 1 (odd)")

    con_mat = con_mat[:, cols]
    obj_mat = obj_mat[:, cols]

    # Define optimization variables
    c = cp.Variable(len(cols))  # Coefficients for Chebyshev polynomials
    f_values_full = con_mat @ c
    f_values_obj = obj_mat @ c

    # Define the optimization problem
    objective = cp.Minimize(cp.max(cp.abs(f_values_obj - yj_obj)))
    constraints = [cp.abs(f_values_full) <= bound]  # global bound
    prob = cp.Problem(objective, constraints)

    # Solve the optimization problem
    prob.solve()

    # Return coefficients, optimal value, and grid points
    pcoeffs = np.zeros(degree + 1)
    pcoeffs[cols] = c.value

    if plot:
        _plot_qsp_approx(pcoeffs, f_target, interval)

    return pcoeffs, prob.value


def _nlft_get_gqsp_phases(
    poly_coeffs: np.ndarray,
) -> list[tuple[float, float, float]]:
    """
    Use the nlft-qsp package to get the gqsp phase angles. The input polynomial is
    assumed to be in monomial basis.
    """
    from nlft_qsp import Polynomial, gqsp_solve

    poly = Polynomial(list(poly_coeffs))
    phases = gqsp_solve(poly).to_mw_gqsp()
    thetas = np.array(phases[0])[::-1]
    phis = np.array(phases[1])[::-1]
    lambdas = np.zeros(len(phases[0]))
    lambdas[0] = phases[2]

    return list(zip(thetas, phis, lambdas))


def gqsp_phases(
    poly_coeffs: np.ndarray, cheb_basis: bool = False
) -> list[tuple[float, float, float]]:
    """
    Compute GQSP phases for a polynomial in the monomial (power) basis.

    The returned phases are compatible with Classiq's `gqsp` function and use the Wz signal
    operator convention.

    The current implementation is using the nlft-qsp package, based on techniques in https://arxiv.org/abs/2503.03026.

    Notes:
    - The polynomial must be bounded on the unit circle:
      |P(e^{i*theta})| <= 1 for all theta in [0, 2*pi).
    - Laurent polynomials are supported by degree shifting. If
      P(z) = sum_{k=m}^n c_k * z^k with m < 0, the phases correspond to the
      degree-shifted polynomial z^{-m} * P(z) (so the minimal degree is zero).
    - The phase finiding works in the monomial basis. If a Chebyshev basis polynomial is provided,
      it will be converted to the monomial basis (and introduce an additional overhead).

    Args:
      poly: array-like of complex, shape (d+1). Monomial coefficients in ascending
            order: [c_0, c_1, ..., c_d].
      cheb_basis: Whether the poly coefficients are given in Chebyshev (True) or Monomial(False). Defaults to Monomial.

    Returns:
      phases: list of (theta, phi, lambda) tuples of length d+1, ready to use with `gqsp`.

    Raises:
      ValueError: if |P(e^{i*theta})| > 1 anywhere on the unit circle.
    """
    _require_qsp()

    # remove redundant zeros at the end
    poly_coeffs = np.array(np.trim_zeros(poly_coeffs, "b"))

    # move to monomial basis if needed
    if cheb_basis:
        poly_coeffs = cheb2poly(poly_coeffs)

    # verify the normalization
    grid = np.exp(1j * np.linspace(0.0, 2.0 * np.pi, 2000))
    p_z = Polynomial(poly_coeffs)(grid)
    assert (
        np.max(np.abs(p_z)) < 1 + 1e-10
    ), "P violates |P(e^{i*theta})| <= 1; cannot create calculate gqsp phases."

    return _nlft_get_gqsp_phases(poly_coeffs)


def poly_jacobi_anger_cos(degree: int, t: float) -> np.ndarray:
    r"""
    Gets the Chebyshev polynomial coefficients approximating cos(t*x) using the Jacobi-Anger expansion.
    $$\cos(xt) = J_0(t) + 2\sum_{k=1}^{d/2} (-1)^k J_{2k}(t)\, T_{2k}(x) $$

    Args:
        degree: the degree of the approximating polynomial.
        t: the parameter in cos(t*x). Can be negative.
    Returns:
        coeffs: The Chebyshev approximating coefficients.
    """
    from scipy.special import jv

    coeffs = np.zeros(degree + 1 if degree % 2 == 0 else degree)
    for k in range(degree // 2 + 1):
        coeffs[2 * k] = (2 if k > 0 else 1) * (-1) ** k * jv(2 * k, t)

    return coeffs


def poly_jacobi_anger_sin(degree: int, t: float) -> np.ndarray:
    r"""
    Gets the Chebyshev polynomial coefficients approximating sin(t*x) using the Jacobi-Anger expansion.
    $$\sin(xt) = 2\sum_{k=0}^{d/2} (-1)^k J_{2k+1}(t)\, T_{2k+1}(x)$$

    Args:
        degree: the degree of the approximating polynomial.
        t: the parameter in sin(t*x).
    Returns:
        coeffs: The Chebyshev approximating coefficients.
    """
    from scipy.special import jv

    coeffs = np.zeros(degree + 1 if degree % 2 == 1 else degree)
    for k in range(len(coeffs) // 2):
        idx = 2 * k + 1
        coeffs[idx] = 2 * (-1) ** k * jv(idx, t)
    return coeffs


def poly_jacobi_anger_exp_sin(degree: int, t: float) -> np.ndarray:
    r"""
    Gets the Chebyshev polynomial coefficients approximating exp(i*t*sin(x)) using the Jacobi-Anger expansion:
    $$e^{it\sin(x)} = \sum_{k=-d}^{d} J_{k}(t) e^{ikx}$$

    Args:
        degree: the maximum degree of the approximating polynomial (negative and positive).
        t: the parameter in exp(i*t*sin(x)).
    Returns:
        coeffs: The approximating coefficients in monomial basis, starting from the negative ones to the positive ones (length is 2*degree+1).
    """
    from scipy.special import jv

    coeffs = [jv(k, t) for k in range(-degree, degree + 1)]
    return np.array(coeffs)


def poly_jacobi_anger_exp_cos(degree: int, t: float) -> np.ndarray:
    r"""
    Gets the Chebyshev polynomial coefficients approximating exp(i*t*cos(x)) using the Jacobi-Anger expansion:
    $$e^{it\cos(x)} = \sum_{k=-d}^{d} i^k J_{k}(t) e^{ikx}$$

    Args:
        degree: the maximum degree of the approximating polynomial (negative and positive).
        t: the parameter in exp(i*t*cos(x)).
    Returns:
        coeffs: The approximating coefficients in monomial basis, starting from the negative ones to the positive ones (length is 2*degree+1).
    """
    from scipy.special import jv

    coeffs = [jv(k, t) * (1j**k) for k in range(-degree, degree + 1)]
    return np.array(coeffs)


def poly_jacobi_anger_degree(eps: float, t: float) -> int:
    r"""
    Get needed degree based on the maximum allowed uniform error on the interval [-1, 1]
    for the Jacobi-Anger approximation. relevant for all poly_*_jacobi_anger functions.
    Args:
        eps: maximum allowed uniform error
        t: the parameter in exp(i*t*cos(x))\exp(i*t*sin(x))\cos(t*x)\sin(t*x)
    Returns:
        degree: the minimal degree such that the polynomial approximation
                using Jacobi-Anger expansion is within eps uniform error
    """
    # based on https://arxiv.org/pdf/1806.01838
    from scipy.special import jv

    t = abs(float(t))
    m: int = 1000  # window size

    # start near the peak
    n: int = max(1, int(t))

    # compute initial window sum S(n)
    idx = np.arange(n, n + m, dtype=int)
    s: float = float(np.sum(np.abs(jv(idx, t))))

    # move forward using window updates
    while s > eps:
        s -= abs(jv(n, t))
        s += abs(jv(n + m, t))
        n += 1
    return n


def poly_jacobi_anger_error(degree: int, t: float) -> float:
    r"""
    Get the uniform error on the interval [-1, 1] for the Jacobi-Anger approximation,
    based on the truncation degree. Relevant for all poly_*_jacobi_anger functions.
    Args:
        degree: truncation maximal degree
        t: the parameter in exp(i*t*cos(x))\exp(i*t*sin(x))\cos(t*x)\sin(t*x)
    Returns:
        eps: a bound on the approximation uniform error
    """
    # based on https://arxiv.org/pdf/1806.01838
    from scipy.special import jv

    t = abs(float(t))
    m: int = 1000  # window size

    idx = np.arange(degree + 1, degree + 1 + m, dtype=int)
    return float(2.0 * np.sum(np.abs(jv(idx, t))))


def _get_max_value_cheb(coeffs: np.ndarray, degree: int) -> float:
    """
    Calculate maximum value on [-1, 1] of Chebyshev polynomial according to Eq. (25) in  https://arxiv.org/pdf/2507.15537.
    """
    sampling_ratio = 25
    grid = np.linspace(0, 1, degree * 25)
    max_sampled = np.max(np.abs(np.polynomial.chebyshev.Chebyshev(coeffs)(grid)))
    return max_sampled * 1 / (np.cos(np.pi / (4 * sampling_ratio)))


class ErrorType(StrEnum):
    RELATIVE = "relative"
    UNIFORM = "uniform"


def _poly_inversion_relative_error(degree: int, kappa: float) -> np.ndarray:
    """
    Gets the Chebyshev odd polynomial p(x) coefficients approximating 1/x on [1/kappa, 1], optimal for
    minimizing the relative error |xp(x)-1| for x in [1/kappa, 1]. Based on the paper https://dl.acm.org/doi/pdf/10.1145/3649320
    """

    def _evaluate_q_t(x: np.ndarray, kappa: float, t: int) -> np.ndarray:
        """
        q_t(x, kappa) = (1-T_t(s_{+}(x))/T_t(s_{+}(0)))/x, (eq. 6)
        with s_{+}(x) = (1 + kappa ** (-2) - 2 * x) / (1 - kappa ** (-2)) and T_t is
        the Chebyshev polynomial of order t.
        """
        from scipy.special import eval_chebyt

        assert t >= 1, "t must be >= 1"
        assert 0.0 < 1 / kappa < 1.0, "1/kappa must be in (0, 1)"

        def s_plus(x: np.ndarray, kappa: float) -> np.ndarray:
            return (1 + kappa ** (-2) - 2 * x) / (1 - kappa ** (-2))

        x = np.asarray(x, dtype=float)

        sp_x = s_plus(x**2, kappa)
        sp_0 = s_plus(0.0, kappa)  # type: ignore[arg-type]

        cheb_t_spx = eval_chebyt(t, sp_x)
        cheb_t_sp0 = eval_chebyt(t, sp_0)

        return (1.0 - (cheb_t_spx / cheb_t_sp0)) / x

    t = (degree + 1) // 2
    coeffs = np.polynomial.chebyshev.chebinterpolate(
        _evaluate_q_t, degree, args=(kappa, t)
    )

    return coeffs


def _poly_inversion_uniform_error(degree: int, kappa: float) -> np.ndarray:
    """
    Gets the Chebyshev odd polynomial p(x) coefficients approximating 1/x on [1/kappa, 1], optimal for minimizing
    the uniform error |p(x)-1/x| for x in [1/kappa, 1]. Based on the paper https://arxiv.org/pdf/2507.15537.
    """

    def _evaluate_l_n(x: np.ndarray, n: int, a: float) -> np.ndarray:
        """
        L_n(x; a) = 2^{-(n-1)} [ T_n(x) + ((1-a)/(1+a)) T_{n-1}(x)]. (eq. 6)
        """
        x = np.asarray(x, dtype=float)
        assert n >= 1, "n must be >= 1"
        assert 0.0 < a < 1.0, "1/kappa must be in (0, 1)"

        alpha = (1 + a) / (2 * (1 - a))
        l1 = (x + (1 - a) / (1 + a)) / alpha
        l2 = (x**2 + (1 - a) / (1 + a) * x / 2 - 1 / 2) / alpha**2
        if n == 1:
            return l1
        for _ in range(3, n + 1):
            l1, l2 = l2, x * l2 / alpha - l1 / (4 * alpha**2)
        return l2

    def _substitute_x(x: np.ndarray, a: float) -> np.ndarray:
        """
        helper function for the variable substitution in eq. (5).
        """
        return (2.0 * x * x - (1.0 + a * a)) / (1.0 - a * a)

    def _evaluate_p(x: np.ndarray, d: int, a: float) -> np.ndarray:
        """
        Evaluate P_{2n-1}(x; a) with d odd, n=(d+1)//2.
        Uses Eq. (5) with L_n from Eq. (6).
        """
        n = (d + 1) // 2
        x = np.asarray(x, dtype=float)

        # main branch
        l_n = _evaluate_l_n(_substitute_x(x, a), n, a)
        l_0 = _evaluate_l_n(_substitute_x(0.0, a), n, a)  # type: ignore[arg-type]
        return (1.0 - (l_n / l_0)) / x

    a = 1 / kappa

    coeffs = np.polynomial.chebyshev.chebinterpolate(
        _evaluate_p, degree, args=(degree, a)
    )

    return coeffs


def poly_inversion(
    degree: int, kappa: float, error_type: str | ErrorType = ErrorType.RELATIVE
) -> tuple[np.ndarray, float]:
    """
    Gets the Chebyshev odd polynomial p(x) coefficients approximating 1/x on [1/kappa, 1].
    Based on the papers: https://dl.acm.org/doi/pdf/10.1145/3649320 -  for optimal polynomial that minimizes the relative error |xp(x)-1| for
    x in [1/kappa,1]; and https://arxiv.org/pdf/2507.15537- for optimal polynomial that minimizes the uniform error |p(x)-1/x| for x in [1/kappa,1].
    The relative error refers to |xp(x)-1|, whereas the uniform error refers to |p(x)-1/x|, both for x in [1/kappa,1].

    Note: To be used within the QSVT framework, the polynomial should be scaled to be bounded by 1 on [-1, 1].
          The maximum absolute value of the returned polynomial on [-1, 1] can be larger than kappa, so the user
          should use the returned max_value to scale down the polynomial accordingly.

    Args:
        degree: The degree of the approximating polynomial.
        kappa: The number defining the interval [1/kappa, 1], usually represents the condition number in the setting of matrix inversion.
        error_type: A string specifying the error type to minimize, can be either "relative" (default) or "uniform".


    Returns:
        coeffs: The Chebyshev polynomial coefficients approximating 1/x on [1/kappa, 1]
                using the optimal polynomial of given degree.
        max_value: An upper bound on the maximum absolute value of the polynomial on [-1, 1]. The value
                   can be used to scale down the polynomial for the usage within QSVT.
    """

    assert degree % 2 == 1, "degree must be odd"

    if error_type == ErrorType.RELATIVE:
        coeffs = _poly_inversion_relative_error(degree, kappa)
    elif error_type == ErrorType.UNIFORM:
        coeffs = _poly_inversion_uniform_error(degree, kappa)
    else:
        raise ClassiqValueError(
            f"Invalid error_type={error_type!r}. Must be one of {tuple(e.value for e in ErrorType)}."
        ) from None
    # enforce odd parity numerically:
    coeffs[0::2] = 0.0
    max_value = _get_max_value_cheb(coeffs, degree)
    return coeffs, max_value


def poly_inversion_degree(
    eps: float, kappa: float, error_type: str | ErrorType = ErrorType.RELATIVE
) -> int:
    """
    Get the needed degree based on the target relative or uniform error on the interval [1/kappa, 1],
    for the polynomial approximation of 1/x using the function poly_inversion.
    Based on the papers https://dl.acm.org/doi/pdf/10.1145/3649320 and https://arxiv.org/pdf/2507.15537.

    Args:
        eps: The target relative or uniform approximation error (depending on the error_type parameter).
        kappa: The number defining the interval [1/kappa, 1], usually represents the condition number in the setting of matrix inversion.
        error_type: A string specifying the error type, can be either "relative" (default) or "uniform".
    Returns:
        degree: The minimal degree such that the polynomial approximation of 1/x on [1/kappa, 1]
                is within eps uniform error.
    """

    if error_type == ErrorType.RELATIVE:
        t = int(np.ceil(0.5 * kappa * np.log(2 * kappa**2 / eps)))
        return 2 * t - 1
    elif error_type == ErrorType.UNIFORM:
        a = 1 / kappa
        n = int(
            np.ceil(
                (np.log(1 / eps) + np.log(1 / a) + np.log(1 + a))
                / np.log((1 + a) / (1 - a))
            )
        )
        return 2 * n - 1
    else:
        raise ClassiqValueError(
            f"Invalid error_type={error_type!r}. Must be one of {tuple(e.value for e in ErrorType)}."
        ) from None


def poly_inversion_error(
    degree: int, kappa: float, error_type: str | ErrorType = ErrorType.RELATIVE
) -> float:
    """
    Calculates relative or uniform error on the interval [1/kappa, 1] for the odd polynomial
    approximation of 1/x given by poly_inversion.
    Based on the papers https://dl.acm.org/doi/pdf/10.1145/3649320 and https://arxiv.org/pdf/2507.15537.
    The relative error refers to |xp(x)-1|, whereas the uniform error refers to |p(x)-1/x|, both for x in [1/kappa,1].

    Args:
        degree: Inversion polynomial degree.
        kappa: The number defining the interval [1/kappa, 1], usually represents the condition number in the setting of matrix inversion.

    Returns:
        eps: Relative or Uniform approximation error on [1/kappa, 1], according to the parameter error_type.
    """
    assert 0.0 < 1 / kappa < 1.0, "1/kappa must be in (0, 1)"

    if error_type == ErrorType.RELATIVE:
        # The minimal error is 1/T_t(s_{+}(0)), then we can use Eq. (4) to find a simpler expression
        t = (degree + 1) // 2
        y = (kappa + 1) / (kappa - 1)
        return 2 / (y**t + y ** (-t))
    elif error_type == ErrorType.UNIFORM:
        a = 1 / kappa
        n = (degree + 1) // 2
        return (1 - a) ** n / (a * (1 + a) ** (n - 1))
    else:
        raise ClassiqValueError(
            f"Invalid error_type={error_type!r}. Must be one of {tuple(e.value for e in ErrorType)}."
        ) from None
