import ast

import sympy
from sympy import Add, Max, simplify, sympify as sympy_sympify
from sympy.core.basic import Basic

from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.generator.types.enum_declaration import EnumDeclaration
from classiq.interface.generator.types.struct_declaration import StructDeclaration

from classiq.evaluators.model_evaluation.evaluation_pass import evaluate_expression
from classiq.evaluators.qmod_annotated_expression import QmodAnnotatedExpression
from classiq.evaluators.qmod_expression_visitors.qmod_expression_simplifier import (
    simplify_qmod_expression,
)
from classiq.evaluators.qmod_node_evaluators.utils import QmodType
from classiq.model_expansions.visitors.variable_references import VarRefTransformer


def expr_int(n: int) -> Expression:
    return Expression(expr=str(n))


def _distribute_add_into_max(expr: Basic) -> Basic:
    """Rewrite ``Max(a, b) + c`` as ``Max(a + c, b + c)``.

    This is valid because Max is monotone.  SymPy doesn't do this
    automatically, but it lets nested Max calls flatten:
    ``Max(Max(a,b)+1, Max(c,d)+1)`` -> ``Max(a+1, b+1, c+1, d+1)``.
    """
    if not expr.args:
        return expr
    args = tuple(_distribute_add_into_max(a) for a in expr.args)
    rebuilt = expr.func(*args)
    if isinstance(rebuilt, Add):
        max_terms = [a for a in rebuilt.args if isinstance(a, Max)]
        if len(max_terms) == 1:
            rest = Add(*[a for a in rebuilt.args if not isinstance(a, Max)])
            distributed = Max(*[a + rest for a in max_terms[0].args])
            return _distribute_add_into_max(distributed)
    return rebuilt


def _strip_max_zero_identity(expr: Basic) -> Basic:
    """Depths are nonnegative: ``Max(0, x, ...)`` simplifies to ``Max(x, ...)``."""
    if not expr.args:
        return expr
    args = tuple(_strip_max_zero_identity(a) for a in expr.args)
    rebuilt = expr.func(*args)
    if isinstance(rebuilt, Max):
        non_zero = [a for a in rebuilt.args if a != 0]
        if not non_zero:
            return sympy.Integer(0)
        if len(non_zero) < len(rebuilt.args):
            return non_zero[0] if len(non_zero) == 1 else Max(*non_zero)
    return rebuilt


def _sympy_simplify_depth_str(expr_str: str) -> str:
    """Run SymPy simplification and strip ``max(0, x)`` identities from a depth string."""
    s = sympy_sympify(expr_str, locals={"max": Max})
    simplified = _distribute_add_into_max(simplify(s))
    stripped = _strip_max_zero_identity(simplified)
    return str(stripped)


def simplify_depth_expression(
    expr: Expression,
    *,
    machine_precision: int,
    classical_struct_declarations: list[StructDeclaration],
    enum_declarations: list[EnumDeclaration],
    scope: dict[str, QmodType],
) -> Expression:
    """Algebraically simplify a depth expression via the qmod evaluator and SymPy.

    Designed to run **once per cell** at the end of a depth/gate-count pass --
    not in a hot loop.
    """
    expr = evaluate_expression(
        expr,
        machine_precision=machine_precision,
        classical_struct_declarations=classical_struct_declarations,
        enum_declarations=enum_declarations,
        scope=scope,
    )
    if isinstance(expr.value.value, QmodAnnotatedExpression):
        qmod_simplified = simplify_qmod_expression(expr.value.value)
        return Expression(expr=_sympy_simplify_depth_str(qmod_simplified))
    return Expression(expr=str(expr.value.value))


def apply_param_substitution_to_expression(
    expr: Expression, ast_map: dict[str, ast.expr]
) -> Expression:
    """Replace parameter names in *expr* with their argument expressions.

    Returns a fresh, unevaluated ``Expression`` -- callers that need a
    simplified or evaluated form must run ``simplify_depth_expression`` or
    ``evaluate_expression`` themselves.
    """
    tree = ast.parse(expr.expr, mode="eval")
    new_tree = VarRefTransformer(ast_map).visit(tree)
    return Expression(expr=ast.unparse(new_tree))
