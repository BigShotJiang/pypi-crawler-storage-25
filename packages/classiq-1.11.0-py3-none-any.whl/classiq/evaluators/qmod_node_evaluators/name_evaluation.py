import ast
from typing import Any

import sympy

from classiq.interface.exceptions import (
    ClassiqInternalExpansionError,
)
from classiq.interface.generator.expressions.nodes.name import Name
from classiq.interface.generator.expressions.proxies.classical.qmod_struct_instance import (
    QmodStructInstance,
)
from classiq.interface.generator.functions.classical_type import (
    ClassicalType,
    Real,
)
from classiq.interface.model.quantum_type import QuantumType

from classiq.evaluators.qmod_annotated_expression import QmodAnnotatedExpression
from classiq.evaluators.qmod_type_inference.classical_type_inference import (
    infer_classical_type,
)


def eval_name(expr_val: QmodAnnotatedExpression, node: ast.Name, value: Any) -> None:
    if isinstance(
        value, (bool, int, float, complex, list, QmodStructInstance, sympy.Basic)
    ):
        expr_val.set_type(node, infer_classical_type(value))
        expr_val.set_value(node, value)
    elif isinstance(value, (ClassicalType, QuantumType)):
        expr_val.set_type(node, value)
        expr_val.set_var(node, Name(name=node.id))
    else:
        raise ClassiqInternalExpansionError


def eval_power_subscript(expr_val: QmodAnnotatedExpression, node: ast.Name) -> None:
    expr_val.set_type(node, Real())
