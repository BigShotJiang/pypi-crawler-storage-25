import ast
from typing import TYPE_CHECKING

import sympy

from classiq.interface.exceptions import ClassiqExpansionError

from classiq.evaluators.qmod_annotated_expression import QmodAnnotatedExpression
from classiq.evaluators.qmod_node_evaluators.utils import (
    SYMPY_SYMBOLS,
    is_classical_integer,
)

if TYPE_CHECKING:
    from classiq.evaluators.qmod_expression_visitors.qmod_expression_evaluator import (
        QmodExpressionEvaluator,
    )


SUM_ITER_VAR_KEYWORDS = frozenset({"start", "end", "expression"})


def is_sum_with_iter_var_call(node: ast.Call) -> bool:
    """True iff *node* is ``sum(<Name>, start=..., end=..., expression=...)``.

    Requires the keywords to be exactly the three expected names, each
    present once -- the ``len == 3`` check rules out duplicate keywords
    (e.g. two ``expression=`` entries) which a set comparison alone
    would silently accept by collapsing them.
    """
    return (
        isinstance(node.func, ast.Name)
        and node.func.id == "sum"
        and len(node.args) == 1
        and isinstance(node.args[0], ast.Name)
        and len(node.keywords) == 3
        and all(kw.arg is not None for kw in node.keywords)
        and {kw.arg for kw in node.keywords} == SUM_ITER_VAR_KEYWORDS
    )


def _node_to_sympy(
    expr_val: QmodAnnotatedExpression,
    node: ast.AST,
    locals_: dict[str, sympy.Basic],
) -> sympy.Basic:
    """Best-effort sympy conversion: use the evaluated value if present, else
    parse the inlined string form (free Names become sympy ``Symbol``s)."""
    if expr_val.has_value(node):
        return sympy.sympify(expr_val.get_value(node), locals=locals_)
    return sympy.sympify(
        expr_val.print_by_node(node), locals={**SYMPY_SYMBOLS, **locals_}
    )


def eval_sum_with_iter_var(
    evaluator: "QmodExpressionEvaluator",
    node: ast.Call,
) -> None:
    """Evaluate ``sum(i, start=S, end=E, expression=expr_with_i)``.

    Range is half-open ``[S, E)`` (Python ``range``-style). The result is
    emitted as ``sympy.Sum(expr_with_i, (i, S, E - 1))`` and ``.doit()`` is
    applied to simplify the result if possible.
    """
    if not is_sum_with_iter_var_call(node):
        raise ClassiqExpansionError(
            "sum(i, start=..., end=..., expression=...) requires the iter "
            "variable as the only positional argument and exactly the keyword "
            "arguments 'start', 'end', 'expression'"
        )

    iter_var_node = node.args[0]
    assert isinstance(iter_var_node, ast.Name)
    iter_var_name = iter_var_node.id

    kwargs_by_name = {kw.arg: kw.value for kw in node.keywords}
    start_node = kwargs_by_name["start"]
    end_node = kwargs_by_name["end"]
    expression_node = kwargs_by_name["expression"]

    expr_val: QmodAnnotatedExpression = evaluator._expr_val
    evaluator.visit(start_node)
    evaluator.visit(end_node)

    if not is_classical_integer(expr_val.get_type(start_node)):
        raise ClassiqExpansionError("'start' of sum(...) must be an integer expression")
    if not is_classical_integer(expr_val.get_type(end_node)):
        raise ClassiqExpansionError("'end' of sum(...) must be an integer expression")

    iter_symbol = sympy.Symbol(iter_var_name, integer=True)
    sub_evaluator = evaluator.with_extended_scope({iter_var_name: iter_symbol})
    sub_evaluator.visit(expression_node)

    expr_val.set_type(node, expr_val.get_type(expression_node))

    locals_ = {iter_var_name: iter_symbol}
    start_sym = _node_to_sympy(expr_val, start_node, locals_)
    end_sym = _node_to_sympy(expr_val, end_node, locals_)
    body_sym = _node_to_sympy(expr_val, expression_node, locals_)

    # Python ``range``-style ``[S, E)`` is empty when ``E <= S``. SymPy's
    # ``Sum`` instead applies reversed-limit summation (e.g.
    # ``Sum(i, (i, 5, 1)).doit() == -9``), so when both bounds are
    # concrete numbers we short-circuit to 0 to keep the API contract.
    if start_sym.is_number and end_sym.is_number and bool(end_sym <= start_sym):
        sum_value: sympy.Basic = sympy.Integer(0)
    else:
        # Otherwise evaluate via ``Sum(...).doit()``: concrete-bound
        # non-empty ranges collapse to a number, polynomial symbolic
        # bounds collapse to a closed-form expression (e.g.
        # ``Sum(i, (i, 0, reps - 1)).doit() == reps**2/2 - reps/2``),
        # and non-polynomial bodies stay as an unevaluated ``sympy.Sum``
        # that Expression accepts via the ``Sum`` + ``Tuple`` entries in
        # its supported set.
        sum_value = sympy.Sum(body_sym, (iter_symbol, start_sym, end_sym - 1)).doit()
    expr_val.set_value(node, sum_value)
