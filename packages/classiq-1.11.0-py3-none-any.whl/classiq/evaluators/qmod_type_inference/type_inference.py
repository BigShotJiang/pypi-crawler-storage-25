from classiq.interface.generator.expressions.expression_types import ExpressionValue

from classiq.evaluators.qmod_annotated_expression import QmodAnnotatedExpression
from classiq.evaluators.qmod_node_evaluators.utils import QmodType
from classiq.evaluators.qmod_type_inference.classical_type_inference import (
    infer_classical_type,
)


def infer_type(value: ExpressionValue) -> QmodType:
    if isinstance(value, QmodAnnotatedExpression):
        return value.get_type(value.root)
    else:
        return infer_classical_type(value)
