from sympy import Basic, collect_const

from classiq.evaluators.qmod_expression_visitors.sympy_simplifiers.sympy_simplifier import (
    SympySimplifier,
)


class CollectConstSimplifier(SympySimplifier):
    @staticmethod
    def condition(expr: Basic) -> bool:
        return not expr.is_number and not expr.is_symbol

    @staticmethod
    def conversion(expr: Basic) -> Basic:
        expr = collect_const(expr, -1)
        expr = collect_const(expr)
        return expr
