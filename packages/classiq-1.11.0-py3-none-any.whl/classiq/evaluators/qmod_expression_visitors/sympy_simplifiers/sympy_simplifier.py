import abc

from sympy import Basic


class SympySimplifier(abc.ABC):
    @staticmethod
    @abc.abstractmethod
    def condition(expr: Basic) -> bool:
        pass

    @staticmethod
    @abc.abstractmethod
    def conversion(expr: Basic) -> Basic:
        pass
