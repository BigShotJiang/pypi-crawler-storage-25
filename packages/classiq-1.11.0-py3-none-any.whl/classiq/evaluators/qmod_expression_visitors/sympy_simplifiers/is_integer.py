from sympy import Basic, Integer

from classiq.evaluators.qmod_expression_visitors.sympy_simplifiers.sympy_simplifier import (
    SympySimplifier,
)


class IsIntegerSimplifier(SympySimplifier):
    @staticmethod
    def condition(expr: Basic) -> bool:
        return expr.is_Float and float(expr) == int(expr)

    @staticmethod
    def conversion(expr: Basic) -> Basic:
        return Integer(expr)
