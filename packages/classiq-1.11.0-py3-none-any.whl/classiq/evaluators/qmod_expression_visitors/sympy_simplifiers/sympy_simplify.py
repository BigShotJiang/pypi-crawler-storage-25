from collections.abc import Callable
from typing import Any

import sympy

from classiq.evaluators.qmod_expression_visitors.sympy_simplifiers.collect_const import (
    CollectConstSimplifier,
)
from classiq.evaluators.qmod_expression_visitors.sympy_simplifiers.is_integer import (
    IsIntegerSimplifier,
)
from classiq.evaluators.qmod_expression_visitors.sympy_simplifiers.sympy_simplifier import (
    SympySimplifier,
)

simplifiers: list[type[SympySimplifier]] = [IsIntegerSimplifier, CollectConstSimplifier]


def simplify_expr(expr: sympy.Basic) -> str:
    for simplifier in simplifiers:
        expr = _recursive_convert(expr, simplifier.condition, simplifier.conversion)

    return str(expr)


def _recursive_convert(
    expr: sympy.Basic,
    condition: Callable[[sympy.Basic], bool],
    conversion: Callable[[sympy.Basic], sympy.Basic],
) -> sympy.Basic:
    def update_expr(expr: Any) -> Any:
        if isinstance(expr, sympy.Basic):
            if hasattr(expr, "args") and expr.args:
                new_args = [update_expr(arg) for arg in expr.args]
                expr_class = type(expr)
                expr = expr_class(*new_args)

            if condition(expr):
                expr = conversion(expr)

        return expr

    return update_expr(expr)
