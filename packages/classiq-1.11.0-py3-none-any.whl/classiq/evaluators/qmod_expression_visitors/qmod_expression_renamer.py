from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.generator.expressions.nodes.name import Name
from classiq.interface.generator.expressions.utilities.path_expression import (
    get_path_expression_name,
    replace_prefix,
)

from classiq.evaluators.qmod_annotated_expression import (
    QmodAnnotatedExpression,
    QmodExprNodeId,
)


def replace_expression_vars(
    expr_val: QmodAnnotatedExpression,
    renaming: dict[Expr, Expr],
) -> QmodAnnotatedExpression:
    expr_val = expr_val.clone()
    if len(renaming) == 0:
        expr_val.lock()
        return expr_val
    all_vars = dict(expr_val.get_classical_vars()) | dict(expr_val.get_quantum_vars())
    renaming_with_names = [
        (source, get_path_expression_name(source), target)
        for source, target in renaming.items()
    ]
    for node_id, var in all_vars.items():
        var_name = get_path_expression_name(var)
        for source, source_name, target in renaming_with_names:
            if var_name == source_name:
                renamed_var = replace_prefix(var, source, target)
                if renamed_var is not var:
                    break
        else:
            continue
        node_type = expr_val.get_type(node_id)
        expr_val.clear_node_data(node_id)
        expr_val.set_type(node_id, node_type)
        expr_val.set_var(node_id, renamed_var)
    expr_val.lock()
    return expr_val


def replace_expression_type_attrs(
    expr_val: QmodAnnotatedExpression,
    renaming: dict[tuple[Expr, str], Expr],
) -> QmodAnnotatedExpression:
    expr_val = expr_val.clone()
    if len(renaming) == 0:
        expr_val.lock()
        return expr_val
    type_attrs = dict(expr_val.get_quantum_type_attributes())
    renaming_with_names = [
        (
            source,
            get_path_expression_name(source),
            attr,
            target,
        )
        for (source, attr), target in renaming.items()
    ]
    for node_id, ta in type_attrs.items():
        var = ta.value
        var_name = get_path_expression_name(var)
        renamed_attr = ta.attr
        for source, source_name, attr, target in renaming_with_names:
            if renamed_attr == attr and var_name == source_name:
                renamed_var = replace_prefix(var, source, target)
                if renamed_var is not var:
                    break
        else:
            continue
        node_type = expr_val.get_type(node_id)
        expr_val.clear_node_data(node_id)
        expr_val.set_type(node_id, node_type)
        expr_val.set_var(node_id, renamed_var)
    expr_val.lock()
    return expr_val


def replace_expression_nodes(
    expr_val: QmodAnnotatedExpression,
    renaming: dict[QmodExprNodeId, str],
) -> str:
    expr_val = expr_val.clone()
    for node_id, renamed_var in renaming.items():
        expr_val.set_var(node_id, Name(name=f"{renamed_var}"))
    return str(expr_val)
