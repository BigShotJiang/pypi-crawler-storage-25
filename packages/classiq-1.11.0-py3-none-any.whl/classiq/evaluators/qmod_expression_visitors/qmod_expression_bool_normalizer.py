import ast
from typing import Any

from classiq.interface.exceptions import ClassiqInternalExpansionError

from classiq.evaluators.qmod_expression_visitors.out_of_place_node_transformer import (
    OutOfPlaceNodeTransformer,
)


class QmodExpressionBoolNormalizer(OutOfPlaceNodeTransformer):
    def visit_BoolOp(self, node: ast.BoolOp) -> Any:
        if isinstance(node.op, ast.Or):
            # apply De-Morgan's law, because 'And' has a smart implementation in control
            return self.visit(
                self._negate(
                    ast.BoolOp(
                        op=ast.And(),
                        values=[self._negate(val) for val in node.values],
                    )
                )
            )

        return self.generic_visit(node)

    def visit_Compare(self, node: ast.Compare) -> Any:
        if len(node.ops) != 1:
            raise ClassiqInternalExpansionError

        op = node.ops[0]
        left = node.left
        right = node.comparators[0]

        if isinstance(op, ast.NotEq):
            # we favor 'Eq' over 'NotEq' because it has a smart implementation in
            # control
            return self.visit(
                self._negate(
                    ast.Compare(left=left, ops=[ast.Eq()], comparators=[right])
                )
            )

        return self.generic_visit(node)

    def visit_UnaryOp(self, node: ast.UnaryOp) -> Any:
        operand = self.visit(node.operand)
        op = node.op

        if (
            isinstance(op, ast.Not)
            and isinstance(operand, ast.UnaryOp)
            and isinstance(operand.op, ast.Not)
        ):
            return operand.operand

        return ast.UnaryOp(op=op, operand=operand)

    @staticmethod
    def _negate(node: ast.expr) -> ast.expr:
        return ast.UnaryOp(
            op=ast.Not(),
            operand=node,
        )
