from classiq.interface.exceptions import ClassiqInternalError
from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.generator.expressions.nodes.member_access import MemberAccess
from classiq.interface.generator.expressions.nodes.slice import Slice
from classiq.interface.generator.expressions.nodes.subscript import Subscript
from classiq.interface.generator.functions.type_name import TypeName
from classiq.interface.model.quantum_type import QuantumBitvector, QuantumType


def translate_handle(
    root_var_type: QuantumType, handle: Expr, calculate_offsets: bool = True
) -> tuple[QuantumType, int, int]:
    if isinstance(handle, Subscript):
        nested_type, start, _ = translate_handle(
            root_var_type, handle.value, calculate_offsets
        )
        if not isinstance(nested_type, QuantumBitvector):
            raise ClassiqInternalError("Slicing but type is not array.")
        if not calculate_offsets:
            return nested_type.element_type, 0, 0
        element_size = nested_type.element_type.size_in_bits
        index = handle.index.to_int_value()
        return (
            nested_type.element_type,
            start + index * element_size,
            start + (index + 1) * element_size,
        )

    if isinstance(handle, Slice):
        nested_type, start, _ = translate_handle(
            root_var_type, handle.value, calculate_offsets
        )
        if not isinstance(nested_type, QuantumBitvector):
            raise ClassiqInternalError("Slicing but type is not array.")
        next_start = handle.start.to_int_value()
        next_stop = handle.stop.to_int_value()
        sliced_type = nested_type.model_copy(
            update={"length": Expression(expr=str(next_stop - next_start))}
        )
        if not calculate_offsets:
            return sliced_type, 0, 0
        element_size = nested_type.element_type.size_in_bits
        return (
            sliced_type,
            start + next_start * element_size,
            start + next_stop * element_size,
        )

    if isinstance(handle, MemberAccess):
        nested_type, start, _ = translate_handle(
            root_var_type, handle.value, calculate_offsets
        )
        if not isinstance(nested_type, TypeName):
            raise ClassiqInternalError("Accessing field but type is not struct.")
        for field_name, field_type in nested_type.fields.items():
            if field_name != handle.member:
                if calculate_offsets:
                    start += field_type.size_in_bits
                continue
            end = start + field_type.size_in_bits if calculate_offsets else 0
            return field_type, start, end
        raise ClassiqInternalError(
            f"Struct {nested_type.name} does not have field {handle.member!r}."
        )

    return root_var_type, 0, root_var_type.size_in_bits if calculate_offsets else 0
