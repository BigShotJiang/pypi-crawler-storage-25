from classiq.interface.exceptions import ClassiqExpansionError
from classiq.interface.generator.expressions.expression_types import ExpressionValue
from classiq.interface.generator.functions.classical_type import Integer, Real
from classiq.interface.model.phase_operation import PhaseOperation

from classiq.evaluators.qmod_annotated_expression import QmodAnnotatedExpression
from classiq.evaluators.qmod_node_evaluators.utils import is_classical_type
from classiq.evaluators.qmod_type_inference.type_inference import infer_type
from classiq.model_expansions.quantum_operations.emitter import Emitter


def _validate_classical_angle_type(angle: ExpressionValue, expected_name: str) -> None:
    angle_type = infer_type(angle)
    if not isinstance(angle_type, (Integer, Real)):
        raise ClassiqExpansionError(
            f"Expected {expected_name}, got {str(angle)!r} of type "
            f"{angle_type.raw_qmod_type_name}"
        )


class PhaseVerifier(Emitter[PhaseOperation]):
    def emit(self, phase_op: PhaseOperation, /) -> bool:
        expr_val = phase_op.expression.value.value
        if not isinstance(expr_val, QmodAnnotatedExpression) or is_classical_type(
            expr_val.get_type(expr_val.root)
        ):
            self._validate_classical_phase(phase_op)
        return False

    @staticmethod
    def _validate_classical_phase(phase_op: PhaseOperation) -> None:
        if phase_op.theta.expr != "1.0":
            raise ClassiqExpansionError(
                "The phase operation theta argument must not be specified when the "
                "phase expression is classical"
            )
        phase_angle_val = phase_op.expression.value.value
        _validate_classical_angle_type(
            phase_angle_val, "classical or quantum real angle"
        )
