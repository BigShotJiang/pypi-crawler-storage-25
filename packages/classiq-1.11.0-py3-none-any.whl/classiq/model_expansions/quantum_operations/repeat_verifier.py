import sympy

from classiq.interface.exceptions import ClassiqExpansionError
from classiq.interface.model.repeat import Repeat

from classiq.model_expansions.quantum_operations.emitter import Emitter


class RepeatVerifier(Emitter[Repeat]):
    def emit(self, repeat: Repeat, /) -> bool:
        count = repeat.count.value.value
        if isinstance(count, (int, float, sympy.Basic)) and float(count) < 0:
            raise ClassiqExpansionError(
                f"repeat count must be non-negative, got {count}"
            )
        return False
