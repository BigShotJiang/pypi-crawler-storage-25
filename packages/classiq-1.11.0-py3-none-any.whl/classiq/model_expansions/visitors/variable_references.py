import ast
from collections.abc import Iterator, Mapping
from contextlib import contextmanager

from classiq.interface.exceptions import (
    ClassiqExpansionError,
    ClassiqInternalExpansionError,
)
from classiq.interface.generator.arith.arithmetic_expression_validator import (
    DEFAULT_SUPPORTED_FUNC_NAMES,
)
from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.generator.expressions.nodes.member_access import MemberAccess
from classiq.interface.generator.expressions.nodes.name import Name
from classiq.interface.generator.expressions.nodes.slice import Slice
from classiq.interface.generator.expressions.nodes.subscript import Subscript
from classiq.interface.generator.expressions.sympy_supported_expressions import (
    SYMPY_SUPPORTED_EXPRESSIONS,
)
from classiq.interface.generator.expressions.utilities.path_expression import (
    get_path_expression_name,
    to_python_str,
)


class VarRefCollector(ast.NodeVisitor):
    def __init__(
        self,
        ignore_duplicated_handles: bool = False,
        unevaluated: bool = False,
        ignore_sympy_symbols: bool = False,
    ) -> None:
        self._var_handles: dict[Expr, bool] = {}
        self._ignore_duplicated_handles = ignore_duplicated_handles
        self._ignore_sympy_symbols = ignore_sympy_symbols
        self._unevaluated = unevaluated
        self._is_nested = False
        self._in_subscript = False

    @property
    def var_handles(self) -> list[Expr]:
        return list(self._var_handles)

    @property
    def subscript_handles(self) -> list[Expr]:
        return [
            handle for handle, in_subscript in self._var_handles.items() if in_subscript
        ]

    def visit(self, node: ast.AST) -> Expr | None:
        res = super().visit(node)
        if not self._ignore_duplicated_handles and len(self._var_handles) != len(
            {get_path_expression_name(handle) for handle in self._var_handles}
        ):
            raise ClassiqExpansionError(
                "Multiple non-identical variable references in an expression are not supported."
            )
        return res

    def visit_Subscript(self, node: ast.Subscript) -> Expr | None:
        return self._get_subscript_handle(node.value, node.slice)

    def visit_Attribute(self, node: ast.Attribute) -> MemberAccess | None:
        return self._get_field_handle(node.value, node.attr)

    def visit_Call(self, node: ast.Call) -> Expr | None:
        if not isinstance(node.func, ast.Name):
            return self.generic_visit(node)
        if node.func.id == "get_field":
            if (
                len(node.args) != 2
                or not isinstance(node.args[1], ast.Constant)
                or not isinstance(node.args[1].value, str)
            ):
                raise ClassiqInternalExpansionError("Unexpected 'get_field' arguments")
            return self._get_field_handle(node.args[0], node.args[1].value)
        if node.func.id == "do_subscript":
            if len(node.args) != 2:
                raise ClassiqInternalExpansionError(
                    "Unexpected 'do_subscript' arguments"
                )
            return self._get_subscript_handle(node.args[0], node.args[1])
        return self.generic_visit(node)

    def _get_field_handle(self, subject: ast.expr, field: str) -> MemberAccess | None:
        with self.set_nested():
            base_handle = self.visit(subject)
        if base_handle is None:
            return None
        handle = MemberAccess(
            value=base_handle,
            member=field,
        )
        if not self._is_nested:
            self._add_handle(handle)
        return handle

    def _get_subscript_handle(
        self, subject: ast.expr, subscript: ast.expr
    ) -> Expr | None:
        with self.set_in_subscript():
            self.visit(subscript)
        with self.set_nested():
            base_handle = self.visit(subject)
        if base_handle is None:
            return None
        handle: Expr
        if isinstance(subscript, ast.Slice):
            if not self._unevaluated and (
                not isinstance(subscript.lower, ast.Num)
                or not isinstance(subscript.upper, ast.Num)
            ):
                raise ClassiqInternalExpansionError("Unevaluated slice bounds")
            if subscript.lower is None or subscript.upper is None:
                raise ClassiqInternalExpansionError(
                    f"{to_python_str(base_handle)!r} slice must specify both lower and upper bounds"
                )
            handle = Slice(
                value=base_handle,
                start=Expression(expr=ast.unparse(subscript.lower)),
                stop=Expression(expr=ast.unparse(subscript.upper)),
            )
        elif not self._unevaluated and not isinstance(subscript, ast.Num):
            raise ClassiqInternalExpansionError("Unevaluated subscript")
        else:
            handle = Subscript(
                value=base_handle,
                index=Expression(expr=ast.unparse(subscript)),
            )
        if not self._is_nested:
            self._add_handle(handle)
        return handle

    def visit_Name(self, node: ast.Name) -> Name | None:
        if not self._ignore_sympy_symbols and node.id in set(
            SYMPY_SUPPORTED_EXPRESSIONS
        ) | set(DEFAULT_SUPPORTED_FUNC_NAMES):
            return None
        handle = Name(name=node.id)
        if not self._is_nested:
            self._add_handle(handle)
        return handle

    @contextmanager
    def set_nested(self, val: bool = True) -> Iterator[None]:
        previous_is_nested = self._is_nested
        self._is_nested = val
        yield
        self._is_nested = previous_is_nested

    @contextmanager
    def set_in_subscript(self) -> Iterator[None]:
        previous_in_subscript = self._in_subscript
        self._in_subscript = True
        with self.set_nested(False):
            yield
        self._in_subscript = previous_in_subscript

    def _add_handle(self, handle: Expr) -> None:
        if handle not in self._var_handles:
            self._var_handles[handle] = self._in_subscript
            return
        if self._in_subscript and not self._var_handles[handle]:
            self._var_handles[handle] = True


class VarRefTransformer(ast.NodeTransformer):
    """Renames ``Name`` ids, or replaces a ``Name`` with a given expression AST."""

    def __init__(self, var_mapping: Mapping[str, str | ast.expr]) -> None:
        self.var_mapping = var_mapping

    def visit_Name(self, node: ast.Name) -> ast.AST:
        if node.id not in self.var_mapping:
            return node
        replacement = self.var_mapping[node.id]
        if isinstance(replacement, str):
            node.id = replacement
            return node
        return ast.fix_missing_locations(ast.copy_location(replacement, node))

    def visit_Call(self, node: ast.Call) -> ast.AST:
        # qmod struct literals are emitted as ``struct_literal(StructName, field=value, ...)``
        # (see ``classiq.evaluators.qmod_annotated_expression.qmod_val_to_str``).
        # The first positional arg is the struct *type* name -- it shares the
        # name namespace with parameters but must never be substituted, since
        # struct types are not values that callers pass as arguments.
        if (
            isinstance(node.func, ast.Name)
            and node.func.id == "struct_literal"
            and len(node.args) == 1
            and isinstance(node.args[0], ast.Name)
        ):
            new_keywords = [
                ast.keyword(arg=kw.arg, value=self.visit(kw.value))
                for kw in node.keywords
            ]
            return ast.copy_location(
                ast.Call(func=node.func, args=[node.args[0]], keywords=new_keywords),
                node,
            )
        return self.generic_visit(node)
