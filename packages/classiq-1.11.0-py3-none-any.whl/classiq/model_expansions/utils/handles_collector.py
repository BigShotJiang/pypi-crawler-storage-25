import ast

from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.generator.expressions.nodes.array import Array
from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.generator.visitor import NodeType, Visitor
from classiq.interface.model.control import Control
from classiq.interface.model.phase_operation import PhaseOperation
from classiq.interface.model.quantum_expressions.arithmetic_operation import (
    ArithmeticOperation,
)

from classiq.evaluators.qmod_annotated_expression import QmodAnnotatedExpression
from classiq.model_expansions.visitors.variable_references import VarRefCollector


class _HandlesCollector(Visitor):
    def __init__(self) -> None:
        self.handles: list[Expr] = []

    def visit_Expr(self, expr: Expr) -> None:
        if isinstance(expr, Array):
            self.visit(expr.elements)
        else:
            self.handles.append(expr)

    def visit_Expression(self, expression: Expression) -> None:
        if expression.is_evaluated():
            expr_val = expression.value.value
            if isinstance(expr_val, QmodAnnotatedExpression):
                self.handles.extend(expr_val.get_classical_vars().values())
                self.handles.extend(expr_val.get_quantum_vars().values())
            return
        vrc = VarRefCollector(ignore_duplicated_handles=True, unevaluated=True)
        vrc.visit(ast.parse(expression.expr))
        self.handles.extend(vrc.var_handles)

    def visit_ArithmeticOperation(self, op: ArithmeticOperation) -> None:
        self.handles.extend(op.var_handles)
        self.generic_visit(op)

    def visit_Control(self, control: Control) -> None:
        self.handles.extend(control.get_control_vars_list())
        self.generic_visit(control)

    def visit_PhaseOperation(self, phase: PhaseOperation) -> None:
        self.handles.extend(phase.inouts)


def extract_handles(node: NodeType) -> list[Expr]:
    collector = _HandlesCollector()
    collector.visit(node)
    return collector.handles
