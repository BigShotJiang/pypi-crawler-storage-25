from collections import Counter


class CountedNameAllocator:
    def __init__(self, global_prefix: str | None = None) -> None:
        self._count: Counter[str] = Counter()
        self._global_prefix = "" if global_prefix is None else f"{global_prefix}_"

    def allocate(self, prefix: str) -> str:
        allocated = f"{self._global_prefix}{prefix}_{self._count[prefix]}"
        self._count[prefix] += 1
        return allocated

    def clone(self) -> "CountedNameAllocator":
        new = CountedNameAllocator.__new__(CountedNameAllocator)
        new._count = Counter(self._count)
        new._global_prefix = self._global_prefix
        return new
