from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import TypeVar, cast

from classiq.interface.generator.expressions.atomic_expression_functions import (
    CLASSICAL_ATTRIBUTES,
)
from classiq.interface.generator.expressions.evaluated_expression import (
    EvaluatedExpression,
)
from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.generator.expressions.nodes.array import Array
from classiq.interface.generator.expressions.nodes.expr import Expr
from classiq.interface.generator.expressions.nodes.member_access import MemberAccess
from classiq.interface.generator.expressions.nodes.name import Name
from classiq.interface.generator.expressions.utilities.path_expression import (
    collapse,
    get_path_expression_source,
    replace_prefix,
    set_prefix,
)
from classiq.interface.generator.visitor import NodeType
from classiq.interface.model.model_visitor import ModelTransformer

from classiq.evaluators.qmod_annotated_expression import QmodAnnotatedExpression
from classiq.evaluators.qmod_expression_visitors.qmod_expression_renamer import (
    replace_expression_type_attrs,
    replace_expression_vars,
)

AST_NODE = TypeVar("AST_NODE", bound=NodeType)


@dataclass(frozen=True)
class HandleRenaming:
    source_handle: Expr
    target_var_name: str

    @property
    def target_var_handle(self) -> Name:
        return Name(name=self.target_var_name)


SymbolRenaming = Mapping[Expr, Sequence[HandleRenaming]]


def rewrite_expression(
    symbol_mapping: SymbolRenaming, expression: Expression
) -> Expression:
    if len(symbol_mapping) == 0:
        return expression
    expr_val = expression.value.value
    if not isinstance(expr_val, QmodAnnotatedExpression):
        return expression

    type_attr_mapping: dict[tuple[Expr, str], Expr] = {
        (source_handle.value, source_attr): renaming.target_var_handle
        for renamings in symbol_mapping.values()
        for renaming in renamings
        if isinstance(source_handle := renaming.source_handle, MemberAccess)
        and (source_attr := source_handle.member) in CLASSICAL_ATTRIBUTES
    }
    expr_val = replace_expression_type_attrs(expr_val, type_attr_mapping)

    var_mapping: dict[Expr, Expr] = {
        source_handle: renaming.target_var_handle
        for renamings in symbol_mapping.values()
        for renaming in renamings
        if not isinstance(source_handle := renaming.source_handle, MemberAccess)
        or source_handle.member not in CLASSICAL_ATTRIBUTES
    }
    expr_val = replace_expression_vars(expr_val, var_mapping)

    renamed_expr = Expression(expr=str(expr_val))
    renamed_expr._evaluated_expr = EvaluatedExpression(value=expr_val)
    return renamed_expr


class _ReplaceSplitVarsHandles(ModelTransformer):
    def __init__(self, symbol_mapping: SymbolRenaming) -> None:
        self._handle_replacements = {
            part.source_handle: part.target_var_handle
            for parts in symbol_mapping.values()
            for part in parts
        }

    def visit_Expr(self, expr: Expr) -> Expr:
        if isinstance(expr, Array):
            return cast(Array, self.generic_visit(expr))
        source = get_path_expression_source(expr)
        if isinstance(source, Array):
            return set_prefix(expr, self.visit(source))
        expr = collapse(expr)
        for prefix, replacement in self._handle_replacements.items():
            expr = replace_prefix(expr, prefix, replacement)
        return expr


class _ReplaceSplitVarsExpressions(ModelTransformer):
    def __init__(self, symbol_mapping: SymbolRenaming) -> None:
        self._symbol_mapping = symbol_mapping

    def visit_Expression(self, expr: Expression) -> Expression:
        return rewrite_expression(self._symbol_mapping, expr)


class ModelRenamer:
    def rewrite(self, subject: AST_NODE, symbol_mapping: SymbolRenaming) -> AST_NODE:
        if len(symbol_mapping) == 0:
            return subject
        subject = _ReplaceSplitVarsHandles(symbol_mapping).visit(subject)
        subject = _ReplaceSplitVarsExpressions(symbol_mapping).visit(subject)
        return subject
