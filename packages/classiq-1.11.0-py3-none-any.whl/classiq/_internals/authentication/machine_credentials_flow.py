from classiq._internals.authentication.auth0 import Tokens
from classiq._internals.authentication.authorization_flow import AuthorizationFlow


class M2MClientCredentialsFlow(AuthorizationFlow):
    """Machine-to-Machine (M2M) authentication using OAuth2 Client Credentials flow."""

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        organization: str | None = None,
    ) -> None:
        # M2M authentication doesn't use refresh tokens or interactive flows
        super().__init__(require_refresh_token=False, text_only=False)
        self.client_id = client_id
        self.client_secret = client_secret
        self.organization = organization

    async def get_tokens(self) -> Tokens:
        data = await self.auth0_client.client_credentials_login(
            client_id=self.client_id,
            client_secret=self.client_secret,
            organization=self.organization,
        )
        return self.handle_ready_data(data)
