"""Diagnostic information for Classiq support."""

import base64
import json
import logging
import sys

import httpx

from classiq.interface._version import VERSION

from classiq._internals.client import _get_python_execution_environment, client

_logger = logging.getLogger(__name__)

_UNAVAILABLE = "(unavailable)"
_NOT_AUTHENTICATED = "(not authenticated)"
_UNABLE_TO_RETRIEVE = "(unable to retrieve)"
_DIAGNOSTICS_TIMEOUT_SECONDS = 10


def _get_backend_version() -> str:
    try:
        _client = client()
        client_args = {
            **_client._make_client_args(),
            "timeout": _DIAGNOSTICS_TIMEOUT_SECONDS,
        }
        versioned_url = _client.make_versioned_url("/versions")
        with httpx.Client(**client_args) as http_client:
            response = http_client.get(versioned_url)
            response.raise_for_status()
            data = response.json()
        if isinstance(data, dict):
            return str(data.get("classiq_interface", _UNAVAILABLE))
        return _UNAVAILABLE
    except Exception as exc:
        _logger.debug("Failed to retrieve backend version", exc_info=exc)
        return _UNAVAILABLE


def _decode_jwt_sub(token: str) -> str:
    """Extract sub from a JWT payload without signature verification."""
    try:
        payload_b64 = token.split(".")[1]
        payload_b64 += "=" * (-len(payload_b64) % 4)
        data = json.loads(base64.urlsafe_b64decode(payload_b64))
        return str(data.get("sub", _UNABLE_TO_RETRIEVE))
    except Exception as exc:
        _logger.debug("Failed to decode JWT payload", exc_info=exc)
        return _UNABLE_TO_RETRIEVE


def _get_user_id(token: str | None) -> str:
    if token is None:
        return _NOT_AUTHENTICATED
    return _decode_jwt_sub(token)


def print_diagnostics() -> None:
    """Print diagnostic information about the Classiq SDK environment.

    Useful for pasting into support tickets.
    """
    try:
        backend_host = client().get_backend_uri()
    except Exception as exc:
        _logger.debug("Failed to retrieve backend host", exc_info=exc)
        backend_host = _UNAVAILABLE

    try:
        token: str | None = client()._token_manager.get_access_token()
    except Exception as exc:
        _logger.debug("Failed to retrieve access token", exc_info=exc)
        token = None

    authenticated = token is not None
    user_id = _get_user_id(token)
    backend_version = _get_backend_version()

    lines = [
        "Classiq SDK Diagnostics",
        "=" * 40,
        f"SDK version      : {VERSION}",
        f"Python version   : {sys.version}",
        f"Python env       : {_get_python_execution_environment()}",
        f"Backend host     : {backend_host}",
        f"Backend version  : {backend_version}",
        f"Authenticated    : {authenticated}",
        f"User ID          : {user_id}",
    ]
    print("\n".join(lines))  # noqa: T201
