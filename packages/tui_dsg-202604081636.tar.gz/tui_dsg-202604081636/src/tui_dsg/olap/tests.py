import pandas as pd
from checkmarkandcross import image


def aufgabe1(df: pd.DataFrame):
    return image(
        isinstance(df, pd.DataFrame)
        and 'show_id' in df
        and 'type' in df
        and 'title' in df
        and 'release' in df
        and 'runtime' in df
        and 'episode_count' in df
        and 'popularity' in df
        and 'avg_runtime' in df
        and df['show_id'][3] == 's536'
        and df['runtime'][1438] == 86.
    )


def aufgabe2(cube: pd.Series):
    return image(
        isinstance(cube, pd.Series)
        and cube.index[177] == ('2006-09', 'mittel', 208.0, 'TV Show')
        and cube.index[876] == ('2020-05', 'kurz', 10.0, 'TV Show')
        and 5.4 < cube['2017-03']['kurz'][12]['TV Show'] < 5.7
    )


def aufgabe3(cube: pd.Series):
    return image(
        isinstance(cube, pd.Series)
        and cube.index.names == ['type', 'release', 'episode_count', 'avg_runtime']
    )


def aufgabe4(cube: pd.Series):
    return image(
        isinstance(cube, pd.Series)
        and cube.index.names == ['release', 'episode_count', 'avg_runtime']
    )


def aufgabe5(cube: pd.Series):
    return image(
        isinstance(cube, pd.Series)
        and (
                cube.index.names == ['release', 'episode_count', 'avg_runtime']
                or cube.index.names == [None, 'episode_count', 'avg_runtime']
        )
        and 2.09 < (cube['1955' if '1955' in cube else 1995][26]['kurz']) < 2.1
    )
