SELECT ? AS profile
