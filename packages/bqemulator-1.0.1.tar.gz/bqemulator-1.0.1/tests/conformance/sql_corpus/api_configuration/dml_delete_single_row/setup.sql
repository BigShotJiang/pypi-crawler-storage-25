CREATE OR REPLACE TABLE `${DATASET}`.target (id INT64, label STRING);
INSERT INTO `${DATASET}`.target (id, label) VALUES (1, 'keep'), (2, 'delete-me');
