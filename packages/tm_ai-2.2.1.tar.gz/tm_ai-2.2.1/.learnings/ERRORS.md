# CVC Errors

[ERR-20260404-001] [Medium] [Telegram Parsing]
Summary: Discovered that using `ParseMode.HTML` during live token streaming causes `aiogram.exceptions.TelegramBadRequest` due to unclosed tags mid-stream.
Resolution: Only apply `ParseMode.HTML` on the initial `message.reply` and action buttons, but pass `parse_mode=None` during chunked `edit_message_text` flushes so raw Markdown tags are safely treated as plaintext until streaming finishes.

[ERR-20260404-002] [Critical] [Dependencies]
Summary: `aiogram.utils.token.TokenValidationError: Token is invalid!` during `start_telegram_gateway()`. Because `python-dotenv` was not installed, the `.env` file was silently skipped, leaving `TELEGRAM_BOT_TOKEN` empty.
Resolution: Added `python-dotenv>=1.0.0` to `dependencies` in `pyproject.toml` so the `.env` file properly loads at runtime. Bumped version to `2.0.55` and published.