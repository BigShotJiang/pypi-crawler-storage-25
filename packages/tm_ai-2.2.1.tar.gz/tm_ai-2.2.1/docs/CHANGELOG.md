# Changelog

All notable changes to Cognitive Version Control (CVC) will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.8.3] - 2026-03-06

### 🚀 Specialized Agents + Slash Command Overhaul

### Added
- **5 new specialized sub-agents** — Security (vulnerability scanning, OWASP Top 10, CVE auditing), AI (AI/ML engineering, LLM integration, RAG pipelines), UI (UI/UX design, frontend engineering, accessibility), Data (analytics, SQL, ETL, visualization), Orchestrator (meta-agent that delegates to other agents and synthesizes results)
- **Tool tier system** — `CODING_TOOLS`, `RESEARCH_TOOLS`, `ORCHESTRATION_TOOLS` frozensets in subagent.py for appropriate capability scoping per agent

### Changed
- **`/trust` toggle** — Running `/trust` with no argument now toggles session trust-all ON/OFF (previously only showed status). Supports `/trust strict|smart|yolo` for mode switching and `/trust status` for current state
- **`/plan` toggle** — Running `/plan` while already in plan mode now switches back to agent mode (previously required `/plan off`)
- **`/think` toggle** — Running `/think` with no argument now toggles between off and medium (previously had no toggle behavior)
- **`/fast` models updated** — Uses current provider models instead of deprecated ones: google → gemini-3-flash-preview, anthropic → claude-haiku-4-5, openai → gpt-5-mini
- **`/help` table** — Updated descriptions for /plan, /think, /fast, /trust, /agents, and /plan-mode to reflect new behavior

---

## [1.8.2] - 2026-03-06

### 🐛 FIX: Emoji Spacing in CLI Output

### Fixed
- **Missing space between emoji and text** — Emoji characters (⚠, 📎, 📁, 📊, 🔧, ⚡, 🔍, etc.) are 2-column wide in most terminals. With only one space after them the text appeared to immediately follow with no gap. All emoji+text patterns across `renderer.py` and `chat.py` now use two spaces, ensuring consistent visual separation regardless of terminal emoji width rendering.

---

## [1.8.1] - 2026-03-06

### 🐛 FIX: Arrow-Key Menus Crash in Async Context

### Fixed
- **RuntimeError: asyncio.run() cannot be called from a running event loop** — `arrow_select()` used prompt_toolkit’s `app.run()` which internally calls `asyncio.run()`. When called from the agent’s async REPL (e.g., session resume prompt, permission panel), this crashed because there was already a running event loop. Now detects async context and runs the prompt_toolkit app in a dedicated worker thread where it can safely create its own event loop.

---

## [1.8.0] - 2026-03-06

### 🎯 ARROW-KEY INTERACTIVE MENUS + PROJECT SCAFFOLDING WIZARD

Massive interaction overhaul: every typed letter/number selection prompt across the entire CLI
has been replaced with smooth arrow-key navigation menus. Plus a new intelligent project
scaffolding wizard that detects empty workspaces and guides users through project creation.
Zero new dependencies — built entirely on prompt_toolkit (already bundled).

### Added
- **🔽 Arrow-Key Selection Component** (`cvc/agent/menus.py`) — Reusable interactive menu system:
  - `arrow_select()` — Full menu with Up/Down/j/k navigation, Enter to select, Esc to cancel, 1-9 quick jump
  - `arrow_confirm()` — Binary Yes/No built on the same UI
  - `▸` cursor indicator with CVC theme colors, optional descriptions per option
  - Works in all terminals — no new dependencies required
- **🏗️ Project Scaffolding Wizard** — Intelligent new-project detection and guided setup:
  - Auto-detects empty workspaces (only boilerplate files like .git, README, LICENSE present)
  - **Step 1**: Project type selection (Web App, API/Backend, CLI Tool, Library, AI Agent, Mobile, Desktop, Other)
  - **Step 2**: Tech stack picker — dynamic options per project type (e.g., Mobile → React Native / Flutter / Kotlin / Swift)
  - **Step 3**: Confirmation summary + scaffold
  - Generates a structured prompt that the LLM executes using existing tools — no hardcoded templates
  - System prompt updated with scaffolding best practices

### Changed
- **Permission Panel** — Replaced `y/a/t/n/r` letter input with 5-option arrow-key menu
- **Plan Approval** — Replaced Enter/n text input with `arrow_confirm()` Yes/No selector
- **Session Resume** — Replaced Y/n text input with `arrow_confirm()` Yes/No selector
- **Agent Question Handler** — When LLM presents options, now renders arrow-key menu instead of numbered list
- **Model Switcher** (`/model`) — Replaced table + number input with arrow-key menu showing current model marker
- **Provider Switcher** (`/provider`) — Replaced numbered list + input with arrow-key menu
- **CVC Init Prompt** — Replaced text Y/n with `arrow_confirm()`
- **Executor Fallback** — Option selection in tool execution uses arrow-key menu
- **Setup Wizard** — All 5 action choices now use arrow-key selection with descriptions
- **Provider Selection** (setup Step 1) — Arrow-key menu replaces numbered list
- **Model Selection** (setup Step 2) — Arrow-key menu replaces text prompt
- **Change Model Shortcut** — Arrow-key menu with current model marked
- **Proxy Confirmation** — `arrow_confirm()` replaces `click.confirm()`
- **Connect Guide Picker** — Arrow-key menu replaces numbered tool list
- **Launch Tool Picker** — Arrow-key menu with installed/not-installed status markers

### Technical
- **New file**: `cvc/agent/menus.py` — ~170 lines, arrow_select + arrow_confirm using prompt_toolkit Application + KeyBindings + FormattedTextControl
- **Files modified**: `renderer.py` (3 functions), `chat.py` (5 functions + scaffolding wizard), `executor.py` (1 function), `cli.py` (6 sections), `auto_context.py` (empty workspace detection), `system_prompt.py` (scaffold instructions)
- **16 interactive prompts converted** across 4 files — zero typed letter/number selection remains
- **No new dependencies** — uses prompt_toolkit (already a CVC dependency)

---

## [1.7.9] - 2026-03-06

### 🎨 COMPLETE UI/UX OVERHAUL — Interactive, Narrated, Trust-Aware Agent

Transformed the CLI agent from a "silent executor that dumps results" into an interactive,
narrated coding companion inspired by Claude Code's excellence in developer experience.
Every interaction is now contextual, permission-aware, and beautifully rendered.

### Added
- **🔐 Trust Mode System** — Three modes for permission handling:
  - `strict` — Always prompt for risky operations (paranoid)
  - `smart` (default) — Auto-allow safe commands, prompt for risky ones (balanced)
  - `yolo` — Trust everything (move fast, break things)
  - Smart risk detection: 40+ safe commands (ls, cat, npm test, git status...), 30+ risky patterns (rm, sudo, git push --force, docker, eval...)
  - Session-wide "trust all" escalation with confirmation prompt
- **✨ Interactive Permission Panel** — Rich panel with `y/a/t/n/r` options:
  - `y` — Allow once
  - `a` — Allow all this session
  - `t` — Trust this command type always
  - `n` — Deny
  - `r` — Deny and suggest alternative (feedback injected into conversation)
- **📖 Narration System** — Agent thoughts before tool execution render as left-border `│` narration (lighter, more conversational than full panels)
- **📋 Plan Detection & Display** — Auto-detects "Plan:" blocks in agent responses:
  - Renders numbered steps in a styled panel
  - Three display modes: `plan-approve` (show + wait for approval), `plan-auto` (show + auto-execute), `plan-quiet` (skip display)
  - Optional approval gate with Enter/n prompt
- **📝 Diff Preview** — Inline color-coded diffs after file edits:
  - Uses difflib for unified diff format (+/- highlighting)
  - Max 15 lines, summary for larger diffs ("X additions, Y deletions across Z lines")
- **💻 Command Output Panel** — Styled bash output after tool execution:
  - Max 8 lines with "..." truncation for larger output
  - Red border for non-zero exit codes
  - Success/error visual feedback
- **📊 Turn Summary** — End-of-turn action recap:
  - Actions grouped by category (Files Read, Files Edited, Commands Run, Subagent Calls)
  - Token usage + cost breakdown
  - Only shown when actions exist (plain token usage for read-only turns)
- **🔢 Step Progress Counter** — "Step N/M │ ⟫ 📄 Reading file..." during multi-tool execution
- **⚙️ New Slash Commands**:
  - `/trust [strict|smart|yolo]` — View/change trust mode with status display and persistence
  - `/plan-mode [plan-approve|plan-auto|plan-quiet]` — View/change plan display with persistence
- **📚 Enhanced Help** — Updated `/help` table with new commands, sorted alphabetically

### Changed
- **Permission prompts redesigned** — From plain text → Rich panel with visual hierarchy
- **Tool execution flow narrated** — Every step now has context: what's happening, why, and status
- **Error visibility improved** — Command failures show actual output + exit code
- **Settings persistence** — Trust mode and plan display settings save to `.cvc/settings.toml`
- **System prompt enhanced** — Instructs LLM to format plans as numbered "Plan:" blocks for auto-detection
- **Help command expanded** — Now includes ~50 slash commands for tab completion

### Technical
- **Files modified**: `settings.py`, `permissions.py`, `renderer.py`, `chat.py`, `executor.py`, `system_prompt.py`
- **New renderer functions**: 7 new display functions (permission panel, narration, plan block, plan approval, diff preview, command output, turn summary, step progress)
- **New imports**: `difflib` for diff generation
- **Enhanced executor**: Exposes last change data for diff previews, bash output for command panels
- **Session state tracking**: Turn actions list, plan display mode, total tokens/cost accumulation

### Fixed
- **Broken permission initialization** — chat.py was calling non-existent `add_rule()` method; replaced with `load_rules()` + `add_cli_rules()` + `load_trust_settings()`
- **Silent file edits** — Now show what changed with color-coded diffs
- **Silent command execution** — Now show actual output with styled panels
- **No feedback on denial** — New `r` option lets users suggest alternatives when denying operations

## [1.7.7] - 2026-02-28

### ⚡ GEMINI PRO SPEED FIX — Always LOW Thinking for Pro Models

Internet research confirmed the exact thinking level support matrix from Google's docs:
- `gemini-3-pro-preview` (3.0): LOW, HIGH only (default = HIGH)
- `gemini-3.1-pro-preview` (3.1): LOW, MEDIUM, HIGH (default = HIGH = **Deep Think Mini**)
- `gemini-3-flash-preview`: MINIMAL, LOW, MEDIUM, HIGH (default = HIGH)

**Critical discovery:** HIGH is the API default when no `thinkingConfig` is sent, and HIGH
on 3.1 Pro activates Deep Think Mini which "may take several minutes." Even MEDIUM on 3.1
Pro adds ~10-15s per call — unacceptable for agentic workflows doing 5-10 tool iterations.

### Fixed
- **Pro always LOW** — removed MEDIUM from 3.1 Pro tool iterations. All Pro models (3.0 and 3.1) now use LOW for every call. LOW responds in seconds while still being smarter than non-thinking models
- **Flash simplified** — Flash now uses MEDIUM for all calls (was MEDIUM first turn, HIGH tool iterations). HIGH/Deep Think is overkill for tool iterations
- **Documented thinking matrix** — added confirmed Google API support matrix in llm.py comments so future changes are based on facts, not guesses

### Changed
- Simplified thinking routing in chat.py — removed `_is_31` variable and per-iteration branching. Now just: Pro → LOW, Flash → MEDIUM
- Updated llm.py comments with full thinking level support matrix and warning about HIGH defaults

## [1.7.6] - 2026-02-27

### 🔧 GEMINI 3.0 PRO COMPATIBILITY FIX — MEDIUM Not Supported

`gemini-3-pro-preview` (3.0) only supports LOW and HIGH thinking — sending MEDIUM causes
a 400 error on every tool iteration. Fixed thinking level routing and cleaned up UI.

### Fixed
- **Critical: MEDIUM thinking 400 errors** — `gemini-3-pro-preview` rejects `thinkingLevel: MEDIUM` with "Thinking level MEDIUM is not supported for this model". Chat.py was sending MEDIUM for Pro tool iterations. Now: 3.0 Pro always uses LOW; 3.1 Pro uses MEDIUM for tool iterations (where supported)
- **Fallback on thinking error** — was removing thinkingConfig entirely (defaulting to slow HIGH/Deep Think); now falls back to LOW (fast, universally supported)
- **llm.py default** — was defaulting to MEDIUM for all Gemini 3 models when no caller-specified level; now defaults to LOW for Pro (safe), MEDIUM for Flash

### Changed
- **Reasoning display** — removed model name, now shows just `Reasoning…` with elapsed timer (was `Reasoning… (gemini-3-pro-preview)`)
- **Thinking Model Notice removed** — the yellow warning box on startup is gone; CVC auto-routes thinking levels transparently without needing to tell the user
- **Elapsed timer** — now appears after 4s (was 5s)

## [1.7.5] - 2026-02-27

### ⚡ GEMINI PRO SPEED REVOLUTION — Research-Backed Thinking Optimization

Deep research into how Aider, GitHub Copilot, and Google's own docs handle Gemini 3 Pro
revealed the proper thinking level strategy. Key insight: **Gemini 3.1 Pro's `MEDIUM` =
3.0 Pro's `HIGH` quality**. The old HIGH is now "Deep Think Mini" — never auto-engaged.

### Changed
- **Thinking level routing redesigned** (research-backed 80/20 strategy):
  - Pro first turn: `LOW` (~3-5s) — minimal reasoning for fast response
  - Pro tool iterations: `MEDIUM` (~10-15s) — equivalent to old HIGH quality
  - Flash first turn: `MEDIUM` — Flash handles it fast
  - Flash tool iterations: `HIGH` — Flash Deep Think is quick
  - Pro `HIGH` (Deep Think Mini) **never auto-used** — only via explicit `--think` in future
- **llm.py thinking defaults unified** — removed special `_is_31_pro` branch; all Gemini 3 models default to `MEDIUM` when no caller-specified level (was separate branches for 3.0 vs 3.1)
- **Slow model warning updated** — timing now shows realistic 3-5s / 10-15s ranges (was 5-15s / 30-60s), removed deprecated `gemini-2.5-flash` from alternatives
- **`--no-think` help text** updated — references current model behavior

### Fixed
- **Pro models never get HIGH automatically** — Pro `HIGH` = Deep Think Mini (30-60s+); chat.py thinking router now guarantees Pro caps at `MEDIUM` for tool iterations and `LOW` for first turns
- **Thinking config comments** aligned with Google Feb 2026 research: documented the 3.1 Pro level equivalences in both llm.py and chat.py

## [1.7.4] - 2026-02-27

### 🧠 INVISIBLE PLANNING — Claude Code-Style Agent Intelligence

Complete redesign of the agent's planning and memory system. Inspired by Claude Code's
`TodoWrite` and `CLAUDE.md` architecture: the agent plans internally, learns from
corrections automatically, and never asks the user to manage task files.

### Changed
- **System prompt rewritten** — cleaner, Claude Code-inspired structure
  - All 6 Workflow Orchestration principles **kept** (Plan First, Subagent Strategy, Self-Improvement Loop, Verification Before Done, Demand Elegance, Autonomous Bug Fixing)
  - But now operate **invisibly** — no filesystem files, no user-facing task management
  - Removed `tasks/todo.md` and `tasks/lessons.md` references — planning is internal
  - Removed redundant "Task Management" checklist and "Working Style" section (merged into Orchestration)
  - Communication and Identity sections condensed
- **Lessons storage moved** from `tasks/lessons.md` → `.cvc/lessons.md` (internal per-workspace, not polluting project root)
- **Gemini 3 Pro thinking capped** — first conversational turns now always use `LOW` (was `HIGH` for messages ≥500 chars causing 58s+ latency); tool iterations capped at `MEDIUM` for Pro models

### Removed
- **`tasks/` directory** — no longer created or expected in user workspaces
- **`tasks/todo.md`** template — agent plans internally, no user-facing task files
- **`tasks/lessons.md`** location — replaced by `.cvc/lessons.md`
- **Complexity estimator** in chat.py — was measuring user message length to decide thinking level; replaced with simple model-type check (Pro → LOW/MEDIUM, Flash → MEDIUM/HIGH)

### Fixed
- **Gemini 3 Pro still slow** — chat.py was overriding llm.py's `LOW` default to `HIGH` for messages ≥500 chars; now Pro models never exceed `MEDIUM` thinking
- **`tasks/todo.md` not found** error in user workspaces — the file was only created in the CVC project root, not per-workspace; eliminated entirely

## [1.7.3] - 2026-02-27

### ⚡ GEMINI 3.1 PRO PERFORMANCE FIX

Fixed slow response times (60-120s) with `gemini-3.1-pro-preview` by applying aggressive thinking level control and matching the slow-model timeout path.

### Fixed
- **Slow model detection** now matches `gemini-3.1-pro` (was only matching `gemini-3-pro`) — gets 300s read timeout instead of 180s
- **Thinking level for 3.1 Pro**: Forced to `LOW` for conversational turns (was falling through to generic default), reducing server-side thinking from ~120s to ~10-20s
- **All error messages** updated to reference current models (`gemini-3-flash-preview`) instead of deprecated `gemini-2.5-flash`

### Changed
- **Model aliases updated**: `gemini-3` → `gemini-3-flash-preview` (was `gemini-2.5-flash`), `gemini-pro` → `gemini-3-pro-preview`, `gemini-flash` → `gemini-3-flash-preview`
- **Added alias**: `gemini-3.1-pro` → `gemini-3.1-pro-preview`
- **Removed deprecated aliases**: `gemini-2.5`, `gemini-2.5-flash-preview`, `gemini-2.5-pro-preview`

## [1.7.2] - 2026-02-27

### 🧭 WORKFLOW ORCHESTRATION — 10x Agent Intelligence

Baked the user's workflow orchestration framework directly into Sofia's system prompt.
Every CVC CLI session now runs with senior engineer discipline by default.

### Added
- **Workflow Orchestration section in system prompt** (6 principles):
  1. **Plan First** — `tasks/todo.md` with checkable items before touching code on any 3+ step task
  2. **Subagent Strategy** — offload research/exploration to subagents to keep main context clean
  3. **Self-Improvement Loop** — `tasks/lessons.md` updated after every user correction; auto-injected at session start
  4. **Verification Before Done** — never mark complete without proving it works
  5. **Demand Elegance** — pause and ask "is there a more elegant way?" for non-trivial changes
  6. **Autonomous Bug Fixing** — just fix it when handed a bug report, zero hand-holding
- **Task Management checklist** embedded in system prompt (plan → verify → track → explain → document → lessons)
- **Core Principles** embedded: Simplicity First, No Laziness, Minimal Impact
- **`tasks/lessons.md`** — live per-project lessons file auto-injected into system prompt at every session start
- **`tasks/todo.md`** — task plan template for structured work tracking
- **`lessons_context` parameter** added to `build_system_prompt()` — loaded from `tasks/lessons.md` in workspace
- Lessons loaded in **parallel** alongside auto-context, memory, and git context at startup (4-threaded pool)
- `_rebuild_system_prompt()` also reloads lessons on branch switch

## [1.7.1] - 2026-02-27

### 🤖 GEMINI 3.1 PRO PREVIEW MODEL SUPPORT

Added Google's newest `gemini-3.1-pro-preview` model. Deprecated Gemini 2.5 series (Pro, Flash, Flash-Lite) — the Gemini 3 family is now the full Google lineup.

### Added
- **`gemini-3.1-pro-preview`** — Refined Gemini 3 Pro with better thinking, improved token efficiency, and optimized agentic tool calling
- **`gemini-3.1-pro-preview-customtools`** endpoint noted in docs (prioritizes custom tools over bash)

### Changed
- Default Google model changed from `gemini-2.5-flash` to `gemini-3-flash-preview`
- Slow model warning now triggers for both `gemini-3-pro` and `gemini-3.1-pro` variants
- Updated model catalogs in CLI setup, agent `/model` command, cost tracker, and all documentation

### Removed
- `gemini-2.5-pro` — superseded by Gemini 3 Pro / 3.1 Pro
- `gemini-2.5-flash` — superseded by Gemini 3 Flash
- `gemini-2.5-flash-lite` — deprecated

## [1.7.0] - 2026-02-27

### 🏗️ TIER 4 PAGEINDEX — REAL ARCHITECTURE REBUILD

Complete rewrite of Tier 4 PageIndex to faithfully adapt the real [VectifyAI/PageIndex](https://github.com/VectifyAI/PageIndex) architecture. Eliminates arbitrary chunking in favor of document-native structure extraction.

**What Changed**:
- ❌ **Old**: Arbitrary 2000-character chunking with 200-char overlap, generic LLM summaries
- ✅ **New**: Table-of-Contents extraction, page-indexed hierarchical tree nodes, LLM-guided tree search

### Added
- **Real PageIndex pipeline for PDFs**: TOC detection → TOC extraction → TOC transformation → physical page offset mapping → hierarchical tree building → large node recursive splitting → LLM summary enrichment → document description generation
- **Markdown pipeline**: Header-based tree construction from `#`/`##`/`###` structure — no arbitrary chunking
- **Plain text pipeline**: LLM-generated pseudo-TOC for documents without natural structure
- **LLM-guided tree navigation search**: Reads node summaries at each tree level, selects most relevant branches, recurses to leaf nodes
- **Page-indexed node structure**: Each node stores `{title, node_id, start_index, end_index, summary, nodes[]}` — exact page references, not character offsets
- **Zstd-compressed JSON persistence**: Document indices stored as compressed JSON in `.cvc/pageindex/`

### Changed
- **`cvc/core/pageindex.py`**: Complete rewrite (~780 lines) adapting real PageIndex architecture
- **`cvc/agent/executor.py`**: All 3 PageIndex handlers updated — results now show `doc_name`, `doc_type`, `node_count`, `doc_description`, `node_id`, `title`, `start_index`/`end_index`
- **`cvc/agent/tools.py`**: Removed `chunk_size` parameter from `cvc_ingest_document`, updated all tool descriptions to reflect TOC-based architecture
- **`cvc/agent/chat.py`**: Increased `max_tokens` from 1024 to 4096 for PageIndex LLM calls to accommodate large TOC transformation responses

### Removed
- Arbitrary character-based chunking (2000-char chunks with 200-char overlap)
- `chunk_size` parameter from ingestion tool
- Generic chunk-level summaries replaced by structure-aware node summaries

## [1.4.4] - 2026-02-17

### 🔄 CROSS-MODE INTEROPERABILITY

This release implements **seamless cross-mode awareness** across all three CVC interfaces (MCP, Proxy, CLI). Users can now start a conversation in one mode and continue it in another—it's the same brain, three different interfaces.

**The Vision**:
- Use MCP in VS Code for coding sessions
- Switch to CLI agent for terminal-based workflows  
- Access via Proxy with Continue.dev or other tools
- **All three modes share the same `.cvc/` database**
- **Full conversation continuity across mode transitions**

**The Problem**:
- No tracking of which mode (MCP/Proxy/CLI) created each commit
- Users couldn't tell if a restored session came from a different tool
- No logging or awareness of cross-mode transitions
- Incomplete documentation on multi-mode workflows

**The Solution**:
- ✅ **Mode tracking in commits** - every commit records its origin (mcp/proxy/cli)
- ✅ **Cross-mode detection** - logs "🔄 Cross-mode restore" when switching tools
- ✅ **Unified interoperability** - all modes read/write same database seamlessly
- ✅ **Comprehensive documentation** - new CROSS_MODE_GUIDE.md explains workflows

### Added
- **Mode tracking**:
  - Added `mode: str` field to `CVCConfig` (defaults to "cli")
  - Added `mode: str | None` field to `CommitMetadata`
  - All commits now store which service created them
  
- **Cross-mode logging**:
  - MCP auto-restore detects if previous session was from Proxy or CLI
  - Proxy auto-restore detects if previous session was from MCP or CLI  
  - CLI auto-restore detects if previous session was from MCP or Proxy
  - Logs "🔄 Cross-mode restore: X messages from MODE1 → MODE2" when detected
  - Makes cross-mode transitions visible and debuggable

- **Entry point configuration**:
  - `mcp_server.py` sets `mode="mcp"` on config creation
  - `proxy.py` sets `mode="proxy"` on config creation
  - `agent/chat.py` sets `mode="cli"` on config creation
  - All three modes properly identify themselves

### Changed
- **CommitMetadata schema**: Now includes optional `mode` field for tracking
- **Auto-restore docstrings**: Updated to mention cross-mode support
- **Engine commit creation**: All commits now include mode from config

### Documentation
- **Created CROSS_MODE_GUIDE.md**:
  - Comprehensive explanation of three modes (MCP, Proxy, CLI)
  - Real-world cross-mode workflows and scenarios
  - Best practices for multi-mode usage
  - Troubleshooting cross-mode issues
  - Technical details on metadata tracking
  - Architectural guarantees for interoperability
  - 50+ examples of cross-mode transitions

### Technical Details
**Modified Files**:
- `cvc/core/models.py` - Added mode tracking to CVCConfig and CommitMetadata
- `cvc/operations/engine.py` - Pass mode to all CommitMetadata creations
- `cvc/core/database.py` - Include mode in genesis commit
- `cvc/mcp_server.py` - Set mode="mcp" and detect cross-mode restores
- `cvc/proxy.py` - Set mode="proxy" and detect cross-mode restores  
- `cvc/agent/chat.py` - Set mode="cli" and detect cross-mode restores

**Backward Compatibility**:
- Existing commits without `mode` field will show "unknown" in logs
- All new commits automatically include mode tracking
- No migration needed - feature works immediately

**Real-World Example**:
```bash
# Day 1: Design in CLI
$ cvc
User: "Design auth system"
AI: [provides design]
User: /commit Auth design v1
# Commit d4e5f6a7 (mode: cli)

# Day 2: Implement in VS Code with MCP  
# VS Code restarts, MCP auto-restores
🔄 Cross-mode restore: 10 messages from CLI → MCP (commit d4e5f6a7)
User: "Implement login endpoint"
AI: [writes code]
# Commit g7h8i9j0 (mode: mcp)

# Day 3: Test with Continue.dev via Proxy
$ cvc proxy
🔄 Cross-mode restore: 24 messages from MCP → PROXY (commit g7h8i9j0)  
User: "Write tests"
AI: [generates tests]
# Commit k1l2m3n4 (mode: proxy)
```

**Result**: One seamless conversation across three different tools, all tracked in `.cvc/`
## [1.4.4] - 2026-02-17

### 🔄 CROSS-MODE INTEROPERABILITY

This release implements **seamless cross-mode awareness** across all three CVC interfaces (MCP, Proxy, CLI). Users can now start a conversation in one mode and continue it in another—it's the same brain, three different interfaces.

**The Vision**:
- Use MCP in VS Code for coding sessions
- Switch to CLI agent for terminal-based workflows  
- Access via Proxy with Continue.dev or other tools
- **All three modes share the same `.cvc/` database**
- **Full conversation continuity across mode transitions**

**The Problem**:
- No tracking of which mode (MCP/Proxy/CLI) created each commit
- Users couldn't tell if a restored session came from a different tool
- No logging or awareness of cross-mode transitions
- Incomplete documentation on multi-mode workflows

**The Solution**:
- ✅ **Mode tracking in commits** - every commit records its origin (mcp/proxy/cli)
- ✅ **Cross-mode detection** - logs "🔄 Cross-mode restore" when switching tools
- ✅ **Unified interoperability** - all modes read/write same database seamlessly
- ✅ **Comprehensive documentation** - new CROSS_MODE_GUIDE.md explains workflows

### Added
- **Mode tracking**:
  - Added `mode: str` field to `CVCConfig` (defaults to "cli")
  - Added `mode: str | None` field to `CommitMetadata`
  - All commits now store which service created them
  
- **Cross-mode logging**:
  - MCP auto-restore detects if previous session was from Proxy or CLI
  - Proxy auto-restore detects if previous session was from MCP or CLI  
  - CLI auto-restore detects if previous session was from MCP or Proxy
  - Logs "🔄 Cross-mode restore: X messages from MODE1 → MODE2" when detected
  - Makes cross-mode transitions visible and debuggable

- **Entry point configuration**:
  - `mcp_server.py` sets `mode="mcp"` on config creation
  - `proxy.py` sets `mode="proxy"` on config creation
  - `agent/chat.py` sets `mode="cli"` on config creation
  - All three modes properly identify themselves

### Changed
- **CommitMetadata schema**: Now includes optional `mode` field for tracking
- **Auto-restore docstrings**: Updated to mention cross-mode support
- **Engine commit creation**: All commits now include mode from config

### Documentation
- **Created CROSS_MODE_GUIDE.md**:
  - Comprehensive explanation of three modes (MCP, Proxy, CLI)
  - Real-world cross-mode workflows and scenarios
  - Best practices for multi-mode usage
  - Troubleshooting cross-mode issues
  - Technical details on metadata tracking
  - Architectural guarantees for interoperability
  - 50+ examples of cross-mode transitions

### Technical Details
**Modified Files**:
- `cvc/core/models.py` - Added mode tracking to CVCConfig and CommitMetadata
- `cvc/operations/engine.py` - Pass mode to all CommitMetadata creations
- `cvc/core/database.py` - Include mode in genesis commit
- `cvc/mcp_server.py` - Set mode="mcp" and detect cross-mode restores
- `cvc/proxy.py` - Set mode="proxy" and detect cross-mode restores  
- `cvc/agent/chat.py` - Set mode="cli" and detect cross-mode restores

**Backward Compatibility**:
- Existing commits without `mode` field will show "unknown" in logs
- All new commits automatically include mode tracking
- No migration needed - feature works immediately

**Real-World Example**:
```bash
# Day 1: Design in CLI
$ cvc
User: "Design auth system"
AI: [provides design]
User: /commit Auth design v1
# Commit d4e5f6a7 (mode: cli)

# Day 2: Implement in VS Code with MCP  
# VS Code restarts, MCP auto-restores
🔄 Cross-mode restore: 10 messages from CLI → MCP (commit d4e5f6a7)
User: "Implement login endpoint"
AI: [writes code]
# Commit g7h8i9j0 (mode: mcp)

# Day 3: Test with Continue.dev via Proxy
$ cvc proxy
🔄 Cross-mode restore: 24 messages from MCP → PROXY (commit g7h8i9j0)  
User: "Write tests"
AI: [generates tests]
# Commit k1l2m3n4 (mode: proxy)
```

**Result**: One seamless conversation across three different tools, all tracked in `.cvc/`

## [1.4.3] - 2026-02-17

### 🚀 CLI AGENT OPTIMIZATIONS

This release fixes critical CLI bugs and optimizes the agent for automatic persistent storage.

**The Problems**:
- `AttributeError: 'CVCConfig' object has no attribute 'cvc_dir'` - persistent cache was broken
- CLI had no auto-restore on startup (losing previous conversations)
- Auto-commit interval too long (5 turns) - risking data loss on crashes
- No clear documentation of CLI features

**The Solutions**:
- ✅ **Fixed persistent cache bug** - changed `cvc_dir` to `cvc_root`
- ✅ **Added auto-restore for CLI** - loads last commit or cache on startup
- ✅ **Aggressive auto-commit** - changed from every 5 turns to every 2 turns
- ✅ **Automatic persistence** - every message saved to persistent cache
- ✅ **Full CLI documentation** - comprehensive guide for all features

### Fixed
- **CRITICAL**: Fixed `AttributeError` in persistent cache (lines 98, 116 in engine.py)
  - Changed `self.config.cvc_dir` to `self.config.cvc_root`
  - Persistent cache now works correctly in all modes

### Added
- **Auto-restore for CLI agent**:
  - Loads last commit on startup (if exists)
  - Falls back to persistent cache if no commits
  - Prevents conversation loss across CLI restarts
  - Logs restore status for debugging

### Changed
- **Auto-commit interval**: 5 turns → 2 turns (configurable via `CVC_AGENT_AUTO_COMMIT` env var)
  - More aggressive auto-save to prevent data loss
  - Optimized for CLI usage patterns
  - Every 2 assistant responses triggers automatic commit

- **CLI persistence strategy**:
  1. Persistent cache saved on EVERY message push
  2. Auto-commit every 2 assistant turns
  3. Final commit on exit (if uncommitted turns exist)
  4. Auto-restore on next CLI startup

### Documentation
- Created comprehensive CLI_AGENT_GUIDE.md (pending)
- Updated chat.py docstrings with persistence details

## [1.4.2] - 2026-02-17

### 🎯 USER EXPERIENCE IMPROVEMENTS

This release improves the MCP server startup messaging to eliminate confusion about manual execution.

**The Problem**:
- Users ran `cvc mcp` manually in terminal and saw "awaiting IDE connection"
- This caused confusion - they thought the server wasn't working
- In reality, VS Code spawns its own background MCP process automatically
- The terminal instance is unnecessary and confusing

**The Solution**:
- ✅ **Clear warning banner**: "⚠️ YOU DON'T NEED TO RUN THIS COMMAND MANUALLY!"
- ✅ **Detailed explanation**: How MCP works with IDE background processes
- ✅ **Quick setup guide**: Step-by-step mcp.json configuration
- ✅ **Better final message**: Explains the terminal instance is not needed
- ✅ **Usage examples**: Shows how to use CVC through AI assistant

### Changed
- **Startup banner** (`_print_stdio_guidance()`):
  - Added prominent warning about manual execution
  - Explained MCP background process architecture
  - Included quick setup guide for first-time users
  - Added usage examples showing AI assistant interaction
  - Removed confusing "awaiting IDE connection" message
  
- **Final message** after banner:
  - Changed from "awaiting IDE connection" to clear explanation
  - Tells users the terminal instance is not needed
  - Explains CVC is already working if configured correctly
  - Encourages users to close terminal and use AI assistant

### Improved
- **User onboarding**: First-time users get clear setup instructions
- **Error prevention**: Users won't waste time waiting for terminal connection
- **Documentation clarity**: Banner now serves as inline documentation

## [1.4.1] - 2026-02-17

### 🌍 MULTI-WORKSPACE SUPPORT IMPROVEMENTS

This release fixes critical multi-workspace issues and improves workspace detection reliability.

**The Problem**:
- Hardcoded `CVC_WORKSPACE` env var in MCP config breaks multi-workspace support
- All projects would share the same `.cvc/` database folder
- Users with multiple projects had no clear guidance on workspace switching

**The Solution**:
- ✅ **Removed hardcoded workspace env var** from MCP config
- ✅ **Improved workspace detection priority** - `cvc_set_workspace` tool now takes highest priority
- ✅ **Comprehensive multi-workspace documentation** ([MULTI_WORKSPACE.md](MULTI_WORKSPACE.md))
- ✅ **Better warning messages** when workspace detection falls back to cwd

### Added
- **MULTI_WORKSPACE.md**: Complete guide to working with multiple projects
  - Automatic workspace detection strategies
  - Manual workspace switching with `cvc_set_workspace` tool
  - Best practices for multi-workspace setups
  - Troubleshooting guide

### Changed
- **Workspace detection priority order** in MCP server:
  1. Explicit override via `cvc_set_workspace` tool (NEW: highest priority)
  2. `CVC_WORKSPACE` environment variable
  3. IDE-specific env vars (CODEX_WORKSPACE_ROOT, etc.)
  4. Walk up from cwd to find markers (`.cvc`, `.git`, `pyproject.toml`, `package.json`)
  5. Fallback to cwd with improved warning message

- **Warning messages**: Now recommend `cvc_set_workspace` tool instead of env var for multi-workspace scenarios

### Documentation
- Added multi-workspace support note to README.md MCP section
- Created comprehensive MULTI_WORKSPACE.md guide
- Updated mcp.json configuration examples

### Fixed
- **Multi-workspace bug**: Removed hardcoded workspace path from default MCP config
- **Detection priority**: `cvc_set_workspace` now correctly takes precedence over all other strategies

## [1.4.0] - 2026-02-17

### 🚨 CRITICAL PERSISTENCE FIX

This release solves the **zero data loss** problem across all CVC modes (MCP, Proxy, CLI).

**The Problem**:
- MCP mode: Context window started EMPTY on every VS Code restart → conversations lost
- Proxy mode: Auto-commits only every 10 turns → up to 9 turns of data loss on crash
- Both modes: No recovery mechanism for interrupted sessions

**The Solution**:
- ✅ **Auto-restore** from last commit on startup (MCP + Proxy)
- ✅ **Persistent cache** file saved on every message push
- ✅ **Database-backed `cvc_get_context`** can retrieve older conversations
- ✅ **Aggressive auto-commit** in Time Machine mode (every turn, not every 3)

### Added

#### MCP Server
- **Auto-restore on startup**: MCP server now automatically loads the last committed context when VS Code starts
  - Priority: Last commit → Persistent cache → Empty state
  - Prevents data loss across IDE restarts
  - Users can now retrieve month-old conversations from `.cvc/` database

#### Engine (Core)
- **Persistent cache file**: `.cvc/context_cache.json` auto-saved on every `push_message()`
  - Survives crashes/force-quits before commit
  - Loaded automatically if no commits exist yet
  - Non-blocking writes (failures are logged but don't crash)

- **`_load_persistent_cache()`**: Recovery mechanism for interrupted sessions
- **`_save_persistent_cache()`**: Called on every message push

#### Tools
- **`cvc_get_context` now reads from database**: 
  - Pass `commit_hash` to retrieve full conversation from any historical commit
  - Returns `source: "database"` vs `source: "memory"` to clarify origin
  - Can now answer "show me what we discussed a month ago"

#### Proxy Mode
- **Aggressive auto-commit intervals**:
  - Time Machine mode: Every 1 turn (was: every 3)
  - Normal mode: Every 3 turns (was: every 10)
  - Configurable via `CVC_TIME_MACHINE_INTERVAL` and `CVC_AUTO_COMMIT_INTERVAL`
- **Auto-restore on proxy startup**: Loads last commit or cache into memory

### Changed

- **Default auto-commit intervals** (proxy mode):
  - `_NORMAL_INTERVAL`: 10 → 3 turns
  - `_TIME_MACHINE_INTERVAL`: 3 → 1 turn
- **MCP `cvc_get_context`**: Now returns `source` field indicating "database" or "memory"
- **Engine initialization**: Always attempts auto-restore from database or cache

### Fixed

- **MCP mode data loss on VS Code restart**: Context now persists across sessions
- **Uncommitted messages lost on crash**: Persistent cache provides recovery
- **Cannot retrieve old conversations**: Database-backed retrieval now works
- **Auto-commit too infrequent**: Aggressive intervals ensure near-zero data loss

### Technical Details

#### Storage Architecture (Updated)
```
.cvc/
├── cvc.db              # SQLite: commit graph, branches, metadata
├── objects/            # Zstandard-compressed context snapshots
├── context_cache.json  # 🆕 Persistent cache (uncommitted work)
└── chroma/             # Optional vector embeddings
```

#### Auto-Restore Flow
1. **MCP/Proxy startup** → Load HEAD commit from database
2. **If HEAD is genesis** → Load from `context_cache.json`
3. **If cache missing** → Start with empty state
4. **Every message push** → Write to cache (async, non-blocking)
5. **Every N turns** → Commit to database + advance HEAD

#### Backward Compatibility
- ✅ Existing `.cvc/` directories work without migration
- ✅ `context_cache.json` created on first save
- ✅ Old commits remain retrievable

### Migration Guide

**No action required!** The v1.4.0 upgrade is seamless:

1. Update: `pip install -U tm-ai`
2. Restart VS Code or proxy server
3. Auto-restore activates automatically

**To verify persistence**:
```bash
# MCP mode (in GitHub Copilot chat):
@cvc /cvc_get_context

# Should show restored messages from last commit, not empty context

# Proxy mode:
curl http://127.0.0.1:8000/cvc/status
# Should show context_size > 0 after restart
```

### Performance Notes

- **Cache writes**: <1ms per message (async JSON write)
- **Auto-restore**: <50ms on startup (one database read)
- **Memory overhead**: +1 JSON file (~1-10KB depending on context size)

---

## [1.3.2] - 2026-02-17

### Fixed
- **Content truncation bug**: `cvc_get_context` now returns full message content by default
  - Previous versions truncated at 200 characters
  - Added `full` parameter (default: `true`)

---

## [1.3.1] - 2026-02-17

### Fixed
- **Database API error** in `cvc_get_context` tool
  - Changed from `db.storage.load_snapshot()` to `engine.log()`

---

## [1.3.0] - 2026-02-17

### Added
- **Workspace auto-detection** (5-strategy fallback system)
  - `CVC_WORKSPACE` env var
  - IDE-specific env vars (`CODEX_WORKSPACE_ROOT`, etc.)
  - Walk up from cwd to find `.cvc/`, `.git/`, `pyproject.toml`
  - Fallback to `os.getcwd()` with warning
- **Auto-initialization**: Creates `.cvc/` if missing
- **Persistent session state**: MCP server maintains engine across tool calls
- **New MCP tools**: `cvc_capture_context`, `cvc_set_workspace`, `cvc_get_context`

### Changed
- MCP server now stateful (module-level `_MCPSession` instance)

---

## [1.2.9] - 2026-02-16

### Added
- `cvc_capture_context` tool for manual conversation capturing in MCP mode

---

## [1.2.8] - 2026-02-15

### Added
- Initial MCP server implementation
- 6 core tools: status, commit, branch, merge, restore, log

---

[1.4.0]: https://github.com/tm-ai/cvc/compare/v1.3.2...v1.4.0
[1.3.2]: https://github.com/tm-ai/cvc/compare/v1.3.1...v1.3.2
[1.3.1]: https://github.com/tm-ai/cvc/compare/v1.3.0...v1.3.1
[1.3.0]: https://github.com/tm-ai/cvc/compare/v1.2.9...v1.3.0
[1.2.9]: https://github.com/tm-ai/cvc/compare/v1.2.8...v1.2.9
[1.2.8]: https://github.com/tm-ai/cvc/releases/tag/v1.2.8
