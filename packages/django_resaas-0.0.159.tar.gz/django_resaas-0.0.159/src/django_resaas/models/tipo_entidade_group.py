
from django.db import models
from django_resaas.core.base.models import TimeModel
class TipoEntidadeGroup(TimeModel):
    tipo_entidade = models.ForeignKey("django_resaas.TipoEntidade", on_delete=models.CASCADE)
    group = models.ForeignKey("auth.Group", on_delete=models.CASCADE)
    

    class Meta:
        permissions = (
            
        )

    class RESAAS:
        label_field = "name"
        # route="view_entidade"

    def __str__(self):
        return str(self.group.name)

