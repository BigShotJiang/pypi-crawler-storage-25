import threading
import datetime

class IsNotArrayError(Exception):
    pass

class ArrayTypeError(Exception):
    pass

# class TError(Exception):
#     pass

# class StackError(TError):
#     def __init__(self, message="Stack is full", cause=None):
#         self.timestamp = datetime.datetime.now()
#         self.thread_name = threading.current_thread().name
#         self.cause = cause

#         full_message = (
#             f"\n[StackError] {self.timestamp}\n"
#             f"Threads: {self.thread_name}\n"
#             f"Message: {message}\n"
#             f"Reason: {repr(self.cause) if self.cause else 'Unknown reason'}"
#         )
#         super().__init__(full_message)

#     def __repr__(self):
#         return f"<ThreadsError in {self.thread_name}>"

# class ThreadsError(TError):
#     def __init__(self, message="Error in thread's work", cause=None):
#         self.timestamp = datetime.datetime.now()
#         self.thread_name = threading.current_thread().name
#         self.cause = cause

#         full_message = (
#             f"\n[ThreadsError] {self.timestamp}\n"
#             f"Threads: {self.thread_name}\n"
#             f"Message: {message}\n"
#             f"Reason: {repr(self.cause) if self.cause else 'Unknown'}"
#         )
#         super().__init__(full_message)

#     def __repr__(self):
#         return f"<ThreadsError in {self.thread_name}>"




async def check(array):
    if not isinstance(array, (list, tuple, dict, set)):
        raise IsNotArrayError