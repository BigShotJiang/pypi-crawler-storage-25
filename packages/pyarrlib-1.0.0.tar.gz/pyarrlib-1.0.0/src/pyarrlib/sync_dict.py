from .sync_arrpy import *

def dict_max(d: dict):
    return max(d.values())

def dict_min(d: dict):
    return min(d.values())


def is_key_value_in_dict(d:dict, key, value) -> bool:
    return d.get(key) == value

def key_sum(d:dict):
    res = 0
    for i in d.keys():
        if isinstance(i, (int, float)):
            res += i
    
    return res

def key_multiplication(d:dict):
    res = 1
    for i in d.keys():
        if isinstance(i, (int, float)):
            res *= i
    
    return res

def same_keys(d1:dict, d2:dict):
    return list(set(d1) & set(d2))
def same_values(d1: dict, d2: dict):
    return list(set(d1.values()) & set(d2.values()))


def value_sum(d:dict):
    res = 0
    for i in d.values():
        if isinstance(i, (int, float)):
            res += i
    
    return res

def value_multiplication(d:dict):
    res = 1
    for i in d.values():
        if isinstance(i, (int, float)):
            res *= i
    
    return res
