class IsNotArrayError(Exception):
    pass

class ArrayTypeError(Exception):
    pass


def check(array):
    if not isinstance(array, (list, tuple, dict, set)):
        raise IsNotArrayError