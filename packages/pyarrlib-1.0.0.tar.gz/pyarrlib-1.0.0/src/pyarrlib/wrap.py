from concurrent.futures import ThreadPoolExecutor
import multiprocessing




def run(func):
    def wrapper(self):
        th = multiprocessing.cpu_count()
        with ThreadPoolExecutor(max_workers=th) as executor:
            futures = [executor.submit(func, self) for _ in range(th)]
            return [f.result() for f in futures]
    return wrapper
