from .async_arrpy import *
from .wrap import run

@run
async def dict_max(d: dict):      
    return max(d.values())  

@run
async def dict_min(d: dict):
    return min(d.values())

@run
async def is_key_value_in_dict(d:dict, key, value):
    return d.get(key) == value

@run
async def key_sum(d:dict):
    res = 0
    for i in d.values():
        if isinstance(i, (int, float)):
            res += i
    
    return res

@run
async def key_multiplication(d:dict):
    res = 1
    for i in d.values():
        if isinstance(i, (int, float)):
            res *= i
    
    return res

@run
async def same_keys(d1:dict, d2:dict):
    return set(d1) & set(d2)

@run
async def same_values(d1:dict, d2:dict):
    return set(d1.values()) & set(d2.values())

@run
async def value_sum(d:dict):
    res = 0
    for i in d.values():
        if isinstance(i, (int, float)):
            res += i
    
    return res

@run
async def value_multiplication(d:dict):
    res = 1
    for i in d.values():
        if isinstance(i, (int, float)):
            res *= i
    
    return res
