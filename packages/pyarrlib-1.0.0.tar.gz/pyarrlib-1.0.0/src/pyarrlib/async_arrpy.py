from .async__checks import ArrayTypeError, check
from .wrap import run

@run
async def reverse_arr(array):
    check(array)
    return array[::-1]

@run
async def sum_arr(array):
    check(array)   
    res = 0
    for i in array:
        if not isinstance(i, (int, float)):
            return ArrayTypeError
        else: res += i
    return res

@run
async def multiplication_arr(array):
    check(array)
    res = 1
    for i in array:
        if not isinstance(i, (int, float)):
            return ArrayTypeError
        else:
            res *= i
    return res

@run
async def min(array):
    check(array)
    res = array[0]
    for i in array:
        if not isinstance(i, (int, float)):
            raise ArrayTypeError
        elif i < res:
            res = i
    return res

@run
async def max(array):
    check(array)
    res = array[0]
    for i in array:
        if not isinstance(i, (int, float)):
            raise ArrayTypeError
        if i > res:
            res = i 
    return res

@run
async def arifmetic_mean(array):
    check(array)
    s = await sum_arr(array)
    return s / len(array)

@run
async def sort(array):
    check(array)
    tmp_lst = []
    while array:
        min_val = min(array)
        count = array.count(min_val)  
        tmp_lst.extend([min_val] * count)
        for _ in range(count):
            array.remove(min_val)
    array[:] = tmp_lst
    return array


@run
async def same(array1, array2):
    check(array1)
    check(array2)
    s = set(array2)
    return [i for i in array1 if i in s]

@run
async def step_filter(array, step:int, first_num=0):
    check(array)
    return array[first_num::step]

@run
async def type_filter(array, type_filt:type):
    check(array)
    res = []
    types = [int, float, bool, str, list, tuple, dict, set, complex]
    if type_filt in types:
        types.remove(type_filt)
        t = tuple(types)
    else: raise TypeError
    for i in array:
        if not isinstance(i, t):
            res.append(i)
    return res

@run
async def range_arr(array, first:float |int, last:int|float):
    check(array)
    if first > last:
        return None
    res = []
    for i in array:
        if isinstance(i, (int, float)):
            if i >= first and i <= last:
                res.append(i)
    return res

@run
async def range_other(array, first, last):
    check(array)
    if first > last:
        return None
    res = []
    for i in array:
        if isinstance(i, (int, float)):
            if i <= first or i >= last:
                res.append(i)
    return res

@run
async def chunk(array, size):
    check(array)
    res = []
    for i in range(0, len(array), size):
        res.append(array[i: i+size])
    return res

@run
async def mv(array, i1, i2):
    check(array)
    r = array[i1]
    array.remove(r)
    array.insert(i2, r)
    
@run
async def hw_times(array, key):
    check(array)
    res = 0
    for i in array:
        if i == key:
            res += 1
    return res

@run
async def not_same(array, array2):
    check(array)
    check(array2)
    return list((array + array2) - set(array2) & set(array2))

@run
async def section(array, part):
    check(array)
    res = []
    for i in range(0, len(array), part):
        res.append(array[i:i+part])
    
    return res