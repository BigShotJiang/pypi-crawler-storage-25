# pyarrlib

A small Python utility library for working with arrays, nested array structures, and dictionaries.

This project provides helper functions for reversing arrays, computing numeric aggregates, counting nested leaves, splitting arrays, solving small systems of linear equations, and working with dictionary keys and values.

## Features

### Array Functions
- `reverse_arr(array)` — reverse a one-dimensional sequence
- `sum_arr(array)` — compute the sum of numeric values
- `multiplication_arr(array)` — compute the product of numeric values
- `min(array)` — find the smallest numeric value in a sequence
- `max(array)` — find the largest numeric value in a sequence
- `arifmetic_mean(array)` — compute the arithmetic mean of numeric values
- `sort(array)` — sort the array in-place
- `same(array1, array2)` — find common elements between two arrays
- `step_filter(array, step, first_num=0)` — filter array with step
- `type_filter(array, type_filt)` — filter elements by type
- `range_arr(array, first, last)` — get numeric values inside an inclusive range
- `range_other(array, first, last)` — get numeric values outside an inclusive range
- `chunk(array, size)` — split the array into fixed-size chunks
- `mv(array, i1, i2)` — move element from index i1 to i2
- `hw_times(array, key)` — count occurrences of key
- `not_same(array, array2)` — find elements not common between arrays
- `section(array, part)` — split the array into consecutive sections

### Nested Array Functions
- `leafs(array)` — flatten nested integer arrays
- `num_of_leafs(array)` — count integer leaf nodes in nested arrays
- `len_arr(array)` — count all scalar leaves in nested arrays
- `equation_system(full_matrix)` — solve 2×2 or 3×3 linear systems using determinants

### Dictionary Functions
- `dict_max(d)` — find the maximum value in dictionary values
- `dict_min(d)` — find the minimum value in dictionary values
- `is_key_value_in_dict(d, key, value)` — check if key-value pair exists
- `key_sum(d)` — sum numeric keys in dictionary
- `key_multiplication(d)` — multiply numeric keys in dictionary
- `same_keys(d1, d2)` — find common keys between dictionaries
- `same_values(d1, d2)` — find common values between dictionaries
- `value_sum(d)` — sum numeric values in dictionary
- `value_multiplication(d)` — multiply numeric values in dictionary

## Installation

From the repository root, install in editable mode:

```bash
python -m pip install -e .
```

If you prefer not to install, you can run code directly from this project by ensuring the repository root is on `PYTHONPATH`.

## Usage

```python
from pyarrlib import (
    ArrayTypeError,
    IsNotArrayError,
    arifmetic_mean,
    chunk,
    dict_max,
    dict_min,
    equation_system,
    hw_times,
    is_key_value_in_dict,
    key_sum,
    key_multiplication,
    leafs,
    len_arr,
    max,
    min,
    multiplication_arr,
    mv,
    not_same,
    num_of_leafs,
    range_arr,
    reverse_arr,
    same,
    section,
    sort,
    step_filter,
    sum_arr,
    type_filter,
    value_sum,
    value_multiplication,
)

print(reverse_arr([1, 'hello', 3, True]))
# [True, 3, 'hello', 1]

print(sum_arr([1, 5, 4, 3, 8]))
# 21

print(multiplication_arr([4, 1, 2, 5, 7]))
# 280

print(min([1, 3, 6, -3, 2]))
# -3

print(arifmetic_mean([2, 4, 6]))
# 4.0

nested = [[1, 2, [3]], [4, [5, 6]]]
print(leafs(nested))
# [1, 2, 3, 4, 5, 6]
print(num_of_leafs(nested))
# 6
print(len_arr(nested))
# 6

system = [
    [2, -1, 1],
    [1, 1, 1],
    [1, 2, -1],
]
print(equation_system([row + [value] for row, value in zip(system, [1, 2, 3])]))

arr = [1, 2, 3, 4, 5]
sort(arr)
print(arr)  # [1, 2, 3, 4, 5]

print(chunk([1, 2], 3))  # [[1, 2, 3]]

print(hw_times([1, 2, 2, 3], 2))  # 2

print(type_filter([1, 'a', 2.0, True], int))  # [1, True]

d = {'a': 1, 'b': 2}
print(key_sum(d))  # 0
print(value_sum(d))  # 3
print(is_key_value_in_dict(d, 'a', 1))  # True
```

## API Reference

### Exceptions

- `ArrayTypeError` — raised when array contains unsupported element types for numeric operations
- `IsNotArrayError` — raised when input is not an array-like structure

### Array Functions

- `reverse_arr(array)` — Return a new sequence with the elements in reverse order.
- `sum_arr(array)` — Return the sum of numeric values in the array. Returns `ArrayTypeError` if non-numeric elements are present.
- `multiplication_arr(array)` — Return the product of numeric values in the array. Returns `ArrayTypeError` if non-numeric elements are present.
- `min(array)` — Return the smallest numeric value from a one-dimensional sequence. Raises `ArrayTypeError` for non-numeric elements.
- `max(array)` — Return the largest numeric value from a one-dimensional sequence. Raises `ArrayTypeError` for non-numeric elements.
- `arifmetic_mean(array)` — Return the arithmetic mean of numeric values in the array.
- `sort(array)` — Sort the array in-place and return the sorted array.
- `same(array1, array2)` — Return common elements between two arrays.
- `step_filter(array, step, first_num=0)` — Return sliced array with the given step.
- `type_filter(array, type_filt)` — Return elements matching the specified type.
- `range_arr(array, first, last)` — Return numeric elements inside the inclusive range `[first, last]`.
- `range_other(array, first, last)` — Return numeric elements outside the inclusive range `[first, last]`.
- `chunk(array, size)` — Split the array into consecutive chunks of size `size`.
- `mv(array, i1, i2)` — Move an element from index `i1` to `i2` in-place.
- `hw_times(array, key)` — Count occurrences of `key` in the array.
- `not_same(array, array2)` — Return elements that are not common between the two arrays.
- `section(array, part)` — Split the array into consecutive sections of length `part`.

### Nested Array Functions

- `leafs(array)` — Return a flat list containing all integer leaf values from a nested array structure.
- `num_of_leafs(array)` — Count integer leaf nodes recursively in a nested array structure.
- `len_arr(array)` — Count all scalar leaf values in a nested array structure. Supported scalar types include `int`, `str`, `float`, and `bool`.
- `equation_system(full_matrix)` — Solve a 2×2 or 3×3 system of linear equations supplied as an augmented matrix.

### Dictionary Functions

- `dict_max(d)` — Return the maximum value from dictionary values.
- `dict_min(d)` — Return the minimum value from dictionary values.
- `is_key_value_in_dict(d, key, value)` — Return `True` if the key-value pair exists in the dictionary.
- `key_sum(d)` — Return the sum of numeric dictionary keys.
- `key_multiplication(d)` — Return the product of numeric dictionary keys.
- `same_keys(d1, d2)` — Return a list of common keys between two dictionaries.
- `same_values(d1, d2)` — Return a list of common values between two dictionaries.
- `value_sum(d)` — Return the sum of numeric dictionary values.
- `value_multiplication(d)` — Return the product of numeric dictionary values.

## Running the included checks

The repository includes a simple assertion-based test file.

```bash
python tests/test.py
```

## Project structure

- `setup.py` — package metadata and build configuration
- `README.md` — project documentation
- `src/pyarrlib/__init__.py` — package initialization
- `src/pyarrlib/sync_arrpy.py` — synchronous array utility functions
- `src/pyarrlib/sync_multidim_arr.py` — synchronous nested array traversal functions
- `src/pyarrlib/sync_dict.py` — synchronous dictionary utility functions
- `src/pyarrlib/sync__checks.py` — validation helpers and exception classes
- `src/pyarrlib/async_arrpy.py` — asynchronous array utility functions
- `src/pyarrlib/async_multidim_arr.py` — asynchronous nested array traversal functions
- `src/pyarrlib/async_dict.py` — asynchronous dictionary utility functions
- `src/pyarrlib/async__checks.py` — asynchronous validation helpers and exception classes
- `tests/test.py` — example assertions covering core behavior

## License

This project is licensed under MIT.
