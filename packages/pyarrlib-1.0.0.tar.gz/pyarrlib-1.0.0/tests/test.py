import sys
import os


src_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src'))
if src_path not in sys.path:
    sys.path.insert(0, src_path)


from pyarrlib.sync_multidim_arr import *
from pyarrlib.sync_dict import *
from pyarrlib.sync_arrpy import *
from pyarrlib.sync__checks import *
# from ..src.pyarrlib.sync.arrpy import *

# multidim_arr
assert num_of_leafs([[[[2]], [4, [5, 6, [6], 6, 6, 6], 7]], [2, 4, 5, 6, 6, 6,  6, 6, 7]]) == 18        
assert num_of_leafs([[1, 2, 3], [1, 2, 3]]) == 6
assert len_arr([[1, 2, 3], [1, 2, 3]]) == 6
assert len_arr([[[12], [32, 54, [3], 5], 63, 6], [54, [43, 54, 65, 43, [1, 54, 6], 54], 64]])
assert leafs([1, [1, 3, [4, 3], 4]]) == [1, 1, 3, 4, 3, 4]
assert equation_system([[1, 1, 2], [1, -1, 0]]) == [1, 1]



# arrpy
assert reverse_arr([1, "hello", 3, True]) == [True, 3, "hello", 1]
assert sum_arr([1, 5, 4, 3, 8]) == 21
assert sum_arr(['int', 43, True]) == ArrayTypeError
assert multiplication_arr([4, 1, 2, 5, 7]) == 280
assert multiplication_arr(['int', 43, True]) == ArrayTypeError
assert min([1, 3, 6, -3, 2]) == -3
assert max([1, 5, 3, -5, 4, 10]) == 10
assert arifmetic_mean([4, 3, 2]) == 3
# assert sort([1, 5, 3, False]) == [False, 1, 3, 5]
assert same([1, 4, 3, ], [5, 6, 3, 1]) == [1, 3]
assert step_filter([1, 4, 3, 5, 4, 2], 3) == [1, 5]

assert type_filter([1, 4, 3, 'int', True, 2, ['some']], int) == [1, 4, 3, 2]
assert range_arr([1, 4, 6, 32, 54, 3, 5, 9], 4, 99) == [4, 6, 32, 54, 5, 9]
assert range_other([1, 4, 6, 32, 54, 3, 5, 9], 4, 99) == [1, 4, 3]
assert chunk([1, 4, 54, 43, 53, 65, 66, 54, 445], 3) == [[1, 4, 54], [43, 53, 65], [66, 54, 445]]
assert hw_times([1, 4, 3, 3, 5, 4, 3, 6, 3], 3) == 4
assert not_same([1, 4, 3], [5, 6, 3, 1]) == [4, 5, 6]




# dict
assert dict_max({
    1: 5,
    4: 55,
    321: 41
}) == 321
assert dict_max({
    1: 5,
    4: 55,
    123: 321
}) == 321
assert dict_min({
    1: 5,
    4: 55,
    123: 321
}) == 1
assert dict_min({
    11: 5,
    42: 55,
    123: 321
}) == 5
assert is_key_value_in_dict({
    'some': 'any',
    'dict': 'some'
}, 'some', 'any') == True
assert key_sum({
    1: '123',
    34: True,
    21: 12.54,
}) == 56
assert key_multiplication({
    1: '123',
    34: True,
    21: 12.54,
}) == 714
assert same_keys({
   1: '123',
    'else': True,
    'hello': [1, 43, 2],
}, {
    1: '43',
    'hello': '23',
    'x3d': 12,  
}) == [1, 'hello']
assert same_values({
    1: '123',
    'else': True,
    'hello': [1, 43, 2],
}, {
    1: '123',
    'hello': True,
    'x3d': 12,  
}) == ['123', True]