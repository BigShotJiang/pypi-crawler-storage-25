"""
Quantum Engine — backward-compatibility shim.

New code should import from :mod:`qndb.core.engine` instead.
"""

from qndb.core.engine.backends import BackendBase, SimulatorBackend, CloudBackend  # noqa: F401
from qndb.core.engine.noise import NoiseConfig                                     # noqa: F401
from qndb.core.engine.quantum_engine import QuantumEngine                          # noqa: F401

# Hardware integration
from qndb.core.engine.hardware import (                                             # noqa: F401
    HARDWARE_ENABLED, IBM_ENABLED, GOOGLE_ENABLED, IONQ_ENABLED, BRAKET_ENABLED,
    BackendCapabilities, BackendRegistry, HardwareBackendBase,
    IBMBackend, GoogleBackend, IonQBackend, BraketBackend,
    HardwareCompiler, TopologyMapper, GateDecomposer, CalibrationData,
    HybridExecutor, WorkloadPartitioner, CircuitKnitter, ErrorBudgetManager,
    CalibrationMonitor, ErrorMitigator, HardwareNoiseModel,
    FidelityScorer, CircuitRetryManager,
)

__all__ = [
    "BackendBase", "SimulatorBackend", "CloudBackend",
    "NoiseConfig", "QuantumEngine",
    # Hardware integration
    "HARDWARE_ENABLED", "IBM_ENABLED", "GOOGLE_ENABLED",
    "IONQ_ENABLED", "BRAKET_ENABLED",
    "BackendCapabilities", "BackendRegistry", "HardwareBackendBase",
    "IBMBackend", "GoogleBackend", "IonQBackend", "BraketBackend",
    "HardwareCompiler", "TopologyMapper", "GateDecomposer", "CalibrationData",
    "HybridExecutor", "WorkloadPartitioner", "CircuitKnitter", "ErrorBudgetManager",
    "CalibrationMonitor", "ErrorMitigator", "HardwareNoiseModel",
    "FidelityScorer", "CircuitRetryManager",
]
