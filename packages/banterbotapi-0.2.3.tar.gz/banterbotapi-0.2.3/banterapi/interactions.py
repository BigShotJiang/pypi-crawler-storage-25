"""Slash-command interaction context.

When a user invokes a slash command, the server emits an
``interaction_create`` gateway event to the owning bot. The SDK wraps
the payload in an :class:`Interaction` and dispatches it to the
registered ``@bot.slash_command`` handler.

Unlike prefix commands (which deliver a :class:`~banterapi.Message`
via ``on_message``), slash commands deliver an :class:`Interaction`
with pre-parsed, typed options and a response-correlation token.

Handler usage::

    @bot.slash_command(
        name="roll",
        description="Roll an N-sided die",
        options=[SlashOption("sides", type=OPTION_INTEGER, required=False)],
    )
    async def roll(interaction):
        sides = interaction.options.get("sides", 6)
        await interaction.respond(f"🎲 {sides}-sided die")

Responding to an interaction:

* :meth:`Interaction.respond` — send the visible reply. The invocation
  stays on screen as a header; this message lands below.
* :meth:`Interaction.defer` — acknowledge that a response is coming
  "soon" (within the interaction timeout, typically 15 minutes). Use
  before long-running work so the UI can show a thinking state.
* :meth:`Interaction.followup` — send additional messages after the
  initial response. Can be called multiple times.

The ``ephemeral`` flag makes a response visible only to the invoker.
Follows Discord's semantics: ephemeral messages are dropped by
clients that aren't the invoker, even though they transit the same
gateway for everyone else.
"""


class Interaction:
    """One slash-command invocation delivered to the bot.

    Constructed by :class:`~banterapi.Bot._dispatch` when an
    ``interaction_create`` event arrives. Do not instantiate manually.

    Attributes:
        id: Server-assigned interaction ID. Used to correlate the
            bot's response back to this invocation.
        token: Short-lived bearer token the server issued for this
            interaction. Included on every follow-up call.
        command_name: The slash command's registered name (without
            the leading ``/``).
        options: Dict of ``{option_name: parsed_value}``. Values are
            typed per the option's declared type:
              - string → str
              - integer → int
              - boolean → bool
              - user, channel, role → the target ID as str
        guild_id: Guild the interaction was invoked in, or ``""`` for
            a DM.
        channel_id: Channel ID it was invoked in.
        user_id: Invoking user's ID.
        _client: The :class:`Bot` that owns this interaction, kept for
            routing responses. Never serialized.
    """

    __slots__ = (
        "id", "token", "command_name", "options",
        "guild_id", "channel_id", "user_id", "_client", "_responded",
    )

    def __init__(self, payload, client=None):
        self.id = payload.get("id", "")
        self.token = payload.get("token", "")
        self.command_name = payload.get("command_name", "")
        self.options = payload.get("options", {}) or {}
        self.guild_id = payload.get("guild_id", "")
        self.channel_id = payload.get("channel_id", "")
        self.user_id = payload.get("user_id", "")
        self._client = client
        # Track whether we've sent the first response. Subsequent calls
        # must go through followup() since the server distinguishes
        # "initial response" from "follow-up" on the wire.
        self._responded = False

    async def respond(self, content="", *, embed=None, ephemeral=False):
        """Send the visible reply to the invocation.

        May only be called once per interaction. After this,
        additional messages must go through :meth:`followup`.

        Args:
            content: Message text.
            embed: Optional :class:`~banterapi.Embed`.
            ephemeral: If True, only the invoking user sees this
                message. Defaults to False (public).

        Raises:
            RuntimeError: If called more than once on the same
                interaction — use :meth:`followup` for subsequent
                messages.
        """
        if self._responded:
            raise RuntimeError(
                "respond() was already called on this interaction. "
                "Use interaction.followup(...) for additional messages."
            )
        if self._client is None:
            raise RuntimeError("Interaction has no attached client.")
        body = {
            "kind": "reply",
            "content": content,
            "ephemeral": bool(ephemeral),
        }
        if embed is not None:
            body["embed"] = embed.to_dict() if hasattr(embed, "to_dict") else embed
        await self._client._http.respond_interaction(self.id, self.token, body)
        self._responded = True

    async def defer(self, *, ephemeral=False):
        """Acknowledge the interaction without replying yet.

        Shows a thinking indicator in the client until :meth:`respond`
        or :meth:`followup` lands. Use for handlers that may exceed
        the client's immediate-response timeout (~3s). The ephemeral
        flag here determines whether the eventual response will be
        ephemeral too.
        """
        if self._responded:
            raise RuntimeError("interaction already responded to")
        if self._client is None:
            raise RuntimeError("Interaction has no attached client.")
        await self._client._http.respond_interaction(self.id, self.token, {
            "kind": "defer",
            "ephemeral": bool(ephemeral),
        })
        self._responded = True

    async def followup(self, content="", *, embed=None, ephemeral=False):
        """Send an additional message after the initial response.

        Callable repeatedly. Unlike :meth:`respond` there's no
        once-only limit — use for streaming progress updates, paginated
        results, or multi-part replies.
        """
        if self._client is None:
            raise RuntimeError("Interaction has no attached client.")
        body = {
            "kind": "followup",
            "content": content,
            "ephemeral": bool(ephemeral),
        }
        if embed is not None:
            body["embed"] = embed.to_dict() if hasattr(embed, "to_dict") else embed
        await self._client._http.respond_interaction(self.id, self.token, body)

    def __repr__(self):
        return (
            f"Interaction(id={self.id!r}, command={self.command_name!r}, "
            f"user={self.user_id!r}, channel={self.channel_id!r})"
        )