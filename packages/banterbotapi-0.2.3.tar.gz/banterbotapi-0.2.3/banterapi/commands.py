"""Command registration, argument parsing, and invocation.

The command system mirrors discord.py's ``commands.Bot`` surface:

* :meth:`~banterapi.Bot.command` decorator produces a :class:`Command`
  wrapping the user's coroutine.
* :class:`CommandRegistry` is a name+alias → :class:`Command` lookup;
  aliases point to the same :class:`Command` object.
* When a message arrives, :meth:`~banterapi.Bot.process_commands`
  splits it on whitespace, looks up the command, constructs a
  :class:`Context`, and invokes.
* Argument conversion is driven by parameter annotations on the
  decorated function — ``int``, ``float``, ``bool``, and ``str`` are
  supported out of the box. ``*args`` collects remaining tokens;
  a keyword-only ``*, text: str`` parameter captures the rest of the
  message verbatim (no further splitting — useful for multi-word
  content like ``!echo hello world``).

Exceptions all inherit from :class:`CommandError`, which itself is NOT
a :class:`~banterapi.errors.BanterError` — command errors are
user-input problems, not SDK problems, and should be caught by an
``on_command_error`` handler rather than by broad SDK except blocks.
"""

import inspect
import shlex

from .errors import MissingPermissions
from .permissions import has_perm, describe


class CommandError(Exception):
    """Base class for command-invocation errors.

    Raised by the parser (:class:`MissingArgument`,
    :class:`BadArgument`) or by the caller's own code. The
    :class:`~banterapi.Bot` catches these during
    :meth:`~banterapi.Bot.process_commands` and fires an
    ``on_command_error`` event instead of letting them crash the
    dispatch loop.
    """


class CommandNotFound(CommandError):
    """The message invoked a command that isn't registered.

    Currently never raised by the SDK — unknown commands are silently
    ignored in :meth:`Bot.process_commands`. Exposed so user code can
    raise it from a custom prefix router.
    """


class MissingArgument(CommandError):
    """A required positional/keyword-only argument was omitted.

    Attributes:
        name: The parameter name that was missing.
    """

    def __init__(self, name):
        self.name = name
        super().__init__(f"missing required argument: {name}")


class BadArgument(CommandError):
    """An argument failed type conversion.

    Attributes:
        name: Parameter name.
        value: Raw string value the user supplied.
        expected: Human-readable description of what was expected
            (e.g. ``"integer"``, ``"yes/no"``, ``"number"``).
    """

    def __init__(self, name, value, expected):
        self.name = name
        self.value = value
        self.expected = expected
        super().__init__(f"argument {name!r} expected {expected}, got {value!r}")


# Accepted tokens for ``bool``-annotated arguments. Case-insensitive on
# input; comparison happens against the lower-cased user token. Kept as
# module-level constants so a bot that wants to localise (e.g. add
# "sí"/"no") can monkey-patch them before registering commands.
_BOOL_TRUE = {"true", "yes", "y", "1", "on", "enable"}
_BOOL_FALSE = {"false", "no", "n", "0", "off", "disable"}


def _convert(value, annotation, name):
    """Coerce a raw string argument to the type declared by its annotation.

    Supported annotations:

    * ``str`` or no annotation → returned as-is.
    * ``int`` → :func:`int`; raises :class:`BadArgument` on parse fail.
    * ``float`` → :func:`float`; raises :class:`BadArgument` on parse fail.
    * ``bool`` → matched against :data:`_BOOL_TRUE` / :data:`_BOOL_FALSE`
      (see module source for the accepted token lists).
    * Any other annotation → returned as-is; no conversion attempted.

    Args:
        value: The raw token from the user's message.
        annotation: The parameter's annotation (from
            :func:`inspect.signature`).
        name: Parameter name — used solely for the
            :class:`BadArgument` error message.

    Returns:
        The converted value.

    Raises:
        BadArgument: Conversion failed for int/float/bool.
    """
    if annotation is inspect.Parameter.empty or annotation is str:
        return value
    if annotation is int:
        try:
            return int(value)
        except ValueError:
            raise BadArgument(name, value, "integer")
    if annotation is float:
        try:
            return float(value)
        except ValueError:
            raise BadArgument(name, value, "number")
    if annotation is bool:
        v = value.lower()
        if v in _BOOL_TRUE:
            return True
        if v in _BOOL_FALSE:
            return False
        raise BadArgument(name, value, "yes/no")
    return value


class Context:
    """Per-invocation state passed to every command as its first argument.

    Constructed by :meth:`Bot.process_commands` (prefix commands) and
    by the interaction dispatcher (slash commands). Never instantiate
    directly.

    Attributes:
        bot: The :class:`~banterapi.Bot` instance.
        message: The :class:`~banterapi.models.Message` that triggered
            this invocation. For slash commands this is a synthetic
            message representing the interaction.
        invoked_with: The command name as typed (one of the command's
            aliases, if any). Useful for behaviour that branches on
            which alias was used.
        args_raw: The full argument string after the command name,
            before :class:`Command`'s argument parser splits it. Rarely
            needed — argument-annotated parameters are preferred.
        author: The invoking :class:`~banterapi.models.User`.
        author_perms: Int bitmask of the author's effective permissions
            in this channel. Pre-resolved by the server.
        channel: The :class:`~banterapi.models.Channel` this was sent
            in (may be a DM stub).
        channel_id: Convenience — same as ``channel.id``.
        guild_id: Guild ID this was sent in, or ``""`` for DMs.
    """

    def __init__(self, bot, message, invoked_with, args_raw):
        self.bot = bot
        self.message = message
        self.invoked_with = invoked_with
        self.args_raw = args_raw
        self.author = message.author
        self.author_perms = message.author_perms
        self.channel = message.channel
        self.channel_id = message.channel_id
        self.guild_id = message.guild_id

    def has_permissions(self, required):
        """Check if the invoker has all bits in ``required``.

        Args:
            required: Permission bitmask to check against
                :attr:`author_perms`. Administrator always satisfies
                the check regardless of the mask.

        Returns:
            bool: ``True`` if the author has every requested bit.
        """
        return has_perm(self.author_perms, required)

    async def send(self, content="", embed=None):
        """Send a new message in the channel this command was invoked in.

        Unlike :meth:`reply`, does not thread-link back to the invoking
        message. Prefer :meth:`reply` for direct command responses.
        """
        return await self.bot.send_message(self.channel_id, content=content, embed=embed)

    async def reply(self, content="", embed=None):
        """Send a message as a reply to the invoking message.

        Shorthand for ``ctx.message.reply(...)``. The reply-chain link
        is set server-side so clients render the "replying to" header.
        """
        return await self.message.reply(content=content, embed=embed)

    async def trigger_typing(self):
        """Show the typing indicator in this channel for the bot.

        Typing indicators auto-expire after ~10s server-side. Call
        repeatedly for long-running work.
        """
        await self.bot._http.trigger_typing(self.channel_id)


def has_permissions(*required):
    """Decorator: refuse to run the command if the invoker lacks perms.

    Stacks a required-permissions bitmask onto the decorated function.
    :meth:`Command.invoke` checks the caller's
    :attr:`Context.author_perms` against this mask before running the
    command body and raises :class:`~banterapi.errors.MissingPermissions`
    on failure. The :class:`Bot` routes that into ``on_command_error``.

    Multiple bits OR together; multiple decorators stack (all required):

        @bot.command(slash=True)
        @has_permissions(Permissions.KICK_MEMBERS)
        @has_permissions(Permissions.MANAGE_MESSAGES)
        async def kick_and_cleanup(ctx, target: str): ...

    The Administrator bit on the invoker bypasses this check (handled
    by :func:`~banterapi.permissions.has_perm`).
    """
    required_mask = 0
    for r in required:
        required_mask |= r
    def decorator(fn):
        existing = getattr(fn, "_required_perms", 0)
        fn._required_perms = existing | required_mask
        return fn
    return decorator


class Command:
    """Wrapper around a user's command coroutine.

    Stores the callback plus its parsed signature metadata (name,
    aliases, help text, and the parameters minus the leading ``ctx``).
    :meth:`CommandRegistry.add` installs instances under their name
    and every alias.

    Args:
        func: The user's async function. Must accept at least one
            parameter (``ctx``); additional parameters drive argument
            parsing.
        name: Registered command name. Defaults to ``func.__name__``.
        aliases: Iterable of alternate names. Stored as a tuple on the
            instance.
        help: Help-text override. Defaults to the first line of
            ``func.__doc__``.

    Raises:
        ValueError: The function has no ``ctx`` parameter.
    """

    def __init__(self, func, name=None, aliases=None, help=None):
        self.callback = func
        self.name = name or func.__name__
        self.aliases = tuple(aliases or ())
        self.help = help or (func.__doc__ or "").strip()
        sig = inspect.signature(func)
        params = list(sig.parameters.values())
        if not params:
            raise ValueError(f"command {self.name!r} must accept a context argument")
        self.params = params[1:]

    def _parse(self, ctx, args_raw):
        """Turn ``args_raw`` into ``(positional, kwargs)`` for the callback.

        Token-level rules:

        * Tokenisation uses :func:`shlex.split` — quoted strings group
          together (``"hello world"`` → one token). If shlex trips on
          unbalanced quotes we fall back to naive whitespace split.
        * Each normal parameter consumes one token; annotation-driven
          conversion is applied via :func:`_convert`.
        * ``*args`` (VAR_POSITIONAL) collects every remaining token,
          each converted using the VAR_POSITIONAL annotation. Scanning
          stops after this parameter.
        * A keyword-only parameter (``*, text: str``) captures the
          REMAINDER of the raw argument string verbatim, bypassing
          tokenisation — this is how multi-word content like
          ``!echo hello "world"`` reaches the callback unmodified.
        * Missing required arg → :class:`MissingArgument`.
        * Conversion failure → :class:`BadArgument` (from ``_convert``).

        Returns:
            tuple: ``(positional_list, kwargs_dict)`` ready for
            ``self.callback(ctx, *positional, **kwargs)``.
        """
        try:
            tokens = shlex.split(args_raw) if args_raw else []
        except ValueError:
            tokens = args_raw.split() if args_raw else []

        positional = []
        kwargs = {}
        i = 0
        for p in self.params:
            if p.kind is inspect.Parameter.VAR_POSITIONAL:
                remaining = tokens[i:]
                positional.extend(_convert(t, p.annotation, p.name) for t in remaining)
                i = len(tokens)
                break
            if p.kind is inspect.Parameter.KEYWORD_ONLY:
                # Consume the rest of the raw arg string verbatim —
                # deliberately bypasses tokenisation so quoted content,
                # emoji, and internal whitespace survive as typed.
                remaining = args_raw
                for _ in range(i):
                    remaining = remaining.split(maxsplit=1)[1] if " " in remaining else ""
                remaining = remaining.strip()
                if not remaining and p.default is inspect.Parameter.empty:
                    raise MissingArgument(p.name)
                kwargs[p.name] = remaining if remaining else p.default
                i = len(tokens)
                break
            if i >= len(tokens):
                if p.default is inspect.Parameter.empty:
                    raise MissingArgument(p.name)
                positional.append(p.default)
            else:
                positional.append(_convert(tokens[i], p.annotation, p.name))
                i += 1
        return positional, kwargs

    @property
    def required_perms(self):
        """Combined permission bitmask from stacked :func:`has_permissions`.

        Zero when the command is not decorated with
        :func:`has_permissions`. Set by the decorator as
        ``callback._required_perms``.
        """
        return getattr(self.callback, "_required_perms", 0)

    async def invoke(self, ctx):
        """Run the permission check, parse args, and call the callback.

        Raises:
            MissingPermissions: Invoker's :attr:`Context.author_perms`
                does not include every bit in :attr:`required_perms`.
            MissingArgument: Parser ran short on required args.
            BadArgument: A typed conversion failed.

        Any exception raised inside the callback propagates unchanged —
        :meth:`Bot.process_commands` catches it and fires
        ``on_command_error``.
        """
        req = self.required_perms
        if req and not has_perm(ctx.author_perms, req):
            missing_bits = req & ~ctx.author_perms
            raise MissingPermissions(describe(missing_bits))
        positional, kwargs = self._parse(ctx, ctx.args_raw)
        result = self.callback(ctx, *positional, **kwargs)
        if inspect.isawaitable(result):
            await result


class CommandRegistry:
    """Name-and-alias → :class:`Command` lookup used by :class:`Bot`.

    Aliases share the same :class:`Command` instance as their canonical
    name, so a registry of 5 commands with 10 aliases between them has
    15 entries all pointing at 5 distinct objects.
    """

    def __init__(self):
        self._commands = {}

    def add(self, command):
        """Register ``command`` under its name and every alias.

        Re-registering under an existing name overwrites the previous
        entry silently — that's deliberate, so a user reloading their
        module during development doesn't hit a duplicate-command
        error.
        """
        self._commands[command.name] = command
        for alias in command.aliases:
            self._commands[alias] = command

    def get(self, name):
        """Look up a command by name or alias. Returns ``None`` if absent."""
        return self._commands.get(name)

    def all(self):
        """Return every distinct registered :class:`Command`, deduped.

        A command registered under ``name="ping"`` with
        ``aliases=["p"]`` appears exactly once in the output, not twice.
        Used by the default help command so aliases don't show up as
        independent entries.
        """
        seen = set()
        out = []
        for cmd in self._commands.values():
            if cmd.name in seen:
                continue
            seen.add(cmd.name)
            out.append(cmd)
        return out


# -----------------------------------------------------------------
# Slash command option metadata
# -----------------------------------------------------------------

# Option type constants. Match the wire strings the server stores in
# the `options` JSON column for each registered command. Keep these
# as strings (not enums) so the JSON payload stays human-readable.
OPTION_STRING = "string"
OPTION_INTEGER = "integer"
OPTION_BOOLEAN = "boolean"
OPTION_USER = "user"
OPTION_CHANNEL = "channel"
OPTION_ROLE = "role"

_VALID_OPTION_TYPES = {
    OPTION_STRING, OPTION_INTEGER, OPTION_BOOLEAN,
    OPTION_USER, OPTION_CHANNEL, OPTION_ROLE,
}


class SlashOption:
    """One named argument to a slash command.

    Registered as part of a slash command's options list. The server
    stores the metadata so the client can render appropriate input
    widgets (text box, number input, user picker, channel picker).
    On invocation, option values are parsed server-side into the
    declared type and delivered to the bot as typed fields on the
    :class:`Interaction` context.

    Attributes:
        name: Option identifier (a-z, 0-9, underscore). Used both in
            the UI and as the key in ``interaction.options[name]``.
        type: One of the ``OPTION_*`` constants — string, integer,
            boolean, user, channel, role.
        description: Human-readable prompt shown under the option.
        required: If True, the invocation UI blocks submission until
            the value is set. Defaults to True — explicit optionals
            are clearer than defaults-by-omission.
        choices: Optional list of fixed choices. Each is either a
            plain scalar (``["low", "medium", "high"]``) or a dict
            ``{"name": "Medium", "value": "medium"}``. Frontend
            renders as a dropdown when present.

    Example::

        @bot.slash_command(
            name="kick",
            description="Kick a member",
            options=[
                SlashOption("user", type=OPTION_USER, description="Who to kick"),
                SlashOption("reason", type=OPTION_STRING, description="Why", required=False),
            ],
        )
        async def kick(interaction):
            target = interaction.options["user"]   # user ID (str)
            reason = interaction.options.get("reason", "")
            ...
    """

    __slots__ = ("name", "type", "description", "required", "choices")

    def __init__(self, name, *, type=OPTION_STRING, description="", required=True, choices=None):
        if type not in _VALID_OPTION_TYPES:
            raise ValueError(
                f"SlashOption {name!r}: unknown type {type!r}. "
                f"Use one of: {', '.join(sorted(_VALID_OPTION_TYPES))}"
            )
        self.name = name
        self.type = type
        self.description = description
        self.required = bool(required)
        self.choices = list(choices) if choices else None

    def to_dict(self):
        """Serialize to the JSON shape the server stores and the
        frontend consumes. Omits ``choices`` when unset to keep the
        payload compact."""
        d = {
            "name": self.name,
            "type": self.type,
            "description": self.description,
            "required": self.required,
        }
        if self.choices is not None:
            # Allow bare scalars or {name, value} dicts — normalize to
            # dicts so the frontend doesn't have to branch.
            normalized = []
            for c in self.choices:
                if isinstance(c, dict) and "value" in c:
                    normalized.append({"name": str(c.get("name", c["value"])), "value": c["value"]})
                else:
                    normalized.append({"name": str(c), "value": c})
            d["choices"] = normalized
        return d

    def __repr__(self):
        req = "required" if self.required else "optional"
        return f"SlashOption({self.name!r}, type={self.type!r}, {req})"

        