# 🔍 GitPutra

<p align="center">
  <img src="https://i.ibb.co/s9VWC1qL/image.png" alt="GitPutra Logo" width="200"/>
</p>

<p align="center">
  <img src="https://img.shields.io/pypi/v/gitputra?color=blue&label=PyPI&logo=pypi&logoColor=white" alt="PyPI Version">
  <img src="https://img.shields.io/pypi/pyversions/gitputra?color=blue&logo=python&logoColor=white" alt="Python Versions">
  <img src="https://static.pepy.tech/badge/gitputra" alt="Downloads">
  <img src="https://img.shields.io/pypi/l/gitputra?color=yellow" alt="License">
  <img src="https://img.shields.io/badge/AI-Gemini%20%7C%20OpenAI-blueviolet?logo=openai&logoColor=white" alt="AI Providers">
</p>

<p align="center">
  <b>◈ Analyze ◈ Visualize ◈ Synthesize ◈</b><br>
  Clone any repo, generate a structured analysis report, visualize architecture, and chat with your codebase — all from the terminal.
  Turn any online Repository or local codebase into AI memory
</p>

---

## ✨ Features

- 🔍 **See Beyond the Code** — Turn any repository into a fully mapped system — architecture, patterns, flaws, and opportunities laid bare.

- 🧠 **Export the Brain of Your Project** — Switched AI tools? No need to re-explain your entire codebase. Export the full project context — with a function inventory, module dependency graph, and function-level call graph — into a single Markdown file, ready to paste into any AI chat.

- 💬 **Talk to Your Codebase** — Ask anything. Get answers grounded in context, not guesses, powered by RAG and semantic search.

- 🤖 **Choose Your Intelligence** — Switch effortlessly between Google Gemini & OpenAI.

- 📊 **Watch Structure Come Alive** — Transform raw code into interactive HTML graphs (full call graph, cross-module graph, module dependency graph) powered by pyvis, plus Mermaid diagrams in multiple types (architecture, sequence, class, flowchart) — all saved to your `output/` folder.

- 📄 **Reports That Speak Your Language** — Export analysis as a styled PDF in ~110 languages.

- 🌐 **Context Export without Internet** — No API key required for a full context export. The functionality graph, call map, and file tree are built entirely offline using Tree-sitter AST parsing.

- 🌿 **Every Branch Has a Story** — Analyze or chat with any specific branch of a repo.

- 🗂️ **Memory That Doesn't Waste Time** — Skips re-embedding if a repo is already indexed; run `clear-db` to reset.

- 📁 **Understands Almost Every File Type** — From Python to Rust, configs to notebooks — your entire stack, decoded (50+ file types supported).

- 🗃️ **Chat Memory That Remembers What You Said** — Conversations don't reset into oblivion. Context is preserved across interactions, allowing deeper, more coherent discussions with your codebase over time.



---

## 📦 Installation

```bash
pip install gitputra
```

Requires Python 3.10+

---

## 🗺️ Show all commands, supported AIs, languages, and file extensions
```bash
gitputra info
```

---

## 🚀 Usage & Examples

### Analyze a Repository

```bash
# Remote repo
gitputra analyze https://github.com/user/repo --ai gemini --key YOUR_API_KEY

# API key stored in .env or entered at prompt
gitputra analyze https://github.com/user/repo --ai gemini

# Local codebase (no cloning)
gitputra analyze ./my-project --local --ai gemini --key YOUR_API_KEY
gitputra analyze "C:\path\with spaces\project" --local --ai gemini --key YOUR_API_KEY

# Local codebase — API key stored in .env or entered at prompt
gitputra analyze ./my-project --local --ai gemini
```

With options:

```bash
# Use OpenAI, output in Bangla, skip diagram
gitputra analyze https://github.com/user/repo --ai openai --key YOUR_KEY --lang Bangla --no-diagram

# Analyze a specific branch
gitputra analyze https://github.com/user/repo --branch dev --ai gemini --key YOUR_API_KEY

# Skip PDF generation
gitputra analyze https://github.com/user/repo --ai gemini --key YOUR_API_KEY --no-pdf

# API key stored in .env or entered at prompt
gitputra analyze https://github.com/user/repo --branch dev --ai gemini
```

Outputs saved to `./output/`:
- `report.pdf` — Full analysis report
- `diagram_full.html` — Interactive full call graph (every intra-project function call)
- `diagram_crossmodule.html` — Interactive cross-module call graph (only edges that cross module boundaries)
- `diagram_modules.html` — Interactive module dependency graph (one node per file, edge weight = call count)
- `mermaid_<type>.txt` — Mermaid diagram source (graph, flowchart, flowchart LR, architecture, sequence, class)

---

### Chat with a Repository

```bash
# Remote repo
gitputra chat https://github.com/user/repo --ai gemini --key YOUR_API_KEY

# API key stored in .env or entered at prompt
gitputra chat https://github.com/user/repo --ai gemini

# Local codebase
gitputra chat ./my-project --local --ai gemini --key YOUR_API_KEY

# Local codebase — API key stored in .env or entered at prompt
gitputra chat ./my-project --local --ai gemini
```

```
💬 Chat mode [repo] — ask anything about the repo. Type 'exit' to quit.

>>  What does the main.py file do?
>>  How is authentication handled?
>>  exit
```

> If `analyze` was already run on the repo, `chat` reuses the existing index automatically.

```bash
# Chat with a specific branch
gitputra chat https://github.com/user/repo --branch feature/my-branch --ai gemini --key YOUR_API_KEY

# If API key is stored in .env
gitputra chat https://github.com/user/repo --branch feature/my-branch --ai gemini
```

> If `--branch` is not specified, the repo's default branch is used.

---

### Export Codebase Context

Export your entire codebase as a single Markdown file you can paste into any AI tool (ChatGPT, Gemini, Claude…) to continue work without re-explaining the project.

The export includes:
- **File tree** of the project
- **Tech stack detection** (languages, infra, package files)
- **Function inventory** — all functions extracted per module
- **Module dependency graph** — Mermaid + plain-text fallback
- **Function-level call graph** — cross-module calls, Mermaid + full call map
- **Per-file summaries** — AI-generated (with `--use-ai`) or function-list stats (offline)
- **Source snapshot** — truncated source for each file

```bash
# Local codebase — fast, no API key needed (no AI summaries)
gitputra export-context ./my-project
gitputra export-context "location"

# With AI summaries (requires --use-ai and an API key)
gitputra export-context ./my-project --use-ai --ai gemini --key YOUR_API_KEY

# If API key is stored in .env
gitputra export-context "location" --use-ai --ai gemini

# Remote GitHub repo
gitputra export-context https://github.com/user/repo --remote --ai gemini --key YOUR_API_KEY

# Remote repo — API key stored in .env or entered at prompt
gitputra export-context https://github.com/user/repo --remote --ai gemini

# Remote repo, specific branch, with AI summaries
gitputra export-context https://github.com/user/repo --remote --branch dev --use-ai --ai gemini --key YOUR_API_KEY

# If API key is stored in .env
gitputra export-context https://github.com/user/repo --remote --branch dev --use-ai --ai gemini

# Scan current directory
gitputra export-context

# Path with spaces — wrap in quotes
gitputra export-context "C:\Users\you\My Project"
```

Output saved to `./output/context_<project_name>_<timestamp>.md`

**How to use the exported file:**
1. Open the `.md` file
2. Paste it into any AI chat (ChatGPT, Gemini, Claude…)
3. Say: *"Here is my codebase context. Read it and help me continue."*

---

### Other Commands

```bash
# Wipe the local ChromaDB index
gitputra clear-db

# Check version
gitputra --version
```

---

## 🤖 AI Providers

| Flag | Provider | Text Model | Embedding Model |
|------|----------|------------|-----------------|
| `--ai gemini` | Google Gemini | gemini-2.5-flash | gemini-embedding-001 |
| `--ai openai` | OpenAI | gpt-4o-mini | text-embedding-3-large |

### Setting up your API Key

**Option 1 — `.env` file (recommended):**

```env
API_KEY=your_api_key_here
```

**Option 2 — Secure Interactive Prompt**

If no key is provided, GitPutra will securely prompt you at runtime — keeping your key out of shell history and config files.

**Option 3 — CLI flag:**

```bash
gitputra analyze https://github.com/user/repo --key YOUR_API_KEY
```

> Avoid Option 3 in shared environments — CLI flags appear in shell history.

---

## 🧬 Call Graph Extraction (Tree-sitter AST)

The functionality graph and context export use a shared `call_extractor` module powered by **Tree-sitter** for precise AST-based extraction — no regex guessing for supported languages.

| Method | Languages |
|--------|-----------|
| Tree-sitter (AST) | Python, JavaScript, TypeScript, JSX, TSX, C, C++ (`.cc`, `.cxx`), Go, Rust, Java |
| Regex fallback | Ruby, PHP, Swift, Kotlin, Scala, Lua, C#, Groovy, Perl, Shell/Bash |

For Python specifically, the stdlib `ast` module is used for maximum accuracy, with Tree-sitter as a fallback on syntax errors.

---

## 🌍 Supported Languages (PDF Output)

GitPutra can generate PDF reports in ~110 languages across 3 scripts:

### Latin Script (~100 languages)
English, French, Spanish, Portuguese, Italian, German, Dutch, Swedish, Norwegian, Danish, Finnish, Polish, Czech, Slovak, Hungarian, Romanian, Croatian, Serbian (Latin), Slovenian, Albanian, Lithuanian, Latvian, Estonian, Turkish, Azerbaijani, Uzbek, Kazakh (Latin), Turkmen, Indonesian, Malay, Filipino, Swahili, Zulu, Xhosa, Afrikaans, Yoruba, Igbo, Hausa, Somali, Kinyarwanda, Welsh, Irish, Basque, Catalan, Galician, Maltese, Icelandic, Faroese, Vietnamese, Hawaiian, Maori, Tok Pisin, Tswana, Shona, Sesotho, and more.

### Bangla Script
Bangla, Assamese

### Devanagari Script
Hindi, Marathi, Nepali, Sanskrit, Maithili, Konkani, Bodo, Dogri

> The AI response language depends on the chosen model's capability. Use `--lang` to set the output language.

```bash
gitputra analyze https://github.com/user/repo --ai gemini --key KEY --lang Bangla

# API key stored in .env or entered at prompt
gitputra analyze https://github.com/user/repo --ai gemini --lang Bangla
```

---

## 📁 Supported File Extensions (50+ types)

| Category | Extensions |
|----------|-----------|
| Python | `.py`, `.ipynb` |
| C/C++ | `.c`, `.h`, `.cpp` |
| Web | `.js`, `.ts`, `.jsx`, `.tsx`, `.html`, `.css`, `.vue` |
| JVM | `.java`, `.kt`, `.kts`, `.scala`, `.groovy`, `.clj`, `.cljs` |
| Systems | `.go`, `.rs`, `.swift`, `.dart` |
| Scripting | `.sh`, `.bat`, `.ps1`, `.pl`, `.lua`, `.r`, `.m`, `.rb`, `.php`, `.coffee`, `.elm` |
| Config | `.json`, `.yaml`, `.yml`, `.xml`, `.toml`, `.ini`, `.cfg`, `.conf`, `.gradle`, `.makefile` |
| Docs | `.md`, `.txt`, `.log`, `.sql`, `.pdf` |
| Special | `Dockerfile`, `Makefile` |

---

## 👨‍💻 Author

**Adityava Gangopadhyay**

- 📧 Email: adityava49cse@gmail.com
- 🔗 LinkedIn: [adityava-gangopadhyay](https://www.linkedin.com/in/adityava-gangopadhyay)
- 📦 PyPI: [pypi.org/project/gitputra](https://pypi.org/project/gitputra/)

Feel free to reach out for any suggestions or issues!

---

AI is ARTIFICIALLY Intelligent, YOU are NATURALLY WISE — use the tool but keep track on the correctness of the results produced.

THANK YOU

## 📄 License

MIT License — free to use, modify, and distribute.