import os
import uuid
import time
import re
import ast

from git import Repo
import chromadb
import math

from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, HRFlowable
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# AI SDKs
from openai import OpenAI
import google.generativeai as genai
from rich.spinner import Spinner
from .call_extractor import extract_calls as _ts_extract_calls

from rich.text import Text
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.align import Align
from rich.columns import Columns
from rich.prompt import Prompt
import threading
import warnings
from . import animations
warnings.filterwarnings("ignore", message=".*tight_layout.*")


console = Console()

wait_texts = ["It may take a while...", "Thanks for your patience...", "Just few moments more...", "Appreciate your patience..."]



def _animated_panel(live: Live, batch_num: int, total: int, stop_event: threading.Event, mode: str = "analyze"):
    """
    Runs in a thread until stop_event is set.
    mode='analyze'    → shockwave animation
    mode='synthesize' → convergence animation
    """

    t = 0
    while not stop_event.is_set():
        pixels = animations._shockwave_frame(t) if mode == "analyze" else animations._synthesis_frame(t)

        frame_text = Text(justify="center")
        for ch, color in pixels:
            if ch == '\n':
                frame_text.append('\n')
            else:
                frame_text.append(ch, style=color)

        progress_filled = int((batch_num - 1 + 0.5) / total * 30)
        progress_bar = "█" * progress_filled + "░" * (30 - progress_filled)
        percent = int((batch_num - 1 + 0.5) / total * 100)

        phase = int(time.time() * 6) % 6
        dots = ["", ".", "..", "...", "..", "."][phase]

        if mode == "analyze":
            status = f"  analyzing codebase{dots}"
            title  = "[bold magenta]◈ GitPutra ◈[/bold magenta]"
            border = "bold blue"
            header = f"\n  batch {batch_num}/{total}\n\n"
            header_style = "bold cyan"
        else:
            status = f"  synthesizing final report{dots}"
            title  = "[bold magenta]◈ GitPutra ◈[/bold magenta]"
            border = "bold cyan"
            header = f"\n  synthesizing {batch_num} batch summaries\n\n"
            header_style = "bold green"

        caption = Text(justify="center")
        caption.append(header, style=header_style)
        caption.append_text(frame_text)
        caption.append(f"\n\n  [{progress_bar}] {percent}%", style="dim")
        caption.append(f"\n  {status}\n", style="dim italic")

        live.update(Align(Panel(
            caption,
            title=title,
            border_style=border,
            padding=(1, 4),
            expand=False,
        ), align="center"))

        t += 1
        time.sleep(0.055)

# ─────────────────────────────────────────────
# SCAN ANIMATION — RADAR PING
# ─────────────────────────────────────────────
_SC_W = 38
_SC_H = 9
_SC_CHARS = [' ', '·', '░', '▒', '▓', '█']

def _scan_frame(t: int) -> list[tuple[str, str]]:
    """
    Radar ping expanding outward from center.
    Returns list of (char, hex_color) tuples, newlines included.
    """
    cx, cy = _SC_W / 2, _SC_H / 2
    result = []

    # blip positions — fixed "found files" that light up after ping passes
    blips = [(6,2),(31,1),(10,7),(28,6),(18,4),(5,6),(33,3),(14,1),(25,7),(8,4)]

    for row in range(_SC_H):
        for col in range(_SC_W):
            dx = (col - cx) / (_SC_W / 2)
            dy = (row - cy) / (_SC_H / 2) * 2.2
            dist = math.sqrt(dx * dx + dy * dy)

            # expanding ring — resets every 40 ticks
            ring_r = (t * 0.055) % 2.2
            delta = abs(dist - ring_r)
            ring = math.exp(-delta * delta * 18) * 0.9

            # blip glow — lights up after ring passes, fades slowly
            blip_v = 0.0
            for bx, by in blips:
                bdx = (col - bx) / 2.0
                bdy = (row - by) / 1.2
                bdist = math.sqrt(bdx*bdx + bdy*bdy)
                if bdist < 1.2:
                    # how long ago did the ring pass this blip
                    bpx = (bx - cx) / (_SC_W / 2)
                    bpy = (by - cy) / (_SC_H / 2) * 2.2
                    bp_dist = math.sqrt(bpx*bpx + bpy*bpy)
                    ring_age = (ring_r - bp_dist) % 2.2
                    if 0 < ring_age < 1.4:
                        fade = math.exp(-ring_age * 1.8) * (1 - bdist / 1.2)
                        blip_v = max(blip_v, fade)

            v = max(0.0, min(1.0, ring + blip_v))

            # color: green radar tones
            gv = int(max(0, min(1, v)) * 220 + 35)
            rv = int(max(0, min(1, v * 0.3)) * 80)
            bv = int(max(0, min(1, v * 0.2)) * 60)
            color = f"#{rv:02x}{gv:02x}{bv:02x}"

            char = _SC_CHARS[int(v * (len(_SC_CHARS) - 1))]
            result.append((char, color))

        if row < _SC_H - 1:
            result.append(('\n', '#ffffff'))

    return result

# ─────────────────────────────────────────────
# GLOBALS
# ─────────────────────────────────────────────
_ai_config     = {}
_openai_client = None
_language      = "English"
_ai_disabled   = False

CHROMA_CLIENT = chromadb.PersistentClient(path="./chroma_db")

SUPPORTED_EXT = (
    ".py", ".c", ".h", ".cpp", ".js", ".ts", ".md", ".pdf", ".txt",
    ".java", ".go", ".rs", ".php", ".rb", ".swift",
    ".cs", ".html", ".css", ".json", ".yaml", ".yml", ".xml",
    ".sh", ".bat", ".ps1", ".gradle", ".makefile",
    ".ini", ".cfg", ".conf", ".log", ".sql", ".ipynb",
    ".vue", ".jsx", ".tsx", ".dart", ".scala", ".toml",
    ".pl", ".lua", ".r", ".m", ".kt", ".kts",
    ".groovy", ".clj", ".cljs", ".coffee", ".elm",
)

# Extensionless files to match by exact name
SUPPORTED_NAMES = ("Dockerfile", "Makefile", "makefile")

SKIP_DIRS = {".git", ".venv", "venv", "node_modules", "__pycache__",
             ".idea", ".vscode", "dist", "build", ".mypy_cache", ".pytest_cache"}

AI_OPTIONS = {
    "gemini": {
        "name": "Gemini",
        "text_model": "models/gemini-2.5-flash",
        "embed_model": "models/gemini-embedding-001",
    },
    "openai": {
        "name": "OpenAI",
        "text_model": "gpt-4o-mini",
        "embed_model": "text-embedding-3-large",
    },
   
}


# ─────────────────────────────────────────────
# INIT
# ─────────────────────────────────────────────
def init(ai_choice: str, api_key: str, language: str = "English"):
    global _ai_disabled, _ai_config, _openai_client, _language

    
    _ai_disabled = False
    _language  = language
    _ai_config = AI_OPTIONS[ai_choice]

    if ai_choice == "gemini":
        genai.configure(api_key=api_key)

    elif ai_choice == "openai":
        _openai_client = OpenAI(api_key=api_key)

# ─────────────────────────────────────────────
# COLLECTION PER REPO
# ─────────────────────────────────────────────
def get_collection(repo_name: str, branch: str = None):
    suffix = f"_{branch.replace('/', '_').replace('-', '_')}" if branch else ""
    safe_name = repo_name.replace("-", "_").replace(".", "_")
    return CHROMA_CLIENT.get_or_create_collection(name=f"repo_{safe_name}{suffix}")

import hashlib
import json

def _hash_file(content: str) -> str:
    """MD5 hash of a file's text content."""
    return hashlib.md5(content.encode("utf-8", errors="ignore")).hexdigest()

def _load_hashes(repo_name: str) -> dict:
    """Load stored hashes from chroma_db/<repo>_hashes.json."""
    path = os.path.join("chroma_db", f"{repo_name}_hashes.json")
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)
    return {}

def _save_hashes(repo_name: str, hashes: dict) -> None:
    """Persist hashes dict to chroma_db/<repo>_hashes.json."""
    os.makedirs("chroma_db", exist_ok=True)
    path = os.path.join("chroma_db", f"{repo_name}_hashes.json")
    with open(path, "w") as f:
        json.dump(hashes, f, indent=2)

def build_dependency_clusters(files):
    all_calls = {}
    for fname, content in files:
        calls = _extract_calls(fname, content)
        all_calls.update(calls)

    clusters = []
    visited = set()

    for func in all_calls:
        if func in visited:
            continue

        stack = [func]
        cluster = set()

        while stack:
            f = stack.pop()
            if f in visited:
                continue
            visited.add(f)
            cluster.add(f)

            for called in all_calls.get(f, []):
                for target in all_calls:
                    if target.endswith(f".{called}"):
                        stack.append(target)

        clusters.append(cluster)

    return clusters

def chunk_by_file(
    files: list[tuple[str, str]],
    max_chars: int = 8000,
    include_header: bool = True,       # include filenames of neighbours as context hints
) -> list[str]:
    """
    Dependency-aware chunking:
    1. Sort files so likely-related ones are adjacent (same extension, then alpha)
    2. Split oversized single files into function-level sub-chunks
    3. Add a 1-line context header listing ALL filenames so the AI
       knows what else exists even when it can't see it
    """
    # ── 1. sort: group by extension so .py files stay together ──────────────
    files = sorted(files, key=lambda f: (os.path.splitext(f[0])[1], f[0]))

    all_filenames = [f[0] for f in files]
    header = f"""
        # CONTEXT SUMMARY:
        This chunk is part of a larger codebase.
        Files included in this chunk:
        {', '.join(f[0] for f in files)}

        Focus:
        - Understand relationships between functions
        - Do NOT assume missing implementations
        """

    # ── 2. split any single file that exceeds max_chars on its own ──────────
    expanded: list[tuple[str, str]] = []
    for fname, content in files:
        if len(content) <= max_chars:
            expanded.append((fname, content))
        else:
            # split on function/class boundaries for Python
            ext = os.path.splitext(fname)[1]
            if ext == ".py":
                parts = _split_python_file(fname, content, max_chars)
            else:
                # generic: split on blank lines, respecting max_chars
                parts = _split_generic(fname, content, max_chars)
            expanded.extend(parts)

    # ── 3. pack into chunks greedily, but never mix extensions ──────────────
    chunks: list[str] = []
    current_parts: list[str] = []
    current_len = len(header)
    current_ext = None

    for fname, content in expanded:
        ext = os.path.splitext(fname)[1]
        piece = f"# FILE: {fname}\n{content}\n\n"

        ext_changed = (current_ext is not None and ext != current_ext)
        would_overflow = (current_len + len(piece) > max_chars and current_parts)

        if ext_changed or would_overflow:
            chunks.append(header + "".join(current_parts))
            current_parts, current_len = [], len(header)

        current_parts.append(piece)
        current_len += len(piece)
        current_ext = ext

    if current_parts:
        chunks.append(header + "".join(current_parts))

    # At the end of chunk_by_file, replace the final_chunks build:
    final_chunks = []
    OVERLAP = 250
    for chunk in chunks:
        # extract the first "# FILE: <name>" from the chunk to use as label
        m = re.search(r"# FILE: (.+)", chunk)
        label = m.group(1).split("[part")[0] if m else "unknown"
        i = 0
        while i < len(chunk):
            final_chunks.append((chunk[i:i + max_chars], label))
            i += max_chars - OVERLAP

    return final_chunks


def _split_python_file(
    fname: str, content: str, max_chars: int
) -> list[tuple[str, str]]:
    """Split a large .py file at top-level def/class boundaries."""
    import ast, textwrap

    try:
        tree = ast.parse(content)
    except SyntaxError:
        return _split_generic(fname, content, max_chars)

    lines = content.splitlines(keepends=True)
    boundaries = sorted(
        node.lineno - 1                          # 0-indexed
        for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        and node.col_offset == 0                 # top-level only
    )

    if not boundaries:
        return _split_generic(fname, content, max_chars)

    # build segments: [0..b1), [b1..b2), ...
    boundaries = [0] + boundaries + [len(lines)]
    segments: list[str] = []
    for i in range(len(boundaries) - 1):
        seg = "".join(lines[boundaries[i]:boundaries[i+1]])
        if seg.strip():
            segments.append(seg)

    # merge small segments, split oversized ones
    result: list[tuple[str, str]] = []
    buffer = ""
    part = 1
    for seg in segments:
        if len(buffer) + len(seg) <= max_chars:
            buffer += seg
        else:
            if buffer:
                result.append((f"{fname}[part{part}]", buffer))
                part += 1
            # oversized single segment — hard-split by lines
            if len(seg) > max_chars:
                for sub in _split_generic(fname, seg, max_chars):
                    result.append((f"{fname}[part{part}]", sub[1]))
                    part += 1
            else:
                buffer = seg
    if buffer:
        result.append((f"{fname}[part{part}]", buffer))

    return result


def _split_generic(
    fname: str, content: str, max_chars: int
) -> list[tuple[str, str]]:
    """Fallback: split on blank lines, hard-cut if needed."""
    paragraphs = re.split(r'\n{2,}', content)
    parts: list[tuple[str, str]] = []
    buffer = ""
    part = 1

    for para in paragraphs:
        piece = para + "\n\n"
        if len(buffer) + len(piece) > max_chars and buffer:
            parts.append((f"{fname}[part{part}]", buffer))
            part += 1
            buffer = piece
        else:
            buffer += piece

    if buffer:
        parts.append((f"{fname}[part{part}]", buffer))

    return parts

# ─────────────────────────────────────────────
# AI — GENERATE
# ─────────────────────────────────────────────
def safe_generate(prompt: str, retries: int = 2) -> str | None:
    global _ai_disabled

    if _ai_disabled:
        return None

    for attempt in range(retries):
        try:
            name = _ai_config["name"]

            if name == "Gemini":
                model = genai.GenerativeModel(_ai_config["text_model"])
                res   = model.generate_content(
                    prompt,
                    generation_config={"max_output_tokens": 16384},
                )
                return getattr(res, "text", None)

            elif name == "OpenAI":
                res = _openai_client.chat.completions.create(
                    model=_ai_config["text_model"],
                    max_tokens=8192,
                    messages=[{"role": "user", "content": prompt}],
                )
                return res.choices[0].message.content

           

        except Exception as e:
            err = str(e)
            if "quota" in err.lower() and "429" not in err:
                console.print("⚠️  Quota exceeded → AI disabled for this session", style="bold red")
                _ai_disabled = True
                return None
            elif "429" in err or "rate" in err.lower():
                console.print(f"⏳ Rate limited — waiting 60 seconds...", style="bold blue")
                time.sleep(60)
                continue
            console.print(f"⚠️  AI unavailable (attempt {attempt + 1}/{retries})", style="bold red")
            if attempt < retries - 1:
                time.sleep(2)

    return None


# ─────────────────────────────────────────────
# AI — EMBED
# ─────────────────────────────────────────────
def embed_text(text: str, is_query: bool = False, retries: int = 3) -> list[float]:

    def _rate_limit_wait(total_wait: int):
        """
        Thread-safe rate-limit wait.  Uses console.print (not Live) so it
        never conflicts with an outer Live context running on another thread.
        """
        start = time.time()
        i = 0
        while True:
            elapsed = time.time() - start
            remaining = total_wait - elapsed
            if remaining <= 0:
                break
            msg = wait_texts[i % len(wait_texts)]
            console.print(f"⏳ {msg} ({int(remaining)}s remaining…)", style="bold yellow")
            time.sleep(min(10, remaining))
            i += 1
    for attempt in range(retries):
        try:
            name = _ai_config["name"]

            if name == "Gemini":
                task_type = "retrieval_query" if is_query else "retrieval_document"
                res = genai.embed_content(
                    model=_ai_config["embed_model"],
                    content=text,
                    task_type=task_type,
                )
                return res["embedding"]

            elif name == "OpenAI":
                res = _openai_client.embeddings.create(
                    model=_ai_config["embed_model"],
                    input=text,
                )
                return res.data[0].embedding

        except Exception as e:
            err = str(e)
            if "429" in err or "rate" in err.lower():
                wait = 60 * (attempt + 1)
                _rate_limit_wait(wait)
                continue
            console.print(f"❌ Embedding failed-> {e}", style="bold red")
            dim = 3072 if _ai_config.get("name") == "Gemini" else 1536
            return [0.0] * dim

    console.print("❌ Embedding failed after retries — using dummy", style="bold red")
    dim = 3072 if _ai_config.get("name") == "Gemini" else 1536
    return [0.0] * dim


# ─────────────────────────────────────────────
# REPO — CLONE & LOAD
# ─────────────────────────────────────────────
def clone_repo(url: str, branch: str = None) -> tuple[str, str]:
    os.makedirs("repos", exist_ok=True)
    name = url.rstrip("/").split("/")[-1].replace(".git", "")
    branch_suffix = f"_{branch.replace('/', '_').replace('-', '_')}" if branch else ""
    path = os.path.join("repos", f"{name}{branch_suffix}")

    if not os.path.exists(path):
        console.print(f"📥 Cloning {url} {'@ ' + branch if branch else ''} ...", style="bold cyan")
        kwargs = {"branch": branch} if branch else {}
        Repo.clone_from(url, path, **kwargs)
    else:
        console.print(f"✅ Repo already exists at {path}", style="bold green")

    return path, name

def load_files(repo_path: str) -> list[tuple[str, str]]:
    result_box = [None]
    done_event = threading.Event()

    def _scan():
        found = []
        for root, dirnames, files in os.walk(repo_path):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
            for file in files:
                if file.endswith(SUPPORTED_EXT) or file in SUPPORTED_NAMES:
                    try:
                        if file.endswith(".pdf"):
                            import pdfplumber
                            with pdfplumber.open(os.path.join(root, file)) as pdf:
                                content = "\n".join(page.extract_text() or "" for page in pdf.pages).strip()
                        else:
                            with open(os.path.join(root, file), "r", errors="ignore") as f:
                                content = f.read().strip()
                        if content:
                            found.append((file, content))
                    except Exception as e:
                        console.print(f"⚠️ Failed to load file {file}: {e}", style="bold red")
        result_box[0] = found
        done_event.set()

    scan_thread = threading.Thread(target=_scan, daemon=True)
    scan_thread.start()

    # wait 2 seconds — if still running, show spinner
    finished_early = done_event.wait(timeout=2.0)

    if not finished_early:
        # ADD this instead
        from rich.text import Text
        t = 0
        with Live(console=console, refresh_per_second=15, transient=True) as live:
            while not done_event.is_set():
                pixels = _scan_frame(t)
                frame_text = Text(justify="center")
                for ch, color in pixels:
                    if ch == '\n':
                        frame_text.append('\n')
                    else:
                        frame_text.append(ch, style=color)

                caption = Text(justify="center")
                caption.append("\n  scanning files\n\n", style="bold green")
                caption.append_text(frame_text)
                caption.append("\n\n  reading directory tree...\n", style="dim italic")

                live.update(Align(Panel(
                    caption,
                    title="[bold magenta]◈ GitPutra ◈[/bold magenta]",
                    border_style="bold green",
                    padding=(1, 4),
                    expand=False,
                ), align="center"))
                t += 1
                time.sleep(0.07)

    scan_thread.join()
    files_data = result_box[0] or []
    console.print(f"📂 Loaded {len(files_data)} source files", style="bold yellow")
    return files_data


# ─────────────────────────────────────────────
# CHROMADB — STORE & QUERY
# ─────────────────────────────────────────────
def store_chunks(files: list[tuple[str, str]], repo_name: str, branch: str = None):
    from rich.text import Text

    collection   = get_collection(repo_name, branch)
    stored_hashes = _load_hashes(repo_name)        # ← load existing hashes
    new_hashes    = dict(stored_hashes)             # we'll mutate this copy

    # ── Determine which files changed ────────────────────────────────────────
    files_to_index = []
    for fname, content in files:
        current_hash = _hash_file(content)
        if stored_hashes.get(fname) == current_hash:
            continue                                # unchanged — skip entirely
        # Changed or new: purge any old chunks for this file first
        try:
            old = collection.get(where={"filename": fname})
            if old["ids"]:
                collection.delete(ids=old["ids"])
        except Exception:
            pass
        console.print(f"  📄 Queuing for indexing: {fname}", style="dim blue")
        files_to_index.append((fname, content))
        new_hashes[fname] = current_hash

    if not files_to_index:
        console.print("✅ All files unchanged — index is up to date.", style="bold green")
        return

    # ── Chunk only the changed/new files ─────────────────────────────────────
    chunks       = chunk_by_file(files_to_index, max_chars=3000, include_header=False)
    total        = len(chunks)
    stored       = 0
    progress_box = [0.0]
    stop_event   = threading.Event()

    console.print(f"💾 Indexing {total} chunks from {len(files_to_index)} changed file(s)…",
                  style="bold yellow")

    # ✅ correct
    def _store():
        nonlocal stored
        for chunk_text, fname_label in chunks:   # chunks = chunk_by_file(...) above
            emb = embed_text(chunk_text)
            collection.add(
                documents=[chunk_text],
                embeddings=[emb],
                ids=[str(uuid.uuid4())],
                metadatas=[{"chunk": chunk_text[:80], "filename": fname_label}],
            )
            stored += 1
            progress_box[0] = stored / total
        stop_event.set()

    store_thread = threading.Thread(target=_store, daemon=True)
    store_thread.start()
    t = 0
    with Live(console=console, refresh_per_second=10, transient=True) as live:
        while not stop_event.is_set():
            prog   = progress_box[0]
            pixels = animations._grid_fill_frame(t, prog)
    
            frame_text = Text(justify="center")
            for ch, color in pixels:
                if ch == '\n':
                    frame_text.append('\n')
                else:
                    frame_text.append(ch, style=color)
    
            filled = int(prog * 30)
            bar    = '█' * filled + '░' * (30 - filled)
            pct    = int(prog * 100)
    
            caption = Text(justify="center")
            caption.append("\n  indexing chunks\n\n", style="bold green")
            caption.append_text(frame_text)
            caption.append(f"\n\n  [{bar}] {pct}%  ({int(prog * total)}/{total})\n", style="dim")
            caption.append("  building vector index...\n", style="dim italic")
    
            live.update(Align(Panel(
                caption,
                title="[bold magenta]◈ GitPutra ◈[/bold magenta]",
                border_style="bold green",
                padding=(1, 4),
                expand=False,
            ), align="center"))
            t += 1
            time.sleep(0.055)
    store_thread.join()

    _save_hashes(repo_name, new_hashes)            # ← persist updated hashes
    console.print(f"✅ Stored {total} chunks", style="bold green")

def query_rag(question: str, repo_name: str, branch: str = None, history: list = None) -> str:

    collection = get_collection(repo_name, branch)

    # ── Phase 1: Embed question (DNA helix animation) ─────────────────────
    emb_box  = [None]
    done_emb = threading.Event()

    def _embed():
        emb_box[0] = embed_text(question, is_query=True)
        done_emb.set()

    embed_thread = threading.Thread(target=_embed, daemon=True)
    embed_thread.start()

    t = 0
    with Live(console=console, refresh_per_second=20, transient=True) as live:
        while not done_emb.is_set():
            pixels = animations._particle_storm_frame(t)
            frame_text = Text(justify="center")
            for ch, color in pixels:
                if ch == '\n':
                    frame_text.append('\n')
                else:
                    frame_text.append(ch, style=color)

            caption = Text(justify="center")
            caption.append("\n  embedding query\n\n", style="bold cyan")
            caption.append_text(frame_text)
            caption.append("\n\n  searching vector index...\n", style="dim italic")

            live.update(Align(Panel(
                caption,
                title="[bold magenta]◈ GitPutra ◈[/bold magenta]",
                border_style="bold cyan",
                padding=(1, 4),
                expand = False,
            ), align="center"))
            t += 1
            time.sleep(0.055)

    embed_thread.join()

    # vector fetch (instant, no animation needed)
    emb  = emb_box[0]
    res  = collection.query(query_embeddings=[emb], n_results=5)
    docs = res.get("documents", [[]])[0]
    context = "\n".join(docs) if docs else ""

    history_block = ""
    if history:
        # always include last 3 exchanges verbatim (most relevant)
        recent = history[-6:]
        # summarize older exchanges into one line each
        older  = history[:-6]

        if older:
            history_block = "Earlier in this conversation:\n"
            for i in range(0, len(older), 2):
                if i + 1 < len(older):
                    q = older[i]["content"][:120].replace("\n", " ")
                    a = older[i+1]["content"][:120].replace("\n", " ")
                    history_block += f"- User asked about: {q}... → {a}...\n"
            history_block += "\n"

        history_block += "Recent conversation:\n"
        for msg in recent:
            role = "User" if msg["role"] == "user" else "Assistant"
            history_block += f"{role}: {msg['content']}\n"
        history_block += "\n"

    prompt = f"""Answer in {_language}.
You are "AI Putra", an expert AI coding assistant with deep understanding of codebases.
Be concise and direct unless you are asked for a detailed answer. 
Answer in 7-15 sentences maximum unless the question explicitly requires detail.

Context from codebase:
{context}

{history_block}Current question:
{question}
"""

    # ── Phase 2: LLM generation (waveform collapse animation) ─────────────
    result_box = [None]
    done_gen   = threading.Event()

    def _generate():
        result_box[0] = safe_generate(prompt)
        done_gen.set()

    gen_thread = threading.Thread(target=_generate, daemon=True)
    gen_thread.start()

    t = 0
    with Live(console=console, refresh_per_second=20, transient=True) as live:
        while not done_gen.is_set():
            pixels = animations._particle_storm_frame(t)
            frame_text = Text(justify="center")
            for ch, color in pixels:
                if ch == '\n':
                    frame_text.append('\n')
                else:
                    frame_text.append(ch, style=color)

            caption = Text(justify="center")
            caption.append("\n  generating answer\n\n", style="bold green")
            caption.append_text(frame_text)
            caption.append("\n\n  synthesizing response...\n", style="dim italic")

            live.update(Align(Panel(
                caption,
                title="[bold magenta]◈ GitPutra ◈[/bold magenta]",
                border_style="bold green",
                padding=(1, 4),
                expand = False,
            ), align="center"))
            t += 1
            time.sleep(0.055)

    gen_thread.join()
    return result_box[0] or "⚠️ AI unavailable."


# ─────────────────────────────────────────────
# ANALYSIS
# ─────────────────────────────────────────────

# Max chars to send in a single API call.
# ~60k chars ≈ 15k tokens — safe for Gemini 2.5 Flash, GPT-4o-mini
# (all support 128k+ context). Fits ~20 chunks of 3000 chars each.
_BATCH_CHARS = 60_000

def analyze_repo(files: list[tuple[str, str]]) -> str:
    console.print("\n🔍 Analyzing repo...\n", style = "bold blue")
    chunks_with_labels = chunk_by_file(files)
    chunks = [text for text, _label in chunks_with_labels]

    # ── pack chunks into batches ─────────────────────────────────────────────
    batches: list[str] = []
    current_batch: list[str] = []
    current_len = 0

    for chunk in chunks:
        if current_len + len(chunk) > _BATCH_CHARS and current_batch:
            batches.append("\n".join(current_batch))
            current_batch, current_len = [], 0
        current_batch.append(chunk)
        current_len += len(chunk)

    if current_batch:
        batches.append("\n".join(current_batch))

    console.print(f"  📦 {len(chunks)} chunks → {len(batches)} batch call(s) + 1 synthesis\n", style = "bold yellow")

    # ── one summary call per batch ───────────────────────────────────────────
    summaries = []
    with Live(console=console, refresh_per_second=20, transient=True) as live:
        for i, batch in enumerate(batches, 1):
            # start animation thread
            stop_event = threading.Event()
            thread = threading.Thread(
                target=_animated_panel,
                args=(live, i, len(batches), stop_event),
                daemon=True
            )
            thread.start()

            # actual API call — animation runs while this blocks
            res = safe_generate(f"""
You are a senior software engineer performing a deep technical audit of a real-world codebase.

IMPORTANT:
- Write VERY DETAILED analysis
- Minimum 800-1200 words per batch
- Expand each section with examples
- Quote code snippets where useful
- Do NOT summarize — EXPLAIN deeply
                                
STRICT RULES:
- Do NOT assume components that are not present in the code.
- Do NOT invent architecture or modules.
- Every claim must be grounded in actual code.
- Reference file names or code snippets as evidence.
- If something is unclear or missing, explicitly say so.
- Every claim MUST reference specific functions, files, or patterns
- Be opinionated and critical
- Call out bad design explicitly
- Include specific code examples where possible
- Explain consequences of each flaw
- Do not soften criticism with polite language — be direct and technical
- Every claim MUST reference:
  - exact function name OR
  - exact file name OR
  - exact code pattern
                                
For every issue:
- What is wrong
- Why it is wrong
- What it breaks
- How to fix it

Your job is NOT to summarize — it is to reverse-engineer and critique.

Analyze the following codebase chunk and provide:

1. REAL FUNCTIONALITY
- What does this code ACTUALLY do (not what it intends to do)
- What problem it is solving in practice

2. CORE LOGIC BREAKDOWN
- Key functions/classes and how they work internally
- Data flow within this chunk
- Any algorithms or patterns used

3. DEPENDENCIES & INTERACTIONS
- Libraries used and why
- How different parts of the code interact

4. ENGINEERING QUALITY
- Code quality issues (duplication, inefficiency, bad patterns)
- Performance concerns
- Maintainability problems

5. NON-OBVIOUS INSIGHTS
- Hidden clever tricks
- Design decisions that are interesting or unusual

Code:
{batch}
""")
            stop_event.set()
            thread.join()

            if res:
                summaries.append(res)

            # flash completion
            progress_filled = int(i / len(batches) * 30)
            progress_bar = "█" * progress_filled + "░" * (30 - progress_filled)
            live.update(Align(Panel(
                f"\n"
                f"[bold green]  ✅ Batch {i}/{len(batches)} complete[/bold green]\n\n"
                f"[bold green]  {'█' * 18}[/bold green]\n\n"
                f"[dim]  [{progress_bar}] {int(i/len(batches)*100)}%[/dim]\n\n"
                f"[dim italic]  {'Synthesizing final report...' if i == len(batches) else 'Next batch loading...'}[/dim italic]\n",
                title="[bold magenta]◈ GitPutra◈[/bold magenta]",
                border_style="bold green",
                padding=(1, 4),
                expand = False,
            ), align="center"))
            time.sleep(0.6)    

    if not summaries:
        return "⚠️ AI unavailable — no analysis generated."

    # ── final synthesis (unchanged) ──────────────────────────────────────────
    result_box = [None]

    def _run_synthesis():
        result_box[0] = safe_generate(f"""
You are a principal engineer reviewing a codebase for production readiness.

IMPORTANT:
- DO NOT summarize
- EXPAND all insights
- Combine and elaborate
- Minimum 800–1200 words output

STRICT RULES:
- Do NOT invent components not present in the summaries
- Base everything ONLY on provided summaries
- Be critical, not polite
- Prefer accuracy over completeness
- Every claim MUST reference specific functions, files, or patterns
- Be opinionated and critical
- Call out bad design explicitly
- Include specific code examples where possible
- Explain consequences of each flaw
- Do not soften criticism with polite language — be direct and technical
- Every claim MUST reference:
  - exact function name OR
  - exact file name OR
  - exact code pattern
                                      
For every issue:
- What is wrong
- Why it is wrong
- What it breaks
- How to fix it


Generate a detailed technical report with:

### ACTUAL SYSTEM SUMMARY
- What the system truly does (not idealized version)
- Real capabilities vs implied ones

### ARCHITECTURE (REAL, NOT ASSUMED)
- How the system is actually structured
- Data flow across components
- Highlight fragmentation or inconsistencies

### KEY ENGINEERING DECISIONS
- Important patterns (e.g., two-stage inference, frame skipping)
- Why they matter

### CODE QUALITY ANALYSIS
- Duplication, lack of abstraction, bad practices
- Scalability and maintainability issues

### FALSE ASSUMPTIONS / GAPS
- Missing components that SHOULD exist but don’t
- Mismatch between expected vs actual system

### PERFORMANCE & DESIGN INSIGHTS
- What is optimized well
- What is inefficient

### CONCRETE IMPROVEMENTS
- Specific fixes with examples
- Refactoring suggestions
- Architecture redesign ideas

Be brutally honest. Avoid generic statements.

Summaries:
{chr(10).join(summaries)}
""")
    stop_event = threading.Event()
    synthesis_thread = threading.Thread(target=_run_synthesis, daemon=True)

    with Live(console=console, refresh_per_second=20, transient=True) as live:
        anim_thread = threading.Thread(
            target=_animated_panel,
            args=(live, len(batches), len(batches), stop_event),
            kwargs={"mode": "synthesize"},
            daemon=True,
        )

        synthesis_thread.start()
        anim_thread.start()
        synthesis_thread.join()
        stop_event.set()
        anim_thread.join()

    return result_box[0] or "⚠️ Final synthesis failed."


_FUNC_PATTERNS = {
    # language: (function definition pattern, call pattern)
    ".py":    (r"^def (\w+)\s*\(",           r"(\w+)\s*\("),
    ".js":    (r"function (\w+)\s*\(",        r"(\w+)\s*\("),
    ".ts":    (r"function (\w+)\s*\(",        r"(\w+)\s*\("),
    ".jsx":   (r"function (\w+)\s*\(",        r"(\w+)\s*\("),
    ".tsx":   (r"function (\w+)\s*\(",        r"(\w+)\s*\("),
    ".java":  (r"(?:public|private|protected|static|\s)+\w+\s+(\w+)\s*\(", r"(\w+)\s*\("),
    ".go":    (r"^func (\w+)\s*\(",           r"(\w+)\s*\("),
    ".rs":    (r"^fn (\w+)\s*\(",             r"(\w+)\s*\("),
    ".c":     (r"^\w[\w\s\*]+(\w+)\s*\(",     r"(\w+)\s*\("),
    ".cpp":   (r"^\w[\w\s\*]+(\w+)\s*\(",     r"(\w+)\s*\("),
    ".cs":    (r"(?:public|private|protected|static|\s)+\w+\s+(\w+)\s*\(", r"(\w+)\s*\("),
    ".rb":    (r"^def (\w+)",                 r"(\w+)\s*[\(\s]"),
    ".php":   (r"function (\w+)\s*\(",        r"(\w+)\s*\("),
    ".swift": (r"func (\w+)\s*\(",            r"(\w+)\s*\("),
    ".kt":    (r"fun (\w+)\s*\(",             r"(\w+)\s*\("),
    ".lua":   (r"function (\w+)\s*\(",        r"(\w+)\s*\("),
}

# names to always ignore — builtins, keywords, noise
_IGNORE = {
    "if", "for", "while", "switch", "return", "print", "len", "range",
    "str", "int", "float", "bool", "list", "dict", "set", "tuple",
    "new", "this", "self", "super", "null", "true", "false",
    "console", "log", "err", "error", "fmt", "append", "make",
    "require", "import", "include", "define", "typeof", "instanceof",
}

def _extract_calls(fname: str, content: str) -> dict[str, set[str]]:
    return _ts_extract_calls(fname, content)


# ─────────────────────────────────────────────
# DIAGRAMS
# ─────────────────────────────────────────────

def _clean(name: str) -> str:
    return (
        name.replace(".py", "_py")
            .replace(".", "_")
            .replace("-", "_")
            .replace("/", "_")
    )

def _build_call_graph(files: list[tuple[str, str]]) -> tuple[dict, dict]:
    """
    Returns:
        all_funcs : short_name -> set of full_names  (fixes collision — one short name
                    can map to multiple full names in different modules)
        all_calls : full_name  -> set of short callee names
    """
    all_funcs: dict[str, set[str]] = {}
    all_calls: dict[str, set[str]] = {}

    for fname, content in files:
        calls = _extract_calls(fname, content)
        all_calls.update(calls)
        for full_name in calls:
            short = full_name.split(".")[-1]
            all_funcs.setdefault(short, set()).add(full_name)  # fix: set not str

    return all_funcs, all_calls


def _module_of(full_name: str) -> str:
    return full_name.rsplit(".", 1)[0]


# ── 1. FULL CALL GRAPH ───────────────────────────────────────────────────────
def generate_diagram(files: list[tuple[str, str]]):
    """Every intra-project function call, same or different module."""
    try:
        from pyvis.network import Network
    except ImportError:
        console.print("⚠️  pyvis not installed — run: pip install pyvis", style="bold red")
        return

    all_funcs, all_calls = _build_call_graph(files)

    COLORS = ["#CECBF6", "#9FE1CB", "#FAC775", "#F5C4B3", "#B5D4F4"]
    module_color: dict[str, str] = {}
    color_idx = 0

    net = Network(height="750px", width="100%", directed=True, bgcolor="#ffffff")
    net.set_options("""
    {
      "layout": { "hierarchical": { "enabled": false } },
      "physics": { "stabilization": true, "barnesHut": { "springLength": 120 } },
      "edges": { "arrows": { "to": { "enabled": true } }, "color": "#888780", "width": 0.8 },
      "nodes": { "font": { "size": 12 }, "shape": "box", "borderWidth": 0.5 }
    }
    """)

    # add nodes
    for full_name in all_calls:
        mod = _module_of(full_name)
        if mod not in module_color:
            module_color[mod] = COLORS[color_idx % len(COLORS)]
            color_idx += 1
        node_id = full_name.replace(".", "_")
        short   = full_name.split(".")[-1]
        net.add_node(node_id, label=short, title=f"{mod}.py → {short}()", color=module_color[mod], borderWidthSelected=2)

    # add ALL intra-project edges
    edges_added = set()
    for func, called_set in all_calls.items():
        src = func.replace(".", "_")
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:      # fix: iterate the set
                if callee_full == func:
                    continue
                tgt  = callee_full.replace(".", "_")
                edge = (src, tgt)
                if edge not in edges_added:
                    net.add_edge(src, tgt)
                    edges_added.add(edge)

    if not edges_added:
        console.print("📊 No intra-project calls found — skipping full call graph", style="bold yellow")
        return

    os.makedirs("output", exist_ok=True)
    out = os.path.abspath("output/diagram_full.html")
    net.save_graph(out)
    console.print(f"📊 Full call graph → {out}", style="bold yellow")


# ── 2. CROSS-MODULE ONLY ─────────────────────────────────────────────────────
def generate_diagram_crossmodule(files: list[tuple[str, str]]):
    """Function-level nodes, only edges that cross a module boundary."""
    try:
        from pyvis.network import Network
    except ImportError:
        console.print("⚠️  pyvis not installed — run: pip install pyvis", style="bold red")
        return

    all_funcs, all_calls = _build_call_graph(files)

    COLORS = ["#CECBF6", "#9FE1CB", "#FAC775", "#F5C4B3", "#B5D4F4"]
    module_color: dict[str, str] = {}
    color_idx = 0

    net = Network(height="750px", width="100%", directed=True, bgcolor="#ffffff")
    net.set_options("""
    {
      "layout": { "hierarchical": { "enabled": false } },
      "physics": { "stabilization": true, "barnesHut": { "springLength": 160 } },
      "edges": { "arrows": { "to": { "enabled": true } }, "color": "#534AB7", "width": 1 },
      "nodes": { "font": { "size": 12 }, "shape": "box", "borderWidth": 0.5 }
    }
    """)

    edges_added = set()
    nodes_needed: set[str] = set()

    # find cross-module edges first so we only add nodes that appear in them
    cross_edges: list[tuple[str, str]] = []
    for func, called_set in all_calls.items():
        src_mod = _module_of(func)
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                if callee_full == func:
                    continue
                if _module_of(callee_full) != src_mod:          # cross-module check
                    edge = (func, callee_full)
                    if edge not in edges_added:
                        cross_edges.append(edge)
                        edges_added.add(edge)
                        nodes_needed.add(func)
                        nodes_needed.add(callee_full)

    if not cross_edges:
        console.print("📊 No cross-module calls found — skipping cross-module graph", style="bold yellow")
        return

    for full_name in nodes_needed:
        mod = _module_of(full_name)
        if mod not in module_color:
            module_color[mod] = COLORS[color_idx % len(COLORS)]
            color_idx += 1
        node_id = full_name.replace(".", "_")
        short   = full_name.split(".")[-1]
        net.add_node(node_id, label=short, title=f"{mod}.py → {short}()", color=module_color[mod], borderWidthSelected=2)

    for src, tgt in cross_edges:
        net.add_edge(src.replace(".", "_"), tgt.replace(".", "_"))

    os.makedirs("output", exist_ok=True)
    out = os.path.abspath("output/diagram_crossmodule.html")
    net.save_graph(out)
    console.print(f"📊 Cross-module graph → {out}", style="bold yellow")


# ── 3. MODULE DEPENDENCY GRAPH ───────────────────────────────────────────────
def generate_diagram_modules(files: list[tuple[str, str]]):
    """High-level: one node per .py file, edge = any call crossing that boundary."""
    try:
        from pyvis.network import Network
    except ImportError:
        console.print("⚠️  pyvis not installed — run: pip install pyvis", style="bold red")
        return

    all_funcs, all_calls = _build_call_graph(files)

    # count how many function calls cross each module boundary
    edge_weights: dict[tuple[str, str], int] = {}
    for func, called_set in all_calls.items():
        src_mod = _module_of(func)
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                tgt_mod = _module_of(callee_full)
                if tgt_mod != src_mod:
                    key = (src_mod, tgt_mod)
                    edge_weights[key] = edge_weights.get(key, 0) + 1

    if not edge_weights:
        console.print("📊 No cross-module dependencies found — skipping module graph", style="bold yellow")
        return

    COLORS = ["#CECBF6", "#9FE1CB", "#FAC775", "#F5C4B3", "#B5D4F4"]
    modules = sorted({m for pair in edge_weights for m in pair})
    module_color = {m: COLORS[i % len(COLORS)] for i, m in enumerate(modules)}

    net = Network(height="600px", width="100%", directed=True, bgcolor="#ffffff")
    net.set_options("""
    {
      "layout": { "hierarchical": { "enabled": false } },
      "physics": { "stabilization": true, "barnesHut": { "springLength": 200 } },
      "edges": { "arrows": { "to": { "enabled": true } }, "color": "#444441", "width": 2, "scaling": { "min": 1, "max": 8 } },
      "nodes": { "font": { "size": 14, "bold": true }, "shape": "box", "borderWidth": 1 }
    }
    """)

    for mod in modules:
        net.add_node(mod, label=f"{mod}.py", color=module_color[mod], size=30)

    for (src_mod, tgt_mod), weight in edge_weights.items():
        net.add_edge(
            src_mod, tgt_mod,
            title=f"{weight} call(s)",   # tooltip shows call count
            value=weight,                # scales edge thickness
        )

    os.makedirs("output", exist_ok=True)
    out = os.path.abspath("output/diagram_modules.html")
    net.save_graph(out)
    console.print(f"📊 Module dependency graph → {out}", style="bold yellow")

# ─────────────────────────────────────────────────────────────────────────────
# MERMAID — ALIASES & HEADERS
# ─────────────────────────────────────────────────────────────────────────────

_MERMAID_ALIASES: dict[str, str] = {
    "1": "graph",           "graph": "graph",
    "call graph": "graph",  "dependency": "graph",      "dep graph": "graph",
    "2": "flowchart",       "flowchart": "flowchart",
    "flow": "flowchart",    "flow chart": "flowchart",
    "3": "flowchart_lr",    "flowchart lr": "flowchart_lr",
    "horizontal": "flowchart_lr", "lr": "flowchart_lr",
    "4": "architecture",    "architecture": "architecture",
    "arch": "architecture", "module": "architecture",   "modules": "architecture",
    "5": "sequence",        "sequence": "sequence",
    "seq": "sequence",      "sequence diagram": "sequence",
    "6": "class",           "class": "class",
    "class diagram": "class", "uml": "class",
}

_MERMAID_HEADERS: dict[str, str | None] = {
    "graph":        "graph TD",
    "flowchart":    "flowchart TD",
    "flowchart_lr": "flowchart LR",
    "architecture": None,
    "sequence":     None,
    "class":        None,
}

_MERMAID_MENU = [
    {"key": "1", "type": "graph",        "icon": "◈", "label": "Call Graph",
     "desc": "Node per function, edges = calls.\nBest for: tracing execution paths."},
    {"key": "2", "type": "flowchart",    "icon": "⬇", "label": "Flowchart  (TD)",
     "desc": "Top-down flow with decision boxes.\nBest for: control flow visualisation."},
    {"key": "3", "type": "flowchart_lr", "icon": "➡", "label": "Flowchart  (LR)",
     "desc": "Left-to-right horizontal flow.\nBest for: pipeline / data-flow diagrams."},
    {"key": "4", "type": "architecture", "icon": "⬡", "label": "Architecture",
     "desc": "Subgraph per module + cross-module edges.\nBest for: high-level system overview."},
    {"key": "5", "type": "sequence",     "icon": "⇄", "label": "Sequence",
     "desc": "Participant per module, messages = calls.\nBest for: runtime interaction timelines."},
    {"key": "6", "type": "class",        "icon": "▣", "label": "Class / UML",
     "desc": "Class per module, methods listed inside.\nBest for: OOP structure / API surface."},
]


# ─────────────────────────────────────────────────────────────────────────────
# MERMAID — INTERACTIVE MENU
# ─────────────────────────────────────────────────────────────────────────────

def _mermaid_show_menu() -> None:
    from rich.panel import Panel
    from rich.columns import Columns

    console.print()
    console.print(Align(
        Text("◈  GitPutra  —  Choose Diagram Type  ◈", style="bold magenta", justify="center"),
        align="center",
    ))
    console.print()

    for row in (_MERMAID_MENU[:3], _MERMAID_MENU[3:]):
        cards = []
        for e in row:
            body = Text(justify="left")
            body.append(f"[{e['key']}] ", style="bold white")
            body.append(f"{e['icon']}  {e['label']}\n", style="bold cyan")
            body.append(e["desc"], style="dim italic")
            cards.append(Panel(body, border_style="dim", padding=(0, 1), expand=True))
        console.print(Columns(cards, equal=True, expand=True))
        console.print()

    console.print(
        "  Enter [bold cyan]number (1–6)[/bold cyan], "
        "[bold cyan]type name[/bold cyan] (e.g. architecture), "
        "or [bold cyan]Enter[/bold cyan] for default (graph):\n",
        style="dim",
    )


def _mermaid_prompt_type(default: str = "graph") -> str:
    from rich.prompt import Prompt

    _mermaid_show_menu()
    try:
        choice = Prompt.ask(
            "  [bold cyan]diagram[/bold cyan]",
            default="",
            show_default=False,
            console=console,
        ).strip().lower()
    except (KeyboardInterrupt, EOFError):
        console.print("\n  Using default: graph\n", style="dim")
        return default

    if not choice:
        return default

    resolved = _MERMAID_ALIASES.get(choice)
    if resolved:
        console.print(f"\n  ✅ Selected: [bold cyan]{resolved}[/bold cyan]\n")
        return resolved

    console.print(f"  ⚠️  Unknown type '{choice}' — using [bold yellow]{default}[/bold yellow]\n")
    return default


# ─────────────────────────────────────────────────────────────────────────────
# MERMAID — BUILDERS  (all use the existing _build_call_graph from this file)
# ─────────────────────────────────────────────────────────────────────────────

def _mermaid_build_graph(files, header: str) -> str | None:
    all_funcs, all_calls = _build_call_graph(files)
    lines, seen = [header], set()

    for func, called_set in all_calls.items():
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                if callee_full == func:
                    continue
                edge = f"    {_clean(func)} --> {_clean(callee_full)}"
                if edge not in seen:
                    lines.append(edge)
                    seen.add(edge)

    return "\n".join(lines) if len(lines) > 1 else None


def _mermaid_build_architecture(files) -> str | None:
    all_funcs, all_calls = _build_call_graph(files)

    modules: dict[str, list[str]] = {}
    for full_name in all_calls:
        mod = full_name.rsplit(".", 1)[0]
        modules.setdefault(mod, []).append(full_name)

    lines = ["graph TD"]
    for mod, funcs in sorted(modules.items()):
        lines.append(f"    subgraph {_clean(mod)}[\"{mod}\"]")
        for fn in funcs:
            lines.append(f"        {_clean(fn)}[\"{fn.split('.')[-1]}\"]")
        lines.append("    end")

    seen = set()
    for func, called_set in all_calls.items():
        src_mod = func.rsplit(".", 1)[0]
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                if callee_full == func:
                    continue
                if callee_full.rsplit(".", 1)[0] != src_mod:
                    edge = f"    {_clean(func)} --> {_clean(callee_full)}"
                    if edge not in seen:
                        lines.append(edge)
                        seen.add(edge)

    return "\n".join(lines) if len(lines) > 2 else None


def _mermaid_build_sequence(files) -> str | None:
    all_funcs, all_calls = _build_call_graph(files)

    participants, seen_p, messages, seen_m = [], set(), [], set()

    for func, called_set in all_calls.items():
        src_mod = func.rsplit(".", 1)[0]
        if src_mod not in seen_p:
            participants.append(src_mod)
            seen_p.add(src_mod)

        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                if callee_full == func:
                    continue
                tgt_mod = callee_full.rsplit(".", 1)[0]
                if tgt_mod not in seen_p:
                    participants.append(tgt_mod)
                    seen_p.add(tgt_mod)
                label = f"{func.split('.')[-1]}() → {callee_full.split('.')[-1]}()"
                msg = f"    {src_mod}->>+{tgt_mod}: {label}"
                if msg not in seen_m:
                    messages.append(msg)
                    seen_m.add(msg)

    if not messages:
        return None

    lines = ["sequenceDiagram"]
    lines += [f"    participant {p}" for p in participants]
    lines += messages
    return "\n".join(lines)


def _mermaid_build_class(files) -> str | None:
    all_funcs, all_calls = _build_call_graph(files)

    modules: dict[str, list[str]] = {}
    for full_name in all_calls:
        mod = full_name.rsplit(".", 1)[0]
        modules.setdefault(mod, []).append(full_name.split(".")[-1])

    lines = ["classDiagram"]
    for mod, funcs in sorted(modules.items()):
        lines.append(f"    class {_clean(mod)} {{")
        for fn in funcs[:12]:
            lines.append(f"        +{fn}()")
        lines.append("    }")

    seen = set()
    for func, called_set in all_calls.items():
        src = _clean(func.rsplit(".", 1)[0])
        for callee_short in called_set:
            if callee_short not in all_funcs:
                continue
            for callee_full in all_funcs[callee_short]:
                tgt = _clean(callee_full.rsplit(".", 1)[0])
                if tgt != src:
                    rel = f"    {src} ..> {tgt} : uses"
                    if rel not in seen:
                        lines.append(rel)
                        seen.add(rel)

    return "\n".join(lines) if len(lines) > 1 else None


# ─────────────────────────────────────────────────────────────────────────────
# REPLACE your old generate_mermaid() with this
# ─────────────────────────────────────────────────────────────────────────────

def generate_mermaid(
    files: list[tuple[str, str]],
    diagram_type: str | None = None,
) -> str | None:
    # resolve type — show menu if not given
    if diagram_type is None:
        dtype = _mermaid_prompt_type()
    else:
        dtype = _MERMAID_ALIASES.get(diagram_type.strip().lower(), "graph")

    console.print(f"🗺️  Generating [bold cyan]{dtype}[/bold cyan] diagram...\n")

    # dispatch to builder
    dispatch = {
        "architecture": _mermaid_build_architecture,
        "sequence":     _mermaid_build_sequence,
        "class":        _mermaid_build_class,
    }

    if dtype in dispatch:
        result = dispatch[dtype](files)
    else:
        result = _mermaid_build_graph(files, _MERMAID_HEADERS.get(dtype, "graph TD"))

    if not result:
        console.print(
            f"🗺️  No intra-project calls found for [{dtype}] — skipping.",
            style="bold yellow",
        )
        return None

    os.makedirs("output", exist_ok=True)
    out = os.path.abspath(f"output/mermaid_{dtype.replace('_', '-')}.txt")
    with open(out, "w", encoding="utf-8") as f:
        f.write(result)

    console.print(f"🗺️  Saved {out}", style="bold green")
    return out


# ─────────────────────────────────────────────
# PDF
# ─────────────────────────────────────────────
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _register_fonts():
    font_dir = os.path.join(_BASE_DIR, "fonts")
    mappings = {
        "NotoLatin":      "NotoSans-Regular.ttf",
        "NotoBengali":    "NotoSansBengali-Regular.ttf",
        "NotoDevanagari": "NotoSansDevanagari-Regular.ttf",
    }
    for font_name, filename in mappings.items():
        path = os.path.join(font_dir, filename)
        if os.path.exists(path):
            pdfmetrics.registerFont(TTFont(font_name, path))


def _get_font(language: str) -> str:
    lang = language.lower()
    if lang in ("bengali", "bangla"):
        font = "NotoBengali"
    elif lang == "hindi":
        font = "NotoDevanagari"
    else:
        font = "NotoLatin"

    try:
        pdfmetrics.getFont(font)
        return font
    except KeyError:
        return "Helvetica"


def generate_pdf(text: str):
    os.makedirs("output", exist_ok=True)
    _register_fonts()
    font = _get_font(_language)

    styles = {
        "title": ParagraphStyle(
            "title",
            fontName=font,
            fontSize=22,
            leading=26,
            textColor=colors.darkblue,
            spaceAfter=16
        ),
        "head": ParagraphStyle(
            "head",
            fontName=font,
            fontSize=16,
            leading=20,
            textColor=colors.HexColor("#1f4e79"),
            spaceBefore=12,
            spaceAfter=8
        ),
        "body": ParagraphStyle(
            "body",
            fontName=font,
            fontSize=11,
            leading=16,
            spaceAfter=6
        ),
        "bullet": ParagraphStyle(
            "bullet",
            fontName=font,
            fontSize=11,
            leading=14,
            leftIndent=12
        ),
        "code_block": ParagraphStyle(
            "code_block",
            fontName="Courier",
            fontSize=9,
            leading=13,
            leftIndent=10,
            rightIndent=10,
            spaceBefore=6,
            spaceAfter=6,
            backColor=colors.HexColor("#f0f0f0"),
            textColor=colors.HexColor("#1a1a1a"),
            borderColor=colors.HexColor("#cccccc"),
            borderWidth=0.5,
            borderPadding=(4, 6, 4, 6),
            wordWrap="CJK",
        ),
    }

    from reportlab.platypus import Preformatted

    def _escape(s: str) -> str:
        return (
            s.replace("&", "&amp;")
             .replace("<", "&lt;")
             .replace(">", "&gt;")
        )

    def _inline_code(line: str) -> str:
        """Replace `inline code` spans with Courier-font markup."""
        import re
        return re.sub(
            r'`([^`]+)`',
            lambda m: f'<font name="Courier" size="10" color="#c7254e">{_escape(m.group(1))}</font>',
            line
        )

    def _parse_section_body(lines: list[str]) -> list:
        """
        Parse lines from a section body into reportlab flowables.
        Handles:
          - fenced code blocks (``` ... ```)
          - bullet lines (- ...)
          - bold (**text**)
          - inline code (`code`)
          - plain body text
        """
        import re
        flowables = []
        i = 0
        while i < len(lines):
            line = lines[i]

            # ── fenced code block ────────────────────────────────────────────
            if line.strip().startswith("```"):
                code_lines = []
                i += 1
                while i < len(lines) and not lines[i].strip().startswith("```"):
                    code_lines.append(lines[i])
                    i += 1
                i += 1  # skip closing ```
                code_text = "\n".join(code_lines)
                flowables.append(Spacer(1, 4))
                flowables.append(Preformatted(code_text, styles["code_block"]))
                flowables.append(Spacer(1, 4))
                continue

            # ── skip empty lines ─────────────────────────────────────────────
            clean = line.strip()
            if not clean:
                i += 1
                continue

            # ── bullet ───────────────────────────────────────────────────────
            if clean.startswith("-"):
                content = clean[1:].strip()
                content = _escape(content)
                content = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', content)
                content = re.sub(r'`([^`]+)`',
                    lambda m: f'<font name="Courier" size="10" color="#c7254e">{_escape(m.group(1))}</font>',
                    content)
                flowables.append(Paragraph(f"• {content}", styles["bullet"]))
                i += 1
                continue

            # ── plain body (with inline bold + inline code) ──────────────────
            content = _escape(clean)
            content = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', content)
            content = re.sub(r'`([^`]+)`',
                lambda m: f'<font name="Courier" size="10" color="#c7254e">{_escape(m.group(1))}</font>',
                content)
            # strip leftover lone asterisks
            content = content.replace("**", "").replace("*", "")
            flowables.append(Paragraph(content, styles["body"]))
            i += 1

        return flowables

    story = [
        Paragraph(f"Repo Analysis Report ({_language})", styles["title"]),
        Paragraph(
            "Automated technical audit generated using AI-assisted repository analysis.",
            styles["body"]
        ),
        Spacer(1, 12),
    ]

    for section in text.split("###"):
        lines = section.splitlines()
        if not lines:
            continue
        heading = lines[0].strip()
        if not heading:
            continue

        story.append(HRFlowable(width="100%", thickness=1, color=colors.grey))
        story.append(Spacer(1, 6))
        story.append(Paragraph(f"<b>{heading}</b>", styles["head"]))
        story.extend(_parse_section_body(lines[1:]))
        story.append(Spacer(1, 10))

    doc = SimpleDocTemplate(
        "output/report.pdf",
        rightMargin=40,
        leftMargin=40,
        topMargin=50,
        bottomMargin=40
    )
    doc.build(story)
    console.print(f"📄 Saved {os.path.abspath('output/report.pdf')}", style="bold green")