import os
import click
from dotenv import load_dotenv
from . import corelogic as core
from . import context_export as ctx
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import track
from rich import print as rprint

from . import animations


console = Console()

load_dotenv()


@click.group()
@click.version_option("0.2.9", prog_name="gitputra")
def main():
    """🔍 Gitputra — AI-powered GitHub repo analyzer."""
    pass


# ─────────────────────────────────────────────
# ANALYZE
# ─────────────────────────────────────────────
@main.command()
@click.argument("url", default=".")
@click.option("--branch", default=None, help="Branch to clone (default: repo default branch). Ignored with --local.")
@click.option(
    "--ai", "ai_choice",
    type=click.Choice(["gemini", "openai", "none"], case_sensitive=False),
    default="none", show_default=True,
    help="AI provider to use."
)
@click.option(
    "--key",
    envvar="API_KEY", default=None,
    help="API key (or set API_KEY in .env). Avoid passing directly to keep it out of shell history."
)
@click.option(
    "--lang", default="English", show_default=True,
    help="Output language for the report."
)
@click.option(
    "--no-pdf", is_flag=True, default=False,
    help="Skip PDF generation."
)
@click.option(
    "--no-diagram", is_flag=True, default=False,
    help="Skip diagram generation."
)
@click.option(
    "--local", is_flag=True, default=False,
    help="Analyze a local directory instead of cloning a GitHub URL."
)
def analyze(url, branch, ai_choice, key, lang, no_pdf, no_diagram, local):
    """Clone a GitHub repo and generate an AI analysis report.

    \b
    Remote repo:
        gitputra analyze https://github.com/user/repo --ai gemini --key AIza...
    \b
    Local codebase:
        gitputra analyze ./my-project --local --ai gemini --key AIza...
        gitputra analyze "C:\\path\\with spaces\\project" --local --ai gemini --key AIza...
    """
    ai_enabled = ai_choice.lower() != "none"
    if ai_enabled:
        if not key:
            key = click.prompt("🔑 Enter API key (input hidden, press Enter when done)", hide_input=True)
            console.print("🔐 Key received", style="dim")
        
        # Initialize AI providers (gemini/openai) so we don't get a KeyError
        core.init(ai_choice.lower(), key, lang)

    if local:
        repo_path = os.path.abspath(url.strip())
        repo_name = os.path.basename(repo_path)
        if not os.path.isdir(repo_path):
            console.print(f"❌ Directory not found: {repo_path}", style="bold red")
            raise SystemExit(1)
        console.print(f"📂 Analyzing local directory: {repo_path}", style="bold cyan")
    else:
        repo_path, repo_name = core.clone_repo(url, branch)

    files = core.load_files(repo_path)

    if not files:
        console.print("❌ No supported source files found.", style="bold red")
        raise SystemExit(1)

    collection = core.get_collection(repo_name, branch)
    core.store_chunks(files, repo_name, branch)
    analysis = core.analyze_repo(files)

    console.print(Panel.fit(analysis, title="🔍 Analysis Report", border_style="green"))

    if not no_diagram:
        core.generate_diagram(files)
        core.generate_diagram_crossmodule(files)
        core.generate_diagram_modules(files)
        core.generate_mermaid(files)

    if not no_pdf:
        core.generate_pdf(analysis)

    console.print(f"✅ Done! Outputs saved in {os.path.abspath('output/')}", style="bold green")


# ─────────────────────────────────────────────
# CHAT
# ─────────────────────────────────────────────
@main.command()
@click.argument("url", default=".")
@click.option("--branch", default=None, help="Branch to clone (default: repo default branch). Ignored with --local.")
@click.option(
    "--ai", "ai_choice",
    type=click.Choice(["gemini", "openai"], case_sensitive=False),
    default="gemini", show_default=True,
)
@click.option(
    "--key",
    envvar="API_KEY", default=None,
    help="API key (or set API_KEY in .env). Avoid passing directly to keep it out of shell history."
)
@click.option("--lang", default="English", show_default=True)
@click.option(
    "--local", is_flag=True, default=False,
    help="Chat about a local directory instead of cloning a GitHub URL."
)
def chat(url, branch, ai_choice, key, lang, local):
    """Start an interactive RAG chat about a repo.

    \b
    Remote repo:
        gitputra chat https://github.com/user/repo --ai gemini
    \b
    Local codebase:
        gitputra chat ./my-project --local --ai gemini --key AIza...
        Type 'exit' or Ctrl+C to quit.
    """
    if not key:
        key = click.prompt("🔑 Enter API key (input hidden, press Enter when done)", hide_input=True)
        console.print("🔐 Key received", style="dim")
    core.init(ai_choice.lower(), key, lang)

    if local:
        repo_path = os.path.abspath(url.strip())
        repo_name = os.path.basename(repo_path)
        if not os.path.isdir(repo_path):
            console.print(f"❌ Directory not found: {repo_path}", style="bold red")
            raise SystemExit(1)
        console.print(f"📂 Using local directory: {repo_path}", style="bold cyan")
    else:
        repo_path, repo_name = core.clone_repo(url, branch)

    files = core.load_files(repo_path)
    if not files:
        console.print("❌ No supported source files found.", style="bold red")
        raise SystemExit(1)
    core.store_chunks(files, repo_name, branch)
    
    console.print(f"\n💬 Chat mode [{repo_name}] — ask anything about the codebase. Type 'exit' to quit.\n", style="bold cyan")

    history = []

    ext = "NAMASKAR"

    while True:
        try:
            question = console.input("[bold cyan]>> [/bold cyan]")
        except (KeyboardInterrupt, click.Abort):
            console.print(f"[bold yellow]{ext}[/bold yellow]")
            break

        if question.strip().lower() in ("exit", "quit", "q"):
            console.print(f"[bold yellow]{ext}[/bold yellow]")
            break

        if not question.strip():
            continue

        if question.strip().lower() == "!switch":
            load_dotenv(override=True)
            new_key = os.getenv("API_KEY")
            if not new_key:
                console.print("❌ No API_KEY found in .env", style="bold red")
                continue
            core.init(ai_choice.lower(), new_key, lang)
            console.print("✅ Key reloaded, quota reset. Chat history preserved.", style="bold green")
            continue

        answer = core.query_rag(question, repo_name, branch, history=history)
        console.print(f"\n[bold green]◈[/bold green] {answer}\n")

        # append to history
        history.append({"role": "user",      "content": question})
        history.append({"role": "assistant", "content": answer})


# ─────────────────────────────────────────────
# EXPORT CONTEXT
# ─────────────────────────────────────────────
@main.command("export-context")
@click.argument("project_path", default=".", metavar="PROJECT_PATH", type=click.Path())
@click.option("--remote", is_flag=True, default=False,
              help="Treat PROJECT_PATH as a GitHub URL and clone it first.")
@click.option("--branch", default=None,
              help="Branch to clone (only used with --remote).")
@click.option("--use-ai", "use_ai", is_flag=True, default=False,
              help="Generate deep AI summaries (requires --ai and --key).")
@click.option(
    "--ai", "ai_choice",
    type=click.Choice(["gemini", "openai"], case_sensitive=False),
    default="gemini", show_default=True,
    help="AI provider (only used with --use-ai)."
)
@click.option("--key", envvar="API_KEY", default=None,
              help="API key (or set API_KEY in .env). Only used with --use-ai.")
@click.option("--lang", default="English", show_default=True,
              help="Language for AI summaries (only used with --use-ai).")
def export_context_cmd(project_path, remote, branch, use_ai, ai_choice, key, lang):
    """Export a portable context .md from a local or remote codebase.
 
    Fully offline by default — scans files, builds a functionality graph
    (module deps + function call map), and writes a single Markdown file
    you can paste into any AI tool to resume work instantly.
 
    Add --use-ai to also generate deep per-file summaries and a project
    synthesis via the chosen AI provider.
 
    \b
    Examples:
        gitputra export-context                                    (current dir, offline)
        gitputra export-context ./my-project                      (offline)
        gitputra export-context ./my-project --use-ai --key AIza...
        gitputra export-context https://github.com/u/r --remote --use-ai --key AIza...
        gitputra export-context "C:\\path\\with spaces\\proj"     (quote paths with spaces)
    """
 
    if remote:
        project_path, _ = core.clone_repo(project_path, branch)
 
    gen_fn = None
    if use_ai:
        if not key:
            key = click.prompt("🔑 Enter API key (input hidden, press Enter when done)", hide_input=True)
        core.init(ai_choice.lower(), key, lang)
        gen_fn = core.safe_generate
 
    ctx.export_context(
        project_path     = project_path,
        safe_generate_fn = gen_fn,
        language         = lang,
        use_ai           = use_ai,
    )
# ─────────────────────────────────────────────
# CLEAR DB
# ─────────────────────────────────────────────
@main.command("clear-db")
def clear_db():
    """Wipe the local ChromaDB collection."""
    import chromadb
    animations.play_clear_db_vortex(frames=40, delay=0.05)
    client = chromadb.PersistentClient(path="./chroma_db")
    for col in client.list_collections():
        client.delete_collection(col.name)
    
    # Also wipe hash sidecars so next run re-indexes from scratch
    for f in os.listdir("./chroma_db"):
        if f.endswith("_hashes.json"):
            os.remove(os.path.join("./chroma_db", f))
    
    console.print("🗑️  ChromaDB cleared.", style="bold yellow")
# ─────────────────────────────────────────────
# INFORMATION
# ─────────────────────────────────────────────
@main.command()
def info():
    """Show supported AIs, languages, extensions, and commands."""
    animations.play_info_intro()
    # console.print("\n")
    # console.print("   ██████╗ ██╗████████╗██████╗ ██╗   ██╗████████╗██████╗  █████╗ ", style="bold red")
    # console.print("  ██╔════╝ ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝██╔══██╗██╔══██╗", style="bold red")
    # console.print("  ██║  ███╗██║   ██║   ██████╔╝██║   ██║   ██║   ██████╔╝███████║", style="bold yellow")
    # console.print("  ██║   ██║██║   ██║   ██╔═══╝ ██║   ██║   ██║   ██╔══██╗██╔══██║", style="bold blue")
    # console.print("  ╚██████╔╝██║   ██║   ██║     ╚██████╔╝   ██║   ██║  ██║██║  ██║", style="bold blue")
    # console.print("   ╚═════╝ ╚═╝   ╚═╝   ╚═╝      ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝", style="bold yellow")
    # console.print("\n ◈ GitPutra — Analyze • Visualize • Synthesize ", style="bold cyan")
    
    


    table = Table(title="📦 GitPutra Info", show_lines=True)

    table.add_column("Field", style="cyan", no_wrap=True)
    table.add_column("Details", style="yellow")

    table.add_row("🤖 Description", "[bold magenta]Chat with your codebase using Gemini or OpenAI[/bold magenta]")
    table.add_row("🏷️ Version", "[bold magenta]0.2.9[/bold magenta]")
    table.add_row("👨‍💻 Author", "[bold bright_blue]   Adityava Gangopadhyay[/bold bright_blue]")
    table.add_row("💼 Email", "[bold bright_blue]adityava49cse@gmail.com[/bold bright_blue]")
    table.add_row("🔗 LinkedIn", "[bold #FFA500]https://www.linkedin.com/in/adityava-gangopadhyay/[/bold #FFA500]")
    table.add_row("📦 Project URL", "[bold #FFA500]https://pypi.org/project/gitputra/[/bold #FFA500]")

    console.print(table)
    
    console.print("   💬 Special Message-> Feel free to contact for any suggestion or issues\n", style="bold blue")
    
    console.print("📦 Commands:", style="bold yellow")
   
    console.print("[bold orange1]analyze <url>[/bold orange1]", " || ", "[bold bright_blue]Clone & analyze a remote GitHub repo without AI[/bold bright_blue]", style="bold blue"),
    console.print("[bold orange1]analyze <url> --ai ai_name[/bold orange1]", " || ", "[bold bright_blue]Clone & analyze a remote GitHub repo with AI insights[/bold bright_blue]", style="bold blue"),
    console.print("[bold orange1]analyze <path> --local[/bold orange1]", " || ", "[bold bright_blue]Analyze a local codebase (no cloning)[/bold bright_blue]", style="bold blue"),
    console.print("[bold orange1]analyze <path> --local --ai ai_name[/bold orange1]", " || ", "[bold bright_blue]Analyze a local codebase (no cloning) with AI insights[/bold bright_blue]", style="bold blue"),
    console.print("[bold orange1]chat <url> --ai ai_name[/bold orange1]", " || ", "[bold bright_blue]Chat with AI_Putra about a remote GitHub repo[/bold bright_blue]", style="bold blue"),
    console.print("[bold orange1]chat <path> --local --ai ai_name[/bold orange1]", " || ", "[bold bright_blue]Chat  about a local codebase [/bold bright_blue]", style="bold blue"),
    console.print("[bold orange1]export-context[/bold orange1]", " || ", "[bold bright_blue]Export portable context of the present working directory .md (AI off by default)[/bold bright_blue]", style="bold blue"),
    console.print("[bold orange1]export-context <path>[/bold orange1]", " || ", "[bold bright_blue]Export context .md from local dir in <path> (AI off by default)[/bold bright_blue]", style="bold blue"),
    console.print("[bold orange1]export-context <url> --remote[/bold orange1]", " || ", "[bold bright_blue]Export context .md from remote GitHub repo[/bold bright_blue]", style="bold blue"),
    console.print("[bold orange1]clear-db[/bold orange1]", " || ", "[bold bright_blue]Wipe the local ChromaDB index[/bold bright_blue]", style="bold blue"),
    console.print("[bold orange1]info[/bold orange1]", " || ", "[bold bright_blue]Show this info screen[/bold bright_blue]", style="bold blue"),

    console.print("\n🤖 Supported AI Providers:", style="bold yellow")
    ais = [
        ("gemini", "Google Gemini 2.5 Flash",    "gemini-embedding-001"),
        ("openai", "OpenAI GPT-4o Mini",          "text-embedding-3-large"),
    ]
    ai_table = Table(title="🤖 Supported AI Providers")

    ai_table.add_column("Flag", style="cyan")
    ai_table.add_column("Model", style="green")
    ai_table.add_column("Embedding", style="magenta")

    for flag, model, embed in ais:
        ai_table.add_row(flag, model, embed)

    console.print(ai_table)

    table = Table(title="🌍 PDF Output Languages (~110 supported)", show_lines=True)

    table.add_column("Script", style="bold cyan", no_wrap=True)
    table.add_column("Languages", style="white")

    latin = [
        "English", "French", "Spanish", "Portuguese", "Italian", "German",
        "Dutch", "Swedish", "Norwegian", "Danish", "Finnish", "Polish",
        "Czech", "Slovak", "Hungarian", "Romanian", "Croatian", "Serbian (Latin)",
        "Slovenian", "Albanian", "Lithuanian", "Latvian", "Estonian",
        "Turkish", "Azerbaijani", "Uzbek", "Kazakh (Latin)", "Turkmen",
        "Indonesian", "Malay", "Filipino", "Swahili", "Zulu", "Xhosa",
        "Afrikaans", "Yoruba", "Igbo", "Hausa", "Somali", "Kinyarwanda",
        "Welsh", "Irish", "Basque", "Catalan", "Galician", "Maltese",
        "Icelandic", "Faroese", "Vietnamese", "Hawaiian", "Maori",
        "Tok Pisin", "Tswana", "Shona", "Sesotho",
    ]

    bangla = ["Bangla", "Assamese"]

    devanagari = ["Hindi", "Marathi", "Nepali", "Sanskrit", "Maithili", "Konkani", "Bodo", "Dogri"]

    # Join nicely instead of manual spacing gymnastics
    table.add_row("Latin script", ", ".join(latin))
    table.add_row("Bangla script", " | ".join(bangla))
    table.add_row("Devanagari script", " | ".join(devanagari))

    console.print(table)

    console.print("\n(AI response language depends on the chosen model's capability)\n\n", style="dim")

    ext_table = Table(title=f"📁 Supported File Extensions ({len(core.SUPPORTED_EXT)} types)")
    ext_table.add_column("Extensions", style="cyan", overflow="fold")
    exts = sorted(core.SUPPORTED_EXT) 
    chunk_size = 10
    for i in range(0, len(exts), chunk_size):
        ext_table.add_row(", ".join(exts[i:i+chunk_size]))

    console.print(ext_table)


    console.print("\n[bold blue]AI is ARTIFICIALLY Intelligent[/bold blue], \n[bold yellow]YOU are NATURALLY WISE,[/bold yellow] \nuse the tool but try to keep track on the correctness of the results produced", style="bold red") 

    console.print("\n\nTHANK YOU FOR USING GITPUTRA", style="bold orange1")

    click.echo()