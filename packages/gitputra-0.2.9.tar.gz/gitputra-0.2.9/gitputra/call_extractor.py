"""
call_extractor.py
=================
Shared call-graph extraction for GitPutra.

Used by both corelogic.py and context_export.py — single source of truth.

Strategy
--------
- Python, JS/TS/TSX/JSX, C, C++, Go, Rust, Java  →  Tree-sitter (precise AST)
- Everything else                                  →  regex fallback

Public API
----------
    extract_calls(fname: str, content: str) -> dict[str, set[str]]

Returns a mapping of  "module.function_name"  →  {called_short_names}.
"""

import os
import re
import ast as pyast

# ── Tree-sitter languages ─────────────────────────────────────────────────────
import tree_sitter_python     as _tspy
import tree_sitter_javascript as _tsjs
import tree_sitter_typescript as _tsts
import tree_sitter_c          as _tsc
import tree_sitter_cpp        as _tscpp
import tree_sitter_go         as _tsgo
import tree_sitter_rust       as _tsrs
import tree_sitter_java       as _tsjava
from tree_sitter import Language, Parser

# Build Language objects once at import time
_LANGS = {
    ".py":   Language(_tspy.language()),
    ".js":   Language(_tsjs.language()),
    ".jsx":  Language(_tsjs.language()),
    ".ts":   Language(_tsts.language_typescript()),
    ".tsx":  Language(_tsts.language_tsx()),
    ".c":    Language(_tsc.language()),
    ".h":    Language(_tsc.language()),
    ".cpp":  Language(_tscpp.language()),
    ".cc":   Language(_tscpp.language()),
    ".cxx":  Language(_tscpp.language()),
    ".go":   Language(_tsgo.language()),
    ".rs":   Language(_tsrs.language()),
    ".java": Language(_tsjava.language()),
}

# ── Regex fallback patterns ───────────────────────────────────────────────────
# (def_pattern, call_pattern)  — for languages not covered by Tree-sitter
_REGEX_PATTERNS: dict[str, tuple[str, str]] = {
    ".rb":    (r"^def (\w+)",                                               r"(\w+)\s*[\(\s]"),
    ".php":   (r"function (\w+)\s*\(",                                      r"(\w+)\s*\("),
    ".swift": (r"func (\w+)\s*\(",                                          r"(\w+)\s*\("),
    ".kt":    (r"fun (\w+)\s*\(",                                           r"(\w+)\s*\("),
    ".kts":   (r"fun (\w+)\s*\(",                                           r"(\w+)\s*\("),
    ".scala": (r"def (\w+)\s*[\(\[]",                                       r"(\w+)\s*\("),
    ".lua":   (r"function (\w+)\s*\(",                                      r"(\w+)\s*\("),
    ".cs":    (r"(?:public|private|protected|static|\s)+\w+\s+(\w+)\s*\(", r"(\w+)\s*\("),
    ".groovy":(r"def (\w+)\s*\(",                                           r"(\w+)\s*\("),
    ".pl":    (r"^sub (\w+)",                                               r"(\w+)\s*\("),
    ".sh":    (r"^(\w+)\s*\(\s*\)",                                         r"(\w+)\s"),
    ".bash":  (r"^(\w+)\s*\(\s*\)",                                         r"(\w+)\s"),
}

_IGNORE_CALLS: frozenset[str] = frozenset({
    # universal
    "if", "for", "while", "switch", "return", "print", "len", "range",
    "str", "int", "float", "bool", "list", "dict", "set", "tuple",
    "new", "this", "self", "super", "null", "true", "false", "None",
    "console", "log", "err", "error", "fmt", "append", "make",
    "require", "import", "include", "define", "typeof", "instanceof",
    "assert", "raise", "yield", "lambda", "class", "pass", "break",
    "continue", "del", "with", "as", "from", "not", "and", "or", "in",
    "var", "let", "const", "void", "static", "public", "private",
    "protected", "async", "await", "throw", "try", "catch", "finally",
    "delete", "typeof", "instanceof", "of", "export", "default",
    # Ruby / Perl keywords that bleed through regex
    "def", "end", "do", "puts", "sub", "use", "my", "our", "local",
    # Kotlin / Scala
    "fun", "val", "object", "when", "data",
    # Go
    "func", "type", "package", "defer", "go", "chan", "map", "select",
    # Rust
    "fn", "let", "mut", "impl", "trait", "struct", "enum", "mod", "use",
    "match", "where", "pub", "crate",
    # Shell
    "echo", "exit", "source", "cd", "export", "read",
})


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def extract_calls(fname: str, content: str) -> dict[str, set[str]]:
    """
    Extract intra-file function definitions and the names they call.

    Returns:
        { "module.func_name": {called_short_name, ...}, ... }

    The module prefix is the file stem (no extension, no path).
    """
    ext = os.path.splitext(fname)[1].lower()
    module = os.path.splitext(os.path.basename(fname))[0]

    if ext in _LANGS:
        return _ts_extract(module, ext, content)

    if ext in _REGEX_PATTERNS:
        return _regex_extract(module, ext, content)

    return {}


# ─────────────────────────────────────────────────────────────────────────────
# TREE-SITTER EXTRACTION
# ─────────────────────────────────────────────────────────────────────────────

def _ts_extract(module: str, ext: str, content: str) -> dict[str, set[str]]:
    lang   = _LANGS[ext]
    parser = Parser(lang)
    tree   = parser.parse(content.encode("utf-8", errors="replace"))
    root   = tree.root_node

    if ext == ".py":
        return _py_extract(module, root)
    elif ext in (".js", ".jsx", ".ts", ".tsx"):
        return _js_extract(module, root)
    elif ext in (".c", ".h"):
        return _c_extract(module, root)
    elif ext in (".cpp", ".cc", ".cxx"):
        return _cpp_extract(module, root)
    elif ext == ".go":
        return _go_extract(module, root)
    elif ext == ".rs":
        return _rs_extract(module, root)
    elif ext == ".java":
        return _java_extract(module, root)
    return {}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _text(node) -> str:
    return node.text.decode("utf-8", errors="replace") if node else ""


def _walk(node, visitor, state=None):
    """Generic depth-first walker. visitor(node, state) → new_state."""
    new_state = visitor(node, state)
    for child in node.children:
        _walk(child, visitor, new_state)


def _callee_name(call_node, func_field: str = "function",
                  id_types: tuple = ("identifier",),
                  member_types: tuple = ("member_expression", "attribute"),
                  attr_field: str = "property") -> str | None:
    """
    Extract the short callee name from a call node.
    Works for JS/TS/Go/C/C++/Rust patterns.
    """
    fn = call_node.child_by_field_name(func_field)
    if fn is None:
        # fall back to first named child
        fn = next((c for c in call_node.children if c.is_named), None)
    if fn is None:
        return None

    if fn.type in id_types:
        return _text(fn)

    # method / member call  →  take the rightmost identifier
    if fn.type in member_types:
        attr = fn.child_by_field_name(attr_field)
        if attr:
            return _text(attr)
        # fallback: last identifier child
        ids = [c for c in fn.children if c.type in id_types]
        return _text(ids[-1]) if ids else None

    return None


# ── Python ────────────────────────────────────────────────────────────────────

def _py_extract(module: str, root) -> dict[str, set[str]]:
    """
    Use Python's stdlib ast for maximum accuracy (handles decorators,
    walrus operator, comprehensions, etc. correctly).
    Falls back to tree-sitter walk if ast.parse fails (syntax errors).
    """
    source = _text(root)
    try:
        tree = pyast.parse(source)
    except SyntaxError:
        return _py_ts_fallback(module, root)

    results: dict[str, set[str]] = {}

    for node in pyast.walk(tree):
        if isinstance(node, (pyast.FunctionDef, pyast.AsyncFunctionDef)):
            full = f"{module}.{node.name}"
            called: set[str] = set()
            for child in pyast.walk(node):
                if isinstance(child, pyast.Call):
                    if isinstance(child.func, pyast.Name):
                        called.add(child.func.id)
                    elif isinstance(child.func, pyast.Attribute):
                        called.add(child.func.attr)
            results[full] = called - _IGNORE_CALLS

    return results


def _py_ts_fallback(module: str, root) -> dict[str, set[str]]:
    results: dict[str, set[str]] = {}

    def _collect(node, current_func: str | None):
        if node.type == "function_definition":
            name_node = node.child_by_field_name("name")
            if name_node:
                current_func = f"{module}.{_text(name_node)}"
                results.setdefault(current_func, set())
        elif node.type == "call" and current_func:
            fn = node.child_by_field_name("function")
            if fn:
                name = None
                if fn.type == "identifier":
                    name = _text(fn)
                elif fn.type == "attribute":
                    attr = fn.child_by_field_name("attribute")
                    if attr:
                        name = _text(attr)
                if name and name not in _IGNORE_CALLS:
                    results[current_func].add(name)
        for child in node.children:
            _collect(child, current_func)  # passes current_func down, not a shared stack

    _collect(root, None)
    return results


# ── JavaScript / TypeScript ───────────────────────────────────────────────────

_JS_FUNC_TYPES = {
    "function_declaration",
    "function",                   # anonymous function expression
    "arrow_function",
    "method_definition",
    "generator_function_declaration",
    "generator_function",
}

def _js_extract(module: str, root) -> dict[str, set[str]]:
    results: dict[str, set[str]] = {}

    def _func_name(node) -> str | None:
        """Best-effort name for a JS/TS function node."""
        # function_declaration / method_definition have a 'name' field
        n = node.child_by_field_name("name")
        if n:
            return _text(n)
        # arrow_function assigned to variable:  const foo = () => ...
        # parent is variable_declarator → its 'name' field
        parent = node.parent
        if parent and parent.type == "variable_declarator":
            n = parent.child_by_field_name("name")
            if n:
                return _text(n)
        return None

    def _collect(node, current_func: str | None):
        if node.type in _JS_FUNC_TYPES:
            name = _func_name(node)
            if name:
                current_func = f"{module}.{name}"
                results.setdefault(current_func, set())

        if node.type == "call_expression" and current_func:
            fn = node.child_by_field_name("function")
            if fn:
                name = None
                if fn.type == "identifier":
                    name = _text(fn)
                elif fn.type == "member_expression":
                    prop = fn.child_by_field_name("property")
                    if prop:
                        name = _text(prop)
                if name and name not in _IGNORE_CALLS:
                    results[current_func].add(name)

        for child in node.children:
            _collect(child, current_func)

    _collect(root, None)
    return results


# ── C ─────────────────────────────────────────────────────────────────────────

def _c_extract(module: str, root) -> dict[str, set[str]]:
    results: dict[str, set[str]] = {}

    def _collect(node, current_func: str | None):
        if node.type == "function_definition":
            # declarator → function_declarator → identifier
            decl = node.child_by_field_name("declarator")
            name = _find_func_name_c(decl)
            if name:
                current_func = f"{module}.{name}"
                results.setdefault(current_func, set())

        if node.type == "call_expression" and current_func:
            fn = node.child_by_field_name("function")
            if fn:
                name = None
                if fn.type == "identifier":
                    name = _text(fn)
                elif fn.type == "field_expression":
                    field = fn.child_by_field_name("field")
                    if field:
                        name = _text(field)
                if name and name not in _IGNORE_CALLS:
                    results[current_func].add(name)

        for child in node.children:
            _collect(child, current_func)

    _collect(root, None)
    return results


def _find_func_name_c(node) -> str | None:
    """Recursively find the identifier inside a C declarator chain."""
    if node is None:
        return None
    if node.type == "identifier":
        return _text(node)
    if node.type in ("function_declarator", "pointer_declarator",
                      "abstract_function_declarator"):
        decl = node.child_by_field_name("declarator")
        return _find_func_name_c(decl)
    # fallback: search children
    for child in node.children:
        found = _find_func_name_c(child)
        if found:
            return found
    return None


# ── C++ ───────────────────────────────────────────────────────────────────────

def _cpp_extract(module: str, root) -> dict[str, set[str]]:
    """C++ — same as C but also handles qualified names and scoped calls."""
    results: dict[str, set[str]] = {}

    def _collect(node, current_func: str | None):
        if node.type == "function_definition":
            decl = node.child_by_field_name("declarator")
            name = _find_func_name_c(decl)
            if name:
                current_func = f"{module}.{name}"
                results.setdefault(current_func, set())

        if node.type == "call_expression" and current_func:
            fn = node.child_by_field_name("function")
            if fn:
                name = None
                if fn.type == "identifier":
                    name = _text(fn)
                elif fn.type == "field_expression":
                    field = fn.child_by_field_name("field")
                    if field:
                        name = _text(field)
                elif fn.type == "qualified_identifier":
                    # ns::func  →  take the last identifier
                    ids = [c for c in fn.children if c.type == "identifier"]
                    if ids:
                        name = _text(ids[-1])
                elif fn.type == "template_function":
                    n = fn.child_by_field_name("name")
                    if n:
                        name = _text(n)
                if name and name not in _IGNORE_CALLS:
                    results[current_func].add(name)

        for child in node.children:
            _collect(child, current_func)

    _collect(root, None)
    return results


# ── Go ────────────────────────────────────────────────────────────────────────

def _go_extract(module: str, root) -> dict[str, set[str]]:
    results: dict[str, set[str]] = {}

    def _collect(node, current_func: str | None):
        if node.type == "function_declaration":
            n = node.child_by_field_name("name")
            if n:
                current_func = f"{module}.{_text(n)}"
                results.setdefault(current_func, set())

        # method_declaration  (receiver func)
        if node.type == "method_declaration":
            n = node.child_by_field_name("name")
            if n:
                current_func = f"{module}.{_text(n)}"
                results.setdefault(current_func, set())

        if node.type == "call_expression" and current_func:
            fn = node.child_by_field_name("function")
            if fn:
                name = None
                if fn.type == "identifier":
                    name = _text(fn)
                elif fn.type == "selector_expression":
                    field = fn.child_by_field_name("field")
                    if field:
                        name = _text(field)
                if name and name not in _IGNORE_CALLS:
                    results[current_func].add(name)

        for child in node.children:
            _collect(child, current_func)

    _collect(root, None)
    return results


# ── Rust ──────────────────────────────────────────────────────────────────────

def _rs_extract(module: str, root) -> dict[str, set[str]]:
    results: dict[str, set[str]] = {}

    def _collect(node, current_func: str | None):
        if node.type == "function_item":
            n = node.child_by_field_name("name")
            if n:
                current_func = f"{module}.{_text(n)}"
                results.setdefault(current_func, set())

        if node.type == "call_expression" and current_func:
            fn = node.child_by_field_name("function")
            if fn:
                name = None
                if fn.type == "identifier":
                    name = _text(fn)
                elif fn.type == "scoped_identifier":
                    # helper::run  →  last identifier
                    ids = [c for c in fn.children if c.type == "identifier"]
                    if ids:
                        name = _text(ids[-1])
                elif fn.type == "field_expression":
                    field = fn.child_by_field_name("field")
                    if field:
                        name = _text(field)
                if name and name not in _IGNORE_CALLS:
                    results[current_func].add(name)

        # method_call_expression  e.g. obj.method(args)
        if node.type == "method_call_expression" and current_func:
            n = node.child_by_field_name("method")
            if n:
                name = _text(n)
                if name and name not in _IGNORE_CALLS:
                    results[current_func].add(name)

        for child in node.children:
            _collect(child, current_func)

    _collect(root, None)
    return results


# ── Java ──────────────────────────────────────────────────────────────────────

def _java_extract(module: str, root) -> dict[str, set[str]]:
    results: dict[str, set[str]] = {}

    def _collect(node, current_func: str | None):
        if node.type == "method_declaration":
            n = node.child_by_field_name("name")
            if n:
                current_func = f"{module}.{_text(n)}"
                results.setdefault(current_func, set())

        if node.type == "method_invocation" and current_func:
            # simple call: multiply(a)  →  first identifier child is method name
            # object call: helper.run(a) → identifier after '.' is method name
            children = [c for c in node.children if c.is_named]
            name = None
            if children:
                # If there's a '.' the method name is the last identifier before args
                ids = [c for c in node.children if c.type == "identifier"]
                if ids:
                    name = _text(ids[-1])
            if name and name not in _IGNORE_CALLS:
                results[current_func].add(name)

        for child in node.children:
            _collect(child, current_func)

    _collect(root, None)
    return results


# ─────────────────────────────────────────────────────────────────────────────
# REGEX FALLBACK
# ─────────────────────────────────────────────────────────────────────────────

def _regex_extract(module: str, ext: str, content: str) -> dict[str, set[str]]:
    def_pat, call_pat = _REGEX_PATTERNS[ext]
    results: dict[str, set[str]] = {}
    current_func: str | None = None

    for line in content.splitlines():
        m = re.search(def_pat, line)
        if m:
            name = next((g for g in m.groups() if g), None) if m.lastindex else m.group(1)
            if name:
                current_func = f"{module}.{name}"
                results.setdefault(current_func, set())

        if current_func:
            for cm in re.finditer(call_pat, line):
                name = cm.group(1)
                if name and name not in _IGNORE_CALLS and name != current_func.split(".")[-1]:
                    results[current_func].add(name)

    return results