import { expect, type BrowserContext, type Page } from "@playwright/test";
import fs from "node:fs";

export function requireLiveEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing required env var: ${name}`);
  }
  return value;
}

export function readLivePassword(): string {
  return fs.readFileSync(requireLiveEnv("LIVE_ADMIN_PASSWORD_FILE"), "utf-8").trim();
}

export async function loginViaApi(context: BrowserContext, baseURL: string, password: string): Promise<void> {
  const response = await context.request.post(`${baseURL}/api/session/login`, {
    headers: {
      origin: baseURL,
      referer: `${baseURL}/`,
    },
    data: {
      username: process.env.LIVE_ADMIN_USER ?? "operator",
      password,
    },
  });
  expect(response.status(), await response.text()).toBe(200);
}

export function captureAdminTraffic(page: Page): { bodies: string[] } {
  const bodies: string[] = [];

  page.on("request", (request) => {
    if (!request.url().includes("/api/") || request.url().includes("/api/session/login")) {
      return;
    }
    const body = request.postData();
    if (body) {
      bodies.push(body);
    }
  });

  page.on("response", (response) => {
    if (!response.url().includes("/api/") || response.url().includes("/api/session/login")) {
      return;
    }
    void response
      .text()
      .then((body) => {
        if (body) {
          bodies.push(body);
        }
      })
      .catch(() => {});
  });

  return { bodies };
}

export async function assertNoBrowserSecretLeak(
  page: Page,
  trafficBodies: string[],
  secretValues: string[],
): Promise<void> {
  const storageDump = await page.evaluate(() =>
    JSON.stringify({
      localStorage: Object.fromEntries(Object.entries(window.localStorage)),
      sessionStorage: Object.fromEntries(Object.entries(window.sessionStorage)),
    }),
  );

  for (const secretValue of secretValues) {
    if (!secretValue) {
      continue;
    }
    expect(storageDump).not.toContain(secretValue);
    for (const body of trafficBodies) {
      expect(body).not.toContain(secretValue);
    }
  }
}
