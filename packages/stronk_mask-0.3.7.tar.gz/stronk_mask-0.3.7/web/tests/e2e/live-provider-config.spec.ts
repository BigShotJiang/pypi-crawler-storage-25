import { expect, test } from "@playwright/test";

import {
  assertNoBrowserSecretLeak,
  captureAdminTraffic,
  loginViaApi,
  readLivePassword,
} from "./live-bundle-helpers";

const baseURL = process.env.BASE_URL ?? "http://127.0.0.1:8788";

test.describe("@live provider config bundle flow", () => {
  test.skip(!process.env.LIVE_ADMIN_PASSWORD_FILE, "LIVE_ADMIN_PASSWORD_FILE is required for live bundle e2e");

  test("adds a provider, publishes an alias, and applies staged config through the real bundle", async ({
    browser,
  }) => {
    const adminPassword = readLivePassword();
    const providerBaseUrl = process.env.LIVE_PROVIDER_BASE_URL ?? "http://fake-openai-upstream:18080/v1";
    const providerSecretRef = process.env.LIVE_PROVIDER_SECRET_REF ?? "PROVIDER_DEFAULT_API_KEY";
    const providerSecretValue = process.env.LIVE_PROVIDER_SECRET_VALUE ?? "";
    const expectedModelId = process.env.LIVE_EXPECT_MODEL_ID ?? "gpt-4.1-mini";
    const suffix = String(Date.now()).slice(-6);
    const providerLabel = `Local Smoke Mirror ${suffix}`;
    const publicAlias = `stronk-live-${suffix}`;

    const context = await browser.newContext({ baseURL });
    await loginViaApi(context, baseURL, adminPassword);

    const page = await context.newPage();
    const traffic = captureAdminTraffic(page);

    await page.goto(`${baseURL}/providers`, { waitUntil: "domcontentloaded" });
    await page.getByRole("button", { name: "Add provider" }).click();
    await page.getByLabel("Label").fill(providerLabel);
    await page.getByLabel("Base URL").fill(providerBaseUrl);
    await page.getByLabel("Secret env var name").fill(providerSecretRef);
    await page.waitForTimeout(8_500);
    await expect(page.getByRole("heading", { name: "Add provider" })).toBeVisible();
    await expect(page.getByLabel("Label")).toHaveValue(providerLabel);
    await expect(page.getByLabel("Base URL")).toHaveValue(providerBaseUrl);
    await expect(page.getByLabel("Secret env var name")).toHaveValue(providerSecretRef);
    await page.getByRole("button", { name: "Save + Verify" }).click();

    await expect(page.getByRole("button", { name: new RegExp(providerLabel, "i") })).toBeVisible({
      timeout: 15000,
    });
    await expect(page.getByLabel("Base URL")).toHaveValue(providerBaseUrl);

    await page.getByRole("button", { name: /^Models\b/ }).click();
    await expect(page.getByRole("button", { name: new RegExp(providerLabel, "i") })).toBeVisible();
    await page.getByRole("button", { name: new RegExp(providerLabel, "i") }).click();
    await expect(page.getByRole("button", { name: new RegExp(expectedModelId, "i") })).toBeVisible({
      timeout: 15000,
    });
    await page.getByRole("button", { name: new RegExp(expectedModelId, "i") }).click();
    await page.getByLabel("Public alias").fill(publicAlias);
    await page.getByRole("button", { name: "Publish alias draft" }).click();

    await expect(page.getByText(publicAlias, { exact: false })).toBeVisible();
    await page.getByRole("button", { name: "Apply staged config" }).click();
    await expect(page.getByText("Staged config applied successfully")).toBeVisible({ timeout: 15000 });

    await assertNoBrowserSecretLeak(page, traffic.bodies, [providerSecretValue]);

    await context.close();
  });
});
