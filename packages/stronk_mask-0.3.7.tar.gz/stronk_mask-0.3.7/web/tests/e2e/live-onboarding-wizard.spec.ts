import { expect, test } from "@playwright/test";

import {
  assertNoBrowserSecretLeak,
  captureAdminTraffic,
  loginViaApi,
  readLivePassword,
} from "./live-bundle-helpers";

const baseURL = process.env.BASE_URL ?? "http://127.0.0.1:8788";

test.describe("@live onboarding wizard bundle flow", () => {
  test.skip(!process.env.LIVE_ADMIN_PASSWORD_FILE, "LIVE_ADMIN_PASSWORD_FILE is required for live bundle e2e");
  test.skip(process.env.LIVE_EXPECT_WIZARD !== "1", "LIVE_EXPECT_WIZARD=1 is required for the empty-bundle onboarding flow");

  test("completes the first-time onboarding wizard against the real bundle", async ({ browser }) => {
    const adminPassword = readLivePassword();
    const providerBaseUrl = process.env.LIVE_PROVIDER_BASE_URL ?? "http://fake-openai-upstream:18080/v1";
    const providerSecretRef = process.env.LIVE_PROVIDER_SECRET_REF ?? "PROVIDER_DEFAULT_API_KEY";
    const providerSecretValue = process.env.LIVE_PROVIDER_SECRET_VALUE ?? "";
    const expectedModelId = process.env.LIVE_EXPECT_MODEL_ID ?? "gpt-4.1-mini";
    const publicAlias = process.env.LIVE_PUBLIC_ALIAS ?? "stronk-lm";
    const suffix = String(Date.now()).slice(-6);
    const providerLabel = `Wizard Local Smoke ${suffix}`;

    const context = await browser.newContext({ baseURL });
    await loginViaApi(context, baseURL, adminPassword);

    const page = await context.newPage();
    const traffic = captureAdminTraffic(page);

    await page.goto(baseURL, { waitUntil: "domcontentloaded" });
    await expect(page.getByText("First-time setup wizard")).toBeVisible();
    await page.getByLabel("Label").fill(providerLabel);
    await page.getByLabel("Base URL").fill(providerBaseUrl);
    await page.getByLabel("Secret env var name").fill(providerSecretRef);
    await page.getByRole("button", { name: "Save + Verify" }).click();

    await expect(page.getByRole("button", { name: new RegExp(expectedModelId, "i") })).toBeVisible({ timeout: 15000 });
    await page.getByRole("button", { name: new RegExp(expectedModelId, "i") }).click();
    await page.getByLabel("Public alias").fill(publicAlias);
    await page.getByRole("button", { name: "Publish alias draft" }).click();

    await expect(page.getByRole("button", { name: "Publish alias" })).toBeVisible({ timeout: 15000 });
    await page.getByRole("button", { name: "Publish alias" }).click();
    await expect(page.getByText("Staged config applied successfully")).toBeVisible({ timeout: 15000 });

    await assertNoBrowserSecretLeak(page, traffic.bodies, [providerSecretValue]);

    await context.close();
  });
});
