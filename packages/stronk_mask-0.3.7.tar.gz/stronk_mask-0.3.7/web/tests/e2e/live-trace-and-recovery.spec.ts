import { expect, test, type BrowserContext } from "@playwright/test";
import fs from "node:fs";
import path from "node:path";

import { loginViaApi, readLivePassword, requireLiveEnv } from "./live-bundle-helpers";

const baseURL = process.env.BASE_URL ?? "http://127.0.0.1:8788";

type OperatorStateSummary = {
  providers: Array<{
    id: string;
    label: string;
    kind: string;
    base_url: string;
    secret_ref: string;
  }>;
};

async function adminJson<T>(
  context: BrowserContext,
  requestPath: string,
  options: {
    method?: "GET" | "POST" | "PUT";
    data?: Record<string, unknown>;
    okStatuses?: number[];
  } = {},
): Promise<T> {
  const response = await context.request.fetch(`${baseURL}${requestPath}`, {
    method: options.method ?? "GET",
    headers: {
      Accept: "application/json",
      Origin: baseURL,
      Referer: `${baseURL}/`,
      ...(options.data ? { "Content-Type": "application/json" } : {}),
    },
    data: options.data,
  });
  const okStatuses = new Set(options.okStatuses ?? [200]);
  expect(okStatuses.has(response.status()), await response.text()).toBe(true);
  return (await response.json()) as T;
}

async function sendPublicRequest(
  context: BrowserContext,
  publicBaseUrl: string,
  publicApiKey: string,
  publicAlias: string,
  content: string,
): Promise<void> {
  const response = await context.request.post(`${publicBaseUrl.replace(/\/+$/, "")}/chat/completions`, {
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${publicApiKey}`,
      "Content-Type": "application/json",
    },
    data: {
      model: publicAlias,
      messages: [{ role: "user", content }],
    },
  });
  expect(response.status(), await response.text()).toBe(200);
  expect(JSON.stringify(await response.json())).toContain(content);
}

async function findRequestIdByNeedle(context: BrowserContext, needle: string): Promise<string> {
  const traces = await adminJson<{ items: Array<{ request_id: string }> }>(context, "/api/debug/traces");
  for (const item of traces.items.slice(0, 10)) {
    const detail = await context.request.get(`${baseURL}/api/debug/traces/${encodeURIComponent(item.request_id)}`, {
      headers: {
        Accept: "application/json",
        Origin: baseURL,
        Referer: `${baseURL}/requests`,
      },
    });
    if (detail.status() !== 200) {
      continue;
    }
    if ((await detail.text()).includes(needle)) {
      return item.request_id;
    }
  }
  return "";
}

function backupFile(filePath: string): string {
  const today = new Date().toISOString().slice(0, 10);
  const backupDir = path.join(path.dirname(filePath), "backups", today);
  fs.mkdirSync(backupDir, { recursive: true });
  const backupPath = path.join(backupDir, `${path.basename(filePath)}.bak.${Date.now()}`);
  fs.copyFileSync(filePath, backupPath);
  return backupPath;
}

function replaceEnvValue(filePath: string, name: string, value: string): void {
  const source = fs.readFileSync(filePath, "utf-8");
  const pattern = new RegExp(`^${name}=.*$`, "m");
  if (!pattern.test(source)) {
    throw new Error(`Missing env var ${name} in ${filePath}`);
  }
  fs.writeFileSync(filePath, source.replace(pattern, `${name}=${value}`), "utf-8");
}

test.describe("@live trace and recovery bundle flow", () => {
  test.skip(!process.env.LIVE_ADMIN_PASSWORD_FILE, "LIVE_ADMIN_PASSWORD_FILE is required for live bundle e2e");

  test("captures a masked live trace through the real bundle", async ({ browser }) => {
    const adminPassword = readLivePassword();
    const publicBaseUrl = requireLiveEnv("LIVE_PUBLIC_BASE_URL");
    const publicApiKey = requireLiveEnv("LIVE_PUBLIC_API_KEY");
    const publicAlias = requireLiveEnv("LIVE_EXPECT_PUBLIC_ALIAS");
    const uniqueEmail = `p7-live-${Date.now()}@example.com`;

    const context = await browser.newContext({ baseURL });
    await loginViaApi(context, baseURL, adminPassword);

    await sendPublicRequest(
      context,
      publicBaseUrl,
      publicApiKey,
      publicAlias,
      `Reach me at ${uniqueEmail} for the stronk validation trace.`,
    );

    await expect
      .poll(async () => findRequestIdByNeedle(context, uniqueEmail), {
        timeout: 15000,
        message: `expected ${uniqueEmail} to appear in debug traces`,
      })
      .not.toBe("");

    const requestId = await findRequestIdByNeedle(context, uniqueEmail);
    const page = await context.newPage();
    await page.goto(`${baseURL}/requests/${encodeURIComponent(requestId)}`, { waitUntil: "domcontentloaded" });

    await expect(page.getByText("Content trace", { exact: true })).toBeVisible();
    await expect(page.getByText("Raw caller payload -> masked upstream payload")).toBeVisible();
    await expect(page.getByText("Provider placeholders -> caller-visible return")).toBeVisible();
    await expect(page.locator("code").filter({ hasText: uniqueEmail }).first()).toBeVisible();
    await expect(page.locator("code").filter({ hasText: /\[\[EMAIL_\d+\]\]/ }).first()).toBeVisible();
    await expect(page.getByText("/messages/#/content").first()).toBeVisible();

    await context.close();
  });

  test("shows apply failure and preserves the working runtime", async ({ browser }) => {
    const adminPassword = readLivePassword();
    const publicBaseUrl = requireLiveEnv("LIVE_PUBLIC_BASE_URL");
    const publicApiKey = requireLiveEnv("LIVE_PUBLIC_API_KEY");
    const publicAlias = requireLiveEnv("LIVE_EXPECT_PUBLIC_ALIAS");
    const failureMode = process.env.LIVE_FAILURE_MODE ?? (process.env.LIVE_BUNDLE_ENV_FILE ? "healthcheck" : "missing-secret");

    const context = await browser.newContext({ baseURL });
    await loginViaApi(context, baseURL, adminPassword);

    const state = await adminJson<OperatorStateSummary>(context, "/api/operator-state");
    const provider = state.providers[0];
    expect(provider).toBeTruthy();

    const page = await context.newPage();

    if (failureMode === "healthcheck") {
      const envFile = requireLiveEnv("LIVE_BUNDLE_ENV_FILE");
      const backupPath = backupFile(envFile);
      try {
        const updatedLabel = `${provider.label} Recovery ${String(Date.now()).slice(-6)}`;
        await adminJson(context, `/api/providers/${encodeURIComponent(provider.id)}`, {
          method: "PUT",
          data: {
            label: updatedLabel,
            base_url: provider.base_url,
            secret_ref: provider.secret_ref,
          },
        });

        await page.goto(`${baseURL}/providers`, { waitUntil: "domcontentloaded" });
        await page.getByRole("button", { name: "Apply staged config" }).click();
        // Force the health check to fail after backups are taken but before the probe executes.
        await page.waitForTimeout(600);
        replaceEnvValue(envFile, "STRONK_GATEWAY_PUBLIC_API_KEY", `broken-live-key-${Date.now()}`);

        await expect(page.getByText("Apply failed")).toBeVisible({ timeout: 15000 });
        await expect(page.getByRole("button", { name: "Rollback" })).toBeVisible();
        await page.getByRole("button", { name: "Rollback" }).click();
        await expect(page.getByText("Rollback restored the last working runtime.")).toBeVisible({
          timeout: 15000,
        });

        await sendPublicRequest(
          context,
          publicBaseUrl,
          publicApiKey,
          publicAlias,
          `runtime stayed healthy during rollback ${Date.now()}@example.com`,
        );
      } finally {
        fs.copyFileSync(backupPath, envFile);
      }
    } else {
      const missingSecretRef = `PROVIDER_MISSING_${String(Date.now()).slice(-6)}`;
      await adminJson(context, `/api/providers/${encodeURIComponent(provider.id)}`, {
        method: "PUT",
        data: {
          label: provider.label,
          base_url: provider.base_url,
          secret_ref: missingSecretRef,
        },
      });

      await page.goto(`${baseURL}/providers`, { waitUntil: "domcontentloaded" });
      await page.getByRole("button", { name: "Apply staged config" }).click();
      await expect(page.getByText("Apply failed")).toBeVisible({ timeout: 15000 });

      await sendPublicRequest(
        context,
        publicBaseUrl,
        publicApiKey,
        publicAlias,
        `runtime stayed healthy after failed validation ${Date.now()}@example.com`,
      );
    }

    await context.close();
  });
});
