import { useMemo } from "react";

import type { AuditEvent, DebugTrace, JsonValue } from "./types";

type DiffLineKind = "context" | "remove" | "add" | "fold";

type DiffLine = {
  key: string;
  kind: DiffLineKind;
  text: string;
  beforeLine: number | null;
  afterLine: number | null;
};

type DiffHunk = {
  path: string;
  beforeText: string;
  afterText: string;
  beforePlaceholderCount: number;
  afterPlaceholderCount: number;
  lines: DiffLine[];
};

const CONTEXT_LINES = 2;
const HUNK_LIMIT = 12;
const MISSING = Symbol("missing");
const PLACEHOLDER_PATTERN = /(?:__SM_[A-Za-z0-9]+__|\[\[[A-Z_]+_\d+\]\])/g;

type ComparableJsonValue = JsonValue | typeof MISSING;

export function DebugDiffDeck({
  trace,
  event,
}: {
  trace: DebugTrace;
  event: AuditEvent;
}) {
  const requestHunks = useMemo(
    () => collectChangedHunks(trace.request_original, trace.request_masked),
    [trace.request_masked, trace.request_original],
  );
  const responseHunks = useMemo(
    () => collectChangedHunks(trace.response_upstream, trace.response_rehydrated),
    [trace.response_rehydrated, trace.response_upstream],
  );

  return (
    <div className="unsafe-debug-panel">
      <div className="unsafe-banner">
        <span className="section-label">Content trace</span>
        <p>
          Authenticated operator trace. Diff hunks show the exact fields that changed during
          masking and rehydration, while the full payload snapshots stay behind a deliberate
          reveal.
        </p>
      </div>

      <div className="diff-deck">
        <DiffStage
          title="Masking diff"
          subtitle="Raw caller payload -> masked upstream payload"
          tone="masking"
          hunks={requestHunks}
          summary={`${event.placeholder_count} placeholders issued`}
          secondarySummary={`${requestHunks.length} changed fields`}
          pathChips={event.masked_paths}
          emptyMessage="No request-side text deltas were captured for this event."
        />
        <DiffStage
          title="Rehydration diff"
          subtitle="Provider placeholders -> caller-visible return"
          tone="rehydration"
          hunks={responseHunks}
          summary={`${event.rehydration_count} placeholder substitutions`}
          secondarySummary={`${responseHunks.length} changed fields`}
          emptyMessage="No response-side text deltas were captured for this event."
        />
      </div>

      <details className="raw-snapshots">
        <summary>Reveal raw payload snapshots</summary>
        <div className="unsafe-debug-grid">
          <DebugCard title="Original request" value={trace.request_original} />
          <DebugCard title="Masked upstream request" value={trace.request_masked} />
          <DebugCard title="Upstream response" value={trace.response_upstream} />
          <DebugCard title="Rehydrated return" value={trace.response_rehydrated} />
        </div>
      </details>
    </div>
  );
}

function DiffStage({
  title,
  subtitle,
  tone,
  hunks,
  summary,
  secondarySummary,
  pathChips = [],
  emptyMessage,
}: {
  title: string;
  subtitle: string;
  tone: "masking" | "rehydration";
  hunks: DiffHunk[];
  summary: string;
  secondarySummary: string;
  pathChips?: string[];
  emptyMessage: string;
}) {
  return (
    <section className={`diff-stage is-${tone}`}>
      <div className="diff-stage-header">
        <div>
          <span className="section-label">{title}</span>
          <h4>{subtitle}</h4>
        </div>
        <div className="diff-stage-meta">
          <span className="diff-chip">{summary}</span>
          <span className="diff-chip">{secondarySummary}</span>
        </div>
      </div>

      {pathChips.length ? (
        <div className="diff-paths">
          {pathChips.map((path) => (
            <span key={`${title}-${path}`} className="diff-path-chip">
              {path}
            </span>
          ))}
        </div>
      ) : null}

      {hunks.length ? (
        <div className="diff-stack">
          {hunks.map((hunk) => (
            <DiffHunkCard key={`${title}-${hunk.path}`} hunk={hunk} tone={tone} />
          ))}
        </div>
      ) : (
        <p className="microcopy">{emptyMessage}</p>
      )}
    </section>
  );
}

function DiffHunkCard({
  hunk,
  tone,
}: {
  hunk: DiffHunk;
  tone: "masking" | "rehydration";
}) {
  return (
    <article className={`diff-card is-${tone}`}>
      <div className="diff-card-header">
        <div>
          <span className="section-label">Changed field</span>
          <strong className="diff-card-path">{hunk.path}</strong>
        </div>
        <div className="diff-card-meta">
          {hunk.beforePlaceholderCount ? (
            <span className="diff-chip">{hunk.beforePlaceholderCount} placeholders before</span>
          ) : null}
          {hunk.afterPlaceholderCount ? (
            <span className="diff-chip">{hunk.afterPlaceholderCount} placeholders after</span>
          ) : null}
        </div>
      </div>

      <div className="diff-code">
        {hunk.lines.map((line) => (
          <div key={line.key} className={`diff-line diff-line-${line.kind}`}>
            <span className="diff-line-number">{line.beforeLine ?? ""}</span>
            <span className="diff-line-number">{line.afterLine ?? ""}</span>
            <span className="diff-line-prefix">{prefixForLine(line.kind)}</span>
            <code className="diff-line-text">{renderDiffText(line.text)}</code>
          </div>
        ))}
      </div>
    </article>
  );
}

function DebugCard({ title, value }: { title: string; value: JsonValue }) {
  return (
    <div className="debug-card">
      <span className="section-label">{title}</span>
      <pre>{formatDiffSnapshot(value)}</pre>
    </div>
  );
}

function collectChangedHunks(before: JsonValue, after: JsonValue): DiffHunk[] {
  const hunks: DiffHunk[] = [];
  visitChangedNodes(before, after, [], hunks);
  return hunks;
}

function visitChangedNodes(
  before: ComparableJsonValue,
  after: ComparableJsonValue,
  pathSegments: string[],
  collector: DiffHunk[],
): void {
  if (collector.length >= HUNK_LIMIT || nodesEqual(before, after)) {
    return;
  }

  if (Array.isArray(before) && Array.isArray(after)) {
    const length = Math.max(before.length, after.length);
    for (let index = 0; index < length; index += 1) {
      visitChangedNodes(
        index < before.length ? before[index] : MISSING,
        index < after.length ? after[index] : MISSING,
        [...pathSegments, String(index)],
        collector,
      );
      if (collector.length >= HUNK_LIMIT) {
        return;
      }
    }
    return;
  }

  if (isPlainObject(before) && isPlainObject(after)) {
    const keys = Array.from(new Set([...Object.keys(before), ...Object.keys(after)])).sort();
    for (const key of keys) {
      visitChangedNodes(
        key in before ? before[key] : MISSING,
        key in after ? after[key] : MISSING,
        [...pathSegments, key],
        collector,
      );
      if (collector.length >= HUNK_LIMIT) {
        return;
      }
    }
    return;
  }

  const beforeText = formatDiffSnapshot(before);
  const afterText = formatDiffSnapshot(after);
  collector.push({
    path: formatPath(pathSegments),
    beforeText,
    afterText,
    beforePlaceholderCount: countPlaceholders(beforeText),
    afterPlaceholderCount: countPlaceholders(afterText),
    lines: buildDiffLines(beforeText, afterText),
  });
}

function buildDiffLines(beforeText: string, afterText: string): DiffLine[] {
  const beforeLines = beforeText.split("\n");
  const afterLines = afterText.split("\n");
  const prefix = countSharedPrefix(beforeLines, afterLines);
  const suffix = countSharedSuffix(beforeLines, afterLines, prefix);
  const lines: DiffLine[] = [];

  if (prefix === beforeLines.length && prefix === afterLines.length) {
    return beforeLines.map((text, index) => ({
      key: `context-${index}`,
      kind: "context",
      text,
      beforeLine: index + 1,
      afterLine: index + 1,
    }));
  }

  const leadingContextStart = Math.max(0, prefix - CONTEXT_LINES);
  if (leadingContextStart > 0) {
    lines.push({
      key: "fold-leading",
      kind: "fold",
      text: `${leadingContextStart} unchanged lines`,
      beforeLine: null,
      afterLine: null,
    });
  }

  for (let index = leadingContextStart; index < prefix; index += 1) {
    lines.push({
      key: `prefix-${index}`,
      kind: "context",
      text: beforeLines[index],
      beforeLine: index + 1,
      afterLine: index + 1,
    });
  }

  const beforeChangedEnd = beforeLines.length - suffix;
  const afterChangedEnd = afterLines.length - suffix;

  for (let index = prefix; index < beforeChangedEnd; index += 1) {
    lines.push({
      key: `remove-${index}`,
      kind: "remove",
      text: beforeLines[index],
      beforeLine: index + 1,
      afterLine: null,
    });
  }

  for (let index = prefix; index < afterChangedEnd; index += 1) {
    lines.push({
      key: `add-${index}`,
      kind: "add",
      text: afterLines[index],
      beforeLine: null,
      afterLine: index + 1,
    });
  }

  const trailingContextCount = Math.min(suffix, CONTEXT_LINES);
  const trailingContextStart = beforeLines.length - suffix;
  const trailingVisibleStart = trailingContextStart + Math.max(0, suffix - trailingContextCount);
  if (suffix > trailingContextCount) {
    lines.push({
      key: "fold-trailing",
      kind: "fold",
      text: `${suffix - trailingContextCount} unchanged lines`,
      beforeLine: null,
      afterLine: null,
    });
  }

  for (let index = trailingVisibleStart; index < beforeLines.length; index += 1) {
    const afterIndex = afterLines.length - (beforeLines.length - index);
    lines.push({
      key: `suffix-${index}`,
      kind: "context",
      text: beforeLines[index],
      beforeLine: index + 1,
      afterLine: afterIndex + 1,
    });
  }

  return lines;
}

function countSharedPrefix(beforeLines: string[], afterLines: string[]): number {
  const max = Math.min(beforeLines.length, afterLines.length);
  let index = 0;
  while (index < max && beforeLines[index] === afterLines[index]) {
    index += 1;
  }
  return index;
}

function countSharedSuffix(beforeLines: string[], afterLines: string[], prefix: number): number {
  const max = Math.min(beforeLines.length, afterLines.length) - prefix;
  let count = 0;
  while (
    count < max &&
    beforeLines[beforeLines.length - 1 - count] === afterLines[afterLines.length - 1 - count]
  ) {
    count += 1;
  }
  return count;
}

function nodesEqual(left: ComparableJsonValue, right: ComparableJsonValue): boolean {
  if (left === MISSING || right === MISSING) {
    return left === right;
  }
  return JSON.stringify(left) === JSON.stringify(right);
}

function isPlainObject(
  value: ComparableJsonValue,
): value is Exclude<JsonValue, string | number | boolean | null | JsonValue[]> & Record<string, JsonValue> {
  return value !== MISSING && typeof value === "object" && value !== null && !Array.isArray(value);
}

function formatDiffSnapshot(value: ComparableJsonValue): string {
  if (value === MISSING) {
    return "<missing>";
  }
  if (value === null) {
    return "Unavailable for this request.";
  }
  if (typeof value === "string") {
    return value;
  }
  return JSON.stringify(value, null, 2);
}

function formatPath(segments: string[]): string {
  if (segments.length === 0) {
    return "/";
  }
  return segments.reduce((path, segment) => {
    if (/^\d+$/.test(segment)) {
      return `${path}[${segment}]`;
    }
    return path ? `${path}.${segment}` : segment;
  }, "");
}

function countPlaceholders(text: string): number {
  return [...text.matchAll(PLACEHOLDER_PATTERN)].length;
}

function prefixForLine(kind: DiffLineKind): string {
  if (kind === "remove") {
    return "-";
  }
  if (kind === "add") {
    return "+";
  }
  if (kind === "fold") {
    return "…";
  }
  return " ";
}

function renderDiffText(text: string) {
  const parts: Array<JSX.Element | string> = [];
  let cursor = 0;
  for (const match of text.matchAll(PLACEHOLDER_PATTERN)) {
    const start = match.index ?? 0;
    if (start > cursor) {
      parts.push(text.slice(cursor, start));
    }
    parts.push(
      <span key={`${match[0]}-${start}`} className="placeholder-inline">
        {match[0]}
      </span>,
    );
    cursor = start + match[0].length;
  }
  if (cursor < text.length) {
    parts.push(text.slice(cursor));
  }
  return parts.length ? parts : text;
}
