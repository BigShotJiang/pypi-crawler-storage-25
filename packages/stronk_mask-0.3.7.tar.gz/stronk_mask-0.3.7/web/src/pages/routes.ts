import type {
  AccessSummary,
  ConfigSummary,
  ModelSummary,
  Overview,
  PolicySummary,
  ProviderSummary,
  SystemSummary,
} from "../types";
import type { ConsoleRoute, NavItem } from "./routeTypes";

export const NAV_ITEMS: NavItem[] = [
  { key: "overview", label: "Overview", description: "Bundle posture and Hermes handoff", href: "/" },
  { key: "requests", label: "Requests", description: "Recent masking and blocking activity", href: "/requests" },
  { key: "providers", label: "Providers", description: "Read-only provider readiness", href: "/providers" },
  { key: "models", label: "Models", description: "Public aliases and backend linkage", href: "/models" },
  { key: "policy", label: "Policy", description: "Fail-closed and detector posture", href: "/policy" },
  { key: "access", label: "Access", description: "Session posture and approved modes", href: "/access" },
  { key: "system", label: "System", description: "Bundle health and private-surface checks", href: "/system" },
];

export function parseRoute(pathname: string): ConsoleRoute {
  if (pathname === "/requests") {
    return { key: "requests", path: pathname };
  }
  if (pathname.startsWith("/requests/")) {
    const requestId = decodeURIComponent(pathname.slice("/requests/".length)).trim();
    return requestId
      ? { key: "requestDetail", path: pathname, requestId }
      : { key: "requests", path: "/requests" };
  }
  if (pathname === "/providers") {
    return { key: "providers", path: pathname };
  }
  if (pathname === "/models") {
    return { key: "models", path: pathname };
  }
  if (pathname === "/policy") {
    return { key: "policy", path: pathname };
  }
  if (pathname === "/access") {
    return { key: "access", path: pathname };
  }
  if (pathname === "/system") {
    return { key: "system", path: pathname };
  }
  return { key: "overview", path: "/" };
}

export function getRouteTitle(route: ConsoleRoute): string {
  if (route.key === "requestDetail") {
    return "Request Detail";
  }
  const match = NAV_ITEMS.find((item) => item.key === route.key);
  return match?.label ?? "Overview";
}

export function getRouteDescription(route: ConsoleRoute): string {
  if (route.key === "requestDetail") {
    return "Trace-safe request detail with role-gated raw-content access and TTL-aware degraded states.";
  }
  const match = NAV_ITEMS.find((item) => item.key === route.key);
  return match?.description ?? "Aggregated operator console posture.";
}

export function buildRouteWarnings(
  route: ConsoleRoute,
  overview: Overview | null,
  config: ConfigSummary | null,
  providers: ProviderSummary | null,
  models: ModelSummary | null,
  policy: PolicySummary | null,
  system: SystemSummary | null,
): string[] {
  const warnings = new Set<string>();
  for (const warning of overview?.gateway.warnings ?? []) {
    warnings.add(warning);
  }
  if (route.key === "providers") {
    for (const warning of providers?.warnings ?? []) {
      warnings.add(warning);
    }
  }
  if (route.key === "models") {
    for (const warning of models?.warnings ?? []) {
      warnings.add(warning);
    }
  }
  if (route.key === "policy") {
    for (const warning of policy?.warnings ?? []) {
      warnings.add(warning);
    }
  }
  if (route.key === "system") {
    for (const warning of system?.warnings ?? []) {
      warnings.add(warning);
    }
  }
  for (const warning of config?.warnings ?? []) {
    warnings.add(warning);
  }
  return [...warnings];
}
