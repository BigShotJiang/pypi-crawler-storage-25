import { useEffect, useMemo, useState } from "react";

import type {
  DiscoveredModel,
  ModelAliasInput,
  ModelSummary,
  OperatorStatePrivacyPolicy,
  OperatorStateProvider,
} from "../types";
import { DegradedStatePanel } from "./DegradedStatePanel";
import { ModelAliasForm } from "./ModelAliasForm";
import { SectionCard, StatusBadge, toneForStatus } from "./shared";

function mergeAvailableModels(
  provider: OperatorStateProvider,
  discoveredModels: DiscoveredModel[],
): DiscoveredModel[] {
  const modelsById = new Map<string, DiscoveredModel>();
  for (const item of discoveredModels) {
    modelsById.set(item.id, item);
  }
  for (const item of provider.models) {
    if (!modelsById.has(item.upstream_id)) {
      modelsById.set(item.upstream_id, { id: item.upstream_id });
    }
  }
  return [...modelsById.values()];
}

export function ModelsPage({
  providers,
  runtimeSummary,
  privacyPolicies,
  selectedProviderId,
  discoveredModelsByProvider,
  busyProviderId,
  formError,
  onSelectProvider,
  onDiscoverProvider,
  onSaveModel,
  onDeleteModel,
  onOpenProviders,
  onApply,
  applyBusy,
}: {
  providers: OperatorStateProvider[];
  runtimeSummary: ModelSummary | null;
  privacyPolicies: OperatorStatePrivacyPolicy[];
  selectedProviderId: string | null;
  discoveredModelsByProvider: Record<string, DiscoveredModel[]>;
  busyProviderId: string | null;
  formError: string | null;
  onSelectProvider: (providerId: string) => void;
  onDiscoverProvider: (providerId: string) => Promise<void>;
  onSaveModel: (providerId: string, value: ModelAliasInput, existing: boolean) => Promise<void>;
  onDeleteModel: (providerId: string, upstreamId: string) => Promise<void>;
  onOpenProviders: () => void;
  onApply: () => Promise<void>;
  applyBusy: boolean;
}) {
  const selectedProvider =
    providers.find((provider) => provider.id === selectedProviderId) ?? providers[0] ?? null;
  const availableModels = useMemo(
    () =>
      selectedProvider
        ? mergeAvailableModels(selectedProvider, discoveredModelsByProvider[selectedProvider.id] ?? [])
        : [],
    [discoveredModelsByProvider, selectedProvider],
  );
  const [selectedUpstreamId, setSelectedUpstreamId] = useState<string | null>(availableModels[0]?.id ?? null);

  useEffect(() => {
    if (!availableModels.length) {
      setSelectedUpstreamId(null);
      return;
    }
    if (!selectedUpstreamId || !availableModels.some((item) => item.id === selectedUpstreamId)) {
      setSelectedUpstreamId(availableModels[0].id);
    }
  }, [availableModels, selectedUpstreamId]);

  const selectedDiscoveredModel =
    availableModels.find((item) => item.id === selectedUpstreamId) ?? availableModels[0] ?? null;
  const selectedModel = selectedProvider?.models.find((item) => item.upstream_id === selectedDiscoveredModel?.id) ?? null;
  const runtimeByAlias = new Map((runtimeSummary?.items ?? []).map((item) => [item.public_alias, item]));
  const publishedAliasCount =
    selectedProvider?.models.filter((item) => item.public_alias && item.enabled).length ?? 0;

  return (
    <div className="route-grid route-grid-config">
      <SectionCard eyebrow="Providers" title="Provider-scoped alias mapping">
        {providers.length ? (
          <div className="provider-selector-list">
            {providers.map((provider) => {
              const publishedCount = provider.models.filter((item) => item.public_alias && item.enabled).length;
              return (
                <button
                  key={provider.id}
                  type="button"
                  className={`nav-link${provider.id === selectedProvider?.id ? " is-active" : ""}`}
                  onClick={() => onSelectProvider(provider.id)}
                  disabled={applyBusy}
                >
                  <strong>{provider.label}</strong>
                  <span>{publishedCount} published alias{publishedCount === 1 ? "" : "es"}</span>
                </button>
              );
            })}
          </div>
        ) : (
          <DegradedStatePanel
            title="No providers available"
            body="Add and verify a provider before you map public aliases to upstream models."
            actionLabel="Open providers"
            onAction={onOpenProviders}
          />
        )}
      </SectionCard>

      <SectionCard
        eyebrow="Aliases"
        title={selectedProvider ? `${selectedProvider.label} models` : "Alias editor"}
        actionLabel={selectedProvider ? "Discover models" : undefined}
        actionDisabled={applyBusy || (selectedProvider ? busyProviderId === selectedProvider.id : false)}
        onAction={selectedProvider ? () => void onDiscoverProvider(selectedProvider.id) : undefined}
        aside={
          selectedProvider ? (
            <button className="inline-button" type="button" onClick={() => void onApply()} disabled={applyBusy}>
              {applyBusy ? "Applying..." : "Apply staged config"}
            </button>
          ) : undefined
        }
      >
        {!selectedProvider ? (
          <DegradedStatePanel
            title="Pick a provider"
            body="Choose a verified provider to review discovered upstream models and publish aliases."
          />
        ) : !availableModels.length ? (
          <DegradedStatePanel
            title="No active models yet"
            body="Verify the provider, discover upstream models, then publish an alias to make one active at runtime."
            actionLabel="Open providers"
            onAction={onOpenProviders}
          />
        ) : (
          <div className="detail-stack">
            {publishedAliasCount === 0 ? (
              <div className="callout">
                <strong>No active models yet</strong>
                <p>Pick a discovered model and publish an alias to make it routable at runtime.</p>
              </div>
            ) : null}
            <div className="model-selector-list">
              {availableModels.map((item) => {
                const configuredModel =
                  selectedProvider.models.find((model) => model.upstream_id === item.id) ?? null;
                const runtimeAlias =
                  configuredModel?.public_alias ? runtimeByAlias.get(configuredModel.public_alias) ?? null : null;
                return (
                  <button
                  key={item.id}
                  type="button"
                  className={`request-row${item.id === selectedDiscoveredModel?.id ? " is-active" : ""}`}
                  onClick={() => setSelectedUpstreamId(item.id)}
                  disabled={applyBusy}
                >
                    <div className="request-row-heading">
                      <strong>{item.id}</strong>
                      <StatusBadge
                        label={runtimeAlias?.readiness_posture ?? (configuredModel ? "configured" : "draft")}
                        tone={toneForStatus(runtimeAlias?.readiness_posture ?? (configuredModel ? "configured" : "draft"))}
                      />
                    </div>
                    <span>
                      {configuredModel?.public_alias
                        ? `Alias ${configuredModel.public_alias}`
                        : "No public alias published yet"}
                    </span>
                  </button>
                );
              })}
            </div>

            {selectedDiscoveredModel ? (
              <div className="detail-stack">
                <ModelAliasForm
                  discoveredModel={selectedDiscoveredModel}
                  model={selectedModel}
                  privacyPolicies={privacyPolicies}
                  busy={busyProviderId === selectedProvider.id}
                  disabled={applyBusy}
                  error={formError}
                  onSubmit={(value) => onSaveModel(selectedProvider.id, value, selectedModel !== null)}
                  onDelete={
                    selectedModel
                      ? () => onDeleteModel(selectedProvider.id, selectedModel.upstream_id)
                      : undefined
                  }
                />
                {selectedModel?.public_alias ? (
                  <div className="callout">
                    <strong>Runtime posture</strong>
                    <p>
                      {runtimeByAlias.get(selectedModel.public_alias)
                        ? `Current runtime alias ${selectedModel.public_alias} is ${runtimeByAlias.get(selectedModel.public_alias)?.readiness_posture}.`
                        : "This alias is staged in draft state and has not been materialized yet."}
                    </p>
                  </div>
                ) : null}
              </div>
            ) : null}
          </div>
        )}
      </SectionCard>
    </div>
  );
}
