import { DebugDiffDeck } from "../debug-diff";
import type { AuditEvent, DebugTrace } from "../types";
import type { ConsoleRoute } from "./routeTypes";
import {
  buildKeyValueRows,
  DataLine,
  EmptyPanel,
  formatRelativeTime,
  formatTimestamp,
  KeyValueGrid,
  MetricCard,
  SectionCard,
  StatusBadge,
  toneForOutcome,
} from "./shared";

export function RequestsPage({
  route,
  events,
  selectedEvent,
  selectedDebugTrace,
  traceAccess,
  contentTraceEnabled,
  onOpenRequest,
  onBackToRequests,
}: {
  route: ConsoleRoute;
  events: AuditEvent[];
  selectedEvent: AuditEvent | null;
  selectedDebugTrace: DebugTrace | null;
  traceAccess: boolean;
  contentTraceEnabled: boolean;
  onOpenRequest: (requestId: string) => void;
  onBackToRequests: () => void;
}) {
  return (
    <div className="route-grid route-grid-requests">
      <SectionCard eyebrow="Requests" title="Recent request list">
        {events.length ? (
          <div className="request-list">
            {events.map((event) => {
              const active = route.key === "requestDetail" && event.request_id === route.requestId;
              return (
                <button
                  key={event.request_id}
                  type="button"
                  className={`request-row${active ? " is-active" : ""}`}
                  onClick={() => onOpenRequest(event.request_id)}
                >
                  <div className="request-row-heading">
                    <StatusBadge label={event.outcome} tone={toneForOutcome(event.outcome)} />
                    <span>{event.provider}</span>
                    <span>{event.endpoint}</span>
                  </div>
                  <strong>{event.model ?? "model pending"}</strong>
                  <div className="request-row-meta">
                    <span>{event.detection_count} detections</span>
                    <span>{event.latency_ms} ms</span>
                    <span>{formatRelativeTime(event.created_at)}</span>
                  </div>
                </button>
              );
            })}
          </div>
        ) : (
          <EmptyPanel
            title="No request traffic yet"
            body="Send traffic through the public Stronk endpoint, then reopen this view to inspect masking outcomes."
          />
        )}
      </SectionCard>

      <SectionCard
        eyebrow={route.key === "requestDetail" ? "Request detail" : "Inspector"}
        title={selectedEvent?.request_id ?? "Choose a request"}
        actionLabel={route.key === "requestDetail" ? "Back to Requests" : undefined}
        onAction={route.key === "requestDetail" ? onBackToRequests : undefined}
      >
        {route.key !== "requestDetail" ? (
          <EmptyPanel
            title="Select a request"
            body="Opening a request detail keeps the event list on the left and moves the inspector into a dedicated route."
          />
        ) : selectedEvent ? (
          <div className="detail-stack">
            <div className="flow-line">
              <span>incoming</span>
              <span>masked upstream</span>
              <span>provider reply</span>
              <span>rehydrated return</span>
            </div>

            {contentTraceEnabled && traceAccess ? (
              selectedDebugTrace ? (
                <div className="unsafe-debug-panel">
                  <DebugDiffDeck trace={selectedDebugTrace} event={selectedEvent} />
                </div>
              ) : (
                <EmptyPanel
                  title="Trace expired"
                  body="The metadata for this request is still present, but the raw in-memory trace has expired under the configured TTL."
                  compact
                />
              )
            ) : (
              <EmptyPanel
                title="Raw trace unavailable"
                body={
                  traceAccess
                    ? "Content trace capture is disabled in the current control-plane configuration."
                    : "Your role can review sanitized request metadata, but not the raw trace body."
                }
                compact
              />
            )}

            <div className="metric-grid">
              <MetricCard value={selectedEvent.status_code} label="Status" tone="neutral" />
              <MetricCard value={selectedEvent.placeholder_count} label="Placeholders" tone="accent" />
              <MetricCard value={selectedEvent.rehydration_count} label="Rehydrations" tone="warning" />
              <MetricCard value={selectedEvent.masked_paths.length} label="Touched paths" tone="danger" />
            </div>

            <KeyValueGrid
              rows={[
                ["Created", formatTimestamp(selectedEvent.created_at)],
                ["Provider", selectedEvent.provider],
                ["Endpoint", selectedEvent.endpoint],
                ["Model", selectedEvent.model ?? "Unavailable"],
              ]}
            />
            <DataLine title="Detector mix" rows={buildKeyValueRows(selectedEvent.detection_types)} />
            <DataLine title="Action mix" rows={buildKeyValueRows(selectedEvent.actions)} />
            <DataLine title="Touched paths" rows={selectedEvent.masked_paths.map((path) => [path, ""])} mono />
          </div>
        ) : (
          <EmptyPanel
            title="Request not found"
            body="The selected request may have expired from the recent request window."
          />
        )}
      </SectionCard>
    </div>
  );
}
