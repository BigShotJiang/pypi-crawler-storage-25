import type { PolicySummary } from "../types";
import { DataLine, EmptyPanel, MetricCard, SectionCard } from "./shared";

export function PolicyPage({ policy }: { policy: PolicySummary | null }) {
  return (
    <div className="route-grid">
      <SectionCard eyebrow="Policy" title="Fail-closed and detector posture">
        {policy ? (
          <div className="detail-stack">
            <div className="metric-grid">
              <MetricCard
                value={policy.detector_readiness.presidio_enabled ? "enabled" : "disabled"}
                label="Presidio"
                tone={policy.detector_readiness.presidio_enabled ? "accent" : "danger"}
              />
              <MetricCard value={policy.detector_readiness.languages.join(", ")} label="Languages" tone="neutral" />
              <MetricCard value={policy.detector_readiness.english_model} label="English model" tone="warning" />
              <MetricCard value={policy.detector_readiness.chinese_model} label="Chinese model" tone="warning" />
            </div>
            <DataLine title="Fail-closed actions" rows={Object.entries(policy.fail_closed_actions)} />
            <DataLine
              title="Endpoint policy linkage"
              rows={policy.endpoint_posture.map((item) => [
                item.public_alias,
                `${item.privacy_policy_id} -> ${item.backend_linkage}`,
              ])}
            />
          </div>
        ) : (
          <EmptyPanel title="Policy snapshot unavailable" body="Detector posture will appear here after the control plane loads." />
        )}
      </SectionCard>
    </div>
  );
}
