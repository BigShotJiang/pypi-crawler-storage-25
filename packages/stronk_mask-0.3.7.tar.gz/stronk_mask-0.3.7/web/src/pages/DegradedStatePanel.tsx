export function DegradedStatePanel({
  title,
  body,
  actionLabel,
  onAction,
}: {
  title: string;
  body: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  return (
    <div className="degraded-panel">
      <div>
        <h4>{title}</h4>
        <p>{body}</p>
      </div>
      {actionLabel && onAction ? (
        <div className="degraded-actions">
          <button className="inline-button" type="button" onClick={onAction}>
            {actionLabel}
          </button>
        </div>
      ) : null}
    </div>
  );
}
