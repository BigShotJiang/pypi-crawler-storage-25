import { AnimatePresence, LayoutGroup, motion } from "framer-motion";
import type { ReactNode } from "react";

import type { ApplyJobSummary, Overview, SessionSummary } from "../types";
import { ApplyStatusBanner } from "./ApplyStatusBanner";
import { NAV_ITEMS } from "./routes";
import type { ConsoleRoute, ThemeMode } from "./routeTypes";
import { formatRelativeTime, MetricCard } from "./shared";

export function ConsoleShell({
  theme,
  route,
  viewerUser,
  viewerRoles,
  traceAccess,
  session,
  overview,
  currentTitle,
  currentDescription,
  error,
  applyJob,
  routeWarnings,
  onToggleTheme,
  onLogout,
  onNavigate,
  onRollbackApply,
  onDismissApplyBanner,
  children,
}: {
  theme: ThemeMode;
  route: ConsoleRoute;
  viewerUser: string;
  viewerRoles: string[];
  traceAccess: boolean;
  session: SessionSummary;
  overview: Overview | null;
  currentTitle: string;
  currentDescription: string;
  error: string | null;
  applyJob: ApplyJobSummary | null;
  routeWarnings: string[];
  onToggleTheme: () => void;
  onLogout: () => Promise<void>;
  onNavigate: (path: string) => void;
  onRollbackApply: (jobId: string) => Promise<void>;
  onDismissApplyBanner: () => void;
  children: ReactNode;
}) {
  return (
    <div className="console-shell">
      <motion.aside
        className="console-rail"
        initial={{ opacity: 0, x: -24 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.45, ease: [0.2, 1, 0.3, 1] }}
      >
        <div className="brand-block">
          <span className="eyebrow">privacy operations</span>
          <h1>stronk-mask-admin</h1>
          <p>
            Aggregated operator console for masked-request monitoring, posture, and Hermes setup.
          </p>
        </div>

        <div className="rail-section">
          <span className="section-label">Navigation</span>
          <nav className="nav-list" aria-label="Primary">
            {NAV_ITEMS.map((item) => {
              const active = route.key === item.key || (route.key === "requestDetail" && item.key === "requests");
              return (
                <button
                  key={item.key}
                  type="button"
                  className={`nav-link${active ? " is-active" : ""}`}
                  onClick={() => onNavigate(item.href)}
                >
                  <strong>{item.label}</strong>
                  <span>{item.description}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="rail-section">
          <span className="section-label">Operator session</span>
          <div className="identity-line">
            <strong>{viewerUser}</strong>
            <span>{viewerRoles.join(" · ")}</span>
          </div>
          <p className="microcopy">
            {traceAccess
              ? "Raw trace access is available to this session inside the authenticated admin lane."
              : "This role stays on sanitized summaries only. Raw traces remain unavailable."}
          </p>
          <div className="mini-stat-row">
            <span>Access mode</span>
            <strong>{session.access_mode}</strong>
          </div>
          <div className="mini-stat-row">
            <span>Secure cookies</span>
            <strong>{session.session_secure_cookies ? "required" : "loopback"}</strong>
          </div>
        </div>

        <div className="rail-section">
          <span className="section-label">Bundle snapshot</span>
          <div className="mini-stat-row">
            <span>Providers ready</span>
            <strong>
              {overview?.gateway.provider_summary.ready ?? 0}/{overview?.gateway.provider_summary.total ?? 0}
            </strong>
          </div>
          <div className="mini-stat-row">
            <span>Models ready</span>
            <strong>
              {overview?.gateway.model_summary.ready ?? 0}/{overview?.gateway.model_summary.total ?? 0}
            </strong>
          </div>
          <div className="mini-stat-row">
            <span>Doctor status</span>
            <strong>{overview?.gateway.doctor.status ?? "unknown"}</strong>
          </div>
        </div>

        <div className="rail-section rail-actions">
          <button className="theme-button" type="button" onClick={onToggleTheme}>
            Switch to {theme === "dark" ? "light" : "dark"} mode
          </button>
          <button className="ghost-button" type="button" onClick={() => void onLogout()}>
            Sign out
          </button>
        </div>
      </motion.aside>

      <main className="console-workspace">
        <motion.section
          className="top-shelf"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.05, ease: [0.2, 1, 0.3, 1] }}
        >
          <div className="top-shelf-copy">
            <span className="section-label">Current view</span>
            <h2>{currentTitle}</h2>
            <p>{currentDescription}</p>
          </div>
          <div className="top-shelf-metrics">
            <MetricCard value={overview?.total_requests ?? 0} label="Total requests" tone="neutral" compact />
            <MetricCard value={overview?.masked_requests ?? 0} label="Masked" tone="accent" compact />
            <MetricCard value={overview?.blocked_requests ?? 0} label="Blocked" tone="danger" compact />
            <MetricCard
              value={overview?.last_event_at ? formatRelativeTime(overview.last_event_at) : "No traffic"}
              label="Last event"
              tone="warning"
              compact
            />
          </div>
        </motion.section>

        {error ? <div className="error-banner">{error}</div> : null}
        <ApplyStatusBanner job={applyJob} onRollback={onRollbackApply} onDismiss={onDismissApplyBanner} />

        {routeWarnings.length ? (
          <div className="warning-ribbon">
            {routeWarnings.map((warning) => (
              <span key={warning}>{warning}</span>
            ))}
          </div>
        ) : null}

        <LayoutGroup>
          <AnimatePresence mode="wait">
            <motion.div
              key={route.path}
              className="route-frame"
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.35, ease: [0.2, 1, 0.3, 1] }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </LayoutGroup>
      </main>
    </div>
  );
}
