import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

import { OnboardingWizard } from "./OnboardingWizard";
import type { ApplyJobSummary, OperatorStatePrivacyPolicy, OperatorStateProvider } from "../types";

const privacyPoliciesFixture: OperatorStatePrivacyPolicy[] = [
  {
    id: "default",
    presidio_required: true,
    spacy_required: true,
    fail_closed_detector_types: ["email"],
  },
];

const providerFixture: OperatorStateProvider = {
  id: "openai-production",
  label: "OpenAI Production",
  kind: "openai_compat",
  base_url: "https://api.openai.com/v1",
  secret_ref: "PROVIDER_OPENAI_API_KEY",
  cliproxy_provider_name: "openai-production",
  models: [],
};

const configuredProviderFixture: OperatorStateProvider = {
  ...providerFixture,
  models: [
    {
      upstream_id: "gpt-4.1",
      public_alias: "stronk-lm-hot",
      privacy_policy_id: "default",
      enabled: true,
    },
  ],
};

describe("OnboardingWizard", () => {
  it("progresses through add provider, verify, pick model, publish alias, and done", async () => {
    const onCreateProvider = vi.fn().mockResolvedValue(undefined);
    const onVerifyProvider = vi.fn().mockResolvedValue(undefined);
    const onSaveModel = vi.fn().mockResolvedValue(undefined);
    const onApply = vi.fn().mockResolvedValue(undefined);

    const { rerender } = render(
      <OnboardingWizard
        provider={null}
        privacyPolicies={privacyPoliciesFixture}
        discoveredModels={[]}
        verification={null}
        applyJob={null}
        busy={false}
        saveError={null}
        modelBusy={false}
        modelError={null}
        configLocked={false}
        onCreateProvider={onCreateProvider}
        onVerifyProvider={onVerifyProvider}
        onSaveModel={onSaveModel}
        onApply={onApply}
        onOpenProviders={vi.fn()}
        onOpenModels={vi.fn()}
      />,
    );

    fireEvent.change(screen.getByLabelText("Label"), { target: { value: "OpenAI Production" } });
    fireEvent.change(screen.getByLabelText("Base URL"), { target: { value: "https://api.openai.com/v1" } });
    fireEvent.change(screen.getByPlaceholderText("PROVIDER_OPENAI_API_KEY"), {
      target: { value: "PROVIDER_OPENAI_API_KEY" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save + Verify" }));

    await waitFor(() => {
      expect(onCreateProvider).toHaveBeenCalledWith({
        label: "OpenAI Production",
        kind: "openai_compat",
        base_url: "https://api.openai.com/v1",
        secret_ref: "PROVIDER_OPENAI_API_KEY",
      });
    });

    rerender(
      <OnboardingWizard
        provider={providerFixture}
        privacyPolicies={privacyPoliciesFixture}
        discoveredModels={[]}
        verification={null}
        applyJob={null}
        busy={false}
        saveError={null}
        modelBusy={false}
        modelError={null}
        configLocked={false}
        onCreateProvider={onCreateProvider}
        onVerifyProvider={onVerifyProvider}
        onSaveModel={onSaveModel}
        onApply={onApply}
        onOpenProviders={vi.fn()}
        onOpenModels={vi.fn()}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Verify provider" }));
    await waitFor(() => {
      expect(onVerifyProvider).toHaveBeenCalledWith("openai-production");
    });

    rerender(
      <OnboardingWizard
        provider={providerFixture}
        privacyPolicies={privacyPoliciesFixture}
        discoveredModels={[{ id: "gpt-4.1" }]}
        verification={{ ok: true, latency_ms: 120 }}
        applyJob={null}
        busy={false}
        saveError={null}
        modelBusy={false}
        modelError={null}
        configLocked={false}
        onCreateProvider={onCreateProvider}
        onVerifyProvider={onVerifyProvider}
        onSaveModel={onSaveModel}
        onApply={onApply}
        onOpenProviders={vi.fn()}
        onOpenModels={vi.fn()}
      />,
    );

    fireEvent.change(screen.getByLabelText("Public alias"), { target: { value: "stronk-lm-hot" } });
    fireEvent.click(screen.getByRole("button", { name: "Publish alias draft" }));

    await waitFor(() => {
      expect(onSaveModel).toHaveBeenCalledWith({
        upstream_id: "gpt-4.1",
        public_alias: "stronk-lm-hot",
        privacy_policy_id: "default",
        enabled: true,
      }, false);
    });

    rerender(
      <OnboardingWizard
        provider={configuredProviderFixture}
        privacyPolicies={privacyPoliciesFixture}
        discoveredModels={[{ id: "gpt-4.1" }]}
        verification={{ ok: true, latency_ms: 120 }}
        applyJob={null}
        busy={false}
        saveError={null}
        modelBusy={false}
        modelError={null}
        configLocked={false}
        onCreateProvider={onCreateProvider}
        onVerifyProvider={onVerifyProvider}
        onSaveModel={onSaveModel}
        onApply={onApply}
        onOpenProviders={vi.fn()}
        onOpenModels={vi.fn()}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Publish alias" }));
    await waitFor(() => {
      expect(onApply).toHaveBeenCalled();
    });

    rerender(
      <OnboardingWizard
        provider={configuredProviderFixture}
        privacyPolicies={privacyPoliciesFixture}
        discoveredModels={[{ id: "gpt-4.1" }]}
        verification={{ ok: true, latency_ms: 120 }}
        applyJob={{
          job_id: "job-1",
          status: "success",
          steps: [],
          error: null,
          rollback_available: false,
          finished_at: "2026-04-03T18:10:00Z",
        } satisfies ApplyJobSummary}
        busy={false}
        saveError={null}
        modelBusy={false}
        modelError={null}
        configLocked={false}
        onCreateProvider={onCreateProvider}
        onVerifyProvider={onVerifyProvider}
        onSaveModel={onSaveModel}
        onApply={onApply}
        onOpenProviders={vi.fn()}
        onOpenModels={vi.fn()}
      />,
    );

    expect(screen.getByText("Done")).toBeInTheDocument();
  });

  it("locks onboarding controls while apply is running", () => {
    render(
      <OnboardingWizard
        provider={providerFixture}
        privacyPolicies={privacyPoliciesFixture}
        discoveredModels={[{ id: "gpt-4.1" }]}
        verification={{ ok: true, latency_ms: 120 }}
        applyJob={{
          job_id: "job-1",
          status: "running",
          steps: [],
          error: null,
          rollback_available: false,
          finished_at: null,
        }}
        busy={false}
        saveError={null}
        modelBusy={false}
        modelError={null}
        configLocked={true}
        onCreateProvider={vi.fn()}
        onVerifyProvider={vi.fn()}
        onSaveModel={vi.fn()}
        onApply={vi.fn()}
        onOpenProviders={vi.fn()}
        onOpenModels={vi.fn()}
      />,
    );

    expect(screen.getByRole("button", { name: /gpt-4\.1/i })).toBeDisabled();
    expect(screen.getByLabelText("Public alias")).toBeDisabled();
    expect(screen.getByLabelText("Privacy policy")).toBeDisabled();
    expect(screen.getByRole("checkbox", { name: "Enabled for publication" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "Publish alias draft" })).toBeDisabled();
  });

  it("disables verification controls while config is locked", () => {
    render(
      <OnboardingWizard
        provider={providerFixture}
        privacyPolicies={privacyPoliciesFixture}
        discoveredModels={[]}
        verification={null}
        applyJob={{
          job_id: "job-1",
          status: "running",
          steps: [],
          error: null,
          rollback_available: false,
          finished_at: null,
        }}
        busy={false}
        saveError={null}
        modelBusy={false}
        modelError={null}
        configLocked={true}
        onCreateProvider={vi.fn()}
        onVerifyProvider={vi.fn()}
        onSaveModel={vi.fn()}
        onApply={vi.fn()}
        onOpenProviders={vi.fn()}
        onOpenModels={vi.fn()}
      />,
    );

    expect(screen.getByRole("button", { name: "Verify provider" })).toBeDisabled();
  });
});
