import { useEffect, useState } from "react";

import type { ProviderDraftInput } from "../types";

const PROVIDER_SECRET_REF_RE = /^PROVIDER_[A-Z0-9_]+$/;
const LOCAL_HTTP_HOSTS = new Set(["localhost", "127.0.0.1", "::1", "fake-openai-upstream"]);

const EMPTY_PROVIDER: ProviderDraftInput = {
  label: "",
  kind: "openai_compat",
  base_url: "",
  secret_ref: "",
};

function normalizeBaseUrl(value: string): string {
  return value.trim().replace(/\/+$/, "");
}

function hasUrlUserInfo(value: string): boolean {
  const trimmed = value.trim();
  const schemeIndex = trimmed.indexOf("://");
  if (schemeIndex === -1) {
    return false;
  }
  const authorityStart = schemeIndex + 3;
  const authorityEnd = trimmed.indexOf("/", authorityStart);
  const authority = authorityEnd === -1 ? trimmed.slice(authorityStart) : trimmed.slice(authorityStart, authorityEnd);
  return authority.includes("@");
}

function getImmediateBaseUrlError(value: string): string | null {
  if (hasUrlUserInfo(value)) {
    return "Base URL must not embed credentials.";
  }
  const trimmed = value.trim();
  if (trimmed.includes("?") || trimmed.includes("#")) {
    return "Base URL must not include query parameters or fragments.";
  }
  return null;
}

function validateProviderDraft(draft: ProviderDraftInput): string | null {
  if (!draft.label.trim()) {
    return "Label is required.";
  }
  if (draft.kind !== "openai_compat") {
    return "Provider kind must stay OpenAI-compatible for v2.";
  }
  const baseUrl = normalizeBaseUrl(draft.base_url);
  if (!baseUrl) {
    return "Base URL is required.";
  }
  let parsed: URL;
  try {
    parsed = new URL(baseUrl);
  } catch {
    return "Base URL must be a valid http or https URL.";
  }
  if (!["http:", "https:"].includes(parsed.protocol)) {
    return "Base URL must use http or https.";
  }
  if (!parsed.hostname) {
    return "Base URL must include a host.";
  }
  if (parsed.username || parsed.password) {
    return "Base URL must not embed credentials.";
  }
  if (parsed.search || parsed.hash) {
    return "Base URL must not include query parameters or fragments.";
  }
  if (parsed.protocol === "http:" && !LOCAL_HTTP_HOSTS.has(parsed.hostname)) {
    return "Base URL must use https, or http only for localhost.";
  }
  const secretRef = draft.secret_ref.trim();
  if (secretRef && !PROVIDER_SECRET_REF_RE.test(secretRef)) {
    return "Secret env var name must match PROVIDER_[A-Z0-9_]+ or be empty for keyless local providers.";
  }
  return null;
}

export function ProviderForm({
  initialValue,
  busy,
  disabled,
  error,
  mode,
  onSubmit,
  onCancel,
  onDelete,
}: {
  initialValue?: ProviderDraftInput;
  busy: boolean;
  disabled?: boolean;
  error: string | null;
  mode: "create" | "edit";
  onSubmit: (value: ProviderDraftInput) => Promise<void>;
  onCancel?: () => void;
  onDelete?: () => Promise<void>;
}) {
  const [draft, setDraft] = useState<ProviderDraftInput>(initialValue ?? EMPTY_PROVIDER);
  const [localError, setLocalError] = useState<string | null>(null);

  useEffect(() => {
    setDraft(initialValue ?? EMPTY_PROVIDER);
    setLocalError(null);
  }, [initialValue]);

  return (
    <form
      className="form-stack"
      autoComplete="off"
      onSubmit={(event) => {
        event.preventDefault();
        if (localError) {
          return;
        }
        const validationError = validateProviderDraft(draft);
        if (validationError) {
          setLocalError(validationError);
          return;
        }
        setLocalError(null);
        void onSubmit({
          ...draft,
          label: draft.label.trim(),
          base_url: normalizeBaseUrl(draft.base_url),
          secret_ref: draft.secret_ref.trim(),
        });
      }}
    >
      <label className="auth-field">
        <span className="field-label">Label</span>
        <input
          autoComplete="off"
          disabled={busy || disabled}
          value={draft.label}
          onChange={(event) => {
            setLocalError(null);
            setDraft((current) => ({ ...current, label: event.target.value }));
          }}
          placeholder="OpenAI Production"
        />
      </label>

      <label className="auth-field">
        <span className="field-label">Kind</span>
        <select
          disabled={busy || disabled}
          value={draft.kind}
          onChange={(event) => {
            setLocalError(null);
            setDraft((current) => ({ ...current, kind: event.target.value }));
          }}
        >
          <option value="openai_compat">OpenAI-compatible</option>
        </select>
      </label>

      <label className="auth-field">
        <span className="field-label">Base URL</span>
        <input
          autoComplete="off"
          disabled={busy || disabled}
          value={draft.base_url}
          onChange={(event) => {
            const nextError = getImmediateBaseUrlError(event.target.value);
            if (nextError) {
              setLocalError(nextError);
              return;
            }
            setLocalError(null);
            setDraft((current) => ({ ...current, base_url: event.target.value }));
          }}
          placeholder="https://api.openai.com/v1"
        />
      </label>

      <label className="auth-field">
        <span className="field-label">Secret env var name</span>
        <input
          autoComplete="off"
          disabled={busy || disabled}
          value={draft.secret_ref}
          onChange={(event) => {
            const nextValue = event.target.value.toUpperCase().replace(/\s+/g, "");
            if (!nextValue) {
              setLocalError(null);
              setDraft((current) => ({ ...current, secret_ref: "" }));
              return;
            }
            if ("PROVIDER_".startsWith(nextValue)) {
              setLocalError(null);
              setDraft((current) => ({ ...current, secret_ref: nextValue }));
              return;
            }
            if (!nextValue.startsWith("PROVIDER_")) {
              setLocalError("Enter a secret env var name like PROVIDER_OPENAI_API_KEY. Do not paste a secret value.");
              return;
            }
            setLocalError(null);
            setDraft((current) => ({
              ...current,
              secret_ref: `PROVIDER_${nextValue
                .slice("PROVIDER_".length)
                .replace(/[^A-Z0-9_]/g, "")}`,
            }));
          }}
          placeholder="PROVIDER_OPENAI_API_KEY"
        />
        <span className="input-hint">Reference only. The browser never stores or reveals the secret value.</span>
      </label>

      {error || localError ? <div className="error-banner">{localError ?? error}</div> : null}

      <div className="form-actions">
        {onCancel ? (
          <button className="ghost-button compact-button" type="button" onClick={onCancel} disabled={busy || disabled}>
            Cancel
          </button>
        ) : null}
        {onDelete ? (
          <button
            className="ghost-button compact-button danger-button"
            type="button"
            onClick={() => void onDelete()}
            disabled={busy || disabled}
          >
            Delete
          </button>
        ) : null}
        <button className="theme-button compact-button" type="submit" disabled={busy || disabled}>
          {busy ? "Saving..." : mode === "create" ? "Save + Verify" : "Update + Verify"}
        </button>
      </div>
    </form>
  );
}
