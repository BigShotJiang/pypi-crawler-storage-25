import type {
  DiscoveredModel,
  OperatorStateProvider,
  ProviderSummary,
  ProviderTestResult,
} from "../types";
import { formatTimestamp, StatusBadge, toneForStatus } from "./shared";

export function ProviderCard({
  provider,
  runtime,
  selected,
  verification,
  discoveredModels,
  busy,
  disabled,
  onSelect,
  onVerify,
  onDiscover,
}: {
  provider: OperatorStateProvider;
  runtime: ProviderSummary["items"][number] | null;
  selected: boolean;
  verification: ProviderTestResult | null;
  discoveredModels: DiscoveredModel[];
  busy: boolean;
  disabled: boolean;
  onSelect: () => void;
  onVerify: () => void;
  onDiscover: () => void;
}) {
  const runtimeStatusLabel = runtime?.readiness_posture ?? "not_applied";
  const stagedStatusLabel = verification?.ok ? "verified" : "unverified";
  const stagedStatusTone = verification?.ok ? "accent" : verification?.error ? "danger" : "warning";
  const lastApplied = runtime?.materialized_at ? formatTimestamp(runtime.materialized_at) : "Pending";

  return (
    <article className={`posture-card provider-card${selected ? " is-selected" : ""}${busy ? " is-busy" : ""}`}>
      <button type="button" className="provider-card-select" onClick={onSelect} disabled={disabled}>
        <div className="posture-card-head">
          <strong>{provider.label}</strong>
          <div className="provider-status-badges">
            <StatusBadge label={`runtime ${runtimeStatusLabel}`} tone={toneForStatus(runtimeStatusLabel)} />
            <StatusBadge label={stagedStatusLabel} tone={stagedStatusTone} />
          </div>
        </div>
        <div className="provider-card-body">
          <div className="keyvalue-row">
            <span>Kind</span>
            <strong>{provider.kind}</strong>
          </div>
          <div className="keyvalue-row">
            <span>Base URL</span>
            <strong>{provider.base_url}</strong>
          </div>
          <div className="keyvalue-row">
            <span>Last apply</span>
            <strong>{lastApplied}</strong>
          </div>
        </div>
      </button>
      <div className="provider-card-actions">
        <button className="inline-button" type="button" onClick={onSelect} disabled={disabled}>
          Edit
        </button>
        <button className="inline-button" type="button" onClick={onVerify} disabled={busy || disabled}>
          {busy ? "Verifying..." : "Verify"}
        </button>
        <button
          className="inline-button"
          type="button"
          onClick={onDiscover}
          disabled={busy || disabled || !verification?.ok}
        >
          Discover models ({discoveredModels.length})
        </button>
      </div>
    </article>
  );
}
