export type ThemeMode = "light" | "dark";

export type RouteKey =
  | "overview"
  | "requests"
  | "requestDetail"
  | "providers"
  | "models"
  | "policy"
  | "access"
  | "system";

export type ConsoleRoute =
  | { key: "overview"; path: "/" }
  | { key: "requests"; path: "/requests" }
  | { key: "requestDetail"; path: string; requestId: string }
  | { key: "providers"; path: "/providers" }
  | { key: "models"; path: "/models" }
  | { key: "policy"; path: "/policy" }
  | { key: "access"; path: "/access" }
  | { key: "system"; path: "/system" };

export type NavItem = {
  key: Exclude<RouteKey, "requestDetail">;
  label: string;
  description: string;
  href: string;
};
