import type {
  DiscoveredModel,
  OperatorStateProvider,
  ProviderDraftInput,
  ProviderSummary,
  ProviderTestResult,
} from "../types";
import { DegradedStatePanel } from "./DegradedStatePanel";
import { ProviderCard } from "./ProviderCard";
import { ProviderForm } from "./ProviderForm";
import { SectionCard } from "./shared";

type ProviderRuntimeItem = ProviderSummary["items"][number];

export function ProvidersPage({
  providers,
  runtimeSummary,
  selectedProviderId,
  verificationByProvider,
  discoveredModelsByProvider,
  providerBusyId,
  formError,
  onSelectProvider,
  onSaveProvider,
  onDeleteProvider,
  onVerifyProvider,
  onDiscoverProvider,
  onApply,
  applyBusy,
}: {
  providers: OperatorStateProvider[];
  runtimeSummary: ProviderSummary | null;
  selectedProviderId: string | null;
  verificationByProvider: Record<string, ProviderTestResult | null>;
  discoveredModelsByProvider: Record<string, DiscoveredModel[]>;
  providerBusyId: string | null;
  formError: string | null;
  onSelectProvider: (providerId: string | null) => void;
  onSaveProvider: (providerId: string | null, value: ProviderDraftInput) => Promise<void>;
  onDeleteProvider: (providerId: string) => Promise<void>;
  onVerifyProvider: (providerId: string) => Promise<void>;
  onDiscoverProvider: (providerId: string) => Promise<void>;
  onApply: () => Promise<void>;
  applyBusy: boolean;
}) {
  const selectedProvider =
    selectedProviderId === null
      ? null
      : providers.find((provider) => provider.id === selectedProviderId) ?? providers[0] ?? null;
  const runtimeByLabel = new Map<string, ProviderRuntimeItem>(
    (runtimeSummary?.items ?? []).map((item) => [item.label, item]),
  );
  const formBusy = providerBusyId !== null;

  return (
    <div className="route-grid route-grid-config">
      <SectionCard
        eyebrow="Providers"
        title="Staged provider setup"
        actionLabel={selectedProvider ? "Add provider" : undefined}
        actionDisabled={applyBusy}
        onAction={selectedProvider ? () => onSelectProvider(null) : undefined}
      >
        {providers.length ? (
          <div className="card-grid">
            {providers.map((provider) => (
              <ProviderCard
                key={provider.id}
                provider={provider}
                runtime={runtimeByLabel.get(provider.label) ?? null}
                selected={provider.id === selectedProvider?.id}
                verification={verificationByProvider[provider.id] ?? null}
                discoveredModels={discoveredModelsByProvider[provider.id] ?? []}
                busy={providerBusyId === provider.id}
                disabled={applyBusy}
                onSelect={() => onSelectProvider(provider.id)}
                onVerify={() => void onVerifyProvider(provider.id)}
                onDiscover={() => void onDiscoverProvider(provider.id)}
              />
            ))}
          </div>
        ) : (
          <DegradedStatePanel
            title="No staged providers yet"
            body="Add the first upstream provider here. The browser stores only the env-var name for secrets, never the secret value."
          />
        )}
      </SectionCard>

      <SectionCard
        eyebrow="Config"
        title={selectedProvider ? `Edit ${selectedProvider.label}` : "Add provider"}
        aside={
          <button className="inline-button" type="button" onClick={() => void onApply()} disabled={applyBusy}>
            {applyBusy ? "Applying..." : "Apply staged config"}
          </button>
        }
      >
        <ProviderForm
          initialValue={
            selectedProvider
              ? {
                  label: selectedProvider.label,
                  kind: selectedProvider.kind,
                  base_url: selectedProvider.base_url,
                  secret_ref: selectedProvider.secret_ref,
                }
              : undefined
          }
          busy={formBusy}
          disabled={applyBusy}
          error={formError}
          mode={selectedProvider ? "edit" : "create"}
          onSubmit={(value) => onSaveProvider(selectedProvider?.id ?? null, value)}
          onCancel={selectedProvider ? () => onSelectProvider(null) : undefined}
          onDelete={selectedProvider ? () => onDeleteProvider(selectedProvider.id) : undefined}
        />
      </SectionCard>
    </div>
  );
}
