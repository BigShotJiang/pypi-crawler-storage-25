import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

import { ApplyStatusBanner } from "./ApplyStatusBanner";

describe("ApplyStatusBanner", () => {
  it("renders running status without dismissal", () => {
    const { container } = render(
      <ApplyStatusBanner
        job={{
          job_id: "job-1",
          status: "running",
          steps: [{ name: "materialize_bundle", status: "running", message: null }],
          error: null,
          rollback_available: false,
          finished_at: null,
        }}
        onRollback={vi.fn()}
        onDismiss={vi.fn()}
      />,
    );

    expect(screen.getByText("Applying staged config: materialize bundle")).toBeInTheDocument();
    expect(container.querySelector(".apply-spinner")).not.toBeNull();
    expect(screen.queryByRole("button", { name: "Dismiss" })).not.toBeInTheDocument();
  });

  it("renders failure with rollback and dismiss actions", async () => {
    const onRollback = vi.fn().mockResolvedValue(undefined);
    const onDismiss = vi.fn();

    render(
      <ApplyStatusBanner
        job={{
          job_id: "job-2",
          status: "failed",
          steps: [],
          error: "The staged configuration failed validation or health checks. Review the provider setup and retry, or rollback to the last working runtime.",
          rollback_available: true,
          finished_at: "2026-04-03T18:10:00Z",
        }}
        onRollback={onRollback}
        onDismiss={onDismiss}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Rollback" }));
    fireEvent.click(screen.getByRole("button", { name: "Dismiss" }));

    await waitFor(() => {
      expect(onRollback).toHaveBeenCalledWith("job-2");
    });
    expect(onDismiss).toHaveBeenCalled();
  });
});
