import type { AccessSummary } from "../types";
import {
  DataLine,
  EmptyPanel,
  formatTimestamp,
  KeyValueGrid,
  MetricCard,
  SectionCard,
} from "./shared";

export function AccessPage({ access }: { access: AccessSummary | null }) {
  return (
    <div className="route-grid route-grid-access">
      <SectionCard eyebrow="Access" title="Approved admin access modes">
        {access ? (
          <div className="detail-stack">
            <div className="metric-grid">
              <MetricCard value={access.mode} label="Current mode" tone="accent" />
              <MetricCard
                value={access.session_posture.secure_cookies ? "required" : "loopback"}
                label="Secure cookies"
                tone="neutral"
              />
              <MetricCard
                value={`${Math.floor(access.session_posture.idle_timeout_seconds / 60)}m`}
                label="Idle timeout"
                tone="warning"
              />
              <MetricCard
                value={`${Math.floor(access.session_posture.absolute_timeout_seconds / 3600)}h`}
                label="Absolute timeout"
                tone="danger"
              />
            </div>

            <KeyValueGrid
              rows={[
                ["Cookie name", access.session_posture.cookie_name],
                [
                  "CSRF guard",
                  access.session_posture.csrf_same_origin_required ? "same-origin enforced" : "off",
                ],
                [
                  "Login throttle",
                  `${access.session_posture.login_attempt_limit} / ${Math.floor(
                    access.session_posture.login_attempt_window_seconds / 60,
                  )}m`,
                ],
                ["Trusted proxy mode", access.remote_access.trusted_proxy_mode || "off"],
              ]}
            />
          </div>
        ) : (
          <EmptyPanel title="Access snapshot unavailable" body="Session posture and remote mode checks will appear here after load." />
        )}
      </SectionCard>

      <SectionCard eyebrow="Enrollment" title="Remote approval posture">
        {access ? (
          <div className="detail-stack">
            <div className="metric-grid">
              <MetricCard value={access.enrollment.approved} label="Approved" tone="accent" />
              <MetricCard value={access.enrollment.pending} label="Pending" tone="warning" />
              <MetricCard value={access.enrollment.revoked} label="Revoked" tone="danger" />
            </div>
            {access.enrollment.active_device ? (
              <KeyValueGrid
                rows={[
                  ["Active device", access.enrollment.active_device.device_id],
                  ["Tailscale login", access.enrollment.active_device.tailscale_login],
                  ["Approved role", access.enrollment.active_device.approved_role ?? "Pending"],
                  ["Last seen", formatTimestamp(access.enrollment.active_device.last_seen_at)],
                ]}
              />
            ) : (
              <EmptyPanel
                title="No active enrolled device"
                body="Loopback and ssh-forward sessions do not require a stored browser enrollment record."
                compact
              />
            )}
            {access.enrollment.recent.length ? (
              <DataLine
                title="Recent enrollment records"
                rows={access.enrollment.recent.map((item) => [
                  item.device_id,
                  `${item.approved_role ?? "pending"} · ${item.revoked_at ? "revoked" : "active"}`,
                ])}
                mono
              />
            ) : null}
          </div>
        ) : (
          <EmptyPanel title="Enrollment posture unavailable" body="Enrollment state will appear here once the control plane loads." />
        )}
      </SectionCard>
    </div>
  );
}
