import type { ApplyJobSummary } from "../types";
import { StatusBadge, toneForStatus } from "./shared";

const APPLY_STEP_LABELS: Record<string, string> = {
  validate_draft: "validate draft",
  backup_active: "backup active",
  promote_draft: "promote draft",
  materialize_bundle: "materialize bundle",
  health_check: "health check",
  rollback: "rollback",
};

function describeActiveStep(job: ApplyJobSummary): string {
  const active = job.steps.find((step) => step.status === "running");
  if (active) {
    return APPLY_STEP_LABELS[active.name] ?? "finalizing";
  }
  return "finalizing";
}

function describeStatus(job: ApplyJobSummary): string {
  if (job.status === "running") {
    return "The gateway is validating, materializing, and probing the staged configuration.";
  }
  if (job.status === "failed") {
    return (
      job.error ??
      "The staged configuration did not pass validation or health checks. Review the provider setup and retry, or rollback to the last working runtime."
    );
  }
  if (job.status === "rolled_back") {
    return "Rollback restored the last working runtime.";
  }
  return "The staged configuration completed without runtime errors.";
}

export function ApplyStatusBanner({
  job,
  onRollback,
  onDismiss,
}: {
  job: ApplyJobSummary | null;
  onRollback: (jobId: string) => Promise<void>;
  onDismiss: () => void;
}) {
  if (!job) {
    return null;
  }

  const variant =
    job.status === "running"
      ? "running"
      : job.status === "success" || job.status === "rolled_back"
        ? "success"
        : "failure";
  const title =
    job.status === "running"
      ? `Applying staged config: ${describeActiveStep(job)}`
      : job.status === "success"
        ? "Staged config applied successfully"
        : job.status === "rolled_back"
          ? "Rollback restored the previous runtime"
          : "Apply failed";

  return (
    <div className={`apply-banner is-${variant}`}>
      <div className="apply-banner-copy">
        <div className="apply-banner-head">
          {job.status === "running" ? <span className="apply-spinner" aria-hidden="true" /> : null}
          <strong>{title}</strong>
          <StatusBadge label={job.status} tone={toneForStatus(job.status)} />
        </div>
        <p>{describeStatus(job)}</p>
      </div>
      <div className="apply-banner-actions">
        {job.status === "failed" && job.rollback_available ? (
          <button className="inline-button" type="button" onClick={() => void onRollback(job.job_id)}>
            Rollback
          </button>
        ) : null}
        {job.status !== "running" ? (
          <button className="ghost-button compact-button" type="button" onClick={onDismiss}>
            Dismiss
          </button>
        ) : null}
      </div>
    </div>
  );
}
