import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { ModelsPage } from "./ModelsPage";
import type { ModelSummary, OperatorStatePrivacyPolicy, OperatorStateProvider } from "../types";

const providersFixture: OperatorStateProvider[] = [
  {
    id: "openai-production",
    label: "OpenAI Production",
    kind: "openai_compat",
    base_url: "https://api.openai.com/v1",
    secret_ref: "PROVIDER_OPENAI_API_KEY",
    cliproxy_provider_name: "openai-production",
    models: [
      {
        upstream_id: "gpt-4.1",
        public_alias: "stronk-lm-hot",
        privacy_policy_id: "default",
        enabled: true,
      },
    ],
  },
];

const privacyPoliciesFixture: OperatorStatePrivacyPolicy[] = [
  {
    id: "default",
    presidio_required: true,
    spacy_required: true,
    fail_closed_detector_types: ["email"],
  },
  {
    id: "strict",
    presidio_required: true,
    spacy_required: true,
    fail_closed_detector_types: ["email", "phone_number"],
  },
];

const runtimeSummaryFixture: ModelSummary = {
  schema_version: "gateway/v2",
  artifact_dir: "/tmp/generated",
  materialization_required: false,
  last_materialized_at: "2026-04-03T17:59:00Z",
  recommended_model_aliases: ["stronk-lm-hot"],
  warnings: [],
  items: [
    {
      public_alias: "stronk-lm-hot",
      backend_id: "openai-production",
      endpoint_id: "chat",
      readiness_posture: "ready",
      fallback_note: null,
      recommended_for_hermes: true,
    },
  ],
};

describe("ModelsPage", () => {
  afterEach(() => {
    cleanup();
  });

  it("renders discovered models and creates an alias mapping", async () => {
    const onSaveModel = vi.fn().mockResolvedValue(undefined);

    render(
      <ModelsPage
        providers={[
          {
            ...providersFixture[0],
            models: [],
          },
        ]}
        runtimeSummary={runtimeSummaryFixture}
        privacyPolicies={privacyPoliciesFixture}
        selectedProviderId="openai-production"
        discoveredModelsByProvider={{ "openai-production": [{ id: "gpt-4.1" }] }}
        busyProviderId={null}
        formError={null}
        onSelectProvider={vi.fn()}
        onDiscoverProvider={vi.fn()}
        onSaveModel={onSaveModel}
        onDeleteModel={vi.fn()}
        onOpenProviders={vi.fn()}
        onApply={vi.fn()}
        applyBusy={false}
      />,
    );

    expect(screen.getAllByText("gpt-4.1")).toHaveLength(2);
    fireEvent.change(screen.getByLabelText("Public alias"), { target: { value: "stronk-lm-hot" } });
    fireEvent.change(screen.getByLabelText("Privacy policy"), { target: { value: "strict" } });
    fireEvent.click(screen.getByRole("button", { name: "Publish alias draft" }));

    await waitFor(() => {
      expect(onSaveModel).toHaveBeenCalledWith("openai-production", {
        upstream_id: "gpt-4.1",
        public_alias: "stronk-lm-hot",
        privacy_policy_id: "strict",
        enabled: true,
      }, false);
    });
  });

  it("edits and deletes an existing alias mapping", async () => {
    const onSaveModel = vi.fn().mockResolvedValue(undefined);
    const onDeleteModel = vi.fn().mockResolvedValue(undefined);
    const onApply = vi.fn().mockResolvedValue(undefined);

    render(
      <ModelsPage
        providers={providersFixture}
        runtimeSummary={runtimeSummaryFixture}
        privacyPolicies={privacyPoliciesFixture}
        selectedProviderId="openai-production"
        discoveredModelsByProvider={{ "openai-production": [{ id: "gpt-4.1" }] }}
        busyProviderId={null}
        formError={null}
        onSelectProvider={vi.fn()}
        onDiscoverProvider={vi.fn()}
        onSaveModel={onSaveModel}
        onDeleteModel={onDeleteModel}
        onOpenProviders={vi.fn()}
        onApply={onApply}
        applyBusy={false}
      />,
    );

    fireEvent.change(screen.getByLabelText("Public alias"), { target: { value: "stronk-lm-cold" } });
    fireEvent.click(screen.getByRole("button", { name: "Update alias" }));
    fireEvent.click(screen.getByRole("button", { name: "Delete" }));
    fireEvent.click(screen.getByRole("button", { name: "Apply staged config" }));

    await waitFor(() => {
      expect(onSaveModel).toHaveBeenCalledWith("openai-production", {
        upstream_id: "gpt-4.1",
        public_alias: "stronk-lm-cold",
        privacy_policy_id: "default",
        enabled: true,
      }, true);
      expect(onDeleteModel).toHaveBeenCalledWith("openai-production", "gpt-4.1");
      expect(onApply).toHaveBeenCalled();
    });
  });

  it("shows a degraded state when no provider is selected or discovered", () => {
    render(
      <ModelsPage
        providers={[]}
        runtimeSummary={null}
        privacyPolicies={privacyPoliciesFixture}
        selectedProviderId={null}
        discoveredModelsByProvider={{}}
        busyProviderId={null}
        formError={null}
        onSelectProvider={vi.fn()}
        onDiscoverProvider={vi.fn()}
        onSaveModel={vi.fn()}
        onDeleteModel={vi.fn()}
        onOpenProviders={vi.fn()}
        onApply={vi.fn()}
        applyBusy={false}
      />,
    );

    expect(screen.getByText("No providers available")).toBeInTheDocument();
  });

  it("disables alias edits while apply is running", () => {
    render(
      <ModelsPage
        providers={providersFixture}
        runtimeSummary={runtimeSummaryFixture}
        privacyPolicies={privacyPoliciesFixture}
        selectedProviderId="openai-production"
        discoveredModelsByProvider={{ "openai-production": [{ id: "gpt-4.1" }] }}
        busyProviderId={null}
        formError={null}
        onSelectProvider={vi.fn()}
        onDiscoverProvider={vi.fn()}
        onSaveModel={vi.fn()}
        onDeleteModel={vi.fn()}
        onOpenProviders={vi.fn()}
        onApply={vi.fn()}
        applyBusy={true}
      />,
    );

    expect(screen.getByRole("button", { name: /openai production/i })).toBeDisabled();
    expect(screen.getByRole("button", { name: "Discover models" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "Applying..." })).toBeDisabled();
    expect(screen.getAllByRole("button", { name: /gpt-4\.1/i })[0]).toBeDisabled();
    expect(screen.getByLabelText("Public alias")).toBeDisabled();
    expect(screen.getByLabelText("Privacy policy")).toBeDisabled();
    expect(screen.getByRole("checkbox", { name: "Enabled for publication" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "Delete" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "Update alias" })).toBeDisabled();
  });
});
