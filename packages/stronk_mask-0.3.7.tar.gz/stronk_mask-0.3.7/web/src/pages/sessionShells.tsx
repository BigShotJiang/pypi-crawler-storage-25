import { motion } from "framer-motion";
import { FormEvent, useState } from "react";

import type { ThemeMode } from "./routeTypes";

export function LoadingShell({
  theme,
  onToggleTheme,
}: {
  theme: ThemeMode;
  onToggleTheme: () => void;
}) {
  return (
    <div className="auth-shell">
      <div className="auth-card">
        <span className="eyebrow">privacy operations</span>
        <h1>stronk-mask-admin</h1>
        <p className="auth-copy">Resolving the authenticated operator console and gateway posture mount.</p>
        <button className="theme-button" type="button" onClick={onToggleTheme}>
          Switch to {theme === "dark" ? "light" : "dark"} mode
        </button>
      </div>
    </div>
  );
}

export function LoginShell({
  theme,
  loginBusy,
  error,
  onSubmit,
  onToggleTheme,
}: {
  theme: ThemeMode;
  loginBusy: boolean;
  error: string | null;
  onSubmit: (username: string, password: string) => Promise<void>;
  onToggleTheme: () => void;
}) {
  const [username, setUsername] = useState("operator");
  const [password, setPassword] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    await onSubmit(username, password);
  }

  return (
    <div className="auth-shell">
      <motion.form
        className="auth-card"
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: [0.2, 1, 0.3, 1] }}
        onSubmit={(event) => void handleSubmit(event)}
      >
        <span className="eyebrow">privacy operations</span>
        <h1>stronk-mask-admin</h1>
        <p className="auth-copy">
          Sign in to inspect live masking outcomes, aggregated bundle posture, and the Hermes setup
          handoff. Sensitive content remains inside authenticated admin sessions only.
        </p>

        <label className="auth-field">
          <span className="section-label">Username</span>
          <input value={username} onChange={(event) => setUsername(event.target.value)} autoComplete="username" />
        </label>

        <label className="auth-field">
          <span className="section-label">Password</span>
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            autoComplete="current-password"
          />
        </label>

        {error ? <div className="error-banner">{error}</div> : null}

        <div className="auth-actions">
          <button className="theme-button" type="submit" disabled={loginBusy}>
            {loginBusy ? "Signing in..." : "Open operator console"}
          </button>
          <button className="ghost-button" type="button" onClick={onToggleTheme}>
            Switch to {theme === "dark" ? "light" : "dark"} mode
          </button>
        </div>
      </motion.form>
    </div>
  );
}
