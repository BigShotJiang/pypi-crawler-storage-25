import type {
  ApplyJobSummary,
  AuditEvent,
  ConfigSummary,
  DiscoveredModel,
  ModelAliasInput,
  OperatorStatePrivacyPolicy,
  OperatorStateProvider,
  Overview,
  ProviderDraftInput,
  ProviderTestResult,
} from "../types";
import {
  EmptyPanel,
  formatTimestamp,
  KeyValueGrid,
  MetricCard,
  SectionCard,
  SnippetBlock,
  StatusBadge,
  toneForOutcome,
  toneForStatus,
} from "./shared";
import { OnboardingWizard } from "./OnboardingWizard";

export function OverviewPage({
  overview,
  config,
  recentRequests,
  showOnboarding,
  onboardingProvider,
  privacyPolicies,
  discoveredModels,
  verification,
  applyJob,
  providerBusy,
  providerError,
  modelBusy,
  modelError,
  configLocked,
  onCreateProvider,
  onVerifyProvider,
  onSaveModel,
  onApply,
  onOpenRequest,
  onOpenProviders,
  onOpenModels,
}: {
  overview: Overview | null;
  config: ConfigSummary | null;
  recentRequests: AuditEvent[];
  showOnboarding: boolean;
  onboardingProvider: OperatorStateProvider | null;
  privacyPolicies: OperatorStatePrivacyPolicy[];
  discoveredModels: DiscoveredModel[];
  verification: ProviderTestResult | null;
  applyJob: ApplyJobSummary | null;
  providerBusy: boolean;
  providerError: string | null;
  modelBusy: boolean;
  modelError: string | null;
  configLocked: boolean;
  onCreateProvider: (value: ProviderDraftInput) => Promise<void>;
  onVerifyProvider: (providerId: string) => Promise<void>;
  onSaveModel: (value: ModelAliasInput, existing: boolean) => Promise<void>;
  onApply: () => Promise<void>;
  onOpenRequest: (requestId: string) => void;
  onOpenProviders: () => void;
  onOpenModels: () => void;
}) {
  return (
    <div className="route-grid route-grid-overview">
      <SectionCard
        eyebrow="Hermes connect"
        title="Public endpoint and alias handoff"
        aside={
          <StatusBadge
            label={overview?.gateway.hermes.credential_flow ?? "cli_only"}
            tone="warning"
          />
        }
      >
        <div className="hero-stack">
          <MetricCard
            value={overview?.gateway.hermes.public_base_url ?? "Not materialized"}
            label="Public base URL"
            tone="neutral"
          />
          <MetricCard
            value={overview?.gateway.model_summary.recommended_aliases.join(", ") || "Pending"}
            label="Recommended aliases"
            tone="accent"
          />
          <div className="callout">
            <strong>Credential flow: CLI only</strong>
            <p>
              The browser never carries the Hermes key value. Retrieve credentials through the
              gateway helper, then point Hermes at the public Stronk endpoint.
            </p>
          </div>
          {overview?.gateway.hermes.copy_snippets.length ? (
            <div className="snippet-grid">
              {overview.gateway.hermes.copy_snippets.map((snippet, index) => (
                <SnippetBlock
                  key={`${snippet.label ?? "snippet"}-${index}`}
                  label={snippet.label ?? `Snippet ${index + 1}`}
                  snippet={snippet.snippet ?? ""}
                />
              ))}
            </div>
          ) : (
            <EmptyPanel
              title="CLI helper snippet pending"
              body="Phase 3 will emit the real Hermes helper snippet. The UI already holds only metadata."
              compact
            />
          )}
        </div>
      </SectionCard>

      {showOnboarding ? (
        <OnboardingWizard
          provider={onboardingProvider}
          privacyPolicies={privacyPolicies}
          discoveredModels={discoveredModels}
          verification={verification}
          applyJob={applyJob}
          busy={providerBusy}
          saveError={providerError}
          modelBusy={modelBusy}
          modelError={modelError}
          configLocked={configLocked}
          onCreateProvider={onCreateProvider}
          onVerifyProvider={onboardingProvider ? onVerifyProvider : async () => {}}
          onSaveModel={onSaveModel}
          onApply={onApply}
          onOpenProviders={onOpenProviders}
          onOpenModels={onOpenModels}
        />
      ) : (
        <SectionCard eyebrow="Setup" title="Gateway setup complete" actionLabel="Manage providers" onAction={onOpenProviders}>
          <div className="callout">
            <strong>At least one alias is ready</strong>
            <p>
              Providers and public aliases are already staged. Use the providers and models views to
              verify additional upstreams or publish more aliases.
            </p>
          </div>
          <div className="wizard-actions">
            <button className="inline-button" type="button" onClick={onOpenProviders}>
              Review providers
            </button>
            <button className="inline-button" type="button" onClick={onOpenModels}>
              Review aliases
            </button>
          </div>
        </SectionCard>
      )}

      <SectionCard eyebrow="Bundle posture" title="Gateway-backed readiness" actionLabel="Providers" onAction={onOpenProviders}>
        <div className="metric-grid">
          <MetricCard
            value={`${overview?.gateway.provider_summary.ready ?? 0}/${overview?.gateway.provider_summary.total ?? 0}`}
            label="Providers ready"
            tone="accent"
          />
          <MetricCard
            value={`${overview?.gateway.model_summary.ready ?? 0}/${overview?.gateway.model_summary.total ?? 0}`}
            label="Models ready"
            tone="warning"
          />
          <MetricCard
            value={overview?.gateway.doctor.status ?? "unknown"}
            label="Doctor status"
            tone={toneForStatus(overview?.gateway.doctor.status ?? "unknown")}
          />
          <MetricCard
            value={overview?.gateway.doctor.private_surface_posture ?? "unknown"}
            label="Private surface posture"
            tone="neutral"
          />
        </div>
        <KeyValueGrid
          rows={[
            ["Bundle version", overview?.gateway.doctor.bundle_version ?? "Unavailable"],
            [
              "Last materialization",
              overview?.gateway.provider_summary.last_materialized_at
                ? formatTimestamp(overview.gateway.provider_summary.last_materialized_at)
                : "Materialization required",
            ],
            ["Artifact schema", overview?.gateway.schema_version ?? "Unavailable"],
            ["Artifact mount", overview?.gateway.artifact_dir ?? "Not configured"],
          ]}
        />
      </SectionCard>

      <SectionCard eyebrow="Recent activity" title="Request river" actionLabel="Models" onAction={onOpenModels}>
        {recentRequests.length ? (
          <div className="request-list compact-list">
            {recentRequests.map((event) => (
              <button
                key={event.request_id}
                type="button"
                className="request-row"
                onClick={() => onOpenRequest(event.request_id)}
              >
                <div className="request-row-heading">
                  <StatusBadge label={event.outcome} tone={toneForOutcome(event.outcome)} />
                  <span>{event.provider}</span>
                  <span>{event.stream ? "stream" : "json"}</span>
                </div>
                <strong>{event.model ?? "model pending"}</strong>
                <span>{formatTimestamp(event.created_at)}</span>
              </button>
            ))}
          </div>
        ) : (
          <EmptyPanel
            title="No traffic yet"
            body="Request monitoring stays available even when the gateway posture artifacts are still missing."
          />
        )}
      </SectionCard>

      <SectionCard eyebrow="Policy" title="Current edge posture">
        <KeyValueGrid
          rows={[
            ["Content trace capture", config?.control_plane.content_trace_enabled ? "enabled" : "disabled"],
            ["Trace TTL", `${config?.control_plane.content_trace_ttl_seconds ?? 0}s`],
            ["Admin access mode", config?.access.mode ?? "loopback"],
            ["Session auth", config?.auth.auth_mode ?? "session"],
          ]}
        />
      </SectionCard>
    </div>
  );
}
