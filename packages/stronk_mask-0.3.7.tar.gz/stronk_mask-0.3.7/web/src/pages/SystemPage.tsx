import type { ConfigSummary, SystemSummary } from "../types";
import {
  DataLine,
  EmptyPanel,
  KeyValueGrid,
  MetricCard,
  SectionCard,
  StatusBadge,
  toneForStatus,
} from "./shared";

export function SystemPage({
  system,
  config,
}: {
  system: SystemSummary | null;
  config: ConfigSummary | null;
}) {
  return (
    <div className="route-grid route-grid-system">
      <SectionCard eyebrow="System" title="Bundle and private-surface checks">
        {system ? (
          <div className="detail-stack">
            <div className="metric-grid">
              <MetricCard value={system.check_status} label="Check status" tone={toneForStatus(system.check_status)} />
              <MetricCard value={system.private_surface_posture} label="Private surface" tone="neutral" />
              <MetricCard value={system.bundle_version ?? "unknown"} label="Bundle version" tone="accent" />
              <MetricCard value={system.topology.current_access_mode} label="Access mode" tone="warning" />
            </div>
            <KeyValueGrid
              rows={[
                ["Browser admin runtime", system.topology.browser_admin_runtime],
                ["Public runtime", system.topology.public_runtime],
                ["Private backplane", system.topology.private_backplane],
                [
                  "CLIProxyAPI browser-direct",
                  system.topology.browser_direct_cliproxyapi ? "unexpected" : "blocked",
                ],
              ]}
            />
            {system.checks.length ? (
              <div className="check-list">
                {system.checks.map((check) => (
                  <div key={check.name} className="check-row">
                    <div>
                      <strong>{check.name}</strong>
                      <p>{check.message}</p>
                    </div>
                    <StatusBadge label={check.status} tone={toneForStatus(check.status)} />
                  </div>
                ))}
              </div>
            ) : (
              <EmptyPanel
                title="Doctor report missing"
                body="Do not infer success here. Phase 3 will emit the real bundle doctor report into the generated artifact mount."
                compact
              />
            )}
          </div>
        ) : (
          <EmptyPanel title="System snapshot unavailable" body="Bundle validation details will appear here after load." />
        )}
      </SectionCard>

      <SectionCard eyebrow="Pins and warnings" title="Image pins and local warnings">
        {system ? (
          <div className="detail-stack">
            <DataLine title="Image pins" rows={Object.entries(system.image_pins)} mono />
            <DataLine title="Warnings" rows={(system.warnings.length ? system.warnings : config?.warnings ?? []).map((item) => [item, ""])} />
          </div>
        ) : (
          <EmptyPanel title="No system warnings yet" body="Image pins and doctor warnings will appear here once the generated artifact is available." />
        )}
      </SectionCard>
    </div>
  );
}
