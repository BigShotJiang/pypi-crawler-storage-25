import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { ProviderForm } from "./ProviderForm";

describe("ProviderForm", () => {
  afterEach(() => {
    cleanup();
  });

  it("accepts the local-smoke fake upstream host over http", async () => {
    const onSubmit = vi.fn().mockResolvedValue(undefined);

    render(<ProviderForm mode="create" busy={false} error={null} onSubmit={onSubmit} />);

    fireEvent.change(screen.getByLabelText("Label"), { target: { value: "Local Smoke OpenAI" } });
    fireEvent.change(screen.getByLabelText("Base URL"), {
      target: { value: "http://fake-openai-upstream:18080/v1/" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save + Verify" }));

    await waitFor(() => {
      expect(onSubmit).toHaveBeenCalledWith({
        label: "Local Smoke OpenAI",
        kind: "openai_compat",
        base_url: "http://fake-openai-upstream:18080/v1",
        secret_ref: "",
      });
    });
  });

  it("rejects arbitrary remote http hosts", () => {
    const onSubmit = vi.fn().mockResolvedValue(undefined);

    render(<ProviderForm mode="create" busy={false} error={null} onSubmit={onSubmit} />);

    fireEvent.change(screen.getByLabelText("Label"), { target: { value: "Remote OpenAI" } });
    fireEvent.change(screen.getByLabelText("Base URL"), { target: { value: "http://example.com/v1" } });
    fireEvent.click(screen.getByRole("button", { name: "Save + Verify" }));

    expect(screen.getByText("Base URL must use https, or http only for localhost.")).toBeInTheDocument();
    expect(onSubmit).not.toHaveBeenCalled();
  });
});
