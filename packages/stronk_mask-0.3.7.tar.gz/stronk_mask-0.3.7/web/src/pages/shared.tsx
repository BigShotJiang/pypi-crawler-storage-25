import type { ReactNode } from "react";

const SECRET_BEARER_RE = /\b(Bearer|Basic)\s+[^\s"'`]+/gi;
const SECRET_INLINE_RE = /\bsk-[A-Za-z0-9_-]+\b/g;
const SECRET_FLAG_RE = /(--(?:api-key|token|secret|password|auth)\s+|--(?:api-key|token|secret|password|auth)=)([^\s"'`]+)/gi;
const SECRET_ASSIGNMENT_RE =
  /(\b(?:export\s+)?[A-Z][A-Z0-9_]*(?:TOKEN|SECRET|PASSWORD|API_KEY|AUTH|KEY)[A-Z0-9_]*\s*=\s*)([^\n]+)/g;
const URL_USERINFO_RE = /(https?:\/\/)([^/\s:@]+):([^@\s/]+)@/gi;

function unwrapSnippetValue(value: string): string {
  return value.trim().replace(/^(['"])(.*)\1$/, "$2");
}

function isSafeSnippetValue(value: string): boolean {
  const normalized = unwrapSnippetValue(value);
  if (!normalized) {
    return true;
  }
  return (
    normalized.startsWith("$") ||
    normalized.startsWith("<") ||
    /^[A-Z][A-Z0-9_]*$/.test(normalized)
  );
}

function sanitizeSnippet(snippet: string): string {
  return snippet
    .replace(SECRET_BEARER_RE, "$1 <redacted>")
    .replace(SECRET_INLINE_RE, "<redacted>")
    .replace(SECRET_FLAG_RE, (_match, prefix: string, value: string) =>
      `${prefix}${isSafeSnippetValue(value) ? value : "<redacted>"}`
    )
    .replace(SECRET_ASSIGNMENT_RE, (_match, prefix: string, value: string) =>
      `${prefix}${isSafeSnippetValue(value) ? value : "<redacted>"}`
    )
    .replace(URL_USERINFO_RE, "$1<redacted>@");
}

export function SectionCard({
  eyebrow,
  title,
  children,
  aside,
  actionLabel,
  actionDisabled,
  onAction,
}: {
  eyebrow: string;
  title: string;
  children: ReactNode;
  aside?: ReactNode;
  actionLabel?: string;
  actionDisabled?: boolean;
  onAction?: () => void;
}) {
  return (
    <section className="panel-card">
      <div className="panel-head">
        <div>
          <span className="section-label">{eyebrow}</span>
          <h3>{title}</h3>
        </div>
        <div className="panel-actions">
          {aside}
          {actionLabel && onAction ? (
            <button className="inline-button" type="button" onClick={onAction} disabled={actionDisabled}>
              {actionLabel}
            </button>
          ) : null}
        </div>
      </div>
      {children}
    </section>
  );
}

export function MetricCard({
  value,
  label,
  tone,
  compact = false,
}: {
  value: number | string;
  label: string;
  tone: "accent" | "warning" | "danger" | "neutral";
  compact?: boolean;
}) {
  return (
    <div className={`metric-card metric-${tone}${compact ? " is-compact" : ""}`}>
      <strong>{value}</strong>
      <span>{label}</span>
    </div>
  );
}

export function StatusBadge({
  label,
  tone,
}: {
  label: string;
  tone: "accent" | "warning" | "danger" | "neutral";
}) {
  return <span className={`status-badge tone-${tone}`}>{label}</span>;
}

export function EmptyPanel({
  title,
  body,
  compact = false,
}: {
  title: string;
  body: string;
  compact?: boolean;
}) {
  return (
    <div className={`empty-panel${compact ? " is-compact" : ""}`}>
      <h4>{title}</h4>
      <p>{body}</p>
    </div>
  );
}

export function KeyValueGrid({ rows }: { rows: Array<[string, string]> }) {
  return (
    <div className="keyvalue-grid">
      {rows.map(([label, value]) => (
        <div key={`${label}-${value}`} className="keyvalue-row">
          <span>{label}</span>
          <strong>{value}</strong>
        </div>
      ))}
    </div>
  );
}

export function DataLine({
  title,
  rows,
  mono = false,
}: {
  title: string;
  rows: Array<[string, string | number]>;
  mono?: boolean;
}) {
  return (
    <div className="data-line">
      <span className="section-label">{title}</span>
      <div className="data-line-list">
        {rows.length ? (
          rows.map(([name, value]) => (
            <div key={`${title}-${name}-${value}`} className={`data-row${mono ? " is-mono" : ""}`}>
              <span>{name}</span>
              <strong>{value}</strong>
            </div>
          ))
        ) : (
          <p className="microcopy">No data in the current snapshot.</p>
        )}
      </div>
    </div>
  );
}

export function SnippetBlock({
  label,
  snippet,
}: {
  label: string;
  snippet: string;
}) {
  const safeSnippet = sanitizeSnippet(snippet);
  return (
    <div className="snippet-card">
      <span className="section-label">{label}</span>
      <pre>
        <code>{safeSnippet}</code>
      </pre>
    </div>
  );
}

export function buildKeyValueRows(values: Record<string, number>): Array<[string, number]> {
  return Object.entries(values).sort((left, right) => right[1] - left[1]);
}

export function toneForOutcome(outcome: string): "accent" | "warning" | "danger" | "neutral" {
  if (outcome === "masked") {
    return "accent";
  }
  if (outcome === "blocked" || outcome === "upstream_error") {
    return "danger";
  }
  if (outcome === "route_local" || outcome === "proxy_error" || outcome === "upstream_rejection") {
    return "warning";
  }
  return "neutral";
}

export function toneForStatus(status: string): "accent" | "warning" | "danger" | "neutral" {
  const normalized = status.trim().toLowerCase();
  if (["ready", "pass", "ok", "healthy", "configured"].includes(normalized)) {
    return "accent";
  }
  if (["warn", "warning", "degraded", "unknown"].includes(normalized)) {
    return "warning";
  }
  if (["fail", "error", "failing"].includes(normalized)) {
    return "danger";
  }
  return "neutral";
}

export function formatRelativeTime(value: string): string {
  const timestamp = new Date(value).getTime();
  const deltaSeconds = Math.max(Math.round((Date.now() - timestamp) / 1000), 0);
  if (deltaSeconds < 60) {
    return `${deltaSeconds}s ago`;
  }
  if (deltaSeconds < 3600) {
    return `${Math.floor(deltaSeconds / 60)}m ago`;
  }
  return `${Math.floor(deltaSeconds / 3600)}h ago`;
}

export function formatTimestamp(value: string): string {
  return new Date(value).toLocaleString();
}
