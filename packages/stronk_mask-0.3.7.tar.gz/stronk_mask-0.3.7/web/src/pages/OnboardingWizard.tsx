import { useMemo, useState } from "react";

import type {
  ApplyJobSummary,
  DiscoveredModel,
  ModelAliasInput,
  OperatorStatePrivacyPolicy,
  OperatorStateProvider,
  ProviderDraftInput,
  ProviderTestResult,
} from "../types";
import { SectionCard, StatusBadge, toneForStatus } from "./shared";
import { DegradedStatePanel } from "./DegradedStatePanel";
import { ModelAliasForm } from "./ModelAliasForm";
import { ProviderForm } from "./ProviderForm";

export function OnboardingWizard({
  provider,
  privacyPolicies,
  discoveredModels,
  verification,
  applyJob,
  busy,
  saveError,
  modelBusy,
  modelError,
  configLocked,
  onCreateProvider,
  onVerifyProvider,
  onSaveModel,
  onApply,
  onOpenProviders,
  onOpenModels,
}: {
  provider: OperatorStateProvider | null;
  privacyPolicies: OperatorStatePrivacyPolicy[];
  discoveredModels: DiscoveredModel[];
  verification: ProviderTestResult | null;
  applyJob: ApplyJobSummary | null;
  busy: boolean;
  saveError: string | null;
  modelBusy: boolean;
  modelError: string | null;
  configLocked: boolean;
  onCreateProvider: (value: ProviderDraftInput) => Promise<void>;
  onVerifyProvider: (providerId: string) => Promise<void>;
  onSaveModel: (value: ModelAliasInput, existing: boolean) => Promise<void>;
  onApply: () => Promise<void>;
  onOpenProviders: () => void;
  onOpenModels: () => void;
}) {
  const configuredModel = provider?.models.find((item) => item.public_alias) ?? null;
  const [selectedModelId, setSelectedModelId] = useState<string | null>(null);
  const selectedDiscoveredModel =
    discoveredModels.find((item) => item.id === selectedModelId) ?? discoveredModels[0] ?? null;
  const steps = useMemo(
    () => [
      { label: "Add provider", state: provider ? "complete" : "active" },
      {
        label: "Verify",
        state: !provider ? "locked" : verification?.ok ? "complete" : "active",
      },
      {
        label: "Pick model",
        state: !verification?.ok ? "locked" : configuredModel ? "complete" : "active",
      },
      {
        label: "Publish alias",
        state: !configuredModel ? "locked" : applyJob?.status === "success" ? "complete" : "active",
      },
    ],
    [applyJob?.status, configuredModel, provider, verification?.ok],
  );

  return (
    <SectionCard eyebrow="Onboarding" title="First-time setup wizard">
      <div className="wizard-shell">
        <div className="wizard-steps" aria-label="Onboarding steps">
          {steps.map((step) => (
            <div
              key={step.label}
              className={`wizard-step${step.state === "active" ? " is-active" : ""}${
                step.state === "complete" ? " is-complete" : ""
              }${step.state === "locked" ? " is-locked" : ""}`}
            >
              <strong>{step.label}</strong>
            </div>
          ))}
        </div>

        {!provider ? (
          <ProviderForm
            mode="create"
            busy={busy}
            disabled={configLocked}
            error={saveError}
            onSubmit={onCreateProvider}
          />
        ) : !verification?.ok ? (
          <div className="detail-stack">
            {verification?.error ? (
              <DegradedStatePanel
                title="Provider verification required"
                body={verification.error}
              />
            ) : (
              <div className="callout">
                <strong>{provider.label}</strong>
                <p>
                  Save uses verify-on-save. Re-run verification here if you want to probe the upstream again
                  before choosing models.
                </p>
              </div>
            )}
            <div className="wizard-actions">
              <button
                className="theme-button compact-button"
                type="button"
                onClick={() => void onVerifyProvider(provider.id)}
                disabled={busy || configLocked}
              >
                {busy ? "Verifying..." : "Verify provider"}
              </button>
              <button className="ghost-button compact-button" type="button" onClick={onOpenProviders}>
                Open providers page
              </button>
            </div>
          </div>
        ) : !selectedDiscoveredModel && !configuredModel ? (
          <DegradedStatePanel
            title="No active models yet"
            body="Verification succeeded, but no model is published yet. Re-run discovery or review the provider settings before publishing an alias."
            actionLabel="Open providers page"
            onAction={onOpenProviders}
          />
        ) : !configuredModel ? (
          <div className="detail-stack">
            <div className="callout">
              <strong>No active models yet</strong>
              <p>Select a discovered model and publish an alias to make the provider usable at runtime.</p>
            </div>
            <div className="wizard-model-picker">
              {discoveredModels.map((item) => (
                <button
                  key={item.id}
                  className={`nav-link${selectedDiscoveredModel?.id === item.id ? " is-active" : ""}`}
                  type="button"
                  onClick={() => setSelectedModelId(item.id)}
                  disabled={configLocked}
                >
                  <strong>{item.id}</strong>
                  <span>Discovered from the verified upstream provider</span>
                </button>
              ))}
            </div>
            {selectedDiscoveredModel ? (
              <ModelAliasForm
                discoveredModel={selectedDiscoveredModel}
                model={null}
                privacyPolicies={privacyPolicies}
                busy={modelBusy}
                disabled={configLocked}
                error={modelError}
                onSubmit={(value) => onSaveModel(value, false)}
              />
            ) : null}
          </div>
        ) : applyJob?.status === "success" ? (
          <div className="callout">
            <strong>Done</strong>
            <p>
              The first public alias is staged, applied, and ready for Hermes and other clients.
            </p>
            <div className="wizard-actions">
              <button className="inline-button" type="button" onClick={onOpenProviders}>
                Manage providers
              </button>
              <button className="inline-button" type="button" onClick={onOpenModels}>
                Manage aliases
              </button>
            </div>
          </div>
        ) : (
          <div className="detail-stack">
            <div className="callout">
              <strong>Publish alias</strong>
              <p>
                The alias draft is ready. Apply it to materialize the runtime config and publish the model.
              </p>
            </div>
            <div className="wizard-summary">
              <StatusBadge label={configuredModel.public_alias ?? "alias pending"} tone={toneForStatus("configured")} />
              <span>{configuredModel.upstream_id}</span>
            </div>
            <div className="wizard-actions">
              <button
                className="theme-button compact-button"
                type="button"
                onClick={() => void onApply()}
                disabled={applyJob?.status === "running"}
              >
                {applyJob?.status === "running" ? "Applying..." : "Publish alias"}
              </button>
              <button className="ghost-button compact-button" type="button" onClick={onOpenModels}>
                Review alias page
              </button>
            </div>
          </div>
        )}
      </div>
    </SectionCard>
  );
}
