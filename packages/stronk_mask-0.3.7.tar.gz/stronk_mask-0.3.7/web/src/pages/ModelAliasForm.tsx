import { useEffect, useState } from "react";

import type {
  DiscoveredModel,
  ModelAliasInput,
  OperatorStateModel,
  OperatorStatePrivacyPolicy,
} from "../types";

export function ModelAliasForm({
  discoveredModel,
  model,
  privacyPolicies,
  busy,
  disabled,
  error,
  onSubmit,
  onDelete,
}: {
  discoveredModel: DiscoveredModel;
  model: OperatorStateModel | null;
  privacyPolicies: OperatorStatePrivacyPolicy[];
  busy: boolean;
  disabled?: boolean;
  error?: string | null;
  onSubmit: (value: ModelAliasInput) => Promise<void>;
  onDelete?: () => Promise<void>;
}) {
  const [draft, setDraft] = useState<ModelAliasInput>({
    upstream_id: discoveredModel.id,
    public_alias: model?.public_alias ?? null,
    privacy_policy_id: model?.privacy_policy_id ?? privacyPolicies[0]?.id ?? "",
    enabled: model?.enabled ?? true,
  });

  useEffect(() => {
    setDraft({
      upstream_id: discoveredModel.id,
      public_alias: model?.public_alias ?? null,
      privacy_policy_id: model?.privacy_policy_id ?? privacyPolicies[0]?.id ?? "",
      enabled: model?.enabled ?? true,
    });
  }, [discoveredModel.id, model, privacyPolicies]);

  return (
    <form
      className="form-stack alias-form"
      autoComplete="off"
      onSubmit={(event) => {
        event.preventDefault();
        void onSubmit({
          ...draft,
          public_alias: draft.public_alias?.trim() ? draft.public_alias.trim() : null,
        });
      }}
    >
      <div className="auth-field">
        <span className="field-label">Upstream model</span>
        <div className="readonly-chip">{discoveredModel.id}</div>
      </div>

      <label className="auth-field">
        <span className="field-label">Public alias</span>
        <input
          autoComplete="off"
          disabled={busy || disabled}
          value={draft.public_alias ?? ""}
          onChange={(event) => setDraft((current) => ({ ...current, public_alias: event.target.value }))}
          placeholder="stronk-lm"
        />
      </label>

      <label className="auth-field">
        <span className="field-label">Privacy policy</span>
        <select
          disabled={busy || disabled}
          value={draft.privacy_policy_id}
          onChange={(event) =>
            setDraft((current) => ({ ...current, privacy_policy_id: event.target.value }))
          }
        >
          {privacyPolicies.map((policy) => (
            <option key={policy.id} value={policy.id}>
              {policy.id}
            </option>
          ))}
        </select>
      </label>

      <label className="checkbox-row">
        <input
          type="checkbox"
          disabled={busy || disabled}
          checked={draft.enabled}
          onChange={(event) => setDraft((current) => ({ ...current, enabled: event.target.checked }))}
        />
        <span>Enabled for publication</span>
      </label>

      {error ? <div className="error-banner">{error}</div> : null}

      <div className="form-actions">
        {onDelete ? (
          <button
            className="ghost-button compact-button danger-button"
            type="button"
            onClick={() => void onDelete()}
            disabled={busy || disabled}
          >
            Delete
          </button>
        ) : null}
        <button className="theme-button compact-button" type="submit" disabled={busy || disabled}>
          {busy ? "Saving..." : model ? "Update alias" : "Publish alias draft"}
        </button>
      </div>
    </form>
  );
}
