import type {
  AccessSummary,
  ApplyJobSummary,
  AuditEvent,
  ConfigSummary,
  DiscoveredModel,
  DebugTrace,
  ModelSummary,
  ModelAliasInput,
  OperatorStateProvider,
  OperatorStateSummary,
  Overview,
  PolicySummary,
  ProviderDiscoverResult,
  ProviderDraftInput,
  ProviderSummary,
  ProviderTestResult,
  RollbackResult,
  SessionSummary,
  SystemSummary,
} from "./types";

export class ApiError extends Error {
  status: number;
  code: string | null;

  constructor(path: string, status: number, message?: string, code?: string | null) {
    super(message ?? `Request failed for ${path}: ${status}`);
    this.name = "ApiError";
    this.status = status;
    this.code = code ?? null;
  }
}

async function requestJson<T>(
  path: string,
  options: {
    method?: string;
    payload?: Record<string, unknown>;
    allowUnauthorized?: boolean;
    allowStatuses?: number[];
  } = {},
): Promise<T | null> {
  const response = await fetch(path, {
    method: options.method ?? "GET",
    cache: "no-store",
    credentials: "include",
    headers: {
      Accept: "application/json",
      ...(options.payload ? { "Content-Type": "application/json" } : {}),
    },
    body: options.payload ? JSON.stringify(options.payload) : undefined,
  });
  if (options.allowUnauthorized && response.status === 401) {
    return null;
  }
  if (options.allowStatuses?.includes(response.status)) {
    if (response.status === 204) {
      return null;
    }
    return (await response.json()) as T;
  }
  if (!response.ok) {
    let code: string | null = null;
    try {
      const payload = (await response.clone().json()) as {
        error?: {
          code?: unknown;
        };
      };
      if (typeof payload.error?.code === "string") {
        code = payload.error.code;
      }
    } catch {
      code = null;
    }
    throw new ApiError(path, response.status, undefined, code);
  }
  if (response.status === 204) {
    return null;
  }
  return (await response.json()) as T;
}

function coerceApplyJob(payload: Partial<ApplyJobSummary> & Pick<ApplyJobSummary, "job_id" | "status">): ApplyJobSummary {
  const status = payload.status;
  return {
    job_id: payload.job_id,
    status,
    steps: Array.isArray(payload.steps)
      ? payload.steps.map((step) => ({
          name: step.name,
          status: step.status,
          message: null,
        }))
      : [],
    error:
      status === "failed"
        ? "The staged configuration failed validation or health checks. Review the provider setup and retry, or rollback to the last working runtime."
        : status === "rolled_back"
          ? "Rollback restored the last working runtime."
          : null,
    rollback_available: Boolean(payload.rollback_available),
    finished_at: typeof payload.finished_at === "string" ? payload.finished_at : null,
  };
}

export async function fetchSession(): Promise<SessionSummary | null> {
  return requestJson<SessionSummary>("/api/session", { allowUnauthorized: true });
}

export async function loginSession(username: string, password: string): Promise<SessionSummary> {
  const payload = await requestJson<SessionSummary>("/api/session/login", {
    method: "POST",
    payload: { username, password },
  });
  if (payload === null) {
    throw new ApiError("/api/session/login", 500, "Login unexpectedly returned no payload.");
  }
  return payload;
}

export async function logoutSession(): Promise<void> {
  await requestJson<null>("/api/session/logout", { method: "POST" });
}

export async function fetchOverview(): Promise<Overview> {
  const payload = await requestJson<Overview>("/api/overview");
  if (payload === null) {
    throw new ApiError("/api/overview", 500, "Overview unexpectedly returned no payload.");
  }
  return payload;
}

export async function fetchEvents(): Promise<{ items: AuditEvent[] }> {
  const payload = await requestJson<{ items: AuditEvent[] }>("/api/events?limit=40");
  if (payload === null) {
    throw new ApiError("/api/events", 500, "Events unexpectedly returned no payload.");
  }
  return payload;
}

export async function fetchEvent(requestId: string): Promise<AuditEvent> {
  const payload = await requestJson<AuditEvent>(`/api/events/${requestId}`);
  if (payload === null) {
    throw new ApiError(`/api/events/${requestId}`, 500, "Event unexpectedly returned no payload.");
  }
  return payload;
}

export async function fetchConfig(): Promise<ConfigSummary> {
  const payload = await requestJson<ConfigSummary>("/api/config");
  if (payload === null) {
    throw new ApiError("/api/config", 500, "Config unexpectedly returned no payload.");
  }
  return payload;
}

export async function fetchProviders(): Promise<ProviderSummary> {
  const payload = await requestJson<ProviderSummary>("/api/providers");
  if (payload === null) {
    throw new ApiError("/api/providers", 500, "Providers unexpectedly returned no payload.");
  }
  return payload;
}

export async function fetchModels(): Promise<ModelSummary> {
  const payload = await requestJson<ModelSummary>("/api/models");
  if (payload === null) {
    throw new ApiError("/api/models", 500, "Models unexpectedly returned no payload.");
  }
  return payload;
}

export async function fetchPolicy(): Promise<PolicySummary> {
  const payload = await requestJson<PolicySummary>("/api/policy");
  if (payload === null) {
    throw new ApiError("/api/policy", 500, "Policy unexpectedly returned no payload.");
  }
  return payload;
}

export async function fetchAccess(): Promise<AccessSummary> {
  const payload = await requestJson<AccessSummary>("/api/access");
  if (payload === null) {
    throw new ApiError("/api/access", 500, "Access unexpectedly returned no payload.");
  }
  return payload;
}

export async function fetchSystem(): Promise<SystemSummary> {
  const payload = await requestJson<SystemSummary>("/api/system");
  if (payload === null) {
    throw new ApiError("/api/system", 500, "System unexpectedly returned no payload.");
  }
  return payload;
}

export async function fetchDebugTrace(requestId: string): Promise<DebugTrace | null> {
  const response = await fetch(`/api/debug/traces/${requestId}`, {
    cache: "no-store",
    credentials: "include",
    headers: {
      Accept: "application/json",
    },
  });
  if (response.status === 404) {
    return null;
  }
  if (!response.ok) {
    throw new ApiError(`/api/debug/traces/${requestId}`, response.status);
  }
  return (await response.json()) as DebugTrace;
}

export async function fetchOperatorState(): Promise<OperatorStateSummary> {
  const payload = await requestJson<OperatorStateSummary>("/api/operator-state");
  if (payload === null) {
    throw new ApiError("/api/operator-state", 500, "Operator state unexpectedly returned no payload.");
  }
  return payload;
}

export async function createProvider(payload: ProviderDraftInput): Promise<OperatorStateProvider> {
  const response = await requestJson<OperatorStateProvider>("/api/providers", {
    method: "POST",
    payload,
  });
  if (response === null) {
    throw new ApiError("/api/providers", 500, "Provider create unexpectedly returned no payload.");
  }
  return response;
}

export async function updateProvider(
  providerId: string,
  payload: Partial<ProviderDraftInput>,
): Promise<OperatorStateProvider> {
  const response = await requestJson<OperatorStateProvider>(`/api/providers/${providerId}`, {
    method: "PUT",
    payload,
  });
  if (response === null) {
    throw new ApiError(`/api/providers/${providerId}`, 500, "Provider update unexpectedly returned no payload.");
  }
  return response;
}

export async function deleteProvider(providerId: string): Promise<void> {
  await requestJson<null>(`/api/providers/${providerId}`, { method: "DELETE" });
}

export async function testProvider(providerId: string): Promise<ProviderTestResult> {
  const response = await requestJson<ProviderTestResult>(`/api/providers/${providerId}/test`, {
    method: "POST",
    payload: {},
  });
  if (response === null) {
    throw new ApiError(`/api/providers/${providerId}/test`, 500, "Provider test unexpectedly returned no payload.");
  }
  return response.ok
    ? response
    : {
        ...response,
        error:
          "Upstream verification failed. Review the base URL, secret env var name, and allowlist, then try again.",
      };
}

export async function discoverProviderModels(providerId: string): Promise<DiscoveredModel[]> {
  const response = await requestJson<ProviderDiscoverResult>(`/api/providers/${providerId}/discover`, {
    method: "POST",
    payload: {},
  });
  if (response === null) {
    throw new ApiError(`/api/providers/${providerId}/discover`, 500, "Provider discover unexpectedly returned no payload.");
  }
  return response.models;
}

export async function createProviderModel(
  providerId: string,
  payload: ModelAliasInput,
): Promise<void> {
  await requestJson<null>(`/api/providers/${providerId}/models`, {
    method: "POST",
    payload,
  });
}

export async function updateProviderModel(
  providerId: string,
  upstreamId: string,
  payload: Partial<ModelAliasInput>,
): Promise<void> {
  await requestJson<null>(`/api/providers/${providerId}/models/${encodeURIComponent(upstreamId)}`, {
    method: "PUT",
    payload,
  });
}

export async function deleteProviderModel(providerId: string, upstreamId: string): Promise<void> {
  await requestJson<null>(`/api/providers/${providerId}/models/${encodeURIComponent(upstreamId)}`, {
    method: "DELETE",
  });
}

export async function startApply(): Promise<ApplyJobSummary> {
  const response = await requestJson<Partial<ApplyJobSummary> & Pick<ApplyJobSummary, "job_id" | "status">>("/api/apply", {
    method: "POST",
    payload: {},
    allowStatuses: [409],
  });
  if (response === null) {
    throw new ApiError("/api/apply", 500, "Apply unexpectedly returned no payload.");
  }
  return coerceApplyJob(response);
}

export async function fetchApplyStatus(jobId: string): Promise<ApplyJobSummary> {
  const response = await requestJson<Partial<ApplyJobSummary> & Pick<ApplyJobSummary, "job_id" | "status">>(`/api/apply/${jobId}`);
  if (response === null) {
    throw new ApiError(`/api/apply/${jobId}`, 500, "Apply status unexpectedly returned no payload.");
  }
  return coerceApplyJob(response);
}

export async function rollbackApply(jobId: string): Promise<RollbackResult> {
  const response = await requestJson<RollbackResult>(`/api/apply/${jobId}/rollback`, {
    method: "POST",
    payload: {},
  });
  if (response === null) {
    throw new ApiError(`/api/apply/${jobId}/rollback`, 500, "Rollback unexpectedly returned no payload.");
  }
  return response;
}
