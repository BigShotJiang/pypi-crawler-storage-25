export type JsonValue =
  | string
  | number
  | boolean
  | null
  | JsonValue[]
  | { [key: string]: JsonValue };

export type AuditEvent = {
  request_id: string;
  created_at: string;
  provider: string;
  endpoint: string;
  model: string | null;
  stream: boolean;
  outcome: string;
  status_code: number;
  latency_ms: number;
  detection_count: number;
  detection_types: Record<string, number>;
  actions: Record<string, number>;
  placeholder_count: number;
  rehydration_count: number;
  masked_paths: string[];
  blocked: boolean;
  route_local: boolean;
};

export type Overview = {
  total_requests: number;
  masked_requests: number;
  blocked_requests: number;
  route_local_requests: number;
  rehydrated_responses: number;
  error_requests: number;
  provider_counts: Record<string, number>;
  detector_counts: Record<string, number>;
  action_counts: Record<string, number>;
  last_event_at: string | null;
  gateway: {
    schema_version: string | null;
    artifact_dir: string | null;
    warnings: string[];
    provider_summary: {
      ready: number;
      total: number;
      last_materialized_at: string | null;
    };
    model_summary: {
      ready: number;
      total: number;
      recommended_aliases: string[];
    };
    doctor: {
      status: string;
      private_surface_posture: string;
      bundle_version: string | null;
    };
    hermes: {
      public_base_url: string | null;
      recommended_model_aliases: string[];
      credential_flow: string;
      copy_snippets: Array<{
        label: string | null;
        snippet: string | null;
      }>;
    };
  };
};

export type ConfigSummary = {
  app_name: string;
  app_env: string;
  proxy_surfaces: string[];
  control_plane: {
    admin_api_enabled: boolean;
    admin_ui_enabled: boolean;
    audit_storage_enabled: boolean;
    ui_built: boolean;
    content_trace_enabled: boolean;
    content_trace_ttl_seconds: number;
  };
  upstreams: {
    openai_host: string;
    anthropic_host: string;
    allow_insecure_upstreams: boolean;
    allow_nonstandard_upstream_hosts: boolean;
  };
  policy_actions: Record<string, string>;
  auth: {
    auth_mode: string;
    allowed_roles: string[];
    trace_allowed_roles: string[];
    session_cookie_name: string;
    session_secure_cookies: boolean;
    viewer: {
      user: string;
      roles: string[];
    };
    trace_access: boolean;
  };
  access: {
    mode: string;
    http_bind: string;
    http_port: number;
    allowed_origins: string[];
    trusted_proxy_mode: string;
    enrollment_required: boolean;
  };
  gateway_artifacts: {
    artifact_dir: string | null;
    schema_version: string | null;
    warnings: string[];
  };
  warnings: string[];
  recent_access: Array<{
    created_at: string;
    actor: string;
    roles: string[];
    path: string;
    method: string;
    status_code: number;
    source_ip: string | null;
  }>;
};

export type DebugTraceSummary = {
  request_id: string;
  created_at: string;
  provider: string;
  endpoint: string;
  model: string | null;
  stream: boolean;
  outcome: string;
  status_code: number;
};

export type DebugTrace = DebugTraceSummary & {
  request_original: JsonValue;
  request_masked: JsonValue;
  response_upstream: JsonValue;
  response_rehydrated: JsonValue;
};

export type SessionSummary = {
  viewer: {
    user: string;
    roles: string[];
  };
  auth_mode: string;
  access_mode: string;
  trace_access: boolean;
  trace_allowed_roles: string[];
  content_trace_enabled: boolean;
  device_id: string | null;
  trusted_proxy_login: string | null;
  session_secure_cookies: boolean;
};

export type ProviderSummary = {
  schema_version: string | null;
  artifact_dir: string | null;
  materialization_required: boolean;
  last_materialized_at: string | null;
  last_doctor_generated_at: string | null;
  last_doctor_status: string;
  warnings: string[];
  items: Array<{
    label: string;
    readiness_posture: string;
    auth_source_type: string;
    materialized_at: string | null;
  }>;
};

export type ModelSummary = {
  schema_version: string | null;
  artifact_dir: string | null;
  materialization_required: boolean;
  last_materialized_at: string | null;
  recommended_model_aliases: string[];
  warnings: string[];
  items: Array<{
    public_alias: string;
    backend_id: string;
    endpoint_id: string;
    readiness_posture: string;
    fallback_note: string | null;
    recommended_for_hermes: boolean;
  }>;
};

export type PolicySummary = {
  warnings: string[];
  detector_readiness: {
    presidio_enabled: boolean;
    languages: string[];
    score_threshold: number;
    english_model: string;
    chinese_model: string;
  };
  fail_closed_actions: Record<string, string>;
  endpoint_posture: Array<{
    public_alias: string;
    privacy_policy_id: string;
    backend_linkage: string;
  }>;
};

export type AccessSummary = {
  mode: string;
  viewer: {
    user: string;
    roles: string[];
  };
  trace_allowed_roles: string[];
  session_posture: {
    cookie_name: string;
    secure_cookies: boolean;
    idle_timeout_seconds: number;
    absolute_timeout_seconds: number;
    csrf_same_origin_required: boolean;
    login_attempt_limit: number;
    login_attempt_window_seconds: number;
  };
  remote_access: {
    allowed_origins: string[];
    trusted_proxy_mode: string;
    enrollment_required: boolean;
  };
  enrollment: {
    approved: number;
    pending: number;
    revoked: number;
    active_device: {
      device_id: string;
      tailscale_login: string;
      browser_public_key: string;
      approved_role: string | null;
      approved_at: string | null;
      last_seen_at: string;
      revoked_at: string | null;
      is_approved: boolean;
    } | null;
    recent: Array<{
      device_id: string;
      tailscale_login: string;
      browser_public_key: string;
      approved_role: string | null;
      approved_at: string | null;
      last_seen_at: string;
      revoked_at: string | null;
      is_approved: boolean;
    }>;
  };
};

export type SystemSummary = {
  schema_version: string | null;
  artifact_dir: string | null;
  bundle_version: string | null;
  generated_at: string | null;
  private_surface_posture: string;
  check_status: string;
  checks: Array<{
    name: string;
    status: string;
    message: string;
    evidence_ref: string | null;
  }>;
  image_pins: Record<string, string>;
  topology: {
    browser_admin_runtime: string;
    public_runtime: string;
    private_backplane: string;
    browser_direct_cliproxyapi: boolean;
    supported_access_modes: string[];
    current_access_mode: string;
  };
  warnings: string[];
};

export type OperatorStateModel = {
  upstream_id: string;
  public_alias: string | null;
  privacy_policy_id: string;
  enabled: boolean;
};

export type OperatorStateProvider = {
  id: string;
  label: string;
  kind: string;
  base_url: string;
  secret_ref: string;
  cliproxy_provider_name: string;
  models: OperatorStateModel[];
};

export type OperatorStatePrivacyPolicy = {
  id: string;
  presidio_required: boolean;
  spacy_required: boolean;
  fail_closed_detector_types: string[];
};

export type OperatorStateSummary = {
  schema_version: string;
  providers: OperatorStateProvider[];
  privacy_policies: OperatorStatePrivacyPolicy[];
};

export type ProviderDraftInput = {
  label: string;
  kind: string;
  base_url: string;
  secret_ref: string;
};

export type ModelAliasInput = {
  upstream_id: string;
  public_alias: string | null;
  privacy_policy_id: string;
  enabled: boolean;
};

export type ProviderTestResult = {
  ok: boolean;
  latency_ms: number;
  error?: string;
};

export type DiscoveredModel = {
  id: string;
  object?: string;
  created?: number;
  owned_by?: string;
};

export type ProviderDiscoverResult = {
  models: DiscoveredModel[];
};

export type ApplyStepSummary = {
  name: string;
  status: string;
  message: string | null;
};

export type ApplyJobSummary = {
  job_id: string;
  status: string;
  steps: ApplyStepSummary[];
  error: string | null;
  rollback_available: boolean;
  finished_at: string | null;
};

export type RollbackResult = {
  status: string;
};
