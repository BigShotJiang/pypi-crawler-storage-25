## ExecPlan Expectations

ExecPlans in this repo are living implementation documents, not static notes.

Each plan should:
- stay scoped to one concrete delivery objective
- define explicit safety constraints and non-goals
- include observable validation gates for each phase
- record meaningful implementation checkpoints in `LOGS.md`
- reference workspaces under `docs/exec-plans/active/<slug>/` and `docs/exec-plans/completed/<slug>/`

Keep plans concise, operational, and easy to revise as the code changes.
