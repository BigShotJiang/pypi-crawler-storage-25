from __future__ import annotations

import re
from collections.abc import Mapping, Set
from urllib.parse import urlparse

from stronk_mask.config import Settings
from stronk_mask.providers import ProviderSpec

HOP_BY_HOP_HEADERS = {
    "connection",
    "content-length",
    "host",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade",
}
STANDARD_PROVIDER_HOSTS = {
    "anthropic": {"api.anthropic.com"},
    "openai": {"api.openai.com"},
}
OPAQUE_REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")


def sanitize_request_headers(
    headers: Mapping[str, str],
    spec: ProviderSpec,
    *,
    proxy_request_id: str | None = None,
) -> dict[str, str]:
    return sanitize_allowed_request_headers(
        headers,
        spec.request_headers,
        proxy_request_id=proxy_request_id,
    )


def sanitize_allowed_request_headers(
    headers: Mapping[str, str],
    allowed_headers: Set[str],
    *,
    proxy_request_id: str | None = None,
    default_accept: str | None = "application/json",
    default_content_type: str | None = "application/json",
) -> dict[str, str]:
    forwarded: dict[str, str] = {}
    for key, value in headers.items():
        lowered = key.lower()
        if lowered in allowed_headers:
            if lowered in {"x-codex-turn-metadata", "x-codex-turn-state"}:
                continue
            if lowered == "x-request-id":
                normalized = value.strip()
                if OPAQUE_REQUEST_ID_RE.fullmatch(normalized):
                    forwarded[key] = normalized
                elif proxy_request_id is not None:
                    forwarded[key] = proxy_request_id
                continue
            forwarded[key] = value
    if default_accept is not None and "Accept" not in forwarded and "accept" not in forwarded:
        forwarded["Accept"] = default_accept
    if (
        default_content_type is not None
        and "Content-Type" not in forwarded
        and "content-type" not in forwarded
    ):
        forwarded["Content-Type"] = default_content_type
    return forwarded


def sanitize_response_headers(headers: Mapping[str, str]) -> dict[str, str]:
    sanitized: dict[str, str] = {}
    for key, value in headers.items():
        if key.lower() in HOP_BY_HOP_HEADERS:
            continue
        sanitized[key] = value
    return sanitized


def resolve_upstream_url(settings: Settings, spec: ProviderSpec) -> str:
    return resolve_provider_upstream_url(
        settings,
        provider=spec.name,
        upstream_path=spec.upstream_path,
    )


def resolve_provider_upstream_url(
    settings: Settings,
    *,
    provider: str,
    upstream_path: str,
) -> str:
    base_url = (
        settings.openai_upstream_base_url
        if provider == "openai"
        else settings.anthropic_upstream_base_url
    ).rstrip("/")
    parsed = urlparse(base_url)
    if parsed.scheme not in {"https", "http"}:
        raise ValueError(f"Unsupported upstream scheme for {base_url}")
    if parsed.scheme != "https" and not settings.allow_insecure_upstreams:
        raise ValueError(f"Insecure upstream blocked by default: {base_url}")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError(f"Unsafe upstream URL shape blocked by default: {base_url}")
    if not settings.allow_nonstandard_upstream_hosts:
        hostname = parsed.hostname or ""
        if hostname not in STANDARD_PROVIDER_HOSTS[provider]:
            raise ValueError(f"Non-standard upstream host blocked by default: {base_url}")
    if base_url.endswith("/v1") and upstream_path.startswith("/v1/"):
        return f"{base_url}{upstream_path[3:]}"
    return f"{base_url}{upstream_path}"
