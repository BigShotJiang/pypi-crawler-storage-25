from __future__ import annotations

import json
import time
from collections import OrderedDict
from dataclasses import dataclass
from threading import Lock
from typing import TypeAlias, cast

from stronk_mask.redaction.models import JSONValue

DebugValue: TypeAlias = JSONValue | str | None
TRUNCATION_MARKER_PREFIX = "[truncated "


class BoundedDebugTextBuffer:
    def __init__(self, *, limit_bytes: int) -> None:
        self.limit_bytes = max(limit_bytes, 0)
        self._tail = b""
        self._truncated_bytes = 0

    def append(self, text: str) -> None:
        if self.limit_bytes == 0 or not text:
            return
        combined = self._tail + text.encode("utf-8")
        if len(combined) > self.limit_bytes:
            self._truncated_bytes += len(combined) - self.limit_bytes
            combined = combined[-self.limit_bytes :]
        self._tail = combined

    def render(self) -> str:
        tail_text = self._tail.decode("utf-8", errors="ignore")
        if self._truncated_bytes == 0:
            return tail_text
        return f"{TRUNCATION_MARKER_PREFIX}{self._truncated_bytes} bytes]\n{tail_text}"


@dataclass(frozen=True)
class UnsafeDebugTraceRecord:
    request_id: str
    created_at: str
    provider: str
    endpoint: str
    model: str | None
    stream: bool
    outcome: str
    status_code: int
    request_original: DebugValue
    request_masked: DebugValue
    response_upstream: DebugValue
    response_rehydrated: DebugValue

    def to_payload(self) -> dict[str, object]:
        return {
            "request_id": self.request_id,
            "created_at": self.created_at,
            "provider": self.provider,
            "endpoint": self.endpoint,
            "model": self.model,
            "stream": self.stream,
            "outcome": self.outcome,
            "status_code": self.status_code,
            "request_original": clone_debug_value(self.request_original),
            "request_masked": clone_debug_value(self.request_masked),
            "response_upstream": clone_debug_value(self.response_upstream),
            "response_rehydrated": clone_debug_value(self.response_rehydrated),
        }


class UnsafeDebugTraceStore:
    def __init__(self, *, max_entries: int, ttl_seconds: int) -> None:
        self.max_entries = max_entries
        self.ttl_seconds = ttl_seconds
        self._entries: OrderedDict[str, tuple[float, UnsafeDebugTraceRecord]] = OrderedDict()
        self._lock = Lock()

    def record(self, record: UnsafeDebugTraceRecord) -> None:
        with self._lock:
            now = time.monotonic()
            cloned = UnsafeDebugTraceRecord(
                request_id=record.request_id,
                created_at=record.created_at,
                provider=record.provider,
                endpoint=record.endpoint,
                model=record.model,
                stream=record.stream,
                outcome=record.outcome,
                status_code=record.status_code,
                request_original=clone_debug_value(record.request_original),
                request_masked=clone_debug_value(record.request_masked),
                response_upstream=clone_debug_value(record.response_upstream),
                response_rehydrated=clone_debug_value(record.response_rehydrated),
            )
            self._entries[record.request_id] = (now, cloned)
            self._entries.move_to_end(record.request_id)
            self._prune(now)

    def list(self, *, limit: int = 20) -> list[UnsafeDebugTraceRecord]:
        with self._lock:
            self._prune(time.monotonic())
            return [entry for _, entry in list(self._entries.values())[::-1][:limit]]

    def get(self, request_id: str) -> UnsafeDebugTraceRecord | None:
        with self._lock:
            self._prune(time.monotonic())
            item = self._entries.get(request_id)
            if item is None:
                return None
            return item[1]

    def _prune(self, now: float) -> None:
        expired_keys = [
            request_id
            for request_id, (recorded_at, _)
            in self._entries.items()
            if now - recorded_at > self.ttl_seconds
        ]
        for request_id in expired_keys:
            self._entries.pop(request_id, None)
        while len(self._entries) > self.max_entries:
            self._entries.popitem(last=False)


def clone_debug_value(value: DebugValue) -> DebugValue:
    if value is None or isinstance(value, str):
        return value
    return cast(DebugValue, json.loads(json.dumps(value, ensure_ascii=False)))


def truncate_debug_text(text: str, *, limit_bytes: int) -> str:
    buffer = BoundedDebugTextBuffer(limit_bytes=limit_bytes)
    buffer.append(text)
    return buffer.render()


def cap_debug_value(value: DebugValue, *, limit_bytes: int) -> DebugValue:
    if value is None:
        return None
    if limit_bytes <= 0:
        return None
    if isinstance(value, str):
        return truncate_debug_text(value, limit_bytes=limit_bytes)
    encoded = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if len(encoded.encode("utf-8")) <= limit_bytes:
        return clone_debug_value(value)
    return truncate_debug_text(encoded, limit_bytes=limit_bytes)
