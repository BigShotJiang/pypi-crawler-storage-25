from __future__ import annotations

import copy
import json
import time
from dataclasses import dataclass, field
from typing import cast

from stronk_mask.redaction.models import JSONValue

TERMINAL_RESPONSE_EVENT_TYPES = frozenset(
    {"response.completed", "response.failed", "response.incomplete", "response.done"}
)


@dataclass(frozen=True)
class ResponsesWebsocketError(Exception):
    status_code: int
    message: str
    error_type: str = "invalid_websocket_request"

    def __str__(self) -> str:
        return self.message


@dataclass(frozen=True)
class ResponsesWebsocketTurn:
    payload: dict[str, JSONValue]
    synthetic_events: tuple[dict[str, JSONValue], ...] = ()


@dataclass(frozen=True)
class ResponsesWebsocketCheckpoint:
    last_request: dict[str, JSONValue] | None
    last_completed_output: JSONValue
    last_response_id: str | None
    last_response_local: bool


@dataclass
class ResponsesWebsocketSession:
    last_request: dict[str, JSONValue] | None = None
    last_completed_output: JSONValue = field(default_factory=list)
    last_response_id: str | None = None
    last_response_local: bool = False
    updated_at: float = field(default_factory=time.monotonic)
    active_owner_token: str | None = field(default=None, repr=False)

    def clone(self) -> ResponsesWebsocketSession:
        return ResponsesWebsocketSession(
            last_request=copy.deepcopy(self.last_request),
            last_completed_output=copy.deepcopy(self.last_completed_output),
            last_response_id=self.last_response_id,
            last_response_local=self.last_response_local,
            updated_at=self.updated_at,
        )

    def checkpoint(self) -> ResponsesWebsocketCheckpoint:
        return ResponsesWebsocketCheckpoint(
            last_request=copy.deepcopy(self.last_request),
            last_completed_output=copy.deepcopy(self.last_completed_output),
            last_response_id=self.last_response_id,
            last_response_local=self.last_response_local,
        )

    def restore(self, checkpoint: ResponsesWebsocketCheckpoint) -> None:
        self.last_request = copy.deepcopy(checkpoint.last_request)
        self.last_completed_output = copy.deepcopy(checkpoint.last_completed_output)
        self.last_response_id = checkpoint.last_response_id
        self.last_response_local = checkpoint.last_response_local
        self.touch()

    def touch(self) -> None:
        self.updated_at = time.monotonic()

    def try_acquire_owner(self, owner_token: str) -> bool:
        if self.active_owner_token is not None:
            return False
        self.active_owner_token = owner_token
        self.touch()
        return True

    def release_owner(self, owner_token: str) -> None:
        if self.active_owner_token != owner_token:
            return
        self.active_owner_token = None
        self.touch()

    def normalize(self, raw_text: str) -> ResponsesWebsocketTurn:
        self.touch()
        payload = _parse_client_payload(raw_text)
        request_type = _require_string(payload.get("type"), field="type")
        if request_type not in {"response.create", "response.append"}:
            raise ResponsesWebsocketError(
                status_code=400,
                message=f"Unsupported websocket request type: {request_type}",
            )

        if request_type == "response.create" and (
            self.last_request is None or _starts_fresh_chain(payload)
        ):
            normalized = _normalize_initial_create(payload)
            self.last_request = normalized
            self.last_completed_output = []
            self.last_response_id = None
            self.last_response_local = False
            if _should_handle_local_prewarm(payload):
                synthetic_events = build_synthetic_prewarm_events(normalized)
                self.last_response_id = response_event_id(synthetic_events[-1])
                self.last_response_local = True
                return ResponsesWebsocketTurn(payload=normalized, synthetic_events=synthetic_events)
            return ResponsesWebsocketTurn(payload=normalized)

        if self.last_request is None:
            raise ResponsesWebsocketError(
                status_code=400,
                message="WebSocket request received before response.create.",
            )

        previous_response_id = _optional_string(payload.get("previous_response_id"))
        if previous_response_id is not None:
            _validate_previous_response_id(
                previous_response_id=previous_response_id,
                expected_previous_response_id=self.last_response_id,
            )
            if self.last_response_local:
                normalized = _normalize_follow_up_replay(
                    payload,
                    last_request=self.last_request,
                    last_completed_output=self.last_completed_output,
                )
            else:
                normalized = _normalize_incremental_follow_up(
                    payload,
                    last_request=self.last_request,
                    previous_response_id=previous_response_id,
                )
        else:
            normalized = _normalize_follow_up_replay(
                payload,
                last_request=self.last_request,
                last_completed_output=self.last_completed_output,
            )
        self.last_request = normalized
        self.last_response_local = False
        self.touch()
        return ResponsesWebsocketTurn(payload=normalized)


def build_synthetic_prewarm_events(
    request_payload: dict[str, JSONValue],
) -> tuple[dict[str, JSONValue], dict[str, JSONValue]]:
    response_id = f"resp_prewarm_{int(time.time() * 1000)}"
    created_at = int(time.time())
    model = request_payload.get("model")

    created_payload: dict[str, JSONValue] = {
        "type": "response.created",
        "sequence_number": 0,
        "response": {
            "id": response_id,
            "object": "response",
            "created_at": created_at,
            "status": "in_progress",
            "background": False,
            "error": None,
            "output": [],
        },
    }
    completed_payload: dict[str, JSONValue] = {
        "type": "response.completed",
        "sequence_number": 1,
        "response": {
            "id": response_id,
            "object": "response",
            "created_at": created_at,
            "status": "completed",
            "background": False,
            "error": None,
            "output": [],
            "usage": {
                "input_tokens": 0,
                "output_tokens": 0,
                "total_tokens": 0,
            },
        },
    }
    if isinstance(model, str) and model:
        cast(dict[str, JSONValue], created_payload["response"])["model"] = model
        cast(dict[str, JSONValue], completed_payload["response"])["model"] = model
    return created_payload, completed_payload


def response_completed_output(payload: dict[str, JSONValue]) -> JSONValue:
    response = payload.get("response")
    if not isinstance(response, dict):
        return []
    output = response.get("output")
    if isinstance(output, list):
        return output
    return []


def websocket_json_payloads_from_sse_chunk(chunk: bytes) -> list[dict[str, JSONValue]]:
    text = chunk.decode("utf-8", errors="replace").replace("\r\n", "\n")
    payloads: list[dict[str, JSONValue]] = []
    for line in text.split("\n"):
        stripped = line.strip()
        if not stripped or stripped.startswith("event:"):
            continue
        if stripped.startswith("data:"):
            stripped = stripped[5:].strip()
        if not stripped or stripped == "[DONE]":
            continue
        try:
            parsed = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict):
            payloads.append(cast(dict[str, JSONValue], parsed))
    return payloads


def is_terminal_response_event(payload: dict[str, JSONValue]) -> bool:
    event_type = payload.get("type")
    return isinstance(event_type, str) and event_type in TERMINAL_RESPONSE_EVENT_TYPES


def response_event_id(payload: dict[str, JSONValue]) -> str | None:
    response = payload.get("response")
    if not isinstance(response, dict):
        return None
    response_id = response.get("id")
    if not isinstance(response_id, str):
        return None
    trimmed = response_id.strip()
    return trimmed or None


def _parse_client_payload(raw_text: str) -> dict[str, JSONValue]:
    try:
        parsed = json.loads(raw_text)
    except json.JSONDecodeError as error:
        raise ResponsesWebsocketError(
            status_code=400,
            message="WebSocket request body must be valid JSON.",
        ) from error
    if not isinstance(parsed, dict):
        raise ResponsesWebsocketError(
            status_code=400,
            message="WebSocket request body must be a JSON object.",
        )
    return cast(dict[str, JSONValue], parsed)


def _normalize_initial_create(payload: dict[str, JSONValue]) -> dict[str, JSONValue]:
    normalized = dict(payload)
    normalized.pop("type", None)
    normalized.pop("generate", None)
    normalized["stream"] = True
    if "input" not in normalized:
        normalized["input"] = []
    elif not isinstance(normalized["input"], list):
        raise ResponsesWebsocketError(
            status_code=400,
            message="WebSocket request requires array field: input",
        )

    model = normalized.get("model")
    if not isinstance(model, str) or not model.strip():
        raise ResponsesWebsocketError(
            status_code=400,
            message="Missing model in response.create request.",
        )
    normalized["model"] = model.strip()
    _normalize_previous_response_id_field(normalized)
    return normalized


def _normalize_incremental_follow_up(
    payload: dict[str, JSONValue],
    *,
    last_request: dict[str, JSONValue],
    previous_response_id: str,
) -> dict[str, JSONValue]:
    next_input = payload.get("input")
    if not isinstance(next_input, list):
        raise ResponsesWebsocketError(
            status_code=400,
            message="WebSocket request requires array field: input",
        )

    normalized = dict(payload)
    normalized.pop("type", None)
    normalized.pop("generate", None)
    normalized["stream"] = True
    normalized["previous_response_id"] = previous_response_id
    normalized["input"] = next_input

    if "model" not in normalized and "model" in last_request:
        normalized["model"] = last_request["model"]
    model = normalized.get("model")
    if not isinstance(model, str) or not model.strip():
        raise ResponsesWebsocketError(
            status_code=400,
            message="Missing model in websocket follow-up request.",
        )
    normalized["model"] = model.strip()

    return normalized


def _normalize_follow_up_replay(
    payload: dict[str, JSONValue],
    *,
    last_request: dict[str, JSONValue],
    last_completed_output: JSONValue,
) -> dict[str, JSONValue]:
    next_input = payload.get("input")
    if not isinstance(next_input, list):
        raise ResponsesWebsocketError(
            status_code=400,
            message="WebSocket request requires array field: input",
        )

    normalized = dict(payload)
    normalized.pop("type", None)
    normalized.pop("generate", None)
    normalized.pop("previous_response_id", None)
    normalized["stream"] = True
    normalized["input"] = _merge_inputs(
        cast(list[JSONValue], last_request.get("input", [])),
        last_completed_output,
        next_input,
    )

    if "model" not in normalized and "model" in last_request:
        normalized["model"] = last_request["model"]
    model = normalized.get("model")
    if not isinstance(model, str) or not model.strip():
        raise ResponsesWebsocketError(
            status_code=400,
            message="Missing model in websocket follow-up request.",
        )
    normalized["model"] = model.strip()
    return normalized


def _merge_inputs(
    existing_input: list[JSONValue],
    last_completed_output: JSONValue,
    next_input: list[JSONValue],
) -> list[JSONValue]:
    merged = list(existing_input)
    if isinstance(last_completed_output, list):
        merged.extend(last_completed_output)
    merged.extend(next_input)
    return merged


def _should_handle_local_prewarm(payload: dict[str, JSONValue]) -> bool:
    generate = payload.get("generate")
    return generate is False


def _starts_fresh_chain(payload: dict[str, JSONValue]) -> bool:
    if "previous_response_id" not in payload:
        return True
    previous_response_id = payload.get("previous_response_id")
    if previous_response_id is None:
        return True
    if isinstance(previous_response_id, str) and not previous_response_id.strip():
        return True
    return False


def _normalize_previous_response_id_field(normalized: dict[str, JSONValue]) -> None:
    previous_response_id = normalized.get("previous_response_id")
    if previous_response_id is None:
        normalized.pop("previous_response_id", None)
        return
    if not isinstance(previous_response_id, str):
        raise ResponsesWebsocketError(
            status_code=400,
            message="Invalid previous_response_id in websocket request.",
        )
    trimmed = previous_response_id.strip()
    if not trimmed:
        normalized.pop("previous_response_id", None)
        return
    normalized["previous_response_id"] = trimmed


def _optional_string(value: JSONValue) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ResponsesWebsocketError(
            status_code=400,
            message="Invalid previous_response_id in websocket request.",
        )
    trimmed = value.strip()
    return trimmed or None


def _validate_previous_response_id(
    *,
    previous_response_id: str,
    expected_previous_response_id: str | None,
) -> None:
    if expected_previous_response_id is None:
        return
    if previous_response_id != expected_previous_response_id:
        raise ResponsesWebsocketError(
            status_code=409,
            message="previous_response_id does not match the active websocket turn.",
            error_type="invalid_websocket_turn",
        )


def _require_string(value: JSONValue, *, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ResponsesWebsocketError(
            status_code=400,
            message=f"Missing or invalid websocket field: {field}",
        )
    return value.strip()
