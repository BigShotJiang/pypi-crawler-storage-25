from __future__ import annotations

import codecs
import json
from collections.abc import AsyncIterator

from stronk_mask.proxy.debug import BoundedDebugTextBuffer
from stronk_mask.redaction.models import JSONValue, PlaceholderVault


class SSERehydrator:
    def __init__(self, vault: PlaceholderVault, *, capture_limit_bytes: int = 0) -> None:
        self.vault = vault
        self._buffers: dict[str, str] = {}
        self.rehydration_count = 0
        self.masked_stream_text = ""
        self.rehydrated_stream_text = ""
        self._masked_capture = BoundedDebugTextBuffer(limit_bytes=capture_limit_bytes)
        self._rehydrated_capture = BoundedDebugTextBuffer(limit_bytes=capture_limit_bytes)

    async def transform(self, source: AsyncIterator[bytes]) -> AsyncIterator[bytes]:
        decoder = codecs.getincrementaldecoder("utf-8")()
        pending = ""
        async for chunk in source:
            pending += decoder.decode(chunk)
            pending = pending.replace("\r\n", "\n")
            while "\n\n" in pending:
                block, pending = pending.split("\n\n", maxsplit=1)
                transformed_block = self._transform_block(block)
                self._masked_capture.append(f"{block}\n\n")
                self._rehydrated_capture.append(f"{transformed_block}\n\n")
                self.masked_stream_text = self._masked_capture.render()
                self.rehydrated_stream_text = self._rehydrated_capture.render()
                yield f"{transformed_block}\n\n".encode()
        pending += decoder.decode(b"", final=True)
        pending = pending.replace("\r\n", "\n")
        if pending:
            transformed_block = self._transform_block(pending)
            self._masked_capture.append(pending)
            self._rehydrated_capture.append(transformed_block)
            self.masked_stream_text = self._masked_capture.render()
            self.rehydrated_stream_text = self._rehydrated_capture.render()
            yield transformed_block.encode("utf-8")

    def _transform_block(self, block: str) -> str:
        lines: list[str] = []
        for line in block.split("\n"):
            if not line.startswith("data:"):
                lines.append(line)
                continue

            raw_value = line[5:].lstrip()
            if raw_value == "[DONE]":
                lines.append("data: [DONE]")
                continue

            try:
                parsed = json.loads(raw_value)
            except json.JSONDecodeError:
                lines.append(f"data: {self.vault.rehydrate_text(raw_value)}")
                continue

            transformed = self._transform_value(parsed, "")
            lines.append(
                "data: " + json.dumps(transformed, ensure_ascii=False, separators=(",", ":"))
            )
        return "\n".join(lines)

    def _transform_value(self, value: JSONValue, path: str) -> JSONValue:
        if isinstance(value, dict):
            return {
                key: self._transform_value(item, _join_pointer(path, key))
                for key, item in value.items()
            }
        if isinstance(value, list):
            return [
                self._transform_value(item, _join_pointer(path, str(index)))
                for index, item in enumerate(value)
            ]
        if isinstance(value, str):
            if not _should_rehydrate_string(path):
                return value
            return self._rehydrate_stream_text(path, value)
        return value

    def _rehydrate_stream_text(self, path: str, text: str) -> str:
        combined = self._buffers.get(path, "") + text
        placeholder_count = self.vault.count_occurrences(combined)
        rehydrated = self.vault.rehydrate_text(combined)
        safe, remainder = _split_rehydratable_tail(rehydrated, self.vault.placeholder_prefixes())
        self._buffers[path] = remainder
        self.rehydration_count += placeholder_count
        return safe


def _split_rehydratable_tail(text: str, prefixes: set[str]) -> tuple[str, str]:
    max_prefix_length = 0
    for prefix in prefixes:
        if text.endswith(prefix) and len(prefix) > max_prefix_length:
            max_prefix_length = len(prefix)
    if max_prefix_length == 0:
        return text, ""
    return text[:-max_prefix_length], text[-max_prefix_length:]


def _should_rehydrate_string(path: str) -> bool:
    if not path:
        return True
    segments = [segment for segment in path.split("/") if segment]
    if not segments:
        return True
    if any(segment in {"arguments", "id", "metadata", "name", "url"} for segment in segments):
        return False
    return segments[-1] in {"content", "delta", "text"}


def _join_pointer(base: str, segment: str) -> str:
    escaped = segment.replace("~", "~0").replace("/", "~1")
    return f"/{escaped}" if not base else f"{base}/{escaped}"
