from __future__ import annotations

import json
from pathlib import Path
from typing import TypedDict, cast

MATERIALIZATION_SUMMARY_NAME = "materialization-summary.json"
HERMES_CONNECT_NAME = "hermes-connect.json"
DOCTOR_REPORT_NAME = "doctor-report.json"


class ProviderArtifact(TypedDict):
    id: str
    label: str
    kind: str
    base_url: str | None
    secret_ref: str | None
    cliproxy_provider_name: str | None
    readiness_posture: str
    auth_source_type: str | None
    materialized_at: str | None
    model_count: int | None
    published_model_aliases: list[str]


class ModelArtifact(TypedDict):
    provider_id: str | None
    provider_label: str | None
    upstream_id: str | None
    public_alias: str
    backend_id: str | None
    endpoint_id: str | None
    privacy_policy_id: str | None
    enabled: bool | None
    readiness_posture: str
    fallback_note: str | None


class EndpointArtifact(TypedDict):
    public_alias: str
    privacy_policy_id: str
    backend_linkage: str


class MaterializationArtifact(TypedDict):
    available: bool
    schema_version: str | None
    generated_at: str | None
    provider_count: int | None
    published_model_count: int | None
    published_model_aliases: list[str]
    providers: list[ProviderArtifact]
    models: list[ModelArtifact]
    endpoints: list[EndpointArtifact]


class HermesSnippet(TypedDict):
    label: str | None
    snippet: str | None


class HermesArtifact(TypedDict):
    available: bool
    schema_version: str | None
    public_base_url: str | None
    recommended_model_aliases: list[str]
    credential_flow: str
    copy_snippets: list[HermesSnippet]


class DoctorCheck(TypedDict):
    name: str
    status: str
    message: str
    evidence_ref: str | None


class DoctorArtifact(TypedDict):
    available: bool
    schema_version: str | None
    generated_at: str | None
    checks: list[DoctorCheck]
    private_surface_posture: str
    bundle_version: str | None
    image_pins: dict[str, str]
    providers: list[dict[str, object]]


class GatewayArtifactsSnapshot(TypedDict):
    artifact_dir: str | None
    warnings: list[str]
    schema_version: str | None
    materialization: MaterializationArtifact
    hermes: HermesArtifact
    doctor: DoctorArtifact


def load_gateway_artifacts(artifacts_dir: str | None) -> GatewayArtifactsSnapshot:
    warnings: list[str] = []
    artifact_root = _resolve_artifact_root(artifacts_dir)
    if artifact_root is None:
        warnings.append("Gateway generated artifact directory is not configured.")
        return {
            "artifact_dir": None,
            "warnings": warnings,
            "schema_version": None,
            "materialization": _empty_materialization_state(),
            "hermes": _empty_hermes_state(),
            "doctor": _empty_doctor_state(),
        }

    materialization = _load_materialization_summary(
        artifact_root / MATERIALIZATION_SUMMARY_NAME,
        warnings=warnings,
    )
    hermes = _load_hermes_connect(
        artifact_root / HERMES_CONNECT_NAME,
        warnings=warnings,
    )
    doctor = _load_doctor_report(
        artifact_root / DOCTOR_REPORT_NAME,
        warnings=warnings,
    )

    schema_versions = {
        value
        for value in (
            materialization["schema_version"],
            hermes["schema_version"],
            doctor["schema_version"],
        )
        if isinstance(value, str) and value
    }
    schema_version = next(iter(schema_versions)) if len(schema_versions) == 1 else None
    if len(schema_versions) > 1:
        warnings.append("Gateway generated artifacts disagree on schema_version.")

    return {
        "artifact_dir": str(artifact_root),
        "warnings": warnings,
        "schema_version": schema_version,
        "materialization": materialization,
        "hermes": hermes,
        "doctor": doctor,
    }


def summarize_doctor_status(checks: list[DoctorCheck]) -> str:
    normalized = [
        _normalize_status(str(check.get("status", "")))
        for check in checks
        if isinstance(check, dict)
    ]
    if not normalized:
        return "unknown"
    if any(status in {"error", "fail", "failing"} for status in normalized):
        return "fail"
    if any(status in {"warn", "warning", "degraded"} for status in normalized):
        return "warn"
    if all(status in {"ok", "pass", "healthy"} for status in normalized):
        return "pass"
    return "unknown"


def _resolve_artifact_root(artifacts_dir: str | None) -> Path | None:
    if not artifacts_dir:
        return None
    resolved = Path(artifacts_dir).expanduser()
    if not resolved.is_absolute():
        resolved = (Path.cwd() / resolved).resolve()
    return resolved


def _load_materialization_summary(
    path: Path,
    *,
    warnings: list[str],
) -> MaterializationArtifact:
    payload = _load_json_object(path, warnings=warnings, artifact_label="materialization summary")
    if payload is None:
        return _empty_materialization_state()

    providers = payload.get("providers")
    models = payload.get("models")
    endpoints = payload.get("endpoints")
    allowed_providers: list[ProviderArtifact] = []
    if isinstance(providers, list):
        for index, item in enumerate(providers):
            if not isinstance(item, dict):
                warnings.append(
                    f"Gateway materialization summary providers[{index}] is not an object."
                )
                continue
            allowed_providers.append(
                {
                    "id": _coerce_string(item.get("id")) or f"provider-{index + 1}",
                    "label": _coerce_string(item.get("label"))
                    or _coerce_string(item.get("provider"))
                    or f"Provider {index + 1}",
                    "kind": _coerce_string(item.get("kind")) or "unknown",
                    "base_url": _coerce_string(item.get("base_url")),
                    "secret_ref": _coerce_string(item.get("secret_ref")),
                    "cliproxy_provider_name": _coerce_string(item.get("cliproxy_provider_name")),
                    "readiness_posture": _coerce_string(item.get("readiness_posture")) or "unknown",
                    "auth_source_type": _coerce_string(item.get("auth_source_type")),
                    "materialized_at": _coerce_string(item.get("materialized_at")),
                    "model_count": _coerce_int(item.get("model_count")),
                    "published_model_aliases": _coerce_string_list(
                        item.get("published_model_aliases")
                    ),
                }
            )
    elif providers is not None:
        warnings.append("Gateway materialization summary providers must be a list.")

    allowed_models: list[ModelArtifact] = []
    if isinstance(models, list):
        for index, item in enumerate(models):
            if not isinstance(item, dict):
                warnings.append(
                    f"Gateway materialization summary models[{index}] is not an object."
                )
                continue
            alias = _coerce_string(item.get("public_alias")) or f"model-{index + 1}"
            allowed_models.append(
                {
                    "provider_id": _coerce_string(item.get("provider_id")),
                    "provider_label": _coerce_string(item.get("provider_label")),
                    "upstream_id": _coerce_string(item.get("upstream_id")),
                    "public_alias": alias,
                    "backend_id": _coerce_string(item.get("backend_id")),
                    "endpoint_id": _coerce_string(item.get("endpoint_id")),
                    "privacy_policy_id": _coerce_string(item.get("privacy_policy_id")),
                    "enabled": _coerce_bool(item.get("enabled")),
                    "readiness_posture": _coerce_string(item.get("readiness_posture")) or "unknown",
                    "fallback_note": _coerce_string(item.get("fallback_note")),
                }
            )
    elif models is not None:
        warnings.append("Gateway materialization summary models must be a list.")

    allowed_endpoints: list[EndpointArtifact] = []
    if isinstance(endpoints, list):
        for index, item in enumerate(endpoints):
            if not isinstance(item, dict):
                warnings.append(
                    f"Gateway materialization summary endpoints[{index}] is not an object."
                )
                continue
            allowed_endpoints.append(
                {
                    "public_alias": _coerce_string(item.get("public_alias"))
                    or f"endpoint-{index + 1}",
                    "privacy_policy_id": _coerce_string(item.get("privacy_policy_id")) or "unknown",
                    "backend_linkage": _coerce_string(item.get("backend_linkage"))
                    or _coerce_string(item.get("backend_id"))
                    or "unknown",
                }
            )
    elif endpoints is not None:
        warnings.append("Gateway materialization summary endpoints must be a list.")

    return {
        "available": True,
        "schema_version": _coerce_string(payload.get("schema_version")),
        "generated_at": _coerce_string(payload.get("generated_at")),
        "provider_count": _coerce_int(payload.get("provider_count")),
        "published_model_count": _coerce_int(payload.get("published_model_count")),
        "published_model_aliases": _coerce_string_list(payload.get("published_model_aliases")),
        "providers": allowed_providers,
        "models": allowed_models,
        "endpoints": allowed_endpoints,
    }


def _load_hermes_connect(
    path: Path,
    *,
    warnings: list[str],
) -> HermesArtifact:
    payload = _load_json_object(path, warnings=warnings, artifact_label="Hermes connect")
    if payload is None:
        return _empty_hermes_state()

    recommended_aliases = payload.get("recommended_model_aliases")
    if isinstance(recommended_aliases, list):
        aliases = [
            alias
            for item in recommended_aliases
            if (alias := _coerce_string(item)) is not None
        ]
    else:
        aliases = []
        if recommended_aliases is not None:
            warnings.append("Gateway Hermes connect recommended_model_aliases must be a list.")

    snippets = payload.get("copy_snippets")
    if isinstance(snippets, list):
        copy_snippets: list[HermesSnippet] = [
            {
                "label": _coerce_string(item.get("label")) if isinstance(item, dict) else None,
                "snippet": _coerce_string(item.get("snippet"))
                if isinstance(item, dict)
                else _coerce_string(item),
            }
            for item in snippets
            if (isinstance(item, dict) and _coerce_string(item.get("snippet")) is not None)
            or _coerce_string(item) is not None
        ]
    elif isinstance(snippets, dict):
        copy_snippets = [
            {"label": key, "snippet": value}
            for key, raw_value in snippets.items()
            if isinstance(key, str) and (value := _coerce_string(raw_value)) is not None
        ]
    else:
        copy_snippets = []
        if snippets is not None:
            warnings.append("Gateway Hermes connect copy_snippets must be a list or object.")

    return {
        "available": True,
        "schema_version": _coerce_string(payload.get("schema_version")),
        "public_base_url": _coerce_string(payload.get("public_base_url")),
        "recommended_model_aliases": aliases,
        "credential_flow": _coerce_string(payload.get("credential_flow")) or "unknown",
        "copy_snippets": copy_snippets,
    }


def _load_doctor_report(
    path: Path,
    *,
    warnings: list[str],
) -> DoctorArtifact:
    payload = _load_json_object(path, warnings=warnings, artifact_label="doctor report")
    if payload is None:
        return _empty_doctor_state()

    raw_checks = payload.get("checks")
    checks: list[DoctorCheck] = []
    if isinstance(raw_checks, list):
        for index, item in enumerate(raw_checks):
            if not isinstance(item, dict):
                warnings.append(f"Gateway doctor report checks[{index}] is not an object.")
                continue
            name = _coerce_string(item.get("name"))
            status = _coerce_string(item.get("status"))
            message = _coerce_string(item.get("message"))
            if name is None or status is None or message is None:
                warnings.append(
                    "Gateway doctor report checks entries must include name, status, and message."
                )
                continue
            checks.append(
                {
                    "name": name,
                    "status": status,
                    "message": message,
                    "evidence_ref": _coerce_string(item.get("evidence_ref")),
                }
            )
    elif raw_checks is not None:
        warnings.append("Gateway doctor report checks must be a list.")

    image_pins = payload.get("image_pins")
    if isinstance(image_pins, dict):
        allowed_image_pins = {
            key: value
            for key, raw_value in image_pins.items()
            if isinstance(key, str) and (value := _coerce_string(raw_value)) is not None
        }
    elif isinstance(image_pins, list):
        allowed_image_pins = {
            f"image-{index + 1}": value
            for index, raw_value in enumerate(image_pins)
            if (value := _coerce_string(raw_value)) is not None
        }
    else:
        allowed_image_pins = {}
        if image_pins is not None:
            warnings.append("Gateway doctor report image_pins must be an object or list.")

    providers = payload.get("providers")
    return {
        "available": True,
        "schema_version": _coerce_string(payload.get("schema_version")),
        "generated_at": _coerce_string(payload.get("generated_at")),
        "checks": checks,
        "private_surface_posture": _coerce_string(payload.get("private_surface_posture"))
        or "unknown",
        "bundle_version": _coerce_string(payload.get("bundle_version")),
        "image_pins": allowed_image_pins,
        "providers": (
            cast(list[dict[str, object]], providers) if isinstance(providers, list) else []
        ),
    }


def _load_json_object(
    path: Path,
    *,
    warnings: list[str],
    artifact_label: str,
) -> dict[str, object] | None:
    if not path.exists():
        warnings.append(f"Gateway {artifact_label} is missing at {path}.")
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        warnings.append(f"Gateway {artifact_label} could not be parsed from {path}.")
        return None
    if not isinstance(payload, dict):
        warnings.append(f"Gateway {artifact_label} must be a JSON object.")
        return None
    return payload


def _coerce_string(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip()
    return normalized or None


def _coerce_string_list(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    return [item for raw in value if (item := _coerce_string(raw)) is not None]


def _coerce_int(value: object) -> int | None:
    if not isinstance(value, int):
        return None
    return value


def _coerce_bool(value: object) -> bool | None:
    if not isinstance(value, bool):
        return None
    return value


def _normalize_status(status: str) -> str:
    return status.strip().lower()


def _empty_materialization_state() -> MaterializationArtifact:
    return {
        "available": False,
        "schema_version": None,
        "generated_at": None,
        "provider_count": None,
        "published_model_count": None,
        "published_model_aliases": [],
        "providers": [],
        "models": [],
        "endpoints": [],
    }


def _empty_hermes_state() -> HermesArtifact:
    return {
        "available": False,
        "schema_version": None,
        "public_base_url": None,
        "recommended_model_aliases": [],
        "credential_flow": "cli_only",
        "copy_snippets": [],
    }


def _empty_doctor_state() -> DoctorArtifact:
    return {
        "available": False,
        "schema_version": None,
        "generated_at": None,
        "checks": [],
        "private_surface_posture": "unknown",
        "bundle_version": None,
        "image_pins": {},
        "providers": [],
    }
