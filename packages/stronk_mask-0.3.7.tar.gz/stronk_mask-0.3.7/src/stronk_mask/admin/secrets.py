from __future__ import annotations

import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile

PROVIDER_SECRET_REF_RE = re.compile(r"^PROVIDER_[A-Z0-9_]+$")
GATEWAY_SECRET_REF_RE = re.compile(r"^STRONK_GATEWAY_[A-Z0-9_]+$")


class SecretResolutionError(ValueError):
    pass


@dataclass(frozen=True)
class SecretResolution:
    name: str
    found: bool
    source: str | None
    path: str | None

    def to_payload(self) -> dict[str, object]:
        return {
            "name": self.name,
            "found": self.found,
            "source": self.source,
            "path": self.path,
        }


def validate_resolvable_secret_ref(secret_ref: str) -> str:
    cleaned = secret_ref.strip()
    if not cleaned:
        raise SecretResolutionError("secret_ref must not be empty")
    if PROVIDER_SECRET_REF_RE.fullmatch(cleaned):
        return cleaned
    if GATEWAY_SECRET_REF_RE.fullmatch(cleaned):
        return cleaned
    raise SecretResolutionError(
        "secret_ref must match ^PROVIDER_[A-Z0-9_]+$ or ^STRONK_GATEWAY_[A-Z0-9_]+$"
    )


def resolve_secret_ref(
    secret_ref: str,
    *,
    process_env: dict[str, str] | None = None,
    env_path: Path | None = None,
    secrets_dir: Path | None = None,
) -> tuple[str | None, SecretResolution]:
    normalized = validate_resolvable_secret_ref(secret_ref)
    env = process_env if process_env is not None else dict(os.environ)
    value = env.get(normalized, "").strip()
    if value:
        return value, SecretResolution(
            name=normalized,
            found=True,
            source="env",
            path=None,
        )
    if env_path is not None:
        env_values = load_env_file(env_path)
        file_env_value = env_values.get(normalized, "").strip()
        if file_env_value:
            return file_env_value, SecretResolution(
                name=normalized,
                found=True,
                source="env_file",
                path=str(env_path),
            )
    if secrets_dir is not None:
        secret_path = secrets_dir / normalized
        try:
            file_value = _read_secret_file(secret_path).strip()
        except FileNotFoundError:
            file_value = ""
        if file_value:
            return file_value, SecretResolution(
                name=normalized,
                found=True,
                source="file",
                path=str(secret_path),
            )
    return None, SecretResolution(
        name=normalized,
        found=False,
        source=None,
        path=None,
    )


def load_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        key, separator, value = raw_line.partition("=")
        if not separator:
            raise SecretResolutionError(f"Invalid env line in {path}: {raw_line}")
        values[key.strip()] = value.strip()
    return values


def write_env_file(path: Path, values: dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    rendered = "".join(f"{key}={values[key]}\n" for key in sorted(values))
    with NamedTemporaryFile(
        "w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        handle.write(rendered)
        temp_path = Path(handle.name)
    temp_path.replace(path)


def sync_secret_into_env_file(path: Path, *, secret_ref: str, value: str) -> None:
    normalized = validate_resolvable_secret_ref(secret_ref)
    env_values = load_env_file(path)
    env_values[normalized] = value.strip()
    write_env_file(path, env_values)


def _read_secret_file(path: Path) -> str:
    stat_result = path.lstat()
    if stat.S_ISLNK(stat_result.st_mode):
        raise SecretResolutionError(f"secret file {path} must not be a symlink")
    if not stat.S_ISREG(stat_result.st_mode):
        raise SecretResolutionError(f"secret file {path} must be a regular file")
    if stat.S_IMODE(stat_result.st_mode) & 0o077:
        raise SecretResolutionError(
            f"secret file {path} must not be group- or world-readable/writable"
        )
    return path.read_text(encoding="utf-8")
