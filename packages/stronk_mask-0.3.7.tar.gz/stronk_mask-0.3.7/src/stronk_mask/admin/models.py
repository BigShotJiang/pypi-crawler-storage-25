from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AdminPrincipal:
    user: str
    roles: tuple[str, ...]

    def has_any_role(self, allowed_roles: frozenset[str]) -> bool:
        return bool(set(self.roles).intersection(allowed_roles))

    def to_payload(self) -> dict[str, object]:
        return {
            "user": self.user,
            "roles": list(self.roles),
        }


@dataclass(frozen=True)
class AdminAccessRecord:
    created_at: str
    actor: str
    roles: tuple[str, ...]
    path: str
    method: str
    status_code: int
    source_ip: str | None

    def to_payload(self) -> dict[str, object]:
        return {
            "created_at": self.created_at,
            "actor": self.actor,
            "roles": list(self.roles),
            "path": self.path,
            "method": self.method,
            "status_code": self.status_code,
            "source_ip": self.source_ip,
        }


@dataclass(frozen=True)
class AdminSessionRecord:
    token_hash: str
    user: str
    roles: tuple[str, ...]
    device_id: str | None
    auth_binding: str | None
    created_at: int
    last_seen_at: int
    absolute_expires_at: int

    def to_principal(self) -> AdminPrincipal:
        return AdminPrincipal(user=self.user, roles=self.roles)


@dataclass(frozen=True)
class AdminEnrollmentRecord:
    device_id: str
    tailscale_login: str
    browser_public_key: str
    approved_role: str | None
    approved_at: str | None
    last_seen_at: str
    revoked_at: str | None

    @property
    def is_approved(self) -> bool:
        return (
            self.approved_role is not None
            and self.approved_at is not None
            and self.revoked_at is None
        )

    def to_payload(self) -> dict[str, object]:
        return {
            "device_id": self.device_id,
            "tailscale_login": self.tailscale_login,
            "browser_public_key": self.browser_public_key,
            "approved_role": self.approved_role,
            "approved_at": self.approved_at,
            "last_seen_at": self.last_seen_at,
            "revoked_at": self.revoked_at,
            "is_approved": self.is_approved,
        }
