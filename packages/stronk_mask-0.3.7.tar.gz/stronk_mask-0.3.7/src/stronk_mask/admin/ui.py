from __future__ import annotations

from pathlib import Path

from stronk_mask.config import Settings


def resolve_admin_ui_dir(settings: Settings) -> Path | None:
    candidates: list[Path] = []
    if settings.admin_ui_dir:
        candidates.append(Path(settings.admin_ui_dir))

    repo_root = Path(__file__).resolve().parents[3]
    candidates.append(repo_root / "web" / "dist")
    candidates.append(Path.cwd() / "web" / "dist")

    for candidate in candidates:
        if (candidate / "index.html").exists():
            return candidate
    return None
