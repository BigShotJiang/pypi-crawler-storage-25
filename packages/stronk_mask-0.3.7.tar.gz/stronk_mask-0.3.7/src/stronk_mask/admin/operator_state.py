from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

OPERATOR_STATE_SCHEMA_VERSION = "stronk.operator-state/v2"
SUPPORTED_PROVIDER_KIND = "openai_compat"
PROVIDER_SECRET_REF_RE = re.compile(r"^PROVIDER_[A-Z0-9_]+$")
SLUG_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
# Local-smoke bundles seed the packaged fake upstream on this Docker DNS name.
LOCAL_HTTP_HOSTS = {"localhost", "127.0.0.1", "::1", "fake-openai-upstream"}


class OperatorStateError(ValueError):
    pass


def slugify_identifier(value: str) -> str:
    collapsed = re.sub(r"[^a-z0-9]+", "-", value.strip().lower()).strip("-")
    collapsed = re.sub(r"-{2,}", "-", collapsed)
    if not collapsed:
        raise OperatorStateError("identifier must contain at least one alphanumeric character")
    if not SLUG_RE.fullmatch(collapsed):
        raise OperatorStateError("identifier must be slug-safe")
    return collapsed


def normalize_provider_base_url(value: object) -> str:
    if not isinstance(value, str) or not value.strip():
        raise OperatorStateError("base_url must be a non-empty string")
    cleaned = value.strip().rstrip("/")
    parsed = urlparse(cleaned)
    if parsed.scheme not in {"http", "https"}:
        raise OperatorStateError("base_url must use http or https")
    if not parsed.netloc or not parsed.hostname:
        raise OperatorStateError("base_url must include a host")
    if parsed.params or parsed.query or parsed.fragment:
        raise OperatorStateError("base_url must not include params, query, or fragment")
    if parsed.username or parsed.password:
        raise OperatorStateError("base_url must not embed credentials")
    if parsed.scheme == "http" and parsed.hostname not in LOCAL_HTTP_HOSTS:
        raise OperatorStateError("base_url must use https or localhost http")
    return cleaned


def normalize_provider_secret_ref(value: object) -> str:
    if value is None:
        return ""
    if not isinstance(value, str):
        raise OperatorStateError("secret_ref must be a string")
    cleaned = value.strip()
    if not cleaned:
        return ""
    if not PROVIDER_SECRET_REF_RE.fullmatch(cleaned):
        raise OperatorStateError(
            "secret_ref must match ^PROVIDER_[A-Z0-9_]+$ or be empty for keyless local providers"
        )
    return cleaned


def _require_non_empty_string(value: object, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise OperatorStateError(f"{field_name} must be a non-empty string")
    return value.strip()


def _require_bool(value: object, field_name: str) -> bool:
    if not isinstance(value, bool):
        raise OperatorStateError(f"{field_name} must be a boolean")
    return value


@dataclass(frozen=True)
class ProviderModel:
    upstream_id: str
    public_alias: str | None
    privacy_policy_id: str
    enabled: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "upstream_id": self.upstream_id,
            "public_alias": self.public_alias,
            "privacy_policy_id": self.privacy_policy_id,
            "enabled": self.enabled,
        }


@dataclass(frozen=True)
class Provider:
    id: str
    label: str
    kind: str
    base_url: str
    secret_ref: str
    cliproxy_provider_name: str
    models: tuple[ProviderModel, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "id": self.id,
            "label": self.label,
            "kind": self.kind,
            "base_url": self.base_url,
            "secret_ref": self.secret_ref,
            "cliproxy_provider_name": self.cliproxy_provider_name,
            "models": [model.to_dict() for model in self.models],
        }


@dataclass(frozen=True)
class PrivacyPolicy:
    id: str
    presidio_required: bool
    spacy_required: bool
    fail_closed_detector_types: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "id": self.id,
            "presidio_required": self.presidio_required,
            "spacy_required": self.spacy_required,
            "fail_closed_detector_types": list(self.fail_closed_detector_types),
        }


@dataclass(frozen=True)
class OperatorState:
    schema_version: str
    providers: tuple[Provider, ...]
    privacy_policies: tuple[PrivacyPolicy, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "providers": [provider.to_dict() for provider in self.providers],
            "privacy_policies": [policy.to_dict() for policy in self.privacy_policies],
        }


def create_empty_operator_state(
    *,
    privacy_policies: tuple[PrivacyPolicy, ...] = (),
) -> OperatorState:
    state = OperatorState(
        schema_version=OPERATOR_STATE_SCHEMA_VERSION,
        providers=tuple(),
        privacy_policies=privacy_policies,
    )
    validate_operator_state(state)
    return state


def parse_operator_state(payload: dict[str, object]) -> OperatorState:
    if payload.get("schema_version") != OPERATOR_STATE_SCHEMA_VERSION:
        raise OperatorStateError(
            f"schema_version must be {OPERATOR_STATE_SCHEMA_VERSION}"
        )
    raw_providers = payload.get("providers")
    raw_policies = payload.get("privacy_policies")
    if not isinstance(raw_providers, list):
        raise OperatorStateError("providers must be a list")
    if not isinstance(raw_policies, list):
        raise OperatorStateError("privacy_policies must be a list")

    providers = tuple(
        _parse_provider(item, index=index) for index, item in enumerate(raw_providers)
    )
    policies = tuple(
        _parse_privacy_policy(item, index=index) for index, item in enumerate(raw_policies)
    )
    state = OperatorState(
        schema_version=OPERATOR_STATE_SCHEMA_VERSION,
        providers=providers,
        privacy_policies=policies,
    )
    validate_operator_state(state)
    return state


def load_operator_state(path: Path) -> OperatorState:
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise OperatorStateError("operator state payload must be an object")
    return parse_operator_state(raw)


def write_operator_state(path: Path, state: OperatorState) -> None:
    path.write_text(json.dumps(state.to_dict(), indent=2) + "\n", encoding="utf-8")


def validate_operator_state(state: OperatorState) -> None:
    if state.schema_version != OPERATOR_STATE_SCHEMA_VERSION:
        raise OperatorStateError(
            f"schema_version must be {OPERATOR_STATE_SCHEMA_VERSION}"
        )
    policy_ids = set()
    for policy in state.privacy_policies:
        if policy.id in policy_ids:
            raise OperatorStateError(f"duplicate privacy_policy id {policy.id}")
        policy_ids.add(policy.id)
        if not policy.fail_closed_detector_types:
            raise OperatorStateError(
                f"privacy_policy {policy.id} must declare fail_closed_detector_types"
            )

    provider_ids: set[str] = set()
    provider_names: set[str] = set()
    public_aliases: set[str] = set()
    for provider in state.providers:
        if provider.id in provider_ids:
            raise OperatorStateError(f"duplicate provider id {provider.id}")
        provider_ids.add(provider.id)
        if provider.kind != SUPPORTED_PROVIDER_KIND:
            raise OperatorStateError(
                f"provider {provider.id} kind must be {SUPPORTED_PROVIDER_KIND}"
            )
        if provider.cliproxy_provider_name in provider_names:
            raise OperatorStateError(
                f"duplicate cliproxy_provider_name {provider.cliproxy_provider_name}"
            )
        provider_names.add(provider.cliproxy_provider_name)
        slugify_identifier(provider.id)
        slugify_identifier(provider.cliproxy_provider_name)
        normalize_provider_base_url(provider.base_url)
        normalize_provider_secret_ref(provider.secret_ref)
        if provider.cliproxy_provider_name != provider.id:
            raise OperatorStateError(
                f"provider {provider.id} cliproxy_provider_name must match provider id"
            )

        model_ids: set[str] = set()
        for model in provider.models:
            if model.upstream_id in model_ids:
                raise OperatorStateError(
                    "provider "
                    f"{provider.id} contains duplicate model upstream_id {model.upstream_id}"
                )
            model_ids.add(model.upstream_id)
            if model.privacy_policy_id not in policy_ids:
                raise OperatorStateError(
                    "provider "
                    f"{provider.id} model {model.upstream_id} references unknown "
                    f"privacy_policy_id {model.privacy_policy_id}"
                )
            if model.public_alias is not None:
                alias = slugify_identifier(model.public_alias)
                if alias != model.public_alias:
                    raise OperatorStateError(
                        f"model public_alias {model.public_alias!r} must be slug-safe"
                    )
                if alias in public_aliases:
                    raise OperatorStateError(f"duplicate public_alias {alias}")
                public_aliases.add(alias)


def iter_published_aliases(state: OperatorState) -> tuple[str, ...]:
    aliases: list[str] = []
    for provider in state.providers:
        for model in provider.models:
            if model.enabled and model.public_alias is not None:
                aliases.append(model.public_alias)
    return tuple(aliases)


def _parse_provider(value: object, *, index: int) -> Provider:
    if not isinstance(value, dict):
        raise OperatorStateError(f"providers[{index}] must be an object")
    raw_models = value.get("models")
    if not isinstance(raw_models, list):
        raise OperatorStateError(f"providers[{index}].models must be a list")
    provider_id = slugify_identifier(
        _require_non_empty_string(value.get("id"), f"providers[{index}].id")
    )
    cliproxy_provider_name = slugify_identifier(
        _require_non_empty_string(
            value.get("cliproxy_provider_name"),
            f"providers[{index}].cliproxy_provider_name",
        )
    )
    if provider_id != cliproxy_provider_name:
        raise OperatorStateError(
            f"providers[{index}].cliproxy_provider_name must match providers[{index}].id"
        )
    provider = Provider(
        id=provider_id,
        label=_require_non_empty_string(value.get("label"), f"providers[{index}].label"),
        kind=_require_non_empty_string(value.get("kind"), f"providers[{index}].kind"),
        base_url=normalize_provider_base_url(value.get("base_url")),
        secret_ref=normalize_provider_secret_ref(value.get("secret_ref")),
        cliproxy_provider_name=cliproxy_provider_name,
        models=tuple(
            _parse_provider_model(model, provider_index=index, model_index=model_index)
            for model_index, model in enumerate(raw_models)
        ),
    )
    return provider


def _parse_provider_model(value: object, *, provider_index: int, model_index: int) -> ProviderModel:
    if not isinstance(value, dict):
        raise OperatorStateError(
            f"providers[{provider_index}].models[{model_index}] must be an object"
        )
    raw_alias = value.get("public_alias")
    public_alias: str | None
    if raw_alias is None:
        public_alias = None
    elif not isinstance(raw_alias, str):
        raise OperatorStateError(
            f"providers[{provider_index}].models[{model_index}].public_alias must be "
            "a string or null"
        )
    else:
        cleaned_alias = raw_alias.strip()
        public_alias = slugify_identifier(cleaned_alias) if cleaned_alias else None
    enabled_value = value.get("enabled", True)
    return ProviderModel(
        upstream_id=_require_non_empty_string(
            value.get("upstream_id"),
            f"providers[{provider_index}].models[{model_index}].upstream_id",
        ),
        public_alias=public_alias,
        privacy_policy_id=_require_non_empty_string(
            value.get("privacy_policy_id"),
            f"providers[{provider_index}].models[{model_index}].privacy_policy_id",
        ),
        enabled=_require_bool(
            enabled_value,
            f"providers[{provider_index}].models[{model_index}].enabled",
        ),
    )


def _parse_privacy_policy(value: object, *, index: int) -> PrivacyPolicy:
    if not isinstance(value, dict):
        raise OperatorStateError(f"privacy_policies[{index}] must be an object")
    raw_detector_types = value.get("fail_closed_detector_types")
    if not isinstance(raw_detector_types, list):
        raise OperatorStateError(
            f"privacy_policies[{index}].fail_closed_detector_types must be a list"
        )
    detector_types = tuple(
        _require_non_empty_string(
            detector_type,
            f"privacy_policies[{index}].fail_closed_detector_types[*]",
        )
        for detector_type in raw_detector_types
    )
    return PrivacyPolicy(
        id=slugify_identifier(
            _require_non_empty_string(value.get("id"), f"privacy_policies[{index}].id")
        ),
        presidio_required=_require_bool(
            value.get("presidio_required"),
            f"privacy_policies[{index}].presidio_required",
        ),
        spacy_required=_require_bool(
            value.get("spacy_required"),
            f"privacy_policies[{index}].spacy_required",
        ),
        fail_closed_detector_types=detector_types,
    )
