from __future__ import annotations

from .apply import (
    ApplyConflictError,
    ApplyManager,
    ApplyNotFoundError,
    ApplyRollbackError,
)
from .auth import (
    AdminAuthError,
    AdminLoginRateLimiter,
    authenticate_admin_request,
    build_admin_session_binding,
    build_auth_error_response,
    build_login_rate_limit_key,
    enforce_same_origin_for_state_change,
    hash_admin_password,
    hash_admin_session_token,
    issue_admin_session_token,
    require_admin_roles,
    resolve_admin_request_context,
    verify_admin_password,
)
from .materialize import materialize_bundle
from .models import AdminAccessRecord, AdminEnrollmentRecord, AdminPrincipal, AdminSessionRecord
from .operator_state import (
    OPERATOR_STATE_SCHEMA_VERSION,
    OperatorState,
    OperatorStateError,
    create_empty_operator_state,
    iter_published_aliases,
    normalize_provider_base_url,
    normalize_provider_secret_ref,
    parse_operator_state,
    slugify_identifier,
)
from .operator_state_store import OperatorStateStore, OperatorStateStoreError
from .secrets import SecretResolutionError, resolve_secret_ref, sync_secret_into_env_file
from .ssrf import (
    SsrfBlockedError,
    fetch_openai_models,
    load_host_allowlist,
    validate_provider_base_url,
)
from .store import AuditStore

__all__ = [
    "AdminAccessRecord",
    "AdminEnrollmentRecord",
    "AdminAuthError",
    "AdminLoginRateLimiter",
    "AdminPrincipal",
    "AdminSessionRecord",
    "ApplyConflictError",
    "ApplyManager",
    "ApplyNotFoundError",
    "ApplyRollbackError",
    "AuditStore",
    "OPERATOR_STATE_SCHEMA_VERSION",
    "OperatorState",
    "OperatorStateError",
    "OperatorStateStore",
    "OperatorStateStoreError",
    "SecretResolutionError",
    "SsrfBlockedError",
    "authenticate_admin_request",
    "build_admin_session_binding",
    "build_auth_error_response",
    "build_login_rate_limit_key",
    "create_empty_operator_state",
    "enforce_same_origin_for_state_change",
    "fetch_openai_models",
    "hash_admin_password",
    "hash_admin_session_token",
    "issue_admin_session_token",
    "iter_published_aliases",
    "load_host_allowlist",
    "materialize_bundle",
    "normalize_provider_base_url",
    "normalize_provider_secret_ref",
    "parse_operator_state",
    "require_admin_roles",
    "resolve_secret_ref",
    "resolve_admin_request_context",
    "slugify_identifier",
    "sync_secret_into_env_file",
    "validate_provider_base_url",
    "verify_admin_password",
]
