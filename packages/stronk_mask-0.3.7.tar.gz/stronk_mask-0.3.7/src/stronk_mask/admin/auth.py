from __future__ import annotations

import base64
import hashlib
import hmac
import ipaddress
import json
import re
import secrets
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from email.header import decode_header
from pathlib import Path
from threading import Lock
from urllib.parse import urlparse

import httpx
from fastapi import Request
from fastapi.responses import JSONResponse, PlainTextResponse, Response

from stronk_mask.admin.models import AdminPrincipal
from stronk_mask.admin.store import AuditStore
from stronk_mask.config import Settings

SCRYPT_PREFIX = "scrypt"
SCRYPT_N = 2**14
SCRYPT_R = 8
SCRYPT_P = 1
SCRYPT_DKLEN = 32


class AdminAuthError(Exception):
    def __init__(self, status_code: int, message: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.message = message


class AdminLoginRateLimiter:
    def __init__(self, *, attempt_limit: int, window_seconds: int) -> None:
        self.attempt_limit = attempt_limit
        self.window_seconds = window_seconds
        self._attempts: dict[str, list[float]] = {}
        self._lock = Lock()

    def is_limited(self, key: str, *, now: float | None = None) -> bool:
        resolved_now = time.time() if now is None else now
        with self._lock:
            attempts = self._prune(key, resolved_now)
            return len(attempts) >= self.attempt_limit

    def register_failure(self, key: str, *, now: float | None = None) -> None:
        resolved_now = time.time() if now is None else now
        with self._lock:
            attempts = self._prune(key, resolved_now)
            attempts.append(resolved_now)
            self._attempts[key] = attempts

    def clear(self, key: str) -> None:
        with self._lock:
            self._attempts.pop(key, None)

    def _prune(self, key: str, now: float) -> list[float]:
        cutoff = now - self.window_seconds
        attempts = [stamp for stamp in self._attempts.get(key, []) if stamp >= cutoff]
        if attempts:
            self._attempts[key] = attempts
        else:
            self._attempts.pop(key, None)
        return attempts


@dataclass(frozen=True)
class AdminTrustedProxyIdentity:
    login: str
    client_ip: str
    forwarded_host: str
    forwarded_proto: str
    external_origin: str


def hash_admin_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    derived = hashlib.scrypt(
        password.encode("utf-8"),
        salt=salt,
        n=SCRYPT_N,
        r=SCRYPT_R,
        p=SCRYPT_P,
        dklen=SCRYPT_DKLEN,
    )
    salt_b64 = base64.urlsafe_b64encode(salt).decode("ascii").rstrip("=")
    derived_b64 = base64.urlsafe_b64encode(derived).decode("ascii").rstrip("=")
    return f"{SCRYPT_PREFIX}${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${salt_b64}${derived_b64}"


def verify_admin_password(password: str, encoded_hash: str) -> bool:
    try:
        prefix, n_raw, r_raw, p_raw, salt_b64, expected_b64 = encoded_hash.split("$", maxsplit=5)
    except ValueError:
        return False
    if prefix != SCRYPT_PREFIX:
        return False
    try:
        salt = _decode_urlsafe_b64(salt_b64)
        expected = _decode_urlsafe_b64(expected_b64)
        derived = hashlib.scrypt(
            password.encode("utf-8"),
            salt=salt,
            n=int(n_raw),
            r=int(r_raw),
            p=int(p_raw),
            dklen=len(expected),
        )
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(derived, expected)


def issue_admin_session_token() -> str:
    return secrets.token_urlsafe(32)


def hash_admin_session_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def authenticate_admin_request(
    request: Request,
    settings: Settings,
    *,
    store: AuditStore | None = None,
) -> AdminPrincipal:
    mode = settings.admin_auth_mode
    session_error: AdminAuthError | None = None
    if mode in {"session", "hybrid"}:
        try:
            return _authenticate_admin_session(request, settings, store=store)
        except AdminAuthError as error:
            session_error = error
            if mode == "session":
                raise
    if mode in {"trusted_headers", "hybrid"}:
        return _authenticate_admin_headers(request, settings)
    assert session_error is not None
    raise session_error


def require_admin_roles(
    principal: AdminPrincipal,
    allowed_roles: frozenset[str],
    *,
    message: str,
) -> None:
    if not principal.has_any_role(allowed_roles):
        raise AdminAuthError(status_code=403, message=message)


def resolve_admin_request_context(
    request: Request,
    settings: Settings,
) -> AdminTrustedProxyIdentity | None:
    if settings.admin_access_mode != "tailscale-serve":
        return None

    immediate_client_ip = request.client.host if request.client is not None else ""
    if not _is_loopback_address(immediate_client_ip):
        raise AdminAuthError(
            status_code=401,
            message="Trusted Tailscale proxy requests must arrive from server loopback.",
        )

    login_header = _decode_identity_header(request.headers.get("tailscale-user-login"))
    forwarded_for = request.headers.get("x-forwarded-for", "")
    forwarded_proto = request.headers.get("x-forwarded-proto", "")
    forwarded_host = request.headers.get("x-forwarded-host", "")
    host = request.headers.get("host", "")

    if not login_header or not forwarded_for or not forwarded_host:
        raise AdminAuthError(
            status_code=401,
            message="Trusted Tailscale proxy headers are required for this admin access mode.",
        )
    if forwarded_proto.strip().lower() != "https":
        raise AdminAuthError(
            status_code=401,
            message="Trusted Tailscale proxy requests must forward HTTPS.",
        )

    forwarded_host_value = forwarded_host.strip().lower()
    if host and host.strip().lower() != forwarded_host_value:
        raise AdminAuthError(
            status_code=401,
            message="Trusted Tailscale proxy host headers did not match the forwarded host.",
        )

    client_ip = forwarded_for.split(",")[0].strip()
    if not client_ip:
        raise AdminAuthError(
            status_code=401,
            message="Trusted Tailscale proxy requests must include a client IP.",
        )

    external_origin = f"https://{forwarded_host_value}".rstrip("/")
    if external_origin not in settings.admin_allowed_origin_set:
        raise AdminAuthError(
            status_code=403,
            message="Trusted Tailscale proxy origin is not allowlisted for the admin plane.",
        )

    whois_login = _tailscale_whois_login(client_ip, settings)
    if whois_login.casefold() != login_header.casefold():
        raise AdminAuthError(
            status_code=401,
            message="Trusted Tailscale proxy identity did not match the verified client login.",
        )

    return AdminTrustedProxyIdentity(
        login=login_header,
        client_ip=client_ip,
        forwarded_host=forwarded_host_value,
        forwarded_proto="https",
        external_origin=external_origin,
    )


def enforce_same_origin_for_state_change(request: Request, settings: Settings) -> None:
    expected_origin = _request_origin(request, settings)
    origin = request.headers.get("origin")
    referer = request.headers.get("referer")
    if origin and origin.rstrip("/") != expected_origin:
        raise AdminAuthError(
            status_code=403,
            message="Cross-site admin state change rejected.",
        )
    if settings.admin_access_mode == "tailscale-serve" and not origin and not referer:
        raise AdminAuthError(
            status_code=403,
            message="Trusted Tailscale browser requests must include an origin or referer.",
        )
    if not origin and referer:
        referer_origin = _origin_from_url(referer)
        if referer_origin is not None and referer_origin != expected_origin:
            raise AdminAuthError(
                status_code=403,
                message="Cross-site admin state change rejected.",
            )


def build_auth_error_response(request: Request, status_code: int, message: str) -> Response:
    if request.url.path.startswith("/api/"):
        return JSONResponse(
            status_code=status_code,
            content={
                "error": {
                    "message": message,
                    "type": "admin_auth_error",
                    "code": "admin_auth_error",
                }
            },
        )
    return PlainTextResponse(message, status_code=status_code)


def _authenticate_admin_session(
    request: Request,
    settings: Settings,
    *,
    store: AuditStore | None,
) -> AdminPrincipal:
    if store is None:
        raise AdminAuthError(
            status_code=503,
            message="Admin session store is unavailable.",
        )
    session_token = request.cookies.get(settings.admin_session_cookie_name)
    if session_token is None or not session_token.strip():
        raise AdminAuthError(
            status_code=401,
            message="Admin session is required for the control plane.",
        )
    session = store.get_session(
        hash_admin_session_token(session_token.strip()),
        idle_ttl_seconds=settings.admin_session_idle_ttl_seconds,
    )
    if session is None:
        raise AdminAuthError(
            status_code=401,
            message="Admin session is invalid or expired.",
        )
    if settings.admin_access_mode == "tailscale-serve":
        trusted_identity = getattr(request.state, "admin_trusted_proxy_identity", None)
        if trusted_identity is None:
            raise AdminAuthError(
                status_code=401,
                message="Trusted Tailscale proxy headers are required for the control plane.",
            )
        if session.device_id is None:
            store.delete_session(session.token_hash)
            raise AdminAuthError(
                status_code=401,
                message="Admin session is missing its enrolled device binding.",
            )
        enrollment = store.get_enrollment(session.device_id)
        if enrollment is None or not enrollment.is_approved:
            store.delete_session(session.token_hash)
            raise AdminAuthError(
                status_code=401,
                message="Admin device enrollment is missing, revoked, or no longer approved.",
            )
        if enrollment.tailscale_login.casefold() != trusted_identity.login.casefold():
            store.delete_session(session.token_hash)
            raise AdminAuthError(
                status_code=401,
                message="Trusted Tailscale device identity no longer matches this session.",
            )
        approved_roles = (
            (enrollment.approved_role,)
            if enrollment.approved_role is not None
            else tuple()
        )
        if session.roles != approved_roles:
            store.delete_session(session.token_hash)
            raise AdminAuthError(
                status_code=401,
                message="Admin session roles are stale. Sign in again.",
            )
        if session.user.casefold() != trusted_identity.login.casefold():
            store.delete_session(session.token_hash)
            raise AdminAuthError(
                status_code=401,
                message="Admin session identity no longer matches the trusted device login.",
            )
        expected_binding = build_admin_session_binding(
            settings,
            user=trusted_identity.login,
            roles=approved_roles,
            device_id=session.device_id,
            tailscale_login=enrollment.tailscale_login,
            browser_public_key=enrollment.browser_public_key,
            approved_role=enrollment.approved_role,
        )
        store.touch_enrollment(
            device_id=session.device_id,
            last_seen_at=datetime.now(UTC).isoformat(),
        )
    else:
        expected_binding = build_admin_session_binding(
            settings,
            user=settings.admin_bootstrap_user or "",
            roles=tuple(sorted(settings.admin_bootstrap_role_set)),
            device_id=None,
        )
        if session.user != (settings.admin_bootstrap_user or ""):
            store.delete_session(session.token_hash)
            raise AdminAuthError(
                status_code=401,
                message="Admin session identity is stale. Sign in again.",
            )
        if session.roles != tuple(sorted(settings.admin_bootstrap_role_set)):
            store.delete_session(session.token_hash)
            raise AdminAuthError(
                status_code=401,
                message="Admin session roles are stale. Sign in again.",
            )
    if session.auth_binding != expected_binding:
        store.delete_session(session.token_hash)
        raise AdminAuthError(
            status_code=401,
            message="Admin session has been rotated. Sign in again.",
        )
    principal = session.to_principal()
    if not principal.has_any_role(settings.admin_allowed_role_set):
        raise AdminAuthError(
            status_code=403,
            message="Admin role is not allowed for the control plane.",
        )
    request.state.admin_session = session
    return principal


def _authenticate_admin_headers(request: Request, settings: Settings) -> AdminPrincipal:
    proxy_secret = request.headers.get(settings.admin_proxy_secret_header)
    if proxy_secret != settings.admin_proxy_secret:
        raise AdminAuthError(
            status_code=401,
            message="Trusted admin gateway secret is required for the control plane.",
        )

    user = request.headers.get(settings.admin_user_header)
    if user is None or not user.strip():
        raise AdminAuthError(
            status_code=401,
            message="Trusted admin identity header is required for the control plane.",
        )

    roles_header = request.headers.get(settings.admin_roles_header, "")
    roles = tuple(
        sorted(
            {
                role.strip().lower()
                for role in re.split(r"[\s,]+", roles_header)
                if role.strip()
            }
        )
    )
    if not roles:
        raise AdminAuthError(
            status_code=403,
            message="Admin role header is required for the control plane.",
        )
    if not set(roles).intersection(settings.admin_allowed_role_set):
        raise AdminAuthError(
            status_code=403,
            message="Admin role is not allowed for the control plane.",
        )
    return AdminPrincipal(user=user.strip(), roles=roles)


def _decode_urlsafe_b64(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(value + padding)


def _decode_identity_header(value: str | None) -> str:
    if value is None:
        return ""
    parts = []
    for chunk, encoding in decode_header(value):
        if isinstance(chunk, bytes):
            parts.append(chunk.decode(encoding or "utf-8", errors="replace"))
        else:
            parts.append(chunk)
    return "".join(parts).strip()


def build_admin_session_binding(
    settings: Settings,
    *,
    user: str,
    roles: tuple[str, ...],
    device_id: str | None,
    tailscale_login: str | None = None,
    browser_public_key: str | None = None,
    approved_role: str | None = None,
) -> str:
    access_mode = (
        "tailscale-serve"
        if settings.admin_access_mode == "tailscale-serve"
        else "loopback"
    )
    payload = {
        "access_mode": access_mode,
        "bootstrap_password_hash": settings.admin_bootstrap_password_hash or "",
        "bootstrap_user": settings.admin_bootstrap_user or "",
        "browser_public_key": browser_public_key or "",
        "device_id": device_id or "",
        "approved_role": approved_role or "",
        "roles": list(roles),
        "tailscale_login": tailscale_login or "",
        "user": user,
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _tailscale_whois_login(client_ip: str, settings: Settings) -> str:
    socket_path = Path(settings.admin_tailscale_socket_path)
    if not socket_path.exists():
        raise AdminAuthError(
            status_code=503,
            message="Tailscale LocalAPI socket is unavailable for trusted proxy verification.",
        )

    transport = httpx.HTTPTransport(uds=str(socket_path))
    with httpx.Client(
        transport=transport,
        base_url="http://local-tailscaled.sock",
        timeout=5.0,
        follow_redirects=False,
    ) as client:
        try:
            response = client.get("/localapi/v0/whois", params={"addr": client_ip})
        except httpx.HTTPError as error:
            raise AdminAuthError(
                status_code=503,
                message=(
                    "Trusted Tailscale client identity could not be verified because "
                    "the LocalAPI lookup failed."
                ),
            ) from error

    if response.status_code != 200:
        raise AdminAuthError(
            status_code=401,
            message="Trusted Tailscale client identity could not be verified.",
        )
    try:
        payload = response.json()
    except json.JSONDecodeError as error:
        raise AdminAuthError(
            status_code=401,
            message="Trusted Tailscale client identity returned an invalid whois payload.",
        ) from error

    login = _decode_identity_header(
        str((payload.get("UserProfile") or {}).get("LoginName", "")).strip()
    )
    if not login:
        raise AdminAuthError(
            status_code=401,
            message="Trusted Tailscale client identity did not include a login name.",
        )
    return login


def build_login_rate_limit_key(client_ip: str | None, username: str) -> str:
    normalized_ip = (client_ip or "unknown").strip() or "unknown"
    normalized_user = username.strip().casefold() or "anonymous"
    return f"{normalized_ip}|{normalized_user}"


def _request_origin(request: Request, settings: Settings) -> str:
    trusted_identity = getattr(request.state, "admin_trusted_proxy_identity", None)
    if isinstance(trusted_identity, AdminTrustedProxyIdentity) and (
        settings.admin_access_mode == "tailscale-serve"
    ):
        return trusted_identity.external_origin
    host = request.headers.get("host", request.url.netloc)
    scheme = request.url.scheme or "http"
    return f"{scheme}://{host}".rstrip("/")


def _origin_from_url(url: str) -> str | None:
    parsed = urlparse(url)
    if not parsed.scheme or not parsed.netloc:
        return None
    return f"{parsed.scheme}://{parsed.netloc}".rstrip("/")


def _is_loopback_address(value: str) -> bool:
    if not value:
        return False
    try:
        return ipaddress.ip_address(value).is_loopback
    except ValueError:
        return value.strip().lower() == "localhost"
