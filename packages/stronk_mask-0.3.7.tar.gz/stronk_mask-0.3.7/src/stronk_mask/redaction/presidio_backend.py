from __future__ import annotations

import re
from dataclasses import dataclass
from functools import lru_cache
from typing import Any

from .models import DetectorType, SpanMatch

PRESIDIO_ENTITY_MAP: dict[str, DetectorType] = {
    "PERSON": DetectorType.PERSON_NAME,
    "PER": DetectorType.PERSON_NAME,
    "ORG": DetectorType.ORGANIZATION,
    "ORGANIZATION": DetectorType.ORGANIZATION,
}
PATH_LIKE_RE = re.compile(r"(?:(?:~|/)[^\s]+|[A-Za-z]:\\[^\s]+)")


@dataclass(frozen=True)
class PresidioBackendConfig:
    languages: tuple[str, ...]
    english_model: str
    chinese_model: str
    score_threshold: float


class PresidioDetector:
    def __init__(self, config: PresidioBackendConfig) -> None:
        self._config = config

    def detect(self, text: str) -> list[SpanMatch]:
        if not text.strip():
            return []
        backend = _load_backend(self._config)
        excluded_spans = _excluded_spans(text)
        matches: list[SpanMatch] = []
        seen: set[tuple[int, int, DetectorType]] = set()
        for language in _languages_for_text(text, self._config.languages):
            for result in backend.analyze(text=text, language=language):
                detector = PRESIDIO_ENTITY_MAP.get(result.entity_type)
                if detector is None:
                    continue
                start = int(result.start)
                end = int(result.end)
                if start < 0 or end <= start or end > len(text):
                    continue
                if _overlaps_any(start, end, excluded_spans):
                    continue
                key = (start, end, detector)
                if key in seen:
                    continue
                seen.add(key)
                matches.append(
                    SpanMatch(
                        detector=detector,
                        start=start,
                        end=end,
                        value=text[start:end],
                        source="presidio",
                    )
                )
        return matches


def _languages_for_text(text: str, supported_languages: tuple[str, ...]) -> tuple[str, ...]:
    languages: list[str] = []
    has_cjk = any("\u4e00" <= char <= "\u9fff" for char in text)
    has_latin = any(("A" <= char <= "Z") or ("a" <= char <= "z") for char in text)
    if "zh" in supported_languages and has_cjk:
        languages.append("zh")
    if "en" in supported_languages and has_latin:
        languages.append("en")
    if not languages:
        languages.extend(language for language in supported_languages if language in {"en", "zh"})
    return tuple(dict.fromkeys(languages))


def _excluded_spans(text: str) -> tuple[tuple[int, int], ...]:
    return tuple((match.start(), match.end()) for match in PATH_LIKE_RE.finditer(text))


def _overlaps_any(start: int, end: int, spans: tuple[tuple[int, int], ...]) -> bool:
    for span_start, span_end in spans:
        if start < span_end and end > span_start:
            return True
    return False


@lru_cache(maxsize=4)
def _load_backend(config: PresidioBackendConfig) -> Any:
    try:
        from presidio_analyzer import AnalyzerEngine
        from presidio_analyzer.nlp_engine import NlpEngineProvider
    except ModuleNotFoundError as error:
        raise RuntimeError(
            "Presidio support is enabled but presidio-analyzer is not installed."
        ) from error

    models: list[dict[str, str]] = []
    if "en" in config.languages:
        models.append({"lang_code": "en", "model_name": config.english_model})
    if "zh" in config.languages:
        models.append({"lang_code": "zh", "model_name": config.chinese_model})

    provider = NlpEngineProvider(
        nlp_configuration={
            "nlp_engine_name": "spacy",
            "models": models,
        }
    )
    nlp_engine = provider.create_engine()
    return AnalyzerEngine(
        nlp_engine=nlp_engine,
        supported_languages=list(config.languages),
        default_score_threshold=config.score_threshold,
    )
