from __future__ import annotations

import json
import re
from collections.abc import Sequence

from stronk_mask.config import Settings
from stronk_mask.policy.engine import PolicyEngine

from .detectors import Detector, build_detectors, collect_matches
from .models import (
    DETECTOR_PRIORITY,
    DetectionDecision,
    JSONValue,
    PlaceholderVault,
    PolicyAction,
    RedactionResult,
    SpanMatch,
)

JSON_STRING_KEYS = {"arguments", "input"}
REHYDRATE_STRING_KEYS = {"content", "delta", "text"}
SKIP_REDACTION_TOP_LEVEL_KEYS = {"tools"}
SKIP_MESSAGE_ROLES = {"developer", "system"}
SKIP_REDACTION_IDENTIFIER_KEYS = {"id", "previous_response_id"}
PATH_LIKE_RE = re.compile(r"(?:(?:~|/)[^\s]+|[A-Za-z]:\\[^\s]+)")


class RedactionEngine:
    def __init__(
        self,
        policy: PolicyEngine,
        detectors: Sequence[Detector] | None = None,
        settings: Settings | None = None,
    ) -> None:
        self.policy = policy
        self.detectors = tuple(detectors or build_detectors(settings))

    def redact_payload(self, payload: JSONValue) -> RedactionResult:
        occupied_text = json.dumps(payload, ensure_ascii=False, sort_keys=True)
        vault = PlaceholderVault(occupied_text=occupied_text)
        decisions: list[DetectionDecision] = []
        transformed = self._redact_value(payload, "", vault, decisions)
        return RedactionResult(payload=transformed, decisions=tuple(decisions), vault=vault)

    def rehydrate_payload(self, payload: JSONValue, vault: PlaceholderVault) -> JSONValue:
        return self._rehydrate_value(payload, "", vault)

    def redact_text(self, text: str, path: str = "") -> RedactionResult:
        vault = PlaceholderVault(occupied_text=text)
        decisions: list[DetectionDecision] = []
        transformed = self._redact_string(text, path, vault, decisions)
        return RedactionResult(payload=transformed, decisions=tuple(decisions), vault=vault)

    def _redact_value(
        self,
        value: JSONValue,
        path: str,
        vault: PlaceholderVault,
        decisions: list[DetectionDecision],
    ) -> JSONValue:
        if _should_skip_redaction_value(path, value):
            return value
        if isinstance(value, dict):
            output: dict[str, JSONValue] = {}
            for key, item in value.items():
                output[key] = self._redact_value(item, _join_pointer(path, key), vault, decisions)
            return output
        if isinstance(value, list):
            return [
                self._redact_value(item, _join_pointer(path, str(index)), vault, decisions)
                for index, item in enumerate(value)
            ]
        if isinstance(value, str):
            if _should_parse_embedded_json(path, value):
                nested = _try_parse_json_container(value)
                if nested is not None:
                    transformed_nested = self._redact_value(
                        path=path,
                        value=nested,
                        vault=vault,
                        decisions=decisions,
                    )
                    return json.dumps(transformed_nested, ensure_ascii=False, separators=(",", ":"))
            return self._redact_string(value, path, vault, decisions)
        return value

    def _rehydrate_value(
        self,
        value: JSONValue,
        path: str,
        vault: PlaceholderVault,
    ) -> JSONValue:
        if isinstance(value, dict):
            return {
                key: self._rehydrate_value(item, _join_pointer(path, key), vault)
                for key, item in value.items()
            }
        if isinstance(value, list):
            return [
                self._rehydrate_value(item, _join_pointer(path, str(index)), vault)
                for index, item in enumerate(value)
            ]
        if isinstance(value, str):
            if _should_rehydrate_string(path):
                return vault.rehydrate_text(value)
            return value
        return value

    def _redact_string(
        self,
        text: str,
        path: str,
        vault: PlaceholderVault,
        decisions: list[DetectionDecision],
    ) -> str:
        excluded_spans = _excluded_spans(text)
        matches = _filter_overlaps(
            [
                match
                for match in collect_matches(text, self.detectors)
                if not _overlaps_any(match.start, match.end, excluded_spans)
            ]
        )
        if not matches:
            return text

        parts: list[str] = []
        cursor = 0
        for match in matches:
            parts.append(text[cursor:match.start])
            action = self.policy.decide(match.detector, path)
            placeholder: str | None = None
            if action is not PolicyAction.ALLOW:
                placeholder = vault.issue_placeholder(match.detector, match.value)
                parts.append(placeholder)
            else:
                parts.append(match.value)
            decisions.append(
                DetectionDecision(
                    detector=match.detector,
                    action=action,
                    path=path or "/",
                    placeholder=placeholder,
                    source=match.source,
                )
            )
            cursor = match.end
        parts.append(text[cursor:])
        return "".join(parts)


def _filter_overlaps(matches: list[SpanMatch]) -> list[SpanMatch]:
    ordered = sorted(
        matches,
        key=lambda item: (
            item.start,
            -(item.end - item.start),
            -DETECTOR_PRIORITY[item.detector],
        ),
    )
    resolved: list[SpanMatch] = []
    cursor = -1
    for match in ordered:
        if match.start < cursor:
            continue
        resolved.append(match)
        cursor = match.end
    return resolved


def _excluded_spans(text: str) -> tuple[tuple[int, int], ...]:
    return tuple((match.start(), match.end()) for match in PATH_LIKE_RE.finditer(text))


def _overlaps_any(start: int, end: int, spans: tuple[tuple[int, int], ...]) -> bool:
    for span_start, span_end in spans:
        if start < span_end and end > span_start:
            return True
    return False


def _should_parse_embedded_json(path: str, text: str) -> bool:
    if not text:
        return False
    if path.rsplit("/", maxsplit=1)[-1] not in JSON_STRING_KEYS:
        return False
    return text.lstrip().startswith(("{", "[")) and text.rstrip().endswith(("}", "]"))


def _should_rehydrate_string(path: str) -> bool:
    if not path:
        return True
    segments = [segment for segment in path.split("/") if segment]
    if not segments:
        return True
    if any(segment in {"arguments", "id", "metadata", "name", "url"} for segment in segments):
        return False
    return segments[-1] in REHYDRATE_STRING_KEYS


def _should_skip_redaction_value(path: str, value: JSONValue) -> bool:
    if not path:
        return False
    segments = [segment for segment in path.split("/") if segment]
    if not segments:
        return False
    if segments[-1] in SKIP_REDACTION_IDENTIFIER_KEYS:
        return True
    return False


def _try_parse_json_container(text: str) -> JSONValue | None:
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return None
    if isinstance(parsed, (dict, list)):
        return parsed
    return None


def _join_pointer(base: str, segment: str) -> str:
    escaped = segment.replace("~", "~0").replace("/", "~1")
    return f"/{escaped}" if not base else f"{base}/{escaped}"


def redact_text(text: str, policy: PolicyEngine) -> RedactionResult:
    return RedactionEngine(policy=policy).redact_text(text)


def count_rehydratable_placeholders(payload: JSONValue, vault: PlaceholderVault) -> int:
    return _count_rehydratable_value(payload, "", vault)


def _count_rehydratable_value(value: JSONValue, path: str, vault: PlaceholderVault) -> int:
    if isinstance(value, dict):
        return sum(
            _count_rehydratable_value(item, _join_pointer(path, key), vault)
            for key, item in value.items()
        )
    if isinstance(value, list):
        return sum(
            _count_rehydratable_value(item, _join_pointer(path, str(index)), vault)
            for index, item in enumerate(value)
        )
    if isinstance(value, str) and _should_rehydrate_string(path):
        return vault.count_occurrences(value)
    return 0
