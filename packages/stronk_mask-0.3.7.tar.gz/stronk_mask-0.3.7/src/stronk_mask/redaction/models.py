from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import StrEnum
from typing import TypeAlias

JSONPrimitive: TypeAlias = str | int | float | bool | None
JSONValue: TypeAlias = JSONPrimitive | list["JSONValue"] | dict[str, "JSONValue"]
PLACEHOLDER_SENTINEL = "[["
PLACEHOLDER_SUFFIX = "]]"
PLACEHOLDER_LITERAL_PATTERN = re.compile(r"\[\[([A-Z_]+)_(\d+)\]\]")


class DetectorType(StrEnum):
    EMAIL = "email"
    PHONE = "phone"
    BUSINESS_ID = "business_id"
    PERSON_NAME = "person_name"
    ORGANIZATION = "organization"
    ADDRESS = "address"
    API_KEY = "api_key"
    BEARER_TOKEN = "bearer_token"
    JWT = "jwt"


class PolicyAction(StrEnum):
    ALLOW = "allow"
    MASK = "mask"
    BLOCK = "block"
    ROUTE_LOCAL = "route_local"


DETECTOR_PRIORITY: dict[DetectorType, int] = {
    DetectorType.API_KEY: 100,
    DetectorType.BEARER_TOKEN: 95,
    DetectorType.JWT: 90,
    DetectorType.EMAIL: 80,
    DetectorType.BUSINESS_ID: 75,
    DetectorType.PHONE: 70,
    DetectorType.ADDRESS: 60,
    DetectorType.ORGANIZATION: 50,
    DetectorType.PERSON_NAME: 40,
}

DETECTOR_PLACEHOLDER_LABEL: dict[DetectorType, str] = {
    DetectorType.EMAIL: "EMAIL",
    DetectorType.PHONE: "PHONE",
    DetectorType.BUSINESS_ID: "BUSINESS_ID",
    DetectorType.PERSON_NAME: "PERSON",
    DetectorType.ORGANIZATION: "ORG",
    DetectorType.ADDRESS: "ADDRESS",
    DetectorType.API_KEY: "API_KEY",
    DetectorType.BEARER_TOKEN: "BEARER_TOKEN",
    DetectorType.JWT: "JWT",
}


@dataclass(frozen=True)
class SpanMatch:
    detector: DetectorType
    start: int
    end: int
    value: str
    source: str = "deterministic"


@dataclass(frozen=True)
class DetectionDecision:
    detector: DetectorType
    action: PolicyAction
    path: str
    placeholder: str | None = None
    source: str = "deterministic"


@dataclass(frozen=True)
class PlaceholderRecord:
    placeholder: str
    detector: DetectorType
    original: str


@dataclass
class PlaceholderVault:
    occupied_text: str = ""
    _by_key: dict[tuple[DetectorType, str], str] = field(default_factory=dict, init=False)
    _records: dict[str, PlaceholderRecord] = field(default_factory=dict, init=False)
    _next_index: dict[DetectorType, int] = field(default_factory=dict, init=False)
    _reserved_indices: dict[str, set[int]] = field(default_factory=dict, init=False)

    def __post_init__(self) -> None:
        for label, raw_index in PLACEHOLDER_LITERAL_PATTERN.findall(self.occupied_text):
            self._reserved_indices.setdefault(label, set()).add(int(raw_index))

    def issue_placeholder(self, detector: DetectorType, original: str) -> str:
        key = (detector, original)
        existing = self._by_key.get(key)
        if existing is not None:
            return existing

        next_index = self._next_index.get(detector, 1)
        label = DETECTOR_PLACEHOLDER_LABEL[detector]
        reserved_indices = self._reserved_indices.get(label, set())
        while True:
            placeholder = f"{PLACEHOLDER_SENTINEL}{label}_{next_index}{PLACEHOLDER_SUFFIX}"
            if placeholder not in self._records and next_index not in reserved_indices:
                break
            next_index += 1

        self._by_key[key] = placeholder
        self._next_index[detector] = next_index + 1
        self._records[placeholder] = PlaceholderRecord(
            placeholder=placeholder,
            detector=detector,
            original=original,
        )
        return placeholder

    def rehydrate_text(self, text: str) -> str:
        result = text
        for placeholder, record in sorted(
            self._records.items(),
            key=lambda item: len(item[0]),
            reverse=True,
        ):
            result = result.replace(placeholder, record.original)
        return result

    def placeholder_prefixes(self) -> set[str]:
        prefixes: set[str] = set()
        for placeholder in self._records:
            for index in range(1, len(placeholder)):
                prefixes.add(placeholder[:index])
        return prefixes

    def count_occurrences(self, text: str) -> int:
        return sum(text.count(placeholder) for placeholder in self._records)

    @property
    def records(self) -> tuple[PlaceholderRecord, ...]:
        return tuple(self._records.values())


@dataclass
class RedactionResult:
    payload: JSONValue
    decisions: tuple[DetectionDecision, ...]
    vault: PlaceholderVault

    @property
    def blocked(self) -> tuple[DetectionDecision, ...]:
        return tuple(item for item in self.decisions if item.action is PolicyAction.BLOCK)

    @property
    def route_local(self) -> tuple[DetectionDecision, ...]:
        return tuple(item for item in self.decisions if item.action is PolicyAction.ROUTE_LOCAL)

    @property
    def masked(self) -> tuple[DetectionDecision, ...]:
        return tuple(item for item in self.decisions if item.action is PolicyAction.MASK)
