from __future__ import annotations

from collections.abc import AsyncIterator, Callable
from contextlib import AbstractAsyncContextManager, asynccontextmanager
from dataclasses import dataclass
from typing import Any

import httpx
from fastapi import FastAPI, Request, WebSocket
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel

from stronk_mask.admin import (
    AdminAuthError,
    authenticate_admin_request,
    build_auth_error_response,
    require_admin_roles,
)
from stronk_mask.config import Settings, get_settings
from stronk_mask.providers import ANTHROPIC_MESSAGES, OPENAI_CHAT_COMPLETIONS, OPENAI_RESPONSES
from stronk_mask.proxy.service import ProxyService


class MaskRequest(BaseModel):
    payload: dict[str, Any]


UNSAFE_DEBUG_GATEWAY_HEADER = "X-Stronk-Unsafe-Debug-Gateway"


@dataclass(frozen=True)
class ProxyRuntimeApps:
    public_app: FastAPI
    debug_app: FastAPI
    proxy_service: ProxyService


def create_app(
    settings: Settings | None = None,
    upstream_transport: httpx.AsyncBaseTransport | None = None,
) -> FastAPI:
    return create_public_app(settings=settings, upstream_transport=upstream_transport)


def create_public_app(
    settings: Settings | None = None,
    upstream_transport: httpx.AsyncBaseTransport | None = None,
) -> FastAPI:
    app_settings = settings or get_settings()
    proxy_service = ProxyService(
        settings=app_settings,
        transport=upstream_transport,
    )
    return _build_public_app(
        app_settings,
        proxy_service,
        include_lifespan=True,
        include_debug_routes=False,
    )


def create_full_app(
    settings: Settings | None = None,
    upstream_transport: httpx.AsyncBaseTransport | None = None,
) -> FastAPI:
    app_settings = settings or get_settings()
    proxy_service = ProxyService(
        settings=app_settings,
        transport=upstream_transport,
    )
    return _build_public_app(
        app_settings,
        proxy_service,
        include_lifespan=True,
        include_debug_routes=True,
    )


def create_debug_bridge_app(
    settings: Settings | None = None,
    upstream_transport: httpx.AsyncBaseTransport | None = None,
) -> FastAPI:
    app_settings = settings or get_settings()
    proxy_service = ProxyService(
        settings=app_settings,
        transport=upstream_transport,
    )
    return _build_debug_bridge_app(
        app_settings,
        proxy_service,
        include_lifespan=True,
    )


def build_runtime_apps(
    settings: Settings | None = None,
    upstream_transport: httpx.AsyncBaseTransport | None = None,
) -> ProxyRuntimeApps:
    app_settings = settings or get_settings()
    proxy_service = ProxyService(
        settings=app_settings,
        transport=upstream_transport,
    )
    return ProxyRuntimeApps(
        public_app=_build_public_app(
            app_settings,
            proxy_service,
            include_lifespan=False,
            include_debug_routes=False,
        ),
        debug_app=_build_debug_bridge_app(
            app_settings,
            proxy_service,
            include_lifespan=False,
        ),
        proxy_service=proxy_service,
    )


def _build_public_app(
    app_settings: Settings,
    proxy_service: ProxyService,
    *,
    include_lifespan: bool,
    include_debug_routes: bool,
) -> FastAPI:
    app = FastAPI(
        title=app_settings.app_name,
        lifespan=_proxy_lifespan(proxy_service) if include_lifespan else None,
    )

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok", "app": app_settings.app_name, "env": app_settings.app_env}

    @app.get("/v1/models")
    async def openai_models(request: Request) -> Response:
        return await proxy_service.handle_openai_models(request)

    @app.post(OPENAI_CHAT_COMPLETIONS.public_path)
    async def openai_chat_completions(request: Request) -> object:
        return await proxy_service.handle(request, OPENAI_CHAT_COMPLETIONS)

    @app.post(OPENAI_RESPONSES.public_path)
    async def openai_responses(request: Request) -> object:
        return await proxy_service.handle(request, OPENAI_RESPONSES)

    @app.websocket(OPENAI_RESPONSES.public_path)
    async def openai_responses_websocket(websocket: WebSocket) -> None:
        await proxy_service.handle_responses_websocket(websocket, OPENAI_RESPONSES)

    @app.post(ANTHROPIC_MESSAGES.public_path)
    async def anthropic_messages(request: Request) -> object:
        return await proxy_service.handle(request, ANTHROPIC_MESSAGES)

    if app_settings.enable_debug_mask_endpoint:
        @app.post("/v1/mask")
        async def mask(request: MaskRequest) -> object:
            return proxy_service.build_debug_response(request.payload)

    if include_debug_routes:
        _attach_debug_routes(app, app_settings, proxy_service)

    return app


def _build_debug_bridge_app(
    app_settings: Settings,
    proxy_service: ProxyService,
    *,
    include_lifespan: bool,
) -> FastAPI:
    app = FastAPI(
        title=f"{app_settings.app_name} debug bridge",
        lifespan=_proxy_lifespan(proxy_service) if include_lifespan else None,
    )

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {
            "status": "ok",
            "app": app_settings.app_name,
            "plane": "debug-bridge",
        }

    _attach_debug_routes(app, app_settings, proxy_service)
    return app


def _attach_debug_routes(
    app: FastAPI,
    app_settings: Settings,
    proxy_service: ProxyService,
) -> None:
    def no_store(response: Response) -> Response:
        response.headers["Cache-Control"] = "no-store, private, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        return response

    def finalize_debug_response(
        request: Request,
        *,
        actor: str,
        roles: tuple[str, ...],
        response: Response,
    ) -> Response:
        proxy_service.record_admin_access(
            actor=actor,
            roles=roles,
            request=request,
            status_code=response.status_code,
        )
        return no_store(response)

    def require_debug_admin(request: Request) -> tuple[str, tuple[str, ...], Response | None]:
        actor = request.headers.get(app_settings.admin_user_header, "anonymous")
        if not app_settings.enable_unsafe_debug_view:
            return actor, tuple(), JSONResponse(
                status_code=404,
                content={"error": {"message": "Content trace monitoring is disabled."}},
            )
        gateway_secret = request.headers.get(UNSAFE_DEBUG_GATEWAY_HEADER)
        if gateway_secret != app_settings.unsafe_debug_gateway_secret:
            return actor, tuple(), JSONResponse(
                status_code=404,
                content={"error": {"message": "Not found."}},
            )
        try:
            request.state.admin_principal = authenticate_admin_request(
                request,
                app_settings,
                store=proxy_service.audit_store,
            )
            require_admin_roles(
                request.state.admin_principal,
                app_settings.admin_trace_allowed_role_set,
                message="Authenticated admin role does not permit content trace access.",
            )
        except AdminAuthError as error:
            return actor, tuple(), build_auth_error_response(
                request, error.status_code, error.message
            )
        principal = request.state.admin_principal
        return principal.user, principal.roles, None

    @app.get("/api/debug/traces")
    async def debug_traces(request: Request, limit: int = 20) -> Response:
        actor, roles, auth_response = require_debug_admin(request)
        if auth_response is not None:
            return finalize_debug_response(
                request,
                actor=actor,
                roles=roles,
                response=auth_response,
            )
        items = [
            {
                "request_id": trace.request_id,
                "created_at": trace.created_at,
                "provider": trace.provider,
                "endpoint": trace.endpoint,
                "model": trace.model,
                "stream": trace.stream,
                "outcome": trace.outcome,
                "status_code": trace.status_code,
            }
            for trace in proxy_service.list_unsafe_debug_traces(limit=limit)
        ]
        return finalize_debug_response(
            request,
            actor=actor,
            roles=roles,
            response=JSONResponse(content={"items": items}),
        )

    @app.get("/api/debug/traces/{request_id}")
    async def debug_trace_detail(request: Request, request_id: str) -> Response:
        actor, roles, auth_response = require_debug_admin(request)
        if auth_response is not None:
            return finalize_debug_response(
                request,
                actor=actor,
                roles=roles,
                response=auth_response,
            )
        trace = proxy_service.get_unsafe_debug_trace(request_id)
        if trace is None:
            return finalize_debug_response(
                request,
                actor=actor,
                roles=roles,
                response=JSONResponse(
                    status_code=404,
                    content={"error": {"message": "Unsafe debug trace not found."}},
                ),
            )
        return finalize_debug_response(
            request,
            actor=actor,
            roles=roles,
            response=JSONResponse(content=trace.to_payload()),
        )


def _proxy_lifespan(
    proxy_service: ProxyService,
) -> Callable[[FastAPI], AbstractAsyncContextManager[None, bool | None]]:
    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        await proxy_service.startup()
        try:
            yield
        finally:
            await proxy_service.shutdown()

    return lifespan
