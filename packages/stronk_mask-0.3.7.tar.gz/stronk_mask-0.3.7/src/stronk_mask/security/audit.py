from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import cast

from stronk_mask.providers import ProviderSpec
from stronk_mask.redaction.detectors import RegexDetector, collect_matches, default_detectors
from stronk_mask.redaction.models import DetectorType, JSONValue, PolicyAction, RedactionResult

SAFE_PATH_SEGMENTS = frozenset(
    {
        "messages",
        "message",
        "content",
        "input",
        "text",
        "model",
        "metadata",
        "function",
        "arguments",
        "tool_calls",
        "output",
        "type",
        "delta",
        "role",
        "id",
    }
)
SAFE_MODEL_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,119}$")
AUDIT_SECRET_DETECTORS = tuple(
    detector
    for detector in default_detectors()
    if isinstance(detector, RegexDetector)
    and detector.detector
    in {
        DetectorType.API_KEY,
        DetectorType.BEARER_TOKEN,
        DetectorType.JWT,
        DetectorType.EMAIL,
        DetectorType.PHONE,
    }
)


@dataclass(frozen=True)
class AuditEventRecord:
    request_id: str
    created_at: str
    provider: str
    endpoint: str
    model: str | None
    stream: bool
    outcome: str
    status_code: int
    latency_ms: int
    detection_count: int
    detection_types: dict[str, int]
    actions: dict[str, int]
    placeholder_count: int
    rehydration_count: int
    masked_paths: tuple[str, ...]
    blocked: bool
    route_local: bool

    def to_payload(self) -> dict[str, object]:
        return {
            "request_id": self.request_id,
            "created_at": self.created_at,
            "provider": self.provider,
            "endpoint": self.endpoint,
            "model": self.model,
            "stream": self.stream,
            "outcome": self.outcome,
            "status_code": self.status_code,
            "latency_ms": self.latency_ms,
            "detection_count": self.detection_count,
            "detection_types": self.detection_types,
            "actions": self.actions,
            "placeholder_count": self.placeholder_count,
            "rehydration_count": self.rehydration_count,
            "masked_paths": list(self.masked_paths),
            "blocked": self.blocked,
            "route_local": self.route_local,
        }


def build_audit_summary(result: RedactionResult | None = None) -> dict[str, object]:
    detection_types: dict[str, int] = {}
    actions: dict[str, int] = {}
    decisions = result.decisions if result is not None else ()
    vault_records = result.vault.records if result is not None else ()

    for decision in decisions:
        detection_key = decision.detector.value
        action_key = decision.action.value
        detection_types[detection_key] = detection_types.get(detection_key, 0) + 1
        actions[action_key] = actions.get(action_key, 0) + 1

    return {
        "masked": any(item.action is PolicyAction.MASK for item in decisions),
        "blocked": any(item.action is PolicyAction.BLOCK for item in decisions),
        "route_local": any(item.action is PolicyAction.ROUTE_LOCAL for item in decisions),
        "detection_count": len(decisions),
        "detection_types": detection_types,
        "actions": actions,
        "placeholder_count": len(vault_records),
    }


def build_audit_event(
    request_id: str,
    spec: ProviderSpec,
    payload: JSONValue | None,
    result: RedactionResult | None,
    *,
    status_code: int,
    stream: bool,
    latency_ms: int,
    rehydration_count: int = 0,
    outcome: str | None = None,
    occurred_at: datetime | None = None,
) -> AuditEventRecord:
    summary = build_audit_summary(result)
    created_at = (occurred_at or datetime.now(UTC)).isoformat()
    masked_paths = (
        tuple(sorted({_sanitize_pointer(decision.path) for decision in result.decisions}))
        if result is not None
        else tuple()
    )
    return AuditEventRecord(
        request_id=request_id,
        created_at=created_at,
        provider=spec.name,
        endpoint=spec.public_path,
        model=_extract_model(payload),
        stream=stream,
        outcome=outcome or _resolve_outcome(result, status_code),
        status_code=status_code,
        latency_ms=latency_ms,
        detection_count=cast(int, summary["detection_count"]),
        detection_types=cast(dict[str, int], summary["detection_types"]),
        actions=cast(dict[str, int], summary["actions"]),
        placeholder_count=cast(int, summary["placeholder_count"]),
        rehydration_count=rehydration_count,
        masked_paths=masked_paths,
        blocked=bool(summary["blocked"]),
        route_local=bool(summary["route_local"]),
    )


def _extract_model(payload: JSONValue | None) -> str | None:
    if not isinstance(payload, dict):
        return None
    model = payload.get("model")
    if isinstance(model, str) and model:
        return _sanitize_model(model)
    return None


def _resolve_outcome(result: RedactionResult | None, status_code: int) -> str:
    if result is not None and result.blocked:
        return "blocked"
    if result is not None and result.route_local:
        return "route_local"
    if status_code >= 500:
        return "upstream_error"
    if status_code >= 400:
        return "upstream_rejection"
    if result is not None and result.masked:
        return "masked"
    return "forwarded"


def _sanitize_model(model: str) -> str:
    normalized = model.strip()
    if not normalized:
        return "<redacted-model>"
    if not SAFE_MODEL_PATTERN.fullmatch(normalized):
        return "<redacted-model>"
    if collect_matches(normalized, AUDIT_SECRET_DETECTORS):
        return "<redacted-model>"
    return normalized


def _sanitize_pointer(path: str) -> str:
    if path in {"", "/"}:
        return "/"
    sanitized_segments: list[str] = []
    for raw_segment in (segment for segment in path.split("/") if segment):
        segment = raw_segment.replace("~1", "/").replace("~0", "~")
        if segment.isdigit():
            sanitized_segments.append("#")
            continue
        sanitized_segments.append(segment if segment in SAFE_PATH_SEGMENTS else "{key}")
    return "/" + "/".join(sanitized_segments)
