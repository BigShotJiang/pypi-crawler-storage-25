# Privacy Proxy Hardening and Scalability v1

## Objective

Harden `stronk-mask` so its supported deployment mode is concurrency-safe, privacy-safe, and honest about scale limits.

This plan focuses on:

- closing upstream-visible privacy bypasses
- making `/openai/v1/responses` websocket behavior deterministic under the supported deployment mode
- reducing avoidable throughput and memory bottlenecks
- proving the new posture with explicit concurrency and load validation before making stronger claims

## Supported Deployment Contract

### V1 Contract

`stronk-mask` v1 websocket continuity is supported only for:

- single-process deployment
- multi-process deployment with sticky-session affinity for a given websocket turn

### Explicitly Unsupported In This Plan

- non-sticky multi-worker websocket continuity
- shared external turn-state storage
- generic websocket passthrough

If external shared turn-state is wanted later, it must land in a separate plan because it changes the current memory-only, process-local privacy and storage model.

## Scope

- OpenAI-compatible HTTP endpoints
- Anthropic-compatible HTTP endpoint
- OpenAI Responses websocket bridge
- privacy-boundary bypasses in upstream-visible request surfaces
- websocket safety limits and correctness rules
- throughput and memory hot paths
- concurrency, load, and abuse-resistance validation
- documentation of exact guarantees and unsupported modes

## Constraints

- preserve privacy-first defaults
- preserve caller-facing API shapes where possible
- do not weaken egress controls, policy behavior, or no-raw-data defaults
- do not make claims the tests do not prove
- keep the implementation incremental and testable

## Non-Goals

- Redis or any other external shared turn-state in this plan
- generic websocket or realtime passthrough
- unrelated product features or UI work
- multi-node control-plane architecture changes

## Privacy Contract For This Plan

V1 will expand the privacy contract for upstream-visible caller-controlled content.

### Required Action Per Surface

- `instructions`: mask
- `developer`: mask
- `system`: mask
- top-level `tools`: reject the request if sensitive content is detected in user-controlled tool descriptions, examples, or schema defaults
- `x-codex-turn-metadata`: strip before upstream forwarding
- `x-codex-turn-state`: do not forward the caller-supplied value upstream; validate it locally and replace any upstream-forwarded turn identifier with a bounded proxy-issued opaque token if upstream correlation is still required
- `x-request-id`: allow only if it matches a bounded opaque identifier shape; otherwise replace with a proxy-issued opaque request id
- `authorization`, `x-api-key`, `openai-*`, `anthropic-*`, and `x-responsesapi-include-timing-metrics`: preserve as transport/auth headers, not as privacy-scoped user content surfaces

### Remaining Exempt Identifiers

- payload `id`
- payload `previous_response_id`
- proxy-issued opaque transport identifiers that are explicitly bounded and normalized

No other caller-controlled upstream-visible surface is exempt in this plan.

## Benchmark And Validation Matrix

### Fixed Benchmark Harness

Use a repo-local benchmark path with:

- `pytest`-based async characterization tests for correctness and limit enforcement
- one repo-local load driver script at `python3 scripts/bench_proxy.py` for repeatable latency, error-rate, memory, and SQLite contention measurements against a real `uvicorn` process

### Environment Assumptions

- local single-process `uvicorn` for the supported websocket mode
- local stubbed upstream or controlled mock upstream behavior
- audit enabled for audit-contention measurements
- unsafe debug disabled for normal scale measurements unless a debug-specific case is under test

### Benchmark Matrix

| ID | Entrypoint | Scenario | Load Shape | Pass Thresholds |
| --- | --- | --- | --- | --- |
| `W1-http-chat` | `python3 scripts/bench_proxy.py --scenario http-chat` | non-stream OpenAI chat completions | `64` concurrent requests for `30s` with the standard 1 KiB mixed-language prompt fixture | error rate `0%`; p95 latency regression `<=10%`; zero leaks |
| `W2-http-responses` | `python3 scripts/bench_proxy.py --scenario http-responses` | non-stream OpenAI responses | `64` concurrent requests for `30s` with the standard 1 KiB prompt fixture | error rate `0%`; p95 latency regression `<=10%`; zero leaks |
| `W3-sse-stream` | `python3 scripts/bench_proxy.py --scenario sse-stream` | concurrent SSE streams | `32` concurrent streams for `30s` with controlled chunk cadence | error rate `0%`; p95 first-byte regression `<=10%`; bounded memory; zero leaks |
| `W4-ws-sequential` | `python3 scripts/bench_proxy.py --scenario ws-sequential` | valid websocket turn flow in supported mode | `16` concurrent websocket sessions, `5` turns per session | error rate `0%`; correct reconnect behavior; no stale-state rollback |
| `W5-ws-abuse` | `python3 scripts/bench_proxy.py --scenario ws-abuse` | oversize frames, invalid frames, blocked frames, same-turn collision attempts | `16` abusive sockets with deterministic scripted cases | all cases rejected before upstream as specified; connections closed on budget exhaustion; bounded session state |
| `W6-audit-contention` | `python3 scripts/bench_proxy.py --scenario audit-contention` | proxy writes plus admin reads with audit enabled | `64` proxy writers and `8` admin readers for `30s` | zero `database is locked`; zero write failures; p95 regression `<=10%` |
| `W7-memory-bound` | `python3 scripts/bench_proxy.py --scenario memory-bound` | long-stream and large-body capture limits | `8` long streams plus `8` large-body responses for `60s` | RSS stays within configured capture envelope; truncation markers appear as specified |

### Required Metrics

- throughput
- p95 latency
- error rate
- peak RSS or equivalent resident-memory metric
- SQLite lock failures and write failures

### Initial Pass Thresholds

- zero cross-request placeholder or plaintext leakage
- zero `database is locked` failures in `W6-audit-contention`
- same-turn collisions are rejected with one deterministic documented outcome
- oversize websocket frames are rejected before parse, redaction, session mutation, or upstream forwarding
- peak RSS remains bounded by configured capture limits on long-stream and large-response tests
- p95 latency regression must not exceed 10% versus the pre-change baseline for `W1-http-chat`, `W2-http-responses`, `W3-sse-stream`, and `W6-audit-contention` unless explicitly explained and accepted in logs
- error rate must remain at 0% for normal-path supported workloads in the local validation matrix

## Task Checklist

- [x] Phase 0: lock the exact supported deployment contract and privacy contract in code-facing terms
- [x] Phase 1: add failing characterization tests before behavior changes
  - [x] same-turn websocket collision
  - [x] mid-stream disconnect and reconnect
  - [x] oversize websocket frame rejection before parse/redaction/upstream
  - [x] privacy behavior for `instructions`, `developer`, `system`, `tools`, and forwarded caller headers
- [x] Phase 2: add new config and lifecycle primitives
  - [x] websocket frame-byte cap
  - [x] websocket idle, message, and consecutive-error budgets
  - [x] turn-state charset and length validation
  - [x] active-session cap and per-turn stored-state bounds
  - [x] bounded debug tail and bounded non-stream capture thresholds
  - [x] lifespan-managed shared `httpx.AsyncClient` with explicit connection limits
  - [x] benchmark harness configuration and baseline capture
- [x] Phase 3: close upstream-visible privacy bypasses
  - [x] mask `instructions`, `developer`, and `system`
  - [x] reject sensitive top-level `tools` surfaces instead of forwarding them upstream
  - [x] strip `x-codex-turn-metadata`
  - [x] normalize or replace `x-request-id` if it is not a bounded opaque id
  - [x] stop forwarding caller-supplied `x-codex-turn-state` upstream
  - [x] document any remaining out-of-scope surfaces explicitly
- [x] Phase 4: harden websocket safety boundaries
  - [x] reject oversize frames early
  - [x] enforce per-socket idle/message/error budgets
  - [x] reject malformed or abusive `x-codex-turn-state` values
  - [x] enforce bounded session-count with reject-on-limit semantics
- [x] Phase 5: harden websocket correctness
  - [x] reject concurrent same-turn ownership attempts instead of serializing them
  - [x] move to shadow-state/checkpointed mutation with commit only after successful terminal upstream completion
  - [x] ensure disconnect cleanup cannot roll back newer state
  - [x] document exact supported reconnect semantics for the chosen deployment mode
- [x] Phase 6: harden throughput and memory hot paths
  - [x] reuse one shared upstream client instead of per-request client construction
  - [x] move audit writes off the hot async request path
  - [x] batch or defer pruning work
  - [x] bound SSE and debug buffering with truncation markers
  - [x] cap materialized non-stream response-body capture
- [x] Phase 7: run concurrency, load, and abuse validation
  - [x] concurrent HTTP isolation
  - [x] concurrent SSE isolation
  - [x] same-turn websocket collision outcome
  - [x] reconnect behavior in supported mode
  - [x] long-stream memory bound
  - [x] SQLite contention envelope
- [x] Phase 8: update docs and deployment guidance
  - [x] exact supported websocket deployment modes
  - [x] exact unsupported deployment modes
  - [x] exact privacy scope for headers and tool schemas
  - [x] exact performance claims tied to the benchmark matrix

## Current Execution Status

- Checkpoint 3 cleared on `2026-03-28` after the websocket turn-ordering model moved to one outstanding receive task per connection, with terminal state committed before any post-send collision or disconnect handling.
- Checkpoint 4 cleared on `2026-03-28` after Phase 6 moved upstream requests onto one pooled client without cookie persistence, moved audit writes off the hot async path with retry-on-transient-flush-failure semantics, removed read-side prune writes, and bounded unsafe-debug capture for long streams and large bodies.
- Audit-backed admin views are intentionally eventually consistent while the in-process audit queue drains; the implementation now retries transient SQLite flush failures without dropping dequeued batches, and tests poll for visibility instead of assuming synchronous commit-at-response.
- Checkpoint 5 cleared on `2026-03-28` after `scripts/bench_proxy.py` gained the repo-local W1-W7 harness, baseline capture plumbing, and a stream-aware SSE token detector that removed the false-positive `W3-sse-stream` cross-request leak finding.
- Checkpoint 6 cleared on `2026-03-28` after the refreshed `W1` through `W7` artifacts, README deployment/privacy contract, and exec-plan status records all passed a final blocking `pro` `critic` review.
- The named benchmark rows `W1` through `W7` were refreshed on `2026-03-28` under the current code and written to `docs/exec-plans/active/privacy-proxy-hardening-and-scalability-v1/artifacts/benchmarks/`.
- `W1`, `W2`, `W3`, and `W6` remain blocked only because no historic pre-change latency baseline was captured; `post-change-baseline.json` exists as a same-harness capture artifact, not as a retroactive pre-change proof.
- `W4`, `W5`, and `W7` remain explicitly blocked by proof or plan-spec gaps rather than implementation failures:
  - `W4`: the black-box reconnect probe still does not deterministically prove rollback semantics even though targeted websocket tests do
  - `W5`: the benchmark proves rejection outcomes, but not internal pre-parse and pre-redaction ordering by itself
  - `W7`: the plan never encoded a numeric RSS envelope, so the row can only prove bounded capture and truncation behavior
- Public header neutralization beyond the current `x-codex-turn-state` compatibility surface remains follow-up scope, not part of this API-preserving v1 checkpoint.
- The execution checklist is complete; the remaining benchmark `blocked` verdicts are documented evidence limits, not unimplemented checkpoints.

## Validation Gates

- duplicate websocket turn collisions are deterministically rejected without stale-state rollback
- reconnect semantics are correct for single-process and sticky-session deployments
- non-sticky multi-worker websocket continuity is documented as unsupported in this plan
- no caller-controlled sensitive text leaks upstream through the finalized in-scope surfaces
- no cross-request placeholder/rehydration leakage occurs under concurrent HTTP and SSE workloads
- websocket abuse limits close the connection after the configured threshold and leave bounded state behind
- bounded debug and response-capture limits keep capture behavior bounded and emit truncation markers during long-stream and large-body tests; `W7` does not prove a numeric RSS envelope because the plan does not define one
- the benchmark matrix, thresholds, and measured results are recorded in the logs before any stronger scalability claim is made

## Risks

- widening masking to more upstream-visible surfaces may affect provider behavior and require careful field-by-field handling
- websocket correctness hardening can break current reconnect assumptions if the supported deployment contract is not enforced consistently
- async telemetry changes can trade durability semantics for latency; the plan must document the chosen tradeoff

## Follow-Up Questions

- after this plan lands, is a second plan for shared external turn-state worth the operational cost?
- should unsafe debug streaming be fully disabled above a threshold or always reduced to a bounded tail buffer?
- should the benchmark harness become CI-blocking, or remain a release gate run outside CI?
