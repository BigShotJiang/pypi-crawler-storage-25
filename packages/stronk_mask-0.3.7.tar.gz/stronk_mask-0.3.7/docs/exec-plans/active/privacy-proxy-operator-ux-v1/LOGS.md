# Privacy Proxy Operator UX v1

## 2026-03-27

- initialized ExecPlan scaffolding for this repo
- drafted the execution plan for setup-first operator UX work
- selected a two-plane architecture: proxy data plane plus separate admin/control plane
- selected a frontend direction: modern light/dark monitoring UI with restrained control-room styling
- implemented a separate `admin_app` FastAPI control plane with read-only sanitized monitoring APIs
- added SQLite-backed sanitized event and access-log storage with bounded retention
- wired proxy audit-event emission so admin views only see counts, statuses, normalized paths, and sanitized model metadata
- built the React/Vite admin UI with dual light/dark themes, animated event river, request inspector, and readiness rail
- updated Compose and Caddy so local deployment exposes the proxy and admin gateway separately while keeping the admin backend on an internal network
- hardened admin trust with a shared gateway secret in addition to trusted identity headers and role checks
- added regression tests for admin auth, upstream-userinfo scrubbing, sanitized audit fields, access-log pruning, and upstream rejection classification
- verified `ruff`, `mypy`, `pytest`, frontend production build, production npm audit, and Compose config rendering

### Checkpoint Record

- `checkpoint_id`: `C1`
- `checkpoint_title`: `Hybrid Presidio Precision Hardening + Live Codex Validation`
- `plan_version`: `privacy-proxy-operator-ux-v1`
- `acceptance_criteria`:
  - latest live PDF run keeps the local file path intact and does not mask path segments
  - latest live PDF run masks `EYYCHEEV GAMES INC.`, `佛山市川东磁电股份有限公司`, `YAN YI MIN`, `914406007375904397`, and `780304507` upstream
  - masking skips top-level `tools`, top-level `instructions`, and developer/system message objects in OpenAI Responses payloads
  - Presidio remains optional, bounded, and guarded against obvious path/schema false positives
  - `ruff`, `mypy`, and `pytest` pass
- `action_taken`:
  - added hybrid Presidio support with opt-in config and narrow `PERSON`/`ORG` entity mapping
  - strengthened deterministic org/person/business-id detection for Chinese/English document content
  - added engine/path guardrails so path-like spans are never masked, regardless of detector source
  - fixed untyped developer/system Responses message skipping
  - added unit/integration regression coverage for PDF-like business IDs, untyped developer/system inputs, and path preservation
  - reran live Codex probes against the local CLIProxyAPI/GLM5 upstream for PDF, mixed-language exact echo, and XLSX workflows
- `gate_mode`: `blocking`
- `independence_mode`: `independent`
- `routing_profile`: `pro`
- `role_requested`: `code-reviewer`
- `role_used`: `code-reviewer`
- `fallback_used`: `false`
- `reviewer_role`: `code-reviewer`
- `status`: `done`
- `verdict`: `accept`
- `retry_count`: `1`
- `key_findings`:
  - first review correctly caught that untyped top-level developer/system Responses items were still being scanned
  - live XLSX validation surfaced a second real bug: deterministic detectors could mask names inside absolute file paths
  - both issues were fixed and covered by new unit/integration tests before the second blocking review
  - remaining live limitation is model behavior, not proxy transport: GLM5 can still invent generic placeholder examples like `[[PERSON_xx]]`, which cannot be rehydrated because they were never issued by the vault
- `strongest_evidence`:
  - full repo checks passed after the fixes: `ruff check src tests`, `mypy src`, `pytest -q` with `86%` total coverage
  - live exact-echo trace `7628546f76bf2bf7`: `detection_count=18`, `placeholder_count=17`, `rehydration_count=30`, with typed placeholders upstream and exact caller-visible rehydration downstream
  - live PDF trace `5f9371520fb0f5fd`: upstream masking preserved the local file path while masking the target company/person/business-id values
  - live XLSX traces `402b4d05211bcae0`, `1283cb8360954572`, and `8b549dd4a9c94e1e`: `request_masked` kept `/Users/eyy/Downloads/李琳-重点项目进度12月份.xlsx` literal after the engine-level path exclusion fix
- `next_action`: `Close the accepted checkpoint and report the verified behavior, remaining model-side limitations, and local runtime details to the user.`
- `blocker`: ``
- `decision_owner`: ``
- `resume_trigger`: ``
