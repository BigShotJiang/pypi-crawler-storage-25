# Threat Model

`stronk-mask` is designed to reduce sensitive-data exposure to upstream language model providers while avoiding a second leak surface in its own operator tooling.

## In Scope

- sensitive values inside proxied JSON payloads
- accidental forwarding of secrets to upstream providers
- websocket turn-state handling for OpenAI Responses-compatible clients
- placeholder collisions and bypass attempts
- unsafe egress to arbitrary upstream hosts
- leakage through debug responses
- leakage through operator monitoring APIs and UI

## Trust Boundaries

### Caller to Proxy

The caller can send arbitrary JSON to the proxy but cannot choose arbitrary upstream targets.

### Proxy to Upstream

Only configured upstream base URLs are allowed. Redirects are refused.

### Proxy to Audit Store

Only sanitized event metadata crosses this boundary. Raw prompt text, raw completion text, websocket frame payloads, full headers, cookies, and placeholder maps must not cross it.

### Operator to Admin Plane

The admin plane expects trusted identity headers and a shared gateway secret from a reverse proxy or identity-aware gateway. Caller-facing proxy credentials must not authorize admin access.

### Websocket Session State

OpenAI Responses websocket compatibility keeps in-memory turn-state so follow-up turns can be reconstructed or recovered across reconnects. That state must remain process-local, memory-only, and absent from persisted telemetry.

## Primary Threats

### Raw Sensitive Data Persistence

Risk:
- storing raw prompts, raw completions, websocket frame payloads, or placeholder-to-original mappings creates a durable secret store

Current mitigation:
- request-scoped placeholder vault remains memory-only
- websocket session state remains memory-only
- SQLite store persists sanitized counts, status, and normalized paths only

### Credential Leakage

Risk:
- capturing inbound `Authorization`, `X-API-Key`, or cookies in the control plane leaks live upstream credentials

Current mitigation:
- request-header forwarding stays allowlisted for upstream use only
- the admin plane never persists or renders raw headers or cookies

### Admin Surface Becomes the Weakest Link

Risk:
- a monitoring UI exposed without real auth becomes easier to abuse than the proxy itself

Current mitigation:
- admin API and UI are disabled by default
- admin plane is separate from proxy routes
- admin requests require trusted identity headers, allowed roles, and the shared gateway secret
- local Compose uses loopback binding and Caddy basic auth
- Compose keeps the admin backend on an internal-only Docker network

### Websocket Bridge Weakens the Privacy Boundary

Risk:
- a generic websocket tunnel or permissive frame handling could bypass masking, rehydration controls, or upstream egress limits

Current mitigation:
- websocket support is limited to the OpenAI Responses path only
- only JSON text frames are accepted in the implemented scope
- real upstream `previous_response_id` values are preserved, but synthetic local prewarm IDs are never forwarded upstream
- unsupported request types return websocket error events instead of falling back
- upstream transport remains fixed to the configured HTTP plus Server-Sent Events (SSE) responses path

### Overclaiming Detection Quality

Risk:
- operators assume heuristic detectors are perfect and route highly sensitive traffic through the system without validating coverage

Current mitigation:
- docs explicitly state that names, organizations, and addresses are heuristic
- UI copy and docs should not imply complete privacy coverage

## Safe Defaults

- secret detectors default to `block`
- non-standard upstream hosts require explicit opt-in
- insecure upstream transport is off by default
- debug masking is off by default
- admin API and admin UI are off by default

## Residual Risks

- Chinese and English name or organization detection can miss ambiguous values
- the admin plane depends on correct reverse-proxy auth configuration
- the shared gateway secret must stay private and should only traverse the private admin path
- local Compose basic auth is convenient but not sufficient for public exposure
- `route_local` remains a fail-closed scaffold rather than a local execution path
- websocket support is intentionally narrow and does not yet cover binary/audio frames or generic vendor-specific realtime protocols

## Operational Guidance

- keep the proxy plane and admin plane on separate trust paths
- use OIDC or another identity-aware proxy for operator access in production
- do not expose the admin backend directly to the internet; keep it private behind the gateway
- treat the SQLite event store as sensitive operational metadata even though it excludes raw content
