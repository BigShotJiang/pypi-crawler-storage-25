# Architecture

`stronk-mask` is scoped as a security boundary service with a separate operator control plane.

## Two-Plane Design

### Data Plane

The proxy handles caller traffic:

1. Receive a request on one of the supported provider endpoints.
2. Parse the JSON body locally and traverse string-bearing fields.
3. Run deterministic detectors first.
4. Resolve per-detector policy decisions.
5. Replace maskable values with opaque request-scoped placeholders.
6. Forward only the masked payload to a fixed configured upstream.
7. Rehydrate placeholders inside the provider response before returning it to the caller.

For OpenAI Responses websocket clients, the data plane adds a scoped bridge:

1. Accept a websocket upgrade on `GET /v1/responses`.
2. Parse JSON text frames and normalize `response.create` / `response.append` events into the canonical `POST /responses` payload shape.
3. Apply the same masking and policy pipeline before any upstream call or local prewarm behavior.
4. Reuse the existing upstream HTTP plus Server-Sent Events (SSE) transport rather than opening a second upstream websocket.
5. Convert rehydrated SSE JSON events back into websocket text frames for the caller.
6. Keep memory-only turn-state, the last completed response ID, and the last completed output so follow-up turns can be reconstructed or recovered across reconnects without leaking prior raw content to disk.

### Control Plane

The admin plane handles operator traffic:

1. Read sanitized audit rows from the shared SQLite store.
2. Authenticate operators with first-party session-cookie login inside `stronk-mask-admin`.
3. Expose read-only monitoring APIs plus authenticated content-trace inspection through the same-origin admin gateway path.
4. Optionally serve the built React/Vite UI.

The control plane never persists the live placeholder vault. Raw request and response traces remain memory-only in the proxy runtime and are exposed only to authenticated operators through the private trace-bridge path.

## Core Components

- `src/stronk_mask/app.py`
  Proxy app factory for OpenAI-compatible and Anthropic-compatible routes.
- `src/stronk_mask/proxy/service.py`
  Request handling, upstream transport, websocket bridging, response rehydration, and sanitized audit-event emission.
- `src/stronk_mask/proxy/responses_ws.py`
  OpenAI Responses websocket session state, request normalization, and SSE-payload extraction helpers.
- `src/stronk_mask/redaction/`
  Deterministic detectors, overlap resolution, placeholder vault, and structured traversal.
- `src/stronk_mask/security/audit.py`
  Sanitized audit summaries and event records.
- `src/stronk_mask/admin/store.py`
  SQLite-backed sanitized event store and admin access log store.
- `src/stronk_mask/admin/auth.py`
  First-party admin password hashing, session handling, rate limiting, and role enforcement.
- `src/stronk_mask/admin_app.py`
  Separate admin API/UI app factory.
- `src/stronk_mask/proxy_runtime.py`
  Dual-listener proxy runtime that serves public inference on `8787` and the internal trace bridge on `8789` from one shared in-memory proxy process.
- `web/`
  React/Vite monitoring UI with light and dark mode.

## Safety Properties

- Only configured upstream base URLs are reachable.
- The caller cannot set a per-request upstream target.
- Official upstream hosts are pinned by default unless the operator explicitly allows non-standard compatible hosts.
- Secrets default to `block`.
- Debug masking is opt-in and sanitized.
- The placeholder map is request-scoped and memory-only.
- Websocket turn-state is memory-only and stores only the canonical normalized request, the last completed response ID, and the last completed output needed for follow-up turns.
- The audit store contains sanitized counts, paths, and metadata only.
- The admin plane is off by default and separate from the caller-facing proxy routes.
- The admin backend is intended to stay on a private or loopback-bound network behind the bundled same-origin gateway.
- Raw trace routes are not mounted on the public proxy listener. The trace bridge runs on a separate private listener inside the proxy runtime and still shares the same in-memory trace store.
- Rehydration is intentionally limited to human-readable response fields such as `content`, `text`, and streaming `delta`.
- Websocket support is intentionally limited to OpenAI Responses-style JSON text events. It is not a generic websocket relay.

## Event Store Schema

Persisted sanitized fields include:

- internal request ID
- timestamp
- provider family and endpoint
- model name
- stream flag
- outcome and HTTP status
- total latency
- detection counts by type
- action counts
- placeholder count
- rehydration count
- normalized masked JSON paths

Persisted fields do not include:

- raw request bodies
- raw response bodies
- rehydrated plaintext
- full headers
- cookies
- provider credentials
- placeholder-to-original mappings

## Implemented Provider Scope

- `POST /v1/chat/completions`
- `POST /v1/responses`
- `GET /v1/responses` websocket upgrade for OpenAI Responses-compatible clients
- `POST /anthropic/v1/messages`

Both streaming and non-streaming HTTP paths are covered in the implemented scope above. The OpenAI Responses surface also supports downstream websocket clients through the HTTP/SSE bridge described earlier.

## Deployment Shape

Recommended local stack:

- `stronk-mask-proxy` on `127.0.0.1:8787`
- private proxy trace bridge on `stronk-mask-proxy:8789`
- `stronk-mask-admin` internal only
- `stronk-mask-admin-gateway` on `127.0.0.1:8788`
- shared SQLite volume for sanitized audit rows
- internal admin-only Docker network between the gateway and admin backend

Recommended production direction:

- keep the proxy and admin planes separate
- keep first-party admin auth inside `stronk-mask-admin`
- keep the admin gateway loopback-bound or privately networked, and add TLS before widening exposure
- let only the gateway bridge `/api/debug/*` into the proxy runtime with the trace-bridge secret
- keep proxy caller traffic and admin traffic on distinct trust paths

## Current Limits

- Heuristic person, organization, and address detection is intentionally modular so a local model can replace or augment it later.
- Embedded JSON traversal currently targets common structured request fields such as tool/function `arguments` and `input`.
- `route_local` is enforced as a policy boundary, but the actual local execution path is not yet implemented.
- Websocket compatibility is scoped to `response.create` and `response.append` JSON text events, preserves real upstream `previous_response_id` continuations, and intentionally fails closed for unsupported frame types.
- The admin plane is read-only in this phase.
