from __future__ import annotations

from stronk_mask.proxy.responses_ws import (
    ResponsesWebsocketError,
    ResponsesWebsocketSession,
    is_terminal_response_event,
    response_completed_output,
    response_event_id,
    websocket_json_payloads_from_sse_chunk,
)


def test_responses_websocket_initial_create_forces_stream() -> None:
    session = ResponsesWebsocketSession()

    turn = session.normalize('{"type":"response.create","model":"gpt-4.1"}')

    assert turn.payload["stream"] is True
    assert turn.payload["input"] == []
    assert turn.synthetic_events == ()


def test_responses_websocket_append_requires_prior_create() -> None:
    session = ResponsesWebsocketSession()

    try:
        session.normalize('{"type":"response.append","input":[]}')
    except ResponsesWebsocketError as error:
        assert error.status_code == 400
        assert "before response.create" in error.message
    else:
        raise AssertionError("expected append without create to fail")


def test_responses_websocket_follow_up_preserves_previous_response_id() -> None:
    session = ResponsesWebsocketSession()
    session.normalize(
        '{"type":"response.create","model":"gpt-4.1","input":[{"type":"message","id":"msg_1"}]}'
    )
    session.last_completed_output = [{"type": "message", "id": "assistant_1"}]
    session.last_response_id = "resp_1"

    turn = session.normalize(
        '{"type":"response.create","previous_response_id":"resp_1","input":[{"type":"message","id":"msg_2"}]}'
    )

    assert turn.payload["previous_response_id"] == "resp_1"
    assert turn.payload["input"] == [{"type": "message", "id": "msg_2"}]


def test_responses_websocket_fresh_create_resets_prior_chain() -> None:
    session = ResponsesWebsocketSession()
    session.normalize(
        '{"type":"response.create","model":"gpt-4.1","input":[{"type":"message","id":"msg_1"}]}'
    )
    session.last_completed_output = [{"type": "message", "id": "assistant_1"}]
    session.last_response_id = "resp_1"

    turn = session.normalize(
        '{"type":"response.create","model":"gpt-4.1","input":[{"type":"message","id":"msg_2"}]}'
    )

    assert "previous_response_id" not in turn.payload
    assert turn.payload["input"] == [{"type": "message", "id": "msg_2"}]


def test_responses_websocket_rejects_mismatched_previous_response_id() -> None:
    session = ResponsesWebsocketSession()
    session.normalize('{"type":"response.create","model":"gpt-4.1"}')
    session.last_response_id = "resp_expected"

    try:
        session.normalize(
            '{"type":"response.create","previous_response_id":"resp_other","input":[]}'
        )
    except ResponsesWebsocketError as error:
        assert error.status_code == 409
        assert error.error_type == "invalid_websocket_turn"
    else:
        raise AssertionError("expected mismatched previous_response_id to fail")


def test_responses_websocket_local_prewarm_returns_synthetic_events() -> None:
    session = ResponsesWebsocketSession()

    turn = session.normalize('{"type":"response.create","model":"gpt-4.1","generate":false}')

    assert len(turn.synthetic_events) == 2
    assert turn.synthetic_events[0]["type"] == "response.created"
    assert turn.synthetic_events[1]["type"] == "response.completed"


def test_responses_websocket_local_prewarm_follow_up_replays_without_previous_response_id() -> None:
    session = ResponsesWebsocketSession()
    session.normalize('{"type":"response.create","model":"gpt-4.1","generate":false}')
    prewarm_response_id = session.last_response_id

    turn = session.normalize(
        '{"type":"response.create","previous_response_id":"'
        + str(prewarm_response_id)
        + '","input":[{"type":"message","id":"msg_2"}]}'
    )

    assert "previous_response_id" not in turn.payload
    assert turn.payload["input"] == [{"type": "message", "id": "msg_2"}]


def test_responses_websocket_follow_up_does_not_inherit_prior_instructions() -> None:
    session = ResponsesWebsocketSession()
    session.normalize(
        '{"type":"response.create","model":"gpt-4.1","instructions":"secret","generate":false}'
    )
    prewarm_response_id = session.last_response_id

    turn = session.normalize(
        '{"type":"response.create","previous_response_id":"'
        + str(prewarm_response_id)
        + '","input":[{"type":"message","id":"msg_2"}]}'
    )

    assert "instructions" not in turn.payload


def test_websocket_json_payloads_from_sse_chunk_extracts_json_messages() -> None:
    payloads = websocket_json_payloads_from_sse_chunk(
        b'data: {"type":"response.created"}\n\n'
        b"data: [DONE]\n\n"
        b'data: {"type":"response.completed"}\n\n'
    )

    assert [payload["type"] for payload in payloads] == ["response.created", "response.completed"]


def test_response_completed_output_returns_output_array() -> None:
    output = response_completed_output(
        {
            "type": "response.completed",
            "response": {"output": [{"id": "out_1"}]},
        }
    )

    assert output == [{"id": "out_1"}]


def test_terminal_response_event_helpers_detect_terminal_events() -> None:
    payload = {
        "type": "response.failed",
        "response": {"id": "resp_2"},
    }

    assert is_terminal_response_event(payload) is True
    assert response_event_id(payload) == "resp_2"
