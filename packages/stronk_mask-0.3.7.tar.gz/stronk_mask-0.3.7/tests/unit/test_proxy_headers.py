from __future__ import annotations

import pytest

from stronk_mask.config import Settings
from stronk_mask.providers import OPENAI_CHAT_COMPLETIONS
from stronk_mask.proxy.headers import resolve_upstream_url, sanitize_request_headers


def test_request_header_allowlist_strips_cookies_and_forwarding_headers() -> None:
    headers = sanitize_request_headers(
        {
            "Authorization": "Bearer upstream",
            "Cookie": "session=1",
            "X-Forwarded-For": "1.1.1.1",
            "Content-Type": "application/json",
        },
        OPENAI_CHAT_COMPLETIONS,
    )

    assert headers["Authorization"] == "Bearer upstream"
    assert "Cookie" not in headers
    assert "X-Forwarded-For" not in headers


def test_resolve_upstream_url_accepts_existing_v1_base() -> None:
    settings = Settings(
        openai_upstream_base_url="http://openai.test/v1",
        allow_insecure_upstreams=True,
        allow_nonstandard_upstream_hosts=True,
    )

    assert resolve_upstream_url(settings, OPENAI_CHAT_COMPLETIONS) == (
        "http://openai.test/v1/chat/completions"
    )


def test_resolve_upstream_url_rejects_insecure_by_default() -> None:
    settings = Settings(openai_upstream_base_url="http://openai.test")

    with pytest.raises(ValueError):
        resolve_upstream_url(settings, OPENAI_CHAT_COMPLETIONS)


def test_resolve_upstream_url_rejects_nonstandard_host_by_default() -> None:
    settings = Settings(openai_upstream_base_url="https://evil.example")

    with pytest.raises(ValueError):
        resolve_upstream_url(settings, OPENAI_CHAT_COMPLETIONS)


def test_resolve_upstream_url_rejects_userinfo_tricks() -> None:
    settings = Settings(
        openai_upstream_base_url="https://api.openai.com@evil.example",
        allow_nonstandard_upstream_hosts=True,
    )

    with pytest.raises(ValueError):
        resolve_upstream_url(settings, OPENAI_CHAT_COMPLETIONS)
