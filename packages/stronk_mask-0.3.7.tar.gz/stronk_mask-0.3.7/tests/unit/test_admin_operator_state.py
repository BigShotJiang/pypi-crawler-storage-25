from __future__ import annotations

import json
from pathlib import Path

import pytest

from stronk_mask.admin.operator_state_store import OperatorStateStore, OperatorStateStoreError
from tests.helpers import build_bundle_root


def build_store(tmp_path: Path) -> OperatorStateStore:
    bundle_root = build_bundle_root(tmp_path / "bundle")
    return OperatorStateStore(bundle_root / "config")


def test_create_provider_slugifies_id_and_keeps_active_untouched(tmp_path: Path) -> None:
    store = build_store(tmp_path)

    created = store.create_provider(
        {
            "label": "OpenAI Production",
            "kind": "openai_compat",
            "base_url": "https://api.openai.com/v1",
            "secret_ref": "PROVIDER_OPENAI_API_KEY",
        }
    )

    assert created.id == "openai-production"
    assert created.cliproxy_provider_name == "openai-production"

    active_payload = json.loads(store.active_path.read_text(encoding="utf-8"))
    draft_payload = json.loads(store.draft_path.read_text(encoding="utf-8"))
    assert active_payload["providers"] == []
    assert draft_payload["providers"][0]["id"] == "openai-production"


def test_create_provider_rejects_browser_supplied_cliproxy_provider_name(tmp_path: Path) -> None:
    store = build_store(tmp_path)

    with pytest.raises(OperatorStateStoreError):
        store.create_provider(
            {
                "label": "OpenAI Production",
                "kind": "openai_compat",
                "base_url": "https://api.openai.com/v1",
                "secret_ref": "PROVIDER_OPENAI_API_KEY",
                "cliproxy_provider_name": "user-supplied",
            }
        )


def test_create_model_requires_known_privacy_policy(tmp_path: Path) -> None:
    store = build_store(tmp_path)
    provider = store.create_provider(
        {
            "label": "OpenAI Production",
            "kind": "openai_compat",
            "base_url": "https://api.openai.com/v1",
            "secret_ref": "PROVIDER_OPENAI_API_KEY",
        }
    )

    with pytest.raises(OperatorStateStoreError):
        store.create_model(
            provider.id,
            {
                "upstream_id": "gpt-4.1-mini",
                "public_alias": "stronk-lm",
                "privacy_policy_id": "missing-policy",
            },
        )


def test_update_model_keeps_upstream_id_immutable(tmp_path: Path) -> None:
    store = build_store(tmp_path)
    provider = store.create_provider(
        {
            "label": "OpenAI Production",
            "kind": "openai_compat",
            "base_url": "https://api.openai.com/v1",
            "secret_ref": "PROVIDER_OPENAI_API_KEY",
        }
    )
    store.create_model(
        provider.id,
        {
            "upstream_id": "gpt-4.1-mini",
            "public_alias": "stronk-lm",
            "privacy_policy_id": "default-openai-chat",
        },
    )

    with pytest.raises(OperatorStateStoreError):
        store.update_model(
            provider.id,
            "gpt-4.1-mini",
            {"upstream_id": "gpt-4.1"},
        )
