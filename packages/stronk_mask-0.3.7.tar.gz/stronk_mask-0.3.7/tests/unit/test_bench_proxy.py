from __future__ import annotations

import json

from scripts.bench_proxy import (
    LatencyBucket,
    _build_benchmark_prompt,
    _build_stream_events,
    _record_output_invariants,
)


def _render_sse_body(*, text: str) -> str:
    events = _build_stream_events(text, {"bench_response_id": "resp-bench-1"})
    return (
        "\n\n".join(
            "data: " + json.dumps(event, ensure_ascii=False, separators=(",", ":"))
            for event in events
        )
        + "\n\n"
    )


def test_record_output_invariants_ignores_split_prefix_tokens_in_sse_body() -> None:
    request_token = "bench-sse-stream-0-10"
    body = _render_sse_body(text=f"{_build_benchmark_prompt()} {request_token}")
    metrics = LatencyBucket()

    _record_output_invariants(
        metrics,
        text=body,
        request_token=request_token,
        sse=True,
    )

    assert metrics.counters["response_token_miss"] == 0
    assert metrics.counters["cross_request_tokens"] == 0


def test_record_output_invariants_still_detects_foreign_token_in_sse_body() -> None:
    request_token = "bench-sse-stream-0-10"
    foreign_token = "bench-sse-stream-1-4"
    body = (
        "\n\n".join(
            [
                "data: "
                + json.dumps(
                    {
                        "type": "response.output_text.delta",
                        "sequence_number": 1,
                        "delta": foreign_token,
                    },
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
                "data: "
                + json.dumps(
                    {
                        "type": "response.completed",
                        "sequence_number": 2,
                        "response": {
                            "id": "resp-bench-1",
                            "object": "response",
                            "status": "completed",
                            "output": [
                                {
                                    "type": "message",
                                    "content": [
                                        {
                                            "type": "output_text",
                                            "text": f"Echo: {_build_benchmark_prompt()} {request_token}",
                                        }
                                    ],
                                }
                            ],
                        },
                    },
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
                "data: [DONE]",
            ]
        )
        + "\n\n"
    )
    metrics = LatencyBucket()

    _record_output_invariants(
        metrics,
        text=body,
        request_token=request_token,
        sse=True,
    )

    assert metrics.counters["response_token_miss"] == 0
    assert metrics.counters["cross_request_tokens"] == 1
