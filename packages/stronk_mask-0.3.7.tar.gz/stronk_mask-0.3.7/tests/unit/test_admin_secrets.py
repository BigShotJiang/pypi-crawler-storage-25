from __future__ import annotations

from pathlib import Path

import pytest

from stronk_mask.admin.secrets import (
    SecretResolutionError,
    load_env_file,
    resolve_secret_ref,
    sync_secret_into_env_file,
    validate_resolvable_secret_ref,
)
from tests.helpers import build_bundle_root


def test_secret_resolution_prefers_process_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    bundle_root = build_bundle_root(tmp_path / "bundle")
    secrets_dir = bundle_root / "secrets"
    (secrets_dir / "PROVIDER_OPENAI_API_KEY").write_text("from-file\n", encoding="utf-8")
    monkeypatch.setenv("PROVIDER_OPENAI_API_KEY", "from-env")

    value, resolution = resolve_secret_ref(
        "PROVIDER_OPENAI_API_KEY",
        secrets_dir=secrets_dir,
    )

    assert value == "from-env"
    assert resolution.source == "env"


def test_secret_resolution_falls_back_to_file(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(tmp_path / "bundle")
    secrets_dir = bundle_root / "secrets"
    (secrets_dir / "PROVIDER_OPENAI_API_KEY").write_text("from-file\n", encoding="utf-8")
    (secrets_dir / "PROVIDER_OPENAI_API_KEY").chmod(0o600)

    value, resolution = resolve_secret_ref(
        "PROVIDER_OPENAI_API_KEY",
        process_env={},
        secrets_dir=secrets_dir,
    )

    assert value == "from-file"
    assert resolution.source == "file"
    assert resolution.path is not None


def test_secret_resolution_rejects_symlink_backed_secret(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(tmp_path / "bundle")
    secrets_dir = bundle_root / "secrets"
    source_secret = bundle_root / "source-secret"
    source_secret.write_text("from-symlink\n", encoding="utf-8")
    source_secret.chmod(0o600)
    (secrets_dir / "PROVIDER_OPENAI_API_KEY").symlink_to(source_secret)

    with pytest.raises(SecretResolutionError, match="symlink"):
        resolve_secret_ref(
            "PROVIDER_OPENAI_API_KEY",
            process_env={},
            secrets_dir=secrets_dir,
        )


def test_secret_resolution_rejects_non_regular_secret_file(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(tmp_path / "bundle")
    secret_path = bundle_root / "secrets" / "PROVIDER_OPENAI_API_KEY"
    secret_path.mkdir()

    with pytest.raises(SecretResolutionError, match="regular file"):
        resolve_secret_ref(
            "PROVIDER_OPENAI_API_KEY",
            process_env={},
            secrets_dir=bundle_root / "secrets",
        )


def test_secret_resolution_rejects_permissive_secret_file_mode(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(tmp_path / "bundle")
    secret_path = bundle_root / "secrets" / "PROVIDER_OPENAI_API_KEY"
    secret_path.write_text("from-file\n", encoding="utf-8")
    secret_path.chmod(0o644)

    with pytest.raises(SecretResolutionError, match="group- or world-readable/writable"):
        resolve_secret_ref(
            "PROVIDER_OPENAI_API_KEY",
            process_env={},
            secrets_dir=bundle_root / "secrets",
        )


def test_secret_validation_rejects_non_allowlisted_names() -> None:
    with pytest.raises(SecretResolutionError):
        validate_resolvable_secret_ref("STRONK_MASK_ADMIN_PROXY_SECRET")


def test_file_backed_secret_can_be_synced_into_runtime_env_file(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(
        tmp_path / "bundle",
        env_values={"STRONK_GATEWAY_PUBLIC_API_KEY": "pub", "STRONK_GATEWAY_PUBLIC_HTTP_PORT": "54321"},
    )
    env_path = bundle_root / ".env"

    sync_secret_into_env_file(
        env_path,
        secret_ref="PROVIDER_OPENAI_API_KEY",
        value="synced-value",
    )

    env_values = load_env_file(env_path)
    assert env_values["PROVIDER_OPENAI_API_KEY"] == "synced-value"
