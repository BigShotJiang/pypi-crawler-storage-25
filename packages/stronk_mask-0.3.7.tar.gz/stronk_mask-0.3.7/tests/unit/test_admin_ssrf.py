from __future__ import annotations

import httpcore
import pytest
from httpcore._backends.anyio import AnyIOBackend

from stronk_mask.admin.ssrf import (
    MAX_RESPONSE_BYTES,
    PinnedAddressBackend,
    SsrfBlockedError,
    fetch_openai_models,
    validate_provider_base_url,
)
from tests.helpers import build_models_transport


@pytest.mark.parametrize(
    "base_url",
    [
        "https://127.0.0.1/v1",
        "https://10.0.0.5/v1",
        "https://169.254.169.254/v1",
        "https://localhost.localdomain/v1",
        "https://service.internal/v1",
        "https://service.local/v1",
        "https://0x7f.0x0.0x0.0x1/v1",
        "https://2130706433/v1",
        "https://[::ffff:127.0.0.1]/v1",
        "https://[2001:0000::1]/v1",
        "https://[2002::1]/v1",
        "http://example.com/v1",
    ],
)
def test_validate_provider_base_url_rejects_blocked_destinations(base_url: str) -> None:
    with pytest.raises(SsrfBlockedError):
        validate_provider_base_url(base_url, resolver=lambda hostname: [hostname])


def test_validate_provider_base_url_accepts_https_public_host() -> None:
    target = validate_provider_base_url(
        "https://api.openai.com/v1",
        resolver=lambda hostname: ["8.8.8.8"],
    )

    assert target.hostname == "api.openai.com"
    assert target.addresses == ("8.8.8.8",)


def test_validate_provider_base_url_accepts_http_localhost() -> None:
    target = validate_provider_base_url("http://localhost:11434/v1")

    assert target.hostname == "localhost"
    assert target.addresses == ("127.0.0.1",)


def test_validate_provider_base_url_accepts_http_allowlisted_host_when_explicitly_enabled() -> None:
    target = validate_provider_base_url(
        "http://fake-openai-upstream:18080/v1",
        allowlist=("fake-openai-upstream",),
        allow_http_allowlist=True,
    )

    assert target.hostname == "fake-openai-upstream"
    assert target.addresses == ("fake-openai-upstream",)


def test_validate_provider_base_url_rejects_http_allowlisted_host_without_opt_in() -> None:
    with pytest.raises(SsrfBlockedError, match="use https"):
        validate_provider_base_url(
            "http://fake-openai-upstream:18080/v1",
            allowlist=("fake-openai-upstream",),
        )


@pytest.mark.anyio
async def test_pinned_address_backend_tries_validated_addresses_in_order(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    attempts: list[str] = []
    sentinel = object()

    async def fake_connect_tcp(
        self: AnyIOBackend,
        host: str,
        port: int,
        timeout: float | None = None,
        local_address: str | None = None,
        socket_options=None,
    ) -> object:
        del self, port, timeout, local_address, socket_options
        attempts.append(host)
        if host == "203.0.113.10":
            raise httpcore.ConnectError("first address failed")
        return sentinel

    monkeypatch.setattr(AnyIOBackend, "connect_tcp", fake_connect_tcp)

    backend = PinnedAddressBackend(
        hostname="api.openai.com",
        addresses=("203.0.113.10", "203.0.113.11"),
    )

    result = await backend.connect_tcp("api.openai.com", 443)

    assert result is sentinel
    assert attempts == ["203.0.113.10", "203.0.113.11"]


@pytest.mark.anyio
async def test_fetch_openai_models_rejects_cross_host_redirect() -> None:
    target = validate_provider_base_url(
        "https://api.openai.com/v1",
        resolver=lambda hostname: ["8.8.8.8"],
    )

    with pytest.raises(SsrfBlockedError):
        await fetch_openai_models(
            target,
            api_key="secret",
            transport=build_models_transport(
                model_ids=["gpt-4.1-mini"],
                expected_bearer="secret",
                redirect_location="https://evil.example/v1/models",
            ),
        )


@pytest.mark.anyio
async def test_fetch_openai_models_streams_and_caps_response_before_full_buffering() -> None:
    target = validate_provider_base_url(
        "https://api.openai.com/v1",
        resolver=lambda hostname: ["8.8.8.8"],
    )

    oversized_chunks = [
        b"a" * (MAX_RESPONSE_BYTES - 8),
        b"b" * 16,
        AssertionError("late buffering detected"),
    ]

    with pytest.raises(SsrfBlockedError, match="1MB"):
        await fetch_openai_models(
            target,
            api_key="secret",
            transport=build_models_transport(
                model_ids=["gpt-4.1-mini"],
                expected_bearer="secret",
                stream_chunks=oversized_chunks,
            ),
        )
