from __future__ import annotations

import httpx

from tests.helpers import build_test_client


def test_blocked_secret_never_reaches_upstream() -> None:
    client, transport = build_test_client(
        lambda request, body: httpx.Response(200, json={"ok": True})
    )
    secret = "sk-proj-abcdefghijklmnopqrstuvwxyz123456"

    response = client.post(
        "/v1/chat/completions",
        json={"model": "gpt-4.1", "messages": [{"role": "user", "content": secret}]},
        headers={"Authorization": "Bearer upstream-token"},
    )

    assert response.status_code == 422
    assert transport.requests == []
    assert secret not in response.text


def test_route_local_policy_fails_closed_until_local_handler_exists() -> None:
    client, transport = build_test_client(
        lambda request, body: httpx.Response(200, json={"ok": True}),
        email_action="route_local",
    )

    response = client.post(
        "/v1/chat/completions",
        json={"model": "gpt-4.1", "messages": [{"role": "user", "content": "alice@example.com"}]},
        headers={"Authorization": "Bearer upstream-token"},
    )

    assert response.status_code == 503
    assert transport.requests == []


def test_malformed_provider_payload_is_rejected_locally() -> None:
    client, transport = build_test_client(
        lambda request, body: httpx.Response(200, json={"ok": True})
    )

    response = client.post(
        "/v1/chat/completions",
        content='"not-an-object"',
        headers={"Authorization": "Bearer upstream-token", "Content-Type": "application/json"},
    )

    assert response.status_code == 400
    assert transport.requests == []
