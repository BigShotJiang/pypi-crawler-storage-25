from __future__ import annotations

import httpx
from fastapi.testclient import TestClient

from stronk_mask.app import create_app
from stronk_mask.config import Settings
from tests.helpers import build_test_client


def test_health_endpoint() -> None:
    client, _ = build_test_client(lambda request, body: httpx.Response(500))

    response = client.get("/health")

    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_debug_mask_endpoint_is_opt_in_and_sanitized() -> None:
    client, _ = build_test_client(
        lambda request, body: httpx.Response(500),
        enable_debug_mask_endpoint=True,
    )

    response = client.post("/v1/mask", json={"payload": {"message": "email alice@example.com"}})

    assert response.status_code == 200
    payload = response.json()
    assert "alice@example.com" not in str(payload)
    assert payload["audit"]["detection_count"] == 1


def test_debug_mask_endpoint_is_disabled_by_default() -> None:
    settings = Settings(
        openai_upstream_base_url="http://openai.test",
        anthropic_upstream_base_url="http://anthropic.test",
        allow_insecure_upstreams=True,
        allow_nonstandard_upstream_hosts=True,
    )
    client = TestClient(create_app(settings=settings))

    response = client.post("/v1/mask", json={"payload": {"message": "email alice@example.com"}})

    assert response.status_code == 404


def test_debug_mask_endpoint_never_echoes_blocked_plaintext() -> None:
    client, _ = build_test_client(
        lambda request, body: httpx.Response(500),
        enable_debug_mask_endpoint=True,
    )
    secret = "sk-proj-abcdefghijklmnopqrstuvwxyz123456"

    response = client.post("/v1/mask", json={"payload": {"message": secret}})

    assert response.status_code == 200
    assert secret not in response.text
    assert response.json()["payload"] is None
    assert response.json()["payload_redacted"] is True
