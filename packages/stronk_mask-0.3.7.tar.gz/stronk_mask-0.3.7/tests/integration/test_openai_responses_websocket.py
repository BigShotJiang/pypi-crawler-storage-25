from __future__ import annotations

import asyncio
import json
from threading import Event

import httpx
import pytest
from starlette.websockets import WebSocket, WebSocketDisconnect

from tests.helpers import StaticAsyncByteStream, build_test_client, contains_placeholder


class GatedAsyncByteStream(StaticAsyncByteStream):
    def __init__(
        self,
        chunks: list[bytes],
        *,
        release_event: Event,
        finished_event: Event | None = None,
    ) -> None:
        super().__init__(chunks)
        self.release_event = release_event
        self.finished_event = finished_event

    async def __aiter__(self):  # type: ignore[override]
        for index, chunk in enumerate(self.chunks):
            if index:
                await asyncio.to_thread(self.release_event.wait)
            yield chunk
        if self.finished_event is not None:
            self.finished_event.set()

    async def aclose(self) -> None:
        if self.finished_event is not None:
            self.finished_event.set()
        await super().aclose()


def test_removed_legacy_openai_responses_websocket_alias_fails_closed() -> None:
    client, _ = build_test_client(lambda request, body: httpx.Response(200, json={"ok": True}))

    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("/openai/v1/responses"):
            pass


def test_canonical_openai_responses_websocket_route_masks_upstream_and_rehydrates_downstream() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        assert payload["stream"] is True
        masked_text = payload["input"][0]["content"][0]["text"]
        chunks = [
            (
                "data: "
                + json.dumps(
                    {"type": "response.output_text.delta", "delta": masked_text},
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            (
                "data: "
                + json.dumps(
                    {
                        "type": "response.completed",
                        "response": {
                            "id": "resp_v1",
                            "output": [
                                {
                                    "type": "message",
                                    "content": [
                                        {
                                            "type": "output_text",
                                            "text": masked_text,
                                        }
                                    ],
                                }
                            ],
                        },
                    },
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            b"data: [DONE]\n\n",
        ]
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(chunks),
        )

    client, transport = build_test_client(handler)
    original = "Contact Alice Johnson at alice@example.com"

    with client.websocket_connect(
        "/v1/responses",
        headers={"Authorization": "Bearer upstream-token"},
    ) as websocket:
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "model": "gpt-4.1",
                    "input": [
                        {
                            "role": "user",
                            "content": [{"type": "input_text", "text": original}],
                        }
                    ],
                }
            )
        )
        delta = json.loads(websocket.receive_text())
        completed = json.loads(websocket.receive_text())

    body = transport.requests[0]["body"].decode("utf-8")
    assert "Alice Johnson" not in body
    assert "alice@example.com" not in body
    assert contains_placeholder(body)
    assert delta["type"] == "response.output_text.delta"
    assert delta["delta"] == original
    assert completed["type"] == "response.completed"
    assert completed["response"]["output"][0]["content"][0]["text"] == original


def test_openai_responses_websocket_supports_local_prewarm_then_follow_up() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        assert "previous_response_id" not in payload
        assert "instructions" not in payload
        chunks = [
            (
                "data: "
                + json.dumps(
                    {
                        "type": "response.completed",
                        "response": {
                            "id": "resp_2",
                            "output": payload["input"],
                        },
                    },
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            b"data: [DONE]\n\n",
        ]
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(chunks),
        )

    client, transport = build_test_client(handler)

    with client.websocket_connect(
        "/v1/responses",
        headers={"Authorization": "Bearer upstream-token"},
    ) as websocket:
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "model": "gpt-4.1",
                    "instructions": "keep local only",
                    "generate": False,
                }
            )
        )
        created = json.loads(websocket.receive_text())
        completed = json.loads(websocket.receive_text())
        prewarm_response_id = completed["response"]["id"]

        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "previous_response_id": prewarm_response_id,
                    "input": [
                        {
                            "type": "message",
                            "id": "msg_1",
                            "content": [{"type": "input_text", "text": "hello"}],
                        }
                    ],
                }
            )
        )
        follow_up = json.loads(websocket.receive_text())

    assert created["type"] == "response.created"
    assert completed["type"] == "response.completed"
    assert len(transport.requests) == 1
    assert transport.requests[0]["json"]["input"][0]["id"] == "msg_1"
    assert follow_up["type"] == "response.completed"


def test_openai_responses_websocket_preserves_previous_response_id_for_real_continuation() -> None:
    request_count = 0

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        nonlocal request_count
        request_count += 1
        payload = json.loads(body)
        if request_count == 1:
            assert "previous_response_id" not in payload
            response_id = "resp_1"
        else:
            assert payload["previous_response_id"] == "resp_1"
            assert payload["input"] == [{"type": "message", "id": "msg_2"}]
            response_id = "resp_2"
        chunks = [
            (
                "data: "
                + json.dumps(
                    {
                        "type": "response.completed",
                        "response": {"id": response_id, "output": payload["input"]},
                    },
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            b"data: [DONE]\n\n",
        ]
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(chunks),
        )

    client, transport = build_test_client(handler)

    with client.websocket_connect("/v1/responses") as websocket:
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "model": "gpt-4.1",
                    "input": [{"type": "message", "id": "msg_1"}],
                }
            )
        )
        first_completed = json.loads(websocket.receive_text())
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "previous_response_id": "resp_1",
                    "input": [{"type": "message", "id": "msg_2"}],
                }
            )
        )
        second_completed = json.loads(websocket.receive_text())

    assert first_completed["type"] == "response.completed"
    assert second_completed["type"] == "response.completed"
    assert len(transport.requests) == 2
    assert transport.requests[1]["json"]["previous_response_id"] == "resp_1"


def test_openai_responses_websocket_fresh_create_resets_prior_chain() -> None:
    request_count = 0

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        nonlocal request_count
        request_count += 1
        payload = json.loads(body)
        if request_count == 2:
            assert "previous_response_id" not in payload
            assert payload["input"] == [{"type": "message", "id": "msg_2"}]
        chunks = [
            (
                "data: "
                + json.dumps(
                    {
                        "type": "response.completed",
                        "response": {
                            "id": f"resp_{request_count}",
                            "output": payload["input"],
                        },
                    },
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            b"data: [DONE]\n\n",
        ]
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(chunks),
        )

    client, transport = build_test_client(handler)

    with client.websocket_connect("/v1/responses") as websocket:
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "model": "gpt-4.1",
                    "input": [{"type": "message", "id": "msg_1"}],
                }
            )
        )
        json.loads(websocket.receive_text())
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "model": "gpt-4.1",
                    "input": [{"type": "message", "id": "msg_2"}],
                }
            )
        )
        completed = json.loads(websocket.receive_text())

    assert completed["type"] == "response.completed"
    assert len(transport.requests) == 2


def test_openai_responses_websocket_reuses_turn_state_across_reconnect_without_forwarding_it() -> (
    None
):
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        assert payload["model"] == "gpt-4.1"
        assert "previous_response_id" not in payload
        chunks = [
            (
                "data: "
                + json.dumps(
                    {
                        "type": "response.completed",
                        "response": {"id": "resp_2", "output": payload["input"]},
                    },
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            b"data: [DONE]\n\n",
        ]
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(chunks),
        )

    client, transport = build_test_client(handler)
    turn_state = "turn-reconnect-1"

    with client.websocket_connect(
        "/v1/responses",
        headers={"x-codex-turn-state": turn_state},
    ) as websocket:
        websocket.send_text(
            json.dumps({"type": "response.create", "model": "gpt-4.1", "generate": False})
        )
        json.loads(websocket.receive_text())
        completed = json.loads(websocket.receive_text())
        prewarm_response_id = completed["response"]["id"]

    with client.websocket_connect(
        "/v1/responses",
        headers={"x-codex-turn-state": turn_state},
    ) as websocket:
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "previous_response_id": prewarm_response_id,
                    "input": [{"type": "message", "id": "msg_2"}],
                }
            )
        )
        follow_up = json.loads(websocket.receive_text())

    assert len(transport.requests) == 1
    assert "x-codex-turn-state" not in {
        key.lower(): value for key, value in transport.requests[0]["headers"].items()
    }
    assert follow_up["type"] == "response.completed"


def test_openai_responses_websocket_reconnect_after_midstream_disconnect_keeps_last_committed_state() -> (
    None
):
    request_count = 0
    release_stream = Event()
    stream_finished = Event()

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        nonlocal request_count
        request_count += 1
        payload = json.loads(body)
        if request_count == 1:
            return httpx.Response(
                200,
                headers={"content-type": "text/event-stream"},
                stream=GatedAsyncByteStream(
                    [
                        (
                            "data: "
                            + json.dumps(
                                {"type": "response.output_text.delta", "delta": "partial"},
                                ensure_ascii=False,
                            )
                            + "\n\n"
                        ).encode("utf-8"),
                        (
                            "data: "
                            + json.dumps(
                                {
                                    "type": "response.completed",
                                    "response": {"id": "resp_retry_1", "output": payload["input"]},
                                },
                                ensure_ascii=False,
                            )
                            + "\n\n"
                        ).encode("utf-8"),
                    ],
                    release_event=release_stream,
                    finished_event=stream_finished,
                ),
            )
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(
                [
                    (
                        "data: "
                        + json.dumps(
                            {
                                "type": "response.completed",
                                "response": {"id": "resp_retry_2", "output": payload["input"]},
                            },
                            ensure_ascii=False,
                        )
                        + "\n\n"
                    ).encode("utf-8"),
                    b"data: [DONE]\n\n",
                ]
            ),
        )

    client, transport = build_test_client(handler)
    turn_state = "turn-retry-1"

    with client.websocket_connect(
        "/v1/responses",
        headers={"x-codex-turn-state": turn_state},
    ) as websocket:
        websocket.send_text(
            json.dumps({"type": "response.create", "model": "gpt-4.1", "generate": False})
        )
        json.loads(websocket.receive_text())
        prewarm_completed = json.loads(websocket.receive_text())
        prewarm_response_id = prewarm_completed["response"]["id"]

    with client.websocket_connect(
        "/v1/responses",
        headers={"x-codex-turn-state": turn_state},
    ) as websocket:
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "previous_response_id": prewarm_response_id,
                    "input": [{"type": "message", "id": "msg_abort"}],
                }
            )
        )
        delta = json.loads(websocket.receive_text())
        websocket.close()
        release_stream.set()
        assert stream_finished.wait(timeout=1.0)

    assert delta["type"] == "response.output_text.delta"

    with client.websocket_connect(
        "/v1/responses",
        headers={"x-codex-turn-state": turn_state},
    ) as websocket:
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "previous_response_id": prewarm_response_id,
                    "input": [{"type": "message", "id": "msg_retry"}],
                }
            )
        )
        completed = json.loads(websocket.receive_text())

    assert completed["type"] == "response.completed"
    assert len(transport.requests) == 2
    assert "previous_response_id" not in transport.requests[1]["json"]
    assert transport.requests[1]["json"]["input"] == [{"type": "message", "id": "msg_retry"}]


def test_openai_responses_websocket_disconnect_after_terminal_event_keeps_committed_state() -> None:
    request_count = 0
    release_done = Event()
    stream_finished = Event()

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        nonlocal request_count
        request_count += 1
        payload = json.loads(body)
        if request_count == 1:
            assert "previous_response_id" not in payload
            return httpx.Response(
                200,
                headers={"content-type": "text/event-stream"},
                stream=GatedAsyncByteStream(
                    [
                        (
                            "data: "
                            + json.dumps(
                                {
                                    "type": "response.completed",
                                    "response": {
                                        "id": "resp_commit_1",
                                        "output": payload["input"],
                                    },
                                },
                                ensure_ascii=False,
                            )
                            + "\n\n"
                        ).encode("utf-8"),
                        b"data: [DONE]\n\n",
                    ],
                    release_event=release_done,
                    finished_event=stream_finished,
                ),
            )
        assert payload["previous_response_id"] == "resp_commit_1"
        assert payload["input"] == [{"type": "message", "id": "msg_2"}]
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(
                [
                    (
                        "data: "
                        + json.dumps(
                            {
                                "type": "response.completed",
                                "response": {"id": "resp_commit_2", "output": payload["input"]},
                            },
                            ensure_ascii=False,
                        )
                        + "\n\n"
                    ).encode("utf-8"),
                    b"data: [DONE]\n\n",
                ]
            ),
        )

    client, transport = build_test_client(handler)
    turn_state = "turn-commit-1"

    with client.websocket_connect(
        "/v1/responses",
        headers={"x-codex-turn-state": turn_state},
    ) as websocket:
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "model": "gpt-4.1",
                    "input": [{"type": "message", "id": "msg_1"}],
                }
            )
        )
        completed = json.loads(websocket.receive_text())
        assert completed["type"] == "response.completed"
        websocket.close()
        release_done.set()
        assert stream_finished.wait(timeout=1.0)

    with client.websocket_connect(
        "/v1/responses",
        headers={"x-codex-turn-state": turn_state},
    ) as websocket:
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "previous_response_id": "resp_commit_1",
                    "input": [{"type": "message", "id": "msg_2"}],
                }
            )
        )
        next_completed = json.loads(websocket.receive_text())

    assert next_completed["type"] == "response.completed"
    assert len(transport.requests) == 2
    assert transport.requests[1]["json"]["previous_response_id"] == "resp_commit_1"


def test_openai_responses_websocket_reconnects_before_upstream_done_after_terminal_commit() -> None:
    request_count = 0
    release_done = Event()

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        nonlocal request_count
        request_count += 1
        payload = json.loads(body)
        if request_count == 1:
            assert "previous_response_id" not in payload
            return httpx.Response(
                200,
                headers={"content-type": "text/event-stream"},
                stream=GatedAsyncByteStream(
                    [
                        (
                            "data: "
                            + json.dumps(
                                {
                                    "type": "response.completed",
                                    "response": {
                                        "id": "resp_commit_early_1",
                                        "output": payload["input"],
                                    },
                                },
                                ensure_ascii=False,
                            )
                            + "\n\n"
                        ).encode("utf-8"),
                        b"data: [DONE]\n\n",
                    ],
                    release_event=release_done,
                ),
            )
        assert payload["previous_response_id"] == "resp_commit_early_1"
        assert payload["input"] == [{"type": "message", "id": "msg_2"}]
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(
                [
                    (
                        "data: "
                        + json.dumps(
                            {
                                "type": "response.completed",
                                "response": {
                                    "id": "resp_commit_early_2",
                                    "output": payload["input"],
                                },
                            },
                            ensure_ascii=False,
                        )
                        + "\n\n"
                    ).encode("utf-8"),
                    b"data: [DONE]\n\n",
                ]
            ),
        )

    client, transport = build_test_client(handler)
    turn_state = "turn-commit-early-1"

    with client.websocket_connect(
        "/v1/responses",
        headers={"x-codex-turn-state": turn_state},
    ) as websocket_one:
        websocket_one.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "model": "gpt-4.1",
                    "input": [{"type": "message", "id": "msg_1"}],
                }
            )
        )
        completed = json.loads(websocket_one.receive_text())
        assert completed["type"] == "response.completed"

        with client.websocket_connect(
            "/v1/responses",
            headers={"x-codex-turn-state": turn_state},
        ) as websocket_two:
            websocket_two.send_text(
                json.dumps(
                    {
                        "type": "response.create",
                        "previous_response_id": "resp_commit_early_1",
                        "input": [{"type": "message", "id": "msg_2"}],
                    }
                )
            )
            next_completed = json.loads(websocket_two.receive_text())

        release_done.set()

    assert next_completed["type"] == "response.completed"
    assert len(transport.requests) == 2
    assert transport.requests[1]["json"]["previous_response_id"] == "resp_commit_early_1"


def test_openai_responses_websocket_accepts_same_socket_next_turn_after_terminal_commit_before_upstream_done() -> (
    None
):
    request_count = 0
    release_done = Event()
    stream_finished = Event()

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        nonlocal request_count
        request_count += 1
        payload = json.loads(body)
        if request_count == 1:
            assert "previous_response_id" not in payload
            return httpx.Response(
                200,
                headers={"content-type": "text/event-stream"},
                stream=GatedAsyncByteStream(
                    [
                        (
                            "data: "
                            + json.dumps(
                                {
                                    "type": "response.completed",
                                    "response": {
                                        "id": "resp_same_socket_1",
                                        "output": payload["input"],
                                    },
                                },
                                ensure_ascii=False,
                            )
                            + "\n\n"
                        ).encode("utf-8"),
                        b"data: [DONE]\n\n",
                    ],
                    release_event=release_done,
                    finished_event=stream_finished,
                ),
            )
        assert payload["previous_response_id"] == "resp_same_socket_1"
        assert payload["input"] == [{"type": "message", "id": "msg_2"}]
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(
                [
                    (
                        "data: "
                        + json.dumps(
                            {
                                "type": "response.completed",
                                "response": {
                                    "id": "resp_same_socket_2",
                                    "output": payload["input"],
                                },
                            },
                            ensure_ascii=False,
                        )
                        + "\n\n"
                    ).encode("utf-8"),
                    b"data: [DONE]\n\n",
                ]
            ),
        )

    client, transport = build_test_client(handler)

    with client.websocket_connect("/v1/responses") as websocket:
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "model": "gpt-4.1",
                    "input": [{"type": "message", "id": "msg_1"}],
                }
            )
        )
        first_completed = json.loads(websocket.receive_text())
        assert first_completed["type"] == "response.completed"

        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "previous_response_id": "resp_same_socket_1",
                    "input": [{"type": "message", "id": "msg_2"}],
                }
            )
        )
        release_done.set()
        second_completed = json.loads(websocket.receive_text())
        assert stream_finished.wait(timeout=1.0)

    assert second_completed["type"] == "response.completed"
    assert len(transport.requests) == 2
    assert transport.requests[1]["json"]["previous_response_id"] == "resp_same_socket_1"


def test_openai_responses_websocket_rejects_same_turn_collision() -> None:
    release_stream = Event()

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=GatedAsyncByteStream(
                [
                    (
                        "data: "
                        + json.dumps(
                            {"type": "response.output_text.delta", "delta": "partial"},
                            ensure_ascii=False,
                        )
                        + "\n\n"
                    ).encode("utf-8"),
                    (
                        "data: "
                        + json.dumps(
                            {
                                "type": "response.completed",
                                "response": {"id": "resp_collision", "output": payload["input"]},
                            },
                            ensure_ascii=False,
                        )
                        + "\n\n"
                    ).encode("utf-8"),
                ],
                release_event=release_stream,
            ),
        )

    client, transport = build_test_client(handler)
    turn_state = "turn-collision-1"

    with client.websocket_connect(
        "/v1/responses",
        headers={"x-codex-turn-state": turn_state},
    ) as websocket_one:
        websocket_one.send_text(json.dumps({"type": "response.create", "model": "gpt-4.1"}))
        first_message = json.loads(websocket_one.receive_text())
        assert first_message["type"] == "response.output_text.delta"

        with client.websocket_connect(
            "/v1/responses",
            headers={"x-codex-turn-state": turn_state},
        ) as websocket_two:
            websocket_two.send_text(json.dumps({"type": "response.create", "model": "gpt-4.1"}))
            collision = json.loads(websocket_two.receive_text())
            websocket_two.close()
            release_stream.set()

    assert collision["type"] == "error"
    assert collision["status"] == 409
    assert collision["error"]["type"] == "invalid_websocket_turn"
    assert len(transport.requests) == 1


def test_openai_responses_websocket_rejects_same_socket_pipelined_turn() -> None:
    release_stream = Event()

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=GatedAsyncByteStream(
                [
                    (
                        "data: "
                        + json.dumps(
                            {"type": "response.output_text.delta", "delta": "partial"},
                            ensure_ascii=False,
                        )
                        + "\n\n"
                    ).encode("utf-8"),
                    (
                        "data: "
                        + json.dumps(
                            {
                                "type": "response.completed",
                                "response": {"id": "resp_pipe", "output": payload["input"]},
                            },
                            ensure_ascii=False,
                        )
                        + "\n\n"
                    ).encode("utf-8"),
                    b"data: [DONE]\n\n",
                ],
                release_event=release_stream,
            ),
        )

    client, transport = build_test_client(handler)

    with client.websocket_connect("/v1/responses") as websocket:
        websocket.send_text(json.dumps({"type": "response.create", "model": "gpt-4.1"}))
        first_message = json.loads(websocket.receive_text())
        assert first_message["type"] == "response.output_text.delta"

        websocket.send_text(json.dumps({"type": "response.create", "model": "gpt-4.1"}))
        release_stream.set()

        completed = json.loads(websocket.receive_text())
        collision = json.loads(websocket.receive_text())

    assert completed["type"] == "response.completed"
    assert collision["type"] == "error"
    assert collision["status"] == 409
    assert collision["error"]["type"] == "invalid_websocket_turn"
    assert len(transport.requests) == 1


def test_openai_responses_websocket_rejects_collision_when_upstream_closes_without_terminal() -> (
    None
):
    release_stream = Event()

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=GatedAsyncByteStream(
                [
                    (
                        "data: "
                        + json.dumps(
                            {"type": "response.output_text.delta", "delta": "partial"},
                            ensure_ascii=False,
                        )
                        + "\n\n"
                    ).encode("utf-8"),
                    b"",
                ],
                release_event=release_stream,
            ),
        )

    client, transport = build_test_client(handler)

    with client.websocket_connect("/v1/responses") as websocket:
        websocket.send_text(json.dumps({"type": "response.create", "model": "gpt-4.1"}))
        delta = json.loads(websocket.receive_text())
        assert delta["type"] == "response.output_text.delta"

        websocket.send_text(json.dumps({"type": "response.create", "model": "gpt-4.1"}))
        release_stream.set()
        collision = json.loads(websocket.receive_text())

    assert collision["type"] == "error"
    assert collision["status"] == 409
    assert collision["error"]["type"] == "invalid_websocket_turn"
    assert len(transport.requests) == 1


def test_openai_responses_websocket_rejects_same_socket_turn_arriving_during_terminal_send(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    terminal_send_started = Event()
    release_terminal_send = Event()
    original_send_text = WebSocket.send_text

    async def gated_send_text(self: WebSocket, data: str) -> None:
        payload = json.loads(data)
        if payload.get("type") == "response.completed" and not terminal_send_started.is_set():
            terminal_send_started.set()
            await asyncio.to_thread(release_terminal_send.wait)
        await original_send_text(self, data)

    monkeypatch.setattr(WebSocket, "send_text", gated_send_text)

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(
                [
                    (
                        "data: "
                        + json.dumps(
                            {
                                "type": "response.completed",
                                "response": {
                                    "id": "resp_terminal_race",
                                    "output": payload["input"],
                                },
                            },
                            ensure_ascii=False,
                        )
                        + "\n\n"
                    ).encode("utf-8"),
                    b"data: [DONE]\n\n",
                ]
            ),
        )

    client, transport = build_test_client(handler)

    with client.websocket_connect("/v1/responses") as websocket:
        websocket.send_text(json.dumps({"type": "response.create", "model": "gpt-4.1"}))
        assert terminal_send_started.wait(timeout=1.0)

        websocket.send_text(json.dumps({"type": "response.create", "model": "gpt-4.1"}))
        release_terminal_send.set()

        completed = json.loads(websocket.receive_text())
        collision = json.loads(websocket.receive_text())

    assert completed["type"] == "response.completed"
    assert collision["type"] == "error"
    assert collision["status"] == 409
    assert collision["error"]["type"] == "invalid_websocket_turn"
    assert len(transport.requests) == 1


def test_openai_responses_websocket_invalid_event_does_not_poison_socket() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        chunks = [
            (
                "data: "
                + json.dumps(
                    {
                        "type": "response.completed",
                        "response": {"id": "resp_3", "output": payload["input"]},
                    },
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            b"data: [DONE]\n\n",
        ]
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(chunks),
        )

    client, transport = build_test_client(handler)

    with client.websocket_connect("/v1/responses") as websocket:
        websocket.send_text(json.dumps({"type": "nope"}))
        error = json.loads(websocket.receive_text())
        websocket.send_text(json.dumps({"type": "response.create", "model": "gpt-4.1"}))
        completed = json.loads(websocket.receive_text())

    assert error["type"] == "error"
    assert error["status"] == 400
    assert error["error"]["type"] == "invalid_websocket_request"
    assert completed["type"] == "response.completed"
    assert len(transport.requests) == 1


def test_openai_responses_websocket_rejects_mismatched_previous_response_id() -> None:
    client, _ = build_test_client(
        lambda request, body: httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(
                [
                    (
                        "data: "
                        + json.dumps(
                            {
                                "type": "response.completed",
                                "response": {"id": "resp_1", "output": []},
                            }
                        )
                        + "\n\n"
                    ).encode("utf-8"),
                    b"data: [DONE]\n\n",
                ]
            ),
        )
    )

    with client.websocket_connect("/v1/responses") as websocket:
        websocket.send_text(json.dumps({"type": "response.create", "model": "gpt-4.1"}))
        json.loads(websocket.receive_text())
        websocket.send_text(
            json.dumps(
                {
                    "type": "response.create",
                    "previous_response_id": "resp_other",
                    "input": [],
                }
            )
        )
        error = json.loads(websocket.receive_text())

    assert error["type"] == "error"
    assert error["status"] == 409
    assert error["error"]["type"] == "invalid_websocket_turn"


def test_openai_responses_websocket_rejects_binary_frames() -> None:
    client, _ = build_test_client(
        lambda request, body: httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream([]),
        )
    )

    with client.websocket_connect("/v1/responses") as websocket:
        websocket.send_bytes(b'{"type":"response.create","model":"gpt-4.1"}')
        error = json.loads(websocket.receive_text())
        assert error["type"] == "error"
        assert error["status"] == 400
        assert error["error"]["type"] == "invalid_websocket_frame"
        with pytest.raises(WebSocketDisconnect):
            websocket.receive_text()


def test_openai_responses_websocket_reports_missing_completed_event() -> None:
    client, _ = build_test_client(
        lambda request, body: httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(
                [
                    (
                        "data: "
                        + json.dumps({"type": "response.output_text.delta", "delta": "partial"})
                        + "\n\n"
                    ).encode("utf-8"),
                    b"data: [DONE]\n\n",
                ]
            ),
        )
    )

    with client.websocket_connect("/v1/responses") as websocket:
        websocket.send_text(json.dumps({"type": "response.create", "model": "gpt-4.1"}))
        delta = json.loads(websocket.receive_text())
        error = json.loads(websocket.receive_text())

    assert delta["type"] == "response.output_text.delta"
    assert error["type"] == "error"
    assert error["status"] == 408
    assert error["error"]["type"] == "upstream_error"
