from __future__ import annotations

import json
import time
from pathlib import Path

import httpx
from fastapi.testclient import TestClient

from stronk_mask.admin.apply import ApplyJob
from stronk_mask.admin_app import create_app
from tests.helpers import (
    RecordingTransport,
    build_admin_client,
    build_admin_settings,
    build_bundle_root,
    build_models_transport,
    login_admin,
    write_json,
)

FORBIDDEN_TOKENS = ("panel-github-repository", "github.com/", "router-for-me")


def wait_for_job(
    client: TestClient,
    job_id: str,
    *,
    max_attempts: int = 200,
    delay_seconds: float = 0.01,
) -> dict[str, object]:
    for _ in range(max_attempts):
        payload = client.get(f"/api/apply/{job_id}").json()
        if payload["status"] != "running":
            return payload
        time.sleep(delay_seconds)
    raise AssertionError(f"job {job_id} did not finish")


def test_operator_state_crud_writes_draft_only(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(tmp_path / "bundle")
    client = build_admin_client(
        bundle_root,
        tmp_path / "audit.sqlite3",
        outbound_transport=build_models_transport(
            model_ids=["gpt-4.1-mini"],
            expected_bearer="provider-secret",
        ),
        host_resolver=lambda hostname: ["8.8.8.8"],
    )
    login_admin(client)

    create_provider = client.post(
        "/api/providers",
        json={
            "label": "OpenAI Production",
            "kind": "openai_compat",
            "base_url": "https://api.openai.com/v1",
            "secret_ref": "PROVIDER_DEFAULT_API_KEY",
        },
        headers={"Origin": "http://testserver"},
    )
    assert create_provider.status_code == 201
    provider_id = create_provider.json()["id"]

    create_model = client.post(
        f"/api/providers/{provider_id}/models",
        json={
            "upstream_id": "gpt-4.1-mini",
            "public_alias": "stronk-lm",
            "privacy_policy_id": "default-openai-chat",
        },
        headers={"Origin": "http://testserver"},
    )
    assert create_model.status_code == 201

    operator_state = client.get("/api/operator-state")
    assert operator_state.status_code == 200
    assert operator_state.json()["providers"][0]["id"] == "openai-production"

    active_payload = json.loads((bundle_root / "config" / "operator-objects.json").read_text(encoding="utf-8"))
    draft_payload = json.loads((bundle_root / "config" / "operator-objects.draft.json").read_text(encoding="utf-8"))
    assert active_payload["providers"] == []
    assert draft_payload["providers"][0]["models"][0]["public_alias"] == "stronk-lm"


def test_operator_state_loads_fake_openai_upstream_base_url(tmp_path: Path) -> None:
    initial_state = {
        "schema_version": "stronk.operator-state/v2",
        "providers": [
            {
                "id": "openai-compat-provider",
                "label": "OpenAI-compatible provider",
                "kind": "openai_compat",
                "base_url": "http://fake-openai-upstream:18080/v1",
                "secret_ref": "PROVIDER_DEFAULT_API_KEY",
                "cliproxy_provider_name": "openai-compat-provider",
                "models": [],
            }
        ],
        "privacy_policies": [
            {
                "id": "default-openai-chat",
                "presidio_required": True,
                "spacy_required": True,
                "fail_closed_detector_types": ["api_key", "bearer_token", "jwt"],
            }
        ],
    }
    bundle_root = build_bundle_root(tmp_path / "bundle", operator_state=initial_state)
    client = build_admin_client(bundle_root, tmp_path / "audit.sqlite3")
    login_admin(client)

    operator_state = client.get("/api/operator-state")

    assert operator_state.status_code == 200
    assert operator_state.json()["providers"][0]["base_url"] == (
        "http://fake-openai-upstream:18080/v1"
    )


def test_create_provider_verifies_before_writing_draft(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(tmp_path / "bundle")

    async def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        del body
        if request.url.host == "api.openai.com" and request.url.path == "/v1/models":
            return httpx.Response(503, request=request, json={"error": "upstream unavailable"})
        return httpx.Response(404, request=request, json={"error": "not found"})

    client = build_admin_client(
        bundle_root,
        tmp_path / "audit.sqlite3",
        outbound_transport=RecordingTransport(handler),
        host_resolver=lambda hostname: ["8.8.8.8"],
    )
    login_admin(client)

    response = client.post(
        "/api/providers",
        json={
            "label": "OpenAI Production",
            "kind": "openai_compat",
            "base_url": "https://api.openai.com/v1",
            "secret_ref": "PROVIDER_DEFAULT_API_KEY",
        },
        headers={"Origin": "http://testserver"},
    )

    assert response.status_code == 400
    assert client.get("/api/operator-state").json()["providers"] == []
    assert not (bundle_root / "config" / "operator-objects.draft.json").exists()


def test_update_provider_verifies_before_writing_draft(tmp_path: Path) -> None:
    initial_state = {
        "schema_version": "stronk.operator-state/v2",
        "providers": [
            {
                "id": "old-provider",
                "label": "Old Provider",
                "kind": "openai_compat",
                "base_url": "https://api.openai.com/v1",
                "secret_ref": "PROVIDER_DEFAULT_API_KEY",
                "cliproxy_provider_name": "old-provider",
                "models": [],
            }
        ],
        "privacy_policies": [
            {
                "id": "default-openai-chat",
                "presidio_required": True,
                "spacy_required": True,
                "fail_closed_detector_types": ["api_key", "bearer_token", "jwt"],
            }
        ],
    }
    bundle_root = build_bundle_root(tmp_path / "bundle", operator_state=initial_state)

    async def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        del body
        if request.url.host == "api.openai.com" and request.url.path == "/v1/models":
            return httpx.Response(503, request=request, json={"error": "upstream unavailable"})
        return httpx.Response(404, request=request, json={"error": "not found"})

    client = build_admin_client(
        bundle_root,
        tmp_path / "audit.sqlite3",
        outbound_transport=RecordingTransport(handler),
        host_resolver=lambda hostname: ["8.8.8.8"],
    )
    login_admin(client)

    response = client.put(
        "/api/providers/old-provider",
        json={"label": "Old Provider Prime"},
        headers={"Origin": "http://testserver"},
    )

    assert response.status_code == 400
    assert client.get("/api/operator-state").json()["providers"][0]["label"] == "Old Provider"
    assert not (bundle_root / "config" / "operator-objects.draft.json").exists()


def test_write_routes_require_same_origin_and_admin_role(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(tmp_path / "bundle")
    cross_origin_client = build_admin_client(
        bundle_root,
        tmp_path / "audit-cross.sqlite3",
        host_resolver=lambda hostname: ["8.8.8.8"],
    )
    login_admin(cross_origin_client)
    cross_origin = cross_origin_client.post(
        "/api/providers",
        json={
            "label": "OpenAI Production",
            "kind": "openai_compat",
            "base_url": "https://api.openai.com/v1",
            "secret_ref": "PROVIDER_DEFAULT_API_KEY",
        },
        headers={"Origin": "https://evil.example"},
    )
    assert cross_origin.status_code == 403

    operator_settings = build_admin_settings(
        bundle_root,
        tmp_path / "audit-operator.sqlite3",
        admin_bootstrap_roles="operator",
    )

    with TestClient(
        create_app(settings=operator_settings, host_resolver=lambda hostname: ["8.8.8.8"]),
        base_url="http://testserver",
    ) as operator_only:
        login_admin(operator_only)
        response = operator_only.post(
            "/api/providers",
            json={
                "label": "OpenAI Production",
                "kind": "openai_compat",
                "base_url": "https://api.openai.com/v1",
                "secret_ref": "PROVIDER_DEFAULT_API_KEY",
            },
            headers={"Origin": "http://testserver"},
        )
    assert response.status_code == 403


def test_provider_test_discover_apply_and_concurrent_apply(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(tmp_path / "bundle")
    healthcheck_ready = {"aliases": ["stronk-lm"]}

    async def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        del body
        if request.url.host == "api.openai.com" and request.url.path == "/v1/models":
            assert request.headers.get("authorization") == "Bearer provider-secret"
            return httpx.Response(
                200,
                request=request,
                json={"data": [{"id": "gpt-4.1-mini", "object": "model"}]},
            )
        if request.url.host == "gateway.test" and request.url.path == "/v1/models":
            assert request.headers.get("authorization") == "Bearer stronk-public-key"
            return httpx.Response(
                200,
                request=request,
                json={
                    "data": [
                        {"id": alias, "object": "model"} for alias in healthcheck_ready["aliases"]
                    ]
                },
            )
        return httpx.Response(404, request=request, json={"error": "not found"})

    client = build_admin_client(
        bundle_root,
        tmp_path / "audit.sqlite3",
        outbound_transport=RecordingTransport(handler),
        host_resolver=lambda hostname: ["8.8.8.8"],
    )
    login_admin(client)

    provider_response = client.post(
        "/api/providers",
        json={
            "label": "OpenAI Production",
            "kind": "openai_compat",
            "base_url": "https://api.openai.com/v1",
            "secret_ref": "PROVIDER_DEFAULT_API_KEY",
        },
        headers={"Origin": "http://testserver"},
    )
    provider_id = provider_response.json()["id"]
    model_response = client.post(
        f"/api/providers/{provider_id}/models",
        json={
            "upstream_id": "gpt-4.1-mini",
            "public_alias": "stronk-lm",
            "privacy_policy_id": "default-openai-chat",
        },
        headers={"Origin": "http://testserver"},
    )
    assert model_response.status_code == 201

    test_response = client.post(
        f"/api/providers/{provider_id}/test",
        json={},
        headers={"Origin": "http://testserver"},
    )
    discover_response = client.post(
        f"/api/providers/{provider_id}/discover",
        json={},
        headers={"Origin": "http://testserver"},
    )
    assert test_response.json()["ok"] is True
    assert discover_response.json()["models"][0]["id"] == "gpt-4.1-mini"
    write_json(
        bundle_root / "generated" / "doctor-report.json",
        {
            "checks": [
                {
                    "name": "legacy-panel",
                    "status": "pass",
                    "message": "panel-github-repository https://github.com/router-for-me/private",
                    "evidence_ref": "https://github.com/router-for-me/private",
                }
            ],
            "private_surface_posture": "private_only",
            "bundle_version": "stronk-gateway.bundle/v1alpha1",
            "image_pins": {
                "stronk-mask": "ghcr.io/eyycheev/stronk-mask@sha256:test",
            },
        },
    )

    manager = client.app.state.apply_manager
    manager._jobs["apply-running"] = ApplyJob(job_id="apply-running")
    manager._active_job_id = "apply-running"
    second_apply = client.post("/api/apply", json={}, headers={"Origin": "http://testserver"})
    assert second_apply.status_code == 409
    manager._active_job_id = None
    manager._jobs.pop("apply-running", None)

    apply_response = client.post("/api/apply", json={}, headers={"Origin": "http://testserver"})
    assert apply_response.status_code == 200

    job_id = apply_response.json()["job_id"]
    final_payload = wait_for_job(client, job_id, max_attempts=900, delay_seconds=0.01)
    assert final_payload["status"] == "success"
    cliproxy_config = (bundle_root / "generated" / "cliproxy-config.yaml").read_text(
        encoding="utf-8"
    )
    assert cliproxy_config
    assert "panel-github-repository" not in cliproxy_config
    system_payload = client.get("/api/system").json()
    for token in FORBIDDEN_TOKENS:
        assert token not in json.dumps(system_payload)
    doctor_report = (bundle_root / "generated" / "doctor-report.json").read_text(encoding="utf-8")
    for token in FORBIDDEN_TOKENS:
        assert token not in doctor_report


def test_local_smoke_allowlist_enables_fake_upstream_create_test_and_discover(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(tmp_path / "bundle")
    (bundle_root / "config" / "ssrf-allowlist.json").write_text(
        json.dumps(["fake-openai-upstream"]) + "\n",
        encoding="utf-8",
    )

    async def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        del body
        if request.url.host == "fake-openai-upstream" and request.url.path == "/v1/models":
            assert request.headers.get("authorization") == "Bearer provider-secret"
            return httpx.Response(
                200,
                request=request,
                json={"data": [{"id": "gpt-4.1-mini", "object": "model"}]},
            )
        return httpx.Response(404, request=request, json={"error": "not found"})

    client = build_admin_client(
        bundle_root,
        tmp_path / "audit.sqlite3",
        allow_insecure_upstreams=True,
        outbound_transport=RecordingTransport(handler),
        host_resolver=lambda hostname: ["172.18.0.10"],
    )
    login_admin(client)

    provider_response = client.post(
        "/api/providers",
        json={
            "label": "Local Smoke OpenAI",
            "kind": "openai_compat",
            "base_url": "http://fake-openai-upstream:18080/v1",
            "secret_ref": "PROVIDER_DEFAULT_API_KEY",
        },
        headers={"Origin": "http://testserver"},
    )
    assert provider_response.status_code == 201
    provider_id = provider_response.json()["id"]

    test_response = client.post(
        f"/api/providers/{provider_id}/test",
        json={},
        headers={"Origin": "http://testserver"},
    )
    discover_response = client.post(
        f"/api/providers/{provider_id}/discover",
        json={},
        headers={"Origin": "http://testserver"},
    )

    assert test_response.status_code == 200
    assert test_response.json()["ok"] is True
    assert discover_response.status_code == 200
    assert discover_response.json()["models"][0]["id"] == "gpt-4.1-mini"


def test_apply_failure_rolls_back_active_config(tmp_path: Path) -> None:
    initial_state = {
        "schema_version": "stronk.operator-state/v2",
        "providers": [
            {
                "id": "old-provider",
                "label": "Old Provider",
                "kind": "openai_compat",
                "base_url": "https://api.openai.com/v1",
                "secret_ref": "PROVIDER_DEFAULT_API_KEY",
                "cliproxy_provider_name": "old-provider",
                "models": [
                    {
                        "upstream_id": "gpt-4.1-mini",
                        "public_alias": "old-model",
                        "privacy_policy_id": "default-openai-chat",
                        "enabled": True,
                    }
                ],
            }
        ],
        "privacy_policies": [
            {
                "id": "default-openai-chat",
                "presidio_required": True,
                "spacy_required": True,
                "fail_closed_detector_types": ["api_key", "bearer_token", "jwt"],
            }
        ],
    }
    bundle_root = build_bundle_root(tmp_path / "bundle", operator_state=initial_state)
    (bundle_root / "secrets" / "PROVIDER_ROTATED_API_KEY").write_text("rotated-secret\n", encoding="utf-8")
    (bundle_root / "secrets" / "PROVIDER_ROTATED_API_KEY").chmod(0o600)
    env_before_apply = (bundle_root / ".env").read_text(encoding="utf-8")
    restart_calls: list[str] = []

    async def restart_hook() -> None:
        restart_calls.append("restart")

    async def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        del body
        if request.url.host == "gateway.test" and request.url.path == "/v1/models":
            return httpx.Response(
                200,
                request=request,
                json={"data": [{"id": "old-model", "object": "model"}]},
            )
        return httpx.Response(
            200,
            request=request,
            json={"data": [{"id": "gpt-4.1-mini", "object": "model"}]},
        )

    client = build_admin_client(
        bundle_root,
        tmp_path / "audit.sqlite3",
        outbound_transport=RecordingTransport(handler),
        host_resolver=lambda hostname: ["8.8.8.8"],
        restart_hook=restart_hook,
    )
    login_admin(client)

    provider_update = client.put(
        "/api/providers/old-provider",
        json={"secret_ref": "PROVIDER_ROTATED_API_KEY"},
        headers={"Origin": "http://testserver"},
    )
    assert provider_update.status_code == 200
    update_response = client.put(
        "/api/providers/old-provider/models/gpt-4.1-mini",
        json={"public_alias": "new-model"},
        headers={"Origin": "http://testserver"},
    )
    assert update_response.status_code == 200
    apply_response = client.post("/api/apply", json={}, headers={"Origin": "http://testserver"})
    job_id = apply_response.json()["job_id"]

    final_payload = wait_for_job(client, job_id, max_attempts=900, delay_seconds=0.01)
    assert final_payload["status"] == "failed"
    assert restart_calls == ["restart", "restart"]
    active_payload = json.loads((bundle_root / "config" / "operator-objects.json").read_text(encoding="utf-8"))
    assert active_payload["providers"][0]["models"][0]["public_alias"] == "old-model"
    assert (bundle_root / ".env").read_text(encoding="utf-8") == env_before_apply


def test_manual_rollback_endpoint_restarts_restored_runtime(tmp_path: Path) -> None:
    initial_state = {
        "schema_version": "stronk.operator-state/v2",
        "providers": [
            {
                "id": "old-provider",
                "label": "Old Provider",
                "kind": "openai_compat",
                "base_url": "https://api.openai.com/v1",
                "secret_ref": "PROVIDER_DEFAULT_API_KEY",
                "cliproxy_provider_name": "old-provider",
                "models": [
                    {
                        "upstream_id": "gpt-4.1-mini",
                        "public_alias": "old-model",
                        "privacy_policy_id": "default-openai-chat",
                        "enabled": True,
                    }
                ],
            }
        ],
        "privacy_policies": [
            {
                "id": "default-openai-chat",
                "presidio_required": True,
                "spacy_required": True,
                "fail_closed_detector_types": ["api_key", "bearer_token", "jwt"],
            }
        ],
    }
    bundle_root = build_bundle_root(tmp_path / "bundle", operator_state=initial_state)
    write_json(
        bundle_root / "generated" / "doctor-report.json",
        {
            "checks": [
                {
                    "name": "legacy-panel",
                    "status": "pass",
                    "message": "panel-github-repository https://github.com/router-for-me/private",
                    "evidence_ref": None,
                }
            ],
            "private_surface_posture": "private_only",
        },
    )
    (bundle_root / "generated" / "cliproxy-config.yaml").write_text(
        "panel-github-repository: https://github.com/router-for-me/private\n",
        encoding="utf-8",
    )
    restart_calls: list[str] = []
    served_aliases = {"value": ["new-model"]}

    async def restart_hook() -> None:
        restart_calls.append("restart")
        active_payload = json.loads((bundle_root / "config" / "operator-objects.json").read_text(encoding="utf-8"))
        served_aliases["value"] = [
            active_payload["providers"][0]["models"][0]["public_alias"]
        ]

    async def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        del body
        if request.url.host == "gateway.test" and request.url.path == "/v1/models":
            return httpx.Response(
                200,
                request=request,
                json={
                    "data": [
                        {"id": alias, "object": "model"} for alias in served_aliases["value"]
                    ]
                },
            )
        return httpx.Response(
            200,
            request=request,
            json={"data": [{"id": "gpt-4.1-mini", "object": "model"}]},
        )

    client = build_admin_client(
        bundle_root,
        tmp_path / "audit.sqlite3",
        outbound_transport=RecordingTransport(handler),
        host_resolver=lambda hostname: ["8.8.8.8"],
        restart_hook=restart_hook,
    )
    login_admin(client)

    update_response = client.put(
        "/api/providers/old-provider/models/gpt-4.1-mini",
        json={"public_alias": "new-model"},
        headers={"Origin": "http://testserver"},
    )
    assert update_response.status_code == 200

    apply_response = client.post("/api/apply", json={}, headers={"Origin": "http://testserver"})
    job_id = apply_response.json()["job_id"]
    final_payload = wait_for_job(client, job_id, max_attempts=900, delay_seconds=0.01)
    assert final_payload["status"] == "success"
    assert restart_calls == []

    rollback_response = client.post(
        f"/api/apply/{job_id}/rollback",
        json={},
        headers={"Origin": "http://testserver"},
    )
    assert rollback_response.status_code == 200
    assert rollback_response.json()["status"] == "rolled_back"
    assert restart_calls == ["restart"]
    restored_active = json.loads((bundle_root / "config" / "operator-objects.json").read_text(encoding="utf-8"))
    assert restored_active["providers"][0]["models"][0]["public_alias"] == "old-model"
    for relative_path in (
        "generated/cliproxy-config.yaml",
        "generated/materialization-summary.json",
        "generated/hermes-connect.json",
        "generated/doctor-report.json",
    ):
        artifact_text = (bundle_root / relative_path).read_text(encoding="utf-8")
        for token in FORBIDDEN_TOKENS:
            assert token not in artifact_text, f"{token!r} leaked via {relative_path}"
