from __future__ import annotations

import json

import httpx
import pytest

from tests.helpers import build_test_client, contains_placeholder


def test_openai_models_uses_dedicated_openai_shape_and_filters_caller_user_agent() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        assert request.method == "GET"
        assert body == b""
        return httpx.Response(
            200,
            json={
                "object": "list",
                "data": [
                    {
                        "id": "gpt-4.1-mini",
                        "object": "model",
                        "created": 1770000000,
                        "owned_by": "openai",
                    }
                ],
            },
            headers={"content-type": "application/json", "x-request-id": "req-models-1"},
        )

    client, transport = build_test_client(handler)

    response = client.get(
        "/v1/models",
        headers={
            "Authorization": "Bearer upstream-token",
            "User-Agent": "claude-cli/1.2.3",
            "Cookie": "session=1",
            "X-Request-ID": "req-public-1",
        },
    )

    assert response.status_code == 200
    assert response.json()["object"] == "list"
    assert response.json()["data"][0]["id"] == "gpt-4.1-mini"
    assert transport.requests[0]["method"] == "GET"
    assert transport.requests[0]["url"] == "http://openai.test/v1/models"
    upstream_headers = {key.lower(): value for key, value in transport.requests[0]["headers"].items()}
    assert upstream_headers["authorization"] == "Bearer upstream-token"
    assert upstream_headers["x-request-id"] == "req-public-1"
    assert upstream_headers.get("cookie") is None
    assert not upstream_headers.get("user-agent", "").startswith("claude-cli")


def test_openai_models_preserves_auth_failures_from_the_backplane() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        assert request.method == "GET"
        assert body == b""
        return httpx.Response(
            401,
            json={
                "error": {
                    "message": "invalid api key",
                    "type": "invalid_request_error",
                    "code": "invalid_api_key",
                }
            },
            headers={"content-type": "application/json"},
        )

    client, _ = build_test_client(handler)

    response = client.get("/v1/models")

    assert response.status_code == 401
    assert response.json()["error"]["code"] == "invalid_api_key"


def test_openai_models_returns_openai_error_shape_on_upstream_failure() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        raise httpx.ConnectError("boom", request=request)

    client, transport = build_test_client(handler)

    response = client.get(
        "/v1/models",
        headers={"Authorization": "Bearer upstream-token"},
    )

    assert response.status_code == 502
    assert response.json()["error"]["type"] == "privacy_policy_error"
    assert transport.requests[0]["url"] == "http://openai.test/v1/models"


def test_canonical_openai_chat_completions_route_masks_and_rehydrates() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["messages"][0]["content"]
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-v1-1",
                "object": "chat.completion",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": f"Echo: {masked_text}"},
                        "finish_reason": "stop",
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    client, transport = build_test_client(handler)
    original = "Please contact Alice Johnson at alice@example.com"

    response = client.post(
        "/v1/chat/completions",
        json={"model": "gpt-4.1", "messages": [{"role": "user", "content": original}]},
        headers={"Authorization": "Bearer upstream-token"},
    )

    assert response.status_code == 200
    upstream_body = transport.requests[0]["body"].decode("utf-8")
    assert "Alice Johnson" not in upstream_body
    assert "alice@example.com" not in upstream_body
    assert contains_placeholder(upstream_body)
    assert response.json()["choices"][0]["message"]["content"] == f"Echo: {original}"


def test_canonical_openai_responses_route_masks_and_rehydrates() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["input"][0]["content"][0]["text"]
        return httpx.Response(
            200,
            json={
                "id": "resp-v1-1",
                "output": [
                    {
                        "type": "message",
                        "content": [{"type": "output_text", "text": masked_text}],
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    client, transport = build_test_client(handler)
    original = "Please contact Alice Johnson at alice@example.com"

    response = client.post(
        "/v1/responses",
        json={
            "model": "gpt-4.1",
            "input": [{"role": "user", "content": [{"type": "input_text", "text": original}]}],
        },
        headers={"Authorization": "Bearer upstream-token"},
    )

    assert response.status_code == 200
    upstream_body = transport.requests[0]["body"].decode("utf-8")
    assert "Alice Johnson" not in upstream_body
    assert "alice@example.com" not in upstream_body
    assert contains_placeholder(upstream_body)
    assert response.json()["output"][0]["content"][0]["text"] == original


@pytest.mark.parametrize(
    "path",
    [
        "/v0/management/api-keys",
        "/management.html",
        "/v1/ws",
        "/v1/completions",
        "/v1/responses/compact",
        "/v1/messages/count_tokens",
        "/v1beta/models",
        "/google/callback",
        "/iflow/callback",
        "/antigravity/callback",
        "/api/debug/traces",
    ],
)
def test_public_denylisted_surfaces_fail_closed(path: str) -> None:
    client, transport = build_test_client(
        lambda request, body: httpx.Response(200, json={"unexpected": True})
    )

    response = client.get(path)

    assert response.status_code == 404
    assert transport.requests == []


@pytest.mark.parametrize(
    ("path", "payload"),
    [
        (
            "/openai/v1/chat/completions",
            {"model": "gpt-4.1", "messages": [{"role": "user", "content": "hello"}]},
        ),
        (
            "/openai/v1/responses",
            {
                "model": "gpt-4.1",
                "input": [{"role": "user", "content": [{"type": "input_text", "text": "hello"}]}],
            },
        ),
    ],
)
def test_removed_legacy_openai_aliases_fail_closed(path: str, payload: dict[str, object]) -> None:
    client, transport = build_test_client(
        lambda request, body: httpx.Response(200, json={"unexpected": True})
    )

    response = client.post(path, json=payload)

    assert response.status_code == 404
    assert transport.requests == []
