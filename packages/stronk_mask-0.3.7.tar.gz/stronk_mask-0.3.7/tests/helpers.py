from __future__ import annotations

import asyncio
import inspect
import json
import re
import time
from collections.abc import Awaitable, Callable
from contextlib import contextmanager
from pathlib import Path
from typing import Any, TypeVar

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.testclient import TestClient

from stronk_mask.admin import hash_admin_password
from stronk_mask.admin_app import create_app as create_admin_app
from stronk_mask.config import Settings

PLACEHOLDER_REGEX = re.compile(r"\[\[[A-Z_]+_\d+\]\]")
T = TypeVar("T")
ADMIN_USER = "operator"
ADMIN_PASSWORD = "stronk-admin-password"


class StaticAsyncByteStream(httpx.AsyncByteStream):
    def __init__(self, chunks: list[bytes | BaseException]) -> None:
        self.chunks = chunks

    async def __aiter__(self):  # type: ignore[override]
        for chunk in self.chunks:
            if isinstance(chunk, BaseException):
                raise chunk
            yield chunk

    async def aclose(self) -> None:
        return None


Handler = Callable[[httpx.Request, bytes], httpx.Response | Awaitable[httpx.Response]]


class RecordingTransport(httpx.AsyncBaseTransport):
    def __init__(self, handler: Handler) -> None:
        self.handler = handler
        self.requests: list[dict[str, Any]] = []

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        body = await request.aread()
        self.requests.append(
            {
                "method": request.method,
                "url": str(request.url),
                "headers": dict(request.headers),
                "body": body,
                "json": json.loads(body) if body else None,
            }
        )
        response = self.handler(request, body)
        if inspect.isawaitable(response):
            return await response
        return response


def build_test_client(
    handler: Handler,
    **overrides: Any,
) -> tuple[TestClient, RecordingTransport]:
    from stronk_mask.app import create_full_app

    transport = RecordingTransport(handler)
    settings = Settings(
        openai_upstream_base_url="http://openai.test",
        anthropic_upstream_base_url="http://anthropic.test",
        allow_insecure_upstreams=True,
        allow_nonstandard_upstream_hosts=True,
        admin_auth_mode="trusted_headers",
        **overrides,
    )
    client = TestClient(create_full_app(settings=settings, upstream_transport=transport))
    return client, transport


@contextmanager
def build_runtime_clients(
    handler: Handler,
    **overrides: Any,
):
    from stronk_mask.app import build_runtime_apps

    transport = RecordingTransport(handler)
    settings = Settings(
        openai_upstream_base_url="http://openai.test",
        anthropic_upstream_base_url="http://anthropic.test",
        allow_insecure_upstreams=True,
        allow_nonstandard_upstream_hosts=True,
        admin_auth_mode="trusted_headers",
        **overrides,
    )
    runtime = build_runtime_apps(settings=settings, upstream_transport=transport)
    asyncio.run(runtime.proxy_service.startup())
    try:
        with (
            TestClient(runtime.public_app) as public_client,
            TestClient(runtime.debug_app) as debug_client,
        ):
            yield public_client, debug_client, transport
    finally:
        asyncio.run(runtime.proxy_service.shutdown())


def contains_placeholder(text: str) -> bool:
    return bool(PLACEHOLDER_REGEX.search(text))


def eventually(
    operation: Callable[[], T],
    *,
    predicate: Callable[[T], bool],
    timeout_seconds: float = 1.0,
    interval_seconds: float = 0.01,
) -> T:
    deadline = time.monotonic() + timeout_seconds
    result = operation()
    while not predicate(result):
        if time.monotonic() >= deadline:
            break
        time.sleep(interval_seconds)
        result = operation()
    return result


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def build_bundle_root(
    root: Path,
    *,
    operator_state: dict[str, object] | None = None,
    env_values: dict[str, str] | None = None,
    create_secrets_dir: bool = True,
) -> Path:
    config_dir = root / "config"
    generated_dir = root / "generated"
    config_dir.mkdir(parents=True, exist_ok=True)
    generated_dir.mkdir(parents=True, exist_ok=True)
    if create_secrets_dir:
        (root / "secrets").mkdir(parents=True, exist_ok=True)
    write_json(
        config_dir / "operator-objects.json",
        operator_state
        or {
            "schema_version": "stronk.operator-state/v2",
            "providers": [],
            "privacy_policies": [
                {
                    "id": "default-openai-chat",
                    "presidio_required": True,
                    "spacy_required": True,
                    "fail_closed_detector_types": ["api_key", "bearer_token", "jwt"],
                }
            ],
        },
    )
    rendered_env = "".join(
        f"{key}={value}\n"
        for key, value in sorted(
            (env_values or {
                "STRONK_GATEWAY_PUBLIC_HTTP_PORT": "54321",
                "STRONK_GATEWAY_PUBLIC_BASE_URL": "http://gateway.test/v1",
                "STRONK_GATEWAY_PUBLIC_API_KEY": "stronk-public-key",
                "PROVIDER_DEFAULT_API_KEY": "provider-secret",
            }).items()
        )
    )
    (root / ".env").write_text(rendered_env, encoding="utf-8")
    return root


def build_admin_settings(
    bundle_root: Path,
    db_path: Path,
    **overrides: object,
) -> Settings:
    settings_kwargs: dict[str, object] = {
        "openai_upstream_base_url": "http://openai.test",
        "anthropic_upstream_base_url": "http://anthropic.test",
        "allow_insecure_upstreams": True,
        "allow_nonstandard_upstream_hosts": True,
        "audit_storage_enabled": True,
        "audit_db_path": str(db_path),
        "enable_admin_api": True,
        "admin_auth_mode": "session",
        "admin_bootstrap_user": ADMIN_USER,
        "admin_bootstrap_password_hash": hash_admin_password(ADMIN_PASSWORD),
        "admin_config_dir": str(bundle_root / "config"),
        "admin_generated_artifacts_dir": str(bundle_root / "generated"),
    }
    settings_kwargs.update(overrides)
    return Settings(**settings_kwargs)


def build_admin_client(
    bundle_root: Path,
    db_path: Path,
    *,
    outbound_transport: httpx.AsyncBaseTransport | None = None,
    host_resolver=None,
    restart_hook=None,
    **overrides: object,
) -> TestClient:
    settings = build_admin_settings(bundle_root, db_path, **overrides)
    return TestClient(
        create_admin_app(
            settings=settings,
            outbound_transport=outbound_transport,
            host_resolver=host_resolver,
            restart_hook=restart_hook,
        ),
        base_url="http://testserver",
    )


def login_admin(
    client: TestClient,
    *,
    username: str = ADMIN_USER,
    password: str = ADMIN_PASSWORD,
    origin: str = "http://testserver",
) -> httpx.Response:
    response = client.post(
        "/api/session/login",
        json={"username": username, "password": password},
        headers={"Origin": origin},
    )
    assert response.status_code == 200
    return response


def build_models_transport(
    *,
    model_ids: list[str],
    expected_bearer: str | None = None,
    status_code: int = 200,
    redirect_location: str | None = None,
    stream_chunks: list[bytes | BaseException] | None = None,
) -> RecordingTransport:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        del body
        if expected_bearer is not None:
            assert request.headers.get("authorization") == f"Bearer {expected_bearer}"
        if redirect_location is not None:
            return httpx.Response(
                307,
                headers={"location": redirect_location},
                request=request,
            )
        if stream_chunks is not None:
            return httpx.Response(
                status_code,
                request=request,
                stream=StaticAsyncByteStream(stream_chunks),
            )
        return httpx.Response(
            status_code,
            request=request,
            json={"data": [{"id": identifier, "object": "model"} for identifier in model_ids]},
        )

    return RecordingTransport(handler)


def build_public_models_app(
    *,
    model_ids: list[str],
    expected_bearer: str,
    status_code: int = 200,
) -> FastAPI:
    app = FastAPI()

    @app.get("/v1/models")
    async def models(request: Request) -> JSONResponse:
        if request.headers.get("authorization") != f"Bearer {expected_bearer}":
            return JSONResponse(status_code=401, content={"error": "unauthorized"})
        return JSONResponse(
            status_code=status_code,
            content={"data": [{"id": identifier, "object": "model"} for identifier in model_ids]},
        )

    return app
