#!/usr/bin/env python3
# ruff: noqa: E402, E501
from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
import threading
import time
from collections import Counter, deque
from collections.abc import Callable
from contextlib import suppress
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

SCRIPT_PATH = Path(__file__).resolve()
REPO_ROOT = SCRIPT_PATH.parents[1]
SRC_DIR = REPO_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

import httpx
import uvicorn
import websockets
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response, StreamingResponse
from websockets.exceptions import ConnectionClosed

from stronk_mask.admin_app import create_app as create_admin_app
from stronk_mask.app import create_app as create_proxy_app
from stronk_mask.config import Settings
from stronk_mask.proxy.debug import TRUNCATION_MARKER_PREFIX

ADMIN_PROXY_SECRET = "bench-admin-proxy-secret"
DEBUG_GATEWAY_SECRET = "bench-unsafe-debug-gateway-secret"
ADMIN_HEADERS = {
    "X-Stronk-Admin-User": "operator",
    "X-Stronk-Admin-Roles": "operator",
    "X-Stronk-Admin-Proxy-Secret": ADMIN_PROXY_SECRET,
    "X-Stronk-Unsafe-Debug-Gateway": DEBUG_GATEWAY_SECRET,
}
DEFAULT_MODEL = "gpt-4.1"
DEFAULT_CONCURRENCY = {
    "http-chat": 64,
    "http-responses": 64,
    "sse-stream": 32,
    "ws-sequential": 16,
    "ws-abuse": 16,
    "audit-contention": 64,
    "memory-bound": 16,
}
DEFAULT_DURATION_SECONDS = {
    "http-chat": 30.0,
    "http-responses": 30.0,
    "sse-stream": 30.0,
    "ws-sequential": 30.0,
    "ws-abuse": 12.0,
    "audit-contention": 30.0,
    "memory-bound": 60.0,
}
DEFAULT_WS_TURNS = 5
DEFAULT_SAMPLE_INTERVAL = 0.25
MATRIX_IDS = {
    "http-chat": "W1-http-chat",
    "http-responses": "W2-http-responses",
    "sse-stream": "W3-sse-stream",
    "ws-sequential": "W4-ws-sequential",
    "ws-abuse": "W5-ws-abuse",
    "audit-contention": "W6-audit-contention",
    "memory-bound": "W7-memory-bound",
}
BASELINE_SCENARIOS = {"http-chat", "http-responses", "sse-stream", "audit-contention"}
PLACEHOLDER_RE = re.compile(r"\[\[[A-Z_]+_\d+\]\]")
BENCH_TOKEN_RE = re.compile(r"bench-(?:http-chat|http-responses|sse-stream|ws-sequential)-\d+-\d+")
PLAINTEXT_MARKERS = (
    "Alice Johnson",
    "alice@example.com",
    "zhangsan@example.com",
    "+1 (415) 555-2671",
    "张三",
)

BENCHMARK_PROMPT = (
    "Please contact Alice Johnson at alice@example.com or +1 (415) 555-2671. "
    "中文联系人是张三，邮箱 zhangsan@example.com。"
)


def _repo_python() -> str:
    return sys.executable


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _json_dumps(data: Any, *, indent: int | None = None) -> str:
    return json.dumps(data, ensure_ascii=False, separators=None if indent else (",", ":"), indent=indent)


def _write_json_file(path: Path, data: Any, *, indent: int | None = 2) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_json_dumps(data, indent=indent), encoding="utf-8")


def _percentile(samples: list[float], percentile: float) -> float | None:
    if not samples:
        return None
    if percentile <= 0:
        return float(min(samples))
    if percentile >= 100:
        return float(max(samples))
    ordered = sorted(samples)
    index = max(0, min(len(ordered) - 1, int(round((percentile / 100.0) * len(ordered) + 0.499999)) - 1))
    return float(ordered[index])


def _truncate_to_bytes(text: str, limit: int) -> str:
    if limit <= 0:
        return ""
    encoded = text.encode("utf-8")
    if len(encoded) <= limit:
        return text
    return encoded[-limit:].decode("utf-8", errors="ignore")


def _now_ms() -> float:
    return time.perf_counter() * 1000.0


def _build_benchmark_prompt(target_bytes: int = 1024) -> str:
    parts: list[str] = []
    while len(" ".join(parts).encode("utf-8")) < target_bytes:
        parts.append(BENCHMARK_PROMPT)
    return " ".join(parts)


def _extract_chat_text(body: dict[str, Any]) -> str:
    messages = body.get("messages")
    if not isinstance(messages, list):
        return _extract_fallback_text(body)
    parts: list[str] = []
    for message in messages:
        if not isinstance(message, dict):
            continue
        content = message.get("content")
        if isinstance(content, str):
            parts.append(content)
            continue
        if isinstance(content, list):
            for block in content:
                if isinstance(block, dict):
                    text = block.get("text")
                    if isinstance(text, str):
                        parts.append(text)
    return " ".join(part for part in parts if part).strip() or _extract_fallback_text(body)


def _extract_responses_text(body: dict[str, Any]) -> str:
    parts: list[str] = []
    instructions = body.get("instructions")
    if isinstance(instructions, str):
        parts.append(instructions)
    input_value = body.get("input")
    if isinstance(input_value, list):
        for item in input_value:
            if not isinstance(item, dict):
                continue
            content = item.get("content")
            if isinstance(content, str):
                parts.append(content)
                continue
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict):
                        text = block.get("text")
                        if isinstance(text, str):
                            parts.append(text)
    return " ".join(part for part in parts if part).strip() or _extract_fallback_text(body)


def _extract_fallback_text(body: dict[str, Any]) -> str:
    encoded = json.dumps(body, ensure_ascii=False, separators=(",", ":"))
    return encoded[:512]


def _repeat_to_size(text: str, target_bytes: int) -> str:
    if target_bytes <= 0:
        return text
    if not text:
        text = "x"
    output = text
    while len(output.encode("utf-8")) < target_bytes:
        output = f"{output} {text}"
    return output


def _build_chat_response(masked_text: str, body: dict[str, Any]) -> dict[str, Any]:
    output_text = _repeat_to_size(masked_text, int(body.get("bench_output_bytes") or 0))
    return {
        "id": "chatcmpl-bench",
        "object": "chat.completion",
        "choices": [
            {
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": f"Echo: {output_text}",
                },
                "finish_reason": "stop",
            }
        ],
    }


def _build_responses_response(masked_text: str, body: dict[str, Any]) -> dict[str, Any]:
    output_text = _repeat_to_size(masked_text, int(body.get("bench_output_bytes") or 0))
    response_id = str(body.get("bench_response_id") or "resp-bench")
    return {
        "id": response_id,
        "object": "response",
        "created_at": int(time.time()),
        "status": "completed",
        "background": False,
        "error": None,
        "output": [
            {
                "type": "message",
                "content": [
                    {
                        "type": "output_text",
                        "text": f"Echo: {output_text}",
                    }
                ],
            }
        ],
        "usage": {
            "input_tokens": 1,
            "output_tokens": 1,
            "total_tokens": 2,
        },
    }


def _split_text(text: str, chunks: int) -> list[str]:
    if chunks <= 1 or not text:
        return [text]
    size = max(1, len(text) // chunks)
    pieces = [text[index : index + size] for index in range(0, len(text), size)]
    return pieces or [text]


def _build_stream_events(masked_text: str, body: dict[str, Any]) -> list[dict[str, Any]]:
    response_id = str(body.get("bench_response_id") or "resp-bench-stream")
    response_text = _repeat_to_size(masked_text, int(body.get("bench_output_bytes") or 0))
    chunk_count = max(int(body.get("bench_stream_chunks") or 4), 1)
    created_at = int(time.time())
    events: list[dict[str, Any]] = [
        {
            "type": "response.created",
            "sequence_number": 0,
            "response": {
                "id": response_id,
                "object": "response",
                "created_at": created_at,
                "status": "in_progress",
                "background": False,
                "error": None,
                "output": [],
            },
        }
    ]
    for index, chunk in enumerate(_split_text(response_text, chunk_count), start=1):
        events.append(
            {
                "type": "response.output_text.delta",
                "sequence_number": index,
                "delta": chunk,
            }
        )
    events.append(
        {
            "type": "response.completed",
            "sequence_number": len(events),
            "response": {
                "id": response_id,
                "object": "response",
                "created_at": created_at,
                "status": "completed",
                "background": False,
                "error": None,
                "output": [
                    {
                        "type": "message",
                        "content": [
                            {
                                "type": "output_text",
                                "text": f"Echo: {response_text}",
                            }
                        ],
                    }
                ],
                "usage": {
                    "input_tokens": 1,
                    "output_tokens": 1,
                    "total_tokens": 2,
                },
            },
        }
    )
    return events


@dataclass
class FakeUpstreamState:
    requests_total: int = 0
    chat_requests: int = 0
    responses_requests: int = 0
    stream_requests: int = 0
    health_requests: int = 0
    request_paths: Counter[str] = field(default_factory=Counter)
    bytes_in: int = 0
    bytes_out: int = 0
    stream_chunks: int = 0
    stream_bytes_out: int = 0
    json_bytes_out: int = 0
    delays_ms: int = 0
    raw_plaintext_hits: int = 0
    placeholder_hits: int = 0
    turn_state_forwarded_hits: int = 0
    recent_requests: deque[dict[str, Any]] = field(default_factory=lambda: deque(maxlen=20))

    def snapshot(self) -> dict[str, Any]:
        return {
            "requests_total": self.requests_total,
            "chat_requests": self.chat_requests,
            "responses_requests": self.responses_requests,
            "stream_requests": self.stream_requests,
            "health_requests": self.health_requests,
            "request_paths": dict(self.request_paths),
            "bytes_in": self.bytes_in,
            "bytes_out": self.bytes_out,
            "stream_chunks": self.stream_chunks,
            "stream_bytes_out": self.stream_bytes_out,
            "json_bytes_out": self.json_bytes_out,
            "delays_ms": self.delays_ms,
            "raw_plaintext_hits": self.raw_plaintext_hits,
            "placeholder_hits": self.placeholder_hits,
            "turn_state_forwarded_hits": self.turn_state_forwarded_hits,
            "recent_requests": list(self.recent_requests),
        }

    def reset(self) -> None:
        self.requests_total = 0
        self.chat_requests = 0
        self.responses_requests = 0
        self.stream_requests = 0
        self.health_requests = 0
        self.request_paths.clear()
        self.bytes_in = 0
        self.bytes_out = 0
        self.stream_chunks = 0
        self.stream_bytes_out = 0
        self.json_bytes_out = 0
        self.delays_ms = 0
        self.raw_plaintext_hits = 0
        self.placeholder_hits = 0
        self.turn_state_forwarded_hits = 0
        self.recent_requests.clear()


def create_upstream_app(state: FakeUpstreamState) -> FastAPI:
    app = FastAPI(title="stronk-mask-bench-upstream")

    def inspect_request(serialized: bytes, headers: httpx.Headers | Any) -> None:
        text = serialized.decode("utf-8", errors="replace")
        header_blob = _json_dumps(dict(headers.items())) if hasattr(headers, "items") else ""
        haystack = f"{text}\n{header_blob}"
        if any(marker in haystack for marker in PLAINTEXT_MARKERS):
            state.raw_plaintext_hits += 1
        if PLACEHOLDER_RE.search(text):
            state.placeholder_hits += 1
        if "x-codex-turn-state" in header_blob.lower():
            state.turn_state_forwarded_hits += 1

    def record_request(path: str, serialized: bytes, body: dict[str, Any]) -> None:
        text = serialized.decode("utf-8", errors="replace")
        previous_response_id = body.get("previous_response_id") if isinstance(body, dict) else None
        state.recent_requests.append(
            {
                "path": path,
                "stream": bool(body.get("stream") is True) if isinstance(body, dict) else False,
                "has_previous_response_id": isinstance(previous_response_id, str),
                "previous_response_id": previous_response_id if isinstance(previous_response_id, str) else None,
                "input_tokens": sorted(set(BENCH_TOKEN_RE.findall(text))),
            }
        )

    @app.get("/health")
    async def health() -> dict[str, Any]:
        state.health_requests += 1
        return {"status": "ok", "role": "upstream"}

    @app.get("/__bench/state")
    async def bench_state() -> dict[str, Any]:
        return state.snapshot()

    @app.post("/__bench/reset")
    async def bench_reset() -> dict[str, Any]:
        state.reset()
        return {"status": "ok"}

    async def _maybe_delay(body: dict[str, Any]) -> None:
        delay_ms = int(body.get("bench_delay_ms") or 0)
        if delay_ms <= 0:
            return
        state.delays_ms += delay_ms
        await asyncio.sleep(delay_ms / 1000.0)

    async def _emit_sse_events(body: dict[str, Any]) -> StreamingResponse:
        masked_text = _extract_responses_text(body)
        events = _build_stream_events(masked_text, body)

        async def iterator() -> Any:
            for payload in events:
                rendered = "data: " + json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
                chunk = f"{rendered}\n\n".encode()
                state.stream_chunks += 1
                state.stream_bytes_out += len(chunk)
                yield chunk
                await _maybe_delay(body)
            done = b"data: [DONE]\n\n"
            state.stream_chunks += 1
            state.stream_bytes_out += len(done)
            yield done

        return StreamingResponse(iterator(), media_type="text/event-stream")

    @app.post("/v1/chat/completions")
    async def chat_completions(request: Request) -> Response:
        body = await request.json()
        state.requests_total += 1
        state.chat_requests += 1
        state.request_paths["/v1/chat/completions"] += 1
        serialized = await request.body()
        state.bytes_in += len(serialized)
        inspect_request(serialized, request.headers)
        record_request("/v1/chat/completions", serialized, body if isinstance(body, dict) else {})
        if isinstance(body, dict) and body.get("stream") is True:
            return await _emit_sse_events(body)
        masked_text = _extract_chat_text(body if isinstance(body, dict) else {})
        payload = _build_chat_response(masked_text, body if isinstance(body, dict) else {})
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        state.bytes_out += len(raw)
        state.json_bytes_out += len(raw)
        await _maybe_delay(body if isinstance(body, dict) else {})
        return JSONResponse(content=payload)

    @app.post("/v1/responses")
    async def responses(request: Request) -> Response:
        body = await request.json()
        state.requests_total += 1
        state.responses_requests += 1
        state.request_paths["/v1/responses"] += 1
        serialized = await request.body()
        state.bytes_in += len(serialized)
        inspect_request(serialized, request.headers)
        record_request("/v1/responses", serialized, body if isinstance(body, dict) else {})
        body_dict = body if isinstance(body, dict) else {}
        if isinstance(body_dict, dict) and "bench_response_id" not in body_dict:
            body_dict = {**body_dict, "bench_response_id": f"resp-bench-{state.requests_total}"}
        if isinstance(body_dict, dict) and body_dict.get("stream") is True:
            state.stream_requests += 1
            return await _emit_sse_events(body_dict)
        masked_text = _extract_responses_text(body_dict if isinstance(body_dict, dict) else {})
        payload = _build_responses_response(masked_text, body_dict if isinstance(body_dict, dict) else {})
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        state.bytes_out += len(raw)
        state.json_bytes_out += len(raw)
        await _maybe_delay(body_dict if isinstance(body_dict, dict) else {})
        return JSONResponse(content=payload)

    return app


@dataclass
class ManagedProcess:
    role: str
    port: int
    args: list[str]
    stderr_tail: deque[str] = field(default_factory=lambda: deque(maxlen=120))
    process: subprocess.Popen[str] | None = None
    _stderr_thread: threading.Thread | None = None

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    @property
    def ws_base_url(self) -> str:
        return f"ws://127.0.0.1:{self.port}"

    def start(self) -> None:
        if self.process is not None:
            return
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        self.process = subprocess.Popen(
            self.args,
            cwd=str(REPO_ROOT),
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
        if self.process.stderr is not None:
            self._stderr_thread = threading.Thread(target=self._drain_stderr, daemon=True)
            self._stderr_thread.start()

    def _drain_stderr(self) -> None:
        assert self.process is not None
        assert self.process.stderr is not None
        for line in self.process.stderr:
            self.stderr_tail.append(line.rstrip())

    def terminate(self) -> None:
        if self.process is None:
            return
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=5.0)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=5.0)
        self.process = None

    def stderr_text(self) -> str:
        return "\n".join(self.stderr_tail)


@dataclass
class RssSampler:
    processes: list[ManagedProcess]
    interval_seconds: float = DEFAULT_SAMPLE_INTERVAL
    stop_event: asyncio.Event = field(default_factory=asyncio.Event)
    peak_total_kb: int = 0
    peak_by_role_kb: dict[str, int] = field(default_factory=dict)
    sample_count: int = 0

    async def run(self) -> None:
        while not self.stop_event.is_set():
            total_kb = 0
            for process in self.processes:
                if process.process is None or process.process.poll() is not None:
                    continue
                current = sample_process_rss_kb(process.process.pid)
                total_kb += current
                previous = self.peak_by_role_kb.get(process.role, 0)
                if current > previous:
                    self.peak_by_role_kb[process.role] = current
            if total_kb > self.peak_total_kb:
                self.peak_total_kb = total_kb
            self.sample_count += 1
            await asyncio.sleep(self.interval_seconds)

    def stop(self) -> None:
        self.stop_event.set()


def sample_process_rss_kb(pid: int) -> int:
    if sys.platform.startswith("linux"):
        statm = Path(f"/proc/{pid}/statm")
        if statm.exists():
            try:
                fields = statm.read_text(encoding="utf-8").split()
                rss_pages = int(fields[1])
                page_size = os.sysconf("SC_PAGE_SIZE") // 1024
                return rss_pages * page_size
            except (OSError, IndexError, ValueError):
                return 0
    completed = subprocess.run(
        ["ps", "-o", "rss=", "-p", str(pid)],
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        return 0
    text = completed.stdout.strip().splitlines()
    if not text:
        return 0
    try:
        return int(text[-1].strip())
    except ValueError:
        return 0


@dataclass
class LatencyBucket:
    samples_ms: list[float] = field(default_factory=list)
    first_byte_ms: list[float] = field(default_factory=list)
    errors: int = 0
    total: int = 0
    error_statuses: Counter[str] = field(default_factory=Counter)
    close_codes: Counter[str] = field(default_factory=Counter)
    counters: Counter[str] = field(default_factory=Counter)

    def record_latency(self, value_ms: float) -> None:
        self.samples_ms.append(value_ms)
        self.total += 1

    def record_first_byte(self, value_ms: float) -> None:
        self.first_byte_ms.append(value_ms)

    def record_error(self, status: str) -> None:
        self.errors += 1
        self.error_statuses[status] += 1

    def record_close_code(self, code: int | None) -> None:
        if code is None:
            return
        self.close_codes[str(code)] += 1

    def record_counter(self, name: str, amount: int = 1) -> None:
        self.counters[name] += amount

    def latency_summary(self) -> dict[str, float | None]:
        return {
            "p50": _percentile(self.samples_ms, 50),
            "p95": _percentile(self.samples_ms, 95),
            "max": float(max(self.samples_ms)) if self.samples_ms else None,
        }

    def first_byte_summary(self) -> dict[str, float | None]:
        return {
            "p50": _percentile(self.first_byte_ms, 50),
            "p95": _percentile(self.first_byte_ms, 95),
            "max": float(max(self.first_byte_ms)) if self.first_byte_ms else None,
        }


def _headers_from_dict(headers: dict[str, str]) -> list[tuple[str, str]]:
    return [(key, value) for key, value in headers.items()]


async def _wait_for_health(client: httpx.AsyncClient, url: str, *, process: ManagedProcess) -> None:
    deadline = time.monotonic() + 20.0
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        if process.process is not None and process.process.poll() is not None:
            raise RuntimeError(
                f"{process.role} exited during startup:\n{process.stderr_text() or '<no stderr>'}"
            )
        try:
            response = await client.get(url)
            if response.status_code == 200:
                return
        except Exception as exc:  # pragma: no cover - startup race
            last_error = exc
        await asyncio.sleep(0.1)
    raise RuntimeError(
        f"timed out waiting for {process.role} at {url}: {last_error!r}\n"
        f"stderr:\n{process.stderr_text() or '<no stderr>'}"
    )


def _build_settings_kwargs(
    *,
    upstream_url: str,
    audit_db_path: str | None = None,
    audit_enabled: bool = False,
    admin_api: bool = False,
    unsafe_debug: bool = False,
    websocket_frame_byte_cap: int | None = None,
    websocket_message_limit: int | None = None,
    websocket_consecutive_error_limit: int | None = None,
    audit_prune_interval: int | None = None,
    unsafe_debug_max_entries: int | None = None,
    unsafe_debug_body_capture_bytes: int | None = None,
    unsafe_debug_stream_tail_bytes: int | None = None,
    presidio_enabled: bool | None = None,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "openai_upstream_base_url": upstream_url,
        "anthropic_upstream_base_url": upstream_url,
        "allow_insecure_upstreams": True,
        "allow_nonstandard_upstream_hosts": True,
    }
    if presidio_enabled is not None:
        kwargs["presidio_enabled"] = presidio_enabled
    if websocket_frame_byte_cap is not None:
        kwargs["websocket_frame_byte_cap"] = websocket_frame_byte_cap
    if websocket_message_limit is not None:
        kwargs["websocket_message_limit"] = websocket_message_limit
    if websocket_consecutive_error_limit is not None:
        kwargs["websocket_consecutive_error_limit"] = websocket_consecutive_error_limit
    if audit_enabled:
        kwargs["audit_storage_enabled"] = True
        kwargs["audit_db_path"] = audit_db_path
    if admin_api:
        kwargs["enable_admin_api"] = True
        kwargs["admin_proxy_secret"] = ADMIN_PROXY_SECRET
        kwargs["audit_storage_enabled"] = True
        kwargs["audit_db_path"] = audit_db_path
    if unsafe_debug:
        kwargs["enable_unsafe_debug_view"] = True
        kwargs["admin_proxy_secret"] = ADMIN_PROXY_SECRET
        kwargs["unsafe_debug_gateway_secret"] = DEBUG_GATEWAY_SECRET
        kwargs["audit_storage_enabled"] = True
        kwargs["audit_db_path"] = audit_db_path
    if audit_prune_interval is not None:
        kwargs["audit_prune_interval"] = audit_prune_interval
    if unsafe_debug_max_entries is not None:
        kwargs["unsafe_debug_max_entries"] = unsafe_debug_max_entries
    if unsafe_debug_body_capture_bytes is not None:
        kwargs["unsafe_debug_body_capture_bytes"] = unsafe_debug_body_capture_bytes
    if unsafe_debug_stream_tail_bytes is not None:
        kwargs["unsafe_debug_stream_tail_bytes"] = unsafe_debug_stream_tail_bytes
    return kwargs


def _spawn_process(role: str, port: int, *, settings_kwargs: dict[str, Any] | None = None) -> ManagedProcess:
    args = [
        _repo_python(),
        str(SCRIPT_PATH),
        "--serve",
        role,
        "--port",
        str(port),
    ]
    if settings_kwargs:
        args.extend(["--settings-json", json.dumps(settings_kwargs, separators=(",", ":"))])
    return ManagedProcess(role=role, port=port, args=args)


@dataclass
class BenchmarkCluster:
    scenario: str
    tempdir: tempfile.TemporaryDirectory[str]
    upstream_state: FakeUpstreamState = field(default_factory=FakeUpstreamState)
    upstream: ManagedProcess | None = None
    proxy: ManagedProcess | None = None
    admin: ManagedProcess | None = None
    sampler: RssSampler | None = None
    proxy_client: httpx.AsyncClient | None = None
    upstream_client: httpx.AsyncClient | None = None
    admin_client: httpx.AsyncClient | None = None

    @property
    def db_path(self) -> Path:
        return Path(self.tempdir.name) / "audit.sqlite3"

    @property
    def upstream_url(self) -> str:
        assert self.upstream is not None
        return self.upstream.base_url

    @property
    def proxy_url(self) -> str:
        assert self.proxy is not None
        return self.proxy.base_url

    @property
    def admin_url(self) -> str:
        assert self.admin is not None
        return self.admin.base_url

    async def start(self) -> None:
        upstream_port = _find_free_port()
        self.upstream = _spawn_process("upstream", upstream_port)
        self.upstream.start()

        upstream_app = httpx.AsyncClient(
            base_url=self.upstream_url,
            timeout=httpx.Timeout(5.0, connect=2.0),
            trust_env=False,
        )
        try:
            await _wait_for_health(upstream_app, "/health", process=self.upstream)
        finally:
            await upstream_app.aclose()

        presidio_enabled = await _probe_presidio_support()
        scenario_settings = _scenario_settings(self.scenario, self.db_path, self.upstream_url, presidio_enabled)
        proxy_port = _find_free_port()
        self.proxy = _spawn_process("proxy", proxy_port, settings_kwargs=scenario_settings["proxy"])
        self.proxy.start()
        proxy_health = httpx.AsyncClient(
            base_url=self.proxy_url,
            timeout=httpx.Timeout(5.0, connect=2.0),
            trust_env=False,
        )
        try:
            await _wait_for_health(proxy_health, "/health", process=self.proxy)
        finally:
            await proxy_health.aclose()

        if scenario_settings["admin"] is not None:
            admin_port = _find_free_port()
            self.admin = _spawn_process("admin", admin_port, settings_kwargs=scenario_settings["admin"])
            self.admin.start()
            admin_health = httpx.AsyncClient(
                base_url=self.admin_url,
                timeout=httpx.Timeout(5.0, connect=2.0),
                trust_env=False,
            )
            try:
                await _wait_for_health(admin_health, "/health", process=self.admin)
            finally:
                await admin_health.aclose()

        self.proxy_client = httpx.AsyncClient(
            base_url=self.proxy_url,
            timeout=httpx.Timeout(60.0, connect=5.0, read=60.0, write=60.0, pool=5.0),
            trust_env=False,
        )
        self.upstream_client = httpx.AsyncClient(
            base_url=self.upstream_url,
            timeout=httpx.Timeout(5.0, connect=2.0, read=10.0, write=10.0, pool=5.0),
            trust_env=False,
        )
        if self.admin is not None:
            self.admin_client = httpx.AsyncClient(
                base_url=self.admin_url,
                timeout=httpx.Timeout(60.0, connect=5.0, read=60.0, write=60.0, pool=5.0),
                trust_env=False,
            )

    async def close(self, *, keep_artifacts: bool = False) -> None:
        sampler = self.sampler
        if sampler is not None:
            sampler.stop()
        clients = [self.proxy_client, self.upstream_client, self.admin_client]
        for client in clients:
            if client is not None:
                await client.aclose()
        for process in (self.admin, self.proxy, self.upstream):
            if process is not None:
                process.terminate()
        if not keep_artifacts:
            self.tempdir.cleanup()

    async def query_upstream_state(self) -> dict[str, Any]:
        assert self.upstream_client is not None
        response = await self.upstream_client.get("/__bench/state")
        response.raise_for_status()
        return response.json()

    async def reset_upstream_state(self) -> None:
        assert self.upstream_client is not None
        response = await self.upstream_client.post("/__bench/reset")
        response.raise_for_status()

    async def query_admin_overview(self) -> dict[str, Any]:
        assert self.admin_client is not None
        response = await self.admin_client.get("/api/overview", headers=ADMIN_HEADERS)
        response.raise_for_status()
        return response.json()

    async def query_admin_config(self) -> dict[str, Any]:
        assert self.admin_client is not None
        response = await self.admin_client.get("/api/config", headers=ADMIN_HEADERS)
        response.raise_for_status()
        return response.json()

    async def query_debug_traces(self, *, limit: int = 20) -> list[dict[str, Any]]:
        assert self.proxy_client is not None
        response = await self.proxy_client.get("/api/debug/traces", params={"limit": limit}, headers=ADMIN_HEADERS)
        response.raise_for_status()
        payload = response.json()
        items = payload.get("items", [])
        if not isinstance(items, list):
            return []
        return [item for item in items if isinstance(item, dict)]

    async def query_debug_trace_detail(self, request_id: str) -> dict[str, Any]:
        assert self.proxy_client is not None
        response = await self.proxy_client.get(f"/api/debug/traces/{request_id}", headers=ADMIN_HEADERS)
        response.raise_for_status()
        payload = response.json()
        return payload if isinstance(payload, dict) else {}


async def _probe_presidio_support() -> bool:
    try:
        from stronk_mask.redaction.presidio_backend import PresidioBackendConfig, PresidioDetector
    except Exception:
        return False
    detector = PresidioDetector(
        PresidioBackendConfig(
            languages=("en", "zh"),
            english_model="en_core_web_sm",
            chinese_model="zh_core_web_sm",
            score_threshold=0.7,
        )
    )
    try:
        detector.detect("Alice Johnson")
    except Exception:
        return False
    return True


def _scenario_settings(
    scenario: str,
    db_path: Path,
    upstream_url: str,
    presidio_enabled: bool,
) -> dict[str, dict[str, Any] | None]:
    proxy_common = _build_settings_kwargs(
        upstream_url=upstream_url,
        presidio_enabled=presidio_enabled,
    )
    admin_common = _build_settings_kwargs(
        upstream_url=upstream_url,
        audit_db_path=str(db_path),
        audit_enabled=True,
        admin_api=True,
        presidio_enabled=presidio_enabled,
    )
    if scenario == "audit-contention":
        proxy = _build_settings_kwargs(
            upstream_url=upstream_url,
            audit_db_path=str(db_path),
            audit_enabled=True,
            audit_prune_interval=8,
            presidio_enabled=presidio_enabled,
        )
        return {"proxy": {**proxy_common, **proxy}, "admin": admin_common}
    if scenario == "memory-bound":
        proxy = _build_settings_kwargs(
            upstream_url=upstream_url,
            audit_db_path=str(db_path),
            audit_enabled=True,
            unsafe_debug=True,
            unsafe_debug_max_entries=200,
            unsafe_debug_body_capture_bytes=256,
            unsafe_debug_stream_tail_bytes=256,
            presidio_enabled=presidio_enabled,
        )
        return {"proxy": {**proxy_common, **proxy}, "admin": None}
    if scenario == "ws-abuse":
        proxy = _build_settings_kwargs(
            upstream_url=upstream_url,
            websocket_frame_byte_cap=1024,
            websocket_message_limit=3,
            websocket_consecutive_error_limit=3,
            presidio_enabled=presidio_enabled,
        )
        return {"proxy": {**proxy_common, **proxy}, "admin": None}
    return {"proxy": proxy_common, "admin": None}


def _build_http_chat_payload(prompt: str) -> dict[str, Any]:
    return {
        "model": DEFAULT_MODEL,
        "messages": [{"role": "user", "content": prompt}],
    }


def _build_http_responses_payload(prompt: str, *, stream: bool = False, delay_ms: int = 0) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "model": DEFAULT_MODEL,
        "input": [{"role": "user", "content": [{"type": "input_text", "text": prompt}]}],
    }
    if stream:
        payload["stream"] = True
    if delay_ms:
        payload["bench_delay_ms"] = delay_ms
    return payload


def _iter_stream_observation_fragments(text: str) -> list[str]:
    fragments: list[str] = []
    delta_fragments: list[str] = []
    normalized = text.replace("\r\n", "\n")
    for block in normalized.split("\n\n"):
        if not block:
            continue
        for line in block.split("\n"):
            if not line.startswith("data:"):
                continue
            raw_value = line[5:].lstrip()
            if not raw_value or raw_value == "[DONE]":
                continue
            try:
                parsed = json.loads(raw_value)
            except json.JSONDecodeError:
                fragments.append(raw_value)
                continue
            if (
                isinstance(parsed, dict)
                and parsed.get("type") == "response.output_text.delta"
                and isinstance(parsed.get("delta"), str)
            ):
                delta_fragments.append(parsed["delta"])
                continue
            fragments.extend(_iter_json_string_values(parsed))
    if delta_fragments:
        fragments.append("".join(delta_fragments))
    return fragments or [text]


def _iter_json_string_values(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        fragments: list[str] = []
        for item in value:
            fragments.extend(_iter_json_string_values(item))
        return fragments
    if isinstance(value, dict):
        fragments = []
        for item in value.values():
            fragments.extend(_iter_json_string_values(item))
        return fragments
    return []


def _record_output_invariants(
    metrics: LatencyBucket,
    *,
    text: str,
    request_token: str,
    sse: bool = False,
) -> None:
    observed_fragments = _iter_stream_observation_fragments(text) if sse else [text]
    if any(PLACEHOLDER_RE.search(fragment) for fragment in observed_fragments):
        metrics.record_counter("placeholder_leaks")
    token_hits = {
        hit
        for fragment in observed_fragments
        for hit in BENCH_TOKEN_RE.findall(fragment)
    }
    if request_token not in token_hits:
        metrics.record_counter("response_token_miss")
    if token_hits - {request_token}:
        metrics.record_counter("cross_request_tokens")


async def _run_http_scenario(
    cluster: BenchmarkCluster,
    *,
    path: str,
    payload_factory: Callable[[str, int], dict[str, Any]],
    duration_seconds: float,
    concurrency: int,
    scenario: str,
    stream: bool = False,
) -> dict[str, Any]:
    assert cluster.proxy_client is not None
    metrics = LatencyBucket()
    prompt_template = _build_benchmark_prompt()
    deadline = time.monotonic() + duration_seconds

    async def worker(index: int) -> None:
        nonlocal metrics
        client = cluster.proxy_client
        ordinal = 0
        while time.monotonic() < deadline:
            request_token = f"bench-{scenario}-{index}-{ordinal}"
            prompt = f"{prompt_template} {request_token}"
            payload = payload_factory(prompt, index)
            ordinal += 1
            started = time.perf_counter()
            try:
                if stream:
                    async with client.stream("POST", path, json=payload) as response:
                        first_byte_recorded = False
                        body_parts: list[bytes] = []
                        async for chunk in response.aiter_bytes():
                            if not first_byte_recorded:
                                metrics.record_first_byte((time.perf_counter() - started) * 1000.0)
                                first_byte_recorded = True
                            body_parts.append(chunk)
                        latency_ms = (time.perf_counter() - started) * 1000.0
                        metrics.record_latency(latency_ms)
                        if response.status_code >= 400:
                            metrics.record_error(str(response.status_code))
                            continue
                        text = b"".join(body_parts).decode("utf-8", errors="replace")
                        _record_output_invariants(
                            metrics,
                            text=text,
                            request_token=request_token,
                            sse=True,
                        )
                        metrics.record_counter("responses", 1)
                        metrics.record_counter("bytes", len(text.encode("utf-8")))
                else:
                    response = await client.post(path, json=payload)
                    latency_ms = (time.perf_counter() - started) * 1000.0
                    metrics.record_latency(latency_ms)
                    if response.status_code >= 400:
                        metrics.record_error(str(response.status_code))
                        continue
                    data = response.json()
                    text = json.dumps(data, ensure_ascii=False)
                    _record_output_invariants(metrics, text=text, request_token=request_token)
                    metrics.record_counter("responses", 1)
                    metrics.record_counter("bytes", len(response.content))
            except Exception as exc:  # pragma: no cover - network failure
                metrics.record_error(type(exc).__name__)
                continue

    await asyncio.gather(*(worker(index) for index in range(concurrency)))
    state = await cluster.query_upstream_state()
    return _build_summary(
        scenario=scenario,
        metrics=metrics,
        cluster=cluster,
        duration_seconds=duration_seconds,
        concurrency=concurrency,
        extra_counters={
            "upstream": state,
        },
    )


async def _run_ws_sequential(
    cluster: BenchmarkCluster,
    *,
    duration_seconds: float,
    concurrency: int,
    turns_per_session: int,
) -> dict[str, Any]:
    assert cluster.proxy is not None
    metrics = LatencyBucket()
    prompt_template = _build_benchmark_prompt()
    reconnect_probe = await _run_ws_reconnect_probe(cluster)
    await cluster.reset_upstream_state()
    session_results: list[dict[str, Any]] = []

    async def run_session(session_index: int) -> None:
        turn_state = f"bench-session-{session_index}"
        previous_response_id: str | None = None
        for turn_index in range(turns_per_session):
            request_token = f"bench-ws-sequential-{session_index}-{turn_index}"
            prompt = f"{prompt_template} {request_token}"
            payload = _build_http_responses_payload(prompt, stream=True, delay_ms=20)
            payload["type"] = "response.create"
            payload["previous_response_id"] = previous_response_id
            if turn_index == 0:
                payload.pop("previous_response_id", None)
            started = time.perf_counter()
            try:
                async with websockets.connect(
                    f"{cluster.proxy.ws_base_url}/v1/responses",
                    additional_headers=_headers_from_dict(
                        {
                            "x-codex-turn-state": turn_state,
                        }
                    ),
                    open_timeout=5.0,
                    ping_interval=None,
                    close_timeout=5.0,
                    proxy=None,
                ) as websocket:
                    await websocket.send(json.dumps(payload, ensure_ascii=False))
                    terminal_payload: dict[str, Any] | None = None
                    while True:
                        raw = await websocket.recv()
                        parsed = json.loads(raw)
                        if isinstance(parsed, dict) and parsed.get("type") == "error":
                            latency_ms = (time.perf_counter() - started) * 1000.0
                            metrics.record_latency(latency_ms)
                            metrics.record_error(str(parsed.get("status") or "ws-error"))
                            metrics.record_close_code(None)
                            return
                        if isinstance(parsed, dict) and parsed.get("type") == "response.completed":
                            terminal_payload = parsed
                            break
                    latency_ms = (time.perf_counter() - started) * 1000.0
                    metrics.record_latency(latency_ms)
                    metrics.record_counter("turns", 1)
                    response = terminal_payload or {}
                    response_text = _json_dumps(response)
                    _record_output_invariants(metrics, text=response_text, request_token=request_token)
                    response_id = response.get("response", {}).get("id") if isinstance(response.get("response"), dict) else None
                    if isinstance(response_id, str):
                        previous_response_id = response_id
                    metrics.record_counter("completed", 1)
                    session_results.append(
                        {
                            "session": session_index,
                            "turn": turn_index,
                            "response_id": previous_response_id,
                        }
                    )
            except ConnectionClosed as exc:
                metrics.record_latency((time.perf_counter() - started) * 1000.0)
                metrics.record_error(type(exc).__name__)
                metrics.record_close_code(getattr(exc, "code", None))
                return
            except Exception as exc:  # pragma: no cover - websocket failure
                metrics.record_latency((time.perf_counter() - started) * 1000.0)
                metrics.record_error(type(exc).__name__)
                return

    session_count = max(concurrency, 1)
    await asyncio.gather(*(run_session(index) for index in range(session_count)))
    state = await cluster.query_upstream_state()
    return _build_summary(
        scenario="ws-sequential",
        metrics=metrics,
        cluster=cluster,
        duration_seconds=duration_seconds,
        concurrency=concurrency,
        extra_counters={
            "upstream": state,
            "sessions": len(session_results),
            "turns_per_session": turns_per_session,
            "reconnect_probe": reconnect_probe,
        },
    )


async def _run_ws_reconnect_probe(cluster: BenchmarkCluster) -> dict[str, Any]:
    assert cluster.proxy is not None
    await cluster.reset_upstream_state()
    turn_state = "bench-ws-sequential-probe"
    prewarm_token = "bench-ws-sequential-9000-0"
    abort_token = "bench-ws-sequential-9000-1"
    retry_token = "bench-ws-sequential-9000-2"
    prewarm_payload = _build_http_responses_payload(f"probe {prewarm_token}", stream=True, delay_ms=20)
    prewarm_payload["type"] = "response.create"
    prewarm_response_id: str | None = None
    try:
        async with websockets.connect(
            f"{cluster.proxy.ws_base_url}/v1/responses",
            additional_headers=_headers_from_dict({"x-codex-turn-state": turn_state}),
            open_timeout=5.0,
            ping_interval=None,
            close_timeout=5.0,
            proxy=None,
        ) as websocket:
            await websocket.send(json.dumps(prewarm_payload, ensure_ascii=False))
            while True:
                parsed = json.loads(await websocket.recv())
                if isinstance(parsed, dict) and parsed.get("type") == "error":
                    return {"completed": False, "reason": "prewarm_error", "error": parsed}
                if isinstance(parsed, dict) and parsed.get("type") == "response.completed":
                    response = parsed.get("response")
                    if isinstance(response, dict) and isinstance(response.get("id"), str):
                        prewarm_response_id = response["id"]
                    break
    except Exception as exc:  # pragma: no cover - websocket setup failure
        return {"completed": False, "reason": "prewarm_exception", "error": type(exc).__name__}
    if prewarm_response_id is None:
        return {"completed": False, "reason": "missing_prewarm_response_id"}

    abort_payload = _build_http_responses_payload(f"probe {abort_token}", stream=True, delay_ms=250)
    abort_payload["type"] = "response.create"
    abort_payload["previous_response_id"] = prewarm_response_id
    try:
        async with websockets.connect(
            f"{cluster.proxy.ws_base_url}/v1/responses",
            additional_headers=_headers_from_dict({"x-codex-turn-state": turn_state}),
            open_timeout=5.0,
            ping_interval=None,
            close_timeout=5.0,
            proxy=None,
        ) as websocket:
            await websocket.send(json.dumps(abort_payload, ensure_ascii=False))
            saw_nonterminal = False
            while True:
                parsed = json.loads(await websocket.recv())
                if isinstance(parsed, dict) and parsed.get("type") == "error":
                    return {"completed": False, "reason": "abort_error", "error": parsed}
                if isinstance(parsed, dict) and parsed.get("type") in {"response.created", "response.output_text.delta"}:
                    saw_nonterminal = True
                    break
                if isinstance(parsed, dict) and parsed.get("type") == "response.completed":
                    return {"completed": False, "reason": "abort_turn_completed_before_disconnect"}
            if not saw_nonterminal:
                return {"completed": False, "reason": "abort_turn_missing_nonterminal_event"}
    except Exception as exc:  # pragma: no cover - websocket setup failure
        return {"completed": False, "reason": "abort_exception", "error": type(exc).__name__}

    retry_payload = _build_http_responses_payload(f"probe {retry_token}", stream=True, delay_ms=20)
    retry_payload["type"] = "response.create"
    retry_payload["previous_response_id"] = prewarm_response_id
    retry_response_id: str | None = None
    try:
        async with websockets.connect(
            f"{cluster.proxy.ws_base_url}/v1/responses",
            additional_headers=_headers_from_dict({"x-codex-turn-state": turn_state}),
            open_timeout=5.0,
            ping_interval=None,
            close_timeout=5.0,
            proxy=None,
        ) as websocket:
            await websocket.send(json.dumps(retry_payload, ensure_ascii=False))
            while True:
                parsed = json.loads(await websocket.recv())
                if isinstance(parsed, dict) and parsed.get("type") == "error":
                    return {"completed": False, "reason": "retry_error", "error": parsed}
                if isinstance(parsed, dict) and parsed.get("type") == "response.completed":
                    response = parsed.get("response")
                    if isinstance(response, dict) and isinstance(response.get("id"), str):
                        retry_response_id = response["id"]
                    break
    except Exception as exc:  # pragma: no cover - websocket setup failure
        return {"completed": False, "reason": "retry_exception", "error": type(exc).__name__}

    probe_state = await cluster.query_upstream_state()
    requests = [
        item
        for item in probe_state.get("recent_requests", [])
        if isinstance(item, dict) and item.get("path") == "/v1/responses"
    ]
    request_by_token: dict[str, dict[str, Any]] = {}
    for request in requests:
        tokens = request.get("input_tokens", [])
        if not isinstance(tokens, list):
            continue
        for token in tokens:
            if isinstance(token, str):
                request_by_token[token] = request
    retry_request = request_by_token.get(retry_token)
    abort_request = request_by_token.get(abort_token)
    return {
        "completed": True,
        "prewarm_response_id": prewarm_response_id,
        "retry_response_id": retry_response_id,
        "probe_request_count": len(requests),
        "abort_request_seen": abort_request is not None,
        "retry_request_seen": retry_request is not None,
        "retry_forwarded_previous_response_id": bool(retry_request and retry_request.get("has_previous_response_id")),
        "retry_abort_token_leaked": bool(retry_request and abort_token in (retry_request.get("input_tokens") or [])),
    }


def _aggregate_upstream_states(states: list[dict[str, Any]]) -> dict[str, Any]:
    aggregate: dict[str, Any] = {
        "requests_total": 0,
        "chat_requests": 0,
        "responses_requests": 0,
        "stream_requests": 0,
        "health_requests": 0,
        "request_paths": {},
        "bytes_in": 0,
        "bytes_out": 0,
        "stream_chunks": 0,
        "stream_bytes_out": 0,
        "json_bytes_out": 0,
        "delays_ms": 0,
        "raw_plaintext_hits": 0,
        "placeholder_hits": 0,
        "turn_state_forwarded_hits": 0,
    }
    for state in states:
        for key in (
            "requests_total",
            "chat_requests",
            "responses_requests",
            "stream_requests",
            "health_requests",
            "bytes_in",
            "bytes_out",
            "stream_chunks",
            "stream_bytes_out",
            "json_bytes_out",
            "delays_ms",
            "raw_plaintext_hits",
            "placeholder_hits",
            "turn_state_forwarded_hits",
        ):
            aggregate[key] += int(state.get(key) or 0)
        request_paths = state.get("request_paths", {})
        if isinstance(request_paths, dict):
            for path, count in request_paths.items():
                if isinstance(path, str):
                    aggregate["request_paths"][path] = aggregate["request_paths"].get(path, 0) + int(count or 0)
    return aggregate


async def _run_ws_abuse(
    cluster: BenchmarkCluster,
    *,
    duration_seconds: float,
    concurrency: int,
) -> dict[str, Any]:
    assert cluster.proxy is not None
    metrics = LatencyBucket()
    prompt = _build_benchmark_prompt()
    case_workers = max(1, concurrency // 4)

    async def oversize_case(index: int) -> None:
        turn_state = f"bench-abuse-oversize-{index}"
        payload = _build_http_responses_payload(prompt, stream=True)
        payload["type"] = "response.create"
        payload["input"][0]["content"][0]["text"] = "x" * 3000
        try:
            async with websockets.connect(
                f"{cluster.proxy.ws_base_url}/v1/responses",
                additional_headers=_headers_from_dict({"x-codex-turn-state": turn_state}),
                open_timeout=5.0,
                ping_interval=None,
                close_timeout=5.0,
                proxy=None,
            ) as websocket:
                started = time.perf_counter()
                await websocket.send(json.dumps(payload, ensure_ascii=False))
                raw = await websocket.recv()
                latency_ms = (time.perf_counter() - started) * 1000.0
                metrics.record_latency(latency_ms)
                parsed = json.loads(raw)
                if (
                    isinstance(parsed, dict)
                    and parsed.get("type") == "error"
                    and parsed.get("status") == 413
                ):
                    metrics.record_error(str(parsed.get("status") or "ws-error"))
                    metrics.record_counter("oversize_rejected", 1)
                else:
                    metrics.record_error("oversize_unexpected_outcome")
        except ConnectionClosed as exc:
            metrics.record_close_code(getattr(exc, "code", None))
        except Exception as exc:
            metrics.record_error(type(exc).__name__)

    async def invalid_json_case(index: int) -> None:
        turn_state = f"bench-abuse-invalid-{index}"
        try:
            async with websockets.connect(
                f"{cluster.proxy.ws_base_url}/v1/responses",
                additional_headers=_headers_from_dict({"x-codex-turn-state": turn_state}),
                open_timeout=5.0,
                ping_interval=None,
                close_timeout=5.0,
                proxy=None,
            ) as websocket:
                started = time.perf_counter()
                await websocket.send("not-json")
                raw = await websocket.recv()
                latency_ms = (time.perf_counter() - started) * 1000.0
                metrics.record_latency(latency_ms)
                parsed = json.loads(raw)
                if (
                    isinstance(parsed, dict)
                    and parsed.get("type") == "error"
                    and parsed.get("status") == 400
                ):
                    metrics.record_error(str(parsed.get("status") or "ws-error"))
                    metrics.record_counter("invalid_json_rejected", 1)
                else:
                    metrics.record_error("invalid_json_unexpected_outcome")
        except ConnectionClosed as exc:
            metrics.record_close_code(getattr(exc, "code", None))
        except Exception as exc:
            metrics.record_error(type(exc).__name__)

    async def blocked_budget_case(index: int) -> None:
        turn_state = f"bench-abuse-blocked-{index}"
        blocked_payload = {
            "type": "response.create",
            "model": DEFAULT_MODEL,
            "input": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_text",
                            "text": "Please use sk-1234567890abcdef1234567890abcdef now.",
                        }
                    ],
                }
            ],
        }
        try:
            async with websockets.connect(
                f"{cluster.proxy.ws_base_url}/v1/responses",
                additional_headers=_headers_from_dict({"x-codex-turn-state": turn_state}),
                open_timeout=5.0,
                ping_interval=None,
                close_timeout=5.0,
                proxy=None,
            ) as websocket:
                for _ in range(3):
                    started = time.perf_counter()
                    await websocket.send(json.dumps(blocked_payload, ensure_ascii=False))
                    raw = await websocket.recv()
                    latency_ms = (time.perf_counter() - started) * 1000.0
                    metrics.record_latency(latency_ms)
                    parsed = json.loads(raw)
                    if (
                        isinstance(parsed, dict)
                        and parsed.get("type") == "error"
                        and parsed.get("status") == 422
                    ):
                        metrics.record_error(str(parsed.get("status") or "ws-error"))
                    else:
                        metrics.record_error("blocked_budget_unexpected_outcome")
                metrics.record_counter("blocked_budget_rejected", 1)
                try:
                    await asyncio.wait_for(websocket.recv(), timeout=1.0)
                except ConnectionClosed as exc:
                    metrics.record_close_code(getattr(exc, "code", None))
                    metrics.record_counter("blocked_budget_closed", 1)
                except TimeoutError:
                    metrics.record_counter("blocked_budget_timeout", 1)
        except ConnectionClosed as exc:
            metrics.record_close_code(getattr(exc, "code", None))
        except Exception as exc:
            metrics.record_error(type(exc).__name__)

    async def collision_case(index: int) -> None:
        turn_state = f"bench-abuse-collision-{index}"
        collision_prompt = "bench collision probe"
        slow_payload = _build_http_responses_payload(collision_prompt, stream=True, delay_ms=250)
        slow_payload["type"] = "response.create"
        fast_payload = _build_http_responses_payload(collision_prompt, stream=True)
        fast_payload["type"] = "response.create"
        try:
            async with websockets.connect(
                f"{cluster.proxy.ws_base_url}/v1/responses",
                additional_headers=_headers_from_dict({"x-codex-turn-state": turn_state}),
                open_timeout=5.0,
                ping_interval=None,
                close_timeout=5.0,
                proxy=None,
            ) as websocket_one:
                await websocket_one.send(json.dumps(slow_payload, ensure_ascii=False))
                created = json.loads(await websocket_one.recv())
                if not (
                    isinstance(created, dict)
                    and created.get("type") == "response.created"
                    and isinstance(created.get("response"), dict)
                ):
                    metrics.record_error("turn_collision_setup_unexpected_outcome")
                    return
                async with websockets.connect(
                    f"{cluster.proxy.ws_base_url}/v1/responses",
                    additional_headers=_headers_from_dict({"x-codex-turn-state": turn_state}),
                    open_timeout=5.0,
                    ping_interval=None,
                    close_timeout=5.0,
                    proxy=None,
                ) as websocket_two:
                    started = time.perf_counter()
                    await websocket_two.send(json.dumps(fast_payload, ensure_ascii=False))
                    raw = await websocket_two.recv()
                    latency_ms = (time.perf_counter() - started) * 1000.0
                    metrics.record_latency(latency_ms)
                    parsed = json.loads(raw)
                    if (
                        isinstance(parsed, dict)
                        and parsed.get("type") == "error"
                        and parsed.get("status") == 409
                        and isinstance(parsed.get("error"), dict)
                        and parsed["error"].get("type") == "invalid_websocket_turn"
                    ):
                        metrics.record_error(str(parsed.get("status") or "ws-error"))
                        metrics.record_counter("turn_collision_rejected", 1)
                    else:
                        metrics.record_error("turn_collision_unexpected_outcome")
                while True:
                    raw = await websocket_one.recv()
                    parsed = json.loads(raw)
                    if isinstance(parsed, dict) and parsed.get("type") == "response.completed":
                        break
        except ConnectionClosed as exc:
            metrics.record_close_code(getattr(exc, "code", None))
        except Exception as exc:
            metrics.record_error(type(exc).__name__)

    await cluster.reset_upstream_state()
    await asyncio.gather(*(oversize_case(index) for index in range(case_workers)))
    oversize_state = await cluster.query_upstream_state()
    await cluster.reset_upstream_state()
    await asyncio.gather(*(invalid_json_case(index) for index in range(case_workers)))
    invalid_state = await cluster.query_upstream_state()
    await cluster.reset_upstream_state()
    await asyncio.gather(*(blocked_budget_case(index) for index in range(case_workers)))
    blocked_budget_state = await cluster.query_upstream_state()
    await cluster.reset_upstream_state()
    await asyncio.gather(*(collision_case(index) for index in range(case_workers)))
    collision_state = await cluster.query_upstream_state()
    state = _aggregate_upstream_states([oversize_state, invalid_state, blocked_budget_state, collision_state])
    return _build_summary(
        scenario="ws-abuse",
        metrics=metrics,
        cluster=cluster,
        duration_seconds=duration_seconds,
        concurrency=concurrency,
        extra_counters={
            "upstream": state,
            "case_workers": case_workers,
            "abuse_case_upstream": {
                "oversize": oversize_state,
                "invalid_json": invalid_state,
                "blocked_budget": blocked_budget_state,
                "collision": collision_state,
            },
        },
    )


async def _run_audit_contention(
    cluster: BenchmarkCluster,
    *,
    duration_seconds: float,
    concurrency: int,
) -> dict[str, Any]:
    assert cluster.proxy_client is not None
    assert cluster.admin_client is not None
    metrics = LatencyBucket()
    prompt = _build_benchmark_prompt()
    deadline = time.monotonic() + duration_seconds
    writer_concurrency = max(1, concurrency)
    reader_concurrency = max(1, concurrency // 8)
    admin_reads = 0
    proxy_write_count = 0

    async def writer(index: int) -> None:
        nonlocal proxy_write_count
        client = cluster.proxy_client
        while time.monotonic() < deadline:
            payload = _build_http_chat_payload(prompt)
            started = time.perf_counter()
            try:
                response = await client.post("/v1/chat/completions", json=payload)
                latency_ms = (time.perf_counter() - started) * 1000.0
                metrics.record_latency(latency_ms)
                if response.status_code >= 400:
                    metrics.record_error(str(response.status_code))
                    metrics.record_counter("proxy_write_failures")
                    continue
                metrics.record_counter("proxy_writes", 1)
                proxy_write_count += 1
            except Exception as exc:
                metrics.record_error(type(exc).__name__)
                metrics.record_counter("proxy_write_failures")

    async def reader(index: int) -> None:
        nonlocal admin_reads
        client = cluster.admin_client
        assert client is not None
        while time.monotonic() < deadline:
            started = time.perf_counter()
            try:
                overview = await client.get("/api/overview", headers=ADMIN_HEADERS)
                events = await client.get("/api/events", params={"limit": 20}, headers=ADMIN_HEADERS)
                config = await client.get("/api/config", headers=ADMIN_HEADERS)
                latency_ms = (time.perf_counter() - started) * 1000.0
                metrics.record_latency(latency_ms)
                if overview.status_code >= 400 or events.status_code >= 400 or config.status_code >= 400:
                    metrics.record_error(
                        ",".join(
                            str(code)
                            for code in (
                                overview.status_code,
                                events.status_code,
                                config.status_code,
                            )
                            if code >= 400
                        )
                    )
                    metrics.record_counter("admin_read_failures")
                    continue
                admin_reads += 3
                metrics.record_counter("admin_reads", 3)
            except Exception as exc:
                metrics.record_error(type(exc).__name__)
                metrics.record_counter("admin_read_failures")

    await asyncio.gather(
        *(writer(index) for index in range(writer_concurrency)),
        *(reader(index) for index in range(reader_concurrency)),
    )
    await _wait_for_admin_total_requests(cluster, expected_total=proxy_write_count)
    await asyncio.sleep(1.0)
    admin_overview = await cluster.query_admin_overview()
    state = await cluster.query_upstream_state()

    return _build_summary(
        scenario="audit-contention",
        metrics=metrics,
        cluster=cluster,
        duration_seconds=duration_seconds,
        concurrency=concurrency,
        extra_counters={
            "upstream": state,
            "admin_overview": admin_overview,
            "admin_reads": admin_reads,
            "sqlite_lock_errors": metrics.error_statuses.get("OperationalError", 0),
            "proxy_writes": proxy_write_count,
        },
    )


async def _run_memory_bound(
    cluster: BenchmarkCluster,
    *,
    duration_seconds: float,
    concurrency: int,
) -> dict[str, Any]:
    assert cluster.proxy_client is not None
    metrics = LatencyBucket()
    prompt = _build_benchmark_prompt(1536)
    deadline = time.monotonic() + duration_seconds
    proxy = cluster.proxy_client

    async def large_body_writer(index: int) -> None:
        while time.monotonic() < deadline:
            payload = _build_http_responses_payload(prompt, stream=False)
            payload["bench_output_bytes"] = 64 * 1024
            started = time.perf_counter()
            try:
                response = await proxy.post("/v1/responses", json=payload)
                latency_ms = (time.perf_counter() - started) * 1000.0
                metrics.record_latency(latency_ms)
                if response.status_code >= 400:
                    metrics.record_error(str(response.status_code))
                    continue
                metrics.record_counter("large_json_responses", 1)
            except Exception as exc:
                metrics.record_error(type(exc).__name__)

    async def long_stream_writer(index: int) -> None:
        while time.monotonic() < deadline:
            payload = _build_http_responses_payload(prompt, stream=True, delay_ms=10)
            payload["bench_output_bytes"] = 128 * 1024
            payload["bench_stream_chunks"] = 8
            started = time.perf_counter()
            try:
                async with proxy.stream("POST", "/v1/responses", json=payload) as response:
                    first_byte_recorded = False
                    body_parts: list[bytes] = []
                    async for chunk in response.aiter_bytes():
                        if not first_byte_recorded:
                            metrics.record_first_byte((time.perf_counter() - started) * 1000.0)
                            first_byte_recorded = True
                        body_parts.append(chunk)
                    latency_ms = (time.perf_counter() - started) * 1000.0
                    metrics.record_latency(latency_ms)
                    if response.status_code >= 400:
                        metrics.record_error(str(response.status_code))
                        continue
                    metrics.record_counter("long_streams", 1)
            except Exception as exc:
                metrics.record_error(type(exc).__name__)

    await asyncio.gather(
        *(large_body_writer(index) for index in range(max(1, concurrency // 2))),
        *(long_stream_writer(index) for index in range(max(1, concurrency // 2))),
    )
    await asyncio.sleep(1.0)
    traces = await cluster.query_debug_traces(limit=200)
    state = await cluster.query_upstream_state()

    truncation_hits = 0
    for trace in traces[:20]:
        request_id = trace.get("request_id")
        if not isinstance(request_id, str):
            continue
        detail = await cluster.query_debug_trace_detail(request_id)
        for field_name in ("response_upstream", "response_rehydrated"):
            value = detail.get(field_name)
            if isinstance(value, str) and value.startswith(TRUNCATION_MARKER_PREFIX):
                truncation_hits += 1
    metrics.record_counter("debug_traces", len(traces))
    metrics.record_counter("truncation_hits", truncation_hits)
    return _build_summary(
        scenario="memory-bound",
        metrics=metrics,
        cluster=cluster,
        duration_seconds=duration_seconds,
        concurrency=concurrency,
        extra_counters={
            "upstream": state,
            "debug_traces": len(traces),
            "truncation_hits": truncation_hits,
        },
    )


async def _run_http_chat(
    cluster: BenchmarkCluster,
    *,
    duration_seconds: float,
    concurrency: int,
) -> dict[str, Any]:
    return await _run_http_scenario(
        cluster,
        path="/v1/chat/completions",
        payload_factory=lambda prompt, _: _build_http_chat_payload(prompt),
        duration_seconds=duration_seconds,
        concurrency=concurrency,
        scenario="http-chat",
    )


async def _run_http_responses(
    cluster: BenchmarkCluster,
    *,
    duration_seconds: float,
    concurrency: int,
) -> dict[str, Any]:
    return await _run_http_scenario(
        cluster,
        path="/v1/responses",
        payload_factory=lambda prompt, _: _build_http_responses_payload(prompt, stream=False),
        duration_seconds=duration_seconds,
        concurrency=concurrency,
        scenario="http-responses",
    )


async def _run_sse_stream(
    cluster: BenchmarkCluster,
    *,
    duration_seconds: float,
    concurrency: int,
) -> dict[str, Any]:
    return await _run_http_scenario(
        cluster,
        path="/v1/responses",
        payload_factory=lambda prompt, _: _build_http_responses_payload(prompt, stream=True, delay_ms=20),
        duration_seconds=duration_seconds,
        concurrency=concurrency,
        scenario="sse-stream",
        stream=True,
    )


def _build_summary(
    *,
    scenario: str,
    metrics: LatencyBucket,
    cluster: BenchmarkCluster,
    duration_seconds: float,
    concurrency: int,
    extra_counters: dict[str, Any],
) -> dict[str, Any]:
    row_id = MATRIX_IDS[scenario]
    error_rate = (metrics.errors / metrics.total) if metrics.total else 0.0
    successes = max(metrics.total - metrics.errors, 0)
    latency = metrics.latency_summary()
    first_byte = metrics.first_byte_summary()
    log_counters = _scan_process_logs(cluster)
    rss_summary = {
        "peak_total_kb": cluster.sampler.peak_total_kb if cluster.sampler else None,
        "peak_by_role_kb": cluster.sampler.peak_by_role_kb if cluster.sampler else {},
        "sample_count": cluster.sampler.sample_count if cluster.sampler else 0,
    }
    baseline_status = "blocked_baseline"
    threshold_status = "skipped_thresholds"
    if extra_counters.get("admin_overview") or extra_counters.get("upstream"):
        comparison_reason = "historic baseline unavailable in this harness run"
    else:
        comparison_reason = "historic baseline unavailable"
    upstream = extra_counters.get("upstream")
    upstream_summary = upstream if isinstance(upstream, dict) else {}
    failure_reasons: list[str] = []
    blocked_reasons: list[str] = []
    if error_rate > 0 and scenario not in {"ws-abuse"}:
        failure_reasons.append(f"observed error_rate={error_rate:.6f}")
    if metrics.counters.get("placeholder_leaks", 0) > 0:
        failure_reasons.append("downstream placeholder leak observed")
    if metrics.counters.get("response_token_miss", 0) > 0:
        failure_reasons.append("downstream response token mismatch observed")
    if metrics.counters.get("cross_request_tokens", 0) > 0:
        failure_reasons.append("downstream cross-request token mix observed")
    if int(upstream_summary.get("raw_plaintext_hits") or 0) > 0:
        failure_reasons.append("upstream raw plaintext observed")
    if int(upstream_summary.get("turn_state_forwarded_hits") or 0) > 0:
        failure_reasons.append("x-codex-turn-state reached upstream")
    if log_counters["database_is_locked"] > 0:
        failure_reasons.append("database is locked appeared in process logs")
    if log_counters["audit_retry_warnings"] > 0:
        failure_reasons.append("audit batch retry warnings observed in process logs")
    if scenario == "memory-bound" and int(extra_counters.get("truncation_hits") or 0) <= 0:
        failure_reasons.append("no truncation markers observed in unsafe debug traces")
    if scenario == "audit-contention" and metrics.counters.get("proxy_write_failures", 0) > 0:
        failure_reasons.append("proxy write failures observed under audit contention")
    if scenario == "ws-sequential":
        reconnect_probe = extra_counters.get("reconnect_probe", {})
        if not isinstance(reconnect_probe, dict) or not reconnect_probe.get("completed"):
            blocked_reasons.append(
                "benchmark reconnect probe did not deterministically prove midstream disconnect rollback semantics"
            )
        elif reconnect_probe.get("retry_forwarded_previous_response_id"):
            failure_reasons.append("reconnect retry forwarded previous_response_id after midstream disconnect")
        elif reconnect_probe.get("retry_abort_token_leaked"):
            failure_reasons.append("reconnect retry leaked aborted-turn state")
        elif not reconnect_probe.get("retry_request_seen"):
            failure_reasons.append("reconnect retry request was not observed upstream")
    if scenario == "ws-abuse":
        for counter_name in (
            "oversize_rejected",
            "invalid_json_rejected",
            "blocked_budget_rejected",
            "blocked_budget_closed",
        ):
            if metrics.counters.get(counter_name, 0) <= 0:
                failure_reasons.append(f"expected websocket abuse signal missing: {counter_name}")
        abuse_case_upstream = extra_counters.get("abuse_case_upstream", {})
        if isinstance(abuse_case_upstream, dict):
            for case_name in ("oversize", "invalid_json", "blocked_budget"):
                case_state = abuse_case_upstream.get(case_name, {})
                if isinstance(case_state, dict) and int(case_state.get("requests_total") or 0) > 0:
                    failure_reasons.append(f"{case_name} abuse traffic reached upstream")
            collision_state = abuse_case_upstream.get("collision", {})
            collision_expected = int(extra_counters.get("case_workers") or 0)
            if isinstance(collision_state, dict) and int(collision_state.get("requests_total") or 0) != collision_expected:
                failure_reasons.append("collision case upstream request count did not match one active owner per attempt")
        if metrics.counters.get("turn_collision_rejected", 0) <= 0:
            blocked_reasons.append("collision probe did not surface the exact downstream rejection frame in this black-box run")
    if scenario in BASELINE_SCENARIOS:
        blocked_reasons.append("historic baseline is unavailable for p95 regression comparison")
    if scenario == "memory-bound":
        blocked_reasons.append("no explicit numeric RSS envelope is encoded in the plan")
    if scenario == "ws-abuse":
        blocked_reasons.append("benchmark proves black-box rejection behavior but not internal pre-parse/pre-redaction ordering")
    if scenario == "audit-contention":
        blocked_reasons.append("admin workload includes access-log writes, not pure reads, in the current control-plane design")
    verdict = "pass"
    if failure_reasons:
        verdict = "fail"
    elif blocked_reasons:
        verdict = "blocked"
    return {
        "matrix_id": row_id,
        "scenario": scenario,
        "duration_seconds": duration_seconds,
        "concurrency": concurrency,
        "requests": metrics.total,
        "successes": successes,
        "errors": metrics.errors,
        "error_rate": round(error_rate, 6),
        "throughput_rps": round((metrics.total / duration_seconds), 6) if duration_seconds > 0 else None,
        "success_throughput_rps": round((successes / duration_seconds), 6) if duration_seconds > 0 else None,
        "latency_ms": latency,
        "first_byte_ms": first_byte if metrics.first_byte_ms else None,
        "rss_kb": rss_summary,
        "error_statuses": dict(metrics.error_statuses),
        "close_codes": dict(metrics.close_codes),
        "counters": dict(metrics.counters),
        "process_log_counters": log_counters,
        "comparison": {
            "baseline_status": baseline_status,
            "threshold_status": threshold_status,
            "reason": comparison_reason,
        },
        "scenario_details": extra_counters,
        "verdict": verdict,
        "failure_reasons": failure_reasons,
        "blocked_reasons": blocked_reasons,
    }


def _scan_process_logs(cluster: BenchmarkCluster) -> dict[str, int]:
    text = "\n".join(
        process.stderr_text()
        for process in (cluster.upstream, cluster.proxy, cluster.admin)
        if process is not None
    )
    lowered = text.lower()
    return {
        "database_is_locked": lowered.count("database is locked"),
        "audit_retry_warnings": text.count("Audit batch flush failed; retrying pending batch."),
    }


async def _wait_for_admin_total_requests(
    cluster: BenchmarkCluster,
    *,
    expected_total: int,
) -> None:
    if expected_total <= 0 or cluster.admin_client is None:
        return
    deadline = time.monotonic() + 10.0
    while time.monotonic() < deadline:
        overview = await cluster.query_admin_overview()
        current_total = int(overview.get("total_requests") or 0)
        if current_total >= expected_total:
            return
        await asyncio.sleep(0.1)


async def _warmup_cluster(cluster: BenchmarkCluster, scenario: str) -> None:
    assert cluster.proxy_client is not None
    if scenario in {"http-chat", "audit-contention"}:
        await cluster.proxy_client.post(
            "/v1/chat/completions",
            json=_build_http_chat_payload(f"{_build_benchmark_prompt()} bench-warmup-chat"),
        )
    else:
        await cluster.proxy_client.post(
            "/v1/responses",
            json=_build_http_responses_payload(
                f"{_build_benchmark_prompt()} bench-warmup-responses",
                stream=False,
            ),
        )
    await cluster.reset_upstream_state()


def _load_baseline_metric(baseline_file: Path, scenario: str, metric_path: tuple[str, ...]) -> float | None:
    if not baseline_file.exists():
        return None
    payload = json.loads(baseline_file.read_text(encoding="utf-8"))
    entry = payload.get(scenario) if isinstance(payload, dict) else None
    if not isinstance(entry, dict):
        return None
    current: Any = entry
    for segment in metric_path:
        if not isinstance(current, dict):
            return None
        current = current.get(segment)
    return float(current) if isinstance(current, (int, float)) else None


def _write_baseline_metric(baseline_file: Path, summary: dict[str, Any]) -> None:
    scenario = str(summary["scenario"])
    payload: dict[str, Any] = {}
    if baseline_file.exists():
        existing = json.loads(baseline_file.read_text(encoding="utf-8"))
        if isinstance(existing, dict):
            payload = existing
    payload[scenario] = {
        "matrix_id": summary["matrix_id"],
        "latency_ms": summary["latency_ms"],
        "first_byte_ms": summary["first_byte_ms"],
        "written_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    baseline_file.parent.mkdir(parents=True, exist_ok=True)
    baseline_file.write_text(_json_dumps(payload, indent=2), encoding="utf-8")


def _apply_baseline(summary: dict[str, Any], baseline_file: Path | None) -> None:
    scenario = str(summary["scenario"])
    metric_path = ("first_byte_ms", "p95") if scenario == "sse-stream" else ("latency_ms", "p95")
    if baseline_file is None:
        return
    baseline_metric = _load_baseline_metric(baseline_file, scenario, metric_path)
    if baseline_metric is None:
        return
    current_metric = summary[metric_path[0]][metric_path[1]] if summary.get(metric_path[0]) else None
    if not isinstance(current_metric, (int, float)) or baseline_metric <= 0:
        return
    regression_pct = ((float(current_metric) - baseline_metric) / baseline_metric) * 100.0
    comparison = summary["comparison"]
    comparison["baseline_status"] = "loaded"
    comparison["threshold_status"] = "measured"
    comparison["threshold_pct"] = 10.0
    comparison["baseline_p95_ms"] = baseline_metric
    comparison["regression_pct"] = round(regression_pct, 6)
    comparison["reason"] = "compared against saved baseline file"
    blocked_reasons = [reason for reason in summary["blocked_reasons"] if "historic baseline" not in reason]
    summary["blocked_reasons"] = blocked_reasons
    if regression_pct > 10.0:
        comparison["threshold_status"] = "exceeded"
        summary["failure_reasons"].append(
            f"p95 regression exceeded 10% threshold: {round(regression_pct, 6)}%"
        )
        summary["verdict"] = "fail"
        return
    comparison["threshold_status"] = "within_threshold"
    if summary["verdict"] == "blocked" and not blocked_reasons and not summary["failure_reasons"]:
        summary["verdict"] = "pass"


def _parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Repo-local benchmark harness for stronk-mask.")
    parser.add_argument("--scenario", choices=sorted(DEFAULT_CONCURRENCY), help="Benchmark scenario.")
    parser.add_argument("--duration-seconds", type=float, help="Override scenario duration.")
    parser.add_argument("--concurrency", type=int, help="Override scenario concurrency.")
    parser.add_argument("--turns", type=int, default=DEFAULT_WS_TURNS, help="Turns per websocket session.")
    parser.add_argument("--json-indent", type=int, default=None, help="Pretty-print JSON output.")
    parser.add_argument("--result-json", type=Path, help="Optional path to write the JSON summary.")
    parser.add_argument("--baseline-file", type=Path, help="Optional path to read or write baseline JSON.")
    parser.add_argument("--write-baseline", action="store_true", help="Write the current summary as the scenario baseline.")
    parser.add_argument("--keep-artifacts", action="store_true", help="Keep the temp workspace instead of deleting it.")
    parser.add_argument(
        "--sample-rss-interval-ms",
        type=float,
        default=DEFAULT_SAMPLE_INTERVAL * 1000.0,
        help="RSS sample interval in milliseconds.",
    )
    parser.add_argument("--serve", choices=("upstream", "proxy", "admin"), help=argparse.SUPPRESS)
    parser.add_argument("--port", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--settings-json", type=str, help=argparse.SUPPRESS)
    return parser.parse_args(argv)


def _serve_process(role: Literal["upstream", "proxy", "admin"], port: int, settings_json: str | None) -> None:
    if role == "upstream":
        state = FakeUpstreamState()
        app = create_upstream_app(state)
    else:
        settings_kwargs = json.loads(settings_json) if settings_json else {}
        settings = Settings(**settings_kwargs)
        if role == "proxy":
            app = create_proxy_app(settings=settings)
        else:
            app = create_admin_app(settings=settings)
    uvicorn.run(
        app,
        host="127.0.0.1",
        port=port,
        log_level="warning",
        access_log=False,
        lifespan="on",
    )


async def _run_benchmark(args: argparse.Namespace) -> dict[str, Any]:
    scenario = args.scenario
    if scenario is None:
        raise ValueError("--scenario is required.")
    if args.write_baseline and args.baseline_file is None:
        raise ValueError("--write-baseline requires --baseline-file.")
    duration_seconds = float(args.duration_seconds or DEFAULT_DURATION_SECONDS[scenario])
    concurrency = int(args.concurrency or DEFAULT_CONCURRENCY[scenario])
    turns = int(args.turns or DEFAULT_WS_TURNS)
    tempdir = tempfile.TemporaryDirectory(prefix="stronk-mask-bench-")
    cluster = BenchmarkCluster(scenario=scenario, tempdir=tempdir)
    workspace_path = Path(cluster.tempdir.name)
    sampler: RssSampler | None = None
    sampler_task: asyncio.Task[None] | None = None
    try:
        await cluster.start()
        await _warmup_cluster(cluster, scenario)
        sampler = RssSampler(
            [process for process in (cluster.upstream, cluster.proxy, cluster.admin) if process is not None],
            interval_seconds=max(args.sample_rss_interval_ms / 1000.0, 0.01),
        )
        cluster.sampler = sampler
        sampler_task = asyncio.create_task(sampler.run())
        if scenario == "http-chat":
            summary = await _run_http_chat(cluster, duration_seconds=duration_seconds, concurrency=concurrency)
        elif scenario == "http-responses":
            summary = await _run_http_responses(
                cluster,
                duration_seconds=duration_seconds,
                concurrency=concurrency,
            )
        elif scenario == "sse-stream":
            summary = await _run_sse_stream(cluster, duration_seconds=duration_seconds, concurrency=concurrency)
        elif scenario == "ws-sequential":
            summary = await _run_ws_sequential(
                cluster,
                duration_seconds=duration_seconds,
                concurrency=concurrency,
                turns_per_session=turns,
            )
        elif scenario == "ws-abuse":
            summary = await _run_ws_abuse(
                cluster,
                duration_seconds=duration_seconds,
                concurrency=concurrency,
            )
        elif scenario == "audit-contention":
            summary = await _run_audit_contention(
                cluster,
                duration_seconds=duration_seconds,
                concurrency=concurrency,
            )
        elif scenario == "memory-bound":
            summary = await _run_memory_bound(
                cluster,
                duration_seconds=duration_seconds,
                concurrency=concurrency,
            )
        else:
            raise ValueError(f"unsupported scenario: {scenario}")
        _apply_baseline(summary, args.baseline_file)
        summary["artifacts"] = {
            "workspace": str(workspace_path),
            "workspace_retained": bool(args.keep_artifacts),
            "result_json": str(args.result_json) if args.result_json is not None else None,
            "baseline_file": str(args.baseline_file) if args.baseline_file is not None else None,
        }
        if args.write_baseline and args.baseline_file is not None:
            _write_baseline_metric(args.baseline_file, summary)
        if args.result_json is not None:
            _write_json_file(args.result_json, summary, indent=args.json_indent)
        return summary
    finally:
        if sampler is not None:
            sampler.stop()
        if sampler_task is not None:
            sampler_task.cancel()
            with suppress(asyncio.CancelledError):
                await sampler_task
        await cluster.close(keep_artifacts=args.keep_artifacts)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv or sys.argv[1:])
    if args.serve:
        if args.port is None:
            raise SystemExit("--port is required in serve mode.")
        _serve_process(args.serve, args.port, args.settings_json)
        return 0
    try:
        summary = asyncio.run(_run_benchmark(args))
    except Exception as exc:
        summary = {
            "scenario": args.scenario,
            "status": "failed",
            "error": str(exc),
        }
        if args.result_json is not None:
            _write_json_file(args.result_json, summary, indent=args.json_indent)
        print(_json_dumps(summary, indent=args.json_indent))
        return 1
    print(_json_dumps(summary, indent=args.json_indent))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
