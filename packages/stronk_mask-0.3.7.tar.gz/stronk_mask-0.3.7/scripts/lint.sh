#!/usr/bin/env zsh
set -euo pipefail

python3 -m ruff check .
python3 -m mypy src
