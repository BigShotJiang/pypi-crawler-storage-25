# Copyright 2023-2026 the contributors of APPXC (github.com/alexander-nbg/appxc)
# SPDX-License-Identifier: Apache-2.0
"""Aggregate single setting frames/windows into one interface

This module handles, in particular, SettingDict but aggregates all setting_*
modules.
"""

import math
import tkinter as tk
from collections.abc import Iterable, Mapping
from typing import Any, TypeAlias

from appxc import logging
from appxc.setting import Setting, SettingDict

from .common import AppxcGuiError, GridFrame, GridToplevel
from .setting_base import SettingFrameBase

# TODO: There is a matter of style open for displaying settings in a column.
# Should the labels be aligned or should the space rather be used for entries.
# What's the default setting and how to adjust?

SettingInput: TypeAlias = Setting | SettingDict | dict[str, Any] | Iterable[Setting]


def input_type_to_setting_dict(setting: SettingInput) -> SettingDict:
    """Convert allowed compound setting inputs to a SettingDict"""
    if isinstance(setting, SettingDict):
        return setting
    # The following two should also not already be a setting dict (which is
    # Iterable and Mapping). Dictionaries of settings are cast into a
    # SettingDict object:
    if isinstance(setting, Mapping):
        # Typing is ignored below since an Iterable[AppxcSetting] could
        # theoretically be a Mapping[AppxcSetting, Unknown] which would also
        # end up here. This is invalid input and not caught here.
        return SettingDict(settings=setting)  # type: ignore[assignment]
    # iterables of settings are also handled like SettingDict
    if isinstance(setting, Iterable) and not isinstance(setting, Mapping):
        return SettingDict(
            settings={
                this_setting.options.name: this_setting for this_setting in setting
            },
        )

    if isinstance(setting, Setting):
        return SettingDict(settings={setting.options.name: setting})

    raise AppxcGuiError(f"Input type unknown: {setting.__class__.__name__}")


class SettingDictSingleFrame(SettingFrameBase):
    """Frame holding SettingWidgets for an APPXC SettingDict.

    Changes are directly applied to the properties if they are valid. Consider
    using backup() on the properties before starting this frame and
    providing a cancel button that uses restore() on the config.
    """

    supports = (SettingDict,)
    log = logging.getLogger(__name__ + ".SettingDictSingleFrame")

    def __init__(
        self,
        parent: tk.BaseWidget,
        setting: SettingInput,
        frame_label: bool = True,
        **kwargs,
    ):

        if frame_label and setting.options.name:
            super().__init__(parent, **kwargs, text=setting.options.name)
        else:
            super().__init__(parent, **kwargs)
        setting = input_type_to_setting_dict(setting)

        # strip properties from the dict that are not mutable:
        self.setting_dict = {
            key: setting.get_setting(key)
            for key in setting
            if setting.get_setting(key).options.mutable
        }
        # TODO: the above should be applied according to visibility. Not
        # mutable should still be displayed but grayed out or not editable.

        self.columnconfigure(0, weight=1)
        # rowconfigure in the loop below

        # TODO: element_gui_options does not do anything anymore. Given the
        # usage in _place_property_frame() it was intended to  allow
        # overwriting the usage of checkboxes for booleans. Once the remarks on
        # default_visibility are resolved, the new concept may incorporate this
        # setting as well.
        element_gui_options = {}
        self.frame_list: list[SettingFrameBase] = []
        for key, this_setting in self.setting_dict.items():
            self._place_setting_frame(this_setting, element_gui_options.get(key, {}))

    def _place_setting_frame(self, setting: Setting, gui_options):
        if "frame_type" in gui_options:
            setting_frame = gui_options["frame_type"](self, setting, gui_options)
        setting_frame = GridFrame.get_frame(self, setting, **gui_options)
        self.place(setting_frame, row=len(self.frame_list), column=0)
        # apply row weight from underlying frame:
        self.rowconfigure(
            len(self.frame_list),
            weight=setting_frame.get_total_row_weight(),
        )

        self.frame_list.append(setting_frame)

    def get_left_col_min_width(self) -> int:
        """Get minimum width of left column.

        Can only be called after placing the widget (e.g. using grid()).

        Example:
        ```
            w = SettingDictFrame(root, property_dict)
            w.grid(row=0, column=0)
            min_width = w.get_left_col_min_width()
        ```

        """
        # TODO: docstring above is not correct anymore after grid() is
        # substituted by place(). When touching this, I may reconsider
        # overwriting grid() (and pack() and the other placing mechanisms).
        # There is no need for a new naming.
        self.winfo_toplevel().update()
        n_rows = self.grid_size()[1]
        # get minimum size
        min_size = 0
        for i_row in range(n_rows):
            # Get the ConfigOptionWidget of the row
            config_option_widget = self.grid_slaves(row=i_row, column=0)[0]
            # get the label
            label_widget = config_option_widget.grid_slaves(row=0, column=0)[0]
            # get label size
            size = label_widget.winfo_width()
            # update min size
            min_size = max(min_size, size)
        # we can simply add 10 here since we know the hard coded
        # padding.
        return min_size + 10

    def set_left_column_min_width(self, width: int):
        n_rows = self.grid_size()[1]
        for i_row in range(n_rows):
            widgets = self.grid_slaves(row=i_row, column=0)
            for widget in widgets:
                widget.columnconfigure(0, minsize=width)

    def adjust_left_columnwidth(self):
        """Get left labels aligned.

        Can only be called after placing the widget (e.g. using grid()). You
        also need to update the root before doing so. Example:
        ```
            w = SettingDictFrame(root, property_dict)
            w.grid(row=0, column=0)
            w.winfo_toplevel().update()
            w.adjust_left_columnwidth()
        ```
        """
        min_size = self.get_left_col_min_width()
        self.set_left_column_min_width(min_size)

    def focus_curser_on_first_entry(self):
        if self.frame_list:
            self.frame_list[0].focus_set()

    def is_valid(self) -> bool:
        valid = True
        for setting_frame in self.frame_list:
            valid &= setting_frame.is_valid()
        return valid

    def update(self):
        # forward update to maintained setting frames:
        for setting_frame in self.frame_list:
            setting_frame.update()
        super().update()


class SettingDictColumnFrame(SettingFrameBase):
    def __init__(
        self,
        parent: tk.BaseWidget,
        setting: SettingInput,
        columns: int,
        appxc_options: dict | None = None,
        frame_label: bool = True,
        **kwargs,
    ):
        # kwargs is NOT passed down to THIS frame. It will be passed down to
        # the column frames. This is hopefully more likely what a user might
        # want.
        super().__init__(parent)
        setting = input_type_to_setting_dict(setting)

        if appxc_options is None:
            appxc_options = {}

        key_list = list(setting.keys())
        direction = appxc_options.get("column_direction", "down")
        if direction == "down":
            items_per_col = math.ceil(len(key_list) / columns)
            key_to_sub_dict = [int(i / items_per_col) for i in range(len(key_list))]
        elif direction == "right":
            key_to_sub_dict = [i % columns for i in range(len(key_list))]
        else:
            raise ValueError(
                f'"column_direction" only supports "down" or '
                f'"right", you provided "{direction}"',
            )

        # fill property dictionaries
        prop_dict_list = [SettingDict() for i in range(columns)]
        for i, key in enumerate(key_list):
            prop_dict_list[key_to_sub_dict[i]][key] = setting.get_setting(key)

        # build up frames
        self.frame_list: list[SettingDictSingleFrame] = []
        max_row_weight_over_columns = 0
        for prop_dict in prop_dict_list:
            self.columnconfigure(len(self.frame_list), weight=1)
            this_frame = SettingDictSingleFrame(
                self,
                prop_dict,
                frame_label=False,
                **kwargs,
            )
            self.place(this_frame, row=0, column=len(self.frame_list))
            self.frame_list.append(this_frame)
            max_row_weight_over_columns = max(
                max_row_weight_over_columns,
                this_frame.get_total_row_weight(),
            )
        # column weights are configured above in the for loop. The weight of
        # the one row containing all columns equals the maximum row weight of
        # the columns. If no column needs vertical resizing, this ColumnFrame
        # would also not need resizing. If a single row needs resizing, the
        # other settings would spread out likewise.
        self.rowconfigure(0, weight=max_row_weight_over_columns)

    def adjust_left_columnwidth(self):
        for frame in self.frame_list:
            frame.adjust_left_columnwidth()

    def focus_set(self):
        self.frame_list[0].focus_set()

    def is_valid(self):
        valid = True
        for frame in self.frame_list:
            valid &= frame.is_valid()
        return valid


class SettingDictWindow(GridToplevel):
    """Display dialog for Settings or Setting dicts"""

    log = logging.getLogger(__name__ + ".SettingDictWindow")

    def __init__(
        self,
        parent,
        title: str,
        setting: Setting | SettingDict,
        appxc_options: dict | None = None,
        **kwargs,
    ):
        """Create GUI window to edit a dictionary of properties."""
        super().__init__(
            parent,
            title=title,
            buttons=["Cancel", "OK"],
            key_enter_as_button="OK",
            **kwargs,
        )
        if appxc_options is None:
            appxc_options = {}
        # Whole class operated on SettingDict and a single setting is just cast
        # up to a SettingDict to handle it (required to obtain store/load
        # behavior for backup&restore upon cancel)
        if isinstance(setting, SettingDict):
            self.property_dict = setting
        elif isinstance(setting, Setting):
            self.property_dict = SettingDict(settings={setting.options.name: setting})
        else:
            raise AppxcGuiError(
                f"Setting must be AppxcSetting or SettingDict but is {type(setting)}",
            )
        # Ensure values are stored. If congiuration fails, values will be
        # reloaded.
        self.property_dict.store()

        columns = appxc_options.get("columns", 1)
        if columns <= 1:
            self.dict_frame = SettingDictSingleFrame(
                self,
                self.property_dict,
                frame_label=False,
                row_spread=True,
                **appxc_options,
            )
        else:
            self.dict_frame = SettingDictColumnFrame(
                self,
                self.property_dict,
                columns,
                appxc_options,
                frame_label=False,
                row_spread=True,
            )
        self.place_frame(self.dict_frame)
        self.update()
        self.dict_frame.adjust_left_columnwidth()

        self.bind("<<Cancel>>", lambda _event: self._handle_cancel_button())
        self.bind("<<OK>>", lambda _event: self._handle_ok_button())

    def _handle_ok_button(self):
        self.log.debug("OK")
        if self.dict_frame.is_valid():
            self.property_dict.store()
            self.destroy()
        else:
            self.log.debug('Cannot "OK", config not valid')

    def _handle_cancel_button(self):
        self.log.debug("Cancel")
        self.property_dict.load()
        self.destroy()
