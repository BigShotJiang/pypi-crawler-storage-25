"""classspace - Python class utilities"""

from .classspace import StaticSpace, withoutdec, DecorateClass, classenum, LabelEnum

__all__ = [
    "StaticSpace",
    "withoutdec", 
    "DecorateClass",
    "classenum",
    "LabelEnum",
]
__version__ = "0.1.0"
