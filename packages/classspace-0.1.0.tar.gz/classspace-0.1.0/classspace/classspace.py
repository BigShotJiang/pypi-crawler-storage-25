"class space"
class StaticSpace:
    """all method is static,like a function bag"""
    
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        
        # 防止实例化
        cls.__new__ = staticmethod(lambda *a, **k: cls._raise_instantiation_error())
        
        # 自动静态化
        for name, method in cls.__dict__.items():
            if callable(method) and not name.startswith('_'):
                setattr(cls, name, staticmethod(method))
    
    @classmethod
    def _raise_instantiation_error(cls):
        raise TypeError(f"'{cls.__name__}' is a static space and cannot be instantiated")
class withoutdec:
    '''delete decorate from DecorateClass'''
    def __init__(self, func):
        self.func = func
        self.skip_decorator = True

class DecorateClass:
    '''put decorate in all methods'''
    def __new__(cls, decorator=None):
        if decorator is None:
            decorator = lambda f: f
        
        class DecoratedBase(cls):
            @classmethod
            def _get_default_decorator(cls):
                return decorator
        
        return DecoratedBase
    
    @classmethod
    def _get_default_decorator(cls):
        return lambda f: f
    
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        decorator = cls._get_default_decorator()
        
        for name, method in list(cls.__dict__.items()):
            if not name.startswith('_') and callable(method):
                if hasattr(method, 'skip_decorator'):
                    setattr(cls, name, method.func)
                else:
                    setattr(cls, name, decorator(method))

class classenum:
    """keep member in LabelEnum Class"""
    def __init__(self, cls):
        self.cls = cls
        self.cls._classenum_marker = True

class LabelEnum:
    """an enum with methods"""
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        
        for name, nested_cls in list(cls.__dict__.items()):
            if not name.startswith('_') and isinstance(nested_cls, type):
                if hasattr(nested_cls, '_classenum_marker'):
                    # 保持为类
                    setattr(cls, name, nested_cls)
                else:
                    # 默认：实例化为单例
                    setattr(cls, name, nested_cls())
