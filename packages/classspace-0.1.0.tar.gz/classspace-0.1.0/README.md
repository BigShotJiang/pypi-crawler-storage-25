# classspace

Python 类工具库：静态空间、装饰器包装、枚举类

## 安装

pip install classspace

## 使用示例

### StaticSpace

from classspace import StaticSpace

class Mathpart(StaticSpace):
    def sqrt(x):
        return x**0.5
    def square(x):
        return x**2

class Stringpart(StaticSpace):
    def isin(a, b):
        return a in b

a = Mathpart.sqrt(2)
b = Stringpart.isin('a', 'apple')
# 不能实例化：Mathpart() 会报错

### DecorateClass

from classspace import DecorateClass, withoutdec

def timer(func):
    def wrapper(*a, **k):
        import time
        start = time.time()
        res = func(*a, **k)
        print(f"耗时: {time.time()-start}")
        return res
    return wrapper

class MyClass(DecorateClass(timer)):
    def heavy():
        print("doing heavy work...")

MyClass.heavy()

### LabelEnum

from classspace import LabelEnum, classenum

class Color(LabelEnum):
    class red: pass
    class blue: pass

print(Color.red)  # <object……>

## 许可证

MIT