# Zil

A framework for production AI agents.

Zil composes with [ADK](https://google.github.io/adk-docs/), [A2A](https://google.github.io/A2A/), [MCP](https://modelcontextprotocol.io/), [DeepEval](https://github.com/confident-ai/deepeval), and [OpenTelemetry](https://opentelemetry.io/) to provide a declarative manifest format and CLI for building, validating, packaging, and deploying AI agents.

## Install

```bash
pip install zil-ai
```

## Quick start

```bash
# Scaffold a new agent project
zil init my-agent
cd my-agent

# Validate the project
zil validate

# Package for deployment
zil pack

# Inspect a package
zil inspect dist/my-agent-0.1.0.zil
```

## Documentation

- [Getting Started](https://getzil.dev/docs/getting-started)
- [CLI Reference](https://getzil.dev/docs/cli)
- [Full Documentation](https://getzil.dev/docs)

## License

Apache-2.0
