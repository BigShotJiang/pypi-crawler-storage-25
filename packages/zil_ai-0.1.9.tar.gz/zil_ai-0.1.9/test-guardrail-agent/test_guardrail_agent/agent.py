"""
test-guardrail-agent — Main agent entry point.

Built with Zil (https://getzil.dev) using the ADK framework.
Run locally:  zil run
ADK web UI:   zil web
"""

from pathlib import Path

import zil


# Define your tools here — each is a plain Python function.
# def lookup_order(order_id: str) -> dict:
#     """Look up an order by ID."""
#     return {"order_id": order_id, "status": "shipped"}


# Create the agent. Zil reads manifest.yaml, identity/, and adapters/
# automatically and wires them into an ADK LlmAgent.
root_agent = zil.create_agent(
    tools=[],  # add your tool functions here
    project_dir=Path(__file__).parent,
)
