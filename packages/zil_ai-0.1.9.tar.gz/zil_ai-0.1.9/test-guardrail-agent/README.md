# test-guardrail-agent

A production AI agent built with [Zil](https://getzil.dev).

## Quick start

```bash
# Validate the project
zil validate

# Run the agent locally (CLI)
zil run

# Run the agent with ADK web UI
zil web

# Package for deployment
zil pack

# Inspect the package
zil inspect dist/test-guardrail-agent-0.1.0.zil
```

## Project layout

```
test-guardrail-agent/
├── manifest.yaml          # Zil agent manifest
├── test_guardrail_agent/       # ADK agent module
│   ├── __init__.py
│   ├── agent.py           # Agent entry point
│   └── .env.example       # API key template
├── adapters/              # LLM and embedding configuration
│   ├── llm.yaml
│   └── embed.yaml
├── identity/              # Agent persona, instructions, guardrails
│   ├── persona.md
│   ├── instructions.md
│   └── guardrails.yaml
├── evals/                 # Evaluation suite
│   ├── baseline.yaml
│   └── cases/
├── observability/         # OpenTelemetry configuration
│   └── config.yaml
├── Dockerfile             # Container build
└── .github/workflows/     # CI/CD pipeline
```

## Customization

1. Edit `identity/persona.md` to define who the agent is
2. Edit `identity/instructions.md` to define how the agent behaves
3. Edit `identity/guardrails.yaml` to set hard rules
4. Configure your LLM in `adapters/llm.yaml` and copy `.env.example` to `.env`
5. Add eval cases in `evals/cases/`

## Deployment

This project is configured for **cloud-run** deployment.
See the Dockerfile and `.github/workflows/zil-pipeline.yaml`.
