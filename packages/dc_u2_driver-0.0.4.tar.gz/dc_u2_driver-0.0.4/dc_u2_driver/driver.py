"""
U2Automator - A helper class for interacting with Android devices via uiautomator2.

Features:
- Connects to a device by ID
- Filters English text from UI elements
- Interacts with elements using multiple locator types
- Handles clicks, long clicks, text input, and attribute retrieval
- Includes retries and post-wait timing for stability

Credit: Developed by Dai Chao Online
"""

import logging
import random
import re
from time import sleep

import uiautomator2 as u2
from urllib3.exceptions import MaxRetryError, NewConnectionError, ProtocolError


class DeviceConnectionError(Exception):
    pass


class U2Driver:
    def __init__(self, device_id: str):
        self.driver = None
        if device_id:
            try:
                self.driver = u2.connect(device_id)
            except (
                MaxRetryError,
                NewConnectionError,
                ProtocolError,
                ConnectionResetError,
            ) as e:
                logging.error(f"Failed to connect to device {device_id}: {e}")
                raise DeviceConnectionError(
                    f"Cannot connect to device {device_id}"
                ) from e

    @staticmethod
    def is_english(text: str):
        if not text:
            return False
        try:
            return all(ord(c) < 128 for c in text)
        except (TypeError, ValueError):
            return False

    def _filter_names(self, texts: str):
        filtered = []
        for t in texts:
            if not t:
                continue

            low = t.lower()
            if (
                "notification" in low
                or "accounts center" in low
                or "create facebook profile" in low
                or "your instagram profile" in low
            ):
                continue

            if not self.is_english(t):
                continue

            filtered.append(t)
        return filtered

    def work_on_element(
        self,
        wait: int,
        locatorValue: str,
        locatorType="xpath",
        isJustWait=False,
        textInput=None,
        index=None,
        isLongClick=False,
        get_attribute=False,
        attribute=None,
        get_all=False,
        status=False,
        element=None,
        filter_result=False,
        post_wait=0.3,
        click_retry=3,
            use_bounds=False,
            double_click=False
    ):
        def _wait_for_clickable(el, timeout=2.0, interval=0.3):
            elapsed = 0
            while elapsed < timeout:
                if el.exists and el.info.get("enabled", False):
                    return True
                sleep(interval)
                elapsed += interval
            return False

        try:
            if locatorType.lower() == "bounds":
                nums = re.findall(r"\d+", locatorValue)
                if len(nums) == 4:
                    x1, y1, x2, y2 = map(int, nums)
                    center_x = (x1 + x2) // 2
                    center_y = (y1 + y2) // 2
                    sleep(post_wait)
                    if isLongClick:
                        self.driver.long_click(center_x, center_y)
                    else:
                        self.driver.click(center_x, center_y)
                    return True
                return False

            if not element:
                locatorType = locatorType.lower()
                selector = None  # noqa

                if locatorType == "xpath":
                    selector = self.driver.xpath(locatorValue)
                elif locatorType == "text":
                    selector = self.driver(text=locatorValue)
                elif locatorType == "class":
                    selector = self.driver(className=locatorValue)
                elif locatorType == "des":
                    selector = self.driver(description=locatorValue)
                else:
                    kwargs = {locatorType: locatorValue}
                    selector = self.driver(**kwargs)

                if not selector.wait(timeout=wait):
                    return False if status else None

                if get_all:
                    elements = selector.all()
                    if get_attribute and attribute:
                        texts = [el.info.get(attribute) for el in elements]
                        return self._filter_names(texts) if filter_result else texts
                    return elements

                if index is not None:
                    if selector.count > index:
                        element = selector[index]
                    else:
                        logging.error(
                            f"Index {index} is out of bounds. Found {selector.count} elements."
                        )
                        return None
                else:
                    element = selector

            target_element = element
            sleep(post_wait)

            if not target_element:
                return False if status else None

            if status:
                return target_element.exists

            if isJustWait:
                return target_element

            if get_attribute and attribute:
                value = target_element.info.get(attribute)
                if filter_result and isinstance(value, str):
                    filtered = self._filter_names([value])
                    return filtered[0] if filtered else None
                return value

            if textInput is not None:
                target_element.set_text(textInput)
                return target_element

            if use_bounds:
                b = target_element.info.get("bounds")
                if b:
                    cx = (b["left"] + b["right"]) // 2 + random.randint(-2, 2)
                    cy = (b["top"] + b["bottom"]) // 2 + random.randint(-2, 2)
                    if isLongClick:
                        self.driver.long_click(cx, cy)
                    else:
                        self.driver.click(cx, cy)
                    return target_element

            if isLongClick:
                target_element.long_click()
                return target_element

            if double_click:
                b = target_element.info.get('bounds')
                self.driver.double_click((b['left'] + b['right']) // 2, (b['top'] + b['bottom']) // 2)
                return target_element

            if not _wait_for_clickable(target_element, timeout=2):
                logging.warning("Element not clickable after waiting")
                return None

            for attempt in range(click_retry):
                try:
                    sleep(random.uniform(0.1, 0.3))
                    target_element.click()
                    break
                except Exception as e:
                    logging.warning(f"Click attempt {attempt+1} failed: {e}")
                    sleep(0.1)

            return target_element

        except (
            MaxRetryError,
            NewConnectionError,
            ProtocolError,
            ConnectionResetError,
        ) as e:
            raise RuntimeError(
                f"Device connection error while interacting with element: {e}"
            ) from e
        except Exception as e:
            logging.error(f"Error while interacting with element: {e}")
            return None
