"""Agno prompt resource for reusable instruction templates."""

from __future__ import annotations

import re

from pragma_sdk import Config, Field, Outputs
from pydantic import model_validator

from agno_provider.resources.base import AgnoResource, AgnoSpec


class PromptSpec(AgnoSpec):
    """Specification for a rendered prompt.

    Attributes:
        instructions: The list of instruction lines.
        variables: Template variables used for interpolation.
        rendered: The final rendered instructions string.
    """

    instructions: list[str]
    variables: dict[str, str] | None = None
    rendered: str


class PromptConfig(Config):
    """Configuration for a reusable prompt template.

    Attributes:
        instructions: List of instruction lines to join with newlines.
        variables: Variable values for template interpolation.
        template: Template string with {{variable}} placeholders.
    """

    instructions: Field[list[str]] = []
    variables: Field[dict[str, str]] = {}
    template: Field[str] | None = None

    @model_validator(mode="after")
    def validate_content(self) -> PromptConfig:
        """Validate that content is provided and variables are complete.

        Returns:
            The validated config instance.

        Raises:
            ValueError: If neither instructions nor template provided,
                or if template references undefined variables.
        """
        if not self.instructions and not self.template:
            msg = "At least one of 'instructions' or 'template' must be provided"
            raise ValueError(msg)

        if self.template:
            placeholders = set(re.findall(r"\{\{(\w+)\}\}", self.template))
            missing = placeholders - set(self.variables.keys())
            if missing:
                msg = f"Missing variables for template placeholders: {sorted(missing)}"
                raise ValueError(msg)

        return self


class PromptOutputs(Outputs):
    """Outputs from prompt resource.

    Attributes:
        spec: The prompt specification with instructions, variables, and rendered text.
    """

    spec: PromptSpec


class Prompt(AgnoResource[PromptConfig, PromptOutputs, PromptSpec]):
    """Reusable prompt template resource.

    Stateless resource (Pragmatiks addition, not in Agno SDK) that enables
    prompt reuse and versioning. The rendered text is available via from_spec().

    Template syntax:
        Use {{variable}} for interpolation. Variables must be defined
        in the 'variables' dict.

    Rendering:
        - If only instructions: join with newlines
        - If only template: interpolate variables
        - If both: interpolate template, append to instructions

    Runtime reconstruction via spec:
        rendered = Prompt.from_spec(spec)

    Lifecycle:
        - on_create: Render and return outputs
        - on_update: Re-render with new config
        - on_delete: No-op (stateless)
    """

    @staticmethod
    def from_spec(spec: PromptSpec) -> str:
        """Factory: return rendered instructions from spec.

        Args:
            spec: The prompt specification.

        Returns:
            The rendered instructions string.
        """
        return spec.rendered

    def _render(self) -> str:
        """Render the prompt text.

        Returns:
            Rendered prompt text with variables interpolated.
        """
        parts: list[str] = []

        if self.config.instructions:
            parts.append("\n".join(self.config.instructions))

        if self.config.template:
            rendered = self.config.template
            for key, value in self.config.variables.items():
                rendered = rendered.replace(f"{{{{{key}}}}}", value)
            parts.append(rendered)

        return "\n".join(parts)

    def _build_spec(self) -> PromptSpec:
        """Build the prompt specification with rendered instructions.

        Returns:
            PromptSpec with instructions, variables, and rendered text.
        """
        rendered = self._render()
        variables = self.config.variables if self.config.variables else None

        return PromptSpec(
            instructions=self.config.instructions,
            variables=variables,
            rendered=rendered,
        )

    def _build_outputs(self) -> PromptOutputs:
        """Build outputs from current config.

        Returns:
            PromptOutputs with spec.
        """
        return PromptOutputs(spec=self._build_spec())

    async def on_create(self) -> PromptOutputs:
        """Create resource and return rendered outputs.

        Returns:
            PromptOutputs with rendered text and instruction count.
        """
        return self._build_outputs()

    async def on_update(self, previous_config: PromptConfig) -> PromptOutputs:  # noqa: ARG002
        """Update resource and return re-rendered outputs.

        Args:
            previous_config: The previous configuration (unused for stateless resource).

        Returns:
            PromptOutputs with updated rendered text.
        """
        return self._build_outputs()

    async def on_delete(self) -> None:
        """Delete is a no-op since this resource is stateless."""

    @classmethod
    def upgrade(cls, config: dict, outputs: dict) -> tuple[dict, dict]:  # noqa: D102
        return config, outputs

    @classmethod
    def downgrade(cls, config: dict, outputs: dict) -> tuple[dict, dict]:  # noqa: D102
        return config, outputs
