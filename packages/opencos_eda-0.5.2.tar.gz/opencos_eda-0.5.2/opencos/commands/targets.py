'''opencos.commands.targets - command handler for: eda targets [args]

Note this command is handled differently than others (such as CommandSim),
it is generally run as simply

    > eda targets
    > eda targets <directory>
    > eda targets [directory/]<pattern> [directory2/]<pattern2> ...

uses no tools and will print a pretty list of targets to stdout.
'''

# Note - similar code waiver, tricky to eliminate it with inheritance when
# calling reusable methods.
# pylint: disable=R0801

import os

from opencos import eda_extract_targets, util
from opencos.eda_base import Command


class CommandTargets(Command):
    '''command handler for: eda targets'''

    command_name = 'targets'

    def __init__(self, config: dict):
        super().__init__(config)
        self.args = {} # clear args, "eda targets" does not support them.
        self.args_help = {}
        self.status = 0

    def process_tokens( # pylint: disable=unused-argument
        self, tokens: list, process_all: bool = True,
        pwd: str = os.getcwd()
    ) -> list:
        '''This is effectively our 'run' method, entrypoint from opencos.eda.main'''

        # disable artifacts, logging is disabled by eda.py adding 'deps-help' to:
        #   util.global_log.default_log_disable_with_args
        util.artifacts.enabled = False

        # Since we need the 'targets', call Command.process_tokens with
        # process_all=False:
        unparsed = super().process_tokens(tokens=tokens, process_all=False, pwd=pwd)
        eda_extract_targets.run(partial_paths=unparsed, base_path=pwd)
        return []
