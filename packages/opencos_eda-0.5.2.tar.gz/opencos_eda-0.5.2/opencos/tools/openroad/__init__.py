'''Collection of files for --tool=openroad

openroad/
 |
 |- handler.py
 |- sh/
 |    |- run_eda.sh
 |    |- analyze_results.sh
 |- tcl/
      |- sta.tcl
      |- pnr_basic.tcl
      |- syn_basic.tcl
      |- run_openroad_placement.tcl
      |- (and others!)
'''
