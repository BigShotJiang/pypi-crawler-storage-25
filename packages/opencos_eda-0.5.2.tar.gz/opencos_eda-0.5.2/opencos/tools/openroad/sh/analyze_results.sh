#!/bin/bash
# analyze_results.sh
# Helper script to analyze timing_comparison.csv results

CSV_FILE="${1:-timing_comparison.csv}"

if [ ! -f "$CSV_FILE" ]; then
    echo "Error: CSV file not found: $CSV_FILE"
    echo "Usage: $0 [csv_file]"
    exit 1
fi

echo "=========================================="
echo "Synthesis Sweep Results Analysis"
echo "=========================================="
echo "CSV file: $CSV_FILE"
echo ""

# Count total configurations
total_configs=$(tail -n +2 "$CSV_FILE" | wc -l | tr -d ' ')
echo "Total configurations tested: $total_configs"
echo ""

# ============================================================================
# WNS Analysis
# ============================================================================
echo "=========================================="
echo "Top 10 Configurations by WNS (Best Timing)"
echo "=========================================="
echo ""
echo "Rank | Config | WNS | TNS | NFE | OPT | FLAT | SHARE | ABC | RETIME"
echo "-----|--------|-----|-----|-----|-----|------|-------|-----|-------"

tail -n +2 "$CSV_FILE" | \
    sort -t',' -k12 -rn | \
    head -10 | \
    awk -F',' 'NR<=10 {printf "%4d | %s | %7.3f | %8.3f | %4d | %3d | %4d | %5d | %3d | %6d\n",
        NR, substr($1,1,30), $12, $13, $14, $2, $3, $4, $5, $6}'

echo ""

# ============================================================================
# TNS Analysis
# ============================================================================
echo "=========================================="
echo "Top 10 Configurations by TNS (Best Overall)"
echo "=========================================="
echo ""
echo "Rank | Config | WNS | TNS | NFE | OPT | FLAT | SHARE | ABC | RETIME"
echo "-----|--------|-----|-----|-----|-----|------|-------|-----|-------"

tail -n +2 "$CSV_FILE" | \
    sort -t',' -k13 -rn | \
    head -10 | \
    awk -F',' 'NR<=10 {printf "%4d | %s | %7.3f | %8.3f | %4d | %3d | %4d | %5d | %3d | %6d\n",
        NR, substr($1,1,30), $12, $13, $14, $2, $3, $4, $5, $6}'

echo ""

# ============================================================================
# NFE Analysis
# ============================================================================
echo "=========================================="
echo "Top 10 Configurations by NFE (Fewest Failures)"
echo "=========================================="
echo ""
echo "Rank | Config | WNS | TNS | NFE | OPT | FLAT | SHARE | ABC | RETIME"
echo "-----|--------|-----|-----|-----|-----|------|-------|-----|-------"

tail -n +2 "$CSV_FILE" | \
    sort -t',' -k14 -n | \
    head -10 | \
    awk -F',' 'NR<=10 {printf "%4d | %s | %7.3f | %8.3f | %4d | %3d | %4d | %5d | %3d | %6d\n",
        NR, substr($1,1,30), $12, $13, $14, $2, $3, $4, $5, $6}'

echo ""

# ============================================================================
# Parameter Impact Analysis
# ============================================================================
echo "=========================================="
echo "Parameter Impact on WNS (Average by Parameter Value)"
echo "=========================================="
echo ""

# ABC_SCRIPT impact
echo "ABC_SCRIPT Impact:"
echo "Value | Avg WNS | Count"
echo "------|---------|------"
for val in 0 1 2 3 4 5; do
    result=$(tail -n +2 "$CSV_FILE" | awk -F',' -v abc=$val '$5 == abc {sum+=$12; count++} END {if(count>0) printf "%5d | %7.3f | %5d\n", abc, sum/count, count}')
    if [ -n "$result" ]; then
        echo "$result"
    fi
done
echo ""

# RETIME_MODE impact
echo "RETIME_MODE Impact:"
echo "Value | Avg WNS | Count"
echo "------|---------|------"
for val in 0 1 2; do
    result=$(tail -n +2 "$CSV_FILE" | awk -F',' -v rt=$val '$6 == rt {sum+=$12; count++} END {if(count>0) printf "%5d | %7.3f | %5d\n", rt, sum/count, count}')
    if [ -n "$result" ]; then
        echo "$result"
    fi
done
echo ""

# OPT_LEVEL impact
echo "OPT_LEVEL Impact:"
echo "Value | Avg WNS | Count"
echo "------|---------|------"
for val in 0 1 2 3 4; do
    result=$(tail -n +2 "$CSV_FILE" | awk -F',' -v opt=$val '$2 == opt {sum+=$12; count++} END {if(count>0) printf "%5d | %7.3f | %5d\n", opt, sum/count, count}')
    if [ -n "$result" ]; then
        echo "$result"
    fi
done
echo ""

# FLATTEN_MODE impact
echo "FLATTEN_MODE Impact:"
echo "Value | Avg WNS | Count"
echo "------|---------|------"
for val in 0 1 2; do
    result=$(tail -n +2 "$CSV_FILE" | awk -F',' -v flat=$val '$3 == flat {sum+=$12; count++} END {if(count>0) printf "%5d | %7.3f | %5d\n", flat, sum/count, count}')
    if [ -n "$result" ]; then
        echo "$result"
    fi
done
echo ""

# ============================================================================
# Statistics Summary
# ============================================================================
echo "=========================================="
echo "Overall Statistics"
echo "=========================================="

stats=$(tail -n +2 "$CSV_FILE" | awk -F',' '
{
    wns = $12
    tns = $13
    nfe = $14

    if (NR == 2 || wns > max_wns) max_wns = wns
    if (NR == 2 || wns < min_wns) min_wns = wns
    sum_wns += wns

    if (NR == 2 || tns > max_tns) max_tns = tns
    if (NR == 2 || tns < min_tns) min_tns = tns
    sum_tns += tns

    if (nfe == 0) configs_meeting_timing++

    count++
}
END {
    printf "Best WNS:               %8.3f\n", max_wns
    printf "Worst WNS:              %8.3f\n", min_wns
    printf "Average WNS:            %8.3f\n", sum_wns/count
    printf "WNS Range:              %8.3f\n", max_wns - min_wns
    printf "\n"
    printf "Best TNS:               %8.3f\n", max_tns
    printf "Worst TNS:              %8.3f\n", min_tns
    printf "Average TNS:            %8.3f\n", sum_tns/count
    printf "\n"
    printf "Configs meeting timing: %8d (%.1f%%)\n", configs_meeting_timing, 100*configs_meeting_timing/count
    printf "Configs failing timing: %8d (%.1f%%)\n", count-configs_meeting_timing, 100*(count-configs_meeting_timing)/count
}')

echo "$stats"
echo ""

# ============================================================================
# Recommendations
# ============================================================================
echo "=========================================="
echo "Recommendations"
echo "=========================================="
echo ""

best_config=$(tail -n +2 "$CSV_FILE" | sort -t',' -k12 -rn | head -1 | cut -d',' -f1)
best_wns=$(tail -n +2 "$CSV_FILE" | sort -t',' -k12 -rn | head -1 | cut -d',' -f12)

echo "Best overall configuration: $best_config"
echo "Best WNS achieved: $best_wns"
echo ""

if awk -v wns="$best_wns" 'BEGIN {exit !(wns >= 0)}'; then
    echo "Status: TIMING MET - Design meets timing constraints!"
else
    echo "Status: TIMING VIOLATED - Consider:"
    echo "  1. Use ABC_SCRIPT=4 or 5 for aggressive delay optimization"
    echo "  2. Enable RETIME_MODE=1 or 2 for pipelined designs"
    echo "  3. Use FLATTEN_MODE=2 for maximum optimization opportunity"
    echo "  4. Try OPT_LEVEL=3 or 4 for more aggressive optimization"
    echo "  5. Enable ALUMINUM_REDUCE=2 for arithmetic-heavy designs"
fi
echo ""

echo "=========================================="
echo "Analysis complete!"
echo "=========================================="
