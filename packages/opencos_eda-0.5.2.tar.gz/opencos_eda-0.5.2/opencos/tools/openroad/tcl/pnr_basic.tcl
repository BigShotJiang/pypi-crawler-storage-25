puts "\[DATE\]: [clock format [clock seconds] -format "%d-%m-%Y_%H:%M:%S"]"
# Read liberty files (may be space-delimited for multi-lib PDKs)
foreach _lib $::env(LIBERTY_FILE) {
    read_liberty $_lib
}
read_lef $::env(LEF_TECH_FILE)
foreach _lef $::env(LEF_FILE) {
    read_lef $_lef
}

puts "\[DATE\]: [clock format [clock seconds] -format "%d-%m-%Y_%H:%M:%S"]"
read_verilog $::env(OUT_DIR)/$::env(TOP_MODULE)_$::env(FILE_SUFFIX).syn.v
link_design $::env(TOP_MODULE)
#read_sdc $::env(SDC_FILE)

puts "\[DATE\]: [clock format [clock seconds] -format "%d-%m-%Y_%H:%M:%S"]"
initialize_floorplan -utilization 65 -aspect_ratio 1.0 -core_space 10.0 -site unit

puts "\[DATE\]: [clock format [clock seconds] -format "%d-%m-%Y_%H:%M:%S"]"
make_tracks
place_pins -hor_layer "met3 met5" -ver_layer "met2 met4"
#insert_tiecells sky130_fd_sc_hs__diode_2/DIODE

puts "\[DATE\]: [clock format [clock seconds] -format "%d-%m-%Y_%H:%M:%S"]"
global_placement -routability_use_grt
puts "\[DATE\]: [clock format [clock seconds] -format "%d-%m-%Y_%H:%M:%S"]"
detailed_placement
puts "\[DATE\]: [clock format [clock seconds] -format "%d-%m-%Y_%H:%M:%S"]"
global_route -verbose

puts "\[DATE\]: [clock format [clock seconds] -format "%d-%m-%Y_%H:%M:%S"]"
report_design_area
check_placement
report_wire_length -net * -summary -global_route

#estimate_parasitics -placement
#report_checks -path_delay max -digits 3
#report_wns -digits 3
#detailed_placement
#global_route
#detailed_route

puts "\[DATE\]: [clock format [clock seconds] -format "%d-%m-%Y_%H:%M:%S"]"
#write_def $::env(OUT_DIR)/$::env(TOP_MODULE)_$::env(FILE_SUFFIX).def
#write_db  $::env(OUT_DIR)/$::env(TOP_MODULE)_$::env(FILE_SUFFIX).odb

exit
