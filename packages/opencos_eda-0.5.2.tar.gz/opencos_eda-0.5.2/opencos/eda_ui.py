#!/usr/bin/env python3

'''opencos.eda_ui - textual dev wrapper for calling eda-ui'''

from opencos import eda

if __name__ == '__main__':
    eda.main_ui()
