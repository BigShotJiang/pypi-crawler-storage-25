# Welcome to OpenCOS

OpenCOS is an EDA flow runner that provides a unified interface for HDL simulation, synthesis, and building.

## Quick Start

```bash
# Install
uv tool install opencos-eda

# Run a simulation
eda sim --tool verilator my_design

# Synthesize
eda synth --tool slang_yosys my_design
```

## Key Features

- **Unified CLI** - Run simulations, synthesis, and builds with a single command
- **Tool abstraction** - Switch between Verilator, Vivado, slang, etc.
- **DEPS.yml** - Declarative dependency management for HDL projects
- **Waveform viewing** - Integrated waveform support

## Documentation

On [Github Pages (animated-adventure-j19gep3.pages.github.io)](https://animated-adventure-j19gep3.pages.github.io/)

- [DEPS.yml Reference](DEPS.md) - Configuration file format
- [EDA Usage](eda.md) - Command-line interface
- [Installation](Installation.md) - Setup instructions
- [RTL Coding Style](RtlCodingStyle.md) - Best practices
