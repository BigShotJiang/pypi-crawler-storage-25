"""Command-line interface for Quodeq evaluation and dashboard commands."""

from __future__ import annotations

import argparse
import json
import logging
import os
import subprocess
import sys
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from quodeq.cli_parser import build_parser  # noqa: F401 — re-export
from quodeq.config.paths import default_paths, load_env_file
from quodeq.dashboard.cli import main as dashboard_main
from quodeq.analysis.subprocess import AnalysisError
from quodeq.analysis.runner import AnalysisOptions, EvaluationError, RunConfig, run
from quodeq.engine.scoring_pipeline import run_full
from quodeq.shared.project_resolver import ProjectIdentity, resolve_project_uuid
from quodeq.shared.repo_handler import cleanup_cloned_repo, prepare_repository
from quodeq.shared.utils import is_repo_url, project_name_from_repo, write_text
from quodeq.shared.validation import validate_path_segment

_logger = logging.getLogger(__name__)


@dataclass
class ResolvedInputs:
    """Grouped evaluation inputs that always travel together."""
    src: Path
    language: str
    manifest: object  # SourceManifest | None
    dims_data: dict


_ENV_MAX_TURNS = "QUODEQ_MAX_TURNS"
_ENV_MAX_DURATION = "QUODEQ_MAX_DURATION"
_ENV_POOL_BUDGET = "QUODEQ_POOL_BUDGET"

def _env_int(var: str, default: int | None, env: dict[str, str] | None = None) -> int | None:
    """Read an environment variable as an int, returning *default* if unset or invalid."""
    raw = (env or os.environ).get(var)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _subagent_model(env: dict[str, str] | None = None) -> str | None:
    """Return the subagent model override from the environment, or None."""
    return (env or os.environ).get("SUBAGENT_MODEL") or None


def _resolve_repo(args: argparse.Namespace) -> Path | None:
    """Resolve the repo argument to a local path (cloning if needed)."""
    repo_path = args.repo
    # NOTE: print() here uses plain text only.  If ANSI escapes are added in
    # the future, gate them on the NO_COLOR environment variable.
    try:
        is_remote = is_repo_url(repo_path)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return None
    if is_remote:
        try:
            repo_path = prepare_repository(repo_path)
        except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired, ValueError) as exc:
            print(f"Failed to clone repository: {exc}", file=sys.stderr)
            return None
    src = Path(repo_path).resolve()
    if not src.exists():
        print(f"Repository path does not exist: {src}. Verify the path is correct and accessible.", file=sys.stderr)
        return None
    return src


def _setup_run_dirs(args: argparse.Namespace, src: Path) -> tuple[Path, Path, Path]:
    """Resolve project UUID and create evidence/evaluation directories."""
    reports_root = Path(args.output)
    reports_root.mkdir(parents=True, exist_ok=True)

    project_name = project_name_from_repo(args.repo)
    location = "online" if is_repo_url(args.repo) else "local"
    project_uuid = resolve_project_uuid(reports_root, ProjectIdentity(project_name, str(src), None, location))

    run_id = str(uuid.uuid4())
    evidence_dir = reports_root / project_uuid / run_id / "evidence"
    evaluation_dir = reports_root / project_uuid / run_id / "evaluation"
    evidence_dir.mkdir(parents=True, exist_ok=True)
    evaluation_dir.mkdir(parents=True, exist_ok=True)
    return reports_root, evidence_dir, evaluation_dir


def _resolve_language(args: argparse.Namespace, src: Path, paths) -> str | None:
    """Detect or validate the language for a repo using universal detection."""
    if args.language:
        validate_path_segment(args.language)
        return args.language
    if not paths.detection_file.exists():
        return None
    try:
        from quodeq.analysis.manifest import detect_language
        return detect_language(src, paths.detection_file)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return None


def _build_manifest(args: argparse.Namespace, src: Path, paths) -> "SourceManifest | None":
    """Build a source manifest for the repository."""
    if args.no_prescan:
        return None

    from quodeq.analysis.manifest import SourceManifest, build_manifest
    from quodeq.shared.utils import read_json

    detection_file = paths.detection_file
    if not detection_file.exists():
        return None

    detection = read_json(detection_file)
    disciplines_conf = paths.disciplines_conf if paths.disciplines_conf.exists() else None
    manifest = build_manifest(src, detection, disciplines_conf)
    if manifest.targets:
        langs = ", ".join(
            f"{t.language} ({t.total_files})"
            for t in manifest.targets
        )
        print(f"Detected: {langs}", file=sys.stderr)
    print(f"Source files: {manifest.total_files}", file=sys.stderr)
    return manifest


def _execute_pipeline(args: argparse.Namespace, config: RunConfig, evidence_dir: Path, evaluation_dir: Path) -> int:
    """Execute the evidence/scoring pipeline and print results."""
    try:
        if args.evidence_only:
            print("Starting evidence collection (this may take several minutes per dimension)...", file=sys.stderr)
            evidence = run(config)
            out_file = evidence_dir / f"{config.language}_evidence.json"
            try:
                write_text(out_file, json.dumps(evidence.to_evidence_dict(), indent=2))
            except OSError as exc:
                print(f"Failed to write evidence file {out_file}: {exc}", file=sys.stderr)
                return 1
            print(f"Evidence written to {out_file}", file=sys.stderr)
        else:
            print("Starting evaluation (this may take several minutes per dimension)...", file=sys.stderr)
            scores = run_full(config, evaluation_dir, mode=args.mode)
            print(f"Reports written to {evaluation_dir}/", file=sys.stderr)
            for dim, score in scores.items():
                print(f"  {dim}: {score}")
    except (AnalysisError, EvaluationError) as exc:
        print(f"\nError: {exc}", file=sys.stderr)
        return 1
    return 0


def _no_verify(args: argparse.Namespace, env: dict[str, str] | None = None) -> bool:
    """Return True if verification should be skipped (CLI flag or env var)."""
    return args.no_verify or (env or os.environ).get("QUODEQ_NO_VERIFY") == "1"


def _build_run_config(args: argparse.Namespace, *, inputs: ResolvedInputs, evidence_dir: Path, env: dict[str, str] | None = None) -> RunConfig:
    """Assemble a RunConfig from CLI args and resolved inputs.

    *inputs* bundles the source path, language, manifest, and dimension data
    that are resolved together early in the evaluation pipeline.

    *env* overrides ``os.environ`` for environment variable reads (useful for
    testing).
    """
    _env = env or os.environ
    standards_dir = default_paths().standards_dir
    dimensions_filter = [d.strip() for d in args.dimensions.split(",") if d.strip()] if args.dimensions else None
    print(f"Dimensions: {', '.join(dimensions_filter)}" if dimensions_filter else "Dimensions: all", file=sys.stderr)

    is_single_file = getattr(args, '_single_file', False)

    # Single-file evaluation: force per-dimension analysis for deeper coverage
    consolidated = not getattr(args, 'no_consolidated', False) and not bool(_env.get("QUODEQ_NO_CONSOLIDATE"))
    if is_single_file:
        consolidated = False
        print("Single-file mode: per-dimension analysis for deeper coverage", file=sys.stderr)

    return RunConfig(
        src=inputs.src,
        language=inputs.language,
        standards_dir=standards_dir if standards_dir.exists() else None,
        work_dir=evidence_dir,
        manifest=inputs.manifest,
        dimensions_data=inputs.dims_data,
        evaluators_dir=default_paths().evaluators_dir,
        options=AnalysisOptions(
            dimensions=dimensions_filter,
            max_turns=args.max_turns if args.max_turns is not None else _env_int(_ENV_MAX_TURNS, None, env=env),
            max_duration=args.max_duration if args.max_duration is not None else _env_int(_ENV_MAX_DURATION, None, env=env),
            max_subagents=args.n_subagents,
            subagent_model=_subagent_model(env=env),
            verify_findings=not _no_verify(args, env=env),
            consolidated=consolidated,
            pool_budget=args.pool_budget if args.pool_budget is not None else _env_int(_ENV_POOL_BUDGET, None, env=env),
            incremental=args.incremental,
        ),
    )


def _save_manifest(manifest, evidence_dir: Path) -> None:
    """Save manifest for debugging (best-effort)."""
    if manifest and evidence_dir:
        try:
            write_text(evidence_dir / "manifest.json", json.dumps(manifest.to_dict(), indent=2))
        except OSError as exc:
            _logger.debug("Could not write manifest: %s", exc)


def _resolve_evaluation_inputs(args: argparse.Namespace) -> ResolvedInputs | None:
    """Resolve src, language, manifest, and dims_data from CLI args.

    Returns ``None`` (with error printed to stderr) if any step fails.
    """
    src = _resolve_repo(args)
    if src is None:
        return None

    # Single-file evaluation: find project root, compute relative path
    single_file: str | None = None
    if src.is_file():
        file_path = src
        # Walk up to find git root, or fall back to immediate parent
        project_root = file_path.parent
        candidate = file_path.parent
        while candidate != candidate.parent:
            if (candidate / ".git").exists():
                project_root = candidate
                break
            candidate = candidate.parent
        single_file = str(file_path.relative_to(project_root))
        src = project_root
        print(f"Single-file evaluation: {single_file} (project root: {src})", file=sys.stderr)

    paths = default_paths()
    if not paths.detection_file.exists() or not paths.dimensions_file.exists():
        print("Configuration not found: detection.json and dimensions.json are required.", file=sys.stderr)
        return None

    language = _resolve_language(args, src, paths)
    if language is None:
        return None

    from quodeq.analysis.runner import load_universal_dimensions
    try:
        dims_data = load_universal_dimensions(paths.dimensions_file)
    except ValueError as exc:
        print(f"Invalid dimensions config: {exc}", file=sys.stderr)
        return None

    manifest = _build_manifest(args, src, paths)

    # For single-file: override manifest to contain only the target file
    if single_file:
        from quodeq.analysis.manifest_models import AnalysisTarget, SourceManifest
        ext = os.path.splitext(single_file)[1]
        target = AnalysisTarget(
            name=single_file,
            language=language,
            source_files=[single_file],
            total_files=1,
            language_stats={ext: 1} if ext else {},
        )
        manifest = SourceManifest(targets=[target], total_files=1, language_stats={ext: 1} if ext else {})
        args._single_file = True  # flag for _build_run_config

    return ResolvedInputs(src=src, language=language, manifest=manifest, dims_data=dims_data)


def _run_pipeline_with_cleanup(
    args: argparse.Namespace, inputs: ResolvedInputs, paths: tuple[Path, Path, Path],
) -> int:
    """Set up directories, build config, run the pipeline, and clean up cloned repos."""
    _reports_root, evidence_dir, evaluation_dir = paths
    print(f"Report path: {evaluation_dir}", file=sys.stderr)
    _save_manifest(inputs.manifest, evidence_dir)

    config = _build_run_config(args, inputs=inputs, evidence_dir=evidence_dir)
    try:
        return _execute_pipeline(args, config, evidence_dir, evaluation_dir)
    finally:
        if is_repo_url(args.repo):
            cleanup_cloned_repo(str(inputs.src))


def run_evaluate(args: argparse.Namespace) -> int:
    """Run the evaluation pipeline."""
    from quodeq.shared.prereqs import check_evaluate_prereqs
    try:
        check_evaluate_prereqs()
    except RuntimeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    inputs = _resolve_evaluation_inputs(args)
    if inputs is None:
        return 1

    return _run_pipeline_with_cleanup(args, inputs, _setup_run_dirs(args, inputs.src))


_COMMAND_HANDLERS: dict[str, Callable] = {
    "dashboard": lambda argv: dashboard_main(argv[1:] if argv is not None else sys.argv[2:]),
}


def main(argv: list[str] | None = None) -> int:
    """Parse arguments and dispatch to the appropriate subcommand handler."""
    load_env_file(default_paths())
    parser = build_parser()
    args, remaining = parser.parse_known_args(argv)
    if args.handler_command == "evaluate":
        return run_evaluate(args)
    handler = _COMMAND_HANDLERS.get(args.handler_command)
    if handler:
        return handler(argv)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
