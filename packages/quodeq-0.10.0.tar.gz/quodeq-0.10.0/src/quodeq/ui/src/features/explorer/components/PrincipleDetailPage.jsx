import { memo } from 'react';
import { buildSingleViolationPlanText } from '../../../utils/planBuilder.js';
import { buildPrinciplePlanText } from '../../../utils/planTextBuilders.js';
import { SEVERITY_ORDER, parseFileRef } from '../../../utils/formatters.js';
import CopyButton, { SparkleIcon } from '../../../components/CopyButton.jsx';
import FileCopyBtn from '../../../components/FileCopyBtn.jsx';
import ContextBlock from '../../../components/ContextBlock.jsx';
import { ComplianceCard } from './EvalCards.jsx';
import { copyToClipboard } from '../../../utils/clipboard.js';

function buildViolationPlanText(v, principleName) {
  return buildSingleViolationPlanText(v, principleName || 'Violation');
}

const ANIM_DELAY_PER_ITEM_MS = 30;
const ANIM_MAX_DELAY_MS = 300;

function filterHttpRefs(reqRefs) {
  return (reqRefs || []).filter(r => r.url && /^https?:\/\//.test(r.url));
}

function ViolationCard({ v, principleName, index }) {
  const { filePath, line } = parseFileRef(v.file, v.line);
  const filename = filePath ? filePath.split('/').pop() : null;
  const range = (v.endLine && v.endLine !== line) ? `${line}-${v.endLine}` : line;
  const ref = line != null ? `${filePath}:${range}` : filePath;
  const display = line != null ? `${filename}:${range}` : filename;
  const linkedRefs = filterHttpRefs(v.reqRefs);
  return (
    <div className={`vdetail-row vdetail-row--${v.severity}`} style={{ animationDelay: `${Math.min(index * ANIM_DELAY_PER_ITEM_MS, ANIM_MAX_DELAY_MS)}ms` }}>
      <div className="vdetail-row-main">
        <span className={`severity-tag ${v.severity}`}>{v.severity}</span>
        <span className="vrow-label">[{principleName}]</span>
        {filename && (
          <FileCopyBtn display={display} copyText={ref} />
        )}
        <CopyButton
          label="Fix plan"
          className="fix-plan-btn"
          icon={<SparkleIcon />}
          onClick={() => copyToClipboard(buildViolationPlanText(v, principleName))}
        />
      </div>
      <div className="vlive-detail">
        {(v.title || v.reason) && (
          <div className="vlive-detail-section">
            <div className="vlive-detail-section-header">
              {v.title && <span className="vlive-detail-section-label">Reason</span>}
              {linkedRefs.length > 0 &&
                <span className="cwe-link-group">{linkedRefs.map((ref, i) => (
                  <a key={i} className="cwe-link" href={ref.url} target="_blank" rel="noopener noreferrer">{ref.label}</a>
                ))}</span>
              }
            </div>
            {v.title && <p className="vlive-detail-title">{v.title}</p>}
            {v.reason && <>
              <span className="vlive-detail-section-label">Detail</span>
              <p className="vlive-detail-reason">{v.reason}</p>
            </>}
          </div>
        )}
        <ContextBlock snippet={v.snippet} line={v.line} endLine={v.endLine} />
      </div>
    </div>
  );
}

function ComplianceStatsRow({ principle, totalViolations, totalCompliance }) {
  return (
    <section className="panel file-detail-summary-panel">
      <div className="file-detail-stats-row">
        <div className="file-detail-stats">
          {principle.critical > 0 && (
            <span className="file-detail-stat severity-tag critical">{principle.critical} critical</span>
          )}
          {principle.major > 0 && (
            <span className="file-detail-stat severity-tag major">{principle.major} major</span>
          )}
          {principle.minor > 0 && (
            <span className="file-detail-stat severity-tag minor">{principle.minor} minor</span>
          )}
          {(principle.critical > 0 || principle.major > 0 || principle.minor > 0) && <span className="file-detail-stat-sep">·</span>}
          <span className="file-detail-stat">
            <strong>{totalViolations}</strong> violations
          </span>
          {totalCompliance > 0 && (
            <>
              <span className="file-detail-stat-sep">·</span>
              <span className="file-detail-stat">
                <strong>{totalCompliance}</strong> compliance
              </span>
              {totalViolations > 0 && (
                <>
                  <span className="file-detail-stat-sep">·</span>
                  <span className="file-detail-stat">
                    <strong>1:{Math.round(totalCompliance / totalViolations)}</strong> ratio
                  </span>
                </>
              )}
            </>
          )}
        </div>
        <CopyButton
          label="Full fix plan"
          className="fix-plan-btn-header"
          icon={<SparkleIcon />}
          onClick={() => copyToClipboard(buildPrinciplePlanText(principle))}
        />
      </div>
    </section>
  );
}

function ViolationGroup({ sev, violations, principleName }) {
  if (!violations || violations.length === 0) return null;
  return (
    <div>
      <div className="violation-group-header">
        <span className="violation-group-title">{sev.charAt(0).toUpperCase() + sev.slice(1)}</span>
        <span className="violation-group-count">{violations.length}</span>
      </div>
      <div className="vlive-violations-group">
        {violations.map((v, idx) => (
          <ViolationCard key={idx} v={v} principleName={principleName} index={idx} />
        ))}
      </div>
    </div>
  );
}

function groupViolationsBySeverity(violations) {
  const result = {};
  for (const sev of SEVERITY_ORDER) result[sev] = [];
  for (const v of (violations || [])) {
    const sev = (v.severity || 'minor').toLowerCase();
    if (result[sev]) result[sev].push(v);
    else result['minor'].push(v);
  }
  return result;
}

const PrincipleDetailPage = memo(function PrincipleDetailPage({ principle }) {
  const totalViolations = principle.total || 0;
  const totalCompliance = principle.compliance?.length || 0;
  const violationsBySeverity = groupViolationsBySeverity(principle.violations);

  return (
    <>
      <div className="section-header">
        <h3 className="section-title file-detail-title">{principle.principle}</h3>
      </div>
      <ComplianceStatsRow principle={principle} totalViolations={totalViolations} totalCompliance={totalCompliance} />
      {SEVERITY_ORDER.map((sev) => (
        <ViolationGroup key={sev} sev={sev} violations={violationsBySeverity[sev]} principleName={principle.principle} />
      ))}
      {totalCompliance > 0 && (
        <div>
          <div className="violation-group-header">
            <span className="violation-group-title">Compliance</span>
            <span className="violation-group-count">{totalCompliance}</span>
          </div>
          <div className="vlive-violations-group">
            {principle.compliance.map((c, idx) => (
              <ComplianceCard key={idx} c={c} principle={principle.principle} index={idx} />
            ))}
          </div>
        </div>
      )}
    </>
  );
});

export default PrincipleDetailPage;
