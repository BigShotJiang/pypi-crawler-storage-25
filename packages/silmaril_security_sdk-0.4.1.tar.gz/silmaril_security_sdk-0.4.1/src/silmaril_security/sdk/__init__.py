# Copyright (c) 2024-2026 Silmaril Security Inc. All rights reserved.

"""Silmaril Firewall Python SDK."""

from __future__ import annotations

from silmaril_security.sdk._version import VERSION
from silmaril_security.sdk.chunking import (
    CHARS_PER_TOKEN,
    CHUNK_OVERLAP,
    CHUNK_OVERLAP_CHARS,
    CHUNK_WINDOW,
    CHUNK_WINDOW_CHARS,
    MAX_INPUT_CHARS,
    MAX_INPUT_TOKENS,
    chunk_text,
)
from silmaril_security.sdk.exceptions import (
    APIError,
    BatchFirewallBlockedException,
    BatchPromptBlockedException,
    FirewallBlockedException,
    PromptBlockedException,
    SilmarilApiError,
)
from silmaril_security.sdk.firewall import (
    DEFAULT_CHUNK_CONCURRENCY,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    Firewall,
    SilmarilFirewall,
)
from silmaril_security.sdk.hooks import (
    ALL_HOOKS,
    DEFAULT_HOOKS,
    FIREWALL_HOOK_TO_LABEL,
    INPUT_HOOKS,
    OUTPUT_HOOKS,
    FirewallHook,
    HookLabel,
    prepend_hook,
    prepend_tool_name,
    resolve_hooks,
)
from silmaril_security.sdk.types import (
    BlockedBatchItem,
    BlockResult,
    ClassificationMetadata,
    ClassifyEvent,
    Prediction,
)

__version__ = VERSION

__all__ = [
    "ALL_HOOKS",
    "APIError",
    "BlockResult",
    "BlockedBatchItem",
    "BatchFirewallBlockedException",
    "BatchPromptBlockedException",
    "CHARS_PER_TOKEN",
    "CHUNK_OVERLAP",
    "CHUNK_OVERLAP_CHARS",
    "CHUNK_WINDOW",
    "CHUNK_WINDOW_CHARS",
    "ClassificationMetadata",
    "ClassifyEvent",
    "DEFAULT_CHUNK_CONCURRENCY",
    "DEFAULT_HOOKS",
    "DEFAULT_MAX_RETRIES",
    "DEFAULT_TIMEOUT",
    "FIREWALL_HOOK_TO_LABEL",
    "Firewall",
    "FirewallBlockedException",
    "FirewallHook",
    "HookLabel",
    "INPUT_HOOKS",
    "MAX_INPUT_CHARS",
    "MAX_INPUT_TOKENS",
    "OUTPUT_HOOKS",
    "Prediction",
    "PromptBlockedException",
    "SilmarilApiError",
    "SilmarilFirewall",
    "chunk_text",
    "prepend_hook",
    "prepend_tool_name",
    "resolve_hooks",
]


def __getattr__(name: str):
    if name == "SilmarilFirewallHandler":
        from silmaril_security.sdk.langchain import SilmarilFirewallHandler

        return SilmarilFirewallHandler
    if name == "AsyncSilmarilFirewallHandler":
        from silmaril_security.sdk.langchain import AsyncSilmarilFirewallHandler

        return AsyncSilmarilFirewallHandler
    raise AttributeError(f"module 'silmaril_security.sdk' has no attribute {name!r}")
