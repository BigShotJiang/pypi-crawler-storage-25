# Tests for stogger
