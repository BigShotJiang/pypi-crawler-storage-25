"""ConfigEditModal: edit a single config knob.

Per design §5.3. 3-tier validation:
  - live: field-level (modal-internal, on every keystroke) — T6.2
  - save-time: full PolilyConfig validation (this modal) — T6.3
  - startup: fatal screen — Phase 7

EPHEMERAL_FIELDS / HIDDEN_IN_TUI keys are filtered out at the
ConfigView level (LeafRow whitelist) so this modal trusts that
key_path is editable. The constructor still rejects non-territory-A
keys as defense-in-depth (T6.7).
"""
from __future__ import annotations

import contextlib
from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Markdown, Static

from polily.tui.i18n import current_language, t
from polily.tui.icons import ICON_CONFIG
from polily.tui.widgets.confirm_cancel_bar import ConfirmCancelBar
from polily.tui.widgets.field_row import FieldRow
from polily.tui.widgets.polily_card import PolilyCard

_MODAL_WIDTH = 80


class ConfigEditModal(ModalScreen[bool | None]):
    """Modal returns True on successful save, False on reset, None on cancel."""

    DEFAULT_CSS = f"""
    ConfigEditModal {{
        align: center middle;
    }}
    ConfigEditModal #dialog-box {{
        width: {_MODAL_WIDTH};
        height: auto;
        max-height: 32;
    }}
    ConfigEditModal #dialog-box > PolilyCard {{
        height: auto;
        margin: 0;
    }}
    ConfigEditModal #modal-keypath {{
        color: $text-muted;
        padding: 0 0 1 0;
    }}
    ConfigEditModal #modal-description {{
        height: auto;
        max-height: 12;
        overflow-y: auto;
    }}
    ConfigEditModal #modal-input {{ width: 30; }}
    ConfigEditModal #modal-error {{
        color: $error;
        padding: 0 0 1 0;
    }}
    ConfigEditModal ConfirmCancelBar Button {{ min-width: 14; }}
    ConfigEditModal #reset-btn {{
        background: $warning 30%;
        min-width: 14;
    }}
    """
    # priority=True: Input widget at #modal-input takes focus on mount and would
    # otherwise consume the escape key before the screen-level binding fires.
    # priority bindings run BEFORE focused-widget key handling, so ESC reliably
    # dismisses regardless of which child has focus.
    BINDINGS = [Binding("escape", "cancel", "Cancel", priority=True)]

    def __init__(
        self,
        *,
        service,
        key_path: str,
        current_value: Any,
        default_value: Any,
    ) -> None:
        # T6.7 — defense-in-depth: reject HIDDEN_IN_TUI / EPHEMERAL paths
        # at construction. UI level (LeafRow whitelist in ConfigView) already
        # prevents these from rendering, so this is belt-and-suspenders.
        from polily.core.config_store import is_territory_a
        if not is_territory_a(key_path):
            raise ValueError(
                f"{key_path} is not editable (HIDDEN_IN_TUI or EPHEMERAL)"
            )
        super().__init__()
        self._service = service
        self._key_path = key_path
        self._current_value = current_value
        self._default_value = default_value
        # SF14 — debounce live validation. CJK IME composition fires one
        # Input.Changed event per pre-edit char (typing "5" via pinyin can
        # emit 5+ events). Without coalescing, each event runs the full
        # _resolve_field_annotation + _coerce_value + Static.update chain,
        # producing visible lag and flicker. The timer holds the latest
        # pending validation; on each new event we cancel + reschedule.
        self._validation_timer = None

    @property
    def _last_segment(self) -> str:
        return self._key_path.rsplit(".", 1)[-1]

    def _cancel_validation_timer(self) -> None:
        """SF14 / round-2 (Goku #2) — cancel pending live-validation timer.

        Called from every dismiss path (save / reset / cancel / ESC) to
        prevent a queued validation from firing against a torn-down widget
        tree after the modal has dismissed. Without this, the timer's
        callback runs `_show_error` which does `query_one("#modal-error")`
        — `contextlib.suppress` in `_show_error` swallows the resulting
        widget-not-found error, so no crash, but it's wasted work against
        a dead screen.

        Idempotent: safe to call when no timer is pending.
        """
        if self._validation_timer is not None:
            with contextlib.suppress(Exception):
                self._validation_timer.stop()
            self._validation_timer = None

    def compose(self) -> ComposeResult:
        from polily.core.config_docs import load_all
        # Per-language docs: read the snapshot at compose time. F2 toggles
        # don't hot-flip an already-open modal — the user must close and
        # reopen, which is fine since the modal is short-lived.
        docs = load_all(current_language())
        description_md = docs.get(
            self._key_path,
            t("config_modal.no_description", key_path=self._key_path),
        )

        with Vertical(id="dialog-box"):
            with PolilyCard(title=t(
                "config_modal.title",
                icon=ICON_CONFIG,
                leaf=self._last_segment,
            )):
                yield Static(
                    t("config_modal.keypath_label", key_path=self._key_path),
                    id="modal-keypath",
                )
                yield Markdown(description_md, id="modal-description")
                yield FieldRow(
                    label=t("config_modal.input_label"),
                    unit="",
                    input_widget=Input(
                        value=str(self._current_value), id="modal-input",
                    ),
                )
                yield Static("", id="modal-error")
                yield Static(
                    t("config_modal.warn_restart"),
                    id="modal-warn",
                )
                yield ConfirmCancelBar(
                    confirm_label=t("config_modal.button.save"),
                    cancel_label=t("config_modal.button.cancel"),
                )
                yield Button(
                    t("config_modal.button.reset"),
                    id="reset-btn", variant="warning",
                )

    def action_cancel(self) -> None:
        # Round-2 (Goku #2) — cancel pending validation timer so it can't
        # fire against a torn-down widget tree post-dismiss.
        self._cancel_validation_timer()
        self.dismiss(None)

    def on_confirm_cancel_bar_cancelled(
        self, event: ConfirmCancelBar.Cancelled,
    ) -> None:
        # Round-2 (Goku #2) — same as ESC.
        self._cancel_validation_timer()
        self.dismiss(None)

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id != "modal-input":
            return
        # SF14 — coalesce keystroke storms (CJK IME composition fires one
        # event per pre-edit char). 100ms idle window matches human typing
        # perception threshold; users won't notice the deferral, but rapid
        # IME bursts collapse into a single validation run.
        if self._validation_timer is not None:
            with contextlib.suppress(Exception):
                self._validation_timer.stop()
        self._validation_timer = self.set_timer(0.1, self._run_live_validation)

    def _run_live_validation(self) -> None:
        """SF14 — debounced field-level validation.

        Reads the current input value (not the captured event.value) so the
        latest text is what actually validates, regardless of how many
        events fired during the debounce window.
        """
        from polily.core.config import _coerce_value, _resolve_field_annotation
        try:
            raw = self.query_one("#modal-input", Input).value
        except Exception:
            return
        annotation = _resolve_field_annotation(self._key_path)
        if annotation is None:
            self._show_error(
                t("config_modal.error.cannot_resolve_type", key_path=self._key_path),
            )
            return
        try:
            _coerce_value(raw, annotation)
        except ValueError as e:
            self._show_error(str(e))
            return
        self._show_error("")

    def _show_error(self, message: str) -> None:
        # Pydantic ValidationError messages contain `[type=...]` brackets that
        # Static.update() interprets as Rich markup → MarkupError. Escape to
        # render literally (T6.3).
        from rich.markup import escape as _escape_markup
        safe = _escape_markup(message) if message else ""
        with contextlib.suppress(Exception):
            self.query_one("#modal-error", Static).update(safe)
        with contextlib.suppress(Exception):
            self.query_one("#confirm", Button).disabled = bool(message)

    def on_confirm_cancel_bar_confirmed(
        self, event: ConfirmCancelBar.Confirmed,
    ) -> None:
        self._do_save()

    def _do_save(self) -> None:
        from polily.core.config import (
            ConfigValidationError,
            _coerce_value,
            _resolve_field_annotation,
            save_knob,
        )
        # SF14 — cancel any pending debounced live-validation. Otherwise
        # if the user types a live-valid but save-invalid value (e.g. 0.5
        # for starting_balance which has Field(ge=1.0)) and clicks Save
        # before the 100ms timer fires, the timer would later overwrite
        # our Pydantic error message with an empty string.
        # Round-2 (Goku #2) — refactored inline cancel into the
        # `_cancel_validation_timer` helper used across all dismiss paths.
        self._cancel_validation_timer()

        raw = self.query_one("#modal-input", Input).value
        annotation = _resolve_field_annotation(self._key_path)
        try:
            new_value = _coerce_value(raw, annotation)
        except ValueError as e:
            self._show_error(str(e))
            return
        try:
            save_knob(self._service.db, self._key_path, new_value)
        except ConfigValidationError as e:
            self._show_error(t("config_modal.error.pydantic_failed", detail=str(e)))
            return
        self.notify(t(
            "config_modal.notify.saved",
            key_path=self._key_path, value=new_value,
        ))
        self.dismiss(True)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "reset-btn":
            self._do_reset()

    def _do_reset(self) -> None:
        from polily.core.config_store import reset
        # Round-2 (Goku #2) — cancel any pending live-validation timer
        # before we mutate the input. Setting `input.value = default`
        # below fires `on_input_changed` which schedules a fresh timer;
        # we don't want a stale timer from prior typing to fire against
        # the now-default value.
        self._cancel_validation_timer()
        try:
            reset(self._service.db, self._key_path)
        except Exception as e:
            self._show_error(t("config_modal.error.reset_failed", detail=str(e)))
            return
        # Update the input + cleared current_value tracking
        self.query_one("#modal-input", Input).value = str(self._default_value)
        self._current_value = self._default_value
        self._show_error("")
        # SF5 — defensive explicit re-enable. User flow that requires this:
        # type invalid → live validation disables Save → click Reset →
        # without this line, if `_show_error("")`'s `contextlib.suppress`
        # swallowed any exception (e.g., during a fast-firing input change
        # event), the disabled flag would stay True and the user couldn't
        # save the default. Belt-and-suspenders.
        with contextlib.suppress(Exception):
            self.query_one("#confirm", Button).disabled = False
        self.notify(t(
            "config_modal.notify.reset",
            leaf=self._last_segment,
            default=self._default_value,
        ))
