"""MonitorListView: shows events with active monitoring.

Role: answer "what am I monitoring, and when's the next poll?" plus a few
routing hints (structure score, AI analysis version, latest movement
signal). Trade / position / P&L details live on their respective pages.

v0.8.0 migration:
- PolilyZone atom wraps the list (title: 监控列表)
- Chinese labels for 状态 column removed; status implied by membership
- EventBus subscription (TOPIC_MONITOR_UPDATED, TOPIC_PRICE_UPDATED,
  TOPIC_SCAN_UPDATED) for auto-refresh on mutations
- Q11 NAV_BINDINGS + view-specific bindings (enter, m, r)
"""

import contextlib

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import VerticalScroll
from textual.message import Message
from textual.widget import Widget
from textual.widgets import DataTable

from polily.core.events import (
    TOPIC_LANGUAGE_CHANGED,
    TOPIC_MONITOR_UPDATED,
    TOPIC_PRICE_UPDATED,
    TOPIC_SCAN_UPDATED,
)
from polily.tui._dispatch import once_per_tick
from polily.tui.bindings import NAV_BINDINGS
from polily.tui.i18n import t
from polily.tui.icons import ICON_AUTO_MONITOR
from polily.tui.monitor_format import (
    format_ai_version,
    format_event_settlement,
    format_movement,
    format_next_check,
)
from polily.tui.service import PolilyService
from polily.tui.widgets._datatable_i18n import set_column_labels
from polily.tui.widgets.polily_zone import PolilyZone


class ViewMonitorDetail(Message):
    def __init__(self, event_id: str):
        super().__init__()
        self.event_id = event_id


# Internal column key -> catalog key. Internal keys are stable ids used by
# `update_cell` callers (refresh_data); visible labels are looked up via t()
# so they flip on language switch.
_COLUMN_SPEC = [
    ("title", "monitor.col.title"),
    ("score", "monitor.col.score"),
    ("count", "monitor.col.count"),
    ("ai", "monitor.col.ai"),
    ("movement", "monitor.col.movement"),
    ("settlement", "monitor.col.settlement"),
    ("next_check", "monitor.col.next_check"),
]


class MonitorListView(Widget):
    # NOTE: I18nFooter renders binding labels via t(f"binding.{action}") at
    # compose time, so the zh strings below are only fallbacks.
    BINDINGS = [
        Binding("enter", "view_detail", "详情", show=True),
        Binding("m", "toggle_monitor", "关闭监控", show=True),
        Binding("r", "refresh", "刷新", show=True),
        *NAV_BINDINGS,
    ]

    DEFAULT_CSS = """
    MonitorListView { height: 1fr; }
    MonitorListView > VerticalScroll { height: 1fr; }
    /* v0.8.0+: stretch zone + table to screen bottom (match paper_status/history/archived). */
    MonitorListView > VerticalScroll > PolilyZone { height: 1fr; }
    MonitorListView DataTable { height: 1fr; }
    """

    def __init__(self, service: PolilyService):
        super().__init__()
        self.service = service
        self._monitored: list[dict] = []

    def compose(self) -> ComposeResult:
        with VerticalScroll():
            yield PolilyZone(
                title=f"{ICON_AUTO_MONITOR} {t('monitor.title.zone')}",
                id="monitor-zone",
            )

    def on_mount(self):
        # Mount the DataTable ONCE inside the zone. `_render_all` then
        # refreshes it in place via `table.clear()` + re-add rows.
        # Re-mounting per render would leak stale widgets because
        # Textual's `remove()` is deferred, tripping DuplicateIds on
        # `#monitor-table` when the user manually hits `r`.
        try:
            zone = self.query_one("#monitor-zone", PolilyZone)
        except Exception:
            zone = None
        if zone is not None:
            table = DataTable(id="monitor-table")
            zone.mount(table)
            table.cursor_type = "row"
            for col_key, cat_key in _COLUMN_SPEC:
                table.add_column(t(cat_key), key=col_key)

        self.service.event_bus.subscribe(
            TOPIC_MONITOR_UPDATED, self._on_monitor_update,
        )
        self.service.event_bus.subscribe(
            TOPIC_PRICE_UPDATED, self._on_price_update,
        )
        self.service.event_bus.subscribe(
            TOPIC_SCAN_UPDATED, self._on_scan_update,
        )
        self.service.event_bus.subscribe(
            TOPIC_LANGUAGE_CHANGED, self._on_lang_changed,
        )
        # Initial render bypasses the @once_per_tick decorator — callers
        # (and tests) expect the table to be populated synchronously by
        # the time on_mount returns.
        type(self)._render_all.__wrapped__(self)

    def on_unmount(self):
        self.service.event_bus.unsubscribe(
            TOPIC_MONITOR_UPDATED, self._on_monitor_update,
        )
        self.service.event_bus.unsubscribe(
            TOPIC_PRICE_UPDATED, self._on_price_update,
        )
        self.service.event_bus.unsubscribe(
            TOPIC_SCAN_UPDATED, self._on_scan_update,
        )
        self.service.event_bus.unsubscribe(
            TOPIC_LANGUAGE_CHANGED, self._on_lang_changed,
        )

    def _on_lang_changed(self, payload: dict) -> None:
        """Update zone title + DataTable column headers + count cells.
        Row event titles are user data — left as-is."""
        from textual.widgets import Static
        with contextlib.suppress(Exception):
            self.query_one("#monitor-zone .polily-zone-title", Static).update(
                f"{ICON_AUTO_MONITOR} {t('monitor.title.zone')}",
            )
            table = self.query_one("#monitor-table", DataTable)
            set_column_labels(table, [(k, t(c)) for k, c in _COLUMN_SPEC])
        self._render_all()

    # -- Bus callbacks (published from non-UI threads — must hop back) --

    def _on_monitor_update(self, payload: dict) -> None:
        with contextlib.suppress(Exception):
            self._render_all()  # coalesced by @once_per_tick

    def _on_price_update(self, payload: dict) -> None:
        with contextlib.suppress(Exception):
            self._render_all()

    def _on_scan_update(self, payload: dict) -> None:
        with contextlib.suppress(Exception):
            self._render_all()

    # -- Rendering --

    @once_per_tick
    def _render_all(self) -> None:
        """Refresh the DataTable rows from fresh service data (in place).

        The table itself is mounted once in `on_mount`; this method only
        clears and repopulates rows so manual `r` refresh doesn't race
        Textual's deferred remove.

        `@once_per_tick`: subscribes to 3 bus topics — each heartbeat
        fan-out would otherwise fire this 3× per 5s. The decorator
        coalesces same-tick invocations to a single execution.
        """
        try:
            table = self.query_one("#monitor-table", DataTable)
        except Exception:
            return

        events = self.service.get_all_events()
        self._monitored = [e for e in events if e["is_monitored"]]

        table.clear()

        for e in self._monitored:
            ev = e["event"]
            mc = e["market_count"]
            score_str = f"{ev.structure_score:.0f}" if ev.structure_score else "—"
            count_str = t("monitor.count.format", count=mc) if mc > 1 else t("monitor.count.binary")
            ai_str = format_ai_version(e.get("analysis_count", 0))

            mov = e.get("movement")
            if mov:
                movement_str = format_movement(
                    mov["label"], mov["magnitude"], mov["quality"],
                )
            else:
                movement_str = "—"

            settlement_str = format_event_settlement(
                ev, e.get("markets_summary") or [],
            )
            next_check_str = format_next_check(e.get("next_check_at"))

            table.add_row(
                ev.title[:45],
                score_str,
                count_str,
                ai_str,
                movement_str,
                settlement_str,
                next_check_str,
                key=ev.event_id,
            )

    def _get_selected(self):
        if not self._monitored:
            return None
        try:
            table = self.query_one("#monitor-table", DataTable)
            row = table.cursor_row
            if row is None or row >= len(self._monitored):
                return None
            return self._monitored[row]
        except Exception:
            return None

    def on_data_table_row_selected(self, event):
        e = self._get_selected()
        if e:
            self.post_message(ViewMonitorDetail(e["event"].event_id))

    def action_view_detail(self):
        e = self._get_selected()
        if e:
            self.post_message(ViewMonitorDetail(e["event"].event_id))

    def action_refresh(self):
        self._render_all()

    def action_toggle_monitor(self):
        e = self._get_selected()
        if not e:
            return
        eid = e["event"].event_id
        title = e["event"].title

        # Block: event with open positions can't be unmonitored — closing it
        # would silently stop auto-resolution.
        pos_count = self.service.get_event_position_count(eid)
        if pos_count > 0:
            self.notify(
                t("monitor.error.cannot_unmonitor", pos_count=pos_count),
                severity="warning",
            )
            return

        from polily.tui.views.monitor_modals import ConfirmUnmonitorModal

        def _on_dismiss(confirmed: bool | None) -> None:
            if not confirmed:
                return
            self.service.toggle_monitor(eid, enable=False)
            self.notify(t("monitor.notify.unmonitored", title=title[:30]))
            with contextlib.suppress(AttributeError):
                self.screen.refresh_sidebar_counts()
            with contextlib.suppress(Exception):
                table = self.query_one("#monitor-table", DataTable)
                table.remove_row(eid)
                self._monitored = [
                    m for m in self._monitored if m["event"].event_id != eid
                ]

        self.app.push_screen(ConfirmUnmonitorModal(title), _on_dismiss)

    def refresh_data(self) -> None:
        """Re-read from DB and refresh mutable columns in-place.

        Kept as a public API for callers that want a lightweight in-place
        update without rebuilding the table (e.g. the main screen's periodic
        refresh tick). `_render_all` is the bus-driven full rebuild path.
        """
        try:
            table = self.query_one("#monitor-table", DataTable)
        except Exception:
            return

        events = self.service.get_all_events()
        fresh = {e["event"].event_id: e for e in events if e["is_monitored"]}

        for e in self._monitored:
            eid = e["event"].event_id
            new = fresh.get(eid)
            if not new:
                continue

            # next check
            next_check_str = format_next_check(new.get("next_check_at"))
            with contextlib.suppress(Exception):
                table.update_cell(eid, "next_check", next_check_str)

            # ai version
            ai_str = format_ai_version(new.get("analysis_count", 0))
            with contextlib.suppress(Exception):
                table.update_cell(eid, "ai", ai_str)

            # movement
            mov = new.get("movement")
            movement_str = (
                format_movement(mov["label"], mov["magnitude"], mov["quality"])
                if mov else "—"
            )
            with contextlib.suppress(Exception):
                table.update_cell(eid, "movement", movement_str)

            # settlement window — lifecycle state may have shifted as
            # sub-markets resolve.
            settlement_str = format_event_settlement(
                new["event"], new.get("markets_summary") or [],
            )
            with contextlib.suppress(Exception):
                table.update_cell(eid, "settlement", settlement_str)

        self._monitored = [e for e in events if e["is_monitored"]]
