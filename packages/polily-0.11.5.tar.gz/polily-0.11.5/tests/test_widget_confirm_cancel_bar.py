"""v0.8.0 Opt-A1: ConfirmCancelBar atom."""
from textual.app import App, ComposeResult
from textual.widgets import Button

from polily.tui.widgets.confirm_cancel_bar import ConfirmCancelBar


class _Harness(App):
    def __init__(self, bar: ConfirmCancelBar):
        super().__init__()
        self._bar = bar
        self.messages = []

    def compose(self) -> ComposeResult:
        yield self._bar

    def on_confirm_cancel_bar_confirmed(self, event: ConfirmCancelBar.Confirmed) -> None:
        self.messages.append("confirmed")

    def on_confirm_cancel_bar_cancelled(self, event: ConfirmCancelBar.Cancelled) -> None:
        self.messages.append("cancelled")


async def test_default_labels_and_variants():
    bar = ConfirmCancelBar()
    app = _Harness(bar)
    async with app.run_test() as pilot:
        await pilot.pause()
        buttons = list(bar.query(Button))
        assert len(buttons) == 2
        labels = {str(b.label) for b in buttons}
        assert labels == {"确认", "取消"}
        ids = {b.id for b in buttons}
        assert ids == {"confirm", "cancel"}
        confirm = next(b for b in buttons if b.id == "confirm")
        assert confirm.variant == "primary"


async def test_custom_labels():
    bar = ConfirmCancelBar(confirm_label="确认取消", cancel_label="继续")
    app = _Harness(bar)
    async with app.run_test() as pilot:
        await pilot.pause()
        labels = {str(b.label) for b in bar.query(Button)}
        assert labels == {"确认取消", "继续"}


async def test_destructive_variant_uses_error_style():
    bar = ConfirmCancelBar(destructive=True)
    app = _Harness(bar)
    async with app.run_test() as pilot:
        await pilot.pause()
        confirm = next(b for b in bar.query(Button) if b.id == "confirm")
        assert confirm.variant == "error"


async def test_confirm_press_emits_confirmed_message():
    bar = ConfirmCancelBar()
    app = _Harness(bar)
    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.click("#confirm")
        await pilot.pause()
        assert "confirmed" in app.messages
        assert "cancelled" not in app.messages


async def test_cancel_press_emits_cancelled_message():
    bar = ConfirmCancelBar()
    app = _Harness(bar)
    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.click("#cancel")
        await pilot.pause()
        assert "cancelled" in app.messages
        assert "confirmed" not in app.messages


async def test_default_labels_flip_with_language():
    """When no explicit labels are passed, defaults follow the active i18n
    language. Compose-time t() lookup ensures English mode shows
    Confirm/Cancel."""
    from polily.tui import i18n

    bar = ConfirmCancelBar()
    app = _Harness(bar)
    try:
        i18n.set_language("en")
        async with app.run_test() as pilot:
            await pilot.pause()
            labels = {str(b.label) for b in bar.query(Button)}
            assert labels == {"Confirm", "Cancel"}
    finally:
        i18n.set_language("zh")
