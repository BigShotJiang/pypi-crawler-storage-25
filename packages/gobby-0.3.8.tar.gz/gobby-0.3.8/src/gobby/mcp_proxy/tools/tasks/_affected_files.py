"""MCP tools for task affected files.

Provides tools for managing file annotations on tasks:
- set_affected_files: Bulk set files for a task
- get_affected_files: Query files for a task
- find_file_overlaps: Detect file contention between tasks
- wire_affected_files_from_run: Re-apply expansion-run file annotations by stable task IDs
"""

import logging
from typing import TYPE_CHECKING, Any, cast

from gobby.mcp_proxy.tools.internal import InternalToolRegistry
from gobby.mcp_proxy.tools.tasks._resolution import resolve_task_id_for_mcp
from gobby.storage.expansion_runs import LocalExpansionRunManager
from gobby.storage.task_affected_files import AnnotationSource, TaskAffectedFileManager
from gobby.storage.tasks import TaskNotFoundError

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from gobby.mcp_proxy.tools.tasks._context import RegistryContext

__all__ = [
    "create_core_affected_files_registry",
    "create_ops_affected_files_registry",
]


def create_core_affected_files_registry(ctx: "RegistryContext") -> InternalToolRegistry:
    """Create a registry with core affected file tools (gobby-tasks).

    Only includes update_observed_files — used by orchestrator hot path.
    """

    registry = InternalToolRegistry(
        name="gobby-tasks-affected-files-core",
        description="Core affected file tools (update_observed_files)",
    )

    af_manager = TaskAffectedFileManager(ctx.task_manager.db)

    # --- update_observed_files ---

    def update_observed_files(
        task_id: str,
        require_commits: bool = False,
    ) -> dict[str, Any]:
        """Annotate a task's affected files from its linked commits.

        Looks up commits linked to the task, runs git diff-tree to get
        changed files, and stores them as 'observed' annotations. This
        provides post-hoc file tracking for conflict detection.

        Args:
            task_id: Task reference (#N, path, or UUID)
            require_commits: If true, fails if no linked commits are found.

        Returns:
            Dict with task_id, commits_processed, files_observed, and files list
        """
        import subprocess

        try:
            resolved_id = resolve_task_id_for_mcp(ctx.task_manager, task_id)
        except (TaskNotFoundError, ValueError) as e:
            return {"error": f"Invalid task_id: {e}"}

        task = ctx.task_manager.get_task(resolved_id)
        if not task:
            return {"error": f"Task {task_id} not found"}

        # Get linked commits from task
        commit_shas = task.commits or []

        if not commit_shas:
            logger.warning(
                f"No linked commits found for task {resolved_id} in update_observed_files"
            )
            if require_commits:
                return {
                    "error": "No linked commits found for task. Commits are required for this action."
                }
            return {
                "task_id": resolved_id,
                "commits_processed": 0,
                "files_observed": 0,
                "files": [],
            }

        # Resolve repo path for git commands
        repo_path = ctx.get_project_repo_path(task.project_id)
        if not repo_path:
            logger.error(
                "Cannot update observed files for task %s: no repo path resolved", resolved_id
            )
            return {
                "task_id": resolved_id,
                "commits_processed": 0,
                "files_observed": 0,
                "files": [],
                "error": "No repository path available for task project",
            }

        # Collect changed files from each commit
        all_files: set[str] = set()
        commits_processed = 0
        for sha in commit_shas:
            try:
                result = subprocess.run(
                    ["git", "diff-tree", "--no-commit-id", "--name-only", "-r", sha],
                    capture_output=True,
                    text=True,
                    timeout=10,
                    cwd=repo_path,
                )
                if result.returncode == 0 and result.stdout.strip():
                    all_files.update(result.stdout.strip().split("\n"))
                    commits_processed += 1
            except (subprocess.TimeoutExpired, FileNotFoundError):
                logger.warning(f"Failed to get diff-tree for commit {sha}")

        if all_files:
            af_manager.set_files(resolved_id, sorted(all_files), "observed")

        return {
            "task_id": resolved_id,
            "commits_processed": commits_processed,
            "files_observed": len(all_files),
            "files": sorted(all_files),
        }

    registry.register(
        name="update_observed_files",
        description="Annotate a task's affected files from its linked commits. "
        "Runs git diff-tree on each commit to discover actually-changed files "
        "and stores them as 'observed' annotations for conflict detection.",
        input_schema={
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Task reference: #N, path, or UUID",
                },
                "require_commits": {
                    "type": "boolean",
                    "description": "If true, fails if no linked commits are found",
                    "default": False,
                },
            },
            "required": ["task_id"],
        },
        func=update_observed_files,
    )

    return registry


def create_ops_affected_files_registry(ctx: "RegistryContext") -> InternalToolRegistry:
    """Create a registry with ops affected file tools (gobby-tasks-ops).

    Includes set, get, find_overlaps, wire_from_run — used by expansion pipeline.
    """

    registry = InternalToolRegistry(
        name="gobby-tasks-affected-files-ops",
        description="Ops affected file tools (expansion pipeline)",
    )

    af_manager = TaskAffectedFileManager(ctx.task_manager.db)

    # --- set_affected_files ---

    def set_affected_files(
        task_id: str,
        files: list[str],
        source: str = "manual",
    ) -> dict[str, Any]:
        """Set affected files for a task."""
        try:
            resolved_id = resolve_task_id_for_mcp(ctx.task_manager, task_id)
        except (TaskNotFoundError, ValueError) as e:
            return {"error": f"Invalid task_id: {e}"}

        if source not in ("expansion", "manual", "observed"):
            return {
                "error": f"Invalid source: {source}. Must be 'expansion', 'manual', or 'observed'."
            }

        annotation_source = cast(AnnotationSource, source)
        results = af_manager.set_files(resolved_id, files, annotation_source)
        return {
            "task_id": resolved_id,
            "files_set": len(results),
            "files": [r.file_path for r in results],
        }

    registry.register(
        name="set_affected_files",
        description="Set affected files for a task. Replaces existing files for the given source.",
        input_schema={
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Task reference: #N, path, or UUID",
                },
                "files": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of file paths (relative to repo root)",
                },
                "source": {
                    "type": "string",
                    "description": "Annotation source: 'expansion', 'manual' (default), or 'observed'",
                    "default": "manual",
                    "enum": ["expansion", "manual", "observed"],
                },
            },
            "required": ["task_id", "files"],
        },
        func=set_affected_files,
    )

    # --- get_affected_files ---

    def get_affected_files(task_id: str) -> dict[str, Any]:
        """Get affected files for a task."""
        try:
            resolved_id = resolve_task_id_for_mcp(ctx.task_manager, task_id)
        except (TaskNotFoundError, ValueError) as e:
            return {"error": f"Invalid task_id: {e}"}

        files = af_manager.get_files(resolved_id)
        return {
            "task_id": resolved_id,
            "count": len(files),
            "files": [f.to_dict() for f in files],
        }

    registry.register(
        name="get_affected_files",
        description="Get affected files for a task.",
        input_schema={
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Task reference: #N, path, or UUID",
                },
            },
            "required": ["task_id"],
        },
        func=get_affected_files,
    )

    # --- find_file_overlaps ---

    def find_file_overlaps(task_ids: list[str]) -> dict[str, Any]:
        """Find file overlaps between tasks."""
        resolved_ids = []
        for tid in task_ids:
            try:
                resolved_ids.append(resolve_task_id_for_mcp(ctx.task_manager, tid))
            except (TaskNotFoundError, ValueError) as e:
                return {"error": f"Invalid task_id '{tid}': {e}"}

        overlaps = af_manager.find_overlapping_tasks(resolved_ids)
        # Convert tuple keys to string for JSON serialization
        result = []
        for (task_a, task_b), shared_files in overlaps.items():
            result.append(
                {
                    "task_a": task_a,
                    "task_b": task_b,
                    "shared_files": shared_files,
                    "overlap_count": len(shared_files),
                }
            )

        return {
            "task_count": len(resolved_ids),
            "overlapping_pairs": len(result),
            "overlaps": result,
        }

    registry.register(
        name="find_file_overlaps",
        description="Detect file contention between tasks. Returns pairs of tasks that share affected files.",
        input_schema={
            "type": "object",
            "properties": {
                "task_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of task references to check for overlaps",
                },
            },
            "required": ["task_ids"],
        },
        func=find_file_overlaps,
    )

    # --- wire_affected_files_from_run ---

    def wire_affected_files_from_run(
        run_id: str,
    ) -> dict[str, Any]:
        """Re-apply affected files from a compiled expansion run.

        Uses the run's stable task-id mapping rather than title matching.
        This is mainly a repair tool; normal expansion apply writes affected
        files directly as tasks are created.
        """
        run_manager = LocalExpansionRunManager(ctx.task_manager.db)
        run = run_manager.get(run_id)
        if run is None:
            return {"error": f"Expansion run {run_id} not found"}
        if not run.compiled_spec:
            return {"error": "Expansion run has no compiled spec"}
        if not run.task_id_map:
            return {"error": "Expansion run has no applied task mapping"}

        tasks = run.compiled_spec.get("tasks") or []
        wired = 0
        skipped = 0
        for task_spec in tasks:
            affected_files = task_spec.get("affected_files") or []
            if not affected_files:
                skipped += 1
                continue
            task_id_key = task_spec.get("id")
            if not task_id_key:
                skipped += 1
                continue
            created_task_id = run.task_id_map.get(task_id_key)
            if not created_task_id:
                skipped += 1
                continue
            af_manager.set_files(created_task_id, affected_files, "expansion")
            wired += 1

        return {
            "run_id": run_id,
            "wired": wired,
            "total_tasks": len(tasks),
            "skipped": skipped,
        }

    registry.register(
        name="wire_affected_files_from_run",
        description="Re-apply affected files from a compiled expansion run using stable task IDs.",
        input_schema={
            "type": "object",
            "properties": {
                "run_id": {
                    "type": "string",
                    "description": "Expansion run ID with compiled spec and applied task map",
                },
            },
            "required": ["run_id"],
        },
        func=wire_affected_files_from_run,
    )

    return registry
