"""Mission CLI — command model v2."""

from __future__ import annotations

import json
import os
import re
import signal
import shlex
import subprocess
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path

import click
import typer
from typer.core import TyperGroup

from importlib.metadata import version as _pkg_version

from mation import cmux
from mation.agents.cc import CCAgent
from mation.state import (
    STATE_DIR,
    add_supervisor,
    add_worker,
    create_mission,
    create_task,
    delete_all,
    delete_mission,
    find_supervisor,
    find_worker,
    get_sole_worker,
    get_task,
    iter_workers,
    list_missions,
    list_tasks,
    load_global,
    load_mission,
    new_global,
    remove_supervisor,
    remove_task,
    remove_worker,
    resolve_content,
    save_global,
    save_mission,
    task_store_dir,
    update_task,
)
from mation.worker import WorkerInfo, resolve_worker, worker_cache_from_info

_HELP = """mation CLI

全局主体只有：
  self
  mission
"""

MISSION_HELP = """mission 管理

Commands:
  create
  update
  remove
  list
  show
  start
  stop

Mission-scoped 用法:
  mation <mission_id> task ...
  mation <mission_id> supervisor ...
  mation <mission_id> worker ...

继续查看:
  mation mission task -h
  mation mission supervisor -h
  mation mission worker -h
"""

class RootGroup(TyperGroup):
    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        if args and args[0].startswith("-"):
            return super().parse_args(ctx, args)
        if args and args[0] not in self.commands and args[0] not in {"-h", "--help"}:
            ctx.meta["mission_scoped_args"] = list(args)
            return []
        return super().parse_args(ctx, args)


class MissionGroup(TyperGroup):
    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        if args and args[0] in MISSION_SCOPED_HELP and args[0] not in self.commands:
            ctx.meta["mission_help_args"] = list(args)
            return []
        return super().parse_args(ctx, args)


app = typer.Typer(
    cls=RootGroup,
    help=_HELP,
    context_settings={"help_option_names": ["-h", "--help"]},
    invoke_without_command=True,
    no_args_is_help=True,
)
self_app = typer.Typer(help="mation 系统管理")
mission_app = typer.Typer(
    cls=MissionGroup,
    help=MISSION_HELP,
    invoke_without_command=True,
)
app.add_typer(self_app, name="self")
app.add_typer(mission_app, name="mission")


MISSION_SCOPED_HELP = {
    "task": """Usage: mation <mission_id> task [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n""",
    "supervisor": """Usage: mation <mission_id> supervisor [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n  send\n  read\n  kick\n""",
    "worker": """Usage: mation <mission_id> worker [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n""",
}
OLD_ROOT_COMMANDS = {"start", "stop", "resume", "status", "send", "read", "kick", "transcript", "plan", "prompt", "worker"}
TASK_STATUS_ALLOWED = {"pending", "in_progress", "completed", "deleted"}
UUID_CANONICAL_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)
UUID_PREFIX_RE = re.compile(r"^[0-9a-fA-F-]{1,36}$")

CREATE_HELP = {
    "supervisor": """Usage: mation <mission_id> supervisor create [OPTIONS]\n\nOptions:\n  --name TEXT\n  --path TEXT\n  -h, --help
""",
    "worker": """Usage: mation <mission_id> worker create [OPTIONS]\n\nOptions:\n  --name TEXT\n  --path TEXT\n  --session TEXT  绑定已有 CC session，跳过 spawn\n  -h, --help
""",
}

COMMAND_HELP = {
    "task": {
        "create": """Usage: mation <mission_id> task create <subject>\n""",
        "update": """Usage: mation <mission_id> task update <task_id> [--subject TEXT] [--description TEXT] [--status TEXT] [--owner TEXT] [--blocks CSV] [--blocked-by CSV]\n""",
    },
    "supervisor": {
        "send": """Usage: mation <mission_id> supervisor send [worker_id] <message>\n""",
        "read": """Usage: mation <mission_id> supervisor read [worker_id]\n""",
        "kick": """Usage: mation <mission_id> supervisor kick [worker_id]\n""",
    },
}


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(_pkg_version("mation"))
        raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", "-V", "-v", callback=_version_callback, is_eager=True, help="显示版本"),
) -> None:
    if ctx.invoked_subcommand is not None:
        return

    scoped_args = ctx.meta.get("mission_scoped_args")
    if not scoped_args:
        return

    mission_id = scoped_args[0]
    rest = scoped_args[1:]

    allow_discovery_help = mission_id in MISSION_SCOPED_HELP and (
        not rest
        or rest in (["--help"], ["-h"])
        or (len(rest) == 2 and rest[0] == "create" and rest[1] in {"--help", "-h"})
    )
    if mission_id in OLD_ROOT_COMMANDS and not allow_discovery_help:
        typer.echo(f"No such command '{mission_id}'", err=True)
        raise typer.Exit(2)

    # Discoverability: allow mission-scoped help without a concrete mission_id,
    # e.g. `mation task --help`, while root subjects remain only self/mission.
    if mission_id in MISSION_SCOPED_HELP:
        if not rest or rest == ["--help"] or rest == ["-h"]:
            typer.echo(MISSION_SCOPED_HELP[mission_id])
            raise typer.Exit()
        if len(rest) == 2 and rest[0] == "create" and rest[1] in {"--help", "-h"} and mission_id in CREATE_HELP:
            typer.echo(CREATE_HELP[mission_id])
            raise typer.Exit()

    if not rest:
        typer.echo(f"Mission '{mission_id}' requires a scoped command", err=True)
        raise typer.Exit(2)

    subject = rest[0]
    if len(rest) == 2 and rest[1] in {"--help", "-h"} and subject in MISSION_SCOPED_HELP:
        typer.echo(MISSION_SCOPED_HELP[subject])
        raise typer.Exit()
    if len(rest) == 3 and rest[2] in {"--help", "-h"} and subject in CREATE_HELP and rest[1] == "create":
        typer.echo(CREATE_HELP[subject])
        raise typer.Exit()

    _dispatch_mission_scoped(mission_id, rest)


# ── Helpers ───────────────────────────────────────────────────


def _require_global() -> dict:
    state = load_global()
    if state is None:
        typer.echo("没有活跃的 mation。先运行 mation self start", err=True)
        raise typer.Exit(1)
    return state


def _require_mission_by_name(name: str) -> dict:
    mission = load_mission(name)
    if mission is None:
        typer.echo(f"Mission '{name}' 不存在", err=True)
        raise typer.Exit(1)
    return mission


def _require_mission_active(mission_id: str, mission: dict) -> None:
    if mission.get("status") == "stopped":
        typer.echo(
            f"Mission '{mission_id}' 已停止，daemon 不会处理事件。"
            f" 请先运行：mation mission start {mission_id}",
            err=True,
        )
        raise typer.Exit(1)


def _extract_named_option(args: list[str], option: str) -> tuple[str | None, list[str]]:
    rest = list(args)
    if option not in rest:
        return None, rest
    index = rest.index(option)
    if index + 1 >= len(rest):
        typer.echo(f"Missing value for {option}", err=True)
        raise typer.Exit(2)
    value = rest[index + 1]
    del rest[index:index + 2]
    return value, rest


def _resolve_session_id_by_prefix_or_fail(
    *,
    mission: dict,
    role: str,
    raw_id: str,
    id_label: str,
) -> str:
    participants = [
        p for p in mission.get("participants", []) if p.get("role") == role and isinstance(p.get("session"), str)
    ]
    sessions = [p["session"] for p in participants]

    if UUID_CANONICAL_RE.fullmatch(raw_id):
        if raw_id in sessions:
            return raw_id
        typer.echo(f"{id_label} '{raw_id}' 不存在", err=True)
        raise typer.Exit(1)

    if not UUID_PREFIX_RE.fullmatch(raw_id):
        typer.echo(f"{id_label} 必须是 UUID 或唯一前缀", err=True)
        raise typer.Exit(1)

    matches = [session for session in sessions if session.startswith(raw_id)]
    if not matches:
        typer.echo(f"{id_label} '{raw_id}' 不存在", err=True)
        raise typer.Exit(1)
    if len(matches) > 1:
        candidates = ", ".join(sorted(matches))
        typer.echo(f"{id_label} '{raw_id}' 歧义: {candidates}", err=True)
        raise typer.Exit(1)
    return matches[0]


def _resolve_task_status_or_fail(status: str) -> str:
    if status not in TASK_STATUS_ALLOWED:
        allowed = ", ".join(sorted(TASK_STATUS_ALLOWED))
        typer.echo(f"Invalid --status '{status}'. allowed: {allowed}", err=True)
        raise typer.Exit(2)
    return status


def _parse_worker_target_or_fail(mission: dict, payload: list[str], *, command: str) -> tuple[dict, list[str]]:
    workers = iter_workers(mission)
    if payload and payload[0] in {"-h", "--help"}:
        help_text = COMMAND_HELP.get("supervisor", {}).get(command)
        if help_text:
            typer.echo(help_text)
            raise typer.Exit()
        typer.echo(f"Usage: mation <mission_id> supervisor {command} [worker_id]")
        raise typer.Exit()

    if not workers:
        typer.echo("Worker not found in mission", err=True)
        raise typer.Exit(1)

    if len(workers) == 1:
        only_worker = workers[0]
        if not payload:
            if command == "send":
                typer.echo("message is required", err=True)
                raise typer.Exit(2)
            return only_worker, []
        if payload[0].startswith("--"):
            raise click.UsageError(f"No such option '{payload[0]}'")

        if command == "send":
            if len(payload) > 1:
                resolved = _resolve_session_id_by_prefix_or_fail(
                    mission=mission,
                    role="worker",
                    raw_id=payload[0],
                    id_label="worker_id",
                )
                worker = find_worker(mission, resolved)
                if worker is None:
                    typer.echo("Worker not found in mission", err=True)
                    raise typer.Exit(1)
                return worker, payload[1:]
            return only_worker, payload

        resolved = _resolve_session_id_by_prefix_or_fail(
            mission=mission,
            role="worker",
            raw_id=payload[0],
            id_label="worker_id",
        )
        worker = find_worker(mission, resolved)
        if worker is None:
            typer.echo("Worker not found in mission", err=True)
            raise typer.Exit(1)
        return worker, payload[1:]

    if not payload:
        typer.echo("Multiple workers found; specify worker_id", err=True)
        raise typer.Exit(1)
    if payload[0].startswith("--"):
        raise click.UsageError(f"No such option '{payload[0]}'")
    if command == "send" and len(payload) == 1:
        typer.echo("Multiple workers found; specify worker_id", err=True)
        raise typer.Exit(1)

    resolved = _resolve_session_id_by_prefix_or_fail(
        mission=mission,
        role="worker",
        raw_id=payload[0],
        id_label="worker_id",
    )
    worker = find_worker(mission, resolved)
    if worker is None:
        typer.echo("Worker not found in mission", err=True)
        raise typer.Exit(1)
    return worker, payload[1:]


def _ensure_worker_online_or_fail(*, worker: dict, mission_id: str, mission: dict) -> tuple[str, WorkerInfo]:
    info = _refresh_worker_cache(worker, mission_id, mission)
    session = worker["session"]
    if not info.running:
        typer.echo("Worker is offline", err=True)
        raise typer.Exit(1)
    surface_id = (worker.get("cache") or {}).get("surface_id")
    if not surface_id:
        typer.echo("Worker surface unavailable", err=True)
        raise typer.Exit(1)
    return str(surface_id), info


def _parse_task_update_payload(payload: list[str]) -> tuple[str, dict[str, object]]:
    if payload and payload[0] in {"-h", "--help"}:
        typer.echo(COMMAND_HELP["task"]["update"])
        raise typer.Exit()
    if not payload:
        typer.echo("Task id is required", err=True)
        raise typer.Exit(2)

    task_id = payload[0]
    rest = payload[1:]
    option_map = {
        "--subject": "subject",
        "--description": "description",
        "--status": "status",
        "--owner": "owner",
        "--blocks": "blocks",
        "--blocked-by": "blockedBy",
    }

    patch: dict[str, object] = {}
    index = 0
    while index < len(rest):
        option = rest[index]
        field = option_map.get(option)
        if field is None:
            if option.startswith("--"):
                typer.echo(f"No such option '{option}'", err=True)
            else:
                typer.echo(f"Unexpected argument '{option}'", err=True)
            raise typer.Exit(2)
        if index + 1 >= len(rest):
            typer.echo(f"Missing value for {option}", err=True)
            raise typer.Exit(2)

        value = rest[index + 1]
        if field in {"blocks", "blockedBy"}:
            patch[field] = [item.strip() for item in value.split(",") if item.strip()]
        elif field == "status":
            patch[field] = _resolve_task_status_or_fail(value)
        else:
            patch[field] = value
        index += 2

    return task_id, patch


def _refresh_worker_cache(worker: dict, mission_name: str, mission: dict) -> WorkerInfo:
    info = resolve_worker(worker["session"])
    if info.running:
        new_cache = worker_cache_from_info(info)
        if new_cache != worker.get("cache"):
            worker["cache"] = new_cache
            save_mission(mission_name, mission)
    return info


def _parse_name_path_update(payload: list[str], *, id_label: str) -> tuple[str, str | None, str | None]:
    if not payload:
        typer.echo(f"{id_label} is required", err=True)
        raise typer.Exit(2)

    target_id = payload[0]
    rest = payload[1:]
    name: str | None = None
    path: str | None = None
    index = 0
    while index < len(rest):
        option = rest[index]
        if option not in {"--name", "--path"}:
            if option.startswith("--"):
                typer.echo(f"No such option '{option}'", err=True)
            else:
                typer.echo(f"Unexpected argument '{option}'", err=True)
            raise typer.Exit(2)
        if index + 1 >= len(rest):
            typer.echo(f"Missing value for {option}", err=True)
            raise typer.Exit(2)
        value = rest[index + 1]
        if option == "--name":
            name = value
        else:
            path = value
        index += 2

    return target_id, name, path


def _is_daemon_running(global_state: dict) -> bool:
    pid = global_state.get("daemon_pid")
    if not pid:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, TypeError):
        return False


def _format_timestamp(ts: float | None) -> str:
    if not ts:
        return "未知"
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


def _generate_session_id() -> str:
    return str(uuid.uuid4())


def _generate_mission_id() -> str:
    return uuid.uuid4().hex[:8]


def _validate_spawn_path_or_fail(path: str | None) -> None:
    if path is None:
        return
    if not os.path.isdir(path):
        typer.echo(f"path 不存在或不是目录: {path}", err=True)
        raise typer.Exit(1)


def build_ready_expect(role: str, session: str) -> str:
    _ = (role, session)
    return "any assistant reply"


def build_worker_contract_v1() -> str:
    return "mation cli 是一个管理 mation 的命令行工具，您被禁止使用此工具。"


def build_supervisor_contract_v1() -> str:
    return (
        "你是 mation 任务中的 supervisor。你的职责是推进任务并审查 worker 产出。"
        "你不直接实现代码，只通过 mission-scoped mation 命令进行协调。"
        "命令路径：mation self ...；mation mission ...；mation <mission_id> task ...；mation <mission_id> supervisor ...；mation <mission_id> worker ...。"
        "mation self show/start/stop/reset；"
        "mation mission create（ID 自动生成）/update/remove/list/show/start/stop <mission_id>；"
        "mation <mission_id> task create/update/remove/list/show ...；"
        "mation <mission_id> supervisor create/update/remove/list/show/send/read/kick ...；"
        "mation <mission_id> worker create/update/remove/list/show ...。"
        "按 mission 外循环 + task 内循环执行。"
        "mission 外循环：检查 mission 目标与当前任务队列；若任务耗尽但目标未达成，生成新 task 并继续推进；若目标达成则收口 mission。"
        "task 内循环：task list -> supervisor send -> supervisor kick -> supervisor read -> task update。"
        "mation是事件驱动系统。你需要理解并遵守以下运行语义："
        "mation系统会有两种notification stop 和stall. 当worker停下来时，mation系统会将worker的结果以stop notification发送给supervisor，当worker停止一段时间后，mation系统会将worker的状态的以stall notification发送给supervisor. 因此你不需要重复 read/send 制造噪声。"
        "stop notification 格式：<mation event=\"stop\" mission=\"...\" worker=\"...\" output_file=\"/path/to/file\"><reply>前200字...</reply></mation>。"
        "output_file 是 worker 完整输出的文件路径（仅在输出超过200字时附带）。需要将结果传给下游 worker 时，直接传 output_file 路径，无需转述内容。"
        "`mation <mission_id> worker create [--path <dir>]` 会自动在新 surface 启动一个 Worker CC session，无需 Human 手动操作，直接运行即可。worker create 后，新worker session的首次stop 属于初始化确认，系统会不发送该通知，不作为任务结果事件，但是 worker create 的返回值是能体现 worker session 是否创建成功的。"
        "you will be automatically notified when it completes — do NOT sleep, poll, or proactively check on its progress."
        "Do not sleep between commands that can run immediately — just run them."
        "Messages from teammates are automatically delivered to you. You do NOT need to manually check your inbox."
        "kick 通常在有过 stall 通知后才考虑使用supervisor kick，不能随便使用 kick。否则会打断 worker 的正常运行。"
        "额外偏好：主线优先；禁止表演；强绑定 mation 命令。不要充当 worker。"
        "### 协调 "
        "分派任务前，先思考 worker 的处境：它实际能访问到什么、还缺什么、拿到指令后大概率会怎么行动。"
        "想清楚这三点再发指令，否则是在把协调的责任甩给 worker。"
    )


def build_worker_bootstrap_prompt_v1(mission_id: str, session: str, name: str | None) -> str:
    _ = name
    return f"Mission: '{mission_id}'。session id: {session}。你是 worker，等待 supervisor 指令后再执行。理解后回复 OK。"


def build_supervisor_bootstrap_prompt_v1(mission_id: str, session: str, name: str | None) -> str:
    _ = name
    return f"Mission: '{mission_id}'。session_id: {session}。你是 supervisor，负责通过 mation 命令推进任务。理解后回复 OK，然后停下来等待下一步指令，不要主动开始工作。"


def _build_contract_metadata(role: str, append_system_prompt: str, bootstrap_prompt: str, ready_expect: str) -> dict:
    return {
        "version": "v1",
        "kind": role,
        "append_system_prompt": append_system_prompt,
        "bootstrap_prompt": bootstrap_prompt,
        "ready_expect": ready_expect,
        "applied_via": "claude-create",
        "created_at": datetime.now().isoformat(),
    }


def _spawn_claude_session(
    session: str,
    path: str | None,
    *,
    bootstrap_prompt: str,
    append_system_prompt: str,
) -> None:
    target_path = path or os.getcwd()

    pane_ref = "pane:1"
    current_surface = cmux.get_current_surface()
    if current_surface:
        try:
            panes = subprocess.run(
                ["cmux", "list-panes"],
                capture_output=True,
                text=True,
                check=True,
            ).stdout.splitlines()
            for line in panes:
                if line.strip().startswith("*") and "pane:" in line:
                    parts = line.strip().split()
                    if len(parts) >= 2 and parts[1].startswith("pane:"):
                        pane_ref = parts[1]
                        break
        except Exception:
            pass

    new_surface_output = subprocess.run(
        ["cmux", "new-surface", "--type", "terminal", "--pane", pane_ref],
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()

    surface_ref = None
    for token in new_surface_output.split():
        if token.startswith("surface:"):
            surface_ref = token
            break
    if surface_ref is None:
        raise RuntimeError("cmux new-surface did not return surface ref")

    subprocess.run(["cmux", "send", "--surface", surface_ref, f"cd {shlex.quote(target_path)}"], check=True, capture_output=True)
    subprocess.run(["cmux", "send-key", "--surface", surface_ref, "Enter"], check=True, capture_output=True)

    cmd = (
        "claude "
        f"{shlex.quote(bootstrap_prompt)} "
        f"--session-id {shlex.quote(session)} "
        f"--append-system-prompt {shlex.quote(append_system_prompt)}"
    )
    subprocess.run(["cmux", "send", "--surface", surface_ref, cmd], check=True, capture_output=True)
    subprocess.run(["cmux", "send-key", "--surface", surface_ref, "Enter"], check=True, capture_output=True)

    # 新目录首次启动 Claude 可能出现 workspace trust 确认，自动选择 1 继续
    for _ in range(10):
        time.sleep(1)
        try:
            screen = subprocess.run(
                ["cmux", "read-screen", "--surface", surface_ref, "--lines", "120"],
                capture_output=True,
                text=True,
                check=True,
            ).stdout
        except Exception:
            continue

        if "Yes, I trust this folder" in screen and "Enter to confirm" in screen:
            subprocess.run(["cmux", "send", "--surface", surface_ref, "1"], check=True, capture_output=True)
            subprocess.run(["cmux", "send-key", "--surface", surface_ref, "Enter"], check=True, capture_output=True)
            break


def _is_ready_message_present(jsonl_path: str | Path | None) -> bool:
    if not jsonl_path:
        return False
    agent = CCAgent()
    last = agent.last_message("", jsonl_path=jsonl_path)
    return last is not None and bool(last.text.strip())


def _wait_for_worker_ready(
    session: str,
    *,
    attempts: int = 10,
    interval: float = 0.2,
) -> WorkerInfo:
    info = resolve_worker(session)
    jsonl_attempts = max(attempts, 300)
    for _ in range(jsonl_attempts - 1):
        if info.jsonl_path is not None:
            break
        time.sleep(interval)
        info = resolve_worker(session)

    if info.jsonl_path is None:
        return info

    ready_attempts = max(attempts, 300)
    for _ in range(ready_attempts):
        if _is_ready_message_present(info.jsonl_path):
            return info
        time.sleep(interval)
    raise TimeoutError(f"Session '{session}' did not reach ready state")


def _launch_daemon(global_state: dict, foreground: bool) -> None:
    global_state["stopped"] = False
    if foreground:
        global_state["daemon_pid"] = os.getpid()
        save_global(global_state)
        typer.echo(f"Daemon 已启动，PID {os.getpid()}，前台模式。")
        from mation.daemon import run_daemon
        run_daemon()
        return

    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_DIR / "daemon.log", "a", encoding="utf-8") as log_file:
        proc = subprocess.Popen(
            [sys.executable, "-m", "mation.daemon_runner"],
            stdout=log_file,
            stderr=log_file,
        )
    global_state["daemon_pid"] = proc.pid
    save_global(global_state)
    typer.echo(f"Daemon 已启动，PID {proc.pid}，后台模式。")


def _dispatch_mission_scoped(mission_id: str, args: list[str]) -> None:
    if not args:
        typer.echo(f"Mission '{mission_id}' requires a scoped command", err=True)
        raise typer.Exit(2)

    _require_global()
    mission = _require_mission_by_name(mission_id)
    resource = args[0]
    command = args[1] if len(args) > 1 else None
    payload = args[2:]

    if resource == "task":
        if command == "create":
            if payload and payload[0] in {"-h", "--help"}:
                typer.echo(COMMAND_HELP["task"]["create"])
                raise typer.Exit()
            if not payload:
                typer.echo("Task subject is required", err=True)
                raise typer.Exit(2)
            task = create_task(mission_id, subject=payload[0])
            typer.echo(f"Task '{task['id']}' created: {task['subject']}")
            raise typer.Exit()
        if command == "update":
            task_id, patch = _parse_task_update_payload(payload)
            if get_task(mission_id, task_id) is None:
                typer.echo(f"Task '{task_id}' 不存在", err=True)
                raise typer.Exit(1)
            task = update_task(mission_id, task_id, patch)
            typer.echo(f"Task '{task['id']}' updated")
            raise typer.Exit()
        if command == "remove":
            if not payload:
                typer.echo("Task id is required", err=True)
                raise typer.Exit(2)
            task_id = payload[0]
            if not remove_task(mission_id, task_id):
                typer.echo(f"Task '{task_id}' 不存在", err=True)
                raise typer.Exit(1)
            typer.echo(f"Task '{task_id}' removed")
            raise typer.Exit()
        if command == "list":
            tasks = list_tasks(mission_id)
            if not tasks:
                typer.echo("(无 task)")
                raise typer.Exit()
            typer.echo("\n".join(f"#{task['id']} {task['subject']}" for task in tasks))
            raise typer.Exit()
        if command == "show":
            if not payload:
                typer.echo("Task id is required", err=True)
                raise typer.Exit(2)
            task = get_task(mission_id, payload[0])
            if task is None:
                typer.echo(f"Task '{payload[0]}' 不存在", err=True)
                raise typer.Exit(1)
            typer.echo(json.dumps(task, ensure_ascii=False, indent=2))
            raise typer.Exit()
        typer.echo(f"No such command '{command}'", err=True)
        raise typer.Exit(2)

    if resource == "worker":
        if command == "create":
            name, rest = _extract_named_option(payload, "--name")
            path, rest = _extract_named_option(rest, "--path")
            existing_session, rest = _extract_named_option(rest, "--session")
            if rest:
                typer.echo("No such argument", err=True)
                raise typer.Exit(2)

            if existing_session is not None:
                # Register an existing session — skip spawn
                _require_mission_active(mission_id, mission)
                info = resolve_worker(existing_session)
                if info.jsonl_path is None:
                    typer.echo(f"session 不存在或尚未产生对话记录: '{existing_session}'", err=True)
                    raise typer.Exit(1)
                session = existing_session
                add_worker(
                    mission,
                    session,
                    cache=worker_cache_from_info(info),
                    name=name,
                    path=path,
                    contract=None,
                    bootstrapped=True,
                )
                save_mission(mission_id, mission)
                typer.echo(f"Worker '{session}' 已创建。")
                raise typer.Exit()

            _require_mission_active(mission_id, mission)
            _validate_spawn_path_or_fail(path)
            session = _generate_session_id()
            append_system_prompt = build_worker_contract_v1()
            bootstrap_prompt = build_worker_bootstrap_prompt_v1(mission_id, session, name)
            ready_expect = build_ready_expect("worker", session)
            contract = _build_contract_metadata("worker", append_system_prompt, bootstrap_prompt, ready_expect)
            _spawn_claude_session(
                session,
                path,
                bootstrap_prompt=bootstrap_prompt,
                append_system_prompt=append_system_prompt,
            )
            try:
                info = _wait_for_worker_ready(session)
            except TimeoutError as exc:
                typer.echo(str(exc), err=True)
                raise typer.Exit(1)
            if info.jsonl_path is None:
                typer.echo(f"未找到可用的 session '{session}'", err=True)
                raise typer.Exit(1)
            add_worker(
                mission,
                session,
                cache=worker_cache_from_info(info),
                name=name,
                path=path,
                contract=contract,
            )
            save_mission(mission_id, mission)
            typer.echo(f"Worker '{session}' 已创建。")
            raise typer.Exit()
        if command == "list":
            workers = iter_workers(mission)
            if not workers:
                typer.echo("(无 worker)")
                raise typer.Exit()
            typer.echo("\n".join(worker["session"] for worker in workers))
            raise typer.Exit()
        if command == "show":
            if not payload:
                typer.echo("worker_id is required", err=True)
                raise typer.Exit(2)
            resolved = _resolve_session_id_by_prefix_or_fail(
                mission=mission,
                role="worker",
                raw_id=payload[0],
                id_label="worker_id",
            )
            worker = find_worker(mission, resolved)
            if worker is None:
                typer.echo(f"Worker '{payload[0]}' 不存在", err=True)
                raise typer.Exit(1)
            typer.echo(json.dumps(worker, ensure_ascii=False, indent=2))
            raise typer.Exit()
        if command == "update":
            worker_id, name, path = _parse_name_path_update(payload, id_label="worker_id")
            resolved = _resolve_session_id_by_prefix_or_fail(
                mission=mission,
                role="worker",
                raw_id=worker_id,
                id_label="worker_id",
            )
            worker = find_worker(mission, resolved)
            if worker is None:
                typer.echo(f"Worker '{worker_id}' 不存在", err=True)
                raise typer.Exit(1)
            if name is not None:
                worker["name"] = name
            if path is not None:
                worker["path"] = path
            save_mission(mission_id, mission)
            typer.echo(f"Worker '{resolved}' 已更新。")
            raise typer.Exit()
        if command == "remove":
            if not payload:
                typer.echo("worker_id is required", err=True)
                raise typer.Exit(2)
            resolved = _resolve_session_id_by_prefix_or_fail(
                mission=mission,
                role="worker",
                raw_id=payload[0],
                id_label="worker_id",
            )
            if not remove_worker(mission, resolved):
                typer.echo(f"Worker '{payload[0]}' 不存在", err=True)
                raise typer.Exit(1)
            save_mission(mission_id, mission)
            typer.echo(f"Worker '{resolved}' 已删除。")
            raise typer.Exit()
        typer.echo(f"No such command '{command}'", err=True)
        raise typer.Exit(2)

    if resource == "supervisor":
        if command == "create":
            name, rest = _extract_named_option(payload, "--name")
            path, rest = _extract_named_option(rest, "--path")
            if rest:
                typer.echo("No such argument", err=True)
                raise typer.Exit(2)
            _validate_spawn_path_or_fail(path)
            session = _generate_session_id()
            append_system_prompt = build_supervisor_contract_v1()
            bootstrap_prompt = build_supervisor_bootstrap_prompt_v1(mission_id, session, name)
            ready_expect = build_ready_expect("supervisor", session)
            contract = _build_contract_metadata("supervisor", append_system_prompt, bootstrap_prompt, ready_expect)
            _spawn_claude_session(
                session,
                path,
                bootstrap_prompt=bootstrap_prompt,
                append_system_prompt=append_system_prompt,
            )
            try:
                info = _wait_for_worker_ready(session)
            except TimeoutError as exc:
                typer.echo(str(exc), err=True)
                raise typer.Exit(1)
            if info.jsonl_path is None:
                typer.echo(f"未找到可用的 session '{session}'", err=True)
                raise typer.Exit(1)
            add_supervisor(
                mission,
                session,
                cache=worker_cache_from_info(info),
                name=name,
                path=path,
                contract=contract,
            )
            save_mission(mission_id, mission)
            typer.echo(f"Supervisor '{session}' 已创建。")
            raise typer.Exit()
        if command == "list":
            supervisor = find_supervisor(mission)
            if supervisor is None:
                typer.echo("(无 supervisor)")
                raise typer.Exit()
            typer.echo(supervisor["session"])
            raise typer.Exit()
        if command == "show":
            if not payload:
                typer.echo("supervisor_id is required", err=True)
                raise typer.Exit(2)
            resolved = _resolve_session_id_by_prefix_or_fail(
                mission=mission,
                role="supervisor",
                raw_id=payload[0],
                id_label="supervisor_id",
            )
            supervisor = find_supervisor(mission)
            if supervisor is None or supervisor.get("session") != resolved:
                typer.echo(f"Supervisor '{payload[0]}' 不存在", err=True)
                raise typer.Exit(1)
            typer.echo(json.dumps(supervisor, ensure_ascii=False, indent=2))
            raise typer.Exit()
        if command == "update":
            supervisor_id, name, path = _parse_name_path_update(payload, id_label="supervisor_id")
            resolved = _resolve_session_id_by_prefix_or_fail(
                mission=mission,
                role="supervisor",
                raw_id=supervisor_id,
                id_label="supervisor_id",
            )
            supervisor = find_supervisor(mission)
            if supervisor is None or supervisor.get("session") != resolved:
                typer.echo(f"Supervisor '{supervisor_id}' 不存在", err=True)
                raise typer.Exit(1)
            if name is not None:
                supervisor["name"] = name
            if path is not None:
                supervisor["path"] = path
            save_mission(mission_id, mission)
            typer.echo(f"Supervisor '{resolved}' 已更新。")
            raise typer.Exit()
        if command == "remove":
            if not payload:
                typer.echo("supervisor_id is required", err=True)
                raise typer.Exit(2)
            resolved = _resolve_session_id_by_prefix_or_fail(
                mission=mission,
                role="supervisor",
                raw_id=payload[0],
                id_label="supervisor_id",
            )
            supervisor = find_supervisor(mission)
            if supervisor is None or supervisor.get("session") != resolved:
                typer.echo(f"Supervisor '{payload[0]}' 不存在", err=True)
                raise typer.Exit(1)
            remove_supervisor(mission)
            save_mission(mission_id, mission)
            typer.echo(f"Supervisor '{resolved}' 已删除。")
            raise typer.Exit()
        if command == "read":
            worker, _ = _parse_worker_target_or_fail(mission, payload, command="read")
            target_worker_id = worker["session"]
            _, info = _ensure_worker_online_or_fail(worker=worker, mission_id=mission_id, mission=mission)

            agent = CCAgent()
            if info.jsonl_path is not None:
                last = agent.last_message(target_worker_id, jsonl_path=info.jsonl_path)
            else:
                last = agent.last_message(target_worker_id)
            if last is None:
                typer.echo(f"Worker '{target_worker_id}' 暂无可读消息", err=True)
                raise typer.Exit(1)
            typer.echo(last.text)
            raise typer.Exit()
        if command == "send":
            _require_mission_active(mission_id, mission)
            if not payload:
                typer.echo("message is required", err=True)
                raise typer.Exit(2)
            worker, rest_payload = _parse_worker_target_or_fail(mission, payload, command="send")
            if not rest_payload:
                typer.echo("message is required", err=True)
                raise typer.Exit(2)
            message = " ".join(rest_payload)

            target_worker_id = worker["session"]
            surface_id, _ = _ensure_worker_online_or_fail(worker=worker, mission_id=mission_id, mission=mission)
            cmux.send_text(surface_id, message)
            typer.echo(f"已发送到 worker '{target_worker_id}'。")
            raise typer.Exit()
        if command == "kick":
            _require_mission_active(mission_id, mission)
            worker, _ = _parse_worker_target_or_fail(mission, payload, command="kick")
            target_worker_id = worker["session"]
            surface_id, _ = _ensure_worker_online_or_fail(worker=worker, mission_id=mission_id, mission=mission)
            cmux.rpc("surface.send_key", {"surface_id": surface_id, "key": "Enter"})
            typer.echo(f"已触发 worker '{target_worker_id}'。")
            raise typer.Exit()
        typer.echo(f"No such command '{command}'", err=True)
        raise typer.Exit(2)

    typer.echo(f"No such command '{resource}'", err=True)
    raise typer.Exit(2)


# ── self ──────────────────────────────────────────────────────


@mission_app.callback()
def mission_main(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is not None:
        return

    help_args = ctx.meta.get("mission_help_args")
    if not help_args:
        return

    subject = help_args[0]
    if len(help_args) == 2 and help_args[1] in {"--help", "-h"} and subject in MISSION_SCOPED_HELP:
        typer.echo(MISSION_SCOPED_HELP[subject])
        raise typer.Exit()
    if len(help_args) == 3 and help_args[2] in {"--help", "-h"} and subject in CREATE_HELP and help_args[1] == "create":
        typer.echo(CREATE_HELP[subject])
        raise typer.Exit()

    typer.echo(f"No such command '{subject}'", err=True)
    raise typer.Exit(2)


@self_app.command("start")
def self_start(
    foreground: bool = typer.Option(False, "-f", "--foreground", help="前台运行 daemon"),
) -> None:
    global_state = load_global()
    if global_state is None:
        global_state = new_global()
        save_global(global_state)
    if _is_daemon_running(global_state):
        typer.echo("Daemon 已在运行", err=True)
        raise typer.Exit(1)
    _launch_daemon(global_state, foreground)


@self_app.command("stop")
def self_stop() -> None:
    global_state = _require_global()
    daemon_pid = global_state.get("daemon_pid")
    if daemon_pid:
        try:
            os.kill(daemon_pid, signal.SIGTERM)
        except (ProcessLookupError, TypeError):
            pass
    global_state["daemon_pid"] = None
    global_state["stopped"] = True
    save_global(global_state)
    typer.echo("Mation 已停止。")


@self_app.command("show")
def self_show() -> None:
    global_state = load_global()
    if global_state is None:
        typer.echo("Mation 未启动。")
        return

    daemon_running = _is_daemon_running(global_state)
    if global_state.get("stopped"):
        state_label = "已锁定 (stopped)"
    elif daemon_running:
        state_label = "运行中"
    else:
        state_label = "异常 (daemon 未运行)"

    lines = [f"状态: {state_label}"]
    pid = global_state.get("daemon_pid")
    if pid:
        lines.append(f"Daemon PID: {pid}" + (" (运行中)" if daemon_running else " (已退出)"))

    missions = []
    for name in list_missions():
        mission = load_mission(name)
        if mission is None:
            continue
        missions.append((name, mission))

    if not missions:
        lines.append("")
        lines.append("没有 mission。用 mation mission create 创建（ID 自动生成）。")
    else:
        lines.append("")
        for name, mission in missions:
            workers = [worker["session"] for worker in iter_workers(mission)]
            supervisor = find_supervisor(mission)
            tasks = list_tasks(name)
            done = sum(1 for task in tasks if task["status"] == "completed")
            running = sum(1 for task in tasks if task["status"] == "in_progress")
            pending = sum(1 for task in tasks if task["status"] == "pending")
            workers_text = ", ".join(workers) if workers else "无"
            supervisor_text = supervisor["session"] if supervisor else "(unclaimed)"
            lines.append(
                f"  {name} — supervisor: {supervisor_text} | workers: {workers_text} | tasks: {done} done, {running} running, {pending} pending ({len(tasks)} total)"
            )

    typer.echo("\n".join(lines))


@self_app.command("reset")
def self_reset() -> None:
    global_state = _require_global()
    daemon_pid = global_state.get("daemon_pid")
    if daemon_pid:
        try:
            os.kill(daemon_pid, signal.SIGTERM)
        except (ProcessLookupError, TypeError):
            pass
    delete_all()
    typer.echo("Mation 已重置，所有状态已清除。")


# ── mission ───────────────────────────────────────────────────


@mission_app.command("create")
def mission_create() -> None:
    _require_global()
    mission_id = _generate_mission_id()
    try:
        create_mission(mission_id)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    typer.echo(f"Mission '{mission_id}' 已创建。")


@mission_app.command("update")
def mission_update(
    mission_id: str = typer.Argument(...),
    prompt: str = typer.Argument(...),
) -> None:
    _require_global()
    mission = _require_mission_by_name(mission_id)
    mission["mission_prompt"] = prompt
    save_mission(mission_id, mission)
    typer.echo(f"Mission '{mission_id}' 已更新。")


@mission_app.command("remove")
def mission_remove(mission_id: str = typer.Argument(...)) -> None:
    _require_global()
    if not delete_mission(mission_id):
        typer.echo(f"Mission '{mission_id}' 不存在", err=True)
        raise typer.Exit(1)
    typer.echo(f"Mission '{mission_id}' 已删除。")


@mission_app.command("list")
def mission_list() -> None:
    _require_global()
    names = list_missions()
    if not names:
        typer.echo("没有 mission。")
        return
    lines = ["Missions:"]
    for name in names:
        mission = load_mission(name)
        if mission is None:
            continue
        task_count = len(list_tasks(name))
        lines.append(f"  {name} — {len(iter_workers(mission))} workers, {task_count} tasks")
    typer.echo("\n".join(lines))


@mission_app.command("show")
def mission_show(mission_id: str = typer.Argument(...)) -> None:
    _require_global()
    mission = _require_mission_by_name(mission_id)
    lines = [f"Mission '{mission_id}':"]
    lines.append(f"  状态: {mission.get('status', 'active')}")
    lines.append(f"  创建时间: {_format_timestamp(mission.get('created_at'))}")
    prompt = mission.get("mission_prompt")
    lines.append(f"  Prompt: {resolve_content(prompt) if prompt else '(未设置)'}")
    lines.append(f"  Tasks dir: {task_store_dir(mission_id)}")
    typer.echo("\n".join(lines))


@mission_app.command("start")
def mission_start(mission_id: str = typer.Argument(...)) -> None:
    _require_global()
    mission = _require_mission_by_name(mission_id)
    mission["status"] = "active"
    save_mission(mission_id, mission)
    typer.echo(f"Mission '{mission_id}' 已启动。\n")

    issues: list[str] = []

    supervisor = find_supervisor(mission)
    if supervisor:
        sup_label = supervisor.get("name") or supervisor.get("session", "?")
        typer.secho(f"  ✓ Supervisor: {sup_label}", fg=typer.colors.GREEN)
    else:
        typer.secho("  ✗ Supervisor: 未注册", fg=typer.colors.RED)
        issues.append(
            f"Supervisor 未注册——daemon 不会路由 stop/stall 事件，mission 无法自动推进\n"
            f"     如果您是 Supervisor，请运行：mation {mission_id} supervisor create --name <session>"
        )

    workers = iter_workers(mission)
    if workers:
        labels = ", ".join(w.get("name") or w.get("session", "?") for w in workers)
        typer.secho(f"  ✓ Workers ({len(workers)}): {labels}", fg=typer.colors.GREEN)
    else:
        typer.secho("  ✗ Workers: 无", fg=typer.colors.YELLOW)
        issues.append("无 Worker——无法执行任务")

    tasks = list_tasks(mission_id)
    pending = [t for t in tasks if t.get("status") != "done"]
    if tasks:
        typer.secho(f"  ✓ Tasks: {len(pending)} pending / {len(tasks)} total", fg=typer.colors.GREEN)
    else:
        typer.secho("  ✗ Tasks: 无", fg=typer.colors.YELLOW)
        issues.append("Task 队列为空——Supervisor 收到 start 后无任务可推进")

    if issues:
        typer.echo("")
        for issue in issues:
            typer.secho(f"  ⚠  {issue}", fg=typer.colors.YELLOW)


@mission_app.command("stop")
def mission_stop(mission_id: str = typer.Argument(...)) -> None:
    _require_global()
    mission = _require_mission_by_name(mission_id)
    mission["status"] = "stopped"
    save_mission(mission_id, mission)
    typer.echo(f"Mission '{mission_id}' 已停止。")


if __name__ == "__main__":
    app()
