"""Worker 解析：从 session name 查找运行时信息（PID、workspace、surface、JSONL 路径）。

查找链路：
  session name → ps 找 "claude.*<session>" → PID
  PID → ps eww 读环境变量 → CMUX_WORKSPACE_ID, CMUX_SURFACE_ID
  session name → JSONL 目录匹配文件名
"""

from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass
class WorkerInfo:
    session: str
    pid: int | None = None
    workspace_id: str | None = None  # cmux UUID
    surface_id: str | None = None  # cmux UUID
    jsonl_path: Path | None = None
    jsonl_search: JsonlSearchResult | None = None
    running: bool = False


def _find_claude_pid(session: str) -> int | None:
    """从 ps 找到 claude --resume <session> 的实际二进制 PID（跳过 bash wrapper）。"""
    try:
        result = subprocess.run(
            ["ps", "-eo", "pid,args"],
            capture_output=True, text=True, timeout=5,
        )
    except Exception:
        return None

    candidates: list[tuple[int, str]] = []
    for line in result.stdout.strip().split("\n"):
        line = line.strip()
        if "claude" not in line:
            continue
        # 匹配 --resume <session> / --name <session> / --session-id <session>
        matched = False
        for flag in ("--resume", "--name", "--session-id"):
            if f"{flag} {session}" in line or f'{flag} "{session}"' in line:
                matched = True
                break
        if not matched:
            continue
        parts = line.split()
        try:
            pid = int(parts[0])
            args = " ".join(parts[1:])
            candidates.append((pid, args))
        except (ValueError, IndexError):
            pass

    if not candidates:
        return None

    # 优先选非 bash wrapper 的进程（实际二进制）
    for pid, args in candidates:
        if "bash" not in args:
            return pid

    # fallback：返回第一个
    return candidates[0][0]


def _read_env_from_pid(pid: int, var: str) -> str | None:
    """从进程环境变量读取指定变量（macOS ps eww）。"""
    try:
        result = subprocess.run(
            ["ps", "eww", "-p", str(pid)],
            capture_output=True, text=True, timeout=5,
        )
    except Exception:
        return None

    for token in result.stdout.replace("\n", " ").split(" "):
        if token.startswith(f"{var}="):
            return token.split("=", 1)[1]
    return None


@dataclass
class JsonlSearchResult:
    path: Path | None = None
    dirs_searched: int = 0
    dirs_missing: int = 0
    files_scanned: int = 0
    titles_found: list[str] | None = None  # populated on miss for diagnostics


def _find_jsonl(session: str) -> JsonlSearchResult:
    """在当前 Claude 配置目录及常见回退目录下找 session 对应的 JSONL 文件。

    session 可以是 UUID（直接匹配文件名）或 display name（从 customTitle 匹配）。
    """
    search_dirs: list[Path] = []

    config_dir = Path.home() / ".claude"
    env_config = subprocess.os.environ.get("CLAUDE_CONFIG_DIR")
    if env_config:
        search_dirs.append(Path(env_config) / "projects")
        config_dir = Path(env_config)

    search_dirs.extend([
        config_dir / "projects",
        Path.home() / ".claude" / "projects",
    ])

    # 去重，保留顺序
    deduped_dirs: list[Path] = []
    seen: set[Path] = set()
    for directory in search_dirs:
        if directory in seen:
            continue
        seen.add(directory)
        deduped_dirs.append(directory)

    search_dirs = deduped_dirs

    result = JsonlSearchResult()
    titles: list[str] = []

    for search_dir in search_dirs:
        if not search_dir.exists():
            result.dirs_missing += 1
            continue
        result.dirs_searched += 1

        # 1. 直接匹配 UUID 文件名
        for jsonl_path in search_dir.rglob(f"{session}.jsonl"):
            result.path = jsonl_path
            return result

        # 2. 按 customTitle 匹配（session name 不是 UUID 的情况）
        #    custom-title 条目可能不在第一行，扫描前 20 行
        for jsonl_path in search_dir.rglob("*.jsonl"):
            result.files_scanned += 1
            try:
                with open(jsonl_path) as f:
                    for _, line in zip(range(20), f):
                        entry = json.loads(line)
                        if entry.get("type") == "custom-title":
                            title = entry.get("customTitle", "")
                            titles.append(title)
                            if title == session:
                                result.path = jsonl_path
                                return result
                            break  # found custom-title, no match, move to next file
            except (json.JSONDecodeError, OSError):
                continue

    result.titles_found = titles
    return result


def resolve_worker(session: str) -> WorkerInfo:
    """解析 CC session 的运行时信息：ps 反查 `claude --resume`/`--name` 进程，读 env 拿 surface_id。"""
    info = WorkerInfo(session=session)

    # 1. 找 PID
    pid = _find_claude_pid(session)
    if pid is None:
        info.running = False
        # 仍然尝试找 JSONL（进程可能已退出但文件还在）
        search = _find_jsonl(session)
        info.jsonl_path = search.path
        info.jsonl_search = search
        return info

    info.pid = pid
    info.running = True

    # 2. 从 PID 读 cmux 信息
    info.workspace_id = _read_env_from_pid(pid, "CMUX_WORKSPACE_ID")
    info.surface_id = _read_env_from_pid(pid, "CMUX_SURFACE_ID")

    # 3. 找 JSONL
    search = _find_jsonl(session)
    info.jsonl_path = search.path
    info.jsonl_search = search

    return info




def worker_cache_from_info(info: "WorkerInfo") -> dict:
    """从 WorkerInfo 构造 participant.cache dict（跳过 None 字段避免 JSON 噪声）。"""
    cache: dict = {}
    if info.pid is not None:
        cache["pid"] = info.pid
    if info.surface_id is not None:
        cache["surface_id"] = info.surface_id
    if info.jsonl_path is not None:
        cache["jsonl_path"] = str(info.jsonl_path)
    return cache



def _read_tail(path: Path, max_bytes: int = 256 * 1024) -> list[str]:
    """从文件尾部读取最多 max_bytes 字节，返回完整行列表。"""
    size = path.stat().st_size
    with open(path, "rb") as f:
        if size > max_bytes:
            f.seek(size - max_bytes)
            f.readline()  # 跳过截断的首行
        return f.read().decode("utf-8", errors="replace").strip().split("\n")


def read_last_message(jsonl_path: Path) -> dict:
    """从 JSONL 读取 Worker 最后一条 assistant 消息（完整内容）。"""
    if not jsonl_path.exists():
        return {"ok": False, "error": "JSONL 不存在"}

    try:
        lines = _read_tail(jsonl_path)
    except Exception:
        return {"ok": False, "error": "无法读取 JSONL"}

    for line in reversed(lines):
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        if entry.get("type") != "assistant":
            continue

        content = entry.get("message", {}).get("content", "")
        if isinstance(content, list):
            text = "\n".join(
                c["text"] for c in content
                if c.get("type") == "text"
            )
        else:
            text = str(content)

        return {
            "ok": True,
            "timestamp": entry.get("timestamp", ""),
            "message": text,
        }

    return {"ok": False, "error": "没有 assistant 消息"}
