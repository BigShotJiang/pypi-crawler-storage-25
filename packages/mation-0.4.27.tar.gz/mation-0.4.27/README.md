# mation

> **mation** = auto**mation** minus the auto. You stay in control.

CC Worker orchestration CLI — manage multiple missions with multiple workers via [cmux](https://cmux.com).

## The Three-Party System

`mation` implements a relay system between three parties: **Human**, **Supervisor CC**, and **Worker CC**. At least one of them is always active — the system never stalls.

```
Worker stops → Daemon relays → Supervisor wakes up, evaluates, instructs Worker
                                        → Worker works → stops → Daemon relays → ...

All plans done → Supervisor notifies Human → Human decides: more plans or done
```

- **Worker CC** does the actual coding work. It doesn't know it's being managed.
- **Supervisor CC** is the Human's agent. It evaluates Worker output, runs verification (by telling Worker to review/test), and drives plans forward.
- **Human** sets the mission direction and makes final decisions. Only gets notified when Supervisor needs input.
- **Daemon** is the relay — when any Worker in any mission stops, it instantly notifies the Supervisor CC. Pure event bridge, no decisions.

> **Supervisor and Worker are homogeneous** — both are Claude Code sessions. Their difference is role, not kind. A bash shell or non-CC terminal cannot serve as either: delivering notification text to a surface is not the same as acting on it. Only a CC session can parse `<mation event>` tags, run mission-scoped supervisor/task commands, and carry out the supervision loop.

## Requirements

- [cmux](https://cmux.com) with socket mode set to **Automation** (Settings → Socket Control Mode)
- Python 3.12+
- [uv](https://github.com/astral-sh/uv)
- CC Stop hook configured (see [Setup](#setup))

## Install

```bash
uv tool install mation
```

## Setup

Configure CC's Stop hook globally so `mation` knows when a Worker finishes a turn:

```json
// ~/.claude/settings.json (or your cac env settings)
{
  "hooks": {
    "Stop": [
      {
        "hooks": [{ "type": "command", "command": "bash ~/.mation/on-stop.sh" }]
      }
    ]
  }
}
```

Create the hook script:

```bash
mkdir -p ~/.mation

cat > ~/.mation/on-stop.sh << 'EOF'
#!/bin/bash
INPUT=$(cat)
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id')
echo "$INPUT" > ~/.mation/stop-${SESSION_ID}
EOF

chmod +x ~/.mation/on-stop.sh
```

## Quick Start

```bash
# Start daemon
mation self start

# Create mission — ID is auto-generated and printed, e.g. 'a3f2c1d9'
# New missions start in stopped state; configure first, then start
mation mission create
# → Mission 'a3f2c1d9' 已创建。

# Set mission prompt (inline text or file path)
mation mission update a3f2c1d9 "Implement chat receipts"
mation mission update a3f2c1d9 ~/path/to/mission.md

# Create tasks and supervisor (allowed while stopped)
mation a3f2c1d9 task create "Backend read API"
mation a3f2c1d9 supervisor create --name my-supervisor

# Activate mission — required before worker create / send / kick
mation mission start a3f2c1d9

# Spawn worker
mation a3f2c1d9 worker create --name my-worker

# Single-worker mission: worker_id can be omitted for send/read/kick
mation a3f2c1d9 supervisor send "开始实现 Backend read API"
mation a3f2c1d9 supervisor read
mation a3f2c1d9 supervisor kick

# Check system and mission state
mation self show
mation mission show a3f2c1d9

# Stop / reset
mation self stop
mation self reset
```

## Multi-Mission

```bash
mation mission create   # → Mission 'aa11bb22' 已创建。
mation mission create   # → Mission 'cc33dd44' 已创建。

mation aa11bb22 worker create --name worker-a
mation aa11bb22 supervisor create --name sup-a
mation aa11bb22 task create "Step 1"

mation cc33dd44 worker create --name worker-b
mation cc33dd44 supervisor create --name sup-b
mation cc33dd44 task create "Step 1"

mation mission list
```

## Multi-Worker

A mission can have multiple workers. In that case, `supervisor send/read/kick` must explicitly pass `worker_id`.

```bash
# assuming mission id is 'a3f2c1d9'
mation a3f2c1d9 worker create --name worker-frontend
mation a3f2c1d9 worker create --name worker-backend

mation a3f2c1d9 supervisor send worker-frontend "implement the UI"
mation a3f2c1d9 supervisor send worker-backend "add the API endpoint"
mation a3f2c1d9 supervisor read worker-frontend
mation a3f2c1d9 supervisor kick worker-backend
```

## Content Resolution

`mission update <mission_id> <prompt>` accepts file paths or inline text:

| Input | Detection | Behavior |
|-------|-----------|----------|
| `~/path/to/file.md` | File exists on disk | Read file content at display/use time |
| `"Implement feature X"` | Not a file path | Use text as-is |

## CLI Reference

### Self
| Command | Description |
|---------|-------------|
| `mation self start [-f]` | Start daemon (`-f`: foreground) |
| `mation self stop` | Stop daemon and lock state |
| `mation self show` | Show system status and mission summary |
| `mation self reset` | Stop daemon and clear all state |

### Mission
| Command | Description |
|---------|-------------|
| `mation mission create` | Create a mission (ID auto-generated, printed on creation) |
| `mation mission update <mission_id> <prompt>` | Update mission prompt |
| `mation mission remove <mission_id>` | Delete a mission |
| `mation mission list` | List missions |
| `mation mission show <mission_id>` | Show mission details |
| `mation mission start <mission_id>` | Mark mission active (prints supervisor/worker/task readiness check) |
| `mation mission stop <mission_id>` | Mark mission stopped |

### Mission-scoped Task
| Command | Description |
|---------|-------------|
| `mation <mission_id> task create <subject>` | Create task |
| `mation <mission_id> task update <task_id> [--status/--owner/--description/--blocks/--blocked-by]` | Update task |
| `mation <mission_id> task remove <task_id>` | Remove task |
| `mation <mission_id> task list` | List tasks |
| `mation <mission_id> task show <task_id>` | Show task |

### Mission-scoped Worker
| Command | Description |
|---------|-------------|
| `mation <mission_id> worker create [--name <name>] [--path <path>]` | Spawn new worker CC session, inject contract, wait for ready reply |
| `mation <mission_id> worker create --session <session_id>` | Re-attach an existing CC session as worker (skips spawn) |
| `mation <mission_id> worker update <worker_id> [--name <name>] [--path <path>]` | Update worker metadata |
| `mation <mission_id> worker remove <worker_id>` | Remove worker |
| `mation <mission_id> worker list` | List workers |
| `mation <mission_id> worker show <worker_id>` | Show worker details |

### Mission-scoped Supervisor
| Command | Description |
|---------|-------------|
| `mation <mission_id> supervisor create [--name <name>] [--path <path>]` | Create/replace supervisor CC session + contract and wait for ready reply |
| `mation <mission_id> supervisor update <supervisor_id> [--name <name>] [--path <path>]` | Update supervisor metadata |
| `mation <mission_id> supervisor remove <supervisor_id>` | Remove supervisor |
| `mation <mission_id> supervisor list` | Show current supervisor |
| `mation <mission_id> supervisor show <supervisor_id>` | Show supervisor details |
| `mation <mission_id> supervisor send [worker_id] <message>` | Send message to worker |
| `mation <mission_id> supervisor read [worker_id]` | Read worker latest message |
| `mation <mission_id> supervisor kick [worker_id]` | Send Enter key to worker |

## How It Works

1. **Worker creation**: `mation <mission_id> worker create` generates a UUID session id, starts Claude with a bootstrap prompt plus `--session-id` and `--append-system-prompt`, waits until the CC process is visible and the session emits its ready reply, then records runtime cache and contract metadata. Use `--session <id>` to re-attach an existing CC session without spawning a new one.
2. **Idle detection**: CC Stop hook writes a signal file when Worker finishes responding. Daemon polls for this file every 2s.
3. **Stop relay**: Daemon consumes the stop signal, saves the Worker's reply to `~/.mation/missions/<name>/worker-output/` if it exceeds 200 characters, then injects a `<mation event="stop" mission="..." worker="..." output_file="...">` notification into the Supervisor session. The `output_file` path can be forwarded directly to downstream workers — no transcription needed.
4. **Stall detection**: Worker idle >3min triggers a stall notification with progressive backoff (180s → 240s → 300s). Multiple workers stalling simultaneously produce a single aggregated `[stall ×N]` message instead of N separate messages.
5. **Stall hint**: At `stall_count=2`, the notification body includes a hint suggesting the Supervisor can remove the worker and re-attach it later via `worker create --session`. At the cap (`stall_max=10`), automatic reminders stop.
6. **Runtime state persistence**: Stall counts, notification timestamps, and closed-worker state survive daemon restarts (`~/.mation/daemon-runtime.json`). Worker bootstrap state is persisted per-worker so the first real task stop is never mistakenly suppressed after a restart.
7. **Send is fire-and-forget**: `mation <mission_id> supervisor send ...` delivers text via cmux RPC. Success = text reached the terminal; CC queues it if Worker is busy.
8. **Supervisor creation**: each mission stores one supervisor participant via `mation <mission_id> supervisor create`. Daemon resolves `session → PID → CMUX_SURFACE_ID` dynamically on each notification.
9. **Dormant until supervisor exists**: a mission without a supervisor participant is skipped by daemon event routing.
10. **Active mission required**: `supervisor send`, `supervisor kick`, and `worker create` (both spawn and `--session`) are blocked when the mission is `stopped`. Run `mation mission start <id>` first.
11. **Multi-mission routing**: daemon iterates active missions and routes events per mission-local supervisor relationship.
12. **Cache refresh**: Worker cache (PID, surface_id, JSONL path) auto-refreshes on `supervisor send/read/kick`.

## State Files

```
~/.mation/
  global.json                          # daemon_pid, stopped
  daemon-runtime.json                  # persisted stall counts, notify timestamps, closed set
  daemon.log                           # daemon log
  stop-<session_id>                    # signal file (CC Stop hook writes, daemon consumes)
  on-stop.sh                           # CC Stop hook script
  missions/<name>.json                 # per-mission: participants, relationships, mission_prompt
  missions/<name>/transcript.jsonl     # worker→supervisor reply transcript
  missions/<name>/worker-output/       # worker stop output files (written when reply > 200 chars)
```

Participant roles: `worker` (managed CC), `supervisor` (human proxy). Mission has 0 or 1 supervisor; claim replaces.

## License

MIT
