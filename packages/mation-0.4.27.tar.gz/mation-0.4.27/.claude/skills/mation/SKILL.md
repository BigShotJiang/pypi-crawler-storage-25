---
name: mation
description: mation 命令模型与标准用法。
allowed-tools: Bash(mation:*)
---

## 当前状态

!`mation self show 2>&1`

## 命令路径模型

```bash
mation self ...
mation mission ...
mation <mission_id> task ...
mation <mission_id> supervisor ...
mation <mission_id> worker ...
```

含义：

- 先通过 `mission` 管理任务本身
- 进入 mission 后，在该 mission 下管理 task/supervisor/worker
- mission 作用域体现在路径中，不需要额外 `-m <mission>`

## 标准命令清单

### self

```bash
mation self show
mation self start
mation self stop
mation self reset
```

### mission

```bash
mation mission create              # ID 自动生成，创建后打印
mation mission update <mission_id> <prompt>
mation mission remove <mission_id>
mation mission list
mation mission show <mission_id>
mation mission start <mission_id>
mation mission stop <mission_id>
```

### task

```bash
mation <mission_id> task create <subject>
mation <mission_id> task update <task_id>
mation <mission_id> task remove <task_id>
mation <mission_id> task list
mation <mission_id> task show <task_id>
```

### supervisor

```bash
mation <mission_id> supervisor create [--name <name>] [--path <path>]
mation <mission_id> supervisor update <supervisor_id> [--name <name>] [--path <path>]
mation <mission_id> supervisor remove <supervisor_id>
mation <mission_id> supervisor list
mation <mission_id> supervisor show <supervisor_id>
mation <mission_id> supervisor send [worker_id] "..."
mation <mission_id> supervisor read [worker_id]
mation <mission_id> supervisor kick [worker_id]
```

### worker

```bash
mation <mission_id> worker create [--name <name>] [--path <path>]
mation <mission_id> worker create --session <session_id>  # 仅用于绑定已有 CC session，跳过 spawn
mation <mission_id> worker update <worker_id> [--name <name>] [--path <path>]
mation <mission_id> worker remove <worker_id>
mation <mission_id> worker list
mation <mission_id> worker show <worker_id>
```

## 常见误用（必须指出）

1. 把 `supervisor` / `worker` 当全局主体用（错误）
2. 在 mission 路径命令里再加 `-m`（错误）
3. `show` 不带必需 id（如 `supervisor show` 缺 `supervisor_id`）
4. 把 `send/read/kick` 当作 Human->Supervisor 通道（错误；Human 应直接在 Supervisor surface 打字）
5. 新建 mission 后直接 `worker create` / `supervisor send`（错误）——新 mission 默认 stopped，必须先 `mission start` 才能执行操作类命令

## Supervisor 执行流程

0. **Supervisor 初始化**：确认 session_id 和 mission，回复 OK，等待 Human 指令
1. **Mission 对齐**：读 mission prompt，与 Human 对齐
2. **Task 自主拆分**：将 mission 拆成可执行 task，用 `task create` 建队列
3. **Worker 自主创建管理**：用 `worker create` spawn worker，分派 task，审视产出，循环推进

## 回答风格

- 优先给可直接执行的命令
- 先纠正路径，再解释原因
- 保持简洁，不扩写无关背景
