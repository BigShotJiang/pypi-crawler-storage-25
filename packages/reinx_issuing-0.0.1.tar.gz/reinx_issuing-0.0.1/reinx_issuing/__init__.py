"""Reinx Issuing Python SDK. Placeholder release."""

__version__ = "0.0.1"


def __getattr__(name):
    raise NotImplementedError(
        "reinx-issuing is currently a placeholder package. "
        "The full SDK will be available at launch. "
        "Visit https://reinx.ai for updates."
    )
