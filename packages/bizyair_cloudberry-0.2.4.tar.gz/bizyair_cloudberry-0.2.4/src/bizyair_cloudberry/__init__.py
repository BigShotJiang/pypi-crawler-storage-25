__version__ = "0.2.4"
from .env import env_vars
from .scx_executor import SCXAPIExecutor


def is_comfyui_runtime():
    try:
        import comfy
        import nodes
        from server import PromptServer  # comfyui.server

        return True
    except ImportError:
        pass
    return False


if is_comfyui_runtime():
    from .cloudberry_node import CloudBerrySubgraphNode
    from .hijack import setup_prompt_hijack
    from .routes import init_routes

    NODE_CLASS_MAPPINGS = {"CloudBerrySubgraphNode": CloudBerrySubgraphNode}
    NODE_DISPLAY_NAME_MAPPINGS = {"CloudBerrySubgraphNode": "CloudBerry SubgraphNode"}
    setup_prompt_hijack()
    
    init_routes()  # Initialize API routes for model selection
    print("☁️🍓 BizyAirPlus: Plugin loaded successfully")
else:
    NODE_DISPLAY_NAME_MAPPINGS = {}
    NODE_CLASS_MAPPINGS = {}

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS"]
