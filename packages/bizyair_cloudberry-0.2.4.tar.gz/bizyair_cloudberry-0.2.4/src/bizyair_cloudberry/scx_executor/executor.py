import asyncio
import logging
import traceback
import uuid
from typing import AsyncGenerator, Optional

from ..client.scx_client import SCXBaseClient
from ..env import env_vars
from ..process_transform import build_process_transform
from .gateway_manager import ScxGatewayManager, ScxTaskSignal
from .task_monitor import TaskMonitor

logger = logging.getLogger(__name__)


class SCXAPIExecutor:
    def __init__(self):
        api_key = env_vars.get_api_key()
        if not api_key:
            raise ValueError(
                "BizyAir API Key 未配置。请通过环境变量 BIZYAIR_API_KEY 设置，"
                "或在 ComfyUI 中开启 CloudBerry 模式时输入 API Key。"
            )
        self.client = SCXBaseClient(
            base_endpoint=env_vars.scx_api_url, api_key=api_key
        )
        self.gateway = ScxGatewayManager(self.client)

    async def _generate_id(self) -> str:
        return uuid.uuid4().hex

    async def execute_workflow(
        self, prompt_dict, *, backend_id: int = 0, result_queue: asyncio.Queue
    ):
        client_id = await self._generate_id()

        task_id: Optional[str] = None
        try:
            task_signal: ScxTaskSignal = await self.gateway.subscribe_task(client_id)
            process_transform = build_process_transform(prompt_dict)
            logger.debug(f"Process transform: {process_transform}")
            logger.debug(f"Submitting task for client: {client_id}")
            submission = await self.client.create_task(
                client_id=client_id,
                prompt_content=prompt_dict,
                process_transform=process_transform,
                backend_id=backend_id,
                suppress_preview=True,
            )
            task_id = submission.get("data", {}).get("task_id")
            logger.debug(f"Task submitted successfully. Task ID: {task_id}")

            task_ws_url = await task_signal.resolve_url()
            if task_ws_url:
                task_monitor = TaskMonitor(self.client)
                await task_monitor.listen(task_ws_url, result_queue)

        except asyncio.CancelledError:
            logger.warning(
                f"Task execution cancelled. Client: {client_id}, Task: {task_id}"
            )
            result_queue.put_nowait({"type": "cancelled"})
            if task_id:
                # Concurrent clean-up on the cloud side
                await asyncio.gather(
                    self.client.interrupt_task(task_id),
                    self.client.cancel_task(task_id),
                    return_exceptions=True,
                )
            raise
        finally:
            logger.debug(traceback.format_exc())
            self.gateway.unsubscribe(client_id)

    async def stream(
        self, prompt_dict, *, backend_id: int = 0
    ) -> AsyncGenerator[dict, None]:
        result_queue = asyncio.Queue()
        # Run the existing workflow in a background task
        worker_task = asyncio.create_task(
            self.execute_workflow(
                prompt_dict=prompt_dict,
                backend_id=backend_id,
                result_queue=result_queue,
            )
        )

        try:
            while True:
                get_task = asyncio.create_task(result_queue.get())

                # Wait for either new queue data or worker completion
                done, _ = await asyncio.wait(
                    [get_task, worker_task],
                    return_when=asyncio.FIRST_COMPLETED,
                )

                if get_task in done:
                    # Yield data successfully fetched from the queue
                    item = get_task.result()
                    yield item
                else:
                    # Worker finished; cancel the pending queue fetch
                    get_task.cancel()

                    # Drain any remaining items in the queue
                    while not result_queue.empty():
                        yield result_queue.get_nowait()

                    # Propagate exceptions if the worker failed
                    if worker_task.exception():
                        raise worker_task.exception()

                    break

        except asyncio.CancelledError:
            # Pass external cancellation (e.g., client disconnect) to the worker
            worker_task.cancel()
            raise
        finally:
            # Fallback cleanup to prevent zombie tasks
            if not worker_task.done():
                worker_task.cancel()
