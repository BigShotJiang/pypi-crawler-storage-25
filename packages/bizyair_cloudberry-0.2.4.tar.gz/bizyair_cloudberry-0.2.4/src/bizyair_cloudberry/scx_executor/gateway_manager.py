import asyncio
import json
import logging as logger
from typing import Dict, Optional

import websockets

from ..client.scx_client import SCXBaseClient
from .io_types import TaskStatus


class ScxTaskSignal:
    """
    [职责：协议解析器]
    负责将网关(Draft WS)的原始消息流，解析为业务可理解的信号。
    """

    def __init__(self, message_queue: asyncio.Queue):
        self._queue = message_queue

    async def resolve_url(self) -> str:
        """
        等待直到获取 Task WS URL。
        """
        task_ws_url = None
        while True:
            data = await self._queue.get()
            logger.debug(f"DEBUG: GateWay: {data=}")

            # 状态判定逻辑收拢在此
            status = data.get("status")
            if data.get("event") not in (
                TaskStatus.TASK_STATUS_CHANGED,
                TaskStatus.QUEUED_CHANGED,
            ):
                continue

            if status == TaskStatus.PREPARING:
                task_ws_url = data.get("wsUrl")
                return task_ws_url
            if status == TaskStatus.SUCCESS:
                break
            if status == TaskStatus.FAILED:
                raise RuntimeError(
                    f"Cloud Task Failed: {data.get('message', 'Unknown Error')}"
                )
        return task_ws_url


class ScxGatewayManager:
    """Draft WS long-lived connection manager with queue-based subscription"""

    def __init__(self, scx_client: SCXBaseClient) -> None:
        self._client = scx_client
        self._subscribers: Dict[str, asyncio.Queue] = {}
        self._listener_task: Optional[asyncio.Task] = None

    async def subscribe_task(
        self, client_id: str, timeout: float = 60
    ) -> ScxTaskSignal:
        msg_q = await self.subscribe(client_id, timeout)
        return ScxTaskSignal(msg_q)

    async def subscribe(self, client_id: str, timeout: float = 60.0) -> asyncio.Queue:
        """Subscribe to draft events, returns an async queue"""
        if self._client is None:
            raise RuntimeError("SCX Client is not initialized.")

        if self._listener_task is None or self._listener_task.done():
            ready_event = asyncio.Event()
            self._listener_task = asyncio.create_task(
                self._connection_loop(ready_event)
            )
            try:
                await asyncio.wait_for(ready_event.wait(), timeout=timeout)
            except asyncio.TimeoutError:
                if self._listener_task and not self._listener_task.done():
                    self._listener_task.cancel()
                raise RuntimeError("Gateway connection timed out.")

        # 3. Only create a dedicated queue for the client after connection is confirmed
        if client_id not in self._subscribers:
            self._subscribers[client_id] = asyncio.Queue()

        return self._subscribers[client_id]

    async def _connection_loop(self, ws_connected_event: asyncio.Event):
        client = self._client
        user_id = await client.get_user_id()
        draft_url = client.build_draft_ws_url(user_id)
        logger.debug(f"Connecting to Gateway: {draft_url}")
        async with client.connect_ws(draft_url) as ws:
            logger.debug("WS Connected successfully.")
            # Key step: Once connected, set Event to True (green light) to allow waiting subscribers to proceed
            ws_connected_event.set()
            async for message in ws:
                try:
                    await self._dispatch_message(message)
                except websockets.exceptions.ConnectionClosed:
                    print("WARNING: Gateway WS reconnect automatically", flush=True)

    async def _dispatch_message(self, message: str):
        if not (isinstance(message, str) and message.startswith("{")):
            return

        try:
            data = json.loads(message)
            client_id = data.get("clientId")
            if client_id and client_id in self._subscribers:
                await self._subscribers[client_id].put(data)
        except json.JSONDecodeError:
            logger.warning(f"Failed to decode message: {message}")

    def unsubscribe(self, client_id: str):
        self._subscribers.pop(client_id, None)
