/**
 * CloudBerry 模型选择核心模块
 * 提供模型选择相关的工具函数
 */

import {
  fetchNodeConfigWithCache,
  nodeConfigCache,
} from "./configLoader.js";


// ==================== Widget名称列表 ====================

export const possibleWidgetNames = [
  "clip_name",
  "clip_name1",
  "clip_name2",
  "clip_name3",
  "clip_name4",
  "ckpt_name",
  "lora_name",
  "name",
  "lora",
  "lora_01",
  "lora_02",
  "lora_03",
  "lora_04",
  "lora_1_name",
  "lora_2_name",
  "lora_3_name",
  "lora_4_name",
  "lora_5_name",
  "lora_6_name",
  "lora_7_name",
  "lora_8_name",
  "lora_9_name",
  "lora_10_name",
  "lora_11_name",
  "lora_12_name",
  "model_name",
  "control_net_name",
  "ipadapter_file",
  "unet_name",
  "vae_name",
  "model",
  "model_name",
  "instantid_file",
  "pulid_file",
  "style_model_name",
  "yolo_model",
  "face_model",
  "bbox_model_name",
  "sam_model_name",
  "model_path",
  "upscale_model",
  "supir_model",
  "sdxl_model",
  "upscale_model_1",
  "upscale_model_2",
  "upscale_model_3",
  "sam_model",
  "sam2_model",
  "grounding_dino_model",
];

// ==================== 工具函数 ====================

/**
 * 隐藏指定的 widget
 * @param {Object} node - 节点对象
 * @param {string} widget_name - widget名称
 */
export const hideWidget = (node, widget_name) => {
  const widget = node.widgets?.find((w) => w.name === widget_name);
  if (!widget) {
    return;
  }
  const originalComputeSize = widget.computeSize;
  const originalType = widget.type;

  widget.computeSize = () => [0, -4];
  widget.type = "hidden";
  widget.hidden = true;
  widget.options = widget.options || {};
  widget.show = () => {
    widget.computeSize = originalComputeSize;
    widget.type = originalType;
    clearWidgetHeight(widget);
  };
};

// ==================== 配置相关 ====================

// 重新导出 configLoader 的内容
export { fetchNodeConfigWithCache, nodeConfigCache } from "./configLoader.js";

/**
 * 从 inputConfig 获取 mode_type
 * @param {Object} inputConfig - 输入配置
 * @returns {string|undefined}
 */
export function getModelTypeFromInput(inputConfig) {
  if (!inputConfig) return undefined;
  return inputConfig.mode_type;
}

/**
 * 根据节点名称获取节点配置信息（名单优先，正则补充；不阻塞返回）
 * @param {string} nodeName - 节点名称
 * @returns {Promise<Object|null>}
 */
export async function getNodeConfig(nodeName) {
  const excluded =
    /bizyair/i.test(nodeName) &&
    ![
      "BizyAir_LoraLoader",
      "BizyAir_NunchakuFluxLoraLoader",
      "BizyAir_Wan_LoraLoader",
      "BizyAir_ControlNetLoader",
      "BizyAir_CheckpointLoaderSimple",
    ].includes(nodeName);
  if (excluded) {
    return null;
  }

  // 1) 名单（API）优先（仅用缓存，不等待网络）
  if (nodeConfigCache && nodeConfigCache[nodeName]) {
    return { nodeName, config: nodeConfigCache[nodeName] };
  }

  // 若尚未发起请求，后台发起一次（统一触发加载逻辑）
  try {
    void fetchNodeConfigWithCache();
  } catch (e) {}

  // 2) 节点名包含哪个 type 的 name 就用该 type 的 value 作为 mode_type
  const modelTypesByApi = [
    "Controlnet",
    "Checkpoint",
    "LoRA",
    "VAE",
    "UNet",
    "CLIP",
    "Upscaler",
    "Detection",
    "Other",
  ];
  const nameLower = nodeName.toLowerCase();
  let matched = modelTypesByApi.find((t) =>
    nameLower.includes(t.toLowerCase())
  );
  if (!matched && nameLower.includes("upscale")) {
    matched = "Upscaler";
  }
  if (matched && nodeName.match(/^(\w+).*Loader.*/i)) {
    return {
      nodeName,
      config: {
        inputs: { [nodeName]: { mode_type: matched, required: true } },
      },
    };
  }
  return null;
}

// ==================== 徽章系统 ====================

const CLOUDBERRY_MODEL_BADGE_TEXT = "☁️请从BizyAir选择模型";

/**
 * 添加红色提示徽章到节点（引导从 BizyAir 选择模型）
 * @param {Object} node - 节点对象
 */
export function addBadge(node) {
  const customBadge = new LGraphBadge({
    text: CLOUDBERRY_MODEL_BADGE_TEXT,
    fgColor: "white",
    bgColor: "#FF6B6B",
    fontSize: 12,
    padding: 8,
    height: 20,
    cornerRadius: 10,
  });
  if (!Array.isArray(node.badges)) {
    node.badges = [];
  }
  if (node.hasTips) {
    return;
  }
  node.badges.push(() => customBadge);
  node.hasTips = true;
}

/**
 * 移除节点上的 BizyAir 模型选择提示徽章
 * @param {Object} node - 节点对象
 */
export function removeBadge(node) {
  if (node.badges && Array.isArray(node.badges)) {
    node.badges = node.badges.filter((badgeFn) => {
      try {
        const badge = typeof badgeFn === "function" ? badgeFn() : badgeFn;
        return badge.text !== CLOUDBERRY_MODEL_BADGE_TEXT;
      } catch (e) {
        return true;
      }
    });
    if (node.hasTips) {
      delete node.hasTips;
    }
  }
}

/**
 * 检查并添加徽章
 * @param {Object} node - 节点对象
 * @param {Array} targetWidgets - 目标widgets数组
 */
export function checkAndAddBadge(node, targetWidgets) {
  for (const { widget, inputConfig } of targetWidgets) {
    if (inputConfig.required) {
      const shouldShowBadge =
        widget.value !== undefined &&
        widget.value !== null &&
        widget.value !== "NONE";
      const idx = targetWidgets.findIndex((tw) => tw.widget === widget);
      const fieldName =
        idx === 0 ? "model_version_id" : `model_version_id${idx + 1}`;
      const mv = node.widgets?.find((w) => w.name === fieldName);
      const hasInvalidVersionId = !mv?.value || isNaN(Number(mv.value));

      if (shouldShowBadge && hasInvalidVersionId) {
        addBadge(node);
        return;
      }
    }
  }
}

// ==================== 回调设置 ====================

function hasOwn(obj, key) {
  return Object.prototype.hasOwnProperty.call(obj, key);
}

function cloneValue(value) {
  if (value === null || value === undefined || typeof value !== "object") {
    return value;
  }
  return JSON.parse(JSON.stringify(value));
}

function valuesEqual(left, right) {
  if (left === right) {
    return true;
  }

  if (
    left === null ||
    left === undefined ||
    right === null ||
    right === undefined
  ) {
    return false;
  }

  if (typeof left !== "object" || typeof right !== "object") {
    return false;
  }

  try {
    return JSON.stringify(left) === JSON.stringify(right);
  } catch (error) {
    return false;
  }
}

function shouldRefreshLocalValue(properties, fieldName, currentValue) {
  const localKey = `${fieldName}_local_value`;
  const cloudKey = `${fieldName}_cloudberry_value`;
  const snapshotKey = getLocalValueSnapshotKey(fieldName);

  if (!hasOwn(properties, snapshotKey) && !hasOwn(properties, localKey)) {
    return true;
  }

  if (!hasOwn(properties, cloudKey)) {
    return true;
  }

  return !valuesEqual(currentValue, properties[cloudKey]);
}

function clearWidgetHeight(widget) {
  try {
    delete widget.height;
  } catch (error) {}

  try {
    widget.height = undefined;
  } catch (error) {}
}

function ensureNodeProperties(node) {
  if (!node.properties) {
    node.properties = {};
  }
  return node.properties;
}

function setNodeProperty(node, key, value) {
  if (typeof node.setProperty === "function") {
    node.setProperty(key, cloneValue(value));
    return;
  }

  ensureNodeProperties(node)[key] = cloneValue(value);
}

function deleteNodeProperty(node, key) {
  if (node.properties) {
    delete node.properties[key];
  }
}

function markNodeChanged(node) {
  try {
    node.setDirtyCanvas?.(true, true);
  } catch (error) {
    node.setDirtyCanvas?.(true);
  }

  node.graph?.change?.();
  node.graph?.setDirtyCanvas?.(true, true);
}

function getModelVersionFieldName(index) {
  return index === 0 ? "model_version_id" : `model_version_id${index + 1}`;
}

function getLocalValueSnapshotKey(fieldName) {
  return `${fieldName}_local_value_state`;
}

function writeLocalValueSnapshot(properties, fieldName, value) {
  console.log("[CloudBerry][local-snapshot][write]", {
    fieldName,
    present: value !== undefined,
    value: cloneValue(value),
  });
  properties[getLocalValueSnapshotKey(fieldName)] = {
    present: value !== undefined,
    value: cloneValue(value === undefined ? null : value),
  };

  if (value !== undefined) {
    properties[`${fieldName}_local_value`] = cloneValue(value);
  } else {
    delete properties[`${fieldName}_local_value`];
  }
}

function readLocalValueSnapshot(properties, fieldName, fallbackValue) {
  const snapshot = properties[getLocalValueSnapshotKey(fieldName)];
  if (snapshot && typeof snapshot === "object" && "present" in snapshot) {
    console.log("[CloudBerry][local-snapshot][read:state]", {
      fieldName,
      snapshot: cloneValue(snapshot),
      fallbackValue: cloneValue(fallbackValue),
    });
    return snapshot.present ? cloneValue(snapshot.value) : undefined;
  }

  if (properties[`${fieldName}_local_value`] !== undefined) {
    console.log("[CloudBerry][local-snapshot][read:legacy]", {
      fieldName,
      value: cloneValue(properties[`${fieldName}_local_value`]),
      fallbackValue: cloneValue(fallbackValue),
    });
    return cloneValue(properties[`${fieldName}_local_value`]);
  }

  console.log("[CloudBerry][local-snapshot][read:fallback]", {
    fieldName,
    fallbackValue: cloneValue(fallbackValue),
  });
  return fallbackValue;
}

function setWidgetValue(node, widget, value) {
  if (!widget) {
    return;
  }

  const nextValue = cloneValue(value);
  widget.value = nextValue;

  const widgetIndex = node.widgets?.indexOf(widget) ?? -1;
  if (widgetIndex !== -1 && Array.isArray(node.widgets_values)) {
    node.widgets_values[widgetIndex] = cloneValue(nextValue);
  }
}

function snapshotWidgetState(widget) {
  const options = widget.options || {};
  return {
    value: cloneValue(widget.value),
    mouse: widget.mouse || null,
    onPointerDown: widget.onPointerDown || null,
    hadOnPointerDown: hasOwn(widget, "onPointerDown"),
    hadOptionsValues: hasOwn(options, "values"),
    optionsValues: options.values,
    hadOptionsEditable: hasOwn(options, "editable"),
    optionsEditable: options.editable,
    hadClickable: hasOwn(widget, "clickable"),
    hadProcessMouse: hasOwn(widget, "processMouse"),
    clickableValue: widget.clickable,
    processMouseValue: widget.processMouse,
    hadShow: hasOwn(widget, "show"),
    showValue: widget.show,
    type: widget.type,
    computeSize: widget.computeSize,
    hidden: widget.hidden,
  };
}

function restoreWidgetState(node, widget, savedState, restoreValue = true) {
  if (!widget || !savedState) {
    return;
  }

  if (restoreValue && hasOwn(savedState, "value")) {
    setWidgetValue(node, widget, savedState.value);
  }

  if (savedState.mouse !== null) {
    widget.mouse = savedState.mouse;
  } else {
    delete widget.mouse;
  }

  if (savedState.hadOnPointerDown) {
    widget.onPointerDown = savedState.onPointerDown;
  } else {
    delete widget.onPointerDown;
  }

  widget.options = widget.options || {};
  if (savedState.hadOptionsValues) {
    widget.options.values = savedState.optionsValues;
  } else {
    delete widget.options.values;
  }

  if (savedState.hadOptionsEditable) {
    widget.options.editable = savedState.optionsEditable;
  } else {
    delete widget.options.editable;
  }

  if (savedState.hadClickable) {
    widget.clickable = savedState.clickableValue;
  } else {
    delete widget.clickable;
  }

  if (savedState.hadProcessMouse) {
    widget.processMouse = savedState.processMouseValue;
  } else {
    delete widget.processMouse;
  }

  if (savedState.computeSize !== undefined) {
    widget.computeSize = savedState.computeSize;
  }

  if (savedState.type !== undefined) {
    widget.type = savedState.type;
  }

  if (savedState.hidden === undefined) {
    delete widget.hidden;
  } else {
    widget.hidden = savedState.hidden;
  }

  if (savedState.hadShow) {
    widget.show = savedState.showValue;
  } else {
    delete widget.show;
  }

  clearWidgetHeight(widget);
}

function applyHiddenWidgetState(widget) {
  widget.computeSize = () => [0, -4];
  widget.type = "hidden";
  widget.hidden = true;
}

function removeWidgetByName(node, widgetName) {
  if (!Array.isArray(node.widgets)) {
    return;
  }

  const widgetIndex = node.widgets.findIndex((widget) => widget.name === widgetName);
  if (widgetIndex === -1) {
    return;
  }

  node.widgets.splice(widgetIndex, 1);
  if (Array.isArray(node.widgets_values)) {
    node.widgets_values.splice(widgetIndex, 1);
  }
}

function ensureModelVersionWidget(node, fieldName, originalState) {
  let widget = node.widgets?.find((item) => item.name === fieldName);

  if (widget) {
    if (!originalState.hiddenWidgets[fieldName]) {
      originalState.hiddenWidgets[fieldName] = {
        created: false,
        state: snapshotWidgetState(widget),
      };
    }
  } else {
    widget = node.addWidget("hidden", fieldName, "", function () {}, {
      serialize: true,
      values: [],
    });
    originalState.hiddenWidgets[fieldName] = { created: true };
  }

  applyHiddenWidgetState(widget);
  return widget;
}

function restoreModelVersionWidgets(node, originalState) {
  for (const [fieldName, meta] of Object.entries(
    originalState.hiddenWidgets || {}
  )) {
    if (meta.created) {
      removeWidgetByName(node, fieldName);
      continue;
    }

    const widget = node.widgets?.find((item) => item.name === fieldName);
    restoreWidgetState(node, widget, meta.state, true);
  }
}

function getDefaultCloudberryValue(savedValue) {
  if (savedValue !== null && typeof savedValue === "object") {
    return cloneValue(savedValue);
  }
  return "to choose";
}

/**
 * 创建 widget 回调函数
 * @param {Object} nodeConfig - 节点配置
 * @param {Array} selectedBaseModels - 选中的基础模型列表
 * @returns {Function}
 */
export function createSetWidgetCallback(nodeConfig, selectedBaseModels = []) {
  return function setWidgetCallback() {
    if (!nodeConfig || !nodeConfig.config || !nodeConfig.config.inputs) {
      console.warn("[CloudBerry] 节点配置无效:", nodeConfig);
      return;
    }

    const targetWidgets = getTargetWidgetsForNode(this, nodeConfig);

    targetWidgets.forEach(({ widget, inputKey, inputConfig }) => {
      if (inputConfig.disable_comfyagent) {
        console.log(`[CloudBerry] 跳过禁用的widget: ${inputKey}`);
        return;
      }

      if (!widget.value) {
        setWidgetValue(this, widget, "to choose");
      }

      const capturedNode = this;
      const modelType = getModelTypeFromInput(inputConfig);

      function openModelSelect(hostNode) {
        if (!modelType) return false;

        const targetNode = capturedNode;
        if (!targetNode || !targetNode.widgets) return false;

        const widgetContext = {
          node: targetNode,
          widget,
          inputKey,
          targetWidgets,
          twIndex: targetWidgets.findIndex((tw) => tw.widget === widget),
        };

        if (!targetNode._pendingWidgetSelect) {
          targetNode._pendingWidgetSelect = new Map();
        }
        targetNode._pendingWidgetSelect.set(widget.name, widgetContext);

        if (
          typeof bizyairCBLib !== "undefined" &&
          typeof bizyairCBLib.showModelSelect === "function"
        ) {
          bizyairCBLib.showModelSelect({
            modelType: [modelType],
            selectedBaseModels,
            onApply: (version, model) => {
              handleModelApply(
                targetNode,
                widget,
                version,
                model,
                targetWidgets
              );
              if (hostNode && hostNode !== targetNode) {
                const promotedWidget = hostNode.widgets?.find(
                  (w) => w.name === widget.name && w !== widget
                );
                if (promotedWidget) {
                  setWidgetValue(hostNode, promotedWidget, widget.value);
                  markNodeChanged(hostNode);
                }
              }

              const siblings = findSubgraphSiblingWidgets(targetNode, widget);
              for (const { node: sibNode, widget: sibWidget } of siblings) {
                if (!sibNode._cloudberryHijacked) continue;
                const sibTWs = getTargetWidgetsForNode(
                  sibNode,
                  sibNode._cloudberryNodeConfig
                );
                const sibTwIdx = sibTWs.findIndex(
                  (tw) => tw.widget === sibWidget
                );
                if (sibTwIdx < 0) continue;

                setWidgetValue(sibNode, sibWidget, widget.value);
                applyVersionToNode(
                  sibNode,
                  sibWidget,
                  version,
                  sibTWs,
                  sibTwIdx
                );
                removeBadgeIfAllRequiredFilled(sibNode, sibTWs);
                markNodeChanged(sibNode);

                console.log("[CloudBerry][onApply][sibling]", {
                  nodeId: sibNode.id,
                  nodeType: sibNode.comfyClass || sibNode.type,
                  widgetName: sibWidget.name,
                  fieldName: sibTWs[sibTwIdx]?.fieldName,
                  versionId: version?.id,
                });
              }
            },
          });
          return true;
        }
        return false;
      }

      widget.onPointerDown = function (pointer, node, canvas) {
        return openModelSelect(node);
      };

      widget.mouse = function (e, pos, node) {
        try {
          if (
            e.type === "pointerdown" ||
            e.type === "mousedown" ||
            e.type === "click" ||
            e.type === "pointerup"
          ) {
            e.preventDefault();
            e.stopPropagation();
            e.widgetClick = true;
            openModelSelect(node || this.node);
            return false;
          }
        } catch (error) {
          console.error("[CloudBerry] Error handling mouse event:", error);
        }
      };

      widget.options = widget.options || {};
      widget.options.values = () => [];
      widget.options.editable = false;
      widget.clickable = true;
      widget.processMouse = true;
    });
  };
}

/**
 * 将 version 信息写入节点的可见 widget、隐藏 model_version_id[N] widget
 * 以及 node.properties（含 cloudberry_value 快照）。
 *
 * 这段逻辑既被锚点节点（handleModelApply）调用，也被子图兄弟内部节点在
 * onApply 回调里复用，以确保多节点共享同一个子图输入槽时版本 ID 都能同步。
 *
 * @param {Object} node - 需要写入的节点
 * @param {Object} widget - 节点上要写入的 widget
 * @param {Object} version - 版本信息（含 id / file_name）
 * @param {Array} targetWidgets - 该节点的 targetWidgets（由 getTargetWidgetsForNode 产出）
 * @param {number} twIndex - widget 在 targetWidgets 中的索引
 */
function applyVersionToNode(node, widget, version, targetWidgets, twIndex) {
  if (!node || !node.widgets || !widget || !version) return;

  const tw = targetWidgets?.[twIndex];
  const fieldName = tw?.fieldName || getModelVersionFieldName(twIndex);

  let nextWidgetValue;
  if (typeof widget.value === "object" && widget.value !== null) {
    const fieldToUpdate = "lora" in widget.value ? "lora" : "model";
    nextWidgetValue = {
      ...widget.value,
      [fieldToUpdate]: version.file_name,
    };
  } else {
    nextWidgetValue = version.file_name;
  }
  setWidgetValue(node, widget, nextWidgetValue);

  const modelVersionField = node.widgets.find((item) => item.name === fieldName);
  if (modelVersionField) {
    setWidgetValue(node, modelVersionField, version.id);
    setNodeProperty(node, fieldName, version.id);
  }

  const isPowerLoraNode = String(node.comfyClass || node.type || "").includes(
    "Power Lora Loader"
  );
  if (isPowerLoraNode && widget.name?.startsWith("lora_")) {
    const idsWidget = node.widgets?.find((item) => item.name === "model_version_id");
    if (idsWidget) {
      const loraWidgets =
        node.widgets?.filter((item) => item.name?.startsWith("lora_")) ?? [];
      const loraIndex = loraWidgets.indexOf(widget);
      const arr = Array.isArray(idsWidget.value) ? [...idsWidget.value] : [];
      if (loraIndex >= 0) {
        arr[loraIndex] = version.id;
      }
      setWidgetValue(node, idsWidget, arr);
      setNodeProperty(node, "model_version_id", arr);
    }
  }

  setNodeProperty(node, `${fieldName}_cloudberry_value`, widget.value);
}

/**
 * 若节点所有 required 的 targetWidget 都已选好模型，则移除红色徽章。
 *
 * @param {Object} node - 节点
 * @param {Array} targetWidgets - 节点的 targetWidgets
 */
function removeBadgeIfAllRequiredFilled(node, targetWidgets) {
  if (!node || !Array.isArray(targetWidgets)) return;
  for (const tw of targetWidgets) {
    if (
      tw?.inputConfig?.required &&
      (!tw.widget ||
        !tw.widget.value ||
        tw.widget.value === "to choose")
    ) {
      return;
    }
  }
  removeBadge(node);
}

/**
 * 处理模型选择后的应用回调
 * @param {Object} node - 节点对象
 * @param {Object} widget - widget对象
 * @param {Object} version - 版本信息
 * @param {Object} model - 模型信息
 * @param {Array} targetWidgets - 目标widgets数组
 */
function handleModelApply(node, widget, version, model, targetWidgets) {
  console.log("[CloudBerry] onApply callback fired", {
    version,
    model,
    nodeId: node?.id,
  });

  if (!node || !node.widgets) {
    console.warn("[CloudBerry] node or widgets not available");
    return;
  }

  const context = node._pendingWidgetSelect?.get(widget.name);
  if (!context) {
    console.warn("[CloudBerry] widget context not found");
    return;
  }

  const { twIndex } = context;

  applyVersionToNode(node, widget, version, targetWidgets, twIndex);
  removeBadgeIfAllRequiredFilled(node, targetWidgets);

  if (node._pendingWidgetSelect) {
    node._pendingWidgetSelect.delete(widget.name);
    if (node._pendingWidgetSelect.size === 0) {
      delete node._pendingWidgetSelect;
    }
  }

  markNodeChanged(node);
  console.log("[CloudBerry] After setting - widget.value:", widget.value);
}

// ==================== 节点鼠标行为 ====================

/**
 * 设置节点鼠标行为
 * @param {Object} node - 节点对象
 * @param {Object} nodeConfig - 节点配置
 */
export function setupNodeMouseBehavior(node, nodeConfig) {
  if (!node._bizyairState) {
    node._bizyairState = {
      lastClickTime: 0,
      DEBOUNCE_DELAY: 300,
      nodeConfig,
    };
    return;
  }

  node._bizyairState.nodeConfig = nodeConfig;
}

// ==================== 加载时值校对 ====================

/**
 * 页面加载后在本地模式下校对节点 widget 值。
 * ComfyUI 的工作流持久化可能延迟保存，导致刷新后 widget
 * 仍然携带 cloudberry 模式的值。此函数利用 node.properties
 * 中的本地快照将 widget 恢复到正确的本地值。
 */
export function reconcileNodeOnLoad(node, nodeConfig) {
  if (!node || !nodeConfig) return;

  const properties = node.properties;
  if (!properties) return;

  const targetWidgets = getTargetWidgetsForNode(node, nodeConfig);
  if (targetWidgets.length === 0) return;

  let reconciled = false;

  targetWidgets.forEach(({ widget, fieldName }) => {
    const cloudKey = `${fieldName}_cloudberry_value`;
    const snapshotKey = getLocalValueSnapshotKey(fieldName);

    if (!hasOwn(properties, cloudKey) || !hasOwn(properties, snapshotKey)) {
      return;
    }

    const cloudberryValue = properties[cloudKey];
    const currentValue = widget.value;

    if (valuesEqual(currentValue, cloudberryValue)) {
      const snapshot = properties[snapshotKey];
      if (snapshot && typeof snapshot === "object" && "present" in snapshot) {
        const restoreValue = snapshot.present ? cloneValue(snapshot.value) : undefined;
        setWidgetValue(node, widget, restoreValue);
        reconciled = true;
      }
    }
  });

  if (reconciled) {
    if (Array.isArray(node.widgets) && Array.isArray(node.widgets_values) &&
        node.widgets_values.length > node.widgets.length) {
      node.widgets_values.length = node.widgets.length;
    }
    markNodeChanged(node);
  }
}

// ==================== 子图兄弟节点查找 ====================

/**
 * 读取 graph.links 中的一条 link，兼容对象与 Map 两种存储形式。
 * @param {Object} graph - LiteGraph graph 实例
 * @param {number|string} id - link id
 * @returns {Object|null}
 */
function getGraphLink(graph, id) {
  if (!graph || id == null) return null;
  const links = graph.links;
  if (!links) return null;
  if (typeof links.get === "function") {
    const v = links.get(id);
    if (v) return v;
  }
  return links[id] ?? null;
}

/**
 * 查找与 anchorWidget 共享同一个 subgraph input 槽的兄弟内部节点及其对应 widget。
 *
 * 场景：子图节点上一个提升出来的 widget（例如 ckpt_name）在子图内部同时连到
 * 多个加载器节点。此时 ComfyUI 通过子图 hoist 联动文件名，但 CloudBerry 自建
 * 的隐藏 widget model_version_id[N] 不在联动范围内，需要前端显式同步。
 *
 * 非子图场景（link.origin_id !== -10）直接返回空数组，行为与现状完全等价。
 *
 * @param {Object} anchorNode - 被点击/回调对应的锚点内部节点
 * @param {Object} anchorWidget - 锚点节点上被操作的 widget
 * @returns {Array<{node: Object, widget: Object}>}
 */
function findSubgraphSiblingWidgets(anchorNode, anchorWidget) {
  if (!anchorNode || !anchorWidget) return [];
  const graph = anchorNode.graph;
  if (!graph) return [];

  if (!Array.isArray(anchorNode.inputs)) return [];
  const anchorInput = anchorNode.inputs.find(
    (inp) => inp?.widget?.name === anchorWidget.name
  );
  if (!anchorInput || anchorInput.link == null) return [];

  const anchorLink = getGraphLink(graph, anchorInput.link);
  if (!anchorLink || anchorLink.origin_id !== -10) return [];

  const subgraphSlot = anchorLink.origin_slot;
  const siblings = [];
  const nodes = graph._nodes ?? graph.nodes ?? [];
  for (const node of nodes) {
    if (!node || node === anchorNode || !Array.isArray(node.inputs)) continue;
    for (const inp of node.inputs) {
      if (!inp?.widget) continue;
      const link = getGraphLink(graph, inp.link);
      if (
        link &&
        link.origin_id === -10 &&
        link.origin_slot === subgraphSlot
      ) {
        const w = node.widgets?.find((x) => x.name === inp.widget.name);
        if (w) siblings.push({ node, widget: w });
      }
    }
  }
  return siblings;
}

// ==================== 模式切换：劫持/恢复 ====================

/**
 * 解析节点上需要被 CloudBerry 劫持的 targetWidgets
 * @param {Object} node - 节点实例
 * @param {Object} nodeConfig - 节点配置
 * @returns {Array} targetWidgets 数组，每项 { widget, inputKey, inputConfig, fieldName }
 */
export function getTargetWidgetsForNode(node, nodeConfig) {
  if (!nodeConfig || !nodeConfig.config || !nodeConfig.config.inputs) {
    return [];
  }

  const inputs = nodeConfig.config.inputs;
  const inputKeys = Object.keys(inputs);
  const targetWidgets = [];

  inputKeys.forEach((inputKey) => {
    const cfg = inputs[inputKey];
    if (cfg && !cfg.disable_comfyagent) {
      if (cfg.pattern) {
        const regex = new RegExp(cfg.pattern);
        const matchedWidgets = node.widgets.filter((widget) =>
          regex.test(widget.name)
        );
        matchedWidgets.forEach((widget, idx) => {
          const widgetCfg = { ...cfg };
          if (cfg.multiple !== undefined) {
            widgetCfg.required = idx < cfg.multiple;
          }
          targetWidgets.push({
            widget,
            inputKey: widget.name,
            inputConfig: widgetCfg,
          });
        });
      } else {
        const widget = node.widgets.find((item) => item.name === inputKey);
        if (widget) {
          targetWidgets.push({
            widget,
            inputKey,
            inputConfig: cfg,
          });
        }
      }
    }
  });

  if (targetWidgets.length === 0) {
    const fallbackWidgets = node.widgets.filter((widget) =>
      possibleWidgetNames.includes(widget.name)
    );
    fallbackWidgets.forEach((widget) => {
      const firstInput = Object.values(inputs)[0];
      if (firstInput) {
        targetWidgets.push({
          widget,
          inputKey: widget.name,
          inputConfig: firstInput,
        });
      }
    });
  }

  return targetWidgets.map((targetWidget, index) => ({
    ...targetWidget,
    fieldName: getModelVersionFieldName(index),
  }));
}

/**
 * 劫持节点 widget，切换到 CloudBerry 模式
 * @param {Object} node - 节点实例
 * @param {Object} nodeConfig - 节点配置
 */
export function hijackNode(node, nodeConfig) {
  if (node._cloudberryHijacked) {
    return;
  }

  const targetWidgets = getTargetWidgetsForNode(node, nodeConfig);
  if (targetWidgets.length === 0) {
    return;
  }

  const properties = ensureNodeProperties(node);
  const originalState = { widgets: {}, hiddenWidgets: {} };

  targetWidgets.forEach(({ widget, fieldName }) => {
    const shouldRefresh = shouldRefreshLocalValue(properties, fieldName, widget.value);
    console.log("[CloudBerry][hijack][prepare]", {
      nodeId: node.id,
      nodeType: node.comfyClass || node.type,
      widgetName: widget.name,
      fieldName,
      currentWidgetValue: cloneValue(widget.value),
      cloudberryValue: cloneValue(properties[`${fieldName}_cloudberry_value`]),
      existingLocalSnapshot: cloneValue(properties[getLocalValueSnapshotKey(fieldName)]),
      shouldRefreshLocalValue: shouldRefresh,
    });

    if (shouldRefresh) {
      writeLocalValueSnapshot(properties, fieldName, widget.value);
    }
    originalState.widgets[widget.name] = snapshotWidgetState(widget);

    const modelVersionWidget = ensureModelVersionWidget(
      node,
      fieldName,
      originalState
    );
    const persistedVersionValue =
      properties[fieldName] !== undefined
        ? properties[fieldName]
        : modelVersionWidget.value ?? "";
    setWidgetValue(node, modelVersionWidget, persistedVersionValue);
  });

  node._cloudberryOriginalState = originalState;

  targetWidgets.forEach(({ widget, fieldName }) => {
    const savedLocalValue = originalState.widgets[widget.name]?.value;
    const cloudberryValue = properties[`${fieldName}_cloudberry_value`];
    let nextValue;

    if (cloudberryValue !== undefined && cloudberryValue !== null) {
      if (
        savedLocalValue !== null &&
        typeof savedLocalValue === "object" &&
        typeof cloudberryValue === "object"
      ) {
        nextValue = {
          ...cloneValue(savedLocalValue),
          ...cloneValue(cloudberryValue),
        };
      } else {
        nextValue = cloudberryValue;
      }
    } else {
      nextValue = getDefaultCloudberryValue(savedLocalValue);
    }

    console.log("[CloudBerry][hijack][apply]", {
      nodeId: node.id,
      nodeType: node.comfyClass || node.type,
      widgetName: widget.name,
      fieldName,
      savedLocalValue: cloneValue(savedLocalValue),
      cloudberryValue: cloneValue(cloudberryValue),
      nextValue: cloneValue(nextValue),
    });
    setWidgetValue(node, widget, nextValue);
  });

  createSetWidgetCallback(nodeConfig, []).call(node);

  setTimeout(() => {
    checkAndAddBadge(node, targetWidgets);
  }, 200);

  setupNodeMouseBehavior(node, nodeConfig);
  node._cloudberryHijacked = true;
  markNodeChanged(node);
}

/**
 * 恢复节点 widget 到原始本地模式
 * @param {Object} node - 节点实例
 */
export function unhijackNode(node) {
  if (!node._cloudberryHijacked || !node._cloudberryOriginalState) {
    return;
  }

  const properties = ensureNodeProperties(node);
  const originalState = node._cloudberryOriginalState;
  const targetWidgets = getTargetWidgetsForNode(node, node._cloudberryNodeConfig);

  targetWidgets.forEach(({ widget, fieldName }) => {
    setNodeProperty(node, `${fieldName}_cloudberry_value`, widget.value);

    const modelVersionWidget = node.widgets.find((item) => item.name === fieldName);
    if (modelVersionWidget) {
      setNodeProperty(node, fieldName, modelVersionWidget.value);
    }

    console.log("[CloudBerry][unhijack][persist-cloudberry]", {
      nodeId: node.id,
      nodeType: node.comfyClass || node.type,
      widgetName: widget.name,
      fieldName,
      widgetValue: cloneValue(widget.value),
      modelVersionValue: cloneValue(modelVersionWidget?.value),
    });
  });

  targetWidgets.forEach(({ widget, fieldName }) => {
    const savedState = originalState.widgets[widget.name];
    const localValue = readLocalValueSnapshot(
      properties,
      fieldName,
      savedState?.value
    );

    console.log("[CloudBerry][unhijack][restore-before]", {
      nodeId: node.id,
      nodeType: node.comfyClass || node.type,
      widgetName: widget.name,
      fieldName,
      currentWidgetValue: cloneValue(widget.value),
      savedStateValue: cloneValue(savedState?.value),
      localValue,
      localSnapshot: cloneValue(properties[getLocalValueSnapshotKey(fieldName)]),
    });
    restoreWidgetState(node, widget, savedState, false);
    setWidgetValue(node, widget, localValue);
    console.log("[CloudBerry][unhijack][restore-after]", {
      nodeId: node.id,
      nodeType: node.comfyClass || node.type,
      widgetName: widget.name,
      fieldName,
      finalWidgetValue: cloneValue(widget.value),
      widgetsValueIndex:
        node.widgets?.indexOf(widget) ?? -1,
      finalWidgetsValue:
        node.widgets &&
        Array.isArray(node.widgets_values) &&
        node.widgets.indexOf(widget) !== -1
          ? cloneValue(node.widgets_values[node.widgets.indexOf(widget)])
          : undefined,
    });
  });

  restoreModelVersionWidgets(node, originalState);
  removeBadge(node);

  delete node._pendingWidgetSelect;
  delete node._cloudberryOriginalState;
  delete node._cloudberryHijacked;
  delete node._bizyairState;

  markNodeChanged(node);
}

