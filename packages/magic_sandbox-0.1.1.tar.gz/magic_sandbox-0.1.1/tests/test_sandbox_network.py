"""测试沙箱网络访问能力"""

import pytest
import subprocess
from pathlib import Path
from magic_sandbox.main import MagicSandbox


class TestSandboxNetwork:
    """测试沙箱网络隔离和白名单功能"""
    
    _manifest_path = Path("/opt/dev/py_project/magic-sandbox/src/magic_sandbox/core/network/scripts/manifest.yaml")
    
    @pytest.fixture
    def sandbox_with_network(self):
        """创建启用网络白名单的沙箱"""
        with MagicSandbox(
            auto_cleanup=True,
            manifest_path=self._manifest_path,
            allow_network=True
        ) as sandbox:
            yield sandbox
    
    @pytest.fixture
    def sandbox_no_network(self):
        """创建禁用网络的沙箱"""
        with MagicSandbox(
            auto_cleanup=True,
            manifest_path=self._manifest_path,
            allow_network=False
        ) as sandbox:
            yield sandbox
    
    def test_dns_resolution_allowed(self, sandbox_with_network):
        # 先查看规则是否加载
        result = sandbox_with_network.run(["nft", "list", "ruleset"])
        print("=== NFT RULESET ===")
        print(result.stdout)
        print("=== END ===")
        
        # 再进行 DNS 查询
        result = sandbox_with_network.run(["nslookup", "github.com"])
        assert result.returncode == 0

    def test_dns_resolution_allowed(self, sandbox_with_network):
        """测试 DNS 解析（应该允许，因为 DNS 在白名单中）"""
        # 执行 DNS 查询
        result = sandbox_with_network.run(["nslookup", "github.com"])
        
        # DNS 应该能解析成功
        assert result.returncode == 0
        assert "Address:" in result.stdout or "Name:" in result.stdout
    
    def test_https_access_allowed(self, sandbox_with_network):
        """测试 HTTPS 访问白名单域名（应该允许）"""
        # 使用 curl 访问 github.com（HTTPS）
        result = sandbox_with_network.run([
            "curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", 
            "https://github.com"
        ])
        
        # 应该能访问成功
        assert result.returncode == 0
        assert result.stdout.strip() in ["200", "301", "302"]
    
    def test_https_access_blocked(self, sandbox_with_network):
        """测试访问非白名单域名（应该被阻止）"""
        # 尝试访问未在白名单中的网站
        result = sandbox_with_network.run([
            "curl", "-s", "--connect-timeout", "5", 
            "https://unknown-domain-12345.com"
        ])
        
        # 应该失败（连接超时或被拒绝）
        assert result.returncode != 0
    
    def test_ip_whitelist_allowed(self, sandbox_with_network):
        """测试 IP 白名单（应该允许）"""
        # 访问白名单中的 IP（159.254.220.17 是测试用 IP）
        result = sandbox_with_network.run([
            "curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
            "--connect-timeout", "5", "http://159.254.220.17"
        ])
        
        # 注意：这个 IP 可能没有服务，所以只要网络层允许即可
        # 这里只验证命令执行了，不验证 HTTP 状态码
        assert result.returncode == 0 or result.returncode == 7  # 7 表示连接失败但网络层允许
    
    def test_no_network_isolation(self, sandbox_no_network):
        """测试网络完全隔离（应该无法访问任何外部地址）"""
        # 尝试 ping 外部地址
        result = sandbox_no_network.run(["ping", "-c", "1", "-W", "2", "8.8.8.8"])
        
        # 应该失败
        assert result.returncode != 0
    
    def test_dig_command_works(self, sandbox_with_network):
        """测试 dig 命令可用（需要网络）"""
        result = sandbox_with_network.run(["dig", "+short", "github.com"])
        
        # dig 应该能正常执行
        assert result.returncode == 0
    
    def test_ping_blocked(self, sandbox_with_network):
        """测试 ICMP 协议被阻止（白名单只允许 TCP 443 和 UDP 53）"""
        result = sandbox_with_network.run(["ping", "-c", "1", "-W", "2", "8.8.8.8"])
        
        # ICMP 应该被阻止
        assert result.returncode != 0