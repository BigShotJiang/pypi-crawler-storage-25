"""测试BubblewrapSandbox的文件结构和隔离性"""
import pytest
from pathlib import Path
from magic_sandbox.main import MagicSandbox
from magic_sandbox.utils import write_to_workspace, read_file, file_exists, cleanup
class TestBubblewrapSandboxFilesystem:
    """测试沙箱文件系统结构和隔离性"""
    _manifest_path = Path("/opt/dev/py_project/magic-sandbox/src/magic_sandbox/core/network/scripts/manifest.yaml")
    @pytest.fixture
    def sandbox(self):
        """创建基础沙箱实例"""
        
        sandbox = MagicSandbox(auto_cleanup=True,manifest_path=self._manifest_path)
        yield sandbox
        sandbox.cleanup()
    
    @pytest.fixture
    def restrictive_sandbox(self):
        """创建严格限制的沙箱实例（无网络）"""
        
        sandbox = MagicSandbox(
            allow_network=False,
            timeout_seconds=5,
            auto_cleanup=True,
            manifest_path=self._manifest_path
        )
        yield sandbox
        sandbox.cleanup()
    
    def _copy_script(self, sandbox, script_name: str):
        """辅助方法：复制脚本到沙箱工作目录"""
        src = Path("tests/scripts") / script_name
        if not src.exists():
            raise FileNotFoundError(f"Script not found: {src}")
        content = src.read_text()
        write_to_workspace(sandbox.get_filesystem(), script_name, content)
    
    def test_readonly_system_dirs(self, sandbox):
        """测试系统目录以只读方式挂载"""
        self._copy_script(sandbox, "readonly_system.py")
        result = sandbox.run(["python3", "/workspace/readonly_system.py"])
        
        assert result.returncode == 0, f"Script failed: {result.stderr}"
        assert "SUCCESS" in result.stdout
    
    def test_writable_dirs_permission(self):
        """测试可写目录权限（工作目录内可写）"""
        
        
        sandbox = MagicSandbox(auto_cleanup=True,manifest_path=self._manifest_path)
        
        try:
            # 创建测试目录
            write_to_workspace(sandbox.get_filesystem(), "output/test.txt", "initial")
            
            # 复制脚本
            src = Path("tests/scripts/writable_permission.py")
            write_to_workspace(sandbox.get_filesystem(), "writable_permission.py", src.read_text())
            
            result = sandbox.run([
                "python3", "/workspace/writable_permission.py",
                "output", "readonly_data"
            ])
            
            assert result.returncode == 0
            assert "SUCCESS" in result.stdout
        finally:
            sandbox.cleanup()
    
    def test_proc_filesystem_mounted(self, sandbox):
        """测试/proc文件系统正确挂载"""
        self._copy_script(sandbox, "proc_mount.py")
        result = sandbox.run(["python3", "/workspace/proc_mount.py"])
        
        assert result.returncode == 0
        assert "PASS: /proc exists" in result.stdout
        assert "SUCCESS" in result.stdout
    
    def test_dev_filesystem_mounted(self, sandbox):
        """测试/dev文件系统正确挂载"""
        src = Path("tests/scripts/dev_mount.py")
        write_to_workspace(sandbox.get_filesystem(), "dev_mount.py", src.read_text())
        
        result = sandbox.run(["python3", "/workspace/dev_mount.py"])
        
        assert result.returncode == 0
        assert "SUCCESS" in result.stdout
    
    def test_tmpfs_mounted(self, sandbox):
        """测试/tmp是tmpfs且可写"""
        self._copy_script(sandbox, "tmpfs.py")
        result = sandbox.run(["python3", "/workspace/tmpfs.py"])
        
        assert result.returncode == 0
        assert "PASS: Can write to /tmp" in result.stdout
    
    def test_restrictive_sandbox(self, restrictive_sandbox):
        """测试严格限制沙箱"""
        self._copy_script(restrictive_sandbox, "restrictive_write.py")
        
        result = restrictive_sandbox.run(["python3", "/workspace/restrictive_write.py"])
        
        assert result.returncode == 0
        assert "FAIL" not in result.stdout
        assert "PASS: Cannot write to" in result.stdout
    
    def test_workspace_isolation(self):
        """测试不同沙箱实例的工作空间隔离"""
        
        
        sandbox1 = MagicSandbox(auto_cleanup=True,manifest_path=self._manifest_path)
        sandbox2 = MagicSandbox(auto_cleanup=True,manifest_path=self._manifest_path)
        
        try:
            # 沙箱1写入文件
            write_to_workspace(sandbox1.get_filesystem(), "unique.txt", "content from sandbox1")
            
            # 沙箱2写入文件
            write_to_workspace(sandbox2.get_filesystem(), "unique.txt", "content from sandbox2")
            
            # 复制测试脚本
            src = Path("tests/scripts/workspace_isolation.py")
            write_to_workspace(sandbox1.get_filesystem(), "test.py", src.read_text())
            write_to_workspace(sandbox2.get_filesystem(), "test.py", src.read_text())
            
            # 验证沙箱1只能看到自己的文件
            result1 = sandbox1.run(["python3", "/workspace/test.py", "content from sandbox1"])
            assert "SUCCESS" in result1.stdout
            
            # 验证沙箱2只能看到自己的文件
            result2 = sandbox2.run(["python3", "/workspace/test.py", "content from sandbox2"])
            assert "SUCCESS" in result2.stdout
            
        finally:
            sandbox1.cleanup()
            sandbox2.cleanup()
    
    def test_auto_cleanup(self):
        """测试自动清理功能"""
        
        
        sandbox = MagicSandbox(auto_cleanup=False,manifest_path=self._manifest_path)
        sandbox_root = sandbox.root
        
        try:
            assert sandbox_root.exists()
            
            write_to_workspace(sandbox.get_filesystem(), "test.txt", "test content")
            assert (sandbox_root / "workspace" / "test.txt").exists()
            
            sandbox.cleanup()
            assert not sandbox_root.exists()
        finally:
            if sandbox_root.exists():
                sandbox.cleanup()
    
    def test_context_manager(self):
        """测试上下文管理器"""
        
        
        with MagicSandbox(auto_cleanup=True, manifest_path=self._manifest_path) as sandbox:
            write_to_workspace(sandbox.get_filesystem(), "test.txt", "context test")
            result = sandbox.run(["cat", "/workspace/test.txt"])
            assert "context test" in result.stdout
            sandbox_root = sandbox.root
            assert sandbox_root.exists()
        
        assert not sandbox_root.exists()
    
    def test_list_workspace(self, sandbox):
        """列出沙箱工作目录"""
        result = sandbox.run(["ls", "-la", "/workspace/"])
        print("\n=== Workspace Files ===\n")
        print(result.stdout)
        
        # 如果有子目录，递归显示
        result = sandbox.run(["find", "/workspace", "-type", "f"])
        print("\n=== All files in workspace ===\n")
        print(result.stdout)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])