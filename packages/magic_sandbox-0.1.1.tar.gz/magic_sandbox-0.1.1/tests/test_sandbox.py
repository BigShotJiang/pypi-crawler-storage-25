"""沙箱测试"""

import sys
import tempfile
from pathlib import Path

from magic_sandbox.utils.util import file_exists, read_file, write_to_workspace

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from magic_sandbox import MagicSandbox

_manifest_path = Path("/opt/dev/py_project/magic-sandbox/src/magic_sandbox/core/network/scripts/manifest.yaml")
    
def test_basic_usage():
    """基本使用测试"""
    with MagicSandbox(allow_network=False, manifest_path=_manifest_path) as sandbox:
        write_to_workspace(sandbox.get_filesystem(), "test.txt", "hello")
        result = sandbox.run(["cat", "test.txt"])
        assert "hello" in result.stdout  # 改为包含检查


def test_file_operations():
    """文件操作测试"""
    with MagicSandbox(manifest_path=_manifest_path) as sandbox:
        write_to_workspace(sandbox.get_filesystem(), "script.py", "print('ok')")
        assert file_exists(sandbox.get_filesystem(), "/workspace/script.py")
        
        content = read_file(sandbox.get_filesystem(), "/workspace/script.py")
        assert "print('ok')" in content


if __name__ == "__main__":
    test_basic_usage()
    test_file_operations()
    print("All tests passed!")