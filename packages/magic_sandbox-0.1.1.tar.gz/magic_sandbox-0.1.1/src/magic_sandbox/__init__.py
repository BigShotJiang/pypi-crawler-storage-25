"""跨平台沙箱"""

from .main import MagicSandbox

__all__ = ["MagicSandbox"]
