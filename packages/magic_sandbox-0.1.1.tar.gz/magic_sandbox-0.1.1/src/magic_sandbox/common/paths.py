"""跨平台路径处理"""

from pathlib import Path


def normalize_sandbox_path(sandbox_path: str) -> str:
    """标准化沙箱内路径（统一使用 /）"""
    return sandbox_path.lstrip("/").replace("\\", "/")


def to_host_path(root: Path, sandbox_path: str) -> Path:
    """将沙箱路径转换为主机路径"""
    normalized = normalize_sandbox_path(sandbox_path)
    if not normalized:
        return root
    return root / normalized
