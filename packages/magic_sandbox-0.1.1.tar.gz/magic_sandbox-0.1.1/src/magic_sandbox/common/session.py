"""会话管理"""

import uuid

def generate_session_id() -> str:
    """生成唯一会话ID"""
    return f"sandbox_{uuid.uuid4().hex[:12]}"
