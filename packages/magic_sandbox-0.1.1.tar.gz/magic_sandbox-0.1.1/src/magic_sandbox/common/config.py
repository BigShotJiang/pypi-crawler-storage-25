"""跨平台配置"""

import os
import platform
from pathlib import Path


def get_default_base_dir() -> Path:
    """根据平台返回默认沙箱根目录"""
    system = platform.system()
    
    if system == "Windows":
        base = Path(os.environ.get("TEMP", "C:\\temp"))
        return base / "magic_sandbox"
    elif system == "Darwin":  # macOS
        return Path("/tmp/magic_sandbox")
    else:  # Linux
        return Path("/opt/dev/sandbox")
