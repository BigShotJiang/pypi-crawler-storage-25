"""Linux 资源限制实现"""

from typing import Dict
from .interface import Resource


class LinuxResource(Resource):
    def __init__(self):
        self._cpu_limit = None
        self._mem_limit = None
    
    def set_limits(self, cpu_limit: int = None, mem_limit: int = None):
        self._cpu_limit = cpu_limit
        self._mem_limit = mem_limit
    
    def get_limits(self) -> Dict[str, int]:
        limits = {}
        if self._cpu_limit:
            limits["cpu"] = self._cpu_limit
        if self._mem_limit:
            limits["memory"] = self._mem_limit
        return limits
