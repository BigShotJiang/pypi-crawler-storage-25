"""资源限制抽象接口"""

from abc import ABC, abstractmethod
from typing import Dict


class Resource(ABC):
    """资源限制接口"""
    
    @abstractmethod
    def set_limits(self, cpu_limit: int = None, mem_limit: int = None):
        """设置资源限制"""
        pass
    
    @abstractmethod
    def get_limits(self) -> Dict[str, int]:
        """获取当前限制"""
        pass
