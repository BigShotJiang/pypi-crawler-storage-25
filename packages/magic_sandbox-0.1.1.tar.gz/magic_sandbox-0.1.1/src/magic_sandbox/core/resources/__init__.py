"""资源限制模块"""
from .linux import LinuxResource
from .darwin import DarwinResource
from .windows import WindowsResource

__all__ = ['LinuxResource', 'DarwinResource', 'WindowsResource']