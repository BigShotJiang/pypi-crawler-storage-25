"""隔离引擎抽象接口"""

from abc import ABC, abstractmethod
from pathlib import Path
from subprocess import CompletedProcess
from typing import List, Optional

from ..filesystem.interface import FileSystem



class Sandbox(ABC):
    """沙箱隔离引擎接口"""
    
    @abstractmethod
    def setup(
        self,
        root: Path,
        manifest_path: Optional[Path] = None  # 新增参数
    ) -> None:
        """初始化隔离环境"""
        pass
    
    @abstractmethod
    def run(self, command: List[str], timeout: int) -> CompletedProcess:
        """在隔离环境中执行命令"""
        pass
    
    @abstractmethod
    def cleanup(self) -> None:
        """清理隔离环境"""
        pass

    @abstractmethod
    def get_filesystem(self) -> FileSystem:
        """获取文件系统接口"""
        pass