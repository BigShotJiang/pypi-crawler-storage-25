"""Windows AppContainer 隔离引擎（占位）"""

from pathlib import Path
from subprocess import CompletedProcess
from typing import List, Optional

from magic_sandbox.core.filesystem.interface import FileSystem

from .interface import Sandbox

class WindowsSandbox(Sandbox):
    def __init__(self):
        self.root: Optional[Path] = None
        self.fs: Optional[FileSystem] = None
    def setup(
        self,
        root: Path,
        manifest_path: Optional[Path] = None  # 新增参数        
    ) -> None:
        self.root = root
        print("[WindowsSandbox] Setup - Full implementation pending")
    
    def run(self, command: List[str], timeout: int) -> CompletedProcess:
        import subprocess
        
        print(f"[WindowsSandbox] Running (limited isolation): {' '.join(command)}")
        
        try:
            return subprocess.run(
                command,
                capture_output=True,
                timeout=timeout,
                text=True,
            )
        except subprocess.TimeoutExpired as e:
            return CompletedProcess(
                args=command,
                returncode=-1,
                stdout=e.stdout or "",
                stderr=e.stderr or f"Execution timed out after {timeout} seconds",
            )
    
    def cleanup(self) -> None:
        pass

    def get_filesystem(self) -> FileSystem:
        if self.fs is None:
            raise RuntimeError("Filesystem not initialized")
        return self.fs 