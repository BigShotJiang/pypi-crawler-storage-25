

# magic_sandbox/core/sandbox/manager.py 


from typing import Optional

from magic_sandbox.core.sandbox.interface import Sandbox
from .linux import LinuxSandbox
from .windows import WindowsSandbox
from .darwin import DarwinSandbox   

sandbox_registry = {
    "linux": LinuxSandbox,
    "windows": WindowsSandbox,
    "darwin": DarwinSandbox,
    
}   

class SandboxManager:
    """沙箱管理器"""

    def __init__(self, platform_name: Optional[str] = None):
        """初始化沙箱管理器"""
        self.platform = platform_name

    @classmethod
    def get_sandbox(self, platform_name: Optional[str] = None   ) -> Sandbox:
        """创建沙箱"""
        _sandbox = sandbox_registry.get(platform_name or self.platform)
        if _sandbox :
            return _sandbox()
        else:             
            raise RuntimeError(f"Unsupported platform: {platform_name or self.platform}") 
            

    