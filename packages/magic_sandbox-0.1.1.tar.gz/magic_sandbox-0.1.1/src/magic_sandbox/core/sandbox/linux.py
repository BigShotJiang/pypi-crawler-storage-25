"""Linux bwrap 隔离引擎"""

import os
import subprocess
from pathlib import Path
from subprocess import CompletedProcess
from typing import List, Optional

from .interface import Sandbox
from ..network.interface import Network
from ..resources.interface import Resource
from magic_sandbox.core.filesystem import FileSystem, LinuxFileSystem
from magic_sandbox.core.network import LinuxNetwork
from magic_sandbox.core.resources import LinuxResource


class LinuxSandbox(Sandbox):
    """
    Linux 沙箱隔离引擎，基于 bwrap（Bubblewrap）实现
    
    提供进程隔离、文件系统隔离、网络隔离和资源限制功能
    """
    
    def __init__(self):
        """初始化 Linux 沙箱实例"""
        self.root: Optional[Path] = None
        """沙箱根目录路径，用于文件系统隔离"""
        self.net: Optional[LinuxNetwork] = None
        """网络隔离控制器实例"""
        self.res: Optional[Resource] = None
        """资源限制控制器实例"""
        self.fs: Optional[LinuxFileSystem] = None
        """文件系统隔离控制器实例"""
    
    def setup(
        self,
        root: Path,        
        manifest_path: Optional[Path] = None
    ) -> None:
        """
        配置沙箱环境
        
        初始化文件系统、网络和资源控制器，准备沙箱运行环境
        
        Args:
            root: 沙箱根目录路径，将作为隔离环境的根文件系统            
            manifest_path: 网络白名单配置文件路径（可选）
        """
        self.root = root
        self.net = LinuxNetwork(manifest_path)  # 传入 manifest_path
        self.res = LinuxResource()
        self.fs = LinuxFileSystem(root)
    
    def run(self, command: List[str], timeout: int) -> CompletedProcess:
        """在沙箱中执行命令
        
        执行流程：
        1. 获取 nftables 规则脚本内容
        2. 将脚本写入沙箱工作目录
        3. 构建命令：先执行网络配置脚本，再执行用户命令
        4. 构建 bwrap 命令（合并文件系统挂载参数和网络参数）
        5. 执行命令并返回结果
        
        Args:
            command: 要执行的命令列表
            timeout: 超时时间（秒）
            
        Returns:
            命令执行结果
        """
        # 1. 获取网络配置脚本内容
        setup_script = self.net.get_nftables_scripts()
        
        # 调试：打印脚本内容
        if setup_script:
            print("=" * 70)
            print("DEBUG: Network setup script content:")
            print("=" * 70)
            print(setup_script)
            print("=" * 70)

        # 2. 构建最终要执行的命令
        exec_command = list(command)
        if setup_script:
            # 通过 fs 将脚本写入沙箱
            script_path = "/workspace/network_setup.sh"
            self.fs.write_file(script_path, setup_script)
            # 设置可执行权限
            host_path = self.fs.root / script_path.lstrip('/')
            host_path.chmod(0o755)
            
            # 调试：打印脚本路径和内容
            print(f"DEBUG: Script written to host path: {host_path}")
            print(f"DEBUG: Script exists: {host_path.exists()}")
            print(f"DEBUG: Script content from host:")
            print(host_path.read_text())

            # 构建命令：先执行网络配置，再运行用户命令
            # 将每个参数用引号括起来，避免空格导致参数分割
            quoted_command = ' '.join(f'"{arg}"' for arg in command)
            full_command = f"bash {script_path} && {quoted_command}"
            exec_command = ["bash", "-c", full_command]

            # 调试：打印最终要执行的命令
            print(f"DEBUG: Full command to execute: {full_command}")

        # 3. 构建 bwrap 命令
        # 先获取 filesystem 的挂载参数
        fs_args = self.fs.get_mount_args()
        
        # 获取 network 的 bwrap 参数（包含 capabilities）
        net_args = self.net.get_bwrap_args()
        
        # 合并命令
        bwrap_cmd = ["bwrap"] + net_args + fs_args + ["--", "bash", "-c", " ".join(exec_command)]
        
        # 调试：打印最终 bwrap 命令
        print(f"DEBUG: Final bwrap command: {bwrap_cmd}")
        
        try:
            return subprocess.run(
                bwrap_cmd,
                capture_output=True,
                timeout=timeout,
                text=True,
            )
        except subprocess.TimeoutExpired as e:
            return CompletedProcess(
                args=bwrap_cmd,
                returncode=-1,
                stdout=e.stdout or "",
                stderr=e.stderr or f"Execution timed out after {timeout} seconds",
            )
    
    def cleanup(self) -> None:
        """清理沙箱资源
        
        依次清理网络控制器和文件系统控制器
        """
        if self.net:
            self.net.cleanup()
        if self.fs:
            self.fs.cleanup()
    
    def get_filesystem(self) -> FileSystem:
        """获取文件系统控制器
        
        Returns:
            文件系统控制器实例
            
        Raises:
            RuntimeError: 如果文件系统尚未初始化
        """
        if self.fs is None:
            raise RuntimeError("Filesystem not initialized")
        return self.fs