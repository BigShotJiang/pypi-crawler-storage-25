
# magic_sandbox/core/filesystem/manager.py

from typing import Optional

from magic_sandbox.core.filesystem.interface import FileSystem

from .linux import LinuxFileSystem
from .windows import WindowsFileSystem
from .darwin import DarwinFileSystem

"""文件系统管理器"""

platform = {
    "Linux": LinuxFileSystem,
    "Windows": WindowsFileSystem,
    "Darwin": DarwinFileSystem
}

class FileSystemManager:
    """文件系统管理器，负责协调不同平台的文件系统实现"""
    def __init__(self, platform_name: str):
        self.platform = platform_name
        
    @classmethod
    def get_filesystem(self, platform_name: Optional[str] = None) -> FileSystem:
        """获取当前平台的文件系统实现"""
        if platform_name is None:
            platform_name = self.platform
        fs_class = platform.get(platform_name)
        if fs_class is None:
            raise RuntimeError(f"Unsupported platform: {platform_name}")
        return fs_class()