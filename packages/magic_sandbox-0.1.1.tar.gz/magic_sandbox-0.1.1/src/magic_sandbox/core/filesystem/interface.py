"""文件系统抽象接口"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Optional


class FileSystem(ABC):
    """文件系统操作接口
    
    职责：文件操作 + 挂载参数
    """
    
    @abstractmethod
    def write_file(self, sandbox_path: str, content: str) -> Path:
        """写入文件"""
        pass
    
    @abstractmethod
    def write_to_workspace(self, filename: str, content: str) -> Path:
        """写入文件到工作目录"""
        pass
    
    @abstractmethod
    def read_file(self, sandbox_path: str) -> str:
        """读取文件"""
        pass
    
    @abstractmethod
    def file_exists(self, sandbox_path: str) -> bool:
        """检查文件是否存在"""
        pass
    
    @abstractmethod
    def get_mount_args(self) -> List[str]:
        """获取挂载参数（供 Sandbox 构建命令）"""
        pass
    
    @abstractmethod
    def cleanup(self):
        """清理沙箱目录"""
        pass