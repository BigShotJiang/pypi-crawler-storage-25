"""Linux 文件系统实现"""

import os
from pathlib import Path
from typing import List, Optional

from .interface import FileSystem
from ...common.paths import to_host_path


class LinuxFileSystem(FileSystem):
    def __init__(self, root: Path):
        self.root = root
        self.workspace = "/workspace"
        self._create_layout()
        
    
    def _create_layout(self):
        """创建 Linux 沙箱目录结构"""
        directories = [
            "usr", "bin", "lib", "lib64", "sbin",
            "var", "var/run", "var/log", "var/tmp",
            "tmp", "proc", "dev", "dev/shm",
            "workspace", "home", "root", "opt", "mnt", "media",
        ]
        for d in directories:
            (self.root / d).mkdir(parents=True, exist_ok=True)
    
    def get_mount_args(self) -> List[str]:
        """获取挂载参数（供 Sandbox 使用）"""
        args = []
        
        # 根目录绑定
        args.extend(["--bind", str(self.root), "/"])
        
        # 只读系统目录
        for sysdir in ["/usr", "/bin", "/lib", "/lib64", "/sbin", "/etc", "/usr/sbin"]:
            if os.path.exists(sysdir):
                args.extend(["--ro-bind", sysdir, sysdir])
        
        # 虚拟文件系统
        args.extend(["--dev", "/dev"])
        args.extend(["--proc", "/proc"])
        
        # 临时目录
        args.extend(["--tmpfs", "/tmp"])
        args.extend(["--tmpfs", "/var/run"])
        args.extend(["--tmpfs", "/var/log"])
        args.extend(["--tmpfs", "/dev/shm"])
        
        # 工作目录
        args.extend(["--chdir", "/workspace"])
        
        return args
    
    def write_to_workspace(self, filename: str, content: str) -> Path:
        return self.write_file(f"{self.workspace}/{filename}", content)
    
    def write_file(self, sandbox_path: str, content: str) -> Path:
        host_path = to_host_path(self.root, sandbox_path)
        host_path.parent.mkdir(parents=True, exist_ok=True)
        host_path.write_text(content)
        return host_path
    
    def read_file(self, sandbox_path: str) -> str:
        host_path = to_host_path(self.root, sandbox_path)
        if host_path.exists():
            return host_path.read_text()
        return ""
    
    def file_exists(self, sandbox_path: str) -> bool:
        host_path = to_host_path(self.root, sandbox_path)
        return host_path.exists()
    
    def build_command(self, command: List[str]) -> List[str]:
        """构建 bwrap 命令（保持原有逻辑）"""
        # 网络隔离
        cmd = ["bwrap", "--unshare-net"]
        
        # 添加挂载参数
        cmd.extend(self.get_mount_args())       
        
        cmd.extend(["--"] + command)
        return cmd
    
    def cleanup(self):
        import shutil
        if self.root.exists():
            shutil.rmtree(self.root)