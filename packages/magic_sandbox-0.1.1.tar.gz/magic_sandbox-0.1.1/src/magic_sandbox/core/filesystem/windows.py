"""Windows 文件系统实现"""

from pathlib import Path
from typing import List

from .interface import FileSystem


class WindowsFileSystem(FileSystem):
    def __init__(self, root: Path):
        self.root = root
        self.workspace = "/workspace"
        self._create_layout()
    
    def _create_layout(self):
        """创建 Windows 沙箱目录结构"""
        directories = ["workspace", "tmp"]
        for d in directories:
            (self.root / d).mkdir(parents=True, exist_ok=True)
    
    def write_to_workspace(self, filename: str, content: str) -> Path:
        return self.write_file(f"{self.workspace}/{filename}", content)
    
    def write_file(self, sandbox_path: str, content: str) -> Path:
        # Windows 路径转换
        normalized = sandbox_path.lstrip("/").replace("/", "\\")
        host_path = self.root / normalized
        host_path.parent.mkdir(parents=True, exist_ok=True)
        host_path.write_text(content)
        return host_path
    
    def read_file(self, sandbox_path: str) -> str:
        normalized = sandbox_path.lstrip("/").replace("/", "\\")
        host_path = self.root / normalized
        if host_path.exists():
            return host_path.read_text()
        return ""
    
    def get_mount_args(self) -> List[str]:
        """获取挂载参数（供 Sandbox 使用）"""
        pass

    def file_exists(self, sandbox_path: str) -> bool:
        normalized = sandbox_path.lstrip("/").replace("/", "\\")
        host_path = self.root / normalized
        return host_path.exists()
    
    def build_command(self, command: List[str]) -> List[str]:
        pass
    
    def cleanup(self):
        import shutil
        if self.root.exists():
            shutil.rmtree(self.root)
