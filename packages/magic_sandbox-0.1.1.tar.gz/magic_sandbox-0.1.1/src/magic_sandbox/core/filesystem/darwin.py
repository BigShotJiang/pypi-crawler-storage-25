"""macOS 文件系统实现"""

from pathlib import Path
from typing import List

from .interface import FileSystem
from ...common.paths import to_host_path


class DarwinFileSystem(FileSystem):
    def __init__(self, root: Path):
        self.root = root
        self.workspace = "/workspace"
        self._create_layout()
    
    def _create_layout(self):
        """创建 macOS 沙箱目录结构"""
        directories = [
            "usr", "bin", "sbin", "etc",
            "var", "tmp",
            "workspace", "home",
        ]
        for d in directories:
            (self.root / d).mkdir(parents=True, exist_ok=True)
    
    def write_to_workspace(self, filename: str, content: str) -> Path:
        return self.write_file(f"{self.workspace}/{filename}", content)
    
    def write_file(self, sandbox_path: str, content: str) -> Path:
        host_path = to_host_path(self.root, sandbox_path)
        host_path.parent.mkdir(parents=True, exist_ok=True)
        host_path.write_text(content)
        return host_path
    
    def read_file(self, sandbox_path: str) -> str:
        host_path = to_host_path(self.root, sandbox_path)
        if host_path.exists():
            return host_path.read_text()
        return ""
    
    def file_exists(self, sandbox_path: str) -> bool:
        host_path = to_host_path(self.root, sandbox_path)
        return host_path.exists()
    
    def get_mount_args(self) -> List[str]:
        """获取挂载参数（供 Sandbox 使用）"""
        pass
    
    def build_command(self, command: List[str]) -> List[str]:
        pass
    
    def cleanup(self):
        import shutil
        if self.root.exists():
            shutil.rmtree(self.root)
