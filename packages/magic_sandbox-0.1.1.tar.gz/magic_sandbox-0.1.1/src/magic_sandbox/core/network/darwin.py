"""macOS 网络实现"""

from .interface import Network


class DarwinNetwork(Network):
    def __init__(self, allow_network: bool):
        self._allow = allow_network
    
    def is_allowed(self) -> bool:
        return self._allow
    
    def get_bwrap_args(self) -> list:
        # macOS 不使用 bwrap
        return []
