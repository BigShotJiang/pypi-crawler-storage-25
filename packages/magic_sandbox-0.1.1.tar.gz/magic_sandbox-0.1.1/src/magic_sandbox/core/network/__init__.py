"""网络管理模块"""
from .linux.manage import LinuxNetwork
from .darwin import DarwinNetwork
from .windows import WindowsNetwork

__all__ = ['LinuxNetwork', 'DarwinNetwork', 'WindowsNetwork']