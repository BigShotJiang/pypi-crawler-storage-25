

from typing import Optional

from magic_sandbox.core.network.interface import Network
from .linux.manage import LinuxNetwork
from .darwin import DarwinNetwork
from .windows import WindowsNetwork

networks = {
    "Linux": LinuxNetwork,
    "Darwin": DarwinNetwork,
    "Windows": WindowsNetwork,
}

class NetworkManager:
    """网络管理器，负责创建和管理网络模块实例"""
    
    @classmethod
    def get_network( allow_network: bool, platform_name: Optional[str]) -> Network:
        """根据平台名称和网络权限创建网络模块实例"""        
        return networks.get(platform_name, LinuxNetwork)(allow_network)