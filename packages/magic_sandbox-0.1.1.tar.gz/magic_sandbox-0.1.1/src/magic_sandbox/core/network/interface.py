"""网络抽象接口"""

from abc import ABC, abstractmethod


class Network(ABC):
    """网络管理接口"""
    
    @abstractmethod
    def __init__(self, allow_network: bool):
        pass
    
    @abstractmethod
    def is_allowed(self) -> bool:
        """是否允许网络访问"""
        pass
    
    @abstractmethod
    def get_bwrap_args(self) -> list:
        """获取 bwrap 网络参数（Linux）"""
        pass
