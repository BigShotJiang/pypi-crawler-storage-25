# magic_sandbox/core/network/linux/rule_manager.py

"""Linux 网络实现 - 支持白名单控制"""

import os
from pathlib import Path
from typing import List, Optional

from .rule_helper import IptableHelper


class RuleManager:
    """规则管理器
    
    负责管理网络白名单规则，生成 nftables 规则，并提供 bwrap 网络参数
    """
    
    def __init__(
        self,        
        manifest_path: Optional[Path] = None,
        enable_seccomp: bool = True,
    ):
        """初始化规则管理器
        
        Args:
            manifest_path: 网络白名单配置文件路径
            enable_seccomp: 是否启用 seccomp 过滤器
        """
        self._manifest_path = manifest_path
        self._enable_seccomp = enable_seccomp
        self._seccomp_fd: Optional[int] = None
        self._helper: Optional[IptableHelper] = IptableHelper(manifest_path)
        
        if manifest_path and manifest_path.exists():
            self._helper = IptableHelper(manifest_path)
    
    def is_allowed(self) -> bool:
        """检查是否允许网络访问
        
        Returns:
            是否允许网络访问
        """
        # return self._allow
        return False
    
    def get_bwrap_args(self) -> list:
        """获取 bwrap 网络隔离参数
        
        Returns:
            bwrap 命令行参数列表
        """
        args = []
        
        # if not self._allow:
        #     return ["--unshare-net"]
        
        args.extend(["--unshare-net"])
        args.extend(["--unshare-user"])
        args.extend(["--uid", "0"])
        args.extend(["--gid", "0"])
        args.extend(["--cap-add", "CAP_NET_ADMIN"])
        args.extend(["--cap-add", "CAP_NET_RAW"])
        args.extend(["--cap-drop", "ALL"])
        # args.extend(["--no-new-privs"])
        
        if self._enable_seccomp:
            self._setup_seccomp()
            if self._seccomp_fd:
                args.extend(["--seccomp", str(self._seccomp_fd)])
        
        return args
    
    def _setup_seccomp(self):
        """设置 seccomp 过滤器"""
        if not self._enable_seccomp:
            return
        
        seccomp_path = Path(__file__).parent / "scripts" / "seccomp.json"
        if seccomp_path.exists():
            self._seccomp_fd = os.open(seccomp_path, os.O_RDONLY)
    
    def get_nftables_rules(self) -> List[str]:
        """获取 nftables 规则列表
        
        Returns:
            nftables 规则命令列表
        """
        # if not self._allow or not self._helper:
        #     return []       
        
        
        # 使用 IptableHelper 生成完整的 iptables 配置脚本
        return self._helper.generate_rules()
        
    
    def get_drop_privilege_command(self, user_code_command: List[str]) -> List[str]:
        """获取降权执行命令
        
        使用 sudo 将进程降权为 nobody 用户执行
        
        Args:
            user_code_command: 用户命令列表
            
        Returns:
            降权执行命令列表
        """
        # if not self._allow:
        #     return user_code_command
        
        # 使用 setuid 降权
        return [
            "bash", "-c",
            f"exec sudo -u nobody {' '.join(user_code_command)}"
        ]
    
    def get_nftables_scripts(self) -> str:
        """获取网络配置命令        
        Returns:
            配置网络的命令字符串   
        """        
        
        # 生成 nftables 规则脚本内容
        return self._helper.generate_rule_script()
    
    def get_full_command(self, user_code_command: List[str]) -> List[str]:
        """获取完整的沙箱启动命令
        
        组合网络配置命令和用户命令，在同一个 shell 中依次执行
        
        Args:
            user_code_command: 用户命令列表
            
        Returns:
            完整的执行命令列表
        """
        # if not self._allow:
        #     return user_code_command
        
        # 组合：先配置网络，再执行用户代码
        config_cmd = self.get_network_config_command()
        if config_cmd:
            # 在同一个 shell 中依次执行
            combined = " && ".join([
                " ".join(config_cmd),
                " ".join(self.get_drop_privilege_command(user_code_command))
            ])
            return ["bash", "-c", combined]
        
        return user_code_command
    
    def cleanup(self):
        """清理资源
        
        关闭 seccomp 文件描述符
        """
        if self._seccomp_fd:
            os.close(self._seccomp_fd)
            self._seccomp_fd = None