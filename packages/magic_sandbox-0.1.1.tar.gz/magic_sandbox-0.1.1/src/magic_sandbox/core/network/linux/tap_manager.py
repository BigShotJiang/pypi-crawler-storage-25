# magic_sandbox/core/network/linux/tap_manager.py

import subprocess
import time
import signal
import os
from pathlib import Path
from typing import Optional


class TapManager:
    """使用 pasta 为沙箱网络命名空间提供网络（无 root）
    
    pasta 是一个用户态网络后端，无需 root 权限即可为网络命名空间提供网络连接。
    它通过 TAP 设备将沙箱内的网络流量转发到宿主机网络栈。
    """

    def __init__(self):
        """初始化 TAP 管理器"""
        self._pasta_proc: Optional[subprocess.Popen] = None
        """pasta 进程对象"""
        self._netns_pid: Optional[int] = None
        """目标网络命名空间的 PID"""
        self._nsenter_proc: Optional[subprocess.Popen] = None
        """nsenter 进程对象（预留）"""

    def setup(self, netns_pid: int) -> None:
        """为指定的网络命名空间 PID 配置网络（启动 pasta）
        
        使用 nsenter 进入目标网络命名空间，然后启动 pasta 进程。
        pasta 会自动创建 TAP 设备并配置网络接口。
        
        Args:
            netns_pid: 目标网络命名空间中的进程 PID
        """
        self._netns_pid = netns_pid
        # 使用 nsenter 进入该命名空间启动 pasta（解决多层用户命名空间问题）
        cmd = [
            "nsenter", "-t", str(netns_pid), "-n",
            "pasta", "--config-net", "--ns-ifname", "eth0"
        ]
        self._pasta_proc = subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True
        )
        # 等待网络设备创建
        time.sleep(0.3)

    def cleanup(self) -> None:
        """清理 pasta 进程
        
        终止 pasta 进程并释放相关资源。
        """
        if self._pasta_proc:
            # 终止整个进程组
            try:
                os.killpg(os.getpgid(self._pasta_proc.pid), signal.SIGTERM)
            except (ProcessLookupError, PermissionError):
                self._pasta_proc.terminate()
            self._pasta_proc.wait(timeout=2)
            self._pasta_proc = None
        self._netns_pid = None