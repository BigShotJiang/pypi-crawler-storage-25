# magic_sandbox/core/network/linux/manage.py
"""网络管理器 - 组合 rule_manager 和 tap_manager"""

import time
import subprocess
from pathlib import Path
from typing import List, Optional, TYPE_CHECKING

from magic_sandbox.core.network.linux.rule_helper import IptableHelper
from ..interface import Network
from .rule_manager import RuleManager
from .tap_manager import TapManager



class LinuxNetwork(Network):
    """
    网络管理器
    
    负责协调网络白名单（rule_manager）和网络连接（tap_manager）
    """
    
    def __init__(self, manifest_path: Optional[Path] = None):
        """
        初始化网络管理器
        
        Args:
            manifest_path: 网络白名单配置文件路径
        """
        self._manifest_path = manifest_path
        """配置文件路径"""
        self._rule_manager: Optional[RuleManager] = None
        """规则管理器实例，负责白名单规则生成"""
        self._tap_manager: Optional[TapManager] = None
        """TAP 管理器实例，负责 pasta 网络连接"""
        self._sandbox_pid: Optional[int] = None
        """沙箱进程 PID"""
        self._is_network_ready = False
        """网络是否就绪标志"""
        
        if manifest_path and manifest_path.exists():
            self._rule_manager = RuleManager(manifest_path)
            self._tap_manager = TapManager()
    
    def is_enabled(self) -> bool:
        """网络是否启用
        
        Returns:
            True 如果规则管理器和 TAP 管理器都已初始化，否则 False
        """
        return self._rule_manager is not None and self._tap_manager is not None
    
    def get_bwrap_args(self) -> List[str]:
        """
        获取 bwrap 网络参数
        
        Returns:
            bwrap 命令行参数列表
        """
        if not self.is_enabled():
            return ["--unshare-net"]
        
        # 由 rule_manager 提供 bwrap 参数
        return self._rule_manager.get_bwrap_args()
    def get_nftables_rules(self) -> List[str]:
        return self._rule_manager.get_nftables_rules() if self._rule_manager else []
    
    def get_nftables_scripts(self) -> str:
        return self._rule_manager.get_nftables_scripts() if self._rule_manager else ""

    def setup_network(self, sandbox_pid: int) -> None:
        """
        为沙箱配置网络
        
        执行顺序：
        1. 启动 pasta 提供网络连接
        2. 等待网络就绪
        3. 应用 nftables 白名单规则
        
        Args:
            sandbox_pid: 沙箱进程 PID
        """
        if not self.is_enabled():
            return
        
        self._sandbox_pid = sandbox_pid
        
        # 1. 启动 pasta 提供网络连接
        if self._tap_manager:
            self._tap_manager.setup(sandbox_pid)
        
        # 2. 等待网络就绪
        time.sleep(0.3)
        
        # 3. 应用 nftables 白名单规则
        self._apply_nftables_rules()
        
        self._is_network_ready = True
    
    def _apply_nftables_rules(self) -> None:
        """在沙箱网络命名空间中应用 nftables 白名单规则
        
        使用 nsenter 进入沙箱的网络命名空间，逐条执行 nftables 命令。
        规则中允许的流量会被放行，其他流量被默认策略拒绝。
        """
        if not self._rule_manager or not self._sandbox_pid:
            return
        
        rules = self._rule_manager.get_nftables_rules()
        if not rules:
            return
        
        # 使用 nsenter 进入沙箱的网络命名空间执行 nft 命令
        for rule in rules:
            if rule.startswith("#"):
                continue
            if not rule.strip():
                continue
            
            # 构建 nft 命令
            nft_cmd = ["nsenter", "-t", str(self._sandbox_pid), "-n", "nft"] + rule.split()
            
            try:
                subprocess.run(
                    nft_cmd,
                    capture_output=True,
                    text=True,
                    timeout=5,
                    check=False
                )
            except Exception:
                pass
    
    def wait_network_ready(self, timeout: float = 5.0) -> bool:
        """
        等待网络就绪
        
        Args:
            timeout: 超时时间（秒）
            
        Returns:
            网络是否就绪
        """
        start = time.time()
        while time.time() - start < timeout:
            if self._is_network_ready:
                return True
            time.sleep(0.1)
        return False
    
    def is_allowed(self) -> bool:
        """检查是否允许网络访问
        
        Returns:
            是否允许网络访问（当前始终返回 False）
        """
        # return self._allow
        return False
    
    def cleanup(self) -> None:
        """清理网络资源
        
        依次清理 TAP 管理器、规则管理器，并重置状态。
        """
        if self._tap_manager:
            self._tap_manager.cleanup()
        if self._rule_manager:
            self._rule_manager.cleanup()
        self._sandbox_pid = None
        self._is_network_ready = False