#!/usr/bin/env python3
# magic_sandbox/core/network/linux/rule_helper.py

"""generate_nftables.py - 根据 manifest.yaml 生成 nftables 脚本"""

import yaml
import subprocess
import ipaddress
from pathlib import Path
from typing import List, Dict, Set


class IptableHelper:
    """nftables 规则生成器
    
    根据 manifest.yaml 白名单配置生成 nftables 规则
    """
    
    def __init__(self, config_path: Path):
        """初始化规则生成器
        
        Args:
            config_path: manifest.yaml 配置文件路径
        """
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        self.whitelist = self.config.get('whitelist', {})
    
    def resolve_domain(self, domain: str) -> List[str]:
        """解析域名为 IP 列表
        
        Args:
            domain: 域名
            
        Returns:
            IP 地址列表，解析失败时返回空列表
        """
        try:
            result = subprocess.run(
                ["dig", "+short", domain],
                capture_output=True,
                text=True,
                check=True
            )
            ips = []
            for line in result.stdout.strip().split('\n'):
                if line and not line.startswith(';'):
                    try:
                        ipaddress.IPv4Address(line)
                        ips.append(line)
                    except ipaddress.AddressValueError:
                        pass
            return ips
        except subprocess.CalledProcessError:
            print(f"Warning: Failed to resolve domain {domain}")
            return []
    
    def generate_rules(self) -> List[str]:
        """生成 nftables 规则列表
        
        Returns:
            nftables 命令列表，每条命令为一个字符串
        """
        rules = []
        
        # 1. 创建表（如果不存在）
        rules.append("# 创建 nftables 表")
        rules.append("nft add table inet sandbox_filter 2>/dev/null || true")
        rules.append("")
        
        # 2. 清空现有规则（可选，用于调试）
        rules.append("# 清空现有规则（可选）")
        rules.append("nft flush table inet sandbox_filter 2>/dev/null || true")
        rules.append("")
        
        # 3. 创建基础链并设置默认策略：拒绝所有
        rules.append("# 默认策略：拒绝所有")
        rules.append("nft 'add chain inet sandbox_filter input { type filter hook input priority 0; policy drop; }' 2>/dev/null || true")
        rules.append("nft 'add chain inet sandbox_filter output { type filter hook output priority 0; policy drop; }' 2>/dev/null || true")
        rules.append("nft 'add chain inet sandbox_filter forward { type filter hook forward priority 0; policy drop; }' 2>/dev/null || true")
        rules.append("")
        
        # 4. 允许回环接口
        rules.append("# 允许本地回环")
        rules.append("nft add rule inet sandbox_filter input iif lo accept")
        rules.append("nft add rule inet sandbox_filter output oif lo accept")
        rules.append("")
        
        # 5. 允许已建立的连接
        rules.append("# 允许已建立的连接返回")
        rules.append("nft add rule inet sandbox_filter input ct state established,related accept")
        rules.append("nft add rule inet sandbox_filter output ct state established,related accept")
        rules.append("")
        
        # 6. DNS 规则
        dns_servers = self.whitelist.get('dns', [])
        if dns_servers:
            rules.append("# DNS 解析（UDP 53）")
            for dns in dns_servers:
                rules.append(f"nft add rule inet sandbox_filter output ip daddr {dns} udp dport 53 accept")
            rules.append("")
        
        # 7. 外部 IP 白名单（HTTPS）
        external_ips = self.whitelist.get('ips', [])
        if external_ips:
            rules.append("# 外部 IP 白名单（HTTPS 443）")
            for ip in external_ips:
                rules.append(f"nft add rule inet sandbox_filter output ip daddr {ip} tcp dport 443 accept")
            rules.append("")
        
        # 8. 外部域名白名单（解析后添加 HTTPS 规则）
        domains = self.whitelist.get('domains', [])
        if domains:
            rules.append("# 外部域名白名单（解析为 IP，HTTPS 443）")
            rules.append("# 注意：域名解析结果会动态添加，请确保 DNS 可访问")
            for domain in domains:
                ips = self.resolve_domain(domain)
                for ip in ips:
                    rules.append(f"nft add rule inet sandbox_filter output ip daddr {ip} tcp dport 443 accept")
                if not ips:
                    rules.append(f"# Warning: No IP resolved for {domain}")
            rules.append("")
        
        # 9. 内部服务白名单
        internal_services = self.whitelist.get('internal', [])
        if internal_services:
            rules.append("# 内部服务白名单")
            for svc in internal_services:
                addr = svc.get('addr')
                port = svc.get('port')
                protocol = svc.get('protocol', 'tcp')
                if addr and port:
                    rules.append(f"nft add rule inet sandbox_filter output ip daddr {addr} {protocol} dport {port} accept")
            rules.append("")
        
        return rules
    
    def generate_rule_script(self) -> str:
        """生成可执行的 nftables 配置脚本
        
        返回完整的 bash 脚本内容，包含 shebang 和规则执行后的确认信息。
        
        Returns:
            完整的 bash 脚本字符串
        """
        lines = ["#!/bin/bash", "# 自动生成的 nftables 白名单配置脚本", ""]
        
        rules = self.generate_rules()
        for rule in rules:
            lines.append(rule)
        
        lines.extend([
            "",
            "echo 'Network isolation configured successfully'"
        ])
        
        return "\n".join(lines)
    
    def generate_rules_only(self) -> str:
        """仅生成规则文本（不包含脚本头）
        
        Returns:
            nftables 命令文本，每条命令以换行分隔
        """
        return "\n".join(self.generate_rules())