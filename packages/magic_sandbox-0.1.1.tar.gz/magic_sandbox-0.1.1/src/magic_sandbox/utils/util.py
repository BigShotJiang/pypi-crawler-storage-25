

# 文件操作（代理）
from pathlib import Path

from magic_sandbox.core.filesystem.interface import FileSystem
from magic_sandbox.core.sandbox.interface import Sandbox


def write_to_workspace(fs: FileSystem, filename: str, content: str) -> Path:
    return fs.write_to_workspace(filename, content)

def read_file(fs: FileSystem, path: str) -> str:
    return fs.read_file(path)

def write_file(fs: FileSystem, path: str, content: str) -> Path:
    """写入文件到沙箱"""
    return fs.write_file(path, content)

def file_exists(fs: FileSystem, path: str) -> bool:
    """检查沙箱内文件是否存在"""
    return fs.file_exists(path)

def cleanup(fs: FileSystem, isolator: Sandbox):
    fs.cleanup()
    isolator.cleanup()