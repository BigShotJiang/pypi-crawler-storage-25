"""沙箱门面 - 对外统一接口"""

import platform
from pathlib import Path
from subprocess import CompletedProcess
from typing import List, Optional

from magic_sandbox.core.sandbox.interface import Sandbox

from .common.session import generate_session_id
from .common.config import get_default_base_dir

from .core.sandbox.manager import SandboxManager
from .platform import get_platform


class MagicSandbox:
    """跨平台沙箱门面"""
    
    def __init__(
        self,
        manifest_path: Optional[Path] = None,  # 新增参数
        session_id: Optional[str] = None,
        allow_network: bool = False,
        timeout_seconds: int = 30,
        auto_cleanup: bool = True,

    ):
        self.session_id = session_id or generate_session_id()
        self.timeout = timeout_seconds
        self.auto_cleanup = auto_cleanup
        
        self.manifest_path = manifest_path  # 存储 manifest_path 以便后续使用
        # 根目录
        self.root = get_default_base_dir() / self.session_id
        self.root.mkdir(parents=True, exist_ok=True)
        
        # 检测平台
        self._platform = get_platform()
        
        # 根据平台创建各模块实现
        
        self._iso = SandboxManager.get_sandbox(self._platform)
        
        # 初始化
        self._iso.setup(self.root, self.manifest_path)   
        
     
    def run(self, command: List[str]) -> CompletedProcess:
        """执行命令"""
        return self._iso.run(command, timeout=self.timeout)
    
    def get_filesystem(self):
        """获取文件系统接口"""
        return self._iso.get_filesystem()
    
    def cleanup(self):
        self.get_filesystem().cleanup()
        self._iso.cleanup()
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        if self.auto_cleanup:
            self.cleanup()


BubblewrapSandbox = MagicSandbox  # 向后兼容
