import platform
    
def get_platform() -> str:
    """获取当前平台"""
    # return platform.system()
    return 'linux'