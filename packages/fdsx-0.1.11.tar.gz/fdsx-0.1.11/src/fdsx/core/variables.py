import json
import re
import shlex
from pathlib import Path
from typing import Any

from fdsx.core.paths import parse_jsonpath
from fdsx.models.flow import Branch, Flow, ParallelState, State

# Sub-directory inside run_dir where result files are written
RESULT_FILE_DATA_DIR = "data"

# Global variables automatically available in every state (injected at runtime by the runner)
GLOBAL_TASK_VARS: set[str] = {"task", "source"}


def write_result_to_file(varname: str, value: Any, run_dir: Path) -> str:
    """Write a result value to a file inside <run_dir>/data/.

    - str values are written as ``<varname>.md``
    - All other values (dict, list, etc.) are JSON-serialized as ``<varname>.json``

    The ``data/`` directory is created automatically if it does not exist.
    Returns the absolute file path as a string.
    """
    data_dir = run_dir / RESULT_FILE_DATA_DIR
    data_dir.mkdir(parents=True, exist_ok=True)

    if isinstance(value, str):
        file_path = data_dir / f"{varname}.md"
        file_path.write_text(value, encoding="utf-8")
    else:
        file_path = data_dir / f"{varname}.json"
        file_path.write_text(
            json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    return str(file_path.resolve())


def resolve_template(template: str, variables: dict[str, Any]) -> str:
    """Resolve {variable} patterns in a template string.

    Only replaces registered variable names. Unknown {...} patterns
    are preserved as literals.
    """
    pattern = re.compile(r"\{([^}]+)\}")

    def replace_match(match: re.Match[str]) -> str:
        var_path = match.group(1)
        value = resolve_jsonpath(var_path, variables)
        if value is None:
            return match.group(0)
        if isinstance(value, (list, dict)):
            return json.dumps(value, indent=2, ensure_ascii=False)
        return str(value)

    return pattern.sub(replace_match, template)


def resolve_template_shell_safe(template: str, variables: dict[str, Any]) -> str:
    """Resolve {variable} patterns with shell-safe quoting of values.

    Each interpolated value is passed through shlex.quote() to prevent
    shell injection when the result is used in sh -c commands.
    Unknown {...} patterns are preserved as literals.
    """
    pattern = re.compile(r"\{([^}]+)\}")

    def replace_match(match: re.Match[str]) -> str:
        var_path = match.group(1)
        value = resolve_jsonpath(var_path, variables)
        if value is None:
            return match.group(0)
        if isinstance(value, (list, dict)):
            return shlex.quote(json.dumps(value, indent=2, ensure_ascii=False))
        return shlex.quote(str(value))

    return pattern.sub(replace_match, template)


def resolve_jsonpath(path: str, data: dict[str, Any]) -> Any:
    """Resolve a JSONPath-like path in data.

    Supports dot notation and array indexing.
    Example: 'reviews[0].summary', 'plan', 'items[2]'
    """
    if not path:
        return data

    path = path.strip()
    if path.startswith("$."):
        path = path[2:]

    current: Any = data

    parts = parse_jsonpath(path)

    for part in parts:
        if isinstance(current, dict):
            if part not in current:
                return None
            if isinstance(part, str):
                current = current[part]
            else:
                return None
        elif isinstance(current, list):
            if not isinstance(part, int):
                return None
            if part < 0 or part >= len(current):
                return None
            current = current[part]
        else:
            return None

    return current


def set_jsonpath(path: str, data: dict[str, Any], value: Any) -> dict[str, Any]:
    """Set a value at a JSONPath location.

    Creates nested structures as needed.
    """
    if not path:
        result: dict[str, Any] = {}
        result[""] = value
        return result

    if path.startswith("$."):
        path = path[2:]

    parts = parse_jsonpath(path)

    if not parts:
        result = {}
        result[""] = value
        return result

    if not data:
        data = {}

    result = dict(data)
    current: Any = result

    for i, part in enumerate(parts[:-1]):
        if isinstance(part, int):
            if not isinstance(current, list):
                raise ValueError(f"Cannot index into non-list at position {i}")
            if part < len(current):
                next_val = current[part]
                new_val = (
                    dict(next_val)
                    if isinstance(next_val, dict)
                    else list(next_val)
                    if isinstance(next_val, list)
                    else {}
                )
                current[part] = new_val
                current = new_val
            else:
                while len(current) <= part:
                    current.append({})
                current = current[part]
        else:
            if not isinstance(current, dict):
                raise ValueError(f"Cannot access dict key in non-dict at position {i}")
            if part not in current or not isinstance(current[part], (dict, list)):
                next_part = parts[i + 1] if i + 1 < len(parts) else parts[-1]
                current[part] = [] if isinstance(next_part, int) else {}
                current = current[part]
            else:
                next_val = current[part]
                new_val = (
                    dict(next_val) if isinstance(next_val, dict) else list(next_val)
                )
                current[part] = new_val
                current = new_val

    last_part = parts[-1]
    if isinstance(last_part, int):
        if not isinstance(current, list):
            raise ValueError("Cannot index into non-list at last position")
        while len(current) <= last_part:
            current.append(None)
        current[last_part] = value
    else:
        if not isinstance(current, dict):
            raise ValueError("Cannot set dict key in non-dict")
        current[last_part] = value

    return result


def _is_var_satisfied(var: str, available: set[str]) -> bool:
    """Check if a variable reference is satisfied by the available paths.

    Uses parsed JSONPath segments so both dot and bracket notation are handled.

    Rules:
    - Exact match: ``review`` satisfied by ``review``
    - Ancestor: ``review.decision`` satisfied by ``review`` (whole subtree provided)
    - Descendant: ``review`` satisfied by ``review.summary`` (parent object exists)
    - Bracket notation: ``reviews[0].summary`` satisfied by ``reviews``
    """
    var_parts = parse_jsonpath(var)
    for provided in available:
        prov_parts = parse_jsonpath(provided)
        # Exact match
        if var_parts == prov_parts:
            return True
        # Provided is ancestor: prov_parts is a proper prefix of var_parts
        if (
            len(prov_parts) < len(var_parts)
            and var_parts[: len(prov_parts)] == prov_parts
        ):
            return True
        # Provided is descendant: var_parts is a proper prefix of prov_parts
        if (
            len(var_parts) < len(prov_parts)
            and prov_parts[: len(var_parts)] == var_parts
        ):
            return True
    return False


def analyze_variable_references(
    flow: Flow, input_keys: set[str] | None = None
) -> list[str]:
    """Static analysis to detect unreachable variable references.

    Traces reachable states from start_at and checks that {variable}
    references in prompts correspond to a result_path set by a
    preceding state on at least one reachable path.
    """
    from fdsx.core.graph_utils import get_next_states

    errors: list[str] = []

    def get_prompt_variables(state: State | Branch) -> set[str]:
        variables: set[str] = set()
        from fdsx.models.flow import Branch, PassState, TaskState

        if isinstance(state, (TaskState, Branch)):
            prompt = state.prompt_template or ""
            command = state.command or ""
            prompt = prompt + " " + command
        elif isinstance(state, PassState):
            parts = []
            if state.parameters:
                for val in state.parameters.values():
                    if isinstance(val, str):
                        parts.append(val)
            prompt = " ".join(parts)
        else:
            return variables

        pattern = re.compile(r"\{([^}]+)\}")
        for match in pattern.finditer(prompt):
            var_path = match.group(1)
            # Preserve full path (strip only leading "$." JSONPath prefix if present)
            if var_path.startswith("$."):
                var_path = var_path[2:]
            variables.add(var_path)

        return variables

    def get_result_paths(state: State) -> set[str]:
        result_paths: set[str] = set()
        from fdsx.models.flow import ParallelState, PassState, TaskState

        if isinstance(state, TaskState):
            if state.result_path:
                path = state.result_path
                if path.startswith("$."):
                    path = path[2:]
                result_paths.add(path)  # full path, not just root key
            if state.extract and state.extract.result_path:
                path = state.extract.result_path
                if path.startswith("$."):
                    path = path[2:]
                result_paths.add(path)
            if state.result_file:
                path = state.result_file
                if path.startswith("$."):
                    path = path[2:]
                result_paths.add(path)
        elif isinstance(state, ParallelState):
            if state.result_path:
                path = state.result_path
                if path.startswith("$."):
                    path = path[2:]
                result_paths.add(path)  # full path, not just root key
            if state.result_file:
                path = state.result_file
                if path.startswith("$."):
                    path = path[2:]
                result_paths.add(path)
            # Do NOT register branch extract paths — they live inside
            # result array elements, not as top-level state variables.
        elif isinstance(state, PassState):
            if state.parameters:
                for key in state.parameters:
                    path = key
                    if path.startswith("$."):
                        path = path[2:]
                    result_paths.add(path)
            if state.aggregate and state.aggregate.result_path:
                path = state.aggregate.result_path
                if path.startswith("$."):
                    path = path[2:]
                result_paths.add(path)
        return result_paths

    reachable_states = set()
    state_queue = [flow.start_at]

    while state_queue:
        current = state_queue.pop(0)
        if current in reachable_states:
            continue
        if current == "$END":
            continue
        if current not in flow.states:
            errors.append(f"State '{current}' referenced but not defined")
            continue

        reachable_states.add(current)
        state = flow.states[current]
        next_states = get_next_states(state, include_end_sentinel=True)
        state_queue.extend(next_states - reachable_states)

    state_provides: dict[str, set[str]] = {}
    for state_name in reachable_states:
        state = flow.states[state_name]
        state_provides[state_name] = get_result_paths(state)

    predecessors: dict[str, set[str]] = {s: set() for s in reachable_states}
    for state_name in reachable_states:
        state = flow.states[state_name]
        next_states = get_next_states(state, include_end_sentinel=True)
        for next_state in next_states:
            if next_state in predecessors:
                predecessors[next_state].add(state_name)

    available_vars: dict[str, set[str]] = {s: set() for s in reachable_states}
    changed = True
    while changed:
        changed = False
        for state_name in reachable_states:
            preds = predecessors.get(state_name, set())
            new_vars = set()
            for pred in preds:
                new_vars.update(available_vars.get(pred, set()))
                new_vars.update(state_provides.get(pred, set()))
            if new_vars != available_vars[state_name]:
                available_vars[state_name] = new_vars
                changed = True

    # Seed all reachable states with CLI --input keys
    if input_keys:
        for state_name in reachable_states:
            available_vars[state_name] = available_vars[state_name] | input_keys

    # Seed all reachable states with global task variables (task, source)
    for state_name in reachable_states:
        available_vars[state_name] = available_vars[state_name] | GLOBAL_TASK_VARS

    for state_name in reachable_states:
        state = flow.states[state_name]
        prompt_vars = get_prompt_variables(state)

        if isinstance(state, ParallelState):
            for branch in state.branches:
                prompt_vars.update(get_prompt_variables(branch))

        for var in prompt_vars:
            if (
                not _is_var_satisfied(var, available_vars.get(state_name, set()))
                and state_name != flow.start_at
            ):
                errors.append(
                    f"State '{state_name}' references variable '{var}' "
                    f"but no preceding state sets a result_path for it"
                )

    return errors
