import zipfile

import numpy as np
import pytest

from matheel import similarity


class FakeModel:
    def encode(self, inputs, convert_to_numpy=True):
        _ = convert_to_numpy
        if isinstance(inputs, str):
            return np.asarray(_vectorize(inputs), dtype=float)
        return np.asarray([_vectorize(item) for item in inputs], dtype=float)


def _vectorize(text):
    value = text or ""
    return [
        float(sum(1 for char in value if char.isalpha())),
        float(sum(1 for char in value if char.isdigit())),
        float(len(value)),
    ]


def test_lexical_tokenizer_choices_are_exported():
    assert similarity.available_lexical_tokenizers() == ("raw", "parser")
    assert similarity.normalize_lexical_tokenizer("tree-sitter") == "parser"


def test_get_sim_list_uses_preprocessed_code(tmp_path, monkeypatch):
    pytest.importorskip("chonkie")
    monkeypatch.setattr(
        similarity,
        "load_backend_model",
        lambda model_name, vector_backend="auto", device="auto", similarity_function="cosine", pooling_method="mean", max_token_length=None: FakeModel(),
    )

    archive_path = tmp_path / "codes.zip"
    with zipfile.ZipFile(archive_path, "w") as archive:
        archive.writestr("a.py", "value = 1  # note")
        archive.writestr("b.py", "value = 1")

    raw_results = similarity.get_sim_list(
        archive_path,
        model_name="fake",
        threshold=0.0,
        number_results=10,
        feature_weights={"semantic": 0.0, "levenshtein": 1.0, "jaro_winkler": 0.0},
        vector_backend="sentence_transformers",
    )
    clean_results = similarity.get_sim_list(
        archive_path,
        model_name="fake",
        threshold=0.0,
        number_results=10,
        feature_weights={"semantic": 0.0, "levenshtein": 1.0, "jaro_winkler": 0.0},
        preprocess_mode="basic",
        chunking_method="chonkie_token",
        chunk_size=2,
        chunk_overlap=1,
        vector_backend="sentence_transformers",
    )

    assert raw_results.iloc[0]["similarity_score"] < 1.0
    assert clean_results.iloc[0]["similarity_score"] == 1.0


def test_get_sim_list_accepts_directory_source(tmp_path, monkeypatch):
    pytest.importorskip("chonkie")
    monkeypatch.setattr(
        similarity,
        "load_backend_model",
        lambda model_name, vector_backend="auto", device="auto", similarity_function="cosine", pooling_method="mean", max_token_length=None: FakeModel(),
    )

    source_dir = tmp_path / "codes"
    source_dir.mkdir()
    (source_dir / "a.py").write_text("value = 1  # note", encoding="utf-8")
    (source_dir / "b.py").write_text("value = 1", encoding="utf-8")
    (source_dir / ".DS_Store").write_text("ignore", encoding="utf-8")

    clean_results = similarity.get_sim_list(
        source_dir,
        model_name="fake",
        threshold=0.0,
        number_results=10,
        feature_weights={"semantic": 0.0, "levenshtein": 1.0, "jaro_winkler": 0.0},
        preprocess_mode="basic",
        chunking_method="chonkie_token",
        chunk_size=2,
        chunk_overlap=1,
        vector_backend="sentence_transformers",
    )

    assert len(clean_results) == 1
    assert clean_results.iloc[0]["file_name_1"] == "a.py"
    assert clean_results.iloc[0]["file_name_2"] == "b.py"
    assert clean_results.iloc[0]["similarity_score"] == 1.0


def test_get_sim_list_rejects_regular_file_source(tmp_path):
    source_file = tmp_path / "single.py"
    source_file.write_text("print(1)", encoding="utf-8")

    with pytest.raises(ValueError, match="directory or a ZIP archive"):
        similarity.get_sim_list(
            source_file,
            feature_weights={"levenshtein": 1.0},
            vector_backend="static_hash",
        )


def test_get_sim_list_validates_source_before_model_metadata_lookup(tmp_path, monkeypatch):
    source_file = tmp_path / "single.py"
    source_file.write_text("print(1)", encoding="utf-8")

    def fail_model_info(model_name):
        raise AssertionError(f"metadata lookup should not run for invalid source: {model_name}")

    monkeypatch.setattr(similarity, "load_hf_model_info", fail_model_info)

    with pytest.raises(ValueError, match="directory or a ZIP archive"):
        similarity.get_sim_list(
            source_file,
            feature_weights={"semantic": 1.0},
            vector_backend="auto",
        )


def test_get_sim_list_rejects_embedding_count_mismatch(tmp_path, monkeypatch):
    source_dir = tmp_path / "codes"
    source_dir.mkdir()
    (source_dir / "a.py").write_text("print(1)", encoding="utf-8")
    (source_dir / "b.py").write_text("print(2)", encoding="utf-8")

    monkeypatch.setattr(
        similarity,
        "load_backend_model",
        lambda model_name, vector_backend="auto", device="auto", similarity_function="cosine", pooling_method="mean", max_token_length=None: FakeModel(),
    )
    monkeypatch.setattr(
        similarity,
        "build_document_embeddings",
        lambda *args, **kwargs: [np.asarray([1.0, 0.0], dtype=float)],
    )

    with pytest.raises(ValueError, match="Embedding count"):
        similarity.get_sim_list(
            source_dir,
            model_name="fake",
            feature_weights={"semantic": 1.0},
            vector_backend="sentence_transformers",
        )


def test_calculate_similarity_supports_chunking(monkeypatch):
    pytest.importorskip("chonkie")
    monkeypatch.setattr(
        similarity,
        "load_backend_model",
        lambda model_name, vector_backend="auto", device="auto", similarity_function="cosine", pooling_method="mean", max_token_length=None: FakeModel(),
    )

    score = similarity.calculate_similarity(
        "def add(a, b):\n    total = a + b\n    return total\n",
        "def add(a, b):\n    total = a + b\n    return total\n",
        model_name="fake",
        feature_weights={"semantic": 1.0},
        chunking_method="chonkie_token",
        chunk_size=2,
        chunk_overlap=1,
        max_chunks=2,
        chunk_aggregation="mean",
        vector_backend="sentence_transformers",
    )

    assert score == pytest.approx(1.0)


def test_aggregate_chunk_embeddings_handles_empty_input():
    result = similarity.aggregate_chunk_embeddings([])

    assert result.shape == (1,)
    assert result[0] == 0.0


def test_calculate_similarity_supports_code_metric_without_semantic_weights(monkeypatch):
    monkeypatch.setattr(
        similarity,
        "load_backend_model",
        lambda model_name, vector_backend="auto", device="auto", similarity_function="cosine", pooling_method="mean", max_token_length=None: FakeModel(),
    )

    score = similarity.calculate_similarity(
        "int value = 1;",
        "int value = 1;",
        model_name="fake",
        feature_weights={"code_metric": 1.0},
        code_metric="codebleu",
        code_metric_weight=1.0,
        vector_backend="sentence_transformers",
    )

    assert score == pytest.approx(1.0)


def test_calculate_similarity_rejects_inactive_code_metric_weight():
    with pytest.raises(ValueError, match="code_metric_weight requires an active code_metric"):
        similarity.calculate_similarity(
            "abc",
            "abc",
            vector_backend="static_hash",
            feature_weights={"levenshtein": 1.0},
            code_metric="none",
            code_metric_weight=1.0,
        )


def test_calculate_similarity_rejects_code_metric_feature_without_metric():
    with pytest.raises(ValueError, match="code_metric_weight requires an active code_metric"):
        similarity.calculate_similarity(
            "abc",
            "abc",
            vector_backend="static_hash",
            feature_weights={"code_metric": 1.0},
            code_metric="none",
        )


def test_calculate_similarity_supports_custom_levenshtein_weights():
    default_score = similarity.calculate_similarity(
        "abcd",
        "abxcd",
        vector_backend="static_hash",
        feature_weights={"levenshtein": 1.0},
    )
    heavier_insertion_score = similarity.calculate_similarity(
        "abcd",
        "abxcd",
        vector_backend="static_hash",
        feature_weights={"levenshtein": 1.0},
        levenshtein_weights=(3, 1, 1),
    )

    assert heavier_insertion_score < default_score


def test_calculate_similarity_supports_custom_jaro_winkler_prefix_weight():
    default_score = similarity.calculate_similarity(
        "prefixAlpha",
        "prefixBeta",
        vector_backend="static_hash",
        feature_weights={"jaro_winkler": 1.0},
    )
    stronger_prefix_score = similarity.calculate_similarity(
        "prefixAlpha",
        "prefixBeta",
        vector_backend="static_hash",
        feature_weights={"jaro_winkler": 1.0},
        jaro_winkler_prefix_weight=0.25,
    )

    assert stronger_prefix_score > default_score


@pytest.mark.parametrize(
    "left,right,expected",
    [
        ("", "", 1.0),
        ("", "abc", 0.0),
        ("abc", "abc", 1.0),
        ("abc", "axc", 2.0 / 3.0),
        ("kitten", "sitting", 4.0 / 7.0),
    ],
)
def test_levenshtein_feature_has_reference_scores(left, right, expected):
    score = similarity.calculate_similarity(
        left,
        right,
        vector_backend="static_hash",
        feature_weights={"levenshtein": 1.0},
    )

    assert score == pytest.approx(expected)


@pytest.mark.parametrize(
    "left,right,expected",
    [
        ("", "", 1.0),
        ("abc", "xyz", 0.0),
        ("MARTHA", "MARHTA", 0.9611111111111111),
        ("DIXON", "DICKSONX", 0.8133333333333332),
    ],
)
def test_jaro_winkler_feature_has_reference_scores(left, right, expected):
    score = similarity.calculate_similarity(
        left,
        right,
        vector_backend="static_hash",
        feature_weights={"jaro_winkler": 1.0},
    )

    assert score == pytest.approx(expected)


def test_winnowing_similarity_handles_empty_and_reference_sets():
    assert similarity.winnowing_similarity_from_tokens([], []) == 1.0
    assert similarity.winnowing_similarity_from_tokens([], ["alpha"]) == 0.0
    assert (
        similarity.winnowing_similarity_from_tokens(
            ["alpha", "beta", "gamma"],
            ["alpha", "beta", "delta"],
            kgram_size=1,
            window_size=1,
        )
        == pytest.approx(0.5)
    )


def test_winnowing_kgram_controls_order_sensitivity():
    left = ["alpha", "beta", "gamma"]
    reordered = ["beta", "alpha", "gamma"]

    assert similarity.winnowing_similarity_from_tokens(
        left,
        reordered,
        kgram_size=1,
        window_size=1,
    ) == pytest.approx(1.0)
    assert similarity.winnowing_similarity_from_tokens(
        left,
        reordered,
        kgram_size=2,
        window_size=1,
    ) == pytest.approx(0.0)


def test_parser_derived_lexical_tokenizer_uses_syntax_token_types():
    pytest.importorskip("tree_sitter_language_pack")

    tokens = similarity.tokenize_for_lexical_matching(
        "def add(a, b):\n    return a + b\n",
        lexical_tokenizer="parser",
        code_language="python",
    )

    assert tokens == [
        "def",
        "identifier",
        "(",
        "identifier",
        ",",
        "identifier",
        ")",
        ":",
        "return",
        "identifier",
        "+",
        "identifier",
    ]


def test_parser_derived_winnowing_is_less_sensitive_to_identifier_renaming():
    pytest.importorskip("tree_sitter_language_pack")

    left = "def add(a, b):\n    total = a + b\n    return total\n"
    renamed = "def add(x, y):\n    answer = x + y\n    return answer\n"
    raw_score = similarity.calculate_similarity(
        left,
        renamed,
        feature_weights={"winnowing": 1.0},
        winnowing_kgram=2,
        winnowing_window=1,
        lexical_tokenizer="raw",
        code_language="python",
        vector_backend="static_hash",
    )
    parser_score = similarity.calculate_similarity(
        left,
        renamed,
        feature_weights={"winnowing": 1.0},
        winnowing_kgram=2,
        winnowing_window=1,
        lexical_tokenizer="parser",
        code_language="python",
        vector_backend="static_hash",
    )

    assert raw_score < 1.0
    assert parser_score == pytest.approx(1.0)


def test_parser_derived_gst_is_less_sensitive_to_identifier_renaming():
    pytest.importorskip("tree_sitter_language_pack")

    left = "def add(a, b):\n    total = a + b\n    return total\n"
    renamed = "def add(x, y):\n    answer = x + y\n    return answer\n"
    raw_score = similarity.calculate_similarity(
        left,
        renamed,
        feature_weights={"gst": 1.0},
        gst_min_match_length=2,
        lexical_tokenizer="raw",
        code_language="python",
        vector_backend="static_hash",
    )
    parser_score = similarity.calculate_similarity(
        left,
        renamed,
        feature_weights={"gst": 1.0},
        gst_min_match_length=2,
        lexical_tokenizer="parser",
        code_language="python",
        vector_backend="static_hash",
    )

    assert raw_score < 1.0
    assert parser_score == pytest.approx(1.0)


def test_gst_similarity_has_reference_token_accounting():
    assert similarity.gst_similarity_from_tokens([], []) == 1.0
    assert similarity.gst_similarity_from_tokens([], ["alpha"]) == 0.0
    assert similarity.gst_similarity_from_tokens(
        ["alpha", "beta", "gamma"],
        ["alpha", "beta", "gamma"],
        min_match_length=2,
    ) == pytest.approx(1.0)
    assert similarity.gst_similarity_from_tokens(
        ["alpha", "beta", "gamma", "delta", "epsilon"],
        ["zero", "beta", "gamma", "delta", "one"],
        min_match_length=2,
    ) == pytest.approx(0.6)


def test_gst_accepts_non_overlapping_tiles_once():
    left = ["alpha", "beta", "x", "gamma", "delta"]
    right = ["alpha", "beta", "y", "gamma", "delta"]

    assert similarity.gst_similarity_from_tokens(left, right, min_match_length=2) == pytest.approx(0.8)
    assert similarity.gst_similarity_from_tokens(left, right, min_match_length=3) == pytest.approx(0.0)


def test_calculate_similarity_supports_winnowing_feature():
    identical_score = similarity.calculate_similarity(
        "int total = value + 1;",
        "int total = value + 1;",
        feature_weights={"winnowing": 1.0},
        winnowing_kgram=3,
        winnowing_window=2,
    )
    different_score = similarity.calculate_similarity(
        "int total = value + 1;",
        "while (ready) { stop(); }",
        feature_weights={"winnowing": 1.0},
        winnowing_kgram=3,
        winnowing_window=2,
    )

    assert identical_score == pytest.approx(1.0)
    assert different_score < identical_score


def test_calculate_similarity_supports_gst_feature():
    related_score = similarity.calculate_similarity(
        "alpha beta gamma delta epsilon zeta",
        "zero beta gamma delta epsilon one",
        feature_weights={"gst": 1.0},
        gst_min_match_length=2,
    )
    unrelated_score = similarity.calculate_similarity(
        "alpha beta gamma delta epsilon zeta",
        "red blue green yellow",
        feature_weights={"gst": 1.0},
        gst_min_match_length=2,
    )

    assert related_score > 0.0
    assert unrelated_score < related_score


def test_calculate_similarity_skips_embedding_loading_without_semantic_feature(monkeypatch):
    monkeypatch.setattr(
        similarity,
        "load_backend_model",
        lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("Embeddings should not be loaded.")),
    )
    monkeypatch.setattr(
        similarity,
        "load_hf_model_info",
        lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("Model metadata should not be loaded.")),
    )

    score = similarity.calculate_similarity(
        "int total = value + 1;",
        "int total = value + 1;",
        feature_weights={"winnowing": 1.0},
        vector_backend="auto",
    )

    assert score == pytest.approx(1.0)


def test_get_sim_list_skips_embedding_loading_without_semantic_feature(tmp_path, monkeypatch):
    monkeypatch.setattr(
        similarity,
        "load_backend_model",
        lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("Embeddings should not be loaded.")),
    )
    monkeypatch.setattr(
        similarity,
        "load_hf_model_info",
        lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("Model metadata should not be loaded.")),
    )

    source_dir = tmp_path / "codes"
    source_dir.mkdir()
    (source_dir / "a.py").write_text("alpha beta gamma delta", encoding="utf-8")
    (source_dir / "b.py").write_text("alpha beta gamma epsilon", encoding="utf-8")

    results = similarity.get_sim_list(
        source_dir,
        threshold=0.0,
        number_results=5,
        feature_weights={"gst": 1.0},
        vector_backend="auto",
        gst_min_match_length=2,
    )

    assert len(results) == 1


def test_get_sim_list_reports_progress_events(tmp_path):
    source_dir = tmp_path / "codes"
    source_dir.mkdir()
    (source_dir / "a.py").write_text("alpha beta", encoding="utf-8")
    (source_dir / "b.py").write_text("alpha gamma", encoding="utf-8")
    (source_dir / "c.py").write_text("delta gamma", encoding="utf-8")
    events = []

    results = similarity.get_sim_list(
        source_dir,
        threshold=0.0,
        number_results=5,
        feature_weights={"levenshtein": 1.0},
        vector_backend="auto",
        progress_callback=events.append,
    )

    prepare_events = [event for event in events if event["stage"] == "prepare_files"]
    pair_events = [event for event in events if event["stage"] == "compare_pairs"]
    assert prepare_events[0] == {
        "stage": "prepare_files",
        "current": 0,
        "total": 3,
        "message": "Prepare files",
    }
    assert prepare_events[-1]["current"] == 3
    assert pair_events[0]["current"] == 0
    assert pair_events[0]["total"] == 3
    assert pair_events[-1]["current"] == 3
    assert results.attrs["elapsed_seconds"] >= 0.0
    assert results.attrs["feature_set"] == "levenshtein"
    assert results.attrs["vector_backend"] == "inactive"
    assert results.attrs["code_metric"] == "none"
    assert results.attrs["chunking_method"] == "none"


def test_get_sim_list_keeps_vector_backend_metadata_when_semantic_is_active(tmp_path, monkeypatch):
    monkeypatch.setattr(
        similarity,
        "load_backend_model",
        lambda model_name, vector_backend="auto", device="auto", similarity_function="cosine", pooling_method="mean", max_token_length=None: FakeModel(),
    )

    source_dir = tmp_path / "codes"
    source_dir.mkdir()
    (source_dir / "a.py").write_text("alpha beta", encoding="utf-8")
    (source_dir / "b.py").write_text("alpha gamma", encoding="utf-8")

    results = similarity.get_sim_list(
        source_dir,
        model_name="fake",
        threshold=0.0,
        number_results=5,
        feature_weights={"semantic": 1.0},
        vector_backend="sentence_transformers",
    )

    assert results.attrs["feature_set"] == "semantic"
    assert results.attrs["vector_backend"] == "sentence_transformers"


def test_calculate_similarity_reports_progress_events():
    events = []

    similarity.calculate_similarity(
        "alpha beta",
        "alpha gamma",
        feature_weights={"levenshtein": 1.0},
        vector_backend="auto",
        progress_callback=events.append,
    )

    assert any(event["stage"] == "prepare_snippets" for event in events)
    pair_events = [event for event in events if event["stage"] == "compare_pairs"]
    assert pair_events[-1]["current"] == 1
    assert pair_events[-1]["total"] == 1


def test_calculate_similarity_supports_static_hash_backend():
    score = similarity.calculate_similarity(
        "def add(a, b):\n    return a + b\n",
        "def add(b, a):\n    return b + a\n",
        feature_weights={"semantic": 1.0},
        vector_backend="static_hash",
        static_vector_dim=64,
    )

    assert score == pytest.approx(1.0)


def test_calculate_similarity_supports_alternative_similarity_functions():
    dot_score = similarity.calculate_similarity(
        "def add(a, b):\n    return a + b\n",
        "def add(a, b):\n    return a + b\n",
        feature_weights={"semantic": 1.0},
        vector_backend="static_hash",
        similarity_function="dot",
        static_vector_dim=64,
    )
    euclidean_score = similarity.calculate_similarity(
        "def add(a, b):\n    return a + b\n",
        "def add(a, b):\n    return a + b\n",
        feature_weights={"semantic": 1.0},
        vector_backend="static_hash",
        similarity_function="euclidean",
        static_vector_dim=64,
    )

    assert dot_score == pytest.approx(1.0)
    assert euclidean_score == pytest.approx(0.0)


def test_calculate_similarity_normalizes_semantic_scores_when_requested():
    raw_score = similarity.calculate_similarity(
        "def add(a, b):\n    return a + b\n",
        "def add(a, b):\n    return a + b\n",
        feature_weights={"semantic": 1.0},
        vector_backend="static_hash",
        similarity_function="euclidean",
        static_vector_dim=64,
    )
    normalized_score = similarity.calculate_similarity(
        "def add(a, b):\n    return a + b\n",
        "def add(a, b):\n    return a + b\n",
        feature_weights={"semantic": 1.0},
        vector_backend="static_hash",
        similarity_function="euclidean",
        static_vector_dim=64,
        normalize_semantic_scores=True,
    )

    assert raw_score == pytest.approx(0.0)
    assert normalized_score == pytest.approx(1.0)


def test_calculate_similarity_guards_raw_distance_scores_in_weighted_blends():
    with pytest.raises(ValueError, match="normalize_semantic_scores"):
        similarity.calculate_similarity(
            "def add(a, b):\n    return a + b\n",
            "def add(a, b):\n    return a + b\n",
            feature_weights={"semantic": 0.5, "levenshtein": 0.5},
            vector_backend="static_hash",
            similarity_function="euclidean",
            static_vector_dim=64,
        )

    score = similarity.calculate_similarity(
        "def add(a, b):\n    return a + b\n",
        "def add(a, b):\n    return a + b\n",
        feature_weights={"semantic": 0.5, "levenshtein": 0.5},
        vector_backend="static_hash",
        similarity_function="euclidean",
        static_vector_dim=64,
        normalize_semantic_scores=True,
    )

    assert score == pytest.approx(1.0)


def test_calculate_similarity_reports_missing_semantic_dependency(monkeypatch):
    def missing_model(*args, **kwargs):
        _ = (args, kwargs)
        raise ImportError("No module named 'sentence_transformers'")

    monkeypatch.setattr(similarity, "load_vector_model", missing_model)

    with pytest.raises(ImportError, match=r"matheel\[semantic\]"):
        similarity.calculate_similarity(
            "def add(a, b):\n    return a + b\n",
            "def add(b, a):\n    return b + a\n",
            feature_weights={"semantic": 1.0},
            vector_backend="sentence_transformers",
        )


def test_model2vec_backend_does_not_fall_back_to_static_hash(monkeypatch):
    def missing_model(*args, **kwargs):
        _ = (args, kwargs)
        raise ImportError("No module named 'model2vec'")

    monkeypatch.setattr(similarity, "load_vector_model", missing_model)

    with pytest.raises(ImportError, match="model2vec"):
        similarity.calculate_similarity(
            "def add(a, b):\n    return a + b\n",
            "def add(b, a):\n    return b + a\n",
            model_name="Jarbas/m2v-256-paraphrase-multilingual-MiniLM-L12-v2",
            feature_weights={"semantic": 1.0},
            vector_backend="model2vec",
            static_vector_dim=64,
        )


def test_model2vec_embeddings_require_loaded_model():
    with pytest.raises(ValueError, match="static_hash"):
        similarity.build_document_embeddings(None, ["print(1)"], vector_backend="model2vec")


def test_calculate_similarity_supports_multivector_backend(monkeypatch):
    monkeypatch.setattr(
        similarity,
        "load_backend_model",
        lambda model_name, vector_backend="auto", device="auto", similarity_function="cosine", pooling_method="mean", max_token_length=None: FakeModel(),
    )

    score = similarity.calculate_similarity(
        "def normalize(name):\n    return name.strip().lower()\n",
        "def normalize(name):\n    return name.strip().lower()\n",
        model_name="fake",
        feature_weights={"semantic": 1.0},
        vector_backend="pylate",
    )

    assert score == pytest.approx(1.0)


def test_calculate_similarity_normalizes_custom_feature_weights(monkeypatch):
    monkeypatch.setattr(
        similarity,
        "load_backend_model",
        lambda model_name, vector_backend="auto", device="auto", similarity_function="cosine", pooling_method="mean", max_token_length=None: FakeModel(),
    )

    score = similarity.calculate_similarity(
        "public int square(int value) {\n    return value * value;\n}\n",
        "public int square(int value) {\n    return value * value;\n}\n",
        model_name="fake",
        vector_backend="sentence_transformers",
        feature_weights={"semantic": 3.0, "levenshtein": 1.0},
    )

    assert score == pytest.approx(1.0)


def test_calculate_similarity_passes_similarity_and_pooling_to_loader(monkeypatch):
    captured = {}

    def fake_load_backend_model(
        model_name,
        vector_backend="auto",
        device="auto",
        similarity_function="cosine",
        pooling_method="mean",
        max_token_length=None,
    ):
        captured["similarity_function"] = similarity_function
        captured["pooling_method"] = pooling_method
        captured["max_token_length"] = max_token_length
        return FakeModel()

    monkeypatch.setattr(similarity, "load_backend_model", fake_load_backend_model)
    monkeypatch.setattr(similarity, "configure_sentence_transformer_pooling", lambda model, pooling_method="mean": model)

    score = similarity.calculate_similarity(
        "def clean_name(name):\n    return name.strip().lower()\n",
        "def clean_name(name):\n    return name.strip().lower()\n",
        model_name="fake",
        feature_weights={"semantic": 1.0},
        vector_backend="sentence_transformers",
        similarity_function="manhattan",
        pooling_method="max",
    )

    assert score == 0.0
    assert captured["similarity_function"] == "manhattan"
    assert captured["pooling_method"] == "max"
    assert captured["max_token_length"] is None


def test_inspect_model_settings_reports_detected_and_configured_max_token_length(monkeypatch):
    monkeypatch.setattr(similarity, "load_hf_model_info", lambda model_name: None)
    monkeypatch.setattr(similarity, "detect_model_max_token_length", lambda model=None, model_name=None, default=512: 256)

    settings = similarity.inspect_model_settings(
        "sentence-transformers/all-MiniLM-L6-v2",
        vector_backend="sentence_transformers",
        device="cpu",
        similarity_function="dot",
        pooling_method="max",
        max_token_length=512,
    )

    assert settings["resolved_vector_backend"] == "sentence_transformers"
    assert settings["runtime_device"] == "cpu"
    assert settings["similarity_function"] == "dot"
    assert settings["pooling_method"] == "max"
    assert settings["detected_max_token_length"] == 256
    assert settings["configured_max_token_length"] == 256
    assert settings["supports_custom_max_token_length"] is True


def test_get_sim_list_auto_backend_uses_routing(tmp_path, monkeypatch):
    monkeypatch.setattr(
        similarity,
        "load_backend_model",
        lambda model_name, vector_backend="auto", device="auto", similarity_function="cosine", pooling_method="mean", max_token_length=None: FakeModel(),
    )
    monkeypatch.setattr(similarity, "load_hf_model_info", lambda model_name: object())
    monkeypatch.setattr(
        similarity,
        "validate_vector_options",
        lambda vector_backend, static_vector_dim, model_name=None, model_info=None: ("sentence_transformers", 256),
    )

    source_dir = tmp_path / "codes"
    source_dir.mkdir()
    (source_dir / "a.py").write_text("print(1)", encoding="utf-8")
    (source_dir / "b.py").write_text("print(1)", encoding="utf-8")

    results = similarity.get_sim_list(
        source_dir,
        model_name="sentence-transformers/all-MiniLM-L6-v2",
        threshold=0.0,
        number_results=5,
        feature_weights={"semantic": 1.0},
        vector_backend="auto",
    )

    assert len(results) == 1


def test_detect_default_device_prefers_mps_when_cuda_is_unavailable(monkeypatch):
    class FakeMPS:
        @staticmethod
        def is_available():
            return True

    class FakeCUDA:
        @staticmethod
        def is_available():
            return False

    class FakeBackends:
        mps = FakeMPS()

    class FakeTorch:
        cuda = FakeCUDA()
        backends = FakeBackends()

    monkeypatch.setattr(similarity, "load_torch", lambda: FakeTorch())

    assert similarity.detect_default_device() == "mps"
    assert similarity.normalize_device("auto") == "mps"


def test_normalize_device_rejects_unavailable_accelerator(monkeypatch):
    class FakeMPS:
        @staticmethod
        def is_available():
            return False

    class FakeCUDA:
        @staticmethod
        def is_available():
            return False

    class FakeBackends:
        mps = FakeMPS()

    class FakeTorch:
        cuda = FakeCUDA()
        backends = FakeBackends()

    monkeypatch.setattr(similarity, "load_torch", lambda: FakeTorch())

    try:
        similarity.normalize_device("mps")
    except ValueError as exc:
        assert "not available" in str(exc)
    else:
        raise AssertionError("Expected normalize_device to reject unavailable mps.")
