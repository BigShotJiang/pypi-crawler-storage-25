# Author: Axel Arnaud
# Licence: BSD-3-Clause
# Copyright: Axel Arnaud
import logging

import crowsetta

from . import log
from .corpus import Corpus
from config import Config
from .formats.marron1csv import Marron1CSV

crowsetta.register_format(Marron1CSV)

logging.basicConfig(level=logging.INFO)
