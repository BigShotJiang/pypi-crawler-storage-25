import importlib.util
import os
import pathlib
import sys
from typing import Any
from .core import ExecutionContext, WorkflowReturnSignal

class SubworkflowLoader:
    """
    Loads and executes other workflows as sub-routines.
    This is the core engine for V3's modular architecture.
    """
    def __init__(self, execution_root: pathlib.Path | str = "workflows"):
        root = pathlib.Path(execution_root)
        if root.name == "workflows":
            self.execution_root = root.parent if root.parent != pathlib.Path("") else pathlib.Path.cwd()
            self.workflows_dir = root
        else:
            self.execution_root = root
            self.workflows_dir = root / "workflows"
        self._cache = {}
        self._call_stack: list[str] = []

    async def execute(self, workflow_id: str, parent_ctx: ExecutionContext, input_value: Any) -> Any:
        """
        Executes a subworkflow by ID.
        
        Args:
            workflow_id: The ID/filename of the subworkflow (w/o extension).
            parent_ctx: The context of the caller (used to inherit config/secrets).
            input_value: Value to pass to the child workflow trigger payload.
            
        Returns:
            Value returned by the child workflow's Return node, or None.
        """
        if workflow_id in self._call_stack:
            raise ValueError(
                f"Circular subworkflow reference detected: {workflow_id} in stack {self._call_stack}"
            )

        self._call_stack.append(workflow_id)
        try:
            module = self._load_module(workflow_id)

            child_payload = self._normalize_input_payload(input_value)

            child_ctx = ExecutionContext(
                workflow_id=workflow_id,
                execution_id=parent_ctx.execution_id,
                inputs=child_payload,
                secrets=parent_ctx._secrets,
                state_manager=parent_ctx._state,
            )
            child_ctx._is_subworkflow = True

            if not hasattr(module, "run"):
                raise ValueError(
                    f"Subworkflow {workflow_id} does not export 'run(ctx, injected_payload=None)'"
                )

            try:
                return await module.run(child_ctx, injected_payload=child_payload)
            except WorkflowReturnSignal as signal:
                return signal.value
        finally:
            self._call_stack.pop()

    def _normalize_input_payload(self, input_value: Any) -> dict[str, Any]:
        if isinstance(input_value, dict):
            envelope_keys = {"body", "headers", "query", "path", "method"}
            if "body" in input_value and envelope_keys.issubset(input_value.keys()):
                return {
                    "body": input_value.get("body"),
                    "headers": input_value.get("headers") or {},
                    "query": input_value.get("query") or {},
                    "path": input_value.get("path") or "",
                    "method": input_value.get("method") or "INTERNAL",
                }

        return {
            "body": input_value,
            "headers": {},
            "query": {},
            "path": "",
            "method": "INTERNAL",
        }

    def _load_module(self, workflow_id: str):
        """Dynamic import of the generated python file."""
        if workflow_id in self._cache:
            return self._cache[workflow_id]
            
        # Security Check: Prevent directory traversal
        if ".." in workflow_id or "/" in workflow_id or "\\" in workflow_id:
             raise ValueError(f"Invalid workflow ID: {workflow_id}")

        file_path = os.path.join(str(self.workflows_dir), f"{workflow_id}.py")
        
        if not os.path.exists(file_path):
             # Try resolving absolute path if provided dir was relative
             abs_path = os.path.abspath(file_path)
             if not os.path.exists(abs_path):
                 raise FileNotFoundError(f"Subworkflow file not found: {file_path}")
             file_path = abs_path

        spec = importlib.util.spec_from_file_location(f"subflow_{workflow_id}", file_path)
        if spec is None or spec.loader is None:
             raise ImportError(f"Could not load spec for {workflow_id}")
             
        module = importlib.util.module_from_spec(spec)
        sys.modules[f"subflow_{workflow_id}"] = module
        spec.loader.exec_module(module)
        
        self._cache[workflow_id] = module
        return module
