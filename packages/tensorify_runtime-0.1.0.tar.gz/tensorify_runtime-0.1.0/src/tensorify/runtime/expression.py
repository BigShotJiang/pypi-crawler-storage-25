from RestrictedPython import compile_restricted, safe_globals, utility_builtins
from typing import Any, Dict

def safe_eval(expression: str, context: Dict[str, Any]) -> Any:
    """
    Safely evaluate a Python expression within a context.
    
    Security:
    - No imports
    - No disk access
    - No dunder (__) access
    
    Args:
        expression: Python expression string (e.g. "a > 10")
        context: Dictionary of variables available to the expression
    
    Returns:
        The result of the expression
    """
    if not expression or not expression.strip():
        return None
        
    try:
        # Prepare restricted execution environment
        loc = {}
        
        # Helper for RestrictedPython subscript access
        def _getitem_(obj, index):
            return obj[index]
            
        def _getattr_(obj, name):
            if isinstance(obj, dict) and name in obj:
                return obj[name]
            return getattr(obj, name)
            
        def _getiter_(obj):
            return iter(obj)

        # Combine safe builtins with user context
        glob = safe_globals.copy()
        glob.update(utility_builtins)
        glob["_getitem_"] = _getitem_
        glob["_getattr_"] = _getattr_
        glob["_getiter_"] = _getiter_
        glob.update(context)
        
        # Compile expression (eval mode)
        code = compile_restricted(expression, '<string>', 'eval')
        
        # Execute
        result = eval(code, glob, loc)
        return result
        
    except Exception as e:
        raise ValueError(f"Expression evaluation failed: {expression}. Error: {str(e)}")
