from abc import ABC, abstractmethod
import json
import os
import sqlite3
from typing import Any, Dict, Optional

class StateManager(ABC):
    """
    Interface for persistent state storage.
    Used by workflows to store data that survives restarts/crashes.
    """
    
    @abstractmethod
    def set(self, workflow_id: str, key: str, value: Any):
        pass
    
    @abstractmethod
    def get(self, workflow_id: str, key: str, default: Any = None) -> Any:
        pass
    
    @abstractmethod
    def delete(self, workflow_id: str, key: str):
        pass
    
    @abstractmethod
    def get_all(self, workflow_id: str) -> Dict[str, Any]:
        pass

class SQLiteStateManager(StateManager):
    """
    Production-ready local state storage using SQLite.
    Stores values as JSON strings.
    """
    
    def __init__(self, db_path: str = ".tensorify/state.db"):
        self.db_path = db_path
        self._init_db()
    
    def _init_db(self):
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        conn = sqlite3.connect(self.db_path)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS state (
                workflow_id TEXT,
                key TEXT,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (workflow_id, key)
            )
        """)
        conn.commit()
        conn.close()
    
    def set(self, workflow_id: str, key: str, value: Any):
        conn = sqlite3.connect(self.db_path)
        try:
            serialized_value = json.dumps(value)
            conn.execute(
                """
                INSERT OR REPLACE INTO state (workflow_id, key, value) 
                VALUES (?, ?, ?)
                """,
                (workflow_id, key, serialized_value)
            )
            conn.commit()
        finally:
            conn.close()
    
    def get(self, workflow_id: str, key: str, default: Any = None) -> Any:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute(
                "SELECT value FROM state WHERE workflow_id = ? AND key = ?",
                (workflow_id, key)
            )
            row = cursor.fetchone()
            if row:
                return json.loads(row[0])
            return default
        finally:
            conn.close()
            
    def delete(self, workflow_id: str, key: str):
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute(
                "DELETE FROM state WHERE workflow_id = ? AND key = ?",
                (workflow_id, key)
            )
            conn.commit()
        finally:
            conn.close()

    def get_all(self, workflow_id: str) -> Dict[str, Any]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute(
                "SELECT key, value FROM state WHERE workflow_id = ?",
                (workflow_id,)
            )
            result = {}
            for key, value_json in cursor.fetchall():
                result[key] = json.loads(value_json)
            return result
        finally:
            conn.close()
