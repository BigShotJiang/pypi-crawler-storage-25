import os
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Optional, Protocol, runtime_checkable
import uuid
import datetime

from .state import StateManager, SQLiteStateManager
from .expression import safe_eval
import json
import importlib.util
import sys
import aiohttp

class WorkflowReturnSignal(Exception):
    """Sentinel exception used to propagate a subworkflow result."""
    def __init__(self, value: Any):
        self.value = value

@dataclass
class PluginOutput:
    """
    Standard output from any plugin execution.
    """
    status: str = "success"  # "success" | "error"
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

@runtime_checkable
class ActionPluginV3(Protocol):
    """
    Protocol for V3 Action Plugins.
    All plugins must implement a 'run' function matching this signature.
    """
    async def run(self, ctx: "ExecutionContext", inputs: Dict[str, Any]) -> PluginOutput:
        pass

class EventSource(ABC):
    """
    Base class for Trigger Plugins.
    """
    def __init__(self):
        self._handlers = []

    def on_event(self, handler):
        """Register an async handler function."""
        self._handlers.append(handler)

    async def emit(self, event_data: Any) -> list:
        """Call all registered handlers with event data and return their results."""
        results = []
        for h in self._handlers:
            result = await h(event_data)
            results.append(result)
        return results

    @abstractmethod
    async def start(self):
        """Start the event loop / listener."""
        pass

    @abstractmethod
    async def stop(self):
        """Stop the listener."""
        pass

class ExecutionContext:
    """
    The Runtime Context passed to every node execution.
    Provides safe access to:
    - Inputs (from Trigger)
    - Secrets (Env/Vault)
    - State (Persistence)
    - Variables (Runtime Data Flow)
    """

    def __init__(
        self,
        workflow_id: str,
        execution_id: str,
        inputs: Dict[str, Any] = None,
        secrets: Optional[Dict[str, str]] = None,
        state_manager: Optional[StateManager] = None,
    ):
        self.workflow_id = workflow_id
        # The compiler still emits placeholder execution IDs like "local" or "event"
        # for generated entrypoints. Prefer the runner-provided run ID when available
        # so snapshots and job audit trails attach to the actual execution record.
        self.execution_id = os.environ.get("TENSORIFY_RUN_ID") or execution_id
        self.inputs = inputs or {}
        
        # Security: Use provided secrets dict or fall back to os.environ
        # In production, this should be restricted.
        self._secrets = secrets if secrets is not None else os.environ
        
        self._state = state_manager or SQLiteStateManager()
        
        # Runtime Variables (The "Universal Editor" Data Bus)
        # Key = Node ID or Variable Name, Value = Any
        self._variables: Dict[str, Any] = {}
        
        # Workflow Return Value (for Webhooks/Sync executions)
        self._return_value = None
        self._is_subworkflow = False

    # === Secrets ===
    def get_secret(self, key: str) -> Optional[str]:
        """Securely retrieve a secret."""
        # TODO: Add audit logging here (Who accessed what?)
        return self._secrets.get(key)
    
    # === State (Persistent) ===
    def set_state(self, key: str, value: Any):
        """Store data that survives workflow restarts."""
        self._state.set(self.workflow_id, key, value)
        
    def get_state(self, key: str, default: Any = None) -> Any:
        """Retrieve persistent data."""
        return self._state.get(self.workflow_id, key, default)

    # === Variables (Transient / Data Flow) ===
    def set_var(self, key: str, value: Any):
        """
        Store a runtime variable.
        Used by the Compiler to store Node Outputs.
        """
        # DEBUG: Print variable update
        val_str = str(value)
        truncated_val = val_str[:150] + "..." if len(val_str) > 150 else val_str
        print(f"[Runtime] [VAR] Setting {key} = {truncated_val}", flush=True)

        self._variables[key] = value
        print(f"[Runtime] [CTX] Available Variables: {list(self._variables.keys())}", flush=True)
        # Auto-persist interaction outputs for "Time Travel" / "IntelliSense"
        # We only persist if it's JSON-serializable (which most plugin outputs are)
        try:
             self._state.set(self.workflow_id, f"var_{key}", value)
             
             # HYBRID TEST MODE SNAPSHOT
             execution_mode = os.environ.get("TENSORIFY_EXECUTION_MODE", "serve")
             if os.environ.get("TENSORIFY_TEST_MODE") == "true" or execution_mode == "invoke":
                 current_node_id = getattr(self, "_current_node_id", None)
                 current_inputs = getattr(self, "_current_node_inputs", None)
                 # Inherit inputs if it's the node's primary output OR a friendly alias set during its execution
                 snapshot_inputs = current_inputs if (current_node_id == key or current_node_id is not None) else None
                 SnapshotCapturer.capture_async(self, key, value, snapshot_inputs)
                 
        except Exception as e:
             print(f"[Runtime] State Error/Snapshot Failed: {e}", flush=True)
             # Ignore serialization errors for non-persistable objects
             pass


        
    def get_var(self, key: str, default: Any = None) -> Any:
        """
        Retrieve a runtime variable.
        Used by Nodes to access upstream data.
        """
        return self._variables.get(key, default)
    
    # === Expressions ===
    def eval(self, expression: str) -> Any:
        """
        Safely evaluate a TSL expression.
        Context includes: inputs, vars, state.
        """
        eval_context = {
            "input": self.inputs,
            "inputs": self.inputs,
            "vars": self._variables,
            "state": self._state.get_all(self.workflow_id)
        }
        # Flatten variables for direct access (e.g. loop iterators)
        eval_context.update(self._variables)

        # Helper for accessing variables with invalid python identifiers (e.g. UUIDs)
        eval_context["get"] = self.get_var

        # Check if this is a template string (contains {{ }})
        if isinstance(expression, str) and "{{" in expression and "}}" in expression:
            # Count how many template sections we have
            template_count = len(re.findall(r"\{\{.+?\}\}", expression))

            def replace_template(match):
                inner = match.group(1).strip()
                resolved = safe_eval(inner, eval_context)
                return str(resolved)  # Return string representation, not repr()

            # Perform template substitution
            result = re.sub(r"\{\{(.+?)\}\}", replace_template, expression)

            # If it's a single template with nothing else, eval to preserve type
            # Otherwise return the substituted string directly
            if template_count == 1 and expression.strip().startswith("{{") and expression.strip().endswith("}}"):
                try:
                    return safe_eval(result.strip("'\"", eval_context))
                except:
                    return result
            else:
                # Multiple templates or mixed content - return string as-is
                return result

        try:
            return safe_eval(expression, eval_context)
        except Exception as e:
            # Provide helpful debugging
            available_keys = list(self._variables.keys())
            print(f"[Runtime] Eval Error: {e}")
            print(f"[Runtime] Available variables: {available_keys}")
            raise e

    def resolve(self, value: Any) -> Any:
        """
        Resolve a value that might contain template strings {{ var }}.
        If value is a string with {{ }}, it evaluates the expression.
        If value is not a string, returns as is.
        """
        if not isinstance(value, str):
            return value

        # Check if this is a template string
        if "{{" in value and "}}" in value:
            # Count how many template sections we have
            template_count = len(re.findall(r"\{\{.+?\}\}", value))

            # Perform template substitution
            def replace(m):
                res = self.eval(m.group(1).strip())
                return str(res)

            result = re.sub(r"\{\{(.+?)\}\}", replace, value)

            # If it's a single template with nothing else, eval to preserve type
            # Check that it starts with {{ and ends with }}
            stripped = value.strip()
            if template_count == 1 and stripped.startswith("{{") and stripped.endswith("}}"):
                try:
                    return self.eval(stripped[2:-2].strip())
                except:
                    return result
            else:
                # Multiple templates or mixed content - return substituted string
                print(f"[Runtime] [Template] Resolved: {value[:100]}... → {result[:100]}", flush=True)
                return result

        return value

    def set_return_value(self, value: Any, status: int = 200, headers: Dict = None):
        """Set the final output of the workflow."""
        self._return_value = {"body": value, "status": status, "headers": headers or {}}

    def get_return_value(self):
        return self._return_value


import asyncio
import aiohttp
import urllib.request
import urllib.error

class SnapshotCapturer:
    _pending_tasks = set()

    @staticmethod
    def capture_async(ctx: "ExecutionContext", node_id: str, data: Any, inputs: Any = None, status: str = "success"):
        """Fire-and-forget snapshot upload."""
        mode = os.environ.get("TENSORIFY_TEST_MODE")
        print(f"[Runtime] Snapshot Capture Triggered for {node_id}. Mode: {mode}", flush=True)
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                task = loop.create_task(SnapshotCapturer._upload(ctx, node_id, data, inputs, status))
                SnapshotCapturer._pending_tasks.add(task)
                task.add_done_callback(SnapshotCapturer._pending_tasks.discard)
            else:
                 SnapshotCapturer._upload_sync(ctx, node_id, data, inputs, status)
        except RuntimeError:
             # Fallback if no event loop exists (e.g. strict exec environments)
             print(f"[Runtime] Falling back to synchronous snapshot upload for {node_id}")
             SnapshotCapturer._upload_sync(ctx, node_id, data, inputs, status)
        except Exception as e:
            print(f"[Runtime] Snapshot Error: {e}")

    @staticmethod
    async def wait_all():
        if SnapshotCapturer._pending_tasks:
            await asyncio.gather(*SnapshotCapturer._pending_tasks, return_exceptions=True)
            SnapshotCapturer._pending_tasks.clear()

    @staticmethod
    async def _upload(ctx: "ExecutionContext", node_id: str, data: Any, inputs: Any = None, status: str = "success"):
        import redis
        import json
        import datetime

        try:
            # 1. Mask Secrets
            masked_inputs = SnapshotCapturer._mask_recursive(inputs, ctx._secrets.values())
            masked_data = SnapshotCapturer._mask_recursive(data, ctx._secrets.values())

            # 2. Prepare Payload
            payload = {
                "id": str(uuid.uuid4()),
                "workflowId": ctx.workflow_id,
                "nodeId": node_id,
                "runId": ctx.execution_id,
                "status": status,
                "inputs": masked_inputs,
                "output": masked_data,
                "capturedAt": datetime.datetime.now(datetime.timezone.utc).isoformat()
            }

            # 3. Publish to Redis for real-time WebSocket streaming
            try:
                # Support REDIS_URL connection string (like DATABASE_URL)
                # Format: redis://localhost:6379/0 or rediss:// for TLS
                redis_url = os.environ.get("REDIS_URL")
                if redis_url:
                    redis_client = redis.from_url(redis_url, decode_responses=True)
                else:
                    # Fallback to individual env vars for backward compatibility
                    redis_client = redis.Redis(
                        host=os.environ.get("REDIS_HOST", "localhost"),
                        port=int(os.environ.get("REDIS_PORT", 6379)),
                        db=int(os.environ.get("REDIS_DB", 0)),
                        decode_responses=True
                    )

                channel = f"workflow:{ctx.workflow_id}:snapshots"
                redis_client.publish(channel, json.dumps(payload))
                print(f"[Runtime] 📤 Published snapshot to Redis: {channel}", flush=True)

            except Exception as redis_err:
                print(f"[Runtime] ⚠️  Redis publish failed: {redis_err}", flush=True)
            
            # 4. Also upload via HTTP for database persistence (fallback)
            api_url = os.environ.get("TENSORIFY_API_URL", "http://localhost:3000")
            token = os.environ.get("TENSORIFY_API_KEY") 
            auth_token = os.environ.get("TENSORIFY_AUTH_TOKEN", token)
            
            url = f"{api_url}/api/v1/snapshots"
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {auth_token}"
            }
            
            timeout = aiohttp.ClientTimeout(total=2)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(url, json=payload, headers=headers) as resp:
                     if resp.status != 200:
                         print(f"[Runtime] Snapshot HTTP Upload Failed: {await resp.text()}", flush=True)

        except Exception as e:
            print(f"[Runtime] Snapshot Upload Exception: {e}")

    @staticmethod
    def _upload_sync(ctx: "ExecutionContext", node_id: str, data: Any, inputs: Any = None, status: str = "success"):
        """Synchronous fallback for snapshot uploads when async event loops are missing."""
        try:
            masked_inputs = SnapshotCapturer._mask_recursive(inputs, ctx._secrets.values())
            masked_data = SnapshotCapturer._mask_recursive(data, ctx._secrets.values())
            
            payload = {
                "workflowId": ctx.workflow_id,
                "nodeId": node_id,
                "runId": ctx.execution_id,
                "status": status,
                "inputs": masked_inputs,
                "output": masked_data
            }
            
            api_url = os.environ.get("TENSORIFY_API_URL", "http://localhost:3000")
            token = os.environ.get("TENSORIFY_API_KEY") 
            auth_token = os.environ.get("TENSORIFY_AUTH_TOKEN", token)
            
            url = f"{api_url}/api/v1/snapshots"
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {auth_token}"
            }
            
            req = urllib.request.Request(
                url, 
                data=json.dumps(payload).encode('utf-8'), 
                headers=headers, 
                method='POST'
            )
            try:
                with urllib.request.urlopen(req, timeout=2) as response:
                     if response.status != 200:
                         print(f"[Runtime] Sync Snapshot Upload Failed: HTTP {response.status}", flush=True)
            except urllib.error.HTTPError as e:
                 print(f"[Runtime] Sync Snapshot Upload HTTP Error: {e.code} - {e.reason}", flush=True)
            except Exception as e:
                 print(f"[Runtime] Sync Snapshot Upload Failed: {e}", flush=True)

        except Exception as e:
            print(f"[Runtime] Sync Snapshot Exception: {e}")

    @staticmethod
    def _mask_recursive(data: Any, secrets: Any) -> Any:
        if isinstance(data, dict):
            return {k: SnapshotCapturer._mask_recursive(v, secrets) for k, v in data.items()}
        elif isinstance(data, list):
            return [SnapshotCapturer._mask_recursive(i, secrets) for i in data]
        elif isinstance(data, str):
            for secret in secrets:
                if secret and len(secret) > 4 and secret in data:
                     data = data.replace(secret, "******")
            return data
        else:
            return data


async def run_plugin(ctx: ExecutionContext, plugin_key: str, inputs: Dict[str, Any]) -> Any:
    """
    Executes a plugin action.
    """
    # Local import to avoid circular dependency
    # from ..plugins.discord_send import DiscordSendPlugin
    # from ..plugins.discord_trigger import DiscordTriggerPlugin
    # from ..plugins.telegram_send import TelegramSendPlugin
    # from ..plugins.telegram_trigger import TelegramTriggerPlugin
    # from ..plugins.python_script import PythonScriptPlugin
    from ..plugins.http_request import HttpRequestPlugin
    # from ..plugins.http_response import HttpResponsePlugin
    # from ..plugins.file_writer import FileWriterPlugin
    # from ..plugins.json_transform import JsonTransformPlugin
    
    # Simple registry (Phase 5)
    registry = {}
    
    plugin = registry.get(plugin_key)
    
    # --- Dynamic Discovery from Bundled Plugins ---
    if not plugin:
        try:
            # Try to load as a flat module from 'plugins' package first
            try:
                # heuristic: @tensorify/webhook-trigger:3.0.0 -> webhook_trigger
                # clean_name = plugin_key.split(":")[0].replace("@tensorify/", "").replace("-", "_")
                # But 'plugins' dir is in sys.path? No, we need to import from 'plugins' package.
                # Assuming 'main.py' is in root and 'plugins' is a package next to it.
                
                clean_name = plugin_key.split(":")[0].replace("@tensorify/", "").replace("-", "_")
                module_name = f"plugins.{clean_name}"
                
                print(f"[Runtime] Attempting import: {module_name}")
                module = importlib.import_module(module_name)
                
                # We need to find the class.
                # Heuristic: CamelCase of clean_name? webhook_trigger -> WebhookTriggerPlugin
                # Or just search the module for a subclass of something?
                # Or check __all__?
                
                # Let's inspect the module
                for attr_name in dir(module):
                    attr = getattr(module, attr_name)
                    # Simple check: class name ends with 'Plugin'
                    if isinstance(attr, type) and attr_name.endswith("Plugin") and attr_name != "Plugin":
                         print(f"[Runtime] Found plugin class {attr_name} in {module_name}")
                         plugin_instance = attr()
                         registry[plugin_key] = plugin_instance
                         plugin = plugin_instance
                         break
                
            except ImportError:
                 # Fallback to nested folder discovery (if manual bundle)
                 pass
            except Exception as e:
                print(f"[Runtime] Flat import failed for {plugin_key}: {e}")

            if not plugin:
                # Look for plugins directory (sibling to this runtime or in executing root)
                # We assume the execution root has 'plugins' folder (from our bundle logic)
                cwd = pathlib.Path.cwd()
                plugin_dir = cwd / "plugins" / plugin_key
    
                if plugin_dir.exists() and plugin_dir.is_dir():
                    manifest_path = plugin_dir / "manifest.json"
                    
                    # Check python directory
                    python_dir = plugin_dir / "python"
                    
                    print(f"[Runtime] Checking {plugin_dir}")
                    
                    if manifest_path.exists() and python_dir.exists():
                        with open(manifest_path, "r") as f:
                            manifest = json.load(f)
                        
                        class_name = manifest.get("entrypointClassName")
                        
                        if class_name:
                            # Scan python files for the class
                            found_class = False
                            for py_file in python_dir.glob("*.py"):
                                # Dynamically load module
                                module_name = f"dynamic_plugins.{plugin_key.replace('/', '_').replace(':', '_').replace('@', '').replace('-', '_')}"
                                try:
                                    spec = importlib.util.spec_from_file_location(module_name, py_file)
                                    if spec and spec.loader:
                                        module = importlib.util.module_from_spec(spec)
                                        sys.modules[module_name] = module
                                        spec.loader.exec_module(module)
                                        
                                        if hasattr(module, class_name):
                                            PluginClass = getattr(module, class_name)
                                            # Instantiate
                                            plugin_instance = PluginClass()
                                            
                                            # Cache and use
                                            registry[plugin_key] = plugin_instance
                                            plugin = plugin_instance
                                            print(f"[Runtime] Dynamically loaded {plugin_key} from {py_file}")
                                            found_class = True
                                            break
                                except Exception as e:
                                    print(f"[Runtime] Error loading module {py_file}: {e}")
                            
                            if not found_class:
                               print(f"[Runtime] Class {class_name} not found in {python_dir}")
                        else:
                            print(f"[Runtime] entrypointClassName not found in metadata for {plugin_key}")
                    else:
                        print(f"[Runtime] Manifest or python dir missing in {plugin_dir}")
                else:
                     print(f"[Runtime] Plugin dir not found: {plugin_dir} (CWD: {cwd})")
        except Exception as e:
            print(f"[Runtime] Dynamic discovery failed for {plugin_key}: {e}")

    if not plugin:
        print(f"[Runtime] Warning: Plugin {plugin_key} not found in registry. Using Mock.")
        return PluginOutput(status="success", data={"message": f"Mock Output from {plugin_key}"})
    
    print(f"[Runtime] Executing {plugin_key}")
    try:
        ctx._current_node_inputs = inputs

        # Return the full PluginOutput object so the caller (generated code)
        # can treat it consistently with direct class calls (accessing .data).
        result = await plugin.run(ctx, inputs)
        
        # LOGGING FOR USER INSPECTION
        if result.status == "success":
             try:
                 print(f"[Runtime] Output from {plugin_key}: {json.dumps(result.data, default=str)}", flush=True)
             except:
                 print(f"[Runtime] Output from {plugin_key}: {result.data} (Not JSON serializable)", flush=True)
        else:
             print(f"[Runtime] Error from {plugin_key}: {result.error}", flush=True)

        return result
    except Exception as e:
        return PluginOutput(status="error", error=str(e))
