
from typing import Any, Dict
from tensorify.runtime.core import ExecutionContext, PluginOutput

class FileWriterPlugin:
    async def run(self, ctx: ExecutionContext, inputs: Dict[str, Any]) -> PluginOutput:
        file_path = inputs.get("file_path", "output.txt")
        mode = inputs.get("mode", "w")
        content = inputs.get("content", "")
        
        # Convert content to string if not
        if not isinstance(content, str):
            content = str(content)
            
        try:
            with open(file_path, mode) as f:
                f.write(content)
            
            print(f"[File Writer] Wrote to {file_path}")
            return PluginOutput(status="success", data=file_path)
        except Exception as e:
             return PluginOutput(status="error", error=str(e))
