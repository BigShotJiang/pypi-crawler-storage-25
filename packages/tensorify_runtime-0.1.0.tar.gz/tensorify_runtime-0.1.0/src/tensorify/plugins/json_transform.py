
from typing import Any, Dict
from tensorify.runtime.core import ExecutionContext, PluginOutput

class JsonTransformPlugin:
    async def run(self, ctx: ExecutionContext, inputs: Dict[str, Any]) -> PluginOutput:
        data = inputs.get("data")
        expr = inputs.get("expression", "data")
        
        # Inject 'data' into the evaluation context
        # We rely on ctx.eval taking care of restricted execution
        # But ctx.eval uses ctx._variables. 
        # We should probably pass a temporary context to eval?
        # core.py `eval` method: `return safe_eval(expression, eval_context)`
        # `eval_context` includes `inputs`, `vars`.
        # So if we want `data` to be available as a variable `data`, we need to inject it.
        # But `core.py` eval constructs context from member variables.
        # It doesn't accept "extra locals".
        # 
        # Helper workaround: We set a temporary variable in ctx? No, dangerous concurrency.
        # The `ctx.eval` method in core.py needs to support overrides?
        #
        # Let's check core.py. 
        # def eval(self, expression: str) -> Any:
        #    ...
        #    return safe_eval(expression, eval_context)
        #
        # This means I CANNOT pass extra vars to eval unless I modify core.py.
        # OR I use `safe_eval` directly here in the plugin.
        # Plugin classes sit next to core, but can import safe_eval?
        # Yes, from tensorify.runtime.expression import safe_eval.
        
        from tensorify.runtime.expression import safe_eval
        
        eval_ctx = ctx._variables.copy()
        eval_ctx["data"] = data
        # Also include standard utils if needed, safe_eval handles it.
        
        try:
            print(f"[JsonTransform] Data: {data}, Expr: {expr}")
            result = safe_eval(expr, eval_ctx)
            print(f"[JsonTransform] Result: {result}")
            return PluginOutput(status="success", data=result)
        except Exception as e:
             print(f"[JsonTransform] Error: {e}")
             return PluginOutput(status="error", error=f"Transform error: {str(e)}")
