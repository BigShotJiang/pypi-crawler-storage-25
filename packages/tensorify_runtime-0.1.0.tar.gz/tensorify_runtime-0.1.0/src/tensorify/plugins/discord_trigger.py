
from typing import Any, Dict
from tensorify.runtime.core import ExecutionContext, PluginOutput

class DiscordTriggerPlugin:
    async def run(self, ctx: ExecutionContext, inputs: Dict[str, Any]) -> PluginOutput:
        # In a real scenario, the Runtime passes the trigger event in ctx.inputs
        trigger_data = ctx.inputs.get("discord_event")
        
        if not trigger_data:
            # Fallback for testing or if invoked manually
            return PluginOutput(status="error", error="No discord_event found in inputs")
            
        return PluginOutput(status="success", data=trigger_data)
