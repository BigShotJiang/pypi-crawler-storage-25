
import aiohttp
import json
from typing import Any, Dict
from tensorify.runtime.core import ExecutionContext, PluginOutput

class HttpRequestPlugin:
    async def run(self, ctx: ExecutionContext, inputs: Dict[str, Any]) -> PluginOutput:
        url = inputs.get("url")
        method = inputs.get("method", "GET").upper()
        headers_str = inputs.get("headers", "{}")
        body = inputs.get("body")
        
        if not url:
            return PluginOutput(status="error", error="Missing URL")
            
        try:
            headers = json.loads(headers_str) if isinstance(headers_str, str) else headers_str
        except Exception:
            return PluginOutput(status="error", error="Invalid Headers JSON")

        # Mock Mode for Testing
        if url == "MOCK_URL":
            print(f"[HTTP Mock] {method} {url}")
            return PluginOutput(status="success", data={"status": 200, "data": {"mock": "result"}, "headers": {}})
            
        async with aiohttp.ClientSession() as session:
            try:
                async with session.request(method, url, headers=headers, json=body) as resp:
                    try:
                        data = await resp.json()
                    except:
                        data = await resp.text()
                        
                    result_obj = {
                        "status": resp.status,
                        "data": data,
                        "headers": dict(resp.headers)
                    }
                    
                    if 200 <= resp.status < 300:
                        return PluginOutput(status="success", data=result_obj)
                    else:
                        # Even if error status, we return as success so workflow can handle logic? 
                        # Or return error? V3 Philosophy: Let user decide via If condition on status.
                        return PluginOutput(status="success", data=result_obj)
                        
            except Exception as e:
                return PluginOutput(status="error", error=str(e))
