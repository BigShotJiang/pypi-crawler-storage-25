
import aiohttp
from typing import Any, Dict
from tensorify.runtime.core import ExecutionContext, PluginOutput

class DiscordSendPlugin:
    async def run(self, ctx: ExecutionContext, inputs: Dict[str, Any]) -> PluginOutput:
        token = ctx.get_secret("DISCORD_TOKEN")
        if not token:
            return PluginOutput(status="error", error="Missing DISCORD_TOKEN secret")

        channel_id = inputs.get("channel_id")
        content = inputs.get("message_content")
        
        if not channel_id or not content:
             return PluginOutput(status="error", error="Missing channel_id or message_content")
        
        if token == "MOCK_TOKEN":
            print(f"[Discord Mock] Sending to {channel_id}: {content}")
            return PluginOutput(status="success", data={"id": "mock-message-id", "content": content})

        url = f"https://discord.com/api/v10/channels/{channel_id}/messages"
        headers = {
            "Authorization": f"Bot {token}",
            "Content-Type": "application/json"
        }
        payload = {"content": str(content)}

        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers, json=payload) as resp:
                if resp.status in (200, 201):
                    data = await resp.json()
                    return PluginOutput(status="success", data=data)
                else:
                    text = await resp.text()
                    return PluginOutput(status="error", error=f"Discord API Error {resp.status}: {text}")
