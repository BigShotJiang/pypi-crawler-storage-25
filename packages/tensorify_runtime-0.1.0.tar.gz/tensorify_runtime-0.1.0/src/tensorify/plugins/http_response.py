
from typing import Any, Dict
from tensorify.runtime.core import ExecutionContext, PluginOutput

class HttpResponsePlugin:
    async def run(self, ctx: ExecutionContext, inputs: Dict[str, Any]) -> PluginOutput:
        body = inputs.get("body")
        status = inputs.get("status", 200)
        headers = inputs.get("headers", {})
        
        ctx.set_return_value(body, int(status), headers)
        
        print(f"[HTTP Response] Set workflow output: Status {status}")
        return PluginOutput(status="success", data={"returned": True})
