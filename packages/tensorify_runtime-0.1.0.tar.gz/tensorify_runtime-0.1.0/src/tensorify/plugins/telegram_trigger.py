
from typing import Any, Dict
from tensorify.runtime.core import ExecutionContext, PluginOutput

class TelegramTriggerPlugin:
    async def run(self, ctx: ExecutionContext, inputs: Dict[str, Any]) -> PluginOutput:
        # Runtime extracts payload from webhook/polling source and puts it in inputs
        tg_event = ctx.inputs.get("telegram_event")
        
        if not tg_event:
            return PluginOutput(status="error", error="No telegram_event found in inputs")
            
        return PluginOutput(status="success", data=tg_event)
