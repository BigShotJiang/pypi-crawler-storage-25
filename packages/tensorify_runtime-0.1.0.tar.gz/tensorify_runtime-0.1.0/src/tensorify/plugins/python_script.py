
from typing import Any, Dict
from tensorify.runtime.core import ExecutionContext, PluginOutput
from RestrictedPython import compile_restricted, safe_globals

class PythonScriptPlugin:
    async def run(self, ctx: ExecutionContext, inputs: Dict[str, Any]) -> PluginOutput:
        code_str = inputs.get("code", "")
        script_params = inputs.get("script_params", {})
        
        # Prepare globs
        # For "Universal" script, we use standard builtins to allow imports
        # In a real production environment, this should be sandboxed via Docker/WASM,
        # but for V3 MVP "Local Execution", we trust the user code (or warn them).
        script_globals = {
            "__builtins__": __builtins__,
            "__name__": "universal_script",
            "ctx": ctx,
            "print": print
        }
        
        # Locals will contain inputs and collect outputs
        loc = {
            "params": script_params, 
            "result": None,
            "ctx": ctx # Expose Context for V3 Variable Access (Temporary/Advanced)
        }
        
        # Helper to indent user code
        indented_code = "\n".join(["    " + line for line in code_str.split("\n")])
        
        # Wrapper function
        wrapped_code = f"""
async def _user_script(ctx, params):
    # Standard globals
{indented_code}
"""
        
        try:
             # Compile standard (unsafe for now, but universal)
             exec(wrapped_code, script_globals, loc)
             
             # Execute the async function
             if "_user_script" in loc:
                 await loc["_user_script"](ctx, script_params)
             
             # Proxy captured output (if any)
             # Note: standard print goes to stdout, so we don't need to capture 'printed' variable unless we redirect stdout.
             # Since we use standard exec, 'print' just prints.
             
             return PluginOutput(status="success", data=loc.get("result"))
        except Exception as e:
            print(f"[Script Error] {str(e)}")
            return PluginOutput(status="error", error=f"Script Error: {str(e)}")
