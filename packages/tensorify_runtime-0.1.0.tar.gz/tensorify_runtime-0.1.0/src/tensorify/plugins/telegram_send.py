
import aiohttp
from typing import Any, Dict
from tensorify.runtime.core import ExecutionContext, PluginOutput

class TelegramSendPlugin:
    async def run(self, ctx: ExecutionContext, inputs: Dict[str, Any]) -> PluginOutput:
        token = ctx.get_secret("TELEGRAM_BOT_TOKEN")
        if not token:
             return PluginOutput(status="error", error="Missing TELEGRAM_BOT_TOKEN")
             
        chat_id = inputs.get("chat_id")
        text = inputs.get("text")
        
        if not chat_id or not text:
            return PluginOutput(status="error", error="Missing chat_id or text")
            
        # Mock Support
        if token == "MOCK_TOKEN":
            print(f"[Telegram Mock] Sending to {chat_id}: {text}")
            return PluginOutput(status="success", data={"ok": True, "result": {"message_id": 123, "text": text}})
        
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        payload = {"chat_id": chat_id, "text": str(text)}
        
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload) as resp:
                data = await resp.json()
                if resp.status == 200 and data.get("ok"):
                    return PluginOutput(status="success", data=data)
                else:
                    return PluginOutput(status="error", error=f"Telegram API Error: {data}")
