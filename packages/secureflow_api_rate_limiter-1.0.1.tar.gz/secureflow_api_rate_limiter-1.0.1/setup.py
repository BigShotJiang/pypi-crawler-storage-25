from setuptools import setup, find_packages

setup(
    name="secureflow-api-rate-LIMITER",
    version="1.0.1",
    packages=find_packages(),
    
    install_requires=[
        "Flask==2.3.3",
        "flask-cors==4.0.0",
        "flask-socketio==5.3.6",
        "python-socketio==5.9.0",
        "PyJWT==2.8.0",
        "bcrypt==4.1.2",
        "requests==2.31.0",
        "python-dotenv==1.0.0",
        "aiohttp==3.9.1",
        "pytz==2023.3",
        "gunicorn==21.2.0",
        "geoip2==4.7.0",
        "redis==5.0.1",
    ],
    
    author="Samad Rehman",
    author_email="samadrehman550@gmail.com",
    url="https://github.com/samadrehman/secureflow-api-rate-LIMITER",
    
    description="Open-source API rate limiting and protection toolkit with dynamic configuration",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    
    keywords="rate-limiting api-protection security rate-limiter",
    
    python_requires=">=3.8",
    
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Web Environment",
        "Framework :: Flask",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Networking",
    ],
    
    project_urls={
        "Bug Reports": "https://github.com/samadrehman/secureflow-api-rate-LIMITER/issues",
        "Source": "https://github.com/samadrehman/secureflow-api-rate-LIMITER",
    },
)