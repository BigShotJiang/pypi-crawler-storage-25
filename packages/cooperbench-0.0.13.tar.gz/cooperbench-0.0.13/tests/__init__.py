"""CooperBench test suite."""
