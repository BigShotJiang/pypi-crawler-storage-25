"""
TFGaurd - Real Terraform policy check runner
Usage: python tests/run_check.py tests/sample_bad.tf
"""
import sys, os
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils import parser
from utils.policy_checker import check_resources, get_severity

def run(tf_path: str):
    print(f"\n{'='*72}")
    print(f"  TFGaurd Policy Engine - Scanning: {tf_path}")
    print(f"{'='*72}")

    resources = parser.parse_terraform_file(tf_path)
    print(f"\n  Resources parsed : {len(resources)}")
    for r in resources:
        for rt, rcs in r.items():
            for rn in rcs:
                print(f"    - {rt}.{rn}")

    violations = check_resources(resources, has_subscription=True)

    # Filter out rule-errors from count
    rule_errors = [v for v in violations if v['violation'].startswith('[RULE ERROR]')]
    real_violations = [v for v in violations if not v['violation'].startswith('[RULE ERROR]')]

    by_sev = {}
    for v in real_violations:
        sev = get_severity(v['violation'])
        by_sev.setdefault(sev, []).append(v)

    print(f"\n  Total violations : {len(real_violations)}")
    print(f"  Rule errors      : {len(rule_errors)} (internals)")
    c = len(by_sev.get('CRITICAL', []))
    h = len(by_sev.get('HIGH', []))
    m = len(by_sev.get('MEDIUM', []))
    l = len(by_sev.get('LOW', []))
    print(f"  CRITICAL: {c}  HIGH: {h}  MEDIUM: {m}  LOW: {l}\n")

    for sev in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']:
        items = by_sev.get(sev, [])
        if not items:
            continue
        print(f"  [{sev}] {len(items)} findings")
        print(f"  {'-'*68}")
        for v in items:
            print(f"  >> {v['resource_type']}.{v['resource_name']}")
            print(f"     {v['violation']}")
        print()

    if rule_errors:
        print(f"\n  [RULE ERRORS - {len(rule_errors)}]")
        for e in rule_errors:
            print(f"  !! {e['resource_type']}.{e['resource_name']}: {e['violation']}")

    print(f"\n{'='*72}\n")
    return real_violations

if __name__ == '__main__':
    tf_file = sys.argv[1] if len(sys.argv) > 1 else 'tests/sample_bad.tf'
    violations = run(tf_file)
    sys.exit(1 if violations else 0)
