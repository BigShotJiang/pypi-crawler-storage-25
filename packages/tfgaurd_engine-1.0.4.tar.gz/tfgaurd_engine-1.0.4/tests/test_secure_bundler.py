"""
End-to-end test for TFGaurd Secure Rule Bundler.
Verifies that the server can encrypt rules and the CLI can decrypt 
and execute them entirely in-memory using an API key.
"""

import sys
import os
import hashlib
import gzip
from pathlib import Path

# Add project root to path so we can import modules
project_root = Path(__file__).parent.parent
sys.path.append(str(project_root))

from services.rule_bundler import build_encrypted_bundle
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

def test_secure_bundle_flow():
    # ── 1. Setup Mock User ──────────────────────────────────────────────────
    MOCK_API_KEY = "tfgaurd_test_key_premium_12345"
    print(f"[*] Starting Secure Rule Bundle Test")
    print(f"[*] Mock API Key: {MOCK_API_KEY}")

    # ── 2. Server Side: Build Bundle ────────────────────────────────────────
    print(f"[*] Step 1: Server encrypting premium rules...")
    try:
        bundle_blob = build_encrypted_bundle(MOCK_API_KEY)
        print(f"[+] Bundle built successfully. Size: {len(bundle_blob)} bytes")
    except Exception as e:
        print(f"[!] Encryption failed: {e}")
        return False

    # ── 3. CLI Side: Derive Key & Decrypt ────────────────────────────────────
    print(f"[*] Step 2: CLI deriving key from API key...")
    # Derive key identically to how tfgaurd_cli.py does it
    cli_key = hashlib.sha256(MOCK_API_KEY.encode()).digest()
    
    print(f"[*] Step 3: CLI decrypting bundle in-memory...")
    try:
        nonce = bundle_blob[:12]
        ciphertext = bundle_blob[12:]
        aesgcm = AESGCM(cli_key)
        
        decrypted_compressed = aesgcm.decrypt(nonce, ciphertext, None)
        decrypted_source = gzip.decompress(decrypted_compressed).decode("utf-8")
        
        print(f"[+] Decryption successful. Decrypted size: {len(decrypted_source)} chars")
    except Exception as e:
        print(f"[!] Decryption failed: {e}")
        return False

    # ── 4. Verify Execution ──────────────────────────────────────────────────
    print(f"[*] Step 4: CLI executing rules in a clean namespace...")
    try:
        # Isolated namespace simulation
        mock_namespace = {
            "__builtins__": __builtins__,
            "__name__": "premium_rules_test",
        }
        
        # This will compile and run the rules (re-building RULE_REGISTRY)
        exec(decrypted_source, mock_namespace)
        
        registry = mock_namespace.get("RULE_REGISTRY")
        if not registry or not isinstance(registry, dict):
            print(f"[!] Error: Decrypted code failed to produce a RULE_REGISTRY dict.")
            return False
            
        rule_count = sum(len(rules) for rules in registry.values())
        print(f"[+] Success! Rebuilt registry with {rule_count} rules across {len(registry)} resource types.")
        
        # Verify a specific premium rule exists
        # aws_s3_bucket should have > 11 rules now (free=11)
        if 'aws_s3_bucket' in registry and len(registry['aws_s3_bucket']) > 11:
            print(f"[+] Verified: Premium S3 rules are present ({len(registry['aws_s3_bucket'])} rules).")
        else:
            print(f"[!] Warning: Premium rule count looks suspicious (Check rules.py mapping).")

    except Exception as e:
        print(f"[!] Namespace execution failed: {e}")
        return False

    print("\n" + "="*50)
    print("  ✓ SECURE RULE BUNDLER VERIFICATION PASSED")
    print("="*50)
    return True

if __name__ == "__main__":
    success = test_secure_bundle_flow()
    sys.exit(0 if success else 1)
