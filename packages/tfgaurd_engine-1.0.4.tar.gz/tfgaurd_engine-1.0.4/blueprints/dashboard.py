"""
Dashboard Blueprint
Handles dashboard UI, policy checking page, rules management, and results viewing
"""

from datetime import datetime

from flask import Blueprint, jsonify, render_template, request, session, flash, redirect, url_for
from sqlalchemy import func

from core.auth import login_required, admin_required
from core.database import get_db_session
from core.models import CheckHistory, User, ContactMessage, InstallationLog
from services import get_visitor_tracker
from utils import rules
from utils.seo_helpers import (
    get_preset_meta, 
    generate_meta_tags, 
    generate_breadcrumbs, 
    generate_faq_schema, 
    generate_software_schema
)

dashboard_bp = Blueprint("dashboard", __name__, url_prefix="")


@dashboard_bp.context_processor
def inject_admin_context():
    """Inject shared context variables into every dashboard template.

    This means no individual route needs to pass admin_username /
    admin_unread_msgs — they are always available in templates.
    """
    username = session.get("username", "")
    unread = 0
    if username:
        try:
            unread = _get_unread_msg_count()
        except Exception:
            unread = 0
    return {
        "admin_username": username,
        "admin_unread_msgs": unread,
    }


# ============================================================================
# PUBLIC HOME PAGE
# ============================================================================


@dashboard_bp.route("/")
def home():
    """Public home page - no login required"""
    # Track visitor
    tracker = get_visitor_tracker()
    ip_address = request.remote_addr
    user_agent = request.headers.get('User-Agent', '')
    page_url = request.path
    referer = request.headers.get('Referer')
    tracker.track_visitor(ip_address, user_agent, page_url, referer)

    # Get visitor stats
    visitor_stats = tracker.get_stats()

    meta = get_preset_meta('homepage')
    return render_template("frontend/home.html", visitor_stats=visitor_stats, meta=meta)


# ============================================================================
# MAIN DASHBOARD (requires login)
# ============================================================================


@dashboard_bp.route("/dashboard")
@login_required
def dashboard():
    """Main dashboard page"""
    # Get statistics from database
    with get_db_session() as session_db:
        # Total checks
        total_checks = session_db.query(CheckHistory).count()

        # Total violations
        total_violations = (
            session_db.query(func.sum(CheckHistory.violation_count)).scalar() or 0
        )

        # Recent checks
        recent_checks = (
            session_db.query(CheckHistory)
            .order_by(CheckHistory.created_at.desc())
            .limit(10)
            .all()
        )
        recent_checks = [c.to_dict() for c in recent_checks]

    # Get statistics from rules
    total_rules = sum(len(rule_list) for rule_list in rules.RULE_REGISTRY.values())
    resource_types = len(rules.RULE_REGISTRY)

    return render_template(
        "admin/dashboard.html",
        total_rules=total_rules,
        resource_types=resource_types,
        total_checks=total_checks,
        total_violations=total_violations,
        recent_checks=recent_checks,
        total_pypi_installs=session_db.query(InstallationLog).filter_by(installer_type='pypi').count(),
        total_vps_installs=session_db.query(InstallationLog).filter(InstallationLog.installer_type.in_(['bash', 'bash_vps', 'shell_vps'])).count(),
    )


# ============================================================================
# POLICY CHECKING
# ============================================================================


@dashboard_bp.route("/check")
@login_required
def check_page():
    """Policy check page"""
    return render_template("admin/check.html")


# ============================================================================
# RULES MANAGEMENT
# ============================================================================


@dashboard_bp.route("/history")
@login_required
def history_page():
    """Policy check history page"""
    # Get current user
    username = session.get("username")

    with get_db_session() as session_db:
        # Get user info for filtering
        from core.models import User

        user = session_db.query(User).filter_by(username=username).first()

        # Get check history
        history_query = session_db.query(CheckHistory)

        # Filter by user if not admin
        if user and user.role.value != "admin":
            history_query = history_query.filter_by(user_id=user.id)

        # Get paginated results
        total_count = history_query.count()
        history = history_query.order_by(CheckHistory.created_at.desc()).limit(50).all()
        history_list = [h.to_dict() for h in history]

    return render_template(
        "admin/history.html", history=history_list, total_count=total_count
    )


@dashboard_bp.route("/rules")
@login_required
def rules_page():
    """Rules management page"""
    # Get all rules organized by resource type
    rules_by_type = {}

    # Add built-in rules
    for resource_type, rule_list in rules.RULE_REGISTRY.items():
        rules_by_type[resource_type] = []
        for rule_func in rule_list:
            rules_by_type[resource_type].append(
                {
                    "name": rule_func.__name__,
                    "description": rule_func.__doc__ or "No description",
                    "category": "built-in",
                    "condition": "built-in",
                    "value": "",
                    "severity": "MEDIUM",
                }
            )

    # Add custom rules from database
    for custom_rule in rules.get_all_custom_rules():
            resource_type = custom_rule.get("resource_type", "aws_s3_bucket")
            if resource_type not in rules_by_type:
                rules_by_type[resource_type] = []
            rules_by_type[resource_type].append(
                {
                    "name": custom_rule.get("name"),
                    "description": custom_rule.get("description"),
                    "category": custom_rule.get("category"),
                    "condition": custom_rule.get("condition"),
                    "value": custom_rule.get("value"),
                    "severity": custom_rule.get("severity"),
                    "resource_type": resource_type,
                }
            )

    return render_template("admin/rules.html", rules_by_type=rules_by_type)


# ============================================================================
# API TESTING
# ============================================================================


@dashboard_bp.route("/api-testing")
@login_required
def api_testing_page():
    """API testing page"""
    return render_template("admin/api_testing.html")


# ============================================================================
# ALL RULES VIEW
# ============================================================================


@dashboard_bp.route("/all-rules")
@login_required
def all_rules_page():
    """View all rules in a single list"""
    all_rules_list = []

    # Add built-in rules
    for resource_type, rule_list in rules.RULE_REGISTRY.items():
        for rule_func in rule_list:
            all_rules_list.append(
                {
                    "name": rule_func.__name__,
                    "description": rule_func.__doc__ or "No description",
                    "resource_type": resource_type,
                    "category": "built-in",
                    "severity": "MEDIUM",
                    "type": "built-in",
                }
            )

    # Add custom rules
    for custom_rule in rules.get_all_custom_rules():
        all_rules_list.append(
            {
                "name": custom_rule.get("name"),
                "description": custom_rule.get("description"),
                "resource_type": custom_rule.get("resource_type"),
                "category": custom_rule.get("category"),
                "severity": custom_rule.get("severity"),
                "type": custom_rule.get("type", "form-based"),
            }
        )

    return render_template(
        "admin/all_rules.html", all_rules=all_rules_list, total_count=len(all_rules_list)
    )


# ============================================================================
# RESOURCE TYPE VIEW
# ============================================================================


@dashboard_bp.route("/resource-types")
@login_required
def resource_types_page():
    """View rules organized by resource type"""
    rules_by_type = {}

    # Add built-in rules
    for resource_type, rule_list in rules.RULE_REGISTRY.items():
        rules_by_type[resource_type] = []
        for rule_func in rule_list:
            rules_by_type[resource_type].append(
                {
                    "name": rule_func.__name__,
                    "description": rule_func.__doc__ or "No description",
                    "category": "built-in",
                    "severity": "MEDIUM",
                    "type": "built-in",
                }
            )

    # Add custom rules
    for custom_rule in rules.get_all_custom_rules():
        resource_type = custom_rule.get("resource_type", "aws_s3_bucket")
        if resource_type not in rules_by_type:
            rules_by_type[resource_type] = []
        rules_by_type[resource_type].append(
            {
                "name": custom_rule.get("name"),
                "description": custom_rule.get("description"),
                "category": custom_rule.get("category"),
                "severity": custom_rule.get("severity"),
                "type": custom_rule.get("type", "form-based"),
            }
        )

    return render_template("admin/resource_types.html", rules_by_type=rules_by_type)


# ============================================================================
# RESULTS VIEWING
# ============================================================================


@dashboard_bp.route("/results/<int:check_id>")
@login_required
def results_page(check_id):
    """View detailed results for a specific check"""
    with get_db_session() as session_db:
        check = session_db.query(CheckHistory).get(check_id)

        if not check:
            return "Check not found", 404

        check_result = check.to_dict()
        return render_template(
            "admin/results.html", check_result=check_result, check_id=check_id
        )


# ============================================================================
# ADMIN - SHARED HELPERS
# ============================================================================


def _get_unread_msg_count() -> int:
    """Return number of unread contact messages (for sidebar badge)."""
    try:
        with get_db_session() as session_db:
            return session_db.query(ContactMessage).filter(ContactMessage.is_read == False).count()
    except Exception:
        return 0


# ============================================================================
# ADMIN - VISITOR ANALYTICS
# ============================================================================


@dashboard_bp.route("/admin/visitors")
@login_required
def admin_visitors():
    """Admin-only: visitor analytics with DB pagination + heatmap data"""
    username = session.get('username')
    if not username:
        return "Access denied. Please login.", 403

    # Load user and read all needed attributes INSIDE the session block
    # to avoid DetachedInstanceError after session closes.
    with get_db_session() as session_db:
        user = session_db.query(User).filter_by(username=username).first()
        if not user or user.role.value != 'admin':
            return "Access denied. Admin privileges required.", 403
        admin_username = user.username   # plain str — safe after session closes

    from services.visitor_tracker import _query_recent, _get_summary, get_heatmap_data, get_stats

    # Query parameters
    page          = request.args.get('page', 1, type=int)
    per_page      = request.args.get('per_page', 50, type=int)
    page_filter   = request.args.get('page_filter', '')
    bot_filter    = request.args.get('bot_filter', '')
    device_filter = request.args.get('device_filter', '')
    search        = request.args.get('search', '')
    heatmap_url   = request.args.get('heatmap_page', '/')

    per_page = min(per_page, 200)

    paginated     = _query_recent(
        page=page, per_page=per_page,
        page_filter=page_filter or None,
        bot_filter=bot_filter or None,
        device_filter=device_filter or None,
        search=search or None,
    )
    summary       = _get_summary()
    overall_stats = get_stats()
    heatmap_data  = get_heatmap_data(
        page_url=heatmap_url if heatmap_url != '/' else None, limit=2000
    )

    # Unpack the dict so Jinja2 never sees paginated.items
    # (which would resolve to the dict's built-in .items() method!)
    return render_template(
        "admin/visitors.html",
        visits=paginated["items"],
        visit_total=paginated["total"],
        visit_pages=paginated["pages"],
        visit_page=paginated["page"],
        summary=summary,
        overall_stats=overall_stats,
        heatmap_data=heatmap_data,
        heatmap_url=heatmap_url,
        admin_username=admin_username,
        admin_unread_msgs=_get_unread_msg_count(),
        page_filter=page_filter,
        bot_filter=bot_filter,
        device_filter=device_filter,
        search=search,
        per_page=per_page,
    )


# ============================================================================
# ADMIN - USER MANAGEMENT
# ============================================================================


@dashboard_bp.route("/admin/users")
@admin_required
def admin_users():
    """Admin page to view all registered users"""
    username = session.get('username')

    with get_db_session() as session_db:
        # Get current admin user
        current_user = session_db.query(User).filter_by(username=username).first()

        # Get all users ordered by most recent first
        all_users = session_db.query(User).order_by(User.created_at.desc()).all()

        # Convert to dictionaries for template
        users_list = []
        for user in all_users:
            users_list.append({
                'id': user.id,
                'username': user.username,
                'email': user.email or 'N/A',
                'phone': user.phone or 'N/A',
                'role': user.role.value,
                'auth_method': user.auth_method,
                'is_active': user.is_active,
                'created_at': user.created_at.strftime('%Y-%m-%d %H:%M:%S') if user.created_at else 'N/A',
                'last_login': user.last_login.strftime('%Y-%m-%d %H:%M:%S') if user.last_login else 'Never',
                'login_count': user.login_count
            })

        # Calculate statistics
        total_users = len(users_list)
        active_users = sum(1 for u in users_list if u['is_active'])
        admin_users = sum(1 for u in users_list if u['role'] == 'admin')
        developer_users = sum(1 for u in users_list if u['role'] == 'developer')
        auditor_users = sum(1 for u in users_list if u['role'] == 'auditor')

        return render_template(
            "admin/users.html",
            users=users_list,
            total_users=total_users,
            active_users=active_users,
            admin_users=admin_users,
            developer_users=developer_users,
            auditor_users=auditor_users,
            current_user=current_user,
            admin_username=username,
            admin_unread_msgs=_get_unread_msg_count(),
        )


# ============================================================================
# RESOURCE PAGES (No auth required)
# ============================================================================


@dashboard_bp.route("/docs")
def docs_page():
    """Public documentation page"""
    meta = get_preset_meta('docs')
    return render_template("frontend/docs.html", meta=meta)


@dashboard_bp.route("/api-reference")
def api_reference_page():
    """Public API reference page"""
    meta = get_preset_meta('api')
    return render_template("frontend/api_reference.html", meta=meta)


@dashboard_bp.route("/support")
def support_page():
    """Public support page"""
    meta = generate_meta_tags(
        title='Support & Help Center | Policy Engine',
        description='Get help with Policy Engine. Browse FAQs, contact support, and find resources for Terraform security scanning and policy validation.',
        keywords='policy engine support, terraform help, iac security support'
    )
    return render_template("frontend/support.html", meta=meta)


@dashboard_bp.route("/contact", methods=["POST"])
def contact_submit():
    """Handle support contact form submission — saves message to DB"""
    from core.models import ContactMessage

    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip()
    category = (data.get("category") or "").strip()
    message = (data.get("message") or "").strip()

    if not name or not email or not message:
        return jsonify({"success": False, "error": "Name, email, and message are required."}), 400

    # Basic email sanity check
    if "@" not in email or "." not in email.split("@")[-1]:
        return jsonify({"success": False, "error": "Please enter a valid email address."}), 400

    ip = request.headers.get("X-Forwarded-For", request.remote_addr)

    try:
        with get_db_session() as session_db:
            msg = ContactMessage(
                name=name,
                email=email,
                category=category or None,
                message=message,
                ip_address=ip,
            )
            session_db.add(msg)
            session_db.commit()
        return jsonify({"success": True, "message": "Thanks! We'll get back to you within 24 hours."})
    except Exception as e:
        return jsonify({"success": False, "error": "Server error. Please try again later."}), 500

@dashboard_bp.route("/pricing")
def pricing_page():
    """Public pricing page"""
    from config.settings import RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET
    import razorpay

    meta = generate_meta_tags(
        title='Pricing | TFGaurd',
        description='TFGaurd pricing plans for Terraform Security Scanner. Free AWS checks, premium rules for GCP, Azure, and Oracle.',
        keywords='tfgaurd pricing, policy engine pricing, terraform security subscription, multicloud security pricing'
    )
    
    # Check if user has active subscription
    has_sub = False
    user_email = ""
    user_phone = ""
    
    if "username" in session:
        with get_db_session() as session_db:
            u = session_db.query(User).filter_by(username=session["username"]).first()
            if u:
                has_sub = u.has_active_subscription
                user_email = u.email or ""
                user_phone = u.phone or ""

    # Generate a Razorpay Order ID if they are logged in and don't have a sub.
    # $29.99 = ~2500 INR (Pricing should be in smallest currency unit: paise)
    order_id = ""
    if "username" in session and not has_sub and RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET:
        try:
            client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))
            data = {
                "amount": 249900,  # 2499 INR down to paise
                "currency": "INR",
                "receipt": "order_receipt_premium_1",
                "payment_capture": "1"
            }
            payment = client.order.create(data=data)
            order_id = payment.get("id", "")
        except Exception as e:
            # Silently fail if keys aren't configured yet so UI doesn't crash
            pass

    return render_template(
        "frontend/pricing.html", 
        meta=meta, 
        has_sub=has_sub, 
        order_id=order_id, 
        razorpay_key_id=RAZORPAY_KEY_ID,
        user_email=user_email,
        user_phone=user_phone
    )


@dashboard_bp.route("/verify-payment", methods=["POST"])
@login_required
def verify_payment():
    """Verify Razorpay payment signature and activate subscription"""
    from config.settings import RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET
    import razorpay

    # Extract payment details from form (sent directly by razorpay checkout)
    payment_id = request.form.get("razorpay_payment_id")
    order_id = request.form.get("razorpay_order_id")
    signature = request.form.get("razorpay_signature")

    if not (payment_id and order_id and signature) or not RAZORPAY_KEY_SECRET:
        flash("Invalid payment details or server configuration error.", "danger")
        return redirect(url_for('dashboard.pricing_page'))

    try:
        # Verify the signature
        client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))
        params_dict = {
            'razorpay_order_id': order_id,
            'razorpay_payment_id': payment_id,
            'razorpay_signature': signature
        }
        client.utility.verify_payment_signature(params_dict)

        # Update User configuration
        with get_db_session() as session_db:
            u = session_db.query(User).filter_by(username=session["username"]).first()
            if u:
                u.has_active_subscription = True
                
        flash("Subscription purchased successfully! You now have access to premium GCP, Azure, and Oracle rules.", "success")
    except razorpay.errors.SignatureVerificationError:
        flash("Payment verification failed! Please contact support.", "danger")
    except Exception as e:
        flash("An error occurred during payment processing.", "danger")

    return redirect(url_for('dashboard.pricing_page'))



# ============================================================================
# BLOG (No auth required)
# ============================================================================

@dashboard_bp.route("/blog")
def blog_index():
    """Blog index — show all articles"""
    meta = generate_meta_tags(
        title='TFGaurd Blog | Terraform Security & Cloud Compliance Articles',
        description='Expert guides on Terraform security, cloud compliance, and shifting security left. Read our latest articles on Sentinel, OPA, and more.',
        keywords='terraform blog, cloud security articles, iac security guide, sentinel vs opa, tfgaurd guides'
    )
    breadcrumbs = generate_breadcrumbs([("Home", "/"), ("Blog", "/blog")])
    return render_template("frontend/blog_list.html", meta=meta, breadcrumbs=breadcrumbs)


@dashboard_bp.route("/blog/sentinel-vs-opa-vs-tfgaurd")
def blog_sentinel_vs_opa():
    """Blog: Terraform Sentinel vs OPA vs TFGaurd"""
    meta = generate_meta_tags(
        title='Terraform Sentinel vs OPA vs TFGaurd: The Complete 2026 Comparison',
        description='Deep-dive comparison of Terraform Sentinel, Open Policy Agent (OPA), and TFGaurd. Learn key differences in language, cost, CI/CD integration, and which tool fits your IaC security workflow.',
        keywords='terraform sentinel vs opa, tfgaurd vs sentinel, opa vs sentinel terraform, terraform policy enforcement, iac security tools comparison, open policy agent terraform',
        article=True,
        author='TFGaurd Team',
        published_time='2026-03-04',
    )
    breadcrumbs = generate_breadcrumbs([("Home", "/"), ("Blog", "/blog"), ("Sentinel vs OPA", "/blog/sentinel-vs-opa-vs-tfgaurd")])
    return render_template("frontend/blog_sentinel_vs_opa_vs_tfgaurd.html", meta=meta, breadcrumbs=breadcrumbs)


@dashboard_bp.route("/blog/cloud-security-tfgaurd")
def blog_cloud_security():
    """Blog: Cloud Security Crisis and tfgaurd Prevention"""
    meta = generate_meta_tags(
        title='Cloud Security Crisis: How tfgaurd.com Prevents 93% of Preventable Breaches',
        description='Why 93% of cloud security breaches are preventable and how automated infrastructure validation with tfgaurd.com catches misconfigurations before they reach production.',
        keywords='cloud security, terraform security, infrastructure security, cloud misconfigurations, tfgaurd, iac security, devsecops, shift-left security',
        article=True,
        author='TFGaurd Team',
        published_time='2026-03-12',
    )
    breadcrumbs = generate_breadcrumbs([("Home", "/"), ("Blog", "/blog"), ("Cloud Security", "/blog/cloud-security-tfgaurd")])
    return render_template("frontend/blog_cloud_security_tfgaurd.html", meta=meta, breadcrumbs=breadcrumbs)


@dashboard_bp.route("/blog/tfgaurd-vs-checkov")
def blog_tfgaurd_vs_checkov():
    """Blog: TFGaurd vs Checkov — head-to-head Terraform security scanner comparison"""
    meta = generate_meta_tags(
        title='TFGaurd vs Checkov: Which Terraform Security Scanner is Right for You? (2026)',
        description='An in-depth comparison of TFGaurd and Checkov for Terraform IaC security scanning. Compare rules coverage, ease of use, CI/CD integration, custom rules, and performance.',
        keywords='tfgaurd vs checkov, checkov vs tfgaurd, terraform security scanner comparison, iac security tools 2026, terraform static analysis, devsecops tools',
        article=True,
        author='TFGaurd Team',
        published_time='2026-03-21',
    )
    breadcrumbs = generate_breadcrumbs([("Home", "/"), ("Blog", "/blog"), ("TFGaurd vs Checkov", "/blog/tfgaurd-vs-checkov")])
    return render_template("frontend/blog_tfgaurd_vs_checkov.html", meta=meta, breadcrumbs=breadcrumbs)


@dashboard_bp.route("/blog/tfgaurd-vs-tfsec")
def blog_tfgaurd_vs_tfsec():
    """Compare: TFGaurd vs tfsec — Terraform security scanner comparison"""
    meta = generate_meta_tags(
        title='TFGaurd vs tfsec: Terraform Security Scanner Comparison (2026)',
        description='In-depth comparison of TFGaurd and tfsec for Terraform IaC security scanning. Compare rules, speed, CI/CD integration, custom checks, and the tfsec deprecation impact.',
        keywords='tfgaurd vs tfsec, tfsec vs tfgaurd, terraform security scanner, tfsec deprecated, trivy terraform, iac security 2026, devsecops tools',
        article=True,
        author='TFGaurd Team',
        published_time='2026-03-21',
    )
    breadcrumbs = generate_breadcrumbs([("Home", "/"), ("Blog", "/blog"), ("TFGaurd vs tfsec", "/blog/tfgaurd-vs-tfsec")])
    return render_template("frontend/blog_tfgaurd_vs_tfsec.html", meta=meta, breadcrumbs=breadcrumbs)


@dashboard_bp.route("/blog/best-terraform-security-scanner")
def blog_best_terraform_scanner():
    """Blog: Best Terraform Security Scanner — 2026 Roundup"""
    meta = generate_meta_tags(
        title='Best Terraform Security Scanner in 2026: Top 6 Tools Ranked',
        description='We tested and ranked the 6 best Terraform security scanners of 2026 — TFGaurd, Checkov, Trivy, Terrascan, Snyk IaC, and tfsec. See rules coverage, speed, CI/CD fit, and our editors pick.',
        keywords='best terraform security scanner, terraform security scanner 2026, terraform static analysis tools, iac security scanner, checkov vs tfsec, tfgaurd scanner, terraform compliance tool',
        article=True,
        author='TFGaurd Team',
        published_time='2026-03-21',
    )
    breadcrumbs = generate_breadcrumbs([("Home", "/"), ("Blog", "/blog"), ("Best Scanners", "/blog/best-terraform-security-scanner")])
    return render_template("frontend/blog_best_terraform_scanner.html", meta=meta, breadcrumbs=breadcrumbs)


@dashboard_bp.route("/blog/hcl-security-tool-delhi-ncr")
def blog_hcl_security_delhi():
    """Blog: Best budget-friendly HCL/Terraform security tool for Delhi-NCR companies"""
    meta = generate_meta_tags(
        title='Secure Your HCL / Terraform Code in Delhi-NCR: Best Budget-Friendly Tool for 2026',
        description='Are you a Delhi-NCR company using Terraform / HCL to manage cloud infrastructure? Discover TFGaurd — the most affordable, zero-setup Terraform security scanner with 1200+ rules.',
        keywords='HCL security tool Delhi, Terraform security scanner India, budget terraform scanner, infrastructure code security NCR, IaC security tool India, TFGaurd Delhi, terraform checker India, affordable cloud security tool',
        article=True,
        author='TFGaurd Team',
        published_time='2026-03-26',
    )
    breadcrumbs = generate_breadcrumbs([("Home", "/"), ("Blog", "/blog"), ("HCL Security Delhi", "/blog/hcl-security-tool-delhi-ncr")])
    return render_template("frontend/blog_hcl_security_delhi.html", meta=meta, breadcrumbs=breadcrumbs)


# ============================================================================
# HEALTH CHECK (No auth required)
# ============================================================================


@dashboard_bp.route("/health")
def health_check():
    """Health check endpoint for CI/CD and monitoring"""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat(),
    }


# ============================================================================
# ADMIN - SUPPORT MESSAGES
# ============================================================================


@dashboard_bp.route("/admin/messages")
@admin_required
def admin_messages():
    """Admin page: view all contact form messages with search, filter, pagination"""
    from sqlalchemy import or_

    PER_PAGE = 20

    search_q       = request.args.get("q", "").strip()
    status_filter  = request.args.get("status", "").strip()
    category_filter = request.args.get("category", "").strip()
    page           = max(1, int(request.args.get("page", 1)))

    with get_db_session() as session_db:
        query = session_db.query(ContactMessage)

        if search_q:
            like = f"%{search_q}%"
            query = query.filter(
                or_(
                    ContactMessage.name.ilike(like),
                    ContactMessage.email.ilike(like),
                    ContactMessage.message.ilike(like),
                )
            )
        if status_filter == "unread":
            query = query.filter(ContactMessage.is_read == False)
        elif status_filter == "read":
            query = query.filter(ContactMessage.is_read == True)

        if category_filter:
            query = query.filter(ContactMessage.category == category_filter)

        total        = query.count()
        unread_count = session_db.query(ContactMessage).filter(ContactMessage.is_read == False).count()
        total_pages  = max(1, (total + PER_PAGE - 1) // PER_PAGE)
        page         = min(page, total_pages)

        messages = (
            query.order_by(ContactMessage.created_at.desc())
            .offset((page - 1) * PER_PAGE)
            .limit(PER_PAGE)
            .all()
        )

        # Detach from session for template use
        session_db.expunge_all()

    return render_template(
        "admin/messages.html",
        messages=messages,
        total=total,
        unread_count=unread_count,
        page=page,
        per_page=PER_PAGE,
        total_pages=total_pages,
        search_q=search_q,
        status_filter=status_filter,
        category_filter=category_filter,
        admin_username=session.get('username', ''),
        admin_unread_msgs=unread_count,
    )


@dashboard_bp.route("/admin/messages/<int:msg_id>/mark-read", methods=["POST"])
@admin_required
def admin_message_mark_read(msg_id):
    """Mark a contact message as read (called by modal JS)"""
    with get_db_session() as session_db:
        msg = session_db.query(ContactMessage).filter_by(id=msg_id).first()
        if msg:
            msg.is_read = True
            session_db.commit()
    return jsonify({"success": True})
