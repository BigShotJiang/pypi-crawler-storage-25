from setuptools import setup, find_packages

setup(
    name="tfgaurd-engine",
    version="1.0.4",
    author="TFGaurd Team",
    author_email="support@tfgaurd.com",
    description="Secure, local-first Terraform security scanner with Cloud reporting.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://tfgaurd.com",
    packages=find_packages(),
    py_modules=["tfgaurd_cli"],
    install_requires=[
        "python-hcl2>=4.3.0",
        "requests>=2.31.0",
        "cryptography>=41.0.0",
    ],
    entry_points={
        "console_scripts": [
            "tfgaurd=tfgaurd_cli:main",
            "tfguard=tfgaurd_cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Security",
        "Intended Audience :: Developers",
    ],
    python_requires=">=3.8",
)
