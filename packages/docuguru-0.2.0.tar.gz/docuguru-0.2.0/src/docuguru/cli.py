import tomllib
from importlib.metadata import PackageNotFoundError, version as pkg_version
from importlib.resources import files
from pathlib import Path
from typing import Optional
from typer import Argument, Exit, Option, Typer

from docuguru.default import DEFAULT_CSS
from docuguru.html_to_pdf import HTMLToPDF
from docuguru.markdon_to_html import MarkdownToHTML

app = Typer(help="Herramienta para convertir documentos Markdown a PDF.")


def _version_callback(value: bool) -> None:
    if value:
        print(_tool_version())
        raise Exit()


@app.callback()
def _main(
    version: bool = Option(
        False,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Muestra la versión y termina.",
    ),
) -> None:
    pass


@app.command(name="convert")
def convert(
    markdown_file: str = Argument(help="Ruta al archivo Markdown a convertir."),
    output: Optional[str] = Option(
        None,
        "--output",
        "-o",
        help="Ruta del archivo PDF de salida. Si no se especifica, se usa el nombre del archivo Markdown con extensión .pdf",
    ),
    title: Optional[str] = Option(
        None,
        "--title",
        "-t",
        help="Título del documento. Si no se especifica, se extrae del primer h1 o se usa el nombre del archivo.",
    ),
    no_cover: bool = Option(
        False,
        "--no-cover",
        help="No incluir página de portada en el PDF.",
    ),
    no_toc: bool = Option(
        False,
        "--no-toc",
        help="No incluir tabla de contenidos en el PDF.",
    ),
    badge: Optional[str] = Option(
        None,
        "--badge",
        "-b",
        help="Texto del badge en la portada. Por defecto: 'Propuesta técnica'.",
    ),
    date: Optional[str] = Option(
        None,
        "--date",
        "-d",
        help="Fecha para la portada (ej: 'Diciembre 2025'). Si no se especifica, se usa la fecha actual.",
    ),
):
    """
    Convierte un archivo Markdown a PDF.

    Soporta títulos (h1-h6), tablas y listas ordenadas/no ordenadas.
    Genera un PDF con estilos predefinidos e incluye una página de portada por defecto.
    """
    markdown_to_html = MarkdownToHTML()
    body_html = markdown_to_html.convert_file(markdown_file)

    if title is None:
        title = _extract_title_from_html(body_html) or Path(markdown_file).stem

    if output is None:
        output = str(Path(markdown_file).with_suffix(".pdf"))

    html_to_pdf = HTMLToPDF()
    html_to_pdf.generate_pdf(
        body_html,
        title,
        DEFAULT_CSS,
        output,
        include_cover=not no_cover,
        cover_badge=badge if badge else "Propuesta técnica",
        cover_date=date,
        include_toc=not no_toc,
    )
    print(f"PDF generado exitosamente: {output}")


@app.command(name="blocks")
def list_blocks(
    output_file: Optional[str] = Option(
        None,
        "--output",
        "-o",
        help="Archivo donde guardar la documentación de bloques. Si no se especifica, se imprime en stdout.",
    ),
):
    """
    Muestra la documentación de todos los bloques HTML personalizados disponibles.

    Lista todos los componentes custom con ejemplos de uso y explicación.
    """
    blocks_doc = _load_blocks_documentation()

    if output_file:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(blocks_doc)
        print(f"Documentación guardada en: {output_file}")
    else:
        print(blocks_doc)


def _tool_version() -> str:
    try:
        return pkg_version("docuguru")
    except PackageNotFoundError:
        return _version_from_pyproject()


def _version_from_pyproject() -> str:
    pyproject = Path(__file__).resolve().parent.parent.parent / "pyproject.toml"
    if not pyproject.is_file():
        return "0.0.0"
    with pyproject.open("rb") as f:
        data = tomllib.load(f)
    return str(data["project"]["version"])


def _load_blocks_documentation() -> str:
    return (
        files("docuguru")
        .joinpath("blocks_documentation.md")
        .read_text(encoding="utf-8")
    )


def _extract_title_from_html(html: str) -> str:
    import re

    match = re.search(r"<h1[^>]*>(.*?)</h1>", html, re.IGNORECASE | re.DOTALL)
    if match:
        title_text = re.sub(r"<[^>]+>", "", match.group(1))
        return title_text.strip()
    return None
