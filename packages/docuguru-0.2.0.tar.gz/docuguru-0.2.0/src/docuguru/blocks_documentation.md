# Bloques HTML Personalizados Disponibles

## 1. Architecture Diagram

Muestra un diagrama de arquitectura centrado.

**Casos de uso:**

- Presentar la vista de alto nivel de un sistema (capas, servicios o integraciones).
- Ilustrar el flujo de datos o dependencias entre componentes en una propuesta o diseño.
- Acompañar la sección de arquitectura de un documento cuando el lector debe “ver” la estructura de una vez.

**Uso:**
```html
<div class="architecture-diagram">
    <img src="ruta/imagen.png" alt="Descripción" />
</div>
```

---

## 2. Info Card

Tarjeta informativa con bordes y sombras, ideal para fases o información destacada.

**Casos de uso:**

- Resumir una fase del proyecto, un alcance entregable o un criterio de aceptación.
- Destacar supuestos, riesgos o dependencias que el lector no debe pasar por alto.
- Agrupar un bloque corto de contexto (quién, qué, cuándo) junto a una sección larga de detalle.

**Uso:**
```html
<div class="info-card">
    <h3>Título</h3>
    <p><strong>Subtítulo en negrita</strong></p>
    <p>Información adicional</p>
    <p>Más detalles</p>
</div>
```

---

## 3. Timeline

Línea de tiempo vertical con items conectados.

**Casos de uso:**

- Mostrar hitos de implementación, entregas o revisiones en orden cronológico.
- Explicar una hoja de ruta o fases de un piloto frente a producción.
- Sustituir párrafos largos por una secuencia clara de eventos en propuestas y planes.

**Uso:**
```html
<div class="timeline">
    <div class="timeline-item">
        <strong>Título del Hito</strong>
        <p>Descripción del hito o fase</p>
    </div>
    <div class="timeline-item">
        <strong>Siguiente Hito</strong>
        <p>Otra descripción</p>
    </div>
</div>
```

---

## 4. Summary Cards

Tarjetas de resumen horizontales con valores destacados.

**Casos de uso:**

- Presentar cifras clave de inversión, plazos, volumen o KPIs en una sola mirada.
- Comparar magnitudes entre áreas, productos o escenarios sin entrar aún en el detalle.
- Abrir o cerrar una sección con un resumen ejecutivo numérico (presupuesto, esfuerzo, capacidad).

**Uso:**
```html
<div class="summary-cards">
    <div class="summary-card">
        <h3>Categoría</h3>
        <div class="value">$1.000.000</div>
        <div class="label">periodo</div>
    </div>
    <div class="summary-card">
        <h3>Otra Categoría</h3>
        <div class="value">500</div>
        <div class="label">unidades</div>
    </div>
</div>
```

---

## 5. Support Packages

Tarjetas de paquetes de servicios lado a lado.

**Casos de uso:**

- Ofrecer niveles de soporte, mantenimiento o SLA con precio y alcance diferenciados.
- Comparar planes de implementación (básico, estándar, premium) en una propuesta comercial.
- Mostrar qué incluye cada modalidad de servicio cuando el lector debe elegir una opción.

**Uso:**
```html
<div class="support-packages">
    <div class="package-card">
        <div class="package-header">
            <h3 class="package-name">Básico</h3>
            <div class="package-price">$500.000</div>
            <div class="package-price-label">mensual</div>
        </div>
        <ul class="package-features">
            <li class="no-style">Feature 1</li>
            <li class="no-style">Feature 2</li>
        </ul>
    </div>
    
    <div class="package-card featured">
        <div class="package-header">
            <span class="package-badge">Recomendado</span>
            <h3 class="package-name">Premium</h3>
            <div class="package-price">$1.200.000</div>
            <div class="package-price-label">mensual</div>
        </div>
        <ul class="package-features">
            <li class="no-style">Feature premium 1</li>
            <li class="no-style">Feature premium 2</li>
        </ul>
    </div>
</div>
```

**Nota:** Usa `class="featured"` para destacar un paquete.

---

## 6. Styled List

Lista con checkmarks personalizados (✔).

**Casos de uso:**

- Enumerar beneficios, entregables ya incluidos o criterios cumplidos de forma visualmente positiva.
- Listar requisitos satisfechos, capacidades del producto o ventajas frente a alternativas.
- Dar lectura rápida a conjuntos cortos de ítems donde cada punto debe percibirse como “hecho” o válido.

**Uso:**
```html
<ul class="styled-list">
    <li>Item 1 con checkmark</li>
    <li>Item 2 con checkmark</li>
    <li>Item 3 con checkmark</li>
</ul>
```

---

## 7. Warranty Notice

Bloque de aviso o garantía destacado con fondo azul claro.

**Casos de uso:**

- Explicitar garantías legales o de servicio, vigencia y condiciones en un bloque visible.
- Señalar exclusiones, limitaciones de responsabilidad o avisos legales sin mezclarlos con el cuerpo del texto.
- Resaltar compromisos formales (SLA, soporte post-entrega, políticas de corrección) al final de una sección crítica.

**Uso:**
```html
<div class="warranty-notice">
    <p><strong>Título del Aviso:</strong> Texto del aviso o garantía aquí.</p>
</div>
```

---

## Características Adicionales

### Listas Ordenadas Estilizadas

Las listas ordenadas (`<ol>`) se muestran con números en círculos azules automáticamente.

**Casos de uso:**

- Pasos de un procedimiento, metodología o checklist donde el orden importa.
- Enumerar fases secuenciales o prioridades en documentos formales o técnicos.
- Dar énfasis visual a una secuencia corta frente a listas largas de viñetas.

**Para desactivar el estilo:**
```html
<ol class="no-style">
    <li>Item con numeración estándar</li>
    <li>Otro item sin estilización</li>
</ol>
```

### Listas dentro de Package Features

Usa `class="no-style"` en cada `<li>` dentro de `package-features` para evitar los checkmarks:

**Casos de uso:**

- Listar características de un paquete sin el estilo de checkmarks de otras listas del documento.
- Diferenciar visualmente el contenido de tarjetas de precio del resto de listas con ✔.
- Evitar doble semántica cuando los ítems son neutros o descriptivos, no “completados”.

```html
<ul class="package-features">
    <li class="no-style">Sin checkmark</li>
</ul>
```

---

## Notas Importantes

1. Todos los bloques respetan `page-break-inside: avoid` para evitar cortes en medio del contenido.
2. Los colores utilizan variables CSS definidas en el tema (--primary, --accent, --accent-dark, etc.).
3. Los gradientes usan la paleta azul del tema (#7dd3fc, #3b82f6).
