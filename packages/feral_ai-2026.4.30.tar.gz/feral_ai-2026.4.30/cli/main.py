#!/usr/bin/env python3
"""
FERAL CLI — Interactive Terminal Agent
========================================
Connects to the FERAL Brain via the same WebSocket used by the web client.

Usage:
    feral                          # Interactive REPL
    feral "search the web for X"   # One-shot command
    feral status                   # System health
    feral devices                  # List connected hardware
    feral skills                   # List loaded skills
    feral identity                 # Show/edit agent identity
"""

import argparse
import asyncio
import json
import os
import shutil
import sys
from importlib import metadata as importlib_metadata
from pathlib import Path
from urllib.parse import urlparse

try:
    import websockets
except ImportError:
    print("websockets package required. Install: pip install websockets")
    sys.exit(1)

try:
    import httpx
except ImportError:
    httpx = None

from version import VERSION as __version__
from config.loader import feral_home
from config.runtime import (
    brain_bind_host,
    brain_port,
    brain_public_base_url,
    brain_public_host,
    brain_public_port,
    brain_public_scheme,
    brain_tls_enabled,
)


def _runtime_http_base() -> str:
    return brain_public_base_url().rstrip("/")


def _runtime_ws_url() -> str:
    parsed = urlparse(_runtime_http_base())
    ws_scheme = "wss" if parsed.scheme == "https" else "ws"
    port = f":{parsed.port}" if parsed.port else ""
    return f"{ws_scheme}://{parsed.hostname}{port}/v1/session"


WS_URL = _runtime_ws_url()
HTTP_BASE = _runtime_http_base()

BANNER = f"""
╔══════════════════════════════════════╗
║          F E R A L                    ║
║   Unleashed AI  v{__version__:<21s}║
╚══════════════════════════════════════╝
  Type a message to chat. Commands:
    /status   — system health
    /devices  — connected hardware
    /skills   — loaded skills
    /identity — agent identity
    /quit     — exit
"""


def _http_get(path: str) -> dict:
    """Quick synchronous HTTP GET to the Brain REST API."""
    if httpx:
        try:
            r = httpx.get(f"{HTTP_BASE}{path}", timeout=5)
            return r.json()
        except Exception as e:
            return {"error": str(e)}
    try:
        import urllib.request
        req = urllib.request.Request(f"{HTTP_BASE}{path}")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {"error": str(e)}


def _http_post(path: str, payload: dict) -> dict:
    """Synchronous HTTP POST — same URL base as _http_get."""
    if httpx:
        try:
            r = httpx.post(f"{HTTP_BASE}{path}", json=payload, timeout=10)
            try:
                return r.json()
            except Exception:
                return {"error": f"non-json {r.status_code}", "text": r.text}
        except Exception as e:
            return {"error": str(e)}
    try:
        import urllib.request
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            f"{HTTP_BASE}{path}", data=data, method="POST",
            headers={"content-type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {"error": str(e)}


def _http_delete(path: str) -> dict:
    """Synchronous HTTP DELETE."""
    if httpx:
        try:
            r = httpx.delete(f"{HTTP_BASE}{path}", timeout=10)
            try:
                return r.json()
            except Exception:
                return {"error": f"non-json {r.status_code}", "text": r.text}
        except Exception as e:
            return {"error": str(e)}
    try:
        import urllib.request
        req = urllib.request.Request(f"{HTTP_BASE}{path}", method="DELETE")
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {"error": str(e)}


def _installed_pkg_info() -> tuple[str, str]:
    """Return installed package version and location."""
    try:
        version = importlib_metadata.version("feral-ai")
        dist = importlib_metadata.distribution("feral-ai")
        location = str(dist.locate_file(""))
        return version, location
    except Exception:
        return "unknown", "unknown"


def cmd_status():
    data = _http_get("/api/dashboard")
    if "error" in data:
        print(f"  Error: {data['error']}")
        return
    print(f"  Sessions:   {data.get('session_count', '?')}")
    print(f"  Devices:    {data.get('device_count', '?')}")
    print(f"  Skills:     {data.get('skills_count', '?')}")
    print(f"  LLM:        {'ready' if data.get('llm_available') else 'not connected'}")
    print(f"  Audio:      {'ready' if data.get('audio_available') else 'off'}")
    print(f"  WASM:       {'ready' if data.get('wasm_available') else 'disabled'}")
    print(f"  Wake Word:  {'on' if data.get('wake_word_enabled') else 'off'}")
    sync = data.get("sync", {})
    print(f"  Sync:       {'running' if sync.get('running') else 'off'} ({sync.get('peer_count', 0)} peers)")
    mem = data.get("memory", {})
    print(f"  Memory:     {mem.get('notes', 0)} notes, {mem.get('episodes', 0)} episodes, {mem.get('knowledge_triples', 0)} knowledge")


def cmd_devices():
    data = _http_get("/api/devices")
    devices = data.get("devices", [])
    if not devices:
        print("  No devices connected.")
        return
    for d in devices:
        status = "connected" if d.get("connected") else "disconnected"
        print(f"  [{status}] {d.get('node_id', '?')} — {d.get('type', 'unknown')}")


def cmd_skills():
    data = _http_get("/skills")
    if isinstance(data, list):
        if not data:
            print("  No skills loaded.")
            return
        for s in data:
            print(f"  {s['name']} ({s['skill_id']}) — {s.get('endpoints', 0)} endpoints")
    else:
        print(f"  Error: {data.get('error', 'unknown')}")


def cmd_identity():
    data = _http_get("/api/identity")
    if "error" in data:
        print(f"  Error: {data['error']}")
        return
    print(f"  Name:        {data.get('name', '?')}")
    print(f"  Tagline:     {data.get('tagline', '?')}")
    print(f"  Personality: {data.get('personality', '?')}")
    rules = data.get("rules", [])
    if rules:
        print("  Rules:")
        for r in rules:
            print(f"    - {r}")
    style = data.get("communication_style", {})
    if style:
        print(f"  Style:       tone={style.get('tone', '?')}, verbosity={style.get('verbosity', '?')}")


async def repl():
    """Interactive REPL that chats with the Brain."""
    print(BANNER)
    uri = WS_URL
    try:
        _ws = None
        for _attempt in range(3):
            try:
                _ws = await websockets.connect(uri)
                break
            except Exception:
                if _attempt == 2:
                    raise
                print(f"  Connection failed (attempt {_attempt + 1}/3) — retrying...")
                await asyncio.sleep(2 ** _attempt)

        async with _ws as ws:
            greeting = await asyncio.wait_for(ws.recv(), timeout=5)
            msg = json.loads(greeting)
            if msg.get("payload", {}).get("text"):
                print(f"  FERAL: {msg['payload']['text']}\n")

            while True:
                try:
                    user_input = await asyncio.get_event_loop().run_in_executor(None, lambda: input("you > "))
                except (EOFError, KeyboardInterrupt):
                    print("\n  Goodbye!")
                    break

                text = user_input.strip()
                if not text:
                    continue

                if text.startswith("/"):
                    cmd = text.lower().split()[0]
                    if cmd in ("/quit", "/exit", "/q"):
                        print("  Goodbye!")
                        break
                    elif cmd == "/status":
                        cmd_status()
                    elif cmd == "/devices":
                        cmd_devices()
                    elif cmd == "/skills":
                        cmd_skills()
                    elif cmd == "/identity":
                        cmd_identity()
                    else:
                        print(f"  Unknown command: {cmd}")
                    continue

                await ws.send(json.dumps({
                    "type": "text_command",
                    "payload": {"text": text},
                }))

                full_response = ""
                while True:
                    try:
                        raw = await asyncio.wait_for(ws.recv(), timeout=30)
                    except asyncio.TimeoutError:
                        if full_response:
                            break
                        print("  (timeout waiting for response)")
                        break

                    msg = json.loads(raw)
                    mtype = msg.get("type", "")

                    if mtype == "stream_delta":
                        delta = msg.get("payload", {}).get("delta", "")
                        print(delta, end="", flush=True)
                        full_response += delta
                    elif mtype == "stream_end":
                        if full_response:
                            print()
                        break
                    elif mtype == "text_response":
                        text_resp = msg.get("payload", {}).get("text", "")
                        if text_resp:
                            print(f"  FERAL: {text_resp}")
                        break
                    elif mtype == "sdui":
                        print(f"  [UI Component: {msg.get('payload', {}).get('component', '?')}]")
                        break
                    elif mtype == "error":
                        print(f"  Error: {msg.get('payload', {}).get('message', '?')}")
                        break

                print()

    except ConnectionRefusedError:
        print(f"  Cannot connect to FERAL Brain at {uri}")
        print("  Make sure the Brain is running: feral serve")
        sys.exit(1)
    except Exception as e:
        print(f"  Connection error: {e}")
        sys.exit(1)


async def one_shot(text: str):
    """Send a single command and print the response."""
    try:
        _ws = None
        for _attempt in range(3):
            try:
                _ws = await websockets.connect(WS_URL)
                break
            except Exception:
                if _attempt == 2:
                    raise
                await asyncio.sleep(2 ** _attempt)

        async with _ws as ws:
            _ = await asyncio.wait_for(ws.recv(), timeout=5)

            await ws.send(json.dumps({
                "type": "text_command",
                "payload": {"text": text},
            }))

            while True:
                try:
                    raw = await asyncio.wait_for(ws.recv(), timeout=30)
                except asyncio.TimeoutError:
                    break

                msg = json.loads(raw)
                mtype = msg.get("type", "")

                if mtype == "stream_delta":
                    print(msg.get("payload", {}).get("delta", ""), end="", flush=True)
                elif mtype == "stream_end":
                    print()
                    break
                elif mtype == "text_response":
                    print(msg.get("payload", {}).get("text", ""))
                    break
                elif mtype == "error":
                    print(f"Error: {msg.get('payload', {}).get('message', '?')}", file=sys.stderr)
                    break

    except ConnectionRefusedError:
        print(f"Cannot connect to FERAL Brain at {WS_URL}", file=sys.stderr)
        sys.exit(1)


def _ensure_tls_certs():
    """Generate self-signed TLS certificate if none exists."""
    from config.runtime import brain_tls_cert, brain_tls_key
    cert_path = Path(brain_tls_cert())
    key_path = Path(brain_tls_key())

    if cert_path.exists() and key_path.exists():
        return str(cert_path), str(key_path)

    cert_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        import datetime
        import ipaddress

        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, "FERAL Brain"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "FERAL"),
        ])

        import socket
        hostname = socket.gethostname()

        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(datetime.datetime.utcnow())
            .not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=365))
            .add_extension(
                x509.SubjectAlternativeName([
                    x509.DNSName("localhost"),
                    x509.DNSName(hostname),
                    x509.IPAddress(ipaddress.ip_address("127.0.0.1")),
                ]),
                critical=False,
            )
            .sign(key, hashes.SHA256())
        )

        key_path.write_bytes(
            key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption())
        )
        cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))

        print(f"Generated self-signed TLS certificate at {cert_path}")
        return str(cert_path), str(key_path)
    except ImportError:
        print("Install 'cryptography' package for auto-generated TLS certs")
        return None, None


def cmd_serve(host: str | None = None, port: int | None = None, tls: bool = False):
    """Start the FERAL Brain server."""
    try:
        import uvicorn
    except ImportError:
        print("uvicorn not installed. Run: pip install 'feral-ai[all]'")
        sys.exit(1)

    core_root = str(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if core_root not in sys.path:
        sys.path.insert(0, core_root)

    host = host or brain_bind_host()
    port = int(port or brain_port())

    ssl_kwargs: dict = {}
    if tls or brain_tls_enabled():
        cert, key = _ensure_tls_certs()
        if cert and key:
            ssl_kwargs["ssl_certfile"] = cert
            ssl_kwargs["ssl_keyfile"] = key
        else:
            print("TLS requested but no certificates available")
            return

    scheme = "https" if ssl_kwargs else "http"
    public_base = os.getenv("FERAL_PUBLIC_BASE_URL", f"{scheme}://localhost:{port}")
    print(f"\n  Starting FERAL Brain on {host}:{port} {'(TLS)' if ssl_kwargs else ''}...")
    print(f"  Dashboard: {public_base}")
    print(f"  API docs:  {public_base}/docs\n")

    uvicorn.run("api.server:app", host=host, port=port, reload=False, log_level="info", **ssl_kwargs)


def _is_first_run() -> bool:
    """Check if this is the first time running FERAL.

    The canonical source is ``settings.json.meta.setup_complete`` — it
    gets set to ``True`` by the setup wizard + the REST ``POST
    /api/llm/config`` route on success. Fall back to the historical
    heuristics (env API key / non-empty credentials.json / Ollama
    provider in settings) so existing installs upgraded from older
    versions don't get a surprise wizard.

    Local-only setups (Ollama, LMStudio) used to re-run the wizard on
    every boot because ``credentials.json`` was empty — this branch
    handles that case explicitly via the provider lookup.
    """
    home_path = feral_home()
    settings_path = home_path / "settings.json"
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
            meta = settings.get("meta") or {}
            if meta.get("setup_complete"):
                return False
            llm = settings.get("llm") or {}
            provider = (llm.get("provider") or "").strip().lower()
            if provider in ("ollama", "lmstudio", "local") and llm.get("model"):
                return False
        except Exception:
            pass

    if os.environ.get("OPENAI_API_KEY") or os.environ.get("ANTHROPIC_API_KEY") \
       or os.environ.get("GOOGLE_API_KEY") or os.environ.get("GROQ_API_KEY"):
        return False

    creds_path = home_path / "credentials.json"
    if creds_path.exists():
        try:
            creds = json.loads(creds_path.read_text())
            if any(v for v in creds.values() if v):
                return False
        except Exception:
            pass

    return True


def cmd_start(port: int | None = None, no_browser: bool = False, tls: bool = False):
    """
    One command to rule them all.
    Starts the brain, checks health, opens browser, and drops into chat.
    If first run, launches setup wizard first.
    """
    import time
    import threading

    try:
        import uvicorn
    except ImportError:
        print("  Missing dependencies. Run: pip install 'feral-ai[llm]'")
        sys.exit(1)

    port = int(port or brain_port())

    ssl_kwargs: dict = {}
    if tls or brain_tls_enabled():
        cert, key = _ensure_tls_certs()
        if cert and key:
            ssl_kwargs["ssl_certfile"] = cert
            ssl_kwargs["ssl_keyfile"] = key
        else:
            print("TLS requested but no certificates available")
            return

    # First run detection — auto-launch setup
    if _is_first_run():
        print()
        print("  First time running FERAL? Let's set you up.\n")
        cmd_setup()
        print()

    # Check if already running
    try:
        scheme = "https" if ssl_kwargs else "http"
        health_url = os.getenv("FERAL_HEALTH_URL", f"{scheme}://127.0.0.1:{port}/health")
        if httpx:
            r = httpx.get(health_url, timeout=2, verify=False)
            if r.status_code == 200:
                print(f"  FERAL is already running on port {port}")
                if not no_browser:
                    _open_browser(port)
                asyncio.run(repl())
                return
    except Exception:
        pass

    tls_label = " (TLS)" if ssl_kwargs else ""
    print(f"""
  ╔══════════════════════════════════════╗
  ║          F E R A L                    ║
  ║   Starting agent on port {port}{tls_label:7s}  ║
  ╚══════════════════════════════════════╝
""")

    # Start server in background thread
    server_ready = threading.Event()

    def _run_server():
        import uvicorn
        config = uvicorn.Config(
            "api.server:app", host=brain_bind_host(), port=port,
            log_level="warning", access_log=False,
            **ssl_kwargs,
        )
        server = uvicorn.Server(config)
        server_ready.set()
        server.run()

    server_thread = threading.Thread(target=_run_server, daemon=True)
    server_thread.start()

    # Wait for server to be healthy.
    #
    # Cold-boot can easily take 30–60s on first run: LLM probe, embeddings
    # model download, mDNS discovery, channel start, Docker sandbox init...
    # FERAL_BOOT_TIMEOUT overrides for slow machines / CI.
    print("  Starting brain...", end="", flush=True)
    health_url = os.getenv("FERAL_HEALTH_URL", f"http://127.0.0.1:{port}/health")
    boot_report_url = f"http://127.0.0.1:{port}/api/boot-report"
    timeout_s = int(os.getenv("FERAL_BOOT_TIMEOUT", "90"))
    last_subsystem: str | None = None
    healthy = False
    for i in range(timeout_s):
        time.sleep(1)
        try:
            if httpx:
                r = httpx.get(health_url, timeout=2)
                if r.status_code == 200:
                    healthy = True
                    break
            else:
                import urllib.request
                urllib.request.urlopen(health_url, timeout=2)
                healthy = True
                break
        except Exception:
            pass

        subsystem = None
        try:
            if httpx:
                rr = httpx.get(boot_report_url, timeout=1.5)
                if rr.status_code == 200:
                    body = rr.json() or {}
                    subsystem = body.get("current") or (body.get("last") or {}).get("name")
        except Exception:
            subsystem = None

        if subsystem and subsystem != last_subsystem:
            print(f"\n    [{i+1}s] {subsystem}...", end="", flush=True)
            last_subsystem = subsystem
        else:
            print(".", end="", flush=True)

    if not healthy:
        print(f"\n  Failed to start after {timeout_s}s. Check logs or run: feral doctor")
        print("  Tip: FERAL_BOOT_TIMEOUT=180 feral start   # for slow first runs")
        sys.exit(1)

    # Print status
    data = _http_get("/api/dashboard")
    skills_count = data.get("skills_count", "?")
    llm_ok = "ready" if data.get("llm_available") else "no key"
    mem = data.get("memory", {})
    print("\n  Brain ready!")
    print(f"  LLM: {llm_ok} | Skills: {skills_count} | Memory: {mem.get('notes', 0)} notes")
    print(f"  Dashboard: {os.getenv('FERAL_PUBLIC_BASE_URL', f'http://localhost:{port}')}")

    if not no_browser:
        _open_browser(port)

    print()
    # Drop into interactive chat
    asyncio.run(repl())


def _open_browser(port: int):
    """Open the FERAL dashboard in the default browser."""
    try:
        import webbrowser
        url = os.getenv("FERAL_PUBLIC_BASE_URL", f"http://localhost:{port}")
        webbrowser.open(url)
    except Exception:
        pass


def cmd_doctor():
    """Run comprehensive diagnostics and report what's working."""
    try:
        from rich.console import Console
        from rich.panel import Panel
    except ImportError:
        print("rich is required for the doctor command: pip install rich")
        sys.exit(1)

    console = Console()
    passed = 0
    warnings = 0
    failures = 0
    fixes: list[str] = []

    def _pass(label: str, detail: str = ""):
        nonlocal passed
        passed += 1
        msg = f"[green]✔[/green]  {label}"
        if detail:
            msg += f"  [dim]{detail}[/dim]"
        console.print(msg)

    def _warn(label: str, detail: str = "", fix: str = ""):
        nonlocal warnings
        warnings += 1
        msg = f"[yellow]⚠[/yellow]  {label}"
        if detail:
            msg += f"  [dim]{detail}[/dim]"
        console.print(msg)
        if fix:
            fixes.append(fix)

    def _fail(label: str, detail: str = "", fix: str = ""):
        nonlocal failures
        failures += 1
        msg = f"[red]✘[/red]  {label}"
        if detail:
            msg += f"  [dim]{detail}[/dim]"
        console.print(msg)
        if fix:
            fixes.append(fix)

    console.print(Panel("[bold]FERAL Doctor[/bold] — installation health check", border_style="cyan"))
    console.print()

    # ── 1. Python version ──
    py_ver = sys.version_info
    ver_str = f"{py_ver.major}.{py_ver.minor}.{py_ver.micro}"
    if (py_ver.major, py_ver.minor) >= (3, 11):
        _pass("Python version", ver_str)
    else:
        _fail("Python version", f"{ver_str} (need >= 3.11)", "Install Python 3.11+: https://python.org")

    # ── 2. FERAL package importable ──
    try:
        pkg_version, pkg_location = _installed_pkg_info()
        if pkg_version != "unknown":
            _pass("FERAL package", f"feral-ai {pkg_version}  ({pkg_location})")
        else:
            _warn("FERAL package", "installed from source (no pip metadata)")
    except Exception as exc:
        _fail("FERAL package", str(exc), "pip install -e '.[all]'")

    # ── 3. Config directory ──
    home = feral_home()
    if home.exists() and home.is_dir():
        _pass("Config directory", str(home))
    else:
        _fail("Config directory", f"{home} does not exist", "Run: feral setup")

    # ── 4. Credentials — at least one LLM key or Ollama reachable ──
    llm_keys = [
        "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GOOGLE_API_KEY",
        "OPENROUTER_API_KEY", "DEEPSEEK_API_KEY", "GROQ_API_KEY",
    ]
    creds_data: dict = {}
    creds_path = home / "credentials.json"
    if creds_path.exists():
        try:
            creds_data = json.loads(creds_path.read_text())
        except Exception:
            pass

    has_llm_key = any(
        os.environ.get(k) or creds_data.get(k) for k in llm_keys
    )
    ollama_ok = False
    try:
        import urllib.request
        with urllib.request.urlopen("http://127.0.0.1:11434/api/version", timeout=2) as resp:
            if resp.status == 200:
                ollama_ok = True
    except Exception:
        pass

    if has_llm_key:
        providers = [k.replace("_API_KEY", "").replace("_", " ").title()
                     for k in llm_keys if os.environ.get(k) or creds_data.get(k)]
        _pass("LLM credentials", ", ".join(providers))
    elif ollama_ok:
        _pass("LLM credentials", "Ollama running locally")
    else:
        _fail("LLM credentials", "No API key and Ollama not reachable",
              "Run: feral setup  (or start Ollama: ollama serve)")

    # ── 5. Identity files — USER.md ──
    user_md = home / "USER.md"
    if user_md.exists():
        content = user_md.read_text().strip()
        if len(content) > 10:
            _pass("Identity (USER.md)", f"{len(content)} chars")
        else:
            _warn("Identity (USER.md)", "file exists but is nearly empty",
                  "Edit ~/.feral/USER.md with info about yourself")
    else:
        _warn("Identity (USER.md)", "not found — agent won't know who you are",
              "Run: feral setup  (creates ~/.feral/USER.md)")

    # ── 6. Memory database ──
    from config.loader import feral_data_home
    mem_db = feral_data_home() / "memory.db"
    if mem_db.exists():
        try:
            import sqlite3
            conn = sqlite3.connect(str(mem_db))
            conn.execute("SELECT 1")
            conn.close()
            size_kb = mem_db.stat().st_size // 1024
            _pass("Memory database", f"{mem_db}  ({size_kb} KB)")
        except Exception as exc:
            _fail("Memory database", f"exists but not accessible: {exc}",
                  "Check permissions on ~/.feral/memory.db")
    else:
        _warn("Memory database", "not created yet — will be created on first run")

    # ── 7. Port availability ──
    import socket
    port = int(brain_port())
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.settimeout(1)
        sock.connect(("127.0.0.1", port))
        sock.close()
        health = _http_get("/health")
        if "error" not in health:
            _pass("Port availability", f":{port} — FERAL brain already running")
        else:
            _warn("Port availability", f":{port} in use by another process",
                  f"Kill the process on port {port} or set FERAL_PORT to another value")
    except (ConnectionRefusedError, OSError):
        _pass("Port availability", f":{port} is free")
    finally:
        sock.close()

    # ── 8. Playwright / chromium ──
    try:
        from playwright.sync_api import sync_playwright
        pw = sync_playwright().start()
        try:
            browser = pw.chromium.launch(headless=True)
            browser.close()
            _pass("Playwright (chromium)", "installed and launchable")
        except Exception:
            _fail("Playwright (chromium)", "package found but chromium not installed",
                  "Run: playwright install chromium")
        finally:
            pw.stop()
    except ImportError:
        _warn("Playwright (chromium)", "not installed — browser automation unavailable",
              "pip install playwright && playwright install chromium")

    # ── 9. Node.js ──
    node_bin = shutil.which("node")
    if node_bin:
        import subprocess
        try:
            ver_out = subprocess.check_output([node_bin, "--version"], text=True).strip()
            major = int(ver_out.lstrip("v").split(".")[0])
            if major >= 20:
                _pass("Node.js", ver_out)
            else:
                _warn("Node.js", f"{ver_out} (recommend >= 20 for client dev)",
                      "Install Node 20+: https://nodejs.org")
        except Exception:
            _warn("Node.js", "found but could not determine version")
    else:
        _warn("Node.js", "not found — needed for client/webui development",
              "Install Node 20+: https://nodejs.org")

    # ── 10. Local audio backends ──
    console.print()
    console.print("[bold]Local Audio[/bold]")
    try:
        from perception.audio_pipeline import detect_local_audio_capabilities
        caps = detect_local_audio_capabilities()
        if caps["local_stt"]:
            _pass("Local STT (faster-whisper)", f"models: {', '.join(caps['stt_models'])}")
        else:
            _warn("Local STT (faster-whisper)", "not installed — cloud-only STT",
                  "pip install 'feral-ai[stt]'")
        if caps["local_tts"]:
            _pass("Local TTS (piper)", f"voices: {', '.join(caps['tts_voices'])}")
        else:
            _warn("Local TTS (piper)", "not installed — cloud-only TTS",
                  "pip install 'feral-ai[tts]'")
    except Exception as exc:
        _warn("Local Audio", f"detection failed: {exc}")

    # ── 11. Key dependencies ──
    console.print()
    console.print("[bold]Dependencies[/bold]")
    dep_pkgs = [
        ("fastapi", "FastAPI", True),
        ("uvicorn", "Uvicorn", True),
        ("websockets", "WebSockets", True),
        ("httpx", "HTTPX", True),
        ("pydantic", "Pydantic", True),
    ]
    for pkg, label, critical in dep_pkgs:
        try:
            __import__(pkg)
            _pass(label, "importable")
        except ImportError:
            if critical:
                _fail(label, "not installed", f"pip install {pkg}")
            else:
                _warn(label, "not installed")

    # ── Summary ──
    console.print()
    parts = []
    if passed:
        parts.append(f"[green]{passed} passed[/green]")
    if warnings:
        parts.append(f"[yellow]{warnings} warnings[/yellow]")
    if failures:
        parts.append(f"[red]{failures} failures[/red]")
    console.print(Panel(", ".join(parts), title="Summary", border_style="cyan"))

    if fixes:
        console.print()
        console.print("[bold]Suggested fixes:[/bold]")
        for i, fix in enumerate(fixes, 1):
            console.print(f"  {i}. {fix}")
        console.print()


def cmd_setup(*, browser: bool = False, terminal: bool = False):
    """Launch the guided setup wizard, then auto-generate a session token.

    When ``browser=True`` the CLI opens http://localhost:9090/setup in
    the default browser so the user gets the v2 /setup page instead of
    the terminal. Requires the brain to be running.
    """
    if browser and not terminal:
        _open_browser_setup()
        # Even in browser mode we still want a session token for the
        # server-side auth layer; generate it now.
    else:
        try:
            from cli.setup import run_setup
            run_setup()
        except ImportError:
            print("Setup wizard not available.")
            sys.exit(1)

    from security.session_auth import generate_session_token, save_session_token, load_session_token
    if load_session_token() is None:
        token = generate_session_token()
        save_session_token(token)
        print(f"  Session token generated: {token[:8]}...{token[-4:]}")
        print(f"  Stored in {feral_home() / 'session_token'}")


def _open_browser_setup() -> None:
    """Open http://localhost:9090/setup in the default browser."""
    import webbrowser
    url = f"{_runtime_http_base()}/setup"
    print(f"  Opening {url} in your browser...")
    print("  (Start the brain first with `feral serve` if you see a connection error.)")
    try:
        webbrowser.open(url)
    except Exception as exc:
        print(f"  Could not open browser: {exc}")
        print(f"  Paste this into your browser instead: {url}")


def cmd_pair(name: str, list_devices: bool, revoke: str, prune: int = -1):
    """Manage per-node device pairing."""
    from security.device_pairing import DevicePairingStore

    store = DevicePairingStore()

    if list_devices:
        devices = store.list_devices()
        if not devices:
            print("  No paired devices.")
            return
        for d in devices:
            import datetime
            ts = datetime.datetime.fromtimestamp(d["paired_at"]).strftime("%Y-%m-%d %H:%M")
            seen = ""
            if d["last_seen"]:
                seen = f", last seen {datetime.datetime.fromtimestamp(d['last_seen']).strftime('%Y-%m-%d %H:%M')}"
            print(f"  {d['device_id'][:12]}...  {d['name']:20s}  paired {ts}{seen}")
        return

    if revoke:
        ok = store.revoke_device(revoke)
        if ok:
            print(f"  Revoked device {revoke}")
        else:
            print(f"  Device {revoke} not found.")
        return

    if prune >= 0:
        result = store.revoke_unclaimed(older_than_seconds=float(prune))
        print(f"  Pruned {result['pruned']} unclaimed pairings (kept {result['kept']}).")
        for row in result["rows"]:
            print(f"    - {row}")
        return

    if not name:
        name = "unnamed"
    result = store.pair_device(name)
    print(f"  Device paired: {result['name']}")
    print(f"  Device ID:     {result['device_id']}")
    print(f"  Token:         {result['token']}")
    print()
    qr_data = f"feral-pair://{result['token']}"
    print(f"  QR data: {qr_data}")
    print("  Pass the token as ?api_key=<token> when connecting to /v1/node")


def cmd_wake_test():
    """Test wake word detection from the microphone for 10 seconds."""
    print("\n  Wake Word Test")
    print("  " + "=" * 40)

    try:
        import openwakeword
    except ImportError:
        print("  openwakeword not installed.")
        print("  Install: pip install 'feral-ai[wake]'")
        print("  (Downloads ~50 MB model on first use)")
        sys.exit(1)

    from perception.wake_word import WakeWordDetector, WakeWordConfig
    detector = WakeWordDetector(WakeWordConfig(enabled=True))
    ml_mode = "ML (openwakeword)" if detector._oww_model else "Energy-based fallback"
    print(f"  Mode:   {ml_mode}")
    print(f"  Phrase: {detector._config.phrase}")
    model_name = os.environ.get("FERAL_WAKE_MODEL", "hey_jarvis_v0.1")
    print(f"  Model:  {model_name}")
    print("\n  Listening for 10 seconds... Say the wake phrase!\n")

    try:
        import pyaudio
    except ImportError:
        print("  pyaudio not installed — needed for mic access.")
        print("  Install: pip install pyaudio")
        sys.exit(1)

    import struct
    import time

    pa = pyaudio.PyAudio()
    stream = pa.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True, frames_per_buffer=1280)
    start = time.time()
    detections = 0

    try:
        while time.time() - start < 10:
            pcm = stream.read(1280, exception_on_overflow=False)
            result = asyncio.get_event_loop().run_until_complete(
                detector.process_frame("test", pcm)
            ) if asyncio.get_event_loop().is_running() else asyncio.run(
                detector.process_frame("test", pcm)
            )
            if result and detector.get_state("test").value == "activated":
                detections += 1
                elapsed = time.time() - start
                print(f"  [{elapsed:.1f}s] WAKE WORD DETECTED! (#{detections})")
                detector.force_deactivate("test")
            remaining = 10 - (time.time() - start)
            if int(remaining) % 3 == 0 and remaining > 0:
                pass
    except KeyboardInterrupt:
        pass
    finally:
        stream.stop_stream()
        stream.close()
        pa.terminate()

    print(f"\n  Done. Detections: {detections}")
    if detections == 0 and not detector._oww_model:
        print("  Tip: Install openwakeword for better detection: pip install openwakeword onnxruntime")


def cmd_marketplace(action: str, query: str, registry: str | None = None):
    """Marketplace CLI commands.

    ``install`` delegates to :mod:`cli.install`, which talks directly to
    the FERAL registry (default ``https://registry.feral.sh``) with
    Ed25519 signature verification. ``search``/``list`` still hit the
    local Brain's marketplace proxy.
    """
    if action == "search":
        q = query or "all"
        data = _http_get(f"/api/marketplace/search?q={q}")
        results = data.get("results", [])
        if not results:
            print("  No skills found.")
            return
        for s in results:
            print(f"  {s.get('name', s.get('skill_id', '?'))} — {s.get('description', '')[:60]}")
    elif action == "install":
        if not query:
            print("  Usage: feral marketplace install <item_id>")
            return
        from cli.install import cmd_install
        cmd_install(query, registry=registry)
    elif action == "list":
        data = _http_get("/api/marketplace/installed")
        skills = data.get("skills", [])
        if not skills:
            print("  No marketplace skills installed.")
            return
        for s in skills:
            print(f"  {s.get('name', s.get('skill_id', '?'))} v{s.get('version', '?')}")


def cmd_sync(action: str, file_path: str):
    """Federated sync CLI commands."""
    if action == "status":
        data = _http_get("/api/sync/status")
        if "error" in data:
            print(f"  Error: {data['error']}")
            return
        print(f"  Enabled:     {data.get('enabled', False)}")
        print(f"  Running:     {data.get('running', False)}")
        print(f"  Node ID:     {data.get('node_id', '?')}")
        print(f"  Peers:       {data.get('peer_count', 0)}")
        vc = data.get("vector_clock", {})
        if vc:
            print(f"  Clock:       {json.dumps(vc, indent=2)}")
    elif action == "peers":
        data = _http_get("/api/sync/status")
        peers = data.get("peers", [])
        if not peers:
            print("  No peers discovered.")
        else:
            for p in peers:
                print(f"  - {p}")
    elif action == "export":
        out = file_path or "feral_memory_export.json"
        data = _http_get("/api/sync/status")
        if data.get("enabled"):
            print(f"  Exporting memory bundle to {out}...")
            import urllib.request
            req = urllib.request.Request(f"{HTTP_BASE}/api/sync/export")
            try:
                with urllib.request.urlopen(req, timeout=30) as resp:
                    bundle = resp.read()
                    with open(out, "wb") as f:
                        f.write(bundle)
                    print(f"  Exported to {out}")
            except Exception as e:
                print(f"  Export failed: {e}")
        else:
            print("  Sync engine not running.")
    elif action == "import":
        if not file_path:
            print("  Usage: feral sync import <file.json>")
            return
        print(f"  Importing from {file_path}...")
        try:
            with open(file_path) as f:
                bundle = json.load(f)
            import urllib.request
            req = urllib.request.Request(
                f"{HTTP_BASE}/api/sync/import",
                data=json.dumps(bundle).encode(),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read())
                print(f"  Imported {result.get('applied', 0)} operations")
        except Exception as e:
            print(f"  Import failed: {e}")


def _apply_connection_args(args):
    global WS_URL, HTTP_BASE
    host = getattr(args, "host", None) or brain_public_host()
    port = str(getattr(args, "port", None) or brain_public_port())
    http_scheme = "https" if brain_public_scheme() == "https" else "http"
    ws_scheme = "wss" if http_scheme == "https" else "ws"
    origin = f"{host}:{port}"
    WS_URL = f"{ws_scheme}://{origin}/v1/session"
    HTTP_BASE = f"{http_scheme}://{origin}"


def main():
    parser = argparse.ArgumentParser(
        description="FERAL — Open AI agent with computer use, voice, GenUI, and hardware control",
        usage="feral [command] [options]",
    )
    parser.add_argument("--host", default=None, help="Brain hostname")
    parser.add_argument("--port", default=None, help="Brain port")

    sub = parser.add_subparsers(dest="subcommand")

    # feral start (THE main command)
    start_p = sub.add_parser("start", help="Start FERAL — brain + dashboard + chat in one command")
    start_p.add_argument("--serve-port", default=str(brain_port()), help=f"Port (default {brain_port()})")
    start_p.add_argument("--no-browser", action="store_true", help="Don't open browser")
    start_p.add_argument("--tls", action="store_true", help="Enable TLS (auto-generates self-signed cert if needed)")
    start_p.add_argument("--demo", action="store_true", help=argparse.SUPPRESS)

    # feral demo (shortcut for start --demo)
    demo_p = sub.add_parser("demo", help=argparse.SUPPRESS)
    demo_p.add_argument("--scenario", default="", choices=["", "morning", "developer", "mesh"], help="Run a specific demo scenario")
    demo_p.add_argument("--serve-port", default=str(brain_port()), help=f"Port (default {brain_port()})")

    # feral serve (headless server only)
    serve_p = sub.add_parser("serve", help="Start the brain server (headless, no chat)")
    serve_p.add_argument("--bind", default=brain_bind_host(), help=f"Bind address (default {brain_bind_host()})")
    serve_p.add_argument("--serve-port", default=str(brain_port()), help=f"Port (default {brain_port()})")
    serve_p.add_argument("--tls", action="store_true", help="Enable TLS (auto-generates self-signed cert if needed)")

    # feral setup — terminal or browser
    setup_p = sub.add_parser(
        "setup", help="Guided setup wizard — configure provider, keys, features",
    )
    setup_mode = setup_p.add_mutually_exclusive_group()
    setup_mode.add_argument(
        "--terminal", action="store_true", dest="setup_terminal",
        help="Stay in the terminal (default when no browser is available).",
    )
    setup_mode.add_argument(
        "--browser", action="store_true", dest="setup_browser",
        help="Open http://localhost:9090/setup in a browser window.",
    )

    # feral doctor
    sub.add_parser("doctor", help="Run diagnostics — check deps, keys, brain health")

    # feral status / devices / skills / identity
    sub.add_parser("status", help="Show system health")
    sub.add_parser("devices", help="List connected hardware")
    sub.add_parser("skills", help="List loaded skills")
    sub.add_parser("identity", help="Show agent identity")

    # feral pair
    pair_p = sub.add_parser("pair", help="Manage per-node device pairing tokens")
    pair_p.add_argument("--name", default="", help="Friendly name for the device")
    pair_p.add_argument("--list", action="store_true", dest="list_devices", help="List paired devices")
    pair_p.add_argument("--revoke", default="", help="Revoke a device by ID")
    pair_p.add_argument(
        "--prune",
        type=int,
        default=-1,
        metavar="SECONDS",
        help="Bulk-revoke unclaimed pair tokens older than N seconds (0 = all)",
    )

    # feral wake-test
    sub.add_parser("wake-test", help="Test wake word detection from your microphone")

    # feral marketplace
    mp = sub.add_parser("marketplace", help="Skill marketplace commands")
    mp.add_argument("action", nargs="?", default="search", choices=["search", "install", "list"], help="Action")
    mp.add_argument("query", nargs="?", default="", help="Search query or item ID")
    mp.add_argument("--registry", default=None, help="Override registry base URL (default: https://registry.feral.sh)")

    # feral install <item_id> — direct registry install
    inst_p = sub.add_parser("install", help="Install a published item from the FERAL registry")
    inst_p.add_argument("item_id", help="Registry item id (from 'feral publish' output)")
    inst_p.add_argument("--registry", default=None, help="Override registry base URL (default: https://registry.feral.sh)")

    # feral publish --skill <dir> | --daemon <dir>
    pub_p = sub.add_parser("publish", help="Publish a skill or daemon bundle to the FERAL registry")
    pub_group = pub_p.add_mutually_exclusive_group(required=True)
    pub_group.add_argument("--skill", dest="skill_dir", default=None, help="Path to a skill directory with manifest.json")
    pub_group.add_argument("--daemon", dest="daemon_dir", default=None, help="Path to a daemon directory with manifest.json")
    pub_p.add_argument("--registry", default=None, help="Override registry base URL (default: https://registry.feral.sh)")

    # feral publisher login|register
    pubr_p = sub.add_parser("publisher", help="Manage FERAL publisher credentials")
    pubr_p.add_argument("action", choices=["login", "register"], help="login | register")
    pubr_p.add_argument("--registry", default=None, help="Override registry base URL (default: https://registry.feral.sh)")

    # feral sync
    sp = sub.add_parser("sync", help="Federated memory sync commands")
    sp.add_argument("action", nargs="?", default="status", choices=["status", "peers", "export", "import"], help="Action")
    sp.add_argument("file", nargs="?", default="", help="File path for export/import")

    # feral memory — backend selector
    mem_p = sub.add_parser("memory", help="Memory backend management")
    mem_p.add_argument(
        "action",
        choices=["status", "switch", "list"],
        help="status: show current backend | list: installed backends | switch <id>: select backend",
    )
    mem_p.add_argument(
        "backend_id",
        nargs="?",
        default=None,
        help="Backend id for `switch` (e.g. sqlite_vec, chroma, qdrant)",
    )

    # feral install-service / uninstall-service
    sub.add_parser("install-service", help="Install FERAL Brain as a system daemon (launchd/systemd)")
    sub.add_parser("uninstall-service", help="Remove the FERAL Brain system daemon")

    # feral twin — manage digital-twin policies + approvals
    twin_p = sub.add_parser("twin", help="Manage the digital twin's per-domain policies + approvals")
    twin_sub = twin_p.add_subparsers(dest="action")
    twin_grant = twin_sub.add_parser("grant", help="Grant / update a twin domain policy")
    twin_grant.add_argument("domain", help="respond_imessage / draft_email / …")
    twin_grant.add_argument("--draft-only", dest="twin_mode_draft", action="store_true")
    twin_grant.add_argument("--auto-send", dest="twin_mode_auto", action="store_true")
    twin_grant.add_argument("--disabled", dest="twin_mode_disabled", action="store_true")
    twin_grant.add_argument("--window", dest="twin_windows", action="append", default=[],
                            help="HH:MM-HH:MM (repeatable)")
    twin_grant.add_argument("--max-per-day", type=int, default=10)
    twin_grant.add_argument("--requires-user-online", action="store_true")
    twin_sub.add_parser("list", help="List every twin policy on this brain")
    twin_revoke = twin_sub.add_parser("revoke", help="Remove a twin policy")
    twin_revoke.add_argument("domain")
    twin_sub.add_parser("pending", help="List pending twin-approval queue rows")

    # feral bridge install — wraps scripts/install-phone-bridge.sh
    bridge_p = sub.add_parser("bridge", help="Install the FERAL phone-bridge daemon on this host")
    bridge_sub = bridge_p.add_subparsers(dest="action")
    bridge_install = bridge_sub.add_parser("install", help="Install + start the phone-bridge daemon")
    bridge_install.add_argument("--token", required=True, help="Pairing token from Pair modal > Daemon token")
    bridge_install.add_argument("--brain-url", required=True, help="ws://host:port/v1/node")
    bridge_install.add_argument("--node-id", default="", help="Stable node id (defaults to hostname)")
    bridge_install.add_argument("--prefix", default="", help="Install prefix (default ~/.feral/phone-bridge)")

    # feral app ...
    try:
        from cli.app_commands import register_app_subparser
        register_app_subparser(sub)
    except Exception:
        pass

    # Parse known args — everything else is treated as a message
    args, remaining = parser.parse_known_args()
    _apply_connection_args(args)

    if args.subcommand == "demo":
        os.environ["FERAL_DEV_DEMO"] = "1"
        if getattr(args, "scenario", ""):
            os.environ["FERAL_DEMO_SCENARIO"] = args.scenario
        cmd_start(port=int(args.serve_port), no_browser=False)
    elif args.subcommand == "start":
        if getattr(args, "demo", False):
            os.environ["FERAL_DEV_DEMO"] = "1"
        cmd_start(port=int(args.serve_port), no_browser=args.no_browser, tls=getattr(args, "tls", False))
    elif args.subcommand == "serve":
        cmd_serve(host=args.bind, port=int(args.serve_port), tls=getattr(args, "tls", False))
    elif args.subcommand == "setup":
        cmd_setup(
            browser=getattr(args, "setup_browser", False),
            terminal=getattr(args, "setup_terminal", False),
        )
    elif args.subcommand == "doctor":
        cmd_doctor()
    elif args.subcommand == "status":
        cmd_status()
    elif args.subcommand == "devices":
        cmd_devices()
    elif args.subcommand == "skills":
        cmd_skills()
    elif args.subcommand == "identity":
        cmd_identity()
    elif args.subcommand == "pair":
        cmd_pair(
            name=getattr(args, "name", ""),
            list_devices=getattr(args, "list_devices", False),
            revoke=getattr(args, "revoke", ""),
            prune=getattr(args, "prune", -1),
        )
    elif args.subcommand == "wake-test":
        cmd_wake_test()
    elif args.subcommand == "marketplace":
        cmd_marketplace(args.action, args.query, registry=getattr(args, "registry", None))
    elif args.subcommand == "install":
        from cli.install import cmd_install
        cmd_install(args.item_id, registry=getattr(args, "registry", None))
    elif args.subcommand == "publish":
        from cli.publish import cmd_publish
        cmd_publish(
            skill_dir=getattr(args, "skill_dir", None),
            daemon_dir=getattr(args, "daemon_dir", None),
            registry=getattr(args, "registry", None),
        )
    elif args.subcommand == "publisher":
        from cli.publish import cmd_publisher_login, cmd_publisher_register
        if args.action == "login":
            cmd_publisher_login(registry=getattr(args, "registry", None))
        else:
            cmd_publisher_register(registry=getattr(args, "registry", None))
    elif args.subcommand == "sync":
        cmd_sync(args.action, getattr(args, "file", ""))
    elif args.subcommand == "memory":
        from cli.memory_cmd import cmd_memory
        cmd_memory(args.action, getattr(args, "backend_id", None))
    elif args.subcommand == "install-service":
        from cli.daemon import install_service
        install_service()
    elif args.subcommand == "uninstall-service":
        from cli.daemon import uninstall_service
        uninstall_service()
    elif args.subcommand == "app":
        from cli.app_commands import dispatch_app_subcommand
        dispatch_app_subcommand(args)
    elif args.subcommand == "bridge":
        from cli.bridge_commands import cmd_bridge
        cmd_bridge(args)
    elif args.subcommand == "twin":
        from cli.twin_commands import cmd_twin
        cmd_twin(args)
    elif args.subcommand is None and not remaining:
        asyncio.run(repl())
    else:
        full_text = " ".join([args.subcommand or ""] + remaining).strip()
        if full_text:
            asyncio.run(one_shot(full_text))
        else:
            asyncio.run(repl())


if __name__ == "__main__":
    main()
