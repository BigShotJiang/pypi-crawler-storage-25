# tools-cicd
share cicd scripts

# Running tool locally

## Example:
```shell
AWS_PROFILE=dev-admin-terraform poetry run cicd --help
```

# Release Procedures
- This project uses "trunk" based development off of `master`.
- PRs are allowed but always folded back to `master`.
- For now, releasing is manual, no automation.
- **To release**:
  - Ensure all your features are ready on `master`
    - *You should not have any staged changes!*
  - In a terminal run `make version v={major|minor|patch}`
    - **Do not include a number! Poetry will auto-rev the value accordingly**
  - That's it
    - This will create a new tag in Git ready for use


# Multi-Repository Release Coordination

The `quest-v2` project includes a coordinated release script that allows you to trigger deployments across all related Quest v2 repositories simultaneously, rather than having to manually trigger each repository's release workflow individually.

### Prerequisites

1. **GitHub CLI**: Install the GitHub CLI tool
   ```bash
   # macOS
   brew install gh
   
   # Ubuntu/Debian
   sudo apt install gh
   
   # Windows
   winget install GitHub.cli
   ```

2. **Authentication**: Authenticate with GitHub
   ```bash
   gh auth login
   ```

3. **Script Setup**: Navigate to the quest-v2 directory and make the script executable
   ```bash
   cd quest-v2
   chmod +x release-all.sh
   ```

### Usage

From the `quest-v2` directory, the script supports promoting from `develop` to `qa`:

```bash
# Promote to QA
./release-all.sh

# Show help and options
./release-all.sh --help
```

### What it does

The script will:
1. Trigger the "Release" workflow on all three Quest v2 repositories:
   - `allfly-quest-ui`
   - `allfly-quest-core-api`
   - `gds-api`
2. Promote code from `develop` branch to `qa`
3. Provide real-time status updates and links to monitor progress
4. Display a summary of successful and failed releases

### Monitoring

After triggering the releases, you can monitor progress through:
- The provided GitHub Actions URLs in the script output
- GitHub's Actions tab in each repository
- Your configured Slack notifications (if enabled)

> **Note**: The script requires appropriate permissions to trigger workflows on all three Quest v2 repositories. Ensure your GitHub account has the necessary access rights.