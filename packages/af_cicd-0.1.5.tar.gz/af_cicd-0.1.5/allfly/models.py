import json
import os
from dataclasses import dataclass, field

from allfly.config import BRANCH_RULES_MATRIX, BranchDeploymentConfig


@dataclass
class DeploymentRules:
    rules: list[BranchDeploymentConfig]

    def to_pretty_json(self):
        return json.dumps(self,
                          default=lambda o: o.__dict__,
                          indent=4)

    @staticmethod
    def from_json(json_str):
        rules_list = json.loads(json_str)
        deployment = DeploymentRules([])
        for rule in rules_list:
            deployment.rules.append(BranchDeploymentConfig(**rule))
        return deployment

    def find_config_rule_by_branch(self, source) -> BranchDeploymentConfig:
        for rule in self.rules:
            if rule.branch == source:
                return rule
        raise Exception(f"no rule for source {source}")

    def assert_valid_git_promotion(self, source, target):
        staging_promotion_enabled = os.environ.get('CICD_STAGING_PROMOTION_ENABLED', 'true').lower()
        if (source == 'qa' and target == 'staging' and 
            staging_promotion_enabled in ['false', '0', 'off']):
            raise Exception("Staging is temporarily locked for Promotion until next official release")
        
        source_rule: BranchDeploymentConfig = self.find_config_rule_by_branch(target)
        if not source_rule.can_be_promoted_from(source):
            raise Exception(f"{source} can't be promoted to {target}")

    def assert_build_only_branch(self, current_branch):
        source_rule: BranchDeploymentConfig = self.find_config_rule_by_branch(current_branch)
        if not source_rule.is_build_only_branch():
            raise Exception(f"{current_branch} doesn't support build_only")

    def get_branch_target_environment(self, current_branch):
        source_rule: BranchDeploymentConfig = self.find_config_rule_by_branch(current_branch)
        return source_rule.target_environment

    def get_branch_docker_tag(self, current_branch):
        source_rule: BranchDeploymentConfig = self.find_config_rule_by_branch(current_branch)
        return source_rule.docker_tag

    def assert_build_and_deploy_branch(self, branch):
        source_rule: BranchDeploymentConfig = self.find_config_rule_by_branch(branch)
        if source_rule.type != 'build_and_deploy':
            raise Exception(f"{branch} doesn't support deploy_and_build")

    def assert_promote_and_deploy_branch(self, branch):
        source_rule: BranchDeploymentConfig = self.find_config_rule_by_branch(branch)
        if source_rule.type != 'promote_and_deploy':
            raise Exception(f"{branch} doesn't support promote_and_deploy")

    def get_sanitize_branch_name(self, source_branch: str):
        """
        This allows us to treat a `hotfix/qa/** | hotfix/staging/**` branch
        as a named static hotfix branch
        """
        sanitized_source = source_branch

        if "hotfix/qa" in source_branch.lower():
            sanitized_source = "hotfix/qa"

        if "hotfix/staging" in source_branch.lower():
            sanitized_source = "hotfix/staging"

        return sanitized_source


@dataclass
class DeploymentContext:
    app_name: str
    current_branch_name: str
    ecr_account_id: str
    current_config_rule: BranchDeploymentConfig
    iac_path: str = None
    iac_var_path: str | None = None
    version_string: str = None
    git_hash: str = None
    is_cicd: bool = False
    for_arm: bool = False
    previous_branch_config_rule: BranchDeploymentConfig | None = None
    pre_deploy_tasks: list[str] = field(default_factory=list)


@dataclass()
class CicdContext:
    repository: str
    branch: str
    commit_message: str
    server_url: str
    run_id: str

    def __init__(self):
        # https://docs.github.com/en/actions/writing-workflows/choosing-what-your-workflow-does/store-information-in-variables
        self.repository = os.environ.get('GITHUB_REPOSITORY')
        self.branch = os.environ.get('GITHUB_REF_NAME')
        self.commit_message = os.environ.get('GITHUB_COMMIT_MESSAGE', '')
        self.server_url = os.environ.get('GITHUB_SERVER_URL', 'https://github.com')
        self.run_id = os.environ.get('GITHUB_RUN_ID')

    def get_build_url(self):
        return f"{self.server_url}/{self.repository}/actions/runs/{self.run_id}"


def build_branch_deployment_config():
    return DeploymentRules(rules=BRANCH_RULES_MATRIX)
