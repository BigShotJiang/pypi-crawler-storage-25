from dataclasses import dataclass
from typing import List


@dataclass
class BranchDeploymentConfig:
    branch: str
    type: str
    promotable_sources: List[str]
    docker_tag: str
    target_environment: str
    previous_environment_rule: str

    def can_be_promoted_from(self, source: str):
        return source in self.promotable_sources

    def is_build_only_branch(self) -> bool:
        return self.type == 'build_only'


BRANCH_RULES_MATRIX: List[BranchDeploymentConfig] = [
    BranchDeploymentConfig(
        branch="develop",
        type="build_and_deploy",
        promotable_sources=[],
        docker_tag="develop",
        target_environment="dev",
        previous_environment_rule=""
    ),
    BranchDeploymentConfig(
        branch="qa",
        type="promote_and_deploy",
        promotable_sources=["develop", "hotfix/qa"],
        docker_tag="qa",
        target_environment="qa",
        previous_environment_rule="develop"
    ),
    BranchDeploymentConfig(
        branch="hotfix/qa",
        type="build_only",
        promotable_sources=[],
        docker_tag="hotfix.qa",
        target_environment="",
        previous_environment_rule=""
    ),
    BranchDeploymentConfig(
        branch="staging",
        type="promote_and_deploy",
        promotable_sources=["qa", "hotfix/staging"],
        docker_tag="staging",
        target_environment="staging",
        previous_environment_rule="qa"
    ),
    BranchDeploymentConfig(
        branch="hotfix/staging",
        type="build_only",
        promotable_sources=[],
        docker_tag="hotfix.staging",
        target_environment="",
        previous_environment_rule=""
    ),
    BranchDeploymentConfig(
        branch="master",
        type="promote_and_deploy",
        promotable_sources=["staging"],
        docker_tag="production",
        target_environment="production",
        previous_environment_rule="staging"
    )
]


def resolve_environment(env: str | None = None, target: str | None = None) -> str:
    """
    Resolve environment from either env or target branch.
    
    Args:
        env: Direct environment name (takes precedence)
        target: Target branch name to resolve to environment
        
    Returns:
        Resolved environment name
        
    Raises:
        ValueError: If neither parameter is provided or target cannot be resolved
    """
    resolved_env = env
    if not resolved_env and target:
        matching_rule = next((rule for rule in BRANCH_RULES_MATRIX if rule.branch == target), None)
        if matching_rule:
            resolved_env = matching_rule.target_environment
        if not resolved_env:
            raise ValueError(f"Could not resolve target branch '{target}' to an environment")
    
    if not resolved_env:
        raise ValueError("Either env or target must be provided")
    
    return resolved_env
