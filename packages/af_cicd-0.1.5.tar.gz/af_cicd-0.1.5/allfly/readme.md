# Allfly CICD Tooling

WIP: This is here temporarily. Our goal is to make these part of an Allfly Dev Toolset independent of repositories.

In other words, this code should not be inside of this repository!

## Promotion Matrix

Commits:
- develop -> build docker and deploy to develop
- qa -> promote from develop and deploy to qa
- staging -> promote from qa and deploy to staging
- master -> promote from staging and deploy to production
- qa-hotfix -> build docker and deploy to qa
- staging-hotfix -> build 


## Act

### Run Tests

```shell
act --container-architecture linux/amd64 -j run-tests --env-file <(aws configure export-credentials --profile dev-admin-terraform --format env)
```


