import os
import shlex
import subprocess

import inquirer
import typer

from allfly.models import CicdContext

###
# It's the drawer in the kitchen with all the useful junk

ECR_ACCOUNT_ID = '878395696414'
PWD = os.getcwd()


def run_command(func):
    try:
        func
    except Exception as e:
        exit_with_error(repr(e))


def build_cli_app():
    return typer.Typer(
        help='''Building blocks to be used as part of a CI/CD pipeline, or run locally''',
        no_args_is_help=True,
        rich_markup_mode=None
    )


def select_branch() -> str:
    selected = inquirer.list_input(
        'Select environment',
        choices=['devops', 'develop', 'qa', 'staging', 'master', 'hotfix', 'other'],
    )
    return selected


def run_shell_command(command: str):
    """
    shlex.split() is used to split the command string into a list of arguments, which is what subprocess actually wants
    check=True will raise a CalledProcessError if the command returns a non-zero exit code

    TODO: I wish we could print out in real-time and also capture output
    """
    env = {}
    env.update(os.environ)
    subprocess.run(shlex.split(command), check=True, env=env)


def run_checked_shell_command(command: str, check=True, capture_output=False):
    """
    Run a shell command with improved flexibility and output handling.

    Args:
        command: The command string to execute
        check: Whether to raise an exception on non-zero exit code
        capture_output: Whether to capture and return the command's output

    Returns:
        The command's stdout output as string if capture_output is True,
        otherwise an empty string
    """
    env = {}
    env.update(os.environ)

    try:
        if capture_output:
            result = subprocess.run(
                shlex.split(command),
                check=check,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            return result.stdout
        else:
            subprocess.run(shlex.split(command), check=check, env=env)
            return ""
    except subprocess.CalledProcessError as e:
        if not check:
            # If we're not checking for errors, just return empty string on failure
            print(f"warning: {e.stderr}")
            return ""
        else:
            # Re-raise the exception
            raise

def dir_not_exists(iac_path):
    return not os.path.exists(f"{PWD}/{iac_path}")


def capture_command_output(command: str):
    """
    check_output captures the output of the command and returns it as a byte string, rather than
    printing it to the console
    """
    ps = subprocess.check_output(shlex.split(command))
    ps = ps.replace(b'\n', b'').decode('utf-8').strip()
    return ps


def get_or_text_prompt(value: str | None, prompt: str) -> str:
    return value if value else inquirer.text(prompt)


def get_exit_code(command: str):
    return subprocess.run(
        shlex.split(command),
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode

def is_cicd() -> CicdContext | None:
    return os.environ.get('CICD')

def stdout(msg: str):
    message = typer.style(msg, fg=typer.colors.GREEN)
    typer.echo(message)

def shellout(msg: str):
    message = typer.style(msg, fg=typer.colors.CYAN)
    typer.echo(message)

def stderr(msg: str):
    message = typer.style(msg, fg=typer.colors.RED)
    typer.echo(message)


def exit_with_error(message: str):
    stderr(message)
    raise typer.Exit(code=1)
