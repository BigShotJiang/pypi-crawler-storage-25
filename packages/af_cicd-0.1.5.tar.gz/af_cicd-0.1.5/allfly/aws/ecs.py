from typing_extensions import deprecated

import boto3
from allfly.aws.ssm import AwsSSM
from allfly.utils import run_shell_command, stdout, exit_with_error


class AwsEcs:
    ssm: AwsSSM

    def __init__(self):
        self.ssm = AwsSSM()

    @deprecated("here are backup in case TF based deployments don't pan out")
    def deploy_image_tag_to_ecs_app(self, app_name: str, tag: str):
        service_id = self.ssm.get_ssm_param_value(f"/infra/services/{app_name}/ecs/cluster_id")
        cluster_id = self.ssm.get_ssm_param_value(f"/infra/services/{app_name}/ecs/service_id")
        stdout(f"Deploying to ecs {cluster_id} {service_id} {tag}")
        run_shell_command(
            f'ecs deploy {cluster_id} {service_id} --tag {tag}'
        )

    def run_pre_deploy_task(self, app_name: str, task_family: str, new_image_url: str) -> None:
        """
        Run a one-off ECS Fargate task before the main service deployment.

        Runs the latest revision of task_family — the targeted terraform apply
        in Phase 1 already registered a new revision with the correct image.
        Clones network configuration from the running service so no extra
        SSM params are needed.

        Raises a hard exit if the task fails to start or exits non-zero.
        """
        cluster_id = self.ssm.get_ssm_param_value(f"/infra/services/{app_name}/ecs/cluster_id")
        service_name = self.ssm.get_ssm_param_value(f"/infra/services/{app_name}/ecs/service_id")

        client = boto3.client("ecs")

        # Clone network config from the live service — keeps subnets/SGs consistent
        services_response = client.describe_services(cluster=cluster_id, services=[service_name])
        services = services_response.get("services", [])
        if not services:
            exit_with_error(f"Could not find ECS service '{service_name}' in cluster '{cluster_id}'")
        network_config = services[0]["networkConfiguration"]

        stdout(f"Running pre-deploy task '{task_family}' with image {new_image_url}")

        run_response = client.run_task(
            cluster=cluster_id,
            taskDefinition=task_family,
            launchType="FARGATE",
            networkConfiguration=network_config,
        )

        failures = run_response.get("failures", [])
        tasks = run_response.get("tasks", [])
        if failures or not tasks:
            exit_with_error(f"Failed to start pre-deploy task '{task_family}': {failures}")

        task_arn = tasks[0]["taskArn"]
        stdout(f"Pre-deploy task started: {task_arn} — waiting for completion...")

        waiter = client.get_waiter("tasks_stopped")
        waiter.wait(
            cluster=cluster_id,
            tasks=[task_arn],
            WaiterConfig={"Delay": 10, "MaxAttempts": 60},  # up to 10 minutes
        )

        describe_response = client.describe_tasks(cluster=cluster_id, tasks=[task_arn])
        container = describe_response["tasks"][0]["containers"][0]
        exit_code = container.get("exitCode")

        if exit_code != 0:
            exit_with_error(
                f"Pre-deploy task '{task_family}' failed with exit code {exit_code}. "
                f"Halting deployment."
            )

        stdout(f"Pre-deploy task '{task_family}' completed successfully.")
