import os

import boto3

from allfly.utils import get_exit_code, run_shell_command, stdout


class AWSCore:

    @staticmethod
    def get_current_user_region():
        current_session = boto3.session.Session()
        current_region = (
            current_session.region_name if current_session.region_name else "us-east-1"
        )
        stdout(f"Current region: {current_region}")
        return current_region

    @staticmethod
    def is_aws_profile_is_active(profile: str):
        return get_exit_code(f'aws s3 ls --profile {profile}') == 0

    @staticmethod
    def setup_aws_creds(cicd: bool = False):
        """
        In CI/CD environments, there are no AWS profiles, so we don't need to set the AWS_PROFILE environment variable
        """
        aws_profile = os.environ.get('AWS_PROFILE', None)
        stdout(f"AWS_PROFILE is set to: {aws_profile}")
        if aws_profile and not cicd:
            # If the AWS profile is not active, re-authenticate with AWS
            if not AWSCore.is_aws_profile_is_active(aws_profile):
                stdout(
                    f'AWS profile {aws_profile} is not active. Re-authenticating with AWS...'
                )
                run_shell_command(f'aws sso login --profile {aws_profile}')
