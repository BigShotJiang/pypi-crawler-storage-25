import boto3
from botocore.client import BaseClient

from allfly.utils import stdout, stderr


class AwsEcr:
    ecr: BaseClient

    def __init__(self):
        self.ecr = boto3.client("ecr")

    @staticmethod
    def build_ecr_image_url(app_name: str, image_tag: str, ecr_account_id: str) -> str:
        return f"{ecr_account_id}.dkr.ecr.us-east-1.amazonaws.com/{app_name}:{image_tag}"

    def promote_ecr_docker_tag(
            self, app_name: str, ecr_account_id: str, source_branch_tag: str, target_branch_tag: str
    ) -> str:
        """
        Re-tag an ECR image without having to pull and push.
        Based on https://docs.aws.amazon.com/AmazonECR/latest/userguide/image-retag.html

        return the full image URL of the container to be used in the next environment
        """
        stdout("Re-tagging image...")

        # First, we need to get all associated images for the source (from) environment
        associated_version_tag = self.get_next_image_tag(
            ecr_account_id=ecr_account_id,
            app_name=app_name,
            source_branch_tag=source_branch_tag
        )

        # Now, we need to get the imageManifest; unfortunately, another call
        get_image_response = self.ecr.batch_get_image(
            registryId=ecr_account_id,
            repositoryName=app_name,
            imageIds=[{"imageTag": associated_version_tag}],
        )
        images = get_image_response.get("images")
        if not images:
            raise Exception(
                f"Failed to get image, could not find image with tag {source_branch_tag}"
            )

        image = images[0]
        image_manifest = image.get("imageManifest")

        # Now, we re-tag for AWS (to) environment
        stdout(f"Re-tagging {associated_version_tag} now to {target_branch_tag}")
        try:
            self.ecr.put_image(
                registryId=ecr_account_id,
                repositoryName=app_name,
                imageManifest=image_manifest,
                imageTag=target_branch_tag,
            )
        except self.ecr.exceptions.ImageAlreadyExistsException as e:
            stderr(f"Image tag already {target_branch_tag} exists with that manifest, that's okay.")

        return self.build_ecr_image_url(
            app_name=app_name,
            image_tag=associated_version_tag,
            ecr_account_id=ecr_account_id,
        )

    def get_next_image_tag(self,
                           ecr_account_id: str,
                           app_name: str,
                           source_branch_tag: str):
        """
        the purpose of this function is to get the image tag that is associated with the previous environment

         for example:  from develop to qa, one might see
         found associated tag develop
         found associated tag v.2025.01.13.212928.18

         v.2025.01.13.212928.18 would be returned to promote to qa
        """
        describe_image_response = self.ecr.describe_images(
            registryId=ecr_account_id,
            repositoryName=app_name,
            imageIds=[{"imageTag": source_branch_tag}],
        )

        # To do things right, we need to get the v. version associated with the previous environment so it's passed
        # on to the next environment
        stdout(f"looking for versioned image associated to tag {source_branch_tag}")
        image_details = describe_image_response.get("imageDetails")
        if not image_details:
            raise Exception(
                f"Failed to describe image for {source_branch_tag}; no images returned"
            )

        aws_image = image_details[0]

        associated_version_tag = None
        image_tags = aws_image.get("imageTags")
        for tag in image_tags:
            stdout(f"found associated tag {tag}")
            if tag.startswith("v."):
                associated_version_tag = tag

        if not associated_version_tag:
            raise Exception(
                f"Could not find associated version tag for {source_branch_tag}! Something is wrong."
            )

        return associated_version_tag