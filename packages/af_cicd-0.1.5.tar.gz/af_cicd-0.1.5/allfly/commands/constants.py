import os

import typer

CICD_OPTION = typer.Option(
        default_factory=lambda: True if os.environ.get("CICD") else False,
        help="Run in CICD mode. Can also be set via CICD environment variable."
    )