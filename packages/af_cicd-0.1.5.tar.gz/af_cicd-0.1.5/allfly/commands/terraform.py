import inquirer

from allfly.aws.core import AWSCore
from allfly.utils import run_shell_command, exit_with_error, dir_not_exists, stdout


# TODO too much duplication around the same code, need to figure out a way to abstract some of this


def exec_infra_as_code_for_ecs_app(iac_path: str,
                                   env: str,
                                   ecs_tag: str,
                                   var_path: str | None = None,
                                   plan_only: bool = False,
                                   auto_apply: bool = False,
                                   targets: list[str] | None = None):
    stdout(f"Executing infra for {env}...")

    iac_path = f"iac/{iac_path}"
    if dir_not_exists(iac_path):
        exit_with_error(f"iac path not found {iac_path}")

    AWSCore.setup_aws_creds()

    run_shell_command(
        f'terraform -chdir={iac_path} init -backend-config=./backends/{env}.tfbackend -reconfigure -upgrade'
    )

    var_file_base = ".." if not var_path else var_path
    common_var_file = f"{var_file_base}/common.tfvars"
    env_var_file = f"{var_file_base}/{env}.tfvars"
    base_vars = f"-var-file={common_var_file} -var-file={env_var_file} -var=ecs_tag_to_deploy={ecs_tag}"
    target_flags = " ".join(f"-target={t}" for t in targets) if targets else ""

    if auto_apply:
        stdout("Running auto-apply")
        cmd = f"terraform -chdir={iac_path} apply {base_vars} {target_flags} -auto-approve"
        stdout(cmd)
        run_shell_command(cmd)
    else:
        stdout("Running plan")
        cmd = f"terraform -chdir={iac_path} plan {base_vars} {target_flags} -out={env}.tfplan"
        stdout(cmd)
        run_shell_command(cmd)
        if not plan_only and inquirer.confirm(
                f'Plan saved to {env}.tfplan. Apply the changes?'
        ):
            run_shell_command(
                f"terraform -chdir={iac_path} apply -auto-approve {env}.tfplan"
            )

def exec_infra_as_code(iac_path: str,
                       var_path: str | None = None,
                       env: str = None,
                       plan_only: bool = False,
                       auto_apply: bool = False):
    print(f"Executing infra for {env}...")

    iac_path = f"iac/{iac_path}"
    if dir_not_exists(iac_path):
        exit_with_error(f"iac path not found {iac_path}")

    AWSCore.setup_aws_creds()

    run_shell_command(
        f'terraform -chdir={iac_path} init -backend-config=./backends/{env}.tfbackend -reconfigure -upgrade'
    )

    var_file_base = ".." if not var_path else var_path
    common_var_file = f"{var_file_base}/common.tfvars"
    env_var_file = f"{var_file_base}/{env}.tfvars"

    if auto_apply:
        run_shell_command(
            f"""
            terraform -chdir={iac_path} apply -var-file={common_var_file} -var-file={env_var_file} -auto-approve
            """
        )
    else:
        run_shell_command(
            f"""
            terraform -chdir={iac_path} plan -var-file={common_var_file} -var-file={env_var_file} -out={env}.tfplan
            """
        )
        if not plan_only and inquirer.confirm(
                f'Plan saved to {env}.tfplan. Apply the changes?'
        ):
            run_shell_command(
                f"terraform -chdir={iac_path} apply -auto-approve {env}.tfplan"
            )
