import os

from allfly.aws.ecr import AwsEcr
from allfly.utils import run_shell_command, ECR_ACCOUNT_ID, capture_command_output, stdout


def generate_local_image_name(app_name: str, version_string: str) -> str:
    return f"{app_name}:{version_string}"


def build_local_image(app_name: str, version_string: str, git_hash: str, for_arm: bool = False) -> str:
    stdout("Building Docker image...")

    local_image = generate_local_image_name(app_name, version_string)

    # Build up a string of `--build-arg="KEY=value"` arguments to pass to the docker build command
    build_args_list = [
        {"key": "ENV_APP_NAME", "value": app_name},
        {"key": "ENV_VERSION", "value": version_string},
        {"key": "ENV_HASH", "value": git_hash},
    ]
    build_args = [f'--build-arg="{ba["key"]}={ba["value"]}"' for ba in build_args_list]
    build_args_str = " ".join(build_args)

    ssh_arg = "--ssh default" if os.environ.get("SSH_AUTH_SOCK") else ""

    if for_arm:
        # First ensure buildx is configured (that's a dependency on the build system)
        run_shell_command("docker buildx create --use")

        cache_from = os.environ.get("DOCKER_BUILDX_CACHE_FROM", None)
        cache_to = os.environ.get("DOCKER_BUILDX_CACHE_TO", None)
        load_push = os.environ.get("DOCKER_BUILDX_LOAD_PUSH", "load")

        if load_push == "push":
            load_push = "--push"
        else:
            load_push = "--load"

        # Support multiple cache scopes (multiline environment variables)
        cache_from_args = []
        cache_to_args = []
        
        if cache_from:
            # Split by newlines and filter empty lines
            cache_from_entries = [line.strip() for line in cache_from.strip().split('\n') if line.strip()]
            cache_from_args = [f'--cache-from="{entry}"' for entry in cache_from_entries]
            
        if cache_to:
            # Split by newlines and filter empty lines  
            cache_to_entries = [line.strip() for line in cache_to.strip().split('\n') if line.strip()]
            cache_to_args = [f'--cache-to="{entry}"' for entry in cache_to_entries]
            
        # Combine all cache arguments
        caches_args = " ".join(cache_from_args + cache_to_args)
        
        # Debug output for cache configuration
        if caches_args:
            stdout(f"🔧 Cache arguments: {caches_args}")
        else:
            stdout("⚠️  No cache configuration found")

        # Build the multi-platform image
        run_shell_command(
            f"docker buildx build . {ssh_arg} --provenance=false --platform=linux/arm64 {build_args_str} {load_push} -t {local_image} {caches_args}"
        )
    else:
        run_shell_command(
            f"docker build . {ssh_arg} --platform=linux/x86_64 {build_args_str} -t {local_image}"
        )
    stdout(f"Docker image '{local_image}' built successfully.")
    return local_image


def tag_and_push_docker_images_from_local(
        app_name: str,
        local_image: str,
        version_string: str,
        environment_tag: str,
        ecr_account_id: str = ECR_ACCOUNT_ID,
):
    """
    this expects the local image to be present!
    """
    stdout("Deploying Docker image...")

    version_image_url = AwsEcr.build_ecr_image_url(
        app_name=app_name, image_tag=version_string, ecr_account_id=ecr_account_id
    )
    environment_image_url = AwsEcr.build_ecr_image_url(
        app_name=app_name, image_tag=environment_tag, ecr_account_id=ecr_account_id
    )

    docker_password = capture_command_output(
        "aws ecr get-login-password --region us-east-1"
    )
    run_shell_command(
        f"docker login --username AWS --password {docker_password} {version_image_url}"
    )

    run_shell_command(f"docker tag {local_image} {version_image_url}")
    run_shell_command(f"docker tag {local_image} {environment_image_url}")

    run_shell_command(f"docker push {version_image_url}")
    run_shell_command(f"docker push {environment_image_url}")

    stdout("Docker images pushed successfully.")
