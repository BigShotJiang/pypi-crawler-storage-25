from allfly.aws.ecr import AwsEcr
from allfly.aws.ecs import AwsEcs
from allfly.aws.lambdas import AwsLambda
from allfly.utils import get_or_text_prompt, ECR_ACCOUNT_ID, stdout


def promote_ecr_docker_tag(app_name: str, ecr_account_id: str, source_branch_tag: str, target_branch_tag: str):
    ecr = AwsEcr()
    return ecr.promote_ecr_docker_tag(
        app_name=app_name, ecr_account_id=ecr_account_id, source_branch_tag=source_branch_tag, target_branch_tag=target_branch_tag
    )


def deploy_image_tag_to_ecs_app(app_name: str, tag: str):
    ecs = AwsEcs()
    ecs.deploy_image_tag_to_ecs_app(app_name, tag)


def update_lambda_image(
        app_name: str, ecr_account_id: str = ECR_ACCOUNT_ID, image_tag: str = None
):
    stdout("Deploying Lambda function...")
    image_tag = get_or_text_prompt(image_tag, "Image tag string")
    image_url = AwsEcr.build_ecr_image_url(
        app_name=app_name, image_tag=image_tag, ecr_account_id=ecr_account_id
    )
    AwsLambda().update_lambda_image_with_image_url(app_name=app_name, image_url=image_url)
    stdout("Lambda function deployed successfully.")


def get_next_image_tag(app_name: str, ecr_account_id: str, env: str):
    next_tag = AwsEcr().get_next_image_tag(
        app_name=app_name, ecr_account_id=ecr_account_id, source_branch_tag=env
    )
    stdout(f"Next image tag for {env} is {next_tag}")


def run_pre_deploy_task(app_name: str, task_family: str, new_image_url: str) -> None:
    AwsEcs().run_pre_deploy_task(app_name=app_name, task_family=task_family, new_image_url=new_image_url)
