import os
import random

from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError


class SlackClient:
    FAILURE_EMOJIS = [
        ":boom:", ":fire:", ":scream:", ":skull:", ":sos:", ":no_entry_sign:",
        ":small_airplane:", ":warning:", ":rotating_light:", ":zap:", ":cloud:", ":bangbang:",
        ":heavy_exclamation_mark:", ":anger:", ":exclamation:", ":interrobang:", ":-1:",
        ":face_with_head_bandage:", ":face_with_thermometer:", ":sob:",
        ":dizzy_face:", ":triumph:", ":grimacing:", ":frowning:", ":confounded:", ":cold_sweat:",
        ":unamused:", ":thumbsdown:", ":japanese_ogre:", ":japanese_goblin:",
        ":see_no_evil:", ":hear_no_evil:", ":speak_no_evil:", ":loudspeaker:"
    ]

    def __init__(self):
        self.builds_channel = os.environ.get('SLACK_BUILDS_CHANNEL')
        self.releases_channel = os.environ.get('SLACK_RELEASES_CHANNEL')
        print(self.builds_channel)
        self.token = os.environ.get('SLACK_BOT_TOKEN')
        if not self.token:
            raise Exception("SLACK_BOT_TOKEN is not set")

        self.client = WebClient(token=self.token)

    def send_build_failure_notification(
            self,
            repository: str,
            branch: str,
            commit_message: str,
            run_url: str
    ) -> None:
        """
        Send a build failure notification to Slack.
        """
        random_emoji = random.choice(self.FAILURE_EMOJIS)
        message = (
            ":boom: *Build Failed!* :boom:\n"
            f"*Repository:* {repository}\n"
            f"*Branch:* {branch}\n"
            f"*Commit Message:* {commit_message}\n"
            f"{random_emoji} <{run_url}|View Build Details>"
        )

        try:
            if self.builds_channel:
                self.client.chat_postMessage(
                    channel=self.builds_channel,
                    text=message,
                    mrkdwn=True
                )
        except SlackApiError as e:
            raise Exception(f"Failed to send Slack message: {str(e)}")

    def send_release_notification(
                self,
                repository: str,
                version: str) -> None:
            celebration_emoji = random.choice([":tada:", ":rocket:", ":sparkles:", ":airplane:", ":ship:"])
            message = (
                f"{celebration_emoji} *RELEASE DEPLOYED* {celebration_emoji}\n"
                f"\n"
                f"📦 *System:* `{repository}`\n"
                f"🏷️ *Version:* `{version}`\n"
            )

            try:
                if self.releases_channel:
                    self.client.chat_postMessage(
                        channel=self.releases_channel,
                        text=message,
                        mrkdwn=True
                    )
            except SlackApiError as e:
                raise Exception(f"Failed to send Slack message: {str(e)}")
