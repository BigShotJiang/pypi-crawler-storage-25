from allfly.aws.ecr import AwsEcr
from allfly.commands import aws, docker, terraform
from allfly.models import DeploymentContext
from allfly.utils import stdout


# #
# # Lambda Deployment Orchestrations
# #
#
# def lambda_build_and_deploy(context: DeploymentContext):
#     stdout(f"Building and deploying for env: {context.current_branch_name}")
#     # do this first to fail fast
#     local_image = docker.build_local_image(context.app_name, context.version_string, context.git_hash)
#
#     terraform.exec_infra_as_code(
#         iac_path=context.iac_path, env=context.get_environment(), plan_only=False, auto_apply=True
#     )
#
#     docker.tag_and_push_docker_images_from_local(
#         app_name=context.app_name,
#         local_image=local_image,
#         version_string=context.version_string,
#         environment=context.current_branch_name,
#         ecr_account_id=context.ecr_account_id,
#     )
#
#     aws.update_lambda_image(
#         app_name=context.app_name,
#         ecr_account_id=context.ecr_account_id,
#         image_tag=context.version_string,
#     )
#     stdout("Done")
#
#
# def lambda_promote_and_deploy(context: DeploymentContext):
#     previous_branch: str = context.get_next_lower_environment_branch()
#     stdout(f"Promoting from {previous_branch} to {context.current_branch_name}")
#
#     terraform.exec_infra_as_code(env=context.get_environment(), plan_only=False, auto_apply=True)
#     tagged_image_url = aws.promote_ecr_docker_tag(
#         app_name=context.app_name,
#         ecr_account_id=context.ecr_account_id,
#         source_branch=previous_branch,
#         target_branch=context.current_branch_name,
#     )
#     AwsLambda().update_lambda_image_with_image_url(
#         app_name=context.app_name, image_url=tagged_image_url
#     )
#     stdout("Done")


#
# ECS Orchestration
#


def ecs_build_and_deploy(context: DeploymentContext):
    stdout("Running ECS Build And Deploy")
    stdout(repr(context))
    local_image = docker.build_local_image(app_name=context.app_name,
                                           for_arm=context.for_arm,
                                           version_string=context.version_string,
                                           git_hash=context.git_hash)

    docker.tag_and_push_docker_images_from_local(
        app_name=context.app_name,
        local_image=local_image,
        version_string=context.version_string,
        environment_tag=context.current_config_rule.docker_tag,
        ecr_account_id=context.ecr_account_id
    )

    if context.pre_deploy_tasks:
        # Convention: "migrations" → tf target "aws_ecs_task_definition.migrations"
        #                          → ECS task family "{app_name}-migrations"
        tf_targets = [f"aws_ecs_task_definition.{name}" for name in context.pre_deploy_tasks]

        # Phase 1: ensure pre-deploy task definitions are up to date before running them.
        terraform.exec_infra_as_code_for_ecs_app(
            env=context.current_config_rule.target_environment,
            ecs_tag=context.version_string,
            iac_path=context.iac_path,
            var_path=context.iac_var_path,
            targets=tf_targets,
            auto_apply=True,
        )

        image_url = AwsEcr.build_ecr_image_url(
            app_name=context.app_name,
            image_tag=context.version_string,
            ecr_account_id=context.ecr_account_id,
        )
        for name in context.pre_deploy_tasks:
            aws.run_pre_deploy_task(context.app_name, f"{context.app_name}-{name}", image_url)

    # Phase 2 (or only phase when no pre-deploy tasks): full infrastructure + service update.
    terraform.exec_infra_as_code_for_ecs_app(
        env=context.current_config_rule.target_environment,
        ecs_tag=context.version_string,
        iac_path=context.iac_path,
        var_path=context.iac_var_path,
        auto_apply=True
    )


def ecs_promote_and_deploy(context: DeploymentContext) -> str:
    previous_branch_docker_tag = context.previous_branch_config_rule.docker_tag
    new_docker_tag = context.current_config_rule.docker_tag

    stdout(f"ECR Promoting from {previous_branch_docker_tag} to {new_docker_tag}")

    new_image_url = aws.promote_ecr_docker_tag(
        app_name=context.app_name,
        ecr_account_id=context.ecr_account_id,
        source_branch_tag=previous_branch_docker_tag,
        target_branch_tag=new_docker_tag
    )
    next_ecs_tag = new_image_url.split(":")[-1]

    if context.pre_deploy_tasks:
        tf_targets = [f"aws_ecs_task_definition.{name}" for name in context.pre_deploy_tasks]

        # Phase 1: ensure pre-deploy task definitions are up to date before running them.
        terraform.exec_infra_as_code_for_ecs_app(
            env=context.current_config_rule.target_environment,
            ecs_tag=next_ecs_tag,
            iac_path=context.iac_path,
            var_path=context.iac_var_path,
            targets=tf_targets,
            auto_apply=True,
        )

        for name in context.pre_deploy_tasks:
            aws.run_pre_deploy_task(context.app_name, f"{context.app_name}-{name}", new_image_url)

    # Phase 2 (or only phase): full infrastructure + service update.
    terraform.exec_infra_as_code_for_ecs_app(env=context.current_config_rule.target_environment,
                                             ecs_tag=next_ecs_tag,
                                             iac_path=context.iac_path,
                                             var_path=context.iac_var_path,
                                             plan_only=False,
                                             auto_apply=True)
    return next_ecs_tag


def ecs_build_only(context: DeploymentContext):
    stdout(f"Building ECR Image for {context.current_config_rule.docker_tag}")

    local_image = docker.build_local_image(
        app_name=context.app_name,
        git_hash=context.git_hash,
        for_arm=context.for_arm,
        version_string=context.version_string
    )

    docker.tag_and_push_docker_images_from_local(
        app_name=context.app_name,
        local_image=local_image,
        version_string=context.version_string,
        ecr_account_id=context.ecr_account_id,
        environment_tag=context.current_config_rule.docker_tag,
    )