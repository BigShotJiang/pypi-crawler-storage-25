from datetime import datetime

from allfly.utils import run_shell_command, stdout, run_checked_shell_command


def __create_temp_branch_name(target_branch: str) -> str:
    now = datetime.now()
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    seconds_since_midnight = (now - midnight).seconds
    today = now.strftime("%Y-%m-%d")
    return f"{target_branch}-{today}-{seconds_since_midnight}"


def promote_branch(source_branch: str, target_branch: str, cicd: bool = False):
    stdout(f"Promoting branch...{source_branch} to {target_branch}")
    if cicd:
        # this is so we don't blitz over our own setup locally
        run_shell_command('git config user.name "AllFly GitHub Actions Bot"')
        run_shell_command('git config user.email "aws.quest.code@allfly.io"')
    run_shell_command(f'git checkout "{source_branch}"')
    run_shell_command("git fetch")
    run_shell_command(f'git checkout "{target_branch}"')
    run_shell_command(f'git pull origin "{target_branch}"')
    run_shell_command(f'git checkout "{source_branch}"')

    temp_branch = __create_temp_branch_name(target_branch)
    stdout(f"Creating temp branch...{temp_branch}")
    run_shell_command(f"git checkout -b {temp_branch}")
    run_shell_command(f"git merge --strategy ours --no-edit --allow-unrelated-histories {target_branch}")
    run_shell_command(f"git checkout {target_branch}")
    run_shell_command(f"git merge --squash {temp_branch}")

    # Check if there are changes to commit
    # Try to commit regardless of status and examine the result
    commit_result = run_checked_shell_command(
        f'git commit -m "merging {source_branch} to {target_branch} for release {temp_branch}"',
        check=False
    )

    if "nothing to commit" in commit_result.lower() or "working tree clean" in commit_result.lower():
        # Git reported no changes to commit
        stdout(f"No changes detected when merging {source_branch} to {target_branch}. Nothing to commit.")
    else:
        # Commit was successful
        stdout(f"Successfully committed changes from {source_branch} to {target_branch}.")

    # Always push to update branch references
    run_shell_command(f"git push origin {target_branch}")


def prep_hotfix(target: str, branch_name: str):
    """
    Prepare a hotfix branch for qa or staging.
    
    Args:
        target: 'qa' or 'staging' - the target environment
        branch_name: your hotfix branch name (without hotfix/ prefix)
    
    This function replicates the functionality of prep_hotfix.sh:
    1. Validates arguments
    2. Checks for uncommitted changes
    3. Fetches latest from origin
    4. Resets hotfix base branch to match target
    5. Creates new hotfix branch
    """
    # Validate target
    if target not in ["qa", "staging"]:
        raise ValueError("Error: target must be 'qa' or 'staging'")
    
    # Check for uncommitted changes (ignore untracked files)
    stdout("🔍 Checking for uncommitted changes...")
    status_result = run_checked_shell_command("git status --porcelain", check=False)
    
    # Filter out untracked files (??) - only care about modified/staged/deleted tracked files
    blocking_changes = []
    if status_result.strip():
        for line in status_result.strip().split('\n'):
            if line and not line.startswith('??'):
                blocking_changes.append(line)
    
    if blocking_changes:
        stdout("❌ Error: You have uncommitted changes to tracked files:")
        for change in blocking_changes:
            stdout(f"  {change}")
        stdout("")
        stdout("Please commit or stash your changes before preparing a hotfix:")
        stdout("  git add . && git commit -m 'your commit message'")
        stdout("  OR")
        stdout("  git stash")
        stdout("")
        stdout("Note: Untracked files (??) are ignored and won't block the operation.")
        raise RuntimeError("Uncommitted changes to tracked files detected. Cannot proceed with hotfix preparation.")
    
    hotfix_base = f"hotfix/{target}"
    hotfix_branch = f"hotfix/{branch_name}"
    
    stdout(f"🔧 Preparing hotfix for {target}...")
    
    # Fetch latest from remote
    stdout("📥 Fetching latest from origin...")
    run_shell_command("git fetch origin")
    
    # Reset hotfix base branch to match target
    stdout(f"🔄 Resetting {hotfix_base} to match origin/{target}...")
    run_shell_command(f"git checkout {hotfix_base}")
    run_shell_command(f"git reset --hard origin/{target}")
    run_shell_command(f"git push origin {hotfix_base} --force")
    
    # Create new hotfix branch
    stdout(f"🌱 Creating new branch {hotfix_branch}...")
    run_shell_command(f"git checkout -b {hotfix_branch}")
    
    stdout("")
    stdout(f"✅ Ready! You're now on branch: {hotfix_branch}")
    stdout("   Next steps:")
    stdout("   1. Make your changes")
    stdout(f"   2. Commit and push: git push origin {hotfix_branch}")
    stdout(f"   3. Create PR: {hotfix_branch} → {hotfix_base}")



