import math
from typing import Any, List

import msgpack
from eth_utils.crypto import keccak
from eth_account.messages import encode_typed_data
from eth_utils.conversions import to_hex
from eth_account.signers.local import LocalAccount

from async_hyperliquid.utils.types import (
    LimitTif,
    OrderType,
    OrderAction,
    EncodedOrder,
    GroupOptions,
    OrderBuilder,
    SignedAction,
    PlaceOrderRequest,
    is_limit_order_type,
    is_trigger_order_type,
    limit_order_type,
)
from async_hyperliquid.utils.constants import (
    SIGNATURE_CHAIN_ID,
    APPROVE_AGENT_TYPES,
    USD_SEND_SIGN_TYPES,
    WITHDRAW_SIGN_TYPES,
    TOKEN_DELEGATE_TYPES,
    SEND_ASSET_SIGN_TYPES,
    SPOT_TRANSFER_SIGN_TYPES,
    APPROVE_BUILDER_FEE_TYPES,
    STAKING_TRANSFER_SIGN_TYPES,
    MULTI_SIG_ENVELOPE_SIGN_TYPES,
    USER_SET_ABSTRACTION_SIGN_TYPES,
    USD_CLASS_TRANSFER_SIGN_TYPES,
    USER_DEX_ABSTRACTION_SIGN_TYPES,
    CONVERT_TO_MULTI_SIG_USER_SIGN_TYPES,
)

_EIP712_DOMAIN_FIELDS = [
    {"name": "name", "type": "string"},
    {"name": "version", "type": "string"},
    {"name": "chainId", "type": "uint256"},
    {"name": "verifyingContract", "type": "address"},
]
_ZERO_ADDRESS = "0x0000000000000000000000000000000000000000"
_EXCHANGE_AGENT_DOMAIN = {
    "chainId": 1337,
    "name": "Exchange",
    "verifyingContract": _ZERO_ADDRESS,
    "version": "1",
}
_EXCHANGE_AGENT_MESSAGE_TYPES = {
    "Agent": [
        {"name": "source", "type": "string"},
        {"name": "connectionId", "type": "bytes32"},
    ]
}
_EXCHANGE_AGENT_PAYLOAD_BASE = {
    "domain": _EXCHANGE_AGENT_DOMAIN,
    "types": {
        "Agent": _EXCHANGE_AGENT_MESSAGE_TYPES["Agent"],
        "EIP712Domain": _EIP712_DOMAIN_FIELDS,
    },
    "primaryType": "Agent",
}
_USER_SIGNED_PAYLOAD_BASE_CACHE: dict[tuple[str, int, int], dict[str, Any]] = {}
_USER_SIGNED_DOMAIN_CACHE: dict[int, dict[str, Any]] = {}
_USER_SIGNED_MESSAGE_TYPES_CACHE: dict[tuple[str, int], dict[str, List[dict]]] = {}


def address_to_bytes(address: str) -> bytes:
    return bytes.fromhex(address[2:] if address.startswith("0x") else address)


def hash_action(
    action: dict, vault: str | None, nonce: int, expires: int | None = None
) -> bytes:
    data: bytes = msgpack.packb(action)
    data += nonce.to_bytes(8, "big")

    if vault is None:
        data += b"\x00"
    else:
        data += b"\x01"
        data += bytes.fromhex(vault.removeprefix("0x"))

    if expires is not None:
        data += b"\x00"
        data += expires.to_bytes(8, "big")

    return keccak(data)


def sign_inner(wallet: LocalAccount, data: dict) -> SignedAction:
    encodes = encode_typed_data(full_message=data)
    signed = wallet.sign_message(encodes)
    return {"r": to_hex(signed["r"]), "s": to_hex(signed["s"]), "v": signed["v"]}


def sign_typed_data(
    wallet: LocalAccount,
    domain_data: dict[str, Any],
    message_types: dict[str, Any],
    message_data: dict[str, Any],
) -> SignedAction:
    encodes = encode_typed_data(
        domain_data=domain_data, message_types=message_types, message_data=message_data
    )
    signed = wallet.sign_message(encodes)
    return {"r": to_hex(signed["r"]), "s": to_hex(signed["s"]), "v": signed["v"]}


def _user_signed_domain(chain_id: int) -> dict[str, Any]:
    payload = _USER_SIGNED_DOMAIN_CACHE.get(chain_id)
    if payload is None:
        payload = {
            "name": "HyperliquidSignTransaction",
            "version": "1",
            "chainId": chain_id,
            "verifyingContract": _ZERO_ADDRESS,
        }
        _USER_SIGNED_DOMAIN_CACHE[chain_id] = payload
    return payload


def _user_signed_message_types(
    primary_type: str, payload_types: List[dict]
) -> dict[str, List[dict]]:
    cache_key = (primary_type, id(payload_types))
    payload = _USER_SIGNED_MESSAGE_TYPES_CACHE.get(cache_key)
    if payload is None:
        payload = {primary_type: payload_types}
        _USER_SIGNED_MESSAGE_TYPES_CACHE[cache_key] = payload
    return payload


def _user_signed_payload_base(
    primary_type: str, payload_types: List[dict], chain_id: int
):
    cache_key = (primary_type, id(payload_types), chain_id)
    payload = _USER_SIGNED_PAYLOAD_BASE_CACHE.get(cache_key)
    if payload is None:
        payload = {
            "domain": {
                "name": "HyperliquidSignTransaction",
                "version": "1",
                "chainId": chain_id,
                "verifyingContract": _ZERO_ADDRESS,
            },
            "types": {
                primary_type: payload_types,
                "EIP712Domain": _EIP712_DOMAIN_FIELDS,
            },
            "primaryType": primary_type,
        }
        _USER_SIGNED_PAYLOAD_BASE_CACHE[cache_key] = payload
    return payload


def sign_action(
    wallet: LocalAccount,
    action: dict,
    active_pool: str | None,
    nonce: int,
    is_mainnet: bool,
    expires: int | None = None,
) -> SignedAction:
    h = hash_action(action, active_pool, nonce, expires)
    msg = {"source": "a" if is_mainnet else "b", "connectionId": h}
    return sign_typed_data(
        wallet, _EXCHANGE_AGENT_DOMAIN, _EXCHANGE_AGENT_MESSAGE_TYPES, msg
    )


def round_float(x: float) -> str:
    if not math.isfinite(x):
        raise ValueError("round_float requires finite number", x)

    rounded = f"{x:.8f}"
    if abs(float(rounded) - x) >= 1e-12:
        raise ValueError("round_float causes rounding", x)

    trimmed = rounded.rstrip("0").rstrip(".")
    if trimmed in {"", "-0"}:
        return "0"
    return trimmed


def ensure_order_type(order_type: OrderType) -> OrderType:
    if is_limit_order_type(order_type):
        return limit_order_type(LimitTif(order_type["limit"]["tif"]))
    if is_trigger_order_type(order_type):
        return {
            "trigger": {
                "isMarket": order_type["trigger"]["isMarket"],
                "triggerPx": round_float(float(order_type["trigger"]["triggerPx"])),
                "tpsl": order_type["trigger"]["tpsl"],
            }
        }

    raise ValueError("Invalid order type", order_type)


def encode_order(order: PlaceOrderRequest) -> EncodedOrder:
    encoded_order: EncodedOrder = {
        "a": order["asset"],
        "b": order["is_buy"],
        "p": round_float(order["px"]),
        "s": round_float(order["sz"]),
        "r": order["ro"],
        "t": ensure_order_type(order["order_type"]),
    }

    if order.get("cloid", None) is not None:
        encoded_order["c"] = order["cloid"].to_raw()  # type: ignore

    return encoded_order


def orders_to_action(
    encoded_orders: List[EncodedOrder],
    grouping: GroupOptions = "na",
    builder: OrderBuilder | None = None,
) -> OrderAction:
    action: OrderAction = {
        "type": "order",
        "orders": encoded_orders,
        "grouping": grouping,
    }
    if builder:
        action["builder"] = builder
    return action


def user_signed_payload(primary_type, payload_types, action):
    chain_id = int(action["signatureChainId"], 16)
    return {
        **_user_signed_payload_base(primary_type, payload_types, chain_id),
        "message": action,
    }


def sign_user_signed_action(
    wallet: LocalAccount,
    action: dict,
    payload_types: List[dict],
    primary_type: str,
    is_mainnet: bool,
):
    action["signatureChainId"] = SIGNATURE_CHAIN_ID
    action["hyperliquidChain"] = "Mainnet" if is_mainnet else "Testnet"
    chain_id = int(action["signatureChainId"], 16)
    return sign_typed_data(
        wallet,
        _user_signed_domain(chain_id),
        _user_signed_message_types(primary_type, payload_types),
        action,
    )


def sign_usd_transfer_action(wallet: LocalAccount, action, is_mainnet: bool):
    return sign_user_signed_action(
        wallet,
        action,
        USD_SEND_SIGN_TYPES,
        "HyperliquidTransaction:UsdSend",
        is_mainnet,
    )


def sign_spot_transfer_action(wallet: LocalAccount, action: dict, is_mainnet: bool):
    return sign_user_signed_action(
        wallet,
        action,
        SPOT_TRANSFER_SIGN_TYPES,
        "HyperliquidTransaction:SpotSend",
        is_mainnet,
    )


def sign_withdraw_action(wallet: LocalAccount, action: dict, is_mainnet: bool):
    return sign_user_signed_action(
        wallet,
        action,
        WITHDRAW_SIGN_TYPES,
        "HyperliquidTransaction:Withdraw",
        is_mainnet,
    )


def sign_usd_class_transfer_action(wallet: LocalAccount, action: Any, is_mainnet: bool):
    return sign_user_signed_action(
        wallet,
        action,
        USD_CLASS_TRANSFER_SIGN_TYPES,
        "HyperliquidTransaction:UsdClassTransfer",
        is_mainnet,
    )


def sign_send_asset_action(wallet: LocalAccount, action: dict, is_mainnet: bool):
    return sign_user_signed_action(
        wallet,
        action,
        SEND_ASSET_SIGN_TYPES,
        "HyperliquidTransaction:SendAsset",
        is_mainnet,
    )


def sign_staking_deposit_action(wallet: LocalAccount, action: dict, is_mainnet: bool):
    return sign_user_signed_action(
        wallet,
        action,
        STAKING_TRANSFER_SIGN_TYPES,
        "HyperliquidTransaction:CDeposit",
        is_mainnet,
    )


def sign_staking_withdraw_action(wallet: LocalAccount, action: dict, is_mainnet: bool):
    return sign_user_signed_action(
        wallet,
        action,
        STAKING_TRANSFER_SIGN_TYPES,
        "HyperliquidTransaction:CWithdraw",
        is_mainnet,
    )


def sign_token_delegate_action(wallet: LocalAccount, action: dict, is_mainnet: bool):
    return sign_user_signed_action(
        wallet,
        action,
        TOKEN_DELEGATE_TYPES,
        "HyperliquidTransaction:TokenDelegate",
        is_mainnet,
    )


def sign_approve_agent_action(wallet: LocalAccount, action: dict, is_mainnet: bool):
    return sign_user_signed_action(
        wallet,
        action,
        APPROVE_AGENT_TYPES,
        "HyperliquidTransaction:ApproveAgent",
        is_mainnet,
    )


def sign_approve_builder_fee_action(
    wallet: LocalAccount, action: dict, is_mainnet: bool
):
    return sign_user_signed_action(
        wallet,
        action,
        APPROVE_BUILDER_FEE_TYPES,
        "HyperliquidTransaction:ApproveBuilderFee",
        is_mainnet,
    )


def sign_convert_to_multi_sig_user_action(
    wallet: LocalAccount, action: dict, is_mainnet: bool
):
    return sign_user_signed_action(
        wallet,
        action,
        CONVERT_TO_MULTI_SIG_USER_SIGN_TYPES,
        "HyperliquidTransaction:ConvertToMultiSigUser",
        is_mainnet,
    )


def sign_multi_sig_action(
    wallet: LocalAccount,
    action: dict,
    is_mainnet: bool,
    vault: str | None,
    nonce: int,
    expires: int | None = None,
):
    action_without_type = action.copy()
    del action_without_type["type"]

    h = hash_action(action_without_type, vault, nonce, expires)

    envelope = {"multiSigActionHash": h, "nonce": nonce}
    return sign_user_signed_action(
        wallet,
        envelope,
        MULTI_SIG_ENVELOPE_SIGN_TYPES,
        "HyperliquidTransaction:SendMultiSig",
        is_mainnet,
    )


def sign_user_dex_abstraction_action(
    wallet: LocalAccount, action: dict, is_mainnet: bool
):
    return sign_user_signed_action(
        wallet,
        action,
        USER_DEX_ABSTRACTION_SIGN_TYPES,
        "HyperliquidTransaction:UserDexAbstraction",
        is_mainnet,
    )


def sign_user_set_abstraction_action(
    wallet: LocalAccount, action: dict, is_mainnet: bool
):
    return sign_user_signed_action(
        wallet,
        action,
        USER_SET_ABSTRACTION_SIGN_TYPES,
        "HyperliquidTransaction:UserSetAbstraction",
        is_mainnet,
    )
