"""Exception hierarchy shared across appcore packages."""


class MyAppError(Exception):
    """Base exception for all application-specific failures."""


class BootstrapError(MyAppError):
    """Raised when bootstrap initialization fails at a specific step."""

    def __init__(self, step: str, cause: Exception) -> None:
        """Initialize the bootstrap error with the failed step and cause."""
        super().__init__(f"Bootstrap failed at step '{step}': {cause}")
        self.step = step
        self.cause = cause


class ConfigurationError(MyAppError):
    """Raised for missing files, invalid schema, or unknown environments."""


class KeyProviderError(MyAppError):
    """Raised when a key cannot be retrieved from its backing store."""


class CryptoError(MyAppError):
    """Raised when encryption or decryption fails."""


class DatabaseError(MyAppError):
    """Raised when database connectivity or session work fails."""


class EmailError(MyAppError):
    """Raised when an email message cannot be prepared or sent."""
