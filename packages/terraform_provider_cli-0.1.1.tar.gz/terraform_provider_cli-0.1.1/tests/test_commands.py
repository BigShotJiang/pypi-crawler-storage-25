"""Tests for CLI commands."""

import pytest
from argparse import Namespace
from unittest.mock import Mock, patch

from terraform_provider_cli.commands import doc, list as list_cmd, search


class TestDocCommand:
    """Test cases for the doc command."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock client."""
        return Mock()

    def test_add_parser(self):
        """Test parser creation."""
        subparsers = Mock()
        parser = doc.add_parser(subparsers)
        assert parser is not None
        subparsers.add_parser.assert_called_once()

    def test_run_success(self, mock_client):
        """Test successful doc fetch."""
        mock_client.get_resource_doc.return_value = "# Test Doc"

        args = Namespace(
            name="azurerm_virtual_machine",
            category="resources",
            version=None,
            output=None,
            set_default=False,
            set_default_provider=False,
            provider=None,
            namespace=None,
        )

        result = doc.run(args, mock_client)
        assert result == 0
        mock_client.get_resource_doc.assert_called_once_with(
            name="azurerm_virtual_machine",
            category="resources",
            version=None,
        )

    def test_run_with_version(self, mock_client):
        """Test doc fetch with specific version."""
        mock_client.get_resource_doc.return_value = "# Test Doc"

        args = Namespace(
            name="azurerm_virtual_machine",
            category="resources",
            version="3.50.0",
            output=None,
            set_default=False,
            set_default_provider=False,
            provider=None,
            namespace=None,
        )

        result = doc.run(args, mock_client)
        assert result == 0
        mock_client.get_resource_doc.assert_called_once_with(
            name="azurerm_virtual_machine",
            category="resources",
            version="3.50.0",
        )

    def test_run_resource_not_found(self, mock_client):
        """Test doc fetch with non-existent resource."""
        from terraform_provider_cli.api.client import ResourceNotFoundError

        mock_client.get_resource_doc.side_effect = ResourceNotFoundError("Not found")

        args = Namespace(
            name="azurerm_fake",
            category="resources",
            version=None,
            output=None,
            set_default=False,
        )

        result = doc.run(args, mock_client)
        assert result == 1


class TestListCommand:
    """Test cases for the list command."""

    def test_add_parser(self):
        """Test parser creation."""
        subparsers = Mock()
        parser = list_cmd.add_parser(subparsers)
        assert parser is not None
        subparsers.add_parser.assert_called_once()


class TestSearchCommand:
    """Test cases for the search command."""

    def test_add_parser(self):
        """Test parser creation."""
        subparsers = Mock()
        parser = search.add_parser(subparsers)
        assert parser is not None
        subparsers.add_parser.assert_called_once()
