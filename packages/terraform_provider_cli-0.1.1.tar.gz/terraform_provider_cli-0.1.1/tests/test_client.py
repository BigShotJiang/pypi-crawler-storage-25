"""Tests for the Terraform Registry API client."""

import pytest
from unittest.mock import Mock, patch, MagicMock

from terraform_provider_cli.api.client import (
    TerraformRegistryClient,
    TerraformRegistryError,
    ResourceNotFoundError,
    VersionNotFoundError,
)


class TestTerraformRegistryClient:
    """Test cases for TerraformRegistryClient."""

    @pytest.fixture
    def client(self):
        """Create a client instance for testing."""
        return TerraformRegistryClient(timeout=10)

    def test_init(self, client):
        """Test client initialization."""
        assert client.timeout == 10
        assert client.max_retries == 3
        assert client.retry_delay == 1.0

    @patch("terraform_provider_cli.api.client.requests.Session")
    def test_init_with_custom_params(self, mock_session):
        """Test client initialization with custom parameters."""
        client = TerraformRegistryClient(timeout=60, max_retries=5, retry_delay=2.0)
        assert client.timeout == 60
        assert client.max_retries == 5
        assert client.retry_delay == 2.0

    def test_cache(self, client):
        """Test that cache is initialized."""
        assert client._cache == {}
        client._cache["test"] = {"data": "value"}
        assert client._cache["test"] == {"data": "value"}

    def test_clear_cache(self, client):
        """Test cache clearing."""
        client._cache["test"] = {"data": "value"}
        client.clear_cache()
        assert client._cache == {}


class TestClientErrors:
    """Test error classes."""

    def test_terraform_registry_error(self):
        """Test base error class."""
        error = TerraformRegistryError("Test error")
        assert str(error) == "Test error"

    def test_resource_not_found_error(self):
        """Test resource not found error."""
        error = ResourceNotFoundError("Resource not found")
        assert str(error) == "Resource not found"

    def test_version_not_found_error(self):
        """Test version not found error."""
        error = VersionNotFoundError("Version not found")
        assert str(error) == "Version not found"