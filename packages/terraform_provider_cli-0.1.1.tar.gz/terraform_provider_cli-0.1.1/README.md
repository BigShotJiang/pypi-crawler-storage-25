# terraform-provider-cli (tpc)

CLI tool to fetch Terraform provider documentation from the official Terraform Registry. Supports AWS, Azure, GCP, Kubernetes, and other providers.

## Installation

```bash
# Install from PyPI
pip install terraform-provider-cli

# Or install from source
pip install -e .
```

## Quick Start

```bash
# Show current configuration
tpc info

# Browse available providers
tpc provider list
tpc provider search aws

# Fetch documentation (no config needed!)
tpc doc aws_instance --provider aws --version 5.0.0
```

## First Run Setup

You have two options:

### Option 1: Set defaults (recommended for frequent use)

```bash
# Set default provider
tpc config set-provider aws

# Set default version
tpc config set-version 5.0.0

# Or use environment variables
export TERRAFORM_PROVIDER=aws
export TERRAFORM_PROVIDER_VERSION=5.0.0
```

### Option 2: Use flags directly (no config needed)

You can pass `--provider` and `--version` directly to any command:

```bash
# No config needed - just use flags
tpc doc aws_instance --provider aws --version 5.0.0
tpc doc azurerm_virtual_machine --provider azurerm --version 4.60.0
tpc list resources --provider kubernetes --version 2.0.0
tpc search pod --provider kubernetes --version 2.0.0
```

## Usage

### Show Configuration

```bash
# Show current default provider and version
tpc info
tpc config show
```

### Browse Providers

```bash
# List popular providers
tpc provider list
tpc provider list --limit 20

# Search for a specific provider
tpc provider search databricks
tpc provider search kubernetes
```

### Fetch documentation

```bash
# Fetch resource documentation
tpc doc aws_instance

# Fetch from specific provider
tpc doc google_compute_instance --provider google

# Fetch data source
tpc doc aws_vpc --category data-sources

# For non-HashiCorp providers (like Databricks)
tpc doc databricks_workspace --provider databricks --namespace databricks --version 1.0.0

# Save to file
tpc doc aws_instance --output docs/instance.md
```

### List resources

```bash
# List all resources (uses default provider)
tpc list resources

# List data sources
tpc list data-sources

# List for specific provider
tpc list resources --provider google

# List for specific version
tpc list resources --version 4.0.0
```

### Search

```bash
# Search resources
tpc search s3

# Search data sources
tpc search vpc --category data-sources
```

## Important Tips

### Resource Names with Underscores

**Use underscores (_) in resource names, not spaces!**

Terraform resource names use underscores. The API searches for exact resource names.

```bash
# Wrong - will not work
tpc search s3 object
tpc doc google compute instance
tpc search aws instance

# Correct - use exact names with underscores
tpc search s3_object
tpc doc google_compute_instance
tpc doc aws_instance
```

**Tip:** Resource names are often compound words like `aws_instance`, `azurerm_virtual_machine`, `google_compute_instance`. If your search returns no results, try using a more specific term from the resource name.

### Non-HashiCorp Providers

Some providers are not maintained by HashiCorp (e.g., Databricks, Okta, Snowflake). Use `--namespace` flag:

```bash
# For Databricks (namespace: databricks)
tpc provider search databricks  # Shows namespace
tpc doc databricks_workspace --provider databricks --namespace databricks --version 1.0.0
```

### Quick Examples

```bash
# Show current config
tpc --info
tpc info

# List providers and search
tpc provider list
tpc provider search aws
tpc provider search databricks

# Set defaults for convenience
tpc config set-provider aws
tpc config set-version 5.0.0

# Or use flags directly (no config needed!)
tpc doc aws_instance --provider aws --version 5.0.0

# Search and list
tpc search s3
tpc list resources --provider aws
```

### Common Issues

**Provider not found error:**
- Try using `--namespace` flag
- Search providers first: `tpc provider search <name>`

**Version not found:**
- Don't specify a version to use the latest
- Or check available versions on the provider's Terraform Registry page

## Options

- `--verbose, -V`: Enable verbose output
- `--version`: Show version information
- `--provider, -p`: Override default provider
- `--namespace, -n`: Specify provider namespace (for non-HashiCorp providers)

## Configuration

The config file is stored at `~/.terraform-provider-cli/config`.

## Development

```bash
# Install with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Run with verbose
python -m terraform_provider_cli doc aws_instance -V
```

## License

MIT