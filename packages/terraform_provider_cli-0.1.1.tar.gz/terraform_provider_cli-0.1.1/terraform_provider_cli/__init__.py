"""terraform_provider_cli - CLI tool to fetch Terraform provider documentation."""

__version__ = "0.1.0"