"""List command - list available resources and data sources."""

import argparse
import sys

from rich.console import Console

from ..api.client import TerraformRegistryClient, TerraformRegistryError
from ..utils.formatter import format_resources_table, format_data_sources_table, print_error

console = Console()


def add_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    """Add the list subcommand parser.

    Args:
        subparsers: Subparsers object from the main parser.

    Returns:
        The parser for the list command.
    """
    parser = subparsers.add_parser(
        "list",
        help="List all resources or data sources",
        description="List all available AzureRM resources or data sources for a given version.",
    )
    parser.add_argument(
        "category",
        choices=["resources", "data-sources"],
        help="Category to list (resources or data-sources)",
    )
    parser.add_argument(
        "--version",
        "-v",
        dest="version",
        help="Provider version (e.g., 3.50.0). If not specified, uses latest.",
    )
    parser.add_argument(
        "--provider",
        "-p",
        dest="provider",
        help="Provider name (overrides default/config)",
    )
    parser.add_argument(
        "--namespace",
        "-n",
        dest="namespace",
        help="Provider namespace (e.g., hashicorp, databricks)",
    )
    parser.add_argument(
        "--limit",
        "-l",
        type=int,
        help="Limit the number of results (default: show all)",
    )
    return parser


def run(args: argparse.Namespace, client: TerraformRegistryClient) -> int:
    """Run the list command.

    Args:
        args: Parsed arguments.
        client: API client instance.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    try:
        # Override client provider/namespace if specified
        provider = getattr(args, "provider", None)
        namespace = getattr(args, "namespace", None)
        if provider:
            client._provider = provider
        if namespace:
            client._namespace = namespace

        # Get resources or data sources
        if args.category == "resources":
            items = client.list_resources(version=args.version)
            table = format_resources_table(items)
        else:
            items = client.list_data_sources(version=args.version)
            table = format_data_sources_table(items)

        # Apply limit if specified
        if args.limit and args.limit > 0:
            items = items[: args.limit]

        if not items:
            print_error(f"No {args.category} found")
            from ..utils.formatter import print_info

            print_info("")
            print_info("Tips:")
            print_info(f"  • Check provider: tpc provider list")
            print_info(f"  • Try different version: tpc list {args.category} --version <version>")
            return 1

        # Print the table
        console.print(table)

        # Print summary
        console.print(f"\n[bold]Total:[/bold] {len(items)} {args.category}")

        # Show next steps
        console.print("\n[bold]Next Steps:[/bold]")
        console.print(f"  • Search: tpc search <keyword>")
        console.print(f"  • Get doc: tpc doc <resource-name>")

        return 0

    except TerraformRegistryError as e:
        print_error(f"API error: {e}")
        from ..utils.formatter import print_info

        print_info("")
        print_info("Possible causes:")
        print_info(f"  • Provider '{client.provider}' not found in namespace '{client.namespace}'")
        print_info("  • Network issues")
        print_info("")
        print_info("Try:")
        print_info(f"  • Verify provider: tpc provider search {client.provider}")
        print_info(f"  • Specify namespace: tpc list {args.category} --namespace <namespace>")
        return 1
    except KeyboardInterrupt:
        print_error("Operation cancelled by user")
        return 130
    except Exception as e:
        print_error(f"Unexpected error: {e}")
        return 1
