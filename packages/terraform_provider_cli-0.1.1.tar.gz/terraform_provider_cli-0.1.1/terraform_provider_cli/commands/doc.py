"""Doc command - fetch and output documentation."""

import argparse
import sys

from ..api.client import (
    TerraformRegistryClient,
    ResourceNotFoundError,
    VersionNotFoundError,
    TerraformRegistryError,
)
from ..utils.formatter import print_error, print_success
from ..utils import config


def add_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    """Add the doc subcommand parser.

    Args:
        subparsers: Subparsers object from the main parser.

    Returns:
        The parser for the doc command.
    """
    parser = subparsers.add_parser(
        "doc",
        help="Fetch documentation for a resource or data source",
        description="Fetch and display markdown documentation for a Terraform resource or data source.",
    )
    parser.add_argument(
        "name",
        help="Resource or data source name (e.g., azurerm_virtual_machine)",
    )
    parser.add_argument(
        "--category",
        "-c",
        choices=["resources", "data-sources"],
        default="resources",
        help="Category (resources or data-sources). Default: resources",
    )
    parser.add_argument(
        "--version",
        "-v",
        dest="version",
        help="Provider version (e.g., 3.50.0). If not specified, uses latest or config default.",
    )
    parser.add_argument(
        "--provider",
        "-p",
        dest="provider",
        help="Provider name (overrides default/config)",
    )
    parser.add_argument(
        "--namespace", "-n",
        dest="namespace",
        help="Provider namespace (e.g., hashicorp, databricks). Auto-detected for known providers.",
    )
    parser.add_argument(
        "--set-default",
        action="store_true",
        help="Save this version as the default for future commands.",
    )
    parser.add_argument(
        "--output",
        "-o",
        help="Output file path (default: stdout)",
    )
    parser.add_argument(
        "--set-default-provider",
        action="store_true",
        help="Save this provider as the default for future commands.",
    )
    return parser


def run(args: argparse.Namespace, client: TerraformRegistryClient) -> int:
    """Run the doc command.

    Args:
        args: Parsed arguments.
        client: API client instance.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    try:
        # Handle --set-default
        if args.set_default:
            if not args.version:
                print_error("--set-default requires --version to be specified")
                return 1
            config.set_default_version(args.version)
            print_success(f"Default version set to {args.version}")
            return 0

        # Handle --set-default-provider
        if args.set_default_provider:
            provider = getattr(args, 'provider', None) or config.get_default_provider()
            if not provider:
                print_error("No provider specified. Use --provider flag or configure default.")
                return 1
            config.set_default_provider(provider)
            print_success(f"Default provider set to {provider}")
            return 0

        # Override client provider/namespace if specified in command
        provider = getattr(args, 'provider', None)
        namespace = getattr(args, 'namespace', None)
        if provider:
            client._provider = provider
        if namespace:
            client._namespace = namespace

        # Fetch documentation
        markdown = client.get_resource_doc(
            name=args.name,
            category=args.category,
            version=args.version,
        )

        # Output to file or stdout
        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                f.write(markdown)
            print(f"Documentation saved to {args.output}")
        else:
            print(markdown)

        return 0

    except ResourceNotFoundError as e:
        print_error(str(e))
        return 1
    except VersionNotFoundError as e:
        print_error(str(e))
        return 1
    except TerraformRegistryError as e:
        print_error(f"API error: {e}")
        return 1
    except KeyboardInterrupt:
        print_error("Operation cancelled by user")
        return 130
    except Exception as e:
        print_error(f"Unexpected error: {e}")
        return 1