"""Search command - search for resources or data sources."""

import argparse

from rich.console import Console

from ..api.client import TerraformRegistryClient, TerraformRegistryError
from ..utils.formatter import format_resources_table, format_data_sources_table, print_error

console = Console()


def add_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    """Add the search subcommand parser.

    Args:
        subparsers: Subparsers object from the main parser.

    Returns:
        The parser for the search command.
    """
    parser = subparsers.add_parser(
        "search",
        help="Search for resources or data sources by keyword",
        description="Search for AzureRM resources or data sources by keyword.",
    )
    parser.add_argument(
        "query",
        help="Search query (keyword to search for)",
    )
    parser.add_argument(
        "--category",
        "-c",
        choices=["resources", "data-sources"],
        default="resources",
        help="Category to search (resources or data-sources). Default: resources",
    )
    parser.add_argument(
        "--version",
        "-v",
        dest="version",
        help="Provider version (e.g., 3.50.0). If not specified, uses latest.",
    )
    parser.add_argument(
        "--provider",
        "-p",
        dest="provider",
        help="Provider name (overrides default/config)",
    )
    parser.add_argument(
        "--namespace",
        "-n",
        dest="namespace",
        help="Provider namespace (e.g., hashicorp, databricks)",
    )
    parser.add_argument(
        "--limit",
        "-l",
        type=int,
        help="Limit the number of results",
    )
    return parser


def run(args: argparse.Namespace, client: TerraformRegistryClient) -> int:
    """Run the search command.

    Args:
        args: Parsed arguments.
        client: API client instance.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    try:
        # Override client provider/namespace if specified
        provider = getattr(args, "provider", None)
        namespace = getattr(args, "namespace", None)
        if provider:
            client._provider = provider
        if namespace:
            client._namespace = namespace

        category = getattr(args, "category", "resources") or "resources"
        version = getattr(args, "version", None)

        results = client.search(
            query=args.query,
            category=category,
            version=version,
        )

        if not results:
            print_error(f"No results found for '{args.query}' in {category}")

            # Provide helpful suggestions
            from ..utils.formatter import print_info, print_warning

            print_info("")
            print_info("Tips:")
            print_info(
                f"  - Use underscores instead of spaces: tpc search {args.query.replace(' ', '_')}"
            )
            print_info(f"  - Try a broader search term")
            print_info(f"  - Check available resources: tpc list {category}")

            return 1

        # Print results
        console.print(
            f"\n[bold]Search results for '[cyan]{args.query}[/cyan]' ({category}):[/bold]\n"
        )

        from ..utils.formatter import format_search_results

        console.print(format_search_results(results))

        console.print(f"\n[dim]Found {len(results)} matching {category}[/dim]")
        return 0

    except TerraformRegistryError as e:
        print_error(f"API error: {e}")
        from ..utils.formatter import print_info

        print_info("")
        print_info("Try:")
        print_info("  - Check your network connection")
        print_info("  - Verify the provider exists: tpc provider list")
        return 1
    except KeyboardInterrupt:
        print_error("Operation cancelled by user")
        return 130
    except Exception as e:
        print_error(f"Unexpected error: {e}")
        return 1
