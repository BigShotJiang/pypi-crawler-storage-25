"""Configuration utilities."""

import os
from pathlib import Path

# Config file path
CONFIG_DIR = Path.home() / ".terraform-provider-cli"
CONFIG_FILE = CONFIG_DIR / "config"

# Environment variables
ENV_PROVIDER = "TERRAFORM_PROVIDER"
ENV_VERSION = "TERRAFORM_PROVIDER_VERSION"


def get_default_provider() -> str | None:
    """Get the default provider name.

    Priority:
    1. Environment variable (TERRAFORM_PROVIDER)
    2. Config file (~/.terraform-provider-cli/config)

    Returns:
        Default provider string or None if not set.
    """
    env_provider = os.environ.get(ENV_PROVIDER)
    if env_provider:
        return env_provider

    if CONFIG_FILE.exists():
        try:
            content = CONFIG_FILE.read_text(encoding="utf-8").strip()
            # Config file format: provider\nversion
            lines = content.split("\n")
            if lines and lines[0]:
                return lines[0]
        except OSError:
            pass

    return None


def set_default_provider(provider: str) -> None:
    """Set the default provider in config file.

    Args:
        provider: Provider name (e.g., "aws", "azurerm", "google").
    """
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # Preserve existing version if set
    existing_version = get_default_version() or ""

    config_content = f"{provider}\n{existing_version}"
    CONFIG_FILE.write_text(config_content, encoding="utf-8")


def get_default_version() -> str | None:
    """Get the default provider version.

    Priority:
    1. Environment variable (TERRAFORM_PROVIDER_VERSION)
    2. Config file (~/.terraform-provider-cli/config)

    Returns:
        Default version string or None if not set.
    """
    env_version = os.environ.get(ENV_VERSION)
    if env_version:
        return env_version

    if CONFIG_FILE.exists():
        try:
            content = CONFIG_FILE.read_text(encoding="utf-8").strip()
            lines = content.split("\n")
            if len(lines) > 1 and lines[1]:
                return lines[1]
        except OSError:
            pass

    return None


def set_default_version(version: str) -> None:
    """Set the default provider version in config file.

    Args:
        version: Provider version string (e.g., "5.0.0").
    """
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # Preserve existing provider if set
    existing_provider = get_default_provider() or "azurerm"

    config_content = f"{existing_provider}\n{version}"
    CONFIG_FILE.write_text(config_content, encoding="utf-8")


def clear_config() -> None:
    """Clear all configuration."""
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()


def is_configured() -> bool:
    """Check if the CLI is configured (has provider and version).

    Returns:
        True if both provider and version are configured.
    """
    return get_default_provider() is not None and get_default_version() is not None