"""Output formatting utilities."""

from typing import Any

from rich.console import Console
from rich.table import Table

import sys

console = Console()
stderr_console = Console(file=sys.stderr)


def format_resources_table(resources: list[dict[str, Any]]) -> str:
    """Format resources as a table.

    Args:
        resources: List of resource dictionaries.

    Returns:
        Formatted table string.
    """
    table = Table(title="Resources", show_header=True, header_style="bold cyan")
    table.add_column("Name", style="green", no_wrap=True)
    table.add_column("Description", style="white")

    for resource in resources:
        name = resource.get("name", "")
        description = resource.get("description", "") or ""
        # Truncate long descriptions
        if len(description) > 60:
            description = description[:57] + "..."
        table.add_row(name, description)

    return table


def format_data_sources_table(data_sources: list[dict[str, Any]]) -> str:
    """Format data sources as a table.

    Args:
        data_sources: List of data source dictionaries.

    Returns:
        Formatted table string.
    """
    table = Table(title="Data Sources", show_header=True, header_style="bold cyan")
    table.add_column("Name", style="green", no_wrap=True)
    table.add_column("Description", style="white")

    for ds in data_sources:
        name = ds.get("name", "")
        description = ds.get("description", "") or ""
        # Truncate long descriptions
        if len(description) > 60:
            description = description[:57] + "..."
        table.add_row(name, description)

    return table


def print_error(message: str):
    """Print error message to stderr.

    Args:
        message: Error message.
    """
    stderr_console.print(f"[bold red]Error:[/bold red] {message}")


def print_info(message: str):
    """Print info message.

    Args:
        message: Info message.
    """
    console.print(f"[bold blue]Info:[/bold blue] {message}")


def print_success(message: str):
    """Print success message.

    Args:
        message: Success message.
    """
    console.print(f"[bold green]Success:[/bold green] {message}")


def format_providers_table(providers: list[dict[str, Any]]) -> Table:
    """Format providers as a table.

    Args:
        providers: List of provider dictionaries.

    Returns:
        Rich Table object.
    """
    table = Table(title="Providers", show_header=True, header_style="bold cyan")
    table.add_column("Provider", style="green", no_wrap=True)
    table.add_column("Namespace", style="yellow")
    table.add_column("Tier", style="magenta")
    table.add_column("Description", style="white")

    tier_icons = {
        "official": "[*]",
        "partner": "[+]",
        "community": "[ ]",
    }

    for p in providers:
        name = p.get("name", "")
        namespace = p.get("namespace", "")
        tier = p.get("tier", "")
        description = p.get("description", "") or ""

        # Add icon to tier
        tier_display = f"{tier_icons.get(tier, '')} {tier}".strip()

        # Truncate long descriptions
        if len(description) > 50:
            description = description[:47] + "..."

        full_name = f"{namespace}/{name}"
        table.add_row(name, namespace, tier_display, description)

    return table


def format_versions_table(versions: list[dict[str, Any]]) -> Table:
    """Format versions as a table.

    Args:
        versions: List of version dictionaries.

    Returns:
        Rich Table object.
    """
    table = Table(title="Versions", show_header=True, header_style="bold cyan")
    table.add_column("Version", style="green", no_wrap=True)
    table.add_column("Created", style="white")

    for v in versions:
        version = v.get("version", "")
        created = v.get("created", "")
        # Truncate date to just the date part
        if "T" in created:
            created = created.split("T")[0]

        table.add_row(version, created)

    return table


def format_search_results(results: list[dict[str, Any]]) -> Table:
    """Format search results as a table.

    Args:
        results: List of resource/data source dictionaries.

    Returns:
        Rich Table object.
    """
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Name", style="green", no_wrap=True)
    table.add_column("Description", style="white")

    for item in results:
        name = item.get("name", "")
        description = item.get("description", "") or ""
        # Truncate long descriptions
        if len(description) > 70:
            description = description[:67] + "..."
        table.add_row(name, description)

    return table


def print_warning(message: str):
    """Print warning message.

    Args:
        message: Warning message.
    """
    console.print(f"[bold yellow]Warning:[/bold yellow] {message}")
