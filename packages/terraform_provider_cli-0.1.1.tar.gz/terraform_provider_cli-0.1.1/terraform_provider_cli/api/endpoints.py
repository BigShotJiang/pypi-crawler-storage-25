"""API endpoint definitions for Terraform Registry."""

BASE_URL = "https://registry.terraform.io"

# Documentation endpoints
PROVIDER_DOCS = "/v2/provider-docs"


def build_provider_info_v1_url(namespace: str = "hashicorp", provider: str = "azurerm") -> str:
    """Build URL for getting provider info (v1)."""
    return f"{BASE_URL}/v1/providers/{namespace}/{provider}"


def build_provider_info_v2_url(namespace: str = "hashicorp", provider: str = "azurerm") -> str:
    """Build URL for getting provider info (v2)."""
    return f"{BASE_URL}/v2/providers/{namespace}/{provider}"


def build_provider_versions_url(namespace: str = "hashicorp", provider: str = "azurerm") -> str:
    """Build URL for getting provider versions."""
    return f"{BASE_URL}/v2/providers/{namespace}/{provider}?include=provider-versions"


def build_docs_url(
    version_id: int,
    category: str,
    slug: str,
    language: str = "hcl"
) -> str:
    """Build URL for resolving document ID."""
    params = {
        "filter[provider-version]": version_id,
        "filter[category]": category,
        "filter[slug]": slug,
        "filter[language]": language,
        "page[size]": 1,
    }
    query_string = "&".join(f"{k}={v}" for k, v in params.items())
    return f"{BASE_URL}{PROVIDER_DOCS}?{query_string}"


def build_doc_detail_url(doc_id: int) -> str:
    """Build URL for fetching document details."""
    return f"{BASE_URL}{PROVIDER_DOCS}/{doc_id}"


# Category constants
CATEGORY_RESOURCES = "resources"
CATEGORY_DATA_SOURCES = "data-sources"