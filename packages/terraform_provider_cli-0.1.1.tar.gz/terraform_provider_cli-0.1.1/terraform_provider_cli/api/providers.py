"""Provider API for browsing and searching Terraform providers."""

import logging
from typing import Any, Optional

import requests

from .client import TerraformRegistryError

logger = logging.getLogger(__name__)

BASE_URL = "https://registry.terraform.io"


def _request(url: str, params: Optional[dict] = None) -> dict[str, Any]:
    """Make a request to the Terraform Registry API."""
    headers = {
        "User-Agent": "terraform-provider-cli/0.1.0",
        "Accept": "application/vnd.api+json",
    }

    try:
        response = requests.get(url, params=params, headers=headers, timeout=30)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        raise TerraformRegistryError(f"API request failed: {e}")


def list_providers(tier: Optional[str] = None, limit: int = 50) -> list[dict[str, Any]]:
    """List official Terraform providers.

    Args:
        tier: Filter by tier (official, partner, community) or None for all
        limit: Number of providers to return

    Returns:
        List of provider dictionaries
    """
    # Use the providers browse endpoint
    url = f"{BASE_URL}/v2/providers"

    # Build filter
    if tier and tier != "all":
        params = {
            "filter[tier]": tier,
            "page[size]": limit,
            "sort": "-featured,tier,name",
        }
    else:
        params = {
            "page[size]": limit,
            "sort": "-featured,tier,name",
        }

    data = _request(url, params)
    providers = data.get("data", [])

    result = []
    for p in providers:
        attrs = p.get("attributes", {})
        result.append({
            "name": attrs.get("name", ""),
            "namespace": attrs.get("namespace", ""),
            "full_name": f"{attrs.get('namespace', '')}/{attrs.get('name', '')}",
            "tier": attrs.get("tier", ""),
            "description": attrs.get("description", ""),
        })

    return result


def search_providers(query: str) -> list[dict[str, Any]]:
    """Search for providers by name.

    Args:
        query: Search query

    Returns:
        List of matching provider dictionaries
    """
    url = f"{BASE_URL}/v2/providers"

    params = {
        "filter[name]": query,
        "page[size]": 20,
        "sort": "-featured,tier,name",
    }

    data = _request(url, params)
    providers = data.get("data", [])

    result = []
    for p in providers:
        attrs = p.get("attributes", {})
        result.append({
            "name": attrs.get("name", ""),
            "namespace": attrs.get("namespace", ""),
            "full_name": f"{attrs.get('namespace', '')}/{attrs.get('name', '')}",
            "tier": attrs.get("tier", ""),
            "description": attrs.get("description", ""),
        })

    return result


def get_provider_info(namespace: str, name: str) -> dict[str, Any]:
    """Get detailed provider information.

    Args:
        namespace: Provider namespace (e.g., 'hashicorp', 'databricks')
        name: Provider name (e.g., 'aws', 'databricks')

    Returns:
        Provider information dictionary
    """
    url = f"{BASE_URL}/v2/providers/{namespace}/{name}"

    data = _request(url)
    attrs = data.get("data", {}).get("attributes", {})

    return {
        "name": attrs.get("name", ""),
        "namespace": attrs.get("namespace", ""),
        "full_name": f"{attrs.get('namespace', '')}/{attrs.get('name', '')}",
        "tier": attrs.get("tier", ""),
        "description": attrs.get("description", ""),
        "version": attrs.get("latest_version", ""),
    }


def get_provider_versions(namespace: str, name: str, limit: int = 10) -> list[dict[str, Any]]:
    """Get available versions for a provider.

    Args:
        namespace: Provider namespace (e.g., 'hashicorp', 'databricks')
        name: Provider name (e.g., 'aws', 'databricks')
        limit: Number of versions to return

    Returns:
        List of version dictionaries
    """
    # Get provider versions endpoint
    url = f"{BASE_URL}/v2/providers/{namespace}/{name}/versions"

    try:
        data = _request(url)
    except TerraformRegistryError:
        # Fallback to the v2 provider endpoint with include
        url = f"{BASE_URL}/v2/providers/{namespace}/{name}?include=provider-versions"
        data = _request(url)

    versions = []

    # Try to get versions from different response formats
    if "data" in data:
        # New format with 'included'
        included = data.get("included", [])
        for item in included:
            if item.get("type") == "provider-versions":
                attrs = item.get("attributes", {})
                versions.append({
                    "version": attrs.get("version", ""),
                    "platform": attrs.get("platforms", []),
                    "created": attrs.get("created", ""),
                })
    elif "versions" in data:
        # Older format
        for v in data.get("versions", []):
            versions.append({
                "version": v.get("version", ""),
                "platform": v.get("platforms", []),
                "created": v.get("created", ""),
            })

    # Sort by version (newest first)
    def version_sort_key(v):
        import re
        ver = v.get("version", "")
        # Parse version into tuple for sorting
        match = re.match(r"(\d+)\.(\d+)\.(\d+)", ver)
        if match:
            return tuple(int(x) for x in match.groups())
        return (0, 0, 0)

    versions.sort(key=version_sort_key, reverse=True)

    return versions[:limit]