"""Terraform Registry API client."""

import logging
import time
from typing import Any, Optional

import requests

from . import endpoints
from ..utils import config

logger = logging.getLogger(__name__)


class TerraformRegistryError(Exception):
    """Base exception for Terraform Registry errors."""

    pass


class ProviderNotFoundError(TerraformRegistryError):
    """Raised when provider is not found."""

    pass


class ResourceNotFoundError(TerraformRegistryError):
    """Raised when resource/data source is not found."""

    pass


class VersionNotFoundError(TerraformRegistryError):
    """Raised when version is not found."""

    pass


# Known namespace mappings for popular providers
KNOWN_NAMESPACES = {
    "databricks": "databricks",
    "helm": "helm",
    "kubernetes": "kubernetes",
    "docker": "kreuzwerker",
    "okta": "okta",
    "snowflake": "Snowflake-Labs",
    "mongodbatlas": "mongodb",
    "azurerm": "hashicorp",
    "aws": "hashicorp",
    "google": "hashicorp",
    "azuread": "hashicorp",
    "ad": "hashicorp",
}


class TerraformRegistryClient:
    """Client for interacting with the Terraform Registry API."""

    def __init__(
        self,
        provider: Optional[str] = None,
        namespace: Optional[str] = None,
        timeout: int = 30,
        max_retries: int = 3,
        retry_delay: float = 1.0,
    ):
        """Initialize the client.

        Args:
            provider: Provider name (e.g., "aws", "azurerm", "google").
                     If None, uses config or defaults to "azurerm".
            namespace: Provider namespace (e.g., "hashicorp", "databricks").
                      If None, defaults to "hashicorp" for known providers.
            timeout: Request timeout in seconds.
            max_retries: Maximum number of retry attempts.
            retry_delay: Delay between retries in seconds.
        """
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_delay = retry_delay

        # Determine provider - priority: arg > env > config > default
        self._provider = provider or config.get_default_provider() or "azurerm"

        # Determine namespace
        if namespace:
            self._namespace = namespace
        elif self._provider in KNOWN_NAMESPACES:
            self._namespace = KNOWN_NAMESPACES[self._provider]
        else:
            self._namespace = "hashicorp"  # Default

        self._session = requests.Session()
        self._session.headers.update(
            {
                "User-Agent": "terraform-provider-cli/0.1.0",
                "Accept": "application/vnd.api+json",
            }
        )

        # In-memory cache
        self._cache: dict[str, Any] = {}

    @property
    def provider(self) -> str:
        """Get current provider."""
        return self._provider

    @property
    def namespace(self) -> str:
        """Get current namespace."""
        return self._namespace

    def _request(
        self,
        method: str,
        url: str,
        cache_key: Optional[str] = None,
        **kwargs,
    ) -> dict[str, Any]:
        """Make an HTTP request with retry logic."""
        if cache_key and cache_key in self._cache:
            logger.debug(f"Cache hit for {cache_key}")
            return self._cache[cache_key]

        last_exception = None
        for attempt in range(self.max_retries):
            try:
                response = self._session.request(method, url, timeout=self.timeout, **kwargs)

                if response.status_code == 404:
                    # Try to detect if it's a namespace issue
                    if "providers" in url and "hashicorp" in url:
                        # Likely a non-HashiCorp provider
                        raise ProviderNotFoundError(
                            f"Provider 'hashicorp/{self._provider}' not found.\n\n"
                            f"This provider may not be from HashiCorp. "
                            f"Use: --namespace {self._namespace} or search first:\n"
                            f"  tpc provider search {self._provider}"
                        )
                    raise TerraformRegistryError(f"Resource not found: {url}")

                response.raise_for_status()
                data = response.json()

                if cache_key:
                    self._cache[cache_key] = data

                return data

            except requests.RequestException as e:
                last_exception = e
                logger.warning(f"Request failed (attempt {attempt + 1}/{self.max_retries}): {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay * (attempt + 1))

        raise TerraformRegistryError(
            f"Request failed after {self.max_retries} attempts: {last_exception}"
        )

    def get_latest_version(self) -> str:
        """Get the latest version of the provider."""
        url = endpoints.build_provider_info_v1_url(self._namespace, self._provider)
        data = self._request(
            "GET", url, cache_key=f"latest_version_{self._namespace}_{self._provider}"
        )
        return data.get("version", "")

    def get_version_id(self, version: str) -> str:
        """Get the internal version ID for a specific provider version."""
        url = endpoints.build_provider_versions_url(self._namespace, self._provider)
        data = self._request(
            "GET", url, cache_key=f"version_id_{self._namespace}_{self._provider}_{version}"
        )

        included = data.get("included", [])
        for item in included:
            if item.get("type") == "provider-versions":
                item_version = item.get("attributes", {}).get("version")
                if item_version == version:
                    return item.get("id")

        raise VersionNotFoundError(
            f"Version {version} not found for provider {self._namespace}/{self._provider}"
        )

    def get_latest_version_id(self) -> str:
        """Get the internal version ID for the latest provider version."""
        latest_version = self.get_latest_version()
        return self.get_version_id(latest_version)

    def resolve_doc_id(
        self,
        version_id: int,
        category: str,
        slug: str,
    ) -> Optional[int]:
        """Resolve the document ID for a resource or data source."""
        url = endpoints.build_docs_url(version_id, category, slug)
        data = self._request(
            "GET",
            url,
            cache_key=f"doc_id_{self._namespace}_{self._provider}_{version_id}_{category}_{slug}",
        )

        data_list = data.get("data", [])
        if data_list:
            return data_list[0].get("id")

        return None

    def get_doc_markdown(self, doc_id: int) -> str:
        """Fetch the markdown content for a document."""
        url = endpoints.build_doc_detail_url(doc_id)
        data = self._request("GET", url, cache_key=f"doc_content_{doc_id}")

        attributes = data.get("data", {}).get("attributes", {})
        return attributes.get("content", "")

    def get_provider_info(self) -> dict[str, Any]:
        """Get basic provider information."""
        url = endpoints.build_provider_info_v1_url(self._namespace, self._provider)
        return self._request(
            "GET", url, cache_key=f"provider_info_{self._namespace}_{self._provider}"
        )

    def _list_provider_docs(
        self, version_id: int, category: str, page: int = 1, per_page: int = 100
    ) -> list[dict[str, Any]]:
        """List provider documents for a specific version and category."""
        url = f"{endpoints.BASE_URL}{endpoints.PROVIDER_DOCS}"
        params = {
            "filter[provider-version]": version_id,
            "filter[category]": category,
            "page[size]": per_page,
            "page[number]": page,
        }
        response = self._session.get(url, params=params, timeout=self.timeout)
        response.raise_for_status()
        data = response.json()
        return data.get("data", [])

    def _get_prefix(self) -> str:
        """Get the provider prefix (e.g., 'aws' from 'aws_instance')."""
        return self._provider.replace("-", "_")

    def list_resources(self, version: Optional[str] = None) -> list[dict[str, Any]]:
        """List all resources for a given version."""
        if not version:
            version = config.get_default_version()

        if version:
            version_id = self.get_version_id(version)
        else:
            version_id = self.get_latest_version_id()

        resources = []
        page = 1
        prefix = self._get_prefix()

        while True:
            docs = self._list_provider_docs(version_id, "resources", page=page)
            if not docs:
                break

            for doc in docs:
                attrs = doc.get("attributes", {})
                resources.append(
                    {
                        "name": f"{prefix}_{attrs.get('slug', '')}",
                        "description": attrs.get("description", ""),
                    }
                )

            if len(docs) < 100:
                break
            page += 1

        return resources

    def list_data_sources(self, version: Optional[str] = None) -> list[dict[str, Any]]:
        """List all data sources for a given version."""
        if not version:
            version = config.get_default_version()

        if version:
            version_id = self.get_version_id(version)
        else:
            version_id = self.get_latest_version_id()

        data_sources = []
        page = 1
        prefix = self._get_prefix()

        while True:
            docs = self._list_provider_docs(version_id, "data-sources", page=page)
            if not docs:
                break

            for doc in docs:
                attrs = doc.get("attributes", {})
                data_sources.append(
                    {
                        "name": f"data_{prefix}_{attrs.get('slug', '')}",
                        "description": attrs.get("description", ""),
                    }
                )

            if len(docs) < 100:
                break
            page += 1

        return data_sources

    def search(
        self,
        query: str,
        category: str = "resources",
        version: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """Search for resources or data sources by keyword."""
        items = (
            self.list_resources(version)
            if category == "resources"
            else self.list_data_sources(version)
        )

        query_lower = query.lower()
        return [
            item
            for item in items
            if query_lower in item.get("name", "").lower()
            or query_lower in item.get("description", "").lower()
        ]

    def get_resource_doc(
        self,
        name: str,
        category: str = "resources",
        version: Optional[str] = None,
    ) -> str:
        """Get documentation for a resource or data source."""
        if not version:
            version = config.get_default_version()

        if version:
            version_id = self.get_version_id(version)
        else:
            version_id = self.get_latest_version_id()

        # Extract slug from name (remove provider prefix if present)
        prefix = self._get_prefix()
        slug = name
        for p in [f"{prefix}_", "data_"]:
            if name.startswith(p):
                slug = name[len(p) :]
                break

        # Resolve document ID
        doc_id = self.resolve_doc_id(version_id, category, slug)

        if doc_id is None:
            # Provide helpful error message
            hint = ""
            if self._namespace == "hashicorp":
                hint = (
                    f"\n\nPossible causes:\n"
                    f"  1. '{self._provider}' is not a HashiCorp provider\n"
                    f"  2. The resource '{name}' doesn't exist in this provider\n"
                    f"  3. Try a different category: --category data-sources\n\n"
                    f"Solutions:\n"
                    f"  - Search for the provider: tpc provider search {self._provider}\n"
                    f"  - Specify namespace: --namespace <correct-namespace>\n"
                    f"  - Browse resources: tpc list resources"
                )
            raise ResourceNotFoundError(
                f"Resource '{name}' not found in category '{category}'{hint}"
            )

        return self.get_doc_markdown(doc_id)

    def clear_cache(self):
        """Clear the internal cache."""
        self._cache.clear()
        logger.debug("Cache cleared")
