"""Main CLI entry point."""

import argparse
import logging
import sys

from rich.console import Console

from .api.client import TerraformRegistryClient, TerraformRegistryError
from .commands import doc, list as list_cmd, search
from .utils import config
from .utils.formatter import print_error, print_info, print_success

console = Console()
logger = logging.getLogger(__name__)


def setup_logging(verbose: bool = False):
    """Set up logging configuration."""
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )


def show_info():
    """Show current configuration info."""
    provider = config.get_default_provider()
    version = config.get_default_version()
    env_provider = config.ENV_PROVIDER
    env_version = config.ENV_VERSION

    console.print("\n[bold]Current Configuration:[/bold]")
    console.print(f"  Default Provider: [cyan]{provider or 'Not set'}[/cyan]")
    console.print(f"  Default Version:  [cyan]{version or 'Not set'}[/cyan]")
    console.print("")
    console.print("[bold]Environment Variables:[/bold]")
    console.print(f"  {env_provider}=<provider>")
    console.print(f"  {env_version}=<version>")
    console.print("")
    console.print("[bold]Config File:[/bold]")
    console.print(f"  {config.CONFIG_FILE}")
    console.print("")
    console.print("[bold]Usage:[/bold]")
    console.print("  tpc config show                    # Show config")
    console.print("  tpc provider list                  # List providers")
    console.print("  tpc provider search <name>         # Search providers")
    console.print("  tpc doc aws_instance --provider aws --version 5.0.0")


def check_configured(args) -> bool:
    """Check if CLI is configured or has flags. Exit if not."""
    provider = config.get_default_provider()
    version = config.get_default_version()

    # Check if provider/version provided via flags
    has_provider_flag = getattr(args, "provider", None)
    has_version_flag = getattr(args, "version", None)

    # Allow if config is set OR flags are provided
    if (provider and version) or has_provider_flag or has_version_flag:
        return True

    # Neither config nor flags provided - show error
    print_error("Error: No default provider/version configured.")
    print_info("")
    print_info("Option 1 - Use flags (recommended):")
    print_info("  tpc doc aws_instance --provider aws --version 5.0.0")
    print_info("  tpc doc azurerm_vm --provider azurerm --version 4.60.0")
    print_info("")
    print_info("Option 2 - Set defaults:")
    print_info("  tpc config set-provider aws")
    print_info("  tpc config set-version 5.0.0")
    print_info("")
    print_info("Option 3 - Browse providers:")
    print_info("  tpc provider list")
    print_info("  tpc provider search aws")
    print_info("")
    print_info("Quick: tpc --info  # Shows current config")
    sys.exit(1)


def create_parser() -> argparse.ArgumentParser:
    """Create the main argument parser."""
    parser = argparse.ArgumentParser(
        prog="tpc",
        description="CLI tool to fetch Terraform provider documentation from the official Terraform Registry",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  tpc --info                              # Show current config
  tpc provider list                       # List official providers
  tpc provider search databricks          # Search providers
  tpc config set-provider aws
  tpc config set-version 5.0.0
  tpc doc aws_instance
  tpc doc google_compute_instance --provider google
  tpc list resources
  tpc search s3

Quick Start:
  tpc provider list                       # Browse providers
  tpc doc aws_instance --provider aws --version 5.0.0
        """,
    )

    # Global options
    parser.add_argument(
        "--verbose",
        "-V",
        action="store_true",
        help="Enable verbose output",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.1.0",
        help="Show version information",
    )
    parser.add_argument(
        "--info",
        "-i",
        action="store_true",
        help="Show current configuration info",
    )
    parser.add_argument(
        "--provider",
        "-p",
        dest="provider",
        help="Provider name (overrides default)",
    )

    # Create subparsers
    subparsers = parser.add_subparsers(
        title="commands",
        dest="command",
        description="Available commands",
        required=True,
    )

    # Add config subcommand
    config_parser = subparsers.add_parser(
        "config",
        help="Manage configuration",
        description="Manage default provider and version configuration",
    )
    config_subparsers = config_parser.add_subparsers(
        title="config commands",
        dest="config_command",
        required=True,
    )

    # config set-provider
    set_provider = config_subparsers.add_parser(
        "set-provider",
        help="Set default provider",
    )
    set_provider.add_argument("provider", help="Provider name (e.g., aws, google, azurerm)")

    # config set-version
    set_version = config_subparsers.add_parser(
        "set-version",
        help="Set default version",
    )
    set_version.add_argument("version", help="Provider version (e.g., 5.0.0)")

    # config show
    config_subparsers.add_parser("show", help="Show current configuration")

    # config clear
    config_subparsers.add_parser("clear", help="Clear all configuration")

    # Add info subcommand
    subparsers.add_parser(
        "info",
        help="Show current configuration",
        description="Display current default provider and version settings",
    )

    # Add provider subcommand
    provider_parser = subparsers.add_parser(
        "provider",
        help="Browse and search providers",
        description="Browse official providers or search for specific ones",
    )
    provider_subparsers = provider_parser.add_subparsers(
        title="provider commands",
        dest="provider_command",
        required=True,
    )

    # provider list
    list_providers = provider_subparsers.add_parser(
        "list",
        help="List official providers",
        description="List popular Terraform providers",
    )
    list_providers.add_argument(
        "--limit",
        "-l",
        type=int,
        default=50,
        help="Number of providers to show (default: 50)",
    )
    list_providers.add_argument(
        "--tier",
        choices=["official", "partner", "community", "all"],
        default="all",
        help="Filter by tier",
    )

    # provider search
    search_provider = provider_subparsers.add_parser(
        "search",
        help="Search providers by name",
        description="Search for a specific provider",
    )
    search_provider.add_argument(
        "query",
        help="Provider name to search (e.g., databricks, aws, azure)",
    )

    # provider versions
    versions_parser = provider_subparsers.add_parser(
        "versions",
        help="List available versions for a provider",
        description="Show available versions for a specific provider",
    )
    versions_parser.add_argument(
        "provider",
        nargs="?",
        help="Provider name (uses default if not specified)",
    )
    versions_parser.add_argument(
        "--namespace",
        "-n",
        dest="namespace",
        help="Provider namespace (e.g., hashicorp, databricks)",
    )
    versions_parser.add_argument(
        "--limit",
        "-l",
        type=int,
        default=10,
        help="Number of versions to show (default: 10)",
    )

    # Add subcommands
    doc.add_parser(subparsers)
    list_cmd.add_parser(subparsers)
    search.add_parser(subparsers)

    return parser


def run_config(args) -> int:
    """Run config subcommand."""
    if args.config_command == "set-provider":
        config.set_default_provider(args.provider)
        print_success(f"Default provider set to: {args.provider}")
        return 0

    elif args.config_command == "set-version":
        config.set_default_version(args.version)
        print_success(f"Default version set to: {args.version}")
        return 0

    elif args.config_command == "show":
        provider = config.get_default_provider() or "Not set"
        version = config.get_default_version() or "Not set"
        console.print(f"Provider: [cyan]{provider}[/cyan]")
        console.print(f"Version: [cyan]{version}[/cyan]")
        return 0

    elif args.config_command == "clear":
        config.clear_config()
        print_success("Configuration cleared")
        return 0

    return 0


def run_provider_list(args) -> int:
    """List/browse providers."""
    from .api.providers import list_providers, search_providers

    tier_map = {
        "official": "official",
        "partner": "partner",
        "community": "community",
        "all": None,
    }

    try:
        providers = list_providers(tier=tier_map[args.tier], limit=args.limit)
        console.print(f"\n[bold]Terraform Providers (Tier: {args.tier}):[/bold]\n")

        from .utils.formatter import format_providers_table

        console.print(format_providers_table(providers))

        console.print(f"\n[dim]Total: {len(providers)} providers[/dim]")

        # Show helpful hints
        console.print("\n[bold]Next Steps:[/bold]")
        console.print("  • Search for a provider: tpc provider search <name>")
        console.print("  • Filter by tier: tpc provider list --tier official")
        console.print("  • Get provider versions: tpc provider versions <provider-name>")

        if args.tier == "all":
            console.print(
                "\n[dim]Tip: Use --tier flag to filter (official, partner, community)[/dim]"
            )

        return 0
    except TerraformRegistryError as e:
        print_error(f"API error: {e}")
        console.print("\n[yellow]Tip:[/yellow] Check your internet connection or try again later.")
        return 1


def run_provider_search(args) -> int:
    """Search for a provider."""
    from .api.providers import search_providers

    try:
        results = search_providers(args.query)

        if not results:
            print_error(f"No providers found matching '{args.query}'")
            console.print("\n[bold]Tips:[/bold]")
            console.print("  • Try different keywords (e.g., 'aws', 'azure', 'k8s')")
            console.print("  • Use exact names: tpc provider search databricks")
            console.print("  • Browse all: tpc provider list")
            console.print("\n[bold]Note:[/bold] For providers like 'databricks', 'okta', etc.,")
            console.print(
                "  they are not HashiCorp providers. Use --namespace flag when fetching docs."
            )
            return 1

        console.print(f"\n[bold]Search results for '[cyan]{args.query}[/cyan]':[/bold]\n")

        from .utils.formatter import format_providers_table

        console.print(format_providers_table(results))

        # Check if any result is NOT hashicorp
        non_hashicorp = [p for p in results if not p.get("namespace", "").startswith("hashicorp")]
        if non_hashicorp:
            console.print("\n[yellow]Note:[/yellow] Some results are NOT HashiCorp providers.")
            console.print("  When fetching docs for these, use --namespace flag:")
            console.print(
                f"  Example: tpc doc <resource> --provider {args.query} --namespace <namespace>"
            )

        console.print("\n[bold]Next Steps:[/bold]")
        console.print("  • Get versions: tpc provider versions <name>")
        console.print("  • Fetch docs: tpc doc <resource> --provider <name>")

        return 0
    except TerraformRegistryError as e:
        print_error(f"API error: {e}")
        console.print("\n[yellow]Tip:[/yellow] Check your network connection and try again.")
        return 1

        console.print(f"\n[bold]Search results for '[cyan]{args.query}[/cyan]':[/bold]\n")

        from .utils.formatter import format_providers_table

        console.print(format_providers_table(results))

        # Check if any result is NOT hashicorp
        non_hashicorp = [p for p in results if not p.get("namespace", "").startswith("hashicorp")]
        if non_hashicorp:
            console.print("\n[yellow]Note:[/yellow] Some providers are not from HashiCorp.")
            console.print("  For non-HashiCorp providers, use: --namespace flag")
            console.print(
                "  Example: tpc doc resource --provider databricks --namespace databricks"
            )

        return 0
    except TerraformRegistryError as e:
        print_error(f"API error: {e}")
        return 1


def run_provider_versions(args) -> int:
    """List versions for a provider."""
    from .api.providers import get_provider_versions

    # Get provider name
    provider = args.provider or config.get_default_provider()
    if not provider:
        print_error("No provider specified.")
        print_info("Usage: tpc provider versions <provider-name>")
        print_info("Example: tpc provider versions aws")
        print_info("        tpc provider versions databricks --namespace databricks")
        return 1

    # Get namespace
    namespace = args.namespace
    if not namespace:
        # Try to detect from known namespaces
        from .api.client import KNOWN_NAMESPACES

        namespace = KNOWN_NAMESPACES.get(provider, "hashicorp")

    try:
        versions = get_provider_versions(namespace, provider, limit=args.limit)

        if not versions:
            print_error(f"No versions found for {namespace}/{provider}")
            return 1

        console.print(
            f"\n[bold]Available versions for [cyan]{namespace}/{provider}[/cyan]:[/bold]\n"
        )

        from .utils.formatter import format_versions_table

        console.print(format_versions_table(versions))

        console.print(f"\n[dim]Showing {len(versions)} of {len(versions)} versions[/dim]")
        return 0

    except TerraformRegistryError as e:
        print_error(f"API error: {e}")
        console.print("\n[yellow]Tip:[/yellow] Try specifying namespace with --namespace flag")
        console.print(f"Example: tpc provider versions {provider} --namespace {namespace}")
        return 1


def run_provider(args) -> int:
    """Run provider subcommand."""
    if args.provider_command == "list":
        return run_provider_list(args)
    elif args.provider_command == "search":
        return run_provider_search(args)
    elif args.provider_command == "versions":
        return run_provider_versions(args)
    return 0


def main(argv: list[str] | None = None) -> int:
    """Main entry point."""
    # Handle --info early before parsing (allows tpc --info without subcommand)
    if argv is None:
        import sys

        argv = sys.argv[1:]

    if "--info" in argv or "-i" in argv:
        show_info()
        return 0

    parser = create_parser()
    args = parser.parse_args(argv)

    # Set up logging
    setup_logging(args.verbose)

    # Handle config command separately
    if args.command == "config":
        return run_config(args)

    # Handle info command
    if args.command == "info":
        show_info()
        return 0

    # Handle provider command
    if args.command == "provider":
        return run_provider(args)

    # Check configuration for other commands
    check_configured(args)

    # Create client with provider from args or config
    provider = args.provider or config.get_default_provider()
    client = TerraformRegistryClient(provider=provider)

    # Run the appropriate command
    command = args.command
    if command == "doc":
        return doc.run(args, client)
    elif command == "list":
        return list_cmd.run(args, client)
    elif command == "search":
        return search.run(args, client)
    else:
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
