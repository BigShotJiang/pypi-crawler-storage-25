# © 2026 Strategos. All rights reserved.
# zakon — stub package. Redirects to zakon-zulu.
# See: https://github.com/ShadowStrike-CTF/shadowstrike-suite

try:
    from zakon_zulu import *  # noqa: F401, F403
    from zakon_zulu import __version__  # noqa: F401
except ImportError:
    raise ImportError(
        "zakon requires zakon-zulu. "
        "Install with: pip install zakon-zulu"
    )
