# Zakon

**Zakon** (codename: Zulu) is part of the [Strategos](https://strategos.au)
Suite — professional forensic investigation platform.

Zakon produces structured civil and regulatory output from forensic
evidence processed by the Strategos Suite engine, maintaining strict
architectural separation between criminal and civil/regulatory
investigation workflows.

This package is a namespace holder. Installing `zakon` automatically
installs `zakon-zulu`, the active development package.

## Install

pip install zakon-zulu

## Part of the Strategos Suite

| Product  | Codename | Line      |
|----------|----------|-----------|
| Nika     | niki     | Strategos |
| Komanda  | Kilo     | Strategos |
| Niska    | November | Strategos |
| Sila     | Sierra   | Strategos |
| Vistina  | Victor   | Strategos |
| Zakon    | Zulu     | Strategos |
| Sarissa  | Delta    | Megdan    |
| Treska   | Tango    | Megdan    |
| Poligon  | Papa     | Megdan    |

---

© 2026 Strategos. All rights reserved.
Aut Viam Inveniam Aut Faciam
