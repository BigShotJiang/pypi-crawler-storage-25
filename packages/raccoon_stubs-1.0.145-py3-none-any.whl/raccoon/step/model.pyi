from __future__ import annotations
import dataclasses
from dataclasses import dataclass
import typing
from typing import Protocol
from typing import runtime_checkable
__all__: list[str] = ['Protocol', 'SimulationStep', 'SimulationStepDelta', 'StepProtocol', 'dataclass', 'runtime_checkable']
class SimulationStep:
    """
    Simulation metadata derived from a runtime step.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'id': Field(name='id',type=<class 'str'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'label': Field(name='label',type=str | None,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'average_duration_ms': Field(name='average_duration_ms',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'duration_stddev_ms': Field(name='duration_stddev_ms',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'delta': Field(name='delta',type=<class 'raccoon.step.model.SimulationStepDelta'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('id', 'label', 'average_duration_ms', 'duration_stddev_ms', 'delta')
    def __eq__(self, other):
        ...
    def __init__(self, id: str, label: str | None, average_duration_ms: float, duration_stddev_ms: float, delta: SimulationStepDelta) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class SimulationStepDelta:
    """
    Estimated pose change caused by a step in simulation space.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'forward': Field(name='forward',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'strafe': Field(name='strafe',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'angular': Field(name='angular',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('forward', 'strafe', 'angular')
    def __eq__(self, other):
        ...
    def __init__(self, forward: float, strafe: float, angular: float) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class StepProtocol(typing.Protocol):
    """
    Structural protocol implemented by executable step objects.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __non_callable_proto_members__: typing.ClassVar[set] = set()
    __parameters__: typing.ClassVar[tuple] = tuple()
    __protocol_attrs__: typing.ClassVar[set] = {'required_resources', 'collected_resources', 'run_step'}
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _is_protocol: typing.ClassVar[bool] = True
    _is_runtime_protocol: typing.ClassVar[bool] = True
    @classmethod
    def __subclasshook__(cls, other):
        ...
    def __init__(self, *args, **kwargs):
        ...
    def collected_resources(self) -> frozenset[str]:
        ...
    def required_resources(self) -> frozenset[str]:
        ...
    def run_step(self, robot: GenericRobot) -> None:
        ...
