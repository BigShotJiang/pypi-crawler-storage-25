from .http_client import HTTPClient, AsyncHTTPClient, ExecResult, MetricsResult, SnapshotResult, TemplateInfo, SandboxHTTPError, SandboxNotFoundError, SandboxID, Command, _resolve_id
from .sandbox import Sandbox, AsyncSandbox, SandboxNotRunningError


def __getattr__(name):
    if name == "SandboxClient":
        from .client import SandboxClient
        return SandboxClient
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "SandboxClient",
    "HTTPClient",
    "AsyncHTTPClient",
    "ExecResult",
    "MetricsResult",
    "SnapshotResult",
    "TemplateInfo",
    "SandboxHTTPError",
    "SandboxNotFoundError",
    "SandboxNotRunningError",
    "SandboxID",
    "Command",
    "_resolve_id",
    "Sandbox",
    "AsyncSandbox",
]
