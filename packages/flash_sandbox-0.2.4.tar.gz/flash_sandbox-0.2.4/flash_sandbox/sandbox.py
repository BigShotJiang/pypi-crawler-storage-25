"""High-level Sandbox wrappers for the Flash Sandbox SDK.

This module provides :class:`Sandbox` and :class:`AsyncSandbox`, convenient
object-oriented wrappers around a single sandbox instance.  Instead of passing
``sandbox_id`` to every client method, callers create a :class:`Sandbox` (or
:class:`AsyncSandbox`) and invoke methods directly on it.

Both classes are transport-agnostic: they accept any client that implements
the expected interface (``HTTPClient``, ``AsyncHTTPClient``, or
``SandboxClient``).

Example (sync)::

    from flash_sandbox import HTTPClient, Sandbox

    client = HTTPClient(host="localhost", port=8080)
    sandbox = Sandbox.create(
        client,
        type="docker",
        image="alpine:latest",
        command=["tail", "-f", "/dev/null"],
    )
    print(sandbox.get_status())
    result = sandbox.exec_command(["echo", "hello"])
    print(result.stdout)
    sandbox.stop()

Example (async)::

    from flash_sandbox import AsyncHTTPClient, AsyncSandbox

    async with AsyncHTTPClient(host="localhost") as client:
        sandbox = await AsyncSandbox.create(
            client,
            type="docker",
            image="alpine:latest",
        )
        status = await sandbox.get_status()
        info = await sandbox.get_platform_info()
        await sandbox.stop()
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

from .http_client import Command, SnapshotResult

# Re-export for type hints
OptionalDict = Optional[Dict[str, Any]]

# Statuses that indicate the sandbox is alive and accepting commands.
_RUNNING_STATUSES = frozenset({"running", "created", "restarting", "resuming"})
# Statuses that can be auto-resumed before executing a command.
_RESUMABLE_STATUSES = frozenset({"paused", "snapshotted"})


class SandboxNotRunningError(RuntimeError):
    """Raised when a command targets a sandbox that is not running and cannot be auto-resumed."""


class Sandbox:
    """High-level wrapper around a single sandbox instance (synchronous).

    This class delegates to an underlying client (``HTTPClient`` or
    ``SandboxClient``) but binds the ``sandbox_id`` so that callers
    never need to pass it explicitly.

    Parameters
    ----------
    sandbox_id:
        The unique identifier of the sandbox.
    client:
        A synchronous sandbox client instance (e.g. ``HTTPClient`` or
        ``SandboxClient``).
    """

    def __init__(self, sandbox_id: str, client: Any) -> None:
        self.id: str = sandbox_id
        self._client = client

    # ------------------------------------------------------------------ #
    # Factory
    # ------------------------------------------------------------------ #

    @classmethod
    def create(
        cls,
        client: Any,
        type: str,
        image: str,
        command: Optional[List[str]] = None,
        memory_mb: int = 512,
        cpu_cores: float = 1.0,
        gpu: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> "Sandbox":
        """Create a new sandbox and return a :class:`Sandbox` wrapping it.

        All arguments (beyond *client*) are forwarded to the client's
        ``start_sandbox`` method.

        Parameters
        ----------
        client:
            A synchronous sandbox client.
        type:
            Sandbox backend (e.g. ``"docker"``).
        image:
            Container / rootfs image name.
        command:
            Entrypoint command.
        memory_mb:
            Memory limit in megabytes.
        cpu_cores:
            CPU cores limit.
        gpu:
            GPU configuration dictionary for NVIDIA GPU support.
            Supported by ``runc`` and ``crun`` backends via containerd.
            Example: ``{"device_ids": ["all"], "driver": "compute"}``.
        **kwargs:
            Additional keyword arguments forwarded to ``start_sandbox``
            (e.g. ``kernel_image``, ``snapshot_path``).

        Returns
        -------
        Sandbox
            A new :class:`Sandbox` bound to the created sandbox.
        """
        start_kwargs = dict(
            type=type,
            image=image,
            command=command,
            memory_mb=memory_mb,
            cpu_cores=cpu_cores,
        )
        if gpu is not None:
            start_kwargs["gpu"] = gpu
        start_kwargs.update(kwargs)
        result = client.start_sandbox(**start_kwargs)
        # HTTP clients return a Sandbox directly; gRPC returns a plain ID.
        if isinstance(result, cls):
            return result
        return cls(result, client)

    # ------------------------------------------------------------------ #
    # Sandbox operations
    # ------------------------------------------------------------------ #

    def _ensure_running(self) -> None:
        """Check that the sandbox is running, auto-resuming if paused.

        Raises
        ------
        SandboxNotRunningError
            If the sandbox exists but is in a non-resumable stopped state.
        """
        status = self._client.get_status(self.id)
        if status.lower() in _RUNNING_STATUSES:
            return
        if status.lower() in _RESUMABLE_STATUSES:
            self._client.resume_sandbox(self.id)
            return
        raise SandboxNotRunningError(
            f"Sandbox {self.id} is '{status}' and cannot execute commands"
        )

    def get_status(self) -> str:
        """Return the current status of the sandbox (e.g. ``"running"``)."""
        return self._client.get_status(self.id)

    def exec_command(self, command: Command, *, interactive: Optional[bool] = None) -> Any:
        """Execute a one-shot command inside the sandbox.

        Parameters
        ----------
        command:
            The command to execute.
        interactive:
            **Deprecated.** If ``True``, routes to :meth:`shell_exec`.
        """
        self._ensure_running()
        kwargs = {}
        if interactive is not None:
            kwargs["interactive"] = interactive
        return self._client.exec_command(self.id, command, **kwargs)

    def shell_exec(self, command: Command) -> Any:
        """Execute a command in the persistent shell.

        The persistent shell preserves state (``cd``, ``export``,
        ``source``) across calls within the same sandbox.

        Parameters
        ----------
        command:
            The command to execute.

        Returns
        -------
        ExecResult or equivalent
            An object with ``stdout``, ``stderr``, and ``exit_code``.
        """
        self._ensure_running()
        return self._client.shell_exec(self.id, command)

    def run_python(self, code: str) -> str:
        """Execute a Python code snippet inside the sandbox.

        Parameters
        ----------
        code:
            The Python source code to execute.

        Returns
        -------
        str
            The standard output produced by the code.
        """
        self._ensure_running()
        return self._client.run_python(self.id, code)

    def get_platform_info(self) -> Dict[str, Any]:
        """Get platform information from the sandbox.

        Returns
        -------
        dict
            A dictionary containing platform info (e.g. keys like
            ``"system"``, ``"node"``, ``"release"``, ``"version"``,
            ``"machine"``, ``"processor"``).
        """
        self._ensure_running()
        return self._client.get_platform_info(self.id)

    def get_metrics(self) -> Any:
        """Return point-in-time resource-usage metrics.

        Returns
        -------
        MetricsResult or equivalent
            Dataclass with memory, CPU, network, and block-I/O counters.
        """
        self._ensure_running()
        return self._client.get_metrics(self.id)

    def read_file(self, path: str) -> bytes:
        """Read a file from the sandbox.

        Parameters
        ----------
        path:
            The path of the file to read.

        Returns
        -------
        bytes
            The contents of the file.
        """
        self._ensure_running()
        return self._client.read_file(self.id, path)

    def write_file(self, path: str, content: bytes) -> None:
        """Write a file to the sandbox.

        Parameters
        ----------
        path:
            The path of the file to write.
        content:
            The file content as bytes.
        """
        self._ensure_running()
        self._client.write_file(self.id, path, content)

    def snapshot(self) -> SnapshotResult:
        """Create a snapshot of the sandbox.

        Returns
        -------
        SnapshotResult
            Dataclass with ``snapshot_path``, ``mem_file_path``, and
            ``node_id`` fields.
        """
        return self._client.snapshot_sandbox(self.id)

    def resume(self) -> None:
        """Resume the sandbox from a paused / snapshotted state."""
        self._client.resume_sandbox(self.id)

    def stop(self, cleanup: bool = True) -> None:
        """Stop the sandbox.

        Parameters
        ----------
        cleanup:
            When ``True`` (the default), backing resources (container, VM,
            temporary files) are removed.  When ``False`` the sandbox
            process is stopped but resources are left in place for
            inspection or later resumption.
        """
        self._client.stop_sandbox(self.id, cleanup=cleanup)

    # ------------------------------------------------------------------ #
    # Context manager
    # ------------------------------------------------------------------ #

    def __enter__(self) -> "Sandbox":
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.stop(cleanup=True)

    # ------------------------------------------------------------------ #
    # Representation
    # ------------------------------------------------------------------ #

    def __repr__(self) -> str:
        return f"Sandbox(id={self.id!r})"


class AsyncSandbox:
    """High-level wrapper around a single sandbox instance (asynchronous).

    This is the ``async`` counterpart of :class:`Sandbox`.  It delegates
    to an asynchronous client (``AsyncHTTPClient``) and all I/O methods
    are coroutines.

    Parameters
    ----------
    sandbox_id:
        The unique identifier of the sandbox.
    client:
        An asynchronous sandbox client instance (e.g. ``AsyncHTTPClient``).
    """

    def __init__(self, sandbox_id: str, client: Any) -> None:
        self.id: str = sandbox_id
        self._client = client

    # ------------------------------------------------------------------ #
    # Factory
    # ------------------------------------------------------------------ #

    @classmethod
    async def create(
        cls,
        client: Any,
        type: str,
        image: str,
        command: Optional[List[str]] = None,
        memory_mb: int = 512,
        cpu_cores: float = 1.0,
        gpu: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> "AsyncSandbox":
        """Create a new sandbox and return an :class:`AsyncSandbox` wrapping it.

        All arguments (beyond *client*) are forwarded to the client's
        ``start_sandbox`` coroutine.

        Parameters
        ----------
        client:
            An asynchronous sandbox client.
        type:
            Sandbox backend (e.g. ``"docker"``).
        image:
            Container / rootfs image name.
        command:
            Entrypoint command.
        memory_mb:
            Memory limit in megabytes.
        cpu_cores:
            CPU cores limit.
        gpu:
            GPU configuration dictionary for NVIDIA GPU support.
            Supported by ``runc`` and ``crun`` backends via containerd.
            Example: ``{"device_ids": ["all"], "driver": "compute"}``.
        **kwargs:
            Additional keyword arguments forwarded to ``start_sandbox``
            (e.g. ``kernel_image``, ``snapshot_path``).

        Returns
        -------
        AsyncSandbox
            A new :class:`AsyncSandbox` bound to the created sandbox.
        """
        start_kwargs = dict(
            type=type,
            image=image,
            command=command,
            memory_mb=memory_mb,
            cpu_cores=cpu_cores,
        )
        if gpu is not None:
            start_kwargs["gpu"] = gpu
        start_kwargs.update(kwargs)
        result = await client.start_sandbox(**start_kwargs)
        # HTTP clients return an AsyncSandbox directly; gRPC returns a plain ID.
        if isinstance(result, cls):
            return result
        return cls(result, client)

    # ------------------------------------------------------------------ #
    # Sandbox operations
    # ------------------------------------------------------------------ #

    async def _ensure_running(self) -> None:
        """Check that the sandbox is running, auto-resuming if paused.

        Raises
        ------
        SandboxNotRunningError
            If the sandbox exists but is in a non-resumable stopped state.
        """
        status = await self._client.get_status(self.id)
        if status.lower() in _RUNNING_STATUSES:
            return
        if status.lower() in _RESUMABLE_STATUSES:
            await self._client.resume_sandbox(self.id)
            return
        raise SandboxNotRunningError(
            f"Sandbox {self.id} is '{status}' and cannot execute commands"
        )

    async def get_status(self) -> str:
        """Return the current status of the sandbox (e.g. ``"running"``)."""
        return await self._client.get_status(self.id)

    async def exec_command(self, command: Command, *, interactive: Optional[bool] = None) -> Any:
        """Execute a one-shot command inside the sandbox.

        Parameters
        ----------
        command:
            The command to execute.
        interactive:
            **Deprecated.** If ``True``, routes to :meth:`shell_exec`.
        """
        await self._ensure_running()
        kwargs = {}
        if interactive is not None:
            kwargs["interactive"] = interactive
        return await self._client.exec_command(self.id, command, **kwargs)

    async def shell_exec(self, command: Command) -> Any:
        """Execute a command in the persistent shell.

        Parameters
        ----------
        command:
            The command to execute.

        Returns
        -------
        ExecResult or equivalent
            An object with ``stdout``, ``stderr``, and ``exit_code``.
        """
        await self._ensure_running()
        return await self._client.shell_exec(self.id, command)

    async def run_python(self, code: str) -> str:
        """Execute a Python code snippet inside the sandbox.

        Parameters
        ----------
        code:
            The Python source code to execute.

        Returns
        -------
        str
            The standard output produced by the code.
        """
        await self._ensure_running()
        return await self._client.run_python(self.id, code)

    async def get_platform_info(self) -> Dict[str, Any]:
        """Get platform information from the sandbox.

        Returns
        -------
        dict
            A dictionary containing platform info (e.g. keys like
            ``"system"``, ``"node"``, ``"release"``, ``"version"``,
            ``"machine"``, ``"processor"``).
        """
        await self._ensure_running()
        return await self._client.get_platform_info(self.id)

    async def get_metrics(self) -> Any:
        """Return point-in-time resource-usage metrics.

        Returns
        -------
        MetricsResult or equivalent
            Dataclass with memory, CPU, network, and block-I/O counters.
        """
        await self._ensure_running()
        return await self._client.get_metrics(self.id)

    async def read_file(self, path: str) -> bytes:
        """Read a file from the sandbox.

        Parameters
        ----------
        path:
            The path of the file to read.

        Returns
        -------
        bytes
            The contents of the file.
        """
        await self._ensure_running()
        return await self._client.read_file(self.id, path)

    async def write_file(self, path: str, content: bytes) -> None:
        """Write a file to the sandbox.

        Parameters
        ----------
        path:
            The path of the file to write.
        content:
            The file content as bytes.
        """
        await self._ensure_running()
        await self._client.write_file(self.id, path, content)

    async def snapshot(self) -> SnapshotResult:
        """Create a snapshot of the sandbox.

        Returns
        -------
        SnapshotResult
            Dataclass with ``snapshot_path``, ``mem_file_path``, and
            ``node_id`` fields.
        """
        return await self._client.snapshot_sandbox(self.id)

    async def resume(self) -> None:
        """Resume the sandbox from a paused / snapshotted state."""
        await self._client.resume_sandbox(self.id)

    async def stop(self, cleanup: bool = True) -> None:
        """Stop the sandbox.

        Parameters
        ----------
        cleanup:
            When ``True`` (the default), backing resources (container, VM,
            temporary files) are removed.  When ``False`` the sandbox
            process is stopped but resources are left in place for
            inspection or later resumption.
        """
        await self._client.stop_sandbox(self.id, cleanup=cleanup)

    # ------------------------------------------------------------------ #
    # Async context manager
    # ------------------------------------------------------------------ #

    async def __aenter__(self) -> "AsyncSandbox":
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.stop(cleanup=True)

    # ------------------------------------------------------------------ #
    # Representation
    # ------------------------------------------------------------------ #

    def __repr__(self) -> str:
        return f"AsyncSandbox(id={self.id!r})"
