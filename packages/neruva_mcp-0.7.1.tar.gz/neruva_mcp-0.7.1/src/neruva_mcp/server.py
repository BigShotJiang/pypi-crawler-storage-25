"""Neruva MCP server.

Exposes Neruva Memory + HD Substrate to any MCP-aware host as a small
set of tools. Pure thin wrapper over the REST API at api.neruva.io --
this process holds NO algorithmic state and imports nothing from the
substrate core. The hard work happens server-side; this is just glue.

Env:
  NERUVA_API_KEY  required, your key from app.neruva.io
  NERUVA_URL      optional, defaults to https://api.neruva.io
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from typing import Any
from urllib.parse import quote

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

API_KEY = os.environ.get("NERUVA_API_KEY")
BASE_URL = os.environ.get("NERUVA_URL", "https://api.neruva.io").rstrip("/")

# Optional auto-record. Set NERUVA_AUTO_RECORD=namespace[:ttl_days] to
# capture every tool call into a Neruva Records namespace as a typed
# event ({kind:"tool_call", tool, ...}) via fire-and-forget POSTs that
# never block or fail the user's call.
#
# Accepted forms (the legacy `index/` prefix from 0.4.x is silently
# dropped -- records have no index abstraction):
#   NERUVA_AUTO_RECORD=main              # no TTL
#   NERUVA_AUTO_RECORD=main:30           # auto-expire after 30 days
#   NERUVA_AUTO_RECORD=brain/main:30     # legacy form; "brain/" stripped
_AUTO_RECORD_RAW = os.environ.get("NERUVA_AUTO_RECORD", "")


def _parse_auto_record(s: str) -> tuple[str, int | None]:
    if not s:
        return "", None
    main, ttl_days = s, None
    colon_idx = s.rfind(":")
    if colon_idx > 0 and colon_idx > s.rfind("/"):
        tail = s[colon_idx + 1 :]
        try:
            n = int(tail)
            if n > 0:
                ttl_days = n
                main = s[:colon_idx]
        except ValueError:
            pass
    if "/" in main:
        _idx, ns = main.split("/", 1)  # legacy 'index/' prefix dropped
        return ns, ttl_days
    return main, ttl_days


AR_NAMESPACE, AR_TTL_DAYS = _parse_auto_record(_AUTO_RECORD_RAW)

NO_RECORD_TOOLS: set[str] = {
    # Records I/O used by the recorder itself -- recording these would loop.
    "records_ingest",
    "records_query",
    "records_timeline",
    "records_get",
    "records_delete",
    "records_forget",
    "records_stats",
    "records_export",
    "records_import",
    "records_compact",
    # Memory index (legacy vector layer) I/O -- same recursion concern.
    "memory_embed",
    "memory_upsert",
    "memory_upsert_text",
    "memory_query",
    "memory_query_text",
    "memory_fetch",
    "memory_update",
    "memory_replace_text",
    "memory_delete",
    "memory_forget_where",
    "memory_export",
    "memory_import",
    "memory_stats",
    "memory_list_indexes",
    "memory_describe_index",
    "memory_create_index",
    "memory_bind_role",
    "memory_read_roles",
}


def _record_preview(value: Any, max_len: int) -> str:
    try:
        s = value if isinstance(value, str) else json.dumps(value, default=str)
    except Exception:
        s = str(value)
    return s if len(s) <= max_len else s[:max_len] + "..."


async def _maybe_record(
    client: httpx.AsyncClient,
    tool_name: str,
    args: dict[str, Any],
    result: Any,
    latency_ms: int,
) -> None:
    if not AR_NAMESPACE:
        return
    if tool_name in NO_RECORD_TOOLS:
        return
    text = (
        f"{tool_name}({_record_preview(args, 400)})\n"
        f"=> {_record_preview(result, 800)}"
    )
    rid = f"mcp-{int(time.time() * 1000)}-{os.urandom(3).hex()}"
    now_ms = int(time.time() * 1000)
    item: dict[str, Any] = {
        "id": rid,
        "kind": "tool_call",
        "text": text,
        "tags": ["mcp", f"tool:{tool_name}"],
        "ts": now_ms,
        "meta": {"tool": tool_name, "latency_ms": latency_ms},
    }
    if AR_TTL_DAYS:
        item["ttlDays"] = AR_TTL_DAYS
    try:
        await client.post(
            f"{BASE_URL}/v1/records/{quote(AR_NAMESPACE, safe='')}",
            headers={"Api-Key": API_KEY or "", "Content-Type": "application/json"},
            json={"items": [item]},
        )
    except Exception:
        # Never break the user's tool call.
        pass


def _enc(s: str) -> str:
    return quote(s, safe="")


def _fold_tags(
    filter_: dict[str, Any] | None,
    tags: list[str] | None,
) -> dict[str, Any] | None:
    """Sugar: tags=['foo','bar'] -> AND-of-$in metadata.tags filter.

    Combines with an explicit filter if both are present."""
    if not tags:
        return filter_
    tag_blocks = [{"tags": {"$in": [t]}} for t in tags]
    tag_block: dict[str, Any] = (
        tag_blocks[0] if len(tag_blocks) == 1 else {"$and": tag_blocks}
    )
    if not filter_:
        return tag_block
    return {"$and": [filter_, tag_block]}


async def _call(
    client: httpx.AsyncClient,
    method: str,
    path: str,
    body: Any | None = None,
) -> Any:
    headers = {"Api-Key": API_KEY or ""}
    if body is not None:
        headers["Content-Type"] = "application/json"
    r = await client.request(method, BASE_URL + path, headers=headers, json=body)
    if r.status_code >= 400:
        raise RuntimeError(f"{method} {path} -> {r.status_code}: {r.text}")
    try:
        return r.json()
    except Exception:
        return r.text


TOOLS: list[Tool] = [
    # ==================================================================
    # Records -- the primary typed-event substrate. Use these first.
    # ==================================================================
    Tool(
        name="records_ingest",
        description=(
            "Append one or more typed events (decisions, mistakes, llm_turns, "
            "tool_calls, user_prompts, ...) to a namespace. Server auto-embeds "
            "the text via the static-MRL D=1024 encoder. Each item: "
            "{kind, text, tags?, ts?, meta?, id?, ttlDays?}. Returns ids. "
            "Records have first-class kind / tags / ts -- no metadata-dict "
            "filter gymnastics."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "items": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "kind": {"type": "string"},
                            "text": {"type": "string"},
                            "tags": {"type": "array", "items": {"type": "string"}, "default": []},
                            "ts": {"type": "integer"},
                            "meta": {"type": "object"},
                            "id": {"type": "string"},
                            "ttlDays": {"type": "integer"},
                            "userId": {"type": "string"},
                        },
                        "required": ["kind", "text"],
                    },
                },
            },
            "required": ["namespace", "items"],
        },
    ),
    Tool(
        name="records_query",
        description=(
            "Semantic + typed-filter query against a Records namespace. Pass "
            "`text` for cosine ranking; omit `text` for a typed-only scan "
            "ordered by ts descending. Filters: `kind` (array), `tagsAny`, "
            "`tagsAll`, `tsGte`, `tsLt`."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "text": {"type": "string"},
                "topK": {"type": "integer", "default": 10},
                "kind": {"type": "array", "items": {"type": "string"}},
                "tagsAny": {"type": "array", "items": {"type": "string"}},
                "tagsAll": {"type": "array", "items": {"type": "string"}},
                "tsGte": {"type": "integer"},
                "tsLt": {"type": "integer"},
                "userId": {"type": "string"},
                "includeText": {"type": "boolean", "default": True},
                "includeMeta": {"type": "boolean", "default": True},
            },
            "required": ["namespace"],
        },
    ),
    Tool(
        name="records_timeline",
        description=(
            "Return records in a namespace as a timeline (most-recent first). "
            "Filter by kind (comma-separated string), tagsAny, tagsAll, since, "
            "until. limit defaults to 50 (max 500). Use `until = nextCursor` "
            "from a prior response to page back in time."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "since": {"type": "integer"},
                "until": {"type": "integer"},
                "kind": {"type": "string"},
                "tagsAny": {"type": "string"},
                "tagsAll": {"type": "string"},
                "userId": {"type": "string"},
                "limit": {"type": "integer", "default": 50},
            },
            "required": ["namespace"],
        },
    ),
    Tool(
        name="records_get",
        description="Fetch a single record by id. 404 if not found.",
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "id": {"type": "string"},
            },
            "required": ["namespace", "id"],
        },
    ),
    Tool(
        name="records_delete",
        description="Soft-delete one record by id.",
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "id": {"type": "string"},
            },
            "required": ["namespace", "id"],
        },
    ),
    Tool(
        name="records_forget",
        description=(
            "GDPR-style bulk forget with typed predicates. Pass any combination "
            "of kind / tagsAny / tagsAll / tsGte / tsLt / ids. Returns "
            "forgottenCount."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "kind": {"type": "array", "items": {"type": "string"}},
                "tagsAny": {"type": "array", "items": {"type": "string"}},
                "tagsAll": {"type": "array", "items": {"type": "string"}},
                "tsGte": {"type": "integer"},
                "tsLt": {"type": "integer"},
                "userId": {"type": "string"},
                "ids": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["namespace"],
        },
    ),
    Tool(
        name="records_compact",
        description=(
            "Consolidate a predicate-selected slice of records into one summary "
            "record + tombstone the originals. Keeps long-running namespaces "
            "lean. Summary carries kind=summary (configurable), tags=[summary, "
            "compacted, ...inherited], and meta {compacted_count, original_ids, "
            "compacted_kinds, compacted_oldest_ts, compacted_newest_ts}."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "kind": {"type": "array", "items": {"type": "string"}},
                "tagsAny": {"type": "array", "items": {"type": "string"}},
                "tagsAll": {"type": "array", "items": {"type": "string"}},
                "tsGte": {"type": "integer"},
                "tsLt": {"type": "integer"},
                "userId": {"type": "string"},
                "summaryKind": {"type": "string", "default": "summary"},
                "maxChars": {"type": "integer", "default": 4000},
            },
            "required": ["namespace"],
        },
    ),
    Tool(
        name="records_stats",
        description="Per-namespace stats: count, by_kind histogram, oldest_ts, newest_ts.",
        inputSchema={
            "type": "object",
            "properties": {"namespace": {"type": "string", "default": ""}},
            "required": ["namespace"],
        },
    ),
    Tool(
        name="records_export",
        description=(
            "Export the namespace as a portable .neruva container "
            "(zip of manifest + records section + reserved kg/scm/analogy "
            "slots). Returns base64 of the .neruva blob."
        ),
        inputSchema={
            "type": "object",
            "properties": {"namespace": {"type": "string", "default": ""}},
            "required": ["namespace"],
        },
    ),
    Tool(
        name="records_import",
        description=(
            "Import a .neruva container into a namespace (REPLACE semantic). "
            "Pass base64-encoded .neruva blob. Returns {imported: N, manifest}."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "neruva_base64": {"type": "string"},
            },
            "required": ["namespace", "neruva_base64"],
        },
    ),
    # ==================================================================
    # Memory index (legacy vector layer) -- migration on-ramp; records_* preferred.
    # ==================================================================
    Tool(
        name="memory_embed",
        description=(
            "Encode one or more texts to L2-normalized D=1024 float vectors using "
            "the server-side static-MRL encoder. Use this for memory_upsert and "
            "memory_query when you don't have a local encoder. ~7000 texts/sec on "
            "the hosted instance; first call adds ~5s for model load."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "texts": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Texts to embed (truncated at ~512 tokens internally).",
                },
            },
            "required": ["texts"],
        },
    ),
    Tool(
        name="memory_upsert_text",
        description=(
            "Embed and upsert text in a single call -- the all-in-one for new "
            "users. Server runs static-MRL D=1024 internally. Each item: "
            "{id, text, metadata?}. Original text auto-stored into metadata.text."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "items": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "text": {"type": "string"},
                            "metadata": {"type": "object"},
                        },
                        "required": ["id", "text"],
                    },
                },
            },
            "required": ["index", "items"],
        },
    ),
    Tool(
        name="memory_query_text",
        description=(
            "Embed a text query and search the namespace in one call. Returns "
            "top-K matches by cosine; metadata included by default. Pass "
            "tags=['foo','bar'] for convenient AND-filter on metadata.tags."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "text": {"type": "string"},
                "topK": {"type": "integer", "default": 10},
                "includeMetadata": {"type": "boolean", "default": True},
                "includeValues": {"type": "boolean", "default": False},
                "filter": {"type": "object", "description": "Metadata filter ({field: value} or {field: {$eq|$gte|$lte|$in: ...}})"},
                "tags": {
                    "type": "array", "items": {"type": "string"},
                    "description": "Convenience AND-filter on metadata.tags",
                },
            },
            "required": ["index", "text"],
        },
    ),
    Tool(
        name="memory_replace_text",
        description=(
            "Re-encode a new text and overwrite the existing vector + metadata.text "
            "in one call. Surgical: bipolar prefilter row, float rerank vector, and "
            "metadata all updated atomically. Use for refactor tracking or any "
            "existing memory whose content changed."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "id": {"type": "string"},
                "newText": {"type": "string"},
            },
            "required": ["index", "id", "newText"],
        },
    ),
    Tool(
        name="memory_forget_where",
        description=(
            "Bulk-delete vectors whose metadata matches a filter. "
            "Filter: {field: value} or {field: {$eq|$gte|$lte|$in: ...}}. GDPR Article 17 "
            "in one call -- forget every vector tagged {user_id: 'alice'}."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "filter": {"type": "object"},
            },
            "required": ["index", "filter"],
        },
    ),
    Tool(
        name="memory_bind_role",
        description=(
            "Bind a named role atom onto a stored vector's bipolar prefilter row. "
            "Lets you narrow future queries by compound roles like ['user', "
            "'from_alice'] without a secondary index."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "id": {"type": "string"},
                "role": {"type": "string"},
            },
            "required": ["index", "id", "role"],
        },
    ),
    Tool(
        name="memory_read_roles",
        description=(
            "Approximate-unbind introspection: given a stored vector's id and its "
            "original encoder vector, recover the role atoms it was bound under. "
            "Pass roleDict mapping axis names to candidate role names; returns "
            "axis -> [best_role, score]."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "id": {"type": "string"},
                "queryVector": {"type": "array", "items": {"type": "number"}},
                "roleDict": {"type": "object"},
                "known": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["index", "id", "queryVector", "roleDict"],
        },
    ),
    Tool(
        name="memory_create_index",
        description=(
            "Create a vector index. Required once before "
            "memory_upsert / memory_query / memory_delete can be used. "
            "Idempotent on existing indexes."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Index name"},
                "dimension": {
                    "type": "integer",
                    "description": "Vector dimension (e.g. 1024 for static-MRL)",
                },
                "metric": {
                    "type": "string",
                    "enum": ["cosine", "dotproduct", "euclidean"],
                    "default": "cosine",
                },
            },
            "required": ["name", "dimension"],
        },
    ),
    Tool(
        name="memory_list_indexes",
        description="List all indexes for your account.",
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    Tool(
        name="memory_describe_index",
        description="Describe one index (dimension, metric, host, status).",
        inputSchema={
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        },
    ),
    Tool(
        name="memory_stats",
        description="Per-namespace vector counts and total vector count for an index.",
        inputSchema={
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        },
    ),
    Tool(
        name="memory_fetch",
        description="Fetch one or more vectors by id from a namespace.",
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "ids": {"type": "array", "items": {"type": "string"}},
                "namespace": {"type": "string", "default": ""},
            },
            "required": ["index", "ids"],
        },
    ),
    Tool(
        name="memory_update",
        description=(
            "Update one vector in a namespace -- replace its values and/or metadata "
            "without re-upserting. ID must already exist."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "id": {"type": "string"},
                "values": {"type": "array", "items": {"type": "number"}},
                "metadata": {"type": "object"},
                "namespace": {"type": "string", "default": ""},
            },
            "required": ["index", "id"],
        },
    ),
    Tool(
        name="memory_export",
        description=(
            "Export an index (or one namespace) to the portable .nmm format. "
            "Returns base64-encoded bytes. Take your memory between providers, "
            "environments, agents."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "description": "Optional namespace; omit to export the whole index."},
            },
            "required": ["index"],
        },
    ),
    Tool(
        name="memory_import",
        description=(
            "Import a previously-exported .nmm blob into an index. Index must already "
            "exist with matching dimension. Pass base64-encoded bytes via nmm_base64."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "nmm_base64": {"type": "string"},
            },
            "required": ["index", "nmm_base64"],
        },
    ),
    Tool(
        name="memory_upsert",
        description=(
            "Insert or update vectors in a Neruva Memory namespace. The "
            "index must exist (create it once with memory_create_index)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string", "description": "Index name"},
                "namespace": {
                    "type": "string",
                    "description": "Namespace; defaults to ''",
                    "default": "",
                },
                "vectors": {
                    "type": "array",
                    "description": "Vectors: {id, values, metadata?}",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "values": {"type": "array", "items": {"type": "number"}},
                            "metadata": {"type": "object"},
                        },
                        "required": ["id", "values"],
                    },
                },
            },
            "required": ["index", "vectors"],
        },
    ),
    Tool(
        name="memory_query",
        description=(
            "Cosine-search a namespace by vector. Returns top-K matches with metadata. "
            "Pass tags=['foo','bar'] for convenient AND-filter on metadata.tags."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "vector": {"type": "array", "items": {"type": "number"}},
                "topK": {"type": "integer", "default": 10},
                "includeMetadata": {"type": "boolean", "default": True},
                "includeValues": {"type": "boolean", "default": False},
                "filter": {"type": "object", "description": "Metadata filter ({field: value} or {field: {$eq|$gte|$lte|$in: ...}})"},
                "tags": {
                    "type": "array", "items": {"type": "string"},
                    "description": "Convenience AND-filter on metadata.tags",
                },
            },
            "required": ["index", "vector"],
        },
    ),
    Tool(
        name="memory_delete",
        description="Delete vectors by id from a namespace. The index must exist.",
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "ids": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["index", "ids"],
        },
    ),
    Tool(
        name="hd_kg_add_fact",
        description=(
            "Add a (subject, relation, object) fact to a knowledge graph. "
            "The KG is auto-created on first add. Persists across restarts."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string", "description": "Knowledge-graph name"},
                "subject": {"type": "string"},
                "relation": {"type": "string"},
                "object": {"type": "string"},
            },
            "required": ["kg", "subject", "relation", "object"],
        },
    ),
    Tool(
        name="hd_kg_query",
        description=(
            "Query a knowledge graph for the object of (subject, relation). "
            "Returns object + confidence. Returns object=null with confidence=0 "
            "when the subject is unknown or no fact matches above the noise "
            "threshold (cosine 0.05)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "subject": {"type": "string"},
                "relation": {"type": "string"},
            },
            "required": ["kg", "subject", "relation"],
        },
    ),
    Tool(
        name="hd_kg_export",
        description=(
            "Export a knowledge graph to the portable .hdkg format. Returns "
            "base64-encoded bytes. Take your KG between providers, environments."
        ),
        inputSchema={
            "type": "object",
            "properties": {"kg": {"type": "string"}},
            "required": ["kg"],
        },
    ),
    Tool(
        name="hd_kg_import",
        description=(
            "Import (or replace) a knowledge graph from a previously-exported "
            ".hdkg blob. Pass base64-encoded bytes via hdkg_base64."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "hdkg_base64": {"type": "string"},
            },
            "required": ["kg", "hdkg_base64"],
        },
    ),
    Tool(
        name="hd_causal_export",
        description=(
            "Export a structural causal model to the portable .hdscm format. "
            "Returns base64-encoded bytes."
        ),
        inputSchema={
            "type": "object",
            "properties": {"scm": {"type": "string"}},
            "required": ["scm"],
        },
    ),
    Tool(
        name="hd_causal_import",
        description=(
            "Import (or replace) an SCM from a previously-exported .hdscm blob. "
            "Pass base64-encoded bytes via hdscm_base64."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scm": {"type": "string"},
                "hdscm_base64": {"type": "string"},
            },
            "required": ["scm", "hdscm_base64"],
        },
    ),
    Tool(
        name="hd_kg_delete_fact",
        description=(
            "Remove a previously-added (subject, relation, object) triple from a "
            "knowledge graph. Subtracts the bound vector from the relation shard, "
            "exactly cancelling the original add. Required for any mutable-state "
            "use case (refactor tracking, deploy status, project state). Triples "
            "whose tokens are unknown are skipped (no-op, not error)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string", "description": "Knowledge-graph name"},
                "subject": {"type": "string"},
                "relation": {"type": "string"},
                "object": {"type": "string"},
            },
            "required": ["kg", "subject", "relation", "object"],
        },
    ),
    Tool(
        name="hd_analogy",
        description=(
            "Solve a four-term analogy in HD feature space: a is to b as c is to ? "
            "Items are integer feature IDs in [0, 2^n_feat). Returns the cleaned-up "
            "candidate plus cosine, runner-up cosine, and a confidence gap."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "n_feat": {"type": "integer", "description": "Number of binary features. Item space size is 2^n_feat."},
                "a": {"type": "integer"},
                "b": {"type": "integer"},
                "c": {"type": "integer"},
                "seed": {"type": "integer", "default": 4301},
            },
            "required": ["n_feat", "a", "b", "c"],
        },
    ),
    Tool(
        name="hd_causal_add_worlds",
        description=(
            "Add or extend a structural causal model (SCM) with integer-coded worlds. "
            "Required once before hd_causal_query can run on a given SCM name. Worlds "
            "are rows of length n_vars; each entry is the value of that variable."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scm": {"type": "string", "description": "SCM name"},
                "n_vars": {"type": "integer", "description": "Number of variables"},
                "vocab_per_var": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "Cardinality per variable; length must equal n_vars",
                },
                "worlds": {
                    "type": "array",
                    "items": {"type": "array", "items": {"type": "integer"}},
                    "description": "Shape (N, n_vars). Each row is one world.",
                },
                "seed": {"type": "integer", "default": 4401},
            },
            "required": ["scm", "n_vars", "vocab_per_var", "worlds"],
        },
    ),
    Tool(
        name="hd_causal_query",
        description=(
            "Run an observational or interventional query against a stored causal model. "
            "The SCM must exist (call hd_causal_add_worlds first). query_type is "
            "'observation' or 'intervention' -- arithmetically distinct."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scm": {"type": "string", "description": "Causal-model name"},
                "query_type": {"type": "string", "enum": ["observation", "intervention"]},
                "condition_var": {"type": "integer"},
                "condition_value": {"type": "integer"},
                "query_var": {"type": "integer"},
                "query_value": {"type": "integer"},
            },
            "required": [
                "scm",
                "query_type",
                "condition_var",
                "condition_value",
                "query_var",
                "query_value",
            ],
        },
    ),
    # hd_plan removed in 0.2.0. Returning in 0.2.x with
    # hd_plan_register_model + hd_plan_with_model so users can describe
    # their actual transition kernels.

    # ==================================================================
    # Self-introspection -- what's in MY substrate, what did I just do,
    # how is my wallet doing. The wedge: agents introspect themselves
    # without leaving the loop to read a dashboard.
    # ==================================================================
    Tool(
        name="neruva_wallet_status",
        description=(
            "Caller's wallet snapshot: balance_usd, low_balance, "
            "projected_days_left (based on 7-day burn), last_topup_usd, "
            "last_topup_capture_id, last_charge_ts, burn_7d_usd. Use this "
            "when an agent should warn the user that funds are low before "
            "continuing an expensive task."
        ),
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="neruva_op_stats",
        description=(
            "Aggregate API usage over the trailing window. Returns total "
            "calls, total cost_usd, by_op (per op-class), by_namespace, "
            "by_day. Use this to answer 'how much has my agent spent on "
            "records vs HD KG today?' or 'which namespace is burning the "
            "most?'."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "window": {"type": "string", "enum": ["7d", "30d"], "default": "30d"},
            },
        },
    ),
    Tool(
        name="neruva_keys_list",
        description=(
            "List the caller's API keys (metadata only -- never raw key "
            "material). Returns id, prefix (last chars of the key), label, "
            "created_at_ms, revoked. Use this to audit which keys exist "
            "and whether stale ones should be revoked."
        ),
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="neruva_op_log",
        description=(
            "Last N op events for the caller (most recent first). Each "
            "entry: ts_ms, op (op-class string), namespace, latency_ms, "
            "status (HTTP). Powered by the metering ring buffer; typical "
            "lag is ~3 seconds. Use this for live agent debugging: 'why "
            "was my last query slow?', 'did my last ingest actually "
            "succeed?'."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "minimum": 1, "maximum": 200, "default": 50},
            },
        },
    ),
]


async def _dispatch(client: httpx.AsyncClient, name: str, args: dict[str, Any]) -> Any:
    # ----- Records -----
    if name == "records_ingest":
        return await _call(
            client, "POST",
            f"/v1/records/{_enc(args.get('namespace', ''))}",
            {"items": args["items"]},
        )
    if name == "records_query":
        body: dict[str, Any] = {
            "topK": args.get("topK", 10),
            "includeText": args.get("includeText", True),
            "includeMeta": args.get("includeMeta", True),
        }
        for k in ("text", "kind", "tagsAny", "tagsAll", "tsGte", "tsLt", "userId"):
            if k in args:
                body[k] = args[k]
        return await _call(
            client, "POST",
            f"/v1/records/{_enc(args.get('namespace', ''))}/query", body,
        )
    if name == "records_timeline":
        params: list[str] = []
        for k in ("since", "until", "limit"):
            if args.get(k) is not None:
                params.append(f"{k}={int(args[k])}")
        for k in ("kind", "tagsAny", "tagsAll", "userId"):
            if args.get(k):
                params.append(f"{k}={_enc(str(args[k]))}")
        qs = ("?" + "&".join(params)) if params else ""
        return await _call(
            client, "GET",
            f"/v1/records/{_enc(args.get('namespace', ''))}/timeline{qs}",
        )
    if name == "records_get":
        return await _call(
            client, "GET",
            f"/v1/records/{_enc(args.get('namespace', ''))}/{_enc(args['id'])}",
        )
    if name == "records_delete":
        return await _call(
            client, "DELETE",
            f"/v1/records/{_enc(args.get('namespace', ''))}/{_enc(args['id'])}",
        )
    if name == "records_forget":
        body = {}
        for k in ("kind", "tagsAny", "tagsAll", "tsGte", "tsLt", "ids", "userId"):
            if args.get(k) is not None:
                body[k] = args[k]
        return await _call(
            client, "POST",
            f"/v1/records/{_enc(args.get('namespace', ''))}/forget", body,
        )
    if name == "records_compact":
        body = {
            "summaryKind": args.get("summaryKind", "summary"),
            "maxChars": args.get("maxChars", 4000),
        }
        for k in ("kind", "tagsAny", "tagsAll", "tsGte", "tsLt", "userId"):
            if args.get(k) is not None:
                body[k] = args[k]
        return await _call(
            client, "POST",
            f"/v1/records/{_enc(args.get('namespace', ''))}/compact", body,
        )
    if name == "records_stats":
        return await _call(
            client, "GET",
            f"/v1/records/{_enc(args.get('namespace', ''))}/stats",
        )
    if name == "records_export":
        import base64
        url = f"{BASE_URL}/v1/records/{_enc(args.get('namespace', ''))}/export"
        r = await client.get(url, headers={"Api-Key": API_KEY or ""})
        if r.status_code >= 400:
            raise RuntimeError(f"GET records export -> {r.status_code}: {r.text}")
        return {
            "neruva_base64": base64.b64encode(r.content).decode("ascii"),
            "bytes": len(r.content),
        }
    if name == "records_import":
        import base64
        blob = base64.b64decode(args["neruva_base64"])
        url = f"{BASE_URL}/v1/records/{_enc(args.get('namespace', ''))}/import"
        files = {"file": ("ns.neruva", blob, "application/x-neruva")}
        r = await client.post(
            url, headers={"Api-Key": API_KEY or ""}, files=files,
        )
        if r.status_code >= 400:
            raise RuntimeError(f"POST records import -> {r.status_code}: {r.text}")
        try:
            return r.json()
        except Exception:
            return r.text
    # ----- Memory index (legacy vector layer) -----
    if name == "memory_embed":
        return await _call(client, "POST", "/v1/memory/embed", {"texts": args["texts"]})
    if name == "memory_list_indexes":
        return await _call(client, "GET", "/v1/indexes")
    if name == "memory_describe_index":
        return await _call(client, "GET", f"/v1/indexes/{_enc(args['name'])}")
    if name == "memory_stats":
        return await _call(
            client, "GET", f"/v1/indexes/{_enc(args['name'])}/describe_index_stats",
        )
    if name == "memory_fetch":
        ids_qs = "&".join(f"ids={_enc(i)}" for i in args["ids"])
        ns_qs = f"&namespace={_enc(args['namespace'])}" if args.get("namespace") else ""
        return await _call(
            client, "GET",
            f"/v1/indexes/{_enc(args['index'])}/vectors/fetch?{ids_qs}{ns_qs}",
        )
    if name == "memory_update":
        body: dict[str, Any] = {"id": args["id"], "namespace": args.get("namespace", "")}
        if "values" in args:
            body["values"] = args["values"]
        # Server expects setMetadata; sending metadata is a silent no-op.
        if "metadata" in args:
            body["setMetadata"] = args["metadata"]
        return await _call(
            client, "POST", f"/v1/indexes/{_enc(args['index'])}/vectors/update", body,
        )
    if name == "memory_export":
        import base64
        ns_qs = f"?namespace={_enc(args['namespace'])}" if args.get("namespace") is not None else ""
        url = f"{BASE_URL}/v1/indexes/{_enc(args['index'])}/export{ns_qs}"
        r = await client.get(url, headers={"Api-Key": API_KEY or ""})
        if r.status_code >= 400:
            raise RuntimeError(f"GET export -> {r.status_code}: {r.text}")
        return {"nmm_base64": base64.b64encode(r.content).decode("ascii"), "bytes": len(r.content)}
    if name == "memory_import":
        import base64
        url = f"{BASE_URL}/v1/indexes/{_enc(args['index'])}/import"
        r = await client.post(
            url,
            headers={"Api-Key": API_KEY or "", "Content-Type": "application/octet-stream"},
            content=base64.b64decode(args["nmm_base64"]),
        )
        if r.status_code >= 400:
            raise RuntimeError(f"POST import -> {r.status_code}: {r.text}")
        try:
            return r.json()
        except Exception:
            return r.text
    if name == "memory_upsert_text":
        return await _call(
            client, "POST",
            f"/v1/indexes/{_enc(args['index'])}/text/upsert",
            {"items": args["items"], "namespace": args.get("namespace", "")},
        )
    if name == "memory_query_text":
        return await _call(
            client, "POST",
            f"/v1/indexes/{_enc(args['index'])}/text/query",
            {
                "text": args["text"],
                "namespace": args.get("namespace", ""),
                "topK": args.get("topK", 10),
                "includeMetadata": args.get("includeMetadata", True),
                "includeValues": args.get("includeValues", False),
                "filter": _fold_tags(args.get("filter"), args.get("tags")),
            },
        )
    if name == "memory_replace_text":
        return await _call(
            client, "POST",
            f"/v1/indexes/{_enc(args['index'])}/text/replace",
            {"id": args["id"], "newText": args["newText"], "namespace": args.get("namespace", "")},
        )
    if name == "memory_forget_where":
        return await _call(
            client, "POST",
            f"/v1/indexes/{_enc(args['index'])}/vectors/delete",
            {"filter": args["filter"], "namespace": args.get("namespace", "")},
        )
    if name == "memory_bind_role":
        return await _call(
            client, "POST",
            f"/v1/indexes/{_enc(args['index'])}/roles/bind",
            {"id": args["id"], "role": args["role"], "namespace": args.get("namespace", "")},
        )
    if name == "memory_read_roles":
        body: dict[str, Any] = {
            "id": args["id"],
            "queryVector": args["queryVector"],
            "roleDict": args["roleDict"],
            "namespace": args.get("namespace", ""),
        }
        if "known" in args:
            body["known"] = args["known"]
        return await _call(
            client, "POST",
            f"/v1/indexes/{_enc(args['index'])}/roles/read",
            body,
        )
    if name == "memory_create_index":
        return await _call(
            client,
            "POST",
            "/v1/indexes",
            {
                "name": args["name"],
                "dimension": args["dimension"],
                "metric": args.get("metric", "cosine"),
            },
        )
    if name == "memory_upsert":
        return await _call(
            client,
            "POST",
            f"/v1/indexes/{_enc(args['index'])}/vectors/upsert",
            {
                "vectors": args["vectors"],
                "namespace": args.get("namespace", ""),
            },
        )
    if name == "memory_query":
        return await _call(
            client,
            "POST",
            f"/v1/indexes/{_enc(args['index'])}/query",
            {
                "vector": args["vector"],
                "namespace": args.get("namespace", ""),
                "topK": args.get("topK", 10),
                "includeMetadata": args.get("includeMetadata", True),
                "includeValues": args.get("includeValues", False),
                "filter": _fold_tags(args.get("filter"), args.get("tags")),
            },
        )
    if name == "memory_delete":
        return await _call(
            client,
            "POST",
            f"/v1/indexes/{_enc(args['index'])}/vectors/delete",
            {
                "ids": args["ids"],
                "namespace": args.get("namespace", ""),
            },
        )
    if name == "hd_kg_add_fact":
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/facts",
            {
                "facts": [
                    {
                        "subject": args["subject"],
                        "relation": args["relation"],
                        "object": args["object"],
                    }
                ]
            },
        )
    if name == "hd_kg_query":
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/query",
            {"subject": args["subject"], "relation": args["relation"]},
        )
    if name == "hd_kg_delete_fact":
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/facts/delete",
            {
                "facts": [
                    {
                        "subject": args["subject"],
                        "relation": args["relation"],
                        "object": args["object"],
                    }
                ]
            },
        )
    if name == "hd_kg_export":
        import base64
        url = f"{BASE_URL}/v1/hd/kg/{_enc(args['kg'])}/export"
        r = await client.get(url, headers={"Api-Key": API_KEY or ""})
        if r.status_code >= 400:
            raise RuntimeError(f"GET kg export -> {r.status_code}: {r.text}")
        return {"hdkg_base64": base64.b64encode(r.content).decode("ascii"), "bytes": len(r.content)}
    if name == "hd_kg_import":
        import base64
        url = f"{BASE_URL}/v1/hd/kg/{_enc(args['kg'])}/import"
        r = await client.post(
            url,
            headers={"Api-Key": API_KEY or "", "Content-Type": "application/octet-stream"},
            content=base64.b64decode(args["hdkg_base64"]),
        )
        if r.status_code >= 400:
            raise RuntimeError(f"POST kg import -> {r.status_code}: {r.text}")
        try: return r.json()
        except Exception: return r.text
    if name == "hd_causal_export":
        import base64
        url = f"{BASE_URL}/v1/hd/causal/{_enc(args['scm'])}/export"
        r = await client.get(url, headers={"Api-Key": API_KEY or ""})
        if r.status_code >= 400:
            raise RuntimeError(f"GET scm export -> {r.status_code}: {r.text}")
        return {"hdscm_base64": base64.b64encode(r.content).decode("ascii"), "bytes": len(r.content)}
    if name == "hd_causal_import":
        import base64
        url = f"{BASE_URL}/v1/hd/causal/{_enc(args['scm'])}/import"
        r = await client.post(
            url,
            headers={"Api-Key": API_KEY or "", "Content-Type": "application/octet-stream"},
            content=base64.b64decode(args["hdscm_base64"]),
        )
        if r.status_code >= 400:
            raise RuntimeError(f"POST scm import -> {r.status_code}: {r.text}")
        try: return r.json()
        except Exception: return r.text
    if name == "hd_analogy":
        return await _call(
            client,
            "POST",
            "/v1/hd/analogy",
            {
                "n_feat": args["n_feat"],
                "a": args["a"],
                "b": args["b"],
                "c": args["c"],
                "seed": args.get("seed", 4301),
            },
        )
    if name == "hd_causal_add_worlds":
        return await _call(
            client,
            "POST",
            f"/v1/hd/causal/{_enc(args['scm'])}/worlds",
            {
                "n_vars": args["n_vars"],
                "vocab_per_var": args["vocab_per_var"],
                "worlds": args["worlds"],
                "seed": args.get("seed", 4401),
            },
        )
    if name == "hd_causal_query":
        return await _call(
            client,
            "POST",
            f"/v1/hd/causal/{_enc(args['scm'])}/query",
            {
                "query_type": args["query_type"],
                "condition_var": args["condition_var"],
                "condition_value": args["condition_value"],
                "query_var": args["query_var"],
                "query_value": args["query_value"],
            },
        )

    # ----- Self-introspection -----
    if name == "neruva_wallet_status":
        return await _call(client, "GET", "/v1/me/wallet")
    if name == "neruva_op_stats":
        window = args.get("window", "30d")
        return await _call(client, "GET", f"/v1/me/usage?window={_enc(window)}")
    if name == "neruva_keys_list":
        return await _call(client, "GET", "/v1/me/keys")
    if name == "neruva_op_log":
        limit = int(args.get("limit", 50))
        return await _call(client, "GET", f"/v1/me/op_log?limit={limit}")

    raise ValueError(f"unknown tool: {name}")


async def _run() -> None:
    if not API_KEY:
        print(
            "[neruva-mcp] NERUVA_API_KEY not set. Get one at https://app.neruva.io",
            file=sys.stderr,
        )
        sys.exit(1)

    if AR_INDEX:
        ttl_note = f" (TTL {AR_TTL_DAYS}d)" if AR_TTL_DAYS else ""
        print(
            f"[neruva-mcp] auto-record ON: tool calls -> "
            f"{AR_INDEX}/{AR_NAMESPACE or '(default)'}{ttl_note}",
            file=sys.stderr,
        )

    server: Server = Server("neruva")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return TOOLS

    async with httpx.AsyncClient(timeout=60.0) as client:

        @server.call_tool()
        async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
            t0 = time.perf_counter()
            try:
                result = await _dispatch(client, name, arguments or {})
                # Fire-and-forget recording (never blocks return, never throws).
                asyncio.create_task(
                    _maybe_record(
                        client, name, arguments or {}, result,
                        int((time.perf_counter() - t0) * 1000),
                    )
                )
                return [TextContent(type="text", text=json.dumps(result, indent=2))]
            except Exception as e:
                return [TextContent(type="text", text=f"error: {e}")]

        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
