"""Verify BS greeks with sqrtT != 1"""

import sys
sys.path.insert(0, r'c:\Users\hans\OneDrive\Python3\packages\cdxcore')

from cdxcore.bs import bs
import numpy as np
from scipy.special import ndtr
import math

# Test with different sqrtT
k = 1.0
vol = 0.2
sqrtT = 0.5  # Different from 1!
is_call = True

print("Testing BS greeks with sqrtT = 0.5")
print("="*60)

# Get vega
vega = bs.vega(k, vol, sqrtT, is_call)
price = bs.price(k, vol, sqrtT, is_call)

print(f"Vega (analytical): {vega:.8f}")

# FD vega: dC/dvol
h_vol = 1e-6
price_vol_up = bs.price(k, vol + h_vol, sqrtT, is_call)
price_vol_dn = bs.price(k, vol - h_vol, sqrtT, is_call)
vega_fd = (price_vol_up - price_vol_dn) / (2 * h_vol)

print(f"Vega (FD dC/dvol): {vega_fd:.8f}")
print(f"Difference:        {abs(vega - vega_fd):.2e}")
print()

# Compute φ(d1)
vf = vol * sqrtT
logK = math.log(k)
d1 = -logK / vf + 0.5 * vf
_inv_sqrt_2pi = 1.0 / np.sqrt(2.0 * np.pi)
pd1 = _inv_sqrt_2pi * math.exp(-0.5 * d1**2)

print("Vega formula check:")
print(f"  φ(d1) = {pd1:.8f}")
print(f"  sqrt(T) * φ(d1) = {sqrtT * pd1:.8f} (standard vega)")
print(f"  φ(d1) / sqrt(T) = {pd1 / sqrtT:.8f} (if code used this)")
print(f"  Code's vega:    = {vega:.8f}")
print()

# Check ratio
print(f"Code's vega / (sqrt(T) * φ(d1)): {vega / (sqrtT * pd1):.8f}")
print(f"Code's vega / (φ(d1) / sqrt(T)): {vega / (pd1 / sqrtT):.8f}")
print()

# Now test theta
theta = bs.theta(k, vol, sqrtT, is_call)

# dC/dT finite difference
h_T = 1e-6
T = sqrtT**2
price_T_up = bs.price(k, vol, np.sqrt(T + h_T), is_call)
price_T_dn = bs.price(k, vol, np.sqrt(T - h_T), is_call)
theta_fd = (price_T_up - price_T_dn) / (2 * h_T)

print("Theta analysis:")
print(f"  Theta (analytical): {theta:.8f}")
print(f"  Theta (FD dC/dT):   {theta_fd:.8f}")
print(f"  Difference:         {abs(theta - theta_fd):.2e}")
print()

# Standard theta formula
standard_theta_formula = -0.5 * vol * pd1 / sqrtT
print(f"  -0.5*vol*φ(d1)/sqrt(T): {standard_theta_formula:.8f}")
print(f"  +0.5*vol*φ(d1)/sqrt(T): {-standard_theta_formula:.8f}")
print(f"  Code's theta:           {theta:.8f}")
print()

print("="*60)
print("CONCLUSION:")
print("-"*60)
print("With sqrtT = 0.5:")
print(f"  Standard vega = sqrt(T)*φ(d1) = {sqrtT * pd1:.8f}")
print(f"  Code vega = dC/dvol = {vega:.8f}")
print(f"  → These match! Code correctly implements dC/dvol")
print()
print("  Theta from FD (dC/dT) = {:.8f} (POSITIVE)".format(theta_fd))
print("  In drift-less BS, theta > 0 because value increases with time")
print("  (more time = more volatility = higher option value)")
print("="*60)
