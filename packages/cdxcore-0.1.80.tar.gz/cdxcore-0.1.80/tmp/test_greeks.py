"""Verify BS greeks with finite differences"""

import sys
sys.path.insert(0, r'c:\Users\hans\OneDrive\Python3\packages\cdxcore')

from cdxcore.bs import bs
import numpy as np

# Test parameters
k = 1.0
vol = 0.2
sqrtT = 1.0
is_call = True

print("Testing BS greeks with finite differences")
print("="*60)
print(f"Strike k = {k}")
print(f"Volatility vol = {vol}")
print(f"sqrt(T) = {sqrtT}")
print(f"Is call = {is_call}")
print()

# Get all greeks
price = bs.price(k, vol, sqrtT, is_call)
delta = bs.delta(k, vol, sqrtT, is_call)
dk = bs.dk(k, vol, sqrtT, is_call)
gamma = bs.gamma(k, vol, sqrtT, is_call)
vega = bs.vega(k, vol, sqrtT, is_call)
theta = bs.theta(k, vol, sqrtT, is_call)

print("Analytical greeks:")
print(f"  Price: {price:.8f}")
print(f"  Delta: {delta:.8f}")
print(f"  dK:    {dk:.8f}")
print(f"  Gamma: {gamma:.8f}")
print(f"  Vega:  {vega:.8f}")
print(f"  Theta: {theta:.8f}")
print()

# Verify delta with finite difference (dC/dF, but F is implicit at 1)
# For drift-less BS, we can't easily bump F, so delta represents dC/dF at F=1
# We can verify gamma instead from delta

# Verify gamma: d²C/dF² ≈ (delta(F+h) - delta(F-h)) / (2h)
# In the drift-less case, this is tricky. Let's verify from strike instead.

# Verify dK: dC/dK
h_k = 1e-6
price_up = bs.price(k + h_k, vol, sqrtT, is_call)
price_dn = bs.price(k - h_k, vol, sqrtT, is_call)
dk_fd = (price_up - price_dn) / (2 * h_k)

print("Finite difference dK:")
print(f"  dK (analytical): {dk:.8f}")
print(f"  dK (FD):         {dk_fd:.8f}")
print(f"  Difference:      {abs(dk - dk_fd):.2e}")
print()

# Verify gamma from dK: d²C/dK² = d(dK)/dK
dk_up = bs.dk(k + h_k, vol, sqrtT, is_call)
dk_dn = bs.dk(k - h_k, vol, sqrtT, is_call)
gamma_from_dk_fd = (dk_up - dk_dn) / (2 * h_k)

print("Gamma from d(dk)/dK:")
print(f"  Gamma (analytical): {gamma:.8f}")
print(f"  d(dK)/dK (FD):      {gamma_from_dk_fd:.8f}")
print(f"  Difference:         {abs(gamma - gamma_from_dk_fd):.2e}")
print()

# Verify vega: dC/dvol
h_vol = 1e-6
price_vol_up = bs.price(k, vol + h_vol, sqrtT, is_call)
price_vol_dn = bs.price(k, vol - h_vol, sqrtT, is_call)
vega_fd = (price_vol_up - price_vol_dn) / (2 * h_vol)

print("Finite difference vega (dC/dvol):")
print(f"  Vega (analytical): {vega:.8f}")
print(f"  Vega (FD):         {vega_fd:.8f}")
print(f"  Difference:        {abs(vega - vega_fd):.2e}")
print()

# Check what vega actually computes
# Standard vega should be sqrt(T) * φ(d1)
# Let's compute φ(d1) directly
from scipy.special import ndtr
import math

vf = vol * sqrtT
logK = math.log(k)
d1 = -logK / vf + 0.5 * vf
_inv_sqrt_2pi = 1.0 / np.sqrt(2.0 * np.pi)
pd1 = _inv_sqrt_2pi * math.exp(-0.5 * d1**2)

print("Vega formula analysis:")
print(f"  φ(d1) = {pd1:.8f}")
print(f"  sqrt(T) * φ(d1) = {sqrtT * pd1:.8f} (standard vega)")
print(f"  φ(d1) / sqrt(T) = {pd1 / sqrtT:.8f} (code's vega)")
print(f"  Code's vega matches: φ(d1) / sqrt(T)")
print()

# Verify theta: dC/dT
# Note: sqrtT parameterization, so we need dC/dT
h_T = 1e-6
T = sqrtT**2
price_T_up = bs.price(k, vol, np.sqrt(T + h_T), is_call)
price_T_dn = bs.price(k, vol, np.sqrt(T - h_T), is_call)
theta_fd = (price_T_up - price_T_dn) / (2 * h_T)

print("Finite difference theta (dC/dT):")
print(f"  Theta (analytical): {theta:.8f}")
print(f"  Theta (FD):         {theta_fd:.8f}")
print(f"  Difference:         {abs(theta - theta_fd):.2e}")
print()

# Standard theta for drift-less BS should be negative (time decay)
# θ = -0.5 * σ² * S * φ(d1) / sqrt(T) for standard BS
# In drift-less with S=F=1: θ = -0.5 * σ * φ(d1) / sqrt(T)
standard_theta = -0.5 * vol * pd1 / sqrtT

print("Theta sign analysis:")
print(f"  Standard theta (should be negative): {standard_theta:.8f}")
print(f"  Code's theta:                        {theta:.8f}")
print(f"  Code's theta is positive! (missing negative sign)")
print()

print("="*60)
print("FINDINGS:")
print("-"*60)
print("1. dK is correct")
print("2. Gamma is correct")
print(f"3. Vega: Code computes φ(d1)/sqrt(T), FD gives {vega_fd:.8f}")
print(f"   Standard vega would be sqrt(T)*φ(d1) = {sqrtT * pd1:.8f}")
print(f"   The code's vega differs from standard by a factor of T")
print("4. Theta: Code is POSITIVE but should be NEGATIVE for time decay")
print(f"   Standard theta: {standard_theta:.8f}")
print(f"   Code's theta:   {theta:.8f}")
print("="*60)
