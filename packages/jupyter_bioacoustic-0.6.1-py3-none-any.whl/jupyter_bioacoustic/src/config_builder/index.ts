export { configBuilderPlugin } from './plugin';
