wit_bindgen::generate!({
    world: "gateway",
    path: "wit",
    with: {
        "wasi:http/types@0.2.2": ::wasi::http::types,
        "wasi:http/outgoing-handler@0.2.2": ::wasi::http::outgoing_handler,
        "wasi:io/poll@0.2.2": ::wasi::io::poll,
        "wasi:io/streams@0.2.2": ::wasi::io::streams,
        "wasi:io/error@0.2.2": ::wasi::io::error,
        "wasi:clocks/monotonic-clock@0.2.2": ::wasi::clocks::monotonic_clock,
        "wasmcloud:messaging/types@0.2.0": generate,
        "wasmcloud:messaging/consumer@0.2.0": generate,
        "wasi:http/incoming-handler@0.2.2": generate,
    }
});

use serde::{Deserialize, Serialize};
use serde_json::Value;

// Resolve ambiguity by referring to the external wasi crate explicitly
use ::wasi::http::types::{
    IncomingRequest, ResponseOutparam, OutgoingResponse, Fields, OutgoingBody,
    OutgoingRequest, Method, Scheme
};
use ::wasi::http::outgoing_handler::handle as outgoing_handle;
use crate::wasmcloud::messaging::consumer::request as nats_request;

// JSON-RPC 2.0 structures
#[derive(Serialize, Deserialize, Debug)]
struct JsonRpcRequest {
    jsonrpc: String,
    method: String,
    params: Params,
    id: Value,
}

#[derive(Serialize, Deserialize, Debug)]
struct Params {
    name: String,
    arguments: Value,
}

#[derive(Serialize, Debug)]
struct JsonRpcErrorResponse {
    jsonrpc: String,
    error: JsonRpcError,
    id: Value,
}

#[derive(Serialize, Debug)]
struct JsonRpcError {
    code: i32,
    message: String,
}

struct Gateway;

fn call_discovery_search(runtime_url: &str, query: &str) -> Result<String, String> {
    // Parse scheme and authority
    let scheme = if runtime_url.starts_with("https://") { Scheme::Https } else { Scheme::Http };
    let authority = runtime_url
        .trim_start_matches("http://")
        .trim_start_matches("https://");

    let headers = Fields::new();
    let _ = headers.set(&"content-type".to_string(), &[b"application/json".to_vec()]);

    let request = OutgoingRequest::new(headers);
    let _ = request.set_method(&Method::Post);
    let _ = request.set_path_with_query(Some("/api/v1/discovery/search"));
    let _ = request.set_scheme(Some(&scheme));
    let _ = request.set_authority(Some(authority));

    let body = request.body().map_err(|e| format!("{:?}", e))?;
    let write_stream = body.write().map_err(|e| format!("{:?}", e))?;

    let payload = serde_json::json!({
        "query": query,
        "limit": 1,
        "tenant_cid": "889955217295c2bfef2d6812071b633b0819477e67f57853febf116f69f30531"
    });
    let payload_bytes = serde_json::to_vec(&payload).unwrap();

    let _ = write_stream.blocking_write_and_flush(&payload_bytes);
    drop(write_stream);

    let _ = OutgoingBody::finish(body, None);

    // Call the handler
    let response = outgoing_handle(request, None).map_err(|e| format!("{:?}", e))?;
    let incoming_res = match response.get() {
        Some(Ok(Ok(res))) => res,
        Some(Ok(Err(err))) => return Err(format!("ErrorCode: {:?}", err)),
        Some(Err(err)) => return Err(format!("Future failed: {:?}", err)),
        None => return Err("No response available".to_string()),
    };

    if incoming_res.status() != 200 {
        return Err(format!("Server returned status code {}", incoming_res.status()));
    }

    let response_body = incoming_res.consume().map_err(|e| format!("{:?}", e))?;
    let read_stream = response_body.stream().map_err(|e| format!("{:?}", e))?;

    let mut body_bytes = Vec::new();
    loop {
        match read_stream.read(65536) {
            Ok(chunk) => {
                if chunk.is_empty() {
                    break;
                }
                body_bytes.extend(chunk);
            }
            Err(_) => break,
        }
    }

    let res_str = String::from_utf8(body_bytes).map_err(|e| format!("{}", e))?;
    let results: Value = serde_json::from_str(&res_str).map_err(|e| format!("{}", e))?;

    if let Some(arr) = results.as_array() {
        if let Some(first) = arr.first() {
            if let Some(name) = first["name"].as_str() {
                return Ok(name.to_string());
            }
        }
    }

    Err("No matching URN found".to_string())
}

impl exports::wasi::http::incoming_handler::Guest for Gateway {
    fn handle(request: IncomingRequest, response_out: ResponseOutparam) {
        // 1. Consume the request body
        let req_body = match request.consume() {
            Ok(body) => body,
            Err(_) => {
                send_error_response(response_out, Value::Null, -32700, "Failed to read request body stream".to_string());
                return;
            }
        };

        let in_stream = match req_body.stream() {
            Ok(stream) => stream,
            Err(_) => {
                send_error_response(response_out, Value::Null, -32700, "Failed to open request body input stream".to_string());
                return;
            }
        };

        let mut body_bytes = Vec::new();
        loop {
            match in_stream.read(65536) {
                Ok(chunk) => {
                    if chunk.is_empty() {
                        break;
                    }
                    body_bytes.extend(chunk);
                }
                Err(_) => break,
            }
        }

        // Clean up input stream resources
        drop(in_stream);
        drop(req_body);

        // 2. Parse JSON-RPC request
        let req_str = match String::from_utf8(body_bytes.clone()) {
            Ok(s) => s,
            Err(e) => {
                send_error_response(response_out, Value::Null, -32700, format!("Invalid UTF-8: {}", e));
                return;
            }
        };

        let mut rpc_request: JsonRpcRequest = match serde_json::from_str(&req_str) {
            Ok(req) => req,
            Err(e) => {
                send_error_response(response_out, Value::Null, -32600, format!("Invalid JSON-RPC payload: {}", e));
                return;
            }
        };

        // Validate method
        if rpc_request.method != "tools/call" {
            send_error_response(response_out, rpc_request.id, -32601, format!("Unsupported method: {}", rpc_request.method));
            return;
        }

        // 3. Semantic Intent Routing
        let mut tool_urn = rpc_request.params.name.clone();
        if !tool_urn.starts_with("urn:") {
            let runtime_url = std::env::var("COREASON_RUNTIME_URL").unwrap_or_else(|_| "http://localhost:8000".to_string());
            match call_discovery_search(&runtime_url, &tool_urn) {
                Ok(resolved_urn) => {
                    tool_urn = resolved_urn;
                }
                Err(e) => {
                    send_error_response(
                        response_out,
                        rpc_request.id,
                        -32602,
                        format!("Failed to dynamically resolve intent '{}': {}", tool_urn, e)
                    );
                    return;
                }
            }
        }

        // Update the name to the resolved URN
        rpc_request.params.name = tool_urn.clone();

        // Re-serialize the JSON-RPC request body to pass over NATS
        let updated_body_bytes = match serde_json::to_vec(&rpc_request) {
            Ok(b) => b,
            Err(e) => {
                send_error_response(response_out, rpc_request.id, -32603, format!("Serialization failure: {}", e));
                return;
            }
        };

        // Derive NATS subject from tool URN
        let subject = get_nats_subject(&tool_urn);

        // 4. Dispatch NATS request-reply call to the lattice
        let nats_res = match nats_request(&subject, &updated_body_bytes, 30000) {
            Ok(msg) => msg,
            Err(e) => {
                send_error_response(
                    response_out,
                    rpc_request.id,
                    -32603,
                    format!("Lattice dispatch failed for subject '{}': {}", subject, e)
                );
                return;
            }
        };

        // 5. Return the NATS reply body directly as the HTTP response
        send_success_response(response_out, &nats_res.body);
    }
}

fn get_nats_subject(urn: &str) -> String {
    let cleaned_urn = urn.replace(":", ".");
    format!("coreason.tool.{}.invoke", cleaned_urn)
}

fn send_success_response(response_out: ResponseOutparam, body: &[u8]) {
    let headers = Fields::new();
    let _ = headers.set(&"content-type".to_string(), &[b"application/json".to_vec()]);

    let response = OutgoingResponse::new(headers);
    response.set_status_code(200).unwrap();

    let response_body = response.body().unwrap();
    let out_stream = response_body.write().unwrap();
    let _ = out_stream.blocking_write_and_flush(body);
    drop(out_stream);

    let _ = OutgoingBody::finish(response_body, None);
    ResponseOutparam::set(response_out, Ok(response));
}

fn send_error_response(response_out: ResponseOutparam, id: Value, code: i32, message: String) {
    let err_res = JsonRpcErrorResponse {
        jsonrpc: "2.0".to_string(),
        error: JsonRpcError { code, message },
        id,
    };

    let body = serde_json::to_vec(&err_res).unwrap_or_default();

    let headers = Fields::new();
    let _ = headers.set(&"content-type".to_string(), &[b"application/json".to_vec()]);

    let response = OutgoingResponse::new(headers);
    response.set_status_code(200).unwrap();

    let response_body = response.body().unwrap();
    let out_stream = response_body.write().unwrap();
    let _ = out_stream.blocking_write_and_flush(&body);
    drop(out_stream);

    let _ = OutgoingBody::finish(response_body, None);
    ResponseOutparam::set(response_out, Ok(response));
}

export!(Gateway);
