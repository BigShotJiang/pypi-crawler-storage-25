use jsonwebtoken::{decode, DecodingKey, Validation, Algorithm};
use serde::{Deserialize, Serialize};
use serde_json::Value;

#[derive(Debug, Deserialize, Serialize, Clone)]
pub struct Claims {
    pub sub: String,
    pub iat: Option<u64>,
    pub exp: Option<u64>,
    pub tenant_cid: Option<String>,
    pub entitlements: Option<Vec<String>>,
}

/// Helper function to decode hex string to bytes
fn decode_hex(s: &str) -> Result<Vec<u8>, String> {
    (0..s.len())
        .step_by(2)
        .map(|i| {
            u8::from_str_radix(&s[i..i + 2], 16)
                .map_err(|e| format!("Failed to parse hex: {}", e))
        })
        .collect()
}

/// Verifies the Ed25519 signature of the JWT using the Root CA or Dev key.
pub fn verify_token_signature(jwt_string: &str, root_ca_key: &str) -> Result<Value, String> {
    let root_ca_key = root_ca_key.trim();
    if root_ca_key.is_empty() {
        return Err("Public key is empty".to_string());
    }

    let decoding_key = if root_ca_key.contains("-----BEGIN PUBLIC KEY-----") {
        DecodingKey::from_ed_pem(root_ca_key.as_bytes())
            .map_err(|e| format!("Invalid PEM public key: {}", e))?
    } else if root_ca_key.len() == 64 && root_ca_key.chars().all(|c| c.is_ascii_hexdigit()) {
        let raw_bytes = decode_hex(root_ca_key)?;
        if raw_bytes.len() != 32 {
            return Err("Hex public key must be exactly 32 bytes (64 hex characters)".to_string());
        }
        // ASN.1 DER prefix for Ed25519 public keys
        let mut der_key = vec![
            0x30, 0x2a, 0x30, 0x05, 0x06, 0x03, 0x2b, 0x65, 0x70, 0x03, 0x21, 0x00,
        ];
        der_key.extend_from_slice(&raw_bytes);
        DecodingKey::from_ed_der(&der_key)
    } else {
        // Fallback: try PEM, then try hex
        if let Ok(key) = DecodingKey::from_ed_pem(root_ca_key.as_bytes()) {
            key
        } else if let Ok(raw_bytes) = decode_hex(root_ca_key) {
            if raw_bytes.len() == 32 {
                let mut der_key = vec![
                    0x30, 0x2a, 0x30, 0x05, 0x06, 0x03, 0x2b, 0x65, 0x70, 0x03, 0x21, 0x00,
                ];
                der_key.extend_from_slice(&raw_bytes);
                DecodingKey::from_ed_der(&der_key)
            } else {
                return Err("Failed to parse public key as PEM or hex".to_string());
            }
        } else {
            return Err("Failed to parse public key as PEM or hex".to_string());
        }
    };

    let mut validation = Validation::new(Algorithm::EdDSA);
    // PyJWT does not validate aud/iss by default unless requested, but we validate exp and iat
    validation.validate_aud = false;
    validation.required_spec_claims.remove("exp"); // exp validation is optional but done if present

    let token_data = decode::<Value>(jwt_string, &decoding_key, &validation)
        .map_err(|e| format!("Malformed or invalid token: {}", e))?;

    Ok(token_data.claims)
}

/// Installs the JWT license into HashiCorp Vault securely.
pub async fn install_license(
    jwt_string: &str,
    vault_url: &str,
    vault_token: &str,
    root_ca_key: &str,
    env: &str,
) -> Result<(), String> {
    // 1. Verify token signature
    let payload = verify_token_signature(jwt_string, root_ca_key)?;

    // 2. Production guards
    if env == "production" {
        if vault_url.is_empty()
            || vault_token.is_empty()
            || vault_url.contains("127.0.0.1")
            || vault_url.contains("localhost")
        {
            return Err("Production deployment requires valid Vault credentials and non-local Vault address.".to_string());
        }
    }

    let tenant_id = payload
        .get("tenant_cid")
        .and_then(|v| v.as_str())
        .or_else(|| payload.get("sub").and_then(|v| v.as_str()))
        .unwrap_or("global");

    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(5))
        .build()
        .map_err(|e| format!("Failed to create reqwest client: {}", e))?;

    // 3. Check for replay attack / supersession
    let secret_path = format!("coreason/license/{}", tenant_id);
    let secret_url = format!("{}/v1/secret/data/{}", vault_url, secret_path);

    let existing_response = client
        .get(&secret_url)
        .header("X-Vault-Token", vault_token)
        .send()
        .await;

    if let Ok(res) = existing_response {
        if res.status().is_success() {
            if let Ok(json) = res.json::<Value>().await {
                let envelope = &json["data"]["data"];
                if !envelope.is_null() {
                    let claims = if envelope["claims"].is_null() {
                        envelope.clone()
                    } else {
                        envelope["claims"].clone()
                    };

                    let existing_iat = claims
                        .get("iat")
                        .and_then(|v| v.as_u64())
                        .or_else(|| claims.get("issued_at_epoch").and_then(|v| v.as_u64()))
                        .unwrap_or(0);

                    let incoming_iat = payload
                        .get("iat")
                        .and_then(|v| v.as_u64())
                        .or_else(|| payload.get("issued_at_epoch").and_then(|v| v.as_u64()))
                        .unwrap_or(0);

                    if existing_iat > incoming_iat {
                        return Err("Cannot install an older token over a newer token.".to_string());
                    }
                }
            }
        }
    }

    // 4. Write token and claims to Vault KV V2
    let payload_to_write = serde_json::json!({
        "data": {
            "token": jwt_string,
            "claims": payload
        }
    });

    let write_res = client
        .post(&secret_url)
        .header("X-Vault-Token", vault_token)
        .json(&payload_to_write)
        .send()
        .await
        .map_err(|e| format!("Failed to connect to Vault: {}", e))?;

    if !write_res.status().is_success() {
        let status = write_res.status();
        let body = write_res.text().await.unwrap_or_default();
        return Err(format!(
            "Failed to securely store license in Vault (status {}): {}",
            status, body
        ));
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use jsonwebtoken::{encode, EncodingKey, Header};

    const TEST_PRIVATE_KEY: &str = "-----BEGIN PRIVATE KEY-----\nMC4CAQAwBQYDK2VwBCIEIAjSmMZLrnPoiMd6JV6uzi0msligZS3priHYd8T+lWmn\n-----END PRIVATE KEY-----";
    const TEST_PUBLIC_KEY: &str = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAflAiCjaAj6Y1Zzd4W1lV5KPT9u7GKxvFkFcpFaXLJRo=\n-----END PUBLIC KEY-----";

    #[test]
    fn test_signature_verification_success() {
        let claims = serde_json::json!({
            "sub": "tenant_123",
            "iat": 1716246000,
            "exp": 3716249600u64, // Year 2087
            "tenant_cid": "tenant_123",
            "entitlements": ["COMMERCIAL_USE"]
        });

        let header = Header::new(Algorithm::EdDSA);
        let encoding_key = EncodingKey::from_ed_pem(TEST_PRIVATE_KEY.as_bytes()).unwrap();
        let token = encode(&header, &claims, &encoding_key).unwrap();

        let decoded = verify_token_signature(&token, TEST_PUBLIC_KEY).unwrap();
        assert_eq!(decoded["sub"], "tenant_123");
        assert_eq!(decoded["tenant_cid"], "tenant_123");
    }

    #[test]
    fn test_signature_verification_failure_with_wrong_key() {
        let claims = serde_json::json!({
            "sub": "tenant_123",
            "iat": 1716246000,
            "exp": 1716249600
        });

        let header = Header::new(Algorithm::EdDSA);
        let encoding_key = EncodingKey::from_ed_pem(TEST_PRIVATE_KEY.as_bytes()).unwrap();
        let token = encode(&header, &claims, &encoding_key).unwrap();

        // Use a different valid public key
        let other_public_key = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAG3WqXf8tG7T+r1XgL1WkM5X9D0qM1rUj9B0qP1f8tG8=\n-----END PUBLIC KEY-----";

        let result = verify_token_signature(&token, other_public_key);
        assert!(result.is_err());
    }
}
