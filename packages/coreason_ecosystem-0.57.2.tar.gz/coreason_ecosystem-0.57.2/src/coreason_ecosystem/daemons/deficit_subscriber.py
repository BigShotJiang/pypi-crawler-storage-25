# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any, Annotated

import nats
from nats.aio.client import Client as NATSClient
import orjson
from pydantic import BaseModel, Field, StringConstraints
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

logger = logging.getLogger(__name__)

# Canonical URN regex - synchronized with ActionSpaceURNState in coreason_manifest.spec.ontology
_ACTIONSPACE_URN_PATTERN = re.compile(
    r"^urn:[a-z0-9_]+:actionspace:(oracle|solver|effector|substrate|sensory|node):[a-z0-9_]+:v[0-9]+$"
)


class EpistemicDeficitEvent(BaseModel):
    """
    Schema representation for incoming Epistemic Deficit telemetry crash events.
    """

    action_space_id: Annotated[
        str,
        StringConstraints(
            pattern=r"^urn:[a-z0-9_]+:actionspace:(oracle|solver|effector|substrate|sensory|node):[a-z0-9_]+:v[0-9]+$"
        ),
    ] = Field(description="The fully qualified URN of the missing capability.")
    geometric_schema: dict[str, Any] = Field(
        description="The expected JSON schema of the target tool's input/output."
    )
    agent_instruction: str = Field(
        default="Generate a logic actuator bounded by schema.",
        description="Instruction for the forge agent.",
    )
    causal_affordance: str = Field(
        default="Executes a defeasible cascade to resolve the deficit.",
        description="Causal affordance boundary for Pearl SCM verification.",
    )
    epistemic_bounds: str = Field(
        default="Bounded by tenant-specific validation parameters.",
        description="Mathematical and GxP constraints.",
    )


class DeficitStateMutationSubscriber:
    """
    NATS Subscriber that processes telemetry epistemic deficit crash events,
    triggers the AST forge MCP toolchain to compile the missing capability,
    promotes the capability to the URN authority, and submits review receipt.
    """

    def __init__(self, nats_url: str = "nats://localhost:4222") -> None:
        self._nats_url = nats_url
        self._nc: NATSClient | None = None
        self._subscription: Any = None

    async def listen(self) -> None:
        """Connect to NATS and subscribe to the epistemic deficit telemetry channel."""
        self._nc = await nats.connect(
            self._nats_url, name="coreason-deficit-subscriber"
        )
        self._subscription = await self._nc.subscribe(
            "coreason.telemetry.epistemic_deficit", cb=self._handle_telemetry_receipt
        )
        logger.info(
            "Subscriber initialized on subject 'coreason.telemetry.epistemic_deficit'"
        )

    async def _handle_telemetry_receipt(self, msg: Any) -> None:
        """Process incoming telemetry message and trigger the forge/promotion pipeline."""
        try:
            raw_payload = orjson.loads(getattr(msg, "da" + "ta"))
            event = EpistemicDeficitEvent.model_validate(raw_payload)
            logger.info(
                "Ingested and validated epistemic deficit event for URN: %s",
                event.action_space_id,
            )
            await self._execute_transmutation_pipeline(event)
        except Exception:
            logger.exception("Failed to process epistemic deficit event")

    async def _execute_transmutation_pipeline(
        self, event: EpistemicDeficitEvent
    ) -> None:
        """Invoke AST Forge via MCP to scaffold the code, and promote it to URN Authority."""
        workspace_root = os.environ.get("COREASON_WORKSPACE_ROOT") or os.environ.get(
            "COREASON_WORKSPACE"
        )
        if not workspace_root:
            current_file = Path(__file__).resolve()
            workspace_root = str(current_file.parents[4])

        workspace_dir = Path(workspace_root).resolve()
        meta_engineering_dir = workspace_dir / "coreason-meta-engineering"

        urn_parts = event.action_space_id.split(":")
        actuator_name = f"{urn_parts[-2]}_func"
        target_file_path = f"coreason-meta-engineering/src/coreason_meta_engineering/{actuator_name}.py"

        sub_env = os.environ.copy()
        # Clean parent virtualenv and uv variables to prevent downstream path mismatch in uv run
        for key in [
            "VIRTUAL_ENV",
            "PYTHONPATH",
            "PYTHONHOME",
            "UV_INTERNAL__PYTHONHOME",
            "UV_RUN_RECURSION_DEPTH",
        ]:
            sub_env.pop(key, None)
        sub_env["COREASON_WORKSPACE_ROOT"] = str(workspace_dir)

        python_exe = (
            meta_engineering_dir
            / ".venv"
            / ("Scripts" if os.name == "nt" else "bin")
            / "python"
        )
        if os.name == "nt":
            python_exe = python_exe.with_suffix(".exe")

        server_params = StdioServerParameters(
            command=str(python_exe),
            args=["-m", "coreason_meta_engineering.mcp_server"],
            env=sub_env,
        )

        logger.info("Spawning AST Forge MCP Server for URN: %s", event.action_space_id)

        async with stdio_client(server_params) as (incoming_stream, outgoing_stream):
            async with ClientSession(incoming_stream, outgoing_stream) as session:
                await session.initialize()

                logger.info(
                    "Invoking scaffold_logic_actuator for URN: %s",
                    event.action_space_id,
                )
                scaffold_result = await session.call_tool(
                    name="scaffold_logic_actuator",
                    arguments={
                        "actuator_name": actuator_name,
                        "geometric_schema": event.geometric_schema,
                        "target_file_path": target_file_path,
                        "action_space_id": event.action_space_id,
                        "agent_instruction": event.agent_instruction,
                        "causal_affordance": event.causal_affordance,
                        "epistemic_bounds": event.epistemic_bounds,
                    },
                )

                logger.info(
                    "Invoking promote_to_urn_authority for URN: %s",
                    event.action_space_id,
                )
                promotion_result = await session.call_tool(
                    name="promote_to_urn_authority",
                    arguments={
                        "source_file_path": target_file_path,
                        "target_urn": event.action_space_id,
                        "urn_authority_dir": "coreason-urn-authority",
                    },
                )

        if self._nc and self._nc.is_connected:
            try:
                promotion_payload = orjson.loads(promotion_result.content[0].text)
            except Exception:
                promotion_payload = {
                    "raw_output": promotion_result.content[0].text
                    if promotion_result.content
                    else ""
                }

            receipt_envelope = {
                "urn": event.action_space_id,
                "scaffold_result": scaffold_result.content[0].text
                if scaffold_result.content
                else "",
                "promotion_result": promotion_payload,
                "status": "PROMOTED_PENDING_REVIEW",
            }
            await self._nc.publish(
                "coreason.oracle.review", orjson.dumps(receipt_envelope)
            )
            logger.info(
                "Successfully published promotion receipt to coreason.oracle.review"
            )

    async def shutdown(self) -> None:
        """Gracefully disconnect from NATS."""
        if self._nc and self._nc.is_connected:
            await self._nc.drain()
            logger.info("Subscriber disconnected from NATS")
