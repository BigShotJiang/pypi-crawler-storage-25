package coreason.governance.license

# Default deny
default is_sovereign = false

# Allow if the JWT explicitly contains the required entitlement and is not expired
is_sovereign {
    # Get expiration timestamp (supporting both standard exp and legacy expires_at_epoch)
    expiry := get_expiry(input)
    expiry > (time.now_ns() / 1000000000)

    # Check for specific IP sovereignty entitlement
    some i
    input.entitlements[i] == "IP_SOVEREIGNTY_EXCEPTION"
}

get_expiry(inp) = val {
    val := inp.exp
}

get_expiry(inp) = val {
    not inp.exp
    val := inp.expires_at_epoch
}
