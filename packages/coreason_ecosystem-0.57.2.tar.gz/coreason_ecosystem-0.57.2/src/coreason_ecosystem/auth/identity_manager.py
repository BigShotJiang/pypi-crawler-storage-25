# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

"""Workload Identity Validation and Passthrough.

This module provides utilities to extract SPIFFE IDs and JWT tokens from
inbound headers for use in zero-trust authorization sidecars.
"""

import base64
import json
import logging
import os
import threading
import time
from typing import Any
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import load_pem_public_key

logger = logging.getLogger(__name__)

_cache_lock = threading.Lock()
# Maps (raw_jwt, public_key_str) -> (expiration_timestamp, verified_payload)
_verification_cache: dict[tuple[str, str], tuple[float, dict[str, Any]]] = {}
_MAX_CACHE_SIZE = 1000


def _decode_b64url(s: str) -> bytes:
    padded = s + "=" * ((4 - len(s) % 4) % 4)
    return base64.urlsafe_b64decode(padded)


def verify_jwt(raw_jwt: str, public_key_str: str) -> dict[str, Any] | None:
    """Verify the signature and claims of an Ed25519 signed JWT."""
    now = time.time()

    # Check verification cache
    with _cache_lock:
        if (raw_jwt, public_key_str) in _verification_cache:
            exp_time, cached_payload = _verification_cache[(raw_jwt, public_key_str)]
            if exp_time > now:
                return cached_payload
            else:
                del _verification_cache[(raw_jwt, public_key_str)]

    parts = raw_jwt.split(".")
    if len(parts) != 3:
        return None

    header_b64, payload_b64, signature_b64 = parts

    try:
        header = json.loads(_decode_b64url(header_b64))
        payload = json.loads(_decode_b64url(payload_b64))
        signature = _decode_b64url(signature_b64)
    except Exception as e:
        logger.debug("Failed to decode JWT parts: %s", e)
        return None

    # We only support EdDSA (Ed25519) algorithm for zero-trust token validation
    if header.get("alg") != "EdDSA":
        logger.warning(
            "Unsupported JWT algorithm for verification: %s", header.get("alg")
        )
        return None

    # Load public key
    try:
        key_str = public_key_str.strip()
        if "-----BEGIN PUBLIC KEY-----" in key_str:
            public_key = load_pem_public_key(key_str.encode("utf-8"))
        elif len(key_str) == 64:
            raw_bytes = bytes.fromhex(key_str)
            public_key = Ed25519PublicKey.from_public_bytes(raw_bytes)
        else:
            logger.error(
                "Failed to parse verification public key format (must be PEM or 64-char hex)"
            )
            return None
    except Exception as e:
        logger.error("Failed to load verification public key: %s", e)
        return None

    if not isinstance(public_key, Ed25519PublicKey):
        logger.error("Loaded verification public key is not an Ed25519PublicKey")
        return None

    # Verify signature
    try:
        message = f"{header_b64}.{payload_b64}".encode("ascii")
        public_key.verify(signature, message)
    except Exception as e:
        logger.warning("JWT signature verification failed: %s", e)
        return None

    # Verify expiration (exp claim)
    exp = payload.get("exp")
    exp_time = float("inf")
    if exp is not None:
        try:
            exp_time = float(exp)
            if exp_time < now:
                logger.warning("JWT token has expired")
                return None
        except ValueError, TypeError:
            logger.warning("JWT exp claim is malformed")
            return None

    if not isinstance(payload, dict):
        return None

    # Cache successful verification result
    ttl = min(exp_time, now + 3600.0)
    with _cache_lock:
        if len(_verification_cache) >= _MAX_CACHE_SIZE:
            # Evict first element if cache is full (FIFO eviction)
            try:
                first_key = next(iter(_verification_cache))
                del _verification_cache[first_key]
            except StopIteration:
                pass
        _verification_cache[(raw_jwt, public_key_str)] = (ttl, payload)

    return payload


def extract_workload_identity(headers: dict[str, str]) -> dict[str, Any]:
    """Extracts the SPIFFE SVID or JWT from Envoy/NATS headers.

    If verification public keys are present in the environment (COREASON_ROOT_CA_KEY
    or COREASON_DEV_KEY), cryptographic signature verification is performed.
    Otherwise, fallback to insecure passthrough decoding is allowed for local test/dev envs.
    """
    # Normalize headers to lowercase for deterministic lookups
    norm_headers = {k.lower(): v for k, v in headers.items()}

    # Extract SPIFFE ID (typically injected by Envoy/SPIRE)
    spiffe_id = norm_headers.get("x-spiffe-id")

    # Extract JWT (typically in Authorization header)
    auth_header = norm_headers.get("authorization")
    jwt_payload = None
    raw_jwt = None

    if auth_header and auth_header.startswith("Bearer "):
        raw_jwt = auth_header[7:]
        public_key_str = os.environ.get("COREASON_ROOT_CA_KEY") or os.environ.get(
            "COREASON_DEV_KEY"
        )
        if public_key_str and public_key_str.strip():
            # Cryptographic verification enabled
            jwt_payload = verify_jwt(raw_jwt, public_key_str)
        else:
            # Fallback passthrough decoding (development only)
            try:
                parts = raw_jwt.split(".")
                if len(parts) >= 2:
                    decoded_bytes = _decode_b64url(parts[1])
                    jwt_payload = json.loads(decoded_bytes)
            except Exception as e:
                logger.debug("Failed to decode JWT for passthrough: %s", e)

    return {
        "spiffe_id": spiffe_id,
        "jwt_payload": jwt_payload,
        "raw_jwt": raw_jwt,
        "tenant_cid": norm_headers.get("x-tenant-cid"),
    }
