# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>


import hashlib
import importlib.metadata
from pathlib import Path


async def calculate_epistemic_root(project_path: Path) -> str:
    """Calculate the Epistemic Merkle Root."""

    # Component 1 (H_ontology)
    schema_path = project_path / "coreason_ontology.schema.json"
    if schema_path.exists():
        h_ontology = hashlib.sha256(schema_path.read_bytes()).hexdigest()
    else:
        h_ontology = hashlib.sha256(b"").hexdigest()

    # Component 2 (H_env)
    env_str = ""

    # 1. Get the local manifest version (which the CLI has access to)
    try:
        manifest_version = importlib.metadata.version("coreason-manifest")
        env_str += f"coreason-manifest=={manifest_version}\n"
    except importlib.metadata.PackageNotFoundError:
        manifest_version = "unknown"
        env_str += f"coreason-manifest=={manifest_version}\n"

    # 2. The Runtime version must strictly mirror the manifest version in a locked ecosystem
    env_str += f"coreason-runtime=={manifest_version}\n"

    h_env = hashlib.sha256(env_str.encode("utf-8")).hexdigest()

    # Component 3 (H_capabilities)
    ledger_path = project_path / ".coreason" / "capability_ledger.json"
    if ledger_path.exists():
        h_capabilities = hashlib.sha256(ledger_path.read_bytes()).hexdigest()
    else:
        h_capabilities = hashlib.sha256(b"{}").hexdigest()

    # The Merkle Root
    combined = h_ontology + h_env + h_capabilities
    return hashlib.sha256(combined.encode("utf-8")).hexdigest()


def write_registry_lock(project_path: Path, root_hash: str) -> None:
    """Write the registry lock file with the given Merkle root."""
    import json

    lock_path = project_path / ".coreason" / "registry.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    out = {"epistemic_root": root_hash}
    lock_path.write_text(json.dumps(out, indent=2), encoding="utf-8")


def read_registry_lock(project_path: Path) -> str | None:
    """Read the registry lock file and return the Merkle root if it exists."""
    import json

    lock_path = project_path / ".coreason" / "registry.lock"
    if lock_path.exists():
        try:
            data = json.loads(lock_path.read_text(encoding="utf-8"))
            return str(data.get("epistemic_root"))
        except json.JSONDecodeError, ValueError:
            return lock_path.read_text(encoding="utf-8").strip()
    return None
