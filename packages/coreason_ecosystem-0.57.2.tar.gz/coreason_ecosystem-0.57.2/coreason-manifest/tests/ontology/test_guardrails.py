# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-manifest>

from coreason_manifest.spec.ontology import GuardrailViolationEvent


def test_guardrail_violation_event_instantiation() -> None:
    """Tests the basic instantiation and validation of GuardrailViolationEvent."""
    event = GuardrailViolationEvent(
        event_cid="cid_123",
        timestamp=123456789.0,
        violation_id="viol_123",
        status_code=403,
        violation_type="pii_leak",
        violation_details={"field": "ssn", "action": "blocked"},
    )
    assert event.violation_id == "viol_123"
    assert event.status_code == 403
    assert event.violation_type == "pii_leak"
    assert event.violation_details["field"] == "ssn"
    assert isinstance(event.timestamp, float)


def test_guardrail_violation_event_json_isomorphism() -> None:
    """Tests that the event correctly serializes and deserializes."""
    event = GuardrailViolationEvent(
        event_cid="cid_456",
        timestamp=123456790.0,
        violation_id="viol_456",
        status_code=422,
        violation_type="input_validation_failed",
        violation_details={"error": "invalid format"},
    )
    json_data = event.model_dump_json()
    rehydrated = GuardrailViolationEvent.model_validate_json(json_data)
    assert rehydrated.violation_id == event.violation_id
    assert rehydrated.status_code == event.status_code
    assert rehydrated.violation_details == event.violation_details
