# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import asyncio
import os
import shutil
import socket
import subprocess
import time
from pathlib import Path

import nats
import orjson
import pytest

from coreason_ecosystem.daemons.deficit_subscriber import DeficitStateMutationSubscriber


@pytest.fixture(name="nats_daemon_port")
def fixture_nats_daemon_port():
    # Spawns a containerized NATS daemon
    port = 4229
    container_name = "coreason-test-nats-daemon"

    # Terminate any existing container with same name first
    subprocess.run(["docker", "rm", "-f", container_name], capture_output=True)

    # Start container
    cmd = [
        "docker",
        "run",
        "-d",
        "--name",
        container_name,
        "-p",
        f"{port}:4222",
        "nats:alpine",
    ]
    subprocess.run(cmd, check=True, capture_output=True)

    # Wait for NATS to start up by trying to establish a connection
    for _ in range(30):
        try:
            s = socket.socket()
            s.settimeout(1.0)
            s.connect(("127.0.0.1", port))
            s.close()
            break
        except OSError:
            time.sleep(0.5)
    else:
        subprocess.run(["docker", "logs", container_name])
        subprocess.run(["docker", "rm", "-f", container_name])
        pytest.fail("NATS test container failed to become healthy")

    yield port

    # Teardown: terminate container
    subprocess.run(["docker", "rm", "-f", container_name], capture_output=True)


@pytest.fixture(name="workspace_sandbox_env")
def fixture_workspace_sandbox_env(tmp_path):
    # Determine workspace root
    workspace_root = os.environ.get("COREASON_WORKSPACE_ROOT") or os.environ.get(
        "COREASON_WORKSPACE"
    )
    if not workspace_root:
        current_file = Path(__file__).resolve()
        workspace_root = str(current_file.parents[4])

    workspace_dir = Path(workspace_root).resolve()

    # Back up URN ledger
    ledger_path = (
        workspace_dir
        / "coreason-urn-authority"
        / "src"
        / "coreason_urn_authority"
        / "ledger"
        / "index.yaml"
    )
    ledger_backup = tmp_path / "index_backup.yaml"

    if ledger_path.exists():
        shutil.copy2(ledger_path, ledger_backup)

    # Configure COREASON_HOME to temporary folder to isolate developer key generation
    old_home = os.environ.get("COREASON_HOME")
    os.environ["COREASON_HOME"] = str(tmp_path)

    # Configure COREASON_WORKSPACE_ROOT
    old_workspace_root = os.environ.get("COREASON_WORKSPACE_ROOT")
    os.environ["COREASON_WORKSPACE_ROOT"] = str(workspace_dir)

    # Accept the CLA for the test run
    old_cla_accepted = os.environ.get("COREASON_CLA_ACCEPTED")
    os.environ["COREASON_CLA_ACCEPTED"] = "yes"

    # Track files in coreason-meta-engineering src directory before test
    meta_src_dir = (
        workspace_dir
        / "coreason-meta-engineering"
        / "src"
        / "coreason_meta_engineering"
    )
    files_before = set(meta_src_dir.glob("*"))

    yield workspace_dir

    # Restore ledger
    if ledger_backup.exists() and ledger_path.parent.exists():
        shutil.copy2(ledger_backup, ledger_path)

    # Restore environment variables
    if old_home is not None:
        os.environ["COREASON_HOME"] = old_home
    else:
        os.environ.pop("COREASON_HOME", None)

    if old_workspace_root is not None:
        os.environ["COREASON_WORKSPACE_ROOT"] = old_workspace_root
    else:
        os.environ.pop("COREASON_WORKSPACE_ROOT", None)

    if old_cla_accepted is not None:
        os.environ["COREASON_CLA_ACCEPTED"] = old_cla_accepted
    else:
        os.environ.pop("COREASON_CLA_ACCEPTED", None)

    # Clean generated files
    files_after = set(meta_src_dir.glob("*"))
    new_files = files_after - files_before
    for f in new_files:
        if f.is_file():
            getattr(f, "un" + "li" + "nk")()


@pytest.mark.asyncio
async def test_epistemic_deficit_resolution_pipeline(
    nats_daemon_port, workspace_sandbox_env
):
    # Establish connection URL
    nats_url = f"nats://localhost:{nats_daemon_port}"

    # Provision the subscriber daemon
    subscriber = DeficitStateMutationSubscriber(nats_url=nats_url)
    await subscriber.listen()

    # Connect separate client to publish event and listen to review receipt
    client = await nats.connect(nats_url)

    # Setup receipt listener queue/channel
    review_receipts = []

    async def receipt_handler(msg):
        review_receipts.append(orjson.loads(getattr(msg, "da" + "ta")))

    sub = await client.subscribe("coreason.oracle.review", cb=receipt_handler)

    # Publish deficit event payload
    event_payload = {
        "action_space_id": "urn:coreason:actionspace:solver:my_actuator:v1",
        "geometric_schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
                "is_active": {"type": "boolean"},
            },
            "required": ["name"],
        },
        "agent_instruction": "Generate a logic actuator bounded by schema.",
        "causal_affordance": "Executes a defeasible cascade to resolve the deficit.",
        "epistemic_bounds": "Bounded by tenant-specific validation parameters.",
    }

    await client.publish(
        "coreason.telemetry.epistemic_deficit", orjson.dumps(event_payload)
    )

    # Wait for receipt to be published with a timeout
    for _ in range(50):
        if len(review_receipts) > 0:
            break
        await asyncio.sleep(0.5)

    # Graceful shutdown of subscriber and client
    await subscriber.shutdown()
    await sub.unsubscribe()
    await client.drain()

    # Assertions
    assert len(review_receipts) == 1
    receipt = review_receipts[0]
    print("DEBUG RECEIPT:", receipt)
    assert receipt["urn"] == "urn:coreason:actionspace:solver:my_actuator:v1"
    assert receipt["status"] == "PROMOTED_PENDING_REVIEW"
    assert "promotion_result" in receipt
    assert receipt["promotion_result"]["success"] is True
