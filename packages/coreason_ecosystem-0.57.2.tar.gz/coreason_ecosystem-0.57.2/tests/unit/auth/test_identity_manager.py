# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-ecosystem>

import base64
import json
from coreason_ecosystem.auth.identity_manager import extract_workload_identity


from typing import Any


def _encode_jwt_manually(payload: dict[str, Any]) -> str:
    header = {"alg": "HS256", "typ": "JWT"}
    header_json = json.dumps(header, separators=(",", ":")).encode("utf-8")
    payload_json = json.dumps(payload, separators=(",", ":")).encode("utf-8")

    header_b64 = base64.urlsafe_b64encode(header_json).decode("utf-8").rstrip("=")
    payload_b64 = base64.urlsafe_b64encode(payload_json).decode("utf-8").rstrip("=")
    signature_b64 = "dummy_signature"

    return f"{header_b64}.{payload_b64}.{signature_b64}"


def test_extract_workload_identity_spiffe_only():
    headers = {"X-SPIFFE-ID": "spiffe://coreason.ai/workload/test"}
    identity = extract_workload_identity(headers)
    assert identity["spiffe_id"] == "spiffe://coreason.ai/workload/test"
    assert identity["jwt_payload"] is None


def test_extract_workload_identity_jwt_only():
    payload = {"sub": "user123", "iat": 1600000000}
    token = _encode_jwt_manually(payload)
    headers = {"Authorization": f"Bearer {token}"}

    identity = extract_workload_identity(headers)
    assert identity["jwt_payload"] == payload
    assert identity["spiffe_id"] is None
    assert identity["raw_jwt"] == token


def test_extract_workload_identity_jwt_and_spiffe():
    payload = {"sub": "user-1"}
    token = _encode_jwt_manually(payload)
    headers = {
        "Authorization": f"Bearer {token}",
        "X-SPIFFE-ID": "spiffe://local/workload",
        "X-Tenant-CID": "tenant-123",
    }

    result = extract_workload_identity(headers)

    assert result["spiffe_id"] == "spiffe://local/workload"
    assert result["jwt_payload"] == payload
    assert result["raw_jwt"] == token
    assert result["tenant_cid"] == "tenant-123"


def test_extract_workload_identity_case_insensitivity():
    payload = {"sub": "user-1"}
    token = _encode_jwt_manually(payload)
    headers = {
        "authorization": f"Bearer {token}",
        "x-spiffe-id": "spiffe://local/workload",
    }

    result = extract_workload_identity(headers)

    assert result["spiffe_id"] == "spiffe://local/workload"
    assert result["jwt_payload"] == payload
    assert result["raw_jwt"] == token


def test_extract_workload_identity_mixed_case():
    headers = {
        "x-spiffe-id": "spiffe://coreason.ai/workload/test",
        "authorization": "Bearer token123",
    }
    # Note: token123 is invalid JWT but extract_workload_identity handles it gracefully
    identity = extract_workload_identity(headers)
    assert identity["spiffe_id"] == "spiffe://coreason.ai/workload/test"
    assert identity["jwt_payload"] is None
    assert identity["raw_jwt"] == "token123"


def test_extract_workload_identity_tenant_cid():
    headers = {"X-Tenant-CID": "tenant-123"}
    identity = extract_workload_identity(headers)
    assert identity["tenant_cid"] == "tenant-123"


def test_extract_workload_identity_with_valid_ed25519_signature(monkeypatch):
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    import time

    # Generate Ed25519 key pair
    private_key = ed25519.Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    public_key_pem = public_key.public_bytes(
        encoding=Encoding.PEM, format=PublicFormat.SubjectPublicKeyInfo
    ).decode("utf-8")

    # Construct JWT
    header = {"alg": "EdDSA", "typ": "JWT"}
    payload = {"sub": "user-456", "exp": time.time() + 3600}

    def encode_b64url(data: bytes) -> str:
        return base64.urlsafe_b64encode(data).decode("utf-8").rstrip("=")

    header_b64 = encode_b64url(json.dumps(header).encode("utf-8"))
    payload_b64 = encode_b64url(json.dumps(payload).encode("utf-8"))

    message = f"{header_b64}.{payload_b64}".encode("ascii")
    signature = private_key.sign(message)
    signature_b64 = encode_b64url(signature)

    token = f"{header_b64}.{payload_b64}.{signature_b64}"

    monkeypatch.setenv("COREASON_ROOT_CA_KEY", public_key_pem)

    headers = {"Authorization": f"Bearer {token}"}
    result = extract_workload_identity(headers)

    assert result["jwt_payload"] == payload
    assert result["raw_jwt"] == token


def test_extract_workload_identity_with_invalid_ed25519_signature(monkeypatch):
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

    # Generate two different keys
    private_key_sign = ed25519.Ed25519PrivateKey.generate()
    private_key_verify = ed25519.Ed25519PrivateKey.generate()
    public_key_verify = private_key_verify.public_key()
    public_key_pem = public_key_verify.public_bytes(
        encoding=Encoding.PEM, format=PublicFormat.SubjectPublicKeyInfo
    ).decode("utf-8")

    # Construct JWT signed with the wrong key
    header = {"alg": "EdDSA", "typ": "JWT"}
    payload = {"sub": "user-456"}

    def encode_b64url(data: bytes) -> str:
        return base64.urlsafe_b64encode(data).decode("utf-8").rstrip("=")

    header_b64 = encode_b64url(json.dumps(header).encode("utf-8"))
    payload_b64 = encode_b64url(json.dumps(payload).encode("utf-8"))

    message = f"{header_b64}.{payload_b64}".encode("ascii")
    signature = private_key_sign.sign(message)
    signature_b64 = encode_b64url(signature)

    token = f"{header_b64}.{payload_b64}.{signature_b64}"

    monkeypatch.setenv("COREASON_ROOT_CA_KEY", public_key_pem)

    headers = {"Authorization": f"Bearer {token}"}
    result = extract_workload_identity(headers)

    # Payload verification should fail (returns None)
    assert result["jwt_payload"] is None
    assert result["raw_jwt"] == token


def test_extract_workload_identity_expired_jwt(monkeypatch):
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    import time

    private_key = ed25519.Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    public_key_pem = public_key.public_bytes(
        encoding=Encoding.PEM, format=PublicFormat.SubjectPublicKeyInfo
    ).decode("utf-8")

    # Construct JWT with exp in the past
    header = {"alg": "EdDSA", "typ": "JWT"}
    payload = {"sub": "user-456", "exp": time.time() - 3600}

    def encode_b64url(data: bytes) -> str:
        return base64.urlsafe_b64encode(data).decode("utf-8").rstrip("=")

    header_b64 = encode_b64url(json.dumps(header).encode("utf-8"))
    payload_b64 = encode_b64url(json.dumps(payload).encode("utf-8"))

    message = f"{header_b64}.{payload_b64}".encode("ascii")
    signature = private_key.sign(message)
    signature_b64 = encode_b64url(signature)

    token = f"{header_b64}.{payload_b64}.{signature_b64}"

    monkeypatch.setenv("COREASON_ROOT_CA_KEY", public_key_pem)

    headers = {"Authorization": f"Bearer {token}"}
    result = extract_workload_identity(headers)

    # Expiry verification should fail (returns None)
    assert result["jwt_payload"] is None


def test_extract_workload_identity_raw_hex_public_key(monkeypatch):
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    import time

    private_key = ed25519.Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    # Hex encode the raw 32-byte public key
    raw_hex_key = public_key.public_bytes(
        encoding=Encoding.Raw, format=PublicFormat.Raw
    ).hex()

    header = {"alg": "EdDSA", "typ": "JWT"}
    payload = {"sub": "user-789", "exp": time.time() + 3600}

    def encode_b64url(data: bytes) -> str:
        return base64.urlsafe_b64encode(data).decode("utf-8").rstrip("=")

    header_b64 = encode_b64url(json.dumps(header).encode("utf-8"))
    payload_b64 = encode_b64url(json.dumps(payload).encode("utf-8"))

    message = f"{header_b64}.{payload_b64}".encode("ascii")
    signature = private_key.sign(message)
    signature_b64 = encode_b64url(signature)

    token = f"{header_b64}.{payload_b64}.{signature_b64}"

    monkeypatch.setenv("COREASON_DEV_KEY", raw_hex_key)

    headers = {"Authorization": f"Bearer {token}"}
    result = extract_workload_identity(headers)

    assert result["jwt_payload"] == payload


def test_verify_jwt_cache_hits():
    from coreason_ecosystem.auth.identity_manager import verify_jwt, _verification_cache
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    import time
    from unittest.mock import patch

    private_key = ed25519.Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    raw_hex_key = public_key.public_bytes(
        encoding=Encoding.Raw, format=PublicFormat.Raw
    ).hex()

    header = {"alg": "EdDSA", "typ": "JWT"}
    payload = {"sub": "cached-user", "exp": time.time() + 3600}

    def encode_b64url(data: bytes) -> str:
        return base64.urlsafe_b64encode(data).decode("utf-8").rstrip("=")

    header_b64 = encode_b64url(json.dumps(header).encode("utf-8"))
    payload_b64 = encode_b64url(json.dumps(payload).encode("utf-8"))

    message = f"{header_b64}.{payload_b64}".encode("ascii")
    signature = private_key.sign(message)
    signature_b64 = encode_b64url(signature)

    token = f"{header_b64}.{payload_b64}.{signature_b64}"

    # Clear cache first to ensure a clean state
    _verification_cache.clear()

    # First call: verifies signature and populates cache
    result1 = verify_jwt(token, raw_hex_key)
    assert result1 == payload
    assert (token, raw_hex_key) in _verification_cache

    # Second call: returns cached value directly (bypasses signature check)
    with patch(
        "coreason_ecosystem.auth.identity_manager.Ed25519PublicKey"
    ) as mock_pubkey:
        result2 = verify_jwt(token, raw_hex_key)
        assert result2 == payload
        # Ensure we bypassed loading the public key from bytes
        mock_pubkey.from_public_bytes.assert_not_called()
