# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-manifest>

from typing import Any

import pytest
from coreason_ecosystem.fleet.skypilot_actuator import SkyPilotActuator, SkyPilotTarget
from coreason_manifest.spec.ontology import (
    SpatialHardwareProfile as HardwareProfile,
    EpistemicSecurityProfile as SecurityProfile,
)


class FakeTask:
    def __init__(self, setup=None, run=None):
        self.setup = setup
        self.run = run
        self.resources = None

    def set_resources(self, resources):
        self.resources = resources


class FakeSky:
    """Fake SkyPilot module for physical substrate testing."""

    def __init__(self):
        self.launch_called = False
        self.down_called = False
        self.resources_called = False
        self.task_called = False
        self.status_data = []
        self.last_resources = None
        self.last_task = None
        self.results = {}

    def Resources(self, cloud=None, accelerators=None, use_spot=True):
        self.resources_called = True
        self.last_resources = {
            "cloud": cloud,
            "accelerators": accelerators,
            "use_spot": use_spot,
        }
        return self.last_resources

    def Task(self, setup=None, run=None):
        self.task_called = True
        self.last_task = FakeTask(setup=setup, run=run)
        return self.last_task

    def launch(self, task, cluster_name, idle_minutes_to_autostop):
        self.launch_called = True
        rid = f"rid-launch-{cluster_name}"
        self.results[rid] = {"status": "SUCCESS"}
        return rid

    def status(self, cluster_names=None, refresh=True):
        rid = "rid-status"
        self.results[rid] = self.status_data
        return rid

    def down(self, cluster_name):
        self.down_called = True
        rid = f"rid-down-{cluster_name}"
        self.results[rid] = {"status": "DOWN"}
        return rid

    def get(self, rid):
        return self.results.get(rid)

    class AWS:
        def name(self):
            return "aws"

    class GCP:
        def name(self):
            return "gcp"


@pytest.fixture
def fake_sky():
    return FakeSky()


@pytest.fixture
def actuator(monkeypatch, fake_sky):
    import coreason_ecosystem.fleet.skypilot_actuator as sp_module

    monkeypatch.setattr(sp_module, "sky", fake_sky)
    return SkyPilotActuator()


@pytest.mark.asyncio
async def test_provision_node_basic(
    actuator: SkyPilotActuator, fake_sky: FakeSky
) -> None:
    target = SkyPilotTarget(use_spot=True, autostop_idle_minutes=15)
    result = await actuator.provision_node(target)

    assert "cluster_name" in result
    assert result["status"] == "provisioned"
    assert fake_sky.resources_called
    assert fake_sky.task_called
    assert fake_sky.launch_called


@pytest.mark.asyncio
async def test_provision_node_with_hardware(
    actuator: SkyPilotActuator, fake_sky: FakeSky
) -> None:
    hardware = HardwareProfile(accelerator_type="urn:coreason:accelerator:h100")
    target = SkyPilotTarget(hardware_profile=hardware, use_spot=False)

    await actuator.provision_node(target)

    task: Any = fake_sky.last_task
    assert task.resources["accelerators"] == "H100:1"
    assert task.resources["use_spot"] is False


@pytest.mark.asyncio
async def test_destroy_node(actuator: SkyPilotActuator, fake_sky: FakeSky) -> None:
    await actuator.destroy_node("test-cluster")
    assert fake_sky.down_called


@pytest.mark.asyncio
async def test_reconcile_state(actuator: SkyPilotActuator, fake_sky: FakeSky) -> None:
    class MockHandle:
        def __init__(self):
            self.cloud = FakeSky.AWS()

    fake_sky.status_data = [
        {
            "name": "coreason-sky-123",
            "status": "UP",
            "handle": MockHandle(),
            "resources": "A100:1",
        }
    ]

    nodes = await actuator.reconcile_state()

    assert len(nodes) == 1
    assert nodes[0]["cluster_name"] == "coreason-sky-123"
    assert nodes[0]["provider"] == "aws"
    assert nodes[0]["vram_capacity"] == 80.0


@pytest.mark.asyncio
async def test_thermodynamic_guillotine(
    actuator: SkyPilotActuator, fake_sky: FakeSky
) -> None:
    fake_sky.status_data = [{"name": "coreason-sky-123", "status": "UP"}]
    await actuator.execute_thermodynamic_guillotine(True)
    assert fake_sky.down_called


@pytest.mark.asyncio
async def test_thermodynamic_guillotine_no_breach(
    actuator: SkyPilotActuator, fake_sky: FakeSky
) -> None:
    await actuator.execute_thermodynamic_guillotine(False)
    assert not fake_sky.down_called


@pytest.mark.asyncio
async def test_provision_node_with_mesh_injection(
    actuator: SkyPilotActuator, fake_sky: FakeSky
) -> None:
    hardware = HardwareProfile(accelerator_type="urn:coreason:accelerator:a100")
    security = SecurityProfile()
    target = SkyPilotTarget(
        hardware_profile=hardware,
        security_profile=security,
        use_spot=True,
    )

    await actuator.provision_node(target)

    task: Any = fake_sky.last_task
    setup_cmd = task.setup
    assert "mkdir -p /etc/coreason" in setup_cmd
    assert "/opt/coreason/bin/bootstrap.sh" in setup_cmd
    assert "base64 -d" in setup_cmd


@pytest.mark.asyncio
async def test_reconcile_state_handle_exception(
    actuator: SkyPilotActuator, fake_sky: FakeSky
) -> None:
    class ErrorHandle:
        @property
        def cloud(self):
            raise Exception("Cloud extraction failed")

    fake_sky.status_data = [
        {"name": "coreason-sky-error", "status": "UP", "handle": ErrorHandle()}
    ]

    nodes = await actuator.reconcile_state()

    assert len(nodes) == 1
    assert nodes[0]["cluster_name"] == "coreason-sky-error"
    assert nodes[0]["provider"] == "unknown"


@pytest.fixture
def temp_db_path(tmp_path):
    return tmp_path / "test_actuator_state.db"


@pytest.mark.asyncio
async def test_actuator_sqlite_state_cache(temp_db_path, monkeypatch, fake_sky):
    import coreason_ecosystem.fleet.skypilot_actuator as sp_module
    import sqlite3

    monkeypatch.setattr(sp_module, "sky", fake_sky)
    actuator = SkyPilotActuator(db_path=temp_db_path)

    # 1. Verify DB is initialized
    assert temp_db_path.exists()

    # 2. Provision node and check state is updated to PROVISIONED
    target = SkyPilotTarget(use_spot=True)
    res = await actuator.provision_node(target)
    cluster_name = res["cluster_name"]

    conn = sqlite3.connect(temp_db_path)
    try:
        cursor = conn.execute(
            "SELECT status FROM sky_clusters WHERE cluster_name = ?", (cluster_name,)
        )
        row = cursor.fetchone()
        assert row is not None
        assert row[0] == "PROVISIONED"
    finally:
        conn.close()

    # 3. Destroy node and check state is deleted
    await actuator.destroy_node(cluster_name)
    conn = sqlite3.connect(temp_db_path)
    try:
        cursor = conn.execute(
            "SELECT status FROM sky_clusters WHERE cluster_name = ?", (cluster_name,)
        )
        row = cursor.fetchone()
        assert row is None
    finally:
        conn.close()


@pytest.mark.asyncio
async def test_actuator_self_healing(temp_db_path, monkeypatch, fake_sky):
    import coreason_ecosystem.fleet.skypilot_actuator as sp_module
    import sqlite3
    import time

    monkeypatch.setattr(sp_module, "sky", fake_sky)
    actuator = SkyPilotActuator(db_path=temp_db_path)

    # Insert stuck clusters manually into the database
    conn = sqlite3.connect(temp_db_path)
    try:
        conn.execute(
            "INSERT INTO sky_clusters (cluster_name, status, updated_at) VALUES (?, ?, ?)",
            ("coreason-sky-stuck-1", "PROVISIONING", time.time()),
        )
        conn.execute(
            "INSERT INTO sky_clusters (cluster_name, status, updated_at) VALUES (?, ?, ?)",
            ("coreason-sky-stuck-2", "DEPROVISIONING", time.time()),
        )
        conn.commit()
    finally:
        conn.close()

    # Trigger self-healing manually
    await actuator.self_heal()

    # Verify fake_sky.down_called was triggered for the stuck clusters
    assert fake_sky.down_called

    # Verify the stuck DB records were deleted/cleaned up
    conn = sqlite3.connect(temp_db_path)
    try:
        cursor = conn.execute("SELECT COUNT(*) FROM sky_clusters")
        count = cursor.fetchone()[0]
        assert count == 0
    finally:
        conn.close()


@pytest.mark.asyncio
async def test_actuator_cli_fallback_provision(monkeypatch):
    import coreason_ecosystem.fleet.skypilot_actuator as sp_module
    from unittest.mock import AsyncMock, patch

    monkeypatch.setattr(sp_module, "sky", None)
    actuator = SkyPilotActuator()

    mock_process = AsyncMock()
    mock_process.returncode = 0
    mock_process.communicate.return_value = (b"", b"")

    with patch(
        "asyncio.create_subprocess_exec", return_value=mock_process
    ) as mock_exec:
        target = SkyPilotTarget(use_spot=True)
        res = await actuator.provision_node(target)

        assert "cluster_name" in res
        assert res["status"] == "provisioned"

        calls = [c[0] for c in mock_exec.call_args_list]
        launch_call = [c for c in calls if "launch" in c][0]
        assert launch_call[0] == "sky"
        assert launch_call[1] == "launch"
        assert launch_call[2] == "-c"
        assert launch_call[3] == res["cluster_name"]

        autostop_call = [c for c in calls if "autostop" in c][0]
        assert autostop_call[0] == "sky"
        assert autostop_call[1] == "autostop"
        assert autostop_call[2] == "-c"
        assert autostop_call[3] == res["cluster_name"]


@pytest.mark.asyncio
async def test_actuator_cli_fallback_destroy(monkeypatch):
    import coreason_ecosystem.fleet.skypilot_actuator as sp_module
    from unittest.mock import AsyncMock, patch

    monkeypatch.setattr(sp_module, "sky", None)
    actuator = SkyPilotActuator()

    mock_process = AsyncMock()
    mock_process.returncode = 0
    mock_process.communicate.return_value = (b"", b"")

    with patch(
        "asyncio.create_subprocess_exec", return_value=mock_process
    ) as mock_exec:
        await actuator.destroy_node("coreason-sky-test")

        mock_exec.assert_called_once_with(
            "sky",
            "down",
            "coreason-sky-test",
            "-y",
            stdout=-1,
            stderr=-1,
        )


@pytest.mark.asyncio
async def test_actuator_cli_fallback_reconcile(monkeypatch):
    import coreason_ecosystem.fleet.skypilot_actuator as sp_module
    from unittest.mock import AsyncMock, patch
    import json

    monkeypatch.setattr(sp_module, "sky", None)
    actuator = SkyPilotActuator()

    mock_process = AsyncMock()
    mock_process.returncode = 0

    status_output = json.dumps(
        [
            {
                "name": "coreason-sky-12345",
                "status": "UP",
                "handle": {"cloud": {"name": "aws"}},
                "resources": "AWS(m5.large, spot)",
            },
            {
                "name": "coreason-sky-67890",
                "status": "UP",
                "handle": {"cloud": {"name": "gcp"}},
                "resources": "GCP(A100:1, spot)",
            },
        ]
    )
    mock_process.communicate.return_value = (status_output.encode("utf-8"), b"")

    with patch(
        "asyncio.create_subprocess_exec", return_value=mock_process
    ) as mock_exec:
        nodes = await actuator.reconcile_state()

        mock_exec.assert_called_once_with(
            "sky",
            "status",
            "--json",
            stdout=-1,
            stderr=-1,
        )

        assert len(nodes) == 2
        assert nodes[0]["cluster_name"] == "coreason-sky-12345"
        assert nodes[0]["provider"] == "aws"
        assert nodes[0]["vram_capacity"] == 0.0

        assert nodes[1]["cluster_name"] == "coreason-sky-67890"
        assert nodes[1]["provider"] == "gcp"
        assert nodes[1]["vram_capacity"] == 80.0
