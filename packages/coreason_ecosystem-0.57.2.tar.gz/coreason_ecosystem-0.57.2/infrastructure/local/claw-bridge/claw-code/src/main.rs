// Copyright (c) 2026 CoReason, Inc
//
// This software is proprietary and dual-licensed
// Licensed under the Prosperity Public License 3.0 (the "License")
// A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
// For details, see the LICENSE file
// Commercial use beyond a 30-day trial requires a separate license
//
// Source Code: <https://github.com/CoReason-AI/coreason-runtime>

use std::env;
use std::io::{self, Read};
use std::process::Command;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

#[derive(Deserialize)]
struct ExecutionInput {
    script: Option<String>,
    schema_to_request: Option<String>,
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let arguments: Vec<String> = env::args().collect();
    if arguments.len() < 2 {
        eprintln!("Usage: claw <list|execute> [tool_name]");
        std::process::exit(1);
    }

    let command = &arguments[1];

    if command == "list" {
        let catalog = json!({
            "tools": [
                {
                    "name": "deploy_cognitive_topology",
                    "description": "Deploy a cognitive topology to the master gateway",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "payload": {"type": "object"},
                            "workflow_id": {"type": "string"},
                            "schema_to_request": {"type": "string"}
                        }
                    }
                },
                {
                    "name": "calculate_math",
                    "description": "Calculate math problem",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "script": {"type": "string"}
                        }
                    }
                },
                {
                    "name": "run_active_inference_model",
                    "description": "Run active inference POMDP model",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "script": {"type": "string"}
                        }
                    }
                }
            ]
        });
        println!("{}", serde_json::to_string(&catalog)?);
        return Ok(());
    }

    if command == "execute" {
        if arguments.len() < 3 {
            eprintln!("Usage: claw execute <tool_name>");
            std::process::exit(1);
        }
        let tool_identity = &arguments[2];

        // Read arguments envelope from standard input
        let mut buffer = String::new();
        let mut stdin_handle = io::stdin();
        stdin_handle.read_to_string(&mut buffer)?;

        let input_envelope: ExecutionInput = serde_json::from_str(&buffer).unwrap_or(ExecutionInput {
            script: None,
            schema_to_request: None,
        });

        if tool_identity == "calculate_math" || tool_identity == "run_active_inference_model" {
            let script_payload = input_envelope.script.unwrap_or_default();
            // Execute the script using Python
            let process_result = Command::new("python3")
                .arg("-c")
                .arg(&script_payload)
                .output();

            let (_success, text_payload) = match process_result {
                Ok(out) => {
                    let stdout_str = String::from_utf8_lossy(&out.stdout).trim().to_string();
                    let stderr_str = String::from_utf8_lossy(&out.stderr).trim().to_string();
                    if out.status.success() {
                        (true, stdout_str)
                    } else {
                        (false, format!("Error: {}", stderr_str))
                    }
                }
                Err(e) => (false, format!("Failed to run python: {}", e)),
            };

            let response_envelope = json!({
                "content": [
                    {
                        "type": "text",
                        "text": text_payload,
                    }
                ]
            });
            println!("{}", serde_json::to_string(&response_envelope)?);
        } else if tool_identity == "deploy_cognitive_topology" {
            let schema_requested = input_envelope.schema_to_request.unwrap_or_else(|| "AgentResponse".to_string());
            let response_envelope = if schema_requested == "VerificationYield" {
                json!({
                    "success": true,
                    "outputs": {"success": true, "justification": "Looks good"},
                    "usage": {"total_tokens": 5},
                    "cost": 0.01,
                    "request_cid": "testhash",
                    "intent_hash": "mcp_hash"
                })
            } else {
                json!({
                    "success": true,
                    "outputs": {"output": "{\"scaffold_type\": \"scaffold_logic_actuator\"}"},
                    "usage": {"total_tokens": 10},
                    "cost": 0.05,
                    "request_cid": "testhash",
                    "intent_hash": "mcp_hash"
                })
            };
            println!("{}", serde_json::to_string(&response_envelope)?);
        } else {
            // Default fallback
            let response_envelope = json!({
                "success": true,
                "receipt": {"success": true},
                "status": "success",
                "intent_hash": "mcp_hash"
            });
            println!("{}", serde_json::to_string(&response_envelope)?);
        }
        return Ok(());
    }

    eprintln!("Unknown command: {}", command);
    std::process::exit(1);
}
