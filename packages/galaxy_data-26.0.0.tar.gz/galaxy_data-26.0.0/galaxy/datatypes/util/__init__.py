"""
Utilities for Galaxy datatypes.
"""
