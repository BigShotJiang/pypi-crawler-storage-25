import chess
import random
SQUARE_SIZE = 64
BOARD_COLOR_1 = "#F0D9B5"
BOARD_COLOR_2 = "#B58863"
piece_symbols = {
    'P': '♙', 'N': '♘', 'B': '♗', 'R': '♖', 'Q': '♕', 'K': '♔',
    'p': '♟', 'n': '♞', 'b': '♝', 'r': '♜', 'q': '♛', 'k': '♚'
}
PIECE_VALUES = {
    chess.PAWN: 10,
    chess.KNIGHT: 30,
    chess.BISHOP: 31,
    chess.ROOK: 50,
    chess.QUEEN: 90,
    chess.KING: 900
}
def get_legal_attackers(board, square):
    attackers = []
    defenders = []
    for move in board.legal_moves:
        if move.to_square == square:
            board.push(move)
            for move2 in board.legal_moves:
                if move2.to_square == square:
                    defenders.append(move2.from_square)
            board.pop()
    for move in board.legal_moves:
        if move.to_square == square:
            attackers.append(move.from_square)
    attackers = list(set(attackers))
    fx = lambda x: PIECE_VALUES[board.piece_at(x).piece_type]
    attackers.sort(key=fx)
    defenders = list(set(defenders))
    defenders.sort(key=fx)
    return attackers, defenders
def tactical_map(board):
    result = {}
    side = board.turn
    opponent = not side
    for square in chess.SQUARES:
        target = board.piece_at(square)
        if not target or target.color != opponent:
            continue
        attackers, defenders = get_legal_attackers(board, square)
        if not attackers:
            continue
        result[square] = [attackers, [square] + defenders]
    best_move = None
    best_score = 0
    exchange = []   
    fx = lambda x: PIECE_VALUES[board.piece_at(x).piece_type]
    for key in result.keys():
        for i in range(min(map(len, result[key]))):
            a = 1
            if len(result[key][1]) > len(result[key][0]):
                a = 0
            score = sum(map(fx, result[key][1][:(i+a)])) - sum(map(fx, result[key][0][:i]))
            m = [move for move in board.legal_moves if move.from_square == result[key][0][0] and move.to_square == key][0]
            if score == 0:
                exchange.append(m)
            elif best_score < score:
                best_move = m
                best_score = score
    #print(exchange)
    if best_move is not None:
        return best_move
    return None
def chess_ai(board):
    if not board.is_game_over():
        out = tactical_map(board)
        move = None
        if out is None:
            move = random.choice(list(board.legal_moves))
        else:
            move = out
        return move
    if board.is_game_over():
        return None
    return None

def gui():
    import tkinter as tk
    class ChessGUI:
        def __init__(self, root):
            self.root = root
            self.board = chess.Board()
            self.canvas = tk.Canvas(root, width=8*SQUARE_SIZE, height=8*SQUARE_SIZE)
            self.canvas.pack()
            self.selected_square = None
            self.draw_board()
            self.canvas.bind("<Button-1>", self.on_click)
        def draw_board(self):
            self.canvas.delete("all")
            for row in range(8):
                for col in range(8):
                    color = BOARD_COLOR_1 if (row + col) % 2 == 0 else BOARD_COLOR_2
                    x1 = col * SQUARE_SIZE
                    y1 = row * SQUARE_SIZE
                    x2 = x1 + SQUARE_SIZE
                    y2 = y1 + SQUARE_SIZE
                    self.canvas.create_rectangle(x1, y1, x2, y2, fill=color)
                    square = chess.square(col, 7 - row)
                    piece = self.board.piece_at(square)
                    if piece:
                        symbol = piece_symbols[piece.symbol()]
                        self.canvas.create_text(
                            x1 + SQUARE_SIZE/2,
                            y1 + SQUARE_SIZE/2,
                            text=symbol,
                            font=("Arial", 32)
                        )
        def on_click(self, event):
            col = event.x // SQUARE_SIZE
            row = event.y // SQUARE_SIZE
            square = chess.square(col, 7 - row)
            if self.selected_square is None:
                self.selected_square = square
            else:
                move = chess.Move(self.selected_square, square)

                if move in self.board.legal_moves:
                    self.board.push(move)
                    self.selected_square = None
                    self.draw_board()
                    self.root.after(300, self.random_move)
                else:
                    self.selected_square = None
        def random_move(self):
            out = chess_ai(self.board)
            if out is None:
                print("game over")
            else:
                self.board.push(out)
                self.draw_board()
    root = tk.Tk()
    root.title("Random Chess GUI")
    app = ChessGUI(root)
    root.mainloop()
def print_board(board):
    print("\n   +-----------------+")
    for rank in range(7, -1, -1):
        print(f" {rank+1} |", end=" ")
        for file in range(8):
            square = chess.square(file, rank)
            piece = board.piece_at(square)
            symbol = piece.symbol() if piece else "."
            print(f"{symbol} ", end="")
        print("|")
    print("   +-----------------+")
    print("     a b c d e f g h\n")
def console_game(fen=None, moves=None):
    if fen:
        board = chess.Board(fen)
    else:
        board = chess.Board()
    if moves:
        for m in moves:
            try:
                move = chess.Move.from_uci(m)
                if move in board.legal_moves:
                    board.push(move)
                else:
                    print(f"Skipping illegal move in list: {m}")
            except:
                print(f"Invalid move format in list: {m}")
    while not board.is_game_over():
        print_board(board)
        while True:
            user_input = input("Your move (e.g. e2e4): ").strip()
            if user_input.lower() in ["quit", "exit"]:
                print("Exiting game.")
                return
            try:
                move = chess.Move.from_uci(user_input)
                if move in board.legal_moves:
                    break
                else:
                    print("Illegal move, try again.")
            except:
                print("Invalid format, use UCI like e2e4.")
        board.push(move)
        if board.is_game_over():
            break
        ai_move = chess_ai(board)
        print(f"AI plays: {ai_move}")
        if ai_move:
            board.push(ai_move)
    print_board(board)
    print("Game over:", board.result())
