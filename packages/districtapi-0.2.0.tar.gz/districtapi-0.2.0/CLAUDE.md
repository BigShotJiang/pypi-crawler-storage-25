# CLAUDE.md — districtapi.dev Project

## What This Project Is

A developer-first REST API for US school district and school data, built entirely on free federal government datasets (NCES CCD, NCES EDGE, Census TIGER). No data licensing fees. No ethical gray areas. The raw data is free — the value is normalization, a clean schema, geospatial lookups, and a great developer experience.

**The killer feature:** `GET /v1/districts?address=123 Main St, Apple Valley, CA` → returns the school district serving that address, with full profile: enrollment, demographics, schools list, boundary polygon (GeoJSON), per-pupil expenditure. This address-to-district lookup currently costs $189/month at SchoolDigger (Enterprise tier). We will offer it on a free tier.

**Primary domain:** districtapi.dev  
**Fallback/redirect:** districtapi.com  
**GitHub org:** github.com/districtapi  
**PyPI package:** districtapi (v0.1.2 placeholder published)

---

## Who Gregory Is

- IT Systems Administrator at Apple Valley Unified School District (AVUSD), San Bernardino County, California
- Google Workspace for Education super admin
- Builds Python automation tools, Slack bots, Flask webhooks, PostgreSQL pipelines
- Familiar with: Python, FastAPI, Supabase, AWS Lambda, Slack SDK, Google APIs, Zendesk, PostgreSQL
- Prefers managed/serverless infrastructure — does not want to manage servers
- Time budget: a few hours per week; needs to be mostly passive after the build phase
- Cash budget: under $500 upfront total

**Gregory's domain expertise is a genuine moat.** He works in a school district, understands NCES data structures, knows what SIS/CAMS systems look like, and can write authoritative Stack Overflow answers as someone who has lived this data professionally.

---

## Legal Status — IMPORTANT

An email was sent on March 22, 2026 to **EDFacts@ed.gov** asking:

> "May the public-use CCD school and district directory files be used as the data source for a commercial API product?"

**Awaiting response.** This is the gate for full build commitment. However, the market has established precedent — SchoolDigger (since 2006), GreatSchools, Geocodio, and Urban Institute all build on CCD public-use data commercially without issue. The "statistical purposes" restriction in CCD language appears to apply to restricted-use microdata (individual student records, NAEP), not institutional directory data.

**Do not build production infrastructure until this reply arrives.** Data ingestion research and schema design can proceed.

---

## Current Status (as of March 22, 2026)

### ✅ Done
- [ ] Project researched and validated
- [x] Domains registered: `districtapi.dev` and `districtapi.com` on Cloudflare
- [x] Email sent to NCES asking about commercial use
- [x] GitHub org claimed: `districtapi`
- [x] X (Twitter) claimed: `@districtapi`
- [x] npm org claimed: `districtapi`
- [x] PyPI account created, package `districtapi` published at v0.1.0 (placeholder)
- [x] dev.to org claimed
- [x] Hashnode claimed
- [x] Reddit: r/districtapi created
- [x] RapidAPI listing claimed
- [x] Postman workspace claimed
- [x] Product Hunt maker account created
- [x] LinkedIn page created

### ⏳ Waiting
- [ ] NCES email reply (1–2 weeks)

### 🔜 Next Up (see ROADMAP.md)
- [ ] Phase 0: Legal confirmation
- [ ] Phase 1: Data ingestion pipeline
- [ ] Phase 2: FastAPI layer
- [ ] Phase 3: Python SDK (replace placeholder)
- [ ] Phase 4: Developer portal on Vercel

---

## Tech Stack Decisions (Final)

All decisions are locked. See TECH-STACK.md for full detail.

| Layer | Choice | Why |
|-------|--------|-----|
| API Framework | FastAPI + Mangum | Python-native, auto-generates OpenAPI spec, runs on Lambda |
| Compute | AWS Lambda (arm64, 512MB) | Serverless, Gregory already uses AWS |
| API Gateway | AWS API Gateway v2 HTTP API | $1.00/million calls (71% cheaper than REST API) |
| Database | Supabase (PostgreSQL + PostGIS) | Managed Postgres, PostGIS for spatial queries, Auth, Row Level Security |
| Cache / Rate Limiting | Upstash Redis | Serverless Redis, $0.20/100K commands, 500K/mo free |
| Raw Data Storage | AWS S3 | $0.023/GB/month for raw county CSV files |
| Scheduler (ingest) | AWS EventBridge Scheduler | Triggers annual data refresh Lambdas |
| Auth | Supabase Auth | API key management + JWT |
| Billing | Stripe + Moesif | Usage-based metering |
| Developer Portal | Next.js on Vercel | Pro plan ($20/mo) — Hobby plan cannot be used commercially |
| DNS / CDN | Cloudflare | Already registered domains here; proxy API subdomain, grey-cloud Vercel subdomain |
| IaC | AWS SAM | Serverless Application Model for Lambda + API Gateway |

---

## Data Sources (All Free)

See DATA-SOURCES.md for full detail and download URLs.

### Primary: NCES Common Core of Data (CCD)
- **URL:** nces.ed.gov/ccd/files.asp
- **Format:** CSV/SAS, annual release
- **Contains:** School and district directory data, enrollment, staff counts, free/reduced lunch, fiscal data
- **Cost:** $0 — federal open data
- **Update cadence:** Annual (directory files August/September, full data December/January)
- **2024-25 data:** Released December 2025 — available now

### Geospatial: NCES EDGE Program
- **URL:** nces.ed.gov/programs/edge/
- **Contains:** Lat/lng for every school and district, school district boundary polygons
- **Format:** Shapefile, GeoJSON, CSV
- **Cost:** $0

### District Boundaries: Census TIGER
- **URL:** nces.ed.gov/programs/edge/Geographic/DistrictBoundaries
- **Contains:** Polygon boundaries for all ~13,000 school districts, updated annually
- **Format:** Shapefile (load into PostGIS)
- **Cost:** $0

### Supplemental: Urban Institute Education Data Explorer
- **URL:** educationdata.urban.org
- **Contains:** CCD data going back to 1980s, plus CRDC, IPEDS
- **Cost:** $0 — free API, no auth required
- **Use:** Reference implementation and historical data supplement

---

## Competitive Landscape Summary

See COMPETITIVE.md for full pricing tables.

| Competitor | Entry Price | Address→District | SDK | Free Tier |
|-----------|------------|-----------------|-----|-----------|
| SchoolDigger | $19.90/mo | $189/mo only | None | 20 calls/day |
| GreatSchools | $52.50/mo | Enterprise only | None | 14-day trial |
| Geocodio | Pay-per-use | Basic name only | Node (unofficial) | 2,500/day |
| Urban Institute | Free | None | None | Unlimited |
| **districtapi.dev** | **$0 (500/mo)** | **All tiers** | **Python + Node** | **500/mo forever** |

**The gap:** No product on the market offers address-to-district with full district profile (enrollment + demographics + schools list + boundary polygon) in a self-serve, SDK-backed, truly-free-to-start product.

---

## Pricing Model

| Tier | Price | Requests/Mo | Key Features |
|------|-------|-------------|-------------|
| Free | $0 | 500 | All endpoints, full schema, no card, no expiry |
| Starter | $29/mo | 10,000 | All endpoints, email support |
| Pro | $99/mo | 50,000 | Batch (100 records), webhooks |
| Growth | $299/mo | 200,000 | Batch (500), Slack support, SLA |
| Enterprise | Custom | Custom | White-label, raw data exports |
| Overage | $0.004/req | — | All paid tiers |

**Break-even:** 2 Starter customers ($58/mo) covers all infrastructure ($48-55/mo).

---

## API Design

See SCHEMA.md for full response schemas.

### Core Endpoints (MVP)
```
GET  /v1/districts          # by address, lat/lng, or NCES LEA ID
GET  /v1/districts/{id}     # by NCES LEA ID
GET  /v1/districts/{id}/schools
GET  /v1/districts/search   # by name, state, county
GET  /v1/schools            # by address, lat/lng radius, NCES ID
GET  /v1/schools/{id}
GET  /v1/schools/{id}/district
GET  /v1/health
```

### Response Envelope (every response)
```json
{
  "data": { },
  "meta": {
    "request_id": "req_abc123",
    "credits_used": 1,
    "credits_remaining": 499
  },
  "source": {
    "nces_year": "2024-25",
    "updated_at": "2025-12-01",
    "freshness_days": 112
  }
}
```

---

## PyPI Package Status

- **Package name:** `districtapi`
- **Current version:** `0.1.2` (placeholder — raises NotImplementedError)
- **Location:** pypi.org/project/districtapi
- **Repo:** github.com/districtapi/districtapi-python
- **Structure:** `src/districtapi/__init__.py` with version and placeholder
- **Next:** Replace with real SDK client when API is deployed

### Installing the placeholder
```bash
pip install districtapi
python -c "import districtapi; print(districtapi.__version__)"
# → 0.1.0
```

---

## Infrastructure Costs (Confirmed)

| Service | Cost | Notes |
|---------|------|-------|
| Supabase Free | $0 | Dev environment only — pauses if inactive |
| Supabase Pro | $25/mo | Production — no pausing, 8GB DB |
| AWS Lambda | ~$0–2/mo | 1M requests/mo free always |
| API Gateway HTTP | ~$0–1/mo | 1M calls free for 12 months |
| Upstash Redis Free | $0 | 500K commands/mo — sufficient early stage |
| Vercel Pro | $20/mo | Required for commercial use (Hobby ToS prohibits it) |
| Cloudflare | $0 | Free tier handles DNS + DDoS + CDN |
| S3 (raw data) | ~$1–2/mo | 50GB raw county CSV files |
| Domains | ~$21/yr total | districtapi.dev (~$10.44) + districtapi.com (~$9.15) |

**Total production monthly:** ~$48–55/mo at launch.

---

## Key Files in This Folder

```
CC-DistrictAPI/
├── CLAUDE.md           ← This file — read first
├── STATUS.md           ← Current task status and blockers
├── ROADMAP.md          ← Phased build plan with time estimates
├── TECH-STACK.md       ← Full technology decisions with rationale
├── DATA-SOURCES.md     ← Where data comes from, download URLs, field lists
├── COMPETITIVE.md      ← Full competitor pricing and feature comparison
└── SCHEMA.md           ← API response schemas and field definitions
```

---

## Working Conventions

- **Language:** Python 3.12 for all backend code
- **Style:** Follow FastAPI conventions; Pydantic models for all schemas
- **Naming:** snake_case for Python, camelCase for JSON responses (use `model_config = ConfigDict(alias_generator=to_camel)` in Pydantic)
- **Environment variables:** Never hardcode credentials; use `.env` locally, AWS SSM Parameter Store in production
- **Tests:** pytest; test all normalization logic before touching infrastructure
- **Git:** All work in `github.com/districtapi` org. Main repo is `districtapi-python` for SDK, `districtapi-api` for FastAPI backend
- **Commits:** Conventional commits format (`feat:`, `fix:`, `data:`, `docs:`)
