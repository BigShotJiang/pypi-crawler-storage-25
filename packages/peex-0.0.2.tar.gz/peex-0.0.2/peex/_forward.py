from typing import Any

import equinox as eqx

from ._hook import AbstractHook, IdentityHook
from ._log import AbstractLog, NoneLog

Result = Any
LogDict = dict


class ForwardHook(eqx.Module):
    """
    Wrap an Equinox module to add runtime hooks to the forward pass.

    !!! Note

    This function applies hooks for depth-1 sub-modules of `model`. A hook is
    applied before/after every sub-module call, but the internals of each
    sub-module are not traced.

    To add forward hooks to the internal evaluation of sub-modules themselves,
    you can simply wrap the sub-module call with `px.ForwardHook`. Be aware
    that a `px.ForwardHook` call cannot be nested inside another
    `px.ForwardHook` call.
    """

    model: eqx.Module
    hook_fn: AbstractHook
    log_fn: AbstractLog
    log: dict
    pre_hook: bool
    layer_names: list[str] | None

    def __init__(
        self,
        model: eqx.Module,
        hook_fn: AbstractHook = IdentityHook(),
        log_fn: AbstractLog = NoneLog(),
        log: dict = {},
        pre_hook: bool = False,
        layer_names: list[str] | None = None,
    ):
        """
        **Arguments**:
        - `model`: Equinox module to be wrapped
        - `hook_fn`: function to be applied pre/post each sub-module evaluation
        - `log_fn`: log function to be applied pre/post each sub-module evaluation
                    (applied after `hook_fn`)
        - `log`: existing log dictionary, defaults to `{}`
        - `pre_hook`: whether the hook should be applied pre sub-module evaluation,
                      defaults to False (post evaluation)
        - `layer_names`: list of sub-module names to evaluate the hook on,
                         defaults to None (all sub-modules)

        """

        self.model = model
        self.hook_fn = hook_fn
        self.log_fn = log_fn
        self.log = log
        self.pre_hook = pre_hook
        self.layer_names = layer_names

    def __call__(self, *args, **kwargs):
        """
        Evaluate the wrapped Equinox module.

        **Arguments:**
        - `*args`: arguments to original Equinox module
        - `**kwargs`: keyword arguments to original Equinox module

        **Returns:**
        - `result`: output of wrapped Equinox module
        - `log`: the log dictionary, `{"layer1": log_fn(...), ...}`
        """

        model = self.model
        hook_fn = self.hook_fn
        log_fn = self.log_fn
        pre_hook = self.pre_hook
        layer_names = self.layer_names

        # Create new log instance to avoid shared python object across hooks
        log = {**self.log}

        if layer_names is not None:
            for layer_name in layer_names:
                assert hasattr(model, layer_name), (
                    f"{model} does not have an attribute `{layer_name}`."
                )
                assert isinstance(getattr(model, layer_name), eqx.Module), (
                    f"`{layer_name}` is not an Equinox module."
                )

        class Hook:
            def __getattr__(self, name):
                val = getattr(model, name)
                if layer_names is not None:
                    if name not in layer_names:
                        return val

                if isinstance(val, eqx.Module) and hasattr(val, "__call__"):

                    def wrapped(*a, **kw):
                        if pre_hook:
                            a = hook_fn(a)
                            _log = log_fn(a)
                            result = val(*a, **kw)  # pyright: ignore
                        else:
                            result = val(*a, **kw)  # pyright: ignore
                            result = hook_fn(result)
                            _log = log_fn(result)

                        if _log is not None:
                            log[name] = _log

                        return result

                    return wrapped
                return val

        result = type(model).__call__(Hook(), *args, **kwargs)
        return result, log
