from abc import abstractmethod

import equinox as eqx
import jax.numpy as jnp
import jax.tree_util as jtu


class AbstractLog(eqx.Module):
    """Base class for all logs.

    A `log_fn` can return an output with any shape/dtype. The only
    requirement is that it accepts the correct input shapes/dtypes:

    - with `pre_hook=True`, `args` are always a `tuple`.
    - with `pre_hook=False`, `args = module(input)`.
    """

    @abstractmethod
    def __call__(self, args):
        pass


class NoneLog(AbstractLog):
    def __call__(self, args):
        return None


class IdentityLog(AbstractLog):
    def __call__(self, args):
        return args


class MeanLog(AbstractLog):
    def __call__(self, args):
        return jtu.tree_map(lambda x: jnp.mean(x), args)


class MeanStdLog(AbstractLog):
    def __call__(self, args):
        mean = jtu.tree_map(lambda x: jnp.mean(x), args)
        std = jtu.tree_map(lambda x: jnp.std(x), args)
        return mean, std
