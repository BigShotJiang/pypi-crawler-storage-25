from typing import Any

import equinox as eqx
import jax.numpy as jnp
import jax.tree_util as jtu

from ._hook import AbstractHook, IdentityHook
from ._log import AbstractLog, NoneLog

Result = Any
LogDict = dict


def _tree_zeros(tree):
    return jtu.tree_map(jnp.zeros_like, tree)


def _eval_hook(model, hook_fn, log_fn, log, pre_hook, layer_names, *args, **kwargs):
    if layer_names is not None:
        for layer_name in layer_names:
            assert hasattr(model, layer_name), (
                f"{model} does not have an attribute `{layer_name}`."
            )
            assert isinstance(getattr(model, layer_name), eqx.Module), (
                f"`{layer_name}` is not an Equinox module."
            )

    class Hook:
        def __getattr__(self, name):
            val = getattr(model, name)
            if layer_names is not None:
                if name not in layer_names:
                    return val

            if isinstance(val, eqx.Module) and hasattr(val, "__call__"):

                def wrapped(*a, **kw):
                    if pre_hook:
                        _log = log.get(name, log_fn(_tree_zeros(a)))
                        a = _hook_and_log_fn((a, _log), hook_fn, log_fn)
                        result = val(*a, **kw)  # pyright: ignore

                    else:
                        result = val(*a, **kw)  # pyright: ignore
                        _log = log.get(name, log_fn(_tree_zeros(result)))
                        result = _hook_and_log_fn((result, _log), hook_fn, log_fn)

                    if _log is not None:
                        log[name] = _log

                    return result

                return wrapped
            return val

    result = type(model).__call__(Hook(), *args, **kwargs)
    return result, log


class BackwardHook(eqx.Module):
    """
    Wrap an Equinox module to add gradient hooks to the backward pass.

    !!! Example

    To ensure gradient logging is achieved functionally without side-effects, we
    must return the gradient log as a gradient itself,

    ```python
    @eqx.filter_grad
    def grad_loss(model, x):
        return model(x)

    model = ...  # some equinox module
    x = ...  # inputs

    hooked_model = px.BackwardHook(model, log_fn=px.IdentityLog())
    hooked_model = hooked_model.init(x)

    grads = grad_loss(hooked_model, x)  # grads is a px.BackwardHook object
    gradient_model = grads.model  # original model gradients
    gradient_log = grads.log  # logging dictionary
    ```

    !!! Note

    This function applies hooks for depth-1 sub-modules of `model`. A hook is
    applied before/after every sub-module backward pass, but the internals of each
    sub-module backward pass are not traced.

    To add backward hooks to the internal backward pass of sub-modules themselves,
    you can simply wrap the sub-module with `px.BackwardHook`. Be aware that a
    `px.BackwardHook` call cannot be nested inside another `px.BackwardHook` call.
    """

    model: eqx.Module
    hook_fn: AbstractHook
    log_fn: AbstractLog
    log: dict
    pre_hook: bool
    layer_names: list[str] | None

    def __init__(
        self,
        model: eqx.Module,
        hook_fn: AbstractHook = IdentityHook(),
        log_fn: AbstractLog = NoneLog(),
        log: dict = {},
        pre_hook: bool = False,
        layer_names: list[str] | None = None,
    ):
        """
        **Arguments**:
        - `model`: Equinox module to be wrapped
        - `hook_fn`: function to be applied before/after each sub-module backward pass
        - `log_fn`: log function to be applied before/after each sub-module backward pass
                    (applied after `hook_fn`)
        - `log`: existing log dictionary, defaults to `{}`
        - `pre_hook`: whether the hook should be applied pre sub-module evaluation,
                      defaults to False (post evaluation)
        - `layer_names`: list of sub-module names to evaluate the hook on,
                         defaults to None (all sub-modules)

        **Returns:**
        - `result`: output of original Equinox module

        !!! Note
        The `pre_hook` argument is ordered with respect to the forward pass. That is,
        `pre_hook=True` means that the `hook_fn` is applied after the sub-module
        backward pass.
        """

        self.model = model
        self.hook_fn = hook_fn
        self.log_fn = log_fn
        self.log = log
        self.pre_hook = pre_hook
        self.layer_names = layer_names

    def init(self, *args, **kwargs):
        _, log_shapes = eqx.filter_eval_shape(
            _eval_hook,
            self.model,
            self.hook_fn,
            self.log_fn,
            self.log,
            self.pre_hook,
            self.layer_names,
            *args,
            **kwargs,
        )
        log = _tree_zeros(log_shapes)
        return BackwardHook(
            self.model, self.hook_fn, self.log_fn, log, self.pre_hook, self.layer_names
        )

    def __call__(self, *args, **kwargs):
        result, _ = _eval_hook(
            self.model,
            self.hook_fn,
            self.log_fn,
            self.log,
            self.pre_hook,
            self.layer_names,
            *args,
            **kwargs,
        )
        return result


@eqx.filter_custom_vjp
def _hook_and_log_fn(vjp_args, hook_fn, log_fn):
    del hook_fn, log_fn
    vjp_args, _log = vjp_args
    return vjp_args


@_hook_and_log_fn.def_fwd
def _hook_and_log_fn_fwd(perturbed, vjp_args, hook_fn, log_fn):
    del perturbed, hook_fn, log_fn
    vjp_args, _log = vjp_args
    return vjp_args, None


@_hook_and_log_fn.def_bwd
def _hook_and_log_fn_bwd(
    residuals, grad_vjp_args, perturbed, vjp_args, hook_fn, log_fn
):
    del residuals, perturbed, vjp_args
    grad_vjp_args = hook_fn(grad_vjp_args)
    log_grad = log_fn(grad_vjp_args)
    return (grad_vjp_args, log_grad)
