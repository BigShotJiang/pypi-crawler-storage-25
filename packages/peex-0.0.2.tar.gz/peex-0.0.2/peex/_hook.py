from abc import abstractmethod

import equinox as eqx


class AbstractHook(eqx.Module):
    """Base class for all hooks.

    The defining rule of a `hook_fn` is that the output shapes/dtypes
    exactly match their input shapes/dtypes:

    - with `pre_hook=True`, `args` are always a `tuple`.
    - with `pre_hook=False`, `args = module(input)`.
    """

    @abstractmethod
    def __call__(self, args):
        pass


class IdentityHook(AbstractHook):
    def __call__(self, args):
        return args
