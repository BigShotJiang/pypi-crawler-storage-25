"""
torrensearch Discord bot.

Run:
  DISCORD_TOKEN=your_token_here uv run torrensearch-bot
"""

import asyncio
import os
import sys
from typing import Any

import discord
from torrensearch import CATEGORIES, init_config, search

_TOKEN = os.environ.get("DISCORD_TOKEN", "")

_PAGE_SIZE = 10

intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

# per-user session: {user_id: {"results": [...], "query": str, "page": int}}
_sessions: dict[int, dict[str, Any]] = {}


def _fmt_results(results: list[dict[str, Any]], page: int, total: int) -> str:
    start = page * _PAGE_SIZE
    chunk = results[start : start + _PAGE_SIZE]
    lines = ["```", f"{'#':>3}  {'size':>8}  {'sd':>4}  {'engine':<14}  name", "─" * 60]
    for i, r in enumerate(chunk, start=start + 1):
        size = str(r.get("size", "?"))
        if size in ("-1", "", "None"):
            size = "?"
        seeds = r.get("seeds", -1)
        try:
            sd = int(seeds)
            sd_s = "?" if sd < 0 else str(sd)
        except (ValueError, TypeError):
            sd_s = "?"
        engine = str(r.get("_engine", "?"))[:14]
        name = str(r.get("name", "?"))
        lines.append(f"{i:>3}  {size:>8}  {sd_s:>4}  {engine:<14}  {name}")
    pages_total = (total + _PAGE_SIZE - 1) // _PAGE_SIZE
    lines.append("```")
    lines.append(f"Page {page + 1}/{pages_total} — {total} results total")
    lines.append(
        "Reply with a number to get the magnet link, or `!more` for the next page."
    )
    return "\n".join(lines)


def _parse_search_args(text: str) -> tuple[str, str, list[str] | None]:
    """Return (query, category, engines|None) from raw command text."""
    import shlex

    try:
        tokens = shlex.split(text)
    except ValueError:
        tokens = text.split()

    query_parts: list[str] = []
    cat = "all"
    engines: list[str] | None = None
    i = 0
    while i < len(tokens):
        t = tokens[i]
        if t == "--cat" and i + 1 < len(tokens):
            cat = tokens[i + 1]
            i += 2
        elif t == "--engines" and i + 1 < len(tokens):
            engines = [e.strip() for e in tokens[i + 1].split(",") if e.strip()]
            i += 2
        else:
            query_parts.append(t)
            i += 1
    query = " ".join(query_parts).strip()
    if cat not in CATEGORIES:
        cat = "all"
    return query, cat, engines


async def _do_search(message: discord.Message, text: str) -> None:
    query, cat, engines = _parse_search_args(text)
    if not query:
        await message.channel.send(
            "Usage: `!s <query> [--cat <cat>] [--engines e1,e2]`"
        )
        return

    await message.channel.send(f"Searching for **{query}**…")

    loop = asyncio.get_event_loop()
    results, errors = await loop.run_in_executor(None, search, query, engines, cat)

    if errors:
        err_text = "\n".join(f"⚠ {e}" for e in errors[:5])
        await message.channel.send(f"Some engines failed:\n```{err_text}```")

    if not results:
        await message.channel.send(f"No results found for **{query}**.")
        _sessions[message.author.id] = {"results": [], "query": query, "page": 0}
        return

    _sessions[message.author.id] = {"results": results, "query": query, "page": 0}
    await message.channel.send(_fmt_results(results, 0, len(results)))


@client.event
async def on_ready() -> None:
    print(f"Logged in as {client.user}", flush=True)


@client.event
async def on_message(message: discord.Message) -> None:
    if message.author == client.user:
        return
    if not isinstance(message.channel, discord.DMChannel):
        return

    content = message.content.strip()

    if content.lower() in ("!help", "help"):
        await message.channel.send(
            "**torrensearch bot**\n"
            "`!s <query>` — search torrents\n"
            "`!s <query> --cat <cat>` — filter by category\n"
            "`!s <query> --engines e1,e2` — use specific engines\n"
            "`!more` — next page of results\n"
            "`<number>` — get magnet link\n\n"
            f"Categories: {', '.join(sorted(CATEGORIES))}"
        )
        return

    if content.lower().startswith("!s ") or content.lower().startswith("!search "):
        prefix = "!s " if content.lower().startswith("!s ") else "!search "
        await _do_search(message, content[len(prefix) :].strip())
        return

    if content.lower() == "!more":
        session = _sessions.get(message.author.id)
        if not session or not session["results"]:
            await message.channel.send("No active search. Use `!s <query>` first.")
            return
        next_page = session["page"] + 1
        total = len(session["results"])
        max_page = (total + _PAGE_SIZE - 1) // _PAGE_SIZE - 1
        if next_page > max_page:
            await message.channel.send("No more pages.")
            return
        session["page"] = next_page
        await message.channel.send(_fmt_results(session["results"], next_page, total))
        return

    if content.isdigit():
        session = _sessions.get(message.author.id)
        if not session or not session["results"]:
            await message.channel.send("No active search. Use `!s <query>` first.")
            return
        idx = int(content) - 1
        if not 0 <= idx < len(session["results"]):
            await message.channel.send(
                f"Enter a number between 1 and {len(session['results'])}."
            )
            return
        r = session["results"][idx]
        name = str(r.get("name", "?"))
        link = str(r.get("link", ""))
        desc = str(r.get("desc_link", ""))
        reply = f"**{name}**\n```\n{link}\n```"
        if desc and desc != "-1":
            reply += f"\nInfo: {desc}"
        await message.channel.send(reply)
        return


def main() -> None:
    init_config()

    if not _TOKEN:
        print("error: DISCORD_TOKEN is not set", file=sys.stderr)
        sys.exit(1)

    client.run(_TOKEN)


if __name__ == "__main__":
    main()
