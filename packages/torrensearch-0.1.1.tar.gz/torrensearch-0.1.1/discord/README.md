# torrensearch-bot

> **Disclaimer:** This project is for educational purposes only. Use it only to search for content you have the legal right to access. The authors are not responsible for any misuse.

A private Discord bot that wraps `torrensearch`. Send it a DM, get a numbered list of torrent results, reply with a number to receive the magnet link.

## Prerequisites

- A Discord account
- Docker **or** Python 3.13+ with [uv](https://docs.astral.sh/uv/)

---

## 1. Create the Discord bot

### 1.1 New application

1. Go to [discord.com/developers/applications](https://discord.com/developers/applications)
2. Click **New Application**, give it a name (e.g. `torrensearch`)
3. Go to the **Bot** tab
4. Click **Add Bot** → confirm
5. Under **Token**, click **Reset Token**, copy and save it somewhere safe — this is your `DISCORD_TOKEN`

### 1.2 Enable the Message Content intent

Still on the **Bot** tab, scroll down to **Privileged Gateway Intents** and enable:

- **Message Content Intent** ✓

Without this the bot cannot read DM content.

### 1.3 Keep the bot private

On the **Bot** tab, make sure **Public Bot** is **off**. This prevents anyone else from adding it to their own server.

### 1.4 Add the bot to a server (required to unlock DMs)

Discord does not allow DMing a bot unless you share a server with it. Create a throwaway private server for yourself, then:

1. Go to **OAuth2 → URL Generator**
2. Scopes: `bot`
3. Bot Permissions: `Send Messages`, `Read Message History`
4. Open the generated URL and add the bot to your private server

You don't need to use that server — it just unlocks the DM channel.

---

## 2. Run the bot

### With Docker (recommended)

```bash
docker build -t torrensearch-bot .

docker run -d \
  --name torrensearch-bot \
  --restart unless-stopped \
  -e DISCORD_TOKEN=your_token_here \
  -v ~/.config/torrent-search:/config/torrent-search \
  torrensearch-bot
```

The `-v` mount persists configuration (including `jackett.json`) across container restarts.

### Without Docker

```bash
DISCORD_TOKEN=your_token_here uv run torrensearch-bot
```

---

## 3. Usage

Open a DM with the bot on Discord.

### Search

```console
!s <query>
!search <query>
```

Returns the top 10 results sorted by seeders.

```console
!s ubuntu 22.04
!s breaking bad --cat tv
!s arch linux --engines piratebay,torrentscsv
!s the matrix --cat movies --engines piratebay
```

### Get a magnet link

After a search, reply with the result number:

```console
3
```

The bot responds with the full magnet link.

### More results

```console
!more
```

Fetches the next page of 10 results from the last search.

### Help

```console
!help
```

### Options

| Flag        | Example                    | Description               |
| ----------- | -------------------------- | ------------------------- |
| `--cat`     | `--cat movies`             | Filter by category        |
| `--engines` | `--engines piratebay,eztv` | Use specific engines only |

**Available categories:** `all`, `anime`, `books`, `games`, `movies`, `music`, `software`, `tv`

### Example session

```console
you  → !s ubuntu 22.04 --cat software

bot  →  #       size   sd  engine        name
       ────────────────────────────────────────────────────────────
        1    4.6 GB  312  piratebay     ubuntu-22.04.3-desktop-amd64.iso
        2    1.8 GB  241  torrentscsv   Ubuntu 22.04.3 LTS Server
        3    3.9 GB   98  limetorrents  Ubuntu 22.04 LTS Jammy x86_64
       ...
       Page 1/5 — 47 results total

       Reply with a number to get the magnet link, or !more for the next page.

you  → 1

bot  → ubuntu-22.04.3-desktop-amd64.iso
       ```
       magnet:?xt=urn:btih:...
       ```
       Info: https://thepiratebay.org/description.php?id=...
```

---

## 4. Jackett integration

To search private or additional public trackers, configure the Jackett engine. See the [Jackett section in README.md](README.md#jackett) for full setup instructions.

Once Jackett is running and configured, include it in your search:

```console
!s linux mint --engines jackett
```

The config file is shared between the CLI and the bot:

```console
~/.config/torrent-search/jackett.json
```

When using Docker, this file lives in the mounted volume at:

```console
~/.config/torrent-search/jackett.json   ← on the host
/config/torrent-search/jackett.json     ← inside the container
```

---

## 5. Security notes

- **Never share your bot token.** Anyone with it can run the bot as you.
- **Rotate a leaked token immediately** in the Discord Developer Portal (Bot tab → Reset Token).
- Magnet links are sent only in the DM thread between you and the bot — no other users can see them.
- Search queries transit Discord's servers. For fully private searches, run the CLI locally instead.
