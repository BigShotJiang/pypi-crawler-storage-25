import os
import sys
import tiktoken


SKIP_DIRS = {
    ".git", ".hg", ".svn",
    "node_modules", "__pycache__", ".venv", "venv", "env",
    ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "dist", "build", ".eggs",
}


def is_skippable_dir(name):
    return name.startswith(".") or name in SKIP_DIRS


def is_binary(path):
    try:
        with open(path, "rb") as f:
            return b"\x00" in f.read(8192)
    except PermissionError:
        return True


def format_tokens(n):
    if n >= 1_000_000:
        return f"{n/1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n/1_000:.1f}K"
    return str(n)


def run():
    target = sys.argv[1] if len(sys.argv) > 1 else "."

    if not os.path.exists(target):
        print(f"error: path '{target}' does not exist")
        sys.exit(1)

    enc = tiktoken.get_encoding("cl100k_base")
    this_file = os.path.abspath(__file__)

    results = []
    skipped_binary = 0
    skipped_permission = 0

    print(f"\nscanning {os.path.abspath(target)} ...\n")

    for root, dirs, files in os.walk(target):
        dirs[:] = [d for d in dirs if not is_skippable_dir(d)]

        for file in sorted(files):
            path = os.path.abspath(os.path.join(root, file))

            if path == this_file:
                continue

            if os.path.islink(path) and not os.path.exists(path):
                skipped_binary += 1
                continue

            if is_binary(path):
                skipped_binary += 1
                continue

            rel_path = os.path.relpath(path, target)

            try:
                text = open(path, encoding="utf-8").read()
                tokens = len(enc.encode(text))
                lines = text.count("\n") + (1 if text and not text.endswith("\n") else 0)
                results.append((rel_path, tokens, lines))
            except UnicodeDecodeError:
                skipped_binary += 1
            except PermissionError:
                skipped_permission += 1

    if not results:
        print("no readable files found.")
        return

    results.sort(key=lambda x: x[1], reverse=True)

    max_len = min(max(len(r[0]) for r in results), 60)

    print(f"  {'file':<{max_len}}  {'tokens':>8}         {'lines':>8}")
    print(f"  {'─' * max_len}  {'─' * 8}  {'─' * 8}")

    for rel_path, tokens, lines in results:
        display_path = rel_path if len(rel_path) <= 60 else "..." + rel_path[-57:]
        print(f"  {display_path:<{max_len}}  {format_tokens(tokens):>8}  {lines:>8}")

    total_tokens = sum(t for _, t, _ in results)
    total_lines  = sum(l for _, _, l in results)

    sep = '─' * (max_len + 22)
    print(f"\n{sep}")
    print(f"  {'TOTAL':<{max_len}}  {format_tokens(total_tokens):>8} tokens  {total_lines:>8} lines")
    print(f"  {'files':<{max_len}}  {len(results):>8}")

    if skipped_binary > 0:
        print(f"  {'skipped (binary)':<{max_len}}  {skipped_binary:>8}")
    if skipped_permission > 0:
        print(f"  {'skipped (permission)':<{max_len}}  {skipped_permission:>8}")
    print(sep)

    print()


if __name__ == "__main__":
    run()