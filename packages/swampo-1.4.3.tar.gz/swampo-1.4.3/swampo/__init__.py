"""Swampo - The most complete skill pack for Claude Code."""

__version__ = "1.4.3"
