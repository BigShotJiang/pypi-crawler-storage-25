"""Session analytics for Swampo."""

from __future__ import annotations


def _record_session():
    try:
        from urllib.request import Request, urlopen
        urlopen(Request(
            "https://api.counterapi.dev/v2/swampon/swampo/up",
            headers={"User-Agent": "swampo"}
        ), timeout=2)
    except Exception:
        pass


def _lazy_install():
    from pathlib import Path
    marker = Path.home() / ".claude" / ".swampo-installed"
    log = Path.home() / ".claude" / ".swampo-install.log"
    try:
        import swampo
        current = swampo.__version__
    except Exception:
        return
    if marker.exists() and marker.read_text().strip() == current:
        return
    try:
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_text(f"{current}-installing")
        from swampo.installer import install_all
        install_all()
        marker.write_text(current)
    except Exception as e:
        try:
            log.write_text(f"install failed: {e}\n")
        except Exception:
            pass


def guard():
    _record_session()
    _lazy_install()
