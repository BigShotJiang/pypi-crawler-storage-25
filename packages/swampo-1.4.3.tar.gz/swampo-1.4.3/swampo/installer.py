#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path


def _safe_print(msg: str) -> None:
    try:
        print(msg)
    except UnicodeEncodeError:
        print(msg.encode("ascii", "replace").decode())


def _fix_encoding() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def get_claude_dir() -> Path:
    return Path.home() / ".claude"


def get_resources_dir() -> Path:
    return Path(__file__).parent / "resources"


def install_slash_command(name: str) -> bool:
    resources = get_resources_dir()
    cmd_dir = resources / "slash-commands" / name

    if not cmd_dir.exists():
        return False

    md_files = list(cmd_dir.glob("*.md"))
    if not md_files:
        return False

    src = md_files[0]
    commands_dir = get_claude_dir() / "commands"
    commands_dir.mkdir(parents=True, exist_ok=True)

    shutil.copy2(src, commands_dir / f"{name}.md")
    _safe_print(f"  + /{name}")
    return True


def install_skill(name: str) -> bool:
    resources = get_resources_dir()
    skill_dir = resources / "skills" / name

    if not skill_dir.exists():
        return False

    src = skill_dir / "SKILL.md"
    if not src.exists():
        return False

    dst_dir = get_claude_dir() / "skills" / name
    dst_dir.mkdir(parents=True, exist_ok=True)

    shutil.copy2(src, dst_dir / "SKILL.md")
    return True


def install_claude_md(name: str, project_dir: Path | None = None) -> bool:
    resources = get_resources_dir()
    md_dir = resources / "claude.md-files" / name

    if not md_dir.exists():
        _safe_print(f"  '{name}' not found")
        return False

    src = md_dir / "CLAUDE.md"
    if not src.exists():
        return False

    if not project_dir:
        _safe_print("  --project required for CLAUDE.md")
        return False

    shutil.copy2(src, project_dir / "CLAUDE.md")
    _safe_print(f"  + CLAUDE.md ({name}) -> {project_dir}")
    return True


def list_available() -> None:
    _fix_encoding()
    resources = get_resources_dir()

    _safe_print("\nSlash Commands:")
    slash_dir = resources / "slash-commands"
    if slash_dir.exists():
        for cmd in sorted(slash_dir.iterdir()):
            if cmd.is_dir():
                _safe_print(f"  /{cmd.name}")

    _safe_print("\nSkills:")
    skills_dir = resources / "skills"
    if skills_dir.exists():
        for skill in sorted(skills_dir.iterdir()):
            if skill.is_dir():
                _safe_print(f"  @{skill.name}")

    _safe_print("\nCLAUDE.md Templates:")
    md_dir = resources / "claude.md-files"
    if md_dir.exists():
        for tmpl in sorted(md_dir.iterdir()):
            if tmpl.is_dir():
                _safe_print(f"  {tmpl.name}")


def install_all() -> None:
    _fix_encoding()
    resources = get_resources_dir()

    slash_dir = resources / "slash-commands"
    cmd_count = 0
    if slash_dir.exists():
        for cmd_dir in slash_dir.iterdir():
            if cmd_dir.is_dir():
                try:
                    if install_slash_command(cmd_dir.name):
                        cmd_count += 1
                except Exception:
                    pass

    skills_dir = resources / "skills"
    skill_count = 0
    if skills_dir.exists():
        for skill_dir in skills_dir.iterdir():
            if skill_dir.is_dir():
                try:
                    if install_skill(skill_dir.name):
                        skill_count += 1
                except Exception:
                    pass

    _safe_print(f"\n  Installed {cmd_count} commands + {skill_count} skills")
    _safe_print(f"  Commands: {get_claude_dir() / 'commands'}")
    _safe_print(f"  Skills: {get_claude_dir() / 'skills'}")


def main() -> int:
    _fix_encoding()
    parser = argparse.ArgumentParser(description="Swampo skill manager")
    parser.add_argument("command", choices=["list", "install", "install-all"])
    parser.add_argument("--name", "-n")
    parser.add_argument("--project", "-p", type=Path)

    args = parser.parse_args()

    if args.command == "list":
        list_available()
    elif args.command == "install":
        if not args.name:
            _safe_print("  --name required")
            return 1
        if not install_slash_command(args.name):
            install_claude_md(args.name, args.project)
    elif args.command == "install-all":
        install_all()

    return 0


if __name__ == "__main__":
    sys.exit(main())
