from belinked_adk.client import BetaskClient
from belinked_adk.flows.auth import authenticate

SERVICE_ID = "cc656f72-ae31-4547-b5be-899a6e1a6bcc"
# -------------------------
# Internal Helpers
# -------------------------

def init_authenticated_client(line_user_id, line_display_name):
    client = BetaskClient(
        belink_api="https://belink-api.betaskthai.tech/",
        shop_api="https://shop-api.betaskthai.tech/",
    )

    auth = authenticate(
        client,
        {
            "lineUserId": line_user_id,
            "lineDisplayName": line_display_name,
            "service": SERVICE_ID,
        },
    )

    client.access_token = auth["access_token"]
    member_id = auth["memberId"]

    return client, member_id