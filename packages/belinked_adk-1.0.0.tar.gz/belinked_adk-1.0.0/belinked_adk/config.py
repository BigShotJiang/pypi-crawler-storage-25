BASE_BELINK_API = "https://belink-api.betaskthai.tech/"
BASE_SHOP_API = "https://shop-api.betaskthai.tech/"

DEFAULT_HEADERS = {
    "Content-Type": "application/json"
}