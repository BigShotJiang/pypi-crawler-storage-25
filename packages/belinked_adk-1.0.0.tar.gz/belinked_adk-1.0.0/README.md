# BeLinked ADK - AI Booking Tools

BeLinked ADK is a Python toolkit for building AI-powered booking agents.  
It provides ready-to-use tools for browsing services, selecting branches, and creating appointments in a structured and testable way.

This package is designed to work with agent frameworks such as Google ADK, enabling developers to build conversational booking experiences quickly.

---

## 🚀 Features

- Retrieve available branches
- Browse services by branch
- Create appointments with validation
- Support chat-driven booking flows
- Compatible with AI agent frameworks (Google ADK, etc.)

---

## 🧠 Use Case

Developers can build AI agents that handle booking workflows end-to-end:

1. User asks for a service (e.g., haircut)
2. Agent suggests available branches
3. Agent lists services for the selected branch
4. Agent collects date and time
5. Agent completes the booking

---

## 📦 Installation

```bash
pip install belinked-adk