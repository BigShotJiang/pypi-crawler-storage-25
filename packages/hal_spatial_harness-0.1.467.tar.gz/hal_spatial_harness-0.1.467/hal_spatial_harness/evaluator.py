# ================= STANDARD LIB =================
import os
import re
import json
import shutil
from pathlib import Path
from itertools import combinations
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed

# ================= DATA =================
import numpy as np
import pandas as pd

# ================= ML / STATS =================
from scipy.stats import chi2
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import MultiLabelBinarizer

# ================= DEEP LEARNING =================
import torch
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModel

# ================= EMBEDDING / CLUSTERING =================
import umap
import hdbscan

# ================= UTILITIES =================
from alive_progress import alive_bar

# ================= API =================
from openai import OpenAI


structured_signal_scoring_prompt_template = """
You are an expert evaluation agent for spatial reasoning tasks. Your job is to rigorously evaluate a model's response.

Return ONLY a valid JSON object. Do NOT include any explanation, markdown, or extra text.

================ INPUT ================

Question: {question}

Ground Truth Answer: {ground_truth}

Model Response: {model_output}


================ INSTRUCTIONS ================

Follow these rules strictly:

1. Accuracy Score (0/1):
- 1 if the final answer is correct.
- 0 otherwise.
- For OE: use semantic equivalence.

2. Refusal Score (0/1):
- 1 if the model refuses (e.g., "I cannot answer", "insufficient information").
- 0 otherwise.

3. Off Topic Score (0/1):
- 1 if response is irrelevant.
- 0 if relevant.

4. Extract Reasoning:
- Extract and summarize the reasoning steps for the Score.

5. Spatial Elements Score (0/1):
- 1 if key spatial objects/entities are correctly identified.
- 0 otherwise.

6. Spatial Relations Score (0/1):
- 1 if spatial relations (left/right/above/below/etc.) are correct.
- 0 otherwise.

7. Spatial Reasoning Score (0/1):
- 1 if logical spatial reasoning is correct.
- 0 otherwise.

================ OUTPUT FORMAT ================

Return STRICT JSON only (no trailing commas, no Python types, use null not None):


{{
  "accuracy_score": 0,
  "refusal_score": 0,
  "off_topic_score": 0,
  "extracted_reasoning": "",
  "spatial_elements_score": 0,
  "spatial_relations_score": 0,
  "spatial_reasoning_score": 0
}}


"""

error_taxonomies_prompt_template="""
You are an expert error taxonomy classifier for spatial reasoning models.

You will be given a set of clustered model failures. Your task is to assign each cluster to exactly ONE primary error type from a fixed taxonomy.

Return ONLY valid JSON. Do NOT include explanation, markdown, or extra text.

================ FIXED ERROR TAXONOMY =================

{error_taxonomies}

================ INPUT =================

Cluster ID: {cluster_id}

Cluster Examples:
{list_of_failure_samples}

================ TASK =================

1. Carefully analyze the cluster behavior.
2. Identify the SINGLE best matching error type.
3. Do NOT assign multiple labels.
4. Prefer the dominant failure mode in the cluster.

================ OUTPUT FORMAT =================

Return STRICT JSON only (no trailing commas, no Python types, use null not None):

{{
  "cluster_id": "{cluster_id}",
  "error_type": "",
  "error_name": "string label of selected type"
}}

"""



def bootstrap_ci(scores_lst, n_bootstrap=1000, alpha=0.05):
    """
    y_true: ground truth labels
    y_pred: model predictions
    metric_fn: function(y_true, y_pred) -> scalar metric (e.g., accuracy)
    """

    scores = []
    n = len(scores_lst)

    for _ in range(n_bootstrap):
        idx = np.random.randint(0, n, n)  # bootstrap sample

        score = np.array(scores_lst)[idx]
        
        scores.append(score)

    scores = np.array(scores)

    lower = np.percentile(scores, 100 * alpha / 2)
    upper = np.percentile(scores, 100 * (1 - alpha / 2))
    mean = np.mean(scores)

    return {
        "mean": mean,
        "ci_lower": lower,
        "ci_upper": upper,
        "std": np.std(scores)
    }



def get_client():
    OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
    OPEN_ROUTER_API_KEY = os.environ.get("OPEN_ROUTER_API_KEY")
    if OPEN_ROUTER_API_KEY:
        return OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=OPEN_ROUTER_API_KEY
        )
    elif OPENAI_API_KEY:
        return OpenAI(api_key=OPENAI_API_KEY)
    else:
        raise ValueError("No API key found. Set OPENAI_API_KEY or OPEN_ROUTER_API_KEY.")
        



# ================= COHEN'S D =================
def cohens_d(x, y):
    x, y = np.asarray(x), np.asarray(y)

    nx, ny = len(x), len(y)
    sx, sy = np.var(x, ddof=1), np.var(y, ddof=1)
 
    pooled = np.sqrt(((nx - 1) * sx + (ny - 1) * sy) / (nx + ny - 2))
    return (np.mean(x) - np.mean(y)) / pooled if pooled != 0 else 0.0


# ================= MCNEMAR TEST =================
def mcnemar_test(x, y):
    x, y = np.asarray(x), np.asarray(y)

    b = np.sum((x == 1) & (y == 0))
    c = np.sum((x == 0) & (y == 1))

    if b + c == 0:
        return 0.0, 1.0

    stat = (abs(b - c) - 1) ** 2 / (b + c)
    p = 1 - chi2.cdf(stat, df=1)

    return stat, p


# ================= FULL PIPELINE =================
def full_pairwise_evaluation(model_dfs, score_col="score"):
    """
    model_dfs: dict {model_name: dataframe}
    score_col: must be binary (0/1) for McNemar
    """

    models = list(model_dfs.keys())
    pairs = list(combinations(models, 2))

    m = len(pairs)
    bonf_alpha = 0.05 / m  # numeric Bonferroni threshold

    results = []

    for m1, m2 in pairs:
        m1_df=model_dfs[m1]
        m2_df=model_dfs[m2]
        m1_df = m1_df[m1_df["id"].isin(m2_df["id"])]
        m2_df = m2_df[m2_df["id"].isin(m1_df["id"])]
        x =m1_df[score_col]
        y = m2_df[score_col]

        # McNemar
        mcn_stat, mcn_p = mcnemar_test(x, y)

        # Cohen's d
        d = cohens_d(x, y)

        results.append({
            "model_1": m1,
            "model_2": m2,
            "mcnemar_stat": mcn_stat,
            "mcnemar_p": mcn_p,
            "cohens_d": d,
            "bonferroni_alpha": bonf_alpha,
            "significant": mcn_p < bonf_alpha
        })

    df = pd.DataFrame(results)

    # ================= REVERSE PAIRS =================
    rev = df.copy()

    rev[["model_1", "model_2"]] = rev[["model_2", "model_1"]]

    # flip Cohen's d sign
    rev["cohens_d"] = -rev["cohens_d"]

    # McNemar symmetric
    rev["mcnemar_stat"] = rev["mcnemar_stat"]
    rev["mcnemar_p"] = rev["mcnemar_p"]
    rev["significant"] = rev["significant"]

    return pd.concat([df, rev], ignore_index=True)





# ================= MEAN POOLING =================
def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output.last_hidden_state
    mask = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * mask, dim=1) / torch.clamp(mask.sum(dim=1), min=1e-9)

# ================= EMBEDDING FUNCTION =================


model_name = "intfloat/e5-large-v2"
token = os.environ.get("HF_TOKEN", None)
device = "cuda" if torch.cuda.is_available() else "cpu"

tokenizer = AutoTokenizer.from_pretrained(model_name, token=token)
model = AutoModel.from_pretrained(model_name, token=token).to(device)
model.eval()


def get_embeddings(texts, batch_size=32):
    
    all_embeddings = []
    batches = [texts[i:i+batch_size] for i in range(0, len(texts), batch_size)]

    with alive_bar(len(batches),
                   title="Generating Embeddings",
                   bar='blocks',
                   spinner='dots') as bar:

        for batch in batches:
            # E5 prefix
            batch = [f"query: {t}" for t in batch]

            inputs = tokenizer(
                batch,
                padding=True,
                truncation=True,
                return_tensors="pt"
            ).to(device)

            with torch.no_grad():
                outputs = model(**inputs)

            emb = mean_pooling(outputs, inputs["attention_mask"])
            emb = F.normalize(emb, p=2, dim=1)

            all_embeddings.append(emb.cpu())

            bar()  # ✅ update per batch

    return torch.cat(all_embeddings, dim=0).numpy()





# ================= 3. HDBSCAN TUNING (WITH PROGRESS) =================
def tune_hdbscan(X, cluster_sizes=[15, 20, 30, 40, 50]):
    best_score = -1
    best_labels = None
    best_model = None
    best_k = None

    with alive_bar(len(cluster_sizes), title="Tuning HDBSCAN") as bar:
        for k in cluster_sizes:

            if k >= len(X):  # invalid setting
                bar()
                continue

            clusterer = hdbscan.HDBSCAN(
                min_cluster_size=k,
                metric='euclidean',
                cluster_selection_method='eom'
            )

            labels = clusterer.fit_predict(X)

            # remove noise
            mask = labels != -1

            # need at least 2 clusters after filtering
            if len(set(labels[mask])) < 2:
                bar()
                continue

            try:
                score = silhouette_score(X[mask], labels[mask])
            except:
                bar()
                continue

            if score > best_score:
                best_score = score
                best_labels = labels
                best_model = clusterer
                best_k = k

            bar()

    return best_model, best_labels, best_k, best_score






def json_parser(json_text):
    try:
        return json.loads(re.search(r"\{.*\}", json_text, re.S).group())
    except Exception as e:
        print(f"Error {e}")
        print(json_text)
    





def process_row_for_signal_extraction(row,model_name):

    max_retry=5
    retry_count=0
    while retry_count<max_retry:
        client = get_client()
        
        try:
            
            if row["question_type"] == "MCQ":
                correct_answer = row["correct_option"].strip().lower()
                model_answer = row["response"].strip().lower()
    
                row["score"] = 1 if correct_answer == model_answer else 0
                row["pattern_score"] = 1 if (len(model_answer) == 1) else 0
                return row
    
            else:
                correct_answer = row["answer"]
                model_answer = row["response"]
                question = row["question"]
    
    
                prompt = structured_signal_scoring_prompt_template.format(
                    question=question,
                    ground_truth=correct_answer,
                    model_output=model_answer
                )
    
                content = [{"type": "text", "text": prompt}]
    
                response = client.chat.completions.create(
                    model=model_name,
                    messages=[{"role": "user", "content": content}],
                    temperature=0.1,
                    max_tokens=1000,
                )
                res = json_parser(response.choices[0].message.content) if response else {}
                
                return {**row, **res}
    
        except Exception as e:
            retry_count+=1
            if retry_count==max_retry:
                print(f"Error: {e}")
                return row  # return original row if failure

def structured_signal_extraction(csv_path,model_name="google/gemini-3.1-flash-image-preview",max_concurrent=10):
    save_path=(Path(csv_path.parent))
    

    
    df=pd.read_csv(csv_path)[:1000]
    ds= df.to_dict(orient="records")
    model=str(save_path).split("/")[-1]

    print(f"Scoring {model}")
    results = []

    with ThreadPoolExecutor(max_workers=max_concurrent) as executor:
        futures = [executor.submit(process_row_for_signal_extraction, row,model_name ) for row in ds]
    
        with alive_bar(len(futures), bar='blocks', spinner='dots',
                       title='Scoring Agent Response', force_tty=True) as bar:
    
            for future in as_completed(futures):
                results.append(future.result())
                pd.DataFrame(results).to_csv(save_path/"agent_scores.csv",index=False)
                bar()

    pd.DataFrame(results).to_csv(save_path/"agent_scores.csv",index=False)

def error_taxonomy_induction(csv_path,error_taxonomies,model_name="google/gemini-3.1-flash-image-preview",):
    df=pd.read_csv(csv_path)

    df["combined_text"] = (
        df["question"] + "\n" +
        df["answer"] + "\n" +
        df["response"]
    )
    # ================= 1. EMBEDDING =================
    embeddings = get_embeddings(df["combined_text"].tolist())

    
    # ================= 2. UMAP REDUCTION =================
    reduced = umap.UMAP(
        n_neighbors=min(15, len(df) - 1),
        n_components=min(10, len(df) - 2),
        metric='cosine',
        random_state=42,
        verbose=False  
    ).fit_transform(embeddings)

    
    
    clusterer, labels, best_k, best_score = tune_hdbscan(reduced)

    print(f"Best Cluster Size for HDBSCAN: {best_k}")
    print(f"Best Silhouette score : {best_score:.4f}")
    
    # ================= 5. ATTACH RESULTS =================
    df["cluster"] = labels
    
    # optional
    df["is_noise"] = df["cluster"] == -1

    clusters=df["cluster"].unique()
    cluster_mapping={} 
    for cluster in clusters:
        question_samples=df[df["cluster"]==cluster]["question"].tolist()
        
        prompt = error_taxonomies_prompt_template.format(
            list_of_failure_samples=question_samples,
            cluster_id=cluster,
            error_taxonomies=error_taxonomies
        )
        
        client = get_client()

        content = [{"type": "text", "text": prompt}]
        retry_count = 0
        max_retry = 3
        
        while retry_count < max_retry:
            try:
                response = client.chat.completions.create(
                    model=model_name,
                    messages=[{"role": "user", "content": content}],
                    temperature=0.1,
                    max_tokens=250,
                )
        
                res = json_parser(response.choices[0].message.content.strip()) if response else {}
                cluster_mapping[cluster] = res.get("error_type")
        
                break  # ✅ success → exit loop
        
            except Exception as e:
                retry_count += 1
        
                if retry_count == max_retry:
                    print(f"❌ Failed after {max_retry} attempts for Cluster {cluster}: {e}")
                    cluster_mapping[cluster] = None  # fallback
                
    df["error_type"]=df["cluster"].map(cluster_mapping)
    df.to_csv(csv_path,index=False)
    


mlb = MultiLabelBinarizer()


def cross_model_diagnostic_synthesis(csv_paths,save_dir):
    model_evals={}
    model_dfs={}
    error_types = set()
    model_dfs = {}
    model_evals = {}
    
    for csv_path in csv_paths:
        df = pd.read_csv(csv_path)
    
        model_name = str(csv_path.parent).split("/")[-1]
    
        df = df[df["error_type"].notna()].copy()
        df["error_type"] = df["error_type"].apply(lambda x: [x] if isinstance(x, str) else [])
    
        error_types.update(df["error_type"].explode().dropna().unique())
    
        mlb = MultiLabelBinarizer()
    
        dummies = pd.DataFrame(
            mlb.fit_transform(df["error_type"]),
            columns=mlb.classes_,
            index=df.index
        )
    
        df = pd.concat([df, dummies], axis=1)
    
        res = {}
        res["bootstrap_ci"] = bootstrap_ci(df["score"], n_bootstrap=500, alpha=0.05)
        res["error_types"] = list(mlb.classes_)  # cleaner than recomputing
    
        model_evals[model_name] = res
        model_dfs[model_name] = df
    
    # final global list
    error_types = list(error_types)


    for error_type in error_types:
        model_evals[model_name][error_type]={}
    
    for error_type in error_types:
        selected_models=[model for model , value in model_evals.items() if error_type in value["error_types"]  ]
        
        selected_model_dfs = {k: v for k, v in model_dfs.items() if k in selected_models}
        
        if len(selected_model_dfs)>1:
            eval_res_df = full_pairwise_evaluation(selected_model_dfs, score_col=error_type)
            
            for model in selected_models:
                
                model_infos=eval_res_df.to_dict(orient="records")
                model_evals[model]["Cohen_d"] = next(
                    (
                        {error_type:{"to": info["model_2"], "cohens_d": info["cohens_d"]}}
                        for info in model_infos
                        if info["model_1"] == model
                    ),
                    None
                )
                model_evals[model]["Bonferroni"] = next(
                    (
                        {error_type:{"to": info["model_2"], "bonferroni_alpha": info["bonferroni_alpha"]}}
                        for info in model_infos
                        if info["model_1"] == model
                    ),
                    None
                )
                model_evals[model]["Mcnemar"] = next(
                    (
                        {error_type:{"to": info["model_2"], "mcnemar_stat": info["mcnemar_stat"], "mcnemar_p":info["mcnemar_stat"]}}
                        for info in model_infos
                        if info["model_1"] == model
                    ),
                    None
                )
    rows = []
    
    for model, data in model_evals.items():
    
        # -------------------------
        # 1. bootstrap_ci
        # -------------------------
        bc = data.get("bootstrap_ci", {})
        if bc:
            rows.append({
                "model": model,
                "to": None,
                "metric": "bootstrap_mean",
                "error_type": "Overall",
                "value": float(bc["mean"])
            })
    
        # -------------------------
        # 3. Cohen's d
        # -------------------------
        for e, v in data.get("Cohen_d", {}).items():
            rows.append({
                "model": model,
                "to": v.get("to"),
                "metric": "cohens_d",
                "error_type": e,
                "value": v.get("cohens_d")
            })
    
        # -------------------------
        # 4. Bonferroni
        # -------------------------
        for e, v in data.get("Bonferroni", {}).items():
            rows.append({
                "model": model,
                "to": v.get("to"),
                "metric": "bonferroni_alpha",
                "error_type": e,
                "value": v.get("bonferroni_alpha")
            })
    
        # -------------------------
        # 5. McNemar
        # -------------------------
        for e, v in data.get("Mcnemar", {}).items():
            rows.append({
                "model": model,
                "to": v.get("to"),
                "metric": "mcnemar_stat",
                "error_type": e,
                "value": v.get("mcnemar_stat")
            })
    
            rows.append({
                "model": model,
                "to": v.get("to"),
                "metric": "mcnemar_p",
                "error_type": e,
                "value": v.get("mcnemar_p")
            })
    
    
    pd.DataFrame(rows).to_csv(save_dir/"model_evaluations.csv",index=False)
    json.dump(model_evals, open(save_dir/"model_evaluations.json","w"), indent=4)



def HarnessEvaluator(results_path,custom_error_taxonomies=None,max_concurrent=10,model_name="gemma-4-31b-it"):

    results_path=Path(results_path)


    error_taxonomies= custom_error_taxonomies if custom_error_taxonomies else {
        "E1":"perceptual failure — model misidentified or failed to detect a spatial element in the image",
        "E2":"grounding failure — model identified elements but failed to anchor them in the correct spatial frame of reference",
        "E3":"spatial transformation failure — model understood the spatial arrangement but failed to correctly apply a rotation, reflection, or perspective change)",
        "E4":"quantitative spatial failure — failure on counting, distance estimation, or measurement",
        "E5":"multi-step reasoning failure — model solved one spatial step correctly but failed on a subsequent step requiring the first as input",
        "E6":"language-spatial mapping failure — model misunderstood the spatial language in the question, e.g., confused 'left of X' with 'right of X'",
        "E7":"format/refusal failure — model did not produce a valid answer regardless of spatial competence",
    } 

    for model_folder in results_path.iterdir():
        if model_folder.is_dir():
            structured_signal_extraction(list(model_folder.glob("*.csv"))[0],max_concurrent=max_concurrent,model_name=model_name)
            error_taxonomy_induction(list(model_folder.glob("agent_scores.csv"))[0],error_taxonomies=error_taxonomies,model_name=model_name)

    

    cross_model_diagnostic_synthesis(results_path.rglob("agent_scores.csv"),results_path)

