from typing import Any

import importlib

from ._api import secure_sandbox
from .core.types import (
    AuditIntegrityConfig,
    AwsKmsConfig,
    AzureKeyVaultConfig,
    ExecOpts,
    ExecResult,
    GcpKmsConfig,
    HashicorpVaultConfig,
    ReadFileFailure,
    ReadFileResult,
    ReadFileSuccess,
    SandboxAdapter,
    SandboxAdapterBase,
    SecuredSandbox,
    SecureConfig,
    WriteFileFailure,
    WriteFileResult,
    WriteFileSuccess,
)
from .core.errors import (
    AgentSHError,
    PolicyValidationError,
    ProvisioningError,
    IntegrityError,
    TransportError,
    RuntimeError as RuntimeError,
)
from .policies.schema import (
    AwsSmProvider,
    AzureKvProvider,
    GcpSmProvider,
    HttpService,
    HttpServiceInject,
    HttpServiceInjectHeader,
    HttpServiceRule,
    HttpServiceSecret,
    KeyringProvider,
    OpProvider,
    PolicyDefinition,
    SecretProvider,
    VaultAuth,
    VaultProvider,
)
try:
    from .toolset.pydantic_ai import SecureSandboxToolset
except ModuleNotFoundError as _exc:
    if _exc.name and _exc.name.split(".")[0] == "pydantic_ai":

        def _missing_toolset(*_a: object, **_kw: object) -> object:
            raise ImportError(
                "SecureSandboxToolset requires the pydantic-ai extra. "
                "Install it with: pip install agentsh-secure-sandbox[pydantic-ai]"
            )

        SecureSandboxToolset = _missing_toolset  # type: ignore[assignment,misc]
    else:
        raise

try:
    from .toolset.langchain import SecureSandboxToolkit
except ModuleNotFoundError as _exc:
    if _exc.name and _exc.name.split(".")[0] in ("langchain", "langchain_core"):

        def _missing_toolkit(*_a: object, **_kw: object) -> object:
            raise ImportError(
                "SecureSandboxToolkit requires the langchain extra. "
                "Install it with: pip install agentsh-secure-sandbox[langchain]"
            )

        SecureSandboxToolkit = _missing_toolkit  # type: ignore[assignment,misc]
    else:
        raise

try:
    from .toolset.openai_agents import SecureSandboxAgentTools
except ModuleNotFoundError as _exc:
    if _exc.name and _exc.name.split(".")[0] in ("agents", "openai_agents"):

        def _missing_agent_tools(*_a: object, **_kw: object) -> object:
            raise ImportError(
                "SecureSandboxAgentTools requires the openai-agents extra. "
                "Install it with: pip install agentsh-secure-sandbox[openai-agents]"
            )

        SecureSandboxAgentTools = _missing_agent_tools  # type: ignore[assignment,misc]
    else:
        raise

_OPENAI_SANDBOX_EXPORTS = {
    "ExeSandboxClient",
    "FreestyleSandboxClient",
    "SecureOpenAISandboxClient",
    "SecureOpenAISandboxSession",
    "SpritesSandboxClient",
    "secure_openai_sandbox_client",
}


def __getattr__(name: str) -> Any:
    if name in _OPENAI_SANDBOX_EXPORTS:
        module = importlib.import_module(".openai_sandbox", __name__)
        value = getattr(module, name)
        globals()[name] = value
        return value
    if name == "toolset":
        module = importlib.import_module(".toolset", __name__)
        globals()[name] = module
        return module
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(set(globals()) | _OPENAI_SANDBOX_EXPORTS | {"toolset"})

__all__ = [
    "AgentSHError",
    "AuditIntegrityConfig",
    "AwsKmsConfig",
    "AwsSmProvider",
    "AzureKeyVaultConfig",
    "AzureKvProvider",
    "ExecOpts",
    "ExecResult",
    "GcpKmsConfig",
    "GcpSmProvider",
    "HashicorpVaultConfig",
    "HttpService",
    "HttpServiceInject",
    "HttpServiceInjectHeader",
    "HttpServiceRule",
    "HttpServiceSecret",
    "IntegrityError",
    "KeyringProvider",
    "OpProvider",
    "PolicyDefinition",
    "PolicyValidationError",
    "ProvisioningError",
    "ReadFileFailure",
    "ReadFileResult",
    "ReadFileSuccess",
    "RuntimeError",
    "ExeSandboxClient",
    "FreestyleSandboxClient",
    "SecureOpenAISandboxClient",
    "SecureOpenAISandboxSession",
    "SandboxAdapter",
    "SandboxAdapterBase",
    "SecretProvider",
    "SecureConfig",
    "SecureSandboxAgentTools",
    "SecureSandboxToolkit",
    "SecureSandboxToolset",
    "SecuredSandbox",
    "TransportError",
    "VaultAuth",
    "VaultProvider",
    "WriteFileFailure",
    "WriteFileResult",
    "WriteFileSuccess",
    "SpritesSandboxClient",
    "secure_openai_sandbox_client",
    "secure_sandbox",
]
