"""Bridge OpenAI Agents sandbox sessions to agentsh sandbox adapters."""

from __future__ import annotations

import base64
import io
import shlex
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from ..core.shell import env_prefix, fire_and_forget, shell_escape
from ..core.types import ExecOpts, ExecResult, SecuredSandbox

_OPENAI_AGENTS_IMPORT_MESSAGE = (
    "OpenAI sandbox support requires the openai-agents extra. "
    "Install it with: pip install agentsh-secure-sandbox[openai-agents]"
)

if TYPE_CHECKING:
    from agents.sandbox.types import User


class _MissingOpenAIConfigurationError(Exception):
    pass


class _MissingOpenAIInvalidManifestPathError(Exception):
    pass


def _load_openai_sdk_runtime_types() -> tuple[type[Any], Any, ModuleNotFoundError | None]:
    try:
        from agents.sandbox.session.base_sandbox_session import BaseSandboxSession
        from agents.sandbox.types import ExecResult as OpenAIExecResult
    except ModuleNotFoundError as _exc:
        if _exc.name and _exc.name.split(".")[0] not in {"agents", "openai_agents"}:
            raise
        return object, object, _exc
    return BaseSandboxSession, OpenAIExecResult, None


_BaseSandboxSession, _OpenAIExecResult, _OPENAI_SANDBOX_IMPORT_ERROR = _load_openai_sdk_runtime_types()


def _load_openai_sdk_error_types() -> tuple[type[BaseException], type[BaseException]]:
    try:
        from agents.sandbox.errors import ConfigurationError, InvalidManifestPathError
    except ModuleNotFoundError as exc:
        if exc.name and exc.name.split(".")[0] not in {"agents", "openai_agents"}:
            raise
        return _MissingOpenAIConfigurationError, _MissingOpenAIInvalidManifestPathError
    return ConfigurationError, InvalidManifestPathError


_OpenAIConfigurationError, _OpenAIInvalidManifestPathError = _load_openai_sdk_error_types()


def _raise_missing_openai_sandbox_extra() -> None:
    if _OPENAI_SANDBOX_IMPORT_ERROR is not None:
        raise ImportError(_OPENAI_AGENTS_IMPORT_MESSAGE) from _OPENAI_SANDBOX_IMPORT_ERROR


def _decode_payload(value: bytes | bytearray | str | None) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return bytes(value).decode(errors="replace")


def _encode_payload(value: str | bytes | bytearray | None) -> bytes:
    if value is None:
        return b""
    if isinstance(value, str):
        return value.encode(errors="replace")
    return bytes(value)


def _read_io_bytes(data: io.IOBase) -> bytes:
    payload = data.read()
    if isinstance(payload, str):
        return payload.encode(errors="replace")
    if payload is None:
        return b""
    if isinstance(payload, (bytes, bytearray)):
        return bytes(payload)
    return str(payload).encode(errors="replace")


def _coerce_openai_exec_result(result: Any) -> ExecResult:
    return ExecResult(
        stdout=_decode_payload(getattr(result, "stdout", b"")),
        stderr=_decode_payload(getattr(result, "stderr", b"")),
        exit_code=int(getattr(result, "exit_code", 0) or 0),
    )


def _coerce_write_bytes(content: str | bytes) -> bytes:
    if isinstance(content, bytes):
        return content
    return content.encode()


def _escape_path_for_shell(path: str) -> str:
    return path.replace("'", "'\\''")


def _is_unsupported_user_error(exc: BaseException) -> bool:
    return isinstance(exc, _OpenAIConfigurationError) and "sandbox-local users" in str(exc)


def _is_invalid_manifest_path_error(exc: BaseException) -> bool:
    return isinstance(exc, _OpenAIInvalidManifestPathError)


def _uses_missing_sudo(result: Any) -> bool:
    stderr = _decode_payload(getattr(result, "stderr", b"")).lower()
    return int(getattr(result, "exit_code", 0) or 0) == 127 and (
        "sudo: not found" in stderr or "sudo: command not found" in stderr
    )


def _build_shell_command(cmd: str, args: list[str] | None, opts: ExecOpts) -> str:
    command = f"{env_prefix(opts.env)}{shell_escape(cmd, args)}"
    if opts.cwd:
        return f"cd '{_escape_path_for_shell(opts.cwd)}' && {command}"
    return command


def _build_detached_shell_command(shell_command: str) -> str:
    return f"nohup sh -lc {shlex.quote(shell_command)} > /dev/null 2>&1 &"


def _build_inline_write_command(path: str, payload: bytes) -> str:
    encoded = base64.b64encode(payload).decode("ascii")
    dir_q = shlex.quote(str(Path(path).parent))
    path_q = shlex.quote(path)
    encoded_q = shlex.quote(encoded)
    return f"mkdir -p -- {dir_q} && printf '%s' {encoded_q} | base64 -d > {path_q}"


def _read_result_content(result: Any, path: str) -> str:
    if not getattr(result, "success", False):
        raise FileNotFoundError(getattr(result, "error", path) or path)
    return _decode_payload(getattr(result, "content", ""))


def _write_result_or_raise(result: Any, path: str) -> None:
    if not getattr(result, "success", False):
        raise PermissionError(getattr(result, "error", path) or path)


def _raise_cleanup_errors(action: str, errors: list[Exception]) -> None:
    if not errors:
        return
    if len(errors) == 1:
        raise errors[0]
    raise ExceptionGroup(action, errors)


class _OpenAISessionAdapter:
    def __init__(self, session: Any) -> None:
        self._session = session
        self._user_override_strategy: str | None = None

    async def _session_exec(
        self,
        *command: str,
        fallback_command: tuple[str, ...] | None = None,
        fallback_kwargs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:
        exec_kwargs = dict(kwargs)
        user = exec_kwargs.get("user")
        if user is not None and self._user_override_strategy == "fallback":
            if fallback_command is not None:
                return await self._session.exec(*fallback_command, **(fallback_kwargs or {}))
            exec_kwargs.pop("user", None)
            user = None
        elif user is not None and self._user_override_strategy == "drop":
            exec_kwargs.pop("user", None)
            user = None

        try:
            result = await self._session.exec(*command, **exec_kwargs)
        except Exception as exc:
            if user is None or not _is_unsupported_user_error(exc):
                raise
            self._user_override_strategy = "fallback"
            if fallback_command is not None:
                return await self._session.exec(*fallback_command, **(fallback_kwargs or {}))
            retry_kwargs = dict(exec_kwargs)
            retry_kwargs.pop("user", None)
            return await self._session.exec(*command, **retry_kwargs)

        if user is not None and _uses_missing_sudo(result):
            self._user_override_strategy = "drop"
            retry_kwargs = dict(exec_kwargs)
            retry_kwargs.pop("user", None)
            return await self._session.exec(*command, **retry_kwargs)

        if user is not None and self._user_override_strategy is None:
            self._user_override_strategy = "direct"
        return result

    async def _write_direct(self, path: str, payload: bytes, *, user: str | None = None) -> bool:
        write_kwargs: dict[str, Any] = {}
        if user is not None and self._user_override_strategy != "drop":
            write_kwargs["user"] = user

        try:
            await self._session.write(Path(path), io.BytesIO(payload), **write_kwargs)
        except Exception as exc:
            if user is not None and "user" in write_kwargs and _is_unsupported_user_error(exc):
                self._user_override_strategy = "fallback"
                try:
                    await self._session.write(Path(path), io.BytesIO(payload))
                except Exception as retry_exc:
                    if _is_invalid_manifest_path_error(retry_exc):
                        return False
                    raise
                return True

            if _is_invalid_manifest_path_error(exc):
                return False
            raise

        if user is not None and "user" in write_kwargs and self._user_override_strategy is None:
            self._user_override_strategy = "direct"
        return True

    async def exec(
        self,
        cmd: str,
        args: list[str] | None = None,
        opts: ExecOpts | None = None,
    ) -> ExecResult:
        opts = opts or ExecOpts()
        user = "root" if opts.sudo else None
        command = [cmd, *(args or [])]

        if opts.cwd or opts.env or opts.detached:
            shell_command = _build_shell_command(cmd, args, opts)
            sudo_shell_command = f"sudo -n sh -lc {shlex.quote(shell_command)}"
            if opts.detached:
                detached_exec_kwargs: dict[str, Any] = {"timeout": None, "shell": True}
                if user is not None:
                    detached_exec_kwargs["user"] = user
                fire_and_forget(
                    self._session_exec(
                        _build_detached_shell_command(shell_command),
                        fallback_command=(_build_detached_shell_command(sudo_shell_command),),
                        fallback_kwargs={"timeout": None, "shell": True},
                        **detached_exec_kwargs,
                    )
                )
                return ExecResult(stdout="", stderr="", exit_code=0)

            exec_kwargs: dict[str, Any] = {"timeout": None, "shell": True}
            if user is not None:
                exec_kwargs["user"] = user
            result: Any = await self._session_exec(
                shell_command,
                fallback_command=(sudo_shell_command,),
                fallback_kwargs={"timeout": None, "shell": True},
                **exec_kwargs,
            )
            return _coerce_openai_exec_result(result)

        exec_kwargs = {"timeout": None, "shell": False}
        if user is not None:
            exec_kwargs["user"] = user
        result = await self._session_exec(
            *command,
            fallback_command=("sudo", "-n", *command),
            fallback_kwargs={"timeout": None, "shell": False},
            **exec_kwargs,
        )
        return _coerce_openai_exec_result(result)

    async def write_file(
        self,
        path: str,
        content: str | bytes,
        *,
        sudo: bool = False,
    ) -> None:
        payload = _coerce_write_bytes(content)
        if await self._write_direct(path, payload, user="root" if sudo else None):
            return

        result = await self.exec("sh", ["-lc", _build_inline_write_command(path, payload)], ExecOpts(sudo=sudo))
        if result.exit_code != 0:
            raise PermissionError(result.stderr or result.stdout or path)

    async def read_file(self, path: str) -> str:
        handle = await self._session.read(Path(path))
        return _decode_payload(handle.read())

    async def stop(self) -> None:
        await self._session.shutdown()

    async def file_exists(self, path: str) -> bool:
        result: Any = await self._session.exec(
            "test",
            "-f",
            path,
            timeout=None,
            shell=False,
        )
        exit_code = int(getattr(result, "exit_code", 1) or 0)
        return exit_code == 0


class SecureOpenAISandboxSession(cast(type[Any], _BaseSandboxSession)):  # type: ignore[misc]
    """Adapt an OpenAI sandbox session to the agentsh secured sandbox wrapper."""

    def __init__(self, inner_session: Any, secured_sandbox: SecuredSandbox) -> None:
        _raise_missing_openai_sandbox_extra()
        self._inner_session = inner_session
        self._secured_sandbox = secured_sandbox
        self._secured_sandbox_stopped = False

    @property
    def inner_session(self) -> Any:
        return self._inner_session

    @property
    def state(self) -> Any:
        return self._inner_session.state

    @state.setter
    def state(self, value: Any) -> None:
        self._inner_session.state = value

    async def _exec_internal(
        self,
        *command: str | Path,
        timeout: float | None = None,
    ) -> Any:
        _raise_missing_openai_sandbox_extra()
        joined = shlex.join(str(part) for part in command)
        result = await self._secured_sandbox.exec(joined, timeout=timeout)
        return _OpenAIExecResult(
            stdout=_encode_payload(result.stdout),
            stderr=_encode_payload(result.stderr),
            exit_code=result.exit_code,
        )

    async def read(self, path: Path, *, user: str | User | None = None) -> io.BytesIO:
        if user is not None:
            raise NotImplementedError("SecureOpenAISandboxSession.read does not support user overrides")
        result = await self._secured_sandbox.read_file(str(path))
        content = _read_result_content(result, str(path))
        return io.BytesIO(content.encode(errors="replace"))

    async def write(self, path: Path, data: io.IOBase, *, user: str | User | None = None) -> None:
        if user is not None:
            raise NotImplementedError("SecureOpenAISandboxSession.write does not support user overrides")
        payload_bytes = _read_io_bytes(data)
        result = await self._secured_sandbox.write_file(str(path), payload_bytes)
        _write_result_or_raise(result, str(path))

    async def persist_workspace(self) -> io.IOBase:
        return cast(io.IOBase, await self._inner_session.persist_workspace())

    async def hydrate_workspace(self, data: io.IOBase) -> None:
        await self._inner_session.hydrate_workspace(data)

    async def running(self) -> bool:
        return cast(bool, await self._inner_session.running())

    def supports_pty(self) -> bool:
        return cast(bool, self._inner_session.supports_pty())

    async def pty_exec_start(
        self,
        *command: str | Path,
        timeout: float | None = None,
        shell: bool | list[str] = True,
        user: str | User | None = None,
        tty: bool = False,
        yield_time_s: float | None = None,
        max_output_tokens: int | None = None,
    ) -> Any:
        return await self._inner_session.pty_exec_start(
            *command,
            timeout=timeout,
            shell=shell,
            user=user,
            tty=tty,
            yield_time_s=yield_time_s,
            max_output_tokens=max_output_tokens,
        )

    async def pty_write_stdin(
        self,
        *,
        session_id: int,
        chars: str,
        yield_time_s: float | None = None,
        max_output_tokens: int | None = None,
    ) -> Any:
        return await self._inner_session.pty_write_stdin(
            session_id=session_id,
            chars=chars,
            yield_time_s=yield_time_s,
            max_output_tokens=max_output_tokens,
        )

    async def pty_terminate_all(self) -> None:
        await self._inner_session.pty_terminate_all()

    async def _resolve_exposed_port(self, port: int) -> Any:
        return await self._inner_session._resolve_exposed_port(port)

    async def _stop_secured_sandbox_once(self) -> None:
        if not self._secured_sandbox_stopped:
            await self._secured_sandbox.stop()
            self._secured_sandbox_stopped = True

    async def stop(self) -> None:
        errors: list[Exception] = []
        try:
            await self._inner_session.stop()
        except Exception as exc:
            errors.append(exc)
        try:
            await self._stop_secured_sandbox_once()
        except Exception as exc:
            errors.append(exc)
        _raise_cleanup_errors("SecureOpenAISandboxSession.stop", errors)

    async def shutdown(self) -> None:
        errors: list[Exception] = []
        try:
            await self._stop_secured_sandbox_once()
        except Exception as exc:
            errors.append(exc)
        try:
            await self._inner_session.shutdown()
        except Exception as exc:
            errors.append(exc)
        _raise_cleanup_errors("SecureOpenAISandboxSession.shutdown", errors)
