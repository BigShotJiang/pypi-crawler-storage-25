"""Wrappers around upstream OpenAI Agents sandbox clients."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from agents.sandbox.manifest import Manifest
from agents.sandbox.session.sandbox_client import BaseSandboxClient
from agents.sandbox.session.sandbox_session import SandboxSession
from agents.sandbox.session.sandbox_session_state import SandboxSessionState
from agents.sandbox.snapshot import SnapshotBase, SnapshotSpec

from .._api import secure_sandbox
from ..core.types import SecureConfig
from .bridge import _OpenAISessionAdapter, SecureOpenAISandboxSession


def _default_config_for_upstream(upstream_client: BaseSandboxClient[Any]) -> SecureConfig:
    backend_id = getattr(upstream_client, "backend_id", "")
    if isinstance(backend_id, str) and backend_id.startswith("cloudflare"):
        return SecureConfig(install_strategy="preinstalled")
    return SecureConfig()


def _raise_cleanup_errors(action: str, errors: list[Exception]) -> None:
    if not errors:
        return
    if len(errors) == 1:
        raise errors[0]
    raise ExceptionGroup(action, errors)


def _unwrap_sandbox_session(session: Any) -> tuple[Any, Any | None]:
    if isinstance(session, SandboxSession):
        inner = session._inner
        return inner, session
    return session, None


def _wrap_secure_session(
    client: BaseSandboxClient[Any],
    secure_inner: SecureOpenAISandboxSession,
    *,
    instrumentation: Any = None,
    dependencies: Any = None,
) -> SandboxSession:
    if instrumentation is None and dependencies is None:
        return client._wrap_session(secure_inner)
    return SandboxSession(
        secure_inner,
        instrumentation=instrumentation,
        dependencies=dependencies,
    )


class SecureOpenAISandboxClient(BaseSandboxClient[Any]):
    """Wrap an upstream OpenAI sandbox client and secure model-facing operations."""

    def __init__(
        self,
        *,
        upstream_client: BaseSandboxClient[Any],
        config: SecureConfig | None = None,
        prepare_upstream_session: Callable[[Any], Awaitable[None]] | None = None,
    ) -> None:
        self._upstream_client = upstream_client
        self._config = config or _default_config_for_upstream(upstream_client)
        self._prepare_upstream_session = prepare_upstream_session
        self.backend_id = f"agentsh-secure:{upstream_client.backend_id}"
        self.supports_default_options = upstream_client.supports_default_options

    @property
    def upstream_client(self) -> BaseSandboxClient[Any]:
        return self._upstream_client

    async def _run_prepare_upstream_session(self, upstream_session: Any) -> None:
        if self._prepare_upstream_session is None:
            return
        await self._prepare_upstream_session(upstream_session)

    async def _secure_session(self, upstream_session: Any) -> SandboxSession:
        await self._run_prepare_upstream_session(upstream_session)
        inner_session, retained_upstream_session = _unwrap_sandbox_session(upstream_session)
        secured = await secure_sandbox(_OpenAISessionAdapter(inner_session), self._config)
        secure_inner = SecureOpenAISandboxSession(
            inner_session=inner_session,
            secured_sandbox=secured,
        )
        setattr(secure_inner, "_upstream_session", retained_upstream_session or upstream_session)
        if isinstance(upstream_session, SandboxSession):
            return _wrap_secure_session(
                self,
                secure_inner,
                instrumentation=getattr(upstream_session, "_instrumentation", None),
                dependencies=upstream_session.dependencies,
            )
        return _wrap_secure_session(self, secure_inner)

    async def create(
        self,
        *,
        snapshot: SnapshotSpec | SnapshotBase | None = None,
        manifest: Manifest | None = None,
        options: Any,
    ) -> SandboxSession:
        upstream_session = await self._upstream_client.create(
            snapshot=snapshot,
            manifest=manifest,
            options=options,
        )
        return await self._secure_session(upstream_session)

    async def resume(self, state: SandboxSessionState) -> SandboxSession:
        upstream_session = await self._upstream_client.resume(state)
        return await self._secure_session(upstream_session)

    async def delete(self, session: SandboxSession) -> SandboxSession:
        inner = getattr(session, "_inner", session)
        if not isinstance(inner, SecureOpenAISandboxSession):
            await self._upstream_client.delete(session)
            return session

        upstream_session = getattr(inner, "_upstream_session", inner.inner_session)
        errors: list[Exception] = []
        try:
            await inner.shutdown()
        except Exception as exc:
            errors.append(exc)
        try:
            await self._upstream_client.delete(upstream_session)
        except Exception as exc:
            errors.append(exc)
        _raise_cleanup_errors("SecureOpenAISandboxClient.delete", errors)
        return session

    def serialize_session_state(self, state: SandboxSessionState) -> dict[str, object]:
        return self._upstream_client.serialize_session_state(state)

    def deserialize_session_state(self, payload: dict[str, object]) -> SandboxSessionState:
        return self._upstream_client.deserialize_session_state(payload)
