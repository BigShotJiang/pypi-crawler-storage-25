"""OpenAI Agents SDK SandboxAgent integration."""

from __future__ import annotations

from typing import Any

_OPENAI_AGENTS_IMPORT_MESSAGE = (
    "OpenAI sandbox support requires the openai-agents extra. "
    "Install it with: pip install agentsh-secure-sandbox[openai-agents]"
)

_OPENAI_SANDBOX_IMPORT_ERROR: ModuleNotFoundError | None

try:
    import agents  # noqa: F401
except ModuleNotFoundError as _exc:
    if _exc.name and _exc.name.split(".")[0] not in {"agents", "openai_agents"}:
        raise
    _OPENAI_SANDBOX_IMPORT_ERROR = _exc
else:
    _OPENAI_SANDBOX_IMPORT_ERROR = None


def _raise_missing_openai_sandbox_extra() -> None:
    if _OPENAI_SANDBOX_IMPORT_ERROR is not None:
        raise ImportError(_OPENAI_AGENTS_IMPORT_MESSAGE) from _OPENAI_SANDBOX_IMPORT_ERROR


def _raise_missing_or_unimplemented_openai_sandbox_extra() -> None:
    _raise_missing_openai_sandbox_extra()
    raise NotImplementedError("OpenAI sandbox support is not implemented yet")


class _MissingSecureOpenAISandboxClient:
    def __init__(self, *_args: object, **_kwargs: object) -> None:
        _raise_missing_openai_sandbox_extra()


class _MissingSecureOpenAISandboxSession:
    def __init__(self, *_args: object, **_kwargs: object) -> None:
        _raise_missing_openai_sandbox_extra()


class _MissingSpritesSandboxClient:
    def __init__(self, *_args: object, **_kwargs: object) -> None:
        _raise_missing_openai_sandbox_extra()


class _MissingExeSandboxClient:
    def __init__(self, *_args: object, **_kwargs: object) -> None:
        _raise_missing_openai_sandbox_extra()


class _MissingFreestyleSandboxClient:
    def __init__(self, *_args: object, **_kwargs: object) -> None:
        _raise_missing_openai_sandbox_extra()

SecureOpenAISandboxSession: Any
SecureOpenAISandboxClient: Any
SpritesSandboxClient: Any
ExeSandboxClient: Any
FreestyleSandboxClient: Any
secure_openai_sandbox_client: Any

if _OPENAI_SANDBOX_IMPORT_ERROR is None:
    from . import bridge as _bridge
    from . import unsupported as _unsupported

    _OPENAI_SANDBOX_IMPORT_ERROR = _bridge._OPENAI_SANDBOX_IMPORT_ERROR
    if _OPENAI_SANDBOX_IMPORT_ERROR is None:
        SecureOpenAISandboxSession = _bridge.SecureOpenAISandboxSession
        from .wrappers import SecureOpenAISandboxClient as _RealSecureOpenAISandboxClient

        SecureOpenAISandboxClient = _RealSecureOpenAISandboxClient
        SpritesSandboxClient = _unsupported.SpritesSandboxClient
        ExeSandboxClient = _unsupported.ExeSandboxClient
        FreestyleSandboxClient = _unsupported.FreestyleSandboxClient
        from .providers import secure_openai_sandbox_client as _secure_openai_sandbox_client

        secure_openai_sandbox_client = _secure_openai_sandbox_client
    else:
        _MissingSecureOpenAISandboxSession.__name__ = "SecureOpenAISandboxSession"
        SecureOpenAISandboxSession = _MissingSecureOpenAISandboxSession
        _MissingSecureOpenAISandboxClient.__name__ = "SecureOpenAISandboxClient"
        SecureOpenAISandboxClient = _MissingSecureOpenAISandboxClient
        _MissingSpritesSandboxClient.__name__ = "SpritesSandboxClient"
        SpritesSandboxClient = _MissingSpritesSandboxClient
        _MissingExeSandboxClient.__name__ = "ExeSandboxClient"
        ExeSandboxClient = _MissingExeSandboxClient
        _MissingFreestyleSandboxClient.__name__ = "FreestyleSandboxClient"
        FreestyleSandboxClient = _MissingFreestyleSandboxClient
        def secure_openai_sandbox_client(*_args: object, **_kwargs: object) -> Any:
            _raise_missing_openai_sandbox_extra()
else:
    _MissingSecureOpenAISandboxSession.__name__ = "SecureOpenAISandboxSession"
    SecureOpenAISandboxSession = _MissingSecureOpenAISandboxSession
    _MissingSecureOpenAISandboxClient.__name__ = "SecureOpenAISandboxClient"
    SecureOpenAISandboxClient = _MissingSecureOpenAISandboxClient
    _MissingSpritesSandboxClient.__name__ = "SpritesSandboxClient"
    SpritesSandboxClient = _MissingSpritesSandboxClient
    _MissingExeSandboxClient.__name__ = "ExeSandboxClient"
    ExeSandboxClient = _MissingExeSandboxClient
    _MissingFreestyleSandboxClient.__name__ = "FreestyleSandboxClient"
    FreestyleSandboxClient = _MissingFreestyleSandboxClient
    def secure_openai_sandbox_client(*_args: object, **_kwargs: object) -> Any:
        _raise_missing_openai_sandbox_extra()


__all__ = [
    "SecureOpenAISandboxClient",
    "SecureOpenAISandboxSession",
    "secure_openai_sandbox_client",
    "SpritesSandboxClient",
    "ExeSandboxClient",
    "FreestyleSandboxClient",
]
