from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any, Literal

from ..core.types import SecureConfig

if TYPE_CHECKING:
    from agents.sandbox.session.sandbox_client import BaseSandboxClient
else:
    BaseSandboxClient = Any

_OPENAI_AGENTS_IMPORT_MESSAGE = (
    "OpenAI sandbox support requires the openai-agents extra. "
    "Install it with: pip install agentsh-secure-sandbox[openai-agents]"
)

OpenAISandboxProvider = Literal[
    "blaxel",
    "cloudflare",
    "daytona",
    "e2b",
    "modal",
    "runloop",
    "vercel",
    "sprites",
    "exe",
    "freestyle",
]

_UPSTREAM_PROVIDERS = {
    "blaxel",
    "cloudflare",
    "daytona",
    "e2b",
    "modal",
    "runloop",
    "vercel",
}


def _reject_unexpected_kwargs(provider: str, kwargs: dict[str, Any]) -> None:
    if kwargs:
        unexpected = ", ".join(sorted(kwargs))
        raise ValueError(
            f"provider {provider!r} does not accept unexpected kwargs: {unexpected}"
        )


def _raise_missing_openai_sandbox_extra(exc: ModuleNotFoundError) -> None:
    raise ImportError(_OPENAI_AGENTS_IMPORT_MESSAGE) from exc


def secure_openai_sandbox_client(
    *,
    provider: str,
    upstream_client: BaseSandboxClient[Any] | None = None,
    config: SecureConfig | None = None,
    prepare_upstream_session: Callable[[Any], Awaitable[None]] | None = None,
    **kwargs: Any,
) -> BaseSandboxClient[Any]:
    if provider in _UPSTREAM_PROVIDERS:
        if upstream_client is None:
            raise ValueError(f"provider {provider!r} requires upstream_client")
        _reject_unexpected_kwargs(provider, kwargs)
        try:
            from .wrappers import SecureOpenAISandboxClient
        except ModuleNotFoundError as exc:
            if exc.name and exc.name.split(".")[0] in {"agents", "openai_agents"}:
                _raise_missing_openai_sandbox_extra(exc)
            raise

        return SecureOpenAISandboxClient(
            upstream_client=upstream_client,
            config=config,
            prepare_upstream_session=prepare_upstream_session,
        )

    if provider == "sprites":
        try:
            from .unsupported import SpritesSandboxClient
        except ModuleNotFoundError as exc:
            if exc.name and exc.name.split(".")[0] in {"agents", "openai_agents"}:
                _raise_missing_openai_sandbox_extra(exc)
            raise

        return SpritesSandboxClient(config=config, **kwargs)

    if provider == "exe":
        try:
            from .unsupported import ExeSandboxClient
        except ModuleNotFoundError as exc:
            if exc.name and exc.name.split(".")[0] in {"agents", "openai_agents"}:
                _raise_missing_openai_sandbox_extra(exc)
            raise

        return ExeSandboxClient(config=config, **kwargs)

    if provider == "freestyle":
        try:
            from .unsupported import FreestyleSandboxClient
        except ModuleNotFoundError as exc:
            if exc.name and exc.name.split(".")[0] in {"agents", "openai_agents"}:
                _raise_missing_openai_sandbox_extra(exc)
            raise

        return FreestyleSandboxClient(config=config, **kwargs)

    available = sorted([*_UPSTREAM_PROVIDERS, "sprites", "exe", "freestyle"])
    raise ValueError(f"unknown provider {provider!r}; available providers: {', '.join(available)}")
