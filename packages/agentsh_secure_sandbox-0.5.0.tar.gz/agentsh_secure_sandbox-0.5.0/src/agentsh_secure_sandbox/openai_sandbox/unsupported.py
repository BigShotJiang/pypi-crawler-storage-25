"""Shared OpenAI-compatible primitives for unsupported custom providers."""

from __future__ import annotations

import base64
import inspect
import io
import shlex
from pathlib import Path
from typing import Awaitable, Callable
from uuid import uuid4
from typing import TYPE_CHECKING, Any, Literal

from agents.sandbox.manifest import Manifest
from agents.sandbox.session.base_sandbox_session import BaseSandboxSession
from agents.sandbox.session.sandbox_client import BaseSandboxClient
from agents.sandbox.session.sandbox_client import BaseSandboxClientOptions
from agents.sandbox.session.sandbox_session import SandboxSession
from agents.sandbox.session.sandbox_session_state import SandboxSessionState
from agents.sandbox.snapshot import SnapshotBase, SnapshotSpec, resolve_snapshot
from agents.sandbox.types import ExecResult as OpenAIExecResult
from agents.sandbox.types import ExposedPortEndpoint

from .._api import secure_sandbox
from ..adapters import (
    FreestyleClient,
    exe,
    exe_defaults,
    freestyle,
    freestyle_defaults,
    sprites,
    sprites_defaults,
)
from ..core.types import SecureConfig
from ..core.types import SecuredSandbox

if TYPE_CHECKING:
    from agents.sandbox.types import User


def _decode_bytes(value: bytes | bytearray | str | None) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return bytes(value).decode("utf-8", errors="replace")


def _encode_bytes(value: str | bytes | bytearray | None) -> bytes:
    if value is None:
        return b""
    if isinstance(value, str):
        return value.encode("utf-8", errors="replace")
    return bytes(value)


def _coerce_openai_exec_result(result: Any) -> OpenAIExecResult:
    return OpenAIExecResult(
        stdout=_encode_bytes(getattr(result, "stdout", b"")),
        stderr=_encode_bytes(getattr(result, "stderr", b"")),
        exit_code=int(getattr(result, "exit_code", 0) or 0),
    )


def _read_io_bytes(data: io.IOBase) -> bytes:
    payload = data.read()
    return _encode_bytes(payload)


def _read_result_or_raise(result: Any, path: str) -> str:
    if not getattr(result, "success", False):
        raise FileNotFoundError(getattr(result, "error", path) or path)
    return _decode_bytes(getattr(result, "content", ""))


def _write_result_or_raise(result: Any, path: str) -> None:
    if not getattr(result, "success", False):
        raise PermissionError(getattr(result, "error", path) or path)


def _config_for_manifest(config: SecureConfig, manifest: Manifest | None) -> SecureConfig:
    if manifest is None:
        return config
    return config.model_copy(update={"workspace": manifest.root})


def _persist_workspace_command(root: str) -> str:
    return (
        f"root={shlex.quote(root)} && "
        "tmp_dir=$(mktemp -d) && "
        'trap \'rm -rf "$tmp_dir"\' EXIT && '
        'archive="$tmp_dir/workspace.tar" && '
        'tar -C "$root" -cf "$archive" . && '
        'base64 -w0 "$archive"'
    )


def _hydrate_workspace_command(root: str, archive_path: str) -> str:
    return (
        f"root={shlex.quote(root)} && "
        f"archive={shlex.quote(archive_path)} && "
        'stage=$(mktemp -d /tmp/agentsh-openai-staging.XXXXXX) && '
        'trap \'rm -rf "$stage" "$archive"; [ -n "${backup:-}" ] && rm -rf "$backup"\' EXIT && '
        'stage_root="$stage/root" && '
        'mkdir -p "$stage_root" && '
        'tar -tf "$archive" >/dev/null && '
        'tar -C "$stage_root" -xf "$archive" && '
        'mkdir -p "$root" && '
        'backup=$(mktemp -d "$root/.agentsh-openai-backup.XXXXXX") && '
        'find "$root" -mindepth 1 -maxdepth 1 ! -name "$(basename -- "$backup")" -exec mv {} "$backup"/ \\; && '
        'if find "$stage_root" -mindepth 1 -maxdepth 1 -exec mv {} "$root"/ \\; ; then '
        'rm -rf "$backup"; '
        'else '
        'find "$root" -mindepth 1 -maxdepth 1 ! -name "$(basename -- "$backup")" -exec rm -rf {} \\; && '
        'find "$backup" -mindepth 1 -maxdepth 1 -exec mv {} "$root"/ \\; && '
        'rm -rf "$backup"; '
        'exit 1; '
        'fi'
    )


class UnsupportedProviderSessionState(SandboxSessionState):
    type: Literal["agentsh_secure_provider"] = "agentsh_secure_provider"
    provider: str
    handle: str | None = None


class UnsupportedProviderClientOptions(BaseSandboxClientOptions):
    type: Literal["agentsh_secure_provider"] = "agentsh_secure_provider"
    handle: str | None = None


class _SecuredAdapterSession(BaseSandboxSession):
    def __init__(
        self,
        *,
        state: UnsupportedProviderSessionState,
        secured_sandbox: SecuredSandbox,
    ) -> None:
        self.state = state
        self._secured_sandbox = secured_sandbox
        self._running = True
        self._secured_sandbox_stopped = False

    async def _exec_internal(
        self,
        *command: str | Path,
        timeout: float | None = None,
    ) -> OpenAIExecResult:
        joined = shlex.join(str(part) for part in command)
        result = await self._secured_sandbox.exec(joined, timeout=timeout)
        return _coerce_openai_exec_result(result)

    async def exec(
        self,
        *command: str | Path,
        timeout: float | None = None,
        shell: bool | list[str] = True,
        user: str | User | None = None,
    ) -> OpenAIExecResult:
        if user is not None:
            raise NotImplementedError("user overrides are not supported for unsupported provider sessions")
        return await super().exec(*command, timeout=timeout, shell=shell, user=None)

    async def read(self, path: Path, *, user: str | User | None = None) -> io.IOBase:
        if user is not None:
            raise NotImplementedError("user overrides are not supported for unsupported provider sessions")
        result = await self._secured_sandbox.read_file(str(path))
        return io.BytesIO(_encode_bytes(_read_result_or_raise(result, str(path))))

    async def write(
        self,
        path: Path,
        data: io.IOBase,
        *,
        user: str | User | None = None,
    ) -> None:
        if user is not None:
            raise NotImplementedError("user overrides are not supported for unsupported provider sessions")
        payload = _read_io_bytes(data)
        result = await self._secured_sandbox.write_file(str(path), payload)
        _write_result_or_raise(result, str(path))

    async def running(self) -> bool:
        return self._running

    async def persist_workspace(self) -> io.IOBase:
        result = await self._secured_sandbox.exec(
            _persist_workspace_command(self.state.manifest.root),
            timeout=None,
        )
        stdout = _decode_bytes(getattr(result, "stdout", ""))
        stderr = _decode_bytes(getattr(result, "stderr", ""))
        if int(getattr(result, "exit_code", 1) or 0) != 0:
            raise RuntimeError(
                f"workspace persistence failed for {self.state.manifest.root}: "
                f"{stderr or stdout or 'non-zero exit code'}"
            )
        if not stdout:
            return io.BytesIO()
        try:
            decoded = base64.b64decode(stdout.encode("ascii"), validate=True)
        except Exception as exc:
            raise RuntimeError(
                f"workspace persistence produced invalid base64 for {self.state.manifest.root}"
            ) from exc
        return io.BytesIO(decoded)

    async def hydrate_workspace(self, data: io.IOBase) -> None:
        payload = _read_io_bytes(data)
        archive_path = f"/tmp/agentsh-openai-hydrate-{uuid4().hex}.tar"
        async def _best_effort_cleanup() -> None:
            try:
                await self._secured_sandbox.exec(
                    f"rm -f {shlex.quote(archive_path)}",
                    timeout=None,
                )
            except Exception:
                pass

        try:
            write_result = await self._secured_sandbox.write_file(archive_path, payload)
            try:
                _write_result_or_raise(write_result, archive_path)
            except PermissionError as exc:
                raise RuntimeError(
                    f"workspace hydration failed for {self.state.manifest.root}: {exc}"
                ) from exc

            command = _hydrate_workspace_command(
                self.state.manifest.root,
                archive_path,
            )
            result = await self._secured_sandbox.exec(command, timeout=None)
            if int(getattr(result, "exit_code", 1) or 0) != 0:
                stderr = _decode_bytes(getattr(result, "stderr", ""))
                stdout = _decode_bytes(getattr(result, "stdout", ""))
                raise RuntimeError(
                    f"workspace hydration failed for {self.state.manifest.root}: "
                    f"{stderr or stdout or 'non-zero exit code'}"
                )
        except Exception:
            await _best_effort_cleanup()
            raise
        else:
            await _best_effort_cleanup()

    async def _stop_secured_sandbox_once(self) -> None:
        if self._secured_sandbox_stopped:
            return
        await self._secured_sandbox.stop()
        self._secured_sandbox_stopped = True

    async def shutdown(self) -> None:
        await self._stop_secured_sandbox_once()
        self._running = False

    async def _resolve_exposed_port(self, port: int) -> ExposedPortEndpoint:
        raise NotImplementedError("exposed ports are not supported for unsupported providers")


class SpritesSandboxClient(BaseSandboxClient[UnsupportedProviderClientOptions | None]):
    backend_id = "agentsh-secure:sprites"
    supports_default_options = True

    def __init__(
        self,
        *,
        sprite: Any | None = None,
        sprite_factory: Callable[[], Any] | None = None,
        config: SecureConfig | None = None,
    ) -> None:
        if sprite is None and sprite_factory is None:
            raise ValueError("SpritesSandboxClient requires sprite or sprite_factory")
        self._sprite = sprite
        self._sprite_factory = sprite_factory
        self._config = config or sprites_defaults()

    def _resolve_sprite(self) -> Any:
        if self._sprite is not None:
            return self._sprite
        if self._sprite_factory is not None:
            return self._sprite_factory()
        raise ValueError("SpritesSandboxClient requires sprite or sprite_factory")

    async def _secure_session(
        self,
        *,
        snapshot: SnapshotSpec | SnapshotBase | None,
        manifest: Manifest | None,
        options: UnsupportedProviderClientOptions | None,
    ) -> SandboxSession:
        snapshot_id = str(uuid4())
        resolved_snapshot = resolve_snapshot(snapshot, snapshot_id)
        effective_manifest = manifest or Manifest(root=self._config.workspace or "/home/sprite")
        effective_config = _config_for_manifest(self._config, effective_manifest)
        state = UnsupportedProviderSessionState(
            provider="sprites",
            handle=options.handle if options else None,
            manifest=effective_manifest,
            snapshot=resolved_snapshot,
        )
        secured = await secure_sandbox(
            sprites(self._resolve_sprite()),
            effective_config,
        )
        secure_inner = _SecuredAdapterSession(state=state, secured_sandbox=secured)
        return self._wrap_session(secure_inner)

    async def create(
        self,
        *,
        snapshot: SnapshotSpec | SnapshotBase | None = None,
        manifest: Manifest | None = None,
        options: UnsupportedProviderClientOptions | None,
    ) -> SandboxSession:
        return await self._secure_session(snapshot=snapshot, manifest=manifest, options=options)

    async def resume(self, state: SandboxSessionState) -> SandboxSession:
        validated_state = UnsupportedProviderSessionState.model_validate(state.model_dump())
        effective_config = _config_for_manifest(self._config, validated_state.manifest)
        secured = await secure_sandbox(
            sprites(self._resolve_sprite()),
            effective_config,
        )
        secure_inner = _SecuredAdapterSession(
            state=validated_state,
            secured_sandbox=secured,
        )
        return self._wrap_session(secure_inner)

    async def delete(self, session: SandboxSession) -> SandboxSession:
        await session.shutdown()
        return session

    def serialize_session_state(self, state: SandboxSessionState) -> dict[str, object]:
        return state.model_dump(mode="json")

    def deserialize_session_state(self, payload: dict[str, object]) -> UnsupportedProviderSessionState:
        return UnsupportedProviderSessionState.model_validate(payload)


class ExeSandboxClient(BaseSandboxClient[UnsupportedProviderClientOptions | None]):
    backend_id = "agentsh-secure:exe"
    supports_default_options = True

    def __init__(
        self,
        vm_name: str,
        *,
        config: SecureConfig | None = None,
    ) -> None:
        if not vm_name:
            raise ValueError("ExeSandboxClient requires vm_name")
        self._vm_name = vm_name
        self._config = config or exe_defaults()

    def _resolve_vm_name(self, state: UnsupportedProviderSessionState | None = None) -> str:
        if state is not None and state.handle:
            return state.handle
        return self._vm_name

    async def _secure_session(
        self,
        *,
        snapshot: SnapshotSpec | SnapshotBase | None,
        manifest: Manifest | None,
        options: UnsupportedProviderClientOptions | None,
        state_handle: str,
    ) -> SandboxSession:
        snapshot_id = str(uuid4())
        resolved_snapshot = resolve_snapshot(snapshot, snapshot_id)
        effective_manifest = manifest or Manifest(root=self._config.workspace or "/workspace")
        effective_config = _config_for_manifest(self._config, effective_manifest)
        state = UnsupportedProviderSessionState(
            provider="exe",
            handle=state_handle,
            manifest=effective_manifest,
            snapshot=resolved_snapshot,
        )
        secured = await secure_sandbox(
            exe(state_handle),
            effective_config,
        )
        secure_inner = _SecuredAdapterSession(state=state, secured_sandbox=secured)
        return self._wrap_session(secure_inner)

    async def create(
        self,
        *,
        snapshot: SnapshotSpec | SnapshotBase | None = None,
        manifest: Manifest | None = None,
        options: UnsupportedProviderClientOptions | None,
    ) -> SandboxSession:
        del options
        return await self._secure_session(
            snapshot=snapshot,
            manifest=manifest,
            options=None,
            state_handle=self._vm_name,
        )

    async def resume(self, state: SandboxSessionState) -> SandboxSession:
        parsed_state = UnsupportedProviderSessionState.model_validate(state.model_dump())
        state_handle = parsed_state.handle or self._vm_name
        if parsed_state.handle is None:
            parsed_state = parsed_state.model_copy(update={"handle": state_handle})
        effective_config = _config_for_manifest(self._config, parsed_state.manifest)
        secured = await secure_sandbox(
            exe(state_handle),
            effective_config,
        )
        secure_inner = _SecuredAdapterSession(
            state=parsed_state,
            secured_sandbox=secured,
        )
        return self._wrap_session(secure_inner)

    async def delete(self, session: SandboxSession) -> SandboxSession:
        await session.shutdown()
        return session

    def serialize_session_state(self, state: SandboxSessionState) -> dict[str, object]:
        return state.model_dump(mode="json")

    def deserialize_session_state(self, payload: dict[str, object]) -> UnsupportedProviderSessionState:
        return UnsupportedProviderSessionState.model_validate(payload)


class FreestyleSandboxClient(BaseSandboxClient[UnsupportedProviderClientOptions | None]):
    backend_id = "agentsh-secure:freestyle"
    supports_default_options = True

    def __init__(
        self,
        *,
        client: Any | None = None,
        vm_resolver: Callable[[str], Awaitable[Any]] | None = None,
        config: SecureConfig | None = None,
    ) -> None:
        self._client = client
        self._owns_client = client is None
        self._vm_resolver = vm_resolver
        self._config = config or freestyle_defaults()

    def _resolve_client(self) -> Any:
        if self._client is None:
            self._client = FreestyleClient()
            self._owns_client = True
        return self._client

    @staticmethod
    def _resolve_handle_from_vm(vm: Any) -> str:
        handle = getattr(vm, "id", None) or getattr(vm, "vm_id", None)
        if handle:
            return str(handle)
        return f"freestyle-{uuid4().hex}"

    async def _secure_session(
        self,
        *,
        vm: Any,
        snapshot: SnapshotSpec | SnapshotBase | None,
        manifest: Manifest | None,
        handle: str,
    ) -> SandboxSession:
        snapshot_id = str(uuid4())
        resolved_snapshot = resolve_snapshot(snapshot, snapshot_id)
        effective_manifest = manifest or Manifest(root=self._config.workspace or "/workspace")
        effective_config = _config_for_manifest(self._config, effective_manifest)
        state = UnsupportedProviderSessionState(
            provider="freestyle",
            handle=handle,
            manifest=effective_manifest,
            snapshot=resolved_snapshot,
        )
        secured = await secure_sandbox(
            freestyle(vm),
            effective_config,
        )
        secure_inner = _SecuredAdapterSession(state=state, secured_sandbox=secured)
        return self._wrap_session(secure_inner)

    async def create(
        self,
        *,
        snapshot: SnapshotSpec | SnapshotBase | None = None,
        manifest: Manifest | None = None,
        options: UnsupportedProviderClientOptions | None,
    ) -> SandboxSession:
        del options
        client = self._resolve_client()
        vm = await client.create_sandbox_vm()
        handle = self._resolve_handle_from_vm(vm)
        return await self._secure_session(
            vm=vm,
            snapshot=snapshot,
            manifest=manifest,
            handle=handle,
        )

    async def resume(self, state: SandboxSessionState) -> SandboxSession:
        parsed_state = UnsupportedProviderSessionState.model_validate(state.model_dump())
        if not parsed_state.handle or self._vm_resolver is None:
            raise ValueError("FreestyleSandboxClient.resume requires vm_resolver and state.handle")
        vm_or_awaitable = self._vm_resolver(parsed_state.handle)
        if not inspect.isawaitable(vm_or_awaitable):
            raise TypeError("vm_resolver must return an awaitable")
        vm = await vm_or_awaitable
        effective_config = _config_for_manifest(self._config, parsed_state.manifest)
        secured = await secure_sandbox(
            freestyle(vm),
            effective_config,
        )
        secure_inner = _SecuredAdapterSession(
            state=parsed_state,
            secured_sandbox=secured,
        )
        return self._wrap_session(secure_inner)

    async def delete(self, session: SandboxSession) -> SandboxSession:
        shutdown_error: BaseException | None = None
        try:
            await session.shutdown()
        except BaseException as exc:
            shutdown_error = exc

        close_error: BaseException | None = None
        try:
            if self._owns_client and self._client is not None:
                aclose = getattr(self._client, "aclose", None)
                if aclose is not None:
                    result = aclose()
                    if inspect.isawaitable(result):
                        await result
        except BaseException as exc:
            close_error = exc
        finally:
            if self._owns_client:
                self._client = None
                self._owns_client = False

        if shutdown_error is not None and close_error is not None:
            if isinstance(shutdown_error, Exception) and isinstance(close_error, Exception):
                raise ExceptionGroup(
                    "FreestyleSandboxClient.delete failed",
                    [shutdown_error, close_error],
                )
            raise BaseExceptionGroup(
                "FreestyleSandboxClient.delete failed",
                [shutdown_error, close_error],
            )
        if shutdown_error is not None:
            raise shutdown_error
        if close_error is not None:
            raise close_error
        return session

    def serialize_session_state(self, state: SandboxSessionState) -> dict[str, object]:
        return state.model_dump(mode="json")

    def deserialize_session_state(self, payload: dict[str, object]) -> UnsupportedProviderSessionState:
        return UnsupportedProviderSessionState.model_validate(payload)
