# src/agentsh_secure_sandbox/_api.py
from __future__ import annotations
from .core.types import SandboxAdapter, SecuredSandbox, SecureConfig
from .core.provision import provision
from .core.runtime import create_secured_sandbox


async def secure_sandbox(
    adapter: SandboxAdapter,
    config: SecureConfig | None = None,
) -> SecuredSandbox:
    cfg = config or SecureConfig()
    result = await provision(adapter, cfg)
    return create_secured_sandbox(
        adapter,
        result.session_id,
        result.security_mode,
        passthrough=result.passthrough,
    )
