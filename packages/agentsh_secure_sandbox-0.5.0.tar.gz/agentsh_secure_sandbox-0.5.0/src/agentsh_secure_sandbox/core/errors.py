"""Error hierarchy for agentsh-secure-sandbox."""

from __future__ import annotations

from typing import Any


class AgentSHError(Exception):
    """Base exception for all agentsh-secure-sandbox errors."""


class PolicyValidationError(AgentSHError):
    """Policy failed Pydantic validation."""

    def __init__(self, errors: list[Any]) -> None:
        self.errors = errors
        summaries = "; ".join(str(e) for e in errors)
        super().__init__(f"Policy validation failed: {summaries}")


class ProvisioningError(AgentSHError):
    """A provisioning step failed."""

    def __init__(self, *, phase: str, command: str, stderr: str):
        self.phase = phase
        self.command = command
        self.stderr = stderr
        super().__init__(f"Provisioning failed at phase: {phase}")


class IntegrityError(AgentSHError):
    """Binary checksum mismatch."""

    def __init__(self, *, expected: str, actual: str, message: str | None = None):
        self.expected = expected
        self.actual = actual
        super().__init__(message or f"Checksum mismatch: expected {expected}, got {actual}")


class TransportError(AgentSHError):
    """agentsh exec transport failure (binary not found, not a policy denial)."""

    def __init__(self, *, session_id: str, command: str, stderr: str):
        self.session_id = session_id
        self.command = command
        self.stderr = stderr
        super().__init__(f"agentsh exec failed (session {session_id})")


class RuntimeError(AgentSHError):
    """agentsh exec runtime failure."""

    def __init__(self, *, session_id: str, command: str, stderr: str):
        self.session_id = session_id
        self.command = command
        self.stderr = stderr
        super().__init__(f"agentsh exec failed (session {session_id})")
