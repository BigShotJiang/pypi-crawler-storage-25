from .core.integrity import PINNED_VERSION  # noqa: F401

__version__ = "0.5.0"
