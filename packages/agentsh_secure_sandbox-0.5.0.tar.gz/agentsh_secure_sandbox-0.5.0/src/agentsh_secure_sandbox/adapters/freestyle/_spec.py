"""FreestyleVmSpec — wire-format builder for the Freestyle VMs API.

Structure, field names, and transforms verified against the
``freestyle-sandboxes`` 0.1.42 npm package source (``package/index.mjs``).
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class FreestyleFile(BaseModel):
    """A file to inject into the VM snapshot."""

    model_config = ConfigDict(extra="allow")

    content: str
    encoding: Literal["utf-8", "base64"] = "utf-8"


class FreestyleSystemdService(BaseModel):
    """A systemd unit definition.

    Either ``bash`` or ``exec_`` must be set; if both are set, the
    wire-format transform in ``FreestyleVmSpec.to_request_body`` will
    move the bash script into a file and rewrite ``exec_``.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    name: str
    mode: Literal[
        "simple", "oneshot", "forking", "notify", "idle", "service"
    ] = "service"
    bash: str | None = None
    exec_: list[str] | None = Field(None, alias="exec")
    description: str | None = None
    after: list[str] | None = None
    requires: list[str] | None = None
    wanted_by: list[str] | None = Field(None, alias="wantedBy")
    restart: Literal[
        "no",
        "always",
        "on-success",
        "on-failure",
        "on-abnormal",
        "on-watchdog",
        "on-abort",
    ] | None = None
    restart_sec: int | None = Field(None, alias="restartSec")
    delete_after_success: bool | None = Field(None, alias="deleteAfterSuccess")
    timeout_sec: int | None = Field(None, alias="timeoutSec")
    environment: dict[str, str] | None = None


class FreestyleSystemdConfig(BaseModel):
    """Systemd configuration block — currently just a services list."""

    model_config = ConfigDict(extra="allow")

    services: list[FreestyleSystemdService] | None = None


class FreestyleVmSpec(BaseModel):
    """Wire-format builder for Freestyle VM specs.

    Mirrors the fluent JavaScript ``VmSpec`` class from
    ``freestyle-sandboxes``. All fields default to ``None`` so only
    the values you set appear on the wire.

    Direct field assignment works: ``spec.workdir = "/app"``. Fluent
    builders are also provided for common chains: ``apt_deps_add``,
    ``additional_files_add``, ``idle_timeout_seconds_``, ``workdir_``,
    and the layer operator ``snapshot()``. ``with_systemd_service``
    and the wire-format serializer ``to_request_body`` are added in
    subsequent tasks.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    apt_deps: list[str] | None = Field(None, alias="aptDeps")
    additional_files: dict[str, FreestyleFile] | None = Field(
        None, alias="additionalFiles"
    )
    systemd: FreestyleSystemdConfig | None = None
    snapshot_: "FreestyleVmSpec | None" = Field(None, alias="snapshot")

    idle_timeout_seconds: int | None = Field(None, alias="idleTimeoutSeconds")
    ready_signal_timeout_seconds: int | None = Field(
        None, alias="readySignalTimeoutSeconds"
    )
    wait_for_ready_signal: bool | None = Field(None, alias="waitForReadySignal")
    workdir: str | None = None
    base_image: str | None = Field(None, alias="baseImage")
    discriminator: str | None = None
    skip_cache: bool | None = Field(None, alias="skipCache")
    rootfs_size_gb: int | None = Field(None, alias="rootfsSizeGb")
    mem_size_gb: int | None = Field(None, alias="memSizeGb")
    vcpu_count: int | None = Field(None, alias="vcpuCount")
    ports: list[int] | None = None

    # ── Fluent builder methods ────────────────────────────

    def snapshot(self) -> "FreestyleVmSpec":
        """Move the current outer layer into a new inner snapshot.

        After this call, ``self.snapshot_`` holds a new
        ``FreestyleVmSpec`` containing the previous values for all
        outer fields (including any ``extra="allow"`` extras), and
        the outer layer is cleared. Returns ``self`` for chaining.
        """
        inner = FreestyleVmSpec.model_validate(
            self.model_dump(by_alias=False, exclude_none=True)
        )
        # Reset every declared outer field to its default (None)…
        for name in type(self).model_fields:
            setattr(self, name, None)
        # …and also drop any ``extra="allow"`` fields that would
        # otherwise persist on the outer layer and get duplicated
        # into the inner snapshot through model_dump.
        if self.__pydantic_extra__ is not None:
            self.__pydantic_extra__.clear()
        self.snapshot_ = inner
        return self

    def apt_deps_add(self, *pkgs: str) -> "FreestyleVmSpec":
        """Append packages to ``apt_deps``. De-duplicates, keeps order."""
        current = list(self.apt_deps or [])
        for p in pkgs:
            if p not in current:
                current.append(p)
        self.apt_deps = current
        return self

    def additional_files_add(
        self,
        files: dict[str, str | bytes | FreestyleFile],
    ) -> "FreestyleVmSpec":
        """Merge files into ``additional_files``.

        Values can be:
        - ``str``: stored as utf-8
        - ``bytes``: stored as base64
        - ``FreestyleFile``: stored as-is
        """
        import base64 as _b64

        current: dict[str, FreestyleFile] = dict(self.additional_files or {})
        for path, value in files.items():
            if isinstance(value, FreestyleFile):
                current[path] = value
            elif isinstance(value, bytes):
                current[path] = FreestyleFile(
                    content=_b64.b64encode(value).decode("ascii"),
                    encoding="base64",
                )
            else:
                current[path] = FreestyleFile(content=value, encoding="utf-8")
        self.additional_files = current
        return self

    def idle_timeout_seconds_(self, seconds: int) -> "FreestyleVmSpec":
        """Set ``idle_timeout_seconds``. Trailing underscore disambiguates from the field."""
        self.idle_timeout_seconds = seconds
        return self

    def workdir_(self, path: str) -> "FreestyleVmSpec":
        """Set ``workdir``. Trailing underscore for consistency with other setters."""
        self.workdir = path
        return self

    def with_systemd_service(
        self,
        name: str,
        **fields: Any,
    ) -> "FreestyleVmSpec":
        """Append a systemd service definition.

        Field names accept both the Python attribute form and the
        camelCase wire form (e.g., ``wanted_by=...`` or
        ``wantedBy=...``). Use ``exec=[...]`` to set the command list
        (the ``exec_`` field's alias).
        """
        service = FreestyleSystemdService.model_validate({"name": name, **fields})
        if self.systemd is None:
            self.systemd = FreestyleSystemdConfig(services=[])
        if self.systemd.services is None:
            self.systemd.services = []
        self.systemd.services.append(service)
        return self

    # ── Wire-format serialization ────────────────────────

    def to_request_body(self) -> dict[str, Any]:
        """Serialize to camelCase wire format with systemd preprocessing.

        Matches the ``freestyle-sandboxes`` 0.1.42 behavior:

        1. For each systemd service with a ``bash`` field, move the
           script into ``additional_files`` at
           ``/opt/freestyle/scripts/<name>.sh`` (prepending a
           ``#!/bin/bash`` shebang if missing) and replace ``bash`` with
           ``exec = ["/bin/bash /opt/freestyle/scripts/<name>.sh"]``.
        2. For bare names in ``after``/``requires``/``wanted_by`` that
           don't contain a dot, append ``.service``.
        3. Recursively apply to ``snapshot_``.
        4. Serialize with camelCase aliases via Pydantic.
        """
        clone = self.model_copy(deep=True)
        clone._preprocess_systemd_in_place()
        return clone.model_dump(by_alias=True, exclude_none=True, mode="json")

    def _preprocess_systemd_in_place(self) -> None:
        """Apply wire-format transforms to self (mutates)."""
        if self.snapshot_ is not None:
            self.snapshot_._preprocess_systemd_in_place()

        if self.systemd is None or self.systemd.services is None:
            return

        files: dict[str, FreestyleFile] = dict(self.additional_files or {})
        for svc in self.systemd.services:
            # 1. bash → script file + exec
            if svc.bash is not None:
                script = svc.bash
                if not script.startswith("#!"):
                    script = "#!/bin/bash\n" + script
                script_path = f"/opt/freestyle/scripts/{svc.name}.sh"
                files[script_path] = FreestyleFile(
                    content=script, encoding="utf-8"
                )
                svc.exec_ = [f"/bin/bash {script_path}"]
                svc.bash = None

            # 2. .service suffix for bare names
            for attr in ("after", "requires", "wanted_by"):
                values = getattr(svc, attr)
                if not values:
                    continue
                setattr(
                    svc,
                    attr,
                    [
                        v if "." in v else f"{v}.service"
                        for v in values
                    ],
                )

        if files:
            self.additional_files = files


FreestyleVmSpec.model_rebuild()
