"""FreestyleVm — bound to a single VM by vm_id.

Wraps ``FreestyleClient`` with per-VM convenience methods (exec, read/
write file, stop, health check). Instances are created by the
``VmsNamespace`` in ``_client.py`` — you don't construct them directly.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ._client import FreestyleClient


class FreestyleVm:
    """A Freestyle VM bound to a ``vm_id``."""

    def __init__(self, client: "FreestyleClient", vm_id: str, raw: dict[str, Any] | None = None) -> None:
        self._client = client
        self.vm_id = vm_id
        self.raw = raw or {}

    async def exec(
        self,
        command: str,
        *,
        terminal: str | None = None,
        timeout_ms: int | None = None,
    ) -> dict[str, Any]:
        """Run a single shell command via ``POST /v1/vms/{id}/exec-await``.

        Returns the raw response dict (``stdout``, ``stderr``,
        ``statusCode``). The adapter in ``_adapter.py`` is responsible
        for mapping this into ``ExecResult``.
        """
        body = {
            "command": command,
            "terminal": terminal,
            "timeoutMs": timeout_ms,
        }
        return await self._client._post(
            f"/v1/vms/{self.vm_id}/exec-await",
            json=body,
        )

    async def write_file(self, path: str, content: str | bytes) -> None:
        """Write a file via ``PUT /v1/vms/{id}/files/{path}`` (base64-encoded)."""
        import base64 as _b64

        data = content.encode("utf-8") if isinstance(content, str) else content
        body = {
            "content": _b64.b64encode(data).decode("ascii"),
            "encoding": "base64",
        }
        await self._client._put(self._file_url(path), json=body)

    async def read_file(self, path: str) -> str:
        """Read a file via ``GET /v1/vms/{id}/files/{path}``.

        Returns the decoded string. The API may return
        ``{content, encoding: "base64"}`` or ``{content, encoding: "utf-8"}``.
        """
        import base64 as _b64

        response = await self._client._get(self._file_url(path))
        content: str = response.get("content", "")
        encoding = response.get("encoding", "utf-8")
        if encoding == "base64":
            return _b64.b64decode(content).decode("utf-8")
        return content

    async def file_exists(self, path: str) -> bool:
        """Returns True iff ``test -e <path>`` exits 0. Never raises."""
        # Import here to avoid a top-level circular import.
        from ._client import FreestyleError

        try:
            import shlex as _shlex

            result = await self.exec(f"test -e {_shlex.quote(path)}")
            return bool(result.get("statusCode", 1) == 0)
        except FreestyleError:
            return False

    async def stop(self) -> None:
        """Stop the VM (POST ``/v1/vms/{id}/stop``)."""
        await self._client._post(f"/v1/vms/{self.vm_id}/stop")

    async def wait_for_agentsh_install(
        self,
        *,
        timeout: float = 120.0,
        poll_interval: float = 1.0,
    ) -> None:
        """Poll until the ``install-agentsh`` systemd service has finished.

        The VM snapshot only *installs* agentsh at boot (via ``dpkg -i``);
        it does not start a server, write policies, or install the shell
        shim — those steps are owned by :func:`provision` and happen
        per-session. This method waits for the install marker file
        (``/var/lib/agentsh/.install-complete``) that the install script
        touches at the very end, then confirms the ``agentsh`` binary is
        executable by running ``agentsh --version``.

        On timeout, attempts to tail
        ``/var/log/install-agentsh.log`` (systemd journal of the install
        service may be written there) for context. Raises
        ``FreestyleError`` on timeout.
        """
        import asyncio

        from ._client import FreestyleError

        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout
        while loop.time() < deadline:
            try:
                marker = await self.exec(
                    "test -f /var/lib/agentsh/.install-complete && echo ok",
                    timeout_ms=5000,
                )
                marker_ok = (marker.get("statusCode") or 0) == 0 and "ok" in (
                    marker.get("stdout") or ""
                )
                if marker_ok:
                    version = await self.exec(
                        "agentsh --version",
                        timeout_ms=5000,
                    )
                    if (version.get("statusCode") or 0) == 0:
                        return
            except FreestyleError:
                pass  # transient — VM may still be booting
            await asyncio.sleep(poll_interval)

        # Timeout: attempt to grab systemd install-agentsh status for diagnostics.
        diag = ""
        try:
            status = await self.exec(
                "systemctl status install-agentsh.service --no-pager 2>&1 "
                "|| journalctl -u install-agentsh.service --no-pager -n 40 2>&1 "
                "|| echo 'no install-agentsh status'",
                timeout_ms=5000,
            )
            diag = status.get("stdout") or ""
        except FreestyleError:
            pass
        raise FreestyleError(
            f"agentsh install did not complete within {timeout}s on vm "
            f"{self.vm_id}. install-agentsh status:\n{diag}"
        )

    def _file_url(self, path: str) -> str:
        """Build the URL for a file operation.

        Matches the ``freestyle-sandboxes`` SDK which uses
        ``encodeURIComponent`` to substitute the ``{filepath}``
        path parameter — this percent-encodes slashes too, so
        ``/tmp/file.txt`` becomes ``%2Ftmp%2Ffile.txt`` in the
        final URL.
        """
        from urllib.parse import quote

        # safe="" encodes everything including slashes, matching JS encodeURIComponent
        encoded = quote(path, safe="")
        return f"/v1/vms/{self.vm_id}/files/{encoded}"
