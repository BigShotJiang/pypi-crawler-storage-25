"""Security defaults and spec configuration for Freestyle VMs.

Mirrors the TypeScript adapter's ``freestyleDefaults()`` and
``configureFreestyleSpec()`` from ``secure-sandbox/src/adapters/freestyle.ts``.
"""
# mypy: disable-error-code="list-item"

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from ...core.types import (
    ApprovalsConfig,
    AuditConfig,
    CgroupsConfig,
    DevelopmentConfig,
    DlpConfig,
    DlpCustomPattern,
    FileMonitorConfig,
    FuseConfig,
    GrpcConfig,
    HealthConfig,
    LoggingConfig,
    MetricsConfig,
    NetworkInterceptConfig,
    ProxyConfig,
    SandboxLimitsConfig,
    SeccompDetailsConfig,
    SecureConfig,
    ServerConfig,
    ServerTimeoutsConfig,
    SessionsConfig,
    UnixSocketsConfig,
)
from ...policies.schema import (
    AuditSettings,
    EnvPolicy,
    PolicyDefinition,
    ResourceLimits,
)
from ._spec import FreestyleVmSpec


_SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+(?:-[a-zA-Z0-9.-]+)?$")


_INSTALL_SCRIPT_TEMPLATE = """\
#!/bin/bash
set -eux
AGENTSH_VERSION="{version}"
URL="https://github.com/canyonroad/agentsh/releases/download/v${{AGENTSH_VERSION}}/agentsh_${{AGENTSH_VERSION}}_linux_amd64.tar.gz"
curl -fsSL "${{URL}}" -o /tmp/agentsh.tar.gz
tar xz -C /tmp/ -f /tmp/agentsh.tar.gz
install -m 0755 /tmp/agentsh /usr/local/bin/agentsh
install -m 0755 /tmp/agentsh-shell-shim /usr/bin/agentsh-shell-shim
install -m 0755 /tmp/agentsh-unixwrap /usr/local/bin/agentsh-unixwrap
rm -f /tmp/agentsh.tar.gz /tmp/agentsh /tmp/agentsh-shell-shim /tmp/agentsh-unixwrap
agentsh --version
mkdir -p /etc/agentsh/system /var/lib/agentsh/quarantine /var/lib/agentsh/sessions /var/log/agentsh /home/user
chmod 755 /etc/agentsh /etc/agentsh/system /var/lib/agentsh /var/lib/agentsh/quarantine /var/lib/agentsh/sessions /var/log/agentsh
# Minimal server config so agentsh v0.18.2+ can start before provision
# writes the real config. The provision flow overwrites this file.
cat > /etc/agentsh/config.yml << 'AGENTSH_CFG'
server:
  http:
    addr: "127.0.0.1:18080"
auth:
  type: none
policies:
  system_dir: /etc/agentsh/system
  dir: /etc/agentsh
  default: agent_default
workspace: /home/user
sandbox:
  enabled: true
  allow_degraded: true
  fuse:
    enabled: false
  network:
    enabled: true
  seccomp:
    enabled: false
sessions:
  base_dir: /var/lib/agentsh/sessions
AGENTSH_CFG
# Sudoers: allow root to run agentsh and fuse helpers with env preservation
# (provision flow uses sudo -E via the adapter)
echo "root ALL=(ALL) NOPASSWD:SETENV: /usr/local/bin/agentsh, /usr/local/bin/agentsh *" >> /etc/sudoers
echo "root ALL=(ALL) NOPASSWD:SETENV: /bin/chmod, /bin/chmod *" >> /etc/sudoers
echo "root ALL=(ALL) NOPASSWD:SETENV: /bin/mknod /dev/fuse c 10 229" >> /etc/sudoers
echo "user_allow_other" >> /etc/fuse.conf
touch /var/lib/agentsh/.install-complete
"""


_STARTUP_SCRIPT_TEMPLATE = """\
#!/bin/bash
# Restrict /dev/fuse to prevent any FUSE mount during snapshot.
# Provision will chmod /dev/fuse 666 before the first exec that needs FUSE.
sudo /bin/chmod 600 /dev/fuse 2>/dev/null || true

# Start agentsh server in background (deferred FUSE: mounts on first exec)
# v0.18.2+ requires an explicit --config; the install phase writes a minimal
# config.yml that the provision flow later overwrites with the real one.
/usr/local/bin/agentsh server --config /etc/agentsh/config.yml >> /var/log/agentsh/server.log 2>&1 &
SERVER_PID=$!

# Wait for server to be ready (health check loop)
for i in $(seq 1 15); do
  if curl -sf http://127.0.0.1:18080/health >/dev/null 2>&1; then break; fi
  sleep 1
done

# Install shell shim (replaces /bin/bash with agentsh shim)
sudo /usr/local/bin/agentsh shim install-shell --root / --shim /usr/bin/agentsh-shell-shim --bash --i-understand-this-modifies-the-host

# Warm up the shim
/bin/bash -c "echo shim warmup ok" 2>/dev/null || true

echo "agentsh ready"

# Keep the script alive so systemd does not kill the service cgroup
wait $SERVER_PID
"""


@dataclass(frozen=True)
class FreestyleConfigureOptions:
    """Options for :func:`configure_freestyle_spec`."""

    agentsh_version: str = "0.18.2"
    server_port: int = 18080


def freestyle_defaults() -> SecureConfig:
    """Return Freestyle-optimized defaults for :class:`SecureConfig`.

    Matches the TypeScript ``freestyleDefaults()``:

    - ``install_strategy="preinstalled"`` — spec is baked into the VM
      snapshot via :func:`configure_freestyle_spec`.
    - ``allow_degraded=True`` — Freestyle kernels lack Yama, so the
      ptrace file monitor can't attach. Agentsh settles into ``minimal``
      security mode.
    - FUSE deferred mode — ``/dev/fuse`` is 600 in the snapshot; it's
      chmod'd 666 at first session start.
    - ``seccomp.file_monitor=False`` — depends on kernel features
      Freestyle doesn't guarantee.
    """
    server_config = ServerConfig(
        grpc=GrpcConfig(addr="127.0.0.1:9090"),
        server_timeouts=ServerTimeoutsConfig(
            read_timeout="30s", write_timeout="60s", max_request_size="10MB",
        ),
        logging=LoggingConfig(level="info", format="text", output="stderr"),
        sessions=SessionsConfig(
            base_dir="/var/lib/agentsh/sessions",
            max_sessions=100,
            default_timeout="1h",
            idle_timeout="15m",
            cleanup_interval="5m",
        ),
        audit=AuditConfig(enabled=True, sqlite_path="/var/lib/agentsh/events.db"),
        sandbox_limits=SandboxLimitsConfig(
            max_memory_mb=4096, max_cpu_percent=100, max_processes=256,
        ),
        allow_degraded=True,
        fuse=FuseConfig(
            deferred=True,
            deferred_marker_file="/tmp/.agentsh-fuse-enabled",
            deferred_enable_command=["sudo", "/bin/chmod", "666", "/dev/fuse"],
        ),
        network_intercept=NetworkInterceptConfig(
            intercept_mode="all", proxy_listen_addr="127.0.0.1:0",
        ),
        seccomp_details=SeccompDetailsConfig(
            execve=True,
            file_monitor=FileMonitorConfig(enabled=False, enforce_without_fuse=False),
        ),
        cgroups=CgroupsConfig(enabled=True),
        unix_sockets=UnixSocketsConfig(enabled=True),
        env_inject={"BASH_ENV": "/usr/lib/agentsh/bash_startup.sh"},
        proxy=ProxyConfig(
            mode="embedded",
            port=0,
            providers={
                "anthropic": "https://api.anthropic.com",
                "openai": "https://api.openai.com",
            },
        ),
        dlp=DlpConfig(
            mode="redact",
            patterns={
                "email": True, "phone": True, "credit_card": True,
                "ssn": True, "api_keys": True,
            },
            custom_patterns=[
                DlpCustomPattern(
                    name="openai_key", display="OPENAI_KEY", regex=r"sk-[a-zA-Z0-9]{48,}",
                ),
                DlpCustomPattern(
                    name="anthropic_key",
                    display="ANTHROPIC_KEY",
                    regex=r"sk-ant-[a-zA-Z0-9-]{95,}",
                ),
                DlpCustomPattern(
                    name="aws_access_key", display="AWS_KEY", regex=r"AKIA[0-9A-Z]{16}",
                ),
                DlpCustomPattern(
                    name="github_pat", display="GITHUB_TOKEN", regex=r"ghp_[a-zA-Z0-9]{36}",
                ),
                DlpCustomPattern(
                    name="github_oauth", display="GITHUB_OAUTH", regex=r"gho_[a-zA-Z0-9]{36}",
                ),
                DlpCustomPattern(
                    name="jwt_token",
                    display="JWT",
                    regex=r"eyJ[a-zA-Z0-9_-]*\.eyJ[a-zA-Z0-9_-]*\.[a-zA-Z0-9_-]*",
                ),
                DlpCustomPattern(
                    name="private_key",
                    display="PRIVATE_KEY",
                    regex=r"-----BEGIN [A-Z]+ PRIVATE KEY-----",
                ),
                DlpCustomPattern(
                    name="slack_token",
                    display="SLACK_TOKEN",
                    regex=r"xox[baprs]-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}",
                ),
            ],
        ),
        approvals=ApprovalsConfig(enabled=False),
        metrics=MetricsConfig(enabled=True, path="/metrics"),
        health=HealthConfig(path="/health", readiness_path="/ready"),
        development=DevelopmentConfig(disable_auth=True, verbose_errors=False),
    )

    policy = PolicyDefinition(
        file=[
            # Deny privilege escalation binaries
            {"deny": [
                "/usr/bin/sudo", "/usr/bin/su", "/usr/bin/pkexec", "/usr/bin/doas",
                "/bin/su", "/usr/sbin/chroot", "/usr/bin/nsenter", "/usr/bin/unshare",
            ]},
            # Deny Freestyle infrastructure
            {"deny": [
                "/usr/bin/envd",
                "/usr/bin/socat",
                "/etc/systemd/**",
                "/run/systemd/**",
            ]},
            # Deny credentials
            {"deny": ["/home/user/.ssh/**", "/root/.ssh/**"]},
            {"deny": ["/home/user/.aws/**", "/root/.aws/**"]},
            {"deny": [
                "/home/user/.gcloud/**", "/home/user/.azure/**",
                "/home/user/.config/gcloud/**", "/home/user/.kube/**",
                "/root/.gcloud/**", "/root/.azure/**",
                "/root/.config/gcloud/**", "/root/.kube/**",
            ]},
            {"deny": ["**/.env", "**/.env.*"]},
            {"deny": ["/home/user/.git-credentials", "/root/.git-credentials", "**/.netrc"]},
            # Workspace: read/write
            {"allow": ["/home/user", "/home/user/**", "/workspace", "/workspace/**"],
             "ops": ["read", "open", "stat", "list", "readlink"]},
            {"allow": ["/home/user", "/home/user/**", "/workspace", "/workspace/**"],
             "ops": ["write", "create", "mkdir", "chmod", "rename"]},
            {"soft_delete": ["/home/user", "/home/user/**", "/workspace", "/workspace/**"]},
            # Temp dirs
            {"allow": ["/tmp/**", "/var/tmp/**"]},
            # System paths (read-only)
            {"allow": ["/usr/**", "/lib/**", "/lib64/**", "/bin/**", "/sbin/**"],
             "ops": ["read", "open", "stat", "list", "readlink"]},
            # Device nodes
            {"allow": [
                "/dev/null", "/dev/zero", "/dev/urandom", "/dev/random",
                "/dev/stdin", "/dev/stdout", "/dev/stderr",
                "/dev/fd/**", "/dev/pts/**", "/dev/tty",
            ], "ops": ["read", "write", "open", "stat"]},
            # Package caches
            {"allow": [
                "/home/user/.npm/**", "/home/user/.cache/**", "/home/user/.cargo/**",
                "/root/.npm/**", "/root/.cache/**", "/root/.cargo/**",
            ], "ops": ["read", "open", "stat", "list"]},
            # Sensitive /etc files
            {"deny": ["/etc/shadow", "/etc/gshadow", "/etc/sudoers", "/etc/sudoers.d/**"]},
            # /etc minimal read
            {"allow": [
                "/etc/hosts", "/etc/resolv.conf",
                "/etc/ssl/certs/**", "/etc/ca-certificates/**",
                "/etc/localtime", "/etc/timezone",
                "/etc/ld.so.cache", "/etc/ld.so.preload", "/etc/ld.so.nohwcap",
                "/etc/nsswitch.conf", "/etc/passwd", "/etc/group",
                "/etc/fuse.conf",
            ], "ops": ["read", "open", "stat", "readlink"]},
            # /proc/self for process introspection
            {"allow": ["/proc/self/**", "/proc/thread-self/**"],
             "ops": ["read", "open", "stat", "list", "readlink"]},
            # agentsh runtime
            {"allow": ["/var/lib/agentsh/**", "/var/log/agentsh/**"],
             "ops": ["read", "write", "open", "stat", "list", "readlink"]},
            # Block /proc and /sys (catch-all)
            {"deny": ["/proc/**", "/sys/**"]},
            # Default deny
            {"deny": "**"},
        ],
        network=[
            # Localhost
            {"allow_cidrs": ["127.0.0.1/32", "::1/128"]},
            # Package registries
            {"allow": ["registry.npmjs.org"], "ports": [443]},
            {"allow": ["pypi.org", "files.pythonhosted.org"], "ports": [443]},
            {"allow": ["crates.io", "static.crates.io"], "ports": [443]},
            {"allow": ["proxy.golang.org", "sum.golang.org"], "ports": [443]},
            # Block cloud metadata (SSRF)
            {"deny_cidrs": ["169.254.169.254/32", "100.100.100.200/32"]},
            # Block private/internal networks
            {"deny_cidrs": ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "169.254.0.0/16"]},
            # Block Freestyle internal events service
            {"deny_cidrs": ["192.0.2.0/24"]},
            # Block example malicious domains
            {"deny": ["evil.com", "*.evil.com"]},
            # Default deny
            {"deny": "*"},
        ],
        commands=[
            # Network tools
            {"allow": ["curl", "wget"]},
            # Safe commands
            {"allow": [
                "bash", "sh", "/bin/bash", "/bin/sh", "/usr/bin/bash", "/usr/bin/sh",
                "ls", "cat", "head", "tail", "grep", "find", "wc", "sort", "uniq",
                "diff", "pwd", "echo", "date", "which",
                "env", "printenv", "true", "false", "test", "[",
                "expr", "seq", "sh.real", "bash.real",
            ]},
            # Dev tools
            {"allow": [
                "git", "node", "npm", "python", "python3", "pip", "pip3",
                "cargo", "go", "make",
            ]},
            # Deny raw network tools
            {"deny": ["nc", "netcat", "ncat", "socat", "telnet", "ssh", "scp", "rsync"]},
            # Deny system admin
            {"deny": [
                "shutdown", "reboot", "systemctl", "service",
                "mount", "umount", "dd", "fdisk", "mkfs",
                "kill", "killall", "pkill",
            ]},
            # Deny privilege escalation
            {"deny": ["sudo", "su", "doas", "chroot", "nsenter", "unshare"]},
            # Deny Freestyle infrastructure interference
            {"deny": ["socat", "envd", "iptables", "ip6tables", "nft", "tc", "ip"]},
            # Allow all other
            {"allow": "*"},
        ],
        env_policy=EnvPolicy(
            allow=[
                "PATH", "HOME", "USER", "SHELL", "LANG", "LANG_*", "LC_*",
                "TERM", "TERM_*", "TZ", "PWD", "OLDPWD", "SHLVL", "_",
                "NODE_ENV", "NODE_PATH", "NPM_*",
                "PYTHONPATH", "VIRTUAL_ENV", "PIP_*",
                "GIT_*",
                "AGENTSH_*",
                "HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy",
                "NO_PROXY", "no_proxy",
            ],
            deny=[
                "AWS_*", "AZURE_*", "GCP_*", "GOOGLE_*",
                "OPENAI_API_KEY", "ANTHROPIC_API_KEY",
                "DATABASE_URL", "DB_*",
                "SECRET_*", "PASSWORD*", "PRIVATE_*", "API_KEY*", "TOKEN*",
            ],
            block_iteration=True,
            max_bytes=65536,
            max_keys=100,
        ),
        signal_rules=[
            {
                "name": "allow-self", "signals": ["@all"],
                "target": {"type": "self"}, "decision": "allow",
            },
            {
                "name": "allow-children", "signals": ["@all"],
                "target": {"type": "children"}, "decision": "allow",
            },
            {
                "name": "allow-session",
                "signals": ["SIGTERM", "SIGINT", "SIGHUP", "SIGUSR1", "SIGUSR2"],
                "target": {"type": "session"}, "decision": "allow",
            },
            {
                "name": "audit-parent", "signals": ["@all"],
                "target": {"type": "parent"}, "decision": "audit",
            },
            {
                "name": "deny-external-fatal", "signals": ["@fatal"],
                "target": {"type": "external"}, "decision": "deny",
                "fallback": "audit",
                "message": "Blocking signal to process outside session",
            },
            {
                "name": "deny-system", "signals": ["@all"],
                "target": {"type": "system"}, "decision": "deny",
                "fallback": "audit",
                "message": "Blocking signal to system process",
            },
        ],
        unix_socket_rules=[
            {
                "name": "deny-system-sockets",
                "paths": ["/var/run/**"],
                "operations": ["connect", "bind", "listen", "sendto"],
                "decision": "deny",
            },
        ],
        resource_limits=ResourceLimits(
            max_memory_mb=2048,
            cpu_quota_percent=50,
            pids_max=100,
            command_timeout="5m",
            session_timeout="1h",
            idle_timeout="15m",
        ),
        audit_settings=AuditSettings(
            log_allowed=True,
            log_denied=True,
            log_approved=True,
            include_stdout=True,
            include_stderr=True,
        ),
    )

    return SecureConfig(
        policy=policy,
        workspace="/home/user",
        install_strategy="preinstalled",
        real_paths=True,
        server_config=server_config,
    )


def configure_freestyle_spec(
    spec: FreestyleVmSpec | dict[str, Any],
    opts: FreestyleConfigureOptions | None = None,
) -> FreestyleVmSpec:
    """Mutate ``spec`` to bake agentsh into the VM snapshot.

    Adds apt deps plus systemd services that:

    1. ``install-agentsh`` (oneshot) — downloads the agentsh ``tar.gz``
       release, installs binaries, configures sudoers and fuse.
    2. ``agentsh`` (service) — starts the agentsh server, waits for
       health, installs the shell shim, and keeps the process alive.

    The provision flow still writes user-specific policy, config, and
    creates a session — but the server and shim are already running.

    Returns the same spec for chaining. If ``spec`` is a ``dict``, it
    is first validated into a :class:`FreestyleVmSpec`::

        spec = configure_freestyle_spec(FreestyleVmSpec().snapshot())
        vm = await client.vms.create(spec=spec)
    """
    if isinstance(spec, dict):
        spec = FreestyleVmSpec.model_validate(spec)

    options = opts or FreestyleConfigureOptions()

    if not _SEMVER_RE.match(options.agentsh_version):
        raise ValueError(
            f"configure_freestyle_spec: invalid agentsh_version "
            f"{options.agentsh_version!r}; expected semver like '0.17.0'"
        )

    install_script = _INSTALL_SCRIPT_TEMPLATE.format(
        version=options.agentsh_version,
    )
    startup_script = _STARTUP_SCRIPT_TEMPLATE

    spec.apt_deps_add(
        "ca-certificates", "curl", "jq", "libseccomp2",
        "sudo", "fuse3", "python3", "file", "sqlite3",
    )
    spec.additional_files_add({
        "/opt/install-agentsh.sh": install_script,
        "/opt/agentsh-startup.sh": startup_script,
    })
    spec.with_systemd_service(
        "install-agentsh",
        mode="oneshot",
        exec=["/bin/bash /opt/install-agentsh.sh"],
        wantedBy=["multi-user.target"],
    )
    spec.with_systemd_service(
        "agentsh",
        mode="service",
        exec=["bash /opt/agentsh-startup.sh"],
        environment={
            "AGENTSH_SERVER": "http://127.0.0.1:18080",
            "AGENTSH_SHIM_FORCE": "1",
        },
        after=["install-agentsh"],
        requires=["install-agentsh"],
        wantedBy=["multi-user.target"],
    )
    return spec
