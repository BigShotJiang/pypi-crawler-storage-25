"""Freestyle SandboxAdapter implementation.

Wraps a ``FreestyleVm`` in the ``SandboxAdapter`` protocol. All the
shell-layer plumbing (env prefixes, cwd wrapping, sudo, detached
execution) is applied client-side because the Freestyle API only
accepts a single command string.
"""

from __future__ import annotations

import shlex
from typing import TYPE_CHECKING, Any  # noqa: F401

from ...core.types import ExecOpts, ExecResult, SandboxAdapter  # noqa: F401

if TYPE_CHECKING:
    from ._vm import FreestyleVm


def _build_command(
    command: str,
    args: list[str] | None,
    opts: ExecOpts | None,
) -> str:
    """Construct the single-string shell command we send to Freestyle.

    Wrapping order inside ``bash -c '<inner>'``:
        cd <cwd> && [ENV=val ENV2=val2] [nohup] [sudo -E] <cmd> <args...> [> /dev/null 2>&1 < /dev/null &]

    - ``bash -c`` is always applied so shell features (&&, env prefix,
      background) work regardless of how Freestyle executes the string.
    - ``sudo -E`` preserves env vars (plain sudo strips them).
    - Detached commands redirect all stdio and use ``nohup`` so
      ``exec-await`` returns immediately without waiting on the child.
    """
    parts: list[str] = []

    if opts and opts.detached:
        parts.append("nohup")

    if opts and opts.sudo:
        parts.extend(["sudo", "-E"])

    parts.append(shlex.quote(command))
    if args:
        parts.extend(shlex.quote(a) for a in args)

    inner = " ".join(parts)

    if opts and opts.detached:
        inner = f"{inner} > /dev/null 2>&1 < /dev/null &"

    if opts and opts.env:
        env_prefix = " ".join(
            f"{k}={shlex.quote(v)}" for k, v in opts.env.items()
        )
        inner = f"{env_prefix} {inner}"

    if opts and opts.cwd:
        inner = f"cd {shlex.quote(opts.cwd)} && {inner}"

    return f"bash -c {shlex.quote(inner)}"


def freestyle(vm: "FreestyleVm") -> "_FreestyleAdapter":
    """Wrap a :class:`FreestyleVm` in a :class:`SandboxAdapter`.

    Use with ``secure_sandbox`` and :func:`freestyle_defaults`::

        async with FreestyleClient() as client:
            vm = await client.create_sandbox_vm()
            try:
                secured = await secure_sandbox(
                    freestyle(vm), freestyle_defaults()
                )
                await secured.exec("echo hello")
            finally:
                await vm.stop()
    """
    return _FreestyleAdapter(vm)


class _FreestyleAdapter:
    """Implements :class:`SandboxAdapter` for Freestyle VMs."""

    def __init__(self, vm: "FreestyleVm") -> None:
        self._vm = vm

    async def exec(
        self,
        cmd: str,
        args: list[str] | None = None,
        opts: ExecOpts | None = None,
    ) -> ExecResult:
        from ...core.shell import fire_and_forget
        from ._client import FreestyleError

        command = _build_command(cmd, args, opts)

        if opts and opts.detached:
            fire_and_forget(self._vm.exec(command))
            return ExecResult(stdout="", stderr="", exit_code=0)

        try:
            response = await self._vm.exec(command)
        except FreestyleError as exc:
            return ExecResult(
                stdout="",
                stderr=f"{exc}" + (f": {exc.body}" if exc.body else ""),
                exit_code=1,
            )
        return ExecResult(
            stdout=response.get("stdout") or "",
            stderr=response.get("stderr") or "",
            exit_code=response.get("statusCode") or 0,
        )

    async def write_file(
        self,
        path: str,
        content: str | bytes,
        *,
        sudo: bool = False,
    ) -> None:
        try:
            await self._vm.write_file(path, content)
        except Exception as exc:
            raise Exception(f"writeFile failed: {exc}") from exc

    async def read_file(self, path: str) -> str:
        try:
            return await self._vm.read_file(path)
        except Exception as exc:
            raise Exception(f"readFile failed: {exc}") from exc

    async def file_exists(self, path: str) -> bool:
        return await self._vm.file_exists(path)

    async def stop(self) -> None:
        await self._vm.stop()
