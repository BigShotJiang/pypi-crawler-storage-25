"""Freestyle VMs HTTP client.

Targets the ``/v1/vms/*`` endpoints on ``api.freestyle.sh``. Wire
format verified against the ``freestyle-sandboxes`` 0.1.42 npm
package (source: ``package/index.mjs``).
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Any

import httpx

from ._spec import FreestyleVmSpec
from ._vm import FreestyleVm

if TYPE_CHECKING:
    from ._defaults import FreestyleConfigureOptions


class FreestyleError(RuntimeError):
    """Raised for Freestyle API errors. Carries HTTP status + body."""

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        body: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.body = body


_DEFAULT_TIMEOUT = httpx.Timeout(connect=10.0, read=300.0, write=60.0, pool=10.0)


class FreestyleClient:
    """Async HTTP client for the Freestyle VMs API.

    Targets the endpoints used by ``freestyle-sandboxes`` 0.1.42 under
    ``/v1/vms/*``. Uses ``httpx.AsyncClient`` internally. Set
    ``FREESTYLE_API_KEY`` in the environment or pass ``api_key``.

    Usage::

        async with FreestyleClient() as client:
            vm = await client.vms.create()
            result = await vm.exec("echo hello")
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = "https://api.freestyle.sh",
        httpx_timeout: httpx.Timeout | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        key = api_key or os.environ.get("FREESTYLE_API_KEY")
        if not key:
            raise FreestyleError(
                "Freestyle api_key missing: pass api_key=... or set FREESTYLE_API_KEY"
            )
        self.api_key = key
        self.base_url = base_url.rstrip("/")
        self._http = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            timeout=httpx_timeout or _DEFAULT_TIMEOUT,
            transport=transport,
        )
        # vms namespace exposes the /v1/vms endpoint group
        self.vms = VmsNamespace(self)

    async def __aenter__(self) -> "FreestyleClient":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if not self._http.is_closed:
            await self._http.aclose()

    async def create_sandbox_vm(
        self,
        spec: "FreestyleVmSpec | dict[str, Any] | None" = None,
        opts: "FreestyleConfigureOptions | None" = None,
        *,
        install_timeout: float = 120.0,
    ) -> "FreestyleVm":
        """One-call helper: bake agentsh into a spec, create the VM, wait for install.

        Equivalent to::

            spec = configure_freestyle_spec(spec or FreestyleVmSpec().snapshot(), opts)
            vm = await self.vms.create(spec=spec)
            await vm.wait_for_agentsh_install(timeout=install_timeout)
            return vm

        The VM snapshot only *installs* agentsh; starting the server,
        writing user policies, installing the shell shim, and creating
        a session are handled by :func:`provision` per-session. That
        mirrors how the E2B / Daytona / Modal adapters behave.

        If the install check fails after ``vms.create`` succeeded, the
        freshly-created VM is stopped best-effort before the error
        propagates, so callers never leak a running (billable) VM they
        have no reference to.
        """
        # Local imports to avoid a top-level circular import.
        from ._defaults import configure_freestyle_spec as _configure

        if spec is None:
            baked = _configure(FreestyleVmSpec().snapshot(), opts)  # type: ignore[call-arg]
        elif isinstance(spec, dict):
            baked = _configure(FreestyleVmSpec.model_validate(spec).snapshot(), opts)
        else:
            baked = _configure(spec, opts)

        vm = await self.vms.create(spec=baked)
        try:
            await vm.wait_for_agentsh_install(timeout=install_timeout)
        except BaseException:
            # Best-effort cleanup; swallow secondary errors so the
            # original install failure propagates untouched.
            try:
                await vm.stop()
            except Exception:
                pass
            raise
        return vm

    # ── Internal HTTP helpers ───────────────────────────

    async def _get(
        self, path: str, *, timeout: httpx.Timeout | None = None
    ) -> dict[str, Any]:
        return await self._request("GET", path, timeout=timeout)

    async def _post(
        self,
        path: str,
        *,
        json: Any = None,
        timeout: httpx.Timeout | None = None,
    ) -> dict[str, Any]:
        return await self._request("POST", path, json=json, timeout=timeout)

    async def _put(
        self,
        path: str,
        *,
        json: Any = None,
        timeout: httpx.Timeout | None = None,
    ) -> dict[str, Any]:
        return await self._request("PUT", path, json=json, timeout=timeout)

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        timeout: httpx.Timeout | None = None,
    ) -> dict[str, Any]:
        try:
            response = await self._http.request(
                method, path, json=json, timeout=timeout
            )
        except httpx.HTTPError as exc:
            raise FreestyleError(
                f"Freestyle request failed: {method} {path}: {exc}"
            ) from exc

        if response.status_code >= 400:
            body = response.text
            raise FreestyleError(
                f"Freestyle {method} {path} returned {response.status_code}",
                status=response.status_code,
                body=body,
            )

        if not response.content:
            return {}
        try:
            parsed = response.json()
        except ValueError as exc:
            raise FreestyleError(
                f"Freestyle returned non-JSON response: {exc}",
                status=response.status_code,
                body=response.text,
            ) from exc
        return parsed if isinstance(parsed, dict) else {"data": parsed}


_log = logging.getLogger("agentsh_secure_sandbox.freestyle")


class VmsNamespace:
    """The ``/v1/vms`` endpoint group on a ``FreestyleClient``."""

    # Override for VM creation because snapshot cache-misses can take minutes
    _CREATE_TIMEOUT = httpx.Timeout(connect=10.0, read=1800.0, write=60.0, pool=10.0)
    _SLOW_CREATE_THRESHOLD_SEC = 5.0

    def __init__(self, client: "FreestyleClient") -> None:
        self._client = client

    async def create(
        self,
        spec: FreestyleVmSpec | dict[str, Any] | None = None,
    ) -> FreestyleVm:
        """Create a VM. ``spec=None`` sends an empty body.

        If the create call takes longer than ``_SLOW_CREATE_THRESHOLD_SEC``
        seconds, an INFO log is emitted noting "snapshot cache-miss likely;
        subsequent creates will be faster" — matches the TS SDK's warning.
        """
        import asyncio as _asyncio

        if spec is None:
            body: dict[str, Any] = {}
        elif isinstance(spec, dict):
            body = FreestyleVmSpec.model_validate(spec).to_request_body()
        else:
            body = spec.to_request_body()

        loop = _asyncio.get_running_loop()
        start = loop.time()
        response = await self._client._post(
            "/v1/vms", json=body, timeout=self._CREATE_TIMEOUT
        )
        elapsed = loop.time() - start
        if elapsed > self._SLOW_CREATE_THRESHOLD_SEC:
            _log.info(
                "Freestyle VM create took %.1fs: snapshot cache-miss likely; "
                "subsequent creates will be faster",
                elapsed,
            )
        return _vm_from_response(self._client, response)

    async def get(self, vm_id: str) -> FreestyleVm:
        """Fetch an existing VM by ID (calls ``GET /v1/vms/{vm_id}``)."""
        response = await self._client._get(f"/v1/vms/{vm_id}")
        return _vm_from_response(self._client, response, fallback_vm_id=vm_id)

    def ref(self, vm_id: str) -> FreestyleVm:
        """Return a FreestyleVm bound to an existing vm_id without an API call."""
        return FreestyleVm(self._client, vm_id)


def _vm_from_response(
    client: "FreestyleClient",
    response: dict[str, Any],
    *,
    fallback_vm_id: str | None = None,
) -> FreestyleVm:
    """Extract a FreestyleVm from a Freestyle create/get response.

    Handles both the envelope form ``{vm: {...}}`` and the flat form.
    """
    payload: dict[str, Any]
    if isinstance(response, dict):
        payload = response.get("vm") or response
    else:
        payload = {}
    vm_id = payload.get("vmId") or payload.get("id") or fallback_vm_id
    if not vm_id:
        raise FreestyleError(
            f"Freestyle response missing vmId: {response}"
        )
    return FreestyleVm(client, vm_id, raw=payload)
