"""Freestyle.sh VMs provider — HTTP-based adapter + snapshot baking.

See the design spec at ``docs/superpowers/specs/2026-04-07-freestyle-provider-design.md``.

Usage::

    import os
    from agentsh_secure_sandbox import secure_sandbox
    from agentsh_secure_sandbox.adapters.freestyle import (
        FreestyleClient, freestyle, freestyle_defaults,
    )

    async with FreestyleClient(api_key=os.environ["FREESTYLE_API_KEY"]) as client:
        vm = await client.create_sandbox_vm()
        try:
            adapter = freestyle(vm)
            secured = await secure_sandbox(adapter, freestyle_defaults())
            result = await secured.exec("echo hello")
        finally:
            await vm.stop()
"""

from ._adapter import freestyle
from ._client import FreestyleClient, FreestyleError, VmsNamespace
from ._defaults import (
    FreestyleConfigureOptions,
    configure_freestyle_spec,
    freestyle_defaults,
)
from ._spec import (
    FreestyleFile,
    FreestyleSystemdConfig,
    FreestyleSystemdService,
    FreestyleVmSpec,
)
from ._vm import FreestyleVm

__all__ = [
    "FreestyleClient",
    "FreestyleConfigureOptions",
    "FreestyleError",
    "FreestyleFile",
    "FreestyleSystemdConfig",
    "FreestyleSystemdService",
    "FreestyleVm",
    "FreestyleVmSpec",
    "VmsNamespace",
    "configure_freestyle_spec",
    "freestyle",
    "freestyle_defaults",
]
