# adapters/vercel.py

from __future__ import annotations
import io
import json
import tarfile
import time
from dataclasses import dataclass
from typing import Any

import httpx

from ..core.types import SandboxAdapter, ExecResult, ExecOpts


def vercel(sandbox: Any) -> SandboxAdapter:
    """
    Adapter for Vercel Sandbox.

    Accepts either a ``VercelSandbox`` instance (built-in HTTP client)
    or any object with ``run_command``, ``write_files``, ``read_file``,
    and ``stop`` methods.

    Usage::

        from agentsh_secure_sandbox.adapters.vercel import VercelSandbox, vercel

        sb = await VercelSandbox.create(token=..., project_id=..., team_id=...)
        adapter = vercel(sb)
    """
    return _VercelAdapter(sandbox)


# ─── Built-in HTTP client ─────────────────────────────────


@dataclass
class _RunResult:
    stdout: str
    stderr: str
    exit_code: int


class VercelSandbox:
    """HTTP client for the Vercel Sandbox REST API.

    Provides the interface expected by the ``vercel()`` adapter so that
    Python users don't need to write their own HTTP wrapper.

    Targets the v1 sandbox endpoints documented at
    https://vercel.com/docs/rest-api/sandboxes.
    """

    def __init__(
        self,
        *,
        token: str,
        project_id: str,
        team_id: str,
        runtime: str = "node24",
        timeout: int = 600_000,
        base_url: str = "https://api.vercel.com",
    ) -> None:
        self._token = token
        self._project_id = project_id
        self._team_id = team_id
        self._runtime = runtime
        self._timeout = timeout
        self._base = base_url
        self._client = httpx.AsyncClient(timeout=120)
        self._sandbox_id: str | None = None

    @classmethod
    async def create(
        cls,
        *,
        token: str,
        project_id: str,
        team_id: str,
        runtime: str = "node24",
        timeout: int = 600_000,
    ) -> VercelSandbox:
        """Create and provision a new Vercel sandbox."""
        sb = cls(
            token=token,
            project_id=project_id,
            team_id=team_id,
            runtime=runtime,
            timeout=timeout,
        )
        await sb._provision()
        return sb

    # ─── HTTP helpers ──────────────────────────────────────

    @property
    def _auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._token}"}

    @property
    def _team_query(self) -> dict[str, str]:
        return {"teamId": self._team_id} if self._team_id else {}

    def _sandbox_url(self, *parts: str) -> str:
        suffix = "/".join(parts)
        if self._sandbox_id is None:
            raise RuntimeError("VercelSandbox has not been provisioned")
        if suffix:
            return f"{self._base}/v1/sandboxes/{self._sandbox_id}/{suffix}"
        return f"{self._base}/v1/sandboxes/{self._sandbox_id}"

    # ─── Lifecycle ─────────────────────────────────────────

    async def _provision(self) -> None:
        res = await self._client.post(
            f"{self._base}/v1/sandboxes",
            headers=self._auth_headers,
            params=self._team_query,
            json={
                "runtime": self._runtime,
                "timeout": self._timeout,
                "projectId": self._project_id,
            },
        )
        res.raise_for_status()
        data = res.json()
        sandbox_obj = data.get("sandbox") or data
        self._sandbox_id = sandbox_obj["id"]

    async def stop(self) -> None:
        try:
            if self._sandbox_id:
                res = await self._client.post(
                    self._sandbox_url("stop"),
                    headers={
                        **self._auth_headers,
                        "Content-Type": "application/json",
                    },
                    params=self._team_query,
                    json={},
                )
                res.raise_for_status()
        finally:
            await self._client.aclose()

    # ─── Command execution ─────────────────────────────────

    async def run_command(
        self,
        cmd: str,
        args: list[str] | None = None,
        *,
        cwd: str | None = None,
        sudo: bool = False,
        detached: bool = False,
    ) -> _RunResult:
        body: dict[str, Any] = {"command": cmd, "args": args or []}
        if cwd:
            body["cwd"] = cwd
        if sudo:
            body["sudo"] = True

        res = await self._client.post(
            self._sandbox_url("cmd"),
            headers=self._auth_headers,
            params=self._team_query,
            json=body,
        )
        res.raise_for_status()
        cmd_id = res.json()["command"]["id"]

        if detached:
            return _RunResult(stdout="", stderr="", exit_code=0)

        stdout, stderr = await self._collect_command_logs(cmd_id)
        exit_code = await self._wait_for_command_exit(cmd_id)
        return _RunResult(stdout=stdout, stderr=stderr, exit_code=exit_code)

    async def _collect_command_logs(self, cmd_id: str) -> tuple[str, str]:
        """Stream ND-JSON logs for a command until the stream closes."""
        stdout_chunks: list[str] = []
        stderr_chunks: list[str] = []
        url = self._sandbox_url("cmd", cmd_id, "logs")
        async with self._client.stream(
            "GET", url, headers=self._auth_headers, params=self._team_query
        ) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                stream = entry.get("stream")
                data = entry.get("data")
                if stream == "stdout" and isinstance(data, str):
                    stdout_chunks.append(data)
                elif stream == "stderr" and isinstance(data, str):
                    stderr_chunks.append(data)
                # other entries (e.g. sandbox_stream_closed) are ignored
        return "".join(stdout_chunks), "".join(stderr_chunks)

    async def _wait_for_command_exit(
        self, cmd_id: str, *, max_wait_seconds: float = 60.0
    ) -> int:
        """Poll the command status until exitCode is non-null."""
        url = self._sandbox_url("cmd", cmd_id)
        deadline = time.monotonic() + max_wait_seconds
        delay = 0.1
        while True:
            res = await self._client.get(
                url,
                headers=self._auth_headers,
                params={**self._team_query, "wait": "true"},
            )
            res.raise_for_status()
            command = res.json().get("command", {})
            exit_code = command.get("exitCode")
            if exit_code is not None:
                return int(exit_code)
            if time.monotonic() > deadline:
                # Treat as failure rather than hanging forever
                return 1
            import asyncio

            await asyncio.sleep(delay)
            delay = min(delay * 2, 1.0)

    # ─── Filesystem ────────────────────────────────────────

    async def write_files(self, files: list[dict[str, Any]]) -> None:
        """Upload files to the sandbox via a gzipped tarball.

        Each entry must have ``path`` (absolute) and ``content`` (str or bytes).
        """
        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode="w:gz") as tar:
            for f in files:
                content = f["content"]
                if isinstance(content, str):
                    content = content.encode()
                # Tar entries are stored relative to the archive root; the
                # sandbox extracts them under the cwd we pass via x-cwd.
                arcname = f["path"].lstrip("/")
                info = tarfile.TarInfo(name=arcname)
                info.size = len(content)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(content))
        buf.seek(0)
        res = await self._client.post(
            self._sandbox_url("fs", "write"),
            headers={
                **self._auth_headers,
                "Content-Type": "application/gzip",
                "x-cwd": "/",
            },
            params=self._team_query,
            content=buf.getvalue(),
        )
        res.raise_for_status()

    async def read_file(self, path: str) -> bytes:
        res = await self._client.post(
            self._sandbox_url("fs", "read"),
            headers=self._auth_headers,
            params=self._team_query,
            json={"path": path},
        )
        res.raise_for_status()
        return res.content


# ─── Adapter ──────────────────────────────────────────────


class _VercelAdapter:
    def __init__(self, sandbox: Any) -> None:
        self._sb = sandbox

    async def exec(
        self,
        cmd: str,
        args: list[str] | None = None,
        opts: ExecOpts | None = None,
    ) -> ExecResult:
        opts = opts or ExecOpts()
        params: dict[str, Any] = {"cmd": cmd, "args": args or []}
        if opts.cwd:
            params["cwd"] = opts.cwd
        if opts.sudo:
            params["sudo"] = True
        if opts.detached:
            params["detached"] = True

        result = await self._sb.run_command(**params)

        if opts.detached:
            return ExecResult(stdout="", stderr="", exit_code=0)

        stdout = result.stdout
        if callable(stdout):
            stdout = await stdout()
        stderr = result.stderr
        if callable(stderr):
            stderr = await stderr()

        return ExecResult(
            stdout=stdout or "",
            stderr=stderr or "",
            exit_code=result.exit_code,
        )

    async def write_file(self, path: str, content: str | bytes, *, sudo: bool = False) -> None:
        # sudo is not supported by Vercel's file API — silently ignored.
        data = content if isinstance(content, bytes) else content.encode()
        await self._sb.write_files([{"path": path, "content": data}])

    async def read_file(self, path: str) -> str:
        stream = await self._sb.read_file(path)
        if hasattr(stream, "__aiter__"):
            chunks: list[bytes] = []
            async for chunk in stream:
                chunks.append(chunk if isinstance(chunk, bytes) else chunk.encode())
            return b"".join(chunks).decode("utf-8", errors="replace")
        if isinstance(stream, bytes):
            return stream.decode("utf-8", errors="replace")
        return stream if isinstance(stream, str) else str(stream)

    async def stop(self) -> None:
        await self._sb.stop()

    async def file_exists(self, path: str) -> bool:
        result = await self.exec("test", ["-f", path])
        return result.exit_code == 0
