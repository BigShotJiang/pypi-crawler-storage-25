"""Blaxel + OpenAI Agents SDK example.

Prerequisites:
    pip install agentsh-secure-sandbox[openai-agents,blaxel]
    export BL_API_KEY=...
    export OPENAI_API_KEY=...
"""
import asyncio

from blaxel_core import SandboxInstance
from agents import Agent, Runner
from agentsh_secure_sandbox import SecureSandboxAgentTools
from agentsh_secure_sandbox.adapters import blaxel


async def main() -> None:
    raw = await SandboxInstance.create({"name": "my-sandbox", "region": "us-pdx-1"})

    sandbox_tools = SecureSandboxAgentTools(blaxel(raw))

    async with sandbox_tools:
        agent = Agent(
            name="Coder",
            instructions="You are a coding assistant with access to a secure sandbox.",
            tools=sandbox_tools.get_tools(),
        )
        result = await Runner.run(
            agent,
            "Write a Python script that prints the first 10 prime numbers and run it.",
        )
        print(result.final_output)


if __name__ == "__main__":
    asyncio.run(main())
