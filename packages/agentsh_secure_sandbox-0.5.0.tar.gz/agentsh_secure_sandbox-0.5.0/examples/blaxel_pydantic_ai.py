"""Blaxel + Pydantic AI example.

Prerequisites:
    pip install agentsh-secure-sandbox[pydantic-ai,blaxel]
    export BL_API_KEY=...
"""
import asyncio

from blaxel_core import SandboxInstance
from pydantic_ai import Agent
from agentsh_secure_sandbox import SecureSandboxToolset
from agentsh_secure_sandbox.adapters import blaxel


async def main() -> None:
    raw = await SandboxInstance.create({"name": "my-sandbox", "region": "us-pdx-1"})

    toolset = SecureSandboxToolset(blaxel(raw))
    agent = Agent("claude-sonnet-4-6", toolsets=[toolset])

    async with agent:
        result = await agent.run(
            "Check what OS this sandbox is running and list installed packages."
        )
        print(result.output)


if __name__ == "__main__":
    asyncio.run(main())
