"""Daytona + OpenAI Agents SDK example.

Prerequisites:
    pip install agentsh-secure-sandbox[openai-agents,daytona]
    export DAYTONA_API_KEY=...
    export OPENAI_API_KEY=...
"""
import asyncio
from typing import Any

from daytona_sdk import AsyncDaytona
from agents import Agent, Runner
from agentsh_secure_sandbox import SecureSandboxAgentTools
from agentsh_secure_sandbox.adapters import daytona


async def _cleanup_daytona_client(client: Any, raw: object | None) -> None:
    try:
        if raw is not None:
            await client.delete(raw)
    finally:
        await client.close()


async def main() -> None:
    client: Any = AsyncDaytona()
    raw: object | None = None

    try:
        raw = await client.create()
        sandbox_tools = SecureSandboxAgentTools(daytona(raw))

        async with sandbox_tools:
            agent = Agent(
                name="Coder",
                instructions="You are a coding assistant with access to a secure sandbox.",
                tools=sandbox_tools.get_tools(),
            )
            result = await Runner.run(
                agent,
                "Create a tiny Python hello world script in /workspace/hello.py and run it.",
            )
            print(result.final_output)
    finally:
        await _cleanup_daytona_client(client, raw)


if __name__ == "__main__":
    asyncio.run(main())
