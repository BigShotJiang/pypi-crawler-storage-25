"""Daytona + Pydantic AI example.

Prerequisites:
    pip install agentsh-secure-sandbox[pydantic-ai,daytona]
    export DAYTONA_API_KEY=...        # or configure via daytona CLI
"""
import asyncio
from typing import Any

from daytona_sdk import AsyncDaytona
from pydantic_ai import Agent
from pydantic_ai.models.test import TestModel
from agentsh_secure_sandbox import SecureSandboxToolset
from agentsh_secure_sandbox.adapters import daytona


async def _cleanup_daytona_client(client: Any, raw: object | None) -> None:
    try:
        if raw is not None:
            await client.delete(raw)
    finally:
        await client.close()


class SandboxDemoTestModel(TestModel):
    def __init__(self) -> None:
        super().__init__(
            call_tools=["write_file", "run_command", "read_file"],
            custom_output_text="Created /workspace/hello.py, ran it, and verified the file contents.",
        )

    def gen_tool_args(self, tool_def: Any) -> Any:
        if tool_def.name == "write_file":
            return {
                "path": "/workspace/hello.py",
                "content": "print('Hello from Daytona!')\n",
            }
        if tool_def.name == "run_command":
            return {"command": "python3 /workspace/hello.py"}
        if tool_def.name == "read_file":
            return {"path": "/workspace/hello.py"}
        return super().gen_tool_args(tool_def)


async def main() -> None:
    client: Any = AsyncDaytona()
    raw: object | None = None

    try:
        raw = await client.create()
        toolset = SecureSandboxToolset(daytona(raw))
        agent = Agent(SandboxDemoTestModel(), toolsets=[toolset])

        async with agent:
            result = await agent.run(
                "Create a tiny Python script in /workspace/hello.py that prints "
                "'Hello from Daytona!' and then run it."
            )
            print(result.output)
    finally:
        await _cleanup_daytona_client(client, raw)


if __name__ == "__main__":
    asyncio.run(main())
