"""Runloop + Pydantic AI example.

Prerequisites:
    pip install agentsh-secure-sandbox[pydantic-ai,runloop]
    export RUNLOOP_API_KEY=...
"""
import asyncio

from runloop_api_client import Runloop
from pydantic_ai import Agent
from agentsh_secure_sandbox import SecureSandboxToolset
from agentsh_secure_sandbox.adapters import runloop, runloop_defaults


async def main() -> None:
    client = Runloop()
    devbox = await client.devboxes.create_and_await_running()

    # runloop_defaults() enables seccomp, FUSE, cgroups, and DLP patterns
    toolset = SecureSandboxToolset(
        runloop({"client": client, "id": devbox.id}),
        runloop_defaults(),
    )
    agent = Agent("claude-sonnet-4-6", toolsets=[toolset])

    async with agent:
        result = await agent.run(
            "Set up a Node.js project in /workspace with a package.json "
            "and a simple index.js, then run it."
        )
        print(result.output)


if __name__ == "__main__":
    asyncio.run(main())
