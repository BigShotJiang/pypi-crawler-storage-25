"""Blaxel + LangChain/LangGraph example.

Prerequisites:
    pip install agentsh-secure-sandbox[langchain,blaxel] langchain-anthropic langgraph
    export BL_API_KEY=...
    export ANTHROPIC_API_KEY=...
"""
import asyncio

from blaxel_core import SandboxInstance
from langchain_anthropic import ChatAnthropic
from langgraph.prebuilt import create_react_agent
from agentsh_secure_sandbox import SecureSandboxToolkit
from agentsh_secure_sandbox.adapters import blaxel


async def main() -> None:
    raw = await SandboxInstance.create({"name": "my-sandbox", "region": "us-pdx-1"})

    toolkit = SecureSandboxToolkit(blaxel(raw))

    async with toolkit:
        agent = create_react_agent(
            ChatAnthropic(model="claude-sonnet-4-6"),
            tools=toolkit.get_tools(),
        )
        result = await agent.ainvoke({
            "messages": [
                {"role": "user", "content": "Check what OS this sandbox is running and list installed packages."}
            ]
        })
        for msg in result["messages"]:
            print(msg.content)


if __name__ == "__main__":
    asyncio.run(main())
