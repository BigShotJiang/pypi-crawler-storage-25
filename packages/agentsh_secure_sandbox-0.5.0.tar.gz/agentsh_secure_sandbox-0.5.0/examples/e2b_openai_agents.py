"""E2B + OpenAI Agents SDK example.

Prerequisites:
    pip install agentsh-secure-sandbox[openai-agents,e2b]
    export E2B_API_KEY=...
    export OPENAI_API_KEY=...
"""
import asyncio

from e2b import AsyncSandbox
from agents import Agent, Runner
from agentsh_secure_sandbox import SecureSandboxAgentTools
from agentsh_secure_sandbox.adapters import e2b


async def main() -> None:
    raw = await AsyncSandbox.create()

    sandbox_tools = SecureSandboxAgentTools(e2b(raw))

    async with sandbox_tools:
        agent = Agent(
            name="Coder",
            instructions="You are a coding assistant with access to a secure sandbox.",
            tools=sandbox_tools.get_tools(),
        )
        result = await Runner.run(
            agent,
            "Create a simple Python web server in /workspace/server.py using http.server.",
        )
        print(result.final_output)

    await raw.kill()


if __name__ == "__main__":
    asyncio.run(main())
