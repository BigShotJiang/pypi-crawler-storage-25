"""Vercel Sandbox — low-level API example.

Prerequisites:
    pip install agentsh-secure-sandbox[vercel]
    export VERCEL_TOKEN=...
    export VERCEL_PROJECT_ID=...
    export VERCEL_TEAM_ID=...    # optional
"""
import asyncio
import os

from agentsh_secure_sandbox import secure_sandbox
from agentsh_secure_sandbox.adapters.vercel import VercelSandbox, vercel


async def main() -> None:
    sb = await VercelSandbox.create(
        token=os.environ["VERCEL_TOKEN"],
        project_id=os.environ["VERCEL_PROJECT_ID"],
        team_id=os.environ.get("VERCEL_TEAM_ID"),
    )

    sandbox = await secure_sandbox(vercel(sb))

    result = await sandbox.exec("echo 'Hello from Vercel Sandbox!'")
    print(result.stdout)

    await sandbox.write_file("/workspace/hello.py", 'print("Hello!")\n')
    result = await sandbox.exec("python /workspace/hello.py")
    print(result.stdout)

    await sandbox.stop()


if __name__ == "__main__":
    asyncio.run(main())
