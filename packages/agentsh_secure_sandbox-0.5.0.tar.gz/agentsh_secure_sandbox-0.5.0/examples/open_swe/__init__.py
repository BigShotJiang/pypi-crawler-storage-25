"""OpenSWE secure-sandbox integration — worked example.

See README.md for usage. Design doc:
docs/superpowers/specs/2026-04-11-open-swe-integration-design.md.
"""
