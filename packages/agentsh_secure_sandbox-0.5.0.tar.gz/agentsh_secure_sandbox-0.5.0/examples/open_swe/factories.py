"""Provider factories for the OpenSWE secure-sandbox bridge.

Each ``create_<provider>_sandbox(sandbox_id=None)`` function returns a
ready-to-use :class:`SecureSandboxBackend`. All heavy SDK imports happen
inside the factory body so importing this module is cheap and doesn't
require every provider SDK to be installed.
"""
from __future__ import annotations

import os
from typing import Callable

from .bridge import SecureSandboxBackend, make_backend

_PHASE1_NO_RECONNECT = (
    "reconnection by sandbox_id is not supported in phase 1; "
    "create a fresh sandbox or track this in the issue tracker"
)


def create_modal_sandbox(sandbox_id: str | None = None) -> SecureSandboxBackend:
    """Create a Modal Sandbox wrapped in secure-sandbox-py.

    Reads ``SECURE_MODAL_APP_NAME`` from env (default
    ``agentsh-secure-sandbox-open-swe``) — a separate name from open-swe's
    own Modal app so both can run side-by-side in the same Modal workspace.
    """
    if sandbox_id is not None:
        raise NotImplementedError(_PHASE1_NO_RECONNECT)

    async def _init(loop):
        # Local imports: Modal SDK is heavy and optional.
        import modal

        from agentsh_secure_sandbox import secure_sandbox
        from agentsh_secure_sandbox.adapters import modal as modal_adapter
        from agentsh_secure_sandbox.adapters import modal_defaults

        app_name = os.environ.get(
            "SECURE_MODAL_APP_NAME", "agentsh-secure-sandbox-open-swe"
        )
        image = modal.Image.debian_slim().apt_install("libseccomp2", "fuse3")
        app = modal.App.lookup(app_name, create_if_missing=True)
        sb = modal.Sandbox.create(app=app, image=image)

        secured = await secure_sandbox(modal_adapter(sb), modal_defaults())
        # Modal Sandbox exposes .object_id for its globally-unique id.
        sandbox_id_str: str = getattr(sb, "object_id", None) or str(id(sb))
        return sandbox_id_str, secured

    return make_backend(_init)


def create_daytona_sandbox(sandbox_id: str | None = None) -> SecureSandboxBackend:
    """Create a Daytona sandbox wrapped in secure-sandbox-py."""
    if sandbox_id is not None:
        raise NotImplementedError(_PHASE1_NO_RECONNECT)

    async def _init(loop):
        from daytona_sdk import Daytona

        from agentsh_secure_sandbox import secure_sandbox
        from agentsh_secure_sandbox.adapters import daytona as daytona_adapter

        client = Daytona()
        raw = await client.create()
        secured = await secure_sandbox(daytona_adapter(raw))
        sandbox_id_str: str = getattr(raw, "id", None) or str(id(raw))
        return sandbox_id_str, secured

    return make_backend(_init)


def create_runloop_sandbox(sandbox_id: str | None = None) -> SecureSandboxBackend:
    """Create a Runloop devbox wrapped in secure-sandbox-py.

    Uses ``runloop_defaults()`` which enables seccomp + unix_sockets +
    FUSE deferred + cgroups — the set that works on Runloop's kernel.
    """
    if sandbox_id is not None:
        raise NotImplementedError(_PHASE1_NO_RECONNECT)

    async def _init(loop):
        from runloop_api_client import Runloop

        from agentsh_secure_sandbox import secure_sandbox
        from agentsh_secure_sandbox.adapters import runloop as runloop_adapter
        from agentsh_secure_sandbox.adapters import runloop_defaults

        client = Runloop()
        devbox = await client.devboxes.create_and_await_running()
        adapter = runloop_adapter({"client": client, "id": devbox.id})
        secured = await secure_sandbox(adapter, runloop_defaults())
        return devbox.id, secured

    return make_backend(_init)


def create_e2b_sandbox(sandbox_id: str | None = None) -> SecureSandboxBackend:
    """Create an E2B sandbox wrapped in secure-sandbox-py.

    Uses :class:`e2b.AsyncSandbox` for async construction.
    """
    if sandbox_id is not None:
        raise NotImplementedError(_PHASE1_NO_RECONNECT)

    async def _init(loop):
        from e2b import AsyncSandbox

        from agentsh_secure_sandbox import secure_sandbox
        from agentsh_secure_sandbox.adapters import e2b as e2b_adapter

        raw = await AsyncSandbox.create()
        secured = await secure_sandbox(e2b_adapter(raw))
        sandbox_id_str: str = getattr(raw, "sandbox_id", None) or str(id(raw))
        return sandbox_id_str, secured

    return make_backend(_init)


def create_freestyle_sandbox(sandbox_id: str | None = None) -> SecureSandboxBackend:
    """Create a Freestyle VM wrapped in secure-sandbox-py.

    Uses ``freestyle_defaults()`` + a baked snapshot (agentsh is
    preinstalled via ``configure_freestyle_spec``). Cold starts can take
    several minutes on first snapshot build — ``make_backend`` gives up
    to 10 minutes by default.

    The internal HTTP client is held open for the life of the backend.
    It is GC'd when the backend is dropped; Freestyle bills per-VM not
    per-HTTP-session, so leaking the client briefly is harmless.
    """
    if sandbox_id is not None:
        raise NotImplementedError(_PHASE1_NO_RECONNECT)

    async def _init(loop):
        from agentsh_secure_sandbox import secure_sandbox
        from agentsh_secure_sandbox.adapters.freestyle import (
            FreestyleClient,
            freestyle,
            freestyle_defaults,
        )

        client = FreestyleClient()
        try:
            vm = await client.create_sandbox_vm(install_timeout=540.0)
        except BaseException:
            await client.aclose()
            raise
        try:
            secured = await secure_sandbox(freestyle(vm), freestyle_defaults())
        except BaseException:
            # secured never materialized; stop the VM ourselves
            try:
                await vm.stop()
            finally:
                await client.aclose()
            raise
        return vm.vm_id, secured

    return make_backend(_init)


SANDBOX_FACTORIES: dict[str, Callable[..., SecureSandboxBackend]] = {
    "modal": create_modal_sandbox,
    "daytona": create_daytona_sandbox,
    "runloop": create_runloop_sandbox,
    "e2b": create_e2b_sandbox,
    "freestyle": create_freestyle_sandbox,
}


def get_secure_sandbox(
    sandbox_type: str, sandbox_id: str | None = None
) -> SecureSandboxBackend:
    """Dispatch to the right factory by provider name.

    Raises :class:`KeyError` if ``sandbox_type`` is not registered.
    """
    try:
        factory = SANDBOX_FACTORIES[sandbox_type]
    except KeyError as exc:
        available = ", ".join(sorted(SANDBOX_FACTORIES))
        raise KeyError(
            f"unknown sandbox_type {sandbox_type!r}; available: {available}"
        ) from exc
    return factory(sandbox_id=sandbox_id)
