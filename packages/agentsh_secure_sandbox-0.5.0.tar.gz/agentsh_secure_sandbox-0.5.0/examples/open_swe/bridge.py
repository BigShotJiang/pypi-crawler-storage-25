"""Sync-to-async bridge between deepagents' BaseSandbox and secure-sandbox-py.

Each ``SecureSandboxBackend`` owns a private asyncio event loop running
on a daemon thread. All BaseSandbox methods dispatch onto that loop via
``asyncio.run_coroutine_threadsafe``.
"""
from __future__ import annotations

import asyncio
import threading
from typing import Any, Awaitable, Callable

from deepagents.backends.protocol import (
    EditResult,
    ExecuteResponse,
    FileData,
    FileDownloadResponse,
    FileUploadResponse,
    ReadResult,
    WriteResult,
)
from deepagents.backends.sandbox import BaseSandbox

from agentsh_secure_sandbox.core.types import SecuredSandbox


# --- error mapping ---------------------------------------------------------
# FileUploadResponse.error and FileDownloadResponse.error are typed as
# Literal["file_not_found", "permission_denied", "is_directory",
# "invalid_path"] | None in deepagents 0.5.2. Our secure-sandbox-py layer
# returns free-form error strings. This helper maps each string to the
# nearest literal; unknowns become "permission_denied" since the
# overwhelming majority of secure-sandbox failures are policy denials.

_FileOpError = str  # alias — the Literal type is in deepagents.backends.protocol


def _map_error(error_string: str | None) -> _FileOpError | None:
    """Map a secure-sandbox-py error string to a deepagents FileOperationError.

    Returns ``None`` if ``error_string`` is falsy. Otherwise returns one
    of the four Literal values accepted by ``FileUploadResponse.error``.
    Uses simple substring matching, defaulting to ``"permission_denied"``.
    """
    if not error_string:
        return None
    lowered = error_string.lower()
    if "not found" in lowered or "no such file" in lowered:
        return "file_not_found"
    if "is a directory" in lowered or "is_directory" in lowered:
        return "is_directory"
    if "invalid path" in lowered or "invalid_path" in lowered:
        return "invalid_path"
    return "permission_denied"


class SecureSandboxBackend(BaseSandbox):
    """Wraps a SecuredSandbox in deepagents' BaseSandbox contract.

    Instantiate via :func:`make_backend`. Direct construction is
    supported but requires the caller to own the event loop and
    daemon thread lifecycle themselves.
    """

    def __init__(
        self,
        sandbox_id: str,
        loop: asyncio.AbstractEventLoop,
        thread: threading.Thread,
        secured: SecuredSandbox,
    ) -> None:
        super().__init__()
        self._id = sandbox_id
        self._loop = loop
        self._thread = thread
        self._secured = secured
        self._closed = False

    @property
    def id(self) -> str:  # satisfies BaseSandbox.id
        return self._id

    def _run(self, coro: Awaitable[Any]) -> Any:
        """Dispatch ``coro`` onto the background loop and block until done."""
        return asyncio.run_coroutine_threadsafe(coro, self._loop).result()

    # Abstract methods we satisfy in later tasks:
    def execute(
        self, command: str, *, timeout: int | None = None
    ) -> ExecuteResponse:
        """Run a shell command under agentsh policy enforcement.

        Concatenates stdout + stderr into a single ``output`` string
        because deepagents' ExecuteResponse carries one output field.
        If both are non-empty, they're separated by a newline; if only
        one is non-empty, no extra separator is added.
        """
        result = self._run(
            self._secured.exec(
                command,
                timeout=float(timeout) if timeout is not None else None,
            )
        )
        if result.stdout and result.stderr:
            output = f"{result.stdout}\n{result.stderr}"
        else:
            output = result.stdout or result.stderr
        return ExecuteResponse(
            output=output,
            exit_code=result.exit_code,
            truncated=False,
        )

    def upload_files(
        self, files: list[tuple[str, bytes]]
    ) -> list[FileUploadResponse]:
        """Write each ``(path, bytes)`` pair through the secured file API.

        Secure-sandbox-py returns free-form error strings; we map them
        to deepagents' ``FileOperationError`` Literal via ``_map_error``
        before building the response.
        """
        responses: list[FileUploadResponse] = []
        for path, content in files:
            result = self._run(self._secured.write_file(path, content))
            if result.success:
                responses.append(FileUploadResponse(path=path))
            else:
                responses.append(
                    FileUploadResponse(
                        path=path, error=_map_error(result.error)
                    )
                )
        return responses

    def download_files(self, paths: list[str]) -> list[FileDownloadResponse]:
        """Read each path through the secured file API; encode content as UTF-8 bytes.

        Failure ``error`` strings are mapped to deepagents'
        ``FileOperationError`` Literal via ``_map_error``.
        """
        responses: list[FileDownloadResponse] = []
        for path in paths:
            result = self._run(self._secured.read_file(path))
            if result.success:
                responses.append(
                    FileDownloadResponse(
                        path=path,
                        content=result.content.encode("utf-8"),
                    )
                )
            else:
                responses.append(
                    FileDownloadResponse(
                        path=path, error=_map_error(result.error)
                    )
                )
        return responses

    def read(
        self,
        file_path: str,
        offset: int = 0,
        limit: int = 2000,
    ) -> ReadResult:
        """Read a file through the secured file API, then slice by lines.

        ``offset`` is a 0-indexed starting line; ``limit`` is the number
        of lines to return. Matches deepagents' default contract.
        """
        result = self._run(self._secured.read_file(file_path))
        if not result.success:
            return ReadResult(error=result.error)
        content = result.content
        lines = content.splitlines(keepends=True)
        content = "".join(lines[offset:offset + limit])
        file_data: FileData = {"content": content, "encoding": "utf-8"}
        return ReadResult(file_data=file_data)

    def write(self, file_path: str, content: str) -> WriteResult:
        """Write a file through the secured file API (policy-aware)."""
        result = self._run(self._secured.write_file(file_path, content))
        if result.success:
            return WriteResult(path=file_path)
        return WriteResult(error=result.error)

    def edit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> EditResult:
        """Read, replace, write-back — using the secured file API throughout.

        Trades BaseSandbox's inline-JSON optimization for consistency
        with our policy-aware read/write paths.
        """
        read_result = self._run(self._secured.read_file(file_path))
        if not read_result.success:
            return EditResult(error=read_result.error)

        content = read_result.content
        occurrences = content.count(old_string)
        if occurrences == 0:
            return EditResult(
                error=f"old_string not found in {file_path}",
            )
        if not replace_all and occurrences > 1:
            return EditResult(
                error=(
                    f"old_string matches {occurrences} times in {file_path}; "
                    "pass replace_all=True or make it unique"
                ),
            )

        if replace_all:
            new_content = content.replace(old_string, new_string)
            count = occurrences
        else:
            new_content = content.replace(old_string, new_string, 1)
            count = 1

        write_result = self._run(
            self._secured.write_file(file_path, new_content)
        )
        if not write_result.success:
            return EditResult(error=write_result.error)
        return EditResult(path=file_path, occurrences=count)

    def close(self, *, stop_secured: bool = True) -> None:
        """Tear down the background loop and (by default) the secured sandbox."""
        if self._closed:
            return
        self._closed = True
        if stop_secured:
            try:
                asyncio.run_coroutine_threadsafe(
                    self._secured.stop(), self._loop
                ).result(timeout=60)
            except Exception:
                pass  # best-effort
        self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join(timeout=5)
        try:
            self._loop.close()
        except Exception:
            pass  # loop may already be closed, or stop hasn't taken effect yet

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass


def make_backend(
    async_init: Callable[
        [asyncio.AbstractEventLoop],
        Awaitable[tuple[str, SecuredSandbox]],
    ],
    *,
    init_timeout: float = 600.0,
) -> SecureSandboxBackend:
    """Spin up a background event loop and run ``async_init`` on it.

    ``async_init`` must create the provider sandbox, wrap it with
    :func:`agentsh_secure_sandbox.secure_sandbox`, and return
    ``(sandbox_id, secured_sandbox)``. The returned
    :class:`SecureSandboxBackend` owns the loop and thread until
    :meth:`SecureSandboxBackend.close` is called.
    """
    loop = asyncio.new_event_loop()
    thread = threading.Thread(
        target=loop.run_forever,
        name="secure-sandbox-backend",
        daemon=True,
    )
    thread.start()

    future: Any = None
    try:
        future = asyncio.run_coroutine_threadsafe(async_init(loop), loop)
        sandbox_id, secured = future.result(timeout=init_timeout)
    except BaseException as init_err:
        # Capture for closures — Python deletes exception vars after
        # the except block exits, which would empty the cell.
        _init_err: BaseException = init_err
        # Cancel any still-pending tasks on the background loop
        # (including a still-running async_init) and wait for their
        # finally blocks to run before we stop the loop. Schedule a
        # helper coroutine onto the loop so we operate within the
        # loop's single-threaded execution model — no other coroutine
        # can progress while we're in a sync section, which eliminates
        # the race between future.done() and all_tasks().
        async def _cancel_and_drain() -> None:
            current = asyncio.current_task()
            pending = [
                t
                for t in asyncio.all_tasks(loop)
                if t is not current and not t.done()
            ]
            for t in pending:
                t.cancel()
            if pending:
                results = await asyncio.gather(
                    *pending, return_exceptions=True
                )
                # Surface any non-cancellation exception from cleanup so
                # the caller can chain it to the original init error.
                for r in results:
                    if isinstance(r, BaseException) and not isinstance(
                        r, asyncio.CancelledError
                    ):
                        raise r

            # Check whether the init future completed (successfully or
            # with an error) while we weren't looking.
            late_exc: BaseException | None = None
            completed_ok = False
            if (
                future is not None
                and future.done()
                and not future.cancelled()
            ):
                try:
                    late_exc = future.exception(timeout=0)
                except BaseException:
                    pass  # couldn't read state; leave both flags default
                completed_ok = late_exc is None

            if completed_ok:
                # Init completed successfully after timeout — stop the
                # orphaned sandbox so it isn't leaked.
                try:
                    _, orphaned = future.result(timeout=0)
                    await orphaned.stop()
                except BaseException as stop_err:
                    raise stop_err
            elif late_exc is not None and late_exc is not _init_err:
                # Init raised *after* the timeout. The caller would
                # only see TimeoutError — surface the real failure so
                # it can be chained onto the init exception.
                raise late_exc

        try:
            cleanup_fut = asyncio.run_coroutine_threadsafe(
                _cancel_and_drain(), loop
            )
            cleanup_fut.result(timeout=30)
        except BaseException as cleanup_err:
            # Cleanup ran but one of the drained tasks raised a non-
            # cancellation exception (or the drain itself timed out).
            # Walk the init_err's __context__ chain and append at the
            # end so neither piece of info is lost — even when the init
            # error already has a context chain of its own.
            target: BaseException = _init_err
            while target.__context__ is not None:
                target = target.__context__
            target.__context__ = cleanup_err
        loop.call_soon_threadsafe(loop.stop)
        thread.join(timeout=5)
        try:
            loop.close()
        except Exception:
            pass
        raise

    return SecureSandboxBackend(
        sandbox_id=sandbox_id,
        loop=loop,
        thread=thread,
        secured=secured,
    )
