"""End-to-end smoke test for the OpenSWE secure-sandbox bridge.

Runs against a real provider sandbox selected by the ``SANDBOX_TYPE``
env var (one of ``modal``, ``daytona``, ``runloop``, ``e2b``,
``freestyle``). Prints a PASS/FAIL summary per operation.

Usage::

    SANDBOX_TYPE=e2b python examples/open_swe/demo_smoke_test.py

Exit codes:
    0 — all ops passed
    1 — one or more ops failed
    2 — SANDBOX_TYPE unset or unknown
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from factories import get_secure_sandbox  # noqa: E402


def _check(label: str, ok: bool, detail: str = "") -> bool:
    status = "PASS" if ok else "FAIL"
    print(f"  [{status}] {label}{(' — ' + detail) if detail else ''}")
    return ok


def main() -> int:
    sandbox_type = os.environ.get("SANDBOX_TYPE")
    if not sandbox_type:
        print("SANDBOX_TYPE env var required", file=sys.stderr)
        return 2

    print(f"Creating secure {sandbox_type} sandbox (this may take minutes)...")
    try:
        backend = get_secure_sandbox(sandbox_type)
    except KeyError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    print(f"  sandbox id: {backend.id}\n")

    all_ok = True
    try:
        # 1. execute echo
        print("[execute]")
        result = backend.execute("echo hello-from-secured")
        all_ok &= _check(
            "echo stdout",
            "hello-from-secured" in result.output,
            result.output.strip()[:60],
        )
        all_ok &= _check(
            "exit code == 0",
            result.exit_code == 0,
            str(result.exit_code),
        )

        # 2. write a file
        print("\n[write]")
        write_path = "/workspace/open-swe-smoke.txt"
        write_res = backend.write(write_path, "greetings from the bridge\n")
        all_ok &= _check(
            "policy-allowed write",
            write_res.error is None,
            write_res.error or "ok",
        )

        # 3. read it back
        print("\n[read]")
        read_res = backend.read(write_path)
        content_ok = (
            read_res.error is None
            and read_res.file_data is not None
            and "greetings" in read_res.file_data.get("content", "")
        )
        all_ok &= _check("content round-tripped", content_ok,
                         (read_res.error or "content matched"))

        # 4. edit (unique replace)
        print("\n[edit]")
        edit_res = backend.edit(write_path, "greetings", "salutations")
        all_ok &= _check(
            "edit applied",
            edit_res.error is None and edit_res.occurrences == 1,
            edit_res.error or f"{edit_res.occurrences} occurrence(s)",
        )

        # 5. read again to confirm edit
        read_res2 = backend.read(write_path)
        all_ok &= _check(
            "edit persisted",
            read_res2.error is None
            and "salutations" in (
                read_res2.file_data or {"content": ""}
            )["content"],
            "salutations visible",
        )

        # 6. upload + download round-trip
        print("\n[upload/download]")
        upload_path = "/workspace/upload-test.bin"
        uploads = backend.upload_files([(upload_path, b"\x01\x02\x03")])
        all_ok &= _check("upload returned no error",
                         uploads[0].error is None, uploads[0].error or "ok")
        downloads = backend.download_files([upload_path])
        all_ok &= _check(
            "download bytes match",
            downloads[0].content == b"\x01\x02\x03",
            repr(downloads[0].content)[:40],
        )

    finally:
        print("\nClosing backend...")
        backend.close()

    print("\n" + ("ALL PASS" if all_ok else "FAILED"))
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
