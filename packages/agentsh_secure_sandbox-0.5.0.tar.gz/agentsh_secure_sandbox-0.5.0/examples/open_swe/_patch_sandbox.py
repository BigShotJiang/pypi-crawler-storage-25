"""Monkeypatch deepagents' sandbox lookup to return a secure backend.

**Usage in your open-swe fork:**

1. Copy ``bridge.py``, ``factories.py``, and this file into your
   open-swe fork at ``agent/integrations/secure/``.
2. Update the imports in the copied files to match your package layout
   (typically ``from .bridge import ...`` and ``from .factories import ...``).
3. At process start — before the deepagents graph is built — call::

       from agent.integrations.secure._patch_sandbox import (
           patch_deepagents_get_sandbox,
       )
       patch_deepagents_get_sandbox()

4. Set ``SANDBOX_TYPE`` (and any provider env vars) before starting
   the agent.

The patch replaces :func:`deepagents.backends.get_sandbox` — the
factory deepagents calls whenever a node needs a sandbox — with a
wrapper that routes through our :func:`get_secure_sandbox`. This
does not touch deepagents source; removing the patch is as simple
as not importing this module.
"""
from __future__ import annotations

import os
from typing import Any

from .factories import get_secure_sandbox

_ORIGINAL = None


def patch_deepagents_get_sandbox(env_var: str = "SANDBOX_TYPE") -> None:
    """Patch deepagents' get_sandbox to return SecureSandboxBackend.

    Idempotent: calling twice is a no-op after the first call.

    :param env_var: environment variable used to select the provider.
        Defaults to ``SANDBOX_TYPE``. The value must be one of the keys
        in :data:`factories.SANDBOX_FACTORIES`.
    """
    global _ORIGINAL
    import deepagents.backends as backends_mod

    if _ORIGINAL is not None:
        return  # already patched

    _ORIGINAL = getattr(backends_mod, "get_sandbox", None)

    def _secure_get_sandbox(*args: Any, sandbox_id: str | None = None, **kwargs: Any) -> Any:
        sandbox_type = os.environ.get(env_var)
        if not sandbox_type:
            raise RuntimeError(
                f"{env_var} env var is required when using the "
                "secure-sandbox patch"
            )
        return get_secure_sandbox(sandbox_type, sandbox_id=sandbox_id)

    backends_mod.get_sandbox = _secure_get_sandbox


def unpatch_deepagents_get_sandbox() -> None:
    """Restore deepagents' original get_sandbox. Primarily for tests."""
    global _ORIGINAL
    if _ORIGINAL is None:
        return
    import deepagents.backends as backends_mod

    backends_mod.get_sandbox = _ORIGINAL
    _ORIGINAL = None
