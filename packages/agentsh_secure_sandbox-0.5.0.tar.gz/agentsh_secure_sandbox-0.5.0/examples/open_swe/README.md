# OpenSWE × secure-sandbox-py (worked example)

This directory contains a worked example of running
[OpenSWE](https://github.com/langchain-ai/open-swe) — LangChain's
open-source coding agent built on
[`deepagents`](https://github.com/langchain-ai/deepagents) — inside a
secure-sandbox-py-managed sandbox. Every command and file operation
the agent performs is enforced by agentsh's syscall-level policy.

## What you get

- **`bridge.py`** — a `SecureSandboxBackend` class that implements
  deepagents' `BaseSandbox` protocol on top of an async
  `SecuredSandbox`. Sync-to-async translation is handled by a
  private background event loop running on a daemon thread.
- **`factories.py`** — five provider factories:
  - `create_modal_sandbox`
  - `create_daytona_sandbox`
  - `create_runloop_sandbox`
  - `create_e2b_sandbox`
  - `create_freestyle_sandbox`
- **`demo_smoke_test.py`** — end-to-end runner exercising execute,
  read, write, edit, upload, and download against any of the above.
- **`_patch_sandbox.py`** — monkeypatch helper that swaps deepagents'
  built-in `get_sandbox` for one that returns a secure backend.

## Prerequisites

```bash
pip install -e '.[dev,modal,daytona,runloop,e2b]'
pip install deepagents
```

Set provider credentials per your needs:

| Provider  | Env vars                                                  |
|-----------|-----------------------------------------------------------|
| Modal     | `modal token set` (interactive) + `SECURE_MODAL_APP_NAME` |
| Daytona   | `DAYTONA_API_KEY`                                         |
| Runloop   | `RUNLOOP_API_KEY`                                         |
| E2B       | `E2B_API_KEY`                                             |
| Freestyle | `FREESTYLE_API_KEY`                                       |

## Quick smoke test

```bash
SANDBOX_TYPE=e2b python examples/open_swe/demo_smoke_test.py
```

Expected output:
```
Creating secure e2b sandbox (this may take minutes)...
  sandbox id: isxxxxxxxxxxxxxxxxxxx

[execute]
  [PASS] echo stdout — hello-from-secured
  [PASS] exit code == 0 — 0

... (read, write, edit, upload, download)

ALL PASS
```

Exits non-zero on any failure.

## Wiring into an open-swe fork

1. Clone [`langchain-ai/open-swe`](https://github.com/langchain-ai/open-swe).
2. Copy `bridge.py`, `factories.py`, and `_patch_sandbox.py` into your
   fork at `agent/integrations/secure/`.
3. Update relative imports to match the new location (replace
   `from .bridge import ...` and `from .factories import ...` with
   `from agent.integrations.secure.bridge import ...` etc.).
4. At process start — before the LangGraph/deepagents graph is built
   — call the patch:
   ```python
   from agent.integrations.secure._patch_sandbox import (
       patch_deepagents_get_sandbox,
   )
   patch_deepagents_get_sandbox()
   ```
5. Set `SANDBOX_TYPE=<provider>` and provider-specific env vars.
6. Run open-swe as usual. Every sandbox-backed operation now routes
   through agentsh.

## Architecture

```
┌──────────────────────────────────────────┐
│  deepagents graph (sync, in main thread) │
└───────────────────┬──────────────────────┘
                    │ execute(), read(), write(), ...
                    ▼
┌──────────────────────────────────────────┐
│  SecureSandboxBackend (sync facade)      │
│  - owns daemon-thread asyncio loop        │
│  - run_coroutine_threadsafe dispatch      │
└───────────────────┬──────────────────────┘
                    │ async
                    ▼
┌──────────────────────────────────────────┐
│  SecuredSandbox                           │
│  - exec / read_file / write_file          │
│  - every call flows through agentsh       │
└───────────────────┬──────────────────────┘
                    │ syscalls
                    ▼
┌──────────────────────────────────────────┐
│  Provider sandbox (Modal/Daytona/E2B/...) │
│  agentsh running as PID 1 → syscall gate  │
└──────────────────────────────────────────┘
```

## Known limitations (phase 1)

- **No reconnection by `sandbox_id`.** Each call to a factory creates
  a new sandbox. Persisting a secured session across process restarts
  is out of scope for phase 1. Phase 2 (a standalone installable
  package) will support reconnection.
- **Daytona teardown is not complete.** Daytona's `stop()` is a no-op;
  sandboxes remain until explicitly removed via `client.remove()`.
  `SecureSandboxBackend.close()` releases the event loop but does
  **not** remove the Daytona sandbox. You must track and clean up
  Daytona sandboxes separately if billing matters.
- **Freestyle cold starts can take 5+ minutes** on the first snapshot
  build. Subsequent creates hit the cache and are fast.
- **LangSmith managed mode is unsupported.** There is no public
  sandbox SDK for LangChain's hosted tier. Use one of the five
  supported providers instead.

## Hacking

Run the unit tests:
```bash
pytest tests/test_open_swe_bridge.py -xvs
```

All bridge tests run offline against a fake SecuredSandbox — no
provider credentials required. End-to-end validation lives in
`demo_smoke_test.py`.
