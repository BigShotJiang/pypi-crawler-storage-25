"""Sprites (Fly.io) + Pydantic AI example.

Prerequisites:
    pip install agentsh-secure-sandbox[pydantic-ai,sprites]
    export SPRITES_API_TOKEN=...
"""
import asyncio

from sprites import SpritesClient
from pydantic_ai import Agent
from agentsh_secure_sandbox import SecureSandboxToolset
from agentsh_secure_sandbox.adapters import sprites, sprites_defaults


async def main() -> None:
    client = SpritesClient()
    sprite = client.sprite("my-sprite")

    # sprites_defaults() sets workspace=/home/sprite and install_strategy=preinstalled
    toolset = SecureSandboxToolset(sprites(sprite), sprites_defaults())
    agent = Agent("claude-sonnet-4-6", toolsets=[toolset])

    async with agent:
        result = await agent.run(
            "Write a bash script to /home/sprite/greet.sh that prints "
            "'Hello from Sprites!' and run it."
        )
        print(result.output)


if __name__ == "__main__":
    asyncio.run(main())
