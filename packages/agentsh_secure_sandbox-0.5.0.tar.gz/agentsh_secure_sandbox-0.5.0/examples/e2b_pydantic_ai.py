"""E2B + Pydantic AI example.

Prerequisites:
    pip install agentsh-secure-sandbox[pydantic-ai,e2b]
    export E2B_API_KEY=...
"""
import asyncio

from e2b import AsyncSandbox
from pydantic_ai import Agent
from agentsh_secure_sandbox import SecureSandboxToolset
from agentsh_secure_sandbox.adapters import e2b


async def main() -> None:
    raw = await AsyncSandbox.create()

    toolset = SecureSandboxToolset(e2b(raw))
    agent = Agent("claude-sonnet-4-6", toolsets=[toolset])

    async with agent:
        result = await agent.run(
            "Install numpy and write a script that generates 5 random "
            "numbers, then run it."
        )
        print(result.output)

    await raw.kill()


if __name__ == "__main__":
    asyncio.run(main())
