"""Cloudflare Containers — low-level API example.

Prerequisites:
    pip install agentsh-secure-sandbox
    # Cloudflare container must be provisioned via Workers API or wrangler.
    # This example assumes you have a running container accessible via
    # a proxy object that implements exec(), read_file(), write_file().
"""
import asyncio

from agentsh_secure_sandbox import secure_sandbox
from agentsh_secure_sandbox.adapters import cloudflare


async def main() -> None:
    # Replace with your actual Cloudflare container proxy object.
    # See https://developers.cloudflare.com/containers/ for setup.
    cf_sandbox = ...  # your Cloudflare container instance

    sandbox = await secure_sandbox(cloudflare(cf_sandbox))

    result = await sandbox.exec("echo 'Hello from Cloudflare Containers!'")
    print(result.stdout)

    await sandbox.write_file("/workspace/test.txt", "Hello, world!")
    content = await sandbox.read_file("/workspace/test.txt")
    print(f"File content: {content.content}")

    await sandbox.stop()


if __name__ == "__main__":
    asyncio.run(main())
