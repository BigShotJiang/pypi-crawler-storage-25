"""exe.dev — low-level API example.

Prerequisites:
    pip install agentsh-secure-sandbox
    ssh exe.dev new my-vm    # create a persistent VM
"""
import asyncio

from agentsh_secure_sandbox import secure_sandbox
from agentsh_secure_sandbox.adapters import exe, exe_defaults


async def main() -> None:
    # exe() takes a VM name — the VM must already exist on exe.dev
    # exe_defaults() enables full enforcement (seccomp + landlock + FUSE + cgroups)
    sandbox = await secure_sandbox(exe("my-vm"), exe_defaults())

    result = await sandbox.exec("echo 'Hello from exe.dev!'")
    print(result.stdout)

    await sandbox.write_file("/workspace/test.py", 'print("It works!")\n')
    result = await sandbox.exec("python3 /workspace/test.py")
    print(result.stdout)

    await sandbox.stop()

    # To delete the VM when done: ssh exe.dev rm my-vm


if __name__ == "__main__":
    asyncio.run(main())
