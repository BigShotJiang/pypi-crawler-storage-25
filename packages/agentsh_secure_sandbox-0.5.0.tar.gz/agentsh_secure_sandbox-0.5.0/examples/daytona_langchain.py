"""Daytona + LangChain/LangGraph example.

Prerequisites:
    pip install agentsh-secure-sandbox[langchain,daytona] langgraph
    export DAYTONA_API_KEY=...
"""
import asyncio
from typing import Any, Sequence

from daytona_sdk import AsyncDaytona
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage
from langgraph.prebuilt import create_react_agent
from agentsh_secure_sandbox import SecureSandboxToolkit
from agentsh_secure_sandbox.adapters import daytona


class ToolFriendlyFakeChatModel(FakeMessagesListChatModel):
    def bind_tools(self, tools: Sequence[object], **kwargs: object) -> "ToolFriendlyFakeChatModel":
        return self


async def _cleanup_daytona_client(client: Any, raw: object | None) -> None:
    try:
        if raw is not None:
            await client.delete(raw)
    finally:
        await client.close()


async def main() -> None:
    client: Any = AsyncDaytona()
    raw: object | None = None

    try:
        raw = await client.create()
        toolkit = SecureSandboxToolkit(daytona(raw))

        async with toolkit:
            agent = create_react_agent(
                ToolFriendlyFakeChatModel(
                    responses=[
                        AIMessage(
                            content="",
                            tool_calls=[
                                {
                                    "name": "run_command",
                                    "args": {"command": "ls /workspace"},
                                    "id": "tool-1",
                                }
                            ],
                        ),
                        AIMessage(content="I listed /workspace and confirmed the sandbox is ready."),
                    ]
                ),
                tools=toolkit.get_tools(),
            )
            result = await agent.ainvoke(
                {
                    "messages": [
                        {
                            "role": "user",
                            "content": "List the files in /workspace and tell me what you see.",
                        }
                    ]
                }
            )
            for msg in result["messages"]:
                print(msg.content)
    finally:
        await _cleanup_daytona_client(client, raw)


if __name__ == "__main__":
    asyncio.run(main())
