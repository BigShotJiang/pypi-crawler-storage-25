"""Modal + Pydantic AI example.

Prerequisites:
    pip install agentsh-secure-sandbox[pydantic-ai,modal]
    modal token set    # authenticate with Modal
"""
import asyncio

import modal
from pydantic_ai import Agent
from agentsh_secure_sandbox import SecureSandboxToolset
from agentsh_secure_sandbox.adapters import modal as modal_adapter, modal_defaults


async def main() -> None:
    image = modal.Image.debian_slim().apt_install("libseccomp2", "fuse3")
    app = modal.App.lookup("agentsh-example", create_if_missing=True)
    sb = modal.Sandbox.create(app=app, image=image)

    # modal_defaults() configures ptrace mode for gVisor compatibility
    toolset = SecureSandboxToolset(modal_adapter(sb), modal_defaults())
    agent = Agent("claude-sonnet-4-6", toolsets=[toolset])

    async with agent:
        result = await agent.run(
            "Write a Python script that calculates fibonacci(30) and run it."
        )
        print(result.output)


if __name__ == "__main__":
    asyncio.run(main())
