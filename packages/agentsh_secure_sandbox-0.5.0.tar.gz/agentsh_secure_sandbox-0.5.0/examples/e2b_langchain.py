"""E2B + LangChain/LangGraph example.

Prerequisites:
    pip install agentsh-secure-sandbox[langchain,e2b] langchain-anthropic langgraph
    export E2B_API_KEY=...
    export ANTHROPIC_API_KEY=...
"""
import asyncio

from e2b import AsyncSandbox
from langchain_anthropic import ChatAnthropic
from langgraph.prebuilt import create_react_agent
from agentsh_secure_sandbox import SecureSandboxToolkit
from agentsh_secure_sandbox.adapters import e2b


async def main() -> None:
    raw = await AsyncSandbox.create()

    toolkit = SecureSandboxToolkit(e2b(raw))

    async with toolkit:
        agent = create_react_agent(
            ChatAnthropic(model="claude-sonnet-4-6"),
            tools=toolkit.get_tools(),
        )
        result = await agent.ainvoke({
            "messages": [
                {"role": "user", "content": "Write a Python fizzbuzz to /workspace/fizzbuzz.py and run it."}
            ]
        })
        for msg in result["messages"]:
            print(msg.content)

    await raw.kill()


if __name__ == "__main__":
    asyncio.run(main())
