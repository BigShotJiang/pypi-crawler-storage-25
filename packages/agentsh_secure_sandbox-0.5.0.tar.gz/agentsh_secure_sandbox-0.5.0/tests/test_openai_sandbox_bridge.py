from __future__ import annotations

import io
import inspect
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import ANY, AsyncMock, MagicMock, call

import pytest

agents_sandbox_errors = pytest.importorskip("agents.sandbox.errors")
agents_sandbox_types = pytest.importorskip("agents.sandbox.types")
ConfigurationError = agents_sandbox_errors.ConfigurationError
ErrorCode = agents_sandbox_errors.ErrorCode
InvalidManifestPathError = agents_sandbox_errors.InvalidManifestPathError
OpenAIExecResult = agents_sandbox_types.ExecResult

from agentsh_secure_sandbox.core.types import ExecOpts, ExecResult  # noqa: E402


def _make_session_mock() -> MagicMock:
    session = MagicMock()
    session.exec = AsyncMock()
    session.write = AsyncMock()
    session.read = AsyncMock()
    session.shutdown = AsyncMock()
    return session


def _unsupported_user_error(op: str) -> ConfigurationError:
    return ConfigurationError(
        message=(
            "VercelSandboxSession does not support sandbox-local users; "
            f"`{op}` must be called without `user`"
        ),
        error_code=ErrorCode.SANDBOX_CONFIG_INVALID,
        op=op,
        context={"backend": "vercel", "user": "root"},
    )


@pytest.mark.parametrize(
    ("stdout", "stderr", "expected_stdout", "expected_stderr"),
    [
        (b"hello\n", b"warn\n", "hello\n", "warn\n"),
        (bytearray(b"hello\n"), bytearray(b"warn\n"), "hello\n", "warn\n"),
        ("hello\n", "warn\n", "hello\n", "warn\n"),
        (b"he\xffllo", b"ba\xffd", "he�llo", "ba�d"),
        (None, None, "", ""),
    ],
)
async def test_openai_session_adapter_exec_coerces_output(
    stdout: bytes | bytearray | str | None,
    stderr: bytes | bytearray | str | None,
    expected_stdout: str,
    expected_stderr: str,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = _make_session_mock()
    inner.exec.return_value = SimpleNamespace(stdout=stdout, stderr=stderr, exit_code=7)

    adapter = _OpenAISessionAdapter(inner)
    result = await adapter.exec("echo", ["hello"], ExecOpts())

    assert result == ExecResult(
        stdout=expected_stdout,
        stderr=expected_stderr,
        exit_code=7,
    )
    inner.exec.assert_awaited_once_with("echo", "hello", timeout=None, shell=False)


async def test_openai_session_adapter_exec_maps_sudo_to_root_user() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = _make_session_mock()
    inner.exec.return_value = OpenAIExecResult(stdout=b"", stderr=b"", exit_code=0)

    adapter = _OpenAISessionAdapter(inner)
    result = await adapter.exec("id", None, ExecOpts(sudo=True))

    assert result == ExecResult(stdout="", stderr="", exit_code=0)
    inner.exec.assert_awaited_once_with("id", timeout=None, shell=False, user="root")


async def test_openai_session_adapter_exec_retries_without_user_when_users_unsupported() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = _make_session_mock()
    inner.exec.side_effect = [
        _unsupported_user_error("exec"),
        OpenAIExecResult(stdout=b"", stderr=b"", exit_code=0),
    ]

    adapter = _OpenAISessionAdapter(inner)
    result = await adapter.exec("id", None, ExecOpts(sudo=True))

    assert result == ExecResult(stdout="", stderr="", exit_code=0)
    assert inner.exec.await_args_list == [
        call("id", timeout=None, shell=False, user="root"),
        call("sudo", "-n", "id", timeout=None, shell=False),
    ]


@pytest.mark.parametrize(
    "stderr",
    [
        b"sh: sudo: not found\n",
        b"/bin/bash: line 1: sudo: command not found\n",
    ],
)
async def test_openai_session_adapter_exec_retries_without_user_when_sdk_uses_missing_sudo(
    stderr: bytes,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = _make_session_mock()
    inner.exec.side_effect = [
        OpenAIExecResult(stdout=b"", stderr=stderr, exit_code=127),
        OpenAIExecResult(stdout=b"", stderr=b"", exit_code=0),
    ]

    adapter = _OpenAISessionAdapter(inner)
    result = await adapter.exec("id", None, ExecOpts(sudo=True))

    assert result == ExecResult(stdout="", stderr="", exit_code=0)
    assert inner.exec.await_args_list == [
        call("id", timeout=None, shell=False, user="root"),
        call("id", timeout=None, shell=False),
    ]


async def test_openai_session_adapter_exec_uses_shell_for_cwd_and_env() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = _make_session_mock()
    inner.exec.return_value = OpenAIExecResult(stdout=b"", stderr=b"", exit_code=0)

    adapter = _OpenAISessionAdapter(inner)
    result = await adapter.exec(
        "echo",
        ["hello world"],
        ExecOpts(cwd="/tmp/space dir", env={"FOO": "bar baz", "BAD-NAME": "ignored"}),
    )

    assert result == ExecResult(stdout="", stderr="", exit_code=0)
    inner.exec.assert_awaited_once_with(
        "cd '/tmp/space dir' && FOO='bar baz' echo 'hello world'",
        timeout=None,
        shell=True,
    )


async def test_openai_session_adapter_detached_exec_schedules_shell_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import bridge as bridge_module
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = _make_session_mock()
    inner.exec.return_value = OpenAIExecResult(stdout=b"", stderr=b"", exit_code=0)
    scheduled: dict[str, object] = {}

    def fake_fire_and_forget(coro: object) -> object:
        scheduled["coro"] = coro
        return object()

    monkeypatch.setattr(bridge_module, "fire_and_forget", fake_fire_and_forget)

    adapter = _OpenAISessionAdapter(inner)
    result = await adapter.exec(
        "echo",
        ["hello world"],
        ExecOpts(detached=True, cwd="/tmp/space dir", env={"FOO": "bar"}),
    )

    assert result == ExecResult(stdout="", stderr="", exit_code=0)
    inner.exec.assert_not_awaited()
    assert "coro" in scheduled
    await scheduled["coro"]  # type: ignore[misc]
    inner.exec.assert_awaited_once_with(
        "nohup sh -lc 'cd '\"'\"'/tmp/space dir'\"'\"' && FOO=bar echo '\"'\"'hello world'\"'\"'' > /dev/null 2>&1 &",
        timeout=None,
        shell=True,
    )
    assert not inner.exec.await_args.args[0].startswith("nohup cd")
    assert not inner.exec.await_args.args[0].startswith("nohup FOO=")


@pytest.mark.parametrize("content", ["hello", b"hello"])
async def test_openai_session_adapter_write_file_uses_bytes_io(content: str | bytes) -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = _make_session_mock()
    adapter = _OpenAISessionAdapter(inner)

    await adapter.write_file("/tmp/demo.txt", content)

    inner.write.assert_awaited_once()
    path_arg, data_arg = inner.write.await_args.args
    assert path_arg == Path("/tmp/demo.txt")
    assert isinstance(data_arg, io.BytesIO)
    assert data_arg.getvalue() == (content.encode() if isinstance(content, str) else content)
    assert inner.write.await_args.kwargs == {}


async def test_openai_session_adapter_write_file_maps_sudo_to_root_user() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = _make_session_mock()
    adapter = _OpenAISessionAdapter(inner)

    await adapter.write_file("/tmp/demo.txt", "hello", sudo=True)

    inner.write.assert_awaited_once()
    path_arg, data_arg = inner.write.await_args.args
    assert path_arg == Path("/tmp/demo.txt")
    assert isinstance(data_arg, io.BytesIO)
    assert data_arg.getvalue() == b"hello"
    assert inner.write.await_args.kwargs == {"user": "root"}


async def test_openai_session_adapter_write_file_falls_back_to_exec_for_manifest_restricted_paths() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = _make_session_mock()
    inner.write.side_effect = InvalidManifestPathError(
        rel=Path("/etc/agentsh/system/policy.yml"),
        reason="absolute",
    )
    inner.exec.return_value = OpenAIExecResult(stdout=b"", stderr=b"", exit_code=0)

    adapter = _OpenAISessionAdapter(inner)
    await adapter.write_file("/etc/agentsh/system/policy.yml", "hello", sudo=True)

    inner.write.assert_awaited_once()
    assert inner.write.await_args.kwargs == {"user": "root"}
    inner.exec.assert_awaited_once_with("sh", "-lc", ANY, timeout=None, shell=False, user="root")
    shell_command = inner.exec.await_args.args[2]
    assert "base64 -d > /etc/agentsh/system/policy.yml" in shell_command
    assert "printf '%s'" in shell_command
    assert "cat <<'__AGENTSH_B64__'" not in shell_command
    assert "aGVsbG8=" in shell_command


async def test_openai_session_adapter_write_file_retries_without_user_before_exec_fallback() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = _make_session_mock()
    inner.write.side_effect = [
        _unsupported_user_error("write"),
        InvalidManifestPathError(rel=Path("/etc/agentsh/config.yml"), reason="absolute"),
    ]
    inner.exec.return_value = OpenAIExecResult(stdout=b"", stderr=b"", exit_code=0)

    adapter = _OpenAISessionAdapter(inner)
    await adapter.write_file("/etc/agentsh/config.yml", "hello", sudo=True)

    assert inner.write.await_args_list == [
        call(Path("/etc/agentsh/config.yml"), ANY, user="root"),
        call(Path("/etc/agentsh/config.yml"), ANY),
    ]
    inner.exec.assert_awaited_once_with("sudo", "-n", "sh", "-lc", ANY, timeout=None, shell=False)


async def test_openai_session_adapter_read_file_decodes_text() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = _make_session_mock()
    inner.read.return_value = io.BytesIO(b"hello\n")

    adapter = _OpenAISessionAdapter(inner)
    result = await adapter.read_file("/tmp/demo.txt")

    assert result == "hello\n"
    inner.read.assert_awaited_once_with(Path("/tmp/demo.txt"))


async def test_openai_session_adapter_stop_calls_shutdown() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = _make_session_mock()
    adapter = _OpenAISessionAdapter(inner)

    await adapter.stop()

    inner.shutdown.assert_awaited_once_with()


@pytest.mark.parametrize("exit_code, expected", [(0, True), (1, False)])
async def test_openai_session_adapter_file_exists_uses_test_f(
    exit_code: int,
    expected: bool,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = _make_session_mock()
    inner.exec.return_value = OpenAIExecResult(stdout=b"", stderr=b"", exit_code=exit_code)

    adapter = _OpenAISessionAdapter(inner)
    result = await adapter.file_exists("/tmp/demo.txt")

    assert result is expected
    inner.exec.assert_awaited_once_with("test", "-f", "/tmp/demo.txt", timeout=None, shell=False)


def test_secure_openai_session_is_exported_from_openai_sandbox() -> None:
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxSession as exported
    from agentsh_secure_sandbox.openai_sandbox.bridge import (
        SecureOpenAISandboxSession as bridge_class,
    )

    assert exported is bridge_class


async def test_secure_openai_session_exec_routes_through_secured_sandbox() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession

    inner = MagicMock()
    inner.state = MagicMock()
    inner.running = MagicMock(return_value=True)
    inner.persist_workspace = MagicMock(return_value=io.BytesIO(b"workspace"))
    inner.hydrate_workspace = AsyncMock()
    inner.supports_pty = MagicMock(return_value=True)
    inner.pty_exec_start = MagicMock(return_value=MagicMock(tag="pty"))
    inner.pty_write_stdin = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_terminate_all = AsyncMock()
    inner._resolve_exposed_port = AsyncMock(return_value=SimpleNamespace(host="127.0.0.1", port=8080))
    inner.stop = AsyncMock()
    inner.shutdown = AsyncMock()

    secured = AsyncMock()
    secured.exec = AsyncMock(return_value=ExecResult(stdout="secure out", stderr="", exit_code=0))
    secured.read_file = AsyncMock()
    secured.write_file = AsyncMock()
    secured.stop = AsyncMock()

    session = SecureOpenAISandboxSession(inner_session=inner, secured_sandbox=secured)
    result = await session.exec("echo", "hello", shell=False)

    assert result.stdout == b"secure out"
    assert result.stderr == b""
    assert result.exit_code == 0
    secured.exec.assert_awaited_once_with("echo hello", timeout=None)


async def test_secure_openai_session_read_write_route_through_secured_sandbox() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession

    inner = MagicMock()
    inner.state = MagicMock()
    inner.running = MagicMock(return_value=True)
    inner.persist_workspace = MagicMock(return_value=io.BytesIO(b"workspace"))
    inner.hydrate_workspace = AsyncMock()
    inner.supports_pty = MagicMock(return_value=True)
    inner.pty_exec_start = MagicMock(return_value=MagicMock(tag="pty"))
    inner.pty_write_stdin = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_terminate_all = AsyncMock()
    inner._resolve_exposed_port = AsyncMock(return_value=SimpleNamespace(host="127.0.0.1", port=8080))
    inner.stop = AsyncMock()
    inner.shutdown = AsyncMock()

    secured = AsyncMock()
    secured.exec = AsyncMock()
    secured.write_file = AsyncMock(
        return_value=SimpleNamespace(success=True, path="/workspace/a.txt")
    )
    secured.read_file = AsyncMock(
        return_value=SimpleNamespace(success=True, path="/workspace/a.txt", content="payload")
    )
    secured.stop = AsyncMock()

    session = SecureOpenAISandboxSession(inner_session=inner, secured_sandbox=secured)

    await session.write(Path("/workspace/a.txt"), io.BytesIO(b"payload"), user=None)
    read = await session.read(Path("/workspace/a.txt"), user=None)

    assert read.read() == b"payload"
    secured.write_file.assert_awaited_once_with("/workspace/a.txt", b"payload")
    secured.read_file.assert_awaited_once_with("/workspace/a.txt")


async def test_secure_openai_session_read_write_reject_user_override() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession

    inner = MagicMock()
    inner.state = MagicMock()
    inner.running = AsyncMock(return_value=True)
    inner.persist_workspace = AsyncMock(return_value=io.BytesIO(b"workspace"))
    inner.hydrate_workspace = AsyncMock()
    inner.supports_pty = MagicMock(return_value=True)
    inner.pty_exec_start = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_write_stdin = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_terminate_all = AsyncMock()
    inner._resolve_exposed_port = AsyncMock(return_value=SimpleNamespace(host="127.0.0.1", port=8080))
    inner.stop = AsyncMock()
    inner.shutdown = AsyncMock()

    secured = AsyncMock()
    secured.exec = AsyncMock()
    secured.read_file = AsyncMock()
    secured.write_file = AsyncMock()
    secured.stop = AsyncMock()

    session = SecureOpenAISandboxSession(inner_session=inner, secured_sandbox=secured)

    with pytest.raises(TypeError):
        session.read(Path("/workspace/a.txt"), "root")

    with pytest.raises(NotImplementedError, match="user overrides"):
        await session.read(Path("/workspace/a.txt"), user="root")

    with pytest.raises(NotImplementedError, match="user overrides"):
        await session.write(Path("/workspace/a.txt"), io.BytesIO(b"payload"), user="root")


async def test_secure_openai_session_read_write_failures_raise() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession

    inner = MagicMock()
    inner.state = MagicMock()
    inner.running = MagicMock(return_value=True)
    inner.persist_workspace = MagicMock(return_value=io.BytesIO(b"workspace"))
    inner.hydrate_workspace = AsyncMock()
    inner.supports_pty = MagicMock(return_value=True)
    inner.pty_exec_start = MagicMock(return_value=MagicMock(tag="pty"))
    inner.pty_write_stdin = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_terminate_all = AsyncMock()
    inner._resolve_exposed_port = AsyncMock(return_value=SimpleNamespace(host="127.0.0.1", port=8080))
    inner.stop = AsyncMock()
    inner.shutdown = AsyncMock()

    secured = AsyncMock()
    secured.exec = AsyncMock()
    secured.write_file = AsyncMock(
        return_value=SimpleNamespace(success=False, path="/workspace/a.txt", error="denied")
    )
    secured.read_file = AsyncMock(
        return_value=SimpleNamespace(success=False, path="/workspace/a.txt", error="missing")
    )
    secured.stop = AsyncMock()

    session = SecureOpenAISandboxSession(inner_session=inner, secured_sandbox=secured)

    with pytest.raises(PermissionError, match="denied"):
        await session.write(Path("/workspace/a.txt"), io.BytesIO(b"payload"))

    with pytest.raises(FileNotFoundError, match="missing"):
        await session.read(Path("/workspace/a.txt"))


async def test_secure_openai_session_delegates_state_running_and_workspace() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession

    state = MagicMock()
    inner = MagicMock()
    inner.state = state
    inner.running = AsyncMock(return_value=True)
    inner.persist_workspace = AsyncMock(return_value=io.BytesIO(b"workspace"))
    inner.hydrate_workspace = AsyncMock()
    inner.supports_pty = MagicMock(return_value=True)
    inner.pty_exec_start = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_write_stdin = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_terminate_all = AsyncMock()
    inner._resolve_exposed_port = AsyncMock(return_value=SimpleNamespace(host="127.0.0.1", port=8080))
    inner.stop = AsyncMock()
    inner.shutdown = AsyncMock()

    secured = AsyncMock()
    secured.exec = AsyncMock()
    secured.read_file = AsyncMock()
    secured.write_file = AsyncMock()
    secured.stop = AsyncMock()

    session = SecureOpenAISandboxSession(inner_session=inner, secured_sandbox=secured)

    assert session.state is state
    new_state = MagicMock()
    session.state = new_state
    assert inner.state is new_state
    assert await session.running() is True
    assert session.supports_pty() is True
    workspace = await session.persist_workspace()
    assert workspace.read() == b"workspace"

    await session.hydrate_workspace(io.BytesIO(b"hydrate"))
    assert inner.hydrate_workspace.await_args.args[0].read() == b"hydrate"

    pty_update = await session.pty_exec_start("echo", "hello", shell=False)
    assert pty_update.tag == "pty"
    await session.pty_write_stdin(session_id=1, chars="x")
    await session.pty_terminate_all()
    endpoint = await session._resolve_exposed_port(8080)
    assert endpoint.host == "127.0.0.1"
    assert endpoint.port == 8080

    inner.pty_exec_start.assert_called_once_with("echo", "hello", timeout=None, shell=False, user=None, tty=False, yield_time_s=None, max_output_tokens=None)
    inner.pty_write_stdin.assert_awaited_once_with(session_id=1, chars="x", yield_time_s=None, max_output_tokens=None)
    inner.pty_terminate_all.assert_awaited_once_with()
    inner._resolve_exposed_port.assert_awaited_once_with(8080)


def test_secure_openai_session_exports_are_classes() -> None:
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxSession

    assert inspect.isclass(SecureOpenAISandboxSession)
    assert SecureOpenAISandboxSession.__name__ == "SecureOpenAISandboxSession"


async def test_secure_openai_session_stop_and_shutdown_stop_secured_once() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession

    inner = MagicMock()
    inner.state = MagicMock()
    inner.running = MagicMock(return_value=True)
    inner.persist_workspace = MagicMock(return_value=io.BytesIO(b"workspace"))
    inner.hydrate_workspace = AsyncMock()
    inner.supports_pty = MagicMock(return_value=True)
    inner.pty_exec_start = MagicMock(return_value=MagicMock(tag="pty"))
    inner.pty_write_stdin = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_terminate_all = AsyncMock()
    inner._resolve_exposed_port = AsyncMock(return_value=SimpleNamespace(host="127.0.0.1", port=8080))
    inner.stop = AsyncMock()
    inner.shutdown = AsyncMock()

    secured = AsyncMock()
    secured.exec = AsyncMock()
    secured.read_file = AsyncMock()
    secured.write_file = AsyncMock()
    secured.stop = AsyncMock()

    session = SecureOpenAISandboxSession(inner_session=inner, secured_sandbox=secured)

    await session.stop()
    await session.shutdown()

    secured.stop.assert_awaited_once()
    inner.stop.assert_awaited_once()
    inner.shutdown.assert_awaited_once()


async def test_secure_openai_session_stop_still_stops_secured_when_inner_fails() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession

    inner = MagicMock()
    inner.state = MagicMock()
    inner.running = AsyncMock(return_value=True)
    inner.persist_workspace = AsyncMock(return_value=io.BytesIO(b"workspace"))
    inner.hydrate_workspace = AsyncMock()
    inner.supports_pty = MagicMock(return_value=True)
    inner.pty_exec_start = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_write_stdin = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_terminate_all = AsyncMock()
    inner._resolve_exposed_port = AsyncMock(return_value=SimpleNamespace(host="127.0.0.1", port=8080))
    inner.stop = AsyncMock(side_effect=RuntimeError("inner stop"))
    inner.shutdown = AsyncMock()

    secured = AsyncMock()
    secured.exec = AsyncMock()
    secured.read_file = AsyncMock()
    secured.write_file = AsyncMock()
    secured.stop = AsyncMock()

    session = SecureOpenAISandboxSession(inner_session=inner, secured_sandbox=secured)

    with pytest.raises(RuntimeError, match="inner stop"):
        await session.stop()

    secured.stop.assert_awaited_once()
    inner.stop.assert_awaited_once()


async def test_secure_openai_session_shutdown_still_shuts_down_inner_when_secured_stop_fails() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession

    inner = MagicMock()
    inner.state = MagicMock()
    inner.running = AsyncMock(return_value=True)
    inner.persist_workspace = AsyncMock(return_value=io.BytesIO(b"workspace"))
    inner.hydrate_workspace = AsyncMock()
    inner.supports_pty = MagicMock(return_value=True)
    inner.pty_exec_start = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_write_stdin = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_terminate_all = AsyncMock()
    inner._resolve_exposed_port = AsyncMock(return_value=SimpleNamespace(host="127.0.0.1", port=8080))
    inner.stop = AsyncMock()
    inner.shutdown = AsyncMock()

    secured = AsyncMock()
    secured.exec = AsyncMock()
    secured.read_file = AsyncMock()
    secured.write_file = AsyncMock()
    secured.stop = AsyncMock(side_effect=RuntimeError("secured stop"))

    session = SecureOpenAISandboxSession(inner_session=inner, secured_sandbox=secured)

    with pytest.raises(RuntimeError, match="secured stop"):
        await session.shutdown()

    secured.stop.assert_awaited_once()
    inner.shutdown.assert_awaited_once()


async def test_secure_openai_session_retries_secured_stop_after_failure() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession

    inner = MagicMock()
    inner.state = MagicMock()
    inner.running = AsyncMock(return_value=True)
    inner.persist_workspace = AsyncMock(return_value=io.BytesIO(b"workspace"))
    inner.hydrate_workspace = AsyncMock()
    inner.supports_pty = MagicMock(return_value=True)
    inner.pty_exec_start = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_write_stdin = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_terminate_all = AsyncMock()
    inner._resolve_exposed_port = AsyncMock(return_value=SimpleNamespace(host="127.0.0.1", port=8080))
    inner.stop = AsyncMock()
    inner.shutdown = AsyncMock()

    secured = AsyncMock()
    secured.exec = AsyncMock()
    secured.read_file = AsyncMock()
    secured.write_file = AsyncMock()
    secured.stop = AsyncMock(side_effect=[RuntimeError("first stop"), None])

    session = SecureOpenAISandboxSession(inner_session=inner, secured_sandbox=secured)

    with pytest.raises(RuntimeError, match="first stop"):
        await session.shutdown()

    assert secured.stop.await_count == 1
    assert inner.shutdown.await_count == 1

    await session.stop()

    assert secured.stop.await_count == 2
    await session.shutdown()

    assert secured.stop.await_count == 2
