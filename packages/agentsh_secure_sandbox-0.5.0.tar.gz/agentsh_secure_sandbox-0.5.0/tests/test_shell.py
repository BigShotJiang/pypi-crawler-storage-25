import asyncio
from agentsh_secure_sandbox.core.shell import shell_escape, fire_and_forget


def test_shell_escape_no_args():
    assert shell_escape("ls") == "ls"


def test_shell_escape_with_args():
    result = shell_escape("test", ["-f", "/tmp/my file.txt"])
    assert result == "test -f '/tmp/my file.txt'"


def test_shell_escape_special_chars():
    result = shell_escape("echo", ["hello; rm -rf /"])
    assert "'" in result  # Should be quoted


def test_shell_escape_empty_args():
    assert shell_escape("ls", []) == "ls"


async def test_fire_and_forget_returns_task():
    async def noop():
        pass

    task = fire_and_forget(noop())
    assert isinstance(task, asyncio.Task)
    await task


async def test_fire_and_forget_swallows_exceptions():
    async def failing():
        raise RuntimeError("boom")

    task = fire_and_forget(failing())
    await task  # Should not raise
