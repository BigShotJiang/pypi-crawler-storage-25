from __future__ import annotations

import asyncio
import importlib.util
import sys
import types
from pathlib import Path
from types import SimpleNamespace


_EXAMPLES = Path(__file__).resolve().parent.parent / "examples"


def _load_example_module(
    monkeypatch,
    filename: str,
    *,
    extra_modules: dict[str, types.ModuleType],
) -> types.ModuleType:
    for name, module in extra_modules.items():
        monkeypatch.setitem(sys.modules, name, module)

    module_name = f"_test_{Path(filename).stem}"
    spec = importlib.util.spec_from_file_location(module_name, _EXAMPLES / filename)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _fake_daytona_sdk(calls: dict[str, object], raw: object) -> types.ModuleType:
    module = types.ModuleType("daytona_sdk")

    class Daytona:
        def create(self) -> object:
            raise AssertionError("sync Daytona client should not be used in async examples")

    class AsyncDaytona:
        async def create(self) -> object:
            calls["async_create"] = int(calls.get("async_create", 0)) + 1
            return raw

        async def delete(self, candidate: object) -> None:
            calls["delete"] = int(calls.get("delete", 0)) + 1
            assert candidate is raw

        async def close(self) -> None:
            calls["close"] = int(calls.get("close", 0)) + 1

    module.Daytona = Daytona
    module.AsyncDaytona = AsyncDaytona
    return module


def _fake_agentsh_modules() -> tuple[types.ModuleType, types.ModuleType]:
    package = types.ModuleType("agentsh_secure_sandbox")
    adapters = types.ModuleType("agentsh_secure_sandbox.adapters")

    def daytona(raw: object) -> object:
        return ("adapter", raw)

    adapters.daytona = daytona
    return package, adapters


def test_daytona_pydantic_ai_example_uses_async_client(monkeypatch) -> None:
    calls: dict[str, object] = {}
    raw = object()
    package, adapters = _fake_agentsh_modules()

    class TestModel:
        def __init__(self, **kwargs: object) -> None:
            self.kwargs = kwargs

    class SecureSandboxToolset:
        def __init__(self, adapter: object) -> None:
            assert adapter == ("adapter", raw)

    class Agent:
        def __init__(self, model: object, toolsets: list[object]) -> None:
            assert isinstance(model, TestModel)
            assert model.kwargs["call_tools"] == ["write_file", "run_command", "read_file"]
            assert "verified the file contents" in model.kwargs["custom_output_text"]
            assert len(toolsets) == 1

        async def __aenter__(self) -> Agent:
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        async def run(self, prompt: str) -> SimpleNamespace:
            assert "Hello from Daytona!" in prompt
            return SimpleNamespace(output="ok")

    package.SecureSandboxToolset = SecureSandboxToolset

    pydantic_ai = types.ModuleType("pydantic_ai")
    pydantic_ai.Agent = Agent

    pydantic_ai_models = types.ModuleType("pydantic_ai.models")
    pydantic_ai_models_test = types.ModuleType("pydantic_ai.models.test")
    pydantic_ai_models_test.TestModel = TestModel

    module = _load_example_module(
        monkeypatch,
        "daytona_pydantic_ai.py",
        extra_modules={
            "agentsh_secure_sandbox": package,
            "agentsh_secure_sandbox.adapters": adapters,
            "daytona_sdk": _fake_daytona_sdk(calls, raw),
            "pydantic_ai": pydantic_ai,
            "pydantic_ai.models": pydantic_ai_models,
            "pydantic_ai.models.test": pydantic_ai_models_test,
        },
    )

    asyncio.run(module.main())

    assert calls["async_create"] == 1
    assert calls["delete"] == 1
    assert calls["close"] == 1


def test_daytona_openai_agents_example_uses_async_client(monkeypatch) -> None:
    calls: dict[str, object] = {}
    raw = object()
    package, adapters = _fake_agentsh_modules()

    class SecureSandboxAgentTools:
        def __init__(self, adapter: object) -> None:
            assert adapter == ("adapter", raw)

        async def __aenter__(self) -> SecureSandboxAgentTools:
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        def get_tools(self) -> list[str]:
            return ["tool"]

    class Agent:
        def __init__(self, *, name: str, instructions: str, tools: list[str]) -> None:
            assert name == "Coder"
            assert "secure sandbox" in instructions
            assert tools == ["tool"]

    class Runner:
        @staticmethod
        async def run(agent: object, prompt: str) -> SimpleNamespace:
            assert "hello world script" in prompt
            return SimpleNamespace(final_output="ok")

    package.SecureSandboxAgentTools = SecureSandboxAgentTools

    agents = types.ModuleType("agents")
    agents.Agent = Agent
    agents.Runner = Runner

    module = _load_example_module(
        monkeypatch,
        "daytona_openai_agents.py",
        extra_modules={
            "agents": agents,
            "agentsh_secure_sandbox": package,
            "agentsh_secure_sandbox.adapters": adapters,
            "daytona_sdk": _fake_daytona_sdk(calls, raw),
        },
    )

    asyncio.run(module.main())

    assert calls["async_create"] == 1
    assert calls["delete"] == 1
    assert calls["close"] == 1


def test_daytona_langchain_example_uses_async_client(monkeypatch) -> None:
    calls: dict[str, object] = {}
    raw = object()
    package, adapters = _fake_agentsh_modules()

    class AIMessage:
        def __init__(self, *, content: str, tool_calls: list[dict[str, object]] | None = None) -> None:
            self.content = content
            self.tool_calls = tool_calls or []

    class SecureSandboxToolkit:
        def __init__(self, adapter: object) -> None:
            assert adapter == ("adapter", raw)

        async def __aenter__(self) -> SecureSandboxToolkit:
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        def get_tools(self) -> list[str]:
            return ["tool"]

    class FakeMessagesListChatModel:
        def __init__(self, *, responses: list[object]) -> None:
            assert len(responses) == 2
            first, second = responses
            assert isinstance(first, AIMessage)
            assert first.tool_calls and first.tool_calls[0]["name"] == "run_command"
            assert "ls /workspace" in first.tool_calls[0]["args"]["command"]
            assert isinstance(second, AIMessage)

    class _Agent:
        async def ainvoke(self, payload: dict[str, object]) -> dict[str, object]:
            assert payload["messages"][0]["role"] == "user"
            return {"messages": [SimpleNamespace(content="ok")]}

    def create_react_agent(model: object, *, tools: list[str]) -> _Agent:
        assert tools == ["tool"]
        assert isinstance(model, FakeMessagesListChatModel)
        return _Agent()

    package.SecureSandboxToolkit = SecureSandboxToolkit

    langchain_core = types.ModuleType("langchain_core")
    langchain_core_language_models = types.ModuleType("langchain_core.language_models")
    langchain_core_fake_chat_models = types.ModuleType(
        "langchain_core.language_models.fake_chat_models"
    )
    langchain_core_fake_chat_models.FakeMessagesListChatModel = FakeMessagesListChatModel

    langchain_core_messages = types.ModuleType("langchain_core.messages")
    langchain_core_messages.AIMessage = AIMessage

    def tool_call(*, name: str, args: dict[str, object], id: str) -> dict[str, object]:
        return {"name": name, "args": args, "id": id}

    langchain_core_messages.tool_call = tool_call

    langgraph = types.ModuleType("langgraph")
    langgraph_prebuilt = types.ModuleType("langgraph.prebuilt")
    langgraph_prebuilt.create_react_agent = create_react_agent

    module = _load_example_module(
        monkeypatch,
        "daytona_langchain.py",
        extra_modules={
            "agentsh_secure_sandbox": package,
            "agentsh_secure_sandbox.adapters": adapters,
            "daytona_sdk": _fake_daytona_sdk(calls, raw),
            "langchain_core": langchain_core,
            "langchain_core.language_models": langchain_core_language_models,
            "langchain_core.language_models.fake_chat_models": langchain_core_fake_chat_models,
            "langchain_core.messages": langchain_core_messages,
            "langgraph": langgraph,
            "langgraph.prebuilt": langgraph_prebuilt,
        },
    )

    asyncio.run(module.main())

    assert calls["async_create"] == 1
    assert calls["delete"] == 1
    assert calls["close"] == 1
