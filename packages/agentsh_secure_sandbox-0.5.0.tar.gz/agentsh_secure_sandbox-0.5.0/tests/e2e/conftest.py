"""Shared fixtures and helpers for e2e tests."""

from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any
from uuid import uuid4

import pytest
from dotenv import load_dotenv

# Load .env from project root
load_dotenv(Path(__file__).resolve().parents[2] / ".env")


def load_additional_e2e_env_files() -> list[str]:
    raw = os.environ.get("AGENTSH_E2E_ENV_FILES", "")
    loaded: list[str] = []
    for item in raw.split(os.pathsep):
        path = item.strip()
        if not path:
            continue
        candidate = Path(path).expanduser()
        if candidate.is_file():
            load_dotenv(candidate, override=True)
            loaded.append(str(candidate))
    return loaded


def _sdk_available(module_name: str) -> bool:
    """Check if a Python SDK is importable."""
    try:
        __import__(module_name)
        return True
    except ImportError:
        return False


def _daytona_repo_available(env: dict[str, str]) -> bool:
    return (_sdk_available("daytona_sdk") or _sdk_available("daytona")) and bool(env["DAYTONA_API_KEY"])


def _daytona_openai_available(env: dict[str, str]) -> bool:
    return _sdk_available("daytona") and bool(env["DAYTONA_API_KEY"])


def _cloudflare_exec_available(env: dict[str, str]) -> bool:
    return (
        _sdk_available("aiohttp")
        and bool(env["CLOUDFLARE_WORKER_URL"])
        and bool(env["CLOUDFLARE_API_TOKEN"])
    )


def _cloudflare_sandbox_available(env: dict[str, str]) -> bool:
    return (
        _sdk_available("aiohttp")
        and bool(env["CLOUDFLARE_SANDBOX_WORKER_URL"])
        and bool(env["CLOUDFLARE_API_TOKEN"])
    )


def _build_env() -> dict[str, str]:
    return {
        "E2B_API_KEY": os.environ.get("E2B_API_KEY", ""),
        "DAYTONA_API_KEY": os.environ.get("DAYTONA_API_KEY", ""),
        "DAYTONA_API_URL": os.environ.get("DAYTONA_API_URL", ""),
        "DAYTONA_TARGET": os.environ.get("DAYTONA_TARGET", ""),
        "OPENAI_API_KEY": os.environ.get("OPENAI_API_KEY", ""),
        "VERCEL_TOKEN": os.environ.get("VERCEL_TOKEN", ""),
        "VERCEL_PROJECT_ID": os.environ.get("VERCEL_PROJECT_ID", ""),
        "VERCEL_TEAM_ID": os.environ.get("VERCEL_TEAM_ID", ""),
        "CLOUDFLARE_WORKER_URL": os.environ.get("CLOUDFLARE_WORKER_URL", ""),
        "CLOUDFLARE_SANDBOX_WORKER_URL": os.environ.get("CLOUDFLARE_SANDBOX_WORKER_URL", ""),
        "CLOUDFLARE_API_TOKEN": os.environ.get("CLOUDFLARE_API_TOKEN", ""),
        "BLAXEL_API_KEY": os.environ.get("BLAXEL_API_KEY", ""),
        "BL_API_KEY": os.environ.get("BL_API_KEY", ""),
        "BL_WORKSPACE": os.environ.get("BL_WORKSPACE", ""),
        "SPRITES_TOKEN": os.environ.get("SPRITES_TOKEN", ""),
        "SPRITES_ORG": os.environ.get("SPRITES_ORG", ""),
        "SPRITES_NAME": os.environ.get("SPRITES_NAME", ""),
        "FLY_API_TOKEN": os.environ.get("FLY_API_TOKEN", ""),
        "MODAL_TOKEN_ID": os.environ.get("MODAL_TOKEN_ID", ""),
        "MODAL_TOKEN_SECRET": os.environ.get("MODAL_TOKEN_SECRET", ""),
        "RUNLOOP_API_KEY": os.environ.get("RUNLOOP_API_KEY", ""),
        "EXE_VM_NAME": os.environ.get("EXE_VM_NAME", ""),
        "FREESTYLE_API_KEY": os.environ.get("FREESTYLE_API_KEY", ""),
    }


def cloudflare_sandbox_route_missing(exc: BaseException) -> bool:
    context = getattr(exc, "context", None)
    if isinstance(context, dict) and context.get("http_status") == 404:
        return True
    return "POST /sandbox failed: HTTP 404" in str(exc)


def sprites_command_endpoint_missing(message: str) -> bool:
    normalized = message.lower()
    return "websocket error" in normalized and "http 404" in normalized


def sprites_target_missing(message: str) -> bool:
    normalized = message.lower()
    return "sprite not found" in normalized or "resource not found for" in normalized


def _sprites_token(env: dict[str, str]) -> str:
    token = env["SPRITES_TOKEN"]
    if token:
        return token

    fly_token = env["FLY_API_TOKEN"]
    org = env["SPRITES_ORG"]
    if fly_token and org:
        from sprites import SpritesClient  # type: ignore[import-untyped]

        return SpritesClient.create_token(fly_token, org)
    return ""


def build_sprites_client():  # type: ignore[no-untyped-def]
    from sprites import SpritesClient  # type: ignore[import-untyped]

    return SpritesClient(_sprites_token(ENV))


def resolve_or_create_sprites_target(prefix: str = "agentsh-sprites-e2e"):  # type: ignore[no-untyped-def]
    client = build_sprites_client()
    configured_name = ENV["SPRITES_NAME"]
    if configured_name:
        try:
            return client, client.get_sprite(configured_name), False
        except Exception as exc:
            if not sprites_target_missing(str(exc)):
                client.close()
                raise

    created_name = f"{prefix}-{int(time.time())}-{uuid4().hex[:6]}"
    try:
        return client, client.create_sprite(created_name), True
    except Exception:
        client.close()
        raise


def cleanup_sprites_target(client: Any, sprite: Any, created: bool) -> None:
    try:
        if created:
            try:
                sprite.delete()
            except Exception as exc:
                if not sprites_target_missing(str(exc)):
                    raise
    finally:
        close = getattr(client, "close", None)
        if callable(close):
            close()


async def require_sprites_command_endpoint(adapter: Any) -> None:
    sprite = getattr(adapter, "_sprite", None)
    if sprite is not None:
        try:
            sprite.client.get_sprite(sprite.name)
        except Exception as exc:
            if sprites_target_missing(str(exc)):
                pytest.skip(
                    f"Configured Sprites target is unavailable: {sprite.name} not found"
                )
            raise

    result = await adapter.exec("true")
    if result.exit_code != 0 and sprites_command_endpoint_missing(result.stderr):
        pytest.skip("Configured Sprites target rejected command websocket with HTTP 404")


_EXE_SSH_OPTS = [
    '-o', 'StrictHostKeyChecking=no',
    '-o', 'UserKnownHostsFile=/dev/null',
    '-o', 'LogLevel=ERROR',
]
_EXE_DEFAULT_IMAGE = 'ubuntu:22.04'


def _exe_available() -> bool:
    return shutil.which('ssh') is not None


def _ssh_exe_dev(args: str, timeout_ms: int = 60_000) -> str:
    result = subprocess.run(
        ['ssh', *_EXE_SSH_OPTS, 'exe.dev', args],
        capture_output=True,
        text=True,
        timeout=timeout_ms / 1000,
        check=False,
    )
    if result.returncode != 0:
        message = (result.stderr or result.stdout or f'exe.dev ssh failed ({result.returncode})').strip()
        raise RuntimeError(message)
    return result.stdout.strip()


def require_exe_gateway_access() -> None:
    try:
        _ssh_exe_dev('ls --json', timeout_ms=15_000)
    except Exception as exc:
        pytest.skip(f'exe.dev gateway unavailable: {exc}')


def exe_vm_exists(name: str) -> bool:
    raw = _ssh_exe_dev('ls --json', timeout_ms=15_000)
    parsed = json.loads(raw)
    vms = parsed.get('vms', parsed) if isinstance(parsed, dict) else parsed
    return any(isinstance(vm, dict) and vm.get('vm_name') == name for vm in vms)


def _ssh_exe_vm(name: str, command: str, timeout_ms: int = 60_000) -> str:
    return _ssh_exe_dev(
        f"ssh {shlex.quote(name)} {shlex.quote(command)}",
        timeout_ms=timeout_ms,
    )


def create_exe_vm(name: str, image: str = _EXE_DEFAULT_IMAGE) -> None:
    _ssh_exe_dev(
        f"new --name={shlex.quote(name)} --image={shlex.quote(image)} --command=none --json",
        timeout_ms=120_000,
    )


def wait_for_exe_vm_ssh(name: str, max_attempts: int = 30) -> None:
    for attempt in range(1, max_attempts + 1):
        try:
            output = _ssh_exe_vm(name, 'echo ssh-ready', timeout_ms=10_000)
            if 'ssh-ready' in output:
                return
        except Exception:
            pass
        if attempt < max_attempts:
            time.sleep(3)
    raise RuntimeError(f'SSH not reachable for exe.dev VM {name!r} after {max_attempts} attempts')


def _exe_vm_prereqs_ready(name: str) -> bool:
    probe = (
        'if command -v curl >/dev/null 2>&1 && '
        'command -v sudo >/dev/null 2>&1 && '
        'command -v git >/dev/null 2>&1 && '
        'command -v file >/dev/null 2>&1 && '
        'command -v find >/dev/null 2>&1 && '
        'command -v python3 >/dev/null 2>&1 && '
        'test -e /dev/fuse && '
        'test -f /etc/ssl/certs/ca-certificates.crt; then echo ready; else echo missing; fi'
    )
    return _ssh_exe_vm(name, probe, timeout_ms=15_000).strip() == 'ready'


def ensure_exe_vm_prereqs(name: str) -> None:
    if _exe_vm_prereqs_ready(name):
        return

    install_cmd = (
        'log=/tmp/agentsh-exe-prereqs.log; '
        ': > "$log"; '
        'for attempt in $(seq 1 120); do '
        'if command -v curl >/dev/null 2>&1 && '
        'command -v sudo >/dev/null 2>&1 && '
        'command -v git >/dev/null 2>&1 && '
        'command -v file >/dev/null 2>&1 && '
        'command -v find >/dev/null 2>&1 && '
        'command -v python3 >/dev/null 2>&1 && '
        'test -e /dev/fuse && '
        'test -f /etc/ssl/certs/ca-certificates.crt; then echo ready; exit 0; fi; '
        'sed -i "s|http://archive.ubuntu.com|https://archive.ubuntu.com|g; s|http://security.ubuntu.com|https://security.ubuntu.com|g" /etc/apt/sources.list >>"$log" 2>&1; '
        'DEBIAN_FRONTEND=noninteractive apt-get -o Acquire::ForceIPv4=true -o Acquire::https::Verify-Peer=false -o Acquire::https::Verify-Host=false update -qq >>"$log" 2>&1 && '
        'DEBIAN_FRONTEND=noninteractive apt-get -o Acquire::ForceIPv4=true -o Acquire::https::Verify-Peer=false -o Acquire::https::Verify-Host=false install -y -qq '
        'ca-certificates curl sudo fuse3 libseccomp2 git file findutils python3 >>"$log" 2>&1; '
        'if command -v curl >/dev/null 2>&1 && '
        'command -v sudo >/dev/null 2>&1 && '
        'command -v git >/dev/null 2>&1 && '
        'command -v file >/dev/null 2>&1 && '
        'command -v find >/dev/null 2>&1 && '
        'test -e /dev/fuse && '
        'test -f /etc/ssl/certs/ca-certificates.crt; then echo ready; exit 0; fi; '
        'sleep 5; '
        'done; '
        'echo failed; tail -n 100 "$log" 2>/dev/null || true'
    )
    output = _ssh_exe_vm(name, install_cmd, timeout_ms=600_000)
    if 'ready' in output.split():
        return
    if _exe_vm_prereqs_ready(name):
        return
    raise RuntimeError(f'exe.dev VM prerequisites missing for {name}: {output.strip() or "no output"}')


def delete_exe_vm(name: str) -> None:
    _ssh_exe_dev(f"rm {shlex.quote(name)}", timeout_ms=60_000)


def resolve_or_create_exe_vm(prefix: str = 'agentsh-exe-e2e') -> tuple[str, bool]:
    require_exe_gateway_access()
    configured_name = ENV['EXE_VM_NAME'].strip()
    if configured_name:
        if not exe_vm_exists(configured_name):
            create_exe_vm(configured_name)
            wait_for_exe_vm_ssh(configured_name)
        ensure_exe_vm_prereqs(configured_name)
        return configured_name, False

    created_name = f"{prefix}-{int(time.time())}-{uuid4().hex[:6]}"
    create_exe_vm(created_name)
    wait_for_exe_vm_ssh(created_name)
    ensure_exe_vm_prereqs(created_name)
    return created_name, True


def cleanup_exe_vm(vm_name: str, destroy_on_cleanup: bool) -> None:
    if not destroy_on_cleanup or os.environ.get('KEEP_VM') == '1':
        return
    try:
        delete_exe_vm(vm_name)
    except Exception as exc:
        if not exe_vm_missing(str(exc)):
            raise


def exe_vm_missing(message: str) -> bool:
    normalized = message.lower()
    return normalized.startswith('vm "') and "not found" in normalized


async def require_exe_vm_available(adapter: Any) -> None:
    result = await adapter.exec("true")
    message = (getattr(result, "stdout", "") or "") + (getattr(result, "stderr", "") or "")
    if result.exit_code != 0 and exe_vm_missing(message.strip()):
        pytest.skip(f"Configured exe VM is unavailable: {message.strip()}")


def _refresh_e2e_state() -> None:
    global ENV
    global e2b_available, daytona_repo_available, daytona_openai_available, cloudflare_exec_available, cloudflare_sandbox_available, blaxel_available
    global vercel_available, sprites_available, modal_available, runloop_available
    global exe_available, freestyle_available
    global skip_no_e2b, skip_no_openai_api_key, skip_no_daytona, skip_no_daytona_repo
    global skip_no_daytona_openai, skip_no_cloudflare, skip_no_cloudflare_exec
    global skip_no_cloudflare_sandbox
    global skip_no_vercel, skip_no_blaxel, skip_no_sprites, skip_no_modal
    global skip_no_runloop, skip_no_exe, skip_no_freestyle

    ENV = _build_env()

    e2b_available = _sdk_available("e2b") and bool(ENV["E2B_API_KEY"])
    daytona_repo_available = _daytona_repo_available(ENV)
    daytona_openai_available = _daytona_openai_available(ENV)
    cloudflare_exec_available = _cloudflare_exec_available(ENV)
    cloudflare_sandbox_available = _cloudflare_sandbox_available(ENV)
    blaxel_available = (_sdk_available("blaxel_core") or _sdk_available("blaxel")) and bool(ENV["BLAXEL_API_KEY"])
    vercel_available = (
        _sdk_available("vercel")
        and bool(ENV["VERCEL_TOKEN"])
        and bool(ENV["VERCEL_PROJECT_ID"])
        and bool(ENV["VERCEL_TEAM_ID"])
    )
    sprites_available = (
        _sdk_available("sprites")
        and bool(ENV["SPRITES_TOKEN"] or (ENV["FLY_API_TOKEN"] and ENV["SPRITES_ORG"]))
    )
    modal_available = (
        _sdk_available("modal")
        and bool(ENV["MODAL_TOKEN_ID"])
        and bool(ENV["MODAL_TOKEN_SECRET"])
    )
    runloop_available = _sdk_available("runloop_api_client") and bool(ENV["RUNLOOP_API_KEY"])
    exe_available = _exe_available()
    freestyle_available = _sdk_available("httpx") and bool(ENV["FREESTYLE_API_KEY"])

    skip_no_e2b = pytest.mark.skipif(not e2b_available, reason="e2b SDK or E2B_API_KEY missing")
    skip_no_openai_api_key = pytest.mark.skipif(
        not ENV["OPENAI_API_KEY"],
        reason="OPENAI_API_KEY missing",
    )
    skip_no_daytona_repo = pytest.mark.skipif(
        not daytona_repo_available,
        reason="daytona_sdk or daytona with DAYTONA_API_KEY missing",
    )
    skip_no_daytona_openai = pytest.mark.skipif(
        not daytona_openai_available,
        reason="daytona or DAYTONA_API_KEY missing for OpenAI sandbox tests",
    )
    skip_no_cloudflare_exec = pytest.mark.skipif(
        not cloudflare_exec_available,
        reason="aiohttp, CLOUDFLARE_WORKER_URL, or CLOUDFLARE_API_TOKEN missing",
    )
    skip_no_cloudflare_sandbox = pytest.mark.skipif(
        not cloudflare_sandbox_available,
        reason="aiohttp, CLOUDFLARE_SANDBOX_WORKER_URL, or CLOUDFLARE_API_TOKEN missing",
    )
    skip_no_daytona = skip_no_daytona_repo
    skip_no_cloudflare = skip_no_cloudflare_exec
    skip_no_vercel = pytest.mark.skipif(
        not vercel_available,
        reason="vercel SDK or VERCEL_TOKEN/VERCEL_PROJECT_ID/VERCEL_TEAM_ID missing",
    )
    skip_no_blaxel = pytest.mark.skipif(
        not blaxel_available, reason="blaxel SDK or BLAXEL_API_KEY missing"
    )
    skip_no_sprites = pytest.mark.skipif(
        not sprites_available,
        reason="sprites-py SDK or Sprites credentials missing",
    )
    skip_no_modal = pytest.mark.skipif(
        not modal_available,
        reason="modal SDK or MODAL_TOKEN_ID/MODAL_TOKEN_SECRET missing",
    )
    skip_no_runloop = pytest.mark.skipif(
        not runloop_available,
        reason="runloop SDK or RUNLOOP_API_KEY missing",
    )
    skip_no_exe = pytest.mark.skipif(
        not exe_available,
        reason="ssh executable missing for exe.dev tests",
    )
    skip_no_freestyle = pytest.mark.skipif(
        not freestyle_available,
        reason="httpx missing or FREESTYLE_API_KEY unset",
    )


def _needs_e2e_env(config: pytest.Config) -> bool:
    markexpr = str(getattr(config.option, "markexpr", "") or "")
    if "openai_agent_e2e" in markexpr or ("e2e" in markexpr and "not e2e" not in markexpr):
        return True
    args = [str(arg) for arg in getattr(config, "args", [])]
    normalized_args = [arg.replace("\\", "/").rstrip("/") for arg in args]
    return any(
        arg == "tests/e2e"
        or arg.endswith("/tests/e2e")
        or arg.startswith("tests/e2e/")
        or "/tests/e2e/" in arg
        for arg in normalized_args
    )


def _is_pure_e2e_path_run(config: pytest.Config) -> bool:
    args = [str(arg) for arg in getattr(config, "args", [])]
    normalized_args = [arg.replace("\\", "/").rstrip("/") for arg in args]
    return bool(normalized_args) and all(
        arg == "tests/e2e"
        or arg.endswith("/tests/e2e")
        or arg.startswith("tests/e2e/")
        or "/tests/e2e/" in arg
        for arg in normalized_args
    )


def pytest_configure(config: pytest.Config) -> None:
    if _needs_e2e_env(config):
        load_additional_e2e_env_files()
        if _is_pure_e2e_path_run(config) and str(getattr(config.option, "markexpr", "") or "").strip() == "not e2e":
            config.option.markexpr = ""
        _refresh_e2e_state()


_refresh_e2e_state()


# ─── Fixtures ──────────────────────────────────────────────


@pytest.fixture(scope="module")
def env() -> dict[str, str]:
    return ENV


@pytest.fixture(scope="module")
def secured_e2b() -> Any:
    """Placeholder — actual fixture is in test_e2b.py module-scoped setup."""
    pytest.skip("Use module-level setup")
