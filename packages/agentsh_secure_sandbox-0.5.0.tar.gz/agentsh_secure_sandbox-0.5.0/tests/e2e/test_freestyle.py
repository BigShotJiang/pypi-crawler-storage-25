"""Freestyle end-to-end tests — mirrors test_runloop.py."""

from __future__ import annotations

import time

import pytest
import pytest_asyncio

from tests.e2e.conftest import skip_no_freestyle

from agentsh_secure_sandbox import SecuredSandbox, secure_sandbox
from agentsh_secure_sandbox.adapters.freestyle import (
    FreestyleClient,
    FreestyleVm,
    freestyle,
    freestyle_defaults,
)
from agentsh_secure_sandbox.core.types import ExecOpts

pytestmark = [
    pytest.mark.e2e,
    pytest.mark.timeout(900),
    skip_no_freestyle,
    pytest.mark.asyncio(loop_scope="module"),
]


@pytest_asyncio.fixture(scope="module", loop_scope="module")
async def freestyle_client():  # type: ignore[misc]
    """A module-scoped FreestyleClient."""
    async with FreestyleClient() as client:
        yield client


@pytest_asyncio.fixture(scope="module", loop_scope="module")
async def freestyle_vm(freestyle_client: FreestyleClient):  # type: ignore[misc]
    """Create a sandbox VM with agentsh baked in."""
    vm = await freestyle_client.create_sandbox_vm(install_timeout=180.0)

    yield vm

    try:
        await vm.stop()
    except Exception:
        pass


@pytest_asyncio.fixture(scope="module", loop_scope="module")
async def adapter(freestyle_vm: FreestyleVm):  # type: ignore[misc]
    return freestyle(freestyle_vm)


@pytest_asyncio.fixture(scope="module", loop_scope="module")
async def secured(adapter) -> SecuredSandbox:  # type: ignore[misc]
    sec = await secure_sandbox(adapter, freestyle_defaults())

    yield sec  # type: ignore[misc]

    await sec.stop()


class TestFreestyleSmoke:
    async def test_vm_has_id(self, freestyle_vm: FreestyleVm) -> None:
        assert isinstance(freestyle_vm.vm_id, str)
        assert freestyle_vm.vm_id


class TestFreestyleAdapter:
    async def test_exec_simple_command(self, adapter) -> None:
        result = await adapter.exec("echo", ["hello"])
        assert result.exit_code == 0
        assert result.stdout.strip() == "hello"

    async def test_exec_nonzero_exit(self, adapter) -> None:
        result = await adapter.exec("ls", ["/nonexistent-path-xyz"])
        assert result.exit_code != 0

    async def test_exec_with_env_vars(self, adapter) -> None:
        result = await adapter.exec(
            "sh", ["-c", "echo $TEST_VAR"],
            ExecOpts(env={"TEST_VAR": "freestyle-e2e"}),
        )
        assert result.exit_code == 0
        assert result.stdout.strip() == "freestyle-e2e"

    async def test_exec_with_cwd(self, adapter) -> None:
        result = await adapter.exec("pwd", opts=ExecOpts(cwd="/tmp"))
        assert result.exit_code == 0
        assert result.stdout.strip() == "/tmp"

    async def test_write_read_roundtrip(self, adapter) -> None:
        content = 'line1\nline2\ttab\n"quotes" & <brackets>'
        await adapter.write_file("/tmp/freestyle-e2e.txt", content)
        read = await adapter.read_file("/tmp/freestyle-e2e.txt")
        assert read == content

    async def test_file_exists_detects_pre_installed_agentsh(self, adapter) -> None:
        exists = await adapter.file_exists("/usr/local/bin/agentsh")
        assert exists is True


class TestFreestyleSecureSandbox:
    async def test_provisions_session_id(self, secured: SecuredSandbox) -> None:
        assert secured.session_id
        assert isinstance(secured.session_id, str)

    async def test_reports_valid_security_mode(self, secured: SecuredSandbox) -> None:
        assert secured.security_mode in (
            "full", "ptrace", "landlock", "landlock-only", "minimal",
        )

    async def test_exec_simple_command(self, secured: SecuredSandbox) -> None:
        result = await secured.exec("echo hello")
        assert result.exit_code == 0
        assert result.stdout.strip() == "hello"

    async def test_write_read_roundtrip(self, secured: SecuredSandbox) -> None:
        path = "/home/user/e2e-roundtrip.txt"
        content = f"freestyle-{int(time.time() * 1000)}"

        write_result = await secured.write_file(path, content)
        assert write_result.success is True

        read_result = await secured.read_file(path)
        assert read_result.success is True
        if read_result.success:
            assert read_result.content.strip() == content


class TestFreestylePolicy:
    async def test_denies_env_write(self, secured: SecuredSandbox) -> None:
        if secured.security_mode != "full":
            pytest.skip("file-deny policies require full security mode")
        result = await secured.write_file("/home/user/.env", "SECRET=leaked")
        assert result.success is False

    async def test_blocks_sudo(self, secured: SecuredSandbox) -> None:
        if secured.security_mode != "full":
            pytest.skip("command-deny policies require full security mode")
        result = await secured.exec("sudo whoami")
        assert result.exit_code != 0

    async def test_allows_npm_registry(self, secured: SecuredSandbox) -> None:
        result = await secured.exec(
            'curl -s --connect-timeout 5 -o /dev/null -w "%{http_code}" '
            "https://registry.npmjs.org/"
        )
        if result.exit_code != 0 or not result.stdout.strip():
            pytest.skip("curl not available in this sandbox")
        assert result.stdout.strip() == "200"

    async def test_blocks_unlisted_domain(self, secured: SecuredSandbox) -> None:
        result = await secured.exec(
            "curl -s -o /dev/null -w '%{http_code}' --connect-timeout 5"
            " https://example.com"
        )
        # Blocked domains should return 000 (no response), 403 (proxy deny),
        # or a non-2xx status — explicit check rather than the trivial "!= 200".
        code = result.stdout.strip()
        assert code != "200", f"example.com should be blocked but returned {code!r}"
        assert code == "" or code.startswith(("0", "4", "5")), (
            f"expected block signal, got {code!r}"
        )

    async def test_denies_ssh_keys(self, secured: SecuredSandbox) -> None:
        if secured.security_mode != "full":
            pytest.skip("file-deny policies require full security mode")
        result = await secured.exec("cat /home/user/.ssh/id_rsa")
        assert result.exit_code != 0
