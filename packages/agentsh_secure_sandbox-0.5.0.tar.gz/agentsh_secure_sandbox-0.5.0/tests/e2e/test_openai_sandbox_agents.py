from __future__ import annotations

import inspect
from pathlib import Path
from typing import Any

import pytest

from agents import ModelSettings, Runner
from agents.run import RunConfig
from agents.sandbox import Manifest, SandboxAgent, SandboxRunConfig

from tests.e2e.conftest import (
    ENV,
    cleanup_exe_vm,
    cleanup_sprites_target,
    require_sprites_command_endpoint,
    resolve_or_create_exe_vm,
    resolve_or_create_sprites_target,
    skip_no_blaxel,
    skip_no_cloudflare_sandbox,
    skip_no_daytona_openai,
    skip_no_e2b,
    skip_no_exe,
    skip_no_freestyle,
    skip_no_modal,
    skip_no_openai_api_key,
    skip_no_runloop,
    skip_no_sprites,
    skip_no_vercel,
)

pytestmark = [
    pytest.mark.e2e,
    pytest.mark.openai_agent_e2e,
    pytest.mark.timeout(900),
    pytest.mark.asyncio,
    skip_no_openai_api_key,
]


async def _run_minimal_agent_task(
    client: Any,
    workspace_root: str,
    options: Any,
    *,
    session_root: str | None = None,
) -> None:
    target_file = Path(workspace_root) / "openai-agent-smoke.txt"
    manifest_root = Path(session_root or workspace_root)
    patch = _agent_smoke_patch(target_file.relative_to(manifest_root))
    agent = SandboxAgent(
        name="Secure sandbox smoke agent",
        model="gpt-5.4",
        model_settings=ModelSettings(tool_choice="required"),
        instructions=(
            "Use sandbox tools only. Prefer apply_patch for text edits. "
            "Do not describe what you plan to do before you do it."
        ),
        default_manifest=Manifest(root=workspace_root),
    )

    session = await client.create(
        snapshot=None,
        manifest=Manifest(root=session_root or workspace_root),
        options=options,
    )
    try:
        last_output = ""
        prompts = [
            f"Use apply_patch with exactly this patch, then stop:\n\n{patch}",
            (
                "The file is still missing. Retry with apply_patch using exactly this patch, "
                f"then stop:\n\n{patch}"
            ),
            (
                "Try again. Use sandbox tools only. Apply exactly this patch, then stop:\n\n"
                f"{patch}"
            ),
        ]
        for prompt in prompts:
            result = await Runner.run(
                agent,
                prompt,
                run_config=RunConfig(
                    sandbox=SandboxRunConfig(session=session),
                    workflow_name="agentsh secure sandbox model e2e",
                ),
                max_turns=8,
            )
            last_output = str(result.final_output or "")
            try:
                read = await session.read(target_file)
            except FileNotFoundError:
                continue
            assert read.read().decode().strip() == "agent-ok"
            assert result.final_output
            return
        raise AssertionError(
            "agent did not create openai-agent-smoke.txt after retries; "
            f"last output: {last_output!r}"
        )
    finally:
        await client.delete(session)
        cleanup = getattr(client, "_test_cleanup", None)
        if cleanup is not None:
            result = cleanup()
            if inspect.isawaitable(result):
                await result
        await _close_client_if_possible(getattr(client, "upstream_client", None))


async def _close_client_if_possible(client: Any) -> None:
    if client is None:
        return
    close = getattr(client, "close", None)
    if close is None:
        return
    result = close()
    if inspect.isawaitable(result):
        await result


def _agent_smoke_patch(target_path: Path) -> str:
    return (
        "*** Begin Patch\n"
        f"*** Add File: {target_path.as_posix()}\n"
        "+agent-ok\n"
        "*** End Patch"
    )


async def _prepare_vercel_upstream_session(session: Any) -> None:
    result = await session.exec(
        "sudo",
        "-n",
        "dnf",
        "install",
        "-y",
        "libseccomp",
        "fuse3",
        "fuse3-libs",
        shell=False,
    )
    assert result.exit_code == 0, result.stderr.decode(errors="replace") or result.stdout.decode(errors="replace")


async def _prepare_modal_upstream_session(session: Any) -> None:
    result = await session.exec(
        "sh",
        "-lc",
        (
            "if command -v sudo >/dev/null 2>&1; then "
            "sudo -n apt-get update -qq && "
            "sudo -n apt-get install -y -qq ca-certificates curl bash git sudo libseccomp2 fuse3; "
            "else "
            "apt-get update -qq && "
            "apt-get install -y -qq ca-certificates curl bash git sudo libseccomp2 fuse3; "
            "fi"
        ),
        shell=False,
    )
    assert result.exit_code == 0, result.stderr.decode(errors="replace") or result.stdout.decode(errors="replace")


async def _prepare_blaxel_upstream_session(session: Any) -> None:
    result = await session.exec(
        "sh",
        "-lc",
        (
            "if command -v sudo >/dev/null 2>&1; then "
            "sudo -n mkdir -p /workspace && "
            "sudo -n apk add --no-cache gcompat curl bash libseccomp; "
            "else "
            "mkdir -p /workspace && "
            "apk add --no-cache gcompat curl bash libseccomp; "
            "fi"
        ),
        shell=False,
    )
    assert result.exit_code == 0, result.stderr.decode(errors="replace") or result.stdout.decode(errors="replace")


async def _make_e2b_case() -> tuple[Any, str, Any]:
    from agents.extensions.sandbox.e2b import E2BSandboxClient, E2BSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=E2BSandboxClient())
    options = E2BSandboxClientOptions(sandbox_type="e2b")
    return client, "/workspace", options


async def _make_daytona_case() -> tuple[Any, str, Any]:
    from agents.extensions.sandbox.daytona import DaytonaSandboxClient, DaytonaSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=DaytonaSandboxClient())
    return client, "/home/daytona", DaytonaSandboxClientOptions()


async def _make_modal_case() -> tuple[Any, str, Any]:
    from agents.extensions.sandbox.modal import ModalSandboxClient, ModalSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(
        upstream_client=ModalSandboxClient(),
        prepare_upstream_session=_prepare_modal_upstream_session,
    )
    options = ModalSandboxClientOptions(app_name="agentsh-openai-agent-e2e", timeout=900)
    return client, "/workspace", options


async def _make_runloop_case() -> tuple[Any, str, Any]:
    from agents.extensions.sandbox.runloop import RunloopSandboxClient, RunloopSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=RunloopSandboxClient())
    return client, "/home/user", RunloopSandboxClientOptions()


async def _make_vercel_case() -> tuple[Any, str, Any]:
    from agents.extensions.sandbox.vercel import VercelSandboxClient, VercelSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(
        upstream_client=VercelSandboxClient(),
        prepare_upstream_session=_prepare_vercel_upstream_session,
    )
    options = VercelSandboxClientOptions(
        project_id=ENV["VERCEL_PROJECT_ID"],
        team_id=ENV["VERCEL_TEAM_ID"],
    )
    return client, "/vercel/sandbox", options


async def _make_cloudflare_case() -> tuple[Any, str, Any]:
    from agents.extensions.sandbox.cloudflare import CloudflareSandboxClient, CloudflareSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=CloudflareSandboxClient())
    options = CloudflareSandboxClientOptions(
        worker_url=ENV["CLOUDFLARE_SANDBOX_WORKER_URL"],
        api_key=ENV["CLOUDFLARE_API_TOKEN"],
    )
    return client, "/workspace", options


async def _make_blaxel_case() -> tuple[Any, str, Any]:
    import time

    from agents.extensions.sandbox.blaxel import BlaxelSandboxClient, BlaxelSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(
        upstream_client=BlaxelSandboxClient(),
        prepare_upstream_session=_prepare_blaxel_upstream_session,
    )
    options = BlaxelSandboxClientOptions(name=f"agentsh-openai-agent-{int(time.time())}")
    return client, "/workspace", options, "/"


async def _make_sprites_case() -> tuple[Any, str, Any]:
    from agentsh_secure_sandbox.adapters import sprites as sprites_adapter, sprites_defaults
    from agentsh_secure_sandbox.openai_sandbox import SpritesSandboxClient

    sprites_client, sprite, created = resolve_or_create_sprites_target()
    await require_sprites_command_endpoint(sprites_adapter(sprite))
    config = sprites_defaults()
    if created:
        config = config.model_copy(update={"install_strategy": "download", "skip_integrity_check": False})
    client = SpritesSandboxClient(sprite=sprite, config=config)
    client._test_cleanup = lambda: cleanup_sprites_target(sprites_client, sprite, created)
    return client, "/home/sprite", None


async def _make_exe_case() -> tuple[Any, str, Any]:
    from agentsh_secure_sandbox.openai_sandbox import ExeSandboxClient

    vm_name, destroy_on_cleanup = resolve_or_create_exe_vm()
    client = ExeSandboxClient(vm_name=vm_name)
    client._test_cleanup = lambda: cleanup_exe_vm(vm_name, destroy_on_cleanup)
    return client, "/workspace", None


async def _make_freestyle_case() -> tuple[Any, str, Any]:
    from agentsh_secure_sandbox.openai_sandbox import FreestyleSandboxClient

    return FreestyleSandboxClient(), "/workspace", None


def _upstream_agent_provider_cases() -> list[dict[str, object]]:
    return [
        {"name": "e2b", "mark": skip_no_e2b, "factory": _make_e2b_case},
        {"name": "daytona", "mark": skip_no_daytona_openai, "factory": _make_daytona_case},
        {"name": "modal", "mark": skip_no_modal, "factory": _make_modal_case},
        {"name": "runloop", "mark": skip_no_runloop, "factory": _make_runloop_case},
        {"name": "vercel", "mark": skip_no_vercel, "factory": _make_vercel_case},
        {"name": "cloudflare", "mark": skip_no_cloudflare_sandbox, "factory": _make_cloudflare_case},
        {"name": "blaxel", "mark": skip_no_blaxel, "factory": _make_blaxel_case},
    ]


def _custom_agent_provider_cases() -> list[dict[str, object]]:
    return [
        {"name": "sprites", "mark": skip_no_sprites, "factory": _make_sprites_case},
        {"name": "exe", "mark": skip_no_exe, "factory": _make_exe_case},
        {"name": "freestyle", "mark": skip_no_freestyle, "factory": _make_freestyle_case},
    ]


@pytest.mark.parametrize(
    "case",
    [
        pytest.param(case, id=str(case["name"]), marks=case["mark"])
        for case in _upstream_agent_provider_cases()
    ],
)
async def test_openai_sandbox_agent_upstream_provider_smoke(case: dict[str, object]) -> None:
    produced = await case["factory"]()
    client, workspace_root, options = produced[:3]
    session_root = produced[3] if len(produced) > 3 else None
    await _run_minimal_agent_task(client, workspace_root, options, session_root=session_root)


@pytest.mark.parametrize(
    "case",
    [
        pytest.param(case, id=str(case["name"]), marks=case["mark"])
        for case in _custom_agent_provider_cases()
    ],
)
async def test_openai_sandbox_agent_custom_provider_smoke(case: dict[str, object]) -> None:
    produced = await case["factory"]()
    client, workspace_root, options = produced[:3]
    session_root = produced[3] if len(produced) > 3 else None
    await _run_minimal_agent_task(client, workspace_root, options, session_root=session_root)
