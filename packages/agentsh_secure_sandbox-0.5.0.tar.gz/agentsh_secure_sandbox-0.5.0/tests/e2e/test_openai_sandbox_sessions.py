from __future__ import annotations

import io
import time
from pathlib import Path
from typing import Any

import pytest

from agents.sandbox import Manifest

from tests.e2e.conftest import (
    ENV,
    cleanup_exe_vm,
    cleanup_sprites_target,
    require_sprites_command_endpoint,
    resolve_or_create_exe_vm,
    resolve_or_create_sprites_target,
    skip_no_blaxel,
    skip_no_cloudflare_sandbox,
    skip_no_daytona_openai,
    skip_no_e2b,
    skip_no_exe,
    skip_no_freestyle,
    skip_no_modal,
    skip_no_runloop,
    skip_no_sprites,
    skip_no_vercel,
)

pytestmark = [pytest.mark.e2e, pytest.mark.timeout(900), pytest.mark.asyncio]


async def _assert_session_baseline(session: Any, workspace_root: str) -> None:
    result = await session.exec("echo", "hello", shell=False)
    assert result.exit_code == 0
    assert result.stdout.decode().strip() == "hello"

    path = Path(workspace_root) / f"openai-session-{int(time.time() * 1000)}.txt"
    await session.write(path, io.BytesIO(b"session-roundtrip"))
    read = await session.read(path)
    assert read.read() == b"session-roundtrip"


async def _prepare_vercel_upstream_session(session: Any) -> None:
    result = await session.exec(
        "sudo",
        "-n",
        "dnf",
        "install",
        "-y",
        "libseccomp",
        "fuse3",
        "fuse3-libs",
        shell=False,
    )
    assert result.exit_code == 0, result.stderr.decode(errors="replace") or result.stdout.decode(errors="replace")


async def _prepare_modal_upstream_session(session: Any) -> None:
    result = await session.exec(
        "sh",
        "-lc",
        (
            "if command -v sudo >/dev/null 2>&1; then "
            "sudo -n apt-get update -qq && "
            "sudo -n apt-get install -y -qq ca-certificates curl bash git sudo libseccomp2 fuse3; "
            "else "
            "apt-get update -qq && "
            "apt-get install -y -qq ca-certificates curl bash git sudo libseccomp2 fuse3; "
            "fi"
        ),
        shell=False,
    )
    assert result.exit_code == 0, result.stderr.decode(errors="replace") or result.stdout.decode(errors="replace")


async def _prepare_blaxel_upstream_session(session: Any) -> None:
    result = await session.exec(
        "sh",
        "-lc",
        (
            "if command -v sudo >/dev/null 2>&1; then "
            "sudo -n mkdir -p /workspace && "
            "sudo -n apk add --no-cache gcompat curl bash libseccomp; "
            "else "
            "mkdir -p /workspace && "
            "apk add --no-cache gcompat curl bash libseccomp; "
            "fi"
        ),
        shell=False,
    )
    assert result.exit_code == 0, result.stderr.decode(errors="replace") or result.stdout.decode(errors="replace")


@skip_no_e2b
async def test_openai_sandbox_session_e2b() -> None:
    from agents.extensions.sandbox.e2b import E2BSandboxClient, E2BSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=E2BSandboxClient())
    options = E2BSandboxClientOptions(sandbox_type="e2b")
    session = await client.create(snapshot=None, manifest=Manifest(root="/workspace"), options=options)
    try:
        await _assert_session_baseline(session, "/workspace")
    finally:
        await client.delete(session)


@skip_no_daytona_openai
async def test_openai_sandbox_session_daytona() -> None:
    from agents.extensions.sandbox.daytona import DaytonaSandboxClient, DaytonaSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=DaytonaSandboxClient())
    options = DaytonaSandboxClientOptions()
    session = await client.create(
        snapshot=None,
        # The upstream Daytona session starts in /home/daytona and rejects a
        # non-existent cwd before the secure wrapper can create it.
        manifest=Manifest(root="/home/daytona"),
        options=options,
    )
    try:
        await _assert_session_baseline(session, "/home/daytona")
    finally:
        await client.delete(session)


@skip_no_modal
async def test_openai_sandbox_session_modal() -> None:
    from agents.extensions.sandbox.modal import ModalSandboxClient, ModalSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(
        upstream_client=ModalSandboxClient(),
        prepare_upstream_session=_prepare_modal_upstream_session,
    )
    options = ModalSandboxClientOptions(app_name="agentsh-openai-e2e", timeout=900)
    session = await client.create(snapshot=None, manifest=Manifest(root="/workspace"), options=options)
    try:
        await _assert_session_baseline(session, "/workspace")
    finally:
        await client.delete(session)


@skip_no_runloop
async def test_openai_sandbox_session_runloop() -> None:
    from agents.extensions.sandbox.runloop import RunloopSandboxClient, RunloopSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=RunloopSandboxClient())
    options = RunloopSandboxClientOptions()
    session = await client.create(snapshot=None, manifest=Manifest(root="/home/user"), options=options)
    try:
        await _assert_session_baseline(session, "/home/user")
    finally:
        await client.delete(session)


@skip_no_vercel
async def test_openai_sandbox_session_vercel() -> None:
    from agents.extensions.sandbox.vercel import VercelSandboxClient, VercelSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(
        upstream_client=VercelSandboxClient(),
        prepare_upstream_session=_prepare_vercel_upstream_session,
    )
    options = VercelSandboxClientOptions(
        project_id=ENV["VERCEL_PROJECT_ID"],
        team_id=ENV["VERCEL_TEAM_ID"],
    )
    session = await client.create(snapshot=None, manifest=Manifest(root="/vercel/sandbox"), options=options)
    try:
        await _assert_session_baseline(session, "/vercel/sandbox")
    finally:
        await client.delete(session)


@skip_no_cloudflare_sandbox
async def test_openai_sandbox_session_cloudflare() -> None:
    from agents.extensions.sandbox.cloudflare import CloudflareSandboxClient, CloudflareSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=CloudflareSandboxClient())
    options = CloudflareSandboxClientOptions(
        worker_url=ENV["CLOUDFLARE_SANDBOX_WORKER_URL"],
        api_key=ENV["CLOUDFLARE_API_TOKEN"],
    )
    session = await client.create(snapshot=None, manifest=Manifest(root="/workspace"), options=options)
    try:
        await _assert_session_baseline(session, "/workspace")
    finally:
        await client.delete(session)


@skip_no_blaxel
async def test_openai_sandbox_session_blaxel() -> None:
    from agents.extensions.sandbox.blaxel import BlaxelSandboxClient, BlaxelSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(
        upstream_client=BlaxelSandboxClient(),
        prepare_upstream_session=_prepare_blaxel_upstream_session,
    )
    options = BlaxelSandboxClientOptions(name=f"agentsh-openai-{int(time.time())}")
    session = await client.create(snapshot=None, manifest=Manifest(root="/"), options=options)
    try:
        await _assert_session_baseline(session, "/workspace")
    finally:
        await client.delete(session)


@skip_no_sprites
async def test_openai_sandbox_session_sprites() -> None:
    from agentsh_secure_sandbox.adapters import sprites as sprites_adapter, sprites_defaults
    from agentsh_secure_sandbox.openai_sandbox import SpritesSandboxClient

    sprites_client, sprite, created = resolve_or_create_sprites_target()
    try:
        await require_sprites_command_endpoint(sprites_adapter(sprite))
        config = sprites_defaults()
        if created:
            config = config.model_copy(update={"install_strategy": "download", "skip_integrity_check": False})
        client = SpritesSandboxClient(sprite=sprite, config=config)
        session = await client.create(snapshot=None, manifest=Manifest(root="/home/sprite"), options=None)
        try:
            await _assert_session_baseline(session, "/home/sprite")
        finally:
            await client.delete(session)
    finally:
        cleanup_sprites_target(sprites_client, sprite, created)


@skip_no_exe
async def test_openai_sandbox_session_exe() -> None:
    from agentsh_secure_sandbox.openai_sandbox import ExeSandboxClient

    vm_name, destroy_on_cleanup = resolve_or_create_exe_vm()
    client = ExeSandboxClient(vm_name=vm_name)
    try:
        session = await client.create(snapshot=None, manifest=Manifest(root="/workspace"), options=None)
        try:
            await _assert_session_baseline(session, "/workspace")
        finally:
            await client.delete(session)
    finally:
        cleanup_exe_vm(vm_name, destroy_on_cleanup)


@skip_no_freestyle
async def test_openai_sandbox_session_freestyle() -> None:
    from agentsh_secure_sandbox.openai_sandbox import FreestyleSandboxClient

    client = FreestyleSandboxClient()
    session = await client.create(snapshot=None, manifest=Manifest(root="/workspace"), options=None)
    try:
        await _assert_session_baseline(session, "/workspace")
    finally:
        await client.delete(session)
