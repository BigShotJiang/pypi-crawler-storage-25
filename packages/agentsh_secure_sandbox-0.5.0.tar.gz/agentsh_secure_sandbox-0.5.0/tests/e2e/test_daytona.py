"""Daytona end-to-end tests — mirrors daytona.e2e.test.ts."""

from __future__ import annotations

import time

import pytest
import pytest_asyncio

from tests.e2e.conftest import skip_no_daytona_repo

from agentsh_secure_sandbox import SecuredSandbox, secure_sandbox
from agentsh_secure_sandbox.adapters import daytona

pytestmark = [
    pytest.mark.e2e,
    pytest.mark.timeout(300),
    skip_no_daytona_repo,
    pytest.mark.asyncio(loop_scope="module"),
]

# ─── Module-scoped setup / teardown ────────────────────────


async def _cleanup_daytona_client(client: object | None, raw: object | None) -> None:
    if client is None:
        return
    try:
        if raw is not None:
            await client.delete(raw)
    finally:
        await client.close()


async def _create_secured_daytona(
    *,
    client_factory=None,
    adapter_factory=daytona,
    secure_factory=secure_sandbox,
) -> tuple[SecuredSandbox, object, object]:
    if client_factory is None:
        from daytona_sdk import AsyncDaytona  # type: ignore[import-untyped]

        client_factory = AsyncDaytona

    client = client_factory()
    raw = await client.create()
    try:
        sec = await secure_factory(adapter_factory(raw))
    except Exception:
        await _cleanup_daytona_client(client, raw)
        raise
    return sec, raw, client


@pytest_asyncio.fixture(scope="module", loop_scope="module")
async def secured() -> SecuredSandbox:  # type: ignore[misc]
    sec, raw, client = await _create_secured_daytona()
    try:
        yield sec  # type: ignore[misc]
    finally:
        await _cleanup_daytona_client(client, raw)


# ─── Smoke tests ──────────────────────────────────────────


class TestDaytonaSmoke:
    async def test_provisions_session_id(self, secured: SecuredSandbox) -> None:
        assert secured.session_id
        assert isinstance(secured.session_id, str)

    async def test_reports_valid_security_mode(self, secured: SecuredSandbox) -> None:
        assert secured.security_mode in ("full", "landlock", "landlock-only", "minimal")

    async def test_exec_simple_command(self, secured: SecuredSandbox) -> None:
        result = await secured.exec("echo hello")
        assert result.exit_code == 0
        assert result.stdout.strip() == "hello"

    async def test_write_read_roundtrip(self, secured: SecuredSandbox) -> None:
        path = "/workspace/e2e-test-file.txt"
        content = f"e2e-roundtrip-{int(time.time() * 1000)}"

        write_result = await secured.write_file(path, content)
        assert write_result.success is True

        read_result = await secured.read_file(path)
        assert read_result.success is True
        if read_result.success:
            assert read_result.content.strip() == content


# ─── Policy enforcement ───────────────────────────────────


class TestDaytonaPolicy:
    async def test_denies_env_write(self, secured: SecuredSandbox) -> None:
        result = await secured.write_file("/workspace/.env", "SECRET=leaked")
        if secured.security_mode in ("full",):
            assert result.success is False
        elif result.success:
            pytest.skip("FUSE not active — .env deny not enforced in this mode")

    async def test_allows_workspace_write(self, secured: SecuredSandbox) -> None:
        result = await secured.write_file("/workspace/allowed-file.txt", "allowed")
        assert result.success is True

    async def test_blocks_sudo(self, secured: SecuredSandbox) -> None:
        result = await secured.exec("sudo whoami")
        if secured.security_mode == "full":
            assert result.exit_code != 0
        elif result.exit_code == 0:
            pytest.skip(
                "sudo not blocked in this security mode "
                "(seccomp_user_notify required)"
            )

    async def test_blocks_env_command(self, secured: SecuredSandbox) -> None:
        result = await secured.exec("env")
        if secured.security_mode == "full":
            assert result.exit_code != 0
        elif result.exit_code == 0:
            pytest.skip("env command not blocked in this security mode")

    async def test_blocks_printenv(self, secured: SecuredSandbox) -> None:
        result = await secured.exec("printenv")
        if secured.security_mode == "full":
            assert result.exit_code != 0
        elif result.exit_code == 0:
            pytest.skip("printenv command not blocked in this security mode")

    async def test_allows_npm_registry(self, secured: SecuredSandbox) -> None:
        result = await secured.exec(
            'curl -s -o /dev/null -w "%{http_code}" https://registry.npmjs.org/'
        )
        if result.exit_code != 0 or not result.stdout.strip():
            pytest.skip("curl not available in this sandbox")
        assert result.stdout.strip() == "200"

    async def test_blocks_unauthorized_network(self, secured: SecuredSandbox) -> None:
        result = await secured.exec(
            "curl -s -o /dev/null -w '%{http_code}' --connect-timeout 5"
            " https://evil.example.com"
        )
        assert result.stdout.strip() != "200"

    async def test_filters_sensitive_env_vars(self, secured: SecuredSandbox) -> None:
        result = await secured.exec("printenv SECRET_KEY")
        assert result.stdout.strip() == ""
