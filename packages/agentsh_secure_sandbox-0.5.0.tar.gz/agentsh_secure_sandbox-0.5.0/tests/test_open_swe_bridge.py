"""Unit tests for the OpenSWE sandbox bridge.

These tests use a fake SecuredSandbox test double. No real provider
credentials are required. Gated on ``deepagents`` being importable;
if it isn't, the whole module is skipped.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import pytest

pytest.importorskip("deepagents")

# Put ``examples/`` on sys.path so ``open_swe.bridge`` is importable.
_EXAMPLES = Path(__file__).resolve().parent.parent / "examples"
if str(_EXAMPLES) not in sys.path:
    sys.path.insert(0, str(_EXAMPLES))

from agentsh_secure_sandbox.core.types import (  # noqa: E402
    ExecResult,
    ReadFileFailure,
    ReadFileResult,
    ReadFileSuccess,
    WriteFileFailure,
    WriteFileResult,
    WriteFileSuccess,
)


@dataclass
class _FakeSecuredSandbox:
    """Minimal fake that matches SecuredSandbox's async protocol.

    Each method records its calls and optionally dispatches to a handler
    supplied by the test. Default handlers return a generic success.
    """
    session_id: str = "fake-session-42"
    security_mode: str = "full"
    exec_handler: Callable[[str], ExecResult] | None = None
    exec_calls: list[tuple[str, dict]] = field(default_factory=list)
    read_handler: Callable[[str], ReadFileResult] | None = None
    read_calls: list[str] = field(default_factory=list)
    write_handler: Callable[[str, str | bytes], WriteFileResult] | None = None
    write_calls: list[tuple[str, str | bytes]] = field(default_factory=list)
    stop_called: bool = False

    async def exec(
        self,
        command: str,
        *,
        cwd: str | None = None,
        timeout: float | None = None,
    ) -> ExecResult:
        self.exec_calls.append((command, {"cwd": cwd, "timeout": timeout}))
        if self.exec_handler:
            return self.exec_handler(command)
        return ExecResult(stdout="", stderr="", exit_code=0)

    async def read_file(self, path: str) -> ReadFileResult:
        self.read_calls.append(path)
        if self.read_handler:
            return self.read_handler(path)
        return ReadFileSuccess(success=True, path=path, content="")

    async def write_file(
        self, path: str, content: str | bytes
    ) -> WriteFileResult:
        self.write_calls.append((path, content))
        if self.write_handler:
            return self.write_handler(path, content)
        return WriteFileSuccess(success=True, path=path)

    async def stop(self) -> None:
        self.stop_called = True


def test_make_backend_returns_backend_with_id():
    from open_swe.bridge import SecureSandboxBackend, make_backend

    async def _init(loop):
        return "my-id-42", _FakeSecuredSandbox(session_id="my-id-42")

    backend = make_backend(_init)
    try:
        assert isinstance(backend, SecureSandboxBackend)
        assert backend.id == "my-id-42"
    finally:
        backend.close()


def test_make_backend_cancels_inflight_init_on_timeout():
    """If async_init hangs past init_timeout, make_backend must cancel it
    and the initializer's ``finally`` block must run via CancelledError.

    This test deliberately does NOT raise from inside ``_init`` — it hangs
    on ``asyncio.sleep`` until cancellation propagates. That way the
    ``cleanup_ran`` flag is only set if the bridge's cancel-on-timeout
    logic works; a pre-fix implementation would stop the loop without
    ever cancelling the task, leaving the finally block unreached.
    """
    import asyncio as _asyncio
    import concurrent.futures

    from open_swe.bridge import make_backend

    cleanup_ran = {"value": False}

    async def _init(loop):
        try:
            await _asyncio.sleep(60)  # hang until cancelled
            return "never", _FakeSecuredSandbox()
        finally:
            cleanup_ran["value"] = True

    # init_timeout is deliberately short so the test is fast; 30s post-
    # cancellation grace gives CancelledError time to propagate.
    with pytest.raises((concurrent.futures.TimeoutError, TimeoutError)):
        make_backend(_init, init_timeout=0.3)

    assert cleanup_ran["value"] is True


def test_make_backend_chains_cleanup_error_to_init_error():
    """If cleanup during cancellation raises its own non-CancelledError,
    it should be chained via __context__ so it isn't silently lost."""
    import asyncio as _asyncio
    import concurrent.futures

    from open_swe.bridge import make_backend

    async def _init(loop):
        try:
            await _asyncio.sleep(60)
        except _asyncio.CancelledError:
            raise ValueError("cleanup exploded") from None

    with pytest.raises(
        (concurrent.futures.TimeoutError, TimeoutError)
    ) as exc_info:
        make_backend(_init, init_timeout=0.3)

    # The original timeout is what propagates to the caller, but the
    # cleanup failure must be attached as __context__ somewhere in the
    # chain so operators can debug it.
    chained = exc_info.value
    found_cleanup_error = False
    while chained is not None:
        if isinstance(chained, ValueError) and "cleanup exploded" in str(chained):
            found_cleanup_error = True
            break
        chained = chained.__context__
    assert found_cleanup_error


def test_make_backend_surfaces_late_init_exception():
    """If async_init raises just after the timeout, the late exception
    should be chained onto the TimeoutError so the caller sees both.

    Uses a blocking ``time.sleep`` inside ``_init`` to hold the event loop
    hostage. This prevents ``_cancel_and_drain`` from running before
    ``_init`` raises, making the test deterministic: when the drain runs,
    the init task is already done with an exception.
    """
    import concurrent.futures
    import time as _time

    from open_swe.bridge import make_backend

    async def _init(loop):
        # Blocking sleep prevents the event loop from processing
        # _cancel_and_drain until _init completes.
        _time.sleep(0.2)
        raise RuntimeError("late init failure")

    with pytest.raises(
        (concurrent.futures.TimeoutError, TimeoutError)
    ) as exc_info:
        make_backend(_init, init_timeout=0.05)

    # The late RuntimeError should appear in the __context__ chain.
    chained = exc_info.value
    found_late = False
    while chained is not None:
        if isinstance(chained, RuntimeError) and "late init failure" in str(
            chained
        ):
            found_late = True
            break
        chained = chained.__context__
    assert found_late, (
        f"Late init exception not found in chain: {exc_info.value!r}"
    )


def test_execute_stdout_only():
    from deepagents.backends.protocol import ExecuteResponse

    from open_swe.bridge import make_backend

    def fake_exec(command):
        assert command == "echo hello"
        return ExecResult(stdout="hello\n", stderr="", exit_code=0)

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(exec_handler=fake_exec)

    backend = make_backend(_init)
    try:
        result = backend.execute("echo hello")
        assert isinstance(result, ExecuteResponse)
        assert result.output == "hello\n"
        assert result.exit_code == 0
        assert result.truncated is False
    finally:
        backend.close()


def test_execute_concatenates_stderr_after_stdout():
    from open_swe.bridge import make_backend

    def fake_exec(command):
        return ExecResult(
            stdout="line-1\n", stderr="warning: X\n", exit_code=0
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(exec_handler=fake_exec)

    backend = make_backend(_init)
    try:
        result = backend.execute("some-cmd")
        # stdout first, then stderr separated by newline
        assert result.output == "line-1\n\nwarning: X\n"
    finally:
        backend.close()


def test_execute_stderr_only_when_no_stdout():
    from open_swe.bridge import make_backend

    def fake_exec(command):
        return ExecResult(stdout="", stderr="boom\n", exit_code=1)

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(exec_handler=fake_exec)

    backend = make_backend(_init)
    try:
        result = backend.execute("false")
        assert result.output == "boom\n"
        assert result.exit_code == 1
    finally:
        backend.close()


def test_execute_passes_timeout_through():
    from open_swe.bridge import make_backend

    fake = _FakeSecuredSandbox()

    async def _init(loop):
        return "sbx", fake

    backend = make_backend(_init)
    try:
        backend.execute("sleep 10", timeout=5)
        assert fake.exec_calls[-1] == (
            "sleep 10",
            {"cwd": None, "timeout": 5.0},
        )
    finally:
        backend.close()


def test_upload_files_success():
    from open_swe.bridge import make_backend

    fake = _FakeSecuredSandbox()

    async def _init(loop):
        return "sbx", fake

    backend = make_backend(_init)
    try:
        responses = backend.upload_files(
            [("/workspace/a.txt", b"hello"), ("/workspace/b.txt", b"world")]
        )
        assert len(responses) == 2
        assert responses[0].path == "/workspace/a.txt"
        assert responses[0].error is None
        assert responses[1].path == "/workspace/b.txt"
        assert responses[1].error is None
        assert fake.write_calls == [
            ("/workspace/a.txt", b"hello"),
            ("/workspace/b.txt", b"world"),
        ]
    finally:
        backend.close()


def test_upload_files_records_errors_per_entry():
    from open_swe.bridge import make_backend

    def fake_write(path, content):
        if path == "/denied/x.txt":
            return WriteFileFailure(success=False, path=path, error="policy: denied")
        return WriteFileSuccess(success=True, path=path)

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(write_handler=fake_write)

    backend = make_backend(_init)
    try:
        responses = backend.upload_files(
            [("/workspace/ok.txt", b"x"), ("/denied/x.txt", b"y")]
        )
        assert responses[0].error is None
        # Secure-sandbox error strings are mapped to the FileOperationError
        # Literal in deepagents. A generic "policy: denied" becomes
        # "permission_denied".
        assert responses[1].error == "permission_denied"
    finally:
        backend.close()


def test_download_files_returns_bytes_on_success():
    from open_swe.bridge import make_backend

    def fake_read(path):
        return ReadFileSuccess(
            success=True, path=path, content="file contents"
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        responses = backend.download_files(["/workspace/x.txt"])
        assert len(responses) == 1
        assert responses[0].path == "/workspace/x.txt"
        assert responses[0].content == b"file contents"
        assert responses[0].error is None
    finally:
        backend.close()


def test_download_files_records_error_per_entry():
    from open_swe.bridge import make_backend

    def fake_read(path):
        if path == "/missing":
            return ReadFileFailure(
                success=False, path=path, error="file not found"
            )
        return ReadFileSuccess(success=True, path=path, content="ok")

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        responses = backend.download_files(["/missing", "/good"])
        # "file not found" -> "file_not_found" via _map_error
        assert responses[0].content is None
        assert responses[0].error == "file_not_found"
        assert responses[1].content == b"ok"
        assert responses[1].error is None
    finally:
        backend.close()


def test_read_full_file():
    from open_swe.bridge import make_backend

    def fake_read(path):
        return ReadFileSuccess(
            success=True, path=path, content="line1\nline2\nline3\n"
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        result = backend.read("/workspace/x.txt")
        assert result.error is None
        assert result.file_data["content"] == "line1\nline2\nline3\n"
        assert result.file_data["encoding"] == "utf-8"
    finally:
        backend.close()


def test_read_with_offset_and_limit():
    from open_swe.bridge import make_backend

    def fake_read(path):
        content = "".join(f"line{i}\n" for i in range(1, 11))
        return ReadFileSuccess(success=True, path=path, content=content)

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        # Skip 2 lines, take 3 → lines 3,4,5
        result = backend.read("/workspace/x.txt", offset=2, limit=3)
        assert result.error is None
        assert result.file_data["content"] == "line3\nline4\nline5\n"
    finally:
        backend.close()


def test_read_returns_error_on_failure():
    from open_swe.bridge import make_backend

    def fake_read(path):
        return ReadFileFailure(
            success=False, path=path, error="policy: denied"
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        result = backend.read("/denied/x")
        assert result.error == "policy: denied"
        assert result.file_data is None
    finally:
        backend.close()


def test_write_success():
    from open_swe.bridge import make_backend

    fake = _FakeSecuredSandbox()

    async def _init(loop):
        return "sbx", fake

    backend = make_backend(_init)
    try:
        result = backend.write("/workspace/new.txt", "contents")
        assert result.error is None
        assert result.path == "/workspace/new.txt"
        assert fake.write_calls == [("/workspace/new.txt", "contents")]
    finally:
        backend.close()


def test_write_policy_denied():
    from open_swe.bridge import make_backend

    def fake_write(path, content):
        return WriteFileFailure(
            success=False, path=path, error="policy: write denied"
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(write_handler=fake_write)

    backend = make_backend(_init)
    try:
        result = backend.write("/denied/x", "contents")
        assert result.error == "policy: write denied"
    finally:
        backend.close()


def test_edit_single_occurrence():
    from open_swe.bridge import make_backend

    state = {"content": "hello WORLD hello"}

    def fake_read(path):
        return ReadFileSuccess(
            success=True, path=path, content=state["content"]
        )

    def fake_write(path, content):
        state["content"] = content
        return WriteFileSuccess(success=True, path=path)

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(
            read_handler=fake_read, write_handler=fake_write
        )

    backend = make_backend(_init)
    try:
        result = backend.edit("/workspace/x.txt", "WORLD", "EARTH")
        assert result.error is None
        assert result.path == "/workspace/x.txt"
        assert result.occurrences == 1
        assert state["content"] == "hello EARTH hello"
    finally:
        backend.close()


def test_edit_replace_all():
    from open_swe.bridge import make_backend

    state = {"content": "foo foo foo"}

    def fake_read(path):
        return ReadFileSuccess(
            success=True, path=path, content=state["content"]
        )

    def fake_write(path, content):
        state["content"] = content
        return WriteFileSuccess(success=True, path=path)

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(
            read_handler=fake_read, write_handler=fake_write
        )

    backend = make_backend(_init)
    try:
        result = backend.edit(
            "/workspace/x.txt", "foo", "bar", replace_all=True
        )
        assert result.error is None
        assert result.occurrences == 3
        assert state["content"] == "bar bar bar"
    finally:
        backend.close()


def test_edit_not_unique_without_replace_all():
    from open_swe.bridge import make_backend

    def fake_read(path):
        return ReadFileSuccess(
            success=True, path=path, content="foo foo"
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        result = backend.edit("/workspace/x.txt", "foo", "bar")
        assert result.error is not None
        assert "2 times" in result.error or "matches" in result.error
    finally:
        backend.close()


def test_edit_not_found():
    from open_swe.bridge import make_backend

    def fake_read(path):
        return ReadFileSuccess(
            success=True, path=path, content="hello"
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        result = backend.edit("/workspace/x.txt", "missing", "new")
        assert result.error is not None
        assert "not found" in result.error.lower()
    finally:
        backend.close()


def test_edit_propagates_read_error():
    from open_swe.bridge import make_backend

    def fake_read(path):
        return ReadFileFailure(success=False, path=path, error="denied")

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        result = backend.edit("/denied", "a", "b")
        assert result.error == "denied"
    finally:
        backend.close()


def test_factories_module_exports_modal_factory():
    import open_swe.factories as fac

    # The factory must exist as a callable with sandbox_id kwarg.
    assert callable(getattr(fac, "create_modal_sandbox", None))
    # Importing must NOT require Modal credentials — creation is lazy.


def test_factories_module_exports_daytona_factory():
    import open_swe.factories as fac

    assert callable(getattr(fac, "create_daytona_sandbox", None))
    assert "daytona" in fac.SANDBOX_FACTORIES


def test_factories_module_exports_runloop_factory():
    import open_swe.factories as fac

    assert callable(getattr(fac, "create_runloop_sandbox", None))
    assert "runloop" in fac.SANDBOX_FACTORIES


def test_factories_module_exports_e2b_factory():
    import open_swe.factories as fac

    assert callable(getattr(fac, "create_e2b_sandbox", None))
    assert "e2b" in fac.SANDBOX_FACTORIES


def test_factories_module_exports_freestyle_factory():
    import open_swe.factories as fac

    assert callable(getattr(fac, "create_freestyle_sandbox", None))
    assert "freestyle" in fac.SANDBOX_FACTORIES


def test_get_secure_sandbox_dispatches_by_name():
    import open_swe.factories as fac

    captured: list[tuple[str, str | None]] = []

    def fake_factory(sandbox_id: str | None = None):
        captured.append(("called", sandbox_id))
        return "SENTINEL"  # pretend backend

    original = fac.SANDBOX_FACTORIES.copy()
    fac.SANDBOX_FACTORIES["_test"] = fake_factory
    try:
        result = fac.get_secure_sandbox("_test", sandbox_id=None)
        assert result == "SENTINEL"
        assert captured == [("called", None)]
    finally:
        fac.SANDBOX_FACTORIES.clear()
        fac.SANDBOX_FACTORIES.update(original)


def test_get_secure_sandbox_unknown_name_raises():
    import open_swe.factories as fac

    with pytest.raises(KeyError) as excinfo:
        fac.get_secure_sandbox("nope")
    msg = str(excinfo.value)
    assert "nope" in msg
    assert "available" in msg
