from __future__ import annotations

import builtins
import importlib
import inspect
import os
import sys
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest


def _pop_modules(*prefixes: str) -> dict[str, object]:
    saved: dict[str, object] = {}
    for key in list(sys.modules):
        if any(key == prefix or key.startswith(f"{prefix}.") for prefix in prefixes):
            saved[key] = sys.modules.pop(key)
    return saved


def test_openai_sandbox_submodule_exports_public_symbols(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    module_name = "agentsh_secure_sandbox.openai_sandbox"
    package_name = "agentsh_secure_sandbox"
    saved_modules = _pop_modules("agents", "openai_agents", package_name, module_name)
    original_import = builtins.__import__
    imported_roots: set[str] = set()

    def fake_import(
        name: str,
        globals: object | None = None,
        locals: object | None = None,
        fromlist: tuple[str, ...] | tuple[object, ...] = (),
        level: int = 0,
    ) -> object:
        root = name.split(".")[0]
        if root in {"agents", "openai_agents"}:
            imported_roots.add(root)
        if root == "openai_agents":
            raise AssertionError("openai_agents should not be imported")
        return original_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", fake_import)

    try:
        openai_sandbox = importlib.import_module(module_name)

        from agentsh_secure_sandbox.openai_sandbox import (
            ExeSandboxClient,
            FreestyleSandboxClient,
            SecureOpenAISandboxClient,
            SecureOpenAISandboxSession,
            SpritesSandboxClient,
            secure_openai_sandbox_client,
        )
        from agentsh_secure_sandbox.openai_sandbox.wrappers import (
            SecureOpenAISandboxClient as wrapper_client,
        )
        from agentsh_secure_sandbox.openai_sandbox.unsupported import (
            ExeSandboxClient as unsupported_exe_client,
            FreestyleSandboxClient as unsupported_freestyle_client,
            SpritesSandboxClient as unsupported_sprites_client,
        )

        assert "SecureOpenAISandboxClient" in openai_sandbox.__all__
        assert "SecureOpenAISandboxSession" in openai_sandbox.__all__
        assert "secure_openai_sandbox_client" in openai_sandbox.__all__
        assert "SpritesSandboxClient" in openai_sandbox.__all__
        assert "ExeSandboxClient" in openai_sandbox.__all__
        assert "FreestyleSandboxClient" in openai_sandbox.__all__
        assert inspect.isclass(SecureOpenAISandboxClient)
        assert inspect.isclass(SecureOpenAISandboxSession)
        assert inspect.isclass(SpritesSandboxClient)
        assert inspect.isclass(ExeSandboxClient)
        assert inspect.isclass(FreestyleSandboxClient)
        assert SecureOpenAISandboxClient is wrapper_client
        assert SpritesSandboxClient is unsupported_sprites_client
        assert ExeSandboxClient is unsupported_exe_client
        assert FreestyleSandboxClient is unsupported_freestyle_client
        assert SecureOpenAISandboxClient.__name__ == "SecureOpenAISandboxClient"
        assert SecureOpenAISandboxSession.__name__ == "SecureOpenAISandboxSession"
        assert SpritesSandboxClient.__name__ == "SpritesSandboxClient"
        assert ExeSandboxClient.__name__ == "ExeSandboxClient"
        assert FreestyleSandboxClient.__name__ == "FreestyleSandboxClient"
        assert len(
            {
                SecureOpenAISandboxClient,
                SecureOpenAISandboxSession,
                SpritesSandboxClient,
                ExeSandboxClient,
                FreestyleSandboxClient,
            }
        ) == 5
        assert secure_openai_sandbox_client is not None
        upstream_client = MagicMock()
        upstream_client.backend_id = "demo"
        upstream_client.supports_default_options = True
        client = SecureOpenAISandboxClient(upstream_client=upstream_client)
        assert client.upstream_client is upstream_client
        assert client.backend_id == "agentsh-secure:demo"
        assert callable(secure_openai_sandbox_client)
        assert isinstance(
            secure_openai_sandbox_client(provider="exe", vm_name="vm-1"),
            ExeSandboxClient,
        )
        with pytest.raises(ValueError, match="sprite or sprite_factory"):
            SpritesSandboxClient()
        with pytest.raises(ValueError, match="vm_name"):
            ExeSandboxClient(vm_name="")
        freestyle_client = FreestyleSandboxClient(client=MagicMock())
        assert freestyle_client.backend_id == "agentsh-secure:freestyle"
        assert "agents" in imported_roots
        assert "openai_agents" not in imported_roots
    finally:
        _pop_modules(module_name, package_name, "agents", "openai_agents")
        sys.modules.update(saved_modules)


@pytest.mark.parametrize("import_error_root", ["agents", "openai_agents"])
def test_openai_sandbox_missing_optional_extra_exports_importerror(
    monkeypatch: pytest.MonkeyPatch,
    import_error_root: str,
) -> None:
    """Probe only `agents`; vary the ModuleNotFoundError.name we surface."""
    module_name = "agentsh_secure_sandbox.openai_sandbox"
    package_name = "agentsh_secure_sandbox"
    toolset_module_name = "agentsh_secure_sandbox.toolset.openai_agents"
    original_import = builtins.__import__
    saved_modules = _pop_modules(
        "agents",
        "openai_agents",
        package_name,
        module_name,
        toolset_module_name,
    )

    def fake_import(
        name: str,
        globals: object | None = None,
        locals: object | None = None,
        fromlist: tuple[str, ...] | tuple[object, ...] = (),
        level: int = 0,
    ) -> object:
        if name == "agents" or name.startswith("agents."):
            raise ModuleNotFoundError(
                f"No module named '{import_error_root}'",
                name=import_error_root,
            )
        return original_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", fake_import)

    try:
        module = importlib.import_module(module_name)

        assert inspect.isclass(module.SecureOpenAISandboxClient)
        assert inspect.isclass(module.SecureOpenAISandboxSession)
        assert inspect.isclass(module.SpritesSandboxClient)
        assert inspect.isclass(module.ExeSandboxClient)
        assert inspect.isclass(module.FreestyleSandboxClient)
        assert module.SecureOpenAISandboxClient.__name__ == "SecureOpenAISandboxClient"
        assert module.SecureOpenAISandboxSession.__name__ == "SecureOpenAISandboxSession"
        assert module.SpritesSandboxClient.__name__ == "SpritesSandboxClient"
        assert module.ExeSandboxClient.__name__ == "ExeSandboxClient"
        assert module.FreestyleSandboxClient.__name__ == "FreestyleSandboxClient"
        assert len(
            {
                module.SecureOpenAISandboxClient,
                module.SecureOpenAISandboxSession,
                module.SpritesSandboxClient,
                module.ExeSandboxClient,
                module.FreestyleSandboxClient,
            }
        ) == 5

        with pytest.raises(
            ImportError,
            match=(
                "OpenAI sandbox support requires the openai-agents extra. "
                "Install it with: pip install agentsh-secure-sandbox\\[openai-agents\\]"
            ),
        ):
            module.SecureOpenAISandboxSession()

        with pytest.raises(
            ImportError,
            match=(
                "OpenAI sandbox support requires the openai-agents extra. "
                "Install it with: pip install agentsh-secure-sandbox\\[openai-agents\\]"
            ),
        ):
            module.SecureOpenAISandboxClient()

        with pytest.raises(
            ImportError,
            match=(
                "OpenAI sandbox support requires the openai-agents extra. "
                "Install it with: pip install agentsh-secure-sandbox\\[openai-agents\\]"
            ),
        ):
            module.SpritesSandboxClient()

        with pytest.raises(
            ImportError,
            match=(
                "OpenAI sandbox support requires the openai-agents extra. "
                "Install it with: pip install agentsh-secure-sandbox\\[openai-agents\\]"
            ),
        ):
            module.ExeSandboxClient()

        with pytest.raises(
            ImportError,
            match=(
                "OpenAI sandbox support requires the openai-agents extra. "
                "Install it with: pip install agentsh-secure-sandbox\\[openai-agents\\]"
            ),
        ):
            module.FreestyleSandboxClient()

        with pytest.raises(
            ImportError,
            match=(
                "OpenAI sandbox support requires the openai-agents extra. "
                "Install it with: pip install agentsh-secure-sandbox\\[openai-agents\\]"
            ),
        ):
            module.secure_openai_sandbox_client()
    finally:
        _pop_modules(module_name, package_name, toolset_module_name, "agents", "openai_agents")
        sys.modules.update(saved_modules)


def test_top_level_package_defers_openai_sandbox_import_until_access() -> None:
    package_name = "agentsh_secure_sandbox"
    module_name = "agentsh_secure_sandbox.openai_sandbox"
    sys.modules.pop(module_name, None)
    sys.modules.pop(package_name, None)

    try:
        package = importlib.import_module(package_name)

        assert module_name not in sys.modules
        assert "SecureOpenAISandboxClient" in package.__all__
        assert "SecureOpenAISandboxSession" in package.__all__
        assert "secure_openai_sandbox_client" in package.__all__
        assert "SpritesSandboxClient" in package.__all__
        assert "ExeSandboxClient" in package.__all__
        assert "FreestyleSandboxClient" in package.__all__

        client = package.SecureOpenAISandboxClient
        assert module_name in sys.modules

        submodule = importlib.import_module(module_name)
        assert client is submodule.SecureOpenAISandboxClient
        assert package.SecureOpenAISandboxSession is submodule.SecureOpenAISandboxSession
        assert package.SpritesSandboxClient is submodule.SpritesSandboxClient
        assert package.ExeSandboxClient is submodule.ExeSandboxClient
        assert package.FreestyleSandboxClient is submodule.FreestyleSandboxClient
        assert package.secure_openai_sandbox_client is submodule.secure_openai_sandbox_client
    finally:
        sys.modules.pop(module_name, None)
        sys.modules.pop(package_name, None)


def test_top_level_package_exports_openai_sandbox_symbols() -> None:
    from agentsh_secure_sandbox import (
        ExeSandboxClient,
        FreestyleSandboxClient,
        SecureOpenAISandboxClient,
        SecureOpenAISandboxSession,
        SpritesSandboxClient,
        secure_openai_sandbox_client,
    )

    import agentsh_secure_sandbox as package

    assert "SecureOpenAISandboxClient" in package.__all__
    assert "SecureOpenAISandboxSession" in package.__all__
    assert "secure_openai_sandbox_client" in package.__all__
    assert "SpritesSandboxClient" in package.__all__
    assert "ExeSandboxClient" in package.__all__
    assert "FreestyleSandboxClient" in package.__all__
    assert inspect.isclass(SecureOpenAISandboxClient)
    assert inspect.isclass(SecureOpenAISandboxSession)
    assert inspect.isclass(SpritesSandboxClient)
    assert inspect.isclass(ExeSandboxClient)
    assert inspect.isclass(FreestyleSandboxClient)
    from agentsh_secure_sandbox.openai_sandbox.wrappers import (
        SecureOpenAISandboxClient as wrapper_client,
    )
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        ExeSandboxClient as unsupported_exe_client,
        FreestyleSandboxClient as unsupported_freestyle_client,
        SpritesSandboxClient as unsupported_sprites_client,
    )

    assert SecureOpenAISandboxClient is wrapper_client
    assert SpritesSandboxClient is unsupported_sprites_client
    assert ExeSandboxClient is unsupported_exe_client
    assert FreestyleSandboxClient is unsupported_freestyle_client
    assert SecureOpenAISandboxClient.__name__ == "SecureOpenAISandboxClient"
    assert SecureOpenAISandboxSession.__name__ == "SecureOpenAISandboxSession"
    assert SpritesSandboxClient.__name__ == "SpritesSandboxClient"
    assert ExeSandboxClient.__name__ == "ExeSandboxClient"
    assert FreestyleSandboxClient.__name__ == "FreestyleSandboxClient"
    assert len(
        {
            SecureOpenAISandboxClient,
            SecureOpenAISandboxSession,
            SpritesSandboxClient,
            ExeSandboxClient,
            FreestyleSandboxClient,
        }
    ) == 5
    assert secure_openai_sandbox_client is not None
    upstream_client = MagicMock()
    upstream_client.backend_id = "top-level"
    upstream_client.supports_default_options = False
    client = SecureOpenAISandboxClient(upstream_client=upstream_client)
    assert client.upstream_client is upstream_client
    assert client.backend_id == "agentsh-secure:top-level"
    assert isinstance(
        secure_openai_sandbox_client(provider="exe", vm_name="vm-1"),
        ExeSandboxClient,
    )
    with pytest.raises(ValueError, match="sprite or sprite_factory"):
        SpritesSandboxClient()
    with pytest.raises(ValueError, match="vm_name"):
        ExeSandboxClient(vm_name="")
    freestyle_client = FreestyleSandboxClient(client=MagicMock())
    assert freestyle_client.backend_id == "agentsh-secure:freestyle"


def test_e2e_env_files_loader_loads_explicit_files(tmp_path, monkeypatch) -> None:
    from tests.e2e.conftest import load_additional_e2e_env_files

    first_env_file = tmp_path / ".env.first"
    second_env_file = tmp_path / ".env.second"
    first_env_file.write_text("OPENAI_API_KEY=sk-first\nCUSTOM_PROVIDER_KEY=first\n")
    second_env_file.write_text("OPENAI_API_KEY=sk-second\nCUSTOM_PROVIDER_KEY=second\n")

    monkeypatch.setenv("OPENAI_API_KEY", "stale-root")
    monkeypatch.setenv("CUSTOM_PROVIDER_KEY", "stale-root")
    monkeypatch.setenv(
        "AGENTSH_E2E_ENV_FILES",
        os.pathsep.join([str(first_env_file), str(second_env_file)]),
    )

    loaded = load_additional_e2e_env_files()

    assert loaded == [str(first_env_file), str(second_env_file)]
    assert os.environ["OPENAI_API_KEY"] == "sk-second"
    assert os.environ["CUSTOM_PROVIDER_KEY"] == "second"


def test_e2e_env_needs_path_based_collection() -> None:
    from tests.e2e.conftest import _is_pure_e2e_path_run, _needs_e2e_env

    assert _needs_e2e_env(SimpleNamespace(option=SimpleNamespace(markexpr=""), args=["tests/e2e/test_openai_sandbox_sessions.py"]))
    assert _needs_e2e_env(SimpleNamespace(option=SimpleNamespace(markexpr=""), args=["tests/e2e"]))
    assert _needs_e2e_env(SimpleNamespace(option=SimpleNamespace(markexpr=""), args=["/abs/path/to/tests/e2e"]))
    assert not _needs_e2e_env(SimpleNamespace(option=SimpleNamespace(markexpr=""), args=[]))
    assert _is_pure_e2e_path_run(SimpleNamespace(option=SimpleNamespace(markexpr=""), args=["tests/e2e"]))
    assert _is_pure_e2e_path_run(SimpleNamespace(option=SimpleNamespace(markexpr=""), args=["/abs/path/to/tests/e2e"]))
    assert not _is_pure_e2e_path_run(
        SimpleNamespace(option=SimpleNamespace(markexpr=""), args=["tests/e2e", "tests/test_openai_sandbox_public_api.py"])
    )


def test_pytest_configure_clears_default_markexpr_for_pure_e2e_path_runs(monkeypatch) -> None:
    from tests.e2e import conftest

    monkeypatch.setattr(conftest, "load_additional_e2e_env_files", lambda: [])
    monkeypatch.setattr(conftest, "_refresh_e2e_state", lambda: None)

    config = SimpleNamespace(option=SimpleNamespace(markexpr="not e2e"), args=["tests/e2e"])

    conftest.pytest_configure(config)

    assert config.option.markexpr == ""


def test_pytest_configure_preserves_mixed_invocation_markexpr(monkeypatch) -> None:
    from tests.e2e import conftest

    monkeypatch.setattr(conftest, "load_additional_e2e_env_files", lambda: [])
    monkeypatch.setattr(conftest, "_refresh_e2e_state", lambda: None)

    config = SimpleNamespace(
        option=SimpleNamespace(markexpr="not e2e"),
        args=["tests/e2e", "tests/test_openai_sandbox_public_api.py"],
    )

    conftest.pytest_configure(config)

    assert config.option.markexpr == "not e2e"
