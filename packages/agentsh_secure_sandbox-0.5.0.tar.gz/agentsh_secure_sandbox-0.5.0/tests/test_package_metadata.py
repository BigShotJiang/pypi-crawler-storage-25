from pathlib import Path
import tomllib


def test_daytona_extra_installs_both_sdks() -> None:
    data = tomllib.loads((Path(__file__).resolve().parents[1] / "pyproject.toml").read_text())
    deps = data["project"]["optional-dependencies"]["daytona"]

    assert "daytona-sdk>=0.10" in deps
    assert "daytona>=0.19" in deps


def test_vercel_extra_installs_sdk() -> None:
    data = tomllib.loads((Path(__file__).resolve().parents[1] / "pyproject.toml").read_text())
    deps = data["project"]["optional-dependencies"]["vercel"]

    assert "vercel>=0.5.7" in deps
