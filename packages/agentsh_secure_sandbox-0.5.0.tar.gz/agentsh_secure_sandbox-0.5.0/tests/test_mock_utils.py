# tests/test_mock_utils.py
from agentsh_secure_sandbox.testing.mock import mock_secured_sandbox, mock_adapter
from agentsh_secure_sandbox.core.types import ExecResult


async def test_mock_sandbox_exec_known():
    sb = mock_secured_sandbox(
        commands={"echo hello": ExecResult(stdout="hello\n", stderr="", exit_code=0)},
    )
    result = await sb.exec("echo hello")
    assert result.stdout == "hello\n"


async def test_mock_sandbox_exec_unknown():
    sb = mock_secured_sandbox()
    result = await sb.exec("unknown_cmd")
    assert result.exit_code == 1


async def test_mock_sandbox_write_read():
    sb = mock_secured_sandbox()
    wr = await sb.write_file("/tmp/test.txt", "data")
    assert wr.success is True
    rr = await sb.read_file("/tmp/test.txt")
    assert rr.success is True
    assert rr.content == "data"


async def test_mock_sandbox_write_bytes():
    sb = mock_secured_sandbox()
    await sb.write_file("/tmp/bin", b"\x00\x01\x02")
    rr = await sb.read_file("/tmp/bin")
    # Bytes should be decoded
    assert rr.success is True


async def test_mock_sandbox_read_missing():
    sb = mock_secured_sandbox()
    rr = await sb.read_file("/nonexistent")
    assert rr.success is False


async def test_mock_sandbox_properties():
    sb = mock_secured_sandbox(session_id="test-sid", security_mode="landlock")
    assert sb.session_id == "test-sid"
    assert sb.security_mode == "landlock"


async def test_mock_adapter_sequential():
    results = [
        ExecResult(stdout="first", stderr="", exit_code=0),
        ExecResult(stdout="second", stderr="", exit_code=0),
    ]
    adapter = mock_adapter(exec_results=results)
    r1 = await adapter.exec("cmd1")
    assert r1.stdout == "first"
    r2 = await adapter.exec("cmd2")
    assert r2.stdout == "second"
    r3 = await adapter.exec("cmd3")
    assert r3.exit_code == 0  # Default empty result
