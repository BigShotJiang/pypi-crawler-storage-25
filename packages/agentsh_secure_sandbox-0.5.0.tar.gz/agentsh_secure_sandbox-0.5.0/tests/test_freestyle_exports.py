"""Check that the freestyle public API is importable from expected places."""

from __future__ import annotations


class TestFreestylePublicAPI:
    def test_freestyle_sub_package_re_exports(self) -> None:
        from agentsh_secure_sandbox.adapters.freestyle import (
            FreestyleClient,
            FreestyleConfigureOptions,
            FreestyleError,
            FreestyleVm,
            FreestyleVmSpec,
            configure_freestyle_spec,
            freestyle,
            freestyle_defaults,
        )
        assert FreestyleClient is not None
        assert FreestyleError is not None
        assert FreestyleVm is not None
        assert FreestyleVmSpec is not None
        assert FreestyleConfigureOptions is not None
        assert callable(configure_freestyle_spec)
        assert callable(freestyle)
        assert callable(freestyle_defaults)

    def test_adapters_re_exports(self) -> None:
        from agentsh_secure_sandbox.adapters import (
            FreestyleClient,
            FreestyleVm,
            FreestyleVmSpec,
            configure_freestyle_spec,
            freestyle,
            freestyle_defaults,
        )
        assert FreestyleClient is not None
        assert FreestyleVm is not None
        assert FreestyleVmSpec is not None
        assert callable(configure_freestyle_spec)
        assert callable(freestyle)
        assert callable(freestyle_defaults)
