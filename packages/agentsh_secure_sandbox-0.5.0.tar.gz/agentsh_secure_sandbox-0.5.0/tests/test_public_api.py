# tests/test_public_api.py


def test_top_level_imports():
    from agentsh_secure_sandbox import (  # noqa: F401
        AuditIntegrityConfig,
        AwsKmsConfig,
        AwsSmProvider,
        AzureKeyVaultConfig,
        AzureKvProvider,
        ExecOpts,
        ExecResult,
        GcpKmsConfig,
        GcpSmProvider,
        HashicorpVaultConfig,
        HttpService,
        HttpServiceInject,
        HttpServiceInjectHeader,
        HttpServiceRule,
        HttpServiceSecret,
        KeyringProvider,
        OpProvider,
        PolicyDefinition,
        ReadFileFailure,
        ReadFileResult,
        ReadFileSuccess,
        SandboxAdapter,
        SandboxAdapterBase,
        SecretProvider,
        SecureConfig,
        SecureSandboxAgentTools,
        SecureSandboxToolkit,
        SecureSandboxToolset,
        SecuredSandbox,
        VaultAuth,
        VaultProvider,
        WriteFileFailure,
        WriteFileResult,
        WriteFileSuccess,
        secure_sandbox,
        AgentSHError,
        PolicyValidationError,
        ProvisioningError,
        IntegrityError,
        TransportError,
    )


def test_policies_namespace():
    from agentsh_secure_sandbox.policies import (  # noqa: F401
        agent_default,
        dev_safe,
        ci_strict,
        agent_sandbox,
        merge,
        merge_prepend,
        PolicyDefinition,
        validate_policy,
        serialize_policy,
    )


def test_adapters_namespace():
    from agentsh_secure_sandbox.adapters import (  # noqa: F401
        vercel,
        VercelSandbox,
        e2b,
        daytona,
        cloudflare,
        blaxel,
        sprites,
        sprites_defaults,
        modal,
        modal_defaults,
        runloop,
        runloop_defaults,
        exe,
        exe_defaults,
    )


def test_version():
    from agentsh_secure_sandbox._version import __version__

    # Verify version is a valid semver string
    parts = __version__.split(".")
    assert len(parts) == 3
    assert all(p.isdigit() for p in parts)
