# tests/test_trace.py
import os
from unittest.mock import patch
from agentsh_secure_sandbox.core.trace import resolve_trace_parent


def test_explicit_false_disables():
    assert resolve_trace_parent(False) is None


def test_explicit_string_passthrough():
    tp = "00-abc123-def456-01"
    assert resolve_trace_parent(tp) == tp


def test_auto_from_env():
    with patch.dict(os.environ, {"TRACEPARENT": "00-envvalue-span-01"}):
        result = resolve_trace_parent(None)
        assert result == "00-envvalue-span-01"


def test_auto_no_sources():
    with patch.dict(os.environ, {}, clear=True):
        # No OTel, no env var
        result = resolve_trace_parent(None)
        assert result is None
