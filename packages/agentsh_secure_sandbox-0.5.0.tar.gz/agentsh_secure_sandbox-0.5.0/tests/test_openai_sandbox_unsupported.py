from __future__ import annotations

import asyncio
import base64
import io
import shlex
from pathlib import Path
from uuid import uuid4
from unittest.mock import AsyncMock, MagicMock

import pytest

agents_manifest_mod = pytest.importorskip("agents.sandbox.manifest")
agents_snapshot_mod = pytest.importorskip("agents.sandbox.snapshot")

Manifest = agents_manifest_mod.Manifest
NoopSnapshot = agents_snapshot_mod.NoopSnapshot


def _make_state(
    provider: str = "unit",
    handle: str | None = None,
    root: str = "/workspace",
):
    from agentsh_secure_sandbox.openai_sandbox.unsupported import UnsupportedProviderSessionState

    return UnsupportedProviderSessionState(
        provider=provider,
        handle=handle,
        manifest=Manifest(root=root),
        snapshot=NoopSnapshot(id=str(uuid4())),
    )


async def test_secured_adapter_session_exec_read_write() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        _SecuredAdapterSession,
    )

    state = _make_state()
    secured = AsyncMock()
    secured.exec = AsyncMock(return_value=MagicMock(stdout="ok", stderr="", exit_code=0))
    secured.write_file = AsyncMock(
        return_value=MagicMock(success=True, path="/workspace/a.txt")
    )
    secured.read_file = AsyncMock(
        return_value=MagicMock(success=True, path="/workspace/a.txt", content="payload")
    )

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    exec_result = await session.exec("echo", "ok", shell=False)
    await session.write(Path("/workspace/a.txt"), io.BytesIO(b"payload"), user=None)
    read_result = await session.read(Path("/workspace/a.txt"), user=None)

    assert exec_result.stdout == b"ok"
    assert exec_result.stderr == b""
    assert exec_result.exit_code == 0
    assert read_result.read() == b"payload"
    secured.exec.assert_awaited_once_with("echo ok", timeout=None)
    secured.write_file.assert_awaited_once_with("/workspace/a.txt", b"payload")
    secured.read_file.assert_awaited_once_with("/workspace/a.txt")


async def test_secured_adapter_session_exec_rejects_user_override() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import _SecuredAdapterSession

    state = _make_state()
    secured = AsyncMock()
    secured.exec = AsyncMock(return_value=MagicMock(stdout="ok", stderr="", exit_code=0))

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    with pytest.raises(NotImplementedError, match="user overrides"):
        await session.exec("echo", "ok", user="root")


async def test_secured_adapter_session_persist_and_hydrate_workspace() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import _SecuredAdapterSession

    root = "/work dir/it's ok"
    state = _make_state(root=root)
    archive_bytes = b"archive-bytes"
    secured = AsyncMock()
    secured.exec = AsyncMock(
        side_effect=[
            MagicMock(
                stdout=base64.b64encode(archive_bytes).decode("ascii"),
                stderr="",
                exit_code=0,
            ),
            MagicMock(stdout="", stderr="", exit_code=0),
        ]
    )
    secured.write_file = AsyncMock(return_value=MagicMock(success=True, path="/tmp/archive.tar"))

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    archive = await session.persist_workspace()
    await session.hydrate_workspace(io.BytesIO(b"tar-bytes"))

    assert archive.read() == archive_bytes
    assert secured.exec.await_count == 3

    persist_command = secured.exec.await_args_list[0].args[0]
    hydrate_command = secured.exec.await_args_list[1].args[0]
    cleanup_command = secured.exec.await_args_list[2].args[0]
    assert 'tar -C "$root" -cf "$archive" .' in persist_command
    assert 'base64 -w0 "$archive"' in persist_command
    assert "|" not in persist_command
    quoted_root = shlex.quote(root)
    assert quoted_root in persist_command
    assert quoted_root in hydrate_command
    assert 'stage=$(mktemp -d /tmp/agentsh-openai-staging.XXXXXX)' in hydrate_command
    assert 'stage_root="$stage/root"' in hydrate_command
    assert 'backup=$(mktemp -d "$root/.agentsh-openai-backup.XXXXXX")' in hydrate_command
    assert "tar -tf" in hydrate_command
    assert hydrate_command.index("tar -tf") < hydrate_command.index('mkdir -p "$root"')
    assert 'find "$root" -mindepth 1 -maxdepth 1 ! -name "$(basename -- "$backup")" -exec mv {} "$backup"/' in hydrate_command
    assert 'if find "$stage_root" -mindepth 1 -maxdepth 1 -exec mv {} "$root"/' in hydrate_command
    assert 'cp -a' not in hydrate_command
    secured.write_file.assert_awaited_once()
    archive_path, archive_payload = secured.write_file.await_args.args
    assert archive_payload == b"tar-bytes"
    assert archive_path.startswith("/tmp/agentsh-openai-hydrate-")
    assert archive_path.endswith(".tar")
    assert shlex.quote(archive_path) in hydrate_command
    assert shlex.quote(archive_path) in cleanup_command


async def test_secured_adapter_session_persist_nonzero_exit_raises() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import _SecuredAdapterSession

    state = _make_state()
    secured = AsyncMock()
    secured.exec = AsyncMock(
        return_value=MagicMock(stdout="ignored", stderr="boom", exit_code=1)
    )

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    with pytest.raises(RuntimeError, match="workspace persistence failed"):
        await session.persist_workspace()


async def test_secured_adapter_session_persist_invalid_base64_raises() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import _SecuredAdapterSession

    state = _make_state()
    secured = AsyncMock()
    secured.exec = AsyncMock(
        return_value=MagicMock(stdout="not-base64!!!", stderr="", exit_code=0)
    )

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    with pytest.raises(RuntimeError, match="invalid base64"):
        await session.persist_workspace()


async def test_secured_adapter_session_hydrate_nonzero_exit_raises() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import _SecuredAdapterSession

    state = _make_state()
    secured = AsyncMock()
    secured.exec = AsyncMock(return_value=MagicMock(stdout="", stderr="boom", exit_code=1))
    secured.write_file = AsyncMock(return_value=MagicMock(success=True, path="/tmp/archive.tar"))

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    with pytest.raises(RuntimeError, match="workspace hydration failed"):
        await session.hydrate_workspace(io.BytesIO(b"tar-bytes"))

    hydrate_command = secured.exec.await_args_list[0].args[0]
    assert "tar -tf" in hydrate_command
    assert 'stage=$(mktemp -d /tmp/agentsh-openai-staging.XXXXXX)' in hydrate_command
    assert 'stage_root="$stage/root"' in hydrate_command
    assert 'backup=$(mktemp -d "$root/.agentsh-openai-backup.XXXXXX")' in hydrate_command
    cleanup_command = secured.exec.await_args_list[1].args[0]
    archive_path, _archive_payload = secured.write_file.await_args.args
    assert cleanup_command == f"rm -f {shlex.quote(archive_path)}"


async def test_secured_adapter_session_hydrate_write_failure_raises() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import _SecuredAdapterSession

    state = _make_state()
    secured = AsyncMock()
    secured.write_file = AsyncMock(
        return_value=MagicMock(success=False, path="/tmp/archive.tar", error="write failed")
    )
    secured.exec = AsyncMock()

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    with pytest.raises(RuntimeError, match="write failed"):
        await session.hydrate_workspace(io.BytesIO(b"tar-bytes"))

    archive_path, _archive_payload = secured.write_file.await_args.args
    secured.exec.assert_awaited_once_with(f"rm -f {shlex.quote(archive_path)}", timeout=None)


async def test_secured_adapter_session_hydrate_exec_transport_failure_triggers_cleanup() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import _SecuredAdapterSession

    state = _make_state()
    secured = AsyncMock()
    secured.write_file = AsyncMock(return_value=MagicMock(success=True, path="/tmp/archive.tar"))
    secured.exec = AsyncMock(side_effect=[ConnectionError("transport down"), None])

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    with pytest.raises(ConnectionError, match="transport down"):
        await session.hydrate_workspace(io.BytesIO(b"tar-bytes"))

    assert secured.exec.await_count == 2
    archive_path, _archive_payload = secured.write_file.await_args.args
    assert secured.exec.await_args_list[1].args[0] == f"rm -f {shlex.quote(archive_path)}"


async def test_secured_adapter_session_hydrate_cleanup_failure_does_not_mask_original() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import _SecuredAdapterSession

    state = _make_state()
    secured = AsyncMock()
    secured.write_file = AsyncMock(return_value=MagicMock(success=True, path="/tmp/archive.tar"))
    secured.exec = AsyncMock(
        side_effect=[
            MagicMock(stdout="", stderr="boom", exit_code=1),
            RuntimeError("cleanup failed"),
        ]
    )

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    with pytest.raises(RuntimeError, match="workspace hydration failed"):
        await session.hydrate_workspace(io.BytesIO(b"tar-bytes"))

    assert secured.exec.await_count == 2


async def test_secured_adapter_session_resolve_exposed_port_not_supported() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import _SecuredAdapterSession

    state = _make_state()
    secured = AsyncMock()

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    with pytest.raises(NotImplementedError, match="exposed ports"):
        await session._resolve_exposed_port(8080)


async def test_secured_adapter_session_rejects_user_overrides() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import _SecuredAdapterSession

    state = _make_state()
    secured = AsyncMock()
    secured.exec = AsyncMock(return_value=MagicMock(stdout="", stderr="", exit_code=0))
    secured.write_file = AsyncMock(return_value=MagicMock(success=True, path="/workspace/a.txt"))
    secured.read_file = AsyncMock(return_value=MagicMock(success=True, path="/workspace/a.txt", content=""))

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    with pytest.raises(NotImplementedError, match="user overrides"):
        await session.read(Path("/workspace/a.txt"), user="root")

    with pytest.raises(NotImplementedError, match="user overrides"):
        await session.write(Path("/workspace/a.txt"), io.BytesIO(b"payload"), user="root")


async def test_secured_adapter_session_running_and_shutdown_once() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import _SecuredAdapterSession

    state = _make_state()
    secured = AsyncMock()
    secured.stop = AsyncMock()

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    assert await session.running() is True
    await session.shutdown()
    assert await session.running() is False
    await session.shutdown()

    secured.stop.assert_awaited_once()


async def test_secured_adapter_session_shutdown_retries_then_stops_once() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import _SecuredAdapterSession

    state = _make_state()
    secured = AsyncMock()
    secured.stop = AsyncMock(side_effect=[RuntimeError("boom"), None])

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    with pytest.raises(RuntimeError, match="boom"):
        await session.shutdown()

    await session.shutdown()
    await session.shutdown()

    assert secured.stop.await_count == 2


async def test_sprites_sandbox_client_create_uses_lazy_factory_and_default_config(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import unsupported
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        SpritesSandboxClient,
        UnsupportedProviderClientOptions,
        _SecuredAdapterSession,
    )

    snapshot = NoopSnapshot(id=str(uuid4()))
    resolved_snapshot = NoopSnapshot(id=str(uuid4()))
    sprite = object()
    sprite_factory = MagicMock(return_value=sprite)
    adapter = object()
    secured = AsyncMock()
    secure_sandbox = AsyncMock(return_value=secured)
    resolve_snapshot = MagicMock(return_value=resolved_snapshot)
    sprites_adapter = MagicMock(return_value=adapter)
    monkeypatch.setattr(unsupported, "resolve_snapshot", resolve_snapshot)
    monkeypatch.setattr(unsupported, "secure_sandbox", secure_sandbox)
    monkeypatch.setattr(unsupported, "sprites", sprites_adapter)

    client = SpritesSandboxClient(sprite_factory=sprite_factory)
    assert sprite_factory.call_count == 0
    assert client.backend_id == "agentsh-secure:sprites"
    assert client.supports_default_options is True

    session = await client.create(
        snapshot=snapshot,
        manifest=Manifest(root="/custom-sprite"),
        options=UnsupportedProviderClientOptions(handle="handle-1"),
    )

    assert sprite_factory.call_count == 1
    resolve_snapshot.assert_called_once()
    resolve_snapshot_snapshot, snapshot_id = resolve_snapshot.call_args.args
    assert resolve_snapshot_snapshot is snapshot
    assert isinstance(snapshot_id, str)
    assert snapshot_id
    sprites_adapter.assert_called_once_with(sprite)
    secure_sandbox.assert_awaited_once()
    secured_adapter, config = secure_sandbox.await_args.args
    assert secured_adapter is adapter
    assert config.workspace == "/custom-sprite"
    assert isinstance(session._inner, _SecuredAdapterSession)
    assert session._inner.state.provider == "sprites"
    assert session._inner.state.handle == "handle-1"
    assert session._inner.state.snapshot is resolved_snapshot
    assert session._inner.state.manifest.root == "/custom-sprite"


async def test_sprites_sandbox_client_factory_is_called_per_session(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import unsupported
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        SpritesSandboxClient,
        UnsupportedProviderClientOptions,
        UnsupportedProviderSessionState,
        _SecuredAdapterSession,
    )

    sprite = object()
    next_sprite = object()
    sprite_factory = MagicMock(side_effect=[sprite, next_sprite])
    adapter = object()
    secured = AsyncMock()
    secure_sandbox = AsyncMock(return_value=secured)
    sprites_adapter = MagicMock(return_value=adapter)
    monkeypatch.setattr(unsupported, "secure_sandbox", secure_sandbox)
    monkeypatch.setattr(unsupported, "sprites", sprites_adapter)

    client = SpritesSandboxClient(sprite_factory=sprite_factory)
    create_session = await client.create(
        snapshot=NoopSnapshot(id=str(uuid4())),
        manifest=Manifest(root="/workspace"),
        options=UnsupportedProviderClientOptions(handle="create-handle"),
    )
    resume_state = UnsupportedProviderSessionState(
        provider="sprites",
        handle="resume-handle",
        manifest=Manifest(root="/workspace"),
        snapshot=NoopSnapshot(id=str(uuid4())),
    )
    resume_session = await client.resume(resume_state)

    assert sprite_factory.call_count == 2
    assert sprites_adapter.call_args_list[0].args == (sprite,)
    assert sprites_adapter.call_args_list[1].args == (next_sprite,)
    assert secure_sandbox.await_count == 2
    assert isinstance(create_session._inner, _SecuredAdapterSession)
    assert isinstance(resume_session._inner, _SecuredAdapterSession)
    assert create_session._inner.state.handle == "create-handle"
    assert resume_session._inner.state.provider == "sprites"
    assert resume_session._inner.state.handle == "resume-handle"
    assert resume_session._inner.state.manifest.root == "/workspace"


async def test_sprites_sandbox_client_concrete_sprite_is_reused(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import unsupported
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        SpritesSandboxClient,
        UnsupportedProviderClientOptions,
        UnsupportedProviderSessionState,
    )

    sprite = object()
    adapter = object()
    secured = AsyncMock()
    secure_sandbox = AsyncMock(return_value=secured)
    sprites_adapter = MagicMock(return_value=adapter)
    monkeypatch.setattr(unsupported, "secure_sandbox", secure_sandbox)
    monkeypatch.setattr(unsupported, "sprites", sprites_adapter)

    client = SpritesSandboxClient(sprite=sprite)
    await client.create(
        snapshot=NoopSnapshot(id=str(uuid4())),
        manifest=Manifest(root="/workspace"),
        options=UnsupportedProviderClientOptions(handle=None),
    )
    await client.resume(
        UnsupportedProviderSessionState(
            provider="sprites",
            handle=None,
            manifest=Manifest(root="/workspace"),
            snapshot=NoopSnapshot(id=str(uuid4())),
        )
    )

    assert sprites_adapter.call_args_list[0].args == (sprite,)
    assert sprites_adapter.call_args_list[1].args == (sprite,)


async def test_sprites_sandbox_client_explicit_sprite_takes_precedence(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import unsupported
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        SpritesSandboxClient,
        UnsupportedProviderClientOptions,
    )

    explicit_sprite = object()
    factory_sprite = object()
    sprite_factory = MagicMock(return_value=factory_sprite)
    adapter = object()
    secured = AsyncMock()
    secure_sandbox = AsyncMock(return_value=secured)
    sprites_adapter = MagicMock(return_value=adapter)
    monkeypatch.setattr(unsupported, "secure_sandbox", secure_sandbox)
    monkeypatch.setattr(unsupported, "sprites", sprites_adapter)

    client = SpritesSandboxClient(sprite=explicit_sprite, sprite_factory=sprite_factory)
    await client.create(
        snapshot=NoopSnapshot(id=str(uuid4())),
        manifest=Manifest(root="/workspace"),
        options=UnsupportedProviderClientOptions(handle="handle-1"),
    )

    assert sprite_factory.call_count == 0
    assert sprites_adapter.call_args_list[0].args == (explicit_sprite,)


def test_sprites_sandbox_client_requires_sprite_or_factory() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import SpritesSandboxClient

    with pytest.raises(ValueError, match="sprite or sprite_factory"):
        SpritesSandboxClient()


async def test_sprites_sandbox_client_delete_shuts_down_session() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import SpritesSandboxClient

    client = SpritesSandboxClient(sprite=object())
    session = MagicMock()
    session.shutdown = AsyncMock(return_value=None)

    result = await client.delete(session)

    session.shutdown.assert_awaited_once()
    assert result is session


def test_sprites_sandbox_client_deserialize_session_state() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        SpritesSandboxClient,
        UnsupportedProviderSessionState,
    )

    state = UnsupportedProviderSessionState(
        provider="sprites",
        handle="handle-1",
        manifest=Manifest(root="/workspace"),
        snapshot=NoopSnapshot(id=str(uuid4())),
    )
    client = SpritesSandboxClient(sprite=object())

    assert client.deserialize_session_state(state.model_dump()) == state


def test_sprites_sandbox_client_class_attributes() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import SpritesSandboxClient

    assert SpritesSandboxClient.backend_id == "agentsh-secure:sprites"
    assert SpritesSandboxClient.supports_default_options is True


def test_sprites_sandbox_client_serialize_session_state_uses_json_mode() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        SpritesSandboxClient,
        UnsupportedProviderSessionState,
    )

    state = UnsupportedProviderSessionState(
        provider="sprites",
        handle="handle-1",
        manifest=Manifest(root="/workspace"),
        snapshot=NoopSnapshot(id=str(uuid4())),
    )
    client = SpritesSandboxClient(sprite=object())

    serialized = client.serialize_session_state(state)

    assert serialized == state.model_dump(mode="json")
    assert serialized["manifest"]["root"] == "/workspace"
    assert serialized["snapshot"]["type"] == "noop"


async def test_exe_sandbox_client_create_resume_delete_and_state(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import unsupported
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        ExeSandboxClient,
        UnsupportedProviderClientOptions,
        UnsupportedProviderSessionState,
        _SecuredAdapterSession,
    )

    vm_name = "vm-123"
    snapshot = NoopSnapshot(id=str(uuid4()))
    resolved_snapshot = NoopSnapshot(id=str(uuid4()))
    adapter = object()
    secured = AsyncMock()
    secure_sandbox = AsyncMock(return_value=secured)
    resolve_snapshot = MagicMock(return_value=resolved_snapshot)
    exe_adapter = MagicMock(return_value=adapter)
    monkeypatch.setattr(unsupported, "resolve_snapshot", resolve_snapshot)
    monkeypatch.setattr(unsupported, "secure_sandbox", secure_sandbox)
    monkeypatch.setattr(unsupported, "exe", exe_adapter)

    client = ExeSandboxClient(vm_name=vm_name)
    assert client.backend_id == "agentsh-secure:exe"
    assert client.supports_default_options is True

    session = await client.create(
        snapshot=snapshot,
        manifest=Manifest(root="/custom-exe"),
        options=UnsupportedProviderClientOptions(handle="ignored"),
    )

    resolve_snapshot.assert_called_once()
    assert resolve_snapshot.call_args.args[0] is snapshot
    assert isinstance(resolve_snapshot.call_args.args[1], str)
    exe_adapter.assert_called_once_with(vm_name)
    secure_sandbox.assert_awaited_once()
    assert secure_sandbox.await_args.args[0] is adapter
    config = secure_sandbox.await_args.args[1]
    assert config.workspace == "/custom-exe"
    assert isinstance(session._inner, _SecuredAdapterSession)
    assert session._inner.state.provider == "exe"
    assert session._inner.state.handle == vm_name
    assert session._inner.state.snapshot is resolved_snapshot
    assert session._inner.state.manifest.root == "/custom-exe"

    resumed_state = UnsupportedProviderSessionState(
        provider="exe",
        handle="resume-vm",
        manifest=Manifest(root="/workspace"),
        snapshot=NoopSnapshot(id=str(uuid4())),
    )
    resume_session = await client.resume(resumed_state)
    assert exe_adapter.call_args_list[1].args == ("resume-vm",)
    assert isinstance(resume_session._inner, _SecuredAdapterSession)
    assert resume_session._inner.state.handle == "resume-vm"

    fallback_client = ExeSandboxClient(vm_name="fallback-vm")
    fallback_state = UnsupportedProviderSessionState(
        provider="exe",
        handle=None,
        manifest=Manifest(root="/workspace"),
        snapshot=NoopSnapshot(id=str(uuid4())),
    )
    await fallback_client.resume(fallback_state)
    assert exe_adapter.call_args_list[2].args == ("fallback-vm",)

    fallback_resume_session = await fallback_client.resume(fallback_state)
    assert fallback_resume_session._inner.state.handle == "fallback-vm"

    shutdown_session = MagicMock()
    shutdown_session.shutdown = AsyncMock(return_value=None)
    result = await client.delete(shutdown_session)
    shutdown_session.shutdown.assert_awaited_once()
    assert result is shutdown_session


def test_exe_sandbox_client_rejects_empty_vm_name() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import ExeSandboxClient

    with pytest.raises(ValueError, match="vm_name"):
        ExeSandboxClient(vm_name="")


def test_exe_sandbox_client_class_attributes() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import ExeSandboxClient

    assert ExeSandboxClient.backend_id == "agentsh-secure:exe"
    assert ExeSandboxClient.supports_default_options is True


def test_exe_sandbox_client_serialize_session_state_uses_json_mode() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        ExeSandboxClient,
        UnsupportedProviderSessionState,
    )

    state = UnsupportedProviderSessionState(
        provider="exe",
        handle="vm-1",
        manifest=Manifest(root="/workspace"),
        snapshot=NoopSnapshot(id=str(uuid4())),
    )
    client = ExeSandboxClient(vm_name="vm-1")

    serialized = client.serialize_session_state(state)

    assert serialized == state.model_dump(mode="json")
    assert serialized["manifest"]["root"] == "/workspace"
    assert serialized["snapshot"]["type"] == "noop"


async def test_freestyle_sandbox_client_create_lazy_client_and_state(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import unsupported
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        FreestyleSandboxClient,
        UnsupportedProviderClientOptions,
        _SecuredAdapterSession,
    )

    snapshot = NoopSnapshot(id=str(uuid4()))
    resolved_snapshot = NoopSnapshot(id=str(uuid4()))
    vm = MagicMock()
    vm.id = "vm-id-1"
    fake_client = MagicMock()
    fake_client.create_sandbox_vm = AsyncMock(return_value=vm)
    client_ctor = MagicMock(return_value=fake_client)
    adapter = object()
    secured = AsyncMock()
    secure_sandbox = AsyncMock(return_value=secured)
    resolve_snapshot = MagicMock(return_value=resolved_snapshot)
    freestyle_adapter = MagicMock(return_value=adapter)
    monkeypatch.setattr(unsupported, "FreestyleClient", client_ctor)
    monkeypatch.setattr(unsupported, "secure_sandbox", secure_sandbox)
    monkeypatch.setattr(unsupported, "resolve_snapshot", resolve_snapshot)
    monkeypatch.setattr(unsupported, "freestyle", freestyle_adapter)

    client = FreestyleSandboxClient()
    assert client.backend_id == "agentsh-secure:freestyle"
    assert client.supports_default_options is True
    assert client_ctor.call_count == 0

    session = await client.create(
        snapshot=snapshot,
        manifest=Manifest(root="/custom-freestyle"),
        options=UnsupportedProviderClientOptions(handle="ignored"),
    )

    client_ctor.assert_called_once_with()
    fake_client.create_sandbox_vm.assert_awaited_once()
    resolve_snapshot.assert_called_once()
    assert resolve_snapshot.call_args.args[0] is snapshot
    assert isinstance(resolve_snapshot.call_args.args[1], str)
    freestyle_adapter.assert_called_once_with(vm)
    secure_sandbox.assert_awaited_once()
    assert secure_sandbox.await_args.args[0] is adapter
    config = secure_sandbox.await_args.args[1]
    assert config.workspace == "/custom-freestyle"
    assert isinstance(session._inner, _SecuredAdapterSession)
    assert session._inner.state.provider == "freestyle"
    assert session._inner.state.handle == "vm-id-1"
    assert session._inner.state.snapshot is resolved_snapshot
    assert session._inner.state.manifest.root == "/custom-freestyle"


async def test_freestyle_sandbox_client_create_vm_id_fallbacks(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import unsupported
    from agentsh_secure_sandbox.openai_sandbox.unsupported import FreestyleSandboxClient

    snapshot = NoopSnapshot(id=str(uuid4()))
    vm_with_vm_id = MagicMock()
    vm_with_vm_id.id = None
    vm_with_vm_id.vm_id = "vm-id-2"
    vm_without_ids = MagicMock()
    vm_without_ids.id = None
    vm_without_ids.vm_id = None
    fake_client = MagicMock()
    fake_client.create_sandbox_vm = AsyncMock(side_effect=[vm_with_vm_id, vm_without_ids])
    client_ctor = MagicMock(return_value=fake_client)
    secure_sandbox = AsyncMock(return_value=AsyncMock())
    monkeypatch.setattr(unsupported, "FreestyleClient", client_ctor)
    monkeypatch.setattr(unsupported, "secure_sandbox", secure_sandbox)
    monkeypatch.setattr(unsupported, "freestyle", MagicMock(return_value=object()))

    client = FreestyleSandboxClient()
    first_session = await client.create(snapshot=snapshot, manifest=None, options=None)
    second_session = await client.create(snapshot=snapshot, manifest=None, options=None)

    assert first_session._inner.state.handle == "vm-id-2"
    assert second_session._inner.state.handle.startswith("freestyle-")
    assert second_session._inner.state.handle != first_session._inner.state.handle


async def test_freestyle_sandbox_client_resume_requires_vm_resolver() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        FreestyleSandboxClient,
        UnsupportedProviderSessionState,
    )

    client = FreestyleSandboxClient(client=MagicMock())
    state = UnsupportedProviderSessionState(
        provider="freestyle",
        handle="vm-1",
        manifest=Manifest(root="/workspace"),
        snapshot=NoopSnapshot(id=str(uuid4())),
    )

    with pytest.raises(ValueError, match="vm_resolver"):
        await client.resume(state)


async def test_freestyle_sandbox_client_resume_requires_handle() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        FreestyleSandboxClient,
        UnsupportedProviderSessionState,
    )

    resolver = AsyncMock()
    client = FreestyleSandboxClient(client=MagicMock(), vm_resolver=resolver)
    state = UnsupportedProviderSessionState(
        provider="freestyle",
        handle=None,
        manifest=Manifest(root="/workspace"),
        snapshot=NoopSnapshot(id=str(uuid4())),
    )

    with pytest.raises(ValueError, match="vm_resolver"):
        await client.resume(state)
    resolver.assert_not_awaited()


async def test_freestyle_sandbox_client_resume_uses_resolver_and_preserves_handle(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import unsupported
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        FreestyleSandboxClient,
        UnsupportedProviderSessionState,
        _SecuredAdapterSession,
    )

    state = UnsupportedProviderSessionState(
        provider="freestyle",
        handle="vm-42",
        manifest=Manifest(root="/custom-resume"),
        snapshot=NoopSnapshot(id=str(uuid4())),
    )
    vm = MagicMock()
    vm.id = "vm-42"
    resolver = AsyncMock(return_value=vm)
    adapter = object()
    secured = AsyncMock()
    secure_sandbox = AsyncMock(return_value=secured)
    freestyle_adapter = MagicMock(return_value=adapter)
    monkeypatch.setattr(unsupported, "secure_sandbox", secure_sandbox)
    monkeypatch.setattr(unsupported, "freestyle", freestyle_adapter)

    client = FreestyleSandboxClient(client=MagicMock(), vm_resolver=resolver)
    session = await client.resume(state)

    resolver.assert_awaited_once_with("vm-42")
    freestyle_adapter.assert_called_once_with(vm)
    secure_sandbox.assert_awaited_once()
    assert secure_sandbox.await_args.args[1].workspace == "/custom-resume"
    assert isinstance(session._inner, _SecuredAdapterSession)
    assert session._inner.state.provider == "freestyle"
    assert session._inner.state.handle == "vm-42"


async def test_freestyle_sandbox_client_resume_rejects_sync_resolver(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import unsupported
    from agentsh_secure_sandbox.openai_sandbox.unsupported import FreestyleSandboxClient

    vm = MagicMock()
    resolver = MagicMock(return_value=vm)
    monkeypatch.setattr(unsupported, "secure_sandbox", AsyncMock())
    monkeypatch.setattr(unsupported, "freestyle", MagicMock(return_value=object()))

    client = FreestyleSandboxClient(client=MagicMock(), vm_resolver=resolver)
    state = _make_state(provider="freestyle", handle="vm-42")

    with pytest.raises(TypeError, match="awaitable"):
        await client.resume(state)


async def test_freestyle_sandbox_client_delete_shuts_down_session() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import FreestyleSandboxClient

    client = FreestyleSandboxClient(client=MagicMock())
    session = MagicMock()
    session.shutdown = AsyncMock(return_value=None)

    result = await client.delete(session)

    session.shutdown.assert_awaited_once()
    assert result is session


async def test_freestyle_sandbox_client_delete_closes_owned_client(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import unsupported
    from agentsh_secure_sandbox.openai_sandbox.unsupported import FreestyleSandboxClient

    snapshot = NoopSnapshot(id=str(uuid4()))
    vm = MagicMock()
    vm.id = "vm-id-1"
    fake_client = MagicMock()
    fake_client.create_sandbox_vm = AsyncMock(return_value=vm)
    fake_client.aclose = AsyncMock(return_value=None)
    client_ctor = MagicMock(return_value=fake_client)
    secure_sandbox = AsyncMock(return_value=AsyncMock())
    monkeypatch.setattr(unsupported, "FreestyleClient", client_ctor)
    monkeypatch.setattr(unsupported, "secure_sandbox", secure_sandbox)
    monkeypatch.setattr(unsupported, "freestyle", MagicMock(return_value=object()))

    client = FreestyleSandboxClient()
    session = await client.create(snapshot=snapshot, manifest=None, options=None)
    session.shutdown = AsyncMock(side_effect=RuntimeError("shutdown failed"))

    with pytest.raises(RuntimeError, match="shutdown failed"):
        await client.delete(session)

    fake_client.aclose.assert_awaited_once()

    next_client = MagicMock()
    next_client.create_sandbox_vm = AsyncMock(return_value=vm)
    next_client.aclose = AsyncMock(return_value=None)
    client_ctor.return_value = next_client

    await client.create(snapshot=snapshot, manifest=None, options=None)
    assert client_ctor.call_count == 2


async def test_freestyle_sandbox_client_delete_does_not_close_external_client() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import FreestyleSandboxClient

    external_client = MagicMock()
    external_client.create_sandbox_vm = AsyncMock(return_value=MagicMock(id="vm-id-1"))
    external_client.aclose = AsyncMock(return_value=None)
    client = FreestyleSandboxClient(client=external_client)
    session = MagicMock()
    session.shutdown = AsyncMock(return_value=None)

    await client.delete(session)

    session.shutdown.assert_awaited_once()
    external_client.aclose.assert_not_awaited()


async def test_freestyle_sandbox_client_delete_closes_owned_client_on_cancelled_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import unsupported
    from agentsh_secure_sandbox.openai_sandbox.unsupported import FreestyleSandboxClient

    snapshot = NoopSnapshot(id=str(uuid4()))
    vm = MagicMock()
    vm.id = "vm-id-1"
    fake_client = MagicMock()
    fake_client.create_sandbox_vm = AsyncMock(return_value=vm)
    fake_client.aclose = AsyncMock(return_value=None)
    client_ctor = MagicMock(return_value=fake_client)
    secure_sandbox = AsyncMock(return_value=AsyncMock())
    monkeypatch.setattr(unsupported, "FreestyleClient", client_ctor)
    monkeypatch.setattr(unsupported, "secure_sandbox", secure_sandbox)
    monkeypatch.setattr(unsupported, "freestyle", MagicMock(return_value=object()))

    client = FreestyleSandboxClient()
    session = await client.create(snapshot=snapshot, manifest=None, options=None)
    session.shutdown = AsyncMock(side_effect=asyncio.CancelledError())

    with pytest.raises(asyncio.CancelledError):
        await client.delete(session)

    fake_client.aclose.assert_awaited_once()


def test_freestyle_sandbox_client_class_attributes() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import FreestyleSandboxClient

    assert FreestyleSandboxClient.backend_id == "agentsh-secure:freestyle"
    assert FreestyleSandboxClient.supports_default_options is True


def test_freestyle_sandbox_client_serialize_session_state_uses_json_mode() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        FreestyleSandboxClient,
        UnsupportedProviderSessionState,
    )

    state = UnsupportedProviderSessionState(
        provider="freestyle",
        handle="vm-1",
        manifest=Manifest(root="/workspace"),
        snapshot=NoopSnapshot(id=str(uuid4())),
    )
    client = FreestyleSandboxClient(client=MagicMock())

    serialized = client.serialize_session_state(state)

    assert serialized == state.model_dump(mode="json")
    assert serialized["manifest"]["root"] == "/workspace"
    assert serialized["snapshot"]["type"] == "noop"


def test_unsupported_provider_state_and_options_shape() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        UnsupportedProviderClientOptions,
        UnsupportedProviderSessionState,
    )

    state = UnsupportedProviderSessionState(
        provider="unit",
        handle="handle-1",
        manifest=Manifest(root="/workspace"),
        snapshot=NoopSnapshot(id=str(uuid4())),
    )
    options = UnsupportedProviderClientOptions(handle="handle-1")

    assert state.type == "agentsh_secure_provider"
    assert state.provider == "unit"
    assert state.handle == "handle-1"
    assert options.type == "agentsh_secure_provider"
    assert options.handle == "handle-1"
    assert UnsupportedProviderSessionState.model_validate(state.model_dump()) == state
    assert UnsupportedProviderClientOptions.model_validate(options.model_dump()) == options
