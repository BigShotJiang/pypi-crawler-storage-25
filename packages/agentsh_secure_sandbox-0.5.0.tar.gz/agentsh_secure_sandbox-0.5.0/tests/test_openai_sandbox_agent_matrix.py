from __future__ import annotations

from tests.e2e import test_openai_sandbox_agents as agent_e2e


def test_upstream_openai_agent_provider_matrix_matches_spec() -> None:
    cases = {case["name"] for case in agent_e2e._upstream_agent_provider_cases()}  # type: ignore[attr-defined]

    assert cases == {
        "blaxel",
        "cloudflare",
        "daytona",
        "e2b",
        "modal",
        "runloop",
        "vercel",
    }


def test_custom_openai_agent_provider_matrix_matches_spec() -> None:
    cases = {case["name"] for case in agent_e2e._custom_agent_provider_cases()}  # type: ignore[attr-defined]

    assert cases == {
        "exe",
        "freestyle",
        "sprites",
    }
