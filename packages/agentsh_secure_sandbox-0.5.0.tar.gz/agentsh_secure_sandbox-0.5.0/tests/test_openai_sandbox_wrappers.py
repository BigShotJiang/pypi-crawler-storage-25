from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

agents_sandbox_client_mod = pytest.importorskip("agents.sandbox.session.sandbox_client")
agents_sandbox_dependencies_mod = pytest.importorskip("agents.sandbox.session.dependencies")
agents_sandbox_session_mod = pytest.importorskip("agents.sandbox.session.sandbox_session")
agents_sandbox_instrumentation_mod = pytest.importorskip("agents.sandbox.session.manager")
agents_sandbox_state_mod = pytest.importorskip("agents.sandbox.session.sandbox_session_state")

BaseSandboxClient = agents_sandbox_client_mod.BaseSandboxClient
Dependencies = agents_sandbox_dependencies_mod.Dependencies
BaseSandboxSession = pytest.importorskip(
    "agents.sandbox.session.base_sandbox_session"
).BaseSandboxSession
Instrumentation = agents_sandbox_instrumentation_mod.Instrumentation
SandboxSession = agents_sandbox_session_mod.SandboxSession
SandboxSessionState = agents_sandbox_state_mod.SandboxSessionState

from agentsh_secure_sandbox.core.types import SecureConfig  # noqa: E402


class _TrackingUpstreamInnerSession:
    def __init__(self) -> None:
        self._dependencies: Dependencies | None = None

    def set_dependencies(self, dependencies: Dependencies | None) -> None:
        self._dependencies = dependencies

    @property
    def dependencies(self) -> Dependencies:
        assert self._dependencies is not None
        return self._dependencies


def _make_upstream_inner_session() -> MagicMock:
    inner = MagicMock(spec=BaseSandboxSession)
    inner.set_dependencies = MagicMock()
    inner.state = MagicMock()
    inner.running = AsyncMock(return_value=True)
    inner.persist_workspace = AsyncMock(return_value=MagicMock(read=lambda: b"workspace"))
    inner.hydrate_workspace = AsyncMock()
    inner.supports_pty = MagicMock(return_value=True)
    inner.pty_exec_start = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_write_stdin = AsyncMock(return_value=MagicMock(tag="pty"))
    inner.pty_terminate_all = AsyncMock()
    inner._resolve_exposed_port = AsyncMock()
    inner.stop = AsyncMock()
    inner.shutdown = AsyncMock()
    return inner


def _make_upstream_session(
    inner: MagicMock,
    *,
    instrumentation: object | None = None,
    dependencies: object | None = None,
) -> SandboxSession:
    session = SandboxSession(
        inner,
        instrumentation=instrumentation,
        dependencies=dependencies,
    )
    return session


async def test_secure_client_create_delegates_and_wraps_sdk_session(monkeypatch: pytest.MonkeyPatch) -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession
    from agentsh_secure_sandbox.openai_sandbox import wrappers as wrappers_module
    from agentsh_secure_sandbox.openai_sandbox.wrappers import SecureOpenAISandboxClient

    inner = _TrackingUpstreamInnerSession()
    instrumentation = Instrumentation()
    dependencies = Dependencies()
    upstream_session = _make_upstream_session(inner, instrumentation=instrumentation, dependencies=dependencies)
    upstream = MagicMock(spec=BaseSandboxClient)
    upstream.backend_id = "e2b"
    upstream.supports_default_options = True
    upstream.create = AsyncMock(return_value=upstream_session)
    upstream.resume = AsyncMock()
    upstream.delete = AsyncMock()
    upstream.serialize_session_state = MagicMock(return_value={"type": "e2b"})
    upstream.deserialize_session_state = MagicMock()

    secured = AsyncMock()
    secure_sandbox_mock = AsyncMock(return_value=secured)
    monkeypatch.setattr(
        wrappers_module,
        "secure_sandbox",
        secure_sandbox_mock,
    )

    client = SecureOpenAISandboxClient(upstream_client=upstream)
    session = await client.create(snapshot=None, manifest=None, options=None)

    assert client.backend_id == "agentsh-secure:e2b"
    assert client.supports_default_options is True
    assert client.upstream_client is upstream
    assert isinstance(session, SandboxSession)
    assert isinstance(session._inner, SecureOpenAISandboxSession)
    assert session._inner.inner_session is inner
    assert session._inner._upstream_session is upstream_session
    assert session._instrumentation is instrumentation
    assert session.dependencies is dependencies
    upstream.create.assert_awaited_once_with(snapshot=None, manifest=None, options=None)
    secure_sandbox_mock.assert_awaited_once()
    secure_args, secure_kwargs = secure_sandbox_mock.await_args
    assert isinstance(secure_args[0], wrappers_module._OpenAISessionAdapter)
    assert secure_args[0]._session is inner
    assert secure_args[1] == SecureConfig()
    assert secure_kwargs == {}


async def test_secure_client_cloudflare_defaults_to_preinstalled_install_strategy(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import wrappers as wrappers_module
    from agentsh_secure_sandbox.openai_sandbox.wrappers import SecureOpenAISandboxClient

    inner = _make_upstream_inner_session()
    upstream_session = _make_upstream_session(inner, instrumentation=Instrumentation(), dependencies=Dependencies())
    upstream = MagicMock(spec=BaseSandboxClient)
    upstream.backend_id = "cloudflare"
    upstream.supports_default_options = True
    upstream.create = AsyncMock(return_value=upstream_session)
    upstream.resume = AsyncMock()
    upstream.delete = AsyncMock()
    upstream.serialize_session_state = MagicMock(return_value={"type": "cloudflare"})
    upstream.deserialize_session_state = MagicMock()

    secure_sandbox_mock = AsyncMock(return_value=AsyncMock())
    monkeypatch.setattr(wrappers_module, "secure_sandbox", secure_sandbox_mock)

    client = SecureOpenAISandboxClient(upstream_client=upstream)
    await client.create(snapshot=None, manifest=None, options=None)

    secure_args, _ = secure_sandbox_mock.await_args
    assert secure_args[1].install_strategy == "preinstalled"


async def test_secure_client_explicit_config_overrides_cloudflare_defaults(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import wrappers as wrappers_module
    from agentsh_secure_sandbox.openai_sandbox.wrappers import SecureOpenAISandboxClient

    inner = _make_upstream_inner_session()
    upstream_session = _make_upstream_session(inner, instrumentation=Instrumentation(), dependencies=Dependencies())
    upstream = MagicMock(spec=BaseSandboxClient)
    upstream.backend_id = "cloudflare"
    upstream.supports_default_options = True
    upstream.create = AsyncMock(return_value=upstream_session)
    upstream.resume = AsyncMock()
    upstream.delete = AsyncMock()
    upstream.serialize_session_state = MagicMock(return_value={"type": "cloudflare"})
    upstream.deserialize_session_state = MagicMock()

    secure_sandbox_mock = AsyncMock(return_value=AsyncMock())
    monkeypatch.setattr(wrappers_module, "secure_sandbox", secure_sandbox_mock)

    config = SecureConfig(install_strategy="download")
    client = SecureOpenAISandboxClient(upstream_client=upstream, config=config)
    await client.create(snapshot=None, manifest=None, options=None)

    secure_args, _ = secure_sandbox_mock.await_args
    assert secure_args[1].install_strategy == "download"


async def test_secure_client_resume_delegates_and_wraps_sdk_session(monkeypatch: pytest.MonkeyPatch) -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession
    from agentsh_secure_sandbox.openai_sandbox import wrappers as wrappers_module
    from agentsh_secure_sandbox.openai_sandbox.wrappers import SecureOpenAISandboxClient

    state = MagicMock(spec=SandboxSessionState)
    inner = _TrackingUpstreamInnerSession()
    instrumentation = Instrumentation()
    dependencies = Dependencies()
    upstream_session = _make_upstream_session(inner, instrumentation=instrumentation, dependencies=dependencies)
    upstream = MagicMock(spec=BaseSandboxClient)
    upstream.backend_id = "modal"
    upstream.supports_default_options = False
    upstream.create = AsyncMock()
    upstream.resume = AsyncMock(return_value=upstream_session)
    upstream.delete = AsyncMock()
    upstream.serialize_session_state = MagicMock(return_value={"type": "modal"})
    upstream.deserialize_session_state = MagicMock()

    secured = AsyncMock()
    secure_sandbox_mock = AsyncMock(return_value=secured)
    monkeypatch.setattr(
        wrappers_module,
        "secure_sandbox",
        secure_sandbox_mock,
    )

    client = SecureOpenAISandboxClient(upstream_client=upstream)
    session = await client.resume(state)

    assert isinstance(session._inner, SecureOpenAISandboxSession)
    assert session._inner.inner_session is inner
    assert session._inner._upstream_session is upstream_session
    assert session._instrumentation is instrumentation
    assert session.dependencies is dependencies
    upstream.resume.assert_awaited_once_with(state)
    secure_sandbox_mock.assert_awaited_once()
    secure_args, secure_kwargs = secure_sandbox_mock.await_args
    assert isinstance(secure_args[0], wrappers_module._OpenAISessionAdapter)
    assert secure_args[0]._session is inner
    assert secure_args[1] == SecureConfig()
    assert secure_kwargs == {}


async def test_secure_client_create_runs_prepare_hook_before_secure_sandbox(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import wrappers as wrappers_module
    from agentsh_secure_sandbox.openai_sandbox.wrappers import SecureOpenAISandboxClient

    inner = _TrackingUpstreamInnerSession()
    upstream_session = _make_upstream_session(inner, dependencies=Dependencies())
    upstream = MagicMock(spec=BaseSandboxClient)
    upstream.backend_id = "vercel"
    upstream.supports_default_options = True
    upstream.create = AsyncMock(return_value=upstream_session)
    upstream.resume = AsyncMock()
    upstream.delete = AsyncMock()
    upstream.serialize_session_state = MagicMock(return_value={"type": "vercel"})
    upstream.deserialize_session_state = MagicMock()

    events: list[tuple[str, object]] = []

    async def prepare_upstream_session(session: object) -> None:
        events.append(("prepare", session))

    async def fake_secure_sandbox(*args, **kwargs):
        events.append(("secure", args[0]._session))
        return AsyncMock()

    monkeypatch.setattr(
        wrappers_module,
        "secure_sandbox",
        AsyncMock(side_effect=fake_secure_sandbox),
    )

    client = SecureOpenAISandboxClient(
        upstream_client=upstream,
        prepare_upstream_session=prepare_upstream_session,
    )
    await client.create(snapshot=None, manifest=None, options=None)

    assert events == [
        ("prepare", upstream_session),
        ("secure", inner),
    ]


async def test_secure_client_resume_runs_prepare_hook_before_secure_sandbox(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import wrappers as wrappers_module
    from agentsh_secure_sandbox.openai_sandbox.wrappers import SecureOpenAISandboxClient

    state = MagicMock(spec=SandboxSessionState)
    inner = _TrackingUpstreamInnerSession()
    upstream_session = _make_upstream_session(inner, dependencies=Dependencies())
    upstream = MagicMock(spec=BaseSandboxClient)
    upstream.backend_id = "runloop"
    upstream.supports_default_options = True
    upstream.create = AsyncMock()
    upstream.resume = AsyncMock(return_value=upstream_session)
    upstream.delete = AsyncMock()
    upstream.serialize_session_state = MagicMock(return_value={"type": "runloop"})
    upstream.deserialize_session_state = MagicMock()

    events: list[tuple[str, object]] = []

    async def prepare_upstream_session(session: object) -> None:
        events.append(("prepare", session))

    async def fake_secure_sandbox(*args, **kwargs):
        events.append(("secure", args[0]._session))
        return AsyncMock()

    monkeypatch.setattr(
        wrappers_module,
        "secure_sandbox",
        AsyncMock(side_effect=fake_secure_sandbox),
    )

    client = SecureOpenAISandboxClient(
        upstream_client=upstream,
        prepare_upstream_session=prepare_upstream_session,
    )
    await client.resume(state)

    assert events == [
        ("prepare", upstream_session),
        ("secure", inner),
    ]


async def test_secure_client_delete_uses_retained_upstream_sdk_session(monkeypatch: pytest.MonkeyPatch) -> None:
    from agentsh_secure_sandbox.openai_sandbox import wrappers as wrappers_module
    from agentsh_secure_sandbox.openai_sandbox.wrappers import SecureOpenAISandboxClient

    inner = _make_upstream_inner_session()
    upstream_session = _make_upstream_session(inner)
    upstream = MagicMock(spec=BaseSandboxClient)
    upstream.backend_id = "runloop"
    upstream.supports_default_options = True
    upstream.create = AsyncMock(return_value=upstream_session)
    upstream.resume = AsyncMock()
    upstream.delete = AsyncMock(return_value=upstream_session)
    upstream.serialize_session_state = MagicMock(return_value={"type": "runloop"})
    upstream.deserialize_session_state = MagicMock()

    secured = AsyncMock()
    secured.stop = AsyncMock()
    monkeypatch.setattr(
        wrappers_module,
        "secure_sandbox",
        AsyncMock(return_value=secured),
    )

    client = SecureOpenAISandboxClient(upstream_client=upstream)
    wrapped_session = await client.create(snapshot=None, manifest=None, options=None)
    returned = await client.delete(wrapped_session)

    assert returned is wrapped_session
    secured.stop.assert_awaited_once()
    inner.shutdown.assert_awaited_once()
    upstream.delete.assert_awaited_once_with(upstream_session)


async def test_secure_client_delete_uses_raw_inner_test_double(monkeypatch: pytest.MonkeyPatch) -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession
    from agentsh_secure_sandbox.openai_sandbox import wrappers as wrappers_module
    from agentsh_secure_sandbox.openai_sandbox.wrappers import SecureOpenAISandboxClient

    inner = _make_upstream_inner_session()
    upstream = MagicMock(spec=BaseSandboxClient)
    upstream.backend_id = "raw"
    upstream.supports_default_options = False
    upstream.create = AsyncMock(return_value=inner)
    upstream.resume = AsyncMock()
    upstream.delete = AsyncMock(return_value=inner)
    upstream.serialize_session_state = MagicMock(return_value={"type": "raw"})
    upstream.deserialize_session_state = MagicMock()

    secured = AsyncMock()
    secured.stop = AsyncMock()
    monkeypatch.setattr(
        wrappers_module,
        "secure_sandbox",
        AsyncMock(return_value=secured),
    )

    client = SecureOpenAISandboxClient(upstream_client=upstream)
    wrapped_session = await client.create(snapshot=None, manifest=None, options=None)
    assert isinstance(wrapped_session._inner, SecureOpenAISandboxSession)
    assert wrapped_session._inner._upstream_session is inner

    returned = await client.delete(wrapped_session)

    assert returned is wrapped_session
    secured.stop.assert_awaited_once()
    inner.shutdown.assert_awaited_once()
    upstream.delete.assert_awaited_once_with(inner)


def test_secure_client_serialization_delegates() -> None:
    from agentsh_secure_sandbox.openai_sandbox.wrappers import SecureOpenAISandboxClient

    state = MagicMock(spec=SandboxSessionState)
    upstream = MagicMock(spec=BaseSandboxClient)
    upstream.backend_id = "vercel"
    upstream.supports_default_options = True
    upstream.create = AsyncMock()
    upstream.resume = AsyncMock()
    upstream.delete = AsyncMock()
    upstream.serialize_session_state = MagicMock(return_value={"type": "vercel", "sandbox_id": "abc"})
    upstream.deserialize_session_state = MagicMock(return_value=state)

    client = SecureOpenAISandboxClient(upstream_client=upstream, config=SecureConfig())

    assert client.serialize_session_state(state) == {"type": "vercel", "sandbox_id": "abc"}
    assert client.deserialize_session_state({"type": "vercel", "sandbox_id": "abc"}) is state


def test_factory_wraps_upstream_provider_client() -> None:
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient
    from agentsh_secure_sandbox.openai_sandbox.providers import secure_openai_sandbox_client

    upstream = MagicMock()
    upstream.backend_id = "e2b"
    upstream.supports_default_options = True

    client = secure_openai_sandbox_client(provider="e2b", upstream_client=upstream)

    assert isinstance(client, SecureOpenAISandboxClient)
    assert client.upstream_client is upstream


async def test_factory_passes_prepare_hook_to_upstream_provider_wrapper(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentsh_secure_sandbox.openai_sandbox import wrappers as wrappers_module
    from agentsh_secure_sandbox.openai_sandbox.providers import secure_openai_sandbox_client

    inner = _TrackingUpstreamInnerSession()
    upstream_session = _make_upstream_session(inner, dependencies=Dependencies())
    upstream = MagicMock(spec=BaseSandboxClient)
    upstream.backend_id = "e2b"
    upstream.supports_default_options = True
    upstream.create = AsyncMock(return_value=upstream_session)
    upstream.resume = AsyncMock()
    upstream.delete = AsyncMock()
    upstream.serialize_session_state = MagicMock(return_value={"type": "e2b"})
    upstream.deserialize_session_state = MagicMock()

    events: list[tuple[str, object]] = []

    async def prepare_upstream_session(session: object) -> None:
        events.append(("prepare", session))

    async def fake_secure_sandbox(*args, **kwargs):
        events.append(("secure", args[0]._session))
        return AsyncMock()

    monkeypatch.setattr(
        wrappers_module,
        "secure_sandbox",
        AsyncMock(side_effect=fake_secure_sandbox),
    )

    client = secure_openai_sandbox_client(
        provider="e2b",
        upstream_client=upstream,
        prepare_upstream_session=prepare_upstream_session,
    )
    await client.create(snapshot=None, manifest=None, options=None)

    assert events == [
        ("prepare", upstream_session),
        ("secure", inner),
    ]


def test_factory_rejects_upstream_provider_without_client() -> None:
    from agentsh_secure_sandbox.openai_sandbox.providers import secure_openai_sandbox_client

    with pytest.raises(ValueError, match="upstream_client"):
        secure_openai_sandbox_client(provider="e2b")


def test_factory_constructs_custom_exe_client() -> None:
    from agentsh_secure_sandbox.openai_sandbox import ExeSandboxClient
    from agentsh_secure_sandbox.openai_sandbox.providers import secure_openai_sandbox_client

    client = secure_openai_sandbox_client(provider="exe", vm_name="vm-1")

    assert isinstance(client, ExeSandboxClient)


def test_factory_rejects_unknown_provider() -> None:
    from agentsh_secure_sandbox.openai_sandbox.providers import secure_openai_sandbox_client

    with pytest.raises(ValueError, match="unknown provider"):
        secure_openai_sandbox_client(provider="unknown")


def test_factory_rejects_unexpected_kwargs_for_upstream_provider() -> None:
    from agentsh_secure_sandbox.openai_sandbox.providers import secure_openai_sandbox_client

    upstream = MagicMock()
    upstream.backend_id = "e2b"
    upstream.supports_default_options = True

    with pytest.raises(ValueError, match="unexpected kwargs"):
        secure_openai_sandbox_client(
            provider="e2b",
            upstream_client=upstream,
            vm_name="vm-1",
        )


def test_providers_module_import_does_not_eagerly_load_openai_submodules() -> None:
    import importlib
    import sys

    sys.modules.pop("agentsh_secure_sandbox.openai_sandbox.providers", None)
    sys.modules.pop("agentsh_secure_sandbox.openai_sandbox.wrappers", None)
    sys.modules.pop("agentsh_secure_sandbox.openai_sandbox.unsupported", None)

    module = importlib.import_module("agentsh_secure_sandbox.openai_sandbox.providers")

    assert "agentsh_secure_sandbox.openai_sandbox.wrappers" not in sys.modules
    assert "agentsh_secure_sandbox.openai_sandbox.unsupported" not in sys.modules
    assert callable(module.secure_openai_sandbox_client)


def test_providers_module_imports_when_agents_are_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    import builtins
    import importlib
    import sys

    module_name = "agentsh_secure_sandbox.openai_sandbox.providers"
    saved_modules = {
        key: sys.modules.pop(key)
        for key in list(sys.modules)
        if key == module_name or key.startswith(f"{module_name}.")
    }
    original_import = builtins.__import__

    def fake_import(
        name: str,
        globals: object | None = None,
        locals: object | None = None,
        fromlist: tuple[str, ...] | tuple[object, ...] = (),
        level: int = 0,
    ) -> object:
        root = name.split(".")[0]
        if root in {"agents", "openai_agents"}:
            raise ModuleNotFoundError(f"No module named '{root}'", name=root)
        return original_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", fake_import)

    try:
        module = importlib.import_module(module_name)
        assert callable(module.secure_openai_sandbox_client)
        with pytest.raises(ImportError, match="openai-agents extra"):
            module.secure_openai_sandbox_client(provider="e2b", upstream_client=MagicMock())
    finally:
        sys.modules.pop(module_name, None)
        sys.modules.update(saved_modules)
