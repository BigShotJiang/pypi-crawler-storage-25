# tests/test_integrity.py
from agentsh_secure_sandbox.core.integrity import (
    PINNED_VERSION,
    CHECKSUMS,
    binary_url,
    get_checksum,
    build_verify_command,
)


def test_pinned_version_exists():
    assert PINNED_VERSION == "0.18.2"


def test_checksums_for_pinned_version():
    assert PINNED_VERSION in CHECKSUMS
    assert "linux_amd64" in CHECKSUMS[PINNED_VERSION]
    assert "linux_arm64" in CHECKSUMS[PINNED_VERSION]


def test_binary_url_default():
    url = binary_url("0.18.2", "linux_amd64")
    assert "agentsh_0.18.2_linux_amd64.tar.gz" in url
    assert url.startswith("https://github.com/canyonroad/agentsh/releases/")


def test_binary_url_override():
    url = binary_url("0.14.0", "linux_amd64", override="https://custom.example.com/bin.tar.gz")
    assert url == "https://custom.example.com/bin.tar.gz"


def test_get_checksum():
    cs = get_checksum("0.18.2", "linux_amd64")
    assert isinstance(cs, str)
    assert len(cs) > 10


def test_get_checksum_unknown():
    import pytest

    with pytest.raises(KeyError):
        get_checksum("99.99.99", "linux_amd64")


def test_build_verify_command():
    cmd = build_verify_command("/usr/local/bin/agentsh", "abcdef123456")
    assert "abcdef123456" in cmd
    assert "/usr/local/bin/agentsh" in cmd
    assert "sha256sum -c --status" not in cmd
    assert "awk" in cmd


def test_pinned_version_is_0_18_2():
    assert PINNED_VERSION == "0.18.2"


def test_checksums_include_0_18_2():
    assert "0.18.2" in CHECKSUMS
    assert "linux_amd64" in CHECKSUMS["0.18.2"]
    assert "linux_arm64" in CHECKSUMS["0.18.2"]
    assert CHECKSUMS["0.18.2"]["linux_amd64"] == "5b277f4565b8beecee1011c7683f58b51ac25ae8cc7c7d2e1f3f7433bdd3b825"
