"""Unit tests for the Freestyle adapter — command wrapping and fake-VM behavior."""

from __future__ import annotations

from typing import Any

import pytest

from agentsh_secure_sandbox.adapters.freestyle._adapter import _build_command
from agentsh_secure_sandbox.core.types import ExecOpts, SandboxAdapter


class TestBuildCommand:
    def test_plain_command_wrapped_in_bash_minus_c(self) -> None:
        # Caller splits cmd from args so each gets quoted independently.
        # _build_command("echo", ["hello"], None) -> "bash -c 'echo hello'"
        result = _build_command("echo", ["hello"], None)
        assert result == "bash -c 'echo hello'"

    def test_args_are_shell_quoted(self) -> None:
        result = _build_command("echo", ["one", "two three"], None)
        assert "echo" in result
        # Single-quoted "two three" should survive the bash -c outer quoting
        assert "'two three'" in result or '"two three"' in result

    def test_arg_with_single_quote(self) -> None:
        # shlex.quote escapes single quotes by closing the quote, emitting
        # an escaped quote, and reopening — so the exact bytes are hard
        # to predict. Assert the shape instead.
        result = _build_command("echo", ["it's"], None)
        assert result.startswith("bash -c ")

    def test_env_prefixes_key_value_pairs(self) -> None:
        result = _build_command("printenv", ["FOO"], ExecOpts(env={"FOO": "bar"}))
        assert "FOO=bar" in result

    def test_env_values_are_quoted(self) -> None:
        # Value with a space must be quoted so the remote shell does not split
        # on it. Because the whole payload is outer-wrapped with shlex.quote,
        # the inner single quotes get re-escaped as `'"'"'`, so the literal
        # substring `X='a b'` will not appear — same caveat the TS freestyle
        # tests document. Assert the component pieces (key prefix + value
        # characters) survive into the final string.
        result = _build_command("printenv", ["X"], ExecOpts(env={"X": "a b"}))
        assert "X=" in result
        assert "a b" in result

    def test_cwd_prefixes_cd(self) -> None:
        result = _build_command("pwd", None, ExecOpts(cwd="/home/user"))
        assert "cd /home/user &&" in result

    def test_cwd_with_spaces_is_quoted(self) -> None:
        # Cwd with a space must be quoted before it gets concatenated into
        # the inner. After the outer shlex.quote wrap, the literal substring
        # `cd '/tmp/a b'` does not appear (embedded single quotes are
        # re-escaped), but the `cd ` keyword and the raw path characters do
        # survive. Same substring-check pattern as the TS freestyle tests.
        result = _build_command("pwd", None, ExecOpts(cwd="/tmp/a b"))
        assert "cd " in result
        assert "/tmp/a b" in result

    def test_sudo_uses_dash_e_to_preserve_env(self) -> None:
        result = _build_command("whoami", None, ExecOpts(sudo=True))
        assert "sudo -E" in result

    def test_detached_appends_background(self) -> None:
        result = _build_command("sleep", ["60"], ExecOpts(detached=True))
        # nohup + redirect all stdio + background
        assert "nohup" in result
        assert "> /dev/null 2>&1" in result
        assert result.rstrip("'").rstrip().endswith("&") or " &'" in result

    def test_env_and_cwd_together(self) -> None:
        result = _build_command(
            "printenv",
            ["FOO"],
            ExecOpts(env={"FOO": "bar"}, cwd="/tmp"),
        )
        # cd wraps env wraps command
        assert "cd /tmp &&" in result
        assert "FOO=bar" in result

    def test_env_after_sudo_before_command(self) -> None:
        result = _build_command(
            "whoami",
            None,
            ExecOpts(sudo=True, env={"X": "1"}),
        )
        # Order inside bash -c must be: X=1 sudo -E whoami
        assert "X=1 sudo -E whoami" in result


class FakeFreestyleVm:
    """Minimal fake — records calls, returns canned responses."""

    def __init__(self) -> None:
        self.exec_calls: list[dict[str, Any]] = []
        self.write_calls: list[dict[str, Any]] = []
        self.read_calls: list[str] = []
        self.file_exists_calls: list[str] = []
        self.stop_calls: int = 0
        self.exec_response: dict[str, Any] = {
            "stdout": "",
            "stderr": "",
            "statusCode": 0,
        }
        self.file_exists_response: bool = True
        self.read_response: str = ""

    async def exec(
        self,
        command: str,
        *,
        terminal: str | None = None,
        timeout_ms: int | None = None,
    ) -> dict[str, Any]:
        self.exec_calls.append(
            {"command": command, "terminal": terminal, "timeout_ms": timeout_ms}
        )
        return self.exec_response

    async def write_file(self, path: str, content: str | bytes) -> None:
        self.write_calls.append({"path": path, "content": content})

    async def read_file(self, path: str) -> str:
        self.read_calls.append(path)
        return self.read_response

    async def file_exists(self, path: str) -> bool:
        self.file_exists_calls.append(path)
        return self.file_exists_response

    async def stop(self) -> None:
        self.stop_calls += 1


class TestFreestyleAdapter:
    def test_freestyle_returns_sandbox_adapter(self) -> None:
        from agentsh_secure_sandbox.adapters.freestyle._adapter import freestyle

        vm = FakeFreestyleVm()
        adapter = freestyle(vm)  # type: ignore[arg-type]
        assert isinstance(adapter, SandboxAdapter)  # type: ignore[misc]

    async def test_exec_maps_status_code_to_exit_code(self) -> None:
        from agentsh_secure_sandbox.adapters.freestyle._adapter import freestyle

        vm = FakeFreestyleVm()
        vm.exec_response = {"stdout": "hi\n", "stderr": "", "statusCode": 7}
        adapter = freestyle(vm)  # type: ignore[arg-type]
        result = await adapter.exec("echo", ["hi"])
        assert result.stdout == "hi\n"
        assert result.stderr == ""
        assert result.exit_code == 7

    async def test_exec_missing_status_code_defaults_to_zero(self) -> None:
        from agentsh_secure_sandbox.adapters.freestyle._adapter import freestyle

        vm = FakeFreestyleVm()
        vm.exec_response = {"stdout": "", "stderr": ""}
        adapter = freestyle(vm)  # type: ignore[arg-type]
        result = await adapter.exec("true")
        assert result.exit_code == 0

    async def test_exec_passes_built_command_string(self) -> None:
        from agentsh_secure_sandbox.adapters.freestyle._adapter import freestyle

        vm = FakeFreestyleVm()
        adapter = freestyle(vm)  # type: ignore[arg-type]
        await adapter.exec(
            "echo",
            ["hello"],
            ExecOpts(env={"FOO": "bar"}, cwd="/tmp"),
        )
        assert len(vm.exec_calls) == 1
        cmd = vm.exec_calls[0]["command"]
        assert cmd.startswith("bash -c ")
        assert "cd /tmp &&" in cmd
        assert "FOO=bar" in cmd

    async def test_exec_detached_returns_immediately_and_fires_background(self) -> None:
        import asyncio as _asyncio
        from agentsh_secure_sandbox.adapters.freestyle._adapter import freestyle

        vm = FakeFreestyleVm()
        adapter = freestyle(vm)  # type: ignore[arg-type]
        result = await adapter.exec("sleep", ["60"], ExecOpts(detached=True))
        # Detached is fire-and-forget — caller gets exit 0 immediately
        assert result.exit_code == 0
        # Give the background task a chance to run
        await _asyncio.sleep(0.05)
        assert len(vm.exec_calls) == 1
        assert "nohup" in vm.exec_calls[0]["command"]

    async def test_exec_freestyle_error_becomes_nonzero_exit(self) -> None:
        from agentsh_secure_sandbox.adapters.freestyle._adapter import freestyle
        from agentsh_secure_sandbox.adapters.freestyle._client import FreestyleError

        class RaisingVm(FakeFreestyleVm):
            async def exec(self, *a: Any, **kw: Any) -> dict[str, Any]:
                raise FreestyleError("boom", status=502, body="upstream")

        adapter = freestyle(RaisingVm())  # type: ignore[arg-type]
        result = await adapter.exec("echo", ["hi"])
        assert result.exit_code != 0
        assert "boom" in result.stderr or "upstream" in result.stderr

    async def test_write_file_delegates_to_vm(self) -> None:
        from agentsh_secure_sandbox.adapters.freestyle._adapter import freestyle

        vm = FakeFreestyleVm()
        adapter = freestyle(vm)  # type: ignore[arg-type]
        await adapter.write_file("/tmp/x", "hello")
        assert vm.write_calls == [{"path": "/tmp/x", "content": "hello"}]

    async def test_write_file_bytes_pass_through(self) -> None:
        from agentsh_secure_sandbox.adapters.freestyle._adapter import freestyle

        vm = FakeFreestyleVm()
        adapter = freestyle(vm)  # type: ignore[arg-type]
        await adapter.write_file("/tmp/x", b"\x00\x01")
        assert vm.write_calls[0]["content"] == b"\x00\x01"

    async def test_write_file_raises_wraps_freestyle_error(self) -> None:
        from agentsh_secure_sandbox.adapters.freestyle._adapter import freestyle
        from agentsh_secure_sandbox.adapters.freestyle._client import FreestyleError

        class RaisingVm(FakeFreestyleVm):
            async def write_file(self, path: str, content: str | bytes) -> None:
                raise FreestyleError("write denied", status=403)

        adapter = freestyle(RaisingVm())  # type: ignore[arg-type]
        with pytest.raises(Exception, match="write denied"):
            await adapter.write_file("/forbidden", "x")

    async def test_read_file_delegates_to_vm(self) -> None:
        from agentsh_secure_sandbox.adapters.freestyle._adapter import freestyle

        vm = FakeFreestyleVm()
        vm.read_response = "file body"
        adapter = freestyle(vm)  # type: ignore[arg-type]
        content = await adapter.read_file("/tmp/x")
        assert content == "file body"
        assert vm.read_calls == ["/tmp/x"]

    async def test_file_exists_delegates(self) -> None:
        from agentsh_secure_sandbox.adapters.freestyle._adapter import freestyle

        vm = FakeFreestyleVm()
        vm.file_exists_response = True
        adapter = freestyle(vm)  # type: ignore[arg-type]
        assert await adapter.file_exists("/usr/local/bin/agentsh") is True
        assert vm.file_exists_calls == ["/usr/local/bin/agentsh"]

    async def test_stop_delegates(self) -> None:
        from agentsh_secure_sandbox.adapters.freestyle._adapter import freestyle

        vm = FakeFreestyleVm()
        adapter = freestyle(vm)  # type: ignore[arg-type]
        await adapter.stop()
        assert vm.stop_calls == 1
