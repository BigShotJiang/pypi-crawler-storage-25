from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from tests.e2e import test_daytona as daytona_e2e


@pytest.mark.asyncio
async def test_create_secured_daytona_cleans_up_on_secure_failure() -> None:
    raw = object()
    client = SimpleNamespace(
        create=AsyncMock(return_value=raw),
        delete=AsyncMock(),
        close=AsyncMock(),
    )
    secure_factory = AsyncMock(side_effect=RuntimeError("boom"))

    with pytest.raises(RuntimeError, match="boom"):
        await daytona_e2e._create_secured_daytona(  # type: ignore[attr-defined]
            client_factory=lambda: client,
            adapter_factory=lambda candidate: ("adapter", candidate),
            secure_factory=secure_factory,
        )

    client.create.assert_awaited_once()
    secure_factory.assert_awaited_once_with(("adapter", raw))
    client.delete.assert_awaited_once_with(raw)
    client.close.assert_awaited_once()


@pytest.mark.asyncio
async def test_cleanup_daytona_client_closes_without_raw() -> None:
    client = SimpleNamespace(
        delete=AsyncMock(),
        close=AsyncMock(),
    )

    await daytona_e2e._cleanup_daytona_client(client, None)  # type: ignore[attr-defined]

    client.delete.assert_not_awaited()
    client.close.assert_awaited_once()
