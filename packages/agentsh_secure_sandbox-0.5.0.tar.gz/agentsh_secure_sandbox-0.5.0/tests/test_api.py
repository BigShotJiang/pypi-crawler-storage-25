# tests/test_api.py
from unittest.mock import AsyncMock, MagicMock
from agentsh_secure_sandbox._api import secure_sandbox
from agentsh_secure_sandbox.core.types import ExecResult, SecureConfig


async def test_secure_sandbox_returns_secured():
    """secure_sandbox() should provision and return a SecuredSandbox."""
    mock_adapter = MagicMock()
    mock_adapter.write_file = AsyncMock()
    mock_adapter.stop = AsyncMock()
    mock_adapter.file_exists = AsyncMock(return_value=False)

    def exec_side_effect(cmd, args=None, opts=None):
        full = f"{cmd} {' '.join(args or [])}"
        if "AGENTSH_SESSION_ID" in full:
            return ExecResult(stdout="test-session-123", stderr="", exit_code=0)
        if "health" in full or ("curl" in full and "18080" in full):
            return ExecResult(stdout="ok", stderr="", exit_code=0)
        return ExecResult(stdout="", stderr="", exit_code=0)

    mock_adapter.exec = AsyncMock(side_effect=exec_side_effect)

    cfg = SecureConfig(install_strategy="running")
    sb = await secure_sandbox(mock_adapter, cfg)

    assert hasattr(sb, "exec")
    assert hasattr(sb, "write_file")
    assert hasattr(sb, "read_file")
    assert hasattr(sb, "stop")
    assert hasattr(sb, "session_id")
    assert hasattr(sb, "security_mode")
