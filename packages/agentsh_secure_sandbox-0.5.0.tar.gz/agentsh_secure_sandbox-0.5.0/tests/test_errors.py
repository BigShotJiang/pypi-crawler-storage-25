from agentsh_secure_sandbox.core.errors import (
    AgentSHError,
    PolicyValidationError,
    ProvisioningError,
    IntegrityError,
    TransportError,
)


def test_error_hierarchy():
    assert issubclass(PolicyValidationError, AgentSHError)
    assert issubclass(ProvisioningError, AgentSHError)
    assert issubclass(IntegrityError, AgentSHError)
    assert issubclass(TransportError, AgentSHError)


def test_provisioning_error_fields():
    e = ProvisioningError(phase="binary", command="curl", stderr="not found")
    assert e.phase == "binary"
    assert e.command == "curl"
    assert e.stderr == "not found"
    assert "binary" in str(e)


def test_integrity_error_fields():
    e = IntegrityError(expected="abc", actual="def")
    assert e.expected == "abc"
    assert e.actual == "def"
    assert "abc" in str(e)


def test_transport_error_fields():
    e = TransportError(session_id="s1", command="ls", stderr="not found")
    assert e.session_id == "s1"
    assert "s1" in str(e)


def test_policy_validation_error():
    e = PolicyValidationError(errors=["bad field", "missing value"])
    assert len(e.errors) == 2
    assert "bad field" in str(e)


def test_runtime_error():
    from agentsh_secure_sandbox.core.errors import RuntimeError as AgentshRuntimeError
    err = AgentshRuntimeError(session_id="sess-1", command="ls", stderr="denied")
    assert err.session_id == "sess-1"
    assert err.command == "ls"
    assert "sess-1" in str(err)
