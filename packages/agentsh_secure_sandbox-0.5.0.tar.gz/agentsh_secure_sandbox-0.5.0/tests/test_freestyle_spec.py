"""Unit tests for FreestyleVmSpec and supporting models."""

from __future__ import annotations

import pytest

from agentsh_secure_sandbox.adapters.freestyle._spec import (
    FreestyleFile,
    FreestyleSystemdService,
    FreestyleSystemdConfig,
    FreestyleVmSpec,
)


class TestFreestyleFile:
    def test_defaults_to_utf8_encoding(self) -> None:
        f = FreestyleFile(content="hello")
        assert f.content == "hello"
        assert f.encoding == "utf-8"

    def test_accepts_base64_encoding(self) -> None:
        f = FreestyleFile(content="aGVsbG8=", encoding="base64")
        assert f.encoding == "base64"

    def test_rejects_unknown_encoding(self) -> None:
        with pytest.raises(ValueError):
            FreestyleFile(content="x", encoding="rot13")  # type: ignore[arg-type]

    def test_extra_fields_allowed(self) -> None:
        f = FreestyleFile(content="x", mode=0o755)  # type: ignore[call-arg]
        assert f.model_dump().get("mode") == 0o755


class TestFreestyleSystemdService:
    def test_minimum_fields(self) -> None:
        svc = FreestyleSystemdService(name="foo")
        assert svc.name == "foo"
        assert svc.mode == "service"

    def test_exec_alias_serializes_as_exec(self) -> None:
        svc = FreestyleSystemdService(name="foo", exec_=["/bin/true"])
        dumped = svc.model_dump(by_alias=True, exclude_none=True)
        assert dumped["exec"] == ["/bin/true"]
        assert "exec_" not in dumped

    def test_wanted_by_alias_serializes_as_wantedBy(self) -> None:
        svc = FreestyleSystemdService(name="foo", wanted_by=["multi-user.target"])
        dumped = svc.model_dump(by_alias=True, exclude_none=True)
        assert dumped["wantedBy"] == ["multi-user.target"]
        assert "wanted_by" not in dumped

    def test_accepts_bash_field(self) -> None:
        svc = FreestyleSystemdService(name="foo", bash="echo hi")
        assert svc.bash == "echo hi"

    def test_extra_fields_allowed(self) -> None:
        svc = FreestyleSystemdService(name="foo", customField=123)  # type: ignore[call-arg]
        dumped = svc.model_dump(by_alias=True, exclude_none=True)
        assert dumped["customField"] == 123


class TestFreestyleSystemdConfig:
    def test_services_list(self) -> None:
        cfg = FreestyleSystemdConfig(
            services=[FreestyleSystemdService(name="a"), FreestyleSystemdService(name="b")]
        )
        assert len(cfg.services or []) == 2


class TestFreestyleVmSpecFields:
    def test_empty_spec_has_all_none_fields(self) -> None:
        spec = FreestyleVmSpec()
        assert spec.apt_deps is None
        assert spec.additional_files is None
        assert spec.systemd is None
        assert spec.snapshot_ is None
        assert spec.idle_timeout_seconds is None
        assert spec.workdir is None

    def test_direct_field_assignment_works(self) -> None:
        spec = FreestyleVmSpec()
        spec.idle_timeout_seconds = 600
        assert spec.idle_timeout_seconds == 600


class TestFreestyleVmSpecSnapshot:
    def test_snapshot_moves_current_layer_inward(self) -> None:
        spec = FreestyleVmSpec(
            apt_deps=["curl"],
            workdir="/workspace",
            idle_timeout_seconds=300,
        )
        returned = spec.snapshot()
        assert returned is spec  # fluent
        # Outer layer is cleared
        assert spec.apt_deps is None
        assert spec.workdir is None
        assert spec.idle_timeout_seconds is None
        # Inner layer holds the old values
        assert spec.snapshot_ is not None
        assert spec.snapshot_.apt_deps == ["curl"]
        assert spec.snapshot_.workdir == "/workspace"
        assert spec.snapshot_.idle_timeout_seconds == 300

    def test_snapshot_on_empty_spec_creates_empty_inner(self) -> None:
        spec = FreestyleVmSpec()
        spec.snapshot()
        assert spec.snapshot_ is not None
        assert spec.snapshot_.apt_deps is None

    def test_snapshot_twice_creates_nested_snapshots(self) -> None:
        spec = FreestyleVmSpec(apt_deps=["a"])
        spec.snapshot()
        spec.apt_deps = ["b"]
        spec.snapshot()
        # Outer: None, inner: ["b"], inner.inner: ["a"]
        assert spec.apt_deps is None
        assert spec.snapshot_ is not None
        assert spec.snapshot_.apt_deps == ["b"]
        assert spec.snapshot_.snapshot_ is not None
        assert spec.snapshot_.snapshot_.apt_deps == ["a"]

    def test_snapshot_clears_and_moves_extra_fields(self) -> None:
        """Unknown (extra=allow) fields should move into the inner
        snapshot and disappear from the outer layer, mirroring how
        declared fields behave."""
        spec = FreestyleVmSpec.model_validate(
            {"aptDeps": ["curl"], "customField": "x"}
        )
        spec.snapshot()
        outer_dump = spec.model_dump(by_alias=True, exclude_none=True)
        # Outer should only contain the snapshot wrapper — no leftovers.
        assert set(outer_dump.keys()) == {"snapshot"}
        # Inner should contain both the declared field and the extra.
        assert spec.snapshot_ is not None
        inner_dump = spec.snapshot_.model_dump(by_alias=True, exclude_none=True)
        assert inner_dump["aptDeps"] == ["curl"]
        assert inner_dump["customField"] == "x"


class TestFreestyleVmSpecFluent:
    def test_apt_deps_add_appends_and_is_chainable(self) -> None:
        spec = FreestyleVmSpec()
        returned = spec.apt_deps_add("curl", "jq")
        assert returned is spec
        assert spec.apt_deps == ["curl", "jq"]

        spec.apt_deps_add("git")
        assert spec.apt_deps == ["curl", "jq", "git"]

    def test_apt_deps_add_ignores_duplicates(self) -> None:
        spec = FreestyleVmSpec()
        spec.apt_deps_add("curl")
        spec.apt_deps_add("curl", "jq")
        assert spec.apt_deps == ["curl", "jq"]

    def test_additional_files_add_accepts_str_content(self) -> None:
        spec = FreestyleVmSpec()
        spec.additional_files_add({"/etc/hello": "world"})
        assert spec.additional_files is not None
        assert spec.additional_files["/etc/hello"].content == "world"
        assert spec.additional_files["/etc/hello"].encoding == "utf-8"

    def test_additional_files_add_accepts_freestyle_file(self) -> None:
        spec = FreestyleVmSpec()
        spec.additional_files_add(
            {"/etc/data": FreestyleFile(content="aGk=", encoding="base64")}
        )
        assert spec.additional_files is not None
        assert spec.additional_files["/etc/data"].encoding == "base64"

    def test_additional_files_add_accepts_bytes(self) -> None:
        import base64 as b64
        spec = FreestyleVmSpec()
        spec.additional_files_add({"/etc/bin": b"\x00\x01\x02"})
        assert spec.additional_files is not None
        f = spec.additional_files["/etc/bin"]
        assert f.encoding == "base64"
        assert b64.b64decode(f.content) == b"\x00\x01\x02"

    def test_additional_files_add_merges_with_existing(self) -> None:
        spec = FreestyleVmSpec()
        spec.additional_files_add({"/a": "1"})
        spec.additional_files_add({"/b": "2"})
        assert spec.additional_files is not None
        assert set(spec.additional_files) == {"/a", "/b"}

    def test_idle_timeout_seconds_underscore_setter(self) -> None:
        spec = FreestyleVmSpec()
        returned = spec.idle_timeout_seconds_(900)
        assert returned is spec
        assert spec.idle_timeout_seconds == 900

    def test_workdir_underscore_setter(self) -> None:
        spec = FreestyleVmSpec()
        returned = spec.workdir_("/home/user")
        assert returned is spec
        assert spec.workdir == "/home/user"


class TestFreestyleVmSpecSystemd:
    def test_with_systemd_service_creates_systemd_block(self) -> None:
        spec = FreestyleVmSpec()
        returned = spec.with_systemd_service("agentsh", bash="echo hi")
        assert returned is spec
        assert spec.systemd is not None
        assert spec.systemd.services is not None
        assert len(spec.systemd.services) == 1
        assert spec.systemd.services[0].name == "agentsh"
        assert spec.systemd.services[0].bash == "echo hi"

    def test_with_systemd_service_appends_additional_services(self) -> None:
        spec = FreestyleVmSpec()
        spec.with_systemd_service("a", bash="echo a")
        spec.with_systemd_service("b", bash="echo b")
        assert spec.systemd is not None
        assert [s.name for s in (spec.systemd.services or [])] == ["a", "b"]

    def test_with_systemd_service_accepts_exec_kwarg(self) -> None:
        spec = FreestyleVmSpec()
        spec.with_systemd_service("foo", exec=["/bin/true"])
        assert spec.systemd is not None
        svc = (spec.systemd.services or [])[0]
        assert svc.exec_ == ["/bin/true"]

    def test_with_systemd_service_accepts_wanted_by_kwarg(self) -> None:
        spec = FreestyleVmSpec()
        spec.with_systemd_service("foo", bash="x", wantedBy=["multi-user.target"])
        assert spec.systemd is not None
        svc = (spec.systemd.services or [])[0]
        assert svc.wanted_by == ["multi-user.target"]

    def test_with_systemd_service_accepts_after_and_requires(self) -> None:
        spec = FreestyleVmSpec()
        spec.with_systemd_service(
            "agentsh", bash="x",
            after=["install-agentsh"],
            requires=["install-agentsh"],
        )
        assert spec.systemd is not None
        svc = (spec.systemd.services or [])[0]
        assert svc.after == ["install-agentsh"]
        assert svc.requires == ["install-agentsh"]


class TestFreestyleVmSpecToRequestBody:
    def test_empty_spec_serializes_to_empty_dict(self) -> None:
        assert FreestyleVmSpec().to_request_body() == {}

    def test_camelcase_aliases_used(self) -> None:
        spec = FreestyleVmSpec(
            apt_deps=["curl"],
            idle_timeout_seconds=600,
            workdir="/app",
        )
        body = spec.to_request_body()
        assert body["aptDeps"] == ["curl"]
        assert body["idleTimeoutSeconds"] == 600
        assert body["workdir"] == "/app"
        assert "apt_deps" not in body
        assert "idle_timeout_seconds" not in body

    def test_bash_service_rewritten_to_exec_plus_script_file(self) -> None:
        spec = FreestyleVmSpec()
        spec.with_systemd_service("install-agentsh", bash="set -eux\necho hi")
        body = spec.to_request_body()

        # The service's bash field is gone, replaced by exec
        services = body["systemd"]["services"]
        assert len(services) == 1
        svc = services[0]
        assert "bash" not in svc
        assert svc["exec"] == ["/bin/bash /opt/freestyle/scripts/install-agentsh.sh"]

        # The script lives in additionalFiles
        files = body["additionalFiles"]
        script_path = "/opt/freestyle/scripts/install-agentsh.sh"
        assert script_path in files
        assert files[script_path]["content"].startswith("#!/bin/bash\n")
        assert "set -eux\necho hi" in files[script_path]["content"]
        assert files[script_path]["encoding"] == "utf-8"

    def test_bash_script_with_existing_shebang_not_duplicated(self) -> None:
        spec = FreestyleVmSpec()
        spec.with_systemd_service("foo", bash="#!/bin/bash\necho hi")
        body = spec.to_request_body()
        content = body["additionalFiles"]["/opt/freestyle/scripts/foo.sh"]["content"]
        assert content.count("#!/bin/bash") == 1

    def test_service_suffix_appended_to_after_and_requires_bare_names(self) -> None:
        spec = FreestyleVmSpec()
        spec.with_systemd_service(
            "agentsh",
            exec=["/usr/local/bin/agentsh"],
            after=["install-agentsh"],
            requires=["install-agentsh"],
            wantedBy=["multi-user.target"],
        )
        body = spec.to_request_body()
        svc = body["systemd"]["services"][0]
        assert svc["after"] == ["install-agentsh.service"]
        assert svc["requires"] == ["install-agentsh.service"]
        # multi-user.target already has a dot — not rewritten
        assert svc["wantedBy"] == ["multi-user.target"]

    def test_service_suffix_not_appended_when_already_present(self) -> None:
        spec = FreestyleVmSpec()
        spec.with_systemd_service(
            "agentsh", exec=["/x"], after=["install-agentsh.service"]
        )
        body = spec.to_request_body()
        svc = body["systemd"]["services"][0]
        assert svc["after"] == ["install-agentsh.service"]

    def test_snapshot_recursion_transforms_inner_layer(self) -> None:
        spec = FreestyleVmSpec()
        spec.with_systemd_service("inner", bash="echo inner")
        spec.snapshot()  # moves "inner" service into snapshot_
        body = spec.to_request_body()
        # The inner snapshot should itself have the transform applied
        inner = body["snapshot"]
        inner_svc = inner["systemd"]["services"][0]
        assert "bash" not in inner_svc
        assert inner_svc["exec"] == [
            "/bin/bash /opt/freestyle/scripts/inner.sh"
        ]
        assert "/opt/freestyle/scripts/inner.sh" in inner["additionalFiles"]

    def test_extra_fields_passthrough(self) -> None:
        spec = FreestyleVmSpec(apt_deps=["curl"], futureField="value")  # type: ignore[call-arg]
        body = spec.to_request_body()
        assert body["aptDeps"] == ["curl"]
        assert body["futureField"] == "value"

    def test_none_fields_excluded(self) -> None:
        spec = FreestyleVmSpec(apt_deps=["curl"])
        body = spec.to_request_body()
        assert list(body.keys()) == ["aptDeps"]

    def test_from_dict_validation(self) -> None:
        d = {"aptDeps": ["curl"], "idleTimeoutSeconds": 600}
        spec = FreestyleVmSpec.model_validate(d)
        assert spec.apt_deps == ["curl"]
        assert spec.idle_timeout_seconds == 600
