# OpenAI Agents SDK Sandbox Adapters Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add OpenAI Agents SDK `SandboxAgent` support by wrapping upstream OpenAI sandbox clients and adding custom OpenAI-compatible clients for Sprites, exe.dev, and Freestyle.

**Architecture:** Add a new `agentsh_secure_sandbox.openai_sandbox` package. Upstream OpenAI provider clients are wrapped by `SecureOpenAISandboxClient`, which returns `SecureOpenAISandboxSession` objects that route model-facing operations through `SecuredSandbox`. Sprites, exe.dev, and Freestyle use custom clients built on the same secured session base.

**Tech Stack:** Python 3.11+, OpenAI Agents SDK `openai-agents>=0.14.1`, pytest, pytest-asyncio, pydantic, existing `SandboxAdapter` and `secure_sandbox()` APIs.

---

## File Structure

Create:

- `src/agentsh_secure_sandbox/openai_sandbox/__init__.py`
  - Public exports and optional dependency errors.
- `src/agentsh_secure_sandbox/openai_sandbox/bridge.py`
  - `_OpenAISessionAdapter`, `SecureOpenAISandboxSession`, stream/result conversion helpers.
- `src/agentsh_secure_sandbox/openai_sandbox/wrappers.py`
  - `SecureOpenAISandboxClient`, which wraps upstream OpenAI SDK sandbox clients.
- `src/agentsh_secure_sandbox/openai_sandbox/unsupported.py`
  - `SpritesSandboxClient`, `ExeSandboxClient`, `FreestyleSandboxClient`, their options, and state classes.
- `src/agentsh_secure_sandbox/openai_sandbox/providers.py`
  - `secure_openai_sandbox_client()` provider registry and upstream-client validation.
- `tests/test_openai_sandbox_bridge.py`
  - Unit tests for session adapter and secured session behavior.
- `tests/test_openai_sandbox_wrappers.py`
  - Unit tests for upstream client wrapper delegation.
- `tests/test_openai_sandbox_unsupported.py`
  - Unit tests for custom unsupported provider clients.
- `tests/test_openai_sandbox_public_api.py`
  - Unit tests for public imports and existing top-level API.
- `tests/e2e/test_openai_sandbox_sessions.py`
  - Provider-session e2e tests for all providers with keys.
- `tests/e2e/test_openai_sandbox_agents.py`
  - Model-driven `SandboxAgent` e2e tests.

Modify:

- `src/agentsh_secure_sandbox/__init__.py`
  - Re-export new OpenAI sandbox symbols with clear missing-extra behavior.
- `tests/e2e/conftest.py`
  - Load explicit extra env files via `AGENTSH_E2E_ENV_FILES`; add `OPENAI_API_KEY`; add marker helpers.
- `pyproject.toml`
  - Register `openai_agent_e2e` marker.
- `README.md`
  - Document the new `SandboxAgent` integration and e2e env handling.

Do not modify existing provider adapters unless a unit test proves a small compatibility fix is required.

---

### Task 1: Public Package Skeleton

**Files:**
- Create: `src/agentsh_secure_sandbox/openai_sandbox/__init__.py`
- Create: `tests/test_openai_sandbox_public_api.py`
- Modify: `src/agentsh_secure_sandbox/__init__.py`

- [ ] **Step 1: Write failing public import tests**

Add `tests/test_openai_sandbox_public_api.py`:

```python
from __future__ import annotations


def test_openai_sandbox_submodule_exports_public_symbols() -> None:
    from agentsh_secure_sandbox.openai_sandbox import (
        ExeSandboxClient,
        FreestyleSandboxClient,
        SecureOpenAISandboxClient,
        SecureOpenAISandboxSession,
        SpritesSandboxClient,
        secure_openai_sandbox_client,
    )

    assert SecureOpenAISandboxClient is not None
    assert SecureOpenAISandboxSession is not None
    assert secure_openai_sandbox_client is not None
    assert SpritesSandboxClient is not None
    assert ExeSandboxClient is not None
    assert FreestyleSandboxClient is not None


def test_top_level_package_exports_openai_sandbox_symbols() -> None:
    from agentsh_secure_sandbox import (
        ExeSandboxClient,
        FreestyleSandboxClient,
        SecureOpenAISandboxClient,
        SecureOpenAISandboxSession,
        SpritesSandboxClient,
        secure_openai_sandbox_client,
    )

    assert SecureOpenAISandboxClient is not None
    assert SecureOpenAISandboxSession is not None
    assert secure_openai_sandbox_client is not None
    assert SpritesSandboxClient is not None
    assert ExeSandboxClient is not None
    assert FreestyleSandboxClient is not None
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```bash
uv run pytest tests/test_openai_sandbox_public_api.py -q
```

Expected: FAIL with `ModuleNotFoundError: No module named 'agentsh_secure_sandbox.openai_sandbox'`.

- [ ] **Step 3: Create minimal module skeleton**

Create `src/agentsh_secure_sandbox/openai_sandbox/__init__.py`:

```python
"""OpenAI Agents SDK SandboxAgent integration."""

from __future__ import annotations


class SecureOpenAISandboxClient:
    pass


class SecureOpenAISandboxSession:
    pass


class SpritesSandboxClient:
    pass


class ExeSandboxClient:
    pass


class FreestyleSandboxClient:
    pass


def secure_openai_sandbox_client(*args: object, **kwargs: object) -> object:
    raise NotImplementedError("secure_openai_sandbox_client is not implemented yet")


__all__ = [
    "SecureOpenAISandboxClient",
    "SecureOpenAISandboxSession",
    "secure_openai_sandbox_client",
    "SpritesSandboxClient",
    "ExeSandboxClient",
    "FreestyleSandboxClient",
]
```

Modify `src/agentsh_secure_sandbox/__init__.py` before `__all__`:

```python
try:
    from .openai_sandbox import (
        ExeSandboxClient,
        FreestyleSandboxClient,
        SecureOpenAISandboxClient,
        SecureOpenAISandboxSession,
        SpritesSandboxClient,
        secure_openai_sandbox_client,
    )
except ModuleNotFoundError as _exc:
    if _exc.name and _exc.name.split(".")[0] in ("agents", "openai_agents"):

        def _missing_openai_sandbox(*_a: object, **_kw: object) -> object:
            raise ImportError(
                "OpenAI sandbox support requires the openai-agents extra. "
                "Install it with: pip install agentsh-secure-sandbox[openai-agents]"
            )

        SecureOpenAISandboxClient = _missing_openai_sandbox  # type: ignore[assignment,misc]
        SecureOpenAISandboxSession = _missing_openai_sandbox  # type: ignore[assignment,misc]
        SpritesSandboxClient = _missing_openai_sandbox  # type: ignore[assignment,misc]
        ExeSandboxClient = _missing_openai_sandbox  # type: ignore[assignment,misc]
        FreestyleSandboxClient = _missing_openai_sandbox  # type: ignore[assignment,misc]
        secure_openai_sandbox_client = _missing_openai_sandbox  # type: ignore[assignment,misc]
    else:
        raise
```

Add these names to the existing top-level `__all__` list:

```python
"SecureOpenAISandboxClient",
"SecureOpenAISandboxSession",
"secure_openai_sandbox_client",
"SpritesSandboxClient",
"ExeSandboxClient",
"FreestyleSandboxClient",
```

- [ ] **Step 4: Run test to verify it passes**

Run:

```bash
uv run pytest tests/test_openai_sandbox_public_api.py -q
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/agentsh_secure_sandbox/openai_sandbox/__init__.py src/agentsh_secure_sandbox/__init__.py tests/test_openai_sandbox_public_api.py
git commit -m "feat(openai): add sandbox integration public API skeleton"
```

---

### Task 2: OpenAI Session Adapter

**Files:**
- Create: `src/agentsh_secure_sandbox/openai_sandbox/bridge.py`
- Modify: `src/agentsh_secure_sandbox/openai_sandbox/__init__.py`
- Test: `tests/test_openai_sandbox_bridge.py`

- [ ] **Step 1: Write failing adapter tests**

Create `tests/test_openai_sandbox_bridge.py`:

```python
from __future__ import annotations

import io
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from agents.sandbox.types import ExecResult as OpenAIExecResult

from agentsh_secure_sandbox.core.types import ExecOpts


async def test_openai_session_adapter_exec_converts_bytes_to_strings() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = AsyncMock()
    inner.exec = AsyncMock(
        return_value=OpenAIExecResult(stdout=b"hello\n", stderr=b"", exit_code=0)
    )

    adapter = _OpenAISessionAdapter(inner)
    result = await adapter.exec("echo", ["hello"], ExecOpts(cwd="/workspace"))

    assert result.stdout == "hello\n"
    assert result.stderr == ""
    assert result.exit_code == 0
    inner.exec.assert_awaited_once_with("echo", "hello", timeout=None, shell=False)


async def test_openai_session_adapter_write_and_read() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = AsyncMock()
    inner.write = AsyncMock()
    inner.read = AsyncMock(return_value=io.BytesIO(b"content"))

    adapter = _OpenAISessionAdapter(inner)
    await adapter.write_file("/workspace/file.txt", "content")
    content = await adapter.read_file("/workspace/file.txt")

    assert content == "content"
    write_args = inner.write.await_args.args
    assert write_args[0] == Path("/workspace/file.txt")
    assert write_args[1].read() == b"content"
    inner.read.assert_awaited_once_with(Path("/workspace/file.txt"))


async def test_openai_session_adapter_stop_calls_inner_shutdown() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = AsyncMock()
    inner.shutdown = AsyncMock()

    adapter = _OpenAISessionAdapter(inner)
    await adapter.stop()

    inner.shutdown.assert_awaited_once()


async def test_openai_session_adapter_file_exists_uses_test_dash_f() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import _OpenAISessionAdapter

    inner = AsyncMock()
    inner.exec = AsyncMock(
        return_value=OpenAIExecResult(stdout=b"", stderr=b"", exit_code=0)
    )

    adapter = _OpenAISessionAdapter(inner)

    assert await adapter.file_exists("/workspace/file.txt") is True
    inner.exec.assert_awaited_once_with(
        "test",
        "-f",
        "/workspace/file.txt",
        timeout=None,
        shell=False,
    )
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```bash
uv run pytest tests/test_openai_sandbox_bridge.py -q -k openai_session_adapter
```

Expected: FAIL with `ModuleNotFoundError` or missing `_OpenAISessionAdapter`.

- [ ] **Step 3: Implement adapter**

Create `src/agentsh_secure_sandbox/openai_sandbox/bridge.py`:

```python
from __future__ import annotations

import io
from pathlib import Path
from typing import Any

from agents.sandbox.session.base_sandbox_session import BaseSandboxSession

from agentsh_secure_sandbox.core.types import ExecOpts, ExecResult


def _decode_bytes(value: bytes | bytearray | str | None) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return bytes(value).decode("utf-8", errors="replace")


def _coerce_openai_exec_result(result: Any) -> ExecResult:
    return ExecResult(
        stdout=_decode_bytes(getattr(result, "stdout", b"")),
        stderr=_decode_bytes(getattr(result, "stderr", b"")),
        exit_code=int(getattr(result, "exit_code", 0) or 0),
    )


class _OpenAISessionAdapter:
    """Adapt an OpenAI SDK sandbox session to this project's SandboxAdapter protocol."""

    def __init__(self, session: BaseSandboxSession) -> None:
        self._session = session

    async def exec(
        self,
        cmd: str,
        args: list[str] | None = None,
        opts: ExecOpts | None = None,
    ) -> ExecResult:
        opts = opts or ExecOpts()
        command = [cmd, *(args or [])]
        result = await self._session.exec(
            *command,
            timeout=None,
            shell=False,
        )
        return _coerce_openai_exec_result(result)

    async def write_file(
        self,
        path: str,
        content: str | bytes,
        *,
        sudo: bool = False,
    ) -> None:
        _ = sudo
        data = content if isinstance(content, bytes) else content.encode()
        await self._session.write(Path(path), io.BytesIO(data))

    async def read_file(self, path: str) -> str:
        payload = await self._session.read(Path(path))
        raw = payload.read()
        return _decode_bytes(raw)

    async def stop(self) -> None:
        await self._session.shutdown()

    async def file_exists(self, path: str) -> bool:
        result = await self._session.exec("test", "-f", path, timeout=None, shell=False)
        return int(getattr(result, "exit_code", 1) or 0) == 0
```

- [ ] **Step 4: Run test to verify it passes**

Run:

```bash
uv run pytest tests/test_openai_sandbox_bridge.py -q -k openai_session_adapter
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/agentsh_secure_sandbox/openai_sandbox/bridge.py tests/test_openai_sandbox_bridge.py
git commit -m "feat(openai): adapt OpenAI sandbox sessions to agentsh adapters"
```

---

### Task 3: Secure OpenAI Session Wrapper

**Files:**
- Modify: `src/agentsh_secure_sandbox/openai_sandbox/bridge.py`
- Modify: `src/agentsh_secure_sandbox/openai_sandbox/__init__.py`
- Test: `tests/test_openai_sandbox_bridge.py`

- [ ] **Step 1: Write failing secured session tests**

Append to `tests/test_openai_sandbox_bridge.py`:

```python
async def test_secure_openai_session_exec_routes_through_secured_sandbox() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession

    inner = AsyncMock()
    inner.state = MagicMock()
    secured = AsyncMock()
    secured.exec = AsyncMock(
        return_value=MagicMock(stdout="secure out", stderr="", exit_code=0)
    )

    session = SecureOpenAISandboxSession(inner_session=inner, secured_sandbox=secured)
    result = await session.exec("echo", "hello", shell=False)

    assert result.stdout == b"secure out"
    assert result.stderr == b""
    assert result.exit_code == 0
    secured.exec.assert_awaited_once_with("echo hello", timeout=None)


async def test_secure_openai_session_read_write_route_through_secured_sandbox() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession

    inner = AsyncMock()
    inner.state = MagicMock()
    secured = AsyncMock()
    secured.write_file = AsyncMock(return_value=MagicMock(success=True, path="/workspace/a.txt"))
    secured.read_file = AsyncMock(
        return_value=MagicMock(success=True, path="/workspace/a.txt", content="payload")
    )

    session = SecureOpenAISandboxSession(inner_session=inner, secured_sandbox=secured)

    await session.write(Path("/workspace/a.txt"), io.BytesIO(b"payload"))
    read = await session.read(Path("/workspace/a.txt"))

    assert read.read() == b"payload"
    secured.write_file.assert_awaited_once_with("/workspace/a.txt", b"payload")
    secured.read_file.assert_awaited_once_with("/workspace/a.txt")


async def test_secure_openai_session_delegates_state_and_running() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession

    state = MagicMock()
    inner = AsyncMock()
    inner.state = state
    inner.running = AsyncMock(return_value=True)
    secured = AsyncMock()

    session = SecureOpenAISandboxSession(inner_session=inner, secured_sandbox=secured)

    assert session.state is state
    assert await session.running() is True


async def test_secure_openai_session_stop_and_shutdown_stop_secured_sandbox_once() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession

    inner = AsyncMock()
    inner.state = MagicMock()
    inner.stop = AsyncMock()
    inner.shutdown = AsyncMock()
    secured = AsyncMock()
    secured.stop = AsyncMock()

    session = SecureOpenAISandboxSession(inner_session=inner, secured_sandbox=secured)

    await session.stop()
    await session.shutdown()

    secured.stop.assert_awaited_once()
    inner.stop.assert_awaited_once()
    inner.shutdown.assert_awaited_once()
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```bash
uv run pytest tests/test_openai_sandbox_bridge.py -q -k secure_openai_session
```

Expected: FAIL with missing `SecureOpenAISandboxSession` behavior.

- [ ] **Step 3: Implement secured session**

Extend `src/agentsh_secure_sandbox/openai_sandbox/bridge.py`:

```python
import shlex

from agents.sandbox.types import ExecResult as OpenAIExecResult
from agents.sandbox.types import ExposedPortEndpoint, User

from agentsh_secure_sandbox.core.types import SecuredSandbox


def _join_command(command: tuple[str | Path, ...]) -> str:
    return shlex.join(str(part) for part in command)


def _to_openai_exec_result(result: ExecResult) -> OpenAIExecResult:
    return OpenAIExecResult(
        stdout=result.stdout.encode(),
        stderr=result.stderr.encode(),
        exit_code=result.exit_code,
    )


class SecureOpenAISandboxSession(BaseSandboxSession):
    """OpenAI SDK sandbox session that routes model-facing IO through agentsh."""

    def __init__(
        self,
        *,
        inner_session: BaseSandboxSession,
        secured_sandbox: SecuredSandbox,
    ) -> None:
        self._inner_session = inner_session
        self._secured_sandbox = secured_sandbox
        self._secured_stopped = False

    @property
    def inner_session(self) -> BaseSandboxSession:
        return self._inner_session

    @property
    def state(self) -> Any:
        return self._inner_session.state

    @state.setter
    def state(self, value: Any) -> None:
        self._inner_session.state = value

    async def start(self) -> None:
        return

    async def _exec_internal(
        self,
        *command: str | Path,
        timeout: float | None = None,
    ) -> OpenAIExecResult:
        result = await self._secured_sandbox.exec(_join_command(command), timeout=timeout)
        return _to_openai_exec_result(result)

    async def read(self, path: Path, *, user: str | User | None = None) -> io.IOBase:
        _ = user
        result = await self._secured_sandbox.read_file(str(path))
        if not result.success:
            raise FileNotFoundError(result.error)
        return io.BytesIO(result.content.encode())

    async def write(
        self,
        path: Path,
        data: io.IOBase,
        *,
        user: str | User | None = None,
    ) -> None:
        _ = user
        payload = data.read()
        result = await self._secured_sandbox.write_file(str(path), payload)
        if not result.success:
            raise PermissionError(result.error)

    async def running(self) -> bool:
        return await self._inner_session.running()

    async def persist_workspace(self) -> io.IOBase:
        return await self._inner_session.persist_workspace()

    async def hydrate_workspace(self, data: io.IOBase) -> None:
        await self._inner_session.hydrate_workspace(data)

    async def _resolve_exposed_port(self, port: int) -> ExposedPortEndpoint:
        return await self._inner_session.resolve_exposed_port(port)

    def supports_pty(self) -> bool:
        return self._inner_session.supports_pty()

    async def pty_exec_start(self, *args: Any, **kwargs: Any) -> Any:
        return await self._inner_session.pty_exec_start(*args, **kwargs)

    async def pty_write_stdin(self, **kwargs: Any) -> Any:
        return await self._inner_session.pty_write_stdin(**kwargs)

    async def pty_terminate_all(self) -> None:
        await self._inner_session.pty_terminate_all()

    async def stop(self) -> None:
        await self._inner_session.stop()
        if not self._secured_stopped:
            self._secured_stopped = True
            await self._secured_sandbox.stop()

    async def shutdown(self) -> None:
        if not self._secured_stopped:
            self._secured_stopped = True
            await self._secured_sandbox.stop()
        await self._inner_session.shutdown()
```

Update `src/agentsh_secure_sandbox/openai_sandbox/__init__.py` to import the real class:

```python
from .bridge import SecureOpenAISandboxSession
```

Remove the temporary skeleton `SecureOpenAISandboxSession` class from `__init__.py`.

- [ ] **Step 4: Run test to verify it passes**

Run:

```bash
uv run pytest tests/test_openai_sandbox_bridge.py -q
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/agentsh_secure_sandbox/openai_sandbox/bridge.py src/agentsh_secure_sandbox/openai_sandbox/__init__.py tests/test_openai_sandbox_bridge.py
git commit -m "feat(openai): route sandbox session operations through agentsh"
```

---

### Task 4: Upstream Client Wrapper

**Files:**
- Create: `src/agentsh_secure_sandbox/openai_sandbox/wrappers.py`
- Modify: `src/agentsh_secure_sandbox/openai_sandbox/__init__.py`
- Test: `tests/test_openai_sandbox_wrappers.py`

- [ ] **Step 1: Write failing wrapper tests**

Create `tests/test_openai_sandbox_wrappers.py`:

```python
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

from agents.sandbox.session.sandbox_session import SandboxSession


async def test_secure_client_create_delegates_and_wraps(monkeypatch) -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession
    from agentsh_secure_sandbox.openai_sandbox.wrappers import SecureOpenAISandboxClient

    inner = AsyncMock()
    inner.state = MagicMock()
    inner.running = AsyncMock(return_value=True)
    upstream = AsyncMock()
    upstream.backend_id = "e2b"
    upstream.supports_default_options = True
    upstream.create = AsyncMock(return_value=inner)

    secured = AsyncMock()
    secure_sandbox = AsyncMock(return_value=secured)
    monkeypatch.setattr(
        "agentsh_secure_sandbox.openai_sandbox.wrappers.secure_sandbox",
        secure_sandbox,
    )

    client = SecureOpenAISandboxClient(upstream_client=upstream)
    session = await client.create(snapshot=None, manifest=None, options=None)

    assert isinstance(session, SandboxSession)
    assert isinstance(session._inner, SecureOpenAISandboxSession)
    upstream.create.assert_awaited_once_with(snapshot=None, manifest=None, options=None)
    secure_sandbox.assert_awaited_once()


async def test_secure_client_resume_delegates_and_wraps(monkeypatch) -> None:
    from agentsh_secure_sandbox.openai_sandbox.wrappers import SecureOpenAISandboxClient

    state = MagicMock()
    inner = AsyncMock()
    inner.state = state
    upstream = AsyncMock()
    upstream.backend_id = "modal"
    upstream.supports_default_options = False
    upstream.resume = AsyncMock(return_value=inner)

    monkeypatch.setattr(
        "agentsh_secure_sandbox.openai_sandbox.wrappers.secure_sandbox",
        AsyncMock(return_value=AsyncMock()),
    )

    client = SecureOpenAISandboxClient(upstream_client=upstream)
    session = await client.resume(state)

    assert isinstance(session, SandboxSession)
    upstream.resume.assert_awaited_once_with(state)


async def test_secure_client_delete_unwraps_secure_session() -> None:
    from agentsh_secure_sandbox.openai_sandbox.bridge import SecureOpenAISandboxSession
    from agentsh_secure_sandbox.openai_sandbox.wrappers import SecureOpenAISandboxClient

    upstream_inner = AsyncMock()
    upstream_inner.state = MagicMock()
    secured = AsyncMock()
    secure_inner = SecureOpenAISandboxSession(
        inner_session=upstream_inner,
        secured_sandbox=secured,
    )

    upstream = AsyncMock()
    upstream.backend_id = "runloop"
    upstream.supports_default_options = True
    upstream.delete = AsyncMock(return_value=upstream_inner)

    client = SecureOpenAISandboxClient(upstream_client=upstream)
    wrapped_session = client._wrap_session(secure_inner)
    returned = await client.delete(wrapped_session)

    assert returned is wrapped_session
    secured.stop.assert_awaited_once()
    upstream.delete.assert_awaited_once_with(upstream_inner)


def test_secure_client_serialization_delegates() -> None:
    from agentsh_secure_sandbox.openai_sandbox.wrappers import SecureOpenAISandboxClient

    state = MagicMock()
    upstream = MagicMock()
    upstream.backend_id = "vercel"
    upstream.supports_default_options = True
    upstream.serialize_session_state.return_value = {"type": "vercel", "sandbox_id": "abc"}
    upstream.deserialize_session_state.return_value = state

    client = SecureOpenAISandboxClient(upstream_client=upstream)

    assert client.serialize_session_state(state) == {"type": "vercel", "sandbox_id": "abc"}
    assert client.deserialize_session_state({"type": "vercel", "sandbox_id": "abc"}) is state
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```bash
uv run pytest tests/test_openai_sandbox_wrappers.py -q
```

Expected: FAIL with missing `wrappers.py` or the temporary skeleton class lacking wrapper behavior.

- [ ] **Step 3: Implement wrapper**

Create `src/agentsh_secure_sandbox/openai_sandbox/wrappers.py`:

```python
from __future__ import annotations

from typing import Any

from agents.sandbox.manifest import Manifest
from agents.sandbox.session.base_sandbox_session import BaseSandboxSession
from agents.sandbox.session.sandbox_client import BaseSandboxClient
from agents.sandbox.session.sandbox_session import SandboxSession
from agents.sandbox.session.sandbox_session_state import SandboxSessionState
from agents.sandbox.snapshot import SnapshotBase, SnapshotSpec

from agentsh_secure_sandbox import secure_sandbox
from agentsh_secure_sandbox.core.types import SecureConfig

from .bridge import _OpenAISessionAdapter, SecureOpenAISandboxSession


class SecureOpenAISandboxClient(BaseSandboxClient[Any]):
    """Wrap an upstream OpenAI sandbox client and secure model-facing operations."""

    def __init__(
        self,
        *,
        upstream_client: BaseSandboxClient[Any],
        config: SecureConfig | None = None,
    ) -> None:
        self._upstream_client = upstream_client
        self._config = config or SecureConfig()
        self.backend_id = f"agentsh-secure:{upstream_client.backend_id}"
        self.supports_default_options = upstream_client.supports_default_options

    @property
    def upstream_client(self) -> BaseSandboxClient[Any]:
        return self._upstream_client

    async def _secure_session(self, inner: BaseSandboxSession) -> SandboxSession:
        adapter = _OpenAISessionAdapter(inner)
        secured = await secure_sandbox(adapter, self._config)
        secure_inner = SecureOpenAISandboxSession(
            inner_session=inner,
            secured_sandbox=secured,
        )
        return self._wrap_session(secure_inner)

    async def create(
        self,
        *,
        snapshot: SnapshotSpec | SnapshotBase | None = None,
        manifest: Manifest | None = None,
        options: Any,
    ) -> SandboxSession:
        inner = await self._upstream_client.create(
            snapshot=snapshot,
            manifest=manifest,
            options=options,
        )
        return await self._secure_session(inner)

    async def resume(self, state: SandboxSessionState) -> SandboxSession:
        inner = await self._upstream_client.resume(state)
        return await self._secure_session(inner)

    async def delete(self, session: SandboxSession) -> SandboxSession:
        inner = getattr(session, "_inner", session)
        if isinstance(inner, SecureOpenAISandboxSession):
            await inner.shutdown()
            await self._upstream_client.delete(inner.inner_session)  # type: ignore[arg-type]
            return session
        await self._upstream_client.delete(session)
        return session

    def serialize_session_state(self, state: SandboxSessionState) -> dict[str, object]:
        return self._upstream_client.serialize_session_state(state)

    def deserialize_session_state(self, payload: dict[str, object]) -> SandboxSessionState:
        return self._upstream_client.deserialize_session_state(payload)
```

Update `src/agentsh_secure_sandbox/openai_sandbox/__init__.py`:

```python
from .wrappers import SecureOpenAISandboxClient
```

Remove the temporary skeleton `SecureOpenAISandboxClient` class.

- [ ] **Step 4: Run test to verify it passes**

Run:

```bash
uv run pytest tests/test_openai_sandbox_wrappers.py -q
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/agentsh_secure_sandbox/openai_sandbox/wrappers.py src/agentsh_secure_sandbox/openai_sandbox/__init__.py tests/test_openai_sandbox_wrappers.py
git commit -m "feat(openai): wrap upstream sandbox clients with agentsh"
```

---

### Task 5: Shared Custom Provider Session Base

**Files:**
- Modify: `src/agentsh_secure_sandbox/openai_sandbox/unsupported.py`
- Test: `tests/test_openai_sandbox_unsupported.py`

- [ ] **Step 1: Write failing custom session tests**

Create `tests/test_openai_sandbox_unsupported.py`:

```python
from __future__ import annotations

import io
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

from agents.sandbox.manifest import Manifest
from agents.sandbox.snapshot import NoopSnapshot


async def test_secured_adapter_session_exec_read_write() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        UnsupportedProviderSessionState,
        _SecuredAdapterSession,
    )

    state = UnsupportedProviderSessionState(
        provider="unit",
        manifest=Manifest(root="/workspace"),
        snapshot=NoopSnapshot(),
    )
    secured = AsyncMock()
    secured.exec = AsyncMock(return_value=MagicMock(stdout="ok", stderr="", exit_code=0))
    secured.write_file = AsyncMock(return_value=MagicMock(success=True, path="/workspace/a.txt"))
    secured.read_file = AsyncMock(
        return_value=MagicMock(success=True, path="/workspace/a.txt", content="payload")
    )

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)

    exec_result = await session.exec("echo", "ok", shell=False)
    await session.write(Path("/workspace/a.txt"), io.BytesIO(b"payload"))
    read_result = await session.read(Path("/workspace/a.txt"))

    assert exec_result.stdout == b"ok"
    assert read_result.read() == b"payload"
    secured.exec.assert_awaited_once_with("echo ok", timeout=None)


async def test_secured_adapter_session_persist_and_hydrate_workspace() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        UnsupportedProviderSessionState,
        _SecuredAdapterSession,
    )

    state = UnsupportedProviderSessionState(
        provider="unit",
        manifest=Manifest(root="/workspace"),
        snapshot=NoopSnapshot(),
    )
    secured = AsyncMock()
    secured.exec = AsyncMock(return_value=MagicMock(stdout="", stderr="", exit_code=0))

    session = _SecuredAdapterSession(state=state, secured_sandbox=secured)
    archive = await session.persist_workspace()
    await session.hydrate_workspace(io.BytesIO(b"tar-bytes"))

    assert archive.read() == b""
    assert secured.exec.await_count == 2
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```bash
uv run pytest tests/test_openai_sandbox_unsupported.py -q -k secured_adapter_session
```

Expected: FAIL with missing `unsupported.py`.

- [ ] **Step 3: Implement shared state and session**

Create `src/agentsh_secure_sandbox/openai_sandbox/unsupported.py`:

```python
from __future__ import annotations

import io
import shlex
from pathlib import Path
from typing import Any, Literal

from agents.sandbox.manifest import Manifest
from agents.sandbox.session.base_sandbox_session import BaseSandboxSession
from agents.sandbox.session.sandbox_client import BaseSandboxClient, BaseSandboxClientOptions
from agents.sandbox.session.sandbox_session import SandboxSession
from agents.sandbox.session.sandbox_session_state import SandboxSessionState
from agents.sandbox.snapshot import NoopSnapshot, SnapshotBase, SnapshotSpec, resolve_snapshot
from agents.sandbox.types import ExecResult as OpenAIExecResult
from agents.sandbox.types import ExposedPortEndpoint, User

from agentsh_secure_sandbox import secure_sandbox
from agentsh_secure_sandbox.core.types import SandboxAdapter, SecuredSandbox, SecureConfig

from .bridge import _to_openai_exec_result, _join_command


class UnsupportedProviderSessionState(SandboxSessionState):
    type: Literal["agentsh_secure_provider"] = "agentsh_secure_provider"
    provider: str
    handle: str | None = None


class UnsupportedProviderClientOptions(BaseSandboxClientOptions):
    type: Literal["agentsh_secure_provider"] = "agentsh_secure_provider"
    handle: str | None = None

    def __init__(
        self,
        handle: str | None = None,
        *,
        type: Literal["agentsh_secure_provider"] = "agentsh_secure_provider",
    ) -> None:
        super().__init__(type=type, handle=handle)


class _SecuredAdapterSession(BaseSandboxSession):
    def __init__(
        self,
        *,
        state: UnsupportedProviderSessionState,
        secured_sandbox: SecuredSandbox,
    ) -> None:
        self.state = state
        self._secured_sandbox = secured_sandbox
        self._running = True

    async def _exec_internal(
        self,
        *command: str | Path,
        timeout: float | None = None,
    ) -> OpenAIExecResult:
        result = await self._secured_sandbox.exec(_join_command(command), timeout=timeout)
        return _to_openai_exec_result(result)

    async def read(self, path: Path, *, user: str | User | None = None) -> io.IOBase:
        _ = user
        result = await self._secured_sandbox.read_file(str(path))
        if not result.success:
            raise FileNotFoundError(result.error)
        return io.BytesIO(result.content.encode())

    async def write(
        self,
        path: Path,
        data: io.IOBase,
        *,
        user: str | User | None = None,
    ) -> None:
        _ = user
        payload = data.read()
        result = await self._secured_sandbox.write_file(str(path), payload)
        if not result.success:
            raise PermissionError(result.error)

    async def running(self) -> bool:
        return self._running

    async def persist_workspace(self) -> io.IOBase:
        root = shlex.quote(self.state.manifest.root)
        result = await self._secured_sandbox.exec(
            f"tar -C {root} -cf - . 2>/dev/null | base64 -w0"
        )
        if result.exit_code != 0 or not result.stdout:
            return io.BytesIO(b"")
        import base64

        return io.BytesIO(base64.b64decode(result.stdout.encode()))

    async def hydrate_workspace(self, data: io.IOBase) -> None:
        import base64

        payload = base64.b64encode(data.read()).decode("ascii")
        root = shlex.quote(self.state.manifest.root)
        await self._secured_sandbox.exec(
            f"mkdir -p {root} && printf %s {shlex.quote(payload)} | base64 -d | tar -C {root} -xf -"
        )

    async def _resolve_exposed_port(self, port: int) -> ExposedPortEndpoint:
        raise NotImplementedError(f"exposed ports are not supported for {self.state.provider}")

    async def shutdown(self) -> None:
        self._running = False
        await self._secured_sandbox.stop()
```

- [ ] **Step 4: Run test to verify it passes**

Run:

```bash
uv run pytest tests/test_openai_sandbox_unsupported.py -q -k secured_adapter_session
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/agentsh_secure_sandbox/openai_sandbox/unsupported.py tests/test_openai_sandbox_unsupported.py
git commit -m "feat(openai): add secured session base for custom providers"
```

---

### Task 6: Sprites OpenAI-Compatible Client

**Files:**
- Modify: `src/agentsh_secure_sandbox/openai_sandbox/unsupported.py`
- Modify: `src/agentsh_secure_sandbox/openai_sandbox/__init__.py`
- Test: `tests/test_openai_sandbox_unsupported.py`

- [ ] **Step 1: Write failing Sprites client tests**

Append to `tests/test_openai_sandbox_unsupported.py`:

```python
async def test_sprites_client_creates_secured_session(monkeypatch) -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import SpritesSandboxClient

    sprite = MagicMock()
    secured = AsyncMock()
    secure = AsyncMock(return_value=secured)
    monkeypatch.setattr(
        "agentsh_secure_sandbox.openai_sandbox.unsupported.secure_sandbox",
        secure,
    )

    client = SpritesSandboxClient(sprite=sprite)
    session = await client.create(snapshot=None, manifest=Manifest(root="/home/sprite"), options=None)

    assert session.state.provider == "sprites"
    assert session.state.manifest.root == "/home/sprite"
    secure.assert_awaited_once()


def test_sprites_client_requires_sprite_or_factory() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import SpritesSandboxClient

    try:
        SpritesSandboxClient()
    except ValueError as exc:
        assert "sprite" in str(exc)
    else:
        raise AssertionError("SpritesSandboxClient should require sprite or sprite_factory")
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```bash
uv run pytest tests/test_openai_sandbox_unsupported.py -q -k sprites_client
```

Expected: FAIL with missing `SpritesSandboxClient` behavior.

- [ ] **Step 3: Implement Sprites client**

Append to `unsupported.py`:

```python
from collections.abc import Callable

from agentsh_secure_sandbox.adapters import sprites, sprites_defaults


class SpritesSandboxClient(BaseSandboxClient[UnsupportedProviderClientOptions | None]):
    backend_id = "agentsh-secure:sprites"
    supports_default_options = True

    def __init__(
        self,
        *,
        sprite: Any | None = None,
        sprite_factory: Callable[[], Any] | None = None,
        config: SecureConfig | None = None,
    ) -> None:
        if sprite is None and sprite_factory is None:
            raise ValueError("SpritesSandboxClient requires sprite or sprite_factory")
        self._sprite = sprite
        self._sprite_factory = sprite_factory
        self._config = config or sprites_defaults()

    def _resolve_sprite(self) -> Any:
        if self._sprite is not None:
            return self._sprite
        assert self._sprite_factory is not None
        return self._sprite_factory()

    async def create(
        self,
        *,
        snapshot: SnapshotSpec | SnapshotBase | None = None,
        manifest: Manifest | None = None,
        options: UnsupportedProviderClientOptions | None,
    ) -> SandboxSession:
        _ = options
        resolved_snapshot = resolve_snapshot(snapshot) if snapshot is not None else NoopSnapshot()
        effective_manifest = manifest or Manifest(root=self._config.workspace or "/home/sprite")
        state = UnsupportedProviderSessionState(
            provider="sprites",
            handle=None,
            snapshot=resolved_snapshot,
            manifest=effective_manifest,
        )
        adapter = sprites(self._resolve_sprite())
        secured = await secure_sandbox(adapter, self._config)
        return self._wrap_session(_SecuredAdapterSession(state=state, secured_sandbox=secured))

    async def resume(self, state: SandboxSessionState) -> SandboxSession:
        parsed = UnsupportedProviderSessionState.model_validate(state.model_dump())
        adapter = sprites(self._resolve_sprite())
        secured = await secure_sandbox(adapter, self._config)
        return self._wrap_session(_SecuredAdapterSession(state=parsed, secured_sandbox=secured))

    async def delete(self, session: SandboxSession) -> SandboxSession:
        await session.shutdown()
        return session

    def deserialize_session_state(self, payload: dict[str, object]) -> SandboxSessionState:
        return UnsupportedProviderSessionState.model_validate(payload)
```

Update `__init__.py`:

```python
from .unsupported import SpritesSandboxClient
```

Remove the temporary skeleton `SpritesSandboxClient` class.

- [ ] **Step 4: Run test to verify it passes**

Run:

```bash
uv run pytest tests/test_openai_sandbox_unsupported.py -q -k sprites_client
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/agentsh_secure_sandbox/openai_sandbox/unsupported.py src/agentsh_secure_sandbox/openai_sandbox/__init__.py tests/test_openai_sandbox_unsupported.py
git commit -m "feat(openai): add Sprites sandbox client"
```

---

### Task 7: exe.dev OpenAI-Compatible Client

**Files:**
- Modify: `src/agentsh_secure_sandbox/openai_sandbox/unsupported.py`
- Modify: `src/agentsh_secure_sandbox/openai_sandbox/__init__.py`
- Test: `tests/test_openai_sandbox_unsupported.py`

- [ ] **Step 1: Write failing exe.dev client tests**

Append to `tests/test_openai_sandbox_unsupported.py`:

```python
async def test_exe_client_creates_secured_session(monkeypatch) -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import ExeSandboxClient

    secured = AsyncMock()
    secure = AsyncMock(return_value=secured)
    monkeypatch.setattr(
        "agentsh_secure_sandbox.openai_sandbox.unsupported.secure_sandbox",
        secure,
    )

    client = ExeSandboxClient(vm_name="unit-vm")
    session = await client.create(snapshot=None, manifest=Manifest(root="/workspace"), options=None)

    assert session.state.provider == "exe"
    assert session.state.handle == "unit-vm"
    secure.assert_awaited_once()


def test_exe_client_requires_vm_name() -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import ExeSandboxClient

    try:
        ExeSandboxClient(vm_name="")
    except ValueError as exc:
        assert "vm_name" in str(exc)
    else:
        raise AssertionError("ExeSandboxClient should require vm_name")
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```bash
uv run pytest tests/test_openai_sandbox_unsupported.py -q -k exe_client
```

Expected: FAIL with missing `ExeSandboxClient` behavior.

- [ ] **Step 3: Implement exe.dev client**

Append to `unsupported.py`:

```python
from agentsh_secure_sandbox.adapters import exe, exe_defaults


class ExeSandboxClient(BaseSandboxClient[UnsupportedProviderClientOptions | None]):
    backend_id = "agentsh-secure:exe"
    supports_default_options = True

    def __init__(
        self,
        *,
        vm_name: str,
        config: SecureConfig | None = None,
    ) -> None:
        if not vm_name:
            raise ValueError("ExeSandboxClient requires vm_name")
        self._vm_name = vm_name
        self._config = config or exe_defaults()

    async def create(
        self,
        *,
        snapshot: SnapshotSpec | SnapshotBase | None = None,
        manifest: Manifest | None = None,
        options: UnsupportedProviderClientOptions | None,
    ) -> SandboxSession:
        _ = options
        resolved_snapshot = resolve_snapshot(snapshot) if snapshot is not None else NoopSnapshot()
        effective_manifest = manifest or Manifest(root=self._config.workspace or "/workspace")
        state = UnsupportedProviderSessionState(
            provider="exe",
            handle=self._vm_name,
            snapshot=resolved_snapshot,
            manifest=effective_manifest,
        )
        secured = await secure_sandbox(exe(self._vm_name), self._config)
        return self._wrap_session(_SecuredAdapterSession(state=state, secured_sandbox=secured))

    async def resume(self, state: SandboxSessionState) -> SandboxSession:
        parsed = UnsupportedProviderSessionState.model_validate(state.model_dump())
        handle = parsed.handle or self._vm_name
        secured = await secure_sandbox(exe(handle), self._config)
        return self._wrap_session(_SecuredAdapterSession(state=parsed, secured_sandbox=secured))

    async def delete(self, session: SandboxSession) -> SandboxSession:
        await session.shutdown()
        return session

    def deserialize_session_state(self, payload: dict[str, object]) -> SandboxSessionState:
        return UnsupportedProviderSessionState.model_validate(payload)
```

Update `__init__.py`:

```python
from .unsupported import ExeSandboxClient
```

Remove the temporary skeleton `ExeSandboxClient` class.

- [ ] **Step 4: Run test to verify it passes**

Run:

```bash
uv run pytest tests/test_openai_sandbox_unsupported.py -q -k exe_client
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/agentsh_secure_sandbox/openai_sandbox/unsupported.py src/agentsh_secure_sandbox/openai_sandbox/__init__.py tests/test_openai_sandbox_unsupported.py
git commit -m "feat(openai): add exe.dev sandbox client"
```

---

### Task 8: Freestyle OpenAI-Compatible Client

**Files:**
- Modify: `src/agentsh_secure_sandbox/openai_sandbox/unsupported.py`
- Modify: `src/agentsh_secure_sandbox/openai_sandbox/__init__.py`
- Test: `tests/test_openai_sandbox_unsupported.py`

- [ ] **Step 1: Write failing Freestyle client tests**

Append to `tests/test_openai_sandbox_unsupported.py`:

```python
async def test_freestyle_client_creates_vm_and_secured_session(monkeypatch) -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import FreestyleSandboxClient

    vm = AsyncMock()
    vm.id = "vm-unit"
    freestyle_client = AsyncMock()
    freestyle_client.create_sandbox_vm = AsyncMock(return_value=vm)

    secure = AsyncMock(return_value=AsyncMock())
    monkeypatch.setattr(
        "agentsh_secure_sandbox.openai_sandbox.unsupported.secure_sandbox",
        secure,
    )

    client = FreestyleSandboxClient(client=freestyle_client)
    session = await client.create(snapshot=None, manifest=Manifest(root="/workspace"), options=None)

    assert session.state.provider == "freestyle"
    assert session.state.handle == "vm-unit"
    freestyle_client.create_sandbox_vm.assert_awaited_once()
    secure.assert_awaited_once()


async def test_freestyle_client_resume_requires_vm_factory(monkeypatch) -> None:
    from agentsh_secure_sandbox.openai_sandbox.unsupported import (
        FreestyleSandboxClient,
        UnsupportedProviderSessionState,
    )

    state = UnsupportedProviderSessionState(
        provider="freestyle",
        handle="vm-1",
        manifest=Manifest(root="/workspace"),
        snapshot=NoopSnapshot(),
    )

    client = FreestyleSandboxClient(client=AsyncMock())

    try:
        await client.resume(state)
    except ValueError as exc:
        assert "vm_resolver" in str(exc)
    else:
        raise AssertionError("resume should require vm_resolver when handle exists")
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```bash
uv run pytest tests/test_openai_sandbox_unsupported.py -q -k freestyle_client
```

Expected: FAIL with missing `FreestyleSandboxClient` behavior.

- [ ] **Step 3: Implement Freestyle client**

Append to `unsupported.py`:

```python
from collections.abc import Awaitable

from agentsh_secure_sandbox.adapters.freestyle import (
    FreestyleClient,
    freestyle,
    freestyle_defaults,
)


class FreestyleSandboxClient(BaseSandboxClient[UnsupportedProviderClientOptions | None]):
    backend_id = "agentsh-secure:freestyle"
    supports_default_options = True

    def __init__(
        self,
        *,
        client: Any | None = None,
        vm_resolver: Callable[[str], Awaitable[Any]] | None = None,
        config: SecureConfig | None = None,
    ) -> None:
        self._client = client
        self._vm_resolver = vm_resolver
        self._config = config or freestyle_defaults()

    async def _resolve_client(self) -> Any:
        if self._client is not None:
            return self._client
        self._client = FreestyleClient()
        return self._client

    async def create(
        self,
        *,
        snapshot: SnapshotSpec | SnapshotBase | None = None,
        manifest: Manifest | None = None,
        options: UnsupportedProviderClientOptions | None,
    ) -> SandboxSession:
        _ = options
        client = await self._resolve_client()
        vm = await client.create_sandbox_vm()
        handle = str(getattr(vm, "id", "") or getattr(vm, "vm_id", "") or id(vm))
        resolved_snapshot = resolve_snapshot(snapshot) if snapshot is not None else NoopSnapshot()
        effective_manifest = manifest or Manifest(root=self._config.workspace or "/workspace")
        state = UnsupportedProviderSessionState(
            provider="freestyle",
            handle=handle,
            snapshot=resolved_snapshot,
            manifest=effective_manifest,
        )
        secured = await secure_sandbox(freestyle(vm), self._config)
        return self._wrap_session(_SecuredAdapterSession(state=state, secured_sandbox=secured))

    async def resume(self, state: SandboxSessionState) -> SandboxSession:
        parsed = UnsupportedProviderSessionState.model_validate(state.model_dump())
        if not parsed.handle or self._vm_resolver is None:
            raise ValueError("FreestyleSandboxClient.resume requires state.handle and vm_resolver")
        vm = await self._vm_resolver(parsed.handle)
        secured = await secure_sandbox(freestyle(vm), self._config)
        return self._wrap_session(_SecuredAdapterSession(state=parsed, secured_sandbox=secured))

    async def delete(self, session: SandboxSession) -> SandboxSession:
        await session.shutdown()
        return session

    def deserialize_session_state(self, payload: dict[str, object]) -> SandboxSessionState:
        return UnsupportedProviderSessionState.model_validate(payload)
```

Update `__init__.py`:

```python
from .unsupported import FreestyleSandboxClient
```

Remove the temporary skeleton `FreestyleSandboxClient` class.

- [ ] **Step 4: Run test to verify it passes**

Run:

```bash
uv run pytest tests/test_openai_sandbox_unsupported.py -q -k freestyle_client
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/agentsh_secure_sandbox/openai_sandbox/unsupported.py src/agentsh_secure_sandbox/openai_sandbox/__init__.py tests/test_openai_sandbox_unsupported.py
git commit -m "feat(openai): add Freestyle sandbox client"
```

---

### Task 9: Provider Factory

**Files:**
- Create: `src/agentsh_secure_sandbox/openai_sandbox/providers.py`
- Modify: `src/agentsh_secure_sandbox/openai_sandbox/__init__.py`
- Test: `tests/test_openai_sandbox_wrappers.py`

- [ ] **Step 1: Write failing factory tests**

Append to `tests/test_openai_sandbox_wrappers.py`:

```python
def test_factory_wraps_upstream_provider_client() -> None:
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient
    from agentsh_secure_sandbox.openai_sandbox.providers import secure_openai_sandbox_client

    upstream = MagicMock()
    upstream.backend_id = "e2b"
    upstream.supports_default_options = True

    client = secure_openai_sandbox_client(provider="e2b", upstream_client=upstream)

    assert isinstance(client, SecureOpenAISandboxClient)
    assert client.upstream_client is upstream


def test_factory_rejects_upstream_provider_without_client() -> None:
    from agentsh_secure_sandbox.openai_sandbox.providers import secure_openai_sandbox_client

    try:
        secure_openai_sandbox_client(provider="e2b")
    except ValueError as exc:
        assert "upstream_client" in str(exc)
    else:
        raise AssertionError("factory should require upstream_client for upstream providers")


def test_factory_constructs_custom_exe_client() -> None:
    from agentsh_secure_sandbox.openai_sandbox import ExeSandboxClient
    from agentsh_secure_sandbox.openai_sandbox.providers import secure_openai_sandbox_client

    client = secure_openai_sandbox_client(provider="exe", vm_name="vm-1")

    assert isinstance(client, ExeSandboxClient)


def test_factory_rejects_unknown_provider() -> None:
    from agentsh_secure_sandbox.openai_sandbox.providers import secure_openai_sandbox_client

    try:
        secure_openai_sandbox_client(provider="unknown")
    except ValueError as exc:
        assert "unknown provider" in str(exc)
    else:
        raise AssertionError("factory should reject unknown provider")
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```bash
uv run pytest tests/test_openai_sandbox_wrappers.py -q -k factory
```

Expected: FAIL with missing `providers.py` or the temporary skeleton factory lacking provider behavior.

- [ ] **Step 3: Implement factory**

Create `src/agentsh_secure_sandbox/openai_sandbox/providers.py`:

```python
from __future__ import annotations

from typing import Any, Literal

from agents.sandbox.session.sandbox_client import BaseSandboxClient

from agentsh_secure_sandbox.core.types import SecureConfig

from .unsupported import ExeSandboxClient, FreestyleSandboxClient, SpritesSandboxClient
from .wrappers import SecureOpenAISandboxClient

OpenAISandboxProvider = Literal[
    "blaxel",
    "cloudflare",
    "daytona",
    "e2b",
    "modal",
    "runloop",
    "vercel",
    "sprites",
    "exe",
    "freestyle",
]

_UPSTREAM_PROVIDERS = {
    "blaxel",
    "cloudflare",
    "daytona",
    "e2b",
    "modal",
    "runloop",
    "vercel",
}


def secure_openai_sandbox_client(
    *,
    provider: str,
    upstream_client: BaseSandboxClient[Any] | None = None,
    config: SecureConfig | None = None,
    **kwargs: Any,
) -> BaseSandboxClient[Any]:
    if provider in _UPSTREAM_PROVIDERS:
        if upstream_client is None:
            raise ValueError(f"provider {provider!r} requires upstream_client")
        return SecureOpenAISandboxClient(upstream_client=upstream_client, config=config)

    if provider == "sprites":
        return SpritesSandboxClient(config=config, **kwargs)

    if provider == "exe":
        return ExeSandboxClient(config=config, **kwargs)

    if provider == "freestyle":
        return FreestyleSandboxClient(config=config, **kwargs)

    available = sorted([*_UPSTREAM_PROVIDERS, "sprites", "exe", "freestyle"])
    raise ValueError(f"unknown provider {provider!r}; available providers: {', '.join(available)}")
```

Update `__init__.py`:

```python
from .providers import secure_openai_sandbox_client
```

Remove the temporary skeleton `secure_openai_sandbox_client`.

- [ ] **Step 4: Run test to verify it passes**

Run:

```bash
uv run pytest tests/test_openai_sandbox_wrappers.py -q -k factory
```

Expected: PASS.

- [ ] **Step 5: Run public API tests**

Run:

```bash
uv run pytest tests/test_openai_sandbox_public_api.py tests/test_openai_sandbox_wrappers.py tests/test_openai_sandbox_unsupported.py tests/test_openai_sandbox_bridge.py -q
```

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add src/agentsh_secure_sandbox/openai_sandbox/providers.py src/agentsh_secure_sandbox/openai_sandbox/__init__.py tests/test_openai_sandbox_wrappers.py
git commit -m "feat(openai): add sandbox client provider factory"
```

---

### Task 10: E2E Environment Loading

**Files:**
- Modify: `tests/e2e/conftest.py`
- Modify: `pyproject.toml`
- Test: `tests/test_openai_sandbox_public_api.py`

- [ ] **Step 1: Write failing env loader test**

Append to `tests/test_openai_sandbox_public_api.py`:

```python
def test_e2e_env_files_loader_loads_explicit_files(tmp_path, monkeypatch) -> None:
    from tests.e2e.conftest import load_additional_e2e_env_files

    env_file = tmp_path / ".env.other"
    env_file.write_text("OPENAI_API_KEY=sk-test\nCUSTOM_PROVIDER_KEY=value\n")

    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("CUSTOM_PROVIDER_KEY", raising=False)
    monkeypatch.setenv("AGENTSH_E2E_ENV_FILES", str(env_file))

    loaded = load_additional_e2e_env_files()

    assert loaded == [str(env_file)]
    assert __import__("os").environ["OPENAI_API_KEY"] == "sk-test"
    assert __import__("os").environ["CUSTOM_PROVIDER_KEY"] == "value"
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```bash
uv run pytest tests/test_openai_sandbox_public_api.py -q -k e2e_env_files_loader
```

Expected: FAIL with missing `load_additional_e2e_env_files`.

- [ ] **Step 3: Implement env loader and marker**

Modify `tests/e2e/conftest.py` immediately after `load_dotenv(Path(__file__).resolve().parents[2] / ".env")`:

```python
def load_additional_e2e_env_files() -> list[str]:
    raw = os.environ.get("AGENTSH_E2E_ENV_FILES", "")
    loaded: list[str] = []
    for item in raw.split(os.pathsep):
        path = item.strip()
        if not path:
            continue
        candidate = Path(path).expanduser()
        if candidate.is_file():
            load_dotenv(candidate, override=False)
            loaded.append(str(candidate))
    return loaded


load_additional_e2e_env_files()
```

Add `OPENAI_API_KEY` to `ENV`:

```python
"OPENAI_API_KEY": os.environ.get("OPENAI_API_KEY", ""),
```

Add a marker helper:

```python
skip_no_openai_api_key = pytest.mark.skipif(
    not ENV["OPENAI_API_KEY"],
    reason="OPENAI_API_KEY missing",
)
```

Modify `pyproject.toml` markers:

```toml
"openai_agent_e2e: model-driven OpenAI SandboxAgent tests against real providers",
```

- [ ] **Step 4: Run test to verify it passes**

Run:

```bash
uv run pytest tests/test_openai_sandbox_public_api.py -q -k e2e_env_files_loader
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add tests/e2e/conftest.py pyproject.toml tests/test_openai_sandbox_public_api.py
git commit -m "test(e2e): load explicit OpenAI sandbox env files"
```

---

### Task 11: Provider-Session E2E Tests

**Files:**
- Create: `tests/e2e/test_openai_sandbox_sessions.py`

- [ ] **Step 1: Add provider-session e2e tests**

Create `tests/e2e/test_openai_sandbox_sessions.py`:

```python
from __future__ import annotations

import io
import time
from pathlib import Path
from typing import Any

import pytest

from agents.sandbox import Manifest

from tests.e2e.conftest import (
    ENV,
    skip_no_blaxel,
    skip_no_cloudflare,
    skip_no_daytona,
    skip_no_e2b,
    skip_no_exe,
    skip_no_freestyle,
    skip_no_modal,
    skip_no_runloop,
    skip_no_sprites,
    skip_no_vercel,
)

pytestmark = [pytest.mark.e2e, pytest.mark.timeout(900), pytest.mark.asyncio]


async def _assert_session_baseline(session: Any, workspace_root: str) -> None:
    result = await session.exec("echo", "hello", shell=False)
    assert result.exit_code == 0
    assert result.stdout.decode().strip() == "hello"

    path = Path(workspace_root) / f"openai-session-{int(time.time() * 1000)}.txt"
    await session.write(path, io.BytesIO(b"session-roundtrip"))
    read = await session.read(path)
    assert read.read() == b"session-roundtrip"


@skip_no_e2b
async def test_openai_sandbox_session_e2b() -> None:
    from agents.extensions.sandbox.e2b import E2BSandboxClient
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=E2BSandboxClient())
    session = await client.create(snapshot=None, manifest=Manifest(root="/workspace"), options=None)
    try:
        await _assert_session_baseline(session, "/workspace")
    finally:
        await client.delete(session)


@skip_no_daytona
async def test_openai_sandbox_session_daytona() -> None:
    from agents.extensions.sandbox.daytona import DaytonaSandboxClient, DaytonaSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=DaytonaSandboxClient())
    options = DaytonaSandboxClientOptions()
    session = await client.create(snapshot=None, manifest=Manifest(root="/home/daytona/workspace"), options=options)
    try:
        await _assert_session_baseline(session, "/home/daytona/workspace")
    finally:
        await client.delete(session)


@skip_no_modal
async def test_openai_sandbox_session_modal() -> None:
    from agents.extensions.sandbox.modal import ModalSandboxClient, ModalSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=ModalSandboxClient())
    options = ModalSandboxClientOptions(app_name="agentsh-openai-e2e", timeout=900)
    session = await client.create(snapshot=None, manifest=Manifest(root="/workspace"), options=options)
    try:
        await _assert_session_baseline(session, "/workspace")
    finally:
        await client.delete(session)


@skip_no_runloop
async def test_openai_sandbox_session_runloop() -> None:
    from agents.extensions.sandbox.runloop import RunloopSandboxClient, RunloopSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=RunloopSandboxClient())
    options = RunloopSandboxClientOptions()
    session = await client.create(snapshot=None, manifest=Manifest(root="/home/user"), options=options)
    try:
        await _assert_session_baseline(session, "/home/user")
    finally:
        await client.delete(session)


@skip_no_vercel
async def test_openai_sandbox_session_vercel() -> None:
    from agents.extensions.sandbox.vercel import VercelSandboxClient, VercelSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=VercelSandboxClient())
    options = VercelSandboxClientOptions(
        project_id=ENV["VERCEL_PROJECT_ID"],
        team_id=ENV["VERCEL_TEAM_ID"],
    )
    session = await client.create(snapshot=None, manifest=Manifest(root="/vercel/sandbox"), options=options)
    try:
        await _assert_session_baseline(session, "/vercel/sandbox")
    finally:
        await client.delete(session)


@skip_no_cloudflare
async def test_openai_sandbox_session_cloudflare() -> None:
    from agents.extensions.sandbox.cloudflare import CloudflareSandboxClient, CloudflareSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=CloudflareSandboxClient())
    options = CloudflareSandboxClientOptions(
        worker_url=ENV["CLOUDFLARE_WORKER_URL"],
        api_key=ENV["CLOUDFLARE_API_TOKEN"],
    )
    session = await client.create(snapshot=None, manifest=Manifest(root="/workspace"), options=options)
    try:
        await _assert_session_baseline(session, "/workspace")
    finally:
        await client.delete(session)


@skip_no_blaxel
async def test_openai_sandbox_session_blaxel() -> None:
    from agents.extensions.sandbox.blaxel import BlaxelSandboxClient, BlaxelSandboxClientOptions
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=BlaxelSandboxClient())
    options = BlaxelSandboxClientOptions(name=f"agentsh-openai-{int(time.time())}")
    session = await client.create(snapshot=None, manifest=Manifest(root="/workspace"), options=options)
    try:
        await _assert_session_baseline(session, "/workspace")
    finally:
        await client.delete(session)


@skip_no_sprites
async def test_openai_sandbox_session_sprites() -> None:
    from sprites import SpritesClient
    from agentsh_secure_sandbox.openai_sandbox import SpritesSandboxClient

    token = ENV["SPRITES_TOKEN"]
    if not token and ENV["FLY_API_TOKEN"] and ENV["SPRITES_ORG"]:
        token = SpritesClient.create_token(ENV["FLY_API_TOKEN"], ENV["SPRITES_ORG"])
    sprite = SpritesClient(token).sprite(ENV["SPRITES_NAME"])
    client = SpritesSandboxClient(sprite=sprite)
    session = await client.create(snapshot=None, manifest=Manifest(root="/home/sprite"), options=None)
    try:
        await _assert_session_baseline(session, "/home/sprite")
    finally:
        await client.delete(session)


@skip_no_exe
async def test_openai_sandbox_session_exe() -> None:
    from agentsh_secure_sandbox.openai_sandbox import ExeSandboxClient

    client = ExeSandboxClient(vm_name=ENV["EXE_VM_NAME"])
    session = await client.create(snapshot=None, manifest=Manifest(root="/workspace"), options=None)
    try:
        await _assert_session_baseline(session, "/workspace")
    finally:
        await client.delete(session)


@skip_no_freestyle
async def test_openai_sandbox_session_freestyle() -> None:
    from agentsh_secure_sandbox.openai_sandbox import FreestyleSandboxClient

    client = FreestyleSandboxClient()
    session = await client.create(snapshot=None, manifest=Manifest(root="/workspace"), options=None)
    try:
        await _assert_session_baseline(session, "/workspace")
    finally:
        await client.delete(session)
```

- [ ] **Step 2: Run collection only**

Run:

```bash
uv run pytest tests/e2e/test_openai_sandbox_sessions.py --collect-only -q
```

Expected: collection succeeds and lists 10 tests.

- [ ] **Step 3: Run skipped local e2e command**

Run without forcing keys:

```bash
uv run pytest tests/e2e/test_openai_sandbox_sessions.py -q
```

Expected: tests either PASS for providers with configured credentials or SKIP with clear missing-key reasons.

- [ ] **Step 4: Commit**

```bash
git add tests/e2e/test_openai_sandbox_sessions.py
git commit -m "test(e2e): add OpenAI sandbox session coverage"
```

---

### Task 12: Model-Driven SandboxAgent E2E Tests

**Files:**
- Create: `tests/e2e/test_openai_sandbox_agents.py`

- [ ] **Step 1: Add model-driven e2e tests**

Create `tests/e2e/test_openai_sandbox_agents.py`:

```python
from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from agents import Runner
from agents.run import RunConfig
from agents.sandbox import Manifest, SandboxAgent, SandboxRunConfig

from tests.e2e.conftest import skip_no_e2b, skip_no_openai_api_key

pytestmark = [
    pytest.mark.e2e,
    pytest.mark.openai_agent_e2e,
    pytest.mark.timeout(900),
    pytest.mark.asyncio,
    skip_no_openai_api_key,
]


async def _run_minimal_agent_task(client: Any, workspace_root: str) -> None:
    agent = SandboxAgent(
        name="Secure sandbox smoke agent",
        model="gpt-5.4",
        instructions=(
            "Use the sandbox tools. Create a file named openai-agent-smoke.txt "
            "containing exactly agent-ok, then read it back and report done."
        ),
        default_manifest=Manifest(root=workspace_root),
    )

    session = await client.create(snapshot=None, manifest=Manifest(root=workspace_root), options=None)
    try:
        result = await Runner.run(
            agent,
            "Create openai-agent-smoke.txt containing exactly agent-ok.",
            run_config=RunConfig(
                sandbox=SandboxRunConfig(session=session),
                workflow_name="agentsh secure sandbox model e2e",
            ),
            max_turns=8,
        )
        assert result.final_output
        read = await session.read(Path(workspace_root) / "openai-agent-smoke.txt")
        assert read.read().decode().strip() == "agent-ok"
    finally:
        await client.delete(session)


@skip_no_e2b
async def test_openai_sandbox_agent_e2b_smoke() -> None:
    from agents.extensions.sandbox.e2b import E2BSandboxClient
    from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

    client = SecureOpenAISandboxClient(upstream_client=E2BSandboxClient())
    await _run_minimal_agent_task(client, "/workspace")
```

- [ ] **Step 2: Run collection only**

Run:

```bash
uv run pytest tests/e2e/test_openai_sandbox_agents.py --collect-only -q
```

Expected: collection succeeds and lists 1 test.

- [ ] **Step 3: Run gated model e2e command**

Run:

```bash
uv run pytest tests/e2e/test_openai_sandbox_agents.py -q
```

Expected: PASS when both `OPENAI_API_KEY` and `E2B_API_KEY` are configured, otherwise SKIP with clear missing-key reasons.

- [ ] **Step 4: Commit**

```bash
git add tests/e2e/test_openai_sandbox_agents.py
git commit -m "test(e2e): add model-driven OpenAI SandboxAgent smoke test"
```

---

### Task 13: README Documentation

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Add docs section**

Modify `README.md` after the existing "OpenAI Agents SDK" function-tool section:

```markdown
### OpenAI Agents SDK SandboxAgent

`agentsh-secure-sandbox` also supports the OpenAI Agents SDK beta
`SandboxAgent` runtime. This is separate from `SecureSandboxAgentTools`: the
tool integration exposes three function tools, while the sandbox integration
plugs into `RunConfig(sandbox=SandboxRunConfig(client=client))`.

For providers supported by OpenAI's SDK, wrap the upstream sandbox client:

```python
from agents import Runner
from agents.run import RunConfig
from agents.sandbox import SandboxAgent, SandboxRunConfig
from agents.extensions.sandbox.e2b import E2BSandboxClient
from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

agent = SandboxAgent(
    name="Secure coder",
    model="gpt-5.4",
    instructions="Work in the sandbox and verify changes.",
)

client = SecureOpenAISandboxClient(upstream_client=E2BSandboxClient())

result = await Runner.run(
    agent,
    "Create hello.txt containing hello, then read it back.",
    run_config=RunConfig(sandbox=SandboxRunConfig(client=client)),
)
```

For providers OpenAI does not expose as sandbox clients, use the custom clients:

```python
from agents.run import RunConfig
from agents.sandbox import SandboxRunConfig
from agentsh_secure_sandbox.openai_sandbox import FreestyleSandboxClient

client = FreestyleSandboxClient()
run_config = RunConfig(sandbox=SandboxRunConfig(client=client))
```

Provider support:

| Provider | SandboxAgent support |
| --- | --- |
| E2B, Daytona, Cloudflare, Vercel, Blaxel, Modal, Runloop | Wrap OpenAI SDK upstream client |
| Sprites, exe.dev, Freestyle | Native `agentsh-secure-sandbox` OpenAI-compatible client |

OpenAI marks sandbox agents as beta. Pin `openai-agents>=0.14.1` and expect
minor API adjustments as the SDK evolves.
```

Add an e2e section:

```markdown
#### OpenAI Sandbox E2E Tests

Provider-session tests run with:

```bash
uv run pytest tests/e2e/test_openai_sandbox_sessions.py -m e2e
```

Model-driven `SandboxAgent` tests are opt-in:

```bash
uv run pytest tests/e2e/test_openai_sandbox_agents.py -m openai_agent_e2e
```

The harness loads this repo's `.env`. To load additional explicit env files
without committing secrets:

```bash
AGENTSH_E2E_ENV_FILES=/path/to/other/.env uv run pytest tests/e2e/test_openai_sandbox_agents.py -m openai_agent_e2e
```

Missing keys skip tests with clear reasons. Secret values are never printed.
```

- [ ] **Step 2: Check README formatting**

Run:

```bash
python - <<'PY'
from pathlib import Path
text = Path("README.md").read_text()
assert "OpenAI Agents SDK SandboxAgent" in text
assert "AGENTSH_E2E_ENV_FILES" in text
PY
```

Expected: command exits 0.

- [ ] **Step 3: Commit**

```bash
git add README.md
git commit -m "docs: document OpenAI SandboxAgent integration"
```

---

### Task 14: Final Verification

**Files:**
- All files changed by previous tasks.

- [ ] **Step 1: Run focused unit tests**

Run:

```bash
uv run pytest \
  tests/test_openai_sandbox_public_api.py \
  tests/test_openai_sandbox_bridge.py \
  tests/test_openai_sandbox_wrappers.py \
  tests/test_openai_sandbox_unsupported.py \
  tests/test_toolset_openai_agents.py \
  -q
```

Expected: PASS.

- [ ] **Step 2: Run full non-e2e suite**

Run:

```bash
uv run pytest -q
```

Expected: PASS for the non-e2e suite.

- [ ] **Step 3: Run lint**

Run:

```bash
uv run ruff check .
```

Expected: `All checks passed!`

- [ ] **Step 4: Run e2e collection checks**

Run:

```bash
uv run pytest tests/e2e/test_openai_sandbox_sessions.py --collect-only -q
uv run pytest tests/e2e/test_openai_sandbox_agents.py --collect-only -q
```

Expected: collection succeeds for both files.

- [ ] **Step 5: Run key-gated e2e smoke tests**

Run:

```bash
uv run pytest tests/e2e/test_openai_sandbox_sessions.py -q
uv run pytest tests/e2e/test_openai_sandbox_agents.py -q
```

Expected: providers with configured keys PASS; providers without configured keys SKIP. Model-driven tests require `OPENAI_API_KEY` plus provider credentials.

- [ ] **Step 6: Check git diff**

Run:

```bash
git diff --check
git status --short
```

Expected: no whitespace errors. Status shows only intentional changes if final commits were not already made.

- [ ] **Step 7: Commit final verification fixes if needed**

If verification required fixes, commit them:

```bash
git add src/agentsh_secure_sandbox/openai_sandbox src/agentsh_secure_sandbox/__init__.py tests/test_openai_sandbox_public_api.py tests/test_openai_sandbox_bridge.py tests/test_openai_sandbox_wrappers.py tests/test_openai_sandbox_unsupported.py tests/e2e/conftest.py tests/e2e/test_openai_sandbox_sessions.py tests/e2e/test_openai_sandbox_agents.py pyproject.toml README.md
git commit -m "fix(openai): address sandbox adapter verification issues"
```

If no fixes were needed, do not create an empty commit.

---

## Self-Review Notes

- Spec coverage: Tasks cover public API, upstream wrapping, custom clients for Sprites/exe/Freestyle, provider-session e2e, model-driven e2e, env-file handling, and docs.
- Scope: The plan does not replace `SecureSandboxAgentTools` or refactor existing provider adapters.
- Type consistency: Client/session names match the approved spec and OpenAI SDK `0.14.1` interfaces.
- Known risk: Some upstream OpenAI provider option constructors may need small argument adjustments after first real e2e collection. Keep those adjustments scoped to tests or provider factory helpers.
