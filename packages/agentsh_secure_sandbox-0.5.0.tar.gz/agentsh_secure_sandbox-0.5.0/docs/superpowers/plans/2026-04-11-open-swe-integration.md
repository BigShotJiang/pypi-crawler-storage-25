# OpenSWE Secure-Sandbox Integration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship a worked example under `examples/open_swe/` that lets OpenSWE (LangChain's open-source coding agent built on `deepagents`) run inside any secure-sandbox-py-supported provider with full agentsh policy enforcement.

**Architecture:** A sync-to-async bridge class (`SecureSandboxBackend`) implements deepagents' `BaseSandbox` protocol on top of an async `SecuredSandbox`. Each backend owns a private asyncio event loop running on a daemon thread; sync methods dispatch onto the loop via `run_coroutine_threadsafe`. Five provider factories (Modal, Daytona, Runloop, E2B, Freestyle) produce ready-to-use backends via a uniform `make_backend(async_init)` helper. Users plug the backend into their open-swe fork by monkeypatching deepagents' sandbox lookup at process start.

**Tech Stack:** Python 3.11+, `asyncio`, `threading`, `agentsh-secure-sandbox` (this repo), `deepagents` (`BaseSandbox`, `ExecuteResponse`, `ReadResult`, etc.), provider SDKs (`modal`, `daytona-sdk`, `runloop-api-client`, `e2b`, `FreestyleClient` from this repo), pytest with `asyncio_mode=auto`.

---

## Prerequisites

Before starting Task 1, install the dev deps plus `deepagents`:

```bash
pip install -e '.[dev,modal,daytona,runloop,e2b]'
pip install deepagents
```

`deepagents` is required at import time by `bridge.py` (for the `BaseSandbox` base class). Tests gate on it via `pytest.importorskip`, so an environment without `deepagents` still runs the rest of the suite cleanly — but you cannot execute the OpenSWE bridge tests without it.

No changes to `pyproject.toml` are made by this plan. The example ships inside `examples/` as copy-paste files, not as an installable sub-package. Phase 2 (a standalone installable package) is out of scope.

---

## Critical Verified Facts (do not deviate)

This plan supersedes the spec's code samples. Several spec assumptions were corrected against real source during plan drafting. When in doubt, trust this plan over `docs/superpowers/specs/2026-04-11-open-swe-integration-design.md`.

### deepagents protocol

Verified from `deepagents/backends/protocol.py` and `deepagents/backends/sandbox.py` in the installed `deepagents==0.5.2` package:

- `BaseSandbox` lives in **`deepagents.backends.sandbox`**, NOT `deepagents.backends.protocol`. It extends `SandboxBackendProtocol` (which lives in `deepagents.backends.protocol`) and `ABC`. Subclasses must inherit from `BaseSandbox` (duck typing does not suffice).
- `BaseSandbox.__abstractmethods__ == {'download_files', 'execute', 'id', 'upload_files'}`. Subclasses MUST provide concrete definitions for all four:
  - `execute(command: str, *, timeout: int | None = None) -> ExecuteResponse` — `timeout` is **keyword-only** (note the `*,`)
  - `id` — a property returning `str`
  - `upload_files(files: list[tuple[str, bytes]]) -> list[FileUploadResponse]`
  - `download_files(paths: list[str]) -> list[FileDownloadResponse]`
- `BaseSandbox` provides concrete defaults for `read`, `write`, `edit`, `ls`, `glob`, `grep` that route through `execute()`. We **override** `read`, `write`, `edit` to go through secure-sandbox-py's typed file API. `ls`, `glob`, `grep` remain execute-based.
- Result types (all in `deepagents.backends.protocol`):
  - `ExecuteResponse` is `@dataclass` with `output: str`, `exit_code: int | None`, `truncated: bool = False`.
  - `ReadResult` is `@dataclass` with `error: str | None = None`, `file_data: FileData | None = None`.
  - `WriteResult` is `@dataclass(init=False)` with custom `__init__(error=None, path=None, files_update=<_Unset>)`. Always construct with kwargs: `WriteResult(path=...)` or `WriteResult(error=...)`.
  - `EditResult` is `@dataclass(init=False)` with `__init__(error=None, path=None, files_update=<_Unset>, occurrences=None)`.
  - `FileUploadResponse(path: str, error: FileOperationError | None = None)` — **`error` is `Literal["file_not_found", "permission_denied", "is_directory", "invalid_path"] | None`**, NOT a free-form string. We map secure-sandbox error strings to this literal in a helper.
  - `FileDownloadResponse(path: str, content: bytes | None = None, error: FileOperationError | None = None)` — same literal constraint on `error`.
- `FileData` is a `TypedDict` with required keys `content: str` and `encoding: str` ("utf-8" or "base64") plus optional `created_at`/`modified_at`. Construct with `{"content": ..., "encoding": "utf-8"}`.
- Errors on `ReadResult`/`WriteResult`/`EditResult` are free-form `error: str | None` — those pass through the secure-sandbox error message verbatim. **Only** `FileUploadResponse`/`FileDownloadResponse` use the restrictive `FileOperationError` literal.

### secure-sandbox-py API

Verified from `src/agentsh_secure_sandbox/core/types.py` and `src/agentsh_secure_sandbox/_api.py`:

- `from agentsh_secure_sandbox import secure_sandbox` — async. Signature:
  ```python
  async def secure_sandbox(
      adapter: SandboxAdapter,
      config: SecureConfig | None = None,
  ) -> SecuredSandbox
  ```
- `SecuredSandbox.exec(command: str, *, cwd: str | None = None, timeout: float | None = None) -> ExecResult` — takes a **single** command string. `ExecResult` is a frozen slotted dataclass: `(stdout: str, stderr: str, exit_code: int)`.
- `SecuredSandbox.write_file(path, content) -> WriteFileResult` where `WriteFileResult = WriteFileSuccess | WriteFileFailure`. Success carries `(success=True, path)`; failure carries `(success=False, path, error)`.
- `SecuredSandbox.read_file(path) -> ReadFileResult` where `ReadFileResult = ReadFileSuccess | ReadFileFailure`. Success carries `(success=True, path, content)`; failure carries `(success=False, path, error)`.
- `SecuredSandbox.stop()` is idempotent and tears down the provider VM/session via the adapter's own `.stop()`.

### Provider construction

Verified from `examples/*_pydantic_ai.py` and the adapter source files:

| Provider  | Client construction                                              | Sandbox creation                                                  | Defaults fn           | Adapter call                                         |
|-----------|------------------------------------------------------------------|-------------------------------------------------------------------|-----------------------|------------------------------------------------------|
| Modal     | `modal.App.lookup(name, create_if_missing=True)` (sync)          | `modal.Sandbox.create(app=app, image=image)` (sync)               | `modal_defaults()`    | `modal(sb)`                                          |
| Daytona   | `Daytona()` (sync)                                               | `await client.create()`                                           | (none)                | `daytona(raw)`                                       |
| Runloop   | `Runloop()` (sync)                                               | `await client.devboxes.create_and_await_running()`                | `runloop_defaults()`  | `runloop({"client": client, "id": devbox.id})`      |
| E2B       | `from e2b import AsyncSandbox`                                   | `await AsyncSandbox.create()`                                     | (none)                | `e2b(raw)`                                           |
| Freestyle | `FreestyleClient(api_key=...)`                                   | `await client.create_sandbox_vm()`                                | `freestyle_defaults()`| `freestyle(vm)`                                      |

Additional notes:
- Modal requires a Linux image with `apt_install("libseccomp2", "fuse3")` for agentsh's seccomp + FUSE dependencies.
- Modal creation is **sync** — wrap the calls in an async lambda (`async def _init(loop): ...`) for uniformity with `make_backend`.
- Freestyle needs `FreestyleClient` to live for the lifetime of the backend. We do NOT use the async context manager form; the HTTP client is GC'd when the backend is dropped. Freestyle bills per-VM, not per-HTTP-session, so an orphaned HTTP client is harmless.
- Daytona's adapter `stop()` is a **no-op** — full teardown requires calling `client.remove(sandbox)` separately. Our factory's cleanup path will call that explicitly.
- Phase 1 factories do **not** support reconnection by `sandbox_id`. If a caller passes `sandbox_id`, the factory raises `NotImplementedError`. This is documented in the README as a known limitation.

---

## File Structure

```
examples/open_swe/
├── __init__.py            # package marker + docstring
├── bridge.py              # SecureSandboxBackend + make_backend helper
├── factories.py           # 5 provider factories + SANDBOX_FACTORIES + get_secure_sandbox
├── demo_smoke_test.py     # end-to-end runner (uses SANDBOX_TYPE env var)
├── _patch_sandbox.py      # monkeypatch helper for open-swe forks
└── README.md              # usage docs + copy-paste instructions

tests/
└── test_open_swe_bridge.py  # unit tests using a fake SecuredSandbox (offline)
```

**Responsibilities:**

- `bridge.py` — defines `SecureSandboxBackend(BaseSandbox)` and the `make_backend(async_init)` helper that owns the background loop/thread. No provider knowledge. Pure translation layer between deepagents' sync API and secure-sandbox-py's async API.
- `factories.py` — one function per provider (`create_modal_sandbox`, `create_daytona_sandbox`, `create_runloop_sandbox`, `create_e2b_sandbox`, `create_freestyle_sandbox`), each returning a `SecureSandboxBackend`. Plus `SANDBOX_FACTORIES: dict[str, Callable]` and `get_secure_sandbox(sandbox_type: str, sandbox_id: str | None)` selector.
- `demo_smoke_test.py` — standalone script (not a pytest test) that exercises `execute`, `read`, `write`, `edit` end-to-end against whichever provider `SANDBOX_TYPE` env var points at. Used as a live integration check. Run with `python examples/open_swe/demo_smoke_test.py`.
- `_patch_sandbox.py` — a small snippet with instructions: users copy `bridge.py`, `factories.py`, and this file into `agent/integrations/secure/` in their open-swe fork, then call `patch_deepagents_get_sandbox()` at process start.
- `tests/test_open_swe_bridge.py` — uses a `_FakeSecuredSandbox` test double to verify the bridge's sync/async translation, result-type mapping, and edge cases. Runs offline (no provider credentials). Gated on `deepagents` via `pytest.importorskip`.

---

## Task 1: Package skeleton + `make_backend` + `SecureSandboxBackend.id`

**Files:**
- Create: `examples/open_swe/__init__.py`
- Create: `examples/open_swe/bridge.py`
- Create: `tests/test_open_swe_bridge.py`

- [ ] **Step 1: Create the package marker**

Create `examples/open_swe/__init__.py`:
```python
"""OpenSWE secure-sandbox integration — worked example.

See README.md for usage. Design doc:
docs/superpowers/specs/2026-04-11-open-swe-integration-design.md.
"""
```

- [ ] **Step 2: Write the failing test**

Create `tests/test_open_swe_bridge.py`:
```python
"""Unit tests for the OpenSWE sandbox bridge.

These tests use a fake SecuredSandbox test double. No real provider
credentials are required. Gated on ``deepagents`` being importable;
if it isn't, the whole module is skipped.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import pytest

pytest.importorskip("deepagents")

# Put ``examples/`` on sys.path so ``open_swe.bridge`` is importable.
_EXAMPLES = Path(__file__).resolve().parent.parent / "examples"
if str(_EXAMPLES) not in sys.path:
    sys.path.insert(0, str(_EXAMPLES))

from agentsh_secure_sandbox.core.types import (  # noqa: E402
    ExecResult,
    ReadFileFailure,
    ReadFileResult,
    ReadFileSuccess,
    WriteFileFailure,
    WriteFileResult,
    WriteFileSuccess,
)


@dataclass
class _FakeSecuredSandbox:
    """Minimal fake that matches SecuredSandbox's async protocol.

    Each method records its calls and optionally dispatches to a handler
    supplied by the test. Default handlers return a generic success.
    """
    session_id: str = "fake-session-42"
    security_mode: str = "full"
    exec_handler: Callable[[str], ExecResult] | None = None
    exec_calls: list[tuple[str, dict]] = field(default_factory=list)
    read_handler: Callable[[str], ReadFileResult] | None = None
    read_calls: list[str] = field(default_factory=list)
    write_handler: Callable[[str, str | bytes], WriteFileResult] | None = None
    write_calls: list[tuple[str, str | bytes]] = field(default_factory=list)
    stop_called: bool = False

    async def exec(
        self,
        command: str,
        *,
        cwd: str | None = None,
        timeout: float | None = None,
    ) -> ExecResult:
        self.exec_calls.append((command, {"cwd": cwd, "timeout": timeout}))
        if self.exec_handler:
            return self.exec_handler(command)
        return ExecResult(stdout="", stderr="", exit_code=0)

    async def read_file(self, path: str) -> ReadFileResult:
        self.read_calls.append(path)
        if self.read_handler:
            return self.read_handler(path)
        return ReadFileSuccess(success=True, path=path, content="")

    async def write_file(
        self, path: str, content: str | bytes
    ) -> WriteFileResult:
        self.write_calls.append((path, content))
        if self.write_handler:
            return self.write_handler(path, content)
        return WriteFileSuccess(success=True, path=path)

    async def stop(self) -> None:
        self.stop_called = True


def test_make_backend_returns_backend_with_id():
    from open_swe.bridge import SecureSandboxBackend, make_backend

    async def _init(loop):
        return "my-id-42", _FakeSecuredSandbox(session_id="my-id-42")

    backend = make_backend(_init)
    try:
        assert isinstance(backend, SecureSandboxBackend)
        assert backend.id == "my-id-42"
    finally:
        backend.close()
```

- [ ] **Step 3: Run test to verify it fails**

Run: `pytest tests/test_open_swe_bridge.py::test_make_backend_returns_backend_with_id -xvs`
Expected: FAIL with `ModuleNotFoundError: No module named 'open_swe.bridge'` or `ModuleNotFoundError: No module named 'open_swe'`.

- [ ] **Step 4: Create the bridge module**

Create `examples/open_swe/bridge.py`:
```python
"""Sync-to-async bridge between deepagents' BaseSandbox and secure-sandbox-py.

Each ``SecureSandboxBackend`` owns a private asyncio event loop running
on a daemon thread. All BaseSandbox methods dispatch onto that loop via
``asyncio.run_coroutine_threadsafe``.
"""
from __future__ import annotations

import asyncio
import threading
from typing import Any, Awaitable, Callable

from deepagents.backends.protocol import (
    EditResult,
    ExecuteResponse,
    FileData,
    FileDownloadResponse,
    FileUploadResponse,
    ReadResult,
    WriteResult,
)
from deepagents.backends.sandbox import BaseSandbox

from agentsh_secure_sandbox.core.types import SecuredSandbox


# --- error mapping ---------------------------------------------------------
# FileUploadResponse.error and FileDownloadResponse.error are typed as
# Literal["file_not_found", "permission_denied", "is_directory",
# "invalid_path"] | None in deepagents 0.5.2. Our secure-sandbox-py layer
# returns free-form error strings. This helper maps each string to the
# nearest literal; unknowns become "permission_denied" since the
# overwhelming majority of secure-sandbox failures are policy denials.

_FileOpError = str  # alias — the Literal type is in deepagents.backends.protocol


def _map_error(error_string: str | None) -> _FileOpError | None:
    """Map a secure-sandbox-py error string to a deepagents FileOperationError.

    Returns ``None`` if ``error_string`` is falsy. Otherwise returns one
    of the four Literal values accepted by ``FileUploadResponse.error``.
    Uses simple substring matching, defaulting to ``"permission_denied"``.
    """
    if not error_string:
        return None
    lowered = error_string.lower()
    if "not found" in lowered or "no such file" in lowered:
        return "file_not_found"
    if "is a directory" in lowered or "is_directory" in lowered:
        return "is_directory"
    if "invalid path" in lowered or "invalid_path" in lowered:
        return "invalid_path"
    return "permission_denied"


class SecureSandboxBackend(BaseSandbox):
    """Wraps a SecuredSandbox in deepagents' BaseSandbox contract.

    Instantiate via :func:`make_backend`. Direct construction is
    supported but requires the caller to own the event loop and
    daemon thread lifecycle themselves.
    """

    def __init__(
        self,
        sandbox_id: str,
        loop: asyncio.AbstractEventLoop,
        thread: threading.Thread,
        secured: SecuredSandbox,
    ) -> None:
        super().__init__()
        self._id = sandbox_id
        self._loop = loop
        self._thread = thread
        self._secured = secured
        self._closed = False

    @property
    def id(self) -> str:  # satisfies BaseSandbox.id
        return self._id

    def _run(self, coro: Awaitable[Any]) -> Any:
        """Dispatch ``coro`` onto the background loop and block until done."""
        return asyncio.run_coroutine_threadsafe(coro, self._loop).result()

    # Abstract methods we satisfy in later tasks:
    def execute(
        self, command: str, *, timeout: int | None = None
    ) -> ExecuteResponse:
        raise NotImplementedError

    def upload_files(
        self, files: list[tuple[str, bytes]]
    ) -> list[FileUploadResponse]:
        raise NotImplementedError

    def download_files(self, paths: list[str]) -> list[FileDownloadResponse]:
        raise NotImplementedError

    def close(self, *, stop_secured: bool = True) -> None:
        """Tear down the background loop and (by default) the secured sandbox."""
        if self._closed:
            return
        self._closed = True
        if stop_secured:
            try:
                asyncio.run_coroutine_threadsafe(
                    self._secured.stop(), self._loop
                ).result(timeout=60)
            except Exception:
                pass  # best-effort
        self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join(timeout=5)
        try:
            self._loop.close()
        except Exception:
            pass  # loop may already be closed, or stop hasn't taken effect yet

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass


def make_backend(
    async_init: Callable[
        [asyncio.AbstractEventLoop],
        Awaitable[tuple[str, SecuredSandbox]],
    ],
    *,
    init_timeout: float = 600.0,
) -> SecureSandboxBackend:
    """Spin up a background event loop and run ``async_init`` on it.

    ``async_init`` must create the provider sandbox, wrap it with
    :func:`agentsh_secure_sandbox.secure_sandbox`, and return
    ``(sandbox_id, secured_sandbox)``. The returned
    :class:`SecureSandboxBackend` owns the loop and thread until
    :meth:`SecureSandboxBackend.close` is called.
    """
    loop = asyncio.new_event_loop()
    thread = threading.Thread(
        target=loop.run_forever,
        name="secure-sandbox-backend",
        daemon=True,
    )
    thread.start()

    future: Any = None
    try:
        future = asyncio.run_coroutine_threadsafe(async_init(loop), loop)
        sandbox_id, secured = future.result(timeout=init_timeout)
    except BaseException as init_err:
        # Cancel any still-pending tasks on the background loop
        # (including a still-running async_init) and wait for their
        # finally blocks to run before we stop the loop. Schedule a
        # helper coroutine onto the loop so we operate within the
        # loop's single-threaded execution model — no other coroutine
        # can progress while we're in a sync section, which eliminates
        # the race between future.done() and all_tasks().
        async def _cancel_and_drain() -> None:
            current = asyncio.current_task()
            pending = [
                t
                for t in asyncio.all_tasks(loop)
                if t is not current and not t.done()
            ]
            for t in pending:
                t.cancel()
            if pending:
                results = await asyncio.gather(
                    *pending, return_exceptions=True
                )
                # Surface any non-cancellation exception from cleanup so
                # the caller can chain it to the original init error.
                for r in results:
                    if isinstance(r, BaseException) and not isinstance(
                        r, asyncio.CancelledError
                    ):
                        raise r

            # Check whether the init future completed (successfully or
            # with an error) while we weren't looking.
            late_exc: BaseException | None = None
            completed_ok = False
            if (
                future is not None
                and future.done()
                and not future.cancelled()
            ):
                try:
                    late_exc = future.exception(timeout=0)
                except BaseException:
                    pass  # couldn't read state; leave both flags default
                completed_ok = late_exc is None

            if completed_ok:
                # Init completed successfully after timeout — stop the
                # orphaned sandbox so it isn't leaked.
                try:
                    _, orphaned = future.result(timeout=0)
                    await orphaned.stop()
                except BaseException as stop_err:
                    raise stop_err
            elif late_exc is not None and late_exc is not init_err:
                # Init raised *after* the timeout. The caller would
                # only see TimeoutError — surface the real failure so
                # it can be chained onto the init exception.
                raise late_exc

        try:
            cleanup_fut = asyncio.run_coroutine_threadsafe(
                _cancel_and_drain(), loop
            )
            cleanup_fut.result(timeout=30)
        except BaseException as cleanup_err:
            # Cleanup ran but one of the drained tasks raised a non-
            # cancellation exception (or the drain itself timed out).
            # Walk the init_err's __context__ chain and append at the
            # end so neither piece of info is lost — even when the init
            # error already has a context chain of its own.
            target: BaseException = init_err
            while target.__context__ is not None:
                target = target.__context__
            target.__context__ = cleanup_err
        loop.call_soon_threadsafe(loop.stop)
        thread.join(timeout=5)
        try:
            loop.close()
        except Exception:
            pass
        raise

    return SecureSandboxBackend(
        sandbox_id=sandbox_id,
        loop=loop,
        thread=thread,
        secured=secured,
    )
```

**Note:** the three abstract methods (`execute`, `upload_files`, `download_files`) are stubbed with `raise NotImplementedError` in this task so the class is instantiable. Python's ABC machinery enforces `@abstractmethod` at class-definition time by checking whether a concrete definition exists; a method that raises at call time still counts as concrete. Tasks 2–4 fill in real implementations.

- [ ] **Step 5: Run test to verify it passes**

Run: `pytest tests/test_open_swe_bridge.py::test_make_backend_returns_backend_with_id -xvs`
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add examples/open_swe/__init__.py examples/open_swe/bridge.py tests/test_open_swe_bridge.py
git commit -m "feat(open-swe): make_backend helper + SecureSandboxBackend skeleton

Introduces the sync-to-async bridge pattern: each backend owns
a background asyncio loop on a daemon thread. Ships a test double
(_FakeSecuredSandbox) used by subsequent tests."
```

---

## Task 2: `execute()` — stdout, stderr, exit code, timeout

**Files:**
- Modify: `examples/open_swe/bridge.py` — replace `execute` stub
- Modify: `tests/test_open_swe_bridge.py` — add test cases

- [ ] **Step 1: Write failing tests**

Append to `tests/test_open_swe_bridge.py`:
```python
def test_execute_stdout_only():
    from deepagents.backends.protocol import ExecuteResponse

    from open_swe.bridge import make_backend

    def fake_exec(command):
        assert command == "echo hello"
        return ExecResult(stdout="hello\n", stderr="", exit_code=0)

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(exec_handler=fake_exec)

    backend = make_backend(_init)
    try:
        result = backend.execute("echo hello")
        assert isinstance(result, ExecuteResponse)
        assert result.output == "hello\n"
        assert result.exit_code == 0
        assert result.truncated is False
    finally:
        backend.close()


def test_execute_concatenates_stderr_after_stdout():
    from open_swe.bridge import make_backend

    def fake_exec(command):
        return ExecResult(
            stdout="line-1\n", stderr="warning: X\n", exit_code=0
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(exec_handler=fake_exec)

    backend = make_backend(_init)
    try:
        result = backend.execute("some-cmd")
        # stdout first, then stderr separated by newline
        assert result.output == "line-1\n\nwarning: X\n"
    finally:
        backend.close()


def test_execute_stderr_only_when_no_stdout():
    from open_swe.bridge import make_backend

    def fake_exec(command):
        return ExecResult(stdout="", stderr="boom\n", exit_code=1)

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(exec_handler=fake_exec)

    backend = make_backend(_init)
    try:
        result = backend.execute("false")
        assert result.output == "boom\n"
        assert result.exit_code == 1
    finally:
        backend.close()


def test_execute_passes_timeout_through():
    from open_swe.bridge import make_backend

    fake = _FakeSecuredSandbox()

    async def _init(loop):
        return "sbx", fake

    backend = make_backend(_init)
    try:
        backend.execute("sleep 10", timeout=5)
        assert fake.exec_calls[-1] == (
            "sleep 10",
            {"cwd": None, "timeout": 5.0},
        )
    finally:
        backend.close()
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k execute`
Expected: FAIL — the stubbed `execute` raises `NotImplementedError`.

- [ ] **Step 3: Implement `execute`**

Replace the `execute` stub in `examples/open_swe/bridge.py`:
```python
    def execute(
        self, command: str, *, timeout: int | None = None
    ) -> ExecuteResponse:
        """Run a shell command under agentsh policy enforcement.

        Concatenates stdout + stderr into a single ``output`` string
        because deepagents' ExecuteResponse carries one output field.
        If both are non-empty, they're separated by a newline; if only
        one is non-empty, no extra separator is added.
        """
        result = self._run(
            self._secured.exec(
                command,
                timeout=float(timeout) if timeout is not None else None,
            )
        )
        if result.stdout and result.stderr:
            output = f"{result.stdout}\n{result.stderr}"
        else:
            output = result.stdout or result.stderr
        return ExecuteResponse(
            output=output,
            exit_code=result.exit_code,
            truncated=False,
        )
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k execute`
Expected: all four `test_execute_*` tests PASS. Plus the `test_make_backend_*` from Task 1.

- [ ] **Step 5: Commit**

```bash
git add examples/open_swe/bridge.py tests/test_open_swe_bridge.py
git commit -m "feat(open-swe): implement SecureSandboxBackend.execute

Wraps SecuredSandbox.exec and maps ExecResult → ExecuteResponse.
Concatenates stdout + stderr with newline separator since deepagents
only carries one output field."
```

---

## Task 3: `upload_files` and `download_files`

**Files:**
- Modify: `examples/open_swe/bridge.py` — replace `upload_files` and `download_files` stubs
- Modify: `tests/test_open_swe_bridge.py` — add tests

- [ ] **Step 1: Write failing tests**

Append to `tests/test_open_swe_bridge.py`:
```python
def test_upload_files_success():
    from open_swe.bridge import make_backend

    fake = _FakeSecuredSandbox()

    async def _init(loop):
        return "sbx", fake

    backend = make_backend(_init)
    try:
        responses = backend.upload_files(
            [("/workspace/a.txt", b"hello"), ("/workspace/b.txt", b"world")]
        )
        assert len(responses) == 2
        assert responses[0].path == "/workspace/a.txt"
        assert responses[0].error is None
        assert responses[1].path == "/workspace/b.txt"
        assert responses[1].error is None
        assert fake.write_calls == [
            ("/workspace/a.txt", b"hello"),
            ("/workspace/b.txt", b"world"),
        ]
    finally:
        backend.close()


def test_upload_files_records_errors_per_entry():
    from open_swe.bridge import make_backend

    def fake_write(path, content):
        if path == "/denied/x.txt":
            return WriteFileFailure(success=False, path=path, error="policy: denied")
        return WriteFileSuccess(success=True, path=path)

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(write_handler=fake_write)

    backend = make_backend(_init)
    try:
        responses = backend.upload_files(
            [("/workspace/ok.txt", b"x"), ("/denied/x.txt", b"y")]
        )
        assert responses[0].error is None
        # Secure-sandbox error strings are mapped to the FileOperationError
        # Literal in deepagents. A generic "policy: denied" becomes
        # "permission_denied".
        assert responses[1].error == "permission_denied"
    finally:
        backend.close()


def test_download_files_returns_bytes_on_success():
    from open_swe.bridge import make_backend

    def fake_read(path):
        return ReadFileSuccess(
            success=True, path=path, content="file contents"
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        responses = backend.download_files(["/workspace/x.txt"])
        assert len(responses) == 1
        assert responses[0].path == "/workspace/x.txt"
        assert responses[0].content == b"file contents"
        assert responses[0].error is None
    finally:
        backend.close()


def test_download_files_records_error_per_entry():
    from open_swe.bridge import make_backend

    def fake_read(path):
        if path == "/missing":
            return ReadFileFailure(
                success=False, path=path, error="file not found"
            )
        return ReadFileSuccess(success=True, path=path, content="ok")

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        responses = backend.download_files(["/missing", "/good"])
        # "file not found" → "file_not_found" via _map_error
        assert responses[0].content is None
        assert responses[0].error == "file_not_found"
        assert responses[1].content == b"ok"
        assert responses[1].error is None
    finally:
        backend.close()
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "upload or download"`
Expected: FAIL — stubs raise `NotImplementedError`.

- [ ] **Step 3: Implement both methods**

Replace the `upload_files` and `download_files` stubs in `bridge.py`:
```python
    def upload_files(
        self, files: list[tuple[str, bytes]]
    ) -> list[FileUploadResponse]:
        """Write each ``(path, bytes)`` pair through the secured file API.

        Secure-sandbox-py returns free-form error strings; we map them
        to deepagents' ``FileOperationError`` Literal via ``_map_error``
        before building the response.
        """
        responses: list[FileUploadResponse] = []
        for path, content in files:
            result = self._run(self._secured.write_file(path, content))
            if result.success:
                responses.append(FileUploadResponse(path=path))
            else:
                responses.append(
                    FileUploadResponse(
                        path=path, error=_map_error(result.error)
                    )
                )
        return responses

    def download_files(self, paths: list[str]) -> list[FileDownloadResponse]:
        """Read each path through the secured file API; encode content as UTF-8 bytes.

        Failure ``error`` strings are mapped to deepagents'
        ``FileOperationError`` Literal via ``_map_error``.
        """
        responses: list[FileDownloadResponse] = []
        for path in paths:
            result = self._run(self._secured.read_file(path))
            if result.success:
                responses.append(
                    FileDownloadResponse(
                        path=path,
                        content=result.content.encode("utf-8"),
                    )
                )
            else:
                responses.append(
                    FileDownloadResponse(
                        path=path, error=_map_error(result.error)
                    )
                )
        return responses
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/test_open_swe_bridge.py -xvs`
Expected: all tests to date PASS (9 tests: 1 from Task 1, 4 from Task 2, 4 from Task 3).

- [ ] **Step 5: Commit**

```bash
git add examples/open_swe/bridge.py tests/test_open_swe_bridge.py
git commit -m "feat(open-swe): upload_files + download_files

Satisfies the remaining BaseSandbox abstract methods. Errors become
per-entry Response.error strings (not exceptions) to match the
deepagents protocol contract."
```

---

## Task 4: Override `read()` with offset/limit pagination

**Files:**
- Modify: `examples/open_swe/bridge.py` — add `read()` override
- Modify: `tests/test_open_swe_bridge.py` — add tests

- [ ] **Step 1: Write failing tests**

Append to `tests/test_open_swe_bridge.py`:
```python
def test_read_full_file():
    from open_swe.bridge import make_backend

    def fake_read(path):
        return ReadFileSuccess(
            success=True, path=path, content="line1\nline2\nline3\n"
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        result = backend.read("/workspace/x.txt")
        assert result.error is None
        assert result.file_data["content"] == "line1\nline2\nline3\n"
        assert result.file_data["encoding"] == "utf-8"
    finally:
        backend.close()


def test_read_with_offset_and_limit():
    from open_swe.bridge import make_backend

    def fake_read(path):
        content = "".join(f"line{i}\n" for i in range(1, 11))
        return ReadFileSuccess(success=True, path=path, content=content)

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        # Skip 2 lines, take 3 → lines 3,4,5
        result = backend.read("/workspace/x.txt", offset=2, limit=3)
        assert result.error is None
        assert result.file_data["content"] == "line3\nline4\nline5\n"
    finally:
        backend.close()


def test_read_returns_error_on_failure():
    from open_swe.bridge import make_backend

    def fake_read(path):
        return ReadFileFailure(
            success=False, path=path, error="policy: denied"
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        result = backend.read("/denied/x")
        assert result.error == "policy: denied"
        assert result.file_data is None
    finally:
        backend.close()
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "read"`
Expected: FAIL — `backend.read()` currently delegates to BaseSandbox's default implementation, which routes through `execute()`. Against our fake (which doesn't shell out), the output will be empty/wrong. Test either fails outright or returns wrong data. (If the default impl coincidentally passes, switch to `assert isinstance(backend.read.__func__, SecureSandboxBackend.read.__func__)` — but the real failure mode is that `file_data` won't exist / encoding mismatch.)

- [ ] **Step 3: Implement `read`**

Add to the `SecureSandboxBackend` class in `bridge.py` (after `download_files`):
```python
    def read(
        self,
        file_path: str,
        offset: int = 0,
        limit: int = 2000,
    ) -> ReadResult:
        """Read a file through the secured file API, then slice by lines.

        ``offset`` is a 0-indexed starting line; ``limit`` is the number
        of lines to return. Matches deepagents' default contract.
        """
        result = self._run(self._secured.read_file(file_path))
        if not result.success:
            return ReadResult(error=result.error)
        content = result.content
        if offset or (limit and limit != len(content.splitlines())):
            lines = content.splitlines(keepends=True)
            end = offset + limit if limit else len(lines)
            content = "".join(lines[offset:end])
        file_data: FileData = {"content": content, "encoding": "utf-8"}
        return ReadResult(file_data=file_data)
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "read"`
Expected: three `test_read_*` tests PASS.

- [ ] **Step 5: Commit**

```bash
git add examples/open_swe/bridge.py tests/test_open_swe_bridge.py
git commit -m "feat(open-swe): typed read() override

Routes through SecuredSandbox.read_file (policy-aware) instead of
the default execute-based implementation. Pages lines client-side
via offset/limit."
```

---

## Task 5: Override `write()`

**Files:**
- Modify: `examples/open_swe/bridge.py` — add `write()` override
- Modify: `tests/test_open_swe_bridge.py` — add tests

- [ ] **Step 1: Write failing tests**

Append to `tests/test_open_swe_bridge.py`:
```python
def test_write_success():
    from open_swe.bridge import make_backend

    fake = _FakeSecuredSandbox()

    async def _init(loop):
        return "sbx", fake

    backend = make_backend(_init)
    try:
        result = backend.write("/workspace/new.txt", "contents")
        assert result.error is None
        assert result.path == "/workspace/new.txt"
        assert fake.write_calls == [("/workspace/new.txt", "contents")]
    finally:
        backend.close()


def test_write_policy_denied():
    from open_swe.bridge import make_backend

    def fake_write(path, content):
        return WriteFileFailure(
            success=False, path=path, error="policy: write denied"
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(write_handler=fake_write)

    backend = make_backend(_init)
    try:
        result = backend.write("/denied/x", "contents")
        assert result.error == "policy: write denied"
    finally:
        backend.close()
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "test_write_"`
Expected: FAIL — the default BaseSandbox.write() shells out via execute(), which would call our fake's `exec` (not `write_file`). So either the assertions about `write_calls` fail or the result type is wrong.

- [ ] **Step 3: Implement `write`**

Add to `SecureSandboxBackend` in `bridge.py`:
```python
    def write(self, file_path: str, content: str) -> WriteResult:
        """Write a file through the secured file API (policy-aware)."""
        result = self._run(self._secured.write_file(file_path, content))
        if result.success:
            return WriteResult(path=file_path)
        return WriteResult(error=result.error)
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/test_open_swe_bridge.py -xvs`
Expected: all tests so far PASS.

- [ ] **Step 5: Commit**

```bash
git add examples/open_swe/bridge.py tests/test_open_swe_bridge.py
git commit -m "feat(open-swe): typed write() override

Routes through SecuredSandbox.write_file so policy denials become
WriteResult.error strings instead of shell-level errors."
```

---

## Task 6: Override `edit()` as read-modify-write

**Files:**
- Modify: `examples/open_swe/bridge.py` — add `edit()` override
- Modify: `tests/test_open_swe_bridge.py` — add tests

- [ ] **Step 1: Write failing tests**

Append to `tests/test_open_swe_bridge.py`:
```python
def test_edit_single_occurrence():
    from open_swe.bridge import make_backend

    state = {"content": "hello WORLD hello"}

    def fake_read(path):
        return ReadFileSuccess(
            success=True, path=path, content=state["content"]
        )

    def fake_write(path, content):
        state["content"] = content
        return WriteFileSuccess(success=True, path=path)

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(
            read_handler=fake_read, write_handler=fake_write
        )

    backend = make_backend(_init)
    try:
        result = backend.edit("/workspace/x.txt", "WORLD", "EARTH")
        assert result.error is None
        assert result.path == "/workspace/x.txt"
        assert result.occurrences == 1
        assert state["content"] == "hello EARTH hello"
    finally:
        backend.close()


def test_edit_replace_all():
    from open_swe.bridge import make_backend

    state = {"content": "foo foo foo"}

    def fake_read(path):
        return ReadFileSuccess(
            success=True, path=path, content=state["content"]
        )

    def fake_write(path, content):
        state["content"] = content
        return WriteFileSuccess(success=True, path=path)

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(
            read_handler=fake_read, write_handler=fake_write
        )

    backend = make_backend(_init)
    try:
        result = backend.edit(
            "/workspace/x.txt", "foo", "bar", replace_all=True
        )
        assert result.error is None
        assert result.occurrences == 3
        assert state["content"] == "bar bar bar"
    finally:
        backend.close()


def test_edit_not_unique_without_replace_all():
    from open_swe.bridge import make_backend

    def fake_read(path):
        return ReadFileSuccess(
            success=True, path=path, content="foo foo"
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        result = backend.edit("/workspace/x.txt", "foo", "bar")
        assert result.error is not None
        assert "2 times" in result.error or "matches" in result.error
    finally:
        backend.close()


def test_edit_not_found():
    from open_swe.bridge import make_backend

    def fake_read(path):
        return ReadFileSuccess(
            success=True, path=path, content="hello"
        )

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        result = backend.edit("/workspace/x.txt", "missing", "new")
        assert result.error is not None
        assert "not found" in result.error.lower()
    finally:
        backend.close()


def test_edit_propagates_read_error():
    from open_swe.bridge import make_backend

    def fake_read(path):
        return ReadFileFailure(success=False, path=path, error="denied")

    async def _init(loop):
        return "sbx", _FakeSecuredSandbox(read_handler=fake_read)

    backend = make_backend(_init)
    try:
        result = backend.edit("/denied", "a", "b")
        assert result.error == "denied"
    finally:
        backend.close()
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "test_edit_"`
Expected: FAIL — default BaseSandbox.edit() shells out via execute().

- [ ] **Step 3: Implement `edit`**

Add to `SecureSandboxBackend` in `bridge.py`:
```python
    def edit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> EditResult:
        """Read, replace, write-back — using the secured file API throughout.

        Trades BaseSandbox's inline-JSON optimization for consistency
        with our policy-aware read/write paths.
        """
        read_result = self._run(self._secured.read_file(file_path))
        if not read_result.success:
            return EditResult(error=read_result.error)

        content = read_result.content
        occurrences = content.count(old_string)
        if occurrences == 0:
            return EditResult(
                error=f"old_string not found in {file_path}",
            )
        if not replace_all and occurrences > 1:
            return EditResult(
                error=(
                    f"old_string matches {occurrences} times in {file_path}; "
                    "pass replace_all=True or make it unique"
                ),
            )

        if replace_all:
            new_content = content.replace(old_string, new_string)
            count = occurrences
        else:
            new_content = content.replace(old_string, new_string, 1)
            count = 1

        write_result = self._run(
            self._secured.write_file(file_path, new_content)
        )
        if not write_result.success:
            return EditResult(error=write_result.error)
        return EditResult(path=file_path, occurrences=count)
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/test_open_swe_bridge.py -xvs`
Expected: all 19 tests PASS (Task 1 × 1 + Task 2 × 4 + Task 3 × 4 + Task 4 × 3 + Task 5 × 2 + Task 6 × 5).

- [ ] **Step 5: Commit**

```bash
git add examples/open_swe/bridge.py tests/test_open_swe_bridge.py
git commit -m "feat(open-swe): typed edit() override

Implements read-modify-write over SecuredSandbox.read_file and
write_file so edits inherit the same policy enforcement as other
file operations."
```

---

## Task 7: Factories skeleton + Modal factory

**Files:**
- Create: `examples/open_swe/factories.py`
- Modify: `tests/test_open_swe_bridge.py` — add import-only test

- [ ] **Step 1: Write failing test**

Append to `tests/test_open_swe_bridge.py`:
```python
def test_factories_module_exports_modal_factory():
    import open_swe.factories as fac

    # The factory must exist as a callable with sandbox_id kwarg.
    assert callable(getattr(fac, "create_modal_sandbox", None))
    # Importing must NOT require Modal credentials — creation is lazy.
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "test_factories_module_exports_modal"`
Expected: FAIL with `ModuleNotFoundError: No module named 'open_swe.factories'`.

- [ ] **Step 3: Create `factories.py` with the Modal factory**

Create `examples/open_swe/factories.py`:
```python
"""Provider factories for the OpenSWE secure-sandbox bridge.

Each ``create_<provider>_sandbox(sandbox_id=None)`` function returns a
ready-to-use :class:`SecureSandboxBackend`. All heavy SDK imports happen
inside the factory body so importing this module is cheap and doesn't
require every provider SDK to be installed.
"""
from __future__ import annotations

import os
from typing import Callable

from .bridge import SecureSandboxBackend, make_backend

_PHASE1_NO_RECONNECT = (
    "reconnection by sandbox_id is not supported in phase 1; "
    "create a fresh sandbox or track this in the issue tracker"
)


def create_modal_sandbox(sandbox_id: str | None = None) -> SecureSandboxBackend:
    """Create a Modal Sandbox wrapped in secure-sandbox-py.

    Reads ``SECURE_MODAL_APP_NAME`` from env (default
    ``agentsh-secure-sandbox-open-swe``) — a separate name from open-swe's
    own Modal app so both can run side-by-side in the same Modal workspace.
    """
    if sandbox_id is not None:
        raise NotImplementedError(_PHASE1_NO_RECONNECT)

    async def _init(loop):
        # Local imports: Modal SDK is heavy and optional.
        import modal

        from agentsh_secure_sandbox import secure_sandbox
        from agentsh_secure_sandbox.adapters import modal as modal_adapter
        from agentsh_secure_sandbox.adapters import modal_defaults

        app_name = os.environ.get(
            "SECURE_MODAL_APP_NAME", "agentsh-secure-sandbox-open-swe"
        )
        image = modal.Image.debian_slim().apt_install("libseccomp2", "fuse3")
        app = modal.App.lookup(app_name, create_if_missing=True)
        sb = modal.Sandbox.create(app=app, image=image)

        secured = await secure_sandbox(modal_adapter(sb), modal_defaults())
        # Modal Sandbox exposes .object_id for its globally-unique id.
        sandbox_id_str: str = getattr(sb, "object_id", None) or str(id(sb))
        return sandbox_id_str, secured

    return make_backend(_init)


SANDBOX_FACTORIES: dict[str, Callable[..., SecureSandboxBackend]] = {
    "modal": create_modal_sandbox,
}


def get_secure_sandbox(
    sandbox_type: str, sandbox_id: str | None = None
) -> SecureSandboxBackend:
    """Dispatch to the right factory by provider name.

    Raises :class:`KeyError` if ``sandbox_type`` is not registered.
    """
    try:
        factory = SANDBOX_FACTORIES[sandbox_type]
    except KeyError as exc:
        available = ", ".join(sorted(SANDBOX_FACTORIES))
        raise KeyError(
            f"unknown sandbox_type {sandbox_type!r}; available: {available}"
        ) from exc
    return factory(sandbox_id=sandbox_id)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "test_factories_module_exports_modal"`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add examples/open_swe/factories.py tests/test_open_swe_bridge.py
git commit -m "feat(open-swe): factories skeleton + Modal factory

Introduces the one-factory-per-provider layout, the SANDBOX_FACTORIES
registry, and the get_secure_sandbox selector. Modal factory uses
SECURE_MODAL_APP_NAME env var so it can coexist with open-swe's
existing MODAL_APP_NAME."
```

---

## Task 8: Daytona factory

**Files:**
- Modify: `examples/open_swe/factories.py` — add Daytona factory
- Modify: `tests/test_open_swe_bridge.py` — add import-only test

- [ ] **Step 1: Write failing test**

Append to `tests/test_open_swe_bridge.py`:
```python
def test_factories_module_exports_daytona_factory():
    import open_swe.factories as fac

    assert callable(getattr(fac, "create_daytona_sandbox", None))
    assert "daytona" in fac.SANDBOX_FACTORIES
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "test_factories_module_exports_daytona"`
Expected: FAIL with `AttributeError` on `create_daytona_sandbox`.

- [ ] **Step 3: Add `create_daytona_sandbox` to `factories.py`**

Insert after `create_modal_sandbox` in `examples/open_swe/factories.py`:
```python
def create_daytona_sandbox(sandbox_id: str | None = None) -> SecureSandboxBackend:
    """Create a Daytona sandbox wrapped in secure-sandbox-py."""
    if sandbox_id is not None:
        raise NotImplementedError(_PHASE1_NO_RECONNECT)

    async def _init(loop):
        from daytona_sdk import Daytona

        from agentsh_secure_sandbox import secure_sandbox
        from agentsh_secure_sandbox.adapters import daytona as daytona_adapter

        client = Daytona()
        raw = await client.create()
        secured = await secure_sandbox(daytona_adapter(raw))
        sandbox_id_str: str = getattr(raw, "id", None) or str(id(raw))
        return sandbox_id_str, secured

    return make_backend(_init)
```

And register it by replacing the `SANDBOX_FACTORIES` dict:
```python
SANDBOX_FACTORIES: dict[str, Callable[..., SecureSandboxBackend]] = {
    "modal": create_modal_sandbox,
    "daytona": create_daytona_sandbox,
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "test_factories_module"`
Expected: both import-only factory tests PASS.

- [ ] **Step 5: Commit**

```bash
git add examples/open_swe/factories.py tests/test_open_swe_bridge.py
git commit -m "feat(open-swe): Daytona factory

Uses Daytona's default async create(); note the Daytona adapter's
stop() is a no-op, so the backend's close() call will not remove
the sandbox from Daytona's billing. Tracking sandbox cleanup
separately is a known phase 1 limitation."
```

---

## Task 9: Runloop factory

**Files:**
- Modify: `examples/open_swe/factories.py` — add Runloop factory
- Modify: `tests/test_open_swe_bridge.py` — add import-only test

- [ ] **Step 1: Write failing test**

Append to `tests/test_open_swe_bridge.py`:
```python
def test_factories_module_exports_runloop_factory():
    import open_swe.factories as fac

    assert callable(getattr(fac, "create_runloop_sandbox", None))
    assert "runloop" in fac.SANDBOX_FACTORIES
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "test_factories_module_exports_runloop"`
Expected: FAIL on `create_runloop_sandbox` missing.

- [ ] **Step 3: Add `create_runloop_sandbox`**

Insert after `create_daytona_sandbox` in `examples/open_swe/factories.py`:
```python
def create_runloop_sandbox(sandbox_id: str | None = None) -> SecureSandboxBackend:
    """Create a Runloop devbox wrapped in secure-sandbox-py.

    Uses ``runloop_defaults()`` which enables seccomp + unix_sockets +
    FUSE deferred + cgroups — the set that works on Runloop's kernel.
    """
    if sandbox_id is not None:
        raise NotImplementedError(_PHASE1_NO_RECONNECT)

    async def _init(loop):
        from runloop_api_client import Runloop

        from agentsh_secure_sandbox import secure_sandbox
        from agentsh_secure_sandbox.adapters import runloop as runloop_adapter
        from agentsh_secure_sandbox.adapters import runloop_defaults

        client = Runloop()
        devbox = await client.devboxes.create_and_await_running()
        adapter = runloop_adapter({"client": client, "id": devbox.id})
        secured = await secure_sandbox(adapter, runloop_defaults())
        return devbox.id, secured

    return make_backend(_init)
```

Update `SANDBOX_FACTORIES`:
```python
SANDBOX_FACTORIES: dict[str, Callable[..., SecureSandboxBackend]] = {
    "modal": create_modal_sandbox,
    "daytona": create_daytona_sandbox,
    "runloop": create_runloop_sandbox,
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "test_factories_module_exports_runloop"`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add examples/open_swe/factories.py tests/test_open_swe_bridge.py
git commit -m "feat(open-swe): Runloop factory

Passes runloop_defaults() through so seccomp, unix_sockets, FUSE
deferred mode, and cgroups all activate. Matches the pattern from
examples/runloop_pydantic_ai.py."
```

---

## Task 10: E2B factory

**Files:**
- Modify: `examples/open_swe/factories.py` — add E2B factory
- Modify: `tests/test_open_swe_bridge.py` — add import-only test

- [ ] **Step 1: Write failing test**

Append to `tests/test_open_swe_bridge.py`:
```python
def test_factories_module_exports_e2b_factory():
    import open_swe.factories as fac

    assert callable(getattr(fac, "create_e2b_sandbox", None))
    assert "e2b" in fac.SANDBOX_FACTORIES
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "test_factories_module_exports_e2b"`
Expected: FAIL.

- [ ] **Step 3: Add `create_e2b_sandbox`**

Insert after `create_runloop_sandbox`:
```python
def create_e2b_sandbox(sandbox_id: str | None = None) -> SecureSandboxBackend:
    """Create an E2B sandbox wrapped in secure-sandbox-py.

    Uses :class:`e2b.AsyncSandbox` for async construction.
    """
    if sandbox_id is not None:
        raise NotImplementedError(_PHASE1_NO_RECONNECT)

    async def _init(loop):
        from e2b import AsyncSandbox

        from agentsh_secure_sandbox import secure_sandbox
        from agentsh_secure_sandbox.adapters import e2b as e2b_adapter

        raw = await AsyncSandbox.create()
        secured = await secure_sandbox(e2b_adapter(raw))
        sandbox_id_str: str = getattr(raw, "sandbox_id", None) or str(id(raw))
        return sandbox_id_str, secured

    return make_backend(_init)
```

Update `SANDBOX_FACTORIES`:
```python
SANDBOX_FACTORIES: dict[str, Callable[..., SecureSandboxBackend]] = {
    "modal": create_modal_sandbox,
    "daytona": create_daytona_sandbox,
    "runloop": create_runloop_sandbox,
    "e2b": create_e2b_sandbox,
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "test_factories_module_exports_e2b"`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add examples/open_swe/factories.py tests/test_open_swe_bridge.py
git commit -m "feat(open-swe): E2B factory

Uses e2b.AsyncSandbox rather than the sync e2b.Sandbox so creation
can happen on the background event loop without blocking the caller."
```

---

## Task 11: Freestyle factory

**Files:**
- Modify: `examples/open_swe/factories.py` — add Freestyle factory
- Modify: `tests/test_open_swe_bridge.py` — add import-only test

- [ ] **Step 1: Write failing test**

Append to `tests/test_open_swe_bridge.py`:
```python
def test_factories_module_exports_freestyle_factory():
    import open_swe.factories as fac

    assert callable(getattr(fac, "create_freestyle_sandbox", None))
    assert "freestyle" in fac.SANDBOX_FACTORIES
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "test_factories_module_exports_freestyle"`
Expected: FAIL.

- [ ] **Step 3: Add `create_freestyle_sandbox`**

Insert after `create_e2b_sandbox`:
```python
def create_freestyle_sandbox(sandbox_id: str | None = None) -> SecureSandboxBackend:
    """Create a Freestyle VM wrapped in secure-sandbox-py.

    Uses ``freestyle_defaults()`` + a baked snapshot (agentsh is
    preinstalled via ``configure_freestyle_spec``). Cold starts can take
    several minutes on first snapshot build — ``make_backend`` gives up
    to 10 minutes by default.

    The internal HTTP client is held open for the life of the backend.
    It is GC'd when the backend is dropped; Freestyle bills per-VM not
    per-HTTP-session, so leaking the client briefly is harmless.
    """
    if sandbox_id is not None:
        raise NotImplementedError(_PHASE1_NO_RECONNECT)

    async def _init(loop):
        from agentsh_secure_sandbox import secure_sandbox
        from agentsh_secure_sandbox.adapters.freestyle import (
            FreestyleClient,
            freestyle,
            freestyle_defaults,
        )

        client = FreestyleClient()
        try:
            vm = await client.create_sandbox_vm()
        except BaseException:
            await client.aclose()
            raise
        try:
            secured = await secure_sandbox(freestyle(vm), freestyle_defaults())
        except BaseException:
            # secured never materialized; stop the VM ourselves
            try:
                await vm.stop()
            finally:
                await client.aclose()
            raise
        return vm.vm_id, secured

    return make_backend(_init)
```

Update `SANDBOX_FACTORIES`:
```python
SANDBOX_FACTORIES: dict[str, Callable[..., SecureSandboxBackend]] = {
    "modal": create_modal_sandbox,
    "daytona": create_daytona_sandbox,
    "runloop": create_runloop_sandbox,
    "e2b": create_e2b_sandbox,
    "freestyle": create_freestyle_sandbox,
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_open_swe_bridge.py -xvs`
Expected: all tests PASS including the new freestyle import test.

- [ ] **Step 5: Commit**

```bash
git add examples/open_swe/factories.py tests/test_open_swe_bridge.py
git commit -m "feat(open-swe): Freestyle factory

Uses FreestyleClient.create_sandbox_vm() which bakes agentsh into
the VM snapshot and waits for install. Includes error-path cleanup
so a failed secure_sandbox() call doesn't leak a running VM."
```

---

## Task 12: `get_secure_sandbox` dispatch test

**Files:**
- Modify: `tests/test_open_swe_bridge.py` — add selector tests

The factory functions are all covered by import-only tests and cannot be exercised without live provider credentials. This task adds two tests for the selector: one verifying a known-good name dispatches correctly (by mocking the factory), one verifying an unknown name raises `KeyError` with the right message.

- [ ] **Step 1: Write failing tests**

Append to `tests/test_open_swe_bridge.py`:
```python
def test_get_secure_sandbox_dispatches_by_name():
    import open_swe.factories as fac

    captured: list[tuple[str, str | None]] = []

    def fake_factory(sandbox_id: str | None = None):
        captured.append(("called", sandbox_id))
        return "SENTINEL"  # pretend backend

    original = fac.SANDBOX_FACTORIES.copy()
    fac.SANDBOX_FACTORIES["_test"] = fake_factory
    try:
        result = fac.get_secure_sandbox("_test", sandbox_id=None)
        assert result == "SENTINEL"
        assert captured == [("called", None)]
    finally:
        fac.SANDBOX_FACTORIES.clear()
        fac.SANDBOX_FACTORIES.update(original)


def test_get_secure_sandbox_unknown_name_raises():
    import open_swe.factories as fac

    with pytest.raises(KeyError) as excinfo:
        fac.get_secure_sandbox("nope")
    msg = str(excinfo.value)
    assert "nope" in msg
    assert "available" in msg
```

- [ ] **Step 2: Run tests to verify they (un)expectedly pass or fail**

Run: `pytest tests/test_open_swe_bridge.py -xvs -k "test_get_secure_sandbox"`
Expected: PASS (the selector was implemented in Task 7 already). If they fail, fix the selector in `factories.py` — the logic in Task 7 step 3 must match:
```python
def get_secure_sandbox(
    sandbox_type: str, sandbox_id: str | None = None
) -> SecureSandboxBackend:
    try:
        factory = SANDBOX_FACTORIES[sandbox_type]
    except KeyError as exc:
        available = ", ".join(sorted(SANDBOX_FACTORIES))
        raise KeyError(
            f"unknown sandbox_type {sandbox_type!r}; available: {available}"
        ) from exc
    return factory(sandbox_id=sandbox_id)
```

- [ ] **Step 3: Commit**

```bash
git add tests/test_open_swe_bridge.py
git commit -m "test(open-swe): get_secure_sandbox dispatch + error cases

Verifies the selector routes by name and emits a useful error
listing available providers for unknown names."
```

---

## Task 13: Smoke test script (`demo_smoke_test.py`)

**Files:**
- Create: `examples/open_swe/demo_smoke_test.py`

This is a standalone script, not a pytest test, so there's no red/green cycle — just a careful write, a manual run, and a commit. The script prints clear pass/fail output and exits non-zero on any failure so CI or shell scripts can gate on it.

- [ ] **Step 1: Create the smoke test**

Create `examples/open_swe/demo_smoke_test.py`:
```python
"""End-to-end smoke test for the OpenSWE secure-sandbox bridge.

Runs against a real provider sandbox selected by the ``SANDBOX_TYPE``
env var (one of ``modal``, ``daytona``, ``runloop``, ``e2b``,
``freestyle``). Prints a PASS/FAIL summary per operation.

Usage::

    SANDBOX_TYPE=e2b python examples/open_swe/demo_smoke_test.py

Exit codes:
    0 — all ops passed
    1 — one or more ops failed
    2 — SANDBOX_TYPE unset or unknown
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from factories import get_secure_sandbox  # noqa: E402


def _check(label: str, ok: bool, detail: str = "") -> bool:
    status = "PASS" if ok else "FAIL"
    print(f"  [{status}] {label}{(' — ' + detail) if detail else ''}")
    return ok


def main() -> int:
    sandbox_type = os.environ.get("SANDBOX_TYPE")
    if not sandbox_type:
        print("SANDBOX_TYPE env var required", file=sys.stderr)
        return 2

    print(f"Creating secure {sandbox_type} sandbox (this may take minutes)...")
    try:
        backend = get_secure_sandbox(sandbox_type)
    except KeyError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    print(f"  sandbox id: {backend.id}\n")

    all_ok = True
    try:
        # 1. execute echo
        print("[execute]")
        result = backend.execute("echo hello-from-secured")
        all_ok &= _check(
            "echo stdout",
            "hello-from-secured" in result.output,
            result.output.strip()[:60],
        )
        all_ok &= _check(
            "exit code == 0",
            result.exit_code == 0,
            str(result.exit_code),
        )

        # 2. write a file
        print("\n[write]")
        write_path = "/workspace/open-swe-smoke.txt"
        write_res = backend.write(write_path, "greetings from the bridge\n")
        all_ok &= _check(
            "policy-allowed write",
            write_res.error is None,
            write_res.error or "ok",
        )

        # 3. read it back
        print("\n[read]")
        read_res = backend.read(write_path)
        content_ok = (
            read_res.error is None
            and read_res.file_data is not None
            and "greetings" in read_res.file_data.get("content", "")
        )
        all_ok &= _check("content round-tripped", content_ok,
                         (read_res.error or "content matched"))

        # 4. edit (unique replace)
        print("\n[edit]")
        edit_res = backend.edit(write_path, "greetings", "salutations")
        all_ok &= _check(
            "edit applied",
            edit_res.error is None and edit_res.occurrences == 1,
            edit_res.error or f"{edit_res.occurrences} occurrence(s)",
        )

        # 5. read again to confirm edit
        read_res2 = backend.read(write_path)
        all_ok &= _check(
            "edit persisted",
            read_res2.error is None
            and "salutations" in (
                read_res2.file_data or {"content": ""}
            )["content"],
            "salutations visible",
        )

        # 6. upload + download round-trip
        print("\n[upload/download]")
        upload_path = "/workspace/upload-test.bin"
        uploads = backend.upload_files([(upload_path, b"\x01\x02\x03")])
        all_ok &= _check("upload returned no error",
                         uploads[0].error is None, uploads[0].error or "ok")
        downloads = backend.download_files([upload_path])
        all_ok &= _check(
            "download bytes match",
            downloads[0].content == b"\x01\x02\x03",
            repr(downloads[0].content)[:40],
        )

    finally:
        print("\nClosing backend...")
        backend.close()

    print("\n" + ("ALL PASS" if all_ok else "FAILED"))
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
```

- [ ] **Step 2: Syntax + import check (no network)**

Run: `python -c "import ast; ast.parse(open('examples/open_swe/demo_smoke_test.py').read())"`
Expected: no output, exit 0.

Also: `SANDBOX_TYPE= python examples/open_swe/demo_smoke_test.py; echo "exit=$?"`
Expected: error message "SANDBOX_TYPE env var required" on stderr, exit code 2.

And: `SANDBOX_TYPE=nonsense python examples/open_swe/demo_smoke_test.py; echo "exit=$?"`
Expected: KeyError message, exit 2.

- [ ] **Step 3: Commit**

```bash
git add examples/open_swe/demo_smoke_test.py
git commit -m "feat(open-swe): demo smoke test script

Exercises execute/read/write/edit/upload/download end-to-end against
a real provider. Driven by SANDBOX_TYPE env var; exits non-zero on any
op failure so it can gate CI or local validation."
```

---

## Task 14: `_patch_sandbox.py` — monkeypatch helper for open-swe forks

**Files:**
- Create: `examples/open_swe/_patch_sandbox.py`

- [ ] **Step 1: Create the patch helper**

Create `examples/open_swe/_patch_sandbox.py`:
```python
"""Monkeypatch deepagents' sandbox lookup to return a secure backend.

**Usage in your open-swe fork:**

1. Copy ``bridge.py``, ``factories.py``, and this file into your
   open-swe fork at ``agent/integrations/secure/``.
2. Update the imports in the copied files to match your package layout
   (typically ``from .bridge import ...`` and ``from .factories import ...``).
3. At process start — before the deepagents graph is built — call::

       from agent.integrations.secure._patch_sandbox import (
           patch_deepagents_get_sandbox,
       )
       patch_deepagents_get_sandbox()

4. Set ``SANDBOX_TYPE`` (and any provider env vars) before starting
   the agent.

The patch replaces :func:`deepagents.backends.get_sandbox` — the
factory deepagents calls whenever a node needs a sandbox — with a
wrapper that routes through our :func:`get_secure_sandbox`. This
does not touch deepagents source; removing the patch is as simple
as not importing this module.
"""
from __future__ import annotations

import os
from typing import Any

from .factories import get_secure_sandbox

_ORIGINAL = None


def patch_deepagents_get_sandbox(env_var: str = "SANDBOX_TYPE") -> None:
    """Patch deepagents' get_sandbox to return SecureSandboxBackend.

    Idempotent: calling twice is a no-op after the first call.

    :param env_var: environment variable used to select the provider.
        Defaults to ``SANDBOX_TYPE``. The value must be one of the keys
        in :data:`factories.SANDBOX_FACTORIES`.
    """
    global _ORIGINAL
    import deepagents.backends as backends_mod

    if _ORIGINAL is not None:
        return  # already patched

    _ORIGINAL = getattr(backends_mod, "get_sandbox", None)

    def _secure_get_sandbox(*args: Any, sandbox_id: str | None = None, **kwargs: Any) -> Any:
        sandbox_type = os.environ.get(env_var)
        if not sandbox_type:
            raise RuntimeError(
                f"{env_var} env var is required when using the "
                "secure-sandbox patch"
            )
        return get_secure_sandbox(sandbox_type, sandbox_id=sandbox_id)

    backends_mod.get_sandbox = _secure_get_sandbox


def unpatch_deepagents_get_sandbox() -> None:
    """Restore deepagents' original get_sandbox. Primarily for tests."""
    global _ORIGINAL
    if _ORIGINAL is None:
        return
    import deepagents.backends as backends_mod

    backends_mod.get_sandbox = _ORIGINAL
    _ORIGINAL = None
```

**Note on `deepagents.backends.get_sandbox`:** the exact name of the
factory function in deepagents' `backends` module is
`get_sandbox` based on the convention in the deepagents source. If
integration testing reveals a different name (e.g., `create_sandbox`,
`make_sandbox`), update the `_patch_sandbox.py` imports and patch
target accordingly. This is the only place in the plan that touches
deepagents' internals, so localized adjustments are expected during
initial use.

- [ ] **Step 2: Syntax check**

Run: `python -c "import ast; ast.parse(open('examples/open_swe/_patch_sandbox.py').read())"`
Expected: no output, exit 0.

- [ ] **Step 3: Commit**

```bash
git add examples/open_swe/_patch_sandbox.py
git commit -m "feat(open-swe): deepagents monkeypatch helper

Provides patch_deepagents_get_sandbox()/unpatch_deepagents_get_sandbox()
for installing the secure backend into a deepagents-based fork
without touching deepagents source. Reads SANDBOX_TYPE at patch time."
```

---

## Task 15: README

**Files:**
- Create: `examples/open_swe/README.md`

- [ ] **Step 1: Create the README**

Create `examples/open_swe/README.md`:
```markdown
# OpenSWE × secure-sandbox-py (worked example)

This directory contains a worked example of running
[OpenSWE](https://github.com/langchain-ai/open-swe) — LangChain's
open-source coding agent built on
[`deepagents`](https://github.com/langchain-ai/deepagents) — inside a
secure-sandbox-py-managed sandbox. Every command and file operation
the agent performs is enforced by agentsh's syscall-level policy.

## What you get

- **`bridge.py`** — a `SecureSandboxBackend` class that implements
  deepagents' `BaseSandbox` protocol on top of an async
  `SecuredSandbox`. Sync-to-async translation is handled by a
  private background event loop running on a daemon thread.
- **`factories.py`** — five provider factories:
  - `create_modal_sandbox`
  - `create_daytona_sandbox`
  - `create_runloop_sandbox`
  - `create_e2b_sandbox`
  - `create_freestyle_sandbox`
- **`demo_smoke_test.py`** — end-to-end runner exercising execute,
  read, write, edit, upload, and download against any of the above.
- **`_patch_sandbox.py`** — monkeypatch helper that swaps deepagents'
  built-in `get_sandbox` for one that returns a secure backend.

## Prerequisites

```bash
pip install -e '.[dev,modal,daytona,runloop,e2b]'
pip install deepagents
```

Set provider credentials per your needs:

| Provider  | Env vars                                                  |
|-----------|-----------------------------------------------------------|
| Modal     | `modal token set` (interactive) + `SECURE_MODAL_APP_NAME` |
| Daytona   | `DAYTONA_API_KEY`                                         |
| Runloop   | `RUNLOOP_API_KEY`                                         |
| E2B       | `E2B_API_KEY`                                             |
| Freestyle | `FREESTYLE_API_KEY`                                       |

## Quick smoke test

```bash
SANDBOX_TYPE=e2b python examples/open_swe/demo_smoke_test.py
```

Expected output:
```
Creating secure e2b sandbox (this may take minutes)...
  sandbox id: isxxxxxxxxxxxxxxxxxxx

[execute]
  [PASS] echo stdout — hello-from-secured
  [PASS] exit code == 0 — 0

... (read, write, edit, upload, download)

ALL PASS
```

Exits non-zero on any failure.

## Wiring into an open-swe fork

1. Clone [`langchain-ai/open-swe`](https://github.com/langchain-ai/open-swe).
2. Copy `bridge.py`, `factories.py`, and `_patch_sandbox.py` into your
   fork at `agent/integrations/secure/`.
3. Update relative imports to match the new location (replace
   `from .bridge import ...` and `from .factories import ...` with
   `from agent.integrations.secure.bridge import ...` etc.).
4. At process start — before the LangGraph/deepagents graph is built
   — call the patch:
   ```python
   from agent.integrations.secure._patch_sandbox import (
       patch_deepagents_get_sandbox,
   )
   patch_deepagents_get_sandbox()
   ```
5. Set `SANDBOX_TYPE=<provider>` and provider-specific env vars.
6. Run open-swe as usual. Every sandbox-backed operation now routes
   through agentsh.

## Architecture

```
┌──────────────────────────────────────────┐
│  deepagents graph (sync, in main thread) │
└───────────────────┬──────────────────────┘
                    │ execute(), read(), write(), ...
                    ▼
┌──────────────────────────────────────────┐
│  SecureSandboxBackend (sync facade)      │
│  - owns daemon-thread asyncio loop        │
│  - run_coroutine_threadsafe dispatch      │
└───────────────────┬──────────────────────┘
                    │ async
                    ▼
┌──────────────────────────────────────────┐
│  SecuredSandbox                           │
│  - exec / read_file / write_file          │
│  - every call flows through agentsh       │
└───────────────────┬──────────────────────┘
                    │ syscalls
                    ▼
┌──────────────────────────────────────────┐
│  Provider sandbox (Modal/Daytona/E2B/...) │
│  agentsh running as PID 1 → syscall gate  │
└──────────────────────────────────────────┘
```

## Known limitations (phase 1)

- **No reconnection by `sandbox_id`.** Each call to a factory creates
  a new sandbox. Persisting a secured session across process restarts
  is out of scope for phase 1. Phase 2 (a standalone installable
  package) will support reconnection.
- **Daytona teardown is not complete.** Daytona's `stop()` is a no-op;
  sandboxes remain until explicitly removed via `client.remove()`.
  `SecureSandboxBackend.close()` releases the event loop but does
  **not** remove the Daytona sandbox. You must track and clean up
  Daytona sandboxes separately if billing matters.
- **Freestyle cold starts can take 5+ minutes** on the first snapshot
  build. Subsequent creates hit the cache and are fast.
- **LangSmith managed mode is unsupported.** There is no public
  sandbox SDK for LangChain's hosted tier. Use one of the five
  supported providers instead.

## Hacking

Run the unit tests:
```bash
pytest tests/test_open_swe_bridge.py -xvs
```

All bridge tests run offline against a fake SecuredSandbox — no
provider credentials required. End-to-end validation lives in
`demo_smoke_test.py`.
```

- [ ] **Step 2: Commit**

```bash
git add examples/open_swe/README.md
git commit -m "docs(open-swe): README with setup, wiring, architecture, limitations"
```

---

## Task 16: Final polish + self-review

**Files:**
- Verify: full `pytest tests/test_open_swe_bridge.py -xvs` run
- Verify: `ruff check examples/open_swe/` if ruff is configured
- Verify: `mypy examples/open_swe/` if strict mypy is required

- [ ] **Step 1: Run the full test suite**

Run: `pytest tests/test_open_swe_bridge.py -xvs`
Expected: all 26 tests PASS (Task 1 × 1, Task 2 × 4, Task 3 × 4, Task 4 × 3, Task 5 × 2, Task 6 × 5, Task 7 × 1, Task 8 × 1, Task 9 × 1, Task 10 × 1, Task 11 × 1, Task 12 × 2).

- [ ] **Step 2: Lint check**

Run: `ruff check examples/open_swe/ tests/test_open_swe_bridge.py`
Expected: clean. Fix any issues (usually unused imports or long lines).

- [ ] **Step 3: Type check (best effort)**

Run: `mypy examples/open_swe/bridge.py`
Expected: either clean or a small number of untyped-import errors from `deepagents` (acceptable). Fix any type errors in our code.

Note: `examples/` is not in `pyproject.toml`'s mypy config, so strict mode may not apply. Ignore untyped-import errors for third-party SDKs; fix any genuine type errors in `bridge.py` itself.

- [ ] **Step 4: Commit any fix-up changes if needed**

If Steps 1–3 surfaced fixes, commit them with a single `chore: lint/type fix-ups` commit.

- [ ] **Step 5: Final validation — existing repo tests still pass**

Run: `pytest -xvs`
Expected: the full repo test suite passes. Our new test file should not interfere with any existing test (we don't modify `src/`, we only add `tests/test_open_swe_bridge.py` and `examples/open_swe/*`).

---

## Summary of commits (expected linear history)

```
feat(open-swe): make_backend helper + SecureSandboxBackend skeleton
feat(open-swe): implement SecureSandboxBackend.execute
feat(open-swe): upload_files + download_files
feat(open-swe): typed read() override
feat(open-swe): typed write() override
feat(open-swe): typed edit() override
feat(open-swe): factories skeleton + Modal factory
feat(open-swe): Daytona factory
feat(open-swe): Runloop factory
feat(open-swe): E2B factory
feat(open-swe): Freestyle factory
test(open-swe): get_secure_sandbox dispatch + error cases
feat(open-swe): demo smoke test script
feat(open-swe): deepagents monkeypatch helper
docs(open-swe): README with setup, wiring, architecture, limitations
chore(open-swe): lint/type fix-ups                           [optional]
```

16 commits, all green at each step. No commit touches `src/` or
`pyproject.toml`.

---

## Risks and mitigations

- **deepagents API drift.** Result types like `WriteResult` and
  `EditResult` use `@dataclass(init=False)` with custom `__init__`
  signatures. If deepagents renames a kwarg (e.g., `path` → `file_path`),
  the bridge's Result construction fails at runtime. Mitigation: test
  coverage in `test_write_*` and `test_edit_*` catches this
  immediately against whatever version of deepagents is installed.
  Pin deepagents in prerequisites to avoid surprise upgrades during
  development.
- **Provider SDK surface changes.** Modal / Daytona / Runloop / E2B
  / Freestyle SDKs all evolve independently. Each factory only uses
  the handful of methods documented in the existing
  `examples/*_pydantic_ai.py` files; if those break, the existing
  examples break too and we can fix both together. Mitigation: the
  import-only factory tests will never fail for SDK breakage (they
  don't execute the factory body), so live SDK validation relies on
  `demo_smoke_test.py`.
- **Modal sandbox creation is synchronous.** Called from inside an
  async `_init`, it blocks the background loop for ~30–60s. This is
  acceptable because the main thread is already blocked waiting on
  `make_backend`'s `.result()`. Nothing else is scheduled on the
  background loop at that point.
- **Background threads may not clean up if `SecureSandboxBackend.close()`
  isn't called.** The `__del__` fallback is best-effort; if the
  process exits abruptly it may leak the thread. Mitigation: document
  calling `close()` explicitly in the README and smoke test. For
  `try/finally` usage in the smoke test, this is sufficient.
- **`_patch_sandbox.py` targets `deepagents.backends.get_sandbox`.**
  If the real deepagents module exposes a different function name,
  the patch fails at import time (AttributeError). Mitigation:
  documented in Task 14 — localized fix during first integration.

## Out of scope (phase 2+)

- Standalone installable package (`pip install agentsh-secure-sandbox-open-swe`).
- Reconnection by `sandbox_id` across process restarts.
- LangSmith managed mode (no public SDK).
- Complete Daytona teardown (requires tracking the `Daytona` client).
- Snapshot / checkpoint support (Modal, Runloop, etc. all offer
  different checkpoint APIs that don't fit under a uniform factory).
