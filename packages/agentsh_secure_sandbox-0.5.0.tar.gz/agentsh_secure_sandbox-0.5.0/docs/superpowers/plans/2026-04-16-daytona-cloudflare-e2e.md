# Daytona And Cloudflare E2E Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the Daytona and Cloudflare e2e harness accurately reflect the latest OpenAI Agents SDK requirements while preserving the repo's existing non-OpenAI integration paths.

**Architecture:** Keep the fix at the packaging, env-gating, and harness layers. Daytona will be dual-supported by installing both Python SDKs and splitting readiness checks between the repo path and the OpenAI path. Cloudflare will stop overloading one worker URL for two different contracts by keeping the legacy exec worker URL and adding a dedicated sandbox-service worker URL for the OpenAI SDK path.

**Tech Stack:** Python 3.11+, `pytest`, `pytest-asyncio`, `tomllib`, `python-dotenv`, `openai-agents`, `daytona-sdk`, `daytona`

---

## File Map

- Modify: `pyproject.toml`
  - Expand the `daytona` extra to install both `daytona-sdk` and `daytona`.
- Modify: `tests/e2e/conftest.py`
  - Add `CLOUDFLARE_SANDBOX_WORKER_URL`.
  - Split Daytona and Cloudflare availability into repo-path and OpenAI-path helpers.
  - Add explicit skip markers for OpenAI Daytona and OpenAI Cloudflare.
- Modify: `tests/e2e/test_openai_sandbox_sessions.py`
  - Switch OpenAI Daytona to the OpenAI-specific skip marker.
  - Switch OpenAI Cloudflare to the sandbox-worker env var and OpenAI-specific skip marker.
- Modify: `tests/e2e/test_daytona.py`
  - Keep it on the generic Daytona skip marker backed by the repo-path helper.
- Modify: `tests/e2e/test_cloudflare.py`
  - Keep it on the legacy exec-worker env var and generic Cloudflare skip marker.
- Create: `tests/test_package_metadata.py`
  - Assert the `daytona` extra installs both packages.
- Create: `tests/test_e2e_conftest.py`
  - Unit tests for the new Daytona and Cloudflare availability helpers.
- Modify: `README.md`
  - Clarify Daytona extra behavior.
  - Clarify that `SecureSandboxAgentTools` usage is separate from OpenAI `SandboxAgent` provider wrappers.
  - Document `CLOUDFLARE_SANDBOX_WORKER_URL` for OpenAI Cloudflare e2e.

### Task 1: Add package metadata coverage for Daytona dual-support

**Files:**
- Create: `tests/test_package_metadata.py`
- Modify: `pyproject.toml`
- Test: `tests/test_package_metadata.py`

- [ ] **Step 1: Write the failing metadata test**

```python
from pathlib import Path
import tomllib


def test_daytona_extra_installs_both_sdks() -> None:
    data = tomllib.loads(Path("pyproject.toml").read_text())
    deps = data["project"]["optional-dependencies"]["daytona"]

    assert "daytona-sdk>=0.10" in deps
    assert any(dep.startswith("daytona>=") for dep in deps)
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `uv run pytest tests/test_package_metadata.py::test_daytona_extra_installs_both_sdks -v`

Expected: FAIL on the `daytona>=...` assertion because `pyproject.toml` only lists `daytona-sdk>=0.10`.

- [ ] **Step 3: Update the Daytona extra to install both packages**

```toml
[project.optional-dependencies]
daytona = [
    "daytona-sdk>=0.10",
    "daytona>=0.19",
]
```

- [ ] **Step 4: Run the test to verify it passes**

Run: `uv run pytest tests/test_package_metadata.py::test_daytona_extra_installs_both_sdks -v`

Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add pyproject.toml tests/test_package_metadata.py
git commit -m "build: install both Daytona Python SDKs"
```

### Task 2: Split Daytona and Cloudflare availability helpers in the e2e harness

**Files:**
- Create: `tests/test_e2e_conftest.py`
- Modify: `tests/e2e/conftest.py`
- Test: `tests/test_e2e_conftest.py`

- [ ] **Step 1: Write failing tests for the new helper split**

```python
from tests.e2e import conftest as e2e_conf


def _env(**overrides: str) -> dict[str, str]:
    env = {
        "DAYTONA_API_KEY": "",
        "CLOUDFLARE_WORKER_URL": "",
        "CLOUDFLARE_SANDBOX_WORKER_URL": "",
        "CLOUDFLARE_API_TOKEN": "",
    }
    env.update(overrides)
    return env


def test_daytona_repo_available_accepts_legacy_sdk(monkeypatch) -> None:
    monkeypatch.setattr(e2e_conf, "_sdk_available", lambda name: name == "daytona_sdk")
    env = _env(DAYTONA_API_KEY="dtn_test")

    assert e2e_conf._daytona_repo_available(env) is True
    assert e2e_conf._daytona_openai_available(env) is False


def test_daytona_openai_available_requires_new_sdk(monkeypatch) -> None:
    monkeypatch.setattr(e2e_conf, "_sdk_available", lambda name: name == "daytona")
    env = _env(DAYTONA_API_KEY="dtn_test")

    assert e2e_conf._daytona_openai_available(env) is True


def test_cloudflare_exec_available_uses_legacy_url(monkeypatch) -> None:
    monkeypatch.setattr(e2e_conf, "_sdk_available", lambda name: name == "aiohttp")
    env = _env(
        CLOUDFLARE_WORKER_URL="https://exec.example.workers.dev",
        CLOUDFLARE_API_TOKEN="token",
    )

    assert e2e_conf._cloudflare_exec_available(env) is True
    assert e2e_conf._cloudflare_sandbox_available(env) is False


def test_cloudflare_sandbox_available_requires_sandbox_url(monkeypatch) -> None:
    monkeypatch.setattr(e2e_conf, "_sdk_available", lambda name: name == "aiohttp")
    env = _env(
        CLOUDFLARE_WORKER_URL="https://exec.example.workers.dev",
        CLOUDFLARE_SANDBOX_WORKER_URL="https://sandbox.example.workers.dev",
        CLOUDFLARE_API_TOKEN="token",
    )

    assert e2e_conf._cloudflare_sandbox_available(env) is True
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/test_e2e_conftest.py -v`

Expected: FAIL with `AttributeError` because `_daytona_repo_available`, `_daytona_openai_available`, `_cloudflare_exec_available`, and `_cloudflare_sandbox_available` do not exist yet.

- [ ] **Step 3: Add the helpers, env key, and split skip markers**

```python
def _daytona_repo_available(env: dict[str, str]) -> bool:
    return (_sdk_available("daytona_sdk") or _sdk_available("daytona")) and bool(
        env["DAYTONA_API_KEY"]
    )


def _daytona_openai_available(env: dict[str, str]) -> bool:
    return _sdk_available("daytona") and bool(env["DAYTONA_API_KEY"])


def _cloudflare_exec_available(env: dict[str, str]) -> bool:
    return (
        _sdk_available("aiohttp")
        and bool(env["CLOUDFLARE_WORKER_URL"])
        and bool(env["CLOUDFLARE_API_TOKEN"])
    )


def _cloudflare_sandbox_available(env: dict[str, str]) -> bool:
    return (
        _sdk_available("aiohttp")
        and bool(env["CLOUDFLARE_SANDBOX_WORKER_URL"])
        and bool(env["CLOUDFLARE_API_TOKEN"])
    )


def _build_env() -> dict[str, str]:
    return {
        "DAYTONA_API_KEY": os.environ.get("DAYTONA_API_KEY", ""),
        "DAYTONA_API_URL": os.environ.get("DAYTONA_API_URL", ""),
        "DAYTONA_TARGET": os.environ.get("DAYTONA_TARGET", ""),
        "CLOUDFLARE_WORKER_URL": os.environ.get("CLOUDFLARE_WORKER_URL", ""),
        "CLOUDFLARE_SANDBOX_WORKER_URL": os.environ.get("CLOUDFLARE_SANDBOX_WORKER_URL", ""),
        "CLOUDFLARE_API_TOKEN": os.environ.get("CLOUDFLARE_API_TOKEN", ""),
        # ...existing keys...
    }


daytona_available = _daytona_repo_available(ENV)
openai_daytona_available = _daytona_openai_available(ENV)
cloudflare_available = _cloudflare_exec_available(ENV)
openai_cloudflare_available = _cloudflare_sandbox_available(ENV)

skip_no_daytona = pytest.mark.skipif(
    not daytona_available,
    reason="daytona_sdk/daytona or DAYTONA_API_KEY missing",
)
skip_no_openai_daytona = pytest.mark.skipif(
    not openai_daytona_available,
    reason="daytona or DAYTONA_API_KEY missing",
)
skip_no_cloudflare = pytest.mark.skipif(
    not cloudflare_available,
    reason="CLOUDFLARE_WORKER_URL or CLOUDFLARE_API_TOKEN missing",
)
skip_no_openai_cloudflare = pytest.mark.skipif(
    not openai_cloudflare_available,
    reason="CLOUDFLARE_SANDBOX_WORKER_URL or CLOUDFLARE_API_TOKEN missing",
)
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `uv run pytest tests/test_e2e_conftest.py -v`

Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add tests/e2e/conftest.py tests/test_e2e_conftest.py
git commit -m "test: split Daytona and Cloudflare e2e availability"
```

### Task 3: Wire the OpenAI e2e session matrix to the correct Daytona and Cloudflare contracts

**Files:**
- Modify: `tests/e2e/test_openai_sandbox_sessions.py`
- Test: `tests/e2e/test_daytona.py`
- Test: `tests/e2e/test_cloudflare.py`
- Test: `tests/e2e/test_openai_sandbox_sessions.py`

- [ ] **Step 1: Update the OpenAI session tests to use the new skip markers and sandbox URL**

```python
from tests.e2e.conftest import (
    ENV,
    cloudflare_sandbox_route_missing,
    require_exe_vm_available,
    require_sprites_command_endpoint,
    skip_no_blaxel,
    skip_no_cloudflare,
    skip_no_daytona,
    skip_no_e2b,
    skip_no_exe,
    skip_no_freestyle,
    skip_no_modal,
    skip_no_openai_cloudflare,
    skip_no_openai_daytona,
    skip_no_runloop,
    skip_no_sprites,
    skip_no_vercel,
)


@skip_no_openai_daytona
async def test_openai_sandbox_session_daytona() -> None:
    ...


@skip_no_openai_cloudflare
async def test_openai_sandbox_session_cloudflare() -> None:
    ...
    options = CloudflareSandboxClientOptions(
        worker_url=ENV["CLOUDFLARE_SANDBOX_WORKER_URL"],
        api_key=ENV["CLOUDFLARE_API_TOKEN"],
    )
```

- [ ] **Step 2: Leave the legacy Daytona and Cloudflare tests untouched and rely on the existing repo-path markers**

```python
# No code change in the legacy files for this task.
# tests/e2e/test_daytona.py should continue importing skip_no_daytona.
# tests/e2e/test_cloudflare.py should continue using CLOUDFLARE_WORKER_URL.
```

- [ ] **Step 3: Run the targeted e2e slice**

Run:

```bash
AGENTSH_E2E_ENV_FILES='/home/eran/work/canyonroad/agentsh-secure-sandbox-py/.env:/home/eran/work/canyonroad/secure-sandbox/.env.e2e:/home/eran/work/agentsh/.env' \
uv run pytest tests/e2e/test_daytona.py tests/e2e/test_cloudflare.py tests/e2e/test_openai_sandbox_sessions.py -k 'daytona or cloudflare' -q -rs
```

Expected:
- repo Daytona tests remain runnable on the repo-path SDK
- repo Cloudflare tests remain runnable on `CLOUDFLARE_WORKER_URL`
- OpenAI Daytona now skips only when `daytona` is missing
- OpenAI Cloudflare now skips only when `CLOUDFLARE_SANDBOX_WORKER_URL` is missing, or runs against that URL if present

- [ ] **Step 4: If the targeted run fails, fix only the harness contract mismatch**

```python
# Keep the behavior change narrow:
# - no adapter changes
# - no provider runtime changes
# - no fallback from CLOUDFLARE_SANDBOX_WORKER_URL back to CLOUDFLARE_WORKER_URL
```

- [ ] **Step 5: Commit**

```bash
git add tests/e2e/test_openai_sandbox_sessions.py
git commit -m "test: separate OpenAI Daytona and Cloudflare e2e contracts"
```

### Task 4: Update README guidance for Daytona dual-SDK support and Cloudflare worker roles

**Files:**
- Modify: `README.md`
- Test: `README.md` via targeted grep checks

- [ ] **Step 1: Clarify the install and integration story in the README**

```md
### OpenAI Agents SDK SandboxAgent

`SecureSandboxAgentTools` and the beta OpenAI `SandboxAgent` runtime are
different integration paths.

- `SecureSandboxAgentTools` continues to work with the repo's direct provider
  adapters, including the existing Daytona examples that use `daytona_sdk`.
- The OpenAI `SandboxAgent` Daytona provider wrapper depends on the newer
  `daytona` Python package required by the upstream OpenAI Agents SDK.
```

- [ ] **Step 2: Document the Cloudflare env split in the e2e section**

```md
For Cloudflare e2e:

- `CLOUDFLARE_WORKER_URL` is the legacy exec-proxy worker used by the repo's
  direct Cloudflare adapter tests.
- `CLOUDFLARE_SANDBOX_WORKER_URL` is the sandbox-service worker URL required by
  the OpenAI Agents SDK Cloudflare backend (`POST /v1/sandbox`).
```

- [ ] **Step 3: Verify the README contains the new guidance**

Run:

```bash
rg -n "daytona_sdk|SandboxAgent|CLOUDFLARE_SANDBOX_WORKER_URL|CLOUDFLARE_WORKER_URL" README.md
```

Expected: the README now contains the dual-SDK Daytona note and the split Cloudflare env var guidance.

- [ ] **Step 4: Run the full verification set**

Run:

```bash
uv run ruff check .
uv run pytest -q
AGENTSH_E2E_ENV_FILES='/home/eran/work/canyonroad/agentsh-secure-sandbox-py/.env:/home/eran/work/canyonroad/secure-sandbox/.env.e2e:/home/eran/work/agentsh/.env' uv run pytest tests/e2e -q -rs
```

Expected:
- `ruff check .` passes
- `pytest -q` passes
- `tests/e2e` passes or skips only on genuine missing SDK/env/provider endpoint conditions

- [ ] **Step 5: Commit**

```bash
git add README.md
git commit -m "docs: clarify Daytona and Cloudflare OpenAI e2e requirements"
```

## Self-Review

- **Spec coverage:** The plan covers both approved design axes:
  - Daytona dual-support via packaging plus split repo/OpenAI readiness
  - Cloudflare env separation between exec worker and sandbox worker
- **Placeholder scan:** No `TBD`, `TODO`, or abstract “handle appropriately” steps remain.
- **Type consistency:** The plan consistently uses:
  - `_daytona_repo_available`
  - `_daytona_openai_available`
  - `_cloudflare_exec_available`
  - `_cloudflare_sandbox_available`
  - `skip_no_openai_daytona`
  - `skip_no_openai_cloudflare`
