# agentsh v0.18.2-rc1 Upgrade Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Upgrade the pinned `agentsh` runtime to `v0.18.2-rc1` and verify the library still works across the full local test and e2e matrix.

**Architecture:** Keep the change scoped to the existing `agentsh` pinning and provisioning paths. Update the canonical version/checksum metadata first, then align provider-specific baked defaults that embed the runtime version, and finally run the full automated matrix to catch rc regressions before shipping.

**Tech Stack:** Python, Hatch/uv, pytest, real-provider e2e integrations, GitHub-hosted `agentsh` release artifacts.

---

### Task 1: Update pinned runtime metadata

**Files:**
- Modify: `src/agentsh_secure_sandbox/core/integrity.py`
- Test: `tests/test_integrity.py`

- [ ] **Step 1: Update the pinned `agentsh` version and release checksums**

Set `PINNED_VERSION` to `0.18.2-rc1` and replace the `CHECKSUMS` entry with the real release checksums for `linux_amd64` and `linux_arm64` from the published `agentsh` `v0.18.2-rc1` release assets.

- [ ] **Step 2: Align integrity tests with the new release**

Update the hard-coded expectations in `tests/test_integrity.py` so the tests assert the new version string, release URL, and checksum values.

- [ ] **Step 3: Run the focused integrity tests**

Run: `uv run pytest tests/test_integrity.py -q`

Expected: all integrity tests pass against the new pinned release.

### Task 2: Align baked provider defaults and version references

**Files:**
- Modify: `src/agentsh_secure_sandbox/adapters/freestyle/_defaults.py`
- Modify: `tests/test_freestyle_defaults.py`
- Modify: `tests/test_freestyle_client.py`
- Modify: any other source/tests that hard-code `0.18.0` or `0.18.1` as the active runtime expectation

- [ ] **Step 1: Update baked-in freestyle defaults**

Change the default `agentsh_version` and any adjacent version-specific comments in `src/agentsh_secure_sandbox/adapters/freestyle/_defaults.py` from the old `0.18.x` value to `0.18.2-rc1`.

- [ ] **Step 2: Update version-sensitive tests**

Adjust `tests/test_freestyle_defaults.py`, `tests/test_freestyle_client.py`, and any other direct version assertions so they reflect `0.18.2-rc1` while preserving the override behavior checks.

- [ ] **Step 3: Run the focused provider-version tests**

Run: `uv run pytest tests/test_freestyle_defaults.py tests/test_freestyle_client.py tests/test_provision.py -q`

Expected: the version-sensitive provisioning/default tests pass.

### Task 3: Run the full verification matrix and fix fallout

**Files:**
- Modify: whichever implementation/tests fail under `v0.18.2-rc1`

- [ ] **Step 1: Run the full non-e2e suite**

Run: `uv run --with-editable . --all-extras --with python-dotenv --with pytest --with pytest-asyncio --with pytest-timeout python -m pytest -q`

Expected: suite passes or reveals rc-specific regressions to fix.

- [ ] **Step 2: Fix any regressions minimally**

If failures appear, patch only the code/tests directly affected by the `agentsh` rc behavior change, then rerun the smallest failing slice first before returning to the full suite.

- [ ] **Step 3: Run the full live e2e suite**

Run:

```bash
set -a
source /home/eran/work/canyonroad/agentsh-secure-sandbox-py/.env >/dev/null 2>&1
source /home/eran/work/canyonroad/daytona-test/.env >/dev/null 2>&1
source /home/eran/work/canyonroad/agentsh-agentdojo/.env >/dev/null 2>&1 || true
export CLOUDFLARE_SANDBOX_WORKER_URL=${CLOUDFLARE_SANDBOX_WORKER_URL:-https://agentsh-cloudflare.eran-e6a.workers.dev}
set +a
uv run --with-editable . --all-extras --with python-dotenv --with pytest --with pytest-asyncio --with pytest-timeout python -m pytest tests/e2e -q -rs
```

Expected: the e2e matrix passes with only the known environment/capability skips.

- [ ] **Step 4: Commit the upgrade**

Commit message: `chore: upgrade agentsh to v0.18.2-rc1`
