# OpenSWE Integration — Design

**Date:** 2026-04-11
**Status:** Approved for implementation planning
**Phase:** 1 of 2 — worked example (phase 2 = standalone package)

## Goal

Show how to plug `agentsh-secure-sandbox-py` into LangChain's
[OpenSWE](https://github.com/langchain-ai/open-swe) so that the agentsh policy
engine sits between the agent and any of five sandbox providers (Daytona, Modal,
Runloop, E2B, Freestyle). Three of those providers (Daytona, Modal, Runloop)
overlap with OpenSWE's built-in support; the other two (E2B, Freestyle) extend
OpenSWE's universe to providers it doesn't ship out of the box.

## Background

### How OpenSWE selects a sandbox

OpenSWE doesn't define its own sandbox interface. The contract lives in
`langchain-ai/deepagents`:

- **Protocol**: `deepagents.backends.protocol.SandboxBackendProtocol`
- **Convenience base**: `deepagents.backends.sandbox.BaseSandbox`

A backend must implement, at minimum:
- `execute(command: str, *, timeout: int | None = None) -> ExecuteResponse`
  where `ExecuteResponse(output: str, exit_code: int, truncated: bool)`
- `id: str` property
- File ops: `ls`, `read`, `write`, `edit`, `glob`, `grep` — all auto-delegated
  to `execute()` if you extend `BaseSandbox`.

The interface is **synchronous**.

OpenSWE selects a provider via the `SANDBOX_TYPE` environment variable, looked
up in a `SANDBOX_FACTORIES` dict at `agent/utils/sandbox.py`. Each existing
factory in `agent/integrations/<provider>.py` is a thin (~10–15 line) wrapper
that imports a provider class from a `langchain_<provider>` partner package and
returns it from a `create_<provider>_sandbox(sandbox_id: str | None = None)`
function.

### How secure-sandbox-py wraps a provider

Each provider exposes an async `SandboxAdapter` (`exec`, `read_file`,
`write_file`). `secure_sandbox(adapter)` provisions agentsh inside the sandbox
and returns a `SecuredSandbox` whose every operation is policy-mediated.

### The mismatch

- OpenSWE/deepagents: **sync**, single `output` string per command, file ops
  delegated through `execute()` by default.
- secure-sandbox-py: **async**, separate `stdout`/`stderr`/`exit_code`,
  policy-aware typed file API.

The bridge collapses the mismatch in one small class.

## Provider coverage

| Provider | OpenSWE built-in | secure-sandbox-py | This integration |
|---|---|---|---|
| Daytona | yes | yes | included |
| Modal | yes | yes | included |
| Runloop | yes | yes | included |
| LangSmith | yes | no | **excluded** (no public SDK) |
| Local | yes (dev only) | n/a | not applicable |
| E2B | no | yes | included (extends OpenSWE) |
| Freestyle | no | yes | included (extends OpenSWE) |
| Cloudflare/Vercel/Blaxel/Sprites/exe.dev | no | yes | deferred to phase 2 |

## File layout

A new `examples/open_swe/` subdirectory in `agentsh-secure-sandbox-py`:

```
examples/open_swe/
├── README.md              setup, wiring, verification
├── bridge.py              SecureSandboxBackend(BaseSandbox)
├── factories.py           5 create_secure_*_sandbox() factories
├── demo_smoke_test.py     standalone runnable; verifies bridge satisfies protocol
└── _patch_sandbox.py      copy-paste-ready snippet for open-swe's agent/utils/sandbox.py
                           (a snippet, not something we run; lives next to README)
```

This deviates from the existing flat `examples/<provider>_<framework>.py`
convention because the bridge class is shared across all five factories.
Duplicating it five times into self-contained scripts would be worse.

## Architecture — the bridge class

```python
# examples/open_swe/bridge.py
import asyncio
import threading
from contextlib import suppress

from deepagents.backends.sandbox import BaseSandbox
from deepagents.backends.protocol import ExecuteResponse

from agentsh_secure_sandbox import secure_sandbox
from agentsh_secure_sandbox.core.types import SandboxAdapter, SecuredSandbox


class SecureSandboxBackend(BaseSandbox):
    """Adapt an async secure-sandbox-py SecuredSandbox to deepagents' sync protocol.

    deepagents calls execute()/read()/write() synchronously. We run a dedicated
    background asyncio loop on a worker thread and dispatch each call onto it
    via run_coroutine_threadsafe. One loop per backend instance; lives for the
    sandbox's lifetime; torn down in close().
    """

    def __init__(self, adapter: SandboxAdapter, *, id: str):
        self._id = id

        self._loop = asyncio.new_event_loop()
        self._loop_thread = threading.Thread(
            target=self._loop.run_forever,
            name=f"secure-sandbox-loop-{id}",
            daemon=True,
        )
        self._loop_thread.start()

        # Provisioning happens on the background loop, synchronously from caller's POV.
        self._sb: SecuredSandbox = self._run(secure_sandbox(adapter))

    @property
    def id(self) -> str:
        return self._id

    def _run(self, coro):
        return asyncio.run_coroutine_threadsafe(coro, self._loop).result()

    # --- SandboxBackendProtocol -----------------------------------------------

    def execute(self, command: str, *, timeout: int | None = None) -> ExecuteResponse:
        result = self._run(self._sb.exec("bash", ["-lc", command]))
        output = result.stdout
        if result.stderr:
            output = f"{output}\n{result.stderr}" if output else result.stderr
        return ExecuteResponse(
            output=output,
            exit_code=result.exit_code,
            truncated=False,
        )

    # --- typed file ops (override BaseSandbox shell delegation) ---------------

    def read(self, path: str) -> str:
        result = self._run(self._sb.read_file(path))
        if not result.success:
            raise PermissionError(f"read denied by policy: {result.error}")
        return result.content

    def write(self, path: str, content: str) -> None:
        result = self._run(self._sb.write_file(path, content))
        if not result.success:
            raise PermissionError(f"write denied by policy: {result.error}")

    # ls/glob/grep inherited from BaseSandbox -> shell via execute()
    # edit() inherited from BaseSandbox; since BaseSandbox.edit is a
    # read->modify->write loop, our overridden read/write apply automatically.

    # --- lifecycle ------------------------------------------------------------

    def close(self) -> None:
        with suppress(Exception):
            self._loop.call_soon_threadsafe(self._loop.stop)
        self._loop_thread.join(timeout=2.0)

    def __del__(self):
        with suppress(Exception):
            self.close()
```

### Design decisions in the bridge

1. **Background loop, not `asyncio.run` per call.** Per-call `asyncio.run`
   creates and destroys a loop each time (~5–20 ms overhead) and can't share
   state. The background-loop pattern lets the agentsh client reuse connections
   across the hundreds of commands an OpenSWE session runs.

2. **stderr concatenated into `output`.** `ExecuteResponse.output` is a single
   string. We always concat stdout + stderr so the agent sees both. Daytona's
   adapter already merges streams; the others split them.

3. **`read/write` raise `PermissionError` on policy denial** (rather than
   returning an error string). Matches Python convention. If verification step 1
   shows deepagents prefers structured error returns, switch to that.

4. **No explicit `provision()` method.** Provisioning is implicit in
   `secure_sandbox(adapter)` during `__init__`. The constructor blocks until
   agentsh is installed (~5–15s on first run, depending on provider).

5. **`close()` and `__del__`.** End the background thread cleanly. `__del__` is
   the safety net.

## Architecture — factories

Five thin factories. Each follows OpenSWE's existing convention so registering
them in `SANDBOX_FACTORIES` is symmetric with the built-in providers.

```python
# examples/open_swe/factories.py
from .bridge import SecureSandboxBackend


def create_secure_daytona_sandbox(sandbox_id: str | None = None):
    from daytona_sdk import Daytona
    from agentsh_secure_sandbox.adapters.daytona import daytona

    client = Daytona()
    raw = client.get(sandbox_id) if sandbox_id else client.create()
    return SecureSandboxBackend(daytona(raw), id=raw.id)


def create_secure_modal_sandbox(sandbox_id: str | None = None):
    import modal
    from agentsh_secure_sandbox.adapters.modal import modal as modal_adapter

    # Match open-swe's convention exactly: app must exist out-of-band.
    # User overrides via SECURE_MODAL_APP_NAME env var (separate from open-swe's
    # MODAL_APP_NAME so the secure variant can run alongside the unsecured one).
    import os
    app_name = os.getenv("SECURE_MODAL_APP_NAME", "agentsh-secure-sandbox-open-swe")
    app = modal.App.lookup(app_name)
    raw = (
        modal.Sandbox.from_id(sandbox_id, app=app)
        if sandbox_id
        else modal.Sandbox.create(app=app)
    )
    return SecureSandboxBackend(modal_adapter(raw), id=raw.object_id)


def create_secure_runloop_sandbox(sandbox_id: str | None = None):
    from runloop_api_client import Runloop
    from agentsh_secure_sandbox.adapters.runloop import runloop as runloop_adapter

    client = Runloop()
    devbox = (
        client.devboxes.retrieve(sandbox_id)
        if sandbox_id
        else client.devboxes.create_and_await_running()
    )
    return SecureSandboxBackend(
        runloop_adapter({"client": client, "id": devbox.id}),
        id=devbox.id,
    )


def create_secure_e2b_sandbox(sandbox_id: str | None = None):
    from e2b import Sandbox
    from agentsh_secure_sandbox.adapters.e2b import e2b as e2b_adapter

    raw = Sandbox.connect(sandbox_id) if sandbox_id else Sandbox.create()
    return SecureSandboxBackend(e2b_adapter(raw), id=raw.sandbox_id)


def create_secure_freestyle_sandbox(sandbox_id: str | None = None):
    from freestyle import Freestyle
    from agentsh_secure_sandbox.adapters.freestyle import freestyle as freestyle_adapter

    client = Freestyle()
    vm = client.vms.get(sandbox_id) if sandbox_id else client.vms.create()
    return SecureSandboxBackend(freestyle_adapter(vm), id=vm.id)
```

| Provider | Native client | New vs reconnect | ID attribute |
|---|---|---|---|
| Daytona | `Daytona()` | `client.create()` / `client.get(id)` | `raw.id` |
| Modal | `modal.App.lookup` | `Sandbox.create(app=app)` / `Sandbox.from_id(id, app=app)` | `raw.object_id` |
| Runloop | `Runloop()` | `client.devboxes.create_and_await_running()` / `client.devboxes.retrieve(id)` | `devbox.id` |
| E2B | (module level) | `Sandbox.create()` / `Sandbox.connect(id)` | `raw.sandbox_id` |
| Freestyle | `Freestyle()` | `client.vms.create()` / `client.vms.get(id)` | `vm.id` |

Each provider's exact SDK construction code is verified at implementation time
against the matching `examples/<provider>_pydantic_ai.py` in this repo, which is
already known to work.

**Modal app name collision:** OpenSWE's existing Modal factory uses
`MODAL_APP_NAME` env var with default `"open-swe"`. The secure variant uses a
**separate** env var `SECURE_MODAL_APP_NAME` with default
`"agentsh-secure-sandbox-open-swe"` so both factories can be registered in the
same `SANDBOX_FACTORIES` dict without conflict. The user must create the Modal
app out-of-band before first use (matches open-swe's existing convention —
`modal.App.lookup` does not create).

## Wiring into OpenSWE

The integration model is **copy-paste**, not a Python import from the
secure-sandbox-py examples directory. Users:

1. `pip install agentsh-secure-sandbox` and any provider SDKs they need into
   the open-swe environment.
2. Copy `bridge.py` and `factories.py` from `agentsh-secure-sandbox-py/examples/open_swe/`
   into their open-swe fork at `agent/integrations/secure/` (a new directory),
   creating an `__init__.py`. This puts the bridge alongside open-swe's
   existing `agent/integrations/{daytona,modal,runloop,langsmith,local}.py`
   files.
3. Patch `agent/utils/sandbox.py` to register the five factories. We ship
   `_patch_sandbox.py` as a copy-paste source (formatted to match the open-swe
   import path that results from step 2):

```python
# examples/open_swe/_patch_sandbox.py
# Paste these lines into open-swe's agent/utils/sandbox.py.
# Assumes you've copied bridge.py and factories.py to agent/integrations/secure/
# with an __init__.py.
from agent.integrations.secure.factories import (
    create_secure_daytona_sandbox,
    create_secure_modal_sandbox,
    create_secure_runloop_sandbox,
    create_secure_e2b_sandbox,
    create_secure_freestyle_sandbox,
)

SANDBOX_FACTORIES["secure_daytona"]   = create_secure_daytona_sandbox
SANDBOX_FACTORIES["secure_modal"]     = create_secure_modal_sandbox
SANDBOX_FACTORIES["secure_runloop"]   = create_secure_runloop_sandbox
SANDBOX_FACTORIES["secure_e2b"]       = create_secure_e2b_sandbox
SANDBOX_FACTORIES["secure_freestyle"] = create_secure_freestyle_sandbox
```

The user then sets `SANDBOX_TYPE=secure_daytona` (or any other) and open-swe
runs with policy enforcement.

This copy-paste model is intentional for the example phase: it has zero
import-path mysteries and matches open-swe's existing convention of one
integration file per provider type. The phase-2 package replaces it with
`pip install` + a one-line factory registration.

Note that `bridge.py`'s relative import `from .bridge import SecureSandboxBackend`
in `factories.py` works after the copy because both files land in the same
`agent/integrations/secure/` directory as a Python package. In the
secure-sandbox-py source location, they also work as a package because
`examples/open_swe/` will get an `__init__.py` so `python -m
examples.open_swe.demo_smoke_test` resolves the relative imports correctly.

The README lists the credential env vars per provider and how to choose an
agentsh policy preset (e.g. `agent_default`, `dev_safe`, `ci_strict`).

## Smoke test

```python
# examples/open_swe/demo_smoke_test.py
"""Verify SecureSandboxBackend satisfies deepagents' SandboxBackendProtocol.

This is a runnable demo, not a pytest. It needs real provider credentials.
Run from repo root:

    python -m examples.open_swe.demo_smoke_test --provider daytona
"""
import argparse
import sys
from .factories import (
    create_secure_daytona_sandbox,
    create_secure_modal_sandbox,
    create_secure_runloop_sandbox,
    create_secure_e2b_sandbox,
    create_secure_freestyle_sandbox,
)

FACTORIES = {
    "daytona":   create_secure_daytona_sandbox,
    "modal":     create_secure_modal_sandbox,
    "runloop":   create_secure_runloop_sandbox,
    "e2b":       create_secure_e2b_sandbox,
    "freestyle": create_secure_freestyle_sandbox,
}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--provider", choices=FACTORIES, default="daytona")
    args = p.parse_args()

    print(f"[1/5] Provisioning {args.provider} sandbox (this can take ~10s)...")
    backend = FACTORIES[args.provider]()
    print(f"      id: {backend.id}")

    try:
        print("[2/5] execute('uname -a')")
        r = backend.execute("uname -a")
        assert r.exit_code == 0, f"unexpected exit {r.exit_code}: {r.output}"
        print(f"      output: {r.output.strip()}")

        print("[3/5] typed write/read roundtrip")
        backend.write("/tmp/secure_demo.txt", "hello from open-swe")
        content = backend.read("/tmp/secure_demo.txt")
        assert content == "hello from open-swe", f"got {content!r}"
        print("      OK")

        print("[4/5] policy denial: write to /etc/passwd should raise")
        try:
            backend.write("/etc/passwd", "boom")
            print("      UNEXPECTED: write to /etc/passwd was allowed", file=sys.stderr)
            sys.exit(2)
        except PermissionError as e:
            print(f"      OK: {e}")

        print("[5/5] inherited shell delegation: execute('ls /tmp/secure_demo.txt')")
        r = backend.execute("ls /tmp/secure_demo.txt")
        assert r.exit_code == 0
        print("      OK")

        print("\nAll checks passed.")
    finally:
        backend.close()


if __name__ == "__main__":
    main()
```

The five checks correspond to the contract surface this integration cares about:

1. Sandbox provisioned with a non-empty `id`.
2. Sync `execute()` returns an `ExecuteResponse` with the right exit code.
3. Typed `read/write` roundtrip works (so `BaseSandbox.edit` will work too).
4. Policy denial path raises (so deepagents tools fail loudly when policy blocks).
5. Inherited shell-mode `execute()` still works for `ls/glob/grep`.

Doesn't need OpenSWE installed. Doesn't need a CI pipeline. Just real
credentials for whichever provider you want to spot-check.

## README outline

The `examples/open_swe/README.md` covers, in this order:

1. **What this is** — one paragraph: secure-sandbox-py + OpenSWE, what the
   bridge does, what providers are covered, what's out of scope (LangSmith).
2. **Install** — `pip install agentsh-secure-sandbox` plus the per-provider SDK
   pip install commands and credential env vars.
3. **Wire into OpenSWE** — show the 6-line patch to `agent/utils/sandbox.py`,
   the `SANDBOX_TYPE` env var to set, and how to override `MODAL_APP_NAME`.
4. **Smoke-test the bridge** — `python -m examples.open_swe.demo_smoke_test
   --provider daytona`.
5. **End-to-end with OpenSWE** — manual steps, no automation: clone open-swe,
   apply the patch, run a real coding task, observe agentsh policy enforcement.
6. **Notes** — agentsh provisioning latency, the daemon thread per backend,
   why LangSmith is excluded, why other secure-sandbox-py providers are deferred
   to the package phase.

## Risks and unknowns

1. **deepagents source unread.** The exact `BaseSandbox`/`SandboxBackendProtocol`
   surface is inferred from the OpenSWE CUSTOMIZATION.md, not the source. First
   implementation step: clone deepagents and read
   `libs/deepagents/src/deepagents/backends/`. If `read()` returns `bytes`, or
   if there's a structured `ReadResponse`, or if `id` is a constructor arg
   rather than a property, the bridge adapts — none of that changes the
   architecture.

2. **agentsh provisioning latency hits the constructor.** First-run
   `secure_sandbox(adapter)` installs the agentsh binary inside the sandbox;
   takes ~5–15s depending on provider. The constructor blocks during this. The
   README needs to call it out.

3. **Sync/async bridge cost is one daemon thread per backend.** Cheap (~10 ms
   thread start), but worth noting in the README so anyone profiling sees the
   extra thread and knows why.

4. **Policy denials become Python exceptions.** Deepagents may handle
   exceptions from `read/write` differently than from a structured failure
   result. If agents crash hard on a `PermissionError` instead of seeing a
   "this was denied, try a different path" tool result, switch to returning a
   sentinel string instead. Decision deferred to verification step 1.

5. **Modal app name collision** with OpenSWE's existing Modal factory. Mitigated
   by a different default app name; documented in README.

6. **Provider SDK API drift.** Each factory imports from a third-party SDK
   whose APIs change. Mitigated by mirroring the construction code in
   `examples/<provider>_pydantic_ai.py`, which is kept in sync with the
   adapters.

## Verification plan

1. Read `deepagents.backends.protocol` and `deepagents.backends.sandbox`
   source. Adjust the bridge if signatures differ from what this design
   assumes.
2. Run `python -m examples.open_swe.demo_smoke_test --provider daytona`
   against a real Daytona credential. Expect all 5 checks pass.
3. Repeat for `--provider e2b`, `--provider modal`, `--provider runloop`,
   `--provider freestyle`. If credentials for any provider are missing, ship
   the factory and skip that provider's smoke test, with a note in the README.
4. **Optional, manual:** clone open-swe, apply the README's `_patch_sandbox.py`
   snippet, set `SANDBOX_TYPE=secure_daytona`, run a real OpenSWE coding task.
   Document the result in the README.

## Out of scope (deferred to phase 2 — package)

- Standalone pip package (`agentsh-secure-sandbox-deepagents` or similar).
- Upstream PR to OpenSWE.
- Pytest-based CI for the bridge.
- LangSmith provider — managed service, no public sandbox SDK to wrap.
- Cloudflare/Vercel/Blaxel/Sprites/exe.dev factories.
- End-to-end automated test that boots OpenSWE and runs a real coding task.
