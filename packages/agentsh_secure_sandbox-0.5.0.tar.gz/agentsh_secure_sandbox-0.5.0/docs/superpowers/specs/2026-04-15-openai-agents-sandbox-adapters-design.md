# OpenAI Agents SDK Sandbox Adapter Support

Date: 2026-04-15

## Summary

Add a first-class OpenAI Agents SDK sandbox integration for
`agentsh-secure-sandbox`. The integration should support OpenAI's new beta
`SandboxAgent` / `SandboxRunConfig` flow while preserving the existing
`SecureSandboxAgentTools` function-tool integration.

The implementation will use a hybrid provider strategy:

1. Wrap OpenAI's upstream sandbox clients for providers OpenAI already
   supports.
2. Add our own OpenAI-compatible sandbox clients for providers OpenAI does not
   support but this project does.

The core invariant is that model-facing sandbox operations must be mediated by
agentsh. `SandboxAgent` should not receive a session whose `exec`, `read`, or
`write` methods bypass agentsh after startup.

## Current Context

The project already supports direct provider adapters plus framework tool
integrations:

- Provider adapters: E2B, Daytona, Cloudflare, Vercel, Blaxel, Sprites, Modal,
  Runloop, exe.dev, and Freestyle.
- OpenAI Agents SDK integration today: `SecureSandboxAgentTools`, which exposes
  three `FunctionTool`s: `run_command`, `write_file`, and `read_file`.
- OpenAI Agents SDK `0.14.1` adds beta sandbox-agent support through
  `SandboxAgent`, `SandboxRunConfig`, `BaseSandboxClient`, `BaseSandboxSession`,
  `SandboxSessionState`, `Manifest`, and provider-specific sandbox clients.

Official docs used while designing:

- Sandbox agent quickstart:
  https://openai.github.io/openai-agents-python/sandbox_agents/
- Sandbox clients:
  https://openai.github.io/openai-agents-python/sandbox/clients/
- `SandboxRunConfig` reference:
  https://openai.github.io/openai-agents-python/ref/run_config/

OpenAI marks sandbox agents as beta. The integration should be isolated so SDK
API drift is contained.

## Provider Matrix

Use OpenAI upstream clients for providers supported by both OpenAI and this
project:

| Provider | OpenAI SDK client path | Strategy |
| --- | --- | --- |
| Blaxel | `agents.extensions.sandbox.blaxel` | Wrap upstream client/session |
| Cloudflare | `agents.extensions.sandbox.cloudflare` | Wrap upstream client/session |
| Daytona | `agents.extensions.sandbox.daytona` | Wrap upstream client/session |
| E2B | `agents.extensions.sandbox.e2b` | Wrap upstream client/session |
| Modal | `agents.extensions.sandbox.modal` | Wrap upstream client/session |
| Runloop | `agents.extensions.sandbox.runloop` | Wrap upstream client/session |
| Vercel | `agents.extensions.sandbox.vercel` | Wrap upstream client/session |

Add first-class OpenAI-compatible clients for providers OpenAI does not support:

| Provider | Strategy |
| --- | --- |
| Sprites | Implement custom `BaseSandboxClient` / `BaseSandboxSession` |
| exe.dev | Implement custom `BaseSandboxClient` / `BaseSandboxSession` |
| Freestyle | Implement custom `BaseSandboxClient` / `BaseSandboxSession` |

## Public API

Add a new module:

```text
agentsh_secure_sandbox.openai_sandbox
```

Initial public exports:

```python
SecureOpenAISandboxClient
SecureOpenAISandboxSession
secure_openai_sandbox_client
SpritesSandboxClient
ExeSandboxClient
FreestyleSandboxClient
```

Example using an upstream OpenAI client:

```python
from agents import Runner
from agents.run import RunConfig
from agents.sandbox import SandboxAgent, SandboxRunConfig
from agents.extensions.sandbox.e2b import E2BSandboxClient
from agentsh_secure_sandbox.openai_sandbox import SecureOpenAISandboxClient

agent = SandboxAgent(
    name="Secure coder",
    model="gpt-5.4",
    instructions="Work in the sandbox and verify changes.",
)

client = SecureOpenAISandboxClient(
    upstream_client=E2BSandboxClient(),
)

result = await Runner.run(
    agent,
    "Create hello.txt containing hello, then read it back.",
    run_config=RunConfig(
        sandbox=SandboxRunConfig(client=client),
    ),
)
```

Example using an unsupported provider:

```python
from agents.sandbox import SandboxRunConfig
from agents.run import RunConfig
from agentsh_secure_sandbox.openai_sandbox import FreestyleSandboxClient

client = FreestyleSandboxClient()

run_config = RunConfig(
    sandbox=SandboxRunConfig(client=client),
)
```

Factory helper:

```python
client = secure_openai_sandbox_client(
    provider="e2b",
    upstream_client=E2BSandboxClient(),
    config=SecureConfig(),
)
```

The factory is convenience only. Direct client construction remains supported so
advanced callers can pass provider-specific upstream clients and options.

## Module Layout

```text
src/agentsh_secure_sandbox/openai_sandbox/
  __init__.py
  bridge.py
  wrappers.py
  unsupported.py
  providers.py
```

Responsibilities:

- `bridge.py`: shared conversion helpers, `SandboxAdapter` wrappers around
  OpenAI sessions, and `SecureOpenAISandboxSession`.
- `wrappers.py`: `SecureOpenAISandboxClient` for upstream OpenAI clients.
- `unsupported.py`: Sprites, exe.dev, and Freestyle client/session
  implementations.
- `providers.py`: provider registry and `secure_openai_sandbox_client()`.
- `__init__.py`: public exports and clear optional dependency errors.

## Lifecycle Design

For upstream OpenAI clients:

1. `SecureOpenAISandboxClient.create(...)` delegates to
   `upstream_client.create(...)`.
2. The returned session is adapted to this project's `SandboxAdapter` protocol.
3. `secure_sandbox(adapter, config)` provisions agentsh and creates a
   `SecuredSandbox`.
4. `SecureOpenAISandboxSession` wraps both the upstream session and the secured
   sandbox.
5. Model-facing `exec`, `read`, and `write` route through the secured sandbox.
6. Lifecycle and provider cleanup delegate to the upstream session/client.

For `resume(...)`:

1. Delegate state deserialization and resume to the upstream client when
   wrapping an OpenAI-supported provider.
2. Re-provision or reattach agentsh through `secure_sandbox(...)` before
   returning the wrapped session.
3. Preserve upstream session state serialization format where possible so the
   OpenAI SDK run-state flow remains compatible.

For unsupported providers:

1. The custom client creates or attaches to the provider sandbox using existing
   project adapter patterns.
2. The client provisions agentsh using `secure_sandbox(...)`.
3. The returned custom session implements OpenAI's `BaseSandboxSession`
   interface for core operations.

## Session Behavior

`SecureOpenAISandboxSession` should implement the OpenAI SDK session interface
while preserving the secured operation path:

- `exec(...)`: convert OpenAI command args to a shell command and call
  `SecuredSandbox.exec(...)`.
- `read(path)`: call `SecuredSandbox.read_file(...)` and return a readable
  byte stream.
- `write(path, data)`: read the provided stream and call
  `SecuredSandbox.write_file(...)`.
- `running()`: delegate to the upstream session where available; for custom
  clients, use a lightweight provider health check.
- `persist_workspace()` and `hydrate_workspace(data)`: delegate to upstream
  sessions for wrapped providers. For custom providers, implement tar-based
  workspace persistence through secured commands when practical.
- `resolve_exposed_port(...)`, PTY operations, mount support, and advanced
  provider features: delegate to upstream sessions for wrapped providers. For
  custom providers, unsupported advanced features should fail clearly rather
  than silently bypassing agentsh.

The implementation should avoid running raw provider commands after agentsh is
provisioned except for provider lifecycle cleanup and operations that are not
model-facing. If raw commands are required during startup, they must happen
before the secured session is exposed to `SandboxAgent`.

## Testing Design

### Unit Tests

Add focused tests for:

- Public imports from `agentsh_secure_sandbox.openai_sandbox`.
- Upstream client wrapper delegates `create`, `resume`, `delete`, and state
  serialization.
- Wrapped sessions route `exec`, `read`, and `write` through `SecuredSandbox`.
- Startup provisions agentsh exactly once per session.
- Unsupported provider clients satisfy the OpenAI SDK abstract interface.
- Custom session state serializes and deserializes for Sprites, exe.dev, and
  Freestyle.
- Missing optional dependencies raise clear install-extra errors.
- Existing `SecureSandboxAgentTools` behavior remains unchanged.

### Provider E2E Tests

Add e2e coverage for every provider this project supports when the needed keys
or config values are available:

- Blaxel
- Cloudflare
- Daytona
- E2B
- Modal
- Runloop
- Vercel
- Sprites
- exe.dev
- Freestyle

Provider-session e2e baseline:

- Create or attach to a sandbox.
- Create an OpenAI-compatible secured session.
- Run `exec("echo hello")`.
- Write and read a file under the workspace.
- Verify policy smoke checks where the provider security mode can enforce them,
  such as `.env` write denial, blocked `sudo`, blocked `env`, or sensitive env
  filtering.

These tests use `pytest.mark.e2e` and skip clearly when provider keys or SDK
dependencies are unavailable.

### Model-Driven E2E Tests

Add a separate marker:

```python
pytest.mark.openai_agent_e2e
```

These tests require both provider credentials and `OPENAI_API_KEY`.

Baseline model task:

1. Create a `SandboxAgent`.
2. Run a cheap deterministic task through `Runner.run(...)`.
3. The task creates a small file, reads it back, and runs a simple verification
   command.
4. Assert the file exists and contains the expected content through the secured
   session after the model run.

Run these tests for all available providers once the provider-session e2e layer
is stable. They should remain opt-in because they consume both model and
provider resources.

## E2E Secret Handling

The test harness should load this repo's `.env` first.

If `OPENAI_API_KEY` or provider keys are stored in another local project, tests
may load explicit additional env files via:

```bash
AGENTSH_E2E_ENV_FILES=/path/to/other/project/.env:/path/to/another/.env
```

Rules:

- Do not automatically scan sibling directories for `.env` files in committed
  test code.
- Do not print secret values.
- Missing keys should produce skip reasons, not failures.
- Local manual runs may locate a key outside the repo, but the value must remain
  process-local and uncommitted.

## Documentation

Update README with:

- Existing `SecureSandboxAgentTools` remains available for function-tool usage.
- New `SandboxAgent` integration examples.
- Provider matrix showing upstream-wrapped vs custom OpenAI-compatible clients.
- Required extras and environment variables.
- E2E test commands and markers.
- Beta caveat for OpenAI's sandbox API.

## Risks and Mitigations

Risk: OpenAI's sandbox interfaces are beta and may change.

Mitigation: isolate all SDK-specific code under `openai_sandbox/`, pin the
minimum OpenAI Agents SDK version to `0.14.1`, and add focused unit tests for
the expected interfaces.

Risk: Upstream provider sessions may perform internal raw operations that bypass
agentsh.

Mitigation: guarantee that model-facing operations exposed through our wrapped
session route through `SecuredSandbox`. Delegate only lifecycle, state, snapshot,
port, and unsupported advanced behavior to upstream sessions.

Risk: Provider e2e tests are slow, flaky, or costly.

Mitigation: key-gate tests, keep model-driven tests under a separate marker, and
make provider-session e2e tests cheap and deterministic.

Risk: Custom clients for Sprites, exe.dev, and Freestyle may not support every
advanced OpenAI SDK sandbox feature initially.

Mitigation: implement the core operations needed by `SandboxAgent` first and
raise clear errors for unsupported advanced features.

## Out of Scope

- Replacing `SecureSandboxAgentTools`.
- Automatically scanning the filesystem for secret-bearing `.env` files.
- Full PTY parity for custom unsupported providers in the first release.
- Full remote mount support for custom unsupported providers in the first
  release.
- Changing the existing provider adapter public API.
