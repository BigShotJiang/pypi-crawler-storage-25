# Freestyle Provider Design (Python)

**Date:** 2026-04-07
**Status:** Draft
**Scope:** Port the `freestyle` adapter from `secure-sandbox` (TypeScript) to `agentsh-secure-sandbox-py`, with full parity including snapshot baking and `installStrategy="preinstalled"`.

---

## 1. Goal

Add a `freestyle` provider to `agentsh-secure-sandbox-py` that wraps a Freestyle VM and integrates with `secure_sandbox()`. Must support the same preinstalled-agentsh flow the TypeScript adapter uses: apt deps + install script as `additionalFiles` + a oneshot `agentsh-install` systemd service + an `agentsh` long-running service, all baked into a snapshot at VM creation time.

Non-goals: a general-purpose Freestyle Python SDK, support for Freestyle dev_servers, cloudstate, git, domains, cron, fork/resize/suspend, terminals, watch-files, or the `VmWith` / `VmBuilder` composition system. Only the surface required by `secure_sandbox`.

---

## 2. Background

The TypeScript adapter (`secure-sandbox/src/adapters/freestyle.ts`) wraps a VM object from the `freestyle-sandboxes` npm package (currently pinned to `^0.1.0`, latest `0.1.42`). That package ships a fluent `VmSpec` builder plus a `Vm` client that covers `/v1/vms/*` endpoints.

The Python side has a different situation. The only published Python client is `freestyle` on PyPI (source: `github.com/freestyle-sh/sandbox-sdks-py`). That package **only** exposes Freestyle dev_servers — a separate product with a fundamentally different surface:

- `freestyle` (Python PyPI 0.0.17) → `Freestyle(token).request_dev_server(repo_id, …) → FreestyleDevServer`. Dev_servers are sync-only, tied to a git `repo_id`, and `FreestyleDevServerProcess.exec()` returns `{id, isNew, stdout, stderr}` — **no `exit_code`**.
- There is no Python equivalent of `freestyle-sandboxes`'s VMs/VmSpec API.

Reimplementing the TS adapter by wrapping `FreestyleDevServer` would target a different product, the security model would be unclear (agentsh's kernel-feature requirements may not hold in dev_servers), and the exec-result shape would lose exit codes. Instead, this design builds a minimal Python HTTP client against the Freestyle VMs REST API — the same endpoints `freestyle-sandboxes` talks to — and wraps it in the existing `SandboxAdapter` protocol.

The wire format for every endpoint and the shape of every field was verified by reading the `freestyle-sandboxes` 0.1.42 npm tarball source directly (`package/index.mjs`).

---

## 3. Architecture

Three layers:

```
┌───────────────────────────────────────────────────────┐
│ Caller: secure_sandbox(adapter, freestyle_defaults()) │
└────────────────────┬──────────────────────────────────┘
                     │
┌────────────────────▼──────────────────────────────────┐
│ _adapter.py : freestyle(vm: FreestyleVm)              │
│   - Implements SandboxAdapter Protocol                │
│   - Wraps env/cwd/sudo/detached/args into bash -c     │
│   - Maps ExecResult.exit_code from statusCode         │
└────────────────────┬──────────────────────────────────┘
                     │
┌────────────────────▼──────────────────────────────────┐
│ _vm.py : FreestyleVm                                  │
│   - Bound to a vm_id                                  │
│   - exec / read_file / write_file / file_exists / stop│
│   - wait_for_agentsh_health                           │
└────────────────────┬──────────────────────────────────┘
                     │
┌────────────────────▼──────────────────────────────────┐
│ _client.py : FreestyleClient                          │
│   - httpx.AsyncClient wrapper                         │
│   - Bearer auth, base URL, retries=off                │
│   - VmsNamespace: create / get / ref                  │
│   - create_sandbox_vm() high-level helper             │
└───────────────────────────────────────────────────────┘
                     │
┌────────────────────▼──────────────────────────────────┐
│ Freestyle HTTPS API (api.freestyle.sh/v1/vms/*)       │
└───────────────────────────────────────────────────────┘

_spec.py : FreestyleVmSpec (standalone — used by _client)
_defaults.py : freestyle_defaults, configure_freestyle_spec
```

Each layer is independently testable. `_client.py` is unit-tested with `httpx.MockTransport`. `_spec.py` is pure dict manipulation. `_adapter.py` is tested with a fake `FreestyleVm`. E2E tests exercise the full stack against a real Freestyle account.

---

## 4. Module layout

```
src/agentsh_secure_sandbox/adapters/freestyle/
├── __init__.py        # public re-exports
├── _client.py         # FreestyleClient + VmsNamespace
├── _vm.py             # FreestyleVm class
├── _spec.py           # FreestyleVmSpec + FreestyleFile + FreestyleSystemdConfig
├── _adapter.py        # freestyle() factory + SandboxAdapter impl + shell-quoting
└── _defaults.py       # freestyle_defaults, configure_freestyle_spec
```

Each file stays small (~100–250 lines). Sub-package chosen over a flat `freestyle.py` because this adapter includes its own HTTP client, unlike the other adapters which wrap external SDKs.

The `adapters/__init__.py` re-exports the public names alongside existing adapters:

```python
from .freestyle import (
    freestyle,
    freestyle_defaults,
    configure_freestyle_spec,
    FreestyleClient,
    FreestyleVm,
    FreestyleVmSpec,
)
```

---

## 5. Public API

### 5.1 End-to-end usage

```python
import os
from agentsh_secure_sandbox import secure_sandbox
from agentsh_secure_sandbox.adapters.freestyle import (
    FreestyleClient,
    freestyle,
    freestyle_defaults,
)

async with FreestyleClient(api_key=os.environ["FREESTYLE_API_KEY"]) as client:
    # One-call helper: configure_freestyle_spec + create + wait_for_agentsh_health
    vm = await client.create_sandbox_vm()
    try:
        adapter = freestyle(vm)
        secured = await secure_sandbox(adapter, freestyle_defaults())
        result = await secured.exec("echo hello")
    finally:
        await vm.stop()
```

For users who need more control:

```python
from agentsh_secure_sandbox.adapters.freestyle import (
    FreestyleClient, FreestyleVmSpec, configure_freestyle_spec,
)

spec = configure_freestyle_spec(
    FreestyleVmSpec().idle_timeout_seconds_(600).snapshot()
)
async with FreestyleClient(api_key=...) as client:
    vm = await client.vms.create(spec=spec)
    await vm.wait_for_agentsh_health(timeout=60)
    ...
```

### 5.2 Exported names

| Name | Kind | Purpose |
|---|---|---|
| `FreestyleClient` | class | `httpx.AsyncClient` wrapper. Constructor: `(api_key=None, base_url="https://api.freestyle.sh", httpx_timeout=None)`. Methods: `vms` namespace, `create_sandbox_vm(spec=None, opts=None, health_timeout=60)`, `aclose()`, `__aenter__`/`__aexit__`. If `api_key` is `None`, reads `FREESTYLE_API_KEY` env var. |
| `FreestyleVm` | class | Bound to a `vm_id`. Methods: `exec(command, terminal=None, timeout_ms=None)`, `read_file(path)`, `write_file(path, content)`, `file_exists(path)`, `stop()`, `wait_for_agentsh_health(timeout=60, port=18080)`. All async. |
| `FreestyleVmSpec` | Pydantic model | Dict-backed wire-format builder. See §6. |
| `freestyle(vm: FreestyleVm) -> SandboxAdapter` | function | Wraps a `FreestyleVm` in the `SandboxAdapter` protocol for `secure_sandbox()`. |
| `freestyle_defaults() -> SecureConfig` | function | Full `SecureConfig` matching TS `freestyleDefaults()`. See §10. |
| `configure_freestyle_spec(spec, opts=None)` | function | Mutates a `FreestyleVmSpec` (or dict) to bake agentsh into a snapshot. Returns the same spec for chaining. |
| `FreestyleConfigureOptions` | dataclass | `agentsh_version: str = "0.17.0"`, `server_port: int = 18080`, `install_path: str = "/usr/local/bin"`. |
| `FreestyleError` | exception | Base exception for all HTTP / API errors. Carries `status` and `body` attributes. |

### 5.3 `FreestyleClient.vms` namespace

```python
class VmsNamespace:
    async def create(
        self,
        spec: FreestyleVmSpec | dict | None = None,
    ) -> FreestyleVm:
        """Create a VM. If spec is None, sends an empty body (Freestyle's defaults apply).

        Serializes via FreestyleVmSpec.to_request_body() so all wire-format
        transformations (bash→script, .service suffix, camelCase aliases) apply.
        """

    async def get(self, vm_id: str) -> FreestyleVm:
        """Fetch an existing VM's state. Makes a GET /v1/vms/{vm_id} call."""

    def ref(self, vm_id: str) -> FreestyleVm:
        """Return a FreestyleVm bound to an existing vm_id without an API call."""
```

### 5.4 `FreestyleClient.create_sandbox_vm()`

```python
async def create_sandbox_vm(
    self,
    spec: FreestyleVmSpec | dict | None = None,
    opts: FreestyleConfigureOptions | None = None,
    health_timeout: float = 60.0,
) -> FreestyleVm:
    """Build a spec with agentsh baked in, create the VM, wait for health.

    Equivalent to:
        spec = configure_freestyle_spec(spec or FreestyleVmSpec().snapshot(), opts)
        vm = await self.vms.create(spec=spec)
        await vm.wait_for_agentsh_health(timeout=health_timeout)
        return vm
    """
```

---

## 6. `FreestyleVmSpec` design

Pydantic v2 model with fluent mutating methods. Chosen because the project already uses Pydantic extensively (`SecureConfig`, `ServerConfig`, etc.) and because we want both runtime validation and camelCase wire-format serialization.

### 6.1 Shape

```python
class FreestyleFile(BaseModel):
    model_config = ConfigDict(extra="allow")
    content: str
    encoding: Literal["utf-8", "base64"] = "utf-8"


class FreestyleSystemdService(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)
    name: str
    mode: Literal["simple", "oneshot", "forking", "notify", "idle", "service"] = "service"
    bash: str | None = None
    exec_: list[str] | None = Field(None, alias="exec")
    description: str | None = None
    after: list[str] | None = None
    requires: list[str] | None = None
    wanted_by: list[str] | None = Field(None, alias="wantedBy")
    restart: Literal["no", "always", "on-success", "on-failure", "on-abnormal", "on-watchdog", "on-abort"] | None = None
    restart_sec: int | None = Field(None, alias="restartSec")
    delete_after_success: bool | None = Field(None, alias="deleteAfterSuccess")
    timeout_sec: int | None = Field(None, alias="timeoutSec")
    environment: dict[str, str] | None = None
    # extra="allow" covers other fields we don't explicitly map


class FreestyleSystemdConfig(BaseModel):
    model_config = ConfigDict(extra="allow")
    services: list[FreestyleSystemdService] | None = None


class FreestyleVmSpec(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    apt_deps: list[str] | None = Field(None, alias="aptDeps")
    additional_files: dict[str, FreestyleFile] | None = Field(None, alias="additionalFiles")
    systemd: FreestyleSystemdConfig | None = None
    snapshot_: "FreestyleVmSpec | None" = Field(None, alias="snapshot")

    idle_timeout_seconds: int | None = Field(None, alias="idleTimeoutSeconds")
    ready_signal_timeout_seconds: int | None = Field(None, alias="readySignalTimeoutSeconds")
    wait_for_ready_signal: bool | None = Field(None, alias="waitForReadySignal")
    workdir: str | None = None
    base_image: str | None = Field(None, alias="baseImage")
    discriminator: str | None = None
    skip_cache: bool | None = Field(None, alias="skipCache")
    rootfs_size_gb: int | None = Field(None, alias="rootfsSizeGb")
    mem_size_gb: int | None = Field(None, alias="memSizeGb")
    vcpu_count: int | None = Field(None, alias="vcpuCount")
    ports: list[int] | None = None

    # Fluent methods (mutate self, return self) ─────────────────────

    def snapshot(self) -> "FreestyleVmSpec":
        """Move the current layer into a new inner snapshot; clear outer fields.

        After this call, `self.snapshot_` holds a new FreestyleVmSpec containing
        the previous apt_deps / additional_files / systemd / etc., and all
        top-level fields on self are cleared.
        """
        ...

    def apt_deps_add(self, *pkgs: str) -> "FreestyleVmSpec": ...
    def additional_files_add(
        self, files: dict[str, str | bytes | FreestyleFile]
    ) -> "FreestyleVmSpec": ...
    def with_systemd_service(
        self, name: str, **fields: Any
    ) -> "FreestyleVmSpec": ...
    def idle_timeout_seconds_(self, seconds: int) -> "FreestyleVmSpec": ...
    def workdir_(self, path: str) -> "FreestyleVmSpec": ...

    def to_request_body(self) -> dict[str, Any]:
        """Serialize to camelCase wire format, applying systemd preprocessing."""
        ...
```

### 6.2 Naming

- The field is `snapshot_` (trailing underscore) so the method `snapshot()` doesn't collide. The `alias="snapshot"` keeps the wire format clean.
- A few other builder methods also have trailing underscores (`idle_timeout_seconds_`, `workdir_`) to avoid colliding with the fields that hold the values. Users who prefer assignment can use `spec.idle_timeout_seconds = 600` directly.

### 6.3 Wire format transformations (in `to_request_body`)

Replicates the TS `processSystemdServices` + `normalizeSystemdServices` logic verified from the `freestyle-sandboxes` 0.1.42 source:

1. **`bash` → script file + `exec`.** For each systemd service with a `bash` field:
   - Prepend `#!/bin/bash\n` if not already present.
   - Write the script content into `additional_files` at `/opt/freestyle/scripts/<service_name>.sh` with `encoding="utf-8"`.
   - Replace the service's `bash` field with `exec=["/bin/bash /opt/freestyle/scripts/<service_name>.sh"]`.
2. **`.service` suffix.** For entries in `after`, `requires`, `wanted_by` that don't contain a `.`, append `.service`. (So `after=["agentsh-install"]` becomes `after=["agentsh-install.service"]`.)
3. **Recursion.** If `snapshot_` is set, recursively apply the same transformations to the inner spec before serialization.
4. **camelCase via Pydantic.** `model_dump(by_alias=True, exclude_none=True)` produces the final wire format.

### 6.4 Unknown-field policy

`extra="allow"` on every model. Unknown fields set on the Python object pass through to the wire format unchanged. This lets users set Freestyle fields we haven't explicitly mapped (e.g. `git`, `template`, `users`, `groups`, new fields Freestyle adds later) without waiting for the library to update.

### 6.5 Dict interop

`client.vms.create(spec=...)` accepts either `FreestyleVmSpec` or a plain `dict`. Dicts are validated via `FreestyleVmSpec.model_validate(d)` before serialization — this ensures the same transformations (bash→script, .service suffix) apply regardless of input form.

---

## 7. Exec mapping

Freestyle's `POST /v1/vms/{vm_id}/exec-await` body is `{command: string, terminal: string | null, timeoutMs: int | null}`. The `command` is a single shell string — there is no separate `env`, `cwd`, `args`, `sudo`, or `detached` parameter. Everything has to be wrapped client-side.

### 7.1 Command construction

```python
def _build_command(
    command: str,
    args: list[str] | None,
    opts: ExecOpts | None,
) -> str:
    parts: list[str] = []

    if opts and opts.detached:
        parts.append("nohup")

    if opts and opts.sudo:
        parts.extend(["sudo", "-E"])

    parts.append(shlex.quote(command))
    if args:
        parts.extend(shlex.quote(a) for a in args)

    inner = " ".join(parts)

    if opts and opts.detached:
        inner = f"{inner} > /dev/null 2>&1 < /dev/null &"

    if opts and opts.env:
        env_prefix = " ".join(
            f"{k}={shlex.quote(v)}" for k, v in opts.env.items()
        )
        inner = f"{env_prefix} {inner}"

    if opts and opts.cwd:
        inner = f"cd {shlex.quote(opts.cwd)} && {inner}"

    return f"bash -c {shlex.quote(inner)}"
```

Rationale for each wrapping layer:

- **`bash -c <wrapped>` always.** Needed because `KEY=val cmd`, `cd && cmd`, and `&` background syntax are shell features. Freestyle may or may not run the command through a shell server-side; wrapping ourselves removes the ambiguity.
- **`sudo -E`** preserves the user's env vars. Plain `sudo` strips them.
- **Detached uses `nohup … > /dev/null 2>&1 < /dev/null &`.** Closing all stdio is what actually unblocks `exec-await`; `nohup` prevents SIGHUP when the exec session ends.
- **Env vars go after sudo and before the command** using `KEY=val` prefix syntax. This is the standard POSIX form.
- **`cd` goes outermost** so env vars apply inside the target directory.
- **`shlex.quote` everywhere.** Handles spaces, quotes, backticks, dollars, newlines.

### 7.2 Exit code mapping

Freestyle's exec response uses `statusCode` (not `exitCode`). Maps directly:

```python
ExecResult(
    stdout=response.get("stdout", ""),
    stderr=response.get("stderr", ""),
    exit_code=response.get("statusCode", 0),
)
```

If `statusCode` is missing from the response, default to `0`. The Freestyle API should always include it; the default is purely defensive against unexpected partial responses.

### 7.3 Timeouts

`ExecOpts` in this project doesn't have a per-call timeout field, so `timeout_ms` is always passed as `null` to Freestyle. The transport-level httpx timeout on `FreestyleClient` is the only bound.

### 7.4 `file_exists`

```python
async def file_exists(self, path: str) -> bool:
    try:
        result = await self.exec("test", ["-e", path])
        return result.exit_code == 0
    except FreestyleError:
        return False
```

Same pattern as TS `fs.exists` (which calls `vm.exec("test -e \"<path>\"")` internally) but uses our argv form to avoid quoting bugs.

---

## 8. File operations

### 8.1 `write_file`

```python
async def write_file(self, path: str, content: str | bytes) -> None:
    if isinstance(content, str):
        content = content.encode("utf-8")
    body = {
        "content": base64.b64encode(content).decode("ascii"),
        "encoding": "base64",
    }
    await self._client._put(f"/v1/vms/{self.vm_id}/files/{path}", json=body)
```

Always base64-encoded on the wire. Matches TS SDK behavior (handles binary content safely).

### 8.2 `read_file`

```python
async def read_file(self, path: str) -> str:
    response = await self._client._get(f"/v1/vms/{self.vm_id}/files/{path}")
    if response.get("encoding") == "base64":
        return base64.b64decode(response["content"]).decode("utf-8")
    return response["content"]  # "utf-8" or missing encoding
```

Returns `str` to match the existing adapter protocol. If the file contains non-UTF-8 binary data, the decode will raise — acceptable since `SandboxAdapter.read_file` is typed to return `str`.

---

## 9. Error handling

Single exception class:

```python
class FreestyleError(RuntimeError):
    """Raised for Freestyle API errors. Carries HTTP status + body for debugging."""
    def __init__(self, message: str, *, status: int | None = None, body: str | None = None):
        super().__init__(message)
        self.status = status
        self.body = body
```

**What raises vs. returns:**

| Operation | On success | On failure |
|---|---|---|
| `FreestyleClient.vms.create(spec)` | returns `FreestyleVm` | raises `FreestyleError` on non-2xx |
| `FreestyleVm.exec(cmd)` | returns `ExecResult` (any exit code) | raises `FreestyleError` only on HTTP-layer failures (5xx, timeout, connection errors) |
| `FreestyleVm.read_file(path)` | returns `str` | raises `FreestyleError` on 404 or non-2xx |
| `FreestyleVm.file_exists(path)` | returns `bool` | never raises (swallows all errors, returns `False`) |
| `FreestyleVm.write_file(path, content)` | returns `None` | raises `FreestyleError` on non-2xx |
| `FreestyleVm.stop()` | returns `None` | raises `FreestyleError` on non-2xx (callers should `try/except` in finalizers) |

Semantics match `runloop.py` where applicable.

### 9.1 `wait_for_agentsh_health`

```python
async def wait_for_agentsh_health(self, timeout: float = 60.0, port: int = 18080) -> None:
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout
    while loop.time() < deadline:
        try:
            result = await self.exec(
                "curl", ["-sf", f"http://127.0.0.1:{port}/health"]
            )
            if result.exit_code == 0 and "ok" in result.stdout:
                return
        except FreestyleError:
            pass  # Transient, VM may still be booting
        await asyncio.sleep(1.0)
    raise FreestyleError(f"agentsh did not become healthy within {timeout}s")
```

Mirrors the TS runner's 60-poll loop.

### 9.2 httpx timeouts

Default `httpx.Timeout(connect=10.0, read=300.0, write=60.0, pool=10.0)`. Create-VM uses a per-request override of `read=1800.0` (30 min) because snapshot cache-miss on first creation can take several minutes. If the first create takes longer than 5 seconds, emit an INFO log mentioning "snapshot cache-miss likely; subsequent creates will be faster" — matches the TS SDK's warning.

### 9.3 Retries

None. Consistent with existing adapters (none of them retry).

---

## 10. Security defaults (`freestyle_defaults`)

Returns a full `SecureConfig` matching the TypeScript `freestyleDefaults()` output. Key settings:

- **`install_strategy="preinstalled"`** — spec bakes agentsh into the snapshot via `configure_freestyle_spec`.
- **`allow_degraded=True`** — Freestyle kernels don't have Yama, so agentsh's ptrace-based file monitor can't attach.
- **FUSE deferred mode** — `/dev/fuse` has mode 600 in Freestyle; install script runs `chmod 666 /dev/fuse` at startup via the agentsh-install systemd unit.
- **`seccomp.file_monitor=False`** — file monitor depends on kernel features Freestyle doesn't guarantee.
- **Network rules** — same allowlist as TS defaults: npm/pypi/cargo/rubygems/crates/github, plus an explicit deny for `192.0.2.0/24` (Freestyle's internal events CIDR — blocking it prevents the sandbox from reaching metadata-ish internal services).
- **Resource limits** — 2 GB RAM, 50% CPU, 100 PIDs. Matches TS.
- **Policy denies** — standard denies for `/home/user/.env`, `/home/user/.ssh/`, `/etc/shadow`, etc.

The exact `SecureConfig` value is cross-referenced from `secure-sandbox/src/adapters/freestyle.ts` `freestyleDefaults()`; the Python version produces the same structure using the project's Pydantic `SecureConfig` model.

---

## 11. `configure_freestyle_spec`

```python
def configure_freestyle_spec(
    spec: FreestyleVmSpec | dict,
    opts: FreestyleConfigureOptions | None = None,
) -> FreestyleVmSpec:
    """Mutate spec to bake agentsh into the snapshot. Returns the same spec.

    Adds:
      - apt_deps: fuse3, libseccomp2 (+ a few tools needed by the install script)
      - additional_files: the agentsh install script and any static config
      - systemd service 'agentsh-install' (oneshot, runs the install script)
      - systemd service 'agentsh' (long-running, requires agentsh-install)

    If spec is a dict, it is validated into a FreestyleVmSpec first.
    """
```

`FreestyleConfigureOptions` has three fields mirroring the TS options:

```python
@dataclass(frozen=True)
class FreestyleConfigureOptions:
    agentsh_version: str = "0.17.0"
    server_port: int = 18080
    install_path: str = "/usr/local/bin"
```

The install script and service unit definitions are ported line-for-line from `secure-sandbox/src/adapters/freestyle.ts` `INSTALL_SCRIPT` and `STARTUP_SCRIPT` constants. Both are plain bash with interpolated options — straightforward to translate.

---

## 12. Testing strategy

### 12.1 Unit tests

Three unit-test files under `tests/` (location determined at implementation time based on existing layout):

**`test_freestyle_spec.py`** — pure dict manipulation, no network:
- `test_snapshot_moves_current_layer`
- `test_apt_deps_add_appends_and_is_chainable`
- `test_with_systemd_service_bash_gets_rewritten_to_exec_plus_script_file`
- `test_systemd_after_requires_get_service_suffix`
- `test_to_request_body_uses_camelcase_aliases`
- `test_extra_fields_passthrough`
- `test_snapshot_recursion_applies_transforms_to_inner_spec`
- `test_from_dict_validation`

**`test_freestyle_client.py`** — `httpx.MockTransport`:
- `test_create_vm_posts_to_v1_vms_with_bearer_auth`
- `test_create_vm_reads_api_key_from_env`
- `test_exec_posts_command_terminal_timeout_body`
- `test_read_file_decodes_base64_response`
- `test_read_file_passes_through_utf8`
- `test_write_file_base64_encodes_content`
- `test_file_404_raises_freestyle_error`
- `test_non_2xx_raises_with_status_and_body`
- `test_aclose_closes_httpx_client`
- `test_async_context_manager`

**`test_freestyle_adapter.py`** — fake `FreestyleVm`:
- `test_exec_wraps_in_bash_c`
- `test_exec_env_prefixes_key_value_pairs`
- `test_exec_cwd_prefixes_cd`
- `test_exec_sudo_uses_dash_e_to_preserve_env`
- `test_exec_detached_appends_nohup_and_background`
- `test_exec_args_shell_quoted`
- `test_exec_exit_code_mapped_from_status_code`
- `test_file_exists_uses_test_minus_e`
- `test_file_exists_returns_false_on_error`

### 12.2 E2E tests (`tests/e2e/test_freestyle.py`)

Mirrors the structure of `tests/e2e/test_runloop.py`:

- `skip_no_freestyle` mark in `conftest.py` — skips unless `FREESTYLE_API_KEY` is set and `httpx` is importable.
- Module-scoped fixture creates a VM once using `client.create_sandbox_vm()`, yields to tests, tears down with `await vm.stop()`.
- `TestFreestyleAdapter` class — adapter-level tests: `exec` simple command, non-zero exit, env vars, cwd, write/read roundtrip, special chars, file_exists, detached.
- `TestFreestyleSmoke` class — secure_sandbox provisioning: session_id set, security_mode valid, basic exec.
- `TestFreestylePolicy` class — policy enforcement: sudo blocked, .env write denied, workspace write allowed, npm allowed, unauthorized network blocked, ssh key read denied.

Runtime budget: under 5 minutes for the full suite. Most time spent on VM creation (especially first-time snapshot cache-miss).

### 12.3 `pyproject.toml`

Add `freestyle = []` to `[project.optional-dependencies]` (empty because httpx is already a core dep).

---

## 13. Risks and assumptions

| Risk | Severity | Mitigation |
|---|---|---|
| **API drift** — Freestyle changes wire format | Medium | Pin target to `freestyle-sandboxes` 0.1.42 in `_client.py` docstring. E2E tests catch drift on next run. |
| **Undocumented wire fields** — OpenAPI spec is incomplete; bash→script transform is only in JS SDK source | Medium | Unit tests lock down the exact transform. Cross-reference to `secure-sandbox` TS adapter. |
| **Incomplete VmSpec surface** — we map ~15 fields, real one has more | Low | `extra="allow"` passes unknown fields through. Document the short list of explicitly-mapped fields. |
| **Shell-quoting edge cases** — args with backticks, newlines, null bytes | Low | `shlex.quote` everywhere. E2E tests with special chars. Document the `bash -c` wrapping. |
| **Snapshot cache-miss slowness** — first create can take minutes | Low | 30-min timeout on create-vm, INFO log after 5s. Matches TS. |
| **Degraded security mode** — `allow_degraded=True` because Freestyle lacks Yama; file_monitor disabled | Acceptable | Documented in `freestyle_defaults()`. Matches TS adapter's explicit trade-off. |

**Assumptions:**

1. Target product is Freestyle VMs (`/v1/vms/*`), not dev_servers or serverless.
2. `agentsh` v0.17.0 is the default target; overridable via `FreestyleConfigureOptions`.
3. `freestyle` optional extra is empty (`freestyle = []`).
4. README gets a freestyle row in the providers table; `docs/spec.md` cross-references this document.
5. `wait_for_agentsh_health` lives on `FreestyleVm` (not adapter-specific) so non-agentsh callers can use it with a custom port.

---

## 14. References

- **TS adapter source:** `secure-sandbox/src/adapters/freestyle.ts`
- **TS design spec:** `secure-sandbox/docs/superpowers/specs/2026-04-07-freestyle-provider-design.md`
- **TS e2e runner:** `secure-sandbox/src/e2e/freestyle-e2e-runner.ts`
- **Freestyle npm SDK (source of truth for wire format):** `freestyle-sandboxes@0.1.42` / `github.com/freestyle-sh/sandbox_sdks`
- **Freestyle Python SDK (not used — dev_servers only):** `freestyle@0.0.17` / `github.com/freestyle-sh/sandbox-sdks-py`
- **Freestyle OpenAPI spec (partial):** `github.com/freestyle-sh/sandbox_sdks/blob/main/packages/sdk/openapi.json`
- **Reference Python adapter for wrapping patterns:** `src/agentsh_secure_sandbox/adapters/runloop.py`
