# Daytona And Cloudflare E2E Design

## Goal

Fix the OpenAI Agents SDK Daytona and Cloudflare e2e coverage without mixing unrelated migrations into the current work. The immediate objective is to make the harness represent the true provider requirements accurately, keep existing non-OpenAI integrations working, and avoid papering over environment or deployment mismatches.

## Current State

### Daytona

- The repo's existing Daytona adapter, examples, and e2e tests use `daytona_sdk`.
- The latest OpenAI Agents SDK Daytona sandbox backend imports `daytona` directly.
- The current OpenAI e2e availability gate treats Daytona as available only when `import daytona` succeeds.
- In the current environment, `daytona` is missing while `daytona_sdk` is installed, so the regular repo Daytona path and the OpenAI Daytona path have diverged.

### Cloudflare

- The repo's existing Cloudflare e2e uses an exec-proxy worker interface at `POST /exec`.
- The OpenAI Agents SDK Cloudflare sandbox backend expects a sandbox-service worker interface at `POST /v1/sandbox`.
- Both test paths currently derive from the same `CLOUDFLARE_WORKER_URL`, which conflates two different worker contracts.
- The currently configured worker serves the legacy exec path but not the OpenAI sandbox-service path, so the OpenAI test skips on an upstream 404.

## Requirements

1. Preserve existing repo Daytona behavior while enabling OpenAI Daytona support for the latest upstream SDK.
2. Do not introduce a fake local `daytona` shim to masquerade as the new SDK.
3. Keep Cloudflare legacy exec-proxy tests working.
4. Make OpenAI Cloudflare tests require the correct sandbox-service worker explicitly.
5. Make e2e skip messages reflect the exact missing SDK, env var, or endpoint capability.
6. Keep changes scoped to packaging, env gating, test harness logic, and docs unless a genuine adapter bug is discovered.

## Chosen Approach

### Daytona: dual-support at the packaging and harness layer

Use both Daytona Python packages where needed instead of forcing an immediate repo-wide migration.

- Update the `daytona` optional dependency to install both:
  - `daytona-sdk`
  - `daytona`
- Keep the current repo adapter and existing examples/tests on their current `daytona_sdk` path for now.
- Make OpenAI-specific Daytona e2e availability depend on `daytona`, because the upstream OpenAI SDK imports that package directly.
- Make general repo Daytona availability accept the SDK that the existing repo path actually uses.

This avoids a broad migration while still making the OpenAI integration truthful to upstream requirements.

### Cloudflare: split env vars by worker contract

Represent the two Cloudflare worker contracts separately instead of guessing.

- Keep the current env var for the legacy exec worker path.
- Add a dedicated sandbox-service env var for the OpenAI SDK path:
  - `CLOUDFLARE_SANDBOX_WORKER_URL`
- For backward compatibility, the legacy Cloudflare tests may continue to accept `CLOUDFLARE_WORKER_URL`.
- The OpenAI Cloudflare test should require `CLOUDFLARE_SANDBOX_WORKER_URL` explicitly and stop trying to infer compatibility from the exec worker.

This keeps the distinction operationally explicit and removes ambiguity from the harness.

## Detailed Design

### Daytona changes

#### Packaging

- Update `[project.optional-dependencies].daytona` in `pyproject.toml` to install both packages.
- Keep the extra name `daytona` unchanged to avoid churn for users.

#### E2E harness

- In `tests/e2e/conftest.py`, split Daytona readiness into:
  - repo Daytona readiness: requires the SDK used by the repo's current Daytona tests
  - OpenAI Daytona readiness: requires `daytona`
- Keep skip reasons specific:
  - regular Daytona tests should mention the currently supported SDK path
  - OpenAI Daytona tests should mention `daytona`

#### Docs

- Update Daytona install guidance in README and examples to clarify the distinction:
  - existing repo examples still show the current `daytona_sdk` usage where applicable
  - OpenAI-specific docs note that the OpenAI path depends on the newer `daytona` package

### Cloudflare changes

#### Environment model

- Continue supporting `CLOUDFLARE_WORKER_URL` for the legacy exec-proxy tests.
- Add `CLOUDFLARE_SANDBOX_WORKER_URL` for the OpenAI SDK tests.
- The OpenAI test should use only the sandbox-specific URL.

#### E2E harness

- Update Cloudflare availability logic in `tests/e2e/conftest.py` to track:
  - legacy exec worker availability
  - OpenAI sandbox worker availability
- Update skip messages so they identify which URL is missing or misconfigured.

#### Docs

- Document the difference between:
  - legacy exec worker (`/exec`)
  - OpenAI sandbox-service worker (`/v1/sandbox`)
- Make it clear that these may be different deployments, even if they can eventually point to the same worker.

## Alternatives Considered

### Daytona full migration now

Rejected for this change set. It would force examples, docs, tests, and possibly adapter assumptions to move all at once. That is larger than needed to fix the OpenAI integration.

### Daytona shim module named `daytona`

Rejected. The upstream OpenAI SDK imports multiple Daytona symbols from the real `daytona` package. A local compatibility shim would be brittle and create more maintenance risk than it removes.

### Single Cloudflare env var with runtime capability probing

Rejected as the primary approach. It hides a real deployment distinction and makes test behavior depend on probing rather than explicit configuration.

### Single Cloudflare worker deployment that supports both APIs

Reasonable as a long-term infra goal, but out of scope for the repo-local fix. The code should not assume that deployment exists today.

## Testing Plan

1. Update unit tests for e2e availability helpers and skip conditions.
2. Run targeted Daytona and Cloudflare OpenAI e2e tests.
3. Run the existing Daytona and Cloudflare repo e2e tests.
4. Run the full `tests/e2e` suite.
5. Run the full non-e2e suite with `pytest -q`.
6. Run `ruff check .`.

## Risks

### Dependency ambiguity

Installing both Daytona packages could introduce overlap or confusion if users assume only one SDK exists. This is acceptable in the short term because it matches the actual current split in integration surfaces.

### Documentation lag

If README/examples are not updated alongside the harness, users will keep hitting the same mismatch. Docs need to ship with the code change.

### Env sprawl

Adding `CLOUDFLARE_SANDBOX_WORKER_URL` increases configuration surface slightly, but it is the correct expression of the two worker contracts.

## Success Criteria

- OpenAI Daytona e2e becomes runnable when `daytona` is installed.
- Existing repo Daytona e2e keeps working on its current SDK path.
- OpenAI Cloudflare e2e no longer relies on the legacy exec worker URL.
- Legacy Cloudflare e2e remains unchanged in behavior.
- Skip messages clearly identify missing SDKs, env vars, or endpoint contracts.
