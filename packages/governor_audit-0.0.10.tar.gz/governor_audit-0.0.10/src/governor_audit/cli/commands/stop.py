"""``governor-audit stop`` — terminate the managed audit web server.

Mirrors ``governor stop`` (governor-cli/commands/stop.py): reads the
PID from ``~/.governor-audit/server.pid``, sends SIGTERM, clears the
pidfile. If no pidfile is present, says so and exits 0.
"""

from __future__ import annotations

import os
import signal

import typer

from governor_audit.cli import state as _state


def stop_command() -> None:
    """Stop the audit web server started by ``governor-audit start``."""
    pid = _state.read_pid()
    if not pid:
        typer.echo("No server PID on file — nothing to stop.")
        return

    try:
        os.kill(pid, signal.SIGTERM)
        typer.secho(f"Server stopped (PID {pid})", fg=typer.colors.GREEN)
    except ProcessLookupError:
        typer.echo(f"Server PID {pid} already gone; clearing pidfile.")

    _state.clear_pid()


__all__ = ["stop_command"]
