"""End-to-end scan orchestrator.

Flow:
    load config → resolve effective dbt_only flag → compute window
        → BigQuery dry-run + cap check
        → submit query (unless --dry-run)
        → persist BigQueryJob rows
        → invoke governor-core detection rules
        → persist Opportunity + AuditOpportunityMetadata rows
        → mark ScanRun status

The BigQuery client is injected so tests can substitute a fake. In
production the client is built from the user's gcloud ADC credentials.

**v2 change**: no manifest loading; no attribution step. Each
opportunity's ``AuditOpportunityMetadata.is_dbt_originated`` is
derived from the underlying job's query prefix.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Iterable

from sqlalchemy.orm import Session

from governor_audit.config.schema import AuditConfig
from governor_audit.db.models import ScanRun
from governor_audit.scan.information_schema import (
    BigQueryClientProtocol,
    DryRunEstimate,
    build_information_schema_query,
    clamp_lookback_days,
    estimated_cost_usd,
    extract_dbt_invocation_id,
    extract_dbt_node_id,
    extract_query_hash,
    is_dbt_originated,
)

logger = logging.getLogger("governor_audit.scan")


class ScanCostCapExceeded(Exception):
    def __init__(self, estimated_bytes: int, cap_bytes: int) -> None:
        self.estimated_bytes = estimated_bytes
        self.cap_bytes = cap_bytes
        super().__init__(
            f"Estimated bytes-billed {estimated_bytes:,} exceeds cap "
            f"{cap_bytes:,}. Override with --max-scan-bytes."
        )


@dataclass
class ScanResult:
    scan_run: ScanRun
    fresh_job_count: int
    cached_job_count: int
    dbt_originated_job_count: int
    unique_query_hash_count: int
    opportunity_count: int
    cost_usd: float
    dbt_only_filter: bool
    lookback_clamp_warning: str | None


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def compute_window(
    *, lookback_days: int, now: datetime | None = None
) -> tuple[datetime, datetime]:
    """Return (window_start, window_end) for the requested lookback."""
    end = now or _now_utc()
    start = end - timedelta(days=lookback_days)
    return start, end


def resolve_dbt_only_flag(
    *, cli_value: bool | None, config: AuditConfig
) -> bool:
    """CLI flag wins over config default; config default is the fallback."""
    if cli_value is not None:
        return cli_value
    return config.scan_defaults.dbt_only


def run_scan(
    *,
    config: AuditConfig,
    session: Session,
    bq_client: BigQueryClientProtocol,
    lookback_days: int | None = None,
    max_scan_bytes: int | None = None,
    dbt_only: bool | None = None,
) -> ScanResult:
    """Execute one scan end-to-end. The caller is responsible for holding
    the scan lock; this function commits the session itself.
    """
    requested_lookback = lookback_days or config.scan_defaults.lookback_days
    # INFORMATION_SCHEMA.JOBS retains 180 days; clamp + warn if user
    # asked for more (the request would silently return empty for the
    # excess range otherwise).
    effective_lookback, clamp_warning = clamp_lookback_days(requested_lookback)
    if clamp_warning:
        logger.warning(clamp_warning)
    cap = max_scan_bytes or config.scan_defaults.max_scan_bytes
    effective_dbt_only = resolve_dbt_only_flag(cli_value=dbt_only, config=config)
    window_start, window_end = compute_window(lookback_days=effective_lookback)

    sql, params = build_information_schema_query(
        project_id=config.gcp_project_id,
        region=config.bigquery_region,
        window_start=window_start,
        window_end=window_end,
        dbt_only=effective_dbt_only,
    )

    # Step 1 — dry-run cost estimate.
    estimate: DryRunEstimate = bq_client.dry_run(sql, params)
    estimated_cost = estimated_cost_usd(estimate.bytes_billed)
    logger.info(
        "scan dry-run estimate: %d bytes billed (%.4f USD), cap %d, dbt_only=%s",
        estimate.bytes_billed,
        estimated_cost,
        cap,
        effective_dbt_only,
    )

    # Persist a ScanRun row immediately so /scans always sees the attempt.
    scan_run = ScanRun(
        id=ScanRun.new_id(),
        started_at=_now_utc(),
        actual_window_start=window_start,
        actual_window_end=window_end,
        requested_lookback_days=effective_lookback,
        status="running",
        dry_run_estimated_bytes=estimate.bytes_billed,
        estimated_cost_usd=Decimal(str(round(estimated_cost, 4))),
        gcp_project_id=config.gcp_project_id,
        bigquery_region=config.bigquery_region,
        dbt_only_filter=effective_dbt_only,
    )
    session.add(scan_run)
    session.flush()

    # Step 2 — enforce cap.
    if estimate.bytes_billed > cap:
        scan_run.status = "failed"
        scan_run.failure_reason = "dry_run_cap_exceeded"
        scan_run.failure_message = (
            f"Estimated {estimate.bytes_billed} bytes > cap {cap}"
        )
        scan_run.completed_at = _now_utc()
        session.commit()
        raise ScanCostCapExceeded(estimate.bytes_billed, cap)

    # Step 3 — fetch jobs.
    rows: Iterable[dict] = bq_client.query_rows(sql, params)
    jobs_raw = list(rows)
    scan_run.fetched_job_count = len(jobs_raw)

    # Step 4 — derive dbt-attribution and query-hash signals per job.
    dbt_originated_count = 0
    unique_query_hashes: set[str] = set()
    for job in jobs_raw:
        if is_dbt_originated(job):
            dbt_originated_count += 1
        qh = extract_query_hash(job)
        if qh:
            unique_query_hashes.add(qh)
    # extract_dbt_* are consumed by detection.run_audit_detection — not
    # needed at this layer, just kept on the import surface for callers.
    _ = (extract_dbt_node_id, extract_dbt_invocation_id)

    logger.info(
        "scan: %d jobs fetched, %d dbt-originated, %d unique query hashes",
        len(jobs_raw),
        dbt_originated_count,
        len(unique_query_hashes),
    )

    # Step 5 — persist BigQueryJob rows so the dashboard / detection
    # engine has something to read. Sentinel parent rows are
    # idempotent — they exist after the first scan and are reused.
    from governor_audit.scan.detection import run_audit_detection
    from governor_audit.scan.persistence import persist_jobs
    from governor_audit.scan.sentinels import (
        create_detection_job,
        create_sync_operation,
        ensure_sentinel_config,
        ensure_sentinel_user,
    )

    user_id = ensure_sentinel_user(session)
    config_id = ensure_sentinel_config(
        session,
        project_id=config.gcp_project_id,
        region=config.bigquery_region,
        user_id=user_id,
    )
    sync_id = create_sync_operation(
        session, config_id=config_id, scan_run_id=scan_run.id
    )
    detection_job_id = create_detection_job(
        session,
        config_id=config_id,
        sync_id=sync_id,
        scan_run_id=scan_run.id,
    )

    fresh_count = persist_jobs(
        session, jobs_raw, config_id=config_id, sync_id=sync_id
    )
    logger.info(
        "scan persistence: %d new bigquery_jobs rows (of %d fetched)",
        fresh_count,
        len(jobs_raw),
    )

    # Step 6 — run detection rules over every job in scope (including
    # earlier-cached rows so multi-scan windows aggregate properly).
    from governor_core.sync.models import BigQueryJob

    jobs_in_scope = (
        session.query(BigQueryJob)
        .filter(BigQueryJob.config_id == config_id)
        .filter(BigQueryJob.creation_time.between(window_start, window_end))
        .all()
    )
    opportunity_count = run_audit_detection(
        session=session,
        jobs=jobs_in_scope,
        config_id=config_id,
        detection_job_id=detection_job_id,
        scan_run_id=scan_run.id,
    )

    scan_run.opportunity_count = opportunity_count
    scan_run.actual_bytes_billed = estimate.bytes_billed
    scan_run.actual_cost_usd = Decimal(str(round(estimated_cost, 4)))
    scan_run.status = "succeeded"
    scan_run.completed_at = _now_utc()
    session.commit()

    return ScanResult(
        scan_run=scan_run,
        fresh_job_count=fresh_count,
        cached_job_count=len(jobs_raw) - fresh_count,
        dbt_originated_job_count=dbt_originated_count,
        unique_query_hash_count=len(unique_query_hashes),
        opportunity_count=opportunity_count,
        cost_usd=estimated_cost,
        dbt_only_filter=effective_dbt_only,
        lookback_clamp_warning=clamp_warning,
    )


__all__ = [
    "ScanCostCapExceeded",
    "ScanResult",
    "compute_window",
    "resolve_dbt_only_flag",
    "run_scan",
]
