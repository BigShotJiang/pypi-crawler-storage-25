"""Audit-side detection runner.

Lightweight wrapper around the ``governor_core.opportunities.rules``
catalogue. The cloud version routes detection through a heavy
``DetectionEngine`` (OpenTelemetry, OpportunityService dedup, rolling
windows, savings-estimator callbacks, manifest history). The audit
package skips all of that — it has no manifest, no Opportunity history
to roll up against, and no users to attribute changes to.

What we actually do:

  1. Load every enabled rule's class from ``get_detection_rule_catalog()``
  2. Call ``rule.detect(jobs, manifest_content=None, thresholds=defaults)``
  3. Persist the resulting ``OpportunityCandidate`` list as ``Opportunity``
     rows tied to our sentinel ManifestConfiguration / DetectionJob
  4. Tag each opportunity's audit-side metadata via ``AuditOpportunityMetadata``

Rules that fundamentally need a dbt manifest (e.g.
``partition_pruning``'s run-results path) handle a None manifest
gracefully — they drop back to the BigQuery-insights-only branch.

This isn't a regression of governor-cloud's detection quality. The
audit's read-only use case is "tell me which queries are problematic
right now" — fancy temporal cross-referencing is exactly the kind of
complexity the audit package was scoped to skip.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

    from governor_core.sync.models import BigQueryJob

logger = logging.getLogger("governor_audit.scan.detection")


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def run_audit_detection(
    *,
    session: "Session",
    jobs: list["BigQueryJob"],
    config_id: str,
    detection_job_id: str,
    scan_run_id: str,
) -> int:
    """Run every enabled detection rule against ``jobs`` and persist the
    resulting opportunities.

    Returns the number of opportunities created (existing rows are
    upserted in place; the count is fresh-rows-only).

    Rule failures are caught per-rule so one broken rule doesn't kill
    the whole scan — the audit user wants partial results over an empty
    page.
    """
    from governor_audit.db.models import AuditOpportunityMetadata
    from governor_audit.scan.information_schema import (
        extract_dbt_invocation_id,
        extract_dbt_node_id,
        extract_query_hash,
        is_dbt_originated,
    )
    from governor_core.opportunities.catalog import get_detection_rule_catalog
    from governor_core.opportunities.models import Opportunity

    catalog = [entry for entry in get_detection_rule_catalog() if entry.enabled]
    logger.info("audit detection: %d rules enabled", len(catalog))

    # Index per-job dbt attribution + query hash via the cached query body.
    # BigQueryJob doesn't carry labels (FR-042), so we approximate using
    # the dbt comment-prefix path — same fallback the orchestrator uses.
    job_attribution: dict[str, dict] = {}
    for j in jobs:
        # Build the same dict shape the rules helpers expect, on demand.
        as_dict = {
            "job_id": j.job_id,
            "query": j.query,
            "query_hashes": j.query_hashes,
        }
        job_attribution[j.job_id] = {
            "is_dbt": is_dbt_originated(as_dict),
            "dbt_node_id": extract_dbt_node_id(as_dict),
            "dbt_invocation_id": extract_dbt_invocation_id(as_dict),
            "query_hash": extract_query_hash(as_dict),
        }

    created = 0
    for entry in catalog:
        try:
            rule = entry.rule_class()
        except Exception as exc:  # noqa: BLE001
            logger.warning("rule %s failed to instantiate: %s", entry.rule_type, exc)
            continue

        # Some rules (storage_billing_optimization) require sidecar data
        # we don't fetch in the audit pipeline. Inject empty defaults so
        # they short-circuit cleanly instead of raising KeyError.
        thresholds = rule.get_thresholds()
        if rule.rule_type == "storage_billing_optimization":
            thresholds["_storage_metrics"] = []

        try:
            candidates = rule.detect(
                jobs=jobs, manifest_content=None, thresholds=thresholds
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "rule %s.detect raised %s — skipping its findings",
                rule.rule_type,
                exc,
            )
            continue

        for cand in candidates:
            # Look up an existing opportunity for this (rule, table,
            # config) so re-scans don't multiply rows. The unique
            # constraint enforces this at the DB level too.
            existing = (
                session.query(Opportunity)
                .filter(
                    Opportunity.opportunity_type == cand.opportunity_type,
                    Opportunity.affected_table == cand.affected_table,
                    Opportunity.config_id == config_id,
                )
                .first()
            )
            if existing is not None:
                # Update the cheap-to-refresh fields so the dashboard
                # reflects the latest cost / severity.
                existing.severity_score = cand.severity_score
                existing.evidence_snapshot = cand.evidence_snapshot
                existing.current_cost_estimate = cand.current_cost_estimate
                existing.expected_savings = cand.expected_savings
                existing.related_job_ids = cand.related_job_ids
                existing.explanation = cand.explanation
                existing.last_detection_job_id = detection_job_id
                existing.last_detected_at = _utcnow()
                existing.occurrence_count = (existing.occurrence_count or 0) + 1
                continue

            opp = Opportunity(
                id=uuid.uuid4().hex,
                config_id=config_id,
                opportunity_type=cand.opportunity_type,
                affected_table=cand.affected_table,
                status="active",
                severity_score=cand.severity_score,
                evidence_snapshot=cand.evidence_snapshot,
                current_cost_estimate=cand.current_cost_estimate,
                expected_savings=cand.expected_savings,
                explanation=cand.explanation,
                related_job_ids=cand.related_job_ids,
                dbt_model_name=cand.dbt_model_name,
                first_detection_job_id=detection_job_id,
                last_detection_job_id=detection_job_id,
                occurrence_count=1,
                last_detected_at=_utcnow(),
                consecutive_clean_days=0,
            )
            session.add(opp)
            session.flush()  # need opp.id for the sidecar

            # Attach audit-side metadata. dbt attribution is derived from
            # the first related job — most rules group jobs by table, so
            # any job with the dbt prefix means this finding is dbt-driven.
            attribution = next(
                (
                    job_attribution.get(jid)
                    for jid in cand.related_job_ids
                    if jid in job_attribution
                ),
                None,
            ) or {}
            session.add(
                AuditOpportunityMetadata(
                    opportunity_id=opp.id,
                    scan_run_id=scan_run_id,
                    is_dbt_originated=bool(attribution.get("is_dbt")),
                    dbt_node_id=attribution.get("dbt_node_id"),
                    dbt_invocation_id=attribution.get("dbt_invocation_id"),
                    query_hash=attribution.get("query_hash"),
                )
            )
            created += 1

    session.flush()
    logger.info("audit detection: %d new opportunities", created)
    return created


__all__ = ["run_audit_detection"]
