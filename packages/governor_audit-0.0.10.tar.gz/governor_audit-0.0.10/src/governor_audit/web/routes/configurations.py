"""/admin/configurations — single-config + run-scan page.

  GET  /admin/configurations         → detail (or 303 to /setup if no config)
  GET  /admin/configurations/new     → form
  POST /admin/configurations         → save config + run a scan inline

The single submit on the detail page does both: persists the project /
region / dbt-only default and immediately kicks off a scan of the chosen
period. Errors render inline on the originating template.

Project picker behaviour
------------------------
On render, both new.html and detail.html call ``gcp_projects_for_picker()``
to populate a ``<datalist>`` of projects the active gcloud principal can
see. This mirrors the cloud version's autocomplete pattern (which uses the
same ``governor_core.gcp.clients.list_gcp_projects`` helper). Free-text
input is preserved as a fallback for cases where the principal lacks
``resourcemanager.projects.list`` (the project audit READ permission is
narrower than the project LIST permission).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Annotated

from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from pydantic import ValidationError

from governor_audit.auth.adc import ProbeStatus, probe_adc
from governor_audit.config.loader import ConfigNotFoundError, load_config, save_config
from governor_audit.config.schema import (
    AuditConfig,
    ScanDefaults,
    WebUIConfig,
)

logger = logging.getLogger("governor_audit.web.configurations")
router = APIRouter()


@dataclass(frozen=True)
class PickerContext:
    """Context the configuration form needs to render the project picker."""

    projects: list[dict[str, str]]
    principal: str | None
    discovery_error: str | None  # human-readable; None when projects[] is fresh


def gcp_projects_for_picker() -> PickerContext:
    """Best-effort listing of projects the active gcloud ADC can see.

    Never raises. Failure modes are surfaced via ``discovery_error`` so the
    template can render the manual-input fallback with an explanatory note.

    Three failure modes worth distinguishing:

    1. ADC missing entirely → user hasn't run gcloud auth.
    2. ADC present but lacks ``resourcemanager.projects.list`` → common in
       narrow-scoped audit principals (consultant has read-only on a single
       project but no org-wide list permission). Free-text input still works.
    3. Network / API error → transient; user can retry.
    """
    try:
        from governor_core.gcp.clients import (
            GCPCredentialsError,
            list_gcp_projects,
        )
    except ImportError as exc:
        return PickerContext(
            projects=[],
            principal=None,
            discovery_error=f"Project discovery unavailable: {exc}",
        )

    principal = _active_principal()

    try:
        projects = list_gcp_projects()
    except GCPCredentialsError as exc:
        return PickerContext(
            projects=[],
            principal=principal,
            discovery_error=(
                "No Application Default Credentials found. Run "
                "`gcloud auth application-default login` and reload this page. "
                f"({exc})"
            ),
        )
    except Exception as exc:  # noqa: BLE001
        # PermissionDenied / Forbidden / network errors all bucket here.
        # Most common: principal can read jobs in their target project but
        # doesn't have org-wide resourcemanager.projects.list. The form keeps
        # working — they just have to type the project ID.
        msg = str(exc).lower()
        if "permission" in msg or "forbidden" in msg or "denied" in msg:
            note = (
                "The active gcloud principal can't list projects. This is "
                "fine — narrow audit principals often lack "
                "resourcemanager.projects.list while still having read access "
                "to a specific project. Type the project ID manually below."
            )
        else:
            note = f"Project discovery failed: {exc}"
        return PickerContext(
            projects=[], principal=principal, discovery_error=note
        )

    # Sort projects for stable rendering (stable IDs first).
    projects.sort(key=lambda p: (p.get("display_name", "") or "", p["project_id"]))
    return PickerContext(projects=projects, principal=principal, discovery_error=None)


def _has_adc() -> bool:
    """True iff Application Default Credentials are present and loadable.

    The wizard's "Continue" button gates on this, NOT on
    ``_active_principal()`` — because user OAuth credentials produced by
    ``gcloud auth application-default login`` don't expose any email
    field on the credential object (the JSON file is just
    ``{"type": "authorized_user", "client_id": ..., "refresh_token": ...}``).
    Insisting on a known principal stranded users with otherwise-valid
    ADC at step 1 of setup.
    """
    try:
        from google.auth import default as google_auth_default
    except ImportError:
        return False
    try:
        creds, _ = google_auth_default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"],
        )
        return creds is not None
    except Exception:  # noqa: BLE001
        return False


def _active_principal() -> str | None:
    """Return the active gcloud principal email, or ``None`` if unknowable.

    Best-effort — never raises. Used for "you're signed in as <email>"
    hints so the user knows whose ADC the audit will be running with.
    Returning None is fine — the wizard advances on ``_has_adc()``, not
    on this. Order of attempts:

    1. Service-account fields (``service_account_email``,
       ``_service_account_email``).
    2. The ``.account`` attr that some credential types expose.
    3. ``gcloud config get-value account`` via subprocess — covers the
       common ``gcloud auth application-default login`` case where the
       cred object has no email but the gcloud config does.
    """
    try:
        from google.auth import default as google_auth_default
    except ImportError:
        return None
    try:
        creds, _ = google_auth_default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"],
        )
    except Exception:  # noqa: BLE001
        return None
    via_creds = (
        getattr(creds, "service_account_email", None)
        or getattr(creds, "_service_account_email", None)
        or getattr(creds, "account", None)
    )
    if via_creds:
        return via_creds
    return _gcloud_config_account()


def _gcloud_config_account() -> str | None:
    """Best-effort: ask `gcloud config get-value account` for the active
    principal email. Returns None if gcloud isn't on PATH or returns
    nothing — never raises."""
    import shutil
    import subprocess

    if not shutil.which("gcloud"):
        return None
    try:
        result = subprocess.run(
            ["gcloud", "config", "get-value", "account"],
            capture_output=True, text=True, timeout=2.0,
        )
    except Exception:  # noqa: BLE001
        return None
    value = (result.stdout or "").strip()
    # gcloud prints "(unset)" to stdout when no account is set.
    if not value or value == "(unset)":
        return None
    return value


def _render_new(
    request: Request,
    *,
    errors: dict | None = None,
    form_data: dict | None = None,
    status_code: int = 200,
) -> HTMLResponse:
    picker = gcp_projects_for_picker()
    return request.app.state.templates.TemplateResponse(
        request,
        "configurations/new.html",
        {
            "title": "Configure Audit Target — Governor Audit",
            "errors": errors or {},
            "form_data": form_data or {},
            "gcp_projects": picker.projects,
            "active_principal": picker.principal,
            "discovery_error": picker.discovery_error,
        },
        status_code=status_code,
    )


def _scan_banner_for(scan_status: str | None, scan_detail: str | None) -> dict | None:
    """Translate ?scan_status=...&scan_detail=... into a template banner."""
    if not scan_status:
        return None
    mapping = {
        "succeeded": ("success", "Scan succeeded."),
        "lock_held": ("warning", "Another scan is already running."),
        "cap_exceeded": ("warning", "Scan refused: cost cap exceeded."),
        "bad_args": ("error", "Invalid scan parameters."),
        "error": ("error", "Scan failed."),
    }
    level, headline = mapping.get(scan_status, ("info", "Scan finished."))
    return {"level": level, "headline": headline, "detail": scan_detail or ""}


def _load_scan_history(limit: int = 20) -> list[dict]:
    """Load recent ScanRun rows for display on the configuration page."""
    from governor_audit.db.models import ScanRun
    from governor_audit.db.session import (
        build_engine,
        create_all,
        make_session_factory,
    )
    from sqlalchemy import desc

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        rows = (
            session.query(ScanRun)
            .order_by(desc(ScanRun.started_at))
            .limit(limit)
            .all()
        )
        return [
            {
                "id": s.id,
                "started_at": s.started_at,
                "completed_at": s.completed_at,
                "status": s.status,
                "requested_lookback_days": s.requested_lookback_days,
                "fetched_job_count": s.fetched_job_count,
                "opportunity_count": s.opportunity_count,
                "actual_cost_usd": float(s.actual_cost_usd) if s.actual_cost_usd else 0.0,
                "estimated_cost_usd": float(s.estimated_cost_usd) if s.estimated_cost_usd else 0.0,
                "dbt_only_filter": s.dbt_only_filter,
                "failure_reason": s.failure_reason,
            }
            for s in rows
        ]


def _cache_stats() -> dict:
    """Snapshot the cache for the configuration page's stats strip:
    cached job count + active opportunity count + last scan timestamp.

    Mirrors governor-web's "Last BigQuery Jobs Sync / Last Manifest
    Change" header strip — except audit only has scans, no manifest.
    """
    from governor_audit.db.models import ScanRun
    from governor_audit.db.session import (
        build_engine,
        create_all,
        make_session_factory,
    )
    from governor_core.opportunities.models import Opportunity
    from governor_core.sync.models import BigQueryJob
    from sqlalchemy import desc

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        last_scan = (
            session.query(ScanRun)
            .filter(ScanRun.status == "succeeded")
            .order_by(desc(ScanRun.completed_at))
            .first()
        )
        return {
            "cached_jobs": session.query(BigQueryJob).count(),
            "active_opps": (
                session.query(Opportunity)
                .filter(Opportunity.status == "active")
                .count()
            ),
            "last_scan_at": (
                last_scan.completed_at if last_scan else None
            ),
        }


def _render_detail(
    request: Request,
    config: AuditConfig,
    *,
    errors: dict | None = None,
    form_data: dict | None = None,
    flash_message: str | None = None,
    scan_status: str | None = None,
    scan_detail: str | None = None,
    status_code: int = 200,
) -> HTMLResponse:
    picker = gcp_projects_for_picker()
    scans = _load_scan_history()
    stats = _cache_stats()

    # Lightweight ADC status pill — never raises.
    try:
        from governor_audit.auth.adc import probe_adc
        probe = probe_adc(config.gcp_project_id, config.bigquery_region)
        adc_state = {"ok": probe.ok, "label": "ADC ok" if probe.ok else "ADC issue"}
    except Exception:  # noqa: BLE001
        adc_state = {"ok": False, "label": "ADC unknown"}

    return request.app.state.templates.TemplateResponse(
        request,
        "configurations/detail.html",
        {
            "title": "Configuration — Governor Audit",
            "config": config,
            "errors": errors or {},
            "form_data": form_data or {},
            "flash_message": flash_message,
            "gcp_projects": picker.projects,
            "active_principal": picker.principal,
            "discovery_error": picker.discovery_error,
            "scans": scans,
            "scan_banner": _scan_banner_for(scan_status, scan_detail),
            "allowed_scan_days": [1, 7, 30, 180],
            "default_scan_days": (
                config.scan_defaults.lookback_days
                if config.scan_defaults.lookback_days in (1, 7, 30, 180)
                else 7
            ),
            "has_scan_data": any(s["status"] == "succeeded" for s in scans),
            "cache_stats": stats,
            "adc_state": adc_state,
        },
        status_code=status_code,
    )


@router.get("/admin/configurations", response_class=HTMLResponse)
def configurations_index(
    request: Request,
    scan_status: str | None = None,
    scan_detail: str | None = None,
):
    """For governor-audit there's exactly one config; this route always
    redirects to /new (no config) or renders the detail page (single config)."""
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)
    return _render_detail(
        request, config, scan_status=scan_status, scan_detail=scan_detail
    )


@router.get("/admin/configurations/new", response_class=HTMLResponse)
def configurations_new(request: Request):
    return _render_new(request)


_ALLOWED_SCAN_DAYS = (1, 7, 30, 180)


@router.post("/admin/configurations", response_class=HTMLResponse)
def configurations_submit(
    request: Request,
    gcp_project_id: Annotated[str, Form()],
    bigquery_region: Annotated[str, Form()],
    dbt_only_default: Annotated[bool, Form()] = False,
    days: Annotated[int | None, Form()] = None,
):
    """Save the active config and (optionally) run a scan inline.

    The configuration page's single form supplies ``days`` so a click on
    "Run scan" both persists project/region/dbt-only and immediately
    fires the scan. The legacy /new form omits ``days`` and just saves.
    """
    project = (gcp_project_id or "").strip()
    region = (bigquery_region or "").strip()
    form_data = {
        "gcp_project_id": project,
        "bigquery_region": region,
        "dbt_only_default": dbt_only_default,
    }

    field_errors: dict[str, str] = {}
    if not project:
        field_errors["gcp_project_id"] = "GCP project ID is required."
    if not region:
        field_errors["bigquery_region"] = "BigQuery region is required."
    if days is not None and days not in _ALLOWED_SCAN_DAYS:
        field_errors["_general"] = (
            f"Lookback must be one of {sorted(_ALLOWED_SCAN_DAYS)} days. Got {days}."
        )

    try:
        existing = load_config()
    except ConfigNotFoundError:
        existing = None

    def _render_error(errors: dict, *, status: int) -> HTMLResponse:
        if existing:
            return _render_detail(
                request, existing, errors=errors, form_data=form_data,
                status_code=status,
            )
        return _render_new(request, errors=errors, form_data=form_data, status_code=status)

    if field_errors:
        return _render_error(field_errors, status=422)

    # ADC probe (same path the CLI's `init` runs).
    logger.info("UI configurations: probing ADC against %s / %s", project, region)
    probe = probe_adc(project, region)
    if probe.status is ProbeStatus.ADC_MISSING:
        return _render_error(
            {
                "_general": (
                    "No Application Default Credentials found. "
                    "Run this in your terminal first, then come back and submit:\n"
                    "  gcloud auth application-default login"
                ),
            },
            status=400,
        )
    if probe.status is ProbeStatus.IAM_INSUFFICIENT:
        return _render_error(
            {
                "_general": (
                    f"Permission denied on project '{project}'. The active "
                    f"gcloud principal{' (' + probe.principal + ')' if probe.principal else ''} "
                    "needs roles/bigquery.resourceViewer + roles/bigquery.jobUser "
                    "on this project."
                ),
            },
            status=403,
        )
    if probe.status is ProbeStatus.REGION_UNKNOWN:
        return _render_error(
            {
                "bigquery_region": (
                    f"Region '{region}' or project '{project}' not found by "
                    "BigQuery. Check the region matches a real BigQuery location "
                    "(e.g. 'us', 'eu', 'australia-southeast1')."
                ),
            },
            status=422,
        )
    if not probe.ok:
        return _render_error(
            {"_general": f"ADC probe failed: {probe.message}"},
            status=500,
        )

    # Persist config — preserve any existing LLM block / detection overrides.
    try:
        update_kwargs = {
            "gcp_project_id": project,
            "bigquery_region": region,
            "scan_defaults": ScanDefaults(dbt_only=dbt_only_default),
        }
        if existing is None:
            new_config = AuditConfig.model_validate({
                **update_kwargs,
                "web_ui": WebUIConfig(),
            })
        else:
            new_config = existing.model_copy(update=update_kwargs)
            # Re-validate so the field validators (project-id grammar,
            # region normalisation) run on the merged record.
            new_config = AuditConfig.model_validate(new_config.model_dump())
    except ValidationError as exc:
        return _render_error(
            {"_general": f"Config validation failed: {exc}"},
            status=422,
        )

    save_config(new_config)
    logger.info("UI configurations: config saved for %s / %s", project, region)

    # No `days` → save-only (used by /new wizard); otherwise run scan inline.
    if days is None:
        return RedirectResponse(url="/admin/configurations?saved=1", status_code=303)

    return _run_scan_and_redirect(new_config, days=days, dbt_only=dbt_only_default)


def _run_scan_and_redirect(
    config: AuditConfig, *, days: int, dbt_only: bool
) -> RedirectResponse:
    """Run a scan inline using the just-saved config and 303 back to
    /admin/configurations with a banner. Mirrors POST /admin/scan but
    avoids the redirect chain a separate endpoint would require."""
    from urllib.parse import quote

    from governor_audit.db.session import (
        build_engine,
        create_all,
        make_session_factory,
        session_scope,
    )
    from governor_audit.scan.bigquery_client import build_default_client
    from governor_audit.scan.lock import ScanLockHeldError, acquire_scan_lock
    from governor_audit.scan.orchestrator import ScanCostCapExceeded, run_scan

    bq_client = build_default_client(
        project_id=config.gcp_project_id, region=config.bigquery_region,
    )
    engine = build_engine()
    create_all(engine)
    session_factory = make_session_factory(engine)

    def _redirect(status: str, detail: str = "") -> RedirectResponse:
        qs = f"scan_status={status}"
        if detail:
            qs += f"&scan_detail={quote(detail, safe='')}"
        # Success → land on the dashboard so the user immediately sees
        # what the scan produced. Failures stay on /admin/configurations
        # where the form (and the error context) live.
        target = "/dashboard" if status == "succeeded" else "/admin/configurations"
        return RedirectResponse(url=f"{target}?{qs}", status_code=303)

    logger.info(
        "UI configurations: running scan project=%s region=%s days=%d dbt_only=%s",
        config.gcp_project_id, config.bigquery_region, days, dbt_only,
    )
    try:
        with acquire_scan_lock():
            with session_scope(session_factory) as session:
                result = run_scan(
                    config=config,
                    session=session,
                    bq_client=bq_client,
                    lookback_days=days,
                    dbt_only=dbt_only,
                )
    except ScanLockHeldError as exc:
        return _redirect("lock_held", str(exc))
    except ScanCostCapExceeded as exc:
        return _redirect("cap_exceeded", str(exc))
    except Exception as exc:  # noqa: BLE001
        logger.exception("UI scan failed")
        return _redirect("error", str(exc)[:500])

    detail = (
        f"Fetched {result.fresh_job_count} jobs "
        f"({result.dbt_originated_job_count} dbt-originated, "
        f"{result.unique_query_hash_count} unique patterns), "
        f"actual cost ${result.cost_usd:.4f}."
    )
    if result.lookback_clamp_warning:
        detail = f"{result.lookback_clamp_warning} {detail}"
    return _redirect("succeeded", detail)
