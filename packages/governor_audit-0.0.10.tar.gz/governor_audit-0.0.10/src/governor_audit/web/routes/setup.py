"""/setup/* — first-run wizard.

Vendored from governor_web's local-mode setup flow but tailored to
audit's data model. Three active steps + completion:

  GET  /setup                  → /setup/account (entry point)
  GET  /setup/account          → step1: ADC probe
  POST /setup/account          → if ADC ok, redirect to /setup/target
  GET  /setup/target           → step2: pick project + region
  POST /setup/target           → ADC probe against target, save config,
                                 redirect to /setup/llm
  GET  /setup/llm              → step3: optional LLM defaults
  POST /setup/llm              → save (or skip), redirect to /setup/complete
  GET  /setup/complete         → wizard end card

The wizard is the only entry point for first-run users — every other
route checks for ``ConfigNotFoundError`` and redirects here. Once a
config exists, the wizard short-circuits to /setup/complete so the
URL doesn't accidentally clobber state.
"""

from __future__ import annotations

import logging
import os
from typing import Annotated

from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from pydantic import ValidationError

from governor_audit.auth.adc import ProbeStatus, probe_adc
from governor_audit.config.loader import (
    ConfigNotFoundError,
    load_config,
    save_config,
)
from governor_audit.config.schema import (
    AuditConfig,
    LLMConfig,
    ScanDefaults,
    WebUIConfig,
)
from governor_audit.web.routes.configurations import (
    _active_principal,
    _has_adc,
    gcp_projects_for_picker,
)

logger = logging.getLogger("governor_audit.web.setup")
router = APIRouter()


_STEP_LABELS = ["Google", "Audit Target", "AI / LLM"]
_TOTAL_STEPS = len(_STEP_LABELS)

_LLM_PROVIDERS = (
    ("gemini", "Google Gemini"),
    ("openai", "OpenAI"),
    ("anthropic", "Anthropic Claude"),
)


def _llm_status(config: AuditConfig | None = None) -> dict:
    """Per-provider 'is a key available' map. Persisted ``config.llm.api_key``
    counts as a key for the active provider; otherwise the matching env var
    is consulted."""
    persisted_provider = config.llm.provider if config and (config.llm.api_key or "").strip() else None
    return {
        "gemini": (
            persisted_provider == "gemini"
            or bool(os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"))
        ),
        "openai": (
            persisted_provider == "openai"
            or bool(os.getenv("OPENAI_API_KEY"))
        ),
        "anthropic": (
            persisted_provider == "anthropic"
            or bool(os.getenv("ANTHROPIC_API_KEY"))
        ),
    }


def _wizard_ctx(step: int, **extra) -> dict:
    return {
        "current_step": step,
        "total_steps": _TOTAL_STEPS,
        "step_labels": _STEP_LABELS,
        **extra,
    }


# ─── Entry redirect ──────────────────────────────────────────────────


@router.get("/setup", response_class=HTMLResponse)
def setup_root(request: Request):
    """If config already exists, jump straight to /setup/complete so the
    user sees the "all set" card instead of the first step prompting
    re-entry. Otherwise: enter the wizard at step 1."""
    try:
        load_config()
        return RedirectResponse(url="/setup/complete", status_code=303)
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup/account", status_code=303)


# ─── Step 1 — Google account / ADC ───────────────────────────────────


@router.get("/setup/account", response_class=HTMLResponse)
def setup_account(request: Request):
    # ``_has_adc()`` is the wizard gate — it returns True for any
    # loadable creds, including the "authorized_user" type produced by
    # ``gcloud auth application-default login`` (which carries no
    # email on the cred object). ``_active_principal()`` is best-effort
    # and may be None even when ADC is present.
    has_adc = _has_adc()
    principal = _active_principal() if has_adc else None
    return request.app.state.templates.TemplateResponse(
        request,
        "setup/step1_account.html",
        _wizard_ctx(
            1,
            title="Sign in — Governor Audit Setup",
            adc_ok=has_adc,
            principal=principal,
            probe_message=None if has_adc else "Run `gcloud auth application-default login` then click Re-check.",
        ),
    )


@router.post("/setup/account", response_class=HTMLResponse)
def setup_account_continue(request: Request):
    if not _has_adc():
        return RedirectResponse(url="/setup/account", status_code=303)
    return RedirectResponse(url="/setup/target", status_code=303)


# ─── Step 2 — pick project + region ──────────────────────────────────


@router.get("/setup/target", response_class=HTMLResponse)
def setup_target(request: Request):
    if not _active_principal():
        return RedirectResponse(url="/setup/account", status_code=303)
    picker = gcp_projects_for_picker()
    return request.app.state.templates.TemplateResponse(
        request,
        "setup/step2_target.html",
        _wizard_ctx(
            2,
            title="Audit target — Governor Audit Setup",
            principal=picker.principal,
            gcp_projects=picker.projects,
            discovery_error=picker.discovery_error,
            errors={},
            form_data={},
        ),
    )


@router.post("/setup/target", response_class=HTMLResponse)
def setup_target_save(
    request: Request,
    gcp_project_id: Annotated[str, Form()],
    bigquery_region: Annotated[str, Form()],
    dbt_only_default: Annotated[bool, Form()] = False,
):
    project = (gcp_project_id or "").strip()
    region = (bigquery_region or "").strip()
    form_data = {
        "gcp_project_id": project,
        "bigquery_region": region,
        "dbt_only_default": dbt_only_default,
    }
    picker = gcp_projects_for_picker()

    def _render_error(errors: dict, status: int = 422) -> HTMLResponse:
        return request.app.state.templates.TemplateResponse(
            request,
            "setup/step2_target.html",
            _wizard_ctx(
                2,
                title="Audit target — Governor Audit Setup",
                principal=picker.principal,
                gcp_projects=picker.projects,
                discovery_error=picker.discovery_error,
                errors=errors,
                form_data=form_data,
            ),
            status_code=status,
        )

    field_errors: dict[str, str] = {}
    if not project:
        field_errors["gcp_project_id"] = "GCP project ID is required."
    if not region:
        field_errors["bigquery_region"] = "BigQuery region is required."
    if field_errors:
        return _render_error(field_errors)

    # ADC probe against the chosen target — cheap dry-run that catches
    # IAM / wrong-region issues before we write the config file.
    logger.info("setup wizard: probing ADC against %s / %s", project, region)
    probe = probe_adc(project, region)
    if probe.status is ProbeStatus.ADC_MISSING:
        return _render_error({"_general":
            "ADC vanished between step 1 and now. Run `gcloud auth application-default login` and start over from /setup/account."},
            status=400)
    if probe.status is ProbeStatus.IAM_INSUFFICIENT:
        return _render_error({"_general":
            f"Permission denied on '{project}'. The active gcloud principal "
            f"{'(' + probe.principal + ') ' if probe.principal else ''}"
            "needs roles/bigquery.resourceViewer + roles/bigquery.jobUser."},
            status=403)
    if probe.status is ProbeStatus.REGION_UNKNOWN:
        return _render_error({"bigquery_region":
            f"Region '{region}' or project '{project}' not found by BigQuery. "
            "Check the region matches a real BigQuery location (e.g. 'us', 'eu', 'australia-southeast1')."},
            status=422)
    if not probe.ok:
        return _render_error({"_general": f"ADC probe failed: {probe.message}"}, status=500)

    # Probe succeeded — write the AuditConfig with default LLM (disabled).
    try:
        config = AuditConfig.model_validate({
            "gcp_project_id": project,
            "bigquery_region": region,
            "scan_defaults": ScanDefaults(dbt_only=dbt_only_default),
            "web_ui": WebUIConfig(),
        })
    except ValidationError as exc:
        return _render_error({"_general": f"Config validation failed: {exc}"}, status=422)

    save_config(config)
    logger.info("setup wizard: config written for %s / %s", project, region)
    return RedirectResponse(url="/setup/llm", status_code=303)


# ─── Step 3 — LLM (skippable) ────────────────────────────────────────


@router.get("/setup/llm", response_class=HTMLResponse)
def setup_llm(request: Request):
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup/target", status_code=303)
    return request.app.state.templates.TemplateResponse(
        request,
        "setup/step3_llm.html",
        _wizard_ctx(
            3,
            title="LLM review — Governor Audit Setup",
            config_llm=config.llm,
            llm_providers=_LLM_PROVIDERS,
            llm_status=_llm_status(config),
            errors={},
        ),
    )


@router.post("/setup/llm", response_class=HTMLResponse)
def setup_llm_save(
    request: Request,
    action: Annotated[str, Form()] = "save",
    llm_enabled: Annotated[bool, Form()] = False,
    llm_provider: Annotated[str, Form()] = "gemini",
    llm_api_key: Annotated[str, Form()] = "",
    llm_model: Annotated[str, Form()] = "gemini-3.1-pro-preview",
    llm_top_n: Annotated[int, Form()] = 20,
    llm_min_confidence: Annotated[float, Form()] = 0.7,
):
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup/target", status_code=303)

    # "Skip for now" → keep defaults, just continue.
    if action == "skip":
        return RedirectResponse(url="/setup/complete", status_code=303)

    new_key = (llm_api_key or "").strip() or config.llm.api_key

    try:
        new_llm = LLMConfig(
            enabled=llm_enabled,
            provider=llm_provider.strip(),
            api_key=new_key,
            model=llm_model.strip(),
            top_n=llm_top_n,
            min_confidence=llm_min_confidence,
        )
    except ValidationError as exc:
        return request.app.state.templates.TemplateResponse(
            request,
            "setup/step3_llm.html",
            _wizard_ctx(
                3,
                title="LLM review — Governor Audit Setup",
                config_llm=config.llm,
                llm_providers=_LLM_PROVIDERS,
                llm_status=_llm_status(config),
                errors={"_general": str(exc)},
            ),
            status_code=422,
        )

    config = config.model_copy(update={"llm": new_llm})
    save_config(config)
    logger.info("setup wizard: llm provider=%s model=%s enabled=%s",
                new_llm.provider, new_llm.model, new_llm.enabled)
    return RedirectResponse(url="/setup/complete", status_code=303)


# ─── Complete ────────────────────────────────────────────────────────


@router.get("/setup/complete", response_class=HTMLResponse)
def setup_complete(request: Request):
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup/account", status_code=303)
    return request.app.state.templates.TemplateResponse(
        request,
        "setup/complete.html",
        {
            "title": "Setup complete — Governor Audit",
            "config": config,
            "principal": _active_principal(),
            # current_step > total_steps suppresses the stepper.
            "current_step": _TOTAL_STEPS + 1,
            "total_steps": _TOTAL_STEPS,
            "step_labels": _STEP_LABELS,
        },
    )


__all__ = ["router"]
