"""/admin/settings/* — vendored from governor_web's `/settings/*` namespace.

Four tabs, one per template, all rendered through ``settings/layout.html``:

  GET  /admin/settings                 → Profile (gcloud principal + ADC)
  GET  /admin/settings/appearance      → Theme picker (browser localStorage)
  GET  /admin/settings/llm             → LLM provider / model / params
  POST /admin/settings/llm             → save LLMConfig
  GET  /admin/settings/detection-rules → per-rule enable/disable
  POST /admin/settings/detection-rules → save detection_rule_overrides

The audit doesn't have organisations or users, so cloud-only tabs
(Profile display name, Security, Installation, Auto-PR, Verification)
are dropped. What remains mirrors governor-web's templates 1:1.
"""

from __future__ import annotations

import logging
import os
from typing import Annotated

from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from pydantic import ValidationError
from starlette.datastructures import FormData

from governor_audit.auth.adc import probe_adc
from governor_audit.config.loader import (
    ConfigNotFoundError,
    load_config,
    save_config,
)
from governor_audit.config.schema import LLMConfig
from governor_audit.web.routes.configurations import _active_principal

logger = logging.getLogger("governor_audit.web.settings")
router = APIRouter()


_LLM_PROVIDERS = (
    ("gemini", "Google Gemini"),
    ("openai", "OpenAI"),
    ("anthropic", "Anthropic Claude"),
)


def _llm_api_key_set(config, provider: str) -> bool:
    """True if a key is available — either persisted in config.llm.api_key
    or supplied via the provider's env var (GEMINI_API_KEY etc.)."""
    if config and (config.llm.api_key or "").strip():
        return True
    return {
        "gemini": bool(os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")),
        "openai": bool(os.getenv("OPENAI_API_KEY")),
        "anthropic": bool(os.getenv("ANTHROPIC_API_KEY")),
    }.get(provider, False)


def _mask_api_key(key: str | None) -> str | None:
    if not key:
        return None
    return "••••••••" + key[-4:] if len(key) > 4 else "••••"


def _adc_status(config) -> dict:
    try:
        probe = probe_adc(config.gcp_project_id, config.bigquery_region)
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "status": "UNKNOWN", "message": f"probe failed: {exc}"}
    return {
        "ok": probe.ok,
        "status": probe.status.name if probe.status else "UNKNOWN",
        "message": probe.message or "",
    }


def _load_config_or_redirect():
    try:
        return load_config(), None
    except ConfigNotFoundError:
        return None, RedirectResponse(
            url="/setup", status_code=303
        )


# ─── Profile (default tab) ───────────────────────────────────────────


@router.get("/admin/settings", response_class=HTMLResponse)
def settings_profile(request: Request):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect
    return request.app.state.templates.TemplateResponse(
        request,
        "settings/profile.html",
        {
            "title": "Profile — Governor Audit",
            "active_tab": "profile",
            "config": config,
            "principal": _active_principal(),
            "adc": _adc_status(config),
        },
    )


# ─── Appearance ──────────────────────────────────────────────────────


@router.get("/admin/settings/appearance", response_class=HTMLResponse)
def settings_appearance(request: Request):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect
    return request.app.state.templates.TemplateResponse(
        request,
        "settings/appearance.html",
        {
            "title": "Appearance — Governor Audit",
            "active_tab": "appearance",
            "config": config,
        },
    )


# ─── AI / LLM ─────────────────────────────────────────────────────────


@router.get("/admin/settings/llm", response_class=HTMLResponse)
def settings_llm(request: Request, saved: int | None = None):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect
    return request.app.state.templates.TemplateResponse(
        request,
        "settings/llm.html",
        {
            "title": "AI / LLM — Governor Audit",
            "active_tab": "llm",
            "config": config,
            "llm_providers": _LLM_PROVIDERS,
            "api_key_set": _llm_api_key_set(config, config.llm.provider),
            "api_key_masked": _mask_api_key(config.llm.api_key),
            "saved": bool(saved),
            "errors": {},
        },
    )


@router.post("/admin/settings/llm", response_class=HTMLResponse)
def settings_llm_submit(
    request: Request,
    llm_enabled: Annotated[bool, Form()] = False,
    llm_provider: Annotated[str, Form()] = "gemini",
    llm_api_key: Annotated[str, Form()] = "",
    llm_model: Annotated[str, Form()] = "gemini-3.1-pro-preview",
    llm_routing_model: Annotated[str, Form()] = "gemini-3.1-pro-preview",
    llm_temperature: Annotated[float, Form()] = 0.2,
    llm_max_tokens: Annotated[int, Form()] = 4096,
    llm_timeout_ms: Annotated[int, Form()] = 60_000,
    llm_top_n: Annotated[int, Form()] = 20,
    llm_min_confidence: Annotated[float, Form()] = 0.7,
):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect

    # Blank api_key field → preserve the existing persisted value.
    new_key = (llm_api_key or "").strip() or config.llm.api_key

    try:
        new_llm = LLMConfig(
            enabled=llm_enabled,
            provider=llm_provider.strip(),
            api_key=new_key,
            model=llm_model.strip(),
            routing_model=llm_routing_model.strip(),
            temperature=llm_temperature,
            max_tokens=llm_max_tokens,
            timeout_ms=llm_timeout_ms,
            top_n=llm_top_n,
            min_confidence=llm_min_confidence,
        )
    except ValidationError as exc:
        return request.app.state.templates.TemplateResponse(
            request,
            "settings/llm.html",
            {
                "title": "AI / LLM — Governor Audit",
                "active_tab": "llm",
                "config": config,
                "llm_providers": _LLM_PROVIDERS,
                "api_key_set": _llm_api_key_set(config, llm_provider),
                "api_key_masked": _mask_api_key(config.llm.api_key),
                "saved": False,
                "errors": {"_general": str(exc)},
            },
        )

    config = config.model_copy(update={"llm": new_llm})
    save_config(config)
    logger.info(
        "settings: llm provider=%s model=%s enabled=%s key_set=%s",
        new_llm.provider,
        new_llm.model,
        new_llm.enabled,
        bool(new_llm.api_key),
    )
    return RedirectResponse(url="/admin/settings/llm?saved=1", status_code=303)


# ─── Detection Rules ─────────────────────────────────────────────────


def _detection_rules_view(config) -> list[dict]:
    """Build the per-rule view-model. Audit's overrides take effect when
    a rule's `rule_type` key is present in `config.detection_rule_overrides`
    with a False value; otherwise hardcoded defaults apply."""
    from governor_core.opportunities.catalog import get_detection_rule_catalog

    overrides = config.detection_rule_overrides or {}
    out: list[dict] = []
    for entry in get_detection_rule_catalog():
        if entry.rule_type in overrides:
            is_enabled = bool(overrides[entry.rule_type])
        else:
            is_enabled = bool(entry.enabled)
        try:
            rule = entry.rule_class()
            display_name = rule.display_name
            description = rule.description or ""
        except Exception:  # noqa: BLE001
            display_name = entry.rule_type.replace("_", " ").title()
            description = ""
        out.append(
            {
                "rule_type": entry.rule_type,
                "display_name": display_name,
                "description": description,
                "is_enabled": is_enabled,
            }
        )
    return out


@router.get("/admin/settings/detection-rules", response_class=HTMLResponse)
def settings_detection_rules(request: Request, saved: int | None = None):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect
    return request.app.state.templates.TemplateResponse(
        request,
        "settings/detection_rules.html",
        {
            "title": "Detection Rules — Governor Audit",
            "active_tab": "detection_rules",
            "config": config,
            "rules": _detection_rules_view(config),
            "saved": bool(saved),
            "errors": {},
        },
    )


@router.post("/admin/settings/detection-rules", response_class=HTMLResponse)
async def settings_detection_rules_submit(request: Request):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect

    form: FormData = await request.form()
    overrides: dict[str, bool] = {}
    from governor_core.opportunities.catalog import get_detection_rule_catalog

    for entry in get_detection_rule_catalog():
        # Checkbox absent → user toggled it off; present → on.
        overrides[entry.rule_type] = f"rule_{entry.rule_type}" in form

    config = config.model_copy(update={"detection_rule_overrides": overrides})
    save_config(config)
    logger.info(
        "settings: detection_rule_overrides updated (%d rules)", len(overrides)
    )
    return RedirectResponse(
        url="/admin/settings/detection-rules?saved=1", status_code=303
    )


__all__ = ["router"]
