"""GET /opportunities — list every active Opportunity in the local cache.
GET /opportunities/{id} — drill-down detail page.

Read-only mirror of governor-web's `/opportunities` UX, scoped to
audit's single (project, region). The list page vendors the cloud's
templates 1:1 (summary cards, filter controls, table, pagination) and
this route hydrates the data shape those templates expect:
``opportunities`` (per-row dict), ``signals`` (filter state), ``summary``
(aggregate stats), ``available_projects`` / ``available_types``,
``pagination`` (with ``query_string_without_page`` /
``query_string_without_sort_or_page``), and ``local_runtime_mode=True``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from typing import Any
from urllib.parse import urlencode

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import desc

from governor_audit.config.loader import ConfigNotFoundError, load_config
from governor_audit.db.session import (
    build_engine,
    create_all,
    make_session_factory,
)
from governor_core.opportunities.catalog import get_detection_rule_catalog
from governor_core.opportunities.models import Opportunity
from governor_core.sync.models import BigQueryJob
from governor_core.utils.pagination import PaginationContext

logger = logging.getLogger("governor_audit.web.opportunities")
router = APIRouter()

_PAGE_SIZE = 10  # matches governor-web's opportunities page (which is what governor-cli boots locally).
_DEFAULT_SORT = "savings"
_DEFAULT_DIRECTION = "desc"
_VALID_SORTS = ("project", "table", "type", "workload", "cost", "savings", "age", "state")


# ── Pagination wrapper — adds the query_string_without_* properties the
# cloud templates use to preserve filter state across page links ────────


@dataclass
class AuditPaginationContext:
    page: int
    page_size: int
    total_items: int
    base_query_pairs: list[tuple[str, str]] = field(default_factory=list)
    sort: str | None = None
    direction: str | None = None

    @property
    def total_pages(self) -> int:
        if self.total_items == 0:
            return 1
        return (self.total_items + self.page_size - 1) // self.page_size

    @property
    def has_prev(self) -> bool:
        return self.page > 1

    @property
    def has_next(self) -> bool:
        return self.page < self.total_pages

    @property
    def start_index(self) -> int:
        if self.total_items == 0:
            return 0
        return (self.page - 1) * self.page_size + 1

    @property
    def end_index(self) -> int:
        return min(self.page * self.page_size, self.total_items)

    def page_range(self, window: int = 2) -> list[int]:
        start = max(1, self.page - window)
        end = min(self.total_pages, self.page + window)
        return list(range(start, end + 1))

    @property
    def query_string_without_page(self) -> str:
        pairs = list(self.base_query_pairs)
        if self.sort:
            pairs.append(("sort", self.sort))
        if self.direction:
            pairs.append(("direction", self.direction))
        return urlencode(pairs)

    @property
    def query_string_without_sort_or_page(self) -> str:
        return urlencode(self.base_query_pairs)


# ── Severity bucket helper ─────────────────────────────────────────────


def _severity_bucket(score: int) -> str:
    if score >= 80:
        return "critical"
    if score >= 50:
        return "high"
    if score >= 20:
        return "medium"
    return "low"


_BUCKET_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


# ── Workload classification ─────────────────────────────────────────────
# Reuse audit's existing manifest-free build/consumption classifier so the
# Workload column doesn't render every row as "Unclassified". The helper
# inspects the job's SQL + statement_type to decide build vs consumption.


def _workload_kind_from_job(job: BigQueryJob | None) -> str | None:
    if job is None:
        return None
    if job.workload_kind:
        return job.workload_kind
    # Fall back to live classification when the column wasn't populated
    # at scan time (rows from earlier audit versions).
    from governor_audit.web.routes.findings import _classify_workload
    kind = _classify_workload(job.query, job.statement_type)
    # Map "other" → None so the template's local_runtime_mode branch
    # renders "Unclassified" only when classification really failed.
    return kind if kind in ("build", "consumption") else None


# ── Per-row view dict — matches the cloud template's expected shape ─────


def _to_row(
    opp: Opportunity,
    *,
    project_name: str,
    job: BigQueryJob | None,
) -> dict[str, Any]:
    severity = int(opp.severity_score or 0)
    return {
        "id": opp.id,
        "config_id": opp.config_id,
        "project_name": project_name,
        "affected_table": opp.affected_table,
        "dbt_model_name": opp.dbt_model_name,
        "opportunity_type": opp.opportunity_type,
        "query_workload_kind": _workload_kind_from_job(job),
        "query_cost_value": float(opp.current_cost_estimate or 0),
        "possible_savings_value": float(opp.expected_savings or 0)
        if opp.expected_savings
        else None,
        "occurrence_count": len(list(opp.related_job_ids or [])) or 1,
        "last_detected_at": opp.updated_at,
        "created_at": opp.created_at,
        "severity_score": severity,
        "severity_bucket": _severity_bucket(severity),
        "evidence_snapshot": opp.evidence_snapshot or {},
        "explanation": opp.explanation or "",
        "related_job_ids": list(opp.related_job_ids or []),
        # Cloud-only fields the audit templates reference but never set:
        "solution_job_status": None,
        "solution_risk_level": None,
        "recommendation_state": None,
        "optimized_cost_value": None,
        "optimized_delta_direction": None,
        "possible_savings_source_label": "detection heuristic",
    }


# ── Summary aggregator ─────────────────────────────────────────────────


def _summary_from_rows(rows: list[dict[str, Any]]) -> dict[str, Any]:
    total_cost = sum(r["query_cost_value"] or 0 for r in rows)
    total_savings = sum(r["possible_savings_value"] or 0 for r in rows)

    def _kind_total(field: str, kind: str) -> float:
        return sum(
            (r[field] or 0) for r in rows if r["query_workload_kind"] == kind
        )

    def _other_total(field: str) -> float:
        return sum(
            (r[field] or 0)
            for r in rows
            if r["query_workload_kind"] not in ("build", "consumption")
        )

    return {
        "active_count": len(rows),
        "with_solutions_count": 0,  # audit has no solutions pipeline
        "clearing_count": 0,
        "verified_count": 0,
        "collecting_count": 0,
        "total_query_cost": total_cost,
        "build_query_cost": _kind_total("query_cost_value", "build"),
        "consumption_query_cost": _kind_total("query_cost_value", "consumption"),
        "other_query_cost": _other_total("query_cost_value"),
        "total_savings": total_savings,
        "total_possible_savings": total_savings,
        "build_possible_savings": _kind_total("possible_savings_value", "build"),
        "consumption_possible_savings": _kind_total(
            "possible_savings_value", "consumption"
        ),
        "other_possible_savings": _other_total("possible_savings_value"),
        "verified_post_merge_savings": 0,
        "clearing_savings": 0,
    }


# ── Filtering ──────────────────────────────────────────────────────────


def _apply_filters(
    rows: list[dict[str, Any]],
    *,
    search: str,
    status: str,
    projects: str,
    types: str,
    smart_view: str,
) -> list[dict[str, Any]]:
    out = rows
    if search:
        needle = search.lower()
        out = [
            r
            for r in out
            if needle in (r["affected_table"] or "").lower()
            or needle in (r["dbt_model_name"] or "").lower()
            or needle in r["opportunity_type"].lower()
        ]
    # `status` doesn't differentiate audit rows beyond `active`; we
    # honour the dropdown so the UI selection round-trips, but every
    # cached row is "active".
    if status not in ("all", "", "active"):
        out = []
    if projects:
        out = [r for r in out if r["config_id"] == projects]
    if types:
        out = [r for r in out if r["opportunity_type"] == types]
    if smart_view == "quick-wins":
        out = [r for r in out if r["severity_bucket"] in ("critical", "high")]
    elif smart_view == "chronic":
        # Highest occurrence_count rows.
        out = sorted(out, key=lambda r: r["occurrence_count"], reverse=True)[:50]
    elif smart_view == "unaddressed":
        out = [r for r in out if r["severity_bucket"] != "low"]
    return out


# ── Sorting ────────────────────────────────────────────────────────────


def _sort_rows(
    rows: list[dict[str, Any]], sort_by: str, direction: str
) -> list[dict[str, Any]]:
    reverse = direction == "desc"
    if sort_by == "project":
        key = lambda r: r["project_name"] or ""
    elif sort_by == "table":
        key = lambda r: (r["dbt_model_name"] or r["affected_table"] or "").lower()
    elif sort_by == "type":
        key = lambda r: r["opportunity_type"]
    elif sort_by == "workload":
        key = lambda r: r["query_workload_kind"] or "zzz"
    elif sort_by == "cost":
        key = lambda r: r["query_cost_value"] or 0
    elif sort_by == "savings":
        key = lambda r: r["possible_savings_value"] or 0
    elif sort_by == "age":
        key = lambda r: r["last_detected_at"] or datetime.min
    elif sort_by == "state":
        # Cloud sorts state asc=Safe→High→Awaiting; audit's analogue
        # is severity bucket order (critical → low) — we treat
        # asc=low_severity_first, desc=critical_first.
        key = lambda r: _BUCKET_ORDER.get(r["severity_bucket"], 99)
        reverse = not reverse  # asc on bucket order = critical first feels wrong; flip
    else:
        key = lambda r: r["possible_savings_value"] or 0
    return sorted(rows, key=key, reverse=reverse)


# ── Routes ─────────────────────────────────────────────────────────────


@router.get("/opportunities", response_class=HTMLResponse)
def opportunities_index(
    request: Request,
    page: int = 1,
    sort: str | None = None,
    direction: str | None = None,
    search: str = "",
    status: str = "all",
    projects: str = "",
    types: str = "",
    view: str = "",
) -> HTMLResponse:
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    sort_by = sort if sort in _VALID_SORTS else _DEFAULT_SORT
    sort_dir = direction if direction in ("asc", "desc") else _DEFAULT_DIRECTION

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        active_rows = (
            session.query(Opportunity)
            .filter(Opportunity.status == "active")
            .order_by(desc(Opportunity.expected_savings))
            .all()
        )
        if not active_rows:
            return RedirectResponse(url="/admin/configurations", status_code=303)

        # Hydrate first related job per opportunity for workload classification.
        all_job_ids: set[str] = set()
        for opp in active_rows:
            for jid in (opp.related_job_ids or []):
                all_job_ids.add(jid)
        jobs_by_id: dict[str, BigQueryJob] = {}
        if all_job_ids:
            jobs = (
                session.query(BigQueryJob)
                .filter(BigQueryJob.job_id.in_(list(all_job_ids)))
                .all()
            )
            jobs_by_id = {j.job_id: j for j in jobs}

        rows = [
            _to_row(
                opp,
                project_name=config.gcp_project_id,
                job=next(
                    (jobs_by_id[j] for j in (opp.related_job_ids or []) if j in jobs_by_id),
                    None,
                ),
            )
            for opp in active_rows
        ]

    # Build available filter values from the full row set.
    available_projects = [(config.gcp_project_id, config.gcp_project_id)]
    available_types = sorted({r["opportunity_type"] for r in rows})

    # Summary BEFORE filters — covers the visible workspace (audit has
    # only one project so this matches the cloud's "all rows in scope").
    summary = _summary_from_rows(rows)

    # Apply filters + sort + paginate.
    filtered = _apply_filters(
        rows,
        search=search,
        status=status,
        projects=projects,
        types=types,
        smart_view=view,
    )
    filtered = _sort_rows(filtered, sort_by, sort_dir)

    page = max(1, page)
    base_pairs: list[tuple[str, str]] = []
    if search:
        base_pairs.append(("search", search))
    if status and status != "all":
        base_pairs.append(("status", status))
    if projects:
        base_pairs.append(("projects", projects))
    if types:
        base_pairs.append(("types", types))
    if view:
        base_pairs.append(("view", view))

    pagination = AuditPaginationContext(
        page=page,
        page_size=_PAGE_SIZE,
        total_items=len(filtered),
        base_query_pairs=base_pairs,
        sort=sort_by if sort_by != _DEFAULT_SORT else None,
        direction=sort_dir if sort_dir != _DEFAULT_DIRECTION else None,
    )
    if page > pagination.total_pages:
        page = pagination.total_pages
        pagination = AuditPaginationContext(
            page=page,
            page_size=_PAGE_SIZE,
            total_items=len(filtered),
            base_query_pairs=base_pairs,
            sort=sort_by if sort_by != _DEFAULT_SORT else None,
            direction=sort_dir if sort_dir != _DEFAULT_DIRECTION else None,
        )
    start = (page - 1) * _PAGE_SIZE
    paged = filtered[start : start + _PAGE_SIZE]

    signals = {
        "search": search,
        "status": status,
        "projects": projects,
        "types": types,
        "smart_view": view,
        "sort": sort_by,
        "direction": sort_dir,
        "page": page,
    }

    return request.app.state.templates.TemplateResponse(
        request,
        "opportunities/index.html",
        {
            "title": "Opportunities — Governor Audit",
            "opportunities": paged,
            "summary": summary,
            "signals": signals,
            "available_projects": available_projects,
            "available_types": available_types,
            "pagination": pagination,
            "local_runtime_mode": True,
        },
    )


@router.get("/opportunities/{opportunity_id}", response_class=HTMLResponse)
def opportunities_detail(
    request: Request, opportunity_id: str
) -> HTMLResponse:
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        opp = session.get(Opportunity, opportunity_id)
        if opp is None:
            raise HTTPException(status_code=404, detail="Opportunity not found")

        # Hydrate the offending job's SQL if a related job is still cached.
        related_job = None
        for jid in (opp.related_job_ids or []):
            related_job = (
                session.query(BigQueryJob).filter(BigQueryJob.job_id == jid).first()
            )
            if related_job is not None:
                break

        row = _to_row(opp, project_name=config.gcp_project_id, job=related_job)

    rule_meta = next(
        (e for e in get_detection_rule_catalog() if e.rule_type == row["opportunity_type"]),
        None,
    )

    return request.app.state.templates.TemplateResponse(
        request,
        "opportunities/detail.html",
        {
            "title": "Opportunity — Governor Audit",
            "row": row,
            "rule_meta": rule_meta,
            "job": related_job,
        },
    )


__all__ = ["router"]
