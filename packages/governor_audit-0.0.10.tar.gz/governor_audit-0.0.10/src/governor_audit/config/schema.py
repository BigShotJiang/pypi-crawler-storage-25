"""Pydantic schema for ``AuditConfig`` — the single source-of-truth file
at ``~/.governor-audit/config.json``. Hand-editable; the
``governor-audit config`` command is a convenience wrapper.

See [data-model.md § AuditConfig](../../../../specs/141-production-audit/data-model.md#auditconfig-configjson)
for the field reference and validator rationale.

**v2 change**: ``manifest`` field removed (manifest no longer required).
``scan_defaults.dbt_only`` field added for the optional
``--dbt-only`` filter default.
"""

from __future__ import annotations

import re
from decimal import Decimal
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

# GCP project ID grammar per
# https://cloud.google.com/resource-manager/reference/rest/v1/projects
_GCP_PROJECT_ID_RE = re.compile(r"^[a-z][-a-z0-9]{4,28}[a-z0-9]$")
_LOOPBACK_BIND_ADDRESSES = frozenset({"127.0.0.1", "::1", "localhost"})

CURRENT_SCHEMA_VERSION = 2  # bumped from 1 (v1 had required `manifest` field)
DEFAULT_LOOKBACK_DAYS = 30
DEFAULT_MAX_SCAN_BYTES = 10 * 1024 * 1024 * 1024  # 10 GB
DEFAULT_PORT = 8765


class ScanDefaults(BaseModel):
    # Lax mode so JSON round-trip works for Decimal etc.
    model_config = ConfigDict(strict=False)

    lookback_days: int = Field(
        default=DEFAULT_LOOKBACK_DAYS, ge=1, le=365,
        description="Default --days for scan when not specified.",
    )
    min_solution_cost_usd: Decimal = Field(
        default=Decimal("0.00"), ge=Decimal("0"),
        description="Filter findings below this current-cost USD.",
    )
    max_scan_bytes: int = Field(
        default=DEFAULT_MAX_SCAN_BYTES,
        ge=1_000_000,
        le=10_995_116_277_760,  # 10 TB
        description="BigQuery dry-run cost cap.",
    )
    dbt_only: bool = Field(
        default=False,
        description=(
            "Default value of --dbt-only for scan. When True, scans add "
            "a STARTS_WITH(query, '/* {\"app\": \"dbt\"') predicate."
        ),
    )


class WebUIConfig(BaseModel):
    model_config = ConfigDict(strict=False)

    port: int = Field(default=DEFAULT_PORT, ge=1024, le=65535)
    bind_address: str = Field(default="127.0.0.1")

    @field_validator("bind_address")
    @classmethod
    def _validate_loopback_only(cls, v: str) -> str:
        if v not in _LOOPBACK_BIND_ADDRESSES:
            raise ValueError(
                f"bind_address must be one of {sorted(_LOOPBACK_BIND_ADDRESSES)}; "
                f"got {v!r}. Non-loopback binds are rejected as a security policy."
            )
        return v


class LLMConfig(BaseModel):
    """LLM-driven best-practices review settings (planned for v0.0.2 +).

    Field shape mirrors ``governor_web/.../settings/llm.html`` so the
    audit settings page can be a near-1:1 vendoring of the cloud's
    template. The actual review code lands in a follow-up spec; the
    settings page reads + writes this struct now so the user's choices
    survive the implementation cut-over.
    """

    model_config = ConfigDict(strict=False)

    enabled: bool = Field(default=False)
    provider: str = Field(default="gemini")
    api_key: str | None = Field(
        default=None,
        description=(
            "Provider API key persisted to ~/.governor-audit/config.json. "
            "When set, takes precedence over the GEMINI_API_KEY / OPENAI_API_KEY "
            "/ ANTHROPIC_API_KEY env vars. File mode is 0600."
        ),
    )
    model: str = Field(
        default="gemini-3.1-pro-preview",
        description="Solution / review model — mirrors governor-web `llm_model`.",
    )
    routing_model: str = Field(
        default="gemini-3.1-pro-preview",
        description="Lighter model for classification / routing.",
    )
    temperature: float = Field(default=0.2, ge=0.0, le=2.0)
    max_tokens: int = Field(default=4096, ge=256, le=65536)
    timeout_ms: int = Field(default=60_000, ge=5000, le=600_000)
    top_n: int = Field(default=20, ge=1, le=200)
    min_confidence: float = Field(default=0.7, ge=0.0, le=1.0)


class AuditConfig(BaseModel):
    """Top-level config file shape for ``~/.governor-audit/config.json``."""

    model_config = ConfigDict(strict=False)

    schema_version: int = Field(default=CURRENT_SCHEMA_VERSION)
    gcp_project_id: str
    bigquery_region: str
    scan_defaults: ScanDefaults = Field(default_factory=ScanDefaults)
    detection_rule_overrides: dict[str, bool] = Field(default_factory=dict)
    web_ui: WebUIConfig = Field(default_factory=WebUIConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)

    @field_validator("schema_version")
    @classmethod
    def _validate_schema_version(cls, v: int) -> int:
        if v > CURRENT_SCHEMA_VERSION:
            raise ValueError(
                f"config.json was written by a newer governor-audit "
                f"(schema_version={v}); upgrade governor-audit to read it. "
                f"This binary supports up to schema_version={CURRENT_SCHEMA_VERSION}."
            )
        return v

    @field_validator("gcp_project_id")
    @classmethod
    def _validate_project_id(cls, v: str) -> str:
        v = v.strip()
        if not _GCP_PROJECT_ID_RE.match(v):
            raise ValueError(
                f"gcp_project_id must match GCP project ID grammar "
                f"(^[a-z][-a-z0-9]{{4,28}}[a-z0-9]$); got {v!r}"
            )
        return v

    @field_validator("bigquery_region")
    @classmethod
    def _normalise_region(cls, v: str) -> str:
        v = v.strip().lower()
        if not v:
            raise ValueError("bigquery_region cannot be empty")
        return v


def stable_config_id(config: AuditConfig) -> str:
    """Derive a stable config_id from (project, region) for use as
    ``Opportunity.config_id``. Re-scanning the same project + region
    produces stable IDs across scans.
    """
    import hashlib

    payload = "|".join([config.gcp_project_id, config.bigquery_region])
    return hashlib.sha256(payload.encode()).hexdigest()[:36]


def migrate_v1_to_v2(payload: dict) -> dict:
    """Drop deprecated v1 fields (``manifest``) and bump schema_version."""
    if payload.get("schema_version", 1) >= 2:
        return payload
    payload = dict(payload)
    payload.pop("manifest", None)
    payload["schema_version"] = 2
    return payload


__all__: list[Any] = [
    "AuditConfig",
    "LLMConfig",
    "ScanDefaults",
    "WebUIConfig",
    "CURRENT_SCHEMA_VERSION",
    "DEFAULT_LOOKBACK_DAYS",
    "DEFAULT_MAX_SCAN_BYTES",
    "DEFAULT_PORT",
    "stable_config_id",
    "migrate_v1_to_v2",
]
