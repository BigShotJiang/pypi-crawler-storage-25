"""Read/write ``~/.governor-audit/config.json`` with secure file modes."""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path

from pydantic import ValidationError

from governor_audit.config.schema import AuditConfig, migrate_v1_to_v2

DEFAULT_CONFIG_DIR = Path.home() / ".governor-audit"
DEFAULT_CONFIG_FILENAME = "config.json"
CONFIG_DIR_MODE = 0o700
CONFIG_FILE_MODE = 0o600


class ConfigError(Exception):
    """Base for config loader errors."""


class ConfigNotFoundError(ConfigError):
    """The config file doesn't exist (yet) — likely first-run; user should
    invoke ``governor-audit init``."""


class ConfigSchemaMismatchError(ConfigError):
    """The config file is structurally invalid — wrong shape, bad value,
    or written by a newer governor-audit binary."""


def config_dir(override: Path | None = None) -> Path:
    return override or DEFAULT_CONFIG_DIR


def config_path(dir_override: Path | None = None) -> Path:
    return config_dir(dir_override) / DEFAULT_CONFIG_FILENAME


def ensure_config_dir(dir_override: Path | None = None) -> Path:
    """Create (or chmod) the config dir to mode 0700. Idempotent."""
    target = config_dir(dir_override)
    target.mkdir(parents=True, exist_ok=True)
    os.chmod(target, CONFIG_DIR_MODE)
    return target


def load_config(dir_override: Path | None = None) -> AuditConfig:
    """Load the config file. Raises ``ConfigNotFoundError`` on first-run
    and ``ConfigSchemaMismatchError`` on corruption / version mismatch.
    """
    path = config_path(dir_override)
    if not path.exists():
        raise ConfigNotFoundError(
            f"No config at {path}. Run `governor-audit init` to create one."
        )
    try:
        raw = json.loads(path.read_text())
    except json.JSONDecodeError as exc:
        raise ConfigSchemaMismatchError(
            f"Config at {path} is not valid JSON: {exc.msg} (line {exc.lineno})"
        ) from exc
    # Forward-only migration: v1 (had required `manifest` field) → v2
    # (manifest dropped per spec rev). Applied silently — once on read.
    raw = migrate_v1_to_v2(raw)
    try:
        return AuditConfig.model_validate(raw)
    except ValidationError as exc:
        raise ConfigSchemaMismatchError(
            f"Config at {path} failed validation:\n{exc}"
        ) from exc


def save_config(config: AuditConfig, dir_override: Path | None = None) -> Path:
    """Write the config to disk with mode 0600 (parent dir 0700)."""
    ensure_config_dir(dir_override)
    path = config_path(dir_override)

    # Use Pydantic's JSON serialiser so Decimal / datetime / nested models
    # round-trip cleanly. mode="json" ensures dumpable types.
    raw = config.model_dump(mode="json")
    payload = json.dumps(raw, indent=2, sort_keys=True) + "\n"

    # Write atomically: write to a temp file in the same dir, rename.
    # If the rename fails (disk full, permission flip, simulated crash),
    # remove the temp file so the next read isn't tripped up by it.
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    try:
        tmp_path.write_text(payload)
        os.chmod(tmp_path, CONFIG_FILE_MODE)
        tmp_path.replace(path)
    except Exception:
        if tmp_path.exists():
            tmp_path.unlink()
        raise

    # The replace preserves the source's mode but be defensive.
    os.chmod(path, CONFIG_FILE_MODE)
    return path


def assert_loopback_only(config: AuditConfig) -> None:
    """Defensive check used by the web layer at boot; the schema's
    own validator already enforces this on write, but a corrupt or
    hand-edited file could slip through unnoticed otherwise."""
    if config.web_ui.bind_address not in {"127.0.0.1", "::1", "localhost"}:
        raise ConfigSchemaMismatchError(
            f"web_ui.bind_address={config.web_ui.bind_address!r} is not "
            "loopback. Refusing to start the local server."
        )


def file_mode_octal(path: Path) -> int:
    """Return the file's permission bits (mode 0700/0600 etc.)."""
    return stat.S_IMODE(path.stat().st_mode)


__all__ = [
    "AuditConfig",
    "ConfigError",
    "ConfigNotFoundError",
    "ConfigSchemaMismatchError",
    "DEFAULT_CONFIG_DIR",
    "config_dir",
    "config_path",
    "ensure_config_dir",
    "load_config",
    "save_config",
    "assert_loopback_only",
    "file_mode_octal",
]
