"""Specification (SPEC/PROD) display formatters.

Pure formatting functions with no business logic.
Formatters take Spec objects and return formatted strings for display.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from supekku.scripts.lib.formatters.cell_helpers import format_tags_cell
from supekku.scripts.lib.formatters.column_defs import (
  EXT_ID_COLUMN,
  PACKAGES_COLUMN,
  REFS_COLUMN,
  SPEC_COLUMNS,
  column_labels,
)
from supekku.scripts.lib.formatters.relation_formatters import (
  format_refs_count,
  format_refs_tsv,
)
from supekku.scripts.lib.formatters.table_utils import (
  format_as_json,
  format_list_table,
)
from supekku.scripts.lib.formatters.theme import get_spec_status_style
from supekku.scripts.lib.relations.query import collect_references

if TYPE_CHECKING:
  from collections.abc import Sequence
  from pathlib import Path

  from supekku.scripts.lib.specs.models import Spec


def format_package_list(packages: list[str]) -> str:
  """Format list of packages as comma-separated string.

  Args:
    packages: List of package paths

  Returns:
    Comma-separated string of packages
  """
  return ",".join(packages)


def format_spec_list_item(
  spec: Spec,
  *,
  include_path: bool = False,
  include_packages: bool = False,
  root: Path | None = None,
) -> str:
  """Format spec as tab-separated list item with optional columns.

  Args:
    spec: Specification object to format
    include_path: Include file path instead of slug (default: False)
    include_packages: Include package list (default: False)
    root: Repository root for relative path calculation (required if include_path=True)

  Returns:
    Tab-separated string: "{id}\\t{slug|path}[\\t{packages}]"
  """
  line = spec.id

  if include_path:
    if root is None:
      msg = "root parameter required when include_path=True"
      raise ValueError(msg)
    try:
      rel = spec.path.relative_to(root)
    except ValueError:
      rel = spec.path
    line += f"\t{rel.as_posix()}"
  else:
    line += f"\t{spec.slug}"

  if include_packages:
    pkg_list = format_package_list(spec.packages)
    line += f"\t{pkg_list}"

  return line


def format_spec_list_table(
  specs: Sequence[Spec],
  format_type: str = "table",
  truncate: bool = False,
  include_packages: bool = False,
  *,
  show_external: bool = False,
  show_refs: bool = False,
) -> str:
  """Format specs as table, JSON, or TSV.

  Args:
    specs: List of Spec objects to format
    format_type: Output format (table|json|tsv)
    truncate: If True, truncate long fields to fit terminal width
    include_packages: Include package list in output
    show_external: If True, show ext_id column after ID
    show_refs: If True, show refs column (count in table, pairs in TSV)

  Returns:
    Formatted string in requested format
  """
  col_defs = list(SPEC_COLUMNS)
  if show_external:
    col_defs.insert(1, EXT_ID_COLUMN)
  if include_packages:
    col_defs.append(PACKAGES_COLUMN)
  if show_refs:
    col_defs.append(REFS_COLUMN)

  def _row(spec: Spec) -> list[str]:
    styled_id = f"[spec.id]{spec.id}[/spec.id]"
    status_style = get_spec_status_style(spec.status)
    styled_status = f"[{status_style}]{spec.status}[/{status_style}]"
    row = [styled_id]
    if show_external:
      row.append(spec.ext_id)
    row.extend([spec.name, format_tags_cell(spec.tags), styled_status])
    if include_packages:
      row.append(format_package_list(spec.packages))
    if show_refs:
      row.append(format_refs_count(collect_references(spec)))
    return row

  def _tsv_row(spec: Spec) -> list[str]:
    row = [spec.id]
    if show_external:
      row.append(spec.ext_id)
    row.extend([spec.name, spec.status])
    if include_packages:
      row.append(format_package_list(spec.packages))
    if show_refs:
      row.append(format_refs_tsv(collect_references(spec)))
    return row

  return format_list_table(
    specs,
    columns=column_labels(col_defs),
    title="Specifications",
    prepare_row=_row,
    prepare_tsv_row=_tsv_row,
    to_json=format_spec_list_json,
    format_type=format_type,
    truncate=truncate,
  )


def _format_basic_fields(spec: Spec) -> list[str]:
  """Format basic spec fields (id, name, slug, kind, status)."""
  return [
    f"ID: {spec.id}",
    f"Name: {spec.name}",
    f"Slug: {spec.slug}",
    f"Kind: {spec.kind}",
    f"Status: {spec.status}",
  ]


def _format_packages(spec: Spec) -> list[str]:
  """Format packages section if packages exist."""
  if not spec.packages:
    return []

  lines = ["", "Packages:"]
  for package in spec.packages:
    lines.append(f"  - {package}")
  return lines


def _format_taxonomy(spec: Spec) -> list[str]:
  """Format taxonomy fields (category, c4_level) if present."""
  lines: list[str] = []
  if spec.category:
    lines.append(f"Category: {spec.category}")
  if spec.c4_level:
    lines.append(f"C4 Level: {spec.c4_level}")
  return lines


def _format_external_refs(spec: Spec) -> list[str]:
  """Format external reference fields if present."""
  if not spec.ext_id:
    return []
  ext_line = f"External: {spec.ext_id}"
  if spec.ext_url:
    ext_line += f" ({spec.ext_url})"
  return [ext_line]


def _format_file_path(spec: Spec, root: Path | None = None) -> list[str]:
  """Format file path section."""
  if root:
    try:
      rel_path = spec.path.relative_to(root)
      return ["", f"File: {rel_path.as_posix()}"]
    except ValueError:
      pass
  return ["", f"File: {spec.path.as_posix()}"]


def _format_spec_relations(spec: Spec) -> list[str]:
  """Format relations section for spec details."""
  if not spec.frontmatter.relations:
    return []
  lines: list[str] = ["", "Relations:"]
  for rel in spec.frontmatter.relations:
    lines.append(f"  - {rel.type}: {rel.target}")
  return lines


def _format_requirements_summary(
  fr_count: int,
  nf_count: int,
  other_count: int = 0,
  *,
  registry_empty_hint: bool = False,
) -> list[str]:
  """Format requirements count summary for spec details.

  Args:
    fr_count: Number of functional requirements.
    nf_count: Number of non-functional requirements.
    other_count: Number of other requirements.
    registry_empty_hint: When True and all counts are zero, display a hint
      suggesting the user run ``spec-driver sync``.

  Returns:
    Lines for the requirements summary, or empty if all counts are zero
    (unless registry_empty_hint is set).
  """
  parts: list[str] = []
  if fr_count:
    parts.append(f"{fr_count} FR")
  if nf_count:
    parts.append(f"{nf_count} NF")
  if other_count:
    parts.append(f"{other_count} other")
  if parts:
    return ["", f"Requirements: {', '.join(parts)}"]
  if registry_empty_hint:
    return [
      "",
      "ℹ No requirements found in registry for this spec. Run "
      "'spec-driver sync' if the spec defines requirements.",
    ]
  return []


def _format_reverse_lookup_counts(
  delta_count: int = 0,
  revision_count: int = 0,
  audit_count: int = 0,
) -> list[str]:
  """Format reverse lookup counts for spec details.

  Args:
    delta_count: Number of deltas referencing this spec.
    revision_count: Number of revisions referencing this spec.
    audit_count: Number of audits referencing this spec.

  Returns:
    Lines for "Related:" section, or empty if all counts are zero.
  """
  entries: list[str] = []
  if delta_count:
    entries.append(f"  Deltas: {delta_count}")
  if revision_count:
    entries.append(f"  Revisions: {revision_count}")
  if audit_count:
    entries.append(f"  Audits: {audit_count}")
  if not entries:
    return []
  return ["", "Related:", *entries]


def _format_requirements_list(
  requirements: list[tuple[str, str, str]],
) -> list[str]:
  """Format expanded requirements list for --requirements flag.

  Args:
    requirements: List of (id, kind_label, title) tuples.

  Returns:
    Lines for the requirements list.
  """
  if not requirements:
    return []
  lines: list[str] = ["", "Requirements:"]
  for req_id, kind_label, title in requirements:
    lines.append(f"  {req_id}  [{kind_label}]  {title}")
  return lines


def format_spec_details(
  spec: Spec,
  root: Path | None = None,
  *,
  fr_count: int = 0,
  nf_count: int = 0,
  other_req_count: int = 0,
  delta_count: int = 0,
  revision_count: int = 0,
  audit_count: int = 0,
  requirements_list: list[tuple[str, str, str]] | None = None,
  registry_empty_hint: bool = False,
) -> str:
  """Format spec details as multi-line string for display.

  Args:
    spec: Specification object to format
    root: Repository root for relative path calculation (optional)
    fr_count: Number of functional requirements (from RequirementsRegistry)
    nf_count: Number of non-functional requirements
    other_req_count: Number of other requirements
    delta_count: Number of deltas referencing this spec
    revision_count: Number of revisions referencing this spec
    audit_count: Number of audits referencing this spec
    requirements_list: Expanded requirements list (id, kind_label, title) when
      --requirements flag is used. When provided, replaces the count summary.
    registry_empty_hint: When True and all counts are zero, show a sync hint.

  Returns:
    Formatted string with all spec details
  """
  if requirements_list is not None:
    req_section = _format_requirements_list(requirements_list)
  else:
    req_section = _format_requirements_summary(
      fr_count,
      nf_count,
      other_req_count,
      registry_empty_hint=registry_empty_hint,
    )

  sections = [
    _format_basic_fields(spec),
    _format_taxonomy(spec),
    _format_external_refs(spec),
    _format_packages(spec),
    _format_spec_relations(spec),
    req_section,
    _format_reverse_lookup_counts(delta_count, revision_count, audit_count),
    _format_file_path(spec, root),
  ]

  # Flatten all non-empty sections
  lines = [line for section in sections for line in section]
  return "\n".join(lines)


def format_spec_list_json(specs: Sequence[Spec]) -> str:
  """Format specs as JSON array.

  Args:
    specs: List of Spec objects

  Returns:
    JSON string with structure: {"items": [...]}
  """
  items = []
  for spec in specs:
    item: dict[str, Any] = {
      "id": spec.id,
      "slug": spec.slug,
      "name": spec.name,
      "kind": spec.kind,
      "status": spec.status,
      "path": spec.path.as_posix(),
      "packages": spec.packages if spec.packages else [],
    }
    if spec.ext_id:
      item["ext_id"] = spec.ext_id
    if spec.ext_url:
      item["ext_url"] = spec.ext_url
    items.append(item)

  return format_as_json(items)
