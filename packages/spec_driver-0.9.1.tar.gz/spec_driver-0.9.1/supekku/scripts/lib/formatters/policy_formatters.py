"""Policy display formatters.

Pure formatting functions with no business logic.
Formatters take PolicyRecord objects and return formatted strings for display.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from supekku.scripts.lib.formatters.cell_helpers import (
  format_date_cell,
  format_tags_cell,
)
from supekku.scripts.lib.formatters.column_defs import (
  EXT_ID_COLUMN,
  POLICY_COLUMNS,
  column_labels,
)
from supekku.scripts.lib.formatters.table_utils import (
  format_as_json,
  format_list_table,
  governance_5col_widths,
)
from supekku.scripts.lib.formatters.theme import get_policy_status_style

if TYPE_CHECKING:
  from collections.abc import Sequence

  from supekku.scripts.lib.policies.registry import PolicyRecord


def _format_basic_fields(policy: PolicyRecord) -> list[str]:
  """Format basic policy fields (id, title, status)."""
  lines = [
    f"ID: {policy.id}",
    f"Title: {policy.title}",
    f"Status: {policy.status}",
  ]
  if policy.ext_id:
    ext_line = f"External: {policy.ext_id}"
    if policy.ext_url:
      ext_line += f" ({policy.ext_url})"
    lines.append(ext_line)
  return lines


def _format_timestamps(policy: PolicyRecord) -> list[str]:
  """Format timestamp fields if present."""
  lines = []
  timestamp_fields = [
    ("Created", policy.created),
    ("Updated", policy.updated),
    ("Reviewed", policy.reviewed),
  ]
  for label, value in timestamp_fields:
    if value:
      lines.append(f"{label}: {value}")
  return lines


def _format_people(policy: PolicyRecord) -> list[str]:
  """Format people-related fields (owners)."""
  lines = []
  if policy.owners:
    lines.append(f"Owners: {', '.join(str(o) for o in policy.owners)}")
  return lines


def _format_relationships(policy: PolicyRecord) -> list[str]:
  """Format policy relationship fields (supersedes, superseded_by)."""
  lines = []
  if policy.supersedes:
    lines.append(f"Supersedes: {', '.join(policy.supersedes)}")
  if policy.superseded_by:
    lines.append(f"Superseded by: {', '.join(policy.superseded_by)}")
  return lines


def _format_artifact_references(policy: PolicyRecord) -> list[str]:
  """Format references to other artifacts (specs, requirements, etc)."""
  lines = []
  artifact_refs = [
    ("Related specs", policy.specs),
    ("Requirements", policy.requirements),
    ("Deltas", policy.deltas),
    ("Standards", policy.standards),
  ]
  for label, refs in artifact_refs:
    if refs:
      lines.append(f"{label}: {', '.join(refs)}")
  return lines


def _format_related_items(policy: PolicyRecord) -> list[str]:
  """Format related policies and standards."""
  lines = []
  if policy.related_policies:
    lines.append(f"Related policies: {', '.join(policy.related_policies)}")
  if policy.related_standards:
    lines.append(f"Related standards: {', '.join(policy.related_standards)}")
  return lines


def _format_tags_and_backlinks(policy: PolicyRecord) -> list[str]:
  """Format tags and backlinks."""
  lines = []
  if policy.tags:
    lines.append(f"Tags: {', '.join(policy.tags)}")

  if policy.backlinks:
    lines.append("\nBacklinks:")
    for link_type, refs in policy.backlinks.items():
      lines.append(f"  {link_type}: {', '.join(refs)}")
  return lines


def format_policy_details(policy: PolicyRecord) -> str:
  """Format policy details as multi-line string for display.

  Args:
    policy: PolicyRecord object to format

  Returns:
    Formatted string with all policy details
  """
  sections = [
    _format_basic_fields(policy),
    _format_timestamps(policy),
    _format_people(policy),
    _format_relationships(policy),
    _format_artifact_references(policy),
    _format_related_items(policy),
    _format_tags_and_backlinks(policy),
  ]

  # Flatten all non-empty sections
  lines = [line for section in sections for line in section]
  return "\n".join(lines)


def _prepare_policy_tsv_row(policy: PolicyRecord) -> list[str]:
  """Prepare a single policy as a plain TSV row (no markup)."""
  updated = format_date_cell(policy.updated, missing="N/A")
  return [policy.id, policy.status, policy.title, updated]


def _prepare_policy_row(policy: PolicyRecord) -> list[str]:
  """Prepare a single policy row with styling.

  Returns:
    List of formatted cell values [id, title, tags, status, updated]
  """
  title = re.sub(r"^POL-\d+:\s*", "", policy.title)
  policy_id = f"[policy.id]{policy.id}[/policy.id]"
  status_style = get_policy_status_style(policy.status)
  status_styled = f"[{status_style}]{policy.status}[/{status_style}]"

  return [
    policy_id,
    title,
    format_tags_cell(policy.tags),
    status_styled,
    format_date_cell(policy.updated),
  ]


def format_policy_list_table(
  policies: Sequence[PolicyRecord],
  format_type: str = "table",
  truncate: bool = False,
  *,
  show_external: bool = False,
) -> str:
  """Format policies as table, JSON, or TSV.

  Args:
    policies: List of PolicyRecord objects to format
    format_type: Output format (table|json|tsv)
    truncate: If True, truncate long fields (default: False, show full content)
    show_external: If True, show ext_id column after ID

  Returns:
    Formatted string in requested format
  """
  col_defs = list(POLICY_COLUMNS)
  if show_external:
    col_defs.insert(1, EXT_ID_COLUMN)

  def _row(policy: PolicyRecord) -> list[str]:
    row = _prepare_policy_row(policy)
    if show_external:
      row.insert(1, policy.ext_id)
    return row

  def _tsv_row(policy: PolicyRecord) -> list[str]:
    row = _prepare_policy_tsv_row(policy)
    if show_external:
      row.insert(1, policy.ext_id)
    return row

  return format_list_table(
    policies,
    columns=column_labels(col_defs),
    title="Policies",
    prepare_row=_row,
    prepare_tsv_row=_tsv_row,
    to_json=format_policy_list_json,
    format_type=format_type,
    truncate=truncate,
    column_widths=governance_5col_widths if not show_external else None,
  )


def format_policy_list_json(policies: Sequence[PolicyRecord]) -> str:
  """Format policies as JSON array.

  Args:
    policies: List of PolicyRecord objects

  Returns:
    JSON string representation
  """
  policy_dicts = []
  for policy in policies:
    d: dict[str, object] = {
      "id": policy.id,
      "title": policy.title,
      "status": policy.status,
      "updated": policy.updated.strftime("%Y-%m-%d") if policy.updated else None,
      "summary": policy.summary,
      "path": policy.path,
    }
    if policy.ext_id:
      d["ext_id"] = policy.ext_id
    if policy.ext_url:
      d["ext_url"] = policy.ext_url
    policy_dicts.append(d)
  return format_as_json(policy_dicts)
