"""
aibrain_payments.py — Stripe payment integration for subscriptions + marketplace.

Handles:
    - Subscription management (Free → Pro → Team → Enterprise)
    - One-time purchases (brain marketplace)
    - Revenue splits via Stripe Connect (70/30 seller/platform)
    - Webhook processing for subscription lifecycle events
    - License key generation on successful payment

Requirements:
    pip install stripe

Environment:
    STRIPE_SECRET_KEY      — Stripe API secret key
    STRIPE_WEBHOOK_SECRET  — Webhook endpoint signing secret
    STRIPE_CONNECT_ID      — Platform Connect account ID (for marketplace)

Usage:
    from aibrain_payments import PaymentManager

    pm = PaymentManager()

    # Create a checkout session for Pro subscription
    session = pm.create_subscription_checkout("pro", "user@example.com")
    print(f"Pay here: {session['url']}")

    # Create a checkout for brain purchase
    session = pm.create_brain_checkout(brain_id, buyer_email, seller_stripe_id)

    # Process webhook (in FastAPI endpoint)
    pm.handle_webhook(payload, sig_header)
"""

import hashlib
import json
import logging
import os
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger("aibrain.payments")

# ---------------------------------------------------------------------------
# Stripe price/product IDs — set after creating products in Stripe Dashboard
# or via API on first run.
# ---------------------------------------------------------------------------

SUBSCRIPTION_TIERS = {
    "pro": {
        "name": "aibrain Pro",
        "price_monthly": 995,     # cents
        "price_yearly": 9950,     # cents (2 months free)
        "description": "3 agents, 155 workflows, skill learning, marketplace access",
        "stripe_price_monthly": os.environ.get("STRIPE_PRICE_PRO_MONTHLY", ""),
        "stripe_price_yearly": os.environ.get("STRIPE_PRICE_PRO_YEARLY", ""),
    },
    "team": {
        "name": "aibrain Team",
        "price_monthly": 2995,
        "price_yearly": 29950,
        "description": "10 agents, full mesh merge, team brains",
        "stripe_price_monthly": os.environ.get("STRIPE_PRICE_TEAM_MONTHLY", ""),
        "stripe_price_yearly": os.environ.get("STRIPE_PRICE_TEAM_YEARLY", ""),
    },
    "enterprise": {
        "name": "aibrain Enterprise",
        "price_monthly": 9900,
        "price_yearly": 99000,
        "description": "Unlimited agents, swarm training, priority support",
        "stripe_price_monthly": os.environ.get("STRIPE_PRICE_ENT_MONTHLY", ""),
        "stripe_price_yearly": os.environ.get("STRIPE_PRICE_ENT_YEARLY", ""),
    },
}

PLATFORM_FEE_PERCENT = 30  # 30% marketplace cut


# ---------------------------------------------------------------------------
# Payment Manager
# ---------------------------------------------------------------------------

class PaymentManager:
    """Manages Stripe subscriptions and marketplace payments."""

    def __init__(self):
        self._stripe = None
        self._api_key = os.environ.get("STRIPE_SECRET_KEY", "")
        self._webhook_secret = os.environ.get("STRIPE_WEBHOOK_SECRET", "")

    @property
    def stripe(self):
        """Lazy import stripe — only needed when actually processing payments."""
        if self._stripe is None:
            try:
                import stripe
                stripe.api_key = self._api_key
                self._stripe = stripe
            except ImportError:
                raise ImportError(
                    "Stripe not installed. Run: pip install stripe"
                )
        return self._stripe

    @property
    def available(self) -> bool:
        """Check if Stripe is configured."""
        return bool(self._api_key)

    # ------------------------------------------------------------------
    # Products & Prices (run once to set up Stripe catalog)
    # ------------------------------------------------------------------

    def setup_products(self) -> Dict[str, Dict]:
        """Create Stripe products and prices. Run once during initial setup.

        Returns dict of tier -> {product_id, monthly_price_id, yearly_price_id}
        """
        results = {}

        for tier, config in SUBSCRIPTION_TIERS.items():
            # Create product
            product = self.stripe.Product.create(
                name=config["name"],
                description=config["description"],
                metadata={"tier": tier, "app": "aibrain"},
            )

            # Create monthly price
            monthly_price = self.stripe.Price.create(
                product=product.id,
                unit_amount=config["price_monthly"],
                currency="usd",
                recurring={"interval": "month"},
                metadata={"tier": tier, "interval": "monthly"},
            )

            # Create yearly price
            yearly_price = self.stripe.Price.create(
                product=product.id,
                unit_amount=config["price_yearly"],
                currency="usd",
                recurring={"interval": "year"},
                metadata={"tier": tier, "interval": "yearly"},
            )

            results[tier] = {
                "product_id": product.id,
                "monthly_price_id": monthly_price.id,
                "yearly_price_id": yearly_price.id,
            }

            log.info("Created Stripe product: %s (%s)", config["name"], product.id)

        return results

    # ------------------------------------------------------------------
    # Subscription Checkout
    # ------------------------------------------------------------------

    def create_subscription_checkout(
        self,
        tier: str,
        email: Optional[str] = None,
        interval: str = "monthly",
        success_url: str = "https://myaibrain.org/success?session_id={CHECKOUT_SESSION_ID}",
        cancel_url: str = "https://myaibrain.org/pricing",
    ) -> Dict:
        """Create a Stripe Checkout session for a subscription.

        Returns: {"url": checkout_url, "session_id": session_id}
        """
        if tier not in SUBSCRIPTION_TIERS:
            raise ValueError(f"Invalid tier: {tier}. Use: pro, team, enterprise")

        config = SUBSCRIPTION_TIERS[tier]
        price_key = f"stripe_price_{interval}"
        price_id = config.get(price_key, "")

        if not price_id:
            raise ValueError(
                f"Stripe price not configured for {tier}/{interval}. "
                f"Set env var or run setup_products() first."
            )

        session_params: Dict = dict(
            mode="subscription",
            line_items=[{"price": price_id, "quantity": 1}],
            success_url=success_url,
            cancel_url=cancel_url,
            metadata={
                "tier": tier,
                "app": "aibrain",
            },
            subscription_data={
                "metadata": {"tier": tier, "app": "aibrain"},
            },
        )
        if email:
            session_params["customer_email"] = email

        session = self.stripe.checkout.Session.create(**session_params)

        return {"url": session.url, "session_id": session.id}

    # ------------------------------------------------------------------
    # Brain Marketplace Checkout (with Stripe Connect for splits)
    # ------------------------------------------------------------------

    def create_brain_checkout(
        self,
        brain_id: str,
        brain_name: str,
        price_cents: int,
        buyer_email: str,
        seller_stripe_account: str = "",
        success_url: str = "https://myaibrain.org/marketplace/success?session_id={CHECKOUT_SESSION_ID}",
        cancel_url: str = "https://myaibrain.org/marketplace",
    ) -> Dict:
        """Create a checkout session for a brain marketplace purchase.

        If seller_stripe_account is provided, uses Stripe Connect for
        automatic revenue split (70% seller, 30% platform).
        """
        platform_fee = int(price_cents * PLATFORM_FEE_PERCENT / 100)

        session_params = {
            "mode": "payment",
            "customer_email": buyer_email,
            "line_items": [{
                "price_data": {
                    "currency": "usd",
                    "unit_amount": price_cents,
                    "product_data": {
                        "name": brain_name,
                        "description": f"aibrain Marketplace — {brain_name}",
                        "metadata": {"brain_id": brain_id},
                    },
                },
                "quantity": 1,
            }],
            "success_url": success_url,
            "cancel_url": cancel_url,
            "metadata": {
                "brain_id": brain_id,
                "type": "brain_purchase",
                "app": "aibrain",
            },
        }

        # Add Stripe Connect split if seller has connected account
        if seller_stripe_account:
            session_params["payment_intent_data"] = {
                "application_fee_amount": platform_fee,
                "transfer_data": {
                    "destination": seller_stripe_account,
                },
            }

        session = self.stripe.checkout.Session.create(**session_params)
        return {"url": session.url, "session_id": session.id}

    # ------------------------------------------------------------------
    # Seller Onboarding (Stripe Connect)
    # ------------------------------------------------------------------

    def create_seller_account(self, email: str) -> Dict:
        """Create a Stripe Connect account for a marketplace seller."""
        account = self.stripe.Account.create(
            type="express",
            email=email,
            capabilities={
                "transfers": {"requested": True},
            },
            metadata={"app": "aibrain", "role": "seller"},
        )

        # Create onboarding link
        link = self.stripe.AccountLink.create(
            account=account.id,
            refresh_url="https://myaibrain.org/marketplace/seller/refresh",
            return_url="https://myaibrain.org/marketplace/seller/complete",
            type="account_onboarding",
        )

        return {
            "account_id": account.id,
            "onboarding_url": link.url,
        }

    # ------------------------------------------------------------------
    # Webhook Handler
    # ------------------------------------------------------------------

    def handle_webhook(self, payload: bytes, sig_header: str) -> Dict:
        """Process a Stripe webhook event.

        Returns: {"event_type": str, "action": str, "data": dict}
        """
        try:
            event = self.stripe.Webhook.construct_event(
                payload, sig_header, self._webhook_secret
            )
        except (ValueError, self.stripe.error.SignatureVerificationError) as e:
            log.error("Webhook verification failed: %s", e)
            return {"event_type": "error", "action": "rejected", "data": {"error": str(e)}}

        event_type = event["type"]
        data = event["data"]["object"]

        if event_type == "checkout.session.completed":
            return self._handle_checkout_complete(data)

        elif event_type == "customer.subscription.updated":
            return self._handle_subscription_update(data)

        elif event_type == "customer.subscription.deleted":
            return self._handle_subscription_cancelled(data)

        elif event_type == "invoice.payment_failed":
            return self._handle_payment_failed(data)

        else:
            log.debug("Unhandled webhook event: %s", event_type)
            return {"event_type": event_type, "action": "ignored", "data": {}}

    def _handle_checkout_complete(self, session) -> Dict:
        """Handle successful checkout — generate and deliver license key."""
        metadata = session.get("metadata", {})

        if metadata.get("type") == "brain_purchase":
            # Brain marketplace purchase
            brain_id = metadata.get("brain_id", "")
            return {
                "event_type": "checkout.session.completed",
                "action": "brain_purchased",
                "data": {
                    "brain_id": brain_id,
                    "buyer_email": session.get("customer_email", ""),
                    "amount": session.get("amount_total", 0),
                },
            }

        # Subscription checkout
        tier = metadata.get("tier", "pro")
        email = session.get("customer_email", "")
        # client_reference_id — set by frontend when user is logged in,
        # used by backend/main.py to write to license_state per-user.
        client_reference_id = session.get("client_reference_id", "") or ""
        customer_id = session.get("customer", "")
        subscription_id = session.get("subscription", "")

        # Generate license key
        from aibrain_licensing import generate_key
        license_key = generate_key(
            tier=tier,
            email=email,
            stripe_customer_id=customer_id,
            stripe_sub_id=subscription_id,
        )

        # Email the license key to the customer
        try:
            import smtplib
            from email.mime.text import MIMEText

            smtp_user = os.environ.get("SMTP_USER", "")
            smtp_pass = os.environ.get("SMTP_PASS", "")
            smtp_host = os.environ.get("SMTP_HOST", "smtp.gmail.com")
            smtp_port = int(os.environ.get("SMTP_PORT", "587"))

            if smtp_user and smtp_pass and email:
                msg = MIMEText(
                    f"Thank you for subscribing to AIBrain {tier.title()}!\n\n"
                    f"Your license key:\n{license_key}\n\n"
                    f"Activate it by running:\n"
                    f"  aibrain license activate {license_key}\n\n"
                    f"— The AIBrain Team"
                )
                msg["Subject"] = f"Your AIBrain {tier.title()} License Key"
                msg["From"] = smtp_user
                msg["To"] = email

                with smtplib.SMTP(smtp_host, smtp_port) as server:
                    server.starttls()
                    server.login(smtp_user, smtp_pass)
                    server.sendmail(smtp_user, [email], msg.as_string())
                log.info("License key emailed to %s", email)
            else:
                log.warning("SMTP not configured — license key not emailed to %s", email)
        except Exception as e:
            log.error("Failed to email license key to %s: %s", email, e)

        log.info("Subscription activated: %s for %s (key: %s...)",
                 tier, email, license_key[:20])

        return {
            "event_type": "checkout.session.completed",
            "action": "subscription_activated",
            "data": {
                "tier": tier,
                "email": email,
                "license_key": license_key,
                "customer_id": customer_id,
                "subscription_id": subscription_id,
                "client_reference_id": client_reference_id,
            },
        }

    def _handle_subscription_update(self, subscription) -> Dict:
        """Handle subscription changes (upgrades, downgrades)."""
        tier = subscription.get("metadata", {}).get("tier", "unknown")
        status = subscription.get("status", "unknown")

        return {
            "event_type": "customer.subscription.updated",
            "action": "subscription_changed",
            "data": {
                "tier": tier,
                "status": status,
                "subscription_id": subscription.get("id", ""),
                "customer_id": subscription.get("customer", ""),
            },
        }

    def _handle_subscription_cancelled(self, subscription) -> Dict:
        """Handle subscription cancellation — downgrade to free."""
        return {
            "event_type": "customer.subscription.deleted",
            "action": "subscription_cancelled",
            "data": {
                "subscription_id": subscription.get("id", ""),
                "customer_id": subscription.get("customer", ""),
                "cancel_at": subscription.get("canceled_at", ""),
            },
        }

    def _handle_payment_failed(self, invoice) -> Dict:
        """Handle failed payment — notify for retry."""
        return {
            "event_type": "invoice.payment_failed",
            "action": "payment_failed",
            "data": {
                "customer_id": invoice.get("customer", ""),
                "amount": invoice.get("amount_due", 0),
                "attempt_count": invoice.get("attempt_count", 0),
            },
        }

    # ------------------------------------------------------------------
    # Customer Portal
    # ------------------------------------------------------------------

    def create_portal_session(
        self,
        customer_id: str,
        return_url: str = "https://myaibrain.org/account",
    ) -> Dict:
        """Create a Stripe Customer Portal session for self-service billing."""
        session = self.stripe.billing_portal.Session.create(
            customer=customer_id,
            return_url=return_url,
        )
        return {"url": session.url}

    # ------------------------------------------------------------------
    # Revenue Dashboard
    # ------------------------------------------------------------------

    def revenue_summary(self, days: int = 30) -> Dict:
        """Get revenue summary from Stripe."""
        import time
        since = int(time.time()) - (days * 86400)

        charges = self.stripe.Charge.list(
            created={"gte": since},
            limit=100,
        )

        total = 0
        subscription_revenue = 0
        marketplace_revenue = 0
        count = 0

        for charge in charges.auto_paging_iter():
            if charge.status == "succeeded":
                amount = charge.amount / 100  # cents to dollars
                total += amount
                count += 1

                metadata = charge.get("metadata", {})
                if metadata.get("type") == "brain_purchase":
                    marketplace_revenue += amount
                else:
                    subscription_revenue += amount

        return {
            "period_days": days,
            "total_revenue": round(total, 2),
            "subscription_revenue": round(subscription_revenue, 2),
            "marketplace_revenue": round(marketplace_revenue, 2),
            "total_charges": count,
        }
