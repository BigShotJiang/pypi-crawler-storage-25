"""
aibrain_licensing.py — License key validation and tier enforcement.

Tiers:
    free        — 1 agent, 40 generic workflows, basic memory, community brains
    pro         — 3 agents, 155 workflows, skill learning, marketplace access ($9.95/mo)
    team        — 10 agents, full mesh merge, team brains ($29/mo)
    enterprise  — Unlimited agents, swarm training, priority support ($99/mo)

License keys are signed tokens: TIER-PAYLOAD-SIGNATURE
    - Offline validation (no phone-home for basic checks)
    - Optional online validation for feature unlocks and usage metering

Usage:
    from aibrain_licensing import check_tier, require_tier, get_license

    # Check current tier
    tier = get_license().tier  # "free", "pro", "team", "enterprise"

    # Gate a feature
    if check_tier("pro"):
        run_skill_workflows()

    # Decorator for functions
    @require_tier("team")
    def mesh_merge():
        ...
"""

import base64
import hashlib
import hmac
import json
import logging
import os
import sqlite3
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from typing import Dict, Optional

log = logging.getLogger("aibrain.licensing")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

TIER_ORDER = {"free": 0, "pro": 1, "team": 2, "enterprise": 3}

TIER_LIMITS = {
    "free": {
        "max_agents": 1,
        "max_workflows": 10,
        "workflow_sources": ["generic"],
        "skill_learning": False,
        "marketplace_access": False,
        "mesh_merge": False,
        "swarm_training": False,
        "brain_export": True,
        "brain_import": True,    # community brains only
        "max_memories": 500,
        "max_entities": 500,
        "max_experiments_per_week": 1,
        "max_satellite_dbs": 3,
        "embedding_models": ["minilm"],
    },
    "pro": {
        "max_agents": 3,
        "max_workflows": 200,
        "workflow_sources": ["generic", "skill_pro", "user_pro", "content_pro", "ops_pro"],
        "skill_learning": True,
        "marketplace_access": True,
        "mesh_merge": False,     # pair merge only (2 agents)
        "swarm_training": False,
        "brain_export": True,
        "brain_import": True,
        "max_memories": 50000,
        "max_entities": None,    # unlimited
        "max_experiments_per_week": None,
        "max_satellite_dbs": None,
        "embedding_models": ["minilm", "bge-base"],
    },
    "team": {
        "max_agents": 10,
        "max_workflows": 200,
        "workflow_sources": ["generic", "skill_pro", "user_pro", "content_pro", "ops_pro"],
        "skill_learning": True,
        "marketplace_access": True,
        "mesh_merge": True,
        "swarm_training": False,
        "brain_export": True,
        "brain_import": True,
        "max_memories": 200000,
        "max_entities": None,
        "max_experiments_per_week": None,
        "max_satellite_dbs": None,
        "embedding_models": ["minilm", "bge-base"],
    },
    "enterprise": {
        "max_agents": 999999,
        "max_workflows": 200,
        "workflow_sources": ["generic", "skill_pro", "user_pro", "content_pro", "ops_pro"],
        "skill_learning": True,
        "marketplace_access": True,
        "mesh_merge": True,
        "swarm_training": True,
        "brain_export": True,
        "brain_import": True,
        "max_memories": 999999,
        "max_entities": None,
        "max_experiments_per_week": None,
        "max_satellite_dbs": None,
        "embedding_models": ["minilm", "bge-base", "custom"],
    },
}

# Resource name → TIER_LIMITS key mapping
_RESOURCE_LIMIT_KEYS = {
    "memories": "max_memories",
    "entities": "max_entities",
    "experiments_per_week": "max_experiments_per_week",
    "satellite_dbs": "max_satellite_dbs",
    "active_workflows": "max_workflows",
    "agents": "max_agents",
}

TIER_PRICES = {
    "free": 0,
    "pro": 9.95,
    "team": 29.95,
    "enterprise": 99.00,
}

# Key signing secret — MUST be provided via AIBRAIN_SIGNING_KEY env var.
# No hardcoded fallback: a public fallback would let anyone reading the
# open-source repo mint valid license keys. If the env var is missing we
# refuse to import rather than silently downgrade security.
_signing_key_env = os.environ.get("AIBRAIN_SIGNING_KEY", "")
if not _signing_key_env:
    raise ValueError(
        "AIBRAIN_SIGNING_KEY environment variable is required. "
        "Set it to a long random secret (see docs/licensing.md). "
        "No hardcoded fallback is provided — a public fallback would "
        "allow anyone to forge license keys."
    )
_SIGNING_KEY = _signing_key_env.encode()


# ---------------------------------------------------------------------------
# License data
# ---------------------------------------------------------------------------

@dataclass
class License:
    """Represents a validated license."""
    tier: str = "free"
    key: str = ""
    email: str = ""
    expires_at: str = ""    # ISO timestamp, "" = never (free tier)
    max_agents: int = 1
    stripe_customer_id: str = ""
    stripe_subscription_id: str = ""
    valid: bool = True
    reason: str = ""

    @property
    def is_expired(self) -> bool:
        if not self.expires_at:
            return False
        try:
            exp = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
            return datetime.now(timezone.utc) > exp
        except (ValueError, TypeError):
            return False

    @property
    def limits(self) -> dict:
        return TIER_LIMITS.get(self.tier, TIER_LIMITS["free"])


# ---------------------------------------------------------------------------
# License storage
# ---------------------------------------------------------------------------

def _license_path() -> Path:
    """Where the license key is stored locally — uses canonical resolver."""
    from aibrain_db import AIBRAIN_ROOT
    return AIBRAIN_ROOT / ".license"


def _load_stored_license() -> Optional[str]:
    """Load license key from disk."""
    path = _license_path()
    if path.exists():
        return path.read_text().strip()
    # Also check env var
    return os.environ.get("AIBRAIN_LICENSE_KEY", "")


def save_license(key: str):
    """Save a license key to disk."""
    path = _license_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(key)
    log.info("License key saved to %s", path)


def remove_license():
    """Remove stored license (downgrade to free)."""
    path = _license_path()
    if path.exists():
        path.unlink()
        log.info("License removed — downgraded to free tier")


# ---------------------------------------------------------------------------
# Key generation and validation
# ---------------------------------------------------------------------------

def generate_key(tier: str, email: str, expires_at: str = "",
                 stripe_customer_id: str = "", stripe_sub_id: str = "") -> str:
    """Generate a license key.

    Format: TIER-BASE64_PAYLOAD-HMAC_SIGNATURE

    This would normally only run server-side. Included here for the
    self-hosted / development case.
    """
    if tier not in TIER_ORDER:
        raise ValueError(f"Invalid tier: {tier}")

    payload = {
        "t": tier,
        "e": email,
        "x": expires_at,
        "sc": stripe_customer_id,
        "ss": stripe_sub_id,
        "ts": datetime.now(timezone.utc).isoformat(),
    }

    payload_b64 = base64.urlsafe_b64encode(
        json.dumps(payload, separators=(",", ":")).encode()
    ).decode().rstrip("=")

    sig = hmac.new(_SIGNING_KEY, payload_b64.encode(), hashlib.sha256).hexdigest()[:16]

    return f"{tier.upper()}-{payload_b64}-{sig}"


def validate_key(key: str) -> License:
    """Validate a license key offline.

    Returns a License object. Check .valid and .reason for status.
    """
    if not key:
        return License(tier="free", valid=True, reason="No key — free tier")

    parts = key.split("-", 2)
    if len(parts) != 3:
        return License(tier="free", valid=False, reason="Invalid key format")

    tier_label, payload_b64, sig = parts
    tier = tier_label.lower()

    if tier not in TIER_ORDER:
        return License(tier="free", valid=False, reason=f"Unknown tier: {tier}")

    # Verify signature
    expected_sig = hmac.new(
        _SIGNING_KEY, payload_b64.encode(), hashlib.sha256
    ).hexdigest()[:16]

    if not hmac.compare_digest(sig, expected_sig):
        return License(tier="free", valid=False, reason="Invalid signature")

    # Decode payload
    try:
        # Re-pad base64
        padded = payload_b64 + "=" * (4 - len(payload_b64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded))
    except (json.JSONDecodeError, Exception) as e:
        return License(tier="free", valid=False, reason=f"Corrupt payload: {e}")

    license = License(
        tier=tier,
        key=key,
        email=payload.get("e", ""),
        expires_at=payload.get("x", ""),
        max_agents=TIER_LIMITS[tier]["max_agents"],
        stripe_customer_id=payload.get("sc", ""),
        stripe_subscription_id=payload.get("ss", ""),
        valid=True,
    )

    # Check expiry
    if license.is_expired:
        license.valid = False
        license.reason = f"License expired: {license.expires_at}"
        license.tier = "free"

    return license


# ---------------------------------------------------------------------------
# Cached license access
# ---------------------------------------------------------------------------

_cached_license: Optional[License] = None
_license_lock = threading.Lock()


def get_license() -> License:
    """Get the current license (cached after first call)."""
    global _cached_license
    with _license_lock:
        if _cached_license is not None:
            return _cached_license
        key = _load_stored_license()
        _cached_license = validate_key(key)
        return _cached_license


def reset_cache():
    """Reset cached license (e.g., after key change)."""
    global _cached_license
    with _license_lock:
        _cached_license = None


# ---------------------------------------------------------------------------
# Rolling short-lived key refresh (item 7 of stripe split-brain fix)
# ---------------------------------------------------------------------------
#
# Triggers (all 24h windows):
#   1. Dashboard open      — the UI calls /api/license/refresh directly
#   2. First CLI command   — `aibrain` CLI calls maybe_refresh_license()
#   3. Scheduled cron      — `aibrain_license_refresh` in scheduled_jobs.json
#
# The Worker endpoint talks to Stripe server-side, mints a new key with
# `valid_until = current_period_end + 24h`, and returns it. We cache the
# refresh timestamp in ~/.aibrain/license_cache.json to avoid thrashing.

_REFRESH_CACHE_PATH = Path.home() / ".aibrain" / "license_cache.json"
_REFRESH_WINDOW_SECONDS = 86400  # 24h — SaaS standard grace period
_REFRESH_ENDPOINT = os.environ.get(
    "AIBRAIN_LICENSE_REFRESH_URL",
    "https://myaibrain.org/api/license/refresh",
)


def _read_refresh_cache() -> Dict[str, str]:
    try:
        if _REFRESH_CACHE_PATH.exists():
            return json.loads(_REFRESH_CACHE_PATH.read_text())
    except Exception:
        pass
    return {}


def _write_refresh_cache(data: Dict[str, str]) -> None:
    try:
        _REFRESH_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        _REFRESH_CACHE_PATH.write_text(json.dumps(data))
    except Exception as e:
        log.warning("Failed to write license refresh cache: %s", e)


def maybe_refresh_license(force: bool = False) -> Optional[License]:
    """Refresh the license key if the 24h cache window has elapsed.

    Returns the new License on success, None if no refresh was needed
    or the refresh failed. Safe to call from CLI startup — logs and
    returns None on any error so callers never block.
    """
    try:
        import urllib.request
        import urllib.error

        current_key = _load_stored_license()
        if not current_key:
            return None  # No key to refresh — nothing to do.

        cache = _read_refresh_cache()
        last_refresh = cache.get("last_refresh", "")
        if not force and last_refresh:
            try:
                last_ts = datetime.fromisoformat(last_refresh.replace("Z", "+00:00"))
                age = (datetime.now(timezone.utc) - last_ts).total_seconds()
                if age < _REFRESH_WINDOW_SECONDS:
                    return None  # Within window — skip
            except Exception:
                pass  # Corrupt cache — proceed to refresh

        req = urllib.request.Request(
            _REFRESH_ENDPOINT,
            method="POST",
            headers={
                "Authorization": f"Bearer {current_key}",
                "Content-Type": "application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())

        new_key = data.get("license_key", "")
        if not new_key:
            log.warning("license refresh: endpoint returned no key")
            return None

        save_license(new_key)
        reset_cache()
        _write_refresh_cache({
            "last_refresh": datetime.now(timezone.utc).isoformat(),
            "valid_until": data.get("valid_until", ""),
            "tier": data.get("tier", ""),
        })
        log.info("License refreshed — tier=%s valid_until=%s",
                 data.get("tier"), data.get("valid_until"))
        return get_license()
    except Exception as e:
        log.warning("License refresh failed (non-fatal): %s", e)
        return None


# ---------------------------------------------------------------------------
# Tier checking
# ---------------------------------------------------------------------------

def check_tier(required: str) -> bool:
    """Check if current license meets the required tier."""
    license = get_license()
    if not license.valid:
        return required == "free"
    return TIER_ORDER.get(license.tier, 0) >= TIER_ORDER.get(required, 0)


def check_feature(feature: str) -> bool:
    """Check if a specific feature is available."""
    license = get_license()
    limits = license.limits
    return bool(limits.get(feature, False))


def check_agent_limit(current_count: int) -> bool:
    """Check if adding another agent would exceed the limit."""
    license = get_license()
    return current_count < license.limits["max_agents"]


def check_workflow_source(source: str) -> bool:
    """Check if a workflow source is available in current tier."""
    license = get_license()
    return source in license.limits["workflow_sources"]


def require_tier(tier: str):
    """Decorator to gate a function behind a tier requirement."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not check_tier(tier):
                current = get_license().tier
                raise PermissionError(
                    f"This feature requires aibrain {tier.title()} "
                    f"(current: {current}). "
                    f"Upgrade at https://myaibrain.org/pricing"
                )
            return func(*args, **kwargs)
        return wrapper
    return decorator


def require_feature(feature: str):
    """Decorator to gate a function behind a feature flag."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not check_feature(feature):
                current = get_license().tier
                raise PermissionError(
                    f"Feature '{feature}' is not available on the {current} tier. "
                    f"Upgrade at https://myaibrain.org/pricing"
                )
            return func(*args, **kwargs)
        return wrapper
    return decorator


# ---------------------------------------------------------------------------
# Resource counting and enforcement (merged from tier_limits.py)
# ---------------------------------------------------------------------------

class TierLimitExceeded(Exception):
    """Raised when a tier resource cap is hit."""
    def __init__(self, resource, current, limit):
        self.resource = resource
        self.current = current
        self.limit = limit
        super().__init__(
            f"Tier limit reached: {resource} ({current}/{limit}). "
            f"Upgrade at https://myaibrain.org/pricing"
        )


def _find_db():
    """Find the aibrain database."""
    root = Path(os.environ.get("AIBRAIN_ROOT",
                os.environ.get("AIBRAIN_ROOT",
                Path(__file__).parent)))
    for name in ["aibrain.db"]:
        p = root / name
        if p.exists():
            return str(p)
    return str(root / "aibrain.db")


def get_current_count(resource: str) -> int:
    """Get the current count for a resource from live DB/filesystem."""
    root = Path(os.environ.get("AIBRAIN_ROOT",
                os.environ.get("AIBRAIN_ROOT",
                Path(__file__).parent)))
    db_path = _find_db()
    try:
        db = sqlite3.connect(db_path)
        db.row_factory = sqlite3.Row
    except Exception:
        return 0

    try:
        if resource == "memories":
            row = db.execute("SELECT COUNT(*) as cnt FROM memories WHERE active = 1").fetchone()
            return row["cnt"] if row else 0

        elif resource == "entities":
            try:
                row = db.execute("SELECT COUNT(*) as cnt FROM entities").fetchone()
                return row["cnt"] if row else 0
            except sqlite3.OperationalError:
                return 0

        elif resource == "experiments_per_week":
            try:
                row = db.execute(
                    """SELECT COUNT(*) as cnt FROM evolution_experiments
                       WHERE started_at > datetime('now', '-7 days')"""
                ).fetchone()
                return row["cnt"] if row else 0
            except sqlite3.OperationalError:
                return 0

        elif resource == "satellite_dbs":
            try:
                row = db.execute("SELECT COUNT(*) as cnt FROM satellite_dbs WHERE active = 1").fetchone()
                return row["cnt"] if row else 0
            except sqlite3.OperationalError:
                return 0

        elif resource == "active_workflows":
            jobs_path = root / "scheduled_jobs.json"
            if jobs_path.exists():
                data = json.loads(jobs_path.read_text())
                jobs = data.get("jobs", data) if isinstance(data, dict) else data
                if isinstance(jobs, list):
                    return sum(1 for j in jobs if isinstance(j, dict) and j.get("enabled", True))
                elif isinstance(jobs, dict):
                    return sum(1 for j in jobs.values() if isinstance(j, dict) and j.get("enabled", True))
            return 0

        elif resource == "agents":
            try:
                row = db.execute(
                    """SELECT COUNT(DISTINCT json_extract(summary, '$.agent')) as cnt
                       FROM activity_log WHERE created_at > datetime('now', '-24 hours')"""
                ).fetchone()
                return max(1, row["cnt"] if row else 1)
            except (sqlite3.OperationalError, TypeError):
                return 1

        return 0
    finally:
        db.close()


def _get_resource_limit(resource: str) -> int | None:
    """Get the limit for a resource based on current tier."""
    lic = get_license()
    limits = lic.limits
    key = _RESOURCE_LIMIT_KEYS.get(resource, resource)
    return limits.get(key)


def can_create(resource: str) -> tuple[bool, int | None]:
    """Check if creating one more of resource is allowed.

    Returns: (allowed: bool, remaining: int or None)
    """
    limit = _get_resource_limit(resource)
    if limit is None:
        return True, None  # unlimited

    current = get_current_count(resource)
    remaining = max(0, limit - current)
    return remaining > 0, remaining


def check_limit(resource: str):
    """Check limit and raise TierLimitExceeded if at cap.

    Call this before creating memories, entities, experiments, etc.
    """
    limit = _get_resource_limit(resource)
    if limit is None:
        return  # unlimited

    current = get_current_count(resource)
    if current >= limit:
        raise TierLimitExceeded(resource, current, limit)


def get_tier_status() -> dict:
    """Get a full status report of all tier resource limits."""
    lic = get_license()
    status = {"tier": lic.tier, "resources": {}}

    for resource in _RESOURCE_LIMIT_KEYS:
        limit = _get_resource_limit(resource)
        current = get_current_count(resource)
        status["resources"][resource] = {
            "current": current,
            "limit": limit,
            "remaining": (limit - current) if limit else None,
            "at_cap": current >= limit if limit else False,
        }

    return status


# ---------------------------------------------------------------------------
# Upgrade prompt
# ---------------------------------------------------------------------------

def upgrade_message(required_tier: str) -> str:
    """Generate a user-friendly upgrade message."""
    current = get_license().tier
    price = TIER_PRICES.get(required_tier, 0)

    features = {
        "pro": [
            "155 workflows (40 free → 155)",
            "Up to 3 agents",
            "Skill learning from experience",
            "Brain marketplace access",
            "50,000 memory capacity",
        ],
        "team": [
            "Everything in Pro, plus:",
            "Up to 10 agents",
            "Full mesh merge (multi-agent intelligence)",
            "Team brain sharing",
            "200,000 memory capacity",
        ],
        "enterprise": [
            "Everything in Team, plus:",
            "Unlimited agents",
            "Swarm training (100+ agents)",
            "Custom embedding models",
            "Priority support",
        ],
    }

    lines = [
        f"\n  Upgrade to aibrain {required_tier.title()} — ${price:.2f}/month\n",
        f"  Current tier: {current.title()}\n",
    ]

    if required_tier in features:
        lines.append(f"  What you get:")
        for f in features[required_tier]:
            lines.append(f"    + {f}")

    lines.append(f"\n  Upgrade: https://myaibrain.org/pricing")
    lines.append(f"  Or: aibrain license activate <key>\n")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cli_license(args: list) -> int:
    """Handle `aibrain license <subcommand>` CLI."""
    if not args:
        # Show current license status
        lic = get_license()
        print(f"\n  aibrain License Status\n")
        print(f"  Tier: {lic.tier.title()}")
        print(f"  Valid: {'Yes' if lic.valid else 'No'}")
        if lic.email:
            print(f"  Email: {lic.email}")
        if lic.expires_at:
            exp_str = "EXPIRED" if lic.is_expired else lic.expires_at[:10]
            print(f"  Expires: {exp_str}")
        if lic.key:
            print(f"  Key: {lic.key[:20]}...")

        limits = lic.limits
        print(f"\n  Limits:")
        print(f"    Agents: {limits['max_agents']}")
        print(f"    Workflows: {limits['max_workflows']}")
        print(f"    Memories: {limits['max_memories']:,}")
        print(f"    Skill learning: {'Yes' if limits['skill_learning'] else 'No'}")
        print(f"    Marketplace: {'Yes' if limits['marketplace_access'] else 'No'}")
        print(f"    Mesh merge: {'Yes' if limits['mesh_merge'] else 'No'}")
        print(f"    Swarm training: {'Yes' if limits['swarm_training'] else 'No'}")
        print()
        return 0

    subcmd = args[0]

    if subcmd == "activate":
        if len(args) < 2:
            print("Usage: aibrain license activate <license_key>")
            return 1
        key = args[1]
        lic = validate_key(key)
        if lic.valid:
            save_license(key)
            reset_cache()
            print(f"  License activated: {lic.tier.title()}")
            print(f"  Email: {lic.email}")
            if lic.expires_at:
                print(f"  Expires: {lic.expires_at[:10]}")
        else:
            print(f"  Invalid license: {lic.reason}")
            return 1

    elif subcmd == "deactivate":
        remove_license()
        reset_cache()
        print("  License deactivated — downgraded to Free tier.")

    elif subcmd == "generate":
        # Dev/self-hosted key generation
        if len(args) < 3:
            print("Usage: aibrain license generate <tier> <email> [--expires YYYY-MM-DD]")
            return 1
        tier = args[1].lower()
        email = args[2]
        expires = ""
        if "--expires" in args:
            idx = args.index("--expires") + 1
            expires = args[idx] if idx < len(args) else ""

        key = generate_key(tier, email, expires)
        print(f"  Generated {tier.upper()} license key:")
        print(f"  {key}")
        print(f"\n  Activate with: aibrain license activate {key}")

    elif subcmd == "tiers":
        print("\n  aibrain Pricing Tiers\n")
        for tier, price in TIER_PRICES.items():
            limits = TIER_LIMITS[tier]
            price_str = "Free" if price == 0 else f"${price:.2f}/mo"
            print(f"  {tier.upper():12s} {price_str:>10s}")
            print(f"    Agents: {limits['max_agents']}")
            print(f"    Workflows: {limits['max_workflows']}")
            print(f"    Memories: {limits['max_memories']:,}")
            features = []
            if limits['skill_learning']:
                features.append("skill learning")
            if limits['marketplace_access']:
                features.append("marketplace")
            if limits['mesh_merge']:
                features.append("mesh merge")
            if limits['swarm_training']:
                features.append("swarm training")
            if features:
                print(f"    Features: {', '.join(features)}")
            print()

    else:
        print(f"Unknown subcommand: {subcmd}")
        print("Usage: aibrain license [activate|deactivate|generate|tiers]")
        return 1

    return 0


if __name__ == "__main__":
    import sys
    sys.exit(cli_license(sys.argv[1:]))
