from setuptools import setup

setup(
    author="Matthew McKee",
    author_email="decker.ops@gmail.com",
)
