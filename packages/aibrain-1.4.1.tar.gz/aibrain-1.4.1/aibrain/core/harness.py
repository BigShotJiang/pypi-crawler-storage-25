"""
harness.py — Universal Execution Harness for AIBrain.

Every task, workflow, skill execution, and agent action passes through this
harness. It wraps execution with:

1. Classification — what type of task is this?
2. Budget check — is there budget remaining?
3. Authority check — does this agent/workflow have permission?
4. Model routing — pick the right model (deterministic/simple/judgment/complex)
5. Execution — run the actual task with timeout
6. Evaluation — score output quality (0.0-1.0)
7. Audit trail — log everything with before/after state
8. Verification — did the result actually succeed?
9. Learning — store corrections, update skill principles
10. Retry/escalate — if quality below threshold, retry or escalate

This is the core engine. Every other feature plugs into it.

Usage:
    from aibrain.core.harness import execute, HarnessConfig

    result = execute(
        task="post_to_linkedin",
        action=lambda: post_linkedin(content),
        config=HarnessConfig(
            authority="standard",
            task_type="deterministic",
            max_cost_cents=10,
        ),
    )
    # result.success — did it complete?
    # result.quality — 0.0-1.0 quality score
    # result.cost_cents — actual cost
    # result.model_used — which model executed
    # result.audit_id — reference to audit trail entry
    # result.retries — how many attempts were needed
"""

import concurrent.futures
import json
import logging
import sqlite3
import time
import traceback
import secrets
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional

from aibrain.core.workflow_quality import evaluate_workflow as _evaluate_workflow_specific

log = logging.getLogger("aibrain.harness")

# Lazy import — avoids circular imports and keeps harness self-contained.
# dynamic_router auto-discovers Ollama models and routes by task complexity.
# Falls back to local_router (static), then to hardcoded MODEL_MAP.
try:
    from aibrain.core.dynamic_router import select_model as _select_model
    _HAS_LOCAL_ROUTER = True
except ImportError:
    try:
        from aibrain.core.local_router import select_model as _select_model
        _HAS_LOCAL_ROUTER = True
    except ImportError:
        _HAS_LOCAL_ROUTER = False
        log.debug("No model router available — using static MODEL_MAP")


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

class TaskType(Enum):
    """Task classification for model routing."""
    DETERMINISTIC = "deterministic"   # No LLM needed — code only
    SIMPLE = "simple"                 # Haiku / local model
    JUDGMENT = "judgment"             # Sonnet
    COMPLEX = "complex"              # Opus


class Authority(Enum):
    """Permission level for task execution."""
    READ_ONLY = "read_only"
    STANDARD = "standard"
    ELEVATED = "elevated"
    ADMIN = "admin"


class RiskLevel(Enum):
    """Task risk classification for approval routing."""
    LOW = "low"         # Auto-approve, log honestly
    MEDIUM = "medium"   # Auto-approve, log for review
    HIGH = "high"       # Require explicit approval — block until granted


# Actions that are HIGH risk and must have explicit human approval
HIGH_RISK_ACTIONS = {
    "spend_money", "delete_file", "publish", "post_to_platform",
    "send_email", "trade", "purchase", "buy", "pay",
}

# Actions that are MEDIUM risk — auto-approved but flagged for review
MEDIUM_RISK_ACTIONS = {
    "git_push", "execute_command", "computer_use", "desktop_control",
}


AUTHORITY_CAPABILITIES = {
    Authority.READ_ONLY: {
        "allowed": {"read_file", "search_memory", "query_db", "list_files"},
        "denied": {"write_file", "send_email", "git_push", "delete_file",
                   "spend_money", "execute_command", "post_to_platform",
                   "computer_use", "desktop_control"},
    },
    Authority.STANDARD: {
        "allowed": {"read_file", "write_file", "search_memory", "store_memory",
                    "query_db", "list_files", "format_text"},
        "denied": {"send_email", "git_push", "delete_file", "spend_money",
                   "post_to_platform", "computer_use", "desktop_control"},
    },
    Authority.ELEVATED: {
        "allowed": {"read_file", "write_file", "send_email", "git_push",
                    "search_memory", "store_memory", "query_db",
                    "post_to_platform", "execute_command",
                    "computer_use", "desktop_control"},
        "requires_approval": {"delete_file", "spend_money"},
    },
    Authority.ADMIN: {
        "allowed": {"*"},
        "requires_approval": set(),
    },
}

MODEL_MAP = {
    TaskType.DETERMINISTIC: "code_only",
    TaskType.SIMPLE: "haiku",
    TaskType.JUDGMENT: "sonnet",
    TaskType.COMPLEX: "opus",
}


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@dataclass
class HarnessConfig:
    """Configuration for a harnessed execution."""
    task_type: str = "judgment"           # deterministic, simple, judgment, complex
    authority: str = "standard"           # read_only, standard, elevated, admin
    max_cost_cents: int = 1000            # budget cap for this execution
    timeout_seconds: int = 300            # max execution time
    quality_threshold: float = 0.5        # minimum quality to accept (0.0-1.0)
    max_retries: int = 1                  # retry attempts on low quality
    require_approval: bool = False        # block until human approves
    audit: bool = True                    # log to audit trail
    actor: str = "system"                 # who initiated this
    tags: list = field(default_factory=list)  # metadata tags
    company_task_id: Optional[str] = None  # if set, harness runs verify_and_complete after execution


# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------

@dataclass
class HarnessResult:
    """Result from a harnessed execution."""
    success: bool = False
    output: Any = None
    error: Optional[str] = None
    quality: Optional[float] = None      # None = could not measure (no rubric signal); 0.0-1.0 = real measurement
    # cost_cents: None = could not measure; 0 = explicitly free (local model); >0 = real measurement.
    # The harness itself cannot measure cost — the action must self-report via
    # output dict {"_cost_cents": N} OR the model routing must stamp it. Previously
    # defaulted to 0 unconditionally which made every execution_log row read "$0"
    # regardless of actual spend (Round 1 honest-rubric audit).
    cost_cents: Optional[int] = None
    # Token-to-cents equivalence (Apr 11 2026 — task #11).
    # cost_cents_actual:     real money spent (0 for subscription-backed CLI, real int for SDK/API)
    # cost_cents_equivalent: what the same tokens WOULD cost at list rates — computed for ALL
    #                         runs regardless of backend. Gives Decker visibility into subscription
    #                         utilization even when actual=0. Honest-None when token counts
    #                         unavailable (old runs, missing envelope, unknown model).
    # cost_cents stays for backwards compat (mirrors cost_cents_actual).
    cost_cents_actual: Optional[int] = None
    cost_cents_equivalent: Optional[int] = None
    # model_used: None = didn't self-report; "code_only" = deterministic (no LLM);
    # "<model_name>" = action reported actually running this model.
    # The previous version stamped model_used from the ROUTING DECISION (what we
    # planned to use) which made 1,242 rows claim model_used='sonnet' despite
    # max latency 11ms — impossible for a real sonnet call. The routing decision
    # is preserved separately in model_routed.
    model_used: Optional[str] = None
    model_routed: str = "unknown"
    duration_ms: int = 0
    retries: int = 0
    audit_id: str = ""
    run_id: str = ""
    task_type: str = ""
    authority_check: str = "passed"
    approval_status: str = "not_required"   # not_required, auto_approved_low_risk, auto_approved_medium_risk, approved, pending_approval, denied
    budget_check: str = "passed"
    evaluation_detail: str = ""
    quality_verified: bool = False     # True if automated checks ran
    quality_checks: dict = field(default_factory=dict)  # individual check results
    # Self-score path (action self-reports its own quality estimate via
    # output["_self_score"], same convention as _cost_cents). The harness
    # passes it to evaluate_task_quality() which computes divergence vs
    # the independent eval_score. Honest-None throughout: any of these
    # can be None when there is no real signal.
    self_score: Optional[float] = None  # what the action self-reported
    divergence: Optional[float] = None  # abs(self_score - eval_score) when both present
    flagged: bool = False               # True when divergence > 0.3 (chronic over/underclaim)
    verification: Optional[dict] = None  # verify_and_complete output (if company_task_id set)
    follow_up_tasks: list = field(default_factory=list)  # auto-created follow-up task IDs


# ---------------------------------------------------------------------------
# Core Harness
# ---------------------------------------------------------------------------

def execute(
    task: str,
    action: Callable,
    config: HarnessConfig = None,
    before_state: dict = None,
) -> HarnessResult:
    """
    Execute a task through the full harness pipeline.

    This is the ONLY way tasks should be executed in AIBrain.
    Everything passes through here — no exceptions.
    """
    # Lazy-register reactive chains on first harness call
    try:
        from aibrain.core.reactive_chains import register_reactive_chains
        register_reactive_chains()
    except Exception:
        pass  # Never block execution for chain registration

    if config is None:
        config = HarnessConfig()

    run_id = secrets.token_urlsafe(8)
    result = HarnessResult(run_id=run_id, task_type=config.task_type)
    start_time = time.time()

    # v1.4 P0-2: Read the thread-local checkout context so this execution
    # can be linked back to a company_issue row in execution_log.
    # checkout_task() stashes the current issue ID on this thread; we pass
    # it through to _log_audit so the row gets entity_type='company_issue'
    # and entity_id=<issue id> instead of the generic 'task' fallback.
    # Lazy import avoids circular dep (companies imports harness helpers).
    try:
        from aibrain.core import companies as _companies_mod
        linked_issue_id: Optional[str] = _companies_mod._get_current_issue_id()
    except Exception:
        linked_issue_id = None

    try:
        # ─── Step 1: Classification ───────────────────────────
        task_type = TaskType(config.task_type)
        if _HAS_LOCAL_ROUTER:
            # SelRoute-inspired local-first routing:
            #   DETERMINISTIC → code_only ($0)
            #   SIMPLE        → ollama/<model> if available, else haiku
            #   JUDGMENT      → sonnet
            #   COMPLEX       → opus
            result.model_routed = _select_model(config.task_type)
        else:
            result.model_routed = MODEL_MAP.get(task_type, "sonnet")
        # DETERMINISTIC tasks never invoke an LLM, so we know in advance that
        # model_used will be "code_only" regardless of what the action self-reports.
        if task_type == TaskType.DETERMINISTIC:
            result.model_used = "code_only"

        # ─── Step 2: Budget Check ─────────────────────────────
        budget_ok, budget_msg = _check_budget(config)
        if not budget_ok:
            result.budget_check = "failed"
            result.error = budget_msg
            _log_audit(run_id, config, task, result, before_state, linked_issue_id=linked_issue_id)
            return result

        # ─── Step 3: Authority Check ──────────────────────────
        auth_ok, auth_msg = _check_authority(task, config)
        if not auth_ok:
            result.authority_check = "failed"
            result.error = auth_msg
            _log_audit(run_id, config, task, result, before_state, linked_issue_id=linked_issue_id)
            return result

        # ─── Step 3b: Enforcement Checks ─────────────────────
        enforcement_ok, enforcement_msg = _check_enforcement(task, config, before_state)
        if not enforcement_ok:
            result.error = enforcement_msg
            result.authority_check = "enforcement_blocked"
            _log_audit(run_id, config, task, result, before_state, linked_issue_id=linked_issue_id)
            return result

        # ─── Step 4: Approval Gate (risk-classified) ──────────
        approval_status = _check_approval(task, config)
        result.approval_status = approval_status
        if approval_status in ("pending_approval", "denied"):
            result.error = (
                "Awaiting human approval — task queued"
                if approval_status == "pending_approval"
                else "Task explicitly denied in approval queue"
            )
            result.success = False
            _log_audit(run_id, config, task, result, before_state, linked_issue_id=linked_issue_id)
            return result

        # ─── Step 5: Execute with Timeout ─────────────────────
        # Retry-loop with KEEP-BEST semantics. Every attempt produces a
        # snapshot dict; after the loop, the BEST snapshot wins and gets
        # applied to `result` for persistence. This prevents the load-
        # bearing bug where a successful first attempt gets overwritten by
        # a failed retry's stale state (caught by the Apr 11 SuperWorker
        # dogfood — first SuperWorker call succeeded via CLI backend at
        # cost_cents=0, retry triggered because quality 0.42 < threshold
        # 0.5, retry's SDK fallback path failed with no API key, the
        # FAILED retry's state was what got persisted to execution_log,
        # hiding the successful run entirely).
        #
        # Best-attempt rule:
        #   1. success=True beats success=False
        #   2. within success=True: higher quality_score wins
        #   3. None quality is treated as -0.5 (worse than any measured
        #      score >=0 but better than failure) — this respects the
        #      honest-rubric "couldn't measure" semantics without
        #      promoting None to a fake default.
        attempts: list[dict] = []
        attempt = 0

        # Field snapshot helper — captures every state field a single
        # attempt can mutate, in the order they need to be restored.
        def _snapshot_attempt() -> dict:
            return {
                'success':               result.success,
                'output':                result.output,
                'error':                 result.error,
                'cost_cents':            result.cost_cents,
                'cost_cents_actual':     result.cost_cents_actual,
                'cost_cents_equivalent': result.cost_cents_equivalent,
                'model_used':            result.model_used,
                'self_score':            result.self_score,
                'quality':               result.quality,
                'divergence':            result.divergence,
                'flagged':               result.flagged,
                'evaluation_detail':     result.evaluation_detail,
                'quality_verified':      result.quality_verified,
                'quality_checks':        dict(result.quality_checks) if result.quality_checks else {},
            }

        # Reset helper — restores the per-attempt mutable fields to their
        # neutral start state so a previous attempt's success can't bleed
        # into a subsequent attempt's failure (Bug #4 root cause).
        def _reset_attempt_state():
            result.success = False
            result.output = None
            result.error = None
            result.cost_cents = None
            result.cost_cents_actual = None
            result.cost_cents_equivalent = None
            # model_used stays at "code_only" for deterministic, None elsewhere
            if config.task_type != "deterministic":
                result.model_used = None
            result.self_score = None
            result.quality = None
            result.divergence = None
            result.flagged = False
            result.evaluation_detail = ""
            result.quality_verified = False
            result.quality_checks = {}

        while attempt <= config.max_retries:
            # Reset per-attempt state (except on first attempt where the
            # fields are already at their dataclass defaults)
            if attempt > 0:
                _reset_attempt_state()

            try:
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                    future = executor.submit(action)
                    try:
                        output = future.result(timeout=config.timeout_seconds)
                    except concurrent.futures.TimeoutError:
                        result.error = f"Task timed out after {config.timeout_seconds}s"
                        result.success = False
                        log.warning("Harness timeout (attempt %d): %s after %ds",
                                    attempt + 1, task, config.timeout_seconds)
                        attempts.append(_snapshot_attempt())
                        attempt += 1
                        continue
                result.output = output
                result.success = True
                result.error = None

                # Extract self-report fields from action output, if present.
                # Conventions (action-side opt-in):
                #   output["_cost_cents"] = int    — explicit cost in cents
                #   output["_cost_usd"]   = float  — cost in USD (converted to cents)
                #   output["_model_used"] = str    — actual model that ran (not routed)
                #   output["_self_score"] = float  — action self-assessed quality
                # Local models (Ollama, llamafile) should self-report cost=0.
                # If cost not self-reported, cost_cents stays None.
                # If model not self-reported, model_used stays at its default
                # ("code_only" for deterministic, None for everything else).
                if isinstance(output, dict):
                    if "_cost_cents" in output:
                        try:
                            result.cost_cents = int(output["_cost_cents"])
                        except (TypeError, ValueError):
                            pass
                    elif "_cost_usd" in output:
                        try:
                            result.cost_cents = int(round(float(output["_cost_usd"]) * 100))
                        except (TypeError, ValueError):
                            pass
                    # Token-to-cents equivalence fields (Apr 11 2026 — task #11).
                    # Honest-None: missing key OR explicit None → stays None;
                    # any int-like value is captured as-is. Negative values
                    # are rejected silently (honest-rubric — never a fake).
                    if "_cost_cents_actual" in output:
                        v = output["_cost_cents_actual"]
                        if v is None:
                            result.cost_cents_actual = None
                        else:
                            try:
                                iv = int(v)
                                if iv >= 0:
                                    result.cost_cents_actual = iv
                            except (TypeError, ValueError):
                                pass
                    else:
                        # Fallback: if the action only self-reports _cost_cents,
                        # mirror it into _actual so downstream consumers have
                        # both names to read. The CLI path is 0, SDK path is a
                        # real int — either way, it's the actual spend.
                        if result.cost_cents is not None:
                            result.cost_cents_actual = result.cost_cents
                    if "_cost_cents_equivalent" in output:
                        v = output["_cost_cents_equivalent"]
                        if v is None:
                            result.cost_cents_equivalent = None
                        else:
                            try:
                                iv = int(v)
                                if iv >= 0:
                                    result.cost_cents_equivalent = iv
                            except (TypeError, ValueError):
                                pass
                    if "_model_used" in output:
                        m = output["_model_used"]
                        if isinstance(m, str) and m:
                            # v1.4 P0-3: refuse to stamp the bare family name
                            # ('sonnet'/'opus'/'haiku') as model_used. The old
                            # router path did exactly this and polluted 1,242
                            # rows with model_used='sonnet' that were really
                            # 11ms code paths. If the self-report is a bare
                            # family name, we append '-unknown' so the honest
                            # rubric can still see it but downstream analysis
                            # can tell it apart from a fully-qualified slug.
                            m_stripped = m.strip()
                            if m_stripped in ("sonnet", "opus", "haiku"):
                                log.warning(
                                    "model_used self-report is bare family name %r — "
                                    "stamping as %r so unknown-version runs are visible "
                                    "in execution_log. Fix the caller to pass a real "
                                    "version slug (e.g. 'claude-sonnet-4-20250514').",
                                    m_stripped, f"{m_stripped}-unknown",
                                )
                                result.model_used = f"{m_stripped}-unknown"
                            else:
                                result.model_used = m_stripped
                    # Self-score self-report (matches _cost_cents convention).
                    if "_self_score" in output:
                        ss = output["_self_score"]
                        if ss is None:
                            result.self_score = None
                        else:
                            try:
                                ssf = float(ss)
                                if 0.0 <= ssf <= 1.0:
                                    result.self_score = ssf
                                # else: out of range -> stays None (honest-rubric)
                            except (TypeError, ValueError):
                                pass  # invalid -> stays None
            except Exception as e:
                result.error = str(e)
                result.success = False
                log.warning("Harness execution error (attempt %d): %s",
                           attempt + 1, e)

            # ─── Step 6: Evaluate Quality ─────────────────────
            if result.success:
                eval_result = evaluate_task_quality(
                    output=result.output,
                    task_name=task,
                    config=config,
                    self_score=result.self_score,
                    before_state=before_state,
                )
                quality = eval_result["eval_score"]
                result.quality = quality  # type: ignore[assignment]
                result.quality_verified = eval_result["verified"]
                result.quality_checks = eval_result["checks"]
                result.evaluation_detail = eval_result["detail"]
                result.divergence = eval_result.get("divergence")
                result.flagged = bool(eval_result.get("flagged"))

            # Snapshot this attempt's full state, then decide whether to retry
            attempts.append(_snapshot_attempt())

            if result.success:
                if result.quality is None:
                    break  # Couldn't measure — accept on success
                if result.quality >= config.quality_threshold:
                    break  # Above threshold — accept
                log.info("Quality %.2f below threshold %.2f (attempt %d) — retrying if budget allows",
                         result.quality, config.quality_threshold, attempt + 1)

            attempt += 1

        # ─── Pick the BEST attempt and apply it to result ─────────
        # Honest-rubric attempt comparison: success first, then quality.
        # None quality is treated as worse than any measured score but
        # better than failure (we don't promote None to a fake default).
        def _attempt_score(snap: dict) -> tuple:
            success_pri = 1 if snap.get('success') else 0
            quality = snap.get('quality')
            quality_pri = float(quality) if quality is not None else -0.5
            return (success_pri, quality_pri)

        if attempts:
            best = max(attempts, key=_attempt_score)
            for field, value in best.items():
                setattr(result, field, value)
            # retries = number of attempts AFTER the first
            result.retries = max(0, len(attempts) - 1)

    except Exception as e:
        result.error = f"Harness error: {e}\n{traceback.format_exc()}"
        result.success = False
        log.error("Harness pipeline error: %s", e)

    # ─── Step 6b: Refuse silent cost_cents=0 on non-deterministic tasks ───
    # v1.4 P0-3 residual honest-rubric gate: if this was a successful
    # non-deterministic run, the action stamped cost_cents_actual=0, AND
    # there is no token-based equivalent signal either, we have NO honest
    # measurement of what that call cost. The old default was to silently
    # write 0 into execution_log and move on — that's exactly how 1,242
    # rows ended up claiming "free" sonnet calls that were really
    # unbudgetable noise. Refuse the run so the caller is forced to either
    # supply real token counts, explicitly mark the task deterministic, or
    # hand in a measured cost.
    #
    # Deterministic tasks are exempt — 0 is the honest answer for a code-
    # only path that never touches an LLM.
    #
    # Failures are exempt — if the run raised we never got a chance to
    # measure cost anyway; the error is the signal.
    #
    # Only fires when cost_cents_actual is LITERALLY 0. None stays None
    # (honest "could not measure") and passes through unmodified.
    if (
        result.success
        and config.task_type != "deterministic"
        and result.cost_cents_actual == 0
        and result.cost_cents_equivalent is None
    ):
        raise ValueError(
            f"Cannot measure cost for non-deterministic task {task!r}. Either "
            f"supply cost_cents_actual explicitly, ensure the LLM envelope has "
            f"a usage block, or set task_type='deterministic' if this truly has "
            f"no LLM call."
        )

    # ─── Step 7: Record Timing ────────────────────────────
    result.duration_ms = int((time.time() - start_time) * 1000)

    # ─── Step 8: Audit Trail ──────────────────────────────
    if config.audit:
        result.audit_id = _log_audit(run_id, config, task, result, before_state, linked_issue_id=linked_issue_id)

    # ─── Step 9: Learning ─────────────────────────────────
    # Record learning for ALL execution outcomes — success AND failure. The
    # previous filter `result.success and quality > 0` silently dropped every
    # failure case, so evolution_outcomes had zero record of what went wrong.
    # That's how we ended up with all 1,299 rows stamped `result='success'`
    # (Round 1 honest-rubric audit).
    #
    # Skip ONLY when quality is None AND success — that's "could not measure a
    # successful run" and recording it would seed the learning system with no
    # signal. Failures are always worth recording even if quality is None.
    if not result.success or result.quality is not None:
        _record_learning(task, result, config)

    # ─── Step 10: Budget Update ───────────────────────────
    _update_budget(config, result.cost_cents)

    # ─── Step 11: Verify-and-followup ─────────────────────
    # If this harness run is tied to a company task, verify completion
    # against acceptance criteria and auto-queue follow-ups for gaps.
    if config.company_task_id:
        try:
            from aibrain.core.task_verification import verify_and_complete
            work_output = {
                "output": result.output,
                "success": result.success,
                "error": result.error,
                "quality": result.quality,
                "quality_checks": result.quality_checks,
                "evaluation_detail": result.evaluation_detail,
                "summary": str(result.output)[:4000] if result.output else "",
            }
            verification = verify_and_complete(config.company_task_id, work_output)
            result.verification = verification
            result.follow_up_tasks = verification.get("follow_up_tasks", [])
            if verification.get("gaps"):
                log.info(
                    "Harness verify: task %s status=%s gaps=%d follow_ups=%d",
                    config.company_task_id,
                    verification.get("verification_status"),
                    len(verification["gaps"]),
                    len(verification.get("follow_up_tasks", [])),
                )
        except Exception as e:
            log.warning("Harness verification step failed: %s", e)

    return result


# ---------------------------------------------------------------------------
# Pipeline Steps
# ---------------------------------------------------------------------------

def _check_budget(config: HarnessConfig) -> tuple[bool, str]:
    """Check if budget allows this execution.

    Checks budget_policies table for applicable limits.
    Creates budget_incidents at 80% (warning) and 100% (hard stop).
    """
    # Deterministic tasks cost nothing — always allowed
    if config.task_type == "deterministic":
        return True, "deterministic: $0"

    try:
        db_path = _find_db()
        if not db_path:
            return True, "no db — skipping budget check"

        import sqlite3
        db = sqlite3.connect(str(db_path))
        db.row_factory = sqlite3.Row

        # Find applicable budget policies (global or scoped to actor)
        policies = db.execute("""
            SELECT * FROM budget_policies
            WHERE is_active=1 AND (scope_type='global' OR scope_id=?)
            ORDER BY scope_type DESC
        """, (config.actor,)).fetchall()

        if not policies:
            db.close()
            return True, "no budget policy"

        for policy in policies:
            limit = policy["limit_cents"]
            warn_pct = policy["warn_percent"]

            # Calculate current spend in this window
            if policy["window"] == "month":
                window_sql = "AND timestamp > datetime('now', '-30 days')"
            elif policy["window"] == "week":
                window_sql = "AND timestamp > datetime('now', '-7 days')"
            elif policy["window"] == "day":
                window_sql = "AND timestamp > datetime('now', '-1 day')"
            else:
                window_sql = ""  # lifetime

            try:
                spent_row = db.execute(
                    "SELECT COALESCE(SUM(cost_usd * 100), 0) as spent FROM costs WHERE 1=1 " + window_sql
                ).fetchone()
                spent = int(spent_row["spent"]) if spent_row else 0
            except Exception:
                spent = 0

            # Check thresholds
            if limit > 0:
                pct = (spent / limit * 100) if limit else 0

                if pct >= 100 and policy["hard_stop"]:
                    # Create incident
                    try:
                        db.execute(
                            "INSERT INTO budget_incidents (policy_id, scope_type, scope_id, threshold_type, limit_cents, observed_cents) VALUES (?, ?, ?, 'hard_stop', ?, ?)",
                            (policy["id"], policy["scope_type"], policy["scope_id"], limit, spent)
                        )
                        db.commit()
                    except Exception:
                        pass
                    db.close()
                    return False, f"Budget exceeded: ${spent/100:.2f}/${limit/100:.2f} ({pct:.0f}%)"

                elif pct >= warn_pct:
                    log.warning("Budget warning: %.0f%% used ($%.2f/$%.2f)",
                               pct, spent/100, limit/100)
                    try:
                        db.execute(
                            "INSERT INTO budget_incidents (policy_id, scope_type, scope_id, threshold_type, limit_cents, observed_cents) VALUES (?, ?, ?, 'warning', ?, ?)",
                            (policy["id"], policy["scope_type"], policy["scope_id"], limit, spent)
                        )
                        db.commit()
                    except Exception:
                        pass

        db.close()
        return True, "ok"

    except Exception as e:
        log.debug("Budget check error: %s", e)
        return True, "budget check failed — allowing"


def _check_authority(task: str, config: HarnessConfig) -> tuple[bool, str]:
    """Check if the configured authority level allows this task.

    Two-layer check:
    1. Harness authority level (read_only/standard/elevated/admin)
    2. Database agent_permissions table (allow_always/require_approval/deny)
    """
    try:
        authority = Authority(config.authority)
    except ValueError:
        return True, "unknown authority level — defaulting to allow"

    caps = AUTHORITY_CAPABILITIES.get(authority, {})
    allowed = caps.get("allowed", set())
    denied = caps.get("denied", set())
    needs_approval = caps.get("requires_approval", set())

    # Extract the action type from the task name
    action = task.split(".")[0] if "." in task else task
    # Also check the second part (e.g., "workflow.heartbeat" → check "heartbeat" too)
    sub_action = task.split(".")[-1] if "." in task else task

    if "*" in allowed:
        # Admin level — still check DB permissions for explicit denials
        pass
    elif action in denied:
        return False, f"Authority '{config.authority}' denies action '{action}'"
    elif action in needs_approval:
        return False, f"Action '{action}' requires approval at authority level '{config.authority}'"

    # Layer 2: Check database permissions
    try:
        db_path = _find_db()
        if db_path:
            import sqlite3
            db = sqlite3.connect(str(db_path))
            db.row_factory = sqlite3.Row

            # Check for explicit deny or require_approval
            for check_action in [action, sub_action]:
                row = db.execute(
                    "SELECT permission FROM agent_permissions WHERE action_type=? AND (target=? OR target='*') ORDER BY target DESC LIMIT 1",
                    (check_action, config.actor)
                ).fetchone()

                if row:
                    perm = row["permission"]
                    if perm == "deny":
                        db.close()
                        return False, f"Permission denied: '{check_action}' is explicitly denied in agent_permissions"
                    elif perm == "require_approval":
                        db.close()
                        return False, f"Action '{check_action}' requires approval per agent_permissions table"

            db.close()
    except Exception as e:
        log.debug("Permission DB check failed: %s", e)

    return True, "ok"


def _check_enforcement(task: str, config: HarnessConfig, before_state: dict = None) -> tuple[bool, str]:
    """Run HARD RULE enforcement checks before execution.

    Maps task names to enforcement points and runs all applicable rules.
    A single blocking violation stops execution.
    """
    try:
        from aibrain.core.enforcement import enforce, load_rules

        # Map task action to enforcement point(s)
        action = task.split(".")[0] if "." in task else task
        points_to_check = []

        if action in ("git_commit", "commit"):
            points_to_check.append("pre_commit")
        if action in ("git_push", "push"):
            points_to_check.append("pre_push")
        if action in ("delete_file", "delete", "rm", "remove"):
            points_to_check.append("pre_delete")
        if action in ("publish", "post", "send_email", "tweet", "linkedin"):
            points_to_check.append("pre_publish")
        if action in ("spend", "purchase", "buy", "pay", "trade"):
            points_to_check.append("pre_spend")

        # Always run pre_action for any elevated/admin task
        if config.authority in ("elevated", "admin"):
            points_to_check.append("pre_action")

        if not points_to_check:
            return True, "no enforcement points applicable"

        # Build context from before_state and task info
        context = dict(before_state) if before_state else {}
        context.setdefault("action", action)
        context.setdefault("actor", config.actor)

        rules = load_rules()
        all_violations = []

        for point in set(points_to_check):
            result = enforce(point, context, rules=rules)
            all_violations.extend(result.violations)

        if all_violations:
            msgs = [f"[{v.rule_id}] {v.message}" for v in all_violations]
            return False, f"HARD RULE enforcement blocked: {'; '.join(msgs)}"

        return True, "enforcement passed"

    except ImportError:
        log.debug("enforcement module not available — skipping")
        return True, "enforcement module not loaded"
    except Exception as e:
        log.warning("Enforcement check error: %s", e)
        # Fail open with warning — don't break the harness if enforcement has a bug
        return True, f"enforcement error (allowed): {e}"


def classify_risk(task: str, config: HarnessConfig) -> RiskLevel:
    """Classify task risk level based on action type and authority.

    Returns:
        RiskLevel.LOW    — safe, auto-approve
        RiskLevel.MEDIUM — auto-approve but flag for review
        RiskLevel.HIGH   — require explicit human approval
    """
    action = task.split(".")[0] if "." in task else task

    # If caller explicitly requests approval, treat as high risk
    if config.require_approval:
        return RiskLevel.HIGH

    # Check action against risk sets
    if action in HIGH_RISK_ACTIONS:
        return RiskLevel.HIGH
    if action in MEDIUM_RISK_ACTIONS:
        return RiskLevel.MEDIUM

    # Elevated/admin authority doing unknown actions = medium risk
    if config.authority in ("elevated", "admin") and action not in {
        "read_file", "write_file", "search_memory", "store_memory",
        "query_db", "list_files", "format_text",
    }:
        return RiskLevel.MEDIUM

    return RiskLevel.LOW


def _check_approval(task: str, config: HarnessConfig) -> str:
    """Risk-classified approval gate.

    Returns an approval status string:
        "not_required"              — no approval gate applicable
        "auto_approved_low_risk"    — classified low risk, auto-approved honestly
        "auto_approved_medium_risk" — classified medium risk, auto-approved, flagged for review
        "approved"                  — explicit human approval found in DB
        "pending_approval"          — high risk, no approval found, BLOCKS execution
        "denied"                    — explicit human denial found in DB
    """
    risk = classify_risk(task, config)

    # Check DB for explicit approval/denial regardless of risk level
    db_status = _query_approval_db(task, config)

    if db_status == "denied":
        log.warning("Task '%s' explicitly denied in approval queue", task)
        return "denied"
    if db_status == "approved":
        log.info("Task '%s' explicitly approved via queue", task)
        return "approved"

    # No explicit DB entry — route by risk level
    if risk == RiskLevel.LOW:
        log.debug("Task '%s' auto-approved (low risk)", task)
        return "auto_approved_low_risk"

    if risk == RiskLevel.MEDIUM:
        log.info("Task '%s' auto-approved (medium risk) — flagged for review", task)
        return "auto_approved_medium_risk"

    # HIGH risk with no explicit approval — create pending entry and block
    _create_pending_approval(task, config)
    log.warning("Task '%s' requires approval — pending entry created, execution blocked", task)
    return "pending_approval"


def _query_approval_db(task: str, config: HarnessConfig) -> Optional[str]:
    """Query the approvals table for an explicit approval/denial.

    Returns 'approved', 'denied', or None if no entry found.
    """
    try:
        db_path = _find_db()
        if db_path:
            db = sqlite3.connect(str(db_path))
            db.row_factory = sqlite3.Row
            row = db.execute(
                "SELECT status FROM approvals WHERE task=? AND (actor=? OR actor='*') ORDER BY created_at DESC LIMIT 1",
                (task, config.actor or "system")
            ).fetchone()
            db.close()
            if row:
                return row["status"]
    except Exception as e:
        log.debug("Approval DB check failed (table may not exist yet): %s", e)
    return None


def _create_pending_approval(task: str, config: HarnessConfig):
    """Insert a pending approval entry so a human can approve/deny later."""
    try:
        # Bug #6 fix: use _get_or_create_db so approval requests persist on
        # fresh installs instead of silently no-op'ing.
        db_path = _get_or_create_db()
        db = sqlite3.connect(str(db_path))
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("""
            CREATE TABLE IF NOT EXISTS approvals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task TEXT NOT NULL,
                actor TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                risk_level TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                resolved_at TIMESTAMP
            )
        """)
        db.execute(
            "INSERT INTO approvals (task, actor, status, risk_level) VALUES (?, ?, 'pending', 'high')",
            (task, config.actor or "system")
        )
        db.commit()
        db.close()
        log.info("Created pending approval entry for task '%s' actor '%s'", task, config.actor)
    except Exception as e:
        log.warning("Failed to create pending approval entry: %s", e)


def _evaluate_quality(task: str, output: Any, config: HarnessConfig):
    """
    Evaluate the quality of task output.

    Returns (score 0.0-1.0 OR None, detail string).

    Returns None as the score when there is no real signal to measure.
    The caller must propagate None and store NULL in quality_score rather
    than fake a baseline. The previous version returned a hardcoded 0.5
    "base score" for JUDGMENT/COMPLEX string outputs which made 79% of
    execution_log rows show quality_score=0.5 exactly (Round 1 honest-rubric audit).

    For deterministic tasks: binary pass/fail based on output existence.
    For LLM tasks: only scores when the output shape is informative.
    """
    task_type = TaskType(config.task_type)

    if output is None:
        # For deterministic tasks, None output with no error = "nothing to do" = success
        if task_type == TaskType.DETERMINISTIC:
            return 0.7, "deterministic: completed with no output (nothing to do)"
        return 0.0, "no output produced"

    score = None  # sentinel — concrete cases below will overwrite; default is "could not measure"
    detail_parts = []

    # ─── Error-signal override (applies to all output types) ─────────────
    # Check the full string representation for hard error signals regardless
    # of any success flag — a dict with success=True but output="Traceback..."
    # should not score 0.9.
    error_override_signals = ["traceback", "exception", "attributeerror", "typeerror",
                               "valueerror", "runtimeerror", "importerror", "keyerror",
                               "zerodivisionerror", "filenotfounderror", "permissionerror"]
    output_repr = str(output).lower()
    has_error_override = any(sig in output_repr for sig in error_override_signals)

    # ─── Type-aware evaluation ────────────────────────────
    # Dict with status/success keys (structured result). A dict WITHOUT an
    # explicit success/error key carries no quality information — we refuse
    # to fake a "structured output" baseline. (Round 1 honest-rubric audit.)
    if isinstance(output, dict):
        # SuperWorker shape — recognize ONLY when there's a real result
        # object with parse_status. Generic actions can use _self_score /
        # _cost_cents WITHOUT being SuperWorkers, so the bare presence
        # of those keys is not enough.
        sw_result = output.get("result")
        is_superworker = (
            sw_result is not None
            and (hasattr(sw_result, "parse_status") or hasattr(sw_result, "synthesis_confidence"))
        )
        if is_superworker:
            ps = getattr(sw_result, "parse_status", None)
            sw_success = getattr(sw_result, "success", None)
            sw_conf = getattr(sw_result, "synthesis_confidence", None)
            if ps == "failed" or sw_success is False:
                score = 0.2
                detail_parts.append(f"superworker failed: parse_status={ps} success={sw_success}")
            elif ps == "partial":
                # Partial parse — synthesis section present but markdown
                # regex couldn't extract everything cleanly. Score
                # honestly: prefer synthesis_confidence if measured,
                # else 0.5 as the partial-floor.
                if sw_conf is not None:
                    score = float(sw_conf) * 0.85  # discount partial output
                else:
                    score = 0.5
                detail_parts.append(f"superworker partial: conf={sw_conf}")
            else:
                # ok parse — score from synthesis_confidence if present,
                # else accept-on-success at 0.85 (lower than the old
                # 0.9 default to leave headroom for divergence).
                if sw_conf is not None:
                    score = float(sw_conf)
                    detail_parts.append(f"superworker ok: synthesis_conf={sw_conf}")
                else:
                    score = 0.85
                    detail_parts.append("superworker ok: no synthesis_conf, accept-on-success")
        elif output.get("error") or output.get("status") == "failed":
            score = 0.2
            detail_parts.append("dict: error indicator present")
        elif has_error_override:
            score = 0.2
            detail_parts.append("dict: exception detected in output values")
        elif output.get("success") or output.get("status") in ("ok", "healthy", "done"):
            score = 0.9
            detail_parts.append("dict: success indicator present")
        else:
            score = None  # no explicit success/error signal — refuse to stamp
            detail_parts.append("dict: no explicit success/error key — could not measure")

    # Tuple (common for count-based results like (ok, failed))
    elif isinstance(output, tuple):
        if len(output) >= 2 and isinstance(output[0], (int, float)):
            ok_count = output[0]
            fail_count = output[1] if len(output) > 1 else 0
            if isinstance(fail_count, (int, float)) and fail_count == 0 and ok_count > 0:
                score = 1.0
                detail_parts.append(f"tuple: {ok_count} ok, {fail_count} failed")
            elif ok_count > 0:
                score = 0.7
                detail_parts.append(f"tuple: {ok_count} ok, {fail_count} failed")
            else:
                score = 0.3
                detail_parts.append(f"tuple: {ok_count} ok, {fail_count} failed")
        else:
            score = 0.6
            detail_parts.append("tuple: non-numeric tuple returned")

    # Boolean
    elif isinstance(output, bool):
        score = 1.0 if output else 0.0
        detail_parts.append(f"bool: {output}")

    # List (results collection)
    elif isinstance(output, list):
        score = 0.8 if len(output) > 0 else 0.3
        detail_parts.append(f"list: {len(output)} items")

    # String or other
    else:
        output_str = str(output)

        # Deterministic: any non-empty output is good
        if task_type == TaskType.DETERMINISTIC:
            score = 0.9 if len(output_str) > 0 else 0.0
            detail_parts.append("deterministic: output produced")
        # Simple
        elif task_type == TaskType.SIMPLE:
            score = 0.8 if len(output_str) > 5 else 0.3
            detail_parts.append("simple: text output")
        # Judgment/Complex: only scoreable when there are explicit signals.
        # Length alone is not signal — long strings can be wrong, short can be right.
        # Refuse to stamp a base score; let the caller treat None as "could not measure".
        else:
            score = None
            detail_parts.append("judgment/complex: no signal in shape alone")

        # Error/success signal check for string outputs (these ARE real signals).
        if has_error_override:
            score = 0.2 if score is None else max(0.0, score - 0.3)
            detail_parts.append("exception/traceback detected")
        elif any(sig in output_repr for sig in ["error", "failed"]):
            score = 0.3 if score is None else max(0.0, score - 0.2)
            detail_parts.append("contains error signals")
        if any(sig in output_repr for sig in ["success", "completed", "done", "posted", "created", "saved"]):
            score = 0.7 if score is None else min(1.0, score + 0.1)
            detail_parts.append("contains success signals")

    if score is None:
        return None, "; ".join(detail_parts) or "could not measure (no signal)"
    return max(0.0, min(1.0, score)), "; ".join(detail_parts) or "evaluated"


# ---------------------------------------------------------------------------
# Automated Quality Checks (post-task verification)
# ---------------------------------------------------------------------------

def _check_git_committed(repo_path: str = None) -> tuple[bool, str]:
    """Check if there are uncommitted changes (implies work wasn't committed)."""
    import subprocess
    try:
        cwd = repo_path or "."
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, timeout=10, cwd=cwd,
        )
        if result.returncode != 0:
            return False, "git not available"
        dirty = result.stdout.strip()
        if dirty:
            return False, f"uncommitted changes: {len(dirty.splitlines())} files"
        return True, "clean working tree"
    except Exception as e:
        return False, f"git check failed: {e}"


def _check_tests_pass(test_cmd: str = None) -> tuple[bool, str]:
    """Run test suite and check if tests pass."""
    import subprocess
    cmd = test_cmd or "python -m pytest --tb=no -q"
    try:
        result = subprocess.run(
            cmd.split(),
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode == 0:
            return True, "tests pass"
        # Extract failure count from pytest output
        output = result.stdout + result.stderr
        return False, f"tests failed (exit {result.returncode})"
    except Exception as e:
        return False, f"test check failed: {e}"


def _check_files_changed(before_files: dict = None) -> tuple[bool, str]:
    """Check if files were actually modified (not a no-op)."""
    if not before_files:
        return False, "no before_state to compare"
    # If before_state has file counts or hashes, compare
    if "file_count" in before_files:
        return True, "before_state recorded"
    return False, "no file tracking data"


def _check_output_not_error(output: Any) -> tuple[bool, str]:
    """Check that the output doesn't represent an error.

    Honest-rubric rule: check STRUCTURED error indicators only. Never
    pattern-match the full str repr — that gives false positives when an
    action's substantive output happens to discuss error scenarios (e.g.
    a SuperWorker producing a migration plan that mentions "rollback path"
    or "exception handling" gets falsely flagged as containing errors).

    Apr 11 SuperWorker dogfood caught this: the SuperWorker successfully
    produced a 15K-char migration plan with parse_status='ok' and
    success=True, but the str-pattern check found "error" in the synthesis
    body and flagged the run as failed.

    Recognized success/error signals (in priority order):
      1. dict with 'error' key set (truthy) → FAIL
      2. dict with 'success' key explicitly False → FAIL
      3. dict with 'status' in ('failed', 'error') → FAIL
      4. dict with SuperWorker shape (_self_score / _cost_cents / result):
         - if result has parse_status='failed' → FAIL
         - if result has success=False → FAIL
         - else → PASS
      5. dict with explicit success indicators → PASS
      6. None output → FAIL
      7. anything else → PASS (no negative signal)
    """
    if output is None:
        return False, "no output"

    if isinstance(output, dict):
        # SuperWorker shape — recognize via the harness self-report keys
        if "_self_score" in output or "_cost_cents" in output or "result" in output:
            sw_result = output.get("result")
            if sw_result is not None:
                # Check the SuperWorkerResult fields directly
                if getattr(sw_result, "parse_status", None) == "failed":
                    return False, "superworker parse_status=failed"
                if getattr(sw_result, "success", True) is False:
                    return False, "superworker success=False"
                return True, "superworker output ok"
            # No result object but harness self-report keys present — accept
            return True, "harness self-report dict (no error indicator)"
        # Generic dict shape
        if output.get("error"):
            return False, f"dict has error key: {str(output['error'])[:80]}"
        if output.get("success") is False:
            return False, "dict success=False"
        if output.get("status") in ("failed", "error"):
            return False, f"dict status={output['status']}"
        return True, "no structured error indicator"

    # For non-dict outputs (strings, lists, bools, etc.) we used to scan
    # the str repr for error words — that produced false positives for
    # any substantive output that discussed error handling. Per honest-
    # rubric: refuse to fake a signal. Non-dict success cases pass.
    return True, "no structured error indicator"


def _check_output_substantive(output: Any) -> tuple[bool, str]:
    """Check that the output has substance (not empty/trivial)."""
    if output is None:
        return False, "no output"
    if isinstance(output, dict):
        if output.get("success") or output.get("status") in ("ok", "done", "healthy"):
            return True, "success indicator"
        if output.get("error"):
            return False, "error in dict"
        return bool(output), "dict with data" if output else "empty dict"
    if isinstance(output, (list, tuple)):
        return len(output) > 0, f"{len(output)} items"
    if isinstance(output, bool):
        return output, f"bool={output}"
    if isinstance(output, str):
        return len(output) > 5, f"{len(output)} chars"
    return True, "has output"


# Check registry: name -> (check_fn, weight, requires_context)
QUALITY_CHECKS = {
    "output_no_error": (_check_output_not_error, 0.30, False),
    "output_substantive": (_check_output_substantive, 0.30, False),
    "git_committed": (_check_git_committed, 0.20, True),
    "tests_pass": (_check_tests_pass, 0.20, True),
}


def evaluate_task_quality(
    output: Any,
    task_name: str = "",
    config: HarnessConfig = None,
    self_score: float = None,
    run_checks: list = None,
    before_state: dict = None,
    repo_path: str = None,
    test_cmd: str = None,
) -> dict:
    """
    Honest quality evaluation combining automated checks and output analysis.

    Returns:
        {
            "eval_score": float,       # system-measured score (0.0-1.0)
            "self_score": float|None,   # what the caller claimed (if any)
            "verified": bool,           # True if automated checks ran
            "checks": {name: {"passed": bool, "detail": str, "weight": float}},
            "divergence": float|None,   # abs(self_score - eval_score) if both present
            "flagged": bool,            # True if divergence > 0.3
            "detail": str,              # human-readable summary
        }
    """
    if config is None:
        config = HarnessConfig()

    checks_to_run = run_checks or ["output_no_error", "output_substantive"]
    check_results = {}
    weighted_sum = 0.0
    total_weight = 0.0

    for check_name in checks_to_run:
        if check_name not in QUALITY_CHECKS:
            continue
        check_fn, weight, requires_context = QUALITY_CHECKS[check_name]

        # Skip context-dependent checks unless context provided
        if requires_context:
            if check_name == "git_committed" and repo_path is None:
                continue
            if check_name == "tests_pass" and test_cmd is None:
                continue

        try:
            if check_name == "output_no_error":
                passed, detail = check_fn(output)
            elif check_name == "output_substantive":
                passed, detail = check_fn(output)
            elif check_name == "git_committed":
                passed, detail = check_fn(repo_path)
            elif check_name == "tests_pass":
                passed, detail = check_fn(test_cmd)
            else:
                passed, detail = check_fn()
        except Exception as e:
            passed, detail = False, f"check error: {e}"

        check_results[check_name] = {
            "passed": passed,
            "detail": detail,
            "weight": weight,
        }
        weighted_sum += weight * (1.0 if passed else 0.0)
        total_weight += weight

    # Also run the existing output-shape evaluation. Both of these now
    # return None when they cannot make a real measurement — see the
    # Round 1 honest-rubric audit (the previous default-0.5 stamp made 79% of rows
    # collapse to exactly 0.5 regardless of actual quality).
    shape_score, shape_detail = _evaluate_quality(task_name, output, config)
    workflow_score = _evaluate_workflow_specific(task_name, output)

    # Build the eval_score from whichever components have real signal.
    #
    # Honest-rubric rule: a real eval_score requires at least one of
    # workflow_score or shape_score to be non-None. Automated checks like
    # output_no_error / output_substantive are verification flags ("the task
    # didn't crash and produced output") — they are necessary but NOT
    # sufficient to claim quality. A task that doesn't crash but produces
    # garbage should not score 1.0 just because nothing exploded.
    #
    # Without that rule, the 79%-of-rows-stamped-0.5 production bug becomes
    # "79%-of-rows-stamped-0.8214" which is still fake. We refuse to fake.
    if workflow_score is None and shape_score is None:
        # No real quality signal — even if checks passed, we don't claim a number.
        eval_score = None
        verified = total_weight > 0  # checks may still have run; they just don't make a score
    else:
        components = []
        if total_weight > 0:
            components.append(("checks", 0.4, weighted_sum / total_weight))
        if workflow_score is not None:
            components.append(("workflow", 0.3, workflow_score))
        if shape_score is not None:
            components.append(("shape", 0.3, shape_score))
        weight_sum = sum(w for _, w, _ in components)
        eval_score = sum(w * s for _, w, s in components) / weight_sum
        eval_score = max(0.0, min(1.0, eval_score))
        verified = total_weight > 0

    # ─── Domain correction trend adjustment ──────────────────
    # Factor the domain's correction trend into quality score (only when we
    # have a real eval_score to begin with — never invent one from a NULL).
    domain_trend = None
    if eval_score is not None:
        try:
            from aibrain.core.correction_baseline import classify_domain, correction_baseline
            domain = classify_domain(task_name)
            baseline = correction_baseline(days=30)
            domain_info = baseline.get("domains", {}).get(domain)
            if domain_info:
                domain_trend = domain_info.get("trend")
                if domain_trend == "learning":
                    eval_score += 0.05
                elif domain_trend == "regressing":
                    eval_score -= 0.05
                eval_score = max(0.0, min(1.0, eval_score))
        except Exception:
            pass  # Correction trend is advisory — never blocks evaluation

    # Divergence detection — requires both self_score and eval_score to compare.
    divergence = None
    flagged = False
    if self_score is not None and eval_score is not None:
        divergence = abs(self_score - eval_score)
        flagged = divergence > 0.3

    # Build detail string
    detail_parts = []
    for name, result in check_results.items():
        status = "PASS" if result["passed"] else "FAIL"
        detail_parts.append(f"{name}:{status}")
    detail_parts.append(f"workflow:{workflow_score:.2f}" if workflow_score is not None else "workflow:NULL")
    detail_parts.append(f"shape:{shape_score:.2f}" if shape_score is not None else "shape:NULL")
    if domain_trend and domain_trend in ("learning", "regressing"):
        detail_parts.append(f"domain_trend:{domain_trend}")
    if flagged:
        detail_parts.append(f"FLAGGED:divergence={divergence:.2f}")
    if eval_score is None:
        detail_parts.append("eval_score:NULL (no measurable signal — refused to fake a baseline)")

    result = {
        "eval_score": round(eval_score, 4) if eval_score is not None else None,
        "self_score": self_score,
        "verified": verified,
        "checks": check_results,
        "domain_trend": domain_trend,
        "divergence": round(divergence, 4) if divergence is not None else None,
        "flagged": flagged,
        "detail": "; ".join(detail_parts),
    }

    # Emit QUALITY_LOW only when we have a real score and it's actually low.
    if eval_score is not None and eval_score < 0.5:
        try:
            from aibrain.core.event_bus import emit as bus_emit, EventTypes
            bus_emit(EventTypes.QUALITY_LOW, {
                "task_name": task_name,
                "eval_score": round(eval_score, 4),
                "self_score": self_score,
                "flagged": flagged,
                "detail": result["detail"],
            })
        except Exception:
            pass  # Event emission never blocks evaluation

    return result


def _log_audit(
    run_id: str,
    config: HarnessConfig,
    task: str,
    result: HarnessResult,
    before_state: dict = None,
    linked_issue_id: Optional[str] = None,
) -> str:
    """Log execution to audit trail.

    When ``linked_issue_id`` is provided (typically pulled from
    ``companies._current_issue`` during a checkout window), the row is
    stamped with entity_type='company_issue' and entity_id=<issue id> so
    audit queries can join execution_log back to company_issues. When
    ``linked_issue_id`` is None, the row falls back to the legacy
    entity_type='task' / entity_id=NULL behavior for backcompat.
    """
    audit_id = secrets.token_urlsafe(8)

    try:
        # Log to aibrain.db execution_log table. Use _get_or_create_db() so
        # fresh installs get a persisted audit row on the first call instead
        # of silently no-op'ing (Bug #6 — _find_db's existence check made
        # first-ever audit writes disappear on clean machines).
        db_path = _get_or_create_db()
        db = sqlite3.connect(str(db_path))
        db.execute("PRAGMA journal_mode=WAL")

        # Create table if it doesn't exist. Fresh installs get the
        # full schema; existing DBs are migrated via
        # scripts/migrate_execution_log_self_score.py which is also
        # idempotent (existing-column check).
        db.execute("""
            CREATE TABLE IF NOT EXISTS execution_log (
                id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                actor TEXT NOT NULL,
                action TEXT NOT NULL,
                entity_type TEXT,
                entity_id TEXT,
                detail TEXT,
                quality_score REAL,
                self_score REAL,
                divergence REAL,
                flagged INTEGER DEFAULT 0,
                model_used TEXT,
                cost_cents INTEGER DEFAULT 0,
                cost_cents_actual INTEGER,
                cost_cents_equivalent INTEGER,
                duration_ms INTEGER DEFAULT 0,
                before_state TEXT,
                after_state TEXT,
                success INTEGER DEFAULT 0,
                error TEXT,
                task_type TEXT,
                authority TEXT,
                retries INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        # Idempotent column migration for pre-Apr11 DBs (task #11 —
        # token-to-cents equivalence). ALTER TABLE throws if the column
        # already exists; we catch and ignore.
        for ddl in (
            "ALTER TABLE execution_log ADD COLUMN cost_cents_actual INTEGER",
            "ALTER TABLE execution_log ADD COLUMN cost_cents_equivalent INTEGER",
        ):
            try:
                db.execute(ddl)
            except sqlite3.OperationalError:
                pass  # column already exists

        # When a company task is checked out on this thread, stamp the
        # row with entity_type='company_issue' and entity_id=<issue id>
        # so audit queries can join execution_log back to company_issues.
        # Otherwise keep the legacy entity_type='task' (entity_id NULL)
        # for backcompat with callers that don't use company checkouts.
        if linked_issue_id:
            entity_type_val = "company_issue"
            entity_id_val = linked_issue_id
        else:
            entity_type_val = "task"
            entity_id_val = None

        db.execute("""
            INSERT INTO execution_log
            (id, run_id, actor, action, entity_type, entity_id, detail, quality_score,
             self_score, divergence, flagged,
             model_used, cost_cents, cost_cents_actual, cost_cents_equivalent,
             duration_ms, before_state, after_state,
             success, error, task_type, authority, retries)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            audit_id, run_id, config.actor, task,
            entity_type_val,
            entity_id_val,
            json.dumps({
                "tags": config.tags,
                "evaluation": result.evaluation_detail,
                "budget_check": result.budget_check,
                "authority_check": result.authority_check,
                "approval_status": result.approval_status,
            }),
            result.quality, result.self_score, result.divergence,
            1 if result.flagged else 0,
            result.model_used, result.cost_cents,
            result.cost_cents_actual, result.cost_cents_equivalent,
            result.duration_ms,
            json.dumps(before_state) if before_state else None,
            json.dumps({"output_preview": str(result.output)[:500]}) if result.output else None,
            1 if result.success else 0,
            result.error,
            config.task_type, config.authority, result.retries,
        ])
        db.commit()
        db.close()

    except Exception as e:
        log.warning("Failed to write audit log: %s", e)

    return audit_id


def _record_learning(task: str, result: HarnessResult, config: HarnessConfig):
    """Record execution outcome for skill learning and evolution.

    The outcome category is derived from BOTH success and quality, not from
    success alone. The previous version stamped every row with
    `result='success' if no exception' else 'failure'` which made 1,299
    rows in a row all say 'success' regardless of actual outcome
    (Round 1 honest-rubric audit). This version:

      - 'failure'   = execution raised or flag is False (failure_reason set)
      - 'flagged'   = execution OK but measured quality below 0.5
                      (failure_reason describes why)
      - 'partial'   = execution OK, quality 0.5-0.8
      - 'succeeded' = execution OK, quality >= 0.8
      - 'no_signal' = execution OK but quality is None
                      (rubric couldn't measure — we still record for visibility)

    The `source` column now carries `harness:<task_type>` so downstream can
    filter by task complexity (deterministic vs simple vs judgment vs complex)
    rather than seeing a constant 'harness' stamp on every row.
    """
    try:
        # Bug #6 fix: use _get_or_create_db so fresh installs get their first
        # evolution_outcomes row instead of silently no-op'ing.
        db_path = _get_or_create_db()

        db = sqlite3.connect(str(db_path))
        db.execute("PRAGMA journal_mode=WAL")

        # Record in evolution_outcomes for pattern detection
        db.execute("""
            CREATE TABLE IF NOT EXISTS evolution_outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT, source_id TEXT, action TEXT,
                result TEXT, details TEXT, failure_reason TEXT,
                duration_seconds REAL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Classify the outcome honestly
        failure_reason = None
        if not result.success:
            outcome = "failure"
            failure_reason = (result.error or "execution failed (no error message captured)")[:500]
        elif result.quality is None:
            # Execution succeeded but rubric could not measure — be honest about it.
            outcome = "no_signal"
            failure_reason = "rubric could not measure — no workflow or shape signal"
        elif result.quality >= 0.8:
            outcome = "succeeded"
        elif result.quality >= 0.5:
            outcome = "partial"
            failure_reason = f"quality {result.quality:.2f} in partial band (0.5-0.8)"
        else:
            outcome = "flagged"
            failure_reason = f"quality {result.quality:.2f} below threshold 0.5"

        details_dict = {
            "quality": result.quality,
            "model_used": result.model_used,       # what actually ran (may be None)
            "model_routed": result.model_routed,   # what the router decided to use
            "cost_cents": result.cost_cents,       # may be None (not measured)
            "task_type": config.task_type,
            "retries": result.retries,
            "verified": result.quality_verified,
            "authority": config.authority,
        }
        if result.quality_checks:
            details_dict["checks"] = result.quality_checks
        if result.evaluation_detail:
            details_dict["evaluation_detail"] = result.evaluation_detail

        db.execute("""
            INSERT INTO evolution_outcomes
                (source, source_id, action, result, details, failure_reason, duration_seconds)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, [
            f"harness:{config.task_type}",
            result.run_id,
            task,
            outcome,
            json.dumps(details_dict),
            failure_reason,
            result.duration_ms / 1000.0,
        ])
        db.commit()
        db.close()

    except Exception as e:
        log.debug("Learning record failed: %s", e)


def _update_budget(config: HarnessConfig, cost_cents: Optional[int]):
    """Update budget tracking after execution."""
    if cost_cents is None or cost_cents <= 0:
        # None = could not measure; 0 = explicitly free (local model); nothing to record.
        return
    try:
        db_path = _find_db()
        if not db_path:
            return

        db = sqlite3.connect(str(db_path))
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("""
            INSERT INTO costs (timestamp, model, category, tokens_in, tokens_out,
                             cost_usd, latency_ms, workflow_id, success, notes)
            VALUES (datetime('now'), ?, ?, 0, 0, ?, 0, ?, 1, ?)
        """, [
            config.task_type, "harness",
            cost_cents / 100.0,
            config.actor,
            f"task={config.tags[0] if config.tags else 'unknown'}",
        ])
        db.commit()
        db.close()
    except Exception as e:
        log.debug("Budget update failed: %s", e)


def _find_db() -> Optional[Path]:
    """Find the aibrain database — read-only semantic.

    Returns the canonical path only if the file already exists. Callers that
    just READ (budget check, authority check, approval query) use this so
    they can safely no-op on fresh installs without creating an empty DB.

    Writers should use _get_or_create_db() instead — that path creates the
    parent dir + empty file if missing, guaranteeing _log_audit, _record_learning,
    and _create_pending_approval can persist their rows on fresh installs.
    Previously _find_db was the only function and the existence check made
    those writers silently no-op (Bug #6, caught in sandboxed dogfood v2).
    """
    from aibrain_db import AIBRAIN_ROOT
    db_path = AIBRAIN_ROOT / "aibrain.db"
    return db_path if db_path.exists() else None


def _get_or_create_db() -> Path:
    """Return the canonical aibrain.db path, creating the file if missing.

    Used by writers (_log_audit, _record_learning, _create_pending_approval)
    that must persist rows even on a fresh install. Parent directory is
    created if needed. The sqlite3 CREATE TABLE IF NOT EXISTS statements in
    each writer handle schema on first touch.

    The canonical resolver in aibrain_db.AIBRAIN_ROOT remains the single
    source of truth for WHERE the DB lives — this function only guarantees
    the file EXISTS at that canonical location.
    """
    from aibrain_db import AIBRAIN_ROOT
    db_path = AIBRAIN_ROOT / "aibrain.db"
    if not db_path.exists():
        db_path.parent.mkdir(parents=True, exist_ok=True)
        # Touch the file so readers see it immediately. sqlite3.connect would
        # also create it, but touching first ensures a consistent state even
        # if the connect fails partway through schema creation.
        db_path.touch()
    return db_path


# ---------------------------------------------------------------------------
# Convenience Wrappers
# ---------------------------------------------------------------------------

def execute_deterministic(task: str, action: Callable, actor: str = "system",
                          tags: list = None) -> HarnessResult:
    """Execute a deterministic task (no LLM, code only)."""
    return execute(task, action, HarnessConfig(
        task_type="deterministic",
        authority="standard",
        max_cost_cents=0,
        timeout_seconds=60,
        quality_threshold=0.1,
        max_retries=0,
        actor=actor,
        tags=tags or [task],
    ))


def execute_simple(task: str, action: Callable, actor: str = "system",
                   tags: list = None) -> HarnessResult:
    """Execute a simple task (Haiku/local model)."""
    return execute(task, action, HarnessConfig(
        task_type="simple",
        authority="standard",
        max_cost_cents=10,
        timeout_seconds=120,
        quality_threshold=0.5,
        max_retries=1,
        actor=actor,
        tags=tags or [task],
    ))


def execute_judgment(task: str, action: Callable, actor: str = "system",
                     tags: list = None) -> HarnessResult:
    """Execute a judgment task (Sonnet)."""
    return execute(task, action, HarnessConfig(
        task_type="judgment",
        authority="elevated",
        max_cost_cents=100,
        timeout_seconds=300,
        quality_threshold=0.6,
        max_retries=1,
        actor=actor,
        tags=tags or [task],
    ))


def execute_complex(task: str, action: Callable, actor: str = "system",
                    tags: list = None) -> HarnessResult:
    """Execute a complex task (Opus)."""
    return execute(task, action, HarnessConfig(
        task_type="complex",
        authority="admin",
        max_cost_cents=1000,
        timeout_seconds=600,
        quality_threshold=0.7,
        max_retries=2,
        actor=actor,
        tags=tags or [task],
    ))
