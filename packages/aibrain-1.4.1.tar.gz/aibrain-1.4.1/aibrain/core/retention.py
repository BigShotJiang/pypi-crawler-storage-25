"""
retention.py — Memory retention policy for AIBrain.

Prevents database bloat by auto-archiving old memories based on type.
Runs as part of the evolution cycle or as a standalone workflow.

Policy:
    - user, feedback, pattern, skill: KEEP FOREVER (curated knowledge)
    - project, reference, decision: 90 days (then archive)
    - completion, correction, fix, discovery: 30 days (auto-generated, high volume)
    - agent: 7 days (ephemeral session data)

"Archive" means setting active=0. Data is never deleted — just hidden
from search results. Can be restored with `aibrain memory restore <id>`.

Usage:
    from aibrain.core.retention import apply_retention_policy
    stats = apply_retention_policy(dry_run=True)
"""

import logging
import sqlite3
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.retention")

# Retention policy: type → max age in days (None = keep forever)
RETENTION_POLICY = {
    # Keep forever — curated, high value
    "user": None,
    "feedback": None,
    "pattern": None,
    "skill": None,

    # 90 days — structured knowledge
    "project": 90,
    "reference": 90,
    "decision": 90,

    # 30 days — auto-generated, high volume
    "completion": 30,
    "correction": 30,
    "fix": 30,
    "discovery": 30,

    # 7 days — ephemeral
    "agent": 7,
}

# Default for unknown types
DEFAULT_RETENTION_DAYS = 60


def apply_retention_policy(
    db_path: Optional[str] = None,
    dry_run: bool = False,
) -> dict:
    """
    Apply retention policy to memories.

    Returns dict with counts per type: {"completion": 42, "correction": 15, ...}
    """
    if db_path is None:
        from aibrain_db import AIBRAIN_ROOT
        db_path = str(AIBRAIN_ROOT / "aibrain.db")

    db = sqlite3.connect(db_path)
    db.row_factory = sqlite3.Row

    archived = {}
    total = 0

    for mem_type, max_days in RETENTION_POLICY.items():
        if max_days is None:
            continue  # Keep forever

        # Count what would be archived
        count = db.execute(
            """SELECT COUNT(*) FROM memories
               WHERE active=1 AND type=?
               AND created < datetime('now', ? || ' days')""",
            (mem_type, f"-{max_days}")
        ).fetchone()[0]

        if count > 0:
            archived[mem_type] = count
            total += count

            if not dry_run:
                db.execute(
                    """UPDATE memories SET active=0, updated=datetime('now')
                       WHERE active=1 AND type=?
                       AND created < datetime('now', ? || ' days')""",
                    (mem_type, f"-{max_days}")
                )
                log.info("Archived %d '%s' memories older than %d days",
                        count, mem_type, max_days)

    # Also archive unknown types using default retention
    unknown_count = db.execute(
        """SELECT COUNT(*) FROM memories
           WHERE active=1 AND type NOT IN (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           AND created < datetime('now', ? || ' days')""",
        tuple(RETENTION_POLICY.keys()) + (f"-{DEFAULT_RETENTION_DAYS}",)
    ).fetchone()[0]

    if unknown_count > 0:
        archived["_unknown"] = unknown_count
        total += unknown_count
        if not dry_run:
            db.execute(
                """UPDATE memories SET active=0, updated=datetime('now')
                   WHERE active=1 AND type NOT IN (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                   AND created < datetime('now', ? || ' days')""",
                tuple(RETENTION_POLICY.keys()) + (f"-{DEFAULT_RETENTION_DAYS}",)
            )

    if not dry_run:
        db.commit()

    db.close()

    result = {
        "archived": archived,
        "total_archived": total,
        "dry_run": dry_run,
        "policy": {k: f"{v} days" if v else "forever" for k, v in RETENTION_POLICY.items()},
    }

    if dry_run:
        log.info("Retention dry run: would archive %d memories", total)
    else:
        log.info("Retention applied: archived %d memories", total)

    return result


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Apply memory retention policy")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--db", help="Database path")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    result = apply_retention_policy(db_path=args.db, dry_run=args.dry_run)

    print(f"\nRetention {'preview' if args.dry_run else 'applied'}:")
    for mem_type, count in result["archived"].items():
        print(f"  {mem_type}: {count} archived")
    print(f"  Total: {result['total_archived']}")
