"""
task_verification.py — Verify-and-followup system for company tasks.

Problem this solves: tasks were being marked done without verification. When
a completion produced gaps or implied new required actions, those follow-ups
were lost. Decker has had to repeat the same work multiple times.

This module:
  1. Parses acceptance criteria from a task's description (numbered lists,
     bullet points, "must" statements).
  2. Checks a caller-supplied work_output against each criterion.
  3. Creates follow-up tasks linked via parent_task_id whenever gaps are
     detected OR whenever the completion output mentions TODOs / follow-ups.
  4. Returns a verification result that complete_task() can use to decide
     whether to actually mark the task done.

Contract:
    verify_and_complete(task_id, work_output) -> {
        'verified': bool,
        'verification_status': 'verified' | 'partial' | 'unverified',
        'gaps': [str, ...],
        'follow_up_tasks': [task_id, ...],
        'criteria': [str, ...],
        'notes': str,
    }

Design notes:
  - The parser is deliberately simple — regex over markdown. If description
    has no explicit criteria, verification falls through to substring match
    against the task title.
  - Follow-up creation uses the same create_task() path (so SelRoute routing,
    evolution logging, etc. still apply) but sets parent_task_id so the
    lineage is preserved.
"""

from __future__ import annotations

import logging
import re
import sqlite3
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.task_verification")


# ---------------------------------------------------------------------------
# DB access (mirrors companies.py pattern so we stay consistent)
# ---------------------------------------------------------------------------

def _get_db() -> sqlite3.Connection:
    """Open a connection via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    db = sqlite3.connect(str(AIBRAIN_ROOT / "aibrain.db"))
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA busy_timeout=5000")
    return db


# ---------------------------------------------------------------------------
# Acceptance criteria extraction
# ---------------------------------------------------------------------------

# Patterns that indicate a line is a criterion the work must satisfy
_NUMBERED = re.compile(r"^\s*\d+[\.)]\s+(.+?)\s*$")
_BULLET = re.compile(r"^\s*[-*+]\s+(.+?)\s*$")
_MUST = re.compile(r"(?i)(?:must|should|shall|needs? to|is required to|has to)\s+(.+?)[.!\n]")


def detect_acceptance_criteria(task_description: str) -> list[str]:
    """Extract acceptance criteria from a task description.

    Looks for:
      - Numbered list items: ``1. do the thing``
      - Bullet list items: ``- do the thing``, ``* do the thing``
      - "must"/"should"/"needs to" statements embedded in prose.

    Filters out obviously noise lines (empty, headings, code fences).
    De-dupes while preserving order.
    """
    if not task_description:
        return []

    criteria: list[str] = []
    seen: set[str] = set()

    in_code_fence = False
    for raw in task_description.splitlines():
        line = raw.rstrip()
        if line.lstrip().startswith("```"):
            in_code_fence = not in_code_fence
            continue
        if in_code_fence:
            continue
        if not line.strip():
            continue
        if line.lstrip().startswith("#"):
            continue

        m = _NUMBERED.match(line) or _BULLET.match(line)
        if m:
            text = m.group(1).strip()
            # Strip markdown emphasis/code-tick wrappers
            text = re.sub(r"[`*]", "", text)
            if text and text.lower() not in seen and len(text) > 3:
                criteria.append(text)
                seen.add(text.lower())

    # Also scan prose for must/should statements — but skip anything that's
    # already a substring of (or contains) an existing bullet/numbered item
    # so we don't double-count "must be satisfied" fragments.
    for m in _MUST.finditer(task_description):
        text = m.group(1).strip()
        text = re.sub(r"[`*]", "", text)
        low = text.lower()
        if not text or low in seen or len(text) <= 3:
            continue
        # Suppress if this fragment is contained within (or contains) an
        # already-captured criterion.
        redundant = any(
            low in existing or existing in low
            for existing in seen
        )
        if redundant:
            continue
        criteria.append(text)
        seen.add(low)

    return criteria


# ---------------------------------------------------------------------------
# Follow-up indicator detection
# ---------------------------------------------------------------------------

# Phrases in completion output that mean "more work pending"
_FOLLOWUP_PATTERNS = [
    re.compile(r"(?i)\bTODO\b[:\- ]+(.+?)(?:[.\n]|$)"),
    re.compile(r"(?i)\bfollow[- ]?up\b[:\- ]+(.+?)(?:[.\n]|$)"),
    re.compile(r"(?i)\bnext step(?:s)?\b[:\- ]+(.+?)(?:[.\n]|$)"),
    re.compile(r"(?i)\bremaining\b[:\- ]+(.+?)(?:[.\n]|$)"),
    re.compile(r"(?i)\bstill needs?\b\s+(.+?)(?:[.\n]|$)"),
    re.compile(r"(?i)\bnot yet\b\s+(.+?)(?:[.\n]|$)"),
    re.compile(r"(?i)\bFIXME\b[:\- ]+(.+?)(?:[.\n]|$)"),
]


def _extract_followup_hints(text: str) -> list[str]:
    """Scan text for follow-up indicator phrases, return snippets."""
    if not text:
        return []
    hints: list[str] = []
    seen: set[str] = set()
    for pat in _FOLLOWUP_PATTERNS:
        for m in pat.finditer(text):
            snippet = m.group(1).strip()
            # Trim trailing fluff
            snippet = snippet.strip(" `*_-:")
            if len(snippet) < 4 or len(snippet) > 300:
                continue
            key = snippet.lower()
            if key in seen:
                continue
            seen.add(key)
            hints.append(snippet)
    return hints


# ---------------------------------------------------------------------------
# Criterion matching
# ---------------------------------------------------------------------------

def _output_to_text(work_output) -> str:
    """Coerce any work_output shape into searchable text."""
    if work_output is None:
        return ""
    if isinstance(work_output, str):
        return work_output
    if isinstance(work_output, dict):
        # Prefer a dedicated 'output' or 'summary' field if present, but still
        # include the rest so criteria can match against any value.
        parts = []
        for k in ("output", "summary", "report", "result", "notes"):
            v = work_output.get(k)
            if isinstance(v, str):
                parts.append(v)
        try:
            import json
            parts.append(json.dumps(work_output, default=str))
        except Exception:
            parts.append(str(work_output))
        return "\n".join(parts)
    if isinstance(work_output, (list, tuple)):
        return "\n".join(_output_to_text(x) for x in work_output)
    return str(work_output)


_STOPWORDS = {
    "the", "a", "an", "and", "or", "of", "to", "in", "on", "for", "with",
    "is", "it", "be", "by", "as", "at", "must", "should", "needs", "need",
    "that", "this", "then", "from", "into",
}


def _stem(word: str) -> str:
    """Very lightweight stemmer: trim common English suffixes so "write",
    "writes", "writing", and "written" all compare equal for matching.

    Not linguistically correct — just enough to reduce false negatives
    on ``Write the module`` → ``Module was written``.
    """
    w = word.lower()
    # Irregular common verbs
    irregular = {
        "written": "writ", "wrote": "writ", "writing": "writ", "writes": "writ",
        "built": "buil", "building": "buil", "builds": "buil",
        "ran": "run", "running": "run", "runs": "run",
        "made": "mad", "making": "mak", "makes": "mak",
    }
    if w in irregular:
        return irregular[w]
    for suffix in ("ings", "ing", "ed", "es", "s"):
        if len(w) > len(suffix) + 2 and w.endswith(suffix):
            return w[: -len(suffix)]
    if len(w) > 3 and w.endswith("e"):
        return w[:-1]
    return w


def _criterion_satisfied(criterion: str, output_text: str) -> bool:
    """Heuristic: a criterion is satisfied if its meaningful keywords appear
    in the output.

    - Extract keywords (alphanumeric, len>=3, not stopwords).
    - Stem keywords and output words so word-form variations still match.
    - Require >=60% of keywords present.
    - If criterion has <=2 keywords, require all of them.
    """
    if not criterion or not output_text:
        return False

    raw_keywords = [
        w for w in re.findall(r"[A-Za-z][A-Za-z0-9_\-]{2,}", criterion)
        if w.lower() not in _STOPWORDS
    ]
    if not raw_keywords:
        return False

    keyword_stems = [_stem(w) for w in raw_keywords]

    # Build a set of stems from the output
    output_stems = {
        _stem(w) for w in re.findall(r"[A-Za-z][A-Za-z0-9_\-]{2,}", output_text)
    }
    # Also keep raw lowered substrings for identifier-style matches
    lower_out = output_text.lower()

    def _kw_in_output(stem: str, raw: str) -> bool:
        if stem in output_stems:
            return True
        # Identifier-style match (snake_case, camelCase fragments, etc.)
        return raw.lower() in lower_out

    hits = sum(1 for s, r in zip(keyword_stems, raw_keywords) if _kw_in_output(s, r))

    if len(raw_keywords) <= 2:
        return hits == len(raw_keywords)
    return (hits / len(raw_keywords)) >= 0.6


# ---------------------------------------------------------------------------
# Follow-up task creation
# ---------------------------------------------------------------------------

def auto_create_followups(parent_task: dict, completion_result) -> list[str]:
    """Scan a completion result for follow-up indicators and create child
    tasks for each. Returns the list of new task IDs.

    The new tasks are linked to the parent via ``parent_task_id`` and stored
    in the same company. They inherit the parent's assignee by default and
    start at priority=medium.
    """
    text = _output_to_text(completion_result)
    hints = _extract_followup_hints(text)
    if not hints:
        return []

    # Lazy import to avoid circular dependency with companies.py
    from aibrain.core.companies import create_task

    company_id = parent_task.get("company_id")
    parent_id = parent_task.get("id")
    parent_title = parent_task.get("title", "")
    assignee = parent_task.get("assignee_agent_id")

    created: list[str] = []
    for hint in hints:
        title = f"Follow-up: {hint[:80]}"
        desc = (
            f"Auto-created follow-up from task {parent_id} ({parent_title}).\n\n"
            f"Reason: completion output flagged this as pending work.\n\n"
            f"Context:\n{hint}"
        )
        try:
            new_task = create_task(
                company_id=company_id,
                title=title,
                description=desc,
                assignee_agent_id=assignee,
                priority="medium",
                auto_route=False,  # inherit parent's assignee verbatim
            )
            new_id = new_task.get("id")
            if not new_id:
                continue
            # Set parent_task_id on the new task
            db = _get_db()
            try:
                db.execute(
                    "UPDATE company_issues SET parent_task_id=? WHERE id=?",
                    (parent_id, new_id),
                )
                db.commit()
            finally:
                db.close()
            created.append(new_id)
            log.info("Auto-created follow-up task %s for parent %s: %s",
                     new_id, parent_id, hint[:60])
        except Exception as e:
            log.warning("Follow-up creation failed for hint %r: %s", hint[:60], e)

    return created


# ---------------------------------------------------------------------------
# Main verification entry point
# ---------------------------------------------------------------------------

def verify_and_complete(task_id: str, work_output) -> dict:
    """Verify task completion against acceptance criteria. If verification
    passes, the caller is expected to actually mark the task done.

    This function:
      - Loads the task row.
      - Extracts acceptance criteria from the description.
      - Checks each criterion against the work_output.
      - Creates follow-up tasks for every gap.
      - Also scans the work_output itself for TODO/follow-up hints and
        creates child tasks for those.
      - Updates verification_status and verification_notes on the task row.

    Returns:
        {
            'verified': bool,   # True iff status == 'verified'
            'verification_status': 'verified'|'partial'|'unverified',
            'criteria': [...],
            'gaps': [...],
            'follow_up_tasks': [task_id, ...],
            'notes': str,
        }
    """
    db = _get_db()
    row = db.execute(
        "SELECT * FROM company_issues WHERE id=?", (task_id,)
    ).fetchone()
    if not row:
        db.close()
        return {
            "verified": False,
            "verification_status": "unverified",
            "criteria": [],
            "gaps": [],
            "follow_up_tasks": [],
            "notes": f"Task {task_id} not found",
            "error": "not_found",
        }

    task = dict(row)
    db.close()

    criteria = detect_acceptance_criteria(task.get("description") or "")
    output_text = _output_to_text(work_output)

    gaps: list[str] = []
    for c in criteria:
        if not _criterion_satisfied(c, output_text):
            gaps.append(c)

    # Fallback criterion: if no explicit criteria were parsed, at least
    # check that the output is non-empty and mentions something from the
    # task title.
    if not criteria:
        if not output_text.strip():
            gaps.append("(fallback) task produced no output")
        else:
            title_keywords = [
                w.lower() for w in re.findall(
                    r"[A-Za-z][A-Za-z0-9_\-]{3,}", task.get("title", "")
                )
                if w.lower() not in _STOPWORDS
            ]
            if title_keywords:
                lower_out = output_text.lower()
                hits = sum(1 for kw in title_keywords if kw in lower_out)
                if hits == 0:
                    gaps.append(
                        f"(fallback) output mentions none of the title keywords "
                        f"({', '.join(title_keywords[:5])})"
                    )

    # Determine status
    if gaps and criteria:
        status = "partial"
    elif gaps and not criteria:
        # Only fallback gaps → still flag as unverified (no real criteria)
        status = "unverified"
    else:
        status = "verified"

    # Create follow-up tasks for gaps (one per gap)
    follow_up_ids: list[str] = []
    if gaps:
        from aibrain.core.companies import create_task
        for gap in gaps:
            title = f"Gap follow-up: {gap[:80]}"
            desc = (
                f"Auto-created gap follow-up from parent task {task_id} "
                f"({task.get('title', '')}).\n\n"
                f"Criterion not satisfied by completion output:\n{gap}\n\n"
                f"Resolve this gap, then mark this follow-up complete."
            )
            try:
                new_task = create_task(
                    company_id=task["company_id"],
                    title=title,
                    description=desc,
                    assignee_agent_id=task.get("assignee_agent_id"),
                    priority=task.get("priority", "medium"),
                    auto_route=False,
                )
                new_id = new_task.get("id")
                if new_id:
                    db = _get_db()
                    try:
                        db.execute(
                            "UPDATE company_issues SET parent_task_id=? WHERE id=?",
                            (task_id, new_id),
                        )
                        db.commit()
                    finally:
                        db.close()
                    follow_up_ids.append(new_id)
            except Exception as e:
                log.warning("Gap follow-up creation failed: %s", e)

    # Also scan the work_output for TODO/follow-up hints
    try:
        follow_up_ids.extend(auto_create_followups(task, work_output))
    except Exception as e:
        log.warning("auto_create_followups failed: %s", e)

    # Persist verification status on the parent task
    notes = _format_verification_notes(criteria, gaps, follow_up_ids)
    db = _get_db()
    try:
        db.execute(
            "UPDATE company_issues "
            "SET verification_status=?, verification_notes=?, updated_at=datetime('now') "
            "WHERE id=?",
            (status, notes, task_id),
        )
        db.commit()
    finally:
        db.close()

    return {
        "verified": status == "verified",
        "verification_status": status,
        "criteria": criteria,
        "gaps": gaps,
        "follow_up_tasks": follow_up_ids,
        "notes": notes,
    }


def _format_verification_notes(criteria: list[str], gaps: list[str],
                               follow_up_ids: list[str]) -> str:
    lines = []
    lines.append(f"criteria_count={len(criteria)}")
    lines.append(f"gap_count={len(gaps)}")
    lines.append(f"follow_ups={len(follow_up_ids)}")
    if gaps:
        lines.append("gaps:")
        for g in gaps[:10]:
            lines.append(f"  - {g[:140]}")
    if follow_up_ids:
        lines.append("follow_up_task_ids: " + ",".join(follow_up_ids))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Public API for retroactive verification
# ---------------------------------------------------------------------------

def re_verify_task(task_id: str, work_output=None) -> dict:
    """Manually re-verify a task. If no work_output is supplied, any existing
    quality_detail / description columns are used as the completion text
    (best-effort retroactive check). Missing columns are tolerated.
    """
    if work_output is None:
        # Whitelist allowed columns to satisfy security pre-commit (no f-string SQL).
        _ALLOWED = frozenset(("quality_detail", "description"))
        db = _get_db()
        try:
            cols = {r[1] for r in db.execute(
                "PRAGMA table_info(company_issues)"
            ).fetchall()}
            select_cols = [c for c in ("quality_detail", "description") if c in cols and c in _ALLOWED]
            if not select_cols:
                work_output = ""
            else:
                # Build SQL from whitelist only — never user input
                col_sql = ",".join(select_cols)  # noqa:sql-fstring — whitelisted column names only
                row = db.execute(
                    "SELECT " + col_sql + " FROM company_issues WHERE id=?",  # noqa:sql-fstring
                    (task_id,),
                ).fetchone()
                if row:
                    work_output = "\n".join((row[c] or "") for c in select_cols)
                else:
                    work_output = ""
        finally:
            db.close()
    return verify_and_complete(task_id, work_output)


def list_followups(parent_task_id: str) -> list[dict]:
    """List all follow-up tasks linked to a parent."""
    db = _get_db()
    rows = db.execute(
        "SELECT * FROM company_issues WHERE parent_task_id=? ORDER BY created_at",
        (parent_task_id,),
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]
