"""
event_bus.py — AIBrain event bus with persistent audit log.

Simple pub/sub: emit() fires events, on() registers handlers.
Every event is logged to the event_bus_log SQLite table for
interpretability — see what's happening before wiring reactive chains.

Usage:
    from aibrain.core.event_bus import emit, on

    emit("MEMORY_STORED", {"id": 42, "type": "feedback"})
    on("QUALITY_LOW", lambda payload: print(f"Low quality: {payload}"))
"""

from __future__ import annotations

import json
import logging
import sqlite3
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

log = logging.getLogger("aibrain.event_bus")

# ---------------------------------------------------------------------------
# Handler registry (in-memory, per-process)
# ---------------------------------------------------------------------------

_handlers: dict[str, list[Callable]] = defaultdict(list)


def on(event_type: str, handler: Callable) -> None:
    """Register a handler for an event type.

    Args:
        event_type: Event name (e.g. "MEMORY_STORED", "QUALITY_LOW").
        handler: Callable that receives a single dict (the payload).
    """
    _handlers[event_type].append(handler)


def off(event_type: str, handler: Callable) -> None:
    """Unregister a handler."""
    try:
        _handlers[event_type].remove(handler)
    except ValueError:
        pass


def clear_handlers() -> None:
    """Remove all registered handlers (useful for tests)."""
    _handlers.clear()


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS event_bus_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    payload TEXT,
    created TEXT DEFAULT (datetime('now'))
);
"""

_INDEX_SQL = """
CREATE INDEX IF NOT EXISTS idx_event_bus_type ON event_bus_log(event_type);
"""


def _get_db_path() -> Path:
    """Resolve the aibrain.db path via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    return AIBRAIN_ROOT / "aibrain.db"


def _ensure_table(db: sqlite3.Connection) -> None:
    """Create event_bus_log table if it doesn't exist."""
    db.execute(_TABLE_SQL)
    db.execute(_INDEX_SQL)
    db.commit()


def _connect() -> sqlite3.Connection:
    """Open a connection to aibrain.db with WAL mode."""
    db_path = _get_db_path()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    _ensure_table(conn)
    return conn


# ---------------------------------------------------------------------------
# Core: emit
# ---------------------------------------------------------------------------

def emit(event_type: str, payload: dict | None = None, source: str | None = None) -> int | None:
    """Fire an event: validate, log to DB, then call registered handlers.

    Args:
        event_type: Event name string.
        payload: Arbitrary dict stored as JSON.
        source: Agent/process that emitted the event (validated against allowlist).

    Returns:
        Row ID of the logged event, or None if logging/validation failed.
    """
    payload = payload or {}

    # 0. Pre-dispatch validation (learning loop poisoning defense)
    try:
        from aibrain.core.event_validation import validate_event
        result = validate_event(event_type, payload, source=source)
        if not result.ok:
            log.warning("Event blocked by validation: %s", result.reason)
            return None
    except ImportError:
        pass  # validation module not available, allow event through
    except Exception as e:
        log.debug("Event validation error (non-fatal, allowing event): %s", e)

    row_id = None

    # 1. Persist to audit log
    try:
        conn = _connect()
        cur = conn.execute(
            "INSERT INTO event_bus_log (event_type, payload) VALUES (?, ?)",
            (event_type, json.dumps(payload, default=str)),
        )
        conn.commit()
        row_id = cur.lastrowid
        conn.close()
    except Exception as e:
        log.debug("Event bus log write failed (non-fatal): %s", e)

    # 2. Dispatch to in-memory handlers
    for handler in _handlers.get(event_type, []):
        try:
            handler(payload)
        except Exception as e:
            log.warning("Event handler error for %s: %s", event_type, e)

    log.debug("Event emitted: %s (id=%s)", event_type, row_id)
    return row_id


# ---------------------------------------------------------------------------
# Query: recent events
# ---------------------------------------------------------------------------

def recent(last: int = 20, event_type: str | None = None) -> list[dict]:
    """Fetch recent events from the audit log.

    Args:
        last: Number of events to return.
        event_type: Optional filter by event type.

    Returns:
        List of dicts with id, event_type, payload (parsed), created.
    """
    try:
        conn = _connect()
        if event_type:
            rows = conn.execute(
                "SELECT id, event_type, payload, created FROM event_bus_log "
                "WHERE event_type = ? ORDER BY id DESC LIMIT ?",
                (event_type, last),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT id, event_type, payload, created FROM event_bus_log "
                "ORDER BY id DESC LIMIT ?",
                (last,),
            ).fetchall()
        conn.close()

        results = []
        for r in rows:
            try:
                p = json.loads(r["payload"]) if r["payload"] else {}
            except (json.JSONDecodeError, TypeError):
                p = {"raw": r["payload"]}
            results.append({
                "id": r["id"],
                "event_type": r["event_type"],
                "payload": p,
                "created": r["created"],
            })
        return results
    except Exception as e:
        log.debug("Event bus query failed: %s", e)
        return []


def count_by_type() -> dict[str, int]:
    """Return event counts grouped by type."""
    try:
        conn = _connect()
        rows = conn.execute(
            "SELECT event_type, COUNT(*) as cnt FROM event_bus_log "
            "GROUP BY event_type ORDER BY cnt DESC"
        ).fetchall()
        conn.close()
        return {r["event_type"]: r["cnt"] for r in rows}
    except Exception:
        return {}


# ---------------------------------------------------------------------------
# Event type constants
# ---------------------------------------------------------------------------

class EventTypes:
    """Standard AIBrain event types."""
    MEMORY_STORED = "MEMORY_STORED"
    CORRECTION_RECEIVED = "CORRECTION_RECEIVED"
    QUALITY_LOW = "QUALITY_LOW"
    TASK_COMPLETED = "TASK_COMPLETED"
    WORKFLOW_EXECUTED = "WORKFLOW_EXECUTED"
    SCAN_FINDING_STORED = "SCAN_FINDING_STORED"


# ---------------------------------------------------------------------------
# CLI helper
# ---------------------------------------------------------------------------

def cli_events(args: list[str]) -> int:
    """CLI entry point for `aibrain events [--last N] [--type TYPE]`."""
    last = 20
    event_type = None

    i = 0
    while i < len(args):
        if args[i] == "--last" and i + 1 < len(args):
            try:
                last = int(args[i + 1])
            except ValueError:
                pass
            i += 2
        elif args[i] == "--type" and i + 1 < len(args):
            event_type = args[i + 1]
            i += 2
        elif args[i] == "--summary":
            counts = count_by_type()
            if not counts:
                print("  No events recorded yet.")
                return 0
            print("\n  Event Bus Summary")
            print("  " + "-" * 40)
            for etype, cnt in counts.items():
                print(f"  {etype:<30} {cnt:>5}")
            total = sum(counts.values())
            print("  " + "-" * 40)
            print(f"  {'TOTAL':<30} {total:>5}")
            print()
            return 0
        else:
            i += 1

    events = recent(last=last, event_type=event_type)
    if not events:
        print("  No events found.")
        return 0

    print(f"\n  Event Bus Log (last {last})")
    print("  " + "-" * 70)
    for e in reversed(events):  # oldest first
        payload_str = json.dumps(e["payload"], default=str)
        if len(payload_str) > 60:
            payload_str = payload_str[:57] + "..."
        print(f"  {e['created']}  {e['event_type']:<25} {payload_str}")
    print()
    return 0
