"""
workflow_runner.py — Run any workflow through the execution harness.

Wraps existing workflow functions with eval, audit, authority, and model routing.
Drop-in replacement for direct workflow execution.

Usage:
    from aibrain.core.workflow_runner import run_workflow

    result = run_workflow("heartbeat", dry_run=True)
    result = run_workflow("db_backup")
    result = run_workflow("email_auto_reply", authority="elevated")

Or from CLI:
    python -m aibrain.core.workflow_runner heartbeat --dry-run
    python -m aibrain.core.workflow_runner db_backup
"""

import importlib
import logging
import sys
from pathlib import Path
from typing import Optional

from aibrain.core.harness import (
    execute, HarnessConfig, HarnessResult,
    execute_deterministic, execute_simple
)

log = logging.getLogger("aibrain.workflow_runner")

# Workflow directory
WORKFLOW_DIR = Path(__file__).parent.parent.parent / "workflows"

# Workflow metadata — task type, authority, budget
# This is the per-workflow capability scoping Decker asked for
WORKFLOW_REGISTRY = {
    # Deterministic: no LLM needed, just code execution
    "heartbeat": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "db_backup": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "service_monitor": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0, "internal": True},
    "smart_file_organizer": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},

    # Simple: light LLM use for formatting/parsing
    "telegram_check": {"task_type": "deterministic", "authority": "standard", "max_cost": 0, "internal": True},

    # Social posting: Playwright only, computer use requires CEO approval
    "social_poster": {"task_type": "simple", "authority": "elevated", "max_cost": 0, "requires_approval": ["computer_use", "desktop_control"]},
    "social_scheduler": {"task_type": "deterministic", "authority": "elevated", "max_cost": 0, "requires_approval": ["computer_use", "desktop_control"]},
    "instagram_poster": {"task_type": "simple", "authority": "elevated", "max_cost": 0, "requires_approval": ["computer_use", "desktop_control"]},

    # Judgment: needs real LLM reasoning
    "cross_domain_questions": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "contradiction_detector": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "evolution_auto_loop": {"task_type": "judgment", "authority": "elevated", "max_cost": 200},
    "evolution_experiment": {"task_type": "complex", "authority": "elevated", "max_cost": 500},

    # Elevated: can send emails, push to git, post to platforms
    "email_auto_reply": {"task_type": "judgment", "authority": "elevated", "max_cost": 100},
    "email_to_task": {"task_type": "simple", "authority": "elevated", "max_cost": 10},

    # Complex: architecture, security, novel reasoning
    "code_review_runner": {"task_type": "complex", "authority": "elevated", "max_cost": 300},

    # Knowledge: memory and brain operations
    "knowledge_graph_builder": {"task_type": "judgment", "authority": "standard", "max_cost": 100},
    "memory_consolidation": {"task_type": "judgment", "authority": "standard", "max_cost": 100},
    "memory_md_sync": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "learning_extractor": {"task_type": "judgment", "authority": "standard", "max_cost": 100},
    "auto_experiment": {"task_type": "complex", "authority": "elevated", "max_cost": 500},

    # Research & monitoring: read-heavy, low authority
    "arxiv_tracker": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "daily_research": {"task_type": "judgment", "authority": "read_only", "max_cost": 50},
    "rss_digest": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "newsletter_digest": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "github_digest": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "security_advisories": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "price_watcher": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "weather_briefing": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "uptime_monitor": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "seo_monitor": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "social_listener": {"task_type": "simple", "authority": "read_only", "max_cost": 10},

    # Productivity: standard authority
    "daily_planner": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "calendar_manager": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "habit_tracker": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "expense_tracker": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "meeting_notes": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "bookmark_organizer": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "document_parser": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "contact_enricher": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "file_declutter": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "weekly_report": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "report_generator": {"task_type": "judgment", "authority": "standard", "max_cost": 50},

    # Content: standard to elevated
    "content_calendar": {"task_type": "judgment", "authority": "standard", "max_cost": 50},

    # Email & comms: elevated (can send)
    "email_triage": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "morning_check_email_summarize": {"task_type": "simple", "authority": "standard", "max_cost": 10},

    # Job search: elevated (can apply/respond)
    "job_search_apply": {"task_type": "judgment", "authority": "elevated", "max_cost": 100},
    "job_response_checker": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "job_tracker_db": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "interview_prep": {"task_type": "judgment", "authority": "standard", "max_cost": 50},

    # Code & dev: elevated (can write files, run commands)
    "dependency_auditor": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "git_monitor": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "friday_check_github_new": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "cli_anything_bridge": {"task_type": "judgment", "authority": "elevated", "max_cost": 100},

    # Risk & analysis: elevated
    "risk_analyst": {"task_type": "complex", "authority": "elevated", "max_cost": 200},

    # intel_agent V2 persona self-improvement experiment (Phase B / Phase C)
    # Both workflows are LLM-authored-content + deterministic-glue shape.
    # Audit files a one-page spec; rewrite files a full V2 persona body.
    # Gated by structural header validation inside each workflow.
    "intel_agent_v2_audit_persona": {"task_type": "judgment", "authority": "standard", "max_cost": 100},
    "intel_agent_v2_rewrite_persona": {"task_type": "judgment", "authority": "standard", "max_cost": 200},

    # Content freshness: regenerates decker_system/00_meta/aibrain_live_truth_v1_4_0.md
    # from live source counts. Pure deterministic file I/O + pytest collect count.
    "update_aibrain_live_truth": {"task_type": "deterministic", "authority": "standard", "max_cost": 10},
}


def get_user_facing_workflows() -> dict:
    """Return WORKFLOW_REGISTRY entries excluding internal-only workflows."""
    return {k: v for k, v in WORKFLOW_REGISTRY.items() if not v.get("internal")}


def clarify_workflow(name: str) -> dict:
    """
    Return what a workflow requires before it can run: env vars, config keys,
    authority level, task type, and a short description from the run function.

    Useful for pre-flight checks before scheduling or automating a workflow.

    Returns:
        {
          "workflow": name,
          "task_type": "deterministic"|"simple"|"judgment"|"complex",
          "authority": "read_only"|"standard"|"elevated"|"admin",
          "max_cost_cents": int,
          "description": str,          # from module/run-fn docstring
          "env_vars": [str],            # detected os.getenv/os.environ calls
          "config_keys": [str],         # detected config.get() calls
          "requires_approval": [str],   # from registry
          "run_fn": str,                # which function will be called
        }
    """
    import re
    import inspect

    meta = WORKFLOW_REGISTRY.get(name, {
        "task_type": "judgment", "authority": "standard", "max_cost": 100,
    })

    workflow_path = WORKFLOW_DIR / f"{name}.py"
    if not workflow_path.exists():
        return {"error": f"Workflow '{name}' not found"}

    source = workflow_path.read_text(encoding="utf-8", errors="ignore")

    # Extract env var names from os.getenv / os.environ.get patterns
    env_vars = sorted(set(
        re.findall(r'os\.(?:getenv|environ\.get)\(["\']([A-Z_][A-Z0-9_]*)["\']', source)
    ))

    # Extract config.get keys
    config_keys = sorted(set(
        re.findall(r'config\.get\(["\']([a-z_][a-z0-9_]*)["\']', source)
    ))

    # Get module/run function docstring
    description = ""
    mod_doc_match = re.search(r'^"""(.*?)"""', source, re.DOTALL | re.MULTILINE)
    if mod_doc_match:
        description = mod_doc_match.group(1).strip().split("\n")[0]

    # Find which run function would be called
    run_fn_name = "run"
    for candidate in [f"run_{name}", "main", "run_pipeline", "run_scan",
                      "run_backup", "run_auto_loop", "run_full_cycle",
                      "check", "execute", "process", "start"]:
        if re.search(rf"^def {candidate}\b", source, re.MULTILINE):
            if candidate != "run" and not re.search(r"^def run\b", source, re.MULTILINE):
                run_fn_name = candidate
                break
    if re.search(r"^def run\b", source, re.MULTILINE):
        run_fn_name = "run"

    return {
        "workflow": name,
        "task_type": meta.get("task_type", "judgment"),
        "authority": meta.get("authority", "standard"),
        "max_cost_cents": meta.get("max_cost", 100),
        "description": description,
        "env_vars": env_vars,
        "config_keys": config_keys,
        "requires_approval": meta.get("requires_approval", []),
        "run_fn": run_fn_name,
    }


def plan_workflow(name: str) -> dict:
    """
    Return a structured execution plan for a workflow: what it will do,
    what model it will use, estimated cost, and what side effects it has.

    Useful for reviewing automation before enabling it.
    """
    clarification = clarify_workflow(name)
    if "error" in clarification:
        return clarification

    meta = WORKFLOW_REGISTRY.get(name, {
        "task_type": "judgment", "authority": "standard", "max_cost": 100,
    })

    # Model routing preview — reads user config if available
    task_type = clarification["task_type"]
    try:
        from aibrain.tools.model.config import load_model_config
        _mcfg = load_model_config()
        _routing = _mcfg.get('routing', {})
    except Exception:
        _routing = {}
    _cost_labels = {
        "code_only": "$0", "haiku": "~$0.001", "local": "$0",
        "sonnet": "~$0.01", "opus": "~$0.05",
    }
    model_map = {}
    for _tier, _default in [("deterministic", "code_only"), ("simple", "haiku"),
                             ("judgment", "sonnet"), ("complex", "opus")]:
        _model = _routing.get(_tier, _default)
        _cost = _cost_labels.get(_model, "~$0.01")
        model_map[_tier] = f"{_model} ({_cost})"
    model_preview = model_map.get(task_type, "sonnet (~$0.01)")

    # Side effects from authority level
    side_effects = {
        "read_only": ["read files", "read DB", "read APIs"],
        "standard": ["read files", "write DB", "write local files"],
        "elevated": ["read files", "write DB", "send emails", "post to platforms", "run commands"],
        "admin": ["all elevated actions", "modify system config", "manage users"],
    }

    return {
        "workflow": name,
        "plan": [
            f"1. Classify task as '{task_type}'",
            f"2. Check authority ('{clarification['authority']}') against permissions DB",
            f"3. Check budget (max ${clarification['max_cost_cents'] / 100:.2f})",
            f"4. Route to model: {model_preview}",
            f"5. Execute {clarification['run_fn']}()",
            "6. Evaluate quality (0.0–1.0)",
            "7. Write audit trail entry",
            "8. Store learning in evolution_outcomes",
        ],
        "model": model_preview,
        "side_effects": side_effects.get(clarification["authority"], []),
        "requires_approval": clarification["requires_approval"],
        "env_vars_needed": clarification["env_vars"],
        "description": clarification["description"],
    }


def run_workflow(
    name: str,
    dry_run: bool = False,
    actor: str = "system",
    authority: Optional[str] = None,
    until_green: bool = False,
    max_retries: int = 5,
    mode: str = "execute",
    event_payload: Optional[dict] = None,
    v3_task_type: Optional[str] = None,
    **kwargs
) -> HarnessResult:
    """
    Run a workflow through the execution harness.

    The harness handles: classification, budget, authority, execution,
    evaluation, audit trail, learning, and retry.

    Args:
        mode:         "execute" (default), "plan" (preview only), or
                      "clarify" (show requirements without executing).
        until_green:  If True, keep retrying until quality_score >= 0.7 or
                      max_retries is reached (inspired by the ralph pattern).
        max_retries:  Maximum retry attempts when until_green=True (default 5).
        v3_task_type: Optional SelRoute v3 task category (e.g. "code_review",
                      "security_review", "polish_refine"). When set, the
                      workflow is routed via aibrain.core.agent_router.route()
                      BEFORE the harness action runs. If the routing decision
                      is `superworker`, the workflow's normal run() function
                      is replaced by a call to aibrain.core.superworker.invoke()
                      that channels the routed lens roster. After execution,
                      agent_router.record_outcome() writes the quality_score
                      back to routing_outcomes for the SelRoute feedback loop.
                      When None (default), routing is skipped — pure backwards
                      compatible behaviour.
    """
    # Short-circuit for plan/clarify modes — no harness needed
    if mode == "clarify":
        info = clarify_workflow(name)
        return HarnessResult(
            success="error" not in info,
            output=info,
            error=info.get("error"),
        )

    if mode == "plan":
        plan = plan_workflow(name)
        return HarnessResult(
            success="error" not in plan,
            output=plan,
            error=plan.get("error"),
        )
    # Look up workflow metadata
    meta = WORKFLOW_REGISTRY.get(name, {
        "task_type": "judgment",  # default to judgment (safe)
        "authority": "standard",
        "max_cost": 100,
    })

    # Override authority if explicitly provided
    if authority:
        meta["authority"] = authority

    # Find the workflow module
    workflow_path = WORKFLOW_DIR / f"{name}.py"
    if not workflow_path.exists():
        return HarnessResult(
            success=False,
            error=f"Workflow '{name}' not found at {workflow_path}",
        )

    # Import and find the run function
    def _execute_workflow():
        """Load and run the workflow."""
        # Add workflow dir to path if needed
        wf_dir = str(WORKFLOW_DIR)
        if wf_dir not in sys.path:
            sys.path.insert(0, wf_dir)

        # Also add parent for imports
        parent_dir = str(WORKFLOW_DIR.parent)
        if parent_dir not in sys.path:
            sys.path.insert(0, parent_dir)

        # Clear sys.argv to prevent workflow's argparse from firing on import
        original_argv = sys.argv[:]
        sys.argv = [name]
        try:
            # Force reimport if already cached
            if name in sys.modules:
                del sys.modules[name]
            mod = importlib.import_module(name)
        except SystemExit:
            # Some modules call argparse at import level — catch the exit
            raise RuntimeError(f"Workflow '{name}' has module-level argparse that conflicts. Use direct import.")
        except ImportError as e:
            raise RuntimeError(f"Cannot import workflow '{name}': {e}")
        finally:
            sys.argv = original_argv

        # Find the run function — try multiple common entry point names
        run_fn = getattr(mod, "run", None)
        if run_fn is None:
            for fn_name in [f"run_{name}", "main", "run_pipeline", "run_scan",
                           "run_backup", "run_auto_loop", "run_full_cycle",
                           "check", "execute", "process", "start",
                           f"{name}_run", f"do_{name}"]:
                run_fn = getattr(mod, fn_name, None)
                if run_fn and callable(run_fn):
                    break

        if run_fn is None:
            raise RuntimeError(f"Workflow '{name}' has no run() function")

        # Execute — handle different function signatures gracefully
        import inspect
        sig = inspect.signature(run_fn)
        params = sig.parameters

        call_kwargs = dict(kwargs)
        if dry_run and "dry_run" in params:
            call_kwargs["dry_run"] = True
        if event_payload is not None and "event_payload" in params:
            call_kwargs["event_payload"] = event_payload

        # Only pass kwargs the function actually accepts
        if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()):
            return run_fn(**call_kwargs)  # accepts **kwargs
        else:
            filtered = {k: v for k, v in call_kwargs.items() if k in params}
            return run_fn(**filtered)

    # ─── SelRoute v3 routing (optional, opt-in via v3_task_type) ─────────
    # When v3_task_type is set, route the workflow through agent_router BEFORE
    # the harness action runs. If the decision is "superworker" we replace the
    # workflow's normal run() with a call to superworker.invoke() that channels
    # the routed lens roster. record_outcome() is called after execute() so
    # SelRoute can learn from the quality_score the harness measures.
    route_decision = None
    if v3_task_type:
        try:
            from aibrain.core.agent_router import route as v3_route
            route_decision = v3_route(
                task_type=v3_task_type,
                task_description=name,
                actor=actor,
            )
            log.info(
                "Workflow '%s' routed via SelRoute v3: shape=%s model=%s reason=%s",
                name,
                route_decision.handler_shape,
                route_decision.model_recommendation,
                route_decision.routing_reason,
            )
        except Exception as e:
            log.warning(
                "v3 routing failed for '%s': %s — falling back to direct execution",
                name, e,
            )
            route_decision = None

    # If routed to SuperWorker, swap the workflow's action for an invoke() call.
    # The harness still runs the action through eval/audit/verify-and-followup;
    # only the action body changes.
    if route_decision and route_decision.handler_shape == "superworker":
        try:
            from aibrain.core.superworker import invoke as sw_invoke
            sw_task_type = v3_task_type
            sw_task = f"workflow.{name}"

            def _execute_via_superworker():
                sw_result = sw_invoke(task=sw_task, task_type=sw_task_type)
                # to_harness_dict returns the contract harness.py:318 reads
                # for self-reported _cost_cents + _model_used.
                return sw_result.to_harness_dict()

            log.info(
                "Workflow '%s' will execute via SuperWorker (lenses=%d)",
                name, len(route_decision.lens_set or []),
            )
            _execute_workflow = _execute_via_superworker
        except Exception as e:
            log.warning(
                "SuperWorker dispatch failed for '%s': %s — falling back to direct execution",
                name, e,
            )

    # Configure harness
    config = HarnessConfig(
        task_type=meta["task_type"],
        authority=meta["authority"],
        max_cost_cents=meta["max_cost"],
        timeout_seconds=300,
        quality_threshold=0.3,  # workflows have lower threshold — they're established
        max_retries=0,  # don't retry workflows automatically
        actor=actor,
        tags=[name, "workflow"],
    )

    log.info("Running workflow '%s' through harness [type=%s, auth=%s]",
             name, meta["task_type"], meta["authority"])

    GREEN_THRESHOLD = 0.7
    attempts = 1 if not until_green else max(1, max_retries)

    result = None
    for attempt in range(1, attempts + 1):
        if until_green and attempt > 1:
            log.info("Workflow '%s' retry %d/%d (previous quality=%.2f)",
                     name, attempt, attempts, result.quality if result else 0.0)

        result = execute(
            task=f"workflow.{name}",
            action=_execute_workflow,
            config=config,
        )

        if result.success:
            log.info("Workflow '%s' completed: quality=%.2f, duration=%dms",
                     name, result.quality, result.duration_ms)
        else:
            log.warning("Workflow '%s' failed: %s", name, result.error)

        if not until_green:
            break

        is_green = result.quality >= GREEN_THRESHOLD and result.success and not result.error
        if is_green:
            log.info("Workflow '%s' is green after %d attempt(s) (quality=%.2f)",
                     name, attempt, result.quality)
            break

        if attempt < attempts:
            log.info("Workflow '%s' not green yet (quality=%.2f, error=%s) — retrying...",
                     name, result.quality, result.error or "none")
    else:
        if until_green:
            log.warning("Workflow '%s' did not reach green after %d attempt(s) (final quality=%.2f)",
                        name, attempts, result.quality if result else 0.0)

    # Record SelRoute v3 outcome for the routing feedback loop.
    # Honest-rubric: record_outcome drops None-quality runs so unmeasured
    # outcomes don't pollute the learned routing preferences.
    if route_decision is not None and result is not None:
        try:
            from aibrain.core.agent_router import record_outcome as v3_record
            v3_record(
                task_type=v3_task_type,
                handler_shape=route_decision.handler_shape,
                quality_score=result.quality,  # may be None — record_outcome filters
                override_mode=route_decision.override_mode,
                duration_ms=result.duration_ms,
                actor=actor,
            )
        except Exception as e:
            log.warning("record_outcome failed for '%s': %s", name, e)

    # Log prediction accuracy (non-blocking, best-effort)
    try:
        from aibrain.core.state_predictor import predict_next, log_prediction_accuracy
        predictions = predict_next(n=3)
        if predictions:
            log_prediction_accuracy(predictions, name)
    except Exception:
        pass  # prediction logging is advisory, never breaks workflows

    # Emit WORKFLOW_EXECUTED event
    try:
        from aibrain.core.event_bus import emit as bus_emit, EventTypes
        bus_emit(EventTypes.WORKFLOW_EXECUTED, {
            "workflow": name,
            "success": result.success if result else False,
            "quality": result.quality if result else 0.0,
            "duration_ms": result.duration_ms if result else 0,
            "error": str(result.error) if result and result.error else None,
            "actor": actor,
        })
    except Exception:
        pass  # Event emission never blocks workflow execution

    return result


# ---------------------------------------------------------------------------
# Event-triggered workflow execution
# ---------------------------------------------------------------------------

# Maps event_type → list of (workflow_name, actor) to run when event fires
_event_triggers: dict[str, list[tuple[str, str]]] = {}
_triggers_registered: bool = False


def trigger_on_event(
    workflow_name: str,
    event_type: str,
    actor: str = "event_trigger",
) -> None:
    """Register a workflow to auto-run when an event fires.

    The workflow is executed through the harness (run_workflow) when
    the event bus emits the specified event type. The event payload
    is passed as a kwarg to the workflow if it accepts one.

    Args:
        workflow_name: Name of a workflow in WORKFLOW_REGISTRY.
        event_type: Event type string to listen for.
        actor: Actor label for audit trail (default: "event_trigger").

    Raises:
        ValueError: If workflow_name is not in WORKFLOW_REGISTRY.
    """
    if workflow_name not in WORKFLOW_REGISTRY:
        wf_path = WORKFLOW_DIR / f"{workflow_name}.py"
        if not wf_path.exists():
            raise ValueError(
                f"Unknown workflow: {workflow_name!r} — not in WORKFLOW_REGISTRY and "
                f"{wf_path} does not exist"
            )

    if event_type not in _event_triggers:
        _event_triggers[event_type] = []

    # Avoid duplicate registrations
    entry = (workflow_name, actor)
    if entry not in _event_triggers[event_type]:
        _event_triggers[event_type].append(entry)

        # Register a handler on the event bus for this event type
        _ensure_event_handler(event_type)

        log.info("Workflow '%s' will trigger on event '%s' (actor=%s)",
                 workflow_name, event_type, actor)


def untrigger_on_event(workflow_name: str, event_type: str) -> bool:
    """Remove an event trigger for a workflow.

    Returns True if a trigger was removed, False if not found.
    """
    entries = _event_triggers.get(event_type, [])
    original_len = len(entries)
    _event_triggers[event_type] = [
        (wf, act) for wf, act in entries if wf != workflow_name
    ]
    removed = len(_event_triggers[event_type]) < original_len
    # Clean up empty lists
    if not _event_triggers[event_type]:
        del _event_triggers[event_type]
    return removed


def get_event_triggers() -> dict[str, list[str]]:
    """Return a dict of event_type → list of workflow names."""
    return {
        event_type: [wf for wf, _actor in entries]
        for event_type, entries in _event_triggers.items()
    }


def clear_event_triggers() -> None:
    """Remove all event triggers. For testing."""
    _event_triggers.clear()


# Track which event types already have a bus handler to avoid double-registration
_registered_event_types: set[str] = set()


def _ensure_event_handler(event_type: str) -> None:
    """Register a single handler on the event bus for the given event type.

    The handler dispatches to all workflows registered for that event type.
    Only registers once per event type.
    """
    if event_type in _registered_event_types:
        return

    from aibrain.core.event_bus import on as bus_on

    def _dispatch(payload: dict, _et: str = event_type) -> None:
        """Dispatch event to all registered workflows for this event type."""
        entries = _event_triggers.get(_et, [])
        for workflow_name, actor in entries:
            try:
                log.info("Event '%s' triggering workflow '%s'", _et, workflow_name)
                run_workflow(
                    workflow_name,
                    actor=actor,
                    event_payload=payload,
                )
            except Exception as e:
                log.warning(
                    "Event-triggered workflow '%s' failed for event '%s': %s",
                    workflow_name, _et, e,
                )

    bus_on(event_type, _dispatch)
    _registered_event_types.add(event_type)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Run workflow through harness")
    parser.add_argument("workflow", help="Workflow name (e.g. heartbeat, db_backup)")
    parser.add_argument("--dry-run", action="store_true", help="Preview mode")
    parser.add_argument("--actor", default="cli", help="Who initiated this")
    parser.add_argument("--authority", help="Override authority level")
    parser.add_argument("--until-green", action="store_true",
                        help="Retry until quality >= 0.7 or max-retries reached")
    parser.add_argument("--max-retries", type=int, default=5,
                        help="Max retry attempts when --until-green is set (default 5)")
    parser.add_argument("--mode", default="execute",
                        choices=["execute", "plan", "clarify"],
                        help="execute (default), plan (preview), or clarify (show requirements)")
    parser.add_argument("--v3-task-type", default=None, dest="v3_task_type",
                        help="SelRoute v3 task category (e.g. code_review, security_review, polish_refine). "
                             "When set, the workflow is routed via agent_router and may dispatch to SuperWorker.")

    args = parser.parse_args()

    # Clear sys.argv BEFORE running workflow (prevents imported modules' argparse from firing)
    sys.argv = [sys.argv[0]]

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    # plan/clarify modes print structured output without running harness
    if args.mode in ("plan", "clarify"):
        import json as _json
        fn = plan_workflow if args.mode == "plan" else clarify_workflow
        data = fn(args.workflow)
        print(_json.dumps(data, indent=2))
        sys.exit(0 if "error" not in data else 1)

    result = run_workflow(
        args.workflow,
        dry_run=args.dry_run,
        actor=args.actor,
        authority=args.authority,
        until_green=args.until_green,
        max_retries=args.max_retries,
        mode=args.mode,
        v3_task_type=args.v3_task_type,
    )

    # Honest-rubric: quality / model_used / duration_ms can legitimately be None
    # ("could not measure"). Handle each gracefully — never format None with :.2f.
    quality_str = f"{result.quality:.2f}" if result.quality is not None else "(unmeasurable)"
    model_str = result.model_used if result.model_used is not None else "(unknown)"
    duration_str = f"{result.duration_ms}ms" if result.duration_ms is not None else "(not recorded)"

    print(f"\n{'='*50}")
    print(f"Workflow: {args.workflow}")
    print(f"Success:  {result.success}")
    print(f"Quality:  {quality_str}")
    print(f"Model:    {model_str}")
    print(f"Duration: {duration_str}")
    print(f"Audit ID: {result.audit_id}")
    if result.error:
        print(f"Error:    {result.error}")
    print(f"{'='*50}")
