"""test_wheel_has_no_persona_leaks.py — v1.4 lens-split wheel gate.

Builds the project wheel via ``python -m build`` and scans every file in
the resulting archive for any of the 41 Shadow Board named personas.

Why this exists:
    Source-tree grep is not enough. The wheel can pick up data-files,
    package-data, or directories the source grep missed. The only way to
    make a leak-free-wheel claim honest is to BUILD the wheel and scan
    what actually ships.

Canonical wordlist lives in ``tests/test_lens_router.py`` under
``SHADOW_BOARD_NAMES`` — that file is the single source of truth, so this
test picks up list changes automatically.

If this test fails, DO NOT loosen the assertion. The whole point is to
catch what the source grep missed — either fix the pyproject.toml
includes/excludes, move the offending file out of the aibrain package
tree, or delete-and-archive the content and re-run.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest


PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _load_shadow_board_names() -> list[str]:
    """Read SHADOW_BOARD_NAMES from tests/test_lens_router.py (canonical)."""
    src = (PROJECT_ROOT / "tests" / "test_lens_router.py").read_text(encoding="utf-8")
    match = re.search(r"SHADOW_BOARD_NAMES\s*=\s*\[(.*?)\]", src, re.DOTALL)
    assert match is not None, "SHADOW_BOARD_NAMES list not found in test_lens_router.py"
    return re.findall(r'"([^"]+)"', match.group(1))


def _build_wheel(tmp_path: Path) -> Path:
    """Invoke ``python -m build --wheel`` into a temp outdir.

    Using an isolated outdir keeps the test hermetic — it does NOT
    interfere with the project's ``dist/`` directory.
    """
    outdir = tmp_path / "dist"
    outdir.mkdir(parents=True, exist_ok=True)

    result = subprocess.run(
        [
            sys.executable, "-m", "build",
            "--wheel",
            "--outdir", str(outdir),
        ],
        cwd=str(PROJECT_ROOT),
        capture_output=True,
        text=True,
        timeout=600,
    )

    if result.returncode != 0:
        raise AssertionError(
            f"python -m build failed (rc={result.returncode}):\n"
            f"STDOUT:\n{result.stdout[-2000:]}\n"
            f"STDERR:\n{result.stderr[-2000:]}"
        )

    wheels = sorted(outdir.glob("aibrain-*.whl"))
    assert wheels, f"No wheel built under {outdir}"
    return wheels[-1]


def _scan_wheel_for_names(
    wheel_path: Path, extract_dir: Path, names: list[str]
) -> list[tuple[str, int, str, str]]:
    """Extract wheel to ``extract_dir`` and scan every file for ``names``.

    Returns a list of ``(relpath, lineno, name, snippet)`` tuples — empty
    list means the wheel is clean.
    """
    extract_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(wheel_path) as zf:
        zf.extractall(extract_dir)

    violations: list[tuple[str, int, str, str]] = []
    for root, _dirs, files in os.walk(extract_dir):
        for fn in files:
            fp = os.path.join(root, fn)
            try:
                with open(fp, "rb") as f:
                    raw = f.read()
            except OSError:
                continue
            try:
                text = raw.decode("utf-8", errors="strict")
            except UnicodeDecodeError:
                # Fall back to latin-1 so binary-ish text files still scan
                try:
                    text = raw.decode("latin-1")
                except Exception:
                    continue  # truly binary — skip

            rel = os.path.relpath(fp, extract_dir)
            for lineno, line in enumerate(text.splitlines(), start=1):
                for name in names:
                    if name in line:
                        violations.append((rel, lineno, name, line[:120]))
                        break  # one violation per line is enough

    return violations


def test_built_wheel_contains_no_shadow_board_names(tmp_path):
    """Build the wheel and assert zero Shadow Board persona leaks.

    This is the CI gate for the v1.4 lens split. If it ever fails, a
    named persona has landed in the public ship path — fix at the source
    (pyproject.toml, MANIFEST.in, or by moving the file out of the
    aibrain package tree). Do NOT suppress this test.
    """
    pytest.importorskip("build", reason="python -m build is required for wheel gate")

    names = _load_shadow_board_names()
    assert len(names) >= 40, (
        f"Canonical SHADOW_BOARD_NAMES list unexpectedly small: {len(names)}"
    )

    wheel_path = _build_wheel(tmp_path)
    extract_dir = tmp_path / "wheel_contents"

    violations = _scan_wheel_for_names(wheel_path, extract_dir, names)

    if violations:
        rendered = "\n".join(
            f"  {rel}:{lineno}: {name!r} -> {snippet}"
            for (rel, lineno, name, snippet) in violations[:30]
        )
        raise AssertionError(
            f"LEAK: built wheel {wheel_path.name} contains "
            f"{len(violations)} Shadow Board persona mention(s):\n"
            f"{rendered}\n"
            f"\nFix by excluding the offending file from the package or "
            f"moving it out of the aibrain package tree. Do NOT loosen "
            f"this assertion."
        )

    # Cleanup — tmp_path is auto-cleaned by pytest, but explicit delete
    # keeps disk footprint small during long test sessions.
    shutil.rmtree(extract_dir, ignore_errors=True)
