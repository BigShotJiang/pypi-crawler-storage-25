"""
Tests for skill file ingestion as procedural memories.
"""

import os
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.ingest_skills import (
    discover_skill_files,
    ingest_skills,
    skill_name_from_path,
)


@pytest.fixture()
def skill_tree(tmp_path):
    """Create a temporary skill file tree."""
    skills_dir = tmp_path / "skills" / "skills" / "most_used"
    skills_dir.mkdir(parents=True)
    (skills_dir / "code_review.md").write_text("# Code Review\nReview code for quality.", encoding="utf-8")
    (skills_dir / "bug_debugging.md").write_text("# Bug Debugging\nFind and fix bugs.", encoding="utf-8")

    top_skill = tmp_path / "skills" / "SKILL_TEMPLATE.md"
    top_skill.write_text("# Template\nBase template.", encoding="utf-8")

    return tmp_path


@pytest.fixture()
def db_env():
    """Create isolated DB for ingestion tests."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="aibrain_ingest_")
    os.close(fd)

    import aibrain_db
    original_path = aibrain_db.DB_PATH
    original_conn = aibrain_db._conn

    aibrain_db.DB_PATH = Path(path)
    aibrain_db._conn = None

    conn = aibrain_db.get_db()

    yield conn, aibrain_db

    try:
        conn.close()
    except Exception:
        pass
    aibrain_db._conn = original_conn
    aibrain_db.DB_PATH = original_path

    try:
        os.unlink(path)
    except OSError:
        pass
    for ext in ("-wal", "-shm"):
        try:
            os.unlink(path + ext)
        except OSError:
            pass


class TestDiscoverSkillFiles:
    """Tests for skill file discovery."""

    def test_finds_skill_files(self, skill_tree):
        """Discovers .md files in the skills directory."""
        files = discover_skill_files(skill_tree)
        names = [f.name for f in files]
        assert "code_review.md" in names
        assert "bug_debugging.md" in names
        assert "SKILL_TEMPLATE.md" in names

    def test_returns_paths(self, skill_tree):
        """All returned items are Path objects pointing to existing files."""
        files = discover_skill_files(skill_tree)
        assert len(files) >= 3
        for f in files:
            assert isinstance(f, Path)
            assert f.exists()


class TestSkillNameFromPath:
    """Tests for skill name derivation."""

    def test_normal_md_file(self):
        """Regular .md files use stem."""
        p = Path("skills/most_used/code_review.md")
        assert skill_name_from_path(p) == "skill:code_review"

    def test_skill_md_uses_parent(self):
        """SKILL.md files use parent directory name."""
        p = Path("boss/SKILL.md")
        assert skill_name_from_path(p) == "skill:boss"

    def test_template_file(self):
        """Template files use their stem."""
        p = Path("skills/SKILL_TEMPLATE.md")
        assert skill_name_from_path(p) == "skill:SKILL_TEMPLATE"


class TestIngestSkills:
    """Tests for the full ingestion pipeline."""

    def test_ingests_new_skills(self, skill_tree, db_env):
        """New skills are ingested as procedural memories."""
        conn, _ = db_env
        result = ingest_skills(skill_tree)
        assert result["ingested"] >= 3
        assert result["errors"] == 0

        # Verify memories were created
        rows = conn.execute(
            "SELECT * FROM memories WHERE type='skill'"
        ).fetchall()
        assert len(rows) >= 3
        for r in rows:
            assert dict(r)["memory_class"] == "procedural"
            assert float(dict(r)["importance"]) == 0.7

    def test_idempotent_skip_existing(self, skill_tree, db_env):
        """Running twice skips already-ingested skills."""
        _, _ = db_env
        result1 = ingest_skills(skill_tree)
        result2 = ingest_skills(skill_tree)
        assert result2["skipped"] == result1["ingested"]
        assert result2["ingested"] == 0

    def test_dry_run_creates_nothing(self, skill_tree, db_env):
        """Dry run counts but doesn't create memories."""
        conn, _ = db_env
        result = ingest_skills(skill_tree, dry_run=True)
        assert result["ingested"] >= 3
        # But nothing actually in DB
        rows = conn.execute(
            "SELECT COUNT(*) FROM memories WHERE type='skill'"
        ).fetchone()
        assert rows[0] == 0

    def test_tags_include_category(self, skill_tree, db_env):
        """Skills in category dirs get category tags."""
        conn, _ = db_env
        ingest_skills(skill_tree)
        row = conn.execute(
            "SELECT tags FROM memories WHERE name='skill:code_review'"
        ).fetchone()
        assert row is not None
        assert "most_used" in row["tags"]
