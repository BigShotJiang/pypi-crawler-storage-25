"""
Tests for the AIBrain master settings menu.

Covers:
  - get_compression_status() — reads compress.toml correctly
  - render_master_menu() — correct structure
  - Stub sub-menus show "coming soon" message
  - _getch is imported from the shared aibrain.cli.utils module
"""
from __future__ import annotations

import sys
import io
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

# Ensure project root is importable
AIBRAIN_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(AIBRAIN_ROOT))


# ---------------------------------------------------------------------------
# test_master_menu_compression_status
# ---------------------------------------------------------------------------

class TestCompressionStatus:
    def test_all_enabled_by_default(self, tmp_path, monkeypatch):
        """When compress.toml has no entries, all 8 categories default to enabled."""
        from aibrain.tools.compress import config as cfg_mod

        # Point config path to an empty temp dir (no file exists)
        monkeypatch.setattr(cfg_mod, '_CONFIG_PATH', tmp_path / 'compress.toml')
        monkeypatch.setattr(cfg_mod, '_config_cache', None)

        from aibrain.cli.settings_menu import get_compression_status
        result = get_compression_status()
        assert result == '8/8 enabled'

    def test_six_enabled(self, tmp_path, monkeypatch):
        """When 6 of 8 categories are enabled in compress.toml, returns '6/8 enabled'."""
        from aibrain.tools.compress import config as cfg_mod

        toml_path = tmp_path / 'compress.toml'
        toml_path.write_text(
            '[compress]\nenabled = true\n'
            '[compress.git]\nenabled = true\n'
            '[compress.test]\nenabled = true\n'
            '[compress.build]\nenabled = true\n'
            '[compress.docker]\nenabled = true\n'
            '[compress.pip]\nenabled = true\n'
            '[compress.env]\nenabled = true\n'
            '[compress.json]\nenabled = false\n'
            '[compress.traceback]\nenabled = false\n',
            encoding='utf-8',
        )
        monkeypatch.setattr(cfg_mod, '_CONFIG_PATH', toml_path)
        monkeypatch.setattr(cfg_mod, '_config_cache', None)

        from aibrain.cli.settings_menu import get_compression_status
        result = get_compression_status()
        assert result == '6/8 enabled'

    def test_master_switch_off_returns_zero(self, tmp_path, monkeypatch):
        """When master switch is false, all categories report disabled."""
        from aibrain.tools.compress import config as cfg_mod

        toml_path = tmp_path / 'compress.toml'
        toml_path.write_text('[compress]\nenabled = false\n', encoding='utf-8')
        monkeypatch.setattr(cfg_mod, '_CONFIG_PATH', toml_path)
        monkeypatch.setattr(cfg_mod, '_config_cache', None)

        from aibrain.cli.settings_menu import get_compression_status
        result = get_compression_status()
        assert result == '0/8 enabled'

    def test_returns_string_format(self, tmp_path, monkeypatch):
        """Status string always has the N/8 format."""
        from aibrain.tools.compress import config as cfg_mod
        monkeypatch.setattr(cfg_mod, '_CONFIG_PATH', tmp_path / 'compress.toml')
        monkeypatch.setattr(cfg_mod, '_config_cache', None)

        from aibrain.cli.settings_menu import get_compression_status
        result = get_compression_status()
        assert '/' in result
        assert 'enabled' in result


# ---------------------------------------------------------------------------
# test_master_menu_stub_display
# ---------------------------------------------------------------------------

class TestStubDisplay:
    def _run_stub(self, title: str) -> str:
        """Run _stub_menu with mocked _getch and capture stdout."""
        from aibrain.cli import settings_menu

        buf = io.StringIO()
        with patch.object(settings_menu, '_getch', return_value=' '):
            with patch('sys.stdout', buf):
                settings_menu._stub_menu(title)
        return buf.getvalue()

    def test_learning_stub_shows_coming_soon(self):
        output = self._run_stub('Learning config')
        assert 'coming soon' in output
        assert 'Learning config' in output

    def test_stub_shows_any_key_message(self):
        output = self._run_stub('Model routing config')
        assert 'Press any key to return' in output

    def test_stub_shows_not_available(self):
        output = self._run_stub('Workflows config')
        assert 'not yet available' in output

    def test_render_master_menu_structure(self):
        """render_master_menu should contain all 7 items and status summaries."""
        from aibrain.cli.settings_menu import render_master_menu, _MENU_ITEMS

        text = render_master_menu(_MENU_ITEMS, 0)

        # Check all labels present
        assert 'Compression' in text
        assert 'Learning' in text
        assert 'Model routing' in text
        assert 'Workflows' in text
        assert 'Evolution' in text
        assert 'Agents' in text
        assert 'Schedule' in text

        # Check selected item has > cursor
        lines = text.splitlines()
        first_item_line = next(l for l in lines if 'Compression' in l)
        assert '>' in first_item_line

        # Check footer hint
        assert 'Q to quit' in text

    def test_render_master_menu_selection_highlight(self):
        """Selected index should show > on the correct row."""
        from aibrain.cli.settings_menu import render_master_menu, _MENU_ITEMS

        # Select item 3 (0-indexed) = Workflows
        text = render_master_menu(_MENU_ITEMS, 3)
        lines = text.splitlines()
        workflows_line = next(l for l in lines if 'Workflows' in l)
        assert '>' in workflows_line
        # Compression line should NOT have >
        comp_line = next(l for l in lines if 'Compression' in l)
        assert '>' not in comp_line


# ---------------------------------------------------------------------------
# test_getch_shared_import
# ---------------------------------------------------------------------------

class TestGetchSharedImport:
    def test_settings_menu_imports_getch_from_utils(self):
        """settings_menu._getch must be the same object as cli.utils._getch."""
        import aibrain.cli.settings_menu as sm
        import aibrain.cli.utils as utils
        assert sm._getch is utils._getch

    def test_compress_config_delegates_to_shared_getch(self):
        """config._getch() should delegate to aibrain.cli.utils._getch."""
        from aibrain.tools.compress.config import _getch as config_getch
        from aibrain.cli.utils import _getch as utils_getch

        # They aren't the same object (config wraps it), but calling config_getch
        # should invoke utils_getch. Verify by patching utils._getch.
        calls = []
        import aibrain.cli.utils as utils_mod

        original = utils_mod._getch

        def fake_getch():
            calls.append(1)
            return 'x'

        utils_mod._getch = fake_getch
        try:
            result = config_getch()
            assert result == 'x'
            assert len(calls) == 1
        finally:
            utils_mod._getch = original

    def test_utils_getch_is_callable(self):
        """_getch in utils must be callable (basic sanity)."""
        from aibrain.cli.utils import _getch
        assert callable(_getch)
