"""
Tests for credential env-var override in config_get().

Verifies: env vars take precedence for sensitive keys, fallback to DB
for missing env vars, and sensitive fields are scrubbed from config export.
"""

import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture()
def db_env():
    """Create a fresh, isolated SQLite DB with the full AIBrain schema."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="aibrain_cfgtest_")
    os.close(fd)

    import aibrain_db
    original_path = aibrain_db.DB_PATH
    original_conn = aibrain_db._conn

    aibrain_db.DB_PATH = Path(path)
    aibrain_db._conn = None

    conn = aibrain_db.get_db()

    yield conn, aibrain_db

    try:
        conn.close()
    except Exception:
        pass
    aibrain_db._conn = original_conn
    aibrain_db.DB_PATH = original_path

    try:
        os.unlink(path)
    except OSError:
        pass
    for ext in ("-wal", "-shm"):
        try:
            os.unlink(path + ext)
        except OSError:
            pass


class TestEnvVarOverride:
    """config_get() prefers env vars for sensitive keys."""

    def test_env_var_overrides_db_value(self, db_env):
        """When GITHUB_PAT is set, config_get('github_token') returns it."""
        conn, mod = db_env
        # Seed a DB value
        conn.execute(
            "INSERT OR REPLACE INTO config (key, value, updated) VALUES (?, ?, datetime('now'))",
            ("github_token", "db_value_fake_token")
        )
        conn.commit()

        with patch.dict(os.environ, {"GITHUB_PAT": "env_pat_override"}):
            result = mod.config_get("github_token")
        assert result == "env_pat_override"

    def test_fallback_to_db_when_env_missing(self, db_env):
        """When no env var is set, config_get falls back to DB."""
        conn, mod = db_env
        conn.execute(
            "INSERT OR REPLACE INTO config (key, value, updated) VALUES (?, ?, datetime('now'))",
            ("github_token", "db_fallback_token")
        )
        conn.commit()

        # Ensure env vars are not set
        env = {k: v for k, v in os.environ.items()
               if k not in ("GITHUB_PAT", "GITHUB_TOKEN")}
        with patch.dict(os.environ, env, clear=True):
            result = mod.config_get("github_token")
        assert result == "db_fallback_token"

    def test_non_sensitive_key_ignores_env(self, db_env):
        """Non-sensitive keys never read from env, even if a matching var exists."""
        conn, mod = db_env
        conn.execute(
            "INSERT OR REPLACE INTO config (key, value, updated) VALUES (?, ?, datetime('now'))",
            ("timezone", "Australia/Adelaide")
        )
        conn.commit()

        with patch.dict(os.environ, {"TIMEZONE": "UTC"}):
            result = mod.config_get("timezone")
        assert result == "Australia/Adelaide"

    def test_second_env_var_fallback(self, db_env):
        """When first env var is missing but second exists, uses second."""
        conn, mod = db_env
        env = {k: v for k, v in os.environ.items() if k != "GITHUB_PAT"}
        env["GITHUB_TOKEN"] = "second_var_value"
        with patch.dict(os.environ, env, clear=True):
            result = mod.config_get("github_token", default="nope")
        assert result == "second_var_value"


class TestConfigSyncScrubbing:
    """config_sync_to_file() scrubs sensitive values from the JSON file."""

    def test_sensitive_fields_scrubbed_on_sync(self, db_env, tmp_path):
        """After sync, sensitive keys in config.json contain SET_VIA_ENV markers."""
        conn, mod = db_env

        # Seed DB with a sensitive value
        conn.execute(
            "INSERT OR REPLACE INTO config (key, value, updated) VALUES (?, ?, datetime('now'))",
            ("github_token", "should_not_appear_in_file")
        )
        conn.execute(
            "INSERT OR REPLACE INTO config (key, value, updated) VALUES (?, ?, datetime('now'))",
            ("timezone", "Australia/Adelaide")
        )
        conn.commit()

        # Point AIBRAIN_ROOT at tmp_path so sync writes there
        cfg_path = tmp_path / "config.json"
        cfg_path.write_text(json.dumps({
            "github_token": "old_plaintext_token",
            "timezone": "Australia/Adelaide"
        }))

        original_root = mod.AIBRAIN_ROOT
        mod.AIBRAIN_ROOT = tmp_path
        try:
            mod.config_sync_to_file()
        finally:
            mod.AIBRAIN_ROOT = original_root

        data = json.loads(cfg_path.read_text())
        # Sensitive key must be scrubbed
        assert data["github_token"].startswith("SET_VIA_ENV")
        assert "should_not_appear_in_file" not in json.dumps(data)
        # Non-sensitive key preserved
        assert data["timezone"] == "Australia/Adelaide"


class TestSetViaEnvSkippedOnSync:
    """SET_VIA_ENV markers in config.json don't overwrite real DB values."""

    def test_marker_not_synced_to_db(self, db_env, tmp_path):
        """config.json with SET_VIA_ENV:X values should not overwrite DB."""
        conn, mod = db_env

        # Seed DB with a real value
        conn.execute(
            "INSERT OR REPLACE INTO config (key, value, updated) VALUES (?, ?, datetime('now'))",
            ("github_token", "real_encrypted_value")
        )
        conn.commit()

        # Simulate what the init sync does: read config.json with marker
        cfg_data = {"github_token": "SET_VIA_ENV:GITHUB_PAT", "timezone": "UTC"}

        for key, value in cfg_data.items():
            val_str = json.dumps(value) if isinstance(value, (dict, list)) else str(value)
            # This is the logic from init_db
            if isinstance(value, str) and value.startswith("SET_VIA_ENV"):
                continue
            existing = conn.execute("SELECT value FROM config WHERE key=?", (key,)).fetchone()
            if existing is None:
                conn.execute(
                    "INSERT INTO config (key, value, updated) VALUES (?, ?, datetime('now'))",
                    (key, val_str)
                )

        conn.commit()

        # DB value should be unchanged
        row = conn.execute("SELECT value FROM config WHERE key='github_token'").fetchone()
        assert row[0] == "real_encrypted_value"
