"""test_superworker.py — unit tests for aibrain/core/superworker.py.

These tests MOCK the Anthropic client — no real API calls are made. They
exercise: dataclass shape, JSON sidecar + markdown fallback parsers, honest-None
propagation, cost computation, lens_router integration, persona path, and the
to_harness_dict() adapter the harness reads at harness.py:318.
"""
from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock, patch

import pytest

from aibrain.core import lens_router, superworker
from aibrain.core.superworker import (
    SUPERWORKER_PERSONA_PATH,
    SuperWorkerResult,
    _coerce_float,
    _compute_cost,
    _parse_output,
    _validate,
    invoke,
)


# --- dataclass shape -------------------------------------------------------

def test_result_dataclass_has_all_spec_fields():
    r = SuperWorkerResult(
        task="t", task_type="tt", lenses_consulted=["L1"], routing_reason="r",
        per_lens=[{"name": "L1"}], synthesis="s",
        compatible_views=["v"], conflicts=["c"], overrode=["o"],
        synthesis_confidence=0.8, eval_score=0.7, raw_markdown="md",
        parse_status="ok", warnings=[], cost_cents=5, model_used="m",
        duration_ms=100, success=True, run_id="rid",
    )
    # Spec says raw_markdown is preserved alongside parsed fields
    assert r.raw_markdown == "md"
    assert r.per_lens == [{"name": "L1"}]
    assert r.eval_score == 0.7
    assert r.cost_cents == 5


def test_to_harness_dict_shape():
    """Harness reads _cost_cents + _model_used + _self_score from action dict
    (harness.py:318). The _self_score path is the divergence-reporting wire
    that lets the harness compare the LLM's self-assessment against its own
    independent eval. Honest-None: when eval_score is None on the result,
    _self_score is also None in the dict (never a fake default)."""
    r = SuperWorkerResult(
        task="t", task_type="tt", lenses_consulted=[], routing_reason="",
        per_lens=[], synthesis="", compatible_views=[], conflicts=[], overrode=[],
        synthesis_confidence=None, eval_score=0.7, raw_markdown="",
        parse_status="ok", warnings=[], cost_cents=42, model_used="claude-sonnet-4",
        duration_ms=0, success=True, run_id="x",
    )
    d = r.to_harness_dict()
    assert d["_cost_cents"] == 42
    assert d["_model_used"] == "claude-sonnet-4"
    assert d["_self_score"] == 0.7
    assert d["result"] is r


def test_to_harness_dict_propagates_none_self_score():
    """Honest-rubric: when eval_score is None AND synthesis_confidence is
    None on the SuperWorker result (parser failed, LLM output had no real
    signal), the harness dict must carry None — NEVER a fake 0.5 default."""
    r = SuperWorkerResult(
        task="t", task_type="tt", lenses_consulted=[], routing_reason="",
        per_lens=[], synthesis="", compatible_views=[], conflicts=[], overrode=[],
        synthesis_confidence=None, eval_score=None, raw_markdown="",
        parse_status="failed", warnings=[], cost_cents=None, model_used="m",
        duration_ms=0, success=False, run_id="x",
    )
    d = r.to_harness_dict()
    assert d["_self_score"] is None
    assert d["_cost_cents"] is None


def test_to_harness_dict_falls_back_to_synthesis_confidence():
    """Bidirectional null rule (Apr 11): when eval_score=None but
    synthesis_confidence is a real number, _self_score falls back to
    synthesis_confidence. The persona drift this protects against:
    legitimate measurement of synthesis_confidence but null eval_score —
    that's an asymmetry the divergence loop can't handle.

    Caught by the first SuperWorker dogfood — the persona returned
    synthesis_confidence=0.78 and eval_score=null, leaving _self_score=None
    and breaking divergence reporting on the very first scored test."""
    r = SuperWorkerResult(
        task="t", task_type="tt", lenses_consulted=[], routing_reason="",
        per_lens=[], synthesis="real synthesis", compatible_views=[],
        conflicts=[], overrode=[],
        synthesis_confidence=0.78, eval_score=None, raw_markdown="",
        parse_status="ok", warnings=[], cost_cents=0, model_used="m",
        duration_ms=0, success=True, run_id="x",
    )
    d = r.to_harness_dict()
    # eval_score on the result stays None (we don't mutate the result),
    # but the dict's _self_score falls back to synthesis_confidence
    assert d["_self_score"] == 0.78
    assert r.eval_score is None  # result object itself is unmodified


def test_to_harness_dict_eval_score_wins_when_both_present():
    """When both eval_score and synthesis_confidence are set, eval_score
    is the primary signal — it's the agent's explicit overall rating."""
    r = SuperWorkerResult(
        task="t", task_type="tt", lenses_consulted=[], routing_reason="",
        per_lens=[], synthesis="", compatible_views=[], conflicts=[], overrode=[],
        synthesis_confidence=0.78, eval_score=0.65, raw_markdown="",
        parse_status="ok", warnings=[], cost_cents=0, model_used="m",
        duration_ms=0, success=True, run_id="x",
    )
    d = r.to_harness_dict()
    # eval_score 0.65 takes priority over synthesis_confidence 0.78
    assert d["_self_score"] == 0.65


# --- JSON sidecar parser ---------------------------------------------------

def test_parse_json_sidecar_happy_path():
    text = (
        "# SuperWorker Output: foo\n\n## Per-lens findings\n\n### Linus\n...\n"
        "## Synthesis\n\n**Final recommendation:** ship it\n\n"
        '<!-- superworker_json: {"synthesis": "ship it", '
        '"compatible_views": ["a", "b"], "conflicts": [], "overrode": [], '
        '"synthesis_confidence": 0.85, "eval_score": 0.7, '
        '"per_lens": [{"name": "Linus", "finding": "ok", "confidence": 0.9}]} -->'
    )
    parsed, warnings = _parse_output(text)
    assert parsed["parse_status"] == "ok"
    assert parsed["synthesis"] == "ship it"
    assert parsed["compatible_views"] == ["a", "b"]
    assert parsed["synthesis_confidence"] == 0.85
    assert parsed["eval_score"] == 0.7
    assert len(parsed["per_lens"]) == 1
    assert warnings == []


def test_parse_json_sidecar_malformed_falls_back_to_markdown():
    text = (
        "## Synthesis\n\n**Final recommendation:** go for it\n"
        "**Synthesis confidence:** 0.6\n"
        "**Honest-rubric eval_score (self-assessed):** 0.5\n\n"
        "<!-- superworker_json: {this is not json} -->"
    )
    parsed, warnings = _parse_output(text)
    assert parsed["parse_status"] == "ok"
    assert parsed["synthesis"] == "go for it"
    assert parsed["synthesis_confidence"] == 0.6
    assert parsed["eval_score"] == 0.5
    assert any("JSON sidecar malformed" in w for w in warnings)


def test_parse_json_sidecar_null_eval_score_preserved_as_none():
    """Honest-rubric: null must become None, NOT a fake 0.5."""
    text = (
        '<!-- superworker_json: {"synthesis": "s", "compatible_views": [], '
        '"conflicts": [], "overrode": [], "synthesis_confidence": null, '
        '"eval_score": null, "per_lens": []} -->'
    )
    parsed, _ = _parse_output(text)
    assert parsed["eval_score"] is None
    assert parsed["synthesis_confidence"] is None


# --- markdown regex fallback -----------------------------------------------

def test_parse_markdown_fallback_no_sidecar():
    text = (
        "# SuperWorker Output\n\n## Per-lens findings\n\n### Linus\n...\n"
        "## Synthesis\n\n**Final recommendation:** merge\n"
        "**Synthesis confidence:** 0.9\n"
        "**Honest-rubric eval_score (self-assessed):** 0.8\n"
    )
    parsed, warnings = _parse_output(text)
    assert parsed["parse_status"] == "ok"
    assert parsed["synthesis"] == "merge"
    assert parsed["synthesis_confidence"] == 0.9
    assert parsed["eval_score"] == 0.8


def test_parse_markdown_null_eval_score_honest_none():
    text = (
        "## Synthesis\n\n**Final recommendation:** ok\n"
        "**Honest-rubric eval_score (self-assessed):** null\n"
    )
    parsed, _ = _parse_output(text)
    assert parsed["eval_score"] is None


def test_parse_missing_synthesis_section_fails_honestly():
    text = "# heading\n\nsome text but no synthesis header"
    parsed, warnings = _parse_output(text)
    assert parsed["parse_status"] == "failed"
    assert any("Synthesis" in w for w in warnings)


def test_parse_empty_output_fails_honestly():
    parsed, warnings = _parse_output("")
    assert parsed["parse_status"] == "failed"
    assert "empty LLM output" in warnings


def test_parse_partial_when_synthesis_header_but_no_final_rec():
    text = "## Synthesis\n\nsome prose but no **Final recommendation:** line"
    parsed, warnings = _parse_output(text)
    assert parsed["parse_status"] == "partial"
    assert parsed["synthesis"] == ""


# --- honest-None coercion --------------------------------------------------

def test_coerce_float_null_variants():
    assert _coerce_float(None) is None
    assert _coerce_float("null") is None
    assert _coerce_float("None") is None
    assert _coerce_float("") is None
    assert _coerce_float("not a number") is None
    assert _coerce_float(True) is None  # bool rejected (not a real measurement)


def test_coerce_float_real_values():
    assert _coerce_float(0.5) == 0.5
    assert _coerce_float("0.85") == 0.85
    assert _coerce_float(1) == 1.0


# --- cost computation ------------------------------------------------------

def test_compute_cost_from_valid_usage():
    usage = MagicMock(input_tokens=1000, output_tokens=2000)
    cost = _compute_cost(usage, "claude")
    # claude rates: 0.003/1k input, 0.015/1k output → 0.003 + 0.030 = 0.033 USD = 3.3 cents → 3
    assert cost == 3


def test_compute_cost_missing_usage_returns_none():
    assert _compute_cost(None, "claude") is None


def test_compute_cost_missing_attrs_returns_none():
    """resp.usage exists but no input_tokens attr (hypothetical SDK change) → None, not 0."""
    usage = types.SimpleNamespace()  # no attrs at all
    assert _compute_cost(usage, "claude") is None


def test_compute_cost_unknown_adapter_returns_none():
    usage = MagicMock(input_tokens=100, output_tokens=100)
    assert _compute_cost(usage, "nonexistent_provider_xyz") is None


# --- validation / invariants -----------------------------------------------

def _mk_result(**overrides) -> SuperWorkerResult:
    base = dict(
        task="t", task_type="tt", lenses_consulted=[], routing_reason="",
        per_lens=[], synthesis="", compatible_views=[], conflicts=[], overrode=[],
        synthesis_confidence=None, eval_score=None, raw_markdown="",
        parse_status="ok", warnings=[], cost_cents=None, model_used="m",
        duration_ms=0, success=True, run_id="x",
    )
    base.update(overrides)
    return SuperWorkerResult(**base)


def test_validate_clamps_out_of_range_eval_to_none():
    r = _mk_result(eval_score=1.5)
    _validate(r)
    assert r.eval_score is None
    assert any("out of [0,1]" in w for w in r.warnings)


def test_validate_clamps_negative_cost_to_none():
    r = _mk_result(cost_cents=-10)
    _validate(r)
    assert r.cost_cents is None


def test_validate_in_range_values_unchanged():
    r = _mk_result(eval_score=0.5, synthesis_confidence=0.8, cost_cents=42)
    _validate(r)
    assert r.eval_score == 0.5
    assert r.synthesis_confidence == 0.8
    assert r.cost_cents == 42


# --- persona file path -----------------------------------------------------

def test_persona_path_resolves_to_real_file():
    """The R1B design hardcodes this path as a load-bearing decision."""
    assert SUPERWORKER_PERSONA_PATH.exists(), f"persona missing: {SUPERWORKER_PERSONA_PATH}"
    content = SUPERWORKER_PERSONA_PATH.read_text(encoding="utf-8")
    assert "SuperWorker" in content


# --- invoke() integration with mocked Anthropic ----------------------------

def _fake_anthropic_module(text: str, in_tok: int = 100, out_tok: int = 200):
    """Build a stand-in anthropic module where Anthropic() returns a client
    whose messages.create() returns a response with the given text + usage."""
    mod = types.ModuleType("anthropic")
    resp = MagicMock()
    resp.content = [MagicMock(text=text)]
    resp.usage = MagicMock(input_tokens=in_tok, output_tokens=out_tok)
    client = MagicMock()
    client.messages.create.return_value = resp
    mod.Anthropic = MagicMock(return_value=client)
    return mod, client


def test_invoke_calls_lens_router_with_correct_args(monkeypatch):
    """lens_router.route() must be called with the task description + count."""
    fake_mod, fake_client = _fake_anthropic_module(
        '<!-- superworker_json: {"synthesis": "ok", "compatible_views": [], '
        '"conflicts": [], "overrode": [], "synthesis_confidence": 0.5, '
        '"eval_score": 0.5, "per_lens": []} -->'
    )
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)
    # Disable DB record so tests don't touch the real brain
    monkeypatch.setattr(superworker, "_record_run", lambda r: None)
    # Force SDK path — this test targets the Anthropic SDK branch specifically
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: False)

    route_spy = MagicMock(wraps=lens_router.route)
    monkeypatch.setattr(lens_router, "route", route_spy)

    result = invoke("Review the arch for drift", task_type="architecture_review", lens_count=6)

    route_spy.assert_called_once()
    _, kwargs = route_spy.call_args
    assert kwargs["task_type"] == "architecture_review"
    assert kwargs["task_description"] == "Review the arch for drift"
    assert kwargs["lens_count"] == 6
    assert result.success is True
    assert result.lenses_consulted  # non-empty after routing
    # Architecture_review routes through public-floor lenses (always_on +
    # task_type list). At least one of the expected public-floor picks
    # for architecture_review must appear. Names here live in
    # aibrain/core/lenses_public.py so the test stays public-mode safe.
    expected_public_lenses = {
        "Systems Architect", "Data-First Thinking", "Algorithmic Rigor",
        "Architecture & Performance Analyst", "CTO", "Long-Term Vision",
        "Desktop App Engineer", "Operator Lens", "Adversarial Security Lens",
    }
    assert expected_public_lenses.intersection(result.lenses_consulted), (
        f"None of the expected architecture_review lenses found in "
        f"{result.lenses_consulted}"
    )


def test_invoke_propagates_honest_none_on_parse_failure(monkeypatch):
    """Parser failure → success=False, eval_score=None (NEVER a fake 0.5)."""
    # LLM returns junk with no synthesis section and no sidecar
    fake_mod, _ = _fake_anthropic_module("just some text with no structure")
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)
    monkeypatch.setattr(superworker, "_record_run", lambda r: None)
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: False)

    result = invoke("trivial task", task_type="architecture_review", lens_count=5)

    assert result.success is False
    assert result.parse_status == "failed"
    assert result.eval_score is None
    assert result.synthesis_confidence is None
    assert result.raw_markdown == "just some text with no structure"  # preserved


def test_invoke_computes_cost_from_usage(monkeypatch):
    """cost_cents must come from resp.usage × adapter rates, not from the LLM body."""
    fake_mod, _ = _fake_anthropic_module(
        '<!-- superworker_json: {"synthesis": "s", "compatible_views": [], '
        '"conflicts": [], "overrode": [], "synthesis_confidence": 0.5, '
        '"eval_score": 0.5, "per_lens": []} -->',
        in_tok=1000, out_tok=2000,
    )
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)
    monkeypatch.setattr(superworker, "_record_run", lambda r: None)
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: False)

    result = invoke("t", task_type="architecture_review", lens_count=5)
    # 1000/1000 * 0.003 + 2000/1000 * 0.015 = 0.033 USD → 3 cents
    assert result.cost_cents == 3
    assert result.model_used == "claude-sonnet-4-20250514"


def test_invoke_llm_exception_becomes_failed_result(monkeypatch):
    """API exceptions must not propagate — they become success=False with a warning."""
    fake_mod = types.ModuleType("anthropic")
    client = MagicMock()
    client.messages.create.side_effect = RuntimeError("rate limit")
    fake_mod.Anthropic = MagicMock(return_value=client)
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)
    monkeypatch.setattr(superworker, "_record_run", lambda r: None)
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: False)

    result = invoke("t", task_type="architecture_review", lens_count=5)
    assert result.success is False
    assert result.cost_cents is None  # honest None, NOT 0
    assert any("rate limit" in w for w in result.warnings)
    assert result.raw_markdown == ""
