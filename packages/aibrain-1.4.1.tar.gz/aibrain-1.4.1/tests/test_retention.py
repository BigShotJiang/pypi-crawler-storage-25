"""
Tests for aibrain/core/retention.py — Memory retention policy.

Covers: RETENTION_POLICY constants, apply_retention_policy (dry_run and real),
        unknown type handling, keep-forever types.

Uses a temporary SQLite DB seeded with memories of various ages and types.
"""

import os
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.retention import (
    RETENTION_POLICY,
    DEFAULT_RETENTION_DAYS,
    apply_retention_policy,
)


MEMORIES_SCHEMA = """
CREATE TABLE IF NOT EXISTS memories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT DEFAULT 'reference',
    content TEXT,
    tags TEXT,
    importance REAL DEFAULT 0.5,
    source TEXT DEFAULT 'test',
    active INTEGER DEFAULT 1,
    embedding BLOB,
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""


@pytest.fixture()
def retention_db(tmp_path):
    """Create a temp DB with memories of various ages and types."""
    db_path = tmp_path / "test_retention.db"
    db = sqlite3.connect(str(db_path))
    db.executescript(MEMORIES_SCHEMA)

    now = datetime.utcnow()

    # Insert memories of different types and ages
    test_data = [
        # (name, type, days_old)
        # Keep forever types
        ("user_pref", "user", 365),
        ("feedback_1", "feedback", 200),
        ("pattern_1", "pattern", 300),
        ("skill_1", "skill", 400),

        # 90-day retention
        ("project_old", "project", 100),   # should be archived
        ("project_new", "project", 10),    # should survive
        ("ref_old", "reference", 120),     # should be archived
        ("ref_new", "reference", 5),       # should survive
        ("decision_old", "decision", 91),  # should be archived

        # 30-day retention
        ("completion_old", "completion", 45),  # should be archived
        ("completion_new", "completion", 10),  # should survive
        ("correction_old", "correction", 60),  # should be archived
        ("fix_new", "fix", 5),                 # should survive
        ("discovery_old", "discovery", 35),    # should be archived

        # 7-day retention
        ("agent_old", "agent", 10),    # should be archived
        ("agent_new", "agent", 3),     # should survive

        # Unknown type
        ("weird_old", "custom_weird", 100),  # should be archived (>60 days)
        ("weird_new", "custom_weird", 30),   # should survive
    ]

    for name, mem_type, days_old in test_data:
        created = (now - timedelta(days=days_old)).strftime("%Y-%m-%d %H:%M:%S")
        db.execute(
            "INSERT INTO memories (name, type, content, active, created) VALUES (?, ?, ?, 1, ?)",
            (name, mem_type, f"Content for {name}", created)
        )

    db.commit()
    db.close()
    return str(db_path)


# ---------------------------------------------------------------------------
# Policy Constants
# ---------------------------------------------------------------------------


class TestRetentionPolicy:

    def test_keep_forever_types(self):
        for mem_type in ("user", "feedback", "pattern", "skill"):
            assert RETENTION_POLICY[mem_type] is None, f"{mem_type} should be kept forever"

    def test_90_day_types(self):
        for mem_type in ("project", "reference", "decision"):
            assert RETENTION_POLICY[mem_type] == 90

    def test_30_day_types(self):
        for mem_type in ("completion", "correction", "fix", "discovery"):
            assert RETENTION_POLICY[mem_type] == 30

    def test_7_day_types(self):
        assert RETENTION_POLICY["agent"] == 7

    def test_default_retention(self):
        assert DEFAULT_RETENTION_DAYS == 60


# ---------------------------------------------------------------------------
# Dry Run
# ---------------------------------------------------------------------------


class TestDryRun:

    def test_dry_run_does_not_modify_db(self, retention_db):
        # Count active memories before
        db = sqlite3.connect(retention_db)
        before = db.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
        db.close()

        result = apply_retention_policy(db_path=retention_db, dry_run=True)

        # Count after -- should be unchanged
        db = sqlite3.connect(retention_db)
        after = db.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
        db.close()

        assert before == after
        assert result["dry_run"] is True

    def test_dry_run_reports_counts(self, retention_db):
        result = apply_retention_policy(db_path=retention_db, dry_run=True)
        assert result["total_archived"] > 0
        assert len(result["archived"]) > 0

    def test_dry_run_identifies_expired_types(self, retention_db):
        result = apply_retention_policy(db_path=retention_db, dry_run=True)
        archived = result["archived"]
        # Old project memories should be flagged
        assert "project" in archived
        # Old completion memories should be flagged
        assert "completion" in archived

    def test_dry_run_reports_policy(self, retention_db):
        result = apply_retention_policy(db_path=retention_db, dry_run=True)
        assert "policy" in result
        assert result["policy"]["user"] == "forever"
        assert result["policy"]["agent"] == "7 days"


# ---------------------------------------------------------------------------
# Real Execution
# ---------------------------------------------------------------------------


class TestApplyRetention:

    def test_archives_old_memories(self, retention_db):
        result = apply_retention_policy(db_path=retention_db, dry_run=False)
        assert result["dry_run"] is False
        assert result["total_archived"] > 0

        # Verify in DB
        db = sqlite3.connect(retention_db)
        db.row_factory = sqlite3.Row

        # Old project should be inactive
        old_proj = db.execute(
            "SELECT active FROM memories WHERE name='project_old'"
        ).fetchone()
        assert old_proj["active"] == 0

        # New project should remain active
        new_proj = db.execute(
            "SELECT active FROM memories WHERE name='project_new'"
        ).fetchone()
        assert new_proj["active"] == 1

        db.close()

    def test_keep_forever_types_untouched(self, retention_db):
        apply_retention_policy(db_path=retention_db, dry_run=False)

        db = sqlite3.connect(retention_db)
        db.row_factory = sqlite3.Row

        for name in ("user_pref", "feedback_1", "pattern_1", "skill_1"):
            row = db.execute("SELECT active FROM memories WHERE name=?", (name,)).fetchone()
            assert row["active"] == 1, f"{name} should be kept forever"

        db.close()

    def test_agent_type_7_day_retention(self, retention_db):
        apply_retention_policy(db_path=retention_db, dry_run=False)

        db = sqlite3.connect(retention_db)
        db.row_factory = sqlite3.Row

        old_agent = db.execute("SELECT active FROM memories WHERE name='agent_old'").fetchone()
        new_agent = db.execute("SELECT active FROM memories WHERE name='agent_new'").fetchone()
        db.close()

        assert old_agent["active"] == 0, "10-day-old agent memory should be archived"
        assert new_agent["active"] == 1, "3-day-old agent memory should survive"

    def test_unknown_type_uses_default(self, retention_db):
        apply_retention_policy(db_path=retention_db, dry_run=False)

        db = sqlite3.connect(retention_db)
        db.row_factory = sqlite3.Row

        weird_old = db.execute("SELECT active FROM memories WHERE name='weird_old'").fetchone()
        weird_new = db.execute("SELECT active FROM memories WHERE name='weird_new'").fetchone()
        db.close()

        assert weird_old["active"] == 0, "100-day-old unknown type should be archived"
        assert weird_new["active"] == 1, "30-day-old unknown type should survive (< 60 default)"

    def test_completion_30_day_retention(self, retention_db):
        apply_retention_policy(db_path=retention_db, dry_run=False)

        db = sqlite3.connect(retention_db)
        db.row_factory = sqlite3.Row

        old = db.execute("SELECT active FROM memories WHERE name='completion_old'").fetchone()
        new = db.execute("SELECT active FROM memories WHERE name='completion_new'").fetchone()
        db.close()

        assert old["active"] == 0
        assert new["active"] == 1


# ---------------------------------------------------------------------------
# Edge Cases
# ---------------------------------------------------------------------------


class TestRetentionEdgeCases:

    def test_empty_database(self, tmp_path):
        db_path = tmp_path / "empty.db"
        db = sqlite3.connect(str(db_path))
        db.executescript(MEMORIES_SCHEMA)
        db.close()

        result = apply_retention_policy(db_path=str(db_path), dry_run=False)
        assert result["total_archived"] == 0
        assert result["archived"] == {}

    def test_all_already_inactive(self, tmp_path):
        db_path = tmp_path / "inactive.db"
        db = sqlite3.connect(str(db_path))
        db.executescript(MEMORIES_SCHEMA)
        db.execute(
            "INSERT INTO memories (name, type, content, active, created) VALUES (?, ?, ?, 0, ?)",
            ("old_inactive", "agent", "content", "2020-01-01 00:00:00")
        )
        db.commit()
        db.close()

        result = apply_retention_policy(db_path=str(db_path), dry_run=False)
        assert result["total_archived"] == 0

    def test_idempotent(self, retention_db):
        """Running retention twice should not change results on second run."""
        r1 = apply_retention_policy(db_path=retention_db, dry_run=False)
        r2 = apply_retention_policy(db_path=retention_db, dry_run=False)
        assert r2["total_archived"] == 0, "Second run should find nothing new to archive"
