"""
Tests for aibrain.core.dynamic_router — SelRoute dynamic model routing.

Covers: discovery, selection, routing table, cache invalidation, CLI,
user config overrides, complexity promotion, and edge cases.
"""

import json
import sys
import time
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.dynamic_router import (
    ModelInfo,
    RoutingTable,
    _parse_param_size,
    _should_skip_model,
    _probe_ollama,
    _pick_local_for_tier,
    discover_models,
    select_model,
    update_routing_table,
    get_routing_table,
    invalidate_cache,
    cli_models,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

FAKE_OLLAMA_RESPONSE = {
    "models": [
        {
            "name": "gemma3:4b",
            "size": 3338801804,
            "details": {
                "family": "gemma3",
                "parameter_size": "4.3B",
                "quantization_level": "Q4_K_M",
            },
        },
        {
            "name": "gemma3:12b",
            "size": 8149190253,
            "details": {
                "family": "gemma3",
                "parameter_size": "12.2B",
                "quantization_level": "Q4_K_M",
            },
        },
        {
            "name": "gemma3:27b",
            "size": 17396936941,
            "details": {
                "family": "gemma3",
                "parameter_size": "27.4B",
                "quantization_level": "Q4_K_M",
            },
        },
        {
            "name": "qwen2.5:7b-instruct",
            "size": 4683087332,
            "details": {
                "family": "qwen2",
                "parameter_size": "7.6B",
                "quantization_level": "Q4_K_M",
            },
        },
        {
            "name": "all-minilm:latest",
            "size": 45960996,
            "details": {
                "family": "bert",
                "parameter_size": "23M",
                "quantization_level": "F16",
            },
        },
        {
            "name": "glm-ocr:latest",
            "size": 2219299168,
            "details": {
                "family": "glmocr",
                "parameter_size": "1.1B",
                "quantization_level": "F16",
            },
        },
    ]
}


@pytest.fixture(autouse=True)
def reset_router_state():
    """Reset module-level caches before each test."""
    invalidate_cache()
    yield
    invalidate_cache()


def _mock_urlopen(response_data):
    """Create a mock for urllib.request.urlopen that returns given JSON."""
    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(response_data).encode()
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    return patch("aibrain.core.dynamic_router.urllib.request.urlopen", return_value=mock_resp)


# ---------------------------------------------------------------------------
# Test: _parse_param_size
# ---------------------------------------------------------------------------

class TestParseParamSize:
    def test_billions(self):
        assert _parse_param_size("27.4B") == 27.4

    def test_millions(self):
        assert _parse_param_size("23M") == 0.023

    def test_empty(self):
        assert _parse_param_size("") == 0.0

    def test_none(self):
        assert _parse_param_size(None) == 0.0

    def test_plain_number(self):
        assert _parse_param_size("7.0") == 7.0


# ---------------------------------------------------------------------------
# Test: _should_skip_model
# ---------------------------------------------------------------------------

class TestShouldSkipModel:
    def test_skip_bert(self):
        assert _should_skip_model("all-minilm:latest", "bert") is True

    def test_skip_ocr_name(self):
        assert _should_skip_model("glm-ocr:latest", "glmocr") is True

    def test_keep_gemma(self):
        assert _should_skip_model("gemma3:4b", "gemma3") is False

    def test_keep_qwen(self):
        assert _should_skip_model("qwen2.5:7b-instruct", "qwen2") is False

    def test_skip_embedding_name(self):
        assert _should_skip_model("embed-model:latest", "custom") is True


# ---------------------------------------------------------------------------
# Test: discover_models (with mocked Ollama)
# ---------------------------------------------------------------------------

class TestDiscoverModels:
    def test_discovers_local_and_cloud(self):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            models = discover_models(force=True)
        local = [m for m in models if m.is_local]
        cloud = [m for m in models if not m.is_local]
        # Should find 4 local (gemma3:4b, qwen2.5:7b, gemma3:12b, gemma3:27b)
        # Skipped: all-minilm (bert family), glm-ocr (ocr in name)
        assert len(local) == 4
        assert len(cloud) == 3  # haiku, sonnet, opus

    def test_skips_bert_and_ocr(self):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            models = discover_models(force=True)
        names = [m.name for m in models if m.is_local]
        assert "all-minilm:latest" not in names
        assert "glm-ocr:latest" not in names

    def test_sorted_by_param_size(self):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            models = discover_models(force=True)
        local = [m for m in models if m.is_local]
        params = [m.params_billions for m in local]
        assert params == sorted(params)

    def test_ollama_unavailable_returns_cloud_only(self):
        with patch("aibrain.core.dynamic_router.urllib.request.urlopen",
                    side_effect=Exception("Connection refused")):
            models = discover_models(force=True)
        local = [m for m in models if m.is_local]
        cloud = [m for m in models if not m.is_local]
        assert len(local) == 0
        assert len(cloud) == 3

    def test_cache_works(self):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            m1 = discover_models(force=True)

        # Second call should use cache even though urlopen would fail
        with patch("aibrain.core.dynamic_router.urllib.request.urlopen",
                    side_effect=Exception("should not be called")):
            m2 = discover_models(force=False)

        assert len(m1) == len(m2)


# ---------------------------------------------------------------------------
# Test: select_model
# ---------------------------------------------------------------------------

class TestSelectModel:
    def test_deterministic_always_code_only(self):
        assert select_model("deterministic") == "code_only"

    def test_simple_uses_local_when_available(self):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            result = select_model("simple")
        assert result.startswith("ollama/")

    def test_simple_picks_smallest(self):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            result = select_model("simple")
        # gemma3:4b is the smallest at 4.3B
        assert result == "ollama/gemma3:4b"

    def test_judgment_picks_large_local(self):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            result = select_model("judgment")
        # gemma3:27b is the largest local model >= 10B
        assert result == "ollama/gemma3:27b"

    def test_complex_always_cloud(self):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            result = select_model("complex")
        assert result == "opus"

    def test_simple_falls_back_to_haiku(self):
        with patch("aibrain.core.dynamic_router.urllib.request.urlopen",
                    side_effect=Exception("no ollama")):
            result = select_model("simple")
        assert result == "haiku"

    def test_judgment_falls_back_to_sonnet(self):
        # Only small models available — no 10B+ local
        small_only = {
            "models": [
                {
                    "name": "tiny:1b",
                    "size": 500_000_000,
                    "details": {"family": "custom", "parameter_size": "1.0B", "quantization_level": "Q4"},
                }
            ]
        }
        with _mock_urlopen(small_only):
            result = select_model("judgment")
        assert result == "sonnet"

    def test_unknown_type_defaults_to_sonnet(self):
        result = select_model("unknown_type")
        assert result == "sonnet"

    def test_complexity_promotion(self):
        """High complexity judgment -> complex (opus)."""
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            result = select_model("judgment", complexity=0.9)
        assert result == "opus"

    def test_low_complexity_no_promotion(self):
        """Low complexity judgment stays judgment."""
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            result = select_model("judgment", complexity=0.3)
        # Should use local large model, not opus
        assert result != "opus"

    def test_user_override_respected(self):
        """If user config says judgment=haiku, respect it."""
        mock_config = {"judgment": "haiku"}
        with patch("aibrain.core.dynamic_router._load_user_overrides", return_value=mock_config):
            result = select_model("judgment")
        assert result == "haiku"

    def test_user_override_code_only(self):
        mock_config = {"simple": "code_only"}
        with patch("aibrain.core.dynamic_router._load_user_overrides", return_value=mock_config):
            result = select_model("simple")
        assert result == "code_only"


# ---------------------------------------------------------------------------
# Test: routing table
# ---------------------------------------------------------------------------

class TestRoutingTable:
    def test_update_builds_table(self):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            table = update_routing_table()
        assert table.deterministic == "code_only"
        assert table.simple.startswith("ollama/")
        assert table.complex == "opus"
        assert table.last_updated > 0

    def test_get_routing_table_lazy_init(self):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            table = get_routing_table()
        assert isinstance(table, RoutingTable)
        assert table.deterministic == "code_only"

    def test_as_dict(self):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            table = update_routing_table()
        d = table.as_dict()
        assert set(d.keys()) == {"deterministic", "simple", "judgment", "complex"}

    def test_invalidate_forces_refresh(self):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            t1 = update_routing_table()
        ts1 = t1.last_updated

        time.sleep(0.01)
        invalidate_cache()

        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            t2 = update_routing_table()
        assert t2.last_updated > ts1

    def test_local_models_listed(self):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            table = update_routing_table()
        assert "gemma3:4b" in table.local_models
        assert "gemma3:27b" in table.local_models


# ---------------------------------------------------------------------------
# Test: _pick_local_for_tier
# ---------------------------------------------------------------------------

class TestPickLocalForTier:
    def _make_models(self):
        return [
            ModelInfo("tiny:1b", "ollama", "1.0B", 1.0, "Q4", 500_000_000, "custom", 0.0, True),
            ModelInfo("mid:8b", "ollama", "8.0B", 8.0, "Q4", 5_000_000_000, "custom", 0.0, True),
            ModelInfo("big:15b", "ollama", "15.0B", 15.0, "Q4", 10_000_000_000, "custom", 0.0, True),
        ]

    def test_simple_picks_smallest(self):
        models = self._make_models()
        result = _pick_local_for_tier(models, "simple")
        assert result == "ollama/tiny:1b"

    def test_judgment_picks_largest_over_threshold(self):
        models = self._make_models()
        result = _pick_local_for_tier(models, "judgment")
        assert result == "ollama/big:15b"

    def test_judgment_none_if_all_small(self):
        models = [
            ModelInfo("tiny:1b", "ollama", "1.0B", 1.0, "Q4", 500_000_000, "custom", 0.0, True),
        ]
        result = _pick_local_for_tier(models, "judgment")
        assert result is None

    def test_empty_models(self):
        assert _pick_local_for_tier([], "simple") is None
        assert _pick_local_for_tier([], "judgment") is None


# ---------------------------------------------------------------------------
# Test: CLI
# ---------------------------------------------------------------------------

class TestCLI:
    def test_cli_json_output(self, capsys):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            code = cli_models(["--json"])
        assert code == 0
        out = capsys.readouterr().out
        data = json.loads(out)
        assert "routing" in data
        assert "models" in data
        assert data["routing"]["deterministic"] == "code_only"

    def test_cli_pretty_output(self, capsys):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            code = cli_models([])
        assert code == 0
        out = capsys.readouterr().out
        assert "Routing Table" in out
        assert "gemma3:4b" in out

    def test_cli_refresh_flag(self, capsys):
        with _mock_urlopen(FAKE_OLLAMA_RESPONSE):
            code = cli_models(["--refresh"])
        assert code == 0


# ---------------------------------------------------------------------------
# Test: ModelInfo
# ---------------------------------------------------------------------------

class TestModelInfo:
    def test_display_name_local(self):
        m = ModelInfo("gemma3:4b", "ollama", "4.3B", 4.3, "Q4", 3_338_801_804, "gemma3", 0.0, True)
        assert m.display_name == "ollama/gemma3:4b"

    def test_display_name_cloud(self):
        m = ModelInfo("sonnet", "anthropic", "n/a", 0.0, "n/a", 0, "anthropic", 0.003, False)
        assert m.display_name == "sonnet"

    def test_size_human_gb(self):
        m = ModelInfo("big", "ollama", "27B", 27.0, "Q4", 17_396_936_941, "gemma3", 0.0, True)
        assert "GB" in m.size_human

    def test_size_human_mb(self):
        m = ModelInfo("small", "ollama", "23M", 0.023, "F16", 45_960_996, "bert", 0.0, True)
        assert "MB" in m.size_human
