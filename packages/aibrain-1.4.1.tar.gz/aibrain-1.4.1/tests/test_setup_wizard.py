"""
Tests for setup_wizard.py — First-run bootstrapper.

Covers: generate_config, save_progress, load_progress, clear_progress,
        run_cmd, http_get_json, color helpers.

Does NOT test interactive prompts (those require stdin).
Uses tmp_path for all file operations.
"""

import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def wizard_env(tmp_path):
    """Patch setup_wizard paths to use tmp_path."""
    import setup_wizard

    original_config = setup_wizard.CONFIG_PATH
    original_progress = setup_wizard.PROGRESS_PATH
    original_aibrain_dir = setup_wizard.AIBRAIN_DIR
    original_db_path = setup_wizard.DB_PATH
    original_scheduled = setup_wizard.SCHEDULED_JOBS_PATH

    setup_wizard.CONFIG_PATH = tmp_path / "config.json"
    setup_wizard.PROGRESS_PATH = tmp_path / ".setup_progress.json"
    setup_wizard.AIBRAIN_DIR = tmp_path
    setup_wizard.DB_PATH = tmp_path / "aibrain.db"
    setup_wizard.SCHEDULED_JOBS_PATH = tmp_path / "scheduled_jobs.json"

    yield tmp_path

    # Restore
    setup_wizard.CONFIG_PATH = original_config
    setup_wizard.PROGRESS_PATH = original_progress
    setup_wizard.AIBRAIN_DIR = original_aibrain_dir
    setup_wizard.DB_PATH = original_db_path
    setup_wizard.SCHEDULED_JOBS_PATH = original_scheduled


# ---------------------------------------------------------------------------
# Progress save/load
# ---------------------------------------------------------------------------


class TestProgress:

    def test_load_empty(self, wizard_env):
        from setup_wizard import load_progress
        result = load_progress()
        assert result == {"completed_steps": [], "config": {}}

    def test_save_and_load(self, wizard_env):
        from setup_wizard import save_progress, load_progress
        progress = {"completed_steps": ["step1"], "config": {"agent_name": "Neuro"}}
        save_progress(progress)

        loaded = load_progress()
        assert loaded["completed_steps"] == ["step1"]
        assert loaded["config"]["agent_name"] == "Neuro"
        assert "last_updated" in loaded

    def test_save_adds_timestamp(self, wizard_env):
        from setup_wizard import save_progress
        progress = {"completed_steps": [], "config": {}}
        save_progress(progress)
        assert "last_updated" in progress

    def test_clear_progress(self, wizard_env):
        from setup_wizard import save_progress, clear_progress, load_progress
        save_progress({"completed_steps": ["step1"], "config": {}})
        clear_progress()
        # After clearing, load should return defaults
        result = load_progress()
        assert result == {"completed_steps": [], "config": {}}

    def test_load_corrupted_file(self, wizard_env):
        from setup_wizard import load_progress, PROGRESS_PATH
        PROGRESS_PATH.write_text("not valid json{{{", encoding="utf-8")
        result = load_progress()
        assert result == {"completed_steps": [], "config": {}}


# ---------------------------------------------------------------------------
# Config generation
# ---------------------------------------------------------------------------


class TestGenerateConfig:

    def test_generate_from_progress(self, wizard_env):
        from setup_wizard import generate_config, CONFIG_PATH
        progress = {
            "completed_steps": [],
            "config": {
                "agent_name": "TestBot",
                "location_name": "Adelaide",
                "github_token": "ghp_test123",
            }
        }
        generate_config(progress)

        assert CONFIG_PATH.exists()
        cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        assert cfg["agent_name"] == "TestBot"
        assert cfg["location_name"] == "Adelaide"
        assert cfg["github_token"] == "ghp_test123"

    def test_generate_sets_db_path(self, wizard_env):
        from setup_wizard import generate_config, CONFIG_PATH, DB_PATH
        progress = {"completed_steps": [], "config": {}}
        generate_config(progress)

        cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        assert cfg["memory_db"] == str(DB_PATH)

    def test_generate_merges_with_existing(self, wizard_env):
        from setup_wizard import generate_config, CONFIG_PATH
        # Pre-existing config
        CONFIG_PATH.write_text(json.dumps({
            "agent_name": "OldBot",
            "custom_field": "preserved",
        }), encoding="utf-8")

        progress = {"completed_steps": [], "config": {"agent_name": "NewBot"}}
        generate_config(progress)

        cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        assert cfg["agent_name"] == "NewBot"
        assert cfg["custom_field"] == "preserved"

    def test_generate_removes_internal_keys(self, wizard_env):
        from setup_wizard import generate_config, CONFIG_PATH
        progress = {"completed_steps": [], "config": {"_selected_workflows": ["a", "b"]}}
        generate_config(progress)

        cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        assert "_selected_workflows" not in cfg
        assert "_readme" not in cfg

    def test_generate_empty_progress(self, wizard_env):
        from setup_wizard import generate_config, CONFIG_PATH
        progress = {"completed_steps": [], "config": {}}
        generate_config(progress)
        assert CONFIG_PATH.exists()
        cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        assert isinstance(cfg, dict)


# ---------------------------------------------------------------------------
# run_cmd
# ---------------------------------------------------------------------------


class TestRunCmd:

    def test_successful_command(self):
        from setup_wizard import run_cmd
        success, output = run_cmd("python --version")
        assert success is True
        assert "Python" in output

    def test_failed_command(self):
        from setup_wizard import run_cmd
        success, output = run_cmd("nonexistent_command_xyz_123")
        assert success is False

    def test_timeout(self):
        from setup_wizard import run_cmd
        # Use a command that would hang, with a very short timeout
        success, output = run_cmd("python -c \"import time; time.sleep(10)\"", timeout=1)
        assert success is False

    def test_list_command(self):
        from setup_wizard import run_cmd
        success, output = run_cmd(["python", "--version"])
        assert success is True
        assert "Python" in output


# ---------------------------------------------------------------------------
# Color helpers
# ---------------------------------------------------------------------------


class TestColorHelpers:

    def test_c_function(self):
        from setup_wizard import c
        result = c("green", "hello")
        assert "hello" in result
        # Should contain ANSI escape codes
        assert "\033[" in result

    def test_c_unknown_color(self):
        from setup_wizard import c
        result = c("nonexistent", "text")
        assert "text" in result
        # Should still have reset code
        assert "\033[0m" in result


# ---------------------------------------------------------------------------
# http_get_json
# ---------------------------------------------------------------------------


class TestHttpGetJson:

    def test_invalid_url(self):
        from setup_wizard import http_get_json
        success, data = http_get_json("http://localhost:99999/nonexistent")
        assert success is False

    def test_non_json_url(self):
        from setup_wizard import http_get_json
        # This will likely fail to parse as JSON even if it connects
        success, data = http_get_json("http://localhost:1/")
        assert success is False
