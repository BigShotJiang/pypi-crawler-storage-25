"""
Tests for category summaries and tiered retrieval.

Covers:
- Category summary creation and update
- Search category summaries returns results
- Tiered search stops at tier 1 when sufficient
- Tiered search falls through to tier 2 when summaries insufficient
- Tiered search returns tier_used and tokens_saved metadata
- Auto-update trigger debouncing
- Brain.smart_search() works
"""

import os
import sys
import sqlite3
import tempfile
import time
from pathlib import Path
from unittest import mock

import pytest

# Ensure project root is on sys.path
AIBRAIN_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(AIBRAIN_ROOT))


@pytest.fixture()
def fresh_db(tmp_path, monkeypatch):
    """Create a fresh isolated SQLite DB for each test.

    Uses monkeypatch.setenv so AIBRAIN_DB does NOT leak into sibling test
    files via aibrain_db._resolve_db_path(). Captures and restores the
    module-level DB_PATH / AIBRAIN_ROOT so tests that read those attrs
    directly (e.g. test_lens_router_completeness) don't see a torn-down
    tmp_path after this fixture's teardown. Mirrors conftest.py pattern.
    """
    db_path = tmp_path / "test_categories.db"
    monkeypatch.setenv("AIBRAIN_DB", str(db_path))
    monkeypatch.setenv("AIBRAIN_ROOT", str(tmp_path))

    import aibrain_db
    # Reset module state
    if aibrain_db._conn is not None:
        try:
            aibrain_db._conn.close()
        except Exception:
            pass
        aibrain_db._conn = None
    original_db_path = aibrain_db.DB_PATH
    original_root = aibrain_db.AIBRAIN_ROOT
    aibrain_db.DB_PATH = db_path
    aibrain_db.AIBRAIN_ROOT = tmp_path

    db = aibrain_db.get_db()
    yield db

    # Cleanup: close conn and restore module attrs so sibling files that
    # read aibrain_db.DB_PATH / AIBRAIN_ROOT directly don't see our
    # torn-down tmp_path.
    try:
        aibrain_db._conn.close()
    except Exception:
        pass
    aibrain_db._conn = None
    aibrain_db.DB_PATH = original_db_path
    aibrain_db.AIBRAIN_ROOT = original_root


def _seed_memories(db, category="project", count=5, base_content="Memory about"):
    """Insert test memories directly, bypassing dedup and satellite routing."""
    for i in range(count):
        db.execute("""
            INSERT INTO memories (name, type, content, importance, active,
                                  created, updated)
            VALUES (?, ?, ?, ?, 1, datetime('now'), datetime('now'))
        """, (
            f"test_mem_{category}_{i}",
            category,
            f"{base_content} {category} item {i} with keywords alpha beta gamma",
            round(0.3 + (i * 0.1), 2),
        ))
    db.commit()
    # Rebuild FTS index
    try:
        db.execute("INSERT INTO memories_fts(memories_fts) VALUES('rebuild')")
    except Exception:
        pass


class TestExtractKeywords:
    """Unit tests for _extract_keywords helper."""

    def test_basic_extraction(self):
        from aibrain_db import _extract_keywords
        text = "Python is a great programming language for data science and machine learning"
        kws = _extract_keywords(text, top_n=5)
        assert isinstance(kws, list)
        assert len(kws) <= 5
        # Should contain substantive words, not stop words
        for kw in kws:
            assert kw not in ("is", "a", "for", "and")

    def test_empty_text(self):
        from aibrain_db import _extract_keywords
        assert _extract_keywords("", top_n=5) == []

    def test_deduplication(self):
        from aibrain_db import _extract_keywords
        text = "test test test unique"
        kws = _extract_keywords(text, top_n=5)
        assert "test" in kws


class TestBuildSummaryText:
    """Unit tests for _build_summary_text helper."""

    def test_basic_summary(self):
        from aibrain_db import _build_summary_text
        memories = [
            {"content": "First memory content", "name": "mem1"},
            {"content": "Second memory content", "name": "mem2"},
        ]
        summary = _build_summary_text(memories)
        assert "First memory content" in summary
        assert "Second memory content" in summary
        assert " | " in summary

    def test_dedup_in_summary(self):
        from aibrain_db import _build_summary_text
        memories = [
            {"content": "Same content", "name": "mem1"},
            {"content": "Same content", "name": "mem2"},
        ]
        summary = _build_summary_text(memories)
        # Should only appear once
        assert summary.count("Same content") == 1

    def test_empty_memories(self):
        from aibrain_db import _build_summary_text
        assert _build_summary_text([]) == ""


class TestUpdateCategorySummary:
    """Tests for update_category_summary()."""

    def test_creates_summary(self, fresh_db):
        import aibrain_db
        _seed_memories(fresh_db, category="feedback", count=5)

        aibrain_db.update_category_summary("feedback", db=fresh_db)

        row = fresh_db.execute(
            "SELECT * FROM category_summaries WHERE category = ?", ("feedback",)
        ).fetchone()
        assert row is not None
        assert row["memory_count"] == 5
        assert row["avg_importance"] > 0
        assert len(row["summary"]) > 0
        assert len(row["top_keywords"]) > 0
        assert row["last_updated"] is not None

    def test_updates_existing_summary(self, fresh_db):
        import aibrain_db
        _seed_memories(fresh_db, category="user", count=3)
        aibrain_db.update_category_summary("user", db=fresh_db)

        first = fresh_db.execute(
            "SELECT memory_count FROM category_summaries WHERE category = 'user'"
        ).fetchone()
        assert first["memory_count"] == 3

        # Add more memories and re-update
        _seed_memories(fresh_db, category="user", count=2,
                       base_content="Additional info about")
        aibrain_db.update_category_summary("user", db=fresh_db)

        second = fresh_db.execute(
            "SELECT memory_count FROM category_summaries WHERE category = 'user'"
        ).fetchone()
        assert second["memory_count"] == 5

    def test_removes_empty_category(self, fresh_db):
        import aibrain_db
        # Insert then remove all memories
        _seed_memories(fresh_db, category="pattern", count=2)
        aibrain_db.update_category_summary("pattern", db=fresh_db)
        assert fresh_db.execute(
            "SELECT COUNT(*) FROM category_summaries WHERE category = 'pattern'"
        ).fetchone()[0] == 1

        # Deactivate all memories
        fresh_db.execute("UPDATE memories SET active = 0 WHERE type = 'pattern'")
        fresh_db.commit()
        aibrain_db.update_category_summary("pattern", db=fresh_db)

        assert fresh_db.execute(
            "SELECT COUNT(*) FROM category_summaries WHERE category = 'pattern'"
        ).fetchone()[0] == 0


class TestGetCategorySummaries:
    """Tests for get_category_summaries()."""

    def test_get_all(self, fresh_db):
        import aibrain_db
        _seed_memories(fresh_db, category="user", count=3)
        _seed_memories(fresh_db, category="feedback", count=4)
        aibrain_db.update_category_summary("user", db=fresh_db)
        aibrain_db.update_category_summary("feedback", db=fresh_db)

        summaries = aibrain_db.get_category_summaries(db=fresh_db)
        assert len(summaries) == 2
        cats = {s["category"] for s in summaries}
        assert "user" in cats
        assert "feedback" in cats

    def test_get_specific(self, fresh_db):
        import aibrain_db
        _seed_memories(fresh_db, category="user", count=3)
        _seed_memories(fresh_db, category="feedback", count=4)
        aibrain_db.update_category_summary("user", db=fresh_db)
        aibrain_db.update_category_summary("feedback", db=fresh_db)

        summaries = aibrain_db.get_category_summaries(
            categories=["user"], db=fresh_db
        )
        assert len(summaries) == 1
        assert summaries[0]["category"] == "user"

    def test_get_nonexistent(self, fresh_db):
        import aibrain_db
        summaries = aibrain_db.get_category_summaries(
            categories=["nonexistent"], db=fresh_db
        )
        assert summaries == []


class TestSearchCategorySummaries:
    """Tests for search_category_summaries()."""

    def test_keyword_fallback_search(self, fresh_db):
        import aibrain_db
        _seed_memories(fresh_db, category="project", count=5,
                       base_content="Python programming project")
        aibrain_db.update_category_summary("project", db=fresh_db)

        results = aibrain_db.search_category_summaries(
            "python programming", db=fresh_db
        )
        assert len(results) >= 1
        assert results[0]["category"] == "project"
        assert results[0]["score"] > 0

    def test_no_match_returns_empty(self, fresh_db):
        import aibrain_db
        _seed_memories(fresh_db, category="project", count=3)
        aibrain_db.update_category_summary("project", db=fresh_db)

        results = aibrain_db.search_category_summaries(
            "zzzznonexistenttopic", db=fresh_db
        )
        assert results == []


class TestTieredSearch:
    """Tests for tiered_search()."""

    def test_returns_required_metadata(self, fresh_db):
        import aibrain_db
        _seed_memories(fresh_db, category="reference", count=5,
                       base_content="Reference about databases")

        result = aibrain_db.tiered_search("databases", db=fresh_db)
        assert "results" in result
        assert "tier_used" in result
        assert "tokens_saved" in result
        assert "reason" in result
        assert result["tier_used"] in (1, 2, 3)

    def test_tier2_individual_memories(self, fresh_db):
        """Tier 2 returns individual memories when summaries are insufficient."""
        import aibrain_db
        _seed_memories(fresh_db, category="feedback", count=10,
                       base_content="Feedback about testing")

        # Don't create summaries, so tier 1 has nothing
        result = aibrain_db.tiered_search("testing feedback", db=fresh_db)
        assert result["tier_used"] >= 2
        assert len(result["results"]) > 0

    def test_temporal_query_skips_tier1(self, fresh_db):
        """Temporal queries should skip tier 1 (summaries lack session detail)."""
        import aibrain_db
        _seed_memories(fresh_db, category="project", count=5,
                       base_content="Project update from last week")
        aibrain_db.update_category_summary("project", db=fresh_db)

        result = aibrain_db.tiered_search(
            "what happened last week", db=fresh_db
        )
        # Should skip tier 1 because temporal queries need session-specific detail
        assert result["tier_used"] >= 2
        assert result["query_type"] == "temporal"

    def test_multi_session_skips_tier1(self, fresh_db):
        """multi_session queries should skip tier 1."""
        import aibrain_db
        _seed_memories(fresh_db, category="user", count=5)
        aibrain_db.update_category_summary("user", db=fresh_db)

        result = aibrain_db.tiered_search(
            "what have we discussed across sessions", db=fresh_db
        )
        assert result["tier_used"] >= 2

    def test_tier3_fallback_no_results(self, fresh_db):
        """Tier 3 is reached when tier 2 returns too few results."""
        import aibrain_db

        # Search for something that doesn't exist anywhere
        result = aibrain_db.tiered_search(
            "xyznonexistenttopicabc", limit=10, db=fresh_db
        )
        assert result["tier_used"] == 3

    def test_tokens_saved_positive_tier1(self, fresh_db):
        """When tier 1 suffices, tokens_saved should be positive."""
        import aibrain_db
        _seed_memories(fresh_db, category="reference", count=20,
                       base_content="Reference data about APIs")
        aibrain_db.update_category_summary("reference", db=fresh_db)

        # Patch search_category_summaries to return high score
        original = aibrain_db.search_category_summaries

        def _mock_search(query, limit=5, db=None):
            results = original(query, limit=limit, db=db)
            if results:
                results[0]["score"] = 0.95  # Force above threshold
            return results

        with mock.patch.object(aibrain_db, 'search_category_summaries', _mock_search):
            result = aibrain_db.tiered_search("API reference", db=fresh_db)

        if result["tier_used"] == 1:
            assert result["tokens_saved"] > 0


class TestDebouncing:
    """Tests for auto-update trigger debouncing."""

    def test_debounce_prevents_rapid_updates(self, fresh_db):
        import aibrain_db
        _seed_memories(fresh_db, category="project", count=3)

        # First call should update
        aibrain_db._category_update_timestamps.pop("project", None)
        aibrain_db.update_category_summary("project", db=fresh_db)

        # Record the last_updated time
        row1 = fresh_db.execute(
            "SELECT last_updated FROM category_summaries WHERE category = 'project'"
        ).fetchone()

        # _maybe_update should be a no-op because debounce timer hasn't expired
        aibrain_db._maybe_update_category_summary("project")
        row2 = fresh_db.execute(
            "SELECT last_updated FROM category_summaries WHERE category = 'project'"
        ).fetchone()
        assert row1["last_updated"] == row2["last_updated"]

    def test_debounce_allows_after_expiry(self, fresh_db):
        import aibrain_db
        _seed_memories(fresh_db, category="decision", count=3)

        # Set timestamp far in the past to simulate expiry
        aibrain_db._category_update_timestamps["decision"] = 0
        # Also set DB last_updated in the past
        fresh_db.execute("""
            INSERT INTO category_summaries (category, summary, memory_count, last_updated)
            VALUES ('decision', 'old', 3, '2020-01-01T00:00:00+00:00')
            ON CONFLICT(category) DO UPDATE SET last_updated = '2020-01-01T00:00:00+00:00'
        """)
        fresh_db.commit()

        aibrain_db._maybe_update_category_summary("decision")

        row = fresh_db.execute(
            "SELECT last_updated FROM category_summaries WHERE category = 'decision'"
        ).fetchone()
        # Should have been updated to a recent timestamp
        assert row["last_updated"] > "2020-01-01"


class TestBrainSmartSearch:
    """Tests for Brain.smart_search()."""

    def test_smart_search_returns_dict(self, fresh_db):
        import aibrain_db
        from aibrain.core.memory_api import Brain

        _seed_memories(fresh_db, category="project", count=5,
                       base_content="Project details about testing")

        brain = Brain(db_path=str(aibrain_db.DB_PATH))
        result = brain.smart_search("testing")

        assert isinstance(result, dict)
        assert "results" in result
        assert "tier_used" in result
        assert "tokens_saved" in result
        assert "reason" in result

    def test_smart_search_finds_results(self, fresh_db):
        import aibrain_db
        from aibrain.core.memory_api import Brain

        _seed_memories(fresh_db, category="feedback", count=8,
                       base_content="Feedback about deployment pipeline")

        brain = Brain(db_path=str(aibrain_db.DB_PATH))
        result = brain.smart_search("deployment pipeline")

        assert len(result["results"]) > 0

    def test_smart_search_custom_threshold(self, fresh_db):
        import aibrain_db
        from aibrain.core.memory_api import Brain

        _seed_memories(fresh_db, category="user", count=5)

        brain = Brain(db_path=str(aibrain_db.DB_PATH))
        result = brain.smart_search("user preferences", sufficiency_threshold=0.99)

        # With a very high threshold, should fall through past tier 1
        assert isinstance(result, dict)
        assert result["tier_used"] >= 1
