"""
Tests for aibrain.core.agent_router — SelRoute v3 Layer 1 (handler shape).

Covers:
  1. Every SHAPE_TABLE task_type resolves to a valid RouteDecision
  2. force_shape= override honored (manual path)
  3. token_budget_exceeded forces tool_action, beating force_shape
  4. record_outcome() is a no-op when quality_score is None (honest rubric)
  5. Referenced agent names exist in the lens_router LENSES registry
  6. Backward compat: route() with no args returns a sensible default
"""

from __future__ import annotations

import os
import sqlite3
import sys
import tempfile
import time
from pathlib import Path
from unittest import mock

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from aibrain.core import agent_router
from aibrain.core.agent_router import (
    HANDLER_SHAPES,
    MIN_QUALITY_DELTA_FOR_OVERRIDE,
    MIN_STATS_SAMPLES_FOR_OVERRIDE,
    RouteDecision,
    SHAPE_TABLE,
    SPECIALIST,
    SUPERWORKER,
    TOOL_ACTION,
    _apply_stats_overlay,
    _invalidate_stats_cache,
    _pick_model,
    list_shapes_for_task_type,
    record_outcome,
    route,
)
from aibrain.core.lens_router import LENSES, TASK_TYPE_LENSES


# ─── Shared fixture: isolated temp DB for the router ──────────────────
@pytest.fixture
def temp_router_db(monkeypatch):
    """Redirect agent_router's DB connection to a temp file."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="router_test_")
    os.close(fd)

    def _fake_conn():
        conn = sqlite3.connect(path)
        conn.row_factory = sqlite3.Row
        return conn

    monkeypatch.setattr(agent_router, "_get_db_conn", _fake_conn)
    _invalidate_stats_cache()
    yield path
    _invalidate_stats_cache()
    try:
        os.unlink(path)
    except OSError:
        pass


# ─── 1. Coverage: every task_type returns valid RouteDecisions ──────
def test_shape_table_matches_task_type_lenses():
    """SHAPE_TABLE must cover every task_type in lens_router.TASK_TYPE_LENSES.

    Floor: at least 25 task types (the original SelRoute v3 set). Apr 11
    expansion added 13 specialty task types for the new specialty agents
    bringing the total to 38. New task types may be added at any time —
    this test fails only if SHAPE_TABLE drifts FROM TASK_TYPE_LENSES (the
    set equality check), not if either set grows.
    """
    assert set(SHAPE_TABLE.keys()) == set(TASK_TYPE_LENSES.keys()), (
        f"SHAPE_TABLE drift: "
        f"missing={set(TASK_TYPE_LENSES) - set(SHAPE_TABLE)}, "
        f"extra={set(SHAPE_TABLE) - set(TASK_TYPE_LENSES)}"
    )
    assert len(SHAPE_TABLE) >= 25


@pytest.mark.parametrize("task_type", sorted(SHAPE_TABLE.keys()))
def test_route_returns_valid_decision_for_each_task_type(task_type, temp_router_db):
    """Every task_type must yield a non-None RouteDecision satisfying invariants."""
    decision = route(task_type=task_type, task_description=f"test {task_type}")
    assert decision is not None
    assert isinstance(decision, RouteDecision)
    assert decision.handler_shape in HANDLER_SHAPES
    assert decision.task_type == task_type
    assert decision.model_recommendation in ("haiku", "sonnet", "opus", "code_only")
    # Shape-coupling invariant (LeCun #2)
    if decision.handler_shape in (TOOL_ACTION, SPECIALIST):
        assert decision.agent_name is not None
        assert decision.lens_set is None
    else:
        assert decision.lens_set is not None and len(decision.lens_set) > 0
        assert decision.agent_name is None


# ─── 2. force_shape= manual override ─────────────────────────────────
@pytest.mark.parametrize("shape", HANDLER_SHAPES)
def test_force_shape_manual_override(shape, temp_router_db):
    """force_shape must be honored and mark override_mode='manual'."""
    # Start with security_review (default SPECIALIST) — force each of the 3
    decision = route(
        task_type="security_review",
        task_description="review login",
        force_shape=shape,
    )
    assert decision.handler_shape == shape
    assert decision.override_mode == "manual"
    assert "manual override" in decision.routing_reason


def test_force_shape_invalid_raises():
    with pytest.raises(ValueError):
        route(task_type="security_review", force_shape="not_a_shape")


# ─── 3. budget_forced wins over force_shape ──────────────────────────
def test_budget_exceeded_forces_tool_action(temp_router_db):
    """token_budget_exceeded=True must override even force_shape=superworker."""
    decision = route(
        task_type="architecture_review",
        task_description="deep review",
        force_shape=SUPERWORKER,
        token_budget_exceeded=True,
    )
    assert decision.handler_shape == TOOL_ACTION
    assert decision.override_mode == "budget_forced"
    assert "budget" in decision.routing_reason.lower()
    assert decision.model_recommendation == "haiku"
    assert decision.agent_name is not None
    assert decision.lens_set is None


def test_budget_exceeded_without_force(temp_router_db):
    decision = route(task_type="security_review", token_budget_exceeded=True)
    assert decision.handler_shape == TOOL_ACTION
    assert decision.override_mode == "budget_forced"


# ─── 4. record_outcome() honest-rubric filter ────────────────────────
def test_record_outcome_drops_none_quality(temp_router_db):
    """quality_score=None must be a no-op — no row written."""
    record_outcome(
        task_type="security_review",
        handler_shape=SPECIALIST,
        quality_score=None,
        override_mode="auto",
        duration_ms=500,
        actor="test",
    )
    # Confirm table is empty (or doesn't exist yet)
    conn = sqlite3.connect(temp_router_db)
    try:
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='routing_outcomes'"
        ).fetchone()
        if row is not None:
            count = conn.execute("SELECT COUNT(*) FROM routing_outcomes").fetchone()[0]
            assert count == 0
    finally:
        conn.close()


def test_record_outcome_writes_honest_score(temp_router_db):
    """quality_score=float writes exactly one row."""
    record_outcome(
        task_type="security_review",
        handler_shape=SPECIALIST,
        quality_score=0.87,
        override_mode="auto",
        duration_ms=1234,
        actor="test",
    )
    conn = sqlite3.connect(temp_router_db)
    try:
        rows = conn.execute(
            "SELECT task_type, handler_shape, quality_score, override_mode, actor "
            "FROM routing_outcomes"
        ).fetchall()
    finally:
        conn.close()
    assert len(rows) == 1
    assert rows[0] == ("security_review", SPECIALIST, 0.87, "auto", "test")


def test_record_outcome_rejects_invalid_shape(temp_router_db):
    record_outcome(
        task_type="security_review",
        handler_shape="bogus_shape",
        quality_score=0.9,
        override_mode="auto",
        duration_ms=100,
        actor="test",
    )
    conn = sqlite3.connect(temp_router_db)
    try:
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='routing_outcomes'"
        ).fetchone()
        if row is not None:
            count = conn.execute("SELECT COUNT(*) FROM routing_outcomes").fetchone()[0]
            assert count == 0
    finally:
        conn.close()


# ─── 5. Agent-name validity against LENSES registry ─────────────────
def test_all_referenced_agent_names_in_lenses():
    """Every name in DEFAULT_SPECIALIST_AGENT / DEFAULT_TOOL_ACTION_AGENT
    must exist in lens_router.LENSES (Schneier: prevent roster drift)."""
    from aibrain.core.agent_router import (
        DEFAULT_FALLBACK_AGENT,
        DEFAULT_SPECIALIST_AGENT,
        DEFAULT_TOOL_ACTION_AGENT,
    )
    referenced = set(DEFAULT_SPECIALIST_AGENT.values())
    referenced |= set(DEFAULT_TOOL_ACTION_AGENT.values())
    referenced.add(DEFAULT_FALLBACK_AGENT)

    missing = [n for n in referenced if n not in LENSES]
    assert not missing, f"Names missing from LENSES: {missing}"


# ─── 6. Backward compat — no args returns sensible default ──────────
def test_route_no_args_returns_default(temp_router_db):
    """route() with no args must return a valid decision, not crash."""
    decision = route()
    assert decision is not None
    assert isinstance(decision, RouteDecision)
    # Empty description → inference returns "broad_unknown" → SUPERWORKER
    assert decision.task_type == "broad_unknown"
    assert decision.handler_shape == SUPERWORKER
    assert decision.lens_set is not None and len(decision.lens_set) > 0


def test_route_unknown_task_type_falls_back(temp_router_db):
    decision = route(task_type="totally_made_up_type")
    assert decision is not None
    assert decision.task_type == "broad_unknown"
    assert decision.handler_shape == SUPERWORKER


def test_route_inference_from_description(temp_router_db):
    """Security keywords in description should steer to security_review."""
    decision = route(task_description="check this code for credential leaks")
    assert decision.task_type == "security_review"
    assert decision.handler_shape == SPECIALIST
    assert decision.agent_name == "Security Engineer"


# ─── Invariant + helper tests ───────────────────────────────────────
def test_route_decision_rejects_bad_shape_coupling():
    """RouteDecision invariants must fire on bad construction."""
    with pytest.raises(ValueError):
        RouteDecision(
            handler_shape=SPECIALIST,
            task_type="security_review",
            routing_reason="bad",
            model_recommendation="sonnet",
            confidence=1.0,
            # agent_name missing — should raise
        )
    with pytest.raises(ValueError):
        RouteDecision(
            handler_shape=SUPERWORKER,
            task_type="architecture_review",
            routing_reason="bad",
            model_recommendation="sonnet",
            confidence=1.0,
            agent_name="Someone",  # superworker must not carry agent_name
            lens_set=("Systems Architect",),
        )
    with pytest.raises(ValueError):
        RouteDecision(
            handler_shape="nonsense",
            task_type="x",
            routing_reason="bad",
            model_recommendation="sonnet",
            confidence=1.0,
        )


def test_pick_model_monotonicity():
    """LeCun invariant #3 — high_stakes never lowers the model."""
    rank = {"haiku": 0, "sonnet": 1, "opus": 2, "code_only": -1}
    for shape in HANDLER_SHAPES:
        low = _pick_model(shape, high_stakes=False)
        high = _pick_model(shape, high_stakes=True)
        assert rank[high] >= rank[low]


def test_pick_model_high_stakes_superworker_goes_opus():
    assert _pick_model(SUPERWORKER, high_stakes=True) == "opus"
    assert _pick_model(SUPERWORKER, high_stakes=False) == "sonnet"
    assert _pick_model(SPECIALIST, high_stakes=False) == "sonnet"
    assert _pick_model(TOOL_ACTION, high_stakes=False) == "haiku"


def test_stats_overlay_flips_on_sufficient_evidence():
    """Simulated stats: SPECIALIST n=50 q=0.9 beats SUPERWORKER n=50 q=0.6 → flip."""
    stats = {
        ("architecture_review", SUPERWORKER): (50, 0.60),
        ("architecture_review", SPECIALIST): (50, 0.90),
    }
    chosen, reason = _apply_stats_overlay("architecture_review", SUPERWORKER, stats)
    assert chosen == SPECIALIST
    assert reason is not None and "stats overlay" in reason


def test_stats_overlay_respects_sample_threshold():
    """n below threshold → no flip."""
    stats = {
        ("architecture_review", SUPERWORKER): (50, 0.60),
        ("architecture_review", SPECIALIST): (5, 0.99),  # too few samples
    }
    chosen, reason = _apply_stats_overlay("architecture_review", SUPERWORKER, stats)
    assert chosen == SUPERWORKER
    assert reason is None


def test_stats_overlay_respects_delta_threshold():
    """Delta below threshold → no flip even with enough samples."""
    stats = {
        ("architecture_review", SUPERWORKER): (50, 0.80),
        ("architecture_review", SPECIALIST): (50, 0.85),  # delta 0.05 < 0.10
    }
    chosen, reason = _apply_stats_overlay("architecture_review", SUPERWORKER, stats)
    assert chosen == SUPERWORKER
    assert reason is None


def test_list_shapes_for_task_type(temp_router_db):
    info = list_shapes_for_task_type("security_review")
    assert info["task_type"] == "security_review"
    assert info["default_shape"] == SPECIALIST
    assert info["default_agent_name"] == "Security Engineer"
    assert TOOL_ACTION in info["stats"]
    assert SPECIALIST in info["stats"]
    assert SUPERWORKER in info["stats"]
