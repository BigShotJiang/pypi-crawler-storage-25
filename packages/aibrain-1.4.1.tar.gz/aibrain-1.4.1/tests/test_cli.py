"""
Tests for AIBrain CLI commands: create, chat, tools, and tool registry.
"""

import os
import shutil
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

# Ensure project root is on path
AIBRAIN_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(AIBRAIN_ROOT))


# ---------------------------------------------------------------------------
# aibrain create
# ---------------------------------------------------------------------------

class TestCreateCommand:
    """Tests for `aibrain create <name>`."""

    def test_create_generates_correct_structure(self, tmp_path):
        """Scaffold creates all expected files and directories."""
        from aibrain.cli.create import create_project

        result = create_project("my_test_project", target_dir=str(tmp_path))
        assert result == 0

        project_dir = tmp_path / "my_test_project"
        assert project_dir.exists()

        # Check all expected files
        expected_files = [
            "config/agents.yaml",
            "config/tasks.yaml",
            "workflows/example.py",
            "flows/example.py",
            "brain_config.yaml",
            "main.py",
            "README.md",
        ]
        for rel in expected_files:
            f = project_dir / rel
            assert f.exists(), f"Missing: {rel}"
            assert f.stat().st_size > 0, f"Empty: {rel}"

    def test_create_templates_contain_project_name(self, tmp_path):
        """Templates are populated with the project name."""
        from aibrain.cli.create import create_project

        create_project("cool_project", target_dir=str(tmp_path))
        project_dir = tmp_path / "cool_project"

        main_py = (project_dir / "main.py").read_text()
        assert "cool_project" in main_py

        config = (project_dir / "brain_config.yaml").read_text()
        assert "cool_project" in config

    def test_create_refuses_existing_directory(self, tmp_path):
        """Create fails if the target directory already exists."""
        from aibrain.cli.create import create_project

        (tmp_path / "existing").mkdir()
        result = create_project("existing", target_dir=str(tmp_path))
        assert result == 1

    def test_create_no_name(self):
        """Create fails gracefully with no name."""
        from aibrain.cli.create import create_project
        result = create_project("")
        assert result == 1

    def test_create_flow_has_class(self, tmp_path):
        """Flow template contains a properly named Flow class."""
        from aibrain.cli.create import create_project

        create_project("data_pipeline", target_dir=str(tmp_path))
        flow = (tmp_path / "data_pipeline" / "flows" / "example.py").read_text()
        assert "DataPipelineFlow" in flow


# ---------------------------------------------------------------------------
# aibrain chat (mock stdin)
# ---------------------------------------------------------------------------

class TestChatCommand:
    """Tests for `aibrain chat` with mocked stdin."""

    @pytest.fixture(autouse=True)
    def _bypass_tier_limits(self, monkeypatch):
        try:
            import aibrain_licensing
            monkeypatch.setattr(aibrain_licensing, "check_limit", lambda *a, **kw: None)
        except (ImportError, AttributeError):
            pass

    def test_chat_exit_command(self, tmp_path):
        """Chat exits cleanly on 'quit'."""
        from aibrain.cli.chat import run_chat

        # Create a minimal DB
        db_path = str(tmp_path / "chat_test.db")
        _init_test_db(db_path)

        with patch("builtins.input", side_effect=["quit"]):
            result = run_chat(db_path=db_path)
        assert result == 0

    def test_chat_remember_command(self, tmp_path):
        """Chat stores memories via 'remember:' prefix."""
        from aibrain.cli.chat import run_chat

        db_path = str(tmp_path / "chat_test.db")
        _init_test_db(db_path)

        with patch("builtins.input", side_effect=["remember: I like Python", "exit"]):
            result = run_chat(db_path=db_path)
        assert result == 0

    def test_chat_search(self, tmp_path):
        """Chat searches memories on plain input."""
        from aibrain.cli.chat import run_chat

        db_path = str(tmp_path / "chat_test.db")
        _init_test_db(db_path)

        with patch("builtins.input", side_effect=["hello world", "quit"]):
            result = run_chat(db_path=db_path)
        assert result == 0

    def test_chat_ctrl_c_exits(self, tmp_path):
        """Chat exits cleanly on KeyboardInterrupt."""
        from aibrain.cli.chat import run_chat

        db_path = str(tmp_path / "chat_test.db")
        _init_test_db(db_path)

        with patch("builtins.input", side_effect=KeyboardInterrupt):
            result = run_chat(db_path=db_path)
        assert result == 0


# ---------------------------------------------------------------------------
# Tool registry
# ---------------------------------------------------------------------------

class TestToolRegistry:
    """Tests for the tool registry."""

    def test_registry_has_15_tools(self):
        """All 15 built-in tools are registered."""
        from aibrain.tools import BUILTIN_TOOLS
        assert len(BUILTIN_TOOLS) == 15

    def test_all_tools_instantiable(self):
        """Every tool can be instantiated and has required attributes."""
        from aibrain.tools import BUILTIN_TOOLS
        for name, tool in BUILTIN_TOOLS.items():
            assert tool.name == name, f"Tool name mismatch: {tool.name} != {name}"
            assert tool.description, f"Tool {name} has no description"
            assert callable(tool), f"Tool {name} is not callable"

    def test_get_tool(self):
        """get_tool returns correct tool or None."""
        from aibrain.tools import get_tool
        assert get_tool("calculator") is not None
        assert get_tool("nonexistent_tool") is None

    def test_list_tools(self):
        """list_tools returns all tool names."""
        from aibrain.tools import list_tools
        names = list_tools()
        assert len(names) == 15
        assert "read_file" in names
        assert "calculator" in names
        assert "memory_search" in names

    def test_tool_names_match_expected(self):
        """All expected tool names are present."""
        from aibrain.tools import list_tools
        expected = {
            "read_file", "write_file", "list_directory", "search_files",
            "web_search", "web_fetch", "shell", "python_repl",
            "memory_search", "memory_store", "json_parse", "csv_read",
            "calculator", "datetime", "text_summary",
        }
        actual = set(list_tools())
        assert expected == actual


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _init_test_db(db_path: str):
    """Create a minimal aibrain DB for testing."""
    import sqlite3
    db = sqlite3.connect(db_path)
    db.execute("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL DEFAULT '',
            type TEXT NOT NULL DEFAULT 'user',
            content TEXT NOT NULL DEFAULT '',
            tags TEXT DEFAULT '',
            importance INTEGER DEFAULT 5,
            access_count INTEGER DEFAULT 0,
            active INTEGER DEFAULT 1,
            user_id TEXT DEFAULT '',
            agent_id TEXT DEFAULT '',
            created TEXT DEFAULT CURRENT_TIMESTAMP,
            updated TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    db.execute("""
        CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts
        USING fts5(name, content, tags, content=memories, content_rowid=id)
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS memory_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            memory_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            old_content TEXT,
            new_content TEXT,
            changed_by TEXT,
            created_at TEXT NOT NULL
        )
    """)
    db.commit()
    db.close()
