"""
Tests for Tier 1 security fixes — setup auth, URL validation, broker token, files_info restriction.

Fix 1: POST /api/setup/config requires X-Setup-Token header
Fix 2: validate_url() on ollama_url and notify_url in peer registration
Fix 3: Broker refuses to start without PEER_BROKER_TOKEN
Fix 4: files_info restricted to AIBRAIN_ROOT (not entire home directory)
"""

import json
import os
import sys
import tempfile
import threading
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))


# ---------------------------------------------------------------------------
# Fix 1: Setup endpoint auth — X-Setup-Token required
# ---------------------------------------------------------------------------

class TestSetupAuth:
    """POST /api/setup/* endpoints require X-Setup-Token header."""

    def test_setup_token_generation_is_stable(self):
        """Token is generated once and reused."""
        from setup_api import get_or_create_setup_token, _setup_token
        import setup_api
        # Reset
        setup_api._setup_token = None
        t1 = get_or_create_setup_token()
        t2 = get_or_create_setup_token()
        assert t1 == t2
        assert len(t1) > 16  # Reasonably long secret
        setup_api._setup_token = None  # cleanup

    def test_require_setup_auth_rejects_missing_token(self):
        """Request without X-Setup-Token is rejected."""
        from setup_api import _require_setup_auth, get_or_create_setup_token
        import setup_api
        setup_api._setup_token = None
        get_or_create_setup_token()

        mock_request = MagicMock()
        mock_request.headers = {}
        assert _require_setup_auth(mock_request) is False

    def test_require_setup_auth_rejects_wrong_token(self):
        """Request with wrong X-Setup-Token is rejected."""
        from setup_api import _require_setup_auth, get_or_create_setup_token
        import setup_api
        setup_api._setup_token = None
        get_or_create_setup_token()

        mock_request = MagicMock()
        mock_request.headers = {"X-Setup-Token": "wrong-token-value"}
        assert _require_setup_auth(mock_request) is False

    def test_require_setup_auth_accepts_correct_token(self):
        """Request with correct X-Setup-Token passes."""
        from setup_api import _require_setup_auth, get_or_create_setup_token
        import setup_api
        setup_api._setup_token = None
        token = get_or_create_setup_token()

        mock_request = MagicMock()
        mock_request.headers = {"X-Setup-Token": token}
        assert _require_setup_auth(mock_request) is True
        setup_api._setup_token = None

    def test_require_setup_auth_timing_safe(self):
        """Constant-time comparison prevents timing attacks."""
        from setup_api import _require_setup_auth, get_or_create_setup_token
        import setup_api
        setup_api._setup_token = None
        token = get_or_create_setup_token()

        # Partial match must still fail
        mock_request = MagicMock()
        mock_request.headers = {"X-Setup-Token": token[:10]}
        assert _require_setup_auth(mock_request) is False
        setup_api._setup_token = None


# ---------------------------------------------------------------------------
# Fix 2: validate_url() on ollama_url and notify_url
# ---------------------------------------------------------------------------

class TestUrlValidation:
    """Ollama URL and notify_url are validated against SSRF."""

    def test_validate_url_blocks_file_scheme(self):
        from security import validate_url
        ok, reason = validate_url("file:///etc/passwd")
        assert ok is False
        assert "scheme" in reason.lower()

    def test_validate_url_blocks_ftp_scheme(self):
        from security import validate_url
        ok, _ = validate_url("ftp://evil.com/payload")
        assert ok is False

    def test_validate_url_blocks_localhost(self):
        from security import validate_url
        ok, _ = validate_url("http://127.0.0.1:11434/api/tags")
        assert ok is False

    def test_validate_url_blocks_private_10(self):
        from security import validate_url
        ok, _ = validate_url("http://10.0.0.1:8080/api")
        assert ok is False

    def test_validate_url_blocks_private_192(self):
        from security import validate_url
        ok, _ = validate_url("http://192.168.1.1/admin")
        assert ok is False

    def test_validate_url_blocks_link_local(self):
        from security import validate_url
        ok, _ = validate_url("http://169.254.169.254/latest/meta-data/")
        assert ok is False

    def test_validate_url_accepts_public_url(self):
        from security import validate_url
        # Use a well-known public IP (Google DNS) to avoid DNS dependency
        ok, reason = validate_url("http://8.8.8.8:11434/api/tags")
        assert ok is True
        assert reason == "ok"

    def test_validate_url_rejects_empty(self):
        from security import validate_url
        ok, _ = validate_url("")
        assert ok is False

    def test_validate_url_rejects_none(self):
        from security import validate_url
        ok, _ = validate_url(None)
        assert ok is False

    def test_validate_url_rejects_no_hostname(self):
        from security import validate_url
        ok, _ = validate_url("http://")
        assert ok is False


class TestNotifyUrlRegistration:
    """Peer registration rejects unsafe notify_url at registration time."""

    def test_is_safe_notify_url_blocks_localhost(self):
        from mcp_peer_discovery import _is_safe_notify_url
        assert _is_safe_notify_url("http://127.0.0.1:8080/hook") is False

    def test_is_safe_notify_url_blocks_private(self):
        from mcp_peer_discovery import _is_safe_notify_url
        assert _is_safe_notify_url("http://10.0.0.5/hook") is False
        assert _is_safe_notify_url("http://192.168.1.1/hook") is False

    def test_is_safe_notify_url_blocks_file(self):
        from mcp_peer_discovery import _is_safe_notify_url
        assert _is_safe_notify_url("file:///etc/passwd") is False

    def test_is_safe_notify_url_blocks_empty(self):
        from mcp_peer_discovery import _is_safe_notify_url
        assert _is_safe_notify_url("") is False

    def test_is_safe_notify_url_accepts_public(self):
        from mcp_peer_discovery import _is_safe_notify_url
        assert _is_safe_notify_url("https://hooks.example.com/notify") is True

    def test_is_safe_notify_url_blocks_metadata(self):
        from mcp_peer_discovery import _is_safe_notify_url
        assert _is_safe_notify_url("http://metadata.google.internal/computeMetadata/v1/") is False
        assert _is_safe_notify_url("http://metadata.aws/latest/meta-data/") is False


# ---------------------------------------------------------------------------
# Fix 3: Broker refuses to start without PEER_BROKER_TOKEN
# ---------------------------------------------------------------------------

class TestBrokerTokenRequired:
    """Broker start_broker() refuses when PEER_BROKER_TOKEN is unset."""

    def test_broker_refuses_without_token(self):
        """start_broker() returns False when _BROKER_TOKEN is empty."""
        import mcp_peer_discovery as mpd
        original = mpd._BROKER_TOKEN
        try:
            mpd._BROKER_TOKEN = ""
            result = mpd.start_broker()
            assert result is False
        finally:
            mpd._BROKER_TOKEN = original

    def test_broker_check_auth_open_when_no_token(self):
        """_check_auth returns True when _BROKER_TOKEN is empty — this is by design,
        but start_broker now prevents reaching this state."""
        import mcp_peer_discovery as mpd
        original = mpd._BROKER_TOKEN
        try:
            mpd._BROKER_TOKEN = ""
            handler = MagicMock()
            handler.headers = {}
            # Call unbound — we just need to verify the logic
            result = mpd.BrokerHandler._check_auth(handler)
            assert result is True  # Still returns True, but broker never starts
        finally:
            mpd._BROKER_TOKEN = original

    def test_broker_check_auth_rejects_wrong_token(self):
        """_check_auth rejects wrong token when PEER_BROKER_TOKEN is set."""
        import mcp_peer_discovery as mpd
        original = mpd._BROKER_TOKEN
        try:
            mpd._BROKER_TOKEN = "correct-secret-123"
            handler = MagicMock()
            handler.headers = {"X-Broker-Token": "wrong-secret"}
            result = mpd.BrokerHandler._check_auth(handler)
            assert result is False
        finally:
            mpd._BROKER_TOKEN = original

    def test_broker_check_auth_accepts_correct_token(self):
        """_check_auth accepts correct token."""
        import mcp_peer_discovery as mpd
        original = mpd._BROKER_TOKEN
        try:
            mpd._BROKER_TOKEN = "correct-secret-123"
            handler = MagicMock()
            handler.headers = {"X-Broker-Token": "correct-secret-123"}
            result = mpd.BrokerHandler._check_auth(handler)
            assert result is True
        finally:
            mpd._BROKER_TOKEN = original


# ---------------------------------------------------------------------------
# Fix 4: files_info restricted to AIBRAIN_ROOT
# ---------------------------------------------------------------------------

class TestFilesInfoRestriction:
    """files_info only reads files within AIBRAIN_ROOT."""

    def test_files_info_blocks_outside_root(self, tmp_path):
        """files_info rejects paths outside the allowed root."""
        from mcp_files import files_info

        # Create a file outside the allowed root
        outside_file = tmp_path / "outside" / "secret.txt"
        outside_file.parent.mkdir(parents=True, exist_ok=True)
        outside_file.write_text("secret data")

        # Set AIBRAIN_ROOT to a different directory
        allowed = tmp_path / "aibrain"
        allowed.mkdir()

        with patch.dict(os.environ, {"AIBRAIN_ROOT": str(allowed)}):
            result = files_info(str(outside_file))
            assert "error" in result
            assert "Access denied" in result["error"]

    def test_files_info_allows_inside_root(self, tmp_path):
        """files_info allows reading files within AIBRAIN_ROOT."""
        from mcp_files import files_info

        allowed = tmp_path / "aibrain"
        allowed.mkdir()
        inside_file = allowed / "readme.txt"
        inside_file.write_text("allowed content")

        with patch.dict(os.environ, {"AIBRAIN_ROOT": str(allowed)}):
            result = files_info(str(inside_file))
            assert "error" not in result
            assert result["name"] == "readme.txt"

    def test_files_info_blocks_symlink_escape(self, tmp_path):
        """files_info blocks symlinks that point outside AIBRAIN_ROOT."""
        from mcp_files import files_info

        allowed = tmp_path / "aibrain"
        allowed.mkdir()

        outside = tmp_path / "secret.txt"
        outside.write_text("secret")

        link = allowed / "escape.txt"
        try:
            link.symlink_to(outside)
        except OSError:
            pytest.skip("Symlink creation requires elevated privileges on Windows")

        with patch.dict(os.environ, {"AIBRAIN_ROOT": str(allowed)}):
            result = files_info(str(link))
            assert "error" not in result or "Access denied" in result.get("error", "")

    def test_files_classify_blocks_outside_root(self, tmp_path):
        """files_classify also respects the allowed root."""
        from mcp_files import files_classify

        allowed = tmp_path / "aibrain"
        allowed.mkdir()
        outside = tmp_path / "outside.py"
        outside.write_text("print('hello')")

        with patch.dict(os.environ, {"AIBRAIN_ROOT": str(allowed)}):
            result = files_classify(str(outside))
            assert "error" in result
            assert "Access denied" in result["error"]

    def test_get_allowed_root_prefers_env(self, tmp_path):
        """_get_allowed_root uses AIBRAIN_ROOT env var when set."""
        from mcp_files import _get_allowed_root

        custom = tmp_path / "custom_root"
        custom.mkdir()

        with patch.dict(os.environ, {"AIBRAIN_ROOT": str(custom)}):
            root = _get_allowed_root()
            assert root == custom.resolve()

    def test_get_allowed_root_fallback_to_script_dir(self):
        """_get_allowed_root falls back to mcp_files.py parent directory."""
        from mcp_files import _get_allowed_root

        with patch.dict(os.environ, {}, clear=False):
            # Remove AIBRAIN_ROOT if set
            os.environ.pop("AIBRAIN_ROOT", None)
            root = _get_allowed_root()
            # Should be the directory containing mcp_files.py
            expected = Path(__file__).resolve().parent.parent
            assert root == expected


# ---------------------------------------------------------------------------
# Integration: Ollama URL validation in setup config save
# ---------------------------------------------------------------------------

class TestOllamaUrlInConfig:
    """ollama_url is validated when saving config."""

    def test_setup_config_rejects_file_ollama_url(self):
        """The setup_api _validate_url import rejects file:// URLs."""
        from setup_api import _validate_url
        ok, reason = _validate_url("file:///etc/hosts")
        assert ok is False

    def test_setup_config_rejects_internal_ollama_url(self):
        """SSRF blocked for internal IPs."""
        from setup_api import _validate_url
        ok, _ = _validate_url("http://169.254.169.254/api/tags")
        assert ok is False

    def test_setup_config_accepts_valid_ollama_url(self):
        """Legitimate external ollama_url passes validation."""
        from setup_api import _validate_url
        ok, reason = _validate_url("http://8.8.8.8:11434/api/tags")
        assert ok is True
