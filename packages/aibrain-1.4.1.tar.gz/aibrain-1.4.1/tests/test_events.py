"""
Tests for aibrain/core/events.py — Centralized event catalog and emission.

Covers: Events constants are strings, ALL_EVENT_TYPES completeness,
        emit() function works, PatternBus receives emitted events.
"""

import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.events import Events, ALL_EVENT_TYPES, emit


# ---------------------------------------------------------------------------
# Event type constants
# ---------------------------------------------------------------------------

class TestEventConstants:
    def test_all_event_types_are_strings(self):
        for name in dir(Events):
            if name.startswith("_"):
                continue
            val = getattr(Events, name)
            assert isinstance(val, str), f"Events.{name} is {type(val)}, expected str"

    def test_event_types_use_dot_notation(self):
        for name in dir(Events):
            if name.startswith("_"):
                continue
            val = getattr(Events, name)
            assert "." in val, f"Events.{name} = {val!r} should use dot notation"

    def test_all_event_types_set_matches_class(self):
        class_events = {
            getattr(Events, name)
            for name in dir(Events)
            if not name.startswith("_") and isinstance(getattr(Events, name), str)
        }
        assert class_events == ALL_EVENT_TYPES

    def test_no_duplicate_event_types(self):
        values = [
            getattr(Events, name)
            for name in dir(Events)
            if not name.startswith("_") and isinstance(getattr(Events, name), str)
        ]
        assert len(values) == len(set(values)), "Duplicate event type values found"

    def test_expected_event_types_present(self):
        expected = [
            "agent.start", "agent.complete", "agent.error",
            "task.start", "task.complete", "task.guardrail_fail", "task.guardrail_pass",
            "team.kickoff", "team.complete", "team.error",
            "flow.start", "flow.step", "flow.router", "flow.complete", "flow.error",
            "flow.hitl_pending", "flow.hitl_resumed",
            "mcp.connect", "mcp.disconnect", "mcp.tool_call", "mcp.tool_error", "mcp.tool_cached",
            "ingest.start", "ingest.progress", "ingest.complete", "ingest.error", "ingest.skipped",
            "memory.store", "memory.search", "memory.forget",
            "hook.before_tool", "hook.after_tool", "hook.before_llm", "hook.after_llm",
            "hook.blocked",
        ]
        for evt in expected:
            assert evt in ALL_EVENT_TYPES, f"Missing event type: {evt}"

    def test_minimum_event_count(self):
        # Sanity check: we should have at least 30 event types
        assert len(ALL_EVENT_TYPES) >= 30


# ---------------------------------------------------------------------------
# emit() function
# ---------------------------------------------------------------------------

class TestEmit:
    def test_emit_calls_pattern_bus(self):
        mock_bus = MagicMock()
        mock_event_cls = MagicMock()

        with patch("aibrain.core.events.PatternBus", return_value=mock_bus, create=True) as mock_pb_cls, \
             patch.dict("sys.modules", {"backend.event_schema": MagicMock(
                 PatternBus=mock_pb_cls,
                 DomainEvent=mock_event_cls,
             )}):
            # Re-import to pick up the mock
            import importlib
            import aibrain.core.events as events_mod
            importlib.reload(events_mod)

            events_mod.emit("task.start", "task-123", agent="Researcher")

            # PatternBus was instantiated
            mock_pb_cls.assert_called_once()
            # emit was called on the bus
            mock_bus.emit.assert_called_once()
            # DomainEvent was constructed
            mock_event_cls.assert_called_once()

            # Check the DomainEvent kwargs
            call_kwargs = mock_event_cls.call_args
            assert call_kwargs.kwargs["event_type"] == "task.start"
            assert call_kwargs.kwargs["key"] == "task-123"
            assert call_kwargs.kwargs["domain"] == "aibrain"
            assert call_kwargs.kwargs["metadata"] == {"agent": "Researcher"}

    def test_emit_never_raises(self):
        """emit() is fire-and-forget — exceptions are swallowed."""
        with patch.dict("sys.modules", {"backend.event_schema": None}):
            # Should not raise even when backend is unavailable
            import importlib
            import aibrain.core.events as events_mod
            importlib.reload(events_mod)

            # This should silently fail, not raise
            try:
                events_mod.emit("task.start", "key-1")
            except Exception:
                pytest.fail("emit() should never raise")

    def test_emit_with_real_pattern_bus(self):
        """Integration test: emit through real PatternBus to temp SQLite."""
        fd, db_path = tempfile.mkstemp(suffix=".db", prefix="aibrain_test_events_")
        os.close(fd)

        try:
            # Use real PatternBus with temp DB
            from backend.event_schema import PatternBus, DomainEvent

            bus = PatternBus(db_path=db_path)

            # Manually emit (since emit() constructs its own bus)
            bus.emit(DomainEvent(
                domain="test",
                source_agent="test_runner",
                event_type=Events.TASK_START,
                key="test-task-1",
                metadata={"hello": "world"},
            ))

            # Verify it was stored
            recent = bus.get_recent(limit=10, domain="test")
            assert len(recent) == 1
            assert recent[0]["event_type"] == "task.start"
            assert recent[0]["key"] == "test-task-1"
        except ImportError:
            pytest.skip("backend.event_schema not importable in this environment")
        finally:
            try:
                os.unlink(db_path)
            except OSError:
                pass
            for ext in ("-wal", "-shm"):
                try:
                    os.unlink(db_path + ext)
                except OSError:
                    pass

    def test_emit_default_domain(self):
        mock_bus = MagicMock()
        mock_event_cls = MagicMock()
        mock_pb_cls = MagicMock(return_value=mock_bus)

        with patch.dict("sys.modules", {"backend.event_schema": MagicMock(
            PatternBus=mock_pb_cls,
            DomainEvent=mock_event_cls,
        )}):
            import importlib
            import aibrain.core.events as events_mod
            importlib.reload(events_mod)

            events_mod.emit("agent.start", "agent-1")
            call_kwargs = mock_event_cls.call_args.kwargs
            assert call_kwargs["domain"] == "aibrain"

    def test_emit_custom_domain_and_source(self):
        mock_bus = MagicMock()
        mock_event_cls = MagicMock()
        mock_pb_cls = MagicMock(return_value=mock_bus)

        with patch.dict("sys.modules", {"backend.event_schema": MagicMock(
            PatternBus=mock_pb_cls,
            DomainEvent=mock_event_cls,
        )}):
            import importlib
            import aibrain.core.events as events_mod
            importlib.reload(events_mod)

            events_mod.emit("mcp.connect", "github", domain="mcp", source_agent="mcp_client")
            call_kwargs = mock_event_cls.call_args.kwargs
            assert call_kwargs["domain"] == "mcp"
            assert call_kwargs["source_agent"] == "mcp_client"
