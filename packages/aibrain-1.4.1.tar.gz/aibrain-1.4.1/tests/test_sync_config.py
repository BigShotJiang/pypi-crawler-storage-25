"""
Tests for aibrain.tools.sync.config — brain sync configuration menu.

Covers: defaults, save/load round-trip, direction validation, table toggles,
non-tty fallback, cache invalidation, partial config, TOML parsing,
render structure, malformed TOML fallback, status helper.
"""
from __future__ import annotations

import io
import sys
from pathlib import Path
from unittest import mock

import pytest


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def isolate_config(tmp_path, monkeypatch):
    """Redirect sync.toml to a temp dir so tests don't touch real config."""
    fake_path = tmp_path / 'sync.toml'
    import aibrain.tools.sync.config as mod
    monkeypatch.setattr(mod, '_CONFIG_PATH', fake_path)
    mod._invalidate_cache()
    yield fake_path
    mod._invalidate_cache()


# ---------------------------------------------------------------------------
# 1. Defaults when no config file exists
# ---------------------------------------------------------------------------

def test_defaults_no_file(isolate_config):
    """load_sync_config returns hardcoded defaults when sync.toml is absent."""
    from aibrain.tools.sync.config import load_sync_config, _invalidate_cache
    _invalidate_cache()
    cfg = load_sync_config()

    assert cfg['direction'] == 'both'
    assert cfg['path'] == '/tmp/brain_sync.json'
    assert all(v is True for v in cfg['tables'].values())
    assert len(cfg['tables']) == 7


# ---------------------------------------------------------------------------
# 2. Save and reload round-trip
# ---------------------------------------------------------------------------

def test_save_load_roundtrip(isolate_config):
    """Saved config is faithfully reloaded."""
    from aibrain.tools.sync.config import _save_config, load_sync_config, _invalidate_cache

    _save_config(
        direction='push',
        tables={
            'memories': True, 'company': False, 'skills': True,
            'workflows': True, 'config': False, 'evolution': True,
            'knowledge_graph': True,
        },
        sync_path='/home/user/my_sync.json',
    )
    _invalidate_cache()
    cfg = load_sync_config()

    assert cfg['direction'] == 'push'
    assert cfg['path'] == '/home/user/my_sync.json'
    assert cfg['tables']['company'] is False
    assert cfg['tables']['config'] is False
    assert cfg['tables']['memories'] is True
    assert cfg['tables']['skills'] is True


# ---------------------------------------------------------------------------
# 3. Invalid direction falls back to default
# ---------------------------------------------------------------------------

def test_invalid_direction_fallback(isolate_config):
    """An invalid direction value in config falls back to 'both'."""
    from aibrain.tools.sync.config import _invalidate_cache, load_sync_config, _write_toml, _CONFIG_PATH

    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_PATH.write_text(
        '[sync]\ndirection = "invalid_direction"\n',
        encoding='utf-8',
    )
    _invalidate_cache()
    cfg = load_sync_config()

    assert cfg['direction'] == 'both'


# ---------------------------------------------------------------------------
# 4. Non-tty fallback prints key=value
# ---------------------------------------------------------------------------

def test_non_tty_fallback(isolate_config):
    """When stdout is not a tty, interactive_menu prints plain key=value lines."""
    from aibrain.tools.sync.config import interactive_menu

    buf = io.StringIO()
    with mock.patch.object(sys, 'stdout', buf):
        interactive_menu()

    output = buf.getvalue()
    assert 'direction=both' in output
    assert 'path=/tmp/brain_sync.json' in output
    assert 'tables.memories=enabled' in output
    assert 'tables.company=enabled' in output


# ---------------------------------------------------------------------------
# 5. Non-tty fallback reflects saved config
# ---------------------------------------------------------------------------

def test_non_tty_reflects_saved(isolate_config):
    """Non-tty output reflects persisted config, not just defaults."""
    from aibrain.tools.sync.config import _save_config, _invalidate_cache, interactive_menu

    _save_config(
        direction='pull',
        tables={
            'memories': True, 'company': False, 'skills': True,
            'workflows': True, 'config': True, 'evolution': True,
            'knowledge_graph': False,
        },
        sync_path='/custom/path.json',
    )
    _invalidate_cache()

    buf = io.StringIO()
    with mock.patch.object(sys, 'stdout', buf):
        interactive_menu()

    output = buf.getvalue()
    assert 'direction=pull' in output
    assert 'path=/custom/path.json' in output
    assert 'tables.company=disabled' in output
    assert 'tables.knowledge_graph=disabled' in output


# ---------------------------------------------------------------------------
# 6. Cache invalidation
# ---------------------------------------------------------------------------

def test_cache_invalidation(isolate_config):
    """After _invalidate_cache, load picks up new file contents."""
    from aibrain.tools.sync.config import load_sync_config, _save_config, _invalidate_cache

    cfg1 = load_sync_config()
    assert cfg1['direction'] == 'both'

    _save_config(direction='push', tables=cfg1['tables'], sync_path=cfg1['path'])
    _invalidate_cache()
    cfg2 = load_sync_config()
    assert cfg2['direction'] == 'push'


# ---------------------------------------------------------------------------
# 7. TOML parsing handles all value types
# ---------------------------------------------------------------------------

def test_toml_parsing(isolate_config):
    """Minimal TOML parser handles bool, string correctly for sync config."""
    from aibrain.tools.sync.config import _parse_toml_minimal

    toml_text = """
[sync]
direction = "pull"
path = "/my/path.json"

[sync.tables]
memories = true
company = false
skills = true
workflows = false
config = true
evolution = true
knowledge_graph = false
"""
    result = _parse_toml_minimal(toml_text)
    assert result['sync']['direction'] == 'pull'
    assert result['sync']['path'] == '/my/path.json'
    assert result['sync']['tables']['company'] is False
    assert result['sync']['tables']['knowledge_graph'] is False
    assert result['sync']['tables']['memories'] is True


# ---------------------------------------------------------------------------
# 8. Menu rendering contains expected structure
# ---------------------------------------------------------------------------

def test_render_menu_structure():
    """_render_menu produces expected labels and structure."""
    from aibrain.tools.sync.config import _render_menu, _TABLE_DEFAULTS

    output = _render_menu(
        direction='both',
        tables=dict(_TABLE_DEFAULTS),
        sync_path='/tmp/brain_sync.json',
        focused=0,
    )

    assert 'Brain Sync Config' in output
    assert 'Sync direction:' in output
    assert 'Push + Pull' in output
    assert 'Push only' in output
    assert 'Pull only' in output
    assert 'Tables to sync:' in output
    assert 'Memories' in output
    assert 'Knowledge graph' in output
    assert 'Sync path' in output
    assert '/tmp/brain_sync.json' in output
    assert 'ENTER to save' in output
    # First item (Push + Pull) should be focused and selected
    assert '> (x) 1. Push + Pull' in output


# ---------------------------------------------------------------------------
# 9. Partial config file — missing keys use defaults
# ---------------------------------------------------------------------------

def test_partial_config(isolate_config):
    """A sync.toml with only some keys still fills in defaults for the rest."""
    from aibrain.tools.sync.config import load_sync_config, _invalidate_cache

    isolate_config.parent.mkdir(parents=True, exist_ok=True)
    isolate_config.write_text(
        '[sync]\ndirection = "push"\n',
        encoding='utf-8',
    )
    _invalidate_cache()
    cfg = load_sync_config()

    assert cfg['direction'] == 'push'
    assert cfg['path'] == '/tmp/brain_sync.json'  # default
    assert cfg['tables']['memories'] is True       # default
    assert cfg['tables']['evolution'] is True      # default


# ---------------------------------------------------------------------------
# 10. Malformed TOML falls back to defaults
# ---------------------------------------------------------------------------

def test_malformed_toml_fallback(isolate_config):
    """Corrupted sync.toml is handled gracefully — defaults used."""
    from aibrain.tools.sync.config import load_sync_config, _invalidate_cache

    isolate_config.parent.mkdir(parents=True, exist_ok=True)
    isolate_config.write_text('{{{{not valid toml!!!!', encoding='utf-8')
    _invalidate_cache()

    cfg = load_sync_config()
    assert cfg['direction'] == 'both'
    assert cfg['tables']['memories'] is True


# ---------------------------------------------------------------------------
# 11. Status helper returns expected format
# ---------------------------------------------------------------------------

def test_status_helper_default(isolate_config):
    """get_sync_status returns correct format with defaults."""
    from aibrain.tools.sync.config import get_sync_status

    status = get_sync_status()
    assert status == 'push+pull, 7/7 tables'


def test_status_helper_with_config(isolate_config):
    """get_sync_status reflects saved config."""
    from aibrain.tools.sync.config import _save_config, get_sync_status

    _save_config(
        direction='push',
        tables={
            'memories': True, 'company': False, 'skills': True,
            'workflows': True, 'config': True, 'evolution': False,
            'knowledge_graph': True,
        },
        sync_path='/tmp/test.json',
    )

    status = get_sync_status()
    assert status == 'push, 5/7 tables'
