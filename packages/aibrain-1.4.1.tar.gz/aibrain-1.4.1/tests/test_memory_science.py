"""
Tests for neuroscience-based memory improvements:
1. Dual-Strength Model (Bjork & Bjork 1992) — storage_strength + retrieval_strength
2. Prediction Error Gating — contradiction detection + 4-zone dedup
"""

import os
import sqlite3
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture()
def db_conn():
    """Create a fresh, isolated SQLite DB with the full AIBrain schema."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="aibrain_scitest_")
    os.close(fd)

    import aibrain_db
    original_path = aibrain_db.DB_PATH
    original_conn = aibrain_db._conn

    aibrain_db.DB_PATH = Path(path)
    aibrain_db._conn = None  # Force fresh connection

    conn = aibrain_db.get_db()

    yield conn

    # Restore original state
    try:
        conn.close()
    except Exception:
        pass
    aibrain_db._conn = original_conn
    aibrain_db.DB_PATH = original_path

    try:
        os.unlink(path)
    except OSError:
        pass
    for ext in ("-wal", "-shm"):
        try:
            os.unlink(path + ext)
        except OSError:
            pass


# =========================================================================
# 1. Dual-Strength Model tests
# =========================================================================

class TestDualStrengthSchema:
    """storage_strength column exists after migration."""

    def test_storage_strength_column_exists(self, db_conn):
        """storage_strength column is present in the memories table."""
        cols = {r[1] for r in db_conn.execute("PRAGMA table_info(memories)").fetchall()}
        assert "storage_strength" in cols

    def test_storage_strength_default_value(self, db_conn):
        """New memories get storage_strength = 1.0 by default."""
        db_conn.execute(
            "INSERT INTO memories (name, type, content, active) "
            "VALUES ('test_default', 'project', 'default ss test', 1)"
        )
        db_conn.commit()
        row = db_conn.execute(
            "SELECT storage_strength FROM memories WHERE name = 'test_default'"
        ).fetchone()
        assert row is not None
        assert row[0] == 1.0


class TestStorageStrengthIncrement:
    """storage_strength increments on search hit."""

    def test_storage_strength_increments_on_access(self, db_conn):
        """Simulating a search hit increments storage_strength by 0.1."""
        db_conn.execute(
            "INSERT INTO memories (name, type, content, storage_strength, active) "
            "VALUES ('test_inc', 'project', 'increment test', 1.0, 1)"
        )
        db_conn.commit()
        mem_id = db_conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Simulate what search does: increment storage_strength
        db_conn.execute(
            "UPDATE memories SET storage_strength = MIN(COALESCE(storage_strength, 1.0) + 0.1, 100.0) "
            "WHERE id = ?",
            (mem_id,),
        )
        db_conn.commit()

        row = db_conn.execute(
            "SELECT storage_strength FROM memories WHERE id = ?", (mem_id,)
        ).fetchone()
        assert abs(row[0] - 1.1) < 0.001

    def test_storage_strength_caps_at_100(self, db_conn):
        """storage_strength cannot exceed 100.0."""
        db_conn.execute(
            "INSERT INTO memories (name, type, content, storage_strength, active) "
            "VALUES ('test_cap', 'project', 'cap test', 99.95, 1)"
        )
        db_conn.commit()
        mem_id = db_conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        db_conn.execute(
            "UPDATE memories SET storage_strength = MIN(COALESCE(storage_strength, 1.0) + 0.1, 100.0) "
            "WHERE id = ?",
            (mem_id,),
        )
        db_conn.commit()

        row = db_conn.execute(
            "SELECT storage_strength FROM memories WHERE id = ?", (mem_id,)
        ).fetchone()
        assert row[0] == 100.0


class TestDualRetentionFormula:
    """Dual-strength retention formula combines retrieval and storage correctly."""

    def test_high_storage_low_retrieval_nonzero(self):
        """A memory accessed 50+ times but not touched for 6 months retains > 0."""
        import aibrain_db

        from datetime import datetime, timedelta
        six_months_ago = (datetime.now() - timedelta(days=180)).strftime("%Y-%m-%d %H:%M:%S")

        _, breakdown = aibrain_db._salience_score(
            fts_score=0.0, vec_score=0.0, importance=0.5,
            access_count=50, updated_at=six_months_ago,
            storage_strength=6.0,
        )

        # retention > 0 because storage component contributes 0.3 * min(6.0/10, 1.0) = 0.18
        assert breakdown["retention"] > 0.0
        assert breakdown["retention"] >= 0.15

    def test_low_storage_low_retrieval_much_lower(self):
        """A memory with low storage and old timestamp has much lower retention
        than a fresh memory with high storage strength."""
        import aibrain_db

        from datetime import datetime, timedelta
        old = (datetime.now() - timedelta(days=730)).strftime("%Y-%m-%d %H:%M:%S")
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        _, old_breakdown = aibrain_db._salience_score(
            fts_score=0.0, vec_score=0.0, importance=0.5,
            access_count=0, updated_at=old,
            storage_strength=1.0,
        )
        _, fresh_breakdown = aibrain_db._salience_score(
            fts_score=0.0, vec_score=0.0, importance=0.5,
            access_count=50, updated_at=now,
            storage_strength=10.0,
        )

        # Old+low-storage memory has significantly less retention than fresh+high-storage
        assert old_breakdown["retention"] < fresh_breakdown["retention"]
        # The storage component for low storage is only 0.03 (0.3 * 0.1)
        assert old_breakdown["storage_strength"] == 1.0

    def test_fresh_memory_high_retention(self):
        """A just-created memory has high retention."""
        import aibrain_db

        from datetime import datetime
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        _, breakdown = aibrain_db._salience_score(
            fts_score=0.0, vec_score=0.0, importance=0.5,
            access_count=0, updated_at=now,
            storage_strength=1.0,
        )

        # retrieval ~ 1.0 for just-created, storage = 0.1
        # retention ~ 0.7 * 1.0 + 0.3 * 0.1 = 0.73
        assert breakdown["retention"] > 0.5


# =========================================================================
# 2. Prediction Error Gating tests
# =========================================================================

class TestContradictionDetection:
    """Contradiction detection heuristic."""

    def test_detects_actually(self):
        """'actually' is a contradiction signal."""
        import aibrain_db
        assert aibrain_db._detect_contradiction(
            "Actually the server is in Sydney", "The server is in Melbourne"
        ) is True

    def test_detects_was_wrong(self):
        """'was wrong' is a contradiction signal."""
        import aibrain_db
        assert aibrain_db._detect_contradiction(
            "I was wrong about the port number", "The port is 8080"
        ) is True

    def test_detects_no_longer(self):
        """'no longer' is a contradiction signal."""
        import aibrain_db
        assert aibrain_db._detect_contradiction(
            "We no longer use Redis", "We use Redis for caching"
        ) is True

    def test_detects_changed(self):
        """'changed' is a contradiction signal."""
        import aibrain_db
        assert aibrain_db._detect_contradiction(
            "The API endpoint changed to /v2", "The API endpoint is /v1"
        ) is True

    def test_no_false_positive_normal_text(self):
        """Normal text without contradiction signals should not trigger."""
        import aibrain_db
        assert aibrain_db._detect_contradiction(
            "The database uses PostgreSQL for persistence",
            "We store data in a relational database"
        ) is False

    def test_no_false_positive_similar_content(self):
        """Similar content without contradiction words should not trigger."""
        import aibrain_db
        assert aibrain_db._detect_contradiction(
            "Python 3.11 is the runtime environment",
            "Python is the primary language"
        ) is False


class TestPredictionErrorGating:
    """Prediction error zones return correct actions."""

    def test_vec_dedup_has_correct_signature(self):
        """_vec_dedup accepts new_content and supersede_threshold params."""
        import aibrain_db
        import inspect
        sig = inspect.signature(aibrain_db._vec_dedup)
        params = list(sig.parameters.keys())
        assert "new_content" in params
        assert "threshold" in params
        assert "supersede_threshold" in params

    def test_canonical_dedup_returns_none_for_no_match(self):
        """canonical_dedup returns None when no match found (create new)."""
        import aibrain_db

        old_enabled = aibrain_db._db_vec_enabled
        aibrain_db._db_vec_enabled = False
        try:
            result = aibrain_db.canonical_dedup("completely unique content xyz123")
            assert result is None
        finally:
            aibrain_db._db_vec_enabled = old_enabled

    def test_reinforce_action_format(self):
        """Reinforce action has correct keys."""
        result = {"action": "reinforce", "id": 1, "similarity": 0.95, "message": "test"}
        assert result["action"] == "reinforce"
        assert "id" in result
        assert result["similarity"] >= 0.92

    def test_merge_action_format(self):
        """Merge action has correct keys."""
        result = {"action": "merge", "id": 1, "similarity": 0.85, "message": "test"}
        assert result["action"] == "merge"
        assert "id" in result
        assert 0.75 <= result["similarity"] < 0.92

    def test_supersede_action_format(self):
        """Supersede action has old_id key."""
        result = {"action": "supersede", "old_id": 1, "similarity": 0.80, "message": "test"}
        assert result["action"] == "supersede"
        assert "old_id" in result
        assert 0.70 <= result["similarity"] < 0.92

    def test_create_below_threshold(self):
        """Below all thresholds, canonical_dedup returns None (create new)."""
        import aibrain_db

        old_enabled = aibrain_db._db_vec_enabled
        aibrain_db._db_vec_enabled = False
        try:
            result = aibrain_db.canonical_dedup(
                "totally novel content that matches nothing abc999"
            )
            assert result is None  # None means create new
        finally:
            aibrain_db._db_vec_enabled = old_enabled


class TestPredictionErrorIntegration:
    """Integration tests for the full prediction error gating pipeline."""

    def test_contradiction_signals_comprehensive(self):
        """All defined contradiction signals are detected."""
        import aibrain_db
        for signal in aibrain_db.CONTRADICTION_SIGNALS:
            content = f"Test content with {signal} in it"
            assert aibrain_db._detect_contradiction(content, "old content") is True, \
                f"Failed to detect signal: {signal}"

    def test_create_memory_sets_storage_strength(self, db_conn):
        """New memories created via create_memory get storage_strength = 1.0."""
        import aibrain_db

        try:
            mem_id = aibrain_db.create_memory(
                name="science_test_mem",
                mem_type="project",
                content="test storage strength initialization",
                dedup_threshold=0.0,
            )
        except Exception as e:
            if "Tier limit" in str(e):
                pytest.skip("Tier limit reached — test requires free memory slots")
            raise
        assert isinstance(mem_id, int)

        row = db_conn.execute(
            "SELECT storage_strength FROM memories WHERE id = ?", (mem_id,)
        ).fetchone()
        assert row is not None
        assert row[0] == 1.0


class TestSalienceScoreBreakdown:
    """Salience score breakdown includes dual-strength fields."""

    def test_breakdown_has_retention_field(self):
        """Score breakdown includes 'retention' instead of old 'recency'."""
        import aibrain_db
        from datetime import datetime

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        _, breakdown = aibrain_db._salience_score(
            fts_score=0.5, vec_score=0.5, importance=0.5,
            access_count=5, updated_at=now, storage_strength=3.0,
        )
        assert "retention" in breakdown
        assert "retrieval_strength" in breakdown
        assert "storage_strength" in breakdown

    def test_breakdown_storage_strength_affects_score(self):
        """Higher storage_strength produces higher retention score."""
        import aibrain_db
        from datetime import datetime, timedelta

        old = (datetime.now() - timedelta(days=90)).strftime("%Y-%m-%d %H:%M:%S")

        _, low_ss = aibrain_db._salience_score(
            fts_score=0.0, vec_score=0.0, importance=0.5,
            access_count=0, updated_at=old, storage_strength=1.0,
        )
        _, high_ss = aibrain_db._salience_score(
            fts_score=0.0, vec_score=0.0, importance=0.5,
            access_count=0, updated_at=old, storage_strength=10.0,
        )

        assert high_ss["retention"] > low_ss["retention"]
