"""
Tests for aibrain/core/adapters.py — LLM adapter registry.

Covers: list_adapters, get_adapter, register_adapter, get_model_for_agent, AdapterConfig.
"""

import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.adapters import (
    ADAPTERS,
    AdapterConfig,
    get_adapter,
    get_model_for_agent,
    list_adapters,
    register_adapter,
)


# ---------------------------------------------------------------------------
# AdapterConfig defaults
# ---------------------------------------------------------------------------

class TestAdapterConfigDefaults:
    def test_default_api_key_env_empty(self):
        cfg = AdapterConfig(name="x", provider="x", display_name="X", models=["m"])
        assert cfg.api_key_env == ""

    def test_default_base_url_empty(self):
        cfg = AdapterConfig(name="x", provider="x", display_name="X", models=["m"])
        assert cfg.base_url == ""

    def test_default_model_empty(self):
        cfg = AdapterConfig(name="x", provider="x", display_name="X", models=["m"])
        assert cfg.default_model == ""

    def test_default_streaming_true(self):
        cfg = AdapterConfig(name="x", provider="x", display_name="X", models=["m"])
        assert cfg.supports_streaming is True

    def test_default_tools_true(self):
        cfg = AdapterConfig(name="x", provider="x", display_name="X", models=["m"])
        assert cfg.supports_tools is True

    def test_default_max_context(self):
        cfg = AdapterConfig(name="x", provider="x", display_name="X", models=["m"])
        assert cfg.max_context == 128000

    def test_default_cost_zero(self):
        cfg = AdapterConfig(name="x", provider="x", display_name="X", models=["m"])
        assert cfg.cost_per_1k_input == 0.0
        assert cfg.cost_per_1k_output == 0.0

    def test_default_status(self):
        cfg = AdapterConfig(name="x", provider="x", display_name="X", models=["m"])
        assert cfg.status == "available"

    def test_default_installed(self):
        cfg = AdapterConfig(name="x", provider="x", display_name="X", models=["m"])
        assert cfg.installed is False


# ---------------------------------------------------------------------------
# Built-in adapter registry
# ---------------------------------------------------------------------------

class TestBuiltinAdapters:
    def test_registry_has_8_adapters(self):
        assert len(ADAPTERS) == 8

    def test_known_adapter_names(self):
        expected = {"claude", "openai", "gemini", "ollama", "groq", "together", "deepseek", "local"}
        assert set(ADAPTERS.keys()) == expected

    def test_all_adapters_are_adapter_config(self):
        for name, adapter in ADAPTERS.items():
            assert isinstance(adapter, AdapterConfig), f"{name} is not AdapterConfig"

    def test_claude_adapter_fields(self):
        c = ADAPTERS["claude"]
        assert c.provider == "anthropic"
        assert c.api_key_env == "ANTHROPIC_API_KEY"
        assert c.max_context == 200000
        assert len(c.models) >= 3

    def test_ollama_no_api_key(self):
        o = ADAPTERS["ollama"]
        assert o.api_key_env == ""
        assert o.base_url == "http://localhost:11434"
        assert o.supports_tools is False

    def test_local_adapter_openai_provider(self):
        loc = ADAPTERS["local"]
        assert loc.provider == "openai"
        assert loc.supports_tools is False

    def test_gemini_million_context(self):
        g = ADAPTERS["gemini"]
        assert g.max_context == 1000000


# ---------------------------------------------------------------------------
# get_adapter
# ---------------------------------------------------------------------------

class TestGetAdapter:
    def test_get_claude(self):
        a = get_adapter("claude")
        assert a is not None
        assert a.name == "claude"

    def test_get_openai(self):
        a = get_adapter("openai")
        assert a is not None
        assert a.provider == "openai"

    def test_get_ollama(self):
        assert get_adapter("ollama") is not None

    def test_get_groq(self):
        assert get_adapter("groq") is not None

    def test_get_together(self):
        assert get_adapter("together") is not None

    def test_get_deepseek(self):
        assert get_adapter("deepseek") is not None

    def test_get_gemini(self):
        assert get_adapter("gemini") is not None

    def test_get_local(self):
        assert get_adapter("local") is not None

    def test_get_unknown_returns_none(self):
        assert get_adapter("nonexistent_provider") is None

    def test_get_empty_string_returns_none(self):
        assert get_adapter("") is None


# ---------------------------------------------------------------------------
# list_adapters
# ---------------------------------------------------------------------------

class TestListAdapters:
    def test_returns_list(self):
        result = list_adapters()
        assert isinstance(result, list)

    def test_returns_8_entries(self):
        result = list_adapters()
        assert len(result) == 8

    def test_entries_have_required_keys(self):
        required = {"name", "display_name", "provider", "models", "default_model",
                     "max_context", "cost_input", "cost_output", "supports_streaming",
                     "supports_tools", "available", "status"}
        for entry in list_adapters():
            assert required.issubset(entry.keys()), f"Missing keys in {entry['name']}"

    def test_adapter_with_api_key_shows_connected(self):
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk-test"}):
            result = list_adapters()
            claude_entry = next(e for e in result if e["name"] == "claude")
            assert claude_entry["available"] is True
            assert claude_entry["status"] == "connected"

    def test_adapter_without_key_shows_not_configured(self):
        with patch.dict(os.environ, {}, clear=True):
            result = list_adapters()
            # Remove all API keys to ensure not configured
            claude_entry = next(e for e in result if e["name"] == "claude")
            if not os.environ.get("ANTHROPIC_API_KEY"):
                assert claude_entry["status"] == "not configured"


# ---------------------------------------------------------------------------
# register_adapter
# ---------------------------------------------------------------------------

class TestRegisterAdapter:
    def test_register_new_adapter(self):
        original_count = len(ADAPTERS)
        try:
            adapter = register_adapter("test_provider", {
                "provider": "custom",
                "display_name": "Test Provider",
                "models": ["test-model-1"],
                "default_model": "test-model-1",
            })
            assert adapter.name == "test_provider"
            assert adapter.provider == "custom"
            assert adapter.display_name == "Test Provider"
            assert "test_provider" in ADAPTERS
            assert ADAPTERS["test_provider"] is adapter
        finally:
            ADAPTERS.pop("test_provider", None)

    def test_register_with_defaults(self):
        try:
            adapter = register_adapter("minimal", {})
            assert adapter.provider == "openai"
            assert adapter.display_name == "minimal"
            assert adapter.models == ["default"]
            assert adapter.default_model == "default"
            assert adapter.max_context == 32000
        finally:
            ADAPTERS.pop("minimal", None)

    def test_register_overwrites_existing(self):
        try:
            register_adapter("overwrite_test", {"display_name": "V1"})
            register_adapter("overwrite_test", {"display_name": "V2"})
            assert ADAPTERS["overwrite_test"].display_name == "V2"
        finally:
            ADAPTERS.pop("overwrite_test", None)

    def test_register_returns_adapter_config(self):
        try:
            result = register_adapter("typed_test", {})
            assert isinstance(result, AdapterConfig)
        finally:
            ADAPTERS.pop("typed_test", None)


# ---------------------------------------------------------------------------
# get_model_for_agent
# ---------------------------------------------------------------------------

class TestGetModelForAgent:
    def test_auto_returns_auto(self):
        prefix, model = get_model_for_agent("auto")
        assert prefix == ""
        assert model == "auto"

    def test_empty_string_returns_auto(self):
        prefix, model = get_model_for_agent("")
        assert prefix == ""
        assert model == "auto"

    def test_none_returns_auto(self):
        prefix, model = get_model_for_agent(None)
        assert prefix == ""
        assert model == "auto"

    def test_claude_resolves_to_default_model(self):
        prefix, model = get_model_for_agent("claude")
        assert prefix == "claude"
        # Claude's provider is anthropic, so no prefix in model
        assert "claude" in model.lower() or "sonnet" in model.lower()

    def test_openai_resolves_with_prefix(self):
        prefix, model = get_model_for_agent("openai")
        assert prefix == "openai"
        assert "openai/" in model

    def test_ollama_resolves_with_prefix(self):
        prefix, model = get_model_for_agent("ollama")
        assert prefix == "ollama"
        assert "ollama/" in model

    def test_specific_model_with_slash(self):
        prefix, model = get_model_for_agent("ollama/qwen3:8b")
        assert prefix == "ollama"
        assert model == "qwen3:8b"

    def test_claude_specific_model(self):
        prefix, model = get_model_for_agent("claude/claude-sonnet-4-20250514")
        assert prefix == "claude"
        assert model == "claude-sonnet-4-20250514"

    def test_unknown_adapter_literal(self):
        prefix, model = get_model_for_agent("unknown_thing")
        assert prefix == ""
        assert model == "unknown_thing"

    def test_returns_tuple(self):
        result = get_model_for_agent("auto")
        assert isinstance(result, tuple)
        assert len(result) == 2
