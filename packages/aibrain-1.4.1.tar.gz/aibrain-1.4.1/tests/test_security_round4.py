"""
Tests for Round 4 security fixes:

- R4-01: WebSocket chat rate limiting (30 msgs/min, disconnect on exceed)
- R4-02: File upload extension allowlist + 10MB size cap
- R4-03: Workflow output sanitization (paths, env vars, truncation)
"""

import sys
import time
from pathlib import Path
from unittest.mock import MagicMock, patch, AsyncMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))


# ============================================================================
# R4-01: WebSocket chat rate limiting
# ============================================================================

class TestWsRateLimiter:
    """Verify per-connection rate limiting on WebSocket chat."""

    def test_allows_messages_under_limit(self):
        from main import _WsRateLimiter
        limiter = _WsRateLimiter(max_msgs=5, window_s=60)
        for _ in range(5):
            assert limiter.check() is True

    def test_blocks_messages_over_limit(self):
        from main import _WsRateLimiter
        limiter = _WsRateLimiter(max_msgs=3, window_s=60)
        assert limiter.check() is True
        assert limiter.check() is True
        assert limiter.check() is True
        # 4th message should be blocked
        assert limiter.check() is False

    def test_window_expiry_allows_new_messages(self):
        from main import _WsRateLimiter
        limiter = _WsRateLimiter(max_msgs=2, window_s=0.1)  # 100ms window
        assert limiter.check() is True
        assert limiter.check() is True
        assert limiter.check() is False
        # Wait for window to expire
        time.sleep(0.15)
        assert limiter.check() is True

    def test_default_limit_is_30(self):
        from main import _WsRateLimiter, _WS_RATE_LIMIT
        limiter = _WsRateLimiter()
        assert limiter._max_msgs == 30
        assert _WS_RATE_LIMIT == 30


# ============================================================================
# R4-02: File upload extension allowlist + size cap
# ============================================================================

class TestFileUploadAllowlist:
    """Verify file upload rejects disallowed types and enforces 10MB cap."""

    def test_allowed_extensions_set(self):
        from aibrain_api import _ALLOWED_UPLOAD_EXTENSIONS
        expected = {".txt", ".md", ".json", ".csv", ".pdf", ".py", ".toml", ".yaml", ".yml"}
        assert _ALLOWED_UPLOAD_EXTENSIONS == expected

    def test_max_upload_is_10mb(self):
        from aibrain_api import _MAX_UPLOAD_BYTES
        assert _MAX_UPLOAD_BYTES == 10 * 1024 * 1024

    @pytest.mark.asyncio
    async def test_rejects_disallowed_extension(self):
        from aibrain_api import ingest_file
        mock_file = MagicMock()
        mock_file.filename = "malware.exe"
        mock_file.size = 100
        result = await ingest_file(file=mock_file)
        assert result.status_code == 400
        body = result.body.decode()
        assert "not allowed" in body
        assert ".exe" in body

    @pytest.mark.asyncio
    async def test_accepts_allowed_extension(self):
        """Ensure allowed extensions pass the extension check (will fail later at ingest, that's fine)."""
        from aibrain_api import ingest_file, _ALLOWED_UPLOAD_EXTENSIONS
        for ext in [".txt", ".json", ".py", ".yaml"]:
            mock_file = MagicMock()
            mock_file.filename = f"test{ext}"
            mock_file.size = 100
            mock_file.read = AsyncMock(return_value=b"test content")
            # Will pass extension check but may fail at ingest step — that's expected
            # We just verify it doesn't return 400 for extension
            try:
                result = await ingest_file(file=mock_file)
                # If it returns a JSONResponse, it shouldn't be the extension error
                if hasattr(result, 'status_code') and result.status_code == 400:
                    body = result.body.decode()
                    assert "not allowed" not in body, f"Extension {ext} should be allowed"
            except Exception:
                pass  # Other errors (missing brain, DB) are fine — extension check passed


# ============================================================================
# R4-03: Workflow output sanitization
# ============================================================================

class TestWorkflowOutputSanitization:
    """Verify stdout/stderr is sanitized before API response."""

    def test_strips_windows_paths(self):
        from aibrain_api import _sanitize_workflow_output
        raw = "Error at C:\\Users\\matt\\projects\\secret\\app.py line 42"
        sanitized = _sanitize_workflow_output(raw)
        assert "matt" not in sanitized
        assert "<path-redacted>" in sanitized

    def test_strips_unix_home_paths(self):
        from aibrain_api import _sanitize_workflow_output
        raw = "FileNotFoundError: /home/deploy/.config/secrets.json"
        sanitized = _sanitize_workflow_output(raw)
        assert "deploy" not in sanitized
        assert "<path-redacted>" in sanitized

    def test_strips_api_key_patterns(self):
        from aibrain_api import _sanitize_workflow_output
        raw = "Using API_KEY=sk-abc123secretkey for auth"
        sanitized = _sanitize_workflow_output(raw)
        assert "sk-abc123" not in sanitized
        assert "<redacted>" in sanitized

    def test_strips_export_lines(self):
        from aibrain_api import _sanitize_workflow_output
        raw = "Starting...\nexport OPENAI_API_KEY=sk-secret\nDone."
        sanitized = _sanitize_workflow_output(raw)
        assert "sk-secret" not in sanitized
        assert "<env-redacted>" in sanitized

    def test_truncates_to_10kb(self):
        from aibrain_api import _sanitize_workflow_output, _MAX_OUTPUT_BYTES
        raw = "A" * 20_000
        sanitized = _sanitize_workflow_output(raw)
        assert len(sanitized) <= _MAX_OUTPUT_BYTES
        assert _MAX_OUTPUT_BYTES == 10 * 1024

    def test_handles_empty_string(self):
        from aibrain_api import _sanitize_workflow_output
        assert _sanitize_workflow_output("") == ""
        assert _sanitize_workflow_output(None) is None
