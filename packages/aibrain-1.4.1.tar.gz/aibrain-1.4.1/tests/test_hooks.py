"""
Tests for aibrain/core/hooks.py — Tool and LLM call interceptors.

Covers: decorator registration, before/after tool hooks, before/after LLM hooks,
        hook blocking (returns False), result modification, agent role filtering.
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.hooks import (
    before_tool_call,
    after_tool_call,
    before_llm_call,
    after_llm_call,
    clear_hooks,
    get_hooks,
    run_before_tool,
    run_after_tool,
    run_before_llm,
    run_after_llm,
)


@pytest.fixture(autouse=True)
def _clean_hooks():
    """Ensure hooks are cleared before and after each test."""
    clear_hooks()
    yield
    clear_hooks()


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

class TestRegistration:
    def test_before_tool_call_registers(self):
        @before_tool_call()
        def my_hook(tool_name, args, agent):
            pass

        hooks = get_hooks("before_tool")
        assert len(hooks) == 1
        assert hooks[0]["fn"] is my_hook

    def test_after_tool_call_registers(self):
        @after_tool_call(tools=["search"])
        def my_hook(tool_name, result, agent):
            pass

        hooks = get_hooks("after_tool")
        assert len(hooks) == 1
        assert hooks[0]["tools"] == ["search"]

    def test_before_llm_call_registers(self):
        @before_llm_call(agents=["Researcher"])
        def my_hook(prompt, agent):
            pass

        hooks = get_hooks("before_llm")
        assert len(hooks) == 1
        assert hooks[0]["agents"] == ["Researcher"]

    def test_after_llm_call_registers(self):
        @after_llm_call()
        def my_hook(response, agent):
            pass

        hooks = get_hooks("after_llm")
        assert len(hooks) == 1

    def test_clear_hooks_removes_all(self):
        @before_tool_call()
        def h1(tool_name, args, agent):
            pass

        @after_llm_call()
        def h2(response, agent):
            pass

        assert len(get_hooks("before_tool")) == 1
        assert len(get_hooks("after_llm")) == 1
        clear_hooks()
        assert len(get_hooks("before_tool")) == 0
        assert len(get_hooks("after_llm")) == 0

    def test_decorator_returns_original_function(self):
        @before_tool_call()
        def my_hook(tool_name, args, agent):
            return "original"

        # The decorator should return the original function unchanged
        assert my_hook("test", {}, None) == "original"


# ---------------------------------------------------------------------------
# Before tool hooks
# ---------------------------------------------------------------------------

class TestBeforeTool:
    def test_allows_by_default(self):
        @before_tool_call()
        def noop(tool_name, args, agent):
            pass

        allow, args = run_before_tool("search", {"q": "test"})
        assert allow is True

    def test_blocks_when_returning_false(self):
        @before_tool_call()
        def blocker(tool_name, args, agent):
            return False

        allow, args = run_before_tool("search", {"q": "test"})
        assert allow is False

    def test_modifies_args_when_returning_dict(self):
        @before_tool_call()
        def modifier(tool_name, args, agent):
            args["injected"] = True
            return args

        allow, args = run_before_tool("search", {"q": "test"})
        assert allow is True
        assert args["injected"] is True

    def test_tool_filter_matches(self):
        calls = []

        @before_tool_call(tools=["search"])
        def hook(tool_name, args, agent):
            calls.append(tool_name)

        run_before_tool("search", {})
        run_before_tool("delete", {})
        assert calls == ["search"]

    def test_tool_filter_no_match(self):
        calls = []

        @before_tool_call(tools=["search"])
        def hook(tool_name, args, agent):
            calls.append(tool_name)

        run_before_tool("delete", {})
        assert calls == []

    def test_agent_filter(self):
        calls = []

        @before_tool_call(agents=["Researcher"])
        def hook(tool_name, args, agent):
            calls.append(agent)

        # Mock agent with role attribute
        class MockAgent:
            role = "Researcher"

        class OtherAgent:
            role = "Writer"

        run_before_tool("search", {}, MockAgent())
        run_before_tool("search", {}, OtherAgent())
        assert len(calls) == 1
        assert calls[0].role == "Researcher"

    def test_hook_exception_does_not_block(self):
        @before_tool_call()
        def bad_hook(tool_name, args, agent):
            raise ValueError("boom")

        allow, args = run_before_tool("search", {"q": "test"})
        assert allow is True  # Exception swallowed, not blocked


# ---------------------------------------------------------------------------
# After tool hooks
# ---------------------------------------------------------------------------

class TestAfterTool:
    def test_returns_original_when_no_hooks(self):
        result = run_after_tool("search", "original result")
        assert result == "original result"

    def test_modifies_result(self):
        @after_tool_call()
        def modifier(tool_name, result, agent):
            return result.upper()

        result = run_after_tool("search", "hello")
        assert result == "HELLO"

    def test_none_return_preserves_result(self):
        @after_tool_call()
        def observer(tool_name, result, agent):
            pass  # returns None implicitly

        result = run_after_tool("search", "original")
        assert result == "original"

    def test_chain_modifications(self):
        @after_tool_call()
        def add_prefix(tool_name, result, agent):
            return f"[{tool_name}] {result}"

        @after_tool_call()
        def add_suffix(tool_name, result, agent):
            return f"{result} (done)"

        result = run_after_tool("search", "data")
        assert result == "[search] data (done)"

    def test_tool_filter(self):
        @after_tool_call(tools=["search"])
        def hook(tool_name, result, agent):
            return "modified"

        assert run_after_tool("search", "original") == "modified"
        assert run_after_tool("delete", "original") == "original"


# ---------------------------------------------------------------------------
# Before LLM hooks
# ---------------------------------------------------------------------------

class TestBeforeLLM:
    def test_modifies_prompt(self):
        @before_llm_call()
        def add_context(prompt, agent):
            return prompt + "\nAlways cite sources."

        result = run_before_llm("Find data about AI.")
        assert result == "Find data about AI.\nAlways cite sources."

    def test_agent_filter(self):
        calls = []

        @before_llm_call(agents=["Researcher"])
        def hook(prompt, agent):
            calls.append(True)
            return prompt + " [researcher context]"

        class MockAgent:
            role = "Researcher"

        class OtherAgent:
            role = "Writer"

        result_r = run_before_llm("test", MockAgent())
        result_w = run_before_llm("test", OtherAgent())

        assert "[researcher context]" in result_r
        assert "[researcher context]" not in result_w
        assert len(calls) == 1

    def test_non_string_return_ignored(self):
        @before_llm_call()
        def bad_return(prompt, agent):
            return 42  # not a string

        result = run_before_llm("original prompt")
        assert result == "original prompt"


# ---------------------------------------------------------------------------
# After LLM hooks
# ---------------------------------------------------------------------------

class TestAfterLLM:
    def test_modifies_response(self):
        @after_llm_call()
        def sanitize(response, agent):
            return response.replace("SECRET", "[REDACTED]")

        result = run_after_llm("The SECRET is 42.")
        assert result == "The [REDACTED] is 42."

    def test_chain_modifications(self):
        @after_llm_call()
        def strip_whitespace(response, agent):
            return response.strip()

        @after_llm_call()
        def add_marker(response, agent):
            return f"[AI] {response}"

        result = run_after_llm("  hello  ")
        assert result == "[AI] hello"

    def test_agent_filter(self):
        @after_llm_call(agents=["Writer"])
        def hook(response, agent):
            return response + " [edited]"

        class Writer:
            role = "Writer"

        class Researcher:
            role = "Researcher"

        assert run_after_llm("text", Writer()) == "text [edited]"
        assert run_after_llm("text", Researcher()) == "text"
