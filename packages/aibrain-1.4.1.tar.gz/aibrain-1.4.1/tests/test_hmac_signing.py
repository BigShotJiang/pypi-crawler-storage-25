"""Tests for HMAC message signing in peer broker."""

import hashlib
import hmac
import json
import time
from unittest.mock import patch

import pytest

# We need to import after patching the env var in some tests
import mcp_peer_discovery as mpd


@pytest.fixture(autouse=True)
def _set_token(monkeypatch):
    """Ensure a known broker token is set for all tests."""
    monkeypatch.setattr(mpd, "_BROKER_TOKEN", "test-secret-key-123")


class TestComputeHMAC:
    def test_deterministic(self):
        """Same inputs produce same HMAC."""
        body = b'{"from_agent": "a", "content": "hello"}'
        ts = "1700000000.0"
        sig1 = mpd._compute_hmac(body, ts)
        sig2 = mpd._compute_hmac(body, ts)
        assert sig1 == sig2  # noqa:PLAIN SECRET COMPARISON — test determinism, not auth

    def test_different_body_different_sig(self):
        """Different bodies produce different signatures."""
        ts = "1700000000.0"
        sig1 = mpd._compute_hmac(b"body1", ts)
        sig2 = mpd._compute_hmac(b"body2", ts)
        assert sig1 != sig2

    def test_different_timestamp_different_sig(self):
        """Different timestamps produce different signatures."""
        body = b"same body"
        sig1 = mpd._compute_hmac(body, "1700000000.0")
        sig2 = mpd._compute_hmac(body, "1700000001.0")
        assert sig1 != sig2

    def test_matches_stdlib_hmac(self):
        """Verify our implementation matches direct stdlib computation."""
        body = b"test message"
        ts = "1700000000.0"
        key = b"test-secret-key-123"
        msg = ts.encode("utf-8") + b":" + body
        expected = hmac.new(key, msg, hashlib.sha256).hexdigest()
        assert mpd._compute_hmac(body, ts) == expected


class TestVerifyHMAC:
    def test_valid_signature_passes(self):
        """A correctly signed message should pass verification."""
        body = b'{"msg": "hello"}'
        ts = str(time.time())
        sig = mpd._compute_hmac(body, ts)
        valid, reason = mpd._verify_hmac(body, sig, ts)
        assert valid is True
        assert reason == "valid"

    def test_wrong_signature_fails(self):
        """A tampered signature should fail."""
        body = b'{"msg": "hello"}'
        ts = str(time.time())
        valid, reason = mpd._verify_hmac(body, "bad_signature_hex", ts)
        assert valid is False
        assert "mismatch" in reason

    def test_expired_timestamp_fails(self):
        """A timestamp older than 5 minutes should be rejected."""
        body = b'{"msg": "hello"}'
        old_ts = str(time.time() - 400)  # 6+ minutes ago
        sig = mpd._compute_hmac(body, old_ts)
        valid, reason = mpd._verify_hmac(body, sig, old_ts)
        assert valid is False
        assert "too old" in reason

    def test_missing_headers_fails(self):
        """Missing signature or timestamp should fail."""
        body = b'{"msg": "hello"}'
        valid, reason = mpd._verify_hmac(body, "", "")
        assert valid is False
        assert "missing" in reason

    def test_no_token_passes_everything(self, monkeypatch):
        """When PEER_BROKER_TOKEN is unset, all messages pass (open mode)."""
        monkeypatch.setattr(mpd, "_BROKER_TOKEN", "")
        valid, reason = mpd._verify_hmac(b"anything", "", "")
        assert valid is True
        assert "open mode" in reason

    def test_invalid_timestamp_format(self):
        """Non-numeric timestamp should fail."""
        body = b"test"
        sig = "anything"
        valid, reason = mpd._verify_hmac(body, sig, "not-a-number")
        assert valid is False
        assert "invalid timestamp" in reason

    def test_fresh_timestamp_within_window(self):
        """A timestamp 4 minutes old should still be valid (within 5-min window)."""
        body = b'{"ok": true}'
        ts = str(time.time() - 240)  # 4 minutes ago
        sig = mpd._compute_hmac(body, ts)
        valid, _ = mpd._verify_hmac(body, sig, ts)
        assert valid is True
