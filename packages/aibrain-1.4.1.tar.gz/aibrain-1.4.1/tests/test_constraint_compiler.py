"""
Tests for constraint_compiler — HARD RULE session-start invariant loader.

Tests:
  1. compile_constraints returns all builtins
  2. compile_constraints counts enforcement points correctly
  3. validate_wiring detects orphan rules
  4. validate_wiring detects uncovered enforcement points
  5. validate_wiring detects missing builtins
  6. validate_wiring detects duplicate rule_ids
  7. validate_wiring detects invalid enforcement points
  8. doctor_check returns True for healthy system
  9. doctor_check returns False when errors exist
  10. print_session_summary produces output
  11. ConstraintReport.is_healthy property
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from aibrain.core.enforcement import (
    BUILTIN_RULES,
    CHECKER_REGISTRY,
    ENFORCEMENT_POINTS,
    HardRule,
    clear_cache,
)
from aibrain.core.constraint_compiler import (
    ConstraintReport,
    WiringIssue,
    compile_constraints,
    doctor_check,
    print_session_summary,
    validate_wiring,
)


@pytest.fixture(autouse=True)
def clear_rule_cache():
    clear_cache()
    yield
    clear_cache()


# ---------------------------------------------------------------------------
# Test 1: compile_constraints loads all builtins
# ---------------------------------------------------------------------------

class TestCompileConstraints:
    def test_loads_all_builtins(self):
        report = compile_constraints(
            db_path=Path("/nonexistent/test.db"),
            memory_dir=Path("/nonexistent/memory"),
        )
        builtin_ids = {r.rule_id for r in BUILTIN_RULES}
        loaded_ids = {r.rule_id for r in report.rules}
        assert builtin_ids.issubset(loaded_ids)
        assert report.rule_count >= len(BUILTIN_RULES)

    def test_summary_contains_counts(self):
        report = compile_constraints(
            db_path=Path("/nonexistent/test.db"),
            memory_dir=Path("/nonexistent/memory"),
        )
        assert "rules active" in report.summary
        assert "enforcement points" in report.summary

    def test_source_breakdown_includes_builtin(self):
        report = compile_constraints(
            db_path=Path("/nonexistent/test.db"),
            memory_dir=Path("/nonexistent/memory"),
        )
        assert "builtin" in report.source_breakdown
        assert report.source_breakdown["builtin"] == len(BUILTIN_RULES)

    def test_severity_breakdown(self):
        report = compile_constraints(
            db_path=Path("/nonexistent/test.db"),
            memory_dir=Path("/nonexistent/memory"),
        )
        assert "block" in report.severity_breakdown
        total = sum(report.severity_breakdown.values())
        assert total == report.rule_count


# ---------------------------------------------------------------------------
# Test 2: enforcement point counting
# ---------------------------------------------------------------------------

class TestEnforcementPointCounting:
    def test_points_with_rules_populated(self):
        report = compile_constraints(
            db_path=Path("/nonexistent/test.db"),
            memory_dir=Path("/nonexistent/memory"),
        )
        # Builtins cover multiple enforcement points
        assert len(report.points_with_rules) > 0
        # pre_commit should have at least 2 rules (credentials + co-author)
        assert report.points_with_rules.get("pre_commit", 0) >= 2


# ---------------------------------------------------------------------------
# Test 3: orphan rule detection
# ---------------------------------------------------------------------------

class TestOrphanRuleDetection:
    def test_detects_orphan_check_fn(self):
        orphan = HardRule(
            rule_id="orphan_test",
            name="Orphan Rule",
            description="References nonexistent checker",
            enforcement_points=["pre_commit"],
            check_fn="check_does_not_exist",
            source="test",
        )
        issues = validate_wiring([orphan])
        orphan_issues = [i for i in issues if i.issue_type == "orphan_rule"]
        assert len(orphan_issues) >= 1
        assert "check_does_not_exist" in orphan_issues[0].message

    def test_no_orphans_in_builtins(self):
        issues = validate_wiring(BUILTIN_RULES)
        orphan_issues = [i for i in issues if i.issue_type == "orphan_rule"]
        assert len(orphan_issues) == 0


# ---------------------------------------------------------------------------
# Test 4: uncovered enforcement point detection
# ---------------------------------------------------------------------------

class TestUncoveredPointDetection:
    def test_detects_uncovered_points(self):
        # A single rule covering only pre_commit leaves others uncovered
        one_rule = [HardRule(
            rule_id="single",
            name="Single Rule",
            description="Only covers pre_commit",
            enforcement_points=["pre_commit"],
            check_fn="check_no_credentials",
            source="test",
        )]
        issues = validate_wiring(one_rule)
        uncovered = [i for i in issues if i.issue_type == "uncovered_point"]
        # Should flag the other enforcement points
        assert len(uncovered) > 0
        uncovered_points = {i.enforcement_point for i in uncovered}
        assert "pre_delete" in uncovered_points or "pre_push" in uncovered_points

    def test_builtins_cover_all_points(self):
        issues = validate_wiring(BUILTIN_RULES)
        uncovered = [i for i in issues if i.issue_type == "uncovered_point"]
        assert len(uncovered) == 0


# ---------------------------------------------------------------------------
# Test 5: missing builtin detection
# ---------------------------------------------------------------------------

class TestMissingBuiltinDetection:
    def test_detects_missing_builtin(self):
        # Pass an empty list — all builtins should be missing
        issues = validate_wiring([])
        missing = [i for i in issues if i.issue_type == "missing_builtin"]
        assert len(missing) == len(BUILTIN_RULES)


# ---------------------------------------------------------------------------
# Test 6: duplicate rule_id detection
# ---------------------------------------------------------------------------

class TestDuplicateDetection:
    def test_detects_duplicate_ids(self):
        dup = HardRule(
            rule_id="dupe",
            name="Duplicate",
            description="Test",
            enforcement_points=["pre_commit"],
            check_fn="check_no_credentials",
            source="test",
        )
        issues = validate_wiring([dup, dup])
        dup_issues = [i for i in issues if i.issue_type == "duplicate"]
        assert len(dup_issues) >= 1


# ---------------------------------------------------------------------------
# Test 7: invalid enforcement point detection
# ---------------------------------------------------------------------------

class TestInvalidPointDetection:
    def test_detects_invalid_point(self):
        bad_rule = HardRule(
            rule_id="bad_point",
            name="Bad Point Rule",
            description="Test",
            enforcement_points=["pre_nonexistent"],
            check_fn="check_no_credentials",
            source="test",
        )
        issues = validate_wiring([bad_rule])
        invalid = [i for i in issues if i.issue_type == "invalid_point"]
        assert len(invalid) >= 1
        assert "pre_nonexistent" in invalid[0].message


# ---------------------------------------------------------------------------
# Test 8: doctor_check healthy
# ---------------------------------------------------------------------------

class TestDoctorCheck:
    def test_healthy_with_builtins(self, capsys):
        result = doctor_check(
            db_path=Path("/nonexistent/test.db"),
            memory_dir=Path("/nonexistent/memory"),
        )
        assert result is True
        captured = capsys.readouterr()
        assert "enforcement" in captured.out.lower() or "constraint" in captured.out.lower()

    def test_doctor_prints_summary(self, capsys):
        doctor_check(
            db_path=Path("/nonexistent/test.db"),
            memory_dir=Path("/nonexistent/memory"),
        )
        captured = capsys.readouterr()
        assert "rules active" in captured.out.lower() or "rule" in captured.out.lower()


# ---------------------------------------------------------------------------
# Test 9: ConstraintReport.is_healthy
# ---------------------------------------------------------------------------

class TestIsHealthy:
    def test_healthy_when_no_errors(self):
        report = ConstraintReport(
            rules=[], rule_count=0, enforcement_point_count=0,
            points_with_rules={}, source_breakdown={}, severity_breakdown={},
            issues=[WiringIssue(severity="warning", issue_type="test", message="warn")],
            summary="test",
        )
        assert report.is_healthy is True

    def test_unhealthy_when_errors(self):
        report = ConstraintReport(
            rules=[], rule_count=0, enforcement_point_count=0,
            points_with_rules={}, source_breakdown={}, severity_breakdown={},
            issues=[WiringIssue(severity="error", issue_type="test", message="err")],
            summary="test",
        )
        assert report.is_healthy is False


# ---------------------------------------------------------------------------
# Test 10: print_session_summary
# ---------------------------------------------------------------------------

class TestPrintSessionSummary:
    def test_prints_enforcement_line(self, capsys):
        report = print_session_summary(
            db_path=Path("/nonexistent/test.db"),
            memory_dir=Path("/nonexistent/memory"),
        )
        captured = capsys.readouterr()
        assert "Enforcement:" in captured.out
        assert report.rule_count >= len(BUILTIN_RULES)
