"""
Tests for mega-blob memory chunking on ingest.

Verifies that create_memory() splits content >10K chars into
parent + chunk children with per-chunk embeddings.
"""

import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture()
def db_conn():
    """Create a fresh, isolated SQLite DB with the full AIBrain schema."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="aibrain_chunktest_")
    os.close(fd)

    import aibrain_db
    original_path = aibrain_db.DB_PATH
    original_conn = aibrain_db._conn

    aibrain_db.DB_PATH = Path(path)
    aibrain_db._conn = None

    conn = aibrain_db.get_db()
    yield conn

    try:
        conn.close()
    except Exception:
        pass
    aibrain_db._conn = original_conn
    aibrain_db.DB_PATH = original_path

    try:
        os.unlink(path)
    except OSError:
        pass
    for ext in ("-wal", "-shm"):
        try:
            os.unlink(path + ext)
        except OSError:
            pass


class TestSplitIntoChunks:
    """Test the _split_into_chunks helper."""

    def test_short_text_single_chunk(self):
        from aibrain_db import _split_into_chunks
        chunks = _split_into_chunks("Hello world.", target_size=500)
        assert len(chunks) == 1
        assert chunks[0] == "Hello world."

    def test_long_text_splits(self):
        from aibrain_db import _split_into_chunks
        # Build text with clear paragraph boundaries
        paragraphs = [f"Paragraph {i}. " * 20 for i in range(30)]
        text = "\n\n".join(paragraphs)
        assert len(text) > 5000

        chunks = _split_into_chunks(text, target_size=500)
        assert len(chunks) > 1
        # All chunks should be roughly within target
        for chunk in chunks:
            assert len(chunk) <= 600  # some slack for boundary alignment

    def test_preserves_all_content(self):
        from aibrain_db import _split_into_chunks
        text = "Sentence one. Sentence two. Sentence three. " * 50
        chunks = _split_into_chunks(text, target_size=100)
        # Reassembled content should contain all words
        reassembled = " ".join(chunks)
        for word in ["one", "two", "three"]:
            assert word in reassembled


class TestChunkedMemoryCreation:
    """Test that create_memory chunks mega-blobs."""

    def test_small_content_not_chunked(self, db_conn):
        """Content under 10K chars is stored as a single memory."""
        import aibrain_db
        content = "Short memory content."
        result = aibrain_db.create_memory(
            "test_small", "project", content, dedup_threshold=0.0
        )
        assert isinstance(result, int)

        # Should be exactly one memory with this name pattern
        rows = db_conn.execute(
            "SELECT * FROM memories WHERE name LIKE 'test_small%'"
        ).fetchall()
        assert len(rows) == 1

    def test_mega_blob_creates_parent_and_chunks(self, db_conn):
        """Content >10K chars creates parent + chunk children."""
        import aibrain_db

        # Build content >10K chars
        content = "\n\n".join(
            [f"Section {i}: " + ("Important data point. " * 30) for i in range(25)]
        )
        assert len(content) > 10_000

        parent_id = aibrain_db.create_memory(
            "test_mega", "project", content, dedup_threshold=0.0
        )
        assert isinstance(parent_id, int)

        # Parent should exist
        parent = db_conn.execute(
            "SELECT * FROM memories WHERE id = ?", (parent_id,)
        ).fetchone()
        assert parent is not None
        assert parent["name"] == "test_mega"
        assert parent["status"] == "active"

        # Chunks should exist as children
        chunks = db_conn.execute(
            "SELECT * FROM memories WHERE name LIKE 'test_mega__chunk_%'"
        ).fetchall()
        assert len(chunks) >= 2  # Must have split into multiple chunks

        # Each chunk should have consolidated_from pointing to parent
        for chunk in chunks:
            cf = json.loads(chunk["consolidated_from"])
            assert parent_id in cf

    def test_chunks_have_reasonable_size(self, db_conn):
        """Each chunk's content should be roughly ~500 chars."""
        import aibrain_db

        content = "\n\n".join(
            [f"Paragraph {i}. " + ("Word " * 80) for i in range(40)]
        )
        assert len(content) > 10_000

        parent_id = aibrain_db.create_memory(
            "test_size", "reference", content, dedup_threshold=0.0
        )

        chunks = db_conn.execute(
            "SELECT content FROM memories WHERE name LIKE 'test_size__chunk_%'"
        ).fetchall()
        assert len(chunks) >= 2

        for chunk in chunks:
            # Chunks should be in the 100-700 char range
            assert 50 <= len(chunk["content"]) <= 700, \
                f"Chunk size {len(chunk['content'])} outside expected range"
