"""
Tests for RBAC (Role-Based Access Control) — admin/user/viewer role enforcement.

Fix: All authenticated users previously had identical privileges.
Now: admin (full), user (read + limited write), viewer (read-only).
"""

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))


# ---------------------------------------------------------------------------
# Unit tests for role resolution and RBAC checks
# ---------------------------------------------------------------------------

class TestGetRoleForRequest:
    """Test role extraction from requests."""

    def _make_request(self, client_ip="8.8.8.8", jwt_payload=None, api_key=None):
        req = MagicMock()
        req.client.host = client_ip
        req.state = MagicMock()
        if jwt_payload is not None:
            req.state.jwt_payload = jwt_payload
        else:
            req.state.jwt_payload = None
        _h = {}
        if api_key:
            _h["x-api-key"] = api_key
        req.headers = MagicMock()
        req.headers.get = lambda k, d="": _h.get(k, d)
        return req

    def test_localhost_gets_admin(self):
        from security import get_role_for_request
        req = self._make_request(client_ip="127.0.0.1")
        assert get_role_for_request(req) == "admin"

    def test_jwt_role_extracted(self):
        from security import get_role_for_request
        req = self._make_request(client_ip="8.8.8.8",
                                 jwt_payload={"sub": "bob", "role": "user"})
        assert get_role_for_request(req) == "user"

    def test_jwt_invalid_role_falls_to_viewer(self):
        from security import get_role_for_request
        req = self._make_request(client_ip="8.8.8.8",
                                 jwt_payload={"sub": "bob", "role": "superadmin"})
        assert get_role_for_request(req) == "viewer"

    def test_no_auth_falls_to_viewer(self):
        from security import get_role_for_request
        req = self._make_request(client_ip="8.8.8.8")
        assert get_role_for_request(req) == "viewer"


class TestCheckRbac:
    """Test RBAC enforcement on various paths."""

    def _make_request(self, path, method="GET", role="viewer", client_ip="8.8.8.8"):
        req = MagicMock()
        req.client.host = client_ip
        req.url.path = path
        req.method = method
        req.state = MagicMock()
        if role == "admin" and client_ip in ("127.0.0.1", "::1"):
            req.state.jwt_payload = None
        else:
            req.state.jwt_payload = {"sub": "test", "role": role}
        req.headers = MagicMock()
        req.headers.get = lambda k, d="": d
        return req

    def test_admin_can_post_auth_keys(self):
        from security import check_rbac
        req = self._make_request("/api/auth/keys", "POST", "admin", "127.0.0.1")
        allowed, _ = check_rbac(req)
        assert allowed is True

    def test_viewer_blocked_from_post_memories(self):
        from security import check_rbac
        req = self._make_request("/api/memories", "POST", "viewer")
        allowed, reason = check_rbac(req)
        assert allowed is False
        assert "User role required" in reason

    def test_viewer_can_get_memories(self):
        from security import check_rbac
        req = self._make_request("/api/memories", "GET", "viewer")
        allowed, _ = check_rbac(req)
        assert allowed is True

    def test_user_blocked_from_post_auth_keys(self):
        from security import check_rbac
        req = self._make_request("/api/auth/keys", "POST", "user")
        allowed, reason = check_rbac(req)
        assert allowed is False
        assert "Admin role required" in reason

    def test_user_can_post_memories(self):
        from security import check_rbac
        req = self._make_request("/api/memories", "POST", "user")
        allowed, _ = check_rbac(req)
        assert allowed is True

    def test_viewer_blocked_from_delete_config(self):
        from security import check_rbac
        req = self._make_request("/api/config", "DELETE", "viewer")
        allowed, reason = check_rbac(req)
        assert allowed is False


class TestRbacHelpers:
    """Test role assignment helpers."""

    def test_set_api_key_role_validates(self):
        from security import set_api_key_role
        db = MagicMock()
        db.config_get.return_value = {}
        with pytest.raises(ValueError, match="Invalid role"):
            set_api_key_role(db, "abc123", "superadmin")

    def test_issue_jwt_with_role_includes_claim(self):
        from security import issue_jwt_with_role, jwt_decode
        db = MagicMock()
        db.config_get.return_value = None
        db.config_set = MagicMock()
        token = issue_jwt_with_role(db, "alice", role="user", ttl=3600)
        # Decode and verify role claim is present
        # Get the secret that was set
        secret = db.config_set.call_args[0][1]
        payload = jwt_decode(token, secret)
        assert payload is not None
        assert payload["role"] == "user"
        assert payload["sub"] == "alice"

    def test_issue_jwt_with_invalid_role_raises(self):
        from security import issue_jwt_with_role
        db = MagicMock()
        with pytest.raises(ValueError, match="Invalid role"):
            issue_jwt_with_role(db, "bob", role="root")
