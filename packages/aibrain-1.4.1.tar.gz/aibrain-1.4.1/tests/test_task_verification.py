"""
Tests for aibrain/core/task_verification.py — verify-and-followup system.

Covers:
  - detect_acceptance_criteria: numbered lists, bullets, must-statements
  - _criterion_satisfied (via verify_and_complete)
  - auto_create_followups: TODO/follow-up hint extraction
  - verify_and_complete: passing, partial, gap-follow-ups
  - Schema migration: new columns exist on test DB
  - complete_task backward compat (no work_output)
  - complete_task with work_output: verified path
  - complete_task with work_output: require_verification blocks failing tasks
  - Multiple gaps → multiple follow-up tasks
  - Parent-child linkage via parent_task_id
  - verification_status persists on parent row
  - CLI `aibrain task verify` invocation
"""

import sqlite3
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ---------------------------------------------------------------------------
# Schema — mirrors current prod schema INCLUDING the new migration columns
# ---------------------------------------------------------------------------

SCHEMA = """
CREATE TABLE IF NOT EXISTS companies (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    mission TEXT,
    status TEXT DEFAULT 'active',
    budget_monthly_cents INTEGER DEFAULT 0,
    spent_monthly_cents INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS company_agents (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT DEFAULT 'general',
    title TEXT,
    status TEXT DEFAULT 'idle',
    reports_to TEXT,
    model TEXT DEFAULT 'auto',
    task_type TEXT DEFAULT 'judgment',
    authority TEXT DEFAULT 'standard',
    budget_monthly_cents INTEGER DEFAULT 0,
    spent_monthly_cents INTEGER DEFAULT 0,
    heartbeat_interval_seconds INTEGER DEFAULT 14400,
    last_heartbeat_at TIMESTAMP,
    instructions TEXT,
    capabilities TEXT,
    permissions TEXT,
    metadata TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS company_issues (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    parent_id TEXT,
    parent_task_id TEXT,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'backlog',
    priority TEXT DEFAULT 'medium',
    assignee_agent_id TEXT,
    project TEXT,
    issue_number INTEGER,
    origin TEXT DEFAULT 'manual',
    request_depth INTEGER DEFAULT 0,
    quality_score REAL,
    self_score REAL,
    eval_score REAL,
    quality_verified INTEGER DEFAULT 0,
    quality_flagged INTEGER DEFAULT 0,
    quality_detail TEXT DEFAULT '',
    verification_status TEXT DEFAULT 'unverified',
    verification_notes TEXT,
    cost_cents INTEGER DEFAULT 0,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_parent_task ON company_issues(parent_task_id);

CREATE TABLE IF NOT EXISTS company_approvals (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    type TEXT NOT NULL,
    requested_by_agent_id TEXT,
    status TEXT DEFAULT 'pending',
    payload TEXT,
    decision_note TEXT,
    decided_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS config (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""


@pytest.fixture()
def verification_db(tmp_path):
    """Temp DB patched into both companies._get_db and task_verification._get_db."""
    db_path = tmp_path / "test_verification.db"
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    conn.close()

    def _patched_get_db():
        db = sqlite3.connect(str(db_path))
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        return db

    with patch("aibrain.core.companies._get_db", _patched_get_db), \
         patch("aibrain.core.task_verification._get_db", _patched_get_db):
        yield db_path


def _make_task(description="", title="Test task"):
    """Helper to create a company and a task inside it. Returns task dict."""
    from aibrain.core.companies import create_company, create_task
    company = create_company("Verify Test Co")
    return create_task(
        company["id"], title, description=description, auto_route=False
    )


# ===========================================================================
# detect_acceptance_criteria
# ===========================================================================


class TestDetectAcceptanceCriteria:

    def test_numbered_list(self):
        from aibrain.core.task_verification import detect_acceptance_criteria
        desc = (
            "Build the feature.\n"
            "1. Write the schema migration\n"
            "2. Add the verify_and_complete function\n"
            "3. Wire it into complete_task\n"
        )
        criteria = detect_acceptance_criteria(desc)
        assert len(criteria) == 3
        assert "Write the schema migration" in criteria
        assert "Wire it into complete_task" in criteria

    def test_bullet_list(self):
        from aibrain.core.task_verification import detect_acceptance_criteria
        desc = (
            "- Create module task_verification.py\n"
            "- Add CLI command\n"
            "- Write ten tests\n"
        )
        criteria = detect_acceptance_criteria(desc)
        assert len(criteria) == 3
        assert "Create module task_verification.py" in criteria

    def test_must_statements(self):
        from aibrain.core.task_verification import detect_acceptance_criteria
        desc = (
            "The system must create follow-up tasks automatically. "
            "It should store them under parent_task_id."
        )
        criteria = detect_acceptance_criteria(desc)
        # Both must/should statements should be captured
        assert any("create follow-up" in c.lower() for c in criteria)
        assert any("parent_task_id" in c.lower() for c in criteria)

    def test_ignores_code_fences(self):
        from aibrain.core.task_verification import detect_acceptance_criteria
        desc = (
            "1. Do this\n"
            "```\n"
            "- fake bullet inside code\n"
            "```\n"
            "2. Do that\n"
        )
        criteria = detect_acceptance_criteria(desc)
        assert "Do this" in criteria
        assert "Do that" in criteria
        assert not any("fake bullet" in c for c in criteria)

    def test_empty_description(self):
        from aibrain.core.task_verification import detect_acceptance_criteria
        assert detect_acceptance_criteria("") == []
        assert detect_acceptance_criteria(None) == []


# ===========================================================================
# verify_and_complete
# ===========================================================================


class TestVerifyAndComplete:

    def test_all_criteria_pass(self, verification_db):
        from aibrain.core.task_verification import verify_and_complete
        task = _make_task(description=(
            "1. Schema migration applied\n"
            "2. Module task_verification created\n"
            "3. CLI command wired\n"
        ))
        work_output = (
            "Completed work:\n"
            "- Schema migration applied to company_issues\n"
            "- Module task_verification created under aibrain/core\n"
            "- CLI command wired into __main__.py\n"
        )
        result = verify_and_complete(task["id"], work_output)
        assert result["verified"] is True
        assert result["verification_status"] == "verified"
        assert result["gaps"] == []

    def test_missing_criterion_creates_followup(self, verification_db):
        from aibrain.core.task_verification import verify_and_complete
        task = _make_task(description=(
            "1. Add schema migration for parent_task_id\n"
            "2. Add schema migration for verification_status\n"
            "3. Write comprehensive tests covering every edge case\n"
        ))
        # Output only covers criterion 1 and 2
        work_output = (
            "Added parent_task_id column and verification_status column "
            "to company_issues table."
        )
        result = verify_and_complete(task["id"], work_output)
        assert result["verification_status"] == "partial"
        assert len(result["gaps"]) >= 1
        # At least the "write comprehensive tests" criterion should be a gap
        assert any("test" in g.lower() for g in result["gaps"])
        # Follow-up tasks should be created
        assert len(result["follow_up_tasks"]) >= 1

    def test_todo_hint_creates_followup(self, verification_db):
        from aibrain.core.task_verification import verify_and_complete
        task = _make_task(
            title="Ship the feature",
            description="- Ship it",
        )
        work_output = (
            "Shipped the core feature.\n"
            "TODO: wire up the dashboard widget for it.\n"
        )
        result = verify_and_complete(task["id"], work_output)
        # At least one follow-up should have been created from the TODO
        assert len(result["follow_up_tasks"]) >= 1

    def test_persists_status_on_parent(self, verification_db):
        from aibrain.core.task_verification import verify_and_complete
        task = _make_task(description="1. Do the thing")
        work_output = "The thing is done"
        verify_and_complete(task["id"], work_output)

        # Read the row back directly
        db = sqlite3.connect(str(verification_db))
        db.row_factory = sqlite3.Row
        row = dict(db.execute(
            "SELECT verification_status, verification_notes FROM company_issues WHERE id=?",
            (task["id"],)
        ).fetchone())
        db.close()
        assert row["verification_status"] == "verified"
        assert "criteria_count" in (row["verification_notes"] or "")

    def test_parent_child_linkage(self, verification_db):
        from aibrain.core.task_verification import verify_and_complete, list_followups
        task = _make_task(description=(
            "1. Criterion A that will be satisfied\n"
            "2. Completely different requirement XYZZY\n"
        ))
        work_output = "Criterion A satisfied."  # gap on criterion 2
        result = verify_and_complete(task["id"], work_output)
        assert len(result["follow_up_tasks"]) >= 1

        # List followups by parent
        children = list_followups(task["id"])
        assert len(children) >= 1
        for c in children:
            assert c["parent_task_id"] == task["id"]

    def test_multiple_gaps_multiple_followups(self, verification_db):
        from aibrain.core.task_verification import verify_and_complete
        task = _make_task(description=(
            "1. Alpha omega requirement must be satisfied\n"
            "2. Beta zeta requirement must be satisfied\n"
            "3. Gamma theta requirement must be satisfied\n"
        ))
        work_output = "Nothing useful mentioning none of those things."
        result = verify_and_complete(task["id"], work_output)
        # Expect 3 gaps → 3 follow-ups
        assert len(result["gaps"]) == 3
        assert len(result["follow_up_tasks"]) >= 3


# ===========================================================================
# auto_create_followups (direct)
# ===========================================================================


class TestAutoCreateFollowups:

    def test_extracts_multiple_hints(self, verification_db):
        from aibrain.core.task_verification import auto_create_followups
        task = _make_task()
        # Reload task as dict (create_task already returns dict)
        completion = (
            "Shipped the base. TODO: add analytics. "
            "Follow up: send outreach email. "
            "FIXME: stripe webhook still broken."
        )
        ids = auto_create_followups(task, completion)
        assert len(ids) >= 3

    def test_no_hints_returns_empty(self, verification_db):
        from aibrain.core.task_verification import auto_create_followups
        task = _make_task()
        ids = auto_create_followups(task, "All done, shipped cleanly.")
        assert ids == []


# ===========================================================================
# Schema migration
# ===========================================================================


class TestSchema:

    def test_new_columns_exist(self, verification_db):
        db = sqlite3.connect(str(verification_db))
        cols = {r[1] for r in db.execute("PRAGMA table_info(company_issues)").fetchall()}
        db.close()
        assert "parent_task_id" in cols
        assert "verification_status" in cols
        assert "verification_notes" in cols

    def test_parent_task_index_exists(self, verification_db):
        db = sqlite3.connect(str(verification_db))
        rows = db.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND name='idx_parent_task'"
        ).fetchall()
        db.close()
        assert len(rows) == 1


# ===========================================================================
# complete_task integration (backward compat + new behavior)
# ===========================================================================


class TestCompleteTaskIntegration:

    def test_backward_compat_no_work_output(self, verification_db):
        """complete_task without work_output still marks tasks done."""
        from aibrain.core.companies import complete_task
        task = _make_task(description="1. Do the thing")
        # Note: pass output=None explicitly so verification is skipped
        result = complete_task(task["id"], quality_score=0.9)
        assert result.get("status") == "done"
        # No verification key expected (skipped)
        assert "verification" not in result or result.get("verification") is None

    def test_complete_task_with_work_output_runs_verification(self, verification_db):
        from aibrain.core.companies import complete_task
        task = _make_task(description="1. Write the module")
        result = complete_task(
            task["id"],
            quality_score=0.9,
            work_output="Module was written successfully.",
        )
        assert "verification" in result
        assert result["verification"]["verification_status"] == "verified"

    def test_require_verification_blocks_failing(self, verification_db):
        """When require_verification=True and criteria not met, task stays open."""
        from aibrain.core.companies import complete_task
        task = _make_task(description=(
            "1. Requirement alpha quantum flux\n"
            "2. Requirement beta neutron drive\n"
        ))
        result = complete_task(
            task["id"],
            quality_score=0.9,
            work_output="totally unrelated output",
            require_verification=True,
        )
        assert result.get("status") == "not_completed"
        assert result.get("reason") == "verification_failed"
        # Task should still be open
        db = sqlite3.connect(str(verification_db))
        row = db.execute(
            "SELECT status FROM company_issues WHERE id=?", (task["id"],)
        ).fetchone()
        db.close()
        assert row[0] != "done"

    def test_complete_task_attaches_followup_ids(self, verification_db):
        from aibrain.core.companies import complete_task
        task = _make_task(description="Please ship the feature")
        result = complete_task(
            task["id"],
            quality_score=0.9,
            work_output="Shipped. TODO: follow up with marketing.",
        )
        assert "follow_up_tasks" in result
        assert len(result["follow_up_tasks"]) >= 1
