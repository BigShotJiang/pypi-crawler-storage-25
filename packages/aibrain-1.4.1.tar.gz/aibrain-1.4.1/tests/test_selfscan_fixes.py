"""
Tests for self-scan security fixes (Apr 10 findings).

CRITICAL 1: Config endpoint no longer leaks secrets
CRITICAL 2: MCP server registration validates commands
HIGH 3: Localhost enforcement on all sensitive endpoints
HIGH 4: SSRF validation on all URL fields in config update
MEDIUM 5: Company endpoints require localhost
BUG 6: MCP delete no longer crashes on missing mcp_tool_cache table
"""

import json
import os
import re
import sys
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch, AsyncMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))


# ---------------------------------------------------------------------------
# CRITICAL 1: Config endpoint strips secrets entirely
# ---------------------------------------------------------------------------

class TestConfigSecretStripping:
    """GET /api/agent/config must NEVER return secret values — only booleans."""

    def test_is_secret_key_explicit_names(self):
        from aibrain_api import _is_secret_key
        assert _is_secret_key("github_token") is True
        assert _is_secret_key("anthropic_api_key") is True
        assert _is_secret_key("openai_api_key") is True
        assert _is_secret_key("smtp_pass") is True
        assert _is_secret_key("telegram_bot_token") is True

    def test_is_secret_key_suffix_matching(self):
        from aibrain_api import _is_secret_key
        assert _is_secret_key("some_new_token") is True
        assert _is_secret_key("custom_api_key") is True
        assert _is_secret_key("db_password") is True
        assert _is_secret_key("oauth_secret") is True

    def test_is_secret_key_rejects_non_secrets(self):
        from aibrain_api import _is_secret_key
        assert _is_secret_key("theme") is False
        assert _is_secret_key("llm_provider") is False
        assert _is_secret_key("user_name") is False
        assert _is_secret_key("ollama_url") is False
        assert _is_secret_key("ollama_model") is False

    def test_config_response_has_booleans_not_values(self):
        """Simulate what get_config() does with secret keys."""
        from aibrain_api import _is_secret_key, _ALLOWED_SETTINGS

        fake_cfg = {
            "github_token": "ghp_abcdef1234567890abcdef1234567890abcd",
            "anthropic_api_key": "sk-ant-abc123xyz",
            "openai_api_key": "",
            "smtp_pass": "mypassword",
            "telegram_bot_token": "12345:ABCDEfghij",
            "weather_api_key": "abc123",
            "theme": "dark",
            "llm_provider": "auto",
            "user_name": "Matt",
        }

        safe = {}
        for k in _ALLOWED_SETTINGS:
            val = fake_cfg.get(k)
            if val is None:
                continue
            if _is_secret_key(k):
                safe[k] = True if val else False
            else:
                safe[k] = val

        # Secrets should be booleans
        assert safe["github_token"] is True
        assert safe["anthropic_api_key"] is True
        assert safe["openai_api_key"] is False  # empty string -> False
        assert safe["smtp_pass"] is True
        assert safe["telegram_bot_token"] is True
        assert safe["weather_api_key"] is True

        # Non-secrets should retain values
        assert safe["theme"] == "dark"
        assert safe["llm_provider"] == "auto"
        assert safe["user_name"] == "Matt"

        # No actual secret values in response
        for k, v in safe.items():
            if _is_secret_key(k):
                assert isinstance(v, bool), f"Secret {k} should be bool, got {type(v)}: {v}"
                assert v is True or v is False

    def test_no_partial_token_leak(self):
        """Old code leaked first 4 + last 4 chars.  New code must not."""
        from aibrain_api import _is_secret_key

        token = "ghp_" + "a" * 36  # noqa:HARDCODED_SECRET — fake test token
        # The old masking would produce "ghp_...abcd" — verify this no longer happens
        if _is_secret_key("github_token"):
            result = True if token else False
            assert "ghp" not in str(result)
            assert "abcd" not in str(result)
            assert result is True


# ---------------------------------------------------------------------------
# CRITICAL 2: MCP server command injection prevention
# ---------------------------------------------------------------------------

class TestMcpCommandValidation:
    """POST /api/agent/mcp/servers must validate command against whitelist."""

    def test_allowed_commands_exist(self):
        from aibrain_api import _MCP_ALLOWED_COMMANDS
        assert "python" in _MCP_ALLOWED_COMMANDS
        assert "node" in _MCP_ALLOWED_COMMANDS
        assert "npx" in _MCP_ALLOWED_COMMANDS
        assert "uvx" in _MCP_ALLOWED_COMMANDS

    def test_disallowed_commands_absent(self):
        from aibrain_api import _MCP_ALLOWED_COMMANDS
        # Shells and arbitrary binaries must NOT be in the whitelist
        assert "bash" not in _MCP_ALLOWED_COMMANDS
        assert "sh" not in _MCP_ALLOWED_COMMANDS
        assert "cmd" not in _MCP_ALLOWED_COMMANDS
        assert "cmd.exe" not in _MCP_ALLOWED_COMMANDS
        assert "powershell" not in _MCP_ALLOWED_COMMANDS
        assert "curl" not in _MCP_ALLOWED_COMMANDS
        assert "wget" not in _MCP_ALLOWED_COMMANDS
        assert "nc" not in _MCP_ALLOWED_COMMANDS

    def test_shell_metachar_regex_catches_injection(self):
        from aibrain_api import _SHELL_META
        dangerous = [
            "python; rm -rf /",
            "python && echo pwned",
            "python | cat /etc/passwd",
            "python `whoami`",
            "python $(id)",
            "python\nwhoami",
        ]
        for cmd in dangerous:
            assert _SHELL_META.search(cmd) is not None, f"Should catch: {cmd}"

    def test_shell_metachar_regex_allows_safe(self):
        from aibrain_api import _SHELL_META
        safe = [
            "python",
            "node",
            "-c",
            "server.py",
            "--port=3000",
            "/usr/bin/python3",
            "C:\\Python311\\python.exe",
            "-m",
            "my_mcp_server",
        ]
        for arg in safe:
            assert _SHELL_META.search(arg) is None, f"Should allow: {arg}"


# ---------------------------------------------------------------------------
# HIGH 4: SSRF validation on all URL fields in config update
# ---------------------------------------------------------------------------

class TestConfigUrlValidation:
    """PUT /api/agent/config validates ALL *_url fields, not just ollama_url."""

    def test_url_suffix_detection(self):
        """Any key ending in _url should trigger validation."""
        url_keys = ["ollama_url", "custom_service_url", "webhook_url"]
        for k in url_keys:
            assert k.endswith("_url"), f"{k} should match _url suffix"

    def test_non_url_keys_not_validated(self):
        """Keys not ending in _url should not trigger URL validation."""
        non_url = ["theme", "user_name", "llm_provider", "ollama_model"]
        for k in non_url:
            assert not k.endswith("_url"), f"{k} should not match _url suffix"


# ---------------------------------------------------------------------------
# MEDIUM 5: Company endpoints require localhost
# ---------------------------------------------------------------------------

class TestCompanyLocalhostEnforcement:
    """Company API mutating endpoints check _require_localhost."""

    def test_require_localhost_rejects_external_ip(self):
        from companies_api import _require_localhost
        mock_request = MagicMock()
        mock_request.client.host = "192.168.1.100"

        with pytest.raises(Exception) as exc_info:
            _require_localhost(mock_request)
        assert "403" in str(exc_info.value.status_code) or "localhost" in str(exc_info.value.detail)

    def test_require_localhost_accepts_127(self):
        from companies_api import _require_localhost
        mock_request = MagicMock()
        mock_request.client.host = "127.0.0.1"
        # Should not raise
        _require_localhost(mock_request)

    def test_require_localhost_accepts_ipv6_loopback(self):
        from companies_api import _require_localhost
        mock_request = MagicMock()
        mock_request.client.host = "::1"
        _require_localhost(mock_request)

    def test_require_localhost_accepts_localhost_string(self):
        from companies_api import _require_localhost
        mock_request = MagicMock()
        mock_request.client.host = "localhost"
        _require_localhost(mock_request)


# ---------------------------------------------------------------------------
# BUG 6: MCP delete no longer crashes on missing mcp_tool_cache
# ---------------------------------------------------------------------------

class TestMcpDeleteNoCrash:
    """DELETE /api/agent/mcp/servers/{name} handles missing mcp_tool_cache table."""

    def test_delete_without_tool_cache_table(self, tmp_path):
        """Deleting a server when mcp_tool_cache doesn't exist should not crash."""
        db_path = tmp_path / "test.db"
        db = sqlite3.connect(str(db_path))
        db.execute("""
            CREATE TABLE mcp_servers (
                name TEXT PRIMARY KEY,
                config_json TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.execute(
            "INSERT INTO mcp_servers (name, config_json) VALUES (?, ?)",
            ("test-server", '{"command": "python"}'),
        )
        db.commit()

        # Delete should work even without mcp_tool_cache table
        db.execute("DELETE FROM mcp_servers WHERE name=?", ("test-server",))
        try:
            db.execute("DELETE FROM mcp_tool_cache WHERE server_name=?", ("test-server",))
            assert False, "Should have raised OperationalError"
        except sqlite3.OperationalError:
            pass  # Expected — table doesn't exist

        db.commit()
        db.close()

        # Verify deletion worked
        db = sqlite3.connect(str(db_path))
        count = db.execute("SELECT COUNT(*) FROM mcp_servers").fetchone()[0]
        assert count == 0
        db.close()


# ---------------------------------------------------------------------------
# Integration: MCP server registration end-to-end validation
# ---------------------------------------------------------------------------

class TestMcpServerRegistrationValidation:
    """End-to-end checks that mcp_add_server validates properly."""

    def test_rejects_bash_command(self):
        """bash is not in the allowed commands whitelist."""
        from aibrain_api import _MCP_ALLOWED_COMMANDS
        assert "bash" not in _MCP_ALLOWED_COMMANDS

    def test_rejects_cmd_exe(self):
        from aibrain_api import _MCP_ALLOWED_COMMANDS
        assert "cmd.exe" not in _MCP_ALLOWED_COMMANDS

    def test_accepts_python(self):
        from aibrain_api import _MCP_ALLOWED_COMMANDS
        assert "python" in _MCP_ALLOWED_COMMANDS
        assert "python.exe" in _MCP_ALLOWED_COMMANDS
        assert "python3" in _MCP_ALLOWED_COMMANDS

    def test_accepts_node(self):
        from aibrain_api import _MCP_ALLOWED_COMMANDS
        assert "node" in _MCP_ALLOWED_COMMANDS
        assert "node.exe" in _MCP_ALLOWED_COMMANDS

    def test_path_stripping_extracts_basename(self):
        """Command validation should strip path prefix to get bare executable name."""
        import ntpath
        import posixpath
        # Unix path
        assert posixpath.basename("/usr/bin/python3") == "python3"
        # Windows path
        assert ntpath.basename("C:\\Python311\\python.exe") == "python.exe"
        # Combined (ntpath.basename of posixpath result)
        assert ntpath.basename(posixpath.basename("/usr/local/bin/node")) == "node"
