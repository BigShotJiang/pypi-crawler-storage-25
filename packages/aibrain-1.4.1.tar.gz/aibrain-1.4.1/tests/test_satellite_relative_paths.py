"""
Tests for satellite DB relative path storage.

Verifies that absolute paths are converted to relative on register,
and resolved back to absolute on read.
"""

import os
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture()
def db_conn():
    """Create a fresh, isolated SQLite DB with the full AIBrain schema."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="aibrain_sattest_")
    os.close(fd)

    import aibrain_db
    original_path = aibrain_db.DB_PATH
    original_conn = aibrain_db._conn
    original_sat_conns = dict(aibrain_db._satellite_conns)

    aibrain_db.DB_PATH = Path(path)
    aibrain_db._conn = None
    aibrain_db._satellite_conns.clear()

    conn = aibrain_db.get_db()
    yield conn

    try:
        conn.close()
    except Exception:
        pass
    aibrain_db._conn = original_conn
    aibrain_db.DB_PATH = original_path
    aibrain_db._satellite_conns.clear()
    aibrain_db._satellite_conns.update(original_sat_conns)

    try:
        os.unlink(path)
    except OSError:
        pass
    for ext in ("-wal", "-shm"):
        try:
            os.unlink(path + ext)
        except OSError:
            pass


class TestRelativePathConversion:
    """Test _to_relative_satellite_path and _to_absolute_satellite_path."""

    def test_absolute_under_root_becomes_relative(self):
        from aibrain_db import _to_relative_satellite_path, AIBRAIN_ROOT
        abs_path = str(AIBRAIN_ROOT / "satellites" / "security.db")
        rel = _to_relative_satellite_path(abs_path)
        assert not os.path.isabs(rel)
        assert rel == os.path.join("satellites", "security.db")

    def test_already_relative_stays_relative(self):
        from aibrain_db import _to_relative_satellite_path
        rel_path = "satellites/security.db"
        assert _to_relative_satellite_path(rel_path) == rel_path

    def test_absolute_outside_root_stays_absolute(self):
        from aibrain_db import _to_relative_satellite_path
        outside = "/tmp/other/data.db"
        result = _to_relative_satellite_path(outside)
        assert result == outside

    def test_relative_resolves_to_absolute(self):
        from aibrain_db import _to_absolute_satellite_path, AIBRAIN_ROOT
        rel = "satellites/test.db"
        abs_path = _to_absolute_satellite_path(rel)
        assert os.path.isabs(abs_path)
        assert abs_path == str(AIBRAIN_ROOT / "satellites" / "test.db")

    def test_roundtrip(self):
        """Absolute -> relative -> absolute roundtrip preserves path."""
        from aibrain_db import _to_relative_satellite_path, _to_absolute_satellite_path, AIBRAIN_ROOT
        original = str(AIBRAIN_ROOT / "data" / "findings.db")
        rel = _to_relative_satellite_path(original)
        restored = _to_absolute_satellite_path(rel)
        assert Path(restored) == Path(original)


class TestSatelliteRegisterStoresRelative:
    """Test that satellite_register converts abs paths to relative."""

    def test_register_converts_absolute_to_relative(self, db_conn):
        import aibrain_db

        # Create a temp satellite DB file under AIBRAIN_ROOT
        sat_dir = aibrain_db.AIBRAIN_ROOT / "test_satellites"
        sat_dir.mkdir(exist_ok=True)
        sat_path = sat_dir / "test_sat.db"
        sat_path.touch()

        try:
            aibrain_db.satellite_register(
                "test_sat",
                str(sat_path),  # absolute path
                "Test satellite",
                ["test_type"],
                "test",
            )

            # Check stored path is relative
            row = db_conn.execute(
                "SELECT db_path FROM satellite_dbs WHERE name='test_sat'"
            ).fetchone()
            assert row is not None
            stored = row["db_path"]
            assert not os.path.isabs(stored), f"Expected relative, got: {stored}"
        finally:
            try:
                sat_path.unlink()
                sat_dir.rmdir()
            except Exception:
                pass


class TestMigrationConvertsExisting:
    """Test that _migrate_schema converts existing absolute paths."""

    def test_migration_converts_absolute_entries(self, db_conn):
        import aibrain_db

        # Insert a satellite with absolute path directly
        abs_path = str(aibrain_db.AIBRAIN_ROOT / "old_sat.db")
        db_conn.execute("""
            INSERT INTO satellite_dbs (name, db_path, description, memory_types, search_keywords, active)
            VALUES ('old_sat', ?, 'Old satellite', '["finding"]', 'security', 1)
        """, (abs_path,))
        db_conn.commit()

        # Run migration
        aibrain_db._migrate_schema(db_conn)

        # Verify it was converted to relative
        row = db_conn.execute(
            "SELECT db_path FROM satellite_dbs WHERE name='old_sat'"
        ).fetchone()
        assert row is not None
        assert not os.path.isabs(row["db_path"]), \
            f"Migration should have converted to relative, got: {row['db_path']}"
