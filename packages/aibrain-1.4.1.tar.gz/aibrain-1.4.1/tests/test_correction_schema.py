"""
Tests for correction_schema — structured fields for correction memories.

Tests:
  1. Severity classification
  2. Error category classification
  3. Wrong action extraction
  4. Correct action extraction
  5. Full field extraction
  6. Content enrichment (append JSON)
  7. Metadata parsing (round-trip)
  8. No double-enrichment
  9. Strip metadata
  10. Integration with HARD RULE content
"""

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from aibrain.core.correction_schema import (
    _CORRECTION_MARKER,
    classify_error_category,
    classify_severity,
    enrich_correction,
    extract_correct_action,
    extract_correction_fields,
    extract_wrong_action,
    parse_correction_metadata,
    strip_correction_metadata,
)


# ---------------------------------------------------------------------------
# Test 1: Severity classification
# ---------------------------------------------------------------------------

class TestSeverityClassification:
    def test_critical_for_hard_rule(self):
        assert classify_severity("HARD RULE: Never commit credentials") == "critical"

    def test_critical_for_never(self):
        assert classify_severity("NEVER delete files directly") == "critical"

    def test_major_for_broken(self):
        assert classify_severity("The deployment was broken after the change") == "major"

    def test_minor_for_style(self):
        assert classify_severity("Naming convention preference: use snake_case") == "minor"

    def test_info_for_reminder(self):
        assert classify_severity("Just a reminder to check the logs") == "info"

    def test_default_minor(self):
        assert classify_severity("Something happened with the system") == "minor"


# ---------------------------------------------------------------------------
# Test 2: Error category classification
# ---------------------------------------------------------------------------

class TestErrorCategoryClassification:
    def test_security_category(self):
        assert classify_error_category("Credential leaked in commit") == "security"

    def test_git_category(self):
        assert classify_error_category("Wrong branch was pushed to remote") == "git"

    def test_aibrain_category(self):
        assert classify_error_category("Memory dedup threshold was too low") == "aibrain"

    def test_infrastructure_category(self):
        assert classify_error_category("Docker container failed to deploy") == "infrastructure"

    def test_deletion_category(self):
        assert classify_error_category("Should not rm -rf the archive directory") == "deletion"

    def test_other_for_unclassifiable(self):
        assert classify_error_category("The weather was nice today") == "other"


# ---------------------------------------------------------------------------
# Test 3: Wrong action extraction
# ---------------------------------------------------------------------------

class TestWrongActionExtraction:
    def test_extracts_never_pattern(self):
        content = "Never commit secrets to git repos. Always use env vars."
        result = extract_wrong_action(content)
        assert "commit secrets" in result.lower()

    def test_extracts_mistake_was(self):
        content = "The mistake was pushing to the wrong remote repository."
        result = extract_wrong_action(content)
        assert "remote" in result.lower()

    def test_returns_empty_for_no_match(self):
        result = extract_wrong_action("All systems nominal")
        assert result == ""


# ---------------------------------------------------------------------------
# Test 4: Correct action extraction
# ---------------------------------------------------------------------------

class TestCorrectActionExtraction:
    def test_extracts_should_pattern(self):
        content = "Should always verify the deployment before announcing."
        result = extract_correct_action(content)
        assert "verify" in result.lower()

    def test_extracts_hard_rule(self):
        content = "HARD RULE: Archive files before deleting them."
        result = extract_correct_action(content)
        assert "archive" in result.lower()

    def test_returns_empty_for_no_match(self):
        result = extract_correct_action("Nothing specific here")
        assert result == ""


# ---------------------------------------------------------------------------
# Test 5: Full field extraction
# ---------------------------------------------------------------------------

class TestFullExtraction:
    def test_extracts_all_fields(self):
        content = (
            "HARD RULE: Never commit credentials to git. "
            "The mistake was hardcoding the API token in config.py. "
            "Should always use environment variables loaded from .env."
        )
        fields = extract_correction_fields(content)
        assert fields["error_category"] == "security"
        assert fields["severity"] == "critical"
        assert "wrong_action" in fields
        assert "correct_action" in fields

    def test_all_keys_present(self):
        fields = extract_correction_fields("some text")
        assert set(fields.keys()) == {"error_category", "wrong_action", "correct_action", "severity"}


# ---------------------------------------------------------------------------
# Test 6: Content enrichment
# ---------------------------------------------------------------------------

class TestEnrichment:
    def test_appends_json_metadata(self):
        enriched = enrich_correction("test_fix", "Never delete files without archiving")
        assert _CORRECTION_MARKER in enriched
        # Original content preserved
        assert enriched.startswith("Never delete files without archiving")
        # JSON is valid
        _, json_part = enriched.split(_CORRECTION_MARKER, 1)
        data = json.loads(json_part)
        assert data["name"] == "test_fix"
        assert data["error_category"] == "deletion"

    def test_no_double_enrichment(self):
        content = "Fix the bug" + _CORRECTION_MARKER + '{"already":"enriched"}'
        result = enrich_correction("test", content)
        assert result == content  # unchanged


# ---------------------------------------------------------------------------
# Test 7: Metadata round-trip
# ---------------------------------------------------------------------------

class TestMetadataRoundTrip:
    def test_parse_enriched_content(self):
        enriched = enrich_correction("cred_leak", "HARD RULE: Never push credentials to git")
        meta = parse_correction_metadata(enriched)
        assert meta is not None
        assert meta["name"] == "cred_leak"
        assert meta["severity"] == "critical"
        assert meta["error_category"] == "security"

    def test_parse_returns_none_for_plain(self):
        assert parse_correction_metadata("Just plain text") is None


# ---------------------------------------------------------------------------
# Test 8: Strip metadata
# ---------------------------------------------------------------------------

class TestStripMetadata:
    def test_strips_json_block(self):
        original = "The original correction content"
        enriched = enrich_correction("test", original)
        stripped = strip_correction_metadata(enriched)
        assert stripped == original

    def test_strip_noop_for_plain(self):
        plain = "No metadata here"
        assert strip_correction_metadata(plain) == plain


# ---------------------------------------------------------------------------
# Test 9: Git-domain corrections
# ---------------------------------------------------------------------------

class TestGitDomainCorrections:
    def test_git_push_correction(self):
        content = "HARD RULE: NEVER push internal code to the sindecker repo. Only DeckerOps."
        fields = extract_correction_fields(content)
        assert fields["error_category"] == "git"
        assert fields["severity"] == "critical"


# ---------------------------------------------------------------------------
# Test 10: Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_empty_content(self):
        fields = extract_correction_fields("")
        assert fields["error_category"] == "other"
        assert fields["severity"] == "minor"
        assert fields["wrong_action"] == ""
        assert fields["correct_action"] == ""

    def test_very_long_content_truncates_actions(self):
        long_text = "Never " + "x" * 300 + "."
        fields = extract_correction_fields(long_text)
        assert len(fields["wrong_action"]) <= 200
