"""test_token_to_cents_conversion.py — regression for task #11.

Goal: verify that cost_cents_equivalent is a real positive number on every
CLI-backend SuperWorker run where the envelope carries token counts, AND stays
honest-None when it doesn't. Also verifies the execution_log + superworker_runs
columns actually persist the new fields.

The canonical DB is NEVER touched — every test uses tmp_path + monkeypatched
AIBRAIN_ROOT, per the acceptance criteria.
"""
from __future__ import annotations

import json
import sqlite3
import subprocess
import sys
import types
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from aibrain.core import pricing, superworker
from aibrain.core.pricing import (
    compute_equivalent_cents,
    compute_equivalent_cents_from_sdk_usage,
    extract_tokens_from_cli_envelope,
    match_rate,
)
from aibrain.core.superworker import _run_llm, _run_via_claude_cli, invoke


# ---------------------------------------------------------------------------
# Rate table + match_rate
# ---------------------------------------------------------------------------

def test_rate_table_has_opus_sonnet_haiku():
    assert match_rate("claude-opus-4-6[1m]") is not None
    assert match_rate("claude-sonnet-4-20250514") is not None
    assert match_rate("claude-haiku-4-5-20251001") is not None


def test_match_rate_rejects_unknown_models():
    assert match_rate("gpt-4o") is None
    assert match_rate("llama-3.3-70b") is None
    assert match_rate(None) is None
    assert match_rate("") is None


def test_opus_rate_is_highest_sonnet_middle_haiku_cheapest():
    """Relative rate ordering — opus > sonnet > haiku."""
    opus = match_rate("claude-opus-4-6[1m]")
    sonnet = match_rate("claude-sonnet-4-20250514")
    haiku = match_rate("claude-haiku-4-5-20251001")
    assert opus.input_cents_per_m > sonnet.input_cents_per_m > haiku.input_cents_per_m
    assert opus.output_cents_per_m > sonnet.output_cents_per_m > haiku.output_cents_per_m


# ---------------------------------------------------------------------------
# compute_equivalent_cents — core math
# ---------------------------------------------------------------------------

def test_compute_equivalent_cents_sonnet_known_math():
    """Sonnet 4.6: $3/M input, $15/M output.
    1M input + 1M output = $3 + $15 = $18 = 1800 cents."""
    cents = compute_equivalent_cents(
        model="claude-sonnet-4-20250514",
        input_tokens=1_000_000,
        output_tokens=1_000_000,
    )
    assert cents == 1800


def test_compute_equivalent_cents_opus_higher_than_sonnet():
    """Same token counts — opus must cost more than sonnet."""
    opus_cents = compute_equivalent_cents(
        model="claude-opus-4-6[1m]",
        input_tokens=100_000,
        output_tokens=100_000,
    )
    sonnet_cents = compute_equivalent_cents(
        model="claude-sonnet-4-20250514",
        input_tokens=100_000,
        output_tokens=100_000,
    )
    assert opus_cents > sonnet_cents > 0


def test_compute_equivalent_cents_returns_none_on_unknown_model():
    """Honest-rubric: unknown model → None, not 0."""
    assert compute_equivalent_cents(
        model="gpt-4o",
        input_tokens=1000,
        output_tokens=1000,
    ) is None


def test_compute_equivalent_cents_returns_none_when_tokens_missing():
    """Honest-rubric: missing input or output → None."""
    assert compute_equivalent_cents(
        model="claude-sonnet-4-20250514",
        input_tokens=None,
        output_tokens=1000,
    ) is None
    assert compute_equivalent_cents(
        model="claude-sonnet-4-20250514",
        input_tokens=1000,
        output_tokens=None,
    ) is None


def test_compute_equivalent_cents_cache_read_cheaper_than_fresh_input():
    """Cache-read tokens should discount vs equivalent fresh-input tokens."""
    fresh = compute_equivalent_cents(
        model="claude-sonnet-4-20250514",
        input_tokens=1_000_000,
        output_tokens=0,
    )
    cached = compute_equivalent_cents(
        model="claude-sonnet-4-20250514",
        input_tokens=0,
        output_tokens=0,
        cache_read_tokens=1_000_000,
    )
    assert fresh > cached > 0


def test_compute_equivalent_cents_zero_tokens_is_zero_not_none():
    """Zero-token call — really zero, not honest-None."""
    assert compute_equivalent_cents(
        model="claude-sonnet-4-20250514",
        input_tokens=0,
        output_tokens=0,
    ) == 0


# ---------------------------------------------------------------------------
# extract_tokens_from_cli_envelope
# ---------------------------------------------------------------------------

def test_extract_tokens_from_cli_envelope_happy_path():
    envelope = {
        "type": "result",
        "result": "ok",
        "modelUsage": {
            "claude-sonnet-4-20250514": {
                "inputTokens": 500,
                "outputTokens": 200,
                "cacheReadInputTokens": 100,
                "cacheCreationInputTokens": 50,
            }
        },
    }
    model, tokens = extract_tokens_from_cli_envelope(envelope)
    assert model == "claude-sonnet-4-20250514"
    assert tokens["input_tokens"] == 500
    assert tokens["output_tokens"] == 200
    assert tokens["cache_read_tokens"] == 100
    assert tokens["cache_write_tokens"] == 50


def test_extract_tokens_from_cli_envelope_missing_modelusage():
    """No modelUsage key → (None, {}) — caller converts to cost_cents_equivalent=None."""
    model, tokens = extract_tokens_from_cli_envelope({"result": "ok"})
    assert model is None
    assert tokens == {}


def test_extract_tokens_handles_partial_usage():
    """Only inputTokens/outputTokens present (no cache fields)."""
    envelope = {
        "modelUsage": {
            "claude-sonnet-4-20250514": {"inputTokens": 100, "outputTokens": 50}
        }
    }
    model, tokens = extract_tokens_from_cli_envelope(envelope)
    assert tokens["input_tokens"] == 100
    assert tokens["output_tokens"] == 50
    assert tokens["cache_read_tokens"] == 0
    assert tokens["cache_write_tokens"] == 0


# ---------------------------------------------------------------------------
# _run_via_claude_cli returns 4-tuple with equivalent cost
# ---------------------------------------------------------------------------

def _fake_completed(returncode: int, stdout: str = "", stderr: str = ""):
    cp = MagicMock(spec=subprocess.CompletedProcess)
    cp.returncode = returncode
    cp.stdout = stdout
    cp.stderr = stderr
    return cp


@pytest.fixture(autouse=True)
def _pin_cli_path(monkeypatch):
    """Pin the fake claude CLI path so tests that call _run_via_claude_cli
    directly don't pick up the real binary on the dev machine."""
    monkeypatch.setattr(superworker, "_CLAUDE_CLI_AVAILABLE", None)
    monkeypatch.setattr(superworker, "_CLAUDE_CLI_PATH", "/fake/claude")


def test_run_via_cli_returns_real_equivalent_cents_for_subscription_run(monkeypatch):
    """Acceptance #1: cost_cents_equivalent is a real positive number on a
    CLI-backend run. cost_cents_actual stays 0 (honest about subscription)."""
    envelope = json.dumps({
        "type": "result",
        "is_error": False,
        "result": "ok",
        "modelUsage": {
            "claude-sonnet-4-20250514": {
                "inputTokens": 50_000,
                "outputTokens": 10_000,
                "cacheReadInputTokens": 0,
                "cacheCreationInputTokens": 0,
            }
        },
    })
    monkeypatch.setattr(
        superworker.subprocess, "run",
        lambda *a, **k: _fake_completed(0, stdout=envelope),
    )

    text, model_used, cost_actual, cost_equivalent = _run_via_claude_cli(
        "prompt", "system", "claude-sonnet-4-20250514",
    )

    assert text == "ok"
    assert model_used == "claude-sonnet-4-20250514"
    # Acceptance #2: actual stays 0 on subscription path
    assert cost_actual == 0
    # Acceptance #1: equivalent is a real positive int
    # 50k input * 300/M + 10k output * 1500/M = 15 + 15 = 30 cents
    assert cost_equivalent == 30
    assert isinstance(cost_equivalent, int)


def test_run_via_cli_honest_none_when_envelope_lacks_tokens(monkeypatch):
    """Acceptance #6: missing envelope field → cost_cents_equivalent = None, never 0."""
    envelope = json.dumps({
        "type": "result",
        "is_error": False,
        "result": "ok",
        # no modelUsage
    })
    monkeypatch.setattr(
        superworker.subprocess, "run",
        lambda *a, **k: _fake_completed(0, stdout=envelope),
    )

    text, _, cost_actual, cost_equivalent = _run_via_claude_cli(
        "p", "s", "claude-sonnet-4-20250514",
    )
    assert cost_actual == 0
    assert cost_equivalent is None, (
        "honest-rubric: missing token signal must be None, NEVER 0"
    )


def test_run_via_cli_honest_none_on_unknown_model(monkeypatch):
    """Non-Claude model slug in envelope → equivalent = None."""
    envelope = json.dumps({
        "type": "result",
        "is_error": False,
        "result": "ok",
        "modelUsage": {
            "gpt-4o": {"inputTokens": 1000, "outputTokens": 500}
        },
    })
    monkeypatch.setattr(
        superworker.subprocess, "run",
        lambda *a, **k: _fake_completed(0, stdout=envelope),
    )
    _, model_used, cost_actual, cost_equivalent = _run_via_claude_cli(
        "p", "s", "gpt-4o",
    )
    assert model_used == "gpt-4o"
    assert cost_actual == 0
    assert cost_equivalent is None


# ---------------------------------------------------------------------------
# invoke() propagates both fields
# ---------------------------------------------------------------------------

def test_invoke_populates_cost_cents_equivalent_via_cli(monkeypatch):
    """Full invoke() path: CLI backend → result.cost_cents_equivalent is set,
    cost_cents_actual is 0, and to_harness_dict carries both."""
    envelope = json.dumps({
        "type": "result",
        "is_error": False,
        "result": (
            '<!-- superworker_json: {"synthesis": "s", "compatible_views": [], '
            '"conflicts": [], "overrode": [], "synthesis_confidence": 0.7, '
            '"eval_score": 0.7, "per_lens": []} -->'
        ),
        "modelUsage": {
            "claude-sonnet-4-20250514": {
                "inputTokens": 100_000,
                "outputTokens": 20_000,
            }
        },
    })
    # Force CLI path to be used
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: True)
    monkeypatch.setattr(
        superworker.subprocess, "run",
        lambda *a, **k: _fake_completed(0, stdout=envelope),
    )
    # Don't touch the real DB — the fixture below handles this, but we ALSO
    # no-op _record_run so the superworker_runs path doesn't write here
    # (the dedicated persistence test does that separately).
    monkeypatch.setattr(superworker, "_record_run", lambda r: None)

    result = invoke("arch review", task_type="architecture_review", lens_count=5)

    assert result.success is True
    assert result.cost_cents == 0  # subscription path
    assert result.cost_cents_actual == 0
    # 100k * 300/M input + 20k * 1500/M output = 30 + 30 = 60 cents
    assert result.cost_cents_equivalent == 60
    d = result.to_harness_dict()
    assert d["_cost_cents_actual"] == 0
    assert d["_cost_cents_equivalent"] == 60


# ---------------------------------------------------------------------------
# Persistence: both columns land in execution_log + superworker_runs
# ---------------------------------------------------------------------------

@pytest.fixture()
def isolated_brain_db(tmp_path, monkeypatch):
    """Point AIBRAIN_ROOT at tmp_path so no test ever touches the canonical DB.

    Returns the Path to the tmp DB file (which will be created on first write).
    """
    brain_root = tmp_path / "brain"
    brain_root.mkdir()
    monkeypatch.setenv("AIBRAIN_ROOT", str(brain_root))
    # Force re-resolution of AIBRAIN_ROOT in modules that cache it
    import importlib
    import aibrain_db
    importlib.reload(aibrain_db)
    # harness imports AIBRAIN_ROOT lazily inside functions so no reload needed
    db_path = brain_root / "aibrain.db"
    return db_path


def test_superworker_runs_persists_both_cost_columns(isolated_brain_db, monkeypatch):
    """_record_run must write cost_cents_actual + cost_cents_equivalent into
    superworker_runs. Fresh DB → schema has both columns."""
    from aibrain.core.superworker import SuperWorkerResult, _record_run

    r = SuperWorkerResult(
        task="persistence test",
        task_type="architecture_review",
        lenses_consulted=["Decker", "Schneier"],
        routing_reason="test",
        per_lens=[],
        synthesis="s",
        compatible_views=[],
        conflicts=[],
        overrode=[],
        synthesis_confidence=0.8,
        eval_score=0.8,
        raw_markdown="",
        parse_status="ok",
        warnings=[],
        cost_cents=0,
        cost_cents_actual=0,
        cost_cents_equivalent=42,
        model_used="claude-sonnet-4-20250514",
        duration_ms=100,
        success=True,
        run_id="test_persist_1",
    )
    _record_run(r)

    # Verify columns persisted
    db = sqlite3.connect(str(isolated_brain_db))
    cols = {row[1] for row in db.execute("PRAGMA table_info(superworker_runs)").fetchall()}
    assert "cost_cents_actual" in cols
    assert "cost_cents_equivalent" in cols

    row = db.execute(
        "SELECT cost_cents_actual, cost_cents_equivalent FROM superworker_runs WHERE run_id=?",
        ("test_persist_1",),
    ).fetchone()
    db.close()
    assert row is not None
    assert row[0] == 0
    assert row[1] == 42


def test_execution_log_persists_both_cost_columns(isolated_brain_db, monkeypatch):
    """harness._log_audit must write cost_cents_actual + cost_cents_equivalent
    into execution_log. Verified via a real execute() call with an action that
    self-reports both fields."""
    from aibrain.core.harness import HarnessConfig, execute

    def action():
        return {
            "ok": True,
            "_cost_cents": 0,
            "_cost_cents_actual": 0,
            "_cost_cents_equivalent": 77,
            "_model_used": "claude-sonnet-4-20250514",
            "_self_score": 0.8,
        }

    result = execute(
        task="token_to_cents_regression",
        action=action,
        config=HarnessConfig(task_type="judgment", actor="pytest"),
    )

    assert result.success is True
    assert result.cost_cents_actual == 0
    assert result.cost_cents_equivalent == 77

    # Verify the row landed in the tmp DB
    db = sqlite3.connect(str(isolated_brain_db))
    cols = {row[1] for row in db.execute("PRAGMA table_info(execution_log)").fetchall()}
    assert "cost_cents_actual" in cols
    assert "cost_cents_equivalent" in cols

    row = db.execute(
        "SELECT cost_cents_actual, cost_cents_equivalent, model_used "
        "FROM execution_log WHERE action=? ORDER BY created_at DESC LIMIT 1",
        ("token_to_cents_regression",),
    ).fetchone()
    db.close()
    assert row is not None
    assert row[0] == 0
    assert row[1] == 77
    assert row[2] == "claude-sonnet-4-20250514"


def test_execution_log_honest_none_when_equivalent_missing(isolated_brain_db):
    """Action doesn't self-report _cost_cents_equivalent → column stays NULL."""
    from aibrain.core.harness import HarnessConfig, execute

    def action():
        return {"ok": True, "_self_score": 0.7}  # no cost fields at all

    result = execute(
        task="no_cost_signal",
        action=action,
        config=HarnessConfig(task_type="judgment", actor="pytest"),
    )
    assert result.cost_cents_equivalent is None  # honest-None

    db = sqlite3.connect(str(isolated_brain_db))
    row = db.execute(
        "SELECT cost_cents_equivalent FROM execution_log "
        "WHERE action=? ORDER BY created_at DESC LIMIT 1",
        ("no_cost_signal",),
    ).fetchone()
    db.close()
    assert row is not None
    assert row[0] is None, "missing token signal must persist as NULL, not 0"


# ---------------------------------------------------------------------------
# aibrain usage CLI — reads execution_log and sums equivalent
# ---------------------------------------------------------------------------

def test_usage_report_sums_current_month_and_excludes_null_rows(isolated_brain_db):
    """collect_usage() must:
      - sum cost_cents_equivalent for rows with non-NULL values
      - count (not sum) rows where the value is NULL
      - never add NULL to the total"""
    from aibrain.core.harness import HarnessConfig, execute
    from aibrain.core.usage_report import collect_usage

    def action_with_cost(cost):
        def _a():
            return {"ok": True, "_cost_cents_actual": 0, "_cost_cents_equivalent": cost,
                    "_model_used": "claude-sonnet-4-20250514", "_self_score": 0.8}
        return _a

    def action_no_cost():
        return {"ok": True, "_self_score": 0.8}

    # Three measured rows (10, 20, 30 cents) + two unmeasured
    for c in (10, 20, 30):
        execute("u", action_with_cost(c), HarnessConfig(task_type="judgment", actor="pytest"))
    for _ in range(2):
        execute("u", action_no_cost, HarnessConfig(task_type="judgment", actor="pytest"))

    data = collect_usage(db_path=isolated_brain_db)
    assert "error" not in data
    assert data["total_rows"] >= 5
    # Sum only counts non-NULL rows
    assert data["sum_cents_equivalent"] == 60  # 10 + 20 + 30
    assert data["rows_with_equivalent"] >= 3
    assert data["rows_unmeasured_equivalent"] >= 2
