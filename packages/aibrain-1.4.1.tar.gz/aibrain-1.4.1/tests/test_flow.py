"""
Tests for the Flow engine — decorator-driven state machines.
"""

import json
import os
import sqlite3
import tempfile
import pytest
from pathlib import Path

# Ensure aibrain package is importable
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from aibrain.core.flow import (
    Flow, FlowState, start, listen, router, or_, and_,
    retry, timeout, SQLiteFlowPersistence, HumanFeedbackPending,
)


# ---------------------------------------------------------------------------
# State classes
# ---------------------------------------------------------------------------

class SimpleState(FlowState):
    steps: list = []
    value: int = 0


class RouterState(FlowState):
    path: str = ""
    value: int = 0


class ParallelState(FlowState):
    results: list = []


# ---------------------------------------------------------------------------
# Test: simple linear flow (start -> listen -> listen)
# ---------------------------------------------------------------------------

class LinearFlow(Flow[SimpleState]):
    @start()
    def begin(self):
        self.state.steps = ["begin"]
        self.state.value = 1

    @listen(begin)
    def middle(self):
        self.state.steps = self.state.steps + ["middle"]
        self.state.value = self.state.value + 1

    @listen(middle)
    def end(self):
        self.state.steps = self.state.steps + ["end"]
        self.state.value = self.state.value + 1


def test_linear_flow():
    flow = LinearFlow()
    result = flow.kickoff()
    assert result.steps == ["begin", "middle", "end"]
    assert result.value == 3


# ---------------------------------------------------------------------------
# Test: router with branching
# ---------------------------------------------------------------------------

class BranchingFlow(Flow[RouterState]):
    @start()
    def begin(self):
        self.state.path = ""

    @router(begin)
    def decide(self) -> str:
        self.state.value = 42
        return "good" if self.state.value > 10 else "bad"

    @listen("good")
    def handle_good(self):
        self.state.path = "took_good_path"

    @listen("bad")
    def handle_bad(self):
        self.state.path = "took_bad_path"


def test_router_branching_good():
    flow = BranchingFlow()
    result = flow.kickoff()
    assert result.path == "took_good_path"
    assert result.value == 42


class BranchingBadFlow(Flow[RouterState]):
    @start()
    def begin(self):
        self.state.path = ""

    @router(begin)
    def decide(self) -> str:
        self.state.value = 5
        return "good" if self.state.value > 10 else "bad"

    @listen("good")
    def handle_good(self):
        self.state.path = "took_good_path"

    @listen("bad")
    def handle_bad(self):
        self.state.path = "took_bad_path"


def test_router_branching_bad():
    flow = BranchingBadFlow()
    result = flow.kickoff()
    assert result.path == "took_bad_path"
    assert result.value == 5


# ---------------------------------------------------------------------------
# Test: or_() compound condition
# ---------------------------------------------------------------------------

class OrState(FlowState):
    triggered_by: str = ""
    final: bool = False


class OrFlow(Flow[OrState]):
    @start()
    def path_a(self):
        self.state.triggered_by = "a"

    @listen(or_(path_a, "external_trigger"))
    def converge(self):
        self.state.final = True


def test_or_condition():
    flow = OrFlow()
    result = flow.kickoff()
    # path_a fires, which triggers converge via or_
    assert result.final is True
    assert result.triggered_by == "a"


# ---------------------------------------------------------------------------
# Test: and_() compound condition
# ---------------------------------------------------------------------------

class AndState(FlowState):
    a_done: bool = False
    b_done: bool = False
    merged: bool = False


class AndFlow(Flow[AndState]):
    @start()
    def step_a(self):
        self.state.a_done = True

    @start()
    def step_b(self):
        self.state.b_done = True

    @listen(and_(step_a, step_b))
    def merge(self):
        self.state.merged = True


def test_and_condition():
    flow = AndFlow()
    result = flow.kickoff()
    assert result.a_done is True
    assert result.b_done is True
    assert result.merged is True


# ---------------------------------------------------------------------------
# Test: state persistence and resume
# ---------------------------------------------------------------------------

class PersistState(FlowState):
    data: str = ""
    feedback: str = ""


class PersistFlow(Flow[PersistState]):
    @start()
    def fetch(self):
        self.state.data = "fetched"

    @listen(fetch)
    def review(self):
        raise HumanFeedbackPending(
            flow_id=self.flow_id,
            context={"question": "Approve?"},
            state=self._state,
        )

    @listen("__resume__")
    def finalize(self):
        self.state.data = f"{self.state.data}_approved_{self.state.feedback}"


def test_persistence_and_resume():
    tmpdir = tempfile.mkdtemp()
    try:
        db_path = os.path.join(tmpdir, "test.db")
        persistence = SQLiteFlowPersistence(db_path=db_path)

        flow = PersistFlow(persistence=persistence)
        flow_id = flow.flow_id

        # kickoff should raise HumanFeedbackPending
        with pytest.raises(HumanFeedbackPending) as exc_info:
            flow.kickoff()

        assert exc_info.value.flow_id == flow_id
        assert exc_info.value.context == {"question": "Approve?"}

        # Verify state was persisted
        pending = persistence.load_pending(flow_id)
        assert pending is not None
        assert json.loads(pending["state_json"])["data"] == "fetched"

        # Resume
        restored = PersistFlow.from_pending(flow_id, persistence)
        restored._state.feedback = "yes"
        result = restored.resume("yes")
        assert result.data == "fetched_approved_yes"
    finally:
        import shutil
        shutil.rmtree(tmpdir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Test: max method calls protection
# ---------------------------------------------------------------------------

class InfiniteState(FlowState):
    counter: int = 0


class InfiniteFlow(Flow[InfiniteState]):
    @start()
    def loop_start(self):
        self.state.counter = 1

    @listen(loop_start)
    def loop_body(self):
        self.state.counter = self.state.counter + 1
        # This would trigger itself if wired — but listen(loop_start) doesn't self-loop


class SelfRefState(FlowState):
    counter: int = 0


# We can't create a true self-referencing listen easily with decorators,
# so test the protection by manually lowering max_method_calls
class LowMaxFlow(Flow[SimpleState]):
    max_method_calls: int = 2

    @start()
    def begin(self):
        self.state.steps = ["begin"]

    @listen(begin)
    def step1(self):
        self.state.steps = self.state.steps + ["step1"]

    @listen(step1)
    def step2(self):
        self.state.steps = self.state.steps + ["step2"]

    @listen(step2)
    def step3(self):
        self.state.steps = self.state.steps + ["step3"]


def test_max_method_calls_protection():
    # Each method only called once, so max=2 allows all (each unique method < 2)
    flow = LowMaxFlow(max_method_calls=1)
    # With max=1, begin is call #1 which is fine, but step1 would also be call #1
    # Actually each method has its own counter, so this should work
    result = flow.kickoff()
    assert "begin" in result.steps


# Explicit loop protection test
def test_explicit_loop_protection():
    """Verify that calling the same node too many times raises RuntimeError."""
    flow = LinearFlow(max_method_calls=0)
    with pytest.raises(RuntimeError, match="infinite loop protection"):
        flow.kickoff()


# ---------------------------------------------------------------------------
# Test: parallel listener execution (same trigger)
# ---------------------------------------------------------------------------

class ParallelFlow(Flow[ParallelState]):
    @start()
    def trigger(self):
        pass

    @listen(trigger)
    def worker_a(self):
        self.state.results = self.state.results + ["a"]

    @listen(trigger)
    def worker_b(self):
        self.state.results = self.state.results + ["b"]


def test_parallel_listeners():
    flow = ParallelFlow()
    result = flow.kickoff()
    assert "a" in result.results
    assert "b" in result.results
    assert len(result.results) == 2


# ---------------------------------------------------------------------------
# Test: kickoff with inputs
# ---------------------------------------------------------------------------

class InputState(FlowState):
    name: str = ""
    greeting: str = ""


class InputFlow(Flow[InputState]):
    @start()
    def greet(self):
        self.state.greeting = f"Hello, {self.state.name}!"


def test_kickoff_with_inputs():
    flow = InputFlow()
    result = flow.kickoff(inputs={"name": "Decker"})
    assert result.greeting == "Hello, Decker!"


# ---------------------------------------------------------------------------
# Test: retry decorator
# ---------------------------------------------------------------------------

_retry_counter = {"n": 0}


class RetryState(FlowState):
    result: str = ""


class RetryFlow(Flow[RetryState]):
    @start()
    @retry(max_retries=3, backoff=0.01)
    def flaky(self):
        _retry_counter["n"] += 1
        if _retry_counter["n"] < 3:
            raise ValueError("not yet")
        self.state.result = "success"


def test_retry_decorator():
    _retry_counter["n"] = 0
    flow = RetryFlow()
    result = flow.kickoff()
    assert result.result == "success"
    assert _retry_counter["n"] == 3


# ---------------------------------------------------------------------------
# Test: timeout decorator
# ---------------------------------------------------------------------------

class TimeoutState(FlowState):
    done: bool = False


class TimeoutFlow(Flow[TimeoutState]):
    @start()
    @timeout(0.1)
    def slow(self):
        import time
        time.sleep(5)
        self.state.done = True


def test_timeout_decorator():
    flow = TimeoutFlow()
    with pytest.raises(TimeoutError):
        flow.kickoff()


# ---------------------------------------------------------------------------
# Test: visualization
# ---------------------------------------------------------------------------

def test_plot():
    flow = LinearFlow()
    path = flow.plot()
    assert path.endswith(".html")
    content = Path(path).read_text()
    assert "mermaid" in content
    assert "begin" in content
    assert "middle" in content
    assert "end" in content
    # Cleanup
    Path(path).unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# Test: async kickoff
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_async_kickoff():
    flow = LinearFlow()
    result = await flow.kickoff_async()
    assert result.steps == ["begin", "middle", "end"]


# ---------------------------------------------------------------------------
# Test: SQLite persistence table creation
# ---------------------------------------------------------------------------

def test_sqlite_persistence_table():
    tmpdir = tempfile.mkdtemp()
    try:
        db_path = os.path.join(tmpdir, "test.db")
        p = SQLiteFlowPersistence(db_path=db_path)

        # Verify table exists
        with sqlite3.connect(db_path) as conn:
            tables = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='flow_states'"
            ).fetchall()
            assert len(tables) == 1

        # Save and load
        p.save_state("flow-1", "step-a", '{"id": "flow-1"}')
        loaded = p.load_state("flow-1")
        assert json.loads(loaded)["id"] == "flow-1"
    finally:
        import shutil
        shutil.rmtree(tmpdir, ignore_errors=True)
