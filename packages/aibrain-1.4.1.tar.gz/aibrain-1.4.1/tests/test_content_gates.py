"""Tests for the 12-gate content pre-publish stack.

Two tests per gate (one pass, one reject) + three integration tests for
the full pipeline. All tests use an isolated temp sqlite DB so they don't
pollute the real aibrain.db.
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from aibrain.core import content_gates
from aibrain.core.content_gates import (
    DraftContent,
    GateResult,
    all_passed,
    check_competitor_name_gate,
    check_factual_gate,
    check_hold_flag_gate,
    check_internal_reference_gate,
    check_legal_gate,
    check_myaibrain_url_present,
    check_numbers_gate,
    check_overclaim_language_gate,
    check_promise_gate,
    check_quiet_gate,
    check_rate_limit_gate,
    check_scope_gate,
    check_superworker_review_gate,
    run_all_gates,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _isolate_db(tmp_path, monkeypatch):
    """Route aibrain.db writes into a temp dir for every test."""
    fake_root = tmp_path / "aibrain_fake"
    fake_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("AIBRAIN_ROOT", str(fake_root))
    # Force aibrain_db to re-resolve AIBRAIN_ROOT by reimporting if needed
    import importlib
    import aibrain_db
    importlib.reload(aibrain_db)
    yield fake_root


@pytest.fixture(autouse=True)
def _isolate_memory_root(tmp_path, monkeypatch):
    """Point the hold-flag scanner at a temp memory dir so real
    project_*_hold.md files can't leak into tests."""
    fake_memory = tmp_path / "fake_memory"
    fake_memory.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(content_gates, "MEMORY_ROOT", fake_memory)
    yield fake_memory


def _mk_draft(body: str, **overrides) -> DraftContent:
    kwargs = {
        "draft_id": "test_draft_1",
        "tier": "T1",
        "title": "Test draft",
        "body": body,
        "platform": "twitter",
        "author": "content_intel_agent",
        "metadata": {},
    }
    kwargs.update(overrides)
    return DraftContent(**kwargs)


CLEAN_BODY = (
    "Agent memory retrieval benchmarks are an interesting area of study. "
    "Latency and recall both matter for LLM tool use and routing."
)


# ---------------------------------------------------------------------------
# Gate 1: rate_limit
# ---------------------------------------------------------------------------


def test_rate_limit_passes_with_empty_log():
    draft = _mk_draft(CLEAN_BODY)
    result = check_rate_limit_gate(draft)
    assert result.passed is True
    assert result.gate_name == "rate_limit"


def test_rate_limit_rejects_when_platform_cap_hit(_isolate_db):
    import json
    import sqlite3
    from aibrain.core.harness import _get_or_create_db

    db_path = _get_or_create_db()
    db = sqlite3.connect(str(db_path))
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS execution_log (
            id TEXT PRIMARY KEY,
            run_id TEXT NOT NULL,
            actor TEXT NOT NULL,
            action TEXT NOT NULL,
            entity_type TEXT,
            entity_id TEXT,
            detail TEXT,
            quality_score REAL,
            success INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    # Insert 3 twitter-published rows in the last 24h
    for i in range(3):
        db.execute(
            """INSERT INTO execution_log (id, run_id, actor, action, detail, success)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (
                f"row_{i}", f"run_{i}", "content_intel_agent",
                "comms_agent_publish",
                json.dumps({"platform": "twitter"}),
                1,
            ),
        )
    db.commit()
    db.close()

    draft = _mk_draft(CLEAN_BODY, platform="twitter")
    result = check_rate_limit_gate(draft)
    assert result.passed is False
    assert "twitter" in (result.reason or "")


# ---------------------------------------------------------------------------
# Gate 2: competitor_name
# ---------------------------------------------------------------------------


def test_competitor_name_passes_clean():
    draft = _mk_draft(CLEAN_BODY)
    assert check_competitor_name_gate(draft).passed is True


def test_competitor_name_rejects_on_mem0():
    draft = _mk_draft("Mem0 is an agent memory layer we studied.")
    result = check_competitor_name_gate(draft)
    assert result.passed is False
    assert "Mem0" in (result.evidence or {}).get("matched", "")


def test_competitor_name_no_substring_match():
    # "autogen" inside "autogenerate" must NOT trigger AutoGen
    draft = _mk_draft("The system will autogenerate config files.")
    assert check_competitor_name_gate(draft).passed is True


# ---------------------------------------------------------------------------
# Gate 3: internal_reference
# ---------------------------------------------------------------------------


def test_internal_reference_passes_clean():
    draft = _mk_draft("Agent memory consolidation research is rich.")
    assert check_internal_reference_gate(draft).passed is True


def test_internal_reference_rejects_product_name():
    draft = _mk_draft("We just shipped a new Wintermute feature.")
    result = check_internal_reference_gate(draft)
    assert result.passed is False
    assert "Wintermute" in (result.evidence or {}).get("matched", "")


# ---------------------------------------------------------------------------
# Gate 4: overclaim_language
# ---------------------------------------------------------------------------


def test_overclaim_passes_clean():
    draft = _mk_draft("We built a small memory retrieval benchmark.")
    assert check_overclaim_language_gate(draft).passed is True


def test_overclaim_rejects_revolutionary():
    draft = _mk_draft("This revolutionary new agent memory tech is ready.")
    assert check_overclaim_language_gate(draft).passed is False


# ---------------------------------------------------------------------------
# Gate 5: legal
# ---------------------------------------------------------------------------


def test_legal_passes_clean():
    draft = _mk_draft("Memory retrieval latency varies by embedding model.")
    assert check_legal_gate(draft).passed is True


def test_legal_rejects_hard_phrase():
    draft = _mk_draft("This tool is guaranteed to fix your retrieval bug.")
    assert check_legal_gate(draft).passed is False


def test_legal_flag_only_does_not_reject():
    # "health" triggers flag-only but should still pass
    draft = _mk_draft("Track your system health metrics via the dashboard.")
    result = check_legal_gate(draft)
    assert result.passed is True
    assert (result.evidence or {}).get("flag_only")


# ---------------------------------------------------------------------------
# Gate 6: promise
# ---------------------------------------------------------------------------


def test_promise_passes_without_date():
    draft = _mk_draft("We improved retrieval accuracy last week.")
    assert check_promise_gate(draft).passed is True


def test_promise_rejects_forward_date():
    draft = _mk_draft("launching next week with new benchmarks")
    assert check_promise_gate(draft).passed is False


# ---------------------------------------------------------------------------
# Gate 7: hold_flag
# ---------------------------------------------------------------------------


def test_hold_flag_passes_when_no_holds(_isolate_memory_root):
    draft = _mk_draft("A post about embedding retrieval performance.")
    assert check_hold_flag_gate(draft).passed is True


def test_hold_flag_rejects_on_matching_topic(_isolate_memory_root):
    (_isolate_memory_root / "project_embedding_benchmark_hold.md").write_text(
        "hold", encoding="utf-8"
    )
    draft = _mk_draft("A post about embedding benchmark retrieval tests.")
    result = check_hold_flag_gate(draft)
    assert result.passed is False


# ---------------------------------------------------------------------------
# Gate 8: scope
# ---------------------------------------------------------------------------


def test_scope_passes_on_category_content():
    draft = _mk_draft("A post about agent memory retrieval and routing.")
    assert check_scope_gate(draft).passed is True


def test_scope_rejects_off_topic():
    draft = _mk_draft("The royal family attended a celebrity wedding party today.")
    assert check_scope_gate(draft).passed is False


def test_scope_rejects_blacklist_even_with_whitelist():
    draft = _mk_draft("Politics plus an agent memory retrieval angle here.")
    assert check_scope_gate(draft).passed is False


# ---------------------------------------------------------------------------
# Gate 9: quiet
# ---------------------------------------------------------------------------


def test_quiet_passes_clean():
    draft = _mk_draft("Benchmarking agent memory retrieval quality is hard.")
    assert check_quiet_gate(draft).passed is True


def test_quiet_rejects_revenue_mention():
    draft = _mk_draft("Our MRR is growing nicely this quarter.")
    assert check_quiet_gate(draft).passed is False


def test_quiet_rejects_customer_count():
    draft = _mk_draft("We now have 42 paying customers.")
    assert check_quiet_gate(draft).passed is False


# ---------------------------------------------------------------------------
# Gate 10: numbers
# ---------------------------------------------------------------------------


def test_numbers_passes_with_no_numbers():
    draft = _mk_draft("Memory retrieval is a worthwhile topic.")
    assert check_numbers_gate(draft).passed is True


def test_numbers_rejects_unsourced_percentage():
    draft = _mk_draft("We saw 30% faster recall on the benchmark.")
    result = check_numbers_gate(draft)
    assert result.passed is False


def test_numbers_passes_sourced_percentage():
    draft = _mk_draft(
        "We saw 30% faster recall on the benchmark.",
        metadata={
            "sources": ["fact_benchmark_apr11.md"],
            "sourced_numbers": ["30", "30%"],
        },
    )
    assert check_numbers_gate(draft).passed is True


def test_numbers_rejects_stale_overclaim():
    draft = _mk_draft("We ship 240 workflows out of the box.")
    assert check_numbers_gate(draft).passed is False


# ---------------------------------------------------------------------------
# Gate 11: factual
# ---------------------------------------------------------------------------


def test_factual_passes_opinion_content():
    draft = _mk_draft("Retrieval-augmented agents feel more useful in practice.")
    assert check_factual_gate(draft).passed is True


def test_factual_rejects_unsourced_claim():
    draft = _mk_draft("According to research, memory quality matters most.")
    assert check_factual_gate(draft).passed is False


def test_factual_passes_sourced_claim():
    draft = _mk_draft(
        "According to research, memory quality matters most.",
        metadata={"sources": ["project_agent_memory.md"]},
    )
    assert check_factual_gate(draft).passed is True


# ---------------------------------------------------------------------------
# Gate 12: superworker_review
# ---------------------------------------------------------------------------


def test_superworker_passes_clean():
    draft = _mk_draft(
        "Agent memory benchmarks explore the tradeoff between recall and latency."
    )
    result = check_superworker_review_gate(draft)
    assert result.passed is True


def test_superworker_rejects_shouting():
    draft = _mk_draft(
        "AGENT MEMORY ROUTING IS AMAZING! BENCHMARK BENCHMARK BENCHMARK!!!"
    )
    result = check_superworker_review_gate(draft)
    assert result.passed is False


def test_superworker_rejects_absolute_claim():
    # "always" + scope signal — accuracy lens fails, then majority <3
    draft = _mk_draft(
        "Agent memory retrieval is always the answer. HEY EVERYONE!!!"
    )
    result = check_superworker_review_gate(draft)
    assert result.passed is False


# ---------------------------------------------------------------------------
# Gate 13: myaibrain_url_present (added 2026-04-11 per Decker directive)
# ---------------------------------------------------------------------------


def test_gate_13_passes_when_myaibrain_url_present():
    draft = _mk_draft(
        "Agent memory retrieval benchmarks are fun. "
        "Check out https://myaibrain.org for more."
    )
    result = check_myaibrain_url_present(draft)
    assert result.passed is True
    assert result.reason == "myaibrain.org URL present"


def test_gate_13_rejects_when_url_missing():
    draft = _mk_draft(
        "Agent memory retrieval benchmarks are fun. "
        "No link in this draft at all."
    )
    result = check_myaibrain_url_present(draft)
    assert result.passed is False
    assert "missing myaibrain.org URL" in (result.reason or "")


# ---------------------------------------------------------------------------
# Integration tests
# ---------------------------------------------------------------------------


def test_full_pipeline_passes_on_clean_draft(_isolate_memory_root):
    draft = _mk_draft(
        "Agent memory retrieval benchmarks are worth studying. "
        "Routing, recall, and context shape LLM tool use. "
        "More at https://myaibrain.org",
        metadata={"sources": ["project_agent_memory.md"]},
    )
    results = run_all_gates(draft)
    # Gate 14 (template_freshness) added 2026-04-12 — 14 gates total.
    assert len(results) == 14, (
        f"expected all 14 gates to run; got {len(results)} — "
        f"first fail: {[r for r in results if not r.passed]}"
    )
    assert all_passed(results) is True


def test_full_pipeline_rejects_on_competitor_mention(_isolate_memory_root):
    draft = _mk_draft("Mem0 is a memory layer we benchmarked.")
    results = run_all_gates(draft)
    assert all_passed(results) is False
    # Competitor gate is #2 — should fail fast
    failing = [r for r in results if not r.passed]
    assert any(r.gate_name == "competitor_name" for r in failing)


def test_full_pipeline_rejects_on_overclaim_word(_isolate_memory_root):
    draft = _mk_draft(
        "Our revolutionary agent memory retrieval approach is the future."
    )
    results = run_all_gates(draft)
    assert all_passed(results) is False
    failing = [r for r in results if not r.passed]
    assert any(r.gate_name == "overclaim_language" for r in failing)
