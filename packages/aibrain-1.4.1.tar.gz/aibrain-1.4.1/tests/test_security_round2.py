"""
Tests for Round 2 security audit fixes (R2-01, R2-09, R2-17).

- R2-09: MCP command whitelist bypass via dangerous interpreter flags
- R2-17: Secrets vault weak fallback key — now generates random key file
- R2-01: DNS rebinding SSRF — validate_url now supports IP pinning
"""

import os
import re
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))


# ============================================================================
# R2-09: MCP command whitelist bypass — dangerous interpreter flags
# ============================================================================

class TestMCPDangerousFlags:
    """Verify that dangerous interpreter flags (-c, -e, -m, --eval, etc.)
    are blocked in MCP server args, preventing code execution bypass."""

    def _get_blocked_flags(self):
        from aibrain_api import _DANGEROUS_INTERPRETER_FLAGS
        return _DANGEROUS_INTERPRETER_FLAGS

    def test_python_c_flag_blocked(self):
        """python -c 'import os; os.system(...)' must be rejected."""
        flags = self._get_blocked_flags()
        assert "-c" in flags

    def test_node_e_flag_blocked(self):
        """node -e 'require(\"child_process\").execSync(...)' must be rejected."""
        flags = self._get_blocked_flags()
        assert "-e" in flags

    def test_python_m_flag_blocked(self):
        """python -m http.server must be rejected."""
        flags = self._get_blocked_flags()
        assert "-m" in flags

    def test_eval_long_form_blocked(self):
        """--eval and --command long forms must be rejected."""
        flags = self._get_blocked_flags()
        assert "--eval" in flags
        assert "--command" in flags

    def test_shell_meta_still_blocks(self):
        """Shell metacharacters still caught (existing behavior preserved)."""
        from aibrain_api import _SHELL_META
        for char in [";", "&", "|", "`", "$", "(", ")", "{", "}", "<", ">", "\n", "\r"]:
            assert _SHELL_META.search(char), f"Expected _SHELL_META to match '{repr(char)}'"

    def test_safe_args_still_allowed(self):
        """Normal args like file paths and --stdio should NOT be blocked."""
        flags = self._get_blocked_flags()
        safe_args = ["server.py", "--stdio", "--port", "3000", "/path/to/script.js", "-v", "--verbose"]
        for arg in safe_args:
            key = arg.split("=", 1)[0].strip().lower()
            assert key not in flags, f"Safe arg '{arg}' should NOT be blocked"

    def test_flag_equals_value_form_blocked(self):
        """--eval=code form must also be caught (split on '=')."""
        flags = self._get_blocked_flags()
        arg = "--eval=console.log('pwned')"
        key = arg.split("=", 1)[0].strip().lower()
        assert key in flags


# ============================================================================
# R2-17: Secrets vault weak fallback key
# ============================================================================

class TestSecretsKeyGeneration:
    """Verify the vault no longer falls back to predictable machine fingerprint.
    Instead it generates a random key file on first use."""

    @staticmethod
    def _setup_fake_root(tmp_path, monkeypatch):
        """Point secrets module __file__ so parent.parent.parent = tmp_path.
        Returns (secrets_mod, old_file) for cleanup."""
        monkeypatch.delenv("AIBRAIN_SECRET_KEY", raising=False)
        import aibrain.core.secrets as secrets_mod
        old_file = secrets_mod.__file__
        # parent.parent.parent of aibrain/core/secrets.py => project root
        # So we need fake_root / aibrain / core / secrets.py
        fake_file = str(tmp_path / "aibrain" / "core" / "secrets.py")
        os.makedirs(Path(fake_file).parent, exist_ok=True)
        secrets_mod.__file__ = fake_file
        # Also need .encryption_salt for _get_salt
        salt_path = tmp_path / ".encryption_salt"
        if not salt_path.exists():
            salt_path.write_bytes(os.urandom(16))
        return secrets_mod, old_file

    def test_no_env_key_generates_file(self, tmp_path, monkeypatch):
        """Without AIBRAIN_SECRET_KEY, a random .encryption_key file is created."""
        monkeypatch.setenv("AIBRAIN_DB", str(tmp_path / "test.db"))
        secrets_mod, old_file = self._setup_fake_root(tmp_path, monkeypatch)
        try:
            fernet = secrets_mod._derive_key()
            key_path = tmp_path / ".encryption_key"
            assert key_path.exists(), ".encryption_key file should be auto-generated"
            key_content = key_path.read_text(encoding="utf-8").strip()
            assert len(key_content) == 64, "Key should be 32 bytes hex = 64 chars"
            # Verify it's valid hex
            int(key_content, 16)
        finally:
            secrets_mod.__file__ = old_file

    def test_generated_key_is_random(self, tmp_path, monkeypatch):
        """Two separate generations produce different keys (not deterministic)."""
        import aibrain.core.secrets as secrets_mod

        keys = []
        for i in range(2):
            sub = tmp_path / f"run{i}"
            sub.mkdir()
            monkeypatch.delenv("AIBRAIN_SECRET_KEY", raising=False)
            secrets_mod_ref, old_file = self._setup_fake_root(sub, monkeypatch)
            try:
                secrets_mod_ref._derive_key()
                key_path = sub / ".encryption_key"
                keys.append(key_path.read_text(encoding="utf-8").strip())
            finally:
                secrets_mod_ref.__file__ = old_file

        assert keys[0] != keys[1], "Generated keys must be random, not deterministic"

    def test_existing_key_file_reused(self, tmp_path, monkeypatch):
        """If .encryption_key already exists, it's loaded (not regenerated)."""
        secrets_mod, old_file = self._setup_fake_root(tmp_path, monkeypatch)

        # Pre-create the key file
        key_path = tmp_path / ".encryption_key"
        known_key = "deadbeef" * 8  # 64 hex chars
        key_path.write_text(known_key, encoding="utf-8")

        try:
            fernet = secrets_mod._derive_key()
            # File should still have the same content (not overwritten)
            assert key_path.read_text(encoding="utf-8").strip() == known_key
        finally:
            secrets_mod.__file__ = old_file

    def test_env_key_takes_precedence(self, tmp_path, monkeypatch):
        """AIBRAIN_SECRET_KEY env var should be used over any file."""
        monkeypatch.setenv("AIBRAIN_SECRET_KEY", "my-explicit-secret-key")
        monkeypatch.setenv("AIBRAIN_DB", str(tmp_path / "test.db"))
        import aibrain.core.secrets as secrets_mod

        salt_path = tmp_path / ".encryption_salt"
        # Need salt file at the right path
        real_salt = Path(secrets_mod.__file__).resolve().parent.parent.parent / ".encryption_salt"
        if not real_salt.exists():
            # Just ensure _get_salt works
            pass

        # Should not raise and should not create .encryption_key
        fernet = secrets_mod._derive_key()
        assert fernet is not None


# ============================================================================
# R2-01: DNS rebinding SSRF — IP pinning
# ============================================================================

class TestDnsRebindingPrevention:
    """Verify validate_url supports IP pinning to defeat TOCTOU DNS rebinding."""

    def test_validate_url_pin_ip_returns_pinned(self):
        """With pin_ip=True, safe URLs return 'pinned:<ip>' in reason."""
        from security import validate_url
        # Use a known-public hostname
        is_safe, reason = validate_url("https://www.google.com/", pin_ip=True)
        if is_safe:
            assert reason.startswith("pinned:"), f"Expected 'pinned:...' but got '{reason}'"
            ip_str = reason.split(":", 1)[1]
            # Verify it's a valid IP
            import ipaddress
            ipaddress.ip_address(ip_str)

    def test_validate_url_pin_ip_false_returns_ok(self):
        """Without pin_ip, safe URLs still return 'ok' (backward compat)."""
        from security import validate_url
        is_safe, reason = validate_url("https://www.google.com/")
        if is_safe:
            assert reason == "ok"

    def test_blocked_ip_still_rejected_with_pin(self):
        """Pinning doesn't bypass blocked IP checks."""
        from security import validate_url
        is_safe, reason = validate_url("http://127.0.0.1:8080/admin", pin_ip=True)
        assert not is_safe
        assert "Blocked" in reason

    def test_resolve_and_pin_url_returns_ip(self):
        """resolve_and_pin_url helper returns (ip, hostname) for safe URLs."""
        from security import resolve_and_pin_url
        try:
            pinned_ip, hostname = resolve_and_pin_url("https://www.google.com/")
            assert pinned_ip, "Pinned IP should not be empty"
            assert hostname == "www.google.com"
            import ipaddress
            ipaddress.ip_address(pinned_ip)
        except ValueError:
            # DNS resolution may fail in CI — skip gracefully
            pytest.skip("DNS resolution unavailable")

    def test_resolve_and_pin_url_rejects_internal(self):
        """resolve_and_pin_url raises ValueError for internal IPs."""
        from security import resolve_and_pin_url
        with pytest.raises(ValueError, match="Blocked"):
            resolve_and_pin_url("http://127.0.0.1:11434/api/tags")

    def test_ipv6_mapped_ipv4_blocked(self):
        """IPv6-mapped IPv4 addresses like ::ffff:127.0.0.1 are caught."""
        from security import validate_url
        # Simulate by testing the IP check logic directly
        import ipaddress
        ip = ipaddress.ip_address("::ffff:127.0.0.1")
        mapped = getattr(ip, "ipv4_mapped", None)
        assert mapped is not None, "::ffff:127.0.0.1 should have ipv4_mapped"
        assert mapped == ipaddress.ip_address("127.0.0.1")


# ============================================================================
# Integration: verify all three fixes don't break normal operation
# ============================================================================

class TestNormalOperationPreserved:
    """Smoke tests to ensure fixes don't break legitimate use cases."""

    def test_mcp_safe_registration_args(self):
        """Normal MCP server args like ['server.py', '--stdio'] pass validation."""
        from aibrain_api import _DANGEROUS_INTERPRETER_FLAGS, _SHELL_META
        safe_args = ["my_mcp_server.py", "--stdio", "--port=3000"]
        for arg in safe_args:
            key = arg.split("=", 1)[0].strip().lower()
            assert key not in _DANGEROUS_INTERPRETER_FLAGS
            assert not _SHELL_META.search(arg)

    def test_secrets_roundtrip_with_env_key(self, tmp_path, monkeypatch):
        """Secrets store/get still works with AIBRAIN_SECRET_KEY set."""
        monkeypatch.setenv("AIBRAIN_DB", str(tmp_path / "test.db"))
        monkeypatch.setenv("AIBRAIN_SECRET_KEY", "test-key-12345")
        from aibrain.core.secrets import store_secret, get_secret
        store_secret("test_key", "test_value_42")
        assert get_secret("test_key") == "test_value_42"

    def test_validate_url_still_allows_external(self):
        """External HTTPS URLs are still allowed."""
        from security import validate_url
        is_safe, reason = validate_url("https://example.com/")
        # May fail in environments without DNS, but should not falsely block
        if is_safe:
            assert reason == "ok"
