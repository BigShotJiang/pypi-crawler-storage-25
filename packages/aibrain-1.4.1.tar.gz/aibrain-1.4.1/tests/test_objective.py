"""
Tests for aibrain.core.objective — brain fitness objective function.

Tests cover:
  1. brain_fitness returns valid structure with empty DB
  2. brain_fitness returns 0.0-1.0 range
  3. Individual metrics return float in 0.0-1.0
  4. brain_fitness_trend returns correct number of periods
  5. record_fitness writes to evolution_metrics
  6. Improving quality scores produce higher task_quality_trend
  7. Decreasing failures produce higher correction_rate_trend
  8. Memory consolidation reflects reuse ratio
  9. CLI exits cleanly
  10. Weights sum to 1.0
"""

import os
import sqlite3
import tempfile
from datetime import datetime, timedelta
from pathlib import Path

import pytest

# Ensure project root importable
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.objective import (
    WEIGHTS,
    brain_fitness,
    brain_fitness_trend,
    cli_fitness,
    metric_correction_rate_trend,
    metric_memory_consolidation,
    metric_recall_precision,
    metric_response_efficiency,
    metric_task_quality_trend,
    record_fitness,
)


@pytest.fixture()
def test_db(tmp_path):
    """Create a temporary DB with the required schema."""
    db_path = tmp_path / "aibrain.db"
    db = sqlite3.connect(str(db_path))
    db.execute("PRAGMA journal_mode=WAL")
    db.executescript("""
        CREATE TABLE IF NOT EXISTS execution_log (
            id TEXT PRIMARY KEY,
            run_id TEXT,
            actor TEXT,
            action TEXT NOT NULL,
            entity_type TEXT,
            entity_id TEXT,
            detail TEXT,
            quality_score REAL,
            model_used TEXT,
            cost_cents INTEGER DEFAULT 0,
            duration_ms INTEGER DEFAULT 0,
            before_state TEXT,
            after_state TEXT,
            success INTEGER DEFAULT 0,
            error TEXT,
            task_type TEXT,
            authority TEXT,
            retries INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            memory_class TEXT DEFAULT 'semantic',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS evolution_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            metric_name TEXT NOT NULL,
            metric_value REAL NOT NULL,
            source TEXT,
            period TEXT,
            recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)
    db.commit()
    db.close()

    # Point AIBRAIN_ROOT at the temp dir
    old = os.environ.get("AIBRAIN_ROOT")
    os.environ["AIBRAIN_ROOT"] = str(tmp_path)
    yield db_path
    if old is not None:
        os.environ["AIBRAIN_ROOT"] = old
    else:
        os.environ.pop("AIBRAIN_ROOT", None)


def _insert_executions(db_path, entries):
    """Insert execution_log rows. entries: list of (success, quality, duration_ms, created_at)."""
    db = sqlite3.connect(str(db_path))
    for i, (success, quality, dur, ts) in enumerate(entries):
        db.execute(
            "INSERT INTO execution_log (id, action, success, quality_score, duration_ms, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (f"test-{i}", "test_task", success, quality, dur, ts)
        )
    db.commit()
    db.close()


def _insert_memories(db_path, entries):
    """Insert memory rows. entries: list of (name, access_count, created)."""
    db = sqlite3.connect(str(db_path))
    for name, access_count, created in entries:
        db.execute(
            "INSERT INTO memories (name, access_count, created, active) "
            "VALUES (?, ?, ?, 1)",
            (name, access_count, created)
        )
    db.commit()
    db.close()


# ── Test 1: Weights sum to 1.0 ─────────────────────────────────────────

def test_weights_sum_to_one():
    total = sum(WEIGHTS.values())
    assert abs(total - 1.0) < 1e-9, f"Weights sum to {total}, expected 1.0"


# ── Test 2: Empty DB returns valid structure ────────────────────────────

def test_fitness_empty_db(test_db):
    result = brain_fitness(db_path=test_db)
    assert "fitness" in result
    assert "metrics" in result
    assert "weights" in result
    assert isinstance(result["fitness"], float)
    assert 0.0 <= result["fitness"] <= 1.0


# ── Test 3: All individual metrics return 0.0-1.0 ──────────────────────

def test_individual_metrics_range(test_db):
    db = sqlite3.connect(str(test_db))
    db.row_factory = sqlite3.Row

    for fn in [metric_task_quality_trend, metric_correction_rate_trend,
               metric_memory_consolidation, metric_recall_precision,
               metric_response_efficiency]:
        val = fn(db)
        assert 0.0 <= val <= 1.0, f"{fn.__name__} returned {val}, out of range"

    db.close()


# ── Test 4: Trend returns correct number of periods ────────────────────

def test_trend_periods(test_db):
    trend = brain_fitness_trend(periods=4, window_days=7, db_path=test_db)
    assert len(trend) == 4
    for entry in trend:
        assert "fitness" in entry
        assert "period" in entry
        assert 0.0 <= entry["fitness"] <= 1.0


# ── Test 5: record_fitness writes to evolution_metrics ──────────────────

def test_record_fitness(test_db):
    record_fitness(db_path=test_db)

    db = sqlite3.connect(str(test_db))
    count = db.execute(
        "SELECT COUNT(*) FROM evolution_metrics WHERE source='objective'"
    ).fetchone()[0]
    db.close()

    # Should have 1 (composite) + 5 (individual metrics) = 6 rows
    assert count == 6


# ── Test 6: Improving quality produces higher trend score ───────────────

def test_improving_quality_trend(test_db):
    now = datetime.utcnow()
    entries = []
    # First half: low quality
    for i in range(10):
        ts = (now - timedelta(days=25) + timedelta(hours=i)).isoformat()
        entries.append((1, 0.3, 100, ts))
    # Second half: high quality
    for i in range(10):
        ts = (now - timedelta(days=5) + timedelta(hours=i)).isoformat()
        entries.append((1, 0.9, 100, ts))

    _insert_executions(test_db, entries)

    db = sqlite3.connect(str(test_db))
    db.row_factory = sqlite3.Row
    score = metric_task_quality_trend(db, window_days=30)
    db.close()

    # Quality improved: score should be > 0.5
    assert score > 0.5, f"Improving quality should yield > 0.5, got {score}"


# ── Test 7: Decreasing failures produce higher correction score ─────────

def test_decreasing_failures(test_db):
    now = datetime.utcnow()
    entries = []
    # First half: many failures
    for i in range(8):
        ts = (now - timedelta(days=25) + timedelta(hours=i)).isoformat()
        entries.append((0, 0.0, 100, ts))
    # Second half: few failures
    for i in range(2):
        ts = (now - timedelta(days=5) + timedelta(hours=i)).isoformat()
        entries.append((0, 0.0, 100, ts))

    _insert_executions(test_db, entries)

    db = sqlite3.connect(str(test_db))
    db.row_factory = sqlite3.Row
    score = metric_correction_rate_trend(db, window_days=30)
    db.close()

    # Failures are decreasing: score should be > 0.5
    assert score > 0.5, f"Decreasing failures should yield > 0.5, got {score}"


# ── Test 8: Memory consolidation reflects reuse ─────────────────────────

def test_memory_consolidation_reuse(test_db):
    now = datetime.utcnow()
    entries = [
        ("mem_active_1", 5, (now - timedelta(days=10)).isoformat()),
        ("mem_active_2", 3, (now - timedelta(days=8)).isoformat()),
        ("mem_unused_1", 0, (now - timedelta(days=5)).isoformat()),
    ]
    _insert_memories(test_db, entries)

    db = sqlite3.connect(str(test_db))
    db.row_factory = sqlite3.Row
    score = metric_memory_consolidation(db, window_days=30)
    db.close()

    # 2 out of 3 memories have access_count > 1 -> reuse_ratio ~0.67
    assert score > 0.3, f"Reused memories should yield > 0.3, got {score}"


# ── Test 9: CLI exits cleanly ───────────────────────────────────────────

def test_cli_fitness(test_db, capsys):
    exit_code = cli_fitness([])
    assert exit_code == 0
    captured = capsys.readouterr()
    assert "Brain Fitness Score" in captured.out


# ── Test 10: No DB returns error in result ──────────────────────────────

def test_no_db_returns_error(tmp_path, monkeypatch):
    # Canonical invariant (commit bd7f5b9): aibrain_db.AIBRAIN_ROOT is
    # resolved once at module import. Setting the AIBRAIN_ROOT env var
    # post-import has no effect because _find_db() reads the already-
    # resolved constant. Tests must patch the constant directly.
    import aibrain_db
    monkeypatch.setattr(aibrain_db, "AIBRAIN_ROOT", tmp_path / "nonexistent")
    result = brain_fitness()
    assert result["fitness"] == 0.0
    assert "error" in result
