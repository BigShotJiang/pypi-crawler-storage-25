#!/usr/bin/env python3
"""
test_brain_export_import.py — Tests for full brain export/import in aibrain_db.py

Covers:
- Export includes all 18 new tables plus original 5
- Import with INSERT OR IGNORE doesn't duplicate
- Credential scrubbing on config table
- Satellite DB path conversion (abs -> relative on export, relative -> abs on import)
- Old-format imports still work (backward compatibility)
- Company agents use INSERT OR REPLACE for propagation
"""

import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path
from unittest import mock

import pytest

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))


# ---------------------------------------------------------------------------
# Helpers — create a minimal DB with all required tables
# ---------------------------------------------------------------------------

def _create_full_db(db_path: str) -> sqlite3.Connection:
    """Create a test DB with all tables needed for brain sync."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, type TEXT DEFAULT 'project',
            memory_class TEXT DEFAULT 'semantic', tags TEXT DEFAULT '',
            content TEXT DEFAULT '', importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0, last_accessed TEXT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')), active INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS entity_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_type TEXT, source_id TEXT, target_type TEXT,
            target_id TEXT, relationship TEXT, metadata TEXT
        );
        CREATE TABLE IF NOT EXISTS semantic_facts (
            fact_id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject TEXT, predicate TEXT, object TEXT,
            fact_type TEXT DEFAULT 'attribute', sentiment TEXT DEFAULT 'NEUTRAL',
            confidence REAL DEFAULT 0.5, status TEXT DEFAULT 'ACTIVE'
        );
        CREATE TABLE IF NOT EXISTS memory_passages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            memory_id INTEGER, passage_index INTEGER,
            content TEXT, role_weight REAL DEFAULT 1.0
        );
        CREATE TABLE IF NOT EXISTS evolution_patterns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern TEXT, frequency INTEGER DEFAULT 1,
            severity TEXT DEFAULT 'medium', status TEXT DEFAULT 'active',
            related_outcomes TEXT
        );
        CREATE TABLE IF NOT EXISTS companies (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, mission TEXT,
            status TEXT DEFAULT 'active', budget_monthly_cents INTEGER DEFAULT 0,
            spent_monthly_cents INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS company_agents (
            id TEXT PRIMARY KEY, company_id TEXT NOT NULL,
            name TEXT NOT NULL, role TEXT DEFAULT 'general',
            title TEXT, status TEXT DEFAULT 'idle',
            reports_to TEXT, model TEXT DEFAULT 'auto',
            task_type TEXT DEFAULT 'judgment', authority TEXT DEFAULT 'standard',
            budget_monthly_cents INTEGER DEFAULT 0,
            spent_monthly_cents INTEGER DEFAULT 0,
            heartbeat_interval_seconds INTEGER DEFAULT 14400,
            last_heartbeat_at TIMESTAMP, instructions TEXT,
            capabilities TEXT, permissions TEXT, metadata TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS company_issues (
            id TEXT PRIMARY KEY, company_id TEXT NOT NULL,
            parent_id TEXT, title TEXT NOT NULL, description TEXT,
            status TEXT DEFAULT 'backlog', priority TEXT DEFAULT 'medium',
            assignee_agent_id TEXT, project TEXT, issue_number INTEGER,
            origin TEXT DEFAULT 'manual', request_depth INTEGER DEFAULT 0,
            quality_score REAL, cost_cents INTEGER DEFAULT 0,
            started_at TIMESTAMP, completed_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS company_goals (
            id TEXT PRIMARY KEY, company_id TEXT NOT NULL,
            title TEXT NOT NULL, description TEXT DEFAULT '',
            status TEXT DEFAULT 'active', priority TEXT DEFAULT 'medium',
            target_date TEXT, progress REAL DEFAULT 0.0,
            milestones TEXT DEFAULT '[]', assigned_agent_id TEXT,
            parent_goal_id TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS company_projects (
            id TEXT PRIMARY KEY, company_id TEXT NOT NULL,
            name TEXT NOT NULL, tagline TEXT DEFAULT '',
            description TEXT DEFAULT '', status TEXT DEFAULT 'active',
            priority TEXT DEFAULT 'medium', repo TEXT DEFAULT '',
            path TEXT DEFAULT '', progress REAL DEFAULT 0.0,
            related_goal_ids TEXT DEFAULT '[]', tech_stack TEXT DEFAULT '',
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS skills (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL, display_name TEXT DEFAULT '',
            description TEXT DEFAULT '', category TEXT DEFAULT '',
            file_path TEXT DEFAULT '', installed INTEGER DEFAULT 1,
            created TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS skill_executions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            skill_name TEXT NOT NULL, success INTEGER,
            tokens_used INTEGER, duration_seconds REAL,
            error_message TEXT, execution_context TEXT,
            created TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS workflows (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL, display_name TEXT DEFAULT '',
            category TEXT DEFAULT 'general', description TEXT DEFAULT '',
            cron_schedule TEXT DEFAULT '', required_services TEXT DEFAULT '[]',
            playwright_setup TEXT DEFAULT '[]', flow TEXT DEFAULT '[]',
            edges TEXT DEFAULT '[]', enabled INTEGER DEFAULT 0,
            config_keys TEXT DEFAULT '[]', script_path TEXT DEFAULT '',
            source TEXT DEFAULT 'registry',
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS config (
            key TEXT PRIMARY KEY, value TEXT DEFAULT '',
            updated TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS satellite_dbs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL, db_path TEXT NOT NULL,
            description TEXT DEFAULT '', memory_types TEXT DEFAULT '[]',
            search_keywords TEXT DEFAULT '',
            created TEXT DEFAULT (datetime('now')), active INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS evolution_outcomes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT NOT NULL, source_id TEXT, action TEXT NOT NULL,
            result TEXT NOT NULL, details TEXT, failure_reason TEXT,
            duration_seconds REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS evolution_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            metric_name TEXT NOT NULL, metric_value REAL NOT NULL,
            source TEXT, period TEXT,
            recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS evolution_cycles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP, outcomes_analyzed INTEGER DEFAULT 0,
            patterns_found INTEGER DEFAULT 0, hypotheses_generated INTEGER DEFAULT 0,
            experiments_started INTEGER DEFAULT 0, experiments_decided INTEGER DEFAULT 0,
            summary TEXT, agent TEXT DEFAULT 'neuro'
        );
        CREATE TABLE IF NOT EXISTS entities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, type TEXT NOT NULL,
            category TEXT DEFAULT '', mention_count INTEGER DEFAULT 1,
            first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
            UNIQUE(name, type)
        );
        CREATE TABLE IF NOT EXISTS category_summaries (
            category TEXT PRIMARY KEY, summary TEXT NOT NULL,
            memory_count INTEGER DEFAULT 0, avg_importance REAL DEFAULT 0.0,
            top_keywords TEXT DEFAULT '', embedding BLOB,
            last_updated TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS approvals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            category TEXT DEFAULT '', title TEXT DEFAULT '',
            detail TEXT DEFAULT '', payload TEXT DEFAULT '{}',
            status TEXT DEFAULT 'pending', decided_at TEXT,
            decision_note TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS agent_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action_type TEXT NOT NULL, target TEXT DEFAULT '*',
            permission TEXT NOT NULL, granted_by TEXT DEFAULT 'user',
            expires_at TIMESTAMP, use_count INTEGER DEFAULT 0,
            last_used_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, notes TEXT
        );
        CREATE TABLE IF NOT EXISTS scheduled_jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL, cron TEXT NOT NULL,
            prompt TEXT DEFAULT '', enabled INTEGER DEFAULT 1,
            notes TEXT DEFAULT '', workflow_id INTEGER,
            last_run TEXT, next_run TEXT,
            created TEXT DEFAULT (datetime('now'))
        );
    """)
    conn.commit()
    return conn


def _seed_data(conn: sqlite3.Connection):
    """Insert sample data into all tables."""
    conn.executescript("""
        INSERT INTO memories (name, type, content, importance, active)
        VALUES ('test_mem', 'project', 'test content', 0.7, 1);

        INSERT INTO entity_links (source_type, source_id, target_type, target_id, relationship)
        VALUES ('memory', '1', 'entity', '1', 'mentions');

        INSERT INTO semantic_facts (subject, predicate, object)
        VALUES ('AIBrain', 'is', 'a brain system');

        INSERT INTO evolution_patterns (pattern, frequency, severity, status)
        VALUES ('test pattern', 3, 'high', 'active');

        INSERT INTO companies (id, name, mission, status)
        VALUES ('CO1', 'DeckerOps', 'Build AI products', 'active');

        INSERT INTO company_agents (id, company_id, name, role, title)
        VALUES ('AG1', 'CO1', 'Lead Engineer', 'general', 'Lead Engineer');

        INSERT INTO company_issues (id, company_id, title, status, priority)
        VALUES ('ISS1', 'CO1', 'Fix brain sync', 'todo', 'high');

        INSERT INTO company_goals (id, company_id, title, created_at, updated_at)
        VALUES ('G1', 'CO1', 'Ship v2', '2026-01-01', '2026-04-01');

        INSERT INTO company_projects (id, company_id, name, created_at, updated_at)
        VALUES ('P1', 'CO1', 'AIBrain', '2026-01-01', '2026-04-01');

        INSERT INTO skills (name, display_name, description, category)
        VALUES ('code_review', 'Code Review', 'Review code quality', 'engineering');

        INSERT INTO skill_executions (skill_name, success, tokens_used, duration_seconds, created)
        VALUES ('code_review', 1, 500, 2.5, '2026-04-01T10:00:00');

        INSERT INTO workflows (name, display_name, category, description, enabled)
        VALUES ('heartbeat', 'Heartbeat', 'system', 'System health check', 1);

        INSERT INTO config (key, value) VALUES ('agent_name', 'neuro');
        INSERT INTO config (key, value) VALUES ('anthropic_api_key', 'sk-ant-super-secret-key');
        INSERT INTO config (key, value) VALUES ('theme', 'dark');

        INSERT INTO satellite_dbs (name, db_path, description)
        VALUES ('findings', 'data/findings.db', 'Vulnerability findings');

        INSERT INTO evolution_outcomes (source, source_id, action, result, created_at)
        VALUES ('workflow', 'heartbeat', 'run_heartbeat', 'success', '2026-04-01T12:00:00');

        INSERT INTO evolution_metrics (metric_name, metric_value, source, period, recorded_at)
        VALUES ('success_rate', 0.95, 'workflow', 'daily', '2026-04-01T12:00:00');

        INSERT INTO evolution_cycles (started_at, completed_at, outcomes_analyzed, agent)
        VALUES ('2026-04-01T10:00:00', '2026-04-01T11:00:00', 50, 'neuro');

        INSERT INTO entities (name, type, category, mention_count, first_seen, last_seen)
        VALUES ('AIBrain', 'product', 'software', 15, '2026-01-01', '2026-04-01');

        INSERT INTO category_summaries (category, summary, memory_count, avg_importance, last_updated)
        VALUES ('project', 'Project memories', 100, 0.6, '2026-04-01');

        INSERT INTO approvals (created, title, status, category)
        VALUES ('2026-04-01T10:00:00', 'Deploy v2', 'approved', 'deployment');

        INSERT INTO agent_permissions (action_type, target, permission, granted_by)
        VALUES ('send_email', '*', 'allow_always', 'user');

        INSERT INTO scheduled_jobs (name, cron, prompt, enabled)
        VALUES ('daily_heartbeat', '0 8 * * *', 'Run heartbeat', 1);
    """)
    conn.commit()


# ---------------------------------------------------------------------------
# We need to mock aibrain_db's get_db to use our test DB
# ---------------------------------------------------------------------------

def _patch_db(conn):
    """Monkey-patch aibrain_db.get_db and config_get to use the given connection."""
    import aibrain_db

    def _mock_get_db():
        return conn

    def _mock_config_get(key, default=None):
        row = conn.execute("SELECT value FROM config WHERE key=?", (key,)).fetchone()
        if row:
            return row[0]
        return default

    aibrain_db.get_db = _mock_get_db
    aibrain_db.config_get = _mock_config_get


@pytest.fixture
def test_db(tmp_path):
    """Create and seed a test database, monkey-patch aibrain_db to use it."""
    import aibrain_db
    _original_get_db = aibrain_db.get_db
    _original_config_get = aibrain_db.config_get

    db_path = str(tmp_path / "test_aibrain.db")
    conn = _create_full_db(db_path)
    _seed_data(conn)
    _patch_db(conn)

    yield conn, tmp_path

    conn.close()
    aibrain_db.get_db = _original_get_db
    aibrain_db.config_get = _original_config_get


@pytest.fixture(autouse=True)
def _restore_aibrain_db_module(monkeypatch):
    """Autouse: always restore aibrain_db.get_db / config_get after every test.

    The _patch_db() helper mutates aibrain_db at module level. Previously only
    the ``test_db`` fixture restored the patch; tests that use ``import_db``
    (which calls _patch_db on the import conn) leaked the monkey-patched
    get_db — pointing at a now-closed tmp conn — into sibling test files
    (test_category_summaries in particular, see:
    'sqlite3.ProgrammingError: Cannot operate on a closed database.'
    once test_brain_export_import runs before test_category_summaries).

    monkeypatch captures the originals BEFORE every test and reverts them
    automatically at teardown, so no test can leak past its own scope.
    """
    import aibrain_db
    monkeypatch.setattr(aibrain_db, "get_db", aibrain_db.get_db, raising=False)
    monkeypatch.setattr(aibrain_db, "config_get", aibrain_db.config_get, raising=False)
    yield


@pytest.fixture
def import_db(tmp_path):
    """Create a second empty DB for import testing (does NOT auto-patch)."""
    db_path = str(tmp_path / "import_aibrain.db")
    conn = _create_full_db(db_path)
    conn.execute("INSERT INTO config (key, value) VALUES ('agent_name', 'case')")
    conn.commit()

    yield conn, tmp_path

    conn.close()


# ---------------------------------------------------------------------------
# Tests: Export
# ---------------------------------------------------------------------------

class TestExportNewTables:
    def test_export_includes_sync_version(self, test_db):
        conn, tmp_path = test_db
        import aibrain_db
        out = str(tmp_path / "export.json")
        aibrain_db.brain_export_redacted(out)

        data = json.loads(Path(out).read_text(encoding="utf-8"))
        assert data["metadata"]["sync_version"] == 2

    def test_export_includes_all_tables(self, test_db):
        conn, tmp_path = test_db
        import aibrain_db
        out = str(tmp_path / "export.json")
        aibrain_db.brain_export_redacted(out)

        data = json.loads(Path(out).read_text(encoding="utf-8"))

        # Original 5 tables
        assert len(data["memories"]) >= 1
        assert len(data["entities"]) >= 1
        assert len(data["facts"]) >= 1
        assert len(data["patterns"]) >= 1

        # New 18 tables
        assert len(data["companies"]) >= 1
        assert len(data["company_agents"]) >= 1
        assert len(data["company_issues"]) >= 1
        assert len(data["company_goals"]) >= 1
        assert len(data["company_projects"]) >= 1
        assert len(data["skills"]) >= 1
        assert len(data["skill_executions"]) >= 1
        assert len(data["workflows"]) >= 1
        assert len(data["config"]) >= 1
        assert len(data["satellite_dbs"]) >= 1
        assert len(data["evolution_outcomes"]) >= 1
        assert len(data["evolution_metrics"]) >= 1
        assert len(data["evolution_cycles"]) >= 1
        assert len(data["knowledge_entities"]) >= 1
        assert len(data["category_summaries"]) >= 1
        assert len(data["approvals"]) >= 1
        assert len(data["agent_permissions"]) >= 1
        assert len(data["scheduled_jobs"]) >= 1

    def test_export_metadata_counts(self, test_db):
        conn, tmp_path = test_db
        import aibrain_db
        out = str(tmp_path / "export.json")
        aibrain_db.brain_export_redacted(out)

        data = json.loads(Path(out).read_text(encoding="utf-8"))
        meta = data["metadata"]

        assert meta["companies_count"] == len(data["companies"])
        assert meta["company_agents_count"] == len(data["company_agents"])
        assert meta["workflows_count"] == len(data["workflows"])
        assert meta["skills_count"] == len(data["skills"])
        assert meta["knowledge_entities_count"] == len(data["knowledge_entities"])


class TestExportCredentialScrubbing:
    def test_config_sensitive_keys_redacted(self, test_db):
        conn, tmp_path = test_db
        import aibrain_db
        out = str(tmp_path / "export.json")
        aibrain_db.brain_export_redacted(out)

        data = json.loads(Path(out).read_text(encoding="utf-8"))
        config_dict = {c["key"]: c["value"] for c in data["config"]}

        assert config_dict["anthropic_api_key"] == "[REDACTED]"
        assert config_dict["agent_name"] == "neuro"
        assert config_dict["theme"] == "dark"

    def test_satellite_db_paths_relative(self, test_db):
        conn, tmp_path = test_db
        import aibrain_db

        # Insert a satellite with absolute path
        abs_path = str(Path(aibrain_db.__file__).parent / "data" / "absolute.db")
        conn.execute("INSERT INTO satellite_dbs (name, db_path) VALUES ('abs_test', ?)", (abs_path,))
        conn.commit()

        out = str(tmp_path / "export.json")
        aibrain_db.brain_export_redacted(out)

        data = json.loads(Path(out).read_text(encoding="utf-8"))
        sat_dict = {s["name"]: s["db_path"] for s in data["satellite_dbs"]}

        # The absolute path should now be relative
        assert not os.path.isabs(sat_dict["abs_test"])
        # The already-relative path should stay relative
        assert sat_dict["findings"] == "data/findings.db"


# ---------------------------------------------------------------------------
# Tests: Import
# ---------------------------------------------------------------------------

def _export_and_import(test_db, import_db):
    """Helper: export from test_db, switch to import_db, import."""
    conn, tmp_path = test_db
    import aibrain_db
    # Ensure source DB is active for export
    _patch_db(conn)
    out = str(tmp_path / "export.json")
    aibrain_db.brain_export_redacted(out)

    # Switch to import DB for import
    imp_conn, _ = import_db
    _patch_db(imp_conn)

    # Import file needs to be under home dir (path validation)
    import_file = str(Path.home() / "brain_test_import.json")
    Path(import_file).write_text(Path(out).read_text(encoding="utf-8"), encoding="utf-8")

    try:
        stats = aibrain_db.brain_import(import_file)
    finally:
        # Clean up temp file
        Path(import_file).unlink(missing_ok=True)

    return stats, imp_conn


class TestImportNewTables:

    def test_import_companies(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["companies_new"] == 1
        row = conn.execute("SELECT * FROM companies WHERE id='CO1'").fetchone()
        assert row is not None
        assert row["name"] == "DeckerOps"

    def test_import_company_agents(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["company_agents_replaced"] >= 1
        row = conn.execute("SELECT * FROM company_agents WHERE id='AG1'").fetchone()
        assert row is not None
        assert row["name"] == "Lead Engineer"

    def test_import_company_issues(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["company_issues_new"] == 1

    def test_import_company_goals(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["company_goals_new"] == 1

    def test_import_company_projects(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["company_projects_new"] == 1

    def test_import_skills(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["skills_new"] == 1

    def test_import_skill_executions(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["skill_executions_new"] == 1

    def test_import_workflows(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["workflows_new"] == 1

    def test_import_evolution_outcomes(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["evolution_outcomes_new"] == 1

    def test_import_evolution_metrics(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["evolution_metrics_new"] == 1

    def test_import_evolution_cycles(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["evolution_cycles_new"] == 1

    def test_import_knowledge_entities(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["knowledge_entities_new"] == 1

    def test_import_category_summaries(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["category_summaries_new"] == 1

    def test_import_approvals(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["approvals_new"] == 1

    def test_import_agent_permissions(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["agent_permissions_new"] == 1

    def test_import_scheduled_jobs(self, test_db, import_db):
        stats, conn = _export_and_import(test_db, import_db)
        assert stats["scheduled_jobs_new"] == 1


class TestImportNoDuplicates:
    def test_double_import_no_duplicates(self, test_db, import_db):
        """Importing the same export twice should not create duplicates."""
        conn, tmp_path = test_db
        import aibrain_db
        _patch_db(conn)
        out = str(tmp_path / "export.json")
        aibrain_db.brain_export_redacted(out)

        imp_conn, _ = import_db
        _patch_db(imp_conn)

        import_file = str(Path.home() / "brain_test_dup.json")
        Path(import_file).write_text(Path(out).read_text(encoding="utf-8"), encoding="utf-8")

        try:
            stats1 = aibrain_db.brain_import(import_file)
            stats2 = aibrain_db.brain_import(import_file)
        finally:
            Path(import_file).unlink(missing_ok=True)

        # Second import should have zero new for all tables
        assert stats2["companies_skipped"] >= 1
        assert stats2["companies_new"] == 0
        assert stats2["company_issues_skipped"] >= 1
        assert stats2["company_issues_new"] == 0
        assert stats2["skills_skipped"] >= 1
        assert stats2["skills_new"] == 0
        assert stats2["workflows_skipped"] >= 1
        assert stats2["workflows_new"] == 0
        assert stats2["evolution_outcomes_skipped"] >= 1
        assert stats2["evolution_outcomes_new"] == 0
        assert stats2["knowledge_entities_skipped"] >= 1
        assert stats2["knowledge_entities_new"] == 0
        assert stats2["scheduled_jobs_skipped"] >= 1
        assert stats2["scheduled_jobs_new"] == 0


class TestImportConfigScrubbing:
    def test_redacted_config_not_imported(self, test_db, import_db):
        """Config values that are [REDACTED] should be skipped on import."""
        conn, tmp_path = test_db
        import aibrain_db
        _patch_db(conn)
        out = str(tmp_path / "export.json")
        aibrain_db.brain_export_redacted(out)

        imp_conn, _ = import_db
        _patch_db(imp_conn)

        import_file = str(Path.home() / "brain_test_config.json")
        Path(import_file).write_text(Path(out).read_text(encoding="utf-8"), encoding="utf-8")

        try:
            stats = aibrain_db.brain_import(import_file)
        except Exception:
            Path(import_file).unlink(missing_ok=True)
            raise

        # anthropic_api_key was REDACTED so it should NOT be in the import DB
        row = imp_conn.execute(
            "SELECT value FROM config WHERE key='anthropic_api_key'"
        ).fetchone()
        assert row is None

        # Non-sensitive config should import
        theme = imp_conn.execute(
            "SELECT value FROM config WHERE key='theme'"
        ).fetchone()
        assert theme is not None
        assert theme["value"] == "dark"
        Path(import_file).unlink(missing_ok=True)


class TestImportCompanyAgentsReplace:
    def test_company_agent_update_propagates(self, test_db, import_db):
        """Company agents should use INSERT OR REPLACE so updates propagate."""
        conn, tmp_path = test_db
        import aibrain_db
        _patch_db(conn)
        out = str(tmp_path / "export.json")
        aibrain_db.brain_export_redacted(out)

        imp_conn, _ = import_db
        # Pre-insert an older version of the agent
        imp_conn.execute("""
            INSERT INTO companies (id, name) VALUES ('CO1', 'DeckerOps')
        """)
        imp_conn.execute("""
            INSERT INTO company_agents (id, company_id, name, role, title)
            VALUES ('AG1', 'CO1', 'Old Name', 'general', 'Old Title')
        """)
        imp_conn.commit()

        _patch_db(imp_conn)

        import_file = str(Path.home() / "brain_test_replace.json")
        Path(import_file).write_text(Path(out).read_text(encoding="utf-8"), encoding="utf-8")

        try:
            stats = aibrain_db.brain_import(import_file)
        finally:
            Path(import_file).unlink(missing_ok=True)

        row = imp_conn.execute("SELECT * FROM company_agents WHERE id='AG1'").fetchone()
        assert row["name"] == "Lead Engineer"  # Updated from export
        assert row["title"] == "Lead Engineer"


class TestBackwardCompatibility:
    def test_old_format_import_works(self, import_db):
        """Old exports with only 5 tables (no sync_version) should still import."""
        imp_conn, imp_path = import_db
        import aibrain_db
        _patch_db(imp_conn)

        # Build an old-format export (sync_version 1 / no version)
        old_export = {
            "metadata": {
                "export_date": "2026-04-01T00:00:00",
                "agent_name": "old_agent",
                "redacted": True,
                "memory_count": 1,
                "entity_count": 0,
                "fact_count": 0,
                "passage_count": 0,
                "pattern_count": 0,
            },
            "memories": [{
                "name": "old_mem", "type": "project",
                "memory_class": "semantic", "tags": "",
                "content": "old format memory", "importance": 0.5,
                "created": "2026-04-01T00:00:00",
            }],
            "entities": [],
            "facts": [],
            "passages": [],
            "patterns": [],
            # No new tables at all
        }

        import_file = str(Path.home() / "brain_test_old.json")
        Path(import_file).write_text(json.dumps(old_export), encoding="utf-8")

        try:
            stats = aibrain_db.brain_import(import_file)
        except Exception:
            Path(import_file).unlink(missing_ok=True)
            raise

        # Should import the memory
        assert stats["memories_new"] == 1
        # All new table stats should be 0 (no data to import)
        assert stats["companies_new"] == 0
        assert stats["company_agents_replaced"] == 0
        assert stats["workflows_new"] == 0
        assert stats["skills_new"] == 0

        # Verify the memory was actually inserted
        row = imp_conn.execute("SELECT * FROM memories WHERE name='old_mem'").fetchone()
        assert row is not None
        Path(import_file).unlink(missing_ok=True)


class TestImportIdCollision:
    """Verify brain_import remaps IDs when collisions exist, preventing silent data loss."""

    def test_company_id_remapped_on_collision(self, import_db):
        """When importing a company with an ID that already exists, a new ID is generated."""
        imp_conn, imp_path = import_db
        import aibrain_db
        _patch_db(imp_conn)

        # Pre-insert a company with the same ID but different data
        imp_conn.execute(
            "INSERT INTO companies (id, name, mission, status, created_at, updated_at) "
            "VALUES ('COLLISION1', 'Existing Co', 'existing', 'active', '2026-01-01', '2026-01-01')"
        )
        imp_conn.commit()

        export_data = {
            "metadata": {"export_date": "2026-04-01", "agent_name": "other_brain",
                         "redacted": True, "memory_count": 0, "entity_count": 0,
                         "fact_count": 0, "passage_count": 0, "pattern_count": 0},
            "memories": [], "entities": [], "facts": [], "passages": [], "patterns": [],
            "companies": [{"id": "COLLISION1", "name": "New Co", "mission": "new",
                          "status": "active", "created_at": "2026-04-01", "updated_at": "2026-04-01"}],
            "company_agents": [], "company_issues": [], "company_goals": [], "company_projects": [],
        }

        import_file = str(Path.home() / "brain_test_collision.json")
        Path(import_file).write_text(json.dumps(export_data), encoding="utf-8")

        try:
            stats = aibrain_db.brain_import(import_file)
        finally:
            Path(import_file).unlink(missing_ok=True)

        # Both companies should exist (original + imported with new ID)
        companies = imp_conn.execute("SELECT * FROM companies").fetchall()
        assert len(companies) == 2, f"Expected 2 companies, got {len(companies)}"
        names = {c["name"] for c in companies}
        assert "Existing Co" in names
        assert "New Co" in names
        assert stats["companies_new"] == 1

    def test_issue_fk_remapped_to_new_company_id(self, import_db):
        """When company ID is remapped, issues should reference the new company ID."""
        imp_conn, imp_path = import_db
        import aibrain_db
        _patch_db(imp_conn)

        # Pre-insert a company to cause collision
        imp_conn.execute(
            "INSERT INTO companies (id, name, created_at, updated_at) "
            "VALUES ('CO_COLLIDE', 'Existing', '2026-01-01', '2026-01-01')"
        )
        imp_conn.commit()

        export_data = {
            "metadata": {"export_date": "2026-04-01", "agent_name": "other",
                         "redacted": True, "memory_count": 0, "entity_count": 0,
                         "fact_count": 0, "passage_count": 0, "pattern_count": 0},
            "memories": [], "entities": [], "facts": [], "passages": [], "patterns": [],
            "companies": [{"id": "CO_COLLIDE", "name": "Imported Co",
                          "created_at": "2026-04-01", "updated_at": "2026-04-01"}],
            "company_agents": [],
            "company_issues": [{"id": "ISS1", "company_id": "CO_COLLIDE",
                               "title": "Test Issue", "created_at": "2026-04-01",
                               "updated_at": "2026-04-01"}],
            "company_goals": [], "company_projects": [],
        }

        import_file = str(Path.home() / "brain_test_fk.json")
        Path(import_file).write_text(json.dumps(export_data), encoding="utf-8")

        try:
            stats = aibrain_db.brain_import(import_file)
        finally:
            Path(import_file).unlink(missing_ok=True)

        assert stats["company_issues_new"] == 1
        # The issue's company_id should point to the remapped company, not the collision ID
        issue = imp_conn.execute("SELECT * FROM company_issues WHERE title='Test Issue'").fetchone()
        assert issue is not None
        # The issue's company_id should match the new company, not the existing one
        imported_co = imp_conn.execute(
            "SELECT id FROM companies WHERE name='Imported Co'"
        ).fetchone()
        assert imported_co is not None
        assert issue["company_id"] == imported_co["id"]

    def test_no_collision_preserves_original_id(self, import_db):
        """When no collision exists, the original ID is kept."""
        imp_conn, imp_path = import_db
        import aibrain_db
        _patch_db(imp_conn)

        export_data = {
            "metadata": {"export_date": "2026-04-01", "agent_name": "other",
                         "redacted": True, "memory_count": 0, "entity_count": 0,
                         "fact_count": 0, "passage_count": 0, "pattern_count": 0},
            "memories": [], "entities": [], "facts": [], "passages": [], "patterns": [],
            "companies": [{"id": "UNIQUE_ID_123", "name": "Unique Co",
                          "created_at": "2026-04-01", "updated_at": "2026-04-01"}],
            "company_agents": [], "company_issues": [], "company_goals": [],
            "company_projects": [],
        }

        import_file = str(Path.home() / "brain_test_nocolli.json")
        Path(import_file).write_text(json.dumps(export_data), encoding="utf-8")

        try:
            stats = aibrain_db.brain_import(import_file)
        finally:
            Path(import_file).unlink(missing_ok=True)

        # ID should be preserved since there was no collision
        row = imp_conn.execute("SELECT id FROM companies WHERE name='Unique Co'").fetchone()
        assert row is not None
        assert row["id"] == "UNIQUE_ID_123"

    def test_goal_project_fk_chain_remapped(self, import_db):
        """Goals and projects with remapped company_id + goal FKs are consistent."""
        imp_conn, imp_path = import_db
        import aibrain_db
        _patch_db(imp_conn)

        # Cause collision on company
        imp_conn.execute(
            "INSERT INTO companies (id, name, created_at, updated_at) "
            "VALUES ('CHAIN_CO', 'Old', '2026-01-01', '2026-01-01')"
        )
        imp_conn.commit()

        export_data = {
            "metadata": {"export_date": "2026-04-01", "agent_name": "chain",
                         "redacted": True, "memory_count": 0, "entity_count": 0,
                         "fact_count": 0, "passage_count": 0, "pattern_count": 0},
            "memories": [], "entities": [], "facts": [], "passages": [], "patterns": [],
            "companies": [{"id": "CHAIN_CO", "name": "Chain Co",
                          "created_at": "2026-04-01", "updated_at": "2026-04-01"}],
            "company_agents": [],
            "company_issues": [],
            "company_goals": [{"id": "GOAL1", "company_id": "CHAIN_CO",
                              "title": "Goal One", "created_at": "2026-04-01",
                              "updated_at": "2026-04-01"}],
            "company_projects": [{"id": "PROJ1", "company_id": "CHAIN_CO",
                                 "name": "Project One", "related_goal_ids": '["GOAL1"]',
                                 "created_at": "2026-04-01", "updated_at": "2026-04-01"}],
        }

        import_file = str(Path.home() / "brain_test_chain.json")
        Path(import_file).write_text(json.dumps(export_data), encoding="utf-8")

        try:
            stats = aibrain_db.brain_import(import_file)
        finally:
            Path(import_file).unlink(missing_ok=True)

        # Verify FK consistency: project's company_id matches goal's company_id
        goal = imp_conn.execute("SELECT * FROM company_goals WHERE title='Goal One'").fetchone()
        project = imp_conn.execute("SELECT * FROM company_projects WHERE name='Project One'").fetchone()
        assert goal is not None and project is not None
        assert goal["company_id"] == project["company_id"]
        # And both point to the remapped company
        imported_co = imp_conn.execute("SELECT id FROM companies WHERE name='Chain Co'").fetchone()
        assert goal["company_id"] == imported_co["id"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
