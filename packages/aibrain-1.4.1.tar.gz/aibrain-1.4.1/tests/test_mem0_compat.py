"""
Tests for aibrain.integrations.mem0_compat — Mem0 MemoryClient compatibility layer.

Uses mocks so no real DB or Mem0 install is required.
"""

from unittest.mock import MagicMock

import pytest


# ---------------------------------------------------------------------------
# Fixture: mock Brain
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_brain():
    """Return a MagicMock Brain with sensible defaults."""
    brain = MagicMock()
    brain.add.return_value = [{"id": 1, "memory": "test fact", "event": "ADD"}]
    brain.search.return_value = [
        {"id": 1, "memory": "User likes Python", "score": 0.95,
         "user_id": "alice", "agent_id": "", "created_at": "", "updated_at": "",
         "metadata": {}, "reason": "semantic", "score_breakdown": {}},
    ]
    brain.get.return_value = {
        "id": 1, "memory": "User likes Python", "user_id": "alice",
        "agent_id": "", "created_at": "", "updated_at": "", "metadata": {},
    }
    brain.get_all.return_value = [
        {"id": 1, "memory": "User likes Python", "user_id": "alice",
         "agent_id": "", "created_at": "", "updated_at": "", "metadata": {}},
        {"id": 2, "memory": "User lives in Adelaide", "user_id": "alice",
         "agent_id": "", "created_at": "", "updated_at": "", "metadata": {}},
    ]
    brain.delete.return_value = True
    brain.delete_all.return_value = 2
    brain.history.return_value = [
        {"memory_id": 1, "action": "created", "new_content": "User likes Python"},
    ]
    brain.update.return_value = {
        "id": 1, "memory": "User likes Rust", "user_id": "alice",
    }
    return brain


@pytest.fixture
def client(mock_brain):
    """Create a MemoryClient with mocked Brain."""
    from aibrain.integrations.mem0_compat import MemoryClient
    mc = object.__new__(MemoryClient)
    mc._brain = mock_brain
    return mc


# ---------------------------------------------------------------------------
# Core API tests
# ---------------------------------------------------------------------------

class TestMem0CompatAdd:
    """Test add() maps correctly to Brain.add()."""

    def test_add_string(self, client, mock_brain):
        result = client.add("User likes Python", user_id="alice")
        assert result[0]["event"] == "ADD"
        mock_brain.add.assert_called_once_with(
            "User likes Python",
            user_id="alice",
            agent_id=None,
            metadata=None,
            infer=True,
        )

    def test_add_messages_list(self, client, mock_brain):
        msgs = [{"role": "user", "content": "I like chess"}]
        client.add(msgs, user_id="bob")
        mock_brain.add.assert_called_once()
        args = mock_brain.add.call_args
        assert args[0][0] == msgs

    def test_add_with_run_id_stored_in_metadata(self, client, mock_brain):
        client.add("fact", user_id="alice", run_id="run-123")
        _, kwargs = mock_brain.add.call_args
        assert kwargs["metadata"]["run_id"] == "run-123"

    def test_add_with_metadata(self, client, mock_brain):
        client.add("fact", metadata={"source": "web"}, user_id="alice")
        _, kwargs = mock_brain.add.call_args
        assert kwargs["metadata"]["source"] == "web"


class TestMem0CompatSearch:
    """Test search() maps correctly to Brain.search()."""

    def test_search_returns_results(self, client, mock_brain):
        results = client.search("Python", user_id="alice", limit=5)
        assert len(results) == 1
        assert results[0]["memory"] == "User likes Python"
        mock_brain.search.assert_called_once_with(
            "Python", user_id="alice", agent_id=None, limit=5,
        )

    def test_search_default_limit(self, client, mock_brain):
        client.search("query")
        _, kwargs = mock_brain.search.call_args
        assert kwargs["limit"] == 10


class TestMem0CompatGet:
    """Test get() and get_all()."""

    def test_get_single(self, client, mock_brain):
        result = client.get(1)
        assert result["id"] == 1
        mock_brain.get.assert_called_once_with(1)

    def test_get_all(self, client, mock_brain):
        results = client.get_all(user_id="alice")
        assert len(results) == 2
        mock_brain.get_all.assert_called_once_with(
            user_id="alice", agent_id=None, limit=100,
        )


class TestMem0CompatDelete:
    """Test delete() and delete_all()."""

    def test_delete(self, client, mock_brain):
        assert client.delete(1) is True
        mock_brain.delete.assert_called_once_with(1)

    def test_delete_all(self, client, mock_brain):
        count = client.delete_all(user_id="alice")
        assert count == 2


class TestMem0CompatHistory:
    """Test history()."""

    def test_history(self, client, mock_brain):
        hist = client.history(1)
        assert len(hist) == 1
        assert hist[0]["action"] == "created"
        mock_brain.history.assert_called_once_with(1)


class TestMem0CompatUpdate:
    """Test update()."""

    def test_update(self, client, mock_brain):
        result = client.update(1, "User likes Rust")
        assert result["memory"] == "User likes Rust"
        mock_brain.update.assert_called_once_with(1, "User likes Rust", metadata=None)


class TestMem0CompatMisc:
    """Test edge cases and migration helper."""

    def test_api_key_ignored(self, mock_brain):
        """api_key param is accepted but ignored (no cloud)."""
        from aibrain.integrations.mem0_compat import MemoryClient
        mc = object.__new__(MemoryClient)
        mc._brain = mock_brain
        # Should work fine — api_key is just for signature compat
        result = mc.search("test")
        assert isinstance(result, list)

    def test_reset_is_noop(self, client):
        client.reset()  # Should not raise

    def test_migrate_from_mem0(self, mock_brain):
        """Migration helper reads from source and writes to destination."""
        from aibrain.integrations.mem0_compat import migrate_from_mem0

        # Mock Mem0 source client
        mem0_source = MagicMock()
        mem0_source.get_all.return_value = [
            {"id": 10, "memory": "fact one", "user_id": "alice"},
            {"id": 11, "memory": "fact two", "user_id": "alice"},
            {"id": 12, "memory": "", "user_id": "alice"},  # empty — should skip
        ]

        # Destination AIBrain client
        from aibrain.integrations.mem0_compat import MemoryClient
        dest = object.__new__(MemoryClient)
        dest._brain = mock_brain

        result = migrate_from_mem0(mem0_source, dest, user_id="alice")
        assert result["migrated"] == 2
        assert result["skipped"] == 1
        assert result["errors"] == 0

    def test_migrate_handles_source_error(self):
        """Migration handles errors from source gracefully."""
        from aibrain.integrations.mem0_compat import migrate_from_mem0, MemoryClient

        broken_source = MagicMock()
        broken_source.get_all.side_effect = ConnectionError("API down")

        dest = MagicMock(spec=MemoryClient)
        result = migrate_from_mem0(broken_source, dest)
        assert result["errors"] == 1
        assert result["migrated"] == 0
